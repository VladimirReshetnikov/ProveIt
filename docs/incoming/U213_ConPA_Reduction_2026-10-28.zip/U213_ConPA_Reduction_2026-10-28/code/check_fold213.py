#!/usr/bin/env python3
"""Exhaustive finite certificate for the guarded 214 -> 213 fold 167 -> 172.

All binary tapes in initial native state 0 are covered.  Only cells -1,0,1
are used in exceptional blocks; radius-two enumeration also checks all
ordinary steps and induction of the predecessor-written-one invariant.
This is an executable mathematical certificate, not a proof-assistant kernel.
"""
from pathlib import Path
import argparse
import hashlib
import itertools
import json

REMOVED = 167
REPRESENTATIVE = 172
HALT = 254


def need(condition, message):
    if not condition:
        raise ValueError(message)


def parse(path, expected):
    table = {}
    headers = []
    for line in path.read_text().splitlines():
        if line.startswith('#! start '):
            headers.append(line)
        if not line or line.startswith('#'):
            continue
        q, b, w, d, z = line.split()
        q, b, w, z = map(int, (q, b, w, z))
        need(q >= 0 and z >= 0 and b in (0, 1) and w in (0, 1), 'bad row')
        need(d in ('L', 'R'), 'bad move')
        need((q, b) not in table, 'duplicate row')
        table[q, b] = (w, 1 if d == 'R' else -1, z)
    states = {q for q, _ in table}
    need(headers == ['#! start 0'], 'wrong start header')
    need(len(states) == expected, 'wrong state census')
    need(set(table) == {(q, b) for q in states for b in (0, 1)}, 'incomplete')
    need(0 in states and HALT not in states, 'wrong initial or halt state')
    need({z for _, _, z in table.values()} - states == {HALT}, 'wrong closure')
    return table, states


def project(q):
    return REPRESENTATIVE if q == REMOVED else q


def invariant(q, h, tape):
    return q != REMOVED or tape[h - 1] == 1


def run(table, q, h, tape, ticks, check_old=False):
    tape = dict(tape)
    trace = []
    for _ in range(ticks):
        need(q != HALT, 'premature halt in a block')
        need(h in tape, 'opaque exterior was read')
        b = tape[h]
        w, d, z = table[q, b]
        trace.append([q, h, b, w, d, z])
        tape[h] = w
        q, h = z, h + d
        if check_old:
            need(invariant(q, h, tape), 'predecessor invariant is not inductive')
    return q, h, tape, trace


def finite_check(old, new, states):
    admitted = 0
    counts = {}
    examples = {}
    for q in sorted(states):
        for bits in itertools.product((0, 1), repeat=5):
            tape = dict(zip(range(-2, 3), bits))
            if not invariant(q, 0, tape):
                continue
            admitted += 1
            old_ticks, new_ticks = (2, 6) if (q, tape[0]) == (167, 0) else (1, 1)
            oq, oh, ot, old_trace = run(old, q, 0, tape, old_ticks, True)
            nq, nh, nt, new_trace = run(new, project(q), 0, tape, new_ticks)
            need((nq, nh, nt) == (project(oq), oh, ot),
                 ('block endpoint differs', q, bits, old_trace, new_trace))
            tag = f'{old_ticks}:{new_ticks}'
            counts[tag] = counts.get(tag, 0) + 1
            if q == 167:
                tag = str(tape[0]) if tape[0] else f'0,{tape[1]}'
                examples.setdefault(tag, {
                    'old_trace': old_trace,
                    'new_trace': new_trace,
                    'endpoint_state': nq,
                    'endpoint_head': nh,
                    'tape_unchanged': tape == ot == nt,
                })
    return admitted, counts, examples


def controls(old, new, states):
    rejected = []

    def test(name, a, b):
        try:
            finite_check(a, b, states)
        except (ValueError, KeyError) as error:
            rejected.append({'name': name, 'status': 'REJECTED',
                             'reason': str(error)[:240]})
        else:
            raise ValueError('bad mutation accepted: ' + name)

    a, b = dict(old), dict(new)
    a[158, 1] = (0, 1, 167)
    b[158, 1] = (0, 1, 172)
    test('wrong predecessor write destroys invariant', a, b)
    b = dict(new)
    b[172, 0] = (0, 1, 112)
    test('wrong initial direction', old, b)
    b = dict(new)
    b[209, 0] = (0, 1, 61)
    test('wrong intermediate state', old, b)
    b = dict(new)
    b[186, 1] = (0, 1, 86)
    test('wrong write in the next-cell-one branch', old, b)
    b = dict(new)
    b[151, 0] = (0, 1, 91)
    test('wrong next-cell-zero exit', old, b)
    return rejected


def verify(old, new, states):
    expected = {(q, b): (w, d, project(z))
                for (q, b), (w, d, z) in old.items() if q != REMOVED}
    need(new == expected, 'new table is not the exact guarded fold')
    incoming = sorted((q, b, *row) for (q, b), row in old.items()
                      if row[2] == REMOVED)
    need(incoming == [(158, 1, 1, 1, 167)], 'wrong guard predecessor')
    admitted, counts, examples = finite_check(old, new, states)
    return {
        'status': 'U213_EXHAUSTIVE_GUARDED_FOLD_PASS',
        'old_working_states': 214,
        'new_working_states': 213,
        'removed_state': REMOVED,
        'representative_state': REPRESENTATIVE,
        'initial_state': 0,
        'initial_tape_scope': 'ALL_BINARY_TAPES',
        'guard': 'old state 167 implies tape[head-1] = 1',
        'incoming_guard': incoming,
        'all_radius_two_frames': 32 * len(states),
        'admitted_frames': admitted,
        'old_new_block_lengths': counts,
        'special_cases': examples,
        'time_bounds': 'old halts at n implies new halts at m with n<=m<=3*n; '
                       'new halts at m implies old halts at n with m/3<=n<=m',
        'proof': 'Ordinary blocks are 1:1. At old 167/read 0 the old block '
                 'has length 2 and the new block length 6; otherwise blocks '
                 'have length 1. Guard induction and exact full-tape endpoint '
                 'equality yield synchronized runs. Blocks have positive '
                 'bounded length and contain no internal halt. This gives '
                 'both directions of halting equivalence by PA induction.',
        'proof_assistant_kernel_certificate': False,
        'negative_controls': controls(old, new, states),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('old', type=Path)
    parser.add_argument('new', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    old, states = parse(args.old, 214)
    new, _ = parse(args.new, 213)
    result = verify(old, new, states)
    result['input_sha256'] = {
        key: hashlib.sha256(path.read_bytes()).hexdigest()
        for key, path in [('old', args.old), ('new', args.new)]
    }
    text = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(text)
    print(text, end='')


if __name__ == '__main__':
    main()
