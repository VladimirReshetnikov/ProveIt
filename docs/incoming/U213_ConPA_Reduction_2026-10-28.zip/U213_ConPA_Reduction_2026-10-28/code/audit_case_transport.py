#!/usr/bin/env python3
"""Audit saved U213 case-proof reuse and rederive its four list schemas.

This is an independent receipt/dependency audit, not a regeneration of the
5,109 primitive derivations. The historical partial run is not certified as
a whole. Its completed, individually proved records are reused only if every
recorded table dependency is unchanged. Use the release's --full reproduction
mode to regenerate all final primitive derivations without historical reuse.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import sys
import zipfile

EXPECTED = {
    "inputs/U214_ConPA_Reduction_2026-10-28.zip": "b3a520e2181b739fec7257a7935b979acb00400f8d8147b5a2c212fd53a38d2c",
    "machine/u213.native.tm": "536872ebb6247342bdfd9fd0f50e71def3733e9514ae43971edcc7bc7beddd6c",
    "machine/sites.json": "f746fd0a238449ddb81d1cfb2be93d823d26f54fcc5296c680a28e5f02587af0",
    "research/rejected_allocation/rejected213.native.tm": "3e6e15d7fc308c29f97e3798f209bc314b7fa9516f5dbfce9ef7c1c54d9230e2",
    "research/rejected_allocation/partial_runtime.json": "daefb3f0288b0dde031035884b18b9f45360ca2e341bb654407adbbebe049010",
    "research/rejected_allocation/partial_runtime_cases.json": "0307b6fb3b5a9dbc716e57aeb92362a8c96b3d1d391fe38a2cd0796052863330",
    "code/runtime/symbolic_runtime.py": "7ca30fd11def00e973d8f30997e51fa2dd87ae2eff311ea8c9fc4ac08c9d774f",
    "code/runtime/independent_runtime.py": "0d1dae10b921cc302a2211d9251ca7ec131aa63ecb040ce66720894877700346",
    "code/validate_transport.py": "d9ebc1a479e6c4c5b13b1fd47b6b417e798e85b808a0762be44d13f8ac7caa57",
}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def case_key(record):
    need(type(record["site_index"]) is int and type(record["positive"]) is bool,
         "Malformed case key")
    return record["site_index"], record["positive"]


def table(path):
    result = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith("#"):
            continue
        q, b, w, direction, target = line.split()
        q, b, w, target = map(int, (q, b, w, target))
        need((q, b) not in result and b in (0, 1) and w in (0, 1)
             and direction in ("L", "R"), "Malformed transition row")
        result[q, b] = w, 1 if direction == "R" else -1, target
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    hashes = {name: digest(root / name) for name in EXPECTED}
    need(hashes == EXPECTED, "Frozen input hash mismatch")

    inherited = ["code/validate_native.py", "code/inputs/legacy_mapping.json",
                 "code/runtime/symbolic_runtime.py", "code/runtime/independent_runtime.py"]
    with zipfile.ZipFile(root / "inputs/U214_ConPA_Reduction_2026-10-28.zip") as archive:
        for name in inherited:
            need(archive.read("U214_ConPA_Reduction_2026-10-28/" + name)
                 == (root / name).read_bytes(), "Inherited file changed: " + name)
            hashes[name] = digest(root / name)

    old = table(root / "research/rejected_allocation/rejected213.native.tm")
    new = table(root / "machine/u213.native.tm")
    need(set(old) == set(new) and len(new) == 426, "Changed row domain")
    states = {q for q, b in new}
    need(len(states) == 213 and all((q, b) in new for q in states for b in (0, 1)),
         "Incomplete binary table")
    need({target for w, d, target in new.values()} - states == {254}, "Halt convention")
    changed = [key for key in sorted(old) if old[key] != new[key]]
    need(changed == [(101, 0)] and old[101, 0] == (0, 1, 150)
         and new[101, 0] == (0, 1, 182), "Wrong one-row repair")
    mapping = {int(q): value for q, value in load(root / "code/inputs/legacy_mapping.json").items()}
    for q in states | {254}:
        mapping.setdefault(q, q + 1000)
    need(len({mapping[q] for q in states | {254}}) == 214, "Noninjective label mapping")
    need(mapping[101] == 117 and mapping[254] == 254, "Unexpected runtime labels")
    old_runtime = {(mapping[q], b): (w, d, mapping[z]) for (q, b), (w, d, z) in old.items()}
    new_runtime = {(mapping[q], b): (w, d, mapping[z]) for (q, b), (w, d, z) in new.items()}

    prior = load(root / "research/rejected_allocation/partial_runtime.json")
    previous = load(root / "research/rejected_allocation/partial_runtime_cases.json")
    final = load(root / "evidence/u213/runtime.json")
    records = load(root / "evidence/u213/runtime_cases.json")
    transport = load(root / "evidence/u213/transport.json")
    sites = load(root / "machine/sites.json")
    expected_keys = [(i, positive) for i, site in enumerate(sites)
                     for positive in ((False, True) if site[1] == "CD" else (False,))]
    need(len(sites) == 3928 and len(expected_keys) == 5109, "Wrong source coverage")
    need([case_key(record) for record in previous] == expected_keys[:4229],
         "Prior completed-case prefix differs")
    need([case_key(record) for record in records] == expected_keys, "Final case coverage differs")
    old_records = {case_key(record): record for record in previous}
    final_records = {case_key(record): record for record in records}
    need(prior["status"] == "NOT_PROVED" and prior["proved_cases"] == len(previous) == 4229,
         "Wrong prior partial status")
    need(final["status"] == "UNIVERSAL_MATHEMATICAL_PASS" and not final["failures"]
         and final["expected_cases"] == final["proved_cases"] == len(records) == 5109,
         "Final status/coverage mismatch")
    for report, path in [(prior, "research/rejected_allocation/rejected213.native.tm"),
                         (final, "machine/u213.native.tm")]:
        need(report["table_sha256"] == hashes[path], "Summary/table binding mismatch")
        need(report["sites_sha256"] == hashes["machine/sites.json"], "Summary/source binding mismatch")
        need(report["checker_sha256"] == hashes["code/runtime/symbolic_runtime.py"], "Checker binding")
        need(report["helper_sha256"] == hashes["code/runtime/independent_runtime.py"], "Helper binding")
        need(report["working_states"] == 213 and report["site_count"] == 3928, "Summary dimensions")

    for record in previous + records:
        rows = [tuple(row) for row in record["rows"]]
        need(rows == sorted(set(rows)) and all(row in old_runtime for row in rows),
             "Malformed recorded dependency set")
        duration = record["duration"]
        need(len(duration) == 13 and all(type(n) is int and n >= 0 for n in duration)
             and duration[0] > 0, "Nonpositive symbolic progress")
        need(sum(record["kinds"].values()) == record["symbolic_steps"], "Event count mismatch")

    reusable = [key for key in expected_keys if key in old_records
                and all(old_runtime[tuple(row)] == new_runtime[tuple(row)]
                        for row in old_records[key]["rows"])]
    rederived = [key for key in expected_keys if key not in set(reusable)]
    need(len(reusable) == 4194 and len(rederived) == 915, "Wrong reuse partition")
    need(transport["reused_cases"] == [list(key) for key in reusable], "Reuse receipt mismatch")
    need(transport["rederived_cases"] == [list(key) for key in rederived], "Rederivation receipt mismatch")
    need(transport["changed_native_rows"] == [[101, 0]]
         and transport["changed_runtime_rows"] == [[117, 0]], "Repair row receipt mismatch")
    for key in reusable:
        need(old_records[key] == final_records[key], "Transported record changed")
    reuse = final["case_proof_reuse"]
    need(reuse == {
        "prior_overall_status": "NOT_PROVED", "prior_individually_proved_cases": 4229,
        "unchanged_row_derivations_transported": 4194, "cases_freshly_rederived": 915,
        "all_four_list_schemas_rederived": True,
        "prior_table_sha256": hashes["research/rejected_allocation/rejected213.native.tm"],
        "prior_summary_sha256": hashes["research/rejected_allocation/partial_runtime.json"],
        "prior_cases_sha256": hashes["research/rejected_allocation/partial_runtime_cases.json"],
        "transport_checker_sha256": hashes["code/validate_transport.py"],
    }, "Proof-reuse binding differs")

    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root / "code/runtime"))
    import symbolic_runtime as symbolic
    old_lemmas, old_blocks = symbolic.prove_blocks(old_runtime)
    new_lemmas, new_blocks = symbolic.prove_blocks(new_runtime)
    need(old_lemmas == new_lemmas and old_blocks == new_blocks, "List schemas changed")
    need(json.loads(json.dumps(new_blocks)) == final["blocks"] == prior["blocks"],
         "Saved list-schema derivation differs")

    # A static count corroborates the manual dependency-closure review below.
    tree = ast.parse((root / "code/runtime/symbolic_runtime.py").read_text())
    reads = [node for node in ast.walk(tree) if isinstance(node, ast.Subscript)
             and isinstance(node.value, ast.Name) and node.value.id == "table"]
    need(len(reads) == 1, "Table-access site changed; manual review required")

    report = {
        "status": "CASE_PROOF_TRANSPORT_AUDIT_PASS",
        "audit_checker_sha256": digest(Path(__file__)),
        "bindings": dict(sorted(hashes.items())),
        "prior_complete_case_records": 4229,
        "final_complete_case_records": 5109,
        "copied_records_identical": 4194,
        "rederived_records": 915,
        "previously_completed_cases_affected_by_repair": 35,
        "previously_missing_cases": 880,
        "changed_native_rows": [[101, 0]],
        "changed_runtime_rows": [[117, 0]],
        "reuse_and_rederivation_disjoint_complete_ordered_partition": True,
        "all_reused_literal_and_unary_dependencies_unchanged": True,
        "four_list_schemas_independently_rederived_in_both_tables": True,
        "wrapper_mapping_and_rule_modules_byte_identical_to_pinned_U214_zip": True,
        "dependency_closure_review": [
            "State.step has one table-read expression. It produces either a literal event or a unary event containing that row's key.",
            "case records the key of every successful non-list event before its next iteration can return a completed record.",
            "A failed State.step or case produces no completed record and is never transported.",
            "List events consult only the four exact-table schemas; these were rederived and found identical for both tables.",
            "Normalization, guard splitting, initial frames, target frames, progress and displacement checks have no additional table access.",
            "With fixed source, rules, wrapper, label mapping and list schemas, unchanged row dependencies give the same deterministic symbolic derivation by induction on its events.",
        ],
        "scope": "Saved-record/dependency audit with fresh four-schema derivations; not a regeneration of 5109 primitive proofs and not a proof-assistant kernel check.",
        "historical_provenance_limit": "The prior summary binds source, table and two rule modules. The transport receipt binds the prior summary and case-file bytes. The wrapper and label mapping are presently byte-identical to the pinned baseline ZIP, but the historical summary did not separately hash them. This audit does not claim signed attestation of historical execution.",
        "rejected_table_status": "The earlier overall NOT_PROVED table remains rejected. Only its completed individual derivations with unchanged dependencies are reused.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(report["status"])


if __name__ == "__main__":
    main()
