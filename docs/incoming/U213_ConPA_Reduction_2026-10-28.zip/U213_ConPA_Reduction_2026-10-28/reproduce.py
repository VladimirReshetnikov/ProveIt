#!/usr/bin/env python3
"""Offline U213 construction and mathematical certificate replay.

Python 3.10+, standard library only. --full rederives all arbitrary-register
cases; --parent-full also replays the complete retained U214 baseline.
This does not claim a new proof-assistant kernel certificate of Con(PA).
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, shutil, stat, subprocess, sys, tempfile, time, zipfile

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT/'code'))
from reconstruct_u213 import reconstruct


def need(ok, why):
    if not ok:
        raise ValueError(why)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def manifest():
    seen = set()
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        p = PurePosixPath(name)
        need(not p.is_absolute() and '..' not in p.parts and '\\' not in name,
             'Unsafe manifest path')
        need(name not in seen, 'Duplicate manifest path')
        seen.add(name)
        need(sha(ROOT/name) == digest, 'Digest mismatch: '+name)
    need({'reproduce.py','machine/u213.tm','machine/u213.native.tm',
          'machine/sites.json','paper/report.tex','paper/report.pdf',
          'inputs/U214_ConPA_Reduction_2026-10-28.zip'} <= seen,
         'Principal artifact omitted from manifest')
    return len(seen)


def extract(archive, dest):
    with zipfile.ZipFile(archive) as z:
        seen = set()
        for info in z.infolist():
            p = PurePosixPath(info.filename)
            need(not p.is_absolute() and '..' not in p.parts and '\\' not in info.filename,
                 'Unsafe archive path')
            need(info.filename not in seen and
                 not stat.S_ISLNK((info.external_attr >> 16) & 0xffff),
                 'Duplicate archive member or symlink')
            seen.add(info.filename)
            target = dest.joinpath(*p.parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src, target.open('wb') as dst:
                    shutil.copyfileobj(src, dst)


def command(script, args, work, label):
    print(label+' ...', flush=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONOPTIMIZE', None)
    result = subprocess.run([sys.executable,'-B',str(script),*map(str,args)],
                            cwd=work, env=env, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    if result.returncode:
        print(result.stdout, end='')
        raise RuntimeError(label+' failed')
    print(label+': PASS', flush=True)


def runtime_audit(folder):
    report = load(folder/'runtime.json')
    cases = load(folder/'runtime_cases.json')
    sites = load(ROOT/'machine/sites.json')
    need(report['status'] == 'UNIVERSAL_MATHEMATICAL_PASS' and not report['failures'],
         'Runtime proof is incomplete')
    need(report['table_sha256'] == sha(ROOT/'machine/u213.native.tm') and
         report['sites_sha256'] == sha(ROOT/'machine/sites.json'),
         'Runtime input binding differs')
    need(report['checker_sha256'] == sha(ROOT/'code/runtime/symbolic_runtime.py') and
         report['helper_sha256'] == sha(ROOT/'code/runtime/independent_runtime.py'),
         'Runtime rule implementation binding differs')
    need(report['working_states'] == 213 and report['site_count'] == 3928 and
         report['proved_cases'] == report['expected_cases'] == len(cases) == 5109,
         'Wrong runtime census')
    expected = {(i,p) for i,site in enumerate(sites)
                for p in ((False,True) if site[1] == 'CD' else (False,))}
    need({(x['site_index'],x['positive']) for x in cases} == expected and
         len(expected) == len(cases), 'Missing or duplicate guarded outcome')
    need(all(x['duration'][0] > 0 and all(v >= 0 for v in x['duration'])
             for x in cases), 'A case lacks positive symbolic duration')
    need(report['startup_status'] == 'CALIBRATED_DIRTY_ROOT_SEED',
         'Uncalibrated startup')
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--full', action='store_true')
    p.add_argument('--parent-full', action='store_true')
    p.add_argument('--report', type=Path)
    a = p.parse_args()
    started = time.monotonic()
    count = manifest()
    with tempfile.TemporaryDirectory(prefix='u213-replay-') as name:
        temp = Path(name)
        archive = ROOT/'inputs/U214_ConPA_Reduction_2026-10-28.zip'
        need(sha(archive) == 'b3a520e2181b739fec7257a7935b979acb00400f8d8147b5a2c212fd53a38d2c',
             'Wrong baseline archive')
        extract(archive,temp/'baseline')
        parent = temp/'baseline/U214_ConPA_Reduction_2026-10-28'
        for name in ('validate_native.py','inputs/legacy_mapping.json',
                     'runtime/symbolic_runtime.py','runtime/independent_runtime.py'):
            need((ROOT/'code'/name).read_bytes() == (parent/'code'/name).read_bytes(),
                 'Inherited runtime implementation changed: '+name)
        build = temp/'build'
        construction = reconstruct(parent, ROOT/'inputs', build)
        for f in ('sites.json','u213.native.tm','u213.tm','state_map.json'):
            need((build/f).read_bytes() == (ROOT/'machine'/f).read_bytes(),
                 'Reconstruction differs: '+f)
        need((build/'reparenthesized214.native.tm').read_bytes() ==
             (ROOT/'inputs/reallocated214.native.tm').read_bytes(),
             'Intermediate reconstruction differs')
        jobs = [
            ('check_fold213.py',
             [ROOT/'inputs/reallocated214.native.tm',ROOT/'machine/u213.native.tm'],
             'fold213_certificate.json','Exhaustive fold, invariant and controls'),
            ('independent_fold_review.py',
             [ROOT/'inputs/reallocated214.native.tm',ROOT/'machine/u213.native.tm'],
             'independent_fold_review.json','Independent opaque-exterior fold and controls'),
            ('review_source_cfg.py',
             [parent/'machine/sites.json',ROOT/'machine/sites.json'],
             'source_cfg_review.json','Independent complete ordinal CFG comparison'),
            ('check_address_successors.py',[ROOT/'machine/sites.json'],
             'address_successors.json','All binary successors and no-stray-suffix conditions'),
            ('check_known_zero_dispatch.py',
             [ROOT/'research/rejected_allocation/rejected213.native.tm',
              ROOT/'machine/u213.native.tm'],
             'known_zero_dispatch.json','Known-zero selector binding and semantic controls'),
        ]
        for script,args,receipt,label in jobs:
            command(ROOT/'code'/script,[*args,'--output',temp/receipt],temp,label)
            need(load(temp/receipt) == load(ROOT/'evidence'/receipt),
                 'Certificate differs: '+receipt)
        # The independent reviewer's original, frozen layout is reconstructed
        # in a private temporary directory; no user-visible file is modified.
        review = temp/'candidate_review'
        review.mkdir()
        for name in ('sites.json','u213.native.tm','reparenthesized214.native.tm'):
            shutil.copyfile(build/name,review/name)
        for name in ('source_recipe.json','table_recipe.json'):
            shutil.copyfile(ROOT/'inputs'/name,review/name)
        shutil.copyfile(ROOT/'code/reconstruct_u213.py',review/'reconstruct_u213.py')
        (review/'runtime').mkdir()
        shutil.copyfile(ROOT/'evidence/u213/startup.json',review/'runtime/startup.json')
        command(ROOT/'code/review_source_bridge.py',
                ['--baseline',parent,'--candidate',review,
                 '--report',temp/'source_bridge_review.json'],temp,
                'Independent macro closure, whole-tape seed and exact byte bridge')
        need(load(temp/'source_bridge_review.json') ==
             load(ROOT/'evidence/source_bridge_review.json'), 'Source bridge differs')
        saved = runtime_audit(ROOT/'evidence/u213')
        command(ROOT/'code/audit_case_transport.py',
                ['--root',ROOT,'--output',temp/'independent_transport_review.json'],
                temp,'Independent proof dependency, partition and list-schema audit')
        need(load(temp/'independent_transport_review.json') ==
             load(ROOT/'evidence/independent_transport_review.json'),
             'Independent proof-transport audit differs')
        command(ROOT/'code/review_native_bootstrap.py',
                ['--table',ROOT/'machine/u213.native.tm',
                 '--sites',ROOT/'machine/sites.json',
                 '--startup',ROOT/'evidence/u213/startup.json',
                 '--out',temp/'bootstrap.json'],temp,'Independent literal blank initialization')
        boot = load(temp/'bootstrap.json')
        need(boot['working_states'] == boot['graph_reachable_working_states'] == 213 and
             boot['startup_steps'] == 95714 and boot['startup_registers'] == [4,0,0,0,0,0,0,0,0]
             and boot['startup_gap'] == 1 and boot['spare_count'] == 40,
             'Wrong startup seed or machine census')
        if a.full:
            fresh = temp/'runtime'
            command(ROOT/'code/validate_native.py',
                    [ROOT/'machine/u213.native.tm',ROOT/'machine/sites.json',fresh],
                    temp,'Rederive all 5109 arbitrary-register cases')
            actual = runtime_audit(fresh)
            need(actual['blocks'] == saved['blocks'], 'List induction certificates differ')
            for f in ('runtime_cases.json','startup.json'):
                need(load(fresh/f) == load(ROOT/'evidence/u213'/f),
                     'Fresh runtime certificate differs: '+f)
        if a.parent_full:
            command(parent/'reproduce.py',['--full','--report',temp/'parent_full.json'],
                    parent,'Retained U214 full reproduction')
            need(load(temp/'parent_full.json')['status'] == 'U214_FULL_REPRODUCTION_PASS',
                 'Parent replay failed')
        report = {
            'status':'U213_FULL_REPRODUCTION_PASS' if a.full else 'U213_RECONSTRUCTION_AND_PROOF_AUDIT_PASS',
            'manifest_files':count,'construction':construction,
            'source_opcode_and_cfg_identity':True,'independent_source_bridge':True,
            'both_local_fold_certificates':True,'admissible_local_frames':6832,
            'known_zero_selector_certificate':True,
            'independent_case_transport_audit':True,
            'unchanged_case_derivations_transported':4194,
            'delivery_fresh_case_derivations':915,
            'saved_universal_cases_audited':5109,'universal_cases_rederived':5109 if a.full else 0,
            'blank_startup_steps':95714,'initial_root_matches_primary_U214':True,
            'parent_full_rederived':a.parent_full,
            'seconds':round(time.monotonic()-started,3),
            'scope':'Exact source/table reconstruction, finite all-tape local proof, source CFG correspondence, '
                    'and full-tape symbolic mathematical runtime evidence. Inherited U214/U/W/PA logical '
                    'calibration remains an explicit dependency; no new proof-assistant endpoint certificate.'
        }
    if a.report:
        a.report.parent.mkdir(parents=True,exist_ok=True)
        a.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
