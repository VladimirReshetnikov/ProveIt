LOGARITHMIC SELECTION, LOCAL FREIMAN MODELS, AND HIGHER UNIFORMITY
Refinements of Gowers's Szemeredi framework
Prepared for Vladimir Reshetnikov, 6 October 2026

REPOSITORY BASELINE

VladimirReshetnikov/ProveIt
e3125e6982abe2d44bd7cb9369063d4e69d41a2d

MAIN CONTENTS

gowers_logarithmic_selection.tex     Complete standalone article source
gowers_logarithmic_selection.pdf     Compiled, visually checked article
figures/                            Prebuilt vector figures used by the TeX
code/verify_selection.py             Finite selection/transport checks
code/verify_u4.py                    Exact norm coefficients and certificates
code/make_figures.py                 Optional figure regeneration
data/selection_checks.json           Recorded successful selection checks
data/u4_exact_results.json           Recorded successful exact norm checks
data/source_provenance.json          Source paths, pins, and attribution
data/verification_scope.txt          What the computations do and do not test
data/build_summary.txt               Final build and PDF checks
Makefile                            Build and verification commands

RESULTS

1. A strengthened Section-10-style local-model theorem for arbitrary finite
   abelian source groups and arbitrary abelian targets. An order-eight
   relation defect at most 2^-21 yields a retained fraction

       alpha*(log 2)^2 / (20*log(32/alpha)*log(32/alpha^2)),

   an original-domain spectrum of size O(alpha^-3), and a Bohr radius
   Omega(alpha^5), with all constants explicit. The local difference map
   preserves every order-seven relation. The main proof combines a new
   logarithmic-window selection with prior transport and Bohr ideas,
   which are explicitly credited.

2. A strict universal real norm comparison, for odd-order finite abelian
   groups and all d >= 4:

       ||f||_(U^d)^4 >= sqrt(323/160) * ||f||_(U^2)^4.

   Exact two-harmonic witnesses give

       0.558729390985... <= c_4^odd <= 0.703815343078....

   A single real character pair of sufficiently large order is not locally
   extremal for any d >= 4. The sharp constants remain open.

3. Fifteen proposed research questions, detailed integration interfaces,
   exact computations, and a source comparison.

BUILD

The included figures allow the article to build without Python or network.
From this directory:

    make

Equivalently:

    latexmk -pdf -interaction=nonstopmode -halt-on-error gowers_logarithmic_selection.tex

The source uses standard TeX Live packages, including Latin Modern,
amsmath, amsthm, mathtools, geometry, microtype, booktabs, tabularx,
longtable, enumitem, xcolor, graphicx, fancyhdr, tcolorbox, hyperref,
bookmark, and cleveref. A bibliography is embedded in the TeX file.
If latexmk is unavailable, run pdflatex three times.

REPRODUCE COMPUTATIONS

    make verify

Both verification programs use only Python's standard library. The U4
program uses exact integer and rational arithmetic throughout. Most
selection checks are exact; a separately labelled section checks actual
natural logarithms using floating point and explicit tolerances.

Optionally regenerate the explanatory figures:

    make figures

This requires matplotlib and NumPy. Plotted floating-point values are
illustrative and are not used as proof certificates.

SUGGESTED INTEGRATION

A suitable destination is:

    Combinatorics/Ramsey/Research/GowersSzemeredi/
        logarithmic-selection-and-higher-uniformity/

Preserve the TeX, both figure PDFs, scripts, data, and this README together.
The actual repository research-folder convention should take precedence.
No repository files were modified or committed by this delivery.

STATUS AND ATTRIBUTION

Complete mathematical arguments and reproducible finite certificates are
provided. The main results received independent internal mathematical
checks during preparation. No new Lean proof, external peer review,
literature priority, sharp c_4 constant, or improved final Szemeredi bound
is claimed.

The article explicitly credits sources 07 and 12 for earlier transport,
dense Freiman extension, Bohr regularization, and Fourier smoothing, and
source 04 for the sharp U3 comparison and quartic cube-count framework.
The full repository comparison and historical archive references are in
the article and data/source_provenance.json.

The remaining Section 13, 16, and 18 obligations in the pinned repository
are not discharged by these local refinements.
