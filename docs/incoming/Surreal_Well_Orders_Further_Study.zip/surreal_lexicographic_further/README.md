# Lexicographic Orders of Surreal Well-Orderings — Further Structure

**Cut reconstruction, asymmetric products, prefix non-rigidity, and size-safe foundations**

Research manuscript prepared for Vladimir Reshetnikov, 3 October 2026.
The compiled article has 33 PDF pages (including the title and contents).

## Read

`article.pdf` is the complete article. `article.tex` is a standalone LaTeX
source with an internal bibliography. No external images or font files are
needed. `RESEARCH_STATUS.md` identifies the mathematical and verification
boundaries.

The main extensions are:

* Theorem 8.3: an exact crossing-cylinder criterion for a normalized cut of
  the coded dense core to come from an injective Ord-word, with a separate
  label-coverage criterion for exhaustion.
* Theorem 9.1: the first-failure classification into a next-label cut or a
  limit-prefix boundary, together with the all-level branch case.
* Theorems 10.1, 10.3, and 10.4: absorption of a surreal left factor versus
  the obstruction to splitting every global enumeration into two points.
  The nonembedding conclusions have explicit full-universe and uniform
  Kelley–Morse interpretations. Proposition 10.5 supplies the contrasting
  externally countable interpretation.
* Theorem 11.2: a uniform order automorphism that sends a prefix cylinder
  to a non-cylinder.
* Theorem 12.1 and Proposition 12.2: central-termination word orders over
  the nonzero surreal alphabet are isomorphic to the surreal line, with
  an explicit sign-code embedding and ordinal birthday formula.

The article surveys the other principal interpretations, includes a
foundational and Lean formalization plan, and proposes thirteen further
research questions. It distinguishes existing repository results from
these extensions and makes no historical-priority claim.

## Build

A reasonably complete TeX Live installation with pdflatex is sufficient:

```sh
bash build.sh
```

The script makes three passes. The delivered PDF was built successfully
with pdfTeX 1.40.26. The final log had no LaTeX warnings, undefined
references, overfull boxes, or underfull boxes.

## Reproduce finite checks

Python 3.10 or later, standard library only:

```sh
python3 code/finite_checks.py --output data/finite_results.json
```

The delivered run checked 533,417 finite relation/lex comparisons and
67,081 central-word pair comparisons, among additional cylinder,
completion, and transitivity tests. These are finite consistency checks,
not proofs of any transfinite or class-theoretic assertion.

## Files

- `article.tex`, `article.pdf`: manuscript and compiled article.
- `build.sh`: reproducible LaTeX build.
- `code/finite_checks.py`: runnable finite checks.
- `data/finite_results.json`: recorded test output.
- `data/pdf_inspection.json`: PDF and build inspection record.
- `RESEARCH_STATUS.md`: scope, provenance, and limitations.
- `SHA256SUMS.txt`: hashes of all delivered files other than the manifest itself.

## Repository snapshot

`VladimirReshetnikov/ProveIt` at commit
`0ecd158fd163bc4aca0ee40ccf6479ca6cf5f2a8`.
Inspection was targeted. No remote repository changes and no new Lean
build or kernel verification were performed.
