# A 223-state machine calibrated to ZFC consistency

This archive gives a deterministic binary one-tape Turing machine with **223
working states**, including its blank-tape initialization. It has a two-way
infinite tape, start state 0, blank symbol 0, only L/R moves, and a separate halt
state 223. In the canonical table the working states are 0–222 and dispatcher 22.

The ordinary mathematical result is formalizable in ZFC:

    M223 does not halt on the blank tape if and only if Con(ZFC).

No consistency assumption is used to establish this equivalence. The archive
does not claim a new compiled Rocq/Lean endpoint, an internal PA proof-code
endpoint, unconditional nonhalting, or minimality.

## Exact machine

The definitive table is `portable/results/candidate223.tm`.

SHA-256:

    7edafbb2395d39e3b0895a5e0f4da61e12a371b0af71ef4cfb1a43c06e7b917f

The native-label table has SHA-256:

    614adb7d387a5ccdaebecd37d8896d62bb162a20fb8b93b73ec2bd80bd75d785

Read `report/report.pdf` for the proof and construction. Editable LaTeX is
`report/report.tex`; the article's build script is supplied.

## The saving

1. Use the conditional-K source already calibrated by the K224 research archive.
2. Assign four new source roles compatibly to existing helper states 37, 26, 162, 11.
   These states still retain their prescribed engine rows. Choosing 37 rather
   than 11 for one child lets its parent reuse 26; greedy allocation loses this
   opportunity. All 24 priority orders were checked.
3. Merge native 18 into 180 using a previously written left-neighbor tag and an
   existing helper. Every old transition matches one or three new transitions,
   with exactly preserved tape/head at the corresponding endpoints.

The expanded source still has 4,799 instructions and 210 DAG nodes. The reduction
comes from sharing physical states, not from a shorter instruction listing.

## Verified evidence

- Exact source emitter, entire guarded CFG, conditional-theory interpretation,
  actual matrix/private-code coupling, and unchanged ten-entry AX enumeration
- All 6,238 unbounded guarded instruction cases, 1,515,697 symbolic applications,
  all 446 literal rows, and positive instruction-block durations
- Complete 409,835-step blank startup, including all 351 one-cells and blank exterior
- Independent all-tape final fold: 448 old rows, 446 one-step and two three-step blocks
- Independent decoder bindings, canonical isomorphism and deliberate corruption controls

Runtime quantification includes nine independent natural registers, arbitrary
natural extra gap and an arbitrary nonempty finite spare list. The checks are
not bounded simulations of register values.

## Reproduce

Use Python 3.10 or later, with assertions enabled. No third-party Python package
or network is needed. Choose an output directory outside `portable/`:

    python3 -B portable/reproduce.py --full --output-dir /tmp/k223-replay

Omit `--full` for a quick replay using stored runtime evidence. The full mode
also rederives all 6,238 unbounded instruction cases. Both modes check the pinned
inventory, reconstruct source and tables, check logical/source bindings, fold,
decoder, numbering, startup and corruption controls. Outputs are external; the
packet remains immutable. Do not run the aggregate or symbolic runtime with
`-O`, `-OO` or `PYTHONOPTIMIZE`.

The parent clean-extraction replay and delivery identity checks are recorded in
`validation/`. The pinned inherited K224 ZIP is retained under `portable/upstream/`.

## Additional research

`research/witness_bases/` contains two independently checked alternative logical
bases using uniform equality witnesses. They are separate results and are not
premises of this 223-state construction. Their shorter expanded sources did not
produce a smaller verified machine here. `research/searches/` preserves bounded
negative-search scopes and selected reproducible fixtures; none is a lower bound.

## Provenance

The starting K224 archive is from ProveIt commit
[49ee7cfdc8e0364c6db3614675d141d66f9350ed](https://github.com/VladimirReshetnikov/ProveIt/commit/49ee7cfdc8e0364c6db3614675d141d66f9350ed).
Its SHA-256 is
`cf5db8d08a34f5661ad1266226809ed1f0099fd38374c66d127e1e06519c6887`.
Its conditional interpretation and canonical-helper calibration are inherited;
the compatible helper allocation and final 223 construction are this contribution.
The underlying K230 calibration is Elliot Glazer's development at
[3142e4dd980f0be12f4abb636c4ae2528afc17eb](https://github.com/elliotglazer/k230-rocq/tree/3142e4dd980f0be12f4abb636c4ae2528afc17eb).

No repository push or external publication was performed by this research session.

The final syntax-alias clarification is in
`validation/positive_label_ir_clarification.md` and the updated independent review
`validation/final_theory_enumerator_review.md`. It derives irreflexivity at a
positive hygienic label without confusing an abstract bottom token with the
literal membership atom Rel(0,0), although both eventually encode to 1. It does
not alter the machine, source, or sealed portable replay inputs.
