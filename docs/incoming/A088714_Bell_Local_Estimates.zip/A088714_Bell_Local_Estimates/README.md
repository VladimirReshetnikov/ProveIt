# A088714: local estimates for the finer Bell comparison

Main result: a proved uniform logarithmic-window coefficient expansion and
an additive one-sided ratio lower bound tending to a correction of 3/2.
The full correction tending to 2 and the Bell normalization remain unproved.
The article states and proves a precise conditional endpoint criterion.

## Contents

- article.tex, article.pdf: detailed report, proofs and limitations.
- code/compute_gmp.cpp: inherited exact triangular generator from ProveIt.
- code/coefficients.py: independent Python implementation of that recurrence.
- code/diagnose.py, code/decimal_math.py: no-dependency exact checks and
  arbitrary-precision Decimal diagnostics.
- data/coefficients_snapshot.txt: exact integers used for the final tests.
- data/diagnostics.csv: all-index normalization, ratio and variance tests.
- data/endpoint_diagnostics.json: direct endpoint tests at selected indices.
- data/window_sweep.json: sensitivity to 8W, 12W, 16W and 24W windows.
- data/precision_check.json: comparison of 80- and 120-digit evaluations.
- data/prior_diagnostics.csv: earlier stored ProveIt diagnostics.

## Reproduce

Diagnostics use only Python 3.11 or later (Decimal logarithm and exponential):

    python3 code/diagnose.py 80

They read the supplied stable coefficient snapshot. To regenerate it with a
normal GMP development installation:

    g++ -O3 code/compute_gmp.cpp -lgmpxx -lgmp -o compute_gmp
    ./compute_gmp 1600 data/coefficients_snapshot.txt
    python3 code/diagnose.py 80

The Python generator is a slower dependency-free alternative:

    python3 code/coefficients.py --n 1600 --output data/coefficients_snapshot.txt

For the PDF, run twice from this directory:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex

The actual run used `code/compute_runtime.c`, a small header-free adapter for
the installed 64-bit Linux GMP runtime because development headers were absent.
It implements the same recurrence. The C++ and Python entry points above are
portable alternatives; the adapter is included to record the executed code.

## Verification scope

The coefficient prefix through 80 is independently generated in Python.
All available stored earlier ratios through 1200 are checked against the
fresh exact integers, allowing their published rounding. The formal functional
recurrence is checked through degree 35 using independent finite polynomial
multiplication. Coefficients of powers are computed with a second exact
recurrence with integer-divisibility checks. Two exact degree-two/degree-three
certificates are tested. Numerical values at 80 and 120 digits are compared.
These are finite checks, not a proof of convergence or an interval certificate.

## Provenance

Repository snapshot: 82afb955918e5af9ccd2a7740424b2a66976f339.
Source directory:
SetTheory/Cardinals/docs/reports/generating-functions-and-asymptotics/
oeis-sequence-asymptotics/a088714-bell-scale-growth/.
The original article, its October 1 Part II and its SOURCE_AUDIT were read.
The inherited coefficient generators and prior CSV retain their repository
license. This continuation does not modify the repository.
