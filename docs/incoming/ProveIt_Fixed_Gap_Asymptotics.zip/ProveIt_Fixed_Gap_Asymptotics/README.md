# Fixed-gap permutations: all orders and boundary universality

Research report prepared for Vladimir Reshetnikov, October 1, 2026.

## Main contents

`article.pdf` is the complete paper; `article.tex` is its self-contained source.
The paper proves a stable path-profile identity, a finite formula for every
fixed asymptotic coefficient, a uniform remainder theorem, and a quantitative
comparison of entire violation-count distributions under changes to long path
lengths. Applications include OEIS A189281 and A110128 through order twelve,
local Poisson corrections, and all-orders Lambert-W inversion.

The particular conjectured recurrences in the OEIS entries are **not proved**.
The method does not assume them. The leading limits and exact matching-tilings
inclusion-exclusion are credited to prior work. These are ordinary mathematical
proofs with computational checks, not a Lean-certified development. Global
publication priority has not been established.

## Run the verification

The tested environment was Python 3.13, SymPy 1.14.0, and mpmath 1.3.0.
From this directory:

```sh
python -m pip install -r requirements.txt
python code/verify.py --order 12
```

The default order is twelve. The test is offline after dependency installation
and usually completes on a timescale of tens of seconds in the tested environment;
runtime is machine-dependent. It regenerates files under `data/` at the selected
order. A smaller `--order` produces a shorter coefficient table.

The test suite checks 90 brute-force avoidance counts and 90 complete histograms
for n=0,...,8; exact A189281 counts through n=26 and at n=40; 132 stable-profile
identities plus a zero case; moment equality for unequal path balances;
50 one-path contraction identities; all ten posted correction terms in both
OEIS sequences; new coefficients through order twelve; general generating-function
and mean identities; and the inverse residual through N^(-3).

`data/verification.txt` records the run delivered with this package. Numerical
errors are decimal checks, not certified interval bounds. The values at n=80 and
n=120 are public OEIS inputs, not independently regenerated exact counts.

## Reuse the coefficient engine

Run Python from this directory:

```python
import sys
sys.path.insert(0, "code")
import sympy as sp
from fixed_gap import asymptotic_coefficients, avoidance, histogram, gap_lengths

# C_j in A(n)/n! = exp(-eta) * sum(C_j / n**j).
a_coeff = asymptotic_coefficients(12, 2, 2, eta=1, z=-1)
b_coeff = asymptotic_coefficients(12, 2, 2, eta=2, z=-1)

# Coefficients for the full pgf:
# E[w**X] ~ exp(eta*(w-1)) * sum(C_j(z=w-1) / n**j).
r, s, z = sp.symbols("r s z")
pgf_coeff = asymptotic_coefficients(3, r, s, eta=1, z=z)

# Independent exact enumeration; no guessed recurrence.
assert avoidance(12, 2, 2, eta=1) == 222822578
counts = histogram(gap_lengths(8, 2), gap_lengths(8, 2), eta=2)
assert sum(counts) == sp.factorial(8)
```

`code/fixed_gap.py` contains both computational routes. Exact enumeration uses
small tiling polynomials; it is not intended to replace the faster specialized
large-n algorithms linked by OEIS. The asymptotic engine is independent of n
and enumerates integer partitions of the target defect.

## Build the PDF

A current TeX Live or MiKTeX installation with the packages named in the preamble
is sufficient. From this directory run:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

A third pass may be needed after large edits that alter page references.
The bibliography is embedded in the TeX file; BibTeX is not required.
No external figures or font files are included or needed beyond the TeX packages.

## Files

- `article.tex`, `article.pdf`: the paper.
- `code/fixed_gap.py`: exact tilings and finite-defect coefficient engine.
- `code/verify.py`: reproducible checks and data generation.
- `data/coefficients.csv`: exact avoidance coefficients for both sequences.
- `data/component_weight_polynomials.txt`: coefficients at r=s=2 with symbolic eta.
- `data/general_pgf_first_three.txt`: first three full-pgf corrections for symbolic r,s.
- `data/numerics.csv`: signed normalized A189281 errors and inverse errors.
- `data/selected_oeis_values.csv`: selected exact input values with their indices.
- `data/verification.txt`: completed verification output.
- `sources.md`: source audit and provenance.
- `requirements.txt`: computational dependencies.

No OEIS edit, repository commit, or persistent Library upload was made.
