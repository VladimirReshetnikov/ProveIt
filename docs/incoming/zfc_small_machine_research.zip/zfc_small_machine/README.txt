EQUALITY ERASURE AND A 250-STATE EXPERIMENTAL ROUTE TO Con(ZFC)
Research report prepared for Vladimir Reshetnikov, 16 October 2026

START HERE

Read report.pdf (22 pages). report.tex and sections/ contain its complete
LaTeX source and embedded bibliography. No external images or bibliography
database are needed to rebuild it.

The concrete result is an experimental 250-working-state binary machine,
alongside a mathematical source-theory equality-erasure theorem, a checked
Lean semantic component, a total base-three codec proof, and an explicit
diagnostic showing a gap in the retained pure logical basis. The archive
does not claim a proved 250-state Con(ZFC) endpoint.

IMPORTANT FILES

  report.pdf / report.tex / sections/
    Complete report, proofs, source audit, measurements, and proposal.
  formal/AtomicEquality.lean
    Standalone Lean 4.32.0 file, importing only Init. Seven principal
    theorems were compiled and report no axiom dependencies.
  results/lean-check.txt
    The actual successful axiom-dependency output.
  code/logical_kernel_diagnostic.py
    Quantifiers-as-identity counterinterpretation for the retained pure
    logical rows; explicitly not a model of the full C/G theory.
  code/base3_codec.py
    Canonical finite decoding of every natural formula code, with finite
    roundtrip, constructor, unpairing, and freshness checks.
  machine/conjunction-candidate-250.tm
    The frozen normalized complete 500-row binary transition table.
  machine/conjunction-candidate-250.named.tm
    The 499-row named partial table before one missing halt edge is filled.
  machine/generate_candidate250.py
    Deterministically regenerates the frozen candidate from its fixed recipe.
  machine/search_conjunctions.py
    Repeats the 9,216 specified compiler choices. Two attain 250 states.
  machine/translation_comparator.py
    Generates the 348-state control retaining all translated equality rows.
  machine/reproduce.py / machine/source-manifest.json
    Reproduce using 12 exact public source files, checked by SHA-256 before
    execution. The first run fetches those files; later runs can be offline.
  machine/STATUS.json / machine/README_AUDIT.md
    Detailed machine scope, commands, attribution, and evidence map.
  PROVENANCE.json / results/upstream253-ci-jobs.json
    Repository and Lean pins; independently retrieved upstream CI metadata.
  SHA256SUMS
    Checksums of the release files. Does not include itself.

QUICK REPRODUCTION

Run from this directory with Python 3.10 or newer:

  python3 code/logical_kernel_diagnostic.py
  python3 code/base3_codec.py
  lean formal/AtomicEquality.lean

The Lean command requires Lean 4.32.0. The Python checks need only the
standard library. The codec script writes its JSON result beside itself.

For the compiler and machine experiments:

  python3 machine/reproduce.py
  python3 machine/translation_comparator.py

After source files have been fetched and checked, use:

  python3 machine/reproduce.py --offline --search-orders

The exact offline command above was run successfully. It reproduces the
eight earlier backend variants, the earlier 288-choice search, the fixed
250-state generation, and the table diagnostics. Add --search-conjunctions
to repeat the new 9,216-choice search; it took about 144 seconds in the
research environment. Reproduction writes only within machine/ and its
cache subdirectories. The source repository is not modified.

To rebuild the PDF:

  latexmk -pdf report.tex

Alternatively run pdflatex report.tex twice (or until references settle).
Standard TeX Live packages are used. The checked build has no undefined
references or overfull boxes. A rebuilt PDF can differ in metadata bytes.

To verify the delivered files before running commands that rewrite results:

  sha256sum -c SHA256SUMS

FROZEN MACHINE CONVENTION

Each non-comment row is:

  current_state read_symbol write_symbol direction next_state

Working states are 0 through 249. The tape is two-way infinite and initially
all zero. Start state is 0. State 250 is terminal and has no outgoing rows.
There are 500 working-state/symbol transitions. The two terminal edges are
13 1 1 R 250 and 164 1 1 R 250. Direction is L or R.

Normalized table SHA-256:
d7af3920268db1c95bf71dc06b77e53c8266086a13043b2fc91f9319c520aff1

Named table SHA-256:
799ec421e41533229cb24aa172f61fc637d3435466d8d0f2eff0fcadf2cdcfc6

CLAIM BOUNDARIES

The equality-erasure theorem concerns ordinary complete first-order logic.
It reuses the imported equality-bearing source's ZF/ZFC calibration. The
Lean file verifies semantic equality erasure and capture-safe binders, not
the complete proof-code translation, source calibration, or Turing machine.

The 250-state compiler change commutes/reassociates relative conjunctions
without changing binders. The finite audits and a million-step prefix are
not a nonhalting proof. The prefix does not exercise the edited AX emitter.

The most immediate open question is adequacy of the reduced numerical
calculus, particularly variable substitution. A counterinterpretation of
only the pure logical fragment does not refute the complete C/G machine.
Further obligations include the designated falsity atom, complete matrix
coverage, fair proof enumeration, compiler simulation, and the literal table.

ATTRIBUTION

ProveIt: Vladimir Reshetnikov and repository contributors.
Original 254-state design and C/G calculus: Mira-Cult.
Imported Coq verification: Jeff (jeff87654/busy-beaver).
253-state verified reduction: mira-emmy, upstream PR 20.
Public TMBuilder backend: Andrew James Wade, with its MIT-0 license.
Exact upstream source locations and hashes remain in the manifest. The
upstream developments and runtime binaries are not duplicated or relicensed.

The two-sided indiscernibility construction is standard equality-free model
theory; this report applies it to the exact imported C/G source. References,
credit for prior subset-closure work, and all qualification details are in
the report. New files supply the stated proofs, semantic formalization,
conjunction search, frozen candidate, diagnostic, and reproducible evidence.
