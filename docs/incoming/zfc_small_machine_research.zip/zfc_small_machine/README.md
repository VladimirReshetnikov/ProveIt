# Toward a Smaller ZFC Consistency Machine

Research report and source package prepared for ProveIt, 16 October 2026.

**Read zfc_small_machine_report.pdf for the complete report.**
The main source is zfc_small_machine_report.tex; all section files and
bibliography source are included.

## Findings

- The best developed explicit construction in the inspected sources is
  already **253 working states**: mira-emmy's public PR 20, built on
  Mira-Cult/Jeff's 254-state machine. Its external Coq finite-refutation
  equivalence has successful exact-revision CI. This is existing work.
- The new contribution includes **three checked Lean modules** that
  discharge both propositional hypotheses of the pinned Tarski
  first-order completeness theorem. The implication derivations are an
  explicitly attributed port of upstream CD254.v.
- A finite counterinterpretation proves that the implication basis
  alone does not derive ex falso for unrestricted primitive bottom.
  A separate proof derives it in the full calculus using rho6.
- An exact finite certificate rules out a smaller **one-step transition
  quotient of this table**. It is not a general state lower bound.
- A concrete **252-state shortened-detector table is rejected** by an
  exact instruction execution. It dispatches at an interior tape marker.
- Two **252-state spare-tail runtimes remain uncalibrated from blank**.
  Their valid local behavior does not establish a new consistency machine.
- The complete-logic grammar searches retained the prior 268-state
  compiler control; the report states the limits of their scoring rules.
- The proposal identifies finite-witness transports needed to prove
  the intended arithmetic equivalence **inside ZFC**. The archive does
  not contain a serialized proof of that complete internal endpoint.

**No new calibrated machine smaller than 253 states is claimed.**

## Exact source pins

| Input | Revision |
|---|---|
| ProveIt comparison snapshot | 4747142d5d15213eb711bdadfa3cc7e769fcb7a7 |
| Requested reconciliation | 6d8bc7f1ba02c83e54757366f019f61b966ed0b7 |
| Requested catalogue update | 63c83cf79986f8a92bb75460848a1d4f863b7b15 |
| Requested full Lean bootstrap | 0301aa64e0676bed17402a63de46996631252a51 |
| Jeff 254-state main baseline | 297ab8df7e5de329605c3875b4934643b371a5e3 |
| Public 253-state PR 20 head | 0d544f2a2e3c18f12278441a74b7879f31cbe856 |

The public 253-state table has SHA-256:

    84a21f714017c1d491008d86e9bd19c43cc6c5c9ae99a538b4f2314387827d95

The report freezes the ProveIt snapshot because main changed during
the research. It audits 19 reconciled reports plus four newly introduced
archives; it does not attribute later reconciliation to the earlier pin.

## Replay

Run the package's integrity and finite-machine checks:

    python3 verify_package.py

This is a Python finite audit, not a Lean or Coq kernel invocation.
It validates the package manifest, the exact source-closure manifest,
the recorded Lean source identities, and the independent machine audit.

For the new Lean proof, with Lean 4.32.0 installed:

    cd propositional_bridge
    python3 check_propositional_bridge.py --repo . --lean /path/to/lean

The existing complete logs are in propositional_bridge/verification/.
The new roots have no admissions, custom axioms or native evaluation.
The propositional roots and bottom counterinterpretation have no axioms;
the completeness roots inherit propext, Classical.choice and Quot.sound
from the existing completeness development.

For the external public Coq chain, check out the exact PR revision in
the upstream repository and run its own driver with Coq 8.20.1 and
matching coqchk:

    python3 -I -B ZF/m253/check.py --coqc /path/to/coqc

The archive's upstream253_sources/ is the exact 160-module source
closure for inspection. It is not a complete upstream repository checkout
with every auxiliary driver. The public CI metadata and log excerpt
are included; this research did not repeat the full Coq build locally.

internalization/E2E253FullReg.v is a short **uncompiled proposal** that
composes already published theorems to include both Foundation and Choice
explicitly. Even after compilation it is an external Coq result, not by
itself a proof that ZFC proves the arithmetic endpoint.

See optimization/README.md for the offline optimization replays,
including finite cutoffs and distinct proof boundaries.

Build the PDF with:

    latexmk -pdf -interaction=nonstopmode -halt-on-error zfc_small_machine_report.tex

After any intentional source changes and their appropriate checks, regenerate
the manifest and create a fresh archive with:

    python3 make_archive.py --output /path/outside/this/directory/new-research.zip

This refuses an existing output and runs the package integrity/finite audit.
It does not replace the Lean, Coq, or source-compiler proof checks.

## Integration

propositional_bridge/integration.patch adds only these files under
Computability/BusyBeaver/Lean/BusyBeaver/ZFC/:

- Lukasiewicz.lean
- TarskiCompleteRows.lean
- PrimitiveBottomAudit.lean

Import BusyBeaver.ZFC.TarskiCompleteRows for the unconditional logical
interface. The seven frozen dependencies are for reproducibility; compare
them with a newer repository instead of overwriting newer files.

The report can be placed in a dated BusyBeaver research directory and
linked from the closure-kernel catalogue.

## Attribution

The machines, upstream Coq proof chain, source compiler and implication
derivations retain their original authorship. Newness is claimed only for
the integration and experiments described as new, relative to the pinned
corpus. No historical priority is asserted beyond that audit.

Original applicable notices accompany the copied material. The ProveIt
sources are under the repository's MIT No Attribution license; the Wade
backend, busycoq and Undecidability sources retain their individual
notices. No blanket relicensing of third-party material is made.
