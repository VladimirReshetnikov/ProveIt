# Sharp Local Refinements in Gowers' Szemerédi Framework

**Simultaneous recurrence, extremal density selection, and centered cube counts**  
Research article prepared for Vladimir Reshetnikov, 6 October 2026.

Start with **`gowers_local_refinements.pdf`**. The complete editable source is
**`gowers_local_refinements.tex`**.

## Scope and mathematical status

The article proves local refinements of specific steps in Gowers' Szemerédi
framework and compares them with a pinned snapshot of the supplied ProveIt
paper transcription and Lean development. Its principal results concern:

- Complete simultaneous linear-phase partitions, exact finite rounding, and a
  matching exponent obstruction for the flexible-length problem.
- Sharp weighted density-selection bounds, a real-valued phase envelope, and
  an exact joint phase/density/exceptional-mass frontier.
- A density-sensitive Fourier increment with an explicit progression length.
- Mean-zero cancellation in cube counts, the exact quartic coefficient, and a
  complete spectral decomposition for the three-dimensional cube.
- Interval discrepancy with a sharp quarter-power dependence on interval
  length, and a density-weighted telescoping bound for progression counts.

The general statements are supported by written mathematical proofs in the
article. The executable checks supplement those proofs with finite arithmetic
and numerical audits. Sharpness is asserted only for the precise classes
specified in the relevant theorems; in particular, optimality of the flexible
partition exponent does not establish optimality of the prescribed-length
exponent.

**This package does not claim a new global Szemerédi bound, resolution of a
major open problem, or established historical priority for the local
formulas.** It also contains no newly kernel-checked Lean development. The
existing Lean sources were inspected to identify hypotheses, normalization,
and insertion points; no fresh Lean compilation is claimed. The article
includes a formalization roadmap and proposed further research questions.

## Package contents

| File or directory | Purpose |
| --- | --- |
| `gowers_local_refinements.pdf` | Compiled article. |
| `gowers_local_refinements.tex` | Complete LaTeX source, including its bibliography. |
| `figures/partition_frontier.pdf` | Standalone vector figure comparing partition exponents. |
| `figures/density_frontier.pdf` | Standalone vector figure comparing density-selection bounds. |
| `figures/*.png` | Raster previews of the same figures. |
| `make_figures.py` | Regenerates both figures as PDF and PNG. |
| `verification/verify_partitions.py` | Exact finite partition and obstruction checks. |
| `verification/verify_density.py` | Phase, selection, joint-frontier, and endpoint checks. |
| `verification/verify_cubes.py` | Cube matroid, rational identity, and Fourier checks. |
| `verification/verify_fourier_counting.py` | Interval, progression-counting, and spectral-deficit checks. |
| `verification/*.json` | Recorded outputs from the four verification scripts. |
| `provenance.json` | Pinned source provenance and deliverable hashes. |
| `README.md` | Build, verification, and provenance instructions. |

The original journal PDF and full third-party paper sources are not
redistributed. They are identified in the article bibliography and below.

## Rebuild the article

Run the following commands **from the extracted package root**, the directory
containing `gowers_local_refinements.tex`.

### TeX prerequisites

Use a TeX installation providing **pdfLaTeX**, such as TeX Live or MiKTeX, with
the packages named in the source preamble. These include Latin Modern fonts,
Microtype, Geometry, the AMS packages and Mathtools, Booktabs, Longtable, Array,
Enumitem, Graphicx, Xcolor, Tcolorbox, Fancyhdr, URL, Xurl, Placeins, Hyperref,
and Cleveref.
Their ordinary dependencies must also be installed.

The bibliography is embedded in the `.tex` file. **BibTeX and Biber are not
needed.** The source uses the two supplied PDF figures, so Python is not needed
for a normal rebuild.

### pdfLaTeX commands

Three passes provide a straightforward build sequence that settles the table
of contents and cross-references:

```sh
pdflatex -interaction=nonstopmode -halt-on-error gowers_local_refinements.tex
pdflatex -interaction=nonstopmode -halt-on-error gowers_local_refinements.tex
pdflatex -interaction=nonstopmode -halt-on-error gowers_local_refinements.tex
```

The output is `gowers_local_refinements.pdf` in the package root. Two passes
usually suffice, as in the article appendix; the third is included here to
settle any remaining reference changes. If TeX reports a missing package,
install that package through your TeX distribution and repeat the build.

No shell-escape option is required. Auxiliary files such as `.aux`, `.log`,
`.out`, and `.toc` are generated during compilation and are not source inputs.

## Python setup

Use **Python 3.10 or later**. The commands below assume that `python` selects
that interpreter; substitute `python3` or, on Windows, `py -3` if appropriate.

| Operation | Python dependencies |
| --- | --- |
| Partition verification | Standard library only. |
| Density verification | Standard library only. |
| Cube verification | NumPy. |
| Fourier/counting verification | NumPy. |
| Figure generation | NumPy and Matplotlib. |

To install the external dependencies for all Python tasks:

```sh
python -m pip install numpy matplotlib
```

Once dependencies are installed, all verification and figure-generation
scripts run locally and use no network. Run verification normally, without
Python's `-O` option: the scripts intentionally use assertions to report
failed checks.

## Run the four verification suites

From the package root:

```sh
python verification/verify_partitions.py
python verification/verify_density.py
python verification/verify_cubes.py
python verification/verify_fourier_counting.py
```

Each command writes or replaces its JSON summary **beside its script** and
prints a result summary. A successful run exits with status zero; a failed
assertion or other error exits with a nonzero status.

| Command | Default result file | What is checked |
| --- | --- | --- |
| `python verification/verify_partitions.py` | `verification/partition_verification.json` | Coverage, disjointness, lengths, modular diameters, conductor thresholds, and a finite obstruction example. |
| `python verification/verify_density.py` | `verification/density_summary.json` | Explicit extremizers, seeded weighted mixtures, phase envelopes, joint frontiers, exceptional mass, and Fourier-increment rounding. |
| `python verification/verify_cubes.py` | `verification/cube_verification_summary.json` | All 256 cube subsets over the listed fields, coloop cancellation, orbit correlations, the centered expansion, face-square identities, spectral formulas, and sign examples. |
| `python verification/verify_fourier_counting.py` | `verification/fourier_counting_summary.json` | Finite interval constants, Fourier-dual equality, the progression telescope, norm estimates, coefficient-invertibility negative control, and spectral-deficit equality. |

The default runs use fixed seeds where sampling is involved. The partition
script additionally accepts `--seed`, `--random-cases`, and `--output`; the
cube script accepts `--output`. Their `--help` options describe these switches.
Changing partition parameters changes its reported test totals. The density
and Fourier/counting scripts use their fixed defaults and do not define
command-line switches.

### Interpretation of the checks

The partition checks use exact integers and rational arithmetic. The cube
suite uses exact rational arithmetic for its combinatorial and physical-space
identities, and floating point for Fourier comparisons. The density and
Fourier/counting suites include floating-point tolerances. Their output files
record the relevant instances, counts, examples, and numerical errors.

A finite test suite cannot establish a theorem for all parameters or replace
Lean kernel checking. Its purpose here is to catch implementation and formula
errors in independently reproducible examples. Small differences in reported
floating-point errors across Python or NumPy versions are possible; the
mathematical statements and exact combinatorial checks do not depend on those
last digits.

## Regenerate the figures

The figures are already included. To regenerate them after installing NumPy
and Matplotlib, run:

```sh
python make_figures.py
```

The script writes the following four files relative to its own location:

- `figures/partition_frontier.pdf`
- `figures/partition_frontier.png`
- `figures/density_frontier.pdf`
- `figures/density_frontier.png`

It uses Matplotlib's noninteractive `Agg` backend and does not require a
graphical desktop or external LaTeX renderer. Rebuild the article with the
pdfLaTeX commands above after regenerating the figures. Figure generation
calculates the displayed analytic comparison curves directly; it does not
read or require the verification JSON files.

## Pinned repository snapshot and provenance

The source comparison is pinned to:

- Repository: [VladimirReshetnikov/ProveIt](https://github.com/VladimirReshetnikov/ProveIt).
- Commit: [`9ea383e9b28d885a936d5d681cd5584fffd2cb29`](https://github.com/VladimirReshetnikov/ProveIt/commit/9ea383e9b28d885a936d5d681cd5584fffd2cb29).
- Commit timestamp: **2026-10-06 20:35:24 UTC**.
- Inspection date: **6 October 2026**, through the user-selected GitHub connection.

Relevant pinned paths:

| Source | Repository path |
| --- | --- |
| Adapted paper | `Combinatorics/Ramsey/Papers/sz-thm-gowers-proof/sz-thm-gowers-proof.tex` |
| Lean development | `Combinatorics/Ramsey/Lean/GowersSzemeredi` |
| Source-inventory ledger | `Combinatorics/Ramsey/gowers-proof-status.json` |

The inspected adapted-paper Git blob SHA is
`41085a0efde8c1932e86e80c791984f52841c22e`. The inspected source-inventory
ledger Git blob SHA is `feb6d45ba9e4a01092b8cf68083e1fbb99a1bf45`.
These are Git object identifiers for the source files, distinct from the
individual deliverable hashes recorded in `provenance.json`.

The ledger distinguishes companion declarations and remaining entries, and
explicitly treats itself as a source inventory. Its existence does not certify
a new compilation or independently establish fidelity to the journal paper.
Repository comparisons in this report concern the pinned snapshot, including
its editorial repairs, rather than whatever a later `main` branch contains.

The underlying journal article is:

> W. T. Gowers, *A new proof of Szemerédi's theorem*, Geometric and Functional
> Analysis **11** (2001), 465–588.
> [DOI: 10.1007/s00039-001-0332-9](https://doi.org/10.1007/s00039-001-0332-9).

The report's bibliography identifies the further mathematical sources used
for context and comparison. `provenance.json` records the packaged provenance
and hashes; regenerating figures, verification outputs, or the compiled PDF
can change their file hashes. Rebuilding with a different TeX or plotting
version is intended to reproduce the content, not necessarily an identical
PDF byte stream.
