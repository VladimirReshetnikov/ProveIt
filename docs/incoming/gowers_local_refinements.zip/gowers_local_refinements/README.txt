SHARPER LOCAL ESTIMATES IN GOWERS'S PROOF OF SZEMEREDI'S THEOREM
Research report prepared for Vladimir Reshetnikov, 6 October 2026

CONTENTS
  gowers_local_refinements.pdf   Complete article
  gowers_local_refinements.tex   Complete LaTeX source (all sections and references)
  figures/local_bound_comparisons.pdf   Included vector figure
  verify_cubes.py                Exact finite cube checks; standard library only
  verify_estimates.py            Selection, DRC, phase and progression checks
  verification_cubes.txt         Recorded output from cube checks
  verification_estimates.txt     Recorded output from the other finite checks
  make_figure.py                 Figure generator (NumPy and Matplotlib)
  SOURCE_NOTES.txt               Pinned input sources and scope

BUILD
From this directory:
  pdflatex -interaction=nonstopmode -halt-on-error gowers_local_refinements.tex
  pdflatex -interaction=nonstopmode -halt-on-error gowers_local_refinements.tex
Run a third time if LaTeX requests cross-reference updates. The vector figure
is already included; Python is not required to compile the article.

CHECKS
  python3 verify_cubes.py
  python3 verify_estimates.py
The cube checks use exact rational arithmetic. Phase oscillation and the
final comparisons involving norm roots use numerical tolerances, as documented
in the article. Finite checks support, but do not replace, the written proofs.
The verification scripts require Python 3 and no external packages.

SCOPE
The report proves local refinements and sharpness results, with a proposed
research and formalization agenda. It does not claim an improvement to the
global Szemeredi record or a new frontier Balog-Szemeredi-Gowers theorem.
The Lean sources were inspected at the pinned revision, not compiled.
No new Lean proof is supplied or claimed as machine checked.
