# Beyond Polynomial Trajectories
## Canonical Exponential-Diophantine Certificates for Computation

Research manuscript prepared with ChatGPT for the ProveIt program, October 2, 2026.

**Start with `article.pdf` or `article.tex`.** The manuscript contains full proofs,
a comparison with the inspected repository and primary literature, applications,
limitations, and ten further research questions.

Repository snapshot inspected:
`e58b724c25bd34533b7a5834cfcbe873dfa01288`.

## Main result

For a fixed shape

    f(n) = sum_b sum_{k=0}^{d_b} c[b,k] * n^k * b^n,
    b positive integers, D = sum_b (d_b+1),

the coefficients and finite horizon are inputs. A complete maximal sign profile
on `0,...,T`, or on all nonnegative integers, has a canonical power-assisted
quadratic arithmetic certificate. The annihilating chain uses `D^2+1` available
run slots and `O(D^3)` witnesses, quadratic residuals, and fixed-base power atoms.
The arity is independent of elapsed time. The entire natural witness tuple is
unique, including padding, comparison slacks, and evaluation wires.

The proofs transfer these certificates to supported affine updates, polynomial
guards, triangular polynomial register updates, and fixed schedules of repeated
instruction words inside a Turing-complete register language. They also give
first-failure and least-minimizer certificates.

The complete sign-chart graph of `2^n-y` already has the following boundary:
its ordinary single-fold representability is equivalent to the general
single-fold conjecture. The analogous finite-fold equivalence is proved too.
This is a reduction, not a resolution of either conjecture.

## Essential distinctions

* Every coordinate in an exported system ranges over **nonnegative integers**.
  Input coefficients use disjoint positive/negative parts. Invalid noncanonical
  signed input pairs are excluded by the residual equations.
* The exported system means **all arithmetic residuals vanish AND all listed
  power atoms hold**. The expanded degree-four polynomial encodes only the
  arithmetic residuals. It is not a complete ordinary Diophantine equation.
* Bounds count coordinates, equations, atoms, and scalar arithmetic operations,
  not bit complexity. `2**T` has `T+1` bits.
* The Python implementation is a scalar exponential-polynomial compiler.
  General affine/Jordan and triangular-polynomial front ends are proved in the
  paper and illustrated by tests, but are not implemented as general parsers.
* The paper is unrefereed. New results have not been kernel-checked in Lean or
  Rocq. Novelty is proposed relative to the targeted audit, not guaranteed.

## Reproduce

Python 3.10 or later; standard library only. Run from this directory:

```sh
python3 code/test_profiles.py
python3 code/test_applications.py
python3 code/compiler.py
python3 code/check_export.py data/finite_certificate.json data/infinite_certificate.json
```

Or use `make test` to refresh the logs. `make pdf` builds the article using
pdfLaTeX; a typical TeX Live installation with the packages listed in the source
is needed. The included PDF can be read without installing TeX.

## Files

`profiles.py` implements the exact exponential-polynomial arithmetic,
annihilating chain, canonical finite/infinite profile construction, and local
endpoint verifier. `compiler.py` emits a parametric quadratic residual system
and power-graph list, together with a satisfying sample assignment and expanded
arithmetic quartic. `check_export.py` is an independent JSON arithmetic checker.
The two test programs check profile behavior, parameter-independent compiler
structure, mutations, and the explicit computational examples.

The JSON files use the declared shape `{1:0,2:0,4:0}`. Their sample is
`4**n - 20*2**n + 64`, with horizon 6 for finite mode. They are **not specialized
to those coefficient values**. A coefficient or horizon change changes the
sample assignment, not the finite/infinite system's symbolic structure.

| Export | Inputs | Witnesses | Quadratic residuals | Power atoms | Quartic monomials |
|---|---:|---:|---:|---:|---:|
| Finite | 7 | 1231 | 1703 | 52 | 7502 |
| Infinite | 6 | 1297 | 1767 | 52 | 8256 |

Counts are deliberately unoptimized, not universal-polynomial operation records.
A polynomial term is stored as `[integer_coefficient, [variable_indices]]`.
Repeated indices represent repeated factors. A power atom records its fixed
base and the indices of the exponent and output.

## Verification recorded

The archive records 1,134 randomized shape checks; two 1,419-candidate exhaustive
small-top-profile tests; twelve compiler uniformity cases; sixteen extra
repeated-root compiler cases; 2,528 rejected single-coordinate witness mutations;
sharp run-bound examples through order seven; and exact rotation checks.
Application tests add 735 triangular-update/lift checks and 82 parity identities.
These tests are evidence for the implementation, not replacements for the proofs.

The large-horizon profile experiment locates a single negative sample at 50,000
among indices 0 through 100,000 using 54 distinct exact sequence evaluations to
construct the chain profiles, or 55 including subsequent verification. It does
not measure bit operations or claim that the fully expanded large-horizon
arithmetic assignment was exported.

See `SOURCE_AUDIT.md` for provenance and limits of the source inspection.
No repository writes were performed. No third-party PDFs or font files are
included.
