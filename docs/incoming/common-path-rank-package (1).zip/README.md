# Sharp Leading Constant for Constrained Crossover Rank

Research note prepared with OpenAI for Vladimir Reshetnikov, 1 October 2026.

## Main result

Every binary epsilon-free NFA with s states, arbitrary initial and final sets, and finite maximal aligned-fragment rank satisfies

    R(L) <= s^2 + 8s.

An explicit s-state family has R(L) = (s-3)^2 for s >= 4. Thus, if F(s) is the largest finite rank obtainable with at most s states,

    (s-3)^2 <= F(s) <= s^2 + 8s,
    lim F(s)/s^2 = 1.

The 19-page article proves the robust primitive theorem, the periodic obstruction criterion needed for the reduction, universal-component and cyclic-stripe structure, the joint entry/exit bound, all three component cases, and the exact lower construction. In particular, it does not infer that an interval in the full language's hull belongs to an isolated component's hull. Its primitive theorem explicitly permits globally witnessed singleton fragments while every other fragment has a fixed-endpoint witness of exactly the required length.

For primitive factor-universal binary graphs, the article also retains:

- R(L) <= n^2 + n + 1 when a Hamilton cycle exists
- R(L) <= n^2 + 3n when the circumference is at least n-1
- An odd-n family of exponent (n-1)(n-2), with no nonempty forward-total or backward-total state subset, yet R(L) <= 6n+3 for every nonempty endpoint choice

The restricted bounds do not have matching lower constructions here. The exact finite function, the optimal additive term, and extension of the leading coefficient to alphabets of size at least three remain open in this note.

## Files

- `hamiltonian-rank.pdf`: final article, retaining its existing filename
- `hamiltonian-rank.tex`: editable, self-contained LaTeX source
- `build.sh`: ordinary two-pass PDF build in a temporary directory
- `check_general.py`: exact parameter arithmetic and exact-length bubble-fragment checks
- `general-verification.json`: its deterministic output
- `check_lower.py`: independent length-gate and rank checks for the lower family
- `lower-verification.json`: its deterministic output
- `check.py`: restricted-bound arithmetic and labeled barrier-family checks
- `check_templates.py`: elementary-cycle checks for the two near-Hamiltonian templates
- `verification.json`: deterministic output from `check.py`
- `source-pins.json`: cited primary sources and pinned companion versions
- `review-receipt.json`: mathematical review, reproduction, and all-page rendering scope
- `SHA256SUMS`: checksums of the package files

The previous delivered version has been preserved separately; it is not mixed into this current package.

## Reproduce

Python 3.10 or newer and its standard library are sufficient:

    PYTHONDONTWRITEBYTECODE=1 python3 check_general.py > general-rerun.json
    diff -u general-verification.json general-rerun.json
    PYTHONDONTWRITEBYTECODE=1 python3 check_lower.py > lower-rerun.json
    diff -u lower-verification.json lower-rerun.json
    PYTHONDONTWRITEBYTECODE=1 python3 check.py > restricted-rerun.json
    diff -u verification.json restricted-rerun.json

With a working TeX Live or compatible pdfLaTeX installation, including AMS mathematics, Latin Modern, geometry, microtype, and hyperref:

    sh build.sh

A rebuilt PDF may have different timestamps or engine metadata and hence a different checksum. The supplied PDF was built with pdfTeX 1.40.26 and rendered with Poppler for visual inspection of every page. Verify the supplied package files using:

    sha256sum -c SHA256SUMS

## Exact finite coverage

The general arithmetic checks cover state counts through 100: 1,012,274 equal-cycle cases, 341,708 unequal-cycle cases, and 166,650 imprimitive-core cases. The bubble checks use five explicit circular chains, including a sole return bubble and unequal alternatives, and 4,884 exhaustive target-segment checks of length at most seven. Their independent dynamic program tests internal fragments using the complete ambient walk length and fixed endpoints; it licenses singleton pieces separately.

The lower-family checks test 147,677 gate lengths, 8,184 literal seed-substring rank calculations, and 8,222 exact-length path rank calculations. The gate is tested for m=2 through 60; literal slices use m=2 through 9 and lengths through nine; alternating extremal targets use m=2 through 20.

The retained restricted checks cover 89,258 Hamiltonian parameter triples and 3,406 near-Hamiltonian pairs through n=150. The template checks cover 737 maximal templates and 7,024 elementary cycles through n=20, including every replica position. The labeled barrier family is checked for odd n=5 through 21, including every singleton final state.

These are finite consistency checks. They are not an exhaustive enumeration of NFAs, an all-size proof, or a certificate of exact general ranks. All-size arguments appear in the article, with classical digraph inputs explicitly cited. The mathematical proof and full reduction passed separate independent reviews, followed by review of the integrated article. This is an unrefereed ordinary mathematical proof, not Lean or another proof-assistant verification. No literature-wide priority claim is made.
