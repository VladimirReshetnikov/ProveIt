QUANTITATIVE REFINEMENTS AROUND GOWERS' PROOF OF SZEMEREDI'S THEOREM
Research report, 6 October 2026

START HERE
  gowers_refinements.pdf       Complete article with proofs and references.
  gowers_refinements.tex       Complete editable LaTeX source and bibliography.
  figures/phase_frontier.pdf   Vector illustration required by the TeX source.

SCOPE
The report proves explicit local refinements, including torsion-sensitive
generalized von Neumann estimates, sharp density-profile bounds, improved
energy/Freiman extraction, and an exact bounded-degree polynomial-coordinate
coloring threshold. It does not claim a new best general Szemeredi bound,
priority for established methods, or Lean kernel certification.

The original paper and supplied Lean files are not redistributed in this
package. Exact source paths, pinned Git blob identifiers, and the status
ledger summary are in source_manifest.json. Bibliographic primary links
are in the article.

REBUILD THE PDF
Use a TeX Live or MiKTeX installation with standard LaTeX packages, including
amsmath, amssymb, amsthm, mathtools, lmodern, geometry, booktabs, longtable,
tabularx, array, xcolor, graphicx, microtype, enumitem, fancyhdr, and hyperref.

From this directory run:
  latexmk -pdf -interaction=nonstopmode -halt-on-error gowers_refinements.tex

Alternatively run this command twice (a third run can settle the contents):
  pdflatex -interaction=nonstopmode -halt-on-error gowers_refinements.tex

No BibTeX run is needed: the bibliography is included in the main source.
Keep figures/phase_frontier.pdf in its relative directory when compiling.

REPRODUCE THE DIAGNOSTICS
Use Python 3.10 or later. NumPy is required for the arbitrary complex-function
checks; Matplotlib is required only to regenerate the figure. Dependency
versions used for the supplied checks are recorded in verification_results.json.

  python3 -m pip install -r requirements.txt
  python3 verification/run_all.py

Each diagnostic can also be run individually. No verification script needs
network access. Exact finite arithmetic is used for the profile, prime-fibre,
representation, explicit norm, and coloring checks. Rational phase geometry
is checked exactly, with floating-point complex-distance checks at tolerance
1e-12. General complex cube calculations use NumPy, tolerance 1e-9, and a
fixed seed. These computations are examples and diagnostics, not universal
proofs or Lean verification.

REGENERATE THE FIGURE AND FORMULA TABLE
  python3 verification/make_figure.py

This regenerates figures/phase_frontier.pdf, figures/phase_frontier.png,
and formula_examples.json. The plot evaluates proved sufficient guarantees;
it is not an empirical or globally optimal frontier.

PACKAGE CONTENTS
  verification/verify_density_phase.py
  verification/verify_structural.py
  verification/verify_torsion.py
  verification/verify_polynomial.py
  verification/run_all.py
  verification/make_figure.py
  verification_results.json
  source_manifest.json
  formula_examples.json
  requirements.txt
  figures/phase_frontier.pdf
  figures/phase_frontier.png
  gowers_refinements.tex
  gowers_refinements.pdf
  README.txt

For theorem hypotheses, equality cases, credit to existing constructions,
current literature, integration risks, and proposed further questions,
consult the complete article.
