# Report 299

## Endpoint Obstructions to Universal Common Base Lifting

For every integer k >= 1, the unasserted proposition Section16ContextualLiftAt k at ProveIt commit 130fca9b1131fd983bd0af27565d36e8dfd2865a is false even at gamma = 1. With

    K = 2^(2^(2^(k+9))), R = 4K, theta = 1/(32K),
    N_* = (2^26 K^6)^(2K),

we construct an input and a bad common-base witness at every prime N >= N_*. The input is a partial function on a positive-density slab. It satisfies the original weighted product property, all structured-pair conditions and every field of the actual common-base structure. On a proper local box, all admissible unit covers reach at most 5/16 of the points while the definition requires at least 1/2.

A second valid common-base witness for the same input selects a modal colour class and satisfies the unit cover. Thus the result refutes the universal quantifier over witnesses, not an existential selection theorem, Theorem 16.2, the conditional implication proofs, or any global Szemeredi theorem. The article gives a precise existential replacement and proves only its conditional transport consequence.

An earlier unnumbered note already establishes a k = 1, gamma < 1 universal-witness obstruction with a full-domain map and vanishing defect. The endpoint, all-dimensional positive-density slab, and paired witnesses distinguish this report. Existing balanced-word and finite-alphabet cover ingredients are credited. No exhaustive priority claim, Lean compilation, or upstream edit is made.

## Contents

- Report299.pdf and Report299.tex: article and editable TeX source
- companion/: bounded exact standard-library checks and certificate
- tests/: 35 companion regression tests and 41 guarded-builder tests
- SOURCE_MANIFEST.json: 40 complete-source identity records, including the 35-file research collection and five independent auxiliary sources
- source_excerpts.json: 28 exact line-ranged source excerpts, not complete source files or third-party paper prose
- SOURCES.md: provenance and source scope
- provenance/PROOF.md: frozen research proof, byte-preserved
- CURRENT_SOURCE_STATUS.json: dated later-revision core identity checks
- build.py and REPRODUCING.md: bounded offline deterministic reproduction
- MANIFEST.sha256: hashes of all other public distribution files

The finite companion illustrates the mechanisms; it does not construct a theorem-scale word, evaluate the enormous K or N_*, prove the general theorem by enumeration, or authenticate unbundled sources independently.

## Quick start

    python3 -I -B build.py verify
    python3 -I -B companion/exact_checks.py
    python3 -I -B build.py reproduce --output /tmp/report299-replay

The output directory must be fresh or empty, absolute, and outside the extracted source tree. See REPRODUCING.md for toolchain requirements, checks, limits and authenticity scope. The package is independent of Reports 1–298 and contains no upstream runtime.
