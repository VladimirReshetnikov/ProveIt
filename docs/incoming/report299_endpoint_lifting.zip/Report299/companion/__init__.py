"""Report 299 standard-library, offline exact companion."""
