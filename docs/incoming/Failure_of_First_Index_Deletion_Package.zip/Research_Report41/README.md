# Research Report 41: first-index deletion counterfamilies

The article presents a symbolic full counterfamily for the exact normalized81
and ordinary82 first-index deletion candidates. The bound 85 is unchanged.
Read the article and the stated inherited compiler premises for the mathematical
claim; finite executable checks are corroboration, not an infinite proof.

## Contents and provenance

- `Research_Report41.tex` and the approved `Research_Report41.pdf`: the article
- `evidence/`: the entire frozen scientific packet, 48 payloads plus its manifest,
  byte-exact without normalization or rewriting
- `smooth/`: separately frozen optional smooth-radix corollary, eight payloads
  plus its own manifest, byte-exact with root/author review attribution
- `verification/`: source lineage, strict expected receipts, replay plan and
  final approval records
- Root Python tools: enclosing integrity, replay, PDF build, archive and QA

The source manifest SHA256 is
`94f45847037067162dd21e77f19e8edc2cc53cb0aa9ca6642e335c5d7c21cbb4`.
The final full proof SHA256 is
`dc886e8991e32c331b9135b4ea6b3f73733656be3df6c2aa01576e1732fb83e1`.
The original independent-reviewed proof, original audit, original receipts,
and inert original checker sources remain in `evidence/audit_bootstrap/`.
The original independent proof SHA256 is
`789e0d876393c4cd74076c41b9d030d3e192939346505217db13cfd599ed48a0`.
See `evidence/FINAL_RELEASE_REVIEW.md`: final clarity/endpoint edits were reviewed
by the coordinating author; release replays of reviewer-written checks were
performed by the author after CLI/path hardening. They are not a new independent
review of the final release bytes or the enclosing tooling.

The optional smooth-radix manifest SHA256 is
`ac48a5a3206514ac1b49d8bb510807e351fccf11730952f19c827b916f28f82b`.
Its proof SHA256 is
`259ec165067555228eb97fd6ca37180feaba6861df4ce1cce94d73917b12d8ca`.
This separate corollary improves the radix selection only; it does not bound
all downstream Pell witnesses and is not attributed to the original independent
reviewer. The factorial packet remains unchanged. See `smooth/ROOT_REVIEW.md`.

## Preserved-source erratum

The preliminary `evidence/PROOF.md` writes the strict upper bound
`psi_A(j) < (2A)^(j-1)` for `j >= 2`. At `j = 2` there is equality.
The strict statement holds for `j >= 3`; the non-strict statement holds for
`j >= 1`. Its relevant preliminary applications use `j = 4, 5`, and the full
family uses `p >= 55`, `n >= 40`, so the conclusions are unchanged. The article
states the corrected lemma and the erratum. The frozen source is preserved
verbatim to keep its provenance auditable.

## Verification and replay

First authenticate the ZIP against its independently supplied SHA256 using a
trusted local hash tool. The verifier cannot authenticate itself against an
attacker who replaces both the verifier and its pin.

From the extracted release directory, using Python 3.9 or later:

```
python -I -B verify_release.py --verify-only
python -I -B verify_release.py --self-test-types
python -I -B verify_release.py --replay
python -I -B -O verify_release.py --replay
```

Replay authenticates the complete allowlist, file bytes/modes, frozen packet
manifest and every permitted mathematical executable before running any copied
checker. Each normal and optimized run uses a fresh external copy. Receipts
must match the expected JSON recursively with exact types and key sets and must
also equal the saved receipt bytes. The original and copied release bytes,
modes and modification times are checked after each run. The implementation
uses explicit exceptions, not optimization-disabled assertions.

Optional exports require a new external directory whose parent already exists:

```
python -I -B verify_release.py --replay --receipt-dir ../fresh-receipts
```

Only the five mathematical scripts in `verification/replay-plan.json` are run.
`search_scaled.py`, `verify_manifest.py`, `.py.txt` historical copies and saved
source arrays are inert evidence. No upstream program or saved arithmetic
schedule is executed. No full astronomical witness tuple is materialized.

## Rebuild the PDF

Requires a locally installed TeX Live pdfLaTeX; nothing is installed or fetched.
Use a fresh external build directory with an existing parent:

```
python -I -B build_pdf.py --output ../fresh-pdf-build --check-packaged
```

The builder uses three passes, a local external format/font-map cache,
`SOURCE_DATE_EPOCH=1790985600`, UTC, omitted PDF dates and trailer ID, and
explicitly disabled shell escape. Byte reproducibility is checked in the
release build environment; different TeX/font versions can produce different
PDF bytes. All build logs and auxiliaries stay outside the release.

## Archive and QA

```
python -I -B archive_release.py --create ../Research_Report41.zip
python -I -B archive_release.py --check ../Research_Report41.zip --sha256 INDEPENDENT_SHA256 --replay
python -I -B tamper_regression.py
python -I -B output_guard_regression.py
python -I -B archive_regression.py --archive ../Research_Report41.zip --sha256 INDEPENDENT_SHA256
```

The ZIP uses sorted names, a fixed timestamp, regular-file modes and fixed
compression settings. Two runs in the same Python/zlib environment must be
byte-identical. Checking compares all member bytes and metadata with the
already authenticated release before any safe manual extraction, then checks
and optionally replays a moved extraction in both interpreter modes.
Archives and exported receipts must be fresh and outside the release. Hostile
ZIP and tamper tests use disposable external copies only.

`seal_release.py` is a maintainer utility, never a tool for validating an
untrusted download. `--final` requires approval bound to the exact article
TeX/PDF and frozen proof plus all-page visual QA. `--engineering-preview`
and archiver `--allow-engineering-preview` exist only for explicitly labeled
external development QA and do not approve a final article release.
