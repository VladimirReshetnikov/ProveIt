# Report55 Chronological Diophantine Matrix Certificates

Report55 gives a fully expanded fixed-arity positive-integer polynomial for the actual pinned ordinary-input five-register matrix countdown, equivalently its associated 195-generator singular 7×7 directed-semigroup target T(x), relative to explicit constructive Pell and inherited matrix-interface theorems.

- One unchanged positive ordinary input x
- 41,309 strictly positive witnesses
- 23,618 equality residuals
- 184,016 binary gates: 72,093 multiplications, 64,111 additions, 47,812 subtractions
- Exact total degree 12
- All 1,475 POWER and 491 Sub calls expanded; no exponentiation, digit extraction, bit operation, AND, SPREAD, selected matrix table, or variable-length conjunction primitive
- A common signed offset, paid common branch selectors and whole-digit slices, complete chronology, exact countdown, and checked carry bounds

The concrete fixed contexts are `[110` and `A0]`. They are not claimed to initialize every c.e. language. An arbitrary-program compiler is neither implemented nor audited, and program-dependent matrices would require a newly sufficient radix factor. No improvement to the repository’s prior 84-operation benchmark, finite-fold or unique-witness representation, real-witness semantics, mortality result, inverse-closed group claim, optimality, or practical witness-size bound is asserted.

## Start here

- `article/Report55.pdf`: the complete 21-page article
- `article/Report55.tex`: editable LaTeX source
- `science/ARCHITECTURE.md` and `science/SOURCE_NOTES.md`: unchanged scientific proof and accounting
- `science/evidence/polynomial-dag.json`: authoritative fully expanded polynomial graph
- `independent_audit/AUDIT.md`: separate exact-source and interface audit, PASS relative to the named dependencies
- `manuscript_review/MANUSCRIPT_AUDIT.md`: separate pin-bound review of the final21-page manuscript, proof, attribution, data, and all rendered pages, PASS
- `dependencies/`: pinned Pell and deeper inherited matrix proof texts
- `audit_replay/README.md`: supported isolated scientific replay and QA commands
- `verification/`: release-time checks and review evidence

The `science/` and `independent_audit/` trees are exact frozen provenance copies. The `manuscript_review/` files are also preserved evidence; its supplemental checker uses historical fixed review-workspace paths and is not a portable replay entry point. Their historical instructions and absolute paths remain unchanged, but are not the release entry points. Do not run the submitted scientific builder or semantic checker, original historical programs, stored accepting schedules, or Lean. The safe replay below executes only newly authored independent audit checkers in fresh external copies; it does not write beside the preserved originals.

## Mathematical dependencies

The constructive arithmetic dependency is mathlib4 commit `ac77769fabe23cb237559e7f56578dbead91499f`, file `Mathlib/NumberTheory/PellMatiyasevic.lean`, theorems `matiyasevic` and `eq_pow_of_pell`. Its exact source is bundled with its Apache 2.0 license. The positive adapters, strict gaps, paired congruence quotients, and index e+1 reduction are stated in full in the article. Lean and its import graph are not rebuilt.

The actual matrix-target equivalence inherits the faithful twenty-letter group encoding, first-row injectivity, lower-marker word shape, context transfer, and synchronized-row theorem. The release includes the four deeper matrix notes fetched read-only at the pinned countdown commit, with exact SHA256 values matching those already recorded by the context proof. Their addition improves inspectability without upgrading inherited theorems to newly executed formal proofs. The further program-family interpretation relies on the inherited effective initialization and Neary–Woods simulation premise. It is explicitly separate from the concrete fixed-context theorem.

## Integrity verification

Python 3 standard library suffices for integrity verification and scientific replay. Obtain the manifest SHA256 from the trusted accompanying delivery, rather than trusting a self-declared value inside an unauthenticated archive. Run from any directory:

    python3 -I /path/to/BUNDLE/release.py verify --manifest-sha256 TRUSTED_MANIFEST_SHA256

The manifest checks exact paths, file bytes, sizes, and POSIX modes, including directory entries and no extra files. It excludes itself to avoid self-reference. Preserve archived modes when extracting if the extraction utility does not do so automatically.

## Safe scientific replay

Use fresh absolute output paths whose parent already exists. The output must be outside the two immutable input trees; choose a location outside the entire release as below.

    python3 -I -S /path/to/BUNDLE/audit_replay/replay_audit.py \
      --packet /path/to/BUNDLE/science \
      --audit /path/to/BUNDLE/independent_audit \
      --output /fresh/external/report55-audit

The adapter authenticates both frozen manifests and exact inventories before creating output. It makes a read-only science snapshot and copies the two independently authored checkers into separate normal and optimized output folders. Each is run using isolated Python, once normally and once with -O. All four generated core receipts must match the frozen expected bytes. The adapter checks the original trees' bytes, modes, modification times, identities, and inventories again before publishing its final success receipt.

Both science and audit inputs may be read-only. Symlinks, parent traversal, extra files/directories, altered or missing source files, mismatched pins, overlapping paths, and reused outputs are rejected. The adapter is not a security sandbox against a hostile process concurrently replacing directories or a compromised runtime. Authenticate its bytes with the release manifest.

A release-time isolated replay reproduced both receipts. The adapter's separate QA passed 28 fail-closed cases and normal/optimized launches from moved, ZIP-extracted, read-only inputs. To repeat its full QA, use the exact command in `audit_replay/README.md`. No numerical full nested-Pell witness was generated; symbolic reconstruction and finite probes corroborate the all-integer proof at their stated levels.

## Deterministic PDF and ZIP

The PDF build requires locally installed TeX Live/pdfTeX and Latin Modern fonts, plus the packages declared in the LaTeX source. The tool is offline, uses fresh output-local TeX caches, and disables shell escape. It performs three passes and rejects overfull boxes or unresolved references. A sealed build requires byte identity with the packaged PDF in the same TeX/font environment. Cross-version PDF byte identity is not promised.

    python3 -I /path/to/BUNDLE/release.py build-pdf \
      --manifest-sha256 TRUSTED_MANIFEST_SHA256 \
      --output /fresh/external/report55-pdf

    python3 -I /path/to/BUNDLE/release.py archive \
      --manifest-sha256 TRUSTED_MANIFEST_SHA256 \
      --output /existing/external/parent/Report55-reproduction.zip

The ZIP uses sorted paths, fixed UTC timestamps, preserved POSIX modes, and ZIP_STORED data, avoiding compression-version differences. Every member is checked against the release after writing. Output paths cannot overlap the release, follow symlink components, or overwrite prior output. The author-only `seal` and `--draft` options are not part of routine reproduction.

To repeat the release-tool guard, relocation, two-ZIP, and two-PDF tests in a fresh external workspace:

    python3 -I /path/to/BUNDLE/verification/check_release_tools.py \
      --output /fresh/external/report55-tool-qa

Those tests mutate only their disposable fixture copies. Source preservation and PDF/ZIP identity are checked separately from mathematical correctness. The whole delivered release can reside on a read-only filesystem without a build writing into it. Ordinary manifest verification still requires the archived POSIX modes; changing mode bits manually changes the manifest inventory.

## Authoritative graph and scope of reproducibility

DAG SHA256:

    95e2563fcfcaecfdc5918ffd6dd7421896350df8969a38f08cbb5f5060d80034

The exact-source checker reconstructs every residual as a sparse polynomial, checks every macro argument and port, verifies every finalizer gate and all liveness, and extracts an exact degree-twelve coefficient of one. The interface checker reconstructs all 195 matrices and their 9,555 entries from actual fixed data, without reading or executing stored accepting schedules. The separate finite checks include 29,524 control words, 14,322 signed-counter candidates, 4,352 arbitrary chronology candidates, 1,280 Sub parity cases, 37,248 carry corners, and 112 slice partitions.

Original scientific inputs and audit files remain unchanged. The final manifest and ZIP hashes belong in the accompanying delivery outside this archive. The independent manuscript review is complete and bound to the final TeX/PDF pins. A terminal sealed-release check is an additional delivery quality gate; neither is an extra assumption of the mathematical theorem.
