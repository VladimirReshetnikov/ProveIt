# A 238-state Turing machine for ZFC consistency

Prepared for Vladimir Reshetnikov and incorporation into ProveIt, 19 October 2026.

## Result

`machines/zfc_combined238.tm` is an explicit binary, one-tape, blank-start Turing
machine with **238 working states**. Its initializer is included. The ordinary
mathematical proof in `report.pdf` establishes, using the identified inherited
ProveIt source calibration,

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halt}(M_{238},0^{\mathbb Z})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

Thus the construction meets the requested strict bound of fewer than 239
working states. This does not assert unconditional consistency of ZFC.

**Evidence level:** ordinary mathematical proof, exact finite reconstruction,
unbounded symbolic instruction certificates, and a separate local simulation.
This submission does **not** contain a newly compiled complete Lean/Rocq
endpoint for the 238-state table or a serialized derivation in the object
theory. The inherited logical calibration and its concrete source are
identified; its ancestor proof-assistant dependency tree is not rebuilt here.

## Machine convention and identity

| Item | Value |
|---|---|
| Working states | `0` through `237` |
| Initial state | `0` |
| Halt outcome | `238`, with no transition rows |
| Tape alphabet and blank | `{0,1}`, blank `0` |
| Tape | One two-way infinite tape |
| Initial head coordinate | `0` |
| Moves | `L` or `R` only |
| Transition rows | `476`, exactly two for each working state |
| Runtime dispatcher | `84` |

Each non-comment table line is
`state read_symbol written_symbol direction next_state`.
The `#! start 0` directive makes the start state explicit. All 238 working
states are reachable in the transition graph; this is a structural statement,
not a claim that the actual blank run visits every state.

SHA-256 of the exact canonical table bytes:

```text
909f29c493e0ccc5d6a481fd7a20a9a82eb934ab2aa7df17b5ec3789255a8c08
```

The equivalent inherited-label table is `machines/zfc_combined238_old.tm`:
start `95`, runtime dispatcher `96`, halt outcome `254`. Its digest is

```text
069942be27db9736875ea042320e51ac3b1eac7116cbe01cdce520fa6056f78c
```

`machines/renumbering.json` gives the complete bijection. Inherited labels
appearing in the proof must not be confused with equal-looking canonical
labels. In particular, deleting inherited state 169 does not delete canonical
state 169.

## The new composition

Two incoming 239-state constructions contribute distinct one-state savings:

1. **Boundary239:** a certified source reparenthesization, decoder repair,
   and fold deleting inherited state 218.
2. **Coordinated239:** a delayed-erasure fold deleting inherited state 169.

The `BusyBeaver239_Research_2026-10-19.zip` and
`ZFC239_Companion_2026-10-19.zip` incoming archives carry identical coordinated
tables. They contribute one saving, not two. The separate
`ZFC_239_State_Construction_2026-10-19.zip` carries Boundary239.

Starting with the inherited-label Boundary239 table, delete state 169 and
make precisely these changes:

| Row | Boundary239 action | Final action |
|---|---|---|
| `80/0` | `0 R 25` | `0 L 106` |
| `91/1` | `0 L 50` | `1 L 167` |
| `147/0` | `0 R 169` | `0 R 80` |

Every other retained row is unchanged: 473 unchanged rows plus the three
changes give 476 rows. `verification/check_construction.py` reconstructs the
table, checks this exact difference, and verifies its canonical renumbering.

The substantive compatibility obligation is the tape context at inherited
state 169 after the source transformation. In addition to a closed local
predicate, its read-one branch needs the next cell to be one. We prove this
on Boundary239's own changed source and arbitrary valid runtime inputs, then
prove the four whole-tape simulation paths independently. Disjoint edited
state names alone would not establish correctness.

## Fresh verification results

The complete packaged replay with both proof routes passed. Its recorded
elapsed time was approximately 467 seconds in the preparation environment.

| Obligation | Result |
|---|---|
| Final universal runtime | 8,386 guarded cases; 2,255,513 symbolic rules |
| Final transition coverage | 476 of 476 rows |
| Minimum instruction duration | At least 13 literal transitions |
| Predecessor guard runtime | 8,386 cases; 2,247,513 symbolic rules |
| Read-one context at inherited 169 | 32 symbolic visits; right run `g+K`, `23 <= K <= 59` |
| Independent local fold | Four exceptional paths; 474 ordinary predecessor rows commute |
| Exact final blank startup | 409,835 transitions |
| Independent relative startup | 409,692 whole-tape mapped checkpoints |
| Source identity | All 6,455 ordered instruction triples and the initial seed |
| Source transformation | 13 stages, 25 rotations; 8,385 successor edges plus halt per stage |
| Independent frame identity | Dyadic-interval audit of every source and successor |

The universal cases quantify all nine register values independently, an
arbitrary natural extra gap, an arbitrary first spare value, and an arbitrary
finite spare tail. The complete spare suffix is nonempty. They are not a
bounded sample of register values or an observation of a long blank run.
The finite symbolic-rule cap bounds proof construction; finite-list and
homogeneous-run induction discharge unbounded literal executions.

Both full runtime routes use the same attributed affine/list engine. The
local symbolic tape verifier and the dyadic source/frame verifier are
separately implemented. The package does not claim two independent
proof-assistant kernels.

The exact startup reaches inherited state 96 with head at -5. Its logical
register tuple is `(3,0,0,0,3,0,0,0,0)`, its additional gap is 117, and it has
167 spare blocks of value one. Sparse, dense, and canonical-label executions
agree on the complete tape. The new run is 144 transitions longer than the
Boundary239 startup; the state saving deliberately trades time for control.

## Reproduce

Requirements: Python 3.10 or later, standard library only. No network or
proof-assistant installation is needed for the new executable checks. Run
with assertions enabled: omit `-O` and `-OO`, and unset `PYTHONOPTIMIZE`.
Run these commands from the extracted package root.

Full final-table proof plus source, construction, startup, and local checks:

```bash
python3 -B reproduce.py --output replay
```

Also replay the independently instrumented predecessor-guard proof:

```bash
python3 -B reproduce.py --with-guard --output replay-both
```

Finite construction, source, local fold, and startup checks only:

```bash
python3 -B reproduce.py --quick --output replay-quick
```

Choose a new or empty output directory. The driver verifies the integrity
manifest, checks every subprocess exit code and the exact JSON success
status, and writes fresh logs and receipts to the chosen directory. Default
full success is `FULL_238_MATHEMATICAL_REPLAY_PASS`; the explicitly abbreviated
run reports `QUICK_238_REPLAY_PASS` and does not rerun either unbounded proof.

The shipped full replay is in `evidence/packaged_replay/`. Its receipt records
76 artifact hashes because that run preceded final article/README assembly
and inclusion of the replay records themselves. The final `SHA256SUMS`
covers the complete delivered file set except the manifest itself. The
machine and verification code were unchanged after the full replay.

To rebuild the PDF while preserving the delivered files:

```bash
mkdir -p build-pdf
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build-pdf report.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build-pdf report.tex
```

The article uses standard LaTeX packages including `lmodern`, `microtype`,
`geometry`, `amsmath`, `amsthm`, `booktabs`, `enumitem`, `fancyhdr`, `xurl`,
and `hyperref`. The PDF includes the complete canonical transition table.

## Alternative formalism result

The report also supplies a concrete logical simplification. In complete
equality-free first-order logic on a nonempty domain, let `E` be equivalence
and `R` membership. Assuming the stated `H1`, `H7`, first-coordinate
membership congruence `H5`, and global-image collection, the single collection
matrix

\[
\theta(x,y;a,c)=E(y,a)\land R(c,y)
\]

derives second-coordinate membership congruence `H3`. The seed is supplied
by the assumed membership premise itself. An explicit quotient argument
then gives a smaller relational axiom presentation equiconsistent with the
native SIR theory, and hence with ZFC through its inherited calibration.

This is a theorem about a complete first-order presentation. The current
numeric proof engine has additional logical-interface constraints; deleting
its numeric `rho3` row would require a separate non-circular derivation or a
new complete engine. The 238-state construction keeps the calibrated logic
intact. The report distinguishes this new logical result from earlier
measured backend costs and from proposals that have no certified small
binary machine yet.

## Layout and incorporation

- `report.pdf`, `report.tex`, `sections/`: complete article and editable sources.
- `machines/`: final tables, source, and canonical map.
- `verification/`: new constructor/wrappers and attributed proof engines.
- `reference/source/`: source certificate, pinned Lean data, seed and semantics.
- `reference/calibration/`: inherited calibration endpoint and relevant notes.
- `evidence/`: discovery receipts, technical audits, and full packaged replay.
- `PROVENANCE.json`: commit and incoming-archive pins.
- `SHA256SUMS`: delivered artifact identity.
- `ATTRIBUTION.md`, `licenses/`: credits, retained licenses, and notices.

Retain the ZIP under `docs/incoming/`, or extract the package into a directory
such as `Computability/BusyBeaver/Research/ZFC/candidate-combined238/` while
preserving its relative structure. No repository files were pushed or merged
as part of this delivery.

The next formalization task is to instantiate the existing binary framework
with the literal 238-state table, startup, source tree, and instruction
coverage, or to formalize the local fold and next-one invariant on a checked
Boundary239 endpoint. No new set-theoretic consistency calibration is needed
for this particular state saving.
