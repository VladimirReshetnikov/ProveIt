# Three alternative 220-state ZFC consistency machines

This self-contained packet delivers **three certified continuation rewrites** of
the pinned K220 construction. Each is a two-symbol, one-tape Turing machine with
220 working states and 440 transition rows. In the inherited ordinary
mathematical calibration, **ZFC proves that blank nonhalting is equivalent to
Con(ZFC)**. These are alternative literal tables, not a 219-state construction.

The new proofs are executable all-tape equivalence certificates. They are not
newly compiled Rocq/Lean kernel theorems for the exact table bytes. No
unconditional nonhalting, PA-internal endpoint, priority, or minimality claim is
made. See `report/report.pdf` and its editable `report/report.tex`.

## Delivered constructions

All row numbers in this list are native labels; the two changes compose.

- `row103`: replace 103/read-1, `0 L 162`, by `0 L 142`.
- `row157`: replace 157/read-1, `1 L 148`, by `1 L 187`.
- `both`: make both replacements.

Each directory `machine/<variant>/` contains `k220.native.tm`, canonical
`k220.tm`, and `canonicalization.json`. The common complete source is
`machine/sites220.json`. The canonical tables are pairwise distinct, including
from the baseline, so these are not merely state renamings.

The model has a two-way infinite binary tape, blank symbol 0, and L/R moves.
A row is `state read write direction next-state`. The header specifies start 0.
Canonical working labels are 0 through 219 and terminal label 220; native
working labels are noncontiguous, dispatcher 84 and terminal 254. Canonical
dispatcher is 22. The terminal is **not** counted as a working state. All 220
working states are reachable in the raw transition graph; this does not assert
that every state is visited on the blank run.

## Reproduce offline

Python 3.10 or newer and its standard library suffice. Keep assertions enabled:
do not use `python -O` or `PYTHONOPTIMIZE`. From this packet's root:

```sh
python3 -B portable/reproduce.py --output-dir ../k220-alternatives-replay
```

The output directory must be initially empty and outside the packet. The
replay verifies the exact inventory and pinned archive, extracts dependencies
safely, replays the retained K220 construction/calibration chain in its `--quick`
mode, reconstructs all three tables, freshly runs both equivalence checkers,
and independently regenerates canonical tables and complete blank startups.
No downloads or external repositories are needed. Expect several minutes for
the inherited chain, followed by seconds for the three variants.

The default **audits the stored baseline unbounded runtime certificate**; it
does not claim a fresh baseline symbolic induction. To rederive that induction
on all 6,167 baseline primitive-interface cases, use:

```sh
python3 -B portable/reproduce.py --full-baseline --output-dir ../k220-full-replay
```

`--deep-baseline` additionally asks the retained baseline driver to rederive
ancestor runtime proofs and is substantially more expensive.
`--skip-baseline-replay` is explicitly weaker debugging mode: it verifies only
the alternatives and their pinned baseline identity, not the inherited
calibration chain. Its success status is correspondingly different.

For an independent structural, whole-tape, and startup audit without importing
any release checker, run after the default replay has extracted the baseline:

```sh
python3 -B verification/independent_core_audit.py \
  --packet . \
  --baseline ../k220-alternatives-replay/vendor/K220_Construction_2026-10-20 \
  --output ../k220-core-audit.json
```

## Why the proof transfers

The original table's finite-window invariant is recomputed from an arbitrary
binary initial tape and checked inductive. Unchanged rows synchronize in one
step. The altered rows have positive old/new blocks of at most two/three steps,
ending at identical state, head, and complete tape, without interior halting.
The explicit macro checker and a separately implemented radius-5 checker both
establish these joins. Each window proof covers **91,337 inductive contexts**;
96, 320, and 416 respectively require nontrivial diagrams.

This establishes halting equivalence from state 0, for every binary tape and
integer head position. It therefore transports the baseline's blank-tape
consistency equivalence. It is not an assertion from arbitrary machine states.
Native sparse-tape and canonical dense-tape simulations independently reach
the same complete initialized frame after **409,835 transitions**: head -5,
351 one cells, all other cells zero. This finite startup check is additional
evidence, not a substitute for the unbounded proof.

The independent default release replay passed all nine phases. It ran on the
24-file executable-core snapshot; the final sealing audit compares those
portable/machine/vendor bytes exactly and checks the added documentation and
exploratory material separately. Its receipt and snapshot manifest are under
`verification/`.

The pinned baseline's earlier fresh full replay proved all 6,167 unbounded
primitive cases using 1,516,421 symbolic rules and represented all 440 rows.
Its unchanged receipt and separate runtime audit are retained under
`verification/baseline_full_*`. Baseline case data, executable checkers,
construction source, and recursive dependencies remain inside the unchanged
`vendor/K220_Construction_2026-10-20.zip`.

## Exploratory material is not certified

`exploratory/` separately retains three 220-state research specimens: a row160
occurrence redistribution, a six-leaf semantic NOP layout, and their combined
layout. They have finite/discovery evidence only and are **not** three more
certified consistency machines. They are excluded from the main replay.
`exploratory/README.md` states the individual gaps; its small reconstruction
script verifies table bytes only. No raw exhaustive-search trees are bundled.

## Integrity and provenance

`manifest.json` covers every payload file except itself and `SHA256SUMS`;
`SHA256SUMS` additionally covers the manifest. `PROVENANCE.json` records exact
artifact and predecessor identities. Historical receipts retain their original
workspace-relative path strings only as provenance; replay uses exclusively
packet-local files and its chosen output directory.

The retained baseline ZIP SHA-256 is
`132cbb326fcbf6e54957a03095c5f790e207f4ed8ebfb6ceb6e272f329e4ee00`.
Its source SHA-256, shared by the three certified alternatives, is
`837e92d7b1c107330f160f654f6c36ff0b03dfbf6bc2b89c6f782eb7db4c4ce7`.
See `NOTICE.md` and `LICENSE` for attribution and inherited licensing.

To verify the sealed inventory and repack it without overwriting an existing ZIP:

```sh
python3 -B verification/repack.py --output ../K220_Alternatives_2026-10-20.rebuilt.zip
```

Archive timestamps, order, and permissions are fixed. Identical ZIP bytes also
require compatible Python/zlib compression behavior; the payload hashes are
platform-independent.
