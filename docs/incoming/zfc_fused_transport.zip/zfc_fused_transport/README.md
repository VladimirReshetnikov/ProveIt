# Smaller proof engines for ZFC consistency machines

Research prepared for Vladimir Reshetnikov and ProveIt, 17 October 2026.

Read `zfc_fused_transport.pdf` for the full report, ordinary proofs,
literature/repository audit, measurements, and implementation proposal.
`zfc_fused_transport.tex` and every included section are supplied for editing.

## Main findings

1. **Preferred complete kernel:** unrestricted universal instantiation at
   free name zero, generalization at zero, and two ordinary free-name
   shifts. Uniform shifts recover arbitrary-name UI/GEN. Universal closure
   followed by instantiation realizes simultaneous substitutions, including
   collisions. The two separate name-stream passes have **11 + 11 = 22**
   reachable controls under the retained source-28 codec.
2. **Stronger name-map-only theorem:** let `u(z) = z + 1`, and let `w(0)=1`,
   `w(1)=-1`, `w(z)=z-1` otherwise. Words in `u,w` realize every map on any
   specified finite set of integer names. The construction is explicit,
   preserves bound indices, and uses **11 + 13 = 24** stream controls,
   compared with **46** for the four separately counted prior operations.
   The report proves two narrow minimality results for this architecture.
3. **Exact logic preservation:** executable certificate translations run
   in both directions between the supplied kernels and the retained
   complete source-28 kernel, with exact formulas at line correspondences.
   Fixed searches target genuine falsity in CP/GIC or in the previously
   calibrated one-parameter closure theory with exact binary Union.
4. **Machine experiment:** an independently checked inductive abstraction
   identifies two forced-zero decrement sites in the literal full
   register program. Replacing their closed empty transfer loops with
   no-ops makes the shared program larger. A **265-state** Wade control
   reproduces the known 203-node sharing of the full source.

**No new complete blank-tape binary machine below 253 working states is
established.** Stream controls, register graph nodes, and binary TM states
are different metrics. The 253-state table is existing work; the included
265-state table is a control, not a new record or a new end-to-end formal
consistency theorem. Historical priority of the particular simple map pair
has not been established. Two-generator existence is classical, and the
fixed-zero quantifier construction uses standard logical ingredients.

## Reproduce

The reference code uses the Python standard library (tested with Python
3.12; Python 3.10 or later is recommended). No network, Lean, Coq, or
external Python packages are required for the finite experiments.

```sh
python3 -B reproduce.py
python3 -B reproduce.py --extended
```

The default run verifies the root file manifest before executing the
checkers. It regenerates the preferred evidence in temporary directories,
compares JSON structurally while excluding only elapsed time, runs the
independent mathematical checks, and invokes the nested machine package's
byte-identical reproducer. `--extended` additionally repeats the retained
preliminary 26-control and three-map constructions. A failed check exits
with a nonzero status.

The initial manifest describes the delivered files. Rebuilding or editing
the PDF/source can change those hashes; run the focused checkers below
when reviewing intentional local changes rather than mistaking the old
manifest for a statement about the edited artifact.

```sh
python3 -B code/verify_name_transport.py --output /tmp/name-check.json
python3 -B code/verify_integration.py --output-dir /tmp/kernel-check
python3 -B code/verify_pair_independent.py
python3 -B shift22/verify_shift_kernel.py --output /tmp/shift-check.json
python3 -B machine_control/reproduce.py
```

The search procedures are reference algorithms with unbounded mathematical
finite lists and integers. The JSON representation is not proposed as a
tiny-machine encoding. Resource exhaustion is an execution error, not
logical rejection. Reproduction does not run the consistency search while
waiting for a contradiction.

## Build the report

Use a standard TeX Live installation with pdfLaTeX, Latin Modern, amsmath,
amsthm, booktabs, microtype, enumitem, needspace, xurl, hyperref, fancyhdr, and listings.
The bibliography is included directly; no BibTeX step is needed.

```sh
make report
```

This runs three passes to resolve the table of contents, references, and
page numbers. `make clean` removes auxiliary files and preserves the PDF.

## File map

| Location | Role |
| --- | --- |
| `report/` | Full report sections and references |
| `shift22/` | Preferred normalized complete kernel, transport, fixed searches, streams, and checks |
| `code/name_transport.py` | Explicit finite-substitution compiler for the 24-control pair |
| `code/two_kernel.py`, `code/proof_transport.py` | Fresh-UI complete kernel and exact bidirectional proof transport |
| `code/fixed_theory.py`, `code/unary_union.py` | Fixed CP/GIC and unary-plus-BU search interfaces |
| `code/vendor/` | Unchanged four-operation comparators |
| `code/transport26.py`, `notes/` | Preliminary construction retained for comparison |
| `data/` | Exact finite evidence, stream tables, and sample certificates |
| `machine_control/` | Original source, invariant certificate, complete control tables, backend, and independent verifiers |
| `provenance.json`, `NOTICE.md`, `MANIFEST.sha256` | Source pins, attribution/license boundaries, and file integrity |

The `alternative=True` option in `code/fixed_theory.py` is the inherited
**EPSC2** option. The **unary-plus-BU** theory has its own explicit entry in
`code/unary_union.py` and the normalized counterpart in `shift22/`.

## Review and integration

The report audits the three requested commits and the later snapshot
`61e77836565f63582561f54745f633d50efd9c7d`, including all five incoming
archives. It distinguishes ordinary mathematical proofs, finite program
checks, already established formal results, and unfinished machine
interfaces. Its source-level consistency theorem adopts the prior
finite-refutation calibration; this package does not reimplement the entire
Foundation/Choice proof-code translation in a theorem prover.

The proposed next task is to compile the normalized complete search and
the 24-control comparator through the same fully accounted binary backend,
with enumeration, formula storage, quantifier traversal, and blank-tape
initialization included. Keep the finite-map theorem, normalized kernel,
and numerical control as separate research ledger entries. A future record
claim requires a literal smaller complete table and its full calibration.
