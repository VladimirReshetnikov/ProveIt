# Polishability at the Hahn–Puiseux–Levi-Civita Boundary

Research manuscript prepared with AI assistance for Vladimir Reshetnikov,
3 October 2026.

## Files

- `article.pdf`: typeset article with full conventional proofs, source audit,
  contribution ledger, and 12 further research questions.
- `article.tex`: self-contained LaTeX source; no external bibliography file,
  figures, or custom font files are needed.
- `verify.py`: deterministic, standard-library-only exact rational regression
  checks for the finite examples and truncation algorithms.
- `verification.json`: actual successful run, 20,116 assertions in 29 families.
- `SOURCES.md`: source locations and precise audit/novelty limits.
- `build.sh`: local reproduction commands.

## Main results and hypotheses

An **admissible** topology makes the additive group Polish, gives the positive
cone the Baire property, and makes multiplication by each fixed scalar Borel.
This is not merely a Polish topology on the underlying set or positive monoid.

The article proves the presentation-invariant Hahn classification:
for a nonzero ordered abelian exponent group Gamma, the full ordered Hahn
field k((t^Gamma)) has an admissible Polish topology precisely when k is
countable and Gamma is order-isomorphic to Z.

For countable ordered coefficients, the Puiseux field has no admissible Polish
topology, while the left-finite Levi-Civita field has exactly one. Their
coefficient-code domains are respectively Sigma^0_2-complete and
Pi^0_3-complete. The full rational Hahn field has a Pi^1_1-complete domain.

Every countable family of rational Hahn series lies in a complete separable
intermediate field with unique admissible topology. These local Polish hulls
have no maximal member. Each has a uniform countable bound on support order
types, but these bounds are unbounded across the family of hulls. Exactly
continuum many admissibly Polish intermediate fields are needed to cover the
full rational Hahn field. With real algebraic coefficients, the hulls can
also be chosen real closed and truncation-closed.

Every integer part of an admissible Polish ordered field is countable and
closed discrete. For real algebraic coefficients, the Levi-Civita field is
real closed and has the explicit finite-principal-part integer part in the
article. Its floor is Baire class one with precisely that integer part as its
discontinuity set. The strengthened local hulls also have canonical countable
omnific integer parts and floor maps with the same exact regularity. Across
these countable arithmetic models, every countable support order type can be
realized.

## Status

These are conventional proofs in an unrefereed research manuscript. The
classical category theorems, generalized-series constructions,
Newton–Puiseux theorem, prior coanalytic support obstruction, and omnific floor
rule are credited rather than claimed as new. The contribution is the
classification, local hull and exact cover theorems, and regularity synthesis
developed here. Global publication
priority has not been established by an exhaustive literature search.

No famous conjecture or new solution of Glazer's printed questions is claimed.
No Lean/Rocq build or kernel check of the new results was performed. The
20,116 finite checks are not substitutes for proofs of infinite, descriptive,
or category-theoretic statements.

## Reproduce

Use a normal TeX Live installation with newpx, AMS packages, mathtools,
microtype, geometry, enumitem, booktabs, tabularx, longtable, xcolor, fancyhdr,
tcolorbox, xurl, hyperref, titlesec, and needspace. No fonts are bundled.

```sh
sh build.sh
```

Alternatively:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
python3 verify.py --output verification.json
```

The checker requires Python 3.10 or later and only its standard library.
The fixed random seed is 20261003. All tested arithmetic uses exact rational
coefficients and exponents; there are no floating-point tolerance checks.
