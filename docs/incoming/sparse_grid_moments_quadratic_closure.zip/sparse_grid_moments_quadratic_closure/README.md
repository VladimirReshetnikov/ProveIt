# Sparse Grid Moments and Quadratic Closure

**Exact finite-field laws, sharp obstructions, and a complete cube rank enumerator**  
Research draft, 7 October 2026. Prepared with ChatGPT for Vladimir Reshetnikov's ProveIt project.

## Main results

The article proves an exact coordinate-margin criterion for relations among sampled polynomial values, a sharp exponential mixing theorem for independent product blocks, and the resulting limiting normalized moments. Its principal proposed original results are the quadratic closure correction (Theorem 7.4), the exact graph-girth convergence law for every two-axis pattern (Theorem 8.1), and the complete binary three-cube rank enumerator over every finite field (Theorem 9.1). Corollary 10.1 gives exact finite-dimensional moments for the punctured seven-site cube and the full eight-site cube.

The minimum-support bound, the connection to trades and tensor relations, and the Fourier tools are explicitly identified as inherited or standard ingredients. These results do **not** certify the global quasipolynomial progression claim in the motivating OpenAI manuscript. Its grid lemma assumes number of axes at most degree; the obstructions outside that range do not refute its stated lemma.

**Status:** written mathematical proofs, with exact-arithmetic computational checks. Not independently refereed, not Lean-verified, and no established priority claim. See `THEOREM_STATUS.md`.

## Files

- `article.tex`: self-contained LaTeX source, including the bibliography.
- `article.pdf`: compiled, visually checked 22-page article.
- `verify.py`: deterministic standard-library Python checks.
- `verification_results.json`: output of the recorded full check run.
- `THEOREM_STATUS.md`: claims, dependencies, novelty boundaries, and verification scope.
- `SOURCES.md`: pinned repository references and literature register.
- `INTEGRATION.md`: proposed placement and formalization interfaces.
- `Makefile`: build and verification commands.
- `SHA256SUMS`: checksums of all other package files.

## Build

A standard TeX Live installation with `latexmk`, `amsmath`, `amssymb`, `amsthm`, `mathtools`, `lmodern`, `microtype`, `booktabs`, `enumitem`, `hyperref`, and `fancyhdr` is sufficient.

```sh
make pdf
```

Equivalent command:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The source is standalone: it does not require downloaded manuscript sources or a separate bibliography file. A final build completed without undefined references, LaTeX warnings, or overfull/underfull box warnings. All 22 pages were rendered with Poppler and inspected in contact sheets.

## Reproduce the recorded checks

Python 3.10 or later; no third-party Python packages are required.

```sh
python3 verify.py --fields 2,3,4,5,7 --output verification_results.json
```

Or run `make check`. The recorded run checked:

- **920,367 matrices**, exhaustively enumerating the seven-dimensional cube space over F_2, F_3, F_4, F_5, F_7;
- **1,275 nonempty cube subpatterns**, checking rank and quadratic closure;
- **28,970 weighted-Laplacian frequency checks**, verifying graph-girth exponents and the exact formulas for cycles of lengths 4, 6, and 8;
- 80 full-grid rank instances and 75 margin/matrix representation comparisons;
- four independent direct moment enumerations (seven/eight sites over F_2/F_3, n = 1);
- three formal polynomial-coefficient comparisons, and three exhaustive binary minimum-support checks.

The matrix counts are compared against the formulas proved in the article, not used to infer them. The direct moment enumerations are separate from the rank-enumerator calculation. The script deliberately records no timestamps or timings, so its JSON output is deterministic.

The default script invocation omits F_7 for a smaller run. `--fields 2,3,4,5,7,8` additionally tests F_8; that larger F_8 enumeration is supported but is **not** part of the supplied recorded run. Arithmetic for F_4 uses t^2+t+1; F_8 uses t^3+t+1.

## Check the package

```sh
sha256sum -c SHA256SUMS
```

Rebuilding the PDF can change embedded PDF metadata, so verify the supplied checksums before rebuilding. No third-party manuscripts, font files, or repository source copies are included.

## Integration

Suggested standalone directory:

```text
Combinatorics/Ramsey/Research/GowersSzemeredi/sparse-grid-moments-quadratic-closure/
```

The package makes no remote repository changes and changes no formalization ledger. Its LaTeX labels use the `gm:` prefix. See `INTEGRATION.md` for potential Lean interfaces and the boundaries of the comparison to the source grid lemma.
