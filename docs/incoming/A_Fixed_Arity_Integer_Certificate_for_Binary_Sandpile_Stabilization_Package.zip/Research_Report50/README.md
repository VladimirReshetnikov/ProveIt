# Research Report 50

A horizon-free fixed-arity positive-integer certificate for finite binary sandpile stabilization, with its proof, literal polynomial DAG, frozen source dependencies, independent audit, and offline reproduction helpers.

## Result and exact scope

One positive input encodes eight physical descriptors by seven right-associated Cantor pairings. The exact raw-instance theorem recognizes valid base-32 periodic 3D tile data (digits 0 through 5) plus a finite anchored patch (digits 0 through 15) that admit finite legal global stabilization with a binary odometer.

- 2,566 strictly positive integer witnesses
- 1,491 residual equations, combined into one sum of squares
- Exact total degree 18, with highest homogeneous coefficient 48 as proved in the report
- 11,469 binary arithmetic gates: 4,518 multiplications, 3,933 additions, 3,018 subtractions
- Fixed integer constants are free; the source is not a restricted-constant or minimal-operation claim

The supplied binary stream may be a stabilizing supersolution strictly larger than the true legal odometer. It does not certify target firing. The explicit fifteen-equation POWER macro inherits two pinned mathlib Pell theorems. The U15 loader, one-shot theorem, geometry and raw-program compiler remain separate dependencies. No real-exactness, unique witness or finite-fold theorem is claimed.

The independent scientific and literal-source audit is complete and passed. Historical statements that the audit was still in progress remain unchanged in the frozen scientific README/PROOF; this release wrapper and the completed independent audit supersede that historical status only. The author’s source files and audit bytes were not edited to make the release portable.

## Files

- `Research_Report50.pdf`: report with the exact theorem, full arithmetic macros and proof
- `Research_Report50.tex`: editable standalone LaTeX source
- `science/`: the 24 frozen scientific files listed in `verification/science-freeze.json`
- `science/evidence/polynomial-dag.json`: the authoritative literal integer polynomial DAG
- `science/sources/`: pinned inert Pell and Report 35/36 proof texts
- `independent_audit/`: unchanged independent audit, checker, exact receipts and source fetch
- `audit_replay/`: separate pinned filesystem adapter and its 16 safety/relocation tests
- `verification/`: review, preservation, reproduction and toolchain evidence
- `MANIFEST.json`: complete release file inventory, excluding itself
- `verify_release.py`: authenticate all members and optionally replay the independent checker
- `build_pdf.py`: deterministic offline PDF helper
- `archive_release.py`: deterministic authenticated ZIP helper

Only the independently authored checker is executed by the default scientific replay. The submitted builder/checkers, historical schedules, universal machine, Lean, and pinned upstream sources are not executed. The DAG is read as formal polynomial syntax, not as a numeric arithmetic schedule. The complete proof is mathematical prose with a pinned number-theoretic dependency; the independent exact polynomial comparison is not an end-to-end Lean formalization.

## Trust and integrity

Obtain the trusted SHA256 of `MANIFEST.json` from the separately distributed release identity, not from an untrusted altered copy. Authenticate the release and helpers before running them. Hash consistency proves identity relative to that trusted value, not the mathematical theorem or authorship.

From the unpacked `Research_Report50` directory, set `PIN` to the trusted 64-character manifest hash. Then run:

```sh
python3 -I -B verify_release.py --manifest-sha256 "$PIN" --verify-only
```

The verifier requires the exact set of listed files and directories, checks bytes, modes and hashes, and rejects symlinks or nonregular objects. Keep the package unchanged; put new outputs outside it. Do not run the historical source-local commands in `science/README.md` against these frozen copies, because those commands were designed to write their local receipts.

## Fresh isolated independent replay

Requires ordinary Python 3.9 or later and no third-party Python package. Choose a new output directory whose parent exists, outside the release. The output itself must not already exist.

```sh
python3 -I -B verify_release.py --manifest-sha256 "$PIN" \
  --output /tmp/report50-replay-new
```

The helper authenticates the entire release and executes the pinned independent audit through its separate portable adapter. It reproduces the exact scientific receipt and log byte-for-byte, and verifies that every release/input byte, mode, modification time and tree entry is preserved. Optimized Python (`-O`, `-OO`, or optimization environment modes) is rejected for replay because scientific assertions must remain enabled. The helper is a reproducibility guard for reviewed, pinned code, not a sandbox for arbitrary Python.

The adapter can also be run directly after authenticating the package:

```sh
python3 -I -B audit_replay/replay_independent_audit.py \
  --source-root science --audit-root independent_audit \
  --output /tmp/report50-audit-new
```

It changes only the frozen checker's two path globals. No checker source bytes are rewritten and cached bytecode cannot substitute for the authenticated checker. Fresh evidence is written only to the new external output.

The included `audit_replay/test_replay_runner.py` can rerun all 16 safety tests with the same two input-root flags and a fresh external `--output`. It copies and moves its own fixtures, tests altered pins, output overlap, existing paths, symlinks, optimization refusal and ignored extraneous bytecode, and checks source preservation. Its included frozen evidence records a successful run.

## Offline PDF reproduction

Requires Python 3, a local TeX Live pdfLaTeX installation, and the standard packages listed at the top of the TeX source. It needs no network, downloaded package or shell escape. The recorded environment uses pdfTeX 1.40.26. Choose a fresh external directory with an existing parent.

```sh
python3 -I -B build_pdf.py --output /tmp/report50-pdf-new \
  --check-packaged --manifest-sha256 "$PIN"
```

This validates the release, builds in the external directory with an isolated TeX cache and fixed epoch, and requires byte identity with the packaged PDF. Three pdfLaTeX passes resolve references and contents. Byte identity is established for the recorded toolchain; another TeX version may render an equivalent PDF with different bytes. To build on a different toolchain without the byte-equality requirement, omit `--check-packaged` after separately authenticating the release.

The released PDF was rendered and all pages visually inspected. No overfull boxes, unresolved references or final-pass LaTeX warnings remain. Raster images are review intermediates, not extra user-facing deliverables.

## Deterministic archive creation

```sh
python3 -I -B archive_release.py --manifest-sha256 "$PIN" \
  --output /tmp/Research_Report50_reproducibility.zip
```

The archive contains only regular files under `Research_Report50/`, with a sorted order, fixed 4 October 2026 timestamp, normalized ZIP metadata and pinned file modes. Its output path must be new and external. Two repeated archives of the frozen release have identical bytes. The SHA256 printed by the helper can be compared with the separate archive identity.

## Publication boundary

This package was prepared locally. It does not modify a repository, publish a site, run upstream code or create/change a saved schedule. Sharing and publication are separate actions owned by the requesting user or coordinating assistant.
