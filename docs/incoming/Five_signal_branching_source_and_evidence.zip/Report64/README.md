# Report64: nondestructive five-signal branching and bounded-horizon certificates

This release combines a physical fixed-ordered-section counter compiler with a separate native finite-trace polynomial certificate. The two original scientific packets remain unchanged, including their historical audit-pending status at the moment of freezing. Completed independent audit dossiers are packaged separately.

## Read first

- `Report64.pdf`: the detailed article
- `Report64.tex`: the standalone editable LaTeX source, exactly flattened from the eleven modules in `manuscript/`
- `science/frozen-proof/`: the frozen physical branching/compiler packet
- `science/arithmetic/`: the frozen bounded-horizon packet, retaining its original filenames and original Report65 development identifier
- `audits/physical/`: independent physical audit and static checker
- `audits/arithmetic/`: independent finite-polynomial audit and static checker
- `dependencies/proofs/`: a separate unchanged copy of the needed predecessor proof with provenance
- `manuscript-review/`: exact-final-byte independent manuscript and all-page visual review
- `qa/independent-tools/`: independent release-tool review
- `tools/`: fresh Report64 release-only authentication, typesetting, sealing, extraction and owned synthetic tests

The arithmetic companion is integrated into Report64; it is not a separate user-facing report.

## Mathematical content and limits

A full section has stationary markers L=0<X=x<Y=y<R=D and one instruction messenger at L outgoing at speed +1. A changing test has two exact complete words on x>0, y-4x>0, 8x-y>0, D-y>0 and x>0, y-8x>0, D-y>0. A physically implemented, branch-tagged inverse restores the original section exactly, giving 14-event and 12-event nondestructive tests. The article specifies forward and inverse collision rules, all event times and positions, strict flight chronology, remote-tie and triple-collision boundaries, and exact positive-coefficient chamber certificates.

The uniform encoding is x=D(1/20+(1/10)2^-a), y=D(19/20-(1/10)2^-b). All zero/positive test guards and all increment/decrement intermediate guards hold for every finite pair of nonnegative counters. Each fixed finite program compiles to one finite table independent of initial counters, scale and horizon. Exactly five live signal occurrences remain; 19 rational speeds and at most 32 binary events per nonhalting instruction suffice, with D<T<10D. Halt means reaching a designated full section. The optional escape convention adds exactly three crossings. Infinite encoded computations have no finite-time collision accumulation.

Five-live-signal counter computation is already present in Durand-Lose's MCU 2004/2005 construction. The report prominently credits this precedent; it makes no novel universality, minimum-population, optimized speed/event count, global reversibility or finite-precision robustness claim. Its concrete interface is a fixed marker order with exact nondestructive branching and uniform guard coverage.

For each fixed native program and horizon T>=1, the companion uses positive inputs A=a+1,B=b+1 and T(E+2) positive witnesses. Here E counts split transition edges including one virtual halt edge; Z counts zero edges. There are T(E+Z+4)+1 displayed residual equation slots and one sum-of-squares polynomial of exactly degree four, jointly in inputs and witnesses. A witness exists exactly for halt by T and is unique if it exists. First halt exactly at T adds one residual, no witnesses. T=0 is a separate constant polynomial with no witnesses. Equation-slot counts include redundant or identically zero residuals for degenerate programs/state codes and are not rank or minimality statements.

The horizon changes the arity. No single fixed-arity unbounded-halting polynomial or finite-fold MRDP conclusion is established. Inputs are native shifted counter values; exponential physical initialization is separate. No polynomial predicate on arbitrary physical coordinates is claimed. Halt-loop padding is virtual arithmetic bookkeeping and is not executed by the escape-to-right physical machine.

## Frozen scientific identity

Physical proof SHA-256:
`85f5de45c0a30f8bdf45b82a613ef9e5a8c766b5d8215d17a3ebbbd0f60b370f`

Physical packet manifest SHA-256:
`e5d9f9a399ab9515a13b66ea4160b063a585c801002105b62f4528da516c1589`

Arithmetic proof SHA-256:
`5d9d7de3c9b6ca5551d7cd537b0e3570c0272af6716ba814453d5ad2123aea6a`

Arithmetic packet manifest SHA-256:
`54d8abdcc872f628e9ae6639f4119b15cd1d4bacd33ba412ffd85155110b3824`

`INPUT_PINS.json` authenticates every packaged file and internal directory in the three frozen scopes `science`, `audits` and `dependencies`, including bytes, modes and nanosecond mtimes. Original source roots and exact-copy snapshots are recorded in `qa/FROZEN_ASSEMBLY_PRESERVATION.json`. SHA-256 is an integrity commitment relative to a trusted external pin, not a digital signature or mathematical proof. Use the final release handoff as the separately supplied pin channel.

## Verification boundary

No author mathematical program, earlier constructor, native counter interpreter, physical simulator, saved physical collision schedule or proof-assistant program was executed by the report writer. Frozen author Python files are inert preserved evidence. Do not run them to reproduce this release.

The independent physical checker is exact static rational algebra and rule syntax. Its 4,424 checks include 56 primitive local rules and a 118-rule/142-label finite example that is assembled but never executed. The general fixed-program conclusion relies on the namespace and induction proof, not on one example. The independent arithmetic audit passed 54 schema instances, 201 finite-polynomial instances covering 33,640 candidate whole edge words, 22 fixtures and six replay-interface negative tests. Its checker uses sparse integer polynomial algebra and finite candidate-word satisfiability; it does not follow an execution path or choose enabled native transitions. The all-horizon uniqueness theorem remains the displayed induction proof, not a finite search claim. Counts from the two audits, manuscript checks and tooling tests overlap and are not additive theorem counts.

The typesetting scripts run ordinary TeX and rendering tools only. Figure coordinates are literal rational substitutions into proved tables, not simulator outputs. A fresh TeX format is built with no shell escape; every format/typesetting-pass recorder is retained. The lock covers executable bytes and the union of all recorded system inputs plus selected font maps. It does not inventory shared libraries, Python standard library or the operating system. The builder validates every rendered PNG and enforces exact packaged PDF equality when requested.

## Portable commands

Run from the release root or its relocated extracted counterpart. Replace PIN values with the externally supplied final handoff pins. Outputs must be new absolute paths outside the release and all frozen scopes. Existing outputs and source-overlapping outputs are rejected.

    python3 -I -S -B tools/release64.py check-inputs

    python3 -I -S -B tools/release64.py verify --manifest-sha256 MANIFEST_PIN

    python3 -I -S -B tools/build_report64.py \
      --pins-sha MANUSCRIPT_PIN \
      --dependency-lock-sha DEPENDENCY_LOCK_PIN \
      --require-packaged-match --output-dir /tmp/report64-build-new

    python3 -I -S -B tools/release64.py archive \
      --manifest-sha256 MANIFEST_PIN --output /tmp/report64-archive-new.zip

    python3 -I -S -B tools/release64.py extract \
      --manifest-sha256 MANIFEST_PIN --archive /tmp/report64-archive-new.zip \
      --output-dir /tmp/report64-extracted-new

The extractor rejects extra, duplicate, unsafe or changed archive entries before publishing the extracted tree and restores manifest-bound file/directory modes and nanosecond mtimes. Its output is the release root directly, without an extra enclosing Report64 directory. Generic unzip preserves payload bytes but need not reproduce the metadata required by strict manifest verification.

After inspecting the independent checker sources, replay the physical static audit to an external file:

    python3 -I -S -B audits/physical/audit_static.py "$PWD/science/frozen-proof" \
      > /tmp/report64-physical-replay-new.json

The physical checker only reads its packet and writes JSON to stdout. Its top-level arithmetic evaluates declared symbolic rows; it is not a collision schedule interpreter. Replay the independently authored arithmetic checker with a protected release root:

    python3 -I -S -B audits/arithmetic/independent_certificate_audit.py \
      --source "$PWD/science/arithmetic" \
      --output-dir /tmp/report64-arithmetic-replay-new --protected-root "$PWD"

Its documented interface and boundary are in `audits/arithmetic/AUDIT.md`. Keep all outputs external. Never redirect a replay over any release file.

## Reproducibility and review records

The final build receipt records the exact PDF/source/pin hashes, dependency scope, every-page inventory and preservation result. A bootstrap run records dependencies; it is not a locked build. Any initial locked build showing `packaged_pdf_match=false` predates promotion of that PDF to the release root. The final promoted-PDF rebuild requires and confirms a match. Independent manuscript acceptance binds the final PDF and source bytes. Independent release-tool review binds the exact three helper sources. A final terminal audit follows sealing and precedes publication.

Two independently requested archive outputs must be byte-identical under the provided deterministic archiver. The external final handoff supplies the manifest, PDF, standalone source, input pins, manuscript pins, toolchain lock, helper and ZIP hashes needed to bind those checks without trusting pins read only from inside the archive.

## Completed independent gates for the final release

- Physical science: accepted exact frozen proof, 4,424 static checks, 56 primitive rules and the 118-rule/142-label syntax example; `audits/physical/AUDIT.md`
- Arithmetic science: accepted exact frozen proof; 54 schema instances, 201 finite-polynomial instances / 33,640 candidate words, 22 fixtures and six interface rejection tests; `audits/arithmetic/AUDIT.md`
- Manuscript: final 21-page candidate d accepted after independent 140-dpi rendering and direct inspection of all pages, 281 static checks and six replay-boundary tests; `manuscript-review/AUDIT.md`
- Release tools: exact final helpers accepted after 93 main checks, 13 additional boundary checks and all 39 owned selftests; the actual PDF and its relocated rebuild are byte-identical, all 271 recorded system inputs are pinned; `qa/independent-tools/REVIEW.md`
- Author promoted-PDF build: `qa/final-locked-build/BUILD_RECEIPT.json` is PASS with `packaged_pdf_match=true`, 21 valid page rasters and complete release preservation

The final PDF SHA-256 is `c86cb407ffb93a37625d0d0a25e86bf2d0434eaee1104e3059a3b002d0210608`; standalone source SHA-256 is `52618709e5354630dacf5c33f18595605f6a8dd4e6d5ea1f6f44bc4bbc8a886e`. The final manuscript-pin map is `cba694ca6bb470c100a0216584bfc198837c2668564eb338767922daee1999db` and dependency lock is `0c8f1c05079b13f29f5b49d0da33a681c02552131dcac81e65af8aa6afb1be69`.

The independent tool review's diagnostic fixture manifest and ZIP pins are not the final publication pins. Final publication includes these review dossiers and build evidence; its separately supplied handoff provides the final manifest and ZIP hashes. The final terminal audit is performed after this source/evidence assembly and is not claimed completed by the archived pre-terminal README.
