"""Bounded exact diagnostics for Report296."""
