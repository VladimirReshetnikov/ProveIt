# Report 296

A Strict Comparison of Explicit Five Term Thresholds

For every real 0 < delta <= 1, the exact definitions at pinned ProveIt commit af74fb522c24a6331886b11db76942642a6a0e42 satisfy

    H_fejer < H_old^(1/4) < H_old.

More precisely, with n_fejer = ceil(8 / beta_fejer) and R = sigma_fejer / sigma_old >= 4,

    log(H_fejer) < R^(-n_fejer) log(H_old)
                <= 4^(-n_fejer) log(H_old).

Report296.tex and Report296.pdf contain all local definitions, a complete analytic proof through the exact maxima and ceilings, the inspected five-term progression implication, and further questions. The common Fourier threshold is retained exactly by reference; the comparison in fact works for any common finite real value in its place.

## Evidence and limits

- The main result is an ordinary rigorous real-variable proof about the pinned finite expressions
- The source's natural_five_term_fejer statement supplies the nonconstant five-term progression implication
- The small standard-library companion checks exact monomial/integer identities, bounded rational regressions, and the integrity of compact source excerpts
- No Lean compilation, complete imported-dependency audit, upstream-code execution, numerical evaluation of the astronomical thresholds, or package installation is part of this work
- No comparison with the paper's numerical five-term threshold, arbitrary-length result, literature-best bound, or historical unresolvedness claim is made

## Reproduce

    python3 -I -B build.py verify
    python3 -I -B build.py reproduce --output /tmp/report296-replay

Use a fresh absolute output directory outside this tree. See REPRODUCING.md for the guarded Linux build contract and reference toolchain. The exact diagnostics can run without TeX:

    python3 -I -B companion/exact_checks.py

SOURCES.md and SOURCE_MANIFEST.json record provenance. The full-source hashes in the manifest identify complete upstream files, which are not included; source_excerpts.json has separate hashes for its partial text records. Offline checks do not authenticate unbundled full-source bytes. Verify the detached ZIP SHA-256 through a trusted channel when package authenticity matters.
