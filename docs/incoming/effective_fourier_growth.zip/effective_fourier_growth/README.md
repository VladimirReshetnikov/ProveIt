# Effective Power-Law Fourier Growth from Low-Degree Observations

Research manuscript and exact-verification package, 8 October 2026.
Prepared with ChatGPT for Vladimir Reshetnikov.

## Main result

The article gives an effective fixed-batch implementation of the low-degree
observation method in the OpenAI preprint *Unbounded Violations of the
Square-Root Degree Bound* (26 September 2026).

It proves a uniform fourth-moment amplification theorem, an explicit
rational-threshold Gaussian certificate, and a family of balanced Boolean
functions whose singleton Fourier sums grow like D^(1/2+epsilon), with
simultaneous degree and dimension bounds. All recursion parameters are
specified, although the explicit parameters are astronomically large.

**Novelty boundary:** an unspecified power-law exponent already follows from
the source's unbounded-ratio assertion by balancing and composition. The
contribution here is the quantitative, fixed-parameter implementation,
its dimension/correlation formulas, and the exact finite witness. No
exhaustive priority claim, peer review, or proof-assistant verification is
claimed.

## Files

- `article.pdf`: compiled 22-page research article.
- `article.tex`: self-contained LaTeX source, including its bibliography.
- `references.bib`: optional bibliography records for reuse.
- `code/verify.py`: exact verifier, using only the Python standard library.
- `certificates/verification.json`: output from an executed verification run.
- `certificates/parameters.json`: symbolic explicit construction parameters.
- `CLAIMS.md`: proved, checked, inherited, and unresolved claims.
- `PROVENANCE.md`: source snapshot and inspected references.
- `FORMALIZATION.md`: proposed proof-assistant dependency plan, not a formal proof.
- `Makefile`: build and verification targets.
- `SHA256SUMS`: checksums of package artifacts other than this checksum file.

## Reproduce the finite certificates

Python 3.10 or later; no third-party modules are required.

```sh
python3 code/verify.py --output certificates/verification.json
```

The script performs three groups of checks:

1. It enumerates all 3,125 weighted block-sum states representing all
   1,048,576 bit strings of the 20-bit example, checks the pointwise
   cancellation identity, computes exact conditional-score moments, and
   performs integer tensor Fourier transforms for the exceptional cell,
   the sign readout, and an ordinary cell attaining the maximum degree.
2. It checks all 11,726 rules in the stated distinct-singleton binomial
   search family (block width 1 through 4). All candidate gains are compared
   using integers and rational numbers, not floating point.
3. It checks the finite rational inequalities used in the analytic Gaussian
   certificate. The exponential estimates come from rational Taylor bounds.

Successful execution ends with a JSON document whose status is
`all exact checks passed`.

## Rebuild the article

A standard TeX Live installation with pdfLaTeX and the packages listed in
`article.tex` is sufficient. No downloaded fonts or external figures are
needed.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Equivalently, run `make`. The bibliography is embedded in the source;
BibTeX is not required. A first build can require a third pdfLaTeX pass
if page-number changes affect cross-references.

## Key finite values

The 20-bit observation has 622 cells, cell degree exactly 16, and retained
variance `557065/34816 = 16 + 9/34816`. Its exceptional cell has probability
`17/2048`, full-sum mean `-31/17`, and full-sum variance `1147/289`.

Its Boolean sign readout has degree 16 and singleton sum `6435/2048 < 4`.
It is therefore **not itself a Boolean square-root-degree counterexample**.
The finite witness is not used as the base of the asymptotic theorem.

## Verification limits

The Python program is an exact finite checker, not a proof assistant. It
neither proves the analytic normal-transfer theorem nor instantiates the
astronomical Gaussian grid or averaging batch. The analytic theorem is
supported by the detailed proofs in the article and remains subject to
independent mathematical review. The explicit construction is computable
by finite exhaustive arithmetic; no practical running-time improvement is
claimed.

No repository was modified. Upstream source files and font files are not
included in this package.
