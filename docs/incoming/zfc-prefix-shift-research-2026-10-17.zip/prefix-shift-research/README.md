# Prefix-shift research toward a smaller ZFC-consistency machine

**Result: no verified machine below 252 working states.** This archive contains
a new 252-state arithmetic engine, its exact clean startup, mathematical
proofs of the changed contracts, source-level alternatives, and reproducible
negative compression experiments. The rejected 250-state table is included
only to document a specific wrong zero-branch control transfer.

The central new idea is to implement a positive decrement by shifting the
register **prefix right**, using the existing increment shifter. The selected
register decreases by one, the root gap increases by one, and no spare block
is appended. A new physical permutation reaches a clean frame with **exactly
nine zero-valued registers and no spare blocks after 25,612 literal binary
transitions**. Exactly nine blocks is then an invariant of the runtime.

Read [the research note](report/prefix_shift_research.pdf) and its
[LaTeX source](report/prefix_shift_research.tex). The PDF reports the result,
unbounded tape argument, logical proof boundary, failed 250-state contraction,
and concrete next synthesis targets.

## Machine files and conventions

| Artifact | Working states | Initial state | Halt outcome |
| --- | ---: | ---: | ---: |
| `bootstrap/prefix_rebased252_canonical.tm` | 252 | 0 | 252 |
| `bootstrap/prefix_rebased252.tm` | 252 | 64 | 254 |
| `bootstrap/mp_rebased252.tm` | 252 | 64 | 254 |
| `compression/prefix_zero250.tm` **REJECTED** | 250 | 64 | 254 |

The format is one row `state read write direction target`, with directions
`L` and `R`. Lines beginning with `#` are comments. The tape is two-way
infinite and initially all 0. The head starts at coordinate 0. The halt
outcome is separate from the counted working states; the transition into it
includes the listed write and move. `bootstrap/prefix_renumbering.json` maps
inherited labels to the canonical labels.

Canonical table SHA-256:

```text
fd09cc6c76b04e1f3eb34c5d6fec5f14bd3ef564767aae70023bb988599f3bc7
```

Inherited-label table SHA-256:

```text
b91dc16e60c26780a3006072347c15ea058fa0fab6c0b4b5493967cab11c6234
```

Its final startup configuration is old state 96, head 4, empty PC, gap 43,
with one-cells exactly `{3,47,49,51,53,55,57,59,61,63,65}` and every other cell
zero. The original-physical-to-new permutation is `(7,8,4,2,5,6,0,3,1)`;
logical `(N,T,W,A,D,H,X,Y,L)` occupy `(0,3,7,4,8,1,5,2,6)`.

## Reproduce the principal checks

Requirements: Python 3.10+ standard library, with assertions enabled. No
network, Lean, Coq, SAT solver, or third-party Python package is required.
Run from the extracted archive root:

```sh
python3 verify_research.py
python3 verify_research.py --extended
```

The first command runs the complete changed instruction audit and literal
startup, an independent phase replay, the alternative MP0 startup, an
independent check of the 2,998-pair source relation, exact source block tests,
and the rejected-250 counterexample. `--extended` also independently
regenerates the pinned baseline and MP0 relation and executes all 17,325
positive root-to-root controls. It normally takes only tens of seconds.
Every subprocess must succeed. Per-check logs and a JSON replay summary are
written to a newly created temporary directory, printed on completion.

The replay regenerates machine tables and some research JSON records in
place. Machine bytes must match the pinned new hashes above; elapsed times
in research records naturally change. `MANIFEST.sha256` describes the exact
delivered archive bytes before a replay. It is not a promise that regenerated
timing records remain byte-identical.

To run the main verification directly:

```sh
python3 bootstrap/verify_prefix_rebased.py
python3 logic_audit/audit_prefix_phase.py
python3 bootstrap/verify_mp_source_certificate.py
python3 redesign/shared_scanner_counterexample.py
```

The main verifier regenerates all **6,441 source leaves**, checks all
**8,366 guarded instruction cases**, checks **1,925 phase premises**, and
re-decodes all **8,365 nonhalting successors** to exclude unconsumed nonzero
PC bits. It then executes the exact 25,612-transition blank prefix.

For the document, a normal TeX installation with `latexmk` suffices:

```sh
make pdf
```

## Proof status

The new positive-decrement lemma is an ordinary unbounded tape proof in
`logic_audit/prefix_decrement_proof.md`. It requires a leading one-run
followed by two zeros in the prepared left context. The checker explicitly
verifies this condition at every invocation. The other three register-box
excursions are inherited from the pinned source with their actual row
dependencies. The new audit must **not** be described as using four unchanged
box contracts or preserving the old 55-row union.

The source program uses the already documented successful-MP dummy-push
deletion. Its original AX, equality, logical schemata, native-theory bundle,
and unrestricted GEN are retained. The supplied proof blocks establish
soundness and completeness for the full original numerical calculus. The
native/ZF/ZFC calibration is reused as a named prior theorem. The note
explains the mathematical composition in ZFC and distinguishes it from the
separate, stronger PA internalization project.

**No new kernel-checked binary/ZFC endpoint or serialized object-language
ZFC proof is included.** Finite literal executions, complete conditional
symbolic checks, unbounded handwritten proofs, and imported formal results
are identified separately. The machine has 252 states; this archive does
not lower the published bound.

The 250-state contraction fails on an explicit all-zero register frame:
it follows the positive successor when decrement sees zero. This refutes its
claimed runtime contract. It does not decide every property of that table's
eventual blank computation. `redesign/shared_scanner_counterexample.py`
reconstructs the contraction and verifies the exact divergent endpoints.

## Contents

| Directory | Purpose |
| --- | --- |
| `report/` | Main `.tex` and compiled `.pdf` |
| `bootstrap/` | New tables, exact startup/guard checks, permutation census, MP0 source certificate |
| `logic_audit/` | Unbounded tape and source proofs; exact independent arithmetic and phase checks |
| `compression/` | Native C++ search engines, input inventories, bounded-search records and scope notes |
| `redesign/` | Alternative compiler/source variants, their tables and results, rejected-scanner counterexamples |
| `source/` | Curated pinned upstream dependency snapshot for replay |
| `evidence/` | Main verification summary and baseline control record |

See the directory READMEs for experimental compiler commands and optional
GCC/Clang C++20 searches. Those diagnostic families have explicit contracts, phase
filters, witness suites, and fuel or node limits. A negative result means no
candidate passed that declared diagnostic. It is not a lower bound on all
machines or all possible semantics-preserving rewrites.

The approximately 298 MiB partial Python lazy-search journal is omitted:
the completed native implementation, its input cases, per-deletion ledger,
and final summary supersede it. The original partial-run summary records
the omitted journal's hash and scope. Compiled binaries, Python caches, TeX
intermediates, and preview PNGs are also omitted. Search scripts, tables,
compact/full JSON evidence, and optional native replay inputs are retained.
Eight large completed JSONL ledgers are stored losslessly as deterministic
`.jsonl.gz` files; the compression summary names those exact files. Native
input `.txt` files remain uncompressed for direct replay.

## Provenance and incorporation

All imported ProveIt inputs are pinned to commit
`43026ff42f0939f09b9e95495248cfadcad38e38`:

<https://github.com/VladimirReshetnikov/ProveIt/tree/43026ff42f0939f09b9e95495248cfadcad38e38/Computability/BusyBeaver/Research/ZFC/candidate-permutation252>

The source inventory records file hashes. The historical arithmetic engine
and compiler are attributed to Mira-Cult, Jeff Ketchersid, and Andrew James
Wade; the upstream and public-253 pins are retained in the source and report.
The Wade backend's MIT-0 license is included. The successful-MP edit itself
is prior work in `source/.../mp_dummy_push_partial_cost.md`; the new boot and
prefix-engine work must not be confused with discovery of that edit.

This directory can be incorporated as a research subdirectory of ProveIt.
Its replay paths are relative to this directory, independent of the parent
repository location. It does not modify the maintained permutation-252
candidate. Before replacing a maintained candidate or announcing a new
bound, integrate the new phase-qualified box theorem, source MP0 contract,
runtime composition, and blank initializer into the formal development.

Prepared on 2026-10-17 as a research deliverable for this investigation.
