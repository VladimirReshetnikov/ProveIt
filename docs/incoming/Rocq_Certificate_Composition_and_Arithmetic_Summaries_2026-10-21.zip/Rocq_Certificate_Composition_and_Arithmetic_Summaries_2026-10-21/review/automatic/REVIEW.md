# Automatic certificates: priority and overlap audit

Materialized user-authorized LibraryZIP libfile_01b98bcb22bc8191ace490807ae5a203, SHA2568b33c232f5c2b9747b1f56e0072fd23477fe19d61f583134e628e4e60cb82d84. Inert source/log inspection only; no archived scripts or proof modules executed. Saved conversation https://chatgpt.com/c/6ad90d6b-6fb8-83e8-8dab-9bc667321042.

New important result: automatic correspondence inferred from literal trees is accepted by both Lean and Rocq normalized checkers, using the same1426tuples. Generator correctness is not assumed: the emitted cache is independently kernel-checked. The packet does not claim to invent the quotient or normalized semantics.

Lean receipt records30fresh project modules,33successful recorded invocations including3emitter executions, same-build resource retries, zero preexisting project objects, and no full binary/ZFC endpoint. Independent byte audit matched all33recorded source hashes and33raw log hashes to included files. Rocq automatic instance compiles2new modules against10hash-bound dependencies, with no second recursive audit. Both new source hashes and logs match included bytes. The earlier normalized Rocq lane records12fresh dependencies/source modules plus recursive coqchk. ProductionRocq9.1/fullbinary endpoint not rebuilt. These are inspected upstream compiler records, not local compilation.

The two shared entries.json files are byte-identical SHA2565f78445c4455e6cef2a7bf5fd321fb940a05194d967fbe66c55b5fc1cde90eb2. Its positive codes use high sentinel then MSB-first consumed paths; Rocq auto renders rev(decode_path code), correctly distinct from the prior NormalizedCert215 packed reversal convention. Do not interchange numeric codes without decoding.

## Balanced/normalized overlap

Lean's RMNormalizedBisim already uses RMBisim.CTree, lookupC and getc. The automatic emitter materializes balanced CTree blocks. Therefore balanced normalized storage is ALREADY checked in the Lean lane, and the broader idea must not be presented as new.

The Rocq normalized and automatic checker is list-based: NCheck.branch_ok calls Bisim230.getc C j, which uses nth_error. No BalancedBisim/getTree composition appears in these Rocq components. The new BalancedNormalized proposal remains a concrete Rocq adaptation of existing ideas, with an independently checked finite1426-entry instance, not a novel generic algorithm and not a compiled theorem.

Priority consequence: retire 'automatic normalized correspondence generator' as an open research milestone. Remaining work includes integrating its exact facade/generator into maintained current endpoints, composing efficient Rocq lookup with normalized checking and compiling that concrete instance, plus untouched primitive/return and final alternative-endpoint adapters. No newly completed CM finalZFCadapter is supplied here.

Evidence: AUDIT.json; inert/K215_Automatic_Certificates_2026-10-21/lean_auto/{README.md,verification/receipt.json,BusyBeaver/ZFC/RMBisim.lean,BusyBeaver/ZFC/RMNormalizedBisim.lean}; rocq_auto/{README.md,verification/result.json}; rocq_normalized/{README.md,NormalizedBisim.v,verification/result.json}.
