# Surreal Polytopes at Finite and Transfinite Scales

## Sharp lifting compression and universal coordinate-truncation histories

Research manuscript prepared for Vladimir Reshetnikov, 30 September 2026.

The article studies two different notions of changing scale in surreal
polytope geometry and proves that they behave very differently.

For a fixed real configuration of n points spanning dimension d, every
surreal lifting vector compresses to at most n-d-1 real coefficient vectors.
The compression preserves every real affine-dependence sign and every common
initial normal-form lifting subdivision. Its minimal length is an intrinsic
real rank. The strict histories are precisely marked regular refinement
chains, and planar parabolic polygons attain the bound.

For moving coordinates, four bounded planar generators can instead realize
any prescribed triangle/quadrilateral history from degree two onward. The
construction uses reciprocal convergent power series with rational
coefficients. Adding omega^(-omega) independently selects either uniform
full configuration type while preserving every finite coordinate truncation.
An elementary rational-function example already alternates indefinitely.

The article also gives standard-part convex-hull and finite-polar identities,
a counterexample to a naive face-lattice residue map, a near-optimality-band
replacement, finite Puiseux realization, a coefficient-query impossibility
result, a proposed Lean development, and eight further research directions.

## Files

- `article.tex` and `article.pdf`: complete article, conventional proofs,
  two mathematical diagrams, references, and proof-boundary tables.
- `code/verify.py`: exact finite regression tests, Python standard library only.
- `data/verification.json`: check counts, seeds, scope, and polygon certificates.
- `data/hexagon_example.json`: exact height rows and marked cells.
- `data/universal_history_example.json`: a prescribed binary history and jets.
- `data/verification_run.txt`: captured output of the final verification run.
- `notes/sources.md`: primary references, repository snapshot, source scope.
- `notes/proof_audit.md`: sensitive steps, limitations, and priority distinctions.
- `notes/validation.json`: build and PDF inspection record.
- `Makefile`: commands for tests and PDF compilation.

## Reproduce

Python 3.10 or later is sufficient for the exact tests:

    python3 code/verify.py

There are no third-party Python dependencies or network calls. The program
writes its output relative to its own location, not the current directory.
The recorded run passed 163,914 exact rational-arithmetic assertions.
The count is not a count of independent theorems or a confidence level.

Build the PDF with a standard TeX Live installation:

    make pdf

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times. No shell escape or separate bibliography processor is needed.
The source uses standard packages listed in its preamble, including newtx,
amsmath, amsthm, mathtools, microtype, TikZ, and hyperref. No font files are
included in the archive.

## Relation to ProveIt

Pinned repository: VladimirReshetnikov/ProveIt
Commit: 6996fee43cc97b6c16351def7507d59a95bf62f0
Commit timestamp: 2026-09-30T16:07:39Z

The concrete inspected Lean source is
`Algebra/SurrealNumbers/Surreal/Algebra/Geometry.lean`, which supplies finite
ordered-field geometry and cross-product identities. See `notes/sources.md`
for precise source identities. No repository files were changed.

## Proof and novelty status

This is an AI-assisted, unrefereed conventional mathematical manuscript.
No Lean build or independent proof certification was performed. Finite
regression tests do not establish the infinite or transfinite theorems;
the written proofs do.

Real-closed-field transfer, finite-dimensional lexicographic orders,
secondary-polytope dimension, finite Puiseux specialization, and curve
selection are classical. The manuscript does not claim those foundations
as new. Its support-adapted synthesis, sharp explicit examples, and universal
four-point coordinate-truncation construction are presented with full
arguments. Exhaustive historical priority has not been established. No
resolution of a named published major conjecture is claimed.
