# Restoring Substitution in Small ZFC-Consistency Machines

Research report prepared for Vladimir Reshetnikov, 16 October 2026.

**Read zfc_substitution_engine.pdf.** Its editable source is report.tex,
with the complete section sources in sections/.

The report inspects the four distinct requested ProveIt commits and newer
material through 47f3a3602946dfe48803a91a910c646e74637ac8. The repeated
b07d1a27b in the request was treated as one commit.

## Main result and scope

The proposal uses equality-free PSC alone, with its inherited ordinary
ZFC consistency calibration, in a complete signed-tableau checker.
The new implementation stores the fixed PSC context once, shares the
matrix through three environment calls, allows arbitrary parameter
identifications, and introduces schema instances dynamically after
fresh tableau witnesses exist.

The report proves soundness and refutation completeness of the specified
abstract algorithm and supplies a total natural-number certificate
encoding. It also gives a new logical obstruction: fresh-variable
instantiation and all positive/negative atomic instantiations can still
fail substitution of an existing variable into a composite formula.

**This is not a new sub-253-state machine or a formally verified Python
program.** No state bound for the new checker is claimed.

The separate engineering directory contains a **268-working-state
compiler control** that retains all eight original logical rows. It
includes an independently checked 4,533-pair register-operation
certificate and can be regenerated offline. The binary interpreter's
complete simulation theorem is not supplied. The existing 253-state
machine and its upstream Coq verification remain prior work.

The later finite-sort audit defeats the intended reduced raw calculi
behind the 248/250/252 experiments. The report distinguishes that
abstract obstruction from an unprovided compiler theorem for each
literal table.

## Contents

| Path | Purpose |
|---|---|
| zfc_substitution_engine.pdf | Complete research report |
| report.tex, sections/ | Editable LaTeX sources |
| code/lazy_psc.py | Shared-template PSC certificate checker |
| code/certificate_codec.py | Total numerical coding and bounded diagnostic search |
| code/verify_artifacts.py | Focused tests, examples, and semantic/coding regressions |
| code/independent_review.py | Separately written direct PSC semantic comparison |
| code/diagonal_obstruction.py | Reproducible logical counterinterpretations |
| examples/ | Three accepted closed-theorem certificates and their targets |
| engineering/ | 268-state table, source DAGs, certificate, generators, pinned inputs |
| evidence/ | Test results, source inventory, upstream CI excerpt, PDF QA |
| STATUS.json | Machine-readable distinction between proved, tested, and pending claims |
| ARTIFACT_SHA256.json | Integrity manifest for the distributed contents |
| reproduce.py | One-command standard-library verification driver |
| Makefile | Verification and PDF rebuild commands |

## Reproduce the checks

Use Python 3.10 or newer. No third-party Python packages, Git checkout,
network, or theorem prover are required for the supplied executable
checks. From this directory:

    python3 -B reproduce.py

This runs the checker tests, the independent semantic comparison,
the diagonal-obstruction regression, and independent engineering
verification. It stops on any failure and records evidence/reproduction.json.
It does not run the optional large compiler searches.

Individual commands:

    python3 -B code/verify_artifacts.py
    python3 -B code/independent_review.py
    python3 -B code/diagonal_obstruction.py
    python3 -B engineering/verify.py
    python3 -B engineering/reproduce.py

The last command regenerates the selected 268-state recipe and compares
all six machine/DAG/certificate artifacts byte for byte.
See engineering/README.md for optional full-grid and PSC control searches.
Do not use Python's -O flag: finite verifiers use assertions.

To inspect a theorem example through the checker CLI:

    python3 -B code/lazy_psc.py examples/colliding_instantiation.json \
        --theorem examples/colliding_instantiation_theorem.json

The examples prove closed theorems; they are not inconsistency witnesses.
The consistency-search interface fixes its target to genuine Bottom.
For a deliberately bounded diagnostic:

    python3 -B code/certificate_codec.py --limit 10000

No acceptance in a finite prefix proves no consistency statement.
Recursion, memory, time, and other host-resource failures are never
interpreted as successful refutations. The unbounded search is the
mathematical specification in the report, not a claim about unlimited
physical Python execution.

## Rebuild the report

A normal TeX Live or comparable LaTeX installation with pdfLaTeX and
the standard packages listed in report.tex is sufficient.

    make pdf

This runs pdfLaTeX three times, puts intermediate files under build/,
and copies the finished PDF to zfc_substitution_engine.pdf.
There are no network-dependent bibliography downloads, figures, or fonts.

## Provenance and attribution

The source cutoff, requested commits, upstream 254 and 253 pins, incoming
archive hashes, and relevant source-file hashes appear in
evidence/source-manifest.json. Original PSC calibration, the prior
environment-tableau design, Re-Pair, and register-certificate architecture
are explicitly credited in the report.

The new contributions are the implemented shared-template/dynamic-AX
checker and its proofs, the stronger logical-fragment obstruction, and
the measured full-logic conjunction layout producing the 268-state
control. See NOTICE.txt and engineering/NOTICE.txt for preserved
upstream notices and exact licensing boundaries.
