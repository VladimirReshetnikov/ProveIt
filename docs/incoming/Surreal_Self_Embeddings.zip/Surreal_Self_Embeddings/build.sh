#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 verification.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
