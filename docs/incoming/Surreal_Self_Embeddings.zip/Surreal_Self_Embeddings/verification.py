#!/usr/bin/env python3
"""Exact finite checks accompanying Self-Embeddings of the Surreal Numbers.

Python 3.10+, standard library only. These tests are NOT a construction of No
and do NOT verify transfinite summability, class recursion, or analytic limits.
Finite nested Hahn polynomials test the formulas for the two-level lift.
"""
from __future__ import annotations

from collections import Counter
from fractions import Fraction as Q
from functools import cmp_to_key
from itertools import product
from pathlib import Path
import json
import random

SEED = 20261003
COUNTS: Counter[str] = Counter()
RNG = random.Random(SEED)
Sign = tuple[int, ...]
# An exponent is itself a finite Hahn polynomial over rational exponents.
Exponent = tuple[tuple[Q, Q], ...]
Series = dict[Exponent, Q]


def check(group: str, statement: bool) -> None:
    if not statement:
        raise AssertionError(f"Failed check in {group}")
    COUNTS[group] += 1


def sign_cmp(a: Sign, b: Sign) -> int:
    for i in range(max(len(a), len(b))):
        x = a[i] if i < len(a) else 0
        y = b[i] if i < len(b) else 0
        if x != y:
            return (x > y) - (x < y)
    return 0


def prefix(a: Sign, b: Sign) -> bool:
    return len(a) <= len(b) and b[:len(a)] == a


def meet(a: Sign, b: Sign) -> Sign:
    n = 0
    while n < min(len(a), len(b)) and a[n] == b[n]:
        n += 1
    return a[:n]


def sign_tests() -> None:
    words = [tuple(w) for n in range(6) for w in product((-1, 1), repeat=n)]
    maps = [
        ("prefix", lambda w: (1, -1) + w),
        ("repeat_2", lambda w: tuple(s for s in w for _ in range(2))),
        ("repeat_3", lambda w: tuple(s for s in w for _ in range(3))),
    ]
    # A nonconstant finite instance of the local-padding construction.
    tree: dict[Sign, Sign] = {(): (-1, 1)}
    for w in sorted(words, key=len):
        if w:
            par, s = w[:-1], w[-1]
            extra = (1, -1) if sum(w) % 3 == 0 else ()
            tree[w] = tree[par] + (s,) + extra
    maps.append(("local_padding", lambda w: tree[w]))
    for name, f in maps:
        for a, b in product(words, repeat=2):
            check(f"sign_{name}_order", sign_cmp(a, b) == sign_cmp(f(a), f(b)))
            check(f"sign_{name}_prefix", prefix(a, b) == prefix(f(a), f(b)))
            check(f"sign_{name}_meet", f(meet(a, b)) == meet(f(a), f(b)))
    # Canonical options characterize the prefix cone, in these finite cases.
    for s, y in product(words, repeat=2):
        left = [s[:i] for i, digit in enumerate(s) if digit == 1]
        right = [s[:i] for i, digit in enumerate(s) if digit == -1]
        separates = all(sign_cmp(x, y) < 0 for x in left) and all(
            sign_cmp(y, x) < 0 for x in right
        )
        check("canonical_cone", separates == prefix(s, y))


def norm_exp(d: dict[Q, Q]) -> Exponent:
    return tuple(sorted((Q(a), Q(r)) for a, r in d.items() if r))


def exp_add(a: Exponent, b: Exponent) -> Exponent:
    d = dict(a)
    for k, r in b:
        d[k] = d.get(k, Q(0)) + r
    return norm_exp(d)


def exp_neg(a: Exponent) -> Exponent:
    return tuple((k, -r) for k, r in a)


def exp_cmp(a: Exponent, b: Exponent) -> int:
    difference = exp_add(a, exp_neg(b))
    return 0 if not difference else (1 if difference[-1][1] > 0 else -1)


def additive_lift(a: Exponent, f) -> Exponent:
    # Keeping aggregation makes the implementation well-defined even when a
    # caller supplies a noninjective map; tests below use increasing maps.
    d: dict[Q, Q] = {}
    for k, r in a:
        t = Q(f(k))
        d[t] = d.get(t, Q(0)) + r
    return norm_exp(d)


def norm_series(d: Series) -> Series:
    return {a: Q(r) for a, r in d.items() if r}


def series_add(x: Series, y: Series) -> Series:
    z = dict(x)
    for a, r in y.items():
        z[a] = z.get(a, Q(0)) + r
    return norm_series(z)


def series_neg(x: Series) -> Series:
    return {a: -r for a, r in x.items()}


def series_mul(x: Series, y: Series) -> Series:
    z: Series = {}
    for a, r in x.items():
        for b, s in y.items():
            c = exp_add(a, b)
            z[c] = z.get(c, Q(0)) + r * s
    return norm_series(z)


def series_cmp(x: Series, y: Series) -> int:
    z = series_add(x, series_neg(y))
    if not z:
        return 0
    lead = max(z, key=cmp_to_key(exp_cmp))
    return 1 if z[lead] > 0 else -1


def double_lift(x: Series, f) -> Series:
    z: Series = {}
    for a, r in x.items():
        b = additive_lift(a, f)
        z[b] = z.get(b, Q(0)) + r
    return norm_series(z)


def rand_q() -> Q:
    return Q(RNG.randint(-5, 5), RNG.randint(1, 4))


def rand_exp() -> Exponent:
    d: dict[Q, Q] = {}
    for _ in range(RNG.randint(0, 4)):
        a, r = rand_q(), rand_q()
        d[a] = d.get(a, Q(0)) + r
    return norm_exp(d)


def rand_series() -> Series:
    d: Series = {}
    for _ in range(RNG.randint(0, 4)):
        a, r = rand_exp(), rand_q()
        d[a] = d.get(a, Q(0)) + r
    return norm_series(d)


def compress_negative(a: Q) -> Q:
    return a / (1 - a) if a < 0 else a


def bounded_map(a: Q) -> Q:
    return -2 + a / (2 * (1 + abs(a)))


def rational_map_tests() -> None:
    grid = sorted({Q(i, j) for i in range(-9, 10) for j in range(1, 5)})
    for f in (compress_negative, bounded_map, lambda a: a + 1, lambda a: 2 * a):
        for a, b in zip(grid, grid[1:]):
            check("rational_order_maps", f(a) < f(b))
    for a in grid:
        check("bounded_interval", Q(-5, 2) < bounded_map(a) < Q(-3, 2))
        check("halfline_interval", compress_negative(a) > -1)
        if a >= 0:
            check("nonnegative_fixed", compress_negative(a) == a)
    # On monomials, a one-level reindexing is multiplicative only if its
    # exponent map is additive. This is an explicit exact counterexample.
    check("nonmultiplicativity_witness", compress_negative(Q(-2)) == Q(-2, 3))
    check("nonmultiplicativity_witness", 2 * compress_negative(Q(-1)) == -1)
    check("nonmultiplicativity_witness", compress_negative(Q(-2)) !=
          2 * compress_negative(Q(-1)))


def hahn_tests() -> None:
    maps = [compress_negative, bounded_map, lambda a: a + 1, lambda a: 2 * a]
    one: Series = {(): Q(1)}
    for _ in range(200):
        x, y = rand_series(), rand_series()
        a, b = rand_exp(), rand_exp()
        for f in maps:
            check("first_lift_addition", additive_lift(exp_add(a, b), f) ==
                  exp_add(additive_lift(a, f), additive_lift(b, f)))
            check("first_lift_order", exp_cmp(a, b) ==
                  exp_cmp(additive_lift(a, f), additive_lift(b, f)))
            check("double_lift_addition", double_lift(series_add(x, y), f) ==
                  series_add(double_lift(x, f), double_lift(y, f)))
            check("double_lift_multiplication", double_lift(series_mul(x, y), f) ==
                  series_mul(double_lift(x, f), double_lift(y, f)))
            check("double_lift_order", series_cmp(x, y) ==
                  series_cmp(double_lift(x, f), double_lift(y, f)))
            check("double_lift_unit", double_lift(one, f) == one)
            check("monomial_inverse", series_mul(double_lift({a: Q(1)}, f),
                  double_lift({exp_neg(a): Q(1)}, f)) == one)
        f, g = maps[RNG.randrange(len(maps))], maps[RNG.randrange(len(maps))]
        check("lift_composition", double_lift(double_lift(x, g), f) ==
              double_lift(x, lambda t: f(g(t))))
        check("identity_lift", double_lift(x, lambda t: t) == x)
        # Preserve finite summation with cancellations, not just disjoint support.
        z = rand_series()
        family_sum = series_add(series_add(x, y), z)
        check("finite_family_sum", double_lift(family_sum, f) == series_add(
            series_add(double_lift(x, f), double_lift(y, f)), double_lift(z, f)))
    # Exact moved-element and missing-exponent calculation at the inner level.
    check("ordinal_fix_example", additive_lift(((Q(-1), Q(1)),),
          compress_negative) == ((Q(-1, 2), Q(1)),))


def displacement_tests() -> None:
    for _ in range(1000):
        sa, sb, ta, tb = [rand_q() for _ in range(4)]
        lhs = sa * sb - ta * tb
        rhs = sa * (sb - tb) + tb * (sa - ta)
        check("two_map_displacement", lhs == rhs)
        # Conditional witness identity, with exact arbitrary values of D(b).
        d = rand_q()
        if d == 0:
            d = Q(1)
        bound = abs(rand_q()) + 1
        probe = 2 * bound * (1 + abs(sa)) / abs(d)
        db = rand_q()
        dab = sa * db + probe * d
        check("two_probe_amplification", max(abs(db), abs(dab)) > bound)


def derivative_exponent_tests() -> None:
    # Only rational inequalities used by the proof; this does not certify a
    # limit over all surreal exponents or all surreal inputs.
    for _ in range(1000):
        q = Q(RNG.randint(2, 12), RNG.randint(1, 12))
        if q == 1:
            continue
        c = rand_q()
        if q > 1:
            b = min(Q(-1), (c - 1) / (q - 1))
            a = b - abs(rand_q())
            check("derivative_q_gt_1", (q - 1) * a <= (q - 1) * b < c)
        else:
            b = min(Q(-1), (c + 1) / (q - 1))
            a = b - abs(rand_q())
            check("derivative_q_lt_1", (q - 1) * a >= (q - 1) * b > c)


def main() -> None:
    sign_tests()
    rational_map_tests()
    hahn_tests()
    displacement_tests()
    derivative_exponent_tests()
    report = {
        "title": "Exact finite checks for surreal self-embedding formulas",
        "seed": SEED,
        "arithmetic": "fractions.Fraction; Python standard library only",
        "all_passed": True,
        "total_assertions": sum(COUNTS.values()),
        "assertions_by_group": dict(sorted(COUNTS.items())),
        "scope": [
            "Finite sign strings of lengths zero through five.",
            "Finite two-level Hahn polynomials with rational coefficients.",
            "Exact displacement identities and rational exponent inequalities.",
            "Not a proof-assistant certificate or a model of all surreal numbers.",
            "No tests certify infinite supports, class recursion, or analytic limits.",
        ],
        "one_level_counterexample": {
            "f(-2)": "-2/3", "f(-1)+f(-1)": "-1",
            "conclusion": "Order reindexing is not automatically multiplicative."
        },
    }
    output = Path(__file__).resolve().with_name("verification.json")
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: {report['total_assertions']:,} exact finite assertions")
    print(f"Wrote {output.name}")


if __name__ == "__main__":
    main()
