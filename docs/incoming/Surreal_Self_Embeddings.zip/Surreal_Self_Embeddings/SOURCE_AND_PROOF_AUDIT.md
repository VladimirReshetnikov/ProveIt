# Source and proof audit

Article: **Self-Embeddings of the Surreal Numbers**  
Date: 3 October 2026.

## 1. Repository access and pin

The GitHub connector returned the repository snapshot
`20aafb9a524196eed950f47134f09bc1b4671bc3` for
`VladimirReshetnikov/ProveIt`. Targeted reads were then pinned to it.
The very large recursive-tree result was not a complete content audit.
No repository files were changed, and no commit or pull request was created.

The substantive repository materials consulted were:

1. `Algebra/SurrealNumbers/docs/surreal/exponential-automorphism-rigidity/README.md`.
   Its dependency and verification discussion was used to distinguish generic
   algebraic Lean results from pending instantiations on the actual surreal
   exponential and natural valuation.
2. The opening portion of
   `Algebra/SurrealNumbers/Surreal/Algebra/ExponentialProfile.lean`
   (requested lines 1–230, including substantial source comments and the
   displayed displacement proof). The returned response was large; this was
   not a full independent audit of every declaration in the file.
3. `Algebra/SurrealNumbers/docs/surreal/omnific-preserving-automorphisms/README.md`
   and the complete targeted audit
   `13-omnific-isomorphisms-SOURCE_AUDIT.md` in the same directory.
   These establish prior repository work on fraction fields and proper pair
   embeddings; the full 221-page assembled report was not newly read.
4. Search excerpts for `SignSequenceSimplicity.lean` and
   `SignSequenceCutOperation.lean`, specifically the distinction between
   simplest-separator uniqueness with an existence premise and separate
   small-cut filling.

Direct network access from the working container was unavailable. There was
no successful clone, repository-wide proof build, or independent execution of
its Lean proofs. The article makes no such claim.

## 2. External primary references

The article's bibliography provides persistent links and version information.
The following describes actual consultation rather than asserting complete
cover-to-cover reading.

- **Kaplan–Krapp–Serra, arXiv:2509.22374v3.** The arXiv record displayed v3,
  revised 23 April 2026, as its latest version. The PDF's printed pages 4 and 10
  were visually inspected. They contain the valuation/leading-term conventions
  and the exponential and omega-field questions used in the article. A different
  date in experimental HTML was not treated as an additional arXiv revision.
- **Bagayoko–van der Hoeven, Surreal substructures.** The primary publication
  record and preprint were consulted for the doubly ordered structure,
  sign-based constructions, and the established surrounding theory.
- **Ehrlich–Kaplan, arXiv:2002.07739v3.** The primary PDF was consulted; printed
  page 2 was visually inspected. Proposition 1.5 explicitly records that the
  surreal exponential field is an elementary extension of the real exponential
  field. This is a background input, not a source for every new construction
  in the delivered article.
- **Kuhlmann–Serra, arXiv:2107.03362v3.** The primary record and abstract were
  checked for the strong Hahn-automorphism setting and bibliographic metadata.
  Our restricted embedding formula is proved in the article.
- **Aschenbrenner–van den Dries–van der Hoeven, arXiv:1512.02267v3.** The primary
  PDF was consulted and its first page visually inspected. Its introduction
  states the constant-field property of the Berarducci–Mantova derivation used
  by the differential discussion.
- **Bagayoko, arXiv:2409.16251.** The primary abstract was used only for the
  scoped discussion of embeddings of specified hyperseries subfields, not to
  assert a global substitution operator on all of No.
- **Coste, An Introduction to O-minimal Geometry.** The institutional catalogue
  was located; attempts to fetch the institutional full text were blocked.
  It is a standard background reference, not a newly audited proof source.
  The article states the o-minimal differentiability, mean-value, Skolem, and
  exchange inputs explicitly.
- **Hamkins, research exposition on transfinite recursion (23 July 2017).**
  Used for the distinction between ordinary set-valued recursion and stronger
  class-recursion/truth principles.
- **Conway and Gonshor.** Standard background books are cited for the classical
  surreal construction and normal forms. They were not newly read in full.

Some targeted searches returned irrelevant material. These results are not
evidence that a mathematical statement has no antecedent. No exhaustive
priority search or certification of the current status of every related open
problem was performed.

## 3. Mathematical proof scope

### Explicit or elementary arguments in the article

The local padding, birthday rigidity, two-level lift, explicit field copies,
topology dichotomy, dilation derivatives, cofinal bounded-difference lemma,
weighted-sector classification, and fixed-field arguments have written proofs.
They are not designated machine-checked proofs.

The Hahn arguments use the standard set-support convolution lemma and the
class-replacement principle for images and inverse images of set supports.
They do not use formal sums indexed by a proper class.

### Results already present in the repository

The one-map bounded-displacement engine and exponential pointwise-valuation
rigidity are attributed to the repository. The fraction-field identity for the
omnific integers is also credited. They are reproved for readability, not
announced as independent discoveries.

The two-map proof here replaces surjectivity of the comparison map by
cofinality of its image. This is a written strengthening; no revised Lean
implementation accompanies it.

### Model-theoretic construction

The omission construction is stated for an o-minimal expansion in a set-sized
language with explicit satisfaction and definable Skolem operations, together
with global choice. Set-sized cut filling supplies enough type realizations;
exchange keeps a chosen point outside the range. Cofinality stages ensure a
cofinal proper image. GBC plus elementary transfinite recursion is offered as
a sufficient framework, not asserted to be necessary or optimal.

Its exponential specialization uses the classical elementary-extension theorem
for the canonical surreal exponential. The construction does not establish
strong Hahn additivity, simplicity preservation, omega compatibility, or
compatibility with a distinguished derivation.

## 4. Finite computation

`verification.py` uses only the Python standard library and exact Fraction
arithmetic. The fixed seed is 20261003. The recorded run passed 61,042 assertions.

It tests all pairs of finite sign strings of length at most five for several
prefix and padding constructions; it also tests the finite canonical-cone
criterion. Nested Hahn polynomials use rational coefficients and rational
inner exponents. Their finite supports make addition and convolution exact.
Composition, order, units, monomial inverses, and a finite-family sum are tested.
The one-level nonmultiplicativity witness and the two-map displacement
identity are explicit. Rational exponent inequalities test the arithmetic
shape of the dilation-limit argument, not the limit itself.

No finite check proves an assertion about all ordinals, all surreal supports,
all class maps, or all small neighborhoods. There is no Lean certificate.

## 5. Presentation check

The LaTeX document compiled successfully with cross-references resolved and
without overfull boxes. All PDF pages were rendered. Contact sheets and
selected full-resolution pages were inspected, including the title, contents,
main theorem sections, and references. A text-span check found no text outside
the chosen safe page rectangle. These are presentation checks, not an
independent mathematical referee report.

The supplied checksums identify the delivered files. No font files, external
source PDFs, repository binaries, or purported proof-assistant certificates are
included.
