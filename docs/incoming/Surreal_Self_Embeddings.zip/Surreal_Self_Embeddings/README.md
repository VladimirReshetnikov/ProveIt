# Self-Embeddings of the Surreal Numbers

**Order, simplicity, field structure, exponential rigidity, and foundations**  
Prepared for Vladimir Reshetnikov, 3 October 2026.

The article is 30 pages, including its contents, proof-status ledger, and
bibliography. It studies proper embeddings as well as automorphisms; these
have materially different rigidity properties.

## Files

- `article.pdf`: the complete article.
- `article.tex`: standalone LaTeX source, with an internal bibliography.
- `verification.py`: exact finite tests, using Python's standard library.
- `verification.json`: the recorded deterministic test results.
- `SOURCE_AND_PROOF_AUDIT.md`: source scope, proof dependencies, and limits.
- `build.sh`: runs the tests and compiles the article three times.
- `build_report.json`: compilation, page-count, and checking record.
- `SHA256SUMS`: checksums of the delivered files other than this checksum file.

## Main mathematical developments

The sign-sequence sections characterize order-and-simplicity embeddings by
successor and limit padding, and prove rigidity under birthday nonincrease,
initiality of the image, or preservation of the ambient simplest-cut operation.

The two-level Hahn construction E_f = H_(A_f) transforms every order
self-embedding into a strongly real-linear field self-embedding. It preserves
composition and detects both surjectivity and cofinality. Explicit applications
include a bounded field copy and a cofinal proper copy fixing every real and
ordinal.

An ordered-field argument characterizes continuity of a field embedding by
cofinality of its range. Noncofinal ranges are uniformly discrete in the ambient
order topology. A separate calculation shows that positive surreal scalar dilations
of Conway exponents can be nonidentity field automorphisms with ordinary
derivative zero everywhere.

The exponential section credits and reproves the repository's pointwise
valuation-rigidity theorem, then proves a cofinal two-map comparison theorem.
The elementary-embedding construction has separate, explicit satisfaction,
Skolem, and o-minimal hypotheses. Ten further research questions conclude the
article.

## Build

Use Python 3.10 or later and a TeX Live installation containing the packages
listed in `article.tex`. No Python packages need to be installed.

```sh
bash build.sh
```

Equivalently, run `python3 verification.py`, followed by three invocations of
`pdflatex -interaction=nonstopmode -halt-on-error article.tex`.

The test output is deterministic for its recorded seed. The PDF is not promised
to reproduce byte for byte on a different TeX installation or at another time;
PDF timestamps and font/package versions may change its checksum.

## Verification and research status

The recorded run passed **61,042 exact finite assertions**. These test finite
sign strings, rational order maps, finite nested Hahn polynomials, convolution,
composition, and displacement identities. They do not certify transfinite
summability, class recursion, or a limit over all surreal inputs.

The article contains written proofs, not a new Lean or other proof-assistant
certificate. It is not independently refereed and makes no claim of historical
priority. Some results are classical or already in the repository and are
explicitly credited. The article is not a classification of every embedding
preserving every possible expansion of the surreal field.

Repository snapshot:
`20aafb9a524196eed950f47134f09bc1b4671bc3`.
