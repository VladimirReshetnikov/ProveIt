# An ADE Threshold for Matching-Support Stability

Research draft prepared for Vladimir Reshetnikov, 29 September 2026.

## Contents

- `article.pdf`: the compiled research article.
- `article.tex`: complete LaTeX source, including the bibliography and graph diagram.
- `code/verify.py`: exact finite regression checks; no network calls.
- `data/verification_results.json`: complete output of the delivered verification run.
- `requirements.txt`: versions of the two Python dependencies used.
- `SOURCE_AUDIT.md`: repository pin, prior-result boundary, and priority limitations.
- `SHA256SUMS.txt`: integrity hashes of the delivered files other than itself.

## Mathematical results

The central graph construction starts with a tree T. Its left vertices are V(T),
its right vertices are E(T) together with an apex, and the apex is adjacent to all
left vertices. The article proves that its signed matching-support polynomial is
real stable if and only if I - A(T)/2 is positive semidefinite, equivalently the
adjacency spectral radius of T is at most two. This connects the construction to
the classical finite and affine ADE tree list.

The proof gives an exact determinant-plus-adjugate coefficient identity and a
rational negative Rayleigh certificate for every excluded tree. It extends to
subdivisions between the original apex neighbors. Consequences include the sharp
four-page book threshold, all-real univariate book polynomials for every number
of pages, positive uniform-basis covariance 1/576 at five pages, and a complete
stability classification for simple bipartite multi-theta graphs. The even-path
part uses a separate independent-column expected-determinant proof.

## Status

This is an AI-assisted, unrefereed mathematical research draft. The all-size
claims rest on the written proofs, not on the finite computations. No Lean or
Rocq verification is included or claimed. Worldwide novelty/priority has not
been certified. The ADE classification and the earlier Theta(3,3,3) obstruction
are explicitly credited; the article does not claim a global classification for
all bipartite graphs or a resolution of the flag-polytope question.

## Reproduce the finite checks

With Python >=3.11 (the delivered run used 3.13.5):

```sh
python -m pip install -r requirements.txt
python code/verify.py
```

The default run writes `data/verification_results.json`. It checks all 95
unlabeled trees through nine vertices; 190 weighted determinant identities;
462 small-tree apex coefficients; books with zero through eight pages; 507 exact
expected squared minors for three even multi-theta examples; four exact
contraction/deletion comparisons of basis sets; and six terminal-subdivision
identity evaluations. It also checks the discriminants and rational obstruction
specified in the article. The support dynamic program removes matching
multiplicities explicitly.

Optional:

```sh
python code/verify.py --max-tree-size 8 --output /tmp/ade-checks.json
```

Finite checks do not establish any all-size theorem by themselves. Weighted
polynomial evaluations are regression checks, not complete polynomial-identity
certificates. The manuscript's coefficient proof supplies the general identity.

## Rebuild the PDF

A standard TeX Live installation with pdfLaTeX and the packages named in the
preamble suffices. No external figure assets are needed.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

An additional pass is harmless if cross-reference or contents warnings remain.
No font files or third-party paper PDFs are distributed.
