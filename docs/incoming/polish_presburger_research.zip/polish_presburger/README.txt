CONTINUOUS PRESBURGER ARITHMETIC ON POLISH SPACES
An affirmative construction for Glazer's question,
Baire-space models, and omnific realizations

Research report prepared for Vladimir Reshetnikov
October 4, 2026

CONTENTS

  polish_presburger.pdf   Complete article, with proofs and references.
  polish_presburger.tex   Self-contained LaTeX source for the article.
  README.txt             This file.

MAIN FINDING

The positive cone of the lexicographically ordered group R x Z,

  M = ((0, infinity) x Z) union ({0} x N),

with the topology inherited from usual R times discrete Z, is an
uncountable Polish model of the full first-order theory of natural-number
addition, and its coordinatewise addition is jointly continuous. This
answers Question 2 as stated in Elliot Glazer's November 2023 paper
"A Topological Tennenbaum Theorem", arXiv:2311.13699, affirmatively.

The article also develops a general Borel-cone realization theorem,
ordinal-indexed Baire-space models, exactly continuum many isomorphism
types with continuous addition on Baire space, unbounded countable
boundary oscillation ranks for one order formula, explicit omnific
embeddings, and algebraic and topological obstructions. It includes a
research agenda and a source-level audit of the ProveIt formalization
boundary.

REBUILDING

Use a TeX distribution with pdfLaTeX and the standard packages listed
in the source. From the directory containing the source, run:

  latexmk -pdf -interaction=nonstopmode -halt-on-error polish_presburger.tex

Alternatively, run pdfLaTeX repeatedly until references and the table
of contents stabilize. The bibliography and TikZ figure are contained
in the TeX file; no separate .bib file, image assets, or shell escape
are required.

SOURCE SNAPSHOT

The ProveIt repository was inspected read-only at commit:

  0f95145cb65d5dc279e2053e8707a71bb490bb59

  https://github.com/VladimirReshetnikov/ProveIt

The article identifies exact source paths and distinguishes existing
integer decision procedures from the model-general and topological
formalizations that remain to be done.

RESEARCH STATUS

The article contains mathematical proofs, including separate checks
of their main constructions. It is not externally refereed and supplies
no new Lean or Rocq certificates. The source audit and targeted literature
search do not establish historical priority. In particular, the precise
claim is an affirmative answer to the question printed in the identified
2023 paper, not a claim that no intervening author has obtained it.
Classical model-theoretic and descriptive-set-theoretic inputs are cited.

Glazer's separate Question 1 concerning ATR_0 is not resolved here.

The compiled PDF was checked for unresolved references and layout warnings
and was visually inspected. Those document checks do not certify the
mathematics.
