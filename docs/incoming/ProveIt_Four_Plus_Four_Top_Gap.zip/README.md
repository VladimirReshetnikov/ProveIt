# The Top Conditional Gap for Four Plus Four Covers

The six-page report proves a graph-generic coefficientwise rank-four upper incidence inequality and a coupled unit correction. The latter gives the strict top conditional factor 16/7 for every genuine 4+4 minimum cover, with unit left activities and arbitrary positive right activities. An explicit six-vector real example shows that the unrestricted upper-incidence inequality fails.

Combined with the preceding 5+3 report, only the 4+4 middle conditional factor 7/4 and its possible equality cases remain in the eventual rank-eight problem. This package does not claim a full rank-eight eventual theorem or a general finite-activity theorem.

Contents:
- Top_Conditional_Gap_for_Four_Plus_Four_Covers.pdf: final report
- article.tex and build_local.sh: editable source and local build helper
- code/primary/: original exact finite-profile checkers and their deterministic certificates
- code/independent/: separately implemented coordinate-injection and signed-permutation replays
- data/: independent replay summaries
- companion/: unchanged 5+3 PDF and complete source archive, including earlier prerequisites
- manifest.json: SHA256 checksums

Run every primary and independent check using only Python 3's standard library:

    python -O code/replay_all.py

The complete run takes roughly one minute on the development environment. All mathematical checks use explicit exceptions and remain active under optimization. The primary scripts deterministically regenerate their JSON certificates; the independent replays compare every profile hash. To refresh the independent output summaries as well, add --save-certificate.

The finite tables cover all relevant support profiles, rather than a bounded population grid. The five-label integer matrix provides exact nonvanishing witnesses after a proved uniformity reduction. The independent replay also checks the universal single-minor symbolic expansion.

To rebuild the PDF with the indicated standard TeX packages available:

    bash build_local.sh
