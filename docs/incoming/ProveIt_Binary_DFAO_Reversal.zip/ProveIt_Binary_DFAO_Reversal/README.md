# Binary DFAO Reversal
## Exact Three-Output Complexity, Odd-Output Rigidity, and Sharp Deficit Asymptotics

Prepared for Vladimir Reshetnikov, 28 September 2026.

An AI-assisted research continuation of ProveIt's
`dfao-reversal-coloring-obstruction` report. The manuscript contains full new
upper-bound proofs and imports the established Davies/Holzer–König lower
witness construction with explicit attribution.

## Main results

Let B_k(n) be maximal reversal complexity for an accessible minimal n-state
DFAO with k outputs and two input letters, and D_k(n) = k^n - B_k(n).

For every n >= 7, the manuscript proves

    B_3(n) = 3^n - 3 (2^a + 2^b - 2) + b,

where (a,b) is the closest coprime split of n:

    n odd:       ((n-1)/2, (n+1)/2)
    n = 0 mod 4: (n/2-1, n/2+1)
    n = 2 mod 4: (n/2-2, n/2+2).

The infinite argument is analytic for n >= 32. The range 7 <= n <= 31 uses
3,717 exhaustive structural inequalities, independently reconstructed by a
second implementation. These are not sampled automata.

For every fixed k >= 3, the exponential rate of D_k(n) is
sqrt(floor(k^2/4)); the article gives the leading constants as well. For fixed
odd k, the nearest coprime construction is eventually exactly optimal. For
fixed even k, a nontrivial interval of cycle proportions is asymptotically
optimal to first order. Exact optimizer structure for k=3 and near-optimal
rigidity for arbitrary fixed k are also proved.

The article includes nine proposed further research questions, their relation
to the results, and suggested approaches.

## Status and scope

This is an unrefereed research manuscript, not an externally certified
breakthrough or a claim of worldwide publication priority. No new theorem
has been checked in Lean or another proof assistant. The finite calculations
were executed and reimplemented during the same investigation; independent
implementation does not mean independent authorship or external review.

No claim is made to solve the all-n, all-k exact optimality problem. For odd
k >= 5, the existence of a cutoff is proved but no numerical cutoff is supplied.
The asymptotic results keep k fixed and are not uniform in k growing with n.
See `STATUS.md` and the article for the dependency boundary.

## Files

- `article.tex`, `article.pdf`: complete editable source and compiled article.
- `code/verify.py`: producer and exact finite inequality verifier; also four BFS
  sanity checks for the three-output witness.
- `code/independent_check.py`: no producer imports; different order recurrence,
  inclusion-exclusion coloring counts, and an independently optimized split.
- `results/finite_certificate.json`: every candidate, not just the minima.
- `results/finite_table.tex`: the table included by the article source.
- `results/bfs_checks.json`: explicit generators, outputs, and computed counts.
- `results/*summary.json`, `results/*console.txt`: recorded executions and audits.
- `SOURCES.md`, `STATUS.md`, `Makefile`: provenance, scope, and rebuild commands.

## Reproduce

Python 3.10 or later, standard library only:

    python code/verify.py
    python code/independent_check.py

The programs use explicit error checks, so `python -O` does not disable them.
The default certificate range is exactly 7 through 31. The producer also
supports exploratory `--max-n` values through 45 and `--bfs-max-n` through 12,
but larger explorations are not needed for the proof and change output files.

Build with a standard TeX Live or MiKTeX installation:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

The bibliography is embedded; no BibTeX process, online fetch, or external
font file is required. Keep `results/finite_table.tex` in the displayed
relative location. A POSIX `make check` / `make pdf` alternative is included.

## Expected default results

    25 state sizes; 3,717 structural candidates; PASS
    Independent reconstruction: 25 state sizes; 3,717 candidates; PASS
    12 independent direct coloring checks; PASS
    Cutoff n=32, even-class rational margin: 2702601/64 > 0
    BFS n=7: 2125; n=8: 6452; n=9: 19550; n=10: 58654

The PDF was compiled without unresolved references or overfull boxes and
rendered for visual inspection. Typesetting checks are separate from the
mathematical and arithmetic verification.
