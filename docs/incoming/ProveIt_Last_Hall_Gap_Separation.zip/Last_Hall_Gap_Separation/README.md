# The Last Hall Gap Does Not Control Ultra Log Concavity

This separate companion gives a rank-49 full Hall graph with a common right-core activity whose last gap is always positive while the preceding gap fails. It does not modify the sharp rank-38 endpoint report or settle the first failure among earlier gaps.

- `article.tex` and `article.pdf`: complete proof and rendered report
- `verify_counterexample.py`: exact standard-library verifier
- `data/verification.json`: coefficients, witness and threshold data
- `build_local.sh`: local TeX build setup
- `SHA256SUMS`: package hashes

Run `python verify_counterexample.py` with Python 3.10 or later. No external dependencies or network access are needed. Rebuild using two passes of `pdflatex article.tex`, or use the supplied local build script.

The proof has been checked independently in ordinary mathematics. No formal proof-assistant verification or global literature-priority claim is made.
