# Toward a sub-254-state ZFC-consistency machine

Research report prepared for Vladimir Reshetnikov, 16 October 2026.

**Read `article/report.pdf` for the complete report. Its source is
`article/report.tex`; the bibliography is embedded in that TeX file.**

## Main results

1. **A shorter calibrated closure presentation.** Extensionality plus
   point-seeded bounded-image closure needs only the local subset bound
   `y ⊆ b`. The membership arm `y ∈ b` of the earlier mixed bound can be
   removed. An explicit empty/singleton/nonsingleton relation constructs
   transitive containers and recovers every mixed-bound instance. This
   resolves the precise open question in the supplied base article.
2. **More freedom for initialization.** The existing proof enumerator is
   complete from every finite candidate cutoff and arbitrary retained
   data. Soundness additionally requires theorem-valued current/cache/stack
   data. The physical tape still must represent an admissible boundary.
3. **A checked decoder experiment.** A 203-node register-program DAG becomes
   202 nodes. Its 2,985-pair finite bisimulation certificate checks both
   directions for every initial register file. The literal emission has
   267 states and becomes 256 after eleven checked contextual folds.
4. **Two useful obstructions.** Pure logical equality vacuity cannot simply
   be dropped, and deleting transitivity from CP admits a ZFC-constructible
   set model even with full GIC and irreflexivity.

**No new sub-254-state blank-tape machine is claimed.** The 252-state
machine in the archive requires an explicitly prepared tape. The new
256-state blank-tape table is an experimental implementation, with Python
symbolic checks using the unchanged published register-box contracts.
No new Lean/Coq kernel proof or serialized ZFC proof is supplied.

## Package contents

| Path | Contents |
|---|---|
| `article/` | Complete TeX source and compiled PDF |
| `decoder/` | Baseline and candidate register-program DAGs; finite certificate; independent checker; deterministic search scripts |
| `machine/` | Literal 254, prepared-252, 267, and 256-state tables; symbolic audit; blank-boot target; fold/rebuild data |
| `code/` | Exact arithmetic, finite logical countermodel, HF container regression, and template measurement scripts |
| `data/` | Commit/source provenance, source snapshot audit, unchanged source-02 formula module |
| `results/` | Executed arithmetic, model, formula-size, and integrated verification records |
| `notes/` | Detailed supplementary theory proofs and research findings |
| `STATUS.json` | Explicit proved/checked/uncompleted status ledger |
| `SHA256SUMS` | Integrity manifest for the archive contents |

The table terminal label remains `254` even in variants with a different
number of working states. State labels need not be consecutive. Count the
distinct nonhalting states with two transition rows each, not the maximum
label. The machine checker verifies this convention and target closure.

## Reproduce the supplied checks

Use Python 3.10 or later, without `-O`. Only the standard library is needed.
From this directory:

```sh
python3 verify.py
```

This verifies the integrity manifest when present, reruns the exact
arithmetic and HF regressions, repeats the finite vacuity countermodel,
recomputes the source's formula measurements, independently checks the
register-program bisimulation, and audits all four literal tables. Each
machine has 8,391 affine instruction cases; the three blank-tape machines
also execute 264,982 steps to the exact specified final initialization
configuration. The symbolic
machine audit uses the published register-box contracts as stated in
`machine/README.md`; it is not a replacement proof of those contracts.

Individual commands are:

```sh
python3 code/tail_padding.py
python3 code/seeded_subset_kernel.py
python3 code/check_vacuity_countermodel.py
python3 code/measure_point_subset_bic.py data/source02_formulas.py
python3 decoder/verify.py
python3 machine/verify.py
```

To regenerate the literal variants, including sequential verification of
all eleven folds:

```sh
python3 machine/build_variants.py
```

The optional searches in `decoder/search/` and `machine/search/` have their
own instructions and may take longer. Their negative results are bounded
search outcomes, not lower bounds or impossibility proofs. Rechecking the
frozen supplied artifacts does not require a network connection or the
full upstream proof-assistant development.

## Rebuild the PDF

A normal TeX installation with `pdflatex` and the standard packages named
in the preamble is sufficient. Run:

```sh
python3 build.py
```

Alternatively, run `latexmk -pdf report.tex` from `article/`. The report
contains its bibliography directly; BibTeX is unnecessary. A rebuilt PDF
can have a different digest because TeX records build metadata. Rebuilding
does not update the supplied original integrity manifest.

## Source pins and attribution

The first of the four supplied commit entries was repeated. The three
distinct ProveIt commits audited are:

- `b07d1a27bbe2814f2fd84cc55feef71c4de5b2db`
- `83ef1da6b717338f710277c2744fb4ec644cedbc`
- `67086c8d8802ea7b3625a2fc0765d39e2181e335`

The imported benchmark is pinned to
`jeff87654/busy-beaver@297ab8df7e5de329605c3875b4934643b371a5e3`.
Mira-Cult designed the 254-state machine; Jeff supplied its formal
verification. The ProveIt closure reports and their formula-measurement
module are prior work, not new results of this report. Greg Oman's
pseudo-hereditary construction supplies the background for the CP′ model.

The archive does not relicense any upstream material. The two unchanged
upstream Python model files in `machine/vendor/`, the baseline table, and
the source-derived program data retain their existing attribution and
ownership. The full imported proof development is not bundled. Exact
paths, pins, and hashes are in the provenance files and report bibliography.

The source snapshot audit matched 111 materialized upstream files; it is
not a claim to have materialized or rebuilt every one of the 202 imported
files. All new mathematical arguments are ordinary proofs. Finite tests,
universal symbolic hypotheses, and uncompleted formalization are expressly
distinguished in the report and status ledger.
