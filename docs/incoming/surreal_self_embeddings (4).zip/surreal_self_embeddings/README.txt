SELF-EMBEDDINGS OF THE SURREAL NUMBERS
Order, simplicity, normal forms, analytic structure, and foundations without paradoxes

Prepared for Vladimir Reshetnikov, 3 October 2026.

CONTENTS
  surreal_self_embeddings.pdf  - The complete 42-page article.
  surreal_self_embeddings.tex  - Standalone LaTeX source, including bibliography.
  README.txt                   - This file and build instructions.

The article contains explicit constructions, proofs of its principal deductions,
18 further research questions, and 22 bibliography entries. It covers numerical
order, the sign-sequence tree, birthday rigidity, additive and field embeddings,
Hahn summability, real coefficients, omnific integers, valuation, topology, the
omega-map, exponential and differential constraints, elementary embeddings,
class foundations, universe changes, and formalization in Lean.

BUILD
Recommended: a current TeX Live or MiKTeX installation with latexmk.
From this directory run:

  latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_self_embeddings.tex

Alternatively, run pdflatex on the source repeatedly until references and the
table of contents stabilize (typically three runs). No BibTeX step, separate
bibliography database, network access, or external image files are needed.
The source uses standard LaTeX packages, including lmodern, geometry, microtype,
amsmath, amssymb, amsthm, mathtools, booktabs, longtable, array, enumitem, xcolor,
xurl, hyperref, fancyhdr, and needspace.

SOURCE AND STATUS
The ProveIt repository was inspected at the fixed commit:
  b0d4af4f30b24529fec877e2ad4a5952888146e9
  https://github.com/VladimirReshetnikov/ProveIt

The source audit identifies the particular repository reports and Lean files
consulted, records corrections to specific printed formulas or support claims,
and separates imported theorems, independently proved deductions, and research
questions. No repository files were modified. No fresh Lean build or new Lean
certification is claimed. A research question is a proposed direction, not a
claim that its status has been exhaustively settled across the literature.

The PDF was compiled with all references resolved and without TeX layout
warnings. Every rendered page was visually checked. The source is self-contained
so the mathematical text can be reviewed and revised independently of the PDF.
