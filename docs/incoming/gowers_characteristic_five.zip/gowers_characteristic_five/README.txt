SHARP CHARACTERISTIC-FIVE CUBE BOUNDS IN GOWERS'S FRAMEWORK
Optimal sixth-order correction, phase rigidity, and an eighth-order extremal term
Prepared for Vladimir Reshetnikov by ChatGPT, 6 October 2026.

START HERE
Read gowers_characteristic_five.pdf. The complete editable source is
gowers_characteristic_five.tex; its figures are included in figures/.

MAIN RESULTS
1. On every finite nontrivial abelian group of exponent 5, for real centered f,
   u = ||f||_(U^3), delta > 0, and u <= c delta:
   Q3(delta+f) <= delta^8 + 6 sqrt(2) delta^4 u^4
                  + (2^(3/4)/3) delta^2 u^6 + C u^8.
   The constants c,C are absolute. The sixth-order coefficient is sharp.
2. A sharp phase envelope and necessary Fourier amplitude/phase conditions.
3. On Z/5Z, the maximum has the additional term (20/9) u^8, with
   O_delta(u^10) remainder.
4. Indicator examples on growing F5-vector spaces attain the coefficients
   through u^8 as lower examples.

The universal eighth-order coefficient over all exponent-five dimensions
is NOT determined. No new global quantitative Szemeredi bound, new Lean
kernel certification, or bibliographic priority is claimed.

WHAT IS NEW RELATIVE TO THE EARLIER PROJECT REPORT
The earlier characteristic-five discussion proved the exponent 6 and
constructed the coefficient 2^(3/4)/3 as a lower bound. This report proves
the matching uniform upper bound, improves its remainder to O(u^8), gives
the sharp phase envelope, and determines 20/9 as the next coefficient on
the fixed five-point group. Background results and the previous lower
construction are credited and reproved where needed.

REPRODUCING
  make verify
  make pdf
The two verifiers use Python's standard library only. PDF compilation uses
pdflatex with standard TeX Live packages. The figures are prebuilt.
To regenerate the figures, install matplotlib and run make figures;
the high-precision computation uses the standard decimal module.

CONTENTS
  gowers_characteristic_five.tex / .pdf   Complete article
  code/verify_order5.py                  Exact five-point formulas and series
  code/verify_profiles.py                Exact/profile checks in F5 and F5^2
  code/make_figures.py                   Decimal calculations and plots
  figures/                              PDF and PNG figures
  data/                                 Certificates, run records, source manifest
  data/mathematical_review.txt           Record of independent AI-assisted review
  data/package_validation.json          Final document/build checks
  Makefile                              Reproduction commands

SOURCE SNAPSHOT
VladimirReshetnikov/ProveIt, Combinatorics/Ramsey
Commit 43306653afaaaaa0b58a7ca71e4067c245594867.
Exact inspected paths and blob hashes are in data/source_manifest.json.
The repository was read, not modified.

EVIDENCE
The article gives written proofs of the mathematical results. Computational
checks validate finite identities and sample inequalities; they do not
replace the general proofs. The independent review was AI-assisted and
should not be described as external peer review.
