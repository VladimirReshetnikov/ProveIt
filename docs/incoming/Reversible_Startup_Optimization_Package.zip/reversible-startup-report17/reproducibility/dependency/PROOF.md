# Audited prime-coded counter source

Complete source input and prime-macro proof, 2 October 2026. The reset-net report supplies the source table and bibliography.

## 3. Exact source TM to three registers

### 3.1 Conventions and table

Registers L,R,T are natural numbers. ADD r q increments r then goes to q. SUB r q z decrements r and goes to q if it is positive; otherwise leaves zero unchanged and goes to z. HALT has no instruction. `virtual3.txt` and `.json` contain every instruction literally, with aliases removed.

The scanned bit is in finite control. At a TM cut, T=0, and L,R store successive symbols strictly left/right of the head, least-significant bit nearest the head. Omitted high bits are blank 0. The TM starts at control A0. A one-instruction prologue

    init_clear_T: SUB T init_clear_T tm_A0_pop0

clears arbitrary initial T before entering the simulation. This takes T+1 virtual instructions. It makes the raw positive-integer interface total on its promised domain in Section 4.

For each defined TM instruction (q,s)->(w,D,q'), let X be the half tape in movement direction D and Y the other half. All labels below are distinct for the source instruction and parity branch. The generator expands exactly this finite graph; the exported files contain no schematic rows.

### 3.2 Pop and recover quotient

At `pop0`:

    pop0: SUB X pop1 back0
    pop1: SUB X pair back1
    pair: ADD T pop0

Starting at (X_0,T)=(2Q+r,0), each full loop consumes two from X and adds one to T. After k complete loops, X=2(Q-k)+r, T=k, while the other half is unchanged. For k<Q the next two decrements are enabled; at k=Q, the final failed test selects `back0` if r=0, or one successful decrement followed by a failed test selects `back1` if r=1. The rank Q-k decreases, so the loop terminates. The exit has X=0,T=Q, with r in control.

Each parity-specific `back` loop is

    back: SUB T back_add push
    back_add: ADD X back

After j successful transfers, X=j,T=Q-j. It terminates with X=Q,T=0. There have been 3Q+(1+r)+(2Q+1)=5Q+r+2 virtual instructions in the entire pop stage.

### 3.3 Double, recover, write

For the selected parity r:

    push: SUB Y twice1 restore
    twice1: ADD T twice2
    twice2: ADD T push
    restore: SUB T restore_add write
    restore_add: ADD Y restore

If the old other half is Y_0, the first loop has Y=Y_0-k,T=2k after k iterations and rank Y_0-k. It finishes at Y=0,T=2Y_0. The second loop transfers one T to Y per iteration, preserving Y+T=2Y_0 and decreasing T. It finishes at Y=2Y_0,T=0. If w=1, `write` is one ADD Y instruction; if w=0, its edge is linked directly to the next TM cut. The next control is (q',r).

This stage takes 7Y_0+2+w instructions. Thus the complete TM macro takes exactly

    C_virtual = 5Q+r+7Y_0+w+4,

and maps the cut to X=Q,Y=2Y_0+w,T=0, scanned bit r and state q'. This is precisely the TM transition for every natural Q,Y_0 and both bits r.

All 29 cases use this graph, with the source row determining only X,Y,w,q'. The two arithmetic loops are terminating; there are no possible premature halts inside them. J1 is linked to HALT and has no simulation row. Induction gives exact simulation for every finite prefix and halting equivalence for infinite runs.

**Cut warning.** A control label alone does not identify a TM macro boundary: the pop loop revisits its first label while T>0. A TM cut requires both the listed label and T=0. The direct replay checks this condition.

## 4. Three registers to a literal two-register table

### 4.1 Representation including every raw positive input

At virtual-instruction boundaries, physical B=0 and

    A = C 2^L 3^R 5^T,  C>=1, gcd(C,30)=1.

Unique prime factorization gives this decomposition for every positive A. C remains unchanged. Virtual register primes are p_L=2,p_R=3,p_T=5. At instruction cuts A remains positive. Intermediate physical A can be zero; this is intentional.

The prologue repeatedly applies the virtual SUB T until v_5(A)=0. It terminates and leaves A=C 2^L 3^R, B=0. The TM simulation therefore starts with T=0 and exactly L=v_2(original A),R=v_3(original A), whatever its other prime factors. No external factorization is run by the loader or machine.

### 4.2 INC: multiply by a fixed prime

For a virtual ADD of register prime p, the physical table drains A one unit at a time. Each successful SUB A is followed by exactly p literal ADD B instructions, then returns to the test. After k iterations:

    A=N-k, B=pk.

The rank N-k decreases. On the first failed SUB A, A=0,B=pN. A second loop transfers B to A with one ADD A per successful SUB B. Its invariant is A+B=pN and its rank is B. On the final failed SUB B it exits to the virtual continuation at A=pN,B=0. Every operation is literally ADD/SUB.

The exact physical instruction counts are:

    ADD: 2pN
    successful SUB: (p+1)N
    failed SUB: 2
    total: (3p+1)N+2.

This multiplies the represented register by its correct prime factor, increasing its exponent by one without changing the other exponents or C.

### 4.3 SUB: divide, test remainder, restore if necessary

The physical table has p remainder-control states `rem0,...,rem(p-1)`. Each successfully decrements A and advances cyclically; crossing from p-1 back to 0 additionally performs one ADD B. At a remainder state j after k complete groups:

    A=N-pk-j, B=k, 0<=j<p.

The number of unconsumed A units decreases with every successful SUB A; the extra group ADD cannot loop by itself. Write uniquely N=pQ+r, 0<=r<p. The first failed SUB A occurs at A=0,B=Q in state r.

If r=0, the number N is divisible by p. Transfer B to A one-for-one; the invariant A+B=Q and decreasing B prove termination at A=Q,B=0. Since N>=1 and p divides N, Q>=1. Take the positive virtual SUB branch. Unique factorization says exactly that the represented exponent of p was positive and has decreased by one.

If r>0, the table enters a remainder-specific restoration loop. For each successful SUB B it executes p literal ADD A instructions. After k restoration groups, A=pk,B=Q-k. At B=0, execute exactly r further ADD A instructions and take the virtual zero branch. The result is A=pQ+r=N,B=0. Nondivisibility is equivalent to exponent zero, so the entire encoded state is restored.

There is no nondeterministic arithmetic test in this program. Remainders are bounded finite control, never an extra unbounded register. The loops terminate for every positive N, and every branch restores B=0 before continuing.

The exact counts are:

| Case | ADD | successful SUB | failed SUB | total |
|---|---:|---:|---:|---:|
| r=0 | 2Q | N+Q | 2 | N+3Q+2 |
| r>0 | N+Q | N+Q | 2 | 2N+2Q+2 |

A virtual ADD at prime p uses p+3 literal rows; a virtual SUB uses (3p^2+p+4)/2 rows, respectively 9,17,42 for p=2,3,5. The virtual table has ADD counts 74,76,145 and SUB counts 58,58,117 on L,R,T, including the scratch-clearing prologue. These counts give the exported total 8,408.

All source continuations, including HALT, occur only after the required restoration. Intermediate loops cannot halt. A physical macro boundary requires both its mapped entry label and B=0: its internal group/drain loop can revisit that label while B>0.

### 4.4 Why the verification covers unbounded input

`verify_frontend.py` reads the saved tables; it does not import the generator. For every macro it executes affine straight-line paths of the form

    input A=x+p, B=y  ->  output A=x, B=y+1

and the corresponding exits, transfer loops, and tails. The variables x,y,z are arbitrary naturals. Every tested SUB is verified either to have identically zero input, or to have nonnegative affine coefficients and constant at least 1. Thus every instruction choice on each checked path is valid for all parameter values, and every resulting affine identity is exact.

Every one of the 528 virtual and 8,408 physical instructions belongs to these checks. The invariants and decreasing ranks in Sections 3–4 compose those straight-line bodies into terminating arbitrary-length loops; this is why the proof is not finite-grid extrapolation. The checker also validates all destinations, all TM table selections, exact source bytes, and absence of aliases/unexpanded macros in the literal exports.

Additional unaccelerated interpreters test all six operation/prime shapes on 256 positive inputs each, 4,698 TM/half-tape cases through the virtual table, 261 whole TM steps through the actual physical table, and 81 arbitrary-cofactor/scratch-prologue cases. These finite tests supplement, rather than replace, the all-input proof.

