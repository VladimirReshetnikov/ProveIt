# Report 17 Startup history in a literal reversible source

This is a separate release. Report 16 and its frozen predecessor source remain unchanged.

## Main result

Four history-tag swaps preserve every original clean-loader input and global partial injection. Runs from the same clean input reach every corresponding normalized boundary no later, and every TM cut strictly earlier, in literal two-counter steps. This comparison does not apply to arbitrary equal-history internal states, and is not a CA-clock comparison.

- Within the fixed recorder/prime-template class, the six startup choices are optimal for all original inputs; exactly `2^227` static assignments attain the minimum
- New source: 122,622 controls and 141,561 literal rows, unchanged dimensions
- Source SHA-256: `fa61d06178d718511232a80a05e02192d940fde3c273f0c202f0623253b2ade3`
- All T=0 startup clocks: `76*A + 4*floor(A/5) + 24*floor(A/7) + 48*floor(A/11) + 62`
- Empty startup: 138 actually executed literal steps
- Exactly one following TM transition: 210 actually executed steps, giving a continuous 348-step prefix
- The old 79,936,151,060,302-step startup is theorem-predicted, not executed
- CA startup and first-transition cumulative clocks are predicted, not traversed

## Files

- `report17.pdf`: 14-page report with all-input proofs, exact delta, vector diagrams, and evidence accounting
- `report17.tex`: editable LaTeX source; figures are native TikZ vectors
- `build.sh`: portable TeX Live PDF rebuild
- `reproducibility/`: exact literal source, pinned dependencies and baseline reconstruction, proofs, complete traces, checkers, and replay receipts
- `release-manifest.json`: SHA-256 and byte sizes for every shipped file except this manifest and its detached checksum
- `release-manifest.json.sha256`: detached hash of the manifest
- `verify_release.py`: verifies the manifest and exact shipped inventory
- `report17-qa.json`: bounded source-trace and rendered-page review receipt

## Verify and replay

From a fresh extraction, first run:

    python3 -B verify_release.py

Replay all source checks in fresh normal and optimized Python copies:

    cd reproducibility
    python3 -B run_checks.py

This aggregate replay leaves the delivered files unchanged. Individual checker commands may regenerate their named receipts or traces. See `reproducibility/README.md` for details. The checks use only the Python 3 standard library and bundled pinned inputs, without network or optional sibling directories. `reproducibility/PORTABILITY.md` explains adaptations and historical provenance boundaries.

To rebuild the PDF with TeX Live:

    sh build.sh

The PDF build writes only to `.build/` and `report17.pdf`. Build caches are not part of the release. Remove `.build/` before an exact-inventory recheck. A different TeX distribution may produce a semantically identical PDF with different bytes; the manifest verifies the shipped PDF rather than promising cross-platform byte identity.

## Evidence limits

The full 348-step literal trace is bundled. No full universal program or CA rule array was executed. Independent finite tests supplement all-natural proofs; they are not extrapolated into a universality proof. The Neary-Woods finite-input universality theorem and the strict binary compiler remain explicit inherited mathematical dependencies. No third-party PDF, full paper extraction, private workspace path, developer log, or cache is shipped.
