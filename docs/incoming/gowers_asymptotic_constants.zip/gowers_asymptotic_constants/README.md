# Asymptotically Sharp Constants in Gowers' Szemerédi Framework

**Odd-order norm limits and efficient local phase removal**

Research manuscript prepared for Vladimir Reshetnikov and the ProveIt project,
7 October 2026. Mathematical development and manuscript by ChatGPT.

## Main results

1. **Exact uniform high-order norm limit.** For centered real functions on all
   finite abelian groups of odd order, the optimal comparison constant
   `c_d = sup ||f||U2^4 / ||f||Ud^4` tends to exactly `1/3`. For `d >= 80`,
   `1/3 <= c_d <= 1/3 + 10 * 2^(-floor(d/8))`.
2. **Sharp bounded inequality at every odd order.** For a group of odd order
   `N >= 3`, the best bound depending only on its order is
   `||f||U2^4 <= (1/3 - 4/(3N^2) + 1/N^3) ||f||infinity^4`.
   Equality is attained on the cyclic group of every such order.
3. **Fixed-group norm limits.** The high-order comparison on a fixed group tends
   to its bounded extremal constant. The cyclic limit is the exact expression
   in item 2.
4. **Sharp asymptotic quartic cube coefficient.** The optimal coefficient in
   the specified universal centered-cube upper expansion is
   `A_d = P_d * c_d`, with `P_d=(6^d-2*4^d+2^d)/8`; hence `A_d ~ 6^d/24`.
   The higher-order remainder is explicit. Sharpness is for real weighted
   perturbations, and no indicator-valued sharpness assertion is made.
5. **Asymptotically optimal local phase removal.** For the precisely normalized
   local problem based on Gowers' Proposition 17.7, the new coefficient is
   `v_k / D_k`, where `v_k=2^(k+1)/(k+2)!` and
   `1 <= D_k <= exp(2/(3(k+2)))`. A geometric upper bound proves that the
   optimal asymptotic local coefficient is equivalent to `v_k`.
6. **Exact positive covers and finite scale profile.** The face measure has an
   exact positive convolution identity, extending to all positive real kernel
   powers. Lattice interpolation preserves mass for powers at least one.
   The explicit finite coefficient has relative limit `exp(-3/lambda)` when
   `m/k^2 -> lambda > 0`, with limiting values 0 and 1 at the two endpoints.
   This profile describes this construction, not a necessary limit for every
   possible localization theorem.

The article includes 13 proposed research questions with concrete follow-up
targets. It resolves the limiting-constant and leading local-coefficient gaps
in the inspected project reports. It does not determine the exact fixed-order
constants for `d >= 4`, the exact fixed-degree local coefficient, or a new final
quantitative Szemerédi bound.

## Files

- `gowers_asymptotic_constants.tex`: complete, single-file article source.
- `gowers_asymptotic_constants.pdf`: compiled article.
- `figures/`: PDF figures used by TeX, PNG previews, and their input provenance.
- `code/`: exact supplementary checkers and the figure-generation script.
- `data/`: recorded checker results and build environment.
- `review/`: internal mathematical reviews and visual checks.
- `SOURCE_AUDIT.md`: repository snapshot, source fingerprints, and comparisons.
- `MANIFEST.sha256`: hashes of all other files in the archive.

The article source does not need the original repository or predecessor reports
to compile. Its only local dependencies are the supplied PDF figures. The
principal proofs are included in the article; standard Gowers norm facts are
cited in the preliminaries.

## Build and reproduce

Use Python 3.10 or newer for the supplementary scripts, with the packages in
`requirements.txt`. A normal TeX Live installation with `latexmk`, the AMS
packages, Latin Modern, `microtype`, `placeins`, and `hyperref` is sufficient.

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error gowers_asymptotic_constants.tex
python3 code/verify_bounded_norm.py
python3 code/verify_norm_limit.py
python3 code/verify_phase_face_cover.py
python3 code/make_figures.py
```

The Makefile provides `pdf`, `verify`, `figures`, and `clean` targets. Figures
are supplied, so regenerating them is optional for compiling the article.
`verify_norm_limit.py` uses 100-digit arithmetic for the transcendental
parameter table. Those decimals are approximate formula evaluations, not
certified interval bounds. The moment, aliasing, bounded-correlation, and
lattice checks use exact integer or rational arithmetic.

## Verification status

The general theorems rest on their analytic proofs. Supplementary checks passed:

- 729 scalar triples; 6,729 centered ternary functions on five groups;
  100 exact cyclic extremizers of odd orders 3 through 201.
- 1,296 moment/collision checks on six groups.
- 273 positive smoothing multiplier checks, including 97 aliased kernels.
- 241 tail-specialization checks and 247 rate-parameter checks.
- 10,980 lattice targets in 32 parameter cases.

Separate ChatGPT instances reviewed the principal proofs, their integration,
and the compiled PDF. This is internal review, not external peer review or
formal proof-assistant verification. The priority statement is relative to the
inspected ProveIt sources; a targeted literature log is included without a
claim of exhaustive historical priority.

## Suggested integration

Place this as a new contribution in the Ramsey research collection and link it
from the research index. Preserve the stated output normalization and the order
of asymptotic quantifiers. Mark the uniform limiting norm question and the
leading local-coefficient gap as resolved in the stated classes. Keep the
fixed-order, fixed-degree, stability, and optimal-rate questions open.

No existing repository files have been modified by this delivery.
