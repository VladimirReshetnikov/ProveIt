# Sharp uniform finite sector truncations of A196460

An unnumbered companion mathematical article dated 4 October 2026.

## Deliverables and contents

- `article.pdf`: the complete 12-page article
- `article.tex`: self-contained LaTeX, identical to `manuscript/article.tex`
- `inputs/uniform-sectors`: the complete accepted proof, exact evidence,
  scientific source programs, and authentic preservation records
- `inputs/independent-audit`: the complete fresh independent analytic audit,
  new exact rational evidence, integrity checks, and preservation records
- `inputs/predecessor-release`: the complete earlier fixed-order article
  release, unchanged and retained as inert reference evidence
- `inputs/source-seals`: original proof/audit archives and receipts, plus the
  authenticated predecessor source-evidence archive
- `tools`: inspected, separately owned presentation-only release tools
- `qa`: original preservation inventories, build receipts, recorder evidence,
  exact-dependency records, review dossiers, and visual acceptance

The article proves the sharp bound for every finite truncation simultaneously
when n>=32, with unique worst order M=2n-4 and exact excess
3(3n^2+n+1)/[n(13n^2-15n+2)]. The sharp asymptotic uniform constant is 9/13.
For the actual clipping-table count C_n=a_n+1, the extra term is merged into
the terminal sector; its exact maximum excess is 1/n, uniquely at M=2n-2.
The unmerged endpoint failure, excess exactly 1, is retained explicitly.

Full proofs include the complement and raising identities, both Gaussian
lattices with explicit common constant 8, every adjacent-sector ratio, and
all strict comparisons and endpoints. The leading coefficient ratio tends to
one iff k^2/n tends to zero. An explicit two-sided corrected estimate gives
uniform k=o(n^(2/3)) control and the exp(-c^2/4) square-root transition.
An exact-data table shows the endpoint maximizers and finite lower-n behavior.

The convenient threshold 32 is not claimed minimal. No scientific theorem is
added beyond the accepted source and audit. Exact-sector uniformity does not
establish growing-order logarithmic/inverse expansions or justify replacing
earlier exact coefficients by leading terms at the next-sector error scale.
Those limits and relevant further questions are explained explicitly.

## Attribution and relation to the earlier article

The prior fixed-order article, Zero auxiliary clipping tables and all orders
asymptotics of A196460, is unchanged. This companion briefly recalls C_n=1+a_n
and the graph model, leaving full closure and inverse proofs in that article.
OEIS A196460, A047863=k! alpha_k, the connected-color count A002027 for k>=1,
and the known parity-dependent theta asymptotic are credited. The previously
documented relational model of Svatos et al. is credited as well. There is no
novelty, priority, exhaustive-literature-search, physical-model, convergence,
or theorem-prover-verification claim.

## Presentation-only replay

Read `tools/README.md` and every tool in full before execution. The current
top-level tools compile and package only this article; all programs under
`inputs`, including predecessor presentation programs, remain inert. Do not
run/import the supplied scientific code, source interpreters, physical or
trajectory simulators, saved schedules, or Lean.

The owned builder uses a clean environment, a fresh isolated TeX format,
selected lm/cm maps, no shell escape, and exactly three typesetting passes.
Its recorder union includes the format and all three compilation passes.
Locked replay checks exact executable/dependency digests before execution
and the observed dependency union afterward. It then extracts PDF text and
renders every page. All-page visual inspection is an additional gate.

The dependency lock covers 190 recorded TeX system inputs, selected maps, and seven
interpreter/executable entries. It is not a full operating-system lock and
does not inventory shared libraries or Python's standard library. Changes to
locked dependencies are refused, not silently accepted. Ordinary local TeX
typesetting is possible separately but is not the verified locked replay.

## Preservation and safe extraction

The presentation freeze contains 213 files and 26 directories under inputs,
excluding the inputs root. The separately recorded 355-object original
boundary contains the new proof/audit trees and seals, the predecessor tree
and archive, and every object in the independent audit's existing 333-object
boundary. No original source content, mode or mtime is repaired to obtain a
passing comparison. Access times, ctime, ownership, inode allocation, and
directory allocation sizes lie outside the claim.

Authentic historical boundaries remain unchanged: the growing-sector source
records equality on its 51 objects, and the independent audit later records
equality on its 333 objects. The predecessor's qualifications concerning
earlier concurrent Report69/70 changes are preserved, not rewritten as a
broader historical preservation claim.

The release manifest and deterministic archive retain exact file bytes,
permission modes, and nanosecond mtimes for files and directories within
their stated boundary. The manifest excludes its own bytes/self-metadata and
the release root's metadata to avoid a circular seal. The archive records
normalized manifest mode 0644 even when the delivered manifest copy is 0444.

Authenticate the detached manifest pin before verifying or extracting. The
owned extractor checks all archive bytes before creating output, rejects
unsafe or duplicate members and unexpected inventory, and restores file and
directory metadata from the manifest. Generic ZIP extractors may not restore
nanosecond mtimes. Read-only sealing and SHA-256 pins provide local integrity,
not a digital signature, WORM storage, or trusted external timestamp.

The detached final manifest and ZIP receipt is supplied alongside the release.
External publication and Library delivery are separate actions.

## Exact artifact identity and replay

The final standalone and manuscript LaTeX SHA-256 is
`d0770c2f36b214204b13f7487f3d7299b2da96844de47f954cd717f5f78b3191`.

The final 12-page PDF SHA-256 is
`e1689dc2ba86b8a1c01ac33897007bcafa3e6454f197b87920e56af87235b1df`.

The manuscript-pin-map SHA-256 is
`10ddbdee2fc822c63b437b3e4b84c57717d3ed7934f63aa05952f0e1aac19164`.

The build-dependency-lock SHA-256 is
`6ee7f579ad072c7c57d76341d35c51742f8b976c40816ad305b12a9836f35d07`.

The exact final page-inventory SHA-256 is
`4c6266dd79053b94a155b17b0148d23d6fb8ecb264f9d161b35420f29711decc`.

From this release, after inspecting every tool, use an absolute fresh output
directory outside this release and all protected originals:

    python3 -I -S -B tools/release.py check-inputs
    python3 -I -S -B tools/build_article.py \
      --pins-sha 10ddbdee2fc822c63b437b3e4b84c57717d3ed7934f63aa05952f0e1aac19164 \
      --dependency-lock-sha 6ee7f579ad072c7c57d76341d35c51742f8b976c40816ad305b12a9836f35d07 \
      --require-packaged-match --output-dir /absolute/fresh/build-directory

Authenticate the detached final manifest digest before archive use:

    python3 -I -S -B tools/release.py verify --manifest-sha256 MANIFEST_PIN
    python3 -I -S -B tools/release.py extract \
      --manifest-sha256 MANIFEST_PIN --archive /absolute/source-evidence.zip \
      --output-dir /absolute/fresh/extracted-directory

The final build is retained in `qa/tool-build-v2`; its separate exact packaged-
match replay confirms both PDF and all twelve raster pages match. The owner
opened all twelve final pages after the caption-only v2 correction and records
acceptance in `qa/OWNER_VISUAL_REVIEW.json`. The v1 caption revision and the
fresh-preservation refusal during a concurrent QA write remain in their
historical records, rather than being silently relabeled as passing runs.

## Completed independent reviews

The complete independent mathematical/manuscript and all-page visual review
is retained in `qa/independent-manuscript-review`. Its manifest SHA-256 is
`c8099b42f7a758b7b1df4130ee3701ac56ccd9f17663237c8f5ad9c3dd95e58b`.
The verdict is PASS without a mathematical correction. The final v2 change is
only the caption opening. The root additionally read the full manuscript and
individually inspected all twelve final pages, with acceptance recorded in
`qa/ROOT_MANUSCRIPT_AND_VISUAL_ACCEPTANCE.json`.

The independent presentation-tool review is retained in
`qa/independent-release-tool-review`. Its `REVIEW_MANIFEST.json` SHA-256 is
`6bf36e3d818d07f08a883819d6621dbafbdece6eeb5285a3c28f25ec639130d2`.
Its PASS covers all reviewed executable tools and the final documentation-only
Human-to-Visual correction, 39 fresh owned synthetic tests, 19 additional
independent hostile probes, direct preservation checks, exact PDF/raster replay
before and after relocation, deterministic candidate ZIPs and metadata-restoring
extraction. The external final-seal coordinator was independently read as inert
source; its snapshot is retained in that dossier. No scientific program ran.

This tool review's exact candidate snapshot precedes final README/QA assembly.
It is explicitly not the completed release manifest or a final terminal gate.
Large repeated fixtures and binaries remain external, identified by the retained
6,692-object evidence inventory; the compact dossier includes all full reports,
scripts, receipts, negative outputs, recorder logs, and exact artifact pins.
The final owned seal and separate root post-seal gate must authenticate the
completed release inventory. All manuscript, visual, and tool reviews here are
model-performed; no claim of human review is made.
