# Same P66 with a smaller complete indexed-tile recipe

CODE/TEX ONLY/HOLD. This page keeps the entire accepted fifteen-positive
P66 arithmetic and whole indexed943 coefficient tuple. The following
sections1--5 are copied verbatim from the accepted fifteen66 proof. Only
section6 below addresses the new fixed recipe and held verification.
The ordinary binary-pass-cleanup proposal has been independently accepted.
No compact candidate application, helper, TeX/PDF or Lean run has occurred.

## 1. Exact equation and domain

All fifteen inputs are strictly positive integers, in order:

    J,F,alpha,z,f,h,i,T,s,w,tau,eta,zeta,y,gamma.

The four free fixed ports are beta,K0,MC,MF. Define

    q=beta*J+1, C=q-F-alpha, X=w*q, Y=s*q^3, E=X*Y,
    k=eta+zeta, ell=E*k*Y, c=k*Y+eta, a=E+Y,
    H=4*a+3, Delta=a^2+H, D=X+a*c+gamma*H,
    R=((q-1)*(q-F)+alpha)*(q^2-1)+(MC+q*MF)*J,
    V=f^2*(c*T-R)-c, S=i*Delta*c^2,
    N0=tau^2-ell*(ell+k), N1=D^2-Delta*c^2,
    Na=S^2*(V^2-y^2)+y^2, Nk=k-h*E-R,
    Nt=(K0+w)*C+(q-F)-z*(q-1), Ns=Delta*f^2-S^2.

The equation is N0*N1*Na*Nk*Nt*Ns-Delta=0. All exponents are fixed
natural integers. All definitions are abbreviations, not additional
quantified variables. The exact66 rows are preserved from the pinned
source54 DAG; only whole coefficient/provenance metadata are newly bound.
The immutable historical DAG copy remains under fixed/ as a free-port
source, with its old binding correctly labeled historical.

## 2. The whole indexed native contract

The sealed indexed-tile-enumeration proof reconstructs the complete
430-action and943-tile language, including all transition/color
conjugacies and a selector permutation fixing Start0/Forbidden1. The
entire native tuple is regenerated, with rho=2^67,L=8807,d=590069,
B=rho^L,beta=B-1,K0=DC+B*DR,MC and MF_source=MF_native+beta. The
four raw payloads total295388 bytes. The old original or sorted-BFS K
is never substituted by an isolated numerical equality.

Its full native basis/support/carry/mask premises and fresh actual-rank
controller are part of that sealed theorem. In particular its canonical
family has arbitrarily large padding, positive normalized source
coordinates, R=3 modulo4 and the native margin giving alpha>0. Soundness
extracts the fresh indexed tiling and then the original blank computation.
Completeness freshly encodes a refutation's padded tableau and corrects
the actual rank using the new DC/controller; it does not preserve packed
F,C,R or private Pell witnesses from another tuple.

Section4 of that proof supplies the normalized positive source interface.
The accepted index-weight proof explicitly reconstructs its prescribed
unscaled source base a+2. The source54 short proof section8 and source36
P67 proof are uniform for precisely this authentic normalized native
interface. The ordinary source theorem explicitly permits another
compiler for which that same whole interface has been proved; arbitrary
four-port values do not have a consistency meaning. The required masks
are 0<MC,MF_native<beta,MC=2 modulo4,MF_native=4 modulo8 and population
sum d. These hold for the indexed tuple. Thus composing the retained
interface is a whole-source specialization, not a same-polynomial claim.

## 3. Positive soundness, including unresolved unit signs

Delta=(a+2)^2-1>0 for every positive assignment. Because
Ns=Delta*(f^2-Delta*i^2*c^4), cancelling Delta in the proof gives
the product of six integer factors equal to1. Every factor is a unit.
The consecutive-product negative-Pell descent excludes N0=-1.
Delta is0 or3 modulo4, so the main and normalized strong units cannot
be-1. Since S^2 is a square, Na is congruent to y^2 or V^2 modulo4,
excluding Na=-1. Therefore

    N0=N1=Na=1, f^2=1+Delta*i^2*c^4,
    Nk=Nt=epsilon with epsilon in{1,-1}.

At this point C>=0, not necessarily C>0. The original normalized
P67 signed-recovery argument retains C=0 through the early rank bounds
and excludes it only after recovering Nk=Nt=1. It is not replaced by
an assertion that every individual unit is already positive.

For the quotient, set T_old=f*T>0. Before any equation there is the exact
identity c*((f*T)*f-1)-R*f^2=f^2*(c*T-R)-c. All other positive inputs
and all four current indexed ports remain unchanged. The assignment
therefore solves the normalized P67 equation on the indexed native
interface. Its unbounded Pell/ratio/whole-product/source recovery yields
a finite syntactic ZFC refutation. The alternative explicit bridge in
source54 section8 takes i_ordinary=Delta*i and reaches the retained
ordinary product proof with the same two unresolved signs; either bridge
uses the whole indexed source contract just established.

## 4. Positive completeness with fresh quotient and ordinate

A finite refutation supplies fresh canonical normalized source witnesses
from the indexed native theorem. Retain the outer positive coordinates,
f and i, with A=a+2,c=psi_A(R),Delta=A^2-1 and

    f^2=1+Delta*i^2*c^4, S=Delta*i*c^2,
    S^2=Delta*(f^2-1), R=3 modulo4.

For integer Pell polynomials define Q_j by
Q0=1,Q1=4Z-3,Q_(j+1)=(4Z-2)Q_j-Q_(j-1). Induction gives
chi_t(2j+1)=t*Q_j(t^2),Q_j(0)=(-1)^j*(2j+1), and
Q_j(1-A^2)=(-1)^j*psi_A(2j+1). These are integer polynomial
identities, so they hold modulo the square modulus f^2.

Set V*=chi_S(R)/S,y*=psi_S(R). These are positive integers and the
Pell identity gives S^2*((V*)^2-(y*)^2)+(y*)^2=1. Since (R-1)/2
is odd,S^2=1-A^2 modulo f^2 and c divides S, the identities imply

    V*=-c modulo f^2, V*=-R modulo c.

Also gcd(c,f)=1 and f^2=1 modulo c. Consequently

    T*=(V*+c+R*f^2)/(c*f^2)

is a positive integer and V*=f^2*(c*T*-R)-c. Replacing only T,y by
T*,y* leaves every other source factor unchanged and yields the new
P66 zero. This construction does not claim every old T_old is divisible
by f or that old private auxiliary witnesses are fixed. No shifted
T*-alpha input occurs in this equation, so the source133 shifted-quotient
R=3 endpoint issue is not imported here.

The two directions establish positive existence iff a finite syntactic
refutation. Negating gives the ordinary ZFC-provable unsolvability iff
Con(ZFC) statement. They do not prove Con(ZFC), add a new formal-kernel
certificate or execute an inherited compiler or paused Lean development.

## 5. Exact free-port arithmetic, liveness and degree

The producer must copy all66 arithmetic rows, the fifteen ordered
unknowns, four ports, output and arithmetic metrics without alteration.
The independent auditor compares those literal fields against the entire
immutable source54 input, then checks topology and full liveness. It
does not trust a changed binding as an algebraic proof.

Every displayed definition and the box is parsed from the actual TeX.
Twenty-two definitions plus the output are checked in order as exact
sparse polynomials over all nineteen free inputs/ports. Previously
proved displayed registers are the only boundaries. The union of these
local expansion cones must cover every one of the66 rows. Formula-map
reference strings are not substituted for the actual displayed TeX.

Give each unknown degree1 and each fixed port degree0. The only leading
cancellation is the main norm, whose complete ancestor polynomial is
expanded exactly when its apparent degree22 cancels. With Z=X+gamma*H,
N1=2*a*c*Z+Z^2-H*c^2 has exact degree18. The six factor degrees are
22,18,62,7,2,46, totaling157; subtraction of Delta is lower degree.
Writing q0=beta*J,k0=eta+zeta, the complete output leader is

    -8*q0^91*h*gamma*i^4*k0^13*w^13*s^26*T^2*f^4
       *(w*(q0-F-alpha)-z*q0).

The auditor must independently propagate entire homogeneous polynomials,
perform the full cancellation expansion, compare this full leader and
extract coefficient8*beta^92 at
J^92*h*gamma*i^4*eta^13*w^13*s^26*T^2*f^4*z. Since beta>0, the
degree is attained by the whole current tuple, not merely generic ports.
Both polynomial and metadata corruptions must reach these checks.

## 6. Smaller complete recipe and held verification boundary

The grouped, compact-tile-parameter and binary-pass-cleanup ordinary
identities, with their full parent closures, prove that the complete3819-
byte constant body specifies the identical943 indexed tuples,430 actions
and four integers. RECIPE_PROOF.md supplies the full dependency order,
payload identity, row inverses and whole-integer argument. No new tuple,
controller, Pell interface or consistency premise is introduced. Thus the
positive soundness and completeness maps above apply without alteration.

The local audited code is held for two complete static reviews and a
separate explicit execution release. It is intended to parse every actual
changed function, rank/set/domain, table coordinate, fixed decoder and
positional sum, prove all943 tuples pointwise and all430 actions against
the whole accepted indexed parent, and prove the complemented payload
identity before collecting the actual Phi in the original943 independent
payload variables. The inherited full3297-digit support audit and every
295388 canonical raw coefficient byte remain mandatory.

The displayed arithmetic prefix is byte-identical to the accepted parent.
The future actual-TeX audit retains all23 cuts, all66 live gates, all15
positive inputs, all4 live whole ports and the cancellation-aware degree157
leader from section5. All previous native/context/front controls remain;
new actual-TeX controls exercise every new recipe family and lexical scope.

The expected complete PDF suffix starts from the actual accepted grouped
page's full extracted glyph stream. Every compact/binary replacement is
charged, including new direction/set/rank subscripts, all row domains and
payload/flag signs. The front is compared in full with the accepted
fifteen66 extraction. Only whitespace, the two known floor encodings and
validated prose-only automatic ASCII line hyphens may be normalized.
Unicode minus, intentional hyphens and unknown glyphs are preserved.

No new source output, receipt or rendered result belongs to this held
checkpoint. A future release must stop at the first failure, retain full
external receipts, pass normal/optimized source audits and pure source
checks, render one Letter page at9-point body/7.7-point seed with zero
overfull diagnostics, pass full normal/optimized actual-PDF audits and
pure rerenders, and obtain independent actual visual review before any
maintained-page promotion. Source bytes are3819 versus3970 for grouped66;
no rendered-size or readability gain is claimed at this stage. The native
and internal-ZFC formalizations remain open in Lean and Lean work is
paused at the user's instruction.
