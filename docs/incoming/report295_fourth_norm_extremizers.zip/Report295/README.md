# Report 295

## Exact Fourth Norms and Two-Valued Extremizers

Mean perturbations and parity energy on finite abelian groups

Prepared for Vladimir Reshetnikov, 7 October 2026.

This self-contained article proves that every real fourth-norm maximizer of I−γJ/n is at most two-valued for n≥3 and γ>0, and every complex maximizer is a complex multiple of a real one. It provides a finite stationary-polynomial reduction, the exact constant-vector threshold with its transition equality cases, and a sharp dimension-free consequence of that threshold.

For the mean reflection I−2J/n, the article gives a radical formula in every finite dimension, at most two candidate multiplicities, every real and complex upper and lower equality vector, a strict finite universal bound, and the limiting norm. The candidate rule compares formula values; it is not nearest-integer rounding.

For a target element δ of order two and a point spike δ1_{0} on a finite abelian group of order n, the reflection norm yields the lower bound η_n=(1+||I−2J/n||_4^(-4))/2 on respected additive energy divided by ordinary additive energy. This spectral bound is attained by nonnegative weights exactly when an optimal reflection multiplicity divides n. The article classifies all such point-spike weights. It also proves the corresponding saturation criterion for spikes on subgroups of index n, without assuming the group extension splits.

Exact examples distinguish order 27, where all minimizers are supported on order 9 subgroups, from order 81, where the spectral lower bound is strictly unattainable. The actual order 81 minimum is not determined. Indicator weights are explicitly distinguished from general nonnegative weights.

## Files

- Report295.pdf: verified reader-facing article
- Report295.tex: complete editable LaTeX source
- companion/exact_checks.py: bounded standard-library exact checks
- companion/interval_certificate.json: exact rational interval data, independently regenerated and checked
- companion/README.md: precise mathematical and computational scope
- tests/test_companion.py: mathematical checker and failure-mode regressions
- tests/test_build.py: guarded build and archive regressions
- build.py: offline reproducible build and deterministic ZIP
- SOURCES.md: source bindings, bibliography and public inventory
- REPRODUCING.md: commands, toolchain and integrity contract
- MANIFEST.sha256: hashes of the public files other than the manifest itself

The tiny companion/__init__.py is also included. The archive contains exactly thirteen regular-file members under Report295/. The separate archive SHA-256 pin is computed from the final ZIP bytes.

## Quick start

    python3 -I -B build.py verify
    python3 -I -B companion/exact_checks.py
    python3 -I -B build.py reproduce --output /tmp/report295-replay

Use a fresh external absolute output directory. The builder never writes into the source tree. See REPRODUCING.md before replaying on another toolchain.

## Scope

The polynomial checks verify identities, not a numerical approximation to the all-parameter theorem. Rational interval certificates establish their stated finite comparisons. General two-valuedness, phase classification, threshold sharpness, the two-candidate rule, and all-group saturation follow from the written proofs. There is no numerical optimizer or claim of formal proof-assistant verification.

The classical quartic half-degree principle already gives existence of a two-valued norming vector; this article proves the all-maximizer statement directly. Equality of real and complex operator norms is established general theory. The comparison with the printed mixed-sign matrix prediction is restricted to its nondegenerate p=4 specialization, with no arbitrary-p, novelty or priority claim. No global Ramsey-number or Szemeredi-bound improvement is asserted.

Reports 1–294 are immutable and unchanged. The code and build require no earlier report or research path.
