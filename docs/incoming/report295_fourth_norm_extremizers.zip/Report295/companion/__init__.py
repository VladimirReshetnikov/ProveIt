"""Standalone exact companion to Report295."""
