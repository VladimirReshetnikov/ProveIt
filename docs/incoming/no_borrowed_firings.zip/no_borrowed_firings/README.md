# No Borrowed Firings

**Canonical Diophantine Certificates for Abelian Sandpiles**  
Research draft, October 2, 2026. Prepared for the ProveIt research program.

## Main results

For a finite loopless undirected multigraph with `n` nonsink vertices and
`m` distinct internal adjacent pairs, the explicit compiler uses
`11*n + 12*m` natural witnesses and `12*n + 16*m` quadratic residuals.
Their sum of squares is a quartic with exactly one natural zero if legal
stabilization terminates, and no natural zero otherwise. The proof replaces
chronological traces with a support-burning test and canonical parallel ranks.

For a stable effectively periodic background plus finitely many added chips
on Z^3, the corresponding fixed local schema has **47 finite-deviation field
witnesses and 60 quadratic residuals**. It has a unique field solution exactly
when the total number of topplings is finite. Field arity is NOT ordinary
integer-witness arity. An exterior no-firing halo makes finite-window checks
sound. Established sandpile universality is imported from Cairns; the article
derives the resulting completeness and uncomputable-support consequences.

The article proves these statements but does not establish literature priority.
Classical burning, least action, MRDP, and Cairns's universality are not claimed
as new results. No Lean verification or single-fold MRDP theorem is claimed.

## Files

- `article.tex`, `article.pdf`: full article, proofs, references, and nine research questions.
- `sandpile_certificates.py`: actual sparse integer-polynomial compiler, natural-domain
  interfaces, validated periodic inputs, finite cube certificates, normalized field
  witnesses, and an independent local field verifier.
- `verify.py`: exact finite checks; regenerates examples and reports.
- `examples/two_vertex_certificate.json`: all 40 residuals and the complete expanded
  201-monomial quartic in 34 variables.
- `examples/two_vertex_witness.json`: its unique natural witness.
- `examples/three_dimensional_avalanche.json`: exact odometer and burning ranks for
  100 chips at the origin of Z^3 with zero background.
- `examples/three_dimensional_field_certificate.json`: the normalized 47-field
  witness, with 57 exceptional sites, for that input.
- `verification/results.json`, `verification/results.txt`: reproducible test results.
- `verification/pdf_preflight.json`: final document checks.
- `SOURCES.md`: pinned sources and attribution boundaries.
- `SHA256SUMS`: integrity hashes for the distributed files.

## Reproduce

Python 3.10+ is required. There are no third-party Python dependencies.

```sh
python verify.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, use `make check` and `make pdf`; `make pdf` uses `latexmk`.
The PDF requires standard LaTeX packages declared in the preamble. No external
images, bibliography service, or font files are needed or bundled.

The test run uses a fixed random seed only for 250 polynomial identity
spot checks. Its graph and candidate families are exhaustively enumerated.
Recorded tests cover 43 dissipative simple graphs, 4,855 inputs, and 305,620
bounded candidate firing vectors. Of the candidates, 3,839 satisfy stable
balance and are independently checked against all fired subsets. The test
suite also checks 290 compiled graph witnesses, bounded rank uniqueness,
multigraph inputs, cube counts, and several deliberately invalid certificates.
These tests supplement the proofs; they do not prove the infinite theorems.

## Minimal graph example

```python
from sandpile_certificates import Graph, compile_graph, graph_assignment

graph = Graph(((0, 1), (1, 0)), (1, 1))
cert = compile_graph(graph, (3, 1))
values = cert.vector(graph_assignment(graph, (3, 1)))
assert not any(cert.evaluate(values))
quartic = cert.quartic()
assert quartic.degree == 4
assert quartic.evaluate(values) == 0
```

The correct odometer is `(2, 1)` and its canonical parallel burning ranks are
`(2, 1)`. With input `(1, 1)`, the tempting firing vector `(1, 1)` leaves a
stable balance but cannot be legally executed; the certificate rejects it.

## Field certificate example

```python
import json
from sandpile_certificates import (
    PeriodicInput, field_witness_from_cube, verify_field_witness,
    serialize_field_witness, read_field_witness,
)

data = PeriodicInput((1, 1, 1), (0,), (((0, 0, 0), 100),))
w = field_witness_from_cube(data, 2)
assert w == field_witness_from_cube(data, 3)  # same fields; no padding radius
assert verify_field_witness(data, w)        # local checks, no run simulation
payload = serialize_field_witness(data, w)
assert read_field_witness(json.loads(json.dumps(payload))) == (data, w)
```

The zero-based direction order is negative then positive along each axis,
matching `lattice_neighbors`. The first eleven field names are
`u, s, sigma, z, alpha, r, k, e, beta, lam, mu`; each direction contributes
`A, p, q, B, P, Q`. The JSON lists the entire ordered field-name array.
All field values are natural. Exceptional coordinates may be negative.

## Important limits

Finite sink graphs whose every component meets a sink always stabilize; their
halting problem is not the universal problem used here. The universal input
class is infinite and has a finite effective periodic-plus-finite description.

A small cube failing its halo check means only that it does not contain global
stabilization. It does NOT prove global nontermination. The simulator's default
budget is a safety guard: exhaustion raises `TimeoutError` with an explicitly
unknown termination status. Increase the supplied budget as appropriate.

Use `compile_periodic_cube` for the validated infinite-input interface.
The lower-level arbitrary-callback `compile_cube` cannot check a whole infinite
background; its caller must supply a stable exterior and include all defects.

The quartic's theorem is over **nonnegative integer witnesses**. Over unrestricted
integers, negative masked slacks can create false roots; a test exhibits one.
A four-squares conversion restores natural-domain existence over integers but
loses uniqueness. The fixed field expression uses shifts and finite-tail
conditions; it is not a 47-variable universal ordinary polynomial.

The polynomial class has an unrestricted integer evaluator for algebraic checks;
use `Certificate.vector` and `Certificate.evaluate` when validating the natural
domain. Avoid fully expanding a large cube quartic: its residual representation
is the practical output. The graph data structure uses a dense matrix, although
its emitted polynomials are sparse.

No files were committed to the ProveIt repository. The current package is a
standalone contribution with its own proofs and reproducible artifacts.
