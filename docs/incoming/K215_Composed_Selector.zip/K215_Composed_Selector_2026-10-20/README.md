# K215: composed partial-selector and command-reader construction

This packet constructs a **215-working-state, two-symbol, one-tape Turing machine** satisfying

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halts}(M_{215},\mathrm{blank})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

The completely blank tape and its initialization are included. Working states are 0–214; the distinct halt label is 215 and has no outgoing rows. Thus there are 215 working states, 216 labels including halt, and 430 transition rows. The tape is two-way infinite, the blank symbol is 0, the initial head coordinate is 0, and every move is L or R.

This is an ordinary mathematical construction, supported by exact finite checks and executable symbolic induction, using the explicitly inherited numerical-calculus/ZFC calibration. **No newly compiled Lean/Rocq endpoint or internal PA proof object for these exact 215-state bytes is claimed.** The equivalence does not assume Con(ZFC); no unconditional nonhalting or minimality claim is made.

## What changed

We combine the Partial Selector 216 source with the command-specific input reader and NIP/DROP/MP permutation from the Permuted Commands 216 packet. Four closed interval splices and one closed reassociation reduce the combined source from 203 to 202 distinct subtrees while retaining the partial-selector fold. Joint physical allocation retires native state 224, changes 35 retained rows, and adds no state.

The native state-81 helper rewrite has a two-cell, arbitrary-tape proof before reallocation. Two newly assigned CB1 wrappers must route through `0 L 302` to clear their entire trailing-one suffix. The final rows are `117 1 0 L 302` and `214 1 0 L 302`. An earlier allocation using the context-limited `0 L 40` shortcut was rejected; its concrete counterexample is retained separately.

## Exact final files

| File | SHA-256 |
|---|---|
| `machine/k215.native.tm` | `03739f080d023166773bc14e7e3a4d8157f81d44c28cd30fef46066b37cf3748` |
| `machine/k215.tm` | `fd9de5a9702c6193350952ca85a43f65d288b20f234b7582549b6aaa7a5ce703` |
| `source/sites215.json` | `17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba` |

`machine/k215.tm` is the canonical table. The text header gives start 0 and halt 215. Each following line has `state read write direction next-state`.

`machine/k215.native.tm` retains the sparse historical labels: start 0, dispatcher 84, halt 254. `machine/canonicalization.json` contains both directions of the exact state bijection; the canonical dispatcher is 83. All 430 rows commute with the bijection. All 215 working states are reachable in the directed transition graph; this does not assert that the blank run visits all of them.

## Verification results

| Obligation | Result |
|---|---:|
| Distinct source subtrees | 202 |
| Primitive occurrences | 4,751 |
| Guarded primitive cases | 6,176 / 6,176 |
| Nonhalting guarded source edges | 6,175 / 6,175 |
| Compound decoder contexts | 4,750 / 4,750 |
| Literal decoder-prefix transition checks | 5,721 |
| Full runtime symbolic steps | 1,698,790 |
| Maximum symbolic derivation length per case | 460 |
| Transition rows covered | 430 / 430 |
| Minimum affine duration constant | 6 overall; 28 for nonhalting primitives |
| Complete blank initialization | 95,726 transitions |

The runtime argument is universal over all natural primary values under their guards, every natural gap, an arbitrary nonempty finite spare list, and the complete zero exterior. The 4,000-step cap in the checker bounds symbolic proof construction, not concrete execution time, data values, or spare-list length. Each successful case ends in exact frame equality or actual halt, using literal transitions, induction over unary runs, and induction over finite lists after proving the exact-table one-block schemas.

At the end of initialization the native machine is in dispatcher 84, head −8, header 57, extra gap 1. Logical registers `(N,T,W,A,D,H,X,Y,L)` are `[4,0,0,0,0,0,0,0,0]`; there are 40 spare values, each 1, exactly 95 one-cells, and zero everywhere else. The visited head interval is `[-18,199]`. This is the ordinary calibrated clean seed. **The final construction does not use a nonzero theorem-valued initial top.**

## Reproduce the checks

Use Python 3.10 or newer with assertions enabled. The scripts use only its standard library. No solver, network access, package installation, or discovery search is needed. From this directory:

```sh
python3 -B verify.py
python3 -B verify.py --runtime
```

The default verifier checks the manifest, pinned parent archives, deterministic reconstruction, exact output bytes, source bisimulation, all decoder contexts, the helper diamond, full independent blank execution, the saved case inventory and bindings, the raw-address/ordinal interface, and the two inherited logical forward checkers. It extracts only three precise members from the parent archives, not their entire nested ancestry.

`--runtime` additionally reruns every symbolic induction case on the exact final table and compares the ordered case receipts and complete startup data. A full runtime replay took about 135 seconds in the research environment. Timing is not part of the proof. `--work /absolute/new/directory` retains new replay outputs outside the packet. The verifier rejects optimized Python execution.

The individual universal checker can also be invoked directly:

```sh
python3 -B code/validate_runtime.py \
  machine/k215.native.tm source/sites215.json /tmp/k215-runtime-replay
```

For a separate native/canonical and complete startup-trace replay:

```sh
python3 -B code/audit_table_and_blank.py \
  --native machine/k215.native.tm \
  --canonical machine/k215.tm \
  --mapping machine/canonicalization.json \
  --trace evidence/startup.trace.jsonl.gz \
  --output /tmp/k215-blank-replay.json
```

For the logical bridge alone:

```sh
python3 -B theory/check_classical_compact.py \
  theory/dominated_rho8_full_certificate.json
python3 -B theory/audit_classical_independent.py \
  theory/dominated_rho8_full_certificate.json
```

These replay 3,728 proof nodes and 5,160 shared term nodes, including 1,260 dominated-row leaves and the unrestricted rho8 conclusion. They check the dominated-to-unrestricted bridge. They do **not** independently reprove the foundational native-calculus/ZFC calibration; that theorem and its proof ancestry are retained in the pinned parent archives.

For the concrete rejected-allocation counterexample:

```sh
python3 -B research/failed_allocation/check_rejected_shortcut.py \
  research/failed_allocation/candidate.native.tm machine/k215.native.tm
```

The rejected table returns an incorrect complete control frame after 44 steps at ordinal 4697. The corrected table returns the exact required whole frame after 156 steps. No conclusion about the rejected table's blank-run consistency equivalence is claimed.

## Report and proof chain

`report.tex` plus `sections/*.tex` compile to the included `report.pdf`:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The report gives the exact numerical constructors and axiom rows, command equations, theorem invariant for all raw natural codes, a strong proof compiler, and a cofinal family of refuting candidates beyond the actual cutoff 4. It then combines:

1. The complete finite blank-prefix calculation.
2. The exact-table, positive-duration primitive simulation.
3. Strong source bisimulation with the calibrated permuted source.
4. The sound and complete source proof enumerator.
5. The inherited dominated/unrestricted logical bridge and native-calculus/ZFC calibration.

The canonical transition table and all changed native rows are printed in the report. The full finite logical countermodels for the four restrictions `U=A`, `U=B`, `U=C`, and `U=truth` are supplied under `research/logical_restrictions/`. These refute recovery of the classical basis in the restricted **pure implicational fragments**; they do not show that the corresponding full quantifier/set theories are weaker than ZFC.

## Provenance and scope

The two direct parents are included unchanged under `parent/` and pinned in `provenance/SOURCE_PINS.json`. Their original archives retain all nested attribution and licensing material. `provenance/ATTRIBUTION.md` distinguishes the new construction from inherited numerical logic, proof compiler, source semantics, runtime infrastructure, and historical work. Separate implementations and parallel review in this collaboration are not external human endorsements.

The `research/failed_allocation/` directory is deliberately excluded from positive evidence: it contains a rejected prototype and diagnostics. The primary final table is only the one with native SHA beginning `03739f08` and canonical SHA beginning `fd9de5a9`.

The report is dated 21 October 2026 UTC; the enclosing research-directory identifier retains the 20 October working-session date.
