# A 222-state binary Turing machine for ZFC consistency

This packet constructs a **222-working-state**, binary, single-tape machine whose blank-tape non-halting is equivalent, by an ordinary mathematical proof formalizable in ZFC, to `Con(ZFC)`.

The complete machine is [`machine/candidate222.tm`](machine/candidate222.tm). Its working states are **0–221**, its initial state is **0**, and its separate halt target is **222**. It starts with head at coordinate 0 on an all-zero tape indexed by the integers. All 444 transitions write one binary symbol and move exactly one position left or right. Initialization is included in the count.

**Canonical table SHA-256**

```text
60e21a040e58e2a2840b0f3d58ad3ee0e6ef4d0d5cdf1372d5a69355f1198ca1
```

The report is [`report/ZFC_K222_Construction_2026-10-20.pdf`](report/ZFC_K222_Construction_2026-10-20.pdf); its complete LaTeX sources and table generator are in the same directory.

## What changed

Two different 223-state constructions in the pinned ProveIt snapshot supply compatible improvements:

| Construction | Set-theoretic core | Equality presentation | Working states |
| --- | --- | --- | ---: |
| Official conditional K223 | Conditional K | Old Euclidean row and separate restricted helper | 223 |
| Incoming G223 | Unconditional K | Merged G row | 223 |
| **This conditional G222** | **Conditional K** | **Merged G row** | **222** |

The new composition retains the conditional core while replacing the old equality row by

```text
Eq(c,a) -> (Eq(c,b) -> All_Rel(a,b) Eq(a,b)).
```

It removes the restricted equality-vacuity helper from the gated set-theoretic bundle. G derives that exact helper, reflexivity, and the old Euclidean row in the retained logical basis. The proof is independent of the set-theoretic core, so it works for the conditional core. Conversely the old row and helper derive G. Both calculi derive exactly the same native formula codes, including the target code 1.

The larger equality row adds 109 primitive occurrences; deleting the helper saves 327, reducing the conditional223 source from 4,799 to **4,581** occurrences. There are **209 distinct source subtrees**, including **186 interior nodes**. The final physical accounting is

```text
49 engine roles + 186 interior source nodes - 13 shared roles = 222 states.
```

A closed source-tree rotation keeps the maximum consecutive-zero address run at 6. The compiled parent has 224 states. Two certified identifications, native `303 -> 118` and `302 -> 159`, reduce it to 222. The old parent always reads 0 in state 118, allowing its unreachable read-1 row to be reused. The resulting direct one-step simulation holds for every initial binary tape and head position, from state 0. The old invariant is not asserted for the final machine.

G fusion, conditional K, and earlier state-sharing machinery are inherited. The contribution is their verified composition into a smaller literal machine, together with a new uniform schematic G certificate. See [ATTRIBUTION.md](ATTRIBUTION.md).

## Exact theorem and proof boundary

For the delivered table `M222`, the ordinary mathematical proof establishes

```text
ZFC proves:
  (there is a finite blank-start halting trace of M222)
    iff (there is a finite ZFC proof of contradiction).

Hence ZFC proves:
  M222 does not halt on the blank tape iff Con(ZFC).
```

The proof composes exact initialization and universal binary runtime, the seeded proof enumerator, exact G/old-calculus proof translations, the restricted equality interpretation, and the conditional-K/ZFC consistency calibration. The report handles the initializer's nonzero proof counter explicitly by a cofinal family of resetting proof prefixes.

**There is no newly compiled Rocq or Lean endpoint for this 222-state table.** The Python certificates are executable ordinary mathematical proofs and calculations. The inherited K230 development and conditional-K interpretation are documented dependencies; they are not recompiled by this packet. This packet does not prove ZFC consistent, does not assert unconditional non-halting, and makes no minimality or two-sided-independence claim from bare consistency.

## Reproduce offline

Use Python **3.10+**, with assertions enabled. There are no third-party Python dependencies and no network requests.

From this directory:

```bash
python3 -B reproduce.py --output-dir ../k222-replay
```

Choose an empty output directory **outside** this packet. Do not use `-O` or `PYTHONOPTIMIZE`. The default performs a fresh derivation of all unbounded runtime cases. The observed replay took about 97 seconds in the preparation environment; timing varies by host.

The command checks the distribution manifest; reconstructs the source and 224-state parent; checks the exact emitter and full source control flow; applies and checks both folds; generates the canonical, native, and inherited-label tables; checks exact sparse/dense blank startup; rejects invalid fold controls; regenerates and independently checks the uniform G proof; independently checks the inherited finite G proof; and rederives the runtime certificate on the final literal table. It compares all reconstructed primary artifacts and runtime case bytes with the retained packet.

For a faster integrity and reconstruction check:

```bash
python3 -B reproduce.py --quick --output-dir ../k222-quick
```

Quick mode still reconstructs source and tables and repeats emitter, fold, bootstrap, and logic checks. Its final phase audits the stored runtime cases, hashes, guard coverage, row coverage, and positive durations; it **does not freshly derive** the runtime cases. This distinction is explicit in its output receipt.

### Verification results

| Check | Result |
| --- | --- |
| Exact source | 4,581 primitive occurrences; 209 distinct subtrees; depth 38; maximum zero run 6 |
| Guarded source control flow | Two independent resolvers agree on all 5,956 cases |
| Decoder compound entries | 4,579 checked |
| Arithmetic emitter | Symbolic all-natural constructor equality; full primitive word and control-flow binding |
| New uniform G proof | 57 nodes; 53 formulas; 8 exact endpoints; separately implemented checker |
| Inherited concrete G proof | 315 nodes; 290 formulas; 33 endpoints; independently rechecked |
| Final folds | Exact one-step whole-tape simulation on arbitrary initial binary tapes |
| Blank initialization | 409,835 transitions; canonical dispatcher 22; head −5; complete tape equality |
| Fresh unbounded runtime | **5,956 cases**, **1,443,614 symbolic rules**, **all 444 rows**, minimum actual instruction duration 13 |

The runtime proof quantifies over all nine natural primary registers, both decrement guards, arbitrary natural extra gap and first spare value, and an arbitrary finite remaining spare list. Four literal-table induction schemas support unbounded unary-block/list scans. The 4,000-rule proof-search limit does not bound register values or actual executions. The source's semantic contracts and symbolic rule soundness remain part of the ordinary mathematical proof boundary.

The complete initial frame is recorded in `machine/bootstrap.json`: logical registers `(3,0,0,0,3,0,0,0,0)`, 167 spare registers each equal to 1, zero gap 181, and 351 one-cells. Every unlisted tape cell is zero.

## Artifact guide

| Path | Purpose |
| --- | --- |
| `machine/candidate222.tm` | Canonical 444-row table, start 0, halt 222 |
| `machine/candidate222.csv` | Same transitions in CSV |
| `machine/candidate222.k.tm` | Native K labels, start 0, dispatcher 84, halt 254 |
| `machine/candidate222.legacy.tm` | Inherited runtime labels, start 95, dispatcher 96, halt 254 |
| `machine/sites.json` | Exact source instruction sites |
| `machine/parent224.k.tm` | Compiled parent before the two final folds |
| `machine/state_map.json` | Verified label bijections |
| `inputs/` | Small hash-pinned upstream inputs needed for offline replay |
| `code/` | Construction and verification code, with retained runtime modules |
| `theory/` | Uniform proof/certificate/checkers and complete inherited interpretation notes |
| `evidence/` | Fresh replay receipts/logs, emitter evidence, and complete runtime cases |
| `research/` | Supplementary bounded local searches, source, fixtures, logs, and limits |
| `report/` | LaTeX, PDF, complete transition table, and report builder |
| `PROVENANCE.json` | Pinned repositories, source inputs, output hashes, and scope |
| `MANIFEST.sha256.json` | Byte counts and hashes for every retained file except itself |

To rebuild the report, install a LaTeX distribution with the packages listed in `report/main.tex`, then run:

```bash
python3 -B report/build_report.py --output-dir ../k222-report-build
```

It regenerates the complete transition table from the canonical machine and invokes `pdflatex` twice. PDF rebuilding is separate from the machine proof replay.

## Further search and incorporation

The supplementary C++17 searches found no 221-state survivor in the specified local families. Their radii and block bounds, coordinated-helper restrictions, and finite discovery-only fixture are documented in `research/README.md`. This is not a lower bound. The main theorem does not depend on the negative search results.

For incorporation, keep this packet intact under a research contribution directory, or adapt its relative paths while preserving the machine/source hashes and proof-status qualification. Its canonical table is ready for a `candidate-k222` intake. Retain the inherited notices and distinguish this ordinary mathematical endpoint from any future proof-assistant endpoint.

Pinned ProveIt snapshot: [`6ab3e41e4dcddfbd7f843bdf4be48ae5c7ba2430`](https://github.com/VladimirReshetnikov/ProveIt/tree/6ab3e41e4dcddfbd7f843bdf4be48ae5c7ba2430/Computability/BusyBeaver/Research/ZFC). K230 dependency: Elliot Glazer's [`3142e4dd980f0be12f4abb636c4ae2528afc17eb`](https://github.com/elliotglazer/k230-rocq/tree/3142e4dd980f0be12f4abb636c4ae2528afc17eb).
