# Arithmetic Circuit Expansions for Cubical Counts

A research article developing a fourth-order strengthening of Gowers' Lemma 3.10,
exact fourth- and fifth-order Fourier/torsion corrections, sharpness examples,
and a formalization roadmap for the ProveIt repository.

Prepared 6 October 2026.

## Contents

- `article.pdf`: the typeset article.
- `article.tex`: complete, self-contained LaTeX source, including bibliography.
- `build.sh`: rebuilds the PDF using latexmk or three pdflatex passes.
- `SOURCE_AUDIT.md`: repository checkpoint, exact inspected source identifiers,
  and public literature references.
- `verification/verify_expansion.py`: standard-library exact checks of 24
  finite-group cube examples, coefficient identities, and the two-frequency
  U^3 polynomial certificate.
- `verification/results.json`: output of the successfully executed checks.
- `verification/verify_lattices.py`: optional SymPy exact Smith-normal-form
  census of all four- and five-vertex subsets of the 3- and 4-cubes, plus the
  determinant-5 certificate.
- `verification/lattice_results.json`: output of the successfully executed
  lattice checks, including the SymPy version.
- `verification/requirements-optional.txt`: optional dependency used for that census.

## Building and checking

From this directory:

```sh
sh build.sh
python3 verification/verify_expansion.py
python3 -m pip install -r verification/requirements-optional.txt
python3 verification/verify_lattices.py
```

The first verification script has no external Python dependencies. The lattice
census is optional and uses SymPy; it may take longer. Both scripts overwrite
only their own JSON result files. Neither script accesses the network or changes
a repository. The LaTeX build uses a conventional TeX installation with
amsmath, amsthm, mathtools, geometry, lmodern, microtype, booktabs, enumitem,
fancyhdr, xcolor, and hyperref.

## Main mathematical statements

For a finite abelian group G, d >= 2, m = 2^d, real mean-zero f, delta >= 0,
and epsilon = ||f||_(U^d), the excess of the normalized cube count over delta^m
starts at order four:

    0 <= C_d(delta+f) - delta^m
       <= sum_(s=4)^m binom(m,s) delta^(m-s) epsilon^s.

For d >= 3, the article identifies the fourth and fifth homogeneous terms
exactly. Their four multiplicities are

    P_d = 2^(d-2) Stirling2(d+1,3),
    T_d = 2^(d-2) Stirling2(d+1,4),
    Q_d = 2^d     Stirling2(d+1,4),
    S_d = 2^d     Stirling2(d+1,5).

The first two multiply fourth Fourier moments, with the second restricted to
order-two characters. The next two multiply explicit quintic Fourier
statistics, with the last restricted to order-three characters. The remaining
error is bounded by an explicit sixth-order binomial tail. The article proves
sharpness of the fourth, fifth, and sixth perturbative orders, including
transfer from weighted functions to sets, and constructs a six-vertex
configuration with an isolated order-five torsion contribution.

## Status and limits

The article gives mathematical proofs of its general statements. The finite
checks were actually executed and passed; they are not a proof of all
infinite families. The two-frequency exact polynomial also has a transparent
exhaustive finite certificate in the appendix and script.

No Lean compiler was available. No new Lean theorem was kernel-checked, no
Lean code is presented as verified, and no repository files were modified.
The formalization section is a proposed implementation plan tied to an
inspected checkpoint. The manuscript is unrefereed; historical originality of
its local identities has not been established. It does not claim a new final
quantitative bound for Szemeredi's theorem or a new solution of the paper's
old progression conjectures.
