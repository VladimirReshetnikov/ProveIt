# Pointwise and summatory bounds for OEIS A290268

This companion proves counting consequences of the established derivative-coefficient facts. It does not assume the global A290268 support conjecture.

The pointwise result, valid for every integer N≥e^10, is

a(N) ≥ 3N²/8 + (N/2)logN − (N/2)loglogN − 5N/4.

An exact parity-sensitive row count also yields

sum_(N=0)^X a(N) ≥ 11X³/72 + 5X²/6 − O(X),

and the lower limit of the average of a(N)/N² is at least 11/24. This average statement is not interpreted as a pointwise lower bound 11N²/24, and the conjectural equivalent a(N)~N²/2 is not proved.

The report states an exact finite summatory inequality, gives all indexing and hole-count details, and explains a narrowly scoped sharpness limitation of the integer counting information. The abstract sharpness pattern is explicitly not asserted to represent actual derivative coefficients.

## Files

- `article.pdf`: six-page companion report
- `article.tex`, `sharpness.tex`: editable LaTeX sources
- `verify_counts.py`: exact direct-count, parity-split, bulk-prefix and rational-generating-function checks
- `verification.txt`: recorded successful output
- `requirements.txt`: dependency for symbolic rational-function verification
- `build_local.sh`: local pdfLaTeX build wrapper

Run `python verify_counts.py` from the extracted folder. The program raises errors if a check fails and writes no external state. It checks the finite counts through X=180 and an exact rational-function identity establishing the displayed quasipolynomial for all X. These checks supplement the written counting proofs.

The proofs received independent mathematical review, and all six PDF pages were rendered and visually inspected. The results are not formally verified in Lean or externally refereed. The pointwise theorem uses Theorem 7.2 of the companion “Depths Five and Six Nonvanishing for OEIS A290268,” while the summatory theorem follows from the pinned ProveIt source's existing Mellin row-zero bound. Source references and the exact repository commit appear in the bibliography.

A standard TeX distribution can compile `article.tex` with pdfLaTeX twice. The build wrapper also handles the local format/map setup used during preparation.
