SHARP FINAL COEFFICIENT BOUNDS FOR DIRECTED CORES WITH UNIVERSAL SINKS
October 1, 2026

RESULT
For an arbitrary loopless directed r-core (r >= 4), with every core vertex
pointing to every vertex of an independent sink set, count feasible ordered
pairs of disjoint matching endpoints once. Independent nonnegative tail and
head activities are allowed. If the top coefficient gamma_r is positive,
the actual degree is r, and m denotes the number of positive sink-head
activities. The sharp bound is

 gamma_(r-1)^2 >= K(r,m) gamma_(r-2) gamma_r,
 K(r,m) = 2 r^2 (m-r+2) / [(r-1)^2 (m-r+1)].

The article gives the ordinary proof, exact equality characterization,
finite-m sharpness, and the optimal uniform constant 2 r^2/(r-1)^2.
At r=4 this strengthens the last degree-four rank-ULC gap. It does not prove
the middle gap or general weighted degree-four rank-ULC.

CONTENTS
 article/universal-sink-last-gap.pdf  Four-page readable theorem and proof
 article/universal-sink-last-gap.tex  Editable mathematical source
 checker/producer/                   Exact Hall-based producer checker
 checker/independent/                Independent exact Hall-based checker
 audit/                              Mathematical review and reference receipts
 proof-notes/                        Expanded proof note and six-term identity
 qa/                                 All-page visual review and render evidence
 verify.py                           Integrity and fresh exact replay driver
 build.sh                            Optional PDF rebuilding script
 SHA256SUMS                          Package file hashes

VERIFY
Python 3.10 or later and its standard library suffice. No numerical solver,
third-party Python package, network, or other research archive is required.

 python verify.py

This first verifies package file hashes, then copies each checker into a
new temporary directory and runs it from scratch. Stored receipts are not
accepted as evidence of a fresh run. Typical runtime is about one minute.
For a persistent fresh report, use a destination of your choice:

 python verify.py --output /tmp/universal-sink-fresh-replay.json

For integrity alone (not mathematical or computational verification):

 python verify.py --mode hashes

The theorem has an ordinary proof in the article. The finite checkers are
corroboration, not a replacement for that proof. Their Hall tests count
endpoint pairs once, and their arithmetic is exact. The independent checker
imports no producer code. Audit paths naming the earlier research directory
are historical provenance, not executable dependencies.

BUILD
The supplied PDF is ready to read. Rebuilding needs a standard TeX Live
installation with pdflatex, amsmath, amsthm, lmodern, microtype, and hyperref.

 bash build.sh

Optional environment settings in build.sh support the original research
container. They are unnecessary on a normally configured TeX installation.
A rebuild changes PDF metadata and therefore changes its recorded hash;
perform verification before rebuilding, or use an extracted working copy.

BOUNDARIES
The effective sink count excludes zero head activities. If gamma_r=0,
the r-indexed inequality is trivial and is not the Newton inequality at a
smaller surviving degree. No real-rootedness, stability, formalization,
external publication, or novelty/priority claim is made.
