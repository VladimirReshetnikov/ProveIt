SHARP EXTREMAL REFINEMENTS IN GOWERS'S SZEMEREDI FRAMEWORK
Secondary cube asymptotics, arrangement stability, and polynomial supersaturation
Research report prepared for Vladimir Reshetnikov — 6 October 2026

START HERE
  gowers_extremal_refinements.pdf
  gowers_extremal_refinements.tex

The PDF is the complete article. The LaTeX source is a single article file
with an embedded bibliography; its only external document asset is the
included figures/cube_convergence.pdf.

MAIN RESULTS
1. Exact secondary coefficient (9/4)^(1/3) in the centered U^3 cube
   extremal problem, a uniform remainder, and two-harmonic rigidity.
2. A torsion distinction: the next correction has sharp exponent 6 on
   exponent-five groups; its optimal coefficient remains a research question.
3. A sharp small-defect coset approximation for near-maximal additive
   energy and cube collisions, plus complete arrangement equality
   classifications and improved geometric/cardinality denominators.
4. Exact pointwise and global supersaturation for polynomial-coordinate
   symmetric colorings, with equality geometry and a prime-field gap.

The article includes complete proofs, worked examples, the correspondence
with the inspected Lean sources, and 12 prioritized further research topics.
Classical minimum-support theorems and norm constructions are credited.

BUILD THE PDF
Run from this directory with a standard pdfLaTeX installation:

  pdflatex -halt-on-error gowers_extremal_refinements.tex
  pdflatex -halt-on-error gowers_extremal_refinements.tex

Alternatively, latexmk -pdf gowers_extremal_refinements.tex may be used.
No BibTeX or Python step is required to build from the supplied sources.

REPRODUCE THE CHECKS
The required Python packages are NumPy and Matplotlib:

  python3 verify_results.py
  python3 verify_certificates.py
  python3 make_figures.py

verify_results.py:
  Exact combinatorial checks, explicitly labelled numerical Fourier
  diagnostics, exhaustive small coloring/label checks, and 90-digit
  evaluations of the exact two-harmonic model. Fixed random seed 20261006.

verify_certificates.py:
  Standard-library-only exact rational and integer-polynomial checks of
  all 255 nonempty cube supports and all order-five/order-seven T slots.

make_figures.py:
  Recreates the PDF/PNG scientific figure from verification_results.json.

RECORDS
  verification_results.json    Main verification outcomes
  certificate_results.json     Exact support and torsion certificates
  source_manifest.json         Inspected revision, paths and Git blob hashes
  environment.json             Versions used for this build
  quality_checks.json          PDF compilation and package checks
  SHA256SUMS                   Checksums of the deliverable files

SOURCE BASELINE
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 9ea383e9b28d885a936d5d681cd5584fffd2cb29
Paper: Combinatorics/Ramsey/Papers/sz-thm-gowers-proof
Lean:  Combinatorics/Ramsey/Lean/GowersSzemeredi

The original paper and Lean repository are referenced, not redistributed.
All inspected local source files were checked against their upstream
Git blob identifiers.

PROOF STATUS
The general results are supported by the written proofs. Finite checks
and internal independent reviews supplement those proofs. No new Lean
formalization or Lean build was performed in preparing this article.
External peer review and an exhaustive historical-priority search have
not been performed. The report does not claim a new global quantitative
bound for Szemeredi's theorem.
