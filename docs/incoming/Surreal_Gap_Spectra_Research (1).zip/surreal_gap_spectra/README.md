# Beyond the First Gap
## Exact Spectra and Boolean Families of Old Surreal Fields

Research report prepared with ChatGPT for Vladimir Reshetnikov, 28 September 2026.

## Read the article

`article.pdf` is the compiled, 26-page article. `article.tex` is its standalone
LaTeX source, with an internal bibliography and clickable references.

The baseline is VladimirReshetnikov/ProveIt at commit
`e21766d04c2b8a9b2cdba0cd43e563024b3bd1b9`, particularly the report
`Algebra/SurrealNumbers/docs/foundations-and-computation/surreal-fields-across-universes/`.

## Main result

Start with a ZFC + GCH ground M. Put kappa_n = aleph_(n+1),
lambda = aleph_omega, and take the full-support product of the ground
Add(kappa_n, 1) forcings. Let W be the full extension and M_A the intermediate
model retaining exactly the coordinates in A, for A a subset of the natural
numbers. Write B for the complement of A.

Theorem 9.1 computes the entire diagonal gap-character spectrum of the old
surreal field No^(M_A), as viewed in W:

    {kappa_n : n belongs to B}
    union {lambda^+ if B is infinite}.

There are no asymmetric genuine set-presented gaps in these full old fields.
The first missing coordinate alone determines saturation, while the complete
spectrum recovers A. Taking all A with 0 not in A gives continuum many pairwise
nonisomorphic fields with the same saturation spectrum and the same real field.
In this construction the continuum is aleph_1, not an arbitrary cardinal.

## Other results

* Theorem 4.1: external cofinality pushforward, including extensions that change
  cardinals or cofinalities.
* Theorem 5.3: the complete external gap spectrum for a single Add(kappa, 1)
  extension is {(kappa, kappa)}, without GCH.
* Theorem 7.1: finite relative Boolean cubes, without the singular-limit input.
* Theorem 11.3: all nonprincipal gap pairs at the common cutoff
  theta = lambda^(++), including asymmetric boundary pairs; the fields all
  have size theta.
* Theorems 12.1 and 12.3: nonconjugate involutions of one algebraically closed
  set field, and of one full surcomplex class field respectively. They agree
  with ordinary complex conjugation on the common complex field.

Section 13 maps the results to repository Questions 19.2, 19.4 and 19.7.
Section 14 gives ten further research questions. Appendix A separates proof
inputs from computational checks.

## Mathematical status and attribution

This is a proposed research contribution with written proofs. It has not been
independently refereed or formally verified in Lean, and priority is not
certified. The article does not claim to classify all fields with equal full
gap spectra or to solve general fresh-spectrum realization problems.

The singular-limit witness is an explicitly cited published input:
Fischer–Koelbing–Wohofsky, *Fresh function spectra*, Corollary 4.21, based on
Shelah's Cohen-algebra embedding theorem. It supplies the lambda^+ term for an
infinite missing set. The relative-model exclusion proof is given in full.
The fresh-sign correspondence is credited to the repository and reproved in
the form needed here. Standard real closed and algebraically closed field
facts are imports, not new claims.

The full-class transport uses GBC with Global Choice and the stated ground
predicates. The set-field transport uses ordinary ZFC/Choice only, within the
specified forcing configuration. No preservation of valuation, exponential,
derivation, simplicity or omnific integers is asserted for the transported
involutions.

## Reproduce

Requirements: Python 3.10 or later; a LaTeX distribution with latexmk,
pdflatex, Latin Modern, AMS packages, microtype, enumitem, xurl, fancyhdr,
longtable and hyperref.

    python3 verify_finite.py --output finite_checks.json
    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

Alternatively run `make`. `make clean` removes TeX intermediate files and
keeps the PDF.

The recorded run passed 619,026 finite assertions. These check finite sign
cones, fixed-block codes, and index-set identities ONLY. They do not verify
forcing, freshness, cofinalities, saturation, pcf theory or class arguments.
See the explicit exclusions in `finite_checks.json` and `PROOF_STATUS.md`.

## Files

- `article.tex`, `article.pdf`: article and source.
- `PROOF_STATUS.md`: claims, imports and review priorities.
- `verify_finite.py`, `finite_checks.json`: executable finite regressions and run.
- `pdf_validation.json`: build and PDF-layout checks, not mathematical evidence.
- `Makefile`: reproducible build/check targets.
- `README.md`: this guide.

No repository files were modified, and no external PDF or font files are
redistributed in this package.
