SHARP OPERATOR MIXING AND FIVE-BLOCK REFLECTION-POSITIVE LAWS
FOR SQUARE CONSTRAINTS

Research report prepared for Vladimir Reshetnikov
7 October 2026

MAIN DELIVERABLES

sharp_operator_mixing.pdf       Compiled article.
sharp_operator_mixing.tex       Main editable LaTeX source.
sections/                      Complete text, proofs, questions, references.
figures/                       Vector PDF figure included by the article.
verification/                  Reproducible small finite checks and outputs.
SOURCE_MANIFEST.json            Pinned source revisions and exact paths.
build.sh                       Portable LaTeX build command.

BUILD

From this directory:

    sh build.sh

This requires a normal LaTeX installation with latexmk and pdfLaTeX, plus
the packages named in sharp_operator_mixing.tex. No network access,
shell-escape, bibliography service, custom fonts, or Python is needed
to compile the article. References are included in the source.

Without latexmk:

    pdflatex -interaction=nonstopmode -halt-on-error sharp_operator_mixing.tex
    pdflatex -interaction=nonstopmode -halt-on-error sharp_operator_mixing.tex
    pdflatex -interaction=nonstopmode -halt-on-error sharp_operator_mixing.tex

The figure PDF is included. To regenerate it, install NumPy and Matplotlib:

    python verification/make_figure.py

VERIFICATION

    python verification/check_bounds.py
    python verification/check_spectra.py

The scripts print JSON. Recorded outputs are verification/results.json
and verification/spectra_results.json. See verification/README.txt.
Numerical checks supplement, and do not replace, the analytical proofs.
No full enormous tuple law is enumerated and no Lean certification is claimed.

MATHEMATICAL SCOPE

The article proves a sharp bounded-kernel operator theorem, exact finite
spectral and conditional examples, a parameterized finite reflection-positive
construction, and a fractional Euler-moment recurrence. The key repository-
specific improvement is from O_m(p^(-1/8)) to O(p^(-1/2)) list mixing.
Seventeen blocks retain the original p^(-4) exceptional-mass target.
Five blocks suffice for the revised fractional-moment interface.

The finite architecture is adapted from the cited OpenAI manuscript and
reproved with explicit new weights. Classical telescoping, character sums,
and reflection positivity are attributed. The report does not claim to
establish worldwide publication priority for the combined result.

The integer square-difference application retains explicitly stated analytic
hypotheses. The article does not claim a new numerical global exponent
without reinstantiating those remaining constants and estimates.

REPOSITORY INTEGRATION

Keep this directory's relative layout when adding it to ProveIt. A possible
location is a new research subdirectory under:

    Combinatorics/Ramsey/Research/

The source manifest pins the reviewed revisions so future repository changes
do not alter the stated comparison. Theorem labels are stable descriptive
labels suitable for cross-reference or later formalization. No existing
ProveIt files were changed, and no remote commit or publication was made.

PROVENANCE

This report was produced through AI-assisted mathematical derivation,
targeted source review, internal adversarial proof review, and finite
numerical checks. It has not undergone external peer review.
Source files from the reviewed repositories are not redistributed in this
archive; the manifest and bibliography link to the pinned originals.
