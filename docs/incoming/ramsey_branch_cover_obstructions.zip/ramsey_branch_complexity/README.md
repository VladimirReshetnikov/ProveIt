# Sharp Branch-Cover Profiles

## Main result

The article gives a mathematical counterexample to the **two-input catalogue formulation** of `lemma_16_10` in the pinned ProveIt Section 16 source. At `k = theta = gamma = 1`, both bundled premises hold at arbitrarily large prime moduli while the required output cover fails. This strengthens the previously documented failure of a numerical closing comparison into a failure of the implication itself.

The construction is a full-domain function `F(h,y) = a(y)` with a balanced finite-alphabet word. Its fixed-final-coordinate sections are constant, and its fibres have exact constant-graph covers. An exact polynomial list-cover law proves that arbitrary partitions into long boxes cannot compress the branch count sufficiently.

The article also proves exact optimizer/stability laws, adaptive product-box extensions, realization of arbitrary branch-mass profiles, a stronger growing-alphabet scale, deterministic construction by conditional expectation, and endpoint characterization of the full-domain product property.

## Scope

This is **not** a disproof of Szemerédi's theorem or of the complete contextual construction in Gowers's paper. The full-domain product property at gamma = 1 is shown to force genuine multiaffinity; our witnesses fail that stronger condition. No improved global progression-free bound is claimed. The new counterexample is proved in the manuscript but is not Lean-kernel-checked or independently peer reviewed.

Snapshot: `588552b79497c93d0e2f3a3f9224fd7681e8d396`.
Section 16 blob: `c5c7d2bee91bc589de1d3082429f7ee3597e99f9`.

## Files

- `article.tex`, `article.pdf`: self-contained article and compiled PDF.
- `code/verify.py`: exhaustive finite tests and a complete F_257 example.
- `code/construct_word.py`: exact conditional-expectation construction.
- `data/verification.json`, `data/construction.json`: executed results.
- `SOURCE_AUDIT.md`, `FORMALIZATION_PLAN.md`: provenance, boundaries, integration guidance.
- `Makefile`: build and verification targets.

Run `make pdf` to compile with latexmk and pdfLaTeX, or run pdfLaTeX twice. Run `make check` to reproduce the exact finite checks. The scripts require only the Python standard library; Python 3.10 or later is suitable. They do not instantiate the astronomical parameters of the source-specific counterexample. The conditional-expectation algorithm runs in time polynomial in the field size, not its bit length.

Suggested new repository location:
`Combinatorics/Ramsey/Research/GowersSzemeredi/branch-cover-obstructions/`.

No repository files have been changed. Review and formalize the negative theorem before changing the catalogue's proof-status ledger. Preserve the old formulation for traceability rather than silently replacing it.
