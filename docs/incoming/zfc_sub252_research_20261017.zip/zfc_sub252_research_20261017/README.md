# Searching below 252 states

Research prepared for Vladimir Reshetnikov, 17 October 2026.

**Outcome: no complete machine below 252 working states with the requested ZFC consistency equivalence was established.** This packet contains new mathematical reductions, executable certificates, a reproduced 252-state baseline, and a concrete unsuccessful compilation experiment. It is suitable for incorporation as a research directory, without changing the existing candidate or its theorem endpoint.

The complete exposition and ordinary mathematical proofs are in **`report.pdf`**, with editable LaTeX in **`report.tex`** and the search-count macros in `metrics.tex`.

## Target and proof status

The requested target is a deterministic one-tape, two-symbol Turing machine `M`, run on a completely blank tape, with fewer than 252 working states and an ordinary ZFC proof of

\[
\neg\operatorname{Halt}(M)\ \longleftrightarrow\ \operatorname{Con}(\mathrm{ZFC}).
\]

Every initialization state counts. The halting label has no outgoing rows. Prepared tapes and weak-universality conventions are not used.

The pinned ProveIt baseline has a closed external Lean endpoint. This packet distinguishes that endpoint from an internally serialized ZFC derivation and the repository's stronger PA-internalization project. No new Lean or Coq build was performed here. The report gives a direct set-coded-model route to an ordinary internal-ZFC argument and states the exact additional simulation obligations for a future smaller machine.

## Main results

| Result | Evidence and limits |
|---|---|
| Exact semantic fragment | Universal validity of a quantifier-free membership/equality formula is equivalent, provably in ZFC, to validity on finite acyclic equality/membership patterns. Every rejected pattern yields an induced membership realization by explicit hereditarily finite sets. |
| Broader startup recognition | Below 65,536, the combined recognizer accepts 13,962 formula codes and 4,082 formula-stack codes, adding 446 and 31 respectively over the previous sufficient pattern recognizer. This compares recognizers, not theorem sets. |
| Transfer-free interpretation changes | A move into a provably zero destination can be implemented by changing the physical-slot interpretation. The literal source has 972 transfer occurrences, of which 970 have the needed external-entry fact. |
| Exact allocation certificate | Nine physical slots; all 5,480 coarse edges checked symbolically; 598 transfers erased and 372 retained; unused primary slots remain zero. Independent mask, macro and progress audits are included. |
| Complete negative compiler result | Source sharing grows from 203 DAG nodes to 917, or 778 after checked compaction. The same complete assembler emits 314 working states for its original-source control and 888 for the coalesced control. Both literal tables and blank-prefix audits are included. |
| Broader local action search | Joint changes of write, move and target on two incoming rows define 46,368,736 recipes. The retained partial run pruned 2,825,507 checker recipes, left 43,543,229 in its frontier, and found no survivor. |

The wider semantic startup theorem applies to the original runtime. The optimized allocation was certified from the all-zero source root. Combining a dirty startup with that specialized allocation requires a new invariant proof; the two relaxations cannot simply be combined.

## Contents

| Path | Purpose |
|---|---|
| `report.tex`, `metrics.tex`, `report.pdf` | Complete mathematical report, proofs, state accounting and source references. |
| `reproduce.py` | Offline end-to-end replay with frozen-output comparisons. |
| `research/logical_reduction/` | Semantic seed implementation, census and detailed proof notes. |
| `research/machine_reduction/` | Value/affine analyses, allocation, compiler experiments, frozen tables and exact hashes. |
| `research/proof_audit/` | Independent HF embedding, source-mask, transfer-boundary, silent-progress and compaction audits; proof-boundary review. |
| `research/joint_actions/` | Coordinated incoming-action search and its explicit partial frontier. |
| `evidence/` | Baseline replay and final packaged reproduction summary. |
| `vendor/ProveIt/` | Required pinned source files and retained context/attribution. This is a partial offline materialization, not a complete repository or Lean build. |
| `provenance.json`, `MANIFEST.sha256` | Original locations, immutable revision and exact deliverable digests. |
| `LICENSE`, `ATTRIBUTION.md` | New-material license and retained source attribution. |

The full 1,500,000-state dynamic-role exploration list is omitted. `dynamic-renaming-summary.json` retains its summary and all 972 transfer-entry records; the script can recreate the large list. No sub-252 candidate table is hidden in the packet. The 314- and 888-state files are explicitly diagnostic controls.

## Verified offline reproduction

Use Python 3.10 or newer with assertions enabled; the packaged replay was tested with Python 3.12. Only the Python standard library is needed. No network access, solver installation, Lean or Coq is required for these finite computations.

From the extracted directory:

```sh
python3 reproduce.py --output-dir /tmp/zfc-sub252-replay
```

Use a new or empty output directory outside the packet. The runner verifies the delivered file manifest, regenerates the exact baseline, repeats the semantic census and independent HF checks, recomputes the mask invariant, regenerates the allocation and both complete compiled controls, and checks their frozen byte hashes. It also runs independent source-mask, transfer, silent-progress and control-compaction checks and verifies the saved search accounting. Generated logs and JSON are written under the selected output directory; the delivered certificates are unchanged.

The main frozen replay is deterministic in its table and certificate bytes. Wall-clock timings and newly measured mask-file timing metadata vary. Optional broad searches are not rerun by default.

For an integrity check alone:

```sh
python3 reproduce.py --verify-only
```

To build the PDF:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

This requires a conventional LaTeX installation with the packages listed at the start of `report.tex`. No bibliography download or shell escape is needed. The delivered PDF was compiled and visually inspected.

### Optional research runs

The machine-reduction notes document each experiment and its arguments. Work in a copy of that directory when exploring variants, because its research scripts write their results beside the scripts.

```sh
python3 research/machine_reduction/replay.py vendor/ProveIt
python3 research/machine_reduction/value_analysis.py 3 4 8 16 32
python3 research/machine_reduction/affine_analysis.py --reduced
python3 research/machine_reduction/coalescing_family_search.py
```

The first optional command regenerates delivered research outputs in place; the top-level `reproduce.py` instead works in a separate copy. The selective-family search explores 232 declared choices, not every allocation.

To continue the saved joint-action frontier, choose a new output path:

```sh
python3 research/joint_actions/search_joint_actions.py \
  --repo vendor/ProveIt \
  --resume research/joint_actions/joint-actions-degree2-v2.json \
  --seconds 900 --fuel 1000 \
  --output /tmp/joint-actions-next.json
```

The saved run consists of a 243-second checkpoint followed by a 900-second continuation. The continuation adds exact symbolic-cycle detection. It fully exhausts deletion labels 107 and 14 in this diagnostic, partly explores label 32, and leaves the other declared groups in the explicit frontier. A fuel failure or unsupported symbolic operation is a diagnostic rejection; it is not a proof of semantic inequivalence or minimality. Any positive must pass every conditional instruction case and a separate exact blank-start proof.

## Source pin and incorporation

Repository: [VladimirReshetnikov/ProveIt](https://github.com/VladimirReshetnikov/ProveIt).

Immutable revision: `beb2c633ae57a0883d28fb6d0c75342d08cfdeda`.

Baseline: [candidate-permutation252](https://github.com/VladimirReshetnikov/ProveIt/tree/beb2c633ae57a0883d28fb6d0c75342d08cfdeda/Computability/BusyBeaver/Research/ZFC/candidate-permutation252).

| Exact baseline file | SHA-256 |
|---|---|
| `zfc_permutation252.tm` | `8dae0c2359aa8bf87d32543b9e53e1f87fe4716c016a4e2fd174bfe09e520797` |
| `zfc_permutation252_old.tm` | `939f99d602c8f7057517c4369279de99e30827050fc743581df83f26aaf1b713` |

The reproduced baseline audit passes all 8,391 conditional affine instruction cases and the full 82,552-transition blank prefix. It records all nine logical zero registers, 65 physical spare blocks, the nonzero spare at index 8, and the entire blank exterior. The original upstream audit's `remaining_obligations` strings describe that audit's limited scope and historical development; consult the pinned candidate README and the report for the later proof endpoint.

A suitable incorporation location is a new sibling research directory such as `Computability/BusyBeaver/Research/ZFC/semantic-seeds-register-roles/`. Retain the current candidate unchanged. The most useful next experiments are (1) startup search using the wider semantic predicate on the original runtime, and (2) allocation search that directly charges decoder cloning and preserves shared operands. The complete 314-to-888 comparison provides a reproducible failure case for improving that compiler objective.
