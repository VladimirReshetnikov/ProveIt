# Lexicographic Well-Orders of the Surreals
## Prefix completions, generalized Baire models, and the set–class boundary

Research manuscript prepared for Vladimir Reshetnikov, 3 October 2026.

The PDF has 32 pages, including the title page, contents, appendices, and references.

## Contents

- `article.pdf`: the complete article.
- `article.tex`: standalone LaTeX source, with an internal bibliography.
- `code/finite_checks.py`: standard-library Python regression tests.
- `data/finite_checks.json`: the recorded passing run.
- `data/build_validation.json`: PDF and typesetting validation record.
- `SOURCE_AUDIT.md`: repository pin, inspected sources, and proof-status limits.
- `build.sh`: rerun the tests and compile the article.
- `SHA256SUMS.txt`: checksums of the delivered files other than this manifest itself.

## Main results and scope

For an infinite set X of cardinality μ, the minimal enumeration space is
P_μ(X) = Bij(μ, X), with the topology of agreement on bounded initial segments.
For a μ-thick numerical alphabet, that topology equals the lexicographic order topology.
Surreal birthday cutoffs satisfy the thickness condition at their actual cardinality
μ = 2^{<κ}; μ is not silently replaced by κ.

The forward uniform completion of P_μ(X) is Inj(μ, X). The missing points are exactly
nonexhaustive injective words. This is not its Dedekind completion, which also has
cylinder edges and other cuts.

For every infinite regular μ, an exhaustion-adapted tree gives a homeomorphism
P_μ(X) ≅ (μ^{<μ})^μ with the bounded topology. No hypothesis μ^{<μ} = μ is required.
The statement is topological, not an order-isomorphism claim and not a forward-uniform
isomorphism claim.

For countable dense alphabets, including No_{<ω}, the space has an explicit complete
compatible metric and is homeomorphic to Baire space. Its Dedekind completion is the
real line, but its complement is a dense meager F_sigma set of continuum cardinality.
It is consequently not order-isomorphic to the irrationals.

At singular cardinalities, the article proves exact boundedness criteria for continuity
of right translation and inversion. It isolates the boundedness-preserving subgroup
H_μ and proves a complete compatible two-sided uniformity there. Complete metrizability
of the full original topology at uncountable singular μ of countable cofinality is left
as an explicit question; a finer complete topology does not settle that question.

For global enumerations, the article works with uniformly coded families in GBC and
never forms a same-level class of classes. Every uniformly set-indexed prefix-Cauchy
net is eventually constant. Class-indexed prefix reconstruction yields injective
Ord-words, and inverse stabilization restores exhaustiveness. Arbitrary non-set-like
class well-orders are treated separately through an elementary common-prefix formula.

There are twelve proposed research questions, along with a universe-sensitive Lean plan.

## Status

This is an AI-assisted, unrefereed mathematical manuscript, not a historical-priority
claim. No new Lean formalization or kernel verification is claimed. The repository was
not changed or built. Mathematical proofs, inherited research results, finite tests,
and remaining questions are explicitly distinguished.

The tests check finite mechanisms only. They do not verify the infinite completion,
regular/singular distinction, or class-theoretic theorems.

## Build

Requires Python 3.10+ and a TeX distribution with the packages named in the preamble
(including newtx, tcolorbox, and needspace). Then run:

```sh
sh build.sh
```

Alternatively:

```sh
python3 code/finite_checks.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The source has an internal bibliography; no BibTeX database, image download, network
connection, or bundled font file is needed. PDF timestamps and TeX installation details
can change byte-level output even when the mathematical content and layout are unchanged.
Rebuilding also means the original delivery checksum manifest no longer describes the
newly generated PDF.
