# A 247-state Turing machine for ZFC consistency

This package gives an exact **247-working-state, two-symbol, one-tape Turing machine starting on a completely blank tape**, and an ordinary mathematical proof that

\[
\mathrm{ZFC}\vdash
\bigl[\neg\operatorname{Halt}(M_{247},\mathrm{blank})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr].
\]

The complete construction, proof, and literal transition table are in [report.pdf](report.pdf) and [report.tex](report.tex). The new reduction removes three states from the incoming prefix250 construction. **No new Lean or Rocq kernel endpoint for this exact table is claimed.** The argument combines proved register identities, exhaustive finite symbolic certificates, an exact blank bootstrap, and the identified inherited logical calibration. A serialized first-order ZFC derivation and the repository's stronger internal PA formalization are not supplied.

Sources were inspected on **17 October 2026**; the report and package were completed on **18 October 2026 UTC**.

## Exact machine

The tape is indexed by the integers. Initially every cell is 0, the head is at coordinate 0, and the machine is in its designated start state. Each row is `state read write L-or-R successor`. The final write and movement into the separate halt label are retained.

| Artifact | Interpretation | SHA-256 |
|---|---|---|
| [machine/zfc_prefix247.tm](machine/zfc_prefix247.tm) | Working states 0–246; start 0; halt 247 | `58bbbda620daf6d4d62f486db05f54d0dccb8373c080c1b5a0b26533e7a3a669` |
| [machine/zfc_prefix247_old.tm](machine/zfc_prefix247_old.tm) | Original labels; start 97; halt 254 | `0d37614f3caf37139b0be127837630539224acd1c45d748cf5704abfc3230b42` |

[machine/renumbering.json](machine/renumbering.json) gives the exact bijection; old dispatch 96 becomes canonical 89. The generator checks this file against the same transition mapping.

There are **494 total transition rows and one halting transition**. Both input rows of every working state are present, and initialization uses the counted table.

## The three-state saving

Relative to [reference/prefix250_old.tm](reference/prefix250_old.tm), change only

```text
60 0 0 R 0    →    60 0 0 R 20
```

and remove states **0, 1, and 3**, including their six rows. The start state and initializer `97 0 1 R 83` stay fixed.

This is a guarded state reuse. Every valid register-selection run reaches old state 0 on the first one-cell of the selected unary block. On input 1, states 0 and 20 both execute `0 L 2`, so the complete configurations coincide after the next transition. Redirecting the only incoming edge to 0 then disconnects the legacy component `{1,3}`. The report proves the selector invariant for arbitrary natural register values and exterior tape contexts.

The old bootstrap cannot be reused: it visited old state 0 on input 0. A new literal bootstrap is checked for the reduced table.

## Complete safe bootstrap

After exactly **741,241 transitions**, the delivered machine reaches old dispatch state 96 with an empty program counter. The head is at −5, the marker at −6, and the register header at 245, giving total head-to-header distance 250.

Its first nine physical register values are `(0,0,0,3,0,0,3,0,0)`. Under the inherited register permutation, the logical vector is

```text
(N,T,W,A,D,H,X,Y,L) = (3,0,0,0,3,0,0,0,0).
```

There are **235 spare blocks**, each of value 1. The complete tape has **487 one-cells**, ending at coordinate 974; all other cells are zero. The exact support is recorded in [results/bootstrap-canonical.json](results/bootstrap-canonical.json) and checked using separately implemented sparse and dense interpreters.

The current formula and retained formula are truth, and the stack is empty (`T=H=W=0`). The inherited safe dirty-root theorem permits the other numerical fields to be arbitrary. The register contracts preserve a nonempty spare suffix and the required distance bound throughout subsequent execution.

## Reproduce

From the package root, use **Python 3.10 or later**, with only its standard library:

```sh
python3 -B code/verify.py
```

The default command runs the seven checks in a temporary copy and leaves the delivered files unchanged. To refresh local result files and logs instead, run:

```sh
python3 -B code/verify.py --in-place
```

Assertions are part of the checks; run without Python's `-O` option. No network access, repository checkout, search, Lean, or Rocq installation is required. [results/verification.json](results/verification.json) records **all seven checks passing**.

| Check | Scope |
|---|---|
| Exact reconstruction | Rebuild the 247-state table from the pinned 252-state source and compare both labelings with the frozen artifacts. |
| Register inductions | Check explicit unary-loop and block-list induction templates and their composition into the four register contracts. |
| Complete symbolic instructions | Reparse all 6,459 source nodes, cover all 6,460 leaves and **8,391 guarded cases**, and verify positive progress and complete-frame effects. |
| Separate marking audit | Check the selector and incoming-edge premises; compare complete marking outputs in supplemental finite regressions. |
| Canonical sparse bootstrap | Execute the full blank prefix and compare the entire tape with the specified safe root. |
| Separate dense bootstrap | Independently reconstruct and replay the reduced table and check its canonical correspondence. |
| Literal instructions | Execute **8,391 finite cases**, totaling **3,647,370 transitions**, as a separate regression against the symbolic contracts. |

The symbolic rules and induction arguments are explained in the report. Literal regressions detect implementation errors; they do not prove the unbounded statements by sampling. “Independent” here means separately implemented automated checks or a separate automated review, not external peer review.

The reconstruction check also parses the balanced tree in the included `reference/lean/Prog254.lean`, verifies every stored subtree size, and compares all 6,459 flattened rows with `Prog254.v`. This binds the instruction input to the exact literal program used by the inherited Lean comparison theorem. It also regenerates and checks the printable table used by the PDF.

To rebuild the PDF, install `latexmk`, pdfLaTeX, and the TeX packages listed in `report.tex`, then run:

```sh
make pdf
```

`make verify`, `make verify-in-place`, and `make clean` provide the corresponding verification and TeX-cleanup commands. The optional bounded bootstrap exploration is documented in [exploration/README.md](exploration/README.md); it is not required for verification.

## Sources, attribution, and integration

The maintained source pin is [ProveIt `e0b512a63e2c1ca6a1698fa437b8568f1643ff6b`](https://github.com/VladimirReshetnikov/ProveIt/tree/e0b512a63e2c1ca6a1698fa437b8568f1643ff6b). The machine descends from Mira-Cult's 254-state construction, Jeff Ketchersid's verification, Andrew James Wade's compiler framework, mira-emmy's public 253-state reduction, and ProveIt's permutation252 and prefix250 work. The prefix-carry, rollback, and pulse design are prior work in the incoming archives. This package contributes the further guarded reduction, its new bootstrap, proof composition, and reproducible checks. It makes no worldwide-priority or minimality claim.

[PROVENANCE.json](PROVENANCE.json) identifies the pins, retained inputs, adapted verifiers, and proof boundaries. [NOTICE.md](NOTICE.md) explains authorship and the scope of retained historical metadata; [licenses/](licenses/) preserves applicable supplied notices. The full `Prog254.v` and selected Lean sources are reference snapshots. Their complete proof-assistant dependency closure is not bundled or rebuilt here.

The archive is suitable for incorporation as a research construction with a mathematical ZFC proof and executable certificates. A new kernel endpoint would require porting the register identities and strengthened frame, checking the reduced bootstrap and instruction certificates, and composing those results with the maintained dirty-root and logical calibration theorems. This package proves the stated equivalence; it does not prove ZFC consistent or the machine nonhalting unconditionally.
