REPORT 121
DSASM fugacity pressure and diagonal statistics
2 October 2026

Read report121.pdf. The editable source is report121.tex.

The report proves the linear-scale asymptotic
  log a_n = (n^2/2) log(3 sqrt(3)/4) + (n/4) log 3 + o(n),
an explicit fugacity pressure, a compactified limiting root measure,
fixed-fugacity cumulant limits, actual-mean CLT and parity local CLT,
a macroscopic LDP, and a rounding-safe count-threshold bracket.
It does not prove the logarithmic correction, amplitude, full conjectured
asymptotic equivalent, effective finite-size onset, or limiting-mean CLT centering.
The finite exact checks are supplementary; the all-size analytic arguments
are in the report. No external peer-review, bibliographic priority, or formal
proof verification is claimed.

1. Requirements

Exact checks and integrity tests: Python 3.10+ with its standard library.
PDF rebuild: pdftex/pdflatex plus the standard TeX packages named in the
source, including Latin Modern, AMS math, mathtools, booktabs, microtype,
hyperref, enumitem and geometry. See build-environment.txt for the delivery
toolchain. No network, package installation or access to another report is
needed. Run commands from this directory, or use absolute script paths.
Use -B or PYTHONDONTWRITEBYTECODE=1 to prevent bytecode from adding files
to the closed package inventory. Do not put logs or new files here.

2. Quick verification

  python -B integrity.py
  python -B checks/verify.py
  python -B -O checks/verify.py
  python -B checks/mutation_tests.py
  python -B test_integrity.py

The checker outputs deterministic JSON. verification_results.json is the
exact output of the delivery run, byte-identical in normal and optimized
Python. checks/README.md records all pinned ranges, mathematical methods,
41 selected mutation/control definitions and limitations. Those mutations
run in both modes, giving 82 expected intentional failures plus positive
baseline checks. They test selected paths, not every possible source edit.
The outer inventory tests 14 error cases in both modes (28 failures).
All guards are explicit exceptions and remain active with Python -O.

The exact routes include original-kernel/Pfaffian comparisons through
order 13, determinant derivatives through order 12, original DSASM matrix
enumeration through order 6, exact Sturm/gcd interlacing with multiplicities,
finite Jacobi identities at several rational parameters, determinant products
through order 16, all-parameter polynomial identities, Stirling coefficients,
pressure-integral algebra, finite pole-cleared determinants and mixed paths,
root-density transforms, four cumulants, LDP and threshold-root algebra.
See checks/README.md for precise per-test ranges and distinctions between
finite checks and symbolic certificates.

3. Rebuild and deterministic ZIP

  python -B build.py
  python -B integrity.py
  python -B pack.py ../report121_reproducibility.zip

build.py uses two fresh temporary directories and three TeX passes per
build; it fixes metadata, checks warnings and requires byte equality.
It overwrites only report121.pdf after success. On the recorded toolchain,
the rebuilt PDF must match the delivered PDF and its inventory hash.
Different TeX/font versions may legitimately produce different bytes.
The mathematical checks are standard-library exact arithmetic.

pack.py requires the outer inventory to pass. Its output must be outside
this directory. Archive entries have sorted names, fixed dates and mode
bits, and a single report121/ root. Checksums detect changes but are not
authenticated signatures; coordinated rewriting of a verifier and its
manifest is outside this integrity model.

4. Complete clean replay

  python -B reproduce.py > ../report121_replay.json

This verifies both checker modes against verification_results.json, runs
all selected mathematical and outer integrity negative tests, rebuilds
the delivered PDF, packs a ZIP outside this directory, extracts it to a
fresh temporary directory, repeats checks and the two-clean-build PDF test,
rechecks inventories, repacks, and requires byte-identical ZIP archives.
All temporary files are external and removed automatically. The JSON
records the resulting PDF and ZIP hashes. The delivery replay passed.
Every page of the delivered PDF was rendered and visually inspected.

5. File inventory and deliberate edits

CHECKSUMS.sha256 lists every other package file, including the checker's
inventory.json. It rejects changed, missing or unexpected files, directories
and symlinks. The checker has its own closed seven-file inventory.
No source-paper PDFs, private notes, absolute workspace paths or temporary
render files belong to this archive.

For a deliberate author-side edit, rebuild, perform the relevant checks
and visual review, then regenerate the outer inventory with
  python -B integrity.py --write
Do not regenerate it merely to suppress an unexplained mismatch.
A changeset to checks/ requires intentionally updating its inner inventory
as documented there, followed by the outer inventory and negative tests.

References and external input locations are stated in the article.
