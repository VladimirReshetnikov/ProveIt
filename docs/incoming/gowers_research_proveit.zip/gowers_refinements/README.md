# Quantitative bilinear extraction and bounded additive defects

Research manuscript prepared for the ProveIt Ramsey project, 7 October 2026.

## Files

- gowers_bilinear_extraction_and_additive_defects.tex — complete standalone LaTeX source, including bibliography.
- gowers_bilinear_extraction_and_additive_defects.pdf — compiled article.
- verification/quantitative_exact_checks.py and its JSON report — exact quantitative constants and finite correction checks.
- verification/verify_structural.py and its JSON report — exact Schur, partition, and energy checks.
- verification/quantitative_structural_review.md — internal AI-assisted mathematical audit.
- provenance.json — pinned source identifiers and exact input files.
- Makefile — build and verification commands.

No copied source papers, external figures, fonts, credentials, or repository checkout are included.

## Mathematical contributions

1. A written proof of the printed Theorem 13.12 length bound, using the existing uniform common-square extraction, with retained-density exponent improved from 2^76 to 2^41. The independent all-parameter length has inner exponent 2^53, replacing 2^88 in the previous inspected propagation.
2. An explicit near-maximal U^4 bilinear-frequency theorem with exceptional proportion 332 epsilon, every-order symmetric and finite abelian group extensions, and polynomial-phase integration in sufficiently large characteristic. The dedicated cubic correlation loss uses constant 6194.
3. Eventual classification of positive real sets with fixed Schur deficit s, for n >= 5s - 1, by the p(s) integer partitions of s.
4. Complete third additive-energy equality classification for torsion-free sets of size at least seven, with its unique extra six-point class and the optimal threshold.
5. Twelve proposed research questions, complete dependency notes, and an integration plan.

The Fejér selection theorem is inherited from repository source 40 and is re-proved in its needed specialization. The prior numerical energy levels and second-level classification are inherited from source 45 and are explicitly credited.

## Baseline and proof status

The repository baseline is:

    128f514afce0bf7eb48133fb30dd3f8e034ea3a2

The article uses Combinatorics/Ramsey/Lean/GowersSzemeredi/Proofs13UniformSquareExtraction.lean as an imported mathematical theorem, with its exact quantifier order, properness, common-step, and equal-length conclusions.

This package contains written proofs and exact supplementary checks. It does not contain a new Lean proof, change any formal ledger, or establish an improved final bound for Szemerédi's theorem. Publication priority has not been established. The internal review is AI-assisted and is not external peer review.

## Rebuild

A current TeX Live installation with standard packages is sufficient. The source uses lmodern, microtype, geometry, AMS packages, mathtools, booktabs, longtable, enumitem, xcolor, fancyhdr, url, xurl, hyperref, and cleveref.

    make pdf
    make verify

Equivalently:

    latexmk -pdf -interaction=nonstopmode -halt-on-error gowers_bilinear_extraction_and_additive_defects.tex
    python3 verification/quantitative_exact_checks.py
    python3 verification/verify_structural.py

If latexmk is unavailable, run pdflatex on the TeX file repeatedly until the cross-reference warnings disappear.

The verification programs use only the Python standard library. The structural enumeration can take longer than the quantitative checker. Their JSON outputs are written beside the programs by default. The finite searches are checks, not proofs of the unbounded or real-set classifications.

## Suggested integration

Place the manuscript as a new research source under the existing Ramsey research hierarchy and retain its source provenance. Its labels use main:, qt:, ep:, st:, rq:, and audit: prefixes.

The first two research questions in source 45 can receive dated pointers to the partition and third-energy classification theorems. The written-proof intake for Theorem 13.12 can cite the new synthesis, with the density improvement. Change the formal catalogue status only after the corresponding Lean proof is compiled and its dependencies audited.

There are no placeholder Lean declarations in this package.
