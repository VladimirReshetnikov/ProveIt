# Rational diagonals and rare boundary phases in shifted rectangles

**D-finiteness at every fixed height and a sharp exponential refinement for OEIS A181199**

Research report prepared for Vladimir Reshetnikov, October 4, 2026.
The main deliverables are `article.pdf` (24 pages) and its self-contained LaTeX source, `article.tex`.

## Results

For fixed `m`, let `T_m(n)` count the `m × n` arrays of `1,...,mn` increasing
in rows, columns, diagonals, and downward antidiagonals (OEIS A181196;
heights 3, 4, 5 give A181197, A181198, A181199).

1. **Every fixed-height generating function is a rational diagonal, hence D-finite.**
   The proof cuts a prefix path at its `2m` row births and completions. Each
   intervening strict-chamber walk is an integer reflection determinant.
   Each event-word contribution becomes a multiple binomial sum with at
   most `m(m−1)` free indices. The theorem of Bostan–Lairez–Salvy completes
   the rational-diagonal argument. This resolves Question 7 of the preceding
   ProveIt shifted-rectangle report.
2. **A sharp rare boundary expansion.** Let `R_m(n)` count arrays where the
   first row finishes before the last row starts. With `r=m−2`,

   `R_m(n) ~ sqrt(m/2) (2π)^(−r/2) 4^(−r(r−1)/2) 9^(−r) (∏_{j=0}^{r−1} j!) (m^m/4)^n n^(−r²/2)`.

   Every inverse-power coefficient is effectively rational. The first is
   `r(6r³−52r²−268r−283)/(72(r+2))`.
   At height five the first three corrections are
   `−1393/120`, `656449/28800`, `9833844689/155520000`.
3. **Further consequences.** The article proves the exact event-word
   realizability criterion, rational diagonality for marked rank totals,
   a Gaussian conditional middle-shape law, and the rare-event probability
   relative to the preceding total-count asymptotic. It gives Lambert-W
   inverse-profile corrections and eight concrete research questions.

The probability consequence uses the previous report's total asymptotic;
the new exact-enumeration and rare-count proofs do not depend on that
asymptotic.

## Scope and status

This is an AI-assisted, unrefereed manuscript. Mathematical proofs are
provided, but they have not been independently peer reviewed or verified
in a proof assistant. Historical priority is not certified.

The specific conjectured order-two/degree-nine recurrence for A181198,
the order-three/degree-twenty-four recurrence for A181199, and the related
finite-sum formulas are **not proved here**. We prove that some recurrence
exists, by the stronger rational-diagonal property. The construction is
effective, but no small general rational function or telescoper is supplied.

The expansions are fixed-height, fixed-order Poincaré expansions. The
combinatorially identified rare sector is not a complete resurgent
transseries; no Stokes constants or Borel-summability assertion is made.
The discrete inverse remains a staircase. Decimal calculations are not
interval certificates. Nothing has been submitted to OEIS or committed
to GitHub.

## Files

- `article.tex`, `article.pdf`: manuscript and compiled article.
- `code/tableaux.py`: prefix DP, independent poset enumerator, reflection
  kernel, event-skeleton evaluator, and shifted-hook core sum.
- `code/coefficients.py`: exact rational all-order coefficient engine.
- `code/verify.py`: 1,954 finite exact checks, including independent
  enumerations, small OEIS reference values, and symbolic coefficient checks.
- `code/numerics.py`: exact rare counts and 70-digit asymptotic diagnostics.
- `code/inverse_profile.py`: continuous inverse-profile diagnostics.
- `data/`: exact coefficient files, exact counts, test log, decimal tables,
  and one inverse-profile example.
- `notes/SOURCES_AND_STATUS.md`: repository pin, sources, and attribution audit.
- `notes/PROPOSED_OEIS_NOTE.md`: draft only, explicitly not submitted.
- `requirements.txt`, `build.sh`: reproduction dependencies and PDF build.
- `SHA256SUMS.txt`: hashes of all other delivered files.

## Reproduce

The tested environment is Python 3.13.5, SymPy 1.14.0, mpmath 1.3.0.
The enumerators in `tableaux.py` use the Python standard library only.
Exact state enumeration becomes expensive as width and height grow;
the supplied parameter ranges are deliberate test ranges, not scalability claims.

```sh
python -m pip install -r requirements.txt
python code/verify.py
python code/coefficients.py --height 5 --order 3
python code/numerics.py
python code/inverse_profile.py --index 60 --height 5
```

The exact verification run passed all 1,954 checks. Runtime fields are
machine dependent. Re-running `numerics.py` recomputes its integer inputs;
it does not obtain them from a conjectured recurrence or from the internet.

Build with a standard TeX Live installation containing the packages named
in the preamble, including `newtx`, `tcolorbox`, `microtype`, and `hyperref`:

```sh
bash build.sh
```

The PDF was compiled and visually inspected in a rendered copy. The source
needs no external image assets or bibliography database. No font files are
included in the package.
