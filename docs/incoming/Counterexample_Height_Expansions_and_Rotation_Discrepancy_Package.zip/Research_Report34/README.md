# Research Report 34

## Height and counting of one canonical signed19 family

This new release follows Research Report 33 without modifying it. It fixes the ordinary input, actual compiler export, repunit and one prime-scale choice. It counts only the prescribed canonical auxiliary family m=p psi_A(p), S=p+2m, with the exact first-Pell ratio selection on one main-index CRT progression.

The report proves eventual height equal to y, an exponentially corrected double-logarithmic height law, an explicit Lambert-W cutoff, a fixed-parameter effective power-saving counting error, and an exact rotation-discrepancy representation. Its independently checked all-orders refinement concerns the continuous height and cutoff only. The convergent normal-form series retain a beyond-all-orders difference from the exact quantities.

Kesten's theorem rules out a smooth two-term count with O(1) remainder. The finer two-term formula with o(logloglog B) remainder is equivalent to the unresolved condition D(R)=o(log R). Neither the all-orders height refinement nor the effective power-saving discrepancy proves that condition.

The short applicability appendix transfers this canonical family to the corresponding asymmetric signed19 orientations by changing only the fixed coordinate w to q²w. It preserves the eventual y-height. It does not assign parent degree/operation ledgers to children or change any positive-index parent theorem. The raw29 and positive21 questions remain outside scope.

## Main files

- Research_Report34.pdf: the rendered report
- Research_Report34.tex: one self-contained editable LaTeX source, including the all-orders proof and asymmetric applicability appendix
- build_pdf.sh: offline PDF build with shell escape disabled; three LaTeX passes
- verify_package.py: identity gate, with an optional local PDF build
- PROVENANCE.json: original and packaged source hashes, origin pins and URLs
- MANIFEST.json and SHA256SUMS: release payload identities
- QA.json: recorded artifact checks and their scope

The evidence directory contains the frozen analytic proof and independent checks, the inherited construction and audit, and the transfer proof. A few workstation-local path references in analytic notes were normalized for portability; PROVENANCE.json records both original and packaged hashes. Mathematical text was not changed. The context directory contains the unchanged LaTeX of Reports 25 and 33 for scope and construction linkage. These context copies are evidence, not substitute builds of the delivered predecessors. The sources directory contains the exact pinned descriptions supporting the applicability appendix, read only as inert text.

Some historical evidence notes describe the broader packets in which they originated, including static source checks. This release includes the analytic notes and selected pinned descriptions needed for the report; it does not claim that every sibling file of those earlier packets is present.

## Verify and rebuild

Requirements for the identity check: Python 3 standard library. From any working directory:

    python3 /path/to/release/verify_package.py
    python3 -O /path/to/release/verify_package.py

To rebuild, install a normal TeX Live distribution with pdfLaTeX and the packages used in the source, then run:

    sh /path/to/release/build_pdf.sh /absolute/path/to/external/build-directory

Or run the identity gate followed by the same build:

    python3 /path/to/release/verify_package.py --build /absolute/path/to/external/build-directory

The build output directory must be outside the release tree. It receives the PDF, LaTeX logs and a local TeX cache. The shipped PDF and evidence files are not overwritten by this workflow. The build script makes no network requests and does not enable shell escape. Runtime-dependent byte-for-byte reproducibility is separately reported in QA.json; a PDF produced by another TeX distribution can be mathematically identical without an identical byte hash.

## Evidence limits

The verifier checks byte identity and complete payload inventory. It is not a mathematical theorem checker. The build script checks that the supplied LaTeX compiles. The growth claims are analytic proofs supported by independent analytic notes; no finite numerical code run proves them. No executable mathematical checker, numerical giant witness, upstream arithmetic schedule, third-party PDF cache or repository edit is part of this release.

There is no whole-signed19-fiber classification, uniform bound over changing scales, machine-specific false-acceptance claim, new universal representation bound or literature-wide novelty claim.
