# Root Collisions and Sharp Recurrences for Polynomially Weighted Catalan Hankel Determinants

Research article, 28 September 2026. Prepared with OpenAI ChatGPT for
Vladimir Reshetnikov's ProveIt research program.

## Main result

For the Catalan numbers C_n, set

    H_N(q) = det(sum_r q_r C_(i+j+r))_(0 <= i,j < N),  H_0(q) = 1.

Write the nonzero multiplier as

    q(x) = gamma*x^m*(x-4)^ell * product_i (x-c_i)^t_i,
    c_i = 2 + z_i + 1/z_i,

with distinct c_i different from 0 and 4. The canonical sector indexed by
0 <= k_i <= t_i has rate

    lambda_k = (-1)^(ell + sum_i t_i) * gamma * product_i z_i^(2*k_i-t_i)

and a polynomial coefficient of EXACT degree

    d_k = m*(m-1)/2 + ell*(ell+1)/2 + sum_i k_i*(t_i-k_i).

The article proves a nonzero product formula for every leading coefficient.
When the rates are distinct, the minimal characteristic polynomial is

    product_k (X-lambda_k)^(d_k+1),

of exact order

    R_0 = product_i(t_i+1) *
          (m*(m-1)/2 + ell*(ell+1)/2 + 1 + sum_i t_i*(t_i-1)/6).

For a single repeated nonendpoint root the generic order is
`t+1+binomial(t+1,3)`, cubic rather than the classical exponential bound.
The example `(2*x-9)^4` has order 15:

    (X-1)*(X-4)^4*(X-16)^5*(X-64)^4*(X-256).

The secondary Hankel determinant of the H_N sequence has an explicit
factorization detecting exactly when the maximal order drops. At resonances,
sectors with equal numerical rates must be added before determining their
degrees. Whole sectors can cancel. A proved finite-prefix theorem gives an
exact algorithm for every nonzero rational polynomial multiplier, without
finding individual roots. The article also includes asymptotics, worked
resonant examples, and eight proposed research directions.

## Scope and status

This is an unrefereed, AI-assisted manuscript, not a Lean-formalized proof.
The general theorems have full written proofs. Finite computations audit
normalization and examples and do not replace those proofs. No claim of
first discovery or exhaustive literature coverage is made.

The article extends the ProveIt report on shifted linear Catalan multipliers,
inspected at commit `fbba58593dc0622aa914972896150d4848f935b5`. Classical
Christoffel identities and general recurrence existence are explicitly
credited. See `notes/provenance.md` and the article bibliography.

## Contents

- `article.pdf`: 23-page article, including complete proofs and further questions.
- `article.tex`: self-contained LaTeX source with embedded bibliography.
- `code/catalan_collisions.py`: exact rational reference implementation.
- `code/verify.py`: reproducible verification suite; checks remain active with `-O`.
- `data/verification.json` and `.txt`: actual verification outcome and counts.
- `data/sectors.json`: full sector polynomials, leading constants and characteristic
  polynomials for twelve nonresonant parameter patterns.
- `data/resonances.json`: exact minimal recurrences at resonant parameters.
- `data/rational_input_examples.json`: root-free rational-coefficient examples.
- `data/central_root_certificate.json`: the nine-value all-index certificate for
  `H_N((x-2)^4) = (N+1)*(N+2)^2*(N+3)/12`.
- `data/fourth_power_sequence.csv`: exact values for `(2*x-9)^4`.
- `notes/provenance.md`: source/version audit, novelty scope and limitations.
- `Makefile`: verification, PDF and cleanup targets.

No font files, external article PDFs, bytecode, or compiler auxiliaries are
included. Links in the bibliography point to the source works.

## Reproduce the verification

Python 3.10 or later; standard library only:

```sh
python3 code/verify.py --out data
```

The recorded run passed **2,843 checks**, including 1,554 original moment
versus Christoffel determinant comparisons over 222 parameter/scale choices,
48 exact sector-leading-coefficient checks, and 15 secondary-Hankel
factorizations. Exact fractions, not floating-point tolerances, are used.
The two determinant constructions share the low-level Gaussian elimination
routine; their moment and orthogonal-polynomial constructions are different.

All polynomial arrays have coefficients in ascending power order. Fractions
in JSON/CSV are exact strings, such as `"8/81"`. A sector's polynomial is
in the determinant size N, not a generating-function numerator.

## Use the root-free implementation

```python
import sys
sys.path.insert(0, "code")
from catalan_collisions import recurrence_from_coefficients

# q(x) = x^2 + 1. No complex root representation is needed.
chi, bound = recurrence_from_coefficients([1, 0, 1], max_bound=16)
print(bound)  # 4
print(chi)    # Fractions representing 1, -5, 4, -5, 1
```

The returned list represents `X^4-5*X^3+4*X^2-5*X+1`. If it is
`[g_0,...,g_r]`, the recurrence is

    sum_(j=0)^r g_j * H_(N+j) = 0   for EVERY N >= 0.

The root-free routine is intentionally a transparent fallback. It computes
original determinants through size `2*bound-1`; a large bound can be expensive.
Use `max_bound` to refuse unexpectedly large requests. When rational roots are
already known, `christoffel_values` uses a fixed-size determinant and is faster.
`minimal_recurrence` on its own is valid only when the supplied sequence has a
PROVED all-index order bound; a finite prefix by itself is not that proof.

## Build the PDF

A reasonably complete TeX Live installation with `newtxtext`, `newtxmath`,
`mathtools`, `amsthm`, `geometry`, `microtype`, `tocloft`, `xurl`, `hyperref`,
and the other standard packages in the preamble is sufficient:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `pdflatex` repeatedly until cross-references stabilize.
The delivered PDF was compiled, rendered, and visually inspected. The build
has no undefined-reference or overfull-box warnings.
