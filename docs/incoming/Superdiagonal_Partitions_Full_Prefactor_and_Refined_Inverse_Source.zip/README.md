# Report162 — Full prefactor and refined inverse for superdiagonal partitions

This self-contained report proves the full multiplicative equivalent for OEIS A238873, counting increasing positive-integer partitions lambda_i >= i and including A(0)=1. Reports156, 158 and160 remain unchanged and are not proof dependencies.

Let b=log(2), C=pi^2/12+b^2, a be the largest negative zero of Ai, B=2sqrt(C), and D=-a b C^(-1/6). The main result is

    A(n) ~ K n^(-11/12) exp(B sqrt(n) - D n^(1/6))
    K = sqrt(2) C^(5/12) / (sqrt(pi) Ai'(a))
      = 1.2704976135603045366...

The radial generating function has the stronger expansion

    F(t) = K_F t^(1/3) exp(C/t + b a t^(-1/3))
           * (1 + alpha t^(1/3) + O(t^(2/3)))
    K_F = 2 sqrt(2) / Ai'(a)
    alpha = a^2 (1/4 - b/30).

For T(y)=min{n>=0:A(n)>=y} and x=(log(y)/B)^2,

    T(y) = x + (2D/B)x^(2/3)
             + (11/(6B))sqrt(x)log(x)
             - (2log(K)/B)sqrt(x) + o(sqrt(x)).

The inverse is proved by largest-part monotonicity and floor/ceiling brackets; it does not differentiate an unknown remainder. It is not an exact rounding rule or a certified finite threshold interval.

## Explicit source dependency and proof scope

Yu-Tian Li's *Airy Turning-Point Asymptotics for Ramanujan's Entire Function A_q(z)*, arXiv:2607.27504v1, submitted 29 July 2026, is an explicit preprint dependency. No journal publication was verified. The exact normalization, compact complex-argument error, and global first/second zero indexing are stated in the report. The asymptotic parameter q=e^(-t) is real; no complex-q uniformity is inferred.

The 2025 Archibald–Blecher–Elizalde–Knopfmacher identity and 2017 Stampach–Stovicek positive simple-zero product are separately credited. The 2025 displayed lower summation index is repaired to include the empty object. The 2017 extraneous q factor in an intermediate display is repaired by the defining independent-set sum; the final product retains constant term one.

The report supplies a positive first-pole estimate uniform at the moving length saddle and preserves the global positive upper bound. Its self-contained coefficient local limit uses a real mgf CLT, an exact multiplicity tilt, exponentially accurate constraint removal at a fixed cutoff, an independent consecutive geometric tail, and Fourier bounds on the central, intermediate and all remaining arcs. A literal Gaussian majorant absorbs the additive total-variation error.

No pointwise first relative correction, effective finite crossover, all-orders expansion, exhaustive novelty certification or unrelated fixed-size fluctuation theorem is claimed. The radial correction is not silently transferred to coefficients. Numerical tests do not prove asymptotics or effective error bounds.

## Deliverables

- Report162.pdf: 15-page rigorous mathematical report
- Report162.tex: editable self-contained LaTeX source
- companion/prefactor.py: bounded standard-library computations, JSON stdout only
- companion/test_prefactor.py and companion/README.md: tests and complete interfaces
- data/counts.json: exact positive-DP counts through 400
- data/series_counts.json: independent exact reciprocal-H series counts through 80
- data/finite_checks.json: finite exact enumeration and algebra checks
- data/illustrations.json: separately labeled noncertified approximate constants and residuals
- SOURCE_PROVENANCE.json: source metadata, URLs, inspected scope and preserved-source hashes
- build_pdf.py and release_tools.py: exclusive clean PDF build and bounded local I/O
- make_zip.py and test_release.py: fixed-allowlist deterministic archive and regression tests
- SHA256SUMS: sorted manifest of all allowlisted payload members, excluding itself

Report162_Source.zip contains this payload and the manifest, without recursively including itself. Internal reviews, working notes, third-party source PDFs, temporary renders, build directories and unlisted files are excluded. No publication, upload, third-party contact, repository modification or OEIS edit is performed by any included command.

## Companion replay and bounds

Python 3.10 or later is required; only the standard library is used. Exact counting is capped at 400, reciprocal-H series work at 100, direct enumeration at 32, and exact threshold values at 10^200. Fixed verification uses enumeration through 28, a series match through 80, and multiplicity vectors of length at most six with entries at most three. Integer APIs reject booleans, floats, strings and out-of-range values. CLI integers must be canonical nonnegative ASCII decimal notation. Checks remain active under -O.

The exact finite checks cover 18,460 ordinary partitions, 3,420 admissible partitions and injection images, 10,922 rational tilt comparisons, two Airy-density reductions, empty-object normalization, reciprocal-series agreement and count monotonicity. These checks support definitions and implementations; the theorem has an analytic proof.

Choose a fresh replay directory and enable shell no-clobber mode:

```sh
mkdir reproduction
set -C
python3 -B companion/prefactor.py counts > reproduction/counts.json
python3 -B companion/prefactor.py series > reproduction/series_counts.json
python3 -B companion/prefactor.py verify > reproduction/finite_checks.json
python3 -B companion/prefactor.py illustrations > reproduction/illustrations.json
cmp data/counts.json reproduction/counts.json
cmp data/series_counts.json reproduction/series_counts.json
cmp data/finite_checks.json reproduction/finite_checks.json
cmp data/illustrations.json reproduction/illustrations.json
python3 -B -m unittest discover -s companion -p 'test_prefactor.py' -v
python3 -O -B -m unittest discover -s companion -p 'test_prefactor.py' -v
python3 -B companion/prefactor.py threshold --value 1000000 --max-n 200
```

Exact JSON outputs use integers or decimal strings and reproduce independently of ordinary floating-point libraries. Approximate illustration strings reproduce on the recorded Python/math platform; last digits can differ across libm implementations. The high-precision-looking Airy input strings are rounded reference evaluations, not certified intervals. They are converted to ordinary floats for illustrations. No approximate output is labeled exact.

## Clean PDF replay

The release platform is Python 3.12.14 and pdfTeX 1.40.26, TeX Live 2025/dev/Debian. The builder requires pdftex and pdflatex, Latin Modern, AMS math and Euler fonts, fontenc, amsmath, amssymb, amsthm, mathtools, geometry, booktabs, array, microtype and hyperref. Poppler is used for visual QA, not PDF authoring.

```sh
python3 -B build_pdf.py --output-dir /tmp/report162-build-one
python3 -B build_pdf.py --output-dir /tmp/report162-build-two
cmp /tmp/report162-build-one/Report162.pdf /tmp/report162-build-two/Report162.pdf
cmp Report162.pdf /tmp/report162-build-one/Report162.pdf
```

The selected build directory must not exist, and its parent must already exist. The builder reads at most 1 MiB of source, creates a fresh LaTeX format and isolated caches, fixes the epoch and PDF metadata, disables shell escape, and limits each subprocess to 180 seconds. It allows at most six document passes. POSIX RLIMIT_FSIZE caps each child-written file, including console output, at 16 MiB. Generated aux/toc/out reads are capped at 1 MiB each; log and PDF reads at 16 MiB each, with regular-file and no-symlink checks. References must settle and the final log must contain no warnings, missing characters, overfull or underfull boxes. Byte identity is expected within the recorded toolchain, not across TeX/font/platform versions.

## Manifest and archive replay

```sh
sha256sum -c SHA256SUMS
python3 -B -m unittest -v test_release
python3 -O -B -m unittest -v test_release
python3 -B make_zip.py --output /tmp/Report162-rebuilt-one.zip
python3 -B make_zip.py --output /tmp/Report162-rebuilt-two.zip
cmp /tmp/Report162-rebuilt-one.zip /tmp/Report162-rebuilt-two.zip
cmp Report162_Source.zip /tmp/Report162-rebuilt-one.zip
```

The last comparison applies if the supplied source ZIP is retained beside the extracted payload. Archive member order, timestamp, permissions and ZIP_STORED mode are fixed. The manifest must match the sorted fixed allowlist exactly, including every recorded hash; unlisted files cannot enter. The ZIP includes the manifest. Any payload edit requires a new release manifest and fails comparison with this release.

All source reads require regular files, reject symlinks and special files, and are capped at 16 MiB per file (64 KiB for the manifest). Archive payloads are capped at 64 MiB; the archive-byte helper allows at most 64 bounded members and rejects absolute paths, parent traversal, empty path components and non-byte contents.

Release file/directory outputs are exclusive and reject preexisting files, directories, symlinks, FIFOs and other special targets. Parent traversal and symlink parents are rejected. POSIX O_NOFOLLOW/O_DIRECTORY and descriptor-relative operations are required. The source tree and output parents must be trusted and nonadversarial. Descriptor pinning reduces accidental substitution; the mkdir-then-open interval is not claimed to defeat a malicious same-user actor. A failed write may leave a new incomplete output, so inspect it rather than blindly retrying. Disabling shell escape is not a sandbox for malicious modified TeX.
