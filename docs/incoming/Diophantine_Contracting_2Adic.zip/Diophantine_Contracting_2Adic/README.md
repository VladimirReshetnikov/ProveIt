# Exact Diophantine Computation in Contracting 2-adic Dynamics

Research article and reproducible exact-arithmetic implementation, prepared
September 30, 2026.

## Read the article

`article.pdf` is the 27-page compiled article. `article.tex` is its complete
LaTeX source; its bibliography is embedded, so no separate `.bib` file is
required. `build.sh` rebuilds the PDF.

The article constructs an unconventional computational substrate: a map of
the 2-adic integers that is globally 1/2-Lipschitz, fixes only zero, and whose
iterated natural-number inputs encode exact Turing-machine halting through
finite-time extinction. A constant-drift version is a finite synchronous
binary Mealy transducer. The map is **not** universal under fixed-precision
clopen observation; every finite quotient is uniformly nilpotent.

## Principal results

Theorems 3.1 and 3.3 prove the contraction and simulation construction.
Corollary 3.4 supplies recursively enumerable completeness for a fixed
universal source machine. Theorem 4.1 constructs the finite transducer.
Theorem 4.4 classifies radial clocks: finite-state realization is equivalent
to eventual periodicity of the added delay `h(t)-t`.

Theorem 6.4 gives the different regularity boundary: differentiability at zero
is equivalent to `h(t)-t` tending to infinity, and then the derivative is zero.
The same family can have an arbitrary prescribed computable convergence rate
or be asymptotically flat to every integral order without changing exact
extinction. Theorem 7.1 gives a scalar analytic obstruction: a contraction
analytic near zero has a uniform finite extinction horizon. Corollary 7.2
gives a coefficient-computable horizon for rational polynomials.

Theorem 8.1 applies MRDP to get a clock-independent fixed-arity unbounded
representation. Theorem 9.1 supplies an explicit **bounded** unique-witness
quartic. For a machine with `m` states and bounds `T, S`, it has

    (3*m + 6)*T + 3*S + m + 4 witnesses
    (4*m + 7)*T + 3*S + 2*m + 7 residual equations.

The bounds `T, S` are compiler parameters, not free variables in a single
fixed-arity polynomial. Thus bounded unique witnesses do not establish a
fixed-arity single-fold MRDP theorem.

## Files

- `article.tex`, `article.pdf`: full article, proofs, references, twelve
  proposed further research directions, and a ProveIt formalization route.
- `code/padic_machine.py`: binary tape semantics, packing and unpacking,
  exact integer and residue evaluation, and the finite Mealy compiler.
- `code/quartic_certificate.py`: exact sparse polynomial arithmetic,
  the bounded quartic compiler, and deterministic witness reconstruction.
- `code/verify.py`: deterministic test suite and example export.
- `examples/demo_mealy.json`: the demonstration transducer, with 1,795
  reachable states. It is not minimized and the source machine is NOT universal.
- `examples/demo_quartic.json`: 117 residuals whose sum of squares is the
  demonstration certificate, with 91 natural-number witnesses.
- `examples/demo_expanded_quartic.json`: the same quartic expanded into
  818 nonzero sparse monomials.
- `examples/demo_witness.json`: the exact accepting witness for input 337.
- `verification_report.json`: actual completed finite-check results.
- `PROOF_STATUS.md`: dependencies, proof boundaries, and limitations.
- `SOURCES.md`: source provenance and literature-search limitations.
- `MANIFEST.json`: file sizes and SHA-256 integrity hashes.

## Run the checks

Python 3.10 or later; standard library only. From this directory:

```sh
python3 code/verify.py
```

This recreates the example JSON files and `verification_report.json`.
The seed is 20260930. The completed suite reports **121,822 passed checks**
across thirteen machine tables. These finite tests supplement the proofs;
they are not exhaustive proofs on all natural numbers or all 2-adic integers.

Do not invoke Python with `-O`: the test suite uses assertions.
Full-value evaluation has a configurable output-bit guard to avoid accidental
allocation of enormous integers. Use `Machine.residue` for finite precision.

## Minimal API example

Run from the `code` directory, or add it to the Python module search path:

```python
from padic_machine import demo_machine, MealyCompiler
from quartic_certificate import compile_certificate, candidate_witness

M = demo_machine()
n = M.encode(M.start, 0, 7)       # 337
print(M.apply(n))                 # 2592
print(M.residue(n, 16))           # 2592, computed modulo 2**16

C = compile_certificate(M, T=5, S=3)
n, witness = candidate_witness(C, right_input=7)
assert C.evaluate(n, witness) == 0
assert len(C.variables) == 91
assert len(C.residuals) == 117

table = MealyCompiler(M).table()
assert len(table['states']) == 1795
```

To construct a different machine, use `Machine(states, start, halt, rules)`
with a rule `Rule(target, write, move)` for every pair `(q, read)` where
`q != halt` and `read` is 0 or 1. Moves are `'L'`, `'R'`, or `'S'` (stay).
The blank symbol is 0. The halt state is padded by identity in the ordinary
machine trace but is sent to zero by the dynamical map. This accounts for
the extra extinction step.

## Build the article

A conventional TeX Live installation with the packages named in the source
is sufficient. Run:

```sh
bash build.sh
```

Or run `pdflatex -interaction=nonstopmode -halt-on-error article.tex` three
times to stabilize the contents and references.

## Proof and novelty status

The new mathematical arguments are presented in full but have not been
formalized in Lean or independently reviewed. Literature priority has not
been established. The article does not claim a historically recognized
open problem has been settled without a verified problem/source match.

The generic compiler accepts any binary source Turing-machine table. The
universal existence theorem uses a fixed ordinary universal machine, but
this archive exports a NONUNIVERSAL test example, not an audited universal
machine table. The fixed-arity unbounded polynomial is obtained through MRDP
and is not numerically expanded. The explicit JSON polynomial is the bounded
certificate, whose parameters are clearly specified.

The inspected ProveIt revision is
`b6bf6406a4c49017fedc6fba068b36c634987150`. No repository files were modified,
and no ProveIt Lean build was run during preparation of this archive.
