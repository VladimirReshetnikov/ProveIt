# Report 217 Exact ratio two partitions at fixed asymptotic order

This archive provides a self-contained proof and reproducible calculation for
partitions whose largest part is exactly twice their smallest (OEIS A118096).

Read `Report217.pdf` or edit `article.tex`. The main coefficient theorem holds
at every fixed order. Four explicit corrections, finite exact coefficient
rules, continuous inverse expansions, two-ceiling threshold bounds, and
eventual increase and strict log-concavity are included.

## Historical scope

This is an independently derived refinement, not a claim of novelty or a
solution of a known open problem. The leading equivalent was already listed
by Kotěšovec in 2025. McIntosh (1998) and Zhou (2017) provide earlier radial
all-order machinery. Pittel (2007) is directly adjacent bounded-ratio
literature, but its full theorem text was not accessible for this comparison.
Historical overlap is consequently unresolved; no source clearance is claimed.
The nearby mock-theta partition conditions are distinguished in the article.
See `SOURCE_NOTES.md` for links and the boundaries of the comparison.

## Rebuild from the actual extracted archive

The rebuild is offline and nondestructive. Choose a new or empty destination;
source files and existing files are never overwritten. It verifies the
source manifest, runs exact tests normally and under `python -O`, regenerates
all exact tables, and compiles the PDF using a private TeX work directory.

    python3 -B rebuild.py --out ../Report217-rebuild

Requirements: Python 3.9 or newer; an installed TeX Live distribution with
pdfTeX, LaTeX, AMS packages, Latin Modern, geometry, microtype, hyperref,
mathtools, booktabs and enumitem. No shell escape is used. The script discovers
the installed TeX tree; it does not install software or use a network.

For the standard-library exact checks without PDF compilation:

    python3 -B rebuild.py --out ../Report217-exact-only --skip-pdf

To rerun the optional high-precision diagnostic as well, provide an existing
`mpmath` installation (tested with mpmath 1.3.0):

    python3 -B rebuild.py --out ../Report217-with-diagnostics --numerical

The exact tables are byte-deterministic. The PDF is byte-stable on repeat
passes and reproducible with the tested TeX installation; a different TeX or
font version can produce different PDF bytes without changing the content.
`REBUILD_RECEIPT.json` in the fresh output records exact comparisons and hashes.
The expected generated-file hashes are also in `generated/SHA256SUMS.json`.
The top-level `MANIFEST.json` covers every public payload file except itself.

## Files and guarantees

- `article.tex` and `Report217.pdf`: the complete article
- `code/`: exact quadratic-field generator, independent Gaussian oracle,
  partition algorithms, formal inverse generator, tests, optional diagnostics
- `generated/`: reproducible exact JSON and TeX tables, test receipt, and
  separately labeled numerical diagnostic results
- `rebuild.py`: complete fresh-output offline rebuild
- `SOURCE_NOTES.md`: attributions and historical-comparison limits
- `MANIFEST.json`: SHA-256 payload pins

The exact algorithms use Python integers and `Fraction` rational pairs for
Q(sqrt(5)). The documented generators and Q5 constructor reject floating-point arguments.
Whole-degree truncation supports
arbitrary fixed order; resource use increases with the order. All public
argument and consistency checks use explicit exceptions and remain active
under `python -O`. See `code/README.md` for individual commands and JSON schema.

Counts are computed from the defining generating function, without a network
or an OEIS data file. The archive contains no third-party papers or source
code and no private research or review files.

## Meaning of the numerical diagnostics

At n=10000, the four-correction approximation has relative error about
-1.4599790544e-8, computed against the exact integer count. The error convention
is approximation/exact minus one. The three-term implicit inverse is about
0.0000270941 above n=10000 when evaluated at that exact sequence value.
These are diagnostics, not certified remainder bounds or exact-rounding
certificates. The theorem's constants and validity thresholds are not made
effective. Keep both ceilings in the integer inverse theorem.

## Recreate the archive

The package can also recreate its ZIP from the manifest-listed payload:

    python3 -B archive.py --out ../Report217-source-copy.zip

The output must not exist and must lie outside the source directory. Entry
ordering, permissions, paths and timestamps are fixed. ZIP bytes are identical
with the tested Python/zlib version; compression-library changes may alter
the compressed bytes while preserving the pinned file contents.
