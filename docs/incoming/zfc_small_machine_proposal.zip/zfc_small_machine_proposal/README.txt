Equality-Free Consistency Kernels and Exact Source Compression
=============================================================
Research report prepared for Vladimir Reshetnikov, 16 October 2026.

Read report.pdf. The complete editable LaTeX is report.tex, with
sections/foundations.tex, sections/logic.tex, sections/late-update.tex,
machines/proof_notes.tex,
and bibliography.tex. The bibliography links to exact primary sources.

Main proposal
-------------
Use the equality-free CP + all GIC source theory, with one binary
relation, one fixed axiom, and one schema. The report supplies an
ordinary mathematical interpretation of ZF without Foundation/Choice
in that source, and the ZFC-provable consistency calibration:
  Con(U) <-> Con(U + IR) <-> Con(ZFC).

The archive also contains two complete binary blank-tape candidates:
  machine-250-oldrho6.tm: 250 working states, 500 rows; preferred.
  machine-249-dual.tm:   249 working states, 498 rows; exploratory.

These tables are NOT newly certified consistency machines.
Exact macro-word preservation and the normal-exit argument establish
preservation of their respective experimental abstract register programs.
Restricted-calculus completeness, enumeration, and binary simulation
remain explicit proof obligations. The report audits four algebraic
counterinterpretations and supplies a positive full-first-order target
calibration. The latest generic old/dual refutation counterexample does
not model the actual C/G theory bundles.
No new Lean or Coq kernel build is claimed.

The newer source08 result also calibrates equality-free subset-PSC alone
with ZFC by hereditary saturation. Its current reduced PSC proof engine,
however, has an elementary non-refutation proof. The separate 252-state
PSC experiment needs a logical repair before it can implement this goal.

Repository cutoffs
------------------
VladimirReshetnikov/ProveIt:
  Research review:
e7c4cadf9b180e4b1801755b09777a7572412360
  Numerical replay:
17d0f2eaa650901cda59764dfcc4661c199e49c8

All four distinct commits named in the request and relevant newer work
through the research cutoff were investigated. None of the nine numerical
replay dependencies changed between these pins. b07d1a27 was listed twice in the
request. The more recent upstream 253-state PR/Coq CI result is audited
separately from the experimental 252, 250 and 249 tables.

Reproduction
------------
Python 3.10 or newer, standard library only for the delivered checks.
Do not run audit scripts with -O: assertions are required.

1. Self-contained codec, logical-counterinterpretation and table audits:

   python3 build.py --checks

2. Rebuild both tables from their frozen grammars and exact pinned sources:

   python3 machines/verify_candidates.py --repo /path/to/ProveIt

   A partial checkout containing the nine files listed in
   machines/source_pins.json is sufficient. If unavailable, explicitly fetch
   the pinned public dependencies, then run without --repo:

   python3 machines/fetch_dependencies.py
   python3 machines/verify_candidates.py

   Fetching needs internet access. Replay itself is offline and deterministic;
   the heuristic grammar search is not rerun.

3. Full delivered checks against a pinned checkout:

   python3 build.py --checks --machines --repo /path/to/ProveIt

   This also replays the finite modal diagnostic. Its lack of a countermodel
   is not evidence that the candidate logical calculus is complete.

4. Recompile the PDF with a standard TeX distribution:

   python3 build.py --pdf

   pdflatex is called without shell escape. It needs the packages listed in
   report.tex (standard TeX Live / MiKTeX packages). No bibliography server
   or internet connection is required.

5. Rebuild the file hashes and ZIP:

   python3 build.py --archive

   This writes ../zfc_small_machine_proposal.zip, with fixed archive timestamps.
   MANIFEST.sha256 excludes itself and the ZIP. Re-running audits changes
   result files where runtime measurements are recorded; regenerate the
   manifest/archive after such changes. PDF byte-for-byte reproducibility
   across TeX distributions is not promised.

Artifact map
------------
report.pdf, report.tex, sections/, bibliography.tex: complete report.
machines/: exact 250/249 tables, frozen grammar certificates, replay code.
code/: original codec, algebraic logic, table and modal diagnostics.
results/: executed output, PDF build information and visual-review record.
provenance.json: source pins, upstream CI evidence and attribution.
provenance/*snapshot_manifest.json: both audited download inventories.
results/late-source-audit.json: late Lean source hashes and recorded results.
STATUS.json: machine-readable proved/open boundary.
MANIFEST.sha256: delivered-file integrity hashes.
build.py: offline build/check/archive entry point.

Attribution and scope
---------------------
The starting construction and register program are Mira-Cult's; Jeff's
proof snapshot is 297ab8df7e5de329605c3875b4934643b371a5e3. Andrew James
Wade's MIT-0 backend and ProveIt's experimental emitter/coding changes
are separately credited in the report and source pins. The archive
does not redistribute these external source packages.

The detailed CP/GIC interpretation and the logical/codec audit are
reconciled with the late formal and mathematical results. Source08 is
credited for the PSC-only calibration and the general exact-word grammar
strategy on its older 185-call emitter (269 = 207 + 62 states). Our frozen
250/249 tables apply that strategy to the 138-call experimental emitters,
with exact certificates, an exit-effect argument, and independent audit code.
Source09 is credited for the observational quotient and decoder controls.
No historical-priority or absolute-minimality assertion is made.

