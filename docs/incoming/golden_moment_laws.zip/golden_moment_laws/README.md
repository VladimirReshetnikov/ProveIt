# Golden-ratio moment laws for OEIS A088714 and A088713

Research article prepared for Vladimir Reshetnikov, October 1, 2026.

## Read first

`article.pdf` is the 23-page article. `article.tex` is its editable LaTeX
source. The source uses the three small table fragments in `data/`, so keep
the directory structure when compiling. The bibliography is included in the
TeX file; no BibTeX run or external bibliography file is required.

The article studies

    A(z) = 1 + z A(z)^2 A(z A(z)),
    C(z) = 1 / (1 - z A(z)),

whose coefficients are A088714 and A088713. It develops a positive-measure
construction and proves strict Hankel positivity, strict infinite
log-convexity, exact Stieltjes-transform identities, complementary
golden-ratio endpoint laws with explicit constants, consecutive-coefficient
asymptotics, and logarithmic far-tail asymptotics. It also constructs
certified algebraic approximants with Fibonacci-ratio endpoint exponents.

The earlier ProveIt Bell-scale growth theorem is credited and reproved in
Appendix A. The specific new deductions and the inherited general machinery
are distinguished in the introduction, Appendix B, and `SOURCE_AUDIT.md`.
These are unrefereed written proofs, not Lean-checked results. A bounded
literature search is not certification of historical priority. In
particular, the article does not claim to settle the earlier finer
multiplicative Bell-number conjecture or prove that the measures have
densities.

## Contents

- `article.pdf`, `article.tex`: complete article and source, including eight
  proposed research questions and a proof-dependency audit.
- `build.sh`: compile the paper with three pdfLaTeX passes.
- `code/verify.py`: independent exact-integer/rational audits.
- `code/orbit_bounds.py`: outward-rounded enclosures on an exact inverse orbit
  of the true Stieltjes transform, seeded by finite moment inequalities.
- `code/make_tables.py`: regenerate the paper's table fragments.
- `data/coefficients.csv`: both coefficient sequences through index 401.
- `data/verification.json`, `data/verification.txt`, `data/run_output.txt`:
  complete verification results and diagnostics.
- `data/orbit_bounds.json`, `data/orbit_output.txt`: exact rational seed,
  logarithmic location intervals, and transform enclosures.
- `data/*_table.tex`: table fragments used by the article.
- `data/environment.txt`: the actual software versions used.
- `SOURCE_AUDIT.md`: provenance, novelty scope, and verification limitations.

## Reproduce the mathematical checks

Python 3.10 or later is sufficient. Only the standard library is required;
there are no network calls, CAS dependencies, or package installations.
Run from the extracted package directory:

```sh
python3 code/verify.py --n 401
python3 code/orbit_bounds.py
python3 code/make_tables.py
```

Run the first command without Python's `-O` option: assertions implement the
checks. The scripts replace their generated data files. The runtime field
in the verification report will naturally change between runs. The
coefficient calculation performs N(N+1)(N+2)/6 integer products and stores
O(N^2) integers; these are not constant-cost bit-complexity claims.

The completed run checked all displayed OEIS prefix values, two independent
formal identities through degree 30, coefficient stabilization through stage
16, direct rational full-Fock moments through order 10, 17,768 generalized
Hankel minors, 40 leading/shifted determinants, 20 exact determinant bridge
identities, and 1,128 positive entries after six log-convexity iterations.
Finite audits supplement rather than replace the all-index proofs.

The orbit script uses 100-digit Decimal arithmetic. Ordinary arithmetic is
rounded outwards; logarithms, square roots, and exponentials are enlarged by
adjacent representable values, and a product subtracted from a bound is
rounded in the opposite direction. Its enclosures concern particular true
inverse-orbit points, not every point in their reported location intervals.
They do not prove the global golden-ratio limit; that proof is in Section 7.

## Build the PDF

A normal TeX Live or MiKTeX installation with pdfLaTeX and the packages in
the preamble is sufficient. From the package directory:

```sh
sh build.sh
```

On Windows without a POSIX shell, execute the following command three times
from that directory:

```text
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The distributed table fragments can be used directly; Python need not run
before building the article. The supplied PDF was built successfully with
no overfull/underfull boxes, undefined references, or LaTeX warnings, and all
23 pages were rendered for layout inspection. Fonts are embedded in the PDF;
no standalone font files are distributed.

## Repository status

This is a standalone research package. It does not modify the ProveIt
repository, the OEIS, or the user's persistent Library. The precise
repository snapshot and prior source path are recorded in the source audit.
