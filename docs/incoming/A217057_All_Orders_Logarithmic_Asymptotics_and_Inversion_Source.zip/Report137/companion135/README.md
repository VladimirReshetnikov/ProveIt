# Report 135: refinements for one classical 1234 occurrence

This offline, self-contained companion contains the Report135 PDF and TeX, a
standard-library-only verifier, minimal reusable exact data, an optional SymPy
builder for the factored rational constant-term kernel, and the unchanged
Report134 reproducibility companion in `companion134/`. Nothing from a prior
working directory or the network is needed. Python 3.10+ is required. PDF builds
also need pdfLaTeX and the packages named in the article's source.

The release environment used Python 3.12.14, optional SymPy 1.14.0,
pdfTeX 3.141592653-2.6-1.40.26 (TeX Live 2025/dev/Debian), and kpathsea
6.4.0/dev. The article names its direct LaTeX packages; their ordinary
transitive packages and Latin Modern/AMS fonts are also required. No package
installation or network access is performed by the scripts.

Report135 proves rational-diagonal/D-finite structure, the first two relative
corrections, a strictly positive logarithmic third correction, and refined
inverse-threshold enclosures from Report134's
exact decomposition and bounds. Read the articles for proofs. The computations
below verify finite identities and algebraic formulas; they do not turn finite
residuals or a partial signed series into an infinite-sequence theorem.

## Fast use

`BUNDLE` is this directory. `OUT` is an existing directory outside the bundle.
Each named output path must be new. Commands may run from any working directory.

    python -I -B BUNDLE/verify.py check
    python -I -B BUNDLE/verify.py replay --output OUT/replay
    python -I -B -O BUNDLE/verify.py replay --output OUT/replay-optimized
    python -I -B BUNDLE/verify.py selftest --output OUT/selftest
    python -I -B BUNDLE/verify.py pack --output OUT/Report135.zip
    python -I -B BUNDLE/verify.py build --output OUT/pdf-build

All outputs, caches, TeX files, and test copies go outside the bundle. The
verifier disables bytecode files as well as recommending `-B`; its checks use
exceptions and remain active under `-O`. Replay JSON is deterministic for a
fixed Python decimal implementation. Normal and optimized runs must agree.
No local companion module is executed before the complete inventory, SHA256
hashes, companion identity, and exact-data schema have been checked. The
verified source bytes are loaded directly, rather than importing by search path.

## What replay checks

- The generalized binomial convention, including negative arguments, and the
  six-term dimension identity on all 7,106 partitions of sizes 0 through 60,
  compared with both hook dimensions and independent corner-removal recursion
- Complete F matrices through size 20: 3,311 entries, comparing the binomial
  dimension encoding with the hook implementation. Complete matrices through
  size 12 are additionally compared with independent removed-cell strip tests
- All exact values u_0 through u_20, calculated by both binomial and hook
  encodings. These do not guess a recurrence. The 24-fold proof encoding is not
  naively enumerated: the equivalent nested strip sums are evaluated
- The D, E, J, K transform formulas as exact identities of rational polynomials
  in k, after removing the factor (3/2)^k. Euler-operator moments are constructed
  independently using Stirling numbers and rising factorials, so this check is
  for all k, not interpolation or sampled decimal fits
- All 12 independent CT exponent columns, the two-term H numerator, the
  alpha-independent inner sizes, exact contour-radius inequalities, and finite
  shuffle coefficient extractions. This is not a 42-dimensional integration
- Exact R and S partial sums through t=20. Selected fractions are frozen in
  `exact_data.json`; the R layers must also match Report134's implementation
- All 819 pairs (m,p,q), 0<=m<=12, in the new unitary character integral,
  reconstructed from exact Fourier polynomials and compared with independent
  Young-lattice dimensions and removed-cell strips. Also 62 composition moment
  checks and 1,000 signed correction-coefficient normalizations
- Exact centered-angle trace/Weyl Taylor polynomial identities and Gamma radial
  moments giving the avoidance coefficient -11/2
- Exact fixed-boundary residuals at n=30,60,120,240. These are finite diagnostics
  of the predicted first coefficient, not tests of the required uniform error
- Exact symbolic cancellation of the 1/L and 1/L^2 terms in the inverse center,
  treating s, beta, lambda as independent formal symbols. A separate 80-digit
  decimal Newton calculation uses the synthetic model M0=1, beta=2 at
  L=100,1000,10000. It never substitutes a guessed R or S

The file `refinements.py` is reusable and has no filesystem or command-line
side effects. The unchanged exact tableau routines are in
`companion134/certificate.py`; the independent finite reconstruction is in
`companion134/independent.py`. `exact_data.json` and `second_exact_data.json` use integer counts and canonical
rational strings, not rounded decimals. The second-correction implementation is
`second_refinements.py`, also free of filesystem and command-line side effects.

## Second correction and logarithm checks

The same standard-library replay also checks:

- L and M transform formulas as exact polynomial identities for every k
- Centered-angle identities through degree six, the discriminant identity,
  factored Weyl density through degree four, exact radial/angular moments,
  avoidance coefficient 20, and the Q-moment correction -24
- Exact all-p identities for the quartic normalized boundary character and its
  second coefficient; the composition fourth moment is independently enumerated
  for p=0 through 30
- Shifted and endpoint series algebra, including that 20z^3 C is the sole
  cubic-in-z third-order endpoint term, and the finite-boundary S2 coefficients
- Bivariate binomial contractions M_dd=99, M_de=49, M_ee=25;
  <C,C>=1,393,848; and the positive kappa factor 43,020 multiplying sqrt(3)/pi
- Exact signed S2 partials through t=20, with selected rational fixtures,
  and exact fixed-boundary second residuals through n=480
- The improved x3 inverse center's exact formal cancellation through 1/L^3.
  Its separate 80-digit Newton diagnostic uses synthetic M0=1, beta=2, mu=3,
  eta=5. It never estimates the unknown S2 or delta

These symbolic/local calculations complement the article's uniform analytic
bounds and endpoint-tail proof. They do not prove convergence, a tail bound,
or an integer-threshold algorithm on their own. First-correction diagnostics
remain included as separately valid, weaker checks.

## Important limits

The positive R partial sums are lower bounds. The S and S2 series are generally
signed;
their partial sums and S_partial/R_partial - 11/2 are not certified values, bounds,
or error-controlled estimates of S, S2, beta, or delta. No decimal value or sign
of these infinite signed coefficients is certified. The logarithmic coefficient
kappa=43020 sqrt(3)/pi is exact and positive by a separate explicit contraction.
The article's O constants are not made
effective here. The inverse diagnostic concerns the corrected continuous model;
it is not a certified algorithm for integer thresholds. The uncertainty must
remain inside both ceilings. The improved inverse enclosure has O(L^-3)
uncertainty with the logarithmic
term included, or O(log L/L^3) when it is omitted; the constants are not
effective. No exact ceiling formula is claimed. No recurrence, differential
equation, useful order bound, certified tail for S or S2, finite nonlogarithmic
third coefficient, or all-orders asymptotic expansion is supplied.

The standard-library replay checks the new algebra, not the published binomial
closure theorem. The rational-diagonal/D-finite conclusion follows from that
theorem and the article's explicit encoding. The rational CT integrand requires
the specified contours/expansions; it is not asserted analytic at the simultaneous
origin of its 42 CT variables.

## Optional SymPy kernel builder

    python -I -B BUNDLE/kernel_sympy.py

This writes JSON only to stdout. It uses SymPy, which is optional and not used by
`verify.py replay`. The module exposes `build_kernel()` returning z, the tuple of
42 CT variables, and the unexpanded rational expression including z^4. Its
checks use explicit exceptions under normal and optimized Python. The factored
expression contains 24 geometric denominator factors. The builder does not
perform creative telescoping or derive a recurrence.

## Unchanged Report134 companion

All eight files under `companion134/` are byte-for-byte the frozen original
release. Its manifest SHA256 is
`87bd951e61b6a51fd8f8ec534b0bf64545535ddd7498f75013ef6656e08ed94b`.
The top-level verifier checks this identity and then every original file against
that original manifest. Read its README for its stronger, slower complete replay:

    python -I -B BUNDLE/companion134/verify.py replay --output OUT/report134-replay

That replay reconstructs the T=40, I=10 exact lower certificate, includes literal
permutation enumeration through n=8, and checks the original gluing fixtures.
It is preserved for completeness rather than rerun silently by the new fast
replay. Its older `seal` command is maintainer-only and writes its own manifest;
do not run it on this frozen companion. All commands documented here leave the
bundle unchanged. The original Report134 files are explicit mathematical
companions, not superseded by Report135.

## Integrity, outputs, and reproducibility

The top-level closed inventory is the exact set hard-coded in `verify.py`.
Unknown files, missing files, symlinks, nonregular files, JSON duplicate keys,
wrong types, changed hashes, or a changed Report134 companion are rejected.
The manifest covers all payload bytes except itself. This is integrity checking,
not a digital signature or protection against a malicious party replacing both
program and manifest.

Output targets must be absent, outside the bundle, and have existing real
(non-symlink) directory parents. Parent-traversal components and symlink ancestors
are refused; existing files are never overwritten. Self-tests run only on new
external copies. They exercise corrupted payloads, schemas, manifests, output
paths, optimized Python, and byte-identical repacking after fresh extraction.
The path checks are intended for an ordinary local filesystem, not a hostile
concurrent administrator changing mount points or directories during a command.

Packaging uses sorted names, fixed timestamps, fixed Unix file modes, and
uncompressed ZIP entries to avoid zlib-version variation. The archive contains
one top-level `Report135/` directory. Two packs of the same verified bytes must
be identical. PDF builds copy the TeX externally, disable shell escape, fix date
and timezone environment values, use private TeX cache/config directories, and
run two passes. Build output records the PDF hash and whether it matches the
frozen PDF. Byte identity across different TeX distributions is not promised.

For maintainers only, after intentionally preparing/reviewing every payload:

    python -I -B BUNDLE/verify.py seal --output OUT/new-manifest.json

This produces a new manifest outside the bundle; it neither edits payloads nor
installs that manifest. Seal deliberately does not check the old top-level
hashes, but does check the closed payload, exact-data schema, and frozen
Report134 companion. Install the reviewed manifest manually, then rerun check,
normal and optimized replay, selftest, build, and pack. A manifest is not a
mathematical audit or permission to describe a pending proof review as passed.
