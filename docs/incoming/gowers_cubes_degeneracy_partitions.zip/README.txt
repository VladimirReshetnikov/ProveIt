HIGHER-ORDER CUBE EXPANSIONS AND SHARP DEGENERACY BOUNDS
IN GOWERS' SZEMEREDI FRAMEWORK

Simultaneous polynomial partitions, exact constants, and quantitative obstructions
Research report prepared for Vladimir Reshetnikov, 6 October 2026

CONTENTS

gowers_cubes_degeneracy_partitions.pdf   Complete 35-page article.
gowers_cubes_degeneracy_partitions.tex   Complete article source and bibliography.
partition_exponents.pdf                Vector figure required by the TeX source.
partition_exponents.png                Convenient raster preview of the figure.
make_partition_figure.py               Optional figure regeneration script.
verify_refinements.py                  Exact finite checks, Python standard library only.
verification_results.json             Results of all successful finite checks.
provenance.json                        Inspected commit, source blobs, and references.
SHA256SUMS.txt                         Integrity checks for the files in this archive.
README.txt                            This guide.

REBUILD THE ARTICLE

Keep the TeX file and partition_exponents.pdf in the same directory, then run:

  pdflatex -interaction=nonstopmode -halt-on-error gowers_cubes_degeneracy_partitions.tex
  pdflatex -interaction=nonstopmode -halt-on-error gowers_cubes_degeneracy_partitions.tex

Alternatively, use:

  latexmk -pdf gowers_cubes_degeneracy_partitions.tex

The bibliography is embedded; BibTeX and external bibliography files are not needed.
Standard LaTeX packages are listed in the preamble. A conventional TeX Live
installation provides them. The supplied PDF has already been compiled, checked
for unresolved references and overflowing text, and visually inspected.

REPRODUCE THE FINITE CHECKS

Python 3.8 or newer is sufficient; no third-party Python modules are required:

  python3 verify_refinements.py --output verification_results.json

The script checks 6,188 small vertex configurations in the four-dimensional
cube, fourth and fifth moment coefficients in 12 finite cyclic-group cases,
ternary certificate class counts, pure-parity hyperplanes, exceptional-diagonal
probabilities, and all binary determinants of sizes two through four.

The optional figure script requires matplotlib:

  python3 make_partition_figure.py

The vector figure is supplied, so regenerating it is not required to compile
the article. Regeneration reproduces the mathematical series and presentation,
not necessarily identical PDF bytes across matplotlib versions.

MAIN RESULTS AND WHERE TO READ THEM

Theorem 2.8, page 10:
Sharp first-order density (k+C_d)/p + O_{k,d}(p^-2) of degenerate arrangements,
with explicit finite inequalities and an exact formula for C_d.

Corollary 2.9, page 11:
Direct replacement of the Lemma 15.5 size factor by k+2,585,445 in the stated
parameter range, retaining the source's sampling exponent.

Theorem 3.1, page 14; Corollary 3.9, page 18; Theorem 3.12, page 20:
Exact fourth and fifth cube coefficients in all finite abelian groups,
including order-two and order-three contributions, a stronger upper bound,
and sharpness of the unrestricted fourth-order coefficient for indicator sets.

Theorem 4.2, page 22; Corollaries 4.4 and 4.5, pages 24-25:
A recurrence-to-partition transfer, stronger simultaneous quadratic partition
exponents, and a specialization to a shared leading frequency.

Section 5, pages 26-29:
A volume obstruction and a necessary exponent region for universal polynomial
partitions, with all constants and limiting qualifications stated.

Sections 7-9, pages 31-34:
Lean integration points, exact finite verification, and twelve research questions.

SCOPE AND ATTRIBUTION

The article contains proofs of its local refinements. Its general numerical
quadratic exponent imports Corollary 1.2 from Lau's 2024 preprint; the recurrence
interface also accepts Maynard's published result and Gowers' scalar recurrence.
These inputs are attributed explicitly. Known three-cube circuits are credited.

The finite checks do not certify the general theorems. The report does not
claim a new globally strongest Szemeredi bound or historical priority over the
entire literature. The Lean source was inspected to establish exact definitions
and integration points, but no new Lean proof has been compiled or kernel-checked.
The source repository was not modified.

The full source record is in provenance.json and the article bibliography.
Third-party papers and repository source files are referenced, not redistributed.
