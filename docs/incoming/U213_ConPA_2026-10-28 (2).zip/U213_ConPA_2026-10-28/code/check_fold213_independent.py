#!/usr/bin/env python3
"""Independent exhaustive finite-frame proof of the native 167 -> 172 fold.

Every admitted five-cell frame at every old working state is checked.
The exterior is opaque: a path reading it is rejected. Tests compare full
local tape words, head coordinates and projected states, with no internal
halt. This is a mathematical finite certificate, not a proof-assistant kernel.
"""
from pathlib import Path
import argparse, hashlib, itertools, json


def need(ok, why):
    if not ok:
        raise ValueError(why)


def read(path, count):
    table = {}; starts = []
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(line); continue
        if not line or line.startswith('#'): continue
        q, b, w, d, z = line.split(); q, b, w, z = map(int, (q, b, w, z))
        need(q >= 0 and z >= 0 and b in (0, 1) and w in (0, 1) and d in ('L', 'R'), 'bad row')
        need((q, b) not in table, 'duplicate row')
        table[q, b] = w, (1 if d == 'R' else -1), z
    states = {q for q, b in table}
    need(starts == ['#! start 0'], 'start mismatch')
    need(len(states) == count and set(table) == {(q,b) for q in states for b in (0,1)}, 'census mismatch')
    need(0 in states and 254 not in states and {z for w,d,z in table.values()} - states == {254}, 'closure mismatch')
    return table, states


def project(q): return 172 if q == 167 else q

def invariant(q, h, tape): return q != 167 or tape[h-1] == 1


def run(table, q, tape, steps):
    h = 0; tape = dict(tape); trace = []
    for _ in range(steps):
        need(q != 254, 'internal halt')
        need(h in tape, 'read outside finite frame')
        b = tape[h]; w, d, z = table[q,b]
        trace.append([q,h,b,w,d,z]); tape[h] = w; h += d; q = z
    return q, h, tape, trace


def finite_check(old, new, states, guarded=True):
    counts = {}; examples = {}; frames = 0
    for q in sorted(states):
        for bits in itertools.product((0,1), repeat=5):
            tape = dict(zip(range(-2,3), bits))
            if guarded and not invariant(q,0,tape): continue
            a = 2 if q == 167 and tape[0] == 0 else 1
            b = 6 if a == 2 else 1
            oq, oh, ot, old_trace = run(old, q, tape, a)
            need(invariant(oq,oh,ot), ('noninductive guard',q,bits))
            nq, nh, nt, new_trace = run(new, project(q), tape, b)
            need((nq,nh,nt) == (project(oq),oh,ot), ('endpoint mismatch',q,bits,old_trace,new_trace))
            frames += 1; key = f'{a}:{b}'; counts[key] = counts.get(key,0)+1
            if q == 167:
                examples.setdefault(f'{tape[0]}{tape[1]}', {'left':1,'current':tape[0],'right':tape[1], 'old':old_trace,'new':new_trace})
    return {'admissible_frames':frames,'block_counts':counts,'special_cases':examples}


def controls(old, new, states):
    results = []
    def reject(name, a, b, guarded=True):
        try: finite_check(a,b,states,guarded)
        except ValueError as e: results.append({'name':name,'status':'REJECTED','reason':str(e)[:240]})
        else: raise ValueError('mutation survived: '+name)
    # Change shared helper rows in BOTH tables. The stated quotient still
    # holds, so these controls test semantics, not just delta/hash identity.
    for key in [(172,0),(172,1),(112,1),(209,0),(157,0),(157,1),(67,0),(151,0),(148,0),(186,1)]:
        a, b = dict(old), dict(new); w,d,z = a[key]
        a[key] = (1-w,d,z); b[key] = (1-w,d,project(z))
        reject('flip shared helper write '+str(key),a,b)
    a, b = dict(old), dict(new)
    a[214,1] = (0,1,167); b[214,1] = (0,1,172)
    reject('break unique predecessor guard',a,b)
    reject('omit left-one guard',old,new,False)
    return results


def verify(old_path, new_path):
    old, states = read(old_path,214); new, _ = read(new_path,213)
    expected = {(q,b):(w,d,project(z)) for (q,b),(w,d,z) in old.items() if q != 167}
    need(new == expected, 'candidate is not exact stated quotient')
    incoming = sorted([q,b,w,d,z] for (q,b),(w,d,z) in old.items() if z == 167)
    need(incoming == [[214,1,1,1,167]], 'incoming guard census differs')
    result = finite_check(old,new,states)
    need(result['admissible_frames'] == 6832 and result['block_counts'] == {'1:1':6824,'2:6':8}, 'frame census differs')
    result.update({'status':'EXHAUSTIVE_GUARDED_BLOCK_PASS','old_states':214,'new_states':213,'incoming':incoming,
      'guard':'old state 167 implies left neighbor is one','frame_offsets':[-2,-1,0,1,2],
      'old_time_bound':'T <= S <= 3*T for complete finite halting runs',
      'scope':'Every initial binary tape started in state 0; exterior unread by each checked block. Blank-tape arithmetic instance formalizable in PA.',
      'proof_assistant_kernel_certificate':False,'negative_controls':controls(old,new,states),
      'sha256':{'old':hashlib.sha256(Path(old_path).read_bytes()).hexdigest(),'new':hashlib.sha256(Path(new_path).read_bytes()).hexdigest()}})
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('old',type=Path);p.add_argument('new',type=Path);p.add_argument('--output',type=Path);a=p.parse_args()
    result=verify(a.old,a.new);raw=json.dumps(result,indent=2)+'\n'
    if a.output:a.output.write_text(raw)
    print(raw,end='')
if __name__=='__main__':main()
