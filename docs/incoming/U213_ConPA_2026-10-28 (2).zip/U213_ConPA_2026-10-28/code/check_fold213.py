#!/usr/bin/env python3
"""Verify the 167 -> 172 fold by an inductive one-cell guard and exact blocks.

The checker treats the complete unbounded exterior as opaque: any attempt to
read or write it is rejected.  Four local patterns cover every binary tape
with cell -1 equal to one.  It proves a finite stuttering lemma; it does not
infer a nonhalting theorem from a bounded simulation.
"""
from pathlib import Path
import argparse,hashlib,json,sys

def need(value,why):
    if not value:raise ValueError(why)

def read(path):
    table={};headers=[]
    for line in Path(path).read_text(encoding='ascii').splitlines():
        if line.startswith('#! start '):headers.append(line);continue
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
        need((q,b)not in table,'duplicate transition')
        need(min(q,z)>=0 and b in(0,1)and w in(0,1)and d in('L','R'),'invalid transition')
        table[q,b]=(w,1 if d=='R'else -1,z)
    need(headers==['#! start 0'],'wrong start convention')
    return table

def validate(table,count):
    states={q for q,b in table}
    need(len(states)==count,'wrong working-state census')
    need(set(table)=={(q,b)for q in states for b in(0,1)},'non-total table')
    need(0 in states and 254 not in states,'wrong start/halt states')
    need({z for w,d,z in table.values()}-states=={254},'wrong target closure')
    return states

def execute(table,start,tape,length):
    cells=dict(tape);q=start;head=0;trace=[];read_cells=set()
    for _ in range(length):
        need(head in cells,'read outside the stated three-cell window')
        need(q!=254,'halt hidden inside a comparison block')
        b=cells[head];w,d,z=table[q,b]
        trace.append([q,head,b,w,d,z]);read_cells.add(head)
        cells[head]=w;q=z;head+=d
    return (q,head,cells),trace,sorted(read_cells)

def check(old,new):
    oldstates=validate(old,214);newstates=validate(new,213)
    need(newstates==oldstates-{167},'the wrong state was deleted')
    need(old[167,0]==(0,1,218)and old[167,1]==(1,1,184),'wrong removed rows')
    incoming=sorted((q,b,w,d)for(q,b),(w,d,z)in old.items()if z==167)
    need(len(incoming)==1 and incoming[0][1:]==(1,1,1),
         'the preceding-one entry invariant is not established')
    wanted={(q,b):(w,d,172 if z==167 else z)
            for(q,b),(w,d,z)in old.items()if q!=167}
    need(new==wanted,'the candidate is not the asserted one-state fold')
    cases=[]
    for current in(0,1):
        for following in(0,1):
            tape={-1:1,0:current,1:following}
            old_length=1 if current else 2
            new_length=1 if current else 6
            left,lt,lr=execute(old,167,tape,old_length)
            right,rt,rr=execute(new,172,tape,new_length)
            need(left==right,'the complete configurations do not agree')
            need(left[2]==tape,'the comparison changed the tape')
            need(left[0]not in(167,254),'invalid common endpoint')
            cases.append({'current':current,'following':following,
                'old_steps':old_length,'new_steps':new_length,
                'endpoint_state':left[0],'endpoint_head':left[1],
                'old_trace':lt,'new_trace':rt,'old_read_cells':lr,
                'new_read_cells':rr,'unchanged_local_tape':True,
                'unbounded_exterior_untouched':True})
    return {'status':'PASS','old_working_states':214,'new_working_states':213,
        'removed_state':167,'representative_state':172,'start':0,'halt':254,
        'incoming_edges':incoming,'guard':'cell immediately left of the head is 1',
        'guard_proof':'State 167 is not the initial state. Its sole predecessor '
            'reads 1, writes 1, and moves R. Thus every entry, on every initial '
            'binary tape, establishes the guard.',
        'scope':'Every initial binary tape, with state 0 and arbitrary initial head; '
            'both finite halting and infinite running are preserved.',
        'finite_case_coverage':'4 assignments of the unconstrained current and '
            'following cells; all other tape cells remain universally opaque.',
        'cases':cases,
        'pa_formalizability':'Finite transition reasoning and induction on run '
            'checkpoints, with positive bounded simulation blocks in both directions.'}

def mutation_controls(old,new):
    records=[]
    def reject(name,a,b):
        try:check(a,b)
        except (ValueError,KeyError) as exc:
            records.append({'name':name,'rejected':True,'reason':str(exc)})
        else:raise ValueError('damaged certificate accepted: '+name)
    # Both machines receive the same helper damage, preserving the purported
    # patch relation. These failures therefore exercise the local simulator.
    helpers=[(172,0),(112,1),(209,0),(157,0),(157,1),(67,0),(151,0),(148,0),(186,1)]
    for key in helpers:
        for field in('write','direction'):
            a=dict(old);b=dict(new);w,d,z=a[key]
            a[key]=b[key]=(1-w,d,z)if field=='write'else(w,-d,z)
            reject(f'common_helper_{key[0]}_{key[1]}_{field}',a,b)
    predecessor=next(q for(q,b),(w,d,z)in old.items()if z==167)
    a=dict(old);b=dict(new);a[predecessor,1]=(0,1,167);b[predecessor,1]=(0,1,172)
    reject('incoming_guard_write_zero',a,b)
    a=dict(old);b=dict(new);a[0,0]=(1,1,167);b[0,0]=(1,1,172)
    reject('additional_incoming_edge',a,b)
    b=dict(new);b[predecessor,1]=(1,-1,172)
    reject('wrong_redirection_move',old,b)
    return records

def main():
    need(__debug__ and not sys.flags.optimize,'run without Python optimization')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('old',type=Path);p.add_argument('new',type=Path)
    p.add_argument('--output',type=Path);a=p.parse_args()
    old=read(a.old);new=read(a.new);result=check(old,new)
    result['mutation_controls']=mutation_controls(old,new)
    result['old_sha256']=hashlib.sha256(a.old.read_bytes()).hexdigest()
    result['new_sha256']=hashlib.sha256(a.new.read_bytes()).hexdigest()
    result['checker_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    raw=json.dumps(result,indent=2)+'\n'
    if a.output:a.output.write_text(raw)
    print(json.dumps({'status':result['status'],'cases':len(result['cases']),
        'negative_controls':len(result['mutation_controls']),
        'new_sha256':result['new_sha256']},indent=2))

if __name__=='__main__':main()
