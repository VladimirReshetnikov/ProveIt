#!/usr/bin/env python3
"""Audit or rederive the complete U213 whole-tape runtime certificate.

The inherited engine uses literal transitions, induction over unary run
lengths and induction over arbitrary finite spare lists. No numeric register
bound is imposed. This remains a mathematical checker, not a proof kernel.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import sys
import time

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent / 'runtime'))
import symbolic_runtime as sy
import independent_runtime as ir


def need(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def normalized(value):
    return json.loads(json.dumps(value))


def load(root):
    root = Path(root)
    table_path = root / 'machine/u213.native.tm'
    source_path = root / 'machine/sites.json'
    native = ir.table(table_path)
    source = json.loads(source_path.read_text())
    mapping = {int(k): int(v) for k, v in json.loads((root / 'inputs/legacy_mapping.json').read_text()).items()}
    states = {q for q, bit in native} | {254}
    for q in states:
        if q not in mapping:
            mapping[q] = q + 1000
    need(len({mapping[q] for q in states}) == len(states), 'Noninjective runtime relabeling')
    need(mapping[84] == 96 and mapping[254] == 254, 'Runtime interface labels differ')
    mapped = {(mapping[q], bit): (w, d, mapping[z]) for (q, bit), (w, d, z) in native.items()}
    need(len(native) == 426 and len({q for q, bit in native}) == 213, 'Runtime table census')
    need(len(source) == 3928, 'Runtime source census')
    report = json.loads((root / 'evidence/runtime.json').read_text())
    with gzip.open(root / 'evidence/runtime_cases.json.gz', 'rt') as f:
        cases = json.load(f)
    return mapped, source, report, cases


def audit(root):
    root = Path(root)
    table, source, report, cases = load(root)
    need(report['status'] == 'UNIVERSAL_MATHEMATICAL_PASS' and not report['failures'], 'Saved runtime did not pass')
    need(report['table_sha256'] == digest(root / 'machine/u213.native.tm') and
         report['sites_sha256'] == digest(root / 'machine/sites.json'), 'Saved runtime input hashes differ')
    need(report['checker_sha256'] == digest(Path(sy.__file__)) and
         report['helper_sha256'] == digest(Path(ir.__file__)), 'Saved proof engine hashes differ')
    expected = [(i, positive) for i, site in enumerate(source)
                for positive in ((False, True) if site[1] == 'CD' else (False,))]
    need([(c['site_index'], c['positive']) for c in cases] == expected, 'Missing, repeated or reordered guarded case')
    need(len(cases) == report['expected_cases'] == report['proved_cases'] == 5109, 'Guarded-case census')
    need(report['working_states'] == 213 and report['site_count'] == 3928, 'Saved counts differ')
    need(report['startup_status'] == 'CALIBRATED_DIRTY_ROOT_SEED', 'Saved startup status')
    rows = set()
    for c in cases:
        need(len(c['duration']) == len(c['motion']) == 13, 'Affine dimension differs')
        need(c['duration'][0] > 0 and all(x >= 0 for x in c['duration']), 'Nonpositive symbolic duration')
        need(sum(c['kinds'].values()) == c['symbolic_steps'], 'Inference census differs')
        need(set(c['kinds']) <= {'literal', 'unary', 'list'}, 'Unknown inference kind')
        rows.update(tuple(row) for row in c['rows'])
    need(rows == set(table), 'Saved cases do not cover exactly the 426 literal rows')
    _, blocks = sy.prove_blocks(table)
    need(normalized(blocks) == report['blocks'], 'Fresh one-block induction derivations differ')
    return {'status': 'SAVED_RUNTIME_COVERAGE_AUDIT_PASS', 'guarded_cases': len(cases),
            'literal_rows_covered': len(rows), 'working_states': 213,
            'symbolic_rules': sum(c['symbolic_steps'] for c in cases),
            'minimum_duration_constant': min(c['duration'][0] for c in cases),
            'four_list_block_schemas_freshly_reproved': True,
            'runtime_cases_rederived': 0,
            'scope': 'Complete saved-case coverage and hash audit; use --full to rederive every case.'}


def full(root, output):
    root, output = Path(root), Path(output)
    audit(root)
    table, source, report, saved = load(root)
    lemmas, blocks = sy.prove_blocks(table)
    need(normalized(blocks) == report['blocks'], 'Block derivations changed')
    begun = time.monotonic()
    fresh = []
    for i, site in enumerate(source):
        for positive in ((False, True) if site[1] == 'CD' else (False,)):
            result = sy.case(table, lemmas, site, positive)
            result['rows'] = sorted(result['rows'])
            result.pop('trace')
            record = normalized({'site_index': i, 'positive': positive, **result})
            need(record == saved[len(fresh)], f'Fresh symbolic derivation differs at site {i}, positive={positive}')
            fresh.append(record)
        if (i + 1) % 1000 == 0:
            print(f'Runtime: {len(fresh)}/5109 cases; {time.monotonic() - begun:.1f} s', flush=True)
    need(len(fresh) == 5109, 'Fresh case census')
    output.mkdir(parents=True, exist_ok=True)
    with gzip.open(output / 'runtime_cases.json.gz', 'wt') as f:
        json.dump(fresh, f, separators=(',', ':'))
    result = {'status': 'FRESH_UNIVERSAL_RUNTIME_PASS', 'guarded_cases': len(fresh),
              'every_case_equals_saved': True, 'literal_rows_covered': len(table),
              'table_sha256': digest(root / 'machine/u213.native.tm'),
              'source_sha256': digest(root / 'machine/sites.json'),
              'symbolic_rules': sum(c['symbolic_steps'] for c in fresh),
              'minimum_duration_constant': min(c['duration'][0] for c in fresh),
              'seconds': round(time.monotonic() - begun, 6),
              'scope': 'All natural primary values under each guard, arbitrary natural gap, nonempty arbitrary finite spare list, and the complete zero exterior. Not proof-assistant kernel checked.'}
    (output / 'runtime_fresh.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    need(__debug__ and not sys.flags.optimize, 'Run without Python optimization')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    p.add_argument('--full', action='store_true')
    p.add_argument('--output', type=Path)
    a = p.parse_args()
    need(not a.full or a.output is not None, '--full requires --output')
    print(json.dumps(full(a.root, a.output) if a.full else audit(a.root), indent=2))
