#!/usr/bin/env python3
"""Independent literal audit of the repaired 213-state machine.

Checks its census, the preceding-zero 182 interface, and two independent
blank-tape executions against a freshly constructed complete root frame.
No project runtime, allocator, source builder, or saved startup receipt is
imported. The unbounded primitive runtime proof is a separate obligation.
"""
import argparse
import hashlib
import json
from pathlib import Path

def need(ok,why):
    if not ok:raise ValueError(why)

def digest(data):return hashlib.sha256(data).hexdigest()

def parse(path):
    raw=path.read_bytes();table={};starts=[]
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):starts.append(line);continue
        if not line.strip()or line.startswith('#'):continue
        fields=line.split();need(len(fields)==5,'bad transition arity')
        q,b,w,z=map(int,(fields[0],fields[1],fields[2],fields[4]));d=fields[3]
        need(q>=0 and z>=0 and b in(0,1)and w in(0,1)and d in('L','R'),'bad transition')
        need((q,b)not in table,'duplicate transition')
        table[q,b]=(w,1 if d=='R'else-1,z)
    need(starts==['#! start 0'],'wrong start convention')
    states={q for q,b in table}
    need(len(states)==213 and len(table)==426,'wrong 213-state census')
    need(set(table)=={(q,b)for q in states for b in(0,1)},'missing binary row')
    need(0 in states and 254 not in states,'start or halt is wrong')
    need({z for w,d,z in table.values()}-states=={254},'bad target closure')
    reached={0};todo=[0]
    while todo:
        q=todo.pop()
        for b in(0,1):
            z=table[q,b][2]
            if z in states and z not in reached:reached.add(z);todo.append(z)
    return raw,table,states,reached

def local_interface(table):
    need(table[204,0]==(0,1,182),'the repaired edge is absent')
    cases=[]
    for scanned in(0,1):
        before={-1:0,0:scanned};cells=dict(before);q=182;head=0;trace=[]
        steps=5 if scanned==0 else 1
        for _ in range(steps):
            need(head in cells,'repair reads unconstrained exterior')
            need(q!=254,'repair hides an internal halt')
            b=cells[head];w,d,z=table[q,b]
            trace.append([q,head,b,w,d,z]);cells[head]=w;head+=d;q=z
        expected=90 if scanned==0 else 61
        need((q,head,cells)==(expected,1,before),'repair fails the virtual-node contract')
        cases.append({'scanned':scanned,'steps':steps,'trace':trace,
                      'endpoint_state':q,'endpoint_head':head,
                      'whole_tape_preserved':True,'unbounded_exterior_untouched':True})
    return {'guard':'cell immediately preceding the head is zero',
      'virtual_rows':{'0':[0,'R',90],'1':[1,'R',61]},
      'guard_established_by':[204,0,0,'R',182],
      'cases':cases,
      'scope':'Exact two-cell interface theorem for arbitrary exterior tape; the failed unrepaired 150 route is not claimed equivalent.'}

def trace_line(q,h,b,w,d,z):return json.dumps([q,h,b,w,d,z],separators=(',',':')).encode()+b'\n'

def sparse_run(table,steps):
    q=head=0;ones=set();trace=hashlib.sha256();covered=set();minimum=maximum=0
    for _ in range(steps):
        b=int(head in ones);need((q,b)in table,'premature halt in sparse replay')
        w,d,z=table[q,b];covered.add((q,b));trace.update(trace_line(q,head,b,w,d,z))
        if w:ones.add(head)
        else:ones.discard(head)
        q=z;head+=d;minimum=min(minimum,head);maximum=max(maximum,head)
    return (q,head,ones),trace.hexdigest(),covered,(minimum,maximum)

def array_run(table,steps):
    """Different tape representation and transition loop; grows both rays."""
    positive=bytearray([0]);negative=bytearray();state=position=0
    rows={q:[table[q,0],table[q,1]]for q,b in table}
    trace=hashlib.sha256()
    for _ in range(steps):
        ray=positive if position>=0 else negative
        index=position if position>=0 else-1-position
        if index>=len(ray):ray.extend(bytes(index+1-len(ray)))
        read=ray[index];need(state in rows,'premature halt in array replay')
        write,move,target=rows[state][read]
        trace.update(trace_line(state,position,read,write,move,target))
        ray[index]=write;position=position+move;state=target
    support={i for i,b in enumerate(positive)if b}
    support.update(-1-i for i,b in enumerate(negative)if b)
    return(state,position,support),trace.hexdigest()

def root_frame():
    head=-8;gap=1;header=head+64+gap
    logical=[4,0,0,0,0,0,0,0,0]
    physical=[0]*9
    for i,j in enumerate((6,2,0,4,3,7,8,5,1)):physical[j]=logical[i]
    ones={head-1,header};position=header+1
    for value in physical+[1]*40:
        ones.update(range(position+1,position+value+2));position+=value+2
    need(header==57 and len(ones)==95,'internal root-frame construction error')
    return(84,head,ones),{'head':head,'header':header,'gap':gap,
      'PC':'zero root pointer','registers':logical,'physical_registers':physical,
      'spares':[1]*40,'one_cells':sorted(ones),'complete_zero_exterior':True}

def audit(table_path,source_path,steps):
    raw,table,states,reached=parse(table_path)
    repair=local_interface(table)
    a,ah,covered,extent=sparse_run(table,steps);b,bh=array_run(table,steps)
    expected,frame=root_frame()
    need(a==b and ah==bh,'independent blank executions disagree')
    need(a==expected,'complete blank endpoint differs from the calibrated frame')
    source=source_path.read_bytes();sites=json.loads(source)
    need(len(sites)==3928,'unexpected source size')
    need(sum(2 if op=='CD'else 1 for p,op,r in sites)==5109,'unexpected source guard census')
    return {'status':'INDEPENDENT_U213_REPAIR_AND_BLANK_FRAME_PASS',
      'table_sha256':digest(raw),'source_sha256':digest(source),
      'checker_sha256':digest(Path(__file__).read_bytes()),
      'working_states':len(states),'transition_rows':len(table),
      'graph_reachable_working_states':len(reached),'start':0,'halt':254,
      'preceding_zero_interface':repair,'startup_steps':steps,
      'startup_state':a[0],'startup_frame':frame,
      'trace_sha256':ah,'trace_format':'One compact JSON [state,head,read,write,move,target] array plus newline per transition',
      'independent_tape_representations':['finite set of one-cells','two dynamically growing byte arrays'],
      'both_complete_endpoints_and_full_trace_digests_agree':True,
      'startup_transition_rows_used':len(covered),'startup_head_extent':list(extent),
      'scope':'Finite literal startup and two-cell repair theorem; no sampled substitute for arbitrary-natural primitive runtime.'}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('table',type=Path);p.add_argument('source',type=Path)
    p.add_argument('--steps',type=int,default=95752);p.add_argument('--report',type=Path)
    args=p.parse_args();result=audit(args.table,args.source,args.steps)
    if args.report:args.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
