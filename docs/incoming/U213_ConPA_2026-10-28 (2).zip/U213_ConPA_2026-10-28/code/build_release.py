#!/usr/bin/env python3
"""Solver-free source/table construction for U213. Runtime is checked separately."""
from pathlib import Path
import argparse, hashlib, json, sys
sys.dont_write_bytecode = True
import inherited_build_source as source_builder


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def parse_table(raw):
    table, starts = {}, []
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(int(line[9:]))
        elif line and not line.startswith('#'):
            q, read, write, direction, target = line.split()
            q, read, write, target = map(int, (q, read, write, target))
            need((q, read) not in table and read in (0, 1) and write in (0, 1)
                 and direction in ('L', 'R'), 'Invalid table row')
            table[q, read] = write, 1 if direction == 'R' else -1, target
    need(starts == [0], 'Start is not zero')
    return table


def table_bytes(table):
    return ('#! start 0\n' + ''.join(
        f'{q} {read} {write} {"R" if direction == 1 else "L"} {target}\n'
        for (q, read), (write, direction, target) in sorted(table.items()))).encode('ascii')


def validate_table(table, count, halt=254):
    states = {q for q, _ in table}
    need(len(states) == count and set(table) == {(q, b) for q in states for b in (0, 1)},
         'Working-state/row census')
    need(0 in states and halt not in states and
         {z for _, _, z in table.values()} - states == {halt}, 'Start/halt/target closure')
    reached, pending = {0}, [0]
    for q in pending:
        for bit in (0, 1):
            target = table[q, bit][2]
            if target != halt and target not in reached:
                reached.add(target)
                pending.append(target)
    need(reached == states, 'Unreachable working state in graph census')
    return states


def apply_rows(table, records):
    keys = set()
    for record in records:
        key = record['state'], record['read']
        need(key not in keys and table[key] == tuple(record['before']), 'Patch precondition')
        keys.add(key)
        after = tuple(record['after'])
        need(after[0] in (0, 1) and after[1] in (-1, 1), 'Patch action')
        table[key] = after

def build(root, output):
    root, output = Path(root), Path(output)
    sr = json.loads((root / 'inputs/source_recipe.json').read_text())
    tr = json.loads((root / 'inputs/table_recipe.json').read_text())
    source = source_builder.build(root / 'inputs/k215_sites.json', sr)
    need(sha(source) == tr['source_sha256'], 'Source/table recipe binding')
    old_bytes = (root / 'inputs/u214.native.tm').read_bytes()
    need(sha(old_bytes) == tr['baseline_sha256'], 'Primary U214 table digest')
    parent = parse_table(old_bytes)
    validate_table(parent, 214)
    need(len(tr['changed_rows']) == tr['changed_row_count'] == 70, 'Compilation patch census')
    apply_rows(parent, tr['changed_rows'])
    validate_table(parent, 214)
    parent_bytes = table_bytes(parent)
    need(sha(parent_bytes) == tr['intermediate_sha256'], 'Repaired parent digest')
    final = dict(parent)
    apply_rows(final, tr['fold_changed_rows'])
    need(tr['removed_states'] == [167], 'Removed-state identity')
    need(len(tr['removed_rows']) == 2, 'Removed-row census')
    for q, bit, write, direction, target in tr['removed_rows']:
        need(q == 167 and final[q, bit] == (write, direction, target), 'Removed-row precondition')
        del final[q, bit]
    states = validate_table(final, 213)
    native = table_bytes(final)
    need(sha(native) == tr['final_native_sha256'], 'Final native digest')
    rename = {q: i for i, q in enumerate(sorted(states))}
    rename[254] = 213
    dense = {(rename[q], bit): (write, direction, rename[target])
             for (q, bit), (write, direction, target) in final.items()}
    validate_table(dense, 213, 213)
    inverse = {v: k for k, v in rename.items()}
    need({(inverse[q], bit): (w, d, inverse[z])
          for (q, bit), (w, d, z) in dense.items()} == final, 'Relabeling inverse')
    dense_bytes = table_bytes(dense)
    mapping = {'native_to_dense': rename, 'dense_to_native': inverse,
               'native_start': 0, 'dense_start': 0, 'native_halt': 254, 'dense_halt': 213}
    result = {
        'status': 'EXACT_U213_CONSTRUCTION_PASS', 'working_states': 213,
        'transitions': 426, 'symbols': [0, 1], 'moves': ['L', 'R'],
        'blank_symbol': 0, 'native_start': 0, 'native_halt': 254,
        'dense_start': 0, 'dense_halt': 213, 'dense_dispatcher': rename[84],
        'source_metrics': sr['expected_metrics'], 'parent_changed_rows': 70,
        'fold_changed_rows': len(tr['fold_changed_rows']), 'removed_native_states': [167],
        'source_sha256': sha(source), 'parent_native_sha256': sha(parent_bytes),
        'native_sha256': sha(native), 'dense_sha256': sha(dense_bytes),
        'all_working_states_graph_reachable': True, 'dense_relabeling_bijective': True,
        'scope': 'Exact finite construction. Source semantics, local proofs, whole-tape runtime and blank initialization are checked separately.'}
    output.mkdir(parents=True, exist_ok=True)
    for name, data in [('sites.json', source), ('u213.native.tm', native),
                       ('u213.tm', dense_bytes), ('parent214.native.tm', parent_bytes)]:
        (output / name).write_bytes(data)
    (output / 'state_map.json').write_text(json.dumps(mapping, indent=2) + '\n')
    (output / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    print(json.dumps(build(a.root, a.output), indent=2))
