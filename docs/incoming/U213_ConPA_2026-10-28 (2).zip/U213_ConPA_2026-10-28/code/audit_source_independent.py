#!/usr/bin/env python3
"""Independent exact source audit for the reassociated U214 emitter.

Standard library only. No builder, allocator, source-language module or
physical-runtime verifier is imported. Two complete CFG computations and
literal macro bindings establish finite source premises. Without the
--lower-exchange option this proves an ordinal-preserving bisimulation;
with that option it binds the equivalent exchanged-antecedent emitter.
The logical exchange proof is separate. This does not verify a binary TM.
"""
import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

U214_SHA='9428a13d4c228e9760e8f546e43527ee5e196ae667ad2386ddabf961b477d083'
K215_SHA='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
MACROS={'a':(26,52),'b':(52,78),'c':(107,133),
        'I':(78,105),'R':(695,723),'Q':(78,107),'N':(995,1042)}
TOKENS='a c c a R a I Q c a a a c R a b R I Q c a R I I Q N I Q'.split()
EXCHANGE_TOKENS='a c c a R a I Q c a a c R a b R I Q a c a R I I Q N I Q'.split()

def require(ok,why):
    if not ok:raise ValueError(why)

def digest(data):return hashlib.sha256(data).hexdigest()

def load(path):
    raw=path.read_bytes();rows=json.loads(raw)
    names=[r[0]for r in rows]
    require(names==sorted(names)and len(set(names))==len(names),'noncanonical leaf order')
    trie={}
    for i,row in enumerate(rows):
        require(type(row)is list and len(row)==3,'bad source row')
        p,op,r=row
        require(type(p)is str and p and set(p)<={'0','1'},'bad source address')
        require(op in('CI','CD','CB','CC','CH'),'unknown opcode')
        require((op=='CH'and r is None)or(op!='CH'and type(r)is int and r>=0),'bad operand')
        require(op not in('CI','CD')or r<9,'bad register')
        require(op not in('CB','CC')or r>0,'bad control depth')
        q=trie
        for bit in p:
            require('leaf'not in q,'leaf has descendant')
            q=q.setdefault(bit,{})
        require(not q,'duplicate leaf or leaf with children')
        q['leaf']=i
    cuts={};nodes=set()
    def walk(q,p=''):
        if 'leaf'in q:
            require(set(q)=={'leaf'},'malformed leaf')
            i=q['leaf'];cuts[p]=(i,i+1);n=tuple(rows[i][1:])
        else:
            require(set(q)=={'0','1'},'incomplete binary prefix tree')
            left=walk(q['0'],p+'0');right=walk(q['1'],p+'1')
            require(cuts[p+'0'][1]==cuts[p+'1'][0],'noncontiguous source interval')
            cuts[p]=(cuts[p+'0'][0],cuts[p+'1'][1]);n=(left,right)
        nodes.add(n);return n
    walk(trie)
    require(cuts['']==(0,len(rows)),'wrong root interval')
    return raw,rows,cuts,{'distinct_subtrees':len(nodes),'primitives':len(rows),
      'maximum_address_length':max(map(len,names)),
      'maximum_zero_run':max(len(z)for p in names for z in p.split('1'))}

def interval_graph(rows,cuts):
    def jump(p,bit,n):
        for j in range(len(p)-1,-1,-1):
            if p[j]==bit:
                n-=1
                if n==0:return cuts[p[:j]][1 if bit=='0'else 0]%len(rows)
        return 0
    graph=[]
    for i,(p,op,r)in enumerate(rows):
        next_i=(i+1)%len(rows)
        if op=='CI':targets=[next_i]
        elif op=='CD':targets=[jump(p,'0',1),next_i]
        elif op=='CB':targets=[jump(p,'0',r)]
        elif op=='CC':targets=[jump(p,'1',r)]
        else:targets=[]
        graph.append([op,r if op in('CI','CD')else None,targets])
    return graph

def arithmetic_graph(rows):
    lookup={p:i for i,(p,op,r)in enumerate(rows)}
    width=max(map(len,lookup))+1
    def at(p):
        padded=p+'0'*width
        for j in range(1,len(padded)+1):
            if padded[:j]in lookup:
                require('1'not in p[j:],'nonzero discarded address suffix')
                return lookup[padded[:j]]
        raise ValueError('computed address misses every leaf')
    def inc(p):return format((int(p,2)+1)%2**len(p),'0'+str(len(p))+'b')if p else''
    def trim(p,bit,n):
        occurrences=[j for j,b in enumerate(p)if b==bit]
        return p[:occurrences[-n]]if len(occurrences)>=n else''
    graph=[]
    for p,op,r in rows:
        if op=='CI':targets=[at(inc(p))]
        elif op=='CD':targets=[at(inc(trim(p,'0',1))),at(inc(p))]
        elif op=='CB':targets=[at(inc(trim(p,'0',r)))]
        elif op=='CC':targets=[at(trim(p,'1',r))]
        else:targets=[]
        graph.append([op,r if op in('CI','CD')else None,targets])
    return graph

def graph(rows,cuts):
    a=interval_graph(rows,cuts);b=arithmetic_graph(rows)
    require(a==b,'independent CFG resolvers disagree')
    return a

def audit(old_path,new_path,k_path,lower_exchange=False):
    oldraw,old,ocuts,om=load(old_path)
    newraw,new,ncuts,nm=load(new_path)
    kraw,k,kcuts,km=load(k_path)
    require(digest(oldraw)==U214_SHA,'unexpected original U214 source bytes')
    require(digest(kraw)==K215_SHA,'unexpected pinned K215 macro source bytes')
    og=graph(old,ocuts);ng=graph(new,ncuts);kg=graph(k,kcuts)
    word=lambda rows:[r[1:]for r in rows]
    if not lower_exchange:
        require(word(old)==word(new),'primitive opcode/operand word changed')
        require(og==ng,'a guarded primitive successor changed')
    require(om['primitives']==3928 and om['distinct_subtrees']==198,'unexpected original census')
    require(nm['primitives']==3928 and nm['distinct_subtrees']==198,'unexpected reassociated census')
    changed=[i for i,(a,b)in enumerate(zip(old,new))if a[0]!=b[0]]
    require(changed==list(range(2885,3659)),'changed address support is not exactly the emitter')
    exterior=list(range(2885))+list(range(3659,len(old)))
    require(all(old[i]==new[i]for i in exterior),'an exterior primitive address changed')
    require(all(og[i]==ng[i]for i in exterior),'an exterior guarded edge changed')
    require(all(not 2885<j<3659 for i in exterior for j in ng[i][2]),
            'retained edge enters the strict emitter interior')
    bindings=[];pos=2885;stack=[]
    tokens=EXCHANGE_TOKENS if lower_exchange else TOKENS
    for token in tokens:
        a,b=MACROS[token];end=pos+b-a
        require(word(new[pos:end])==word(k[a:b]),'literal constructor macro mismatch')
        for i in range(a,b):
            op,r,targets=kg[i]
            require(all(a<=j<=b for j in targets),'macro has nonlocal control edge')
            require(ng[pos+i-a]==[op,r,[pos+j-a for j in targets]],'macro control edge mismatch')
        bindings.append({'macro':token,'K215_interval':[a,b],'new_interval':[pos,end]})
        pos=end
        if token in('a','b','c'):stack.append(token)
        elif token=='N':
            require(len(stack)>=1,'postfix underflow');stack.append(['N',stack.pop()])
        else:
            require(len(stack)>=2,'postfix underflow');v=stack.pop();u=stack.pop();stack.append([token,u,v])
    require(pos==3659 and len(stack)==1,'wrong emitter extent or postfix stack depth')
    I=lambda a,b:['I',a,b];Q=lambda a,b:['Q',a,b];R=lambda a,b:['R',a,b];N=lambda a:['N',a]
    E=R('c','a');G=Q('a',I(R('a','c'),R('a','b')))
    lower=I(G,I('a',E))if lower_exchange else I('a',I(G,E))
    H=Q('a',I(Q('c',I(E,'a')),N(Q('c',lower))))
    require(stack[0]==H,'wrong logical emitter expression')
    guarded=sum(max(1,len(row[2]))for row in ng)
    require(guarded==5109,'wrong complete guarded census')
    return {'status':'INDEPENDENT_U214_LOWER_EXCHANGE_BINDING_PASS'if lower_exchange else'INDEPENDENT_U214_REASSOCIATION_PASS',
      'scope':('Exact exterior CFG and exchanged-emitter macro binding; uniform logical exchange proof, physical runtime and startup are separate obligations'if lower_exchange else'All-natural source bisimulation finite premises and exact emitter macro binding; physical table/startup are separate obligations'),
      'original_source_sha256':digest(oldraw),'new_source_sha256':digest(newraw),
      'pinned_K215_source_sha256':digest(kraw),'original_metrics':om,'new_metrics':nm,
      'primitive_word_identical':word(old)==word(new),'all_guarded_control_edges_identical':og==ng,
      'changed_primitive_positions':sum(a[1:]!=b[1:]for a,b in zip(old,new)),
      'changed_guarded_instruction_records':sum(a!=b for a,b in zip(og,ng)),
      'guarded_cases':guarded,'emitter_interval':[2885,3659],
      'changed_addresses':len(changed),'literal_exterior_primitives':len(exterior),
      'exterior_guarded_cases':sum(max(1,len(ng[i][2]))for i in exterior),
      'macro_occurrences':len(tokens),'macro_counts':dict(Counter(tokens)),
      'lower_antecedent_exchange':lower_exchange,
      'postfix_tokens':tokens,'formula_AST':H,'macro_bindings':bindings,
      'guarded_graph_sha256':digest(json.dumps(ng,separators=(',',':')).encode()),
      'semantic_consequence':('Only L changes from Q_c(a -> (G -> E)) to Q_c(G -> (a -> E)); unchanged native core interderives both bundles uniformly.'if lower_exchange else'Equal natural registers at the same ordinal are preserved step for step, including halt, without a numeric input bound.')}

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('original_source',type=Path);ap.add_argument('new_source',type=Path)
    ap.add_argument('k215_source',type=Path);ap.add_argument('--report',type=Path)
    ap.add_argument('--lower-exchange',action='store_true',help='Bind the logically equivalent exchanged lower clause rather than identical primitive word.')
    a=ap.parse_args();result=audit(a.original_source,a.new_source,a.k215_source,a.lower_exchange)
    if a.report:a.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
