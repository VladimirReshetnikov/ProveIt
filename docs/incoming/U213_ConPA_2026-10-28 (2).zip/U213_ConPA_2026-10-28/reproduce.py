#!/usr/bin/env python3
"""Offline U213 construction, proof audit and optional full symbolic replay.

Python 3.10+, standard library only. No network, optimizer, solver or proof
assistant executable is needed. --full rederives all 5,109 arbitrary-register
cases. --parent additionally replays the included U214 archive with --full.
"""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import json
import os
import stat
import subprocess
import sys
import tempfile
import time
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'code'))
import build_release as build
import check_runtime_release as runtime
import audit_source_independent as source_audit
import audit_repair_startup as physical_audit
import check_fold213 as fold_primary
import check_fold213_independent as fold_independent


def need(ok, why):
    if not ok:
        raise ValueError(why)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2) + '\n')


def check_manifest():
    path = ROOT / 'SHA256SUMS'
    need(path.is_file(), 'Missing required SHA256SUMS manifest')
    seen = set()
    for line in path.read_text().splitlines():
        expected, name = line.split('  ', 1)
        relative = PurePosixPath(name)
        need(not relative.is_absolute() and '..' not in relative.parts
             and '\\' not in name and name not in seen, 'Unsafe or duplicate manifest member')
        seen.add(name)
        target = ROOT.joinpath(*relative.parts)
        need(target.is_file() and not target.is_symlink(), 'Missing or linked manifest member: ' + name)
        need(digest(target) == expected, 'Manifest digest differs: ' + name)
    required = {'machine/u213.tm', 'machine/u213.native.tm', 'machine/sites.json',
                'machine/state_map.json', 'paper/report.tex', 'paper/report.pdf',
                'reproduce.py', 'code/build_release.py', 'code/check_runtime_release.py',
                'inputs/U214_ConPA_Reduction_2026-10-28.zip'}
    need(required <= seen, 'A principal deliverable is omitted from the manifest')
    return {'status': 'ALL_MANIFEST_HASHES_PASS', 'files': len(seen)}


def safe_extract(archive, destination):
    seen = set()
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            relative = PurePosixPath(item.filename)
            need(not relative.is_absolute() and '..' not in relative.parts and
                 '\\' not in item.filename and item.filename not in seen,
                 'Unsafe or duplicate archive member')
            need(not stat.S_ISLNK((item.external_attr >> 16) & 0xffff), 'Archive symlink')
            seen.add(item.filename)
            target = destination.joinpath(*relative.parts)
            if item.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(item) as src, target.open('wb') as dst:
                    while True:
                        block = src.read(1024 * 1024)
                        if not block:
                            break
                        dst.write(block)


def check_saved_startup(fresh):
    with gzip.open(ROOT / 'evidence/startup.json.gz', 'rt') as f:
        saved = json.load(f)
    need(saved['status'] == 'CALIBRATED_DIRTY_ROOT_SEED', 'Saved startup status')
    need(saved['steps'] == fresh['startup_steps'] == len(saved['trace']) == 95752, 'Startup trace census')
    frame = fresh['startup_frame']
    for key in ('head', 'gap', 'registers', 'spares', 'one_cells'):
        need(saved[key] == frame[key], 'Saved startup endpoint differs: ' + key)
    need(saved['state'] == fresh['startup_state'] == 84, 'Saved startup state differs')
    trace = hashlib.sha256()
    for row in saved['trace']:
        trace.update(json.dumps(row, separators=(',', ':')).encode('ascii') + b'\n')
    need(trace.hexdigest() == fresh['trace_sha256'], 'Saved full blank trace differs from both fresh simulators')
    return {'status': 'SAVED_STARTUP_TRACE_MATCHES_FRESH_EXECUTIONS',
            'steps': saved['steps'], 'one_cells': len(saved['one_cells']),
            'trace_sha256': trace.hexdigest()}


def run(work, full=False, parent=False):
    begun = time.monotonic()
    work = Path(work)
    work.mkdir(parents=True, exist_ok=True)
    manifest = check_manifest()
    archive = ROOT / 'inputs/U214_ConPA_Reduction_2026-10-28.zip'
    need(digest(archive) == 'b3a520e2181b739fec7257a7935b979acb00400f8d8147b5a2c212fd53a38d2c', 'Primary U214 archive digest')
    need(digest(ROOT / 'inputs/pa_unary_power_cover.zip') ==
         '0fcb1117a5353766a3366bab04e56b4efbd0607833cdc73ffb34b67e6808b0ff', 'Theory U archive digest')
    print('Reconstruct source, repaired parent, native and dense U213 ...', flush=True)
    construction = build.build(ROOT, work / 'construction')
    for name in ('sites.json', 'u213.native.tm', 'u213.tm', 'state_map.json', 'summary.json'):
        need((work / 'construction' / name).read_bytes() == (ROOT / 'machine' / name).read_bytes(),
             'Packaged reconstruction differs: ' + name)
    need((work / 'construction/parent214.native.tm').read_bytes() ==
         (ROOT / 'inputs/recompiled214.native.tm').read_bytes(), 'Repaired parent bytes differ')

    print('Independently audit all source addresses and guarded control edges ...', flush=True)
    source = source_audit.audit(ROOT / 'inputs/u214_sites.json', ROOT / 'machine/sites.json',
                                ROOT / 'inputs/k215_sites.json')
    save(work / 'source_independent.json', source)
    need(source == json.loads((ROOT / 'evidence/source_independent.json').read_text()), 'Source certificate differs')

    print('Replay both local fold proofs and mutation controls ...', flush=True)
    old_path, new_path = ROOT / 'inputs/recompiled214.native.tm', ROOT / 'machine/u213.native.tm'
    old, new = fold_primary.read(old_path), fold_primary.read(new_path)
    local = fold_primary.check(old, new)
    local['mutation_controls'] = fold_primary.mutation_controls(old, new)
    local['old_sha256'], local['new_sha256'] = digest(old_path), digest(new_path)
    local['checker_sha256'] = digest(ROOT / 'code/check_fold213.py')
    save(work / 'fold213_local.json', local)
    exhaustive = fold_independent.verify(old_path, new_path)
    save(work / 'fold213_exhaustive.json', exhaustive)
    need(len(local['mutation_controls']) == 21 and len(exhaustive['negative_controls']) == 12,
         'Mutation-control census')

    print('Independently verify the repaired interface and two complete blank executions ...', flush=True)
    startup = physical_audit.audit(new_path, ROOT / 'machine/sites.json', 95752)
    save(work / 'repair_startup_independent.json', startup)
    saved_startup = check_saved_startup(startup)
    save(work / 'saved_startup_audit.json', saved_startup)

    print('Audit all saved arbitrary-register cases and all literal rows ...', flush=True)
    coverage = runtime.audit(ROOT)
    save(work / 'runtime_coverage.json', coverage)
    fresh = runtime.full(ROOT, work / 'fresh_runtime') if full else None

    parent_result = None
    if parent:
        print('Replaying the complete inherited U214 package with --full ...', flush=True)
        safe_extract(archive, work / 'parent')
        inherited = work / 'parent/U214_ConPA_Reduction_2026-10-28'
        need((inherited / 'machine/u214.native.tm').read_bytes() ==
             (ROOT / 'inputs/u214.native.tm').read_bytes(), 'Parent machine binding')
        need((inherited / 'machine/sites.json').read_bytes() ==
             (ROOT / 'inputs/u214_sites.json').read_bytes(), 'Parent source binding')
        report_path = (work / 'parent_full_replay.json').resolve()
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
        env.pop('PYTHONOPTIMIZE', None)
        with (work / 'parent_full_replay.log').open('w') as log:
            completed = subprocess.run([sys.executable, '-B', str((inherited / 'reproduce.py').resolve()),
                                        '--full', '--report', str(report_path)],
                                       cwd=inherited, env=env, stdout=log, stderr=subprocess.STDOUT)
        need(completed.returncode == 0, 'Inherited full replay failed; see parent_full_replay.log')
        parent_result = json.loads(report_path.read_text())
        need(parent_result['status'] == 'U214_FULL_REPRODUCTION_PASS', 'Inherited full replay status')

    result = {'status': 'U213_FULL_REPRODUCTION_PASS' if full else 'U213_FINITE_REPRODUCTION_PASS',
              'manifest': manifest, 'construction': construction,
              'identical_source_primitive_word': source['primitive_word_identical'],
              'identical_source_guarded_CFG': source['all_guarded_control_edges_identical'],
              'changed_source_addresses': source['changed_addresses'],
              'all_symbolic_cases_covered': coverage['guarded_cases'],
              'all_symbolic_cases_rederived': 5109 if full else 0,
              'literal_rows_covered': coverage['literal_rows_covered'],
              'symbolic_rules': coverage['symbolic_rules'],
              'minimum_duration_constant': coverage['minimum_duration_constant'],
              'local_fold_patterns': len(local['cases']),
              'exhaustive_local_frames': exhaustive['admissible_frames'],
              'negative_controls': len(local['mutation_controls']) + len(exhaustive['negative_controls']),
              'blank_steps': startup['startup_steps'], 'blank_one_cells': len(startup['startup_frame']['one_cells']),
              'two_startup_simulators_and_saved_trace_agree': True,
              'parent_full_replayed': parent_result is not None,
              'fresh_runtime': fresh, 'seconds': round(time.monotonic() - begun, 6),
              'scope': 'Exact finite construction, source bisimulation, local whole-tape proofs and ordinary symbolic mathematical verification. The inherited Theory U/PA calibration is explicit; no newly kernel-checked endpoint is claimed.'}
    save(work / 'reproduction.json', result)
    return result


def main():
    need(__debug__ and not sys.flags.optimize, 'Run without Python optimization')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--full', action='store_true')
    p.add_argument('--parent', action='store_true', help='Additionally rederive the inherited U214 package with --full')
    p.add_argument('--work', type=Path, help='Directory for replay outputs; otherwise a temporary directory is used')
    p.add_argument('--report', type=Path, help='Write the final JSON receipt to this path')
    a = p.parse_args()
    if a.work is not None:
        result = run(a.work.resolve(), a.full, a.parent)
    else:
        with tempfile.TemporaryDirectory(prefix='u213-replay-') as name:
            result = run(Path(name), a.full, a.parent)
    if a.report:
        a.report.parent.mkdir(parents=True, exist_ok=True)
        save(a.report, result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
