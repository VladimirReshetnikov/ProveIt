SUPPLEMENTARY RESEARCH; NOT THE ACCEPTED MACHINE

The accepted table is ../machine/u213.tm (or its native-labeled equivalent).
None of the files in this directory enters its correctness argument or
the main reproduction pipeline.

rejected_unrepaired213.native.tm is the earlier 213-state allocation WITHOUT
the essential native 204/0 -> (0,R,182) repair. It is deliberately retained
as a negative example. It passes the small last-state-fold argument but
fails the full primitive-runtime contract. It must not be substituted for
the accepted table.

unrepaired_counterexample.json records ordinal 3256 (CI 1), all nine logical
registers zero, gap one, and forty unit-valued spare blocks. The rejected
machine returns after 538 transitions with a tape different from the
required postcondition. The literal trace uses inherited legacy labels;
../inputs/legacy_mapping.json supplies the native-to-legacy names. This is
a counterexample to a universal runtime contract, not an assertion that
this frame is reached from the blank tape.

stu197/ contains a smaller source graph based on a K215 direct-transfer
command language and the U214 covering emitter. It is a source-level
research lead. There is no accepted binary machine below 213 states for
that source in this release. Its source reasoning does not replace its
separate literal runtime and initialization obligations.

Further research questions are in Section 9 of the main report (the section
heading is authoritative if later edits change the numbering).
