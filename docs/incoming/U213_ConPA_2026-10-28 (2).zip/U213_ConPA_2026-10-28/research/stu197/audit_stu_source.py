#!/usr/bin/env python3
"""Independent source-splice and partial-AX binding for ST plus U214.

No compiler, source-construction script, or runtime engine is imported.
This checks exact finite premises; the companion semantic note supplies
the unbounded command/compiler/credit argument. It does not verify a TM.
"""
from pathlib import Path
import argparse
import hashlib
import json


def require(ok, why):
    if not ok:
        raise ValueError(why)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def read(p):
    rows = json.loads(p.read_text())
    names = [r[0] for r in rows]
    require(names == sorted(names) and len(set(names)) == len(names), 'noncanonical leaf order')
    for p, op, a in rows:
        require(p and set(p) <= {'0', '1'}, 'bad binary address')
        require(op in {'CI', 'CD', 'CB', 'CC', 'CH'}, 'bad opcode')
        require((op == 'CH' and a is None) or
                (op != 'CH' and type(a) is int and a >= 0), 'bad operand')
        require(op not in {'CI', 'CD'} or a < 9, 'bad register')
        require(op not in {'CB', 'CC'} or a > 0, 'bad control depth')
    return rows


def intervals(rows):
    index = {r[0]: i for i, r in enumerate(rows)}
    cuts = {}
    nodes = set()
    def visit(p):
        if p in index:
            i = index[p]
            require(not any(x.startswith(p) and x != p for x in index), 'leaf has descendant')
            cuts[p] = (i, i + 1)
            t = tuple(rows[i][1:])
        else:
            require(any(x.startswith(p + '0') for x in index) and
                    any(x.startswith(p + '1') for x in index), 'incomplete prefix tree')
            l, r = visit(p + '0'), visit(p + '1')
            require(cuts[p + '0'][1] == cuts[p + '1'][0], 'noncontiguous tree')
            cuts[p] = (cuts[p + '0'][0], cuts[p + '1'][1])
            t = (l, r)
        nodes.add(t)
        return t
    tree = visit('')
    require(cuts[''] == (0, len(rows)), 'wrong root span')
    def jump(p, bit, n):
        for j in range(len(p) - 1, -1, -1):
            if p[j] == bit:
                n -= 1
                if n == 0:
                    return cuts[p[:j]][1 if bit == '0' else 0] % len(rows)
        return 0
    graph = []
    for i, (p, op, a) in enumerate(rows):
        nxt = (i + 1) % len(rows)
        if op == 'CI': targets = [nxt]
        elif op == 'CD': targets = [jump(p, '0', 1), nxt]
        elif op == 'CB': targets = [jump(p, '0', a)]
        elif op == 'CC': targets = [jump(p, '1', a)]
        else: targets = []
        graph.append((op, a if op in {'CI', 'CD'} else None, targets))
    return graph, len(nodes)


def arithmetic(rows):
    lookup = {r[0]: i for i, r in enumerate(rows)}
    depth = max(map(len, lookup))
    def at(p):
        padded = p + '0' * (depth + 1)
        for j in range(1, len(padded) + 1):
            if padded[:j] in lookup:
                require('1' not in p[j:], 'stray one beyond decoded address')
                return lookup[padded[:j]]
        raise ValueError('invalid computed successor')
    def inc(p):
        return format((int(p, 2) + 1) % 2 ** len(p), '0' + str(len(p)) + 'b') if p else ''
    def cut(p, b, k):
        js = [i for i, c in enumerate(p) if c == b]
        return p[:js[-k]] if len(js) >= k else ''
    graph = []
    for p, op, a in rows:
        if op == 'CI': targets = [at(inc(p))]
        elif op == 'CD': targets = [at(inc(cut(p, '0', 1))), at(inc(p))]
        elif op == 'CB': targets = [at(inc(cut(p, '0', a)))]
        elif op == 'CC': targets = [at(cut(p, '1', a))]
        else: targets = []
        graph.append((op, a if op in {'CI', 'CD'} else None, targets))
    return graph


def source_prefix(graph):
    pc, registers = 25, [1, 0, 2, 0, 0, 0, 0, 0, 0]
    trace = []
    for k in range(177):
        op, arg, targets = graph[pc]
        trace.append([pc, list(registers)])
        if op == 'CI':
            registers[arg] += 1
            pc = targets[0]
        elif op == 'CD':
            positive = registers[arg] > 0
            registers[arg] -= positive
            pc = targets[int(positive)]
        else:
            require(op in {'CB', 'CC'}, 'unexpected halt in prefix')
            pc = targets[0]
    require(pc == 58 and registers == [1, 0, 0, 0, 0, 0, 0, 18, 0], 'partial AX endpoint mismatch')
    return {'steps': 177, 'entry_ordinal': 25,
            'entry_registers': [1, 0, 2, 0, 0, 0, 0, 0, 0],
            'ordinal': pc, 'registers': registers,
            'trace_sha256': hashlib.sha256(json.dumps(trace, separators=(',', ':')).encode()).hexdigest()}


def audit(st_path, u_path, new_path):
    st, u, new = map(read, (st_path, u_path, new_path))
    gs, ns = intervals(st); gu, nu = intervals(u); gn, nn = intervals(new)
    require(gs == arithmetic(st) and gu == arithmetic(u) and gn == arithmetic(new), 'independent CFG disagreement')
    require(len(st) == 4732 and ns == 201, 'unexpected ST source')
    require(len(u) == 3928 and nu == 198, 'unexpected U214 source')
    lo, hi, ul, uh = 2884, 4481, 2885, 3659
    delta = uh - ul - (hi - lo)
    require(delta == -823 and len(new) == 3909, 'wrong source size')
    word = lambda r: [x[1:] for x in r]
    require(word(new) == word(st[:lo]) + word(u[ul:uh]) + word(st[hi:]), 'wrong primitive splice')
    def tr(i):
        require(not lo < i < hi, 'retained edge enters removed emitter interior')
        return i if i <= lo else i + delta
    retained, retained_outcomes = 0, 0
    for old in list(range(lo)) + list(range(hi, len(st))):
        new_i = tr(old)
        op, a, targets = gs[old]
        require(gn[new_i] == (op, a, [tr(j) for j in targets]), 'retained guarded edge changed')
        retained += 1; retained_outcomes += max(1, len(targets))
    for k in range(uh - ul):
        op, a, targets = gu[ul + k]
        require(all(ul <= j <= uh for j in targets), 'nonclosed U214 emitter')
        require(gn[lo + k] == (op, a, [j - 1 for j in targets]), 'emitter guarded edge changed')
    require(new[3873][1:] == ['CC', 3] and gn[3873][2] == [0], 'ordinary return is not scheduler root')
    require(new[3874][1:] == ['CD', 1] and gn[3874][2] == [3876, 3875], 'clear-top context mismatch')
    require(new[3894][1:] == ['CH', None], 'halt guard mismatch')
    prefix = source_prefix(gn)
    return {'status': 'INDEPENDENT_ST_U214_SOURCE_SPLICE_PASS',
            'input_sha256': {'ST_source': sha(st_path), 'U214_source': sha(u_path), 'new_source': sha(new_path)},
            'source_nodes': nn, 'source_primitives': len(new),
            'guarded_cases': sum(max(1, len(r[2])) for r in gn),
            'retained_primitives': retained, 'retained_guarded_outcomes': retained_outcomes,
            'old_emitter_interval': [lo, hi], 'new_emitter_interval': [lo, lo + uh - ul],
            'U214_emitter_interval': [ul, uh], 'ordinal_delta_after_emitter': delta,
            'emitter_primitives': uh - ul,
            'partial_AXIOM_prefix': prefix,
            'partial_AXIOM_checkpoint_address': new[58][0],
            'direct_transfer_entry': 3874, 'halt_ordinal': 3894,
            'scope': 'Exact source, whole guarded CFG and finite partial-AX binding only; generic command semantics, protected-tail proof, and literal machine runtime are separate obligations.'}


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('st_source', type=Path); p.add_argument('u214_source', type=Path)
    p.add_argument('new_source', type=Path); p.add_argument('--report', type=Path)
    a = p.parse_args(); result = audit(a.st_source, a.u214_source, a.new_source)
    if a.report:
        a.report.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
