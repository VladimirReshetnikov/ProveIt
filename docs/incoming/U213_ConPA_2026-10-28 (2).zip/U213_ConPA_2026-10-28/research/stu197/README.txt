STU197: source-only research supplement
=====================================

STATUS
------
This directory preserves a further source-level lead: the ST215 direct
transfer command language with the exact U214 covering emitter substituted
for its old Theory K emitter. The resulting source has 197 distinct
subtrees, 3,909 primitive occurrences, and 5,084 guarded primitive outcomes.

The number 197 counts source subtrees. It is not a Turing-machine state
count. No literal machine compiled from this source is accepted here, and
this supplement establishes no machine smaller than the package's accepted
213-state U213. The primary result, its transition table, and its replay
harness are independent of this research supplement.

CONTENTS
--------
  sites.json                 Exact 197-subtree source.
  st215_sites.json            Exact ST215 parent source, supplied locally.
  audit_stu_source.py         Independent, portable finite source checker.
  source_audit.json           Checked receipt for these exact inputs.
  input_provenance.json       Input locations, SHA-256 pins, and ST Git blob.
  semantics.tex              Mathematical command/compilation argument and
                             the remaining literal-machine obligations.

The U214 parent source is already included elsewhere in this same package:
  ../../inputs/u214_sites.json
No network access or additional download is required.

REPLAY THE SOURCE AUDIT
----------------------
Python 3.10 or later and its standard library are sufficient. From this
directory run:

  python3 -B audit_stu_source.py st215_sites.json ../../inputs/u214_sites.json sites.json

To write a new receipt instead of only printing it:

  python3 -B audit_stu_source.py st215_sites.json ../../inputs/u214_sites.json sites.json --report replay.json

The expected status is INDEPENDENT_ST_U214_SOURCE_SPLICE_PASS. The checker
takes explicit file paths and contains no absolute workspace paths. It
imports no compiler, source-construction program, or runtime engine.

EXACT SCOPE OF THE AUDIT
-----------------------
Two independently implemented successor calculations must agree for every
instruction in each of the three source trees. The checker then verifies
the precise closed-emitter splice and every retained guarded control edge:

  ST parent emitter:       [2884,4481)
  U214 replacement:        [2885,3659), containing 774 primitives
  Result emitter:         [2884,3658)
  Shift of later ordinals: -823

It checks all 3,135 retained exterior primitives and their 4,080 guarded
outcomes. It also replays the stated 177-step source prefix from ordinal
25 to the partial AX checkpoint at ordinal 58. This is a source-register
calculation; it is not a blank-tape initialization of a literal TM.

The receipt must contain these SHA-256 values:

  ST source:
    212cf0ffde43c1cc22c183dd8bf0b3a699396f96c9942ee92a7cc372cd273ca9
  U214 source:
    9428a13d4c228e9760e8f546e43527ee5e196ae667ad2386ddabf961b477d083
  STU197 source:
    7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00

The ST parent is the ordinary direct-transfer variant. Its successful
modus-ponens command remains the ordinary ST command, not the separate
cache-return modus-ponens proposal. The repository path and exact Git blob
identifier for the parent are recorded in input_provenance.json.

WHAT REMAINS TO BE PROVED FOR A NEW MACHINE
-----------------------------------------
The mathematical note supplies command equations, a proof-compilation
argument, cofinal enumeration, and the protected-tail argument required by
the proposed initialization. These semantic arguments are distinct from
the finite source audit and are not newly kernel-checked proof-assistant
certificates.

A physical allocation must implement every one of the 5,084 guarded
primitive outcomes on complete tape frames, with the required arbitrary
natural register values and permitted spare tails. Its literal blank
startup must also reach the exact frame required by the partial-AX and
protected-tail argument. State counts or a decoder-prefix check alone do
not discharge these obligations. The Con(PA) endpoint in semantics.tex is
conditional on those separate literal runtime and initialization proofs.

The accepted U213 in the main package uses its own verified source and
complete literal-machine evidence. Nothing in this source-only supplement
is substituted for any part of that accepted endpoint.
