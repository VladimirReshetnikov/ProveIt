# K223: a binary machine for Con(ZFC)

This packet constructs a deterministic, one-tape, two-symbol Turing machine
with **223 working states**, starting on the all-zero tape. It improves the
pinned 224-state construction by one state.

The result is an ordinary mathematical proof, formalizable in ZFC, of

\[
\mathrm{ZFC}\vdash
\operatorname{Nonhalt}(M_{223},\mathrm{blank})
\longleftrightarrow\operatorname{Con}(\mathrm{ZFC}).
\]

The exact candidate, its source, positive simulation certificates, and
reproduction programs are included. **This packet does not claim a new
Rocq or Lean endpoint for the 223-state table.** The pinned K230 formal
development and the intervening K224 mathematical adapters remain explicit
dependencies. The result is an equivalence, not a proof of Con(ZFC).

## Start here

- [Report and complete transition table](report/main.pdf) — 19 pages.
- [TeX source](report/main.tex), with `theory.tex`, `folds.tex`,
  `exploration.tex`, and the generated `transition_table.tex` beside it.
- [Canonical machine](portable/results/candidate223.tm).
- [Offline reproduction driver](portable/reproduce.py).
- [Further equality frontends](research/equality_frontends/README.md).
- [Provenance and proof boundary](PROVENANCE.md).

The separately distributed `K223_Construction_2026-10-20.pdf` has the same
bytes as `report/main.pdf` in this archive.

## Exact machine convention

| Property | Value |
|---|---|
| Working states | 0 through 222 |
| Separate halt state | 223, with no outgoing rows |
| Alphabet | 0, 1 |
| Tape | One tape indexed by the integers |
| Initial tape | All zero |
| Initial head / state | 0 / 0 |
| Moves | L or R, exactly one cell per transition |
| Transition rows | 446 |
| Canonical dispatcher | 22 |

A non-comment row is `state read write direction next_state`.
The first line records the start state. Entering the separate halt state
halts. No preloaded program, extra tape, extra symbol, or stationary move
is excluded from the count.

Canonical table SHA-256:

```text
0d4eb8ffbcd5dc025c8dac198c7d8a15404c35f63134b5e3ed0b7df7673d9231
```

Three files describe the same machine under explicit renaming:

| File in `portable/results/` | Start | Halt | Dispatcher | Purpose |
|---|---:|---:|---:|---|
| `candidate223.tm` | 0 | 223 | 22 | Canonical breadth-first labels; preferred for use |
| `candidate223.k.tm` | 0 | 254 | 84 | Historical K labels used in the fold proofs |
| `candidate223.legacy.tm` | 95 | 254 | 96 | Labels accepted by the inherited runtime engine |

Each has 223 working states. Historical labels above 223 are identifiers,
not additional states. `state_map.json` supplies the complete bijections;
`candidate223.csv` is the canonical table in CSV form.

## The new reduction

Write `d_ab = Eq(a,b)`, `Q_i A = All(i,A)`, and
`kappa(a,b) = RelCode(a,b) = 4*P(a,b)+1`, with the unchanged Cantor pairing.
The old calculus separately emitted

\[
\rho_7(a,b,c):d_{ca}\to(d_{cb}\to d_{ab}),\qquad
H(a,b):d_{ab}\to Q_{\kappa(a,b)}d_{ab}.
\]

The new seventh row is

\[
G(a,b,c):d_{ca}\to
\bigl(d_{cb}\to Q_{\kappa(a,b)}d_{ab}\bigr).
\]

The independent helper H is removed from the successful K bundle. The
remaining bundle is the exact negative conjunction of the unchanged K
core and full gated membership vacuity. The old and new native theories
prove **exactly the same numerical formula codes**. The report proves
reflexivity from G without circularity, reconstructs H, eliminates its
quantifier, recovers literal rho7, and proves the reverse transformation.
Thus the earlier equality interpretation and K code calibration are
inherited unchanged.

The source shrinks from 4,799 to 4,581 primitive occurrences, and from
210 to 209 distinct subtrees. One closed reassociation repairs a seven-zero
program-counter address. The resulting source has maximum zero run six
and compiles to a 226-state parent. Three checked folds then identify
K191 with K157, K303 with K118, and K302 with K159, in that order. The last
two savings use a branch exposed by the changed source/control flow.
The final table has 223 working states.

## Verification performed

| Layer | Checked result |
|---|---|
| Baseline | Fresh complete K224 replay, including inherited runtime replays |
| Native logic | 315 proof nodes, 290 formulas; independent second checker |
| Numerical emitter | Twelve all-register macro bisimulations; arithmetic expression equality for all natural parameters |
| Source binding | Complete 4,581-occurrence instruction word; two guarded-CFG resolvers, 5,956 cases |
| Decoder | All 4,579 compound source entries checked |
| Table folds | Whole-tape positive-block simulation for all initial binary tapes at the start state; three negative controls rejected |
| Final runtime | All 5,956 unbounded symbolic cases freshly derived; all 446 rows covered |
| Blank startup | All 409,835 literal transitions to the stated valid frame; no earlier halt |
| Printed table | All 446 PDF transition rows compared with the canonical machine |

The unbounded runtime proof quantifies over nine independent natural
register values, arbitrary extra gap, arbitrary first spare value, and an
arbitrary finite remaining spare list. Its proof-construction step limit
is not a bound on those values or on the machine's running time.

The checked blank endpoint has dispatcher state 22, head -5, logical
registers `(3,0,0,0,3,0,0,0,0)`, extra gap 117, and 167 spare blocks each
encoding one. Earlier dispatcher visits occur during startup; the report
does not claim this endpoint is the first visit.

## Reproduce offline

Use Python 3.10 or later with assertions enabled. The scripts use only the
standard library. Run from the extracted packet's top directory. Choose
an initially empty destination outside the packet:

```sh
python3 -B portable/reproduce.py --output-dir /tmp/k223-quick
python3 -B portable/reproduce.py --full --output-dir /tmp/k223-full
python3 -B portable/reproduce.py --full --full-baseline --output-dir /tmp/k223-all
```

The modes have distinct scopes:

- **Default:** verify the manifest, replay the inherited baseline's quick
  checks, reconstruct the new source, check the exact emitter, regenerate
  and independently check the finite logic certificate, prove the folds,
  rebuild the canonical machine, execute blank startup, and audit the
  retained final runtime cases' hashes and complete coverage.
- **`--full`:** also freshly derive every final 223-state runtime case.
- **`--full --full-baseline`:** additionally request the predecessor's
  complete runtime replay through its K224/K225/K226 ancestry.

Expected final status is `QUICK_REPLAY_PASS` or `FULL_REPLAY_PASS`.
The destination receives a JSON receipt and separate phase logs.
No network download or third-party Python package is needed.

A fresh final-machine full replay passed in the recorded run. After its
new runtime metadata was incorporated and an incidental bytecode cache
was removed, the 36-file portable manifest was refreshed and another quick
replay passed. Both receipts and their logs are in `verification_runs/`;
the full replay and final quick replay pin the identical table, source,
and finite proof DAG. The separate earlier complete baseline receipt is
in `portable/vendor/baseline224_fresh_replay.json`.

To regenerate the nine exploratory logical certificates:

```sh
python3 -B research/equality_frontends/research_reproduce.py --output-dir /tmp/k223-frontends
```

To regenerate the table appendix and compile the report, install a
standard pdfLaTeX distribution and run:

```sh
python3 -B report/build_report.py --output-dir /tmp/k223-report
```

That command produces `/tmp/k223-report/main.pdf`. It pins the canonical
table before generating `report/transition_table.tex`. Rebuilt PDF bytes
can differ because of TeX timestamps and environment metadata.

## Incorporation and research scope

Keep the portable manifest and its exact inputs together. The pinned
K224 archive is preserved unchanged under `portable/vendor/`, including
its predecessor sources, manifests, and licensing notices. No original
224-state artifact is overwritten by this packet.

The research directory includes further proved equality frontends,
finite NBG/GBC and reflection alternatives, concrete logical obstructions,
and scoped source/table measurements. Those alternative frontends are
not separate claims of improved machines. There is no minimality or
literature-wide priority claim.

The new material uses the MIT No Attribution license in `LICENSE`.
Inherited components retain their original licenses; see `NOTICE.md`.
