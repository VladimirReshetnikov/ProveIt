# Rank Six Conditioning for Every Core

The six-page research note proves both shifted Newton inequalities for the all-right-core conditional cubic of every rank-six bipartite graph with a displayed 3+3 minimum cover, unit left activities and arbitrary positive right activities. A rank-three plane-incidence inequality handles every core rank and all exterior neighborhoods.

The main higher bound is C2^2 >= (21/8) C1 C3; a short refinement gives 75/28. The lower bound is C1^2 >= (2n/(n-1)) C0 C2 and permits arbitrary positive two-shore activities. Common scaling of the three right-cover activities therefore eventually makes all five rank-six gaps strictly positive.

This does not settle arbitrary finite-activity rank-six one-shore ULC. It does not assert that the conditional cubic is ULC3. The globally scoped eventual statement may have equality in the previously settled small-cover branch.

## Files

- article.pdf and article.tex: the complete proof
- build_local.sh: build command for the established local TeX environment
- code/verify_incidence.py: exact integer-vector and full endpoint-minor regressions
- code/check_weighted_planes.py: independently written weighted plane-incidence regressions
- code/replay_all.py: runs both checks and compares their exact output with the included data
- data/: reproducible reference outputs
- VERIFICATION.md: scope and validation summary
- SHA256SUMS: package file manifest

## Replay

Run Python 3. No third-party package is required:

    python code/replay_all.py
    python -O code/replay_all.py

The scripts produce their JSON outputs alongside the scripts. The driver compares those outputs with the included reference data using explicit exceptions, including under optimized Python.

The checks cover 960 unit and 960 weighted plane configurations, 512 exact matrix representations indexed by all Boolean core masks, 38 direct full endpoint-minor enumerations, and 600 independently generated weighted plane configurations. Matrix assignments are permitted to have algebraic dependencies beyond their zero patterns. These checks supplement the general proof; they do not exhaust the infinite graph family.

To rebuild the PDF in an ordinary complete TeX installation, compile article.tex twice with pdflatex. The supplied build_local.sh also provides paths and format generation for the execution environment in which this report was prepared.

## Companion reports

The global minimum-cover corollary uses the already proved small-shore cover theorem in ProveIt_Weighted_Rank_Five_and_Two_Shore_Covers.zip.
The exact counterexample to unrooted ULC3 is in ProveIt_Rooted_Hall_Sectors_and_Cubic_Obstruction.zip.
The rank-38 persistent-failure witness is in ProveIt_Sharp_Rank_38_Hall_Endpoint.zip.

These are companion research notes prepared on 1 October 2026. The new all-core conditional theorem itself has a complete proof in the present article using established Lorentzian theory.

