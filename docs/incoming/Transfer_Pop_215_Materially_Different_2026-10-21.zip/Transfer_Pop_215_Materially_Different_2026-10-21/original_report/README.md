# A 201 node source compiler toward 214 states

The 214-state target remains unmet.

This research packet establishes a complete three-command compiler with 201
source DAG nodes. Its fully checked binary implementation still has 215
working states plus a separate halt label. Source nodes are not TM states.
The two 214-state tables under negative_controls/ are explicitly REJECTED;
neither is presented as a solution.

## Main result

- Complete transfer-pop compiler, retaining the original numerical calculus,
  every logical row, the full gated seed, MP and theorem generalization.
- Closed command S = old DROP; old NIP; old NIP, with a sound additional
  top-equals-one halt. New wire arities are 1, 2 and 3.
- Exact 201-node / 4,775-occurrence source, 215-state / 430-row machine.
- All 6,209 arbitrary-natural whole-tape primitive cases pass, with 1,611,489
  symbolic rules and all 430 literal rows covered.
- Exact blank prefix of 68,442 transitions reaches source ordinal 55,
  head -2, gap 0, registers (1,11,2,0,0,0,0,0,0), 59 spares of value 1,
  and 150 one-cells. Independent sparse/dense and canonical replays agree.
- An independent 174-primitive abstract source prefix identifies this as a
  partial AX computation. Its completion supplies ten theorem heads above
  arbitrary tail 4. A new all-natural credit theorem needs only two heads
  at cutoff 1, leaving permanent conservative margin eight.

Using the explicitly inherited numerical-calculus calibration and all-natural
arithmetic macro contracts, this is an ordinary mathematical proof of the new
215-state machine's blank-start Con(ZFC) equivalence. It is not a new exact-byte
Lean/Rocq endpoint, an unconditional nonhalting proof, or a state lower bound.

## Offline reproduction

Requirements: Python 3, standard library only, assertions enabled. No network,
package installation, repository checkout, or received program execution.

    python3 verify.py --runtime --work /tmp/transfer-replay

The output directory must not already exist. Omit --runtime for the finite
checks alone. The full run takes approximately two minutes on the preparation
machine; runtime varies. A successful full run writes FULL_REPLAY_PASS in
replay.json. This proves only the explicitly stated certificate scope, not
that the unmet 214-state target was achieved.

The default manifest check verifies exact file sizes and SHA-256 hashes.
SHA256SUMS also includes MANIFEST.json and excludes only itself.

## Contents and trust boundary

- report.pdf and report.tex: mathematical report and editable TeX source.
- machine/: ONLY the calibrated 215-state native/canonical tables and map.
- source/: exact 201-node source as a primitive-occurrence list.
- negative_controls/: rejected raw 214 allocation and rejected helper-deletion
  table. The latter provably enters an outward zero-ray from all 214 possible
  designated blank starts, within 85 transitions.
- checks/ and verify.py: owned executable checkers and deterministic recipe.
- inputs/: pinned tables, source, label map and logical certificate, read only
  as inert data. These inputs are never imported as programs.
- evidence/: exact original and fresh isolated replay receipts; compressed
  all-natural case census; finite startup and source-prefix witnesses.
- proofs/: complete command and credit proofs, independent review, and the
  NIP;DROP logical obstruction. Some proof texts retain historical artifact
  names as source references; the report and README give current paths.
- provenance/ and licenses/: inherited source calibration, exact foundational
  pins, relevant upstream finite checks, attribution and unchanged licenses.

The 51 symbolic command tests and 500,000-candidate credit calculation are
finite corroborations. The written inductive arguments prove the unbounded
compiler and credit claims. The symbolic runtime's inference rules have
ordinary mathematical soundness proofs; Python is not a proof-assistant kernel.

## Remaining barrier

The raw 214 allocation overwrites a live arithmetic use of state 26. Protecting
that role costs the missing state. The report separates this concrete failure,
the deleted-helper all-start ray theorem, the NIP;DROP completeness obstruction,
and bounded unsuccessful source/layout searches. None is a general impossibility
proof for 214 states.

## Rebuilding the PDF

report.tex is standalone. With a normal TeX Live installation providing the
listed standard packages, run pdflatex report.tex twice. This typesetting step
is separate from mathematical certificate replay and is not needed to verify
the machine, source, startup, or exact negative controls.
