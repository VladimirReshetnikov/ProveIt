#!/usr/bin/env python3
"""Owned offline exact graph comparison; received tables are inert data.
The table and iso functions are reused from the owned independent upstream
comparison checker. No received program is imported or executed.
"""
from pathlib import Path
from collections import deque
import json, hashlib, itertools

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def table(p):
    out = {}
    for line in p.read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        q, a, b, d, r = line.split()
        key = (int(q), int(a))
        assert key not in out
        out[key] = (int(b), d, int(r))
    states = {q for q, a in out}
    assert set(out) == {(q, a) for q in states for a in (0, 1)}
    assert all((b in (0, 1) and d in ('L', 'R') for b, d, r in out.values()))
    assert {r for b, d, r in out.values()} - states == {254}
    seen = {0}
    todo = [0]
    for q in todo:
        if q == 254:
            continue
        for a in (0, 1):
            r = out[q, a][2]
            if r not in seen:
                seen.add(r)
                todo.append(r)
    assert seen == states | {254}
    return out

def iso(A, B):
    """Start/edge preserving map is forced by word reachability; no heuristic."""
    f = {0: 0}
    g = {0: 0}
    todo = deque([(0, 0, '')])
    while todo:
        q, r, w = todo.popleft()
        if (q, 0) not in A or (r, 0) not in B:
            if ((q, 0) in A) != ((r, 0) in B):
                return {'isomorphic': False, 'witness_word': w, 'reason': 'halt_mismatch'}
            continue
        for a in (0, 1):
            b, d, s = A[q, a]
            c, e, t = B[r, a]
            if (b, d) != (c, e):
                return {'isomorphic': False, 'witness_word': w + str(a), 'reason': 'write_or_direction_mismatch', 'left': [q, a, b, d, s], 'right': [r, a, c, e, t]}
            if s in f:
                if f[s] != t:
                    return {'isomorphic': False, 'witness_word': w + str(a), 'reason': 'nonfunctional_forced_map', 'left_state': s, 'earlier_right': f[s], 'new_right': t}
            elif t in g:
                return {'isomorphic': False, 'witness_word': w + str(a), 'reason': 'noninjective_forced_map', 'right_state': t, 'earlier_left': g[t], 'new_left': s}
            else:
                f[s] = t
                g[t] = s
                todo.append((s, t, w + str(a)))
    assert len(f) == len(g) == 216
    assert f[0] == 0 and f[254] == 254
    assert all((B[f[q], a] == (b, d, f[s]) for (q, a), (b, d, s) in A.items()))
    return {'isomorphic': True, 'full_map': dict(sorted(f.items())), 'changed_labels': {q: r for q, r in sorted(f.items()) if q != r}}

def main():
    import os, sys
    assert __debug__ and not sys.flags.optimize and not os.environ.get('PYTHONOPTIMIZE'), 'Enable Python assertions'
    root = Path(__file__).resolve().parent
    read = lambda rel: json.loads((root / rel).read_text())
    manifest = read('MANIFEST.json')
    for item in manifest['files']:
        path = root / item['path']
        assert path.is_file() and path.stat().st_size == item['bytes'], item['path']
        assert digest(path) == item['sha256'], item['path']
    # Preserve every file, including the original manifest and checksums, exactly.
    original = read('evidence/ORIGINAL_PACKET_IDENTITY.json')
    for rel, pin in original['files'].items():
        path = root / 'original_report' / rel
        assert path.stat().st_size == pin['bytes'] and digest(path) == pin['sha256'], rel
    published = read('evidence/TRANSFER_PUBLICATION_IDENTITY.json')
    assert published['identical_to_delivered_local_packet'] is True
    assert published['bytes'] == original['original_archive_bytes'] == 602802
    assert published['sha256'] == original['original_archive_sha256'] == '851bdba4edbed213157ad7ea18c6a0f3de54c84e29d2293cfab2c1962fd3c02b'
    index = read('evidence/COMPARISON_INPUTS.json')
    assert len(index) == 12 and 'transfer' in index
    tables = {}
    for name, pin in index.items():
        path = root / pin['path']
        assert digest(path) == pin['sha256'], name
        assert path.read_text().splitlines()[0].strip() == '#! start 0', name
        tables[name] = table(path)
        assert len(tables[name]) == 2 * pin['states'] == 430, name
    actual = {name: iso(tables['transfer'], t) for name, t in tables.items() if name != 'transfer'}
    assert len(actual) == 11 and all(x['isomorphic'] is False for x in actual.values())
    extended = read('evidence/EXTENDED_EXACT_COMPARISON.json')
    assert extended['tables'] == index and extended['comparisons'] == actual
    first = read('evidence/EXACT_NOVELTY_COMPARISON.json')
    assert len(first['comparisons']) == 9
    for name, pin in first['tables'].items():
        assert pin['sha256'] == index[name]['sha256']
        assert pin['states'] == index[name]['states']
        assert pin['path'] == index[name]['original_path']
    assert first['comparisons'] == {name: actual[name] for name in first['comparisons']}
    # Independent direct two-word witness. Check edge outputs too, not just endpoints.
    witness = read('evidence/MATERIAL_DISTINCTION_WITNESS.json')
    assert witness['delivered_table_sha256'] == index['transfer']['sha256']
    endpoints = []
    for entry in witness['witnesses']:
        left = right = 0
        for char in entry['read_word']:
            a = int(char)
            u = tables['transfer'][left, a]
            v = tables['ours210'][right, a]
            assert u[:2] == v[:2]
            left, right = u[2], v[2]
        assert (left, right) == (entry['transfer_state'], entry['baseline_state'])
        endpoints.append((left, right))
    assert len(endpoints) == 2 and endpoints[0][0] != endpoints[1][0] and endpoints[0][1] == endpoints[1][1]
    result = {
        'status': 'DISTINCTION_REPLAY_PASS',
        'working_states': 215, 'source_dag_nodes': 201, 'target214_met': False,
        'preserved_original_files': len(original['files']),
        'total_pinned_tables': len(index), 'nonisomorphic_predecessor_tables': len(actual),
        'exact_original_nine_results_preserved': True,
        'independent_two_word_witness': 'PASS',
        'original_publication_identity': 'PASS',
        'comparison_convention': 'start/read/write/direction/halt preserving state relabeling',
        'received_code_executed': False
    }
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
