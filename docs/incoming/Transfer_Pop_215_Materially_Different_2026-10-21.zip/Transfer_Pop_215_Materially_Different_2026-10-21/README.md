# A materially different transfer pop machine with 215 states

This packet presents the previously constructed and delivered transfer-pop machine, with **215 working states plus a separate halt label**, as the materially different 215-state alternative allowed by the revised request. It does not contain a newly constructed post-request table. The original 214-state target remains unmet. **201 is the source DAG node count, not the machine-state count.**

Read `addendum.pdf` first. Its editable source is `addendum.tex`. The complete original 12-page report and every original reproducibility file are preserved byte-for-byte under `original_report/`, including that packet's manifest and checksums. No original archive was modified.

## The substantive difference

The executable command language changes from NIP / DROP / MP / AX to transfer-pop S / MP / AX. The actual S body is oldDROP; oldNIP; oldNIP. A complete compiler and a new unbounded protected-credit theorem establish the changed source and its unusual partial-AX blank startup. These are ordinary mathematical proofs with exact executable certificate checks, not a new exact-byte Lean or Rocq endpoint.

The candidate is `original_report/machine/transfer215.native.tm`:

`1f8194fa49a638857ecf5b4f69b1ae92cb47d11d1a74e952bbb91049c893a836`

Its canonical form and label map are in the same folder. Rejected 214-state controls are explicitly separated under `original_report/negative_controls/` and are not the candidate.

## Exact distinction checks

`comparison_inputs/` contains eleven predecessor tables as inert data. The standalone owned checker `check_distinction.py` verifies their complete digests, 215-state total transition format and rooted graph reachability, then reconstructs all eleven exact forced-map nonisomorphism results. It also replays a separate direct two-word collision witness, preserves the original nine-table receipt, and checks every original packet file against a byte-level extraction inventory.

Run from the new archive root, using Python 3 with assertions enabled:

```
python3 check_distinction.py
sha256sum -c SHA256SUMS
```

Expected checker status: `DISTINCTION_REPLAY_PASS`.

The comparison preserves the designated start, read symbols, write symbols, directions and halt. It excludes mere state renaming under that convention. It does not test global reflection or symbol recoding, claim different computed behavior, or establish global novelty. The material algorithmic difference is supported by the language, compiler and startup proofs, not graph nonisomorphism alone.

To replay the original finite certificate and full symbolic runtime checks:

```
python3 original_report/verify.py --runtime --work /tmp/transfer215-replay
```

Choose a fresh, nonexistent output directory. The all-natural runtime replay covers 6,209 cases and takes about two minutes on the original environment. The unbounded compiler and protected-credit arguments are written proofs, not claims that this command invokes a proof assistant. Their independent review and the previous isolated full replay are retained in the original packet. No received programs are executed. Both checkers use only the Python standard library.

## Chronology and provenance

The eleven-table scope comprises the nine earlier reviewed tables plus two q13 variants from commit `32498004963846db7655eedce7e94f8c88f6fa8a`. Full paths, digests and exact witnesses are in `evidence/EXTENDED_EXACT_COMPARISON.json`; table labels are navigation aids, not assertions that all eleven are pairwise distinct.

Commit `7342ae8c96c325bb8340291f43d7573866a77cd7` subsequently put our original packet in `docs/incoming/`. The retrieved ZIP is byte-identical to the delivered 602,802-byte archive:

`851bdba4edbed213157ad7ea18c6a0f3de54c84e29d2293cfab2c1962fd3c02b`

See `evidence/TRANSFER_PUBLICATION_IDENTITY.json`. This is the same contribution, not an additional predecessor or a new construction after the revised request. Presence in an incoming collection is not asserted to be formal acceptance.

The independent assessment in `evidence/MATERIAL_DIFFERENCE_ASSESSMENT.md` records its original nine-table scope. The extended receipt and owned replay checker add the two later q13 tables without altering that historical assessment. `evidence/CURRENT_UPSTREAM_DISTINCTION.md` records the bounded upstream snapshot. No ongoing latest-commit monitoring is implied.

Inherited licenses, notices and source links are preserved in `original_report/licenses/` and `original_report/provenance/`, with direct repository links in the original report and this addendum. New executable code is owned checker code only. Comparison tables are copied inert inputs from the pinned research packets, with their provenance retained.
