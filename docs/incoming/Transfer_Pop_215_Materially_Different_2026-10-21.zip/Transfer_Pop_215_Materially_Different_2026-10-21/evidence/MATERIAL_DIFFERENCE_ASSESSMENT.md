# Assessment against the revised 214-or-different-215 request

Date: 2026-10-21.

## Conclusion

Yes. The delivered transfer-pop machine is a materially different 215-state construction compared with the nine previously reviewed 215-state tables. The distinction is not merely a renumbering, a different association of unchanged source statements, or another allocator applied to the same command system.

The delivered native table is `research214_report/package/machine/transfer215.native.tm`, SHA-256 `1f8194fa49a638857ecf5b4f69b1ae92cb47d11d1a74e952bbb91049c893a836`. Its separate halt label is not counted among its 215 working states.

## Substantive differences

1. **Different executable command system.** The predecessors expose four command families: NIP, DROP, MP and AX. The new source exposes only transfer-pop S, MP and AX. It removes standalone DROP and changes the old NIP operation into S=oldDROP;oldNIP;oldNIP. On a nonhalting input, S moves old cache to top and pops the stack into cache; it tests both incoming top and cache for falsity. Old NIP preserved top and tested only cache. The selector partition becomes 0,1,>=2, rather than 0,1,2,>=3. Raw candidate numbers therefore have genuinely different operational meanings.

2. **A new complete compiler is necessary and supplied.** The old DROP-based strong blocks do not apply by a simple label permutation. The new proof derives PUSH from AX;S^9;MP(0), derives a top-preserving guarded pop from AX;S^11, and rebuilds all axiom retrieval, GEN and major-first MP blocks. It proves exact arbitrary-stack strong contracts, handles I(0,0)=0 and earlier halts, and supplies cofinal refuting candidate encodings. This changes the source from 202 distinct DAG nodes / 4,751 primitive occurrences to 201 / 4,775.

3. **A different initialization argument is essential.** The reviewed predecessors use an exact clean zero root with next candidate 4. This machine reaches a complete represented frame inside an AX computation after 68,442 blank transitions. An exact 174-primitive source-prefix match identifies the computation. Completing that AX yields ten theorem heads above arbitrary numerical tail4, with next candidate1. The freshly proved new-tag protected-credit theorem requires only two heads there and preserves a margin of eight indefinitely. This is not the predecessor's clean-root startup or a verbatim reuse of its old-tag credit theorem.

4. **The literal transition graph is not a relabeling.** Root receipt `research215_distinction/EXACT_NOVELTY_COMPARISON.json` rejects start/read/write/direction-preserving isomorphism to all nine previously reviewed tables. An additional independent witness against the direct predecessor is in `MATERIAL_DISTINCTION_WITNESS.json`: the abstract root-read words 00000010010000000010111 and 00000010010000000011110 reach distinct new states13 and311 but both force predecessor state13, contradicting injectivity of any state relabeling. The delivered table bytes match the table used in that comparison. These words are graph witnesses, not an assertion that both occur in a blank-tape trajectory.

## Established status and limits

The integrated delivered result has an independently reviewed ordinary mathematical compiler and protected-credit proof, complete all-natural primitive certificates for 6,209 guarded cases, all 430 literal transition rows covered, exact full-frame blank startup, and an isolated full replay marked PASS. Under the explicitly pinned inherited numerical-calculus calibration and arithmetic macro contracts, these establish the claimed blank-halting equivalence to existence of a ZFC refutation. This is an established ordinary mathematical construction, not a still-provisional decoder allocation.

It is not a 214-state construction, a proof that 214 is impossible, an unconditional nonhalting result, or a new exact-byte proof-assistant endpoint. The numerical calculus, arithmetic machinery, runtime method and foundational comparison are inherited and credited. The novelty comparison is bounded to the previously reviewed tables, not an unverified claim of worldwide priority.

The delivered archive's “214 target unmet” title records the earlier narrower request. It does not negate that its verified transfer-pop215 satisfies the newly allowed materially different215 alternative.
