# Pinned upstream snapshot and publication identity

Observed on 21 October 2026 at approximately 03:42 UTC. This is a bounded snapshot, not a continuing claim about the latest repository state.

## Two additional comparison tables

[Commit 32498004963846db7655eedce7e94f8c88f6fa8a](https://github.com/VladimirReshetnikov/ProveIt/commit/32498004963846db7655eedce7e94f8c88f6fa8a) adds the investigation packet containing two further 215-state scheduler variants:

- q13 CB: SHA-256 `c6ff22b5446bb7f14a9f8ea02828fa694291ce1b7c71cf1ea3cb488d03d30dc5`.
- q13 normal: SHA-256 `04a920b972cd14da6d9bb0496a31fb882f2a37be9dae333894301c290176df7c`.

These tables are included as inert data. The new packet's owned checker independently verifies their byte digests, total 215-state format, rooted graph reachability, and exact nonisomorphism to the transfer-pop table. Both fail the forced state-renaming comparison with the same witness word `000000100100000000100000`.

Their source retains the earlier four-command system and adds a CB1 scheduler operation. The upstream packet reports 202 source DAG nodes, 4,752 primitive occurrences, and 6,177 runtime cases. Those runtime claims were not re-proved by the new comparison checker and are not needed for the graph distinction. The transfer-pop result instead has the independently checked 201-node, 4,775-occurrence, three-command source and 6,209 runtime cases documented in the preserved original report.

## The original transfer packet is now upstream

[Commit 7342ae8c96c325bb8340291f43d7573866a77cd7](https://github.com/VladimirReshetnikov/ProveIt/commit/7342ae8c96c325bb8340291f43d7573866a77cd7) adds `docs/incoming/Transfer_Compiler_201_Nodes_214_Target_Unmet_2026-10-21.zip`.

The retrieved file is byte-for-byte identical to the previously delivered archive: 602,802 bytes, SHA-256 `851bdba4edbed213157ad7ea18c6a0f3de54c84e29d2293cfab2c1962fd3c02b`. The separate `TRANSFER_PUBLICATION_IDENTITY.json` records the exact URL and receipt.

This is publication of the same transfer-pop construction, not a twelfth distinct predecessor and not a new post-request construction. Its presence in `docs/incoming/` is not asserted to be formal acceptance as a primary candidate. The addendum therefore compares it with the eleven earlier pinned table presentations, rather than claiming it is absent from current upstream or globally novel.

No verified 214-state construction was established in this bounded review. The original 214-state target remains unmet. No received program was executed; the new reproduction executes only owned checks on inert tables.

This publication-oriented summary condenses the upstream comparison findings. The exact table and publication receipts, not this prose summary, are the inputs to the executable checks.
