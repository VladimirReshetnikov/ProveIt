# Logarithmic square growth for ascent sequences avoiding 000

This package contains a self-contained mathematical article for OEIS A202058 and finite reproducibility checks. The proof is in `a202058-lognormal.pdf`; its editable source is `a202058-lognormal.tex`.

## Proved results and limits

For T = 3π²/8, A(t) = Σ a_n t^n/n!, c_n = a_n T^n/n!, and S_N = Σ_{n≤N} c_n:

- log A′(t(Q)) = Q²/6 + O(Q^(3/2) sqrt(log Q))
- log A(t) ~ (2/3) log²(1/(T−t))
- log S_N = (2/3) log² N + O((log N)^(3/2) sqrt(log log N))
- limsup log c_n / log² n = 2/3

The full individual limit remains unproved. No full coefficient equivalent, amplitude, ratio limit, optimal remainder, or explicit effective remainder constant is asserted. The weaker one-sided ratio criterion in the article is an abstract sufficient condition, not a verified property of A202058.

## Portable extraction and replay

From the directory containing the ZIP, Python extraction avoids any dependency on a system unzip command:

    python3 -m zipfile -e a202058-lognormal-report.zip extracted
    cd extracted/a202058-lognormal-report
    bash replay.sh core

Run shell scripts with `bash`, regardless of executable bits after extraction.

- `bash replay.sh core`: standard-library exact rational and independent literal-word enumeration checks
- `bash replay.sh full`: core checks plus forty numerical corrected-residual checks; requires NumPy
- `bash replay.sh all`: full checks followed by a three-pass PDF rebuild; requires NumPy and pdfLaTeX
- `bash build.sh`: PDF rebuild only

The shell entry points require Bash, Python 3, and standard command-line utilities. They do not access the network or install packages. The PDF build requires pdfLaTeX and the standard packages geometry, fontenc, lmodern, microtype, amsmath, amssymb, amsthm, mathtools, enumitem, booktabs and hyperref. On a TeX installation missing its format cache, the build script generates the format inside the local `build` directory. No elevated permissions are needed.

All frozen package members are verified first with Python SHA-256. Regenerated test outputs go in `build/replay`; frozen results remain unchanged. Building replaces the top-level PDF, which is deterministic in the tested environment. Other TeX versions may produce a visually equivalent PDF with a different byte hash; re-extract the archive to restore the frozen original before rechecking its manifest.

## Contents

- `a202058-lognormal.pdf` and `.tex`: article and source
- `scripts`: exact rational identities, independent small-word enumeration, residual diagnostic, manifest checker
- `results`: frozen JSON test results
- `source-audit`: public reference/provenance metadata, source fingerprints, integrated review and release QA records
- `build.sh`, `replay.sh`: portable entry points
- `SHA256SUMS`: SHA-256 hashes of all other frozen package members

The rational checker covers 73,984 transition cases. The independent enumeration checks every length through 10 against literal ascent words. The residual check uses closed-form interval integrals, 64-point Gaussian quadrature, and centered finite differences. These finite tests corroborate formulas and implementation; they cannot prove the article's uniform bounds, convergence, regularity hypotheses, or asymptotic conclusions.

The package contains no third-party full papers, credentials, or working correspondence. Public references are linked in the article. Analytical source reviews and the fresh integrated article review are not formal proof-assistant certificates. Scoped novelty searches are not a worldwide-priority claim.
