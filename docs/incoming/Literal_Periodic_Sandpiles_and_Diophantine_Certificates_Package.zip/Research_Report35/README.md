# Research Report 35

## A Literal Periodic Sandpile Loader and Finite Prism Certificates

Read `Research_Report35.pdf` for the self-contained mathematical article. `Research_Report35.tex` is a standalone editable source, with all diagrams authored inline in TikZ. It does not require external image files or the author's workspace.

The construction gives one explicit stable periodic ordinary Z³ sandpile background and a finite nonnegative loader for each finite two-sided binary U15 tape. Global finite total activity is equivalent to U15 halting. On halting pairs with total half-length n and halting time T, this layout has total toppling work of order (n+T+1)² and a fixed-thickness quadratic-volume active prism. The cubic finite-prism certificate uses exactly 8V+6E+H natural witnesses and 8V+7E+H nonnegative summands, where H counts the exact exterior six-face halo.

Cairns's sandpile universality and Neary–Woods's fixed-machine universality are prior results. The arbitrary-program-to-U15-pair software encoder is not implemented here. Natural-witness uniqueness holds separately for each fixed prism, not across padded prisms and not over nonnegative real witnesses. This is a variable-arity polynomial family, not a new fixed-arity universal Diophantine polynomial or a Lean-verified theorem.

## Contents

- `Research_Report35.pdf` and `.tex`: the article
- `evidence/loader/`: byte-identical approved loader packet, finite U15 data, full literal rule stream, primitive/router/compiler code, proofs, receipts and independent audit
- `evidence/composition/`: byte-identical approved coefficient compiler, full proof, exact ledgers, literal adapter, tests and independently authored audit programs
- `verification/`: frozen structured replay expectations, replay plan, original-to-packaged source identities, primary-source metadata and separate mathematical/code review receipts
- `INTEGRITY.md`: detailed trust boundary, replay and archive behavior
- `verify_release.py`, `tamper_regression.py`: immutable enclosing replay and rejection checks
- `build_pdf.py`: external deterministic PDF rebuild
- `archive_release.py`, `archive_regression.py`: deterministic ZIP production and safe-inventory validation

Original proof source-relative locators are interpreted relative to their preserved evidence packet. For example, `compiler/literal_loader.py` in the loader proof means `evidence/loader/compiler/literal_loader.py` in this release. No pinned source file was silently normalized or edited for packaging. The composition adapter's sibling `../loader` path resolves within `evidence/`.

## Safe first checks

From this directory, with standard Python 3:

    python verify_release.py --verify-only
    python -O verify_release.py --verify-only
    python verify_release.py --self-test-types
    python tamper_regression.py

Run the complete finite evidence replay with:

    python verify_release.py --replay

The wrapper runs each suite under both normal and optimized Python in disposable external copies and compares regenerated structured receipts exactly. It leaves the received release unchanged. Full replay can take several minutes: it checks the complete 5,819,945-edge incidence stream and substantial finite geometry/coefficient suites. The inner research scripts regenerate receipts in place; use the wrapper rather than running them inside the received release.

## Rebuild the PDF or ZIP

A local TeX Live installation including pdfLaTeX, Latin Modern, AMS packages, TikZ and hyperref is required to rebuild the PDF. No downloads or shell escape are used:

    python build_pdf.py --output ../report35-new-build

Create a deterministic archive at a new destination:

    python archive_release.py --create ../Research_Report35.zip

Use an independently received SHA256 to anchor archive authenticity. A package cannot authenticate a coordinated replacement of its own verifier and all expected data. See `INTEGRITY.md` for exact moved-extraction and tamper-regression commands. `seal_release.py` is a maintainer tool; recipients should not reseal a received release.

## What has and has not been executed

The release contains finite primitive, rule, route, port-incidence, background-coefficient, machine-trace and polynomial-coefficient evidence. The literal composition test checks a 45-record raw coefficient prefix and genuinely lazy huge-prism iterator prefixes. The 43-chip example is a 75-transition U15 halt whose CA extinction and literal seed coordinates were checked.

The approximately 1.9×10²⁷-entry dense period, a full universal routed-sandpile evolution and a complete giant-prism polynomial were not materialized, simulated, expanded or solved. The full collected coefficient algorithm is mathematically finite with bounded local record storage, but computes a global constant first; limiting its output does not make this initial pass inexpensive. The coefficient CLI's candidate time/head arguments do not certify that the machine really halts there.

Hashes, reproducible builds and finite tests identify and test the delivered objects. The unbounded mathematical conclusions rest on the proofs and separately recorded independent reviews.
