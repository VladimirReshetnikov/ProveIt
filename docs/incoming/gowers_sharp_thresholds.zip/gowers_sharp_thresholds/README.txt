SHARP THRESHOLDS AND EXTREMAL CONSTANTS
IN GOWERS'S SZEMEREDI FRAMEWORK

Research article prepared for ProveIt, 6 October 2026.

MAIN DELIVERABLES

gowers_sharp_thresholds.tex is the complete article in one LaTeX file.
gowers_sharp_thresholds.pdf is its compiled, linked PDF.
The figure PDF is included, so a normal LaTeX build needs no Python packages.

The article includes complete written proofs, finite examples, a provenance
ledger, a formalization roadmap, and twelve further research questions.

MAIN RESULTS

1. Sharp thresholds for simultaneous affine-phase partitions with prescribed
   admissible lengths. The numerical-semigroup conductor is necessary even
   when different cells may use different steps. Matching upper and lower
   bounds have leading constant one for narrow sets of admissible lengths.
   For lengths L and L+1, the eventual universal threshold is asymptotic to
   L^(q+2) divided by the product of the q accuracy tolerances. This settles
   the necessity question in the earlier project report. The already known
   sufficient exponent 1/(3q+2), when accuracy has twice the length exponent,
   is proved optimal in this precise model. The article also proves an exact
   residue-packing formula and a sharp small-exception threshold.

2. The optimal secondary coefficient for centered three-cube counts on
   groups of exponent five is 2^(3/4)/3. The bound has an absolute O(u^8)
   remainder and is uniform in dimension. An exact five-point example and
   indicator approximations attain it. Necessary phase rigidity is proved.
   An appendix computes the tertiary value 20/9 for the particular example;
   determining the GLOBAL tertiary optimum remains open.

3. A common-base refinement and exact residue transport for proper modular
   boxes provide a conditional refinement of the geometric part of Gowers's
   Lemma 16.10. Localization keeps at least one third of the initial width;
   the subsequent common base width is preserved during transport. Explicit
   interpolation lists, exception budgets, and sampling estimates are given.

READING MAP

Section 1: main conclusions, attribution, and scope.
Sections 2-6: phase partitions, numerical semigroups, prime witnesses,
              exponent optimality, and partial coverage.
Section 7: characteristic-five cube asymptotics and sharpness.
Section 8: common partitions, exact transport, and conditional gluing.
Section 9: verification and proposed repository integration.
Section 10: twelve further research questions.
Appendix A: tertiary expansion of the five-point model.
Appendix B: build instructions and package description.

BUILD

Requirements: a standard TeX Live installation providing pdfLaTeX, AMS
packages, Latin Modern, geometry, microtype, graphicx, booktabs, longtable,
tabularx, enumitem, xcolor, fancyhdr, xurl, hyperref, and bookmark.

From this directory:

    make pdf

This invokes pdfLaTeX three times to stabilize the table of contents and
cross-references. No bibliography processor or shell escape is required.
You can instead run the following command three times:

    pdflatex -interaction=nonstopmode -halt-on-error gowers_sharp_thresholds.tex

To reproduce the exact checks:

    make check

The three verification scripts use only Python 3's standard library and
make no network requests. Their outputs are recorded in data/.

To regenerate the figure, install NumPy and Matplotlib and run:

    make figure

The optional plotting packages are unnecessary for the proofs, verification
scripts, or PDF build. The figure plots proved bounds, not numerical estimates
of the unknown exact threshold.

PACKAGE CONTENTS

    gowers_sharp_thresholds.tex
    gowers_sharp_thresholds.pdf
    README.txt
    Makefile
    SHA256SUMS
    code/verify_prescribed_partitions.py
    code/check_fifth.py
    code/verify_section16_gluing.py
    code/make_figure.py
    figures/phase_thresholds.pdf
    figures/phase_thresholds.png
    data/partition_checks.json
    data/fifth_checks.txt
    data/gluing_checks.json
    data/source_manifest.json
    data/build_validation.json
    data/latex_build.log

SOURCE PROVENANCE AND INTEGRATION

Repository: https://github.com/VladimirReshetnikov/ProveIt
Inspected revision: 65f4e039fc4ad30a8f492e63abde2bcd0740d7c9
The exact source URLs and available Git blob hashes are in
data/source_manifest.json. Earlier project reports are explicitly credited.

Suggested destination:

    Combinatorics/Ramsey/Research/GowersSzemeredi/
        sharp-thresholds-and-extrema/

Keep the article as a separate research unit during review. Section 9 explains
which research questions the written proofs settle, which nearby formal
interfaces can be reused, and what remains open. Update the research ledger
only with the precise hypotheses and scope stated in the article.

STATUS AND LIMITS

This is a research draft with complete written proofs and reproducible exact
finite checks. The finite checks detect arithmetic, counting, and transcription
errors; they are not substitutes for the quantified proofs in the article.

No Lean source or kernel-checked proof of these new results is supplied.
The full Section 16 control-function recurrence remains open here.
No new best general bound for Szemeredi's theorem or comprehensive historical
priority claim is made. No changes have been pushed to the ProveIt repository.

Checksums describe the delivered package. Regenerating files may change their
checksums even when their mathematical content is unchanged.
