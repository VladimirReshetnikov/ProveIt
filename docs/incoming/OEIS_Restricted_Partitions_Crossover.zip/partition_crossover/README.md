# Beyond the Cubic Boundary

**Uniform restricted-partition asymptotics, an infinite crossover hierarchy,
and analytic inversion.**

Research report prepared for Vladimir Reshetnikov, October 4, 2026.
AI-generated, unrefereed, not formalized in a proof assistant.

## Read

`article.pdf` is the 20-page report. `article.tex` is its self-contained LaTeX
source, with an internal bibliography and no external figure dependencies.

The subject is `p_m(N)`, partitions of N into parts at most m. With
`X = N + m(m+1)/4`, the main result is a uniform fixed-order logarithmic
expansion for every `N >= a*m^2`, for each fixed a>0, without any upper bound
on N. It extends the zero-saddle matching problem identified by the two
restricted-partition reports in ProveIt.

The centered volume approximation has its first sharp boundary at m^(5/2),
not the uncentered m^3 boundary. Subsequent nonzero entropy coefficients
produce further transition exponents `2 + 1/(2r)`. The first six are explicitly
negative; infinitely many coefficients are proved nonzero. Negativity or
nonvanishing of EVERY coefficient remains a proposed research question.

## Result map

- Theorem 2.1, proved in Sections 3–6: the uniform all-fixed-orders expansion.
- Theorem 2.2 and Section 8.2: the sharp centered m^(5/2) boundary.
- Theorem 2.3 and Sections 7–8: rational coefficients and infinite hierarchy.
- Theorem 2.4 and Section 10: analytic inversion; Proposition 10.1 gives
  discrete threshold error transfer rather than an exact rounding claim.
- Section 9: compatibility with classical Szekeres and existing OEIS/cubic laws.
- Section 11: the precise meaning and limitations of the exponential hierarchy.
- Section 12: computational evidence, including a finite-size example that has
  not yet reached the sign of its limiting second-transition constant.
- Section 13: seven further research directions.

## Reproduce

Python 3.10 or later is recommended; the recorded run used Python 3.13.5.

```sh
python -m pip install -r requirements.txt
python code/derive_coefficients.py
python code/verify.py
```

The scripts locate `data/` relative to their own package location, so they
can be invoked from any working directory. They overwrite only their own
result files. No network access is used by the scripts themselves.

The recorded verifier passes 4,017 exact arithmetic assertions, four symbolic
identities, and ten numerical profile checks. It records 46 exact partition
samples, up to m=96 and N=268566, with 55-digit numerical diagnostics.
Numerical diagnostics use mpmath, NOT outward-rounded interval arithmetic.
They do not certify the analytic error constants or replace the proofs.

For a PDF build with a reasonably complete TeX Live installation:

```sh
sh build.sh
```

The document uses standard pdfLaTeX packages, including Latin Modern,
amsmath, amsthm, mathtools, microtype, geometry, booktabs, fancyhdr and hyperref.
No font files are distributed.

## Files

- `article.tex`, `article.pdf`: source and report.
- `code/asymptotics.py`: continuum profiles, exact finite-saddle evaluator,
  and sample-value inverse chart.
- `code/derive_coefficients.py`: exact coefficient derivation and assertions.
- `code/verify.py`: independent integer recurrences and numerical comparisons.
- `data/coefficients.json`, `data/symbolic_run.txt`: rational coefficient record.
- `data/exact_samples.json`: exactly computed partition counts (decimal strings).
- `data/uniform_errors.csv`, `data/finite_saddle_checks.csv`: forward errors.
- `data/crossover_checks.csv`, `data/inverse_checks.csv`: transition and inverse
  diagnostics.
- `data/profiles.csv`: numerical analytic profiles.
- `data/verification_summary.json`, `data/verification_run.txt`: verification log.
- `SOURCE_AUDIT.md`: actual source access and novelty boundary.
- `QA.md`: production and mathematical review checklist.
- `SHA256SUMS.txt`: checksums of the delivery files, excluding the ledger itself.

## Scope and attribution

Leading Szekeres asymptotics and the uncentered cubic law are classical or
already in the inspected repository. They are not claimed as new here.
The report is a new-to-this-delivery uniform formulation and explicit
correction/inverse calculus, not a declaration of a historically verified
breakthrough. See `SOURCE_AUDIT.md` for the limited literature audit.

No individual noncentral Sylvester waves, optimal truncation, Borel summation,
or uniform opposite endpoint N/m^2 -> 0 are proved. The listed future questions
are proposals, not results. Nothing was submitted to OEIS or committed to GitHub.
