# Topology Is Not Free
## Loop-Sensitive Diophantine Certificates for Interaction Nets

Research prepared with ChatGPT for Vladimir Reshetnikov's ProveIt program.
Date: 2 October 2026.

## Read first

`article.pdf` is the full research article; `article.tex` is its LaTeX source.
The article addresses the bounded topology-aware compilation interface left
open in ProveIt's `interaction_combinator_wiring_obstruction.md`.

Proved constructions:

* A ten-state local boundary calculus, with exact surviving wires and closed
  wire counts. The explicit annihilation kernel has six source variables,
  17 extension variables, and 23 quadratic equations.
* A deterministic capped-memory certificate with exactly `17*L - 4` private
  variables and quadratic equations, for fixed positive horizon/address/value
  caps `L,A,V`. The source log has a further `3*L` coordinates. A precomputed-base
  variant reduces both private counts to `16*L - 4` at a coefficient-size cost.
* A constructive, proved quartic family for exact bounded interaction-net
  executions, linear in explicit input size and the external horizon, with
  exactly one auxiliary witness per legal scheduled execution. It preserves
  bare loops, numbered ports, and a canonical fresh-name convention.

The local matching abstraction's ten-state lower bound has a specific
observation interface: it recovers the external-position set and both binary
annihilation loop counts. It is not a global graph-memory lower bound.

## Scope and trust boundary

The two arithmetic kernel emitters, complete sparse/expanded polynomial
exports, witness generators, exact reducers, and finite tests are implemented.
The **full unknown-schedule interaction-net polynomial assembler is specified
and proved in the paper, but is not implemented in this package**. Consequently
no measured full-controller gate count is reported.

This is mathematical proof plus finite exact-integer testing, not a Lean
formalization. The uniqueness is for the auxiliary extension of a supplied
schedule; different schedules remain different zeros. The construction is a
polynomial family whose arity grows with the external horizon, not a fixed-arity
single-fold universal polynomial. No solution of the general finite-fold
problem, operation-count record, or independent priority for all ingredients
is claimed.

## Reproduce

Python 3.10 or later, standard library only:

```sh
python code/verify.py
python code/verify_exports.py
```

The first command regenerates the kernel exports and verification receipt.
The second is an independent JSON polynomial checker: it does not import the
compiler, checks the expanded sum of squares coefficient-by-coefficient,
checks the degree and witness, and rejects each one-coordinate increment.

Build the PDF with a TeX installation providing Libertinus, AMS packages,
geometry, microtype, hyperref, fancyhdr, titlesec, listings, and TikZ:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

No font files are included. The TeX source uses the installation's fonts.

## Files

- `code/certificates.py`: sparse quadratic systems, witness generators, quartic
  exporters; exact natural-number domain.
- `code/nets.py`: literal six-rule interaction-combinator templates and two
  different gluing implementations (component traversal and local formulas).
- `code/verify.py`: exhaustive boundary/log/four-cell tests and seeded full-rule
  tests; writes `data/verification.json`.
- `code/verify_exports.py`: independent verification of serialized quartics;
  writes `data/export_audit.json`.
- `data/delta_loop_quartic.json`, `data/gamma_loop_quartic.json`: full local
  quartics, quadratic residuals, and two-loop witnesses.
- `data/memory_example_quartic.json`: the four-access example (`A=4,V=10`),
  12 source coordinates, 64 private coordinates, 64 residuals, 402 monomials.
- `data/verification.json`, `data/export_audit.json`: actual test receipts.
- `data/source_audit.json`: literature and repository provenance.
- `data/pdf_quality.json`: PDF build/render audit.

A polynomial in JSON is a list of `{coefficient, monomial}` records. A monomial
is a sorted list of variable names; repeated names are repeated factors. The
empty list means 1. All coefficients are exact integers. Source and auxiliary
variables are explicitly separated. All variables range over nonnegative
integers, not arbitrary integers or finite fields.

## Validation coverage

For each annihilation rule: 64 Boolean inputs classified, with ten legal
partial matchings and 54 impossible ones. All ten outputs agree with a separate
component oracle. For memory: 584 source logs at `A=V=2`, lengths 1 through 3;
258 are valid; all 11,310 single-private-coordinate increments are rejected.
For nets: all 73 closed two-cell inputs over ordered symbol assignments,
all 10,395 four-delta-cell port matchings and 5,670 enabled rewrites, and 2,762
steps on 1,000 seeded mixed-rule inputs. All checks pass.

The two reducers share the fixed numbered rule templates, but not their gluing
algorithms. Their agreement does not independently prove the source rule table.
The original numbered diagrams were separately visually inspected. The written
proofs, not the finite mutation tests, establish uniqueness over all naturals.

## Provenance

Repository snapshot: `6914ccca6685baf53b7a35f25efc89366c76ba74`.
Motivating note blob: `764c982297342093307a0e831bc0d9ed5084c87f`.
The bibliography credits Lafont, de Falco, Batcher, Matiyasevich, and the earlier
ProveIt constructions. Only the newly prepared article and code are included;
no third-party paper PDFs or repository files are redistributed.
