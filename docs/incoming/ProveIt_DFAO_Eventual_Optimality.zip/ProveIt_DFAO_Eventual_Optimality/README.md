# Eventual Optimality in Binary DFAO Reversal

Research article prepared for Vladimir Reshetnikov, 28 September 2026.

## Main result and its exact scope

Fix the number k >= 3 of output symbols. Let M_k(n) be the largest reversal
state complexity of a minimal, accessible, binary-input n-state DFAO with
surjective output map. For every fixed k, the article develops a conventional
proof that, for all sufficiently large n,

    M_k(n) = k^n - B_k(a_n,b_n) + T_k(a_n,b_n),

where B_k(a,b) is the number of proper k-colorings of K_(a,b),
T_3(a,b)=b and T_k(a,b)=ab for k>=4 (a<=b), and (a_n,b_n) is the closest
coprime split of n. Its difference is 1 for odd n, 2 for n divisible by four,
and 4 for n congruent to two modulo four.

This proves an eventual fixed-output form of the optimum question posed by
Sylvie Davies (arXiv:1705.07150v2, Section 5, Problem 2), building on the
ProveIt report `dfao-reversal-coloring-obstruction`.

The article also proves strict balancing with a quantitative gap, a necessary
and sufficient eventual extremizer criterion, explicit parity-sensitive
asymptotics, and eventual recurrences and rational generating functions.
Ten proposed further research questions are included.

## Important limitations

- The quantifiers are: for each fixed k, there exists N(k), such that the
  formula holds for all n >= N(k). No explicit N(k) is established.
- The full statement for every n >= 7 and 3 <= k < n is not proved here.
- No conclusion for growing k=k(n) or the diagonal k=n is claimed.
- This is an AI-assisted, unrefereed research draft, not a Lean/Rocq development.
- The published two-generator theorem for U_(a,b) is an explicit imported
  mathematical dependency. The needed projection, counting, and asymptotic
  arguments are proved in the article.
- Literature priority has not been established. A missing search hit is not
  evidence that no earlier or later result exists.

## Package

- `article.pdf`: compiled article.
- `article.tex`: complete source, with embedded bibliography.
- `code/verify.py`: exact-integer producer plus regression checks.
- `code/check_certificates.py`: independent finite certificate checker.
- `results/finite_certificates.csv`: all 919 finite equality certificates.
- `results/verification_summary.json`: 42,960 producer checks, no failures.
- `results/independent_check.json`: 919 accepted rows, no rejected rows.
- `results/bfs_witnesses.json`: eight explicitly enumerated automata, totaling
  605,713 visited coloring states.
- `results/recurrences.json`: exact recurrence coefficients for k=3,...,10.
- `results/asymptotic_ratios.csv`: illustrative floating-point ratios only.
- `SOURCE_AUDIT.md`: source anchors, imported statements, novelty boundaries.
- `Makefile`: build and verification commands.

## Reproduction

Python 3.10 or later; standard library only. The recorded run used Python
3.13.5. From the package directory:

    python code/verify.py
    python code/check_certificates.py

Both programs fail explicitly if a check fails. The independent checker
imports no producer code. It uses inclusion-exclusion rather than Stirling
recurrence, dynamic programming rather than the closed residual-order
bound, and direct coprime-split enumeration rather than residue cases.

The certified region is exactly

    7 <= n <= 100,  3 <= k <= min(12,n-1).

These are exhaustive checks of a universal graph-parameter bound, NOT
exhaustive enumerations of all automata. The proof of the certificate
principle is in the article. The finite checks do not prove the infinite tail;
the tail has a separate proof. Likewise an unspecified tail plus this finite
region does not by itself cover any possible intervening gap.

Compile with a TeX distribution providing the packages listed in the source:

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

Alternatively, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times. No BibTeX, external font files, or downloaded reference papers are
required. `make verify`, `make pdf`, and `make clean` are also provided.

## Review priorities

The most useful independent checks are the strict balancing proof, the
one-isolated-vertex inequality for odd k, and the use of the imported
U_(a,b) generation theorem. A complete dependency ledger and ten further
questions are in the article. No uploaded repository files were modified.
