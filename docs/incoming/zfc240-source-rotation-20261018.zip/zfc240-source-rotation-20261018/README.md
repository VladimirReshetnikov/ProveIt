# A 240-state Turing machine for ZFC consistency

The requested strict improvement is achieved: **240 working states**, including blank-tape initialization, with two tape symbols and one separate halt state. The ordinary proof gives

\[
\mathrm{ZFC}\vdash\bigl(\neg\operatorname{Halt}(M_{240},\mathrm{blank})\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr),
\]
using the pinned predecessor's logical calibration and proof predicate. The new source and binary equivalence arguments are supplied in full. A new complete Lean/Rocq endpoint and PA internalization are not supplied.

## Exact machine

- `machines/zfc240.tm`: canonical, headerless 480-row table. Working states 0–239; start 0; dispatcher 84; halt 240.
- `machines/zfc240_old.tm`: identical machine in inherited labels. Start 95; dispatcher 96; halt 254.
- `machines/renumbering.json`: exact bijection, including halt.
- Each row is `state read write direction next_state`, with `L` or `R` direction.
- Start with head 0 on an all-zero, two-way infinite binary tape. Initialization is included. Every transition moves.

Canonical SHA-256:

```text
508b55a6dfdf96a42f09c49e410e078ae7478a1d0257d78d25503b4da24541cd
```

Inherited-table SHA-256:

```text
547dd69da66f66dd48238a53d34b52a3ce85bb6c7d01534dd1cfb815507f248f
```

## The entire construction from the pinned 241-state table

The base is `BusyBeaver_241_Companion_2026-10-18.zip`, added in ProveIt commit `8c41b1fb7d7bb8cd0612e37848181fe4a2f5d569`. Its exact archive is retained under `reference/`.

Delete inherited state **90** and replace these five retained rows:

| Row | Old | New |
|---|---|---|
| 142/0 | `0 R 37` | `0 R 72` |
| 142/1 | `1 R 72` | `1 R 17` |
| 72/0 | `0 R 57` | `0 L 144` |
| 72/1 | `0 R 64` | `1 L 36` |
| 79/1 | `1 R 90` | `1 R 72` |

All **475 other retained rows are unchanged**. There are no additional states or input symbols.

The first two changes rotate all four occurrences of a transfer-plus-one source macro. Both versions map `(R5,R6)=(a,b)` to `(a+b+1,0)` in exactly `3b+2` source instructions, preserving every other register. The static source becomes 6,455 leaves and 8,386 guarded cases. The complete source-graph proof checks every outside guarded edge and excludes entry into the macro interiors.

The rotation strengthens a binary invariant: state 72 always has `10` in the two cells immediately to its left, while state 90 has a left 1. Both roles can therefore use state 72, with the old control distinction recovered from existing tape bits. The four exceptional comparisons use 9, 3, 3 and 3 new steps. Every other old step uses one new step. The proof applies from inherited start 95 to every complete binary tape and integer head, including tapes of infinite support. This local theorem is from the rotated intermediate machine; the preceding rotation has its separate source-level proof.

## Verified results

| Check | Result |
|---|---:|
| Working states / binary rows | 240 / 480 |
| Local invariant implications | 7,640 |
| Positive whole-tape blocks | 7,640 |
| Outside source guarded edges | 8,370 |
| Transformed macros | 4 |
| Final complete runtime guards | 8,386 / 8,386 |
| Symbolic rules in final replay | 2,322,575 |
| Final rows exercised | 480 / 480 |
| Minimum certified instruction duration | 13 |
| Exact final blank prefix | 409,691 transitions |

The initialized frame has inherited dispatcher 96, head −5, marker −6, header 176, logical registers `(3,0,0,0,3,0,0,0,0)`, and 167 spare blocks of value 1. Its complete tape has 351 one-cells and zero elsewhere. Independent sparse and dense implementations compare the entire tape. The rotated 241-state prefix takes 408,941 transitions; the fold adds exactly 750 according to its proved clock formula.

The final symbolic runtime covers arbitrary natural register values and gap, an arbitrary first spare value, and an arbitrary finite remaining spare list. Its loop rules are justified by natural and list induction. The construction-fuel limit is not a limit on these mathematical values. Per-case output is retained in `evidence/runtime240_cases.json`.

## Reproduce from a clean extraction

Use Python 3.10 or later with assertions enabled:

```bash
python3 -B verify_all.py
```

This checks manifest identities, regenerates the construction, reruns independent source/local/boot checks and the theory tool, runs the prior 241 archive's quick dependency checks in a temporary extraction, and performs a fresh full final 8,386-case symbolic replay. It compares the full per-case data with the sealed outputs. The final status is `FULL_FRESH_ZFC240_REPLAY_PASS`. No network request or nonstandard Python package is needed.

For a quicker integration check:

```bash
python3 -B verify_all.py --quick
```

This skips only the fresh final universal replay and returns the distinct `QUICK_ZFC240_REPLAY_PASS` status. Historical 241/242/243 full receipts remain explicitly inherited, not relabeled as fresh executions. Verification runs on temporary copies and does not overwrite the sealed evidence. `--output` selects the final receipt path; its default is outside the package directory.

The full new report is `report/zfc240.pdf`; all LaTeX sources are included. Rebuild with:

```bash
cd report
pdflatex -no-shell-escape -interaction=nonstopmode zfc240.tex
pdflatex -no-shell-escape -interaction=nonstopmode zfc240.tex
```

## Alternative-formalism result

The report also proves that interpreting membership as strict order on the nonnegative rationals models CP and every weak-Collection instance, even with Extensionality, Empty Set, Union, ordinary Foundation, irreflexivity and transitive membership. Full GIC fails already for the formula requiring an empty output. Thus merely deleting its support condition loses the required internal consistency calibration.

`theory/dense_order_filter.py` evaluates first-order formulas exactly on this infinite structure by using finite automorphism orbits at each quantifier. It is a reusable rejection tool for proposed smaller axiom packets, not a finite-domain approximation. The separate uniform automorphism proof establishes the entire Collection schema. The report also proves the calibrated presentation `GIC = weak Collection + Separation`; no binary state improvement is claimed for that presentation.

## Package layout and proof boundary

| Directory or file | Purpose |
|---|---|
| `machines/` | Exact final machine, source list and renumbering |
| `reference/` | Pinned predecessor, intermediate table, original symbolic engine and full 241 companion ZIP |
| `verification/` | New independent proofs and the narrowly adapted runtime engine |
| `evidence/` | Actual local, source, boot, runtime and theory receipts |
| `report/` | Complete 19-page report, editable TeX and section files |
| `theory/` | Exact infinite-model tool |
| `search/` | Selected reproducible finite search families and negative results |
| `build.py` | Checks exact regeneration from the baseline |
| `verify_all.py` | Clean, full reproduction driver |
| `MANIFEST.json` | File sizes and SHA-256 identities |
| `PROVENANCE.json`, `ATTRIBUTION.md`, `licenses/` | Source pins, exact edits, credits and unchanged inherited terms |

The ordinary source-theory calibration is inherited from the exact 241/242/243 chain and original SIR/ZFC development. The new source rotation and local fold are fully proved as ordinary mathematics with executable certificates. This package does not claim to have compiled a new end-to-end Lean/Rocq theorem, established absolute consistency, proved unconditional nonhalting, proved global minimality, or obtained two-sided independence from mere consistency.
