# Rational Gram Packing, Four-Dimensional Quantum Mortality, and Diophantine Certificates

Research manuscript and reproducible artifacts, 30 September 2026.
Prepared for Vladimir Reshetnikov in response to the ProveIt research request.

## Start here

Read `article.pdf` (22 pages); `article.tex` is its complete, self-contained
LaTeX source, including the bibliography. The central construction is Theorem
4.1; the four-dimensional, seven-outcome result is Theorem 6.2; the explicit
quartic compiler is Theorem 9.1.

The manuscript develops a rational normalization of matrix-mortality instances
that distributes correction rows among the active Kraus operators. It preserves
mortality without restricting the allowable outcome words. A shortest nonempty
zero-product word grows in length by at most one. A classical rational
quadratic-form argument gives a dimension bound

    D = d + ceil((d + 3) / k),   outcomes = k + 1.

Together with Neary's published six-generator, 3-by-3 matrix-mortality theorem,
this gives undecidability for seven rational outcomes in dimension four. An
explicit four-square alternative gives dimension five with seven outcomes.

For fixed word length n, the manuscript specifies a quartic integer polynomial
whose natural solutions correspond bijectively to the impossible words. For
D=4 and K=7, the polynomial has 71n+32 natural witnesses and is a sum of squares
of 72n+48 quadratic-or-lower residuals. The input matrix coordinates are not
included in the witness count. The separate fixed-arity, unbounded
representation uses MRDP and does not claim to preserve witness uniqueness.

## Contents

- `article.tex`, `article.pdf`: manuscript, proofs, ten proposed research
  directions, source references, and a formalization plan.
- `code/quantum_diophantine.py`: exact matrix arithmetic, rational Gram
  constructions, packed instrument construction, a sparse polynomial class,
  and the bounded-history certificate compiler.
- `code/run_checks.py`: deterministic exact-arithmetic checks and regeneration
  of the example files and check report.
- `examples/four_dimensional_instrument.json`: an explicit four-dimensional,
  seven-outcome rational instrument, stored as integer numerator matrices
  with common denominator 15.
- `examples/quartic_D2_K2_n2.json`: a fully expanded sample quartic with 647
  monomials, 44 existential coordinates, and 50 residuals before expansion.
- `examples/zero_word_witness.json`: a complete canonical assignment for the
  length-three zero word (2,1,1) in the four-dimensional example, including
  its fixed matrix-input coordinates.
- `verification/check_results.json`: the executed check report.
- `verification/STATUS.md`: what has and has not been verified.
- `Makefile`: optional convenience targets for PDF construction and tests.

## Reproduce the checks

Python 3.10 or later is required. Only the standard library is used. From this
directory run:

```sh
python code/run_checks.py
```

The program overwrites the three generated example JSON files and
`verification/check_results.json`. The delivered run passed 32,418 individual
checks. This number counts assertions, not statistically independent trials.
The random seed is fixed at 20260930. Runtime is machine-dependent and the
runtime field will change between executions.

The suite tests exact normalization, block-product identities, idle-letter
erasure, the one-step extension, probabilities, elementary and searched Gram
factors, polynomial degree and evaluation, and rejection of single-coordinate
mutations of canonical witnesses. It does not turn finite examples into a
proof of an unbounded theorem.

Do not run with Python's `-O` switch: some internal consistency checks use
`assert`. Use integers or `fractions.Fraction` for exact input data. There are
no floating-point tolerances in the mathematics or the test suite.

## Small API example

From the package root:

```python
import sys
from fractions import Fraction
sys.path.insert(0, "code")
from quantum_diophantine import (
    signed_example, build_certificate, canonical_assignment
)

instrument = signed_example()
assert instrument.dimension == 4
assert len(instrument.kraus) == 7
assert instrument.probability((2, 1)) == Fraction(64, 50625)
assert instrument.probability((2, 1, 1)) == 0

N, H = instrument.integer_numerators()
assert N == 15
certificate = build_certificate(d=4, k=7, n=3)
assignment = canonical_assignment(H, (2, 1, 1))
assert len(certificate.witnesses) == 245
assert len(certificate.residuals) == 264
assert certificate.value(assignment) == 0
```

Words are chronological: `(i, j)` denotes the matrix product `A[j] @ A[i]`.
Instrument label 0 is the idle outcome; labels 1 through k correspond to the
original matrices with Python indices 0 through k-1. Generic certificate words
use zero-based matrix labels, so the instrument's labels can be passed directly
to a certificate compiled from its complete numerator list.

`compile_instrument` uses the elementary 4d-row Gram factor by default. To
obtain the d+3-row bound, provide a suitable exact factor, or use `gram_search`
on the residual form and provide its result. The search is deliberately not
advertised as a practical general-purpose number-theory algorithm. A finite
`max_height` cap raises `TimeoutError` when exhausted; this is not evidence
that the factor does not exist. Without a cap, the search is total for a
positive definite d-dimensional rational form and at least d+3 rows, by the
classical theorem used in the manuscript.

The certificate is stored as a list of residual polynomials. Calling
`certificate.expanded()` forms the actual single sum-of-squares polynomial.
Expansion can be large; the full four-dimensional example is checked in
residual form, while the smaller example is expanded and serialized.

## Build the PDF

A standard TeX installation with pdfLaTeX, latexmk, AMS packages, newtx,
geometry, microtype, mathtools, booktabs, array, longtable, enumitem, xcolor,
fancyhdr, listings, hyperref, and bookmark is sufficient.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `pdflatex` repeatedly until cross-references and the table
of contents settle. Bibliography entries are included in the source; neither
BibTeX nor an external `.bib` file is needed. No network access is required.

## Relation to ProveIt and scope of the claims

The inspected ProveIt snapshot is
`f608f1cb3c5be8a736df1328c01b293aabfccf4e`.
The repository's MRDP guide and Diophantine trace module provide the conceptual
integration points. This package does not modify the repository, import it at
runtime, or claim that the new construction has already been formalized there.

The article provides full mathematical proofs of the packing and certificate
theorems, while explicitly importing Meyer's theorem, Lagrange's theorem,
Neary's mortality hardness result, and MRDP. No independent peer review,
exhaustive novelty search, Lean verification, globally optimal resource bound,
general finite-fold MRDP theorem, or physically noise-robust solution to an
unbounded undecidable problem is claimed. The new resource refinement and
witness-preserving construction are presented for independent mathematical
review.
