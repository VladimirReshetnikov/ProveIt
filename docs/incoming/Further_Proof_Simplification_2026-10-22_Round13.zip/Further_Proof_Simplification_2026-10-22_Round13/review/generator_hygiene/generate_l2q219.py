#!/usr/bin/env python3
"""Fork the dag222 program layer (Dag222, L2Lib222 ... L2Root222) for dag219.

  python generate_l2q219.py      (from Computability/BusyBeaver/Lean)

dag219 (make_dag219.py) is dag222 with the equality test (node 123) replaced by Source 140's
routine on the appended nodes 461-466. Every other node keeps its number and its content, so
every program-level proof about dag222 rechecks on dag219 after the textual substitution
dag222 -> dag219, namespace L2K -> L2Q. The only proofs that change are those of the equality
test itself: `loop124`, `ifeq_eq` and `ifeq_ne` (about the old routine's nodes 123-129) are
replaced by proofs about the new routine with the same two statements.

The endpoints of the 219 and the 218 do not use the fork: `Dag219Equiv` relates `dag219` to
`dag222` directly. The forked modules remain as the source contracts cited by
`k217-protected-tail-seed`. `Dag219.lean` itself is written by hand, as `dag222` patched at the
routine's seven nodes.
"""
import subprocess, sys
from pathlib import Path

D = Path("BusyBeaver/ZFC")
HERE = Path(__file__).resolve().parent

SUBS = [
    ("import BusyBeaver.ZFC.Dag222", "import BusyBeaver.ZFC.Dag219"),
    ("import BusyBeaver.ZFC.L2Lib222", "import BusyBeaver.ZFC.L2Lib219"),
    ("import BusyBeaver.ZFC.L2Macros222", "import BusyBeaver.ZFC.L2Macros219"),
    ("import BusyBeaver.ZFC.L2Control222", "import BusyBeaver.ZFC.L2Control219"),
    ("import BusyBeaver.ZFC.L2Axioms222", "import BusyBeaver.ZFC.L2Axioms219"),
    ("namespace SetTheory.BusyBeaver.ZFC.L2K\n", "namespace SetTheory.BusyBeaver.ZFC.L2Q\n"),
    ("end SetTheory.BusyBeaver.ZFC.L2K\n", "end SetTheory.BusyBeaver.ZFC.L2Q\n"),
    ("Dag222", "Dag219"),
    ("dag222", "dag219"),
]

NEW_EQ = '''/-! ## The equality test: Source 140's routine (nodes 123, 461-466)

`P = (D6, C2)` (461), `U = (P, B)` (462), `A = (D5, U)` (463), `L = (A, D6)` (464),
`Z = (D5, C1)` (465), `R = (Z, U)` (466), `E = (L, R)` (123); `D6` decrements `s1` and `D5`
decrements `p2`. `A` cancels the two counters, `L` breaks exactly on equality, `R` clears both
and breaks; so `E` returns normally iff `s1 = p2`, and leaves both zero. -/

theorem run_eq' {e : Edge} {s s1 s2 : AS} {x : Exit} (h : Run dag219 e (enc s) x (enc s1))
    (he : s1 = s2) : Run dag219 e (enc s) x (enc s2) := he ▸ h

theorem eqP_pos (st : AS) (b : Nat) (h : st.s1 = b + 1) :
    Run dag219 (.node 461) (enc st) (.cont 1) (enc { st with s1 := b }) := by
  have hdec := Run.decPos (p := dag219) 6 (enc st) b (by simp [enc, h])
  rw [upd_s1] at hdec
  exact cont_cdr (p := dag219) (n := 461) (k := 0) rfl hdec (Run.contS 1 _)

theorem eqP_zero (st : AS) (h : st.s1 = 0) :
    Run dag219 (.node 461) (enc st) .normal (enc st) :=
  skip (p := dag219) (n := 461) rfl (Run.decZero 6 (enc st) (by simp [enc, h]))

theorem eqU_pos (st : AS) (b : Nat) (h : st.s1 = b + 1) :
    Run dag219 (.node 462) (enc st) (.cont 1) (enc { st with s1 := b }) :=
  Run.carCont 462 0 _ _ (by exact eqP_pos st b h)

theorem eqU_zero (st : AS) (h : st.s1 = 0) :
    Run dag219 (.node 462) (enc st) (.brk 1) (enc st) :=
  brk_cdr (p := dag219) (n := 462) (k := 0) rfl (eqP_zero st h) (Run.brkS 0 _)

/-- The cancellation loop `A`. -/
theorem eqA : ∀ (a : Nat) (st : AS), st.p2 = a →
    (a ≤ st.s1 → Run dag219 (.node 463) (enc st) .normal (enc { st with p2 := 0, s1 := st.s1 - a })) ∧
    (st.s1 < a → Run dag219 (.node 463) (enc st) (.brk 1) (enc { st with p2 := a - st.s1 - 1, s1 := 0 }))
  | 0, st, ha => by
      refine ⟨fun _ => ?_, fun h => absurd h (Nat.not_lt_zero _)⟩
      have h := skip (p := dag219) (n := 463) rfl (Run.decZero 5 (enc st) (by simp [enc, ha]))
      apply run_eq' h
      cases st; simp only at ha; subst ha; simp
  | a + 1, st, ha => by
      have hdec := Run.decPos (p := dag219) 5 (enc st) a (by simp [enc, ha])
      rw [upd_p2] at hdec
      rcases Nat.eq_zero_or_pos st.s1 with hs | hs
      · refine ⟨fun h => by omega, fun _ => ?_⟩
        have hU := eqU_zero { st with p2 := a } (by simpa using hs)
        have := brk_cdr (p := dag219) (n := 463) (k := 0) rfl hdec hU
        apply run_eq' this
        cases st; simp only at ha hs; subst ha; subst hs; simp
      · obtain ⟨b, hb⟩ : ∃ b, st.s1 = b + 1 := ⟨st.s1 - 1, by omega⟩
        have hU := eqU_pos { st with p2 := a } b (by simpa using hb)
        obtain ⟨ih1, ih2⟩ := eqA a { { st with p2 := a } with s1 := b } rfl
        refine ⟨fun h => ?_, fun h => ?_⟩
        · have := restart (p := dag219) (n := 463) rfl hdec hU (ih1 (show a ≤ b by omega))
          apply run_eq' this
          cases st; dsimp only at ha hb ⊢; subst ha; subst hb; congr 1 <;> omega
        · have := restart (p := dag219) (n := 463) rfl hdec hU (ih2 (show b < a by omega))
          apply run_eq' this
          cases st; dsimp only at ha hb ⊢; subst ha; subst hb; congr 1 <;> omega

theorem eqL_eq (st : AS) (h : st.s1 = st.p2) :
    Run dag219 (.node 464) (enc st) (.brk 1) (enc { st with p2 := 0, s1 := 0 }) := by
  have hA := (eqA st.p2 st rfl).1 (by omega)
  have hz : enc { st with p2 := 0, s1 := st.s1 - st.p2 } 6 = 0 := by simp [enc, h]
  have := brk_cdr (p := dag219) (n := 464) (k := 0) rfl hA (Run.decZero 6 _ hz)
  apply run_eq' this
  cases st; simp only at h; subst h; simp

theorem eqL_ne (st : AS) (h : st.s1 ≠ st.p2) :
    ∃ x y, Run dag219 (.node 464) (enc st) .normal (enc { st with p2 := x, s1 := y }) := by
  rcases Nat.lt_or_gt_of_ne h with h' | h'
  · exact ⟨_, _, skip (p := dag219) (n := 464) rfl ((eqA st.p2 st rfl).2 h')⟩
  · obtain ⟨c, hc⟩ : ∃ c, st.s1 - st.p2 = c + 1 := ⟨st.s1 - st.p2 - 1, by omega⟩
    have hA := (eqA st.p2 st rfl).1 (by omega)
    have hdec := Run.decPos (p := dag219) 6 (enc { st with p2 := 0, s1 := st.s1 - st.p2 }) c
      (by simp [enc, hc])
    rw [upd_s1] at hdec
    exact ⟨0, c, run_eq' (seq (p := dag219) (n := 464) rfl hA hdec) (by cases st; rfl)⟩

/-- `Z` clears `p2`. -/
theorem eqZ : ∀ (a : Nat) (st : AS), st.p2 = a →
    Run dag219 (.node 465) (enc st) .normal (enc { st with p2 := 0 })
  | 0, st, ha => by
      have h := skip (p := dag219) (n := 465) rfl (Run.decZero 5 (enc st) (by simp [enc, ha]))
      apply run_eq' h
      cases st; simp only at ha; subst ha; rfl
  | a + 1, st, ha => by
      have hdec := Run.decPos (p := dag219) 5 (enc st) a (by simp [enc, ha])
      rw [upd_p2] at hdec
      have := restart (p := dag219) (n := 465) rfl hdec (Run.contS 0 _) (eqZ a { st with p2 := a } rfl)
      apply run_eq' this
      cases st; rfl

/-- `R` clears `p2`, then `s1`, and breaks. -/
theorem eqR : ∀ (b : Nat) (st : AS), st.s1 = b →
    Run dag219 (.node 466) (enc st) (.brk 1) (enc { st with p2 := 0, s1 := 0 })
  | 0, st, hb => by
      have hZ := eqZ st.p2 st rfl
      have hU := eqU_zero { st with p2 := 0 } (by simpa using hb)
      have := brk_cdr (p := dag219) (n := 466) (k := 0) rfl hZ hU
      apply run_eq' this
      cases st; simp only at hb; subst hb; rfl
  | b + 1, st, hb => by
      have hZ := eqZ st.p2 st rfl
      have hU := eqU_pos { st with p2 := 0 } b (by simpa using hb)
      have := restart (p := dag219) (n := 466) rfl hZ hU
        (eqR b { { st with p2 := 0 } with s1 := b } rfl)
      apply run_eq' this
      cases st; rfl

/-- The equality test (node 123): normal iff equal, otherwise break one level. -/
theorem ifeq_eq (st : AS) (h : st.s1 = st.p2) :
    Run dag219 (.node 123) (enc st) .normal (enc { st with s1 := 0, p2 := 0 }) := by
  have := skip (p := dag219) (n := 123) rfl (eqL_eq st h)
  apply run_eq' this
  cases st; rfl

theorem ifeq_ne (st : AS) (h : st.s1 ≠ st.p2) :
    Run dag219 (.node 123) (enc st) (.brk 1) (enc { st with s1 := 0, p2 := 0 }) := by
  obtain ⟨x, y, hL⟩ := eqL_ne st h
  have hR := eqR y { st with p2 := x, s1 := y } rfl
  have := brk_cdr (p := dag219) (n := 123) (k := 0) rfl hL hR
  apply run_eq' this
  cases st; rfl

'''

for name in ["L2Lib", "L2Macros", "L2Control", "L2Axioms", "L2Root"]:
    t = (D / f"{name}222.lean").read_text(encoding="utf-8")
    if t.startswith("/- Forked"):
        t = t[t.index("\n") + 1:]
    for a, b in SUBS:
        t = t.replace(a, b)
    if name == "L2Control":
        i = t.index("/-- The joint decrement loop (node 124). -/")
        j = t.index("/-! ## Uses of the equality test -/")
        t = t[:i] + NEW_EQ + t[j:]
        assert "node 124" not in t and "loop124" not in t
    for bad in ["dag222", "Dag222", "L2Lib222", "L2Macros222", "L2Control222", "L2Axioms222", "ZFC.L2K"]:
        assert bad not in t, (name, bad)
    head = (f"/- Forked by Research/ZFC/k225-formal/generate_l2q219.py from {name}222.lean for dag219 "
            "(dag222 with Source 140's equality test); do not edit. -/\n")
    if t.startswith("/- Forked"):
        t = t[t.index("\n") + 1:]
    (D / f"{name}219.lean").write_text(head + t, encoding="utf-8", newline="\n")
    print("wrote", f"{name}219.lean")
