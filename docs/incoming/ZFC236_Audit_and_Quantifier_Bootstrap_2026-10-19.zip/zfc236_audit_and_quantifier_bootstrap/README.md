# A 236-state audit and new compact consistency encodings

**The package contains a fully specified 236-working-state machine and a fresh audit of its mathematical calibration.** That machine was published in ProveIt commit `0b5fec6980cc3a5ba7dd47b404f0cbbe9a451c02` during this investigation. Its construction is credited to that incoming report. This supplement independently checks it, combines the latest equational reductions into **E667**, and supplies new logical-basis proofs and reproducible source experiments. It does not claim a 235-state machine.

Read **report.pdf** for the complete account. **report.tex** and its included sections rebuild that PDF.

## What is established

- **236-state audit:** exact source reassociation, literal table construction, 409,835-step blank initialization, a separate four-case whole-tape fold proof, and fresh unbounded symbolic runtime over all 8,386 guarded source cases. The final table uses all 472 rows and takes 2,267,815 symbolic proof rules to validate. The fresh full case array matches the incoming array exactly.
- **E667:** the optimized 692-bit equational packet still forces its designated constant to be Boolean truth without its explicit truth equation. Deleting that six-node equation and its marker saves 25 bits. The resulting seven-equation, nine-symbol packet has exactly the same models and ground-query consequences as E692, with its inherited ZFC calibration.
- **K/S plus quantified idempotence:** retaining the other numerical-calculus rows and the actual gated CP/GIC bundle, the schema `Q_i A -> Q_i Q_i A` suffices to recover double-negation elimination for every numerical code, including the exceptional code 0. K/S plus global DNE gives exact equality with the old numerical theorem calculus. Twelve finite Hilbert certificates contain 2,015 checked proof nodes.
- **Exact source costs:** across 288 variants each, the best K/S/Peirce source has 226 shared nodes; K/S/Q4, K/S/quantified-DNE and K/S/DNE each have 227, against the original 224. Combining their saved best forms with the six-leaf NIP specialization does not improve those figures. These are source costs, not binary state estimates.
- **Affine invariants:** a primal affine discovery and separate dual equation checker establish 970 nonconstant pairwise register-offset facts. They transfer to the new 236 source layout because its ordered guarded CFG is unchanged. They have not yet yielded a smaller machine.
- **Search scope:** expanded helper, caller-encoding, and halt-aware classes produce no new table on the original237 baseline. A targeted eight-pair search on the new236 baseline also produces no235 candidate. Receipts explicitly state the finite profiles, horizons and restrictions; no lower bound is claimed.

## Exact machine and theorem boundary

`machines/zfc236.tm` is a deterministic binary single-tape machine, with two-sided blank tape, only L/R moves, working states 0–235, initial state 0, dispatcher 84, and separate halt outcome 236. It has exactly 472 rows.

Canonical SHA-256:

```text
d4302309401891d68b93c393e4ad6e24d2abf993dede4a61baa2d3e0c1c53c8e
```

Inherited-label SHA-256:

```text
ff059535876bc9e1e1e63174ebfd1c10a91c1a818ba0c3f8c4ef2ac51a3cfcc3
```

The ordinary proofs and exact certificates compose with the pinned existing calibration to give

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halts}(M_{236},\mathrm{blank})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

No consistency assumption is needed to state this biconditional. Consistency then implies actual nonhalting. The package does not claim a newly compiled Lean/Rocq endpoint for236 or a completed internal PA proof-code endpoint. It inherits the native SIR/ZFC comparison and the existing240-state external Lean chain.

E667's calibrated property is **nonderivability of `N(d,d) = d`**, not bare consistency of the equational theory: a one-element model always exists. Its 667-bit size includes signature, arities, variable capacity, equations, and ground endpoints under the stated codec. A counted binary interpreter, data writer and initializer remain necessary before deriving a TM state bound from that packet.

## Reproduce

Use Python3.10 or newer, with assertions enabled, and a new output directory:

```sh
python3 -B reproduce.py --output-dir replay
python3 -B reproduce.py --full --output-dir replay-full
```

The quick run checks the manifest, independently replays finite proof certificates, reruns source/macro/control/invariant checks, audits the stored full runtime arrays, and runs the unchanged incoming236 quick suite. The `--full` run additionally reruns both complete symbolic runtime proofs, for the reassociated237 basis and final236 table. All jobs run in an isolated temporary copy; delivered evidence is not overwritten. Python replay is offline and uses the standard library. Optional discovery scripts require a C++17 compiler and can take several minutes; their exact commands are documented separately.

To rebuild the PDF from this directory:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

## Layout

| Directory | Contents |
|---|---|
| `machines/` | Exact236 tables, numbering map, source and construction receipt |
| `equational667/` | New complete packet, codec checker, ground truth recipe and proof |
| `theory/` | K/S/Q4, quantified-DNE, global-DNE and equality-free quotient arguments; finite Hilbert certificates |
| `verification/` | Literal runtime wrapper, inherited engines, independent product and dual affine checkers |
| `evidence/` | Fresh runtime arrays, independent invariant certificates and replay logs |
| `fold236_audit/` | Independent four-case proof and targeted235 search |
| `source236_audit/` | Source rotation/NIP compatibility and rejected binary graft |
| `source237_experiments/` | Portable basis pricing, macro bridge, NIP and affine substitution experiments |
| `fold237_experiments/` | Earlier finite searches, halt-aware corrections and positive controls |
| `code/` | Root affine discovery and neutral-edit search |
| `upstream/` | Unmodified incoming236 ZIP and inherited E692 proof/encoder |
| `baseline/`, `inputs/` | Pinned237/238 source and machine controls |
| `licenses/` | Inherited licenses and attribution notices |

`PROVENANCE.json` records both inspected heads and the exact pins. `SHA256SUMS` covers all delivered files except itself. The original236 ZIP is retained byte-for-byte for offline reproduction; the replay script extracts it safely into a temporary directory. The report includes attribution to Mira-Cult, Jeff Ketchersid, Andrew James Wade, and the preceding ProveIt/incoming contributions. New work follows the ProveIt MIT license; inherited notices are preserved.

For incorporation, add this supplement under a new research directory or retain the ZIP in `docs/incoming`. The supplied236 table is the same upstream construction, so it should not be credited as an independent new state-count discovery.
