# Proof status and overlap map

All status descriptions below concern this delivered manuscript. They do
not mark anything accepted in the canonical repository.

## Prior inputs, not new theorems of this continuation

The complex-order Barnes–Hurwitz family and its height-one generating
interpretation are classical (Young 2024). Positive-integer beta
differentiation and the fixed-shift harmonic Laurent formula are already
in the preserved repository report `twisted-harmonic-laurent`. The
successive Gauss coefficient subtraction theorem, the analytic residue
identity, and the resonant Stieltjes coefficient method are already in
`stieltjes-harmonic-identities`.

## Proved continuation results

- **Theorem 3.2**: elementary finite-polynomial proof of the analytic
  Gauss residue identity. This answers the *separate algebraic proof*
  request, not an unproved analytic residue conjecture.
- **Theorem 4.1**: the entire resonant tail has a finite Stirling formula
  and a hypergeometric exponential generating function. Its proof uses
  the formal Gamma-ratio recurrence and a negative-power/Borel transform.
- **Theorems 6.1 and 6.3; Corollary 6.2**: moving reflection, centered
  common zeros, and uniqueness of the center. Joint holomorphy, not only
  a formal parity observation, is proved by uniform Mellin subtraction.
- **Theorem 7.1**: an exact centered Gamma generating function and its
  explicit every-depth zeta-cumulant expansion. The underlying beta and
  Gamma reflection identities are classical; their centered coefficient
  family is worked out here.
- **Theorem 8.1**: the centered principal and finite Laurent coefficients,
  with an exact transport formula for higher Stieltjes coefficients.
- **Theorem 10.1**: the all-depth common-zero mechanism for any finite
  number of positive unequal frequencies and independent order jets.
- **Theorem 5.1 and Section 9**: a self-contained shifted Beta–Stieltjes
  generating identity, all logarithmic coefficients, and explicit
  antiderivatives. These are proved consequences of classical summation
  and Hurwitz calculus; no claim of worldwide novelty is attached.

All results are ordinary mathematical proofs. No Lean/Isabelle/Coq
formalization, exhaustive literature priority search, or certified
numerical error enclosure is claimed.

## Unresolved and excluded claims

S6 and revised S8 remain unresolved by this work. The full reduction of
higher harmonic Stieltjes coefficients remains unproved. There is no
claim that arbitrary colored higher-depth polylogarithms reduce to depth
one, nor that irrational-frequency Barnes periods are zeta polynomials.

## Audit limitations

The incoming directory contains queued binary archives. Their filenames
and status were inspected, but they were not all downloaded, unpacked,
and independently audited. Novelty is therefore scoped to the inspected
textual sources, not to every queued report or all published literature.
