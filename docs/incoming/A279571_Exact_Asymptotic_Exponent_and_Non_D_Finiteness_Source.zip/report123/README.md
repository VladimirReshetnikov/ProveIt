# Report 123 A279571 exact logarithmic exponent

This reader package contains the standalone mathematical report, its editable
LaTeX source, exact integer data and offline finite checks. The theorem is

    a_n = 9^n n^(-kappa + o(1)),
    kappa = 1 + pi / arccos(2 / sqrt(7)).

It also proves that 1/9 is the generating function's unique singularity on its
convergence circle, that the generating function is not D-finite even over C(z),
and the two-term logarithmic threshold inverse with remainder o(log log y).

It does not prove a leading coefficient equivalent, an amplitude constant,
a correction series, a transseries, a local Delta-domain expansion, or a bounded
inverse error. No fitted asymptotic constants are included. The published
numerical exponent and amplitude estimates are credited to Vaclav Kotesovec
(OEIS, 13 January 2026, after Nicholas R. Beaton) and Britt and Beaton, version 3.

## Read

- `report123.pdf`: standalone proof with exact hypotheses, uniformity and limits
- `report123.tex`: complete editable source; no source papers or figures required
- `checks/README.md`: independent finite-check design and precise finite ranges
- `data/verification_results.json`: exact authoritative checker output
- `data/negative_results.json`: deterministic mathematical/schema mutation results

The rational computations and finite enumerations are independently replayable.
They do not by themselves prove an asymptotic theorem. The free functional and
local limit arguments, annulus estimates, original-time gluing, resolvent
continuation and G-function implication are explained in the mathematical text.

## Quick verification

Python 3.10 or newer is required. The authoritative finite checker uses the
standard library, requires no network and has no installation step. From this
directory run:

    python3 -B integrity.py
    python3 -B checks/verify.py --output ../report123-results.json
    python3 -B checks/negative_tests.py --output ../report123-negative.json
    python3 -B test_integrity.py

Checks remain active under optimized Python (`python3 -B -O`). Both the checks
subtree and the complete package have closed inventories: extra files or
directories, missing files, altered bytes and symbolic links are rejected.
Inventories are integrity records, not cryptographic signatures. They do not
protect against an adversary replacing both a verifier and its inventory.

## Complete immutable replay

    python3 -B reproduce.py --output ../report123-replay.json

This verifies the outer inventory, runs the independent exact checks in normal
and optimized Python, compares their output bytes with the supplied result,
runs the independent mathematical/schema mutation tests and outer inventory
mutation tests, and rebuilds the PDF twice in clean external directories. It
then creates a deterministic ZIP, extracts to a fresh directory, reruns the
checks in both modes, rebuilds the PDF twice, repacks, and requires identical
ZIP bytes. The original package is checked again at the end. All work products
stay outside the reader directory. Without TeX, use:

    python3 -B reproduce.py --skip-pdf --output ../report123-checks-only.json

This retains the exact checks and fresh ZIP replay but explicitly omits PDF
rebuild verification. The result records that omission. A complete replay can
take several minutes.

## PDF build

Requires pdfTeX/pdflatex plus geometry, fontenc, Latin Modern, amsmath, amssymb,
amsthm, mathtools, booktabs, microtype, hyperref and enumitem.

    bash build.sh
    python3 -B build.py --output ../rebuilt-report123.pdf

The default destination is `../build/report123.pdf`. The builder creates a
fresh TeX format in temporary directories and performs three passes in each
of two clean builds. It rejects overfull boxes and unresolved references and
requires byte equality. It never overwrites the delivered source PDF.
Exact PDF bytes are verified for the versions in `build-environment.txt`;
a different TeX distribution may generate equivalent content with other bytes.

## Deterministic packaging

    python3 -B repack.py ../report123_reproducibility.zip

The ZIP contains a single `report123/` directory. Member order, timestamps,
permissions and compression settings are fixed. Compressor versions can affect
compressed bytes, so the zlib version is recorded. No intermediate renders,
logs, downloaded papers, fitted diagnostics or private working material are
part of the reader package.

After an intentional author-side edit, regenerate the outer inventory with
`python3 -B integrity.py --write`. This is not validation of an unexpected
change. Intentional changes inside `checks/` also require its separately
reviewed closed inventory to be updated.
