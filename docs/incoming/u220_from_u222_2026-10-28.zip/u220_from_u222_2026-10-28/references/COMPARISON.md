# Comparison of the supplied U-machine proposals

Reviewed 2026-10-28 against ProveIt commit `340b96f75c64de58948509a12eec78baa9b5663e`. This is a read-only mathematical and source review. No executable from these external packets was run. Literal table counts and SHA-256 identities were computed by an independently written reader; see `TABLE_IDENTITIES.json`.

## Primary baseline: U222

The selected dense table is `U222/u222_consistency_machine/machine/u.tm`, SHA-256 `f3c8492394b2589c47cfe0bb38a3dc6e51e11bfdead7cdec6b07913a4106cb3e`, with 222 working states and 444 transition rows. Its source has 3,891 primitive occurrences, 204 distinct subtrees including leaves, maximum depth 45 and maximum zero run 6. The primary source recipe replaces old primitive interval [2885,4482), not the larger interval used in our U228 replacement.

It already incorporates the strongest emitter-level simplifications in the supplied collection:

* The old selector c itself is both matrix code and output-variable label. There is no extra payload reader, global shift, or increment of the matrix code.
* Source and test variables are fixed to 0 and 1. The subset guard uses c as its local bound variable.
* Exceptional matrix codes 0 and 1 are justified mathematically rather than rejected at runtime. Code 0 asks for a container of all empty objects; code 1 is harmless under irreflexivity.
* Membership vacuity and the weak-cover shell remain bundled as the negation of an implication, under the two original freshness gates. In particular the retained logical family still includes diagonal membership vacuity.
* Exact parenthesization and context-sensitive state allocation matter: its own search ledger rejects an earlier 222-state table with a wrong arithmetic context. The state number alone is not a certificate.

These features explain why directly transplanting our 228-state emitter would be a regression. Our earlier implementation separated membership vacuity, read a new matrix payload, and repeated the gate/cleanup. Its precise ordinary proof and independent runtime checks remain useful validation patterns, but its emitter is not a smaller baseline.

## Other proposals and transferable mechanisms

### U232: PA source on the compact K runtime

Source: `u232_con_u_construction/u232_con_u/report.tex`, especially source-control-flow, register-offset bisimulation, and state-allocation sections. This packet retains the PA proof calculus rather than replacing it by U's weak-cover emitter. It uses a 207-node source DAG (184 internal nodes plus 23 primitive types).

Useful mechanisms:

1. Replace closed helpers by equivalent compact K helpers; verify the complete guarded source graph, not only the ordered primitive word. Its 26 closed replacements are accompanied by a 930-pair product check.
2. Use integer register offsets in a finite product-graph bisimulation. Contract finite increment/jump segments; whenever both sides reach a decrement of r, require offset[r]=0. This permits increments to migrate across a transfer that never tests their register.
3. Its concrete CI5 migration across transfer6-to5 changes four problematic right-child increments to left-child occurrences. Moving the next-candidate increment to the start of the copy block similarly uses a temporary offset in the candidate counter.
4. Select noncanonical primitive entries per source parent and validate every occurrence. A single global entry for all uses can unnecessarily require extra physical helper states.

Transfer status: the method is applicable to U222's source and allocator, but the concrete PA-source node numbers and state patches are not directly portable.

### PA236: opposite-predecessor-tag selector folds

Source: `PA236_Unary_Power_Covering_2026-10-28/PA236_Unary_Power_Covering_2026-10-28/proofs/main.tex`.

Six decoder-DAG reassociations expose two contextual state folds. The general pattern is particularly relevant to U222: two states share one transition; their entries write opposite predecessor bits. On the differing transition, move left into an existing selector, branch on the predecessor tag, and return right through existing states that perform the original action. This replaces a one-step branch with a three-step stuttering segment and saves a state without adding a helper.

The PA-native examples are state pair 200/208 on branch 0 using helper230, and pair222/180 on branch1 using helper203. These labels belong to PA238 and must not be mistaken for U222 labels. Each fold needs a universal incoming-context invariant, positive-duration nonhalting segments and exact reflection, not just a bounded blank run.

An important negative example is supplied: the first rotation alone raises a source zero run from6 to7 and fails an instruction simulation. A second rotation restores the delimiter invariant. Thus complete source-CFG preservation alone does not establish literal correctness.

### U237_ConU: startup/runtime role reuse

Source: `U237_ConU_2026-10-28/u237/report.tex`. Starting from PA238, delete oldstate1 and use oldstate3 as the new initializer and a contextual selector. Changes are old(0,0)->1L4, (3,0)->1L0, (3,1)->1R60, (45,1)->0R3. The start becomes oldstate3.

Transfer status: reuse an initialization-only read branch for a runtime role whose invariant always reads the opposite bit. The concrete tape layout and direction differ from the K runtime, so the exact patch is not reusable without a new local invariant and blank proof.

### u237_research_package: a distinct initializer reuse

Source: `u237_research_package/u237/sections/runtime_patch.tex`. This is not the preceding U237 table. It deletes PA-oldstate1 but uses a different four-row patch: old(0,0)->1L4, (119,0)->0R3, (3,0)->1L9, (3,1)->0L2; startold3.

Its local proof makes the transfer pattern explicit: zero-decrement and selector paths are replaced by complete equal tape/head transformations under short local bit guards, with arbitrary unread surrounding tape. The changed initializer branch is unreachable under the runtime invariant. Its bootstrap gives a gap36 rather than the baseline38, so the runtime proof explicitly widens its applicability; simply reusing a minimum-gap38 theorem would be wrong.

### u237_construction: destructive-equality helper factoring

Source: `u237_construction/u237_construction/report.tex`, exact-patch and sharing sections. It replaces the PA destructive equality helper, saving oldstate151. Two source clearing nodes already share state153; a new helper puts both uses of a decrement/continue node on the left, allowing further sharing. It adapts continuation suffixes11 and101 through existing states0 and21, rather than assuming one suffix-specific return works everywhere. Eight rows change and one state is deleted.

Transfer status: search U222's own repeated comparison/cleanup helpers for equivalent source orderings with more favorable left/right contexts. PA's equality-calculus source helper is not necessarily present verbatim in U222, so verify any proposed analogue rather than applying its state labels.

## Ranked research directions beyond the baseline

1. Closed rotations that expose the PA236 predecessor-tag selector pattern. Preserve both guarded CFG and delimiter constraints, then verify every primitive and blank startup.
2. Register-offset helper transformations and per-parent entry choices, especially right-child increments and continuations that force extra context adapters.
3. Initialization branch reuse, with an explicit invariant distinguishing startup from arbitrary source runtime frames. No row may be deleted because a finite trace did not visit it.
4. Shared arithmetic for the three repeated native membership constructors. If q=2n(n+1), then R(n,0)=q+1, R(n,1)=q+4n+9, and R(1,n)=q+8n+5. These identities suggest replacing repeated generic pair computations by one quadratic and affine transfers. This is an exploratory source idea, not a smaller verified table: extra scratch-register and decoder costs may exceed any saving. The original n must remain available for its gate and output binder.

The logical changes already achieved in U222 should be retained unless a new proof justifies a different family. In particular, do not remove full membership vacuity, identify source/test labels, or silently reinterpret code0/1. A lower count, an unchanged primitive word, or a successful finite blank run is insufficient by itself.
