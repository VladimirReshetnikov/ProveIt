# Exact 222-to-221 state reduction

The parent is U222's native table, SHA256 `88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427`. Native state labels are not dense. The proposed quotient identifies native state200 with112, leaves every other state fixed, redirects all targets accordingly, and deletes200. Its native SHA256 is `5b6ec891b5fa573123a8dbdcf479a30d744d8539dc0a16d11c1c5871fd84657c`; the dense221-state table has SHA256 `c23c796f9275fd407e29c32d59293e077d00700ecc77114914a90ad4ecf702ba`.

## A syntactic marker invariant

In the parent table, the only incoming edge to state112 is

    172 0 0 L 112.

The only incoming edge to state200 is

    112 1 1 R 200.

Consequently every entry into200 on a run starting in a state other than112 or200 occurs by the following two steps: state172 reads and writes0 at positionh, moves left into112; state112 reads1, preserves it, and moves right into200 at positionh. Thus200 always scans the zero just written by172. This conclusion holds for arbitrary initial tapes, not just a bounded set of blank-tape traces. State0 and dispatcher84 are outside the two excluded initial states.

The read-zero transitions coincide:

    112 0 0 R 157
    200 0 0 R 157.

The parent's200/read1 transition is never executed on the runs under consideration. Every other parent transition commutes exactly with the state map pi(200)=112, pi(q)=q otherwise. In the quotient the112/read1 edge becomes1R112; it returns to the known zero and immediately uses112/read0. No extra step is introduced or removed.

## Exact simulation theorem

Induct on finite time. At time0 both machines have the same tape and head, and their states agree under pi. The marker invariant excludes the only noncommuting parent row. Hence each step writes the same bit, makes the same move, and preserves the mapped-state relation. The halting state254 is a singleton fiber of pi. Therefore for every initial tape in state0, the two machines halt at exactly the same time, or both do not halt. The same theorem holds for every common initial state except112 and200.

The proof is a finite transition-table argument and ordinary induction, hence is provable in PA using any standard finite tape/trace coding. Composing it with the parent U222 calibration proves the same Con(U) endpoint for U221. It does not need a new source calibration, a claim of unbounded nonhalting from simulation, or a global minimality assertion.

## Independent verification

`check_u221.py` independently checks the unique incoming edges, exact two marker steps, identical readzero rows, all443 nonexceptional parent rows, completeness and state counts, and singletonhalt fiber. A separate width5 finite-window inductive closure, initially containing every5-bit window at state0, has3082 windows and excludes200/read1. Its transitions allow both possibilities for the newly exposed exterior bit, so it overapproximates all tapes. The closure provides a second proof of the unreachable row rather than a finite run experiment.

`window_quotient.py` is an independent constructor and width9 closure search. The resulting maps and literal tables are included. Dense relabeling is bijective, with start0 and halt221.
