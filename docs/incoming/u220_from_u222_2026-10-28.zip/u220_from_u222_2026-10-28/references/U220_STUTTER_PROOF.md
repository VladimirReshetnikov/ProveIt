# Independent direct 222-to-220 stuttering proof

## Exact tables

Parent: U222 native table, SHA-256 `88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427`.

Child: 220-state native table, SHA-256 `8d68adfc1090439d510de72624d625a7337e022b02c94a77df704ebe6dc03673`.

Both use start0 and halt254. The child removes parent states200 and503. Its state112 rows are `0 L 195` and `1 R 174`, with target503 redirected to112. All remaining rows are unchanged. The state labels are sparse; actual working-state counts are222 and220, not their largest labels.

The map on parent *cutpoint* states is pi(503)=112 and pi(q)=q otherwise. State200 is excluded from cutpoints. The only incoming edge to200 in the parent is112/read1; its use is covered inside the checked matching blocks. There is no target200 in the child. The initial state0 and halting state254 are cutpoints, and the halting state has a singleton fiber.

## Finite inductive invariant, not bounded simulation

For each parent state q, record an eleven-bit window around the current head, at offsets -5 through5. Start with all2048 windows at state0. Close under each exact parent transition, allowing either bit for the newly exposed exterior cell whenever the window shifts. The resulting finite set has86387 state-window pairs, including64 halt-state windows and64 state200 windows.

This closure is an invariant for runs from state0 on every initial binary tape. Proof is induction on steps. The initial window belongs by construction. A transition changes exactly its scanned bit and shifts the window one cell; the actual newly exposed bit is one of the two admitted choices. No assumption is made about unobserved tape cells or the run's length. Correlations discarded at the boundary only enlarge the set, never invalidate coverage.

For the PA endpoint, only finite-support tapes and the blank tape are needed. The finite set is an explicit decidable predicate, and its closure is a finite table calculation. PA proves the corresponding step induction.

## Matching blocks

At a cutpoint, the machines have identical full tapes and head coordinates, with states related by pi, and the parent window belongs to the invariant. There are86259 nonhalting cutpoint windows after excluding state200 and halt254.

For86131 windows, the transitions commute immediately under pi, so use one step in each machine. For the remaining128 windows, the independent checker supplies the following positive block lengths:

- 32 windows: parent1 step, child3 steps;
- 32 windows: parent3 steps, child3 steps;
- 64 windows: parent5 steps, child3 steps.

Every read and write of each block lies inside the initially known eleven-cell window. The checker stops a path rather than reading an unknown exterior cell. At each selected endpoint, the entire eleven-cell tape word and head displacement are equal, and the states agree under pi. Outside cells were never touched and therefore also agree. Endpoints are cutpoints, not state200. Neither block has an interior halt; endpoint halt occurs in both or neither.

The parent endpoint again satisfies the invariant because it is an actual finite continuation from an invariant state. Although a block may cross other potential cutpoints, induction only uses its selected endpoint. There is no obligation to map every intermediate parent state, which is why deleting200 is legitimate.

## Both finite-halting directions

Starting at a common state0 configuration, repeatedly apply the matching-block lemma. Each block has at least one step on both sides. This excludes infinite stuttering that could hide a finite halt.

More explicitly, induct on the remaining length of a given finite parent halting trace. Its next matched parent block cannot overshoot the trace's halt, since the block has no interior halt. Remove that positive block and recurse. This constructs a finite child halting trace. Conversely, induct on the remaining length of a child halting trace and use the same block lemma; its positive child duration makes the induction decrease, and no interior halt can be skipped. The parent trace obtained is finite and halts at the matching endpoint.

The construction gives useful quantitative bounds. If the parent first halts after T steps, the child halts within3T steps. If the child first halts after S steps, the parent halts within5S steps. These are worst-case bounds, not equal-time claims.

Thus PA proves equivalence of blank halting for the exact two tables by finite trace coding and ordinary induction. Composing with the reviewed U222 endpoint gives

    PA proves: Nonhalt(U220, blank) iff Con(U).

This proof needs no fresh source-to-theory translation and no inference of nonhalting from a long finite run.

## Independent checker

`check_u220_stutter_independent.py` is newly authored and independent of the search code. It uses tuple-valued windows rather than the searcher's integer bit shifts, verifies binary total tables and target closure, recomputes the invariant, omits state200 from the cutpoint map, and tests both finite block paths directly. Its result is `U220_INDEPENDENT_STUTTER.json`, including all128 nontrivial endpoint witnesses. The checker uses explicit exceptions rather than assertions, so optimized Python does not remove obligations. It accepts explicit `--parent`, `--child`, and `--output` paths for portable replay.

This is an ordinary finite mathematical certificate checked by Python, not a new proof-assistant kernel certificate. The U222 source-to-theory proof remains an explicit inherited dependency.

## Shorter analytic marker proof

The large finite-window invariant is not necessary for the primary proof. The exact incoming-edge lists yield a short history invariant instead:

* The only incoming edge to112 is172/read0, writing0 and moving left. Consequently every parent112 configuration has a0 immediately to its right.
* If112 currently scans0, the preceding172 must have been entered from116/read0. Its other incoming edges are180/read1 and501/read1, each of which would have left a1 at the current112 cell. The only incoming edge to116 is146/read1, writing1 and moving right. Thus in the112/read0 case the immediate left neighbor is1.
* The only incoming edge to503 is156/read0, writing0 and moving right. Every503 configuration therefore has a0 immediately to its left.

These facts hold for arbitrary initial tapes from state0. State0 is none of the intermediate states in these predecessor chains, so all required predecessor steps exist. They are proved by inspection of the finite incoming lists and induction on finite trace length.

All untouched cutpoint rows commute under pi; there are438 such rows. Five local traces cover the exceptional cases (the112/read1 case splits on the bit two cells to the right):

| Parent entry | Required cells, relative to head | Old steps | New steps | Common endpoint |
|---|---|---:|---:|---|
|112 reads0| -1:1,0:0,+1:0 |3|3|151 at+1|
|112 reads1|0:1,+1:0,+2:0|5|3|90 at+3|
|112 reads1|0:1,+1:0,+2:1|5|3|86 at+3|
|503 reads0|-1:0,0:0|1|3|90 at+1|
|503 reads1|0:1|1|1|174 at+1|

Each trace reads only listed cells and preserves every bit. Other tape cells are arbitrary and untouched. Endpoints avoid200, and no trace passes through halt254. The same positive-block proof above gives both halting directions and the same3/5 bounds.

`check_u220_markers.py` independently verifies the five exact incoming-edge families, all438 ordinary row commutations, and these five partial-tape traces. It fails rather than reading an unspecified cell. It also verifies exact input hashes, explicit start0 headers, binary symbols, L/R directions, total tables, target closure, and the222/220 census. Normal and optimized Python produce byte-identical receipts. This provides a compact primary certificate; the tuple-window checker is a separately implemented stronger cross-check of the same stuttering relation.
