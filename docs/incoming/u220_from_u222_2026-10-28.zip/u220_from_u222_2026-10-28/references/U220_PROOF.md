# U220: a two-state reduction of the primary U222

## Exact tables

Parent native U222 SHA256:
`88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427`.

Final native U220 SHA256:
`8d68adfc1090439d510de72624d625a7337e022b02c94a77df704ebe6dc03673`.

Final dense U220 SHA256:
`b28ea3337cc3feb56d22e4b4b032e52e19e5b7d89554fe4c49ca4ed57f36e745`.

The final machine has220 working states,440 binary transitions,start0,halt220 in its dense presentation. All220 states are graph reachable. No initialization or parser state is excluded from this count. The tape convention is inherited unchanged.

## Literal construction

Use native labels until the last relabeling step. Identify503 with112 and redirect every target503 to112. Replace the two rows at112 by

    112 0 0 L 195
    112 1 1 R 174.

Delete503. The resulting intermediate table has221 working states. It has no incoming edge to200, and200 is not the initial state. Delete200 as graph unreachable. Finally relabel the remaining states bijectively in increasing native-label order, with254 becoming the halting label220.

This construction makes no change to the source calculus or formula enumeration. Its correctness is a direct transition-table equivalence theorem.

## Three local marker facts

All statements refer to parent runs starting in state0, on any initial tape. At the current head positionh:

1. At state112, cellh+1 contains0. The only incoming edge is172/read0, which writes0 then moves left.
2. At state112 reading0, cellh-1 contains1. The preceding172 state can only be entered by116/read0,180/read1,or501/read1; all move right and preserve the read bit. Because112 returns left to that same cell and reads0, the predecessor must have been116/read0. The only incoming edge to116 is146/read1, which writes1 immediately to its left. No intervening step changes that cell.
3. At state503, cellh-1 contains0. Its only incoming edge is156/read0, which writes0 then moves right.

State0 is distinct from112,172,116,and503, so no exceptional initial entry defeats these arguments. These facts are proved directly from the complete incoming-edge census; they are not inferred from finite executions.

## Four local path identities

Let pi identify503 with112 and fix all other states. A pairq@j denotes stateq at head positionh+j. Every transition in the displayed paths preserves the scanned bit. All omitted tape cells therefore remain unchanged.

* Parent112/read0: by facts1 and2, the local cells at−1,0,+1 are1,0,0. The parent path is
  `112@0 →157@1 →67@0 →151@1`.
  The new path is
  `112@0 →195@−1 →101@0 →151@1`.
  Both take3 steps and have the same final tape,state,and head.

* Parent112/read1 with cell+2 equal0: fact1 gives cell+1=0. The parent path is
  `112@0 →200@1 →157@2 →67@1 →151@2 →90@3`.
  The new path is
  `112@0 →174@1 →504@2 →90@3`.
  They take5 and3 steps, respectively, and end identically.

* Parent112/read1 with cell+2 equal1: the parent path is
  `112@0 →200@1 →157@2 →148@1 →186@2 →86@3`.
  The new path is
  `112@0 →174@1 →504@2 →86@3`.
  They again take5 and3 steps and end identically.

* Parent503/read0: fact3 gives cell−1=0. The parent path is
  `503@0 →90@1`.
  Its new counterpart is
  `112@0 →195@−1 →150@0 →90@1`.
  They take1 and3 steps and end identically.

The503/read1 row already commutes exactly with pi. Every row at another state commutes in one step, except the isolated intermediate200 remains present until the separate deletion. Every block has positive duration in both machines. No displayed strict interior contains the halting state.

These identities do not imply a general speedup: one family shortens5 steps to3, another lengthens1 to3.

## Full-run and PA theorem

Compare the parent with the221-state intermediate table at aligned block boundaries. Initially tape and head coincide and the states agree under pi. The three parent marker facts and the four path identities supply the next pair of positive-duration blocks; all other rows use a one-step block. The endpoint relation is preserved with exactly the same tape and head.

All parent block lengths are at most5 and all intermediate block lengths at most3; every block length is at least1. The halting state254 is a singleton fiber of pi, and no strict block interior halts. Consequently the parent has a finite halting run if and only if the intermediate table does. For example, a putative halting run ofN steps permits at mostN nonhalting block starts; positive durations prevent the comparison from stalling. This is a finite induction argument in both directions, not an appeal to observed nonhalting or infinite tape objects.

State200 has no incoming edge anywhere in the intermediate table, so it cannot occur on a run from0. Its deletion preserves every such run exactly. Dense relabeling also preserves every transition exactly. Hence PA proves

    Halt(U220,blank) iff Halt(U222,blank).

Combining this finite machine-equivalence theorem with the supplied primary U222 calibration gives

    PA proves Nonhalt(U220,blank) iff Con(U).

The reduction proof uses no additional assumption about U and no new source calibration. The inherited ordinary mathematical U222 proof remains part of the dependency chain; this package is not a new kernel-checked PA/Rocq/Lean certificate and establishes no global minimality bound.

## Reproducible checks

`certify_u220.py` reconstructs the exact intermediate and final tables from the pinned U222 table, checks target closure and graph reachability, and independently verifies a width11 inductive local-window invariant over all initial tapes. The closure has86387 windows including64 halting windows:86195 one-step cases and128 nontrivial catch-up cases. For each nontrivial case it checks all reads/writes stay in the known window, exact final tape/head/mapped-state equality, positive durations, and no interior halt. The untouched exterior is therefore preserved. This finite closure is a mathematical induction certificate, not a bounded execution sample.

`check_marker_u220.py` independently checks the complete incoming-edge census for the three marker facts and enumerates just20 guarded5-bit cases for the four path identities. The fifth bit is harmless padding; all reads/writes are within positions−2 through+2. Endpoints may move to+3, but no unknown cell is read or written there. This checker uses explicit exceptions rather than Python assertions and also works under optimized Python.

`U221_PROOF.md` and `check_u221.py` retain the simpler one-state fallback as a separately transparent result. It is not the primary final construction.
