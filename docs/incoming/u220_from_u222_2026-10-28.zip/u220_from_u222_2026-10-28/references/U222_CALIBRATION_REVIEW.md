# Independent U222 calibration review

28 October 2026. Input is the U222 packet at ProveIt commit `340b96f75c64de58948509a12eec78baa9b5663e`, archive SHA-256 `d23e80857214900f8e0806f03f6df752af501dd0108eb92c6ed7a49795802652`. This review reads external code as text and uses a newly authored data-only audit; it does not execute the delivered packet's programs.

## Verdict and difference from U228

No obstruction was found in the conventional source-to-theory calibration. U222 retains the original ten-head axiom/proof-search interface and both original private-variable gates. It replaces only the old K shell, using the existing selector c directly as matrix code and output-variable label. Unlike our U228, it neither separates the membership-vacuity component into another stack head nor reads a new private payload. Fixed source/test roles are 0 and 1, respectively. Both exceptional selectors 0 and 1 are proved sound, so there is no extra increment or low-code gate. These are substantive improvements, not just a changed state count.

The exact source has SHA-256 `1d258cfe56f8b845826a63af57de8134fbc4886b47f95312cf6d49424f3f3072`. The independent data audit reconstructs primitive control-flow edges and verifies all 3,154 exterior primitive rows across the replacement of [2885,4482) by [2885,3622). It independently evaluates the 28-token postfix shell into the published formula tree. Result: `U222_DATA_AUDIT.json`, produced by `audit_u222_data.py`. This is structural evidence, not an all-natural runtime or logical certificate.

## Soundness of the small codes

Write F=R(0,0), n=c, e=R(1,n), G=Q(n,I(R(n,1),R(n,0))), U=Q(1,I(e,n)), L=Q(1,I(G,I(n,e))), H=Q(n,I(L,N(U))). The bundle is N(I(V,H)), where V is the retained gated membership-vacuity formula.

At n=0, the matrix is closed truth. Under IR the dynamically bound guard G becomes emptiness of the tested object. U is true, and the shell N(H) asserts that some object contains every empty object. W proves this: obtain an empty object using its false matrix, then apply its true matrix at that empty source. This argument depends on the guard's local dynamic binder 0; it is not a generic freshness argument.

At n=1, the matrix is F, false under IR. The upper clause is universally quantified diagonal membership implying F; the lower clause has false matrix antecedent. Both are true, all occurrences of variable1 in them are already locally bound, and the outer existential shell is true. The relative-falsity normalization is essential.

For n>=2, the quoted matrix's labels are strictly below n. Thus the dynamic output name is fresh, and the displayed formula is the ordinary unrestricted power-cover instance at source0/test1. The original gate independently guarantees freshness of V. The soundness direction therefore covers every raw selector, not only a well-formed subset of codes.

Do not swap source/test roles to 1/0 while keeping the unshifted zero case. At n=0 the tested variable would also be the output label, and the lower condition would require false diagonal membership for all qualifying subsets. An empty object supplies a contradiction under W+IR. A swapped-role variant needs a separate repair.

## Logical completeness and finite proof transport

The bundle projects V by classical propositional logic, including diagonal membership atoms. This is what preserves the inherited full membership-vacuity interface. The dominated eighth row and the other retained logical rows are unchanged. Designated falsehood behaves as bottom through a finite proof: weakening gives F -> Ex_i All_i A, the sixth row gives Ex_i All_i A -> A, and composition gives F -> A. This includes binder0 and does not silently treat R(0,0) as a closed raw atom.

The inherited two-sided-membership interpretation of equality must be applied before choosing the actual matrix-code/private-variable coupling. In the equality-free U lower direction the matrix is unchanged by that interpretation. Normalize the genuine-bottom comparison formula's source/test names to 0/1, then quote a double-negated matrix and set c to its actual code n>1. Choose the old logical parameters a=b=n+1 so both gates pass. The bundle's other propositional projection supplies N(H_n), and the ordinary finite logical templates remove padding and restore names. This is a proof transformation, not an assumption that arbitrary native renaming is admissible.

The upper direction decodes into W+IR, then the finite-bit interpretation produces a PA refutation. The supplied uniform arithmetic interpretation produces a U refutation from that PA refutation. Thus both directions are uniform finite refutation transformations formalizable in PA. No old K/ZFC endpoint is applied to the new machine.

## Compiler and cutoff

The original ten-head stack order is preserved. GEN selects head9; an ordinary logical leaf selects its indicated head j; saved current lies at head10. Direct substitution checks the given Discard, leaf, GEN and MP blocks. J(0) must remain empty, since MP(0) would trigger the I(0,0)=0 alias and push an extra zero.

The strong Build contract accepts any current top with counter/cache zero, preserving the underlying stack unless it halts early. Accordingly START(Y)=AX(0;1,Y) need only reset counter/cache; it need not return top0. This distinction is harmless and matches the stated contract. Every positive proof-list tail decreases after its initial decrement and inverse-pair reads. The padded initial candidate P(3,P(Y,P(1,s))) is at least Y, so Y>=4 gives completeness above the actual initialization cutoff4.

## Safe reduction envelope

1. Exact table quotients or state renamings preserving every transition immediately preserve the endpoint.
2. Reassociation of closed source sequencing preserves the theorem if the complete exterior/control-flow contract and literal runtime are rechecked.
3. Swapping the two cover clauses inside H is classically equivalent, retains the outer propositional bundle projections, and preserves the low-code arguments. It may change source sharing or register-entry contexts and therefore still needs a new physical-runtime audit.
4. Moving the two tested-variable quantifiers to one quantifier over their conjunction preserves ordinary W semantics, but adds negation work in the implication-only representation. It remains a possible source-sharing experiment, not an established improvement.
5. Moving the output quantifier across V is semantically equivalent when its binder is fresh for V, but cannot be called a safe native-calculus reduction yet. The current calculus recovers V by direct propositional projection; the moved form may need V's own quantifier-vacuity theorem to recover V, creating a circular bootstrap. A new finite native derivation would be required.

All state-count conclusions must come from a literal table's own universal primitive simulation and blank initialization. This review supplies no new kernel-checked PA certificate or lower bound on machine size.
