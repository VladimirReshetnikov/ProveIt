U220: REDUCING THE PRIMARY U222 CONSISTENCY MACHINE
28 October 2026

RESULT

220 working states, 440 binary transitions, blank tape, start 0, halt 220.
The literal table is machine/u220.tm. Initialization is included.
The report gives a conventional mathematical proof, formalizable in PA,
that blank nonhalting is equivalent to Con(U). This saves two states over
the primary U222. It is not a global minimality result or a new compiled
Lean/Rocq/MM0/PA kernel certificate.

THE REDUCTION

Using U222's NATIVE labels, change only 112/0, 112/1, 156/0, then remove
states 503 and 200. Three incoming-marker facts imply four short path
identities. Parent/new block durations are positive and bounded by 5/3.
The machine's source, theory and formula stream are unchanged. It is not
claimed to be faster on every input; one path grows from 1 step to 3.

READ FIRST

report.pdf and report.tex       New mathematical report and full dense table
machine/u220.tm                Canonical final literal table
machine/u220.native.tm          Same table with native compiler labels
machine/dense_map.json          Complete bijective relabeling including halt
baseline/U222_ConU_2026-10-28.zip  Original primary packet, byte-for-byte
references/                    New proofs, calibration review and comparisons
supplementary/u221/             Simpler 221-state fallback, not primary result
checks/                        New portable builders and verification scripts
checks/runtime/                Hash-bound, previously authored symbolic modules
reproduce.py                   Offline full replay using a temporary directory
SHA256SUMS                     Manifest, excluding itself

REPLAY

Python 3.10+ and standard library only. No network or installation needed:

  python3 reproduce.py

The script validates this manifest, extracts the supplied parent archive
as DATA, verifies all 110 of its manifest entries, rebuilds both new tables,
runs 18 marker-certificate tests normally and under -O, 11 structural tests,
source-CFG audit, parent 5060 symbolic cases, complete 95714-step bootstrap,
and two independent finite-window certificates. It explicitly verifies
result statuses, counts and hashes, rather than trusting subprocess exit 0.
The original parent packet's executable programs are not run. Its runtime
modules coincide byte-for-byte with our previously authored retained copies;
these exact copies are run through a new input-validating wrapper.

The new small certificate uses explicit errors and works under -O. The full
baseline symbolic replay and source audit require assertions and refuse -O.
The top-level replay also refuses -O. Temporary reconstruction files are
removed automatically. The final line is REPLAY_RESULT={...}; status PASS
means all listed checks succeeded, not that a proof assistant accepted the
PA endpoint.

The independent all-tape theorem starts in state 0. Do not generalize it to
arbitrary dispatcher frames. The parent universal runtime check plus the
new positive-stuttering theorem transfers the required blank endpoint.

BUILD PDF

On a complete TeX Live installation, run pdflatex twice on report.tex.
This workspace also supports:

  bash build_local.sh

The latter uses a local TeX format/cache and explicit font maps without
installing packages. Output is build/report.pdf. Pixel/text comparison,
not cross-version PDF-byte equality, is the portable document criterion.

SCOPE AND PROVENANCE

The exact source repository revision is
340b96f75c64de58948509a12eec78baa9b5663e.
Input and output hashes are in evidence and the report. The entire U222
packet preserves its complete proof source, original theory U packet,
notices, licenses and inherited theorem dependencies. Other proposals are
recorded in a comparison ledger and input inventory, not all duplicated.
No upstream repository was modified. Historical source-review notes have
their own scope: statements that their reviewers did not execute supplied
programs are not claims that no prior owned verification code was run.
