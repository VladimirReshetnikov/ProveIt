"""Owned wrapper around hash-bound previously authored mathematical checker."""
from pathlib import Path
import hashlib,json,sys,time,os
if not __debug__ or sys.flags.optimize: raise RuntimeError("Universal checking requires assertions; do not use -O or PYTHONOPTIMIZE.")
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'
K=ROOT/'checks/runtime'
for name,sha in [('symbolic_runtime.py','7ca30fd11def00e973d8f30997e51fa2dd87ae2eff311ea8c9fc4ac08c9d774f'),('independent_runtime.py','0d1dae10b921cc302a2211d9251ca7ec131aa63ecb040ce66720894877700346')]:assert hashlib.sha256((K/name).read_bytes()).hexdigest()==sha
sys.path.insert(0,str(K));import symbolic_runtime as S
packet=Path(sys.argv[1]).resolve()
p=packet/'machine/u.native.tm'
sp=packet/'machine/sites.json'
N=S.r.table(p);sites=json.loads(sp.read_text());M={int(k):int(v)for k,v in json.load(open(packet/'code/inputs/legacy_mapping.json')).items()}
for q in sorted({q for q,b in N}|{z for w,d,z in N.values()}):
 if q not in M:M[q]=max(M.values())+1
# Independent input contracts replace the historical checker's old source pin.
working={q for q,b in N}
assert len(N)==2*len(working) and all((q,b) in N for q in working for b in (0,1))
assert {z for w,d,z in N.values()}-working=={254}
assert M[254]==254 and M[84]==96 and len(M)==len(set(M.values()))
leaves=set();prefixes=set()
for site in sites:
 assert isinstance(site,list) and len(site)==3
 pc,op,arg=site
 assert isinstance(pc,str) and 0<len(pc)<=64 and set(pc)<={'0','1'} and pc not in leaves
 assert op in ('CI','CD','CB','CC','CH')
 assert (arg is None) if op=='CH' else (type(arg) is int and (0<=arg<9 if op in ('CI','CD') else arg>=1))
 leaves.add(pc);prefixes.update(pc[:i] for i in range(len(pc)))
assert not leaves.intersection(prefixes)
assert all(p+b in leaves or p+b in prefixes for p in prefixes for b in ('0','1'))
assert len(prefixes)==len(leaves)-1
T={(M[q],b):(w,d,M[z])for(q,b),(w,d,z)in N.items()}
assert len(T)==len(N)
lemmas,block_proofs=S.prove_blocks(T);cases=[];rows=set();failure=None;start=time.monotonic()
for i,site in enumerate(sites):
 if i<int(os.environ.get("START_SITE",0)):continue
 for positive in([False,True]if site[1]=='CD'else[False]):
  try:c=S.case(T,lemmas,site,positive)
  except(AssertionError,KeyError)as e:failure=dict(index=i,site=site,positive=positive,error=repr(e));break
  rows.update(c.pop('rows'));c.pop('trace');cases.append(dict(index=i,positive=positive,**c))
 if failure:break
 if i%500==0:print(i,'sites',len(cases),'cases',time.monotonic()-start,flush=True)
r=dict(status='PASS'if failure is None and len(cases)==sum(2 if s[1]=='CD'else 1 for s in sites)else'PARTIAL_PASS'if failure is None else'FAIL',table=str(p),table_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source=str(sp),source_sha256=hashlib.sha256(sp.read_bytes()).hexdigest(),states=len(N)//2,checked_cases=len(cases),expected_cases=sum(2 if s[1]=='CD'else 1 for s in sites),failure=failure,seconds=time.monotonic()-start,scope='Universal symbolic primitive-contract check, not source calibration or blank startup.')
(OUT/os.environ.get('REPORT','BASELINE_RUNTIME.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

assert r['status']=='PASS' and r['checked_cases']==r['expected_cases']==5060
assert r['table_sha256']=='88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427'
assert r['source_sha256']=='1d258cfe56f8b845826a63af57de8134fbc4886b47f95312cf6d49424f3f3072'
