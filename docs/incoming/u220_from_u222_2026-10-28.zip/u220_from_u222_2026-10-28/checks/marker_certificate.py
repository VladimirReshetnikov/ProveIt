"""Independent finite conditions for the three-marker/four-path U220 theorem."""
def need(ok,reason):
 if not ok:raise ValueError(reason)
def verify(A,B):
 Q={q for q,b in A};R={q for q,b in B}
 need(len(Q)==222 and len(R)==220 and R==Q-{200,503},'states')
 for T,S in[(A,Q),(B,R)]:
  need(set(T)=={(q,b)for q in S for b in(0,1)},'totality')
  need(all(w in(0,1)and d in(-1,1)and(z in S or z==254)for w,d,z in T.values()),'action closure')
 need(254 not in Q|R and 0 in R,'start/halt')
 inc=lambda z:{(q,b)for(q,b),(w,d,t)in A.items()if t==z}
 need(inc(112)=={(172,0)}and A[172,0]==(0,-1,112),'right zero')
 need(inc(172)=={(116,0),(180,1),(501,1)},'172 incoming')
 need(A[116,0]==(0,1,172)and A[180,1]==A[501,1]==(1,1,172),'predecessor tag')
 need(inc(116)=={(146,1)}and A[146,1]==(1,1,116),'left one')
 need(inc(503)=={(156,0)}and A[156,0]==(0,1,503),'left zero')
 f=lambda q:112 if q==503 else q
 C=dict(B);C[200,0]=A[200,0];C[200,1]=A[200,1]
 need(all(z!=200 for w,d,z in C.values()),'unreachable 200')
 need(set(C)=={(q,b)for q in Q-{503}for b in(0,1)},'intermediate total')
 for(q,b),(w,d,z)in A.items():
  if q not in(112,503):need(C[f(q),b]==(w,d,f(z)),'ordinary commutation')
 need(C[112,0]==(0,-1,195)and C[112,1]==(1,1,174),'patch')
 need(C[112,1]==(A[503,1][0],A[503,1][1],f(A[503,1][2])),'503 one commutation')
 def run(T,q,x,n):
  h=0;out=[]
  for _ in range(n):
   need(-2<=h<=2,'read outside window');need(q!=254,'interior halt')
   bit=(x>>(h+2))&1;w,d,z=T[q,bit]
   need(w==bit,'path changes tape')
   x=(x&~(1<<(h+2)))|(w<<(h+2));q=z;h+=d;out.append([q,h,x])
  return(q,h,x),out
 records=[]
 for x in range(32):
  l=(x>>1)&1;b=(x>>2)&1;r=(x>>3)&1
  for q in(112,503):
   if q==112:
    if r or(not b and not l):continue
    a=3 if not b else 5
   else:
    if l or b:continue
    a=1
   u,ut=run(A,q,x,a);v,vt=run(C,f(q),x,3)
   need((f(u[0]),u[1],u[2])==v,'local endpoint')
   need(u[2]==v[2]==x,'unchanged tape')
   records.append(dict(state=q,window=x,old_steps=a,new_steps=3,old_trace=ut,new_trace=vt))
 need(len(records)==20,'case count')
 return dict(status='PASS',guarded_cases=20,marker_facts=3,states=220,rows=440,records=records)
def verify_dense(B,D,M):
 R={q for q,b in B}
 need(set(M)==R|{254}and len(M)==len(set(M.values()))==221 and set(M.values())==set(range(221)),'dense bijection')
 need(M[0]==0 and M[254]==220,'dense start/halt')
 need(D=={(M[q],b):(w,d,M[z])for(q,b),(w,d,z)in B.items()},'dense conjugacy')
