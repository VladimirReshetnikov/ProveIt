"""Independent data-only audit of U222 formula tree and exterior control flow."""
from pathlib import Path
import json, hashlib, sys
if not __debug__: raise RuntimeError("Assertions required; do not use -O.")
R=Path(sys.argv[1]).resolve()
base=json.loads((R/'inputs/k215_sites.json').read_text()); new=json.loads((R/'machine/sites.json').read_text())
def tree(rows):
 d={s[0]:tuple(s[1:]) for s in rows}
 assert len(d)==len(rows)
 def go(p): return d[p] if p in d else (go(p+'0'),go(p+'1'))
 return go('')
def leaf(t): return isinstance(t[0],str)
def count(t): return 1 if leaf(t) else count(t[0])+count(t[1])
def cfg(t):
 out=[]
 def go(t,k,br,co):
  if leaf(t):
   op,r=t
   z=(k+1,) if op=='CI' else (br[0],k+1) if op=='CD' else (br[r-1],) if op=='CB' else (co[r-1],) if op=='CC' else ()
   out.append((op,r if op not in ('CB','CC') else None,z)); return
  m=k+count(t[0]);e=m+count(t[1]);go(t[0],k,[e]+br,co);go(t[1],m,br,[k]+co)
 go(t,0,[],[]);return out
b=cfg(tree(base));n=cfg(tree(new));lo,hi=2885,4482;delta=len(n)-len(b)
def shift(i):
 assert not lo<i<hi
 return i if i<=lo else i+delta
exterior=0
for i,(op,r,edges) in enumerate(b):
 if lo<=i<hi:continue
 assert n[shift(i)]==(op,r,tuple(shift(e) for e in edges)),(i,b[i],n[shift(i)])
 exterior+=1
c=json.loads((R/'machine/construction.json').read_text());tokens=c['new_shell_macro_word']
s=[]
for x in tokens:
 if x in ('n',0,1):s.append(x)
 elif x=='N':s.append(['I',s.pop(),'F'])
 else:
  right=s.pop();left=s.pop();s.append([x,left,right])
assert len(s)==1 and s[0]==c['negseed']
assert len(base)==4751 and len(new)==3891 and exterior==3154
result={'status':'PASS','baseline_sha256':hashlib.sha256((R/'inputs/k215_sites.json').read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((R/'machine/sites.json').read_bytes()).hexdigest(),'source_leaves':len(new),'retained_primitive_cfg_rows':exterior,'old_interval':[lo,hi],'new_interval':[lo,hi+delta],'postfix_matches_negseed':True,'scope':'Data-only exact formula postfix and retained control-flow audit; mathematical low-code and proof calibration checked in accompanying note.'}
print(json.dumps(result,indent=2));(Path(__file__).resolve().parents[1]/'evidence/U222_DATA_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
