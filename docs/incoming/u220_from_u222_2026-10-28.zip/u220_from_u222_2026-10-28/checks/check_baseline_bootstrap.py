"""Independent direct replay of every supplied baseline startup row."""
from pathlib import Path
import sys,json,hashlib
if not __debug__: raise RuntimeError('Assertions required; do not use -O.')
P=Path(sys.argv[1]).resolve();O=Path(__file__).resolve().parents[1]/'evidence'
T={}
for ln in(P/'machine/u.native.tm').read_text().splitlines():
 if not ln or ln.startswith('#'):continue
 q,b,w,d,z=ln.split();q,b,w,z=map(int,(q,b,w,z));assert(q,b)not in T;assert b in(0,1)and w in(0,1)and d in('L','R');T[q,b]=(w,1 if d=='R'else-1,z)
qs={q for q,b in T};assert len(qs)==222 and len(T)==444
A=json.loads((P/'evidence/startup.json').read_text());assert len(A['trace'])==A['steps']==95714
q=h=0;ones=set();coverage=set()
for i,row in enumerate(A['trace']):
 b=int(h in ones);w,d,z=T[q,b];assert row==[q,h,b,w,d,z],(i,row,[q,h,b,w,d,z]);coverage.add((q,b))
 if w:ones.add(h)
 else:ones.discard(h)
 q=z;h+=d
assert (q,h,sorted(ones))==(A['state'],A['head'],A['one_cells'])
# Own frame constructor, no imported runtime or supplied startup decoder.
phy=(6,2,0,4,3,7,8,5,1);logical=[4]+[0]*8;vals=[0]*9
for i,j in enumerate(phy):vals[j]=logical[i]
row=[0]*65+[1]
for v in vals+[1]*40:row += [0]+[1]*(v+1)
expected={i-8 for i in {-1}|{j for j,b in enumerate(row)if b}}
assert(q,h,ones)==(84,-8,expected)
result=dict(status='PASS',steps=95714,working_states=222,table_sha256=hashlib.sha256((P/'machine/u.native.tm').read_bytes()).hexdigest(),startup_sha256=hashlib.sha256((P/'evidence/startup.json').read_bytes()).hexdigest(),every_transition_replayed=True,complete_finite_support_compared=True,exact_independent_frame=True,dispatch=84,head=-8,logical_registers=logical,spares=[1]*40,gap=1,rows_observed=len(coverage))
(O/'BASELINE_BOOTSTRAP.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
