#!/usr/bin/env python3
"""Generate a complete three-panel TeX table directly from literal TM data."""
import argparse
from pathlib import Path
from check_literal_table import parse_table

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("table", type=Path)
    parser.add_argument("--halt", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    _, _, states, rows = parse_table(args.table, args.halt)
    height = (len(states) + 2) // 3
    lines = [r"\begingroup\small\ttfamily", r"\setlength{\tabcolsep}{8pt}",
             r"\begin{longtable}{rll@{\hspace{18pt}}rll@{\hspace{18pt}}rll}",
             r"\toprule", r"q & 0 & 1 & q & 0 & 1 & q & 0 & 1\\\midrule\endfirsthead",
             r"\toprule", r"q & 0 & 1 & q & 0 & 1 & q & 0 & 1\\\midrule\endhead",
             r"\midrule\multicolumn{9}{r}{Continued on the next page}\\\endfoot",
             r"\bottomrule\endlastfoot"]
    for i in range(height):
        fields = []
        for panel in range(3):
            j = i + panel * height
            if j >= len(states):
                fields.extend(["", "", ""])
                continue
            q = states[j]
            action = []
            for bit in (0, 1):
                w, d, target = rows[q, bit]
                action.append(f"{w}{d}" + ("H" if target == args.halt else str(target)))
            fields.extend([str(q), *action])
        lines.append(" & ".join(fields) + r"\\")
    lines.extend([r"\end{longtable}", r"\endgroup"])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n")

if __name__ == "__main__":
    main()
