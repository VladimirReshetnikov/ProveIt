from pathlib import Path
import sys,json,unittest
from marker_certificate import verify,verify_dense
P=Path(sys.argv.pop(1)).resolve();R=Path(__file__).resolve().parents[1]
def read(p):
 t={}
 for l in p.read_text().splitlines():
  if l and not l.startswith('#'):
   q,b,w,d,z=l.split();t[int(q),int(b)]=(int(w),-1 if d=='L'else 1,int(z))
 return t
A=read(P/'machine/u.native.tm');B=read(R/'machine/u220.native.tm');D=read(R/'machine/u220.tm');M={int(k):v for k,v in json.loads((R/'machine/dense_map.json').read_text()).items()}
class Tests(unittest.TestCase):
 def test_positive(self):self.assertEqual(verify(A,B)['guarded_cases'],20);verify_dense(B,D,M)
 def test_right_zero(self):
  a=A.copy();a[172,0]=(1,-1,112)
  with self.assertRaisesRegex(ValueError,'right zero'):verify(a,B)
 def test_left_one(self):
  a=A.copy();a[146,1]=(0,1,116)
  with self.assertRaisesRegex(ValueError,'left one'):verify(a,B)
 def test_left_zero(self):
  a=A.copy();a[156,0]=(1,1,503)
  with self.assertRaisesRegex(ValueError,'left zero'):verify(a,B)
 def test_extra_incoming(self):
  a=A.copy();a[0,1]=(1,1,112)
  with self.assertRaisesRegex(ValueError,'right zero'):verify(a,B)
 def test_extra_incoming116(self):
  a=A.copy();a[0,1]=(1,1,116)
  with self.assertRaisesRegex(ValueError,'left one'):verify(a,B)
 def test_extra_incoming172(self):
  a=A.copy();a[0,1]=(1,1,172)
  with self.assertRaisesRegex(ValueError,'172 incoming'):verify(a,B)
 def test_extra_incoming503(self):
  a=A.copy();a[0,1]=(1,1,503)
  with self.assertRaisesRegex(ValueError,'left zero'):verify(a,B)
 def test_bad_redirect(self):
  b=B.copy();b[156,0]=(0,1,503)
  with self.assertRaisesRegex(ValueError,'action closure'):verify(A,b)
 def test_deleted_state_target(self):
  b=B.copy();b[112,1]=(1,1,200)
  with self.assertRaisesRegex(ValueError,'action closure'):verify(A,b)
 def test_changed_tag(self):
  a=A.copy();a[180,1]=(0,1,172)
  with self.assertRaisesRegex(ValueError,'predecessor tag'):verify(a,B)
 def test_bad_patch(self):
  b=B.copy();b[112,0]=(1,-1,195)
  with self.assertRaisesRegex(ValueError,'patch'):verify(A,b)
 def test_ordinary_row(self):
  b=B.copy();b[0,0]=(0,-1,0)
  with self.assertRaisesRegex(ValueError,'ordinary commutation'):verify(A,b)
 def test_missing_row(self):
  b=B.copy();del b[112,0]
  with self.assertRaisesRegex(ValueError,'totality'):verify(A,b)
 def test_bad_direction(self):
  b=B.copy();b[112,0]=(0,0,195)
  with self.assertRaisesRegex(ValueError,'action closure'):verify(A,b)
 def test_dense_collision(self):
  m=M.copy();m[1]=m[2]
  with self.assertRaisesRegex(ValueError,'bijection'):verify_dense(B,D,m)
 def test_halt_swap(self):
  m=M.copy();m[254],m[1]=m[1],m[254]
  with self.assertRaisesRegex(ValueError,'start/halt'):verify_dense(B,D,m)
 def test_dense_row(self):
  d=D.copy();d[0,0]=(0,-1,0)
  with self.assertRaisesRegex(ValueError,'conjugacy'):verify_dense(B,d,M)
if __name__=='__main__':unittest.main()
