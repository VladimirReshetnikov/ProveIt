"""Reconstruct exact U220 and independently check its finite proof conditions."""
from pathlib import Path
import json,hashlib,sys
from marker_certificate import verify,verify_dense,need
P=Path(sys.argv[1]).resolve();R=Path(__file__).resolve().parents[1];O=R/'evidence';M=R/'machine';O.mkdir(exist_ok=True);M.mkdir(exist_ok=True)
Afile=P/'machine/u.native.tm'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
need(sha(Afile)=='88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427','parent identity')
A={};starts=[]
for line in Afile.read_text().splitlines():
 if line.startswith('#! start '):starts.append(int(line.split()[-1]));continue
 if not line or line.startswith('#'):continue
 q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z));need((q,b)not in A,'duplicate');need(d in('L','R'),'direction');A[q,b]=(w,-1 if d=='L'else 1,z)
need(starts==[0],'start directive');f=lambda q:112 if q==503 else q
B={(q,b):(w,d,f(z))for(q,b),(w,d,z)in A.items()if q not in(200,503)}
B[112,0]=(0,-1,195);B[112,1]=(1,1,174)
r=verify(A,B)
mp={q:i for i,q in enumerate(sorted({q for q,b in B}))};mp[254]=220
D={(mp[q],b):(w,d,mp[z])for(q,b),(w,d,z)in B.items()};verify_dense(B,D,mp)
def text(T):return '#! start 0\n'+''.join(f'{q} {b} {w} {"L" if d==-1 else "R"} {z}\n'for(q,b),(w,d,z)in sorted(T.items()))
(M/'u220.native.tm').write_text(text(B));(M/'u220.tm').write_text(text(D));(M/'dense_map.json').write_text(json.dumps(mp,indent=2)+'\n')
need(sha(M/'u220.native.tm')=='8d68adfc1090439d510de72624d625a7337e022b02c94a77df704ebe6dc03673','native identity')
need(sha(M/'u220.tm')=='b28ea3337cc3feb56d22e4b4b032e52e19e5b7d89554fe4c49ca4ed57f36e745','dense identity')
r.update(parent_sha256=sha(Afile),native_sha256=sha(M/'u220.native.tm'),dense_sha256=sha(M/'u220.tm'),scope='Exact sufficient table conditions and20finite local identities for all-initial-tape stuttering theorem; proof in report')
(O/'U220_BUILD_AND_CHECK.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='records'},indent=2))
