"""Original exact finite invariant/stuttering certificate. Stdlib only.
This checks a mathematical all-tape simulation, not a bounded TM run.
"""
from pathlib import Path
from collections import deque
import argparse,hashlib,json
ROOT=Path(__file__).resolve().parent
DEFAULT=ROOT.parent/'intake/U222/u222_consistency_machine/machine/u.native.tm'
def need(ok,why):
 if not ok:raise ValueError(why)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 t={};starts=[]
 for l in p.read_text().splitlines():
  if l.startswith('#! start '):starts.append(int(l[9:]));continue
  if not l or l.startswith('#'):continue
  q,b,w,d,z=l.split();q,b,w,z=map(int,(q,b,w,z));need((q,b)not in t,'duplicate row');need(b in(0,1)and w in(0,1)and d in('L','R'),'invalid symbol');t[q,b]=(w,1 if d=='R'else-1,z)
 need(starts==[0],'start');ss={q for q,b in t};need(set(t)=={(q,b)for q in ss for b in(0,1)},'totality');need(254 not in ss and {z for w,d,z in t.values()}-ss=={254},'halt closure');return t
def encode(t):return '#! start 0\n'+''.join(f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'for(q,b),(w,d,z)in sorted(t.items()))
def closure(t,W):
 K=W//2;mask=(1<<W)-1;seen={(0,x)for x in range(mask+1)};todo=deque(sorted(seen))
 while todo:
  q,x=todo.popleft()
  if q==254:continue
  w,d,z=t[q,(x>>K)&1];y=(x&~(1<<K))|(w<<K)
  for b in(0,1):
   v=(y>>1)|(b<<(W-1))if d==1 else((y<<1)&mask)|b
   if(z,v)not in seen:seen.add((z,v));todo.append((z,v))
 # Independent postcondition for every seed and both possible exterior bits.
 need(all((0,x)in seen for x in range(mask+1)),'seeds')
 for q,x in seen:
  if q==254:continue
  w,d,z=t[q,(x>>K)&1];y=(x&~(1<<K))|(w<<K)
  vs=[(y>>1)|(b<<(W-1))if d==1 else((y<<1)&mask)|b for b in(0,1)]
  need(all((z,v)in seen for v in vs),'closure')
 return seen

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--parent',type=Path,default=DEFAULT);ap.add_argument('--output',type=Path,default=ROOT/'u220_certificate');a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 need(sha(a.parent)=='88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427','parent identity')
 A=read(a.parent);need(len(A)==444,'parent rows')
 phi=lambda q:112 if q==503 else q
 # First construct full intermediate quotient before deleting isolated200.
 B={(q,b):(w,d,phi(z))for(q,b),(w,d,z)in A.items()if q!=503}
 B[112,0]=(0,-1,195);B[112,1]=(1,1,174)
 (a.output/'intermediate221.native.tm').write_text(encode(B))
 need({z for w,d,z in B.values()}-{q for q,b in B}=={254},'intermediate closure')
 W=11;K=W//2;reach=closure(A,W);witnesses=[];commute=0;maxo=maxn=0
 def step(t,p):
  q,h,x=p;need(-K<=h<=K,'window read escaped');w,d,z=t[q,(x>>(h+K))&1];return z,h+d,(x&~(1<<(h+K)))|(w<<(h+K))
 for q,x in sorted(reach):
  if q==254:continue
  c=(x>>K)&1;w,d,z=A[q,c]
  if B[phi(q),c]==(w,d,phi(z)):commute+=1;continue
  old=(q,0,x);ends={};oldtrace=[]
  for oi in range(1,41):
   if old[0]==254 or not -K<=old[1]<=K:break
   old=step(A,old);oldtrace.append(old);ends.setdefault((phi(old[0]),old[1],old[2]),oi)
  new=(phi(q),0,x);newtrace=[];ni=oi=0
  for ni in range(1,257):
   if new[0]==254 or not -K<=new[1]<=K:break
   new=step(B,new);newtrace.append(new)
   if new in ends:oi=ends[new];break
  need(oi>0,f'no positive catchup {q},{x}')
  need(1<=oi<=5 and 1<=ni<=3,'claimed time bounds')
  need((phi(oldtrace[oi-1][0]),oldtrace[oi-1][1],oldtrace[oi-1][2])==newtrace[ni-1],'endpoint')
  need(all(t[0]!=254 for t in oldtrace[:oi-1])and all(t[0]!=254 for t in newtrace[:ni-1]),'no interiorhalt')
  maxo=max(maxo,oi);maxn=max(maxn,ni);witnesses.append({'state':q,'window':x,'old_steps':oi,'new_steps':ni,'old_trace':oldtrace[:oi],'new_trace':newtrace[:ni]})
 # Halt singleton and positive durations establish halting equivalence by finite induction.
 need(phi(0)==0 and phi(254)==254 and all(phi(q)!=254 for q,b in A),'initial/halting fibers')
 need(all(z!=200 for w,d,z in B.values()),'200 has no incoming edge')
 need(200!=0,'deleted not initial')
 C={k:v for k,v in B.items()if k[0]!=200};need(len(C)==440,'220 rows')
 ss=sorted({q for q,b in C});todo=[0];seen={0}
 for q in todo:
  for b in(0,1):
   z=C[q,b][2]
   if z!=254 and z not in seen:seen.add(z);todo.append(z)
 need(seen==set(ss),'all220 graph reachable')
 (a.output/'u220.native.tm').write_text(encode(C));m={q:i for i,q in enumerate(ss)};m[254]=220
 D={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in C.items()};(a.output/'u220.tm').write_text(encode(D));(a.output/'dense_map.json').write_text(json.dumps(m,indent=2)+'\n')
 (a.output/'local_witnesses.json').write_text(json.dumps(witnesses,indent=2)+'\n')
 r={'status':'UNIVERSAL_ALL_INITIAL_TAPES_STUTTER_EQUIVALENCE_PASS','parent_sha256':sha(a.parent),'native_sha256':sha(a.output/'u220.native.tm'),'dense_sha256':sha(a.output/'u220.tm'),'parent_states':222,'candidate_states':220,'width':W,'closure_windows':len(reach),'one_step_windows':commute,'nontrivial_windows':len(witnesses),'max_old_steps':maxo,'max_new_steps':maxn,'merged_state':503,'representative_state':112,'deleted_unreachable_state':200,'candidate_rows':440,'scope':'All tapes initially in state0. Positive bounded stuttering plus graph-unreachable deletion, formally expressible in PA; no new source assumptions.'}
 (a.output/'certificate.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
