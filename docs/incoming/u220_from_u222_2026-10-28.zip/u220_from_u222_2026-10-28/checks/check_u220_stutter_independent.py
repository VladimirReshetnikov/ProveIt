"""Independent finite-window stuttering proof checker, newly authored.
Never executes programs from the input archive. Standard library only.
"""
from pathlib import Path
from collections import deque,Counter
import json,hashlib,time,argparse
R=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--parent',type=Path,default=R/'intake/U222/u222_consistency_machine/machine/u.native.tm')
parser.add_argument('--child',type=Path,default=R/'table_search/u220_stutter.native.tm')
parser.add_argument('--output',type=Path,default=Path(__file__).parent/'U220_INDEPENDENT_STUTTER.json')
args=parser.parse_args();Afile=args.parent;Bfile=args.child
def require(x,s):
 if not x:raise ValueError(s)
def table(p):
 t={}
 for l in p.read_text().splitlines():
  if not l.strip() or l.startswith('#'):continue
  q,b,w,d,z=l.split();q,b,w,z=map(int,(q,b,w,z))
  require((q,b) not in t and b in (0,1) and w in (0,1) and d in ('L','R'),'bad row')
  t[q,b]=(w,-1 if d=='L' else 1,z)
 qs={q for q,b in t};require(set(t)=={(q,b)for q in qs for b in(0,1)},'not total')
 require({z for w,d,z in t.values()}<=qs|{254},'bad target');return t,qs
A,QA=table(Afile);B,QB=table(Bfile)
require(len(QA)==222 and len(QB)==220,'bad state count')
require(QB==QA-{200,503},'removed states')
require([(q,b)for(q,b),(w,d,z)in A.items()if z==200]==[(112,1)],'200 entry')
require(0 not in (200,503) and 254 not in QA|QB,'initial/halt')
def phi(q):
 require(q!=200,'interior200 is not a cutpoint');return 112 if q==503 else q
W=11;K=W//2
# Tuple windows are ordered from left to right. Exposed bits are unconstrained.
windows=[tuple((n>>i)&1 for i in range(W))for n in range(1<<W)]
seen={(0,w)for w in windows};queue=deque(seen);edges=0
while queue:
 q,x=queue.popleft()
 if q==254:continue
 w,d,z=A[q,x[K]];y=x[:K]+(w,)+x[K+1:]
 for bit in(0,1):
  nxt=(z,y[1:]+(bit,)) if d==1 else(z,(bit,)+y[:-1])
  edges+=1
  if nxt not in seen:seen.add(nxt);queue.append(nxt)

def path(t,q,window,bound):
 h=0;cells=list(window);out=[]
 for step in range(1,bound+1):
  if q==254 or not -K<=h<=K:break
  w,d,z=t[q,cells[h+K]];cells[h+K]=w;h+=d;q=z
  out.append((q,h,tuple(cells),step))
 return out
records=[];trivial=0;maxa=maxb=0;lengths=Counter()
for q,x in sorted(seen):
 if q in (200,254):continue
 ar=A[q,x[K]]; br=B[phi(q),x[K]]
 if ar[2]!=200 and (ar[0],ar[1],phi(ar[2]))==br:
  trivial+=1;continue
 ap=path(A,q,x,40);bp=path(B,phi(q),x,256);match=None
 for z,h,y,j in bp:
  for z0,h0,y0,i in ap:
   if z0!=200 and phi(z0)==z and h0==h and y0==y:
    match=(i,j,z0,z,h,y);break
  if match:break
 require(match is not None,f'no match at {(q,x)}')
 i,j,z0,z,h,y=match
 require(all(v[0]!=254 for v in ap[:i-1]),'old interior halt')
 require(all(v[0]!=254 for v in bp[:j-1]),'new interior halt')
 require((z0==254)==(z==254),'halt fiber')
 # A matched old endpoint remains in the invariant: full actual continuation
 # induces one of the BFS edges at each step. The checker uses no future bits.
 maxa=max(maxa,i);maxb=max(maxb,j);lengths[i,j]+=1
 records.append({'state':q,'window':''.join(map(str,x)),'old_steps':i,'new_steps':j,'end_old_state':z0,'end_new_state':z,'head_delta':h})
require(len(records)==128 and maxa<=5 and maxb<=3,'unexpected counts')
out={'status':'PASS','parent_sha256':hashlib.sha256(Afile.read_bytes()).hexdigest(),'child_sha256':hashlib.sha256(Bfile.read_bytes()).hexdigest(),'parent_states':222,'child_states':220,'width':W,'initial_windows':len(windows),'closure_states':len(seen),'closure_edges':edges,'trivial_cutpoints':trivial,'nontrivial_cutpoints':len(records),'max_old_steps':maxa,'max_new_steps':maxb,'step_pair_counts':{f'{i},{j}':v for(i,j),v in sorted(lengths.items())},'scope':'All-tape state0 stuttering proof via finite inductive window invariant; not bounded blank-run testing','records':records}
p=args.output;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='records'},indent=2))
