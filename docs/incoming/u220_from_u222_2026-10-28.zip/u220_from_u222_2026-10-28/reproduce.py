"""Offline full replay. Extracts the parent as data; runs only bundled audited checks."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile,zipfile,platform
R=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Full replay includes assertion-based baseline proof code; do not use -O.')
def need(x,s):
 if not x:raise ValueError(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for line in(R/'SHA256SUMS').read_text().splitlines():
 h,n=line.split(maxsplit=1);n=n.lstrip('* ');p=R/n
 need(p.is_file()and sha(p)==h,'manifest '+n)
archive=R/'baseline/U222_ConU_2026-10-28.zip'
need(sha(archive)=='d23e80857214900f8e0806f03f6df752af501dd0108eb92c6ed7a49795802652','parent archive')
with tempfile.TemporaryDirectory(prefix='u220-replay-')as td:
 W=Path(td);shutil.copytree(R/'checks',W/'checks');shutil.copytree(R/'machine',W/'machine');(W/'evidence').mkdir()
 with zipfile.ZipFile(archive)as z:
  need(z.testzip()is None,'parent CRC')
  need(all(not Path(n).is_absolute()and '..'not in Path(n).parts for n in z.namelist()),'parent paths')
  z.extractall(W/'baseline')
 P=W/'baseline/u222_consistency_machine';count=0
 for line in(P/'SHA256SUMS').read_text().splitlines():
  h,n=line.split(maxsplit=1);n=n.lstrip('* ');need(sha(P/n)==h,'parent manifest '+n);count+=1
 need(count==110,'parent manifest count')
 def run(script,*args,optimized=False):
  cmd=[sys.executable,*(['-O']if optimized else[]),'-B',str(W/'checks'/script),*map(str,args)]
  print('RUN',script,'optimized'if optimized else'normal',flush=True);subprocess.run(cmd,check=True,cwd=W)
 run('build_u220.py',P)
 for f in ['u220.tm','u220.native.tm','dense_map.json']:need((W/'machine'/f).read_bytes()==(R/'machine'/f).read_bytes(),'rebuilt '+f)
 run('test_marker_certificate.py',P);run('test_marker_certificate.py',P,optimized=True)
 run('test_table_checker.py')
 run('audit_u222_data.py',P)
 run('check_baseline_bootstrap.py',P)
 run('check_baseline_runtime.py',P)
 run('certify_u220.py','--parent',P/'machine/u.native.tm','--output',W/'window_certificate')
 for f in ['u220.tm','u220.native.tm']:need((W/'window_certificate'/f).read_bytes()==(R/'machine'/f).read_bytes(),'independent built '+f)
 run('check_u220_stutter_independent.py','--parent',P/'machine/u.native.tm','--child',W/'machine/u220.native.tm','--output',W/'evidence/INDEPENDENT_WINDOW.json')
 for script in ['check_baseline_runtime.py','check_baseline_bootstrap.py','audit_u222_data.py']:
  out=subprocess.run([sys.executable,'-O','-B',str(W/'checks'/script),str(P)],capture_output=True,text=True)
  need(out.returncode!=0 and('Assertions required'in out.stderr or'requires assertions'in out.stderr),'optimized refusal '+script)
 runtime=json.loads((W/'evidence/BASELINE_RUNTIME.json').read_text());boot=json.loads((W/'evidence/BASELINE_BOOTSTRAP.json').read_text());data=json.loads((W/'evidence/U222_DATA_AUDIT.json').read_text());marker=json.loads((W/'evidence/U220_BUILD_AND_CHECK.json').read_text());window=json.loads((W/'window_certificate/certificate.json').read_text());ind=json.loads((W/'evidence/INDEPENDENT_WINDOW.json').read_text())
 need(runtime['status']=='PASS'and runtime['checked_cases']==runtime['expected_cases']==5060,'runtime result')
 need(boot['status']=='PASS'and boot['steps']==95714 and boot['exact_independent_frame'],'bootstrap result')
 need(data['status']=='PASS'and data['retained_primitive_cfg_rows']==3154,'source result')
 need(marker['status']=='PASS'and marker['guarded_cases']==20 and marker['states']==220,'marker result')
 need(window['status']=='UNIVERSAL_ALL_INITIAL_TAPES_STUTTER_EQUIVALENCE_PASS'and window['closure_windows']==86387 and window['nontrivial_windows']==128,'window result')
 need(ind['status']=='PASS'and ind['closure_states']==86387 and ind['nontrivial_cutpoints']==128,'independent window result')
 result=dict(status='PASS',python=platform.python_version(),parent_manifest=110,parent_universal_cases=5060,parent_bootstrap_steps=95714,source_exterior_rows=3154,marker_cases=20,marker_tests_normal=18,marker_tests_optimized=18,structural_tests=11,window_pairs=86387,nontrivial_window_cases=128,optimized_refusals=3,states=220,rows=440,native_sha256=sha(W/'machine/u220.native.tm'),dense_sha256=sha(W/'machine/u220.tm'),scope='Exact offline artifact replay plus finite symbolic proof certificates; conventional mathematical PA calibration is in the report and inherited packet')
 print('REPLAY_RESULT='+json.dumps(result,sort_keys=True),flush=True)
