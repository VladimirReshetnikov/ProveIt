# Research Report 42

A Paid Arithmetic Initialization for a Fixed Periodic Langton Ant

Uniform binary word recoding with an explicit Pell macro

3 October 2026

## Main result and boundary

The fixed initializer uses 2,306,387 operations (1,153,192 multiplication and 1,153,195 addition/subtraction gates), 234 equations, and 396 new strictly positive internal witnesses. These counts are independent of the two raw binary-sentinel word lengths. Five inherited parent geometry/initialization expression ports remain explicit. This is not a merged universal arithmetic record.

The article contains the all-length recoder proof, the explicit 70-operation power macro, the exact periodic rectangle and patch formula, source ledgers, the qualitative history/endpoint composition, and limitations. The source graphs and independent checks are included. The full earlier Report 40 physical-template packet is a cited dependency rather than duplicated here. Its colour-recipe read closure is preserved as under1MB of exact source/data; projected template maps retain original and projection hashes. No recipe program is run.

## Contents

- `Research_Report42.tex` and `Research_Report42.pdf`: complete article
- `science/`: byte-preserved compact scientific packet with the periodic wrapper, all-length splice, exact-degree and single-equation sources, proofs, anchor data, recipe assets and reference receipts
- `science/dilation/`: final recoder proof, guarded normal/optimized checker, six authoritative arithmetic graphs and reference receipt
- `recoder-degree/`: separate exact sparse-polynomial degree and SOS checker for the recoder
- `dependencies/`: compact scientific snapshots, source/license pins and read-only colour-recipe reference; no file here is executed by replay
- `verification/`: independent audit findings and receipts, release/visual review records
- `verify_release.py`: strict inventory authentication followed by isolated own-code replay
- `build_pdf.py`: deterministic no-shell-escape local TeX rebuild in a fresh external directory
- `archive_release.py`: deterministic ZIP builder
- `MANIFEST.json`: complete release file inventory excluding only itself; authenticate its SHA256 from the enclosing delivery

Some source proofs intentionally retain their earlier conditional component scope. `science/PROOF.md` is the fixed-length predecessor and conditional wrapper; `science/COMPOSITION.md`, the final recoder theorem and the article supply the all-length composition. Historical receipts describe exactly their own tests, not every later conclusion.

## Trust and preexecution authentication

Obtain the manifest SHA256 from the enclosing delivery or another trusted channel. A manifest stored beside a payload cannot authenticate an attacker who replaces both. Before executing any archived scientific script, inspect the verifier or use an independently written standard-library inventory check to authenticate every file against that trusted manifest hash. The delivered release was authenticated externally before its own verifier was invoked.

The inventory rejects extra/missing files, symlinks, nonregular paths, changed bytes, sizes, modes, duplicate JSON keys and unexpected directories. It does not depend on an upstream program or import archived dependencies. For a release already authenticated externally, run:

    python3 -I -B verify_release.py --manifest-sha256 TRUSTED_HEX --verify-only

## Isolated scientific replay

Use Python 3.10 or later (the release was checked with Python 3.12). No nonstandard Python packages are needed for the scientific checks. Choose an output directory that does not exist and whose parent exists, outside this release:

    python3 -I -B verify_release.py --manifest-sha256 TRUSTED_HEX --output /absolute/path/new-replay

This authenticates the inventory before science, copies only the own-code arithmetic components into isolated work areas, and performs:

1. Normal bridge geometric/patch/raw/residual checks and both full 2.3-million-gate predecessor/wrapper streams
2. A full composed 2,306,387-gate stream, with exact topology, counts, source hash and expression aliases
3. Forty-eight independent off-solution splice comparisons and eight malformed-source cases
4. Normal and optimized recoder checks, with explicit checks active in both modes
5. A fresh byte-identical rebuild of all six recoder DAGs and its reference receipt
6. Full initializer degree propagation and a 2,307,088-operation single-equation source stream
7. Normal and optimized exact sparse-polynomial recoder degree/SOS verification
8. Six optimized bridge/splice/degree/folding invocations that must reject immediately because their scientific checks use assertions

Normal assertion-dependent checks are not silently skipped. An optimized rejection is a guard test, not an optimized scientific success. The bridge's checker compares its stored receipt without writing; all scientific source copies must retain their bytes, modes and timestamps. Original release bytes, modes and timestamps must remain unchanged. Logs, receipts and any caches remain outside the release.

The replay does not run upstream Lean, upstream code, the frozen ant colour generator, saved ant schedules, a dense literal board, the inherited parent-history checker or the astronomical literal-constant prefix. Small numerical checks supplement the mathematical proofs; they do not establish all-input exponentiation by testing.

## Deterministic PDF rebuild

Requires a local TeX Live installation with pdfLaTeX, Latin Modern, microtype, amsmath/amsthm, geometry, enumitem, fancyhdr, needspace, hyperref and xurl. No TeX packages are downloaded. Choose another new external directory:

    python3 -I -B build_pdf.py --output /absolute/path/new-pdf-build --check-packaged --manifest-sha256 TRUSTED_HEX

The builder makes three no-shell-escape passes with `SOURCE_DATE_EPOCH=1790985600` and verifies byte identity with the packaged PDF. Exact PDF bytes are a same-toolchain guarantee; a different TeX version can produce different bytes from the same mathematical source. The original release is never a TeX output directory.

## Deterministic ZIP rebuild

After authenticating the release:

    python3 -I -B archive_release.py --manifest-sha256 TRUSTED_HEX --output /absolute/path/new-report42.zip

Files are sorted, modes normalized to 0644 and timestamps fixed to 3 October 2026. The ZIP top-level folder is `ant-initialization-report42`. An existing destination is refused. The archive's SHA256 is kept outside the archive to avoid self-reference.

## Scientific limitations

- The 396 count concerns new internal positive witnesses, not inherited ports or arithmetic gate values
- Forward/reverse outputs are unique; complete witness tuples are not single-fold or finite-fold
- Huge periodic coefficients are fixed by a pinned recipe and are not materialized
- The strict literal-1-and-3 initializer count is 554,386,261,710,211,459 operations; that source grammar is specified, not expanded
- The parent 174-operation history and endpoint selector retain their own port, witness and constant conventions
- The initializer-only single polynomial is paid: 2,307,088 operations, exact degree 2,304,000, 396 positive witnesses; fully merged history/endpoint counts remain distinct work
- No new minimal count, new proof of Diophantine exponentiation, or new qualitative ant universality is asserted

No upload, public repository write, external communication, or saved-schedule execution is part of this release workflow.
