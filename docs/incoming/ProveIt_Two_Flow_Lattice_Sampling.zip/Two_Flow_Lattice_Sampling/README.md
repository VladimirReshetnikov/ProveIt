# Two-Flow Bijections for Demand Polytopes

**Full-coordinate sampling, exact certificates, restriction laws, and preorder applications**

Research manuscript prepared for Vladimir Reshetnikov with ChatGPT, 30 September 2026.

## What this package supplies

For a bipartite graph with suppliers X and receivers Y, a demand vector c is a nonnegative integer vector satisfying

    sum(c[y] for y in A) <= number of suppliers adjacent to A

for every receiver subset A. The manuscript gives mutually inverse polynomial-time maps between full demand vectors of positive support J and supplier subsets I perfectly matchable to J. Each support pair is counted once, regardless of the number of perfect matchings realizing it.

The maps use a fixed cycle-generic edge-cost system and exact min-cost transportation. The forward and inverse optimizers have the same tree support. A smaller forward implementation solves a flow only on the selected suppliers; every unselected supplier then makes one independent reduced-cost choice. Exact primal/dual certificates check the optimizers and decoded coordinates.

Composing this bijection with the established matroid basis walk gives an almost-uniform sampler of actual demand vectors and, in particular, actual lattice points of every finite preorder polytope. It does not merely sample their supports. The change of coordinates preserves total-variation error exactly.

**Prior work:** the abstract geometric correspondence is due to Suho Oh (2013), and the general matroid mixing theorem is due to Anari–Liu–Oveis Gharan–Vinzant. The manuscript does not claim either as new. Its constructive refinements, certificates, restrictions, and full-coordinate implementation address the explicit sampling boundary in the pinned ProveIt report. Worldwide first priority of the particular algorithmic formulation has not been established. See `SOURCE_AUDIT.md` and `PROOF_STATUS.md`.

## Repository provenance

Repository: VladimirReshetnikov/ProveIt

Pinned commit:

    6d04e1e385f2fe7d1cfbdbd8fd8d4e45bd6b6c72

Continued report:

    SetTheory/Cardinals/docs/reports/enumerative-combinatorics/
    preorder-root-polytopes/article.tex

Blob:

    920246d173bfbc708bcfdd6d67e0a6fc358cb3dc

The identified question is the “Sampling boundary” box in the source interval 9510–9555, following “Sampling after fixing the support size.” The full-coordinate part is answered. Restriction compatibility is proved in precise senses: receivers outside the support, and suppliers outside the selected basis. Arbitrary minor compatibility is not asserted. No repository file has been edited or committed.

## Contents

- `article.tex`, `article.pdf`: 23-page article with full proofs, implementation details, limitations, and eight proposed research questions.
- `code/transport_bijection.py`: standard-library reference implementation, including full/core forward maps, inverse, exact checkers, matching oracles, and unconditioned basis-walk sampling.
- `code/verify.py`: exhaustive and independent finite checks, compatibility checks, exact rational chain checks, and worked certificates.
- `data/*.json`: recorded outcomes and the worked example.
- `data/verification_run.txt`: execution output for all suites.
- `PROOF_STATUS.md`: proof and implementation boundaries.
- `SOURCE_AUDIT.md`: literature and repository audit.
- `build.sh`: PDF rebuilding script.

## Run the implementation

Python 3.10 or later is required. No external Python package is required. From the package directory:

```sh
python code/transport_bijection.py
python code/verify.py --suite all
```

The verifier writes fresh reports into `data/`. Run on a copy to preserve the delivered records. Timing fields are expected to vary.

Individual suites are `small`, `four_by_three`, `preorders`, `random`, `chain`, and `example`.

A programmatic example, with `code/` on Python's module search path:

```python
from random import Random
from transport_bijection import BipartiteDemand, preorder_graph

H = BipartiteDemand(4, 3,
    [(0, 0), (1, 0), (1, 1), (2, 1), (2, 2), (3, 2)])
I, J = (0, 1, 3), (0, 1, 2)

c, certificate = H.basis_to_demand_core(I, J, certificate=True)
H.verify_core_certificate(c, certificate)
assert c == (1, 1, 2)
assert H.demand_to_basis(c) == (I, J)
assert H.basis_to_demand(I, J) == c

# Actual coordinates of a sampled demand vector, not just its support.
sample = H.sample_demand(0.05, rng=Random(20260930))
assert H.is_demand(sample)

# rows[x] lists all y with x <= y. This is the three-element chain.
P = preorder_graph([{0, 1, 2}, {1, 2}, {2}])
point = P.sample_demand(0.05, rng=Random(123))
```

The dummy receiver is `-1` in code; ordinary suppliers and receivers are zero-based. The article uses a separate dummy symbol 0, and its worked figure uses one-based ordinary labels. `data/example.json` uses the code labels.

The `edge_order` constructor argument can specify any ordering of all ordinary edges and dummy edges. It determines the powers-of-two costs and can change the bijection, but not the exact uniform target law. Restriction theorems keep inherited costs fixed. Do not silently replace inherited costs by an unrelated ordering.

## Sampling scope

`sample_demand` uses the lifted matroid down-up walk, a conservative integer mixing budget, and the core decoder once at the end. It directly supports positive integer receiver activities via `support_weights`. Those activities weight presence in the support, not the magnitude of the coordinate. The mathematical rational-activity and support-conditioning extensions are specified in the article but are not separate API wrappers in this reference implementation.

The theorem assumes ideal random bits. The implementation uses Python's pseudorandom generator, with optional seeded reproducibility. The exact maps and certificate checks are deterministic. Supplying a smaller `steps` override disables the asserted conservative mixing guarantee; it is intended for experiments, not for a certified error claim.

Neither an exact i.i.d. uniform sampler nor a production-optimized large-graph sampler is claimed. The general FPRAS machinery is cited rather than reimplemented.

## Executed checks

All suites passed:

- 4,785 exhaustive bipartite graphs: all graphs with both shore sizes at most three, and all 4-by-3 graphs; 74,712 matchable support pairs, all demand vectors, inverse identities, common trees, full/core agreement, and certificates.
- All 390 labeled preorders on at most four elements; 12,709 lattice points tested against independently enumerated lower-ideal inequalities.
- 250 seeded random graph/cost-order cases; 4,256 feasible-pair trials, 9,427 restriction/deletion checks, and 8,512 chamber/gauge checks.
- Two 17-state exact rational chains, plus rejection of three corrupted certificates.

These are finite verification results, not a replacement for the general proofs and not a Lean/Rocq verification.

## Rebuild the article

A reasonably complete TeX Live installation is needed, including `newpx`, `tcolorbox`, `tikz`, and the standard AMS packages.

On Unix-like systems:

```sh
sh build.sh
```

On Windows, run the commands directly in the package directory:

```text
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The extra pass stabilizes the table of contents and cross-references. No bibliography program or external figure download is needed.
