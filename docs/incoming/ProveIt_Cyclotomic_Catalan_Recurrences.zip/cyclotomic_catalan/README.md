# A One-Defect Law for Cyclotomic Catalan Hankel Recurrences

**Date:** 29 September 2026  
**Prepared with:** OpenAI ChatGPT  
**For:** Vladimir Reshetnikov's ProveIt research program

## Contents

- `article.pdf`: the complete 22-page typeset research article.
- `article.tex`: self-contained LaTeX source, including bibliography.
- `code/verify.py`: exact, standard-library-only verification and factorization code.
- `data/verification_summary.json`: counts and status of the full audit.
- `data/verification_run.txt`: full-run console transcript.
- `data/cyclotomic_orders.json`: the 264 principal parameter cases, with exact minimal characteristic multiplicities.
- `data/orders_c1_c2_c3.csv`: rational examples through multiplicity 20.
- `SOURCES.md`: pinned repository provenance, source comparison, and novelty limitations.
- `Makefile`: build and verification commands.

## Mathematical result

For the size-N Catalan Hankel determinant with multiplier `(x-c)^t`, with
`c != 0,4`, write `c = 2 + z + 1/z` and let `L = ord(z^2)`.

When `L > t` (including infinite order), the minimal recurrence order is

    R_generic = t + 1 + binomial(t+1, 3).

When `3 <= L <= t`, put `eta = 1` when `t` and `L` have the same parity,
and zero otherwise. The exact order is

    R = L*(3*t^2 - L^2 + 13 - 3*eta)/12 - delta,

where `delta` is either zero or one. It is one exactly when the parities
agree and `(-1)^(L*(t+1)/2) * z^(L*t) = -1`.
The article determines every characteristic-root multiplicity, not just R.
The one-defect statement concerns cancellation **after** equal exponential
rates have been grouped; grouping itself can already reduce the generic
order by much more than one.

The extra sign `z^L` is necessary. Multiplicity three with `c=1` and `c=3`
has the same `L=3` but minimal orders seven and six, respectively.

The center `c=2` is an exceptional whole-sector cancellation, governed by
Cigler's known middle-binomial determinant product. Its orders are
`t^2/4 + 1` for even t and `(t^2+3)/2` for odd t. The central product is
credited as a known result, not claimed as new.

A further theorem gives a **root-free factorization** of the minimal
characteristic polynomial over the field containing c. Two short scalar
recurrences in `c-2` detect the relevant resonance and supply all the
linear/quadratic factors. The factored answer takes O(t) exact field
operations and equality tests; this is not an expanded-output or
bit-complexity bound.

## Proof and novelty status

This is an unrefereed AI-assisted manuscript, not a Lean formalization.
Its universal assertions have ordinary mathematical proofs in the article.
Finite checks are an independent audit, not the basis for the universal
claims. The full run passed **22,124 exact assertions**.

The proposed extension is the noncentral cyclotomic cancellation theorem,
its explicit first centered coefficient, and the resulting complete
factorization and order classification. Classical Christoffel identities,
the repository's prior generic degree law, and Cigler's central product are
not new claims. First-discovery priority has not been established.

The article does not solve multi-root resonance in general, does not claim
uniform collision asymptotics, and does not transfer its characteristic-zero
minimality theorem unchanged to positive characteristic. It includes eight
precise further research directions.

## Reproduce the verification

Python 3.10 or later is sufficient; no third-party packages, network access,
floating point, or CAS are needed.

```sh
python3 code/verify.py
```

This regenerates the data files in `data/`. A smaller principal grid, kept
separate from the full-run records, is available with

```sh
python3 code/verify.py --quick --output data_quick
```

The main grid uses primitive z-orders 3 through 24 and multiplicities 1
through 12. Tests include division-free sector polynomials, first centered
coefficients, full reflection identities, actual grouped polynomial degrees,
root-free factorization, independent cyclotomic moment determinants,
integer moment matrices versus normalized-jet determinants, the central
product, exact condensation ratios, and the worked residue-class formulas.

`root_free_factors(t, c, ring)` implements the factorization theorem for the
exact coefficient-ring interface used by the audit. It reads neither the
spectral generator nor the cyclotomic order. Its output is a list of pairs
`(polynomial_coefficients, exponent)`, with ascending coefficient order.
For example:

```python
import sys
sys.path.insert(0, "code")
from verify import CyclotomicRing, root_free_factors

ring = CyclotomicRing(12)
c = ring.add(ring.integer(2), ring.add(ring.zp(1), ring.zp(-1)))
L, factors = root_free_factors(8, c, ring)
assert L == 6
assert sum((len(p) - 1) * e for p, e in factors) == 82
```

Here c is `2 + sqrt(3)` in its exact cyclotomic representation. The output
is equivalent to

    (X-1)^17 (X+1)^7 (X^2+X+1)^13 (X^2-X+1)^16.

The program is an auditable reference implementation. In particular, the
subset expansion is deliberately exponential in t and is used for testing;
it is not the fast classification algorithm. The separate root-free routine
provides the compact minimal-polynomial factors without forming determinants.

## Build the PDF

A TeX Live installation with the standard `newtx`, `mathtools`, `amsthm`,
`geometry`, `microtype`, `booktabs`, `fancyhdr`, `titlesec`, `tocloft`,
`enumitem`, `listings`, `xurl`, and `hyperref` packages is sufficient.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `make pdf`. No separate bibliography processor is needed.
The supplied PDF was rendered and visually inspected.
