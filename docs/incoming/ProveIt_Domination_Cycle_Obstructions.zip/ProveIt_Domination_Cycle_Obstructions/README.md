# Cycle Budgets for Integer Domination Roots

A research article prepared with ChatGPT for Vladimir Reshetnikov, 30 September 2026.

## Read

`article.pdf` is the complete article. `article.tex` is a self-contained source:
tables, diagrams, and bibliography are embedded; no external figures or font
files are needed.

The article continues ProveIt's domination-root-minus-four-order-30 report,
inspected at commit `0744012ba29db0e345c44be953c6de3e000439e6`.

## Main results

For a finite simple graph let beta = edges - vertices + components.

* A conventional proof of the sharp bound 1 <= |D(G,-1)| <= 3^beta.
  The upper bound is attained by connected planar subcubic graphs at every beta.
* A simultaneous integer-root multiplicity budget:
  product (k_j-1)^r_j divides D(G,-1) and is at most 3^beta.
* The exact absolute evaluation spectrum for beta <= 2 is {1,3,7,9}.
  This has a conventional matrix proof and excludes a root -6 throughout
  the entire class, without a vertex-count bound.
* The exact spectrum for beta <= 3 is {1,3,5,7,9,11,15,17,21,27}.
  The finite part uses fifteen exhaustively generated kernels and 26,688
  exact residue assignments. It excludes, for example, a root -14 and a
  double root -6 at cycle rank at most three.
* The repository's zero-C four-cycle search architecture forces |D(-1)|=3;
  its only possible integer root below -2 is -4, and that root is simple.

These results do NOT construct roots -6 or -8, do not settle minimum order
for a root -4, and do not claim that the arithmetic necessary conditions
are sufficient. The article gives specific further research questions.

## Reproduce the certificates

Python 3.10 or later, standard library only:

```sh
python3 code/verify.py
python3 code/check_repo_example.py
```

`verify.py` generates the kernel catalogue from scratch, checks the signed
state closure and transfer matrices, evaluates all residue assignments,
constructs witnesses, and compares independent exact algorithms on all
1,100 labeled graphs through order five and supplementary seeded tests.
It writes `results/verification.json`, `data/kernel_certificate.json`, and
`data/spectrum_witnesses.json`.

`check_repo_example.py` verifies D(G30,-1)=-3 from the pinned original edge
list, gives the full polynomial of the eight-vertex H5 example, and checks
the subcubic equality examples through cycle rank six. It writes
`results/example_checks.json`. It does NOT reprove the original root -4;
that fact is credited to the repository's certificate.

The recorded runs pass. Finite tests alone do not establish universal
claims; the article supplies the all-graph reductions and proofs.

## Build the PDF

A standard TeX Live installation with newtx, TikZ, and tcolorbox suffices:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Or run `pdflatex` three times to stabilize the contents and references.
No shell escape or internet access is required.

## Status and provenance

This is an unrefereed research manuscript, not a Lean formalization.
The three-cycle classification is computer-assisted; the general bound,
root budget, pruning and transfer identities, bicyclic classification, and
search obstruction have conventional proofs. Publication priority has not
been established. `SOURCE_AUDIT.md` separates prior results from the new
derivations relative to the inspected report.

`SHA256SUMS.txt` records the delivered files. The two TeX table files in
`data/` are also supplied as convenient standalone extracts, but the main
TeX document does not depend on them.
