# Local Compactness Forces Arithmetic Rigidity

## Borel ordered groups, Presburger models, and multiplication without regularity assumptions

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov, 3 October 2026.

## Main result

Let A be a nonzero commutative unital discretely ordered ring. If its additive
group has a Hausdorff locally compact second-countable group topology and its
positive cone is Borel, then that topology is discrete and A is countable.
No measurability or continuity of multiplication and no induction scheme
are assumed.

The proof combines an algebraic amplification lemma with classical facts
about measurable orders and locally compact abelian groups. An uncountable
real identity component C would inject into the countable additive quotient
A/C by c -> uc + C, for an appropriate positive additive order unit u in C.

The article also proves a pointed topological-group classification of locally
compact Borel signed Presburger models, exact regularity statements for their
positive cones, continuous standard division, and a countability theorem for
Borel scalar multipliers of an arbitrary integral-domain multiplication.
Set-sized omnific and surreal examples, counterexamples to weakened
hypotheses, a formalization plan, and eight further research questions are
included.

## Status and scope

The central results have mathematical proofs in the manuscript. Bibliographic
priority has NOT been established, and no independently certified
breakthrough is claimed. This is an AI-assisted, unrefereed research draft.
It has not been Lean-verified. The underlying group is the signed additive
group; an arbitrary topology on a positive monoid is not silently assumed
to extend to a locally compact group topology.

Classical Presburger elimination, the principal LCA structure theorem,
measurable-order results, and automatic continuity are credited. The earlier
user-library companion constructions are distinguished from the proposed
contributions here. See sources.md and proof_audit.md.

## Files

- article.tex: complete LaTeX source, with an internal bibliography.
- article.pdf: compiled manuscript.
- verify.py: exact finite arithmetic regression checks; standard library only.
- verification_results.json: recorded results of executing the checks.
- build.sh: rebuilds the article and reruns the checks.
- sources.md: source provenance and repository inspection boundary.
- proof_audit.md: theorem dependencies, assumptions, and checked pitfalls.
- SHA256SUMS: hashes of all the preceding files and this README.

No separate bibliography database, font files, third-party PDFs, or network
access are needed to rebuild the document once the TeX packages are installed.

## Rebuild

Requirements: Python 3.10 or later, pdfLaTeX, latexmk, and a TeX Live
installation with the packages used in article.tex (including newpxtext,
newpxmath, microtype, tcolorbox, xurl, hyperref, bookmark, and cleveref).
The finite checks were run using Python 3.13.5.

On a Unix-like system:

```sh
./build.sh
```

Or run these commands from this directory, including on Windows with suitable
TeX and Python installations:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
python3 verify.py --output verification_results.json
```

A successful run reports 24,470 passing exact checks: 7,595 standard-division
cases, 9,000 coset-invariant finite-witness cases, 1,875 polynomial-amplification
tuples, and 6,000 lexicographic-order triples. All rational calculations use
fractions.Fraction, not floating point. Fixed seeds make sampled tests
reproducible.

The tests do not prove any theorem about all real points, Borel sets, Haar
measure, topology, or infinite cardinalities. Those conclusions depend on
the mathematical arguments in the article.

The delivered PDF was rendered and visually inspected. PDF hashes may change
on rebuilding because of TeX metadata even when the content is unchanged.
