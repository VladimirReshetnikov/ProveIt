# Subset-only closure kernels for a small ZFC-consistency machine

Research report prepared for Vladimir Reshetnikov, 16 October 2026.
Start with **article/report.pdf** (24 pages). The self-contained LaTeX source
includes the bibliography. This archive contains original report, reference,
and audit artifacts; it does not contain a new Turing-machine table.

## Main result

The inspected predecessor explicitly left open whether the membership arm
could be removed from its point-seeded mixed-bound closure schema. This report
proves that it can, for both point and subset seeds.

For each definable binary relation R, write

    SB(R) := forall x exists b forall y (R(x,y) -> y subset b).

The new schema says that SB(R) implies, for every seed a, an output set C with:

    ((sigma(x,a) OR x in C) AND R(x,y)) -> y in C,
    y in C -> exists x R(x,y).

Here sigma is x=a (point seed) or x subset a (subset seed). All parameters are
universally closed, and all auxiliary binders are fresh for the matrix.

The new positive-transitive-cover lemma proves

    forall A exists C (A subset C AND C is transitive)

without first using Separation, Union, or Extensionality. It combines
constant-relation singleton formation with the predecessor's singleton/subset
switching relation. A cover of a mixed bound is a pure subset bound. Thus the
pure and mixed schemas are deductively equivalent.

Consequently Extensionality plus either pure schema is deductively equivalent
to ZF without Foundation and Choice, with functional Replacement and full
Separation. Replacing equality by membership-profile equivalence and adding
one congruence sentence gives the recommended equality-free Q_subset theory.
The report proves the ZFC consistency calibration mathematically.

## Comparison and limits

The same formula-tree metric used by the inspected predecessor gives:

| Candidate | Mixed | Pure |
|---|---:|---:|
| Point seed + Extensionality | 69 | 65 |
| Subset seed + Extensionality | 72 | 68 |
| Subset seed + profile congruence | 83 | 79 |

These counts exclude variable payloads, parameter closure, equality support,
proof-engine code, and the entire machine backend. They are **not TM state
counts**. The four-node reduction is a proved theory simplification, not a
claimed sub-254-state construction or an absolute minimality result.

The imported 254-state table was independently hash-checked and parsed. A
coarsest tape-preserving state-congruence refinement has 254 singleton blocks;
there is no nontrivial merge under that context-free criterion. All 254 states
are graph-reachable when symbol constraints are ignored. A 264,982-step blank
prefix was simulated. None of these finite/static checks establishes the
end-to-end set-theoretic specification or proves nonhalting.

## Reproduce

Python 3.10+ and the standard library suffice for the reference checks:

```sh
python3 build.py --tests --skip-pdf
python3 code/logic.py examples/identity.json
python3 code/codec.py --stop 10000
```

The example is a valid five-line proof of A -> A, **not a refutation**.
The bounded search reports only a finite prefix; no consistency conclusion
follows from it. All 20 unit tests and the finite experiments passed in the
delivered run. Their actual outputs are under `results/`.

For the PDF, install `pdflatex` and the standard packages listed in the
preamble, then run:

```sh
python3 build.py --tests
```

Do not run Python with `-O` or `PYTHONOPTIMIZE`; the finite experiments use
assertions. The PDF build writes intermediates only to `.build/`. PDF digests
can change on rebuild because of TeX timestamps and tool versions.

The table is not redistributed. Obtain the exact pinned table identified in
`provenance/sources.json`, then run:

```sh
python3 code/tm_audit.py /path/to/zfc_254.tm --steps 264982 \
    --out results/tm_audit.json
```

## What is and is not delivered

Delivered: detailed mathematical proofs, the new closure schema, equality-free
calibration, an executable certificate reference, a fair prefix codec and
bounded search demonstrator, syntax metrics, finite regressions, independent
machine-audit code and actual results, provenance, and a certification plan.

Not delivered: a new literal TM, a state-count improvement, a completed Lean
development, an exported ZFC or PA derivation, a verified Python implementation,
a full source-to-TM compiler, or a replay of upstream Coq verification. The
specified ideal unbounded proof search has the stated mathematical correctness;
the reference Python code is not promoted to a certified small-machine result.
Resource errors are not silently interpreted as invalid certificates.

## Provenance and attribution

The three distinct requested ProveIt commits are recorded in
`provenance/sources.json`; the duplicated first SHA is treated once. The base
article and metric source are pinned to `83ef1da6b717338f710277c2744fb4ec644cedbc`.
The imported machine is pinned to
`67086c8d8802ea7b3625a2fc0765d39e2181e335` and its upstream snapshot to
`297ab8df7e5de329605c3875b4934643b371a5e3`.

The machine design is Mira-Cult's; the imported Coq verification is Jeff's.
Their sources are not redistributed or relicensed. The singleton/subset
switching relation and the mixed-schema framework are credited to the
predecessor. The positive-cover bootstrap and membership-arm elimination are
new contributions relative to that inspected manuscript, not claims of
historical priority. See `notes/DELTA.md` and the report's review boundary.

`SHA256SUMS` covers release files other than itself. `python3 verify_release.py`
checks the delivered bytes. Rebuilding may legitimately change generated files.
