# Report62: Fixed-center projective returns with five live signals

This release presents the frozen fixed-center projective construction and its independently checked mixed-clock example. Its mathematical claims and limitations are stated in the report and the original source-bound audit. Release tooling performs typesetting, file authentication, and packaging only.

## Contents

- `Report62.pdf`: final typeset report after build and review
- `Report62.tex`: standalone editable source, exactly the deterministic flattening of the nine files in `manuscript/`
- `science/frozen-proof/`: complete unchanged 14-file scientific packet, including inert source code and its two original dependency proof copies
- `audits/scientific/`: complete unchanged nine-file source-bound independent audit, including its checker and original evidence
- `dependencies/proofs/`: the two unchanged inert dependency proofs, with provenance
- `INPUT_PINS.json`: exact frozen inventories, including bytes, SHA-256, file/directory modes, and nanosecond modification times
- `tools/`: owned release helpers and the separately reviewed portable independent replay when integrated
- `qa/` and `manuscript-review/`: assembly, release-tool, build, preservation, and independent manuscript/visual evidence as assembled for the final release

All files under `science/`, `audits/`, and `dependencies/` are frozen. Later release-tool, manuscript, or replay review evidence belongs under `qa/` or `manuscript-review/`, never under those frozen roots. Neither the author scientific checker nor any upstream program, simulator, saved schedule, or Lean source is executed by these release tools. The independent replay has its own reviewed runner and instructions; it is not part of the TeX build.

## Trust and execution boundary

Use the installed Python interpreter and TeX Live/Poppler tools recorded by the final dependency lock. These commands require Python `-I -S -B` without optimization. They do not install anything. Every destination must be a new canonical absolute path with an existing parent, outside the release and original frozen source roots. Symlinks, hardlinked input files, path aliases, overlapping outputs, and unexpected tree entries are rejected. A late failure may leave its new output directory for inspection; existing outputs are not overwritten.

The release manifest pin, manuscript pin-map digest, and dependency-lock digest must be obtained from the separately supplied reviewed release receipts. A hash is an integrity commitment, not a digital signature. Do not treat an untrusted file and a digest supplied alongside it as independent authentication.

The executable/TeX lock covers the running Python interpreter, invoked TeX/Poppler binary bytes, selected font maps, and the union of system inputs reported by the fresh-format recorder and all three document TeX passes. It deliberately does not inventory shared libraries, Python's standard library, or the operating system. It is not a sandbox for hostile TeX or Python. The inputs are reviewed owned manuscript code and pinned system packages.

## Authenticate frozen inputs

From this release directory:

    python3 -I -S -B tools/release62.py check-inputs

This checks complete file and directory inventories and original metadata. It only reads scientific sources as inert bytes.

## Rebuild a reviewed release

Substitute the separately supplied trusted pins:

    python3 -I -S -B tools/build_report62.py \
      --pins-sha MANUSCRIPT_PINS_SHA256 \
      --dependency-lock-sha BUILD_DEPENDENCIES_LOCK_SHA256 \
      --require-packaged-match \
      --output-dir /tmp/report62-rebuild-new

The builder verifies all locked executable and system-input bytes before launching subprocesses, creates a fresh format in an isolated temporary tree, disables shell escape and automatic font generation, and compiles three times. It saves each recorder before the next pass can overwrite it; an input read only on the first pass remains in the checked union. The post-build dependency receipt must equal the preflight lock exactly. Executable bytes are checked before every subprocess and again after rendering.

Every PDF page is rendered. The exact PNG inventory is compared with the PDF page count, and each PNG's signature, chunk order and CRCs, dimensions, decompressed raster size, stream completeness, and row filters are checked. Final overfull boxes and unresolved references are rejected. Human all-page visual review is a separate required release check.

`BUILD_RECEIPT.json`, `BUILD_DEPENDENCIES.json`, `RECORDER_INPUT_UNION.json`, four `.fls` files, complete command outputs, `PAGE_INVENTORY.json`, and before/after preservation snapshots remain in the fresh output directory. `PASS` is emitted only for a lock-verified build. The original release remains unchanged.

## Owned preparation and initial dependency bootstrap

These commands are release-authoring operations, not scientific reconstruction. Inspect newly written helpers before executing them and obtain independent review before final sealing.

    python3 -I -S -B tools/release62.py prepare \
      --output-dir /tmp/report62-prepared-new

The helper writes `Report62.tex` and `MANUSCRIPT_PINS.json` externally. The manuscript owner may copy them to the release root and `manuscript/`, respectively, after inspection. The helper never rewrites the manuscript itself.

    python3 -I -S -B tools/build_report62.py \
      --pins-sha INSPECTED_MANUSCRIPT_PINS_SHA256 \
      --bootstrap --output-dir /tmp/report62-bootstrap-new

A successful bootstrap is explicitly labeled `BOOTSTRAP`; it has no preflight toolchain-lock guarantee. Promote its exact `BUILD_DEPENDENCIES.json` bytes to `tools/BUILD_DEPENDENCIES_LOCK.json`, review that file and obtain its external digest, then use the locked build command. Never claim the bootstrap itself was lock-verified. A change to manuscript packages can require a new reviewed bootstrap and lock.

Owned regression tests use separate synthetic manuscripts, never scientific source execution:

    python3 -I -S -B tools/selftest62.py \
      --output-dir /tmp/report62-tools-selftest-new

These tests are self-testing, not independent approval. They include a deliberately first-pass-only package input, controlled input/metadata corruption, path and alias rejection, invalid PNGs, deterministic archive equality, metadata-restoring extraction, and a relocated byte-identical PDF rebuild.

## Seal, archive, and relocate

Create a prospective manifest outside the release after all intended evidence is assembled:

    python3 -I -S -B tools/release62.py manifest \
      --output /tmp/report62-manifest-new.json

After inspection, copy those exact bytes to `RELEASE_MANIFEST.json`. Record its SHA-256 through the separate reviewed channel. Manifest generation deliberately excludes the manifest's own bytes and release-root metadata, but includes every other file and all subdirectory metadata. Changes after sealing require a new prospective manifest and pin.

    python3 -I -S -B tools/release62.py verify --manifest-sha256 MANIFEST_SHA256
    python3 -I -S -B tools/release62.py archive \
      --manifest-sha256 MANIFEST_SHA256 --output /tmp/Report62-source-evidence-new.zip

ZIP order, compression parameters, timestamps, and regular-file modes are deterministic. Repeated archives of the same sealed release must be byte-identical. Use the supplied extractor to restore exact nanosecond mtimes and modes; ordinary ZIP extraction does not preserve all authenticated metadata:

    python3 -I -S -B tools/release62.py extract \
      --manifest-sha256 MANIFEST_SHA256 \
      --archive /tmp/Report62-source-evidence-new.zip \
      --output-dir /tmp/Report62-relocated-new

The extractor authenticates the archived manifest using the external pin before writing, rejects duplicate or unexpected entries, checks every payload and CRC, and restores metadata. Run `verify`, the locked PDF rebuild, and the separately reviewed portable replay in the relocated directory. Include that successful extraction roundtrip in final release evidence.

## Scientific scope

The report concerns fixed-center projective returns with positive homogeneous center coefficient and an invertible rational planar block, realized with exactly five live signals. The 44-event example distinguishes Zeno and non-Zeno infinite validity in one fixed word. Native-gap positive-integer polynomial certificates are exact support within their stated domains. Finite symbolic/static checks supplement conventional proof; they are not end-to-end formal verification or a collision simulation.

No arbitrary original-coordinate GL3 realization, priority, minimality, Turing completeness, or continuation beyond Zeno accumulation is claimed. See the manuscript, frozen `PROOF.md`, `LITERATURE_AND_SCOPE.md`, and the independent `REVIEW.md` for precise quantifiers and boundaries.

## Final inspected build details

The final manuscript has 22 pages. Its SHA-256 pins are:

- PDF: `1051897d89f648725ecb8c22634c67738606a7a07da9cfeeb973720c50b8f560`
- Standalone TeX: `3e7a002438b86eae5ef0a4156899185926ce9c838e9ac5ad466164fb52f0283d`
- Manuscript pin map: `643c37451af5fb280f9da64ab45ca26eef7a1f39c8fce71a24d3e5675df1adf3`
- Build dependency lock: `59ee80be4c4ff42f68e6b3613da2010f52831d34c65915a71cb6098d92c648e9`

The final owned release-tool selftest passed 39 tests, including separate TMPDIR, TEMP and TMP regressions and reserved manifest-directory rejection. The builder anchors its temporary TeX workspace inside the validated fresh external output directory, ignoring inherited temporary-directory choices. An earlier selftest and normal locked build are retained as historical evidence; `qa/final-locked-build/` records the corrected builder's byte-identical locked PDF rebuild, and `qa/RELEASE_TOOLS_SELFTEST.json` is the final owned suite. Independent tool acceptance remains separately source-bound.

The complete reviewed portable replay is integrated unchanged at `tools/portable-replay/`. Read its README for the Python/SymPy trust boundary. `qa/integrated-replay/` reproduces the original 157 static checks in the actual release layout. `qa/read-only-replay/` repeats them on a separate relocation whose science, audit, adapter and pins are read-only. All three golden outputs match byte-for-byte, and both input trees' bytes and metadata are preserved.

## Independent acceptance

- The frozen scientific audit accepts the conventional mathematics and records 157 named algebraic, structural and authentication checks; its count includes 44 literal-rule and 44 phase-speed comparisons
- `manuscript-review/REVIEW.md` accepts the final 22-page PDF and source, directly inspects every page, binds a fresh pixel-exact render, and records 142 fresh static/authentication checks with their proper scope
- `qa/release-tools-review/REVIEW.md` accepts the final helper sources after 127 independent checks and an independent rerun of the 39-case owned suite, including both corrected safeguards
- `tools/portable-replay/independent_review/REVIEW.md` accepts the unchanged-checker transport adapter, with 24 separate CLI cases and 6 facade edge checks in addition to its 42-case owned suite

These counts record different, overlapping verification activities and must not be summed or advertised as independent mathematical theorems. The final archive has its own separate manifest and external integrity pin.
