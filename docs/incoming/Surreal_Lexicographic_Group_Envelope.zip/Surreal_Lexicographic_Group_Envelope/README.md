# Lexicographic Well-Orders of the Surreals
## Singular permutation geometry and the canonical group envelope

Research manuscript prepared for Vladimir Reshetnikov, 3 October 2026.

## Contents

- `article.pdf`: compiled research article.
- `article.tex`: standalone LaTeX source with an internal bibliography.
- `build.sh`: three-pass PDF build; uses a temporary directory for auxiliaries.
- `code/finite_checks.py`: exact standard-library finite regression checks.
- `data/finite_checks.json`: recorded results and explicit scope limitations.
- `SOURCE_AUDIT.md`: inspected sources and provenance.
- `SHA256SUMS.txt`: checksums of the delivered files, excluding the manifest itself.

## Principal results relative to the inspected predecessor report

The article proves maximality and singular self-normalization of the two-sided
boundedness-preserving subgroup; identifies its forward closure and uniform
completion; describes a dense inverse-continuity locus that is completely
metrizable at countable cofinality; and constructs the coarsest group topology
finer than bounded-prefix agreement. This envelope is agreement on arbitrary
small sets, has character cof([mu]^{<mu}, inclusion), strictly greater than mu
at singular mu, and is complete for its two-sided group uniformity.

The discussion distinguishes all main interpretations of surreal well-orders,
reproves the required set-sized order theory, gives a direct comparison for
non-set-like class well-orders, and specifies size-safe class and Lean modeling
approaches. Twelve further research questions are included.

## Status

AI-assisted and unrefereed. Historical priority is not claimed. The new
mathematical results are supported by written proofs, not a new Lean kernel
verification. The repository was inspected at a pinned revision and was not
modified. No repository-wide build or audit was performed.

The full singular forward space's complete metrizability remains an explicit
question. A dense complete subspace and a complete finer uniform topology do
not settle it. The character lower bound concerns the coarsest group refinement;
it does not exclude other finer metrizable topologies, such as the discrete one.

## Rebuild

From this directory:

```sh
./build.sh
./build.sh --check
```

The build needs pdfLaTeX and the packages in the source preamble, including
`newtx`, `microtype`, `tcolorbox`, `titlesec`, and `hyperref`. The optional tests
require Python 3.10 or later and no third-party libraries. Neither operation
requires a network connection. PDF binary hashes may change on rebuilding
because of metadata or TeX-version differences.

To run only the tests:

```sh
python3 code/finite_checks.py --output data/finite_checks.json
```

The recorded tests check finite prefix convexity, conjugation and group-uniformity
identities, partial-injection extension, the common-prefix relation, and a
relation-code reversal. They do not prove singular-cardinal, completion, or
class-theoretic theorems. No external paper copies or font files are included.
