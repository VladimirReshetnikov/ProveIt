# Borel Presentations and Support Barriers in Omnific Arithmetic

## Scattered exponent orders, Hahn fields, and the exact discontinuities of finite normal forms

Research report prepared with ChatGPT for Vladimir Reshetnikov, 3 October 2026.
The PDF has 23 pages. The LaTeX source is standalone with an internal bibliography.

## Files

- article.pdf: complete article, proofs, eight further research questions, source audit, and contribution ledger.
- article.tex: source for the PDF; no external figures or bibliography database are required.
- verify.py: Python 3.10+ standard-library-only exact rational checks.
- verification.json: actual deterministic verification results: PASS, 84,388 assertions.
- provenance.json: repository revision, inspected guides, and validation scope.
- checksums.sha256: integrity hashes of the other files.

## Main results and their locations

- Theorem 3.4: for a fixed countable linear order L, its well-ordered subsets form a Borel set exactly when L is scattered; otherwise the predicate is coanalytic-complete.
- Theorem 4.1: exact support-validity complexities for Z and finite lexicographic powers Z^d, including sharp support-order bounds.
- Theorem 5.2: the corresponding criterion for coefficient-observable standard Borel presentations of full real Hahn fields over countable exponent groups, with Borel field operations on the positive side.
- Theorem 6.2: every Borel coefficient-observable family of valid series has a uniform countable bound on its support order types.
- Theorem 7.1: the non-Borel obstruction already occurs for binary coefficients in one fixed omnific interval.
- Theorems 8.2 and 9.3: an explicit finite-principal-part open-induction model, with exactly determined closed nowhere dense cancellation loci for addition and multiplication.
- Theorem 10.2: Glazer's theorem prevents any compatible Polish recoding from making addition globally continuous.

## Rebuild

With a TeX Live installation providing the packages named in article.tex:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

No BibTeX run or network access is needed. The delivered PDF compiled without
LaTeX warnings, overfull/underfull boxes, or undefined references.

## Reproduce finite checks

    python verify.py --output verification.json

The recorded run used Python 3.13.5 and random seed 2601003. The test suite uses
exact fractions, not floating-point tolerances. It checks ring identities,
principal-part closure, positive-cone and floor calculations, explicit
cancellation examples, and finite rational Kleene--Brouwer embedding data.
These finite checks do not verify infinitary well-foundedness, descriptive
completeness, or the external classical theorems.

## Status and scope

This is a research draft, not an independently refereed paper or a Lean proof.
Complete arguments for the report's constructions and deductions are provided,
with classical inputs identified. Global priority is not established.
The repository already contains the general coanalytic support obstruction
and the negative-infinitesimal floor correction; these are credited rather
than presented as new discoveries. See Appendix A for the contribution ledger.

The full-Hahn nonpresentation results require observable coefficients and
coverage of the entire field. They do not exclude abstract unobservable Borel
presentations or useful Borel real-closed subfields. The report proves that
addition cannot be globally continuous under compatible Polish recoding;
it does not improperly extend Glazer's stronger multiplication obstruction
to a model for which its extra arithmetic hypotheses have not been verified.

All results are set-sized in ZFC; no proper-class Polish topology is used.
No repository files were changed, and the whole ProveIt project was not audited.
