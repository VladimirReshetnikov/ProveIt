# Cactus Rigidity for Matching-Support Determinants

**Exact classification, a sharp approximation gap, and stability beyond vertex determinants**

Research report prepared for Vladimir Reshetnikov, September 29, 2026.

## The question answered

Part II, Section 24 of ProveIt's `preorder-root-polytopes/article.tex` asks which
bipartite graphs admit complex edge matrices whose square-minor squared norms
are exactly the perfect-matchability indicators, and whether this property
is equivalent to multivariate stability.

The article proves that the exact graph class is the cacti, and that the
representation property is strictly stronger than stability of the signed
matching-support polynomial. The old cactus construction is explicitly credited.

## Main results

- A finite simple bipartite graph has the exact minor model if and only if it
  is a cactus. Equivalent formulations use a Hermitian vertex-diagonal
  determinant or a support-exact matrix over F_3.
- A cactus of cycle rank beta has exactly 2^beta complex gauge classes,
  each represented by sixth-root phases, and one ternary gauge class.
- For every noncactus and every unit-edge-phase matrix, some matchable minor
  has squared-norm defect at least (sqrt(17)-3)/2. This universal constant
  is sharp, attained on K_{2,3}.
- The shared-edge theta Theta(1,3,3) has exact minimum defect
  (sqrt(5)-1)/2. The exact value for Theta(3,3,3) remains a research target.
- The signed support polynomial of K_{2,3} is real stable, with three exact
  sums-of-squares Rayleigh certificates. Arbitrary tree attachments preserve
  stability but cannot restore a Hermitian vertex determinant.
- No fixed maximum minor order recognizes the exact property, even among
  connected subcubic bipartite graphs of treewidth two.

The manuscript includes complete ordinary proofs, nine further research
questions, an explicit claim-status ledger, a source audit, and a formalization
plan. It is AI-assisted, unrefereed, and not Lean-verified. Worldwide priority
for equivalent formulations is not asserted.

## Files

- `article.tex`: standalone LaTeX source, with internal bibliography.
- `article.pdf`: compiled article.
- `code/verify.py`: exact Python 3.10+ verifier; standard library only.
- `data/verification.json`: recorded exact finite-check results.
- `data/verification_log.txt`: console output of the recorded run.
- `SOURCES.md`: pinned repository provenance and primary literature.
- `STATUS.md`: proof status, limitations, and audit priorities.
- `Makefile`: build and verification commands.
- `SHA256SUMS.txt`: checksums of the distributed files other than this manifest.

## Reproduce

From this directory:

```sh
python3 code/verify.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `make` and `make verify`. No network access, repository
checkout, third-party Python package, external image, or BibTeX step is needed.
The LaTeX source uses standard TeX packages. Rerunning the verifier rewrites the
local JSON report; its elapsed-time field will differ across runs.

## Verification scope

The recorded run checked all 512 labeled 3-by-3 bipartite support patterns
against every normalized sixth-root phase assignment, and all 4,096 labeled
3-by-4 patterns against every normalized ternary assignment. It also checked
118,470 canonical cactus minors, all three small cores, 100 compression
minor/support pairs, the three Rayleigh identities, five independently enumerated
leaf attachments, and exact algebra for the sharp constant. All checks passed.

Finite tests are not the all-graph proof, and sixth-root enumeration alone
cannot exclude arbitrary complex phases. Those conclusions rely on the
mathematical proofs in the article.
