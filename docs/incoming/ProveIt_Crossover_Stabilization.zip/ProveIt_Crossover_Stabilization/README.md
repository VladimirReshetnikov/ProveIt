# Finite Crossover Stabilization Is PSPACE-Complete

**Periodic interior universality, quadratic rank bounds, and linear-growth obstructions**  
Research draft prepared with ChatGPT for Vladimir Reshetnikov, 30 September 2026.

## Main results

For equal-length, aligned one-point self-crossover with endpoint cuts allowed:

- Finite stabilization is PSPACE-complete for binary NFA input, even for factorial languages with universal coordinate hull. The result holds for both parallel and frozen-source iteration.
- An s-state NFA language that stabilizes has aligned fragment rank at most `(2s+5)^2`. Thus parallel stabilization occurs by `ceil(log2((2s+5)^2))` generations. The logarithmic order in s is sharp.
- In every eventual length residue, maximal finite rank is either bounded or linear. A single periodic interior obstruction constructs a linear-rank family at every sufficiently large length in its residue.
- Deterministic automata admit a safe-core characterization and an interior obstruction bound `p*s^2`, where p is a common eventual period. The exact DFA decision complexity is not settled here; the proved upper bound is PSPACE.

The article answers the NFA part of the inspected ProveIt report's **Sharp regular-input complexity** question and improves its DFA upper bound from EXPSPACE to PSPACE.

## Status

These are ordinary mathematical proofs in an unrefereed research draft. No Lean or Rocq verification is claimed. The unary arithmetic-progression theorem, binary all-initial/all-final NFA universality hardness, and Savitch's space simulation are explicitly imported and cited. The earlier fragment-rank calculus is credited and reproved, not claimed as a new result. The targeted literature search does not establish worldwide priority.

## Files

```
article.tex                     Standalone LaTeX source, internal bibliography
article.pdf                     Compiled 23-page article
code/verify.py                  Exact finite reference implementation and audits
code/example.py                 Small runnable use of the reference solver
data/verification.json          Delivered machine-readable PASS receipt
data/verification.txt           Delivered console transcript
notes/proof-audit.md             Claim/dependency and edge-case audit
notes/source-ledger.md           Pinned repository and primary-source record
build.sh                        Local PDF build script
README.md                       This guide
```

## Reproduce the finite checks

Python 3.10 or later; standard library only. No network access or theorem prover is needed.

```sh
python3 code/verify.py --output data/local-verification.json
python3 code/example.py
```

The explicit output path preserves the delivered receipt. Without `--output`, the verifier writes `data/verification.json` in the local package, replacing any existing receipt at that path. Checks are assertions: run ordinary Python, not `python -O`.

The audit includes all 4,096 labelled two-state binary NFAs with all initial/final subsets, all 5,832 complete three-state binary DFAs with fixed initial state, 258,048 independent finite-rank comparisons, 1,641 pumped-witness checks, 256 instances of the binary hardness transformation, and additional exact and explicitly seeded-sample families. See Section 10 and the JSON receipt for the full ranges. Categories overlap and are not to be summed as independent experiments.

The reference solver stores explicit phase/subset graphs. It decides the property for small inputs but is **not an implementation of the theorem's polynomial-space bound**. Finite audits do not prove the universal statements.

## Build the PDF

A TeX installation with pdfLaTeX, latexmk, newtx, amsmath/amsthm, TikZ, booktabs, longtable, microtype, enumitem, listings, fancyhdr, hyperref, and bookmark is needed.

```sh
sh build.sh
```

This writes local LaTeX auxiliary files. The delivered package omits those generated build intermediates. Bibliography entries are internal, so no BibTeX run is required.

## Repository basis

Pinned revision: `b8b0fa2184a044d46ce9ed0f25f88d7bb60fa042`.

Report:
`SetTheory/Cardinals/docs/reports/automata-and-formal-languages/constrained-crossover-closure/`.

The source and README were read through the GitHub connector. The corollary headed **Decidable regular-input stabilization** and Section 11's **Sharp regular-input complexity** question were separately inspected. This delivery makes no changes to the repository.
