# Coercive Linear Algebra as a Universal Computational Substrate

**Canonical Quasi-Diophantine Certificates, Rational Green Functions, and Uniformly Shunted Resistor Networks**

Research report prepared for Vladimir Reshetnikov, 2 October 2026.

## Main result

The article constructs a fixed, finitely described path forest from a universal
counter-machine frontend. For every fixed integer alpha >= 3, its adjacency
operator A gives a self-adjoint operator L = alpha I - A with condition number
at most (alpha+2)/(alpha-2). The analytic equation Lw = e_s always has a unique
square-summable solution. Nevertheless, for an empty-history source s:

- w has finite support exactly when the source computation halts;
- the diagonal Green value <e_s, L^-1 e_s> is rational exactly when it halts;
- the normalized system Lu = c e_s, H(u) = 1 has a unique finite-support
  integer witness exactly when it halts.

A run with n configurations gives c = D_n and coefficients
D_(n-1), ..., D_0, where D_-1 = 0, D_0 = 1, D_(j+1) = alpha D_j - D_(j-1).
The response is D_(n-1)/D_n, or (alpha - sqrt(alpha^2-4))/2 for an infinite run.
For alpha = 3 the continuants are even-index Fibonacci numbers.

The article includes full proofs, a Pell-type output-spectrum classification,
polynomial-time approximation and rational-level testing, ordinary quadratic
finite-support slices, resistor and killed-random-walk interpretations,
a positive-characteristic obstruction, and twelve further research directions.

## Read and build

Open `article.pdf`. Its editable source is `article.tex`, with a self-contained
bibliography. From this directory, rebuild with a standard TeX Live installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The document uses New TX fonts, TikZ, and other standard packages. Font files and
third-party papers are not included. The delivered PDF was compiled with pdfLaTeX
and visually inspected after rendering with Poppler.

## Replay the code

Python 3.10 or later is required. There are no third-party Python dependencies.

```sh
python3 code/verify.py
python3 code/green_machine.py --export-example examples
```

The delivered run used Python 3.13.5 and completed **110,522 exact checks in 43
categories**, using seed 20261002. `validation/results.json` is the full ledger;
`validation/test_output.txt` contains captured output. A replay may report a
different Python version but should preserve the deterministic check counts.

## Small example

The implementation uses **zero-based register numbers 0 and 1**, corresponding
to the article's registers 1 and 2. Its scalar is called `q` in Python and JSON,
and `c` in the article. A configuration is `(state, c0, c1, history)`.

```python
# Run from this directory, or add the code directory to your Python path.
import sys
sys.path.insert(0, "code")
from fractions import Fraction
from green_machine import (
    Config, Program, certificate, check_certificate,
    green_interval, exact_rational_level,
)

program = Program((("test", 0, 0, 1), ("halt",)))
source = Config(0, 2, 0)  # empty history is the default
q, witness = certificate(program, source, alpha=3, horizon=10)
assert q == 55
assert check_certificate(program, source, 3, q, witness)
assert Fraction(witness[source], q) == Fraction(21, 55)
assert exact_rational_level(program, source, 3, Fraction(21, 55))
print(green_interval(program, source, 3, bits=40))
```

`examples/countdown.json` contains the complete instruction table, source,
history-lifted support, unique witness, and every residual of the ordinary
quadratic finite-slice polynomial. Its residuals are to be squared and summed.

`examples/modular_false_positive.json` exhibits a nonhalting source with a
spurious normalized certificate modulo 2. The same certificate fails over the
integers. This is an intentional boundary counterexample, not a program bug.

## Contracts and limitations

The compiler accepts explicit finite instruction tables; it does **not** include
a numerically instantiated minimal universal machine. Fixed-machine universality
in the article uses the classical effective two-counter simulation. The local
construction and its correctness are proved for every valid table.

A bounded `certificate` search raises `TimeoutError` when its horizon is
exhausted. This means only that no halt was reached within that horizon. It is
not a nonhalting decision.

`check_certificate` is the source-bound semantic checker. It rebuilds all graph
residuals, including rows just outside the supplied support, and checks the
terminal normalization. It does not trust a supplied trace. `rows_value` is an
arithmetic evaluator for residuals already emitted by `slice_rows`; arbitrary
caller-supplied residual lists are not themselves a trusted semantics interface.

The principal algebraic witness has unbounded finite polynomial support and uses
explicit fixed substitution and coefficient-extraction operations. It is a
**quasi-Diophantine** certificate, not a fixed tuple of ordinary integer unknowns.
The ordinary quadratic polynomial for a supplied support has variable arity
as that support grows. No improvement to the repository's reported 75/87
arithmetic-operation bounds, and no finite-fold ordinary Diophantine theorem,
is claimed.

The resistor network is countable and finitely specified. Its exact response
encodes halting, but no finite physical measurement or finite circuit is claimed
to decide halting. Numerical approximation remains uniformly efficient.

The proofs are mathematical, not Lean/Coq formalizations. The exact tests are
finite validation. Established literature priority for the combined normal form
has not been determined. See `SOURCE_AUDIT.md` for the audit boundary.
