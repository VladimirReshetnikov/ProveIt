# Degree Filtrations in Gowers' Ramsey Framework

**Sharper degeneracy bounds, exact polynomial pattern thresholds, and obstructions to extending norm constructions**

Research report developed with ChatGPT for Vladimir Reshetnikov, 6 October 2026.

## Contents

- `gowers_degree_stratification.tex`: the complete, standalone article, including proofs and bibliography.
- `gowers_degree_stratification.pdf`: the compiled article.
- `code/`: four independent exact-arithmetic verification programs, requiring only Python's standard library.
- `data/`: the recorded verification results in JSON.
- `SOURCE_LEDGER.json`: source revisions, local content checksums, attribution, and claim status.
- `Makefile`: convenient PDF and verification targets.
- `SHA256SUMS`: checksums for the packaged files, except the checksum file itself.

The article contains eight theorems, nine lemmas, additional propositions and corollaries, and fifteen research questions. It has no external bibliography, figure, or network dependency when compiled.

## Main results and relation to the preceding work

| Result | Contribution of this article | Scope |
| --- | --- | --- |
| Theorem 3.2 | Exact slope-balanced degree-one certificate count. For fixed arrangement parameter d, the count is polynomial of degree 2d in the cube dimension k. For d = 2 it is 30 k^4 + 204 k^3 + 111 k^2 + 114 k. | Prime p > 4d. Counts certificate classes, not distinct success loci. |
| Theorem 4.1 | A finite bound for Gowers' full arrangement-degeneracy predicate, charging Boolean degree t >= 2 at scale p^(-t-1) and degree one at its sharply reduced coefficient. | Direct improvement to the exceptional-set input of Gowers' Section 15; the higher-degree tail is retained explicitly. |
| Theorem 5.1 | Sharp first-order degeneracy coefficient k^2 + 3k for the previously excluded two-cube case. An explicit finite interval is proved, with exact value 4/p - 3/p^2 when k = 1. | Prime p > max(3, 2k + 1). Exactness of the lower endpoint for all k is left open. |
| Theorem 6.5 | Exact minimum q^max(n-B,0) for the number of directions realizing any prescribed equality pattern at a prescribed center. B is a maximum-weight column-basis sum of an explicit evaluation matrix. | Arbitrary finite fields and degree caps; includes sparse supports at the prescribed center. The polynomial attaining the minimum may depend on that center. |
| Section 7 | Closed formulas for arbitrary-degree symmetric and monochromatic progression budgets; simultaneous global sharpness in the stated interpolation ranges. | Characteristic exceeds progression length. High-degree prescribed-center sharpness does not assert high-degree global sharpness. |
| Theorem 8.1 | Classification and exact counts for scalar quadratic minimizers, including the least positive global excess. | Odd characteristic for the algebraic classification. |
| Theorems 9.2 and 9.3 | Complete low-degree norm cores cannot be improved by appending an arbitrary independent additive function; an exact cubic-core defect formula counts the additional directions. | Holds for arbitrary added functions. Zero defect means quadratic over the prime field, which is a broader class over extension fields. |
| Section 10 | Exact constant-line counts for degree-p norms, and quantitative lower bounds for layered constructions with characteristic-divisible norm blocks. | The F5 example N3 + N5 has at least 7,810,000 ordered nontrivial symmetric four-term progressions, despite being sharp at the origin. |

The earlier project reports already established the d >= 2 leading degeneracy coefficient and the low-degree symmetric norm-layer threshold. They are credited and their necessary arguments are reproduced. The present article also credits the classical polynomial support theorem, its Reed–Muller equality case, and the norm-coloring work of Shi and Dong.

“Established here” refers to the proofs supplied in this article. Independent bibliographic priority has not been established. No improvement of the global Szemerédi bound, resolution of the global quintic avoidance dimension, or new Lean kernel certification is asserted.

## Build the PDF

A standard TeX Live installation with `latexmk`, pdfLaTeX, `mathpazo`, `amsmath`, `amsthm`, `mathtools`, `geometry`, `microtype`, `booktabs`, `longtable`, `enumitem`, `xcolor`, `fancyhdr`, `xurl`, `hyperref`, and the Latin Modern typewriter font is sufficient.

```sh
make pdf
```

Equivalently:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error gowers_degree_stratification.tex
```

Without `latexmk`, run pdfLaTeX three times to settle the contents and cross-references. No shell escape is required. The supplied PDF was built with pdfTeX 1.40.25 / TeX Live 2023 and latexmk 4.83. Its final build has no undefined references or overfull boxes.

## Reproduce the finite checks

Use Python 3.9 or later, without optimization (`python -O` disables the assertions used in several checks).

```sh
make verify
```

Or run individually, from this directory:

```sh
python3 code/verify_certificates.py
python3 code/verify_two_cubes.py
python3 code/verify_polynomial_patterns.py > data/polynomial_pattern_verification.json
python3 code/verify_norm_obstruction.py --output data/norm_obstruction_verification.json
```

The certificate program compares independent sparse Laurent convolution and a joint-moment recurrence, checks the Boolean moment/degree identity exhaustively in small dimensions, and reproduces the coefficient tables. All theorem-relevant tests use exact arithmetic; the displayed base-ten logarithms in comparison tables are floating-point presentation values.

The two-cube program directly evaluates and matches the full squarefree moment vectors. It does not assume the translation-stabilizer proof. The polynomial program checks norm fibers, evaluation-matrix ranks, quadratic counts, and the exact cubic-core extension formula. The norm-obstruction program checks irreducible moduli, enumerates every eligible ratio in its stated fields, and independently enumerates all start/direction pairs in F27.

These finite checks support reproducibility and catch arithmetic or transcription mistakes. The general theorems rely on the proofs in the article, not extrapolation from the checks. The recorded results specify which counts are exhaustive and which are certified by factorization. They do not claim an exhaustive enumeration of all F7^8 direction vectors.

## Suggested repository integration

The work is grounded in commit `43306653afaaaaa0b58a7ca71e4067c245594867` of [VladimirReshetnikov/ProveIt](https://github.com/VladimirReshetnikov/ProveIt/tree/43306653afaaaaa0b58a7ca71e4067c245594867/Combinatorics/Ramsey).

A suitable additive location is:

```text
Combinatorics/Ramsey/Research/GowersSzemeredi/degree-filtrations/
```

Copy this package's contents there and add a link from the relevant research index. The article's integration section maps the definitions to `GeneralArrangement`, `arrangementMoment`, `GeneralArrangement.IsDegenerate`, and `degenerateGeneralArrangementCount` in the existing Lean development. It proposes a formalization order but supplies no Lean proof file.

When substituting the new finite bound into a quantitative argument, retain its explicit characteristic hypotheses and all of its higher-degree terms. The field-size threshold obtained by equal allocation among terms is a convenient sufficient condition; it is not advertised as uniformly smaller than every previously optimized threshold. A separate additive threshold is included in the article.

The package leaves the repository's existing theorem statements and proof-status catalogue for a separate, explicit formalization change. Do not mark these results as kernel-checked based on this article or its Python programs.

## Research agenda

The fifteen questions in Section 12 cover the true second degeneracy coefficient; exactness of the two-cube lower endpoint; balanced degree-two certificates; feasible higher-degree profiles; generating functions for the balanced counts; small characteristics; full downstream propagation; global quintic avoidance beyond independent additive extensions; simultaneous sharpness for general patterns; classification of extremizers; reflection-map surjectivity; higher-order defect formulas; quantitative defect stability; norm-line classification; and initial Lean milestones.

The most immediate next steps are the second degeneracy coefficient and degree-two certificate classification, followed by a checked propagation of the new finite bound through the later sections of Gowers' argument. The global quintic problem requires additional ideas because both prescribed-center reasoning and independent additive extensions encounter proved obstructions here.
