#!/usr/bin/env python3
"""Verify release payloads, optionally comparing an independently run replay."""
import argparse
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compare-replay", type=Path,
                        help="compare this JSON with the reference replay")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    for entry in manifest["files"]:
        path = root / entry["path"]
        payload = path.read_bytes()
        digest = hashlib.sha256(payload).hexdigest()
        if len(payload) != entry["bytes"] or digest != entry["sha256"]:
            raise SystemExit("FAIL: checksum or size mismatch: " + entry["path"])
    print("PASS: all %d manifest payloads verified." % len(manifest["files"]))
    if args.compare_replay:
        reference = json.loads((root / "replay_results.json").read_text(encoding="utf-8"))
        actual = json.loads(args.compare_replay.read_text(encoding="utf-8"))
        for result in (reference, actual):
            result.pop("duration_seconds", None)
            result.get("versions", {}).pop("python", None)
        if actual != reference:
            different = [key for key in set(actual) | set(reference)
                         if actual.get(key) != reference.get(key)]
            raise SystemExit("FAIL: replay differs in: " + ", ".join(sorted(different)))
        print("PASS: reproduced replay matches reference results.")


if __name__ == "__main__":
    main()
