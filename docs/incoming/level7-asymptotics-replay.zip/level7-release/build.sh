#!/usr/bin/env bash
# Rebuild the PDF without network access or shell escape.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p .build
for command in pdflatex kpsewhich pdftex; do
  command -v "$command" >/dev/null || { echo "Missing TeX tool: $command" >&2; exit 1; }
done
# Some minimal Debian installations have TeX files but no global filename database.
if [[ -z "${TEXMF:-}" ]] && [[ -d /usr/share/texlive/texmf-dist ]] && ! kpsewhich article.cls >/dev/null 2>&1; then
  export TEXMF='{/usr/share/texlive/texmf-dist,/usr/share/texmf}'
fi
export TEXMFVAR="$PWD/.build"
export TEXMFCONFIG="$PWD/.build"
export TEXFORMATS="$PWD/.build:"
if ! kpsewhich pdflatex.fmt >/dev/null 2>&1; then
  (cd .build && pdftex -ini -etex -interaction=nonstopmode -halt-on-error -jobname=pdflatex -progname=pdflatex pdflatex.ini > format-build.log)
fi
if ! kpsewhich pdftex.map >/dev/null 2>&1; then
  : > .build/pdftex.map
  for name in lm.map cm.map cmextra.map symbols.map latxfont.map; do
    map=$(kpsewhich "$name") || { echo "Missing font map $name" >&2; exit 1; }
    cat "$map" >> .build/pdftex.map
  done
  export TEXFONTMAPS="$PWD/.build:"
fi
export SOURCE_DATE_EPOCH=1790899200
export FORCE_SOURCE_DATE=1
for pass in 1 2 3; do
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error -output-directory=.build level7-asymptotics.tex > ".build/compile-$pass.log"
done
cp .build/level7-asymptotics.pdf level7-asymptotics.pdf
printf 'Built %s\n' "$PWD/level7-asymptotics.pdf"
