# Level seven asymptotics for A279619

This release contains a complete mathematical article proving

C = sqrt(3*pi) / (Gamma(1/7)*Gamma(2/7)*Gamma(4/7))

for the leading asymptotic of OEIS A279619, together with every-fixed-order
coefficient generators, the natural fixed positive integer-weight family
[x^n] A(x)^k, and Lambert-W inverse expansions with integer ceiling enclosures.
The inverse error constants and sufficiently-large cutoffs are existential.
Neither the article nor the numerical replay supplies an effective rounding
certificate.

## Files

- `level7-asymptotics.pdf`: the typeset article, including proofs and bibliography
- `level7-asymptotics.tex`: the complete editable LaTeX source
- `replay.py`: exact symbolic checks and high-precision numerical diagnostics
- `replay_results.json`: reference output from the default replay
- `requirements.txt`: pinned Python dependencies
- `build.sh`: offline PDF build script
- `verify_manifest.py`: standard-library manifest and replay comparison utility
- `MANIFEST.json`: SHA-256 checksums, file sizes, and file roles
- `README.md`: this guide

The manifest covers every release payload file except itself. The archive has
one `level7-release/` directory containing exactly the nine files above. Build
products, environments, page images, research logs, private working notes and
third-party source PDFs are not included. Published references and their links
are in the article itself.

## Verify the downloaded files

From the extracted `level7-release` directory, run:

```sh
python3 verify_manifest.py
```

This checks every listed file's SHA-256 digest and size. The manifest is an
integrity check against accidental changes, not a digital signature.

## Run the replay

Requirements: Python 3.10 or later, SymPy 1.14.0, and mpmath 1.3.0. A virtual
environment is recommended:

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python replay.py --output reproduced_results.json
python verify_manifest.py --compare-replay reproduced_results.json
```

On Windows, activate with `.venv\Scripts\activate` rather than the Unix
activation command. Dependency installation needs access to a package registry;
the replay itself performs no network operations. The comparison ignores
elapsed runtime and the Python version, and compares all other reported
results to the reference output.

The default run uses order 6, n up to 1600, and 100 decimal digits, and normally
finishes in a few seconds. The tested reference environment used Python 3.12.14.
Alternative settings are available:

```sh
python replay.py --order 8 --max-n 2000 --dps 120 --output results/order8.json
python replay.py --help
```

The exact scalar sequence is computed through `--max-n`. For speed, weights 2
and 3 are computed by integer convolution only through `min(--max-n, 400)`.
The established weight-two binomial identity is checked through
`min(--max-n, 40)`, and the norm representation and suborder coefficients are
checked through 500. Symbolic coefficients and formal inverse coefficients are
generated through `--order`; direct local-series multiplication checks weights
1 through 6. Higher orders are supported but increase symbolic cost. Increase
`--dps` along with the order or largest index; the CLI enforces a guard-digit
floor.

The JSON records the transformed differential equation, Frobenius coefficients,
recurrence/transfer agreement, symbolic weight-dependent corrections, universal
inverse coefficients, finite integrality and norm checks, and high-precision
CM, eta, theta, Fricke and Epstein identities. It also records empirical
forward and inverse residuals for weights 1, 2 and 3.

A `PASS` means the stated finite checks passed. It is not a proof from numerical
experimentation, interval certification, an effective asymptotic bound, or a
certified integer-threshold calculation. Inverse tests at Y = a_(k,n) are
exactly at discrete thresholds and must not be read as an unconditional ceiling
rule. The article supplies the analytic proof and its fixed-parameter scope.

## Rebuild the PDF

Use a TeX Live or MiKTeX installation providing pdfLaTeX and these ordinary
packages: Latin Modern, geometry, amsmath, amssymb, amsthm, mathtools, microtype,
booktabs, xurl and hyperref. On a Unix-like system with Bash:

```sh
bash build.sh
```

The script uses no network access and disables TeX shell escape. It writes
intermediate files into `.build/` and replaces `level7-asymptotics.pdf` after
three successful LaTeX passes. A fallback handles minimal Debian installations
whose installed TeX files lack a global filename database or prebuilt format.
On other systems, compiling `level7-asymptotics.tex` with pdfLaTeX three times
is sufficient; the bibliography is included in the source and needs no BibTeX.

The reference PDF was built with pdfTeX 1.40.26 (TeX Live 2025/dev/Debian).
Different TeX installations may produce byte-different PDFs with equivalent
content and layout. A rebuilt PDF is consequently not guaranteed to retain the
reference checksum. Verify the downloaded manifest before rebuilding; preserve
the original PDF if you need its reference digest.

## Prior work and boundaries

O'Brien's 2016 thesis provides the recurrence and modular parametrization,
conjectures the scalar expansion in Conjecture 8.1, and asks for the exact
weight-one constant in Question 10.2. Hirschhorn's 2013 paper already establishes
the weight-two asymptotic, including higher corrections. Cooper's 2025 Section
10 discusses that known weight-two result; Section 11 treats weight-one
congruences. Guillera and Zudilin's 2013 work supplies the prior general modular
radial-connection mechanism. The article explicitly credits these distinctions,
and derives the required classical CM normalization in detail.

The literature search is bounded rather than an exhaustive priority claim.
All asymptotic expansions keep k and the truncation order fixed. There is no
claim about growing-weight uniformity, optimal truncation, an exponential
transseries, or a resolution of the oscillatory companion A279613.
