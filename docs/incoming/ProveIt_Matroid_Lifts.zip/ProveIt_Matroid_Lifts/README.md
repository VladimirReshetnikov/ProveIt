# Preorders as Transversal Matroids
## Reconstruction, Ultra-Log-Concavity, and Stability of Matching Supports

Prepared for Vladimir Reshetnikov, 29 September 2026.
AI-assisted mathematical research by ChatGPT.

## Contents

- `article.pdf`: the complete 24-page research manuscript, with proofs, examples,
  references, ten further research questions, and a formalization plan.
- `article.tex`: self-contained LaTeX source; the bibliography is embedded.
- `verify.py`: exact finite verification using Python's standard library.
- `verification_results.json`: machine-readable output of the delivered run.
- `verification_run.txt`: the corresponding console output.
- `CLAIMS_AND_SOURCES.md`: contribution and dependency ledger.
- `Makefile`: optional build and verification targets.
- `SHA256SUMS.txt`: integrity checks for the delivered files.

## Main results

The paper constructs the transversal matroid associated with a finite preorder
and proves that it determines the preorder up to isomorphism. It identifies
intrinsic clone classes, computes the full automorphism group, gives an exact
upset rank formula, and realizes order reversal as matroid duality. It also
constructs every transversal matroid as an explicit minor of a height-two
preorder matroid. Combined with the classical Ingleton--Piff theorem, this
identifies the minor closure of the height-two family with finite gammoids.

A second strand applies the established Lorentzian/bimatroid theory to prove
ultra-log-concavity for every finite preorder h-polynomial, including a positive
transport-weighted version. A third proves a vertex-sum formula and exact block
locality for signed matching-support stability, including complete-bipartite
and even-cycle blocks.

## Build the article

Use a normal TeX installation containing the packages named in `article.tex`.
No network access, external figures, BibTeX database, or shell escape is needed.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

`make pdf` uses the two-pass pdflatex route. PDF timestamps can vary between
builds; the checksum identifies the specific delivered PDF.

## Reproduce the finite checks

Python 3.10 or newer is sufficient. No third-party modules are required.

```sh
python3 verify.py --output verification_results.json
```

The program raises an exception on failure. It uses integers and exact rational
numbers, not floating-point root tests or random sampling. It verifies 4,690
bipartite graphs, all 4,165 reflexive relations on one to four labeled elements
(including all 389 preorders in that range), 92,804 subset-rank comparisons,
34 full automorphism-group counts, 592 explicit minor constructions, 16
vertex-sum identities, and an exact negative Rayleigh/Sturm certificate.
The elapsed-time field is expected to vary between runs.

## Repository snapshot

Repository: https://github.com/VladimirReshetnikov/ProveIt

Commit: `e1afd75e35a4de734d5aa47aec5cdb917b82ed3e`.
The commit timestamp is 2026-09-30 01:40:17 UTC, still 29 September in
America/Los_Angeles.

Inspected report:
`SetTheory/Cardinals/docs/reports/enumerative-combinatorics/preorder-root-polytopes/`.
Exact source blobs and dependencies are recorded in Appendix B of the article.
No repository files were modified.

## Status, attribution, and limits

This is an unrefereed manuscript with complete written proofs of the stated
results, conditional only on the explicitly identified classical inputs where
used. It is not a Lean or Rocq formalization. The finite checks supplement the
proofs and do not establish their universal claims.

The general matching-support matroid lift and its unweighted
ultra-log-concavity theorem are prior work, explicitly credited to the
bimatroid literature. Existing repository gamma formulas, the known theta
counterexample, and the cactus determinant method are not claimed as new.
The structural preorder reconstruction and related consequences are the main
research contribution proposed here. The literature audit was targeted, so
absolute publication priority is not certified.

The ten final questions distinguish existing unresolved directions from new
questions suggested by the construction. The article does not claim to settle
all stability, flag-polytope, or gamma-log-concavity questions.
