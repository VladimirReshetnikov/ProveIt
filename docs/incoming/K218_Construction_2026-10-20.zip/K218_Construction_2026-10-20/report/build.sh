#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -B generate_tables.py
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error research_supplement.tex
pdflatex -interaction=nonstopmode -halt-on-error research_supplement.tex
