# K218: a 218-state ZFC consistency machine

This packet constructs an explicit **218-working-state, two-symbol, one-tape
Turing machine** for which ZFC proves

```text
not Halt(K218, blank) <-> Con(ZFC).
```

The complete proof and transition table are in `report/report.pdf`; editable
LaTeX begins at `report/report.tex`. The additional formalism lemmas and
finite search diagnostics are developed in `report/research_supplement.pdf`
and `research/theory/additional_formalisms.tex`. The accepted construction retains the
entire calibrated classical calculus of the pinned K219 predecessor.

## Machine conventions

The tape is infinite in both directions, the blank symbol is 0, the initial
head position is 0, and every transition moves one cell L or R. The
**canonical working states are 0–217**, the start is 0, the dispatcher is 23,
and **218 is the separate halt outcome**, with no outgoing rows. There are
exactly **436 transition rows**. Initialization is included in the 218 states.

`machine/k218.tm` is the complete canonical table. A row has the form

```text
state read_bit write_bit L_or_R next_state
```

The first line, `#! start 0`, declares the initial state.
`machine/k218.native.tm` is the same machine with inherited labels: start 0,
dispatcher 84, and halt 254. The bijection is in
`machine/canonicalization.json`.

## The breakthrough

The saving comes from coordinating source parenthesization with the use of
an already written tape bit to recover control context.

An intermediate source has the same **4,744 primitive instructions and
complete ordinal control graph** as K219, but only **205 distinct DAG
nodes**, compared with K219's 206. Its first allocation still needs 219
states because it separates a previously shared decoder role.

The decisive reassociation is

```text
((A, B), C)  ->  (A, (B, C))
```

where A, B, and C are closed, halt-free blocks with 26, 19, and 7 primitive
occurrences. Five occurrences of this 52-instruction block change. The
source remains at 205 DAG nodes, and every primitive instruction and control
edge is preserved. The new parenthesization changes native state 188 to

```text
188/0 -> 0 R 166
188/1 -> 1 R 12
```

This exposes the existing entry to the right 26-instruction block and makes
the following merge possible.

In the unfolded 219-state checkpoint, states 85 and 212 agree on read 0:
both perform `0 R 98`. On read 1, state 85 goes to 12, while state 212 goes
to 150. Their unique incoming transitions are

```text
155/0 -> 0 R 85
177/1 -> 1 R 212
```

Every entry therefore records the old state's identity in the tape cell
immediately behind the head: 0 for state 85, and 1 for state 212. Redirect
the second edge to 85, delete state 212, and set

```text
85/1 -> 1 L 190
```

The existing rows then recover the required continuation:

| Preceding bit | Route on a scanned 1 | Duration | Old successor |
|---|---|---:|---:|
| 0 | 85 → 190 → 188 → 12 | 3 steps | 12 |
| 1 | 85 → 190 → 189 → 156 → 176 → 150 | 5 steps | 150 |

Both paths read only the preceding and current cells, preserve both bits,
and finish one cell to the right, exactly matching the old transition.
The scanned-zero case still agrees in one step.

The unique incoming transitions establish the marker invariant on **every
execution from native start 0, on an arbitrary initial tape**. Thus this
last merge has a global stuttering proof, including initialization. An old
prefix of n transitions with u uses of `85/1` and v uses of `212/1` expands
to exactly `n + 2u + 4v` transitions. Every block is finite, nonempty, and
has no intermediate halt.

Relative to the pinned K219 table, **32 retained rows change, native state
212 is deleted, and no state is added**. The intermediate source allocation
is part of this construction: the final edits must be paired with the new
source addresses.

## Proof and verification

The proof consists of four independent obligations.

1. **Exact source equivalence.** The complete instruction word and guarded
   ordinal control graph agree with the pinned K219 source. Three algorithms
   resolve the control graph: arithmetic address cuts, subtree intervals,
   and independently written explicit continuation stacks. Graph equality
   gives a step-for-step source simulation for every register valuation.
2. **Unbounded literal runtime.** All **6,167 guarded primitive interfaces**
   have been freshly proved for the final table, with the unchanged pinned
   symbolic engine. The derivations use **1,515,158 symbolic proof steps**.
   They quantify independent arbitrary natural register values, gap,
   first spare value, and finite remaining spare list. They compare the
   complete resulting tape. Every duration has positive constant term;
   the minimum is **12**. All **436 rows** occur in the symbolic receipt.
3. **Complete blank initialization.** Independent native sparse and
   canonical dense simulations, plus a separately written sparse audit,
   reach the exact entry frame after **312,909 transitions**. Its head is
   −5, header is 139, extra gap is 80, logical registers are
   `[3,0,0,0,3,0,0,0,0]`, and there are 130 spare values, all 1. Its complete
   tape contains exactly **277 one cells**, with every other cell 0.
4. **Pinned finite-refutation calibration.** The unchanged source semantics
   transfers K219's effective correspondence with finite ZFC refutations.
   The exact predecessor archive and its recursive dependencies are bundled.

These give the internal chain

```text
Halt(K218, blank) <-> Halt(K219, blank) <-> not Con(ZFC).
```

The new endpoint is an **ordinary mathematical proof with executable
symbolic certificates, formalizable in ZFC**. It is **not a newly compiled
Rocq or Lean theorem for the exact K218 bytes**. No consistency assumption
is used to prove the equivalence. The packet makes no unconditional
nonhalting claim or minimality claim.

The compact `cases.json` is a guard/duration/rule-count receipt, not a full
standalone proof trace. The default replay regenerates every derivation.
The 4,000-step per-case bound limits symbolic proof construction, not any
register value or actual machine computation.

An earlier structurally clean frame at transition 92,808 has a nonzero
program counter. The startup checker verifies the root source address and
the entire tape at the certified 312,909-step endpoint.

## Exact state accounting

| Quantity | K219 | Intermediate | K218 |
|---|---:|---:|---:|
| Distinct source DAG nodes | 206 | 205 | 205 |
| Distinct primitive leaf types | 23 | 23 | 23 |
| Distinct interior source nodes | 183 | 182 | 182 |
| Physical state/source-role pairs | 184 | 183 | 183 |
| Physical source-decoder states | 169 | 169 | 168 |
| Additional shared roles | 15 | 14 | 15 |
| Other working states | 50 | 50 | 50 |
| Total working states | 219 | 219 | 218 |

The inherited open subtree `(CD6, CC2)` has two physical entry states,
13 and 108. A source node need not have a unique physical owner, and a
physical decoder state may carry two logical roles. The census explicitly
accounts for both facts. `machine/decoder_allocation.json` lists every
internal source prefix and its role.

## Reproduce offline

Use Python 3.10 or newer and its standard library, with assertions enabled.
From this extracted directory:

```sh
python3 -B portable/reproduce.py --output-dir /tmp/k218-replay
```

The output directory must initially be empty. Default mode authenticates
the exact portable inventory and parent archive, replays the predecessor's
construction and audits the pinned proof dependencies, reconstructs the source and machine without
search, verifies the independent source/fold premises, recomputes the
canonical table and complete blank initialization, freshly proves the
final unbounded runtime, and independently audits the result. The expected
endpoint is **`FULL_K218_REPLAY_PASS`**.

Default mode audits authenticated predecessor runtime receipts. To freshly
derive those inherited runtimes recursively, add `--full-baseline`. To audit
the stored final runtime instead of deriving it again, add `--quick`; that
mode reports **`QUICK_K218_REPLAY_PASS`**.

The packaged default replay passed in 184.15 seconds in the release
environment, including a fresh final unbounded proof. A separately launched
quick replay passed in 76.83 seconds. Their phase logs and machine identities
are in `verification/release_full/` and
`verification/release_independent_quick/`. These times are measurements,
not required bounds.

The accepted replay requires no network, repository checkout, optimizer,
Z3 installation, or proof assistant. Runtime may vary with the computer.

To rebuild the PDF using a conventional TeX Live installation:

```sh
bash report/build.sh
```

The complete table and transition-delta appendices are generated directly
from the machine and construction receipt.

## Research from the formalism side

The K/S-only experiment removed the fourth parameter reader and produced
a 203-node source after additional restructuring. Its full consistency
calibration remained open. In particular, atomic double-negation stability
does not automatically supply quantified-formula stability or justify
Booleanizing commuting quantifiers. Finite Heyting-algebra diagnostics in
`research/theory/` disprove those specific proposed proof steps; they do
not purport to model the whole set-theoretic bundle.

That experiment nevertheless exposed the useful state 85/212 pair. The
successful contribution was to transfer its decoder reassociation into
the unchanged classical source. **None of the unfinished K/S calibration
is a premise of the 218-state theorem.**

Other explored routes include ordinary-theory equality reduction,
alternative axiom orderings and parameter encodings, loop rotation in
unpairing, and broader valid enumerator seeds. Their status is separated
from the accepted construction in the report and research notes. A failed
218-state table illustrates that passing every primitive interface does
not guarantee successful blank initialization. These searches are not
claims of lower bounds on alternative machines.

## Artifact map

| Path | Contents |
|---|---|
| `machine/` | Canonical/native tables, source, decoder allocation, startup/bijection |
| `portable/` | Deterministic construction, symbolic proof, independent audits, replay |
| `portable/data/` | Literal 205-node grammar, exact patch and reassociation locations |
| `portable/vendor/` | Exact K219 archive, including its predecessors |
| `portable/reference_results/` | Fresh final runtime and all guarded case summaries |
| `verification/construction/` | Intermediate and unfolded 219-state checkpoints and final construction receipts |
| `verification/` | Independent certificates and packaged release replay evidence |
| `research/` | Supplementary formalism and encoding diagnostics |
| `report/` | Main PDF, editable LaTeX sections, generated appendices and build scripts |

## Exact identities

The immediate parent is the archive in ProveIt revision
`26d5de6d21fa354d50e0b84fe851c289925b8d72`.

| Artifact | SHA-256 |
|---|---|
| Pinned K219 archive | `04813567f393b6c4015a96aba092159e9021703b4b662c7be69bd2a86497e31b` |
| Native K218 table | `2dfaba6da09b78291e534777cd30c5f0d68bd84faa670e868e779c396aeb308f` |
| Canonical K218 table | `06d7a91c583739e17f8b33ce3e03d0aeaf9e1faa186c76d596418942fe2a8730` |
| Source sites | `b0169f2d477d0584ac70f9bdb79c3a78ef2bc700d080b3cd80976210235b80d9` |
| Guarded-case summaries | `8180a18a947ea8d4a2990f32c41a4dfcfdf1e2898cfbc40ca5b8e1b5e2dd1866` |

`MANIFEST.sha256` covers the packet files other than itself. A second
exact-inventory manifest covers the portable subdirectory before replay.
Original attribution and licenses remain in the bundled predecessor.
