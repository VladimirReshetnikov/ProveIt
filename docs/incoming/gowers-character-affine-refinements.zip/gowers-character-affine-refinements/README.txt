SHARP CHARACTER SEPARATION AND AFFINE RIGIDITY IN GOWERS' INVERSE STEPS
Research manuscript prepared with ChatGPT for Vladimir Reshetnikov
7 October 2026

START HERE

gowers-character-affine-refinements.pdf is the complete article.
gowers-character-affine-refinements.tex is its standalone LaTeX source.
The source embeds its bibliography; no figures, BibTeX run, private style
files, network requests, or generated inputs are needed to compile it.

This is an AI-assisted research manuscript with full written proofs,
independent mathematical audits, and supplementary exact computations.
It has not been externally refereed or formally verified. The results
are local refinements; the article does not claim a new global bound in
Szemeredi's theorem or a solution to the lonely runner conjecture.

PRINCIPAL RESULTS

1. For q sign orbits in a finite symmetric forbidden set, exact universal
   separator ranks floor(log_2(q+1)) at radius 1/5 and
   floor(log_3(2q+1)) at radius 1/7 for odd-order defects. Both ranks are
   sharp for every q, and both rank/radius pairs are jointly sharp.
   The prime-primary rank is floor(log_p((p-1)q+1)) at radius 1/(2p).

2. Weighted Freiman extraction over arbitrary abelian targets, exact
   finite-image rounding, a projective finite-field refinement, and
   an explicit target-independent polynomial bound from small doubling.
   The argument answers the pinned project's mixed-torsion extension
   question, with classical Green--Tao and Gowers--Milicevic precedents
   credited explicitly.

3. Every finite symmetric forbidden set is the exact vertical defect set
   of a graph at any prescribed order k>=2, even with finite domain.
   The construction has exactly computable optimal retained cardinality,
   weight, and graph difference size. It separates sharpness of the
   separator rank from sharpness of retained mass.

4. Signed graph-energy inequalities enlarge the sufficient local cubic
   affine-rigidity range from t<1/7 to t<4/9 for targets without
   involutions, and to t<1/2 when order-three elements are absent too.
   Equality is exactly a single nonzero error value on a subgroup coset
   in the stated open ranges. At t=4/9 the first class has strict
   inequality; at t=1/2 the second has exactly the index-two coset
   extremizers. The support coefficients 3 and 4 in the signed-kernel
   bounds are sharp. Explicit near-equality bounds are included.

5. Classical correction plus the cubic yields unique recovery for graph
   defect epsilon<2/9, the exact non-affine energy maximum for N>=16,
   and a canonical partial-graph recovery theorem. These are credited
   as applications of prior correction theory, not new global testing
   theorems. The original sufficient cutoff in repository source 11 is 34.

6. A one-character torsion budget, the exact lonely-runner reduction,
   and an explicit dissociated Riesz-product radius. The stronger general
   lonely-runner estimate is attributed to Bedert.

The article also records a precise order-five failure of the probability
estimate displayed in Green--Tao Lemma 8.3. It does NOT claim that the
lemma's conclusion or their inverse theorem is false.

BUILD THE ARTICLE

Requirements: a conventional TeX Live/MiKTeX distribution containing
pdfLaTeX, latexmk, Latin Modern, AMS packages, mathtools, mathrsfs,
microtype, booktabs, longtable, enumitem, xcolor, fancyhdr, xurl, hyperref.

From this directory:

    latexmk -pdf -interaction=nonstopmode -halt-on-error \
        gowers-character-affine-refinements.tex

Alternatively run `make pdf`. The delivered PDF was built with pdfTeX
and inspected after rendering. The date in the article is fixed, while
the PDF's build metadata may differ between compilations.

REPRODUCE THE EXACT CHECKS

Requirements: Python 3.10 or newer; standard library only. Run:

    make check

The Makefile writes fresh reports under build/ and compares parsed JSON
with the supplied data/*.json reports. The individual commands are:

    python3 code/check_extraction.py
    python3 code/verify_affine.py --output build/affine_checks.json
    python3 code/check_graph_realization.py

Create build/ first for the second command if it does not exist. Do not
run under Python -O or -OO: all programs reject those modes because
assertions carry the exact checks. The affine sampling seed is 20261007.

VERIFICATION.txt gives the exact scope and counters. In particular,
23,516 affine evaluations include repeated sampling, and 6,495 extraction
applications concern 2,441 underlying partial maps. These are not counts
of all functions on arbitrary finite groups. Finite tests supplement the
analytic proofs and do not establish novelty or formal verification.

REPOSITORY INTEGRATION

The comparison is pinned to ProveIt commit:
    bec460a3335f8da421459b4bf69d082e674560a6

INTEGRATION.txt identifies the relevant source chapters and the main
theorem dependencies. data/source_manifest.json records verified Git
blob identities and primary literature references. No repository files
were modified or pushed as part of preparing this archive.

PACKAGE CONTENTS

  gowers-character-affine-refinements.tex
  gowers-character-affine-refinements.pdf
  README.txt
  INTEGRATION.txt
  VERIFICATION.txt
  Makefile
  code/check_extraction.py
  code/verify_affine.py
  code/check_graph_realization.py
  data/extraction_checks.json
  data/affine_checks.json
  data/realization_checks.json
  data/source_manifest.json
  data/build_validation.json
  SHA256SUMS

SHA256SUMS covers all other released files. It records the delivered
bytes; rebuilding the PDF can change its creation metadata and hash.
