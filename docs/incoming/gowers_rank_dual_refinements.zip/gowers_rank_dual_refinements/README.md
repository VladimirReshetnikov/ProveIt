# Second-Order Degeneracy, Dual Uniformity Bounds, and an Acyclic Model Theorem

Research manuscript prepared for Vladimir Reshetnikov with ChatGPT, dated 6 October 2026, for integration into ProveIt's Ramsey research development.

## Main results

1. **Derivative-rank-two classification and census.** For ternary-valued multiaffine Boolean polynomials in characteristic at least five, rank two forces a product across disjoint coordinate supports of size at most two each. The exact number is `62 binom(k,2) + 84 binom(k,3) + 24 binom(k,4)`.
2. **Second degeneracy coefficient in every fixed dimension.** The two-cube proportion is `(k^2+3k)/p - k(3k^3+14k^2+15k-14)/(6p^2) + O_k(p^-3)`, with the explicit remainder in the article. The signed-coordinate product formula is exact in dimensions one, two, and three for every odd prime.
3. **Stronger real uniformity gaps.** On every finite odd-order abelian group, real centered functions satisfy `U4^16 >= (29/4) U2^16` and `U5^4 >= (50/29) U2^4`. A largest Fourier pair of order other than five gives the stronger fourth factor `15/2`. Thus `c4^odd <= (4/29)^(1/4)` and `c5^odd <= 29/50`.
4. **An acyclic cover theorem from explicit structural hypotheses.** The proof assumes seven corrected pre-Section-16 interfaces and gives dimension-decreasing recurrences for a global prime threshold, local model count, width exponent, and minimum width. It proves the stated conditional replacement for the Section 16 inverse interface.
5. **Eventual Laurent polynomiality** of the two-cube degeneracy probability for each fixed dimension, outside an effective finite set of characteristics.
6. **Exact finite-field generalizations.** The dimension-one/two/three signed-coordinate formulas extend to all finite fields of characteristic at least five. In characteristic three, every dimension has the exact formula `1 - (1-1/q)^k product_{i=1}^k(1-3^i/q)`. More generally, the complement of the translation union for a full subfield alphabet F_s inside F_q has size `product_{i=1}^k(q-s^i)`. These last reductions are deductive, not additional computations.

## Proof status

This is a research manuscript, not a peer-reviewed or Lean-certified contribution. Its rank-two structure and general asymptotic formulas have deductive proofs. The exact dimension-three theorem and the new norm constants use explicitly identified exhaustive finite certificates in integer/rational arithmetic. The cover theorem is an implication from its listed inputs I1–I7; those deep source inputs were not re-proved or formally certified in this work.

The article credits earlier project results, including the translation-coset reduction and first coefficient, balanced Fourier moments, the existing norm examples, and improved interpolation sampling. It does not claim sharp norm constants, general exactness in dimension four and higher, or a new global Szemerédi bound. Its proposed questions are questions left unresolved by this manuscript, not a claim that every formulation is a previously recognized published open problem.

## Files

- `gowers_rank_dual_refinements.tex`: complete single-file article source, including bibliography and the vector plot.
- `gowers_rank_dual_refinements.pdf`: compiled article.
- `code/verify_rank_two.py` and its JSON: supplemental exact checks for the rank-two proof and low-dimensional formulas.
- `code/verify_dimension_three.py` and its JSON: the complete finite certificate for dimension three, combined with the reduction proved in the article.
- `code/verify_dual_gap.py` and its JSON: the complete integer dual coefficients and rational bounds used in the new fourth/fifth norm constants.
- `code/check_dual_numeric.py`: optional, independent direct-cube numerical cross-check.
- `source_ledger.json`: repository pin, source identities, contribution status, and verification scope.
- `MANIFEST.sha256`: package-file hashes; this file excludes itself.
- `Makefile`: build and verification commands.

## Build

Use Python 3.10 or newer and a standard TeX Live installation with `latexmk`, `pdflatex`, AMS packages, `cleveref`, and `pgfplots`.

```sh
make pdf
make verify
```

The exact verifiers need no third-party Python packages, no random seed, and no network. They regenerate JSON files beside the scripts and reject `python -O`/`-OO`. The whole article compiles from its single TEX file; no earlier project manuscript is required at build time. Two direct `pdflatex` runs can be used in place of `latexmk`.

The optional independent direct-cube check requires NumPy:

```sh
make numeric
```

It uses floating point and is not part of the proof. The figure likewise illustrates already certified inequalities; it does not establish their margins.

## Reproducibility scope

The dimension-three certificate covers 1,985,589 ordered cubic pairs, 12,610 ordered quadratic pairs with an equal nonzero quadratic part, and all 91,854 polynomial/representative cases at primes eleven and thirteen. Its integer gcd obstruction handles every prime at least seventeen. The prime-field cases three, five, and seven are handled by the signed-coordinate covering argument in the text.

The norm certificate regenerates five complete punctured-cube dual expansions using two-face enumeration, plus the full-cube order-three sign count. Small character orders and all phase-dependent aliases are included. The exact verifier tests every rational comparison appearing in the new bounds.

The rank-two verifier is supplemental evidence for an all-dimension proof in the article; finite rank censuses alone are not asserted to prove its general statement. None of these scripts certifies the source interfaces I1–I7.

## Proposed integration

Suggested destination:

`Combinatorics/Ramsey/Research/gowers-rank-dual-refinements/`

The baseline snapshot is commit `8c12c906e4ab5a00001a65de3c882f935a15661a` of `VladimirReshetnikov/ProveIt`. Keep the article as a research contribution with its exact certificates. Preserve the conditional hypothesis boundary of the cover theorem and distinguish computational certificates from future Lean proofs. No repository files or proof-status ledger entries were changed in producing this deliverable.
