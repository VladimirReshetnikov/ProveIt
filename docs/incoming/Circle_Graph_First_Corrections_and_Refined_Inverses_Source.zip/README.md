# Report 152 First corrections for unlabeled circle graphs

This release contains the complete proofs, editable LaTeX, rendered PDF, and fresh
exact companion for the first asymptotic corrections to OEIS A156808 (connected)
and A156809 (all unlabeled circle graphs). Let h_n=(2n−1)!!/(4n). The main results are

- c_n = e^(−3/2) h_n [1−15/(4n)+O(n^−2)]
- g_n = e^(−3/2) h_n [1−13/(4n)+O(n^−2)]
- c_n/g_n = 1−1/(2n)−1/n²+O(n^−3)

The report includes a uniform complex local-pattern expansion, a direct
three-chord interval lemma, canonical graph-level split-tree transfer with
controlled global tails, bounded reciprocal-automorphism refinements, labeled
corrections, and a Lambert-W least-index inverse with ceiling-safe uncertainty.

## Scope and qualifications

The every-fixed-order graph transfer requires corresponding prime coefficients
with controlled remainders. It is not an unconditional all-orders expansion.
The displayed second graph coefficients are conditional on an unknown prime
coefficient beta; no value of beta is supplied or conjectured. The inverse is an
asymptotic bracket with an existence constant and onset. It does not authorize
rounding its center unconditionally near an integer. No effective finite-input
threshold certificate or unbounded positive automorphism moment is claimed.

The primary circle-graph source versions inspected were arXiv:2402.06394v1 and a
complete 2024 author copy, together with the specified structural sources. The
2026 final journal text was not inspected. No exhaustive novelty or priority
claim is made, and the labeled consequence has no separate completed
literature/OEIS audit. SOURCE_PROVENANCE.json records exact source versions and
hashes. No downloaded paper, private working note, prior report or audit note is
bundled. No external publication, author contact or repository edit was performed.

## Contents

- Report152.tex and Report152.pdf: complete proof and its verified rendering
- companion/: standard-library Python exact diagnostics, expected rational
  claims, test suite, source provenance, and recorded machine-readable results
- build_pdf.py: deterministic, isolated PDF builder
- make_zip.py: fixed-allowlist checksum-verifying deterministic archive builder
- release_tools.py: descriptor-pinned, no-follow, exclusive-output helpers
- test_release.py: output-safety, manifest-mutation and archive tests
- SHA256SUMS: SHA-256 checksums of the fixed release allowlist

The exact packaged file set is the FILES tuple in make_zip.py. The source ZIP
contains these files plus SHA256SUMS; it does not recursively bundle the
workspace. The ZIP itself is deliberately not a manifest member.

## Reproduce exact diagnostics

Requirements: Python 3.10 or newer on POSIX with O_DIRECTORY and O_NOFOLLOW.
No external Python packages are needed. From the extracted release root:

```sh
python3 -B companion/verify.py
python3 -B -O companion/verify.py
python3 -B companion/test_companion.py
python3 -B -O companion/test_companion.py
python3 -B -m unittest -v test_release
python3 -B -O -m unittest -v test_release
```

The companion README specifies every finite range, output-safety contract, and
recorded result. In particular it exhausts 60 three-chord interval cases,
constructs local atoms at M=8,10,12,16,20,30,40, enumerates rooted connected
circle classes on two through five vertices, and checks 45 factorial-product
series against rational transfer formulas. It also checks small root-stabilizer
histograms, weighted coefficients, and inverse residual cancellation. Its
checks use explicit exceptions and remain active under Python -O. Mutation
tests require wrong coefficient targets to fail. The finite diagnostics do not
prove analytic uniformity, prime uniqueness or the graph-split theorem.

For an optional new JSON result, use an unused filename under companion/results:

```sh
python3 -B companion/verify.py --output companion/results/my-replay.json
```

The program refuses an existing output, source/input replacement, paths outside
its results directory, traversal and symlink routes. Shell redirection is not
subject to the program's safety guarantees. The build/archive tools likewise
refuse existing destinations and symlink path components.

## Rebuild PDF and archive

The tested platform uses Python 3.12.14 and pdfTeX 1.40.26 (TeX Live 2025), with
LaTeX, Latin Modern, AMS, mathtools, geometry, booktabs, longtable, array,
microtype and hyperref available. A full compatible TeX installation is required.
The builder currently uses the Linux TeX trees /usr/share/texlive/texmf-dist and
/usr/share/texmf, and POSIX /proc/self/fd; it is not a cross-platform wrapper.

Choose a fresh output directory whose parent already exists:

```sh
python3 -B build_pdf.py --output-dir /tmp/report152-pdf-replay
cmp Report152.pdf /tmp/report152-pdf-replay/Report152.pdf
```

The builder creates a private output directory exclusively, initializes an
isolated TeX format, disables shell escape, pins the font maps, fixes locale,
timezone and source date, suppresses PDF timestamps and trailer identifiers,
and iterates until cross-reference files stabilize. It rejects settled TeX
warnings, overfull/underfull boxes and missing characters. Build intermediates
remain inside the new output directory. The supplied source never requires
network access or TeX shell commands. PDF byte identity is qualified to the
tested toolchain, not promised across TeX installations.

After verifying the manifest, reproduce the archive to a new path:

```sh
sha256sum -c SHA256SUMS
python3 -B make_zip.py --output /tmp/Report152_Source_replay.zip
```

The ZIP uses fixed sorted members, timestamp 2026-10-03 00:00:00, regular-file
permissions and stored data. Its builder validates each payload hash before
writing, then reads its in-memory archive back and compares every member.
Repeated builds from the same payload are byte-identical. Do not update the
manifest merely to suppress an unexpected verification failure: determine why
the payload changed. A manifest proves internal consistency, not authenticity
against simultaneous replacement of the payload and manifest.
