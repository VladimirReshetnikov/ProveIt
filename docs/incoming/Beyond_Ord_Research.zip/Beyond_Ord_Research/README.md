# Beyond Ord: Definable Class Well-Orders

**Explicit arithmetic, condensation, definability ceilings, and truth jumps**  
Research manuscript prepared for Vladimir Reshetnikov, 4 October 2026.

The PDF has 27 pages, including the cover, contents, appendices, and references.
The LaTeX source is self-contained and uses an internal bibliography.

## Principal results

- Theorem 5.2: canonical division `W ≅ Ω · Q + α` by least-representative
  set-interval blocks, with a set-ordinal remainder.
- Theorem 6.1: any admitted condensation hierarchy on `W` indexed through
  `W + 1` collapses by its final stage. `ETR_(W+1)` supplies a sufficient
  existence hypothesis; existence in bare GBC is not established.
- Theorem 7.1: a diagonal sum of the orders `W_i + 1` embeds into none of the
  members of a supplied uniform family, without a comparison principle.
- Theorem 8.3: over an inaccessible-rank universe `V_κ`, with fixed predicates
  `G, A` and all set parameters allowed, the definable well-order spectrum is
  an initial ordinal segment with ceiling `δ_A`, where
  `κ < δ_A < κ^+`, `cf(δ_A) = ω`, and `κ^δ_A = δ_A` (external operations).
- Theorem 9.1: adjoining full truth for `(V_κ, ∈, G, A)` makes that old ceiling
  itself representable and strictly increases the new definability ceiling.

The article also treats finite-support exponentiation, hereditary fixed-point
presentations, cofinality, explicit long condensation examples, five
formalization routes, and eleven further research questions.

## Files

`beyond_ord.pdf` — compiled article.  
`beyond_ord.tex` — complete source and bibliography.  
`finite_checks.py` — finite exact regression checks, Python standard library only.  
`finite_checks.json` — the recorded 689,808 successful assertions.  
`PROOF_STATUS.md` — mathematical, computational, source, and layout audit.  
`Makefile` — build/check convenience targets.  
`SHA256SUMS` — checksums for the distributed files.

## Build and check

Use a standard TeX Live or MiKTeX installation with common LaTeX packages
(including amsthm, aliascnt, cleveref, hyperref, microtype, and lmodern).

```sh
pdflatex -interaction=nonstopmode -halt-on-error beyond_ord.tex
pdflatex -interaction=nonstopmode -halt-on-error beyond_ord.tex
pdflatex -interaction=nonstopmode -halt-on-error beyond_ord.tex
python3 finite_checks.py --output finite_checks.json
```

Alternatively run `make`. Python 3.9 or later is sufficient for the checker.
The checker is deterministic, using seed 20261004.

## Scope and status

This is an AI-assisted, unrefereed research manuscript, not a peer-reviewed
publication or a machine-checked proof. Historical priority for the arguments
proved here is not established. Standard facts and relevant repository
antecedents are explicitly credited. Finite checks validate coding conventions,
not proper-class mathematics, ETR, or the inaccessible-model assumptions.

The user's repository was inspected but not modified. No Lean or Rocq build was
performed. Suggested formalization modules are a plan, not supplied verified code.
