REPORT 115
Order seven B tree histories
Convergent psi series and coefficient asymptotics
2 October 2026

START HERE

Read report115.pdf. The editable mathematical source is report115.tex.
The report proves the m=3 case of Burghart and Wagner's B-tree history
conjecture for OEIS A336009, using Astashova's published fourth-order
real-profile theorem and a complete complex-analytic argument. It gives
a convergent three-variable psi series, an exact energy amplitude, an
analytic proof that the complex amplitude is nonzero, coefficient
expansions at every fixed order, smooth inverse models, Lambert W
corrections, and integer threshold brackets.

The final mathematical section also proves that BOTH the order-five EGF
(A333497) and the order-seven EGF (A336009) are not D-finite over C(z),
and that both exact integer sequences are not P-recursive over C[n].
The order-five application takes its established convergent local theorem
from companion Report 113, identified in the bibliography. That companion
is not modified or reproduced in this package. Its precise needed local
input is restated in this report. The order-seven result is proved here.

The source convention is important: h_n counts reduced 7-historic trees
with n internal vertices, equivalently shape histories of length n+3.
The leading law is 140(n+3)! rho^(-n-4).
The rigorous enclosure is 16800^(1/6) <= rho <= 840^(1/4).
The real amplitude is c0 = -1/18052070400, and the complex amplitude
is proved nonzero without numerical fitting.

The local psi series converges. The large-n coefficient and inverse
expansions are asserted only to arbitrary fixed finite order. All decimal
fits of rho and C are EXPLORATORY, not certified intervals or counts of
trustworthy digits. Do not infer a numerical rounding guarantee from an
unquantified asymptotic remainder. The report does not settle the B-tree
conjecture for every m or classify global analytic continuation.

FILES

report115.tex                  Standalone mathematical source
report115.pdf                  Rendered report
build.py                       Two clean, byte-identical PDF builds
pack.py                        Deterministic verified ZIP generation
CHECKSUMS.sha256                Closed package SHA-256 inventory
checks/                        Exact checks, fixtures, validation and fits
verification_results.json      Reproducible machine-readable test results

The reader package contains no source-paper PDFs or temporary rendering
files. Sources are linked in the report.

DEPENDENCIES

Exact checks: Python 3.10 or later and SymPy (tested with 1.14.0).
Optional exploratory fits: mpmath (tested with 1.3.0).
Manifest checking: Python standard library only.
PDF build: pdfTeX/pdflatex and the standard LaTeX packages geometry,
fontenc, lmodern, amsmath, amssymb, amsthm, mathtools, booktabs, microtype,
hyperref and enumitem. Tested with pdfTeX 1.40.26.

Different TeX/font distributions may produce different PDF bytes without
changing the mathematics. The byte-reproduction claim is within the tested
toolchain, with independent clean build directories. ZIP byte identity also
assumes the same Python/zlib compression toolchain. The scripts do not
install software or access the network. A fresh-directory replay is not a
newly provisioned operating system.

INTEGRITY AND PDF BUILD

Run from the report115 directory after extracting the ZIP:

  python3 -B checks/check_manifest.py .
  python3 -B build.py
  python3 -B checks/check_manifest.py .

build.py creates formats and intermediates in temporary directories,
compiles from two independent clean states, rejects overfull boxes and
unresolved references, requires byte equality, and writes report115.pdf.
It fixes timestamps and PDF metadata and does not edit the TeX source.

The package inventory is closed: unexpected, missing or changed files are
errors. Use -B as shown so Python does not write bytecode caches into the
archive. Store new outputs outside the extracted package directory.
Never use --write to validate a received package: it replaces the checksum
inventory and is intended only for an author deliberately repackaging files.
The checksums detect changes relative to their inventory; they are not an
authenticated signature and do not establish source trust.

EXACT CHECKS AND MUTATION REPLAY

  python3 -B checks/check.py
  python3 -B -O checks/check.py
  python3 -B checks/validate_bundle.py --with-exploratory --output /tmp/report115-validation.json

The exact checker uses explicit guards, not removable assertions. It
regenerates 501 terms by two independent exact recurrence formulations,
compares the 31 externally checked OEIS prefix terms, and tests the displayed
symbolic constants, identities, finite psi recursions and inverse formulas.
The 501-term fixture is generated from the defining recurrence, not an
externally retrieved OEIS b-file.

The delivered verification_results.json records the successful run.
The harness runs normal and optimized checks, tests 50 named negative runs,
replays from a fresh directory, checks specific expected error diagnostics,
and records source hashes before and after. Optional numerical replay is
reported separately. See checks/README.md for full scope and command details.
These finite tests support algebra and reproducibility; they do not prove
infinite-series convergence, analytic continuation or infinite monodromy.

OPTIONAL EXPLORATORY FITS

  python3 -B checks/exploratory_fit.py --output /tmp/report115-exploratory.json

This uses 100-decimal point arithmetic and fixed-degree gamma-ratio fits.
The result status remains EXPLORATORY_ONLY. Agreement with a reference run,
apparent digit stability and small residuals do not certify the constants.
Fitted-index residuals are specifically distinguished from out-of-fit ones.

RECREATE THE ZIP

  python3 -B pack.py /tmp/report115-reproducibility.zip

The destination must be outside the package directory. pack.py first checks
the closed inventory, then writes all files beneath report115/ using sorted
paths, fixed timestamps and fixed file modes.

LAYOUT REVIEW

The final PDF was rendered and every page visually reviewed. No clipped
text, overlap, unreadable formulas or broken references were observed.
The deterministic build also rejects overfull boxes and unresolved references.
These layout checks are separate from mathematical proof review.
