SURREAL AND OMNIFIC FOUNDATIONS
Bi-Interpretations with Set Theory and the Boundary at Classes
Research study prepared for Vladimir Reshetnikov
4 October 2026

CONTENTS
  surreal_omnific_foundations.pdf -- complete 34-page article
  surreal_omnific_foundations.tex -- self-contained LaTeX source
  README.txt                     -- this file

The article includes explicit numerical interpretation formulas, proofs,
recursive axiom systems, a class-theory obstruction and positive class lift,
a repository provenance record, 12 further research questions, and 21
bibliographic entries.

BUILD
Use a standard TeX Live or MiKTeX installation with Latin Modern,
AMS-LaTeX, geometry, microtype, enumitem, booktabs, longtable, tabularx,
array, xcolor, fancyhdr, xurl, hyperref, cleveref, and TikZ/PGF.
From this directory run the following command three times, to settle
the table of contents, cross-references, and PDF bookmarks:

  pdflatex -interaction=nonstopmode -halt-on-error surreal_omnific_foundations.tex

The bibliography is embedded in the TeX file. No BibTeX run, external
image, custom style file, or repository checkout is required.

RESEARCH STATUS
The surreal/ZFC result was already announced by Junhong Chen,
Joel David Hamkins, and Ruizhi Yang, and appears in related ProveIt
material. The article develops an explicit native omnific-integer
construction and states the precise scope of its class-theory results.
It does not claim worldwide priority or resolution of a published open
problem without verification. No new result supplied here has been
formalized in a proof assistant.

REPOSITORY BASELINE
https://github.com/VladimirReshetnikov/ProveIt
Commit: 722337445aa691a90e005ff8f619fd8ce5397103
The relevant source links in the bibliography are pinned to this commit.
The repository was inspected but was not modified.

VALIDATION
The final TeX source compiled successfully with resolved references.
The PDF was rendered and visually inspected. The main mathematical
constructions received independent proof reviews during preparation.
These checks are distinct from external peer review or machine-checked
mathematical formalization.
