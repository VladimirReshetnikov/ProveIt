# Leaf compression and weighted rank three

Research note dated 1 October 2026, prepared for Vladimir Reshetnikov.

## Main result

For every bipartite graph of matching rank at most three, its matching-support polynomial is ultra-log-concave after normalization by the binomial coefficients of its actual matching rank, for arbitrary positive vertex activities on both shores. Nonnegative activities are handled by deleting zero-activity vertices and using the surviving degree.

This answers the explicitly open “Weighted rank three” question in the incoming ProveIt Matching Rank manuscript. The more general theorem handles every minimum vertex cover split as 1 + (r - 1), and removes all 1 + 3 covers from the rank-four problem.

The key observation is exact: leaves sharing one neighbor may be collapsed to one leaf whose activity is the sum of theirs. Each matchable support contains at most one member of the class. The compressed graph has a shore of size r, so the published weighted smaller-shore inequality applies.

## Scope

- Relative novelty is checked against the new incoming Matching Rank manuscript and the batch-68 Hall Bottlenecks manuscript
- Global priority is not claimed
- Unit-weight and one-shore normalization in general remain open here
- The real-rootedness assertion for the mixed rank-three cover class is identified as a corollary of already existing repository block-stability results; an independent elementary proof is included
- No Lean formalization or journal referee review is claimed

## Files

- `article.pdf`: six-page research note
- `article.tex`: editable source
- `verify.py`: independent exact checker, using only the Python standard library
- `verification.json`: recorded output
- `build_local.sh`: optional build wrapper for a TeX Live environment with missing filename databases; a normal TeX Live installation needs only two runs of `pdflatex article.tex`
- `PROOF_STATUS.md`: dependencies and unresolved scope

## Reproduction

Run `python3 verify.py`. It checks 600 weighted leaf-compression examples, all 4096 graphs on a 4 by 3 bipartition under a fixed nonuniform integer field, and 500 exact mixed-cover cubic examples. All checks pass. The mathematical proofs establish the universal claims; these finite checks are regression evidence.
