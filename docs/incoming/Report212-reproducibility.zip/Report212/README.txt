Report212 - Dominant vertices in sparse graph moments
4 October 2026

RESULT AND BOUNDARY
For every integer window log k=o(S_k), S_k=o(k^(1/3)), the normalized closed
length-2k tree walks with some vertex making at least k-S_k departures have
size (2+o(1)) B_(k+1). Arbitrary depth, repetition and nesting are permitted
inside that off-hub multiplicity budget. The article gives complete proofs,
an exact finite weighted-rotation and two-hub formula, and a separate rigorous
truncated Poisson-neighborhood calculation with counterexamples to untruncated
averaging.

The full equivalent M_(2k) ~ 2 B_(k+1) is NOT proved. An explicit sufficient
middle-return tail estimate is formulated and its implication is proved; the
estimate itself remains unproved here. Finite data are evidence only. Published
counting infrastructure and spectral results are credited, with no global
priority or open-status claim.

MAIN DELIVERABLES
Report212.pdf             Complete article
Report212.tex             Editable LaTeX source
reproduce.py              Full data + PDF + deterministic archive rebuild
CODE_README.md             Detailed finite-computation workflow and scope
CODE_INVENTORY.txt         Exact list of computation files distributed
MANIFEST.json             SHA256 of every other public file
SOURCES.txt                Public references and bounded inspection scope
requirements.txt          Required installed runtimes, compiler and TeX packages

DEFAULT COMPLETE REPRODUCTION
Extract the archive. From its Report212 directory run:
  python3 reproduce.py --out ../replay-normal
  python3 -O reproduce.py --out ../replay-optimized
Each output directory must be new and outside this source directory. Nothing is
downloaded or installed. The source directory is read-only input. Each complete
run freshly compiles C++/GMP and regenerates all rows through256, verifies the
small fixture and full256 digest references, regenerates every public numeric
table exactly, runs the independent finite verifiers and deliberate corruption
harness under normal and optimized Python, rebuilds the PDF to byte stability,
and creates and reads back a deterministic ZIP. reproduction.json hashes actual
ZIP members and the whole ZIP. The two complete rebuild ZIPs should match bytes.

A quicker source/PDF replay is available:
  python3 reproduce.py --out ../replay-quick --quick
It reads fixture32, independently enumerates through8, implements the Python
recurrence through16, and checks fixture consistency and deliberate failures.
It uses the stored public256 table and DOES NOT regenerate or independently
validate those higher rows. The resulting receipt states this reduced scope.

The code-only commands and optional512 source generation are in CODE_README.md.
No complete256 or512 raw arrays are distributed. Optional512 output is not used
by any public table or proof. No third-party papers or private review notes are
included.

VERIFICATION SCOPE
Direct walk enumeration reaches8. A different Python implementation of the
recurrence reaches16. Complete256 tables are from fresh C++/GMP execution;
repeating the same higher-row algorithm is not a different algorithmic proof.
Integer counts and exact rational values precede decimal display. The log-squared
window at16 has threshold exactly k/2, so its union/complement are N/A; a zero
middle sum there is not evidence for the asymptotic sufficient tail.

The code avoids assert-only checks. Deliberate corruption tests verify named
failure paths in both normal Python and -O. The outer driver's own pre-write
failure probe must fail without creating the requested output directory:
  python3 reproduce.py --out ../must-not-exist --self-test-failure
  python3 -O reproduce.py --out ../must-not-exist --self-test-failure
--initialize is authoring-only and permits missing PDF/manifest baselines; it
must not be used to verify a distributed release.

PDF byte identity is scoped to the same TeX and font toolchain. A different
version may typeset correctly but produce different bytes; the driver reports
that mismatch rather than silently treating it as a byte-identical rebuild.
