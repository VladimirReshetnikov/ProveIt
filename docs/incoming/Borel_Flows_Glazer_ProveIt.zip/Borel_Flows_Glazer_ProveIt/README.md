# Borel Flows on Left-Finite Series Fields

**A local-finiteness criterion, a rational-rank dichotomy, and failure of Lie closure**

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov.
Dated 4 October 2026. The delivered PDF has 24 pages.

## Main results

For a nonzero countable divisible ordered subgroup Gamma of the reals, let
L_Gamma consist of real-coefficient formal series whose supports are finite
below every real bound.

The manuscript proves an exact classification of jointly coefficient-Borel
real-parameter field-automorphism flows. Their generators are precisely the
real-linear, valuation-nondecreasing derivations that are locally finite on
every bounded exponent window. Real scalar fixing, valuation fixing, and
coefficientwise entire time dependence are consequences, not assumptions.

It also proves an exact and unique time-one embedding criterion: a Borel
field automorphism embeds into such a flow exactly when it preserves the
valuation and acts locally finitely on every window.

For strict derivations, the criterion reduces to local nilpotence on windows,
or equivalently escape of all iterated monomial valuations to infinity.
Every strict derivation integrates exactly in finite rational rank. At
infinite rank, two explicit integrable alternating derivations have a
nonintegrable sum and commutator; their time-one maps have a product that
cannot be a time-one map of any Borel flow.

The integrable strict derivations form a Borel subset of the natural
coefficient parameter space.

## Research provenance and scope

The mathematical intersection is Glazer's work on Borel/topological algebraic
structures and ProveIt's surreal-series and BCH developments. The paper
answers Question 13.5 in the earlier research draft *Borel Regularity Forces
Summability* **in the countable divisible exponent-group setting**. It does
not claim to solve a remaining numbered problem in Glazer's own paper.

This is an AI-assisted, unrefereed mathematical manuscript. Full proofs are
included, but they have not been independently peer-reviewed or checked by
Lean. The exact priority of the new theorem package remains unverified.
The general formal exponential/BCH correspondence and the uniform-gain
special case are explicitly attributed to prior work. Neither Glazer nor
the repository maintainer is presented as a coauthor or endorser.

## Files

- `borel_flows.tex`: complete self-contained LaTeX source, including bibliography.
- `borel_flows.pdf`: compiled 24-page paper with internal links.
- `verify.py`: standard-library-only exact finite verification program.
- `verification_results.json`: receipt from the delivered verification run.
- `CLAIM_LEDGER.md`: proof status, hypotheses, and limitations.
- `SOURCES.md`: source URLs, inspected material, and repository pin.
- `build.sh`: compilation and verification commands.
- `SHA256SUMS`: integrity hashes for the other package files.

## Reproduce

Requirements: Python 3.10 or later, and a LaTeX installation providing
pdfLaTeX, `newtxtext`, `newtxmath`, `microtype`, `geometry`, `amsmath`,
`amsthm`, `mathtools`, `xcolor`, `booktabs`, `longtable`, `array`, `enumitem`,
`fancyhdr`, `needspace`, `hyperref`, and `bookmark`.

```sh
python verify.py --json verification_results.json
python -O verify.py
sh build.sh
```

The verification performs **5,372 checks using exact rational arithmetic**.
The normal and optimized Python runs produced identical receipts. Bounds and
stage counts appear in the receipt. No test is implemented using an `assert`
that would disappear under optimization.

The script checks finite algebraic identities and examples. It is not a
proof of Baire-category statements, infinite-support closure, or the general
classification theorems. Those arguments are in the paper.

The PDF was compiled with three successful pdfLaTeX passes and shell escape
disabled. There were no undefined references or overfull/underfull boxes;
the only package notice was that epstopdf shell escape was disabled (the
paper uses no EPS figures). Rendered pages were inspected. No source-font files or external papers are
bundled.
