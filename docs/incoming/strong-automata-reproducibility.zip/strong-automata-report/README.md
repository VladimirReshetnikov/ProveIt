# Strongly connected automata

This package contains a research article and reproducible computations for complete deterministic transition structures with a fixed alphabet of k >= 2 named maps. States have no terminal or output labels unless the marked-state corollary is explicitly invoked.

The article proves fixed-order inverse-power expansions with remainders, supplies a finite coefficient algorithm and qualified inverse thresholds, and develops the consequences of the classical exact unrooted divisor formula. The leading equivalents, auxiliary recurrence and logarithm, and Liskovets's exact automorphism formula are prior work. Historical priority of the higher-order refinement remains qualified; see SOURCES.md.

## Start here

- strong-automata.pdf: complete article
- strong-automata.tex and cyclic-lift-proof.tex: editable TeX sources
- SOURCES.md: curated literature and exact OEIS indexing
- REPLAY.md: validation scope and the recorded fresh replay
- MANIFEST.sha256: checksums of all delivered files except the manifest itself

No third-party papers are redistributed. The package contains original code, generated data, explanatory documentation, and the article.

## Reproduce the mathematics

Python 3.10 or later, with mpmath and sympy, is sufficient. Install the dependencies in an environment of your choice with `python -m pip install -r requirements.txt`. The computations themselves need no network.

Run a full fresh replay without overwriting the supplied data:

    bash replay.sh

Replay uses .replay/work as a disposable package-local working directory, reruns every supplied computation, and compares the results with the distributed data. It also runs independent low-order and exact n <= 600 checks and an additional all-model inverse test. Logs stay in .replay. The final status is nonzero if a command or numerical comparison fails.

Individual commands can be run from the package directory:

    python generate_coefficients.py --k 2 --order 5 --digits 70 --output coefficients_k2.json
    python verify_precision.py
    python verify_exact_sectors.py
    python verify_inverses.py
    python verify_all_model_inverses.py
    python independent_checks/derive_low_orders.py
    python independent_checks/check_small_models.py
    python independent_checks/verify_exact_counts.py --k 2 --N 600 --coefficients coefficients_k2.json --output independent_checks/exact_k2.json

Repeat coefficient and exact-count commands for k = 3 and k = 4. Individual scripts replace their named JSON outputs; the full replay isolates these writes. verify_inverses.py imports verify_exact_sectors.py, which intentionally repeats its exact assertions.

## Code and data

- generate_coefficients.py: finite formal saddle, strict renewal, and logarithmic transfer; no count fitting and no truncated infinite endpoint sums
- coefficients_k2.json, coefficients_k3.json, coefficients_k4.json: coefficients through degree five at 70-digit output precision
- verify_precision.py and precision_validation.json: 70/100-digit comparisons, exact modulo-four complex phases, and a k = 500 first-order regression
- verify_exact_sectors.py and exact_sector_validation.json: strict checkpoint and exact recurrence checks, brute labeled and unrooted graph enumeration, terminal subsets, primes, and the one-letter cycle identity
- verify_cyclic_lifts.py and cyclic_lift_validation.json: exhaustive connected lift counts for four small binary quotient/cycle-size combinations
- verify_inverses.py and inverse_validation.json: original B/R/U smooth-inverse evaluations at k = 2,3,4 and n = 40,80,120,240
- verify_all_model_inverses.py and all_model_inverse_validation.json: additional smooth inverse checks for all four models, including labeled counts and the Stirling correction
- independent_checks/: a separate implementation of low-order formulas, graph enumeration, and integer recurrence checks through n = 600; see its README
- verify_replay.py: compares fresh outputs and enforces explicit numerical tolerances
- verify_manifest.py and make_archive.py: checksum verification and an explicit-allowlist, relative-path archive builder

## Build the article

    bash build.sh

The build requires a TeX installation with pdfTeX, LaTeX, Latin Modern, AMS packages, geometry, microtype, xcolor, booktabs, and hyperref. All are standard TeX Live packages. build.sh uses a writable .build directory for TeX caches. If a system format is unavailable it builds a local format; if the standard font map is unavailable it creates a local map from installed component maps. It does not download or install software. Three passes resolve the contents and cross-references. The resulting PDF replaces strong-automata.pdf.

## Scope and limitations

- Each theorem fixes both k and the expansion order; no uniform growing-k result
- Fixed-divisor expansions require n/l to tend to infinity; exact bounds handle large divisors
- To resolve small automorphism sectors, retain larger sectors exactly
- Finite algebraic truncation errors dominate the next automorphism sectors
- No optimal truncation, Borel summability, or complete beyond-all-orders expansion of the identity count is claimed
- Inverse ceilings are brackets with existential constants and sufficiently large cutoffs, not unconditional rounding instructions
- Numerical digits are stability-tested approximations, not interval certificates
- No terminal-state subset is included in the main counts

## Integrity and portable archive

    python verify_manifest.py
    python make_archive.py

The archive builder uses only the documented allowlist, rejects links and unsafe names, checks the manifest first, and writes the ZIP beside this directory. Build caches, replay work, and unlisted files are never included.
