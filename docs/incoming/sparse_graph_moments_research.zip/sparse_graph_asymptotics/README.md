# Sparse graph moments

**Sharp corrections, optimal Poisson laws, and a growing-degree transition**  
Research manuscript prepared with OpenAI assistance for the ProveIt project.  
8 October 2026.

## Read the article

- [article.pdf](article.pdf): the complete research article, proofs, figures, references, and twelve further research questions.
- [article.tex](article.tex): master source; keep its `sections`, `data`, and `figures` directories alongside it.
- [source_audit.txt](source_audit.txt): the inspected sources, their precise scopes, and the boundary of the novelty assessment.
- [claim_ledger.json](claim_ledger.json): mathematical claims, parameter regimes, proof locations, and evidence types.
- [provenance.json](provenance.json): immutable repository snapshots and reproducibility metadata.

## Mathematical scope

For a normalized time-rooted closed tree walk of length `2k`, give each distinct edge weight `c`, regardless of how often the edge is traversed. The sum of these weights is `m_k(c)`, the limiting expected adjacency spectral moment of `G(N,c/N)` when `N` tends to infinity with `k,c` fixed. All growing-order results in this package concern those limiting moments; no simultaneous finite-graph limit is asserted.

Set `w = W(k/c)` and `H_k(c) = E[(X+c)^k]` for `X ~ Pois(c)`.

The article proves:

1. A finite-collision expansion through every fixed order, uniformly for `c` in a fixed compact subset of `(0,infinity)`, and the explicit logarithmic correction

   `log(m_k(c)/(2 H_k(c))) = c w^2 (w+2+2c)/(2k) + c w^5/(6k^2) + O_K(w^4/k^2)`.

2. A signed Poisson–Charlier expansion for the moment-weighted maximum-departure deficit, sharp total variation constants before and after recentering, and optimality among all Poisson means. A positive two-jump compound Poisson approximation improves on that optimal single-Poisson order.

3. The critical growing-degree theorem, uniformly when `a <= c w/sqrt(k) <= b` for fixed positive `a,b`:

   `m_k(c)/(2 H_k(c)) = exp(c^2 w^2/k) [1 + O_{a,b}(k^(-1/4) log^(13/4)(k))]`.

   In particular, `c_k = beta sqrt(k)/log(k)` gives the limit `exp(beta^2/4)`. The proof includes the full complement of the dominant-hub region, not only an explicitly counted subclass.

The earlier ProveIt manuscript already develops the all-fixed-order method at `c=1`. This article credits that precursor. Merely invoking one more of its existing correction terms is not claimed as independent novelty. The parameter extension, explicit evaluations, corrected deficit law, and critical transition are distinguished in the article and source audit. Broader historical priority remains subject to expert review. These are written mathematical proofs with internal independent audits, not proof-assistant certificates or peer-reviewed results.

## Rebuild the PDF

A standard TeX Live installation with pdfLaTeX and the usual AMS, Latin Modern, geometry, microtype, graphics, booktabs, enumitem, fancyhdr, and hyperref packages is sufficient. No BibTeX step is needed.

```sh
./build.sh
```

Or run `make pdf`. The build uses `latexmk` when available; otherwise it runs pdfLaTeX three times. The committed figures and table make this independent of the Python environment and network access.

## Reproduce the archived computations

Exact enumeration uses only the standard library and supports Python 3.10 or newer. To reproduce the pinned symbolic and numerical environment, use Python 3.12 (the archived run used 3.12.14) and install the recorded dependencies:

```sh
python3 -m pip install -r requirements.txt
make verify
```

The three underlying commands, in their required order, are:

```sh
python3 code/verify_exact.py --order 128 --enumerate-through 7
python3 code/verify_symbolic.py
python3 code/numerical_diagnostics.py
```

The recurrence script defaults to order 40 when no `--order` is given; the commands above reproduce the archive's order 128. A smaller recurrence order must still reach the direct-enumeration cutoff. Direct enumeration grows quickly; the archive uses half-length 7 deliberately. The recorded run enumerates all 12,850 walks at half-lengths 1 through 7.

`make clean` removes only local LaTeX build intermediates. It preserves the article PDF, source, data, and figures.

## What the computations establish

| Artifact | Role |
|---|---|
| `data/exact_checks.json` | 84 rationally weighted return-row checks, 84 weighted and 168 coefficientwise simple-forest checks, 21 rotation checks, 1,515 fresh factorial-moment identities, and 13 OEIS prefix terms; all pass. |
| `data/exact_rows.json` | Exact scaled integer rows and moments through half-length 128 at `c=1/2,1,2`; integer strings preserve arbitrary precision. |
| `data/symbolic_checks.json` | Newton identities for block orders 0 through 6, low-row polynomials in `c`, and 132 exact Catalan-product checks; all pass. |
| `data/collision_polynomials.tex` | Generated symbolic polynomials in TeX form. |
| `data/moment_diagnostics.json` | Exact moment ratios converted to decimals and compared with logarithmic approximations. |
| `data/deficit_diagnostics.json` | Floating-point first-collision model, not the full walk law. |
| `data/critical_diagnostics.json` | Floating-point fresh-law average of the exact Catalan quotient in a concentrated window. |
| `data/numerical_summary.json` | Scope and saddle-width stability metadata; these are not interval certificates. |
| `verification_report.json` | Build and visual-review record, including the limits of each check. |

Exact checks test finite identities. Floating-point plots illustrate the formulas and slow asymptotic onset. Neither supplies a proof of a limit, a uniform remainder, or historical novelty. Those assertions are addressed by the mathematical proofs and the source audit.

## Suggested ProveIt integration

Copy this directory as a new report directory, for example:

`SetTheory/Cardinals/docs/reports/generating-functions-and-asymptotics/oeis-sequence-asymptotics/a094149-weighted-moments-and-critical-transition/`

Preserve the existing `a094149-sparse-graph-moments` report and its identity. Add a link to this article from the appropriate report index, following the repository's existing conventions. This package does not contain an upstream commit or pull request, and no repository files were published or changed during its preparation.

The archive includes everything needed to compile or rerun locally. External papers are cited and linked, not bundled. `SHA256SUMS` records the exact bytes of each included source, result, and figure except the manifest itself.
