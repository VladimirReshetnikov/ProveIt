FOURIER LIMITS, EXACT ARRANGEMENT REPAIR, AND TRANSLATED RESTRICTION
IN GOWERS'S QUANTITATIVE FRAMEWORK

Research prepared with ChatGPT for Vladimir Reshetnikov's ProveIt project
Version 1.0, 7 October 2026

MAIN FILES

  gowers_fourier_arrangements.tex  Complete standalone LaTeX manuscript
  gowers_fourier_arrangements.pdf  Compiled article
  figures/arrangement_profiles.pdf  Vector figure used by the manuscript
  figures/arrangement_profiles.png  Raster preview of the same figure
  code/                           Reproducible finite checks and figure source
  audit/SOURCE_AUDIT.json          Pinned source provenance and input identities
  audit/PROOF_REVIEW.txt           Review scope, resolved issues, and limitations
  MANIFEST.sha256                 SHA-256 checksums of the packaged files

MAIN RESULTS

1. The limiting ratio c_d^odd = sup ||f||U2^4 / ||f||Ud^4 equals the
   bounded Fourier extremum beta_odd. Its interval narrows to
   [1/3, 1/2 - 8/pi^2 + 64/pi^4] = [1/3, 0.3464533951610953...].
   When both norm degree and the least prime divisor of the group order
   tend to infinity, the exact joint limit is 1/3.

2. The arrangement defect satisfies the all-order polynomial B_s, with
   a complete interior equality classification and every inverse Taylor
   coefficient optimal in succession. For s=16 the cubic inverse
   coefficient is 155/512. The common-prime quadratic coefficient is
   narrowed to [15/256, 23/256] when s=16.

3. A sharp robust-intersection modulus synchronizes the two directional
   model classes. Two-direction biaffine repair has optimal inverse
   coefficients through degree s-2.

4. A translated Fejer selector preserves the earlier retained count
   while lowering the proposed prime-uniform threshold from L^m to
   L^(m-1). The all-group certificate records torsion and repeated tuples.

The article includes full proofs, 14 further research questions, and a
repository crosswalk. The inherited coarse decoder is reproduced with
credit. It claims no new global Szemeredi bound, no exact unrestricted
value beta_odd=1/3, and no Lean formalization or publication priority.

BUILD THE PDF

From this directory, with a standard TeX Live or MiKTeX installation:

  make pdf

or:

  latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error \
    -no-shell-escape gowers_fourier_arrangements.tex

The bibliography is embedded in the TeX file; no BibTeX step is needed.
The figure is included in the archive. No network access is needed to
compile the manuscript. Standard packages include amsmath, amssymb,
amsthm, mathtools, lmodern, geometry, microtype, booktabs, longtable,
enumitem, graphicx, fancyhdr, tocloft, hyperref, cleveref, and bookmark.

If latexmk is unavailable, run pdflatex with the same flags repeatedly
until the log reports no changed labels or cross-reference warnings.
PDF bytes can change with the TeX version and creation metadata.

RUN THE CHECKS

The four verification programs use only Python's standard library:

  make check

or run these commands individually:

  python3 code/verify_exact_arrangements.py
  python3 code/verify_translated_fejer.py
  python3 code/verify_norm_limits.py --output code/norm_verification.json
  python3 code/verify_series.py

Use ordinary Python, without -O or -OO, because two verifiers use assert
statements for their checks. Each program writes its JSON output beside
the code. The recorded JSON files are included. Regeneration uses the
same deterministic finite cases; the last bits of explicitly marked
floating-point trigonometric diagnostics may vary across platforms.

Exact arithmetic is used for all arrangement and restriction comparisons,
inverse-series checks, and bounded Fourier extrema. The cotangent-cap
cross-check is floating point and is labelled accordingly. The universal
theorems use the written proofs, not an extrapolation from computation.

OPTIONAL FIGURE REGENERATION

  python3 code/make_figures.py

This optional step needs NumPy and Matplotlib. It is unnecessary for a
normal PDF build because the vector figure is already present.

INTEGRATION

The repository baseline is commit
89c1cbc38600279fed03c8e741aba9eafb08ca70, dated 2026-10-07T04:12:28Z.
At that pin, the combined research article includes sources 01-33 and
sources 34-46 are separately staged. No existing repository file was
modified by this deliverable.

Register the manuscript as a new source according to the repository's
current intake numbering. The article's integration section explains
which source-29 and source-33 questions are resolved or narrowed and
where the source-04/source-17 restriction theorem improves. Preserve the
distinction between full-product repair and sparse-domain applications.

For the simplest integration, retain the standalone TeX and its figures
directory. If folding the article into a combined manuscript, import the
body, namespace labels and macros as required by that manuscript, and
retain the explicit citations and parameter hypotheses. Do not replace
the existing finite-U4 coefficient by the qualitative limiting bound.

CHECKSUMS

  sha256sum -c MANIFEST.sha256

The manifest checks the supplied files, not mathematical truth. It omits
itself to avoid a circular checksum. Rebuilding or regenerating outputs
can change their hashes; the manifest records this delivered version.
