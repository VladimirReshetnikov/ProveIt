# Compacted binary trees and a positive Airy amplitude

This archive accompanies the article **A positive Airy amplitude for compacted binary trees**, dated 2 October 2026. It contains the complete signed-memory proof, all-order polynomial-Airy construction, convergent amplitude representation, exact coefficient certificates, and inverse asymptotic algorithm for OEIS A254789.

The result is a positive finite amplitude and a Poincaré expansion to every fixed algebraic order. No numerical digits of the amplitude, effective inverse cutoff, or exponentially small transseries sector are certified.

## Files and dependency

- `compacted_tree_amplitude.pdf` is the article
- `compacted_tree_amplitude.tex` is its editable mathematical source
- `build.sh` rebuilds the PDF with three TeX passes and rejects overfull boxes or unresolved references
- `replay.sh` runs all exact acceptance and corruption suites in both normal and optimized Python
- `checks/verify_compacted.py` checks the exact memory algebra, actual finite support, and gauged coefficients
- `checks/formal/` contains the reusable exact polynomial-Airy engine, independently generated coefficient tables, endpoint certificates, schema checks, integrity manifest, and negative tests
- `dependencies/relaxed_tree_amplitude.pdf` and its source ZIP are unchanged copies of the 24-page private companion article that proves the Jacobi lemmas used here
- `PROVENANCE.json` gives public primary-source references and the unchanged dependency hashes
- `VERIFICATION.md` describes the mathematical and finite-certificate scope
- `MANIFEST.json` and `verify_release.py` check the packaged file inventory, byte sizes, and hashes

The relaxed companion is a mathematical dependency, not an externally peer-reviewed paper. Its comments that compacted trees are outside its scope remain unchanged; the additional compacted proof is the present article.

## Build and replay

Use a recent TeX Live with pdfLaTeX, AMS packages, Latin Modern, microtype, geometry, hyperref, and fancyhdr. Python checks require Python 3.12 and SymPy 1.14.0; the fixed checks use no network or numerical eigenvalue packages.

First validate the extracted release before creating build outputs:

    python verify_release.py

Then:

    ./build.sh
    ./replay.sh

The default replay checks every declared state and coefficient. It does not silently accept empty data, reduced coverage, unsupported options, corrupted coefficients, or an expected rejection with the wrong cause. Acceptance uses explicit exceptions and remains active under `python -O`.

The formal suite includes both relaxed and compacted data because they share one algebraic engine. These finite identities are distinct from the analytic all-order transfer in the article. Archived numerical diagnostics are decimal evaluations and extrapolations, not interval bounds; the exact suite does not recompute the optional large dynamic program.

## Exact coverage

The compacted suite checks nine symbolic identities for odd-time elimination, the exceptional boundary, and cancellation in the gauged bands. For every n=4,...,30 it checks 486 normalized recurrence states, 432 diagonal gauge entries, 432 lower gauge entries, and 405 three-lag gauge entries, including the highest allowed coordinates. Ten deliberate compacted corruptions or invalid input cases must be rejected.

The reusable formal suite checks both polynomial components at every local power through degree nine; profiles indexed 0,...,7; scalar coefficients 0,...,9; exact ghost-boundary and derivative gauges; fresh triangular and generic linear-system constructions; six logarithmic endpoint coefficients; seven multiplicative coefficients including the constant; and ten diagonal-ratio coefficients. Its 53 negative regressions include malformed or missing tables, schema errors, hash violations, incorrect recurrence data, and endpoint coefficient corruption. It also replays the companion's finite Jacobi identities.

The global estimates, amplitude convergence and positivity, arbitrary-depth residual bounds, and inverse error theorems are analytic proofs in the article and its supplied dependency. Finite tests alone do not establish them.
