# K223: construction, independent verification, and further research

This packet contains a deterministic **223-working-state, two-symbol,
one-tape Turing machine** whose blank nonhalting is equivalent in ZFC to
`Con(ZFC)`, with the proof status explained below. It improves on the pinned
224-state ProveIt construction by one working state.

The main deliverable is `report/K223_Construction_And_Research.pdf`.
Its complete TeX source is `report/main.tex`, with the companion `.tex`
files in the same directory. The complete canonical machine is
`portable/results/candidate223.tm`; its CSV representation and state maps
are beside it.

## Exact machine convention

- Working states: `0,...,222`; separate halt state: `223`.
- Symbols: `0,1`; blank symbol: `0`.
- Initial state and head: `0,0`.
- One tape indexed by the integers, initially entirely zero.
- Every transition writes a bit and moves exactly one cell left or right.
- Exactly 446 transition rows, two for each working state.

The SHA-256 of the canonical `.tm` file is:

```
0d4eb8ffbcd5dc025c8dac198c7d8a15404c35f63134b5e3ed0b7df7673d9231
```

## The successful idea

Write `E(a,b)` for the native equality atom and `Q_i A` for its named
universal constructor. The baseline emits both an equality propagation
row and a canonical equality-vacuity helper. Replace them with the single
row

```
G(a,b,c) = E(c,a) -> (E(c,b) -> Q_kappa(a,b) E(a,b)),
kappa(a,b) = 4 P(a,b) + 1,
P(a,b) = (a+b)(a+b+1)/2 + b.
```

The separate helper is removed from the gated K bundle. The report gives
a noncircular derivation of literal equality reflexivity, the old helper,
and the old equality propagation row from G. The reverse derivation is
also explicit. Thus the old and new sources have the **same native
theorems**, including the distinguished refutation target 1. The original
K matrix, code/private-label coupling, and ZFC calibration are inherited.

The source has 4,581 primitive occurrences and 209 distinct subtrees.
A necessary source reassociation keeps its largest consecutive-zero
address run at six. The compiled parent has 226 working states; three
proved transition folds produce the final 223-state machine.

## Proof status and verified scope

The mathematical conclusion is

```
ZFC proves: Nonhalt(candidate223, blank) <-> Con(ZFC).
```

The packet supplies ordinary mathematical arguments formalizable in ZFC,
finite derivation certificates, exact source and table checks, and an
unbounded symbolic runtime verification. **It does not claim a newly
compiled Rocq or Lean theorem about this 223-state table.** The inherited
K230 development and the later K224 adaptations have their own explicitly
recorded proof boundaries.

A fresh independent replay returned `FULL_REPLAY_PASS`:

- The exact source constructor and arithmetic emitter reproduced their
  pinned bytes and formula trees.
- Both finite logical checkers passed.
- The three-fold checker proved positive whole-tape simulations.
- All **5,956 guarded source cases** were freshly rederived, over arbitrary
  natural register values, gap, first spare value, and finite spare tail.
- The new runtime used all **446 literal transition rows** and 1,431,799
  symbolic proof steps.
- All **409,835 blank-start transitions** were checked. The endpoint has
  logical registers `(3,0,0,0,3,0,0,0,0)`, 167 spare blocks of value 1,
  head `-5`, and canonical dispatcher state 22.

The independent full replay checks the stored inherited runtime evidence
for the baseline; `--full-baseline` below can additionally rederive that
older runtime. This distinction is recorded in the replay receipt.

## Reproduction

Use Python 3.10 or later with assertions enabled. The core replay uses
only the standard library and requires no network access.

From this extracted packet directory:

```bash
python3 -B portable/reproduce.py --output-dir ../K223-quick
python3 -B portable/reproduce.py --full --output-dir ../K223-full
```

Use a new, empty output directory outside the supplied packet. To rederive
the inherited K224/K225/K226 runtime as well:

```bash
python3 -B portable/reproduce.py --full --full-baseline --output-dir ../K223-all
```

To regenerate the nine exploratory equality-front-end proof artifacts:

```bash
python3 -B research/equality_frontends/research_reproduce.py --output-dir ../K223-equality-research
```

To replay the additional symmetry, polarity, and obstruction evidence
after the core replay:

```bash
python3 -B additional_research/reproduce_additional.py --core-replay ../K223-full --output-dir ../K223-additional
```

Add `--full-symmetry` to rederive the alternate 224-state SYM table's
6,097 unbounded cases. That alternate machine is research material; the
record candidate in this packet is the canonical **223-state G machine**.

To rebuild the report, install a standard pdfLaTeX distribution and run:

```bash
python3 -B report/build_report.py --output-dir ../K223-report-build
```

The generated `main.pdf` contains the entire report and the literal table.
The delivered PDF is a renamed copy of that build. The table appendix is
generated from the pinned machine bytes rather than transcribed manually.

## Additional research

`additional_research/` retains the work from the independent search:

- A calibrated SYM source and complete 224-state table, with a separate
  source check, fold proof, full runtime receipt, and 64-root logical
  certificate containing 55,327 proof nodes.
- A negated-matrix K presentation whose fused bundle uses **four native
  negation macros instead of eight**, saving 188 expanded instructions.
  Its code/private-binder proof and 19-step formula-rewrite certificate
  are explicit. This did not improve the selected 223-state machine.
- A 229-state polarity compiler specimen, clearly marked as finite-tested
  research material. It has a checked arithmetic emitter, but no retained
  unbounded runtime theorem for that table. Its finite screen must not be
  substituted for the main candidate's verification.
- Counterinterpretations for a proposed quantifier-axiom replacement and
  all six pairwise identifications in the four-variable implicational
  single axiom. These concern the stated logical fragments, not the full
  K set theory.
- Scoped failed control-layout and shared-router searches. Development
  search scripts retain their original workspace dependencies and are
  not part of the portable proof replay.

The report also discusses finite class theories, reflection schemes,
alternative equality frontends, and interpreter/seed tradeoffs. It
distinguishes proved logical alternatives, concrete compiled tables,
finite-only experiments, and proposals without a measured machine.

## Provenance and incorporation

The baseline is ProveIt commit
`49ee7cfdc8e0364c6db3614675d141d66f9350ed`, whose incoming archive is
`K224_Construction_2026-10-20.zip`. Its SHA-256 is
`cf5db8d08a34f5661ad1266226809ed1f0099fd38374c66d127e1e06519c6887`.
The exact archive is embedded under `portable/vendor/`.

The 223-state G construction was obtained from existing shared ProveIt
project work during the independent SYM/polarity search. This packet
retains its **core portable files unchanged**, independently replays and
audits them, and adds the separate research and review evidence. The
discovery of the G construction is not attributed to the SYM/polarity
branch. `PROVENANCE.json` records the input snapshot and hashes.

`portable/manifest.json` covers the unchanged core reproduction packet.
`MANIFEST.sha256.json` covers this complete deliverable, including the
PDF, TeX, additional research, and independent audit receipts.

The packet is suitable for incorporation as a research contribution. The
new mathematical and executable evidence should retain the stated
proof-assistant boundary when it is incorporated.
