# K226: a 226-state binary machine for ZFC consistency

This research package constructs a **226-working-state, two-symbol, one-tape
Turing machine**, starting on a blank tape, by combining the ProveIt reductions
with Elliot Glazer's compact K230 axiom system. It includes the literal table,
deterministic source construction, ordinary mathematical proofs, a direct Rocq
endpoint, the paper's TeX and PDF, complete verification evidence, and pinned
upstream sources.

The target assertion is

\[
\mathrm{ZFC}\vdash
\bigl(\operatorname{Nonhalt}(M_{226},\mathrm{blank})
      \leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

The biconditional itself does not assume consistency. Assuming ZFC is
consistent, the machine does not halt and ZFC cannot prove that nonhalting.
The package does not infer unprovability of halting from mere consistency.

## Exact selected machine

The standalone public table is [`machines/k226.tm`](machines/k226.tm).

| Property | Value |
|---|---:|
| Working states | **226**, numbered 0 through 225 |
| Binary transition rows | **452** |
| Start state | 0 |
| Initial head position | 0 |
| Initial tape | Identically zero, infinite in both directions |
| Alphabet | 0, 1 |
| Moves | L, R |
| Interpreter dispatcher | 82 |
| Separate halt label | 226, with no transition rows |
| Blank initialization | 409,835 transitions |
| Deleted original K230 states | 65, 79, 140, 175 |
| Changed surviving original K230 rows | 52 |

The SHA-256 includes the start header and final newline:

```text
b58279b8b2e2cf029dd94e084d47cd6097772d7bce2a62653767895123d29599
```

Each noncomment line is `state read write direction target`. The halt label is
excluded from the working-state count. `machines/k226_k230labels.tm` retains
the original K230 labels for review; `machines/k226_native.tm` uses the inherited
interpreter labels. `machines/renumbering226.json` gives the complete bijections.
The symbolic runtime driver's own canonical numbering is another checked
bijection, so its canonical-table hash differs from the selected public hash.

## Where the four savings come from

All labels in this section are original K230 labels, before dense renumbering.

| Change | State saving | Construction |
|---|---:|---|
| Closed increment/drain identity | 1 | Four source replacements expose the fold `79 -> 63`. |
| Delayed erasure | 1 | Coordinated helper changes allow `140 -> 71`. |
| Decoder-role reassignment | 1 | Move the `pi` role of 175 into existing state 150, then its `zi` role into existing state 152. |
| Duplicate exposed by reassociation | 1 | Rebracket a closed source subtree so both rows of 65 equal those of 98; quotient `65 -> 98`. |

The third saving adapts the older boundary and predecessor-bit ideas together;
they yield **one deletion** in this layout. The fourth saving is an additional
source/dictionary optimization. It reduces the number of distinct source
subtrees from 212 to 211.

The complete source recipe has four H substitutions, **two boundary rotations**
and **eleven rotations of three closed chunks**. The boundary rotations include
a nonclosed `CB1` chunk and are justified by complete source-control-graph
checks. They are not applications of the three-closed-chunk reassociation lemma.

Address correctness matters independently of source equivalence. Initial 227
and 226 layouts had seven consecutive zero bits in some instruction addresses,
which confused the separator scanner. Two repairs at the 227 stage and five
repairs at the 226 stage remove those collisions. The exact rejected tables,
tape discrepancies, and replayable counterexamples are retained.

The historical 243-to-235 savings are not additive on K230. Two were already
present; two transfer directly; the boundary and predecessor ideas combine;
and two other literal historical folds have changed sharing premises and were
not transplanted. The complete accounting is in
[`source-construction/transfer_matrix.md`](source-construction/transfer_matrix.md).
No minimality or impossibility result is claimed.

## Proof chain and verification scope

The paper separates three kinds of evidence.

**Mathematical simulation proofs.** The exact selected table satisfies every
instruction frame for arbitrary natural primary-register values, an arbitrary
natural additional gap, an arbitrary first spare register and a finite spare
tail. Four finite-list induction schemas and unary-run induction cover
unbounded values. Every nonhalting source instruction has the exact required
whole-tape/head/register successor. The halt case reaches the unique terminal
state after a positive number of transitions. A separate exact blank-tape
calculation establishes the required seed.

| Complete selected-table check | Result |
|---|---:|
| Source leaves | 5,121 |
| Guarded cases | 6,656 |
| Symbolic rule applications | 1,615,284 |
| Largest case | 412 symbolic rules |
| Minimum constant instruction duration | 13 transitions |
| Finite-list induction schemas | All four |
| Source maximum depth / zero run | 41 / 6 |
| Rows outside runtime and startup coverage | None |
| Exact initialization support | 351 one-cells, all other cells zero |

The adapted portable driver was replayed in full and its complete 6,656-case
array agrees with the earlier independent full replay. Its fuel bounds proof
search in the checker, not register values or actual machine running time.

The source H identity is proved by induction and independently audited at every
external entry and exit. The later reassociations preserve the complete ordered
source graph. The role fold has eight positive-block proofs with arbitrary
outside tape. The duplicate quotient commutes with one TM step on **all 454
rows of its intermediate source table**, without a tape invariant.

**External Rocq proof.** The exact dense table has its own 226-working-state
context. The direct endpoint is

```coq
K226F.CorrectDense226.tm226_halts_iff_ZFC_inconsistent
K226F.CorrectDense226.tm226_nonhalting_iff_ZFC_consistent
```

The first states blank halting iff `StandardZFC` has a finite classical
derivation of falsity. The second is the negated equivalence. `StandardZFC`
includes Foundation, Choice, and the ordinary Separation and Replacement
schemas. The new source bridge uses a checked offset certificate with 2,376
checkpoint pairs, 4,750 branches, and eight nonzero offsets, each `+1` in
register 5 at a test of register 6. Both directions are checked independently.

Both exact226 endpoint theorems compiled closed, and the independent
`coqchk` recheck of `K226F.CorrectDense226` passed. All 19 portable proof
sources also compiled afresh. Only two corrected count comments distinguish
the kernel-checked source from the portable source; an exact correspondence
receipt retains both versions. The default build performs a fresh kernel check.

The complete compiler, assumption, and independent-kernel-check receipts are
under `rocq-extension/receipts/` and `evidence/rocq230/`. See their exact status
and the paper's Rocq section. The frozen native subpackets describe only their
own mathematical-checker scope; the separate Rocq subtree supplies the new
direct formal endpoint. The pinned toolchain is Rocq 9.1.0, rocq-stdlib 9.0.0,
and OCaml 4.14.2.

**ZFC internalization.** A closed external Rocq theorem is not a serialized
proof in an encoded ZFC calculus. The displayed ZFC-provability assertion is
supported by the explicit finitary mathematical argument: arithmetize the
fixed table, source simulation, proof enumerator and finite-derivation
translations; formalize their recursion and induction in ZFC. The upstream
K-to-ZFC direction constructs finite derivations using finitely many axiom
instances. No assumption of a model of ZFC or of ZFC's consistency is used.
The archive does not claim to contain a separately serialized ZFC proof.

Finite instruction fixtures and rejected controls are retained for diagnosis.
Their successful runs are not the unbounded simulation theorem.

## Reproduce without network access

The default suite needs Python 3.10 or later, assertions enabled, and a C++17
compiler available as `g++`. It writes into a new or empty directory outside
the delivered package:

```sh
python3 -B reproduce.py --output /tmp/k226-quick
```

This checks the manifest, rebuilds both selected source/table checkpoints,
rechecks local and source proofs, replays the duplicate quotient and the
rejected scanner witness, runs 26,624 instruction fixtures, proves the exact
blank initialization, audits the delivered complete proof cases, and rebuilds
both equational packets. It preserves the delivered files.

To reconstruct every universally quantified instruction proof afresh:

```sh
python3 -B reproduce.py --full --output /tmp/k226-full
```

The full suite compares **every case** with the delivered full evidence.
On the preparation machine, the selected symbolic proof itself took about
two minutes. Timings are diagnostic and are not proof premises.

The independent native packets can also be checked directly:

```sh
python3 -B native226_extension/reproduce.py \
  --base native227_evidence --output /tmp/k226-native --full
```

The full inherited H guard and intermediate controls have their own replay:

```sh
python3 -B native227_evidence/reproduce.py --output /tmp/k227-native --full
```

For the complete external formal proof, first activate the pinned Rocq
toolchain, then build the vendored reference and the extension:

```sh
python3 -u vendor/k230-rocq/build.py \
  --reference vendor/jeff-reference --coqchk --require-opam-stdlib
python3 -u rocq-extension/build.py \
  --reference vendor/k230-rocq --jeff-reference vendor/jeff-reference --states 226
```

The extension's default formal build includes independent `coqchk`. Its
`--all` option also rechecks the 227 and 229 endpoints. Its `--check-only`
option performs source, literal-data, and generation checks without invoking
Rocq; that option alone is not a proof-assistant verification. Refer to
`rocq-extension/README.md` for exact load paths and output directories.

The paper is rebuilt from the package root with:

```sh
python3 -B research/generate_appendices.py
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

## Other formalism results

The paper gives the compact K schema explicitly and explains both finite
proof translations to ordinary ZFC. It also examines direct ZFC proof search,
finite equational noncollapse, constructor sharing, and a possible finite
class-theory frontend.

The concrete extra encoding result is a **574-bit prefix packet** for E663:
nine operation symbols, seven equations and ground query `Q(d) = d`. The
complete cost is 46 codebook bits, 508 equation-term bits, 8 framing bits and
12 query bits. The decoder receives only the bit string and the fixed codec
grammar; all operations, arities and variable slots are declared in the packet.
An exact round trip checks the presentation up to bijective renaming.

The independent E679 constructor-sharing study includes an ordinary
equiconsistency proof and a 679-bit fixed-width packet, or 586 bits under the
new prefix codec. E663 is the smaller concrete packet. Neither packet supplies
a counted binary proof-search interpreter or blank writer, and neither is
used in the 226-state count.

## Package map

| Path | Contents |
|---|---|
| `report.tex`, `report.pdf`, `sections/` | Full paper, formulas, exact table and complete transition delta |
| `machines/` | Public table, original-label and inherited-label forms, renumberings, intermediate tables |
| `source/` | Pinned original, H-transformed and selected source lists |
| `source-construction/` | Deterministic selected construction, source proofs, offset certificates, discovery controls and transfer matrix |
| `verification/`, `evidence/` | Independent source/local audits, exact runtime drivers and complete receipts |
| `native227_evidence/` | Frozen proved checkpoint and inherited symbolic engines/controls |
| `native226_extension/` | Compact final extension, exact quotient and failing-layout witness |
| `rocq-extension/` | Direct dense226 proof, generic offset proof, intermediate formal endpoints and portable builder |
| `formalisms/` | E663/E679 presentations, full prefix codec and constructor-sharing proof |
| `vendor/` | Exact K230 source, 115 pinned reference files, unchanged ProveIt235 incoming archive |
| `MANIFEST.json`, `SHA256SUMS` | Final distributed file identities |

## Pinned inputs and attribution

| Input | Commit |
|---|---|
| [Elliot Glazer's K230](https://github.com/elliotglazer/k230-rocq) | `3142e4dd980f0be12f4abb636c4ae2528afc17eb` |
| [Jeff's reference](https://github.com/jeff87654/busy-beaver/tree/zf-254/ZF/m254) | `c132d7eae8158cd3a9850ea3eb7251158c3dd821` |
| [ProveIt235](https://github.com/VladimirReshetnikov/ProveIt/commit/0128d662fd46f72dc84505176ae8ec28affb2d9d) | `0128d662fd46f72dc84505176ae8ec28affb2d9d` |
| [ProveIt236](https://github.com/VladimirReshetnikov/ProveIt/commit/0b5fec6980cc3a5ba7dd47b404f0cbbe9a451c02) | `0b5fec6980cc3a5ba7dd47b404f0cbbe9a451c02` |

The unchanged ProveIt235 ZIP is retained because it contains the full earlier
construction and formalism lineage. Its quick mathematical suite was freshly
replayed; its delivered full-runtime evidence was audited, without claiming a
fresh full235 symbolic rebuild. The K230 source and required reference proof
files are present for offline reproduction.

Original license and attribution notices remain with the imported code. In
particular, `vendor/k230-rocq/THIRD_PARTY.md` distinguishes MIT, MPL-2.0 and
custom proof-file scopes. This package does not apply a new blanket license
to those imported files.

The selected construction can be incorporated under
`Computability/BusyBeaver/Research/ZFC/`, with the complete ZIP under
`docs/incoming/`. This delivery does not publish or merge changes to either
upstream repository.
