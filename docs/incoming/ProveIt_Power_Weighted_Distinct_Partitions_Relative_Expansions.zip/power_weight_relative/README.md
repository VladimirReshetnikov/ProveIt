# Relative expansions for power weighted distinct partitions

This package studies A_a(n) = [q^n] product_{k>=1}(1+k^a q^k), for fixed real a>0. Its main results are:

- A smooth lattice-minus-integral boundary sector with an exact coefficient functional
- A finite Gamma, digamma and Hurwitz zeta algorithm at every order for integer powers
- Relative coefficient expansions to every fixed algebraic order in t ~ a log(sqrt(2n))/sqrt(2n)
- Inverse models with exact-range error O(t^M), and eventual nearest-integer recovery for M>=1
- The leading-log conjectures for OEIS A092484 and A265840 through A265842 as applications

The report is unrefereed ordinary mathematics, not Lean formalized. It makes no claim that the asymptotic series converges, that an effective onset is known, or that an exponentially small lattice correction has been derived. Uniformity in the power is on compact subsets of (0,infinity), not for powers growing with n. Exact-range rounding and arbitrary-threshold rounding have different, explicitly stated scopes.

## Contents

- article.pdf and article.tex: the complete standalone proof
- checks/check_corrections.py and .json: exact boundary coefficients for power1 and Gaussian cumulant blocks
- checks/check_reconstruction.py and reconstruction.json: independent probability-variable cumulants and weighted profile enumeration
- checks/check_integer_roots.py and .json: independent rational reconstructions at the square-weight roots, and Gamma constant check
- checks/check_logarithmic_reversion.py and .json: exact formal reversion for the inverse-log corollary; general powers follow by pi^2 -> pi^2/a^2 and the displayed overall factor
- checks/check_boundary.py: optional numerical boundary illustration
- checks/check_relative_numeric.py and .json: exact product dynamic programming and numerical integral comparisons
- checks/verify_numeric_examples.py and .json: independent exact coefficient recurrence and 65-digit log-coordinate quadrature for the printed table
- run_checks.sh: exact symbolic checks only
- verify_package.py and PROVENANCE.json: reproducible file hashes and source links
- build_local.sh: the build helper used in the original environment

## Reproduce

The exact checks require Python3 and SymPy. Run:

    bash run_checks.sh
    python3 -O verify_package.py

All acceptance tests use explicit exceptions and remain active under python -O. The scripts regenerate deterministic JSON outputs. The optional numerical programs require mpmath. They are not directed interval certificates and are not inputs to the proof. Exact integer coefficient values in the table were checked by two separate recurrences.

A standard TeX Live installation can build article.tex with two pdflatex passes. Required packages are amsmath, amssymb, amsthm, mathtools, geometry, lmodern, microtype, booktabs, hyperref and xurl. build_local.sh preserves the explicit font/format paths used for preparation; on another system, ordinary pdflatex is normally preferable. No network is needed once these standard dependencies are available.

## Source positioning

The OEIS fixed-power entries currently state their leading logarithmic asymptotics as conjectures. The nearest located general source using the same inside weights is Gikunda's March2026 dissertation, but its distinct-part tilt theorem uses a shrinking exponent a=O(t^delta). The report distinguishes this from fixed a and discusses the different assumptions in Granovsky–Stark, Bridges–Brindle–Bringmann–Franke, Ahmadi–Gomez-Aiza–Ward, and Canton et al. This bounded literature comparison is not an exhaustive priority claim.

The earlier A022629 report remains unchanged. The present contribution is the smooth matched boundary sector, all-orders relative corrections and higher-accuracy inversion; it is not merely a change of the fixed power in a leading logarithmic formula.
