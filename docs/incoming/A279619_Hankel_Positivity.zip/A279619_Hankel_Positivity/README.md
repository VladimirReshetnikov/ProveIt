# A Sharp Positivity Threshold for OEIS A279619

**Strict total positivity through order five, a twelfth-moment obstruction,
and all-orders Hankel asymptotics**

Research report prepared for Vladimir Reshetnikov, 4 October 2026.

## Results

For c[0]=1, c[1]=2 and

    (n+1)^2 c[n+1] = (26 n^2+13 n+2)c[n] + (27 n^2-27 n+6)c[n-1],

the infinite Hankel matrix (c[i+j]) is strictly totally positive of order
five, but not totally nonnegative of order six. Its shifted 6-by-6 minor is

    D_6(1) = -26875777009408537346562624.

An elementary ratio argument proves global strict log-convexity. The stronger
TP_5 theorem has a finite exact certificate covering every index: 21 rational
polynomials with 1,090 strictly positive coefficients after translation.

The first eleven terms c[0] through c[10] are representable as moments of a
positive measure supported at zero and five positive points. The actual
c[11] is below the minimum admissible next moment by exactly

    210335094301031002274 / 6107572673541.

The report proves an all-orders fixed-size Hankel expansion and a general
all-orders coefficient generator. Every fixed total-positivity order is
restored sufficiently far out in the sequence, but no single threshold
valid for all orders is proved. Inverse envelope expansions and safeguarded
integer rounding brackets are also supplied.

## Read and verify

- `article.pdf`: 23-page article, including ten further-research topics.
- `article.tex`: complete LaTeX source with internal bibliography; no figures
  or external bibliography database are required.
- `code/verify_certificates.py`: independent checker; Python standard library
  only. Does not import SymPy or the certificate generator.
- `code/generate_certificates.py`: optional exact SymPy certificate generator.
- `code/asymptotics_and_experiments.py`: optional symbolic coefficient generator
  and exact/high-precision experiments, using SymPy and mpmath.
- `data/`: complete coefficient vectors, exact moment witness, tables, and logs.
- `SOURCE_AUDIT.md`: provenance and scope of the novelty claim.
- `OEIS_NOTE.txt`: an unsubmitted draft comment; no OEIS entry was edited.
- `SHA256SUMS.txt`: file integrity manifest, not a substitute for verification.

From the extracted directory, run:

    python code/verify_certificates.py

The checker proves polynomial identities by exact interpolation on grids
whose sizes exceed explicit degree bounds. It does NOT infer universal signs
from finitely many sampled signs. Coefficient positivity plus the verified
identities gives a sign proof on the entire half-line; ratio induction then
covers the integer sequence. The classical strict Fekete criterion transfers
contiguous positivity to arbitrary minors.

The exact checker also verifies the ratio base case, all twenty initial
minors, the negative determinant, the degree-five polynomial obstruction,
its orthogonality identities, and the exact minimum-moment repair.

Optional regeneration:

    python -m pip install -r requirements.txt
    python code/generate_certificates.py
    python code/verify_certificates.py
    python code/asymptotics_and_experiments.py

Build the PDF with a LaTeX installation providing the packages listed in the
preamble (including newpx):

    latexmk -pdf article.tex

## Status and boundaries

This is unrefereed research, not Lean-formalized. The main sequence-specific
proof includes exact computer-assisted certificates with independent replay.
The general asymptotic proofs are given in the article. Numerical tables are
illustrations, not proofs of the global signs.

The exact gamma evaluation of the sequence's leading asymptotic constant was
already obtained in the ProveIt report cited in the article; it is not a new
claim of this report. None of the new global sign or truncated-moment results
requires that evaluation. Targeted source checks found no earlier statement
of the sharp TP_5/not-TN_6 result or the exact twelfth-moment repair, but this
is a limited literature audit, not proof of historical priority.

Open questions include a positive Hamburger measure, optimal tail thresholds,
a single Stieltjes-positive tail, and uniform growing-order asymptotics.
No repository files or external services were modified.
