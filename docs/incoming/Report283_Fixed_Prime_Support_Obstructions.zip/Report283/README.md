# Report283

Fixed prime support obstructions to Section 13 extraction

Fix an integer r >= 2 and an integer s with r^s >= 8r, and set a=r^(-s). Every sufficiently large N with r^s | N and rad(N) | r supports one canonical genuine context with selected exact-cutoff initial data, all six literal source budgets, and a genuine Stage 13.6 witness nested inside the selected initial progression.

For this same context, EVERY genuine alternative initial D/E at the exact cutoff admits no Stage 13.6 / weak Stage 13.7 continuation. The alternative records need not have a budget M or satisfy the other five numerical budgets. The common width inequality depends only on a,N. It forces positive critical-height count and, separately, spectral radius below 1/4. Exact annihilator frequencies and the sharp 1/3 subgroup rigidity threshold force every genuine alternative Q step to be divisible by r. Thus no genuine initial package with unit Q step exists in this particular context and range; the same divisibility transfers to every Stage 13.6 R step. No divisibility claim is made for the Stage 13.4 P step.

The moduli may have several prime factors with independent exponents above the required divisibility floor. The original prime-power threshold is unchanged. This does not classify every composite modulus or general unit-step contexts, contradict the actual prime-qualified theorem, or claim Lean verification.

## Contents

- article.tex: complete editable mathematical article
- Report283.pdf: compiled, page-reviewed PDF
- companion/exact_checks.py: standard-library bounded exact diagnostics, including mixed support and all-initial consequences
- tests/test_companion.py: 35 independent enumeration and defensive mathematical regressions
- tests/test_build.py: 37 build, inventory, path, subprocess and archive regressions
- build.py: offline bounded deterministic reproduction and packaging
- SOURCES.md and provenance/source_manifest.json: source scope and exact retained-byte bindings
- provenance/sources/: five relevant exact-byte Lean snapshots at one fixed commit
- MANIFEST.sha256: every public payload file, excluding the manifest itself

The source snapshots are a reading set. Imported dependencies are not included, so this is not a standalone Lean project. No earlier article body, private review, tool receipt or repository checkout is bundled.

## Quick verification

From the extracted Report283 directory:

    python3 -I -B build.py verify
    python3 -I -B companion/exact_checks.py
    python3 -I -B tests/test_companion.py
    python3 -I -B tests/test_build.py

To reproduce the checks, PDF and ZIP in a fresh or empty directory outside this source tree:

    python3 -I -B build.py reproduce --output /tmp/report283-rebuild

Do not reuse a nonempty output directory. The builder requires an ordinary absolute path outside the source tree, rejects protected locations, and never modifies the distributed source files. It rejects symlinks, hard-link aliases, nonregular files, unexpected files and directories, changed hashes and malformed manifests.

To deterministically repackage already verified distribution bytes without recompiling:

    python3 -I -B build.py package --output /tmp/report283-repackage

The external report283_fixed_prime_support.zip.sha256 sidecar binds the actual ZIP. Internal SHA256 values identify files; neither hashes nor the packaging checks certify the mathematics or independently establish upstream origin.

## Reference environment and dependencies

Reference build: Linux; CPython 3.12.14; pdfTeX 3.141592653-2.6-1.40.26 (TeX Live 2025/dev/Debian); kpathsea 6.4.0/dev. Use Python 3.11 or newer for full reproduction, including the integer conversion limit. Full reproduction requires Linux no-follow directory descriptors and /proc/self/fd, plus /usr/bin/pdftex and /usr/bin/pdflatex. The TeX source uses fontenc, lmodern, amsmath, amssymb, amsthm, mathtools, geometry, microtype, enumitem, booktabs, longtable, array, xcolor and hyperref. No Python packages, network access, package installation or Lean toolchain are needed by the companion.

The builder creates a local LaTeX format with shell escape disabled, compiles twice, and rejects overfull boxes, unresolved references/citations and rerun warnings. Deterministic metadata, fixed archive ordering, 2026-10-07 timestamps, fixed file permissions and fixed compression settings are used. A PDF rebuild from the distribution must match its stored hash. PDF byte identity is toolchain-sensitive: a different TeX build or font environment can give a mismatch even if the mathematics and appearance are unchanged. Report and inspect such mismatches; do not overwrite the supplied manifest to make the check pass.

Both test suites and the exact companion run normally and under Python -O, with identical standard output required. Each build-launched test or diagnostic process receives a deliberately restricted PATH and a 640-digit integer-to-string limit. The companion's checks use explicit failures rather than assert, so optimization cannot silently remove mathematical validations. Subprocess output and runtime are bounded. Original and staged source inventories must remain unchanged. Reproduction logs and a machine-readable receipt are written only to the external output directory and are not bundled in the public ZIP.

The builder and its 37 security regressions are adapted from Report280's packaging code. The mathematical companion and its 35 tests were developed for Report283. The five Lean files are byte-identical retained snapshots, not newly authored code.

## Diagnostic coverage

All 37 builder regressions and 35 companion regressions run normally and under Python -O. The companion JSON reports the full model inventory. Its verified coverage is:

- 40 (r,N) models at 37 distinct moduli: 24 retained prime-power models and 16 composite-r models with independently varying prime exponents
- All 2,456,341 affine coefficient pairs covered by exhaustive forced-intercept histograms, with an independent inverse-equation check at every slope/point pair
- Twelve direct-enumeration regression models covering 88,844 coefficient pairs by separately iterating slope, intercept and point
- 160 exact rational surrogate alias cases
- 40 annihilator cases with 2,730 exact phase checks; 20 admissible strip cases include another 779 annihilator phase checks
- Every one of 5,895 residue steps in the model list, checking image order r/gcd(r,d), exact centered maximum, strict one-third and one-quarter rigidity, and 1,984 complete-period divisible-step carriers
- Subgroup orders 2 through 128 and the sharp order-three image at radius 1/3
- Retained 77,328 step-prime carriers, including 38,664 wrapping parameterizations and lengths beyond the additive period
- 20 admissible strip models with joint convolution, independent binomial coefficients, energy and fixed-height normalization
- Twelve formal monomial identities, 79 scalar integer comparisons and the c<d/8 exponent margins
- Retained 20,864 positive rational floor cases; 25,024 additional rational inputs covering 47,968 floor/predecessor branches, of which 16,640 have X>8
- Six eight-threshold/six-budget dyadic toys and 12 width-only toys covering both source length branches; the latter explicitly do not assume the other five budgets
- The outside-support r=2,N=80,slope=3 example with agreements [0,32,64], and the retained N=18 cancellation-boundary example
- Five source snapshots checked by exact byte length, SHA-256 and Git blob SHA-1 against a single five-entry manifest

Small models test the stated local algebra and combinatorics. They do not claim to satisfy the theorem's enormous thresholds. Some mixed-support agreement/subgroup models satisfy r | N and rad(N) | r without the additional strip depth r^s | N; full strip models are labelled separately. All arithmetic is exact integer, rational, counter or formal exponent arithmetic, without floating-point spectral certification.

## Limits and quantifiers

The arbitrary-parameter proof is in article.tex. Finite checks do not prove the universal real-power inequalities, sine estimate or existence of N0. Genuine q0, Q13, N0, k0 and witness N are not evaluated. Dyadic scale checks deliberately substitute toy constants and are not genuine source witnesses. No network access, Lean compilation, kernel or dependency audit, or application of a prime theorem at a composite modulus is performed.

The selected D0/E0/M/F0 satisfy every input predicate and all six budgets. For arbitrary alternative D/E, only the genuine exact-cutoff initial predicates and the common width property of a,N are used. No survival of the other five budgets under reselection is assumed. There need not be a Stage 13.6 witness for each alternative pair; the displayed F0 establishes nonvacuity for one pair.

Every prime divisor of N must divide the fixed r. The threshold depends on r,s. The theorem is not uniform over changing support, gives no squarefree family, and does not settle unit-step extraction in other contexts. The outside-support r=2,N=80 example only diagnoses why the affine-cap proof cannot be extended indiscriminately.
