# Small machines for Con(ZFC)

Research report prepared for Vladimir Reshetnikov, 16 October 2026.

## Start here

Read **report.pdf**. The complete editable manuscript is **report.tex** plus
**experiment_results.tex**. The report audits ProveIt through commit
47f3a3602946dfe48803a91a910c646e74637ac8, including the four distinct
requested commits and the newer incoming archives at that cutoff.

The proposal keeps the equality-free one-schema PSC theory, but replaces
the incomplete shortened logical calculus with a complete first-order
refutation procedure. The supplied ground-clause reference implements
that procedure on ideal unbounded finite storage. It has not been
compiled into a new binary Turing machine, and no new state record is
claimed.

The report also supplies an ordinary mathematical PA formalization
argument for the finite-sort obstruction, a general fresh-hull theorem,
and a tagged repair to one Capture-to-Collection inference.

## Contents

| Path | Purpose |
|---|---|
| report.pdf | Typeset report, proofs, proposal, and bibliography |
| report.tex, experiment_results.tex | Complete LaTeX sources |
| Makefile | PDF build and principal finite-check commands |
| code/clausal_trace.py | Signed clausifier, ground clausal trace checker, exact PSC entry point, and exhaustive candidate codec |
| code/qpsc_syntax.py | Attributed inherited PSC formula constructor |
| code/check_clausal_trace.py | Independent finite semantic comparisons, propositional oracle, and targeted regressions |
| code/synthetic_ground_refutation.json | Generic inconsistent test theory and a closed certificate |
| code/specialization_certificates.json | Cross-variable and diagonal specialization certificates; dependence control |
| code/CLAUSAL_TRACE_ATTRIBUTION.md | Attribution and exact source pin for the inherited constructor |
| code/capture_tagged_check.py | Hereditarily finite counterexample and tagged-repair regression |
| code/equality_free_countermodel.py | Unchanged inherited finite-sort regression; see COUNTERMODEL_ATTRIBUTION.md |
| code/search_full_grammar.py, vendor/ | Reproducible equality-preserving grammar experiment and pinned inputs |
| data/clausal_trace_proof.md | Detailed certificate contracts and mathematical correctness argument |
| data/clausal_trace_results.json | Executed results for the principal finite suite |
| data/clausal_trace_manifest.json | Sizes and hashes for the reference implementation and its evidence |
| data/capture_tagged_proof.md | General tagged argument and source locator |
| data/capture_tagged_results.json | Executed finite Capture regression |
| data/source_manifest.json | Immutable repository and literature provenance |
| data/repository_audit.md | Detailed audit and proof-status distinctions |
| data/countermodel_rerun.json | Independent finite rerun of the inherited sorted interpretation |
| data/full_grammar_comparison.json | Equality-preserving compiler comparison; not a state record |
| data/full_grammar/ | Actual named partial TM, DAGs, finite correspondence certificate, provenance, and offline reproduction guide |
| SHA256SUMS | Checksums of packaged files other than this checksum file |

The guide at data/full_grammar/README.md gives an entirely offline
reproduction command for the compiler experiment. The audit and
code/COUNTERMODEL_ATTRIBUTION.md give the inherited countermodel command.
Run those assertion-based checks without Python's -O or -OO options.
Large upstream Lean/Coq
developments are cited rather than included.

## Reproduce the finite reference checks

Tested with Python 3.12. The principal checker uses the standard library
only. From this archive's root:

    python3 code/check_clausal_trace.py --output-dir /tmp/zfc-clausal-check
    python3 code/clausal_trace.py --prefix 1000
    python3 code/capture_tagged_check.py

Use any writable output directory in place of the example. The first
command emits results and example certificates for comparison with the
packaged data. The second is a bounded diagnostic: reaching its prefix
limit is an ordinary command completion, not a halting event of the
mathematical consistency-search machine.

The principal suite checks 159 generic first-order formulas in 2,862
finite structure/Skolem-expansion comparisons; all 20,854 sets of at most
four nontautological clauses over three propositional atoms, including
4,613 checked refutations; 15 rejected invalid traces; 200 actual PSC
matrices; 5,000 round trips each for the matrix, term, and certificate
codecs; and two explicit missing-specialization certificates.

Finite testing is not a proof of consistency or a substitute for the
report's unbounded correctness argument. The example refutation is for a
deliberately inconsistent generic theory, not for PSC. The PSC-facing
entry point reconstructs every axiom from its matrix and does not accept
arbitrary generic formulas.

The manual parser additionally accepts a truth token. The exhaustive
matrix codec uses bottom, relation, implication, and universal
quantification; truth is definable as bottom implies bottom.

## Compile the PDF

Install a normal TeX Live distribution with pdfLaTeX, latexmk, and the
packages named at the start of report.tex. Then run:

    make pdf

Without latexmk, run:

    pdflatex -interaction=nonstopmode -halt-on-error report.tex
    pdflatex -interaction=nonstopmode -halt-on-error report.tex
    pdflatex -interaction=nonstopmode -halt-on-error report.tex

The third pass resolves table-of-contents pagination when needed. No
external images or bibliography database are required.

## Exact scope of the claims

- PSC's equality-free equiconsistency and the original full-calculus
  finite-sort counterinterpretation are inherited results, credited in
  the report. They are not presented as discoveries of this investigation.
- The PA strengthening, generic hull argument, and Capture repair have
  ordinary mathematical proofs, not supplied proof-assistant derivations.
- The Python code is an executable reference with finite regressions and
  a mathematical contract. It is not a verified machine compiler.
- The nonhalting conclusion for a raw literal 248/250/252-state table is
  conditional on its simulation of the defeated abstract enumerator.
- The submitted 253-state upstream work remains the operational
  benchmark. Its theorem sources and successful public checking log
  were inspected; no new local Coq build was run.
- A 270-state named compiler output is a comparison using the larger
  public backend. A prior report already has 269. The named output's
  missing transition and remaining binary proof obligations are stated.
- No finite unsuccessful proof-search prefix is evidence for Con(ZFC).

## Provenance

The source manifest contains the pinned GitHub URLs and exact incoming
archive members. External mathematical sources are cited in the PDF.
Retain the supplied attribution files when reusing inherited code.
No GitHub repository was modified or published during this research.
