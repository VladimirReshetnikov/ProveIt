# One-parameter closure and smaller ZFC consistency machines

Research prepared for Vladimir Reshetnikov and the ProveIt project, **16 October 2026**.

Read **[report.pdf](report.pdf)** for the complete mathematical report. The complete LaTeX source is `report.tex` plus `sections/`. This archive includes the finite reference programs, positive proof certificates, literal public machine tables, new bounded search evidence, and pinned source excerpts used in the audit.

## Main outcome

**No new certified complete binary machine below 253 working states was found.** The 253-state public construction, including initialization, is an attributed prior result. The archive does not turn a prepared-tape 252-state runtime or the refuted reduced-calculus 248–252-state experiments into a new consistency machine.

The principal mathematical contribution is a direct raw-language reduction:

\[
\mathrm{EPSC}_1+\mathrm{AU}
\equiv_{\mathrm{ded}}
\mathrm{EPSC}_2
\equiv_{\mathrm{ded}}
\mathrm{EPSC}_{\mathrm{full}}.
\]

The language is classical, equality-free first-order membership logic over a nonempty domain, with genuine falsity. EPSC permits a supported positive closure of every locally subset-bounded relation, with all empty inputs initially active. EPSC_k permits at most k extra free matrix parameters; arbitrary bound variables and arbitrary negative matrices remain allowed.

The fixed short adjunction axiom is

\[
\mathrm{AU}:\quad
\forall a\,b\,\exists c\,\forall y\;
\left[y\in c\leftrightarrow
\left(y\in a\lor\forall z(y\in z\to b\in z)\right)\right].
\]

The new proof uses full incoming-and-outgoing membership-profile equivalence O. EPSC_1 supplies exact O-singletons, which make the short outgoing implication equivalent to O. A fixed two-parameter EPSC instance supplies O-pairing; Kuratowski coordinates are recoverable without Extensionality; fixed finite tuple formulas then pack arbitrary raw parameters. The report does **not** establish that EPSC_1 alone suffices.

A second result proves EPSC_k equivalent to the exact active-image fixed-point schema XFP_k for k >= 1, preserving the matrix parameter budget. The least object constructed in the proof is least among **represented** prefixed points, not automatically the external finite-reachability class of an arbitrary model.

The report reconstructs the inherited hereditary-saturation and set-theory calibration and proves the ordinary mathematical statement

\[
\mathrm{ZFC}\vdash
\operatorname{Con}(\mathrm{EPSC}_1+\mathrm{AU})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC}).
\]

These are ordinary mathematical proofs independently reviewed during preparation. The archive contains no serialized Lean/Rocq/PA/ZFC certificate for the complete new interpretation or a new literal machine.

## Concrete machine experiments

Both experiments operate on the **actual public 253-state table**, pinned below.

| Experiment | Scope | Result |
| --- | --- | --- |
| Local macro folds, radius 4 / 64 steps per side | 31,909 abstract configurations; 63,756 ordered state pairs | No certified merge |
| Local macro folds, radius 6 / 128 steps per side | 335,369 abstract configurations; 63,756 ordered state pairs | No certified merge |
| Mixed-row amalgamations | 49,952 construction choices; 886 protected-row rejections; 49,066 tested under the affine interface | No survivor |

Of the 49,066 affine failures, 44,836 exhausted fuel, 4,027 left the symbolic geometry handled by the executor, and 203 returned an unexpected terminal status. Fuel exhaustion and an unsupported symbolic shape are **not semantic refutations**. The results do not prove a state lower bound.

The complete finite boot was reproduced: 312,975 transitions, compact state 33, head -17, current symbol 0, and 178 one cells. This is finite-prefix evidence, not a general runtime theorem.

## Reproduce the evidence

Python 3.10+ with its standard library is sufficient. Run without `-O`; assertions enforce several input and interface checks. No network, Lean, or Rocq installation is needed for the finite scripts.

```sh
python3 tools/reproduce.py --quick
python3 tools/reproduce.py --full
python3 tools/reproduce.py --searches
```

- `--quick` checks source identities, the finite proof interfaces, both positive certificates, formula metrics, least-hull graph controls, a packing census through three objects, the public finite boot, and the stored mixed-row evidence.
- `--full` additionally uses every binary relation through four objects for packing.
- `--searches` additionally replays both macro searches and all mixed-row constructions in a disposable copied dependency tree. The original mixed run took approximately 102 seconds; host runtime varies.

New outputs and command logs are written beneath `reproduced/`. The original result files are preserved. The driver compares mathematical results, not elapsed times or incidental output paths. The detailed baseline-only commands and per-candidate normalization are in `research/baseline/REPRODUCING.md`.

The finite reference Python uses recursive syntax operations and can raise `RecursionError` on sufficiently deep finite input. It is a diagnostic implementation of an explicitly total mathematical primitive-recursive checker; it is **not** claimed to be a total infinite-search process as executed by the Python host. Such resource errors are never caught and reported as invalid proofs.

## Positive proof artifacts

`research/bridge/empty_object_certificate.bits` is a 20-node, 4,087-bit EPSC proof of an empty object. `empty_object_xfp_certificate.bits` is the corresponding 21-node, 5,404-bit XFP proof. They contain raw bits without a line terminator and are read using the matching theory preset.

The fixed-axiom choice and EPSC/XFP choice are part of the checker specification, external to the binary word. Descriptor bit zero means the selected fixed axiom. The default fixed axiom is AU; PairO is retained as a comparison preset. **Neither supplied positive certificate is a refutation.**

The files `finite_bridge.py`, `bridge_contract.json`, and `bridge_results.json` give the separate exact-library arithmetic endpoint. The upstream regularity-and-choice theorem already exists; the remaining uniform arithmetic witness transports are stated precisely. Those transports are not supplied as arithmetic proof certificates here.

## Build the report

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

Alternatively run `make pdf`. The packages are declared in the preamble and are conventional TeX Live packages. The delivered PDF has 40 physical pages, with a title page, two contents pages, and numbered main text. It was compiled with resolved references and no overfull/underfull boxes, then visually inspected. The bibliography uses pinned primary sources.

`SHA256SUMS` describes the delivered files and excludes itself. Rebuilding the PDF can change metadata and therefore its byte hash. The snapshot contains no TeX build debris or Python caches.

## Exact source pins

| Source | Commit |
| --- | --- |
| ProveIt research snapshot | `6ec2e80dbbe45a99b7812fb5757977307959a51e` |
| Accepted upstream 254-state reference | `297ab8df7e5de329605c3875b4934643b371a5e3` |
| Public PR20 253-state head | `0d544f2a2e3c18f12278441a74b7879f31cbe856` |

Public 253-state table SHA-256:

```text
84a21f714017c1d491008d86e9bd19c43cc6c5c9ae99a538b4f2314387827d95
```

The user-specified ProveIt commits `6d8bc7f1ba02c83e54757366f019f61b966ed0b7`, `63c83cf79986f8a92bb75460848a1d4f863b7b15`, and `0301aa64e0676bed17402a63de46996631252a51` were considered alongside subsequent work. The report explains which later developments change the comparison.

`provenance/proveit_sources.json` records verified Git blob identities for 34 pinned ProveIt source excerpts. `research/bridge/bridge_contract.json` records the twelve exact upstream sources used for the proof interface. The audit copies are not a complete repository or proof-assistant dependency closure. See `NOTICE.md` for attribution and license boundaries.

## Recommended next implementation

Compile plain EPSC_2 first, then compare EPSC_1+AU and XFP_1+AU in the same complete backend. One free parameter is mathematically sufficient with AU, but the expanded implication/falsity/universal tree metric is **53 nodes for EPSC_2 versus 85 for EPSC_1+AU**. Only a full binary compilation can determine whether the simpler parameter interface repays the fixed axiom's cost.

The final comparison must include complete logical substitution, genuine falsity, fair proof search, all runtime states, blank-tape initialization, and the internal ZFC endpoint. No formula-count-to-state-count subtraction is valid.
