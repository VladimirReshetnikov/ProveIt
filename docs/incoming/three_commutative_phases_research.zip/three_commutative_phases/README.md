# Three Commutative Phases Are Diophantine-Universal

Research manuscript prepared for Vladimir Reshetnikov, October 2, 2026.

## Main result

An explicit compiler sends every integral quadratic system to a product of
three free abelian subgroups of a finite Heisenberg power, with a bijection
between arithmetic solutions and ordered subgroup-element factorizations.
Classical MRDP then supplies three fixed subgroups with c.e.-complete
membership on a central affine cyclic line. This is presented as a proposed
resolution of the three-subgroup decidability problem stated in the cited
literature. The proof is in Sections 2–5; Appendix A is a compact independent
proof capsule.

Additional results: two-phase decidability, a natural-exponent monoid
version, explicit quartic reverse certificates, exact counting/weight
transfer, witness-height bounds, and an explicit non-profinite-closed
three-subgroup product in H x Z.

## Files

- article.pdf — 22-page article with complete proofs and source audit.
- article.tex — complete editable LaTeX source, with embedded bibliography.
- code/heisenberg_compiler.py — standard-library exact-integer compiler.
- code/verify.py — deterministic verification and example regeneration.
- examples/*_input.json — source quadratic specifications.
- examples/*.json (without _input) — full compiler data and generator lists.
- verification_receipt.json — exact test counts from the included run.
- build.sh — PDF build command.

## Reproduce

Python 3.10 or later is required. No third-party Python packages are needed.

    python code/verify.py
    python code/heisenberg_compiler.py \
      examples/multiplication_input.json multiplication_regenerated.json

The verification command regenerates the examples and receipt. It fails
immediately on a failed check. It does not invoke a theorem prover or solve
unbounded Diophantine problems.

To rebuild the article, install a LaTeX distribution containing the packages
listed in the preamble and run:

    sh build.sh

The Python API `circuit_system(n_inputs, gates, pins)` also flattens arithmetic
circuits. Its docstring gives the wire and target conventions. For natural
circuits, use nonnegative constants, addition, and multiplication; integer
circuits may also use subtraction. The quadratic compiler supports both
integer and natural exponent domains as specified in the article.

## Validation and limits

The supplied run passes 190,826 exact-integer assertions. Tests include
independent matrix multiplication and powers, signed parameters, all 50,625
small-box parameter tuples in a one-variable case, noncanonical witness
rejection, and modular certificates for moduli 1 through 2000.

These finite tests are not a proof of universality or undecidability. Full
mathematical proofs are provided, but the manuscript has not been
independently refereed or formalized in Lean. The universal fixed generator
lists are proved to exist from MRDP; no numerically expanded universal
polynomial or optimized universal dimension is supplied. The executable
compiler does fully instantiate any quadratic system given to it.

The source audit identified a published open question but does not certify
historical priority. Roman'kov's abstract and publication dates were checked
through his institutional publication record; his full journal paper was
not accessed. The relevant ProveIt core source was read at commit
433df1be37188224dd00d0561bfb157949cd6320, but no full repository build was run.

No repository files were changed. The package is a standalone research
artifact.
