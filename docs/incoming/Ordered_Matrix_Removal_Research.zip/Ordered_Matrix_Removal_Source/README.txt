A 5 x 5 Obstruction to Polynomial Ordered Matrix Removal
======================================================
Exact repair distance, copy packing, Poisson sampling,
and an inverse logarithmic barrier

Research draft prepared for the ProveIt project, 7 October 2026.
Prepared with ChatGPT; no human author or external peer review is implied.

MAIN RESULT
-----------
The article gives an explicit fixed 5 x 5 binary pattern H and matrices A_h
with m = 2^h, d = 20h + 2, n = d m, for which:

  Number of ordered H copies:             2 m^8
  Minimum original-copy cell transversal: m
  Maximum entry-disjoint H copies:        m
  Minimum binary changes to H-freeness:   m^2

The successful repair changes the entire dummy-row by leaf-column rectangle
from ones to zeros. Its freeness is proved separately, so the argument does
not confuse hitting the original copies with preventing new copies.

Additional theorems give exact finite sampling identities, the balanced
Poisson threshold, an optimal entry budget for one uniform rectangle,
an exact Lambert W inverse and convergent logarithmic expansion with an
explicit remainder, and a regular-tree generalization. Nine research
questions and a staged formalization plan are included.

FILES
-----
  ordered_matrix_removal.pdf          Complete article
  ordered_matrix_removal.tex          Main LaTeX source
  sections/*.tex                      All mathematical sections
  references.bib                     Versioned primary-source bibliography
  ordered_matrix_removal.bbl          Prebuilt bibliography
  figures/*.pdf                       Vector figures used by the article
  figures/*.png                       Figure previews
  figures/sampling_figure_data.json    Numerical figure/optimization receipt
  code/verify.py                      Exact finite combinatorial checks
  code/verification_results.json       Results of the default exact checks
  code/verify_inversion.py             Symbolic and high-precision checks
  code/inversion_results.json          Inversion-check receipt
  code/generate_figures.py             Reproduce figures and their data
  requirements-optional.txt           Versions used for optional scripts
  Makefile                           Build and verification commands
  PROVENANCE.json                     Source snapshots and proof scope
  NOTICE.txt                         Attribution and modification record
  OPENAI_APACHE_LICENSE.txt           Source repository's license text
  SHA256SUMS.txt                      Checksums of archive contents

BUILD THE PDF
-------------
All figure assets and bibliography sources are included. No network access
or optional Python packages are needed to rebuild the article.

From this directory, with a standard TeX Live installation and latexmk:

  make pdf

or:

  latexmk -pdf -interaction=nonstopmode -halt-on-error ordered_matrix_removal.tex

Without latexmk:

  pdflatex -interaction=nonstopmode -halt-on-error ordered_matrix_removal.tex
  bibtex ordered_matrix_removal
  pdflatex -interaction=nonstopmode -halt-on-error ordered_matrix_removal.tex
  pdflatex -interaction=nonstopmode -halt-on-error ordered_matrix_removal.tex

The source uses the article class, Latin Modern fonts, AMS mathematics,
geometry, microtype, booktabs, enumitem, graphicx, xcolor, fancyhdr,
needspace, hyperref, and cleveref. The supplied build was made with
pdfTeX from TeX Live 2023/Debian and latexmk 4.83.

RUN EXACT FINITE CHECKS
----------------------
Python 3.10 or later is recommended; the supplied receipt used Python 3.12.14.
The main verifier needs only the standard library:

  make verify

or:

  python3 code/verify.py

It writes code/verification_results.json. The output path is resolved
relative to the script, so it also works from another current directory.
See python3 code/verify.py --help for the optional larger and legacy checks.
The default is the full 5 x 5 pattern with three anchor groups. Explicit
exception checks remain active under python3 -O; both modes were verified
to produce the same receipt.

Default scope:
  * Full-copy exhaustive searches at depths h = 1 and 2, original/repaired.
  * Structural checks and designated-body counts through depth 6.
  * Explicit disjoint expanded copies and the four-by-four counterexample.
  * Small exact Bernoulli witness computations with anchor events integrated.
  * 58 exhaustive fixed-size factorial-moment comparisons on witness submodels.

The finite checks supplement the proofs. They do not enumerate all edit
sets, prove the general edit lower bound by computation, or provide a Lean
formalization of the new theorems. Weighted compressed counts are exact
because H has pairwise distinct rows and pairwise distinct columns.

OPTIONAL SYMBOLIC, NUMERICAL, AND FIGURE CHECKS
--------------------------------------------
For all optional scripts, install the versions used in this package:

  python3 -m pip install -r requirements-optional.txt
  make inversion
  make figures

The inversion script requires mpmath. SymPy adds an independent exact
formal-equation check of the first four coefficient polynomials; the
Makefile requires that symbolic check. The supplied numerical receipt uses
120 decimal digits. Numerical evaluations at finitely many parameters
do not prove the all-parameter remainder bound; its analytic proof is in
the article.

Figure generation requires NumPy, SciPy, and Matplotlib. Bernoulli curves
evaluate exact analytic formulas using stable log1p/expm1 expressions.
Rectangular optimizer locations are numerical approximations, not certified
intervals; uniqueness of the optimizer is not claimed. The asymptotic
variational theorem is proved without reliance on numerical optimization.

PROVENANCE AND INTEGRATION
--------------------------
The construction develops Family 190 in openai/math, at commit
adc7f1241b42e322a6451854ab7e4b4c146bf78a. Its manuscript uses a 66 x 66
pattern. We retain its signed tree, role table, nonanchor threshold entries,
and protected-path distance argument with explicit attribution. We change
the anchor and prove the additional statements listed in the article.

The Lambert inversion is an application of ProveIt's existing theorem
p0:thm:lambert-core and its positive-parameter Lean counterpart, read at
commit fb9602e556560a15704b4feb176ba6de08378665. General Lambert inversion
is not claimed as new. Neither upstream Lean project was rebuilt here.

The source review, precise contribution boundary, and formalization plan
are in Section 13 and PROVENANCE.json. This is a research draft with
complete written proofs and supplementary verification; the new theorems
have not been formally verified in Lean or independently peer reviewed.

A possible integration location is:
  Combinatorics/OrderedMatrixRemoval/Research/
The package is self-contained and does not require changing an existing
ProveIt import surface. Its formalization can be added in separate modules
following the dependency order in the article. The repository itself has
not been modified by this package.

The five-by-five pattern is not asserted globally minimal. The rectangular
testing optimum is for one independently uniform sampled rectangle with
fixed sample sizes; it is not an unrestricted adaptive-query lower bound.
The inverse logarithmic barrier is a necessary lower bound on universal
repair conversions, not a proved matching upper bound.
