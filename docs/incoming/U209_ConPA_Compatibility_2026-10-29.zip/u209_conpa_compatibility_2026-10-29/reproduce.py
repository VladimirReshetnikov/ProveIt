#!/usr/bin/env python3
"""Offline reconstruction, independent finite checks, and universal replay.

Default: all finite checks and all 5,084 U209 symbolic contracts.
--both: also freshly rederive the U210 contracts.
--quick: explicitly skip new universal runtime derivations.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'code'))
import build
import check_u210
import check_u209
import check_startup
import compare
import replay_runtime

def need(ok, message):
    if not ok:
        raise ValueError(message)

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def manifest():
    data = json.loads((ROOT / 'MANIFEST.json').read_text())
    for name, entry in data['files'].items():
        path = (ROOT / name).resolve()
        need(path.is_relative_to(ROOT) and path.is_file(), 'Manifest path: ' + name)
        raw = path.read_bytes()
        need(len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'],
             'Manifest mismatch: ' + name)
    return len(data['files'])

def finite():
    out = ROOT / 'build'
    result = build.build(out)
    for number in (210, 209):
        stem = f'u{number}'
        for ext in ('.native.tm', '.tm', '.state_map.json'):
            need((out / (stem + ext)).read_bytes() == (ROOT / 'machine' / (stem + ext)).read_bytes(),
                 'Rebuilt machine differs: ' + stem + ext)
        need((out / (stem + '.sites.json')).read_bytes() ==
             (ROOT / 'source' / (stem + '.sites.json')).read_bytes(), 'Rebuilt source differs')
    for name in ('u210_prefold211.native.tm', 'u209_prefold210.native.tm'):
        need((out / name).read_bytes() == (ROOT / 'intermediates' / name).read_bytes(),
             'Prefold snapshot differs: ' + name)
    comparison = compare.compare()
    write(out / 'comparison.json', comparison)
    input_parent = ROOT / 'comparison/Research'
    inputs = {
        210: [input_parent / 'u211.native.tm', input_parent / 'sites.json',
              ROOT / 'intermediates/u210_prefold211.native.tm', ROOT / 'machine/u210.native.tm',
              ROOT / 'source/u210.sites.json', ROOT / 'machine/u210.tm'],
        209: [ROOT / 'machine/u210.native.tm', ROOT / 'source/u210.sites.json',
              ROOT / 'intermediates/u209_prefold210.native.tm', ROOT / 'machine/u209.native.tm',
              ROOT / 'source/u209.sites.json', ROOT / 'machine/u209.tm'],
    }
    audits, startups = {}, {}
    for number, module in ((210, check_u210), (209, check_u209)):
        audit = module.audit(*inputs[number])
        audit['input_sha256'] = {name: hashlib.sha256(path.read_bytes()).hexdigest()
                                for name, path in zip(('parent_table', 'parent_source', 'prefold',
                                                      'candidate', 'source', 'dense'), inputs[number])}
        sealed = json.loads((ROOT / f'evidence/u{number}_independent_check.json').read_text())
        need(json.loads(json.dumps(audit)) == sealed, 'Independent evidence differs')
        write(out / f'u{number}_independent_check.json', audit)
        startup = check_startup.check(input_parent / 'u211.native.tm',
                                       ROOT / f'machine/u{number}.native.tm',
                                       ROOT / f'source/u{number}.sites.json')
        write(out / f'u{number}_startup.json', startup)
        audits[number], startups[number] = audit['status'], startup['status']
    # Reused induction engine is byte-bound to the unmodified input archive.
    provenance = json.loads((ROOT / 'code/runtime/PROVENANCE.json').read_text())
    for name, digest in provenance['files'].items():
        need(hashlib.sha256((ROOT / 'code/runtime' / name).read_bytes()).hexdigest() == digest,
             'Inherited runtime file changed: ' + name)
    # Validate the sealed cases as records; this is not a fresh universal replay.
    saved = {}
    for number in (209, 210):
        with gzip.open(ROOT / f'evidence/u{number}_runtime_cases.json.gz', 'rb') as stream:
            case_file = out / f'u{number}_saved_cases.json'
            case_file.write_bytes(stream.read())
        saved[number] = replay_runtime.summarize(number, ROOT / f'evidence/u{number}_runtime.json',
                                                  case_file, compare=False)
        case_file.unlink()
    return {'construction': result['status'], 'comparison': comparison['status'],
            'independent_audits': audits, 'startups': startups, 'saved_runtime_records': saved}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--quick', action='store_true', help='skip fresh universal runtime replay')
    parser.add_argument('--both', action='store_true', help='freshly replay U210 as well as U209')
    args = parser.parse_args()
    need(not (args.quick and args.both), 'Choose --quick or --both')
    if not args.quick:
        need(__debug__ and not sys.flags.optimize, 'Universal replay requires enabled assertions')
    began = time.monotonic()
    files = manifest()
    finite_result = finite()
    runtime = []
    if not args.quick:
        for number in ((209, 210) if args.both else (209,)):
            runtime.append(replay_runtime.run(number))
    result = {'status': 'FINITE_REPLAY_PASS_RUNTIME_SKIPPED' if args.quick else 'FULL_REPLAY_PASS',
              'manifest_files_checked': files, 'finite_checks': finite_result,
              'fresh_runtime': runtime, 'seconds': round(time.monotonic() - began, 3),
              'scope': 'Executable mathematical evidence, with inherited U/PA calibration. '
                       'No new proof-assistant endpoint certificate.'}
    write(ROOT / 'build/replay.json', result)
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
