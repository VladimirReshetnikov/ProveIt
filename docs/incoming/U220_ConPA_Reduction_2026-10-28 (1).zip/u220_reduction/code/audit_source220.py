#!/usr/bin/env python3
"""Independent audit of the exchanged, upper-first U220 source.

No imports from any source builder or inherited source checker. This resolves
counter-program edges by binary-searching lexicographic prefix intervals.
The logical proof is given in paper/u220_shell_proof.tex; truth tables below
check the two purely propositional exchange identities, not consistency.
"""
import argparse
import bisect
import hashlib
import itertools
import json
from pathlib import Path

TOKENS = ["n", 1, 1, "n", "R", "n", "I", "Q", 1, "n", "n", "n", 1,
          "R", "n", 0, "R", "I", "Q", 1, "n", "R", "I", "I", "Q",
          "N", "I", "Q"]
MACROS = {0: 171, 1: 177, "n": 168, "I": 119, "R": 181, "Q": 180, "N": 218}
LO, HI = 2885, 3622


def require(test, message):
    if not test:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source(path):
    rows = json.loads(path.read_text())
    addresses = [row[0] for row in rows]
    require(addresses == sorted(set(addresses)), "Addresses are not uniquely ordered")
    primitives = {p: (op, arg) for p, op, arg in rows}
    prefixes = {p[:j] for p in addresses for j in range(len(p))}
    require(not prefixes.intersection(primitives), "A leaf is a strict ancestor")
    require(all(p+b in prefixes or p+b in primitives for p in prefixes for b in "01"),
            "Incomplete binary source tree")
    nodes = set()

    def tree(p):
        if p in primitives:
            node = primitives[p]
        else:
            node = (tree(p+"0"), tree(p+"1"))
        nodes.add(node)
        return node

    tree("")

    def jump(p, wanted, count):
        positions = [i for i, b in enumerate(p) if b == wanted]
        require(0 < count <= len(positions), "An instruction escapes the source root")
        ancestor = p[:positions[-count]]
        return bisect.bisect_left(addresses, ancestor if wanted == "1" else ancestor+"2")

    graph = []
    for i, (p, op, arg) in enumerate(rows):
        if op == "CI":
            edges = (i+1,)
        elif op == "CD":
            edges = (jump(p, "0", 1), i+1)
        elif op == "CB":
            edges = (jump(p, "0", arg),)
        elif op == "CC":
            edges = (jump(p, "1", arg),)
        elif op == "CH":
            edges = ()
        else:
            raise ValueError("Unknown primitive")
        graph.append((op, arg, edges))
    metrics = {"leaf_occurrences": len(rows), "dag_nodes": len(nodes),
               "maximum_depth": max(map(len, addresses)),
               "maximum_zero_run": max(len(z) for p in addresses for z in p.split("1"))}
    return rows, graph, metrics


def postfix(tokens):
    stack = []
    current = "old-current"
    for token in tokens:
        if token in (0, 1, "n"):
            stack.append(current)
            current = token
        elif token == "N":
            current = ("I", current, 1)
        else:
            require(token in ("I", "R", "Q") and stack, "Invalid postfix expression")
            current = (token, stack.pop(), current)
    require(stack == ["old-current"], "Emitter has the wrong stack effect")
    return current


def expected_formula():
    guard = ("Q", "n", ("I", ("R", "n", 1), ("R", "n", 0)))
    lower = ("Q", 1, ("I", "n", ("I", guard, ("R", 1, "n"))))
    upper = ("Q", 1, ("I", ("R", 1, "n"), "n"))
    return ("Q", "n", ("I", upper, ("I", lower, 1)))


def verify(original, proposed):
    old_rows, old_graph, old_metrics = source(original / "machine/sites.json")
    new_rows, new_graph, new_metrics = source(proposed / "sites.json")
    require(len(old_rows) == len(new_rows) == 3891, "Unexpected source size")
    for i, old in enumerate(old_graph):
        if LO <= i < HI:
            continue
        require(old == new_graph[i], f"Retained CFG differs at {i}")
        require(all(not LO < edge < HI for edge in old[2]),
                "Retained instruction enters replacement interior")
    for op, arg, edges in new_graph[LO:HI]:
        require(op != "CH" and all(LO <= target <= HI for target in edges),
                "Replacement is not a closed nonhalting macro")

    _, kgraph, _ = source(original / "inputs/k215_sites.json")
    recipe = json.loads((original / "inputs/source_recipe.json").read_text())
    ranges = recipe["macro_intervals"]
    expanded = []
    for token in TOKENS:
        begin, end = ranges[str(MACROS[token])]
        offset = LO + len(expanded)
        for op, arg, edges in kgraph[begin:end]:
            require(all(begin <= edge <= end for edge in edges), "Inherited macro is open")
            expanded.append((op, arg, tuple(offset+edge-begin for edge in edges)))
    require(len(expanded) == 737, "Wrong primitive expansion size")
    require(expanded == new_graph[LO:HI], "Actual replacement does not bind to the formula")
    require(postfix(TOKENS) == expected_formula(), "The emitter has a different formula tree")

    imply = lambda a, b: (not a) or b
    truth_cases = []
    for a, b, c in itertools.product((False, True), repeat=3):
        left = imply(a, imply(b, c))
        right = imply(b, imply(a, c))
        require(left == right, "Exchange identity is false")
        truth_cases.append([a, b, c, left])

    # Two mutation controls bind the audit to instructions and control flow.
    corrupted = list(expanded)
    op, arg, edges = corrupted[0]
    corrupted[0] = (op, (arg+1) % 9, edges)
    require(corrupted != new_graph[LO:HI], "Instruction corruption went undetected")
    corrupted = list(expanded)
    for i, (op, arg, edges) in enumerate(corrupted):
        if edges:
            corrupted[i] = (op, arg, (edges[0]+1,) + edges[1:])
            break
    require(corrupted != new_graph[LO:HI], "Control-edge corruption went undetected")
    return {
        "status": "INDEPENDENT_SOURCE_CFG_AND_FORMULA_BINDING_PASS",
        "old_source_sha256": sha(original / "machine/sites.json"),
        "new_source_sha256": sha(proposed / "sites.json"),
        "old_metrics": old_metrics,
        "new_metrics": new_metrics,
        "retained_instructions_and_resolved_edges": len(new_rows)-(HI-LO),
        "replacement_interval": [LO, HI],
        "closed_replacement": True,
        "independently_bound_replacement_instructions": len(expanded),
        "macro_word": TOKENS,
        "formula_tree": expected_formula(),
        "exchange_truth_cases": truth_cases,
        "logical_fact": "A -> (B -> C) iff B -> (A -> C), including arbitrary truth value for C",
        "scope": "Exact finite source identities plus ordinary uniform logical proof; no literal runtime acceptance",
    }


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("original_package", type=Path)
    ap.add_argument("proposed_source_directory", type=Path)
    ap.add_argument("output", type=Path)
    args = ap.parse_args()
    result = verify(args.original_package, args.proposed_source_directory)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ("formula_tree", "macro_word", "exchange_truth_cases")}, indent=2))
