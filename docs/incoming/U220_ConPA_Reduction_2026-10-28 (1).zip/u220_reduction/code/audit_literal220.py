#!/usr/bin/env python3
"""Independent local-quotient and blank-start audit for a U220 allocation.

The source/runtime calibration is a separate obligation. This script imports
neither the allocator nor the original symbolic interpreter.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def require(test, message):
    if not test:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def table(path):
    rows = path.read_text().splitlines()
    require(rows[0] == "#! start 0", "Wrong start declaration")
    result = {}
    for line in rows[1:]:
        if not line or line.startswith("#"):
            continue
        q, b, w, d, z = line.split()
        q, b, w, z = map(int, (q, b, w, z))
        require(b in (0, 1) and w in (0, 1) and d in ("L", "R"), "Malformed row")
        require((q, b) not in result, "Duplicate row")
        result[q, b] = (w, -1 if d == "L" else 1, z)
    states = {q for q, b in result}
    require(0 in states and 254 not in states, "Wrong start/halt convention")
    require(set(result) == {(q, b) for q in states for b in (0, 1)}, "Incomplete table")
    require({z for w, d, z in result.values()} <= states | {254}, "Unknown target")
    reach = {0}
    queue = [0]
    for q in queue:
        for b in (0, 1):
            z = result[q, b][2]
            if z != 254 and z not in reach:
                reach.add(z)
                queue.append(z)
    require(reach == states, "Graph-unreachable state")
    return result


def advance(t, conf):
    q, head, ones = conf
    b = int(head in ones)
    w, d, z = t[q, b]
    if w:
        ones.add(head)
    else:
        ones.discard(head)
    return z, head+d, ones


def project(q):
    return 112 if q == 200 else q


def verify_local(pre, post):
    incoming = lambda q: sorted([a, b] for (a, b), v in pre.items() if v[2] == q)
    require(incoming(112) == [[172, 0]], "Unexpected entry to state112")
    require(incoming(200) == [[112, 1]], "Unexpected entry to state200")
    require(pre[172, 0] == (0, -1, 112), "Wrong marker-writing predecessor")
    require(pre[112, 1] == (1, 1, 200), "Wrong return to marked cell")
    require(pre[112, 0] == pre[200, 0] == (0, 1, 157), "Unequal live rows")
    require(set(post) == {k for k in pre if k[0] != 200}, "Unexpected deleted rows")
    checked = 0
    for (q, b), (w, d, z) in pre.items():
        if (q, b) == (200, 1):
            continue
        require(post[project(q), b] == (w, d, project(z)), "Noncommuting quotient row")
        checked += 1
    return checked


def frame(pc, logical, spares=(0,), gap=0):
    physical = [None] * 9
    for i, j in enumerate((6, 2, 0, 4, 3, 7, 8, 5, 1)):
        physical[j] = logical[i]
    ones = {-1, 64+gap} | {i for i, b in enumerate(pc) if b == "1"}
    p = 65+gap
    for n in physical+list(spares):
        p += 1
        ones.update(range(p, p+n+1))
        p += n+1
    return ones


def boundary(conf):
    q, h, ones = conf
    if q != 84 or not ones or min(ones) != h-1:
        return False
    right = [x for x in ones if x >= h+52]
    if not right or min(right) < h+64:
        return False
    p, end, blocks = min(right)+1, max(ones), 0
    while p <= end:
        if p in ones or p+1 not in ones:
            return False
        p += 1
        while p in ones:
            p += 1
        blocks += 1
    return blocks >= 10


def marker_regression(t, site):
    pc, op, arg = site
    require((op, arg) == ("CI", 1), "Wrong targeted regression site")
    bits = len(pc)
    value = int(pc, 2)+1
    carry = int(value == 2**bits)
    nxt = format(value % 2**bits, f"0{bits}b")
    expected_registers = [0] * 9
    expected_registers[1] = 1
    expected = (84, -carry,
                {p-carry for p in frame(nxt, expected_registers, (0, 1), carry)})
    actual = (84, 0, frame(pc, [0] * 9))
    for tick in range(1, 100001):
        actual = advance(t, actual)
        if boundary(actual) or actual[0] == 254:
            return {"passed": actual == expected, "steps": tick,
                    "actual": [actual[0], actual[1], sorted(actual[2])],
                    "expected": [expected[0], expected[1], sorted(expected[2])]}
    raise ValueError("Targeted regression failed to redispatch within its finite bound")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("original_package", type=Path)
    ap.add_argument("allocation_directory", type=Path)
    ap.add_argument("source_sites", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--rejected-table", type=Path)
    args = ap.parse_args()
    old_path = args.original_package / "machine/u.native.tm"
    pre_path = args.allocation_directory / "candidate.native.tm"
    post_path = args.allocation_directory / "candidate220.native.tm"
    paths = [old_path, pre_path, post_path]
    tables = list(map(table, paths))
    require([len(t)//2 for t in tables] == [222, 221, 220], "Wrong working-state counts")
    equations = verify_local(tables[1], tables[2])
    states = [(0, 0, set()) for _ in tables]
    different_labels = Counter()
    for tick in range(95714):
        original, before, after = states
        require(original[1:] == before[1:] == after[1:], "Startup tapes/heads diverge")
        require(after[0] == project(before[0]), "Startup quotient control diverges")
        if original[0] != before[0]:
            different_labels[original[0], before[0]] += 1
        q, h, tape = before
        require(q != 112 or h+1 not in tape, "Local neighbor invariant fails")
        require(q != 200 or h not in tape, "Local scanned-bit invariant fails")
        states = [advance(t, c) for t, c in zip(tables, states)]
    require(states[0] == states[1] == states[2], "Final startup frames differ")
    q, h, ones = states[0]
    inherited = json.loads((args.original_package / "evidence/startup.json").read_text())
    require((q, h, sorted(ones)) ==
            (inherited["state"], inherited["head"], inherited["one_cells"]),
            "Independent startup differs from the supplied complete frame")
    sites = json.loads(args.source_sites.read_text())
    fixed = marker_regression(tables[2], sites[3435])
    require(fixed["passed"], "The corrected table still fails marker regression")
    rejected = None
    if args.rejected_table:
        rejected = marker_regression(table(args.rejected_table), sites[3435])
        require(not rejected["passed"], "The claimed rejection does not reproduce")
    result = {
        "status": "INDEPENDENT_STARTUP_LOCAL_QUOTIENT_AND_MARKER_REGRESSION_PASS",
        "tables": [{"path": str(p), "sha256": digest(p), "working_states": len(t)//2}
                   for p, t in zip(paths, tables)],
        "source_sha256": digest(args.source_sites),
        "quotient_live_equations": equations,
        "startup_steps": 95714,
        "startup_tapes_and_heads_equal_at_every_step": True,
        "startup_control_reallocation":
            [[a, b, n] for (a, b), n in sorted(different_labels.items())],
        "final_frame": {"state": q, "head": h, "one_cells": sorted(ones)},
        "marker_regression_site": 3435,
        "corrected_marker_regression": fixed,
        "rejected_marker_regression": rejected,
        "scope": "Finite literal startup/regression and hypotheses of a general quotient theorem; source calibration and complete universal runtime remain separate obligations",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ("final_frame", "corrected_marker_regression",
                                   "rejected_marker_regression")}, indent=2))


if __name__ == "__main__":
    main()
