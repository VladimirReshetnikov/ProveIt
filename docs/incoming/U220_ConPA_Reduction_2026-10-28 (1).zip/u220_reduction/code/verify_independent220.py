#!/usr/bin/env python3
"""Standalone independent source, table, startup, and regression audit for U220.

Requires Python's standard library only. No imports from the source generator,
allocator, symbolic checker, or any other release script. The complete universal
runtime proof remains a separate executable check; optional receipt validation
here checks its coverage and input identities without rerunning that proof.
"""
import argparse
import bisect
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path

TOKENS = ["n", 1, 1, "n", "R", "n", "I", "Q", 1, "n", "n", "n", 1,
          "R", "n", 0, "R", "I", "Q", 1, "n", "R", "I", "I", "Q",
          "N", "I", "Q"]
MACROS = {0: 171, 1: 177, "n": 168, "I": 119, "R": 181, "Q": 180, "N": 218}
LO, HI = 2885, 3622


def require(test, message):
    if not test:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source(path):
    rows = json.loads(path.read_text())
    addresses = [row[0] for row in rows]
    require(addresses == sorted(set(addresses)), "Addresses are not uniquely ordered")
    primitives = {p: (op, arg) for p, op, arg in rows}
    prefixes = {p[:j] for p in addresses for j in range(len(p))}
    require(not prefixes.intersection(primitives), "A leaf is a strict ancestor")
    require(all(p+b in prefixes or p+b in primitives for p in prefixes for b in "01"),
            "Incomplete binary source tree")
    nodes = set()

    def tree(p):
        if p in primitives:
            node = primitives[p]
        else:
            node = (tree(p+"0"), tree(p+"1"))
        nodes.add(node)
        return node

    tree("")

    def jump(p, wanted, count):
        positions = [i for i, b in enumerate(p) if b == wanted]
        require(0 < count <= len(positions), "An instruction escapes the source root")
        ancestor = p[:positions[-count]]
        return bisect.bisect_left(addresses, ancestor if wanted == "1" else ancestor+"2")

    graph = []
    for i, (p, op, arg) in enumerate(rows):
        if op == "CI":
            edges = (i+1,)
        elif op == "CD":
            edges = (jump(p, "0", 1), i+1)
        elif op == "CB":
            edges = (jump(p, "0", arg),)
        elif op == "CC":
            edges = (jump(p, "1", arg),)
        elif op == "CH":
            edges = ()
        else:
            raise ValueError("Unknown primitive")
        graph.append((op, arg, edges))
    metrics = {"leaf_occurrences": len(rows), "dag_nodes": len(nodes),
               "maximum_depth": max(map(len, addresses)),
               "maximum_zero_run": max(len(z) for p in addresses for z in p.split("1"))}
    return rows, graph, metrics


def postfix(tokens):
    stack = []
    current = "old-current"
    for token in tokens:
        if token in (0, 1, "n"):
            stack.append(current)
            current = token
        elif token == "N":
            current = ("I", current, 1)
        else:
            require(token in ("I", "R", "Q") and stack, "Invalid postfix expression")
            current = (token, stack.pop(), current)
    require(stack == ["old-current"], "Emitter has the wrong stack effect")
    return current


def expected_formula():
    guard = ("Q", "n", ("I", ("R", "n", 1), ("R", "n", 0)))
    lower = ("Q", 1, ("I", "n", ("I", guard, ("R", 1, "n"))))
    upper = ("Q", 1, ("I", ("R", 1, "n"), "n"))
    return ("Q", "n", ("I", upper, ("I", lower, 1)))


def verify(original, proposed):
    old_rows, old_graph, old_metrics = source(original / "machine/sites.json")
    new_rows, new_graph, new_metrics = source(proposed / "sites.json")
    require(len(old_rows) == len(new_rows) == 3891, "Unexpected source size")
    for i, old in enumerate(old_graph):
        if LO <= i < HI:
            continue
        require(old == new_graph[i], f"Retained CFG differs at {i}")
        require(all(not LO < edge < HI for edge in old[2]),
                "Retained instruction enters replacement interior")
    for op, arg, edges in new_graph[LO:HI]:
        require(op != "CH" and all(LO <= target <= HI for target in edges),
                "Replacement is not a closed nonhalting macro")

    _, kgraph, _ = source(original / "inputs/k215_sites.json")
    recipe = json.loads((original / "inputs/source_recipe.json").read_text())
    ranges = recipe["macro_intervals"]
    expanded = []
    for token in TOKENS:
        begin, end = ranges[str(MACROS[token])]
        offset = LO + len(expanded)
        for op, arg, edges in kgraph[begin:end]:
            require(all(begin <= edge <= end for edge in edges), "Inherited macro is open")
            expanded.append((op, arg, tuple(offset+edge-begin for edge in edges)))
    require(len(expanded) == 737, "Wrong primitive expansion size")
    require(expanded == new_graph[LO:HI], "Actual replacement does not bind to the formula")
    require(postfix(TOKENS) == expected_formula(), "The emitter has a different formula tree")

    imply = lambda a, b: (not a) or b
    truth_cases = []
    for a, b, c in itertools.product((False, True), repeat=3):
        left = imply(a, imply(b, c))
        right = imply(b, imply(a, c))
        require(left == right, "Exchange identity is false")
        truth_cases.append([a, b, c, left])

    # Two mutation controls bind the audit to instructions and control flow.
    corrupted = list(expanded)
    op, arg, edges = corrupted[0]
    corrupted[0] = (op, (arg+1) % 9, edges)
    require(corrupted != new_graph[LO:HI], "Instruction corruption went undetected")
    corrupted = list(expanded)
    for i, (op, arg, edges) in enumerate(corrupted):
        if edges:
            corrupted[i] = (op, arg, (edges[0]+1,) + edges[1:])
            break
    require(corrupted != new_graph[LO:HI], "Control-edge corruption went undetected")
    return {
        "status": "INDEPENDENT_SOURCE_CFG_AND_FORMULA_BINDING_PASS",
        "old_source_sha256": sha(original / "machine/sites.json"),
        "new_source_sha256": sha(proposed / "sites.json"),
        "old_metrics": old_metrics,
        "new_metrics": new_metrics,
        "retained_instructions_and_resolved_edges": len(new_rows)-(HI-LO),
        "replacement_interval": [LO, HI],
        "closed_replacement": True,
        "independently_bound_replacement_instructions": len(expanded),
        "macro_word": TOKENS,
        "formula_tree": expected_formula(),
        "exchange_truth_cases": truth_cases,
        "logical_fact": "A -> (B -> C) iff B -> (A -> C), including arbitrary truth value for C",
        "scope": "Exact finite source identities plus ordinary uniform logical proof; no literal runtime acceptance",
    }




def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def table(path, halt=254):
    rows = path.read_text().splitlines()
    require(rows[0] == "#! start 0", "Wrong start declaration")
    result = {}
    for line in rows[1:]:
        if not line or line.startswith("#"):
            continue
        q, b, w, d, z = line.split()
        q, b, w, z = map(int, (q, b, w, z))
        require(b in (0, 1) and w in (0, 1) and d in ("L", "R"), "Malformed row")
        require((q, b) not in result, "Duplicate row")
        result[q, b] = (w, -1 if d == "L" else 1, z)
    states = {q for q, b in result}
    require(0 in states and halt not in states, "Wrong start/halt convention")
    require(set(result) == {(q, b) for q in states for b in (0, 1)}, "Incomplete table")
    require({z for w, d, z in result.values()} <= states | {halt}, "Unknown target")
    reach = {0}
    queue = [0]
    for q in queue:
        for b in (0, 1):
            z = result[q, b][2]
            if z != halt and z not in reach:
                reach.add(z)
                queue.append(z)
    require(reach == states, "Graph-unreachable state")
    return result


def advance(t, conf):
    q, head, ones = conf
    b = int(head in ones)
    w, d, z = t[q, b]
    if w:
        ones.add(head)
    else:
        ones.discard(head)
    return z, head+d, ones


def project(q):
    return 112 if q == 200 else q


def verify_local(pre, post):
    incoming = lambda q: sorted([a, b] for (a, b), v in pre.items() if v[2] == q)
    require(incoming(112) == [[172, 0]], "Unexpected entry to state112")
    require(incoming(200) == [[112, 1]], "Unexpected entry to state200")
    require(pre[172, 0] == (0, -1, 112), "Wrong marker-writing predecessor")
    require(pre[112, 1] == (1, 1, 200), "Wrong return to marked cell")
    require(pre[112, 0] == pre[200, 0] == (0, 1, 157), "Unequal live rows")
    require(set(post) == {k for k in pre if k[0] != 200}, "Unexpected deleted rows")
    checked = 0
    for (q, b), (w, d, z) in pre.items():
        if (q, b) == (200, 1):
            continue
        require(post[project(q), b] == (w, d, project(z)), "Noncommuting quotient row")
        checked += 1
    return checked


def frame(pc, logical, spares=(0,), gap=0):
    physical = [None] * 9
    for i, j in enumerate((6, 2, 0, 4, 3, 7, 8, 5, 1)):
        physical[j] = logical[i]
    ones = {-1, 64+gap} | {i for i, b in enumerate(pc) if b == "1"}
    p = 65+gap
    for n in physical+list(spares):
        p += 1
        ones.update(range(p, p+n+1))
        p += n+1
    return ones


def boundary(conf):
    q, h, ones = conf
    if q != 84 or not ones or min(ones) != h-1:
        return False
    right = [x for x in ones if x >= h+52]
    if not right or min(right) < h+64:
        return False
    p, end, blocks = min(right)+1, max(ones), 0
    while p <= end:
        if p in ones or p+1 not in ones:
            return False
        p += 1
        while p in ones:
            p += 1
        blocks += 1
    return blocks >= 10


def marker_regression(t, site):
    pc, op, arg = site
    require((op, arg) == ("CI", 1), "Wrong targeted regression site")
    bits = len(pc)
    value = int(pc, 2)+1
    carry = int(value == 2**bits)
    nxt = format(value % 2**bits, f"0{bits}b")
    expected_registers = [0] * 9
    expected_registers[1] = 1
    expected = (84, -carry,
                {p-carry for p in frame(nxt, expected_registers, (0, 1), carry)})
    actual = (84, 0, frame(pc, [0] * 9))
    for tick in range(1, 100001):
        actual = advance(t, actual)
        if boundary(actual) or actual[0] == 254:
            return {"passed": actual == expected, "steps": tick,
                    "actual": [actual[0], actual[1], sorted(actual[2])],
                    "expected": [expected[0], expected[1], sorted(expected[2])]}
    raise ValueError("Targeted regression failed to redispatch within its finite bound")


def encode(t):
    return ("#! start 0\n" + "".join(
        f'{q} {b} {w} {"R" if d == 1 else "L"} {z}\n'
        for (q, b), (w, d, z) in sorted(t.items()))).encode("ascii")


def check_runtime_receipt(directory, sites, native_digest, source_digest):
    report = json.loads((directory / "runtime.json").read_text())
    cases = json.loads((directory / "runtime_cases.json").read_text())
    expected = {(i, positive) for i, (_, op, _) in enumerate(sites)
                for positive in ((False, True) if op == "CD" else (False,))}
    require(report["status"] == "UNIVERSAL_MATHEMATICAL_PASS" and not report["failures"],
            "The supplied runtime receipt is not a pass")
    require(report["table_sha256"] == native_digest and
            report["sites_sha256"] == source_digest, "Runtime receipt belongs to other inputs")
    require(len(cases) == len(expected) == report["proved_cases"] ==
            report["expected_cases"] == 5060, "Wrong runtime case census")
    require({(c["site_index"], c["positive"]) for c in cases} == expected,
            "Runtime case coverage has a gap or unexpected guard")
    for case in cases:
        require(len(case["duration"]) == 13 and case["duration"][0] > 0 and
                all(n >= 0 for n in case["duration"]), "Invalid progress certificate")
    return {"status": "RECEIPT_IDENTITIES_AND_EXACT_COVERAGE_PASS",
            "cases": len(cases),
            "runtime_report_sha256": digest(directory / "runtime.json"),
            "runtime_cases_sha256": digest(directory / "runtime_cases.json"),
            "scope": "Recorded proof receipt checked; symbolic derivations are not rerun here"}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("original_package", type=Path,
                    help="Pinned original U222 package, containing machine/ and inputs/")
    ap.add_argument("release_directory", type=Path,
                    help="New source directory containing sites.json and, by default, the U220 tables")
    ap.add_argument("output", type=Path)
    ap.add_argument("--native", type=Path, help="Override path to the native U220 table")
    ap.add_argument("--dense", type=Path, help="Override path to the dense U220 table")
    ap.add_argument("--runtime-directory", type=Path)
    ap.add_argument("--rejected-table", type=Path,
                    help="Optional first rejected U220 allocation, for the marker negative control")
    args = ap.parse_args()
    original, release = args.original_package, args.release_directory
    native_path = args.native or release / "u220.native.tm"
    dense_path = args.dense or release / "u220.tm"
    require(sha(original / "machine/u.native.tm") ==
            "88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427",
            "Original U222 native table is not pinned")
    require(sha(original / "machine/sites.json") ==
            "1d258cfe56f8b845826a63af57de8134fbc4886b47f95312cf6d49424f3f3072",
            "Original U222 source is not pinned")
    require(sha(original / "inputs/k215_sites.json") ==
            "17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba",
            "Original K215 source is not pinned")
    require(sha(release / "sites.json") ==
            "711b6fd113d70888b336be984b22a8b8824f5280bebbd283ce0c75fe22aefd69",
            "New source is not pinned")
    require(sha(native_path) ==
            "414fe9c89a13e92ed9fcc2f99bc577865df824c92c95a06bd6774d37e6d30812",
            "Native U220 table is not the accepted corrected allocation")
    require(sha(dense_path) ==
            "9439ec08a7af2a8441adc22532ff6d2112a1388b6f67966b221e3b6ab0d5102e",
            "Dense U220 table is not pinned")
    source_result = verify(original, release)
    old = table(original / "machine/u.native.tm")
    native = table(native_path)
    dense = table(dense_path, 220)
    require(len(old) == 444 and len(native) == len(dense) == 440, "Wrong row census")
    rename = {q: i for i, q in enumerate(sorted({q for q, b in native}))}
    rename[254] = 220
    require({(rename[q], b): (w, d, rename[z])
             for (q, b), (w, d, z) in native.items()} == dense,
            "The canonical dense table is not the exact native renaming")

    # Recover the uniquely specified 221-state parent without requiring a
    # separate file in the archive, and bind it to the actual allocator output.
    before = dict(native)
    before[112, 1] = (1, 1, 200)
    before[200, 0] = (0, 1, 157)
    before[200, 1] = (1, 1, 119)
    parent_digest = hashlib.sha256(encode(before)).hexdigest()
    require(parent_digest ==
            "1f531f6ed04b0d5faf39fcf28ea9aa4c7d219a0c263c56b93ea40e0d3e4520d5",
            "Recovered prequotient table differs from the corrected allocation")
    equations = verify_local(before, native)
    require(equations == 441, "Wrong quotient-equation census")
    configs = [(0, 0, set()) for _ in range(4)]
    tables = [old, before, native, dense]
    reallocations = Counter()
    for tick in range(95714):
        a, b, c, d = configs
        require(a[1:] == b[1:] == c[1:] == d[1:], "Startup tape/head discrepancy")
        require(c[0] == project(b[0]) and d[0] == rename[c[0]], "Startup control discrepancy")
        if a[0] != b[0]:
            reallocations[a[0], b[0]] += 1
        q, h, ones = b
        require(q != 112 or h+1 not in ones, "Prequotient neighbor invariant failed")
        require(q != 200 or h not in ones, "Prequotient scanned-cell invariant failed")
        configs = [advance(t, c) for t, c in zip(tables, configs)]
    require(configs[0] == configs[1] == configs[2], "Final native startup frames differ")
    require(configs[3][0] == rename[configs[2][0]] and
            configs[3][1:] == configs[2][1:], "Final dense startup frame differs")
    q, h, ones = configs[0]
    inherited = json.loads((original / "evidence/startup.json").read_text())
    require((q, h, sorted(ones)) ==
            (inherited["state"], inherited["head"], inherited["one_cells"]),
            "Startup target differs from complete original frame")
    sites = json.loads((release / "sites.json").read_text())
    marker = marker_regression(native, sites[3435])
    require(marker["passed"], "The marker-sensitive primitive regression failed")
    negative = None
    if args.rejected_table:
        negative = marker_regression(table(args.rejected_table), sites[3435])
        require(not negative["passed"], "The rejected marker allocation was not rejected")
    runtime = None
    if args.runtime_directory:
        runtime = check_runtime_receipt(args.runtime_directory, sites,
                                        sha(native_path), sha(release / "sites.json"))
    result = {
        "status": "INDEPENDENT_U220_AUDIT_PASS",
        "native_sha256": sha(native_path), "dense_sha256": sha(dense_path),
        "source_sha256": sha(release / "sites.json"),
        "prequotient_sha256": parent_digest,
        "working_states": 220, "transition_rows": 440,
        "source_audit": source_result,
        "local_quotient_commuting_equations": equations,
        "dense_renaming_transition_equations": len(native),
        "startup_steps": 95714,
        "startup_complete_tapes_and_heads_equal_every_step": True,
        "startup_control_reallocation": [[a, b, n] for (a, b), n in sorted(reallocations.items())],
        "final_native_frame": {"state": q, "head": h, "one_cells": sorted(ones)},
        "marker_regression_site": 3435,
        "marker_regression": marker,
        "rejected_marker_negative_control": negative,
        "runtime_receipt": runtime,
        "scope": "Independent exact source/table checks, local-quotient hypotheses, and literal replay; ordinary logical proof and full universal runtime checker remain distinct evidence",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ("source_audit", "final_native_frame", "marker_regression",
                                   "rejected_marker_negative_control")}, indent=2))


if __name__ == "__main__":
    main()
