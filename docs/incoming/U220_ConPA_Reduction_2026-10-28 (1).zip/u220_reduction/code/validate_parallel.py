"""Parallel scheduling of the unchanged U222 symbolic runtime proof rules.

No sampling: every primitive guard case is passed to symbolic_runtime.case.
The sequential U222 checker remains in the original source package.
"""
import sys,json,time,hashlib,multiprocessing,argparse
from pathlib import Path
v=None
TABLE=None;LEMMAS=None

def prove(job):
 i,site,positive=job
 try:
  a=v.s.case(TABLE,LEMMAS,site,positive);a['rows']=sorted(a['rows']);a.pop('trace');return {'site_index':i,'positive':positive,**a}
 except Exception as e:return {'failure':True,'site_index':i,'site':site,'positive':positive,'reason':str(e)}

def main():
 global TABLE,LEMMAS,v
 a=argparse.ArgumentParser();a.add_argument('table',type=Path);a.add_argument('sites',type=Path);a.add_argument('output',type=Path);a.add_argument('--jobs',type=int,default=6);a.add_argument('--validator-directory',type=Path,default=Path(__file__).resolve().parent,help='Directory containing the archived validate_native.py and runtime/.');args=a.parse_args();sys.path.insert(0,str(args.validator_directory.resolve()));import validate_native;v=validate_native;args.output.mkdir(exist_ok=True,parents=True)
 T=v.s.r.table(args.table);sites=json.loads(args.sites.read_text());states={q for q,b in T};m={int(k):int(z)for k,z in json.loads(v.MAPPATH.read_text()).items()}
 assert all((q,b)in T for q in states for b in(0,1)) and {z for w,d,z in T.values()}-states=={254}
 leaves={pc for pc,op,arg in sites};prefixes={pc[:i]for pc in leaves for i in range(len(pc))};assert not leaves&prefixes and len(leaves)==len(sites)
 assert all(p+b in leaves|prefixes for p in prefixes for b in('0','1'))
 for q in states|{254}:
  if q not in m:m[q]=q+1000
 assert len({m[q]for q in states|{254}})==len(states)+1
 TABLE={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()};LEMMAS,blocks=v.s.prove_blocks(TABLE);st=v.startup(T);(args.output/'startup.json').write_text(json.dumps(st,indent=2)+'\n');print('STARTUP',st['status'],st['steps'],flush=True)
 jobs=[(i,site,pos)for i,site in enumerate(sites)for pos in((False,True)if site[1]=='CD'else(False,))];started=time.monotonic()
 with multiprocessing.get_context('fork').Pool(args.jobs)as pool:cases=list(pool.imap(prove,jobs,chunksize=32))
 fail=[c for c in cases if c.get('failure')];passed=[c for c in cases if not c.get('failure')]
 report={'status':'UNIVERSAL_MATHEMATICAL_PASS'if not fail else'NOT_PROVED','table_sha256':v.digest(args.table),'sites_sha256':v.digest(args.sites),'checker_sha256':v.digest(Path(v.s.__file__)),'helper_sha256':v.digest(Path(v.s.r.__file__)),'working_states':len(states),'site_count':len(sites),'expected_cases':len(jobs),'proved_cases':len(passed),'failures':fail,'blocks':blocks,'seconds':time.monotonic()-started,'startup_status':st['status'],'scheduler':'cases scheduled in fork workers; unchanged proof rules','scheduler_sha256':v.digest(Path(__file__)),'scope':'All natural primary values at each guard; arbitrary natural gap; nonempty arbitrary finite spare list; complete zero exterior. Induction over unary scans and list length. Not proof-assistant kernel checked.'}
 (args.output/'runtime.json').write_text(json.dumps(report,indent=2)+'\n');(args.output/'runtime_cases.json').write_text(json.dumps(passed,indent=2)+'\n');print(json.dumps({k:z for k,z in report.items()if k not in('blocks',)},indent=2),flush=True)
 if fail:sys.exit(1)
if __name__=='__main__':main()
