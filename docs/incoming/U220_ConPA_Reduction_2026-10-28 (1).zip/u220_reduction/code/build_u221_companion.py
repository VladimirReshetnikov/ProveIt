#!/usr/bin/env python3
"""Build and audit the one-state U222 -> U221 local quotient.

The decisive certificate is syntactic: in U222, every entry to state 200
is immediately preceded by 112/1, and every entry to state 112 is immediately
preceded by 172/0. The latter writes 0 and moves left; the former moves right.
Thus state 200 necessarily reads 0, from any tape whose initial state is 0.

The proof is given in local_quotient_proof.txt. This executable checks all
hypotheses and every transition equation; it is not a proof-assistant kernel.
Only Python's standard library is required.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

BASELINE_SHA256 = "88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427"
START, HALT = 0, 254
A, B, C = 172, 112, 200


def require(test, message):
    if not test:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def parse(data):
    table = {}
    starts = []
    for line in data.decode("ascii").splitlines():
        if line.startswith("#! start "):
            starts.append(int(line[9:]))
        elif line and not line.startswith("#"):
            fields = line.split()
            require(len(fields) == 5, "Invalid transition width")
            q, b, w, direction, z = fields
            q, b, w, z = map(int, (q, b, w, z))
            require((q, b) not in table, "Duplicate transition")
            require(b in (0, 1) and w in (0, 1), "Nonbinary transition")
            require(direction in ("L", "R"), "Invalid head movement")
            table[q, b] = (w, -1 if direction == "L" else 1, z)
    require(starts == [START], "Expected exactly one start declaration")
    return table


def encode(table):
    lines = ["#! start 0"]
    for (q, bit), (write, direction, target) in sorted(table.items()):
        move = "R" if direction == 1 else "L"
        lines.append(f"{q} {bit} {write} {move} {target}")
    return ("\n".join(lines) + "\n").encode("ascii")


def validate(table, halt=HALT):
    states = {q for q, _ in table}
    require(START in states and halt not in states, "Wrong start/halt convention")
    require(set(table) == {(q, b) for q in states for b in (0, 1)},
            "Not a complete binary working table")
    require({z for w, d, z in table.values()} <= states | {halt}, "Unknown target")
    reached = {START}
    queue = [START]
    for q in queue:
        for b in (0, 1):
            z = table[q, b][2]
            if z != halt and z not in reached:
                reached.add(z)
                queue.append(z)
    require(reached == states, "A working state is graph-unreachable")
    return states


def incoming(table, target):
    return sorted([q, b] for (q, b), action in table.items() if action[2] == target)


def local_invariant(table):
    require(START not in (B, C) and HALT not in (B, C), "Exceptional start/halt")
    require(incoming(table, B) == [[A, 0]], "State B has an unaccounted entrance")
    require(incoming(table, C) == [[B, 1]], "State C has an unaccounted entrance")
    require(table[A, 0] == (0, -1, B), "A/0 must write 0 and move left to B")
    require(table[B, 1] == (1, 1, C), "B/1 must return right to C")
    require(table[B, 0] == table[C, 0], "The two live read-0 actions differ")
    return {
        "entry_to_B": [A, 0, *table[A, 0]],
        "entry_to_C": [B, 1, *table[B, 1]],
        "incoming_B": incoming(table, B),
        "incoming_C": incoming(table, C),
        "B_read_0": list(table[B, 0]),
        "C_read_0": list(table[C, 0]),
        "impossible_row": [C, 1],
        "quantification": "Every initial tape and head position, initial state 0",
    }


def project(q):
    return B if q == C else q


def quotient(table):
    return {(q, bit): (write, direction, project(target))
            for (q, bit), (write, direction, target) in table.items() if q != C}


def verify_commutation(old, new):
    checked = []
    for (q, bit), (write, direction, target) in sorted(old.items()):
        if (q, bit) == (C, 1):
            continue
        expected = (write, direction, project(target))
        require(new.get((project(q), bit)) == expected,
                f"Projection fails at row {(q, bit)}")
        checked.append([q, bit])
    require(len(checked) == 443, "Wrong transition-equation census")
    require(project(START) == START and project(HALT) == HALT,
            "Projection does not preserve start/halt")
    require([q for q in {x for x, _ in old} | {HALT} if project(q) == HALT] == [HALT],
            "A working state projects to halt")
    return checked


def negative_controls(old, new):
    outcomes = {}

    def rejects(name, fn):
        try:
            fn()
        except ValueError as exc:
            outcomes[name] = {"rejected": True, "reason": str(exc)}
        else:
            raise ValueError(f"Negative control was accepted: {name}")

    altered = dict(old)
    altered[A, 0] = (1, -1, B)
    rejects("predecessor_writes_one", lambda: local_invariant(altered))

    altered = dict(old)
    altered[A, 0] = (0, 1, B)
    rejects("predecessor_moves_right", lambda: local_invariant(altered))

    altered = dict(old)
    altered[START, 0] = (0, 1, C)
    rejects("new_incoming_edge_to_200", lambda: local_invariant(altered))

    altered = dict(old)
    altered[START, 0] = (0, 1, B)
    rejects("new_incoming_edge_to_112", lambda: local_invariant(altered))

    altered = dict(new)
    w, d, z = altered[B, 0]
    altered[B, 0] = (1-w, d, z)
    rejects("quotient_wrong_live_write", lambda: verify_commutation(old, altered))

    altered = dict(new)
    w, d, z = altered[B, 1]
    altered[B, 1] = (w, d, 157)
    rejects("quotient_wrong_loop_target", lambda: verify_commutation(old, altered))
    return outcomes


def build(baseline, output):
    raw = baseline.read_bytes()
    require(digest(raw) == BASELINE_SHA256, "Pinned U222 table hash mismatch")
    old = parse(raw)
    require(len(validate(old)) == 222, "Baseline must have 222 working states")
    invariant = local_invariant(old)
    new = quotient(old)
    states = validate(new)
    require(len(states) == 221, "Quotient must have 221 working states")
    equations = verify_commutation(old, new)
    controls = negative_controls(old, new)

    dense_map = {q: i for i, q in enumerate(sorted(states))}
    dense_map[HALT] = len(states)
    dense = {(dense_map[q], b): (w, d, dense_map[z])
             for (q, b), (w, d, z) in new.items()}
    require(len(validate(dense, 221)) == 221, "Dense table is malformed")
    inverse = {v: k for k, v in dense_map.items()}
    require({(inverse[q], b): (w, d, inverse[z])
             for (q, b), (w, d, z) in dense.items()} == new,
            "Dense renaming did not preserve transitions")
    native_raw, dense_raw = encode(new), encode(dense)
    output.mkdir(parents=True, exist_ok=True)
    (output / "u221.native.tm").write_bytes(native_raw)
    (output / "u221.tm").write_bytes(dense_raw)
    (output / "native_to_dense.json").write_text(json.dumps(dense_map, indent=2) + "\n")
    report = {
        "status": "LOCAL_INVARIANT_AND_EXACT_QUOTIENT_PASS",
        "baseline_sha256": digest(raw),
        "native_sha256": digest(native_raw),
        "dense_sha256": digest(dense_raw),
        "working_states": 221,
        "transition_rows": 442,
        "native_start": START,
        "native_halt": HALT,
        "dense_start": 0,
        "dense_halt": 221,
        "projection": {"200": 112, "all_other_states": "identity"},
        "patch": {"redirected_row": [112, 1, 1, 1, 112], "deleted_state": 200},
        "local_invariant": invariant,
        "checked_projection_rows": equations,
        "negative_controls": controls,
        "claim": "Exact stepwise tape/head equality, projected control, from any state-0 tape",
        "proof_status": "Ordinary mathematical proof with exhaustive finite premise checks",
    }
    (output / "quotient_certificate.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "checked_projection_rows"}, indent=2))
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    build(args.baseline, args.output)
