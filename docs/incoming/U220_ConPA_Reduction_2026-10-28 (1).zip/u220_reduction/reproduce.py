#!/usr/bin/env python3
"""Rebuild and verify the exact U220 construction without network or a solver.

Default: exact source/table reconstruction, two source audits, local quotient,
blank startup, arithmetic-routing negative control, and U221 companion.
--full: also rerun every symbolic primitive case. --jobs N uses the supplied
parallel scheduler on systems supporting fork; --jobs 1 uses the unchanged
sequential U222 driver.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE_HASH = 'd23e80857214900f8e0806f03f6df752af501dd0108eb92c6ed7a49795802652'
SOURCE_HASH = '711b6fd113d70888b336be984b22a8b8824f5280bebbd283ce0c75fe22aefd69'
NATIVE_HASH = '414fe9c89a13e92ed9fcc2f99bc577865df824c92c95a06bd6774d37e6d30812'
DENSE_HASH = '9439ec08a7af2a8441adc22532ff6d2112a1388b6f67966b221e3b6ab0d5102e'
INTERMEDIATE_HASH = '1f531f6ed04b0d5faf39fcf28ea9aa4c7d219a0c263c56b93ea40e0d3e4520d5'


def need(value, message):
    if not value:
        raise RuntimeError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def manifest():
    seen = set()
    path = ROOT / 'SHA256SUMS'
    need(path.is_file(), 'The release manifest is missing')
    for line in path.read_text().splitlines():
        expected, name = line.split('  ', 1)
        relative = Path(name)
        need(not relative.is_absolute() and '..' not in relative.parts, 'Unsafe manifest path')
        need(name not in seen, 'Repeated manifest entry')
        seen.add(name)
        need(digest(ROOT / relative) == expected, 'Hash mismatch: ' + name)
    need({'machine/u220.tm', 'machine/u220.native.tm', 'machine/sites.json',
          'inputs/source_recipe.json', 'inputs/table_recipe.json',
          'paper/report.tex', 'paper/report.pdf', 'reproduce.py',
          'upstream/U222_ConU_2026-10-28.zip'} <= seen,
         'Manifest omits a principal artifact')
    return len(seen)


def run(script, args, temporary, name, optimized=False):
    argv = [sys.executable, '-B'] + (['-O'] if optimized else [])
    argv += [str(script), *map(str, args)]
    print('Checking ' + name, flush=True)
    log = temporary / (name + '.log')
    with log.open('w') as stream:
        result = subprocess.run(argv, cwd=temporary, stdout=stream,
                                stderr=subprocess.STDOUT,
                                env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
    if result.returncode:
        print(log.read_text(), file=sys.stderr)
    need(result.returncode == 0, 'Failed verification stage: ' + name)


def unpack(temporary):
    archive = ROOT / 'upstream/U222_ConU_2026-10-28.zip'
    need(digest(archive) == ARCHIVE_HASH, 'Pinned U222 archive differs')
    destination = temporary / 'upstream'
    destination.mkdir()
    with zipfile.ZipFile(archive) as z:
        for member in z.infolist():
            target = (destination / member.filename).resolve()
            need(target.is_relative_to(destination.resolve()), 'Unsafe archive path')
            need((member.external_attr >> 16) & 0o170000 != 0o120000,
                 'Unexpected archive symbolic link')
        z.extractall(destination)
    return destination / 'u222_consistency_machine'


def check_runtime(result, source, upstream):
    expected = sum(2 if row[1] == 'CD' else 1 for row in source)
    need(result['status'] == 'UNIVERSAL_MATHEMATICAL_PASS', 'Runtime status')
    need(result['table_sha256'] == NATIVE_HASH, 'Runtime table binding')
    need(result['sites_sha256'] == SOURCE_HASH, 'Runtime source binding')
    need(result['working_states'] == 220 and result['site_count'] == 3891,
         'Runtime state/site census')
    need(result['expected_cases'] == result['proved_cases'] == expected == 5060,
         'Incomplete runtime coverage')
    need(not result['failures'], 'Runtime contains failures')
    need(result['startup_status'] == 'CALIBRATED_DIRTY_ROOT_SEED', 'Runtime initialization')
    need(result['checker_sha256'] == digest(upstream / 'code/runtime/symbolic_runtime.py'),
         'Wrong symbolic proof rules')
    need(result['helper_sha256'] == digest(upstream / 'code/runtime/independent_runtime.py'),
         'Wrong symbolic helper')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--full', action='store_true')
    ap.add_argument('--jobs', type=int, default=1)
    ap.add_argument('--report', type=Path)
    args = ap.parse_args()
    need(sys.flags.optimize == 0 and not os.environ.get('PYTHONOPTIMIZE'),
         'Run this driver with assertions enabled, without -O or PYTHONOPTIMIZE')
    need(args.jobs >= 1, 'jobs must be positive')
    begun = time.monotonic()
    count = manifest()
    with tempfile.TemporaryDirectory(prefix='u220-replay-') as directory:
        tmp = Path(directory)
        upstream = unpack(tmp)
        candidate = tmp / 'machine'
        candidate.mkdir()
        for optimized, label in [(False, 'normal'), (True, 'optimized')]:
            generated = tmp / ('generated-' + label)
            generated.mkdir()
            run(upstream / 'code/build_source.py',
                ['--baseline', upstream / 'inputs/k215_sites.json', '--recipe',
                 ROOT / 'inputs/source_recipe.json', '--output', generated / 'sites.json'],
                tmp, 'source-' + label, optimized)
            run(upstream / 'code/build_table.py',
                ['--baseline', upstream / 'inputs/k215.native.tm', '--recipe',
                 ROOT / 'inputs/table_recipe.json', '--output', generated],
                tmp, 'table-' + label, optimized)
            for generated_name, released_name in [('sites.json', 'sites.json'),
                    ('u.tm', 'u220.tm'), ('u.native.tm', 'u220.native.tm'),
                    ('state_map.json', 'state_map.json')]:
                need((generated / generated_name).read_bytes() ==
                     (ROOT / 'machine' / released_name).read_bytes(),
                     'Reconstruction differs: ' + released_name)
            if not optimized:
                for name in ['sites.json', 'u.tm', 'u.native.tm']:
                    shutil.copy2(generated / name, candidate / name)
        shutil.copy2(ROOT / 'machine/construction.json', candidate / 'construction.json')
        need(digest(candidate / 'sites.json') == SOURCE_HASH and
             digest(candidate / 'u.native.tm') == NATIVE_HASH and
             digest(candidate / 'u.tm') == DENSE_HASH, 'Primary byte identities')

        run(ROOT / 'code/audit_source_exchanged.py',
            ['--baseline', upstream / 'inputs/k215_sites.json', '--candidate', candidate,
             '--unshifted', '--upper-first', '--macro-dag', upstream / 'references/logic/DagPerm.v',
             '--out', tmp / 'source-audit.json'], tmp, 'macro-source-audit')
        audit = read(tmp / 'source-audit.json')
        need(audit['status'] == 'PASS' and audit['matrix_code'] == 'c'
             and audit['clause_order'] == 'upper-first', 'Source audit status')
        need(audit['closed_splice']['retained_primitive_nodes'] == 3154,
             'Retained source census')
        need(audit['new_body_literal_binding']['bound_new_primitive_instructions'] == 737
             and audit['unchanged_axiom_stack_slots'] == 10, 'New source interface')
        bindings = audit['proved_macro_node_binding']['macro_nodes']
        need(set(bindings) == {'119', '168', '171', '177', '180', '181', '218'}
             and all(v['exact_CFG_match_modulo_primitive_normalization']
                     for v in bindings.values()), 'Inherited macro proof bindings')
        run(ROOT / 'code/audit_source220.py', [upstream, candidate,
            tmp / 'independent-source.json'], tmp, 'independent-source-audit')
        independent = read(tmp / 'independent-source.json')
        need(independent == read(ROOT / 'evidence/source_audit_independent.json'),
             'Independent source audit differs')

        allocation = tmp / 'allocation'
        allocation.mkdir()
        shutil.copy2(ROOT / 'machine/u221_reordered.native.tm', allocation / 'candidate.native.tm')
        shutil.copy2(candidate / 'u.native.tm', allocation / 'candidate220.native.tm')
        need(digest(allocation / 'candidate.native.tm') == INTERMEDIATE_HASH,
             'Wrong pre-quotient table')
        run(ROOT / 'code/audit_literal220.py',
            [upstream, allocation, candidate / 'sites.json', tmp / 'literal-audit.json',
             '--rejected-table', ROOT / 'inputs/rejected_allocation.native.tm'],
            tmp, 'literal-quotient-bootstrap')
        literal = read(tmp / 'literal-audit.json')
        need(literal['status'] == 'INDEPENDENT_STARTUP_LOCAL_QUOTIENT_AND_MARKER_REGRESSION_PASS'
             and literal['quotient_live_equations'] == 441, 'Local quotient audit')
        need(literal['startup_steps'] == 95714 and
             literal['startup_tapes_and_heads_equal_at_every_step'], 'Blank startup audit')
        need(literal['corrected_marker_regression']['passed'] and
             not literal['rejected_marker_regression']['passed'], 'Routing control')
        expected_literal = read(ROOT / 'evidence/literal_audit_independent.json')
        normalized = lambda j: {k: v for k, v in j.items() if k != 'tables'}
        need(normalized(literal) == normalized(expected_literal), 'Literal audit differs')
        need([x['sha256'] for x in literal['tables']] ==
             [x['sha256'] for x in expected_literal['tables']], 'Literal audit tables differ')

        companion = tmp / 'companion'
        run(ROOT / 'code/build_u221_companion.py',
            [upstream / 'machine/u.native.tm', companion], tmp, 'local-u221-companion')
        for name in ['u221.tm', 'u221.native.tm', 'native_to_dense.json',
                     'quotient_certificate.json']:
            need((companion / name).read_bytes() == (ROOT / 'companion' / name).read_bytes(),
                 'Companion differs: ' + name)

        source = read(candidate / 'sites.json')
        check_runtime(read(ROOT / 'evidence/runtime.json'), source, upstream)
        saved_startup = read(ROOT / 'evidence/startup.json')
        need(saved_startup['steps'] == 95714 and
             saved_startup['registers'] == [4, 0, 0, 0, 0, 0, 0, 0, 0] and
             saved_startup['spares'] == [1] * 40 and saved_startup['gap'] == 1,
             'Saved startup calibration')
        if args.full:
            destination = tmp / 'runtime'
            runtime_args = [candidate / 'u.native.tm', candidate / 'sites.json', destination]
            if args.jobs == 1:
                script = upstream / 'code/validate_native.py'
            else:
                script = ROOT / 'code/validate_parallel.py'
                runtime_args += ['--jobs', args.jobs, '--validator-directory', upstream / 'code']
            run(script, runtime_args, tmp, 'all-symbolic-cases')
            fresh = read(destination / 'runtime.json')
            check_runtime(fresh, source, upstream)
            need(read(destination / 'runtime_cases.json') ==
                 read(ROOT / 'evidence/runtime_cases.json'), 'Regenerated cases differ')
            need(read(destination / 'startup.json') == saved_startup,
                 'Regenerated startup differs')
        receipt = {
            'status': 'U220_FULL_REPRODUCTION_PASS' if args.full else 'U220_CONSTRUCTION_AUDIT_PASS',
            'manifest_files_checked': count, 'working_states': 220, 'transition_rows': 440,
            'native_sha256': NATIVE_HASH, 'dense_sha256': DENSE_HASH,
            'source_sha256': SOURCE_HASH, 'source_occurrences': 3891,
            'source_dag_nodes': independent['new_metrics']['dag_nodes'],
            'retained_source_instructions': 3154, 'new_macro_instructions': 737,
            'ten_entry_stack_interface_unchanged': True,
            'reconstruction_normal_and_optimized': True,
            'independent_source_and_literal_audits': True,
            'local_quotient_live_equations': 441,
            'routing_negative_control_reproduced': True,
            'startup_steps': 95714,
            'u221_companion_reconstructed': True,
            'symbolic_cases': 5060, 'symbolic_cases_rerun': args.full,
            'symbolic_workers': args.jobs if args.full else 0,
            'seconds': round(time.monotonic() - begun, 3),
            'proof_scope': 'Ordinary PA-formalizable proof with executable source/runtime checks; '
                           'no new end-to-end proof-assistant certificate.',
        }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
