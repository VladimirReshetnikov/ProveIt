# U220: a 220-state reduction of the primary U222 candidate

**Primary result:** `machine/u220.tm` is an explicit binary Turing machine
with **220 working states**, 440 transitions, start state 0, and separate
halt label 220. The tape is initially all zero, infinite in both directions;
there is one tape and one head, and every step moves left or right.
Initialization is included in the state count.

The mathematical result, with the supplied U222/U consistency calibration,
is

    PA proves: Nonhalt(U220, blank) iff Con(U) iff Con(PA).

This saves **two states relative to the primary U222 candidate**, and
eighteen relative to the specified PA238 reference. It is an achieved upper
bound, not a claim of absolute minimality.

## The two savings

1. **Equivalent axiom formula, better source sharing.** Exchange the two
   curried antecedents inside the lower covering clause, and swap the
   covering clauses in the outer negative shell. Both use the ordinary
   implication identity `A -> (B -> C) <-> B -> (A -> C)`. No binder changes
   or moves. Uniform finite proof translations show the old and new numerical
   calculi prove exactly the same codes, including for selectors 0 and 1.
   Closed-macro reassociation lowers the source DAG from 204 to 202 nodes.
   Correct physical allocation removes native state 507, yielding a
   221-state intermediate with the reordered source.

2. **A local tape invariant removes native state 200.** The only entry to
   state 112 is `172/0 -> 0L112`; the only entry to 200 is
   `112/1 -> 1R200`. Therefore 112 always has a zero immediately right of
   the head, and 200 always reads zero. Since `112/0 = 200/0 = 0R157`,
   change `112/1` to `1R112` and delete state 200. This final quotient
   preserves every step, complete tape, head, and halting time of that
   reordered 221-state intermediate.

The complete U222-to-U220 patch changes 75 retained native rows and deletes
states 200 and 507. The source keeps 3,891 primitive occurrences, the same
737-instruction shell size, and the ten-entry axiom-stack interface.

## Files

| File or directory | Purpose |
|---|---|
| `paper/report.pdf` | Full mathematical paper and complete transition table |
| `paper/report.tex` | Main LaTeX source |
| `paper/u220_shell_proof.tex` | Uniform numerical derivation-transport proof |
| `machine/u220.tm` | Definitive dense 220-state transition table |
| `machine/u220.native.tm` | Same machine with native compiler labels |
| `machine/u221_reordered.native.tm` | Corrected 221-state pre-quotient allocation |
| `machine/sites.json` | Exact new source program |
| `machine/state_map.json` | Native-to-dense bijection |
| `inputs/` | Fixed source/table recipes, full patch, rejected allocation control |
| `code/` | Source audits, literal audits, optional runtime scheduler |
| `evidence/` | Fresh runtime cases, complete startup, independent receipts |
| `companion/` | Simpler 221-state reduction with the original source unchanged |
| `upstream/` | Exact original U222 ZIP and pinned input identities |
| `notes/` | Logical review, construction provenance, and proof-scope notes |
| `reproduce.py` | Non-mutating offline build and check driver |

Dense table SHA-256:

    9439ec08a7af2a8441adc22532ff6d2112a1388b6f67966b221e3b6ab0d5102e

Native table SHA-256:

    414fe9c89a13e92ed9fcc2f99bc577865df824c92c95a06bd6774d37e6d30812

Source-site SHA-256:

    711b6fd113d70888b336be984b22a8b8824f5280bebbd283ce0c75fe22aefd69

## Reproduce offline

Python 3.10+ and its standard library suffice. No network, solver, external
repository checkout, or proof-assistant installation is required.

```sh
python3 reproduce.py
```

The default checks release integrity, byte-identical source/table
reconstruction in normal and optimized Python, both source audits, the
local quotient, the full blank initialization, the rejected-allocation
negative control, and the simpler U221 companion.

For all 5,060 arbitrary-register symbolic runtime cases:

```sh
python3 reproduce.py --full --report /tmp/u220-receipt.json
```

On a system supporting process forking, schedule the independent cases in
parallel with the same unchanged proof rules:

```sh
python3 reproduce.py --full --jobs 6 --report /tmp/u220-receipt.json
```

Run the driver with assertions enabled. The symbolic engine intentionally
rejects optimized Python. The driver tests the separate fixed builders under
`python -O`; this is distinct from disabling the symbolic proof checks.

All temporary verification data are written outside the release. A receipt
is written only when its path is explicitly supplied. The full check verifies
the exact case census, hashes, success statuses, case summaries, and complete
initial frame, rather than accepting only a successful process exit.

## Verification completed

- All **5,060** universal primitive cases passed on the accepted U220 table.
  Primary registers, gap, and finite nonempty spare list are arbitrary.
- All **737** new primitive instructions and edges bind to the new formula;
  all **3,154** retained instructions and edges are unchanged.
- All seven macro factors bind to the inherited all-natural proof contracts.
- Blank initialization takes exactly **95,714** steps and reaches the complete
  source frame with logical registers `(4,0,0,0,0,0,0,0,0)`.
- All **441** allowed pre-quotient transition equations and all **440** dense
  relabeling equations were independently checked.
- A marker-sensitive CI1 regression passes in **578** steps; the rejected
  earlier 220-state allocation fails after **538** steps. That rejected table
  is explicitly named as a negative control and is never an accepted result.
- The original U222 packet was independently replayed in full.

## Distinguish the two 221-state machines

`companion/u221.tm` is a direct state-200 merge in original U222. It retains
the original source and preserves original U222's entire run step for step.

`machine/u221_reordered.native.tm` is a different 221-state machine produced
by the new emitter and allocation. U220 is its stepwise quotient. U220's
equivalence with original U222 passes through the source/calculus proof;
we do **not** claim equality of their complete halting times.

## Mathematical and formal status

The new construction has an ordinary mathematical proof formalizable in PA,
with exact executable source and universal-runtime checks. The connection
from the original U222 calculus to Con(U), and from Con(U) to Con(PA), is the
supplied mathematical dependency. This packet does **not** export a new
end-to-end Lean, Rocq, MM0, or literal PA proof object. The existing K215/ZFC
certificate does not automatically certify the changed source or table.

The machine-facing unrestricted theory W+IR is connected to unary U and PA
through the supplied proof translations; the theories are not identified.
The original U222 ZIP is preserved unchanged. Its older shifted-emitter note
`references/theory_bridge_notes.txt` is superseded for the selected unshifted
machine by its final paper and enumerator notes. The audit records that
historical distinction. Some U222 audit notes were written before U220 was
accepted; `notes/logical_transport.txt` supplies the additional U220 proof.

## Rebuild the PDF

In a copy of the release:

```sh
cd paper
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
```

The machine is identified by its ASCII bytes and fixed hash; PDF metadata
can vary across TeX installations.

## Attribution

The inherited machines, theory, proof core, compiler, codec, and interpreter
retain the attribution in the supplied ProveIt, Mira, Andrew Wade, Jeff
Ketchersid, Elliot Glazer, and associated developments. This work adds the
selected emitter ordering/source factoring, context-correct allocation,
local state merge, transport proofs, and validation of U220. Original
notices and license texts are retained; no third-party work is relicensed.
