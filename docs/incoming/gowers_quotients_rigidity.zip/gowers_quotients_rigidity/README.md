# Exact Quotient Reduction and Sharp Stability in Gowers' Ramsey Framework

Research article prepared for Vladimir Reshetnikov, 6 October 2026.

The complete manuscript is **gowers_quotients_rigidity.tex**; the compiled
article is **gowers_quotients_rigidity.pdf**. The ZIP contains the figure,
verification programs, recorded outputs, source ledger, and build instructions.

## Mathematical contribution

1. **Exact quotient reduction in characteristic five.** On every nontrivial
   finite abelian group of exponent five, the maximum cube count of a real
   centered perturbation of a positive constant, at fixed U³ norm `u`, equals
   the maximum on the five-point group whenever `u/delta <= 10^-5`.
   Every maximizer factors through a five-point quotient. The result includes
   the norm-ball constraint and, in an explicit interior range, weights in
   `[0,1]`. A retained projection deficit yields quantitative off-quotient
   U² and U³ control.

2. **A theorem for every fixed odd exponent.** If the group has exponent
   exactly `m`, the corresponding profile equals that on `Z/mZ` when
   `u/delta <= 10^-8 m^-8`. Individual maximizers factor through some cyclic
   quotient of order dividing `m`. The cutoff is an explicit sufficient
   bound and has not been optimized.

3. **Sharp characteristic-five coefficients through order twelve.** Exact
   quotient reduction promotes the formerly five-point coefficient `20/9`
   to the dimension-uniform profile. The next coefficients are
   `869/(216*2^(3/4))` at `u^10/delta^2` and
   `65759/(5832*2^(3/2))` at `u^12/delta^4`.
   The full optimized profile is even and analytic near zero. Its first
   phase adjustment is explicitly computed; fixing the limiting phases
   would miss part of the twelfth-order term.

4. **Sharp odd-order critical stability.** For unit L² norm and deficit
   `epsilon = 1 - ||v||_U3^8`, the worst infidelity with a normalized
   quadratic phase on a subgroup coset is
   `epsilon/4 + 3*epsilon^2/16 + sqrt(2)*epsilon^(5/2)/64 + O(epsilon^3)`.
   The fractional term disappears when the group order is coprime to six.
   The article proves an explicit finite envelope, exact sharpness examples,
   and a tangent-rigidity corollary forcing an order-three character pair
   at asymptotic equality.

5. **Exact symmetric six-term extension count.** For the coloring
   `a + Norm_3(u) + Norm_5(v) + R(w)` over a finite field of characteristic
   greater than five, the article gives the exact progression count for
   arbitrary independent `R`. The correction involves centered third and
   fifth differences and a quadratic character. Equality with the baseline
   is equivalent to additive quadraticity over the prime field.

The manuscript contains **15 proposed research questions**, including the
optimal quotient range, exponent dependence, higher stability terms, higher
norm layers, the global quintic avoidance problem, and a formalization plan.

## Scope and status

These are local extremal and counting results, developed with AI assistance.
The article contains complete written proofs and independent algebraic and
computational checks. It has not been externally refereed or checked by Lean.
No new global Szemerédi bound or exhaustive claim of bibliographic priority
is made. Previously established results are credited separately.

The main analytic series is valid in an absolute neighborhood of zero that
may be smaller than the explicit range of exact quotient reduction. Numerical
stationary-branch calculations do not certify the size of that neighborhood.
All cube averages include zero increments and repeated vertices; the
six-term progression count explicitly removes zero directions.

## Repository checkpoint and integration

The inspected ProveIt checkpoint is
`12da356730b12cb73c276a258aaadf3223e3662b`.
`SOURCE_LEDGER.json` records eight source files whose bytes were verified
against their Git blob hashes, four separately inspected preceding reports,
and the primary literature. The consolidated research article inspected at
that checkpoint incorporates source reports 01–10.

Suggested destination: a separate contribution in the Ramsey research
collection, preserving the relationship with the existing report at
`Combinatorics/Ramsey/Research/GowersSzemeredi/local-quantitative-refinements/`.
This is a delivery archive, not a commit or a change to the existing Lean
catalogue. Existing theorem declarations should keep their current scope;
the new arithmetic hypotheses belong in separately stated refinements.

The main TeX source is complete and does not import manuscript fragments.
Keep `figures/asymptotic_coefficients.pdf` at its relative path when building.
The bibliography is embedded; BibTeX and external source files are unnecessary.

## Build

With TeX Live and `latexmk` available:

```sh
make pdf
```

Equivalently:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error gowers_quotients_rigidity.tex
```

The supplied PDF figure suffices for rebuilding the article. No Python
dependency is required just to compile the TeX source.

## Reproduce the mathematical checks

The recorded environment is in `data/environment.json`. It uses Python
3.12.14; package versions are pinned in `requirements.txt`.

```sh
python3 -m pip install -r requirements.txt
make verify
```

The five programs write their own JSON reports; the runner writes
`data/verification_run.json` and captures each program's output.

| Program | What it checks |
|---|---|
| `verify_quotient.py` | Exact rational cutoff, exact tenth-order identities, 160 finite Fourier projection examples |
| `verify_twelfth_order.py` | Exact Hessian/phase/amplitude calculations and twelfth-order coefficient, plus 80-digit stationary solutions |
| `verify_odd_cube_expansion.py` | All nine physical-cube coefficients on six odd-order groups, including nonprime cyclic groups |
| `verify_odd_rigidity.py` | Exact small-support cube multiplicities and 120 numerical Weyl-expansion/envelope examples |
| `verify_six_ap_defect.py` | Exact finite-field norm and quadratic-form distributions and all target fibers for base fields of orders 7 and 13 |

The universal proofs do not rely on sampling. Exact symbolic and finite
integer checks are explicitly separated from floating-point examples.
The scripts do not enumerate all center–direction pairs in the
ten-dimensional norm-coloring examples; they check the exact factorized
counting identities instead.

To reproduce the 120-digit figure and its CSV data:

```sh
make figures
```

Both plotted curves represent explicit families, not numerical assertions
of global optimality at every plotted positive parameter.

## Verification records

- `VALIDATION.json`: final build, reference, page, and visual-inspection status.
- `data/verification_run.json`: exit codes and execution times for all checks.
- `data/latex_build.log`: the recorded successful TeX build.
- `SHA256SUMS`: hashes for all included files other than the checksum file itself.

The archive omits temporary manuscript fragments, TeX auxiliary files,
rendered review pages, and downloaded copies of prior papers.
