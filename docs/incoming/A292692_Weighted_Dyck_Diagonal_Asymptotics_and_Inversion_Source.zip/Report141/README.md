# Report 141: A weighted Dyck path Newton diagonal

This offline companion accompanies Report141.pdf and its complete LaTeX source.
The mathematical proof is in the article. Finite exact checks and decimal
normalization diagnostics are separately reproducible; neither is a proof of
an asymptotic remainder. No all-orders theorem is claimed.

## Quick start

Requirements: Python 3.11 or newer, standard library only. PDF rebuilds also
need pdfTeX/pdflatex, the LaTeX packages named by Report141.tex, Latin Modern,
and the TeX font maps. The tested environment was Python 3.12.14 and pdfTeX
1.40.26 (TeX Live 2025/dev/Debian). No network access is needed.

All executable Python files reject non-isolated startup before importing
anything except built-in sys. Always supply -I; -B is also shown explicitly.
An unsealed local module cannot execute during normal verification.

The following are absolute-path examples. Replace /home/alice/Report141 with
the absolute directory containing this README. Ensure /home/alice/results
already exists and every named output below does not exist, even as a
symlink. The outputs must be outside the bundle. Do not use literal relative
placeholders, reuse existing output paths, or place output inside this tree.

    python -I -B /home/alice/Report141/verify.py check
    python -I -B /home/alice/Report141/verify.py replay --output /home/alice/results/report141-replay
    python -I -B -O /home/alice/Report141/verify.py replay --output /home/alice/results/report141-replay-optimized
    python -I -B /home/alice/Report141/verify.py selftest --output /home/alice/results/report141-selftest
    python -I -B /home/alice/Report141/verify.py build --output /home/alice/results/report141-build
    python -I -B /home/alice/Report141/verify.py pack --output /home/alice/results/Report141.zip
    python -I -B /home/alice/Report141/verify.py reproduce --output /home/alice/results/report141-reproduction

check validates the closed inventory, every SHA256 digest, and the complete
nested fixture schema. replay recomputes the mathematics and diagnostic
values, compares the complete result to the fixtures, and only then creates
its output directory. It does not regenerate or repair fixtures in place.
selftest works on disposable external copies, including deliberately corrupt
and rehashed inputs. build makes an isolated external TeX environment and
rebuilds the format plus the article; its result says whether the PDF bytes
match the frozen PDF. reproduce runs self-tests and two fresh PDF builds,
requires byte identity between them and the frozen PDF, and tests a fresh
ZIP extraction/repack. A different TeX toolchain can change PDF bytes even
when the mathematical source is identical.

pack uses sorted paths, fixed ZIP timestamps, fixed permissions, and stored
uncompressed entries. It contains this exact sealed bundle under Report141/.
No generated files or logs belong inside the bundle.

## Exact checks and fixture representation

code/exact.py uses Fraction arithmetic and independently builds completed-
peak path states. A state records height and whether the preceding step was
up; a factor k+x/h is attached only when a down-step completes a peak. This
construction does not use the weighted-prefix recurrence or Riccati equation.
A separate exhaustive walk generator checks every Dyck path through
semilength 7. All prefix polynomials, including parity-forbidden zeroes, are
recorded for lengths 0 through 24 and checked against both the last-step
recurrence and the powers of the independently defined Riccati series.

Polynomials are stored in increasing ordinary powers of k as canonical
rational strings. The Riccati and hypergeometric polynomials run through
order 20. Checks include the auxiliary differential equation, the
logarithmic-derivative convolution, coefficient positivity, monicity,
Stirling-number versus finite-difference Newton coefficients with the exact
factor 1/m!, and the large-power formula for Q_(N,m). Direct finite
Differences verify the Newton multiplication coefficients. The first eleven
A292692 terms are independently recovered from the polynomial diagonal.

code/algebra.py implements rational functions over Q and exact Q(sqrt(17))
arithmetic without a symbolic-algebra dependency. Rational functions have
coprime polynomials and monic denominators; a field pair [a,b] means
 a+b sqrt(17). It derives the Gaussian first correction by differentiation,
checks logarithmically shifted saddle coefficient algebra for all
0 <= r <= ell <= 4, derives the endpoint moments by Euler differentiation,
and solves the first contraction residual including its drift and opposite-
endpoint source. Newton operator polynomials through ell=12 verify their
leading and first subleading terms.

The exact output recovers

    d = (51 sqrt(17)-107)/4
    pi^3 C^2 = 2+2/sqrt(17)
    b1 = -989/2176-907 sqrt(17)/36992

The diagonal correction is the sum of the factorial contribution -3/16,
the Gaussian coefficient c1(s0), and r1(s0)/2. The inverse algebra records
c1_inverse=b1+1/12 and the cancellation for

    x1 = x0-c1_inverse/(x0 log(d x0))
    x0 = T/W(d T/e),  T = log(X)-log(C sqrt(2 pi))

With y=1/x0 and g=log(d x0), the first nonzero smooth residual term is
c1_inverse^2 y^3 (1/g+1/(2g^2)). This checks the algebra, not the analytic
error estimate. The article's integer inverse keeps its O(x0^-2/log x0)
uncertainty inside ceilings. Its existence constant is not supplied as an
effective numerical bound.

code/replay.py is loaded from verified bytes by verify.py. Its Decimal
calculations use 85 working digits and display 46 significant digits.
Four public b-file terms at n=40,80,160,290 provide convergence diagnostics;
they are source data, not independently enumerated terms. A smooth inverse
example at X=10^1000 is also diagnostic. These are not fitted coefficients,
proofs, certified intervals, or exact integer-threshold answers.

## Integrity, semantic fault tests, and output discipline

The manifest covers every payload byte except itself. Allowed file and
directory names are hard-coded. Unknown or missing entries, symlinks,
nonregular files, duplicate JSON keys, any JSON floating-point token
(including 1e999), NaN/Infinity, booleans in integer fields, noncanonical
rationals, unknown nested fields, and malformed arrays are rejected.
Decimal approximations are explicitly typed finite decimal strings.

Self-tests include structural corruption, source and mathematical fixture
faults with recomputed hashes, Gaussian/correction/inverse algebra faults,
all entrypoints' nonisolated import-shadowing defenses, output containment,
parent traversal, double-leading-slash aliases, symlink ancestors, existing
target preservation, nonmutation, and normal/-O byte-identical replay.
Hash-valid but mathematically false data are rejected by replay. Tests never
patch the original bundle. Output creation is exclusive and ancestor
symlinks are rejected before canonical containment checks.

This is an integrity/reproducibility seal, not an authenticated signature
or a sandbox for hostile code. Someone who changes the verifier and matching
hashes can create a different bundle. Obtain a trusted archive hash and
review source where that matters. The tool is designed for a trusted local
workspace; it does not claim adversarial filesystem race isolation.

For maintainers, seal validates payload and schemas and writes a proposed
manifest to an absent external file. It never installs it or rewrites this
bundle. After authorized edits, review and install it manually, then rerun
replay and reproduce:

    python -I -B /home/alice/Report141/verify.py seal --output /home/alice/results/report141-new-manifest.json

The public-source provenance and the scope of prior-art comparisons are in
SOURCES.md. No exploratory logs, internal notes, or unpublished audit files
are required to use this companion.
