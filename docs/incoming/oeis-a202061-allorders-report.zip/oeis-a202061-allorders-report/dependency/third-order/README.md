# The third logarithmic deficit term of A202061

A proof and reproducible research companion, 2 October 2026.

## Proved result

For classical 120-avoiding ascent sequences, put L=log n and F=n^(1/3)L^(2/3). The matching independently audited proofs establish

n log(mu)-log a_n
 = C_* F [1+(7/3)log L/L+kappa/L+o(1/L)],

where

C_*=2.2326253076128449221797647005258492735...,
kappa=-1.9401481831362703920932820713711739149... .

The report gives exact expressions for all constants and proves the result along every sufficiently large integer n. The previously conjectural global constant is now established at additive o(F/log n) precision. No numerical fit is used.

For T=log Y and N(Y)=min{n:a_n>=Y}, the corresponding inverse is

N(Y)=T/log(mu)+B_* T^(1/3)(log T)^(2/3)
 [1+(7/3)loglog T/log T+kappa_inv/log T+o(1/log T)],

where B_*=C_*(log mu)^(-4/3) and
kappa_inv=kappa-(2/3)log(log mu)=-2.39800354051534742875... .

## What is new

The upper coefficient bound retains the exact row amplitude in a quantitative finite-time calibration. The lower bound samples complete normalized tilted rows, preserving the small-q critical mass. A fixed central patch repairs both physical degree and endpoint height exactly with o(F/log n) loss. A scalar energy minimum constructs the required mean-flow arch without differentiating an asymptotic remainder.

## Files

- `a202061-third-order.pdf`: complete 17-page article
- `a202061-third-order.tex`, `proofs/*-section.tex`: editable sources
- `proofs/*.md`: source proof notes retained verbatim for provenance
- `audit/`: independent upper and lower proof reviews, exact amplitude/constant certificate, source hashes, and integrated report signoff
- `checks/`: exact algebra, scale checks, numerical evaluation from exact definitions, and byte-for-byte dependency pinning
- `dependency/second-order/`: the unchanged approved second-order package, including its unchanged sharp-deficit and positive-walk foundation dependencies
- `producer-replay.txt`: complete successful verification output
- `SHA256SUMS`: exact released payload set and SHA-256 hashes

The lower source note retains its pre-audit research-draft header. Its status is superseded by the hash-bound `audit/lower-construction-audit.md` and the integrated report review. Earlier dependencies retain their historical scope statements and conjectural outlooks unchanged; the present article states exactly which formerly open term is now proved.

## Reproduction

With Python 3, SymPy, mpmath, Bash and standard utilities, run

    bash verify_all.sh

This verifies the exact payload manifest when present, pins every byte of the approved dependency, runs the new deterministic checks, replays the independent amplitude/constant certificate, and runs the entire inherited mathematical verification chain. Finite diagnostics complement the analytic proofs and audits; they do not establish the asymptotic limits by themselves.

With a standard pdfLaTeX installation, rebuild using

    bash build.sh

The build fixes the PDF timestamp and rejects overfull boxes and unresolved references. The PDF is also rendered and visually inspected. Local `.build/`, `.qa/` and Python cache directories are excluded from the release.

The release generator requires hash-bound integrated signoff on all article sources and the final PDF. Its pinned second-order dependency manifest is SHA256 `a05af510251956f138a54be2aec3517dd34fd649e820d3227556d84bfcb5f7d6`.

## Scope

The remainder is o(n^(1/3)(log n)^(-1/3)) in the logarithm and may still diverge. The report does not give a multiplicative equivalent for a_n, a power-law prefactor, a fluctuation determinant, an exact integer inverse rounding rule, or an all-orders transseries. Possible higher inverse-log terms remain future work and are not included in the proved statement.

The audits are mathematical research verification, not journal peer review or formal proof-assistant certification. Source-comparison and priority qualifications are preserved in the unchanged dependencies. No additional literature-priority claim is made.
