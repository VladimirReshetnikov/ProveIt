# All finite inverse logarithmic orders for A202061

Complete proof and reproducibility companion, 2 October 2026.

## Main result

Let a_n count classical 120-avoiding ascent sequences. Put L=log n,
F=n^(1/3)L^(2/3), and B=kappa+(7/3)log L. For every fixed integer J>=0,

    n log(mu)-log a_n
      = C F [sum_{j=0}^J P_j(B)/L^j + o(L^(-J))].

The polynomials are universal and have exact degree j. Their highest-degree
coefficient is binomial(2/3,j)(3/2)^j. The paper gives a finite beta-moment
recurrence for every P_j and independently checked explicit formulas through
P4. In particular,

    P0=1,
    P1=B,
    P2=-B^2/4+7B/2-10,
    P3=(4B^3-105B^2+774B-2050-27pi^2)/24,
    P4=-(7B^4-273B^3+3444B^2-(19768+189pi^2)B
           +1944zeta(3)+999pi^2+46290)/48.

C=2.232625307612844922179764700526... and
kappa=-1.940148183136270392093282071371... have exact algebraic/logarithmic
expressions in the report. No sequence-value fitting is used.

For lambda=log(mu), T=log p, S=log T and N(p)=min{n:a_n>=p}, the inverse is

    N(p)=T/lambda
      +C lambda^(-4/3) T^(1/3)S^(2/3)
        sum_{j=0}^J P_j(kappa_inv+(7/3)log S)/S^j
      +o(T^(1/3)S^(2/3-J)),

where kappa_inv=kappa-(2/3)log(lambda). The proof differentiates only explicit
smooth approximants and uses monotonicity to bracket the exact integer inverse.

## What is proved and what remains open

The coefficient-to-action reduction now has a tunable error smaller than every
prescribed fixed inverse-log layer. It preserves complete positive rows,
repairs degree and height exactly, and uses an exact smooth convex-potential
calibration. Small-height and peak-endpoint estimates justify finite-order
termwise integration and duration inversion.

This is one all-finite-orders dominant sector of the logarithmic deficit.
It is not a multiplicative equivalent for a_n, a power-law prefactor, a
convergent infinite series, an exponentially complete transseries, a theorem
uniform in growing J, or a certified finite integer threshold. Every retained
error scale still tends to infinity. Independent mathematical research audits
are included; these are not journal peer review or proof-assistant certificates.
No additional literature-priority claim is made.

## Contents

- `a202061-allorders.pdf`: 20-page integrated mathematical report
- `a202061-allorders.tex`, `proofs/*-section.tex`: editable article sources
- `proofs/*.md`: unchanged reviewed mathematical source notes
- `checks/`: recurrence generator, independent P2 substitution, inverse scaling,
  hierarchy/error identities, and source/dependency pinning
- `audit/`: independent analytic and P3/P4 reviews, reproducible independent
  checks, exact proof hashes, integrated source/PDF signoff, and visual QA
- `dependency/third-order/`: unchanged approved third-order report, including
  its unchanged second-order, sharp-deficit, and positive-walk foundations
- `producer-replay.txt`: complete successful mathematical verification output
- `verification.md`: verification methods, limits, and clean-replay result
- `SHA256SUMS`: exact payload file set and SHA-256 hashes

The source notes retain historical draft qualifications. Their status is
superseded by the matching hash-bound analytic audit and integrated review.
The original scalar note labels P3/P4 as generated-only: the later independent
`audit/polynomial-audit.md` supplies the additional exact direct-substitution
check. Earlier reports retain their original scope statements unchanged.

## Reproduction

Requirements: Python 3, SymPy 1.14.0, mpmath 1.3.0, Bash and standard utilities.
The tested interpreter is Python 3.12.14. From this extracted directory run

    bash verify_all.sh

It checks the exact manifest (when present), every reviewed source, every byte
of the pinned third-order dependency, the recurrence through P4, the separate
P2 check, inverse/covariance identities, independent quadrature and exact P3/P4
checks, and the entire inherited verification chain. This takes a few minutes
on ordinary hardware. All active verification scripts resolve paths relative
to the extracted package. The original P3/P4 script is retained as provenance;
its portable copy changes only source-location reporting, and that limited
adaptation is itself checked exactly.

To generate further fixed orders, use

    python checks/generate_action_polynomials.py 5

Runtime grows rapidly with order. The theorem gives a finite algorithm, not
an efficient arbitrary-order complexity bound.

To rebuild the PDF with pdfLaTeX, Latin Modern, AMS fonts and standard LaTeX
packages installed, run

    bash build.sh

The build uses three passes, fixes the source date, and rejects overfull boxes
and unresolved references/citations. Exact PDF bytes may depend on the TeX
engine and font versions; the clean replay in the tested toolchain reproduces
the released PDF byte for byte. Local build, page-rendering and Python caches
are excluded from the release.

`make_release.py` requires current hash-bound integrated signoff, verifies the
reviewed source and dependency pins, and writes a deterministically ordered
ZIP with fixed timestamps and permissions. Its companion `.sha256` records
the archive checksum. The pinned third-order manifest is SHA256
`46235c0b3313375922cd4f0663e1e3bbb470a25384b9841caa5e827e691167a0`.
