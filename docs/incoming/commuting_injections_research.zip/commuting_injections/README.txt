RELATIONS AMONG COMMUTING INJECTIONS
Connected actions, exact enumeration, and Replacement

Research manuscript prepared for Vladimir Reshetnikov
4 October 2026

CONTENTS

commuting_injections.pdf   The complete article, with proofs, bibliography,
                          examples, and twelve further research questions.
commuting_injections.tex   Self-contained LaTeX source. The figure and
                          bibliography are embedded in this file.
verify_results.py         Reproducible exact finite checks; standard library only.
verification.json         The deterministic output of the verification program.
README.txt                This guide.

MAIN RESULTS

* A finite/countable/continuum classification of connected injective actions
  of finitely generated commutative monoids, computed from the group
  completion and the effective unit subgroup.
* Finite or continuum many types for each fixed localization stabilizer,
  and a continuously coded family of rigid components in higher rank.
* An exact presentation test with rational positive-circuit and integer
  unit certificates.
* Complete finite and infinite connected-type enumeration for f^m = g^n,
  including automorphism groups, defects, and finite-action generating functions.
* Sharp universal Replacement thresholds in the stated cardinal-kernel
  models, using the prior repository component-block criterion.
* Collection and reflection criteria, explicit counterexamples, and a
  characterization of when forcing adds new connected action types.

RESEARCH SETTING AND STATUS

The motivating sources are Elliot Glazer and Bokai Yao's Reflection
Principles in ZFU (arXiv:2602.21970) and the ProveIt report Naming Elementary
Embeddings, including Part II, Commuting Actions and Replacement.

The inspected ProveIt revision is:
715a716a3002b1e9f28daa2d81c009a392851b94

Repository-relative report path:
SetTheory/Cardinals/docs/reports/ordinals-and-order-types/naming-elementary-embeddings/article.tex

The article answers Question 23.3 of that revision for all finitely generated
commutative monoids and gives an effective answer to the related commutative
case of Question 23.5. Classical ingredients and prior repository results are
credited in the article. Historical priority is not established.

This is an AI-assisted research manuscript with ordinary mathematical proofs,
multiple internal proof reviews, and finite computational checks. It has not
been externally refereed or certified in a proof assistant. The finite checks
do not substitute for the infinite and foundational proofs.

BUILD THE PDF

With a standard TeX Live installation, run:

  latexmk -pdf commuting_injections.tex

Alternatively run the following command twice, or until references stabilize:

  pdflatex -interaction=nonstopmode -halt-on-error commuting_injections.tex

Required packages are standard LaTeX packages including amsmath, amsthm,
mathpazo, Latin Modern typewriter fonts, microtype, geometry, booktabs,
tabularx, longtable, enumitem, fancyhdr, TikZ, hyperref, and cleveref.
No external image files, bibliography processor, or shell escape are required.

RUN THE EXACT CHECKS

Python 3.10 or later, with no third-party packages:

  python verify_results.py

This writes verification.json next to the script. To keep the bundled output
and write a new result for comparison:

  python verify_results.py --output verification-rerun.json

The output is deterministic and records witnesses and individual outcomes.
All 148 cases passed in the supplied run:

  8 presentation/rank examples (8 positive circuits, 3 unit identities)
  36 weak-composition/necklace cases (1,709 compositions)
  24 finite-subgroup cases (3,759 candidate subsets)
  80 finite-permutation cases (9,888 pair/exponent checks)

Every check uses exact integers or fractions. The checks remain active when
Python is run with optimization enabled.
