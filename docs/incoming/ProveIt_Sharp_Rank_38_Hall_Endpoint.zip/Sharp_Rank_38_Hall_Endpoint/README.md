# A Sharp Rank 38 Boundary for the Last Hall Inequality

The report classifies the last actual-rank Newton gap for full Hall graphs with one common activity on the right core and all other vertex activities equal to one. The sharp first-failure rank is 38. It does not classify earlier gaps or arbitrary individual one-shore activities.

## Files

- `article.tex`, `article.pdf`: complete manuscript and rendered report
- `verify_boundary.py`: standard-library exact certificate and regression checks
- `verify_symbolic.py`: independent symbolic expansion checks using SymPy
- `data/rank_certificate.json`: all 2237 cubic values, finite-tail cutoffs, rank minima, and negative cases
- `data/verification.json`: exact witness populations, primitive quadratics, activity thresholds, and full-polynomial gap checks
- `build_local.sh`: TeX build script for the supplied environment
- `SHA256SUMS`: package file hashes

## Reproduce

Python 3.10 or newer:

    python verify_boundary.py

For the optional symbolic identity check, install SymPy from its standard package registry and run:

    python verify_symbolic.py

Both commands complete using exact integer/rational arithmetic. They do not access the network. Rebuild the report with a normal LaTeX installation by running `pdflatex article.tex` twice; `build_local.sh` supplies the local TeX format setup used for this package.

These are ordinary proofs with a reproducible finite arithmetic certificate, not a formal proof-assistant development. Global literature priority is not claimed.
