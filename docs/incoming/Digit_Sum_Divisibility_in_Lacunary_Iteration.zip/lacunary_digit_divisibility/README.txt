DIGIT-SUM DIVISIBILITY IN LACUNARY ITERATION
All prime powers, explicit first residues, finite automata, and p-adic iteration

Prepared for Vladimir Reshetnikov by OpenAI ChatGPT, October 5, 2026.

MAIN RESULT

Let F_p(x) = sum_{j >= 0} x^(p^j), let A_p(m,N) = [x^N] F_p^{compose m},
and let s_p(N) be the base-p digit sum. For every prime p and every integer
iterate m, including negative iterates, coefficients outside N = 1 mod (p-1)
vanish, while every supported degree N >= 1 satisfies

    v_p(A_p(m,N)) >= (s_p(N)-1)/(p-1).

The article proves this statement and a broader composition theorem, an
explicit first-residue formula for the second iterate, highest-digit
stability, three infinite sharp families, sparse-support and density-one
bounds, constructive automaticity for each fixed nonnegative iterate,
and a p-adic iteration group with sufficient coefficient periods.

The precise source question, prior results, and novelty boundaries are
documented in article.pdf and SOURCE_AUDIT.txt. Ten research questions
and proposed approaches are included in the article.

FILES

article.pdf                 Complete typeset article.
article.tex                 Complete LaTeX source, bibliography included.
SOURCE_AUDIT.txt            Exact repository pin and source provenance.
code/verify.py              Direct composition and independent Bell checks.
code/leading_residue.py     Sparse digit-polynomial residue algorithm.
code/cartier.py             Sparse Cartier representation and queries.
code/make_figure.py         Scientific figure from the supplied exact data.
data/                      Exact arithmetic verification receipts and data.
figures/valuation_grid.pdf  Vector figure required for LaTeX compilation.
figures/valuation_grid.png  Raster preview of that figure.

BUILD THE ARTICLE

From this directory, with a reasonably complete TeX Live installation:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

The bibliography is embedded: BibTeX is unnecessary. No shell escape,
network access, or Python execution is required to compile the article.
The supplied figure PDF is already complete.

REPRODUCE THE EXACT CHECKS

The three verification programs require Python 3.10 or newer and only the
standard library. Run from this directory:

    python3 code/verify.py --output data/verification.json \
        --heatmap data/valuation_grid.json
    python3 code/leading_residue.py \
        --verify data/leading_residue_verification.json
    python3 code/cartier.py --verify \
        --verification-output data/cartier_verification.json

Every arithmetic check uses exact integers or exact modular arithmetic.
The finite checks supplement the proofs; they do not establish statements
for all indices. Each JSON receipt describes its actual ranges and scope.

QUERY A FIRST RESIDUE

    python3 code/leading_residue.py --prime 3 --degree 51

The output is A_p(2,N)/p^w modulo p, where w=(s_p(N)-1)/(p-1), not the
full coefficient. A zero residue at a supported degree means additional
divisibility. For an unsupported degree, the coefficient is zero and the
reported weight is null. See --help for further options.

QUERY OR EXPORT A FIXED-ITERATE REPRESENTATION

    python3 code/cartier.py -p 2 -q 3 -m 2 -n 1125899906842630
    python3 code/cartier.py -p 2 -q 2 -m 3 -n 9 --export matrices.json

The first example uses N=2^50+6 and returns 4 modulo 8; the second
returns 2 modulo 4 and exports the transition matrices.
This computes A_p(m,N) modulo p^q for a fixed nonnegative iterate m.
Once built, the representation accepts arbitrarily large nonnegative
indices; setup can be expensive as p, q, or m grow. The program has
explicit resource guards and reports when a requested representation
exceeds them. See --help for the guard options. The theorem proves
existence without those implementation limits. Neither the code nor the
fixed-iterate theorem claims automaticity of the diagonal m=N.

REGENERATE THE FIGURE (OPTIONAL)

Install matplotlib and numpy, then run:

    python3 code/make_figure.py

The figure was generated with Python 3.12.14 and matplotlib 3.10.8.
Its data come from direct composition modulo 128; entries labeled 7+
mean valuation at least 7, including possible zero coefficients.

RESEARCH STATUS AND ATTRIBUTION

This is an AI-assisted research manuscript with complete arguments and
independent exact checks. It has not been peer reviewed or formally
verified. Claims of novelty are relative to the inspected sources, not
a guarantee of historical priority. The real-growth ratio conjecture for
A168362 remains open in this work. No OEIS submission or repository edit
was made.

Initial-term fixtures are credited to The Online Encyclopedia of Integer
Sequences, https://oeis.org/A168362, https://oeis.org/A168365, and
https://oeis.org/A168366. OEIS data are available under CC BY-SA 4.0:
https://creativecommons.org/licenses/by-sa/4.0/
https://oeis.org/wiki/The_OEIS_End-User_License_Agreement
