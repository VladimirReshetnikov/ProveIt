import DiophantineConsistency.ObjectPairingSurjective
import DiophantineConsistency.ObjectNaturalOrderedSemiring
import DiophantineConsistency.OrderedWindow

/-! # Sharp pairing is injective throughout the internal omega -/
noncomputable section
namespace DiophantineConsistency.MaxSquarePairing
variable {R : Type*} [CommSemiring R] [LinearOrder R] [CanonicallyOrderedAdd R]
  [IsStrictOrderedRing R]

def pair (a b : R) : R := if a<b then b*b+a else a*a+a+b

omit [IsStrictOrderedRing R] in
theorem max_square_le_pair (a b : R) :
    (max a b)*(max a b)≤pair a b := by
  by_cases h : a<b
  · simp only [pair,if_pos h,max_eq_right h.le]
    exact le_self_add
  · simp only [pair,if_neg h,max_eq_left (le_of_not_gt h)]
    exact le_self_add.trans le_self_add

theorem pair_lt_next_square (a b : R) :
    pair a b<(max a b+1)*(max a b+1) := by
  by_cases h : a<b
  · simp only [pair,if_pos h,max_eq_right h.le]
    have hb : b≤b+b := le_self_add
    have hb' : b+b≤b+b+1 := le_self_add
    have ha : a<b+b+1 := h.trans_le (hb.trans hb')
    calc
      b*b+a < b*b+(b+b+1) := by
        simpa only [add_comm] using add_lt_add_left ha (b*b)
      _ = (b+1)*(b+1) := by ring
  · simp only [pair,if_neg h,max_eq_left (le_of_not_gt h)]
    calc
      a*a+a+b ≤ a*a+a+a := by
        simpa only [add_comm] using add_le_add_left (le_of_not_gt h) (a*a+a)
      _ < a*a+a+a+1 := lt_add_of_pos_right _ zero_lt_one
      _ = (a+1)*(a+1) := by ring

variable (succ_le : ∀ a b : R,a<b → a+1≤b)
include succ_le

theorem pair_eq_pair_iff (a b c d : R) :
    pair a b=pair c d ↔ a=c ∧ b=d := by
  constructor
  · intro he
    have hm : max a b=max c d :=
      OrderedWindow.index_unique (fun x : R => x+1) (fun {x y} h => succ_le x y h)
        (fun x => x*x)
        (fun _ _ h => mul_le_mul h h (zero_le : (0 : R)≤_) (zero_le : (0 : R)≤_))
        (max_square_le_pair a b) (pair_lt_next_square a b)
        (by rw [he]; exact max_square_le_pair c d)
        (by rw [he]; exact pair_lt_next_square c d)
    by_cases hab : a<b <;> by_cases hcd : c<d
    · have hbd : b=d := by simpa only [max_eq_right hab.le,max_eq_right hcd.le] using hm
      subst d
      have hac : a=c := add_left_cancel (by
        simpa only [pair,if_pos hab,if_pos hcd] using he)
      exact ⟨hac,rfl⟩
    · have hbc : b=c := by
        simpa only [max_eq_right hab.le,max_eq_left (le_of_not_gt hcd)] using hm
      subst c
      have hae : a=b+d := add_left_cancel (a := b*b) (by
        simpa only [pair,if_pos hab,if_neg hcd,add_assoc] using he)
      have hba : b≤a := by rw [hae]; exact le_self_add
      exact False.elim (hab.not_ge hba)
    · have had : a=d := by
        simpa only [max_eq_left (le_of_not_gt hab),max_eq_right hcd.le] using hm
      subst d
      have hce : c=a+b := add_left_cancel (a := a*a) (by
        simpa only [pair,if_neg hab,if_pos hcd,add_assoc] using he.symm)
      have hac : a≤c := by rw [hce]; exact le_self_add
      exact False.elim (hcd.not_ge hac)
    · have hac : a=c := by
        simpa only [max_eq_left (le_of_not_gt hab),max_eq_left (le_of_not_gt hcd)] using hm
      subst c
      exact ⟨rfl,add_left_cancel (by
        simpa only [pair,if_neg hab,if_neg hcd] using he)⟩
  · rintro ⟨rfl,rfl⟩
    rfl

end DiophantineConsistency.MaxSquarePairing

namespace DiophantineConsistency.ObjectPairingInjective
open SetTheory ObjectOmegaSemiring
universe u
variable {V : Type u} {mem : V → V → Prop}
variable (H : ZFAxioms mem)
abbrev N := Natural H

theorem pair_eq_pair_iff (a b c d : N H) :
    ObjectNatPairing.pair H a b=ObjectNatPairing.pair H c d ↔ a=c ∧ b=d := by
  apply MaxSquarePairing.pair_eq_pair_iff (R := N H)
  intro x y h
  obtain ⟨s,hs⟩ := (ObjectNaturalDiscrete.lt_iff_exists_add_one H x y).mp h
  exact (ObjectNaturalOrder.Natural.le_iff_exists_add H _ _).mpr ⟨s,by rw [hs]; ac_rfl⟩

end DiophantineConsistency.ObjectPairingInjective
