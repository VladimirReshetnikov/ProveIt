#!/usr/bin/env python3
"""Rebuild U212 by the exact two-row patch; no search or solver is used."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PARENT_SHA = 'bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7'
NATIVE_SHA = '386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4'
DENSE_SHA = 'c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e'
SOURCE_SHA = '7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00'

def need(ok, message):
    if not ok:
        raise ValueError(message)

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def parse(raw):
    table, starts = {}, []
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
        if not line or line.startswith('#'):
            continue
        q, b, w, d, z = line.split()
        q, b, w, z = map(int, (q, b, w, z))
        need(q >= 0 and z >= 0 and b in (0, 1) and w in (0, 1), 'Row domain')
        need(d in ('L', 'R') and (q, b) not in table, 'Bad or duplicate row')
        table[q, b] = (w, 1 if d == 'R' else -1, z)
    need(starts == [0], 'Expected exactly one start declaration for state0')
    return table

def encode(table):
    return ('#! start 0\n' + ''.join(
        f'{q} {b} {w} {"R" if d == 1 else "L"} {z}\n'
        for (q, b), (w, d, z) in sorted(table.items()))).encode('ascii')

def validate(table, count, halt):
    states = {q for q, _ in table}
    need(len(states) == count and len(table) == 2 * count, 'Wrong census')
    need(set(table) == {(q, b) for q in states for b in (0, 1)}, 'Partial table')
    need(0 in states and halt not in states, 'Start/halt convention')
    need({z for _, _, z in table.values()} - states == {halt}, 'Target closure')
    seen, queue = {0}, [0]
    for q in queue:
        for b in (0, 1):
            z = table[q, b][2]
            if z != halt and z not in seen:
                seen.add(z)
                queue.append(z)
    need(seen == states, 'Unreachable state in transition graph')
    return states

def build(output=None):
    parent = ROOT / 'inputs/parent_u213.native.tm'
    need(digest(parent) == PARENT_SHA, 'Parent identity')
    table = parse(parent.read_bytes())
    validate(table, 213, 254)
    need(table[180, 1] == (1, 1, 172), 'Wrong bypass input')
    need(table[172, 0] == (0, -1, 112), 'Wrong deletion input')
    table[180, 1] = (1, 1, 211)
    intermediate = encode(table)
    table[172, 0] = (0, -1, 67)
    del table[112, 0]
    del table[112, 1]
    states = validate(table, 212, 254)
    native = encode(table)
    mapping = {q: i for i, q in enumerate(sorted(states))}
    mapping[254] = 212
    inverse = {v: k for k, v in mapping.items()}
    need(len(inverse) == 213, 'Nonbijective state map')
    dense_table = {(mapping[q], b): (w, d, mapping[z])
                   for (q, b), (w, d, z) in table.items()}
    validate(dense_table, 212, 212)
    dense = encode(dense_table)
    need({(inverse[q], b): (w, d, inverse[z])
          for (q, b), (w, d, z) in dense_table.items()} == table, 'Inverse relabel')
    need(hashlib.sha256(native).hexdigest() == NATIVE_SHA, 'Native identity')
    need(hashlib.sha256(dense).hexdigest() == DENSE_SHA, 'Dense identity')
    need(digest(ROOT / 'machine/sites.json') == SOURCE_SHA, 'Source identity')
    need(native == (ROOT / 'machine/u212.native.tm').read_bytes(), 'Delivered native')
    need(dense == (ROOT / 'machine/u212.tm').read_bytes(), 'Delivered dense')
    need(intermediate == (ROOT / 'inputs/bypass213.native.tm').read_bytes(), 'Intermediate')
    delivered_map = json.loads((ROOT / 'machine/state_map.json').read_text())
    if 'native_to_dense' in delivered_map:
        delivered_map = delivered_map['native_to_dense']
    need({int(k): v for k, v in delivered_map.items()} == mapping, 'Delivered state map')
    receipt = dict(status='EXACT_U212_RECONSTRUCTION_PASS', working_states=212,
                   transition_rows=424, start=0, halt=212, native_halt=254,
                   all_working_states_graph_reachable=True,
                   parent_sha256=PARENT_SHA, native_sha256=NATIVE_SHA,
                   dense_sha256=DENSE_SHA, source_sha256=SOURCE_SHA,
                   changed_retained_rows=2, deleted_native_states=[112],
                   added_states=[], exact_bijection=True)
    if output:
        output.mkdir(parents=True, exist_ok=True)
        (output / 'u212.native.tm').write_bytes(native)
        (output / 'u212.tm').write_bytes(dense)
        (output / 'construction.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return receipt

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    print(json.dumps(build(args.output), indent=2))
