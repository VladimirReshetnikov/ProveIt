U212: combining two compatible reductions for Con(PA)
====================================================
Research prepared for Vladimir Reshetnikov, 28 October 2026.

RESULT
------
machine/u212.tm is the exact accepted candidate: 212 working states,
424 transitions, two symbols, one two-way infinite tape, all-zero input,
start state 0/head coordinate 0, L/R moves only, and separate halt label 212.
Working states are 0 through 211. Blank initialization is included.

The mathematical local reduction proves, in a form formalizable in PA:

  Halt(U212, blank) <-> Halt(direct-transfer U213, blank).

Together with the explicitly retained parent source/calculus calibration
and unary-theory interpretation arguments, this gives:

  PA |- not Halt(U212, blank) <-> Con(U) <-> Con(PA).

This packet contains a mathematical proof, two independently implemented
finite local checkers, and freshly rederived unbounded symbolic runtime
contracts. It is not a newly compiled Lean, Rocq, MM0, or exported PA
endpoint certificate. The fixed K215/ZFC certificate concerns another table.
No unconditional consistency/nonhalting, priority, or minimality is asserted.

THE SUCCESSFUL COMBINATION
-------------------------
Parent A: U213_ConPA_2026-10-28 (1).zip
  Direct-transfer source, U214 role-a emitter, repaired arithmetic entrance,
  seven-zero origin detector; 3,909 primitive instructions / 197 subtrees.

Donor H: u213_from_u214_2026-10-28.zip
  Bypass one incoming path to state 172, then delete return helper 112
  under a stronger preceding-zero invariant.

The decoder called 167 in H's parent is present in A under label 211.
The exact new native patch is:

  180 1 1 R 172  ->  180 1 1 R 211
  172 0 0 L 112  ->  172 0 0 L 67

Delete both rows sourced at native 112. No other retained row changes,
no state is added, and the source is unchanged. The native halt is 254;
machine/state_map.json gives the dense relabeling.

Four arbitrary-exterior path identities preserve the complete tape and
final head/state. The incoming-row census proves the needed invariant
on every run from state 0, without a blank-input assumption. Direct
positive block synchronization proves halting equivalence and, on every
common halting input, T212 <= T213 <= (7/3) T212.

VALIDATION
----------
- All eight 213-state proposals structurally compared against one U214.
- Two local checkers pass; five deliberately damaged controls rejected.
- All 5,084 guarded primitive contracts freshly reconstructed for U212.
- All 424 literal rows covered; 1,275,761 symbolic inference applications.
- Arbitrary natural primary registers/gap and arbitrary finite spare tails,
  using unary/list induction; these are not small-register simulations.
- Exact 48,140-step blank startup, full tape support and zero exterior.
- Neither edited row is visited during that initializer.
- The initializer reaches an interior AX frame. The inherited suffix builds
  nine theorem heads over tail 4; exact scheduler debt 2 leaves margin 7.
- Parent A's full finite reconstruction/source/startup audit and inherited
  U214/U218 audit freshly replayed. Historical runtime replays are optional.

OFFLINE REPRODUCTION
--------------------
Use Python 3.10+ on Linux or WSL, standard library only, assertions enabled.
The sealed replay was tested on Linux. From this directory:

  python3 -B reproduce.py
  python3 -B reproduce.py --full --report /tmp/u212-replay.json

The default reconstructs tables, verifies all SHA256SUMS entries, checks
both local proofs, recomputes the eight-way comparison, replays startup,
audits the saved symbolic records and runs the complete parent finite audit.
--full additionally regenerates every U212 symbolic derivation and compares
all case records. --parent-full additionally regenerates the parent's
5,084 runtime cases. Reproduction needs no network or external solver.
Temporary work is removed. Only a requested --report is written persistently.
The unchanged historical parent compares generated text bytes against LF
originals; native Windows newline conversion is not supported by that replay.

Do not use -O or PYTHONOPTIMIZE for reproduce.py or the symbolic engine.
The independent local checker uses explicit exceptions and also works with -O.

All kernel-independent validation is reproducible. A fresh full symbolic
run took about two minutes on the preparation host; actual timing varies.
The optional C++ searches under research/local_search are discovery evidence,
not dependencies of the accepted proof or of reproduce.py.

FILES
-----
paper/report.tex and report.pdf  Full report, proofs, comparison and full table.
paper/transition_table.tex       Generated exact dense transition-table appendix.
machine/                        Native/dense tables, map, source, summary.
code/                           Builder and portable proof/structural checkers.
evidence/                       All runtime case records and validation receipts.
comparison/                     Exact source/table snapshots of eight proposals.
inputs/direct_transfer_U213.zip  Unchanged parent A and its complete dependencies.
inputs/bypass_U213.zip           Unchanged donor H and original bypass argument.
research/                       Independent audit and limited negative searches.
licenses/, NOTICE.txt            Attribution and retained licenses.
SHA256SUMS                      Integrity manifest for every other release file.

The symbolic engine uses legacy labels distinct from native machine labels;
inputs/legacy_mapping.json binds them. For example, a legacy list-lemma
entry called 112 is not the deleted native state 112.

To rebuild the PDF, use a copy of the package:

  python3 -B code/build_paper_data.py
  cd paper
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

TeX timestamps and versions can change PDF bytes. Editing a sealed file
invalidates SHA256SUMS; retain the original extraction for auditing.

PRIMARY IDENTITIES (SHA-256)
---------------------------
Dense:
c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e
Native:
386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4
Source:
7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00

Inputs frozen at ProveIt commit:
6b3145c0bbbf7563bd7bce44c974b4515656a5b0

Eight-way comparison and further research found no accepted 211-state
machine. Its absence here is not a lower bound. The exact E/G rotation
recipes conflict with the extra bypass entry into helper 211; different
allocations or stronger invariants remain open.
