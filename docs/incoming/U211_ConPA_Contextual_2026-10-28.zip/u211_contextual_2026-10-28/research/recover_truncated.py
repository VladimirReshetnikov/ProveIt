from pathlib import Path
import struct
import zlib
import json

root = Path('sources')
archive = root / 'U212_ConPA_Stacked_2026-10-28 (5).zip'
dest = root / 'U212_ConPA_Stacked_2026-10-28_5_recovered'
data = archive.read_bytes()
offset = 0
recovered = []
while offset + 30 <= len(data) and data[offset:offset+4] == b'PK\x03\x04':
    _, version, flags, method, time, date, crc, csize, usize, nlen, xlen = struct.unpack_from('<IHHHHHIIIHH', data, offset)
    name = data[offset+30:offset+30+nlen].decode('utf-8')
    start = offset + 30 + nlen + xlen
    end = start + csize
    if end > len(data):
        print('Incomplete final member:', name, 'available', len(data)-start, 'needed', csize)
        break
    if flags & 8:
        raise ValueError('Cannot recover descriptor entries')
    try:
        raw = zlib.decompress(data[start:end], -15) if method == 8 else data[start:end]
    except zlib.error as exc:
        print('Incomplete compressed member:', name, str(exc))
        break
    assert len(raw) == usize and zlib.crc32(raw) == crc
    path = dest / name
    assert path.resolve().is_relative_to(dest.resolve())
    if not name.endswith('/'):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        recovered.append({'name': name, 'size': usize, 'crc32': crc})
    offset = end
dest.mkdir(exist_ok=True)
(dest/'recovery.json').write_text(json.dumps({'archive':str(archive),'bytes':len(data),'last_intact_offset':offset,'members':recovered},indent=2)+'\n')
print('Recovered', len(recovered), 'CRC-verified members')
