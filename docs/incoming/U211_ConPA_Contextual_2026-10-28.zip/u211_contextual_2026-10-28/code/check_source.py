#!/usr/bin/env python3
"""Independent source parsing and ordinal control-flow comparison."""
import argparse
import bisect
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def need(ok, message):
    if not ok:
        raise ValueError(message)

def analyze(rows):
    names = [r[0] for r in rows]
    need(names == sorted(set(names)), 'Noncanonical addresses')
    lookup = {p: (i, op, arg) for i, (p, op, arg) in enumerate(rows)}
    intervals = {}
    nodes = set()
    def tree(p):
        if p in lookup:
            i, op, arg = lookup[p]
            node, interval = (op, arg), (i, i+1)
        else:
            need(any(x.startswith(p) for x in names), 'Missing branch')
            left, li = tree(p+'0')
            right, ri = tree(p+'1')
            need(li[1] == ri[0], 'Noncontiguous leaves')
            node, interval = (left, right), (li[0], ri[1])
        intervals[p] = interval
        nodes.add(node)
        return node, interval
    _, extent = tree('')
    need(extent == (0, len(rows)), 'Incomplete tree')
    def cut(pc, bit, count):
        need(isinstance(count, int) and count >= 0, 'Bad branch count')
        if count == 0:
            return pc
        for j in range(len(pc)-1, -1, -1):
            if pc[j] == bit:
                count -= 1
                if count == 0:
                    return pc[:j]
        return ''
    def increment(pc):
        n = len(pc)
        if not n:
            return ''
        return format((int(pc, 2)+1) % (1 << n), '0'+str(n)+'b')
    def decode(pc):
        # Missing suffix bits are zero; this models the physical zero padding.
        p = ''
        while p not in lookup:
            p += pc[len(p)] if len(p) < len(pc) else '0'
            need(p in intervals, 'Stray program counter')
        need(len(p) >= len(pc) or set(pc[len(p):]) <= {'0'}, 'Nonzero stray suffix')
        return lookup[p][0]
    arithmetic, interval_graph = [], []
    for i, (pc, op, arg) in enumerate(rows):
        need(op in ('CI', 'CD', 'CB', 'CC', 'CH'), 'Unknown opcode')
        if op in ('CI', 'CD'):
            need(isinstance(arg, int) and 0 <= arg < 9, 'Register operand')
        if op == 'CI':
            aa, bb = (decode(increment(pc)),), ((i+1) % len(rows),)
        elif op == 'CH':
            need(arg is None, 'Halt operand')
            aa = bb = ()
        elif op == 'CC':
            pre = cut(pc, '1', arg)
            aa, bb = (decode(pre),), (intervals[pre][0],)
        else:
            count = 1 if op == 'CD' else arg
            positions = [j for j, bit in enumerate(pc) if bit == '0']
            need(len(positions) >= count and count > 0, 'Escaping forward branch')
            ancestor = pc[:positions[-count]]
            zero_a = decode(increment(cut(pc, '0', count)))
            zero_b = intervals[ancestor][1] % len(rows)
            aa, bb = (zero_a,), (zero_b,)
            if op == 'CD':
                aa += (decode(increment(pc)),)
                bb += ((i+1) % len(rows),)
        need(aa == bb, 'Independent CFG resolvers disagree')
        arithmetic.append((op, arg, aa))
        interval_graph.append((op, arg, bb))
    return dict(graph=arithmetic, source_primitives=len(rows), dag_nodes=len(nodes),
                maximum_depth=max(map(len, names)),
                maximum_zero_run=max(len(z) for p in names for z in p.split('1')),
                control_edges=sum(len(x[2]) for x in arithmetic),
                guarded_cases=sum(2 if op == 'CD' else 1 for pc, op, arg in rows))

def check(parent_path, candidate_path):
    parent = json.loads(Path(parent_path).read_text())
    candidate = json.loads(Path(candidate_path).read_text())
    a, b = analyze(parent), analyze(candidate)
    need([r[1:] for r in parent] == [r[1:] for r in candidate], 'Primitive order/operands')
    need(a['graph'] == b['graph'], 'Ordinal transition semantics changed')
    need(all(a[k] == b[k] for k in b if k != 'graph'), 'Source metrics changed')
    need(candidate[136] == parent[136], 'Calibrated startup instruction changed')
    return dict(status='PASS', **{k: v for k, v in b.items() if k != 'graph'},
                complete_ordinal_cfg_equal=True, independent_resolvers_agree=True,
                changed_address_count=sum(a[0] != b[0] for a, b in zip(parent, candidate)),
                source_sha256=hashlib.sha256(Path(candidate_path).read_bytes()).hexdigest())

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path)
    a = p.parse_args()
    result = check(ROOT/'baseline/sites.json', ROOT/'machine/sites.json')
    if a.output:
        a.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
