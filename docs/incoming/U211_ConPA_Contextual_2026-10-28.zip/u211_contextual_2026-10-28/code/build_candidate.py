#!/usr/bin/env python3
"""Deterministically reconstruct U211 from the literal common U212 parent.

No search or optimizer. The six source rotations preserve closed sequential
factors. The engine entry repair and final guarded fold require the stated
local proofs, which are separate from the source graph checks performed here.
"""
import argparse
import hashlib
import json
from pathlib import Path
import source_language as L

PARENT_NATIVE_SHA256 = '386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4'
PARENT_SOURCE_SHA256 = '7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00'
ROTATIONS = [(216,220,1),(204,216,0),(216,163,1),(206,199,1),(205,206,1),(7,205,1)]

def need(condition, message):
    if not condition:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def parse(raw):
    table = {}
    starts = []
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
        if not line or line.startswith('#'):
            continue
        q,b,w,d,z = line.split()
        q,b,w,z = map(int,(q,b,w,z))
        need((q,b) not in table and b in (0,1) and w in (0,1) and d in ('L','R'), 'Row syntax')
        table[q,b] = (w,d,z)
    need(starts == [0], 'Start convention')
    return table

def encode(table):
    return ('#! start 0\n' + ''.join(
        f'{q} {b} {w} {d} {z}\n' for (q,b),(w,d,z) in sorted(table.items()))).encode('ascii')

def validate(table, count, halt):
    states = {q for q,b in table}
    need(len(states) == count and set(table) == {(q,b) for q in states for b in (0,1)}, 'Census')
    need(0 in states and halt not in states and {z for w,d,z in table.values()} - states == {halt}, 'Closure')
    todo = [0]
    seen = {0}
    for q in todo:
        for b in (0,1):
            z = table[q,b][2]
            if z not in seen and z != halt:
                seen.add(z)
                todo.append(z)
    need(seen == states, 'Graph reachability')
    return states

def occurrences(root, table, target):
    found = []
    def visit(node, q, path):
        if q == target:
            found.append((path,node))
            return
        if L.leaf(node):
            return
        for b in (0,1):
            w,d,z = table[q,b]
            if (w,d) == (b,'R'):
                visit(node[b],z,path+str(b))
    visit(root,84,'')
    return found

def leaf_count(node):
    return 1 if L.leaf(node) else leaf_count(node[0])+leaf_count(node[1])

def build(parent_table, parent_source, output):
    raw = Path(parent_table).read_bytes()
    source_raw = Path(parent_source).read_bytes()
    need(sha(raw) == PARENT_NATIVE_SHA256, 'Parent table hash')
    need(sha(source_raw) == PARENT_SOURCE_SHA256, 'Parent source hash')
    table = parse(raw)
    validate(table,212,254)
    parent = table.copy()
    original_rows = json.loads(source_raw)
    original_graph = L.graph_intervals(original_rows)
    need(L.graph_arithmetic(original_rows)[0] == original_graph, 'Parent CFG resolvers')
    root = L.tree(original_rows)
    recipe = []
    for p,q,side in ROTATIONS:
        places = occurrences(root,table,p)
        need(places and len({node for path,node in places}) == 1, 'Outer source occurrences')
        need(table[p,side] == (side,'R',q), 'Rotation child')
        incoming = [(r,b,w,d) for (r,b),(w,d,z) in table.items() if z == q]
        need(incoming == [(p,side,side,'R')], 'Inner has another incoming edge')
        need(all(table[r,b][:2] == (b,'R') for r in (p,q) for b in (0,1)), 'Pure decoders')
        node = places[0][1]
        if side == 0:
            A,B = node[0]
            C = node[1]
            replacement = (A,(B,C))
            a,b,c = table[q,0][2],table[q,1][2],table[p,1][2]
            table[p,0],table[p,1] = (0,'R',a),(1,'R',q)
            table[q,0],table[q,1] = (0,'R',b),(1,'R',c)
        else:
            A = node[0]
            B,C = node[1]
            replacement = ((A,B),C)
            a,b,c = table[p,0][2],table[q,0][2],table[q,1][2]
            table[p,0],table[p,1] = (0,'R',q),(1,'R',c)
            table[q,0],table[q,1] = (0,'R',a),(1,'R',b)
        need(all(L.boundary(x) == (0,0,False) for x in (A,B,C)), 'Nonclosed factor')
        for path,node in places:
            root = L.replace(root,path,replacement)
        rows = L.sites(root)
        need([r[1:] for r in rows] == [r[1:] for r in original_rows], 'Primitive word changed')
        need(L.graph_intervals(rows) == original_graph, 'Interval CFG changed')
        need(L.graph_arithmetic(rows)[0] == original_graph, 'Arithmetic CFG changed')
        recipe.append(dict(outer=p,inner=q,side=side,paths=[p for p,n in places],
                           factor_sizes=[leaf_count(x) for x in (A,B,C)]))
    # Protect the non-decoder entry that originally used native 7.
    need(table[171,0] == (0,'L',7), 'Engine entry before repair')
    table[171,0] = (0,'L',205)
    prefold = table.copy()
    need(table[163,0] == (0,'R',90) and table[180,0] == (0,'R',152), 'Fold branches')
    need(table[163,1] == table[180,1] == (1,'R',211), 'Common fold branch')
    need([(k,v) for k,v in table.items() if v[2] == 163] == [((216,0),(0,'R',163))], 'Zero tag')
    need([(k,v) for k,v in table.items() if v[2] == 180] ==
         [((132,1),(1,'R',180)),((199,1),(1,'R',180))], 'One tag')
    for key,(w,d,z) in list(table.items()):
        if z == 180:
            table[key] = (w,d,163)
    del table[180,0]
    del table[180,1]
    table[163,0] = (0,'L',211)
    states = validate(table,211,254)
    mapping = {q:i for i,q in enumerate(sorted(states))}
    mapping[254] = 211
    dense = {(mapping[q],b):(w,d,mapping[z]) for (q,b),(w,d,z) in table.items()}
    validate(dense,211,211)
    source_out = (json.dumps(rows,separators=(',',':'))+'\n').encode('ascii')
    native_out,dense_out = encode(table),encode(dense)
    summary = dict(working_states=211,transition_rows=422,start=0,halt=211,native_halt=254,
                   metrics=L.metrics(root),rotations=recipe,engine_repair=[171,0,0,'L',205],
                   fold=dict(keep=163,delete=180,selector=211,changed_row=[163,0,0,'L',211]),
                   parent_native_sha256=sha(raw),parent_source_sha256=sha(source_raw),
                   native_sha256=sha(native_out),dense_sha256=sha(dense_out),source_sha256=sha(source_out),
                   changed_retained_rows=sum(parent[k] != v for k,v in table.items()),
                   source_control_edges=sum(len(x[1]) for x in original_graph),
                   scope='Construction, source CFG conjugacy, and finite table facts; universal runtime, startup, and inherited consistency calibration are separate obligations.')
    output = Path(output)
    output.mkdir(parents=True,exist_ok=True)
    (output/'u211.native.tm').write_bytes(native_out)
    (output/'u211.tm').write_bytes(dense_out)
    (output/'rotated212.native.tm').write_bytes(encode(prefold))
    (output/'sites.json').write_bytes(source_out)
    (output/'state_map.json').write_text(json.dumps(dict(native_to_dense=mapping,dense_to_native={v:k for k,v in mapping.items()}),indent=2)+'\n')
    (output/'construction.json').write_text(json.dumps(summary,indent=2)+'\n')
    return summary

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('parent_table',type=Path)
    parser.add_argument('parent_source',type=Path)
    parser.add_argument('output',type=Path)
    args = parser.parse_args()
    print(json.dumps(build(args.parent_table,args.parent_source,args.output),indent=2))
