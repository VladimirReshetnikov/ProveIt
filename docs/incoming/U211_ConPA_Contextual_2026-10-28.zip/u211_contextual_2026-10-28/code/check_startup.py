from pathlib import Path
import json, hashlib, argparse

def parse(path):
    table={}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'): continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
        if (q,b)in table:raise ValueError('duplicate row')
        table[q,b]=(w,1 if d=='R'else -1,z)
    return table

def run(table,n):
    ones=set();q=h=0;trace=hashlib.sha256();visits=set()
    for i in range(n):
        b=int(h in ones);w,d,z=table[q,b];visits.add((q,b))
        trace.update((json.dumps([i,q,h,b,w,d,z],separators=(',',':'))+'\n').encode())
        if w:ones.add(h)
        else:ones.discard(h)
        q,h=z,h+d
    return(q,h,ones),trace.hexdigest(),visits

def graph(rows):
    lookup={p:i for i,(p,o,a)in enumerate(rows)};bounds={}
    def walk(p):
        if p in lookup:out=lookup[p],lookup[p]+1
        else:
            a,b=walk(p+'0'),walk(p+'1')
            assert a[1]==b[0]
            out=a[0],b[1]
        bounds[p]=out
        return out
    assert walk('')==(0,len(rows))
    def jump(p,b,n):
        for j in range(len(p)-1,-1,-1):
            if p[j]==b:
                n-=1
                if n==0:return bounds[p[:j]][int(b=='0')]%len(rows)
        return 0
    ret=[]
    for i,(p,o,a)in enumerate(rows):
        nxt=(i+1)%len(rows)
        ret.append([jump(p,'0',1),nxt]if o=='CD'else[jump(p,'0',a)]if o=='CB'else[jump(p,'1',a)]if o=='CC'else[nxt]if o=='CI'else[])
    return ret

def check(baseline_path,candidate_path,source_path):
    A,B=map(parse,(baseline_path,candidate_path));C,ha,used_a=run(A,48140);D,hb,used_b=run(B,48140)
    assert C==D,'startup whole-tape endpoint changed'
    assert ha==hb,'startup transition trace changed'
    assert C[:2]==(84,-2)
    changed={k for k in set(A)|set(B)if A.get(k)!=B.get(k)}
    assert not(used_a&changed),'startup touches edited rows'
    rows=json.loads(source_path.read_text());assert rows[136][0]=='001100110101010'
    R=[1,0,13,0,0,1,0,0,1];phy=(6,2,0,4,3,7,8,5,1);phys=[0]*9
    for i,j in enumerate(phy):phys[j]=R[i]
    want={-3,54}|{-2+i for i,c in enumerate(rows[136][0])if c=='1'};pos=55
    for n in phys+[1]*43:
        want.update(range(pos+1,pos+n+2));pos+=n+2
    assert C[2]==want
    g=graph(rows);regs=[1,0,4,0,0,1,0,0,1];ip=106;source_trace=[]
    for t in range(141):
        prior=(ip,regs.copy());p,o,a=rows[ip]
        if o=='CI':regs[a]+=1;ip=g[ip][0]
        elif o=='CD':positive=regs[a]>0;regs[a]-=int(positive);ip=g[ip][int(positive)]
        elif o in('CB','CC'):ip=g[ip][0]
        else:raise ValueError('unexpected halt')
        source_trace.append([*prior,ip,regs.copy()])
    assert(ip,regs)==(136,R)
    return {'status':'PASS','candidate_sha256':hashlib.sha256(candidate_path.read_bytes()).hexdigest(),
      'source_sha256':hashlib.sha256(source_path.read_bytes()).hexdigest(),'literal_steps':48140,
      'state':84,'head':-2,'header':54,'header_distance':56,'source_ordinal':136,
      'source_address':rows[136][0],'logical_registers':R,'spares':[1]*43,
      'complete_tape_one_cells':sorted(want),'zero_exterior':True,
      'trace_sha256':ha,'trace_identical_to_U212':True,'changed_row_visits':0,
      'source_seed_ordinal':106,'source_seed':[1,0,4,0,0,1,0,0,1],
      'source_prefix_steps':141,'source_prefix_trace':source_trace,
      'scope':'Exact finite startup and corresponding source prefix only; full runtime and logical calibration separate.'}
if __name__=='__main__':
    if not __debug__:raise RuntimeError('Run with assertions enabled')
    p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('candidate',type=Path);p.add_argument('source',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    r=check(a.baseline,a.candidate,a.source);a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k not in('complete_tape_one_cells','spares','source_prefix_trace')},indent=2))
