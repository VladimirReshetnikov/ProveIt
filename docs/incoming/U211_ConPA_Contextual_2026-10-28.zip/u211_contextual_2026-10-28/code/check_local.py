#!/usr/bin/env python3
"""Independent exact local proofs over arbitrary, unread tape exteriors.

Uses no builder, source compiler, symbolic runtime, or saved PASS flag.
All six local branches are exhaustive by their explicitly specified bits.
"""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def need(ok, message):
    if not ok:
        raise ValueError(message)

def read(path, count):
    table, starts = {}, []
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
        if not line or line.startswith('#'):
            continue
        q, b, w, direction, target = line.split()
        q, b, w, target = map(int, (q, b, w, target))
        need(q >= 0 and target >= 0 and b in (0, 1) and w in (0, 1), 'Row domain')
        need(direction in ('L', 'R') and (q, b) not in table, 'Row syntax')
        table[q, b] = w, (-1 if direction == 'L' else 1), target
    states = {q for q, b in table}
    need(starts == [0] and 0 in states and 254 not in states, 'Start/halt')
    need(len(states) == count and len(table) == 2 * count, 'State census')
    need(set(table) == {(q, b) for q in states for b in (0, 1)}, 'Completeness')
    need({t for w, d, t in table.values()} - states == {254}, 'Target closure')
    return table

def execute(table, state, cells, steps):
    tape = dict(cells)
    head = 0
    trace = []
    for _ in range(steps):
        need(state != 254, 'Internal halt')
        need(head in tape, 'Unspecified exterior cell read')
        old = tape[head]
        w, d, z = table[state, old]
        trace.append([state, head, old, w, d, z])
        tape[head] = w
        head, state = head + d, z
    return (state, head, tape), trace

def path_identity(old, new, old_state, new_state, cells, n, m, endpoint, name):
    need(n > 0 and m > 0, 'Zero-length simulation')
    a, pa = execute(old, old_state, cells, n)
    b, pb = execute(new, new_state, cells, m)
    need(a == b, name + ': unequal state, head, or whole local tape')
    need(a[:2] == endpoint and a[2] == cells, name + ': wrong endpoint/tape')
    return dict(name=name, cells=cells, old_start=old_state, new_start=new_state,
                old_steps=n, new_steps=m, endpoint=endpoint, old_path=pa, new_path=pb,
                exterior_unread=True, entire_tape_unchanged=True)

def fold_premises(rotated, child):
    need(set(rotated) - set(child) == {(180, 0), (180, 1)}, 'Deleted rows')
    need(not set(child) - set(rotated), 'Added rows')
    need({k for k in child if child[k] != rotated[k]} ==
         {(132, 1), (199, 1), (163, 0)}, 'Fold row delta')
    need(sorted(k for k, a in rotated.items() if a[2] == 163) == [(216, 0)],
         'Complete incoming census for zero-tag state')
    need(rotated[216, 0] == (0, 1, 163), 'Zero tag is not produced')
    need(sorted(k for k, a in rotated.items() if a[2] == 180) ==
         [(132, 1), (199, 1)], 'Complete incoming census for one-tag state')
    need(all(rotated[k] == (1, 1, 180) for k in [(132, 1), (199, 1)]),
         'One tag is not produced')
    need(all(a[2] != 180 for a in child.values()), 'Deleted state still targeted')
    need(rotated[163, 0] == (0, 1, 90) and rotated[180, 0] == (0, 1, 152),
         'Distinct zero branches')
    need(rotated[163, 1] == rotated[180, 1] == (1, 1, 211), 'Shared one branch')
    need(child[163, 0] == (0, -1, 211), 'Selector entry')
    # Check the complete quotient relation for all other rows, not just the edits.
    rho = lambda q: 163 if q == 180 else q
    for (q, b), (w, d, z) in rotated.items():
        if q in (163, 180):
            continue
        need(child[rho(q), b] == (w, d, rho(z)), 'Other row breaks quotient')

def fold_paths(rotated, child):
    cases = []
    for old_state, tag, zero_target in [(163, 0, 90), (180, 1, 152)]:
        for bit in (0, 1):
            cells = {-1: tag, 0: bit}
            cases.append(path_identity(rotated, child, old_state, 163, cells,
                         1, 3 if bit == 0 else 1,
                         (zero_target if bit == 0 else 211, 1),
                         f'fold_state{old_state}_read{bit}'))
    return cases

def repair_paths(parent, rotated):
    cases = []
    for left in (0, 1):
        n = 2 + left
        cases.append(path_identity(parent, rotated, 171, 171, {-1: left, 0: 0},
                     n, n, (86, 0) if left == 0 else (164, 1),
                     f'engine_repair_left{left}'))
    return cases

def check(parent_path, rotated_path, child_path):
    parent = read(parent_path, 212)
    rotated = read(rotated_path, 212)
    child = read(child_path, 211)
    fold_premises(rotated, child)
    paths = repair_paths(parent, rotated) + fold_paths(rotated, child)
    mutations = [
        ('selector_wrong_direction', (163, 0), (0, 1, 211)),
        ('selector_wrong_write', (163, 0), (1, -1, 211)),
        ('selector_wrong_target', (163, 0), (0, -1, 218)),
        ('helper_wrong_zero_branch', (211, 0), (0, 1, 184)),
        ('helper_wrong_one_branch', (211, 1), (1, 1, 218)),
        ('second_helper_wrong_target', (184, 0), (0, 1, 90)),
    ]
    rejected = []
    for name, row, action in mutations:
        broken = dict(child)
        broken[row] = action
        try:
            fold_paths(rotated, broken)
        except (ValueError, KeyError):
            rejected.append(name)
        else:
            raise ValueError('Semantic mutation survived: ' + name)
    broken = dict(rotated)
    broken[171, 0] = (0, -1, 7)
    try:
        repair_paths(parent, broken)
    except (ValueError, KeyError):
        rejected.append('unrepaired_engine_entrance')
    else:
        raise ValueError('Missing engine repair survived')
    broken = dict(rotated)
    broken[199, 0] = (0, 1, 180)
    try:
        fold_premises(broken, child)
    except ValueError:
        rejected.append('wrong_preceding_bit_inventory')
    else:
        raise ValueError('Broken tag invariant survived')
    return dict(status='PASS', universal_local_cases=len(paths), paths=paths,
                negative_controls_rejected=rejected, complete_incoming_censuses=True,
                fold_scope='All common initial tapes from state 0; positive 1-to-1/3 blocks.',
                repair_scope='Local whole-tape identity for every 171/read0 entry.',
                candidate_sha256=hashlib.sha256(Path(child_path).read_bytes()).hexdigest(),
                proof_assistant_certificate=False)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path)
    a = p.parse_args()
    result = check(ROOT/'baseline/u212.native.tm', ROOT/'machine/rotated212.native.tm',
                   ROOT/'machine/u211.native.tm')
    if a.output:
        a.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'paths'}, indent=2))
