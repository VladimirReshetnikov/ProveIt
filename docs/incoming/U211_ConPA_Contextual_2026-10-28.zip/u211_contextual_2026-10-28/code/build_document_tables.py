#!/usr/bin/env python3
"""Generate the report's exact row delta and full dense transition appendix."""
from pathlib import Path
from build_candidate import parse

ROOT = Path(__file__).resolve().parents[1]

def action(row, halt=None):
    write, direction, target = row
    target = r'\mathrm H' if target == halt else str(target)
    return rf'\(\act{{{write}}}{{{direction}}}{{{target}}}\)'

old = parse((ROOT/'baseline/u212.native.tm').read_bytes())
new = parse((ROOT/'machine/u211.native.tm').read_bytes())
rows = [r'\begin{center}\small',
        r'\begin{tabular}{rrcc}',
        r'\toprule',
        r'State & Read & U212 action & U211 action\\',
        r'\midrule']
for key in sorted(new):
    if old[key] != new[key]:
        rows.append(f'{key[0]} & {key[1]} & {action(old[key])} & {action(new[key])}'+r'\\')
for bit in (0, 1):
    rows.append(f'180 & {bit} & {action(old[180,bit])} & deleted'+r'\\')
rows += [r'\bottomrule', r'\end{tabular}', r'\end{center}']
(ROOT/'patch_table.tex').write_text('\n'.join(rows)+'\n')

dense = parse((ROOT/'machine/u211.tm').read_bytes())
rows = [r'{\small\renewcommand{\arraystretch}{0.96}',
        r'\setlength{\tabcolsep}{8pt}',
        r'\begin{longtable}{rcc@{\hspace{1cm}}rcc}',
        r'\toprule',
        r'State & Read 0 & Read 1 & State & Read 0 & Read 1\\',
        r'\midrule\endfirsthead',
        r'\multicolumn{6}{c}{\small Dense transition table, continued}\\',
        r'\toprule',
        r'State & Read 0 & Read 1 & State & Read 0 & Read 1\\',
        r'\midrule\endhead',
        r'\midrule\multicolumn{6}{r}{\small Continued on next page}\\\endfoot',
        r'\bottomrule\endlastfoot']
for q in range(106):
    line = f'{q} & {action(dense[q,0],211)} & {action(dense[q,1],211)}'
    other = q+106
    if other < 211:
        line += f' & {other} & {action(dense[other,0],211)} & {action(dense[other,1],211)}'
    else:
        line += ' & & &'
    rows.append(line+r'\\')
rows += [r'\end{longtable}', '}']
(ROOT/'transition_table.tex').write_text('\n'.join(rows)+'\n')
print('Generated 16 changed rows, 2 deleted rows, and all 422 dense transitions')
