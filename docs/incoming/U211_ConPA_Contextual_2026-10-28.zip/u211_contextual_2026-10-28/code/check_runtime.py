#!/usr/bin/env python3
"""Regenerate all unbounded unary/list-inductive contracts for literal U211.

The two mathematical induction-engine modules are byte-identical to U212.
This is an executable mathematical checker, not a proof-assistant kernel.
"""
import argparse
import gzip
import hashlib
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'code/runtime'))
import symbolic_runtime as s
from check_local import read, need
from check_source import analyze

PINS = {
    'symbolic_runtime.py': '61b9c66272e8fd149829177cc384013814aea3c6b3b6b6f48e462d3913ea2022',
    'independent_runtime.py': 'd490397a2b31be4f7f62461a3d9bcd88faf9093de904e43eea1b865561e7b7ee',
}

def check(output, compare_saved=True):
    need(__debug__ and not sys.flags.optimize, 'Assertions must be enabled')
    for name, expected in PINS.items():
        need(hashlib.sha256((ROOT/'code/runtime'/name).read_bytes()).hexdigest() == expected,
             'Induction engine changed: ' + name)
    raw = (ROOT/'machine/u211.native.tm').read_bytes()
    source_raw = (ROOT/'machine/sites.json').read_bytes()
    table = read(ROOT/'machine/u211.native.tm', 211)
    rows = json.loads(source_raw)
    metrics = analyze(rows)
    need(metrics['guarded_cases'] == 5084, 'Case count')
    mapping = {int(k): int(v) for k, v in json.loads(
        (ROOT/'baseline/legacy_mapping.json').read_text()).items()}
    states = {q for q, bit in table} | {254}
    for q in states:
        mapping.setdefault(q, q+1000)
    need(len({mapping[q] for q in states}) == 212, 'Legacy mapping not injective')
    literal = {(mapping[q], bit): (w, d, mapping[z])
               for (q, bit), (w, d, z) in table.items()}
    need(s.HEADER_BASE == 56 and s.r.PHY == (6, 2, 0, 4, 3, 7, 8, 5, 1), 'Frame')
    began = time.monotonic()
    lemmas, blocks = s.prove_blocks(literal)
    cases, used = [], set()
    for i, site in enumerate(rows):
        for positive in ((False, True) if site[1] == 'CD' else (False,)):
            answer = s.case(literal, lemmas, site, positive)
            used.update(answer['rows'])
            answer['rows'] = sorted(answer['rows'])
            answer.pop('trace')
            cases.append(dict(site_index=i, positive=positive, **answer))
        if (i+1) % 1000 == 0:
            print('Reproved', len(cases), 'guarded contracts', flush=True)
    for block in blocks:
        for event in block['trace']:
            used.add(tuple(event[1][:2]))
    need(len(cases) == 5084 and used == set(literal), 'Complete case/row coverage')
    need(all(len(c['duration']) == 13 and c['duration'][0] > 0
             and all(a >= 0 for a in c['duration']) for c in cases), 'Positive durations')
    cases = json.loads(json.dumps(cases))
    if compare_saved:
        with gzip.open(ROOT/'evidence/runtime_cases.json.gz', 'rt') as f:
            need(cases == json.load(f), 'Saved derivations differ from fresh derivations')
    result = dict(status='UNIVERSAL_MATHEMATICAL_PASS', states=211, rows=422,
                  cases=len(cases), row_coverage=len(used), header_distance=56,
                  symbolic_steps=sum(c['symbolic_steps'] for c in cases),
                  minimum_duration_constant=min(c['duration'][0] for c in cases),
                  table_sha256=hashlib.sha256(raw).hexdigest(),
                  source_sha256=hashlib.sha256(source_raw).hexdigest(),
                  checker_sha256=PINS, blocks=blocks, seconds=time.monotonic()-began,
                  scope='All natural registers/gap and all nonempty finite spare lists; '
                        'unary/list induction in ordinary Python, no proof-assistant kernel.')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    (output/'runtime.json').write_text(json.dumps(result, indent=2)+'\n')
    with gzip.GzipFile(filename=str(output/'runtime_cases.json.gz'), mode='wb', mtime=0) as f:
        f.write((json.dumps(cases, separators=(',', ':'))+'\n').encode())
    return result

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--no-compare', action='store_true')
    a = p.parse_args()
    result = check(a.output, not a.no_compare)
    print(json.dumps({k: v for k, v in result.items() if k != 'blocks'}, indent=2))
