#!/usr/bin/env python3
"""Rebuild and audit U211 offline; optionally rederive every symbolic contract."""
import argparse
import gzip
import hashlib
import json
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'code'))
import build_candidate
import check_local
import check_source
import check_startup

def need(ok, message):
    if not ok:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def manifest():
    names = []
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        p = (ROOT/name).resolve()
        need(p.is_relative_to(ROOT) and p.is_file(), 'Manifest path: '+name)
        need(sha(p) == digest, 'Manifest mismatch: '+name)
        names.append(name)
    need(len(names) == len(set(names)), 'Duplicate manifest path')
    return len(names)

def comparison():
    data = json.loads((ROOT/'comparison/comparison.json').read_text())
    need(len(data['rows']) == 8, 'Proposal census')
    for row in data['rows']:
        for kind, base in [('native', 'u212.native.tm'), ('dense', 'u212.tm'),
                           ('source', 'sites.json')]:
            p = ROOT/row[kind+'_path']
            need(sha(p) == row[kind+'_sha256'], 'Comparison digest')
            need(p.read_bytes() == (ROOT/'baseline'/base).read_bytes(), 'Nonidentical proposal')
    # Reconstruct the damaged archive's candidate from its intact parent snapshot.
    parent = build_candidate.parse((ROOT/'comparison/P05_parent.native.tm').read_bytes())
    parent[180, 1] = (1, 'R', 211)
    parent[172, 0] = (0, 'L', 67)
    del parent[112, 0]
    del parent[112, 1]
    need(build_candidate.encode(parent) == (ROOT/'baseline/u212.native.tm').read_bytes(),
         'P05 reconstruction differs')
    return dict(proposals=8, direct=7, reconstructed=1, all_tables_and_sources_identical=True)

def baseline_binding():
    with zipfile.ZipFile(ROOT/'baseline/selected_U212.zip') as archive:
        prefix = 'U212_ConPA_Stacked_2026-10-28/'
        for local, archived in [('u212.native.tm', 'machine/u212.native.tm'),
                                 ('u212.tm', 'machine/u212.tm'),
                                 ('sites.json', 'machine/sites.json'),
                                 ('legacy_mapping.json', 'inputs/legacy_mapping.json')]:
            need((ROOT/'baseline'/local).read_bytes() == archive.read(prefix+archived),
                 'Unbound baseline input: '+local)
        for name in ['symbolic_runtime.py', 'independent_runtime.py']:
            need((ROOT/'code/runtime'/name).read_bytes() ==
                 archive.read(prefix+'code/vendor/'+name), 'Runtime helper changed')
    return dict(archive_sha256=sha(ROOT/'baseline/selected_U212.zip'),
                table_source_and_runtime_bytes_bound=True)

def runtime_receipt():
    receipt = json.loads((ROOT/'evidence/runtime.json').read_text())
    with gzip.open(ROOT/'evidence/runtime_cases.json.gz', 'rt') as f:
        cases = json.load(f)
    rows = json.loads((ROOT/'machine/sites.json').read_text())
    expected = [(i, positive) for i, (_, op, _) in enumerate(rows)
                for positive in ((False, True) if op == 'CD' else (False,))]
    need([(c['site_index'], c['positive']) for c in cases] == expected, 'Saved case census')
    need(receipt['cases'] == len(cases) == 5084, 'Saved case count')
    need(receipt['table_sha256'] == sha(ROOT/'machine/u211.native.tm'), 'Runtime table binding')
    need(receipt['source_sha256'] == sha(ROOT/'machine/sites.json'), 'Runtime source binding')
    for name, digest in receipt['checker_sha256'].items():
        need(sha(ROOT/'code/runtime'/name) == digest, 'Runtime checker binding')
    need(sum(c['symbolic_steps'] for c in cases) == receipt['symbolic_steps'] == 1277525,
         'Saved symbolic step census')
    need(all(len(c['duration']) == 13 and c['duration'][0] > 0
             and all(a >= 0 for a in c['duration']) for c in cases), 'Duration shape')
    mapping = {int(k): int(v) for k, v in json.loads(
        (ROOT/'baseline/legacy_mapping.json').read_text()).items()}
    table = check_local.read(ROOT/'machine/u211.native.tm', 211)
    for q in {q for q, b in table} | {254}:
        mapping.setdefault(q, q+1000)
    literal = {(mapping[q], b): (w, d, mapping[z])
               for (q, b), (w, d, z) in table.items()}
    sys.path.insert(0, str(ROOT/'code/runtime'))
    import symbolic_runtime as engine
    _, blocks = engine.prove_blocks(literal)
    need(json.loads(json.dumps(blocks)) == receipt['blocks'], 'List lemmas changed')
    used = {tuple(row) for c in cases for row in c['rows']}
    for block in blocks:
        for event in block['trace']:
            used.add(tuple(event[1][:2]))
    need(used == set(literal) and len(used) == 422, 'Literal row coverage')
    return dict(cases=5084, rows=422, symbolic_steps=1277525,
                minimum_duration_constant=min(c['duration'][0] for c in cases),
                fresh_list_block_proofs=len(blocks))

def parent_replay(work):
    target = work/'baseline'
    with zipfile.ZipFile(ROOT/'baseline/selected_U212.zip') as archive:
        for member in archive.infolist():
            need((target/member.filename).resolve().is_relative_to(target.resolve()),
                 'Unsafe baseline ZIP member')
        archive.extractall(target)
    folder = target/'U212_ConPA_Stacked_2026-10-28'
    report = work/'baseline-replay.json'
    proc = subprocess.run([sys.executable, '-B', str(folder/'reproduce.py'),
                           '--report', str(report)], cwd=folder, text=True, capture_output=True)
    need(proc.returncode == 0, 'Baseline replay failed:\n'+proc.stderr[-3000:])
    result = json.loads(report.read_text())
    need(result['status'] == 'U212_FINITE_REPLAY_PASS', 'Baseline status')
    return result

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--full', action='store_true', help='freshly prove all 5,084 runtime contracts')
    p.add_argument('--baseline', action='store_true', help='also replay the selected U212/213/214 chain')
    p.add_argument('--report', type=Path, help='write a JSON receipt outside the sealed package')
    args = p.parse_args()
    need(__debug__ and not sys.flags.optimize, 'Run without -O or PYTHONOPTIMIZE')
    began = time.monotonic()
    files = manifest()
    with tempfile.TemporaryDirectory(prefix='u211-replay-') as temporary:
        work = Path(temporary)
        built = build_candidate.build(ROOT/'baseline/u212.native.tm',
                                      ROOT/'baseline/sites.json', work/'machine')
        for name in ['u211.native.tm', 'u211.tm', 'rotated212.native.tm',
                     'sites.json', 'state_map.json', 'construction.json']:
            need((work/'machine'/name).read_bytes() == (ROOT/'machine'/name).read_bytes(),
                 'Rebuilt bytes differ: '+name)
        local = check_local.check(ROOT/'baseline/u212.native.tm',
                                  ROOT/'machine/rotated212.native.tm', ROOT/'machine/u211.native.tm')
        source = check_source.check(ROOT/'baseline/sites.json', ROOT/'machine/sites.json')
        startup = check_startup.check(ROOT/'baseline/u212.native.tm',
                                       ROOT/'machine/u211.native.tm', ROOT/'machine/sites.json')
        for result, name in [(local, 'local_proofs.json'), (source, 'source.json'),
                              (startup, 'startup.json')]:
            need(json.loads(json.dumps(result)) == json.loads((ROOT/'evidence'/name).read_text()),
                 'Fresh receipt differs: '+name)
        compared = comparison()
        binding = baseline_binding()
        saved = runtime_receipt()
        parent = parent_replay(work) if args.baseline else None
        fresh = None
        if args.full:
            from check_runtime import check
            fresh = check(work/'runtime', compare_saved=True)
        result = dict(status='U211_FULL_REPLAY_PASS' if args.full else 'U211_FINITE_REPLAY_PASS',
                      manifest_files=files, working_states=211, transition_rows=422,
                      native_sha256=built['native_sha256'], dense_sha256=built['dense_sha256'],
                      source_sha256=built['source_sha256'],
                      local_universal_cases=local['universal_local_cases'],
                      negative_controls=len(local['negative_controls_rejected']),
                      source=source, startup_steps=startup['literal_steps'],
                      startup_trace_identical=startup['trace_identical_to_U212'],
                      comparison=compared, baseline_binding=binding, saved_runtime=saved,
                      runtime_contracts_freshly_rederived=5084 if fresh else 0,
                      baseline_status=parent['status'] if parent else 'not selected',
                      seconds=round(time.monotonic()-began, 3),
                      scope='Executable mathematical verification; inherited U/PA proof '
                            'calibration is retained; no new proof-assistant endpoint certificate.')
        if args.report:
            need(not args.report.resolve().is_relative_to(ROOT),
                 'Write replay receipts outside the sealed package')
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
