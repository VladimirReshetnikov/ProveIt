A 242-state Turing machine for Con(ZFC)
=====================================

This package supplies a concrete binary, single-tape Turing machine with
242 WORKING STATES, including its blank-tape initializer, and one separate
halt state. The full ordinary proof is in report.pdf and report.tex.

The exact conclusion is

    ZFC proves:  not Halt(M242, blank)  iff  Con(ZFC).

The new theorem is an unconditional all-tape halting equivalence with the
pinned Combined243 machine. The displayed consistency calibration follows
by composition with Combined243's inherited ordinary argument. No new
complete Lean/Rocq consistency endpoint or absolute nonhalting theorem is
claimed. The package records ordinary proofs, finite proof-premise checks,
finite regression tests, and inherited evidence with their distinct scopes.

EXACT MACHINE
-------------
Canonical file: machine/zfc_zero_reuse242.tm
Working states: 0 through 241
Initial state: 0
Dispatcher: 86
Separate halt: 242
Alphabet: {0,1}
Input: all-zero two-way infinite tape; initial head 0
Moves: one cell left or right on every transition
Binary rows: 484

Canonical SHA256:
64ddeb2c01c3e9c7feffaffaad87266a270716c9307892a0445bf869b988984d

Inherited file: machine/zfc_zero_reuse242_old.tm
Inherited start/dispatcher/halt: 95 / 96 / 254
Inherited SHA256:
6b700aa713418cfe347a6ff2d0a92de7c31810d1cf69814b4684c7fb463876a0

Every noncomment row has five fields:
    state read write direction next_state
The first line declares the start. Halt has no outgoing rows and does not
count as a working state. machine/renumbering.json contains the full bijection.

THE NEW REDUCTION
-----------------
Reference: ProveIt commit e58338db7545909907e07a7603e8eb88625c527a,
Computability/BusyBeaver/Research/ZFC/candidate-combined243.

Use inherited labels. Delete old state 15 and change only these retained rows:

    11 0 0 R 15    becomes    11 0 0 R 27
    27 1 1 R 39    becomes    27 1 1 R 22

All 482 other retained rows are identical. The old machine satisfies

    q in {18,47,65} implies T(h-1)=0;
    q=27 implies T(h)=0.

The invariant is vacuous at initial state 95 for every tape. Thus old (27,1) is
never read. It can take over state 15's one branch. On the zero branch, the
new route 11 -> 27 -> 32 -> 45 -> 21 takes four transitions instead of two
and reaches exactly the same state, head, and WHOLE TAPE. The one branch
takes two transitions on both machines and reaches 22. Positive finite blocks
and identical ordinary rows prove both halting directions.

ACTUAL VERIFICATION
-------------------
- Exact construction, complete predecessor inventory, totality and bijection.
- 7,712 exhaustive local Boolean invariant implications.
- 482 common-row comparisons and two universal two-cell block identities.
- Independent source regression: all 8,390 cases from 6,459 source leaves.
- 6,473,406 literal fixture transitions; all 484 rows covered, none unused.
- Sparse and dense blank replay, in both candidate numberings.
- Exact common root frame after 407,979 transitions, versus 407,967 baseline.
- Complete frame: head -5, marker -6, header 176, span 181; logical registers
  (3,0,0,0,3,0,0,0,0); 167 spare ones; 351 one-cells; zero everywhere else.
- Independent adversarial review found no gap in the ordinary local proof.

The full-tape equivalence supplies the universal argument; finite fixture
coverage is corroboration. No long-run simulation is used to infer nonhalting.

REPRODUCE OFFLINE
----------------
Use Python 3.10 or later, standard library only, with assertions enabled.
From this package directory, choose a NEW output directory outside it:

    python3 -B code/verify_all.py --output /tmp/zfc242-check

To reproduce the optional restricted discovery searches as well:

    python3 -B code/verify_all.py --search --output /tmp/zfc242-search-check

The wrapper hashes all principal inputs before and after the checks,
regenerates the exact tables, compares the delivered bytes, rechecks the
ordinary proof premises, runs every source fixture and blank replay, and
regenerates both separate equational packets. No network is needed.

The search summaries cover radius-4 windows, direct state redirects, and
selected row-replacement unions with bounded local coalescence. Their
negative results are not a lower bound on machine size. The six accepted
243-to-242 representations share the same available old (27,1) row and cannot
simply be composed into three deletions.

REBUILD THE PDF
---------------
    python3 -B code/render_table.py --check
    pdflatex -interaction=nonstopmode -halt-on-error report.tex
    pdflatex -interaction=nonstopmode -halt-on-error report.tex

If LaTeX requests another pass to settle the table of contents, run it again.
The appendix prints all 242 states directly from the exact canonical file.
paper/zero_reuse242_proof.tex is the independently reviewed proof fragment.

SEPARATE FORMALISM RESULT
------------------------
research/stack-kernel/ contains the full ordinary proof, standalone generator,
literal equations, codec, exact old packet/metrics, and both new variants.
The preferred environment-stack packet has 14 equations, 16 symbols, 3 local
variables and 214 term nodes. Its COMPLETE payload is 1,169 bits, compared with
the exhibited source 70 packet's 2,324 bits. It uses the same fully charged
fixed-opcode packet format, including signature, equation delimiters and
ground endpoints. The alternate derived-member-pick packet has 1,201 bits.

The new native stack equations remove conditional assignment-update equality
and the reified equality/congruence completion. The ordinary model argument
uses the precise inherited empty-seed EPSC calibration and the published
Sh1 Boolean single axiom. Its finite checks cover 2,080 symbolic projections,
16,384 formula/class comparisons, 72 truth assignments per variant, codec
round trips and malformed-packet rejection.

This frontend supplies NO COMPILED BINARY TM and no additional state bound.
A complete term-rewrite search interpreter and blank initializer must still
be constructed and counted. The 242-state machine does not depend on it.
The PDF contains the full frontend argument as its final appendix.

INHERITED MATERIAL AND CREDIT
----------------------------
baseline/ includes the exact Combined243 tables and logical source sites.
vendor/zfc243-composed-20261018.zip is the original queued predecessor
research archive, copied byte for byte. Its SHA256 is
f98b5b6485475e7aca3bcd8d93d2ddc11f83a34b55bffca113b23bd9e54ba44a
It retains its historical calibration/source/runtime proofs, records,
reproduction instructions and attribution. A historical expanded result is
not presented as a new expanded run of the 242 table.

Original credit is retained for Mira-Cult, Jeff Ketchersid, Andrew James
Wade, ProveIt contributors, and the credited source-rotation and compensated
fold contributions. See NOTICE.txt, licenses/, PROVENANCE.json and the
inherited archive. No additional personal author is inferred.

SHA256SUMS covers the final package contents except itself. INPUTS.json
binds the principal executable and data inputs. Evidence records retain
the precise distinction between actual replays and reviewed source claims.
