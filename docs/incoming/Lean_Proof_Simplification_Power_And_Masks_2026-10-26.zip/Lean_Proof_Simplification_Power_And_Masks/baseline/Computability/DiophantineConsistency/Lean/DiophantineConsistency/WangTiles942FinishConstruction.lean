import DiophantineConsistency.WangMachineEncoding
import DiophantineConsistency.WangTiles942Language

/-!
# Explicit halted, finish, initialization, and reset rows

These whole-integer rows use only the actual finite tile constructors. The
halted rows retain head colors 432/433. The initializer is the post-first-step
configuration with south color 4 at its head, and the reset row returns exactly
to its north colors. No finite walls or periodic trace cycle are asserted here.
-/

namespace DiophantineConsistency.WangTiles942FinishConstruction

open SetTheory.BusyBeaver WangTiles942 WangTiles942Language WangMachineEncoding

set_option Elab.async false
set_option maxHeartbeats 1000000
set_option maxRecDepth 10000

/-- A halted row can wait, preserving every encoded vertical color. -/
def passTile (cfg : Config 215) (x : ℤ) : Tile :=
  ⟨0,color cfg x,0,color cfg x⟩

/-- A halted row can finish, replacing every encoded color by 438. -/
def finishTile (cfg : Config 215) (x : ℤ) : Tile :=
  ⟨0,color cfg x,0,438⟩

theorem passTile_allowed (cfg : Config 215) (hh : cfg.state = none) (x : ℤ) :
    Allowed (passTile cfg x) := by
  unfold passTile
  by_cases hx : x = cfg.head
  · subst x
    rw [color_at_head,hh,halted_head_color]
    exact Allowed.pass (1 : Fin 2)
      ⟨(Tape.read cfg.tape cfg.head).toNat, by have h := bit_le_one (Tape.read cfg.tape cfg.head); omega⟩
  · rw [color_of_ne_head cfg x hx]
    simpa only [Fin.val_zero, Nat.mul_zero, zero_add] using
      Allowed.pass (0 : Fin 2)
        ⟨(Tape.read cfg.tape x).toNat, by have h := bit_le_one (Tape.read cfg.tape x); omega⟩

theorem finishTile_allowed (cfg : Config 215) (hh : cfg.state = none) (x : ℤ) :
    Allowed (finishTile cfg x) := by
  unfold finishTile
  by_cases hx : x = cfg.head
  · subst x
    rw [color_at_head,hh,halted_head_color]
    exact Allowed.finish (1 : Fin 2)
      ⟨(Tape.read cfg.tape cfg.head).toNat, by have h := bit_le_one (Tape.read cfg.tape cfg.head); omega⟩
  · rw [color_of_ne_head cfg x hx]
    simpa only [Fin.val_zero, Nat.mul_zero, zero_add] using
      Allowed.finish (0 : Fin 2)
        ⟨(Tape.read cfg.tape x).toNat, by have h := bit_le_one (Tape.read cfg.tape x); omega⟩

theorem passTile_colors (cfg : Config 215) (x : ℤ) :
    (passTile cfg x).north = color cfg x ∧ (passTile cfg x).south = color cfg x ∧
      (passTile cfg x).west = 0 ∧ (passTile cfg x).east = 0 := ⟨rfl,rfl,rfl,rfl⟩

theorem finishTile_colors (cfg : Config 215) (x : ℤ) :
    (finishTile cfg x).north = color cfg x ∧ (finishTile cfg x).south = 438 ∧
      (finishTile cfg x).west = 0 ∧ (finishTile cfg x).east = 0 := ⟨rfl,rfl,rfl,rfl⟩

theorem passTile_horizontal (cfg : Config 215) (x : ℤ) :
    (passTile cfg (x+1)).west = (passTile cfg x).east := rfl

theorem finishTile_horizontal (cfg : Config 215) (x : ℤ) :
    (finishTile cfg (x+1)).west = (finishTile cfg x).east := rfl

/-- Literal initializer on all signed positions, with Start at 0 and head at 1. -/
def initialTile (x : ℤ) : Tile :=
  if x < 0 then ⟨2,434,2,0⟩
  else if x = 0 then start
  else if x = 1 then ⟨3,436,4,4⟩
  else ⟨4,436,4,0⟩

theorem initialTile_negative (x : ℤ) (hx : x < 0) : initialTile x = ⟨2,434,2,0⟩ := by
  simp only [initialTile, if_pos hx]

theorem initialTile_zero : initialTile 0 = start := by simp [initialTile]

theorem initialTile_one : initialTile 1 = ⟨3,436,4,4⟩ := by simp [initialTile]

theorem initialTile_right (x : ℤ) (hx : 1 < x) : initialTile x = ⟨4,436,4,0⟩ := by
  simp only [initialTile, if_neg (show ¬ x < 0 by omega),
    if_neg (show x ≠ 0 by omega), if_neg (show x ≠ 1 by omega)]

theorem initialTile_allowed (x : ℤ) : Allowed (initialTile x) := by
  unfold initialTile
  split_ifs
  · exact Allowed.initLeft
  · exact Allowed.start
  · exact Allowed.initHead
  · exact Allowed.initRight

/-- All three initializer north colors are precisely valid reset targets. -/
theorem initialTile_north_mem (x : ℤ) : (initialTile x).north ∈ [434,435,436] := by
  unfold initialTile
  split_ifs <;> decide

/-- Actual output is the written origin and state1/blank head, not a blank initial tape. -/
theorem initialTile_south (x : ℤ) :
    (initialTile x).south = color DecimalMachineInitialization.initialized x := by
  rw [initialized_color]
  by_cases hn : x < 0
  · have h0 : x ≠ 0 := by omega
    have h1 : x ≠ 1 := by omega
    simp only [initialTile, if_pos hn, if_neg h0, if_neg h1]
  · by_cases h0 : x = 0
    · subst x
      rw [initialTile_zero]
      rfl
    · by_cases h1 : x = 1
      · subst x
        rw [initialTile_one]
        rfl
      · simp only [initialTile, if_neg hn, if_neg h0, if_neg h1]

/-- The color changes 2→3→4 occur at the actual adjacent Start and head tiles. -/
theorem initialTile_horizontal (x : ℤ) : (initialTile (x+1)).west = (initialTile x).east := by
  have hc : x < -1 ∨ x = -1 ∨ x = 0 ∨ x = 1 ∨ 1 < x := by omega
  rcases hc with h | rfl | rfl | rfl | h
  · rw [initialTile_negative x (by omega), initialTile_negative (x+1) (by omega)]
  · decide
  · decide
  · decide
  · rw [initialTile_right x h, initialTile_right (x+1) (by omega)]

/-- The exact reset tuple leading back to this initializer at each signed position. -/
def resetTile (x : ℤ) : Tile := ⟨1,438,1,(initialTile x).north⟩

theorem resetTile_allowed (x : ℤ) : Allowed (resetTile x) :=
  Allowed.reset _ (initialTile_north_mem x)

theorem resetTile_colors (x : ℤ) :
    (resetTile x).north = 438 ∧ (resetTile x).south = (initialTile x).north ∧
      (resetTile x).west = 1 ∧ (resetTile x).east = 1 := ⟨rfl,rfl,rfl,rfl⟩

theorem resetTile_horizontal (x : ℤ) : (resetTile (x+1)).west = (resetTile x).east := rfl

/-- Arbitrary repeated halted pass rows and their finish row match vertically. -/
theorem pass_finish_matching (cfg : Config 215) (x : ℤ) :
    (passTile cfg x).north = (passTile cfg x).south ∧
      (finishTile cfg x).north = (passTile cfg x).south := ⟨rfl,rfl⟩

/-- Finish, reset, and initializer interfaces match exactly, without choosing walls. -/
theorem finish_reset_initial_matching (cfg : Config 215) (x : ℤ) :
    (resetTile x).north = (finishTile cfg x).south ∧
      (initialTile x).north = (resetTile x).south := ⟨rfl,rfl⟩

/-- Complete explicit local row constructions, with the sole halted-state premise. -/
theorem closing_rows (cfg : Config 215) (hh : cfg.state = none) :
    (∀ x : ℤ, Allowed (passTile cfg x) ∧ Allowed (finishTile cfg x)) ∧
    (∀ x : ℤ, Allowed (initialTile x) ∧ Allowed (resetTile x)) ∧
    (∀ x : ℤ, (initialTile x).south = color DecimalMachineInitialization.initialized x) ∧
    (∀ x : ℤ, (passTile cfg (x+1)).west = (passTile cfg x).east ∧
      (finishTile cfg (x+1)).west = (finishTile cfg x).east ∧
      (initialTile (x+1)).west = (initialTile x).east ∧
      (resetTile (x+1)).west = (resetTile x).east) :=
  ⟨fun x => ⟨passTile_allowed cfg hh x, finishTile_allowed cfg hh x⟩,
    fun x => ⟨initialTile_allowed x,resetTile_allowed x⟩, initialTile_south,
    fun x => ⟨passTile_horizontal cfg x,finishTile_horizontal cfg x,
      initialTile_horizontal x,resetTile_horizontal x⟩⟩

end DiophantineConsistency.WangTiles942FinishConstruction
