import DiophantineConsistency.WangTiles942HelicalMarker

namespace DiophantineConsistency.WangTiles942HelicalMarkerChecks

open WangTiles942 WangTiles942Language WangTiles942HelicalExtension
  WangTiles942HelicalQuotient WangTiles942HelicalMarker

set_option Elab.async false
set_option maxRecDepth 10000

-- The canonical representative bound is material: an entire period
-- has marker coordinates too, but lies outside [0,w*H).
example : representative 3 1 (-12) = 0 ∧ quotient 3 1 (-12) % 4 = 0 ∧
    (12 : ℤ) ≠ 0 := by decide

-- The arithmetic implication permits noncoprime geometric dimensions.
example (x : ℤ) (h0 : 0 ≤ x) (h4 : x < 4)
    (hr : representative 2 1 (-x) = 0) (hq : quotient 2 1 (-x) % 2 = 0) : x = 0 :=
  zero_of_marker_coordinates 2 2 1 x h0 h4 hr hq

-- Marker transport needs a local classification and allowedness only;
-- this helper does not assert matching or machine semantics.
example (C : ℤ → ℤ → Tile)
    (hA : ∀ x, InBand 2 1 x → ∀ t, Allowed (C x t))
    (hm : ∀ x, InBand 2 1 x → ∀ t,
      C x t = start ↔ x = 0 ∧ t % 2 = 0) (z : ZMod 4) :
    tile (quotientWord (extend C 2 1) (extend_allowed C 2 (by decide) 1 hA) 2 2 z) = start ↔
      z = 0 :=
  quotientWord_marker_iff C 2 2 (by decide) (by decide) 1 (by decide) (by decide) hA hm z

#print axioms zero_of_marker_coordinates
#print axioms quotientWord_marker_iff

end DiophantineConsistency.WangTiles942HelicalMarkerChecks
