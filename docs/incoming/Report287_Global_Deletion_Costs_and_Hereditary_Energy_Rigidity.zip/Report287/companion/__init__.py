"""Bounded exact diagnostic companion for Report287; see README.md for scope."""
