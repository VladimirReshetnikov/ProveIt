# Report 287

## Global Deletion Costs and Hereditary Energy Rigidity

Prepared for Vladimir Reshetnikov, 7 October 2026.

The report proves two connected results. For every fixed k ≥ 1 and 0 < gamma < 1, and every sufficiently large cyclic modulus N, full-domain maps satisfying the pinned weighted product and named Section 16 predicates can require positive ambient deletion to meet the parameter-one local cover target. The deletion lower bound allows arbitrary retained domains. An optimized construction gives Delta >= eta gamma^E / [12 e^2 (E+2)^2]. The entire defective slab is a matching upper repair up to the stated factors; no exact minimum is claimed.

For a map a: Z/NZ -> Z/NZ, let r(a) be the infimum over all nonnegative nonzero weights of respected additive energy divided by ordinary additive energy. Then r(a) lies in [0,8/11] union {3/4,1}; above 8/11 only affine maps and even-modulus parity forms occur. A non-affine parity form has exact ratio 3/4 by a sum-of-squares identity. The threshold r>3/4 is sharp and forces affinity. Optimality of 8/11 is not asserted. Nontrivial modifications of an affine map on fewer than N/2 points have r <= 8/11. The sharp >3/4 implication extends to arbitrary abelian targets (including infinite targets), using a division-free even-cycle form. The 8/11 classification remains stated for target Z/NZ. A deterministic linear scan supplies a small indicator certificate or an affine/parity representation.

This is an AI-assisted mathematical research manuscript, not a refereed publication, a publication-priority claim, or a Lean kernel certificate. The relative-energy classification is full-domain and one-variable; no inheritance through upstream selections, general partial-domain repair, full multivariate cover theorem, or global Szemeredi bound is established.

## Contents

- `Report287.pdf`: complete standalone manuscript
- `article.tex`: editable LaTeX source
- `companion/exact_checks.py`: bounded deterministic exact diagnostics and certificates
- `companion/README.md`: diagnostic scope and bounded public API
- `tests/test_companion.py`: exact mathematical, validation and provenance regressions
- `tests/test_build.py`: inventory, no-follow path, process, archive and replay regressions
- `build.py`: guarded offline reproduction and deterministic ZIP packaging
- `SOURCES.md`, `provenance/source_manifest.json`, and four pinned Lean snapshots: source evidence and attribution
- `MANIFEST.sha256`: distribution integrity, excluding itself

The snapshots are source evidence only. No upstream code is executed; no Lean project is built. Earlier reports, original ZIP archives, the large canonical combined article, and private working reviews are deliberately omitted.

## Quick checks

From the extracted `Report287` directory:

    python3 -I -B build.py verify
    python3 -I -B companion/exact_checks.py
    python3 -I -B tests/test_companion.py
    python3 -I -B tests/test_build.py

The companion uses Python's standard library without network access or third-party packages. It accepts no command-line options and prints deterministic JSON. Public helpers reject unsupported types and oversized inputs before work. All runtime mathematical checks use explicit exceptions rather than optimization-removable assert statements.

## Reproduce the complete distribution

Choose a fresh absolute output directory outside the extracted source tree:

    python3 -I -B build.py reproduce --output /tmp/report287-replay

The destination must not exist or must be empty. The builder refuses source ancestors/descendants, unsafe locations, aliases, symlinks, hard-linked source files, unexpected source entries, and existing outputs. It runs builder tests, companion tests, and exact checks normally and with `-O`, in an isolated environment with a 640-digit integer-string limit. Matching standard output and unchanged original/staged source inventories are required.

It creates a local TeX format, compiles the article three times with shell escape disabled and restricted file policies, checks the log, and creates the PDF, manifest, deterministic ZIP, ZIP SHA-256 pin, and reproduction receipt. The ZIP has only the fixed public member allowlist; logs and receipts remain outside it.

Additional commands:

    python3 -I -B build.py reproduce --output /tmp/report287-pdf-only --no-zip
    python3 -I -B build.py package --output /tmp/report287-package-only

The `package` command requires an already manifest-pinned distribution and repackages its exact PDF and source bytes without compiling.

## Reproducibility boundary

The reference environment is Linux with Python 3.12.14, pdfTeX 3.141592653-2.6-1.40.26 (TeX Live 2025/dev/Debian), Latin Modern and the standard LaTeX packages named in the article. The guarded builder requires Linux no-follow directory handles and `/proc/self/fd`, and fails closed elsewhere. It requires `/usr/bin/pdftex` and `/usr/bin/pdflatex`; it installs nothing.

The archive has sorted member names, a fixed 7 October 2026 timestamp, fixed modes, and fixed deflate settings. Byte-identical replay requires matching TeX/font and Python/zlib toolchains. A rebuilt PDF mismatch fails the distribution replay rather than replacing the reference. Mathematical diagnostics can be run independently of TeX.

The compiler gate rejects overfull boxes and unresolved references/citations. The final PDF is additionally rendered and visually inspected; text extraction alone is not a layout check.

## What the finite checks mean

Finite checks detect errors in the written formulas, count identities, classification certificates, rounded bounds, and implementation safeguards. They are not proofs by enumeration of the infinite theorems. Small exponent regressions for deletion inequalities do not instantiate the actual enormous Section 16 exponent. No universal random word at the theorem's scale is computed; its existence is established in the manuscript. The companion neither computes the exact minimum deletion fraction nor optimizes over all real weights.

Raw source identities verify bundled bytes. The provenance manifest separates the four bundled source records from external citation metadata. Offline replay does not refetch omitted archives or public repository objects. Canonical-base64 digests are alternate representation hashes, not transport receipts. Checksums certify byte identity, not mathematical correctness, authorship, or publication priority.
