# Compressed Queue Computation

**Grammar-size quartic certificates, exact periodic acceleration, and certified infinite loops**

Prepared for Vladimir Reshetnikov's ProveIt research program, 2 October 2026.
The standalone article is `article.tex`; its compiled version is `article.pdf`.

## Main results

For a prescribed FIFO transition trace represented by a straight-line grammar
with `g` nodes, `l` leaves and `c` concatenations, the finite compiler produces
an ordinary integer polynomial of degree at most four. It has exactly
`6g + 3c + 1` natural-number variables and `6l + 9c + 3` quadratic residuals.
There is exactly one natural zero when the trace connects the specified actual
queue words and no natural zero otherwise. The parameter is grammar size,
not expanded execution length. Arithmetic assignments can still have very
large bit lengths.

A second compiler certifies indefinite repetition of a specified closed macro
using a finite word-conjugacy equation. It is also an **ordinary quartic** with
unique witnesses and grammar-linear size for a fixed transition table.
The article additionally gives the exact number of executable repetitions,
a finite Fine–Wilf pumping test, multichannel extensions, a powered-schema
extension with explicitly retained exponentiation predicates, and limits on
complete automatic trace compression and periodic nontermination certificates.

## Status

The mathematical arguments are supplied in the article. This is an unrefereed,
AI-assisted research manuscript, not a Lean-verified development. The exact
arithmetic construction is the proposed contribution; queue universality,
queue-action algebras, loop acceleration and Fine–Wilf periodicity are credited
prior work. Priority for the combination and exact constants is not certified.
No named longstanding open problem, universal single-fold MRDP result, or
complete decision procedure for halting/nonhalting is claimed.

The repository audit used commit `44983ed7ebfd545de55bfdb50e040c82f3d24295`.
The queue predecessor's catalogue and integration note were read, but its
large merged article was not fully retrievable. See `CLAIMS_AND_PROVENANCE.md`.

## Reproduce

Python 3.10 or later, standard library only:

```sh
python code/verify.py
python code/check_certificate.py data/example_quartic.json data/infinite_growth_quartic.json
```

The recorded suite passed **259,025 assertions** with seed `20261002`, using
Python 3.13.5. `data/verification.json` records all finite test domains and
counts. The separate checker does not import the compiler; it checks sparse
integer syntax, degrees, the exact polynomial sum-of-squares identity, and the
listed natural zero. These checks supplement but do not replace compiler
soundness, completeness, and uniqueness proofs.

Build the article with a standard TeX Live installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `pdflatex` three times. No bibliography tool, shell escape,
network access, or separate images are needed. `make verify` and `make pdf`
provide equivalent commands.

## Python example

```python
import sys
sys.path.insert(0, "code")
from queue_certificates import Action, Leaf, Concat, compile_certificate

# Two copies of: read 0 / append 010; read 1 / append nothing.
grammar = [
    Leaf(Action("0", "010")),
    Leaf(Action("1", "")),
    Concat(0, 1),
    Concat(2, 2),
]
cert = compile_certificate(grammar, initial="01", final="0010")
assert cert.accepts()
assert len(cert.names) == 31
assert len(cert.residuals) == 33
assert cert.polynomial().degree == 4
cert.export("example.json")
```

For an infinite loop:

```python
from queue_certificates import compile_infinite_certificate
cert = compile_infinite_certificate([Leaf(Action("1", "11"))], initial="1")
assert cert.accepts()  # The queue grows by one 1 at each copy.
```

`maximum_repetitions(actions, initial)` returns an exact integer, or `None`
for infinity. It requires a nonempty total read word. Read-free closed macros
are handled separately by the infinite compiler.

## Encoding and API conventions

The default alphabet is `01`, encoded by radix-three digits 1 and 2. Empty
words have `(scale, value) = (1, 0)`. Actual input and output strings are supplied;
arbitrary natural triples are not presumed to be valid encodings. A transition
removes its entire read word before appending its write word. Child references
must point backward. All control compositions are checked before compilation.

`Certificate.witness` is the forced **candidate** assignment. When the requested
execution is invalid it fails `accepts()`; its mere presence does not assert that
the trace was legal. Syntax/control errors raise an exception. The library
constructs certificates, not a general Diophantine solver.

Sparse JSON exports store monomials as sorted variable-index lists. Coefficients
and witness coordinates are exact JSON integers; exceptionally large values are
written as explicitly prefixed hexadecimal strings to avoid Python's decimal
conversion limit. The independent checker supports both representations.

## Contents

- `article.tex`, `article.pdf`: self-contained article with proofs and research agenda.
- `code/queue_certificates.py`: finite and infinite quartic compilers and loop analyzer.
- `code/verify.py`: deterministic exact test suite.
- `code/check_certificate.py`: independent sparse-export checker.
- `data/verification.json`, `data/verification_stdout.txt`: actual test receipt/output.
- `data/export_checks.json`: independent check results for the two exported examples.
- `data/example_quartic.json`, `data/infinite_growth_quartic.json`: complete polynomials and zeros.
- `CLAIMS_AND_PROVENANCE.md`: mathematical scope, dependencies and source-audit limits.

The variable-exponent schema theorem is proved in the article; its elementary
identities are tested in Python. The supplied exporter does not emit formulas
with variable exponentiation predicates. The asymptotic compressed-word
decision corollary uses an established external word-comparison algorithm,
not an implementation of that algorithm in this package.
