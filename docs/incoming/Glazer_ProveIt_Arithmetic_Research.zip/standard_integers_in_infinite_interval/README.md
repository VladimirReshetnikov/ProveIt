# Standard Integers in a Single Infinite Interval

**Residue characters, bounded induction, and omnific arithmetic**

Research draft prepared for Vladimir Reshetnikov, 3 October 2026.

## Contents

- `article.pdf`: compiled, 20-page research article (page count may change on rebuild).
- `article.tex`: self-contained LaTeX source, including the bibliography.
- `code/verify.py`: exact rational-polynomial certificate checks.
- `code/compile_interval.py`: executable syntax-tree compiler and invariant checks.
- `verification.json`: recorded exact-certificate test results.
- `compiler_report.json`: recorded compiler tests, with full input/output examples.
- `SOURCE_AUDIT.md`: provenance, correction scope, and novelty boundaries.
- `build.sh`: reproducible local build and test commands.

## Main mathematical content

A fixed bounded dyadic predicate defines the ordinary powers of two in a
discretely ordered ring with division by 2 and 3 and a normalized additive
map to Z. Dyadic bracketing then defines its standard natural-number cut.
One explicit bounded induction instance forces standardness in this class.

A nonstandard model of bounded arithmetic has a difference ring with no
nonzero additive homomorphism to Z. In particular, it has no unit-preserving
additive map into the omnific integers. The article proves the obstruction
without imposing continuity, definability, injectivity, or order preservation.

An effective translation places arbitrary standard arithmetic sentences into
a fragment using a single positive infinite bound and quadratic atoms. In
the computable ring Z + X Q[X], that bounded truth fragment is many-one
equivalent to true arithmetic.

A separate source-level correction gives the counterexample (X), (X-1) in
Z[X] to Lemma 2.7 of Enayat–Łełyk–Visser, arXiv:2508.14758v2. A valid
uniqueness theorem is proved under division by 2. This local correction is
not a claim that the paper's main results fail.

## Build

Requirements: Python 3.10 or later, a LaTeX installation with `latexmk` and
`pdflatex`, and the standard packages named in `article.tex`. No additional
Python packages or network access are required.

```sh
sh build.sh
```

Or run the steps individually:

```sh
python3 code/verify.py --output verification.json
python3 code/compile_interval.py --output compiler_report.json
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The Python files can also be imported to construct additional examples.
The compiler takes formula trees through its public constructors; it does
not parse arbitrary strings or evaluate quantified formulas at infinite bounds.

## Verification and limits

The recorded certificate run checks 2,000 positive-infinite polynomial
factorizations, 12,000 division certificates, 4,000 character identities,
1,025 finite dyadic cases, 1,025 finite standard-cut cases, and 272 pairs
of distinct evaluation kernels. The compiler run checks five sentence
examples and 768 finite local gate evaluations.

These are finite, exact checks, not machine-checked proofs of the universal
theorems. The article supplies the mathematical proofs. No new Lean or
Rocq proof is included or claimed. The draft is AI-assisted and unrefereed.
Global priority has not been established for its exact formulations.
Standard-cut definability and failure of stronger induction in omnific
arithmetic were already known and are credited explicitly.

Elliot Glazer is not an author of this draft, and no review or endorsement
by him is implied. The mathematical connection is to his published work on
weak arithmetic and regularity of presentations.
