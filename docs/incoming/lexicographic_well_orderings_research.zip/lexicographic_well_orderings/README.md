# Lexicographic orders of real well-orderings

A research report prepared for Vladimir Reshetnikov, 2 October 2026.

## Contents

- `article.pdf`: the typeset article.
- `article.tex`: complete, self-contained LaTeX source, including bibliography.
- `source_audit.md`: exact sources, repository revision, proof dependencies,
  and verification limits.
- `finite_checks.py`: reproducible finite illustrations; standard library only.
- `finite_checks_results.json`: recorded output of those checks.
- `README.md`: this guide and build instructions.

## Main results

Writing c for the initial ordinal of the continuum:

1. The full order W, the minimal-type stratum P, and the actual Kanovei–Shelah
   index A each contain exactly the ordinals below c^+, as well as every linear
   order of cardinality at most c. Their cardinality is 2^c.
2. P and A are mutually embeddable with R^c in lexicographic order. W instead
   has real-power representation rank c^+ and contains R^beta for each beta
   below c^+, but not at beta = c^+.
3. W absorbs its nonzero lexicographic beta-th power under mutual embeddability
   exactly for beta < c^+. Even the square of P does not embed in P.
4. The article classifies all finite convex blocks, point-character pairs,
   and gap-character pairs of W. Every gap of W has a countable side, whereas
   P has a gap with both sides of character cf(c).
5. Density, cellularity, weight, global cofinality, and additional properties
   of the actual ultrafilter index are calculated. A genuine well-ordering-based
   ultrafilter labeling is also constructed.

These are conventional proofs in ZFC, not Lean-verified results. Historical
priority is not asserted. The report distinguishes the actual published
ultrafilter-enumeration index from the literal order of all well-orderings.
Seven proposed research directions close the article.

## Rebuild the PDF

Use a TeX distribution providing AMS packages, NewTX, microtype, enumitem,
hyperref, cleveref, and fancyhdr. No external bibliography program is needed.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex` enough times for references and the table of
contents to stabilize (normally two or three).

## Repeat the finite checks

Requires Python 3.10 or later. Do not use Python's `-O` option, which disables
assertions.

```sh
python finite_checks.py --output finite_checks_results.json
```

The checks are finite illustrations, not a machine verification of the
transfinite theorems. See the source audit for exact boundaries.
