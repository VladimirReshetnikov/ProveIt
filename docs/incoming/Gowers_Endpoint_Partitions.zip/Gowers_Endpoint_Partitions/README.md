# Partition Normal Forms for Small Schur Defect

**Sharp endpoint bounds and the first four additive-energy levels**

A 24-page mathematical research manuscript prepared with ChatGPT for
Vladimir Reshetnikov, for integration into ProveIt's Ramsey research materials.
The article strengthens the ordered-energy endpoint immediately before
Theorem 7.2 in Gowers, *A new proof of Szemerédi's theorem* (2001).

## Main results

Write E(A) for the number of ordered additive quadruples in an m-element set,
M_m = (2m^3+m)/3, and D(A) = (M_m-E(A))/4.

1. **All-defect partition theorem (Theorem 4.1).** A positive real n-set with
   Schur defect at most r, for n >= 3r+1, has the form
   c_i = d(i+lambda_i), with nonnegative nondecreasing integer shifts whose
   sum is exactly the defect. Exact defect r has p(r) positive-dilation classes.
2. **Boundary-hole energy and sharp envelope (Theorems 6.1 and 7.2).** Every
   small endpoint-defect set is a bounded-hole arithmetic template. Its energy
   is an explicit affine function of cardinality after subtraction of M_m.
   For last-endpoint defect r >= 1 and m-1 >= 3r+1,
   E(A) <= M_m - 4r(m-1-r), with equality precisely at a single hole in
   position r (up to translation and positive dilation).
3. **Complete third and fourth energy levels (Theorems 9.1, 10.1, 10.2).**
   The third-level equality cases are classified for m >= 8, and the fourth
   for m >= 11. For m >= 11, the first four distinct energies are
   M_m, M_m-4(m-2), M_m-8(m-3), and M_m-8m+20. They have respectively
   1, 2, 3, and 2 oriented affine templates.
4. **Full-set recovery (Section 11).** In the first-four-level energy window,
   the entire set lies in an arithmetic progression of at most m+2 points,
   contains one of at least m-2 points, and has at most 2m+3 differences.
   The invariant energy classification extends to torsion-free abelian groups.
   A graph corollary gives a globally affine graph under the same high-energy
   hypothesis; cyclic applications require a justified no-wrap lift.

The article proposes ten further research questions, including an optimal
Schur threshold, the second endpoint-energy constant, the fifth global energy
level, linear-defect stability, and a verified recovery algorithm.

## Scope and attribution

The first energy gap, the second-level classification, the unit-Schur case,
and the third-level lower bound are prior repository material and are credited.
The first gap is also implicit in published inverse Pollard theory. The article
reproves this background before giving the all-defect and equality extensions.

This is an AI-assisted, unrefereed written proof manuscript. No result here has
been proof-assistant verified. Publication priority for the additions has not
been established by the bounded source search. There is no claimed improvement
to a global Szemerédi or Ramsey bound, and the endpoint-defect hypothesis is
not interchangeable with a total-energy hypothesis.

## Contents

- `article.tex`, `article.pdf`: standalone source and compiled 24-page article.
- `code/verify.py`: exact finite checks, standard-library Python only.
- `data/verification.json`, `data/verification.log`: actual default-run results.
- `data/partition_spectrum.csv`: all 271 partition templates of weights 1--12,
  with their hole sets and exact boundary-energy constants.
- `SOURCES.md`: primary sources, repository content identifiers, priority limits.
- `INTEGRATION.md`: contribution crosswalk and suggested repository placement.
- `PROOF_AUDIT.md`: preparation-workflow checks and scope hazards; not an
  external referee report.
- `data/build_validation.json`: compilation, rendering, and verification record.
- `Makefile`: reproduction commands.
- `MANIFEST.sha256`: integrity inventory of the other delivered files.

## Reproduction

From this directory:

```sh
python3 code/verify.py
make pdf
```

Or run `make all` to do both. The verifier uses integer and rational arithmetic,
not floating-point tolerances. Its default search inspects all 65,535 nonempty
subsets of [1,16] and all 65,535 subsets of [0,16] containing zero with size at
least two. The narrow theorem hypotheses apply to only some of these inputs;
those counts are recorded separately. These are finite checks, not a proof
outside the boxes. The article contains the general proofs.

Alternative output locations and finite search bounds are supported:

```sh
python3 code/verify.py --out /tmp/endpoint-checks --box 16 --partition-limit 12
```

The PDF needs a conventional pdfLaTeX installation with the packages in the
preamble. No font files are included or required beyond a normal TeX installation.
Compilation is not promised to be byte-identical across different TeX versions.
The semantic theorem labels all have the prefix `epnf:` to reduce collisions
when integrating the source into a larger report.

## Suggested placement

`Combinatorics/Ramsey/Research/GowersSzemeredi/endpoint-partition-normal-forms/`

This is a proposed destination only. No repository files or proof-status ledgers
were modified while producing this archive.
