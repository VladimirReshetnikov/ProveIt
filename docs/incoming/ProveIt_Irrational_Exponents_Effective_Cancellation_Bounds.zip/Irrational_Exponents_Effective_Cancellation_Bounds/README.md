# Effective fixed-defect bounds for irrational exponents

This six-page report proves that for every positive irrational a, each fixed factor defect in derivatives of x^(x^a) has only finitely many cancellation cells.

- For r >= 2, the uniform upper bound is (2 floor(r/2))^2 - 1, independent of the algebraic degree
- There are no cancellations at defect one
- At defects two and three there is at most one physical cancellation for each fixed irrational exponent; both bounds are sharp
- Transcendental exponents have no cancellations; algebraic degree greater than 2 floor(r/2) also excludes them on that defect
- For an exactly specified algebraic exponent, polynomial elimination gives the complete finite zero list and a computable threshold
- A direct coefficient-size estimate gives an explicit order bound as well

The proof compares residual polynomials at distinct algebraic conjugates and uses their distinct leading lines with Bézout's theorem. It strengthens the earlier sufficient algebraic-degree threshold to every fixed defect. Rational exponents retain their separately studied behavior.

For each exponent a=1±1/sqrt(3), the complete physical defect-two zero list is exactly (N,k)=(3,0). A separate family shows that no derivative-order cutoff can be uniform as the irrational exponent varies, despite the uniform bound on the number of cells.

## Files

- `article.pdf`, `article.tex`: full report and editable source
- `verify.py`, `checks.json`: exact degree, odd-factor, structural-point and elimination checks
- `check_low_defect_injectivity.py`: separate exact check of both low-defect quadratic forms and their derivative identities
- `build_local.sh`: optional preparation-environment LaTeX build helper

## Reproduction

Run `python verify.py` and `python check_low_defect_injectivity.py` with Python 3 and SymPy installed. The first checks exact polynomial identities through defect six, the unbounded-order example, and both directions of the quadratic ideal equivalence. The latter directly verifies the sharp one-cell argument's formulas.

Run `pdflatex article.tex` twice on a standard LaTeX installation. The optional helper includes environment-specific font-map setup.

The effective procedure requires an exact algebraic minimal polynomial and a positive-real embedding, rather than a decimal approximation. No favorable computational complexity, complete growing-defect classification, or global support-density theorem for arbitrary algebraic exponents is claimed. Classical Bézout and elimination inputs are explicit, without a worldwide priority claim or formal-proof claim.

The complete proof and final transcription received independent mathematical review. All six rendered pages were visually inspected; the final build has no LaTeX warnings or unresolved references.
