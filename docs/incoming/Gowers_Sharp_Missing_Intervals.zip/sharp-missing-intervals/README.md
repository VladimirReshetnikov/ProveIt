# Sharp Spectral Detection of Missing Intervals

**Exact moment tradeoffs, extremal rigidity, and quantitative recurrence in Gowers's argument**

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov, 6 October 2026.

## Main files

- `sharp_missing_intervals.tex`: complete, standalone LaTeX manuscript with embedded bibliography.
- `sharp_missing_intervals.pdf`: compiled manuscript.
- `verify.py`: exact symbolic/rational checks and floating-point regression tests.
- `verification_results.json` and `verification_run.txt`: results from the supplied script.
- `INTEGRATION.md`: proposed repository placement, dependency split, and status safeguards.
- `SOURCE_AUDIT.md`: inspected source identifiers and comparison conventions.
- `requirements.txt` and `Makefile`: reproduction helpers.

## Main mathematical results

Theorem 2.1 solves the first-window missing-arc Fourier minimax problem and the corresponding noisy-gap mass problem exactly. It also proves uniqueness and describes the extremizing measures. Theorem 8.1 gives critical-grid geometric stability; Theorem 8.3 gives quantitative stability of the full mass extremizer.

Corollary 7.2 replaces the proof-supported version of Gowers's Lemma 5.2 by a weighted estimate with frequency at most `floor(N/M)-1` and unnormalized coefficient at least `W*M/(N-M)`. The underlying gap is **open**. The stronger original half-open exclusion implies that hypothesis, but open-gap extremizers may charge an endpoint and therefore need not satisfy the original half-open condition.

Theorem 9.1 optimizes the recurrence deduction from a stated Weyl input. Corollary 9.3 uses the explicit input recorded in ProveIt, obtaining

    b_k = (1 - 1/(4*k)) / (2^(k-1) + 1)
    A_k = (16 * 1000^(2^(k-1)))^(1/(2^(k-1)+1))

and a recurrence bound `A_k * T^(-b_k)`, at the stated Weyl threshold. This is an improvement of the selected local argument, not a claimed best-known Diophantine-approximation bound.

## Status

Unrefereed research draft. Full mathematical proofs of the stated refinements are included. The Weyl estimate is an identified external input. General supported-moment and positive-polynomial machinery is classical and is credited and proved in the required form.

Historical priority of the explicit extremal formula and related refinements is not established. No improved global Szemeredi bound is claimed. No new Lean code is supplied, and no theorem in this package has been verified in a proof assistant. The existing Lean repository was inspected, not built.

## Reproduce

A normal TeX Live or MiKTeX installation with `amsmath`, `amsthm`, `lmodern`, `microtype`, `geometry`, `hyperref`, `xurl`, `fancyhdr`, `enumitem`, `booktabs`, and `listings` is sufficient.

```sh
latexmk -pdf sharp_missing_intervals.tex
python -m pip install -r requirements.txt
python verify.py
```

Alternatively, run `pdflatex sharp_missing_intervals.tex` three times. The checks use no network access after dependencies are installed. They overwrite only their local JSON output. The recorded run used Python 3.13.5. The dependency versions are the versions tested in that run, not a claim that they are the latest versions.

The suite passed 36 symbolic autocorrelation identities, 2 exact example identities, 120 matrix/root/weight cases, 250 linear programs, 5,411 finite-cyclic indicator cases, 300 random stability checks, and 1,000 exact rational rounding cases. Floating-point LP and root checks are not proof certificates.

## Proposed destination

`Combinatorics/Ramsey/Research/GowersSzemeredi/sharp-missing-intervals/`

This archive does not modify ProveIt or change its formalization status ledger.
