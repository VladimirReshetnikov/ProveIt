# Binomial separation and endpoint bounds for uniform progression counts

Research manuscript for the ProveIt Ramsey program, dated 6 October 2026.

## Mathematical results

The article proves an explicit `(1,5,10)`-separating alphabet
`{0,1,4,13}` modulo `80`, its cyclic digit lifts, and an all-moduli embedding.
The resulting six-binomial reciprocal growth exponent is at most
`log(80)/log(4) = 3.160964047443681...`, compared with the general exponent `5`
recorded in Deng–Tidor–Zhao (2025). The conjectured exponent `3` is not proved.

An exact nine-copy circle transfer and a scale-uniform endpoint argument give

- `rho_4(alpha) = O(alpha^5)`;
- `rho_6(alpha) = O(alpha^(5 + 9 log(4)/log(80)))`, with exponent
  `7.847232636916080...`.

These consequences use the credited Shi–Dong (2026) coloring theorem. The
analytic realization is credited to Deng–Tidor–Zhao and is reproved, in the
prime-modulus indicator case needed here, in Section 7. Exact rational-density
examples are also supplied by a pullback and deterministic editing argument.

Two further theorems identify limitations: no non-singleton cyclic seed for
`(1,5,10)` can have a perfect `r^3`-element target, and a scalar polynomial color
of degree at most `k-1` cannot avoid symmetric `k`-progressions in dimension
larger than `k^2/4`. The latter extends to `t` polynomial coordinates with bound
`t k^2/4`.

## Files

`article.tex` is self-contained, including its bibliography; `article.pdf` is
the compiled 19-page article. `construction.py` implements the finite label
construction and exact membership given an input coloring. `verify.py` runs
reproducible exact finite checks; `certificate.json` and `verification.log`
record a successful run. `SOURCE_AUDIT.md` documents sources and comparisons.
`FORMALIZATION_PLAN.md` gives a staged integration plan without implying that
Lean proofs are included. `Makefile` builds and checks the package.

## Reproduction

The TeX document uses standard TeX Live packages and pdfLaTeX. Run:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
python verify.py --output certificate.json
```

Equivalently run `make`. The Python files need only the standard library;
Python 3.13.5 was used for the supplied successful run. They are written for
Python 3.10 or later. Finite injectivity and rational volumes are checked with
exact arithmetic. Decimal logarithms only report approximate exponents.

The verification covers 64 seed images, digit lifts through 262,144 ordered
triples, 248,000 equal-arc grid progressions, and 2,211,300 nine-copy grid
progressions, as well as coefficient and membership checks. These finite tests
are supplementary checks, not substitutes for the mathematical proofs and not
a Lean formalization. No alphabet optimality claim is supported by the search.

## Suggested integration

Place this directory at:

```text
Combinatorics/Ramsey/Research/GowersSzemeredi/binomial-separation-six-progressions/
```

Do not add these results to a formal-proof ledger until actual proofs and the
analytic interfaces are checked. The manuscript does not replace any existing
formal theorem. In particular, `Section04.lean` stores the Gowers conjectures as
non-asserting `Prop` definitions. It uses `k+2` for the progression length,
where this manuscript uses `k`.

## Research and attribution status

The constructions and deductions are presented with mathematical proofs and
explicit hypotheses. They improve the specified estimates in the inspected
sources. Literature priority is not certified. Gowers's four-term
counterexample and Shi–Dong's even-length counterexamples are credited, not
rediscovered or claimed as original here. There is no claim of an improved
general Szemerédi bound, a classical graph Ramsey bound, or a resolution of the
superpolynomial-decay conjectures. The Shi–Dong input is a preprint theorem.
