# Report54 Unrestricted finite global sandpile stabilization

Report54 gives an explicit fixed-arity positive-integer polynomial for existence of a finite legal globally stabilizing sequence on the threshold-six lattice Z³, with arbitrary repeated topplings. It retains Report50's raw eight-field physical input: a base-32 stable periodic tile with digits 0–5 and a base-32 finite nonnegative patch with digits 0–15.

- One positive ordinary input and 3,262 strictly positive witnesses
- 1,897 equality residuals and 14,571 binary +, −, × gates, with fixed literals free
- Exact total degree 18
- Two paid raw radix conversions, variable radix b=32^L, exact 16h=b and count cap h−1
- A finite stabilizing supersolution, not necessarily the actual legal odometer
- Explicit constructive Pell dependency and independently audited source

The event is finite total global stabilization. A target firing or an infinite locally finite stabilization is a different event. No finite-fold, real-witness, minimality, formalization, practical-witness-size, or paid raw-program-compiler claim is made.

## Read first

- `article/Report54.pdf`: complete article
- `article/Report54.tex`: editable LaTeX source
- `science/PROOF.md`: unchanged scientific proof
- `science/evidence/polynomial-dag.json`: authoritative fully expanded polynomial graph
- `independent_audit/AUDIT.md`: separate adversarial audit, PASS relative to the pinned Pell theorem
- `hardness-interface/REVIEW.md`: separately conditional finite-total hardness interface
- `hardness-interface/CORRECTIONS.md`: mathematical readings of defects in the printed primary source, not an author-issued erratum
- `audit_replay/README.md`: exact safe replay interface and restrictions
- `verification/manuscript-review/AUDIT.md`: final independent mathematical and all-page manuscript review, PASS
- `verification/`: release receipts and visual review record

The science and audit directories are frozen provenance copies. Historical instructions and absolute paths inside them are preserved, not release entry points. Use only the new release utility and portable replay below. Do not run the original scientific builder, historical replay programs, upstream programs, saved schedules, or Lean to reproduce this release.

## Mathematical dependencies

The raw physical equivalence uses the constructive exponentiation characterization in mathlib4 commit `ac77769fabe23cb237559e7f56578dbead91499f`, `Mathlib/NumberTheory/PellMatiyasevic.lean`, theorems `matiyasevic` and `eq_pow_of_pell`. Its exact source text is in `dependencies/pell-source.lean`; no Lean process was run.

The article's separate computability corollary additionally assumes the pinned Report35 fixed-background finite-total loader theorem and its inherited U15 universality dependency. It supplies original period-multiple translation into the exact raw interface and an original semidecision procedure. The loader's particular fixed tile and binary finite seeds are sufficient. No arbitrary-program-to-U15 compiler was reconstructed or charged, and no first-firing alarm is substituted for global halting. Removing this conditional section does not alter the physical equivalence theorem or polynomial ledger.

## Integrity and isolated replay

The checked environment is Debian GNU/Linux 13 with Python 3.12.14. Python 3 standard library is sufficient for integrity checks and audit replay. Integrity verification checks POSIX modes; Windows execution is not part of this release verification. Run with isolated Python (`-I`). All replay outputs must be fresh absolute external directories, outside the release. The bundle may be read-only. The manifest SHA256 must come from a trusted accompanying delivery, not from an unverified file claiming its own integrity.

From any directory:

    python3 -I /path/to/BUNDLE/release.py verify --manifest-sha256 TRUSTED_MANIFEST_SHA256

    python3 -I /path/to/BUNDLE/audit_replay/replay_audit.py --output /fresh/external/audit

The adapter independently pins the frozen DAG and six checker/receipt files, executes only the three inspected independent checkers, and reproduces all three scientific receipts byte-for-byte. It redirects only the mutation harness's one historical DAG read to the bundled pinned graph, with no fallback and no source rewriting. Child Python processes use `-I`; normal and `-O` mutation modes remain distinct. The adapter checks the entire bundle's entry inventory, bytes, sizes, modes and modification times before and after replay.

Its twenty expected mutation rejections exercise semantic/structural checks with the hash guard disabled only for temporary corrupted graphs. No full nested Pell witness is constructed; finite tests corroborate, rather than replace, the proof and exact polynomial reconstruction.

## Deterministic PDF and ZIP

The PDF build needs a locally installed TeX Live/pdfTeX with the packages named in the LaTeX source and Latin Modern fonts. It works offline, uses writable caches only in its fresh output directory, and disables shell escape. Three passes resolve references. A sealed rebuild verifies byte identity with the packaged PDF. Identical installed TeX and font versions are the reproducibility environment; cross-version PDF byte identity is not promised.

    python3 -I /path/to/BUNDLE/release.py build-pdf --manifest-sha256 TRUSTED_MANIFEST_SHA256 --output /fresh/external/pdf-build

    python3 -I /path/to/BUNDLE/release.py archive --manifest-sha256 TRUSTED_MANIFEST_SHA256 --output /existing/external/parent/Report54-reproduction.zip

The ZIP contains sorted members with fixed UTC timestamps, Unix permissions, and uncompressed ZIP_STORED data, avoiding compression-version differences. It authenticates the manifest and exact inventory before packaging and checks every resulting member. Outputs cannot overlap the release, follow symlink paths, or overwrite existing destinations. Verification, PDF building, ZIP creation and audit replay preserve release bytes and metadata. The author-only `seal` and `--draft` options are not needed for reproduction.

## Provenance and what was actually checked

The source graph is SHA256:

    8622585bcafaf9b3aee84e12f229beb17a33d27d6f1bf0b6cb6bc956ee4ac759

The included original receipts record prior scientific checks. New release receipts record the actual isolated replay, deterministic PDF builds, final full-page visual inspection, and source-preservation comparison. Original packets remain unchanged. The safe replay does not execute their builders, schedules, simulations or theorem-prover source.

Every deliverable is described by `MANIFEST.json`, which excludes itself. ZIP and final manifest hashes must remain outside the archive to avoid self-reference. A terminal independent release check is an additional delivery gate, not a mathematical dependency of the theorem.
