UNIFORM AVOIDANCE OF GEOMETRIC PROGRESSIONS
AND EXPONENTIAL-POLYNOMIAL PATTERNS
Research manuscript prepared for Vladimir Reshetnikov
Mathematical development and exposition with ChatGPT
7 October 2026

CONTENTS AND MAIN RESULTS

The article proves the following statements.

1. For every 0 < epsilon < 1, one closed, symmetric, 1-periodic subset
   F of the real line has measure at least 1 - epsilon/2 in every unit
   interval and omits infinitely many terms of x + s q^n for every
   real x, every nonzero real s, and every q in (0,1), simultaneously.

   Its compact section in [0,1] answers negatively Question 1 of
   Burgin--Goldberg--Keleti--MacMahon--Wang, "Large sets avoiding
   infinite arithmetic / geometric progressions" (2023).

2. A general normalized hitting theorem applies to compact
   finite-dimensional polynomial families whose terms contract between
   two fixed positive ratios below one and whose parameter degrees grow
   at most polynomially in the sequence index.

3. One common set also avoids every nonzero finite real exponential
   polynomial A_n = sum_i P_i(n) q_i^n, with q_i in (0,1), arbitrary
   real polynomial coefficients, and arbitrary finite component count.
   Equal bases are combined before deciding whether the expression
   is nonzero. This includes all nonzero real solutions of homogeneous
   constant-coefficient recurrences whose characteristic roots all lie
   in (0,1), including repeated roots.

4. At rational accuracy the compact section can be effectively closed
   with computable Lebesgue measure. There are nested finite unions
   K_N of closed rational intervals with
       0 <= measure(K_N) - measure(K) <= epsilon * 2^(-N).
   Finite avoidance certificates with positive rational margins can
   be found algorithmically on the stated compact parameter boxes.

The manuscript includes the complete probabilistic argument, the
continuum-parameter count, the signed dominant-term reduction, the
effective search and its termination proof, ten further research
directions, and explicit limitations. The general Erdos similarity
conjecture for arbitrary infinite patterns is not claimed to be solved.

FILE MAP

uniform_geometric_avoidance.pdf   The complete article.
uniform_geometric_avoidance.tex   Main LaTeX source and bibliography.
sections/                        Nine modular LaTeX source files.
figures/synchronized_scales.pdf   Included vector figure used by LaTeX.
figures/synchronized_scales.png   A convenient raster copy of the figure.
figures/make_figure.py            Optional figure regeneration script.
verification/verify_exact.py     Standard-library exact finite checks.
verification/results.json       Deterministic output of the successful run.
verification/README.md          Explanation of the checks and their scope.
SOURCE_AUDIT.md                  Source revisions and detailed proof audit.
THIRD_PARTY_NOTICES.txt          Attribution of the inherited construction.
LICENSE-APACHE-2.0.txt            Retained upstream license text.
Makefile                        Convenience targets for build and checks.
MANIFEST.sha256                  SHA-256 checksums of the package files.

BUILDING THE PDF

Requirements: a TeX Live or equivalent installation providing XeLaTeX,
xdvipdfmx, the Latin Modern fonts, and the packages named in the main
source. The supplied figure PDF means that Python is not needed to
build the article. No network access is needed for a rebuild once the
TeX dependencies are installed.

From this directory:

    make pdf

The equivalent explicit commands are:

    xelatex -no-pdf -interaction=nonstopmode -halt-on-error uniform_geometric_avoidance.tex
    xelatex -no-pdf -interaction=nonstopmode -halt-on-error uniform_geometric_avoidance.tex
    xelatex -no-pdf -interaction=nonstopmode -halt-on-error uniform_geometric_avoidance.tex
    xdvipdfmx -o uniform_geometric_avoidance.pdf uniform_geometric_avoidance.xdv

Three XeLaTeX passes settle the cross-references, contents, and table layout. The
separate xdvipdfmx step makes completion of the PDF export explicit.
Use XeLaTeX for this source; pdfLaTeX cannot process fontspec. The
released PDF was built with the commands above and visually reviewed.

To regenerate the explanatory figure, optionally install Python with
matplotlib and NumPy and run:

    python3 figures/make_figure.py

The figure uses exact rational sampling before converting coordinates
for plotting. It is explanatory and is not a proof certificate.
Figure regeneration is unnecessary for the supplied PDF build.

RUNNING THE EXACT CHECKS

Python 3.10 or later is sufficient; no third-party Python packages
are required for the verification program.

    make verify

or:

    python3 verification/verify_exact.py

The accompanying run passes 91,759 exact checks. These include window
geometry, original-index selection, exact equality cases, grid
addresses, periodic density budgets, and exhaustive finite probability
identities. One routing model enumerates 262,144 complete assignments
and checks all 16 joint outcomes at three rational probabilities.
An intentional negative control detects failure when terminal addresses
are shared. The output is deterministic.

The program does not construct the full infinite avoiding set, perform
real quantifier elimination, prove all continuum-parameter statements,
or provide a Lean formalization. Those distinctions are explained in
the article and the verification README.

RESEARCH AND REVIEW STATUS

The work was developed from a close reading of the fixed-ratio
OpenAI manuscript and a selective review of ProveIt, with a targeted
primary-source literature search. The inherited construction and the
new extensions are separated explicitly. Repository revisions and
source identifiers are retained in SOURCE_AUDIT.md.

The proofs were independently checked within the mathematical
development of this package. They have not undergone external peer
review or formal proof-assistant verification. Novelty is assessed
relative to the sources reviewed; absolute priority is not certified.

INTEGRATION INTO PROVEIT

Keep this directory intact when adding it to a research-report area:
the main source uses relative section and figure paths. The article is
self-contained mathematically apart from its explicitly cited classical
real-algebraic-geometry inputs, and it makes no assumption that another
repository's flagship theorem has already been verified.

The natural formalization boundaries are finite routing probability,
finite polynomial avoidance certificates, and countable measure
assembly. Later repository integration should retain the third-party
notices, source provenance, verification-scope distinctions, and any
applicable repository conventions.

Neither remote repository was modified in preparing this package.

ATTRIBUTION AND LICENSE

The ordered-tree routing construction and parts of its mathematical
exposition adapt the Apache-2.0-licensed OpenAI source identified in
THIRD_PARTY_NOTICES.txt. The upstream Apache 2.0 license is included
for those portions. External research papers are cited; their text
is not bundled. The notices do not imply endorsement by their authors.

CHECKSUMS

From this directory, verify the supplied files before rebuilding with:

    sha256sum -c MANIFEST.sha256

A rebuild may change PDF metadata and hence its byte checksum without
changing the mathematical content.

