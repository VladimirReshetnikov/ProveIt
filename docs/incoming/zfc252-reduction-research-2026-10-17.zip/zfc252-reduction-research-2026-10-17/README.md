# State-reduction research for candidate-permutation252

**Research status: no verified machine with fewer than 252 working states
was obtained.** This packet contains a mathematical report, stronger symbolic
verification methods, **181 newly proved guarded source-case contracts**,
source-invariant certificates, completed search records, and independent
validation scripts. The original 252-state machine
is included unchanged as benchmark input. No smaller transition table is
presented as satisfying the ZFC consistency specification.

Start with [`report/report.pdf`](report/report.pdf). Its editable source is
[`report/report.tex`](report/report.tex). The report states the new simulation
lemmas and their proofs, develops a worked unbounded register transfer,
separates the different proof claims, and explains the exact scope of both
the positive certificates and the remaining checker failures.

## Fixed problem and source identity

The intended model is a deterministic, one-tape, two-symbol Turing machine
with only L/R moves, entirely blank input, and a two-way infinite tape.
Working-state counts exclude the halt label. The intended conclusion for
an explicit smaller table M would be

```
ZFC proves: Nonhalt(M, blank) <-> Con(ZFC).
```

The source snapshot is
[`VladimirReshetnikov/ProveIt@43026ff42f0939f09b9e95495248cfadcad38e38`](https://github.com/VladimirReshetnikov/ProveIt/tree/43026ff42f0939f09b9e95495248cfadcad38e38).
The candidate directory is
`Computability/BusyBeaver/Research/ZFC/candidate-permutation252`.

| Artifact | Exact SHA-256 |
|---|---|
| Canonical `zfc_permutation252.tm` | `8dae0c2359aa8bf87d32543b9e53e1f87fe4716c016a4e2fd174bfe09e520797` |
| Original-label `zfc_permutation252_old.tm` | `939f99d602c8f7057517c4369279de99e30827050fc743581df83f26aaf1b713` |
| Literal source `Prog254.v` | `1fbc30fcf82a1442ed88d1a1dde412630a431d32a7265d22bdf8517bffe01746` |
| Inherited strict affine executor | `da3cc5f3f5f4d5ebde71c9f353c9ddead010d9c8529d8ae97b6e9ccfe1ba21ce` |

The machine has 252 working states, 504 transitions, and one halting
transition. Canonical start/halt labels are 0/252; experimental original
start/dispatch/halt labels are 64/96/254. The actual logical-to-physical
register map is `(6,2,0,4,3,7,8,5,1)`.

The reproduced complete blank bootstrap has 82,552 transitions, final head
2, marker 1, header 42, empty program counter, nine zero primary registers,
and 65 spare blocks. Spare index 8 has value 1; all the others have value 0.
The complete tape has 77 one-cells. The independent audit also replays 64
runtime instructions and all 8,391 conditional affine instruction cases.
The latter audit is conditional on the four retained unbounded register-box
contracts; a Python replay is not a new Lean proof.

## New results

### Implemented binary induction: 181 previously rejected contracts

The principal positive result is a universal binary-countdown rule with
complete relative tape interfaces and full affine matrix endpoints. It
proves **181 distinct mutation/source-case contracts** rejected by the
earlier constant-offset checker. These are local contracts under the
verified source-phase and guard domains, conditional on the attributed
register-box contracts. They are not 181 new machines.

The diagnostic examines 51,290 recorded first failures and finds 9,253
countdown-shaped recurrences. Separate universal replay verifies all 9,253
positive bodies; 9,239 also have clean zero exits, and 9,101 of those cover
the full original source-case domain. Exactly 138 match an exact source
endpoint in PC, affine gap, and all nine primary matrix rows, with full
prefix coverage.

The adaptive continuation checks the remaining affected cases of all 138
table recipes. In five rounds, 568 additional conventional checks expose
58 new countdown candidates, of which 43 yield further complete contracts.
All 138 recipes eventually encounter another rejection: 123 have no
eligible countdown at that case and 15 fail the exact source endpoint
comparison. **There is no all-case survivor.**

The strongest worked example is fold **78 → 11**, source case **8231**,
using the original state labels and physical register indices:

```
R_7 := R_7 + R_8(entry)
R_8 := 0
all other primary registers unchanged
final PC: 111010011
gap: the same arbitrary 40 + g, with g >= 0
source clock: 3 * R_8(entry) + 2 successful steps
```

Its invariant is simply that all primary registers are natural numbers.
The body returns to the complete dispatch interface and preserves the
invariant, including the final positive iteration. The separately checked
zero exit completes the induction. The 451 body and 209 zero-exit literal
step counts exclude expanded box/scan runtimes and witness positive
progress; they are not total binary runtimes. The same fold subsequently
fails case 8227 under the 1,000-rule diagnostic budget, so this contract
does not certify the folded table as a consistency machine.

`binary_loop_experiments/worked_certificate.json` contains the complete
worked proof record and later obstruction. `binary_loop_experiments/NOTES.md`
documents the implemented rule, full accounting, and reproduction commands.

### Supporting proof interface and completed searches

The supporting proof extension replaces the original none/one-effect register
oracle with a vector of integer offsets. Several correctly connected box
operations may implement a source step or a positive source block. Positive
decrement appends a zero spare block; its physical effect is retained in the
proof and existentially hidden only at a justified source frame boundary.
Unknown register guards may be split exhaustively into zero and positive
cases. Every branch must pass, and exhausted search fuel is a rejection.

| Experiment | Family size | Outcome |
|---|---:|---|
| Known-zero specialization | 55,471 fold recipes | No survivor |
| Composed effects, arbitrary initial registers | The same 55,471 recipes | No survivor |
| Composed effects and source intervals | The same 55,471 recipes | No survivor |
| Positive finite source-reference blocks | The same 55,471 recipes | No survivor |
| Unbounded source countdowns, singleton projection | The same 55,471 recipes | No additional targets; no survivor |
| Unbounded source countdowns, DBM equality projection | The same 55,471 recipes | No additional targets; no survivor |
| Inductive binary countdowns with full matrix endpoints | 51,290 selected first failures; continuation of 138 recipes | 181 new guarded contracts; no all-case survivor |
| Exhaustive splitting of newly unknown guards | 22,923 selected recipes from that family | No newly accepted first contract; no survivor |
| Completed two-incoming target search | 2,898,046 assignments | Complete partition; no survivor; empty frontier |
| Shorter delimiter plus one extra detector edit | 14,042 recipes | No survivor |
| Single source-layout transformations | 238 legal operations | No reduction in the maximum zero run |
| Deterministic source-layout beam | 18,561 distinct layouts, width 12 | No validated smaller table |

The first six rows overlap exactly as recipe sets; do not add their counts.
The binary countdown extension selects failures from the same family.
The splitting follow-up uses 46,844 splits and 78,645 trace replays. Its
64-split-per-contract and 1,000-rule-per-branch limits are certificate-search
limits. The completed two-incoming family contains 46 eligible deletion
labels and `46 * 251^2` assignments. Its separate partition audit accounts
for 737 branch entries, 184,296 prune entries, and all 185,033 partial nodes.

Stronger source-invariant computations use 24 explicit-value/residue domains,
a full finite relational abstraction with 7,725,677 reachable abstract
control/tuple pairs, and difference-bound matrices at four thresholds.
All still exclude the same six source guards as the previously known phase
invariant. The DBM certificates contain cross-register information at 698
controls and are independently checked using only integer arithmetic.

The final source extension recognizes 1,433 exact countdown loops and retains
full affine register matrices and value-dependent source clocks. It applies
25,952 loop summaries, including 25,589 with an unbounded upper iteration
count. Neither projection through entry singleton values nor through exact
DBM equalities yields an additional constant-offset binary target. Both
complete fold reruns reproduce the fixed-prefix journal byte-for-byte.
`loop_experiments/NOTES.md` supplies actual source sites, exact formulas,
and a small API exposing matrix targets for further binary verification.
The new binary rule then admits some of these matrix targets directly,
without reducing them to constant offsets.

These results concern specified sufficient certificate procedures. A
rejected recipe can reflect an unsupported symbolic rule or exhausted fuel.
The packet establishes neither that every rejected machine is incorrect nor
that 252 is a lower bound.

## Proof and validation boundary

`proof_audit/compositional_box_simulation.md` gives the ordinary composition,
spare-frame, and positive macro-simulation arguments. A future smaller table
still needs its own complete blank initialization and unbounded certificate
set. `proof_audit/binary_countdown_acceleration.md` proves the new induction,
including translation-equivariant head witnesses and invariant preservation.
`proof_audit/binary_loop_audit.md` audits its actual implementation, prefix
coverage, zero boundary, and source endpoint comparisons.

`proof_audit/zfc_proof_boundary.md` records the exact inspected Lean
declarations and a set-coded ZFC-formalizability argument. The maintained
external Lean endpoint, an ordinary mathematical proof formalizable in ZFC,
an exported object-language ZFC derivation, and the stronger PA proof-code
internalization are distinguished. This packet does not claim a new Lean
build, an exported internal ZFC proof, or completion of the PA project.

The new regression suite includes 20 algebraic controls, 1,020 finite
composite bodies with 2,190 fully covered leaves, 26,670 independently
evaluated concrete comparisons, and 405 prepared literal register-box
excursions comprising 19,179 Turing transitions. Fifty-four controls detect
the wrong physical tape when an appended zero spare is omitted. Finite
examples test the implementation; the mathematical lemmas justify the
unbounded abstraction.

A separate direct source parser checks all 8,390 nonhalting control edges,
all 1,433 countdown summaries, and 5,732 probes totaling 45,556 source steps.
Forty-eight nonidentity matrix controls independently exercise the signs
and physical-register permutation in the DBM equality projection.

The binary countdown checker compares its observer with the original
executor on all 8,391 baseline cases and freshly replays all 181 positive
contracts. The separate continuous literal transfer controls use 16
prepared complete frames, 42,008 actual binary transitions, and 128
independently executed source steps. They compare entire final tapes and
heads; twelve controls detect omitted spare blocks. These runs contain no
intermediate reset or symbolic shortcut. They validate the implementation
on finite inputs; the universal replay and induction justify the arbitrary
counter result. The earlier 405 individual box fixtures reset their head
and control between contracts and have a different scope.

## Quick verification

Use Python 3.12 with assertions enabled. The principal verification path
uses the standard library and does not need network access, NumPy, Lean,
Coq, or the complete ProveIt checkout. From the extracted packet root:

```sh
python3 verify.py
```

This validates the packet checksums and input identities, reruns the
principal baseline audit, independently checks the source DBM certificates,
replays the complete two-incoming assignment partition, and exercises the
new oracle regression suite. It also reruns the independent countdown
catalogue and matrix-projection controls and regenerates both source-loop
frontier sets. It checks the binary-loop manifest, freshly replays all 181
new contracts, and independently reruns the continuous literal transfer
controls. Temporary outputs are kept separate from the
delivered records. The original broad searches are represented by their
complete records; quick verification does not rerun every search family.

Individual checks can also be run directly:

```sh
python3 proof_audit/check_dbm_certificate.py \
  proof_audit/relational_dbm_threshold2.json \
  proof_audit/relational_dbm_threshold8.json \
  proof_audit/relational_dbm_threshold32.json \
  proof_audit/relational_dbm_threshold128.json
python3 proof_audit/oracle_regressions.py
python3 -B binary_loop_experiments/verify_diagnostics.py
```

The oracle-regression command regenerates its local result JSON. To retain the archived
records byte-for-byte while rerunning experiments, use a working copy.

## Reproducing the searches

The files in `binary_experiments/NOTES.md` and
`compiler_experiments/NOTES.md` give the exact families, parameters,
dependencies, and additional commands. The variable-length source extension
is documented in `loop_experiments/NOTES.md`; the binary induction in
`binary_loop_experiments/NOTES.md`. Principal commands are:

```sh
python3 binary_experiments/multieffect_fold_search.py
python3 binary_experiments/multieffect_phase_search.py
python3 root_experiments/specialized_folds.py
python3 root_experiments/split_guard_folds.py
python3 binary_experiments/delimiter_repair_search.py

python3 compiler_experiments/refined_phase.py --output /tmp/refined-phase.json
python3 compiler_experiments/joint_phase.py --cap 2 --output /tmp/joint-phase.json
python3 compiler_experiments/delimiter_rebracket.py \
  --output /tmp/delimiter-layout --width 12 --rounds 12
python3 compiler_experiments/reference_block_folds.py \
  --output /tmp/reference-blocks --block-limit 64 --seconds 600
python3 loop_experiments/affine_reference_loops.py \
  --output /tmp/source-countdown-blocks --hop-limit 64 --seconds 600
python3 loop_experiments/affine_reference_loops.py \
  --output /tmp/source-countdown-dbm --hop-limit 64 --seconds 600 --dbm-projection

python3 -B binary_loop_experiments/trace_cutpoints.py \
  --output /tmp/binary-countdown-traces
python3 -B binary_loop_experiments/check_countdowns.py \
  --input /tmp/binary-countdown-traces/results.json \
  --output /tmp/binary-countdown-certificates
python3 -B binary_loop_experiments/screen_remaining.py \
  --input /tmp/binary-countdown-certificates/results.json \
  --references /tmp/binary-countdown-certificates/matrix_reference_targets.json \
  --output /tmp/binary-countdown-remaining

python3 upstream/Computability/BusyBeaver/Research/ZFC/permutation252_lazy_context_search.py \
  --repo upstream --seconds 600 \
  --output /tmp/lazy-context-results.json \
  --scratch /tmp/zfc252-lazy-context-work
```

The split-guard follow-up reads the saved universal composed-effect results;
run the universal search first if replacing that record. Several of the
small experimental scripts write to their own result paths, while scripts
with `--output` accept a separate destination. The lazy driver requires its
scratch directory to lie outside the selected source snapshot.

DBM *search*, unlike its independent checker, requires NumPy:

```sh
python3 proof_audit/relational_dbm.py \
  --threshold 2 --output /tmp/dbm-threshold2.json
```

Repeat with thresholds 8, 32, and 128 for the other recorded certificates.
Wall times depend on the host. The reproducible claims are the exact inputs,
completed declared families, certificate obligations, and measured outcomes.

## Contents and repository incorporation

| Location | Contents |
|---|---|
| `report/` | LaTeX source, PDF, and build instructions |
| `upstream/` | Selected exact pinned inputs and inspected source files |
| `binary_experiments/` | Composed-effect oracles, fold records, delimiter edits, complete lazy journal |
| `compiler_experiments/` | Refined and joint source invariants, layout and reference-block searches |
| `loop_experiments/` | Exact unbounded countdowns, matrix frontiers, two complete projection searches |
| `binary_loop_experiments/` | Implemented binary induction, all 181 certificates, diagnostics, continuation, worked example |
| `root_experiments/` | Specialized/split guards, decoder analysis, baseline audit |
| `proof_audit/` | Mathematical notes, DBM certificates, independent checker and regression suite |
| `verify.py` | Portable principal verifier |
| `PROVENANCE.json` | Source pin and exact delivered upstream-file identities |
| `ATTRIBUTION.md` | Authorship and retained upstream license boundaries |
| `MANIFEST.sha256` | SHA-256 of every delivered file except this manifest itself |

`upstream/` is a selected subset. Some unmodified upstream documentation
links to files outside that subset, and it does not contain a complete Lean
or Coq build closure. The older duplicate source-block journal was omitted;
the final halt-aware run covers the same 55,471 recipes and reproduces that
earlier journal byte-for-byte.

A suitable incorporation is a new research directory alongside
`candidate-permutation252`, linked from the research index. Retain the
benchmark directory unchanged and describe this packet as a research
extension with 181 new local contracts and no improved state bound. The
supplied mathematical interface, concrete certificates, and remaining-case
records are intended to support a subsequent construction.
