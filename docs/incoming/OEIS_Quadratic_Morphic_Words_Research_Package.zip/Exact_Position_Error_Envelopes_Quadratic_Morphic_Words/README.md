# Exact position-error envelopes for quadratic morphic words

Research article and exact verification package, October 1, 2026.

## Main result

For the two-parameter substitution

```text
0 -> 1
1 -> 1 0^a 1^b
```

put

```text
q = (sqrt((b+1)^2 + 4a) - (b+1))/2.
```

The report proves that prefix and position discrepancy is bounded exactly
when `a <= b+1`. In that regime, with

```text
C = (a-q)/(1-q^2),
```

the sharp position-error envelopes are

```text
q-C < (1+q)n - position_of_nth_1 < q(1+C),
1/q-C-1 < (1+1/q)n - position_of_nth_0 < C/q.
```

Every endpoint is a subsequential limit and none is attained.

The special cases `(a,b)=(1,2)` and `(2,1)` sharpen the posted OEIS
position bounds associated with A284368--A284371. A284368 is already linked to
the generalized s-Wythoff pair A184484--A184485, so that specialization is
presented as a calibration and alternative derivation. The principal claims
are the two-parameter theorem and the sharp A284369--A284371 envelopes. The
report also proves that the complete state attractors are intervals in both
cases, constructs extremal subsequences, and derives rational generating
functions for their indices.

## Files

- `article.tex` — complete LaTeX source.
- `article.pdf` — compiled paper.
- `code/verify.py` — exact standard-library verification.
- `code/make_figures.py` — deterministic figure generation.
- `data/verification.json` — recorded successful verification output.
- `figures/` — PDF and PNG versions of both figures.
- `oeis_proposed_updates.txt` — draft OEIS comments; not submitted.
- `research_status.md` — novelty and verification boundaries.
- `build.sh` — reproducible PDF build.

## Verify

Python 3.10 or newer is sufficient. No third-party package is required for
the exact verifier.

```sh
python code/verify.py
```

The included run reports 201,686 exact/counting checks. It checks the general
Bellman formulas for 119 parameter pairs, posted OEIS prefixes, exact interval
identities, and every position error in the first 100,000 letters of both
special words.

Regenerating the figures additionally requires Matplotlib:

```sh
python code/make_figures.py
```

## Build

From this directory:

```sh
sh build.sh
```

The script keeps intermediate files in `.build/` and copies the finished PDF
to `article.pdf`. The bibliography is embedded, so BibTeX is not needed.

## Research status

The cited OEIS pages still displayed the bounds as conjectures when checked
on October 1, 2026. The report is a self-contained research draft, not a
peer-reviewed publication or a proof-assistant formalization. The A284368
case has an independent generalized-Wythoff route and is not claimed as the
main novelty. A limited source search found no proof of the A284369 position
bounds, but no exhaustive priority claim is made. No OEIS changes or
repository modifications were submitted.
