# Attribution and inherited terms

This packet records research performed for Vladimir Reshetnikov’s ProveIt project on 21 October 2026. It does not claim a new accepted machine with at most 214 working states. The baseline is the accepted K215 source and transition table from the pinned public repository snapshot specified in `README.md` and `report.tex`.

The baseline directory, including its `NOTICE.md`, `licenses/`, and provenance records, is included without changing its authorship statements. Those records credit the original contributions of Mira and ProveIt, Elliot Glazer, Jeff, Andrew James Wade, BusyCoq, the Coq Library of Undecidability, and the earlier source and machine constructions within their stated scopes. New scripts that import or adapt baseline helpers retain those inherited dependencies. Original third-party licenses apply to their respective components; this packet does not relicense them.

The new proof exposition, finite-algebra certificates, source-invariant checkers, physical-evidence checkers, and synthesis experiments were prepared in this research session. “Independent” checking means a separate implementation or review inside the research collaboration, as stated in the report; it does not imply an external human endorsement or proof-assistant kernel verification. No global novelty or discovery-priority claim is made.

New material is provided for incorporation under the ProveIt project’s MIT No Attribution terms. The exact upstream license is retained as `LICENSE.ProveIt`. Inherited notices and licenses remain authoritative for inherited components.

Later incoming research submissions are credited by their exact public repository commits in the report. Their presence in the incoming collection does not constitute acceptance of their claims.
