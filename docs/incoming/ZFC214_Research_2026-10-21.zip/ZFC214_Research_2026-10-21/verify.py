#!/usr/bin/env python3
"""Fast independent replay of the packet's principal positive certificates.
Python standard library only; no numerical optimizer or theorem-prover install.
"""
from pathlib import Path
import hashlib,json,subprocess,sys,importlib.util,argparse
if sys.flags.optimize:
    raise RuntimeError('Run verification without -O or PYTHONOPTIMIZE; assertions are proof checks.')
ROOT=Path(__file__).resolve().parent
K=ROOT/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215'
OUT=ROOT/'out/verification';OUT.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(script,*args):
    cmd=[sys.executable,'-B',str(ROOT/script),*map(str,args)]
    result=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True)
    if result.returncode:
        print(result.stdout);print(result.stderr,file=sys.stderr)
        raise SystemExit('Verification failed: '+str(script))
    return json.loads(result.stdout)
assert sha(K/'k215.native.tm')=='9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2'
assert sha(K/'sites215.json')=='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
source=K/'sites215.json';results={}
results['formalism_fast_replay']=run('formalism/replay_formalism_fast.py','--source',source,'--out',OUT/'formalism')
assert results['formalism_fast_replay']['status']=='FORMALISM_FAST_REPLAY_PASS'
results['source_invariant']=run('formalism/check_source_invariant.py','--source',source,'--certificate',ROOT/'formalism/k215-invariant-broad/source_invariant.json.gz','--require-clean-root','--out',OUT/'source-invariant.json')
results['initial_scratch_zero_invariant']=run('formalism/check_source_invariant.py','--source',source,'--certificate',ROOT/'formalism/k215-invariant-initial-scratch-zero/source_invariant.json.gz','--out',OUT/'initial-scratch-zero-invariant.json')
results['literal_formula_controls']=run('formalism/check_literal_k215_models.py','--source',source,'--out',OUT/'literal-controls.json')
controls=json.loads((OUT/'literal-controls.json').read_text());assert controls['models'][0]['all_literal_rows_designated'];assert not controls['models'][1]['all_literal_rows_designated']
results['finite_models']=[]
for code,certificate in [('a','literal-identity-rho8-model-certificate.json'),('b','literal-rho8-b-model-certificate.json'),('c','literal-rho8-c-model-certificate.json'),('ab','literal-rho8-ab-model-certificate.json'),('ac','literal-rho8-ac-model-certificate.json'),('bc','literal-rho8-bc-model-certificate.json')]:
    old=json.loads((ROOT/'formalism'/certificate).read_text())
    model={'I':old['implication'],'Q':old['universal_quantifier'],'membership':old['membership_atom'],'equality':old['equality_atom'],'identity':True}
    path=OUT/f'model-{code}.json';path.write_text(json.dumps(model,indent=2)+'\n')
    result=run('formalism/check_literal_finite_certificate.py','--source',source,'--model',path,'--rho8',code,'--out',OUT/f'checked-model-{code}.json')
    assert result['status']=='LITERAL_K215_FINITE_ALGEBRA_CERTIFICATE_PASS'and result['identity_schema_holds']
    results['finite_models'].append({'identification':result['rho8_identification'],'values':len(result['values']),'status':result['status']})
results['transfer_mp_splices']=[]
for mode in ('cache_return','omit_zero'):
    result=run('formalism/check_transfer_mp_splices.py','--parent',ROOT/'formalism/transfer-combinations/parent201.sites.json','--changed',ROOT/'formalism/transfer-combinations'/(mode+'.sites.json'),'--mode',mode,'--out',OUT/('transfer-'+mode+'.json'))
    assert result['status']=='EXACT_TRANSFER_MP_SPLICE_CFG_PASS' and result['outside_primitive_edges_checked']==6173
    results['transfer_mp_splices'].append(result)
results['physical_evidence']=run('physical/portable/verify_evidence.py')
assert results['physical_evidence']['status']=='PASS'
# Independently compare the exact blank trace before the rejected alias first matters.
def table(path):
    t={}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();assert d in ('L','R')and b in('0','1')and w in('0','1')
        key=int(q),int(b);assert key not in t;t[key]=(int(w),1 if d=='R'else-1,int(z))
    return t
t=table(K/'k215.native.tm');u=table(ROOT/'physical/portable/rejected-clean-alias214.tm')
q=h=0;ones=set();seen=set()
for step in range(95714):
    key=q,int(h in ones);seen.add(key);assert t[key]==u[key]
    w,d,q=t[key]
    if w:ones.add(h)
    else:ones.discard(h)
    h+=d
assert q==84 and h==-8 and len(ones)==95 and len(seen)==228
results['blank_trace_comparison']={'steps':95714,'state':q,'head':h,'one_cells':len(ones),'distinct_rows':len(seen),'exact_alias_trace_preserved':True}
results['status']='PASS'
results['accepted_smaller_machine']=False
(OUT/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'status':'PASS','source_invariants':2,'literal_axiom_identification_countermodels':results['finite_models'],'all_tape_local_reroute_cases':results['physical_evidence']['all_tape_local_reroute_cases'],'concrete_contract_counterexamples':results['physical_evidence']['concrete_contract_counterexamples'],'blank_trace_steps':95714,'accepted_smaller_machine':False,'detail':'out/verification/summary.json'},indent=2))
