"""Collect certified finite leaf-entry contexts from every baseline symbolic contract.
No finite register-value simulation. Every captured bit comes from a fixed
coefficient of an exact symbolic tape run, or its explicit infinite zero exterior.
"""
from pathlib import Path
import sys,json,time,hashlib
B=Path('/dev/shm/zfc214-9d0ff4abecf6');K=B/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215';O=B/'physical'
sys.path[:0]=[str(K/'code'),str(K/'code/runtime-inputs/runtime')]
import build221 as b,source_language as sl,symbolic_runtime as s
T=b.read_table((K/'k215.native.tm').read_bytes());ss=json.loads((K/'sites215.json').read_text());tree=sl.tree(ss);g,ps=b.decoder_map(T,tree);at={p:q for q,paths in ps.items()for p in paths}
m={int(q):int(z)for q,z in json.loads((K/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
for q in{q for q,_ in T}|{254}:m.setdefault(q,q+1000)
L={(m[q],bit):(w,d,m[z])for(q,bit),(w,d,z)in T.items()};lemmas,_=s.prove_blocks(L)
base_step=s.State.step;contexts={};case_contexts=[];targetq=None;targetmotion=None;leafbit=None;current_pc=None;current_site=None;decode_phase=None;expected_decode=[]

def prefix(atoms,limit=256):
 bits=[];blank=False
 for a in s.normal(atoms):
  if a==s.BLANK:blank=True;break
  if a[0]!='run':break
  n=a[2];c=n[0];bits.extend([a[1]]*min(c,limit-len(bits)))
  if len(bits)==limit:break
  if any(n[1:]):break
 return ''.join(map(str,bits)),blank

def hook(self,table,lems,clock,motion):
 global decode_phase
 if decode_phase is None and self.q==m[84]:decode_phase=0
 if decode_phase==len(expected_decode)-1:
  assert self.q==targetq and motion==targetmotion,(current_site,self.q,motion)
  self.key();direction=self.direction
  src=self.right if direction==1 else self.left
  if src and src[0][0]=='run' and src[0][1]==leafbit and src[0][2][0]>=1:
   a,ab=prefix(self.left);z,zb=prefix(self.right)
   if direction==1:
    left=a;right=z
   else:
    # Fixed convention: left holds h-1,h-2,...; right holds h,h+1,...
    assert a and a[0]==str(leafbit)
    left=a[1:];right=a[0]+z
   rec={'left_nearest_first':left,'right_nearest_first':right,'left_blank':ab,'right_blank':zb,'action':list(T[at[current_pc[:-1]],leafbit]),'old_state':at[current_pc[:-1]]}
   key=json.dumps(rec,sort_keys=True,separators=(',',':'))
   if key not in contexts:contexts[key]={'id':len(contexts),'context':rec,'sites':[]}
   item=contexts[key]
   if current_site not in item['sites']:item['sites'].append(current_site)
   case_contexts.append(item['id'])
 result=base_step(self,table,lems,clock,motion)
 if decode_phase is not None:
  event=result[2]
  assert event[0]=='literal' and tuple(event[1])==expected_decode[decode_phase],(current_site,decode_phase,event,expected_decode[decode_phase])
  decode_phase+=1
  if decode_phase==len(expected_decode):decode_phase=None
 return result
s.State.step=hook
beg=time.monotonic();cases=[]
for i,site in enumerate(ss):
 current_pc=site[0];current_site=i;targetq=m[at[current_pc[:-1]]];targetmotion=s.num(len(current_pc)-1);leafbit=int(current_pc[-1])
 expected_decode=[];q=84;h=0;tape={-1:1,**{j:int(c)for j,c in enumerate(current_pc)}}
 for tick in range(1000):
  if h==len(current_pc)-1:break
  assert h in tape
  bit=tape[h];w,d,z=T[q,bit];expected_decode.append((m[q],bit,w,d,m[z]));tape[h]=w;h+=d;q=z
 else:raise AssertionError('decoderprefix')
 bit=int(current_pc[-1]);w,d,z=T[q,bit];expected_decode.append((m[q],bit,w,d,m[z]))
 for positive in([False,True]if site[1]=='CD'else[False]):
  case_contexts=[];decode_phase=None
  s.case(L,lemmas,site,positive)
  assert case_contexts,(i,site,positive,'NO_LEAF_CONTEXT')
  cases.append({'site_index':i,'positive':positive,'contexts':case_contexts})
 if(i+1)%500==0:print('sites',i+1,'contexts',len(contexts),'cases',len(cases),'seconds',round(time.monotonic()-beg,2),flush=True)
out={'status':'ALL_BASELINE_SYMBOLIC_CASES_PROVED','table_sha256':hashlib.sha256((K/'k215.native.tm').read_bytes()).hexdigest(),'sites_sha256':hashlib.sha256((K/'sites215.json').read_bytes()).hexdigest(),'cases':cases,'contexts':list(contexts.values()),'seconds':time.monotonic()-beg,'scope':'Only genuine decoder-prefix leaf events, identified by exact repeated literal prefix and exact head coordinate during each of6176 universally quantified symbolic contracts. Literal finite bits only; variable-length run tails are opaque. All repeated literal decoder prefixes are checked before their final leaf event is captured.'}
(O/'leaf-phase-contexts-exact.json').write_text(json.dumps(out,indent=2)+'\n');print('DONE',len(contexts),len(cases),out['seconds'],flush=True)
