#!/usr/bin/env python3
"""Dependency-free verification of positive local rewrites and negative examples."""
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
BASE_SHA='9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2'
def read_table(name):
 raw=(HERE/name).read_bytes();table={}
 for line in raw.decode().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,d,z=line.split();key=int(q),int(b);assert key not in table;table[key]=(int(w),1 if d=='R'else-1,int(z))
 states={q for q,b in table};assert set(table)=={(q,b)for q in states for b in(0,1)};assert all(z in states|{254}for w,d,z in table.values())
 return raw,table
raw,T=read_table('baseline-k215.tm');assert hashlib.sha256(raw).hexdigest()==BASE_SHA
assert len(T)==430

def block(table,q,left,stop):
 tape={-1:left,0:1};h=0;trace=[]
 for n in range(20):
  if(q,h)==stop:return q,h,tape,trace
  assert h in tape,'Block read an unspecified cell'
  bit=tape[h];w,d,z=table[q,bit];trace.append((q,bit));tape[h]=w;h+=d;q=z
 raise AssertionError('No common block endpoint')
count=0
for a in(107,128):
 for b in(57,126,141):
  N=dict(T);N[13,1]=(1,-1,a);N[83,1]=(0,-1,b)
  for q in(13,83):
   for left in(0,1):
    stop={(13,0):(21,0),(13,1):(16,-1),(83,0):(49,1),(83,1):(16,-2)}[q,left]
    old=block(T,q,left,stop);new=block(N,q,left,stop);assert old[:3]==new[:3]
    assert old[3]and new[3]
    assert all(row not in{(13,1),(83,1)}for row in old[3][1:]+new[3][1:])
    count+=1
_,supplied=read_table('positive-reroute215.tm');N=dict(T);N[13,1]=(1,-1,107);N[83,1]=(0,-1,57);assert supplied==N

def run(table,initial,steps):
 q,h=initial['state'],initial['head'];ones=set(initial['ones'])
 for _ in range(steps):
  w,d,q=table[q,int(h in ones)]
  if w:ones.add(h)
  else:ones.discard(h)
  h+=d
 return {'state':q,'head':h,'ones':sorted(ones)}
data=json.loads((HERE/'counterexamples.json').read_text());negative=0
for case in data['cases']:
 _,N=read_table(case['table']);assert len(N)==428
 assert run(T,case['initial'],case['baseline_steps'])==case['expected']
 assert run(N,case['initial'],case['candidate_steps'])==case['actual']
 assert case['actual']!=case['expected'];negative+=1
print(json.dumps({'status':'PASS','all_tape_local_reroute_cases':count,'concrete_contract_counterexamples':negative,'positive_machine_states':215,'rejected_machine_states':214,'claim':'The reroutes preserve all-tape halting behavior. The rejected tables fail their claimed K215 primitive contracts; no accepted machine with fewer than 215 states is certified here.'},indent=2))
