# Physical reduction evidence for K215

**Status:** this directory certifies two exact local rewrites of the existing 215-state machine. It also contains reproducible counterexamples to two proposed 214-state reductions. It does **not** certify a 214-state solution.

The baseline is `candidate-k215/k215.native.tm` from ProveIt commit `c8029f50d324910a36694c39a1e62f5720c36f4c`. Its SHA-256 is `9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2`.

Run the independent checker with Python 3:

```sh
python3 verify_evidence.py
```

It needs only the Python standard library and the files in this directory. It checks all 24 local tape cases for six combinations of the two rewrites, and simulates three concrete counterexamples. The local proofs quantify over arbitrary contents of every unvisited tape cell; they are not a bounded nonhalting test.

## Positive result

In `positive-reroute215.tm`, replace baseline rows `13/1: 1L31` and `83/1: 0L42` by `1L107` and `0L57`. Every other row remains identical. The complete boundary configuration agrees after each short replacement block. Both rewrites therefore preserve halting behavior on every starting tape, including the blank tape. This is a useful source of flexibility for later state allocation, but the table still has 215 working states.

The first target may also be 128, and the second target may be 126 or 141. The checker proves all six choices directly from the baseline table.

## Rejected candidates

`rejected-scanner214.tm` removes scanner state 50 by replacing `34/0: 0L50` with `0L75`. The existing source contains six consecutive zeros on some instruction paths. At source site 26, this modification returns to the wrong next instruction, even when every register is zero. The baseline reaches its specified next frame in 588 steps; the shortened scanner reaches a different frame in 662 steps.

`rejected-clean-alias214.tm` removes state 126 by changing `107/1: 1R126` to `1R13`. It preserves the baseline blank startup and passes a decoder-prefix test. It nevertheless fails source site 50, the instruction `CI4`. The arithmetic engine revisits the decoder while the padding has changed. An alias that is valid only on clean zero padding does not justify those later visits. The two recorded register vectors give finite counterexamples.

The rejected tables are retained to prevent these tempting reductions from being mistaken for successful constructions. A failed primitive contract rejects the proposed implementation proof; it does not itself prove that every possible alternate logical interpretation of that table is impossible.

All state labels in `counterexamples.json` and the tables here are **native** labels. The full runtime checker elsewhere in the research tree uses a separate legacy numbering; mixing the two numberings can lead to incorrect claims about which states the engine uses.
