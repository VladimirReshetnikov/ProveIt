"""Exact internal-edge aliases for arbitrary assignable first-row actions.

The initial free action is followed solely by rows in the fixed protected set.
The known tape is precisely sentinel + literal source prefix + current bit.
We accept only restored tape and first exit one cell to the right; no outside
cell is read. Thus witnesses hold uniformly for all surrounding tape contents.
"""
from pathlib import Path
import sys,json,time,hashlib
B=Path('/dev/shm/zfc214-9d0ff4abecf6');K=B/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215';O=B/'physical'
sys.path.insert(0,str(K/'code'));import build221 as b
T=b.read_table((K/'k215.native.tm').read_bytes());R=json.loads((O/'roles-fullproofseed.json').read_text());P=set(map(tuple,R['protected']));Q=sorted({q for q,bit in T})
def edge(act,p,bit):
 tape={-1:1,**{i:int(c)for i,c in enumerate(p+str(bit))}};before=tape.copy();h=len(p);used=[];w,d,q=act;tape[h]=w;h+=d
 for k in range(1,301):
  if h==len(p)+1:return (q,used,k)if tape==before else None
  if h not in tape:return None
  row=q,tape[h]
  if row not in P:return None
  used.append(row);w,d,q=T[row];tape[h]=w;h+=d
 return None
beg=time.monotonic();rows=[];count=0;different=0
pool=[(w,d,q) for w in[0,1] for d in[-1,1] for q in Q]
for role in R['roles']:
 for bit,ch in enumerate(role['children']):
  if ch['kind']!='internal':continue
  pp=sorted(role['occurrences'],key=lambda p:(len(p),p));alternatives=[]
  for act in pool:
   if act[:2]==(bit,1):continue
   endpoints=[];deps=set();steps=[]
   for p in pp:
    ans=edge(act,p,bit)
    if ans is None:break
    q,used,k=ans;endpoints.append({'prefix':p,'target':q});deps.update(used);steps.append(k)
   else:
    alternatives.append({'action':list(act),'endpoints':endpoints,'dependencies':[list(x)for x in sorted(deps)],'min_steps':min(steps),'max_steps':max(steps)})
    if len({v['target']for v in endpoints})>1:different+=1
  if alternatives:rows.append({'role':role['id'],'bit':bit,'alternatives':alternatives});count+=len(alternatives)
 if role['id']%20==0:print('role',role['id'],'groups',len(rows),'macros',count,'differentendpoints',different,'seconds',round(time.monotonic()-beg,2),flush=True)
out={'status':'EXACT_FREE_ROW_INTERNAL_MACRO_CATALOG','table_sha256':hashlib.sha256((K/'k215.native.tm').read_bytes()).hexdigest(),'protected':R['protected'],'rows':rows,'count':count,'different_endpoint_count':different,'seconds':time.monotonic()-beg,'scope':'Initial row is freely assignable. Subsequent rows belong to protected. Known cells are p+bit and sentinel1 at coordinate -1. All known cells are restored before first exit at len(p)+1, without reading any unknown cell. This is a finite all-tape local proof, not bounded execution evidence about blank-tape nonhalting.'}
(O/'internal-action-macros-fullproof.json').write_text(json.dumps(out,indent=2)+'\n');print('DONE',len(rows),count,different,out['seconds'],flush=True)
