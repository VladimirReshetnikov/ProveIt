from pathlib import Path
import sys,json,time,collections
B=Path('/dev/shm/zfc214-9d0ff4abecf6');K=B/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215';O=B/'physical';sys.path.insert(0,str(K/'code'));import build221 as b
T=b.read_table((K/'k215.native.tm').read_bytes());ss=json.loads((K/'sites215.json').read_text());site_at={s[0]:i for i,s in enumerate(ss)}
roles=json.loads((O/'roles185.json').read_text());PROTECTED=set(map(tuple,roles['protected']))
data=json.loads((O/'leaf-phase-contexts.json').read_text());records={x['id']:x for x in data['contexts']};by_site=collections.defaultdict(set)
for i,x in records.items():
 for j in x['sites']:by_site[j].add(i)
def trace(rec,act,stop=None):
 c=rec['context'];left=c['left_nearest_first'];right=c['right_nearest_first'];lo=-len(left);hi=len(right)-1
 ones={-(i+1)for i,x in enumerate(left)if x=='1'}|{i for i,x in enumerate(right)if x=='1'};w,d,q=act;h=0
 if w:ones.add(h)
 else:ones.discard(h)
 h+=d;used=set();seen=set();out={}
 for i in range(1,301):
  key=q,h,frozenset(ones)
  if stop is not None and key in stop:
   j,oldused=stop[key];return i,j,sorted(used|oldused)
  if key in seen:break
  seen.add(key);out[key]=(i,frozenset(used))
  if(h<lo and not c['left_blank'])or(h>hi and not c['right_blank']):break
  row=q,int(h in ones)
  if row not in PROTECTED or row not in T:break
  used.add(row);w,d,q=T[row]
  if w:ones.add(h)
  else:ones.discard(h)
  h+=d
 return out if stop is None else None
pool={bit:{(w,d,q)for w in[0,1]for d in[-1,1]for q in ({q for q,b in T}|{254})}for bit in[0,1]};refs={};proofs=[];beg=time.monotonic();nontrivial=0
for role in roles['roles']:
 for bit,ch in enumerate(role['children']):
  if ch['kind']!='leaf':continue
  ids=set.union(*(by_site[site_at[p+str(bit)]]for p in role['occurrences']))
  ids=sorted(ids,key=lambda i:(-records[i]['context']['right_nearest_first'][1:8].count('1'),i))
  for i in ids:
   assert records[i]['context']['old_state']==role['old_q']
   if i not in refs:refs[i]=trace(records[i],records[i]['context']['action'])
  allowed=[];witnessed=[]
  for act in pool[bit]:
   witnesses=[]
   for i in ids:
    got=trace(records[i],act,refs[i])
    if got is None:break
    witnesses.append([i,*got])
   else:
    allowed.append(list(act));witnessed.append({'action':act,'witnesses':witnesses})
    nontrivial+=list(act)!=ch['action']
  assert ch['action']in allowed,(role['id'],bit,ch['action'])
  ch['allowed_actions']=sorted(allowed);ch['phase_contexts']=len(ids)
  proofs.append({'role':role['id'],'bit':bit,'actions':witnessed})
roles['leaf_alias_proofs']='role185-leafall-proofs.json';roles['leaf_alias_scope']='Each action synchronized against the actual old leaf action in every extracted symbolic phase, using only protected helper rows before unknown tape.'
(O/'roles185-leafall.json').write_text(json.dumps(roles,indent=2)+'\n');(O/'role185-leafall-proofs.json').write_text(json.dumps({'status':'ALL_PHASE_ROLE_LEAF_ALIASES','protected':sorted(PROTECTED),'nontrivial':nontrivial,'proofs':proofs,'seconds':time.monotonic()-beg},indent=2)+'\n');print('DONE groups',len(proofs),'nontrivial',nontrivial,'seconds',time.monotonic()-beg,flush=True)
