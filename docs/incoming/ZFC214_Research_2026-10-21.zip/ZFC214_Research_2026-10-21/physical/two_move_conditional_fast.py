"""Bounded two-source-host relocation search with exact conditional helpers."""
from pathlib import Path
from collections import defaultdict,deque,Counter
import json,sys,time,argparse
B=Path('/dev/shm/zfc214-9d0ff4abecf6');K=B/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215';O=B/'physical/two-move-conditional-fast'
sys.path.insert(0,str(K/'code'));import build221 as bu,source_language as sl
ap=argparse.ArgumentParser();ap.add_argument('--seconds',type=int,default=300);ap.add_argument('--dead',type=int);args=ap.parse_args();O.mkdir(exist_ok=True)
T=bu.read_table((K/'k215.native.tm').read_bytes());R0=json.loads((B/'physical/roles-conditionalfull.json').read_text());R={r['id']:r for r in R0['roles']};E=set(map(tuple,json.loads((B/'global/engine.json').read_text())['rows']));Q=sorted({q for q,b in T});S=set(map(tuple,json.loads((B/'global/startup_rows.json').read_text())['rows']));mac=json.loads((B/'physical/internal-action-macros-conditionalfull.json').read_text());M={r:rr['old_q']for r,rr in R.items()};G=defaultdict(list)
for r,q in M.items():G[q].append(r)
parents=defaultdict(set);childq={};sigopts=defaultdict(dict);leafopts={}
for r,rr in R.items():
 for bit,ch in enumerate(rr['children']):
  if ch['kind']=='internal':
   childq[r,bit]=tuple(sorted({M[c['role']]for c in ch['targets']}))
   for q in childq[r,bit]:parents[q].add((r,bit))
  else:leafopts[r,bit]={tuple(x['action']):frozenset(map(tuple,x['dependencies']))for x in ch['action_dependencies']}
for row in mac['rows']:
 r,bit=row['role'],row['bit'];by={x['prefix']:M[x['role']]for x in R[r]['children'][bit]['targets']}
 for x in row['alternatives']:
  req={};ok=True
  for z in x['endpoints']:
   q=by[z['prefix']]
   if q in req and req[q]!=z['target']:ok=False;break
   req[q]=z['target']
  if not ok:continue
  sig=tuple(req[q]for q in childq[r,bit]);ops=sigopts[r,bit].setdefault(sig,{});act=tuple(x['action']);deps=frozenset(map(tuple,x['dependencies']))
  if act not in ops or len(deps)<len(ops[act]):ops[act]=deps
cache={};leafcache={};CURRENT_DEAD=None
def filtered(ops):
 if CURRENT_DEAD is None:return ops
 return {a:ds for a,ds in ops.items()if a[2]!=CURRENT_DEAD and all(q!=CURRENT_DEAD for q,b in ds)}
def options(r,bit,mv):
 if(r,bit)in leafopts:
  key=r,bit,CURRENT_DEAD
  if key not in leafcache:leafcache[key]=filtered(leafopts[r,bit])
  return leafcache[key]
 sig=tuple(mv.get(q,q)for q in childq[r,bit]);key=r,bit,sig,CURRENT_DEAD
 if key not in cache:
  ops=dict(sigopts[r,bit].get(sig,{}))
  if len(set(sig))==1:ops[bit,1,sig[0]]=frozenset()
  cache[key]=filtered(ops)
 return cache[key]
def combine(opts):
 opts=list(opts)
 if not opts:return None
 common=set(opts[0])
 for o in opts[1:]:common.intersection_update(o)
 return {act:frozenset().union(*(o[act]for o in opts))for act in common}
baseopts={(r,b):options(r,b,{})for r in R for b in(0,1)};basegroup={(q,b):combine(baseopts[r,b]for r in rs)for q,rs in G.items()for b in(0,1)}
assert all(T[M[r],b]in baseopts[r,b]for r in R for b in(0,1))
def build(mv,dead):
 groups={q:list(rs)for q,rs in G.items()if q not in mv}
 for q,z in mv.items():groups.setdefault(z,[]).extend(G.get(q,[]))
 affected=set(mv.values())|set(mv)
 for q in mv:
  for r,b in parents[q]:affected.add(mv.get(M[r],M[r]))
 opts={k:v for k,v in basegroup.items()if k[0]!=dead}
 for q in affected-{dead}:
  for bit in(0,1):
   if q not in groups:opts.pop((q,bit),None);continue
   o=combine(options(r,bit,mv)for r in groups[q]);opts[q,bit]=o
   if not o:return None,{q}
 return opts,None

def csp(rowopts,dead):
 dom={};removed=defaultdict(set)
 for k,old in T.items():
  q,bit=k
  if q==dead:continue
  ops=rowopts.get(k,{old:frozenset(),(bit,1,q):frozenset()})
  dom[k]={act:deps for act,deps in ops.items()if act[2]!=deadand(k not in E or act==old)}
  if not dom[k]:return None,{q}
 rev=defaultdict(list)
 for k,ops in dom.items():
  for act,deps in ops.items():
   for dep in deps:rev[dep].append((k,act))
 bad=deque(k for k in dom if T[k]not in dom[k]);causes={k:{k[0]}for k in bad}
 while bad:
  dep=bad.popleft()
  for k,act in rev.get(dep,[]):
   if act not in dom[k]:continue
   del dom[k][act];removed[k].update(causes[dep])
   if not dom[k]:return None,removed[k]|{k[0]}
   if T[k]not in dom[k]and k not in causes:causes[k]=set(removed[k]);bad.append(k)
 N={k:T[k]if T[k]in ops else min(ops)for k,ops in dom.items()}
 assert all(N[dep]==T[dep]for k,act in N.items()for dep in dom[k][act]);assert all(N[k]==T[k]for k in E)
 return N,None
beg=time.monotonic();found=[];counts=Counter();tree=sl.tree(json.loads((K/'sites215.json').read_text()))
def save(N,mv,dead):
 _,pth=bu.decoder_map(N,tree);actual={p:q for q,pcs in pth.items()for p in pcs};newM={r:mv.get(q,q)for r,q in M.items()};assert all(actual[p]==newM[r]for r,rr in R.items()for p in rr['occurrences'])
 changed=[{'row':list(k),'old':list(T[k]),'new':list(v)}for k,v in N.items()if T[k]!=v];preserve=all(k in N and N[k]==T[k]for k in S);tag='-'.join(f'{q}to{z}'for q,z in sorted(mv.items()));(O/(tag+'.native.tm')).write_bytes(bu.table_bytes(N));rec={'removed':dead,'moves':mv,'states':len(Q)-1,'startup_preserved':preserve,'changes':changed,'file':tag+'.native.tm'};found.append(rec);print('FOUND',tag,'startup',preserve,'changes',len(changed),flush=True)
stop=False
for dead in Q:
 if args.dead is not None and dead!=args.dead:continue
 if dead in{0,84}or any(q==dead for q,b in E)or any(T[k][2]==dead for k in E):continue
 CURRENT_DEAD=dead;cache.clear();leafcache.clear();baseopts={(r,b):options(r,b,{})for r in R for b in(0,1)};basegroup={(q,b):combine(baseopts[r,b]for r in rs)for q,rs in G.items()if q!=dead for b in(0,1)}
 print('DEAD',dead,'seconds',round(time.monotonic()-beg,2),flush=True)
 for target in Q:
  if target==dead:continue
  if time.monotonic()-beg>args.seconds:stop=True;break
  counts['single']+=1;mv={dead:target};opts,bad=build(mv,dead)
  if opts is not None:N,bad=csp(opts,dead)
  else:N=None
  if N is not None:save(N,mv,dead);continue
  victims=sorted((bad|{target})&set(G)-{0,84,dead})
  for victim in victims:
   for dest in Q:
    if dest in{dead,victim}:continue
    if time.monotonic()-beg>args.seconds:stop=True;break
    counts['double']+=1
    if counts['double']%5000==0:print('TRIES',dict(counts),'dead',dead,'target',target,'seconds',round(time.monotonic()-beg,2),flush=True)
    move={dead:target,victim:dest};ops,why=build(move,dead)
    if ops is None:counts['source_empty']+=1;continue
    NN,why=csp(ops,dead)
    if NN is None:counts['helper_empty']+=1;continue
    save(NN,move,dead)
   if stop:break
  if stop:break
 if counts['single']%100<1 or stop:print('progress dead',dead,dict(counts),'found',len(found),'seconds',round(time.monotonic()-beg,2),flush=True)
 if stop:break
out={'status':'BOUNDED_TWO_HOST_CONDITIONAL_SEARCH','counts':dict(counts),'found':found,'seconds':time.monotonic()-beg,'time_limit':args.seconds,'last_dead':dead,'last_target':target,'complete':not stop};(O/('result-dead%d.json'%args.dead if args.dead is not None else'result.json')).write_text(json.dumps(out,indent=2)+'\n');print('DONE',dict(counts),'found',len(found),'complete',not stop,'seconds',out['seconds'],flush=True)
