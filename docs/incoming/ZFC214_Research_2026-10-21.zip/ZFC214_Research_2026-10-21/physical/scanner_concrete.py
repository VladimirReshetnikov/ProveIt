from pathlib import Path
import sys,json
B=Path('/dev/shm/zfc214-9d0ff4abecf6')
K=B/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215'
sys.path.insert(0,str(K/'code/runtime-inputs/runtime'))
import independent_runtime as r
m={int(q):int(z) for q,z in json.loads((K/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
m[254]=254
for q in range(1000):m.setdefault(q,q+1000)
rev={z:q for q,z in m.items()}
def lt(path):
 return {(m[q],b):(w,d,m[z]) for (q,b),(w,d,z) in r.table(path).items()}
Ts=[lt(K/'k215.native.tm'),lt(B/'physical/scanner214.native.tm')]
site=json.loads((K/'sites215.json').read_text())[26]
results=[]
for w in range(5):
 regs=[0]*9;regs[2]=w
 expected=r.expected(site,regs,[0])
 outcomes=[]
 for name,T in zip(['baseline215','scanner214'],Ts):
  actual,steps,trace=r.run(T,site[0],regs,limit=100000,trace=True)
  item={'name':name,'registers':regs,'matches':actual==expected[0],'steps':steps,'actual':r.describe(actual),'expected':r.describe(expected[0]),'trace_native':[[tick,rev[q],h,b,x,d,rev[z]]for tick,q,h,b,x,d,z in trace]}
  outcomes.append(item)
 results.append(outcomes)
 print(w,[(x['name'],x['matches'],x['steps'],x['actual']['state'],x['actual']['head'])for x in outcomes],flush=True)
(B/'physical/scanner-concrete.json').write_text(json.dumps({'site_index':26,'site':site,'outcomes':results},indent=2)+'\n')
