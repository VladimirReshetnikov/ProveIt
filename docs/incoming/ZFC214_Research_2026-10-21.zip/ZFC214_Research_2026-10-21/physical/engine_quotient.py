"""Build engine-only partial-machine quotient templates, not complete candidates."""
from pathlib import Path
import json,hashlib
HERE=Path(__file__).resolve().parent
P=HERE.parent/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215'
def load(p):
 t={}
 for l in p.read_text().splitlines():
  if l.startswith('#'):continue
  q,b,w,d,z=l.split();t[int(q),int(b)]=(int(w),1 if d=='R'else-1,int(z))
 return t
T=load(HERE/'reroute83.native.tm');E=set(map(tuple,json.loads((HERE/'engine83.json').read_text())['rows']))
quotients={'merge38':{42:38},'merge575':{42:38,47:57},'merge5':{42:38,47:57,70:28,99:182,128:31}}
for name,mp in quotients.items():
 m=lambda q:mp.get(q,q)
 pe={}
 for(q,b)in E:
  w,d,z=T[q,b];key=(m(q),b);val=(w,d,m(z))
  assert key not in pe or pe[key]==val,(key,pe.get(key),val)
  pe[key]=val
 # Keep all labels available to the decoder allocator, but canonicalize every
 # target. The source decoder needs to be regenerated against its original map.
 N={(q,b):(w,d,m(z))for(q,b),(w,d,z)in T.items()}
 N.update(pe)
 path=HERE/f'engine-{name}.native.tm';path.write_text('#! start 0\n'+''.join(f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'for(q,b),(w,d,z)in sorted(N.items())))
 out={'engine_only':True,'quotient':mp,'rows':sorted(pe),'transitions':[list(k)+list(v)for k,v in sorted(pe.items())],'removed_engine_labels':sorted(mp),'source_table':str(HERE/'reroute83.native.tm'),'source_census':str(HERE/'engine83.json'),'table_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'scope':'A partial-machine quotient of universally covered engine rows. At each engine step virtualstateq and readb are constrained by the inherited complete runtime proofs; every usedtransition commutes exactly withq→m(q). Unusedrows are deliberately unconstrained. Every decoder role, helpercontext, leafentry and blankstartup must be allocated and reverified separately. This fulltable is onlya synthesis template, notan accepted candidate.'}
 (HERE/f'engine-{name}.json').write_text(json.dumps(out,indent=2)+'\n');print(name,'rows',len(pe),'engine-labels',len({q for q,b in pe}),'identifications',mp)
