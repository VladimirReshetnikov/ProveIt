"""Exact finite whole-tape block proofs for the two K215 entry reroutes.
The proof reads only positions -1 and0; all other tape cells are arbitrary.
"""
from pathlib import Path
import json,hashlib
HERE=Path(__file__).resolve().parent
P=HERE.parent/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215'
def load(p):
 t={}
 for l in p.read_text().splitlines():
  if l.startswith('#'):continue
  q,b,w,d,z=l.split();t[int(q),int(b)]=(int(w),1 if d=='R'else-1,int(z))
 return t
T=load(P/'k215.native.tm')
def block(t,q,left,stop):
 tape={-1:left,0:1};h=0;tr=[]
 for i in range(20):
  if (q,h)==stop:return{'state':q,'head':h,'tape':tape,'trace':tr,'steps':i}
  assert h in tape,('read beyond two-cell premise',q,h)
  b=tape[h];w,d,z=t[q,b];tr.append([q,h,b,w,d,z]);tape[h]=w;q=z;h+=d
 raise ValueError('block did not close')
proofs=[]
for a in(107,128):
 for b in(57,126,141):
  path=HERE/f'reroute-{a}-{b}.native.tm';N=load(path);assert len(N)==430
  assert{r for r in T if T[r]!=N[r]}=={(13,1),(83,1)}
  cases=[]
  for q in(13,83):
   for left in(0,1):
    stop={(13,0):(21,0),(13,1):(16,-1),(83,0):(49,1),(83,1):(16,-2)}[q,left]
    old=block(T,q,left,stop);new=block(N,q,left,stop)
    assert{z:old[z]for z in('state','head','tape')}=={z:new[z]for z in('state','head','tape')}
    # Neither derivation revisits a rewritten row after its first step.
    assert all((x[0],x[2])not in{(13,1),(83,1)} for x in old['trace'][1:]+new['trace'][1:])
    cases.append({'state':q,'read':1,'predecessor':left,'old':old,'new':new})
  proofs.append({'table':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'cases':cases})
report={'status':'ALL_TAPE_TWO_CELL_BLOCK_PASS','parent_sha256':hashlib.sha256((P/'k215.native.tm').read_bytes()).hexdigest(),'scope':'Both predecessor bits exhaust all tape assignments read. Every other cell is never read or written by the block. Common exit state/head/tape is exact. Positive lengths and absence of nested changed rows permit simultaneous block replacement.','variants':proofs}
(HERE/'reroute_proofs.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'],len(proofs),'variants',sum(len(p['cases'])for p in proofs),'cases')
