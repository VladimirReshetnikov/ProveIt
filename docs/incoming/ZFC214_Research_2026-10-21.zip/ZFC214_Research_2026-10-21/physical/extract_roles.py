from pathlib import Path
import sys,json,collections,time
B=Path('/dev/shm/zfc214-9d0ff4abecf6');K=B/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215';P=B/'global';O=B/'physical'
sys.path.insert(0,str(K/'code'));import build221 as b,source_language as s
T=b.read_table((K/'k215.native.tm').read_bytes());ss=json.loads((K/'sites215.json').read_text());tree=s.tree(ss);g,ps=b.decoder_map(T,tree);at={p:q for q,pp in ps.items()for p in pp}
role_occ=collections.defaultdict(list)
for p,q in at.items():role_occ[s.subtree(tree,p),q].append(p)
keys=sorted(role_occ,key=lambda k:(k[1],min(role_occ[k])));ids={k:i for i,k in enumerate(keys)}
pathrole={p:ids[s.subtree(tree,p),q]for p,q in at.items()}
def edge(q,p,bit,protected=None):
 tape={-1:1,**{i:int(c)for i,c in enumerate(p+str(bit))}};before=tape.copy();h=len(p);used=[]
 for k in range(100):
  if h==len(p)+1:return(q if tape==before else None),used
  if h not in tape or(q,tape[h])not in T:return None,used
  row=q,tape[h]
  if protected is not None and k and row not in protected:return None,used
  used.append(row);w,d,q=T[row];tape[h]=w;h+=d
 return None,used
protected=set(map(tuple,json.loads((P/'engine.json').read_text())['rows']))
for(n,q),pp in role_occ.items():
 for bit,ch in enumerate(n):
  if s.leaf(ch):continue
  for p in pp:
   z,used=edge(q,p,bit);assert z==at[p+str(bit)];protected.update(used[1:])
roles=[];optional=set()
for i,(n,q)in enumerate(keys):
 pp=sorted(role_occ[n,q]);children=[]
 for bit,ch in enumerate(n):
  if s.leaf(ch):children.append({'kind':'leaf','op':ch[0],'arg':ch[1],'action':list(T[q,bit]),'allowed_actions':[list(T[q,bit])]})
  else:
   children.append({'kind':'internal','targets':[{'prefix':p,'role':pathrole[p+str(bit)]}for p in pp]})
   if(q,bit)not in protected and T[q,bit][:2]!=(bit,1):optional.add((q,bit))
 roles.append({'id':i,'old_q':q,'representative':pp[0],'occurrences':pp,'children':children})
minimal_protected=set(protected)
protected.update(optional)
base={'minimal_protected':sorted(minimal_protected),'status':'ROLE_CLASSES_EXTRACTED','root_role':pathrole[''],'roles':roles,'protected':sorted(protected),'optional_macro_rows':sorted(optional),'hosts':[],'source_states':len(g),'role_count':len(roles),'logical_internal_nodes':len(set(n for n,q in keys))}
(O/'roles.json').write_text(json.dumps(base,indent=2)+'\n');print('roles',len(roles),'minimalprotected',len(protected),'optional',sorted(optional),flush=True)
hosts=[];beg=time.monotonic()
for role,(n,oldq)in zip(roles,keys):
 for bit,ch in enumerate(n):
  if s.leaf(ch):continue
  for q in sorted({q for q,b in T}):
   if(q,bit)not in protected and(q,bit)not in optional:continue
   endpoints=[];deps=set();ok=True
   for p in role['occurrences']:
    z,used=edge(q,p,bit,protected)
    if z is None:ok=False;break
    endpoints.append({'prefix':p,'target':z});deps.update(used[1:])
   if ok:hosts.append({'role':role['id'],'bit':bit,'q':q,'entry_protected':(q,bit)in protected,'action':T[q,bit],'endpoints':endpoints,'dependencies':sorted(deps)})
base['hosts']=hosts;base['status']='ROLE_BRANCH_CATALOG';base['seconds']=time.monotonic()-beg
(O/'roles.json').write_text(json.dumps(base,indent=2)+'\n');print('DONE hosts',len(hosts),'seconds',base['seconds'],flush=True)
