from pathlib import Path
import sys,json,random,time
B=Path('/dev/shm/zfc214-9d0ff4abecf6');K=B/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215';O=B/'physical'
sys.path.insert(0,str(K/'code/runtime-inputs/runtime'))
import independent_runtime as r
m={int(q):int(z) for q,z in json.loads((K/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
for q in range(1000):m.setdefault(q,q+1000)
m[254]=254
T={(m[q],b):(w,d,m[z]) for (q,b),(w,d,z) in r.table(O/'scanner214.native.tm').items()}
ss=json.loads((K/'sites215.json').read_text());rng=random.Random(214)
def decode(conf):
 q,h,ones=conf
 if q!=96:return {'bad':'not_dispatch','state':q,'head':h}
 right=sorted(x for x in ones if x>=h+52)
 if not right:return {'bad':'no_header'}
 header=right[0];pc=''.join(str(int(h+i in ones)) for i in range(52))
 matches=[i for i,s in enumerate(ss) if pc.startswith(s[0])]
 if len(matches)!=1:return {'bad':'no_source_leaf','pc':pc}
 p=header+1;last=max(ones);vals=[]
 while p<=last:
  if p in ones or p+1 not in ones:return {'bad':'file_shape','pc':pc,'p':p}
  p+=1;n=0
  while p in ones:n+=1;p+=1
  vals.append(n-1)
 if len(vals)<10:return {'bad':'too_few_registers'}
 return {'site_index':matches[0],'registers':[vals[j] for j in r.PHY],'spares':vals[9:],'gap':header-h-64,'head':h}
results=[]
for i,site in enumerate(ss):
 if '000000' not in site[0]:continue
 cases=[]
 for positive in ([False,True] if site[1]=='CD' else [False]):
  inputs=[[0]*9,[1]*9,[2]*9]+[[rng.randrange(4)for _ in range(9)]for _ in range(6)]
  for regs in inputs:
   if site[1]=='CD':regs[site[2]]=1 if positive else 0
   act,steps,_=r.run(T,site[0],regs,spares=[0,2],gap=0,limit=200000)
   want=r.expected(site,regs,[0,2]);d=decode(act);wd=decode(want[0]) if want else None
   out={'positive':positive,'input':regs,'steps':steps,'actual':d,'expected':wd}
   if 'bad' not in d and wd:
    out['registers_match']=d['registers']==wd['registers'];out['spares_match']=d['spares']==wd['spares'];out['gap_match']=d['gap']==wd['gap'];out['head_match']=d['head']==wd['head']
   cases.append(out)
 results.append({'site_index':i,'site':site,'cases':cases})
 print(i,site,[(p,sorted(set(c['actual'].get('site_index',c['actual'].get('bad'))for c in cases if c['positive']==p)),all(c.get('registers_match',False) and c.get('spares_match',False) for c in cases if c['positive']==p))for p in set(c['positive']for c in cases)],flush=True)
(O/'scanner-sixzero-effects.json').write_text(json.dumps(results,indent=2)+'\n')
