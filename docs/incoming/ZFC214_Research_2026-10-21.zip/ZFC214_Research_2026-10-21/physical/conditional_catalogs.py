"""Make formerly global helper preservation an explicit per-mode condition."""
from pathlib import Path
import json,collections
B=Path('/dev/shm/zfc214-9d0ff4abecf6');O=B/'physical';E=set(map(tuple,json.loads((B/'global/engine.json').read_text())['rows']))
R=json.loads((O/'roles185-leafall.json').read_text());C=json.loads((O/'internal-action-macros185.json').read_text());proofs=json.loads((O/'role185-leafall-proofs.json').read_text());P=set(map(tuple,R['protected']));assert E<=P
proof_at={(x['role'],x['bit']):x for x in proofs['proofs']};counts=collections.Counter()
for rr in R['roles']:
 for bit,ch in enumerate(rr['children']):
  if ch['kind']!='leaf':continue
  ch['action_dependencies']=[]
  for ap in proof_at[rr['id'],bit]['actions']:
   ds=set()
   for witness in ap['witnesses']:ds.update(map(tuple,witness[3]))
   assert ds<=P
   ch['action_dependencies'].append({'action':ap['action'],'dependencies':sorted(ds),'conditional_dependencies':sorted(ds-E)})
   counts['actions']+=1;counts['conditional_actions']+=bool(ds-E)
  assert set(map(tuple,ch['allowed_actions']))=={tuple(x['action'])for x in ch['action_dependencies']}
R['helper_proof_rows']=sorted(P);R['protected']=sorted(E);R['conditional_helper_actions']=True;R['status']='ROLE_CONDITIONAL_HELPER_CATALOG';R['leaf_alias_scope']='Each leaf action has an explicit dependency set; all those original row actions must be installed whenever that action mode is selected. Only engine rows are unconditionally protected.'
C['helper_proof_rows']=sorted(P);C['protected']=sorted(E);C['conditional_helper_actions']=True;C['status']='CONDITIONAL_FREE_ROW_INTERNAL_MACRO_CATALOG';C['scope']='Initial row freely assignable; every dependency row must have its original action whenever this macro is selected. Prefix/sentinel restored before first right exit. Engine rows alone are unconditional.'
(O/'roles-conditional185.json').write_text(json.dumps(R,separators=(',',':'))+'\n');(O/'internal-action-macros-conditional185.json').write_text(json.dumps(C,separators=(',',':'))+'\n');print('DONE E',len(E),'helper',len(P-E),dict(counts))
