"""Streaming, bit-exact leaf alias certificates with conditional full-table tails."""
from pathlib import Path
import sys,json,time,collections,hashlib
B=Path('/dev/shm/zfc214-9d0ff4abecf6');K=B/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215';O=B/'physical';sys.path.insert(0,str(K/'code'));import build221 as b
T=b.read_table((K/'k215.native.tm').read_bytes());ss=json.loads((K/'sites215.json').read_text());site_at={s[0]:i for i,s in enumerate(ss)}
R=json.loads((O/'roles185.json').read_text());P=set(T);E=set(map(tuple,json.loads((B/'global/engine.json').read_text())['rows']));rowlist=sorted(P);rowbit={r:1<<i for i,r in enumerate(rowlist)}
data=json.loads((O/'leaf-phase-contexts-exact.json').read_text());records={x['id']:x for x in data['contexts']};by_site=collections.defaultdict(set)
for i,x in records.items():
 for j in x['sites']:by_site[j].add(i)
OFFSET=301;LIMIT=300

def trace(c,act,stop=None):
 left=c['left_nearest_first'];right=c['right_nearest_first'];lo=-len(left);hi=len(right)-1
 tape=sum(1<<(OFFSET-i-1)for i,x in enumerate(left)if x=='1')|sum(1<<(OFFSET+i)for i,x in enumerate(right)if x=='1')
 w,d,q=act;h=0;cell=1<<OFFSET;tape=(tape|cell)if w else(tape&~cell);h+=d;used=0;seen=set();out={}
 for i in range(1,LIMIT+1):
  key=q,h,tape
  if stop is not None and key in stop:
   j,oldused=stop[key];return i,j,used|oldused
  if key in seen:break
  seen.add(key)
  if stop is None:out[key]=(i,used)
  if(h<lo and not c['left_blank'])or(h>hi and not c['right_blank']):break
  assert h+OFFSET>=0
  cell=1<<(h+OFFSET);row=q,int(bool(tape&cell))
  if row not in P:break
  used|=rowbit[row];w,d,q=T[row];tape=(tape|cell)if w else(tape&~cell);h+=d
 return out if stop is None else None

def rows(mask):return [list(row)for i,row in enumerate(rowlist)if(mask>>i)&1]
pool={(w,d,q)for w in[0,1]for d in[-1,1]for q in({q for q,b in T}|{254})};proofs=[];beg=time.monotonic();nontrivial=0
for rr in R['roles']:
 for bit,ch in enumerate(rr['children']):
  if ch['kind']!='leaf':continue
  ids=set.union(*(by_site[site_at[p+str(bit)]]for p in rr['occurrences']));ids=sorted(ids,key=lambda i:(-records[i]['context']['right_nearest_first'][1:8].count('1'),i))
  active={act:{'mask':0,'witnesses':[]}for act in pool}
  for i in ids:
   rec=records[i];assert rec['context']['old_state']==rr['old_q'];ref=trace(rec['context'],rec['context']['action'])
   for act,proof in list(active.items()):
    got=trace(rec['context'],act,ref)
    if got is None:del active[act]
    else:
     an,bn,mask=got;proof['mask']|=mask;proof['witnesses'].append([i,an,bn])
  allowed=sorted(active);assert tuple(ch['action'])in allowed,(rr['id'],bit,ch['action']);ch['allowed_actions']=[list(a)for a in allowed];ch['phase_contexts']=len(ids);ch['action_dependencies']=[];pp=[]
  for act in allowed:
   proof=active[act];ds=rows(proof['mask']);ch['action_dependencies'].append({'action':list(act),'dependencies':ds,'conditional_dependencies':[k for k in ds if tuple(k)not in E]});pp.append({'action':list(act),'dependencies':ds,'witnesses':proof['witnesses']});nontrivial+=list(act)!=ch['action']
  proofs.append({'role':rr['id'],'bit':bit,'actions':pp});print('group',len(proofs),'role',rr['id'],'contexts',len(ids),'allowed',len(allowed),'nontrivial',nontrivial,'seconds',round(time.monotonic()-beg,2),flush=True)
R['helper_proof_rows']=rowlist;R['protected']=sorted(E);R['conditional_helper_actions']=True;R['status']='FULL_TABLE_CONDITIONAL_LEAF_CATALOG';R['leaf_alias_proofs']='role-fullproof-leafall-stream-proofs.json';R['leaf_alias_scope']='For every actual symbolic decoder-entry phase, each action synchronizes with the old entry action before either trace reads an unknown cell. Every used continuation row is an explicit conditional dependency.'
(O/'roles-fullproof-leafall.json').write_text(json.dumps(R,separators=(',',':'))+'\n');(O/'role-fullproof-leafall-stream-proofs.json').write_text(json.dumps({'status':'ALL_PHASE_FULL_TABLE_CONDITIONAL_LEAF_ALIASES','helper_proof_rows':rowlist,'nontrivial':nontrivial,'proofs':proofs,'seconds':time.monotonic()-beg,'phase_contexts_sha256':hashlib.sha256((O/'leaf-phase-contexts-exact.json').read_bytes()).hexdigest()},separators=(',',':'))+'\n');print('DONE groups',len(proofs),'nontrivial',nontrivial,'seconds',time.monotonic()-beg,flush=True)
