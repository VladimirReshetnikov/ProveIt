from pathlib import Path
from collections import defaultdict
P=Path('/dev/shm/zfc214-9d0ff4abecf6/incoming-late/Transfer_Compiler_201_Nodes_214_Target_Unmet_2026-10-21/Transfer_Compiler_201_Nodes_214_Target_Unmet_2026-10-21/machine')
T={}
for line in (P/'transfer215.native.tm').read_text().splitlines():
 if line.startswith('#'):continue
 q,b,w,d,z=line.split();T[int(q),int(b)]=(int(w),1 if d=='R' else -1,int(z))
Q={q for q,b in T};inc=defaultdict(list)
for (q,b),(w,d,z) in T.items():inc[z].append((q,b,w,d))
def mark(q):
 if q==0:return None
 if any(d!=1 for _,_,_,d in inc[q]):return None
 ms={w for _,_,w,_ in inc[q]}
 return next(iter(ms)) if len(ms)==1 else None

pairs=[]
for a in Q:
 for b in Q:
  if a>=b:continue
  for bit in (0,1):
   if T[a,1-bit]!=T[b,1-bit]:continue
   if T[a,bit]==T[b,bit]:print('DUPLICATE',a,b)
   if T[a,bit][:2]!=(bit,1) or T[b,bit][:2]!=(bit,1):continue
   ma,mb=mark(a),mark(b)
   pairs.append((a,b,bit,ma,mb))
   if ma is None or mb is None or ma==mb:continue
   x0,x1=[T[q,bit][2]for q in sorted([a,b],key=mark)]
   for r in Q-{a,b}:
    if T[r,0][:2]!=(0,1) or T[r,1][:2]!=(1,1):continue
    z0,z1=T[r,0][2],T[r,1][2]
    if z0 not in Q-{a,b} or z1 not in Q-{a,b}:continue
    if T[z0,bit]==(bit,1,x0) and T[z1,bit]==(bit,1,x1):print('FOLD',a,b,bit,ma,mb,'via',r)
print('pairs',len(pairs))
for a,b,bit,ma,mb in pairs: print(a,b,'different bit',bit,'targets',T[a,bit][2],T[b,bit][2],'marks',ma,mb,'incoming',inc[a],inc[b])
