from pathlib import Path
import sys,json,time,hashlib
B=Path('/dev/shm/zfc214-9d0ff4abecf6');K=B/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215';O=B/'physical/late-transfer'
U=Path('/dev/shm/zfc214-9d0ff4abecf6/incoming-late/Transfer_Compiler_201_Nodes_214_Target_Unmet_2026-10-21/Transfer_Compiler_201_Nodes_214_Target_Unmet_2026-10-21')
sys.path[:0]=[str(K/'code'),str(K/'code/runtime-inputs/runtime')]
import build221 as b,symbolic_runtime as s
f=O/'repair26-214.native.tm';T=b.read_table(f.read_bytes());ss=json.loads((U/'source/transfer201.sites.json').read_text())
m={int(q):int(z)for q,z in json.loads((K/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
for q in{q for q,_ in T}|{254}:m.setdefault(q,q+1000)
L={(m[q],bit):(w,d,m[z])for(q,bit),(w,d,z)in T.items()};lemmas,_=s.prove_blocks(L)
start=time.monotonic();cases=0;fail=None
for i,site in enumerate(ss):
 for pos in ([False,True]if site[1]=='CD'else[False]):
  try:s.case(L,lemmas,site,pos)
  except Exception as e:fail={'site_index':i,'site':site,'positive':pos,'error':repr(e)};break
  cases+=1
 if fail:break
 if i%500==0:print('sites',i,'cases',cases,'seconds',time.monotonic()-start,flush=True)
out={'status':'RUNTIME_FAIL'if fail else'ALL_NATURAL_RUNTIME_PASS','cases':cases,'fail':fail,'seconds':time.monotonic()-start,'table_sha256':hashlib.sha256(f.read_bytes()).hexdigest()};(O/'repair26-runtime.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
