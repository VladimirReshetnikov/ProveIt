from pathlib import Path
from collections import defaultdict
P=Path('/dev/shm/zfc214-9d0ff4abecf6/incoming-late/Transfer_Compiler_201_Nodes_214_Target_Unmet_2026-10-21/Transfer_Compiler_201_Nodes_214_Target_Unmet_2026-10-21/machine')
T={}
for line in (P/'transfer215.native.tm').read_text().splitlines():
 if line.startswith('#'):continue
 q,b,w,d,z=line.split();T[int(q),int(b)]=(int(w),1 if d=='R' else -1,int(z))
Q={q for q,b in T};inc=defaultdict(list)
for (q,b),(w,d,z) in T.items():inc[z].append((q,b,w,d))
def mark(q):
 if q==0:return None
 if any(d!=1 for _,_,_,d in inc[q]):return None
 ms={w for _,_,w,_ in inc[q]}
 return next(iter(ms)) if len(ms)==1 else None

from functools import lru_cache
import itertools,json,sys,time
OUT=Path('/dev/shm/zfc214-9d0ff4abecf6/physical/late-transfer')
@lru_cache(None)
def contexts(q,k):
 if not k:return {''}
 if q==0:return set(map(''.join,itertools.product('01',repeat=k)))
 ss=set()
 for p,b,w,d in inc[q]:
  if d==-1:ss.update(map(''.join,itertools.product('01',repeat=k)))
  else:ss.update(x+str(w)for x in contexts(p,k-1))
 return ss

def trial(e,c,b,limit):
 # known input c at [-len(c),-1], b at 0. return (target, visited rows, duration) possible exact net +1 no tape change.
 tape={i-len(c):int(x)for i,x in enumerate(c)};tape[0]=b;init=tape.copy();w,d,q=e;tape[0]=w;h=d;ans={};used=set();visited=set()
 for step in range(1,limit+1):
  if h==1 and tape==init:ans[q]=(set(used),step)
  if q==254 or (q,h,tuple(sorted(tape.items()))) in visited:break
  visited.add((q,h,tuple(sorted(tape.items()))))
  if h not in tape:
   # Unknown bit cannot be written differently; if both rows preserve and go same place, no tape dependence.
   if T[q,0][0]==0 and T[q,1][0]==1 and T[q,0][1:]==T[q,1][1:]:
    used.add((q,0));used.add((q,1));d,z=T[q,0][1:];q=z;h+=d;continue
   break
  r=tape[h];w,d,z=T[q,r];used.add((q,r));tape[h]=w;h+=d;q=z
 return ans

def main(k,limit):
 states=sorted(Q-{0})
 # Filter same simple branch pairs initially.
 pairs=[(a,b)for a in states for b in states if a<b and any(T[a,x]==T[b,x]for x in(0,1))]
 cache={};cnt=0
 for a,b in pairs:
  ca,cb=contexts(a,k),contexts(b,k)
  for bit in(0,1):
   x,y=T[a,bit][2],T[b,bit][2]
   if x==y:continue
   if T[a,bit][:2]!=(bit,1) or T[b,bit][:2]!=(bit,1):continue
   if ca & cb:continue
   for w in(0,1):
    for d in(-1,1):
     for r in sorted(Q-{a,b}):
      e=(w,d,r);usedall=set();dur=[];ok=True
      for qs,goal in ((ca,x),(cb,y)):
       for c in qs:
        key=(e,c,bit)
        if key not in cache:cache[key]=trial(e,c,bit,limit)
        s=cache[key]
        if goal not in s or {q for q,z in s[goal][0]}&{a,b}:ok=False;break
        usedall|=s[goal][0];dur.append(s[goal][1])
       if not ok:break
      if ok:
       ans={'a':a,'b':b,'bit':bit,'entry':e,'contexts_a':sorted(ca),'contexts_b':sorted(cb),'targets':[x,y],'rows':sorted(usedall),'durations':dur,'k':k}
       print('FOLD',json.dumps(ans),flush=True);(OUT/f'found-{a}-{b}-{bit}-k{k}.json').write_text(json.dumps(ans,indent=2));cnt+=1
 print('FINISH',k,len(pairs),len(cache),'folds',cnt,flush=True)
if __name__=='__main__':main(int(sys.argv[1])if len(sys.argv)>1 else 2,int(sys.argv[2])if len(sys.argv)>2 else 24)
