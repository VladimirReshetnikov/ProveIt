# Two exact engine-entry reroutes in K215

Let T be the accepted native table at commit c8029f50d324910a36694c39a1e62f5720c36f4c. Simultaneously replace

- `13/1: 1L31` by `1L107`;
- `83/1: 0L42` by `0L57`.

Every other row is unchanged. The resulting table remains215 states. These changes are preparation for state reallocation, not by themselves a214-state result.

## Whole-tape proof

At the changed row put the head at0; the read symbol is1. Denote the arbitrary predecessor symbol at-1 byx. All following blocks read only these two cells. They therefore hold for every assignment to every other tape cell, with no runtime invariant needed.

For state13, ifx=0, the old block goes `13→31→21`, and the new block goes `13→107→21`. Both end at head0 with unchanged tape after2 steps. Ifx=1, the old block goes `13→31→47→16`, and the new block goes `13→107→126→16`. Both end at head-1 after3 steps and have changed only cell0 from1 to0.

For state83, ifx=0, the old block goes `83→42→13→91→82→49` in5 steps and the new block goes `83→57→61→49` in3 steps. Both end at head1 after changing cell0 from1 to0 and leave cell-1=0 unchanged. Ifx=1, the old block is `83→42→16` and the new is `83→57→16`, both2 steps, ending at head-2 with both cells-1 and0 equal to0.

The interiors contain neither rewritten row. Thus the two rewrites compose without circularity: segment any run at visits to either rewritten row, replace its finite positive-length block, and preserve the full boundary configuration. Halting equivalence follows on every starting tape. For infinite runs, every rewritten block has length at least2 and at most5, so block substitution cannot collapse infinitely many transitions into a finite run.

The same proof permits107→128 in the first change (using intermediate141 in place of126); and57→126 or141 in the second (their zero branches reach49 through71/91/82 or161, respectively). `check_reroutes.py` verifies all six variants, all four two-cell cases per variant, exact changed-row sets, full local tape equality, and absence of nested rewritten rows.

## Allocation relevance

All incoming rows to31 are13/1,20/1,69/1. After the first reroute, every arrival at31 moves right and leaves a predecessor1. All incoming rows to42 are28/1,83/1,109/1. After the second reroute, every arrival at42 moves right and leaves a predecessor1. Their former backward microengine uses can now be removed from the engine protection census. The full source/runtime census must be recomputed before treating any particular row as available.
