# Research toward a 214-state ZFC consistency machine

**Status: the requested machine with at most 214 working states has not been constructed and verified.** This packet is a research contribution, not an accepted `candidate-k214`. The accepted K215 baseline is reproduced unchanged; the smaller transition tables are explicitly rejected experiments.

The target is an ordinary deterministic two-symbol machine on an initially blank, two-way infinite tape, with every initialization state included in its working-state count and a separate halt excluded. The desired statement is

    ZFC proves: nonhalting of the exact blank-start machine iff Con(ZFC).

No larger alphabet, prewritten input, omitted bootstrap cost, proof-search timeout, or finite execution prefix is used to claim that statement.

## Read first

- `report.pdf` and `report.tex`: mathematical exposition, exact scope, proofs and primary-source links.
- `research-status.json`: machine-readable distinction between proved certificates, source-level results, rejected tables and bounded searches.
- `verify.py`: fast standalone replay of the principal certificates, using only the Python standard library.
- `MANIFEST.sha256`: integrity of every delivered file other than the manifest itself.
- `NOTICE.md` and the retained upstream notices/licenses: attribution and component terms.

## Main reusable results

1. **All six pairwise identifications in the four-variable propositional row are insufficient.** Explicit four- and five-valued algebras validate K215’s literal retained axioms and theory bundle, every identity instance, MP and GEN, while separating refutation code 1. The interpretation is defined on every natural-number code, including junk and the alias `I(0,0)=0`. Derivation induction gives an ordinary ZFC proof of nonrefutation for each precisely specified weakening. Assuming ZFC is consistent, these calculi cannot satisfy the requested ZFC-provable consistency equivalence. This is not a general obstruction to weaker equiconsistent formalisms.

2. **An unbounded source invariant.** A separate checker reconstructs the control graph and validates all transfers over natural-number buckets with an unbounded final bucket. It proves three dead leaves, two forced-zero tests and 4,295 singleton entry assertions from every source root with `T=W=H=0`. A second certificate begins with arbitrary enumerator cutoff and all eight scratch registers zero. A dead-subtree transport theorem states exactly which rewrites preserve execution.

3. **Concrete failures of misleading state folds.** The clean-padding `126 -> 13` fold preserves the complete 95,714-step blank prefix but fails a later arithmetic phase at source ordinal 50. The six-zero scanner fold fails 72 of 6,176 arbitrary-natural cases. Small portable checkers replay exact tapes and endpoints. These failures refute the proposed source simulation, not every conceivable interpretation of those tables.

4. **Valid all-tape engine reroutes.** Two local block substitutions have exact finite proofs for arbitrary surrounding tape. Six combinations give 24 checks. They preserve behavior but the machines obtained here still have 215 working states.

5. **Equiconsistent source changes.** Cache-return and omitted-zero MP variants have explicit strong compiler transfers. K/S/Peirce and correctly gated unbundling are also developed. Their source costs and implementation obligations are recorded separately from machine-state counts.

6. **A more general physical allocator.** The model uses 180 occurrence-sensitive roles, 11,401 exact phase contexts, 45,637 internal macro actions and 1,985 phase-checked leaf actions. Helper rows are preserved only when a selected macro needs them. A deterministic monotone constraint algorithm rejects all 28,463 tested single-host deletions in the full recorded vocabulary. MILP and CP-SAT runs have scoped receipts; timeouts do not establish infeasibility.

7. **Direct register-sum coalescing is concretely obstructed.** Forty-seven short source execution witnesses cover all 36 register pairs and the relevant N/L zero-test sites. These are counterexamples to the specified simple sum encodings, not a register lower bound.

## Fast offline replay

Use Python 3.10 or later, with assertions enabled. No package installation, optimizer, repository checkout or network access is needed.

```sh
python3 -B verify.py
```

Expected top-level status: `PASS`, with `accepted_smaller_machine: false`. The run checks two unbounded source invariants; nine positive finite-algebra certificates with the older Code254 scope explicitly separated; the literal-formula negative control; all six literal K215 identification countermodels; 47 concrete coalescing witnesses; 24 all-tape local block cases; three concrete physical contract counterexamples; the complete 95,714-step unchanged blank prefix; and two exact transfer/pop MP source-splice correspondences, each checking 6,173 outside edges. It writes fresh receipts under `out/verification/`.

The numerical search programs are not trusted dependencies of these concrete checks. Ordinary proof arguments in the report explain how finite invariant and algebra certificates imply statements about all natural numbers and all finite derivations. The executable scripts are not proof-assistant kernel artifacts. Run without `-O` or `PYTHONOPTIMIZE`.

For the two compact subpackets separately:

```sh
python3 -B formalism/replay_formalism_fast.py --source repo/Computability/BusyBeaver/Research/ZFC/candidate-k215/sites215.json --out out/formalism
python3 -B physical/portable/verify_evidence.py
```

The first command replays the exact literal formulas extracted from the source, rather than substituting a classically equivalent older bundle.

## Full baseline runtime replay

The accepted baseline, its exact reconstruction, full symbolic runtime checker, source proof and provenance are retained under

    repo/Computability/BusyBeaver/Research/ZFC/candidate-k215/

Its `reproduction.md` gives the complete commands. For a fresh all-natural runtime proof from the packet root:

```sh
python3 -B repo/Computability/BusyBeaver/Research/ZFC/candidate-k215/code/fresh_check.py --out out/k215-runtime
```

Use a fresh output directory. Require the explicit `UNIVERSAL_MATHEMATICAL_PASS` status and all 6,176 cases, not merely exit code zero. This optional replay takes longer than the fast certificate suite. No new exact-table Lean/Rocq build or internal PA endpoint is supplied by this packet.

The rejected 214-state clean-padding table’s failed runtime receipt is in `global/k214-runtime/`; the scanner’s is in `physical/scanner214-all/`. The exact compact tapes needed for independent counterexamples are in `physical/portable/`.

## Optional synthesis replay

Large historical JSON inputs are gzip-compressed without changing their uncompressed bytes. Before a search that needs them, run:

```sh
python3 -B materialize.py
```

`compressed-artifacts.json` binds each original size and digest. The finite proof checks above do not require this expansion. To keep the original research scripts and historical input hashes intact, `run_research.py` relocates task-local path string constants in memory before executing the selected program. It does not edit the archived scripts. Optional solver versions are listed in `requirements-search.txt`; install them in your own environment.

A reproducible exact finite search using only the standard library:

```sh
mkdir -p out
python3 -B run_research.py global/pair_merge_conditional.py --roles physical/roles-conditionalfull.json --macros physical/internal-action-macros-conditionalfull.json --out out/single-host-search
```

A CP-SAT control and target search:

```sh
python3 -B run_research.py encoding/allocate_roles_cpsat.py --roles physical/roles-conditionalfull.json --macros physical/internal-action-macros-conditionalfull.json --control --warmstart --bound 215 --seconds 15 --out out/cpsat-control
python3 -B run_research.py encoding/allocate_roles_cpsat.py --roles physical/roles-conditionalfull.json --macros physical/internal-action-macros-conditionalfull.json --bound 214 --distance 8 --seconds 180 --out out/cpsat-target
```

The control must recover the byte-identical baseline. A target allocation is only a synthesis witness: full phase-sensitive arithmetic proof, initialization, source calibration and execution composition must still be checked for the emitted exact table. A `NO_ALLOCATION` receipt with solver status `UNKNOWN` or a time limit is not an infeasibility proof.

The 185-row vocabulary’s conflict cliques must not be supplied to the full vocabulary. Their certificates bind the smaller vocabulary’s exact hashes; the full vocabulary has different compatibility behavior.

## Build the PDF

A standard TeX Live installation is sufficient:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The three included formalism `.tex` files are included by the main source. Typesetting is separate from mathematical verification. The delivered PDF is rendered and visually checked.

## Late incoming submissions and combinations

Three public research archives arrived during this investigation. Their original ZIP bytes, extracted sources and attribution are preserved under `incoming-late/`, with exact public commit links in the report. The two transfer/pop packets describe the same 201-node / 215-state construction, not two independent improvements. The other packet proves a 214-state runtime whose blank startup instead enters a provable outward ray after 85 steps; it explicitly says the requested target is unmet.

Our fresh transfer/pop runtime replay passes all 6,209 cases and extracts 144 engine rows and 11,453 exact phase contexts. Its cache-return and omit-zero combinations have repaired strong compiler proofs and independent source-splice checks; both still have 201 source nodes, and the narrow physical allocations require 216 states. The old K215 phase catalogs must not be reused on those changed sources. `formalism/late-transfer-addendum.tex` develops the complete command argument and its inherited protected-stack-credit premise.

The final focused bootstrap experiment is in `late-bootstrap/`: a proved `83/1` reroute, 5,536 freshly collected radius-eight contexts at states 42 and 51 from all 6,176 cases, and two completed coordinated repair families. Neither found a structural seed. This is a bounded negative search, not a machine-size lower bound.

The adjacent-code restriction `A=U+1` remains open logically. Its exact source costs 204 subtrees, reduced to 203 by a bounded reassociation search. No consistency equivalence or smaller binary machine follows from that experiment.

## Repository identity and incorporation

Repository: https://github.com/VladimirReshetnikov/ProveIt

Research baseline snapshot: `c8029f50d324910a36694c39a1e62f5720c36f4c`.

K215 acceptance commit: `a61476422532a5d3b7dec11fc7a92751fe0d60f8`.

Native K215 SHA-256: `9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2`.

Source SHA-256: `17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba`.

This packet belongs in a research subdirectory or incoming archive. It should not replace the accepted baseline, advertise an accepted K214 bound, or turn optimizer timeouts into lower bounds. Preserve the exact rejected/proved/source-only distinctions and all inherited attribution.
