from pathlib import Path
from collections import defaultdict
import json,sys,time
B=Path('/dev/shm/zfc214-9d0ff4abecf6');K=B/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215';O=B/'global/pair-macro-merges';O.mkdir(exist_ok=True)
sys.path.insert(0,str(K/'code'));import build221 as bu
T=bu.read_table((K/'k215.native.tm').read_bytes());R0=json.loads((B/'physical/roles-leafall.json').read_text());R={r['id']:r for r in R0['roles']};P=set(map(tuple,R0['protected']));Q=sorted({q for q,b in T});E=set(map(tuple,json.loads((B/'global/engine.json').read_text())['rows']));S=set(map(tuple,json.loads((B/'global/startup_rows.json').read_text())['rows']));mac=json.loads((B/'physical/internal-action-macros.json').read_text());M={r:rr['old_q']for r,rr in R.items()};oldhosts=defaultdict(list)
for r,q in M.items():oldhosts[q].append(r)
A={}
for row in mac['rows']:
 r,b=row['role'],row['bit'];by={x['prefix']:x['role']for x in R[r]['children'][b]['targets']};A[r,b]=[(tuple(x['action']),[(by[e['prefix']],e['target'])for e in x['endpoints']])for x in row['alternatives']]
parents=defaultdict(set)
for r,rr in R.items():
 for b,ch in enumerate(rr['children']):
  if ch['kind']=='internal':
   for c in ch['targets']:parents[M[c['role']]].add((r,b))
def options(r,b,delete=None,host=None):
 ch=R[r]['children'][b]
 if ch['kind']=='leaf':return set(map(tuple,ch['allowed_actions']))
 mm=lambda c:host if M[c]==delete else M[c]
 zz={mm(c['role'])for c in ch['targets']};opts={(b,1,next(iter(zz)))}if len(zz)==1 else set()
 for act,ends in A.get((r,b),[]):
  if all(mm(c)==t for c,t in ends):opts.add(act)
 return opts
baseopts={(r,b):options(r,b)for r in R for b in(0,1)}
assert all(T[M[r],b]in baseopts[r,b]for r in R for b in(0,1)),[(r,b)for r in R for b in(0,1)if T[M[r],b]not in baseopts[r,b]]
basegroup={}
for q,rs in oldhosts.items():
 for b in(0,1):basegroup[q,b]=set.intersection(*(baseopts[r,b]for r in rs))
beg=time.monotonic();found=[];tested=0;reasons=defaultdict(int)
for dead in Q:
 if dead in{0,84}or any(q==dead for q,b in E):continue
 # Any retained protected row targeting dead prevents this single-state deletion.
 if any(q!=dead and T[q,b][2]==dead for q,b in P):continue
 for target in Q:
  if target==dead:continue
  tested+=1;newopts={rb:options(*rb,dead,target)for rb in parents[dead]};groups={q:list(rs)for q,rs in oldhosts.items()if q!=dead};groups.setdefault(target,[]).extend(oldhosts.get(dead,[]));affected={target}|{M[r]for r,b in parents[dead]};affected.discard(dead);edits={};valid=True
  for q in affected:
   for bit in(0,1):
    opts=set.intersection(*(newopts.get((r,bit),baseopts[r,bit])for r in groups[q]));opts={a for a in opts if a[2]!=dead}
    if(q,bit)in P:opts&={T[q,bit]}
    if not opts:valid=False;break
    act=T[q,bit]if T[q,bit]in opts else min(opts,key=lambda a:(a!=T[q,bit],a));edits[q,bit]=act
   if not valid:break
  if not valid:reasons['incompatible_row']+=1;continue
  NT={};rolekeys={(q,b)for q,rs in groups.items()for b in(0,1)}
  for(q,b),old in T.items():
   if q==dead:continue
   if(q,b)in edits:act=edits[q,b]
   elif(q,b)in P or(q,b)in rolekeys:act=old
   else:act=(b,1,q)if old[2]==dead else old
   NT[q,b]=act
  if any(v[2]==dead for v in NT.values()):reasons['dangling']+=1;continue
  changed=[{'row':list(k),'old':list(T[k]),'new':list(v)}for k,v in NT.items()if T[k]!=v]
  preserve=all(NT[k]==T[k]for k in S if k[0]!=dead)and all(k[0]!=dead for k in S)
  tag=f'{dead}-to-{target}';(O/(tag+'.native.tm')).write_bytes(bu.table_bytes(NT));record={'removed':dead,'target':target,'states':len(Q)-1,'startup_preserved':preserve,'changes':changed};found.append(record);print('FOUND',tag,'startup',preserve,'changes',len(changed),flush=True)
res={'status':'EXACT_SINGLE_SOURCE_HOST_MERGE_SEARCH','tested':tested,'found':found,'reasons':dict(reasons),'seconds':time.monotonic()-beg};(O/'result.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items()if k!='found'},indent=2),'found',len(found),flush=True)
