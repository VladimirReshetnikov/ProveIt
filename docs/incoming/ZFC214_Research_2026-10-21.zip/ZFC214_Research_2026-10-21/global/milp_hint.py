from types import SimpleNamespace
import numpy as np
from scipy.optimize._highspy import _core as h

def solve(cost,A,lo,hi,hint,seconds,lower=None,upper=None,integrality=None):
 A=A.tocsc();n=len(cost);lower=np.zeros(n)if lower is None else lower;upper=np.ones(n)if upper is None else upper
 check=A@hint
 bad=(check<np.asarray(lo)-1e-6)|(check>np.asarray(hi)+1e-6)
 assert not np.any(bad),('Bad primal hint',np.where(bad)[0].tolist()[:20],check[bad].tolist()[:20])
 lp=h.HighsLp();lp.num_col_=n;lp.num_row_=len(lo);lp.col_cost_=cost;lp.col_lower_=lower;lp.col_upper_=upper;lp.row_lower_=lo;lp.row_upper_=hi;lp.integrality_=[h.HighsVarType.kInteger]*n if integrality is None else[h.HighsVarType.kInteger if v else h.HighsVarType.kContinuous for v in integrality]
 mat=h.HighsSparseMatrix();mat.num_col_=n;mat.num_row_=len(lo);mat.format_=h.MatrixFormat.kColwise;mat.start_=A.indptr.astype(np.int32);mat.index_=A.indices.astype(np.int32);mat.value_=A.data;lp.a_matrix_=mat
 solver=h._Highs();solver.setOptionValue('output_flag',True);solver.setOptionValue('threads',1);solver.setOptionValue('time_limit',float(seconds));solver.setOptionValue('mip_rel_gap',0.0);solver.passModel(lp)
 sol=h.HighsSolution();sol.col_value=hint;sol.value_valid=True;print('Submitting hint',flush=True);solver.setSolution(sol);print('Running solver',flush=True);solver.run();print('Solver finished',flush=True);out=solver.getSolution();info=solver.getInfo();status=solver.getModelStatus()
 return SimpleNamespace(x=np.asarray(out.col_value)if out.value_valid else None,message=str(status),mip_gap=info.mip_gap,mip_dual_bound=info.mip_dual_bound,objective=info.objective_function_value,nodes=info.mip_node_count)
