from pathlib import Path
import sys,json,collections,time,hashlib,argparse
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import lil_matrix
ROOT=Path('/dev/shm/zfc214-9d0ff4abecf6/repo/Computability/BusyBeaver/Research/ZFC/candidate-k215')
sys.path.insert(0,str(ROOT/'code'))
import source_language as s
import build221 as b
P=Path(__file__).parent

def edge(T,q,p,bit):
 tape={-1:1,**{i:int(v)for i,v in enumerate(p+str(bit))}};before=tape.copy();h=len(p);used=[]
 for _ in range(100):
  if h==len(p)+1:return (q if tape==before else None),used
  if h not in tape or(q,tape[h])not in T:return None,used
  k=(q,tape[h]);used.append(k);w,d,q=T[k];tape[h]=w;h+=d
 return None,used

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--seconds',type=int,default=120);ap.add_argument('--drop',type=int);ap.add_argument('--table',type=Path,default=ROOT/'k215.native.tm');ap.add_argument('--engine',type=Path,default=P/'engine.json');a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=False)
 T=b.read_table(a.table.read_bytes());tree=s.tree(json.loads((ROOT/'sites215.json').read_text()));original=b.read_table((ROOT/'k215.native.tm').read_bytes());g,ps=b.decoder_map(original,tree)
 oldstates=collections.defaultdict(set);occ=collections.defaultdict(list)
 for q,ns in g.items():
  for n in ns:oldstates[n].add(q)
  for p in ps[q]:occ[s.subtree(tree,p)].append(p)
 special={q for q,ns in g.items()if len(ns)>1 or any(not s.leaf(n[k])and T[q,k][:2]!=(k,1)for n in ns for k in(0,1)) or any(len(oldstates[n])>1 for n in ns)}|{84}
 frozen_nodes=set.union(*(g[q]for q in special));nodes=[n for n in occ if n not in frozen_nodes]
 fixed={n:set(qs)for n,qs in oldstates.items()if n not in nodes}
 used_fixed=set.union(*fixed.values())
 pool=sorted({q for q,_ in T}-used_fixed-{0})
 protected={tuple(row)for row in json.loads(a.engine.read_text())['rows']}
 # Maintain every non-direct contextual edge, and its exact endpoint binding.
 pins=collections.defaultdict(set);flex={}
 for q in sorted(used_fixed):
  for bit in(0,1):
   childs={n[bit]for n in g[q]}
   if len(childs)==1 and not s.leaf(next(iter(childs)))and T[q,bit][:2]==(bit,1)and(q,bit)not in protected:
    flex[q,bit]=next(iter(childs));continue
   protected.add((q,bit))
   for p in ps[q]:
    n=s.subtree(tree,p);ch=n[bit]
    if s.leaf(ch):continue
    z,tr=edge(T,q,p,bit);assert z is not None;protected.update(tr);pins[ch].add(z)
 # Protect every decoder helper row (intermediate local steps).
 for q in g:
  for p in ps[q]:
   n=s.subtree(tree,p)
   for bit,ch in enumerate(n):
    if s.leaf(ch):continue
    z,tr=edge(T,q,p,bit);assert z is not None;protected.update(tr[1:])
 leafacts=collections.defaultdict(collections.Counter)
 for q,ns in g.items():
  for n in ns:
   for bit,ch in enumerate(n):
    if s.leaf(ch):leafacts[ch,bit][T[q,bit]]+=1
 defaults={}
 for key,acts in leafacts.items():
  dr=[z for z in acts if z[:2]==(key[1],1)]
  defaults[key]=max(dr or acts,key=lambda z:acts[z])
 for op,arg,q in [('CC',1,1),('CC',2,16),('CB',1,302)]:
  key=((op,arg),1)
  if key in leafacts:defaults[key]=(0,-1,q)
 domains={n:set(pool)for n in nodes};req={}
 for n,states in pins.items():
  if n in domains:domains[n]&=states if len(states)==1 else set()
  else:assert states<=fixed[n],('bad pin',states,fixed[n])
 if a.drop is not None:
  for d in domains.values():d.discard(a.drop)
 for n in nodes:
  for q in list(domains[n]):
   valid=True;r=[]
   for bit,ch in enumerate(n):
    if(q,bit)not in protected:continue
    act=T[q,bit]
    if s.leaf(ch):valid &= act==defaults.get((ch,bit))or(q in oldstates[n] and act in leafacts[ch,bit])
    elif act[:2]!=(bit,1):valid=False
    elif ch in fixed:valid &= act[2]in fixed[ch]
    else:r.append((ch,act[2]))
   if valid:req[n,q]=r
   else:domains[n].remove(q)
 # Fixed state row protected direct targets constrain child assignment too.
 for (q,bit),ch in flex.items():
  if(q,bit)in protected:
   if ch in domains:domains[ch]&={T[q,bit][2]}
   else:assert T[q,bit][2]in fixed[ch]
 changed=True
 while changed:
  changed=False
  for n in nodes:
   for q in list(domains[n]):
    if any(z not in domains[ch]for ch,z in req[n,q]):domains[n].remove(q);changed=True
 essential={0}|used_fixed|{q for q,bit in protected}|{T[k][2]for k in protected};essential.discard(254)
 receipt={'status':'PENDING','nodes':len(nodes),'fixed':len(fixed),'fixed_states':len(used_fixed),'pool':pool,'essential':sorted(essential),'protected':sorted(protected),'domain_sizes':[len(domains[n])for n in nodes],'flex_fixed_rows':len(flex)}
 def finish():
  (a.out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k not in('pool','essential','protected','domain_sizes','changed_rows','assignments')},indent=2),flush=True)
 if any(not d for d in domains.values()):receipt['status']='EMPTY_DOMAIN';finish();return
 choices=[(n,q)for n in nodes for q in sorted(domains[n])];idx={v:i for i,v in enumerate(choices)};rows=[];lo=[];hi=[]
 for n in nodes:rows.append({idx[n,q]:1 for q in domains[n]});lo.append(1);hi.append(1)
 for q in pool:rows.append({idx[n,q]:1 for n in nodes if q in domains[n]});lo.append(0);hi.append(1)
 for n,q in choices:
  for ch,z in req[n,q]:rows.append({idx[n,q]:1,idx[ch,z]:-1});lo.append(-np.inf);hi.append(0)
 A=lil_matrix((len(rows),len(choices)))
 for i,row in enumerate(rows):
  for j,v in row.items():A[i,j]=v
 costs=np.array([10000*int(q not in essential)+int(q not in oldstates[n])+q/1e6 for n,q in choices])
 start=time.monotonic();ans=milp(costs,integrality=np.ones(len(choices)),bounds=Bounds(0,1),constraints=LinearConstraint(A.tocsc(),lo,hi),options={'time_limit':a.seconds})
 receipt.update(solver=ans.message,seconds=time.monotonic()-start,variables=len(choices),constraints=len(rows))
 if ans.x is None:receipt['status']='NO_ALLOCATION';finish();return
 mapped={n:set(qs)for n,qs in fixed.items()}
 for(n,q),x in zip(choices,ans.x):
  if x>.5:mapped[n]={q}
 N=T.copy()
 for n in nodes:
  q=next(iter(mapped[n]))
  for bit,ch in enumerate(n):
   if(q,bit)in protected:continue
   N[q,bit]=defaults[ch,bit]if s.leaf(ch)else(bit,1,min(mapped[ch]))
 for(q,bit),ch in flex.items():
  if(q,bit)not in protected:N[q,bit]=(bit,1,min(mapped[ch]))
 assert all(N[k]==T[k]for k in protected)
 reach={0};todo=[0]
 for q in todo:
  for bit in(0,1):
   z=N[q,bit][2]
   if z!=254 and z not in reach:reach.add(z);todo.append(z)
 N={k:v for k,v in N.items()if k[0]in reach};fail=[]
 try:
  ng,newpaths=b.decoder_map(N,tree)
  for q,ns in ng.items():
   for n in ns:
    if q not in mapped[n]:fail.append([q,sorted(mapped[n])])
 except Exception as ex:fail.append(str(ex))
 receipt.update(status='PREFIX_PASS'if not fail else'PREFIX_FAIL',states=len(N)//2,failures=fail,removed=sorted({q for q,_ in T}-reach),changed_rows=[list(k)+list(v)for k,v in N.items()if T.get(k)!=v],assignments=[{'path':occ[n][0],'q':min(mapped[n]),'old':sorted(oldstates[n])}for n in nodes])
 (a.out/'candidate.native.tm').write_bytes(b.table_bytes(N));finish()
if __name__=='__main__':main()
