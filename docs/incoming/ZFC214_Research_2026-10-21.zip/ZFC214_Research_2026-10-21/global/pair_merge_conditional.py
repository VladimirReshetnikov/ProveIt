"""Exact single source-host merges with conditional baseline helper rows.
All dependencies have the monotone form chosen action => row=baseline(row).
Thus preserve every still-possible baseline action, propagate impossibility,
and choose any surviving nonbaseline action at the remaining source rows.
"""
from pathlib import Path
from collections import defaultdict,deque
import json,sys,time,argparse
B=Path('/dev/shm/zfc214-9d0ff4abecf6');K=B/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215'
sys.path.insert(0,str(K/'code'));import build221 as bu,source_language as sl
ap=argparse.ArgumentParser();ap.add_argument('--roles',type=Path,default=B/'physical/roles-conditional185.json');ap.add_argument('--macros',type=Path,default=B/'physical/internal-action-macros-conditional185.json');ap.add_argument('--out',type=Path,default=B/'global/pair-conditional-merges');a=ap.parse_args();O=a.out;O.mkdir(exist_ok=True)
T=bu.read_table((K/'k215.native.tm').read_bytes());R0=json.loads(a.roles.read_text());R={r['id']:r for r in R0['roles']};E=set(map(tuple,json.loads((B/'global/engine.json').read_text())['rows']));Q=sorted({q for q,b in T});S=set(map(tuple,json.loads((B/'global/startup_rows.json').read_text())['rows']));mac=json.loads(a.macros.read_text());M={r:rr['old_q']for r,rr in R.items()};oldhosts=defaultdict(list)
for r,q in M.items():oldhosts[q].append(r)
A={}
for row in mac['rows']:
 r,b=row['role'],row['bit'];by={x['prefix']:x['role']for x in R[r]['children'][b]['targets']};A[r,b]=[(tuple(x['action']),[(by[e['prefix']],e['target'])for e in x['endpoints']],set(map(tuple,x['dependencies'])))for x in row['alternatives']]
parents=defaultdict(set)
for r,rr in R.items():
 for b,ch in enumerate(rr['children']):
  if ch['kind']=='internal':
   for c in ch['targets']:parents[M[c['role']]].add((r,b))
def options(r,b,delete=None,host=None):
 ch=R[r]['children'][b]
 if ch['kind']=='leaf':return {tuple(x['action']):set(map(tuple,x['dependencies']))for x in ch['action_dependencies']}
 mm=lambda c:host if M[c]==delete else M[c]
 zz={mm(c['role'])for c in ch['targets']};opts={(b,1,next(iter(zz))):set()}if len(zz)==1 else{}
 for act,ends,deps in A.get((r,b),[]):
  if all(mm(c)==t for c,t in ends):opts[act]=deps
 return opts
baseopts={(r,b):options(r,b)for r in R for b in(0,1)}
assert all(T[M[r],b]in baseopts[r,b]for r in R for b in(0,1))
def combine(opts):
 common=set.intersection(*(set(o)for o in opts))
 return {act:set().union(*(o[act]for o in opts))for act in common}
basegroup={(q,b):combine([baseopts[r,b]for r in rs])for q,rs in oldhosts.items()for b in(0,1)}
def csp(rowopts,dead):
 dom={}
 for k,old in T.items():
  q,b=k
  if q==dead:continue
  if k in rowopts:ops=rowopts[k]
  else:ops={old:set(),(b,1,q):set()}
  dom[k]={act:deps for act,deps in ops.items()if act[2]!=dead and all(x[0]!=dead for x in deps)and(k not in E or act==old)}
  if not dom[k]:return None
 rev=defaultdict(set)
 for k,ops in dom.items():
  for act,deps in ops.items():
   for dep in deps:rev[dep].add((k,act))
 bad=deque(k for k in dom if T[k]not in dom[k]);seen=set(bad)
 while bad:
  dep=bad.popleft()
  for k,act in rev.get(dep,[]):
   if act not in dom[k]:continue
   del dom[k][act]
   if not dom[k]:return None
   if T[k]not in dom[k]and k not in seen:seen.add(k);bad.append(k)
 N={k:T[k]if T[k]in ops else min(ops)for k,ops in dom.items()}
 assert all(N[dep]==T[dep]for k,act in N.items()for dep in dom[k][act]);assert all(N[k]==T[k]for k in E)
 return N
beg=time.monotonic();found=[];tested=0;reasons=defaultdict(int);tree=sl.tree(json.loads((K/'sites215.json').read_text()))
for dead in Q:
 if dead in{0,84}or any(q==dead for q,b in E):continue
 if any(T[k][2]==dead for k in E):continue
 for target in (Q if oldhosts.get(dead)else[0]):
  if target==dead:continue
  tested+=1;newopts={rb:options(*rb,dead,target)for rb in parents[dead]};groups={q:list(rs)for q,rs in oldhosts.items()if q!=dead};groups.setdefault(target,[]).extend(oldhosts.get(dead,[]));affected=({target}if oldhosts.get(dead)else set())|{M[r]for r,b in parents[dead]};affected.discard(dead);rowopts={k:v for k,v in basegroup.items()if k[0]!=dead}
  valid=True
  for q in affected:
   for bit in(0,1):
    rowopts[q,bit]=combine([newopts.get((r,bit),baseopts[r,bit])for r in groups[q]])
    if not rowopts[q,bit]:valid=False;break
   if not valid:break
  if not valid:reasons['empty_source_row']+=1;continue
  N=csp(rowopts,dead)
  if N is None:reasons['dependency_conflict']+=1;continue
  _,pth=bu.decoder_map(N,tree);actual={p:q for q,pcs in pth.items()for p in pcs};newM={r:target if q==dead else q for r,q in M.items()}
  assert all(actual[p]==newM[r]for r,rr in R.items()for p in rr['occurrences'])
  changed=[{'row':list(k),'old':list(T[k]),'new':list(v)}for k,v in N.items()if T[k]!=v];preserve=all(k in N and N[k]==T[k]for k in S)
  tag=f'{dead}-to-{target}';(O/(tag+'.native.tm')).write_bytes(bu.table_bytes(N));record={'removed':dead,'target':target,'states':len(Q)-1,'startup_preserved':preserve,'changes':changed};found.append(record);print('FOUND',tag,'startup',preserve,'changes',len(changed),flush=True)
res={'status':'EXACT_SINGLE_SOURCE_HOST_CONDITIONAL_SEARCH','tested':tested,'found':found,'reasons':dict(reasons),'seconds':time.monotonic()-beg};(O/'result.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items()if k!='found'},indent=2),'found',len(found),flush=True)
