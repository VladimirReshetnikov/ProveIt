"""Sound compatibility cuts for a finite role/macro synthesis vocabulary.
A negative result is relative to that vocabulary, not a TM lower bound.
"""
from pathlib import Path
from itertools import combinations
from collections import defaultdict
import json,time,hashlib,argparse
B=Path('/dev/shm/zfc214-9d0ff4abecf6');O=B/'global';RP=B/'physical/roles185-leafall.json';MP=B/'physical/internal-action-macros185.json'
ap=argparse.ArgumentParser();ap.add_argument('--roles',type=Path,default=RP);ap.add_argument('--macros',type=Path,default=MP);ap.add_argument('--out',type=Path,default=O/'role-conflicts185.json');args=ap.parse_args();RP=args.roles;MP=args.macros
R0=json.loads(RP.read_text());R={r['id']:r for r in R0['roles']};Cat=json.loads(MP.read_text());n=len(R);beg=time.monotonic()
def pair(a,b):return(min(a,b),max(a,b))
def reqcheck(pairs):
 by={};hosts=defaultdict(set)
 for c,q in pairs:
  if c in by and by[c]!=q:return None
  by[c]=q;hosts[q].add(c)
 return frozenset(pair(a,b)for cs in hosts.values()for a,b in combinations(cs,2))
opts={};dyn={}
for r,rr in R.items():
 for bit,ch in enumerate(rr['children']):
  key=r,bit
  if ch['kind']=='leaf':opts[key]={tuple(a):set()for a in ch['allowed_actions']};dyn[key]=None
  else:opts[key]={};dyn[key]={c['role']for c in ch['targets']}
for grp in Cat['rows']:
 r,b=grp['role'],grp['bit'];key=r,b;cm={x['prefix']:x['role']for x in R[r]['children'][b]['targets']}
 for v in grp['alternatives']:
  req={(cm[z['prefix']],z['target'])for z in v['endpoints']}
  if reqcheck(req)is not None:opts[key][tuple(v['action'])]=req
witness={};always=0
for r,s in combinations(R,2):
 for bit in(0,1):
  a=(r,bit);b=(s,bit);ws=set()
  if dyn[a]is not None and dyn[b]is not None:
   cs=sorted(dyn[a]|dyn[b]);ws.add(frozenset(pair(c,d)for c,d in combinations(cs,2)))
  for act in opts[a].keys()&opts[b].keys():
   req=reqcheck(opts[a][act]|opts[b][act])
   if req is not None:ws.add(req)
  for x,y in((a,b),(b,a)):
   if dyn[x]is not None:
    for act,rr in opts[y].items():
     if act[:2]!=(bit,1):continue
     req=reqcheck(rr|{(c,act[2])for c in dyn[x]})
     if req is not None:ws.add(req)
  if frozenset()in ws:ws={frozenset()};always+=1
  witness[r,s,bit]=ws
compatible={pair(r,s)for r in R for s in R};layers=[]
while True:
 rejected=[]
 for r,s in combinations(R,2):
  if(r,s)not in compatible:continue
  if any(not any(w<=compatible for w in witness[r,s,b])for b in(0,1)):rejected.append((r,s))
 if not rejected:break
 compatible.difference_update(rejected);layers.append(rejected);print('ROUND',len(layers),'new',len(rejected),'remain',len(compatible),flush=True)
conflicts=[(r,s)for r,s in combinations(R,2)if(r,s)not in compatible]
# Baseline role cohabitation must remain possible.
assert all(pair(r,s)in compatible for r,s in combinations(R,2)if R[r]['old_q']==R[s]['old_q'])
out={'status':'FINITE_MACRO_VOCABULARY_CONFLICTS','roles_sha256':hashlib.sha256(RP.read_bytes()).hexdigest(),'macros_sha256':hashlib.sha256(MP.read_bytes()).hexdigest(),'roles':n,'conflicts':conflicts,'layers':layers,'compatible_pairs':len(compatible)-n,'always_feasible_branches':always,'seconds':time.monotonic()-beg,'scope':'Intrinsic pairwise role conflict under the supplied direct-edge/internal-macro/phase-safe-leaf action vocabulary. No physical host-domain assumptions, no permanent-row assumptions. Every exclusion follows from a previous layer. Safe for conditional helper constraints using this same vocabulary or a subset.'}
adj={i:set()for i in R}
for a,b in conflicts:adj[a].add(b);adj[b].add(a)
uncovered=set(conflicts);cliques=[]
while uncovered:
 deg={i:0 for i in R}
 for a,b in uncovered:deg[a]+=1;deg[b]+=1
 a,b=max(uncovered,key=lambda ab:(deg[ab[0]]+deg[ab[1]],ab));cl=[a,b];cand=adj[a]&adj[b]
 while cand:
  v=max(cand,key=lambda v:(sum(pair(v,c)in uncovered for c in cl),len(cand&adj[v]),deg[v],v));cl.append(v);cand&=adj[v]
 cliques.append(sorted(cl));uncovered.difference_update(pair(a,b)for a,b in combinations(cl,2))
out['cliques']=cliques
args.out.write_text(json.dumps(out,indent=2)+'\n');print('CONFLICTS',len(conflicts),'compatible',len(compatible)-n,'seconds',out['seconds'],flush=True)
