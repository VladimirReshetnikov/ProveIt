from pathlib import Path
import argparse,json,collections,sys,time
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import lil_matrix
HERE=Path(__file__).parent;ROOT=HERE.parent/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215'
sys.path.insert(0,str(ROOT/'code'));import build221 as b,source_language as sl

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--roles',type=Path,default=HERE.parent/'physical/roles.json');ap.add_argument('--out',type=Path,required=True);ap.add_argument('--startup',action='store_true');ap.add_argument('--seconds',type=int,default=180);a=ap.parse_args();a.out.mkdir(exist_ok=False,parents=True)
 data=json.loads(a.roles.read_text());R={r['id']:r for r in data['roles']};T=b.read_table((ROOT/'k215.native.tm').read_bytes());Q=sorted({q for q,bb in T});P=set(map(tuple,data['protected']));E=set(map(tuple,json.loads((HERE/'engine.json').read_text())['rows']))
 if a.startup:P.update(map(tuple,json.loads((HERE/'startup_rows.json').read_text())['rows']))
 # Roles catalog must include every pinned action to keep its dependency proof valid.
 hosts={(h['role'],h['bit'],h['q']):h for h in data['hosts']}
 root=next(r for r in R if ''in R[r]['occurrences']);D={r:set(Q)for r in R};D[root]={84};req={};desc={};reasons=collections.Counter()
 for r,rr in R.items():
  for q in list(D[r]):
   need=[];signature=[];valid=True
   for bit,ch in enumerate(rr['children']):
    if(q,bit)in P:
     act=T[q,bit]
     if ch['kind']=='leaf':
      allowed={tuple(v)for v in ch['allowed_actions']}
      if act not in allowed:valid=False;reasons['leaf']+=1;break
     else:
      h=hosts.get((r,bit,q));children={z['prefix']:z['role']for z in ch['targets']}
      if h is None and act[:2]==(bit,1):ends={p:act[2]for p in rr['occurrences']}
      elif h is None:valid=False;reasons['edge']+=1;break
      else:
       if not set(map(tuple,h['dependencies']))<=P:valid=False;reasons['dependencies']+=1;break
       ends={z['prefix']:z['target']for z in h['endpoints']}
      for p,z in ends.items():need.append((children[p],z))
    else:
     if ch['kind']=='leaf':signature.append(('leaf',T[rr['old_q'],bit]))
     else:
      children={z['role']for z in ch['targets']}
      if len(children)!=1:valid=False;reasons['contextual_unprotected']+=1;break
      signature.append(('child',next(iter(children))))
   if valid:req[r,q]=set(need);desc[r,q]=tuple(signature)
   else:D[r].remove(q)
 changed=True
 while changed:
  changed=False
  for r in R:
   for q in list(D[r]):
    if any(z not in D[c]for c,z in req[r,q]):D[r].remove(q);changed=True
 receipt={'status':'PENDING','roles':len(R),'protected':sorted(P),'domain_sizes':{r:len(D[r])for r in R},'rejection_counts':dict(reasons),'startup_preserved':a.startup}
 def finish():
  (a.out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k not in ['protected','domain_sizes','assignments','changed_rows']},indent=2),flush=True)
 if any(not D[r]for r in R):receipt['status']='EMPTY_DOMAIN';receipt['empty_roles']=[r for r in R if not D[r]];finish();return
 choices=[(r,q)for r in R for q in sorted(D[r])];ix={v:i for i,v in enumerate(choices)};iy={q:len(choices)+i for i,q in enumerate(Q)};nvars=len(choices)+len(Q);rows=[];lo=[];hi=[]
 def add(row,l,h):rows.append(row);lo.append(l);hi.append(h)
 for r in R:add({ix[r,q]:1 for q in D[r]},1,1)
 for r,q in choices:
  add({ix[r,q]:1,iy[q]:-1},-np.inf,0)
  for c,z in req[r,q]:add({ix[r,q]:1,ix[c,z]:-1},-np.inf,0)
  for bit,ch in enumerate(R[r]['children']):
   if(q,bit)not in P and ch['kind']=='leaf':
    z=T[R[r]['old_q'],bit][2]
    if z!=254:add({ix[r,q]:1,iy[z]:-1},-np.inf,0)
 # If a label is retained, every frozen outgoing target is retained as well.
 for(q,bit)in P:
  z=T[q,bit][2]
  if z!=254 and z!=q:add({iy[q]:1,iy[z]:-1},-np.inf,0)
 forced={0}|{q for q,bit in E}
 for q in forced:add({iy[q]:1},1,1)
 groupcount=0
 for q in Q:
  groups=collections.defaultdict(list)
  for r in R:
   if q in D[r]:groups[desc[r,q]].append(ix[r,q])
  if len(groups)<=1:continue
  yy=[];groupcount+=1
  for ids in groups.values():
   j=nvars;nvars+=1;yy.append(j)
   for i in ids:add({i:1,j:-1},-np.inf,0)
  add({j:1 for j in yy},0,1)
 A=lil_matrix((len(rows),nvars))
 for i,row in enumerate(rows):
  for j,v in row.items():A[i,j]=v
 cost=np.zeros(nvars)
 for q,j in iy.items():cost[j]=100000
 for(r,q),j in ix.items():cost[j]=int(q!=R[r]['old_q'])+q/1e6
 begin=time.monotonic();ans=milp(cost,integrality=np.ones(nvars),bounds=Bounds(0,1),constraints=LinearConstraint(A.tocsc(),lo,hi),options={'time_limit':a.seconds})
 receipt.update(solver=ans.message,variables=nvars,constraints=len(rows),group_hosts=groupcount,seconds=time.monotonic()-begin)
 if ans.x is None:receipt['status']='NO_ALLOCATION';finish();return
 M={r:q for(r,q),j in ix.items()if ans.x[j]>.5};keep={q for q,j in iy.items()if ans.x[j]>.5};N={};written={}
 for q in keep:
  for bit in(0,1):N[q,bit]=T[q,bit]if(q,bit)in P else(bit,1,q)
 for r,q in M.items():
  for bit,ch in enumerate(R[r]['children']):
   if(q,bit)in P:continue
   if ch['kind']=='leaf':act=T[R[r]['old_q'],bit]
   else:act=(bit,1,M[ch['targets'][0]['role']])
   assert(q,bit)not in written or written[q,bit]==act,('conflicting rows',q,bit)
   N[q,bit]=act;written[q,bit]=act
 assert all(z in keep|{254}for w,d,z in N.values())
 tree=sl.tree(json.loads((ROOT/'sites215.json').read_text()));fail=[]
 try:
  ng,npth=b.decoder_map(N,tree)
  actual={p:q for q,pcs in npth.items()for p in pcs}
  for r,rr in R.items():
   for p in rr['occurrences']:
    if actual[p]!=M[r]:fail.append([p,actual[p],M[r]])
 except Exception as e:fail.append(repr(e))
 receipt.update(status='PREFIX_PASS'if not fail else'PREFIX_FAIL',states=len(keep),failures=fail,removed=sorted(set(Q)-keep),changed_rows=[list(k)+list(v)for k,v in sorted(N.items())if T.get(k)!=v],assignments=[{'role':r,'old':R[r]['old_q'],'q':q,'path':R[r]['representative']}for r,q in M.items()])
 (a.out/'candidate.native.tm').write_bytes(b.table_bytes(N));finish()
if __name__=='__main__':main()
