from pathlib import Path
import sys,json,time,collections,hashlib
ROOT=Path('/dev/shm/zfc214-9d0ff4abecf6/repo/Computability/BusyBeaver/Research/ZFC/candidate-k215')
sys.path[:0]=[str(ROOT/'code'),str(ROOT/'code/runtime-inputs/runtime')]
import build221 as b
import symbolic_runtime as s
T=b.read_table((ROOT/'k215.native.tm').read_bytes()); sites=json.loads((ROOT/'sites215.json').read_text())
m={int(k):int(v)for k,v in json.loads((ROOT/'code/runtime-inputs/inputs/legacy_mapping.json').read_text()).items()}
for q in {q for q,_ in T}|{254}:
 if q not in m:m[q]=q+1000
inv={v:k for k,v in m.items()}
L={(m[q],a):(w,d,m[z])for(q,a),(w,d,z)in T.items()}
lemmas,blocks=s.prove_blocks(L)
engine=set(); proofs=[]; starting=time.monotonic()
for bl in blocks:
 for e in bl['trace']:
  if e[0]!='list':engine.add((inv[e[1][0]],e[1][1]))
for i,(pc,op,arg) in enumerate(sites):
 # Exact initial decoding prefix, not the final leaf action.
 tape={-1:1,**{j:int(x)for j,x in enumerate(pc)}};q=84;h=0;pre=[]
 for k in range(1000):
  if h==len(pc)-1:break
  assert h in tape
  r=(q,tape[h]);w,d,z=T[r];pre.append((m[q],r[1],w,d,m[z]));tape[h]=w;h+=d;q=z
 else:raise Exception('decoder')
 assert tape=={-1:1,**{j:int(x)for j,x in enumerate(pc)}}
 for pos in ((False,True)if op=='CD'else(False,)):
  ans=s.case(L,lemmas,(pc,op,arg),pos,keep_trace=True)
  tr=ans['trace']
  assert all(tr[j][0]=='literal'and tuple(tr[j][1])==r for j,r in enumerate(pre)),(i,'trace prefix mismatch')
  assert tr[len(pre)][0]=='literal' and tr[len(pre)][1][:2]==(m[q],int(pc[-1]))
  er=set();j=0;decodes=0
  while j<len(tr):
   e=tr[j]
   if e[0]!='list' and e[1][0]==m[84]:
    assert all(tr[j+k][0]=='literal' and tuple(tr[j+k][1])==r for k,r in enumerate(pre)),(i,pos,j,'redecode differs')
    assert tr[j+len(pre)][0]=='literal' and tr[j+len(pre)][1][:2]==(m[q],int(pc[-1]))
    j+=len(pre)+1;decodes+=1
   else:
    if e[0]!='list':er.add((inv[e[1][0]],e[1][1]))
    j+=1
  engine|=er
  proofs.append([i,pos,len(pre),len(tr),sorted(er)])
 if i%500==0:print(i,len(engine),round(time.monotonic()-starting,1),flush=True)
result={'rows':sorted(engine),'cases':len(proofs),'seconds':time.monotonic()-starting,'table_sha256':hashlib.sha256((ROOT/'k215.native.tm').read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((ROOT/'sites215.json').read_bytes()).hexdigest(),'scope':'Every actual exact-table symbolic primitive proof, with every repeated decoder prefix plus its first leaf action removed after literal trace equality verification; all block schemas added.'}
Path(__file__).with_name('engine.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
