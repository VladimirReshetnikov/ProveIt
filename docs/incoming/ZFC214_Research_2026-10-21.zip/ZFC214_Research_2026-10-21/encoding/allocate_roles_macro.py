"""All-role physical synthesis with factored free-row macro modes.
This emits synthesis witnesses only; full arithmetic runtime and blank checks remain mandatory.
"""
from pathlib import Path
import argparse,json,collections,sys,time,hashlib,array
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
BASE=Path('/dev/shm/zfc214-9d0ff4abecf6');HERE=BASE/'global';ROOT=BASE/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215'
sys.path.insert(0,str(ROOT/'code'));import build221 as b,source_language as sl

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--roles',type=Path,default=BASE/'physical/roles.json');ap.add_argument('--macros',type=Path,default=BASE/'physical/internal-action-macros.json');ap.add_argument('--table',type=Path,default=ROOT/'k215.native.tm');ap.add_argument('--engine',type=Path,default=HERE/'engine.json');ap.add_argument('--startup-rows',type=Path,default=HERE/'startup_rows.json');ap.add_argument('--distance',type=int);ap.add_argument('--warmstart',action='store_true');ap.add_argument('--symmetry',action='store_true');ap.add_argument('--out',type=Path,required=True);ap.add_argument('--startup',action='store_true');ap.add_argument('--seconds',type=int,default=180);ap.add_argument('--bound',type=int,default=215);a=ap.parse_args();assert not(a.distance is not None and a.symmetry),'Distance is measured in original labels; disable symmetry';a.out.mkdir(exist_ok=False,parents=True)
 data=json.loads(a.roles.read_text());catalog=json.loads(a.macros.read_text());assert catalog['table_sha256']==digest(a.table)
 R={r['id']:r for r in data['roles']};T=b.read_table(a.table.read_bytes());Q=sorted({q for q,bb in T});P=set(map(tuple,data['protected']));E=set(map(tuple,json.loads(a.engine.read_text())['rows']))
 if a.startup:P.update(map(tuple,json.loads(a.startup_rows.read_text())['rows']))
 assert set(map(tuple,catalog['protected']))<=P
 hosts={(h['role'],h['bit'],h['q']):h for h in data['hosts']};root=next(r for r in R if ''in R[r]['occurrences']);D={r:set(Q)for r in R};D[root]={84};req={};children={};macros=collections.defaultdict(list);reasons=collections.Counter()
 for r,rr in R.items():
  for bit,ch in enumerate(rr['children']):
   if ch['kind']=='internal':children[r,bit]={z['prefix']:z['role']for z in ch['targets']}
 for group in catalog['rows']:
  key=(group['role'],group['bit']);cm=children[key]
  for v in group['alternatives']:
   assert set(map(tuple,v['dependencies']))<=P
   need={(cm[z['prefix']],z['target'])for z in v['endpoints']}
   if len({c for c,z in need})!=len(need):reasons['inconsistent_macro_endpoint']+=1;continue
   macros[key].append((tuple(v['action']),need))
 for r,rr in R.items():
  for q in list(D[r]):
   need=[];valid=True
   for bit,ch in enumerate(rr['children']):
    if(q,bit)not in P:continue
    act=T[q,bit]
    if ch['kind']=='leaf':
     if act not in set(map(tuple,ch['allowed_actions'])):valid=False;reasons['leaf']+=1;break
    else:
     h=hosts.get((r,bit,q));child_at=children[r,bit]
     if h is None and act[:2]==(bit,1):ends={p:act[2]for p in rr['occurrences']}
     elif h is None:valid=False;reasons['edge']+=1;break
     else:
      if not set(map(tuple,h['dependencies']))<=P:valid=False;reasons['dependencies']+=1;break
      ends={z['prefix']:z['target']for z in h['endpoints']}
     assert set(ends)==set(rr['occurrences'])
     for p,z in ends.items():need.append((child_at[p],z))
   if valid:req[r,q]=set(need)
   else:D[r].remove(q)
 def validmacro(v):return all(z in D[c]for c,z in v[1])
 def direct(key):return bool(set.intersection(*(D[c]for c in set(children[key].values()))))
 changed=True
 while changed:
  changed=False
  for r,rr in R.items():
   for q in list(D[r]):
    bad=any(z not in D[c]for c,z in req[r,q])
    if not bad:
     for bit,ch in enumerate(rr['children']):
      if(q,bit)not in P and ch['kind']=='internal' and not direct((r,bit))and not any(validmacro(v)for v in macros[r,bit]):bad=True;break
    if bad:D[r].remove(q);changed=True
 receipt={'status':'PENDING','scope':'Synthesis and source-prefix binding only; full runtime and startup are separate gates.','roles_sha256':digest(a.roles),'macros_sha256':digest(a.macros),'table_sha256':digest(a.table),'engine_sha256':digest(a.engine),'source_sha256':digest(ROOT/'sites215.json'),'roles':len(R),'protected':sorted(P),'domain_sizes':{r:len(D[r])for r in R},'rejection_counts':dict(reasons),'startup_preserved':a.startup,'state_bound':a.bound,'distance':a.distance}
 def finish():
  (a.out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k not in ['protected','domain_sizes','assignments','changed_rows','chosen_modes','symmetric_free_states']},indent=2),flush=True)
 if any(not D[r]for r in R):receipt['status']='EMPTY_DOMAIN';receipt['empty_roles']=[r for r in R if not D[r]];finish();return
 blocked={0,84}|{q for q,bit in P}|{T[q,bit][2]for q,bit in P}|{act[2]for rr in R.values()for ch in rr['children']if ch['kind']=='leaf'for act in ch['allowed_actions']}|{act[2]for vs in macros.values()for act,need in vs}
 F=sorted(set(Q)-blocked)if a.symmetry else[]
 assert all(all((q in D[r])==(F[0]in D[r])for q in F)for r in R)
 receipt['symmetric_free_states']=F
 choices=[(r,q)for r in R for q in sorted(D[r])];ix={v:i for i,v in enumerate(choices)};lower=[0.0]*len(choices);upper=[1.0]*len(choices);integral=[1]*len(choices);cost=[int(q!=R[r]['old_q'])+q/1e6 for r,q in choices]
 def variable(lb=0,ub=1,integer=0,obj=0):
  j=len(lower);lower.append(lb);upper.append(ub);integral.append(integer);cost.append(obj);return j
 iy={q:variable(integer=1,obj=100000)for q in Q};ir={r:variable(min(D[r]),max(D[r]))for r in R}
 free={(q,bit)for r,q in choices for bit in(0,1)if(q,bit)not in P};rowvars={k:(variable(),variable(),variable(0,302))for k in sorted(free)}
 branchvars={};options={};iv={}
 for r,rr in R.items():
  for bit,ch in enumerate(rr['children']):
   if not any((q,bit)not in P for q in D[r]):continue
   key=r,bit;branchvars[key]=(variable(),variable(),variable(0,302))
   if ch['kind']=='leaf':opts=[(act,set())for act in sorted(set(map(tuple,ch['allowed_actions'])))]
   else:opts=([(None,set())]if direct(key)else[])+[v for v in macros[key]if validmacro(v)]
   options[key]=opts
   for i,v in enumerate(opts):iv[key,i]=variable(integer=1)
 ai=array.array('i');aj=array.array('i');av=array.array('d');lo=[];hi=[]
 def add(row,l,h):
  i=len(lo);lo.append(l);hi.append(h)
  for j,v in row.items():
   if v:ai.append(i);aj.append(j);av.append(v)
 def force_when(x,j,value,big):
  add({j:1,x:-big},value-big,np.inf);add({j:1,x:big},-np.inf,value+big)
 def equal_when(x,j,k,big=302):
  add({j:1,k:-1,x:-big},-big,np.inf);add({j:1,k:-1,x:big},-np.inf,big)
 for r in R:
  add({ix[r,q]:1 for q in D[r]},1,1);add({ir[r]:-1,**{ix[r,q]:q for q in D[r]}},0,0)
 for r,q in choices:
  x=ix[r,q];add({x:1,iy[q]:-1},-np.inf,0)
  for c,z in req[r,q]:add({x:1,ix[c,z]:-1},-np.inf,0)
  for bit in(0,1):
   if(q,bit)in P:continue
   for j,k,big in zip(rowvars[q,bit],branchvars[r,bit],(1,1,302)):equal_when(x,j,k,big)
 for key,opts in options.items():
  r,bit=key;w,d,t=branchvars[key]
  add({**{iv[key,i]:1 for i in range(len(opts))},**{ix[r,q]:-1 for q in D[r]if(q,bit)not in P}},0,0)
  for i,(act,need)in enumerate(opts):
   u=iv[key,i]
   if act is None:
    force_when(u,w,bit,1);force_when(u,d,1,1)
    for c in set(children[key].values()):equal_when(u,t,ir[c])
   else:
    ww,dd,zz=act;force_when(u,w,ww,1);force_when(u,d,int(dd==1),1);force_when(u,t,zz,302)
    if zz!=254:add({u:1,iy[zz]:-1},-np.inf,0)
    for c,z in need:add({u:1,ix[c,z]:-1},-np.inf,0)
 for(q,bit)in P:
  z=T[q,bit][2]
  if z!=254 and z!=q:add({iy[q]:1,iy[z]:-1},-np.inf,0)
 for q in {0}|{q for q,bit in E}:add({iy[q]:1},1,1)
 if F:
  ordered=sorted(R)
  for left,right in zip(F,F[1:]):
   add({iy[right]:1,iy[left]:-1},-np.inf,0)
   for i,r in enumerate(ordered):
    if(r,right)in ix:add({ix[r,right]:1,**{ix[rr,left]:-1 for rr in ordered[:i]if(rr,left)in ix}},-np.inf,0)
 if a.distance is not None:add({ix[r,R[r]['old_q']]:1 for r in R if(r,R[r]['old_q'])in ix},len(R)-a.distance,len(R))
 add({j:1 for j in iy.values()},0,a.bound)
 A=coo_matrix((np.frombuffer(av,dtype='d'),(np.frombuffer(ai,dtype='i'),np.frombuffer(aj,dtype='i'))),shape=(len(lo),len(lower))).tocsc()
 print('SOLVING',len(lower),len(lo),'choices',len(choices),'modes',len(iv),'nnz',A.nnz,flush=True)
 begin=time.monotonic()
 if a.warmstart:
  sys.path.insert(0,str(HERE));import milp_hint
  oldM={r:rr['old_q']for r,rr in R.items()};used=sorted(set(oldM.values())&set(F),key=lambda q:min(r for r in R if oldM[r]==q));rename=dict(zip(used,F));M0={r:rename.get(q,q)for r,q in oldM.items()};hint=np.zeros(len(lower));keep0={0}|set(M0.values())|{q for q,bit in E};acts0={}
  for r,q in M0.items():
   assert q in D[r],('baseline host excluded',r,q)
   hint[ix[r,q]]=1;hint[ir[r]]=q
   for bit,ch in enumerate(R[r]['children']):
    if(q,bit)in P:continue
    key=r,bit
    if ch['kind']=='leaf':
     act=T[R[r]['old_q'],bit];i=next(i for i,(aa,need)in enumerate(options[key])if aa==act)
    else:
     oldact=T[R[r]['old_q'],bit];zz={M0[c]for c in children[key].values()}
     if oldact[:2]==(bit,1)and len(zz)==1:
      act=(bit,1,next(iter(zz)));i=next(i for i,(aa,need)in enumerate(options[key])if aa is None)
     else:
      act=oldact;i=next(i for i,(aa,need)in enumerate(options[key])if aa==act and all(M0[c]==z for c,z in need))
    hint[iv[key,i]]=1
    w,d,t=branchvars[key];hint[w]=act[0];hint[d]=int(act[1]==1);hint[t]=act[2]
    assert(q,bit)not in acts0 or acts0[q,bit]==act
    acts0[q,bit]=act
    if act[2]!=254:keep0.add(act[2])
  changed=True
  while changed:
   before=set(keep0)
   for q,bit in P:
    if q in keep0 and T[q,bit][2]!=254:keep0.add(T[q,bit][2])
   changed=before!=keep0
  for q in keep0:hint[iy[q]]=1
  for key,act in acts0.items():
   w,d,t=rowvars[key];hint[w]=act[0];hint[d]=int(act[1]==1);hint[t]=act[2]
  assert np.all(hint>=np.array(lower)-1e-8)and np.all(hint<=np.array(upper)+1e-8)
  receipt['hint_states']=len(keep0);print('HINT',len(keep0),'symmetric',len(F),flush=True)
  ans=milp_hint.solve(np.array(cost),A,lo,hi,hint,a.seconds,lower=np.array(lower),upper=np.array(upper),integrality=np.array(integral));ans.fun=ans.objective
 else:ans=milp(np.array(cost),integrality=np.array(integral),bounds=Bounds(lower,upper),constraints=LinearConstraint(A,lo,hi),options={'time_limit':a.seconds})
 receipt.update(solver=ans.message,variables=len(lower),constraints=len(lo),modes=len(iv),seconds=time.monotonic()-begin,objective=ans.fun,bound=getattr(ans,'mip_dual_bound',None))
 if ans.x is None:receipt['status']='NO_ALLOCATION';finish();return
 M={r:q for(r,q),j in ix.items()if ans.x[j]>.5};keep={q for q,j in iy.items()if ans.x[j]>.5};N={};written={};chosen={}
 for(key,i),j in iv.items():
  if ans.x[j]>.5:assert key not in chosen;chosen[key]=i
 for q in keep:
  for bit in(0,1):N[q,bit]=T[q,bit]if(q,bit)in P else(bit,1,q)
 for r,q in M.items():
  for bit,ch in enumerate(R[r]['children']):
   if(q,bit)in P:continue
   key=r,bit;act,need=options[key][chosen[key]]
   if act is None:
    zz={M[c]for c in children[key].values()};assert len(zz)==1;act=(bit,1,next(iter(zz)))
   else:assert all(M[c]==z for c,z in need)
   assert(q,bit)not in written or written[q,bit]==act,('conflicting rows',q,bit)
   N[q,bit]=act;written[q,bit]=act
 assert all(z in keep|{254}for w,d,z in N.values());assert all(N[k]==T[k]for k in P if k[0]in keep)
 tree=sl.tree(json.loads((ROOT/'sites215.json').read_text()));fail=[]
 try:
  ng,npth=b.decoder_map(N,tree);actual={p:q for q,pcs in npth.items()for p in pcs}
  for r,rr in R.items():
   for p in rr['occurrences']:
    if actual[p]!=M[r]:fail.append([p,actual[p],M[r]])
 except Exception as e:fail.append(repr(e))
 receipt.update(status='PREFIX_PASS'if not fail else'PREFIX_FAIL',states=len(keep),failures=fail,removed=sorted(set(Q)-keep),changed_rows=[list(k)+list(v)for k,v in sorted(N.items())if T.get(k)!=v],assignments=[{'role':r,'old':R[r]['old_q'],'q':q,'path':R[r]['representative']}for r,q in M.items()],chosen_modes=[dict(role=key[0],bit=key[1],action=options[key][i][0],requirements=sorted(options[key][i][1]))for key,i in chosen.items()])
 (a.out/'candidate.native.tm').write_bytes(b.table_bytes(N));finish()
if __name__=='__main__':main()
