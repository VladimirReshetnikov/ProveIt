"""Source-only x=1 specialization. Completeness/equiconsistency remains unproved."""
from pathlib import Path
import sys,json,hashlib
BASE=Path('/dev/shm/zfc214-9d0ff4abecf6')
K=BASE/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215'
sys.path.insert(0,str(K/'research/composition-allocation'))
import source_splice as sp
source=K/'sites215.json';old=sp.parse(json.loads(source.read_text()))
assert [v[1:] for v in sp.sites(old)[211:214]]==[('CD',6),('CI',4),('CC',2)]
sp.closed_forest(old,200,214)
new=sp.apply_closed_splices(old,{(200,214):('CI',4)})
out=BASE/'encoding/successor-rho-source.json';raw=sp.compact(sp.sites(new));out.write_bytes(raw)
receipt=dict(status='SOURCE_ONLY_NO_COMPLETENESS_OR_EQUICONSISTENCY_PROOF',baseline_sha256=sp.sha(source.read_bytes()),source_sha256=sp.sha(raw),edit=dict(old_interval=[200,214],new_primitive=['CI',4],meaning='Replace complete A-field reader/addition by D := D+1; no x wire field consumed'),parameters='U=oldD; A=U+1; B=oldH+y; C=c; fields [c+3,y]',metrics=sp.metrics(new),semantic_scope='This specializes an accepted sound axiom schema. Completeness has not been established. It is not an accepted ZFC candidate.')
(BASE/'encoding/successor-rho-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
