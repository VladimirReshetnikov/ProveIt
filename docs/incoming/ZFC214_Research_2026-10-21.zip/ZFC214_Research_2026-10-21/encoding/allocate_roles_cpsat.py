"""All-role physical synthesis with conditional helper row preservation.
This emits synthesis witnesses only; full arithmetic runtime and blank checks remain mandatory.
"""
from pathlib import Path
import argparse,json,collections,sys,time,hashlib,array
sys.path.insert(0,'/dev/shm/zfc214-9d0ff4abecf6/deps')
import ortools
from ortools.sat.python import cp_model
BASE=Path('/dev/shm/zfc214-9d0ff4abecf6');HERE=BASE/'global';ROOT=BASE/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215'
sys.path.insert(0,str(ROOT/'code'));import build221 as b,source_language as sl

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--conflicts',type=Path);ap.add_argument('--conflict-roles',type=Path);ap.add_argument('--conflict-macros',type=Path);ap.add_argument('--roles',type=Path,default=BASE/'physical/roles-conditional185.json');ap.add_argument('--macros',type=Path,default=BASE/'physical/internal-action-macros-conditional185.json');ap.add_argument('--table',type=Path,default=ROOT/'k215.native.tm');ap.add_argument('--engine',type=Path,default=HERE/'engine.json');ap.add_argument('--startup-rows',type=Path,default=HERE/'startup_rows.json');ap.add_argument('--workers',type=int,default=4);ap.add_argument('--seed',type=int,default=23174);ap.add_argument('--control',action='store_true');ap.add_argument('--distance',type=int);ap.add_argument('--warmstart',action='store_true');ap.add_argument('--symmetry',action='store_true');ap.add_argument('--out',type=Path,required=True);ap.add_argument('--startup',action='store_true');ap.add_argument('--seconds',type=int,default=180);ap.add_argument('--bound',type=int,default=215);a=ap.parse_args();assert not(a.distance is not None and a.symmetry),'Distance is measured in original labels; disable symmetry';a.out.mkdir(exist_ok=False,parents=True)
 data=json.loads(a.roles.read_text());catalog=json.loads(a.macros.read_text());assert catalog['table_sha256']==digest(a.table)
 R={r['id']:r for r in data['roles']};T=b.read_table(a.table.read_bytes());Q=sorted({q for q,bb in T});P=set(map(tuple,data['protected']));E=set(map(tuple,json.loads(a.engine.read_text())['rows']))
 if a.startup:P.update(map(tuple,json.loads(a.startup_rows.read_text())['rows']))
 assert set(map(tuple,catalog['protected']))<=P
 hosts={(h['role'],h['bit'],h['q']):h for h in data['hosts']};root=next(r for r in R if ''in R[r]['occurrences']);D={r:set(Q)for r in R};D[root]={84};req={};children={};macros=collections.defaultdict(list);reasons=collections.Counter();actiondeps={};hostdeps={}
 for r,rr in R.items():
  for bit,ch in enumerate(rr['children']):
   if ch['kind']=='internal':children[r,bit]={z['prefix']:z['role']for z in ch['targets']}
   else:
    for v in ch['action_dependencies']:actiondeps[r,bit,tuple(v['action'])]=set(map(tuple,v['dependencies']))
 for group in catalog['rows']:
  key=(group['role'],group['bit']);cm=children[key]
  for v in group['alternatives']:
   assert set(map(tuple,v['dependencies']))<=set(T)
   actiondeps[key[0],key[1],tuple(v['action'])]=set(map(tuple,v['dependencies']))
   need={(cm[z['prefix']],z['target'])for z in v['endpoints']}
   if len({c for c,z in need})!=len(need):reasons['inconsistent_macro_endpoint']+=1;continue
   macros[key].append((tuple(v['action']),need))
 for r,rr in R.items():
  for q in list(D[r]):
   need=[];deps=set();valid=True
   for bit,ch in enumerate(rr['children']):
    if(q,bit)not in P:continue
    act=T[q,bit]
    if ch['kind']=='leaf':
     if act not in set(map(tuple,ch['allowed_actions'])):valid=False;reasons['leaf']+=1;break
     deps.update(actiondeps[r,bit,act])
    else:
     h=hosts.get((r,bit,q));child_at=children[r,bit]
     if h is None and act[:2]==(bit,1):ends={p:act[2]for p in rr['occurrences']}
     elif h is None:valid=False;reasons['edge']+=1;break
     else:
      deps.update(map(tuple,h['dependencies']))
      ends={z['prefix']:z['target']for z in h['endpoints']}
     assert set(ends)==set(rr['occurrences'])
     for p,z in ends.items():need.append((child_at[p],z))
   if valid:req[r,q]=set(need);hostdeps[r,q]=deps
   else:D[r].remove(q)
 def validmacro(v):return all(z in D[c]for c,z in v[1])
 def direct(key):return bool(set.intersection(*(D[c]for c in set(children[key].values()))))
 changed=True
 while changed:
  changed=False
  for r,rr in R.items():
   for q in list(D[r]):
    bad=any(z not in D[c]for c,z in req[r,q])
    if not bad:
     for bit,ch in enumerate(rr['children']):
      if(q,bit)not in P and ch['kind']=='internal' and not direct((r,bit))and not any(validmacro(v)for v in macros[r,bit]):bad=True;break
    if bad:D[r].remove(q);changed=True
 # Close a proposed host under engine/mandatory helper actions, before MILP.
 macroat={key:{act:(need,actiondeps[key[0],key[1],act])for act,need in vs}for key,vs in macros.items()}
 leafat={(r,bit):set(map(tuple,ch['allowed_actions']))for r,rr in R.items()for bit,ch in enumerate(rr['children'])if ch['kind']=='leaf'}
 def forced_closure(seed_r,seed_q):
  assigned={};at=collections.defaultdict(set);fixed=set(P);todo=[];done=set();moves=0
  def bind(r,q):
   nonlocal moves
   if r in assigned:return assigned[r]==q
   if q not in D[r]:return False
   assigned[r]=q;at[q].add(r);todo.extend([(r,0),(r,1)]);moves+=int(q!=R[r]['old_q'])
   return a.distance is None or moves<=a.distance
  if not bind(seed_r,seed_q):return None
  while todo:
   r,bit=todo.pop();q=assigned[r];key=r,bit
   if key in done or(q,bit)not in fixed:continue
   done.add(key);act=T[q,bit];ch=R[r]['children'][bit]
   if ch['kind']=='leaf':
    if act not in leafat[key]:return None
    need=();deps=actiondeps[r,bit,act]
   elif act[:2]==(bit,1):need={(c,act[2])for c in children[key].values()};deps=()
   else:
    v=macroat.get(key,{}).get(act)
    if v is None:return None
    need,deps=v
   for c,z in need:
    if not bind(c,z):return None
   for k in deps:
    if k not in fixed:
     fixed.add(k);todo.extend((c,k[1])for c in at[k[0]])
  return assigned,fixed-P
 rounds=0;total_removed=0;closed_hosts={}
 while True:
  removed=0;closed_hosts={}
  for r in R:
   for q in list(D[r]):
    result=forced_closure(r,q)
    if result is None:D[r].remove(q);removed+=1
    else:closed_hosts[r,q]=result
  rounds+=1;total_removed+=removed
  print('DOMAIN_CLOSURE',rounds,'removed',removed,'remain',sum(map(len,D.values())),flush=True)
  if not removed:break
 for(r,q),(assigned,extra)in closed_hosts.items():
  req[r,q]={(c,z)for c,z in assigned.items()if(c,z)!=(r,q)};hostdeps[r,q].update(extra)
 receipt={'status':'PENDING','scope':'Synthesis and source-prefix binding only; full runtime and startup are separate gates.','roles_sha256':digest(a.roles),'macros_sha256':digest(a.macros),'table_sha256':digest(a.table),'engine_sha256':digest(a.engine),'source_sha256':digest(ROOT/'sites215.json'),'roles':len(R),'protected':sorted(P),'domain_sizes':{r:len(D[r])for r in R},'rejection_counts':dict(reasons),'startup_preserved':a.startup,'state_bound':a.bound,'distance':a.distance,'conditional_helpers':True}
 def finish():
  (a.out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k not in ['protected','domain_sizes','assignments','changed_rows','chosen_modes','symmetric_free_states']},indent=2),flush=True)
 if any(not D[r]for r in R):receipt['status']='EMPTY_DOMAIN';receipt['empty_roles']=[r for r in R if not D[r]];finish();return
 blocked={0,84}|{q for q,bit in P}|{T[q,bit][2]for q,bit in P}|{act[2]for rr in R.values()for ch in rr['children']if ch['kind']=='leaf'for act in ch['allowed_actions']}|{act[2]for vs in macros.values()for act,need in vs}
 blocked|={q for q,bit in data['helper_proof_rows']}|{T[q,bit][2]for q,bit in data['helper_proof_rows']}
 F=sorted(set(Q)-blocked)if a.symmetry else[]
 assert all(all((q in D[r])==(F[0]in D[r])for q in F)for r in R)
 receipt['symmetric_free_states']=F
 model=cp_model.CpModel();forcedQ={0}|{q for q,bit in E};choices=[(r,q)for r in R for q in sorted(D[r])]
 ix={(r,q):model.NewBoolVar('x_%d_%d'%(r,q))for r,q in choices};iy={q:model.NewBoolVar('keep_%d'%q)for q in Q};ir={r:model.NewIntVarFromDomain(cp_model.Domain.FromValues(sorted(D[r])),'host_%d'%r)for r in R}
 def code(act):w,d,z=act;return 4*z+2*w+int(d==1)
 rowvars={k:model.NewIntVar(0,1211,'row_%d_%d'%k)for k in T if k not in P}
 options={};iv={};branchvars={};active={}
 for r,rr in R.items():
  for bit,ch in enumerate(rr['children']):
   if not any((q,bit)not in P for q in D[r]):continue
   key=r,bit
   if ch['kind']=='leaf':opts=[(act,set())for act in sorted(set(map(tuple,ch['allowed_actions'])))]
   else:opts=([(None,set())]if direct(key)else[])+[v for v in macros[key]if validmacro(v)]
   options[key]=opts;possible={0}|{code(act)for act,need in opts if act is not None}
   if any(act is None for act,need in opts):possible.update(4*z+2*bit+1 for z in set.intersection(*(D[c]for c in set(children[key].values()))))
   branchvars[key]=model.NewIntVarFromDomain(cp_model.Domain.FromValues(sorted(possible)),'branch_%d_%d'%key);active[key]=model.NewBoolVar('active_%d_%d'%key)
   for i in range(len(opts)):iv[key,i]=model.NewBoolVar('mode_%d_%d_%d'%(r,bit,i))
 helper_universe=set().union(*actiondeps.values(),*hostdeps.values())-P;ih={k:model.NewBoolVar('helper_%d_%d'%k)for k in sorted(helper_universe)};helper_rules=[]
 def require_helpers(u,deps):
  helper_rules.append((u,tuple(sorted(deps))))
  for k in deps:
   if k in E:continue
   if k in P:
    if k[0]not in forcedQ:model.AddImplication(u,iy[k[0]])
   else:model.AddImplication(u,ih[k])
 for k,h in ih.items():
  q,bit=k;act=T[k];model.Add(rowvars[k]==code(act)).OnlyEnforceIf(h)
  if q not in forcedQ:model.AddImplication(h,iy[q])
  if act[2]!=254 and act[2]not in forcedQ:model.AddImplication(h,iy[act[2]])
 for r in R:
  model.AddExactlyOne(ix[r,q]for q in D[r])
  for q in D[r]:model.Add(ir[r]==q).OnlyEnforceIf(ix[r,q])
 for r,q in choices:
  x=ix[r,q]
  if q not in forcedQ:model.AddImplication(x,iy[q])
  for c,z in req[r,q]:model.AddImplication(x,ix[c,z])
  require_helpers(x,hostdeps[r,q])
  for bit in(0,1):
   if(q,bit)not in P:model.Add(rowvars[q,bit]==branchvars[r,bit]).OnlyEnforceIf(x)
 for key,opts in options.items():
  r,bit=key;av=active[key];v=branchvars[key]
  model.Add(sum(iv[key,i]for i in range(len(opts)))==av)
  model.Add(sum(ix[r,q]for q in D[r]if(q,bit)not in P)==av)
  model.Add(v==0).OnlyEnforceIf(av.Not())
  for i,(act,need)in enumerate(opts):
   u=iv[key,i]
   if act is None:
    for c in set(children[key].values()):model.Add(v==4*ir[c]+2*bit+1).OnlyEnforceIf(u)
   else:
    model.Add(v==code(act)).OnlyEnforceIf(u)
    if act[2]!=254 and act[2]not in forcedQ:model.AddImplication(u,iy[act[2]])
    for c,z in need:model.AddImplication(u,ix[c,z])
    require_helpers(u,actiondeps[r,bit,act])
 helper_host_cuts=0
 for(q,bit),h in ih.items():
  act=T[q,bit]
  for r in R:
   if(r,q)not in ix:continue
   key=r,bit;allowed=[]
   for i,(aa,need)in enumerate(options[key]):
    if aa==act:allowed.append(iv[key,i])
    elif aa is None and act[:2]==(bit,1)and all(act[2]in D[c]for c in children[key].values()):
     allowed.append(iv[key,i])
     for c in set(children[key].values()):model.AddImplication(iv[key,i],ix[c,act[2]]).OnlyEnforceIf([h,ix[r,q]])
   model.AddBoolOr([h.Not(),ix[r,q].Not()]+allowed);helper_host_cuts+=1
 receipt['helper_host_cuts']=helper_host_cuts
 for(q,bit)in P:
  z=T[q,bit][2]
  if z!=254 and z!=q:model.AddImplication(iy[q],iy[z])
 for q in forcedQ:model.Add(iy[q]==1)
 if a.conflicts:
  cuts=json.loads(a.conflicts.read_text());refroles=a.conflict_roles or(a.roles if digest(a.roles)==cuts['roles_sha256']else BASE/'physical/roles185-leafall.json');refmacros=a.conflict_macros or(a.macros if digest(a.macros)==cuts['macros_sha256']else BASE/'physical/internal-action-macros185.json')
  assert digest(refroles)==cuts['roles_sha256']and digest(refmacros)==cuts['macros_sha256']
  def rv(d):return sorted((r['id'],tuple((ch['kind'],tuple(sorted(tuple(v)for v in ch['allowed_actions']))if ch['kind']=='leaf'else tuple(sorted((v['prefix'],v['role'])for v in ch['targets'])))for ch in r['children']))for r in d['roles'])
  def mv(d):return sorted((g['role'],g['bit'],tuple(sorted((tuple(v['action']),tuple(sorted((z['prefix'],z['target'])for z in v['endpoints'])))for v in g['alternatives'])))for g in d['rows'])
  assert rv(data)==rv(json.loads(refroles.read_text()));assert mv(catalog)==mv(json.loads(refmacros.read_text()))
  for q in Q:
   for clique in cuts['cliques']:
    vv=[ix[r,q]for r in clique if(r,q)in ix]
    if len(vv)>1:model.Add(sum(vv)<=iy[q])
  receipt['conflicts_sha256']=digest(a.conflicts);receipt['conflict_cliques']=len(cuts['cliques'])
 if F:
  ordered=sorted(R)
  for left,right in zip(F,F[1:]):
   model.AddImplication(iy[right],iy[left])
   for i,r in enumerate(ordered):
    if(r,right)in ix:model.AddBoolOr([ix[r,right].Not()]+[ix[rr,left]for rr in ordered[:i]if(rr,left)in ix])
 moved=len(R)-sum(ix[r,R[r]['old_q']]for r in R if(r,R[r]['old_q'])in ix)
 if a.distance is not None:model.Add(moved<=a.distance)
 model.Add(sum(iy.values())<=a.bound)
 objective=model.NewIntVar(0,1000*a.bound+(a.distance if a.distance is not None else len(R)),"bounded_objective")
 model.Add(objective==1000*sum(iy.values())+moved);model.Minimize(objective)
 if a.warmstart:
  oldM={r:rr['old_q']for r,rr in R.items()};used=sorted(set(oldM.values())&set(F),key=lambda q:min(r for r in R if oldM[r]==q));rename=dict(zip(used,F));M0={r:rename.get(q,q)for r,q in oldM.items()};acts0={};picked={}
  for(r,q),x in ix.items():model.AddHint(x,int(M0[r]==q))
  for r,q in M0.items():
   model.AddHint(ir[r],q)
   for bit,ch in enumerate(R[r]['children']):
    if(q,bit)in P:continue
    key=r,bit;oldact=T[R[r]['old_q'],bit]
    if ch['kind']=='leaf':act=oldact;i=next(i for i,(aa,need)in enumerate(options[key])if aa==act)
    else:
     zz={M0[c]for c in children[key].values()}
     if oldact[:2]==(bit,1)and len(zz)==1:act=(bit,1,next(iter(zz)));i=next(i for i,(aa,need)in enumerate(options[key])if aa is None)
     else:act=oldact;i=next(i for i,(aa,need)in enumerate(options[key])if aa==act and all(M0[c]==z for c,z in need))
    picked[key]=i;assert(q,bit)not in acts0 or acts0[q,bit]==act;acts0[q,bit]=act
  for key,v in branchvars.items():
   r,bit=key;isactive=key in picked;model.AddHint(active[key],int(isactive));model.AddHint(v,code(acts0[M0[r],bit])if isactive else 0)
   for i in range(len(options[key])):model.AddHint(iv[key,i],int(isactive and i==picked[key]))
  for q,y in iy.items():model.AddHint(y,1)
  for k,h in ih.items():model.AddHint(h,1)
  for k,v in rowvars.items():model.AddHint(v,code(acts0.get(k,T[k])))
  receipt['hint_states']=len(Q)
 check=model.Validate();assert not check,check
 (a.out/'model_stats.txt').write_text(model.ModelStats()+'\n');print('MODEL',model.ModelStats(),flush=True)
 solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=a.seconds;solver.parameters.num_search_workers=a.workers;solver.parameters.random_seed=a.seed;solver.parameters.log_search_progress=True;solver.parameters.fix_variables_to_their_hinted_value=a.control
 class StopAt214(cp_model.CpSolverSolutionCallback):
  def on_solution_callback(self):
   count=sum(self.Value(v)for v in iy.values());print('INCUMBENT',count,'moved',self.Value(moved),'seconds',self.WallTime(),flush=True)
   if count<=214:self.StopSearch()
 begin=time.monotonic();status=solver.Solve(model,StopAt214());receipt.update(solver=solver.StatusName(status),solver_version=ortools.__version__,workers=a.workers,seed=a.seed,time_limit=a.seconds,seconds=time.monotonic()-begin,objective=solver.ObjectiveValue(),bound=solver.BestObjectiveBound(),control=a.control)
 (a.out/'solver_response.txt').write_text(solver.ResponseStats()+'\n')
 if status not in(cp_model.OPTIMAL,cp_model.FEASIBLE):receipt['status']='NO_ALLOCATION';finish();return
 M={r:solver.Value(v)for r,v in ir.items()};keep={q for q,v in iy.items()if solver.Value(v)};assert len(keep)<=a.bound,('state bound violated',len(keep),a.bound);N={};written={};chosen={key:i for(key,i),v in iv.items()if solver.Value(v)}
 for q in keep:
  for bit in(0,1):N[q,bit]=T[q,bit]if(q,bit)in P else(bit,1,q)
 activated_helpers=set()
 for k,h in ih.items():
  if solver.Value(h):assert k[0]in keep;N[k]=T[k];written[k]=T[k];activated_helpers.add(k)
 for u,deps in helper_rules:
  if solver.Value(u):
   for k in deps:
    act=T[k];assert k[0]in keep;assert k not in written or written[k]==act;N[k]=act;written[k]=act;activated_helpers.add(k)
 for r,q in M.items():
  for bit,ch in enumerate(R[r]['children']):
   if(q,bit)in P:continue
   key=r,bit;act,need=options[key][chosen[key]]
   if act is None:zz={M[c]for c in children[key].values()};assert len(zz)==1;act=(bit,1,next(iter(zz)))
   else:assert all(M[c]==z for c,z in need)
   assert(q,bit)not in written or written[q,bit]==act,('conflicting rows',q,bit);N[q,bit]=act;written[q,bit]=act
 assert all(z in keep|{254}for w,d,z in N.values());assert all(N[k]==T[k]for k in P if k[0]in keep)
 tree=sl.tree(json.loads((ROOT/'sites215.json').read_text()));fail=[]
 try:
  ng,npth=b.decoder_map(N,tree);actual={p:q for q,pcs in npth.items()for p in pcs}
  for r,rr in R.items():
   for p in rr['occurrences']:
    if actual[p]!=M[r]:fail.append([p,actual[p],M[r]])
 except Exception as e:fail.append(repr(e))
 receipt.update(status='PREFIX_PASS'if not fail else'PREFIX_FAIL',states=len(keep),failures=fail,removed=sorted(set(Q)-keep),activated_helpers=sorted(activated_helpers),changed_rows=[list(k)+list(v)for k,v in sorted(N.items())if T.get(k)!=v],assignments=[{'role':r,'old':R[r]['old_q'],'q':q,'path':R[r]['representative']}for r,q in M.items()],chosen_modes=[dict(role=key[0],bit=key[1],action=options[key][i][0],requirements=sorted(options[key][i][1]))for key,i in chosen.items()])
 (a.out/'candidate.native.tm').write_bytes(b.table_bytes(N));finish()
if __name__=='__main__':main()
