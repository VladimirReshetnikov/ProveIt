from pathlib import Path
import sys,json,hashlib
B=Path('/dev/shm/zfc214-9d0ff4abecf6');K=B/'repo/Computability/BusyBeaver/Research/ZFC/candidate-k215'
sys.path.insert(0,str(K/'research/composition-allocation'));import source_language as s,source_splice as sp
P=B/'incoming-late/Transfer_Compiler_201_Nodes_214_Target_Unmet_2026-10-21/Transfer_Compiler_201_Nodes_214_Target_Unmet_2026-10-21'
source=P/'source/transfer201.sites.json';old=s.tree(json.loads(source.read_text()));target=s.subtree(old,'11010111');assert sp.size(target)==26
assert sp.sites(old)[4670:4696]==[('11010111'+p,*q)for p,*q in sp.sites(target)]
out=B/'encoding/transfer-mp';out.mkdir(exist_ok=True)
rows=[]
for name,repl in [('cache_return',(('CD',4),(('CI',5),('CC',2)))),('omit_zero',target[1])]:
 new=s.replace(old,'11010111',repl);raw=sp.compact(sp.sites(new));(out/(name+'.json')).write_bytes(raw)
 rows.append(dict(name=name,source_sha256=sp.sha(raw),metrics=sp.metrics(new),replacement=sp.sites(repl),scope='Source pricing only. Formal compiler repair supplied separately by formalism agent; no binary runtime or blank-start proof.'))
(out/'receipt.json').write_text(json.dumps(dict(baseline_sha256=sp.sha(source.read_bytes()),old_interval=[4670,4696],old_prefix='11010111',results=rows),indent=2)+'\n');print(json.dumps(rows,indent=2))
