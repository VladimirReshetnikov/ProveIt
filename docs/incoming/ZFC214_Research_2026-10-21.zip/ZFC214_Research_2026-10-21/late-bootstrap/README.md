# Final focused bootstrap search

Status: no calibrated 214-state machine found.

The parent runtime-only table is from the public incoming `zfc214-research.zip`, commit b74074eacb936164d85e0f1aea5a8254412ade48. Its original attribution and licenses are retained under `incoming-late/` in this packet.

`reroute-proof.json` checks the two predecessor bits for the all-tape replacement83/1:0L42 ->0L57. It preserves the parent’s unconditional blank ray; by itself it cannot fix startup. The purpose was to remove an engine use of42/1 before coordinated synthesis.

`collect_target_contexts.py` is the incoming collector with one explicit target-state filter for42 and51. It rechecks all6176 symbolic primitive cases and the block schemas, but records local neighborhoods only at those two states. Do not treat its empty context sets for other states as unreachable-state claims. `contexts8.txt` is for radius8, with5536 contexts total. `summary.json` and the collection log give exact scope and hashes.

The copied incoming C++ synthesizer was reviewed before use. It searches exact common configurations within radius8 and40 positive local steps, and tests each nontrivial accepted mutation from all214 blank start states for at most200000steps. The `any-seed` option admits arbitrary primary register tuples as structural seeds; a logical calibration would still be required. Neither recorded family found a seed, and neither had a startup step-bound exit.

Reproduce after compiling `repair_bootstrap.cpp` with C++17 and flags `-O3 -DDIAGRAM_RADIUS=8 -DDIAGRAM_STEPS=40`:

    ./repair_bootstrap8 rerouted-runtime214.native.tm contexts8.txt 42 51 1 any-seed
    ./repair_bootstrap8 rerouted-runtime214.native.tm contexts8.txt 51 42 -1 any-seed

The first frees42/1 and both51 rows; the second frees both rows at both states. These are scoped finite searches. Their failure gives no lower bound against different helpers, larger local simulations, nonlocal transformations, or different encodings.
