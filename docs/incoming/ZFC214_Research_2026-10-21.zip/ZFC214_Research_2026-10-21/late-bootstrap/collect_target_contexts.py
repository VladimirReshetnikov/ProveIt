from pathlib import Path
import sys,json,time,functools,math
import argparse
ap=argparse.ArgumentParser(description='Collect sound local contexts while rechecking every symbolic primitive case.')
ap.add_argument('packet_root',type=Path)
ap.add_argument('table',type=Path)
ap.add_argument('sites',type=Path)
ap.add_argument('output',type=Path)
ap.add_argument('--radius',type=int,default=4)
args=ap.parse_args()
B=args.packet_root.resolve();OUT=args.output.resolve()
sys.path.insert(0,str(B/'verification/code/runtime'))
import symbolic_runtime as s
T=s.r.table(args.table);m={int(k):int(v) for k,v in json.loads((B/'verification/code/inputs/legacy_mapping.json').read_text()).items()}
for q,b in T:m.setdefault(q,q+1000)
m.setdefault(254,254);inv={v:k for k,v in m.items()};L={(m[q],b):(w,d,m[z]) for(q,b),(w,d,z)in T.items()}
R=args.radius;seen={q:set() for q,b in T};orig=s.State.step;calls=0;unary=0
REVERSE={n:[int(format(v,f'0{n}b')[::-1],2) if n else 0 for v in range(1<<n)] for n in range(R+2)}
@functools.lru_cache(maxsize=100000)
def prefix(atoms,n):
 if n==0:return frozenset([0])
 if not atoms:raise AssertionError('No exterior in prefix')
 a,*rest=atoms;rest=tuple(rest)
 if a==s.BLANK:return frozenset([0])
 if a[0]=='opaque':return frozenset(range(1<<n))
 if a[0]=='run':
  bit,expr=a[1:];k=expr[0];g=math.gcd(*expr[1:]);out=set()
  if k>=n:return frozenset([(1<<n)-1 if bit else 0])
  lens=[k] if not g else list(range(k,n,g))+[n]
  for length in lens:
   if length>=n:out.add((1<<n)-1 if bit else 0)
   else:
    pre=(1<<length)-1 if bit else 0
    for tail in prefix(rest,n-length):out.add(pre|(tail<<length))
  return frozenset(out)
 if a[0]=='list':
  family,reverse=a[1],a[3];out=set(prefix(rest,n))
  # Empty or one arbitrary block followed by another arbitrary finite list.
  # Values >=n have the same visible prefix as the v=n representative.
  for value in range(n+1):
   word=([0]+[1]*(value+1)) if family=='B' else ([1,0]+[1]*value)
   if reverse:word=word[::-1]
   if len(word)>=n:out.add(sum(x<<i for i,x in enumerate(word[:n])))
   else:
    pre=sum(x<<i for i,x in enumerate(word))
    for tail in prefix((a,)+rest,n-len(word)):out.add(pre|(tail<<len(word)))
  return frozenset(out)
 raise AssertionError(a)

def add_context(q,d,src,dst):
 if d==1:
  for x in src:
   for y in dst:seen[q].add(REVERSE[R][y]|(x<<R))
 else:
  for x in src:
   for y in dst:seen[q].add(REVERSE[R+1][x]|(y<<(R+1)))

def prefixed(bit,length,rest,n):
 if length>=n:return frozenset([(1<<n)-1 if bit else 0])
 pre=(1<<length)-1 if bit else 0
 return frozenset(pre|(t<<length) for t in prefix(rest,n-length))

def observe(obj,table,lemmas,clock,motion):
 global calls,unary
 obj.key();q=inv[obj.q];d=obj.direction;calls+=1
 if q not in {42,51}:return orig(obj,table,lemmas,clock,motion)
 src=tuple(obj.right if d==1 else obj.left);dst=tuple(obj.left if d==1 else obj.right)
 add_context(q,d,prefix(src,R+1),prefix(dst,R))
 if src and src[0][0]=='run':
  a=src[0];row=table[obj.q,a[1]]
  if row[2]==obj.q and row[1]==d:
   unary+=1;k=a[2][0];g=math.gcd(*a[2][1:]);b=a[1];w=row[0]
   # i=consumed cells; j=remaining cells including the current cell.
   # i==R and j==R+1 stand for their respective unbounded upper classes.
   for i in range(R+1):
    dp=prefixed(w,i,dst,R)
    for j in range(1,R+2):
     lower=i+j;unbounded=i==R or j==R+1
     if g:
      possible=unbounded or (lower>=k and (lower-k)%g==0)
     else:possible=(k>=lower if unbounded else k==lower)
     if possible:add_context(q,d,prefixed(b,j,src[1:],R+1),dp)
 return orig(obj,table,lemmas,clock,motion)
s.State.step=observe
beg=time.time();lemmas,blocks=s.prove_blocks(L)
for i,site in enumerate(json.loads(args.sites.read_text())):
 for pos in ((False,True) if site[1]=='CD' else (False,)):s.case(L,lemmas,site,pos)
 if i%1000==0:print(i,round(time.time()-beg,1),prefix.cache_info(),flush=True)
with OUT.open('w')as f:
 for q,vals in sorted(seen.items()):f.write(f'{q} {len(vals)} '+' '.join(map(str,sorted(vals)))+'\n')
OUT.with_suffix('.json').write_text(json.dumps({'target_states':[42,51],'complete_contexts_for_other_states':False,'runtime_calls':calls,'unary_calls':unary,'radius':R,'contexts':{q:sorted(v) for q,v in seen.items()},'seconds':time.time()-beg},indent=2)+'\n')
print('DONE',round(time.time()-beg,1),sum(map(len,seen.values())),flush=True)
