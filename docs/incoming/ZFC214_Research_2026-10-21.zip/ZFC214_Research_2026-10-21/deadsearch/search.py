from pathlib import Path
import json,itertools,sys,time,hashlib
BASE=Path('/dev/shm/zfc214-9d0ff4abecf6/repo/Computability/BusyBeaver/Research/ZFC/candidate-k215')
sys.path.insert(0,str(BASE/'code'));import source_language as s
rows=json.loads((BASE/'sites215.json').read_text());S=s.tree(rows);nodes=[];interns={}
def intern(n):
 if n in interns:return interns[n]
 i=len(nodes);nodes.append(n);interns[n]=i;return i

def put(n):return intern(n)if s.leaf(n)else intern(tuple(put(c)for c in n))
root=put(S);leafids=[i for i,n in enumerate(nodes)if isinstance(n[0],str)];cb=intern(('CB',1))
def update(q,path,z):
 if not path:return z
 k=int(path[0]);cs=list(nodes[q]);cs[k]=update(cs[k],path[1:],z);return intern(tuple(cs))
def live(q):
 seen=set();stack=[q]
 while stack:
  x=stack.pop()
  if x in seen:continue
  seen.add(x);n=nodes[x]
  if isinstance(n[0],int):stack.extend(n)
 return len(seen)
def thaw(q):
 n=nodes[q];return n if isinstance(n[0],str)else tuple(thaw(z)for z in n)
assert rows[4672][0][:-1]==rows[4673][0][:-1]
slot1=rows[4672][0][:-1];slot2=rows[4734][0];g1=rows[4671][0];g2=rows[4733][0]
print('slots',slot1,slot2,'guards',g1,g2,'types',len(leafids),flush=True)
best=202;bestlist=[];counts={};start=time.monotonic();total=0
for mask in range(4):
 rr=root
 if mask&1:rr=update(rr,g1,cb)
 if mask&2:rr=update(rr,g2,cb)
 for a,b in itertools.product(leafids,repeat=2):
  r1=update(rr,slot1,intern((a,b)))
  for c in leafids:
   nr=update(r1,slot2,c);cost=live(nr);total+=1;counts[cost]=counts.get(cost,0)+1
   if cost<best:
    best=cost;bestlist=[];print('best',best,'mask',mask,'leaves',[nodes[i]for i in(a,b,c)],'iter',total,'seconds',time.monotonic()-start,flush=True)
   if cost<=best and len(bestlist)<100:bestlist.append((mask,a,b,c,nr))
report={'baseline_nodes':202,'best':best,'total':total,'histogram':counts,'seconds':time.monotonic()-start,'node_count_storage':len(nodes),'witnesses':[]}
for j,(mask,a,b,c,nr)in enumerate(bestlist):
 cand=s.sites(thaw(nr));raw=s.compact(cand);name=f'best{best}-{j:03}.json';(Path(__file__).parent/name).write_bytes(raw)
 report['witnesses'].append({'file':name,'mask':mask,'leaves':[nodes[i]for i in(a,b,c)],'sha256':hashlib.sha256(raw).hexdigest(),'changed_rows':[[i,o,n]for i,(o,n)in enumerate(zip(rows,cand))if o!=n]})
(Path(__file__).parent/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='witnesses'},indent=2))
