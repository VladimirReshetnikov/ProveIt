#!/usr/bin/env python3
"""Finite abstract certificate for all-natural source reachability.
Buckets0..K-1 are singleton natural values; bucketK denotes all values>=K.
Independent post-fixed-point replay is mandatory. No bounded machine run.
"""
from pathlib import Path
import argparse,sys,json,gzip,hashlib,time
from collections import deque
ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--lib',type=Path,required=True);ap.add_argument('--seed',default='4,0,0,0,0,0,0,0,0');ap.add_argument('--bucket',type=int,default=8);ap.add_argument('--initial-entry',type=int,default=0);ap.add_argument('--domains',default=None);a=ap.parse_args()
sys.path.insert(0,str(a.lib));import source_language as s
raw=a.source.read_bytes();rows=json.loads(raw);g=s.graph_arithmetic(rows)[0];assert g==s.graph_intervals(rows);n=len(g);k=a.bucket;assert k>=2
seed=list(map(int,a.seed.split(',')));assert len(seed)==9 and min(seed)>=0
inc=[];dec=[]
for mask in range(1<<(k+1)):
 i=d=0
 for b in range(k+1):
  if mask>>b&1:
   i|=1<<min(b+1,k)
   if b==k:d|=(1<<k)|(1<<(k-1))
   elif b>0:d|=1<<(b-1)
 inc.append(i);dec.append(d)
def succ(i,st):
 eff,targets=g[i];op=eff[0]
 if op=='halt':return []
 if op=='identity':return [(targets[0],st)]
 j=eff[1]
 if op=='increment':
  nxt=st.copy();nxt[j]=inc[st[j]];return[(targets[0],nxt)]
 assert op=='decrement';out=[]
 if st[j]&1:
  nxt=st.copy();nxt[j]=1;out.append((targets[0],nxt))
 if st[j]&~1:
  nxt=st.copy();nxt[j]=dec[st[j]];out.append((targets[1],nxt))
 return out
initial=[1<<min(x,k)for x in seed]if a.domains is None else list(map(int,a.domains.split(',')));assert len(initial)==9 and all(0<x<(1<<(k+1))for x in initial)
entry=a.initial_entry;assert 0<=entry<n;S=[None]*n;S[entry]=initial;q=deque([entry]);inq={entry};updates=edges=0;start=time.monotonic()
while q:
 i=q.popleft();inq.remove(i)
 for j,st in succ(i,S[i]):
  old=S[j]
  if old is None:new=st.copy()
  else:new=[x|y for x,y in zip(old,st)]
  if new!=old:
   S[j]=new;updates+=1
   if j not in inq:q.append(j);inq.add(j)
# independent inductive post-fixpoint verification, not trusting worklist scheduling
assert all(x&~y==0 for x,y in zip(initial,S[entry]))
for i,st in enumerate(S):
 if st is None:continue
 assert len(st)==9 and all(0<m<(1<<(k+1))for m in st)
 for j,nxt in succ(i,st):
  edges+=1;assert S[j] is not None and all(x&~y==0 for x,y in zip(nxt,S[j])),(i,j)
dead=[i for i,st in enumerate(S)if st is None];forced0=[];forcedpos=[]
for i,st in enumerate(S):
 if st is None or g[i][0][0]!='decrement':continue
 m=st[g[i][0][1]]
 if m==1:forced0.append(i)
 if m&1==0:forcedpos.append(i)
res={'status':'INDUCTIVE_CARTESIAN_SOURCE_CLOSURE','source_sha256':hashlib.sha256(raw).hexdigest(),'seed':seed,'initial_domains':initial,'initial_entry':entry,'bucket_limit':k,'updates':updates,'edges':edges,'dead':dead,'forced_zero':forced0,'forced_positive':forcedpos,'seconds':time.monotonic()-start,'proof_scope':'Inductive all-natural reachability over singleton buckets and the unbounded >=K bucket; independent post-fixed-point replay passes.'}
a.out.mkdir(parents=True,exist_ok=True);d={'result':res,'states':S};(a.out/'source_invariant.json.gz').write_bytes(gzip.compress((json.dumps(d,separators=(',',':'))+'\n').encode(),mtime=0))
(a.out/'summary.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2));print('dead_paths',[(i,rows[i])for i in dead]);print('forced_zero_paths',[(i,rows[i])for i in forced0])
