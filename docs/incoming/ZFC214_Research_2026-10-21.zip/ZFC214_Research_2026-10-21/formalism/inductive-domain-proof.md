# An inductive source domain for K215

## Exact quantified claim

The source is the published K215 `sites215.json`, SHA-256 `17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba`. At source ordinal0, let the nine registers be `[N,T,W,A,D,H,X,Y,L]`. The certificate covers **every** natural initial store satisfying only T=W=H=0. The other six registers N,A,D,X,Y,L are arbitrary naturals. In particular it covers the complete accepted blank endpoint `[4,0,0,0,0,0,0,0,0]`, every larger candidate cutoff, and every other formula-clean root admitted by the predecessor's dirty-root theorem. This is a source invariant assertion; applicability of the ordinary numerical-calculus compiler to a dirty root remains the inherited theorem, not a conclusion of abstract interpretation.

The finite invariant proves that source ordinals4672,4673,4734 are never entered. At ordinal4671 the tested register T=register1 is0; at ordinal4733 register6 is0. These are the only decrement guards forced by this particular abstract invariant. No implication about other stronger source invariants or minimality is intended.

## Bucket semantics

Use nine buckets B_0,...,B_8, with B_j={j} for0<=j<8 and B_8={n in N:n>=8}. A nonzero integer mask m<=511 denotes V(m)=the union of B_j over its set bits. A row of nine masks denotes their Cartesian product. `null` denotes the empty set of stores at an unreachable ordinal.

The initial-domain masks are exactly `[511,1,1,511,511,1,511,511,511]`. A displayed representative seed in producer metadata is not the quantified initial domain; the `initial_domains` field is authoritative. All nine masks at ordinal0 contain the corresponding initial masks.

The increment abstraction sends each bit j to min(j+1,8). This is exact on singleton buckets, and sends the tail bucket into itself because n>=8 implies n+1>=8. For a positive decrement, bits1,...,7 map to0,...,6. Bucket8 maps to the union of buckets7 and8: n>=8 implies n-1>=7. Zero is excluded from that branch. The zero decrement branch restricts the tested register to bucket0 and leaves it there. Every other register is unchanged. CB/CC preserve all registers; CH has no successor.

For every source edge feasible in an invariant row, the finite verifier checks that the abstract image is contained coordinatewise in the invariant row at its successor. Bit inclusion is exactly set inclusion between unions of these disjoint buckets. Thus these finite inequalities prove that every concrete natural step preserves membership in the certified row, even when a register lies in the unbounded tail bucket. By induction on the number of source steps, every reached store satisfies its row. A `null` row cannot be reached. This is a mathematical induction proof over all finite executions, not testing up to bucket value8.

## Independent verification

`abstract_source.py` computes a candidate post-fixed point by worklist iteration. `check_source_invariant.py` imports neither that producer nor the source-language or binary-runtime helpers. It rebuilds the complete source control graph from literal paths, through ancestor subtree intervals, and checks every local inclusion and the initial-domain inclusion. The root certificate has 4,751 sites and6,170 feasible nonhalting edges. The halt site supplies one additional primitive case, yielding6,171 feasible guarded primitive contracts. The originally unconditional primitive suite has6,176 cases; three dead leaves and two impossible positive decrement guards account for the difference.

The checker counts4,295 singleton entry-register assertions, of which4,163 specify zero. Tail-only mask256 is deliberately not counted as a singleton. Its interpretation is all values>=8.

## Dead decoder-provider slots

The maximal dead prefixes are:

| Prefix | Existing subtree | Ordinal interval |
|---|---|---|
| `11010010111001` | `(CI6,CC2)` | [4672,4674) |
| `1111001101` | `CC2` | [4734,4735) |

Suppose one replaces either dead subtree by any finite full source tree. Retained source leaves keep their literal paths. To prove preservation, construct a partial map from old ordinals to new ordinals by equal retained paths. For every old reachable instruction, compare its opcode/operand and each invariant-feasible successor under this map. The corresponding successor must remain a retained leaf, not a newly inserted leaf. If these finite checks pass, the relation consisting of mapped ordinals and identical register stores is a forward simulation at every reachable old step. Induction proves that no inserted instruction is reached by the new execution either. The root and halt correspondence must be included explicitly. All steps have duration one at the source level, so infinite source runs are preserved too.

No need exists to assign an intended logical meaning to a new dead leaf. Its physical decoder state may still be used as a marker-inspecting helper; that is a separate exact binary transition argument. The binary verification may prove every primitive case including dead leaves, or may restrict to the just-proved reachable source domain. The latter is sufficient when coupled to this invariant.

An attempted rewrite may change control-depth meaning despite preserving some textual paths. The mapping/guarded-CFG check is mandatory. Source count and observed nonexecution alone do not establish this correspondence.

## Restricting primitive runtime domains

At each reachable source ordinal, specialize every singleton entry-register to its certified natural constant. For each other mask, use the larger affine domain `minimum(mask)+n`, n any natural. On a positive CD branch first remove bucket0; on its zero branch use exactly0. These domains contain the invariant row's guard-restricted Cartesian product. A symbolic proof valid throughout these possibly larger affine domains therefore proves the primitive contract for every actually reachable source frame.

The binary-frame gap and every spare value remain independent arbitrary naturals; the spare list remains arbitrary finite nonempty. Source invariants do not constrain those tape parameters. Existing literal-step, unary-scan induction and finite-list induction rules are unchanged. An exact positive duration is still required for every proved primitive, and full-tape endpoints must match.

Combining the actual finite blank prefix, source-domain induction, and the restricted primitive theorems yields complete binary/source simulation from the blank endpoint. It does not assert arbitrary-start equivalence on binary frames whose source register tuple violates the invariant. That broader assertion is unnecessary for the requested blank nonhalting equivalence.

A row census generated by these symbolic proofs is a synthesis filter. Any new table must have the relevant primitive theorems rederived from its exact literal rows. In particular a row omitted by one diagnostic proof is not automatically unreachable on every arbitrary tape.

## Proof-assistant scope

All objects and proof obligations here are finite or use elementary induction and can be formalized in ZFC (indeed far less is sufficient for the invariant itself). No new Lean/Rocq or internal PA endpoint is claimed. The standalone checker validates ordinary mathematical proof evidence outside a proof-assistant kernel.
