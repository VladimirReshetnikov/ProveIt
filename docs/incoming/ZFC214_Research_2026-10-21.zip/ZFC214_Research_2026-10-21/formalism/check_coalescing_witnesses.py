#!/usr/bin/env python3
"""Replay concrete direct-sum counter-coalescing counterexamples.
This verifies finite witnesses only, not the absence of all possible encodings.
"""
import argparse,hashlib,json
from collections import defaultdict
from pathlib import Path
from check_source_invariant import graph
SOURCE_SHA='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--witnesses',type=Path,nargs='+',required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();raw=a.source.read_bytes();assert hashlib.sha256(raw).hexdigest()==SOURCE_SHA;G=graph(json.loads(raw));jobs=defaultdict(lambda:defaultdict(list));hashes={};count=0
 for p in a.witnesses:
  b=p.read_bytes();d=json.loads(b);hashes[p.name]=hashlib.sha256(b).hexdigest()
  if 'witnesses'in d:
   items=[]
   for r in d['witnesses']:
    items.append((r,'zero_other_positive'))
  else:
   items=[]
   for site,entries in d['sites'].items():
    for kind,r in entries.items():
     rr=dict(r);rr['site']=int(site);rr['tested_register']=G[int(site)][1];rr['other_register']=8 if rr['tested_register']==0 else 0;items.append((rr,kind))
  for r,kind in items:
   assert r['initial_N']>=4 and r['steps']>=0;assert len(r['store'])==9 and all(type(x)is int and x>=0 for x in r['store']);jobs[r['initial_N']][r['steps']].append((r,kind));count+=1
 steps=0
 for seed,queries in jobs.items():
  R=[seed,0,0,0,0,0,0,0,0];pc=0
  for k in range(max(queries)+1):
   for r,kind in queries.get(k,[]):
    assert pc==r['site']and R==r['store'],(seed,k,pc,R,r)
    op,j,_=G[pc];assert op=='CD'and j==r['tested_register'];other=r['other_register'];assert j!=other
    if kind=='positive':assert R[j]>0
    elif kind=='zero_both':assert R[j]==R[other]==0
    else:assert kind=='zero_other_positive'and R[j]==0 and R[other]>0
   op,j,ts=G[pc]
   if k==max(queries):break
   assert op!='CH'
   if op=='CI':R[j]+=1;pc=ts[0]
   elif op=='CD':
    if R[j]==0:pc=ts[0]
    else:R[j]-=1;pc=ts[1]
   else:pc=ts[0]
   steps+=1
 r={'status':'CONCRETE_COALESCING_WITNESSES_REPLAY_PASS','source_sha256':SOURCE_SHA,'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashes,'checked_witnesses':count,'initial_counters':sorted(jobs),'source_steps_replayed':steps,'scope':'Each listed finite source configuration is reached exactly from its stated clean root. Zero/other-positive tests refute direct sum simulation. Positive tests at the same site refute replacing that guard uniformly by its zero branch. No claim excludes more extensive source specialization or other representations.'};a.out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
