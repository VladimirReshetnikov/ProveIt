#!/usr/bin/env python3
"""Construct and price theorem-equivalent K/S/Peirce AX variants (source only)."""
from pathlib import Path
from functools import lru_cache
import sys,json,itertools,hashlib,time
B=Path('/dev/shm/zfc214-9d0ff4abecf6/repo/Computability/BusyBeaver/Research/ZFC/candidate-k215')
sys.path.insert(0,str(B/'research/composition-allocation'))
import source_splice as sp
root=sp.parse(json.loads((B/'sites215.json').read_text()))
def get(a,b):return sp.serial(sp.closed_forest(root,a,b))
M={'a':get(26,52),'b':get(52,78),'c':get(107,133),'i':get(173,200),'y':get(159,173)}
assert all(sp.boundary(n)==(0,0,False) for n in M.values())
ids={};nodes=[]
def intern(n):
 if n not in ids:ids[n]=len(nodes);nodes.append(n)
 return ids[n]
@lru_cache(None)
def enc(n):return intern(n if sp.leaf(n) else (enc(n[0]),enc(n[1])))
oldroot=enc(root);oldids=set(range(len(nodes)));macro={enc(n):a for a,n in M.items()}
@lru_cache(None)
def dec(k):
 n=nodes[k];return n if isinstance(n[0],str) else(dec(n[0]),dec(n[1]))
@lru_cache(None)
def tokens(k):
 if k in macro:return(macro[k],)
 n=nodes[k]
 if isinstance(n[0],str):return None
 a,b=map(tokens,n)
 return None if a is None or b is None else a+b
@lru_cache(None)
def missing(k):
 if k in oldids:return frozenset()
 n=nodes[k]
 return frozenset([k]) if isinstance(n[0],str) else missing(n[0])|missing(n[1])|{k}
@lru_cache(None)
def stats(k):
 n=nodes[k]
 if isinstance(n[0],str):return(0,0,0)
 l,r=map(stats,n)
 return(1+max(l[0],r[0]),1+l[1],max(1+l[1],l[2],r[2]))
patterns={}
for k in oldids:
 t=tokens(k)
 if t is not None:patterns.setdefault(t,[]).append(k)
@lru_cache(None)
def synth(t):
 if t in patterns:return min(patterns[t],key=lambda k:(stats(k)[2],stats(k)[0]))
 candidates=[intern((synth(t[:j]),synth(t[j:]))) for j in range(1,len(t))]
 return min(candidates,key=lambda k:(len(missing(k)),stats(k)[2],stats(k)[0]))
@lru_cache(None)
def size(k):
 n=nodes[k];return 1 if isinstance(n[0],str) else size(n[0])+size(n[1])
def splice(k,replacement,i=0):
 j=i+size(k)
 if j<=107 or 479<=i:return k
 if 107<=i and j<=479:return replacement if i==107 else None
 a,b=nodes[k];u=splice(a,replacement,i);v=splice(b,replacement,i+size(a))
 if u is None:return v
 if v is None:return u
 return intern((u,v))
def score(k):
 seen=set();todo=[k]
 while todo:
  k=todo.pop()
  if k in seen:continue
  seen.add(k);n=nodes[k]
  if not isinstance(n[0],str):todo.extend(n)
 return len(seen)
# The original unrestricted/dominated axiom's scalar macro word, including
# its two field readers, is separately identified by exact closed intervals.
assert sp.size(get(107,479))==372
K=('a','b','a','i','i')
S=('a','b','c','i','i','a','b','i','a','c','i','i','i')
P=('a','b','i','a','i','a','i')
perms=list(itertools.permutations('abc'));start=time.monotonic();best=None;wins=[]
out=Path('/dev/shm/zfc214-9d0ff4abecf6/formalism/ksp-source');out.mkdir(exist_ok=True)
trials=0
for order in itertools.permutations(range(3)):
 for choices in itertools.product(range(6),repeat=3):
  words=[]
  for w,k in zip((K,S,P),choices):
   ren=dict(zip('abc',perms[k]));words.append(tuple(ren.get(x,x)for x in w))
  word=('y',)+sum((words[k]for k in order),())
  replacement=synth(word)
  rr=splice(oldroot,replacement)
  z=stats(rr);m=dict(dag_nodes=score(rr),leaf_occurrences=size(rr),maximum_depth=z[0],maximum_zero_run=z[2]);sc=m['dag_nodes'];trials+=1
  if best is None or sc<best:
   best=sc;wins=[]
   print('BEST',trials,m,'order',order,'parameters',choices,flush=True)
  if sc==best:
   item={'order':order,'parameters':choices,'metrics':m,'macro_word':word}
   wins.append((rr,item))
print('END',trials,best,len(wins),'seconds',time.monotonic()-start,flush=True)
for j,(r,item)in enumerate(wins[:32]):
 raw=sp.compact(sp.sites(dec(r)));name='ksp-'+str(j)+'.json';(out/name).write_bytes(raw);item['file']=name;item['source_sha256']=sp.sha(raw)
(out/'summary.json').write_text(json.dumps({'status':'SOURCE_ONLY_NO_BINARY_CANDIDATE','trials':trials,'best':best,'tie_count':len(wins),'permutation_dictionary':perms,'winners':[x for r,x in wins[:32]],'semantic_change':'Replace rho8 by K,S,Peirce; remove additive A field; U=A=D, B=H+y,C=c; retain all other rows, MP,GEN,gate.'},indent=2)+'\n')
