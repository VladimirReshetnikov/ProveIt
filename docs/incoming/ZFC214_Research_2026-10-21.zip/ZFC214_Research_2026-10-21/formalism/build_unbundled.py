#!/usr/bin/env python3
"""Split literal K215 bundle B=not(V -> H) into V and K=not H.
Preserve the two comparisons; after them, if top=0, discard the extra V.
This gives the old stack length on failed gates and one extra entry otherwise.
Source construction/census only; binary allocation is a separate obligation.
"""
from pathlib import Path
import json,sys
B=Path('/dev/shm/zfc214-9d0ff4abecf6/repo/Computability/BusyBeaver/Research/ZFC/candidate-k215')
sys.path.insert(0,str(B/'research/composition-allocation'));import source_splice as sp
from check_literal_k215_models import extract
raw=(B/'sites215.json').read_bytes();rows=json.loads(raw);root=sp.parse(rows)
def get(a,b):return sp.serial(sp.closed_forest(root,a,b))
parsed=extract(B/'sites215.json');bundle=parsed[-1]['formula'];assert bundle[0]=='i'and bundle[2]=='f'and bundle[1][0]=='i'
V,H=bundle[1][1:];K=['i',H,'f']
assert parsed[-1]['tokens'][-3:]==[['i',4482,4509],['f',4509,4529],['i',4529,4556]]
assert get(4482,4509)==get(173,200)
unpair=get(4737,4748);zeroX=(('CD',6),('CC',1));discard=(unpair,zeroX)
guard=((('CD',1),(('CI',1),('CB',1))),discard)
assert sp.boundary(unpair)==sp.boundary(discard)==sp.boundary(guard)==(0,0,False)
changed=sp.apply_closed_splices(root,{(4482,4509):None})
r2=sp.sites(changed);old_exit=4590;new_exit=old_exit-27;path,op,arg=r2[new_exit];assert(op,arg)==('CB',1)
def put(t,p,v):
 if not p:return v
 d=int(p[0]);return(put(t[0],p[1:],v),t[1])if d==0 else(t[0],put(t[1],p[1:],v))
changed=put(changed,path,(guard,('CB',1)));rr=sp.sites(changed);assert sp.cfg_intervals(rr)==sp.cfg_arithmetic(rr)
out=Path(__file__).parent/'unbundled-source';out.mkdir(exist_ok=True);src=sp.compact(rr);(out/'unbundled215.json').write_bytes(src)
report={'status':'SOURCE_ONLY_WITH_COMMAND_TRANSFER_PROOF','source_sha256':sp.sha(src),'baseline_sha256':sp.sha(raw),'metrics':sp.metrics(changed),'removed_closed_interval':[4482,4509],'added_guard_leaves':sp.size(guard),'guard':'if T=0 then unpair W into X; clear X else leave T unchanged','valid_gate_effect':'top=K; stack=[V,R1,...,R7,L,Q_U(oldH),oldT;oldW]','invalid_gate_effect':'top=0; stack=[R1,...,R7,L,Q_U(oldH),oldT;oldW]','V':V,'H':H,'K':K,'gate':'C differs from A and B; both old destructive comparisons retained before new guard','limitation':'Macro meanings are inherited and the new closed guard has an elementary arithmetic proof. No binary machine allocation or full source checker has yet accepted this source.'}
(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in('V','H','K')},indent=2))
