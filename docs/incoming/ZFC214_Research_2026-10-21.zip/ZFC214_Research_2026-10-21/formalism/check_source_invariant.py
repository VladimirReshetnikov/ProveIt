#!/usr/bin/env python3
"""Standalone finite verifier for an all-natural source inductive invariant.
No import of its producer, source-language helpers, optimizer, or runtime.
Input certificate entries are Cartesian products of numerical buckets.
"""
import argparse,gzip,hashlib,json
from pathlib import Path

def graph(rows):
    lookup={p:i for i,(p,o,a)in enumerate(rows)}
    assert len(lookup)==len(rows)
    bounds={}
    def rec(p):
        if p in lookup:
            i=lookup[p];ans=(i,i+1)
        else:
            assert len(p)<=max(map(len,lookup));x=rec(p+'0');y=rec(p+'1');assert x[1]==y[0];ans=(x[0],y[1])
        bounds[p]=ans;return ans
    assert rec('')==(0,len(rows));out=[]
    for i,(p,o,a)in enumerate(rows):
        assert p and set(p)<={'0','1'}
        assert o in ('CI','CD','CB','CC','CH')
        if o in ('CI','CD'):assert isinstance(a,int)and 0<=a<9
        if o in ('CB','CC'):assert isinstance(a,int)and a>=1
        if o=='CH':assert a is None
        def exit_of(bit,count):
            node=p
            while node:
                last=node[-1];node=node[:-1]
                if last==bit:
                    count-=1
                    if count==0:return bounds[node][1]%len(rows)if bit=='0'else bounds[node][0]
            return 0
        nxt=(i+1)%len(rows)
        if o=='CI':ts=[nxt]
        elif o=='CD':ts=[exit_of('0',1),nxt]
        elif o=='CB':ts=[exit_of('0',a)]
        elif o=='CC':ts=[exit_of('1',a)]
        else:ts=[]
        out.append((o,a,ts))
    return out

def verify(source,certificate,expected_initial=None):
    raw=Path(source).read_bytes();rows=json.loads(raw);cp=Path(certificate);blob=cp.read_bytes();cert=json.loads(gzip.decompress(blob)if cp.suffix=='.gz'else blob);r=cert['result'];S=cert['states'];k=r['bucket_limit'];assert 2<=k<=30
    assert r['source_sha256']==hashlib.sha256(raw).hexdigest();assert len(S)==len(rows)
    initial=r.get('initial_domains',[1<<min(v,k)for v in r['seed']]);full=(1<<(k+1))-1
    assert len(initial)==9 and all(isinstance(m,int)and 0<m<=full for m in initial)
    if expected_initial is not None:assert initial==expected_initial
    for st in S:
        assert st is None or(len(st)==9 and all(isinstance(m,int)and 0<m<=full for m in st))
    assert S[0] is not None and all(x&~y==0 for x,y in zip(initial,S[0]))
    G=graph(rows);checked=0;zero=[];positive=[]
    def lower(mask):
        ans=0
        for b in range(1,k+1):
            if mask&(1<<b):ans|=(1<<(b-1))|((1<<k)if b==k else 0)
        return ans
    def raise_mask(mask):
        return ((mask<<1)&full)|((1<<k)if mask&(1<<k)else 0)
    for i,st in enumerate(S):
        if st is None:continue
        op,arg,ts=G[i];edges=[]
        if op=='CI':
            after=st.copy();after[arg]=raise_mask(st[arg]);edges.append((ts[0],after))
        elif op=='CD':
            m=st[arg]
            if m==1:zero.append(i)
            if m&1==0:positive.append(i)
            if m&1:
                after=st.copy();after[arg]=1;edges.append((ts[0],after))
            if m&~1:
                after=st.copy();after[arg]=lower(m);edges.append((ts[1],after))
        elif op!='CH':edges.append((ts[0],st))
        for j,after in edges:
            assert S[j] is not None and all(x&~y==0 for x,y in zip(after,S[j])),('not inductive',i,j)
            checked+=1
    dead=[i for i,st in enumerate(S)if st is None]
    assert dead==r['dead']and zero==r['forced_zero']and positive==r['forced_positive']
    return {'status':'INDEPENDENT_INDUCTIVE_INVARIANT_PASS','source_sha256':r['source_sha256'],'certificate_sha256':hashlib.sha256(blob).hexdigest(),'initial_domains':initial,'bucket_limit':k,'source_sites':len(rows),'feasible_nonhalt_edges':checked,'dead':dead,'forced_zero':zero,'forced_positive':positive,'singleton_entry_registers':sum(m&(m-1)==0 and m<(1<<k)for st in S if st is not None for m in st),'zero_entry_registers':sum(m==1 for st in S if st is not None for m in st),'scope':'Induction over every natural source step, starting from every store in the stated Cartesian initial domain. Infinite top bucket includes all integers>=K. No finite execution bound.'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--certificate',type=Path,required=True);ap.add_argument('--out',type=Path);ap.add_argument('--require-clean-root',action='store_true');a=ap.parse_args();expected=[511,1,1,511,511,1,511,511,511]if a.require_clean_root else None;r=verify(a.source,a.certificate,expected);txt=json.dumps(r,indent=2)+'\n';print(txt,end='')
    if a.out:a.out.write_text(txt)
if __name__=='__main__':main()
