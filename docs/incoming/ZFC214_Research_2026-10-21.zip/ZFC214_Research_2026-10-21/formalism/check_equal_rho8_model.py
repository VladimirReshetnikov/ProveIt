#!/usr/bin/env python3
"""Check a finite algebra for the *entire* U=A-restricted numerical calculus.

Source definitions: Code254.lean at upstream commit
c8029f50d324910a36694c39a1e62f5720c36f4c. The check imports only the
standard library. Atom values are independent of variable indices, and
all quantifier indices use the same unary operation. It checks full,
ungated bundle validity, which is stronger than the required gated case.

The finite checks combine with structural recursion on natural codes,
using I(0,0)=0 for the numerical truth alias, to give a soundness proof.
This is not a search and does not presume a model of ZFC.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path

VALUES = range(3)
IMP = ((0, 2, 2), (0, 2, 0), (0, 0, 0))
ALL = (0, 2, 2)
MEMBERSHIP = EQUALITY = FALSUM = 1


def check(identity=False):
    if identity:
        imp_table = ((0,4,3,2,2), (0,0,0,0,2), (0,0,0,0,2),
                     (0,0,0,0,0), (0,2,0,0,0))
        q_table = (0,4,4,3,3)
        eq_value = 0
    else:
        imp_table, q_table, eq_value = IMP, ALL, EQUALITY
    values = range(len(imp_table))
    assert len(q_table) == len(imp_table)
    assert all(len(row) == len(imp_table) for row in imp_table)
    assert all(v in values for row in imp_table for v in row)
    assert all(v in values for v in q_table)
    def imp(a, b):
        return imp_table[a][b]
    def all_(a):
        return q_table[a]
    def neg(a):
        return imp(a, FALSUM)
    def conj(a, b):
        return neg(imp(a, neg(b)))
    def exists(a):
        return neg(all_(neg(a)))
    def rel(i, j):
        return MEMBERSHIP
    def eq(i, j):
        return eq_value
    def quant(i, body):
        return all_(body)
    def ex(i, body):
        return exists(body)

    # Literal AST shape of the retained container/global-image bundles.
    # c_value is the numerical formula interpretation of parameter c;
    # c also occurs as a variable index, which this algebra ignores.
    def bundle_c(a, b, c):
        return ex(b, conj(
            quant(a, imp(rel(a, b), conj(
                ex(c, conj(
                    quant(b, imp(
                        quant(c, imp(rel(c, b), rel(c, a))),
                        rel(b, c))),
                    rel(c, b))),
                quant(c, imp(rel(c, a), rel(c, b)))))),
            rel(c, b)))

    def bundle_g(a, b, c, c_value):
        return ex(c, conj(
            quant(a, imp(rel(a, b), quant(b, imp(
                c_value, ex(b, conj(c_value, rel(b, c))))))),
            quant(b, imp(rel(b, c), ex(a, c_value)))))

    def bundle(a, b, c, c_value):
        return conj(conj(bundle_c(a, b, c), bundle_g(a, b, c, c_value)),
                    conj(imp(rel(a, b), quant(c, rel(a, b))),
                         imp(eq(a, b), quant(c, eq(a, b)))))

    assert imp(0, 0) == 0
    assert FALSUM != 0
    assert all(imp(0, b) != 0 for b in values if b != 0)
    assert all_(0) == 0
    checked = {}
    rows = {
        'rho1': [ex(0, eq(0, 0))],
        'rho2': [imp(quant(0, imp(b, c)), imp(quant(0, b), quant(0, c)))
                 for b, c in itertools.product(values, repeat=2)],
        'rho3': [imp(eq(0, 1), imp(rel(2, 0), rel(2, 1)))],
        'rho4': [imp(quant(0, quant(1, c)), quant(1, quant(0, c)))
                 for c in values],
        'rho5': [imp(eq(2, 0), imp(rel(2, 1), rel(0, 1)))],
        'rho6': [imp(ex(0, quant(0, b)), b) for b in values],
        'rho7': [imp(eq(2, 0), imp(eq(2, 1), eq(0, 1)))],
        'rho8_U_equals_A': [imp(imp(imp(c, a), a), imp(imp(a, c), imp(b, c)))
                            for a, b, c in itertools.product(values, repeat=3)],
        'ungated_bundle': [bundle(0, 1, 2, c_value) for c_value in values],
    }
    if identity:
        rows['identity_schema'] = [imp(a, a) for a in values]
    for name, results in rows.items():
        assert all(v == 0 for v in results), (name, results)
        checked[name] = len(results)
    return {
        'status': 'FULL_RESTRICTED_CALCULUS_WITH_IDENTITY_MODEL_PASS' if identity else 'FULL_RESTRICTED_CALCULUS_FINITE_MODEL_PASS',
        'values': list(values),
        'designated': [0],
        'implication': imp_table,
        'universal_quantifier': q_table,
        'membership_atom': MEMBERSHIP,
        'equality_atom': eq_value,
        'truth': 0,
        'falsum': FALSUM,
        'axiom_checks': checked,
        'bundle_C_value': bundle_c(0, 1, 2),
        'bundle_G_values': [bundle_g(0, 1, 2, c) for c in values],
        'identity_schema_failure': next(({'A_value': a, 'I_A_A_value': imp(a, a)} for a in values if imp(a, a) != 0), None),
        'scope': 'All natural numerical codes, by recursive interpretation and induction on finite derivations; no formula well-formedness or ZFC model assumed.',
        'limitation': 'Applies to rho8 restricted to U=A while retaining the other seven rows and literal bundle' + (' and all identity instances (hence also the weaker repair adding only code16).' if identity else '.') + ' It does not apply to the accepted dominated U<=A calculus.'
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path)
    ap.add_argument('--identity', action='store_true')
    args = ap.parse_args()
    result = check(args.identity)
    result['checker_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    data = json.dumps(result, indent=2) + '\n'
    if args.out:
        args.out.write_text(data)
    print(data, end='')

if __name__ == '__main__':
    main()
