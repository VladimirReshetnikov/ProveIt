#!/usr/bin/env python3
"""Source-invariant-restricted symbolic primitive runtime and engine census.
Extends the inherited literal/unary/list proof rules only by specializing
initial independent primary values to sound affine supersets of certified
entry domains. Unreachable guards are omitted only after independent
inductive-invariant verification. This is not a proof-assistant artifact.
"""
from pathlib import Path
import argparse,json,gzip,hashlib,sys,time,importlib.util
import check_source_invariant as ci

def affine_values(s,site,positive,domain,k):
    op,arg=site[1:];out=[]
    for j,m in enumerate(domain):
        if op=='CD'and j==arg:
            m=m&~1 if positive else m&1
            assert m
        lo=(m&-m).bit_length()-1
        if m==(1<<lo)and lo<k:out.append(s.num(lo))
        else:out.append(s.add(s.num(lo),s.var(2+j)))
    return out

def restricted_case(s,table,lemmas,site,positive,values,append=1,keep_trace=False):
    pc,op,arg=site;physical=[None]*9
    for i,j in enumerate(s.r.PHY):physical[j]=values[i]
    result=physical.copy();overflow=0;delta=0;extra=None
    if op=='CI':result[s.r.PHY[arg]]=s.add(result[s.r.PHY[arg]],s.num(1));successor,overflow=s.r.inc(pc);extra=append
    elif op=='CD'and positive:result[s.r.PHY[arg]]=s.minus1(result[s.r.PHY[arg]]);successor,overflow=s.r.inc(pc);delta=1
    elif op in('CD','CB'):successor,overflow=s.r.inc(s.r.strip(pc,'0',arg if op=='CB'else 1))
    elif op=='CC':successor=s.r.strip(pc,'1',arg)
    elif op=='CH':successor=''
    else:raise AssertionError(site)
    state=s.State(96,[s.bit(1),s.BLANK],[s.bit(int(b))for b in pc]+[s.run(0,s.add(s.var(1),s.num(64-len(pc)))),s.bit(1)]+s.file_bits(physical))
    target=s.State(96,[s.bit(1),s.BLANK],[s.bit(int(b))for b in successor]+[s.run(0,s.add(s.var(1),s.num(64+delta+overflow-len(successor)))),s.bit(1)]+s.file_bits(result,extra))
    target_key=target.key();clock=s.ZERO;motion=s.ZERO;trace=[];rows=set();engine_rows=set();kinds={};after_leaf=False;list_keys=set()
    for count in range(4000):
        key=state.key()
        if count and((op=='CH'and state.q==254)or(op!='CH'and key==target_key)):
            assert s.nonnegative(clock)and clock[0]>0,('No positive progress',clock)
            if op!='CH':assert motion==s.num(-overflow),('Wrong head displacement',motion,overflow)
            assert after_leaf,('leaf transition was not identified',site)
            return {'symbolic_steps':count,'duration':clock,'motion':motion,'rows':rows,'engine_rows':engine_rows,'list_keys':list_keys,'kinds':kinds,'trace':trace}
        entry_now=not after_leaf and motion==s.num(len(pc)-1)
        old_motion=motion
        clock,motion,event=state.step(table,lemmas,clock,motion)
        kinds[event[0]]=kinds.get(event[0],0)+1
        if event[0]!='list':
            row=event[1][:2];rows.add(row)
            if after_leaf:engine_rows.add(row)
        else:list_keys.add(tuple(event[1]))
        # A unary proof may pass the last path bit in one batch. Conservatively
        # retain its row as an engine row when the batching crosses this point.
        crossed=(not after_leaf and all(x==0 for x in old_motion[1:])and all(x==0 for x in motion[1:])and old_motion[0]<len(pc)-1 and motion[0]>=len(pc))
        if crossed:
            assert event[0]!='list';engine_rows.add(event[1][:2])
        after_leaf |= entry_now or crossed
        if keep_trace:trace.append(event)
    raise AssertionError(('Symbolic proof did not close',site,positive,state.key(),target_key))

def exact_decoder(table, mapping, pc):
    original={-1:1, **{j:int(x) for j,x in enumerate(pc)}}
    tape=original.copy();q=84;h=0;prefix=[]
    for _ in range(1000):
        if h==len(pc)-1:break
        assert h in tape, ('Decoder left literal path',pc,q,h)
        read=tape[h];w,d,z=table[q,read]
        prefix.append((mapping[q],read,w,d,mapping[z]))
        tape[h]=w;h+=d;q=z
    else:raise AssertionError(('Decoder did not reach leaf',pc))
    assert tape==original, ('Decoder did not restore path',pc)
    return prefix,(mapping[q],int(pc[-1]))

def strip_all_decodes(trace,prefix,leafrow,dispatch):
    rows=set();j=0;decodes=0
    while j<len(trace):
        e=trace[j]
        if e[0]!='list' and e[1][0]==dispatch:
            assert j+len(prefix)<len(trace), ('Truncated decoder trace',j)
            assert all(trace[j+k][0]=='literal' and tuple(trace[j+k][1])==r
                       for k,r in enumerate(prefix)), ('Repeated literal decoder differs',j)
            assert trace[j+len(prefix)][0]=='literal' and tuple(trace[j+len(prefix)][1][:2])==leafrow, ('Leaf entry differs',j)
            j+=len(prefix)+1;decodes+=1
        else:
            if e[0]!='list':rows.add(tuple(e[1][:2]))
            j+=1
    assert decodes>=1, 'No source decode was certified'
    return rows,decodes

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--invariant',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--table',type=Path);ap.add_argument('--source',type=Path);ap.add_argument('--limit-sites',type=int);ap.add_argument('--trace',action='store_true');a=ap.parse_args()
    assert __debug__ and not sys.flags.optimize
    c=a.candidate;source=a.source or c/'sites215.json';tablepath=a.table or c/'k215.native.tm';runtime=c/'code/runtime-inputs/runtime';mapping=c/'code/runtime-inputs/inputs/legacy_mapping.json'
    invcheck=ci.verify(source,a.invariant);cert=json.loads(gzip.decompress(a.invariant.read_bytes()));S=cert['states'];k=cert['result']['bucket_limit'];sites=json.loads(source.read_text())
    sys.path.insert(0,str(runtime));import symbolic_runtime as s
    m={int(q):z for q,z in json.loads(mapping.read_text()).items()};T=s.r.table(tablepath);states={q for q,b in T}
    for q in states|{254}:
        if q not in m:m[q]=q+1000
    assert len({m[q]for q in states|{254}})==len(states)+1;rev={z:q for q,z in m.items()};L={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()}
    lemmas,blocks=s.prove_blocks(L);expected=sum((int(bool(st[site[2]]&1))+int(bool(st[site[2]]&~1)))if site[1]=='CD'else 1 for site,st in zip(sites,S)if st is not None)
    a.out.mkdir(parents=True,exist_ok=False);(a.out/'invariant-review.json').write_text(json.dumps(invcheck,indent=2)+'\n');begin=time.monotonic();allrows=set();engine=set();proofcount=steps=0;usedlists=set();minimum=None;fail=[]
    with gzip.open(a.out/'cases.jsonl.gz','wt')as records:
        for i,(site,st)in enumerate(zip(sites,S)):
            if a.limit_sites is not None and i>=a.limit_sites:break
            if st is None:continue
            prefix,leafrow=exact_decoder(T,m,site[0])
            guards=(False,True)if site[1]=='CD'else(False,)
            for positive in guards:
                if site[1]=='CD'and not(st[site[2]]&(~1 if positive else 1)):continue
                try:
                    values=affine_values(s,site,positive,st,k);ans=restricted_case(s,L,lemmas,site,positive,values,keep_trace=True)
                    ans['engine_rows'],ans['decoder_repetitions']=strip_all_decodes(ans['trace'],prefix,leafrow,m[84])
                    allrows.update((rev[q],b)for q,b in ans['rows']);engine.update((rev[q],b)for q,b in ans['engine_rows']);usedlists.update(ans['list_keys']);proofcount+=1;steps+=ans['symbolic_steps'];minimum=ans['duration'][0]if minimum is None else min(minimum,ans['duration'][0])
                    for key in('rows','engine_rows','list_keys'):ans[key]=sorted(ans[key])
                    if not a.trace:ans.pop('trace')
                    records.write(json.dumps({'site_index':i,'positive':positive,'domain':st,'affine_values':values,**ans},separators=(',',':'))+'\n')
                except Exception as e:
                    fail.append({'site_index':i,'site':site,'positive':positive,'reason':repr(e)});print('FAIL',fail[-1],flush=True);break
            if fail:break
            if(i+1)%1000==0:print('PROGRESS',i+1,proofcount,round(time.monotonic()-begin,3),flush=True)
    for b in blocks:
        key=(b['entry'],b['direction'],b['before'],b['direction']==-1)
        if True: # Include every proved generic block schema.
            for event in b['trace']:
                if event[0]!='list':engine.add((rev[event[1][0]],event[1][1]));allrows.add((rev[event[1][0]],event[1][1]))
    digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    report={'status':'RESTRICTED_RUNTIME_PASS'if not fail and proofcount==expected else'NOT_COMPLETE','expected_cases':expected,'proved_cases':proofcount,'failures':fail,'symbolic_rules':steps,'minimum_constant_duration':minimum,'seconds':time.monotonic()-begin,'working_states':len(states),'table_sha256':digest(tablepath),'source_sha256':digest(source),'invariant_sha256':digest(a.invariant),'checker_sha256':digest(Path(__file__)),'all_rows':sorted(allrows),'engine_rows':sorted(engine),'all_rows_count':len(allrows),'engine_rows_count':len(engine),'blocks':blocks,'used_list_schemas':sorted(usedlists),'scope':'All finite source executions from the certified initial domains; exact singleton register specialization and affine interval supersets elsewhere, plus arbitrary natural gap and nonempty arbitrary spare list. Engine census excludes every exact repeated dispatcher-to-leaf literal trace after equality verification and includes all four proved generic list schemas. Ordinary mathematical induction checker, not kernel certification.'}
    (a.out/'runtime.json').write_text(json.dumps(report,indent=2)+'\n');(a.out/'engine_rows.json').write_text(json.dumps({'rows':sorted(engine),'source_sha256':report['source_sha256'],'scope':report['scope']},indent=2)+'\n');print(json.dumps({q:v for q,v in report.items()if q not in('blocks','all_rows','engine_rows')},indent=2),flush=True)
if __name__=='__main__':main()
