#!/usr/bin/env python3
"""Independent exact CFG check for two MP splices in incoming transfer201.
Only the source correspondence is checked; no binary-machine claim.
"""
from pathlib import Path
import argparse,hashlib,json
from check_source_invariant import graph
PINS={'parent':'05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922','cache_return':'2cf1207ae030f6d1daeb676b4f9412105f8324e5089529ea0b2b7034c7bc38ff','omit_zero':'2ec05ced11603aa1cac306d5c30460c446bf8b7480e22216929d7239a12970bb'}
def verify(parent,changed,mode):
 raw=Path(parent).read_bytes();newraw=Path(changed).read_bytes();assert hashlib.sha256(raw).hexdigest()==PINS['parent'];assert hashlib.sha256(newraw).hexdigest()==PINS[mode];old=json.loads(raw);new=json.loads(newraw);G=graph(old);H=graph(new);lo,hi=4670,4696;length=3 if mode=='cache_return' else 7;delta=26-length
 def phi(i):
  assert i<=lo or i>=hi,('external edge enters removed macro interior',i)
  return i if i<=lo else i-delta
 count=0
 for i in range(len(old)):
  if lo<=i<hi:continue
  j=phi(i);assert old[i][1:]==new[j][1:];assert H[j][:2]==G[i][:2];assert H[j][2]==[phi(k)for k in G[i][2]],('changed outside edge',i,j);count+=len(G[i][2])
 end=hi-delta
 if mode=='cache_return':
  expected=[('CD',4,[end,lo+1]),('CI',5,[lo+2]),('CC',2,[lo])]
 else:
  expected=[('CD',4,[lo+4,lo+1]),('CI',1,[lo+2]),('CI',6,[lo+3]),('CC',3,[lo]),('CD',6,[end,lo+5]),('CI',4,[lo+6]),('CC',2,[lo+4])]
 assert H[lo:end]==expected,(H[lo:end],expected)
 assert old[:lo]==new[:lo]
 return {'status':'EXACT_TRANSFER_MP_SPLICE_CFG_PASS','mode':mode,'parent_source_sha256':PINS['parent'],'changed_source_sha256':PINS[mode],'replaced_parent_interval':[lo,hi],'replacement_interval':[lo,end],'parent_sites':len(old),'changed_sites':len(new),'unchanged_prefix_sites':lo,'outside_primitive_edges_checked':count,'local_macro_graph':expected,'scope':'Every primitive and guarded edge outside the changed success macro agrees under the ordinal map. The local macro graph is exact. Arithmetic macro semantics and the ordinary source/command compiler remain separate mathematical premises. The partial-AX initializer at ordinal55 lies in the identical literal prefix.'}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--parent',type=Path,required=True);ap.add_argument('--changed',type=Path,required=True);ap.add_argument('--mode',choices=['cache_return','omit_zero'],required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();r=verify(a.parent,a.changed,a.mode);a.out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
