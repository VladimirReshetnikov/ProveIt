#!/usr/bin/env python3
"""Exhaustive, solver-independent certificate check for literal K215 axioms.
Uses only Python's standard library. Syntax is extracted from the pinned
primitive word; arithmetic correctness of those unchanged macros is inherited.
The checked finite algebra extends recursively to ALL natural formula codes.
"""
import argparse,hashlib,itertools,json
from pathlib import Path
from check_literal_k215_models import extract,SOURCE_SHA

def check(source,model_path,rho8='a',unbundle=False):
 raw=Path(model_path).read_bytes();m=json.loads(raw);table=m['I'];q=m['Q'];r=m['membership'];e=m['equality'];n=len(table);values=range(n)
 assert n>=2 and len(q)==n and all(len(row)==n for row in table)
 assert all(type(v)is int and 0<=v<n for row in table for v in row)
 assert all(type(v)is int and 0<=v<n for v in q+[r,e])
 assert r==1 and rho8 in ('a','b','c','ab','ac','bc')
 I=lambda a,b:table[a][b]
 assert I(0,0)==0 and q[0]==0
 assert all(I(0,b)!=0 for b in values if b!=0)
 identity=all(I(a,a)==0 for a in values)
 if m.get('identity'):assert identity
 checks=0
 for a,b,c in itertools.product(values,repeat=3):
  aa,bb,cc,uu={'a':(a,b,c,a),'b':(a,b,c,b),'c':(a,b,c,c),'ab':(a,a,b,c),'ac':(a,b,a,c),'bc':(a,b,b,c)}[rho8]
  assert I(I(I(cc,uu),aa),I(I(aa,cc),I(bb,cc)))==0,('rho8',a,b,c)
  checks+=1
 def value(node,env):
  if isinstance(node,str):return 1 if node=='f'else env[node]
  op,x,y=node
  if op=='r':return r
  if op=='e':return e
  if op=='q':return q[value(y,env)]
  assert op=='i';return I(value(x,env),value(y,env))
 formulas=extract(source)
 if unbundle:
  bundled=formulas.pop();f=bundled['formula'];assert f[0]=='i'and f[2]=='f'and f[1][0]=='i'
  v,h=f[1][1:];formulas.extend([{'interval':[2643,2885],'formula':v},{'interval':[2885,4556],'formula':['i',h,'f']}])
 row_checks=[]
 for entry in formulas:
  count=0
  for a,b,c in itertools.product(values,repeat=3):
   assert value(entry['formula'],dict(zip('abc',(a,b,c))))==0,('literal_row',entry['interval'],a,b,c)
   count+=1
  row_checks.append({'source_interval':entry['interval'],'assignments':count,'all_designated':True})
 return {'status':'LITERAL_K215_FINITE_ALGEBRA_CERTIFICATE_PASS','source_sha256':SOURCE_SHA,'model_sha256':hashlib.sha256(raw).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'values':list(values),'designated_value':0,'falsum_value':1,'implication':table,'universal_quantifier':q,'membership_atom':r,'equality_atom':e,'identity_schema_holds':identity,'rho8_identification':{'a':'U=A','b':'U=B','c':'U=C','ab':'A=B','ac':'A=C','bc':'B=C'}[rho8],'rho8_assignments':checks,'unbundled_theory':unbundle,'literal_row_checks':row_checks,'zero_alias_compatible':True,'modus_ponens_preserves_designation':True,'generalization_preserves_designation':True,'ordinary_proof_consequence':'Recursive interpretation on every natural code makes all axioms designated and MP/GEN preserve designation; the code1 is not designated. Nonderivability of1 is therefore provable arithmetically, and hence in ZFC, for this weakened calculus. This is not a binary machine proof.','source_scope':'Exact pinned K215 primitive words are decomposed into inherited parameter, PUSH, implication, relation, quantifier, and equality macros. Each ungated theory instance is checked, a stronger condition than checking only the legal gate C!=A,B.'}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--model',type=Path,required=True);ap.add_argument('--rho8',choices=['a','b','c','ab','ac','bc'],default='a');ap.add_argument('--unbundle',action='store_true');ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();d=check(a.source,a.model,a.rho8,a.unbundle);a.out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
if __name__=='__main__':main()
