# A two-field AX calculus with the K/S/Peirce basis

This is a proved mathematical reformulation and a source-pricing experiment,
not an accepted smaller binary Turing machine. It changes the command codec
and the logical basis together; no formula parser or decoding guard is added.

Let `I(a,b)=4P(a,b)` with the inherited Cantor pairing, and retain truth 0,
falsity 1, MP, GEN, the seven first-order rows, and the gated set-theoretic
bundle. Replace dominated rho8 by these three axiom schemas:

- `K(A,B)=I(A,I(B,A))`;
- `S(A,B,C)=I(I(A,I(B,C)),I(I(A,B),I(A,C)))`;
- `Peirce(A,B)=I(I(I(A,B),A),A)`.

The three schemas use only A,B,C. Consequently AX can set `U=A=D` and omit
the additive A-field entirely. Its two wire fields are `[c+3,y]`, with
`B=H+y` and `C=c`. It constructs `Q_D(old H)` before adding y, emits the
three propositional rows, and then emits the seven unchanged first-order
rows and the unchanged gated bundle. At a command boundary it clears D,H
and pushes twelve entries: the seven retained rows, three propositional
rows (in reverse emission order), `Q_D(old H)`, and old T. The other command
equations are unchanged.

## Equality of numerical theorem sets

The inherited full rho8 calculus derives K, S and Peirce by its finite
Lukasiewicz derivations. Therefore every new axiom is already an inherited
numerical theorem. Conversely K, S and Peirce are the standard complete
Hilbert basis for classical implication, so they derive the rho8 formula as
a finite schematic implication proof. Instantiating that finite proof using
the *numerical* operation I gives the exact old rho8 number for every natural
assignment. This reasoning only evaluates fixed finite proof trees; it does
not require native theory axioms to be closed under arbitrary substitutions,
nor does it require I to be injective. In particular `I(0,0)=0` is included.
Replacing axiom leaves in derivations gives equality of the two numerical
theorem sets. Thus the inherited ZFC refutation calibration transfers.

## Explicit strong block compiler

Write an AX command as `AX(c;y)`. Let m=12. From `(t,w,0,0)`, put

`Discard = MP(1); AX(1;0); NIP^12`.

The MP deliberately fails because `I(t,1)>0`; AX has A=c=1 and hence top 0.
All eleven new generated entries are implication or quantifier codes, so
none is 1. Its saved old top is 0. Twelve NIPs therefore return `(0,w,0,0)`.
As before, `J(0)` is empty and `J(u>0)=MP(u)`, entered with top/cache/counter
zero, loads the counter without changing the underlying stack.

For any AX stack row with desired parameters A,B,C, use

`Discard; J(A); AX(C;B); NIP^j; DROP; NIP^(13-j)`,

where j is that row's position among the eleven generated stack entries.
This returns the desired theorem, original stack and zero counter/cache,
unless it halts earlier. Independent parameter permutations of a universal
row merely require applying the inverse permutation when choosing A,B,C.
For the permitted bundle use

`Discard; J(A); AX(C;B); NIP^12`.

Given a strong block for X, generalization by i uses

`B_X; DROP; J(i); NIP; AX(i;0); NIP^11; DROP; NIP^2`.

The selected eleventh entry is exactly `Q_i(X)`, because AX reads incoming H
before adding y. The equality gate A=c makes its top 0, and the two final pops
remove that zero and the saved old top, recovering the original stack.

Given strong blocks for X and `I(X,Y)`, use

`B_X; DROP; B_I; NIP; DROP; NIP; MP(Y); AX(Y;0); NIP^12; DROP; NIP^2`.

The premises are placed in top and cache. Successful MP returns
`(Y,P(0,w),Y,0)`. The reset AX has A=c=Y. Twelve NIPs recover Y in the cache
and the stack `P(0,w)`; DROP and two pops return `(Y,w,0,0)`, or halt early
if a tested cache is 1. These cases and truth give an induction on finite
numerical derivations.

Packing uses the same right-folded Cantor convention, but AX has two fields.
For a fixed compiled refutation tail R, the initial command `AX(0;Y)` resets
counter/cache, and its first-candidate number is

`N_Y=P(3,P(Y,R)) >= Y`.

All positive candidate tails still drain because every field reader returns
a remainder no greater than its input and the command loop consumes its
outer successor. Hence the successful candidate family is cofinal beyond
every natural starting cutoff. Soundness on arbitrary junk candidates is
the usual theorem-stack invariant: AX emits numerical axioms and a genuine
generalization, and all other commands preserve theorem-bearing slots.

## Source experiment and limitation

`build_ksp.py` replaces the closed source interval [107,479) in the pinned
K215 tree. It retains the exact inherited parameter-push, implication and
B-field-reader macros and removes the A-field reader. The replacements are
priced under 1,296 choices: six row orders and six independent permutations
of A,B,C for each row. A deterministic dynamic-programming parser shares
available old source subtrees before full source DAG counting.

The best source found has 207 distinct subtrees and 5,054 primitive leaves,
compared with the accepted K215 source's 202 and 4,751. Its longest zero run
is 10. Thus this limited source family does not improve the current binary
construction. No lower bound is asserted: the experiment does not exhaust
other axiom bases, source associations, or physical allocations. The source
files and their exact survey receipt are in `ksp-source/`.
