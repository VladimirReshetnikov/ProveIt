# Semantic command variants for the K215 source

This note is ordinary mathematics, conditional only on the inherited numerical-calculus calibration and the separately required exact source/binary implementation. It does not claim a 214-state machine.

## Baseline

Let P(a,b)=(a+b)(a+b+1)/2+b and I(a,b)=4P(a,b). Truth is 0 and falsum is 1. At a command boundary write the retained tuple as (t,w,d,h): top formula, paired theorem stack, additive counter, cache. A stack written `x::w` means P(x,w), retaining P(0,0)=0. The initial decoded tuple has t=w=d=h=0. The actual root also carries enumerator cutoff4 and scratch/selector zero.

The calibrated K215 command ordering is NIP0 / DROP1 / MP2 / AX(c+3). AX has fields [c+3,y,x], U=d, A=d+x, B=h+y, C=c. It pushes seven retained logical rows, dominated rho8, Q_U(old h), and old t; the gated bundle is the new t. AX clears d,h. The bundle is 0 whenever c=A or c=B. Thus AX(c;0,0), when d=c, outputs top0 and pushes nine generated entries followed by old t. The generated entries are implication or quantifier codes and never1. Popping ten times recovers the original stack and caches old t.

The source success suffix is precisely path `11010010111`, ordinal interval [4671,4697), containing26 leaves. Source paths use the pinned K215 `sites215.json` at upstream commit c8029f50d324910a36694c39a1e62f5720c36f4c. The original suffix is PUSH(top); COPY(d,top).

## Cache-return MP

Replace the suffix by `(CD4,(CI5,CC2))`, which transfers all d into cache. The command becomes, for B=d+x:

- if h=I(t,B), return (0,w,0,B);
- otherwise, return (0,w,B,0).

This is exactly the existing cache-return convention applied to the command-local-reader K215 source. Soundness follows because on success B is a theorem by numerical MP. Failure retains only truth0 and existing theorem stack; d is an unrestricted numerical counter.

For completeness, use the strong block property: a derived code X has a finite command block which from every (t,w,0,0) either halts early or returns (X,w,0,0). These claims concern arbitrary natural t,w; the soundness theorem separately assumes theorem-safe values.

Discard = MP(1); AX(1;0,0); NIP^10. Its MP fails since I(t,1)>0 while h=0, giving (0,w,1,0). AX's equality gate gives top0, and ten pops restore (0,w,0,0). J(0) is empty; J(i>0)=MP(i) when t=h=d=0. It gives (0,w,i,0), because I(0,i)>0 for i>0. Skipping MP(0) avoids its real success at the numerical alias I(0,0)=0.

All baseline leaf and GEN blocks still apply, because they use MP only in these deliberately failing positions. For MP from X and I(X,Y), let B_X and B_I be the inductively available blocks. The unchanged premise arrangement

    B_X; DROP; B_I; NIP; DROP; NIP

produces (X,w,0,I(X,Y)), or halts early. MP(Y) now produces (0,w,0,Y). Append only DROP;NIP. DROP gives (Y,0::w,0,Y); NIP either halts for Y=1 or pops0 and returns (Y,w,0,0). This includes Y=0 and the zero pairing alias. No reset AX or extra filler removal is needed. Thus finite induction yields every native theorem.

Appending DROP;NIP;NIP to B_1 halts. Prepend START_Y=AX(0;1,Y), which clears counter/cache from every incoming retained tuple. With R the continuation code, the candidate is P(3,P(Y,P(1,R))) >= Y. Choosing Y beyond any cutoff proves completeness of the changed enumerator. Candidate draining and source arithmetic termination are unchanged except for a shorter terminating transfer loop.

### Physical warning

The old standalone K217 edit164/1 ->1R130 is not valid directly on K215. State164 now has four AX occurrences entered with predecessor marker0 and one MP occurrence with marker1. Its shared1 action currently enters the original26-leaf suffix98. The MP source replacement must not alter the AX occurrences. A new allocation or a second marker selector is required. There is no claim that the emitted source files already implement a valid smaller physical table.

## Omit the successful MP zero push

Replace the same26-leaf suffix by its seven-leaf right child, COPY(d,top). Success becomes (B,w,B,0), and failure stays (0,w,B,0). Soundness holds because the theorem stack remains unchanged. The strong compiler's only changed case is MP.

After successful MP(Y), run AX(Y;0,0);NIP^10;DROP;NIP. AX has c=A=Y, so top0 and stack L::Y::w, where L has nine generated theorem entries. Ten pops give (0,w,0,Y). DROP gives (Y,0::w,0,Y); the final NIP either halts or returns (Y,w,0,0). The baseline compiler used two final NIPs because success had pushed an extra0. This variant needs one. Leaf, GEN, Discard, cofinal padding and soundness arguments are unchanged. The same physical164 warning applies.

## Additional equiconsistency idea: atomic membership as refutation

The sole designated refutation need not be code1. One may instead halt when a derived code is congruent to1 modulo4. Such a code is R(a,b) for a unique natural pair. Under the inherited numerical soundness theorem, a derivation makes the corresponding membership atom true for every variable valuation in every ZFC model. Assign both variables the empty set; that atom is false. Hence existence of any such theorem is inconsistent with Con(ZFC). Conversely 1=R(0,0) is in this class, preserving completeness. This argument uses the ordinary completeness/model theorem inside ZFC, or can be turned into a syntactic refutation translation by universal closure and the empty-set instance. It must inherit the exact raw-code soundness bridge, not just named-syntax truth tables.

A destructive modulo4 scanner can replace NIP's compare-to-one plus cache clearing; afterward the usual pop runs. A tested structured source scanner has7 leaves and the ordinary loop invariant: each back edge subtracts4 from h; residue1 halts; residues0,2,3 reach the pop with h=0. But this source costs208 distinct subtrees, compared to202, so it is not presently a state-count improvement.

More generally, exact full-register simulation can be stronger than necessary for this problem. Replacing a transition by an additional halt is valid if its reachability implies a refutation already exists: consistency excludes the extra halt, and inconsistency permits it to occur before the original halting run. This supports future state folds justified by theorem-bearing register invariants. It does not permit arbitrary unproved unreachable-row assumptions.

## Measured source costs

All counts below refer to literal source trees, not binary working states. The baseline has202 subtrees,4751 primitive occurrences, maximum depth47 and maximum zero-run6. The listed primary splices preserve the latter two numbers.

| Variant | Distinct subtrees | Primitive occurrences |
|---|---:|---:|
| K215 baseline |202|4751|
| Cache-return MP |202|4728|
| Omitted MP zero push |202|4732|
| Copy-only DROP (requires a different compiler) |202|4732|
| Cache-return plus copy-only DROP |202|4709|
| DROP clearing its cache |204|4747|
| MP with only increment-one payload |204|4738|
| Atomic-membership NIP |208|4746|

The COPY-only DROP and increment-only MP ideas were priced as source experiments; this note does not supply their complete command compiler. They are not accepted candidates. Decreasing primitive occurrences by itself does not imply fewer decoder states, especially when the old code is heavily shared inside AX.

## Attribution and limits

The source-language utilities and unchanged arithmetic macros originate in the maintained ProveIt/Mira-Cult/Jeff/Wade lineage, with their upstream notices retained by the parent snapshot. The cache-return convention was already recorded in Source154 / candidate-k217/research/cache-return; omitted-success-push was already recorded in candidate-k218/alternatives/omit-zero. This work identifies their exact K215 splices, proves the command-local compiler adaptations, detects the shared164 conflict, and adds the atomic-membership refutation observation and measured source experiments. No Lean/Rocq build or exact modified binary runtime was completed in this subtask.
