#!/usr/bin/env python3
from pathlib import Path
import json,sys
B=Path('/dev/shm/zfc214-9d0ff4abecf6/repo/Computability/BusyBeaver/Research/ZFC/candidate-k215')
sys.path.insert(0,str(B/'research/composition-allocation'));import source_splice as sp
rows=json.loads((B/'sites215.json').read_text());root=sp.parse(rows);word=[tuple(r[1:])for r in rows]
def get(a,b):return sp.serial(sp.closed_forest(root,a,b))
def seq(n):return[tuple(r[1:])for r in sp.sites(n)]
push=get(26,45);imp=get(173,200)
M={'a':get(26,52),'b':get(52,78),'c':get(107,133),'f':(push,('CI',1)),'i':imp,'r':(imp,('CI',1)),'q':(imp,(('CI',1),('CI',1))),'e':(imp,sp.serial([('CI',1)]*3))}
W={k:seq(v)for k,v in M.items()};keys=sorted(W,key=lambda k:-len(W[k]));tokens=[];p=2643
while p<4556:
 ks=[k for k in keys if word[p:p+len(W[k])]==W[k]]
 assert ks,(p,word[p:p+20])
 k=ks[0];tokens.append((k,p,p+len(W[k])));p+=len(W[k])
assert p==4556
stack=[{'kind':'old','start':2643,'end':2643}]
for k,a,b in tokens:
 if k in'abcf':stack.append({'kind':k,'start':a,'end':b})
 else:
  right=stack.pop();left=stack.pop();stack.append({'kind':k,'left':left,'right':right,'opstart':a,'start':left['start'],'end':b})
assert len(stack)==2, len(stack)
def short(n):
 if 'left'not in n:return n['kind']
 return n['kind']+'('+short(n['left'])+','+short(n['right'])+')'
def and_(n):
 assert n['kind']=='i'and n['right']['kind']=='f'
 z=n['left'];assert z['kind']=='i';a=z['left'];nb=z['right'];assert nb['kind']=='i'and nb['right']['kind']=='f';b=nb['left']
 span=(nb['right']['start'],n['end']);assert span[1]-span[0]==121
 get(*span)
 return a,b,span
bundle=stack[-1];print('FULL',short(bundle));cg,vv,s0=and_(bundle);c,g,s1=and_(cg);vr,ve,s2=and_(vv)
print('tokens',len(tokens),'AND intervals',s0,s1,s2)
print('components',[(n['start'],n['end'],short(n))for n in(c,g,vr,ve)])
(Path(__file__).parent/'bundle-structure.json').write_text(json.dumps({'tokens':tokens,'component_intervals':[[n['start'],n['end']]for n in(c,g,vr,ve)],'conjunction_intervals':[s1,s2,s0],'formula':short(bundle)},indent=2)+'\n')
