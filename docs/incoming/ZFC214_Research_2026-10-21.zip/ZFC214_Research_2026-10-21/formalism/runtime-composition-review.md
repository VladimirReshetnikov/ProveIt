# Review of source/runtime composition and contextual sharing

## Scope

This review concerns the unchanged K215 source, SHA-256
`17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba`,
and the requirements for accepting a newly allocated binary transition table.
It does not certify an allocator output merely from its prefix map. In
particular, the provisional 208-state multi-role allocation and the first
214-state startup-preserving allocation are not accepted by this review.

## Mathematical composition criterion

Let a canonical machine frame consist of the complete zero exterior, its
left marker, the finite source address, zero padding, a header, the nine
unary primary blocks, and a nonempty finite spare-block list. The current
runtime representation uses the fixed physical permutation
`(6,2,0,4,3,7,8,5,1)` of the logical registers
`N,T,W,A,D,H,X,Y,L`. The additional padding is an arbitrary natural.

For each source instruction and each decrement guard, the required binary
contract must hold for every natural assignment to the remaining primary
values, every natural gap, and every nonempty finite spare list. A nonhalting
contract must return the entire canonical frame for the exact source
successor and specified register effect. A halting contract must enter the
distinguished state 254. Each contract must take a strictly positive finite
number of binary steps.

Once all 6,176 contracts hold for the actual candidate table, induction on
source executions gives the binary/source simulation. Source successors may
be nonleaf address prefixes; their trailing zero completion names the first
leaf in that subtree. The two source CFG resolvers establish that no stray
one lies beyond that leaf, so the physical word already represents the next
canonical leaf frame. The gap update is nonnegative, all resulting primary
values are natural, and the spare list remains nonempty.

A finite source halt yields a finite binary halt by concatenation of the
primitive blocks. Conversely, an infinite nonhalting source execution gives
an infinite chain of nonhalting binary blocks. Strictly positive durations
make their partial sums unbounded, so a binary halt cannot occur between
blocks or beyond all of them. An intermediate halt inside a nonhalting
contract is excluded by the actual transition proof: state 254 has no row,
so such a trace could not proceed to its prescribed endpoint.

The blank-start calculation is a separate premise. It must reach dispatcher
84 with a canonical root frame whose formula-bearing registers T,W,H are
zero, at some finite candidate cutoff. The inherited all-natural source
calibration permits arbitrary natural counter and scratch registers at this
clean formula root. An exact finite startup trace suffices. Protecting every
row used by a known startup trace is also sufficient, provided that the
candidate literally retains those rows and working states.

Since the source is unchanged, its arithmetic command semantics, cofinal
refutation compiler, and the pinned numerical-calculus/ZFC calibration are
inherited without a new formalism translation. These premises yield the
ordinary ZFC-formalizable equivalence between blank halting and a ZFC
refutation. This review claims neither a fresh Lean/Rocq endpoint nor an
internal PA proof.

## Review of the executable induction rules

The inherited symbolic checker uses three rules. A literal step applies an
actual table row when the represented run has a positive constant lower
bound. A unary step applies a direction-preserving self-loop to an arbitrary
natural number of identical cells; ordinary induction proves the result,
including the zero-length case. A list step uses a separately derived
one-block theorem with opaque left and right contexts, then induction on a
finite list of blocks. The four list schemas are rederived from the supplied
candidate table, not assumed from state names.

Affine run lengths have nonnegative coefficients. They therefore denote
natural lengths under every natural valuation. Adjacent runs may be merged,
zero-length runs deleted, and finite zero tails absorbed into a zero
exterior. The only nontrivial list normalization is `C(A)1 = 1B(A)` and its
reversal, with `B(v)=0 1^(v+1)` and `C(v)=1 0 1^v`; the empty and one-element
identities extend by induction over list concatenation. All these rules
preserve whole tapes. The finite search limits bound certificate
construction, not the quantified register values or represented time.

## The decoder relation may be many-to-many

A physical state need not denote a unique source subtree. Its interpretation
may depend on the already known source prefix. For an internal source edge,
a finite table trace may move left through that prefix and then return at
the first cell of the child, provided it restores every modified cell and
does not inspect unknown right context. Such a proof is valid for arbitrary
gap and data. Multiple source nodes can therefore use an immutable physical
state when every occurrence has a proved contextual interpretation.

This observation is a valid synthesis improvement. It does not by itself
prove the resulting complete machine. The allocator, its finite catalogs,
and its optimization status remain discovery artifacts. A fresh exact-table
runtime proof and blank-start check remove any reliance on their completeness
or on the optimization solver's correctness.

## A rejected leaf alias and the missing phase condition

The first startup-preserving multi-role proposal changed only native row
`107/1` from `1 R 126` to `1 R 13`, and removed state 126. The candidate hash
was `d9538822a27cb4796c1082a6dd4f10a40f2fbf7bca66a814a0011ec9e7b637fc`.
The original state 126 represents the source pair `(CI4,CC2)` at 29 source
occurrences. All their incoming prefix bits are 1.

For a CI4 leaf with two zero cells immediately to its right, the old trace is

`126 -> 71 -> 91 -> 82 -> 49 -> 35`

in five steps. The proposed trace is

`13 -> 91 -> 81 -> 111 -> 128 -> 21 -> 24 -> 35`

in seven steps. Both reach the same head and complete tape. For the CC2 leaf,
`126 -> 16` and `13 -> 31 -> 47 -> 16` likewise synchronize with a two-step
delay. These are valid local calculations under their stated contexts.

However, a primitive can decode its address more than once while its padding
is temporarily transformed. At source site 50 (CI4), the exact baseline
symbolic trace reaches state 126 with these three right-hand contexts:

1. `0^(48+gap) 1 ...`;
2. `0 1^(48+gap) 0 ...`;
3. `00 1^(47+gap) 0 ...`.

Thus the cells immediately after the leaf are not always zero. The original
leaf-alias catalog checked only the initial phase, and its local result did
not justify replacement during all repeated decodes. The universal candidate
runtime failed, and a concrete all-zero-register counterexample was reported
by the physical reviewer. This is an invalid source implementation, not a
new accepted consistency machine.

A repaired leaf catalog must cover all actual reentry phases, or prove a
stronger synchronization statement independent of the right context. One
safe finite method is to enumerate a bounded known extension and reject every
trace that reads beyond it before synchronization. Final acceptance should
still use the fresh full runtime and startup gates.
