#!/usr/bin/env python3
"""Fast portable proof-artifact replay. Python standard library only.
Run: python3 -B replay_formalism_fast.py --source PATH/sites215.json --out OUTDIR
No optimizer, SciPy, runtime interpreter, or repository checkout is imported.
"""
import argparse,hashlib,json,subprocess,sys,time
from pathlib import Path
import check_source_invariant as inv
import check_equal_rho8_model as old
from check_literal_finite_certificate import check

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();p=Path(__file__).resolve().parent;a.out.mkdir(parents=True,exist_ok=True);t=time.monotonic();results=[]
 def save(name,d):
  (a.out/name).write_text(json.dumps(d,indent=2)+'\n');results.append({'receipt':name,'status':d.get('status'),'sha256':hashlib.sha256((a.out/name).read_bytes()).hexdigest()})
 save('broad-source-invariant.json',inv.verify(a.source,p/'k215-invariant-broad/source_invariant.json.gz',[511,1,1,511,511,1,511,511,511]))
 save('scratch-zero-source-invariant.json',inv.verify(a.source,p/'k215-invariant-initial-scratch-zero/source_invariant.json.gz',[511,1,1,1,1,1,1,1,1]))
 save('code254-three-valued.json',old.check(False));save('code254-identity-five-valued.json',old.check(True))
 jobs=[('a','literal-diagonal-rho8-three-valued.json','literal-diagonal-three-valued.json'),('a','literal-identity-rho8-five-valued.json','literal-U-A-identity.json'),('b','literal-rho8-b-four-valued.json','literal-U-B-identity.json'),('c','literal-rho8-b-four-valued.json','literal-U-C-identity.json'),('ab','literal-rho8-b-four-valued.json','literal-A-B-identity.json'),('bc','literal-rho8-b-four-valued.json','literal-B-C-identity.json'),('ac','literal-rho8-ac-5-valued.json','literal-A-C-identity.json')]
 for rho,model,out in jobs:save(out,check(a.source,p/model,rho))
 out=a.out/'coalescing-witnesses.json';subprocess.run([sys.executable,'-B',str(p/'check_coalescing_witnesses.py'),'--source',str(a.source),'--witnesses',str(p/'sum-coalescing-witnesses.json'),str(p/'sum-coalescing-N-L-witnesses.json'),'--out',str(out)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);results.append({'receipt':out.name,'status':json.loads(out.read_text())['status'],'sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
 r={'status':'FORMALISM_FAST_REPLAY_PASS','source_sha256':hashlib.sha256(a.source.read_bytes()).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'receipts':results,'seconds':time.monotonic()-t,'scope':'Two all-natural inductive source invariants; nine positive finite-algebra checks (old Code254 distinguished from literal K215); finite concrete coalescing witnesses. Not a new binary-machine runtime or exact-table consistency proof.'};(a.out/'summary.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
