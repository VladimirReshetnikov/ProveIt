#!/usr/bin/env python3
"""Extract literal K215 AX row syntax by exact primitive macro word matching.
Then evaluate finite truth algebras against the actual retained rows/bundle.
The arithmetic meaning of each extracted macro is inherited, not proved by
this matcher. No changed binary table or source implementation is asserted.
"""
import argparse,hashlib,itertools,json
from pathlib import Path
import check_equal_rho8_model as models
SOURCE_SHA='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
INTERVALS=[(479,888),(888,1171),(1171,1467),(1467,1766),(1766,2062),(2062,2412),(2412,2643),(2643,4556)]

def extract(source):
 raw=Path(source).read_bytes();assert hashlib.sha256(raw).hexdigest()==SOURCE_SHA
 rows=json.loads(raw);word=[tuple(r[1:])for r in rows]
 push=word[26:45];imp=word[173:200]
 macros={'a':word[26:52],'b':word[52:78],'c':word[107:133],'f':push+[('CI',1)],'i':imp,'r':imp+[('CI',1)],'q':imp+[('CI',1)]*2,'e':imp+[('CI',1)]*3}
 keys=sorted(macros,key=lambda k:-len(macros[k]));out=[]
 for lo,hi in INTERVALS:
  p=lo;tokens=[];stack=[]
  while p<hi:
   ks=[k for k in keys if word[p:p+len(macros[k])]==macros[k]];assert ks,(p,word[p:p+20])
   k=ks[0];end=p+len(macros[k]);tokens.append([k,p,end])
   if k in'abcf':stack.append(k)
   else:
    assert len(stack)>=2;right=stack.pop();left=stack.pop();stack.append([k,left,right])
   p=end
  assert p==hi and len(stack)==1,(lo,hi,p,len(stack));out.append({'interval':[lo,hi],'tokens':tokens,'formula':stack[0]})
 return out

def evaluate(rows,identity):
 model=models.check(identity);I=model['implication'];Q=model['universal_quantifier'];r=model['membership_atom'];e=model['equality_atom'];vals=model['values']
 def ev(n,env):
  if isinstance(n,str):return 1 if n=='f'else env[n]
  op,x,y=n
  if op=='r':return r
  if op=='e':return e
  if op=='q':return Q[ev(y,env)]
  assert op=='i';return I[ev(x,env)][ev(y,env)]
 result=[]
 for j,row in enumerate(rows):
  bad=[]
  for vs in itertools.product(vals,repeat=3):
   v=ev(row['formula'],dict(zip('abc',vs)))
   if v!=0:bad.append({'assignment':vs,'value':v})
  result.append({'source_interval':row['interval'],'index':j,'checked':len(vals)**3,'failures':bad})
 return {'identity':identity,'model':model,'literal_row_checks':result,'all_literal_rows_designated':all(not r['failures']for r in result)}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();rows=extract(a.source);report={'status':'LITERAL_K215_AXIOM_ALGEBRA_CHECK','source_sha256':SOURCE_SHA,'macro_intervals':{'parameter_a':[26,52],'parameter_b':[52,78],'parameter_c':[107,133],'push':[26,45],'implication':[173,200]},'rows':rows,'models':[evaluate(rows,False),evaluate(rows,True)],'scope':'Exact primitive-word decomposition with inherited macro semantics, then exhaustive algebraic checks of every actual retained source axiom and gated bundle (checked even without its gate). Restricted rho8, truth, MP and GEN are checked by check_equal_rho8_model.py. No changed binary machine is asserted.'};a.out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'models':[{'identity':x['identity'],'all_literal_rows_designated':x['all_literal_rows_designated'],'failures':[{'index':r['index'],'count':len(r['failures']),'examples':r['failures'][:2]}for r in x['literal_row_checks']if r['failures']]}for x in report['models']]},indent=2))
if __name__=='__main__':main()
