#!/usr/bin/env python3
"""Finite truth-algebra search by one-hot MILP; all positive outputs rechecked.
This is discovery only. Supports the full U=A-restricted calculus and optional
identity/K/S/Peirce schemas. No absence-of-model result is a completeness proof.
"""
import argparse,itertools,json,time
from pathlib import Path
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix

class Model:
 def __init__(self,n):
  self.n=n;self.lb=[];self.ub=[];self.rr=[];self.cc=[];self.vv=[];self.lo=[];self.hi=[];self.cache={};self.tables={}
 def clause(self,terms,lo,hi):
  d={};off=0
  for x,v,a in terms:
   if x[0]=='c':off+=a*(x[1]==v)
   else:
    j=x[1]*self.n+v
    if self.lb[j]==self.ub[j]:off+=a*self.lb[j]
    else:d[j]=d.get(j,0)+a
  if not d:
   assert lo<=off<=hi,(terms,lo,hi,off);return
  k=len(self.lo);self.lo.append(lo-off);self.hi.append(hi-off)
  for j,a in d.items():
   if a:self.rr.append(k);self.cc.append(j);self.vv.append(a)
 def group(self):
  g=('g',len(self.lb)//self.n);self.lb.extend([0.]*self.n);self.ub.extend([1.]*self.n);self.clause([(g,v,1)for v in range(self.n)],1,1);return g
 def fix(self,g,v):
  if g[0]=='c':assert g[1]==v;return
  j=g[1]*self.n
  assert self.ub[j+v]>0
  for k in range(self.n):self.lb[j+k]=self.ub[j+k]=float(k==v)
 def const(self,g):
  if g[0]=='g':
   a=[v for v in range(self.n)if self.ub[g[1]*self.n+v]]
   if len(a)==1:return ('c',a[0])
  return g
 def vals(self,g):
  if g[0]=='c':return[g[1]]
  return [v for v in range(self.n)if self.ub[g[1]*self.n+v]]
 def init_tables(self,identity=False):
  n=self.n;self.I=[[self.group()for b in range(n)]for a in range(n)];self.Q=[self.group()for a in range(n)];self.E=self.group()
  self.fix(self.I[0][0],0);self.fix(self.Q[0],0)
  for b in range(1,n):self.ub[self.I[0][b][1]*n]=0
  if identity:
   for a in range(n):self.fix(self.I[a][a],0)
 def imp(self,x,y):
  x=self.const(x);y=self.const(y)
  if x[0]=='c'and y[0]=='c':return self.I[x[1]][y[1]]
  key=('i',x,y)
  if key in self.cache:return self.cache[key]
  z=self.group();self.cache[key]=z
  for a,b in itertools.product(self.vals(x),self.vals(y)):
   t=self.I[a][b]
   for c in self.vals(t):self.clause([(x,a,1),(y,b,1),(t,c,1),(z,c,-1)],-np.inf,2)
  return z
 def quant(self,x):
  x=self.const(x)
  if x[0]=='c':return self.Q[x[1]]
  key=('q',x)
  if key in self.cache:return self.cache[key]
  z=self.group();self.cache[key]=z
  for a in self.vals(x):
   for c in self.vals(self.Q[a]):self.clause([(x,a,1),(self.Q[a],c,1),(z,c,-1)],-np.inf,1)
  return z

def constrain(m,extra,literal=None,unbundle=False,rho8="a"):
 n=m.n;I=m.imp;Q=m.quant;c=lambda a:('c',a);F=c(1);E=m.E;N=lambda a:I(a,F);A=lambda a,b:N(I(a,N(b)));X=lambda a:N(Q(N(a)));Z=lambda a:m.fix(a,0)
 for a,b,d in itertools.product(map(c,range(n)),repeat=3):
  aa,bb,cc,uu={"a":(a,b,d,a),"b":(a,b,d,b),"c":(a,b,d,d),"ab":(a,a,b,d),"ac":(a,b,a,d),"bc":(a,b,b,d)}[rho8];Z(I(I(I(cc,uu),aa),I(I(aa,cc),I(bb,cc))))
 if literal is None:
  for b,d in itertools.product(map(c,range(n)),repeat=2):Z(I(Q(I(b,d)),I(Q(b),Q(d))))
  for b in map(c,range(n)):Z(I(X(Q(b)),b));Z(I(Q(Q(b)),Q(Q(b))))
  Z(X(E));Z(I(E,I(F,F)));Z(I(E,I(E,E)))
  C=X(A(Q(I(F,A(X(A(Q(I(Q(I(F,F)),F)),F)),Q(I(F,F))))),F))
  for d in map(c,range(n)):
   G=X(A(Q(I(F,Q(I(d,X(A(d,F)))))),Q(I(F,X(d)))))
   Z(A(A(C,G),A(I(F,Q(F)),I(E,Q(E)))))
 else:
  def ev(t,env):
   if isinstance(t,str):return F if t=='f'else env[t]
   op,x,y=t
   if op=='r':return F
   if op=='e':return E
   if op=='q':return Q(ev(y,env))
   assert op=='i';return I(ev(x,env),ev(y,env))
  fs=[r['formula'] for r in literal]
  if unbundle:
   b=fs.pop();assert b[0]=='i'and b[2]=='f'and b[1][0]=='i';v,h=b[1][1:];fs.extend([v,['i',h,'f']])
  for vs in itertools.product(map(c,range(n)),repeat=3):
   env=dict(zip('abc',vs))
   for f in fs:Z(ev(f,env))
 for a,b,d in itertools.product(map(c,range(n)),repeat=3):
  if 'K'in extra:Z(I(a,I(b,a)))
  if 'S'in extra:Z(I(I(a,I(b,d)),I(I(a,b),I(a,d))))
  if 'P'in extra:Z(I(I(I(a,b),a),a))

def verify(t,q,e,identity,extra,literal=None,unbundle=False,rho8="a"):
 n=len(t);I=lambda a,b:t[a][b];Q=lambda a:q[a];N=lambda a:I(a,1);A=lambda a,b:N(I(a,N(b)));X=lambda a:N(Q(N(a)))
 assert I(0,0)==Q(0)==0 and all(I(0,b)!=0 for b in range(1,n))
 if identity:assert all(I(a,a)==0 for a in range(n))
 for a,b,c in itertools.product(range(n),repeat=3):
  aa,bb,cc,uu={"a":(a,b,c,a),"b":(a,b,c,b),"c":(a,b,c,c),"ab":(a,a,b,c),"ac":(a,b,a,c),"bc":(a,b,b,c)}[rho8]
  assert I(I(I(cc,uu),aa),I(I(aa,cc),I(bb,cc)))==0
 if literal is None:
  assert all(I(Q(I(b,c)),I(Q(b),Q(c)))==0 for b,c in itertools.product(range(n),repeat=2))
  assert all(I(X(Q(b)),b)==I(Q(Q(b)),Q(Q(b)))==0 for b in range(n))
  assert X(e)==I(e,I(1,1))==I(e,I(e,e))==0
  C=X(A(Q(I(1,A(X(A(Q(I(Q(I(1,1)),1)),1)),Q(I(1,1))))),1))
  for c in range(n):
   G=X(A(Q(I(1,Q(I(c,X(A(c,1)))))),Q(I(1,X(c)))))
   assert A(A(C,G),A(I(1,Q(1)),I(e,Q(e))))==0
 else:
  def ev(t,env):
   if isinstance(t,str):return 1 if t=='f'else env[t]
   op,x,y=t
   if op=='r':return 1
   if op=='e':return e
   if op=='q':return Q(ev(y,env))
   assert op=='i';return I(ev(x,env),ev(y,env))
  fs=[r['formula']for r in literal]
  if unbundle:
   b=fs.pop();v,h=b[1][1:];fs.extend([v,['i',h,'f']])
  for vs in itertools.product(range(n),repeat=3):
   for f in fs:assert ev(f,dict(zip('abc',vs)))==0
 for a,b,c in itertools.product(range(n),repeat=3):
  if 'K'in extra:assert I(a,I(b,a))==0
  if 'S'in extra:assert I(I(a,I(b,c)),I(I(a,b),I(a,c)))==0
  if 'P'in extra:assert I(I(I(a,b),a),a)==0

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--n',type=int,default=4);ap.add_argument('--rho8',choices=['a','b','c','ab','ac','bc'],default='a');ap.add_argument('--identity',action='store_true');ap.add_argument('--literal-source',type=Path);ap.add_argument('--unbundle',action='store_true');ap.add_argument('--self-falsum',action='store_true');ap.add_argument('--extra',default='');ap.add_argument('--seconds',type=int,default=120);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();m=Model(a.n);m.init_tables(a.identity);
 if a.self_falsum:m.fix(m.I[1][1],0)
 literal=None
 if a.literal_source:
  from check_literal_k215_models import extract
  literal=extract(a.literal_source)
 constrain(m,a.extra,literal,a.unbundle,a.rho8);print('built',len(m.lb),'variables',len(m.lo),'constraints',flush=True)
 mat=coo_matrix((m.vv,(m.rr,m.cc)),shape=(len(m.lo),len(m.lb))).tocsc();ts=time.monotonic();r=milp(np.zeros(len(m.lb)),integrality=np.ones(len(m.lb)),bounds=Bounds(m.lb,m.ub),constraints=LinearConstraint(mat,m.lo,m.hi),options={'time_limit':a.seconds,'mip_rel_gap':0.0});d={'n':a.n,'rho8':a.rho8,'identity':a.identity,'self_falsum':a.self_falsum,'literal_source':str(a.literal_source)if a.literal_source else None,'unbundle':a.unbundle,'extra':a.extra,'status':int(r.status),'message':r.message,'seconds':time.monotonic()-ts,'variables':len(m.lb),'constraints':len(m.lo)}
 if r.x is not None:
  dec=lambda g:int(np.argmax(r.x[g[1]*a.n:(g[1]+1)*a.n]));t=[[dec(g)for g in row]for row in m.I];q=list(map(dec,m.Q));e=dec(m.E);verify(t,q,e,a.identity,a.extra,literal,a.unbundle,a.rho8);
  if a.self_falsum:assert t[1][1]==0
  d.update({'checked_model':True,'I':t,'Q':q,'membership':1,'equality':e})
 a.out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
if __name__=='__main__':main()
