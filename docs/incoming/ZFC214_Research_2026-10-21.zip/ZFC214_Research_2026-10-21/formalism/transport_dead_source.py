#!/usr/bin/env python3
"""Certify arbitrary finite subtree changes confined to unreachable source leaves.
The retained source-path relation must preserve every invariant-feasible edge.
Emits a transported inductive certificate and verifies it independently.
"""
import argparse,gzip,hashlib,json
from pathlib import Path
import check_source_invariant as ci

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--old',type=Path,required=True);ap.add_argument('--new',type=Path,required=True);ap.add_argument('--invariant',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    oldcheck=ci.verify(a.old,a.invariant);blob=a.invariant.read_bytes();cert=json.loads(gzip.decompress(blob)if a.invariant.suffix=='.gz'else blob);S=cert['states'];old=json.loads(a.old.read_text());newraw=a.new.read_bytes();new=json.loads(newraw);lookup={p:i for i,(p,o,x)in enumerate(new)};assert len(lookup)==len(new)
    G0=ci.graph(old);G1=ci.graph(new);mapping={};NS=[None]*len(new)
    for i,st in enumerate(S):
        if st is None:continue
        p,o,x=old[i];assert p in lookup,('reachable path removed',i,p)
        j=lookup[p];assert new[j]==old[i],('reachable instruction changed',i,j)
        mapping[i]=j;NS[j]=st
    assert mapping[0]==0
    checked=0
    for i,j in mapping.items():
        o,x,t0=G0[i];p,y,t1=G1[j];assert(o,x)==(p,y)
        assert len(t0)==len(t1)
        if o=='CD':
            m=S[i][x];bits=[b for b in(0,1)if m&(1 if b==0 else~1)]
        else:bits=range(len(t0))
        for b in bits:
            assert t0[b]in mapping and t1[b]==mapping[t0[b]],('feasible CFG edge changed',i,j,b,t0[b],t1[b]);checked+=1
    zero=[];positive=[]
    for j,st in enumerate(NS):
        if st is None or G1[j][0]!='CD':continue
        m=st[G1[j][1]]
        if m==1:zero.append(j)
        if m&1==0:positive.append(j)
    r={'status':'TRANSPORTED_INDUCTIVE_SOURCE_CLOSURE','source_sha256':hashlib.sha256(newraw).hexdigest(),'seed':cert['result']['seed'],'initial_domains':oldcheck['initial_domains'],'bucket_limit':oldcheck['bucket_limit'],'dead':[j for j,st in enumerate(NS)if st is None],'forced_zero':zero,'forced_positive':positive,'producer':'transport_dead_source.py','parent_certificate_sha256':hashlib.sha256(blob).hexdigest()}
    a.out.mkdir(parents=True,exist_ok=False);cp=a.out/'source_invariant.json.gz';cp.write_bytes(gzip.compress((json.dumps({'result':r,'states':NS},separators=(',',':'))+'\n').encode(),mtime=0));newcheck=ci.verify(a.new,cp)
    report={'status':'DEAD_SOURCE_TRANSPORT_PASS','old_source_sha256':oldcheck['source_sha256'],'new_source_sha256':r['source_sha256'],'old_certificate_sha256':oldcheck['certificate_sha256'],'new_certificate_sha256':newcheck['certificate_sha256'],'retained_reachable_sites':len(mapping),'checked_feasible_edges':checked,'old_dead':oldcheck['dead'],'new_dead_count':len(r['dead']),'root_and_halt_preserved':True,'source_ordinal_map':sorted(mapping.items()),'new_invariant_review':newcheck,'scope':'Identical registers and mapped retained paths give one-step correspondence on every invariant-feasible source edge. New dead leaves are never entered. Exact binary implementation and startup remain separate.'}
    (a.out/'transport.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='source_ordinal_map'},indent=2))
if __name__=='__main__':main()
