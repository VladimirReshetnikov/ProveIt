#!/usr/bin/env python3
"""Run an original research script with its task-local path literals relocated.

The archived source bytes remain unchanged.  Only Python string constants
beginning with the original research directory are transformed in memory.
Use materialize.py first when the selected experiment needs .json.gz catalogs.
"""
import ast,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OLD='/dev/shm/zfc214-9d0ff4abecf6'
class Relocate(ast.NodeTransformer):
    def visit_Constant(self,node):
        if isinstance(node.value,str) and node.value.startswith(OLD):
            return ast.copy_location(ast.Constant(str(ROOT)+node.value[len(OLD):]),node)
        return node
if len(sys.argv)<2:
    raise SystemExit('Usage: python run_research.py relative/script.py [script arguments]')
path=(ROOT/sys.argv[1]).resolve()
if not path.is_relative_to(ROOT) or path.suffix!='.py':raise SystemExit('Expected a Python script inside this packet')
sys.argv=[str(path)]+sys.argv[2:]
sys.path.insert(0,str(path.parent));os.chdir(ROOT)
code=ast.fix_missing_locations(Relocate().visit(ast.parse(path.read_text(),filename=str(path))))
exec(compile(code,str(path),'exec'),{'__name__':'__main__','__file__':str(path),'__package__':None})
