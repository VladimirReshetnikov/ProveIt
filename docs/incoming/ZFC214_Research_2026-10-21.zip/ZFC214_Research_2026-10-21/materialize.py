#!/usr/bin/env python3
"""Inflate exact large research inputs when a synthesis experiment needs them."""
from pathlib import Path
import gzip,hashlib,json
ROOT=Path(__file__).resolve().parent
record=json.loads((ROOT/'compressed-artifacts.json').read_text())
for entry in record:
    dst=ROOT/entry['original'];src=ROOT/entry['compressed']
    if dst.exists():
        assert hashlib.sha256(dst.read_bytes()).hexdigest()==entry['original_sha256'],str(dst)
        continue
    raw=gzip.decompress(src.read_bytes())
    assert len(raw)==entry['original_bytes'] and hashlib.sha256(raw).hexdigest()==entry['original_sha256']
    dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw)
print('Materialized',len(record),'exact research inputs')
