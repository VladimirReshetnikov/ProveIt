# Mixing Does Not Remove Arithmetic

**Optimal Positive Markov Realizations of Diophantine Predicates**  
Research note prepared with ChatGPT, 2 October 2026.

## Main files

`article.pdf` is the complete article; `article.tex` is its self-contained LaTeX
source. The bibliography is embedded in the TeX file.

`code/mixing_compiler.py` compiles a nonzero finite family of rational
polynomials into its minimal joint translation module and then into a strictly
positive, doubly stochastic, commuting and invertible rational Markov alphabet.
One actual accepting state realizes

    acceptance(n) = 1/states + epsilon * q**sum(n) * P(n).

The dimension is translation rank plus one. The lower-bound claim concerns the
exact centered scalar series, not merely its natural zero set.

`code/build_examples.py` generates all fourteen JSON examples and runs producer
checks. `code/verify_exports.py` independently checks those files using only
Python's `fractions.Fraction`; it imports neither the compiler nor SymPy.

`verification/compiler_report.json` and `verification/independent_report.json`
record the successful runs. `verification/document_qa.json` records document
checks. `provenance.json` records the source snapshot and primary references.
`SHA256SUMS.txt` supplies a digest for every other packaged file.

## Reproduce

Tested with Python 3.13.5 and SymPy 1.14.0. The code uses Python 3.10+ syntax.
The independent checker requires only the standard library.

```sh
python -m pip install -r requirements.txt
python code/build_examples.py
python code/verify_exports.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The article uses common LaTeX packages including Latin Modern, AMS mathematics,
microtype, geometry, hyperref, xurl, listings, booktabs and fancyhdr. No external
images, bibliography database, or separately supplied font files are needed.
A POSIX reproduction script is supplied as `reproduce.sh`; the individual
commands work from an ordinary terminal on other systems as well.

## Example families

The difference test `(x-y)^2-1` uses four states. The multiplication graph
`x*y-z` uses five, and `(x^2+y^2)^2` uses ten. A second difference-test alphabet
uses the stronger contraction bound theta=1/100.

The fixed eleven-state quadratic-input family encodes

    Q_t(x,y,z) = (z-t)^2 + (z-x*y)^2,

and the fixed nineteen-state straight-line-input family encodes

    P_t(x,y,z) = t-z + (z+1)*(z-x*y)^2.

Both have precisely the same natural root tuples. Inputs 0, 1, 2, 6 and 11 are
exported for each family. All numbers in the JSON files are exact rational
strings. Counts are nonnegative integers, including all zero. The all-zero
joint family is a documented degenerate case rejected by `compile_family`;
a zero polynomial can still be loaded into any compiled nonzero module.

The independent checks cover 1,310 count vectors, 1,424 arbitrary-order words,
and 269 degree-plus-one nilpotence products. The producer checks fourteen
symbolic reverse-polynomial identities, four radial-rank instances, and
nineteen malformed-input rejections. These finite checks supplement the
article's proofs; they are not a proof-assistant certification.

## Mathematical scope

The article proves a quartic state bound `states <= binomial(k+3,2)`, sharp for
numerical-series realization. It also proves fixed-alphabet universality with
a quadratic initial curve at joint nilpotence depth at most four, and with a
rational line segment at depth at most five. The latter has initial rows
`p(t)=(b0+t*b1)/(1+t)` with fixed strictly positive rational endpoints.

The universal results import the classical MRDP theorem and prove their gate
normalization on paper. The package implements the polynomial-to-Markov
compiler, not a complete Turing-machine-to-polynomial frontend. **The numerical
examples are not a universal alphabet.** No claim is made to improve the
repository's 87-operation universal-polynomial bound, to prove finite-fold
MRDP, or to simulate an autonomous Turing machine with a finite Markov chain.
Undecidability concerns existence of some finite control word as input varies;
acceptance of a supplied finite word is an exact finite rational computation.

The literature already contains commuting probabilistic-automaton
undecidability, weighted-automaton Hankel-rank minimality, stochastic embedding
methods and inverse-system dimension theory. This package does not certify
historical priority. Its proofs establish the particular combination,
state-optimal scalar realization, input-geometry tradeoffs and reverse
polynomial extraction stated in the article.

## Input and implementation notes

Construct models through `compile_family`. It expects exact symbolic
polynomials and rational numerical parameters; do not use floating-point input.
Its optional initial scale is validated for strict positivity. The symbolic
compiler is a reference implementation, not an optimized large-instance solver.
The independent script is a replay checker for the packaged export format,
not a general parser for hostile or arbitrary certificate formats. Do not run
Python in optimized (`-O`) mode when running the assertion-based checks.
