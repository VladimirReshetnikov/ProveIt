# Report138: exact unique-12345 companion

This self-contained offline package accompanies **Exact formulas and leading
asymptotics for unique 12345**. It checks the exact combinatorial formulas and
the leading normalization used in the article. There is no inherited Report135
or Report137 dependency, network dependency, decimal R_5 fixture, fitted
correction expansion, or guessed recurrence for U_n.

## What is proved, and what is computed

The article supplies mathematical proofs of its bijections, the six-term
inverse-Cauchy formula, rational diagonality/P-recursiveness, uniform domination,
the positive leading-ratio limit, and leading inversion with an error inside the
ceiling. A finite computation does not prove any of those infinite assertions.

Replay supplies the following exact, independently checkable finite evidence:

1. Expanded factorial determinants versus independent removable-corner Young
   paths for all four-row outer shapes through size 10, including noncontainment:
   5,096 cases
2. Two-row Littlewood–Richardson coefficients checked against independent
   symmetric-polynomial multiplication; the six-term dual-Cauchy polynomial
   identity checked exactly
3. Every supported gamma-boundary parameter tuple at every m=2..8, checked by
   direct enumeration against the six-term count: 462 parameter tuples
4. Direct standard-RSK saturation enumeration at m=6,7,8; the counts are compared
   with a separately supplied audit. It checks corner-emptiness invariance when
   both initial tableau fillings vary, including nonvacuous repeated-filling
   groups
5. Avoidance RSK sums, an independent three-term recurrence, and official OEIS
   b-file values through n=24
6. Direct unique-12345 permutation counts for n=5..8, followed by six-term half
   enumeration and the four-binomial gluing formula through n=24. All U_n values
   are compared with Rutgers data and the available OEIS overlap
7. Exact rational leading h(v) values for coordinate sum at most four, h(0)=240,
   cancellation of the correction-size normalization powers, the rational
   Regev factor 1536, and the lower bound R_5 >= 15/32768. This checks the formula
   and normalization; it does not numerically evaluate the infinite R_5 series

The optional C++ `deep` command adds exhaustive object-level forward/inverse
round trips through n=10, checking the marked spine, northern geometry, boundary
statistics, and pivot deletion/insertion. Its source was supplied by the earlier
investigation; the standard replay is a fresh stdlib Python implementation.

## Requirements

- Python 3.10 or newer with the standard library; run with `-I` (mandatory)
- For `build`/`reproduce`: a TeX installation providing `pdftex`, `pdflatex`,
  standard LaTeX, geometry, T1/lmodern, microtype, AMS packages, mathtools,
  booktabs, hyperref, needspace, and the cm/cmextra/symbols/lm font maps
- Only for optional `deep`: a C++17 compiler invoked as `c++`

No Python package installation is needed. Full replay is intended to take
minutes rather than hours; the exact measured runtime of this release is
reported in the delivery notes. Selftest runs the full replay three times,
including normal and optimized (`-O`) launches. All mathematical comparisons use
explicit exceptions, not removable Python assertions.

## Commands

From the bundle directory, substitute absolute absent output paths whose parent
already exists. All output commands reject targets inside this bundle, existing
files/directories, symbolic links at any component, missing parents, and `..`
components. Output paths shown below are examples, not required locations.

```sh
python -I -B verify.py check
python -I -B verify.py replay --output /tmp/report138-replay-new
python -I -B -O verify.py replay --output /tmp/report138-replay-opt-new
python -I -B verify.py selftest --output /tmp/report138-selftest-new
python -I -B verify.py build --output /tmp/report138-build-new
python -I -B verify.py deep --output /tmp/report138-deep-new
python -I -B verify.py pack --output /tmp/report138-new.zip
python -I -B verify.py reproduce --output /tmp/report138-reproduce-new
```

- `check` verifies the closed inventory, file lengths/SHA256, strict JSON
  schemas/types, source inventory, source numeric syntax and offsets, and
  overlapping official-source values. It does not recompute the mathematics
- `replay` performs the complete exact computations, compares the typed sealed
  fixtures and independent audit counters, and writes `replay-result.json` only
  after success. No subset/quick mode is substituted by `-O`
- `selftest` runs normal and optimized integrity checks; adversarial inventory,
  hash, schema, numeric-type, duplicate-key, nonfinite-number, fixture-code,
  shadow-import, symlink, FIFO, and output-path cases; full normal and optimized
  replays; a full replay of a rehashed well-typed but false fixture; and an
  extraction/repack byte-identity check. Its results list every test
  Historical elapsed-runtime provenance must be a finite nonnegative number;
  fully resealed source mutations test booleans, NaN, infinities, and decimal
  exponent overflow in both normal and optimized Python
- `build` initializes a fresh local pdflatex format, explicitly loads the four
  font maps, compiles three times with shell escape disabled and a fixed source
  date, and checks the final TeX log for overfull boxes, missing glyphs,
  unresolved references/citations, and label warnings. It records the output PDF
  hash and whether it matches the bundled PDF. A different toolchain can change
  PDF bytes without changing mathematical content
- `deep` copies and compiles the C++ source in the new external directory and
  checks exact round-trip output through n=10
- `pack` emits a deterministic uncompressed ZIP, sorted paths, fixed 1980 ZIP
  dates, fixed Unix regular-file metadata, rooted at `Report138/`
- `reproduce` runs selftest and two clean PDF builds. It requires equal fresh
  PDF hashes and byte equality with the bundled PDF. C++ is optional and is not
  needed by this command

Outputs such as logs, fresh PDFs, executables, and extracted test copies stay in
the explicitly requested external destination. A failed build or selftest can
leave diagnostic files there; no existing output target is overwritten.

## Integrity model and adversarial checks

`manifest.json` is a closed list of all payload files. Extra files and extra
directories (including `__pycache__`), missing files, symbolic links, and FIFOs
are rejected. Both Python executable sources first import only built-in `sys`; their isolated-mode
guards run before argparse, pathlib, json, collections, or any other shadowable
import. The
non-isolated shadowing test runs in both normal and optimized Python and confirms
that injected local argparse/fractions modules never execute, through both the
verifier entry point and direct launches of the mathematical module. Python startup and the
system standard library are trusted; this is not a sandbox for a hostile Python
installation or concurrent filesystem mutation.

Fixtures are JSON data, never importable executable code. A strict field and
type contract rejects booleans/floats/strings in integer fields, malformed or
noncanonical rational strings, unexpected keys, and incorrect coverage. A
well-typed false fixture can pass hashes after an attacker reseals it, but must
fail full replay. Sealed executable modules are the only bytes compiled during
replay. Source data are parsed using numeric-only grammars.

Hashes establish internal consistency, not authorship, authenticity, correctness
of malicious replacement code, or formal proof. Review the code and establish
bundle provenance separately. The verifier itself necessarily lies inside the
trust boundary. It checks all remaining code bytes before executing them.

## Updating the article and sealing

Only the maintainer should replace the article or computational files. Review
changes, rebuild the final article PDF, and replace the intended payload files
before generating an external manifest:

```sh
python -I -B verify.py seal --output /tmp/report138-manifest-new.json
```

`seal` validates the closed payload, typed fixtures, and sources but deliberately
does not require a valid old manifest. It never overwrites the bundle manifest.
After review, install the emitted manifest manually as `manifest.json`, run
`check`, full `replay`, and `reproduce`, and then generate the release ZIP.
Resealing is not mathematical validation and does not regenerate fixtures.

The bundle's article TeX/PDF are a matched release snapshot after this final
maintainer step. Source provenance and historical-source limitations are in
`SOURCES.md`; executable algorithms are in `code/exact.py`.
