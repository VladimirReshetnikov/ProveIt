# Provenance and scope

Prepared for Vladimir Reshetnikov with OpenAI on 1 October 2026.

The pressure normalization and finite transfer model are taken from the ProveIt manuscript *Integer Pressure and a Missing Taylor Coefficient*, inspected at commit `6a98f89bac85cc6b4ba5d5c3b63996037d9824e1`, source blob `1973fd17245864bb8a83e1b1d90416ac032ba7c1`:

https://github.com/VladimirReshetnikov/ProveIt/blob/6a98f89bac85cc6b4ba5d5c3b63996037d9824e1/Analysis/FabiusFunction/docs/semi-formalized-research-frontiers/drafts/thue-morse/Thue_Morse_Integer_Pressure/article.tex

The unchanged input report *The Full Positive Triangle in Integer Thue Morse Pressure* supplies the dyadic tangent weak log-majorization and the pre-feedback positive triangle. The quadratic-cluster envelope needed here is proved in the new paper. The earlier all-order first-feedback boundary is cited for context; the explicit diagonal lower bound used in this proof is obtained anew from the complex-disk estimate and the entropy lemma.

The new contribution is an explicit full-width pressure positivity theorem for all m at least 4096. It relies on a scalar interval certificate, a periodic C1 Green estimate, an exact two-branch residual identity, a Hermite boundary repair, coefficient log-concavity and integer-mean entropy bounds. All finite numerical comparisons are rational or integer comparisons. The proof does not assume finite-iterate positivity, termwise excursion positivity or atomic-coordinate positivity; those stronger premises have counterexamples.

This package contains no claim that all smaller orders are resolved, no claim of positivity at or above degree 6m, and no first-negative-degree asymptotic theorem. The stronger raw frozen-tail inequality remains open. The cutoff is conservative. This is unrefereed ordinary mathematics and has not been formalized in Lean; no global priority claim is made.
