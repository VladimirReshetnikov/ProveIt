"""Replay every exact certificate with the Python standard library."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for name in ['verify_outer_product.py','verify_green_constants.py','verify_pressure_separation.py','verify_explicit_cutoff.py']:
 print('Running',name,flush=True)
 subprocess.run([sys.executable,str(root/name)],cwd=root,check=True)
print('All four exact certificate stages passed.',flush=True)
