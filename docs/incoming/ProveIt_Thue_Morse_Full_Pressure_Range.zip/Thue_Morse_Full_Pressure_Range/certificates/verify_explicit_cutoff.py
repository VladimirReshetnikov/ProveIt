"""Exact endpoint arithmetic for the full pressure range at m>=4096."""
from fractions import Fraction as F
from pathlib import Path
import json
alpha=F(707,275);rho=F(7,25)/(2*alpha*F(19,50)**3);d=8192
bound=520020*d**4*rho**d
successive=rho*F(d+1,d)**4
assert bound<F(1,4) and successive<1
assert alpha>2 and 2**128>4*20*128
diagonal_rate=F(7,4)/alpha
assert 26000*128**3*diagonal_rate**128<F(3,20)
assert diagonal_rate*F(129,128)**3<1
assert F(25,2)*128+F(385,8)<128**2
# The C_K(d)<=d² bound continues from log2(d)<=d and a positive increasing quadratic.
assert 128**2-F(25,2)*128-F(385,8)>0
# Log-concavity base case and inductive polynomial difference.
assert F(5,3**4)<F(4,3*7)
# Entropy constant, using pi<22/7 and e<3.
assert 2*F(22,7)*3*F(13,12)<25
out=dict(all_checks_passed=True,cutoff_d=d,cutoff_m=d//2,error_ratio_bound_less_than='1/4',rho=str(rho),successive_ratio=str(successive),cosine_absorption=True,diagonal_lower_bound_cutoff_d=128,diagonal_ratio=str(diagonal_rate),coefficient_log_concavity_base_case=True,entropy_constant_less_than_5=True)
Path(__file__).with_name('explicit_cutoff_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print('All exact checks pass: the full pressure-only range is positive for m>=4096, subject to the written analytic proof.')
