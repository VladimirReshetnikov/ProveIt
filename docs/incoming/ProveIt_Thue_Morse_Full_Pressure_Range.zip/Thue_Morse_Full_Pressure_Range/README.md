# The full pressure positivity range for large integer orders

The paper proves that, for every integer m at least 4096, every even coefficient of p_m(t/pi) at degrees strictly between 2m and 6m is positive. The degree-2m cancellation coefficient is excluded.

This is an unrefereed mathematical research note with exact rational certificates, not a Lean formalization. It does not settle every smaller order or the stronger raw frozen-tail coefficient inequality. Earlier reports are unchanged.

## Contents

- `article.pdf` and `article.tex`: the nine-page paper and editable LaTeX source
- `certificates/exact_intervals.py`: directed integer interval arithmetic and exact Machin/Taylor enclosures
- `certificates/verify_outer_product.py`: the compact-product proof over 131072 rational cells
- `certificates/verify_green_constants.py`: scalar bounds, contraction rows and the d=128 Green cutoff
- `certificates/verify_pressure_separation.py`: half-angle saddle bounds, exact Sturm sequence and coefficient-comparison constants
- `certificates/verify_explicit_cutoff.py`: the diagonal lower bound and final d=8192 pressure cutoff
- The four JSON certificate outputs
- `inputs/positive_triangle.pdf` and `.tex`: the earlier report containing the tangent comparison and pre-feedback positive triangle, included unchanged as an explicit mathematical input
- `inputs/repository_integer_pressure.tex`: the inspected, versioned source manuscript that fixes the pressure normalization
- `PROVENANCE.md`: source versions and mathematical scope

## Replay the exact checks

Run from any working directory:

    python3 certificates/run_all.py

The checkers use only the Python standard library. The compact-product stage normally takes about twelve seconds in the reference environment. The scripts regenerate their JSON outputs beside themselves and fail on any violated comparison. Their correctness is explained by the proofs in the paper; they are finite exact certificates, not floating-point sign samples.

## Build the PDF

A standard TeX installation with the AMS, geometry, Latin Modern, microtype, hyperref and xurl packages can compile `article.tex` with two pdflatex passes. `build_local.sh` is also included for the explicit TeX paths used in the reference Linux environment. Rebuilding may change PDF metadata while leaving the mathematics and layout unchanged.

## Main proof chain

A paired two-factor product estimate retains the sign cancellation that is lost by taking absolute values of each transfer weight separately. A weighted periodic C1 norm then proves uniform complex-disk invertibility of the frozen operator. A cubic Hermite repair makes the nearest two inverse branches a legitimate periodic C1 approximation. The resulting error is at most 26000 d^2 (7/10)^d on the disk of radius 2/5, for even d at least 128.

Log-concavity and an entropy bound at an integer mean supply a uniform positive coefficient lower bound. Exact arithmetic puts the total adverse error below one quarter of that term for d at least 8192, which is m at least 4096.
