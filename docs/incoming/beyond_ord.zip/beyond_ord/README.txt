BEYOND ORD
Definable Class Well-Orders, Canonical Arithmetic, and the Limits of Notation
Research report prepared for Vladimir Reshetnikov
Dated 4 October 2026 (the date of the request in the user's time zone)

CONTENTS

beyond_ord.tex       Complete, self-contained LaTeX source with internal bibliography.
beyond_ord.pdf       Compiled 32-page article.
README.txt           This guide.
PROOF_STATUS.txt     Main claims, assumptions, provenance, and verification limits.

THE MAIN RESULT RELATIVE TO PROVEIT

The article establishes over GB, without set Choice or Global Choice, the
same equivalence that the inspected ProveIt report established over GBC:
strong class-well-order comparability, canonical terminating condensation
histories, and the indicated initial-segment polynomial representations.
The new dependency is a choice-free finite-support power theorem. Both a
greedy-prefix proof and a set-subset proof are supplied. The existing
canonical-history construction is explicitly attributed and re-established.
This resolves the precise base-theory question left open in the inspected
repository. It does not assert that GB proves either equivalent existence
principle, and it does not resolve whether comparability implies ETR.

OTHER DEVELOPMENTS

- Arithmetic of tagged sums, lexicographic products, and finite-support powers.
- Hereditary finite normal forms with arbitrary ordinal coefficients, in GB.
- A canonical fixed point E isomorphic to Ord^[E], with an initial universal
  property and an explicit condensation history of length E+1.
- Exact external calibration E = epsilon_(kappa+1) in full inaccessible models.
- A uniform-family diagonal and explicit growth when a full truth predicate
  is supplied as a new class parameter.
- External spectra of definable class well-orders, including countable
  cofinality under a named global order and a transitive beta-model hypothesis.
- Five formalization viewpoints and twelve specific research directions.

REBUILD

Install a standard TeX Live or MiKTeX distribution with the usual article,
AMS, Palatino/mathpazo, geometry, microtype, hyperref, xurl, fancyhdr, enumitem,
booktabs, and array packages. Then run:

    latexmk -pdf beyond_ord.tex

Alternatively, run this command twice:

    pdflatex -interaction=nonstopmode -halt-on-error beyond_ord.tex

No BibTeX run, external figures, shell escape, network access, or additional
source files are required. The supplied PDF was produced with pdfLaTeX.

PROVENANCE

Inspected repository commit:
e1d2f3048b947801873a6e9ddc4e03736234b328

Principal source:
Algebra/SurrealNumbers/docs/foundations-and-computation/
surreal-well-orders/article.tex

The bibliography in the article contains the exact permalink and primary
literature references. This report does not modify the repository.

STATUS

The article contains full mathematical proofs and underwent independent
mathematical checks during preparation. It is not a refereed publication
or a kernel-checked formalization. Historical priority is not established.
