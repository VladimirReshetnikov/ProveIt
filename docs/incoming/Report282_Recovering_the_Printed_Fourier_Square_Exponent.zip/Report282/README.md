# Report282: the printed Fourier-square exponent

This package contains a mathematical article, its TeX source, a bounded exact Python companion, regression tests, and selected immutable source snapshots. The article combines a source-attributed polynomial local extraction exponent with an elementary near-maximal Fourier argument to recover the printed Fourier-square exponent for every density parameter, at a sufficiently large prime-modulus threshold.

The Lau branch delivers local exponent `2^-3100876 a^9222672` with actual-density mass `2^-137 a^704`. Its Fourier exponent is `2^-3100876 (alpha/2)^(9222672*2^66)`. A separate near-maximal branch treats `1-2^-16 <= alpha < 1`, with full cycles and mass greater than `1-9792(1-alpha)`. The endpoint `alpha=1` is vacuous. The near-maximal argument also works for every cyclic modulus `N>=2`; this does not extend the independent lower-density branch to composite moduli.

This is a source-attributed mathematical consequence, conditional on the stated external recurrence input and imported analytic extraction results. Those inputs are not reproved or formally verified by this package. The lower-range threshold contains non-numerical recurrence constants. This is not an all-primes proof of a source paragraph with no displayed threshold, a new recurrence theorem, a Lean implementation or kernel/axiom audit, a global Szemeredi bound, or a claim of priority.

## Offline use

Requirements: Linux, Python 3.11 or later, and TeX Live with pdftex, pdflatex, Latin Modern, amsmath, amssymb, amsthm, mathtools, geometry, microtype, enumitem, booktabs, longtable, array, xcolor and hyperref. The builder uses only the Python standard library, installed TeX packages, and distributed files. No network connection, repository checkout, or Python package installation is needed. The Lean snapshots are not a standalone Lean project.

From any working directory, supply the absolute path to this package:

    python3 -I -B /path/to/Report282/build.py verify
    python3 -I -B /path/to/Report282/build.py reproduce --output /tmp/report282-rebuild

The output must be a fresh or empty absolute directory outside the source tree, not an ancestor of it. Choose a fresh output for each run. Do not build inside the supplied payload. The builder rejects extra files or directories, source/output symlinks, hard-link aliases, nonregular entries, oversized files, protected system destinations, and existing output files. It never overwrites an output.

The `verify` command checks the exact source allowlist and, for the released distribution, every payload hash against `MANIFEST.sha256`. The `reproduce` command additionally runs all tests and exact diagnostics, including byte-length, SHA-256, Git blob SHA-1 and pinned-URL checks for the source snapshots. Checks execute in isolated staged copies, both normally and with Python `-O`; their stdout must match. Each build-launched test or diagnostic process uses a 640-digit integer-conversion cap, bounded logs and a timeout. Explicit exceptions enforce validation even under optimization. Original and staged source inventories are rechecked after every command, including failures.

A successful reproduction writes:

- `Report282.pdf`
- `report282_printed_fourier_exponent.zip`
- `report282_printed_fourier_exponent.zip.sha256`, covering the actual ZIP bytes
- `MANIFEST.sha256`, covering every public member except itself
- `reproduction_receipt.json`, build logs and isolated working directories, all outside the public payload

To create only a deterministic ZIP from an already manifest-pinned distribution:

    python3 -I -B /path/to/Report282/build.py package --output /tmp/report282-repack

The ZIP has the exact allowlisted `Report282/` members, sorted paths, fixed timestamps and file modes, and deterministic compression. A manifest supplies byte-integrity checks; it is not a mathematical certificate or author authentication.

For a checked PDF reproduction without a ZIP, add `--no-zip` to the `reproduce` command. All arithmetic, source-integrity, mutation and PDF quality gates still run; the external receipt records a null ZIP hash.

## PDF reproducibility

The reference environment uses Python 3.12.14 and pdfTeX 3.141592653-2.6-1.40.26 (TeX Live 2025/dev/Debian). The builder fixes `SOURCE_DATE_EPOCH=1791331200`, UTC, and locale; the article suppresses volatile PDF metadata. TeX shell escape is disabled and file-access policies are restrictive. A local pdflatex format is generated in the external staging directory, followed by three compile passes. The final pass must contain no overfull boxes, unresolved/multiply-defined references, missing citations, or rerun warning.

Replaying a released distribution also requires the rebuilt PDF hash to equal its bundled hash. Different TeX/font/package versions may produce a mismatch even with unchanged mathematics. Keep the supplied distribution and inspect the toolchain/logs rather than replacing its manifest to conceal a mismatch. For a personal non-bit-identical build, use a separate source-only copy.

## Companion scope and limits

`companion/exact_checks.py` checks coefficient-exponent identities; Lau recurrence power margins; exact floor, ceiling and row-budget guards; source-16 two-scale partitions; short-parent rectification, balanced partitions and endpoint-contained covers; mass averaging; near-maximal rational constants; printed-exponent integer certificates; and exhaustive small cyclic instances of the dense-extension lemma and multiplication-kernel bound.

All arithmetic uses bounded integers and exact `Fraction` values. Evaluated binary powers have exponents at most 30; powers such as `2^66`, `2^70`, the reported density exponents, and astronomical thresholds remain symbolic. No floating-point approximation is used. CLI parameter overrides are rejected. Importable helpers validate bounded inputs and reject booleans, invalid geometry, insufficient density, and oversized models.

The diagnostics are finite regression checks, not proofs of universal real inequalities, the analytic identities, dense extension for arbitrary groups, or the article's theorems. In particular, the constants alone do not verify Parseval, character rigidity or an external recurrence theorem. The mathematical arguments and explicit imported hypotheses are in the article.

The fixed run includes 2,474 source-16 partitions, 512 recurrence-margin instances, 1,365 tolerance guards, 81 rounded-row models, 1,784 square-absorption cases, and 16,254 candidate maps over all qualifying subsets of cyclic domains of size 1 through 6 and codomains of size 1 through 4. All 104 partially additive maps in that enumeration extend uniquely. It also checks 8,128 nonzero multiplication kernels for cyclic moduli 2 through 128. The inherited finite geometric suite contains 2,776 rectifications, 3,503 balanced partitions, 3,813 aligned-parent partitions, 2,079 endpoint covers, 16,150 square fits, 372 short-parent budgets and 25 mass-averaging cases. These counts describe the diagnostic coverage only.

The payload contains 19 relevant Lean snapshots and the exact repository dependency manifest. It excludes private audits, internal research notes, raw connector receipts, logs, the full canonical article, canonical source-16 excerpts, and external papers. No repository file is modified or uploaded by this build.
