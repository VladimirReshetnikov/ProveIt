# Exact logical inventory reconstructed from accepted K215

This inventory concerns source SHA-256 `17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba`, not the ancestral 254-state program. The ancestral primary `lib/jeff-busy-beaver-zfc254/ZF/m254/tools/logic/spec.py` was fetched at ProveIt commit `c8029f50d324910a36694c39a1e62f5720c36f4c`; it supplies the constructor conventions. Its old rho7 and old C/G bundle must not be mistaken for the accepted source's modified growG row and private K bundle.

Write I(x,y)=4P(x,y), R(x,y)=4P(x,y)+1, Q_i(x)=4P(i,x)+2, E(x,y)=4P(x,y)+3, F=1, N(x)=I(x,F), and Ex_i(x)=N(Q_i(N(x))). The following formulas were independently recovered by symbolically running the scalar-push and constructor macro word of the actual accepted AX subtree. The exact unabridged syntax is in `actual_ax_formulas.json`. `ax_macro_parse.json` gives each constructor interval. Primitive costs below are the lengths of these literal contiguous source intervals, not separately additive state counts.

At AX entry let U be the old counter and h the old cache; payloads set A=U+x, B=h+y, and C is the residual selector. The emitted formula stack, from bottom to top above the saved old top, is:

| Object | Exact formula | Source primitive occurrences |
|---|---|---:|
| GEN | Q_U(h) | 81 |
| rho8 | ((C→U)→A)→((A→C)→(B→C)), U≤A | 344, plus 28 for two input readers/accumulation |
| rho7 growG | E(C,A)→(E(C,B)→Q_{R(A,B)} E(A,B)) | 409 |
| rho6 | (Ex_A Q_A(C))→C | 283 |
| rho5 | E(C,A)→(R(C,B)→R(A,B)) | 296 |
| rho4 | Q_A Q_B(C)→Q_B Q_A(C) | 299 |
| rho3 | E(A,B)→(R(C,A)→R(C,B)) | 296 |
| rho2 | Q_A(B→C)→(Q_A(B)→Q_A(C)) | 350 |
| rho1 | Ex_A E(A,B) | 231 |
| private K, left in top | formula below | 1913 |

The final two freshness comparisons and cleanup occupy 35 further primitive occurrences. The complete AX subtree has 4565 primitives. It gates the final top to zero when C=A or C=B; otherwise the top remains K. Other generated formulas remain on the theorem stack.

## Exact private K formula

The following definitions use only the literal arrow, negation N and universal constructors; no classical equivalence has been applied:

\[
\begin{aligned}
 V&=R(A,B)\to Q_C R(A,B),\\
 S&=Q_C(R(C,A)\to R(C,B)),\\
 Z&=Q_B(C\to N R(B,C)),\\
 U_*&=Q_B(C\to N Z),\\
 H_*&=Q_A(S\to U_*),\\
 J_*&=Q_A(C\to N H_*),\\
 K(A,B,C)&=N\left(V\to Q_C\left(Q_B(R(B,C)\to N J_*)\to N U_*\right)\right).
\end{aligned}
\]

C is simultaneously the raw matrix formula code, a variable label, and the parameter in both freshness inequalities. R(A,B) in rho7 is likewise a formula code used as a variable label. These heterotyped uses are why arbitrary recoding or formula substitution requires a genuine calibration argument. The final K contains nineteen literal implication constructors, ten universal constructors and seven membership constructors. No separate Choice axiom or Choice-generating branch appears in this emitter.

## Constructor costs and sharing

In the actual source, scalar pushes of A, B or C each cost 26 primitives; pushing zero costs19; pushing one costs20. The literal formula constructors cost I27, R28, Q29 and E30 primitives. The negative constructor costs47, and Ex costs123. These counts include shared Cantor stack/arithmetic helpers, and a constructor may straddle a source-tree association boundary. In particular E is not itself a closed subtree in the accepted DAG: it is assembled from an R constructor and two further increments shared with surrounding sequence structure.

Across the entire source, including MP's implication construction, the formula constructor occurrences are I42, Q21, R12 and E6. Changing the formula code therefore needs to change MP as well as AX. The separate Cantor coding of proof lists and theorem stacks must remain untouched unless its own source and compiler proof changes too.

## Warning for intuitionistic proposals

Ex is syntactically negative universal quantification, and the historical conjunction is N(I(A,N(B))). They do not have the usual constructive existential/conjunction meanings without additional principles. The current K is even more aggressively simplified in negative notation. Thus a standard intuitionistic set-theory or Diaconescu theorem cannot simply be quoted for the literal current emitter.

Rho6 has the shape (not forall a not forall a B)→B, suggesting a possible bootstrap of double-negation elimination once a sufficiently strong vacuity theorem B→Q_a B has been derived. Establishing that bootstrap from K/S and the remaining actual rows is a real remaining proof obligation; no successful reduction has been claimed here.
