# A 214-state runtime fold and numerical calculi with junk codes

**Status: research result; the requested complete ≤214-state blank-start machine has not been constructed.**

This packet contains a verified 214-state interpreter runtime, a proof that its actual blank startup fails, and independent logical and source-level results. It must not be installed as an accepted `candidate-k214`.

## Read first

- `report.pdf` — complete mathematical report.
- `report.tex`, `sections/*.tex` — editable LaTeX sources.
- `STATUS.json` — machine-readable outcome and proof scope.
- `NOTICE.md`, `licenses/` — attribution and inherited licenses.

The 214-state runtime table passes all 6,176 arbitrary-natural guarded primitive cases for the unchanged accepted source. Nevertheless, from blank tape and initial state 0 it reaches state 35 at head 7 after exactly 85 transitions, with ones only at cells −3 and −2. Its transition `35/0 = 1 R 35` then gives a proved outward ray. This table therefore does not establish the requested consistency equivalence.

The strongest separate logical result is a finite-proof embedding theorem for constructor algebras with arbitrary junk generators. It preserves mixed formula/index roles and finite equality/disequality gates. The numerical domination restriction is handled separately, using the inherited 3,728-node certificate and a new structural audit of all 1,260 dominated instances.

## Contents

| Path | Purpose |
| --- | --- |
| `reference/` | Pinned K215 source, native and dense tables, source-language utilities, parent proof/reproduction text |
| `data/runtime-fold/` | Exact 214-state runtime-only native/dense tables and independent startup replay |
| `evidence/runtime-fold/` | Full runtime summary, compressed 6,176-case derivation inventory, complete startup trace, independent structural audit |
| `verification/code/` | Complete inherited arbitrary-natural primitive checker and label map |
| `data/source149/` | Exact domination certificate, both original forward checkers, structural witness audit and provenance |
| `data/constructor-variants/` | Nested Cantor, prefix and tag-permutation source experiments |
| `data/command-variants/` | Refutation-complete consuming DROP, COPY and TAKE sources |
| `data/source-retagging/` | Source with no CC(3), preserving the exact guarded ordinal graph |
| `data/search-contexts/` | Conservative local tape neighborhoods used by synthesis |
| `evidence/searches/` | Precisely scoped search receipts, including negative results |
| `data/rejected69-111.native.tm`, `evidence/rejected69-111/` | A separately rejected 214-state table that actually halts after 141,208 blank steps |
| `code/` | Portable builders, independent checks, optional source and local-transition searches |
| `search-supplement/` | Coordinated helper/initializer synthesis, 13 compressed raw search batches and exact scopes |
| `MANIFEST.sha256` | File integrity manifest |

## Reproduce the positive results and the startup obstruction

Python 3.10 or later, standard library only; run without `-O` because the independent audit scripts deliberately use assertions.

```sh
python code/verify_packet.py
python code/reproduce.py --output reproduced
python code/reproduce.py --output reproduced --runtime
```

The optional `--runtime` pass takes a few minutes. Its expected pair of statuses is:

```text
runtime: UNIVERSAL_MATHEMATICAL_PASS, 6176/6176 cases
startup: EXACT_OUTWARD_RAY, 85 transitions
```

A zero process exit code alone is not a candidate acceptance signal. The source-to-ZFC calibration is inherited from the pinned repository; the present runtime proof is an executable ordinary mathematical derivation, not an exact-table proof-assistant certificate. The report states the precise scope of every proof.

To reproduce the stronger reachable spare invariant:

```sh
python code/collect_unit_contexts.py --output reproduced/unit-contexts
```

The `--mode conservative` variant uses opaque one-block exteriors. The default uses caller-relative exteriors. Full runs must cover all 6,176 cases. Partial diagnostic runs are explicitly marked partial.

To rebuild the all-pair local synthesis experiment (C++17):

```sh
c++ -O3 -std=c++17 code/search_pair_synthesis.cpp -o reproduced/search-pairs
reproduced/search-pairs reference/k215.native.tm data/search-contexts/precise.txt
reproduced/search-pairs reference/k215.native.tm data/search-contexts/unit_spares_callers.txt
```

These searches use radius-four whole-window stuttering with at most 20 positive local steps; negative outputs are not global lower bounds.

Optional source investigations are documented by `--help` in `code/search_axiom_permutations.py` and `code/source_invariants.py`. For the source invariant, supply an output filename:

```sh
python code/source_invariants.py --output reproduced/source-invariants.json
```

## Compile the report

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

Standard TeX Live packages are sufficient. The PDF was rendered and visually checked. Generated LaTeX auxiliary files and scratch executables are omitted from the archive.

## Repository identity

Repository: https://github.com/VladimirReshetnikov/ProveIt

Snapshot: `c8029f50d324910a36694c39a1e62f5720c36f4c`

Accepted K215 commit: `a61476422532a5d3b7dec11fc7a92751fe0d60f8`

Parent native table SHA-256:
`9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2`

Parent source SHA-256:
`17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba`

Runtime-only native table SHA-256:
`06cdddee109e178fb1b398316a393ac2897b3763d5dcbce31968a5840c2e893a`

Retain `NOTICE.md`, inherited notices and licenses when incorporating the packet. The proposed integration destination is a research subdirectory, not an accepted candidate directory.
