#include <array>
#include <chrono>
#include <cmath>
#include <vector>
#include <set>
#include <fstream>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <string>
using namespace std;
struct Row{int w,d,t;bool operator==(const Row&r)const{return w==r.w&&d==r.d&&t==r.t;}};Row T[400][2];bool present[400];
struct Alt{int q,b;Row r;};vector<Alt>alts;vector<int>bykey[800];
pair<int,int> unpair(int n){int s=int((sqrt(8.0*n+1)-1)/2);while((s+1)*(s+2)/2<=n)s++;while(s*(s+1)/2>n)s--;int b=n-s*(s+1)/2;return{s-b,b};}
bool known_theorem(int n){if(n==0)return true;auto [a,b]=unpair(n/4);if(n%4==2)return known_theorem(b);if(n%4==0)return a==b||known_theorem(b);return false;}
bool known_stack(int n){while(n){auto [a,b]=unpair(n);if(!known_theorem(a))return false;n=b;}return true;}
bool calibrated(int q,int h,const set<int>&ones,vector<int>&logical,int&spares,int &gap){
 if(q!=84||ones.empty()||*ones.begin()!=h-1)return false;
 auto it=ones.begin();++it;if(it==ones.end()||*it<h+64)return false;int header=*it,p=header+1,last=*ones.rbegin();vector<int>v;
 while(p<=last){if(ones.count(p)||!ones.count(p+1))return false;p++;int n=0;while(ones.count(p)){n++;p++;}v.push_back(n-1);}
 if(v.size()<10)return false;int phy[]={6,2,0,4,3,7,8,5,1};logical.clear();for(int i:phy)logical.push_back(v[i]);if(logical[3]||logical[6]||logical[7]||logical[8])return false;if(!known_theorem(logical[1])||!known_theorem(logical[5])||!known_stack(logical[2]))return false;spares=v.size()-9;gap=header-h-64;return true;
}
struct Result{string status;long tick;int q,h,gap=0,spares=0;vector<int>regs,keys;};
Result run(int start,int limit,bool record){int q=start,h=0;set<int>ones;Result res;bool used[800]{};int cq=q,ch=h;set<int> checkpoint=ones;long power=1,lam=0;
 for(int tick=0;tick<=limit;tick++){
  res.tick=tick;res.q=q;res.h=h;
  if(calibrated(q,h,ones,res.regs,res.spares,res.gap)){res.status="CALIBRATED";break;}
  if(q==254){res.status="HALT";break;}
  if(tick==limit){res.status="BOUND";break;}
  int bit=ones.count(h);Row r=T[q][bit];if(record&&!used[2*q+bit]){used[2*q+bit]=true;res.keys.push_back(2*q+bit);}
  if(!bit&&r.t==q&&(ones.empty()||(r.d>0&&h>*ones.rbegin())||(r.d<0&&h<*ones.begin()))){res.status="RAY";break;}
  if(r.w)ones.insert(h);else ones.erase(h);h+=r.d;q=r.t;
  lam++;if(q==cq&&h==ch&&ones==checkpoint){res.status="EXACT_CYCLE";break;}if(lam==power){cq=q;ch=h;checkpoint=ones;power*=2;lam=0;}
 }
 return res;
}
int main(int argc,char**argv){ifstream tf(argv[1]);string line;while(getline(tf,line)){if(line.empty()||line[0]=='#')continue;int q,b,w,t;char d;istringstream s(line);s>>q>>b>>w>>d>>t;T[q][b]={w,d=='R'?1:-1,t};present[q]=true;}
 ifstream af(argv[2]);while(getline(af,line)){int q,b,w,t;char d;istringstream s(line);if(!(s>>q>>b>>w>>d>>t))continue;if(!present[q])continue;if(t==301)t=88;Row r{w,d=='R'?1:-1,t};if(r==T[q][b])continue;int id=alts.size();alts.push_back({q,b,r});bykey[2*q+b].push_back(id);}
 int limit=argc>3?stoi(argv[3]):200000;long tests=0,bounds=0;int hits=0;auto began=chrono::steady_clock::now();bool timedout=false;
 for(int id=-1;id<int(alts.size());id++){
  Row old;Alt a;if(id>=0){a=alts[id];old=T[a.q][a.b];T[a.q][a.b]=a.r;}
  for(int start=0;start<400;start++)if(present[start]){
   auto r=run(start,limit,false);tests++;if(r.status=="BOUND")bounds++;
   if(r.status=="CALIBRATED"){hits++;cout<<"HIT patch "<<id;if(id>=0)cout<<" "<<a.q<<" "<<a.b<<" "<<a.r.w<<" "<<a.r.d<<" "<<a.r.t;cout<<" start "<<start<<" ticks "<<r.tick<<" gap "<<r.gap<<" regs";for(int v:r.regs)cout<<" "<<v;cout<<" spares "<<r.spares<<endl;}
   if(chrono::duration<double>(chrono::steady_clock::now()-began).count()>55){timedout=true;break;}
  }
  if(id>=0)T[a.q][a.b]=old;if(timedout)break;
 }
 cerr<<"DONE tests "<<tests<<" bounds "<<bounds<<" hits "<<hits<<" time_limited "<<timedout<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-began).count()<<endl;
}
