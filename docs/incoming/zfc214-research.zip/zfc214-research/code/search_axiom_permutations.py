#!/usr/bin/env python3
"""Optional bounded source search. All 5040 row orders, one additive-cost DP parse per order.
Only improving candidates undergo complete CFG comparison; no binary runtime is implied.
"""
from pathlib import Path
import sys,json,itertools,hashlib,time,functools,argparse
ap=argparse.ArgumentParser(description='Optional 5040-order AX permutation/source-association cost census; no global lower bound.')
ap.add_argument('--parent',type=Path,required=True)
ap.add_argument('--blocks',type=Path,default=Path(__file__).resolve().parents[1]/'data'/'ax_block_intervals.json')
ap.add_argument('--output',type=Path,required=True)
a=ap.parse_args();assert __debug__ and not sys.flags.optimize
B=a.parent;sys.path.insert(0,str(B));import source_language as s
assert hashlib.sha256((B/'sites215.json').read_bytes()).hexdigest()=='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
rows=json.loads((B/'sites215.json').read_text());tree=s.tree(rows);oldg=s.graph_arithmetic(rows)[0];axpath='1101001001';ax=s.subtree(tree,axpath)
meta=json.loads(a.blocks.read_text());base=meta['ax_first_ordinal'];blocks=meta['blocks']
# Integer DAG, existing source only.
keys=[];ids={}
def put(t):
 if t in ids:return ids[t]
 if s.leaf(t):key=t
 else:key=(put(t[0]),put(t[1]))
 i=len(keys);keys.append(key);ids[t]=i;return i
root=put(tree);reverse={i:t for t,i in ids.items()}
@functools.lru_cache(None)
def desc(i):
 if isinstance(keys[i][0],str):return frozenset([i])
 a,b=keys[i];return desc(a)|desc(b)|{i}
# Nodes forced by the unchanged program exterior and every maximal component.
components=[[ids[s.subtree(tree,p)]for lo,hi,p,bd in b['maximal_contained_subtrees']]for b in blocks]
atomset=set(sum(components,[]));fixed=set()
def outside(t,p=''):
 if p==axpath:return
 if s.leaf(t):fixed.add(ids[t]);return
 if not axpath.startswith(p):fixed.update(desc(ids[t]));return
 outside(t[0],p+'0');outside(t[1],p+'1')
outside(tree)
for i in atomset:fixed.update(desc(i))
# Existing fragment yields over these opaque components.
@functools.lru_cache(None)
def yield_(i):
 if i in atomset:return(i,)
 if isinstance(keys[i][0],str):return None
 a,b=keys[i];aa,bb=yield_(a),yield_(b)
 return None if aa is None or bb is None else aa+bb
known={}
for i in range(len(keys)):
 seq=yield_(i)
 if seq is not None:
  cost=len(desc(i)-fixed)
  if seq not in known or cost<known[seq][0]:known[seq]=(cost,i)
# Additive cost is an upper estimate: final candidates are priced by exact DAG.
def parse(seq):
 n=len(seq);dp=[[None]*(n+1)for _ in range(n)]
 for i in range(n):dp[i][i+1]=(0,('old',seq[i]))
 for width in range(2,n+1):
  for i in range(n-width+1):
   j=i+width;old=known.get(tuple(seq[i:j]));best=(old[0],('old',old[1]))if old else (10**9,None)
   for k in range(i+1,j):
    cost=dp[i][k][0]+dp[k][j][0]+1
    if cost<best[0]:best=(cost,('split',k))
   dp[i][j]=best
 def build(i,j):
  tag,v=dp[i][j][1]
  return reverse[v]if tag=='old'else(build(i,v),build(v,j))
 return build(0,n),dp[0][n][0]
start=time.monotonic();O=a.output;O.mkdir(parents=True,exist_ok=True);best=999;history=[];counts={};tested=0
order0=(0,1,2,3,4,5,6,7,8,9,10)
for perm in itertools.permutations(range(2,9)):
 order=(0,1)+perm+(9,10);seq=sum([components[k]for k in order],[]);newax,estimate=parse(seq);new=s.replace(tree,axpath,newax);met=s.metrics(new);n=met['dag_nodes'];tested+=1;counts[n]=counts.get(n,0)+1
 if n<best:
  nr=s.sites(new);ng=s.graph_intervals(nr);assert ng==s.graph_arithmetic(nr)[0]
  # Every moved interval has the same primitive word and internal guarded
  # edges. Its former exits now lead to the next block in the new order.
  newstarts={};cursor=base
  for k in order:newstarts[k]=cursor;cursor+=blocks[k]['relative_span'][1]-blocks[k]['relative_span'][0]
  mapping={};owner={}
  for k,b in enumerate(blocks):
   lo,hi=b['absolute_span']
   for i in range(lo,hi):mapping[i]=newstarts[k]+i-lo;owner[i]=k
  for i,(p,op,arg)in enumerate(rows):
   if i not in owner:
    assert nr[i][1:]==rows[i][1:] and ng[i]==oldg[i],('outside CFG',i)
    continue
   k=owner[i];j=mapping[i];assert nr[j][1:]==rows[i][1:]
   lo,hi=blocks[k]['absolute_span'];end=newstarts[k]+hi-lo
   eff,targets=oldg[i]
   wanted=[]
   for target in targets:
    if target==hi:wanted.append(end)
    elif lo<=target<hi:wanted.append(mapping[target])
    else:
     # The final gate may leave AX. Every earlier block is closed.
     assert k==10,('unexpected open row edge',i,target,k)
     wanted.append(mapping.get(target,target))
   assert ng[j]==[eff,wanted],('changed internal control',i,j,ng[j],[eff,wanted])
  best=n;raw=s.compact(nr);f=O/f'best{n}.json';f.write_bytes(raw)
  rec={'tested':tested,'permutation':[blocks[k]['name']for k in order],'metrics':met,'estimate':estimate,'file':f.name,'sha256':hashlib.sha256(raw).hexdigest(),'seconds':time.monotonic()-start,'all_primitive_effects_and_guarded_edges_checked_up_to_block_permutation':True}
  history.append(rec);print(json.dumps(rec),flush=True)
 if tested%500==0:print(json.dumps({'tested':tested,'best':best,'seconds':time.monotonic()-start}),flush=True)
result={'tested':tested,'total_permutations':5040,'complete':tested==5040,'best':best,'histogram':counts,'history':history,'seconds':time.monotonic()-start,'scope':'DP over fixed maximal closed components; additive parse heuristic, exact DAG metric; no global lower bound or binary runtime.'}
(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
