#!/usr/bin/env python3
"""Reproduce the source-only DROP', COPY, and TAKE variants of pinned K215.

The checked objects are exact source trees and retained guarded CFG edges.
The ordinary mathematical compiler proofs are in the accompanying report.
No binary allocation, runtime correctness, or blank initialization is asserted.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, sys

PARENT_SHA='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
EXPECTED={
 'drop_consume':'113409cc4bb7db12510561578f654be113a307517528b88c92ca007bba832fe3',
 'copy_clear':'ca70b22d9e98759a41609527b104ca1989dc2e1c6c5737e37ede822d5c7362af',
 'take_clear':'9bec95174571a0768450e1e01285eb270c7e2f973ffa8625176887c99281510b',
}
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--parent',type=Path,required=True,help='Directory containing pinned sites215.json and source_language.py')
 ap.add_argument('--output',type=Path,required=True)
 a=ap.parse_args();assert __debug__ and not sys.flags.optimize
 spec=importlib.util.spec_from_file_location('source_language',a.parent/'source_language.py')
 s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 raw=(a.parent/'sites215.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==PARENT_SHA
 rows=json.loads(raw);tree=s.tree(rows);g=s.graph_arithmetic(rows)[0];assert g==s.graph_intervals(rows)
 copy=s.subtree(tree,'1101011')
 assert copy==((('CD',5),(('CI',1),(('CI',6),('CC',3)))),(('CD',6),(('CI',5),('CC',2))))
 transfer=(('CD',5),(('CI',1),('CC',2)));clear=(('CD',1),('CC',1))
 variants={'drop_consume':[('1101011',transfer)],'copy_clear':[('110101',(clear,copy))],
           'take_clear':[('110101',(clear,transfer))]}
 a.output.mkdir(parents=True,exist_ok=True);out={}
 for name,replacements in variants.items():
  new=tree
  for p,node in replacements:
   assert s.boundary(s.subtree(tree,p))==s.boundary(node)==(0,0,False)
   new=s.replace(new,p,node)
  nr=s.sites(new);ng=s.graph_arithmetic(nr)[0];assert ng==s.graph_intervals(nr)
  ni={p:i for i,(p,_,_)in enumerate(nr)};spans=[]
  for p,node in replacements:
   ix=[i for i,(q,_,_)in enumerate(rows)if q.startswith(p)]
   jx=[i for i,(q,_,_)in enumerate(nr)if q.startswith(p)]
   assert ix==list(range(min(ix),max(ix)+1)) and jx==list(range(min(jx),max(jx)+1))
   spans.append((p,min(ix),max(ix)+1,min(jx),max(jx)+1))
  def remap(i):
   for p,lo,hi,nlo,nhi in spans:
    if lo<=i<hi:
     assert i==lo,('outside edge enters fragment interior',name,i,p)
     return nlo
   return ni[rows[i][0]]
  retained=edges=0
  for i,(p,op,arg)in enumerate(rows):
   if any(p.startswith(root)for root,_ in replacements):continue
   j=ni[p];assert nr[j]==rows[i]
   eff,targets=g[i];assert ng[j]==[eff,[remap(k)for k in targets]],(name,i,j)
   retained+=1;edges+=len(targets)
  data=s.compact(nr);sha=hashlib.sha256(data).hexdigest();assert sha==EXPECTED[name]
  filename='sites215_'+name+'.json';(a.output/filename).write_bytes(data)
  out[name]={'file':filename,'sha256':sha,'metrics':s.metrics(new),
   'guard_cases':sum(2 if op=='CD'else 1 for _,op,_ in nr),
   'replacement_intervals':[{'path':p,'old':[lo,hi],'new':[nlo,nhi]}for p,lo,hi,nlo,nhi in spans],
   'retained_primitive_occurrences':retained,'retained_guarded_edges':edges,
   'two_cfg_resolvers_agree':True,'outside_entries_only_at_roots':True}
 result={'status':'SOURCE_VARIANTS_CONSTRUCTED_AND_RETAINED_CFG_CHECKED',
  'parent_source_sha256':PARENT_SHA,'variants':out,
  'scope':'Exact finite source/CFG checks only. Arithmetic and compiler contracts are ordinary proofs; no binary candidate is certified.'}
 (a.output/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
