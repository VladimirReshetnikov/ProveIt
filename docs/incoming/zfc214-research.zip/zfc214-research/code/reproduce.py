#!/usr/bin/env python3
"""Rebuild all positive finite results; optionally rerun the unbounded runtime.
The expected startup result is an outward ray. This is not a candidate-acceptance
script: it reproduces an explicitly incomplete research construction.
"""
from pathlib import Path
import argparse,json,subprocess,sys
P=Path(__file__).resolve().parents[1]
def run(script,*args):
 cmd=[sys.executable,str(P/script),*map(str,args)]
 print('\nRUN', ' '.join(cmd),flush=True);subprocess.run(cmd,check=True,cwd=P)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,default=Path('reproduced'));ap.add_argument('--runtime',action='store_true');a=ap.parse_args()
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
 run('code/verify_packet.py')
 run('code/build_runtime_fold.py','--parent',P/'reference/k215.native.tm','--output',out/'runtime-fold')
 run('code/independent_table_audit.py','--baseline',P/'reference/k215.native.tm','--candidate',out/'runtime-fold/k214-runtime-only.native.tm','--source',P/'reference/sites215.json','--output',out/'independent')
 run('code/build_command_variants.py','--parent',P/'reference','--output',out/'command-variants')
 run('code/build_constructor_variants.py','--parent',P/'reference','--output',out/'constructor-variants')
 run('code/audit_constructor_domination.py','--output',out/'constructor_domination_audit.json')
 if a.runtime:
  run('verification/code/validate_native.py',out/'runtime-fold/k214-runtime-only.native.tm',P/'reference/sites215.json',out/'runtime-proof','--all-failures')
  r=json.loads((out/'runtime-proof/runtime.json').read_text());s=json.loads((out/'runtime-proof/startup.json').read_text())
  assert r['status']=='UNIVERSAL_MATHEMATICAL_PASS'and r['proved_cases']==6176
  assert s['status']=='EXACT_OUTWARD_RAY'and s['steps']==85
 print('\nReproduction complete. Runtime theorem holds; blank bootstrap fails exactly. TARGET NOT MET.')
if __name__=='__main__':main()
