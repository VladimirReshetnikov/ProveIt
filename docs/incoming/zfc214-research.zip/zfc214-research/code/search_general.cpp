#include <array>
#include <vector>
#include <set>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <tuple>
#include <algorithm>
using namespace std;
struct Row {int w,d,t; bool operator==(const Row&a)const{return w==a.w&&d==a.d&&t==a.t;}};
struct C {int q,h,bits;};
Row T[400][2];bool present[400];vector<int>ctx[400];const int R=4,N=20;
vector<Row> actions;vector<int>alts[400][2];
C perform(C x,Row r){return {r.t,x.h+r.d,(x.bits&~(1<<(x.h+R)))|(r.w<<(x.h+R))};}
vector<C> traj(int q,int bits){C x{q,0,bits};vector<C>v;for(int n=0;n<N;n++){if(x.h<-R||x.h>R||!present[x.q])break;x=perform(x,T[x.q][x.bits>>(x.h+R)&1]);v.push_back(x);}return v;}
vector<C> traces[400][512];
bool local(int q,int bits,Row r){auto&old=traces[q][bits];C y=perform({q,0,bits},r);for(int n=1;n<=N;n++){for(const C&z:old)if(y.q==z.q&&y.h==z.h&&y.bits==z.bits)return true;if(y.h<-R||y.h>R||!present[y.q])break;y=perform(y,T[y.q][y.bits>>(y.h+R)&1]);}return false;}
bool check(int q,int bits,int a,int b,Row r0,Row r1){auto&old=traces[q][bits];C y{q==b?a:q,0,bits};for(int n=0;n<=N;n++){if(n)for(const C&z:old)if(y.q==(z.q==b?a:z.q)&&y.h==z.h&&y.bits==z.bits)return true;if(y.h<-R||y.h>R||!present[y.q])break;int sym=y.bits>>(y.h+R)&1;Row r=y.q==a?(sym?r1:r0):T[y.q][sym];if(r.t==b)r.t=a;y=perform(y,r);}return false;}
int main(int argc,char**argv){
 ifstream f(argv[1]);string line;while(getline(f,line)){if(line.empty()||line[0]=='#')continue;int q,b,w,t;char d;istringstream s(line);s>>q>>b>>w>>d>>t;T[q][b]={w,d=='R'?1:-1,t};present[q]=true;}
 ifstream cf(argv[2]);int q,n;while(cf>>q>>n){for(int j=0;j<n;j++){int b;cf>>b;ctx[q].push_back(b);}}
 for(int w:{0,1})for(int d:{-1,1})for(int t=0;t<400;t++)if(present[t])actions.push_back({w,d,t});
 for(int q=0;q<400;q++)if(present[q])for(int b:ctx[q])traces[q][b]=traj(q,b);
 long checks=0;for(int q=0;q<400;q++)if(present[q])for(int b:{0,1})for(int act=0;act<(int)actions.size();act++){bool ok=true;for(int bits:ctx[q])if((bits>>R&1)==b){checks++;if(!local(q,bits,actions[act])){ok=false;break;}}if(ok)alts[q][b].push_back(act);}
 cerr<<"local checks "<<checks<<endl;for(int q=0;q<400;q++)if(present[q])cerr<<q<<":"<<alts[q][0].size()<<","<<alts[q][1].size()<<" ";cerr<<endl;
 long pairs=0,combs=0;for(int a=0;a<400;a++)if(present[a]&&ctx[a].size()&&a!=84)for(int b=a+1;b<400;b++)if(present[b]&&ctx[b].size()&&b!=84){vector<int>common[2];for(int k:{0,1})set_intersection(alts[a][k].begin(),alts[a][k].end(),alts[b][k].begin(),alts[b][k].end(),back_inserter(common[k]));if(common[0].empty()||common[1].empty())continue;pairs++;
  for(int c0:common[0])for(int c1:common[1]){combs++;bool ok=true;for(int q:{a,b}){for(int bits:ctx[q]){if(!check(q,bits,a,b,actions[c0],actions[c1])){ok=false;break;}}if(!ok)break;}if(ok){auto x=actions[c0],y=actions[c1];cout<<"PASS "<<a<<" "<<b<<" "<<x.w<<" "<<x.d<<" "<<x.t<<" "<<y.w<<" "<<y.d<<" "<<y.t<<endl;}}
 }
 cerr<<"pairs "<<pairs<<" combinations "<<combs<<endl;
 return 0;
}
