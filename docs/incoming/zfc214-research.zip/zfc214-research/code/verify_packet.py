#!/usr/bin/env python3
"""Independent integrity and finite-obligation checks for this research packet.
This deliberately concludes TARGET_NOT_MET: the runtime table has an exact
blank-start ray. Rebuilding the unbounded derivations is a separate command.
"""
from pathlib import Path
import gzip,hashlib,importlib.util,json,sys
P=Path(__file__).resolve().parents[1]
assert __debug__ and not sys.flags.optimize, 'Run Python without -O'
def load(f):return json.loads((P/f).read_text())
def sha(f):return hashlib.sha256((P/f).read_bytes()).hexdigest()
def table(f):
 t={};start=None
 for line in (P/f).read_text().splitlines():
  if line.startswith('#! start '):start=int(line.split()[-1])
  elif line and not line.startswith('#'):
   q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
   assert(q,b)not in t and b in(0,1)and w in(0,1)and d in('L','R')
   t[q,b]=(w,1 if d=='R'else-1,z)
 assert start==0
 return t
NATIVE='data/runtime-fold/k214-runtime-only.native.tm'
DENSE='data/runtime-fold/k214-runtime-only.tm'
SOURCE='reference/sites215.json'
assert sha('reference/k215.native.tm')=='9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2'
assert sha(SOURCE)=='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
assert sha(NATIVE)=='06cdddee109e178fb1b398316a393ac2897b3763d5dcbce31968a5840c2e893a'
assert sha(DENSE)=='ec27181e8de8f3920ced8206f16b59365cd4e1a4fe1a294defaa6119fc941b84'
t=table(NATIVE);states={q for q,b in t};assert len(states)==214
assert set(t)=={(q,b)for q in states for b in(0,1)}
assert{z for w,d,z in t.values()}-states=={254}
rename={q:i for i,q in enumerate(sorted(states))};rename[254]=214
assert table(DENSE)=={(rename[q],b):(w,d,rename[z])for(q,b),(w,d,z)in t.items()}
assert rename[0]==0 and rename[84]==83
rows=load(SOURCE);rt=load('evidence/runtime-fold/runtime.json')
assert rt['status']=='UNIVERSAL_MATHEMATICAL_PASS'
assert rt['table_sha256']==sha(NATIVE)and rt['sites_sha256']==sha(SOURCE)
assert rt['checker_sha256']==sha('verification/code/runtime/symbolic_runtime.py')
assert rt['helper_sha256']==sha('verification/code/runtime/independent_runtime.py')
assert rt['proved_cases']==rt['expected_cases']==6176 and rt['site_count']==len(rows)==4751
assert not rt['failures'] and rt['startup_status']=='EXACT_OUTWARD_RAY'
casefile=P/'evidence/runtime-fold/runtime_cases.json.gz'
cases=json.loads(gzip.decompress(casefile.read_bytes()))
expected=[(i,pos)for i,(p,op,arg)in enumerate(rows)for pos in((False,True)if op=='CD'else(False,))]
assert[(c['site_index'],c['positive'])for c in cases]==expected
assert all(c['duration'][0]>0 and all(x>=0 for x in c['duration'])for c in cases)
m={int(k):int(v)for k,v in load('verification/code/inputs/legacy_mapping.json').items()}
for q in states|{254}:m.setdefault(q,q+1000)
assert len({m[q]for q in states|{254}})==215
covered={tuple(x)for c in cases for x in c['rows']}
for block in rt['blocks']:
 for step in block['trace']:
  if step[0]in('literal','unary'):covered.add(tuple(step[1][:2]))
assert covered=={(m[q],b)for q,b in t}
# Exact blank replay; the induction premise is checked on the full finite support.
q=h=0;ones=set();trace=[]
for tick in range(85):
 b=int(h in ones);w,d,z=t[q,b];trace.append([q,h,b,w,d,z])
 if w:ones.add(h)
 else:ones.discard(h)
 q,h=z,h+d
assert(q,h,ones)==(35,7,{-3,-2})
assert t[q,0]==(1,1,q)and all(x<h for x in ones)
st=load('evidence/runtime-fold/startup.json')
assert st['steps']==85 and st['status']=='EXACT_OUTWARD_RAY'and st['trace']==trace
# The retagged source has exactly the same guarded ordinal computation.
spec=importlib.util.spec_from_file_location('source_language',P/'reference/source_language.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
new=load('data/source-retagging/sites_no_cc3.json')
assert s.graph_arithmetic(rows)[0]==s.graph_intervals(rows)==s.graph_arithmetic(new)[0]==s.graph_intervals(new)
changes=[]
for i,(a,b)in enumerate(zip(rows,new)):
 assert a[1]==b[1]
 if a[2]!=b[2]:assert a[1:] ==['CC',3]and b[1:]==['CC',2];changes.append(i)
assert len(changes)==517
assert s.metrics(s.tree(rows))['dag_nodes']==202
assert s.metrics(s.tree(new))=={'dag_nodes':203,'leaf_occurrences':4751,'maximum_depth':46,'maximum_zero_run':6}
# If supplied, a manifest is checked without trusting its interpretation of files.
manifest=P/'MANIFEST.sha256'
manifest_count=0
if manifest.exists():
 for line in manifest.read_text().splitlines():
  digest,name=line.split('  ',1);rel=Path(name)
  assert not rel.is_absolute()and'..'not in rel.parts
  assert sha(rel)==digest, name
  manifest_count+=1
print(json.dumps({'status':'RESEARCH_PACKET_CHECKED_TARGET_NOT_MET',
 'runtime_cases':len(cases),'runtime_rows_covered':len(covered),
 'minimum_duration_constant':min(c['duration'][0]for c in cases),
 'symbolic_rule_applications':sum(c['symbolic_steps']for c in cases),
 'retagged_CC3_occurrences':len(changes),'blank_ray_time':85,
 'manifest_files_checked':manifest_count},indent=2))
