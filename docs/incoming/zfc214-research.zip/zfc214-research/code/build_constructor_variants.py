#!/usr/bin/env python3
"""Reproduce alternative constructor encodings as exact source-only experiments.

Six equality macro intervals are isolated with the complete guarded CFG fixed.
Every subsequent changed constructor is closed; all retained CFG edges are
checked. The source cost does not constitute a binary state count or runtime proof.
The finite proof-transport theorem in the report handles raw numerical junk.
"""
from pathlib import Path
import argparse,functools,hashlib,importlib.util,json,sys
PARENT_SHA='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
EXPECTED={
 'swap_Q_E':'ef53e999baa6ccf29eafd5e86cf8ef76ac2d15d365c8a1b68e5634a20f4e9918',
 'binary_huffman':'6ef32f835241574c689a9dc2bfb039d0a7a2a762d43c5ea5e167064cc6c2a487',
 'ternary_huffman':'b70b6de99cc8a803bf60ce9038b8d85ab45d06cb69a6479505097c41c287969b',
 'nested_I0_R1_Q2_E3':'e5ed930632f47fd3501273d0bfe27d80428082c5aeba8fb2c581a49019aea449',
 'nested_I0_R1_Q3_E2':'11c52d438cc74ef0518263163c727d6671851768f33ea3e7e5a76323db24b3c3',
}
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--parent',type=Path,required=True)
 ap.add_argument('--inputs',type=Path,default=Path(__file__).resolve().parents[1]/'data'/'constructor-inputs')
 ap.add_argument('--output',type=Path,required=True)
 a=ap.parse_args();assert __debug__ and not sys.flags.optimize
 spec=importlib.util.spec_from_file_location('source_language',a.parent/'source_language.py')
 s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 raw=(a.parent/'sites215.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==PARENT_SHA
 rows=json.loads(raw);tree=s.tree(rows);g=s.graph_intervals(rows);assert g==s.graph_arithmetic(rows)[0]
 def tup(x):return tuple(map(tup,x))if isinstance(x,list)else x
 macros={k:tup(v)for k,v in json.loads((a.inputs/'macros215.json').read_text()).items()}
 @functools.lru_cache(None)
 def length(t):return 1 if s.leaf(t)else length(t[0])+length(t[1])
 def seq(x,y):return y if x is None else x if y is None else(x,y)
 def splice(t,lo,hi,new):
  assert 0<=lo<hi<=length(t)
  if lo==0 and hi==length(t):return new
  assert not s.leaf(t)
  left,right=t;na=length(left)
  if hi<=na:return(splice(left,lo,hi,new),right)
  if lo>=na:return(left,splice(right,lo-na,hi-na,new))
  def take(t,n):
   if n==0:return None
   if n==length(t):return t
   x,y=t;nx=length(x)
   return take(x,n)if n<=nx else seq(x,take(y,n-nx))
  def drop(t,n):
   if n==0:return t
   if n==length(t):return None
   x,y=t;nx=length(x)
   return drop(y,n-nx)if n>=nx else seq(drop(x,n),y)
  return seq(seq(take(left,lo),new),drop(right,hi-na))
 I4=macros['I'];inc=('CI',1);E4=(macros['R'],(inc,inc))
 axlo=next(i for i,(p,_,_)in enumerate(rows)if p.startswith('1101001001'))
 Eintervals=[(axlo+i,axlo+i+n)for i,k,n in json.loads((a.inputs/'ax_macro_parse.json').read_text())if k=='E']
 assert len(Eintervals)==6
 normalized=tree
 for lo,hi in reversed(Eintervals):normalized=splice(normalized,lo,hi,E4)
 base_rows=s.sites(normalized)
 assert [r[1:]for r in base_rows]==[r[1:]for r in rows]
 assert s.graph_intervals(base_rows)==g==s.graph_arithmetic(base_rows)[0]
 assert s.metrics(normalized)=={'dag_nodes':205,'leaf_occurrences':4751,'maximum_depth':46,'maximum_zero_run':10}
 assert I4[1][1][0]==('CD',7)and I4[1][1][1][1]==('CC',2)
 @functools.lru_cache(None)
 def adds(n):
  assert n>0
  return inc if n==1 else(adds(n//2),adds(n-n//2))
 def pairscale(k):return(I4[0],(I4[1][0],(('CD',7),(adds(k),('CC',2)))))
 def linear(k,t):
  p=pairscale(k)
  return p if t==0 else(p,adds(t))
 I1=pairscale(1);core=I1[1];assert s.boundary(core)==(0,0,False)
 @functools.lru_cache(None)
 def addX(n):
  return None if n==0 else('CI',6)if n==1 else(addX(n//2),addX(n-n//2))
 def nested(t):return(I1,seq(addX(t),core))
 variants=[
  ('swap_Q_E','k*P(a,b)+tag',{'I':(4,0),'R':(4,1),'Q':(4,3),'E':(4,2)},linear),
  ('binary_huffman','k*P(a,b)+tag',{'I':(2,0),'R':(4,1),'Q':(8,3),'E':(8,7)},linear),
  ('ternary_huffman','k*P(a,b)+tag',{'I':(3,0),'R':(3,1),'Q':(6,2),'E':(6,5)},linear),
  ('nested_I0_R1_Q2_E3','P(tag,P(a,b))',{'I':(0,),'R':(1,),'Q':(2,),'E':(3,)},nested),
  ('nested_I0_R1_Q3_E2','P(tag,P(a,b))',{'I':(0,),'R':(1,),'Q':(3,),'E':(2,)},nested)]
 roots={'E':E4,'Q':macros['Q'],'R':macros['R'],'I':I4}
 a.output.mkdir(parents=True,exist_ok=True);results=[]
 for name,description,coding,constructor in variants:
  change={roots[k]:(k,constructor(*v))for k,v in coding.items()};replacements=[]
  def rewrite(t,path=''):
   if t in change:
    k,new=change[t];assert s.boundary(t)==s.boundary(new)==(0,0,False)
    replacements.append((path,k,new));return new
   return t if s.leaf(t)else(rewrite(t[0],path+'0'),rewrite(t[1],path+'1'))
  new=rewrite(normalized);nr=s.sites(new);ng=s.graph_intervals(nr);assert ng==s.graph_arithmetic(nr)[0]
  ni={p:i for i,(p,_,_)in enumerate(nr)};spans=[]
  for path,k,node in replacements:
   old=[i for i,(p,_,_)in enumerate(base_rows)if p.startswith(path)]
   fresh=[i for i,(p,_,_)in enumerate(nr)if p.startswith(path)]
   spans.append((path,k,min(old),max(old)+1,min(fresh),max(fresh)+1))
  def remap(i):
   for path,k,lo,hi,nlo,nhi in spans:
    if lo<=i<hi:
     assert i==lo,('outside edge enters replaced interior',name,i,path)
     return nlo
   return ni[base_rows[i][0]]
  kept=edges=0
  for i,(p,op,arg)in enumerate(base_rows):
   if any(p.startswith(path)for path,k,node in replacements):continue
   j=ni[p];assert nr[j]==base_rows[i]
   eff,targets=g[i];assert ng[j]==[eff,[remap(k)for k in targets]],(name,i,j)
   kept+=1;edges+=len(targets)
  counts={k:sum(kind==k for p,kind,node in replacements)for k in roots}
  assert counts=={'E':6,'Q':21,'R':12,'I':42}
  data=s.compact(nr);sha=hashlib.sha256(data).hexdigest();assert sha==EXPECTED[name]
  filename=name+'.json';(a.output/filename).write_bytes(data)
  results.append({'name':name,'file':filename,'sha256':sha,'constructor_form':description,
   'coding':coding,'constructor_occurrences':counts,'metrics':s.metrics(new),
   'guard_cases':sum(2 if op=='CD'else 1 for p,op,arg in nr),
   'retained_primitive_occurrences':kept,'retained_guarded_edges':edges,
   'two_cfg_resolvers_agree':True,'outside_entries_only_at_roots':True})
 result={'status':'SOURCE_CONSTRUCTORS_BUILT_AND_RETAINED_CFG_CHECKED','parent_source_sha256':PARENT_SHA,
  'normalization_preserves_word_and_all_guarded_edges':True,'equality_intervals':Eintervals,
  'normalization_metrics':s.metrics(normalized),'variants':results,
  'scope':'Source-only implementation cost. No binary allocation or runtime proof; logical transport is proved in the report with the inherited dominated-rho dependency.'}
 (a.output/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
