#define main inherited_main
#include "search_general.cpp"
#undef main
#include <chrono>
int partial(int q,int bits,int a,int b,int branch,Row action){
 auto&old=traces[q][bits];C y{q==b?a:q,0,bits};
 for(int n=0;n<=N;n++){
  if(n)for(const C&z:old)if(y.q==(z.q==b?a:z.q)&&y.h==z.h&&y.bits==z.bits)return 1;
  if(y.h<-R||y.h>R||!present[y.q])break;
  int sym=y.bits>>(y.h+R)&1;
  if(y.q==a&&sym!=branch)return 2;
  Row r=y.q==a?action:T[y.q][sym];if(r.t==b)r.t=a;y=perform(y,r);
 }
 return 0;
}
int main(int argc,char**argv){
 ifstream f(argv[1]);string line;while(getline(f,line)){if(line.empty()||line[0]=='#')continue;int q,b,w,t;char d;istringstream s(line);s>>q>>b>>w>>d>>t;T[q][b]={w,d=='R'?1:-1,t};present[q]=true;}
 ifstream cf(argv[2]);int q,n;while(cf>>q>>n){for(int j=0;j<n;j++){int b;cf>>b;ctx[q].push_back(b);}}
 vector<int>qs;for(int q=0;q<400;q++)if(present[q]&&q!=84){qs.push_back(q);for(int b:ctx[q])traces[q][b]=traj(q,b);}
 for(int w:{0,1})for(int d:{-1,1})for(int t=0;t<400;t++)if(present[t] || t==254)actions.push_back({w,d,t});
 long paircount=0,combinations=0,partial_pass=0,totalpass=0;auto started=chrono::steady_clock::now();
 for(int a:qs)for(int b:qs)if(a<b){
  vector<pair<int,int>>quick[2],all;
  for(int q:{a,b})for(int bit:{0,1}){vector<int>v;for(int x:ctx[q])if((x>>R&1)==bit)v.push_back(x);if(v.empty())continue;quick[bit].push_back({q,v.front()});if(v.size()>1)quick[bit].push_back({q,v.back()});if(v.size()>2)quick[bit].push_back({q,v[v.size()/2]});}
  for(int q:{a,b})for(int bits:ctx[q])all.push_back({q,bits});
  vector<int>options[2];
  for(int branch:{0,1})for(int i=0;i<(int)actions.size();i++){if(actions[i].t==b)continue;bool ok=true;for(auto[q,bits]:quick[branch])if(!partial(q,bits,a,b,branch,actions[i])){ok=false;break;}if(ok)options[branch].push_back(i);}
  partial_pass+=options[0].size()+options[1].size();
  for(int r0:options[0])for(int r1:options[1]){combinations++;bool ok=true;for(int branch:{0,1}){for(auto[q,bits]:quick[branch])if(!check(q,bits,a,b,actions[r0],actions[r1])){ok=false;break;}if(!ok)break;}if(!ok)continue;for(auto[q,bits]:all)if(!check(q,bits,a,b,actions[r0],actions[r1])){ok=false;break;}if(ok){totalpass++;auto x=actions[r0],y=actions[r1];cout<<"PASS "<<a<<" "<<b<<" "<<x.w<<" "<<x.d<<" "<<x.t<<" "<<y.w<<" "<<y.d<<" "<<y.t<<endl;}}
  paircount++;if(paircount%1000==0)cerr<<"pairs "<<paircount<<" combinations "<<combinations<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<endl;
 }
 cerr<<"DONE pairs "<<paircount<<" combinations "<<combinations<<" partialchoices "<<partial_pass<<" passes "<<totalpass<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<endl;
}
