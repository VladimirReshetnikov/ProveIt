#!/usr/bin/env python3
"""Build the 214-state runtime fold and prove its specific blank-start ray.

This is deliberately not a verifier of Con(ZFC) equivalence. The exact blank
run enters an elementary outward ray, so this table fails the required bootstrap.
Universal primitive-runtime derivations are separate evidence in the packet.
"""
from pathlib import Path
import argparse, hashlib, json, sys
EXPECTED='06cdddee109e178fb1b398316a393ac2897b3763d5dcbce31968a5840c2e893a'

def read(raw):
 rows={};starts=[]
 for line in raw.decode('ascii').splitlines():
  if line.startswith('#! start '):starts.append(int(line[9:]));continue
  if not line or line.startswith('#'):continue
  q,b,w,d,t=line.split();q,b,w,t=map(int,(q,b,w,t))
  assert (q,b)not in rows and b in (0,1)and w in (0,1)and d in ('L','R')
  rows[q,b]=(w,1 if d=='R'else -1,t)
 assert starts==[0]
 states={q for q,b in rows};assert set(rows)=={(q,b)for q in states for b in (0,1)}
 assert {t for w,d,t in rows.values()}-states=={254}
 return rows

def raw_table(rows):
 return ('#! start 0\n'+''.join(f'{q} {b} {w} {"R" if d==1 else "L"} {t}\n'
  for(q,b),(w,d,t)in sorted(rows.items()))).encode('ascii')

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--parent-table',type=Path,required=True)
 ap.add_argument('--output',type=Path,required=True)
 a=ap.parse_args();assert __debug__ and not sys.flags.optimize
 parent_raw=a.parent_table.read_bytes();T=read(parent_raw);assert len(T)==430
 for k,v in { (88,0):(0,1,122),(88,1):(1,1,103),(51,0):(0,1,16),
  (51,1):(1,1,51),(301,0):(0,1,45),(301,1):(1,1,103),(87,0):(0,1,301),
  (77,1):(1,1,88),(122,0):(0,-1,137),(137,0):(0,1,30),(30,0):(0,1,45),
  (16,1):(0,-1,1),(122,1):(0,-1,1),(35,0):(1,1,35)}.items():assert T[k]==v,(k,T[k],v)
 assert [k for k,v in T.items()if v[2]==301]==[(87,0)]
 assert [k for k,v in T.items()if v[2]==88]==[(77,1)]
 T[88,0]=(0,-1,51);T[51,0]=(0,1,122)
 T={k:(w,d,88 if t==301 else t)for k,(w,d,t)in T.items()if k[0]!=301}
 assert len(T)==428 and len({q for q,b in T})==214
 data=raw_table(T);assert hashlib.sha256(data).hexdigest()==EXPECTED
 # Check the two exact local paths with arbitrary outside values represented by
 # a forbidden-cell set: neither computation may inspect any cell outside {-1,0}.
 local=[]
 for marker,steps,end in [(1,3,122),(0,5,45)]:
  tape={-1:marker,0:0};q,h=88,0;trace=[]
  for _ in range(steps):
   assert h in tape
   bit=tape[h];w,d,nq=T[q,bit];trace.append([q,h,bit,w,d,nq]);tape[h]=w;q,h=nq,h+d
  assert (q,h,tape)==(end,1,{-1:marker,0:0})
  local.append({'predecessor_bit':marker,'steps':steps,'end_state':end,'trace':trace})
 # Independent literal replay of the complete startup.
 ones=set();q=h=0;trace=[]
 for tick in range(85):
  bit=int(h in ones);w,d,nq=T[q,bit];trace.append([q,h,bit,w,d,nq])
  if w:ones.add(h)
  else:ones.discard(h)
  q,h=nq,h+d
 assert (q,h,ones)==(35,7,{-3,-2})
 assert T[q,0]==(1,1,q)and all(x<h for x in ones)
 result={'status':'EXACT_OUTWARD_RAY','steps':85,'state':q,'head':h,
  'write':1,'direction':1,'one_cells':sorted(ones),'trace':trace,
  'ray_proof':'All cells at or right of head are zero; row 35/0 writes1, movesR, and stays35. Induction proves nonhalting.',
  'scope':'Invalid blank bootstrap, not a Con(ZFC) candidate.'}
 a.output.mkdir(parents=True,exist_ok=True)
 (a.output/'k214-runtime-only.native.tm').write_bytes(data)
 (a.output/'startup_independent.json').write_text(json.dumps(result,indent=2)+'\n')
 summary={'status':'EXACT_RUNTIME_FOLD_BUILT_BUT_BLANK_BOOTSTRAP_FAILS',
  'parent_table_sha256':hashlib.sha256(parent_raw).hexdigest(),'table_sha256':EXPECTED,
  'working_states':214,'rows':428,'local_decoder_identities':local,
  'blank_start':{k:v for k,v in result.items()if k!='trace'}}
 (a.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
