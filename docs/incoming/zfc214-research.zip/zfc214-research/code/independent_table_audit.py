#!/usr/bin/env python3
"""Independent standard-library table, source-prefix, and dense-isomorphism audit.
This does not replace the arbitrary-natural primitive proof or blank-start check.
"""
from pathlib import Path
from collections import defaultdict
import argparse,hashlib,json

def sha(raw):return hashlib.sha256(raw).hexdigest()
def parse(raw,halt):
 rows={};start=[]
 for line in raw.decode('ascii').splitlines():
  if line.startswith('#! start '):start.append(int(line[9:]));continue
  if not line or line.startswith('#'):continue
  q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
  assert(q,b)not in rows and b in(0,1)and w in(0,1)and d in('L','R')
  rows[q,b]=(w,-1 if d=='L'else 1,z)
 states={q for q,b in rows};assert start==[0]
 assert set(rows)=={(q,b)for q in states for b in(0,1)}
 assert{z for w,d,z in rows.values()}-states=={halt}
 return rows

def serialize(T):
 return ('#! start 0\n'+''.join(f'{q} {b} {w} {"L"if d==-1 else"R"} {z}\n'for(q,b),(w,d,z)in sorted(T.items()))).encode('ascii')
def reachable(T,start,halt):
 reach={start};todo=[start]
 for q in todo:
  for b in(0,1):
   z=T[q,b][2]
   if z!=halt and z not in reach:reach.add(z);todo.append(z)
 return reach

def internal_prefixes(rows):
 leaves={p:(op,arg)for p,op,arg in rows};nodes=set()
 for p in leaves:
  nodes.update(p[:j]for j in range(len(p)))
 assert not(nodes&set(leaves))
 assert all(p+'0'in nodes or p+'0'in leaves for p in nodes)
 assert all(p+'1'in nodes or p+'1'in leaves for p in nodes)
 return sorted(nodes,key=lambda p:(len(p),p))
def prefix_binding(T,p):
 tape={-1:1,**{j:int(c)for j,c in enumerate(p)}};initial=dict(tape);q=84;h=0;ticks=0
 while h!=len(p):
  assert h in tape,('outside prefix',p,q,h)
  assert ticks<10000,('prefix timeout',p)
  w,d,q=T[q,tape[h]];tape[h]=w;h+=d;ticks+=1
 assert tape==initial,('prefix changed',p)
 return q,ticks

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--baseline',type=Path,required=True);ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--source',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 oldraw=a.baseline.read_bytes();newraw=a.candidate.read_bytes();srcraw=a.source.read_bytes()
 assert sha(oldraw)=='9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2'
 assert sha(srcraw)=='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
 T=parse(oldraw,254);N=parse(newraw,254)
 assert T[301,0]==(0,1,45)and T[301,1]==(1,1,103)
 assert T[88,0]==(0,1,122)and T[88,1]==(1,1,103)
 assert T[51,0]==(0,1,16)and T[51,1]==(1,1,51)
 incoming=[list(k)for k,act in sorted(T.items())if act[2]==301];assert incoming==[[87,0]]
 R={(q,b):(w,d,88 if z==301 else z)for(q,b),(w,d,z)in T.items()if q!=301}
 R[88,0]=(0,-1,51);R[51,0]=(0,1,122)
 assert R==N and serialize(R)==newraw
 states={q for q,b in N};assert len(states)==214 and len(N)==428
 assert{q for q,b in T}-states=={301}and reachable(N,0,254)==states
 assert not any(z==301 for w,d,z in N.values())
 rows=json.loads(srcraw);prefixes=internal_prefixes(rows);assert len(prefixes)==4750
 prefixrows=[];oldroles=defaultdict(list);newroles=defaultdict(list)
 for p in prefixes:
  qo,to=prefix_binding(T,p);qn,tn=prefix_binding(N,p)
  assert qn==(88 if qo==301 else qo),(p,qo,qn)
  oldroles[qo].append(p);newroles[qn].append(p)
  prefixrows.append([p,qo,qn,to,tn])
 mapping={q:i for i,q in enumerate(sorted(states))};mapping[254]=214
 C={(mapping[q],b):(w,d,mapping[z])for(q,b),(w,d,z)in N.items()};dense=serialize(C)
 assert set(q for q,b in C)==set(range(214))and mapping[0]==0 and mapping[84]==83
 inverse={v:k for k,v in mapping.items()};undo={(inverse[q],b):(w,d,inverse[z])for(q,b),(w,d,z)in parse(dense,214).items()};assert undo==N
 (a.output/'k214.tm').write_bytes(dense)
 canonical={'status':'EXACT_REVERSIBLE_TABLE_ISOMORPHISM_PASS','method':'ascending native working-state labels, terminal214','native_sha256':sha(newraw),'canonical_sha256':sha(dense),'native_to_canonical':mapping,'canonical_to_native':inverse,'start_native':0,'start_canonical':0,'dispatch_native':84,'dispatch_canonical':83,'halt_native':254,'halt_canonical':214}
 (a.output/'canonicalization.json').write_text(json.dumps(canonical,indent=2)+'\n')
 recipe={'base_table_sha256':sha(oldraw),'unchanged_source_sha256':sha(srcraw),'drop_native_state':301,'redirect_target':88,'incoming_redirects':incoming,'replacement_rows':[[88,0,0,-1,51],[51,0,0,1,122]],'expected_native_sha256':sha(newraw),'expected_canonical_sha256':sha(dense),'working_states':214,'rows':428}
 (a.output/'table_recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
 receipt={'status':'INDEPENDENT_STRUCTURAL_AND_PREFIX_AUDIT_PASS','scope':'Exact reconstruction, table totality, graph reachability, all literal source internal prefixes, and reversible dense renaming. Primitive runtime and blank startup are separate obligations.','baseline_sha256':sha(oldraw),'source_sha256':sha(srcraw),'native_sha256':sha(newraw),'dense_sha256':sha(dense),'working_states':214,'transition_rows':428,'graph_reachable_working_states':len(states),'terminal_native':254,'terminal_dense':214,'start':0,'source_primitive_occurrences':len(rows),'checked_internal_prefixes':len(prefixes),'old_decoder_entry_states':len(oldroles),'new_decoder_entry_states':len(newroles),'folded_old_paths':oldroles[301],'retained_old_paths':oldroles[88],'row_changes':[[*k,*T[k],*N[k]]for k in sorted(set(T)&set(N))if T[k]!=N[k]],'removed_rows':[[*k,*T[k]]for k in sorted(set(T)-set(N))],'maximum_prefix_duration_old':max(r[3]for r in prefixrows),'maximum_prefix_duration_new':max(r[4]for r in prefixrows),'code_sha256':sha(Path(__file__).read_bytes())}
 (a.output/'audit.json').write_text(json.dumps(receipt,indent=2)+'\n');(a.output/'prefix_bindings.json').write_text(json.dumps(prefixrows,separators=(',',':'))+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
