from pathlib import Path
import sys,json,time,hashlib
from collections import deque,Counter
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
B=Path(__file__).resolve().parents[1]/'reference'
sys.path.insert(0,str(B));import source_language as s
rows=json.loads((B/'sites215.json').read_text());graph=s.graph_intervals(rows);assert graph==s.graph_arithmetic(rows)[0]
K=8;TOP=(1<<(K+1))-1;TAIL=1<<K

def inc(v):return ((v<<1)&TOP)|(v&TAIL)
def dec(v):return (v>>1)|(v&TAIL)
def edges(i,v):
 pc,op,arg=rows[i];targets=graph[i][1]
 if op=='CH':return []
 if op=='CI':
  u=list(v);u[arg]=inc(v[arg]);return [(targets[0],tuple(u))]
 if op=='CD':
  out=[]
  if v[arg]&1:
   u=list(v);u[arg]=1;out.append((targets[0],tuple(u)))
  if v[arg]&~1:
   u=list(v);u[arg]=dec(v[arg]&~1);out.append((targets[1],tuple(u)))
  return out
 return [(targets[0],v)]
initial=(1<<4,)+(1,)*8
states=[None]*len(rows);states[0]=initial;todo=deque([0]);queued={0};updates=0
while todo:
 i=todo.popleft();queued.remove(i)
 for j,v in edges(i,states[i]):
  old=states[j];new=tuple(a|b for a,b in zip(old,v)) if old is not None else v
  if new!=old:
   states[j]=new;updates+=1
   if j not in queued:todo.append(j);queued.add(j)
assert all((old is not None and all((a|b)==a for a,b in zip(old,v))) for i in range(len(rows)) if states[i] is not None for j,v in edges(i,states[i]) for old in [states[j]])
assert all(a&b==b for a,b in zip(states[0],initial))
fixed=Counter();impossible=[]
for i,(site,v) in enumerate(zip(rows,states)):
 if v is None:continue
 for r,m in enumerate(v):
  if m<TAIL and m.bit_count()==1:fixed[r]+=1
 if site[1]=='CD':
  if not(v[site[2]]&1):impossible.append((i,False))
  if not(v[site[2]]&~1):impossible.append((i,True))
out={'status':'INDUCTIVE_ABSTRACT_INVARIANT_CHECKED','domain':'singleton 0..7, tail >=8, independent finite unions','initial':initial,'source_sha256':hashlib.sha256((B/'sites215.json').read_bytes()).hexdigest(),'states':states,'unreachable_sites':[i for i,v in enumerate(states) if v is None],'impossible_guards':impossible,'fixed_counts':dict(fixed),'updates':updates}
a.output.write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k not in ['states','impossible_guards']});print('impossible_guards',len(impossible),impossible[:40]);print('selected',[(i,rows[i],states[i]) for i in [21,4737,4746]])
