#!/usr/bin/env python3
"""Conservative radius-four runtime contexts under the unit-reservoir invariant.

Requires the included symbolic-runtime helper; uses only Python's standard
library. Default inputs are relative to this archive, and output paths are
explicitly overridable. This proves primitive contracts and collects contexts;
it does not validate any new blank-start machine.
"""
from pathlib import Path
import sys,json,time,functools,math,argparse,hashlib
if not __debug__ or sys.flags.optimize:
 raise RuntimeError('Assertions must be enabled for mathematical checking')
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--reference',type=Path,default=ROOT/'reference')
ap.add_argument('--verification',type=Path,default=ROOT/'verification/code')
ap.add_argument('--output',type=Path,default=ROOT/'data/search-contexts/unit_spares_callers.txt')
ap.add_argument('--mode',choices=('conservative','caller'),default='caller',help='Use opaque unit-block exteriors, or the actual caller exterior')
ap.add_argument('--max-sites',type=int,default=None,help='Partial diagnostic run only; omitted for the complete proof')
args=ap.parse_args();C=args.reference;OUT=args.output
OUT.parent.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(args.verification/'runtime'))
import symbolic_runtime as s
T=s.r.table(C/'k215.native.tm')
m={int(k):int(v) for k,v in json.loads((args.verification/'inputs/legacy_mapping.json').read_text()).items()}
for q,b in T:m.setdefault(q,q+1000)
m.setdefault(254,254)
assert len(set(m.values()))==len(m), 'State map is not injective'
inv={v:k for k,v in m.items()}
L={(m[q],b):(w,d,m[z]) for(q,b),(w,d,z)in T.items()}
R=4;seen={q:set() for q,b in T};orig=s.State.step;calls=0;unary=0;list_iterations=0
REVERSE={n:[int(format(v,f'0{n}b')[::-1],2) if n else 0 for v in range(1<<n)] for n in range(R+2)}
@functools.lru_cache(maxsize=100000)
def prefix(atoms,n):
 if n==0:return frozenset([0])
 if not atoms:raise AssertionError('No exterior in prefix')
 a,*rest=atoms;rest=tuple(rest)
 if a==s.BLANK:return frozenset([0])
 if a[0]=='opaque':return frozenset(range(1<<n))
 if a[0]=='run':
  bit,expr=a[1:];k=expr[0];g=math.gcd(*expr[1:]);out=set()
  if k>=n:return frozenset([(1<<n)-1 if bit else 0])
  lens=[k] if not g else list(range(k,n,g))+[n]
  for length in lens:
   if length>=n:out.add((1<<n)-1 if bit else 0)
   else:
    pre=(1<<length)-1 if bit else 0
    for tail in prefix(rest,n-length):out.add(pre|(tail<<length))
  return frozenset(out)
 if a[0]=='list':
  family,reverse=a[1],a[3];out=set(prefix(rest,n))
  # Invariant: the finite spare tail contains only value-one blocks.
  # We still quantify over arbitrary list length, including zero.
  for value in (1,):
   word=([0]+[1]*(value+1)) if family=='B' else ([1,0]+[1]*value)
   if reverse:word=word[::-1]
   if len(word)>=n:out.add(sum(x<<i for i,x in enumerate(word[:n])))
   else:
    pre=sum(x<<i for i,x in enumerate(word))
    for tail in prefix((a,)+rest,n-len(word)):out.add(pre|(tail<<len(word)))
  return frozenset(out)
 raise AssertionError(a)

def add_context(q,d,src,dst):
 if d==1:
  for x in src:
   for y in dst:seen[q].add(REVERSE[R][y]|(x<<R))
 else:
  for x in src:
   for y in dst:seen[q].add(REVERSE[R+1][x]|(y<<(R+1)))

def prefixed(bit,length,rest,n):
 if length>=n:return frozenset([(1<<n)-1 if bit else 0])
 pre=(1<<length)-1 if bit else 0
 return frozenset(pre|(t<<length) for t in prefix(rest,n-length))

def observe_list_iteration(obj,table,lemmas):
 # Every actual list traversal consists of zero or more proved unit-block
 # traversals. At any particular iteration, the already consumed output
 # list and the remaining input list have independent nonnegative lengths.
 # Surround both with the actual caller's unchanged exterior. The prefix
 # enumerator independently expands the two lists, a sound overapproximation.
 global list_iterations
 d=obj.direction
 src,dst=(obj.right,obj.left) if d==1 else (obj.left,obj.right)
 a=src[0];key=(obj.q,d,a[1],a[3]);after=lemmas[key]
 consumed=('list',after,a[2],not a[3])
 unit=s.block(s.num(1),a[1])
 produced=s.block(s.num(1),after)
 if d==1:
  state=s.State(obj.q,[consumed]+dst,unit+[a]+src[1:],d)
  target=s.State(obj.q,s.rev(produced)+[consumed]+dst,[a]+src[1:],d)
 else:
  state=s.State(obj.q,s.rev(unit)+[a]+src[1:],[consumed]+dst,d)
  target=s.State(obj.q,[a]+src[1:],produced+[consumed]+dst,d)
 steps=s.ZERO;motion=s.ZERO
 for _ in range(10):
  if state.key()==target.key():break
  current=state.right if state.direction==1 else state.left
  assert current[0][0]!='list',('Unit traversal reached a list early',state.key())
  steps,motion,event=observe(state,table,{},steps,motion)
 else:raise AssertionError(('Caller-relative unit schema did not close',key))
 assert steps==s.num(3) and motion==s.num(3*d)
 list_iterations+=1

def observe(obj,table,lemmas,clock,motion):
 global calls,unary
 obj.key();q=inv[obj.q];d=obj.direction;calls+=1
 src=tuple(obj.right if d==1 else obj.left);dst=tuple(obj.left if d==1 else obj.right)
 add_context(q,d,prefix(src,R+1),prefix(dst,R))
 if src and src[0][0]=='run':
  a=src[0];row=table[obj.q,a[1]]
  if row[2]==obj.q and row[1]==d:
   unary+=1;k=a[2][0];g=math.gcd(*a[2][1:]);b=a[1];w=row[0]
   # i=consumed cells; j=remaining cells including the current cell.
   # i==R and j==R+1 stand for their respective unbounded upper classes.
   for i in range(R+1):
    dp=prefixed(w,i,dst,R)
    for j in range(1,R+2):
     lower=i+j;unbounded=i==R or j==R+1
     if g:
      possible=unbounded or (lower>=k and (lower-k)%g==0)
     else:possible=(k>=lower if unbounded else k==lower)
     if possible:add_context(q,d,prefixed(b,j,src[1:],R+1),dp)
 if args.mode=='caller' and src and src[0][0]=='list':observe_list_iteration(obj,table,lemmas)
 return orig(obj,table,lemmas,clock,motion)
# Establish inherited general block lemmas without collecting their broader
# arbitrary-spare neighborhoods. Only actual unit-spare schemas below contribute.
beg=time.time();lemmas,blocks=s.prove_blocks(L)
def unit_file_bits(values,append=None):
 atoms=[]
 for value in values:atoms+=s.block(value)
 atoms+=s.block(s.num(1))+[s.tail()]
 if append is not None:
  assert append==1
  atoms+=s.block(s.num(append))
 return atoms+[s.BLANK]
s.file_bits=unit_file_bits
s.State.step=observe
unit_blocks=[]
if args.mode=='conservative':
 for q,d,before,after in [(73,1,'B','B'),(95,1,'B','C'),(48,-1,'B','B'),(112,-1,'C','B')]:
  left=('opaque','left');right=('opaque','right');v=s.num(1)
  if d==1:
   state=s.State(q,[left],s.block(v,before)+[right])
   target=s.State(q,s.rev(s.block(v,after))+[left],[right])
  else:
   state=s.State(q,s.rev(s.block(v,before))+[left],[right],-1)
   target=s.State(q,[left],s.block(v,after)+[right],-1)
  steps=s.ZERO;motion=s.ZERO;trace=[]
  for _ in range(50):
   if state.key()==target.key():break
   steps,motion,event=state.step(L,{},steps,motion);trace.append(event)
  else:raise AssertionError(('Unit one-block schema did not close',q,d))
  assert steps==s.num(3) and motion==s.num(3*d)
  unit_blocks.append({'entry':q,'direction':d,'before':before,'after':after,'value':1,'trace':trace})
sites=json.loads((C/'sites215.json').read_text())
expected_cases=sum(2 if site[1]=='CD' else 1 for site in sites)
selected_sites=sites if args.max_sites is None else sites[:args.max_sites]
proved_cases=0
for i,site in enumerate(selected_sites):
 for pos in ((False,True) if site[1]=='CD' else (False,)):
  s.case(L,lemmas,site,pos);proved_cases+=1
 if i%1000==0:print(i,round(time.time()-beg,1),prefix.cache_info(),flush=True)
with OUT.open('w')as f:
 for q,vals in sorted(seen.items()):f.write(f'{q} {len(vals)} '+' '.join(map(str,sorted(vals)))+'\n')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt={
 'status':'UNIT_RESERVOIR_UNIVERSAL_MATHEMATICAL_PASS' if proved_cases==expected_cases else 'PARTIAL_DIAGNOSTIC_ONLY',
 'scope':'Arbitrary natural primary registers and gap; nonempty finite reservoir consisting only of spare value1. Startup supplies40 unit spares; CI appends1 and all primitives preserve old spares. Runtime contexts only; no new blank-start acceptance.',
 'mode':args.mode,'cases':proved_cases,'expected_cases':expected_cases,
 'unit_blocks':unit_blocks,'caller_relative_unit_schemas':list_iterations,
 'runtime_calls':calls,'unary_calls':unary,'radius':R,
 'context_count':sum(map(len,seen.values())),
 'contexts':{q:sorted(v) for q,v in seen.items()},
 'table_sha256':sha(C/'k215.native.tm'),'sites_sha256':sha(C/'sites215.json'),
 'checker_sha256':sha(__file__),'runtime_helper_sha256':sha(s.__file__),
 'independent_runtime_sha256':sha(s.r.__file__),
 'seconds':time.time()-beg,
}
OUT.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('DONE',round(time.time()-beg,1),receipt['context_count'],proved_cases,receipt['status'],flush=True)
