#!/usr/bin/env python3
"""Audit every dominated-rho8 leaf needed for constructor-independent recovery.

Run the two pinned forward proof checkers, then independently extract a literal
implicational path from each nonzero U to A. These witness paths justify U<=A
for every constructor algebra with I(0,0)=0 and coordinate dominance. No numeric
sampling, arbitrary substitution in the private theory, or order-preserving
proof-transport assumption is used.
"""
from pathlib import Path
import argparse,collections,functools,hashlib,importlib.util,json,sys

def module(path,name):
 spec=importlib.util.spec_from_file_location(name,path)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--source149',type=Path,default=Path(__file__).resolve().parents[1]/'data'/'source149')
 ap.add_argument('--output',type=Path,required=True)
 a=ap.parse_args();assert __debug__ and not sys.flags.optimize
 provenance=json.loads((a.source149/'provenance.json').read_text())
 for record in provenance['members']:
  raw=(a.source149/record['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==record['sha256']
 certificate=a.source149/'theory'/'dominated_rho8_full_certificate.json'
 first=module(a.source149/'theory'/'check_classical_compact.py','source149_shared')
 second=module(a.source149/'audits'/'audit_classical_independent.py','source149_nested')
 r1=first.check(certificate);r2=second.audit(certificate)
 assert r1['verified']and r2['verified']and r1['proof_nodes']==r2['proof_nodes']==3728
 assert r1['roots']['rho8']==r2['roots']['rho8']==3727
 # Own term DAG decoder and structural witness finder. Canonical nodes contain
 # only ('T',), ('v',number), or ('I',canonical_left,canonical_right).
 data=json.loads(certificate.read_text());canon=[('T',)];intern={canon[0]:0};mapping=[]
 def put(x):
  if x not in intern:intern[x]=len(canon);canon.append(x)
  return intern[x]
 for i,t in enumerate(data['term_table']):
  if t=='T':j=0
  elif isinstance(t,dict):
   assert set(t)=={'var'}and type(t['var'])is int and t['var']>=0;j=put(('v',t['var']))
  else:
   assert isinstance(t,list)and len(t)==2 and all(type(k)is int and 0<=k<i for k in t)
   x,y=[mapping[k]for k in t];j=0 if x==y==0 else put(('I',x,y))
  mapping.append(j)
 def parts(x):
  if x==0:return 0,0
  t=canon[x];assert t[0]=='I';return t[1],t[2]
 @functools.lru_cache(None)
 def path(x,u):
  if x==u:return ''
  if canon[x][0]!='I':return None
  for bit,child in enumerate(canon[x][1:]):
   suffix=path(child,u)
   if suffix is not None:return str(bit)+suffix
  return None
 witnesses=[];counts=collections.Counter()
 for node in data['nodes']:
  if node['rule']['kind']!='dominated_rho8':continue
  t=mapping[node['term']];pre,post=parts(t);cu,A=parts(pre);C,U=parts(cu)
  ac,bc=parts(post);A2,C2=parts(ac);B,C3=parts(bc)
  assert A==A2 and C==C2==C3
  if U==0:kind='zero';p=None
  else:
   p=path(A,U);assert p is not None
   kind='self'if p==''else'proper_implication_subterm'
   x=A
   for bit in p:x=parts(x)[int(bit)]
   assert x==U
  counts[kind]+=1
  witnesses.append({'proof_node':node['id'],'term_table_root':node['term'],
   'kind':kind,'path_from_A_to_U':p,'depth':None if p is None else len(p)})
 assert len(witnesses)==r1['rules']['dominated_rho8']==r2['rules']['dominated_rho8']
 result={'status':'ALL_DOMINATED_RHO8_LEAVES_HAVE_CONSTRUCTOR_INDEPENDENT_WITNESSES',
  'certificate_sha256':hashlib.sha256(certificate.read_bytes()).hexdigest(),
  'proof_nodes':3728,'rho8_root':3727,'forward_check_shared':r1,'forward_check_nested':r2,
  'leaf_witness_kinds':dict(counts),'witnesses':witnesses,
  'mathematical_consequence':'For every numerical I with I(0,0)=0 and I(a,b)>=a,b, all these schematic dominated axioms remain valid for every natural assignment. Substituting implications preserves the exhibited path or collapses U to0; induction over the finite proof recovers unrestricted rho8.'}
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items()if k!='witnesses'},indent=2))
if __name__=='__main__':main()
