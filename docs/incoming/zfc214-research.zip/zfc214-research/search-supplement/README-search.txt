BOUNDED LOCAL SYNTHESIS SUPPLEMENT

Status
------
The search found the 88/301 fold with helper51. Its resulting 214-state table
passes all6176 symbolic runtime cases, but its blank start enters an exact
outward ray after85steps. No completed search in this supplement repairs the
blank start. The final radius8 searches also admit arbitrary primary tuples
as structural seeds:57failure-tail families and39entry-row families all
completed without a seed, a subprocess error, or a startup step-bound exit. Negative search results are not state-count lower bounds.

Portable tools
--------------
The C++ programs take a native transition table and a context catalogue.
A catalogue line is STATE COUNT MASK..., with mask bit j recording the tape
symbol at position j-R relative to the current head. The radius is a compile
setting and must agree with the catalogue. All states must have labels below
399; native halt254 and dispatcher84 are built into the bootstrap recognizer.

From the packet root, after copying this supplement's code files into code/:

  c++ -O3 -std=c++17 code/merge_with_helper.cpp -o merge_with_helper
  ./merge_with_helper reference/k215.native.tm data/search-contexts/precise.txt 88 301 51

This reproduces the successful runtime fold. The program synthesizes both rows
of retained state A and both rows of helper P, deletes state B, and redirects
all old B targets to A. A positive result is a finite common-configuration
certificate over the supplied local contexts. It still requires a complete
symbolic runtime check and an independently checked blank startup.

  c++ -O3 -std=c++17 code/repair_bootstrap.cpp -o repair_bootstrap
  ./repair_bootstrap data/runtime-fold/k214-runtime-only.native.tm data/search-contexts/core214-direct.txt 51 50 -1

The final argument is a free row bit,0 or1; -1 frees both rows of A. Both rows
of helper P are free. Each locally accepted mutation is tested from all214
working states on the blank tape, to200000steps, stopping exact outward rays.
A structural seed requires empty PC, gap>=0, nine primary blocks, and at least
one spare block. By default physical blocks0,2,7 must also be zero. Appending
"any-seed" accepts any primary tuple as a structural candidate; logical seed
soundness must then be proved separately. No finite search proves that a
configuration failing to appear before the step bound never appears.

Radius8 search uses:

  c++ -O3 -std=c++17 -DDIAGRAM_RADIUS=8 -DDIAGRAM_STEPS=40 code/repair_bootstrap.cpp -o repair_bootstrap8

The default is radius4 and20steps. The local rule requires positive progress
on both sides and exact equality of state, head, and every tape cell in the
window at a common endpoint. A simulation leaving the represented window is
rejected; it is not treated as equivalent. Targets include all retained working
states and halt254. The search allows mutually compensating rewrites, not only
individually equivalent row replacements.

Collecting contexts
-------------------
The portable collector imports the packet's independent symbolic runtime
modules and reruns every guarded primitive case. It includes intermediate
unary-loop configurations; affine run lengths are overapproximated using their
minimum and coefficient gcd, while list contexts retain the B/C block grammar.
Independent choices deliberately forget correlations, so the result is a sound
overapproximation rather than an exact reachable-configuration language.

  python code/collect_contexts.py . reference/k215.native.tm reference/sites215.json precise.txt --radius 4
  python code/collect_contexts.py . data/runtime-fold/k214-runtime-only.native.tm reference/sites215.json core214-direct.txt --radius 4
  python code/collect_contexts.py . reference/k215.native.tm reference/sites215.json precise8.txt --radius 8
  python code/transport_contexts.py precise8.txt data/runtime-fold/k214-runtime-only.native.tm core214-contexts8.txt --radius 8

The transport tool adds all intermediate contexts of the3-step and5-step
88/301 simulations and the2-step ordinary51 refinement. Newly exposed exterior
bits are arbitrary. This is safe but sometimes loose: transporting radius4
loses the fifth predecessor bit of old301. Incoming-edge analysis shows that
four consecutive predecessor zeros at old301 force the fifth predecessor bit
to1. A fresh direct core collection avoids this loss entirely and also removes
obsolete ordinary16 contexts.

Evidence and scope
------------------
search-summary.json gives per-batch counts and SHA-256 digests. Compressed raw
receipts retain individual families, stdout, stderr, and return codes. Search
families and startup attempts include duplicates; these are not counts of
distinct transition tables. Wall-clock times are observational and irrelevant
to the mathematical certificates. The portable source was checked by replaying
the known88/301/51 positive fold and a negative51/50 bootstrap family.

The initial broad shared-row helper batch used only working-state action
targets; later unit-spare and bootstrap searches include halt254. This omission
does not affect the displayed positive fold. Earlier narrower and finite-only
screens are documented separately in the parent packet; they are not claimed
to exhaust all possible semantic changes.
