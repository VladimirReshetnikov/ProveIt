#include "local_diagrams.hpp"
#include <chrono>
int A,B,P; Row chosen[4];bool assigned[4];vector<pair<int,int>> tests;long nodes=0,checks=0,passes=0;auto started=chrono::steady_clock::now();
int partial(int q,int bits){
 auto &old=traces[q][bits];C y{q==B?A:q,0,bits};
 for(int n=0;n<=N;n++){
  if(n)for(const C&z:old)if(y.q==(z.q==B?A:z.q)&&y.h==z.h&&y.bits==z.bits)return -1;
  if(y.h<-R||y.h>R||!present[y.q])return -2;
  int sym=y.bits>>(y.h+R)&1;int slot=y.q==A?sym:(y.q==P?2+sym:-1);
  if(slot>=0&&!assigned[slot])return slot;
  Row r=slot>=0?chosen[slot]:T[y.q][sym];if(r.t==B)r.t=A;y=perform(y,r);
 }return -2;
}
void dfs(int depth){
 nodes++;if(nodes%1000000==0)cerr<<"nodes "<<nodes<<" checks "<<checks<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<endl;
 array<int,4> blockers{};int missing=-1;
 for(auto[q,bits]:tests){checks++;int v=partial(q,bits);if(v==-2)return;if(v>=0){blockers[v]++;missing=v;}}
 if(missing<0){passes++;cout<<"PASS "<<A<<" "<<B<<" helper "<<P;for(int j=0;j<4;j++){auto r=assigned[j]?chosen[j]:T[j<2?A:P][j%2];cout<<" | "<<r.w<<" "<<r.d<<" "<<r.t;}cout<<endl;return;}
 int slot=max_element(blockers.begin(),blockers.end())-blockers.begin();assigned[slot]=true;
 for(Row r:actions){if(r.t==B)continue;chosen[slot]=r;dfs(depth+1);}
 assigned[slot]=false;
}
int main(int argc,char**argv){
 if(argc<6){cerr<<"usage: merge_with_helper TABLE CONTEXTS A B P [SLOT WRITE DIRECTION TARGET]\n";return 2;}
 ifstream f(argv[1]);string line;while(getline(f,line)){if(line.empty()||line[0]=='#')continue;int q,b,w,t;char d;istringstream s(line);s>>q>>b>>w>>d>>t;T[q][b]={w,d=='R'?1:-1,t};present[q]=true;}
 ifstream cf(argv[2]);int q,n;while(cf>>q>>n){for(int j=0;j<n;j++){int b;cf>>b;ctx[q].push_back(b);}}
 A=stoi(argv[3]);B=stoi(argv[4]);P=stoi(argv[5]);
 for(int w:{0,1})for(int d:{-1,1})for(int t=0;t<400;t++)if(present[t]||t==254)actions.push_back({w,d,t});
 for(int q:{A,B,P})for(int bits:ctx[q]){traces[q][bits]=traj(q,bits);tests.push_back({q,bits});}
 if(argc>6){int slot=stoi(argv[6]);chosen[slot]={stoi(argv[7]),stoi(argv[8]),stoi(argv[9])};assigned[slot]=true;}
 cerr<<"SEARCH "<<A<<" "<<B<<" helper "<<P<<" contexts "<<tests.size()<<endl;dfs(0);
 cerr<<"DONE nodes "<<nodes<<" checks "<<checks<<" passes "<<passes<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<endl;
}
