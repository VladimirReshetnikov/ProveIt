#include <array>
#include <unordered_map>
#ifndef DIAGRAM_RADIUS
#define DIAGRAM_RADIUS 4
#endif
#ifndef DIAGRAM_STEPS
#define DIAGRAM_STEPS 20
#endif
#include <vector>
#include <set>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <tuple>
#include <algorithm>
using namespace std;
struct Row {int w,d,t; bool operator==(const Row&a)const{return w==a.w&&d==a.d&&t==a.t;}};
struct C {int q,h,bits;};
Row T[400][2];bool present[400];vector<int>ctx[400];const int R=DIAGRAM_RADIUS,N=DIAGRAM_STEPS;
vector<Row> actions;vector<int>alts[400][2];
C perform(C x,Row r){return {r.t,x.h+r.d,(x.bits&~(1<<(x.h+R)))|(r.w<<(x.h+R))};}
vector<C> traj(int q,int bits){C x{q,0,bits};vector<C>v;for(int n=0;n<N;n++){if(x.h<-R||x.h>R||!present[x.q])break;x=perform(x,T[x.q][x.bits>>(x.h+R)&1]);v.push_back(x);}return v;}
unordered_map<int,vector<C>> traces[400];
bool local(int q,int bits,Row r){auto&old=traces[q][bits];C y=perform({q,0,bits},r);for(int n=1;n<=N;n++){for(const C&z:old)if(y.q==z.q&&y.h==z.h&&y.bits==z.bits)return true;if(y.h<-R||y.h>R||!present[y.q])break;y=perform(y,T[y.q][y.bits>>(y.h+R)&1]);}return false;}
bool check(int q,int bits,int a,int b,Row r0,Row r1){auto&old=traces[q][bits];C y{q==b?a:q,0,bits};for(int n=0;n<=N;n++){if(n)for(const C&z:old)if(y.q==(z.q==b?a:z.q)&&y.h==z.h&&y.bits==z.bits)return true;if(y.h<-R||y.h>R||!present[y.q])break;int sym=y.bits>>(y.h+R)&1;Row r=y.q==a?(sym?r1:r0):T[y.q][sym];if(r.t==b)r.t=a;y=perform(y,r);}return false;}
