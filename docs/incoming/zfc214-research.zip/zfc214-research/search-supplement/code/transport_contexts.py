from pathlib import Path
import json,hashlib
import argparse
ap=argparse.ArgumentParser(description='Transport a baseline context catalogue through the88/301/51 fold.')
ap.add_argument('baseline_contexts',type=Path)
ap.add_argument('core_table',type=Path)
ap.add_argument('output',type=Path)
ap.add_argument('--radius',type=int,default=4)
args=ap.parse_args();R=args.radius
contexts={}
for line in args.baseline_contexts.read_text().splitlines():
 q,n,*m=map(int,line.split());assert len(m)==n;contexts[q]=set(m)
new={q:set(v) for q,v in contexts.items() if q!=301}
new[88].update(contexts[301])
T={}
for line in args.core_table.read_text().splitlines():
 if line and not line.startswith('#'):
  q,b,w,d,z=line.split();T[int(q),int(b)]=(int(w),1 if d=='R' else -1,int(z))
def addtrace(oldq,bits,steps,startq):
 for left in[0,1]:
  for right in[0,1]:
   tape={j-R:(bits>>j)&1 for j in range(2*R+1)};tape[-R-1]=left;tape[R+1]=right;q=startq;head=0
   for tick in range(steps):
    assert head in[-1,0,1]
    mask=sum(tape[head+j-R]<<j for j in range(2*R+1))
    new.setdefault(q,set()).add(mask)
    w,d,q=T[q,tape[head]];tape[head]=w;head+=d
for q,steps in[(88,3),(301,5)]:
 for bits in contexts[q]:
  if not(bits>>R&1):addtrace(q,bits,steps,88)
for bits in contexts[51]:
 if not(bits>>R&1):
  assert bits>>(R+1)&1
  addtrace(51,bits,2,51)
args.output.write_text(''.join(f'{q} {len(v)} '+' '.join(map(str,sorted(v)))+'\n' for q,v in sorted(new.items())))
report={'baseline_context_sha256':hashlib.sha256(args.baseline_contexts.read_bytes()).hexdigest(),'core214_table_sha256':hashlib.sha256(args.core_table.read_bytes()).hexdigest(),'old_patterns':sum(map(len,contexts.values())),'transported_patterns':sum(map(len,new.values())),'changed_counts':{q:[len(contexts.get(q,[])),len(new.get(q,[]))]for q in sorted(set(contexts)|set(new))if contexts.get(q,set())!=new.get(q,set())},'description':'Conservative union of baseline contexts with old301 mapped88 and all intermediate windows of exact fold/refinement diagrams. Both newly exposed exterior bits are quantified independently.'}
args.output.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
