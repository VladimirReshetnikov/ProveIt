#include "local_diagrams.hpp"
#include <chrono>
bool strict_seed=true;
int A,B,P; Row chosen[4];bool assigned[4];vector<pair<int,int>> tests;long nodes=0,checks=0,passes=0,seeds=0,starttests=0,bounds=0;auto started=chrono::steady_clock::now();
int partial(int q,int bits){
 auto &old=traces[q][bits];C y{q==B?A:q,0,bits};
 for(int n=0;n<=N;n++){
  if(n)for(const C&z:old)if(y.q==(z.q==B?A:z.q)&&y.h==z.h&&y.bits==z.bits)return -1;
  if(y.h<-R||y.h>R||!present[y.q])return -2;
  int sym=y.bits>>(y.h+R)&1;int slot=y.q==A?sym:(y.q==P?2+sym:-1);
  if(slot>=0&&!assigned[slot])return slot;
  Row r=slot>=0?chosen[slot]:T[y.q][sym];if(r.t==B)r.t=A;y=perform(y,r);
 }return -2;
}

Row current(int q,int bit){int slot=q==A?bit:(q==P?2+bit:-1);return slot>=0&&assigned[slot]?chosen[slot]:T[q][bit];}
bool calibrated(int q,int h,const set<int>&ones,vector<int>&logical,int &gap){
 if(q!=84||ones.empty()||*ones.begin()!=h-1)return false;auto it=ones.begin();++it;if(it==ones.end()||*it<h+64)return false;int header=*it,p=header+1,last=*ones.rbegin();vector<int>v;
 while(p<=last){if(ones.count(p)||!ones.count(p+1))return false;p++;int n=0;while(ones.count(p)){n++;p++;}v.push_back(n-1);}
 if(v.size()<10)return false;
 if(strict_seed&&(v[0]||v[2]||v[7]))return false;int phy[]={6,2,0,4,3,7,8,5,1};logical.clear();for(int i:phy)logical.push_back(v[i]);gap=header-h-64;return true;
}
void checkstartup(){
 bool changed=false;for(int q:{A,P})for(int bit:{0,1})if(!(current(q,bit)==T[q][bit]))changed=true;if(!changed)return;
 vector<int>order{0,A,P};for(int q=0;q<400;q++)if(present[q]&&q!=0&&q!=A&&q!=P)order.push_back(q);
 for(int start:order){int q=start,h=0,gap=0;set<int>ones;vector<int>regs;starttests++;
  for(long ticks=0;ticks<=200000;ticks++){
   if(calibrated(q,h,ones,regs,gap)){seeds++;cout<<"SEED A "<<A<<" P "<<P<<" start "<<start<<" ticks "<<ticks<<" gap "<<gap<<" regs";for(int v:regs)cout<<" "<<v;for(int z:{A,P})for(int bit:{0,1}){auto r=current(z,bit);cout<<" | "<<z<<" "<<bit<<" "<<r.w<<" "<<r.d<<" "<<r.t;}cout<<endl;break;}
   if(q==254||!present[q])break;int bit=ones.count(h);auto r=current(q,bit);if(!bit&&r.t==q&&(ones.empty()||(r.d>0&&h>*ones.rbegin())||(r.d<0&&h<*ones.begin())))break;if(ticks==200000){bounds++;break;}if(r.w)ones.insert(h);else ones.erase(h);h+=r.d;q=r.t;
  }
 }
}
void dfs(int depth){
 nodes++;if(nodes%1000000==0)cerr<<"nodes "<<nodes<<" checks "<<checks<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<endl;
 array<int,4> blockers{};int missing=-1;
 for(auto[q,bits]:tests){checks++;int v=partial(q,bits);if(v==-2)return;if(v>=0){blockers[v]++;missing=v;}}
 if(missing<0){passes++;checkstartup();return;}
 int slot=max_element(blockers.begin(),blockers.end())-blockers.begin();assigned[slot]=true;
 for(Row r:actions){if(r.t==B)continue;chosen[slot]=r;dfs(depth+1);}
 assigned[slot]=false;
}
int main(int argc,char**argv){
 if(argc<6){cerr<<"usage: repair_bootstrap TABLE CONTEXTS A P FREEBIT [any-seed]\n";return 2;}
 strict_seed=!(argc>6&&string(argv[6])=="any-seed");
 ifstream f(argv[1]);string line;while(getline(f,line)){if(line.empty()||line[0]=='#')continue;int q,b,w,t;char d;istringstream s(line);s>>q>>b>>w>>d>>t;T[q][b]={w,d=='R'?1:-1,t};present[q]=true;}
 ifstream cf(argv[2]);int q,n;while(cf>>q>>n){for(int j=0;j<n;j++){int b;cf>>b;ctx[q].push_back(b);}}
 A=stoi(argv[3]);B=399;P=stoi(argv[4]);int freebit=stoi(argv[5]);
 for(int w:{0,1})for(int d:{-1,1})for(int t=0;t<400;t++)if(present[t]||t==254)actions.push_back({w,d,t});
 for(int q:{A,B,P})for(int bits:ctx[q]){traces[q][bits]=traj(q,bits);tests.push_back({q,bits});}
 if(freebit>=0){assigned[1-freebit]=true;chosen[1-freebit]=T[A][1-freebit];}
 cerr<<"SEARCH "<<A<<" "<<B<<" helper "<<P<<" contexts "<<tests.size()<<endl;dfs(0);
 cerr<<"DONE nodes "<<nodes<<" checks "<<checks<<" passes "<<passes<<" startup_tests "<<starttests<<" bounds "<<bounds<<" seeds "<<seeds<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<endl;
}
