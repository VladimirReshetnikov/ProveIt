# Decidable Gates, Undecidable State Transfer

**Dense rational rotations, polynomial-time membership, a fifth-order input
recurrence, and Diophantine certificates**

Research article prepared for the ProveIt project, September 30, 2026.

## Contents

- `article.pdf`: the compiled 23-page article.
- `article.tex`: complete LaTeX source, including its bibliography.
- `code/rotations.py`: exact rational quaternion arithmetic, free-word decoders,
  inverse-spin reconstruction, a presentation-to-rotation compiler, Miller
  normal forms, matrix membership, finite-trace certificates, and the
  fifth-order target recurrence.
- `code/verify.py`: deterministic exact-arithmetic verification.
- `verification_results.json`: results from the distributed verification run.
- `source_manifest.json`: repository revision and primary-source provenance.
- `build.sh`: recompiles the PDF and reruns the checks.
- `SHA256SUMS`: hashes of the other distributed files.

## Main result

The article proves the existence of one fixed finite symmetric set of rational
four-dimensional rotation gates, with denominators using only the prime 5,
such that membership of a complete rational transformation is polynomial-time
decidable, but exact reachability from one fixed small rational state is
computably enumerable complete. The same gates have another fixed rational
state whose orbit membership is polynomial-time decidable. Both orbits are
disjoint and dense; the gate group is dense in SO(4).

Hard target queries can be restricted to a rational sequence satisfying a
common linear recurrence of order at most five. Positive-tolerance transfer
has a computable uniform control-length bound, whereas exact transfer has no
recursive worst-case bound on control length or transfer-matrix denominator
in terms of target bit length.

The finite-length construction is an explicit quartic sum of squares. MRDP
then gives a fixed unbounded polynomial representation; ordinary circuit
lifting can make this fixed polynomial quartic with more auxiliary variables.

## Mathematical status and boundaries

This is a proved structural synthesis and algorithmic refinement built from
classical Higman, Mihailova, Miller, free-rotation, and MRDP constructions.
Historical priority for the complete combination has not been established.
The article does not claim to discover rotation reachability undecidability
for the first time or to settle finite-fold Diophantine representation.

The fixed hard finite presentation is obtained from Higman's embedding
theorem. The complete numerical hard gate list and a fully expanded fixed
universal polynomial are not printed or generated here. The presentation
compiler is explicit and executable once its finite input is supplied.
A fully specified 20-gate example based on <x | x^2> illustrates the compiler
and certificates, but is not the universal hard instance.

The article's new mathematics is not formalized in Lean. Existing ProveIt
MRDP source was inspected, but no new Lean build or axiom audit was run.
Finite tests check local algebra and implementations, not the infinite
freeness, density, or undecidability theorems. Those rest on the proofs and
the named imported theorems.

## Run the exact checks

Requires Python 3.10 or later; no third-party Python packages.

```sh
python3 code/verify.py
```

Run without Python's `-O` flag, since the verification program uses assertions.
The program writes `verification_results.json` next to this README. It uses
seed 20260930 and exact integers / `fractions.Fraction`, never floating-point
acceptance tests. The distributed run passes all checks, including all 4,373
reduced binary free-group words of length at most seven, 100 spin/membership
round trips, finite trace corruption checks, and 240 coordinate-recurrence
identities.

Word generators in the code are signed **one-based** integers; the article's
free generators x_0,...,x_(r-1) correspond to 1,...,r. Gate labels in certificate
traces are **zero-based**. The order and chronological multiplication
conventions are documented in Appendix A and the code.

## Rebuild the PDF

Requires a standard LaTeX distribution with pdfLaTeX and the packages listed
in the preamble (Latin Modern, AMS packages, microtype, geometry, booktabs,
tabularx, enumitem, xcolor, xurl, hyperref, fancyhdr, and listings).

```sh
sh build.sh
```

Alternatively:

```sh
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build article.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build article.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build article.tex
cp build/article.pdf article.pdf
```

The distributed PDF was built with pdfTeX 1.40.26. Its final build had no
LaTeX warnings, undefined references, or overfull/underfull box messages.
All pages were rendered and visually inspected; the contents and bibliography
were rechecked after the final layout adjustments.

## Repository anchor

Inspected ProveIt commit:
`b6bf6406a4c49017fedc6fba068b36c634987150`

Public MRDP endpoint:
`Computability/HilbertTenthProblem/Lean/Diophantine/MRDP.lean`

The repository was read, not modified. The bibliography in the article and
`source_manifest.json` distinguish primary mathematical sources from the
repository's formal endpoint and explanatory documentation.
