PARITY-MOMENT CANCELLATION AT EVERY ORDER
Sharp variance, Wasserstein closure, and explicit moment-indeterminate laws
Research manuscript prepared for the ProveIt project, 7 October 2026

MAIN DELIVERABLES

article.pdf                 Complete article with proofs and research questions.
article.tex                 Main LaTeX source.
sections/                   Self-contained mathematical sections and bibliography.
figures/                    Vector PDF and PNG of the prescribed-mean/support plot.
code/verify.py              Exact rational checks; optional moment diagnostics.
code/make_figures.py        Regenerates the scientific plot and table fragments.
data/verification_results.json
                            Recorded exact checks and numerical diagnostics.
data/*_table.tex            Generated rounded table displays used by the article.
SOURCE_PROVENANCE.json      Pinned upstream revisions, inspected sources, scope.
VALIDATION.json             Build, proof-review, computation, and visual QA record.
SHA256SUMS                  Integrity hashes for the packaged files.
Makefile                    Convenience build targets.

RESEARCH SCOPE

The article resolves the higher-codimension alternating-moment question in
ProveIt's square-root-degree-bound report at the inspected revision:

  E[(-1)^Y Y^j] = 0 for 0 <= j < k
  implies sharp variance infimum 3/4 for every k >= 3, and also for all
  cancellation orders imposed simultaneously. The infimum is not attained
  at any k >= 4 or at infinite order.

The additional principal results are the exact W_p closure of the all-order
class, the full prescribed-mean infimum and attainment classification,
minimum atom counts and quantitative support bounds, sharp stretched-
exponential tail ranges, explicit q-product probabilities, and all-orders
fixed-truncation Mellin and inverse asymptotic expansions.

The moment condition is necessary for a low-degree Boolean cube cell.
The article does not resolve the actual-cell realization problem, improve
the Boolean Fourier degree exponent, or claim a new Lean formalization.
Historical priority is not asserted over the general moment-problem
literature. See the article for the exact novelty and proof-status scope.

BUILD THE PDF

From this directory:

  latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

or:

  make pdf

The PDF build uses the included figure PDF and table sources, so Python is
not needed merely to compile the article. The packages used are ordinary
TeX Live packages: lmodern, amsmath, amssymb, amsthm, mathtools, geometry,
microtype, booktabs, array, longtable, enumitem, graphicx, xcolor, hyperref,
xurl, bookmark, and cleveref. No shell escape, external bibliography
processor, network connection, or external source file is required.

REPRODUCE THE COMPUTATIONS

Python 3.9 or newer is sufficient for the scripts.

  python3 code/verify.py

This checks 64 finite affine families at k = 3,...,18 and
R = 18, 32, 100, 1000, including 672 exact zero alternating-moment
equations, normalization, positivity, support size, strict nonattainment,
the variance upper bound, and equality of two probability formulas.
It also checks five exact order-four prescribed-mean extremizers.

The required checks use only the Python standard library. A failed check
raises an exception even when Python is run with optimization enabled.

To reproduce the optional numerical data in the supplied JSON:

  python3 code/verify.py --numerical

This additionally requires mpmath. It uses 100 decimal digits and 150 tail
terms for R = 32. These are diagnostics, not interval-certified proofs of
infinite identities or rigorous numerical remainder bounds.

Both verification commands replace data/verification_results.json. The
plain command omits numerical diagnostics; use --numerical before
regenerating the optional Mellin error table.

To regenerate the scientific plot and rounded tables:

  python3 code/make_figures.py

This requires numpy and matplotlib. The figure is generated from the
proved formulas, not from fitting or numerical optimization. The table
values are derived from verification_results.json. The included files
were generated with Python 3.12.14, mpmath 1.3.0, numpy 2.3.5, and
matplotlib 3.10.8.

SUGGESTED PROVEIT LOCATION

  Combinatorics/BooleanFunctions/Research/parity-moment-cancellation/

The package is self-contained and may be placed next to the existing
square-root-degree-bound report. The user can add links from the relevant
repository index and from the earlier report's research question. No
repository mutation, pull request, or integration has been performed.

INTEGRITY AND REVIEW

On systems with sha256sum, run from this directory:

  sha256sum -c SHA256SUMS

Checksums identify the delivered version. Rebuilding the PDF can change
its metadata and hash without changing the mathematical content.
The final validation record describes the exact checks and independent
mathematical review actually completed. Numerical checks supplement the
written proofs; they do not establish infinitely many equations. No
external peer review or Lean kernel verification is claimed.
