# Report 127: Sharp logarithmic deficit constants for two inversion sequence classes

This reader package contains a standalone proof, editable LaTeX source,
and an exact finite verification companion for A279556 (Class 759) and
A279551 (Class 247). With natural logarithms and

    S(n) = n^(1/3) (log n)^(2/3),

the proved asymptotics are

    log A279556(n) = n log 9 - (3 pi^2/2)^(1/3) S(n) + o(S(n)),
    log A279551(n) = n log 8 - (3 pi^2)^(1/3) S(n) + o(S(n)).

The constants are about 2.455445701568578 and 3.093667726280136,
respectively. These decimals evaluate the exact expressions; they are
not fits to sequence data. The growth constants are exactly 9 and 8.

This is a leading logarithmic asymptotic. It is **not a coefficient
asymptotic equivalent**. The exact multiplier, lower-order exponent
terms, polynomial factors, effective remainder, ratio expansion,
all-orders expansion, and transseries remain unproved here. In
particular, the local row's log-log correction is not a global
coefficient correction. No global priority claim is made.

## Mathematical contents

The combinatorial input is credited to the exact commitment trees of
Nathan Britt and Nicholas Beaton, arXiv:2512.21943v3, Sections 3.8-3.9.
The report reproduces the model and proves all analytical steps used:

- Decorated auxiliary histories, completed-path injectivity, legal
  initial-drop cutoff, and true terminal extraction
- Critical original-time substochastic weights and exact joint
  displacement-duration transforms, including zero commitments
- A uniform sharp local critical root with the actual drop CDF
- Legal-law moment estimates and a concavity-based drift estimate
- Separate genuine clock and reward martingales on a positive strip,
  plus the exact likelihood action without freezing any duration
- Uniform arbitrary-height entrance and every-integer residual-time
  repair, preserving all elementary multiplicities and bulk realizations
- A positive original-space-time supersolution, long-cycle/jump tails,
  a global spatial barrier, and exact-time coefficient extraction
- The singular variational minimum and both matching coefficient bounds

The earlier literal numerical forms with a fixed negative nonzero
n^(3/8) term cannot be full equivalents. This concerns those asymptotic
forms, not the source paper's finite enumerations or its exact trees;
the source explicitly calls its estimates nonrigorous numerical analysis.

## Consequences

For N(T)=min{n:a(n)>=T}, lambda=log(mu), s=log(T)/lambda, and the
corresponding sharp constant sigma,

    N(T) = s + (sigma/lambda) S(s) + o(S(s)).

No monotonicity or coefficient ratio theorem is assumed. The correction
coefficient in terms of log(T) is sigma/lambda^(4/3).

Writing F(z)=sum a(n)z^n, rho=1/mu, and
M_k=sum n^k a(n)mu^(-n), the boundary values are smooth and

    log M_k = 3k log k - 2k loglog k
              + [log(2D/pi^2)-3]k + o(k),

where D=1 for A279556 and D=1/2 for A279551. The same expression for
log F^(k)(rho) has the additional linear term k log(mu). This implies
sharp boundary Gevrey order 3 under the convention
||f^(k)|| <= C A^k (k!)^s. It is a derivative-growth conclusion, not a
next-order coefficient expansion.

## Read

- `report127.pdf`: complete standalone mathematical report
- `report127.tex`: editable source; no downloaded paper is needed to build
- `checks/README.md`: precise finite check ranges, provenance, and limits
- `data/verification_results.json`: exact checker reference output
- `data/negative_results.json`: mathematical/schema mutation reference

Finite checks supplement the proof. They cannot prove asymptotic
uniformity, the martingale or tail estimates, or any limiting theorem.

## Quick verification

Python 3.10 or newer is required. The authoritative checker uses only
the standard library, with no network access or installation:

    python3 -B integrity.py
    python3 -B checks/verify.py --output ../report127-results.json
    python3 -B checks/negative_tests.py --output ../report127-negative.json
    python3 -B test_integrity.py

Guards remain active under optimized Python (`python3 -B -O`). Both
inventories are closed: extra files or directories, missing members,
changed bytes, and symlinks fail validation. Inventories are integrity
records, not signatures; they do not protect against simultaneous
malicious replacement of the verifier and its inventory.

## Complete immutable offline replay

    python3 -B reproduce.py --output ../report127-replay.json

This validates the outer inventory, compares the exact checks in normal
and optimized Python bytewise, runs mathematical/schema and outer
inventory mutations, and builds the PDF twice in clean external
directories. It creates a deterministic ZIP, extracts a fresh copy,
repeats exact checks in both modes and double-clean PDF rebuilding,
and requires byte-identical repacking. Original source inventories
are checked again at the end. All work products remain outside the
reader directory.

For a checks-only replay when TeX is unavailable:

    python3 -B reproduce.py --skip-pdf --output ../report127-checks-only.json

The output explicitly records skipped PDF reconstruction; it does not
claim a full replay. The complete replay can take several minutes.

## PDF build

Requires pdfTeX/pdflatex and geometry, fontenc, Latin Modern, amsmath,
amssymb, amsthm, mathtools, booktabs, microtype, hyperref, and enumitem.

    bash build.sh
    python3 -B build.py --output ../rebuilt-report127.pdf

The default destination is `../build/report127.pdf`. The builder creates
fresh TeX formats in temporary directories, runs three passes in each
of two clean builds, rejects overfull boxes and unresolved references,
and requires identical bytes. It never overwrites the delivered PDF.
Exact byte replay is tested for the versions in `build-environment.txt`;
other versions may produce equivalent content with different bytes.

## Deterministic packaging

    python3 -B repack.py ../report127_reproducibility.zip

The ZIP contains one `report127/` directory. Member order, timestamps,
permissions, and compression settings are fixed. The zlib version is
recorded because it can affect bytes. No intermediate renders, build
logs, downloaded source papers, development notes, or fits are included.

After an intentional author-side edit, regenerate the outer inventory
with `python3 -B integrity.py --write`. This is not validation of an
unexpected change. Changes inside `checks/` need that companion's
separately maintained closed inventory regenerated as well.
