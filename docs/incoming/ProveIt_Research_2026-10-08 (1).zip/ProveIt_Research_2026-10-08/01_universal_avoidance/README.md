# A common avoiding set for stable recurrences and balanced P-recursive sequences

Research prepared for Vladimir Reshetnikov, developed with OpenAI ChatGPT, 8 October 2026.

## Result

For every epsilon in (0,1), there is one closed, symmetric, 1-periodic set F whose measure in every unit interval exceeds 1-epsilon. The same F has the following property simultaneously for every sequence in the class below: every translate of every nonzero scalar multiple has infinitely many terms outside F.

The sequence class consists of real, non-eventually-zero sequences a_n with eventual exponential decay and an eventual recurrence

    A_0(n) a_n + ... + A_d(n) a_(n+d) = 0,

where the A_i are real polynomials and

    deg A_0 = deg A_d = max_i deg A_i.

The manuscript calls this last condition balanced and defines that usage explicitly. The recurrence need not be minimal, and its parameters need not be rational or computable.

Consequences include one common set for:

- All stable constant-coefficient recurrence sequences, with arbitrary orders, nonreal roots, repeated roots, cancellations, exact zeros, and real initial values.
- All convergent C-finite sequences which are not eventually constant, after absorbing the limiting value into the translation.
- Balanced hypergeometric sequences with eventual exponential decay.
- Central binomial coefficients and Catalan numbers divided by 8^n.
- rho^n P_n(t), with 0<rho<1 and -1<=t<=1.
- Polynomial observations of stable finite-dimensional linear systems, after subtraction of the limiting value.

For rational epsilon, F can be effectively closed with computable measure on every bounded rational interval. This is a terminating existence algorithm based on real quantifier elimination, not an implemented efficient blocker constructor or a computable distance function.

The compact section F intersect [0,1] has the same near-full measure property and avoids every pattern in this class. A perfect compact subset of the same measure can also be taken; effectiveness of that perfect-subset operation is not claimed.

## Proof architecture

1. Replace the scalar magnitude by the maximum g_n of a finite recurrence state. A uniform inverse-state bound gives g_(n+1)>=alpha g_n.
2. At the first crossing of each geometric scale Q^j, choose a nonzero scalar coordinate. The signed samples satisfy alpha Q^j<|a_j|<=Q^j and uniform separation, even when earlier coordinates vanish.
3. Apply finite random routing with nested grids and ordered edge windows. All scalar values are rational functions of a fixed finite-dimensional parameter vector.
4. Count full polynomial sign conditions, including zero signs, to represent every relevant parameter choice before unexposed random entries are inspected.
5. Bound exceptional centers and repair them using a small open neighborhood and convergence of the original sequence to zero.
6. Exhaust balanced recurrence tails by countably many compact parameter families, then assemble reflected dyadic copies with a summable density budget.
7. Replace compactness by a terminating search over finite outer approximants and rational arc unions to obtain effective closedness and a computable measure modulus.

The abstract rational-family theorem also permits subexponential degree growth: log Delta_N=o(N). Polynomial growth is sufficient for the recurrence application.

## Dependency and novelty boundary

The ordered-tree routing mechanism is adapted from OpenAI family 084 and the earlier ProveIt uniform-geometric-avoidance continuation. It is reproved in full. Neither predecessor's main theorem is assumed.

The new extension relative to the inspected sources is the signed block sampling, its rational-parameter sign encoding, the compact balanced-recurrence exhaustion, and the effective outer-approximation argument. The earlier report explicitly proposed oscillatory recurrences as a future direction.

The only non-elementary general input in the existence proof is a classical finite polynomial sign-condition bound. The effective statement additionally uses real quantifier elimination. Standard measure-theoretic and linear-algebraic facts are used explicitly.

The general Erdos similarity conjecture is not proved. The theorem does not cover every P-recursive null sequence, arbitrarily rapidly decreasing sequences, or arbitrary infinite-dimensional collections with exponential upper and lower bounds. No assertion of historical priority or external peer review is made.

## Files and reproduction

- article.tex and four numbered TeX section files: complete article.
- article.pdf: compiled manuscript.
- code/verify_exact.py: standard-library exact verification.
- code/make_sampling_figure.py: optional Matplotlib figure generation from exact sequence values.
- code/README.md: detailed check scope.
- data/verification_results.json: deterministic verification receipt.
- figures/: the illustration in PDF and PNG form.
- SOURCE_AUDIT.md and provenance.json: pinned sources and claim boundaries.

From this directory:

```sh
python3 code/verify_exact.py --output data/verification_results.json
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Optional figure regeneration:

```sh
python3 code/make_sampling_figure.py
```

The exact script requires Python 3.10 or later. Plot regeneration additionally needs Matplotlib. The PDF can be rebuilt with standard TeX Live packages; no network access or source-report download is required.

## Verification performed

| Mechanism | Checks |
|---|---:|
| Independent recurrence formulas | 168 terms |
| Rational matrix-product representations | 896 terms |
| Rational signs, negative denominators and equalities | 2,184 comparisons |
| Half-open periodic boundaries | 51 boundary triples |
| Preorder windows and local spans | 24 cases |
| Exhaustive finite routing experiment | 65,536 event cases |

The local experiment gives exactly 625/1296=(1-1/6)^4. A deliberately shared terminal address changes the answer to 9/16, checking the necessity of the distinct-address hypothesis.

These are finite corroborations of the local mechanisms. The proofs establish the infinite and uncountable assertions. No proof-assistant formalization, real-quantifier-elimination implementation, or practical universal avoiding set is supplied.

## Suggested ProveIt integration

Proposed destination:

    Analysis/ErdosSimilarity/Research/stable-and-balanced-recurrence-avoidance/

Copy this entire directory so that the article's relative TeX and figure paths remain valid. The repository was only read during preparation. The source audit records the exact predecessor revision; later repository changes do not alter that comparison.

The eight research questions at the end of the article address polynomially growing inverse-state norms, larger parameter complexity, infinite mixtures and analytic observables, feasible finite blockers, formal certificates, computable geometry, slower decay, and multivariate patterns.
