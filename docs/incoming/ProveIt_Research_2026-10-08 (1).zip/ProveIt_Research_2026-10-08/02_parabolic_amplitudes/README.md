# A Common Density for Parabolic Iteration

This companion resolves explicit amplitude questions in the pinned ProveIt
Euler, Bell, and strict partition-chain reports. It contains a standalone
16-page article, complete new proofs, exact checks and independent floating
diagnostics.

## Main results

Let f(z) = exp(z) - 1 and H(n,m) = n! [z^n] f^{∘m}(z). Let P be the normalized
entire Fatou orbit, h its positive Laplace density, and I the compact-ratio
Bell amplitude.

1. **Exact identification:** I(t) = t 2^(t/3) h(t) for every t > 0.
2. **Analytic continuation:** h(z) = 2^(-z/3) I(z)/z is holomorphic for Re z > 0.
3. **Geometric depth aggregate:** for every L > 0,
   S_n(L) = Σ_m exp(-Lm) H(n,m) is asymptotic to
   (n!)² (2L)^(-n) n^(-1-L/3) L^(L/3-1) I(L), uniformly on compact L-intervals.
4. **Marked strict-chain amplitude:** with L(q) = log(1+1/q),
   C(q) = L(q)^(L(q)/3-1) I(L(q))/(q+1)
   = (2L(q))^(L(q)/3) h(L(q))/(q+1).
   This amplitude extends holomorphically to Re q > 0 and is positive for q > 0.
5. **Consequences:** exact Lengyel-constant identity at L = log 2, explicit
   density formulas for the constant terms in the chain-length mean and
   variance, and the small-t logarithmic expansion of the Bell amplitude.

The new proof uses the positive measures
μ_m = Σ_n [z^n] f^{∘m}(z) P(-m)^n δ_(n/m). Their masses are exactly P(0).
Their Laplace limits identify h, while the existing local Bell theorem
identifies I(t)/(t 2^(t/3)). A rational coefficient majorant controls all
depths in the geometric sum.

## Dependency and novelty boundary

Four analytic input statements are reproduced precisely in Section 2:

- Input F: normalized Fatou coordinate and entire orbit.
- Input M: positive Laplace measure with continuous density.
- Input L: absolute local Bell coefficient transfer, before division by I.
- Input A: holomorphy of the Bell contour amplitude.

These are ordinary results proved in the cited, unrefereed repository reports.
They are not Lean-verified facts. This companion proves the implication from
their interfaces and does not independently redo every earlier contour or
interval-certificate proof. It needs no numerical positivity seed for I(1);
it does not remove every other computational dependency of the Bell foundation.

The exact resolved labels are:

- ied:q:ibd — fully resolved.
- ied:q:analytic — real analyticity on the full positive axis resolved;
  analyticity of the germ at zero remains open.
- spc:q:depth — leading amplitude identification resolved;
  all-order summation and logarithmic cancellation remain open.
- spc:q:disk — amplitude continued to Re q > 0;
  complex zero-freeness and global uniform asymptotics remain open.

Prellberg's 2002 seminar summary already treats the parabolic bivariate
mechanism and an aggregate contour constant. It is credited explicitly.
No worldwide novelty, new leading-equivalent, or major open-conjecture
priority claim is made.

## Files

- article.tex, article.pdf — complete standalone article.
- code/verify_exact.py — exact finite count and coordinate checks.
- code/explore_density.py — independent exploratory inverse Laplace calculation.
- code/compare_counts.py — exact-count comparisons with that density.
- data/exact_checks.json — passed exact checks.
- data/density_160.json, data/density_320.json — two numerical runs.
- data/count_comparison.json — Bell and chain diagnostics.
- provenance.json — exact repository pin, source blobs, labels and literature.
- requirements.txt — Python dependencies for the optional calculations.

Raw copies of the three large source reports are not included.

## Reproduction

Use Python 3 with SymPy and mpmath available. From this directory:

```sh
python code/verify_exact.py --output data/exact_checks.json
python code/explore_density.py --steps 160 --degree 48 --output data/density_160.json
python code/explore_density.py --steps 320 --degree 64 --output data/density_320.json
python code/compare_counts.py --density data/density_320.json --output data/count_comparison.json
pdflatex -halt-on-error -interaction=nonstopmode article.tex
pdflatex -halt-on-error -interaction=nonstopmode article.tex
```

The counting portion uses standard-library integer and rational arithmetic.
SymPy checks the truncated Fatou equation; mpmath performs numerical inverse
Laplace transformation. No script uses network access. Reproduction overwrites
only the explicitly requested output paths.

## Validation actually performed

All exact finite checks passed:

- 960 coefficient-majorant inequalities.
- 144 independent Newton-basis evaluations of depth polynomials.
- 96 rational geometric-mixture identities.
- The four-term Fatou-coordinate Abel defect through degree five.

The two inverse-Laplace runs agree at least to 12 decimal places at
t = 1/2, log 2, 1, 2. These are **not interval-certified digits**.
The density-derived constant is approximately 1.098685805525187.
Exact chain counts, normalized using four previously proved correction
terms, agree to roughly 1e-15 by n = 320; this also is a diagnostic,
not a proof or a certified enclosure.

Bell ratios at beta = 2 are not monotone over the small sample n = 40,80,160:
the first logarithmic correction is large enough to change its trend.
The records are supplied as computed, with no assertion that every finite
ratio converges monotonically.

The final PDF compiles to 16 pages. Mathematical conclusions rely on
the proofs and their stated analytic inputs, not on this finite testing.

