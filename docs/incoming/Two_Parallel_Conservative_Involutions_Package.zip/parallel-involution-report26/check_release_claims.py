"""Check symbolic arithmetic and frozen receipt counts; no universal execution."""
import sys
sys.dont_write_bytecode=True
import json
from pathlib import Path
from verify_release import verify,ROOT,require


def main():
    verify(ROOT)
    data=json.loads((ROOT/'references/report19-audit-universal-count.json').read_text())
    m,p,a,J=[data[k] for k in ('m','p','a','J')]
    D=2*m+4*p;b=4*D+5;Z=10*b+10+2*J
    old=4*p*(6*D+8)+(8*p*D+23*p+m)*(24*D+32)+(2*p+a)*(Z+J+12*D+16)
    new=180*D+258+9*J
    require((D,old,new)==(509508,3292955588459274804,91711698),'universal symbolic arithmetic')
    require(8*p*D+29*p+m+a==269291358255,'template arithmetic')
    main=json.loads((ROOT/'scientific/test-receipt.json').read_text())
    periodic=json.loads((ROOT/'scientific/periodic-receipt.json').read_text())
    api=json.loads((ROOT/'scientific/api-receipt.json').read_text())
    require(main['status']==periodic['status']==api['status']=='passed','producer suite status')
    require(sum(r['exhaustive_words'] for r in periodic['runs'])==24576,'periodic count')
    require(sum(r['multiple_move_words'] for r in periodic['runs'])==520,'simultaneous count')
    require(api['invalid_input_or_mutation_rejections']==58,'API count')
    print(json.dumps({'status':'PASS','symbolic_universal_radius':new,'old_symbolic_radius':old,
                      'universal_rule_executed':False,'new_truth_table_emitted':False,
                      'api_rejections':58,'periodic_words':24576},indent=2))

if __name__=='__main__':main()
