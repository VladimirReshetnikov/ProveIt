"""Strict offline replay in fresh normal and optimized copies.

Usage: python3 -B replay.py --output NEW_EXTERNAL_DIRECTORY
No scientific code runs before the exact inventory and mandatory pins pass.
"""
import sys
sys.dont_write_bytecode = True
import argparse
import ast
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
from verify_release import ROOT, require, inventory, verify

SCIENTIFIC = ('test_parallel.py','test_periodic_lemma.py','test_public_api.py')
BOOTSTRAP = r'''
import sys, runpy
from pathlib import Path
sys.dont_write_bytecode = True
try:
    import resource
except ImportError:
    resource = None
if resource is not None:
    resource.setrlimit(resource.RLIMIT_CPU,(420,420))
    resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,64*1024**2))
script = Path(sys.argv[1]).resolve()
sys.argv = [str(script)] + sys.argv[2:]
sys.path.insert(0,str(script.parent))
runpy.run_path(str(script),run_name='__main__')
'''


def prepare_output(output, root=ROOT):
    root = Path(root).resolve()
    if output is None:
        parent = Path(tempfile.gettempdir()).resolve()
        require(parent!=root and root not in parent.parents,'temporary output lies within release')
        return Path(tempfile.mkdtemp(prefix='report26-replay-'))
    path = Path(output).expanduser().absolute()
    for ancestor in (path,)+tuple(path.parents):
        require(not ancestor.is_symlink(),'symlink output path rejected')
    actual = path.resolve()
    require(actual!=root and root not in actual.parents,'output must be outside release')
    require(not path.exists(),'output already exists')
    require(path.parent.is_dir(),'output parent must already exist')
    path.mkdir()
    return path


def snapshot(root):
    files, directories = inventory(root)
    records = {}
    for name, path in files.items():
        info = path.stat()
        records[name] = (info.st_size,sha256(path.read_bytes()).hexdigest(),info.st_mode,info.st_mtime_ns)
    dirs = {name:((Path(root)/name).stat().st_mode,(Path(root)/name).stat().st_mtime_ns) for name in directories}
    info = Path(root).stat()
    return records, dirs, (info.st_mode,info.st_mtime_ns)


def check_runtime_dependencies(root):
    require(hasattr(sys,'stdlib_module_names'),'Python 3.10 or newer is required')
    files, unused = inventory(root)
    local = {Path(name).stem for name in files if name.endswith('.py')}
    imports = set()
    for name,path in files.items():
        if not name.endswith('.py'):continue
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'),filename=name)):
            if isinstance(node,ast.Import):
                imports.update(alias.name.split('.')[0] for alias in node.names)
            elif isinstance(node,ast.ImportFrom):
                require(node.level==0,'relative code import is not allowed')
                imports.add((node.module or '').split('.')[0])
    require(imports <= sys.stdlib_module_names | local,'non-standard-library dependency found')
    return sorted(imports-local)


def run_script(root,script,optimized,log,output=None):
    cmd=[sys.executable,'-I','-S','-B']+(['-O'] if optimized else [])+['-c',BOOTSTRAP,str(root/script)]
    if output is not None:cmd += ['--output-dir',str(output)]
    environment={k:v for k,v in os.environ.items() if not k.startswith('PYTHON')}
    environment['TMPDIR']=str(log.parent)
    started=time.monotonic()
    with log.open('wb') as out:
        done=subprocess.run(cmd,cwd=log.parent,env=environment,stdout=out,stderr=subprocess.STDOUT,timeout=480)
    require(done.returncode==0,'script failed: '+script+'; see '+str(log))
    return {'script':script,'optimized':optimized,'returncode':done.returncode,
            'seconds':round(time.monotonic()-started,3),'isolated':True,'site_packages_disabled':True}


def semantic_receipt(path):
    data=json.loads(path.read_text())
    data.pop('elapsed_seconds',None)
    return data


def replay(output=None,root=ROOT):
    root=Path(root).absolute()
    before=snapshot(root)
    integrity=verify(root)
    imports=check_runtime_dependencies(root)
    output=prepare_output(output,root)
    runs=[]
    for optimized in (False,True):
        mode='optimized' if optimized else 'normal'
        copy=output/mode
        shutil.copytree(root,copy)
        logs=output/(mode+'-output');logs.mkdir()
        require(snapshot(copy)==before,'initial relocated copy differs')
        commands=['verify_release.py','scientific/verify_packet.py','check_release_claims.py']
        commands += ['scientific/'+s for s in SCIENTIFIC]
        commands += ['release_checks.py','verify_release.py']
        for index,script in enumerate(commands):
            dest=logs if script.startswith('scientific/test_') else None
            runs.append(run_script(copy,script,optimized,logs/(str(index).zfill(2)+'.log'),dest))
            require(snapshot(copy)==before,'copied release inventory, bytes, modes or mtimes changed')
            require(snapshot(root)==before,'original release inventory, bytes, modes or mtimes changed')
    pairs=[('test-receipt.json','test-receipt-optimized.json'),
           ('periodic-receipt.json','periodic-receipt-optimized.json'),
           ('api-receipt.json','api-receipt-optimized.json')]
    for normal,optimized in pairs:
        a=semantic_receipt(output/'normal-output'/normal)
        b=semantic_receipt(output/'optimized-output'/optimized)
        expected=semantic_receipt(root/'scientific'/normal)
        require(a==b==expected,'deterministic receipt differs: '+normal)
    require(snapshot(root)==before,'original release changed before completion')
    receipt={'status':'PASS','scope':'complete sealed Report 26 release',
             'python':sys.version.split()[0],'modes':['normal','optimized'],
             'runs':runs,'scientific_subprocesses':6,'integrity':verify(root),
             'standard_library_imports':imports,'third_party_runtime_dependencies':[],
             'whole_original_and_relocated_releases_unchanged':True,
             'invariance_fields':['file inventory','directory inventory','bytes','file modes','modification times'],
             'producer_receipts_match_except_elapsed_time':True,
             'negative_integrity_tests':'passed normally and optimized',
             'network_access_used':False,'upstream_repository_executed':False,
             'frozen_local_compiler_executed':True,
             'universal_new_rule_evaluated':False,'universal_template_array_materialized':False}
    (output/'replay-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    return receipt


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output')
    args=parser.parse_args()
    print(json.dumps(replay(args.output),indent=2))
