"""Read-only research packet integrity verifier (not mathematical verification)."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def require(value,message):
    if not value:raise RuntimeError(message)

def main():
    data=json.loads((ROOT/'manifest.json').read_text())
    expected=set(data['files'])|{'manifest.json','SHA256SUMS'}
    actual={p.name for p in ROOT.iterdir() if p.is_file()}
    require(actual==expected,('file inventory differs',sorted(actual^expected)))
    require(not any(p.is_symlink() for p in ROOT.iterdir()),'symlink in packet')
    for name,record in data['files'].items():
        require('/' not in name and '\\' not in name and name not in {'.','..'},'nonflat inventory')
        content=(ROOT/name).read_bytes()
        require(len(content)==record['bytes'],('size mismatch',name))
        require(hashlib.sha256(content).hexdigest()==record['sha256'],('hash mismatch',name))
    sums={}
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        sha,name=line.split('  ',1)
        require(name not in sums,'duplicate checksum name')
        sums[name]=sha
    require(set(sums)==expected-{'SHA256SUMS'},'checksum inventory differs')
    for name,sha in sums.items():
        require(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha,('checksum mismatch',name))
    require(data['files']['frozen_reversible_binary.py']['sha256']==
            'f95a6028c9d3cc6f8b0b497cfc0cad68104da6d70e55205df04ad234e5d0c76f','wrong inherited compiler')
    print(json.dumps({'status':'passed','pinned_files':len(data['files']),
                      'scope':'byte integrity only; mathematical correctness uses proof and tests'},sort_keys=True))

if __name__=='__main__':main()
