# Two parallel conservative involutions

Report 26, 3 October 2026. This is a new binary full-shift cellular automaton
whose two blocks are individually particle-conserving involutions. It equals
the frozen old compiler on every admissible doubled five-particle state, with
unchanged exact clocks, reflections, observer, and clean targets. It differs
on malformed inputs. A sufficient radius is 180D+258+9J.

## Read

- report26.pdf: standalone 16-page report (editable source: report26.tex)
- scientific/PROOF.md: final source-uniform proof
- scientific/audit-lemma.md and audit-preservation.md: independent proofs
- scientific/parallel_particles.py: new finite-support interpreter
- scientific/test_*.py: finite trajectory, periodic, and public API suites
- scientific/manifest.json and SHA256SUMS: untouched producer seal
- references/prior-art-audit.md: checked primary sources and attribution limits
- references/report19-*: inherited universal ledger and provenance only
- references/report20-PROOF.md: old event-budget certificate background only

The scientific directory is byte-preserved from its final 28-file packet.
Scientific sources, audits, producer receipts, and background references are
mandatory pinned dependencies; none is an optional replay input.

## Offline replay

Python 3.10 or newer is required, with only its standard library. No installation
or network access is required. From the extracted release directory:

    python3 -B verify_release.py
    python3 -B replay.py --output /existing/parent/new-external-output

The output directory must be new, and its parent must already exist. Omit
--output for a new temporary directory. Normal and optimized runs occur in
separate fresh copies with isolated Python, site packages disabled, external
logs/receipts, and bytecode disabled. The three scientific suites run in each
mode, followed by tamper tests. Expect roughly 3-5 minutes total, depending on
CPU. Original and copied release inventories, bytes, modes, and modification
times are checked after every command. Semantic receipts must match each other
and the producer receipts, excluding elapsed timing only.

The final exact-inventory seal rejects additional and missing paths, symlinks,
changed bytes, malformed manifests and inconsistent mandatory source pins.
Tamper tests include resealed deletions/changes of required scientific sources.
This proves internal consistency, not authenticity against a malicious party
who can replace the verifier too; obtain the archive digest through a trusted
channel.

The individual scientific scripts accept --output-dir EXTERNAL_DIRECTORY.
Always pass it and use -B when running them from this sealed package: their
research defaults write receipts beside the scripts and would invalidate the
release seal. The supported new source-facing API is ParallelCompiler(source).
Its custom-predicate lower-level helpers are internal mathematical test harnesses.

## Optional PDF rebuild

With TeX installed, run sh build.sh. It creates its TeX format/build files in a
temporary directory and copies only report26.pdf into the release. This is an
explicit edit: recheck every rendered page and reseal with write_manifest.py
before treating edited bytes as a release. Neither build.sh nor write_manifest.py
is called by replay.

## Boundaries

- No optimal-radius or global novelty claim; two-involution CA architectures,
  marker permutations and conserved-landscape methods are established prior art
- The universal radius 91,711,698 is symbolic substitution only; no universal
  new-rule array/evaluator/truth table is executed or emitted
- Report 19's old-rule lazy evaluator and Report 20's old-rule full-malformed
  event-budget certificates are not new-rule verifiers
- Admissible semantic computations transfer by the proved trajectory equality;
  arbitrary malformed-state fibers and old circuit counts do not automatically
  transfer
- Finite tests corroborate the mathematical proof; no proof-assistant
  formalization is claimed
