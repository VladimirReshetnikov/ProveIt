"""Strict, standard-library-only verification of Report 26's complete release.

The seal proves internal consistency, not external authenticity. Obtain the final
archive digest through a trusted channel. Every scientific source is mandatory.
"""
import sys
sys.dont_write_bytecode = True
from hashlib import sha256
import json
import os
from pathlib import Path
import stat

ROOT = Path(__file__).absolute().parent
MANIFEST = 'release-manifest.json'
DIGEST = MANIFEST+'.sha256'
SCHEMA = 'report26-exact-inventory-v1'
MAX_FILES = 256
MAX_FILE_BYTES = 64*1024*1024
MAX_TREE_BYTES = 128*1024*1024
SOURCE_PINS = {'scientific/COMPILER_PROOF.md': '55ecb9c26bf0c2ce929c97187013171f8b8ec52ee30cb9a8703b41b1d106a4e8', 'scientific/PROOF.md': 'fe809adaa74418bcddafc61cc5ff70102724256c310ae53fd396c2fe34ef65c9', 'scientific/README.md': '98dc159a2bf9b469d1e3df9a93f6cc5b57b015671617d23d0ba7b2b9dbc9a241', 'scientific/SHA256SUMS': 'bae046a6fb327ef93073189875269eba702742a9746fad44459e2150552c18a7', 'scientific/SOURCE_SCHEMA.md': '4929b248dcf3f604694d3abf7d9efbf4649f6a5f8219661f01fc3469e900dcd3', 'scientific/api-optimized.log': '46ee461744380b1c080c167124604777ec9a6907aeacc956341382b5d3c20f05', 'scientific/api-receipt-optimized.json': '46ee461744380b1c080c167124604777ec9a6907aeacc956341382b5d3c20f05', 'scientific/api-receipt.json': '46ee461744380b1c080c167124604777ec9a6907aeacc956341382b5d3c20f05', 'scientific/api.log': '46ee461744380b1c080c167124604777ec9a6907aeacc956341382b5d3c20f05', 'scientific/audit-lemma.md': '435b547d2476230f9d532cc7ed7f5a52f779b6e5f241aaacb1d316c10e117dc1', 'scientific/audit-preservation.md': 'c474f1fa73d4ced47b554fb73d91e020e834612dab00c5f8f8f7ce6afebe2e8b', 'scientific/clean-target-sample-source.json': 'ed7e9e016b990d8e5676428567aa04a8307c5fa69f69ee0c0621d8263b6367eb', 'scientific/frozen_reversible_binary.py': 'f95a6028c9d3cc6f8b0b497cfc0cad68104da6d70e55205df04ad234e5d0c76f', 'scientific/manifest.json': '141f1ecf4e34f9046b738fa6caf2d3a80c4e74f46aad7d9fa4e3b140d634f26b', 'scientific/parallel_particles.py': '2c8b639646a587a51bddeaac16e46d2dbd8c4e8138ac67a2601025334d4a64cd', 'scientific/periodic-optimized.log': '045e85aee0f2523f5874bcb13773344bde445058409db484548ff5dda6668956', 'scientific/periodic-receipt-optimized.json': '045e85aee0f2523f5874bcb13773344bde445058409db484548ff5dda6668956', 'scientific/periodic-receipt.json': '70c5890c45cecd7d5a10faa8b8868be65145f92ff3d6625f5d805d7c1a6a9f49', 'scientific/periodic.log': '70c5890c45cecd7d5a10faa8b8868be65145f92ff3d6625f5d805d7c1a6a9f49', 'scientific/resource-ledger.json': 'bc2daa11fbecd5fe703135debafb1ca59f2b7d574b6e86d47701e59e031c0f84', 'scientific/test-optimized.log': 'aa387395a3530c5e733eb657ab70b700749c9be019ebf101b2ad9cdac84b4187', 'scientific/test-receipt-optimized.json': '8542b3eb3aa06682656e38d73f38e4c9d3bdc0cdea91f73aeb4448bc74c01da0', 'scientific/test-receipt.json': 'c8e2e27d026df7008c1f15ec50907d523114d92715cb5f82d9f4cb916b09b7ae', 'scientific/test.log': 'eb9c1ceec64597ceeb8f06c7fa0c6cc10416f8ba572a1eb85e3a4273dc15b686', 'scientific/test_parallel.py': '04e904ecce3eb45b009d50ef981267ae4f2f3d6d506fea097f00a9eec029a942', 'scientific/test_periodic_lemma.py': '761014de9f8af092c093ac4ab992db280993f6f7b1526c2f4ac5a5df45b9b612', 'scientific/test_public_api.py': '01add596556fdcd7b44d03e6d4ae8a04904c9a589d9b0b8076978ef20487cba3', 'scientific/verify_packet.py': '62bdc94aec9b418ea7af003c7fb96f8dac8941acea178c1f06608ca7dfb6ebe8', 'references/prior-art-audit.md': 'b1df611bd4f019bcd2ab0cd9745ee8d4a5e6aa06a4401d07ab5e71c08f68059e', 'references/report19-PROVENANCE.json': 'cf11f74c568c4b9913af5a7b983db2ea301c66ee5fd339307058518ef3cfa4c6', 'references/report19-audit-universal-count.json': 'c60dea97515d38c02cbeb2568134ce32ec9775bfe5dee6c1eb343263165d0f6c', 'references/report19-universal-receipt.json': '4e9f4e7c43a80c7c692e55c2e89c81744606507d50a175dbe2ca0b5b7913b0ee', 'references/report20-PROOF.md': 'd74157254a36e53c1568cea383cdcc46dd73adca48a1a9a7eee4e46b51b73922', 'references/root-scientific-QA.json': '33285eadf3e4ac255f50df57041a98dd62d89bd2140bc0209479e18aea9a91e6', 'delivery-provenance.json': '4ef924506be2cc0bb2e67c14895ed71181b41652214d338c927649c5727d4d83'}
RELEASE_FILES = set(SOURCE_PINS) | {
    'source-pins.json','README.md','build.sh','verify_release.py',
    'write_manifest.py','release_checks.py','replay.py','check_release_claims.py',
    'report26.tex','report26.pdf','report26-qa.json','delivery-provenance.json',
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def unique_object(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, 'duplicate JSON key: '+key)
        out[key] = value
    return out


def load_json(raw):
    return json.loads(raw, object_pairs_hook=unique_object,
                      parse_constant=lambda s: (_ for _ in ()).throw(ValueError('nonfinite JSON number')))


def relative_name(name):
    require(type(name) is str and bool(name) and '\\' not in name and ':' not in name, 'invalid path')
    require(not name.startswith('/') and all(part not in ('','.','..') for part in name.split('/')), 'unsafe relative path')
    require(Path(name).as_posix()==name, 'noncanonical path')
    return name


def inventory(root):
    root = Path(root).absolute()
    require(not root.is_symlink() and root.is_dir(), 'release root must be an ordinary directory')
    files, directories, total = {}, set(), 0
    for base, dirs, names in os.walk(root, followlinks=False):
        for child in sorted(dirs+names):
            path = Path(base)/child
            name = relative_name(path.relative_to(root).as_posix())
            mode = path.lstat().st_mode
            require(not stat.S_ISLNK(mode), 'symlink rejected: '+name)
            if stat.S_ISDIR(mode):
                directories.add(name)
            else:
                require(stat.S_ISREG(mode), 'nonregular file rejected: '+name)
                size = path.stat().st_size
                require(size<=MAX_FILE_BYTES, 'file size limit')
                total += size
                require(total<=MAX_TREE_BYTES, 'release size limit')
                files[name] = path
            require(len(files)+len(directories)<=MAX_FILES, 'inventory limit')
    return files, directories


def expected_directories(names):
    return {p.as_posix() for name in names for p in Path(name).parents if p!=Path('.')}


def check_pins(root=ROOT):
    root = Path(root).absolute()
    observed, directories = inventory(root)
    require('source-pins.json' in observed, 'mandatory source pin manifest missing')
    data = load_json(observed['source-pins.json'].read_bytes())
    require(type(data) is dict and set(data)=={'schema','files'}, 'source pin manifest shape')
    require(data['schema']=='report26-mandatory-source-pins-v1', 'source pin schema')
    require(data['files']==SOURCE_PINS, 'mandatory source pin set/value mismatch')
    for name, digest in SOURCE_PINS.items():
        require(name in observed, 'missing mandatory scientific dependency: '+name)
        require(sha256(observed[name].read_bytes()).hexdigest()==digest, 'scientific dependency pin mismatch: '+name)
    require(set(observed)<=RELEASE_FILES|{MANIFEST,DIGEST}, 'unexpected release file outside exact deliverable inventory')
    require(directories<=expected_directories(RELEASE_FILES), 'unexpected release directory')
    return {'mandatory_scientific_files':len(SOURCE_PINS),'optional_scientific_files':0}


def manifest_data(root=ROOT):
    files, directories = inventory(root)
    expected = RELEASE_FILES | {MANIFEST,DIGEST}
    require(set(files)-{MANIFEST,DIGEST}==RELEASE_FILES,'missing/additional final release file')
    require(directories==expected_directories(expected),'missing/additional final release directory')
    check_pins(root)
    entries = {}
    for name in sorted(RELEASE_FILES):
        raw = files[name].read_bytes()
        entries[name] = {'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
    return {'schema':SCHEMA,'files':entries,'directories':sorted(directories)}


def verify(root=ROOT):
    root = Path(root).absolute()
    files, directories = inventory(root)
    require(MANIFEST in files and DIGEST in files, 'missing final seal')
    raw = files[MANIFEST].read_bytes()
    require(len(raw)<=1024*1024,'manifest too large')
    require(files[DIGEST].read_text(encoding='ascii')==sha256(raw).hexdigest()+'  '+MANIFEST+'\n','manifest digest mismatch')
    data = load_json(raw)
    require(type(data) is dict and set(data)=={'schema','files','directories'},'release manifest shape')
    require(data['schema']==SCHEMA,'release manifest schema')
    entries = data['files']
    require(type(entries) is dict and set(entries)==RELEASE_FILES,'manifest exact mandatory file inventory mismatch')
    for name, entry in entries.items():
        relative_name(name)
        require(type(entry) is dict and set(entry)=={'bytes','sha256'},'manifest entry shape')
        require(type(entry['bytes']) is int and 0<=entry['bytes']<=MAX_FILE_BYTES,'invalid manifest size')
        require(type(entry['sha256']) is str and len(entry['sha256'])==64 and all(c in '0123456789abcdef' for c in entry['sha256']),'invalid manifest SHA')
    require(set(files)==RELEASE_FILES|{MANIFEST,DIGEST},'actual file inventory mismatch')
    wanted_dirs = expected_directories(RELEASE_FILES)
    require(type(data['directories']) is list and data['directories']==sorted(wanted_dirs),'manifest exact directory inventory mismatch')
    require(directories==wanted_dirs,'actual directory inventory mismatch')
    for name, expected in entries.items():
        content = files[name].read_bytes()
        require(len(content)==expected['bytes'] and sha256(content).hexdigest()==expected['sha256'],'changed release file: '+name)
    pins = check_pins(root)
    return {'status':'PASS','files_verified':len(files),'directories_verified':len(directories),**pins}


if __name__=='__main__':
    print(json.dumps(verify(),indent=2))
