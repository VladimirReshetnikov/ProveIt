# Report 16 — A literal universal reversible two-counter source

Read `report16.pdf`. Editable LaTeX is `report16.tex` plus `sections/`.

## What this release establishes

One exact universal source now has 122,622 controls and 141,561 fully expanded branches, with exactly two natural counters. It is partial-injective on every natural configuration, has no incoming START and no outgoing HALT, and simulates the pinned Neary–Woods universal TM on its clean finite-input family. Every clean nonhalting input continues forever. The fixed binary five-particle CA specified by Report 15 therefore has r.e.-complete periodicity/positive return on the encoded family; its least halting-input period is 2Theta+2 using the base CA clock.

Source SHA-256:
`38c586706fa1069442d3e5103151adb156448b7d7c783f5c46d9d507b87fe73a`

## Reproduce without changing published files

Requires Python 3.10+ and only its standard library:

    python3 replay.py
    python3 replay.py --receipt /tmp/report16-replay.json

The driver checks the exact manifest, runs eight source checks in normal and optimized Python, regenerates seven literal JSON files byte for byte, and reruns the independent release audit in both modes. It also replays thirteen primitive-certificate tests in each mode, its universal source ledger audit and independent 53,786-check/136-rejection audit in both modes, and all 6,232 actual CA steps of the new small five-row example. All generated work is temporary. The eight source checkers, affine proof coverage, mutation rejection, class counts, loader validation and history/prime proofs have distinct scopes explained in the article. The earlier companion reports' full computational suites are not rerun.

PDF rebuilding needs TeX Live:

    sh build.sh

This writes only `.build/` and `report16.pdf`; rebuilding may change the PDF bytes if the TeX toolchain differs, and the existing manifest will then correctly report that change. The hidden build directory is not part of the distributable inventory.

Small loader demonstration:

    python3 source/loader.py --left 101 --right 01 --particles

Both finite binary tape halves are nearest-head-first, the scanned symbol is zero, and omitted cells are zero. The Python loader API returns exact integers; the CLI prints hexadecimal. This example has L=5, R=2, A=288 and B=0.

## Contents and dependency boundaries

- `source/`: final literal tables, source generator, clean loader, proof/checker files and deterministic receipts, all preserved from the stabilized source release
- `audits/`: the finalized independent proof reviews, package-relative replay scripts, regenerated portable receipts and stabilized source hashes
- `companions/report15/`: byte-preserved authored compiler PDF, LaTeX and required sections/vector figure; original universal-source existential wording describes that earlier release
- `companions/report12/`: byte-preserved four-mass lower-bound proof/PDF/vector figure, used as an explicit dependency rather than a new lower-bound proof
- `primitive-certificates/`: specialized shared-offset quartic implementation/proof, exact ledgers, a fully expanded small polynomial/witness, and its full raw CA orbit
- `manifest.json` and `SHA256SUMS`: exact bytes and hashes for this package, with the two integrity files excluded from their own payload inventory to avoid self-reference

Original source logs, screenshots, third-party papers, obsolete verifier, cache files and the old source-package manifest were intentionally omitted. Audit scripts were adapted to package-relative defaults and mandatory bundled dependency hashes, and their receipts were regenerated on the filtered source tree. See `PACKAGING-ADAPTATIONS.md` for exact original/adapted hashes and scope; the current manifest binds this precise portable release. Run `replay.py`, not an old upstream manifest verifier.

`source/dependency/PROOF.md` is an unchanged historical front-end dependency. Only its three-counter/TM section is used here; its later old nonreversible two-counter conversion is not the source of this report. The unchanged compiler snapshot is in `source/compiler-reference/`. Its eager universal `compile_source` is not invoked.

## Honest materialization and practical limits

The universal source transition table is materialized. The CA's 269,291,358,255-factor array and astronomical local truth table are not. The counted universal-instance quartic certificate is not emitted. Blank-tape initialization has a proof-derived two-counter clock of 79,936,151,060,302 steps; the full physical path was not traversed. Small literal macros and the fresh entry were tested. A separate small five-row source has a fully executed 6,232-step CA orbit, first halt at 3,115, and a materialized 1,100-monomial quartic certificate. The shared-offset universal core has 141,565K witnesses and 23,435K+1 squares, while its universal polynomial remains indexed and unmaterialized. This is a mathematical construction with executable audits, not a practical universal emulator, optimality/novelty claim or proof-assistant formalization.
