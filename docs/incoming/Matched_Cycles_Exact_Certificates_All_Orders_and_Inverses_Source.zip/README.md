# Report155 — Exact positive certificates and all orders for matched cycles

Standalone mathematical report for OEIS A192561,

b_n = sum_{k=0}^n [n+1,k+1]^2 k!, with unsigned first-kind Stirling numbers.

## Main results

- Exact positive Fock expansion with an explicit tail for every n ≥ 1
- Uniform S2 ≤ 1/φ, with q = K/(K+1) minimizing the exact-center bound for every K ≥ 2
- A rational-center certificate requiring only Fraction arithmetic and elementary exponential Taylor bounds
- A generic certificate for nonconstant finite polynomials with strictly negative real zeros
- All fixed inverse-logarithm orders, w = W0(en), leading term (n!)² exp(w²+1)/(2πw)
- Rational coefficients A0 through A10 and a general finite-order generator
- An explicit nested-Lambert inverse with a safe two-ceiling threshold bracket

The inverse-logarithm series is a fixed-order asymptotic expansion, not a claimed convergent series. Its remainder constants and onset are not numerically supplied. The finite-n Fock tail is explicit. At an off-saddle rational center, q = K/(K+1) is admissible but is not generally optimal.

The exact companion example isolates b10 = 1273270076895432. Its full rational interval has width < 2283679986302/10^30. The 30-place displayed decimal endpoints are rounded outward using integer arithmetic, not floating point. This is an actual interval certificate, not merely a high-precision numerical check.

## Files

- `Report155.pdf`: complete report
- `Report155.tex`: editable self-contained LaTeX
- `companion/`: Python standard-library exact coefficient generator, certificate, integer enumeration, bounded CLI, tests, fixed inputs and deterministic results
- `SOURCE_PROVENANCE.json`: public sources, precise inspection scope, and attribution
- `build_pdf.py`: clean deterministic PDF builder
- `release_tools.py`: common exclusive POSIX file helpers
- `make_zip.py`: fixed-allowlist manifest verification and deterministic ZIP builder
- `test_release.py`: release safety and archive regression tests
- `SHA256SUMS`: SHA-256 manifest for every allowlisted payload file except itself

The source ZIP contains the above payload and manifest. It does not include older reports, external papers, scratch work, temporary TeX files, private review notes, or release receipts. A manifest cannot include its own digest without a self-reference cycle; the ZIP includes the manifest, and its overall hash is supplied separately with the release.

## Requirements

The companion requires Python 3.11 or later, POSIX directory-relative opens, O_NOFOLLOW/O_DIRECTORY, and hard-link support. No third-party Python dependencies or network access are needed. See `companion/README.md` for its strict input bounds and supported commands.

The report build was checked with Python 3.12.14, pdfTeX 1.40.26 (TeX Live 2025/dev/Debian), and the installed TeX Live distribution. The builder uses `pdftex`, `pdflatex`, the LaTeX format source, and the following packages/fonts: fontenc, Latin Modern, amsmath, amssymb, amsthm, mathtools, geometry, booktabs, longtable, array, microtype, and hyperref. `pdftoppm` and `pdfinfo` are useful for visual verification but are not required by the builder itself.

## Reproduce exact results

Run these commands from `companion`. Use fresh output filenames, because existing files are refused:

```sh
python3 -B fock_exact.py certificate --input inputs/certificate_n10.json --output results/replay_n10.json
python3 -B fock_exact.py coefficients --order 10 --output results/replay_A10.json
python3 -B fock_exact.py enumerate --n 10 --output results/replay_enumeration_n10.json
python3 -B -m unittest -v test_companion
python3 -O -B -m unittest -v test_companion
```

The fixed result files can be compared byte-for-byte with regenerated outputs. All certification decisions use exact integer or rational comparisons. Printed decimal endpoints are exact grid rationals. No timestamps or elapsed times appear in reproducible result files.

The companion includes a maximum-workload check at n=20, K=96, 64 bisections and 192 exponential Taylor terms; the shipped implementation deliberately caps its workload. This check is not a production-general interval package claim. The mathematical theorems themselves have the ranges stated in the report, independent of those practical software limits.

## Rebuild the PDF

From the package root, choose a new directory whose parent already exists:

```sh
python3 -B build_pdf.py --output-dir /tmp/report155-build-one
python3 -B build_pdf.py --output-dir /tmp/report155-build-two
cmp /tmp/report155-build-one/Report155.pdf /tmp/report155-build-two/Report155.pdf
```

The builder creates the directory exclusively, generates an isolated LaTeX format, disables shell escape, fixes the build epoch and metadata, repeats TeX until references stabilize, and rejects warnings or layout diagnostics in the settled log. The original `.tex` file is copied into the clean directory and is the only authoring input. Byte identity is expected within the same recorded toolchain; it is not promised across TeX versions, font versions, operating systems, or arbitrary platform changes.

The build output directory must have a trusted parent and must not be subject to concurrent adversarial replacement. Existing paths, static symlink paths, and parent traversal are refused. The directory helper uses a mkdir-then-open sequence and is not claimed to resist a malicious same-user process replacing that freshly created directory between those calls. Descriptor pinning protects subsequent operations once the directory has been opened. No shell escape or network is used by these scripts, but TeX is not a sandbox for an arbitrarily modified input file.

## Verify and reproduce the archive

From the unchanged extracted package root:

```sh
sha256sum -c SHA256SUMS
python3 -B -m unittest -v test_release
python3 -O -B -m unittest -v test_release
python3 -B make_zip.py --output /tmp/Report155_rebuild_one.zip
python3 -B make_zip.py --output /tmp/Report155_rebuild_two.zip
cmp /tmp/Report155_rebuild_one.zip /tmp/Report155_rebuild_two.zip
```

The archive uses a fixed sorted allowlist, validates every member hash, and has fixed timestamps, permissions, member order, and ZIP_STORED compression. Unlisted files, including your replay files, never enter the archive. Output is exclusive and does not overwrite an existing file, directory, FIFO, or symlink. Do not edit the source and expect its original checksum manifest to validate: authoring a changed edition and freezing a new manifest is a separate release action.

The companion has an additional local manifest for its own payload. The root manifest also hashes that local manifest. Normal and optimized Python test runs are required; validation is explicit rather than assert-dependent.

## Source scope

Classical inputs include Gaussian Fock orthogonality, unsigned Stirling recurrence, shifted Gamma/digamma/Hurwitz-zeta asymptotics, and general saddle methods. Wilf's unweighted squared-Stirling result is a close antecedent. The inspected OEIS snapshot lists no asymptotic, and the bounded search located no identical sequence-specific expansion. This is not a first-ever priority claim. Two potentially relevant broader papers were not fully read; the report and provenance record say exactly which source claims were checked.

No external publication, OEIS submission, repository modification, or source-site change is part of this package.
