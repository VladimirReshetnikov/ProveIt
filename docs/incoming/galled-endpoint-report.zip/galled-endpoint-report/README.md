# Near maximal gall counts

A self-contained research report for A399421, the unlabeled nonplane simplex time-consistent binary galled-tree triangle. Deficiency is d=n−2k−1. The report proves a uniform asymptotic expansion to every fixed order when d/√n lies in a fixed compact positive interval, with the exact spacing-two lattice and parity factor. It also gives a supplied-integer-deficiency Lambert W0/Newton inverse with asymptotic lattice qualifications.

## Read the report

- `output/endpoint.pdf`: the 18-page report
- `manuscript/endpoint.tex`: editable LaTeX source
- `code/README.md`: computational methods, inputs, and additional commands
- `data/ratios.csv`: exact count comparisons against leading, C1, and C2 approximations
- `verification/`: release verification summaries

The known maximal-gall identity is credited to Agranat-Tamir et al. The outer shrinking-saddle mechanism is classical, with De Angelis as the applicable signed-coefficient precedent. No exhaustive novelty claim is made. Numerical constants are non-interval evaluations; the asymptotic remainder constants are not effective, and the inverse is not a certified finite-size recovery rule.

## Reproduce

From this directory:

```sh
python3 code/check_manifest.py
bash reproduce.sh
```

The first command verifies all shipped SHA-256 hashes. The second regenerates the exact integer triangle through n=160, recomputes critical jets at U truncations 220 and 320, checks the symbolic generator and C1/C2, compares 16 finite-size cases, checks Lambert/Newton inversion models and 6320 monotonicity pairs, and rebuilds the PDF. Outputs from this replay go into `results/` and `build/`; the rebuilt PDF is copied to `output/endpoint.pdf`.

Requirements: Python 3.12 (tested with 3.12.14), mpmath 1.3.0, SymPy 1.14.0, Bash, and a TeX Live installation with pdfLaTeX and the standard packages used in the source. Python versions are pinned in `requirements.txt`. The checks and build make no network requests and do not install software. They do not require any other report, original research workspace, or full third-party paper. A normal TeX Live setup is supported; the build includes an offline fallback for missing local format or font-map caches.

The full replay generally takes under a minute when dependencies are present. PDF output is byte-reproducible in the tested environment. Other TeX/font versions may produce a visually equivalent PDF with a different byte hash.

## Files and integrity

`SHA256SUMS` covers the shipped files except the manifest itself. The enclosing ZIP has its own companion SHA-256 file. The data include both reference outputs and provenance hashes. Long decimal strings are retained for comparison, not as certificates that every digit is accurate. Exact integer identities and zero symbolic residuals are distinct from numerical stability checks.

The archive contains original report and code materials, small reference data, and verification summaries. Public sources are linked in the report; full source papers are not included.
