"""Reconstruct every primitive of the frozen PA238 physical source DAG.

The JSON contains mathematical data extracted from the pinned Prog238.v.
One graph resolver uses binary prefix arithmetic. The other uses leaf
intervals and walks the syntax tree. Their complete outputs must agree.
"""
from pathlib import Path
from functools import cache
import hashlib
import json


def validate_sites(rows):
    if len(rows) != 4409:
        raise ValueError('Wrong full source leaf count')
    leaves = {}
    prefixes = set()
    for i, (p, op, arg) in enumerate(rows):
        if not p or set(p)-{'0', '1'} or len(p) > 34 or p in leaves:
            raise ValueError('Invalid, duplicate, or overly deep leaf')
        if op not in ('CI', 'CD', 'CB', 'CC', 'CH'):
            raise ValueError('Unknown source instruction')
        if op == 'CH':
            if arg is not None:
                raise ValueError('Halt has an operand')
        elif type(arg) is not int or arg < 0:
            raise ValueError('Non-natural operand')
        elif op in ('CI', 'CD') and arg >= 9:
            raise ValueError('Invalid register')
        elif op in ('CB', 'CC') and arg < 1:
            raise ValueError('Invalid control depth')
        leaves[p] = i
        prefixes.update(p[:j] for j in range(len(p)))
    if set(leaves) & prefixes:
        raise ValueError('One leaf extends another')
    if any(p+b not in leaves and p+b not in prefixes
           for p in prefixes for b in ('0', '1')):
        raise ValueError('Tree is not a complete prefix code')
    if list(leaves) != sorted(leaves):
        raise ValueError('Leaf order differs from ordinal source order')
    if max(len(run) for p in leaves for run in p.split('1')) != 6:
        raise ValueError('Wrong zero-run census')
    if sum(op == 'CD' for _, op, _ in rows) != 1323:
        raise ValueError('Wrong decrement census')
    if sum(op == 'CH' for _, op, _ in rows) != 1:
        raise ValueError('Wrong halt census')
    return leaves


def arithmetic_graph(rows):
    leaves = validate_sites(rows)
    depth = max(map(len, leaves))

    def locate(p):
        word = p+'0'*depth
        for d in range(1, depth+1):
            if word[:d] in leaves:
                if '1' in p[d:]:
                    raise ValueError('Stray nonzero bit beyond successor')
                return leaves[word[:d]]
        raise ValueError('No successor leaf')

    def increment(p):
        if not p:
            return ''
        bits = list(p)
        for j in range(len(bits)-1, -1, -1):
            bits[j] = '1' if bits[j] == '0' else '0'
            if bits[j] == '1':
                break
        return ''.join(bits)

    def cut(p, b, k):
        positions = [j for j, x in enumerate(p) if x == b]
        return p[:positions[-k]] if len(positions) >= k else ''

    result = []
    for p, op, arg in rows:
        if op == 'CI':
            effect, targets = ['increment', arg], [locate(increment(p))]
        elif op == 'CD':
            effect = ['decrement', arg]
            targets = [locate(increment(cut(p, '0', 1))), locate(increment(p))]
        elif op == 'CB':
            effect, targets = ['identity'], [locate(increment(cut(p, '0', arg)))]
        elif op == 'CC':
            effect, targets = ['identity'], [locate(cut(p, '1', arg))]
        else:
            effect, targets = ['halt'], []
        result.append([effect, targets])
    if locate('') != 0:
        raise ValueError('Wrong first instruction')
    return result


def interval_graph(rows):
    indices = {p: i for i, (p, _, _) in enumerate(rows)}
    intervals = {}

    def visit(p):
        if p in indices:
            ans = indices[p], indices[p]+1
        else:
            left, right = visit(p+'0'), visit(p+'1')
            if left[1] != right[0]:
                raise ValueError('Noncontiguous source')
            ans = left[0], right[1]
        intervals[p] = ans
        return ans

    if visit('') != (0, len(rows)):
        raise ValueError('Wrong whole-tree interval')

    def outward(p, b, k):
        while p:
            last, p = p[-1], p[:-1]
            if last == b:
                k -= 1
                if k == 0:
                    return intervals[p][1] % len(rows) if b == '0' else intervals[p][0]
        return 0

    result = []
    for i, (p, op, arg) in enumerate(rows):
        after = (i+1) % len(rows)
        if op == 'CI':
            effect, targets = ['increment', arg], [after]
        elif op == 'CD':
            effect, targets = ['decrement', arg], [outward(p, '0', 1), after]
        elif op == 'CB':
            effect, targets = ['identity'], [outward(p, '0', arg)]
        elif op == 'CC':
            effect, targets = ['identity'], [outward(p, '1', arg)]
        else:
            effect, targets = ['halt'], []
        result.append([effect, targets])
    return result


def extract(path):
    payload = json.loads(Path(path).read_text())
    nodes = {}
    for i, a, b in payload['nodes']:
        if i in nodes:
            raise ValueError('Duplicate DAG node')
        nodes[i] = tuple(a), tuple(b)
    if len(nodes) != 185 or payload['root'] != 0:
        raise ValueError('Wrong frozen DAG')
    visiting = set()

    @cache
    def expand(e):
        op, arg = e
        if op != 'node':
            return e
        if arg in visiting:
            raise ValueError('Cyclic program data')
        visiting.add(arg)
        a, b = nodes[arg]
        out = expand(a), expand(b)
        visiting.remove(arg)
        return out

    root = expand(('node', 0))
    rows = []

    def leaves(t, p):
        if isinstance(t[0], str):
            rows.append([p, *t])
        else:
            leaves(t[0], p+'0')
            leaves(t[1], p+'1')

    leaves(root, '')
    if rows != payload['leaf_inventory']:
        raise ValueError('DAG expansion differs from independent original inventory')
    first, second = arithmetic_graph(rows), interval_graph(rows)
    if first != second:
        raise ValueError('Independent guarded control-flow graphs disagree')
    raw = (json.dumps(rows, separators=(',', ':'))+'\n').encode()
    report = dict(status='PASS', internal_nodes=185, primitive_leaves=len(rows),
                  decrement_leaves=1323, symbolic_cases=5732,
                  maximum_depth=max(len(p) for p, _, _ in rows),
                  maximum_zero_run=6, both_guarded_graphs_equal=True,
                  dag_matches_original_inventory=True,
                  compact_sites_sha256=hashlib.sha256(raw).hexdigest(),
                  upstream_file_sha256=payload['upstream_file_sha256'])
    return rows, raw, report
