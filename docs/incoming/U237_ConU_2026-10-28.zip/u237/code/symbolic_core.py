"""Affine unary/list execution core adapted from ProveIt K215.
Original attribution and terms are in ../licenses/K215-NOTICE.md.
This module proves mathematical macro contracts; it is not a kernel checker.
"""
from pathlib import Path
import json,hashlib,time,argparse,os,sys
if not __debug__ or sys.flags.optimize:
    raise RuntimeError("Universal checking requires enabled assertions; disable -O and PYTHONOPTIMIZE.")
import independent_runtime as r

# Thirteen affine slots: constant, gap, nine independent primary values,
# first-spare value, and remaining spare-list width. The separate generic
# one-block proof reuses slot 2 for its arbitrary natural block value.
NV=13
ZERO=(0,)*NV

def num(n):return (n,)+(0,)*(NV-1)
def var(i):return tuple(int(j==i) for j in range(NV))
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def neg(a):return tuple(-x for x in a)
def minus1(a):return (a[0]-1,)+a[1:]
def nonnegative(a):return all(x>=0 for x in a)
def run(bit,n):return ('run',bit,n if isinstance(n,tuple) else num(n))
def bit(b):return run(b,1)
def block(value,family='B'):
    # B(v)=0 1^(v+1), C(v)=1 0 1^v.
    if family=='B':return [bit(0),run(1,add(value,num(1)))]
    if family=='C':return [bit(1),bit(0),run(1,value)]
    if family=='D':return [run(1,value),bit(0),bit(1)]
    raise ValueError('Unknown block family')
def tail(family='B',reverse=False):return ('list',family,'spare_tail',reverse)
BLANK=('blank',)
def rev(atoms):
    return [a if a[0]!='list' else (a[0],a[1],a[2],not a[3]) for a in reversed(atoms)]

def normal(atoms):
    out=[]
    for a in atoms:
        if a[0]=='run':
            assert a[1] in (0,1) and nonnegative(a[2]),('negative run',a)
            if a[2]==ZERO:continue
            if out and out[-1][0]=='run' and out[-1][1]==a[1]:
                a=run(a[1],add(out.pop()[2],a[2]))
        out.append(a)
    # An infinite zero exterior absorbs any finite adjacent zero run.
    if len(out)>1 and out[-1]==BLANK and out[-2][0]=='run' and out[-2][1]==0:out.pop(-2)
    # Finite-list word identity, proved by base/cons algebra independently below:
    # C(A) 1 = 1 B(A), and its reversal 1 rev(C(A)) = rev(B(A)) 1.
    for i in range(len(out)-1):
        a,b=out[i:i+2]
        if a[:2]==('list','C') and not a[3] and b[:2]==('run',1) and b[2][0]>=1:
            return normal(out[:i]+[bit(1),('list','B',a[2],False),run(1,minus1(b[2]))]+out[i+2:])
        if a[:2]==('run',1) and a[2][0]>=1 and b[:2]==('list','C') and b[3]:
            return normal(out[:i]+[run(1,minus1(a[2])),('list','B',b[2],True),bit(1)]+out[i+2:])
    return out

class State:
    def __init__(self,q,left,right,direction=1):self.q=q;self.left=list(left);self.right=list(right);self.direction=direction
    def key(self):
        self.left=normal(self.left);self.right=normal(self.right)
        return self.q,self.direction,self.left,self.right
    def step(self,table,lemmas,clock,motion):
        self.key()
        src,dst=(self.right,self.left) if self.direction==1 else (self.left,self.right)
        if not src:raise AssertionError('Unrepresented tape exterior')
        a=src[0]
        if a==BLANK:src.insert(0,bit(0));a=src[0]
        if a[0]=='list':
            key=(self.q,self.direction,a[1],a[3])
            assert key in lemmas,('No checked list traversal',key)
            src.pop(0);dst.insert(0,('list',lemmas[key],a[2],not a[3]))
            width=var(12)
            return add(clock,width),add(motion,width if self.direction==1 else neg(width)),('list',key)
        assert a[0]=='run',('Opaque context reached',self.q,self.direction,a)
        w,d,q=table[self.q,a[1]]
        row=(self.q,a[1],w,d,q)
        if q==self.q and d==self.direction:
            src.pop(0);dst.insert(0,run(w,a[2]))
            return add(clock,a[2]),add(motion,a[2] if d==1 else neg(a[2])),('unary',row,a[2])
        assert a[2][0]>=1,('Unknown run may be empty',row,a)
        src[0]=run(a[1],minus1(a[2]))
        if d==self.direction:dst.insert(0,bit(w))
        else:src.insert(0,bit(w));self.direction=d
        self.q=q
        return add(clock,num(1)),add(motion,num(d)),('literal',row)


def prove_blocks(table):
    # These names merely identify entry states. Every theorem is rederived
    # from this exact literal table; failed derivation is fatal.
    signatures=[(73,1,'B','B'),(95,1,'B','C'),(48,-1,'B','B'),(112,-1,'C','B')]
    lemmas={};certificates=[];v=var(2)
    # Empty-list identity, and one-element identity with symbolic natural v.
    assert normal([bit(1)])==normal([bit(1)])
    assert normal(block(v,'C')+[bit(1)])==normal([bit(1)]+block(v,'B'))
    for q,d,before,after in signatures:
        L=('opaque','left');R=('opaque','right')
        if d==1:
            state=State(q,[L],block(v,before)+[R]);target=State(q,rev(block(v,after))+[L],[R])
        else:
            state=State(q,rev(block(v,before))+[L],[R],-1);target=State(q,[L],block(v,after)+[R],-1)
        steps=ZERO;motion=ZERO;trace=[]
        for _ in range(50):
            if state.key()==target.key():break
            steps,motion,event=state.step(table,{},steps,motion);trace.append(event)
        else:raise AssertionError(('One-block lemma did not close',q,d))
        assert steps==add(v,num(2))
        assert motion==(steps if d==1 else neg(steps))
        lemmas[q,d,before,d==-1]=after
        certificates.append({'entry':q,'direction':d,'before':before,'after':after,'steps':'v+2','arbitrary_contexts':True,'trace':trace})
    return lemmas,certificates


def file_bits(values,append=None):
    atoms=[]
    for v in values:atoms+=block(v)
    atoms+=block(var(11))+[tail()]
    if append is not None:atoms+=block(num(append))
    return atoms+[BLANK]
