"""Literal table parsing and program-counter arithmetic.

The path arithmetic follows the unchanged PA238 interpreter. The two
independent source-level graph resolvers are in source.py.
"""
from pathlib import Path


def table(path):
    rows = {}
    starts = []
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
            continue
        if not line or line.startswith('#'):
            continue
        q, b, w, d, t = line.split()
        q, b, w, t = map(int, (q, b, w, t))
        if (q, b) in rows or b not in (0, 1) or w not in (0, 1):
            raise ValueError('Duplicate row or nonbinary symbol')
        if d not in ('L', 'R') or min(q, t) < 0:
            raise ValueError('Invalid direction or state')
        rows[q, b] = w, 1 if d == 'R' else -1, t
    if len(starts) != 1:
        raise ValueError('Exactly one start directive required')
    states = {q for q, _ in rows}
    if set(rows) != {(q, b) for q in states for b in (0, 1)}:
        raise ValueError('Incomplete transition table')
    if starts[0] not in states:
        raise ValueError('Start state is not working')
    return rows


def inc(pc):
    n = len(pc)
    v = (int(pc, 2) if pc else 0) + 1
    return (format(v % 2**n, '0'+str(n)+'b') if n else ''), int(v == 2**n)


def strip(pc, bit, count):
    if type(count) is not int or count < 0 or bit not in ('0', '1'):
        raise ValueError('Invalid strip request')
    if count == 0:
        return pc
    for i in range(len(pc)-1, -1, -1):
        if pc[i] == bit:
            count -= 1
            if count == 0:
                return pc[:i]
    return ''
