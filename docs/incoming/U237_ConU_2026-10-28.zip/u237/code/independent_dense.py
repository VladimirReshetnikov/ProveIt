#!/usr/bin/env python3
"""Independent literal/finite-prefix review of the proposed PA237 table.
No imported construction or simulator. No claim of unbounded correctness.
"""
from pathlib import Path
import hashlib,json,sys
BASE=Path(__file__).resolve().parents[1]
OUT=Path(sys.argv[1]).resolve()
if not __debug__ or sys.flags.optimize:raise RuntimeError('Assertions required')

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def parse(p):
 table={};start=None
 for line in p.read_text().splitlines():
  if line.startswith('#! start '):
   assert start is None;start=int(line.split()[-1]);continue
  if not line or line.startswith('#'):continue
  q,b,w,d,t=line.split();q,b,w,t=map(int,(q,b,w,t))
  assert (q,b) not in table and b in (0,1) and w in (0,1) and d in ('L','R')
  table[q,b]=(w,-1 if d=='L' else 1,t)
 return table,start

old,oldstart=parse(BASE/'inputs/mira-pa238.tm')
native,start=parse(BASE/'machine/u237.native.tm')
dense,dstart=parse(BASE/'machine/u237.tm')
assert start==3 and dstart==0
assert set(native)=={(q,b) for q in range(238) if q!=1 for b in (0,1)}
assert set(dense)=={(q,b) for q in range(237) for b in (0,1)}
changes={k:(old.get(k),native.get(k)) for k in old.keys()|native.keys() if old.get(k)!=native.get(k)}
assert set(changes)=={(0,0),(1,0),(1,1),(3,0),(3,1),(45,1)}
assert native[0,0]==(1,-1,4)
assert native[3,0]==(1,-1,0)
assert native[3,1]==(1,1,60)==old[60,1]
assert native[45,1]==(0,1,3)
# Independently reconstruct an isomorphism by rooted graph traversal.
mapping={3:0};pending=[3]
while pending:
 q=pending.pop()
 if q==238:
  assert mapping[q]==237;continue
 for b in (0,1):
  w,d,t=native[q,b];ww,dd,tt=dense[mapping[q],b]
  assert (w,d)==(ww,dd)
  if t not in mapping:mapping[t]=tt;pending.append(t)
  else:assert mapping[t]==tt
assert set(mapping)==set(range(239))-{1}
assert set(mapping.values())==set(range(238))
# Reproduce the blank prefix on a dense byte array, using only canonical rows.
size=1<<18;offset=size//2;tape=bytearray(size);head=offset;state=0
nsteps=3601258
lo=hi=head
for _ in range(nsteps):
 assert 0<=state<237 and 0<=head<size
 write,direction,state=dense[state,tape[head]]
 tape[head]=write;head+=direction
 lo=min(lo,head);hi=max(hi,head)
ones=[i-offset for i in range(lo,hi+1) if tape[i]]
assert state==mapping[25] and head-offset==-26
assert ones[0]==-27 and ones[1]==23
# Independent direct decoder: 0 1^(n+1) repeated, beginning after the header.
cursor=24;blocks=[]
while cursor<=ones[-1]:
 assert tape[cursor+offset]==0
 cursor+=1;value=-1
 while tape[cursor+offset]==1:
  value+=1;cursor+=1
 assert value>=0
 blocks.append(value)
assert blocks[:9]==[0,2,0,0,0,0,6,0,0]
assert len(blocks)==826
claimed=json.loads((BASE/'evidence/bootstrap.json').read_text())
assert claimed['one_cells']==ones
assert claimed['spare_values']==blocks[9:]
# Local contextual blocks. Enumerate all contexts read by the replacement;
# unbounded entry invariants are checked separately by the runtime checker.
for x in (0,1):
 # old1 on a 0 whose left neighbor is 1 and new4 produce the same
 # two-step outcome; no other cells are inspected.
 oldt={0:0,-1:1,-2:x};newt=oldt.copy()
 def twice(T,q,t):
  h=0
  for _ in range(2):
   w,d,q=T[q,t[h]];t[h]=w;h+=d
  return q,h,t
 assert twice(old,1,oldt)==twice(native,4,newt)
 # The 45/1 detour is an exact copy when the next tape symbol is 1.
 oldt={0:1,1:1,2:x};newt=oldt.copy()
 assert twice(old,45,oldt)==twice(native,45,newt)
report={
 'status':'PASS',
 'scope':'Independent literal-table comparison, rooted renaming, contextual two-step blocks, and finite blank prefix only; unbounded runtime proof is separate.',
 'working_states':237,'rows':474,'start':0,'halt':237,
 'native_sha256':digest(BASE/'machine/u237.native.tm'),
 'canonical_sha256':digest(BASE/'machine/u237.tm'),
 'baseline_sha256':digest(BASE/'inputs/mira-pa238.tm'),
 'finite_prefix_steps':nsteps,'native_end_state':25,'canonical_end_state':state,
 'head':head-offset,'min_head':lo-offset,'max_head':hi-offset,
 'marker':ones[0],'header':ones[1],'gap':49,
 'active_registers':blocks[:9],'spare_block_count':len(blocks)-9,
 'nonzero_spares':[[i,v] for i,v in enumerate(blocks[9:]) if v],
 'full_tape_matches_construction':True,
 'remaining_entry_invariants':['Whenever old state1 is entered on0 in a proper run, the preceding cell is1.','Whenever state45 reads1 in a proper run, its next cell is1.'],
}
(OUT/'independent_review237.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
