"""Four-row construction and finite blank replay of the 237-state machine."""
from pathlib import Path
from collections import deque
import hashlib
from independent_runtime import table

BASE_SHA = 'ffe370842d70bae96688ad5e290073edffe0bb213cf12fe562a75a74bec966de'
NATIVE_SHA = '36775740917dff0e8328b8bd5f97bbb1483b797bb6afceb4f703d22be16d6478'
DENSE_SHA = '534f49111e493d2c1211aaf5155798b11b3d8b573b848bd4498ea20ec98cb930'
STEPS = 3601258


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(rows, start):
    return ('#! start %d\n' % start + ''.join(
        '%d %d %d %s %d\n' % (q, b, w, 'R' if d == 1 else 'L', t)
        for (q, b), (w, d, t) in sorted(rows.items()))).encode('ascii')


def build(root, out):
    root, out = Path(root), Path(out)
    raw = (root/'inputs/mira-pa238.tm').read_bytes()
    if digest(raw) != BASE_SHA:
        raise ValueError('Baseline hash mismatch')
    baseline = table(root/'inputs/mira-pa238.tm')
    rows = {key: value for key, value in baseline.items() if key[0] != 1}
    changes = {(0, 0): (1, -1, 4), (3, 0): (1, -1, 0),
               (3, 1): (1, 1, 60), (45, 1): (0, 1, 3)}
    rows.update(changes)
    if len(rows) != 474 or set(rows) != {
            (q, b) for q in range(238) if q != 1 for b in (0, 1)}:
        raise ValueError('Wrong native state census')
    if any(q != 238 and (q, 0) not in rows for _, _, q in rows.values()):
        raise ValueError('Dangling transition')
    seen, order, queue = {3}, [3], deque([3])
    while queue:
        q = queue.popleft()
        if q == 238:
            continue
        for b in (0, 1):
            target = rows[q, b][2]
            if target not in seen:
                seen.add(target)
                order.append(target)
                queue.append(target)
    if seen != set(range(239))-{1}:
        raise ValueError('Not every retained state is graph reachable')
    order.remove(238)
    order.append(238)
    renaming = {q: i for i, q in enumerate(order)}
    dense = {(renaming[q], b): (w, d, renaming[t])
             for (q, b), (w, d, t) in rows.items()}
    native_raw, dense_raw = encode(rows, 3), encode(dense, 0)
    if digest(native_raw) != NATIVE_SHA or digest(dense_raw) != DENSE_SHA:
        raise ValueError('Reconstructed machine hash mismatch')
    if native_raw != (root/'machine/u237.native.tm').read_bytes():
        raise ValueError('Delivered native bytes differ')
    if dense_raw != (root/'machine/u237.tm').read_bytes():
        raise ValueError('Delivered canonical bytes differ')
    out.mkdir(parents=True, exist_ok=True)
    (out/'u237.native.tm').write_bytes(native_raw)
    (out/'u237.tm').write_bytes(dense_raw)
    return rows, dict(status='PASS', working_states=237, transitions=474,
                     start=0, halt=237, native_sha256=NATIVE_SHA,
                     canonical_sha256=DENSE_SHA, baseline_sha256=BASE_SHA,
                     deleted_native_states=[1], changed_retained_rows=[
                         [q, b, w, d, t] for (q, b), (w, d, t) in changes.items()],
                     old_state_of_canonical=order)


def replay(rows):
    q, head, ones = 3, 0, set()
    for _ in range(STEPS):
        if q == 238:
            raise ValueError('Halt before the verified checkpoint')
        write, direction, q = rows[q, int(head in ones)]
        if write:
            ones.add(head)
        else:
            ones.discard(head)
        head += direction
    ordered = sorted(ones)
    origin, header = ordered[:2]
    if (q, head, origin, header) != (25, -26, -27, 23):
        raise ValueError('Wrong literal checkpoint')
    cursor, values = header+1, []
    while cursor <= ordered[-1]:
        if cursor in ones or cursor+1 not in ones:
            raise ValueError('Malformed unary register file')
        cursor += 1
        n = 0
        while cursor in ones:
            n += 1
            cursor += 1
        values.append(n-1)
    if values[:9] != [0, 2, 0, 0, 0, 0, 6, 0, 0] or len(values) != 826:
        raise ValueError('Wrong logical seed')
    reconstructed, cursor = {origin, header}, header+1
    for value in values:
        reconstructed.update(range(cursor+1, cursor+value+2))
        cursor += value+2
    if reconstructed != ones:
        raise ValueError('Whole-tape reconstruction failed')
    return dict(steps=STEPS, state_native=q, state_canonical=25,
                head=head, origin=origin, header=header, zero_gap=49,
                physical_registers=values[:9], blocks=len(values),
                spare_values=values[9:], one_cells=ordered,
                nonzero_spares=[[i, v] for i, v in enumerate(values[9:]) if v],
                whole_tape_reconstruction=True)
