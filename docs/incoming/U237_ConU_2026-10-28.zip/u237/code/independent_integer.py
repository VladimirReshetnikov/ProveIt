"""Independent two-integer-tape replay of the proposed PA237 bootstrap."""
from pathlib import Path
import json,hashlib,time,sys
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'machine'
OUT=Path(sys.argv[1]).resolve()
if not __debug__ or sys.flags.optimize:raise RuntimeError('Assertions required')
def read(path):
    t={}
    for line in path.read_text().splitlines():
        if line.startswith('#') or not line:continue
        q,b,w,d,n=line.split();key=(int(q),int(b))
        if key in t:raise ValueError('Duplicate row')
        if d not in ('L','R'):raise ValueError('Direction')
        t[key]=(int(w),d=='R',int(n))
    return t
C=read(D/'u237.tm');T=read(D/'u237.native.tm')
meta=json.loads((ROOT/'evidence/construction.json').read_text())
boot=json.loads((ROOT/'evidence/bootstrap.json').read_text())
order=meta['old_state_of_canonical'];inv={old:new for new,old in enumerate(order)}
assert len(order)==238 and len(inv)==238 and order[0]==3 and order[-1]==238
assert set(q for q,b in C)==set(range(237)) and len(C)==474
assert set(q for q,b in T)==set(range(238))-{1} and len(T)==474
for (q,b),(w,d,n) in T.items():assert C[inv[q],b]==(w,d,inv[n])
rows=[[C[q,b] for b in (0,1)] for q in range(237)]
q=h=L=R=0;start=time.monotonic()
for tick in range(boot['steps']):
    assert q!=237,('Early halt',tick)
    w,d,q=rows[q][R&1]
    R=(R&-2)|w
    if d:L=(L<<1)|(R&1);R>>=1;h+=1
    else:R=(R<<1)|(L&1);L>>=1;h-=1
assert q==25 and h==boot['head']
ones=[]
for number,base,step in ((L,h-1,-1),(R,h,1)):
    i=0
    while number:
        if number&1:ones.append(base+step*i)
        number>>=1;i+=1
assert sorted(ones)==boot['one_cells']
# Parse the whole finite word independently, retaining every spare block.
lo=min(ones);hi=max(ones);one_set=set(ones);header=min(x for x in ones if x>lo)
assert h==lo+1 and header-h==49
at=header+1;vals=[]
while at<=hi:
    assert at not in one_set
    j=at+1
    while j in one_set:j+=1
    assert j>at+1
    vals.append(j-at-2);at=j
assert at==hi+1
assert vals[:9]==[0,2,0,0,0,0,6,0,0] and vals[9:]==boot['spare_values']
result={'status':'PASS','method':'independent canonical two-integer tape; whole finite word parsing',
 'steps':boot['steps'],'working_states':len(C)//2,'transitions':len(C),'canonical_state':q,
 'head':h,'gap':header-h,'active':vals[:9],'blocks':len(vals),'nonzero_spares':[[i,v] for i,v in enumerate(vals[9:]) if v],
 'canonical_sha256':hashlib.sha256((D/'u237.tm').read_bytes()).hexdigest(),
 'native_sha256':hashlib.sha256((D/'u237.native.tm').read_bytes()).hexdigest(),
 'seconds':time.monotonic()-start}
(OUT/'independent-integer-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
