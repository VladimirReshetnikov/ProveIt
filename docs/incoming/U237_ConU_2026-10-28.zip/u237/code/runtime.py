"""Quantified whole-tape instruction checks for the PA238 interpreter.

Adapted from the K215 affine unary/list proof checker, with PA238's actual
block transducers and a carry-zero left-shift lemma. No bounded register
tests are used as induction premises. This is a mathematical certificate
checker, not a proof-assistant kernel.
"""
from pathlib import Path
import json, sys, time
import symbolic_core as s
from source import validate_sites
import hashlib

PHY = (6, 7, 0, 2, 1, 8, 4, 3, 5)
DISPATCH = 25
HALT = 238
BASE_GAP = 38
original_normal = s.normal


def normal(atoms):
    out = original_normal(atoms)
    # B(A) 01 = 01 D(A), D(v)=1^v 01, by list induction.
    for i in range(len(out)-2):
        a,b,c=out[i:i+3]
        if (a[:2]==('run',0) and a[2][0]>=1 and
            b[:2]==('run',1) and b[2]==s.num(1) and
            c[:2]==('list','D') and not c[3]):
            return normal(out[:i]+[s.run(0,s.minus1(a[2])),
                ('list','B',c[2],False),s.bit(0),s.bit(1)]+out[i+3:])
    return out


s.normal = normal


class State(s.State):
    def step(self, table, lemmas, clock, motion):
        self.key()
        src,dst=(self.right,self.left) if self.direction==1 else (self.left,self.right)
        # Traverse an arbitrary reversed list and the guaranteed following
        # one in one positive macro. If the list is empty this is literally
        # the 15/1 row. If nonempty its first row equals 11/1, the checked
        # list traversal ends in 11, and that same row consumes the next one.
        if (self.q==15 and self.direction==-1 and len(src)>=2 and
            src[0][:2]==('list','B') and src[0][3] and
            src[1][:2]==('run',1) and src[1][2][0]>=1 and
            table[15,1]==table[11,1]==(1,-1,15)):
            if lemmas.get((11,-1,'B',True))!='B':
                raise AssertionError('Return-list traversal is not proved')
            a=src.pop(0)
            dst.insert(0,('list','B',a[2],False))
            src[0]=s.run(1,s.minus1(src[0][2]))
            dst.insert(0,s.bit(1))
            width=s.add(s.var(12),s.num(1))
            return s.add(clock,width),s.add(motion,s.neg(width)),('list_started_return',15)
        if (self.q==9 and self.direction==-1 and len(src)>=2 and
            src[0]==s.bit(0) and src[1][:2]==('list','B') and src[1][3]):
            if ('carry_zero_left',9) not in lemmas:
                raise AssertionError('Carry-zero traversal is not proved')
            a=src.pop(1)
            dst.insert(0,('list','D',a[2],False))
            width=s.var(12)
            return s.add(clock,width),s.add(motion,s.neg(width)),('list_carry',9)
        return super().step(table,lemmas,clock,motion)


def prove_blocks(table):
    signatures=[(99,1,'B','B'),(78,1,'B','B'),(10,1,'B','B'),
                (137,1,'B','C'),(11,-1,'B','B'),(7,-1,'B','B'),
                (8,-1,'B','B')]
    lemmas={}; certificates=[];v=s.var(2)
    for q,d,before,after in signatures:
        L=('opaque','left');R=('opaque','right')
        if d==1:
            state=State(q,[L],s.block(v,before)+[R])
            target=State(q,s.rev(s.block(v,after))+[L],[R])
        else:
            state=State(q,s.rev(s.block(v,before))+[L],[R],-1)
            target=State(q,[L],s.block(v,after)+[R],-1)
        clock=s.ZERO;motion=s.ZERO;trace=[]
        for _ in range(50):
            if state.key()==target.key():break
            clock,motion,event=state.step(table,{},clock,motion);trace.append(event)
        else:raise AssertionError(('Block lemma failed',q,d))
        if clock!=s.add(v,s.num(2)):raise AssertionError(('Block duration',q,clock))
        if motion!=(clock if d==1 else s.neg(clock)):
            raise AssertionError(('Block displacement',q,motion))
        lemmas[q,d,before,d==-1]=after
        certificates.append(dict(entry=q,direction=d,before=before,after=after,
                                 duration=clock,trace=trace))
    L=('opaque','left');R=('opaque','right')
    state=State(9,[s.bit(0)]+s.rev(s.block(v))+[L],[R],-1)
    target=State(9,[s.bit(0),L],[s.run(1,v),s.bit(0),s.bit(1),R],-1)
    clock=s.ZERO;motion=s.ZERO;trace=[]
    for _ in range(50):
        if state.key()==target.key():break
        clock,motion,event=state.step(table,{},clock,motion);trace.append(event)
    else:raise AssertionError(('Carry-zero block lemma failed',state.key(),target.key()))
    if clock!=s.add(v,s.num(2)):raise AssertionError('Carry block duration')
    if motion!=s.neg(clock):raise AssertionError('Carry block displacement')
    lemmas['carry_zero_left',9]=True
    certificates.append(dict(entry=9,direction=-1,kind='carry_zero',duration=clock,
                             trace=trace))
    return lemmas,certificates


def case(table,lemmas,site,positive=False,keep_trace=False):
    pc,op,arg=site
    values=[s.var(2+i) for i in range(9)]
    if op=='CD':values[arg]=s.add(s.num(1),values[arg]) if positive else s.ZERO
    physical=[None]*9
    for i,j in enumerate(PHY):physical[j]=values[i]
    result=physical.copy();overflow=0;extra=None
    if op=='CI':
        result[PHY[arg]]=s.add(result[PHY[arg]],s.num(1))
        successor,overflow=s.r.inc(pc)
    elif op=='CD' and positive:
        result[PHY[arg]]=s.minus1(result[PHY[arg]])
        successor,overflow=s.r.inc(pc);extra=0
    elif op in ('CD','CB'):
        successor,overflow=s.r.inc(s.r.strip(pc,'0',arg if op=='CB' else 1))
    elif op=='CC':successor=s.r.strip(pc,'1',arg)
    elif op=='CH':successor=''
    else:raise ValueError(site)
    state=State(DISPATCH,[s.bit(1),s.BLANK],
        [s.bit(int(b)) for b in pc]+[s.run(0,s.add(s.var(1),s.num(BASE_GAP-len(pc)))),
        s.bit(1)]+s.file_bits(physical))
    target=State(DISPATCH,[s.bit(1),s.BLANK],
        [s.bit(int(b)) for b in successor]+[s.run(0,s.add(s.var(1),
        s.num(BASE_GAP+overflow-len(successor)))),s.bit(1)]+s.file_bits(result,extra))
    targetkey=target.key();clock=s.ZERO;motion=s.ZERO;trace=[];rows=set()
    for count in range(4000):
        key=state.key()
        if count and ((op=='CH' and state.q==HALT) or (op!='CH' and key==targetkey)):
            if not s.nonnegative(clock) or clock[0]<=0:raise AssertionError('No progress')
            if op!='CH' and motion!=s.num(-overflow):raise AssertionError('Displacement')
            return dict(symbolic_steps=count,duration=clock,motion=motion,
                        rows=sorted(rows),trace=trace)
        clock,motion,event=state.step(table,lemmas,clock,motion)
        if event[0]=='list_started_return':
            rows.add((15,1));rows.add((11,1))
        elif event[0] not in ('list','list_carry'):rows.add(event[1][:2])
        if keep_trace:trace.append(event)
    raise AssertionError(('Instruction did not close',site,positive,state.key(),targetkey))


def check(table_path, sites_path, output, limit=None):
    table=s.r.table(table_path);sites=json.loads(Path(sites_path).read_text())
    validate_sites(sites)
    if len(table)!=474 or {q for q,b in table}!=set(range(238))-{1}:
        raise ValueError('Expected the complete 237-state native table')
    if {z for w,d,z in table.values()}-{q for q,b in table}!={238}:
        raise ValueError('Wrong halt convention')
    table_sha=hashlib.sha256(Path(table_path).read_bytes()).hexdigest()
    if table_sha!='36775740917dff0e8328b8bd5f97bbb1483b797bb6afceb4f703d22be16d6478':
        raise ValueError('Literal native table differs from the target')
    lemmas,blocks=prove_blocks(table);cases=[];start=time.monotonic()
    for i,site in enumerate(sites):
        for pos in ((False,True) if site[1]=='CD' else (False,)):
            try:r=case(table,lemmas,site,pos)
            except Exception as e:
                print('FAIL',i,site,pos,str(e),flush=True)
                raise
            r.pop('trace');cases.append(dict(site_index=i,positive=pos,**r))
        if (i+1)%500==0:print('sites',i+1,'seconds',round(time.monotonic()-start,2),flush=True)
        if limit is not None and i+1>=limit:break
    report=dict(status='PASS' if len(cases)==sum(2 if x[1]=='CD' else 1 for x in sites)
                else 'PARTIAL',sites=len(sites),cases=len(cases),blocks=blocks,
                seconds=time.monotonic()-start,cases_data=cases,
                table_sha256=table_sha,
                sites_sha256=hashlib.sha256(Path(sites_path).read_bytes()).hexdigest(),
                checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                core_sha256=hashlib.sha256(Path(s.__file__).read_bytes()).hexdigest(),
                scope='Every source leaf; arbitrary natural active values, extra gap, '
                      'first spare value and arbitrary finite remaining spare list; '
                      'complete zero exterior. Mathematical induction certificates, '
                      'not a proof-assistant kernel check.')
    Path(output).write_text(json.dumps(report,indent=2)+'\n')
    print({k:v for k,v in report.items() if k not in ('blocks','cases_data')},flush=True)
    return report


if __name__=='__main__':
    check(*sys.argv[1:4],limit=int(sys.argv[4]) if len(sys.argv)>4 else None)
