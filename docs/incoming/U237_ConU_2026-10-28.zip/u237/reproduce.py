#!/usr/bin/env python3
"""Non-mutating complete replay of the U237 research archive.

Uses Python 3.10+ and the standard library. This checks a mathematical
simulation certificate; it is not a proof-assistant kernel invocation.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'code'))
if not __debug__ or sys.flags.optimize:
    raise RuntimeError('Proof assertions must be enabled; do not use python -O')
import construct
import source
import runtime


def need(value, message):
    if not value:
        raise ValueError(message)


def hashes():
    manifest = ROOT/'SHA256SUMS'
    expected = {}
    for line in manifest.read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = ROOT/name
        need(path.is_file(), 'Missing release file: '+name)
        need(hashlib.sha256(path.read_bytes()).hexdigest() == digest,
             'Release hash mismatch: '+name)
        expected[name] = digest
    need('machine/u237.tm' in expected and 'report.pdf' in expected,
         'Manifest omits a main deliverable')
    return len(expected)


def rejected(action, name):
    try:
        action()
    except (AssertionError, ValueError, KeyError):
        return dict(control=name, status='REJECTED_AS_REQUIRED')
    raise ValueError('Invalid control was accepted: '+name)


def replay(output):
    start = time.monotonic()
    count = hashes()
    print('Release hashes:', count, 'PASS', flush=True)
    rows, construction = construct.build(ROOT, output)
    checkpoint = construct.replay(rows)
    need(checkpoint == json.loads((ROOT/'evidence/bootstrap.json').read_text()),
         'Whole bootstrap differs from the delivered checkpoint')
    print('Exact construction and 3,601,258-step bootstrap: PASS', flush=True)
    sites, site_bytes, source_report = source.extract(ROOT/'inputs/physical-program.json')
    need(site_bytes == (ROOT/'inputs/sites.json').read_bytes(),
         'Reconstructed source paths differ')
    need(source_report == json.loads((ROOT/'evidence/source-check.json').read_text()),
         'Source certificate differs')
    for name in ('independent_dense.py', 'independent_integer.py'):
        child = subprocess.run([sys.executable, '-B', str(ROOT/'code'/name), str(output)],
                               capture_output=True, text=True)
        (output/(name+'.log')).write_text(child.stdout+child.stderr)
        need(child.returncode == 0, 'Independent checker failed: '+name+'\n'+child.stderr)
        print(name+': PASS', flush=True)
    actual = runtime.check(ROOT/'machine/u237.native.tm', ROOT/'inputs/sites.json',
                           output/'runtime.json')
    # Compare JSON data in one representation: live affine vectors and
    # transition rows use tuples, while JSON arrays deserialize as lists.
    actual = json.loads(json.dumps(actual))
    saved = json.loads(gzip.decompress((ROOT/'evidence/runtime-cases.json.gz').read_bytes()))
    need(actual['status'] == 'PASS' and actual['cases'] == 5732,
         'The universal instruction check is incomplete')
    need(actual['blocks'] == saved['blocks'] and actual['cases_data'] == saved['cases_data'],
         'Fresh induction certificates differ from the saved exact cases')
    lemmas, _ = runtime.prove_blocks(rows)
    broken = dict(rows)
    broken[137, 0] = (0, 1, 149)
    controls = [rejected(lambda: runtime.prove_blocks(broken), 'broken block transducer'),
                rejected(lambda: source.validate_sites(sites[:-1]), 'omitted source leaf')]
    # This wrong selector row still has a complete deterministic table, but
    # violates a complete instruction contract. Its rejection checks the
    # symbolic proof rules, not merely a hash or a state count.
    broken = dict(rows)
    broken[3, 1] = (0, 1, 60)
    index = next(c['site_index'] for c in saved['cases_data'] if [3, 1] in c['rows'])
    entry = next(c for c in saved['cases_data']
                 if c['site_index'] == index and [3, 1] in c['rows'])
    controls.append(rejected(lambda: runtime.case(broken, lemmas, sites[index],
                                                  entry['positive']),
                             'wrong contextual selector transition'))
    print('Three invalid controls: rejected', flush=True)
    need(hashes() == count, 'Release changed during replay')
    report = dict(status='PASS', working_states=237, transitions=474,
                  canonical_sha256=construct.DENSE_SHA,
                  source_leaves=len(sites), symbolic_cases=actual['cases'],
                  symbolic_steps=sum(c['symbolic_steps'] for c in actual['cases_data']),
                  minimum_duration_constant=min(c['duration'][0]
                                                for c in actual['cases_data']),
                  startup_steps=construct.STEPS, independent_startup_replays=2,
                  whole_tape_checkpoint_match=True, negative_controls=controls,
                  release_files_checked=count, seconds=time.monotonic()-start,
                  scope='Exact finite construction and startup; complete arbitrary-value '
                        'symbolic instruction induction certificates. The PA/U proof '
                        'translations are the mathematical argument in report.pdf; '
                        'this command does not invoke a proof-assistant kernel.')
    (output/'replay.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify-only', action='store_true',
                        help='Verify sealed file hashes only; no mathematical replay')
    parser.add_argument('--output', type=Path,
                        help='Keep fresh logs outside the sealed release directory')
    args = parser.parse_args()
    if args.verify_only:
        print('Hash checks PASS:', hashes(), 'files; no runtime replay requested')
        return
    if args.output is not None:
        output = args.output.resolve()
        need(output != ROOT and ROOT not in output.parents,
             'Fresh output must be outside the sealed release directory')
        output.mkdir(parents=True, exist_ok=True)
        replay(output)
    else:
        with tempfile.TemporaryDirectory(prefix='u237-replay-') as name:
            replay(Path(name))


if __name__ == '__main__':
    main()
