A 237-STATE TURING MACHINE FOR CON(U)
===================================
Research prepared for Vladimir Reshetnikov, 28 October 2026.

RESULT
------
The literal machine machine/u237.tm has 237 working states, two symbols,
one two-way infinite tape, a completely blank initial tape, initial state 0,
and separate halt 237. Initialization is included. There are 474 transitions.

The ordinary mathematical proof in report.pdf establishes

    PA proves Nonhalt(u237, blank) <-> Con(U).

U is precisely the unary power-covering theory in the supplied
pa_unary_power_cover.zip. The construction uses the equivalence
PA proves Con(U) <-> Con(PA), together with a smaller implementation of
Mira's existing PA consistency search. It establishes 237 < 238, the
requested threshold. It does not establish an absolute state minimum.

Canonical machine SHA-256:
534f49111e493d2c1211aaf5155798b11b3d8b573b848bd4498ea20ec98cb930

WHAT CHANGED
------------
Starting with the pinned PA238 table, delete old state 1 and change only:

    state read write direction next
       0    0     1      L        4
       3    0     1      L        0
       3    1     1      R       60
      45    1     0      R        3

Start in old state 3, then rename working states densely to 0..236.
The native table preserves the original labels for audit.

After 3,601,258 literal steps from blank, the machine has dispatcher 25,
head -26, marker -27, header 23, zero gap 49, and exactly the original
active physical register seed [0,2,0,0,0,0,6,0,0]. All 817 spare blocks
are retained in the full checkpoint. Nonzero spares are 0:3, 3:1, 376:1.

The complete runtime check proves 5,732 symbolic instruction cases for
all 4,409 source leaves, including both decrement branches. The quantified
domain is every natural active register value, extra gap, first spare
value and arbitrary finite remaining spare list, with the complete zero
exterior and a valid source program counter. Thus spare lists are nonempty.

REPRODUCE
---------
Python 3.10+; standard library only. From any current working directory:

    python3 -B /path/to/extracted/u237/reproduce.py

Or, inside this directory:

    python3 -B reproduce.py

This verifies release hashes, exact machine reconstruction, full source
and control-flow bindings, sparse blank replay, two independent canonical
blank replays, all 5,732 symbolic cases, and three invalid controls. Fresh
results must match the delivered mathematical certificates exactly. The
default writes only to a temporary directory. A full run takes several
minutes, depending on the host. To retain fresh results outside the release:

    python3 -B reproduce.py --output /absolute/path/to/fresh-u237-check

Hash checks alone (not a proof replay):

    python3 -B reproduce.py --verify-only

Do not run with -O: assertions are part of the proof-obligation checker.
The driver rejects optimized Python. No network access is needed.

PDF REBUILD
-----------
The complete LaTeX source is report.tex, evidence-summary.tex, and
machine/table.tex. With a standard TeX Live installation:

    pdflatex -interaction=nonstopmode -halt-on-error report.tex
    pdflatex -interaction=nonstopmode -halt-on-error report.tex

Build in a copy if preserving the sealed release hashes matters. Different
TeX versions and PDF metadata can produce different PDF bytes.

PROOF STATUS
------------
The new runtime certificates express number/list induction on the actual
table; they are not finite register sampling. The finite bootstrap is
checked by three separate tape representations. The PA internalization
and U calibration are ordinary proofs by finite syntax transport, explained
in the paper and audit notes. This archive does not contain a newly checked
Lean, Rocq, or MM0 proof of u237 or an exported PA derivation. The reference
PA238 theorem is an external Rocq result; that fact is explicitly separated
from the additional internalization argument.

No unconditional consistency or nonhalting claim is made. The biconditional
itself has no consistency hypothesis. No 236-state candidate was accepted.

CONTENTS
--------
report.pdf / report.tex     Complete research report and LaTeX source.
machine/                   Canonical and native tables; full table appendix.
inputs/                    Baseline table and exact physical source data.
code/                      Constructor, source binding, symbolic proof rules,
                           two independently implemented finite reviewers.
evidence/                  Full startup, source checks, exact per-case
                           induction certificates and numerical summaries.
notes/                     Independent theory, internalization and construction
                           audits. These reviews are within this collaboration.
licenses/                  Inherited notices and applicable license texts.
PROVENANCE.json             Pinned repositories, commits, paths, source hashes.
SHA256SUMS                 Sealed release file hashes.
reproduce.py               Non-mutating integrated replay.

ATTRIBUTION
-----------
Mira's PA238 machine and the proof development in Jeff Ketchersid's
busy-beaver repository are the baseline. The source/interpreter has the
Andrew Wade ancestry recorded there. The affine/list checker is adapted
from ProveIt's K215 infrastructure, with notices retained. The U theorem
is inherited from the supplied 27 October 2026 archive. The four-row
reduction, initializer and new validation were produced for this request.
Existing attribution and third-party terms are not replaced by this work.
