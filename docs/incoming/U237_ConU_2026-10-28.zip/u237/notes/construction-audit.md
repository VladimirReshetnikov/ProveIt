# Independent audit of the PA237 construction

## Literal machine and bootstrap

Independently parsed both transition tables, checked their 474 actions, and
verified the supplied bijective relabeling between native labels and working
states 0--236 plus halt 237. Native state 1 is absent; old state 3 is the new
start, mapped to canonical state 0. No extra uncounted initialization state
is used.

Canonical table SHA-256:

    534f49111e493d2c1211aaf5155798b11b3d8b573b848bd4498ea20ec98cb930

Native table SHA-256:

    36775740917dff0e8328b8bd5f97bbb1483b797bb6afceb4f703d22be16d6478

The separate verifier `verify237_boot.py` uses two nonnegative integer bit
stacks for the two sides of the tape, rather than the constructor's sparse
set of one-cells. It executes the canonical table from a blank tape for
exactly 3,601,258 transitions and excludes an earlier halt. It independently
parses the entire resulting finite tape, including every spare block.
It agrees with the supplied bootstrap witness:

* dispatcher state 25, head -26, origin marker -27;
* header at 23, hence 49 zero cells before the header;
* physical active values (0,2,0,0,0,0,6,0,0);
* 826 total blocks, including 817 spare blocks;
* nonzero spare values at spare indices 0,3,376 are respectively 3,1,1.

All one-cells, not merely these aggregates, were compared. The receipt is
`pa237_independent_bootstrap.json`.

## Runtime state folds

The transition comparison explains the two folds:

* States 1 and 4 have identical read-1 behavior. Their read-0 behaviors
  differ only by targeting old state 3 versus state 7.
* Old states 3 and 7 have identical read-1 behavior `(1,L,4)`. Their read-0
  behavior differs, so folding 3 into 7 requires the runtime invariant that
  each such old-3 entry scans a 1. This is a context-sensitive fold, not a
  global bisimulation on arbitrary tapes.

Once runtime references to old 3 have been redirected to 7, native state 3
can be repurposed. Its new read-0 action `(1,L,0)` begins blank initialization.
Its new read-1 action `(1,R,60)` is exactly the read-1 action of state 60.
The only newly redirected runtime edge is 45/1, which writes 0, moves right,
and enters new 3 instead of 60.

This latter replacement is correct whenever the next scanned cell is 1:
the 3/1 and 60/1 actions then coincide, so after one further literal step the
configurations are identical. No claim of global state-3/state-60 equivalence
is warranted. A quantified runtime certificate for the complete source must
verify the required context, or prove the resulting instruction endpoint
directly. Root's whole-tape symbolic checker is the intended independent
obligation; finite blank replay alone would not establish it.

## Why the changed spare file is admissible

The new bootstrap has a different gap and many different spare blocks from
PA238. The symbolic instruction contract quantifies an arbitrary extra gap,
an arbitrary first spare value, and an arbitrary finite remaining spare list.
The new gap is 38+11 and there is at least one spare block, so this complete
frame falls under that contract. It would be unsound to justify this using
only a register projection that discards the nonzero spares; the actual
whole-tape contract retains them throughout all instruction rounds.

## Proof composition once the full runtime receipt passes

For each source leaf and each decrement branch, the quantified certificate
constructs a strictly positive finite TM segment implementing the required
source effect. The source list must be checked complete and bound to the
retained PA program; instruction relabeling and source CFG agreement are
separate finite obligations. Determinism and strict positivity permit inverse
halt reflection by induction on the number of remaining literal steps.
The finite bootstrap followed by these rounds therefore yields halting
exactly when the established PA proof enumerator halts.

The proof/program bridges and their PA internalization are explained in
`pa238_internalization.md`. Composing them with this new finite prefix and
quantified runtime simulation proves, mathematically in PA,

    Nonhalt(PA237, blank) <-> Con(PA) <-> Con(U).

This is a conventional mathematical correctness proof with executable
certificates. Neither this audit nor the new Python checker constitutes a
new kernel-checked internal PA theorem. The unbounded runtime receipt is a
required part of the composition; the independent bootstrap receipt alone
only verifies the finite prefix.

## Updated checker review

The previously recommended alias hardening has been applied. The state-15
rule now fuses the reversed-list traversal and one known following 1 into a
positive macro of duration `list_width+1`. The explicit ordinary block motion
check is also present. These changes remove the prior pending-continuation
concern and make each acceleration event a direct finite-run lemma.
