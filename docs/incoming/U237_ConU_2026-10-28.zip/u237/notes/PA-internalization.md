# PA238: external endpoint and a separate PA-internalization argument

## Status distinction

The checked repository endpoint `Targets238.pa238_iff_ordinary_proved` states,
in the Rocq metatheory,

    blank_halts238 <-> PA238.PAeq_inconsistent.

It does **not** export an arithmetized theorem `PA proves (...)`, nor an MM0 or
other PA proof certificate. The README correctly describes finite ordinary-PA
refutations and literal executions. An arbitrary external equivalence need not
be provable in PA. The internal claim requires the finitary argument below.
The fact that the endpoint has no Rocq axioms is not, by itself, that argument.

## Fixed arithmetizations

Choose ordinary primitive-recursive encodings of finite terms, formulas,
finite classical natural-deduction derivation trees, finite axiom lists, and
finite TM configurations/runs. A PA axiom code carries its schema tag and,
for induction, its formula code. Universal closure and parameter retention
are primitive-recursive syntax operations. This gives the standard PA proof
predicate up to PA-verifiable intertranslation with a Hilbert presentation.

Let `PrfPA(p, false)` denote a checked finite ordinary-PA refutation and
`Run238(r)` denote a finite blank-tape run of the literal 238-state table ending
at halt. A sufficient internalization contract is primitive-recursive maps F,G
such that PA proves

    PrfPA(p, false) -> Run238(F(p)),
    Run238(r) -> PrfPA(G(r), false).

Map invalid inputs to a fixed default; the displayed implications only concern
valid inputs. Taking existential quantifiers gives the halting equivalence;
classical negation gives the nonhalting/consistency equivalence. No consistency
assumption, reflection principle, or soundness-of-PA statement is used.

## Finite proof translations are syntactic

`PAForward238.pa_PAeq_proof_family` has one branch for each finite arithmetic
axiom family, successor axioms, and the unrestricted induction family.
`PAForwardFinite238.finite_pa_refutation_from_proof_families` joins the finite
axiom contexts and transports the given natural-deduction derivation. The
interpreted arithmetic domain is inhabited by an actual finite S0 derivation.
The numerical graph/arithmetic lemmas are proofs *inside the interpreted set
theory*, not semantic premises about standard natural numbers.

For every non-induction PA axiom the translation uses a fixed finite proof.
For induction with formula phi it builds translated phi, freshens bound names,
and inserts it into one fixed finite induction-proof template. Formula
translation, bounded name environments, substitution, context concatenation,
weakening, cut, and rule expansion are primitive recursive. A structural
induction on the input derivation proves the resulting proof correct in PA.

`NativePointed238.S0_numeric_refutation` then translates finite S0 proofs to
the explicit numeric calculus. Formula padding, fresh labels, and finite
closing generalizations depend on syntax bounds computed from the formula.
The number of closing generalizations can be huge (a numeric formula code),
but is a primitive-recursive bound. The use of term/environment functions in
Rocq is notation for finite syntax operations: only names within the formula's
computed support matter. Arbitrary higher-type recursion is unnecessary.

In the reverse direction, `NumericBundle238.numeric_refutation_to_compact`
produces a finite compact-theory refutation.
`PACompactReverse238.compact_finite_proof_reverse` translates its finite
natural-deduction derivation and recursively cuts each finite translated
axiom context. Its axiom supplier is
`PABoundedComprehension238.actual_bounded_comprehension`, which constructs
actual PA derivations. Given phi, the latter inserts phi into the arithmetic
code-comprehension induction formula; it does not decide phi's truth.
Excluded middle is used as an ordinary PA proof rule. Hence this reverse
proof translator is also primitive recursive and PA-verifiable.

This establishes finite proof intertranslation by an ordinary mathematical
argument. This note is not an extraction or a new kernel check of the complete
translator.

## Numeric proof programs and an explicit enumeration bound

`Compiler238.compile` is structural recursion on a numeric derivation. Every
case supplies a concrete finite command list: `reset`, `row_program`,
`bundle_program`, `generalize_program`, or `mp_program`. `compile_falsity`
adds `start` and `finish` so that the resulting list halts from **any** retained
register contents. Its encoded candidate is `candidateN(ks)`, a nested Cantor
pairing of finitely many fields; this is primitive recursive. The code is at
least 32, whereas the literal bootstrap starts `nextproof` at 6.

For an arbitrary candidate n, `Candidate238.decode_fields_tail_bound` gives
`tail <= n`. If the continuation is nonzero, the next decoded candidate value
is `tail-1 < n`. Therefore every candidate drains or halts in at most n+1
numeric commands. Consequently the scheduler reaches and finishes candidate N,
or halts earlier, within

    sum(n+1, n=6,...,N) <= (N+2)^2

numeric commands. This is a PA-provable finite bound independent of the
register magnitudes carried over from earlier candidates. No appeal to an
unbounded search being total is needed for this particular prefix.

Every primitive numeric command has primitive-recursive value growth. For
example put H(B)=16(B+1)^2. Cantor pairing and all four formula constructors on
arguments <=B are at most H(B). Expanding the literal `Codes238.v` expressions
shows that `bundle` has constructor nesting depth 13; the nine rows and their
stack packing have bounded depth below 20. Unpairing has both coordinates at
most its input. Thus, for candidates <=N, a safe coarse bound on the retained
registers after one numeric command is

    F_N(B) = H iterated 20 times at (B+N+2).

From bootstrap register bound 6, iteration of F_N for (N+2)^2 commands is a
primitive-recursive bound on all command-boundary registers in the prefix.
The bound is intentionally enormous; it is a totality proof, not a speed claim.

## Source execution and literal microsteps

The source helper library has explicit decreasing natural-number measures:

* `ProgLib238.sem_while` inducts on the value of a decremented counter; its
  body leaves that counter unchanged.
* `pair134` uses the fixed pairing-helper shuttle measure (the sum of the two shuttle counters while the output accumulator grows).
* `unpair87` and `unpair88` use a bounded number of `next_pair` iterations.
* The remaining per-command routines are fixed compositions of these helpers.

These induction proofs construct finite source traces. Replacing them by
primitive recursion on their displayed measures produces a primitive-recursive
trace constructor for each numeric command. The finite program/DAG bisimulation
uses a fixed path-pair certificate. Its arithmetic verification consists of
finite tree/list traversals and equality of increment counts.

At the physical TM level, the dispatch invariant tracks the actual program
counter, gap/header, nine active registers, and **all spare blocks**, including
the nonzero bootstrap spare. Each increment/decrement/control instruction has
a strictly positive finite literal segment. Its trace is constructed by
recursion on finite list/block lengths and counter values. These are again
primitive-recursive constructions, with correctness proved by ordinary
number/list induction. Composing the command-prefix constructor with these
segment constructors produces the required F(p).

For the inverse map, parse a given finite literal halting trace. The finite
bootstrap certificate excludes a premature halt and locates the checkpoint.
At each dispatcher boundary apply the checked segment correspondence.
`Reflection238.inv238_reflects_halt` consumes a strictly positive number of
remaining literal steps each time. Its strong induction on remaining steps is
ordinary PA induction, and at most the input run length many boundaries are
processed. This constructs a finite register trace, then a numeric command
trace. It does not assume that arbitrary TM computations terminate.

## Soundness proof certificates along a run

`SoundCommands238.command_sound` maintains proofs of the current formula,
cache, and all stack entries. Although `safe_stack` is written as a universal
predicate over an infinite zero tail, the computational invariant can store a
finite list of proof certificates plus a fixed proof of code 0 as its default
tail. Push/pop manipulate that finite list; successful MP appends a derivation
node, and each AX operation inserts fixed schema-instance proofs. One can
retain zero entries even when their numeric pair coding collapses to zero.
This realizes the invariant by primitive recursion on the finite numeric run.
At halt, the cache has code 1, yielding a finite numeric refutation. Applying
the reverse compact/PA translator above produces G(r).

## Conclusion and appropriate claim

For this particular machine and these proof translations, the finite syntax,
explicit candidate bound, decreasing source loops, and finite positive TM
segments give a conventional proof that PA proves

    Nonhalt(PA238, blank) <-> Con(PA).

Combining this with the supplied U interpretation yields

    PA proves Nonhalt(PA238, blank) <-> Con(U).

A candidate with a PA-verifiable finite-trace equivalence to PA238 inherits
the same biconditional. The external Rocq endpoint is supporting evidence for
the underlying correspondences. The PA internalization described here is a
separate mathematical proof argument; no newly checked formal PA certificate
should be claimed.
