# Audit of U and the calibrated positive interface

## Input scope

Read the supplied archive's overview, unary_core, unary_arithmetic, unary_separation,
upper_transport, positive_interface, stream, and emitter sections. No unbounded
proof-assistant certificate for U is in that archive. Its finite tests do not
substitute for the following mathematical proof obligations.

## Schema and upper interpretation

The theory U is classical equality-free first-order logic over a nonempty domain,
with one binary relation E and every source-free unary power-cover instance:

  for all a, some b has
    every x in b satisfying phi(x), and
    every represented subset x of a satisfying phi(x) belonging to b.

There are no other nonlogical axioms. The stronger unrestricted parameter schema
W is also interpreted in PA by E(x,a) := Bit(a,x): Sub(x,a) implies x <= a,
and PA's formula-specific finite comprehension builds exactly the selected
subsets. PA proves irreflexivity in this interpretation. Thus W+IR has a
PA-verifiable refutation translation into PA, and W contains U.

## Lower interpretation audit

No circular use of total successors was found in the supplied dependency order.

1. Coextensionality is an equivalence by logic alone and respects membership in
   the second coordinate. Saturated containers provide first-coordinate
   congruence locally; the proof does not silently assume global extensionality.
2. The numeric predicate supplies transitive, saturated finite-order behavior,
   together with endpoints of represented intersections. Local predecessor and
   hypothetical-successor lemmas require no successor totality.
3. Parameter-free counterexample filtering gives induction for every unary
   predicate before successor totality. Arbitrary parameters are internalized
   by Q(v) = forall p (the base-and-step premises for theta(p) imply theta(v,p)).
   This matrix is legitimately unary.
4. The comparison and global least-witness arguments use this conditional
   induction and existing predecessors, so do not reintroduce successor totality.
5. Bounded numerical comprehension uses the lexicographically least failing
   numerical tuple, quantified *inside* its matrix. Invariance in each numerical
   parameter is necessary and is checked for the actual uses. The externally
   chosen supporting object never becomes a free matrix parameter.
6. Successor and numerical powers are then obtained. Saturated singleton, pair,
   and all-representatives Kuratowski codes have the stated supports.
7. Exact graph comprehension needs only a power W of a number n: component sets
   are subsets of n, so ordered-pair codes are subsets of W.
8. Canonical history extension/restriction quantifies old graphs internally and
   retains only numerical free parameters. Pointwise comparison is proved first,
   preventing an illicit graph-parameter comprehension.
9. Addition and multiplication follow by two concrete total-history recursions;
   translated arithmetic induction is an instance of step 3.

This gives a defensible conventional mathematical proof of the fixed
interpretation. Its proof-template operations are primitive recursive, and their
correctness can be established in PA by syntax and proof-length inductions.
The archive does not implement or kernel-check those general proof translators.

## Positive target audit

Let q(a)=E(a,a), D=forall v E(v,v), and take positive formulas built using E,
implication, and universal quantification. The positive shell is

  [forall b (V_phi(b,a) -> (U_phi(b) -> q(a)))] -> q(a).

At an irreflexive source it is the ordinary power-cover assertion. Replacing
falsity in a unary matrix by the *closed* D preserves unary scope. The theory
with the positive unary shells and not D interprets PA. Every support used in
the lower proof is irreflexive, including the potentially problematic numerical
power W: n in W; if W in W, then W subset n and hence n in n, contradiction.

For the raw arbitrary-input emitter, output-binder collision at inputs 0 and 1
is intentional and harmless. The two resulting meanings are q(a) or existence
of an empty object, and q(a) or J respectively, where J says every reflexive
object implies D. With not D, the latter yields global irreflexivity. Regular
inputs, padding of the two exceptional matrices, and uniform renaming yield all
unrestricted positive shells. Consequently R + not D and W + IR have
PA-verifiable proof conversions.

The positive theory R alone is consistent even in a one-object total relation
model. The machine target must be nonderivability of q0=E(v0,v0), not ordinary
consistency of R. The closed-seed deduction transformation and positive
conservativity identify this target with Con(U) through Con(PA).

## Machine-construction implication

An axiom emitter accepting *arbitrary* matrix parameters is sufficient and may
be cheaper than a unary validator. A machine need not encode U's long numeric
interpretation: it may search the positive raw theory R for q0, then invoke the
fixed mathematical PA calibration externally in its correctness proof.

Constructor/node counts, arithmetic polynomial degree, host-level register
counts, and finite samples give no binary single-tape state bound. The final
claim needs an actual complete blank-tape transition table, its counted
working states (separate halt), and a simulation proof tied to that table.
