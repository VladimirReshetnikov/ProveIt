# Decidable Regularity and Exact Stabilization of Crossover Closures

**Arithmetic invariants, sparse-marker trichotomies, and immediate loss of context-freeness**  
Research manuscript prepared with ChatGPT for Vladimir Reshetnikov, 30 September 2026.

## Read first

`article.pdf` is the compiled 23-page article; `article.tex` is its standalone source with an internal bibliography. The article develops results beyond the inspected ProveIt report on constrained crossover. Its main contributions are:

* A decidable finite-row criterion for regularity of the full constrained-crossover closure of a context-free seed, with effective DFA synthesis or an infinite marked-prefix obstruction. Full-closure comparison and Boolean-combination length sets are also decidable.
* An exact classification for sparse semilinear one-marker seeds: regular, linear context-free but nonregular, or non-context-free. Compatible distinct interior velocities cause non-context-freeness already at the first generation.
* An exact maximum-clique formula for stabilization depth and a coNP-completeness theorem for **binary-encoded ray inputs with variable depth**, even for regular endpoint-marker seeds. This is not a claim about the same complexity for explicit DFAs.
* A binary linear seed that reaches a non-context-free fixed point after one crossover, with at most four words per length; a uniform family realizes every positive finite depth.

Complete proofs, nine further research questions, and verification boundaries appear in the article.

## Status

This is an unrefereed mathematical research manuscript. No Lean or Rocq proof was produced or checked. The inherited coordinate hull, effective Parikh semilinearity, general monadic decomposition, and classical slender-language background are credited. The newness claim is relative to the inspected repository and a bounded literature search; global priority has not been established.

The exact finite audit passed **12,867 checks**, including all 1,099 labeled simple graphs on one through five vertices. These computations test implementations and finite specializations; they do not replace the universal proofs.

## Repository context

Pin: `b8b0fa2184a044d46ce9ed0f25f88d7bb60fa042`.

Predecessor:
`SetTheory/Cardinals/docs/reports/automata-and-formal-languages/constrained-crossover-closure/`

No files in the user's repository were modified. See `notes/provenance.md` for scope and sources.

## Rebuild the article

Requires a normal pdfLaTeX installation with `lmodern`, AMS packages, `mathtools`, `geometry`, `microtype`, `booktabs`, `array`, `longtable`, `xcolor`, `enumitem`, `fancyhdr`, `listings`, `hyperref`, and `bookmark`.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
# Alternatively run pdflatex three times.
```

No BibTeX or external graphics are needed. `make pdf` runs the same build.

## Run the exact ray analyzer

Python 3.10 or later, standard library only. Tested with Python 3.13.5.

```sh
python code/crossover_masks.py examples/two_markers.json
python code/crossover_masks.py examples/endpoint_cycle5.json
python code/crossover_masks.py examples/five_markers.json --output result.json
```

Input format:

```json
{
  "rays": [
    {"base": [0, 1], "step": [1, 2]},
    {"base": [1, 0], "step": [2, 1]}
  ]
}
```

A ray represents `(base_i, base_j) + t * (step_i, step_j)` for nonnegative integer `t`. The seed contains `0^i 1 0^j` for every represented pair, **and all words in `0*`**. The empty list is allowed. A zero step is a single finite point. All coordinates must be nonnegative integers. Python integers and rational arithmetic are exact.

Output reports the structural class, maximum number of simultaneous marker sites, parallel and frozen-source stabilization depths, and a cofinal maximum clique. A non-context-free result also provides a pair of distinct compatible interior velocities and a common length congruence. Clique and obstruction indices refer to the infinite-ray list, omitting finite points.

`maximum_clique` is an exact exponential-time branch-and-bound routine. Large ray inputs can be expensive. The analyzer does not expand huge periods into automata and does not scan all lengths.

This code does **not** implement a general CFG compiler, a Presburger solver, general semilinear-to-ray normalization, or DFA synthesis. The article proves those effective algorithms separately.

## Repeat the checks

```sh
python code/verify.py
# To refresh both delivered receipts in a working copy:
python code/verify.py > data/verification.txt
```

The script overwrites `data/verification.json`. It writes the text report to stdout. Work in a copy to preserve the delivered receipts.

The suite includes exact CRT enumeration, literal crossover on finite slices, complete-period comparison for random small ray inputs, all graphs through five vertices, and larger fixed-seed graph samples. Fixed pseudorandom seeds are recorded in the JSON receipt.

## Files

- `article.tex`, `article.pdf`: manuscript.
- `code/`: analyzer and finite verifier.
- `data/`: exact verification receipts and artifact checks.
- `examples/`: five ray inputs with their recorded results.
- `notes/`: provenance and proof audit.
- `Makefile`: build/check/clean helpers.
- `SHA256SUMS`: hashes of the final delivered files, excluding the hash ledger itself.
