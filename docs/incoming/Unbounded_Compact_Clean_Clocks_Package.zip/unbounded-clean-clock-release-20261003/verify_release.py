"""Verify every delivered byte, exact inventory, and mandatory local dependencies.

This is a consistency checker, not an external digital signature. Trust a separately
obtained archive digest when authenticity matters. Standard library only.
"""
from hashlib import sha256
import json
import os
from pathlib import Path
import stat

ROOT = Path(__file__).absolute().parent
MANIFEST = 'release-manifest.json'
DIGEST = MANIFEST + '.sha256'
MAX_FILES = 512
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_TREE_BYTES = 128 * 1024 * 1024
PINS = {'reproducibility/MANIFEST.json': '1bf1225aa950ad1d4f842c8bf098e1935925cd1d52c90453b7696c1321648f95', 'reproducibility/README.md': '99ce53f971e7da8f0ef79e308fe7e7aa58a71a2d575e8259ba67748d507de0cb', 'reproducibility/THEOREM.md': '93bf673898816aed526ef943160a9d3dfb950cedc3bf0f59d6ae4d78c7add11d', 'reproducibility/audit/EMITTED-CIRCUIT-AUDIT.md': '6b49b28fdc4f80b91d48bfbb9874ddf6e8891035fd0d689e2fec651f5f10acd3', 'reproducibility/audit/PROOF-AUDIT.md': 'ec2e89c5e6a23a25b4c1c7e85fb3625082b40f2e9bc4aeaceb04e22656912151', 'reproducibility/audit/check_degree_certificate.py': '975ecfa10c16f1ffbc9202a341fdea86a763cb5117081110c2a07fb847d7796c', 'reproducibility/audit/check_emitted_circuits.py': '770a27797020b667ebc2d0567203664f7dad8c83d0aa2eb3ff570bcc96d71e27', 'reproducibility/audit/degree_crosscheck.json': 'df1bcde4dece78663d07a1ce6d51eb38aa16c9d00e48c0e68f2e23a4b31bcdfa', 'reproducibility/audit/independent_emitted_circuit_audit.json': '50e3656eb796f0861de38523bbca03b610cbaa78dee8544c6318437f3b3ab44d', 'reproducibility/check_semantics.py': '435d220df26c679251e34ddb9723000412d83e72c98991be3b4679de0d71faee', 'reproducibility/circuits/incdec-native.dag.txt': '1061b3f15b33a6831ea3fe54df9a4d0966ad23d2b9619f8c5e068821c7a89001', 'reproducibility/circuits/incdec-native.json': '0b15774bfae926c332450ec3f85fa04d68f1ffd1cd06b995d50eb1e93f480bb8', 'reproducibility/circuits/incdec-phase4.dag.txt': 'b688f04c685bebe68932fffab955138895cb60a844bcb7a263fd5269dee57a70', 'reproducibility/circuits/incdec-phase4.json': '9be75161540999bbc17f9b8fbe713bf4f0864f66b7fd5d24e9fe6d7ff6d5c53b', 'reproducibility/circuits/nop-native.dag.txt': '024f113c6b6f6a16fa82170149b4f5a3e9489042d72b12072801e3db51511b0d', 'reproducibility/circuits/nop-native.json': '7f336034555b8760eb5b6ba6f98d07a91fbb2134e8317046582ca1e29c2593bb', 'reproducibility/circuits/nop-phase4.dag.txt': '372ae84ff76278415ac546fe62d6e37c70ea68082229855d53b87864fd2c0495', 'reproducibility/circuits/nop-phase4.json': 'fd0219fd217ff0007c9e6937eeb3909dfd8d410158cff846fe1361393b0a8ff5', 'reproducibility/circuits/positive3-native.dag.txt': '8839ee3aefd85ff959f9064db1cf1950d942e4a8361bced1146416a0a684bd9c', 'reproducibility/circuits/positive3-native.json': '62937b7759fee953641f16bb54f33c71421a91502516bbf133c0f423cc699a1b', 'reproducibility/circuits/positive3-phase4.dag.txt': '158be7c8cfc403ead665235d31ba319edb390a7e0bfc745a638c7c95260f40e3', 'reproducibility/circuits/positive3-phase4.json': '78746f78901be26b9f24f18ebf94fa0d003c2fa6f7252f50fa234bd776906c44', 'reproducibility/circuits/zero-step-native.json': '55635db65b7f25cffe1dad353d328ec6673451f135b7aa937cbfbbb81bba0160', 'reproducibility/circuits/zero-step-phase4.json': 'e27901298554353187f8f77c84c72b6b9b5418513da91322479c2652602c1af5', 'reproducibility/circuits/zero3-native.dag.txt': '1d1cc6db121395de3af229c674761392c3a4b3704502cf1f05a695ed224d997e', 'reproducibility/circuits/zero3-native.json': '7e3fcede624ae9325c36ff469360bac97e103125389e8458587c6754b0582f63', 'reproducibility/circuits/zero3-phase4.dag.txt': '3c1aa22ce536465328fc989f8873dee8f2ca360787cbfbb43bf7895af69b8e8c', 'reproducibility/circuits/zero3-phase4.json': '7b124d7dff09a5b95b9dc4ffd64721e0b364e1eafb5bb349467fd6289e155bd8', 'reproducibility/emit_clean_clocks.py': '29edf80ad567f215b55518d80667fcd4efa71455b54468b5fb206508bc9115f2', 'reproducibility/receipts/emission.json': 'd19d1558bde05474340a1da5a53e1d63ee9711a4d4c05d24ca125467ebd109ae', 'reproducibility/receipts/final-degree-replay.log': 'b7c4fbbb9b91cf34326cfe6c49022f5f8bd34da5b2285202bc2e7c1fc12d6d57', 'reproducibility/receipts/final-emission-replay.log': '0ee779dc6f951b59c2b9ba7f0feaef2324f0ee9054a67ebf4934cf4a85b73572', 'reproducibility/receipts/final-independent-replay.log': '131e64aced8931246aef0730f633be997ed072664caabe56902e8ab002cdb654', 'reproducibility/receipts/final-semantics-replay.log': '9892421b81e729f8daf59d381e23f8bdc45d8df3243c0037660d4f2d342446a7', 'reproducibility/receipts/semantics.json': '357e6376a9b47e14c7e4fecfd05139e732b9d64086a9820f344e5ac4f43e5e70', 'reproducibility/source/inherited_clean_target_theorem.md': '3d85f8cde66837d8916fb3273c2c57cc1a91ce37de1f3d6c6fe28a4db9103168', 'reproducibility/source/provenance.json': '9b38ad3411c8286003aa7a7f3237f2c4a9818d950d049305750229628d767b1a', 'reproducibility/source/residue_affine_packed_history.md': '0b6c533e8ef6c26b3ed5419dbb2baa44bc1509255c4bcf5226e5f85d37683882', 'reproducibility/source/review_three_mass_unbounded_interface.json': '3d30d2399401861fdd7400914f12eda6a33afea0e5575088300dfd27f9534212', 'reproducibility/source/review_three_mass_unbounded_interface.md': '401c354e49441c09a1e11068a07ee9d27b75f961dc61fd72039c4914ce2094fe', 'reproducibility/source/review_three_mass_unbounded_interface.py': '70f7c0c0959c5c3da1337956eb6ffdd47799915dd977839dc8f5a7358d4ebf69', 'reproducibility/source/three_mass_unbounded_interface.json': 'fe69f0504c8f68c4130c4b21fed5c817596ab5c0e2fdf9621b0bf5f45c12ac0e', 'reproducibility/source/three_mass_unbounded_interface.md': 'd336c8c12d3328eb4b6857ee382f91b2c9363f50effba5a7b1bf75308f25df45', 'reproducibility/source/three_mass_unbounded_interface.py': 'cf9aee77ab78d68a165cbc31e19ded6d1de69663b34e0078f0106777b472340a', 'reproducibility/verify_manifest.py': '8d3ebe6513cb89056cc792bf620c2d20e37b69ae3d96b7b1cccd08be8188a7d1', 'folded-clocks/ADDENDUM.md': '1ce912386db479f63eed0d05f2a7d79649b4d8a03b91bf2080338f1cafaafde8', 'folded-clocks/MANIFEST.json': '3896e694780c6620f3097503165925abc18285b8c40ff9c7c1755b092bde73ca', 'folded-clocks/PORTABILITY.md': '03953d5995e3849b1471647a19bbcd94c4af7e7a80d348fcbcf0b50638c46c01', 'folded-clocks/README.md': 'd7a611b90b73b7e70e13474c1bd8a833d2853a99643a6d595907c4568ce21e20', 'folded-clocks/audit/FIVE-GATE-FOLDING-AUDIT.md': '9d7009c9c66127013d6e9edb7985e7754e6ff9ca0b04fd6bccd3253d67d30290', 'folded-clocks/audit/check_folded_clocks.py': '9372d9c6c7d1bafb784d15bb89d552545d05733a02973d69e4333c5e8d86e1f7', 'folded-clocks/audit/final-live-base-replay.log': '4f3806f8dbc8d0e4663e7b67e13c430888144272d23f3f1347d79c92781bab58', 'folded-clocks/audit/independent_folded_clock_audit.json': 'e59b1464add0238496e82a16e87aa77d5657ac1bdf4026a93c1d674c5d91df98', 'folded-clocks/audit/initial-live-base-audit.log': 'f64b82ab25b497e0e7a19d0897c2151f3105aec9a80af5f7562fc6c5d53ca6e6', 'folded-clocks/audit/portable-read-only-replay.log': '7ef8eae35f1d704779e1d7bb3dd266c649a693829a4c8c1958afff7708ce17a0', 'folded-clocks/circuits/incdec-native-folded.dag.txt': '2d743df8b64e16e40c78dc25967f56f96ba98ec2bd692a641c4f77db310f3774', 'folded-clocks/circuits/incdec-native-folded.json': '016763e884341dce3c6f4edf5526503672cc36d963b37dcad92dad45b4fc87f6', 'folded-clocks/circuits/incdec-phase4-folded.dag.txt': 'ea728ffa3cf25f0e520465b351b053bd64e2c3a5156e71c98bc1b40bc400b132', 'folded-clocks/circuits/incdec-phase4-folded.json': 'f4e7874b92d083a139f4583819f46c4ee7ebb987455dc645f5e857acf5d90f48', 'folded-clocks/circuits/nop-native-folded.dag.txt': '8f45035ba32f027361e6241b1754daa81d49d24828183c464203992f5744033d', 'folded-clocks/circuits/nop-native-folded.json': '04725936d07fea801d05a2467e3f8648679f59f95d72b30853731ddc02261f2c', 'folded-clocks/circuits/nop-phase4-folded.dag.txt': 'acb15c431b457bf0e01295d891b63bde848bd1df39b550c973184ad2b1beb302', 'folded-clocks/circuits/nop-phase4-folded.json': 'f7f819da91f55e0e9d535b8bca6184ac15a7304390e6774c04dfb1af03e9d03f', 'folded-clocks/circuits/positive3-native-folded.dag.txt': '3bbc00ca1c1f29a68c6a08b6a98e104949129959758d7d22da77570c393ca405', 'folded-clocks/circuits/positive3-native-folded.json': 'a2981542883cb85385d96592c20c469fb719a3d8ff09c1cc94133813455b6284', 'folded-clocks/circuits/positive3-phase4-folded.dag.txt': '2de3fa83c223ab5014809fd6a7bfbca58e977f46c41232096cb93946c197b333', 'folded-clocks/circuits/positive3-phase4-folded.json': '7d08a3005d444b2e7b8c07e1e11a64a1c2472451d3e72182e3a95d0b0aa2c9be', 'folded-clocks/circuits/zero3-native-folded.dag.txt': '7554128b0697a30b763b6467cabc14e0379a54ba61e56d62f21f76a7fc69288a', 'folded-clocks/circuits/zero3-native-folded.json': '1c1a072c8a60d7b84e4acdb79e67609a14bcfe7568de6aa0d920cf1d56d3da16', 'folded-clocks/circuits/zero3-phase4-folded.dag.txt': '875bedb124aa68bc1d6ca495b6ea26e0b6c561d5e57444f567e283293e226d75', 'folded-clocks/circuits/zero3-phase4-folded.json': 'cd23cb3f29d51336f6cab68f99eb8cd926cf166bef143894b43fff404f1df988', 'folded-clocks/emit_folded_clocks.py': 'd7c5fe90c5a94a2bafd27cc220c19be7d7b9a5b2f228b0e5950464e12c9854d0', 'folded-clocks/original-MANIFEST.json': '774a4498984ebccf8216897e21bf597084e70b148557ba4fa12b597bba44ba91', 'folded-clocks/receipts/base-integrity-after-audit.log': '8e51d92e87114c28ec4248169610901880e5be956c87accfdaf76c70aae0e378', 'folded-clocks/receipts/base-integrity-before-audit.log': '8e51d92e87114c28ec4248169610901880e5be956c87accfdaf76c70aae0e378', 'folded-clocks/receipts/emission.json': 'e28dedb6d02cc104108fa2ce1ef1cf86ec0757295dc812bd909eb2d057e8d116', 'folded-clocks/receipts/emitter-replay.log': '3f484fa995932d20969b744f76884409d9a319938fca9d1b06dd31042f437374', 'folded-clocks/receipts/independent-live-base-replay.log': '4f3806f8dbc8d0e4663e7b67e13c430888144272d23f3f1347d79c92781bab58', 'folded-clocks/receipts/independent-portable-replay.log': '7ef8eae35f1d704779e1d7bb3dd266c649a693829a4c8c1958afff7708ce17a0', 'folded-clocks/receipts/relocated-portable-replay.json': 'f85c21e0bf2ba7599872365e446a26d538c9ba31bfd74e5e8cd8b3aac0bebfbd', 'folded-clocks/reference/base-MANIFEST.json': '1bf1225aa950ad1d4f842c8bf098e1935925cd1d52c90453b7696c1321648f95', 'folded-clocks/reference/incdec-native.json': '0b15774bfae926c332450ec3f85fa04d68f1ffd1cd06b995d50eb1e93f480bb8', 'folded-clocks/reference/incdec-phase4.json': '9be75161540999bbc17f9b8fbe713bf4f0864f66b7fd5d24e9fe6d7ff6d5c53b', 'folded-clocks/reference/nop-native.json': '7f336034555b8760eb5b6ba6f98d07a91fbb2134e8317046582ca1e29c2593bb', 'folded-clocks/reference/nop-phase4.json': 'fd0219fd217ff0007c9e6937eeb3909dfd8d410158cff846fe1361393b0a8ff5', 'folded-clocks/reference/positive3-native.json': '62937b7759fee953641f16bb54f33c71421a91502516bbf133c0f423cc699a1b', 'folded-clocks/reference/positive3-phase4.json': '78746f78901be26b9f24f18ebf94fa0d003c2fa6f7252f50fa234bd776906c44', 'folded-clocks/reference/zero3-native.json': '7e3fcede624ae9325c36ff469360bac97e103125389e8458587c6754b0582f63', 'folded-clocks/reference/zero3-phase4.json': '7b124d7dff09a5b95b9dc4ffd64721e0b364e1eafb5bb349467fd6289e155bd8', 'folded-clocks/verify_manifest.py': '8d3ebe6513cb89056cc792bf620c2d20e37b69ae3d96b7b1cccd08be8188a7d1'}


def require(ok, detail):
    if not ok:
        raise ValueError(detail)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def load_json(raw):
    return json.loads(raw, object_pairs_hook=unique_object)


def relative_name(name):
    require(type(name) is str and name and '\\' not in name and ':' not in name,
            'invalid relative path')
    path = Path(name)
    require(not path.is_absolute() and all(p not in ('', '.', '..') for p in name.split('/')),
            'invalid relative path: ' + name)
    require(path.as_posix() == name, 'noncanonical path: ' + name)
    return name


def inventory(root):
    root = Path(root).absolute()
    require(not root.is_symlink() and root.is_dir(), 'root must be an ordinary directory')
    files, directories = {}, set()
    total = 0
    for base, dirs, names in os.walk(root, followlinks=False):
        for name in sorted(dirs + names):
            path = Path(base) / name
            rel = relative_name(path.relative_to(root).as_posix())
            mode = path.lstat().st_mode
            require(not stat.S_ISLNK(mode), 'symlink rejected: ' + rel)
            if stat.S_ISDIR(mode):
                directories.add(rel)
            else:
                require(stat.S_ISREG(mode), 'nonregular file rejected: ' + rel)
                size = path.stat().st_size
                require(size <= MAX_FILE_BYTES, 'file size limit: ' + rel)
                total += size
                require(total <= MAX_TREE_BYTES, 'tree size limit')
                files[rel] = path
                require(len(files) <= MAX_FILES, 'inventory entry limit')
    return files, directories


def check_pins(root):
    root = Path(root)
    for name, expected in PINS.items():
        path = root / name
        require(path.is_file() and not path.is_symlink(), 'missing ordinary pinned dependency: ' + name)
        require(sha256(path.read_bytes()).hexdigest() == expected, 'dependency pin mismatch: ' + name)
    return dict(frozen_files=len(PINS), mathematical_manifest_sha256=PINS['reproducibility/MANIFEST.json'], folded_manifest_sha256=PINS['folded-clocks/MANIFEST.json'])


def verify(root=ROOT):
    root = Path(root).absolute()
    observed, directories = inventory(root)
    require(MANIFEST in observed and DIGEST in observed, 'missing release manifest or its digest')
    raw = observed[MANIFEST].read_bytes()
    require(len(raw) <= 1024 * 1024, 'manifest size limit')
    expected_digest = sha256(raw).hexdigest() + '  ' + MANIFEST + '\n'
    require(observed[DIGEST].read_text() == expected_digest, 'manifest digest mismatch')
    manifest = load_json(raw)
    require(type(manifest) is dict and set(manifest) == {'schema', 'files'}, 'manifest shape')
    require(manifest['schema'] == 'report21-exact-inventory-v1', 'manifest schema')
    entries = manifest['files']
    require(type(entries) is dict and 1 <= len(entries) <= MAX_FILES - 2, 'manifest file map')
    for name, entry in entries.items():
        relative_name(name)
        require(name not in (MANIFEST, DIGEST), 'self-referential manifest entry')
        require(type(entry) is dict and set(entry) == {'bytes', 'sha256'}, 'manifest entry shape: ' + name)
        require(type(entry['bytes']) is int and 0 <= entry['bytes'] <= MAX_FILE_BYTES, 'manifest byte count')
        require(type(entry['sha256']) is str and len(entry['sha256']) == 64 and
                all(c in '0123456789abcdef' for c in entry['sha256']), 'manifest digest syntax')
    expected = set(entries) | {MANIFEST, DIGEST}
    require(set(observed) == expected, 'inventory mismatch: extra=' + str(sorted(set(observed) - expected)) +
            ' missing=' + str(sorted(expected - set(observed))))
    wanted_dirs = {p.as_posix() for name in expected for p in Path(name).parents if p != Path('.')}
    require(directories == wanted_dirs, 'directory inventory mismatch: extra=' +
            str(sorted(directories - wanted_dirs)) + ' missing=' + str(sorted(wanted_dirs - directories)))
    for name, entry in entries.items():
        raw = observed[name].read_bytes()
        require(len(raw) == entry['bytes'] and sha256(raw).hexdigest() == entry['sha256'],
                'file content mismatch: ' + name)
    pins = check_pins(root)
    return dict(status='passed', files_verified=len(entries), **pins)


if __name__ == '__main__':
    print(json.dumps(verify(), indent=2))
