#!/usr/bin/env python3
"""Read-only SHA-256/byte-count verification of the mathematical freeze."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root/'MANIFEST.json').read_text())
for name, claim in manifest['files'].items():
    path = Path(name)
    if path.is_absolute() or '..' in path.parts:
        raise ValueError('Manifest path leaves artifact root')
    data = (root/path).read_bytes()
    if len(data) != claim['bytes'] or hashlib.sha256(data).hexdigest() != claim['sha256']:
        raise ValueError('Frozen artifact mismatch: '+name)
print(json.dumps({'status':'PASS','verified_files':len(manifest['files']),'manifest_sha256':hashlib.sha256((root/'MANIFEST.json').read_bytes()).hexdigest()},sort_keys=True))
