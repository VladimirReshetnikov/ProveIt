# Report 21 Unbounded compact clean clocks

The PDF and editable LaTeX report describe complete fixed-source Diophantine certificates for first exact cleaned three-mass target time. Four native/spatial circuits cost 604, 479, 477 and 480 operations, with 60, 58, 58 and 58 strictly positive integer witnesses and exact degrees 2344, 1192, 1192 and 1192. The original phase-four schedules add one multiplication. Separately audited five-gate affine folding gives 603, 478, 476 and 479 operations in both native and phase-four models, with the same witness counts and degrees; these alternatives are under folded-clocks/. Every accepted nonempty fiber has infinitely many positive witnesses. Initial halt has separate four-gate, witness-free quadratic circuits.

Read report21.pdf first. The reproducibility directory is an unchanged 45-file mathematical freeze: 44 payload files plus its manifest. The source directory contains pinned mathematical text and arithmetic DAG data; upstream Python is inert provenance and is never executed by the new replay.

## Replay

Use Python 3 with its standard library, without a checkout or network:

    python -B verify_release.py
    python -B replay.py --output /tmp/new-report21-replay

The output directory must be new and outside this release. The runner authenticates the full release, copies the packet to fresh normal and optimized work areas, replays own emitters and independent checkers, checks deterministic bytes, and rejects integrity attacks. The secondary assertion-based degree checker must reject -O; this rejection is tested. The full independent circuit auditor rechecks every degree certificate in both modes. No check silently disappears under optimization.

Use sh build.sh to rebuild the PDF with TeX. It creates intermediate files outside the release; intentionally replacing the PDF changes the sealed inventory until write_manifest.py is run. Re-sealing is a deliberate local edit, not authentication of a new publication.

## Important limits

These are generic unbounded-runtime mechanisms instantiated on four nonuniversal one- or two-step sources. They do not establish an ordinary-input universal loader, a universal numerical operation bound, minimality, exact rational/real zero sets or later target recurrence. Whole positive native/Pell witness tuples have not been materialized; finite full-DAG signed/modular evaluations and positive outer histories are distinct evidence. The report identifies inherited theorem dependencies explicitly.

The release verifier rejects extra/missing files and directories, symlinks, duplicate manifest keys and changed pinned dependencies. SHA-256 manifests are consistency checks, not digital signatures. Obtain the final archive digest separately when authenticity matters. Prior reports and repository sources are unchanged.
