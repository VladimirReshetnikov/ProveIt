"""Seal the finalized release; rerun only after an intentional release edit.

The manifest establishes consistency, not authenticity. Obtain the archive hash
through a trusted channel. No generated/build directories are silently ignored.
"""
import sys
sys.dont_write_bytecode = True
from hashlib import sha256
import json
from pathlib import Path
from verify_release import ROOT, MANIFEST, DIGEST, inventory, check_pins, verify, require


def write(root=ROOT):
    root = Path(root).absolute()
    files, directories = inventory(root)
    for name in ('report21.tex', 'report21.pdf', 'README.md', 'replay.py',
                 'release_checks.py', 'reproducibility/THEOREM.md', 'reproducibility/source/provenance.json'):
        require(name in files, 'finalization prerequisite missing: ' + name)
    check_pins(root)
    entries = {}
    for name, path in sorted(files.items()):
        if name not in (MANIFEST, DIGEST):
            raw = path.read_bytes()
            entries[name] = dict(bytes=len(raw), sha256=sha256(raw).hexdigest())
    wanted_dirs = {p.as_posix() for name in entries for p in Path(name).parents if p != Path('.')}
    require(directories == wanted_dirs, 'empty or unexpected directory must be removed before sealing')
    raw = (json.dumps(dict(schema='report21-exact-inventory-v1', files=entries), indent=2) + '\n').encode()
    (root / MANIFEST).write_bytes(raw)
    (root / DIGEST).write_text(sha256(raw).hexdigest() + '  ' + MANIFEST + '\n')
    return verify(root)


if __name__ == '__main__':
    print(json.dumps(write(), indent=2))
