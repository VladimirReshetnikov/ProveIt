"""Replay the sealed packet in fresh copies with normal and optimized Python.

Usage: python -B replay.py --output /tmp/new-report21-replay
The chosen output must be new and outside the release. Standard library only.
"""
import sys
sys.dont_write_bytecode = True
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
from verify_release import ROOT, verify, require, inventory

BASE_COMMANDS = (
    ('verify_manifest.py',),
    ('emit_clean_clocks.py', '--check'),
    ('check_semantics.py', '--check'),
    ('audit/check_emitted_circuits.py', '--expect', 'audit/independent_emitted_circuit_audit.json'),
    ('audit/check_degree_certificate.py',),
    ('verify_manifest.py',),
)
BOOTSTRAP = r'''
import sys, runpy
from pathlib import Path
sys.dont_write_bytecode = True
try:
    import resource
except ImportError:
    resource = None
if resource is not None:
    resource.setrlimit(resource.RLIMIT_CPU, (240, 240))
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE, (64 * 1024**2, 64 * 1024**2))
script = Path(sys.argv[1]).resolve()
sys.argv = [str(script)] + sys.argv[2:]
sys.path.insert(0, str(script.parent))
runpy.run_path(str(script), run_name='__main__')
'''


def prepare_output(output, root=ROOT):
    root = Path(root).resolve()
    if output is None:
        parent = Path(tempfile.gettempdir()).resolve()
        require(parent != root and root not in parent.parents, 'temporary directory is inside release')
        return Path(tempfile.mkdtemp(prefix='report21-replay-'))
    path = Path(output).expanduser().absolute()
    for ancestor in (path,) + tuple(path.parents):
        require(not ancestor.is_symlink(), 'symlink output path rejected')
    actual = path.resolve()
    require(actual != root and root not in actual.parents, 'replay output must be outside the release')
    require(not path.exists(), 'replay output already exists; choose a new directory')
    require(path.parent.is_dir(), 'output parent must already exist')
    path.mkdir()
    return path


def run_command(directory, arguments, optimized, log, expected_rejection=False):
    script = directory / arguments[0]
    command = [sys.executable, '-I', '-S', '-B'] + (['-O'] if optimized else [])
    command += ['-c', BOOTSTRAP, str(script)] + list(arguments[1:])
    env = {k:v for k,v in os.environ.items() if not k.startswith('PYTHON')}
    started = time.monotonic()
    with Path(log).open('wb') as stream:
        done = subprocess.run(command, cwd=directory, env=env, stdout=stream,
                              stderr=subprocess.STDOUT, timeout=300)
    if expected_rejection:
        require(done.returncode != 0 and 'requires assertions enabled' in Path(log).read_text(),
                'assertion-dependent checker did not fail closed under -O')
    else:
        require(done.returncode == 0, 'replay failed: ' + arguments[0] + '; see ' + str(log))
    return dict(command=list(arguments), optimized=optimized,
                expected_fail_closed=expected_rejection, returncode=done.returncode,
                seconds=round(time.monotonic()-started,3))


def bytes_inventory(directory):
    files, dirs = inventory(directory)
    return {n:sha256(p.read_bytes()).hexdigest() for n,p in files.items()}, dirs


def replay(output=None, root=ROOT):
    root = Path(root).absolute()
    integrity = verify(root)
    output = prepare_output(output, root)
    original = root/'reproducibility'
    baseline = bytes_inventory(original)
    all_runs = []
    for optimized in (False, True):
        mode = 'optimized' if optimized else 'normal'
        copied = output/mode
        shutil.copytree(original, copied)
        logs = output/(mode+'-logs'); logs.mkdir()
        for i,args in enumerate(BASE_COMMANDS):
            rejected = optimized and args[0] == 'audit/check_degree_certificate.py'
            all_runs.append(run_command(copied,args,optimized,logs/(str(i).zfill(2)+'.log'),rejected))
            require(bytes_inventory(copied)==baseline, 'replay changed deterministic base packet bytes')
        if (root/'folded-clocks').is_dir():
            extra = output/(mode+'-folded-clocks')
            shutil.copytree(root/'folded-clocks',extra)
            # The standalone addendum discovers its own pinned native inputs.
            for i,args in enumerate(ADDENDUM_COMMANDS):
                all_runs.append(run_command(extra,args,optimized,logs/('addendum-'+str(i)+'.log')))
            require(bytes_inventory(extra)==bytes_inventory(root/'folded-clocks'), 'folded addendum changed bytes')
    for optimized in (False,True):
        mode='optimized' if optimized else 'normal'
        all_runs.append(run_command(root,('release_checks.py',),optimized,output/(mode+'-release-checks.log')))
    verify(root)
    result=dict(status='passed',python=sys.version.split()[0],source_release_unchanged=True,
                deterministic_bytes_unchanged=True,modes=['normal','optimized'],scripts=all_runs,
                integrity=integrity,secondary_degree_optimized='expected fail-closed rejection',
                full_independent_degree_audit='passes normal and optimized',third_party_python_executed=False,
                limits=dict(wall_seconds=300,unix_cpu_seconds=240,unix_address_space_bytes=2*1024**3))
    (output/'replay-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

ADDENDUM_COMMANDS = (('verify_manifest.py',), ('emit_folded_clocks.py','--check'), ('audit/check_folded_clocks.py','--expect','audit/independent_folded_clock_audit.json'), ('verify_manifest.py',))
if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output')
    args=parser.parse_args()
    print(json.dumps(replay(args.output),indent=2))
