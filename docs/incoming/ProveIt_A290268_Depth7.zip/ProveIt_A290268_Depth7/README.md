# Depth Seven Is Complete for OEIS A290268

This package contains an AI-assisted, unrefereed computer-assisted proof of the
depth-seven support theorem for OEIS A290268, the number of terms in the fully
expanded `N`-th derivative of `x^(x^2)`.

## Main theorem

For

```text
phi(w) = (1+w)^2 log(1+w),
gamma(k,d,M) = [w^M] (2+w)^k phi(w)^d,
```

the article proves, for every `k >= 0` and `M >= 7`,

```text
gamma(k,7,M) = 0  <=>  M = k + 29 and k is odd.
```

For `M < 7`, vanishing is structural because `phi(w)^7` has order seven.
Thus the only nonstructural zeros at depth seven are the known
reflection-symmetry holes; there are no sporadic depth-seven cancellations.

In derivative coordinates the holes are

```text
j = -15,  N = 2k + 29,  k odd.
```

The exact depth-seven contribution has generating function

```text
x^7/(1-x)^2 - x^31/(1-x^4).
```

The full A290268 conjecture is not claimed: depths `d >= 8` remain outside the
classification proved here.

## Proof structure

The analytic part reduces all nonhole cells with `k >= 4897` or `q >= 9825`
to a first-moment inequality. The remaining rectangle is

```text
0 <= k <= 4896,
0 <= q <= 9824,
```

with 48,113,025 cells. The finite checker finds exactly 2,448 symmetry holes
(`q = 14`, `k` odd) and proves every other cell nonzero modulo 1,000,000,007.
It then replays every cell with an independent centered-jet recurrence.

## Files

- `article.tex` - complete LaTeX source.
- `article.pdf` - compiled 17-page article.
- `verify_depth7_seeds.py` - exact rational verifier for the Machin bounds,
  largest-root threshold, and moment cutoffs.
- `depth7_seed_certificate.json` - recorded seed-verifier output.
- `verify_depth7_rectangle.cpp` - exact C++17 modular rectangle checker and
  independent recurrence replay.
- `depth7_rectangle_certificate.json` - recorded rectangle-checker output.
- `SHA256SUMS.txt` - SHA-256 hashes of package files other than itself.

## Reproduction

Run from this directory:

```bash
python3 verify_depth7_seeds.py

g++ -O3 -std=c++17 -Wall -Wextra -pedantic \
  verify_depth7_rectangle.cpp -o verify_depth7_rectangle
./verify_depth7_rectangle > depth7_rectangle_certificate.rerun.json
cmp depth7_rectangle_certificate.json depth7_rectangle_certificate.rerun.json

python /home/oai/skills/pdfs/scripts/latex_to_pdf.py \
  article.tex -o article.rerun.pdf
```

The delivered rectangle output was independently reproduced with both GCC and
Clang. On the packaging run, GCC took about 1.21 seconds and Clang about 1.36
seconds; both used about 190 MB peak resident memory and produced byte-identical
JSON output. Runtime is not proof-relevant.

## Exact certificate summary

```text
Depth:                         7
Center cutoff R:               4898
Tail cutoff Q:                 9825
Finite cells:                  48,113,025
Symmetry holes:                2,448
Unresolved nonholes:           0
Largest derivative order:      19,631
Independent jet cells checked: 48,113,025
First-prime nonholes:           48,110,577
Transcript fingerprint:        0xd571d65231d87a70
Status:                        PASS
```

The transcript fingerprint is diagnostic only. The proof-relevant facts are
the exact recurrence identities, exhaustive finite traversal, and nonzero
modular residues.

## Provenance and status

The source analysis was pinned to ProveIt commit
`d3c317c09898410c046a4c4f74f12e903d40f287` on 1 October 2026. At that pin,
the repository report classified depths 1 through 6 and identified depth 7 as
the first unresolved stratum.

This work is not peer reviewed and is not formalized in Lean. The programs use
exact integer/rational arithmetic for every theorem decision; decimals in the
article are explanatory only. Independent mathematical and source-code review
is recommended before publication or OEIS adoption.
