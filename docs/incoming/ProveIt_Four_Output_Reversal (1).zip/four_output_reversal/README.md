# Exact Binary Reversal with Four Outputs

**An all-state formula, quantitative rigidity, and missing-orbit structure**  
Research manuscript prepared for Vladimir Reshetnikov, 29 September 2026.

## Main result

For every n >= 7, let (A,B) be the closest coprime split of n, A < B:

- n = 2h+1: (A,B) = (h,h+1).
- n = 2h with h even: (A,B) = (h-1,h+1).
- n = 2h with h odd: (A,B) = (h-2,h+2).

The manuscript gives a proposed complete proof that the largest reversal
state complexity of a minimal n-state binary DFAO with four output values is

    R_2(n,4) = 4^n - 6*2^n - 4*(3^A+3^B)
                     + 12*(2^A+2^B) - 12 + A*B.

The remaining admissible values are R_2(4,4)=176, R_2(5,4)=826,
and R_2(6,4)=3526. The upper bound applies to arbitrary transformation pairs
and arbitrary four-valued output maps, whether or not the original machine
is accessible or minimal. Minimal equality witnesses are supplied.

Additional results include necessary extremizer conditions, an AB/2
near-extremizer threshold, a 24AB penalty for a second cross-cycle collision
under the specified hypotheses, an exact missing-orbit inventory, an exact
count of extremal outputs on the standard transition pair, and a minimal
order-15 recurrence for the missing-state count.

## Files

- `article.pdf`: compiled 21-page article.
- `article.tex`: complete standalone LaTeX source; bibliography is included.
- `code/verify.py`: exact finite certificate producer and supplementary tests.
- `code/independent_check.py`: independent arithmetic and orbit checker;
  imports no code from the producer.
- `data/finite_certificate.json`: all 2,082 structural entries for n=4..25.
- `data/finite_summary.csv`: minima, runner-up values, and structural gaps.
- `data/bfs_witnesses.json`: explicit transition and output arrays, orbit sizes,
  accessibility/minimality results, and two complete missing-orbit inventories.
- `data/orbit_inventories.json`: exact period inventories for n=7..100.
- `data/recurrence.json`: denominator, numerator, and initial deficit values.
- `data/verification_summary.json`, `data/independent_check.json`: recorded checks.
- `notes/SOURCE_AUDIT.md`: source identities, repository baseline, and attribution.
- `notes/PROOF_AUDIT.md`: proof dependencies, scope, and boundary checks.
- `notes/PDF_AUDIT.json`: rendering and layout audit of the delivered PDF.
- `Makefile`: build and verification commands.

## Reproduce the checks

Use Python 3.10 or later. No third-party Python packages are needed.
From this directory, run:

```sh
python3 code/verify.py
python3 code/independent_check.py
```

The producer regenerates the data files and exits nonzero on failure.
The independent checker reads the finite certificate but re-enumerates all
cases and re-evaluates their values. Both programs ran successfully for this
delivery. They can also be invoked by absolute path from another directory.

The finite upper-bound proof has 2,082 entries over n=4..25, not 2,082
sampled automata. The remaining infinite range is handled analytically in
Section 4. The small lower witnesses are checked by complete orbit closure.
Producer BFS runs through n=9; the independent integer BFS runs through n=8.

## Rebuild the PDF

A standard TeX Live installation with pdfLaTeX and latexmk is sufficient:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run pdfLaTeX three times. No external images, font files,
BibTeX database, network access, or shell escape are required.

```sh
make pdf
make check
```

## Status and novelty boundary

This is an AI-assisted, unrefereed research manuscript, not a Lean or Rocq
formalization. Publication priority is unverified. It proposes the full
four-output slice of Davies's exact binary reversal problem; it does not
claim the general variable-output conjecture or the largest two-generated
transformation-monoid problem.

The ProveIt baseline already contains the collision-graph framework, the
exact all-state three-output result, finite comparisons including four
outputs, and a separate eventual fixed-output analysis. Those results,
methods, the published lower witness, and previously recorded small values
are credited rather than presented as new. The all-state four-output upper
bound, explicit threshold plus finite completion, and specialized quantitative
and orbit consequences are the focus of this package.

The universal lower bound imports Holzer–König's two-generation theorem in
the form stated by Davies. Its original proof was not reconstructed. The
upper bound and the coloring-saturation step are proved in the manuscript.
The finite certificate has an ordinary Python execution trust boundary;
two implementations provide an implementation-level cross-check, not a
proof-assistant kernel check or independent expert review.
