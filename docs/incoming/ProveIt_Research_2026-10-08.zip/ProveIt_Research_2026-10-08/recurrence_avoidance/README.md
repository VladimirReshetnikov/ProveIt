# Large Closed Sets Avoiding All Convergent Linear Recurrences

Complete research manuscript with an extension to rational observations and effective finite certificates. Prepared for the ProveIt project on 8 October 2026.

## Main result

For every `0 < epsilon < 1`, one closed, symmetric, 1-periodic subset of the real line has measure at least `1 - epsilon/2` in every unit interval and excludes infinitely many terms of every nonzero affine image of every convergent, non-eventually-constant real constant-coefficient finite-order linear recurrence sequence. The set is chosen before the recurrence, its order, coefficients, initial conditions, translation, and dilation.

The same set covers every non-eventually-constant rational observation of finitely many convergent recurrence sequences when its denominator is nonzero at the limiting vector. Negative and complex roots, repeated roots, exact zero terms, and spectral collisions are allowed. For rational epsilon, a compact section can be effectively closed with computable measure.

## Files and build

- `main.tex`, `sections/*.tex`, `references.tex`: complete source.
- `../common/preamble.tex`: shared LaTeX preamble; preserve this relative path.
- `recurrence_avoidance.pdf`: compiled manuscript.
- `verification/verify_recurrence.py`: exact checks, using only Python's standard library.
- `verification/results.json`: recorded exact outputs and witnesses.
- `verification/PROOF_AUDIT.md`: internal mathematical audit, including limits of the verification.
- `figures/generate_figures.py`: reproducible figure generation; requires Matplotlib.
- `figures/*.pdf`, `figures/*.png`: generated illustrations. The vector PDF figures are included directly by LaTeX.

From the package root:

```sh
make recurrence
make verify-recurrence
make figures
```

Or, from this directory:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error -jobname=recurrence_avoidance main.tex
python3 verification/verify_recurrence.py
python3 figures/generate_figures.py
```

Figure generation is optional when compiling because the generated PDF figures are included. Python comparisons in the verifier use `fractions.Fraction`; plots use floating point only for display.

## Proof dependencies and scope

The manuscript re-proves the required routing and measure arguments from the supplied OpenAI geometric-case manuscript and the earlier ProveIt uniform-avoidance manuscript. It adds sampling by a contracting quadratic norm of consecutive state blocks, exact polynomial-sign encoding of the selected original terms, and a second recurrence for a regular denominator. The sign-condition bound of Basu, Pollack, and Roy and decidability of real closed fields are explicitly cited external inputs.

The verified examples check algebra and indexing; they are not a proof over the continuum of parameter values. The finite-blocker algorithm is proved to terminate by real quantifier elimination, but neither that search nor the full random routing tree is implemented in this package. No proof-assistant formalization or external peer review is claimed. Source-relative novelty is distinguished from established priority in the manuscript and top-level source audit.

The theorem excludes eventually constant sequences and does not cover unrestricted relative perturbations, arbitrary nonlinear dynamics, or rational observations with a vanishing limiting denominator. A proved density-point obstruction explains why all perturbations `q^n + o(q^n)` cannot be included, even for one fixed `q`.

## Further research

Section 9 gives ten questions with proposed starting points: practical finite blockers, efficient routing, intrinsic parameter dimension, degeneration near zero or the unit circle, vanishing limiting denominators, restricted analytic observations, general address-complexity criteria, controlled errors, effective perfect subsets, and formal verification.
