# Recurrence avoidance and optimal simplex products

Research package prepared for the ProveIt project, 8 October 2026.

This archive contains two independent mathematical manuscripts, their complete
LaTeX sources, compiled PDFs, exact verification programs, recorded results,
and source-audit information. The papers do not depend on each other's results.
The outer archive is a delivery bundle containing two manuscripts; for the
repository's one-manuscript-per-intake-archive convention, treat the two
manuscript directories as separate sources and retain their shared preamble.

| Manuscript | PDF | Source |
|---|---|---|
| **Large Closed Sets Avoiding All Convergent Linear Recurrences** | [recurrence_avoidance.pdf](recurrence_avoidance/recurrence_avoidance.pdf) | [main.tex](recurrence_avoidance/main.tex), with `sections/` and `references.tex` |
| **Optimal simplex products for projection-body volume** | [optimal_simplex_products.pdf](simplex_products/optimal_simplex_products.pdf) | [main.tex](simplex_products/main.tex) and [body.tex](simplex_products/body.tex) |

Both manuscripts use [common/preamble.tex](common/preamble.tex). Keep this
directory beside the two manuscript directories when rebuilding the package.
The delivered [BUILD_INFO.json](BUILD_INFO.json) records the compilation
environment and PDF inspection. `SHA256SUMS.txt` lists the delivery hashes;
from the extracted package root, check it with `sha256sum -c SHA256SUMS.txt`.
Follow the repository's intake convention for dropping delivery checksum
manifests after verification.

## 1. Main result: one large closed set for all convergent recurrences

For every real `0 < epsilon < 1`, the main paper constructs a closed, symmetric,
one-periodic set `F_epsilon` whose measure in every unit interval is at least
`1 - epsilon/2`, hence greater than `1 - epsilon`. This **one set works
simultaneously** for every convergent, non-eventually-constant real C-finite
sequence: every translation and nonzero dilation of such a sequence has
infinitely many terms outside `F_epsilon`.

Here C-finite means that a homogeneous linear recurrence with constant real
coefficients holds, possibly only from some index onward. The order, real
coefficients, and initial data are unrestricted. Negative and nonreal roots,
repeated roots, spectral collisions, and infinitely many zero terms are
allowed. The eventual-constancy exclusion and the nonzero-dilation condition
are necessary.

The same set also handles every non-eventually-constant **rational observation
of finitely many convergent C-finite sequences**, when the rational function's
denominator does not vanish at the limiting vector. Its basic quotient theorem
applies to `a_n/b_n` when `a_n -> 0` is not eventually zero and
`b_n -> b_infinity != 0`, with both numerator and denominator C-finite.

Examples include damped rotations, polynomial factors from repeated roots,
observations of stable matrix orbits, and `q^n/(1+q^n)` for `0 < q < 1`.
The new sampling argument controls a quadratic norm of a consecutive-state
block, then chooses an actual scalar term from that block. It therefore does
not require scalar terms to be positive or their consecutive ratios to exist.

### Effective construction: theorem versus implementation

For rational `epsilon`, the proof gives an effectively closed compact section
`F_epsilon intersect [0,1]` with computable measure. A proved terminating search
enumerates finite rational open-arc blockers and checks their uniform hitting
property, including a positive hitting margin, by real quantifier elimination.

**That full quantifier-elimination search and the ordered random routing
construction are not implemented in this package.** The executable verifier
checks finite-dimensional algebra, sampling, indexing, and boundary cases in
three explicit examples. It is not a program that outputs the universal set.
The proof supplies no practical complexity bound for producing its blockers.

The theorem does not cover every quotient with a vanishing limiting
denominator, arbitrary variable-coefficient recurrences, arbitrary analytic
observations, or all infinite subsets of the line. The paper also proves an
elementary limitation: allowing every perturbation `q^n + o(q^n)` is already
too broad for one positive-measure set to avoid all affine copies. This is not
a claimed solution of the full Erdős similarity conjecture.

## 2. Companion result: exact optimization of simplex products

For a convex body `K` in dimension `n`, let

`R_n(K) = volume(Pi K) / volume(K)^(n-1)`.

The companion determines its maximum over affine images of Cartesian products
of simplices. With `s_d = (d+1)d^d/d!`, the problem becomes maximizing
`product(s_(d_i))` over all positive factor dimensions summing to `n`.

The paper proves the following exact results.

- **Dimension 13 is the unique optimal exponential block size:**
  `sup_d s_d^(1/d) = s_13^(1/13)`, approximately `2.80996473256`.
- **Every dimension requires only two candidates.** Their factor counts are
  `max(1, floor(n/13))` and `ceil(n/13)`; each candidate has balanced factor
  dimensions.
- **From dimension 100 onward, the optimum has an exact rule modulo 13.**
  If `r = n mod 13` is at most 8, use `r` factors of dimension 14 and fill the
  remaining dimension with factors of dimension 13. If `r` is at least 9, use
  `13-r` factors of dimension 12 and fill the rest with dimension 13.
- **In every dimension at least 100, the maximizing dimension multiset is
  unique**, and every other multiset loses at least the sharp multiplicative factor
  `G = s_14^8/(s_13^4 s_12^5)`, approximately `1.00103981380358`.
- The optimum satisfies the exact recurrence `P_(n+13) = s_13 P_n` for
  `n >= 100`, has a fully determined periodic asymptotic expansion relative
  to a simplex, and admits exact optimization at prescribed factor or facet
  count. The threshold 100 and the uniform gap are both sharp.

The geometric identities are re-proved, with attribution to the inspected
source. The new contribution is the optimization of the product class. The
paper does not determine the maximum over arbitrary convex bodies. Arbitrary
simplex shapes in the same dimensions are affinely equivalent, so its
uniqueness and gap statements refer to dimension multisets or their affine
product classes.

## 3. Rebuild the PDFs

Requirements are a modern TeX installation with pdfLaTeX and the packages in
`common/preamble.tex`, plus GNU Make and a POSIX shell for the supplied Makefile.
The package was built with pdfTeX from TeX Live 2023. The included figures mean
that no Python plotting packages are required merely to rebuild the PDFs.

From this package directory:

```sh
make pdfs
```

Each article is compiled three times to stabilize references and the table of
contents. The output paths are the PDF paths listed above. To force rebuilding
existing PDFs, use `make -B pdfs`. The default `make` target also builds both
PDFs. Bibliographies are included in the LaTeX sources; BibTeX is not required.
Use `make recurrence` or `make simplex` to build only one article.

The equivalent per-paper command, run in its manuscript directory, is:

```sh
pdflatex -interaction=nonstopmode -halt-on-error -jobname=recurrence_avoidance main.tex
```

or, for the companion:

```sh
pdflatex -interaction=nonstopmode -halt-on-error -jobname=optimal_simplex_products main.tex
```

Repeat the relevant command until cross-references stabilize. On Windows, the
Makefile can be used in WSL or another compatible POSIX environment; the
per-paper commands also work from an appropriately configured terminal.
PDF byte hashes can change with TeX versions and build metadata even when the
mathematical content and layout agree.

`make clean` removes only generated TeX auxiliary files for these two job
names. It preserves the PDFs, sources, figures, recorded evidence, and any
delivery checksum manifest.

## 4. Reproduce the exact checks

Python 3.10 or newer is sufficient; the verification programs use only the
standard library. The recorded environment used Python 3.12.14. All
mathematical comparisons in the verifiers use exact rational arithmetic.

```sh
make verify
```

The Makefile copies the verification programs into `build/verification/`, runs
those copies, and compares the new evidence with the delivered records. It
does not overwrite the delivered evidence. Override the interpreter or the
reproduction directory if needed:

```sh
make verify PYTHON=python VERIFY_DIR=/tmp/proveit_research_checks
```

| Check | Recorded scope | Evidence |
|---|---|---|
| Recurrence sampling and rational normalization | Three explicit examples, 3,380 exact assertions, including 16 threshold-equality witnesses | `recurrence_avoidance/verification/results.json` |
| Simplex-product arithmetic and optimization | Seven strict rational enclosures, eight initial comparisons, prime-power identities, and an exact dynamic program through dimension 300 | `simplex_products/verification/results/` |
| Independently implemented simplex optimum and runner-up calculation | Exact best and runner-up values and all maximizing multisets through dimension 260 | `simplex_products/verification/results/independent_audit_report.json` |

The assertion count describes the finite run; it is not evidence for an
uncountable-parameter theorem by extrapolation. The recurrence proof rests on
the sign-condition bound, the finite conditional-probability argument,
compactness, and the summable construction. The simplex proofs establish the
classification in every dimension by concavity and deficit bounds, with
finite exact inequalities for the constants. The dynamic programs check the
formulas and implementations independently on their stated ranges.

The three verification targets can also be run separately:

```sh
make verify-recurrence
make verify-simplex
make verify-independent
```

### Optional figure regeneration

The recurrence paper includes the source for its two scientific figures:

```sh
make figures
```

This runs `python3 recurrence_avoidance/figures/generate_figures.py` by default;
the `PYTHON` Make variable selects a different interpreter.

This optional step requires NumPy and Matplotlib; the recorded environment
used NumPy 2.3.5 and Matplotlib 3.10.8. It rewrites the two figure pairs in
`recurrence_avoidance/figures/`, so run it on a working copy when preserving
delivered hashes. The displayed values come from the exact verifier; only
rendering uses floating-point values.

## 5. Provenance, claim status, and proposed ProveIt integration

[SOURCE_AUDIT.md](SOURCE_AUDIT.md) records the pinned repository snapshots,
the inherited ingredients, the present extensions, and the limits of the
literature and proof reviews. The source comparison uses:

- `openai/math` at `adc7f1241b42e322a6451854ab7e4b4c146bf78a`;
- `VladimirReshetnikov/ProveIt` at `58175ca45563d9ee29875374dd77942f069268a9`.

The older ProveIt revision recorded inside the predecessor's own audit belongs
to that predecessor's provenance; it is not the snapshot for this delivery.
The manuscripts distinguish results inherited from those sources from the
new extensions proved here. Priority is assessed against inspected sources
and targeted literature searches, not certified globally. The package does
not claim external peer review or Lean/Rocq formal verification.

For intake, treat the two manuscripts as distinct reports:

| Paper | Proposed placement or continuation |
|---|---|
| Recurrence avoidance | Continue `Analysis/ErdosSimilarity/Research/uniform-geometric-avoidance/`, following the repository's procedure for a new source that extends an existing report. A separate `uniform-recurrence-avoidance` report beside it is another possible maintainer choice. |
| Simplex products | A new convex-geometry report in the research-report collection; a proposed destination is `SetTheory/Cardinals/docs/reports/convex-geometry/optimal-simplex-products/`. The category and final path should be checked against the current catalogue at intake. |

Keep the delivered structure intact during review. If the papers are placed
separately, preserve the shared preamble dependency or adjust their input paths
as part of integration. The verification programs, their recorded outputs,
and the source audit belong with their respective report. Follow the
repository's current rules for delivery checksums and cataloguing.

These paths are integration proposals. This delivery does not represent a
repository push, merge, or modification of the existing ProveIt reports.
