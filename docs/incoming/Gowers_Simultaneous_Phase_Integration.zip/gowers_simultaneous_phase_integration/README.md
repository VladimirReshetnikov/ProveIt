# Simultaneous Phase Integration in Gowers's Framework

**Alternating pencils, optimal finite-test budgets, exact rank profiles, and sharp defect stability**  
Research manuscript prepared with ChatGPT for Vladimir Reshetnikov and the ProveIt project.  
Date: 7 October 2026.

## Main result

For symmetric Boolean cubics T0, T1 and T+ = T0 + T1, suppose their selected
second-derivative Fourier energies are at least 2^(-K0), 2^(-K1), 2^(-K+).
They integrate on a common subspace of codimension at most

    min(K0+K1, K0+K+, K1+K+, floor((K0+K1+K+)/2)).

Every nonnegative integer budget triple has an extremizer, including with one
common test function. For equal budgets K this gives the optimal floor(3K/2),
rather than the two-test bound 2K. In dimension n, additionally cap the bound
by floor(n/2).

The paper also establishes the complete finite-direction rank-budget frontier,
realizes every feasible exact rank profile, and proves a sharp restriction
stability theorem in terms of an integral rank defect. It gives a rank-based
extension to the first nonclassical obstruction degree p+1 over F_p.

The relation to Gowers is the phase-removal step in Section 17. The finite-field
results are not claimed as a literal replacement for the cyclic-group theorem
or as an improved global Szemeredi bound.

## Files

- `article.tex`: standalone source; bibliography included, labels prefixed `spi:`.
- `article.pdf`: compiled article with proofs, references, and ten further questions.
- `checks/verify.py`: exact, standard-library-only finite verification program.
- `checks/results.json`: successful output from the delivered run.
- `FORMALIZATION.md`: proposed Lean interfaces and certificate boundaries.
- `SOURCE_AUDIT.md`: inspected sources, checkpoint, and attribution boundaries.
- `Makefile`: build and verification commands.

## Reproduce

From this folder:

```sh
python3 checks/verify.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Python 3.10 or later is sufficient. No network, numerical libraries, random
seed, external data, or numerical tolerances are needed. The mathematical
checks use exact integers, F_2[z], Z/8Z, Gaussian integers, and prime-field
arithmetic. The `elapsed_seconds` field is informational and not deterministic.
Do not run with `python -O`, which disables assertions.

The PDF uses standard TeX Live packages: amsmath, amssymb, amsthm, mathtools,
lmodern, microtype, geometry, booktabs, enumitem, hyperref, cleveref, fancyhdr.

## Verification scope

The run covers all 4096 pairs of alternating forms on F_2^4, all 67 subspaces,
4096 exact common-isotropic codimension equalities, and 4096 defect-stability
checks. It also checks 2225 unequal finite-test budget vectors, 343 independent
three-colour optimization cases, 39 exact-profile constructions, every
hyperplane in the irreducible sharpness example, 524288 pointwise cubic
primitive identities, 82944 fourth-derivative checks, 384 exact cubic energy
bounds at Gaussian-rational inputs, and full-direction extremizers over
F_2, F_3, F_5, F_7.

The prime-field extremizer checks evaluate all rational directions of
explicit block pencils. Their generic ranks are certified by their nonzero
block products. The Boolean census and exact-profile checks independently
compute generic ranks via polynomial Pfaffians.

These are finite validation checks, not proof-assistant formalizations.

## Attribution and limitations

The alternating-pencil classification is classical. The common-isotropic
formula follows from that classification. Nonclassical integration is credited
to the published work discussed in the paper. The exact single-Boolean-cubic
energy theorem and primitive are credited to the previous project manuscript
`boolean_phase_integration.tex` and reproved here. The current contribution
is their simultaneous refinement, its sharp parameter frontier, and the
rank-profile/defect analysis.

No result in this package has been checked in Lean. Publication priority for
the new formulations has not been exhaustively established. The article does
not claim simultaneous retention of full-group energy on a common coset,
function-level stability, an odd-prime exact scalar energy law, or a new
global Szemeredi bound.

## Repository integration

Suggested standalone destination:

    Combinatorics/Ramsey/Research/GowersSzemeredi/simultaneous-phase-integration/

The audited formal interface is pinned at
`c9a9f2662ac9929f6cfb836957452256ef7e601c`.
This package does not update the repository or its formalization-status ledger.
Assign any aggregate source number at integration time; none is reserved here.
When incorporating the body into a larger TeX aggregate, retain the `spi:`
label prefix and reconcile preamble macros/theorem environments separately.
