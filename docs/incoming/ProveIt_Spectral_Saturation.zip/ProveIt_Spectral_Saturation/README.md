# When Exact Prefixes Stop Improving
## Spectral saturation, sharp square-root laws, and a certified barrier for convolution majorants

Research report prepared for Vladimir Reshetnikov, September 28, 2026.

Start with **article.pdf**. The complete LaTeX source is **article.tex**, with two
small generated table inputs in `data/`. This package continues the ProveIt
report *Finite-Prefix Corrections and Dual Certificates for Polyomino Growth*.

## Main results

For a proper nonnegative polynomial system A <= Phi(z,A), set
D = Phi(z,A)-A and correct its equality recurrence by the exact defect through
size N.

* At a convergent evaluation where the true-profile Jacobian is irreducible
  and its spectral radius is at least one, a finite-prefix certificate exists
  exactly when the omitted defect vanishes. This includes the critical case
  left unclassified in the source report.
* For an infinite defect, the corrected radii tend to the first Perron crossing,
  or to the true radius when no earlier crossing occurs.
* At an interior nonlinear crossing, the radius gap is asymptotic to an explicit
  constant times the square root of the Perron-weighted omitted defect. The
  report also proves a universal scaled branch and a quarter-power singular
  amplitude law. No regular variation or nonlacunarity assumption is needed.
* For the fixed 17-variable polyomino map, the supplied size-18 profile and a
  new integer vector give an exact all-prefix growth wall of 4.3149.

**The 4.3149 result is a lower bound for the corrected majorants, not for true
polyomino growth.** It is not a new upper bound on Klarner's constant. It does
not resolve the distinct neighborhood-refinement question.

## Status and trust boundary

The article contains written mathematical proofs. It is an AI-assisted,
unrefereed research draft, not a Lean-verified development. Novelty is assessed
only against the inspected repository continuation and the stated primary
sources, not an exhaustive literature search.

The exact arithmetic checker was run successfully. It proves its finite
rational inequalities and consistency checks; it does not prove the analytic
theorems. The size-18 marked counts are inherited from the repository and were
not independently re-enumerated for this package. See `PROOF_STATUS.md` and
`SOURCES.md` for the precise boundaries.

## Replay

From the extracted package directory, with Python 3.10 or later:

```sh
python3 code/verify.py
```

This uses the standard library only. It checks all 17 rational spectral
inequalities, an independently implemented directional derivative, strong
connectivity, nilpotence of the constant linear part, 95 partition equalities,
323 nonnegative prefix-defect entries, six exact scalar root brackets, and
18 rational evaluations of a scalar polynomial identity.

To rewrite the verification outputs and regenerate the two table files:

```sh
python3 code/verify.py --write
```

`data/verification.json` retains the exact rational scalar brackets. Decimal
values are displays, not the root certificates. Every failed required check
raises an exception; the verifier does not rely on removable Python assertions.

The optional `code/discover.py` requires NumPy and searches for an integer
witness by rounding a numerical Perron vector. It is outside the proof boundary;
the final verifier ignores the numerical discovery fields.

## Build the PDF

A conventional TeX Live installation with pdfLaTeX and the packages named in the
preamble is sufficient:

```sh
sh build.sh
```

The build uses three pdfLaTeX passes to resolve the contents and theorem
references. No network access or shell escape is needed. The two included TeX
tables must remain in `data/` relative to `article.tex`.

## Contents

- `article.tex`, `article.pdf`: complete report.
- `code/bui_model.py`: exact map representation, profile reader, and Jacobian.
- `code/verify.py`: exact replay and scalar bracket generator.
- `code/discover.py`: optional numerical discovery, not verification.
- `data/profiles_18.csv`: inherited marked and unmarked counts.
- `data/bui_spectral_certificate.json`: new positive integer witness.
- `data/verification.json`, `data/verification.txt`: recorded replay outputs.
- `data/scalar_table.tex`, `data/witness_table.tex`: generated article tables.
- `SOURCES.md`: versioned provenance and literature review boundaries.
- `PROOF_STATUS.md`: claim-by-claim status and limitations.
- `build.sh`: PDF build command.

Ten further research projects are developed in the article, including the
actual Bui stability barrier, reducible critical blocks, boundary-singular
crossings, two-limit coefficient asymptotics, verified enumeration, and
geometric neighborhood refinement.
