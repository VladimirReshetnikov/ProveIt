# Closing the Catalan Growth-Constant Gap

Research manuscript prepared for Vladimir Reshetnikov, September 28, 2026.

## Main mathematical results

For adjacency-bounded 132-avoiding permutations, write alpha_m for the
fixed-m exponential growth constant. Let r_m be the positive solution of

    sum_{k=1}^m Catalan(k-1) * r_m^k = 1,

and beta_m = 1/r_m. The article proves

    alpha_m < beta_m                         (m >= 2),
    0 <= beta_m - alpha_m = O(log(m)^2/m^2),
    m(4-alpha_m) - 2 log(m) - 4 log(log(m)) -> 2 log(pi).

It also derives all inverse-logarithmic corrections through an explicit
polynomial recursion. The first four correction polynomials are included
and symbolically checked.

This resolves the specific centered-remainder question left open in the
inspected ProveIt adjacency-bounded-132-avoiders report. The broader ordering
of the two finite-state components, the optimal scalar defect, and joint
length/bound limits are not resolved. The article proposes nine research
directions and explains these boundaries.

## Status

The universal claims are supported by written mathematical proofs in the
article. This is an unrefereed, AI-assisted research manuscript, not an
external novelty certification. No new Lean or Rocq formalization is supplied
or claimed. Finite checks supplement rather than replace the proofs.

Exact certificates and floating-point illustrations are kept separate.
The decimal bounds in the article's certified table are rounded outwards
from exact fractions. The large-m and component tables, and both figures,
are floating-point illustrations, not interval certificates.

## Build the PDF

The retained figure PDFs are sufficient; computation need not be rerun.
Use a standard TeX Live installation with newpx, amsmath, amsthm, mathtools,
tcolorbox, cleveref, and the other packages declared in article.tex.
From this directory:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

No font files are distributed. The source uses standard installed TeX fonts.

## Exact verification (Python 3.10+, no third-party dependencies)

    python code/verify.py

Do not use Python's -O option: the verifier uses assertions. It writes
`data/verification_report.json` and `data/rational_certificates.json`.
Checks include exhaustive avoidance through length seven, first-entry
counts, Catalan-witness coefficient comparisons, uniform deficiency tails,
restricted-U comparisons, and five exact rational scalar corridors.

## Symbolic and numerical reproduction (optional)

    python -m pip install -r requirements.txt
    python code/verify_expansion.py
    python code/compute.py
    python code/plot_results.py

To limit numerical-library threads in a POSIX shell, the numerical command
can be written as `OPENBLAS_NUM_THREADS=1 python code/compute.py`.

`verify_expansion.py` uses exact rational SymPy algebra and writes the
first four polynomials and a zero-residual check to
`data/expansion_verification.json`. The divergent formal series used for
coefficient extraction is never numerically summed.

`compute.py` produces component comparisons through selected m <= 50 and
scalar-root calculations through m = 1,000,000, using normalized Catalan
coefficients. Its output is numerical, not rigorously outward-rounded.
`plot_results.py` recreates two independent figures from those CSV files.

The executed package versions are recorded in `data/environment.json`.

## Source provenance

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 6c9175a54bcaad3bfc2d416257d2b7d3dff2c1e0
Report path:
SetTheory/Cardinals/docs/reports/enumerative-combinatorics/adjacency-bounded-132-avoiders/article.tex
Source Git blob: 5ec75ee48df94b6d12804a26ba109c08564df5c7

The report is dated September 19, 2026. Its concluding section explicitly
asks whether the centered remainder E_m converges and identifies the prior
window of width 4 log(2). The present article retains attribution for the
endpoint system and recoverable skew-block construction.

Primary papers checked on September 28, 2026:
- Nathaniel Nadler, arXiv:2604.22135v1.
- Teruki Mayama and Dai Akita, arXiv:2605.23519v1.

The manuscript includes hyperlinks and a detailed provenance appendix.
The prior source reports themselves are not redistributed in this archive.
