# K225: a 225-state composition

The principal table is portable/results/k225.tm: 225 working states, start state 0, dispatcher 83, separate halt 225; binary alphabet, one two-way tape, blank input, initialization included.

Canonical SHA-256:
f5d69a16a0324c69c8c6c407dbf18abcccf0e2d2a2283d5101ebc4591964140c

The four-page report and editable LaTeX are in report/. The self-contained ordinary proof packet is portable/. It includes the pinned226 baseline, all exact source and machine data, complete state maps, independent checks, and the universal runtime engine.

From this directory:

    python3 -B portable/reproduce.py --full --output-dir ../k225-replay

Python 3.10+ standard library suffices. Leave assertions enabled. The --full mode freshly rederives all 6,656 unbounded 225 runtime cases. Add --full-baseline to also rederive the inherited 226 runtime; this does not rebuild Rocq or rederive K230.

The result has an ordinary mathematical proof, formalizable in ZFC, that blank nonhalting is equivalent to Con(ZFC), inheriting the pinned K230 calibration. No new reduced-table Rocq endpoint, internal PA proof code, unconditional consistency result, or minimality claim is supplied.

A clean-extraction full replay passed. A later documentation-only correction clarified --full-baseline; the executable Python AST and every other mathematical input were independently verified unchanged, and the corrected sealed packet passed a second clean-extraction quick replay. Both receipts are retained in delivery_verification/.

additional_audits/ contains input audits, compatibility analysis, independent startup/report checks, and scoped search receipts. Their historical paths are provenance, not extra dependencies of the portable replay. Finite/negative discovery screens are not lower bounds.

All inherited attributions and licenses remain in portable/baseline226/. The new contribution is the four-rotation helper-preserving 225 composition. No repository push or publication was performed.
