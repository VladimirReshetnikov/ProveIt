# One closure schema toward a smaller ZFC consistency machine

Prepared for Vladimir Reshetnikov, 16 October 2026.

Start with **report.pdf**. The complete LaTeX source is `report.tex` plus
the `sections/` directory. The report reviews the specified ProveIt commits,
the newer work through `bda2b4860e6b3664d8ae84978bd7683572f55f49`, and the
separately pinned upstream 253-state benchmark.

## Principal recommendation and status

Use equality-free subset-seeded positive closure (PSC) alone as the
nonlogical theory, with a **complete** equality-free refutation checker.
The theory has one infinite schema, arbitrary finite parameters, one binary
relation, and no Extensionality, congruence or irreflexivity axiom.

The late repository intake already accepts the ordinary mathematical
PSC-only consistency calibration from **batch 144 source 08**. This report
credits that result and supplies an independently checked alternative
bootstrap using incoming-profile fragments and a nonempty monochromatic
decoder. Its final interpretation adopts source 08's shorter purity cut.
The full argument proves, in ZFC, `Con(PSC) iff Con(ZFC)`.

The package also contains two exact logical countermodels for the isolated
kernel of the current 252-state experiment, a total base-three decoder,
a complete finite tableau reference and fair certificate enumeration, and
measured 276/280-state compiler controls. **No new verified state record is
claimed.** The existing 253-state table has external upstream proof
endpoints; the finite table/renumbering/bootstrap audit was rerun here.

## Reproduce the finite checks

Use Python 3.10 or newer (the recorded run used Python 3.12). Only the
standard library is required. Run from this directory, without `python -O`:

```sh
python code/run_checks.py
```

This reruns the tableau and search regressions, algebraic logical audit,
all 66,066 graphs on domains of sizes 1–4 for the decoder checks, all 276
exceptional-row semantic cases, and the full 312,975-step 253-state bootstrap
audit. Results are written under `results/`. These are finite checks with
explicit scopes, not consistency proofs or proof-assistant certificates.

Inspect the concrete variable-instantiation example:

```sh
python code/environment_tableau.py examples/ui.json
python code/environment_tableau.py examples/schema_identity.json
```

The output must have `valid: true` and **`refutation: false`**: these are
theorem demonstrations. The actual refutation enumerator never supplies
a theorem field and accepts only a verified refutation of logical bottom.

```sh
python code/refutation_search.py --limit 500
```

The limit runs a finite diagnostic prefix and then stops. That stop is not
the halting event of the mathematical search. Without `--limit`, the abstract
search enumerates all natural certificate codes; the Python implementation
remains subject to host resource limits. Memory/recursion/interpreter errors
are never interpreted as a successful refutation.

## Reproduce all ten compiler measurements offline

Nine unmodified pinned source files are included under `reference_sources/`.
They retain the directory layout required by the original ProveIt recovery
code. They are a small dependency snapshot, not a complete ProveIt checkout.

```sh
python code/measure_psc_controls.py \
  --repo reference_sources/proveit \
  --output /tmp/qpsc-controls
```

Choose an output directory outside `reference_sources/proveit`. The script
checks all pinned generator/backend hashes and emits ten named tables plus
`measurements.json`. Compare the state counts and table hashes against
`results/psc_measurements.json`. All controls keep the original eight logical
schemas, base-four coding and separate logical vacuity gates. The 276- and
280-state outputs are **uncalibrated compiler controls**, not new certified
consistency machines.

## Build the report

Install a standard TeX distribution with `latexmk`, Latin Modern, AMS packages,
`microtype`, `booktabs`, `tabularx`, `enumitem`, `xurl`, `fancyhdr`, `listings`
and `hyperref`. Then:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error report.tex`
three times. The bibliography is included as ordinary LaTeX; BibTeX is not
required. The delivered PDF was rendered and visually inspected.

## Contents

| Path | Role |
|---|---|
| `report.pdf`, `report.tex`, `sections/` | Complete report and editable source |
| `code/environment_tableau.py` | Six-rule environment-based signed tableau verifier |
| `code/qpsc_syntax.py` | Attributed capture-avoiding named schema generator |
| `code/refutation_search.py` | Total finite-certificate decoder and fair enumeration |
| `code/test_tableau.py`, `code/test_search.py` | Semantic/adversarial/target-guard regressions |
| `code/audit_calculus.py` | Exact logical obstructions and total base-three codec |
| `code/audit_monochromatic_decoder.py` | Local graph regressions and two small witnesses |
| `code/check_exceptional_psc.py` | Captured-binder checks for codes zero and one |
| `code/measure_psc_controls.py` | Reproducible full-logic compiler measurements |
| `code/verify_benchmarks.py` | Attributed independent literal 253/254 table audit |
| `examples/` | Valid theorem certificates, not refutations |
| `results/` | JSON evidence, verification scopes and build/QA information |
| `machines/` | Existing benchmark/candidate tables and named compiler controls |
| `notes/` | Readable proofs, audit notes and late-source reconciliation |
| `provenance/` | Commit, source, archive and file-hash metadata |
| `reference_sources/` | Nine exact compiler dependency files |
| `ATTRIBUTION.md` | Authorship and third-party license boundaries |
| `MANIFEST.sha256` | Integrity hashes for the delivered contents |

The compiler measurements remain pinned to ProveIt
`17d0f2eaa650901cda59764dfcc4661c199e49c8` and upstream
`297ab8df7e5de329605c3875b4934643b371a5e3`. The later repository review
changes attribution and formalization status, not those measured inputs.

The report's mathematical proof, its Python reference, recorded upstream
formal results, and its uncalibrated machine controls have separate scopes.
See Sections 3–8 and the source-specific notices before reusing a state count.
