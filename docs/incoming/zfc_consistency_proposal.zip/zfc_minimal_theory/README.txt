SMALL TURING MACHINES FOR Con(ZFC)
Research report and reproducible artifacts — 16 October 2026
=======================================================================

START HERE
----------
report.pdf is the complete report. Its editable sources are report.tex
and sections/*.tex. The main proposal uses equality-free empty-seed
positive closure (EPSC) in a complete first-order logical interface.

The new local theorem is that EPSC proves

    E(a,b) := forall z (R(a,z) -> R(b,z))

equivalent to full incoming-and-outgoing observational equivalence O.
EPSC first supplies exact O-singletons, making the proof noncircular.
A reserved-variable translation then represents equality and logical
Bottom using only membership, implication and universal quantification.
The target is designated-F derivability; it is not ordinary inconsistency
of a bottom-free theory. The report proves the exact model and refutation
transports and states the remaining numerical/machine obligations.

There is NO new sub-253 consistency machine in this archive. The best
strict EPSC proxy control tested has 288 working states. The 253-state
table is attributed upstream data, not a new construction by this report.

CONTENTS
--------
report.tex, sections/, report.pdf
    Complete LaTeX source and compiled report.

code/proxy_kernel.py; results/proxy_validation.json
    Profile theorem diagnostics, formula translation and prefix codec.
    Checks 66,066 finite relations, 51,968 truth comparisons, and two
    binder-error controls. No tested structure is claimed to model EPSC.

experiments/o_erasure/
    Exact compiler controls retaining cross-variable equality transport.
    Includes eight frozen best recipes, all 264 search measurements,
    symbolic formulas, macro words, named and numeric transition tables,
    independent operational/table audits, pinned vendored helpers,
    and the inherited Wade MIT-0 license.
    README.txt states the precise mathematical and compiler boundary.

experiments/record/
    Exact upstream 253-state table; complete finite certificate ruling
    out any strict one-step state quotient; independent verifier;
    finite macro witness corpus and a blank initialization prefix.
    The conditional 252-state quotient omits one bootstrap row and
    is not a 252-state blank-tape consistency machine.

experiments/sk_carrier/
    A genuine finite theory: Kxy=x, Sxyz=(xz)(yz), P!=K, with universal
    closures on the two equations. P is a fully emitted closed term.
    Includes a one-constant variant, full and packed payloads, compiler,
    finite regression checks, metrics, and supplementary proof_sketch.tex.
    For the literal input table, the payload has 192,272 BCL bits.
    Its relation to the user's exact Con(ZFC) sentence still inherits
    the separately identified calibration of that input machine.

reproduce.py
    Runs the six offline finite verification jobs and stores per-job logs
    and results/reproduction.json. Requires Python 3.10+ standard library.
    Do not run Python with -O: several tests intentionally use assertions.

build_report.py
    Rebuilds the main report PDF using three pdflatex passes. Requires a
    normal LaTeX installation. Temporary output is under tmp/pdf/.

SHA256SUMS.txt
    Delivered-file integrity hashes, excluding this manifest itself.

REPRODUCTION
------------
From the extracted top-level directory:

    python3 reproduce.py
    python3 build_report.py

The reproduction script has no network or package-installation behavior.
The finite experiments are deterministic. Generated logs and replay
outputs can be regenerated locally; the original measurement JSON is
kept separately from the replay results.

To repeat the full bounded compiler family rather than the frozen best
recipes, run from experiments/o_erasure/:

    python3 measure_proxy.py --seeds 32 --output another_output_directory

The optional 8,391-case full macro census needs the pinned upstream
Prog254.v identified by immutable URL and SHA256 in record/metadata.json.
The included 187-case corpus checks the same 505 observed macro rows
without that larger source input. The all-pairs quotient theorem requires
only the complete literal table and certificate, not a reachability census.

SOURCE PINS AND ATTRIBUTION
--------------------------
ProveIt audit cutoff:
    2178c3885423f923021d4aaf1dbf52b4e2060837
    https://github.com/VladimirReshetnikov/ProveIt

Requested commits:
    6d8bc7f1ba02c83e54757366f019f61b966ed0b7
    63c83cf79986f8a92bb75460848a1d4f863b7b15

Submitted upstream 253-state reference:
    0d544f2a2e3c18f12278441a74b7879f31cbe856
    https://github.com/jeff87654/busy-beaver/pull/20
    Open/unmerged at inspection. Machine by mira-emmy, derived from
    Mira-Cult's 254-state machine, with Jeff's verification and Andrew
    James Wade's framework. Source, CI and literal-table hashes are
    recorded in experiments/record/metadata.json.

The EPSC seed-removal and raw PSC hereditary-saturation calibrations are
prior work preserved by ProveIt and cited in the report. The general SK
and term-model techniques are standard. The new report, tests, compiler
controls, payloads and quotient certificate were prepared by OpenAI's
assistant for this request; no historical novelty is claimed for the
general methods. Vendored upstream helpers retain their source notices
and are not presented as newly verified compiler code.

VERIFICATION BOUNDARY
---------------------
The report supplies ordinary mathematical proofs and explicit finite
certificates. It does not include a new Lean/Coq build, a proof-assistant
extraction of the Python compiler, a full simulation proof for the changed
288-state control, or an internally serialized ZFC proof for a new literal
machine. The upstream Coq result is reported at its declared external
halting/refutation scope. These distinctions are part of the result.
