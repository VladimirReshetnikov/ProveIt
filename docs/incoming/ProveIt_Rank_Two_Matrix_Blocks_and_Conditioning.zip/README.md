# Rank Two Matrix Blocks and Exterior Conditioning

The report proves a regular-minor matrix theorem and exact conditioning reductions.

- A matrix with q ordinary columns and an exterior column block of rank two has a ULC_(q+2) regular-minor support polynomial for arbitrary positive activities. This is actual-rank normalization when the total matrix rank is q+2.
- Conditioning a matchable right set with Hall slack zero or one gives an exact graph reduction; slack two gives an exact regular-minor matrix reduction through a two-dimensional coefficient kernel.
- In a genuine a+q bipartite cover, forcing any matchable a−2 exterior-right vertices therefore leaves t^(a−2) times an actual-degree-(q+2) ULC polynomial.
- Scaling those forced activities sufficiently far makes the complete original polynomial strictly ULC_(a+q). The report gives a coefficient-based threshold depending on the graph and fixed activities.

The compressed matrix need not be a graph representation. A positive 9×9 rank-three matrix with polynomial 1+81t+1296t²+7056t³ illustrates the scope distinction. The finite-activity rank-six one-shore problem remains open.

## Read and reproduce

Read `article.pdf`; edit `article.tex`.

Use Python 3.10 or later with SymPy installed, then run:

`python3 checks/run_all.py`

`requirements.txt` lists the single third-party dependency. All determinant and activity calculations are exact. The suite checks 32 rank-two-block lifts, 32 degree-three contractions, 50 general-kernel compressions including omitted and parallel lines, 200 graph reductions, 36 eventual-scaling thresholds, and all 8,433 relevant minors of the rank-three example.

A normal TeX installation can build the PDF with `pdflatex article.tex` twice. The supplied `build_local.sh` supports the minimal TeX setup used here.

The mathematical arguments and verifiers received independent review. The finite examples are regression checks, not the proof of the universal statements. This is not formal theorem-prover verification or an exhaustive priority claim.
