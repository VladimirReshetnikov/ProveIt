DISTINCT MULTIPLICITIES -- PRIMARY ARTICLE
=========================================

article.tex is the main LaTeX entry point. The mathematical proof, source
review, exact checks, and proposed research questions are in sections/.
The compiled article.pdf and both vector figure components are included.

Build with:
    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
or use ../build.py to rebuild both manuscripts in this package.

Reproduce the finite checks and samples with:
    python3 code/verify.py
Recreate the figure components with:
    python3 code/make_figures.py

The scripts resolve their input and output directories from their own paths,
so they can also be invoked from the package root. Dependencies and exact
verification scope are documented in code/README.txt and requirements.txt.
All correctness checks remain active under optimized Python.

Key results are Theorem 1.1 (three fluctuation regimes), Corollaries 1.2--1.4
(unweighted variance/CLT, Gumbel law, quadratic-weight limit), Theorem 1.5
(critical window), and Theorem 8.1 (mutual independence of the regimes).
The quantitative conditioning argument is Proposition 3.4.

This directory can be integrated as a separate continuation alongside the
existing ProveIt A373271 report. The exact source pin and attribution are
recorded in Section 2 and the references. The new proofs do not depend on
the earlier report's refined mean expansion.

The numerical data are diagnostics and finite checks, not substitutes for
the asymptotic proofs. The critical finite-size discrepancy is deliberately
retained. No proof-assistant formalization or functional tightness theorem
is included.
