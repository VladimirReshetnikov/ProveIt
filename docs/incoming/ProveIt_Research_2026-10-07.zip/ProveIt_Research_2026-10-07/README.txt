PROVEIT RESEARCH CONTINUATION -- 7 OCTOBER 2026
=============================================

This package contains two independent mathematical research manuscripts,
their complete LaTeX sources and compiled PDFs, and reproducible verification
material. Prepared with ChatGPT for the requested continuation of research in
VladimirReshetnikov/ProveIt and VladimirReshetnikov/math.

PRIMARY ARTICLE
---------------
partitions/article.pdf
partitions/article.tex

Title: Fluctuations of Distinct Multiplicities in Random Integer Partitions

For a uniform partition of n, let D_alpha sum m^alpha over the distinct
positive multiplicity values m that occur. The article proves:

* Gaussian limits for 0 <= alpha < 1/2, with an explicit positive covariance
  kernel and variance asymptotic V_alpha * tau^(-alpha-1/2),
  tau = pi / sqrt(6n).
* At alpha = 1/2, variance asymptotic
  (1-pi/4) * log(1/tau) / (2*tau), with a Gaussian limit.
* For alpha > 1/2, centered limits given by convergent series of powers of
  independent mean-one exponential variables; all these limits are non-Gaussian.
* An explicit critical-window covariance for alpha = 1/2 + theta/log(1/tau).
* Mutual independence of the three limiting families in joint finite-dimensional
  convergence, with a separately proved row-deletion lemma.
* Var(D_0) ~ 0.308000244403717958... * n^(1/4), answering the inspected
  ProveIt Report 197 variance and central-limit question.
* A standard Gumbel limit for
  tau*D_1 - log(1/tau)/2 - (3-3*EulerGamma)/2, and Var(D_1) ~ n.
* Explicit weighted means, uncentered limits for alpha > 1, and the example
  E[D_2]/n -> 2 and Var(D_2)/n^2 -> 8.

The proof includes full support localization, a quantitative reservoir local
limit theorem, conditional first/second-moment transfer, repeated-index
cumulants, Efron--Stein collision estimates, and uniform moving-window bounds.
It does not assume the refined earlier mean expansion.

SENSITIVITY COMPANION
--------------------
sensitivity/article.pdf
sensitivity/article.tex

Title: An explicit exponent above 65/32 for ordinary sensitivity versus
block sensitivity

The note proves the existence of total Boolean functions F_m with
  s(F_m) <= (9*2^318)^m,
  bs(F_m,0) >= (100*2^646)^m.
Hence bs(F_m,0)/s(F_m)^(65/32) tends to infinity. The conservative explicit
exponent from these bounds is 2.03208272439..., strictly larger than 65/32.
This refines the nested tournament construction in math family 132.

The note proves all general combinatorial recurrences and composition steps.
Its twenty-stage finite calculation is checked with arbitrary-precision
integers. The label construction is an existence proof with finite exhaustive
search; no enormous truth table or practical label-generation algorithm is
claimed. The sensitivity is ordinary one-bit sensitivity, not spectral
sensitivity. The note records the source's stronger d=20 baseline, so the
comparison does not rely only on its first displayed example.

BUILDING THE PDFS
-----------------
From this directory:

    python3 build.py

This requires pdflatex and standard TeX packages. It compiles each manuscript
three times, resolves its internal references, and verifies that the final
logs contain no undefined references/citations or overfull boxes. It does not
download dependencies. Existing vector figure components are included, so
Python plotting libraries are unnecessary merely to rebuild the PDFs.

Alternatively, from either manuscript directory, run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

Each directory is self-contained. The primary source has modular sections
under partitions/sections/. No external bibliography processor is required.

REPRODUCING THE CHECKS
----------------------
The sensitivity certificate uses only Python's standard library:

    python3 -O sensitivity/verify.py

Its exact full output is sensitivity/certificate.json. To write a fresh copy:

    python3 sensitivity/verify.py --json sensitivity/certificate.json

For the partition checks, use the dependencies listed in
partitions/code/requirements.txt, then:

    python3 partitions/code/verify.py
    python3 partitions/code/make_figures.py

The default partition run enumerates every partition through n=40 and compares
first, second, and selected cross moments with an independent forbidden-value
generating-function method. It includes 215,308 exact partitions. It also
reproduces high-precision constant checks and 6,000 seeded finite-row Boltzmann
samples. These samples are unconditioned and are not fixed-n simulations.
All samples and the visible slow critical convergence are retained.

For a quicker replay without the simulations:

    python3 -O partitions/code/verify.py --skip-simulations --output-dir /tmp/partition-checks

Use an output directory appropriate to your system. Verification conditions
raise explicit exceptions and remain active under python3 -O. More detailed
scope and reproduction information appears in each manuscript and its README.

REPOSITORY INTEGRATION
----------------------
The partition article is a continuation of Report 197 at:
SetTheory/Cardinals/docs/reports/generating-functions-and-asymptotics/
oeis-sequence-asymptotics/a373271-distinct-multiplicity-values/

Preserve the existing mean paper. The new partitions/ directory can be added
as a separate continuation, with a link from the earlier report. The
sensitivity/ directory is independent and should have its own entry. No
repository files were modified or pushed by the preparation of this package.

SOURCE PINS AND RESEARCH STATUS
-------------------------------
ProveIt: 1210e9d3ac88a573f98d7ef8626ba3d2c30e9749
         2026-10-07 16:29:40 UTC
math:    adc7f1241b42e322a6451854ab7e4b4c146bf78a
         2026-10-06 21:58:50 UTC

Detailed attribution, source-access limitations, and further research questions
are in the manuscripts. The review was targeted, not a verification of every
repository manuscript. New means progress beyond the inspected source
statements; no exhaustive historical-priority claim is made.

These are written mathematical proofs with independent internal audits and
finite checks. They are not externally peer-reviewed publications or new
Lean/Rocq formalizations. Exact computations establish their finite claims;
the all-size theorems depend on the mathematical arguments. The source's
existing formalization was inspected but not rebuilt for this task.

MANIFEST
--------
SHA256SUMS records every delivered file except itself, relative to this root.
Run sha256sum -c SHA256SUMS on systems that provide that command. The hashes
verify package integrity, not mathematical correctness. A rebuild can change
PDF bytes and therefore need not match the delivery hashes.

The package intentionally excludes scratch searches, superseded schedules,
downloaded prior manuscripts, temporary build files, and page-render previews.
