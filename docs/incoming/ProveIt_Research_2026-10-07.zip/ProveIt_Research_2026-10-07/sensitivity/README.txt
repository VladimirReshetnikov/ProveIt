ORDINARY SENSITIVITY COMPANION
=============================

Title:
An explicit exponent above 65/32 for ordinary sensitivity versus block sensitivity

Main result:
There is a sequence of nonconstant total Boolean functions F_m with
  s(F_m) <= (9 * 2^318)^m,
  bs(F_m, zero) >= (100 * 2^646)^m.
Thus bs(F_m, zero) >= s(F_m)^alpha_star, where
  alpha_star = log(100 * 2^646) / log(9 * 2^318)
             = 2.03208272439... > 65/32.
The ratio bs(F_m, zero) / s(F_m)^(65/32) tends to infinity.

Files:
  article.tex       Self-contained mathematical proof and research questions.
  article.pdf       Compiled article, when built.
  verify.py         Dependency-free exact integer certificate.
  certificate.json Complete output of the integer calculation (when generated).

Verification:
  python verify.py
  python verify.py --json certificate.json
No third-party Python package, randomness, numerical solver, or floating-point
arithmetic is used by the verifier.  It checks the twenty label union bounds,
the indexed sensitivity recurrences, the disjoint-block bookkeeping, and the
exact rational-exponent inequality.  The general combinatorial recurrence
proof is in article.tex; running the integer verifier does not replace it.

Build:
  pdflatex -interaction=nonstopmode -halt-on-error article.tex
  pdflatex -interaction=nonstopmode -halt-on-error article.tex
The document uses standard AMS mathematics packages, geometry, Latin Modern,
microtype, booktabs, array, verbatim, and hyperref.  No external bibliography
processor or generated figure is required.

Attribution and repository snapshot:
The construction refines OpenAI's September 25, 2026 manuscript,
"A superquadratic separation between sensitivity and block sensitivity".
The source was inspected at VladimirReshetnikov/math commit
  adc7f1241b42e322a6451854ab7e4b4c146bf78a
which is dated October 6, 2026, 21:58:50 UTC.

Pinned manuscript source:
https://github.com/VladimirReshetnikov/math/tree/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/A-superquadratic-separation-between-sensitivity-and-block-sensitivity-September-25-2026/build

The source sections actually reviewed were:
  sections/00-introduction.tex
  sections/01-construction.tex
  sections/02-recurrences.tex
  sections/03-separation.tex

Related formalization scope and proof entry:
https://github.com/VladimirReshetnikov/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/lean/docs/132.md
https://github.com/VladimirReshetnikov/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/lean/OAI/Combinatorics/Sensitivity/Separation.lean
https://github.com/VladimirReshetnikov/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/lean/ComparatorChallenges/SensitivitySeparation.json

Status and limits:
The source's printed d=9 seed certifies exponent about 2.00025240714.
Using d=20 in its original uniform-parameter estimates already gives about
2.00647082823; the companion explicitly includes that stronger baseline.
The new result uses indexed ordinary sensitivities, a sharper gate-list count,
and a different tournament size at each of twenty levels.  Its labels exist by
a finite union bound and can be selected by exhaustive search.  No practical
truth-table construction, optimality claim, or new Lean formalization is made.
The original repository's Lean development was inspected but not rebuilt here.

Ordinary versus spectral sensitivity:
The measure s in this article is ordinary maximum one-bit sensitivity.
The cited Meiburg preprint studies the different spectral sensitivity measure;
its exponent is not used as an ordinary-sensitivity bound.
