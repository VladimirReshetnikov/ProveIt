# Report 114

## Result and scope

This report proves the order-of-growth conjectures for self-complementary tournament **score sequences** (OEIS A345470) and the strong companion (A351869):

- C(n) = Theta(2^n n^(-3/4))
- D(n) = Theta(2^n n^(-3/4))
- The threshold inverse for either count is log_2(x) + (3/4) log_2(log_2(x)) + O(1)

These are counts of sorted score sequences, not tournament isomorphism classes. The proof uses Denisov–Wachtel Theorem 1 (survival and conditional weak convergence), an exact geometric-gap encoding, and an elementary bounded-bridge argument. It does not rely on a killed local limit formula. It proves no leading constant, parity ratio, strong/all limiting ratio, or correction expansion.

Read `report114.pdf`; edit `report114.tex` if desired. The exact finite checks are supplementary consistency tests and do not prove the asymptotic theorem. The external theorem is cited precisely in the report and is not re-proved in the package.

## Replay

Requires Python 3.10 or newer, standard library only. No network connection is used.

    python3 replay.py

This validates the sealed file set, runs the exact checker normally and with `-O`, compares its outputs byte for byte with the archived results, and runs semantic/schema mutation tests plus strict-manifest attack tests. Guards use explicit exceptions, not optimization-disabled assertions. Replay writes only temporary files outside this directory, and verifies the original package again at the end.

To rebuild and compare the PDF too, install pdfTeX/LaTeX and the packages listed in `build-environment.txt`, then run:

    python3 replay.py --build-pdf

This builds the PDF twice in independent temporary directories and requires both outputs to match the archived PDF byte for byte. The same TeX engine, package versions, and fonts are needed for byte identity. Another toolchain may produce a mathematically equivalent PDF with different bytes. The script generates an isolated LaTeX format and enables no shell escape. It does not install anything or write to system caches.

For a single PDF build at an explicit location:

    python3 build_pdf.py --output /tmp/report114-rebuilt.pdf

For an exact checker only:

    python3 checks/validate.py
    python3 -O checks/validate.py

For the mathematical and schema mutation campaign only:

    python3 checks/mutation_campaign.py

The checker's `--only` options permit individual groups; use the full replay for the complete validation contract. `checks/reader_validation.md` explains the coverage and its limits.

## Reproducing the archive

After extracting the original archive, run:

    python3 make_archive.py --output /tmp/report114_reproducible.zip

The archive uses a fixed `report114/` prefix, sorted paths, fixed timestamps and permissions, and stored ZIP members (no compression-library dependency). It contains only the declared files. The output must be outside the sealed package directory. Recreating from unchanged contents gives the same ZIP bytes.

## Files and integrity

- `report114.tex`, `report114.pdf`: the mathematical report
- `checks/validate.py`, `checks/fixtures.json`, `checks/results.json`: exact arithmetic and frozen reference prefixes/results
- `checks/mutation_campaign.py`, `checks/mutation_results.json`: named semantic/schema mutants and their required rejection diagnostics
- `checks/reader_validation.md`: finite-check scope and interpretation
- `build_pdf.py`, `build-environment.txt`: PDF builder and recorded toolchain
- `integrity.py`, `integrity_tests.py`, `integrity_results.json`: strict integrity checks and attack-test results
- `replay.py`: end-to-end local verification
- `make_archive.py`: deterministic ZIP reconstruction
- `manifest.json`: all other files' SHA-256 hashes and sizes

The manifest excludes only itself. It rejects missing or unexpected files/directories, links and special files, malformed entries, duplicate JSON keys or paths, unsafe paths, bad sizes, and bad hashes. A manifest is an integrity record, not a digital signature or a proof of mathematical correctness.

Do not save new files or Python bytecode inside the sealed directory before replay: the extra-file check intentionally rejects them. Work on a separate copy when editing. Downloaded research PDFs are not bundled; primary-source links are in the report bibliography and reference-prefix fixture.

## Small initial exception

C is nondecreasing from n=0. D is nondecreasing for n>=2, but D(1)=1 and D(2)=0. The threshold inverse is defined by its minimum, and the isolated decrease has no effect on the asymptotic inverse formula.
