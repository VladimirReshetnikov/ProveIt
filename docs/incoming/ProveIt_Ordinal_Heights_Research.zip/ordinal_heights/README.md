# Exact ordinal heights of finitely generated downsets
## Persistent coordinates, mixed ordinal fibers, and a finite-state rank calculus

Research manuscript prepared for Vladimir Reshetnikov with ChatGPT, 24 September 2026.

## Main results

The 23-page article proves an exact height formula for the finitary Hoare
powerset (including the empty downset) of every finite lexicographic sum of
ordinal chains. It resolves the mixed-fiber height gap explicitly left in the
ProveIt report *Cofinal strata and ordinal absorption*, at pinned commit
`e21766d04c2b8a9b2cdba0cd43e563024b3bd1b9`.

The central finite persistence theorem counts a coordinate when it leaves a
state, not every time that coordinate remains present. Natural-sum rank bounds
prove the upper estimate; an explicit chain realizes the matching ordinary
ordinal sum. A finite decreasing-sequence-tree cover gives the global maximum.

The principal results are:

- Theorem 3.3: finite persistence theorem for pure ordinal coordinates.
- Theorem 4.2: exact ideal-state dynamic program and finite certificates.
- Corollaries 4.3–4.4: a chain-partition complexity bound and NP membership
  of the height-threshold problem for the explicitly encoded pure-block case.
- Theorem 5.4: compressed maximal-frontier formula for mixed positive pure fibers.
- Theorem 6.2: arbitrary ordinal fibers, including finite and successor fibers,
  by finite Cantor-normal-form refinement.
- Theorem 6.3: exact point ranks of individual finitely generated downsets.
- Further consequences: arbitrary-coordinate phase refinement, scale invariance,
  bounded output coefficient sum, and a sufficient non-chain-coordinate extension.

There are nine proposed further research problems with explicit boundaries.

## Status

The manuscript includes full mathematical proofs but is unrefereed and is not
Lean-verified. The accompanying tests are finite and exact-symbolic checks, not
a proof-assistant verification of transfinite statements. Priority of the general
formulas has not been independently established. Classical special cases and
the pre-existing repository result are identified as such.

The main theorems do not assume any unproved result from ProveIt. No repository
files were modified. This package does not claim a general width formula or
closure under repeated finitary powersets of arbitrary well-quasi-orders.

## Files

| File | Purpose |
|---|---|
| `article.pdf` | Typeset article with complete proofs and bibliography |
| `article.tex` | Self-contained editable LaTeX source, including TikZ diagram |
| `code/ordinals.py` | Exact hereditary Cantor normal forms below epsilon_0 |
| `code/heights.py` | Finite posets, CNF refinement, height/rank algorithms, checker |
| `code/check_certificate.py` | Command-line checker for saved certificates |
| `code/verify.py` | Deterministic finite and symbolic regression suite |
| `examples/*.json` | Inputs, complete certificates, and point-rank example |
| `verification.json` | Actual recorded test outcome and counts |
| `PROOF_AUDIT.md` | Assumptions, proof dependencies, and potential failure points |
| `SOURCES.md` | Repository provenance and literature-search scope |
| `Makefile` | Optional PDF, verification, and cleanup commands |

## Run

Use Python 3.10 or later; no third-party Python packages are needed. The delivered
run used Python 3.13.5 and passed all **63,270 assertions**.

```sh
python code/verify.py
python code/heights.py examples/weighted_N.json
python code/heights.py examples/mixed_CNF.json --output result.json
python code/heights.py examples/point_rank.json
python code/check_certificate.py examples/mixed_CNF_certificate.json
```

On systems that use `python3` or `py -3`, substitute that command for `python`.
The verifier rewrites `verification.json` and the named example certificates.

A small height input is:

```json
{
  "n": 3,
  "edges": [[1, 2]],
  "fiber_types": [[[2, 1]], [[1, 1]], [[1, 1]]]
}
```

Vertices are `0,...,n-1`. An edge `[i,j]` means strict order `i < j`; Hasse edges
are sufficient because the program computes transitive closure. The example
has an isolated omega^2 fiber beside two successive omega fibers, and returns
height omega^2, not omega^2*2.

### Ordinal notation

A nonnegative JSON integer denotes a finite ordinal. Otherwise use a list of
`[exponent, positive_coefficient]` pairs in strictly decreasing exponent order.
Exponents use the same recursive notation. For example:

- `[[2,1],[1,3],[0,2]]` denotes omega^2 + omega*3 + 2.
- `[[[[1,1],[0,1]],1]]` denotes omega^(omega+1).
- `0` denotes an empty fiber; the expansion removes it.

All arithmetic is exact. No infinite ordinal is approximated by a large integer.
The mathematical theorems allow arbitrary ordinal exponents. The executable
hereditary notation represents only ordinals below epsilon_0.

### Point ranks

Add `"generators": [[vertex, position], ...]` to request the exact rank of the
generated downset. Positions are ordinals in the same JSON notation and must
be strictly below their fiber lengths. Redundant generators are normalized.
The result contains a certificate for the principal lower interval, whose
height is the requested rank plus one.

### Safety and complexity

The number of expanded CNF blocks is limited to 20 by default. The state space
can have 2^N ideals, and a CNF coefficient contributes that many unary blocks.
The `--max-vertices` option changes the guard, not the underlying complexity.
Malformed normal forms, strict-order cycles, and invalid generator positions
are rejected. Certificate checking verifies the full ideal-state recurrence,
the witness path, and (when present) the recorded input-to-block refinement.

## Rebuild the article

Use a TeX distribution with pdfLaTeX, the New PX fonts, AMS packages, microtype,
TikZ, hyperref, bookmark, listings, titlesec, fancyhdr, and the other standard
packages in the preamble. Font files are supplied by the TeX distribution and
are not included in this archive.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The bibliography is embedded; no BibTeX run or external image is required.
`make pdf` runs the two passes. The delivered PDF was compiled without LaTeX
warnings or overfull/underfull boxes and visually inspected after rendering.
