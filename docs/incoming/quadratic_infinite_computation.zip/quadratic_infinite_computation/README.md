# Quadratic Laws, Infinite Computation

**Exact Diophantine Dynamics, Planar Stack Machines, and the Boundary Created by Recurrence Deadlines**

Research report prepared for Vladimir Reshetnikov, September 30, 2026.

## Start here

Read `article.pdf` (27 pages). Its editable, self-contained LaTeX source is
`article.tex`; the bibliography is embedded in the source.

The article studies the distinction between finite acceptance and recurrent
infinite behavior. It provides an exact polynomial representation of counter
machine steps, develops compatible finite certificates for prescribed
recurrence deadlines, separates three kinds of recurrent witnesses, and
transfers the results to exact rational piecewise-affine planar dynamics.

## Main mathematical results

For a binary-branching unit-counter machine with `d` counters and `m` edges
including initialization, the compiler produces `P2(X,Y)` and `P4(X,Y)` on
states of dimension `D=d+m`:

- `P2` has degree at most two, coefficient height at most six, and is
  nonnegative on the nonnegative real orthant.
- `P4` has degree at most four and the same height bound; it is globally a
  sum of squares.
- Their natural-number zero graphs are exactly the incoming-edge machine
  transition graph. The encoding has no existential transition auxiliaries
  and preserves edge-labelled paths.

The article proves the fixed-law analytic-completeness transfer and the
strict hierarchy

    computable recurrent run
        => recurrent run with a computable deadline
        => recurrent run,

with counterexamples to both converses. The first two index sets are
Sigma^0_3-complete; unrestricted recurrence is Sigma^1_1-complete.

See Theorem 3.1 for the compiler, Theorem 5.2 for the fixed-law result,
Theorem 8.1 for deadline compactness, Theorem 9.1 for the index-set
classifications, Theorems 10.2 and 10.3 for strict separations, and
Section 11 for the planar realization. Section 15 gives eight concrete
research directions.

## Contents

| Path | Purpose |
| --- | --- |
| `article.pdf` | Complete article with proofs, references, and status ledger |
| `article.tex` | LaTeX source; no separate bibliography file required |
| `code/quadratic_dynamics.py` | Exact sparse-polynomial compiler, machine semantics, finite exploration, and rational stack operations |
| `code/verify.py` | Reproducible finite tests and example export |
| `data/countdown_polynomials.json` | Fully expanded quadratic and quartic polynomials for the eight-dimensional budget example |
| `data/countdown_prefixes.csv` | Exact finite-path statistics through horizon 100 |
| `data/verification_results.json` | Test receipt and scope statement |
| `SOURCE_NOTES.md` | Repository snapshot, source roles, and verification boundaries |
| `Makefile` | Optional build/test commands |
| `SHA256SUMS.txt` | Checksums of the delivered files, excluding the checksum file itself |

## Reproduce the tests

Python 3.10 or later is required. No third-party Python packages are needed.
From the extracted package directory:

```sh
python code/verify.py
```

The test script refuses to run with Python assertions disabled. It regenerates
the JSON and CSV data. The elapsed-time field depends on the computer.

The delivered run passes 59,049 exhaustive state-pair checks, 1,000 exact
rational residual comparisons, 1,000 signed-input quartic checks, 300 generated
machine coefficient audits, and 2,046 exact stack push/pop checks. These are
finite regression checks, not proof-assistant verification of the theorems.

The local compiler can also export its worked example directly:

```sh
python code/quadratic_dynamics.py > budget_example.json
```

### Compile a different finite machine

The following example can be run in a Python script in the package root:

```python
from code.quadratic_dynamics import Edge, Machine

machine = Machine(
    counters=1,
    start="q",
    edges=[
        Edge("q", "r", "inc", 0),
        Edge("r", "q", "dec", 0),
        Edge("r", "halt", "zero", 0),
    ],
    marked={"r"},
)
p2, p4, variable_names = machine.compile()
initial = machine.initial([0])
for successor in machine.successors(initial):
    assert p2.evaluate(initial + successor) == 0
    assert p4.evaluate(initial + successor) == 0
print(machine.dimension, p2.degree, p2.height)
```

The reserved label `*` and initialization edge are added by the constructor.
A no-op has no counter index; all other instruction kinds require one.
Each label may have at most two syntactic outgoing edges. Deadlocks have no
successors and are not automatically padded with self-loops.

## Rebuild the PDF

A LaTeX installation with pdfLaTeX and the packages named at the top of
`article.tex` is required. Run three passes:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, use `make pdf` and `make test` where GNU Make is installed.
The delivered PDF was compiled and its rendered pages inspected.

## Status and limitations

These are mathematical proofs accompanied by executable finite checks, not a
new Lean or Rocq formalization. The repository's existing proof-assistant
build was not rerun. Classical analytic-hardness and recursive-tree results
are cited as prior work, not claimed as new discoveries. Literature priority
for the report's precise normal form and refinements has not been established.
No named long-standing conjecture is claimed solved.

The generic finite-table compiler and the complete budget example are
implemented. A fully instantiated universal interpreter table and its expanded
fixed polynomial are not included: their existence is proved through the
finite compilation route described in the article. The planar realization
uses exact rational inputs and operations; it is not a robustness theorem for
noisy physical computation.

The repository was inspected at commit
`e18718e837d43e162252f9a314e8cb797fbd1a1f`. This package does not modify it.
