# Toward a 217-state ZFC consistency machine

Research packet prepared for Vladimir Reshetnikov's ProveIt repository,
21 October 2026 (UTC).

**This packet does not contain a verified machine with 217 or fewer states
whose blank-start nonhalting is provably equivalent in ZFC to Con(ZFC).**
The requested state reduction was not achieved. The included 217-state
tables are explicitly labelled diagnostic constructions with known missing
or failed obligations. They must not be incorporated as successful entries.

The report and code are based on the public ProveIt revision
`704b87442afbd571833a628cd558f1d207fd8b2f`:
[pinned research tree](https://github.com/VladimirReshetnikov/ProveIt/tree/704b87442afbd571833a628cd558f1d207fd8b2f/Computability/BusyBeaver/Research/ZFC).
No repository changes were pushed.

## Read first

- `report.pdf` is the main mathematical and experimental report.
- `report.tex` is its complete LaTeX source.
- `verify.py` is the offline evidence-replay entry point.
- `SEARCHES.md` describes the finite startup/repair/rotation search families.
- `research/machine-search/README.md` specifies the full two-action fold searches.
- `research/formalism/formalism_research_note.md` gives the longer logical
  derivations, source experiments and open equiconsistency obligations.
- `research/source-search/README.md` specifies the two source-DAG beams and
  one-row cylinder discovery.

## What was established

| Object or result | Exact status |
| --- | --- |
| Pinned K218 | Inherited 218-state control; its accepted calibration is an upstream premise. |
| `data/core217.native.tm` | Existing 217-state delete-301 interpreter. A fresh unbounded runtime replay proves all 6,167 primitive interfaces using 1,515,310 symbolic rules and every one of its 434 rows. All 217 blank initial states instead reach elementary infinite zero rays. |
| 252 one-row core variants | These pass the finite screen. Every one of the 54,684 variant/start combinations has an exact independently replayed zero-ray witness. |
| `data/delete50.native.tm` | A 217-state shortened scanner reaches a logically admissible clean seed after 104,082 steps. An exact seven-zero wrong turn invalidates the intended runtime argument. The affected guard is reachable in the intended abstract source computation. No equivalence or inequivalence theorem for its halting statement is claimed. |
| Clean-seed interface | Independently reviewed and specialized to the new seed. The general cofinal-start argument already appears in upstream report146; it is not a new theorem here. The 79-node equality certificate for native code3 has a separate replay checker. |
| 62 one-row K218 alternatives | Each independently has an exact whole-tape three-for-one step refinement. None removes a state; simultaneous composition is not automatic. |
| Expanded physical and source searches | Exact bounded domains, source prices and completed/partial receipts are retained. No successful reduction resulted, and no global lower bound follows. |
| Freshness-wrapper formalisms | The forward consistency inclusion is clear, but a converse bridge is missing. The cofinite-binder variant is explicitly an open research idea. |

The four accepted K218 layouts and the existing core predate this work.
The main new material is the additional executable evidence, independent
finite witnesses, broader search implementations and executions, source
pricing, and analysis of the consistency gaps in proposed syntax changes.

## Offline verification

Run from this directory using Python 3.11 or newer, without `-O`:

```sh
python3 -B verify.py
```

This verifies the distributed file hashes, table well-formedness, all
core blank rays, all 54,684 one-row ray witnesses, the 79-node equality
certificate, 3,968 one-row refinement cylinders, the shortened scanner's
exact startup/local wrong turn/source reachability, and the stored runtime
case coverage and provenance. It writes its own outputs to `reproduced/`.
It does not treat stored runtime coverage alone as a fresh symbolic proof.

To rederive the unbounded runtime contracts from the supplied engine:

```sh
python3 -B verify.py --full-runtime
```

The packaged full replay passed in about 99 seconds in the preparation
environment and reproduced the stored `cases.json` bytes exactly.
`evidence/portable-full-verification.json` records that execution.
Timing is not a mathematical claim. The proof uses symbolic block induction
and arbitrary register/list parameters, not a finite numerical test bound.
Its soundness is an ordinary mathematical argument about the supplied
engine and block rules; no new Lean/Rocq/kernel endpoint is claimed.

The search results have their own independent accounting and controls:

```sh
python3 -B research/machine-search/code/audit_results.py
python3 -B research/machine-search/code/reproduce_controls.py --output /tmp/zfc217-fold-controls
```

The first command recomputes the finite invariant domains and checks family
sizes and pruning arithmetic. It does not replay each rejected candidate.
The second compiles small synthetic controls and exhaustively compares
their complete survivor sets with the separately supplied diagram checkers.
Their README gives commands to rerun the full search families; a C++20
compiler is required. The radius-15 shifted family in the recorded research
stopped at its time limit and is explicitly incomplete.

Source/pricing and logical-certificate replay:

```sh
python3 -B research/formalism/reproduce_formalism.py --upstream upstream/zfc --verify-only
python3 -B research/formalism/reproduce_formalism.py --upstream upstream/zfc --experiment core
```

The first checks five pinned inputs and independently replays the equality
certificate. The second also regenerates row-order and tag-assignment
prices and the direct-MP finite checks. Additional experiment groups are
listed by `--help`. These source-pricing programs write their experimental
outputs beside themselves; run them in a copy if preserving the original
distribution hashes is desired. Their results are source metrics, not
binary runtime certificates. `origin-map.json` records the original paths
and byte hashes of the selected files and their small upstream dependency set.

## Rebuilding the report

With a standard TeX Live installation including `latexmk`, `lmodern`,
`microtype`, `xurl`, and the usual AMS packages:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build report.tex
```

This produces `build/report.pdf`. The distributed `report.pdf` is the same
typeset source after visual inspection. The longer formalism note also has
a supplemental LaTeX source; `seed217_lemma.tex` is an inclusion fragment,
not a separate standalone document.

## File layout and provenance

`data/` contains exact native tables, source sites, finite proof objects and
compressed witnesses. Native state labels are sparse; a terminal label is
not counted as a working state. `evidence/` contains results and receipts.
`code/` contains portable replay and startup-search programs. `research/`
contains the three selected deeper investigations. `upstream/` holds the
small pinned dependency set needed for offline reproduction.

`UPSTREAM_ATTRIBUTION.md` is an unchanged attribution document from the
accepted upstream K218 contribution. Its references to a new 218-state
construction describe that upstream work, not the present packet.
`UPSTREAM_LICENSE` retains its MIT No Attribution terms; new code in this
packet is supplied under the same terms. Copied and adapted files retain
their notices and hash-based provenance.

`manifest.json` binds the distributed source, data, receipts and PDF.
Generated `reproduced/`, `build/`, bytecode caches, executables, and the
manifest itself are outside that manifest. No network connection or complete
ProveIt checkout is needed for the supplied replay commands.
