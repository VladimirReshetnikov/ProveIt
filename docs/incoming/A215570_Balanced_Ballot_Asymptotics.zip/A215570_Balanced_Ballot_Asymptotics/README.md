# Balanced five-letter ballot words (A215570)

This package contains the standalone proof of the stated leading
asymptotic, two exact corrections, a finite recipe to every algebraic
order, and qualified asymptotic inversion. It uses the defining walk
counts, not the conjectured recurrence.

## Files

- `article.pdf`, `article.tex`: seven-page report and complete LaTeX source
- `checks/`: direct coefficient and exact symbolic jet checks, with outputs
- `audit/`: independent mathematical and exact normalization review
- `run_checks.py`: runs all exact checks in this package
- `build_local.sh`: builds the PDF using standard TeX Live

## Reproduce

Python 3 and SymPy are required for symbolic checks. The direct walk and
kernel-box checks use the Python standard library. No command installs
dependencies, accesses a network, or uses an OEIS recurrence.

Run `python -O run_checks.py`. The second-correction symbolic computation
can take about two minutes. It reconstructs the saddle through degree
six, the amplitude through degree four, and the required Puiseux terms.
It then performs exact Gaussian integration. The direct dynamic program
checks all diagonal coefficients through n=30 and matches the published
initial terms.

The final independent check reconstructs the marked jets with finite
polynomial convolution over an exact algebraic number field and verifies
the complete second correction. Its source and output are in
`checks/audit/`; they are included unchanged from the independent review.

Run `bash build_local.sh` to rebuild the PDF. The script keeps TeX's
generated format and auxiliary files inside `build/`, making it usable
in a container with a read-only home directory.

The finite checks supplement the analytic proof. The theorem is an
all-orders Poincare expansion of the dominant exponential sector, not
a complete description of every smaller exponential contribution. The
particular conjectured order-three recurrence is still unproved here.
The inverse retains its integer-rounding qualification; no numerical
error constant or unconditional exact-ceiling rule is asserted.
