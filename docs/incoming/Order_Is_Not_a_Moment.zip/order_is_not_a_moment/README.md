# Order Is Not a Moment
## Exact Pair-Count Geometry and Diophantine Certificates for Heisenberg Computation

Research report prepared for Vladimir Reshetnikov, 2 October 2026.

The report develops exact word-realizability results motivated by the ProveIt
repository's Heisenberg pair-count obstruction. Complete mathematical proofs
are in `article.pdf` and `article.tex`.

### Results

- For three letters with fixed multiplicities and two fixed independent
  scattered-pair counts, the remaining pair count fills an integer interval.
- A gap representation gives six quadratic equations and `2c+4` natural
  witnesses, where the number `c` of separator letters is fixed externally.
- With exactly two separator letters, four bilinear corner values give the
  exact endpoints without enumeration of words.
- A canonical polynomial has 24 natural witnesses and 24 quadratic residuals;
  its sum of squares is an explicit quartic with 297 nonzero monomials.
  Every accepted pair profile has exactly one complete arithmetic witness tuple.
- With four letters, fixed values of the other five pair counts can force the
  spectrum `{0,b,2b,...,b*floor(n/2)}`, so internal holes can be arbitrarily large.
- The profile certificates lift to arbitrary finite direct powers of the
  integer Heisenberg group by adding three coordinate equations per factor.
- A further theorem decides three-generator membership when the third
  generator's multiplicity is supplied, without bounding the other two counts.

### Scope

This is a research draft, not a peer-reviewed or Lean-kernel-certified result.
Independent priority for the new formulations has not been established.
Finite tests support, but do not replace, the mathematical proofs.
The supplied-multiplicity decision theorem and the general matrix certificate
lift are mathematical results in the article, not separate implemented
membership-solver or exporter APIs.

No universal Diophantine operation bound is improved. No universal monoid is
numerically instantiated. The canonical certificate is single-fold over a
complete profile, not necessarily over a projected matrix target. The
separator-indexed family is not advertised as one fixed-arity all-c polynomial.

### Build

A TeX Live installation with pdfLaTeX, latexmk, newpx, TikZ, tcolorbox,
microtype, and the standard math packages can rebuild the report:

```sh
latexmk -pdf -interaction=nonstopmode article.tex
```

The supplied PDF is already built. Bibliography entries are self-contained;
BibTeX and external source files are not required.

### Run the code

Python 3.10 or later; standard library only. From the package root:

```sh
python3 code/verify.py
python3 code/pair_geometry.py decide 3 2 2 1 4
python3 code/pair_geometry.py decide 3 2 2 1 1
python3 code/pair_geometry.py export /tmp/canonical_c2_quartic.json
```

The first decision accepts and prints its unique witness; the second rejects.
Parameters are `a b p q k`, with the separator count `c=2` fixed:
`a=#A`, `b=#B`, `p=K_AC`, `q=K_BC`, `k=K_AB`.
`K_XY` counts ordered pairs of positions, not adjacent bigrams.

`python3 code/verify.py --write` regenerates the checked receipt.
The normal run recomputes the tests and compares with the bundled receipt.
Do not run Python with `-O`: these development checks deliberately use asserts.

Useful importable functions in `code/pair_geometry.py`:

- `corner_bounds(a,b,p,q)`: exact endpoints for two separators, or `None`.
- `canonical_c2(parameters)`: symbolic system plus triangular candidate tuple.
- `gap_system(c)`: the six-residual, `2c+4`-witness symbolic system.
- `pair_profile(word, alphabet)`: direct scattered-pair statistics.
- `normalization_path(word)`: an explicit path used by the connectivity proof.
- `realize_gaps(a,b,c,p,q,k)`: a small-instance realizing word, or `None`.

All public numeric profile parameters are nonnegative integers. The candidate
returned by `canonical_c2` on a rejected input may contain negative *slacks*;
zero residuals alone are not sufficient. Check the natural domain of all
parameters and witnesses, as the CLI and `System.verify` do. Invalid types
(including booleans) and negative inputs are rejected.

The corner decision and canonical-witness evaluation use exact big-integer
arithmetic and do not enumerate words. Explicit-word, normalization, and
variable-c gap routines are for modest instances and are not polynomial in
binary input length. Extremely large c may also exceed Python recursion limits
in the enumerative helper; it is not the succinct decision interface.

### Polynomial format

`data/canonical_c2_quartic.json` contains:

- all parameter and witness names, with their natural-number domain;
- all 24 residuals as sparse integer polynomials;
- the complete expanded sum-of-squares polynomial;
- degree and monomial counts.

A term is `{"coefficient": integer, "monomial": [variable,...]}`.
Repeated variable names mean repeated factors; an empty list is the constant
monomial. Ordering is deterministic. No min, max, floor, or unexpanded
gadget call is hidden in the JSON polynomial.

### Verification

The reference profile recurrence is independent of the gap and corner
implementations. The test suite checks complete bounded profile sets,
normalization paths, canonical assignments, invalid domains, immutable input
ownership, direct 3-by-3 matrix products, the four-letter obstruction, and
signed off-zero evaluations of the exported polynomial construction.
The receipt records exact counts and a SHA-256 hash of `pair_geometry.py`.
It does not assert an exhaustive search over all candidate witness tuples.

### Repository provenance

Audited commit: `4cccfa06866b6b81b2467e1cf7514ea85ed0216d`.
Relevant source:
`Computability/HilbertTenthProblem/Papers/research-wip/native-stream-queue/heisenberg_two_generator_membership.md`.
Blob: `f155e77516db512d3434c0077cf50bff10ecbcd1`.

The repository was read, not modified. The bibliography in the article links
the pinned note and the external primary sources. The package contains new
code for this report, not copies of the repository's implementation.
