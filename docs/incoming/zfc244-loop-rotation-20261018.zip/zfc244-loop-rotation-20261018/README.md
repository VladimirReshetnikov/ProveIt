# A 244-state Turing machine for Con(ZFC)

This packet gives a concrete **244-working-state, binary, single-tape Turing machine**, with all initialization included, and an ordinary mathematical proof in ZFC of

\[
\neg\operatorname{Halt}(M_{244},0^{\mathbb Z})
\quad\longleftrightarrow\quad
\operatorname{Con}(\mathrm{ZFC}).
\]

The tape is bi-infinite and initially all zero. Every transition moves left or right. The separate halt state is excluded from the working-state count, as in the supplied 245-state construction.

**Read `report.pdf` for the proof, verification results, alternative-formalism research, and complete printed transition table.** The editable source is `report.tex` with the accompanying `sections/*.tex` files.

## Exact machine

| Object | Value |
|---|---|
| Canonical table | `machine/machine.tm` |
| Working states | 0 through 243 |
| Initial state / dispatcher / halt | 0 / 87 / 244 |
| Total transition rows | 488 |
| Inherited-label table | `machine/machine_old.tm` |
| Inherited start / dispatcher / halt | 95 / 96 / 254 |
| Logical source sites | `machine/sites_logical.json` |
| Physical source sites | `machine/sites_physical.json` |
| Exact renumbering | `machine/renumbering.json` |

Canonical SHA-256:

```text
91ff0ff2dfe9155548d21405615934b46784c5e3cb850bbf056682d02b203790
```

Inherited-label SHA-256:

```text
0160caaf5d6db52eb7eb97a76cb04db4b424eb2bc0d58617818a6c7c6a1fe776
```

Every noncomment table row is `state read write direction next_state`. The initial-state declaration is on the first line. The halt state has no outgoing transitions.

## The state-saving idea

Rotate this proof-enumerator loop:

```text
while X > 0:
    X -= 1
    N += 1
N += 1
```

into:

```text
repeat:
    N += 1
    if X == 0:
        exit
    X -= 1
```

Both terminate for every natural input, preserve the other seven registers, send `(N,X)` to `(N+X+1,0)`, and take exactly `3*X+2` source instructions. The old local decoder has three roles; the rotated decoder uses two. Its increment also has the necessary entry phase in the binary implementation.

Starting from the **inherited-label** routing245 table, change exactly:

| Row | Old `(write,move,target)` | New |
|---|---|---|
| `(12,0)` | `(0,R,17)` | `(0,R,18)` |
| `(12,1)` | `(1,R,18)` | `(1,R,17)` |
| `(17,1)` | `(1,R,26)` | `(0,L,20)` |

Delete both rows of state 26. The other 485 retained rows remain unchanged. Apply this patch to the pinned old-label table, **not** to its differently numbered canonical version.

The complete source loses one leaf, becoming 6,459 leaves. An independent checker proves the local transformation over all nine natural-valued registers and checks every one of the 8,385 surrounding control edges. No source reachability invariant or consistency assumption is needed for this transformation.

## Verification and proof scope

| Check | Recorded result |
|---|---|
| Exact table count and canonical renumbering | 244 working states, 488 rows |
| Universal source equivalence | Both unbounded loop cases and 8,385 outside edges pass |
| Universal affine runtime | All 8,390 guarded cases pass |
| Expanded whole-tape runtime | All 8,390 cases, 2,312,438 symbolic rules |
| Positive progress | Minimum constant lower bound 13 transitions |
| Independent frame closure | All 8,389 nonhalting successors normalized |
| Exact blank prefix | 407,931 steps; two tape representations in both numberings |
| Independent finite literal regression | 8,390 cases, 6,470,964 transitions |

Initialization reaches exactly the same complete frame as the reference 245-state machine, 16 transitions later: head −5, marker −6, header 176, empty program counter, logical registers `(3,0,0,0,3,0,0,0,0)`, 167 spare blocks of value one, and exactly 351 one-cells.

The expanded runtime quantifies an independent natural gap, all nine primary registers, and every nonempty finite spare suffix. Its unary and list rules are justified by induction. The finite literal fixtures provide an independent regression check; they are not substituted for the universal argument.

There is one retained unused transition, `(27,1)` in old labels. All valid runtime paths and the complete blank prefix avoid it. The table retains this row for totality, and state 27 still counts. An initial wrapper incorrectly demanded that every retained row be visited; it was corrected, and the expanded replay was rerun fully. No instruction case or register valuation was removed.

Composing the exact boot and runtime, the source rotation, and the inherited calibrated source theorem proves the requested ZFC equivalence. **This is an ordinary mathematical proof with executable certificates, not a newly completed Lean/Rocq endpoint or a serialized ZFC proof object.** The exact 245-state kernel endpoint was already open in the supplied baseline. The current source/root and set-theoretic adapters are explicitly identified in the report.

## Reproduce

Python 3.10 or newer, standard library only; tested on Python 3.12. Assertions must remain enabled: do not use `-O`. No network is required.

```bash
python3 -B code/verify_all.py --whole-frame --baseline \
  --output /tmp/zfc244-full-replay
```

Use a new or empty output directory. This reconstructs the new machine and replays its checks, including the expanded whole-frame proof, and executes the unchanged baseline's verifier. It takes several minutes. To repeat the unchanged 245-state ancestor's expanded proof as well, add `--baseline-whole-frame`; its separate complete replay is already recorded. All fresh results are written outside the delivered certificate directories.

A complete replay from this packet's portable paths passed with status `PASS_244_FULL_REPLAY` in approximately 398 seconds. Its summary and driver log are preserved as `certificate/portable-full-replay.json` and `certificate/portable-full-replay.log`. The summary's manifest count describes the packet at that replay; the final manifest additionally includes these records and final document files.

For a shorter integration check:

```bash
python3 -B code/verify_all.py --output /tmp/zfc244-fast-replay
```

The fast mode still rebuilds the table, independently proves the source rotation, checks every frame successor, executes four exact blank runs, checks all universal affine cases, and regenerates all finite literal fixtures. It checks the recorded expanded certificate's identity and completeness but does not freshly execute that expanded replay.

The printed table and PDF can be rebuilt with:

```bash
python3 code/render_table.py --check
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

## Further research included

`research/formalisms/` contains independently checked K/B/Peirce and fixed-falsity Peirce certificates; explicit source-calculus equivalences and enumerator-width bridges; equality-root fusion and separately gated bundle experiments; and exact finite countermodels to several tempting propositional shortcuts. The matrices' scope is explicitly limited to their stated fragments, not the full CP/GIC theory.

`research/grammar/` contains portable generators, 560 independently checked conjunction/DNE sources, selected grammar witnesses, aggregate audits, broader C++ search moves, and the source-only NIP reductions. `research/joint-source/` contains the composed equality/DNE family, row and role permutation families, and the separate 14,867,173-proposal campaign. These searches did not produce the successful machine; the QT loop rotation changes the source control-flow vocabulary itself.

The earlier shared-helper deletion is **rejected** and isolated under `research/rejected/`. Its passing blank prefix does not certify it. The only certified new primary machine is the one identified by the canonical hash above.

## Provenance and integration

ProveIt is pinned at `fd1adfa19f8fe8da41444e3fa43b89a59d891067`; upstream `zf-254` at `c132d7eae8158cd3a9850ea3eb7251158c3dd821`. The original 245-state proof package is preserved under `reference/baseline245`, with its own 293-file manifest. Its complete fresh replay is recorded separately.

`PROVENANCE.json`, `ATTRIBUTION.md`, the research manifests, and `SHA256SUMS` identify the inputs, modifications, original notices, and every delivered file. The packet can be incorporated as an incoming research archive, with the primary machine and certificates maintained in a new `candidate-rotation244` directory if desired. No remote repository changes were made while preparing it.
