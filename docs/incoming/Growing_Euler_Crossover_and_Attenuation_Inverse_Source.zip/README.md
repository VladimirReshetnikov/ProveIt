# Report 148

Growing Euler crossover and attenuation inverse

This package proves a uniform moderate-cloud expansion for the two-parameter Euler products associated with A252782 and A270917. For n = 3m + r and z = m²(8/9)^t up to S m^(3/4), the ratio to its undepleted pure-defect normalizer has limiting attenuation exp(-8s^(4/3)/9), s = z/m^(3/4). The report includes quarter-power corrections, the noninteger size-five correction, the full infinite atom bound, and a real-parameter attenuation inverse.

The smooth finite model has one root on the prescribed compact window. The exact ratio has at least one crossing there and every such crossing is localized; exact uniqueness and monotonicity are not asserted. The inverse must not be rounded into an exact integer-t threshold. Uniform asymptotic error bounds are not effective finite-input numerical certificates.

## Contents

- `Report148.pdf` and `Report148.tex`: the report and its editable LaTeX source
- `companion/`: new Python standard-library exact checks, semantic fixtures, and a reproducible certificate; see its README for detail
- `foundation/Report147.pdf` and `foundation/Report147.tex`: unchanged reference copies of the earlier report; its computational code archive is deliberately not included
- `build_pdf.py`: a deterministic clean local TeX build, with shell escape disabled and a warning-free settled-log requirement
- `make_zip.py`: fixed-allowlist archive builder, normalized timestamps and permissions, no recursive collection, and no overwrite
- `SOURCE_PROVENANCE.json`: frozen mathematical-source and unchanged foundation hashes
- `SHA256SUMS`: hashes of every other archive payload

The PDF is self-contained. The foundation files are context, not an imported proof of the growing-range estimates. No external publication, submission, contact, or repository action was made.

## Requirements

The exact companion requires Python 3.10 or later and only the standard library. Hardened certificate creation also requires POSIX O_NOFOLLOW and O_DIRECTORY support. No installation command or network access is needed. The PDF rebuild additionally needs a Linux TeX Live installation with `pdftex`, `pdflatex`, Latin Modern, amsmath/amsthm/mathtools, geometry, booktabs, longtable, array, microtype, and hyperref. The bundled builder uses the Debian-style system trees `/usr/share/texlive/texmf-dist` and `/usr/share/texmf`. The test environment used Python 3 and pdfTeX 1.40.26 (TeX Live 2025/dev/Debian).

The PDF is byte-reproducible on the tested TeX toolchain. Different TeX distributions or versions can change bytes despite equivalent rendering. The unchanged foundation PDF is supplied, not rebuilt by this package.

## Verify and rebuild

Run commands from the extracted package root. Each build/archive output must be new; the tools refuse existing targets and symlink output paths. Create the working parent once:

```sh
mkdir validation
sha256sum -c SHA256SUMS
python3 build_pdf.py --output-dir validation/pdf-a
python3 build_pdf.py --output-dir validation/pdf-b
cmp Report148.pdf validation/pdf-a/Report148.pdf
cmp validation/pdf-a/Report148.pdf validation/pdf-b/Report148.pdf
python3 make_zip.py --output validation/source-a.zip
python3 make_zip.py --output validation/source-b.zip
cmp validation/source-a.zip validation/source-b.zip
```

The PDF builder starts with an empty default font map and adds only its explicit required maps. It runs until the auxiliary cross-references stabilize and rejects warning, overfull, underfull, or missing-character messages in the final TeX log. Early first-pass undefined-reference warnings are normal and are not accepted in the settled log.

Run the companion's exact verification commands from the package root as documented in `companion/README.md`, in both normal and optimized (`-O`) modes. The package's final validation tested those exact commands from a fresh extraction, in addition to the commands above.

## What the exact checks mean

The companion checks finite coefficient rows independently, fixture semantics, exact rational polynomial identities, inverse equations, exponent comparisons, and finite falling-factorial bounds. Tests remain active under `python3 -O`. They do not establish the analytic uniformity by sampling, prove infinite-tail bounds by truncation, or demonstrate monotonicity of the exact normalized ratio. Those claims are made only where justified by the report's analytic proofs.

## Background and source scope

The primary-source abstract and bibliographic metadata for Arratia and Tavaré's 1994 independent-process paper (author-posted in 2013, https://arxiv.org/abs/1308.3279) and Arratia and DeSalvo's 2016 low-rank assemblies paper (https://arxiv.org/abs/1606.04642v2) were inspected. This is not a full-text overlap review. The conditioning methods are classical, and no global novelty or complete phase-diagram claim is made.
