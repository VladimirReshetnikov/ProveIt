# Exact Odd-Order Cube Stability

**A complete defect decomposition, weighted extremizers, and parity obstructions**  
Research draft prepared for Vladimir Reshetnikov, October 7, 2026.

## Main result

For a finitely supported function `a : G -> [0,1]` of positive mass `n`, and a coset `C` of a finite odd-order subgroup, let

`delta = ||a - 1_C||_1 / n`,

and let `C3(a)` be the unnormalized additive three-cube count, including degenerate cubes. If `delta <= 1/50`, then

`1 - C3(a)/n^4 >= 4 delta - 10 delta^2 + 8 delta^3`.

For positive delta, equality holds exactly when `a` is the indicator of `C` minus one subgroup coset. This resolves the explicitly stated `conj:oddexact` in the predecessor Library manuscript `sharp_cube_stability.tex` in a quantitative neighborhood.

The proof is based on an exact identity, valid in every finite abelian group and for arbitrary `[0,1]` hole functions. It separates an explicit polynomial, a parity fourth moment, an additive-energy defect, and a nonnegative Boolean-certificate remainder. The paper also includes the optimal universal tail coefficient, weighted boundary estimates, global near-extremizer rounding, an inverse profile and near-equality rigidity.

## Files

- `odd_order_cube_stability.pdf`: 24-page research article.
- `odd_order_cube_stability.tex`: self-contained LaTeX source, with inline bibliography.
- `verification/verify.py`: standard-library exact verifier.
- `verification/results.json`: recorded complete verification run.
- `verification/local_checks.py`: independent small-distance and equality examples.
- `verification/local_results.json`: their recorded results.
- `certificates/boolean_patterns.json`: all 256 Boolean patterns and certificate values.
- `CLAIMS.md`: new-versus-prior theorem ledger and scope restrictions.
- `SOURCE_AUDIT.md`: source provenance, retrieval limitations, and novelty-search scope.
- `INTEGRATION.md`: proposed research-only integration path and formalization boundary.
- `build.sh`: clean PDF rebuild and verification commands.
- `SHA256SUMS`: integrity hashes for the package files, excluding this manifest itself.

## Build and run

A normal TeX Live installation with `pdflatex`, AMS packages, Latin Modern, geometry, microtype, hyperref, listings and fancyhdr is sufficient. No BibTeX run is required. Verification requires Python 3.10 or later and only the standard library.

```sh
./build.sh
```

Or run the exact checks without building the article:

```sh
python3 verification/verify.py
python3 verification/local_checks.py
```

The optional `--quick` flag on `verify.py` omits some larger exhaustive groups and weighted examples. A quick run is not the full 21,518-subset run and will replace `results.json` with the smaller report.

## Verification status

The included full run passed all 256 pattern tests, all 70 four-subset determinant checks, the five-subset incidence checks, and all 21,518 subsets across 18 finite abelian groups. Twelve rational-weight examples independently evaluated the cube count, inclusion-exclusion tail and Bernstein remainder. A separate script checked four small-distance weighted examples and independently counted the exact equality example in `Z/51Z`. Polynomial identities and the inverse-series coefficients were checked with exact arithmetic.

These are **finite exact checks, not a theorem-prover certification**. The general proofs are in the article. No Lean/Rocq files, unproved theorem stubs, or claimed kernel checks are included.

## Research and provenance status

This is an AI-assisted, unrefereed research draft. The predecessor's stated conjecture is resolved by the supplied proof; broader historical priority for the stronger identities has not been established by an exhaustive literature search. The article expressly credits antecedent set-boundary, energy-rounding, and exact coset-deletion results.

The reviewed OpenAI arithmetic-progression preprint is motivational, not a proof dependency. The paper does not claim improved global Szemeredi bounds. ProveIt directory listings and commit reads did not establish one consistent immutable source snapshot; the predecessor is anchored to the independently read user Library artifact. See `SOURCE_AUDIT.md`.

No repository modifications or pull requests were made. No third-party source papers or font files are redistributed in this package.
