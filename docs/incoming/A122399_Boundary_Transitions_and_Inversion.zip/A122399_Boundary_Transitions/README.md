# From Gaussian Blocks to Poisson Defects

**Boundary transseries, local limit laws, and inverse thresholds for the rectangular family of OEIS A122399.**

Research manuscript prepared for Vladimir Reshetnikov, 4 October 2026.
Author: ChatGPT. Unrefereed; not Lean- or Rocq-formalized.

## Main result

The array is

    A[m,n] = sum(k^n k! Stirling2(m,k), k=1..m).

Its diagonal is OEIS A122399. For a uniformly selected ordered partition of an m-element red set together with a map from an n-element blue set to the red blocks, let K be its block count and D=m-K its defect.

The article proves an exact independent-Bernoulli representation, finite Poisson/count bounds, an all-direction Gaussian–Poisson–degenerate trichotomy, and a complete critical-window expansion at n=m(log(m)+c). In that window,

    D -> Poisson(exp(-c)/2),
    A[m,n]/(m! m^n) -> exp(exp(-c)/2).

Every fixed expansion order has a uniform proved remainder. A rational coefficient algorithm produces explicit corrections. The article also proves uniform local Edgeworth expansions whenever the exact variance diverges, and inverts the critical expansion for a prescribed probability of the all-singleton partition.

The prior ProveIt report treated fixed positive directions and explicitly excluded boundary-uniform and local-limit claims. These are extensions of that inspected report; exhaustive worldwide priority is not established. Classical interlacing and Poisson approximation are attributed, not claimed as new methods.

## Contents

- `article.pdf`: compiled research article, including proofs, tables, six further research questions, and bibliography.
- `article.tex`: editable LaTeX source; uses the two supplied `data/*_table.tex` fragments.
- `SOURCE_AUDIT.md`: repository pin, source links, dependency and novelty limitations.
- `code/coefficients.py`: exact rational all-order coefficient generator (default: order 4).
- `code/verify.py`: independent exact Stirling, polynomial, root-count, moment-bound, and inverse checks.
- `code/numerics.py`: finite-sum numerical diagnostics for counts, laws, and inverse roots.
- `code/certify_threshold.py`: standard-library-only exact proof that N_(1/e)(1000)=6207.
- `data/`: generated coefficients, CSV diagnostics, tables, and verification/certificate JSON files.
- `requirements.txt`, `Makefile`: regeneration and build configuration.
- `MANIFEST.sha256`: checksums for delivered files other than the manifest itself.

## Reproduce

Python 3.10 or later and a TeX Live installation with `newtx`, `microtype`, `mathtools`, `amsthm`, `booktabs`, `geometry`, `hyperref`, `cleveref`, `enumitem`, `fancyhdr`, and `float` are sufficient.

```sh
python -m pip install -r requirements.txt
python code/coefficients.py --order 4
python code/verify.py
python code/numerics.py --dps 80
python code/certify_threshold.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, `make reproduce` runs the computations and builds the PDF. No network access is required after installing dependencies. The computations overwrite their corresponding generated files. `python code/numerics.py --dps 120` repeats the numerical diagnostics at higher precision; preserve the 80-digit output before comparing. `--max-m 200` permits a faster partial numerical run, but does not regenerate the full delivered tables.

The coefficient generator accepts orders 0 through 8, with rapidly increasing symbolic cost. The formulas in the article specify arbitrary fixed orders; the implementation's upper limit is a practical guard, not a mathematical restriction. Orders other than 4 overwrite coefficient files but do not change the hard-coded order-4 numerical test workflow.

## Executed checks

All passed:

- 85 exact coefficient identities and 50 exact root counts with simplicity checks.
- 272 exact rational moment-bound instances and the first 15 OEIS values.
- Exact cancellation of the two printed inverse correction orders.
- 18 critical-window, 12 inverse, and 6 diagonal local-law numerical cases.
- All 432 stored diagnostic fields compared at 80 and 120 decimal digits agree at their 14-significant-digit output precision. Precision-dependent root residuals are excluded from this comparison.
- Exact integer comparisons with rational upper/lower bounds for e prove N_(1/e)(1000)=6207 independently of the floating-point inverse solver.

## Scope and limitations

Finite checks supplement the mathematical proofs and do not verify their infinite quantifiers. The 80/120-digit calculations are not interval certificates. Only the separate threshold certificate uses exact arithmetic to establish the displayed integer threshold. Other inverse roots and threshold columns in the numerical CSV are diagnostics, not certified finite-input enclosures.

“All orders” means every fixed power-logarithmic order with a proved remainder, not convergence, Borel summability, an exponentially complete transseries, or a Stokes analysis. Exact Bernoulli factorization is proved for integer n; the real-exponent continuation used for inversion is justified without assuming real-rootedness. The explicit diagonal constants are inherited from the earlier ProveIt report; the principal finite and boundary theorems are self-contained.

No external repository or OEIS entry was changed or submitted to. Independent mathematical review remains appropriate before publication or reliance on a global novelty claim.
