FIRST PATTERN FAILURE BEYOND 132
Exact enumeration, critical condensation, and a logarithmic transition window
An extension of OEIS A273821
5 October 2026

START HERE

Read article.pdf. The complete editable source is article.tex. The bibliography
is embedded in that source, and both figure PDFs needed to compile it are in
figures/. A TeX rebuild therefore needs no Python or network access.

The article studies permutations avoiding 123 and the largest restriction to
their largest values that avoids tau_r = 1(r+1)r...2. It resolves the first
proposed research question in Section 13 of the ProveIt report cited below
for every fixed integer r >= 2: exact first-failure enumeration, its generating
function, and its weighted limiting behavior. The safe simultaneous-avoidance
enumeration is classical; the r = 2 first-failure formula and beta law are
already in the source report and are explicitly credited there and here.

The principal additional results are a uniform two-index coefficient estimate;
critical deficit laws with sharp total-variation convergence and all positive
moment regimes; a logarithmically displaced two-phase coexistence window with
conditional limits; locally controlled complex zeros; and an iterated
long-pattern limit with an explicit Wasserstein bound. The article contains
full proofs, a worked r = 3 example, and ten concrete research directions.

CONTENTS

  article.tex              Complete LaTeX source and bibliography.
  article.pdf              Compiled research article.
  README.txt               This guide.
  requirements.txt         Tested plotting/numerical dependencies.
  provenance.json          Source snapshot, links, scope, and environment.
  code/
    verify_first_failure.py  Literal permutation checks, insertion-state DP,
                             finite coefficient formulas, safe-state checks,
                             and formal-series specializations.
    audit_limit_laws.py     Additional exact moment and limit-law checks.
    make_figures.py         Exact r = 3 counting rows, numerical diagnostics,
                             figures, and high-precision approximate zeros.
  figures/
    critical_deficit.pdf    Publication figure used by article.tex.
    coexistence_window.pdf  Publication figure used by article.tex.
    *.png                  Raster previews of the same figures.
  data/
    verification_summary.json     Core verification results and scope.
    limit_law_audit.json           Additional rational/numerical audit results.
    exact_small_tables.csv        First-failure triangles for small inputs.
    numerical_summary.json        Counting checks and figure/zero diagnostics.
    critical_moments.csv           Exact-count-based finite-size moments.
    critical_deficit_pmf.csv       Finite and limiting deficit probabilities.
    coexistence_probabilities.csv  Finite and limiting phase probabilities.
    complex_zero_diagnostics.csv   Approximate roots and numerical residuals.
    verification_run.txt          Output of the packaged verification run.
    numerical_run.txt             Output of the packaged figure run.
    latex_build.txt               Successful final LaTeX build output.
    delivery_checks.json          Final compilation and packaging checks.

REPRODUCING THE PDF

From the directory containing article.tex, run:

  latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

The tested distribution was TeX Live 2023/Debian, pdfTeX 1.40.25, with latexmk
4.83. Standard packages used include amsmath, amsthm, mathtools, geometry,
lmodern, microtype, booktabs, enumitem, graphicx, fancyhdr, needspace, hyperref,
xurl, and cleveref. All bibliography entries are included in article.tex;
BibTeX, shell escape, and an external bibliography database are unnecessary.

If latexmk is unavailable, run pdflatex repeatedly until the cross-reference
warnings disappear (normally three passes from a fresh directory):

  pdflatex -interaction=nonstopmode -halt-on-error article.tex

REPRODUCING THE COMPUTATIONS

The standard-library verification needs Python 3.10 or later and no third-party
packages. Tested interpreter: Python 3.12.14. Run:

  python3 code/verify_first_failure.py

This also invokes audit_limit_laws.py. Default results are written to data/.
Its --outdir option accepts another output-data directory. The standalone
audit_limit_laws.py also defaults to data/ when run directly.

For the figures, install the packages in requirements.txt if necessary:

  python3 -m pip install -r requirements.txt
  python3 code/make_figures.py

Installing dependencies may require network access; the computations themselves
do not. The figure script defaults to this package's root, writes CSV and JSON
to data/, and writes figures to figures/. Its --outdir option selects an
alternative package root, under which it creates data/ and figures/. The option
--maximum controls the largest computed size (default 4000). The option
--skip-zeros omits the optional high-precision root diagnostics.

Rerun latexmk after regenerating the figure PDFs. Regeneration updates files in
place; elapsed times and PDF metadata can differ across machines even when all
mathematical outputs agree. No Monte Carlo or random input is used.

EXECUTED VERIFICATION

Literal enumeration inspected every permutation of sizes 1 through 9: 409,113
permutations, of which 6,917 avoid 123. The first-failure statistic was checked
for r = 2,...,6. Independent insertion-state dynamic programming reached n = 40;
safe-state, support, recurrence, diagonal, and Catalan checks reached n = 120.
Rational normalizations and first two limiting moments were checked for
r = 2,...,60. The plotting code computed nine exact r = 3 rows through n = 4000,
made 7,990,003 integer recurrence updates, verified all nine Catalan row sums,
and independently checked 166 coefficients against the finite binomial sum.
The packaged scripts were rerun successfully with their final output paths.

The root-finding diagnostics use 55 decimal digits and report small residuals.
They are numerical approximations, not interval-certified enclosures. Plotting
normalizes integer counts numerically. In particular, the coexistence curves
converge slowly at the displayed sizes; the article reports that discrepancy.
The proofs of the asymptotic theorems do not depend on these finite checks.

PROVENANCE AND CLAIM BOUNDARIES

Selected source repository:
  https://github.com/VladimirReshetnikov/ProveIt
Pinned commit:
  0f93381e8932d3aee3d5c2abfb5c98d128d49b9c
Selected file:
  SetTheory/Cardinals/docs/reports/enumerative-combinatorics/
  a273821-first-pattern-failure/article.tex
Relevant source question:
  Section 13, first proposed research question, on patterns 1(r+1)r...2.

The article distinguishes the source report's r = 2 results, the classical
Chow-West safe counts, and the longer-pattern refinement established here.
The source audit is restricted to the stated snapshot and inspected reports.
The literature search does not certify worldwide priority.

This is an AI-assisted research manuscript with conventional mathematical
proofs and two independent AI proof audits. It has not undergone external
peer review or proof-assistant formalization. All asymptotic results keep r
fixed unless the iterated long-pattern limit is explicitly stated. No joint
r = r(n) theorem, global ordering of polynomial zeros, or resolution of the
source's distinct r = 2 zero question is claimed.

The exact count formula can be reused independently of the analytic section.
For a formalization project, the article gives a concrete sequence of targets
starting with the combinatorial meaning of the coefficients. It also lists
ten further research questions with their unresolved scope stated explicitly.
