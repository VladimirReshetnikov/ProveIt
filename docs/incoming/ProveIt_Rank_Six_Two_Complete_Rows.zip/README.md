# Rank Six Cores with Two Complete Rows

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October 2026.

Read **article.pdf** for the theorem and proof. The LaTeX source is **article.tex**.

## Scope

The graph has matching rank six and a displayed three-plus-three minimum cover. Two core rows are complete; the third has any degree from zero through three. Exterior neighborhoods are arbitrary. All left activities are one, and right activities are positive real numbers.

For each fixed graph and field, sufficiently large common scaling of the three right-core activities makes every rank-six Newton gap strictly positive. The new proofs address exceptional-row degrees zero and one; degrees two and three use the previously established matching-hole and complete-core results cited in the article. The threshold is field-dependent and computable.

This does not establish rank-six ULC for arbitrary finite activities, nor does it automatically cover transposed column defects. The certificate is exact rational algebra, not a formal proof-assistant verification.

## Reproduce the checks

Python 3 with the standard library suffices:

```sh
python3 code/verify_degree_one_certificate.py
python3 code/check_flag_algebra.py
python3 code/check_degree_one_counts.py
python3 code/check_zero_row_counts.py
```

The scripts raise an explicit exception on failure and write a JSON summary beside the script. The reference summaries are in **data/**. No numerical optimizer is required.

The first script reconstructs all 25 neighborhood-pair identities from the rational data. Its 1,112 nonnegative terms have a strict remainder of one. The flag checker independently multiplies the Hessian and mixed-flag identities and the grouped zero-row comparisons. The two support checkers count endpoint supports directly on 100 deterministic small graphs each; 66 degree-one examples are coloop-free and check all 19 flag constraints.

## Build the PDF

A standard LaTeX installation with the packages listed at the top of **article.tex** can compile the source with two pdflatex passes. **build_local.sh** additionally supplies the TeX paths used in the preparation environment. It writes intermediate files to **build/**.

**SHA256SUMS** covers every shipped file except itself. Run `sha256sum -c SHA256SUMS` from this directory to verify integrity.
