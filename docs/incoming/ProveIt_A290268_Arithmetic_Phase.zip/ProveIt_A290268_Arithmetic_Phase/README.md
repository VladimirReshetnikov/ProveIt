# Arithmetic nonvanishing and central phase laws for A290268

`article.pdf` is the self-contained 10-page research report. `article.tex` and its three included TeX fragments are the complete manuscript source.

The report proves:

- A finite-field block reduction of the coefficient model, with at most two residual terms
- Infinite prime-unit families at unbounded depth and logarithmic degree, together with exact valuations of the original derivative coefficients
- Nonvanishing at logarithmic degree zero throughout the stated all-depth central strips
- Eventual nonvanishing at every fixed logarithmic degree and every fixed displacement from the symmetry line
- An exact counterexample to a proposed argument using only the locations and parities of the two factors' roots

The full noncancellation conjecture remains open. The phase result is eventual for each fixed pair of parameters; it gives neither a uniform growing-parameter theorem nor a numerical depth threshold. The larger evaluation-parameter assertion discussed in Section 7 is explicitly unproved.

## Reproduction

Use Python 3 with SymPy installed (`requirements.txt`). From this directory run:

```sh
python3 verify_prime_blocks.py
python3 verify_k0.py
python3 verify_geometry.py
```

These check five symbolic prime-length identities, 874 exact prime-family and valuation cases, 300 full polynomial-jet block identities, the 258 finite cases closing the central-strip argument, 1791 logarithm-free prime-block cases, and the exact geometric obstruction. The reported algebraic and analytic proofs establish the infinite statements; these finite checks supplement those proofs.

`test_stronger_parameter.py` is an optional exact diagnostic scan of an unproved stronger lemma. Its 813120-cell outcome is recorded in `stronger_parameter_scan.json`; it is not used in any theorem.

The JSON certificates and text run records preserve the checked outcomes. No floating-point calculation is used in these exact verifiers.

## Typesetting

On a standard TeX Live installation, compile `article.tex` twice with pdfLaTeX. `build_local.sh` is the wrapper used to generate the included PDF in the research environment. The final PDF was visually checked on every page.

## Source and scope

The source comparison is pinned to ProveIt commit `ca81647a9f679e96d49ffdbc54b0c0ab13d10a36`, in the report `power-tower-derivative-term-counts`. The bibliography credits the classical congruence mechanism, Meixner–Pollaczek normalization, falling-factorial identities, and the local limit theorem used in the phase proof. The results and verification scripts received independent mathematical checks during preparation. They have not been formalized in Lean or externally refereed, and no exhaustive priority claim is made.

