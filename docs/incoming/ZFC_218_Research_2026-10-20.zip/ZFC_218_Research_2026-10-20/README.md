# Research toward a 218-state ZFC consistency machine

**Status: the requested bound has not been achieved.** This packet does not
contain a verified machine with 218 or fewer working states. It contains two
new **219-state** variants, new equiconsistency arguments, and reproducible
optimization experiments. It is suitable as a research contribution, not
as an announcement of a new state-count record.

The reference is the ProveIt K219 release at commit
`26d5de6d21fa354d50e0b84fe851c289925b8d72`. `PROVENANCE.json` records the
exact archive, source, and table hashes. The original release ZIP is included
unchanged, including its recursively pinned predecessors. No network access
is needed for the machine replay.

## Contents

* `report/report.pdf` and its `.tex` sources: mathematical arguments,
  verification boundaries, measurements, and open obligations.
* `machine/no_push_copy/` and `machine/no_push_cache/`: native sparse-label
  transition tables, complete source-site lists, and canonical tables with
  working states 0 through 218 and halting label 219.
* `portable/`: deterministic constructors, independent complete blank-start
  checking, and the unbounded primitive runtime verifier.
* `receipts/`: fresh symbolic runtime results for both new tables and the
  inherited K219 replay.
* `research/theory/`: detailed calculus and proof-command arguments, finite
  algebra checks, and explicitly scoped countermodels.
* `research/theory_late/`: the conditional multiple-designated-value
  supplement, its TeX include, and independent mathematical audit.
* `research/encoding/`: source encodings, compiler experiments, pinned
  support modules, and search receipts.
* `research/machine/`: finite whole-operation mutation screens and their
  precise scope.
* `research/machine_late/`: the completed 435-pair combined-operation search
  involving native states 301 or 302, superseding its earlier partial log.
* `research/root/`: additional source reassociation experiments and saved
  checkpoints.
* `research/machine_preflight/`: the final small structural check of the
  newly published K219 alternatives and explicitly bounded follow-up screens.
* `MANIFEST.json`: file sizes and SHA-256 hashes of all other packet files.

## What is proved for the new tables

Both new tables have 219 working states and 438 explicit binary transition
rows. They use one tape, two symbols, left/right moves, start state 0, and an
initially all-zero tape. A halt target is excluded from the working-state
count. Only native row `(164,1)` differs from the inherited K219 table.

The exact tables pass a fresh symbolic proof of every guarded primitive
interface, with independent arbitrary natural register values, arbitrary
natural extra header gap, and arbitrary finite spare lists. Copy return has
6,142 cases and cache return has 6,137 cases. Both reach the same complete
initialized frame after exactly 312,617 blank-tape transitions. Independent
sparse and dense simulators check every nonzero cell and the zero exterior.

The written command-block argument proves completeness for the revised MP
return conventions; it composes with the inherited native-calculus/ZFC
calibration and the exact machine interfaces. This supplies an ordinary
mathematical proof, formalizable in ZFC, of the stated consistency
equivalence for each new 219-state table. **No new Lean or Rocq kernel
endpoint is claimed.** The Python checker implements mathematical induction
checks; it is not a proof-assistant kernel.

The new negative-equality and dual-quantifier calculi have written
equiconsistency proofs. Their exploratory source/compiler measurements do
not certify smaller machines. Finite mutation screens reject candidates
within specified search families; they do not establish a lower bound on
all 218-state machines.

A late conditional semantic supplement extends the repository's
three-input `U=R(A,B)` fresh-label argument to multiple designated values.
Its assumptions and proof are explicit. The required consistency-to-model
step remains open; this supplement is not an equiconsistency result.

## Reproduce the concrete constructions

Use Python 3 with assertions enabled. Run from the extracted packet root and
choose a new output directory **outside** the packet:

```sh
python3 -B portable/reproduce.py --output-dir ../zfc219_replay
```

The default freshly reconstructs and canonicalizes both variants and
rederives both unbounded primitive runtime proofs. It integrity-checks the
inherited runtime receipts through the predecessor's quick replay. Runtime
is machine-dependent; symbolic proof construction can take several minutes.

For a faster check that reconstructs the tables and reruns both complete
blank initializations, but audits the packaged symbolic receipts instead
of rederiving them:

```sh
python3 -B portable/reproduce.py --quick --output-dir ../zfc219_quick
```

To rederive the recursively inherited runtime proofs too:

```sh
python3 -B portable/reproduce.py --full-baseline --output-dir ../zfc219_all
```

Inspect `replay.json` and the phase logs in the chosen directory. A stored
receipt integrity audit is deliberately distinguished from a fresh proof.
These commands reproduce the **219-state variants**, not a 218-state result.
They do not mechanically check the prose equiconsistency proofs.

## Rebuild the report

The report uses standard LaTeX packages. From `report/`, run:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

Search commands and their different requirements are documented inside the
corresponding `research/` directories. Run exploratory scripts in a scratch
copy, since some create generated files beside their inputs. Published
tables, runtime receipts, and the baseline ZIP should remain immutable.
