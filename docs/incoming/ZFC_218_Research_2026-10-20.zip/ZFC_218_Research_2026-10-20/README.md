# Toward 218 states: verified research, target not met

**This archive does not contain a verified blank-start machine with 218 or fewer working states whose nonhalting is equivalent in ZFC to Con(ZFC).** Do not incorporate it as a successful K218 construction or a new Busy Beaver bound.

It contains a complete alternative **219-state blank-start construction**, a fully checked **218-state initialized-tape core**, an exact proof that this core's blank startup fails, and mathematical and computational results intended to support the next reduction.

## Main results

| Artifact | Working states | Transition rows | Result |
|---|---:|---:|---|
| `machine/alternative219/` | 219 | 438 | Complete blank-start construction; retains the inherited Con(ZFC) calibration |
| `machine/core218/` | 218 | 436 | All 6,167 arbitrary-natural primitive interfaces verified; requires a specified valid initial frame |
| The same core on blank tape | 218 | 436 | Enters an unconditional outward-writing loop at step 85; does not implement the required blank computation |
| Requested blank-start bound | ≤218 | — | **Not obtained** |

The terminal outcome is not counted as a working state. The machines have one two-way infinite tape, alphabet `{0,1}`, zero blank, and only left/right moves. Native numeric state labels are names, not counts.

The main report is **`report/report.pdf`**, with complete TeX source in `report/report.tex` and two included TeX files. It explains the construction, the exact failure, the new theorems, and the remaining obligation. The final appendix prints all 436 transitions of the canonical initialized core.

### The 218-state reduction

Starting with the pinned published K219 native table, delete state 301 and change only three retained rows:

| Row | Published action | New action |
|---|---|---|
| 87 / read 0 | `0 R 301` | `0 R 88` |
| 88 / read 0 | `0 R 122` | `0 L 51` |
| 51 / read 0 | `0 R 16` | `0 R 122` |

The decoder uses the preceding source bit to distinguish two logical roles. A complete source-prefix audit and the fresh symbolic runtime proof establish the initialized simulation for all natural register values, arbitrary permitted gap, and any nonempty finite spare list. The runtime proof uses 1,515,192 symbolic rule applications, covers every literal row, and has positive primitive durations.

The blank initializer violates the local precondition needed by the shared register helper. At step 85 it reaches native state 35, head 7, with one-cells exactly `{-3,-2}`. Since row `35/0` is `1 R 35`, induction proves an infinite outward ray. This failure is proved, rather than inferred from a bounded simulation.

### Additional mathematical results

- A general clean-seed theorem permits logical registers `[n,0,0,0,d,0,0,0,p]` for arbitrary natural `n,d,p`, with the stated complete frame representation.
- Successful padded refutation codes are cofinal in **every residue class modulo every fixed power of two**. This permits sound fixed-stride enumerators, including even-only and odd-only enumeration. It does not validate variable command-dependent counter increments.
- A fused quantifier schema is proved equivalent to instantiation plus explicit explosion over the retained implicational calculus. The altered quantifier calculus's consistency calibration is **not established**.
- A uniform finite-algebra obstruction excludes a broad fourth-parameter restriction of the native implicational axiom. A terminal-cluster theorem supplies a conditional semantic result, with its representation problem explicitly left open.
- The earlier G/H implicational basis certificate and formalism/encoding supplements are included.

## Reproduction

Use Python 3 with assertions enabled. The acceptance replay needs only the Python standard library and the bundled pinned archives; it makes no network requests.

From the archive's top directory:

```sh
python3 -B portable/reproduce.py --output-dir /tmp/zfc218-replay
```

The output directory must initially be empty. Default mode freshly rederives the 6,167 arbitrary-natural primitive interfaces for both the alternative219 and initialized218 machines, reconstructs their tables, replays the blank initialization/failure, audits the inherited baseline, and checks the logical certificates. Successful output is deliberately labeled:

```text
FULL_RESEARCH_REPLAY_PASS_TARGET_NOT_MET
```

`--quick` audits stored runtime certificates instead of regenerating those proofs. `--full-baseline` additionally rederives inherited runtime proofs. Neither mode is a new compiled proof-assistant endpoint: the result consists of ordinary mathematical arguments, executable induction certificates, and the inherited written logical calibration.

The delivered fresh run is recorded in `verification/fresh_release_replay.json`; its seven phases preceded the addition of the power-of-two certificate to the wrapper. The final quick replay records all eight current phases in `verification/final_quick_replay.json`, including that new certificate. Both passed. The proof inputs for the already completed fresh phases are unchanged.

The compact register-transport experiment is independently reproducible with Python 3 and a C++17 compiler:

```sh
python3 -B research/source218/transport_replay/reproduce.py \
  --output /tmp/zfc218-transport
```

All 28 tasks were replayed from the staged package: 3,386,880 literal initial configurations, with zero successful seeds and zero unresolved bounded traces. Each trace closes by an exact cycle modulo translation or an outward blank ray. This is a negative result for the specified finite family, not a lower bound for arbitrary machines or encodings.

Build the main PDF with `make -C report`, or run `pdflatex` twice in `report/`. The supplements have their own complete TeX sources. The final main PDF was rendered and visually inspected; its printed transition table was checked against the supplied machine file.

## Archive map

- `machine/`: exact native and canonical transition tables, source trees, label maps, initialized configuration, and blank-failure statement.
- `portable/`: offline reconstruction, symbolic runtime drivers, independent auditors, reference results, and the unchanged pinned K219 archive.
- `report/`: main research paper, source, and printed table.
- `research/theory218/`: new formalism appendix and certificates.
- `research/theory218_bootstrap/`: residue theorem, source-scheduler probes, and precise failed-entry examples.
- `research/theory_notes/`: earlier formalism and encoding supplements.
- `research/source218/`: alternative source-layout work, decoder proof, clean-seed theorem, and compact transport replay.
- `research/machine218/` and `research/root218/`: local synthesis, residue/projection evidence, comparator work, and failed startup repairs.
- `verification/`: fresh and quick replay receipts, independent audits, transport replay, and report QA.

`RESEARCH_INDEX.md` distinguishes standalone replay packages from development scripts. Some exploratory scripts retain worktree-relative imports; they are included as research aids and are not all claimed to run independently. Incomplete or timed-out searches are not treated as exhaustive negatives.

## Provenance

Pinned ProveIt commit: `26d5de6d21fa354d50e0b84fe851c289925b8d72`.

Bundled parent: `K219_Construction_2026-10-20.zip`, SHA-256:

```text
04813567f393b6c4015a96aba092159e9021703b4b662c7be69bd2a86497e31b
```

The source repository is <https://github.com/VladimirReshetnikov/ProveIt/tree/main/Computability/BusyBeaver/Research/ZFC>. `STATUS.json` gives the exact claim boundary and principal hashes; `MANIFEST.sha256` covers the delivered regular files except itself. The upstream license is retained in `LICENSE`.
