# Spectral Guards Without Time Expansion

**Canonical Diophantine certificates for exponentially long linear computation**  
Research manuscript prepared with ChatGPT for the ProveIt program, 2 October 2026.

Start with `article.pdf`; `article.tex` is its complete, self-contained LaTeX source.
No external bibliography file or image asset is required.

## Main results

For a fixed shape of integer polynomial-exponential sequences

    F(n) = sum_i P_i(n) b_i^n,    1 <= b_1 < ... < b_s,
    D = sum_i (declared degree of P_i + 1),

the article proves an exact endpoint-only verifier for canonical discrete sign
charts. The root-removing difference ladder uses exactly D^2+1 allocated chart
slots. A full chart has exactly one arithmetic witness when auxiliary values
are encoded canonically.

The fixed-shape exponential-arithmetic system uses O(D^4) gates and functional
power atoms, independently of the numerical horizon T. For an **externally
fixed** exponent bit bound B with T < 2^B, binary powering gives an ordinary
single-fold polynomial of degree at most four with O(D^4(B+1)) witnesses.
The article also proves an explicit permanent-sign threshold, affine-loop
macro applications, and a complex-spectrum obstruction for this sign-chart
format.

These are coordinate-count bounds, not bounds polynomial in the binary input
size. Exact endpoint values can have very large bit lengths. The ordinary
quartic family depends on the externally fixed B; it is not one fixed-arity
polynomial eliminating arbitrary exponentiation single-fold.

## Files

- `article.tex`, `article.pdf`: complete article, proofs, bibliography, research
  questions, implementation ledger, and reproduction instructions.
- `code/spectral_guards.py`: scalar sequences, exact difference ladder,
  binary-search chart generation, separate endpoint verification, first
  negative index, and elementary tail threshold.
- `code/quartic_compiler.py`: functional natural-coordinate gates, sparse
  quadratic residuals, power-atom and bounded-bit modes, and serialized
  assignment verification.
- `code/run_tests.py`: reproducible main test suite and example generation.
- `code/supplementary_checks.py`: 54 additional single-mode assignments,
  fractional-input rejection tests, and a second check of the bundled exports.
- `examples/*.json`: compact charts and, for the principal small example,
  complete equation/assignment exports in both modes.
- `validation/results.json`, `validation/test_output.txt`: executed main test
  record. Any supplementary check record is clearly labelled separately.
- `SOURCES.md`: inspected sources, repository pin, and limits of source audit.
- `Makefile`: build and test commands.
- `SHA256SUMS.txt`: hashes for the delivered files, excluding the hash list itself.

## Run

Python 3.10+ is required. All code uses only the Python standard library.
Run from this directory:

```sh
python3 code/run_tests.py
python3 code/supplementary_checks.py
```

The suite regenerates the main examples and test report. Do not run Python
with `-O`: the test suite intentionally uses assertions.

Build the PDF with a normal TeX installation (TeX Live or MiKTeX with the
packages imported in `article.tex`):

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

`make test` and `make pdf` provide the same commands on systems with Make.

## Minimal example

```python
import sys
sys.path.insert(0, "code")
from spectral_guards import Mode, Sequence, build_certificate
from spectral_guards import verify_certificate, first_negative
from quartic_compiler import compile_certificate, verify_export

f = Sequence((Mode(1, (16,)), Mode(2, (-10,)), Mode(4, (1,))))
certificate = build_certificate(f, 4)
assert verify_certificate(certificate)
assert first_negative(certificate) == 2
system = compile_certificate(certificate, bits=3)
assert not system.failed_residuals()
system.export("example_quartic.json")
assert verify_export("example_quartic.json")
```

A full sign-chart representation describes negative values too. To require
nonnegativity, pass `require_nonnegative=True`. The principal example must then
fail its polynomial constraints because its value at time two is negative.

Use `bits=None` for the quasi-Diophantine mode. Its nonempty `power_atoms` list
is part of the representation; its residual sum alone is not equivalent to
the intended relation. In the ordinary bounded-bit mode that list is empty.

## How to read an exported polynomial

A residual term `[c, [i1, ..., ik]]` represents the monomial
`c * values[i1] * ... * values[ik]`. An empty index list denotes a constant;
repeated indices denote repeated factors. All residuals have degree at most two.
The ordinary polynomial is **exactly the sum of their squares**, without
expanding the outer sum. Input coordinate indices are listed separately from
witness coordinates. Negative coefficients in equations are allowed, while
all coordinate values are natural numbers.

`verify_export` evaluates the equations actually present in an export. It is
not a proof that an arbitrarily modified equation list is the compiler's
correct output for a specified shape. The compiler proof in the article and
the fixed-shape syntax tests supply that separate connection. Use hashes to
detect accidental modification of the delivered examples.

## Validation and scope

The main completed run used seed 20261002 and checked 3,087 exhaustive chart
instances, 700 additional randomized chart instances, 8,097 ladder identities,
704 forged-chart rejections, 480 tail-sign samples, 12 compiled assignments,
3,134 witness-coordinate perturbations, two independently reevaluated serialized
exports, and 12 fixed-shape syntax comparisons. All passed. Finite tests are
not a proof of uniqueness or of an infinite tail; the article provides those
mathematical arguments.

The million-horizon compact example covers 1,000,001 integer times with nine
occupied blocks over the ladder. Construction used 75 exact sequence evaluations;
the largest constructed value had 1,000,602 bits. This is not a claim that the
entire arithmetic witness has a small binary encoding.

No automatic matrix/Jordan frontend, whole-program branching compiler,
separate global-threshold export frontend, or Lean formalization is supplied.
The scalar tail function is implemented; the global representation and affine
applications are proved in the article as composition theorems.

This is a research draft, not peer-reviewed or proof-assistant verified.
Historical priority has not been established. No resolution of general
Skolem/Positivity, finite-fold MRDP, or single-fold MRDP is claimed.
