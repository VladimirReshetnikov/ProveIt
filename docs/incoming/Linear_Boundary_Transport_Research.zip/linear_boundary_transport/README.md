# Linear Quasi-Diophantine Universality

**Unique Polynomial Certificates, Boundary Tests, and an Exact Convex Integrality Gap**  
Research report prepared for Vladimir Reshetnikov, 2 October 2026.

The 22-page article proves an explicit linear polynomial-certificate construction
for deterministic two-counter computation. The unknowns are polynomials of
unbounded finite support, with precisely specified omitted-coordinate sorts.
They are not a fixed finite tuple of ordinary integer Diophantine witnesses.

## Main results

For a program with q states and d test instructions, the compiler emits q+d
linear identities in q+2d polynomial unknowns. A clock makes the full witness
unique, and a solution exists exactly when the source computation halts.
Every solution coefficient is zero or one. The equivalence holds over every
nonzero commutative coefficient ring. Row tagging gives one scalar equation
without dropping the unknown-sort restrictions.

The corresponding sparse incidence operator A gives a strictly convex
finite-support energy E(h) = ||Ah - e_source||^2. On a nonhalting source its
integer minimum is exactly 1, but its rational and real infima are 0 and are
not attained. An explicit N+1-term taper has energy 1/(N+2). The Hilbert-space
extension has dense nonclosed range and exact basis-source membership detects
halting.

The article includes full proofs, a worked five-polynomial example, explicit
false-positive counterexamples to relaxed interfaces, a one-counter decidability
boundary, an integration plan for ProveIt, and twelve further research questions.

## Contents

- `article.tex` and `article.pdf`: self-contained source and rendered article.
- `code/boundary_transport.py`: exact sparse-polynomial compiler and checker.
- `code/verify.py`: reproducible exact tests and example generation.
- `examples/`: the complete transfer-counter example, witness, and tagged equation.
- `validation/test_results.json`: the executed test report and its limitations.
- `SOURCE_AUDIT.md`: pinned repository/source audit and comparison scope.
- `Makefile`: convenience targets for verification and PDF generation.

## Run the tests

From the package root:

```sh
python code/verify.py
```

The code uses only the Python standard library and requires Python 3.10 or newer.
It was executed with Python 3.13. The final run passed **32,502 exact checks**,
covering 169 exhaustive two-state programs, 3,042 simulation instances, 1,352
independent finite-box F_2 systems, modular rings with moduli 2, 3, 5, and 6,
rational taper identities, signed integer residuals, and malformed-input tests.
The script also regenerates the example files.

Runs not halting within the 32-transition test horizon are NOT classified as
divergent. The finite-box solver retains all output spill rows, including those
outside its candidate support box. The polynomial checker enforces the declared
subring sorts. Disabling either safeguard changes the problem and permits false
positives.

## Rebuild the PDF

With a TeX installation providing the packages listed in `article.tex`:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `make pdf`. All bibliography entries are embedded in the TeX
source; no BibTeX run or network access is needed. The distributed PDF was
rendered and visually inspected after compilation.

## Minimal API example

For an actual standalone example, put the following file next to
`code/boundary_transport.py`, or run it with `code` on `PYTHONPATH`:

```python
from boundary_transport import TRANSFER, compile_system, history

source = (0, 2, 0)
path, halted = TRANSFER.run(source, max_steps=20)
system = compile_system(TRANSFER, source)
witness = system.witness(history(TRANSFER, path))
assert halted and system.accepts(witness)
print(system.tagged_equation())
```

The `history` function constructs a candidate from a supplied path; the residual
checker, not a claimed runtime or an unchecked path annotation, establishes the
certificate identity.

## Status and limitations

These are written mathematical proofs with implementation tests, not a claimed
Lean formalization or an independent peer review. The compiler handles any valid
concrete finite program, but no numerical fixed universal interpreter table is
included. The fixed-universal-instance theorem uses established counter-machine
universality. Literature priority for the combined construction has not been
established, and general undecidability of constrained linear polynomial equations
predates this report.

The work does not claim an improvement to ProveIt's ordinary 87-operation
universal-polynomial bound, a solution to ordinary single-fold/finite-fold MRDP,
or an undecidability result for fixed finite-dimensional convex least squares.
The essential domains are unbounded finite polynomial support and exact
omitted-variable sorts.

Repository baseline:
`48ee077c7ab647d7121370e95a353169c89c79db`.
No repository changes or full repository build were performed.
