# Report276

## Threshold free quadratic density increments on cyclic groups

This package contains a self-contained mathematical article, editable TeX, and bounded exact Python diagnostics. The written proof establishes the theorem. The diagnostics check finite structural identities and regressions; they are not a numerical proof for all real parameters, Lean certification, or evidence of novelty.

## Main result

Let A have density δ in Z/NZ, N≥2. Suppose M nonempty disjoint proper modular progressions cover A, their lengths are pairwise within a factor of two, and degree at most two coefficient-polynomial phases have summed balanced correlation at least αN, with α>0. Then a nonempty proper modular progression Q satisfies

    |Q| ≥ max{1, (N/M)^(1/39)/17}
    |A ∩ Q| ≥ (δ + α/3)|Q|

No lower bound on α or N/M and no primality or least-prime-factor condition is imposed. The output progression need not lie in the cover. Proper means injectively parameterized; modular wrapping is allowed.

The proof includes:

- Uniform quadratic recurrence: for every real θ and integer R≥2, some 1≤p≤1024 R^5 has ||θp²||<1/R
- A full quadratic phase partition into cells of lengths L through 2L−1 with phase error <1/(4L), whenever n≥2^116 L^38
- An all-cyclic-moduli variance increment after accounting for nonproper directions
- Exact mass, ceiling, and positive-cell calculations joining the two regimes without an additional scale hypothesis
- A singleton-aware comparison proving that the effective length bound dominates (N/M)^(1/64)/8, and hence the entire pinned degree-two Corollary 5.8 conclusion with K=2048 and gain α/16

The R^4 witness constructed inside the recurrence contradiction does not establish an unconditional R^4 recurrence estimate. Every subsequent budget uses R^5. The recurrence and localization methods have classical precedents. No priority, optimality, higher-degree theorem, integer rectification, or global Ramsey/Szemerédi improvement is claimed.

## Files

The exact source allowlist is:

- README.md
- SOURCES.md
- article.tex
- build.py
- companion/exact_checks.py
- tests/test_build.py
- tests/test_companion.py

A packaged distribution adds Report276.pdf and MANIFEST.sha256. The ZIP contains exactly these nine files under Report276/. The manifest lists the eight public files other than itself. The archive's own SHA-256 digest is supplied alongside it, not embedded circularly inside it. No third-party paper, repository source, or private review material is bundled.

## Run the exact diagnostics

From this directory:

    python3 -B companion/exact_checks.py
    python3 -B companion/exact_checks.py --full
    python3 -B companion/exact_checks.py --nmax 6
    python3 -B tests/test_companion.py
    python3 -O -B tests/test_companion.py
    python3 -B tests/test_build.py
    python3 -O -B tests/test_build.py

The default exhaustive modulus cap is 8; --full raises it to 12 and extends fixed parameter samples. An explicit --nmax takes precedence, with the enforced range 2 through 12. Exhaustive A⊆U cover enumeration has its own cap of 9. The deterministic JSON output reports actual coverage and limitations.

Checks use integers and fractions, not floating-point complex exponentials. They include bounded subgroup-coset pair counts and all-direction variance, the proportion of bad directions, cover balanced-mass algebra, positive-cell extraction, lossless residue chunking, reduced affine midpoints, modular quadratic pullbacks, reduced curvature, formal quadratic-differencing residue histograms, and small rational recurrence examples. Exact budget checks verify the powers of two and L, the coefficient comparison 3·17^39>2^158, and root-free ceiling boundaries.

Default / --full coverage includes:

- 2,016 / 32,736 exhaustive all-step subset-length moment cases, with lengths at most 4
- 3,076 / 81,924 direct subgroup-coset pair cases
- 28 / 66 multiplication-kernel cases and 35 / 77 bad-direction length cases
- 9,837 / 29,520 cover pairs A⊆U
- 832 / 3,561 affine and 969 / 3,081 quadratic refinements, plus an exact-constant N=128 toy example
- 203 / 649 formal quadratic-differencing histograms
- 396 / 858 small rational recurrence samples
- 317 root-free ceiling boundary cases in both modes, and 5 / 10 selected larger variance cases

The theorem-sized n≥2^116 L^38 partition is not materialized. Small rational recurrence cases are explicitly finite samples; no numerical search certifies the assertion for all real θ. Argument caps and validation remain active under Python optimization. See the companion's function documentation and JSON for the precise finite scope.

Public helper caps are 512 for phase moduli, 64 for individual moment/coset moduli and formal differencing lengths, 4096 for budget parameters, and 1024 bits per integer in the root-free target-length ratio. The CLI accepts at most three arguments of at most 64 characters each. Invalid parameters raise runtime errors; internal diagnostic failures raise CheckFailure, also under -O.

## Rebuild and package offline

Requirements: Linux, Python 3.11 or later, /proc/self/fd, and a trusted system TeX installation containing /usr/bin/pdftex, /usr/bin/pdflatex, lmodern, amsmath, amssymb, amsthm, mathtools, geometry, microtype, enumitem, booktabs, xcolor, and hyperref. Python uses only its standard library. The build downloads nothing and performs no network access.

Check the exact source inventory or a manifest-pinned distribution:

    python3 -B build.py verify

Run normal and optimized diagnostics/tests, compile the article, and make the PDF and ZIP in a fresh external directory:

    python3 -B build.py reproduce --output /tmp/report276-rebuild

The output directory must be absent or empty, absolute, outside the source directory, and outside protected system locations. It must not be an ancestor of the source. Existing output files are never overwritten. The source inventory is checked before and after the operation.

Outputs include Report276.pdf, report276_quadratic_density.zip, the ZIP SHA-256 sidecar, MANIFEST.sha256, reproduction_receipt.json, and separate staging/log files. The ZIP excludes staging and logs. When starting from a manifest-pinned distribution, reproduce requires the rebuilt PDF to equal the pinned PDF bytes. Exact PDF reproduction depends on matching the TeX engine, packages, fonts, and compression toolchain; a mismatch is reported rather than silently accepted.

For a manifest-pinned distribution only, repackage existing checked bytes without compiling:

    python3 -B build.py package --output /tmp/report276-package

ZIP member names are sorted, timestamps and permissions fixed, and extra fields/comments empty. CRC, member bytes, and exact inventory are checked. Normal and optimized diagnostic stdout must agree; test-runner timing on stderr is not required to be byte-identical.

## Trust boundary

The builder is for supplied trusted source and installed trusted tools. It uses exact inventory allowlists, bounded reads, no-follow directory/file handles, single-link regular-file checks, exclusive output creation, a minimal child environment, subprocess time/output bounds, and disabled TeX shell escape. Its tests cover the documented inventory, packaging, and filesystem regressions.

These controls are not a security sandbox for arbitrary hostile TeX or Python, or a guarantee against an actively malicious concurrent filesystem owner. The compiler and installed TeX resources remain trusted. A manifest verifies bytes against a supplied digest list, not authorship or mathematical correctness.

## Provenance

SOURCES.md provides the exact repository commit and source fingerprints, primary literature links, and the scope of the comparison. No repository file or previous report is modified by this package.
