# Three Plus One
## Radical-Solvability Tests Without Separating Sextic Resolvents

Research article prepared for Vladimir Reshetnikov, September 29, 2026.

**Main theorem.** For an irreducible sextic over a characteristic-zero field,
radical solvability is equivalent to either the degree-10 triple resolvent
having a base-field root at one chosen parameter, or the degree-15 matching
resolvents having base-field roots at all three distinct chosen parameters.
The fixed rational tests are R3(1,Z), R2(1,Z), R2(2,Z), and R2(3,Z).

The proof permits collisions. For a nonsolvable sextic, any rational matching
fiber is the unique possible invariant pentad, has exactly five elements, and
has value (e2*t^2 + 3*e3*t - e4)/5. Such a false positive occurs at no more than
two base-field parameters. The triple resolvent is separable and has no
base-field root at every base-field parameter in the nonsolvable case.

**Status and limitations.** Complete written proofs, unrefereed, not formalized
in Lean or Rocq. Novelty is proposed relative to the inspected repository and
consulted sources; historical priority is not certified. We do not prove that
three tests are optimal or exhibit an actual nonsolvable false positive.
General radical-solvability decidability is classical. No repository files
were modified and no Lean/Rocq rebuild was performed.

## Contents

- `article.tex` and `article.pdf`: self-contained article, 22 pages, internal
  bibliography, proofs, coefficient-only matrix formulas, integration plan,
  ten research questions, and audit appendices.
- `code/sextic_resolvents.py`: exact coefficient-only evaluator and decision
  function. Its decision routine calls no Galois-group classifier.
- `code/verify.py`: symbolic identities, root-level cross-checks, and independent
  Galois-classifier comparisons. It uses the classifier only for verification.
- `data/verification.json` and `data/verification.log`: actual recorded outputs.
- `data/sources.json`: repository pin and consulted source provenance.
- `requirements.txt`, `build.sh`, `SHA256SUMS`: reproducibility support.

## Build the article

Run `./build.sh` from any directory. It requires `pdflatex`, newtx fonts, and
the standard TeX packages named in the preamble. No external figures, font
files, or separate bibliography database are required.

## Run the exact code

Use Python 3.10 or later; the recorded run used Python 3.13.5 and SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python code/sextic_resolvents.py 'x**6-3*x**2-1'
python code/sextic_resolvents.py 'x**6+x+1'
python code/verify.py
```

The first example returns solvable by the matching branch. The second returns
nonsolvable after its triple test and first matching test. The CLI expression
parser accepts trusted local expressions, not untrusted network input.

The decision function rejects reducible inputs and polynomials of degree other
than six. It accepts rational coefficients and makes the input monic. Its
interface requires nonzero test parameters for compatibility with the original
bivariate descriptor convention, although the mathematical compressed theorem
also permits zero.

## Verification record

The delivered run passed all checks:

- Enumeration of 15 matchings, 10 triple partitions, and 6 pentads; all 15
  pentad intersections and all 15 matching-membership counts.
- 45 symbolic shared-edge identities, 18 pentad-sum identities, 25 descriptor
  expansions, and 1 quartic resolvent identity.
- 30 exact matching-matrix identities and 30 exact triple-matrix identities
  against direct root products, using 10 rational root tuples. Six matching
  tests have repeated roots.
- 48 irreducible inputs: 16 standard sextic group-type seeds and two affine
  variants each. All results agree with the independent classifier.
- All API branches exercised: 22 triple-positive, 14 matching-positive, and
  12 negative; 6 invalid-input tests rejected as expected.

These are finite exact implementation checks, not machine-checked proofs of
the research theorems. None of the tested nonsolvable examples has a matching
false positive at parameters 1, 2, or 3. The independently invoked classifier
shares SymPy's arithmetic library with the prototype.

## Repository relation

Inspected ProveIt commit:
`e47ed8547bd021f9bd85bdcf767c94a2fcb41001`.

This develops the existing sextic radical-solvability project and the report
`SetTheory/Cardinals/docs/reports/galois-theory-and-radicals/sextic-block-resolvent-separators`.
It bypasses separation for the irreducible Boolean decision; it does not
improve or contradict the earlier 196-point simultaneous-separation bound.
The 45-dimensional matching and 20-dimensional triple matrix constructions
provide a coefficient-only alternative to searching for symmetric-expression
certificates. Integrating and formally verifying that route remains future work.
