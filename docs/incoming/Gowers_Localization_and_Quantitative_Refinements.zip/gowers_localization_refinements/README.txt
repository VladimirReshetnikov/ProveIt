LOCAL PHASE REMOVAL WITHOUT CARRY PATTERNS
and further quantitative refinements of Gowers' proof of Szemeredi's theorem

Research report prepared for Vladimir Reshetnikov
6 October 2026

ARTICLE
=======
Gowers_Localization_and_Quantitative_Refinements.pdf
Gowers_Localization_and_Quantitative_Refinements.tex

The 30-page article includes complete proofs of three families of local
refinements, sharpness results, source comparisons, a formalization plan,
and 14 further research questions. The TEX file contains the entire text
and bibliography; its only external article asset is the supplied vector
figure figures/localization_constants.pdf.

PRINCIPAL RESULTS
=================
1. A finite sliding-window argument for local phase removal replaces the
   displayed retention factor 2^(-2(k+1)^3) by
       (4 / (3(k+2)))^(k+2).
   The output remains an exact progression partition. The changed upper
   cell scale, at most 3km in the nontrivial branch, is explicit.
   The optimized fixed-k asymptotic coefficient is (2/(k+2))^(k+2).
   A local-scale upper obstruction of 2^(k+1)/(k+2)! establishes the
   optimal leading logarithmic loss k log k, with an exponential-in-k
   gap remaining in the constants.

2. A finite recurrence-certificate theorem constructs exact partitions
   controlling affine frequencies after multiplication by each cell's
   actual step. Combining this elementary theorem with the cited Lau
   recurrence theorem gives every balanced exponent
       gamma < 1 / ((q+1)(42q+1))
   for sufficiently large intervals, uniformly in the coefficients.
   The external threshold X_0(C,q) is not numerically explicit.
   A rigorous full-partition obstruction forces gamma <= 1/(3q+1).
   The article also proves anisotropic, composite-modulus transport,
   weighted selection, and effective slope-dimension variants.

3. Exact fourth-order cube coefficients in every dimension, and exact
   fifth-order coefficients over odd-order groups, include the necessary
   order-two and order-three torsion terms. The error power 4/2^d is
   optimal even for actual sets of exact density 1/3 in odd cyclic groups.

Additional results characterize formal multi-affine polarization by
factorial divisibility and classical functional polarization over F_p.

SCOPE
=====
These are local mathematical results supplied with proofs. Historical
priority of the formulations is not asserted. The report does not claim
a new global quantitative Szemeredi bound, a solution of a recognized
major open problem, a completed Lean formalization, or an exhaustive
literature review. The modern recurrence theorem is explicitly cited
as an external input. The repository's reported Lean status was read;
its build was not rerun. The source and numerical scope of every
comparison are explained in the article.

SOURCE SNAPSHOT
===============
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: dca9f06383ccdfc2ed208ccb7c9882214fdb09ac
Inspected paths:
  Combinatorics/Ramsey/Papers/sz-thm-gowers-proof
  Combinatorics/Ramsey/Lean/GowersSzemeredi

External inputs:
W. T. Gowers, A new proof of Szemeredi's theorem, GAFA 11 (2001), 465-588.
  https://doi.org/10.1007/s00039-001-0332-9
J. Maynard, Simultaneous small fractional parts of polynomials,
  GAFA 31 (2021), 150-179.
  https://doi.org/10.1007/s00039-021-00559-3
C. F. (Joshua) Lau, Simultaneously small fractional parts of polynomials,
  arXiv:2407.01611v1 (2024), Theorem 1.1 and Corollary 1.2.
  https://arxiv.org/abs/2407.01611v1

BUILD THE PDF
=============
Run from this directory, with a normal TeX Live installation:
  latexmk -pdf -interaction=nonstopmode -halt-on-error \
    Gowers_Localization_and_Quantitative_Refinements.tex

Alternatively, run pdflatex on the TEX file three times to resolve the
contents and cross-references. No BibTeX or network access is needed.
The supplied figure is already generated.

REPRODUCE THE FINITE CHECKS
==========================
Python 3 is required. The localization script uses NumPy; the other two
verification programs use only Python's standard library.

  python3 code/verify_localization.py > data/localization_results.json
  python3 code/verify_partitions.py --output data/partition_results.json
  python3 code/verify_cube_coefficients.py > data/cube_results.txt

Recorded results:
* Localization: 10,599 exact cube/basepoint coverage checks, cyclic
  partition checks, modular phase identities, and 32 exact interval cube
  counts. Three finite examples also check the analytic energy bound
  using complex floating-point arithmetic and documented tolerances.
* Partitions: exact rational certificates and complete coverage in a
  prime-modulus example (19,038 cells) and a composite-modulus example
  (9,990 cells), with every own-step inequality checked. A third example
  deliberately has no certificate at its finite size; its recorded
  status is expected and does not contradict the certificate theorem
  or the asymptotic existence theorem.
* Cubes: exact classification of four- and five-vertex supports in
  dimensions 2, 3, and 4, and exact rational coefficient checks in
  cyclic groups of orders 3, 5, 7, and 9.

The proofs establish the general claims; these finite checks challenge
signs, coefficients, normalization, coverage, and implementation.
They are not proof assistants or substitutes for the cited recurrence
input. Exact results are deterministic; floating-point output can vary
slightly across numerical-library versions.

FIGURE AND DATA
===============
  code/make_figures.py
  figures/localization_constants.pdf
  figures/localization_constants.png
  data/localization_constants.csv

The figure compares base-2 logarithmic losses for the source factor,
the new finite factor, the optimized asymptotic factor, and the local
upper obstruction. The CSV uses floating-point evaluations of the exact
formulas, for k = 1,...,20. It does not compare final Szemeredi bounds.

To regenerate the plot and CSV, install Matplotlib and run:
  python3 code/make_figures.py

ARCHIVE INTEGRITY
=================
SHA256SUMS.txt records the SHA-256 hashes of all other archive files.
The ZIP was tested for integrity after creation.
