# A two-element Lorentzian deformation of every matroid basis polynomial

## Main result

For every finite matroid with two distinct distinguished elements, the explicit homogeneous degree-(rank+2) polynomial in the paper is Lorentzian. Every original element variable remains separate. Three finite nonnegative weighted populations enter as parameters. Distinguished loops, parallel elements, a nonspanning old ground set, and nonrepresentable matroids are all allowed.

The ordinary proof uses principal extensions, matroid union, contraction, and a complete rank-zero-through-four Hessian calculation. It needs no finite certificate archive. Parallel copies remove the old-spanning hypothesis by a zero-variable specialization.

The graph specialization retains every selected-tail variable for a disjoint bipartite graph with a cover of two left vertices and q right vertices. Diagonal specialization has cover order q+2. Applying a minimum cover to the positive-activity graph gives actual-degree ultra-log-concavity for every independently vertex-weighted bipartite endpoint-support polynomial of surviving matching rank at most five. Endpoint supports are counted once regardless of the number of perfect matching witnesses.

Population activities stay parameters. The theorem does not assert joint Lorentzianity in those activities, physical tail/head collision merging in directed relations, general degree renormalization for a nonminimum cover, or the balanced 3+3 case at actual rank six. No real-rootedness or blanket strictness is asserted.

## Contents

- `article/two-element-matroid-lorentzian.pdf`: six-page self-contained paper
- `article/two-element-matroid-lorentzian.tex`: editable TeX source
- `proof-notes/`: the three unchanged approved proof stages
- `audits/`: mathematical approvals, including the extension to all matroids and the removal of the spanning assumption; final integrated review
- `reproducibility/producer/`: exact symbolic identities, rational Hessian inertia and support-exchange checks
- `reproducibility/represented/`: independent literal augmentation and contraction identities
- `reproducibility/abstract/`: independent principal-extension and matroid-union rank-oracle checks, including nonrepresentable examples
- `reproducibility/padding/`: independent parallel-copy and zero-specialization checks
- `qa/visual-qa.json`: final PDF hash and complete visual inspection record

The historical source notes retain proposed-status headers and earlier narrower scopes so that their approved bytes remain intact. The later stage approvals and final integrated approval supersede those historical status statements. Absolute paths in approval records identify the historical originals; the driver resolves packaged copies by exact hashes.

## Reproduce the checks

With Python 3.11 or newer and SymPy 1.14.0 installed, run:

    python verify.py

The driver checks exact manifest coverage, every approval pin, the PDF inspection hash, and all four checkers. It copies each checker to a temporary directory and compares every deterministic receipt field, excluding only elapsed timings. The package is never rewritten. The driver and checkers reject Python `-O`, since assertions are part of the exact verification. No network, numerical optimizer or earlier release archive is required.

Recorded corroboration:

- Producer: 60 represented matroids, 3,505 exact quadratic inertia checks, 94,442 support-exchange checks
- Independent represented case: 250 literal augmentation identities and 1,240 contractions
- Independent abstract case: 84 principal-line basis identities, 840 union-polynomial identities over 82,331 candidate bases, and 365 contractions
- Independent padding: 86 distinguished pairs, including 16 initially nonspanning old sets and six distinguished-loop occurrences

These finite checks are supplementary. No theorem is inferred from random search, and no population-size bound is a proof premise. No proof-assistant formalization, literature-wide priority claim, or external publication is asserted.

To rebuild the PDF with a normal TeX Live installation, run `sh build.sh`. Byte-identical recompilation is not promised because TeX metadata may vary. The supplied PDF is ready to read. Earlier research releases are unchanged.
