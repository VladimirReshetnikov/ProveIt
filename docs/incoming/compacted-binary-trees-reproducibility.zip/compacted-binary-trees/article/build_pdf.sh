#!/usr/bin/env bash
# Rebuild the exact supplied TeX. Package inputs remain unchanged.
set -euo pipefail
srcdir="$(cd "$(dirname "$0")" && pwd)"
if [[ -f "$srcdir/../SHA256SUMS" ]]; then
  outdir="$srcdir/../output/article"
else
  outdir="$srcdir"
fi
mkdir -p "$outdir/.build"
outdir="$(cd "$outdir" && pwd)"
builddir="$outdir/.build"
if ! command -v pdflatex >/dev/null || ! command -v kpsewhich >/dev/null; then
  printf 'A TeX distribution with pdfLaTeX is required.\n' >&2
  exit 1
fi
# Minimal TeX installations may lack generated formats or font maps. Build
# those locally, using only files from the installed TeX distribution.
if ! kpsewhich pdflatex.fmt >/dev/null 2>&1 || ! kpsewhich pdftex.map >/dev/null 2>&1; then
  export TEXMF="$(kpsewhich -var-value=TEXMF | sed 's/!!//g')"
  export TEXMFVAR="$builddir/texmf-var"
  export TEXMFCONFIG="$builddir/texmf-config"
  export TEXMFCACHE="$builddir/texmf-cache"
  export TEXFORMATS="$builddir:"
  if ! kpsewhich pdflatex.fmt >/dev/null 2>&1; then
    (cd "$builddir" && pdftex -ini -etex -interaction=nonstopmode -halt-on-error \
      -jobname=pdflatex -progname=pdflatex pdflatex.ini > format-build.log)
  fi
  if ! kpsewhich pdftex.map >/dev/null 2>&1; then
    : > "$builddir/pdftex.map"
    for name in lm.map cm.map cmextra.map symbols.map latxfont.map euler.map; do
      map="$(kpsewhich "$name")" || {
        printf 'Missing TeX font map: %s\n' "$name" >&2
        exit 1
      }
      cat "$map" >> "$builddir/pdftex.map"
    done
    export TEXFONTMAPS="$builddir:"
  fi
fi
cd "$builddir"
for pass in 1 2 3; do
  pdflatex -interaction=nonstopmode -halt-on-error -output-directory="$builddir" \
    "$srcdir/compacted-binary-trees.tex" > "compile-$pass.log"
done
cp "$builddir/compacted-binary-trees.pdf" "$outdir/compacted-binary-trees.pdf"
printf 'Built %s\n' "$outdir/compacted-binary-trees.pdf"
