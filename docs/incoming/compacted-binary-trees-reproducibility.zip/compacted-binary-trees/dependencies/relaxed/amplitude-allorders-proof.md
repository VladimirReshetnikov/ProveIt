# A082161: a spectral proof of the amplitude and full algebraic expansion

Draft completed 2 October 2026 for independent mathematical audit. This is a proposed proof, not a claim of an independently verified or published result. The argument below uses the already proved lower bound of Elvey Price–Fang–Wallner in exactly one place, to show that the limiting amplitude is nonzero. Everything else needed for the upgrade from their Θ theorem is proved here.

## 1. Statement, provenance, and scope

Let `a_n` be OEIS A082161, the number of relaxed binary trees with `n` internal nodes. Its defining triangular recurrence is

\[
r_{n,m}=r_{n,m-1}+(m+1)r_{n-1,m},\qquad
r_{n,0}=1,\quad r_{n,m}=0\ (m>n),\quad a_n=r_{n,n}.
\]

Let `z=a_1^{Ai}=-2.338107410459767…` be the largest real zero of `Ai`. (This Airy zero is denoted by `z` throughout, to avoid confusing it with the counting sequence.) Set

\[
a=2^{-1/3}z,\qquad F(x)=\operatorname{Ai}(z+2^{1/3}x).
\]

**Proposed theorem.** There is a constant `γ>0` such that, for each integer `M≥0`,

\[
a_n=\gamma n!4^n e^{3zn^{1/3}}n
\left(1+\sum_{k=1}^M c_kn^{-k/3}
+O_M(n^{-(M+1)/3})\right).
\tag{1}
\]

The coefficients belong to `Q[z]` and are determined by the polynomial–Airy recursion in §8. The first logarithmic coefficients are

\[
\log\frac{a_n}{\gamma n!4^n e^{3zn^{1/3}}n}
=\frac{53z^2}{90}n^{-1/3}
+\frac{44z}{27}n^{-2/3}
+\left(\frac{141}{140}-\frac{1304z^3}{42525}\right)n^{-1}
+O(n^{-4/3}).
\tag{2}
\]

Consequently

\[
\begin{aligned}
c_1&=53z^2/90,\\
c_2&=z(2809z^3+26400)/16200,\\
c_3&=(1042139z^6+28444320z^3+30836700)/30618000.
\end{aligned}
\tag{3}
\]

Numerically these are `3.2193061325653844`, `1.3717168742447035`, and `−5.306490818002809`. No rigorous numerical enclosure or elementary evaluation of `γ` is asserted.

The counting recurrence, the Θ estimate, and the conjectural limiting amplitude and all-orders shape are due to Andrew Elvey Price, Wenjie Fang, and Michael Wallner, [Compacted binary trees admit a stretched exponential](https://arxiv.org/pdf/1908.11181), especially Theorem 1.1 and §3.4. Their paper explicitly leaves existence of the amplitude open and reports the fit `166.95208957`. The proposed contribution here is a convergence/stability argument for the relaxed recurrence. It does not extend without further work to compacted trees, whose recurrence is different. It proves a Poincaré expansion to every finite algebraic order, not an exponentially improved transseries or a canonical interpolation between integers.

## 2. Exact recurrence and contractive symmetrization

Put

\[
d_{N,j}=\frac{r_{(N+j)/2,(N-j)/2}}{((N+j)/2)!}
\]

when `0≤j≤N` and `j≡N mod 2`, and zero otherwise. Direct substitution gives

\[
d_{0,j}=\mathbf 1_{j=0},\qquad d_{N,-1}=0,
\qquad
d_{N,j}=\frac{N-j+2}{N+j}d_{N-1,j-1}+d_{N-1,j+1}.
\tag{4}
\]

In particular `a_n=n!d_{2n,0}`. Values outside the admissible support are interpreted as zero.

For `N≥1`, define on `0≤j≤N+1`

\[
D_N(j)^2=\frac{\Gamma(N+2)\Gamma(N+1)}
{\Gamma(N-j+2)\Gamma(N+j+1)},\qquad D_N(0)=1,
\]

and `v_N(j)=d_{N,j}/D_N(j)`. All vectors are padded with zeros in `ℓ²(Z_{≥0})`. Define `S_N` to be the symmetric Jacobi matrix on `0,…,N+1`, padded by zero, with edge weights

\[
b_{N,j}=\sqrt{\frac{N-j+2}{N+j}},\quad 1\le j\le N+1,
\]

and define a diagonal contraction by

\[
Q_N(j)=\sqrt{1-\frac{j(j-1)}{N(N+1)}}
\quad(0\le j\le N+1),\qquad Q_N(j)=0\quad(j>N+1).
\]

The factorial identities

\[
\frac{D_N(j)}{D_N(j-1)}=b_{N,j},\qquad
\frac{D_{N-1}(j)}{D_N(j)}=Q_N(j)
\]

on the support where the second ratio is needed establish the exact identity

\[
v_N=S_NQ_Nv_{N-1}.
\tag{5}
\]

Both `b` and `Q` lie in `[0,1]`. If `J` denotes the half-line adjacency matrix, then `0≤S_NQ_N≤J` entrywise. If `λ_N` is the largest eigenvalue of `S_N`, then `‖S_NQ_N‖≤λ_N`. The finite Jacobi matrix is irreducible, so its top eigenvector `ψ_N` can be taken positive and of norm one. Its spectrum is symmetric about zero because it exchanges the two parity subspaces. In particular its operator norm is `λ_N`.

## 3. The coarse Airy limit and a uniform spectral gap

Write `ε=N^{-1/3}` and `x_j=(j+1)ε`. The quadratic form is exactly

\[
\begin{aligned}
\langle v,(2I-S_N)v\rangle={}&
\sum_{j=0}^{N}b_{N,j+1}|v_{j+1}-v_j|^2+|v_0|^2\\
&+\sum_{j=1}^{N}(2-b_{N,j}-b_{N,j+1})|v_j|^2
+(2-b_{N,N+1})|v_{N+1}|^2.
\end{aligned}
\tag{6}
\]

Here `|v_0|²` is the first Dirichlet-gradient interval, with fictitious value `v_{−1}=0`; no nonphysical edge coefficient `b_{N,0}` is introduced.

For `1≤j≤N+1`,

\[
1-b_{N,j}
=\frac{2(j-1)}{(N+j)(1+b_{N,j})}
\ge\frac{j-1}{N+j}.
\]

It follows from (6) that, for universal positive constants `c,C`,

\[
\varepsilon^{-2}\langle v,(2I-S_N)v\rangle
\ge c\sum_{j=0}^{N+1}x_j|v_j|^2-C\varepsilon\|v\|^2.
\tag{7}
\]

On each fixed `x` window the edge weights tend uniformly to one, and

\[
\varepsilon^{-2}(2-b_{N,j}-b_{N,j+1})\longrightarrow 2x_j
\]

uniformly there. Interpolate linearly with value `ε^{-1/2}v_j` at `x_j` and zero at zero. The gradient terms in (6) give local `H¹` bounds for any sequence with bounded scaled energy. Equation (7) gives uniformly small `L²` tails outside a large fixed window. Local compactness, followed by this tail bound, gives strong `L²` compactness. The boundary interval enforces the trace zero at zero. The resulting liminf form is

\[
\int_0^\infty (|f'(x)|^2+2x|f(x)|^2)\,dx.
\]

For completeness, convergence of norms in this interpolation follows first on a fixed window from the local gradient bound and the Riemann-sum identity, and then globally by (7). Sampling smooth compactly supported functions with zero boundary value gives the reverse, limsup bound. Applying the elementary min–max principle in both directions therefore gives convergence of each fixed low eigenvalue of `ε^{-2}(2I−S_N)` to that of

\[
\mathcal H=-\frac{d^2}{dx^2}+2x,
\qquad f(0)=0.
\]

The latter eigenvalues are `μ_k=−2^{2/3}z_k`, where `z_1=z>z_2>…` are the negative Airy zeros. Thus, if `λ_{2,N}` is the second-largest positive eigenvalue for large `N`,

\[
\lambda_N=2+2a\varepsilon^2+o(\varepsilon^2),\qquad
\lambda_N-\lambda_{2,N}
\sim 2^{2/3}(z-z_2)\varepsilon^2.
\tag{8}
\]

As a map between opposite parity subspaces, `S_N` has singular values equal to its positive eigenvalues (and possibly additional zeros). Hence, after deleting its top singular direction, its norm divided by `λ_N` is at most `1−cN^{-2/3}` for all sufficiently large `N`. This parity formulation is essential: the negative eigenvalue `−λ_N` is not a second slow direction within the occupied parity space.

## 4. A finite quasimode supplies all quantitative estimates needed initially

The Airy equation reads `F''=2(x+a)F`. Define

\[
\begin{aligned}
F_2(x)&=\frac{2(-a+2x)}{15}F(x)
+\frac{x(2a+x)}{15}F'(x),\\
F_3(x)&=\frac{F(x)-xF'(x)}{3},\\
f_N(x)&=F(x)+\varepsilon^2F_2(x)+\varepsilon^3F_3(x),\\
\widehat\lambda_N&=2+2a\varepsilon^2+3\varepsilon^3
+\frac{13a^2}{15}\varepsilon^4+\frac{5a}{3}\varepsilon^5.
\end{aligned}
\tag{9}
\]

Choose a fixed smooth cutoff `χ`, equal to one on `[0,1]` and zero on `[2,∞)`, and sample `χ(j/N^{1/2})f_N(x_j)`. Let `\widehat f_N` denote its `ℓ²` normalization. Changing or omitting the cutoff in local calculations produces an error smaller than every inverse power of `N`.

Here is an explicit way to check and bound the quasimode residual. At a sample point the two edge coefficients are

\[
b_-(x,\varepsilon)=\sqrt{\frac{1-x\varepsilon^2+3\varepsilon^3}
{1+x\varepsilon^2-\varepsilon^3}},\qquad
b_+(x,\varepsilon)=\sqrt{\frac{1-x\varepsilon^2+2\varepsilon^3}
{1+x\varepsilon^2}}.
\]

Expand `b_- f_N(x−ε)+b_+ f_N(x+ε)−\widehatλ_N f_N(x)` through degree five in `ε`, reducing every derivative using `F''=2(x+a)F`. Every coefficient vanishes. At the left boundary the omitted sample is zero because `F(0)=F_2(0)=F_3(0)=0`. On the support of the cutoff, `xε²=O(N^{-1/2})`; Taylor remainders are bounded by `Cε⁶` times a fixed polynomial in `x` multiplying Airy decay. All such polynomial–Airy envelopes are square-integrable. Derivatives of the cutoff contribute only `exp(−cN^{1/4})` times a power of `N`. Since the unnormalized sampled norm is asymptotic to `ε^{-1/2}‖F‖_{L²}`, this proves

\[
\|(S_N-\widehat\lambda_N)\widehat f_N\|=O(\varepsilon^6).
\tag{10}
\]

The Airy gap (8) identifies the nearby eigenvalue with `λ_N`; projecting the residual on the complement of `ψ_N` then gives

\[
\lambda_N=\widehat\lambda_N+O(\varepsilon^6),\qquad
\|\psi_N-\widehat f_N\|=O(\varepsilon^4).
\tag{11}
\]

The sign is fixed by the positive leading Airy profile. Several useful consequences follow without a separate quantitative localization theorem:

\[
\begin{aligned}
\|\psi_N-\psi_{N-1}\|&=O(N^{-1}),\\
\|(I-Q_N)\psi_N\|&=O(N^{-4/3}),\\
\psi_N(0)&=\sqrt2\,N^{-1/2}(1+O(N^{-1/3})).
\end{aligned}
\tag{12}
\]

For the first, the explicitly normalized samples in (9) have `ℓ²` derivative `O(N^{-1})` with respect to continuous `N`; the two approximation errors in (11) are smaller. For the second, use `1−√(1−t)≤t` for `0≤t≤1`, the finite polynomial moments of the sampled Airy profile, and (11). For the endpoint, the pointwise error is at most the `ℓ²` error, and

\[
I:=\int_0^\infty F(x)^2\,dx=2^{-1/3}\operatorname{Ai}'(z)^2,
\qquad \frac{F'(0)}{\sqrt I}=\sqrt2.
\]

A Riemann-sum estimate with an integrable derivative gives a relative `O(ε)` normalization error; the endpoint Taylor error is `O(ε²)` and the normalized quasimode error divided by the leading endpoint is `O(ε^{5/2})`. These identities therefore verify the quantitative endpoint estimate in (12). Standard Airy decay needed above follows, for example, directly from the decaying solution of the Airy ODE; only its polynomially weighted integrability and exponential tail are used.

## 5. Convergence of the scalar amplitude

Set

\[
P_N=\prod_{i=1}^N\lambda_i,\qquad
u_N=v_N/P_N,\qquad M_N=S_NQ_N/\lambda_N.
\]

Then `u_N=M_Nu_{N−1}`, `‖M_N‖≤1`, and `‖u_N‖≤1`. Let `E_p` be projection onto height parity `p`. The positive eigenvector has equal squared mass on the two parities: this follows by taking the scalar product of each half of `S_Nψ_N=λ_Nψ_N` with that half. Therefore

\[
g_N=\sqrt2 E_{N\bmod2}\psi_N,\qquad
h_N=\sqrt2 E_{(N-1)\bmod2}\psi_N
\]

are unit vectors, with `S_Nh_N=λ_Ng_N`. By (12),

\[
\|h_N-g_{N-1}\|=O(N^{-1}),\qquad
\|(I-Q_N)h_N\|+\|(I-Q_N)g_{N-1}\|=O(N^{-4/3}).
\tag{13}
\]

The second estimate for `g_{N−1}` uses the first estimate only for its approximation by explicit Airy samples, rather than the crude `O(N^{-1})` difference: direct use of (11) at `N−1` gives the stated `O(N^{-4/3})` estimate with `Q_N`. It also follows by observing that `Q_N≥Q_{N−1}` pointwise on the old support and treating its negligible eigenvector tail.

Decompose

\[
u_N=A_Ng_N+w_N,\qquad w_N\perp g_N.
\]

Write `Π_N=I−|g_N⟩⟨g_N|` on the occupied parity subspace. The singular gap from §3 gives, for every vector `y` on the preceding parity,

\[
\|\Pi_NM_Ny\|
\le (1-cN^{-2/3})\|Q_Ny\|
\le (1-cN^{-2/3})\|y\|.
\tag{14}
\]

Indeed `Π_NS_N=S_N(I−|h_N⟩⟨h_N|)` on that parity; this projection removes the top singular direction, regardless of whether `y` is perpendicular to `h_N`. Also, (13) implies

\[
\|M_Ng_{N-1}-g_N\|=O(N^{-1}).
\]

Applying (14) to `w_{N−1}` and the latter estimate to the scalar term yields

\[
\|w_N\|\le (1-cN^{-2/3})\|w_{N-1}\|+CN^{-1}.
\tag{15}
\]

Iteration gives `‖w_N‖=O(N^{-1/3})`. One general estimate used here and later is

\[
\sum_{k=N_0}^N k^{-r}
\prod_{i=k+1}^N(1-ci^{-2/3})=O_r(N^{2/3-r}).
\tag{16}
\]

To prove it, split at `N/2`. The earlier half is exponentially small in `N^{1/3}` times a polynomial; on the later half bound the product by `exp(−c'(N−k)N^{-2/3})` and sum a geometric series. A finite initial segment makes no difference.

The scalar equation is

\[
A_N=t_NA_{N-1}+\langle k_N,w_{N-1}\rangle,
\quad
t_N=\langle Q_Nh_N,g_{N-1}\rangle,
\quad k_N=Q_Nh_N-g_{N-1}.
\tag{17}
\]

The unit-vector identity `⟨h,g⟩=1−‖h−g‖²/2` and (13) show

\[
t_N=1+O(N^{-4/3}),\qquad \|k_N\|=O(N^{-1}).
\tag{18}
\]

Since `|A_N|≤1`, (15), (17), and (18) give

\[
A_N-A_{N-1}=O(N^{-4/3}).
\]

Thus

\[
A_N=A_\infty+O(N^{-1/3}).
\tag{19}
\]

Positivity gives `A_N≥0` and hence `A_∞≥0`; strict positivity is established in §7.

## 6. A boundary smoothing estimate

Norm tracking alone cannot read a coordinate whose leading size is `N^{-1/2}`. A short final block of the original positive kernel provides the missing smoothing.

Let `U(N,k)=M_N⋯M_{k+1}`. For `0≤ℓ≤N^{2/3}`, positivity and `S_iQ_i≤J` give

\[
\|e_0^TU(N,N-\ell)\|_2
\le\frac{\|e_0^TJ^\ell\|_2}
{\lambda_{N-\ell+1}\cdots\lambda_N}.
\]

The squared numerator is the number of nonnegative walks of length `2ℓ` returning to zero:

\[
\|e_0^TJ^\ell\|_2^2=(J^{2\ell})_{0,0}
=\frac{1}{\ell+1}{2\ell\choose\ell}
\le C4^\ell(\ell+1)^{-3/2}.
\]

Equation (11) implies

\[
\frac{2^\ell}{\lambda_{N-\ell+1}\cdots\lambda_N}
\le\exp(C\ell N^{-2/3})\le C'
\]

over the same range. Therefore

\[
\|e_0^TU(N,N-\ell)\|_2\le C(\ell+1)^{-3/4}.
\tag{20}
\]

The exact error recurrence for `w_N` is

\[
w_N=M_Nw_{N-1}+f_N^{\rm err},\qquad
f_N^{\rm err}=A_{N-1}M_Ng_{N-1}-A_Ng_N,
\quad \|f_N^{\rm err}\|=O(N^{-1}).
\]

Use Duhamel over `L=⌊N^{2/3}⌋` steps. Since all times in this block are comparable with `N`, (15) and (20) imply

\[
\begin{aligned}
|w_N(0)|
&\le CL^{-3/4}\|w_{N-L}\|
+CN^{-1}\sum_{\ell=0}^{L-1}(\ell+1)^{-3/4}\\
&=O(N^{-5/6}).
\end{aligned}
\tag{21}
\]

For even `N`, (12) gives `g_N(0)=2N^{-1/2}(1+O(N^{-1/3}))`.

## 7. The limiting constant and its strict positivity

From (11),

\[
\log\lambda_N=\log2+aN^{-2/3}+\frac32N^{-1}+O(N^{-4/3}).
\]

Summation gives

\[
P_N=\kappa\,2^N e^{3aN^{1/3}}N^{3/2}(1+O(N^{-1/3})),
\qquad \kappa>0.
\tag{22}
\]

If desired, a convergent expression is

\[
\log\kappa=a\zeta(2/3)+\tfrac32\gamma_E
+\sum_{N=1}^\infty\left[
\log(\lambda_N/2)-aN^{-2/3}-\frac{3}{2N}\right].
\tag{23}
\]

Here `γ_E` is Euler's constant, not the counting amplitude. This is an existence formula; it does not by itself give efficient certified numerical evaluation.

Equations (19)–(22), for even `N`, now give

\[
d_{N,0}=2\kappa A_\infty\,2^N e^{3aN^{1/3}}N
+O\left(2^N e^{3aN^{1/3}}N^{2/3}\right).
\tag{24}
\]

The known lower half of the Elvey Price–Fang–Wallner Θ theorem states that `d_{2n,0}` is bounded below by a positive constant times `4^n e^{3zn^{1/3}}n` for all sufficiently large `n`. If `A_∞=0`, (24) contradicts that bound. Hence `A_∞>0` and

\[
\gamma=4\kappa A_\infty>0.
\tag{25}
\]

Taking `N=2n` in (24) proves (1) with `M=0`. This is the complete amplitude-convergence argument, subject only to the explicit prior lower-bound theorem and the elementary Airy facts used above.

## 8. Arbitrary-order formal profiles exist by a triangular polynomial recursion

Work now with the original recurrence (4), rather than the symmetric gauge. Seek

\[
Z_{N,j}=H_N\sum_{k=0}^K\varepsilon^kG_k(x_j),\qquad
G_0=F,\quad G_k(0)=G_k'(0)=0\ (k\ge1),
\]

with

\[
\frac{H_N}{H_{N-1}}
\sim2\left(1+\sum_{m\ge2}s_m\varepsilon^m\right).
\tag{26}
\]

At the previous time the two arguments and powers are

\[
y_\pm=(x\pm\varepsilon)(1-\varepsilon^3)^{-1/3},
\qquad
\varepsilon_{N-1}^k=\varepsilon^k(1-\varepsilon^3)^{-k/3},
\]

and the downward coefficient is

\[
\frac{1-x\varepsilon^2+3\varepsilon^3}
{1+x\varepsilon^2-\varepsilon^3}.
\]

After the leading orders, the coefficient at degree `m` has the form

\[
\mathcal LG_{m-2}-2s_mF+R_m(x)F+S_m(x)F',
\quad
\mathcal L=\frac{d^2}{dx^2}-2(x+a),
\tag{27}
\]

where `R_m,S_m` are known polynomials over `Q[a]`, formed from earlier orders. In particular `s_2=a`. This form follows by Taylor expansion: the new profile first appears through the second-order spatial operator; its lower, zeroth-order terms cancel between the two sides of (4). Time-change terms involving this new profile enter only at later degree.

To solve `\mathcal L(PF+QF')=RF+SF'`, compute

\[
\mathcal L(PF+QF')
=(P''+4(x+a)Q'+2Q)F+(2P'+Q'')F'.
\]

Eliminating `P'=(S−Q'')/2` reduces the problem to

\[
-\tfrac12 Q'''+4(x+a)Q'+2Q=R-\tfrac12S'.
\tag{28}
\]

On polynomials of degree at most `d`, the operator on the left is upper triangular by degree with nonzero diagonal entries `4j+2`, `0≤j≤d`; hence it is invertible. The new scalar `s_m` adds `2s_m` to the forcing `R`, thus adds exactly `s_m` to the constant term of `Q`. Choose it uniquely to enforce `Q(0)=0`, which is the boundary condition. Integrating `P'` leaves one free constant; choose it so `P(0)+Q'(0)=0`, which enforces the derivative normalization. This proves existence and uniqueness at every formal order within the stated normalization, not merely consistency of finitely many guessed coefficients.

The first scalar coefficients are

\[
s_2=a,\quad s_3=\frac43,\quad s_4=\frac{29a^2}{270},\quad
s_5=-\frac{23a}{81},\quad
s_6=\frac{74385-8783a^3}{85050}.
\tag{29}
\]

For example,

\[
G_1=-\tfrac23x^2F,\quad
G_2=\frac{2(2a+15x^4+111x)}{135}F
+\frac{x(-8a+51x)}{270}F'.
\]

The amplitude factor can be chosen as a genuine smooth function of `N` with finite logarithmic expansion

\[
\log H_N=N\log2+3aN^{1/3}+\frac43\log N
+\sum_{k=1}^J h_kN^{-k/3}.
\tag{30}
\]

Expanding its exact one-step ratio matches any prescribed finite number of coefficients in (26). At degree `ε^{k+3}`, the new `h_k` has coefficient `−k/3`, so the construction is again triangular and nonsingular. Crucially the leading multiplicative constant in (30) is fixed to one for every truncation. This avoids an artificial truncation-dependent amplitude.

## 9. Formal profiles become approximate solutions in the required norm

Fix any `p>1`. Take enough orders in §8, multiply the sampled profile by the cutoff `χ(j/N^{1/2})`, and restrict to the occupied parity. Call the result `Z_N`. Choose the truncation so that its local formal residual starts at a power `N^{-p'}` with `p'≥p`. Define

\[
z_N=D_N^{-1}Z_N/P_N.
\]

Then

\[
\|z_N\|=O(1),\qquad
r_N:=z_N-M_Nz_{N-1}=O(N^{-p})\quad\hbox{in }\ell^2.
\tag{31}
\]

Here are the needed global bounds. On `j≤2N^{1/2}`, the product formula for `D_N` gives `D_N^{-1}≤C` uniformly: `−log D_N(j)≤Cj²/N≤C'`. On any fixed scaled window `D_N^{-1}=1+O(N^{-1/3}(1+x)^2)`. Taylor remainders in the rational coefficients and the time dilation are bounded by `N^{-p}` times a fixed polynomial–Airy envelope on the cutoff support. Cutoff errors decay like `exp(−cN^{1/4})` times a polynomial, also after multiplication by `D_N^{-1}`. Finally,

\[
H_N/P_N\sim\kappa^{-1}N^{-1/6},
\]

while a parity-restricted sampled profile has norm asymptotic to `N^{1/6}\sqrt{I/2}`. These bounds prove (31) by direct summation. The same reasoning proves

\[
\langle g_N,z_N\rangle\longrightarrow
q_0:=\kappa^{-1}\sqrt{I/2}>0.
\tag{32}
\]

Indeed, after the natural sample normalization, both profiles converge to the same positive Airy function. Neither (31) nor (32) needs a pointwise estimate on the unknown solution.

## 10. A zero-limit projection bootstrap proves all finite orders

Set

\[
C=A_\infty/q_0,\qquad e_N=u_N-Cz_N.
\]

Then `e_N=M_Ne_{N−1}−Cr_N` and the ground projection tends to zero. Decompose

\[
e_N=\alpha_Ng_N+W_N,\qquad W_N\perp g_N,
\qquad \alpha_N\longrightarrow0.
\]

The exact same estimates (14), (17), and (18) now give

\[
\begin{aligned}
\|W_N\|&\le(1-cN^{-2/3})\|W_{N-1}\|
+CN^{-1}|\alpha_{N-1}|+CN^{-p},\\
|\alpha_N-\alpha_{N-1}|&\le
CN^{-4/3}|\alpha_{N-1}|+CN^{-1}\|W_{N-1}\|+CN^{-p}.
\end{aligned}
\tag{33}
\]

Suppose initially that `α_N=O(N^{-q})`, where `q≥0`. Formula (16) gives

\[
\|W_N\|=O(N^{-q-1/3}+N^{2/3-p}).
\]

Substitute this into the second inequality of (33). Its right-hand side is summable because `p>1`; summing from `N+1` to infinity and using the zero limiting projection gives

\[
|\alpha_N|=O(N^{-q-1/3}+N^{1-p}).
\tag{34}
\]

The smaller tail `O(N^{2/3-p})` has been absorbed by `O(N^{1-p})`. Start with `q=0`, which holds since `u_N,z_N` are bounded. Finitely many repetitions of (34) reach

\[
\alpha_N=O(N^{1-p}),\qquad
\|W_N\|=O(N^{2/3-p}),\qquad
\|e_N\|=O(N^{1-p}).
\tag{35}
\]

There is no boundary-at-infinity assumption beyond the already proved, explicit limit (32) and the choice of `C`. No inverse operator with a small gap is silently assumed uniformly bounded.

Apply Duhamel directly to the inhomogeneous `e` recurrence on the final block `L=⌊N^{2/3}⌋`. By (20), (31), and (35),

\[
\begin{aligned}
|e_N(0)|&\le CL^{-3/4}N^{1-p}
+CN^{-p}\sum_{\ell=0}^{L-1}(\ell+1)^{-3/4}\\
&=O(N^{1/2-p})+O(N^{1/6-p})
=O(N^{1/2-p}).
\end{aligned}
\tag{36}
\]

The main endpoint is of size `N^{-1/2}`, so the relative endpoint error is `O(N^{1-p})`. Since `p` can be taken as large as desired, every prescribed finite algebraic order of the explicit approximation transfers to the exact sequence. All truncations have the same `q_0`, hence the same `C` and the same `γ=2CF'(0)=4κA_∞`. This proves (1).

## 11. Coefficient extraction and computational checks

Solving the scalar ratio matching (30) using (29) gives

\[
h_1=53a^2/45,\qquad h_2=79a/27,\qquad
h_3=143/210-5216a^3/42525.
\]

The normalized endpoint profile is

\[
\frac{\sum_k\varepsilon^kG_k(\varepsilon)}{F'(0)\varepsilon}
=1+\frac a3\varepsilon^2+\frac43\varepsilon^3+O(\varepsilon^4).
\]

Consequently the logarithmic endpoint corrections in time `N` are

\[
\frac{53a^2}{45}N^{-1/3}
+\frac{88a}{27}N^{-2/3}
+\left(\frac{141}{70}-\frac{5216a^3}{42525}\right)N^{-1}.
\]

Substituting `N=2n` and `a=2^{-1/3}z` yields (2), and exponentiation gives (3).

Existing local checks supporting the algebra, but not substituting for the analytic proof, are:

- `root-checks/check_quasimode.py`: independent symbolic cancellation of the frozen residual through `ε⁵` and exact left-boundary cancellation
- `../oeis-screening-next-wave/formal_airy.py`: nonautonomous polynomial profiles through `s_6`
- `../oeis-screening-next-wave/spectral_airy.py`: frozen polynomial profiles and eigenvalue coefficients
- `../oeis-screening-next-wave/extract_coefficients.py`: endpoint/logarithm conversion, rerun successfully on 2 October 2026
- `../oeis-screening-next-wave/spectral-check.json`: numerical gap, eigenvalue, shape, and endpoint checks
- `../oeis-screening-next-wave/forward-check.json`: normalized exact-recurrence evidence

The reported three-correction estimate at `n=20000`, about `166.95063854245`, is consistent with the published fitted value; neither is a certified enclosure. The exact asymptotic constant in the theorem is defined by (23), (25), and the convergent scalar projection, not by a numerical fit.

## 12. Audit checklist

The nontrivial places warranting independent scrutiny are now isolated:

1. The compactness/min–max passage in §3, including the varying finite interval and the first Dirichlet interval
2. The finite Taylor residual and its weighted `ℓ²` remainder in §4
3. The parity-singular projection inequality (14); using the ordinary second spectral radius instead would be wrong
4. The endpoint row estimate (20) and its use on changing finite supports
5. The arbitrary-order residual bound (31), especially the bounded gauge on the chosen cutoff
6. The direction of the zero-limit tail summation in (34)
7. The fixed leading normalization of `H_N`, which ensures a common amplitude at all orders

The proof does not require an unproved all-orders eigenvector expansion, an unproved positive asymptotic amplitude, or a heuristic interchange of an infinite formal series with a limit.
