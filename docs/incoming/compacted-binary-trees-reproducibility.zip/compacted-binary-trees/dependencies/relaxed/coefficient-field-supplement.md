# Why the all-orders coefficients lie in Q[z]

Supplement to the pinned `amplitude-allorders-proof.md`, prepared 2 October 2026. This is a formal-algebra lemma for independent audit. It is not a change to the pinned analytic proof.

The recursion immediately puts every coefficient at time `N` in `Q[a]`, where `a=2^(-1/3)z`. The substitution `N=2n` initially gives the weaker field `Q(2^(1/3))[z]`. To justify the stronger field `Q[z]` asserted in the proposed theorem, one needs the following mod-3 grading.

Let `phi_a` be the formal power-series solution of

\[
\phi_a''=2(x+a)\phi_a,\qquad \phi_a(0)=0,\quad\phi_a'(0)=1.
\]

Every coefficient of `phi_a` belongs to `Q[a]`. At the special Airy parameter used in the proof, this is exactly `F(x)/F'(0)`. For any primitive cube root of unity `omega`, uniqueness of the initial-value solution gives

\[
\phi_{\omega a}(\omega x)=\omega\phi_a(x),\qquad
\phi'_{\omega a}(\omega x)=\phi'_a(x).
\tag{1}
\]

Indeed, the left side of the first identity, as a function of `x`, obeys the same ODE as `phi_a` because `omega^3=1`, and its derivative at zero is `omega`.

Divide every formal profile in §8 of the main proof by `F'(0)` and denote the resulting formal sum by

\[
\Phi(a,\varepsilon,x)=\sum_{k\ge0}\varepsilon^k\mathcal G_k(a,x),
\qquad \mathcal G_0=\phi_a.
\]

Its normalization is `Phi(a,epsilon,0)=0` and `partial_x Phi(a,epsilon,0)=1`. Denote the half-ratio of the amplitude factors by

\[
R(a,\varepsilon)=1+\sum_{m\ge2}s_m(a)\varepsilon^m.
\]

In the formal recurrence, the rational coefficient depends only on `x epsilon^2` and `epsilon^3`; the dilation depends only on `epsilon^3`; and the shifted arguments are `(x±epsilon)(1−epsilon^3)^(-1/3)`. Consequently the transformation

\[
(a,\varepsilon,x)\longmapsto(\omega a,\omega\varepsilon,\omega x)
\]

preserves the recurrence. The transformed profile

\[
\widetilde\Phi(a,\varepsilon,x)
=\omega^{-1}\Phi(\omega a,\omega\varepsilon,\omega x)
\]

has the same leading solution and the same boundary and derivative normalizations, by (1). The order-by-order polynomial recursion in §8 is unique under exactly these normalizations. Therefore

\[
R(\omega a,\omega\varepsilon)=R(a,\varepsilon),\qquad
\Phi(\omega a,\omega\varepsilon,\omega x)
=\omega\Phi(a,\varepsilon,x).
\tag{2}
\]

In particular,

\[
s_m(\omega a)=\omega^{-m}s_m(a).
\tag{3}
\]

The uniquely determined coefficients `h_k(a)` of the finite logarithmic amplitude satisfy the same grading,

\[
h_k(\omega a)=\omega^{-k}h_k(a).
\tag{4}
\]

One way to see (4) without manipulating a logarithm branch is to use its ratio equation. The leading ratio contributions involve `3a/epsilon`, multiplied by a series in `epsilon^3`, and `log(1−epsilon^3)`. They are invariant under the transformation. The term involving `h_k epsilon^k` first enters at degree `k+3` with nonzero coefficient `−k/3`, so the unique recursive solution must have the indicated grading.

The normalized endpoint factor is

\[
E(a,\varepsilon)=\frac{\Phi(a,\varepsilon,\varepsilon)}{\varepsilon}.
\]

Equation (2) shows `E(omega a,omega epsilon)=E(a,epsilon)`. The constant term of `E` is one. Thus every coefficient of both `E` and `log E` has the same mod-3 grading. Combining it with (4), the time-`N` logarithmic and relative correction coefficients `b_k(a)` obey

\[
b_k(\omega a)=\omega^{-k}b_k(a).
\tag{5}
\]

Since `b_k` is a polynomial with rational coefficients, every nonzero monomial `a^r` in it satisfies

\[
r+k\equiv0\pmod3.
\]

Finally its contribution after changing variables is

\[
a^rN^{-k/3}
=2^{-(r+k)/3}z^r n^{-k/3}.
\]

The exponent `(r+k)/3` is an integer, so the factor of two is rational. This proves that every forward correction coefficient at time `n` lies in `Q[z]`, rather than merely in `Q(2^(1/3))[z]`.

This argument concerns formal coefficients only. It neither strengthens nor substitutes for the analytic stability proof that transfers those coefficients to the exact sequence.
