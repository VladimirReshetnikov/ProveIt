# Compacted binary trees amplitude and complete algebraic expansion

The article proves a positive asymptotic amplitude and a Poincare expansion to every finite algebraic order for compacted binary trees, mathematical sequence c_n indexed by n internal nodes (OEIS A254789). It also provides exact positive counting models, asymptotic inversion with discrete rounding safeguards, and a refined comparison with relaxed binary trees.

This is independently checked mathematical research, not a claim of publication or peer review. The prior paper's numerical amplitude 173.12670485 is an uncertified fit. No rigorous decimal enclosure, transseries, canonical continuous interpolation or exhaustive priority claim is made.

## Files

- article/: LaTeX source, PDF and portable build script
- source-proofs/: pinned analytic and algebraic sources, exact positive models, primary-source provenance
- audits/: independent analytic, inverse and final integrated transcription audits
- dependencies/relaxed/: exact approved companion proof and its independent audit; the article also supplies a self-contained appendix for the Jacobi estimates it uses
- checks/: exact arithmetic, two independent symbolic coefficient derivations, shared-Jacobi and delayed-operator diagnostics, inversion checks and exact-term forward evidence
- fixtures/: recorded reference outputs; numeric entries are evidence rather than certified error bounds
- SHA256SUMS: manifest for every immutable input
- output/: replay and final verification receipts, excluded from the input manifest

The development proof retains the filename amplitude-allorders-candidate.md to preserve its approved SHA-256. Its final revision is explicitly approved in the corresponding audit. This historical filename does not override the final audit.

## Reproduce

Use Python 3 with SymPy, mpmath, NumPy and SciPy installed. The scripts do not install packages or access the network.

Run:

    python replay.py

This first verifies all manifest-bound inputs, runs the exact/symbolic/numerical checks in an isolated output subdirectory, compares the independently derived coefficients symbolically, checks the exact finite-state reference output, and verifies that no input changed.

To verify only the manifest:

    python replay.py --manifest-only

To rebuild the PDF with an existing TeX installation:

    bash article/build_pdf.sh

The article build writes only under output/article/. Its PDF can be compared with article/compacted-binary-trees.pdf. The release was checked in a clean extracted package; its supplied and rebuilt PDF have identical extracted text and rendered page images.

The exact finite-state tests cover all 5,151 cells through n=100 and 709,506 directly enumerated prefixes through n=7. Exact integer counts are evaluated through n=2500. Those checks and finite formal cancellation are not substitutes for the analytic stability proof.

## Source and scope

The baseline recurrence, H-decorated-path interpretation, theta asymptotics and numerical amplitude fit are due to Andrew Elvey Price, Wenjie Fang and Michael Wallner, Compacted binary trees admit a stretched exponential, https://arxiv.org/pdf/1908.11181. A bounded review of later primary literature and read-only ProveIt code search found no amplitude resolution; this is not an exhaustive novelty certificate.

The theorem is an all-finite-orders expansion. Effective numerical amplitude bounds and finite-threshold certificates require additional work. Near integer boundaries the inverse is stated as two-ceiling brackets, not as an unconditional rounding formula.
