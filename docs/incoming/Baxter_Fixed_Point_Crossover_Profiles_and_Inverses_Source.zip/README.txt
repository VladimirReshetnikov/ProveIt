REPORT 151: SPARSE FIXED-POINT CROSSOVER
Reproducible source package, 3 October 2026

Meaning and scope
-----------------
This report refines the corrected all-length structural decomposition of
alternating Baxter involutions. x marks half the original even length and q
marks PAIRS of fixed points. Odd ascent-first objects have 2K+1 fixed points;
their pair statistic K is counted by the reverse-first even class.

The main theorem is an all-fixed-orders expansion uniform on each fixed
complex compact weight window. Interior inverse expansions require model
roots bounded away from zero. A separate even-parity boundary proposition
treats the exact limiting-threshold targets. This is not a boundary-uniform
inverse theorem. At the limiting reverse threshold, every sufficiently large
odd m has no nonnegative exact root. Odd E has exactly the zero root at its
zero threshold. The original odd-E zero-weight probability law is undefined;
its stated continuous extension is delta_1.

The analytic uniform remainder proof is in Report151.pdf/tex. Exact finite
checks and high-precision numerical diagnostics are NOT a proof of those
bounds, novelty, or any stronger growing-window/growing-order assertion.

Contents (strict build allowlist)
--------------------------------
Report151.tex                    Main report source
Report151.pdf                    Newly compiled main report
foundation/Report149.tex         Unchanged structural foundation
foundation/Report149.pdf         Unchanged structural foundation
companion.py                    Fresh exact and numerical implementation
test_companion.py               Exact, numerical, and build-safety checks
build.py                        Deterministic no-clobber PDF/ZIP builder
README.txt                      This file
requirements.txt                Pinned numerical dependency

No earlier companion, private research notes, or audit working files are
imported or included. The two Report149 files are the only foundation files.

Requirements
------------
Python 3.10 or newer. Exact arithmetic uses only the standard library.
Numerical diagnostics and their tests use mpmath 1.3.0. Install it in your
chosen Python environment if needed:

    python -m pip install -r requirements.txt

The PDF build additionally requires a POSIX filesystem with hard links,
O_NOFOLLOW and O_DIRECTORY, and TeX Live with pdftex/pdflatex and the report's
packages (including lmodern, AMS packages, mathtools, geometry, booktabs,
microtype, and hyperref). This builder uses the standard Debian/Ubuntu TeX
trees /usr/share/texlive/texmf-dist and /usr/share/texmf. Reproducing PDF bytes
requires the same TeX distribution, fonts, and package versions. Builds use
no network and do not install or update software.

Tests and exact calculations
----------------------------
From this source directory:

    python -m unittest -v test_companion
    python -O -m unittest -v test_companion
    python companion.py exact --m 12
    python companion.py profiles --order 4
    python companion.py diagnostics --dps 80

The same substantive tests run with and without -O. Checks use unittest
methods and explicit exceptions, not stripped Python assert statements.
The test suite:
  * Compares independent triangular recurrence and fixed-k coefficient
    formulas through half-length 32, with parity sums and finite support
  * Independently enumerates involutions through original length 9 and
    checks the alternating inequalities and Baxter forbidden patterns
  * Checks nonnegative coefficients, exact degrees, positive linear terms,
    gamma/Bernoulli coefficients, finite-product identities and majorants
  * Checks all printed P/Q tables, B operator polynomials, and Catalan
    coefficients, with polynomial evaluations outside interpolation nodes
  * Checks rational-factor exact finite thresholds and exact formal boundary
    reversion coefficients in Q[t,S], S=sqrt(2pi), t=m^(-1/2)
  * Runs finite high-precision complex crossover, inverse, boundary and
    endpoint diagnostics, including the odd-R obstruction
  * Rejects nonfinite numerical inputs, unsafe source/output paths, source
    symlinks/FIFOs, and existing outputs, including dangling symlinks
  * Checks deterministic ZIP ordering/metadata and no-clobber publication

The test suite's PDF build is mocked: the independent real two-build check
below is needed to check actual TeX/PDF byte reproducibility. Numerical
tolerances are finite regression checks, not analytic error certificates.
companion.py diagnostics writes JSON to standard output and changes no files.

Public companion interfaces
---------------------------
recurrence_polynomials(m): integer coefficient tuples E[0..m],R[0..m]
closed_coefficient(class,m,k): independent exact coefficient [x^m q^k]
closed_polynomial(class,m): exact coefficient tuple in ascending q powers
h_parity_coefficient(r,n): independent finite-support parity extraction
gamma_ratio_coefficients(L,a,b): exact G_0,...,G_L using Bernoulli polynomials
p_polynomial(L), q_polynomial(L), b_operator_polynomial(L): exact monomials
exact_profile_coefficient(kind,class,L,epsilon,k): [w^k]sqrt(2pi)A or [w^k]B
exact_threshold(class,m): rational factor times sqrt(m), exact in that basis
profile(kind,class,L,epsilon,w,derivative=0): numerical entire profile
normalized_value(class,m,w): evaluation of the exact finite polynomial
model_root(class,epsilon,Y): limiting root, using Lambert W_{-1} for R
numerical_exact_root(class,m,Y): bisection of the exact finite polynomial
inverse_series(class,epsilon,w0,order): formal interior coefficients in
  powers of m^(-1/2), numerically evaluated from the exact profile algorithms
boundary_root_approximation(class,m): separate even-m boundary expansion

class is 'E' or 'R'; kind is 'A' or 'B'; epsilon is +1 or -1. The word
"exact" in numerical_exact_root describes the coefficient polynomial, not
a rigorous floating-point root enclosure. The eligibility check uses the
actual finite-m threshold rather than the limiting threshold. General
profile polynomials are obtained by rational interpolation using the proved
degree bounds; the report supplies those bounds. No general analytic theorem
is inferred merely from interpolation or finite cancellation checks.

Safe deterministic rebuild
--------------------------
The destination's parent must already exist and contain no symlinks. The
destination directory itself MUST NOT exist (even if empty). For example,
choose two new absolute paths under /tmp:

    python build.py --output-dir /tmp/report151-rebuild-a
    python build.py --output-dir /tmp/report151-rebuild-b
    cmp /tmp/report151-rebuild-a/Report151.pdf /tmp/report151-rebuild-b/Report151.pdf
    cmp /tmp/report151-rebuild-a/Report151-source.zip /tmp/report151-rebuild-b/Report151-source.zip
    sha256sum /tmp/report151-rebuild-a/Report151.pdf /tmp/report151-rebuild-a/Report151-source.zip

Each build prints SHA-256 digests and creates exactly Report151.pdf and
Report151-source.zip in its new destination. No source file is overwritten.
The ZIP contains the nine allowlisted deliverables above, in sorted order,
and its Report151.pdf is byte-identical to the standalone PDF. To rebuild
from a ZIP, extract it into a new directory, run both test commands there,
and use another fresh --output-dir. A --source-dir option can select an
explicit source directory.

SOURCE_DATE_EPOCH=1790985600 and FORCE_SOURCE_DATE=1 are set internally.
The builder uses a sanitized locale/timezone/environment, creates a private
TeX format/cache/home, disables shell escape, and supplies explicit font
maps. It compiles at least twice, requiring stable auxiliary files within
six passes, then rejects final rerun, missing-character, and box warnings.
The source suppresses nondeterministic PDF date/trailer metadata. ZIP entries
use the fixed epoch, ZIP_STORED, Unix regular-file mode 0644, and sorted names.

Source/output directory traversal uses pinned descriptors and O_NOFOLLOW.
Sources must be regular files; symlinks, including ancestors, are rejected.
Source bytes are snapshotted before compilation. Foundation SHA-256 digests
are pinned by build.py. The final directory is created exclusively, and each
complete output file is published atomically with a no-clobber hard link.
Publication of two separate files is not a single cross-file transaction:
if an I/O failure interrupts it, a newly created partial release directory
may remain. Inspect it and choose a fresh destination for the next build;
the builder never removes or overwrites an existing release.

Pinned unchanged foundation hashes
---------------------------------
0bb57104e7bd6efd1a11096c56222bd4a891f4bd1dc10cdb346988ce1c6ab24b  foundation/Report149.tex
3b5edb943820dd6c061ccf0ad96a38cee0d3004550f75eef3a3eb70e865ea648  foundation/Report149.pdf
