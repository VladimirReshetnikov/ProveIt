# K215: a 215-state consistency machine

This packet constructs an explicit binary, single-tape Turing machine with **215 working states** whose blank-tape nonhalting is equivalent, in ZFC, to `Con(ZFC)`. The proof composes the new exact source, runtime, and startup arguments with the inherited ProveIt numerical-calculus/ZFC calibration. The complete statement, proof dependencies, and canonical table are in `report.pdf` and `report.tex`.

The machine has one bi-infinite tape, alphabet `{0,1}`, an entirely zero initial tape, initial state `0`, and only left/right moves. Canonical states `0..214` are working states; `215` is the separate halt with no outgoing rows. All 430 working-state rows are explicit. There is no external bootstrap or initialized input.

## Contribution

Two previous 216-state submissions optimize different parts of the same implementation. Their transition patches do not simply add together. This construction combines the **source transformations before allocating physical states**: it retains the partial selector, moves the counter input into the commands that require it, permutes the command tags, and preserves both origin-marker merges in the resulting allocation.

Relative to the partial-selector 216-state table, the exact recipe changes 36 retained transition rows, deletes native state 185, and adds no state. The resulting source has 202 distinct subtrees and 4,751 primitive occurrences. A separate all-natural source bisimulation compares the entire primitive word and guarded ordinal graph with the calibrated permuted-command source.

This saving preserves the dominated numerical calculus, including its treatment of arbitrary raw codes and the zero alias. It does not depend on interpreting every code as a conventional formula. The report also develops concrete directions toward a smaller refutation-equivalent formalism and further state reductions; those directions are explicitly marked as research questions.

## Reproduce

From this extracted directory, using Python 3.10 or newer with assertions enabled:

```sh
python3 -B verify.py
python3 -B verify.py --runtime --work /path/to/new-k215-replay
```

The work directory, if supplied, must not already exist. Both commands are offline and use only the Python standard library. Without `--work`, temporary outputs are removed when the run finishes.

The default command checks the release manifest; the pinned parent's finite theory, source, and table chain; reconstruction of both relevant intermediate sources; exact K215 reconstruction; all-natural source bisimulation; both marker merges; the complete blank prefix; the canonical table; a concrete mutation control; and the inventory of stored symbolic-runtime results.

**Use `--runtime` to derive all 6,176 unbounded primitive cases afresh.** It compares every ordered case receipt and every startup-trace entry with the released evidence. The primitive derivation took about two minutes in the construction environment. Timings are descriptive. The fresh full path passed before release; its result is recorded in `evidence/release_replay.json`.

Verification does not need TeX, a solver, a network connection, or a theorem prover. To rebuild the article, use `sh build.sh` with a normal LaTeX installation. The complete transition-table appendix is generated from `machine/k215.tm`; the verifier checks it byte for byte.

## Checked results

| Quantity or obligation | Result |
|---|---:|
| Working states / transition rows | 215 / 430 |
| Native start / dispatcher / halt | 0 / 84 / 254 |
| Canonical start / dispatcher / halt | 0 / 83 / 215 |
| Source occurrences / distinct subtrees | 4,751 / 202 |
| Source maximum depth / zero run | 47 / 6 |
| Guarded runtime cases | 6,176 / 6,176 proved |
| Symbolic rules | 1,698,790 |
| Minimum affine-duration constant | 6 |
| Literal rows covered by runtime proofs | 430 / 430 |
| Exact blank prefix | 95,714 transitions |
| Logical root registers | `(4,0,0,0,0,0,0,0,0)` |
| Root head / gap / header | -8 / 1 / 57 |
| Spare register values | Forty ones |
| Three-step marker cases, 164/183 and 69/400 | 128 and 64 |

The runtime certificates quantify over arbitrary natural register values, arbitrary natural gap, and arbitrary nonempty finite spare lists. They use induction over unary runs and list tails. They are not bounded testing of those values. The entire blank-prefix tape, including zero exterior, is independently reconstructed. A second interpreter also replays the full canonical trace.

All working states are reachable in the transition graph; this does not assert that all are visited on the blank execution. A supplied negative control restores a known wrong context-dependent entry and is rejected on an unbounded primitive case. That control is defect detection, not a proof of checker soundness.

## Proof boundary

The claim is an **ordinary mathematical proof formalizable in ZFC**, with explicitly identified inherited foundational lemmas and executable symbolic proof checks. This packet does not introduce a newly compiled exact-table Lean/Rocq theorem or a new internal PA endpoint.

The numerical endpoint in the pinned repository is `KLower221.c222_iff_zf_refutation`, composed with `ConstructibleChoice.zf_refutation_iff_zfc_refutation`. The included dominated-basis certificate transfers the numerical calculus without excluding junk codes. The new verifier rechecks that finite basis certificate and the relevant source/tape bridges; it does not rebuild the whole foundational Lean development. See the report for the exact proof chain and its trusted boundary.

Nothing assumes `Con(ZFC)` to prove the equivalence. The packet does not establish actual nonhalting unconditionally and does not claim a minimum state count.

## Exact file identities

| File | SHA-256 |
|---|---|
| `machine/k215.tm` | `5de1af90b1c5f0849956c4e8a895621e24b1f26c38c5348ac7d74fbe6ab729f2` |
| `machine/k215.native.tm` | `2bae0de1f3388fc46c0558da3cf66d17e0d597ec0ae843731300e825f26fb3ba` |
| `source/sites215.json` | `17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba` |

Table rows have the format `state read write direction next_state`; lines beginning with `#` are metadata. The native and canonical tables are related by the complete checked bijection in `machine/canonicalization.json`.

## Contents

| Location | Contents |
|---|---|
| `report.tex`, `report.pdf`, `sections/` | Article, mathematical proofs, research directions, complete canonical table |
| `machine/` | Exact native/canonical machine and label map |
| `source/` | Final structured source and deterministic transition recipe |
| `code/` | Reconstruction, independent audits, inherited symbolic runtime implementation |
| `evidence/` | Full startup trace, all ordered symbolic results, independent and fresh replay receipts |
| `reference/` | Selected unchanged inputs from the two 216-state submissions; see its `SNAPSHOT.md` |
| `parent/` | Exact K217 archive with its nested dominated-K218 packet |
| `provenance/`, `licenses/` | Input identities, attribution, search receipts, inherited notices and licenses |
| `manifest.json` | SHA-256 of every delivered regular file except the manifest itself |

`code/repack.py --output /path/to/archive.zip` checks this manifest and makes a deterministic archive of the listed bytes plus the manifest. Rebuilding the PDF can change its byte identity because TeX embeds build metadata; it does not change the machine or theorem. A modified article requires a correspondingly updated release manifest.

The repository was inspected at commit `d59b4418821c598c4703f0a60b1f7cbae4f3bcf6`. The immediate 216-state inputs were the submissions in `docs/incoming/` at that snapshot. Original attributions and licenses are preserved; the new contribution is distinguished in `provenance/ATTRIBUTION.md`.
