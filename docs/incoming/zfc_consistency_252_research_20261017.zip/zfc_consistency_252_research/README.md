# A 252-state ZFC consistency machine

Research report and reproducible experiments, 17 October 2026. Prepared for
Vladimir Reshetnikov and the ProveIt project.

## Main result and claim boundary

The report reconstructs an **ordinary mathematical proof formalizable in ZFC**
for the existing register-permutation252 machine:

\[
\mathrm{ZFC}\vdash \mathrm{NH}(M_{252})
\leftrightarrow \operatorname{Con}(\mathrm{ZF})
\leftrightarrow \operatorname{Con}(\mathrm{ZFC}).
\]

It combines the inspected finite arithmetic/runtime arguments, the exact
native container/GIC calculus, set-coded Henkin and quotient constructions,
the internally well-founded submodel, and Gödel's classical constructibility
interpretation. It does not infer a ZFC theorem merely from a Lean theorem.

**The 252-state machine is prior ProveIt work, not a new state record from this
investigation. No justified machine below 252 states was found.** The current
closed external Lean endpoint is nonhalting iff Con(ZF), with Foundation and
Power. A direction from Con(ZFC) is checked. The final Lean Choice comparison
and an explicit internal PA proof-code comparison remain separate work. The
report supplies neither a fresh complete Lean/Coq rebuild nor a new proof of
the consistency of ZFC.

The selected source scope is pinned:

- ProveIt: `fab89c5d26b81cd2ccab2ee5d213ff23725c7726`.
- busy-beaver upstream audit: `ec9ed4f713d8c017f15743ad0692cdf31a59952a`.
- ProveIt's imported busy-beaver source: `297ab8df7e5de329605c3875b4934643b371a5e3`.
- Prior public mira-emmy253 PR head: `0d544f2a2e3c18f12278441a74b7879f31cbe856`.

The three commits requested in the research brief, and the newer closed
endpoint commits, are discussed and linked in the report.

## Files

| Path | Contents |
| --- | --- |
| `report.tex`, `report.pdf` | Complete research report and compiled document. |
| `sections/` | LaTeX sections, bibliography, and all 504 literal machine actions. |
| `machines/` | Unchanged canonical252, old-label252 and imported254 tables. |
| `code/verify.py` | Read-only quick verifier, using Python's standard library. |
| `code/cofinal_countermodel.py` | Two counterinterpretations, padding checks, exact gap-enumeration checks. |
| `code/cofinal_gate_cost.py` | Full source/compiler controls, including the corrected fixed-role generator. |
| `code/incoming_action_search.py` | New 166,413-recipe incoming-write/move deletion screen. |
| `code/generate_machine_appendix.py` | Generates the two-page table appendix directly from the canonical table. |
| `data/` | Results, scoped project verification records, blank-frame metadata, and complete compressed search journal. |
| `experiments/cofinal_gate/` | Actual selected compiler tables, DAGs, label maps, all sharing measurements and backend sources. |
| `references/lean/` | 40 selected pinned prior source files, with original paths, URLs, lengths and SHA256 values. |
| `references/coq/` | Four selected pinned upstream source files and their manifest. |
| `vendor/proveit/` | Narrow source snapshot required for replaying the new experiments; not a complete formal project. |

`SHA256SUMS` covers all delivered files except itself. The vendor blob manifest
checks the 75 directly retrieved snapshot files by Git blob SHA1. The extra
strict-affine helper is checked by SHA256 against the recorded search input.
The reference manifests record the individual exact source identities.

## Exact reference machine

`machines/zfc_permutation252.tm` has 252 working states numbered 0 through 251,
start 0, two tape symbols, and a separate halt state 252. The head starts at
integer 0 on an all-zero, two-way infinite tape. Each row is
`state read write L-or-R next-state`. The final write and movement still occur
on a halting transition. There are 504 rows and exactly one halting edge.

Canonical SHA256:

```text
8dae0c2359aa8bf87d32543b9e53e1f87fe4716c016a4e2fd174bfe09e520797
```

The old-label table uses start 64 and halt 254 and omits working labels 5 and 8.
`data/renumbering.json` contains the complete bijection and exact whole-tape
bootstrap target. After 82,552 transitions, the canonical run is at state 94,
head 2, with 77 one-cells. All nine primary registers are zero; the full 65
spare blocks are retained, with spare index 8 equal to one. The quick verifier
checks the complete tape support, canonical/old relabelling, and all actions
against the pinned Lean literal array.

## New logical proposal and its limitation

The first experiment replaces the bundle's two freshness tests by
`c = a + b + d + 1`, after preserving all original logical outputs. The report
proves a cofinal padding theorem **over an independently complete first-order
calculus**. It also gives a two-element interpretation of indexed membership
with hidden assignment coordinates, proving that cofinal vacuity does not
recover all original atomic-vacuity instances in the restricted logical
fragment. This is not a model of the full container/GIC theory and does not
prove a consistency-strength separation for that full theory.

A safe alternative specification is exact gap enumeration. With
`x=u`, `y=u+g+1`, `z=u+g+h+2`, the six permutations of `(x,y,z)` together with
`(x,x,y)` and `(y,y,x)` enumerate exactly all old triples with `c != a,b`.
This preserves every original numerical bundle, including its logical
component. Its complete compiler cost is **unmeasured**; no smaller machine
is claimed for this proposal.

## Reproduce the quick checks

Run from the extracted archive root, without Python's `-O` option:

```sh
python3 -B code/verify.py
```

The archived successful output is `data/quick_verification.json`. It checks:

- All 504 canonical rows, their old-label bijection, and the pinned Lean array.
- The full 82,552-transition blank run and exact entire finite tape support.
- All 44 selected reference file hashes and the 75 vendored Git blob identities.
- 118,848 finite row/assignment evaluations, 1,137 padding triples, 8,000 gap
  emissions, and exact coverage of 810 admissible triples below ten.
- Every recipe in the complete compressed search journal and its first-stop
  category, in the declared enumeration order.
- Sizes and SHA256 values of the selected complete compiler tables.

This command does not rerun the 210,941 affine candidate checks, rebuild Lean
or Coq, or prove an unbounded consistency theorem by simulation.

## Reproduce the compiler controls

```sh
python3 -B code/cofinal_gate_cost.py \
  --repo vendor/proveit \
  --output /tmp/zfc-cofinal-replay --seeds 32
```

The complete outputs should have these counts:

| Control | Unshared | Best of 32 seeds | Best decision + framework |
| --- | ---: | ---: | ---: |
| Original | 281 | Not separately optimized | 219 + 62 |
| General cofinal | 287 | 279, seed 25 | 217 + 62 |
| Fixed CP/GIC, corrected | 307 | 286, seed 9 | 224 + 62 |

The fixed-role variant uses `c = a+b+d+2`, because its C/G roles bind labels 0
and 1. An earlier `+1` implementation collided at the all-zero input and is
superseded. Its earlier 285-state table is not included as a usable result.

The run executes 729 tests for each shift and 729 cleanup tests, checks exact
macro expansions, and re-extracts every decision edge. It compiles the original,
two unshared variants, and 64 sharing alternatives. The best alternatives are
exported with complete binary tables, source DAGs and label maps.

**These are uncalibrated compiler controls.** Both retain the cofinal-vacuity
obstruction. Their generic bootstrap has not been proved to establish the
changed source invariant. The framework's missing `1.inc`/read1 row is
totalized to halt, without an unreachability proof. Two states saved against
the 281-state compiler control cannot be subtracted from the optimized252.

## Reproduce the incoming-action search

```sh
python3 -B code/incoming_action_search.py \
  --repo vendor/proveit \
  --output /tmp/zfc-incoming-replay/results.json \
  --scratch /tmp/zfc-incoming-replay \
  --seconds 600 --affine-fuel 1000
```

The family fixes 55 box-support rows and the dispatcher identity. It chooses
one of 221 eligible deleted states, one of 251 retained targets, and one of
three nontrivial uniform incoming-action edits: flip write, reverse movement,
or both. Thus there are 166,413 recipes. The archived completed run took
83.83 seconds with a 240-second allowance, performing 210,941 affine checks.
All 8,391 baseline instruction cases and the exact82552 blank prefix passed.

No recipe passed the affine screen, so no modified candidate received a blank
run. First stops were 80,692 fuel exhaustions, 84,788 unsupported symbolic
rules, and 933 missing-transition lookups. These are bounded checker
diagnostics, not semantic counterexamples and not a lower bound. A different
invariant or executor could change which mutations can be certified.

The output must say `completed` and list 166,413 completed recipes before it
is compared to the archived full run. Elapsed time and output paths will
vary. The compressed journal records all recipes and is retained separately
from the readable summary.

## Build the PDF

```sh
make report
```

This requires Python 3, `latexmk`, `pdflatex`, and common TeX packages:
`amsmath`, `amssymb`, `amsthm`, `mathtools`, `lmodern`, `microtype`, `geometry`,
`booktabs`, `tabularx`, `longtable`, `enumitem`, `xcolor`, `xurl`, `hyperref`,
`fancyhdr`, `listings`, and `needspace`. No network is used during the build.
The table appendix is regenerated from the frozen canonical machine file.
`make clean` removes auxiliary TeX files and preserves the PDF.

## Attribution and integration

The original254 design is attributed to Mira-Cult; Jeff supplied the Coq
verification; the public253 reduction is attributed to mira-emmy; Andrew Wade
supplied the imported binary compiler; ProveIt supplied the permutation252
construction, Lean development, and earlier experiments used here. The new
drivers and mathematical analysis are prepared for incorporation into ProveIt.
Existing upstream notices and the ProveIt MIT No Attribution license are
retained; this archive does not relicense third-party material.

Keep the distinction between prior checked sources and this report's new
ordinary arguments and diagnostics when integrating the archive. The reference
snapshot is intentionally incomplete as a Lean/Coq checkout; complete formal
builds should use the upstream repository at the stated pin.
