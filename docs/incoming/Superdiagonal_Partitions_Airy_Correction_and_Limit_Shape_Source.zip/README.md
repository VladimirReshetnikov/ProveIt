# Report160 — Airy correction and limit shape for superdiagonal partitions

This self-contained report concerns OEIS A238873: weakly increasing positive-integer partitions (lambda_1,...,lambda_K) with lambda_i >= i. The empty partition contributes A(0)=1. It is a distinct refinement of Report158; Reports158 and159 are unchanged.

## Main results

Write b=log(2), C=pi^2/12+b^2, and let -zeta be the largest negative zero of Ai. The report proves

    log sum_{n>=0} A(n) exp(-tn) = C/t - zeta b t^(-1/3) + o(t^(-1/3))
    log A(n) = 2 sqrt(Cn) - zeta b C^(-1/6) n^(1/6) + o(n^(1/6))

The coefficient result is pointwise. Mallein's published killed-walk area estimates supply the Airy exponent, with their hypotheses, area convention and variance normalization checked explicitly. The exact-weight lower bound is separate: a localized early prefix, a surviving concentrated head block creating a buffer, a far-tail lattice local limit covering all Fourier arcs, a moderate retilt at fixed cutoff, and subtraction of an exponentially smaller ruin probability. The proof uses no radial-to-pointwise Tauberian shortcut.

For T(y)=min{n>=0:A(n)>=y} and x=(log(y)/(2 sqrt(C)))^2,

    T(y)=x+zeta b C^(-2/3) x^(2/3)+o(x^(2/3)).

This is proved by monotonicity and two integer bracketing sequences, not by differentiating a remainder. It is not an exact rounding rule or a certified finite-input threshold window.

Under the uniform law on these partitions of n, put t=sqrt(C/n). The typical length satisfies tK -> 2b, hence K/sqrt(n) -> 2b/sqrt(C), in probability and every finite positive moment. The cumulative profile t C_floor(x/t) converges uniformly for all x>=0 to

    g(x)=x                         for 0<=x<=b
    g(x)=2b+log(1-exp(-x))          for x>=b.

Its inverse row curve is

    f(y)=y                         for 0<=y<=b
    f(y)=-log(1-exp(y)/4)           for b<=y<2b.

Row convergence is uniform only on fixed compact subsets of (0,2b). All these fixed-tolerance deviation bounds have the form exp(-c/t), with constants depending on the tolerance and interior interval. The cumulative theorem is global. The row theorem explicitly includes missing rows as a bad event.

The initial half of the limiting row curve follows the diagonal. Equivalently, the fraction of rows with part size at most floor(b/t) converges to one half. Neither statement gives the density of exact contacts lambda_i=i. The shape argument needs only the coarse pointwise lower bound already proved in Report158, although the current report also proves a stronger bound.

No amplitude, power prefactor, multiplicative equivalent, O(log n) remainder, further asymptotic term, all-orders expansion, central limit theorem, extreme-part law or fluctuation scale is claimed. The constants and onset in the asymptotic errors and concentration bounds are not numerically effective here.

## Sources and attribution

Archibald, Blecher, Elizalde and Knopfmacher's 2025 paper supplies the partition class, exact refined generating functions and prior ballot/Dyck encodings. The Airy inputs are Lemmas 2.6 and 2.7 of Mallein's 2015 paper, in the homogeneous variance-two specialization. General geometric conditioning and exponential tilting are established techniques. The local-limit proof is supplied in full here. NIST DLMF Table 9.9.1 supplies the ten-decimal Airy-zero value used only in numerical illustrations.

A bounded check of primary sources and the available report catalogue found no duplicate of the stated refinement or shape law. This is not exhaustive scholarly priority clearance. SOURCE_PROVENANCE.json gives source URLs, inspected scopes and preserved-source hashes where available. Full third-party papers, full OEIS entry text and private working records are not redistributed.

## Package contents

- Report160.pdf: 17-page article with analytic cumulative and row profile illustrations
- Report160.tex: editable self-contained LaTeX source, including drawing coordinates
- companion/airy_shape.py: bounded standard-library computation
- companion/test_airy_shape.py and companion/README.md: tests and complete command/API documentation
- data/counts.json: exact counts through n=400
- data/finite_checks.json: exact finite checks and coverage
- data/illustrations.json: separately labeled scalar illustrations and exact finite length means
- data/shape_coordinates.json: numerical coordinates of the analytic limiting curves
- data/oeis_prefix.json: attributed 61-term numerical prefix used as input
- SOURCE_PROVENANCE.json: attribution and source record
- build_pdf.py, release_tools.py: exclusive clean PDF build and local I/O helpers
- make_zip.py, test_release.py: fixed-allowlist reproducible packaging and release tests
- SHA256SUMS: sorted SHA-256 manifest of the allowlisted payload, excluding itself

The ZIP includes the manifest but does not include itself recursively. Working render images, audit records, test logs, build directories and unlisted files are excluded.

## Requirements and bounded computation

Python 3.10 or later is required; the companion uses only the standard library, performs no network requests, and prints JSON to stdout without any file-writing API. Exact count workloads are capped at n=400, direct enumeration at n=32, shape grids at 1001 requested points, vector lengths and entries at eight, finite survival horizons at 20, and threshold values at 10^200. Public integer APIs reject booleans, floats and strings; CLI numbers use canonical nonnegative ASCII decimal notation. Domain and runtime checks remain active under -O.

The counting recurrence is positive and indexed by largest allowed part, length and weight; it uses O(N^2 sqrt(N)) arithmetic operations and O(N sqrt(N)) cells. An independent recursive enumerator checks the indexed and cumulative definitions. See companion/README.md for the recurrence and all individual input bounds.

Default finite checks include 18,460 ordinary partitions through weight 28, 3,420 admissible partitions and largest-part injection images, 365,081 row/cumulative inverse comparisons, 4,095 rational prefix changes of measure, 2,916 full-product identities, 164 exact retilting identities, 63 finite survival horizons, six cutoff sign cases and all 61 supplied OEIS terms. Finite evidence validates definitions, algebra and implementations; it does not prove asymptotic results, effective errors or probability certificates.

Approximate numbers use ordinary floating point. The Airy input is the DLMF table value 2.3381074105, not a locally computed or certified root. Displaying twelve significant digits does not assert twelve-digit accuracy. The profile area series tail bound excludes floating-point rounding. Reference-product expectations and exact uniform fixed-size expectations are labeled separately. All shape figures show the analytic formulas, not sampled partitions or confidence bands.

## Companion replay

From the extracted package directory, choose a new output directory and use shell no-clobber mode:

```sh
mkdir reproduction
set -C
python3 -B companion/airy_shape.py counts > reproduction/counts.json
python3 -B companion/airy_shape.py verify > reproduction/finite_checks.json
python3 -B companion/airy_shape.py illustrations > reproduction/illustrations.json
python3 -B companion/airy_shape.py shape > reproduction/shape_coordinates.json
cmp data/counts.json reproduction/counts.json
cmp data/finite_checks.json reproduction/finite_checks.json
cmp data/illustrations.json reproduction/illustrations.json
cmp data/shape_coordinates.json reproduction/shape_coordinates.json
python3 -B -m unittest discover -s companion -p 'test_airy_shape.py' -v
python3 -O -B -m unittest discover -s companion -p 'test_airy_shape.py' -v
python3 -B companion/airy_shape.py threshold --value 1000000 --max-n 200
```

Thresholds are searched in actual counts, beginning at n=0. Value one has threshold zero. An unreached threshold is explicitly unreached; no continuous approximation is substituted for an exact first crossing. Approximate output snapshots are reproducible on the recorded Python/math platform; last digits may depend on another platform's math library.

## Clean PDF replay

The release toolchain is Python 3.12.14 and pdfTeX 1.40.26, TeX Live 2025/dev/Debian. The builder requires pdftex and pdflatex, plus fontenc, Latin Modern, amsmath, amssymb, amsthm, mathtools, geometry, booktabs, array, pict2e, microtype and hyperref. Poppler is used for visual QA but not by the builder.

```sh
python3 -B build_pdf.py --output-dir /tmp/report160-build-one
python3 -B build_pdf.py --output-dir /tmp/report160-build-two
cmp /tmp/report160-build-one/Report160.pdf /tmp/report160-build-two/Report160.pdf
cmp Report160.pdf /tmp/report160-build-one/Report160.pdf
```

Choose fresh build directories whose parents already exist. The builder creates the destination exclusively, uses fresh LaTeX formats and isolated caches, fixes epoch and metadata, disables shell escape, and repeats until references stabilize. The settled log must contain no warnings, missing characters, overfull or underfull boxes. The .tex file is the only authoring input. Byte identity is expected within the recorded toolchain, not across TeX versions, fonts or operating systems.

## Manifest and archive replay

```sh
sha256sum -c SHA256SUMS
python3 -B -m unittest -v test_release
python3 -O -B -m unittest -v test_release
python3 -B make_zip.py --output /tmp/Report160-rebuilt-one.zip
python3 -B make_zip.py --output /tmp/Report160-rebuilt-two.zip
cmp /tmp/Report160-rebuilt-one.zip /tmp/Report160-rebuilt-two.zip
cmp Report160_Source.zip /tmp/Report160-rebuilt-one.zip
```

The final cmp applies if the source ZIP is retained alongside the extracted files. The archive checks the exact sorted allowlist and all recorded hashes before packaging; timestamps, order, permissions and ZIP_STORED compression are fixed. It excludes unlisted files. Editing any payload requires a new release manifest; a modified file fails the original manifest.

Release file outputs are exclusive and refuse existing files, symlinks, directories, FIFOs and other special targets. Symlink parent components and parent traversal are rejected. POSIX O_NOFOLLOW/O_DIRECTORY and directory-relative operations are required. The source tree and output parents must be trusted and nonadversarial. Descriptor pinning reduces accidental substitution; the mkdir-then-open interval is not claimed to defeat a malicious same-user actor. A failed output write may leave a new incomplete file, so inspect it rather than blindly retrying. Shell-escape suppression does not sandbox arbitrary modified TeX. The companion's bounded data reader is described in its README and is not a general file-access security boundary.

No command uploads, publishes, contacts an author, edits OEIS, or modifies an external repository.
