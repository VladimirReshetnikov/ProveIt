# Stability of Two by Two Covers and Weighted Rank Four

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October 2026.

## Main result

Every bipartite graph with a vertex cover consisting of two vertices on each shore has a real stable complemented-row matching-support basis polynomial. Therefore its matching-support polynomial is real-rooted for every positive assignment of vertex activities.

Together with exact leaf compression and the published smaller-shore Lorentzian inequality, this proves rank-normalized ultra-log-concavity for every bipartite matching-support polynomial of matching rank at most four. Nonnegative activities are covered using the actual surviving degree.

This resolves the incoming ProveIt Matching Rank manuscript's “Finish rank four” question, including arbitrary weights on both shores. It follows the separately delivered weighted rank-three note rather than replacing that document.

## Proof architecture

A two-plus-two cover has six core types up to symmetry. Exterior degree-one vertices are leaves and can be reattached by a direct stability-preserving operator. Three easy core types are vertex sums of stable complete bipartite blocks. The matching and three-edge cores admit explicit positive-semidefinite independent-column covariance constructions whose squared-minor expectations are exactly the Boolean matchability indicators. The complete core has a two-block basis polynomial whose stable quadratic diagonal polarizes to the full polynomial.

The article includes a complete human proof for every supported minor type. The finite exact checks supplement that proof.

A further section gives the exact stability threshold for a complete two-by-s mixed core. The first rank-five family already contains a 17-vertex graph with unstable multivariate signed support polynomial but a real-rooted unit-weight diagonal. This demonstrates a boundary of the stability argument without claiming a rank-five ULC counterexample.

## Files

- `article.pdf`: final visually inspected research note
- `article.tex`: editable LaTeX source
- `verify_covariance.py` and `covariance_verification.json`: 140 exact Boolean squared-minor checks and finite principal covariance checks
- `verify_complete_core.py` and `complete_core_verification.json`: 49 independent support-to-basis checks for the complete two-by-two core
- `verify_boundary.py` and `boundary_verification.json`: 75 small complete mixed cores plus the exact 17-vertex rank-five example and rational root certificate
- `PROOF_STATUS.md`: proof scope, dependencies, audit and limitations
- `SOURCES.md`: provenance and literature links
- `requirements.txt`: Python dependency
- `build_local.sh`: optional build helper for the preparation environment
- `Makefile`: standard verification and LaTeX targets

## Reproduction

Install SymPy, then run:

    python3 verify_covariance.py
    python3 verify_complete_core.py
    python3 verify_boundary.py

A standard TeX Live installation can compile `article.tex` with two `pdflatex` runs. The provided build helper additionally handles the preparation environment's missing TeX filename databases and explicit font-map loading.

No Lean verification or global mathematical priority is claimed. Published stability and Lorentzian tools are explicitly attributed, and the article distinguishes rank-four ULC from the stronger real-rootedness statement proved only for the two-plus-two class.
