# The Sharp Weighted Energy Gap on Elementary Abelian Three-Groups

ProveIt Report 293, prepared for Vladimir Reshetnikov, 7 October 2026.

For full-domain maps from any F_3-vector space into any abelian group, the sharp upper bound on the weighted energy infimum outside the affine and translated index-three affine-cut families is

    lambda = (11 + 6 sqrt(6)) / (11 + 6 sqrt(6) + 7 sqrt(6 sqrt(6) - 8))
           = 0.5865294215371424...

Every such map has a witness on at most nine points, and nine is necessary at the exact threshold. The spike admits no rational-valued exact-threshold witness; positive rational weights approximate its minimum from above. The bound is optimal uniformly over all source ranks and targets, with equality already attained by an order-two single-point spike on the nine-point plane. The manuscript proves the unrestricted all-weight minimum, unique minimizing weight ray, and an explicit nonoptimal weight-stability estimate. On the plane, equality maps are exactly affine maps plus one nonzero order-two spike; all other unfavorable plane maps have ratio at most 677/1161. That latter bound is not asserted optimal. The report does not classify higher-rank equality maps or claim sharpness at every fixed target.

The structural upper proof covers arbitrary targets by group-theoretic reductions and one exhaustive integer-relation lemma. All 729 midpoint choices and their checked unimodular matrices are retained. The all-rank geometric gluing and exact favorable-cut value are proved in full. No symmetry of an unknown minimizing weight is assumed. No numerical search, bounded-target extrapolation, publication-priority claim, or proof-assistant certification is used.

## Contents

- Report293.tex: editable mathematical manuscript
- Report293.pdf: compiled report in the final distribution
- companion/exact_checks.py: bounded exact diagnostics using the Python standard library
- companion/lattice_certificate.json: all 729 relation choices and integer transformation certificates
- companion/README.md: exact scope, bounds and checker details
- tests/test_companion.py: mathematical and adversarial certificate regressions
- tests/test_build.py: guarded-builder and exact-inventory regressions
- build.py: offline verification, full replay and deterministic packaging
- REPRODUCING.md: toolchain and archive contract
- SOURCES.md: mathematical provenance, literature and inspection boundaries
- MANIFEST.sha256: canonical hashes of the twelve public nonmanifest files

There are eleven authored source files, including companion/__init__.py. The final archive has exactly thirteen regular-file entries under Report293/, including the PDF and manifest. Working notes, render images, receipts and logs are excluded.

## Quick replay

    python3 -I -B build.py verify
    python3 -I -B build.py reproduce --output /tmp/report293-replay

The output must be fresh or empty, absolute, and outside the source tree. The builder preserves the input, refuses file aliases and unexpected entries, runs all checks normally and with -O, and compares outputs. In distribution mode the rebuilt PDF must match the included PDF byte for byte. Matching the documented toolchain is needed for byte identity. No installation, download, network access or upstream execution occurs.

The separately supplied final ZIP SHA-256 authenticates the bytes only when obtained through a trusted channel. The manifest alone is not a signature. Reports 1-292 remain unchanged.
