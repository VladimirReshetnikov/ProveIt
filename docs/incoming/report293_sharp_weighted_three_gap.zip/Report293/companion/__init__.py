"""Standard-library exact certificates accompanying Report293."""
import sys
sys.dont_write_bytecode = True
