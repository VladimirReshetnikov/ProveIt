# Diophantine Barriers for Continuous Computation

**A three-dimensional trichotomy, finite quartic certificates, and a computable critical-noise radius**

Research manuscript prepared for Vladimir Reshetnikov and the ProveIt research program, 30 September 2026.

## Main results

The article proves a horizon-independent approximation theorem for the minimum per-step adversarial perturbation needed to reach a closed rational target. A weighted rational grid gives an error at most `(L + 1)/(2N)`, regardless of trajectory length. Finite graph cuts give explicit quartic sum-of-squares certificates, complete for strictly positive critical radius.

A single continuous rational piecewise-affine map of the three-dimensional unit cube realizes every disjoint pair of computably enumerable sets as exact acceptance and robust rejection. The remaining encoded inputs diverge but admit accepting paths under arbitrarily small perturbations. The article proves quantitative rejection-time/radius bounds, recursive inseparability, the Diophantine representations of the two positive outcomes, and the impossibility of an existential Diophantine representation of the third. It also gives a noise-faithful transfer theorem and a rational recurrent ReLU-block corollary.

These are proposed research contributions with mathematical proofs, not a certified priority claim or a claimed solution of a named classical open conjecture. Known universality and robustness/decidability results are credited in the article.

## Files

- `diophantine_barriers.tex`: complete, self-contained LaTeX source, including bibliography.
- `diophantine_barriers.pdf`: compiled article.
- `code/barriers.py`: exact-rational grid/certificate algorithms and generic binary-TM-to-three-dimensional-PWA compiler.
- `code/run_checks.py`: deterministic tests and example generation.
- `results/verification.json`: 5,660 passing assertions and their exact categories.
- `results/contraction_table.json`: the manuscript's rational approximation table.
- `results/small_certificate.json`: a five-vertex safety certificate.
- `results/small_quartic.txt`: its full factored quartic polynomial.
- `PROVENANCE.md`: source inspection, proof dependencies, and limits.

## Reproduce the checks

Python 3.10 or newer; standard library only:

```sh
python code/run_checks.py results
```

This command regenerates all files in `results/`. Arithmetic uses `fractions.Fraction`, and the deterministic sampling seed is 20260930. The tests include all affine simplex bounds of one non-universal five-state sample compiler, exhaustive small graph cuts, all 1,024 assignments in `{-1,0,1,2}^5` for a small quartic, tape formulas, and perturbation schedules.

## Build the PDF

A normal TeX Live installation with the packages listed in the source is sufficient:

```sh
pdflatex -interaction=nonstopmode -halt-on-error diophantine_barriers.tex
pdflatex -interaction=nonstopmode -halt-on-error diophantine_barriers.tex
```

A third pass may be needed after changing pagination. No separate BibTeX run is needed.

## Minimal exact-arithmetic example

Run from the `code` directory, or add that directory to `PYTHONPATH`:

```python
from fractions import Fraction as F
from barriers import Box, make_grid_graph, bottleneck, safety_certificate

graph = make_grid_graph(
    lambda p: (p[0] / 2,),
    (F(0),),
    [Box((F(3, 4),), (F(1),))],
    mesh=4,
    lipschitz=F(1, 2),
)
r = bottleneck(graph.weights, graph.source, graph.targets)
assert r == F(1, 2)
assert safety_certificate(graph) == (1, 1, 0, 0, 0)
print('Certified radius interval:', max(F(0), r - graph.error), r)
```

The true radius is `3/8`; the returned interval is `[5/16, 1/2]`. The particular Boolean cut certifies the weaker but positive lower radius `3/16`. A certified lower radius guarantees avoidance for errors **strictly smaller** than it, unless a separate endpoint argument is supplied.

## Implementation limits

The complete graph has quadratically many edges in the vertex count. A conservative default limit of 2,000 vertices prevents accidental huge allocations in the reference implementation. It is not a scalable universal decision procedure.

Supply exact rational data and a mathematically valid global Lipschitz bound. The generic grid routine cannot verify a bound for an arbitrary Python callable. For maps returned by `PackedPWA`, the article proves the advertised bound from the validated finite transition table.

The generic compiler accepts finite binary transition tables. It does **not** include an expanded universal interpreter table. The universal theorem fixes a standard universal interpreter abstractly, then applies the fully described compiler to it.

The archive does not contain a Lean proof, an extracted fixed MRDP polynomial, or an extracted ReLU weight list. The fixed polynomial and neural block are existence/construction theorems with explicit dependencies. The quartic for each individual finite graph, in contrast, is directly generated by the code.

## Noise model

Time is discrete, states are real and remain in the compact cube, and adversarial error is measured in the sup norm after each complete update. The ReLU corollary uses error at the three recurrent output coordinates, not independently at every hidden neuron. Finite-precision hardware, parameter errors, stochastic noise, and continuous-time flows require separate analysis.
