# Beyond Enumerable Clock Cones

**Limit Computations, Unique-Path Trees, and Quadratic Diophantine Progress**  
Prepared for Vladimir Reshetnikov, October 2, 2026.

## Read first

`article.pdf` is the complete research manuscript; `article.tex` is its self-contained
LaTeX source, including the bibliography. The principal target is the ProveIt
report's question `lbh:q:spectra`, concerning deadline spectra beyond c.e. cones.

The manuscript proves a tree-bounding realization theorem; realizes every
limit-computable degree as a least clock degree by an explicit first-matching-stage
tree; gives a deferred-check tree construction for effective jump hierarchies;
constructs unions of spectra with no least degree; proves a self-modulus necessary
condition for a least degree; and supplies canonical quadratic finite certificates
and an exact rational affine realization.

This is an unrefereed AI-generated manuscript. Literature-wide priority is not
claimed. Classical unique-path/modulus, jump-hierarchy, and incomparability results
are attributed in the article. The included tests are finite implementation checks,
not Lean/Rocq verification or proofs of the infinitary results. The full intrinsic
classification of least clock degrees is left open.

## Contents

- `article.pdf`, `article.tex`: manuscript and editable source.
- `code/clock_certificates.py`: exact sparse polynomial compiler, natural-domain
  checker, independent list-based stack interpreter, canonical witness generator,
  and first-matching-stage tree predicate. Python standard library only.
- `code/test_all.py`: reproducible exhaustive finite and regression checks.
- `code/verify_export.py`: independent evaluation of the exported monomial list.
- `examples/quadratic_certificate.json`: the complete 1,494-monomial degree-two
  polynomial for the seven-rule test fixture, with 334 declared variables and a
  full natural zero assignment.
- `test_results.json`: actual test results generated in this environment.
- `source_audit.md`: inspected repository anchor, literature, and novelty boundary.
- `build.sh`: rerun tests and rebuild the PDF.

## Reproduce

Python 3.10 or later is required. The delivered run used Python 3.13.5.

```sh
python3 code/test_all.py
python3 code/verify_export.py examples/quadratic_certificate.json
```

The tests regenerate `test_results.json` and the example polynomial. No network,
CAS, or third-party Python library is required. The example verifier checks the
file's declared natural domain, the exact variable set, coefficients, degree,
monomial count, and polynomial value of its supplied assignment. It does not prove
the compiler correct or solve the polynomial.

For the PDF, install a reasonably complete TeX Live distribution with pdfLaTeX,
NewPX, microtype, mathtools, amsthm, booktabs, tabularx, xcolor, enumitem, fancyhdr,
listings, TikZ, tcolorbox, xurl, hyperref, and cleveref. Then:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The bibliography is internal, so BibTeX is unnecessary. `sh build.sh` executes the
complete workflow. The supplied PDF has already been built and visually inspected.

## Important domains and limits

All coordinates of the finite polynomial are **nonnegative integers**. Its
nonnegativity argument is not valid for unrestricted signed or rational witnesses.
The witness count is `3*(T+1) + 9*m*T + k`: the horizon `T` is external and the arity
grows with it. This is not a fixed universal quadratic equation and does not prove
finite-fold or single-fold MRDP. A unique lift for each labelled finite trace is a
more limited statement, proved explicitly in the article.

The seven-rule example is **not universal**. The article proves that one fixed
universal two-stack interpreter suffices in principle, but this package does not
instantiate that universal transition table or claim a numerical universal bound.
The affine substrate uses exact rational coordinates of unbounded precision; no
noise robustness or global continuity is claimed.

The tree checker takes a total computable approximation as a parameter. The
convergence promise is mathematical input, not something the code decides.
`first_matches` additionally takes the limit as a callable; the supplied example
limit is computable. There is no implementation of a noncomputable oracle or a
transfinite halting solver.
