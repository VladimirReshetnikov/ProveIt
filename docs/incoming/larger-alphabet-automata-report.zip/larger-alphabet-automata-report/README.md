# Finite languages over larger alphabets

The main report is article/larger-alphabet-automata.pdf; editable source is alongside it.
For each fixed k>=3, the report proves a positive product comparison with relaxed k-ary trees, transfers their published sharp Theta scale to minimal finite-language DFAs, and derives a logarithmic inverse threshold enclosure. It also provides a uniform finite-level approximation and an exact frozen singular-boundary calculation explaining an obstacle to amplitude proofs.

The state parameter n always means transient states; one rejecting sink is additional. The empty language has n=0. The main comparison starts at n=1. The total-state reindexing appears separately in Remark 1.2.

No positive limiting amplitude, all-orders expansion, effective numerical inverse certificate, or global novelty guarantee is claimed.

## Offline replay

Requires Python 3.11+ (standard library only):

    python run_all.py

To rebuild the PDF from the supplied exact source, additionally requires a TeX Live installation with pdfLaTeX, amsmath, amsthm, mathtools, geometry, lmodern, microtype, enumitem, booktabs, hyperref and xurl:

    python run_all.py --pdf

The replay verifies SHA256SUMS before and after, runs all three independent checks in output/checks, compares generated JSON with expected receipts, and optionally rebuilds the PDF in output/article. It never modifies supplied inputs. The independent exact checker additionally enumerates canonical small acyclic automata directly, avoiding the signed recurrence.

## Contents

- article/: six-page report, TeX source and local-format-compatible build script
- code/: exact renewal/truncation tests, independent automaton enumerator, inverse-model and frozen-boundary checks
- expected/: reproducible JSON outputs
- review/: independent mathematical review, integrated review and visual-QA receipt
- sources/: primary URLs, bounded later-literature/OEIS/semantic-overlap receipt, raw authorized ProveIt search outputs

No third-party full paper is redistributed. The cited published relaxed-tree theorem is an external mathematical input; its full Airy proof is not re-certified here. Numerical inverse-model tests supplement the written proof and do not produce a certified threshold for the original sequence.
