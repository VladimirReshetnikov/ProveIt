# Report130: bounded-outdegree rooted identity trees

## What is proved

For every fixed maximum outdegree d >= 2, the report proves a complete relative asymptotic expansion for rooted, unlabelled, nonplane identity trees, with unique dominant square-root singularity, explicit coefficient recurrences, and all-orders inverse ceiling brackets. The ternary and quaternary specializations are OEIS A116379 and A116380.

The article is standalone. It does not require private notes or previous reports. It makes no global literature-priority claim. The full texts of the Labelle 1992 and Kennedy–McKeon–Palmer–Robinson 1990 articles were not obtained in the literature review; their possible incidental overlap remains unchecked.

## Contents

- `Report130.pdf`: reader-facing article
- `Report130.tex`, `certified_constants.tex`: complete editable mathematical source
- `certificate/certify.py`: unchanged exact-integer outward-interval verifier for d = 3, 4, through the first two relative corrections
- `certificate/certificate.json`: exact reference interval endpoints and diagnostic certificates
- `certificate/a_d3_through_400.json`, `certificate/a_d4_through_400.json`: exact coefficient lists, with index 0 equal to zero
- `certificate/test_certifier.py`, `certificate/tests.json`: supplementary arithmetic and algebra checks and expected output
- `build.sh`: isolated deterministic PDF build
- `verify_package.py`: exact closed-inventory check and optional isolated numerical/PDF replay
- `test_package.py`: mutation rejection and arithmetic-guard regression tests, performed only in disposable copies
- `release_checks.json`: checks actually performed for this release
- `SHA256SUMS`: sorted SHA-256 inventory of every regular package file except the manifest itself

The certificate program has not been modified for this article. Its SHA-256 is `13457a7cadc64fbe0095204859603d575375016627fcc2cc6b8cab7cbe47b00a`; the reference JSON has SHA-256 `3f2afeac4eb02aa59418ec37aa99cee309b691312a40e44e542f833fa262faa0`.

## Verify and replay

Requirements for the numerical steps: Python 3, standard library only. Always pass `-B` to avoid writing bytecode into the package. Commands may be run from any working directory by providing the path to the scripts; the following assume the package is the current directory.

```sh
python3 -B verify_package.py
python3 -B verify_package.py --replay
python3 -B test_package.py
python3 -B -O test_package.py
```

The first command rejects missing files, unexpected files or directories, symlinks, malformed/noncanonical manifests, and any byte mismatch. It verifies identity relative to the supplied manifest; an unauthenticated manifest is not a digital signature.

`--replay` writes only in a temporary directory outside the package. It reproduces the reference certificate in ordinary and optimized Python modes, reproduces the supplementary tests, checks both opt-in coefficient exports, confirms that a repeat export is rejected without changing either file, and checks the package inventory again afterward. No input package file is modified. All correctness guards in the core use explicit exceptions and remain active under `python3 -O`.

The negative regression suite copies the package into disposable temporary directories before introducing missing, extra, modified, symlinked, and malformed-manifest entries. It also checks explicit arithmetic guard failures and a wrong radius locator in both ordinary and optimized Python. It does not mutate the source package or the frozen core verifier.

## Build the PDF

Additional requirements: Bash, pdfTeX/pdfLaTeX, and standard LaTeX packages used by the source (`amsmath`, `amssymb`, `amsthm`, `mathtools`, `geometry`, `lmodern`, `microtype`, `booktabs`, `array`, `longtable`, `xcolor`, `enumitem`, `fancyhdr`, `hyperref`). The release was built with pdfTeX 1.40.26, TeX Live 2025/dev/Debian.

```sh
out=$(mktemp -d)
bash build.sh "$out"
```

The script builds its format and all auxiliary files in another temporary directory, runs three LaTeX passes, rejects overfull boxes and unresolved reference/citation warnings, and copies only the PDF and log to the specified existing directory. The output directory must be outside the source package, and existing PDF/log outputs are not overwritten. On Debian-style installations the script uses the installed TeX trees directly, so a missing per-user format cache does not require writing into the user's home directory.

To replay everything and compare the rebuilt PDF byte-for-byte with this release:

```sh
python3 -B verify_package.py --build
```

Byte-identical PDF reproduction is checked for the specified TeX toolchain. Different TeX or font versions may produce a visually equivalent PDF with different bytes; the exact comparison intentionally reports that as a mismatch.

## Interpreting the mathematics and numerics

The interval endpoints are exact rationals, not rounded equalities. Displaying 90 decimal places records the arithmetic grid, not 90 certified digits. The article's shorter tables are rounded outward. The reference certificate contains the actual widths, strict critical-root sign tests, and enclosing inner-series tails.

The qualitative all-orders proof is general in fixed d. The supplied numerical executable is intentionally specialized to d = 3, 4, N = 400, and local jet degree 6. The article states how to extend the finite recurrence to arbitrary order; it does not claim that arbitrary-order software has already been implemented or tested.

No explicit coefficient-asymptotic remainder constant or starting index is supplied. Accordingly, substituting these constants into a truncated asymptotic formula does not certify an arbitrary finite-n coefficient or finite threshold. The article gives a separate exact monotone enumeration/search algorithm for a specified threshold. The ceiling effect cannot be discarded in an integer inverse law.

The mathematical certificate and its reproducible checks are not proof-assistant verification. No external upload, submission, or publication accompanies this package.
