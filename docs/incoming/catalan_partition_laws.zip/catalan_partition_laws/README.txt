SHARP CONDITIONING AND JOINT LIMIT LAWS FOR CATALAN PARTITIONS
============================================================
Upper multiplicities, a corrected edge distribution, and the total
number of parts

Research article on OEIS A033552
Prepared with ChatGPT, October 5, 2026

Start here
----------
Read catalan_partition_laws.pdf. The article contains the definitions,
full proofs, numerical examples, source discussion, and eight proposed
research directions. Its editable source is catalan_partition_laws.tex.

The topic is the uniform random partition of n into the distinct allowed
sizes C_k = binomial(2k,k)/(k+1), k >= 1: 1, 2, 5, 14, 42, ...
The duplicated value C_0=1 is not included as a second part type.

Main contributions developed in the article
-------------------------------------------
1. A necessary and sufficient total variation criterion for replacing
   the complete upper multiplicity process by independent geometricals.
2. An explicit Gaussian transition curve, and a sharp rate even for
   arbitrarily slowly diverging independent upper windows.
3. A first-order density correction to the joint upper edge, with a
   polynomially weighted L1 remainder of order m^(-2).
4. Uniform maximum tails and an exponentially weighted expansion,
   giving explicit first corrections to its mean and variance.
5. An exponential-sum limit for the total number of parts, convergence
   of moments and moment-generating functions, and independence from
   the phase-dependent upper edge and maximum.
6. A uniform logarithmic mass profile, finite-dimensional Brownian
   bridge fluctuations, and a sufficient class of lacunary extensions.

Here m is the exact continuous saddle cutoff, asymptotic to log_4(n).
The PDF carefully distinguishes proved statements, numerical diagnostics,
and proposed extensions. The conditioning framework and the distribution
family of exponential convolutions are classical. No assertion of global
publication priority or formal proof-assistant verification is made.

Contents
--------
catalan_partition_laws.pdf     Complete article
catalan_partition_laws.tex     LaTeX source
code/verify.py                Exact coefficient and moment calculations
code/audit_correction.py      Independent central Fourier diagnostic
code/README.txt               Detailed computational documentation
data/verification.json        Exact integer numerators and diagnostics
data/correction_fourier_audit.json
                             Fourier diagnostic settings and results
data/phase_functions.json     Periodic functions and exploratory values
data/*_table.tex              Generated tables used by the article
figures/*.pdf                 Vector figures used by the article
figures/*.png                 Raster previews of those figures
requirements.txt             Python packages for reproducing calculations

Build the PDF
-------------
From this extracted directory, with pdfLaTeX and latexmk installed:

    latexmk -pdf -interaction=nonstopmode -halt-on-error catalan_partition_laws.tex

The source uses standard TeX packages, including lmodern, microtype,
geometry, amsmath, amssymb, amsthm, mathtools, booktabs, array, longtable,
graphicx, xcolor, enumitem, fancyhdr, hyperref, and cleveref.
All table and figure inputs are included; compiling does not rerun Python.
Use the ZIP's complete directory, since the standalone TEX file refers
to the included data and figure files.

Reproduce the calculations
-------------------------
With Python 3.10 or later and the packages in requirements.txt:

    python code/verify.py
    python code/audit_correction.py

These commands regenerate the recorded data and figures in place.
To keep the supplied results intact, use separate destinations:

    python code/verify.py --output reproduced
    python code/audit_correction.py reproduced/data/correction_fourier_audit.json

For a smaller run:

    python code/verify.py --sizes 100 1000 10000 --no-plots --output quick_check

The full coefficient calculation uses sizes up to n=1,000,000.
Counts and integer moment numerators are exact. Saddles, infinite
products, numerical integrals, and displayed approximation errors
are numerical evaluations without rigorous interval certificates.
Exploratory fields in the JSON are labelled and are not article theorems.
Versions and calculation settings are recorded in the JSON files.

Checks recorded
---------------
The implementation matches the first 62 inspected OEIS terms, a separate
coefficient recurrence through n=300, exhaustive moment enumeration through
n=40, and a full-vector versus tail-mass total variation identity.
An independently implemented central Fourier calculation checks the edge
correction signs at four much larger saddle cutoffs. Its target is a
continuous canonical mean; it is not an exact integer coefficient test.

Sources and provenance
----------------------
OEIS: https://oeis.org/A033552
Repository: https://github.com/VladimirReshetnikov/ProveIt
Inspected commit: ec4b972dba46c5f0557cdc55964f286c2bcd4899
Source report: Partitions into Catalan Numbers, October 1, 2026
Repository-relative path:
SetTheory/Cardinals/docs/reports/generating-functions-and-asymptotics/
oeis-sequence-asymptotics/a033552-catalan-partitions/article.tex

The starting questions are in Sections 7, 10.4, and 10.5 of that report.
The PDF gives the relevant primary references and explains how the new
derivations extend those questions. The repository itself was not modified.
