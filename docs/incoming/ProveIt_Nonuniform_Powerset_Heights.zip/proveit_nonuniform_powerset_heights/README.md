# Retirement paths and exact heights of nonuniform finitary powersets

A research continuation of the order-theoretic material in Vladimir
Reshetnikov's ProveIt repository. Prepared 24 September 2026.

## Main result

Let Q be a finite nonempty poset. Replace each q by the ordinal chain
alpha_q = omega^(rho_q), where rho_q > 0. Let K(P) be the finitely generated
downsets, including the empty downset, ordered by inclusion.

For a chain A_0 <_H ... <_H A_m of inclusion-maximal antichains, its cost is

    max(alpha_q : q in A_0 \ A_1) + ...
      + max(alpha_q : q in A_(m-1) \ A_m)
      + max(alpha_q : q in A_m).

All these additions are ORDINARY ordinal additions in the displayed order.
The height of K(P) is the largest path cost. A saturated path from min(Q)
to max(Q) suffices, and an explicit chain attains the computed height.

The article proves the formula and extends it, by finite Cantor-normal-form
block expansion, to every finite lexicographic sum of nonzero limit-ordinal
chains. It includes a dynamic program, examples, coefficient-pattern
invariance, proof and verification audits, and nine further research questions.

## Research status

The nonuniform height formula addresses a gap explicitly left in ProveIt's
`cofinal-strata-of-finitary-powersets` README and proof audit. The uniform
formula and the persistent-coordinate counterexample are credited to that
prior report and are not presented as new results here. Complete conventional
proofs are supplied; independent peer review, Lean formalization, and an
exhaustive global priority search have not been completed.

The result is about HEIGHT, not maximal order type or width. It does not
assert the unrestricted result for arbitrary WPO fibres, finite or successor
fibres, repeated powersets, or infinite skeletons.

Repository snapshot:
`e21766d04c2b8a9b2cdba0cd43e563024b3bd1b9`.
See SOURCES.md for the inspected files and primary literature.

## Contents

- `article.pdf` and `article.tex`: complete article, with embedded bibliography.
- `code/retirement.py`: independent exact ordinal arithmetic and height evaluator.
- `code/verify.py`: deterministic finite verification suite.
- `data/*.json`: examples, path certificates, and recorded verification results.
- `PROOF_AUDIT.md`: logical dependencies, sensitive steps, and limits.
- `SOURCES.md`: source and novelty-scope record.
- `Makefile`: rebuild and verification commands.

No third-party source articles or font files are distributed.

## Run

Python 3.10 or later; no third-party Python packages are needed.

```sh
python code/retirement.py data/persistent_large_coordinate.json
python code/retirement.py data/branching_frontiers.json
python code/retirement.py data/limit_fibres.json
python code/verify.py
```

The supplied run used Python 3.13.5 and passed **3,210,888 assertions** on
5,231 nonempty naturally labelled posets through six vertices and 128,793
weighted instances. The all-chain brute-force oracle was used on 90,201
weighted instances through five vertices. All counts are recorded in
`data/verification_results.json`.

These are finite structural and implementation checks, not a computation of
infinite tree ranks or a proof-assistant certification. The transfinite
upper bound is proved separately in the article.

## Pure-fibre JSON input

```json
{
  "n": 3,
  "edges": [[1, 2]],
  "exponents": [2, 1, 1]
}
```

Vertices are numbered 0 through n-1. Edges may be Hasse edges or any acyclic
relation with the intended transitive closure. Exponents must be positive
integers; the above means an isolated omega^2 beside omega + omega. Omitting
both fibre fields defaults to exponent 1 at every vertex. An empty skeleton
is accepted separately and has height 1 because K(empty) is a singleton.

Integer exponents can also be interpreted as ranks in any finite ordered
list of positive ordinal exponents: replace output exponents by the same
ordered labels. The article proves this coefficient-pattern invariance.
The code is not a general parser for arbitrary ordinal notations.

The certificate gives the height in exact Cantor normal form, a maximizing
saturated frontier path, retirement groups, edge/terminal weights, and pivot
vertices for the attaining-chain construction. Use `--output filename.json`
to write the result to a file.

## Nonzero limit fibres

Use `fibres_cnf` instead of `exponents`:

```json
{
  "n": 2,
  "edges": [],
  "fibres_cnf": [
    [[2, 1], [1, 1]],
    [[3, 1], [2, 1]]
  ]
}
```

Each CNF is a list of [exponent, positive coefficient] pairs in strictly
decreasing exponent order. This example gives the two incomparable fibres
omega^2 + omega and omega^3 + omega^2. Its answer is omega^3 + omega^2*2.
Exponent 0, empty fibres, cycles, and conflicting input modes are rejected.
The algorithm expands coefficients into blocks, so large coefficients or
many vertices may lead to expensive frontier enumeration.

## Rebuild the PDF

A standard TeX installation with pdfLaTeX, New PX, AMS packages, TikZ,
tcolorbox, microtype, hyperref, and the other packages in the preamble:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

No BibTeX run is required. Alternatively run pdflatex three times.
`make verify` reruns the tests; `make clean` removes TeX intermediates.
Nothing in this package modifies or commits to the user's GitHub repository.
