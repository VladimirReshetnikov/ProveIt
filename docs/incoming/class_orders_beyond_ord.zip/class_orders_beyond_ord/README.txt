DEFINABLE CLASS WELL-ORDERS BEYOND ORD
Arithmetic, canonical notation, fixed-point completion,
and the limits of uniform definability

Research report prepared for Vladimir Reshetnikov
5 October 2026

CONTENTS

class_orders_beyond_ord.pdf
    The complete 40-page article, including proofs, examples, an axiom
    ledger, ten bibliographic references, and thirteen research questions.

class_orders_beyond_ord.tex
    Self-contained LaTeX source. The bibliography is inline. There are
    no external figures, section inputs, or bibliography database files.

artifacts/finite_notation_checks.py
    A Python 3 program illustrating the finite support-splitting and
    support-flattening maps and comparing hereditary terms with finite
    numerical specializations. It uses only the Python standard library.

artifacts/finite_notation_results.json
    Recorded successful results and ordered notation examples.

README.txt
    This guide.

BUILDING THE PDF

Use a standard TeX Live or MiKTeX installation with the packages named
in the source. From the directory containing the source, run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error class_orders_beyond_ord.tex

Alternatively, run the following command until the contents and
cross-references stabilize, normally three passes from a clean directory:

    pdflatex -interaction=nonstopmode -halt-on-error class_orders_beyond_ord.tex

No network connection is needed once the LaTeX packages are installed.

RUNNING THE FINITE ILLUSTRATIONS

From the extracted archive directory, run:

    python3 artifacts/finite_notation_checks.py

The script rewrites artifacts/finite_notation_results.json. The included
run passed 1,825 splitting cases, 21,993 flattening cases, and 2,700
comparisons involving 30 hereditary terms interpreted at bases 5, 7, 11.
Its coefficients are natural numbers, only a fragment of the article's
ordinal-coefficient syntax. These checks do not prove infinite or class
well-foundedness and are not a proof-assistant formalization.

READING GUIDE

Sections 1-2: Scope, provenance, axioms, class well-orders, initial
embeddings, set-likeness, and the interpretation of the symbol Omega.

Section 3: Sums, products, finite-support powers, exponent laws,
cofinality, and the choice-free finite-support theorem (Theorem 3.1).

Section 4: Canonical condensation, finite normal forms, the local
history criterion (Theorem 4.8), and the comparison/history equivalence
over GB without set Choice or Global Choice (Theorem 4.9).

Sections 5-6: Hereditary notation; an explicit polynomial fixed point;
finite-trace fixed-point completion (Theorem 5.7); the exact local
extension criterion (Theorem 5.8); the global equivalence of fixed-point
extension, strong comparison, and canonical histories (Corollary 5.9);
and systematic notation rules and worked examples.

Section 7: Strict bounds for uniform families (Theorem 7.2) and a
separate escape order for each fixed definability level (Theorem 7.5).

Sections 8-9: The distinction between comparison and class-valued ETR;
the full external spectrum over an inaccessible V_kappa (Theorem 9.1);
definability-sensitive cutoffs (Theorem 9.2); and rigorous formalization
routes through definable classes, GB/GBC, ETR, KM, and larger universes.

Section 10: Thirteen proposed research questions, with a practical
sequence of next steps. Appendix A records proof status and validation.

AXIOMS AND STATUS

GB in this article means two-sorted Godel-Bernays theory with ZF sets,
elementary comprehension with class parameters, and Class Replacement.
It includes neither set Choice nor Global Choice. GBC adds Global Choice.

Theorems 3.1 and 4.9 hold over the stated choice-free GB base. The fixed-
point construction and local criterion in Section 5 retain GBC. Theorem
7.2 uses GB and a supplied well-order of the index class. The full-model
spectrum is an external theorem in ambient ZFC for strongly inaccessible
kappa; its hypotheses should not be suppressed.

The article gives prose mathematical proofs, with separate proof audits
during preparation. It is unrefereed and is not Lean-verified. Its novel
contributions are identified relative to the inspected repository, not
as independently established literature-wide priority. In particular,
the article does not claim to solve whether class-well-order comparison
implies full elementary transfinite recursion.

SOURCE PROVENANCE

The relevant ProveIt article was inspected at commit:

    f158f27b46bd1efb5a771ffc3c07e64eea970501

Repository path:

    Algebra/SurrealNumbers/docs/foundations-and-computation/surreal-well-orders/article.tex

Pinned source:

https://github.com/VladimirReshetnikov/ProveIt/blob/f158f27b46bd1efb5a771ffc3c07e64eea970501/Algebra/SurrealNumbers/docs/foundations-and-computation/surreal-well-orders/article.tex

Existing polynomial, condensation, and comparison results receive
explicit credit. Classical class epsilon notation is credited through
Jeon's note and its reference to Rathjen. The bibliography also includes
the relevant class-recursion, forcing, model-theory, and 2026 literature.

The archive is a standalone report. No repository changes were made.
