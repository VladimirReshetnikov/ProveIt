# Growing logarithmic degrees in A290268

The five-page `article.pdf` proves two extensions of the fixed-logarithmic-degree central phase theorem:

- For each fixed integer offset b and every prescribed K(d)=o(d), the coefficients H(d,k,2d+b) are eventually nonzero uniformly for all 0<=k<=K(d), except the proved reflection holes
- For each fixed b, there is a positive constant eta_b such that the same nonvanishing holds throughout 0<=k<=eta_b d at all sufficiently large depths

The sublinear range also has a precise phase law with a modified positive saddle amplitude. The constant linear range asserts nonvanishing without claiming that unchanged limiting phase. No numerical eta_b or depth threshold is supplied, and b is fixed. The full support conjecture remains open.

The proof is self-contained after the explicitly cited coefficient model and factorization from ProveIt. It uses algebraic root bounds, an exact angular inequality, and an elementary contour saddle calculation. It requires no finite numerical certificate, simulation, or extrapolation. Its mathematical argument received independent review; it has not been formalized in Lean or externally refereed.

`article.tex` is the complete source. Compile twice with pdfLaTeX using standard TeX Live packages, or use `build_local.sh`, the wrapper used for the included PDF. All five PDF pages were visually inspected.

Source comparison is pinned to ProveIt commit `ca81647a9f679e96d49ffdbc54b0c0ab13d10a36`. The bibliography contains the full source location and classical polynomial-family reference. This report is a continuation of the separately prepared *Arithmetic Nonvanishing and Central Phase Laws for OEIS A290268* and does not change that earlier artifact.
