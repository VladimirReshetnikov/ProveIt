# A330266 uniform tail repair

This is a repair note for the existing ProveIt report on balanced Smirnov words and fixed-multiplicity shuffles. It does not claim a new proof of the source's already proved leading Poisson law or e^(-(k-1)) equivalent.

## Mathematical result

The model-specific bound E[(X_{n,k})_m] <= (k-1)^m holds for every n >= 1 and every integer m >= 0. Together with a positive complete-homogeneous-polynomial remainder, it proves the compact-uniform all-orders operator expansion with an explicit finite constant. A separate logarithmic-degree argument establishes the factorial-cumulant scale. The source's correction, local probability, count, and ratio expansions are thereby justified. The inverse estimate is justified along actual sequence values and for a specified smooth carrier; certified integer thresholds remain separate.

The next coefficient is also derived. For k=4,

e^3 p(n,4) = 1 - 9/(8n) - 3/(128n^2) + 189/(1024n^3) + 7395/(32768n^4) + O(n^-5).

## Files

- `repair_note.pdf`: seven-page proof, claim audit, fourth correction, and further questions
- `repair_note.tex`: complete editable mathematical source
- `check_repair.py`: exact symbolic and integer/rational checks; requires SymPy 1.14.0
- `run_checks.sh`: normal and optimized checks plus deliberately corrupted-coefficient rejection
- `independent_check.py` and `AUDIT.md`: a separate finite-PGF recurrence, brute-force small cases, and mathematical review
- `build_local.sh`: reproducible local PDF build with a writable TeX cache
- `coefficients.json` and `symbolic_checks.txt`: checked coefficient output
- `source_manifest.json`: immutable source URLs and Git blob identities
- `source/`: four byte-identical reviewed source files from the original report
- `MANIFEST.sha256` and `verify_manifest.py`: package-integrity verification

## Reproduce

With Python 3, SymPy 1.14.0, and the supplied Linux TeX Live layout:

1. Run `python verify_manifest.py`
2. Run `bash run_checks.sh`
3. Run `bash build_local.sh`

The main check script tests 14,850 exact factorial-coefficient inequalities and 19,434 exact scalar-remainder inequalities. It computes the full general-k operator expansion through fourth order, verifies the reported lower-order terms, and checks the displayed fourth-order probability and log-probability formulas. The independent checker uses the finite-PGF coefficient recurrence through order four and v-degree twelve, and enumerates rank words for six small parameter pairs. All validation gates use explicit exceptions and survive Python's `-O` mode. The negative test changes a computed coefficient, so it must fail rather than silently produce a wrong report.

The build script redirects TeX-generated caches into a local `build/` directory, avoiding writes to protected home directories. Its fixed source epoch is 2 October 2026 UTC. It rejects overfull/underfull boxes and unresolved reference warnings. Render the PDF independently for visual review if changing the mathematical source.

On other TeX Live installations, the mathematical source also builds with the usual two-pass `pdflatex repair_note.tex` command; the convenience script's `TEXMF` paths are specific to the tested Linux environment.

## Source and status

Original repository: https://github.com/VladimirReshetnikov/ProveIt

Reviewed immutable commit: `4b874cea0012c51a6841ad9c58f6e20fa57c71da`

Original report path: `SetTheory/Cardinals/docs/reports/generating-functions-and-asymptotics/oeis-sequence-asymptotics/a330266-balanced-smirnov-poisson/`

The article blob is `afa43ce608b793d078a8887392766122ec36293a`. Full URLs and all four source hashes are in the source manifest and are checked before mathematical verification runs.

AI-assisted, unrefereed, not formally verified. No literature-priority claim. Numerical and symbolic tests supplement the written proof. No repository files or OEIS entries have been changed, and this package does not authorize publication.
