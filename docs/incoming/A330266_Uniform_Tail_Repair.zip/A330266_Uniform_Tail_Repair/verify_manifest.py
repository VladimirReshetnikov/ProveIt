#!/usr/bin/env python3
"""Fail-closed verification of every file listed in MANIFEST.sha256."""
import hashlib
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
rows = (ROOT/'MANIFEST.sha256').read_text().splitlines()
if not rows:
    raise ValueError('Empty manifest')
seen = set()
for row in rows:
    digest, name = row.split('  ', 1)
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or name in seen:
        raise ValueError(f'Invalid or duplicate manifest name: {name}')
    seen.add(name)
    if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
        raise ValueError(f'Invalid SHA256 digest: {name}')
    actual = hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    if actual != digest:
        raise ValueError(f'Package integrity mismatch: {name}')
print(f'Package integrity verified: {len(seen)} files')
