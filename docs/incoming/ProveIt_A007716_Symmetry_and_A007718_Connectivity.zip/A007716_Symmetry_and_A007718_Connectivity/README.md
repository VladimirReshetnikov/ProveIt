# Rare Symmetries and Connected Bipartite Multigraphs

A probability companion for OEIS A007716 and a complete fixed-order asymptotic and inverse-growth transfer for OEIS A007718.

## Results

For a uniformly sampled isomorphism class of n-edge bipartite multigraphs with distinguished shores and no isolated vertices, write w=W(n).

- Nontrivial vertex symmetry has probability 2w^3/n + O((1+w)^7/n^2).
- Apart from probability O((1+w)^6/n^2), the vertex automorphism group is trivial or a single C2 swapping two degree-one vertices with a common neighbor.
- Disconnection has probability w^2/n with the explicit second correction in the article; an isolated-edge component accounts for the leading term.
- The connected counts c_n=A007718(n), n>=1, satisfy c_n=sum_{j=0}^J b_j a_{n-j}+O_J(a_{n-J-1}) for every fixed J, where b(z)=1/sum a_n z^n.
- This yields rational-coefficient relative asymptotic expansions at every fixed order, explicit smooth inverse models, rigorously widened integer-threshold brackets, and non-P-recursiveness for A007718.

Automorphisms here act on vertices and preserve the two shores. Permutations of parallel edges are separately accounted for as a kernel, not counted as vertex symmetries. The connected-count convention is c_0=0; OEIS assigns a separate conventional value 1 at zero.

## Contents

- article.pdf and article.tex: the ten-page report and editable source
- code/: exact standard-library checkers and recorded JSON outputs
- build_local.sh: a two-pass local LaTeX build using writable format/cache locations
- verify_local.sh: cleanly replay the supplied exact checks, validate the unchanged prior archive, and rebuild the PDF
- verification.md: scope, review and reproducibility notes
- dependency/: the preceding A007716 asymptotic package, unchanged
- SHA256SUMS: manifest of all included deliverables other than the manifest itself

## Replay

Run `bash verify_local.sh` from this directory. Python 3, unzip, sha256sum, and a TeX Live installation containing pdfTeX, Latin Modern, AMS packages, microtype, hyperref and xurl are required. The build uses the system TeX trees at /usr/share/texlive/texmf-dist and /usr/share/texmf; adjust those paths for a different installation. No network connection is required.

The proofs explicitly depend on the preceding report's established all-orders asymptotic, marked-cycle bounds, weighted tail estimate and Ewens factorial moments. Its complete original ZIP is included unchanged. New proofs and exact checks are supplied here, but neither this package nor its dependency is a Lean formalization or a refereed publication. All asymptotic orders are fixed; effective constants and numerical onset are not claimed. No exhaustive priority claim is made.
