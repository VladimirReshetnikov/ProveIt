# Hall Bottlenecks and the Limits of Rank Normalization

**Exact counterexamples, a complete rank-six phase diagram, and fixed-parameter counting of matching supports.**

Prepared for Vladimir Reshetnikov by ChatGPT, 30 September 2026.

## Main result and scope

The article gives an explicit negative answer to the universal **two-shore positively weighted** rank-normalization strengthening of matching-support ultra-log-concavity.

The lead example is the graph H_{4,11}: each shore has 11 outer vertices and four core vertices; all bipartite edges are present except those between the two outer blocks. Give each core vertex weight 500 and each outer vertex weight one. The graph has 30 vertices, 104 edges, and maximum matching size eight. If its weighted support polynomial is sum a_k t^k, then

    7*a_7(w)^2 - 16*a_6(w)*a_8(w)
      = 9*3025^2*w^14*(-w^2 + 480*w + 2304),

whose quadratic factor is -7696 at w=500. The polynomial remains ultra-log-concave with the established smaller-shore normalization 15.

Other proved results include a complete symmetric core-three/rank-six activity phase diagram; the general-core endpoint threshold; the exact uniform normalization of a forced-core limiting family, which imposes a universal lower bound asymptotic to 4r/3; a universal first rank-normalized inequality with a defect identity and equality classification; and exact counting parameterized by matching rank.

These statements count **support pairs**, once each, not individual matchings. The unit-weight and one-shore-only rank-normalization questions are not settled here. No minimality claim is made for the 30-vertex example. The full phase classification is for the defined core-three family, not for all rank-six graphs. The limiting-family order is a lower bound, not a universal upper bound. There is no Lean formalization. Priority beyond the targeted reviewed sources is not certified.

## Files

- `article.pdf`: compiled article, with nine proposed research questions.
- `article.tex`: self-contained LaTeX source; appendix tables are embedded, so this source does not require the `tex/` directory to compile.
- `code/support_count.py`: exact graph-counting API using the Python standard library.
- `code/verify.py`: exact computational and symbolic verification driver.
- `data/`: full witness, exact coefficient/margin data, threshold tables, positivity certificates, provenance, and executed verification transcript.
- `tex/positivity_tables.tex`: regenerated copy of the tables embedded in the article; the verifier checks that they agree.
- `build.sh`: two-pass PDF build.
- `requirements.txt`: tested symbolic-check dependency.

## Reproduce the verification

Use Python 3.10 or later. The delivered run used Python 3.13.5 and SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python code/verify.py
```

The counting module itself does not require SymPy. The verifier checks all 512 labeled 3-by-3 graphs under two sets of weights, 200 additional seeded rationally weighted graphs, 36 small Hall-family instances, and the full 30-vertex witness. For that witness, the closed formula, cover-type algorithm, and independent exhaustive support enumeration all agree. Symbolic identities and finite positive-coefficient certificates are checked with exact arithmetic. The output files are written relative to the script, independent of the current working directory.

The main algorithm is a reference implementation. Its fixed-parameter dependence can be prohibitive at large matching rank. Use `brute_force` only for small graphs; its memory and time are exponential in the shore sizes. Exact rational weights must be supplied as integers or `fractions.Fraction`, not floats.

Example, from the package root:

```python
import sys
sys.path.insert(0, "code")
from support_count import hall_graph, support_polynomial, ulc_margins

s, n, w = 4, 11, 500
weights = [1] * n + [w] * s
p = support_polynomial(hall_graph(s, n), n + s, weights, weights)
assert ulc_margins(p, 8)[-1] < 0
assert all(x >= 0 for x in ulc_margins(p, 15))
```

## Rebuild the PDF

A TeX Live installation with pdfLaTeX, AMS packages, `newtx`, `microtype`, `geometry`, TikZ, `booktabs`, `enumitem`, `fancyhdr`, `listings`, `xurl`, and `hyperref` is sufficient.

```sh
sh build.sh
```

Or run `pdflatex -interaction=nonstopmode -halt-on-error article.tex` twice. No BibTeX run is required. The bibliography is included in the source. A PDF rebuild can have different metadata and need not be byte-identical.

## Repository provenance

Repository: https://github.com/VladimirReshetnikov/ProveIt

Pinned commit: `0a543d5e435df885f78ca731d71856f3ee0ab2d4`.

Target: `SetTheory/Cardinals/docs/reports/enumerative-combinatorics/preorder-root-polytopes/article.tex`, blob `ba1cc4a6c99abd5ff808aae97df75efe434833e9`, especially lines 8190–8335 and 8400–8590 at that pin. The article records what was read and distinguishes published results, repository motivation, new derivations, exact tests, and unsettled questions.
