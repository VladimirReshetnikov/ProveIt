# Research Report48

Exact fusion of the ant background polynomials. The independently audited literal-1/3 sources have 14,658,934 operations for two raw positive inputs and 14,658,944 for one. They compute exactly the same complete integer polynomial as the frozen Reports44/47 sources, preserving 465/467 positive witnesses, one final equation and exact degree 2,304,000.

This package is a new release. It does not replace or modify the frozen predecessors. The theorem is an arithmetic-source refinement, not a numerical bit-complexity estimate, global optimum, operation-record claim or stronger ant-dynamics theorem.

## Contents

- Research_Report48.pdf and Research_Report48.tex: the report and editable LaTeX
- block_groups.tex and release_evidence.tex: included tables and provenance
- science/: exact frozen author packet, including the literal-source generator, finite profile data, authenticated owned arithmetic generators and receipts
- independent_audit/: unchanged independent proof, checker sources and receipts
- audit_replay/: separately authenticated relocation adapter and its test evidence for the unchanged audit scripts
- references/: the frozen Report47 PDF/LaTeX, manifest and complete reproducibility ZIP, which also contains its authenticated Report44 reference
- verification/: provenance, independent manuscript review, preservation and final reproduction evidence
- verify_release.py, build_pdf.py, archive_release.py: authenticated isolated replay and deterministic artifact builders

The frozen author's README calls the result a candidate awaiting audit. That text is historical evidence preserved byte for byte. The later independent audit verdict is PASS and is included separately.

## Trust and authentication

Obtain the SHA256 of MANIFEST.json from the delivery message or another trusted channel. A manifest stored alongside its own files is an integrity inventory, not an independent trust anchor. Authenticate these helper bytes externally before running them. Do not use Python -O: scientific checks require assertions enabled. No network or package installation is required.

Read-only inventory check:

    python3 -I -B verify_release.py --manifest-sha256 TRUSTED_MANIFEST_SHA256 --verify-only

Full isolated science replay, including independently reconstructed complete sources and exact polynomial weights:

    python3 -I -B verify_release.py --manifest-sha256 TRUSTED_MANIFEST_SHA256 --output /new/external/replay-directory

The output directory must not exist, its parent must exist, and it must be outside this release. Replay copies the science packet, safely unpacks and authenticates the supplied Report47 baseline, disables bytecode, reruns author checks, and runs the unchanged independent scripts through the narrow relocation adapter. Original release bytes, modes and modification times are checked before and after. No physical ant/color recipe or saved upstream schedule implementation executes. Fixed physical-program JSON is compilation data for the owned occurrence compiler.

Receipt comparison is exact for author generation/checks and all five independent evidence JSON objects; no normalization is required. The symbolic identities and independent exact coefficient checks establish equality; modular samples are supplementary regression tests.

## Rebuild the PDF

Requires local Python3, TeX Live pdfLaTeX and the standard packages used in the source. Shell escape is disabled and SOURCE_DATE_EPOCH is fixed. No packages are fetched. Use a new or empty external build directory:

    python3 -I -B build_pdf.py --manifest-sha256 TRUSTED_MANIFEST_SHA256 --check-packaged --output /new/external/pdf-directory

The build checks byte equality with the packaged PDF on the recorded compatible toolchain. Different TeX versions may legitimately produce different PDF bytes; that does not change the scientific source.

## Rebuild the ZIP

    python3 -I -B archive_release.py --manifest-sha256 TRUSTED_MANIFEST_SHA256 --output /new/external/Research_Report48_reproducibility.zip

The ZIP uses sorted members, fixed timestamps, fixed Unix modes and deterministic deflate settings. The output must not exist and must be outside the release.

## Key arithmetic identities

- Two inputs: 5,971,120 multiplications + 8,687,814 additions/subtractions = 14,658,934
- One input: 5,971,124 multiplications + 8,687,820 additions/subtractions = 14,658,944
- Retained constant prefix: 14,563,366
- Fused spatial source: 92,107
- Other retained main gates: 3,461 / 3,471
- Removed dense Horner gates: 2,303,996
- Savings versus the corresponding Report47 source: 16,729,897

Complete two-input stream SHA256:
62cf59e79cd5d3baf61b19ed50ccc8965e8fb4814bbdc33a6d7fad417d379667

Complete one-input stream SHA256:
722340689ce84f505af7d010db21d6b48178c5d6008b28966e9836aeca75b25b

The source is generated and hashed symbolically; the huge coefficient integers and full multi-million-record stream are not materialized. Only literal 1 and 3 are constant leaves, and all 598 surviving old constant ports are bound. All modulo operations in the new factorization apply to fixed coefficient indices; no identity W^576000=1, division by W or exception at W=0, +/-1 is used.
