# Perfect Transcendence Gaps in Borel Arithmetic

**Standard systems, p-adic shadows, Hahn fields, and omnific integers**

Research manuscript prepared for Vladimir Reshetnikov, October 3, 2026.

## Start here

Read `article.pdf` for the complete 26-page article. Its editable, self-contained LaTeX
source is `article.tex`. The manuscript has 14 main sections, two appendices,
12 bibliography entries, and 11 proposed further research questions.

The starting point is Elliot Glazer's theorem that Borel models of elementary
function arithmetic cannot have full standard system. The application uses
nonstandard Borel models of full Peano arithmetic, not arbitrary weak models.
ProveIt's arithmetic coding and surreal/omnific developments motivate the
local-field and Hahn-series bridge.

## Principal statements

**Theorem 1.1 — a countable-parameter-robust perfect gap.** If F is R or Q_p and
K is a proper analytic subfield relatively algebraically closed in F, then
for every external countable C in F, H = acl_F(K(C)) remains proper. Every
finite polynomial-dependence relation over H is null and meager. Every
nonempty open subset of F contains a Cantor set algebraically independent
over H. Thus trdeg(F/H) is continuum.

**Lemma 4.1 — the mechanism.** An analytic subfield of R or Q_p cannot have
positive finite or countably infinite transcendence degree in the ambient
field. A hypothetical countable transcendence basis would give a nonzero
derivation whose graph is analytic; automatic continuity contradicts its
vanishing on the dense rational subfield.

**Theorem 7.1 — the exact arithmetic image.** If M is any nonstandard PA model,
S is its standard system, and D = M-M, then the image of the standard residue
map D -> Z_p is precisely K_p(S) intersect Z_p, where K_p(S) consists of points
with a fast name computable from some member of S. The fraction field of this
image is K_p(S). Borelness is not needed for this exact identification; it is
needed for the stated descriptive and perfect-gap consequences.

**Theorem 7.3 and Corollary 7.4 — the full profinite image remembers S.**
The canonical image B(S) in the profinite integers consists exactly of residue
sequences computable from one oracle in S. Its idempotents are exactly the
0/1 prime-coordinate patterns indexed by the members of S. When S is proper,
B(S) is strictly smaller than the product of its individual p-adic images.
Thus local realizability at every prime does not imply simultaneous realization
by one element of the arithmetic model.

**Theorems 9.1 and 10.1 — the Hahn and omnific bridge.** Scalar independence
over K persists over K((t^G)) for every set-sized ordered abelian group G.
With t = omega^-1, a Cantor coefficient set P gives continuum many same-scale
omnific integers r*omega, independent over the specified restricted
coefficient Hahn field and zero in every ordinary finite congruence quotient.

**Theorem 8.2 — identical completions do not determine canonical images.**
A signed nonstandard PA ring and the tail ring Z+I have the same finite residue
towers and Z_p completions, but their canonical images are respectively
K_p(S) intersect Z_p and Z.

## Scope and status

This is an AI-assisted, unrefereed research manuscript. Complete ordinary
mathematical proofs are supplied for the deductions developed here. Glazer's
standard-system theorem, Mycielski's theorem, classical descriptive set theory,
quantifier elimination, and the real dimension corollary's Edgar–Miller input
are identified rather than presented as new proofs. Historical priority for
the assembled theorem or its components has not been established. This is not
a claimed solution to Scott's general problem.

No Lean or Rocq implementation of these new deductions is included or claimed.
The repository was not rebuilt. Its relevant documentation was inspected at
commit `7d9b8b957fa6a1cc28636ac8fce3cfaa6d230031`. The distinction between
standard-natural formula evaluation and internal PA derivability is made
explicit in the proposed formalization plan.

The independent omnific family is **Cantor-parameterized by its real
coefficients**, but **discrete in the surreal order topology**. Independence
is over the specified restricted coefficient field, not over the full real
or surreal field. The construction uses set-sized Hahn fields and does not
treat the proper class of all surreals as a set.

## Reproduce the checks

Requirements: Python 3.10 or newer, standard library only.

```sh
python3 verify.py
```

This writes `verification.json`; a report from the executed checks is included.
An alternate output path can be supplied with `--output`.

The checks passed for 23,941 base-p digit words (p = 2, 3, 5, 7; lengths 0–5),
including 139,168 prefix-residue comparisons and 23,941 uncontrolled-tail
recodings. They also passed 38,000 exact finite Laurent-tail identities on
1,000 seeded sample pairs and seven exact Newton stages for a 7-adic root of
X^2-2. The profinite extension additionally checks 720 factorial-residue
samples, 15,120 finite coherence comparisons, all 16 idempotents modulo 8!,
and 272 Boolean-operation identities. There is no floating-point arithmetic
in these checks.

These are finite regression tests. They do not verify perfect sets,
uncountable algebraic independence, nonstandard models, arbitrary Hahn
supports, or the correctness of a proof-assistant formalization.

## Rebuild the PDF

Use a LaTeX installation with the packages named in the preamble, including
newtx, amsthm, mathtools, microtype, tcolorbox, and hyperref:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `pdflatex article.tex` three times. The bibliography is
embedded; BibTeX and external image assets are not required. The supplied PDF
was compiled and rendered for layout inspection. Recompilation can produce a
different PDF hash because of timestamps or TeX versions.

## Other package files

`theorem_ledger.md` maps the main statements to dependencies and proof status.
`source_audit.md` records primary sources, versions, repository paths, and
read/verification boundaries. `SHA256SUMS` records the supplied files' hashes.
No third-party papers or font files are redistributed.
