# Sharper asymptotic bounds for A202058

This standalone addendum proves new asymmetric bounds for ascent sequences in which each value occurs at most twice. The frozen root-limit foundation is bundled unchanged. No external publication has been made.

## Main result

Let μ=8/(3π²). There are fixed positive constants C1,C2 such that, for all sufficiently large n,

    −C1 n^(2/3)(log n)^(5/3)
      <= log(a_n/(n! μ^n))
      <= C2(log n)².

In particular, a positive stretched-exponential correction exp(c n^σ), c,σ>0, is impossible. The upper bound does not exclude a negative stretched exponential of small exponent.

For N(y)=min{n:log a_n>=y}, T=3π²/8 and x=y/W(y/(eT)),

    x−O(log x) <= N(y) <= x+O(x^(2/3)(log x)^(2/3)).

The report includes detailed proofs, independent mathematical review, exact checks, numerical evidence and explicit open questions. The proposed leading correction +(2/3)(log n)² is a conjecture. No asymptotic equivalent, limiting prefactor, ratio limit or all-orders expansion is asserted.

## Start here

- `a202058-fine-addendum.pdf`: standalone readable addendum
- `a202058-fine-addendum.tex`: editable mathematical source
- `audits/independent-mathematical-audit.md`: independent integrated review
- `verification-summary.json`: final verification and release checks
- `qa/visual-review.md`: all-page visual review
- `SHA256SUMS`: file integrity manifest

## Rebuild and verify

A normal TeX Live installation with pdfLaTeX, the listed Python packages, a C++17 compiler and GMP development libraries is sufficient. Poppler is used for PDF rendering. Install Python dependencies with `python3 -m pip install -r requirements.txt` if needed.

    ./build.sh
    ./verify.sh
    ./verify.sh --full

The quick verification regenerates coefficients through 176. Full verification regenerates all 400 exact terms and all 1000 long-double terms and takes several minutes, with substantial memory use. Both modes run the weighted residual/padding checks, generic suffix log-concavity checks, exact small-polynomial obstructions and the frozen radius/root-limit checks.

The verification scripts compare exact counts as integers. Floating checks use a platform-tolerant replay diagnostic and are not rigorous numerical error certificates. Terms 401–1000 remain numerical approximations. The PDF build uses fixed metadata to support byte-identical rebuilds in the recorded toolchain.

    python3 qa/check_pdf.py
    python3 create_bundle.py

The first command renders every PDF page and performs structural checks; it does not replace visual inspection. The second recreates the deterministic ZIP and SHA-256 manifest, omitting compiled executables, caches and the build directory.

## Included dependencies and research

- `dependencies/frozen-foundation/`: unchanged PDF, TeX, proofs, checks and audits for the previously established root limit
- `dependencies/frozen-foundation.zip`: the exact original archive
- `support/fine-research/`: new proof notes, literature review, kernel calculations, exact/numerical generators, raw counts and fit diagnostics
- `support/fine-research/source-provenance.json`: original archive hash and source comparison
- `support/fine-research/numerics/README.md`: detailed numerical reproduction instructions and caveats

The report itself restates the operator, characteristic identities and comparison arguments it uses. The bundled foundation supplies the original recurrence justification and endpoint evaluation. The scoped literature/ProveIt check is negative evidence only, not a comprehensive novelty certificate.

## Remaining mathematical work

The improved positive barriers do not identify individual coefficients sharply enough for a full equivalent. The formal frozen-circle calculation points to 2/3, but a weighted finite-state-to-bulk estimate and a coefficient-transfer theorem are still missing. The original-profile transformed process is nearly trapped at its initial state; an unweighted typical-growth argument cannot bridge that gap. Global factorial-normalized log-concavity is plausible from the exact checks but remains unproved.
