SMALL ZFC-CONSISTENCY MACHINES
Research report and reproducible artifacts, 16 October 2026
Prepared for Vladimir Reshetnikov

START HERE

Read report.pdf for the mathematical results, source audit, exact proposal,
proofs, counterexamples, and verification boundaries. report.tex is its
complete editable LaTeX source.

The recommended NEW artifact is machines/raw-candidate-old_rho6-248.tm:
248 working states, 496 transitions, two symbols, blank symbol 0, start
state 0, and terminal target 248. It includes the existing blank initializer.
It retains the original quantifier axiom. The equal-sized dual-row variant
is included for comparison.

These 248-state machines are research candidates. No new theorem equating
their blank-tape nonhalting with Con(ZFC) is claimed. The equality-free
calculus calibration and complete binary-interpreter simulation remain
open. A finite register-operation certificate verifies the new grammar
compression against its source program; this is a local result.

The prior 253-state benchmark table is included separately. Its upstream
PR has end-to-end Coq theorem sources and a successful complete CI check.
This report inspected those sources and the CI log; it did not rebuild
Coq locally or claim the prior machine as a new result.

REPRODUCE THE FINITE ARTIFACTS

From this directory, with Python 3.12 (the tested version):

    python3 reproduce.py

This command checks every manifest hash, validates the three main tables,
reruns 11,000 exact codec cases and 5,712 abstract macro contracts across
four AX profiles, checks the relative-falsity countermodels, independently
checks both 3,394-pair register-operation certificates, reruns the prior
PSC reference checker's tests, census and schema comparison, and regenerates the
two final tables, named tables, label maps, DAGs, and certificates. It
requires those regenerated files to match byte for byte. No network or
third-party Python package is needed. Temporary output is removed on exit.
Do not run Python with -O: some attributed upstream checkers use assertions.

To skip table regeneration while checking the supplied artifacts:

    python3 reproduce.py --skip-regeneration

To save verification output, choose a path outside this archive:

    python3 reproduce.py --output /tmp/zfc-verification.json

The immutable manifest excludes only MANIFEST.json itself. Keep edits in
a separate copy if you want the original manifest checks to continue passing.
Hash checks establish file identity; the mathematical proofs are in the
report and are not consequences of passing tests.

FIXED TABLE-GENERATION RECIPE

All needed source dependencies are included, unmodified and attributed:

    python3 code/generate_schema_candidates.py \
      --repo vendor/ProveIt \
      --rebracket-dir vendor/one_schema_machine \
      --output /tmp/zfc-schema-248

The generator checks source digests before executing its helpers. It uses
fixed winning grammar seeds (122 for the original row, 39 for the dual row;
exponent 2 in both cases), so no search is required. The complete bounded
search descriptions and their limits appear in the report.

INDEPENDENT REGISTER-CERTIFICATE CHECK

    python3 code/verify_schema_rm_certificate.py \
      --prior-machine-dir vendor/one_schema_machine \
      --reference machines/old_rho6-reference-dag.json \
      --candidate machines/old_rho6-dag.json \
      --certificate machines/old_rho6-rm-bisimulation.json

Replace old_rho6 with dual_rho6 to check the comparison branch. The path
engine is independently implemented from the grammar generator and TM
compiler. Both zero and positive decrement branches are checked.

PRIOR PSC REFERENCE CHECKER

vendor/psc_reference_checker contains the newest incoming manuscript's
explicit first-order PSC proof-checking prototype. It is prior work, not
a new implementation in this report. Its own README explains its encoding,
commands, and tests. This checker is not the program in the 248-state TM.
The report recommends reusing its transparent calculus as a specification
for a future PSC-only compilation experiment.

ARCHIVE CONTENTS

report.pdf, report.tex       Main report and complete editable source.
reproduce.py                Self-contained finite reproduction entry point.
MANIFEST.json               Sizes and SHA-256 hashes of all other files.
code/                       New fixed generator and independent-check wrappers.
machines/                   Literal and named tables; maps; register DAGs;
                            finite operation-bisimulation certificates;
                            separate prior 253-state benchmark.
results/                    Exact regression results, candidate metadata,
                            conservative finite table audits, independent
                            certificate checks, and reproduction evidence.
provenance/                 Source cutoffs, source audit records, engineering
                            detail, calculus memo, and prior-checker review.
vendor/                     Minimum pinned dependencies and prior prototype;
                            see vendor/NOTICE.txt for attribution/licenses.

TABLE FORMAT

The numbered .tm files begin with '#! start 0'. Each subsequent row has:

    current_state  read_symbol  write_symbol  L_or_R  next_state

The tape is indexed by all integers, initially all zero, with the head at
position zero. Working states are 0..N-1. Target N halts and has no outgoing
rows. There are exactly two rows per working state. The one originally
undefined backend transition is explicitly normalized to a terminal move;
the report records that convention.

BUILD THE PDF

With TeX Live, latexmk, and the standard packages named in report.tex:

    latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

The distributed PDF was compiled and visually reviewed. Its content is
self-contained; the source uses no external figures or bibliography file.

SOURCE AND STATUS CUTOFF

Requested four distinct commits and newer material were inspected through
ProveIt commit 83dec60c249ca0f9e1b2e5ee3cf18fd1ce58c373. Executable inputs
are pinned to 17d0f2eaa650901cda59764dfcc4661c199e49c8. The two later
commits in the audit add reports rather than changing those inputs.
Source URLs, complete pins, archive hashes, PR head, and CI run identifiers
are in provenance/sources.json and the report bibliography.

The equality-free PSC-alone theorem and the weighted Re-Pair method are
attributed to the newest incoming one-schema manuscript. The new result
here applies that method after an exact schema-parameter permutation,
producing the two 248-state tables and their finite certificates.
