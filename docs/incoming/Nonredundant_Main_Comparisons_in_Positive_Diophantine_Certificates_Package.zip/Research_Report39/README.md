# Research Report 39: Nonredundant Main Comparisons in Positive Diophantine Certificates

Research_Report39.tex and Research_Report39.pdf present the infinite reduced-
predicate construction from the complete frozen unwrapped-family packet. For a
fixed genuine compiler export and positive input, one admissible q and
W=2^u, Z=1, C=W+1, s=t=1 are fixed. Infinitely many scales satisfy every inherited
Report37 predicate condition except the main congruence 2^p=X mod H. The analytic
proof gives an eventual dyadic lower count proportional to N/log N in the
progression index r. It gives no feasible numerical threshold.

The Jacobi addendum strengthens this to infinitely many certified misses.
Choose the admissible even square q=B^(2x+2), put h0=4q^3+3, and take
r=h0*j (the older r=4h0*j thinning also works). For any positive w,
(X/H)=(w/h0); an odd-p hit requires symbol -1. The thinned family has symbol
+1, so its main congruence fails. Fixed-thinning discrepancy gives the same
eventual lower bound delta0*N/(32L0*log N), now counting j. Its raw and positive21
squared residuals are strictly positive, proving nonredundancy of their respective
main comparisons. The earlier frozen family's unresolved-miss wording is
historical and is superseded only by this addendum.

Both results remain conditional on inherited compiler/bootstrap premises.
No main-congruence hit, full negative zero or global sign theorem is established.
The symbol -1 sector remains unresolved. The family is not an exhaustive
parametrization, and no global novelty claim is made. Finite fixtures neither
materialize genuine-family candidates nor prove analytic existence. Authenticity
is not mathematical truth.

## Package map

- Research_Report39.tex / Research_Report39.pdf: standalone article
- evidence/: all 21 frozen payloads plus MANIFEST.sha256, byte-exact
- evidence/ALL-BUT-MAIN-PROJECTION.md: frozen proof
- evidence/independent/INDEPENDENT-REVIEW.md: conditional independent review
- evidence/context/: inert Report37 theorem and upstream source snapshots
- jacobi/: 10 new frozen addendum members, including its complete source manifest
- verification/source-lineage.json: original/packaged identity of the 22 family files
- verification/jacobi-lineage.json: all 32 addendum members mapped to packaged
  identities; its 22 inherited-family members are deduplicated against evidence/
- verification/expected-receipts.json: recursively typed frozen expected receipts
- verification/replay-plan.json: exact three-program replay allowlist
- verify_release.py: authenticated exact inventory and fresh-copy replay
- tamper_regression.py / output_guard_regression.py: rejection tests
- archive_release.py / archive_regression.py: deterministic ZIP, safe extraction,
  moved-copy verification and hostile ZIP regression
- build_pdf.py: external local pdfLaTeX build with shell escape disabled
- seal_release.py: maintainer tool, never a way to validate a received package

## Authenticate before running

First hash the complete ZIP using a trusted external hashing tool and compare
against a SHA256 independently obtained from the sender. A packaged verifier
cannot authenticate itself. If only an enclosing MANIFEST.json digest is
provided, a trusted external implementation must also verify every payload hash,
including the normalized verifier convention in INTEGRITY.md, before any
packaged program runs. Merely hashing the manifest is insufficient.

Python 3.9+ is required. The author and Jacobi checkers are standard-library only; the
independent checker requires exactly SymPy 1.14.0. No tool installs dependencies.
An installed trusted SymPy distribution is part of the runtime trust boundary.
From an authenticated extracted release directory:

    python -I -B verify_release.py --verify-only
    python -I -B -O verify_release.py --verify-only
    python -I -B verify_release.py --self-test-types
    python -I -B verify_release.py --replay
    python -I -B -O verify_release.py --replay
    python -I -B tamper_regression.py
    python -I -B output_guard_regression.py

A full replay executes only these mathematical programs, each normally and
under -O in separate fresh external copies:

1. evidence/check_unwrapped_family.py
2. evidence/independent/check_audit.py
3. jacobi/check_jacobi_addendum.py, staged in its authenticated portable layout

Identity is checked before every program and again after each. Six freshly
captured stdout receipts must match the frozen bytes and every recursive JSON
type, key and value. Original and copied bytes, modes and mtimes must remain
unchanged. No context Python is imported, compiled, interpreted or executed; no
saved upstream arithmetic schedule is evaluated. Helper programs and trusted
runtime dependencies are separate from this three-program mathematical allowlist.

The Jacobi checker expects inherited-family/ beside it. To preserve its frozen
bytes without archiving a second copy of all inherited evidence, the verifier
assembles that layout from verified jacobi/ and evidence/ into a separate external
directory. It authenticates every staged byte, mode and path before running the
checker, then checks that the entire stage is unchanged. The frozen addendum
manifest and lineage authenticate this exact deduplication. Do not invoke the
archived Jacobi checker directly without that portable layout.

For optional receipt files, pass --receipt-dir with a NEW external directory
whose parent already exists. For temporary copies, --workdir names an external
parent. All six receipt files are created exclusively after successful replay.
The supported interface never passes --output to any frozen checker.
Important historical distinction: the frozen author checker's direct --output
refuses paths inside its evidence packet but CAN overwrite an existing external
file. The frozen independent and Jacobi checkers require new external files. The
checkers' own packet guards do not protect every enclosing-release path. Their bytes
are preserved; use the enclosing verifier rather than direct --output.

## Rebuild and archive

A trusted installed local TeX Live/pdfLaTeX is needed. PDF outputs must use a
new or empty external directory; ZIP creation and receipt export never overwrite
existing paths. Replace OUTPUT_DIR with an external directory of your choice.

    python -I -B build_pdf.py --output OUTPUT_DIR/pdf --check-packaged
    python -I -B archive_release.py --create OUTPUT_DIR/Research_Report39.zip
    python -I -B archive_release.py --check OUTPUT_DIR/Research_Report39.zip --sha256 INDEPENDENT_ZIP_SHA256 --replay
    python -I -B archive_regression.py --archive OUTPUT_DIR/Research_Report39.zip --sha256 INDEPENDENT_ZIP_SHA256

PDF byte reproducibility assumes the same installed engine, packages and fonts.
The builder uses three passes, a fixed epoch, UTC, suppressed PDF timestamp and
trailer identifiers, and no shell escape. All caches and logs remain external.
--check-packaged authenticates the sealed tree and requires exact PDF bytes.

ZIP checking requires both a trusted local release and an independent archive
digest. Exact names, counts, regular-file modes, sizes and bytes must match
before safe manual extraction. Extracted identity is checked normally and under
-O; --replay additionally runs the full mathematical replay in both verifier
modes. ZIP byte reproducibility assumes the same Python/zlib implementation.

See INTEGRITY.md for trust, provenance, output and maintainer boundaries.
