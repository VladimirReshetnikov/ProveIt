# Theta Modulation at the 132-Avoider Renewal Boundary

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October 2026.

The seven-page manuscript proves a periodic-Gaussian correction to the
relative avoidance probability when n is of order m(log m)^2. For each
fixed c0>0, under n>=c0 m(log m)^2 and n(log m)^2/m^2->0,

    p_n(m) ~ sqrt(pi) n^(5/2)/m^2 exp(-n t_m/m) Theta(H_m(n),L_m(n)).

The complete scalar root and the exact auxiliary cluster mean and variance
are retained. At n/[m(log m)^2]->c>0, every phase u modulo one occurs and
the limiting amplitude is sum_j exp(-8*pi^2*c*j^2) exp(2*pi*i*j*u).
It is nonconstant in u. Thus the unmodulated equivalent fails at this
boundary. The scalar-envelope theorem has no upper restriction on n.

Contents:
- theta_avoider_boundary.pdf: manuscript
- theta_avoider_boundary.tex: editable source
- build.sh: standard three-pass pdflatex build
- checks/: optional diagnostics and recorded data
- SOURCES.md: pinned source, companion inputs, classical attribution,
  and the explicitly limited inspection of a related preprint announcement
- validation.json and latex-build.log: completed validation record
- SHA256SUMS: hashes of every other package file

Run bash build.sh with a standard TeX installation containing Latin Modern,
geometry, amsmath/amssymb/amsthm, mathtools, microtype, booktabs, hyperref,
and xurl. The optional diagnostic script needs NumPy, SciPy and mpmath;
these packages are not vendored. The mathematical proof does not depend
on these numerical calculations.

This is ordinary mathematical research, not formally verified or externally
refereed. The Gaussian periodization identity is classical. The claimed
contribution is specific to the inspected repository question; no exhaustive
priority claim is made. The full manuscript of the related Li announcement
could not be retrieved, so overlap beyond its public abstract is not excluded.
