# Reciprocal-gamma kernels in the Stieltjes derivative tower

**Research article, proposed corrections, exact certificates, and reproducibility tools.**
Prepared for Vladimir Reshetnikov's ProveIt project on 2026-10-07.

Start with `article/stieltjes-zero-geometry-and-regularized-jets.pdf` (22 pages).
The complete LaTeX source and three table inputs are in the same directory.

## Results and their status

Write `gamma_n^(k)(a)` for the k-th derivative in the Hurwitz parameter a of
 the n-th generalized Stieltjes constant. Throughout, a > 0 and k >= 1.

1. **Analytic theorem:** there are at most n positive zeros, counting
   multiplicity, for every n and k. The proof uses a common Laplace kernel,
   the simple real roots of reciprocal-gamma Appell polynomials, and a
   multiplicity-sensitive variation argument proved in the article.
2. **Analytic theorem:** for fixed n, exactly n simple positive zeros exist
   for all sufficiently large k. Their slopes and the next two asymptotic
   coefficients are explicit, and a justified all-orders recursion is given.
   No uniformity for growing n is claimed.
3. **Analytic propagation theorem + finite exact certificates:** saturation
   at one k persists forever with strict right-interlacing. Fourteen exact
   sign enclosures establish the initial case k=1 for n=1,2,3,4. Thus these
   indices have exactly n simple zeros for every k >= 1.
4. **Entirely analytic first-index theorem:** the unique zero alpha_k obeys
   `exp(H_(k-1)) < alpha_k < exp(H_(k-1)) + 1/2`. Its location has a three-term
   expansion `exp(EulerGamma)*k + d + c/(k+1) + O(k^(-2))`, with d and c
   explicit in the article. Eight width-10^(-20) intervals are certified.
5. **Analytic arithmetic identities:** regularized Dirichlet L-jets across
   trivial zeros are transported by two parity-dependent kernels. Combining
   transport with the derivative tower cancels all conductor and harmonic
   factors from the kernel. The first bridge at a trivial zero contains
   `L''(-k)/(2*L'(-k))`, with conjugation for nonreal characters.

These are research claims supported by the included proofs. They have not been
independently refereed or formalized in Lean. Priority is not established by the
limited literature check. The classical parameter-derivative identity is
credited to prior work, not claimed as a new theorem. No special-value linear
or algebraic independence is claimed.

## What was audited

The main source is
`Analysis/Polylogarithms/docs/articles/stieltjes-parameter-derivative-tower.tex`
at commit `c78c7c3dc2fc742a1af9492e47d578b3fb4e01e7`, blob
`e4d53b7c921c72ff40c5393a9d3ac5cfb44ea6bb`.
The introductory antiderivative calculus and CM row-sum article were consulted
for context. This is **not** a full audit of the directory or a recertification
of every displayed table.

The four proposed changes in `corrections/` distinguish an unsupported
independence inference, a missing general rank proof, an underspecified
trivial-zero normalization, and an inaccurately described residual vocabulary.
No counterexample to the rank formula is asserted. No repository file was changed.

## Reproduce

Python 3.10 or later is required. Exact verification needs only its standard
library. Optional symbolic and numerical checks use SymPy and mpmath:

```sh
python tools/exact_verify.py
python -m pip install -r requirements.txt
python tools/symbolic_checks.py
python tools/numerical_checks.py
```

The delivered run passed **30 exact sign certificates**, **80 symbolic
regression checks**, and **48 high-precision regression checks**. The numerical
script also computed nine first-index roots. Numerical computations do not
replace the exact sign certificates or the analytic proofs.

`data/certificates.json` is the exact verifier's input. Each output enclosure
is obtained afresh, not trusted from a stored answer. The exact verifier uses
outward integer intervals at scale 10^90, a rational atanh-series logarithm with
an explicit tail, exact Bernoulli numbers, and the article's proved
Euler--Maclaurin remainder. A certificate is accepted only when its entire
interval has the requested strict sign. An inconclusive interval causes a
failure, not a claim that the sign is zero.

The fixed default working precision is sufficient for the supplied certificates;
the theoretical general threshold-search principle is not implemented as a
production search program. Computational complexity of that search is not claimed.

Build the article with a standard TeX Live installation:

```sh
cd article
latexmk -pdf -interaction=nonstopmode -halt-on-error \
  stieltjes-zero-geometry-and-regularized-jets.tex
```

Alternatively use `make exact`, `make symbolic`, `make numerical`, or `make pdf`
from the package root. The article can be built without rerunning the experiments:
its table inputs are included. `tools/render_tables.py` regenerates the tables
from the saved result JSON, rounding interval endpoints outward.

## Package layout

- `article/`: PDF, complete TeX, and table inputs.
- `tools/`: exact verifier, symbolic checks, numerical checks, and table generator.
- `data/`: certificate inputs, three result records, and root asymptotic CSV.
- `corrections/`: a scoped audit and proposed replacement TeX snippets.
- `provenance/`: source identifiers, proof/dependency map, environment and validation record.
- `SHA256SUMS`: hashes of the deliverable files, excluding itself.

The suggested integration is a new self-contained subdirectory, for example
`Analysis/Polylogarithms/research/stieltjes_zero_geometry/`. Keeping `tools/`
and `data/` as siblings preserves the scripts' relative paths. The article and
correction notes may instead be moved into the existing docs hierarchy, provided
the TeX table inputs remain adjacent and the tool/data relationship is retained.
Review correction snippets before editing the original source. This package has
no automatic upload, commit, overwrite, or patch-application step.

## Further research

The article proposes ten directions, notably saturation thresholds K_n,
large-index root separation and joint n,k asymptotics, effective error bounds,
continuous-order zero bifurcations, sharper global first-index bounds, formal
distribution modules, and certified symbolic integration of the two arithmetic
kernels. The proof map separates reusable analytic components from the small
computer-assisted base case.
