U220: TWO STATES BELOW THE PRIMARY U222 CANDIDATE
28 October 2026
================================================

RESULT
------
machine/u220.tm is an explicit deterministic, single-tape, two-symbol machine
with 220 working states and 440 transition rows. Its initial state is 0, its
separate halt label is 220, and its entire initial tape is zero. Initialization
is included in the state count. Each step moves exactly one cell left or right.

The new reduction establishes, by ordinary mathematics formalizable in PA,

    PA |- Halt(U220, blank) <-> Halt(U222, blank).

Composing with the supplied U222 calibration gives

    PA |- not Halt(U220, blank) <-> Con(U) <-> Con(PA).

U and its arithmetic consistency calibration are inherited from the original
U222 archive and the unary-power-covering manuscript included within it.
The new reduction has exact finite certificates and complete symbolic runtime
verification. This release has no newly compiled Lean, Rocq, MM0, or exported
PA proof object for the final consistency endpoint. No absolute state minimum
or unconditional consistency/nonhalting assertion is made.

START HERE
----------
paper/report.pdf               Complete mathematical report and full table
paper/report.tex               Editable LaTeX source
machine/u220.tm                Exact dense transition table (primary machine)
machine/u220.native.tm         Same machine with native construction labels
machine/u220.csv               All 440 transitions in CSV format
machine/state_map.json         Native/dense bijection
machine/sites.json             Reassociated source program
machine/construction.json     Deterministic reconstruction receipt
machine/u221.native.tm         First, time-preserving reduction
machine/u221.tm                Dense intermediate U221
machine/u221_rotated.native.tm Intermediate before the second guarded fold
inputs/                       Pinned original U222 machine and source copies
upstream/U222_ConU_2026-10-28.zip  Intact original research package
code/                         Builders and independently implemented checkers
evidence/                     Structural, startup, and all-natural receipts
notes/                        Comparison notes and bounded search record
PROVENANCE.json               Source identities and file-level attribution
NOTICE.txt and licenses/      Attribution and inherited notices
SHA256SUMS                    Sealed release inventory and file hashes

HOW THE TWO STATES ARE SAVED
---------------------------
1. Delete native state 200 and redirect its only entrance to 112. The only
   entrance to 112 first writes a zero immediately to its right; entering 200
   returns to that same zero. The reachable read-zero rows of 112 and 200
   coincide. This preserves the tape, head, and halting status at every time.

2. Reassociate three closed source blocks of 19, 28, and 56 primitive leaves.
   All 3,891 ordered instructions and every guarded control-flow successor
   remain identical. The resulting layout lets native states 134 and 145 share
   state 145: the preceding tape bit records the old selector identity, and
   existing helpers recover it in three steps. No helper state is added.

The final table deletes native states 134 and 200 and changes exactly seven
retained rows. All other 433 retained rows are unchanged. The full patch and
two short invariant proofs are in the report. The source still has 204 distinct
subtrees, depth 45, and maximum consecutive-zero address run 6.

VERIFICATION AND REPRODUCTION
----------------------------
Python 3.10+ and its standard library suffice. No network or solver is needed.

    python3 reproduce.py

This reconstructs every new table and the source, checks all byte identities,
runs the local guard and selector certificates (including negative controls),
checks both source-CFG resolutions, compares dense/native rows, and independently
replays all 95,714 initialization steps. It compares normal and python -O
structural verification. It checks the saved symbolic report identities but
does not regenerate the arbitrary-register derivations in this default mode.

    python3 reproduce.py --full

This additionally replays the original U222 verification and regenerates every
symbolic primitive derivation for U221 and U220. Each suite has 5,060 cases
over arbitrary natural register values and gap, and arbitrary finite spare
lists with at least one block. It may take several minutes. The checker uses
unary-length and list-length induction; these are not bounded register samples.

Full symbolic checking requires enabled assertions and refuses python -O.
The structural builders/checkers use explicit checks and are separately
verified under -O. The script uses temporary output locations and does not
modify the sealed release. To retain a new receipt outside this directory:

    python3 reproduce.py --full --report /absolute/path/fresh-u220-receipt.json

Standalone deterministic reconstruction:

    python3 code/build_u220.py --baseline-table inputs/u222.native.tm \
      --baseline-source inputs/u222_sites.json --output /tmp/u220-built

PDF rebuild, in a working copy if preserving release hashes:

    python3 code/build_paper_data.py
    cd paper
    pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
    pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex

EXACT MACHINE IDENTITY
----------------------
Dense U220 SHA-256:
93f33799ab59fc977627d93944bf03af601320b28344eb59595485fed42dec0b

Native U220 SHA-256:
0abab2f6e9841b4227483c12560844326bfb723dd90bb81d938f083326491081

Source SHA-256:
232307837f575ee79ffa43a9f8ec1eaf94978d8cd1fe544ed4f6fb64a170fd12

The table format is '#! start 0', followed by five-field ASCII rows:

    state read_symbol written_symbol L_or_R next_state

ATTRIBUTION
-----------
The theory U, U222 source/calibration, K215 interpreter and proof-search
architecture, and upstream Mira/Wade/Ketchersid/Glazer work retain their
original attribution. This package adds the two-state reduction, proofs,
exact final construction, independent audits, and verification replays.
Independent reviewers here were other assistants in the same research
collaboration; they are not external human endorsements. See NOTICE.txt.
