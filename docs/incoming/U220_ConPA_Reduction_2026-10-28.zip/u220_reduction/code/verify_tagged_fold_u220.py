#!/usr/bin/env python3
"""Independent check: rotated U221 -> U220 by tagged three-step selector.

The one-bit tag invariant is established from all incoming transitions,
then all possible local tape bits are exhausted. No source interpreter,
construction recipe, search heuristic, or bounded run is trusted.
"""
from pathlib import Path
import argparse,json,hashlib
from itertools import product


def require(v,m):
    if not v: raise ValueError(m)

def parse(path):
    T={}
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
        require((q,b)not in T,'duplicate row');require(b in(0,1)and w in(0,1)and d in('L','R'),'bad action')
        T[q,b]=(w,1 if d=='R'else -1,z)
    return T

def check(T,U):
    keep,drop,helper=145,134,507
    qs={q for q,b in T};us={q for q,b in U}
    require(len(qs)==221 and len(T)==442,'input count')
    require(len(us)==220 and len(U)==440 and us==qs-{drop},'output count')
    require(0 in qs and 254 not in qs,'start/halt')
    require(all((q,b)in T for q in qs for b in(0,1)),'input totality')
    require(all((q,b)in U for q in us for b in(0,1)),'output totality')
    f=lambda q:keep if q==drop else q
    incoming={}
    for q,tag in [(keep,0),(drop,1)]:
        edges=sorted((p,b,w,d)for(p,b),(w,d,z)in T.items()if z==q)
        require(edges and all(w==tag and d==1 for p,b,w,d in edges),'left-tag invariant')
        incoming[str(q)]={'tag':tag,'incoming':edges}
    require(T[keep,1]==T[drop,1]==(1,1,215),'common branch')
    require(T[keep,0]==(0,1,19)and T[drop,0]==(0,1,203),'differing branch')
    require(U[keep,0]==(0,-1,helper),'fold entry')
    require(U[helper,0]==(0,1,166)and U[helper,1]==(1,1,163),'tag selector')
    require(U[166,0]==(0,1,19)and U[163,0]==(0,1,203),'tag replay')
    for(q,b),(w,d,z)in T.items():
        if q==drop or(q,b)==(keep,0):continue
        require(U[q,b]==(w,d,f(z)),'unrelated row changed')
    # Window covers offsets-2..2. Enumerate every assignment to the other
    # four positions for each mandatory tag, including both tested symbols.
    cases=[]
    for q,tag in [(keep,0),(drop,1)]:
        for bits in product((0,1),repeat=4):
            tape=[bits[0],tag,bits[1],bits[2],bits[3]]
            expected=tape.copy();w,d,z=T[q,tape[2]];expected[2]=w
            expected=(f(z),2+d,expected)
            state,pos,result=keep,2,tape.copy();count=3 if tape[2]==0 else 1
            for _ in range(count):
                require(0<=pos<5,'macro escaped window');require(state!=254,'macro halted internally')
                w,d,state=U[state,result[pos]];result[pos]=w;pos+=d
            require((state,pos,result)==expected,'local macro mismatch')
            cases.append({'old_state':q,'window':tape,'steps':count})
    return {'status':'PASS','input_states':221,'output_states':220,
      'keep':keep,'drop':drop,'helper':helper,'differing_read':0,
      'incoming_tag_invariants':incoming,'local_cases':len(cases),'maximum_steps_per_old_step':3,
      'time_map':'one step except an old read0 at native145 or134, which becomes three steps',
      'scope':'Tagged fold only, from rotated U221. Prior decoder rotation has separate source/CFG and universal-runtime obligations.',
      'proof_status':'Elementary finite invariant and local macro proof, executable checker; not proof-assistant kernel checked.'}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('before',type=Path);ap.add_argument('after',type=Path);ap.add_argument('--output',type=Path,default=Path(__file__).with_name('tagged_fold_u220_certificate.json'));a=ap.parse_args()
    T,U=parse(a.before),parse(a.after);ans=check(T,U)
    neg=[]
    for label,which,key,value in [('bad_tag','before',(506,0),(1,1,145)),('bad_replay','after',(163,0),(0,1,19))]:
        V=T.copy();W=U.copy();(V if which=='before'else W)[key]=value
        try:check(V,W)
        except ValueError as e:neg.append({'control':label,'status':'REJECTED','reason':str(e)})
        else:raise ValueError('negative control accepted')
    ans['negative_controls']=neg
    ans['sha256']={'before':hashlib.sha256(a.before.read_bytes()).hexdigest(),'after':hashlib.sha256(a.after.read_bytes()).hexdigest()}
    a.output.write_text(json.dumps(ans,indent=2)+'\n');print(json.dumps(ans,indent=2))
if __name__=='__main__':main()
