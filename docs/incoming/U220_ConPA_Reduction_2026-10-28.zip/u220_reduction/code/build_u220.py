#!/usr/bin/env python3
"""Deterministically reconstruct U220 from the pinned U222 table and source.

Only the standard library is used. No optimizer, allocator, or search is run.
The closed-source reassociation and the two guarded folds are independently
justified in the accompanying mathematical report and finite certificates.

Tree/CFG conventions follow ProveIt's K215 source_language.py and the U222
construction packet, which credit Wade's MIT-0 register-machine framework.
Preserve their provenance and license notices when redistributing inputs.
"""
from pathlib import Path
from functools import cache
import argparse, hashlib, json

TABLE_SHA='88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427'
SOURCE_SHA='1d258cfe56f8b845826a63af57de8134fbc4886b47f95312cf6d49424f3f3072'
OUT_TABLE_SHA='0abab2f6e9841b4227483c12560844326bfb723dd90bb81d938f083326491081'
OUT_SOURCE_SHA='232307837f575ee79ffa43a9f8ec1eaf94978d8cd1fe544ed4f6fb64a170fd12'
ROTATION_PATH='11010010011101010110111111100'
PATCH=[(112,1,1,1,112),(145,0,0,-1,507),(145,1,1,1,215),
       (156,1,1,1,145),(210,1,1,1,145),(506,0,0,1,145),(506,1,1,1,504)]

def need(p,m):
    if not p: raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def packed(d):return (json.dumps(d,separators=(',',':'))+'\n').encode('ascii')
def leaf(t):return isinstance(t[0],str)
def rows(t,p=''):
    return [[p,*t]] if leaf(t) else rows(t[0],p+'0')+rows(t[1],p+'1')
def parse_source(rs):
    leaves={p:(op,arg)for p,op,arg in rs}
    need(len(leaves)==len(rs),'duplicate source leaf')
    prefixes={p[:i]for p in leaves for i in range(len(p))}
    need(not prefixes.intersection(leaves),'prefix collision')
    need(all(p+b in prefixes or p+b in leaves for p in prefixes for b in'01'),'incomplete source tree')
    def visit(p):return leaves[p] if p in leaves else (visit(p+'0'),visit(p+'1'))
    t=visit('');need(rows(t)==rs,'noncanonical source order');return t
@cache
def boundary(t):
    if leaf(t):
        op,a=t
        return (1 if op=='CD' else a if op=='CB' else 0,
                a if op=='CC' else 0,op=='CH')
    a,b=boundary(t[0]),boundary(t[1]);return max(a[0]-1,b[0],0),max(a[1],b[1]-1,0),a[2]or b[2]
def at(t,p):
    for x in p:need(not leaf(t),'path past leaf');t=t[int(x)]
    return t
def replace(t,p,x):
    if not p:return x
    z=list(t);z[int(p[0])]=replace(z[int(p[0])],p[1:],x);return tuple(z)

def cfg_intervals(rs):
    """Resolver1: ancestor intervals, without binary arithmetic."""
    intervals={}
    for i,(p,_,_)in enumerate(rs):
        for j in range(len(p)+1):intervals.setdefault(p[:j],[i,i+1])[1]=i+1
    def jump(p,b,k):
        for j in range(len(p)-1,-1,-1):
            if p[j]==b:
                k-=1
                if k==0:return intervals[p[:j]][0 if b=='1' else 1]%len(rs)
        return 0
    ans=[]
    for i,(p,op,a)in enumerate(rs):
        after=(i+1)%len(rs)
        dst=(after,)if op=='CI' else (jump(p,'0',1),after)if op=='CD' else (jump(p,'0',a),)if op=='CB' else (jump(p,'1',a),)if op=='CC' else ()
        ans.append((op,a,dst))
    return ans

def cfg_binary(rs):
    """Resolver2: binary increment and address cuts, with no-stray-one check."""
    leaves={p:i for i,(p,_,_)in enumerate(rs)};depth=max(map(len,leaves))
    def locate(prefix):
        word=prefix+'0'*depth
        for j in range(1,depth+1):
            if word[:j]in leaves:
                need('1'not in prefix[j:],'stray one after successor leaf')
                return leaves[word[:j]]
        raise ValueError('no successor leaf')
    def inc(p):return format((int(p,2)+1)%(1<<len(p)),'0'+str(len(p))+'b')if p else ''
    def cut(p,b,k):
        positions=[j for j,x in enumerate(p)if x==b]
        return p[:positions[-k]]if len(positions)>=k else ''
    ans=[]
    for p,op,a in rs:
        dst=(locate(inc(p)),)if op=='CI' else (locate(inc(cut(p,'0',1))),locate(inc(p)))if op=='CD' else (locate(inc(cut(p,'0',a))),)if op=='CB' else (locate(cut(p,'1',a)),)if op=='CC' else ()
        ans.append((op,a,dst))
    return ans

def table(raw):
    ts={};starts=[]
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):starts.append(int(line[9:]));continue
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
        need((q,b)not in ts and b in(0,1)and w in(0,1)and d in('L','R'),'invalid transition')
        ts[q,b]=(w,1 if d=='R'else-1,z)
    need(starts==[0],'start label');return ts

def encode(ts):
    return ('#! start 0\n'+''.join(f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'for(q,b),(w,d,z)in sorted(ts.items()))).encode('ascii')
def census(ts,halt):
    qs={q for q,b in ts};need(0 in qs and halt not in qs,'start/halt state')
    need(set(ts)=={(q,b)for q in qs for b in(0,1)},'partial table')
    need({z for w,d,z in ts.values()}-qs=={halt},'target closure')
    seen={0};todo=[0]
    for q in todo:
        for b in(0,1):
            z=ts[q,b][2]
            if z!=halt and z not in seen:seen.add(z);todo.append(z)
    need(seen==qs,'graph-unreachable counted state');return qs

def build(tablepath,sourcepath,out):
    tr=tablepath.read_bytes();sr=sourcepath.read_bytes()
    need(sha(tr)==TABLE_SHA,'U222 native-table hash');need(sha(sr)==SOURCE_SHA,'U222 source hash')
    T=table(tr);need(len(census(T,254))==222,'U222 census')
    oldrows=json.loads(sr);t=parse_source(oldrows);node=at(t,ROTATION_PATH)
    need(not leaf(node)and not leaf(node[1]),'rotation shape')
    A,(B,C)=node;need([len(rows(v))for v in(A,B,C)]==[19,28,56],'rotation factor lengths')
    need(all(boundary(v)==(0,0,False)for v in(A,B,C)),'nonclosed factor')
    nt=replace(t,ROTATION_PATH,((A,B),C));newrows=rows(nt)
    need([x[1:]for x in oldrows]==[x[1:]for x in newrows],'primitive word changed')
    a,b,c,d=cfg_intervals(oldrows),cfg_binary(oldrows),cfg_intervals(newrows),cfg_binary(newrows)
    need(a==b==c==d,'source CFG mismatch')
    rawsource=packed(newrows);need(sha(rawsource)==OUT_SOURCE_SHA,'new source hash')
    selected=[i for i,(p,_,_)in enumerate(oldrows)if p.startswith(ROTATION_PATH)]
    need(selected==list(range(selected[0],selected[0]+103)),'rotation interval')
    # U221: the first independently certified guarded fold.
    I={(q,b):(w,m,112 if z==200 else z)for(q,b),(w,m,z)in T.items()if q!=200}
    need(len(census(I,254))==221,'intermediate U221 census')
    # Closed reassociation, before the second independently certified fold.
    P=dict(I)
    need([P[k]for k in[(506,0),(506,1),(145,0),(145,1)]]==[(0,1,19),(1,1,145),(0,1,215),(1,1,504)],'physical rotation correspondence')
    P[506,0]=(0,1,145);P[506,1]=(1,1,504);P[145,0]=(0,1,19);P[145,1]=(1,1,215)
    F={(q,b):(w,m,145 if z==134 else z)for(q,b),(w,m,z)in P.items()if q!=134};F[145,0]=(0,-1,507)
    # Independently replay the declared seven-row patch and deletion set.
    N={k:v for k,v in T.items()if k[0]not in(134,200)}
    for q,b,w,m,z in PATCH:N[q,b]=(w,m,z)
    need(N==F,'staged construction differs from explicit patch')
    qs=census(N,254);need(len(qs)==220,'U220 census');native=encode(N);need(sha(native)==OUT_TABLE_SHA,'new native hash')
    ren={q:i for i,q in enumerate(sorted(qs))};ren[254]=220;need(ren[0]==0,'dense start')
    dense={(ren[q],b):(w,m,ren[z])for(q,b),(w,m,z)in N.items()};need(census(dense,220)==set(range(220)),'dense census')
    inv={z:q for q,z in ren.items()};need({(inv[q],b):(w,m,inv[z])for(q,b),(w,m,z)in dense.items()}==N,'transition bijection')
    leaves=max(len(p)for p,_,_ in newrows);zeros=max(len(z)for p,_,_ in newrows for z in p.split('1'))
    seen=set()
    def visit(n):
        if n in seen:return
        seen.add(n)
        if not leaf(n):visit(n[0]);visit(n[1])
    visit(nt)
    out.mkdir(parents=True,exist_ok=True)
    outputs={'u221.native.tm':encode(I),'u221_rotated.native.tm':encode(P),'u220.native.tm':native,'u220.tm':encode(dense),'sites.json':rawsource,'state_map.json':packed({'native_to_dense':ren,'native_halt':254,'dense_halt':220,'start':0})}
    for name,raw in outputs.items():(out/name).write_bytes(raw)
    report={'status':'EXACT_U220_RECONSTRUCTION_PASS','working_states':220,'transitions':440,'baseline_native_sha256':TABLE_SHA,'baseline_source_sha256':SOURCE_SHA,'rotation':{'path':ROTATION_PATH,'ordinal_interval':[selected[0],selected[-1]+1],'factor_leaves':[19,28,56],'all_factors_closed':True},'removed_states':[134,200],'changed_rows':[list(x)for x in PATCH],'source_metrics':{'dag_nodes':len(seen),'leaf_occurrences':len(newrows),'maximum_depth':leaves,'maximum_zero_run':zeros},'source_primitive_word_equal':True,'interval_and_binary_CFGs_all_equal':True,'retained_primitive_ordinal_correspondence':'identity','native_dense_exact_transition_bijection':True,'outputs':{name:{'sha256':sha(raw),'bytes':len(raw)}for name,raw in outputs.items()},'scope':'Deterministic reconstruction and finite source/transition binding. Guarded-fold correctness and arbitrary-register simulation are separate certificates.'}
    (out/'construction.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));return report

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--baseline-table',type=Path,required=True);ap.add_argument('--baseline-source',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();build(a.baseline_table,a.baseline_source,a.output)
