#!/usr/bin/env python3
"""Generate the exact table appendix, table CSV, and document hash macros."""
from pathlib import Path
import csv
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
table = {}
with (ROOT / "machine/u220.tm").open() as source:
    for line in source:
        if line.startswith("#") or not line.strip():
            continue
        q, b, w, d, z = line.split()
        table[int(q), int(b)] = (int(w), d, int(z))
if set(table) != {(q, b) for q in range(220) for b in (0, 1)}:
    raise ValueError("unexpected dense table census")
hashes = {key: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
          for key, path in (("DenseHash", "machine/u220.tm"),
                            ("NativeHash", "machine/u220.native.tm"),
                            ("SourceHash", "machine/sites.json"))}
(ROOT / "paper/metadata.tex").write_text("% Generated from exact delivered files.\n" +
    "".join("\\newcommand{\\" + key + "}{" + value + "}\n"
            for key, value in hashes.items()))
with (ROOT / "machine/u220.csv").open("w", newline="") as file:
    writer = csv.writer(file, lineterminator="\n")
    writer.writerow(["state", "read", "write", "direction", "next_state"])
    for (q, b), (w, d, z) in sorted(table.items()):
        writer.writerow([q, b, w, d, z])
lines = [r"\begingroup\small\setlength{\tabcolsep}{6pt}",
         r"\begin{longtable}{rrr@{\hspace{14pt}}rrr@{\hspace{14pt}}rrr}",
         r"\toprule", r"State & Read 0 & Read 1 & State & Read 0 & Read 1 & State & Read 0 & Read 1\\",
         r"\midrule\endfirsthead", r"\toprule",
         r"State & Read 0 & Read 1 & State & Read 0 & Read 1 & State & Read 0 & Read 1\\",
         r"\midrule\endhead", r"\midrule\endfoot", r"\bottomrule\endlastfoot"]
for i in range(74):
    groups = []
    for q in (i, i + 74, i + 148):
        if q >= 220:
            groups.extend(["", "", ""])
        else:
            groups.append(str(q))
            for b in (0, 1):
                w, d, z = table[q, b]
                groups.append(r"$" + str(w) + d + str(z) + "$")
    lines.append(" & ".join(groups) + r"\\")
lines.extend([r"\end{longtable}", r"\endgroup"])
(ROOT / "paper/transition_table.tex").write_text("\n".join(lines) + "\n")
print(json.dumps({"status": "PASS", "dense_rows": len(table), "hashes": hashes}, indent=2))
