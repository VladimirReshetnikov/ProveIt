#!/usr/bin/env python3
"""Independent structural proof of the U222 -> U221 guarded quotient.

No source-language or symbolic-runtime module is imported.  The certificate
uses only the literal table, its two predecessor sets, and a state map.
All mathematical guards are explicit, so python -O is equally supported.
"""
from pathlib import Path
from collections import deque
import argparse
import hashlib
import json

BASELINE_SHA256 = "88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_table(path):
    table = {}
    initial = None
    for line in Path(path).read_text().splitlines():
        if not line:
            continue
        if line.startswith("#! start "):
            require(initial is None, "duplicate initial-state header")
            initial = int(line.split()[-1])
            continue
        if line.startswith("#"):
            continue
        fields = line.split()
        require(len(fields) == 5, "malformed row")
        q, b, w, d, z = fields
        q, b, w, z = map(int, (q, b, w, z))
        require(b in (0, 1) and w in (0, 1), "nonbinary row")
        require(d in ("L", "R"), "invalid move")
        require((q, b) not in table, "duplicate row")
        table[q, b] = (w, -1 if d == "L" else 1, z)
    require(initial == 0, "unexpected initial state")
    states = {q for q, b in table}
    require(len(table) == 2 * len(states), "incomplete table")
    require(all((q, b) in table for q in states for b in (0, 1)), "missing row")
    require({z for w, d, z in table.values()} - states == {254}, "wrong halt")
    return table


def encode(table, rename=None):
    if rename is None:
        rename = lambda q: q
    rows = [(rename(q), b, w, "R" if d == 1 else "L", rename(z))
            for (q, b), (w, d, z) in table.items()]
    return ("#! start 0\n" + "".join("%d %d %d %s %d\n" % row
                                    for row in sorted(rows))).encode()


def phi(q):
    return 112 if q == 200 else q


def predecessors(table, state):
    return sorted((q, b, w, d, z) for (q, b), (w, d, z) in table.items()
                  if z == state)


def quotient(table):
    return {(q, b): (w, d, phi(z)) for (q, b), (w, d, z) in table.items()
            if q != 200}


def audit(table, candidate=None):
    states = {q for q, b in table}
    require(len(states) == 222, "baseline must have 222 working states")
    # This finite check establishes the entire induction for the invariant
    # I(c) := (q=112 -> tape[h+1]=0) and (q=200 -> tape[h]=0).
    require(predecessors(table, 112) == [(172, 0, 0, -1, 112)],
            "unaccounted entrance to 112")
    require(predecessors(table, 200) == [(112, 1, 1, 1, 200)],
            "unaccounted entrance to 200")
    require(0 not in (112, 200), "initial invariant unavailable")
    require(table[112, 0] == table[200, 0] == (0, 1, 157),
            "reachable merged rows disagree")
    Q = quotient(table)
    if candidate is not None:
        require(candidate == Q, "candidate is not exact quotient")
    qstates = {q for q, b in Q}
    require(len(qstates) == 221 and len(Q) == 442, "wrong quotient count")
    require(qstates == states - {200}, "unexpected removed state")
    require({z for w, d, z in Q.values()} - qstates == {254}, "halt mismatch")
    checked = 0
    for (q, b), (w, d, z) in table.items():
        if (q, b) == (200, 1):
            continue
        require(Q[phi(q), b] == (w, d, phi(z)), "step square does not commute")
        checked += 1
    require(checked == 443, "wrong transition coverage")
    return Q, {
        "status": "PASS",
        "theorem": "For every natural t, folded_run(t) = phi(baseline_run(t))",
        "consequence": "Blank runs halt at exactly the same time, in either direction",
        "invariant": ["q=112 implies tape[head+1]=0", "q=200 implies tape[head]=0"],
        "entrances_112": predecessors(table, 112),
        "entrances_200": predecessors(table, 200),
        "forbidden_row": [200, 1],
        "checked_commuting_rows": checked,
        "baseline_working_states": len(states),
        "quotient_working_states": len(qstates),
        "separate_halt": 254,
        "trusted_logic": "Elementary induction on time plus finite row checks",
        "not_required": ["theory U", "source program", "symbolic runtime checker",
                         "bounded blank-run simulation", "consistency assumption"],
    }


def window_audit(table, radius=1):
    """Independent finite inductive overapproximation from an all-zero tape.

    A node is (state, a 2r+1-cell window centered at the head). After each
    real step, either symbol is allowed at the newly revealed edge cell.
    Thus induction on steps embeds every concrete run in the closed set.
    """
    width = 2 * radius + 1
    mask = (1 << width) - 1
    seen = {(0, 0)}
    queue = deque(seen)
    while queue:
        q, bits = queue.popleft()
        if q == 254:
            continue
        w, direction, z = table[q, (bits >> radius) & 1]
        written = (bits & ~(1 << radius)) | (w << radius)
        base = written >> 1 if direction == 1 else (written << 1) & mask
        edge = 1 << (width - 1) if direction == 1 else 1
        for next_bits in (base, base | edge):
            node = (z, next_bits)
            if node not in seen:
                seen.add(node)
                queue.append(node)
    rows = {(q, (bits >> radius) & 1) for q, bits in seen if q != 254}
    require((200, 1) not in rows, "forbidden row occurs in closed invariant")
    return {"radius": radius, "inductive_window_count": len(seen),
            "excluded_rows": [list(x) for x in sorted(set(table) - rows)]}


def negative_controls(table):
    mutations = []
    # Erasing the key write must invalidate the invariant proof.
    changed = dict(table)
    changed[172, 0] = (1, -1, 112)
    mutations.append(("wrong_preceding_mark", changed, None))
    # An unaccounted entry into the dropped state must be rejected.
    changed = dict(table)
    changed[0, 1] = (1, 1, 200)
    mutations.append(("extra_entrance_to_200", changed, None))
    # Agreement of the reachable rows is necessary.
    changed = dict(table)
    changed[200, 0] = (1, 1, 157)
    mutations.append(("wrong_live_write", changed, None))
    # The candidate cannot differ elsewhere.
    candidate = quotient(table)
    w, d, z = candidate[0, 0]
    candidate[0, 0] = (1 - w, d, z)
    mutations.append(("extraneous_candidate_change", table, candidate))
    results = []
    for name, changed, candidate in mutations:
        try:
            audit(changed, candidate)
        except ValueError as exc:
            results.append({"name": name, "status": "REJECTED", "reason": str(exc)})
        else:
            raise ValueError("negative control accepted: " + name)
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("baseline", type=Path)
    ap.add_argument("--candidate", type=Path)
    ap.add_argument("--output", type=Path)
    ap.add_argument("--emit-directory", type=Path)
    args = ap.parse_args()
    require(hashlib.sha256(args.baseline.read_bytes()).hexdigest() == BASELINE_SHA256,
            "baseline hash mismatch")
    table = read_table(args.baseline)
    candidate = read_table(args.candidate) if args.candidate else None
    Q, result = audit(table, candidate)
    result["baseline_native_sha256"] = BASELINE_SHA256
    result["finite_window_audit"] = window_audit(table)
    result["negative_controls"] = negative_controls(table)
    result["quotient_native_sha256"] = hashlib.sha256(encode(Q)).hexdigest()
    dense_map = {q: i for i, q in enumerate(sorted({q for q, b in Q}))}
    dense_map[254] = 221
    dense = encode(Q, dense_map.__getitem__)
    result["quotient_dense_sha256"] = hashlib.sha256(dense).hexdigest()
    if args.emit_directory:
        args.emit_directory.mkdir(parents=True, exist_ok=True)
        (args.emit_directory / "u221.native.tm").write_bytes(encode(Q))
        (args.emit_directory / "u221.tm").write_bytes(dense)
        (args.emit_directory / "dense_map.json").write_text(json.dumps(dense_map, indent=2) + "\n")
    text = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(text)
    print(text, end="")


if __name__ == "__main__":
    main()
