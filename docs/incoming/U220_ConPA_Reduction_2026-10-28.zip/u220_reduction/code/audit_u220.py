#!/usr/bin/env python3
"""Independent source-rotation, selector-fold, and startup audit for U220.

Imports no construction/search or inherited symbolic runtime implementation.
The whole-tape arbitrary-register proof remains a separate obligation.
"""
from pathlib import Path
import argparse
import hashlib
import json
from audit_guarded_fold import read_table, predecessors, require, encode

PIVOT = "11010010011101010110111111100"


def source(path):
    rows = json.loads(Path(path).read_text())
    leaves = {p: (i, op, arg) for i, (p, op, arg) in enumerate(rows)}
    require(len(leaves) == len(rows), "duplicate source leaf")
    require(list(leaves) == sorted(leaves), "nonlexical source order")
    prefixes = {p[:i] for p in leaves for i in range(len(p))}
    require(not prefixes.intersection(leaves), "overlapping source leaf")
    require(all(p + b in prefixes or p + b in leaves
                for p in prefixes for b in "01"), "incomplete source tree")
    require(all(op in ("CI", "CD", "CB", "CC", "CH") for p, op, a in rows),
            "invalid source instruction")
    return rows, leaves, prefixes


def graph(rows):
    leaves = {p: i for i, (p, op, arg) in enumerate(rows)}
    depth = max(map(len, leaves))

    def lookup(prefix):
        extended = prefix + "0" * depth
        for length in range(depth + 1):
            short = extended[:length]
            if short in leaves:
                require("1" not in prefix[length:], "nonzero stray source suffix")
                return leaves[short]
        raise ValueError("source counter has no next leaf")

    def advance(p):
        if not p:
            return ""
        return format((int(p, 2) + 1) % (1 << len(p)), "0%db" % len(p))

    def discard(p, bit, count):
        for i in range(len(p) - 1, -1, -1):
            if p[i] == bit:
                count -= 1
                if count == 0:
                    return p[:i]
        return ""

    result = []
    for p, op, arg in rows:
        if op == "CI":
            edges = [lookup(advance(p))]
        elif op == "CD":
            edges = [lookup(advance(discard(p, "0", 1))), lookup(advance(p))]
        elif op == "CB":
            edges = [lookup(advance(discard(p, "0", arg)))]
        elif op == "CC":
            edges = [lookup(discard(p, "1", arg))]
        else:
            edges = []
        result.append((op, arg, edges))
    require(lookup("") == 0, "wrong root source entry")
    return result


def rotation_audit(oldrows, newrows, before, after):
    expected = []
    factors = []
    for label, oldprefix in (("A", PIVOT + "0"), ("B", PIVOT + "10"),
                             ("C", PIVOT + "11")):
        factor = [(p[len(oldprefix):], op, arg) for p, op, arg in oldrows
                  if p.startswith(oldprefix)]
        require(factor, "missing rotation factor")
        for p, op, arg in factor:
            require(op != "CH", "halting factor is not closed")
            require(op != "CD" or p.count("0") >= 1, "escaping decrement")
            require(op != "CB" or p.count("0") >= arg, "escaping break")
            require(op != "CC" or p.count("1") >= arg, "escaping continue")
        factors.append({"factor": label, "leaves": len(factor), "closed": True})
    require([x["leaves"] for x in factors] == [19, 28, 56], "wrong factor lengths")
    for p, op, arg in oldrows:
        if p.startswith(PIVOT + "0"):
            p = PIVOT + "00" + p[len(PIVOT) + 1:]
        elif p.startswith(PIVOT + "10"):
            p = PIVOT + "01" + p[len(PIVOT) + 2:]
        elif p.startswith(PIVOT + "11"):
            p = PIVOT + "1" + p[len(PIVOT) + 2:]
        expected.append([p, op, arg])
    require(newrows == expected, "new source is not the exact single rotation")
    require([x[1:] for x in oldrows] == [x[1:] for x in newrows], "primitive word changed")
    oldgraph, newgraph = graph(oldrows), graph(newrows)
    require(oldgraph == newgraph, "guarded successor graph changed")
    require(predecessors(before, 145) == [(506, 1, 1, 1, 145)],
            "physical right child has another entrance")
    require(before[506, 0] == (0, 1, 19) and before[506, 1] == (1, 1, 145)
            and before[145, 0] == (0, 1, 215) and before[145, 1] == (1, 1, 504),
            "unexpected old rotation rows")
    expected_table = dict(before)
    expected_table.update({(506, 0): (0, 1, 145), (506, 1): (1, 1, 504),
                           (145, 0): (0, 1, 19), (145, 1): (1, 1, 215)})
    require(after == expected_table, "extraneous or missing rotation table change")
    return {"factors": factors, "primitive_occurrences": len(oldrows),
            "changed_addresses": sum(x[0] != y[0] for x, y in zip(oldrows, newrows)),
            "primitive_word_identical": True, "guarded_CFG_identical": True,
            "maximum_new_depth": max(len(p) for p, op, arg in newrows),
            "maximum_new_zero_run": max(len(z) for p, op, arg in newrows
                                        for z in p.split("1")),
            "exact_four_row_patch": True}


def selector_audit(before, after):
    require(predecessors(before, 145) == [(506, 0, 0, 1, 145)],
            "keep-state predecessor tag is not certified zero")
    require(predecessors(before, 134) == [(156, 1, 1, 1, 134), (210, 1, 1, 1, 134)],
            "drop-state predecessor tag is not certified one")
    require(before[145, 1] == before[134, 1] == (1, 1, 215), "common read-one row differs")
    require(before[145, 0] == (0, 1, 19) and before[134, 0] == (0, 1, 203),
            "unexpected selected successors")
    require(before[507, 0] == (0, 1, 166) and before[507, 1] == (1, 1, 163),
            "helper does not preserve/read preceding tag")
    require(before[166, 0] == before[145, 0] and before[163, 0] == before[134, 0],
            "selector arms do not reproduce original transitions")
    phi = lambda q: 145 if q == 134 else q
    expected = {(q, b): (w, d, phi(z)) for (q, b), (w, d, z) in before.items() if q != 134}
    expected[145, 0] = (0, -1, 507)
    require(after == expected, "candidate is not exact selector fold")
    require(len(after) == 440, "candidate does not have 220 states")
    # Exhaustive finite local simulations include arbitrary adjacent bits.
    cases = 0
    for oldstate, tag in ((145, 0), (134, 1)):
        for read in (0, 1):
            for left in (0, 1):
                for right in (0, 1):
                    initial = {-2: left, -1: tag, 0: read, 1: right}
                    oldtape, newtape = initial.copy(), initial.copy()
                    w, d, q = before[oldstate, read]
                    oldtape[0] = w
                    wanted = (phi(q), d, oldtape)
                    q, head = 145, 0
                    for _ in range(3 if read == 0 else 1):
                        require(head in newtape, "selector inspected unrepresented context")
                        w, d, q = after[q, newtape[head]]
                        newtape[head] = w
                        head += d
                    require((q, head, newtape) == wanted, "selector local simulation failed")
                    cases += 1
    return {"status": "PASS", "keep": 145, "drop": 134, "helper": 507,
            "invariant": ["q=145 implies tape[head-1]=0", "q=134 implies tape[head-1]=1"],
            "local_cases": cases, "direct_duration": 1, "selected_duration": 3,
            "forbidden_extra_entrances": True, "new_states": 220,
            "scope": "All runs from state 0 on any tape; positive finite stuttering"}


def decoder_entries(table, prefixes):
    entries = {}
    for p in sorted(prefixes, key=lambda x: (len(x), x)):
        tape = {-1: 1, **{i: int(b) for i, b in enumerate(p)}}
        initial = tape.copy()
        q, head = 84, 0
        for _ in range(500):
            if head == len(p):
                break
            require(head in tape, "decoder reads beyond known address")
            w, d, q = table[q, tape[head]]
            tape[head] = w
            head += d
        else:
            raise ValueError("decoder failed to consume prefix")
        require(tape == initial, "decoder changes address prefix")
        entries[p] = q
    return entries


def bootstrap(table, steps=95714):
    ones = set()
    q = h = 0
    for _ in range(steps):
        require(q != 254, "unexpected bootstrap halt")
        w, d, q = table[q, int(h in ones)]
        if w:
            ones.add(h)
        else:
            ones.discard(h)
        h += d
    return q, h, sorted(ones)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--u221", required=True, type=Path)
    ap.add_argument("--u222-source", required=True, type=Path)
    ap.add_argument("--candidate-directory", required=True, type=Path)
    ap.add_argument("--output", required=True, type=Path)
    a = ap.parse_args()
    directory = a.candidate_directory
    before = read_table(a.u221)
    prefold = read_table(directory / "u221_rotated.native.tm")
    candidate = read_table(directory / "u220.native.tm")
    oldrows, oldleaves, oldprefixes = source(a.u222_source)
    newrows, newleaves, newprefixes = source(directory / "sites.json")
    report = {"status": "PASS", "rotation": rotation_audit(oldrows, newrows, before, prefold),
              "selector_fold": selector_audit(prefold, candidate)}
    oldentries = decoder_entries(before, oldprefixes)
    preentries = decoder_entries(prefold, newprefixes)
    require([p for p, q in oldentries.items() if q == 506] == [PIVOT], "rotation root aliases")
    require([p for p, q in oldentries.items() if q == 145] == [PIVOT + "1"], "rotation child aliases")
    require(preentries[PIVOT] == 506 and preentries[PIVOT + "0"] == 145,
            "rotated decoder points to wrong source nodes")
    report["decoder_prefix_audit"] = {"old_internal_prefixes": len(oldprefixes),
                                       "new_internal_prefixes": len(newprefixes),
                                       "root_aliases": [PIVOT], "child_aliases": [PIVOT + "1"]}
    oldboot, newboot = bootstrap(before), bootstrap(candidate)
    require(oldboot == newboot, "whole-tape bootstrap checkpoints differ")
    require(oldboot[0] == 84 and oldboot[1] == -8, "unexpected source seed location")
    report["bootstrap"] = {"steps": 95714, "state": 84, "head": -8,
                            "one_cell_count": len(oldboot[2]), "whole_tape_identical": True}
    report["candidate_native_sha256"] = hashlib.sha256((directory / "u220.native.tm").read_bytes()).hexdigest()
    report["source_sha256"] = hashlib.sha256((directory / "sites.json").read_bytes()).hexdigest()
    report["remaining_obligation"] = "Whole-tape arbitrary-register runtime proof for rotated source/candidate table"
    text = json.dumps(report, indent=2, sort_keys=True) + "\n"
    a.output.write_text(text)
    print(text, end="")


if __name__ == "__main__":
    main()
