#!/usr/bin/env python3
"""Reconstruct and verify the U222 -> U220 research release offline.

Default: exact reconstruction, source CFGs, both local invariants, independent
source/selector audit, complete blank startup, negative controls, and byte
agreement under normal/optimized Python. --full additionally regenerates
every symbolic runtime derivation for U222, U221, and U220.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE_SHA = "d23e80857214900f8e0806f03f6df752af501dd0108eb92c6ed7a49795802652"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def integrity():
    entries = {}
    for line in (ROOT / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        p = ROOT / name
        require(p.resolve().is_relative_to(ROOT), "manifest escapes release")
        require(name not in entries and len(expected) == 64, "invalid manifest entry")
        require(p.is_file() and sha(p) == expected, "hash mismatch: " + name)
        entries[name] = expected
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob("*")
              if p.is_file() and "__pycache__" not in p.parts
              and p.name != "SHA256SUMS" and p.suffix != ".pyc"}
    require(actual == set(entries), "manifest/file inventory mismatch")
    require(sha(ROOT / "upstream/U222_ConU_2026-10-28.zip") == ARCHIVE_SHA,
            "baseline archive pin")
    return len(entries)


def command(args, log, optimized=False, expect_failure=False):
    cmd = [sys.executable, "-B"] + (["-O"] if optimized else []) + list(map(str, args))
    env = dict(os.environ)
    env.pop("PYTHONOPTIMIZE", None)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, cwd=ROOT, env=env)
    log.write_text(result.stdout)
    if expect_failure:
        require(result.returncode != 0, "required refusal was not enforced")
    elif result.returncode:
        raise RuntimeError("check failed: " + str(args[0]) + "\n" + result.stdout[-9000:])
    return result.stdout


def saved_runtime(kind, table, sites):
    directory = ROOT / "evidence" / kind
    report = json.loads((directory / "runtime.json").read_text())
    cases = json.loads((directory / "runtime_cases.json").read_text())
    source = json.loads(sites.read_text())
    expected = {(i, p) for i, (_, op, _) in enumerate(source)
                for p in ((False, True) if op == "CD" else (False,))}
    require(report["status"] == "UNIVERSAL_MATHEMATICAL_PASS", kind + " status")
    require(report["proved_cases"] == report["expected_cases"] == len(cases) == 5060,
            kind + " case count")
    require({(c["site_index"], c["positive"]) for c in cases} == expected,
            kind + " case coverage")
    require(all(c["duration"][0] > 0 and all(n >= 0 for n in c["duration"])
                for c in cases), kind + " finite positive progress")
    require(report["table_sha256"] == sha(table) and report["sites_sha256"] == sha(sites),
            kind + " runtime input binding")
    require(report["checker_sha256"] == sha(ROOT / "code/runtime/symbolic_runtime.py")
            and report["helper_sha256"] == sha(ROOT / "code/runtime/independent_runtime.py"),
            kind + " runtime checker binding")
    require(report["failures"] == [] and len(report["blocks"]) == 4,
            kind + " symbolic blocks/failures")
    startup = json.loads((directory / "startup.json").read_text())
    require(startup["status"] == "CALIBRATED_DIRTY_ROOT_SEED"
            and startup["steps"] == 95714 and startup["state"] == 84
            and startup["head"] == -8 and startup["gap"] == 1
            and startup["registers"] == [4, 0, 0, 0, 0, 0, 0, 0, 0]
            and startup["spares"] == [1] * 40 and len(startup["one_cells"]) == 95,
            kind + " saved startup binding")
    return report, cases, startup


def compare_runtime(fresh, saved):
    for name in ("runtime_cases.json", "startup.json"):
        require(json.loads((fresh / name).read_text()) ==
                json.loads((saved / name).read_text()), "fresh " + name + " differs")
    a = json.loads((fresh / "runtime.json").read_text())
    b = json.loads((saved / "runtime.json").read_text())
    a.pop("seconds", None)
    b.pop("seconds", None)
    require(a == b, "fresh symbolic runtime summary differs")


def extract_original(destination):
    with zipfile.ZipFile(ROOT / "upstream/U222_ConU_2026-10-28.zip") as archive:
        for member in archive.infolist():
            path = destination / member.filename
            require(not Path(member.filename).is_absolute()
                    and path.resolve().is_relative_to(destination.resolve()),
                    "unsafe archive member")
            require((member.external_attr >> 16) & 0o170000 != 0o120000,
                    "archive symlinks are not expected")
        archive.extractall(destination)
    base = destination / "u222_consistency_machine"
    for local, original in (("inputs/u222.native.tm", "machine/u.native.tm"),
                            ("inputs/u222.tm", "machine/u.tm"),
                            ("inputs/u222_sites.json", "machine/sites.json")):
        require((ROOT / local).read_bytes() == (base / original).read_bytes(),
                "baseline copy/archive mismatch")
    return base


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--full", action="store_true")
    ap.add_argument("--report", type=Path,
                    help="write fresh receipt OUTSIDE the sealed release")
    args = ap.parse_args()
    require(not args.full or (__debug__ and sys.flags.optimize == 0),
            "--full requires enabled assertions; do not run under -O")
    if args.report:
        require(not args.report.resolve().is_relative_to(ROOT),
                "put the new receipt outside the sealed release")
    started = time.monotonic()
    files = integrity()
    print("PASS: release integrity (" + str(files) + " files)", flush=True)
    receipt = {"status": "U220_FULL_REPRODUCTION_PASS" if args.full
               else "U220_STRUCTURAL_REPRODUCTION_PASS",
               "manifest_files_checked": files, "working_states": 220,
               "transition_rows": 440, "native_sha256": sha(ROOT / "machine/u220.native.tm"),
               "dense_sha256": sha(ROOT / "machine/u220.tm"),
               "source_sha256": sha(ROOT / "machine/sites.json")}
    with TemporaryDirectory(prefix="u220-replay-") as tmp:
        work = Path(tmp)
        original = extract_original(work / "original")
        for mode in ("normal", "optimized"):
            out = work / mode
            out.mkdir()
            opt = mode == "optimized"
            command([ROOT / "code/build_u220.py", "--baseline-table",
                     ROOT / "inputs/u222.native.tm", "--baseline-source",
                     ROOT / "inputs/u222_sites.json", "--output", out / "machine"],
                    out / "build.log", optimized=opt)
            for generated in (out / "machine").iterdir():
                require(generated.read_bytes() == (ROOT / "machine" / generated.name).read_bytes(),
                        "reconstruction mismatch: " + generated.name)
            command([ROOT / "code/audit_guarded_fold.py", ROOT / "inputs/u222.native.tm",
                     "--candidate", out / "machine/u221.native.tm",
                     "--output", out / "guard.json", "--emit-directory", out / "guard-machine"],
                    out / "guard.log", optimized=opt)
            require((out / "guard-machine/u221.tm").read_bytes() ==
                    (ROOT / "machine/u221.tm").read_bytes(), "U221 dense identity")
            command([ROOT / "code/audit_u220.py", "--u221", out / "machine/u221.native.tm",
                     "--u222-source", ROOT / "inputs/u222_sites.json",
                     "--candidate-directory", out / "machine", "--output", out / "audit.json"],
                    out / "audit.log", optimized=opt)
            command([ROOT / "code/verify_tagged_fold_u220.py",
                     out / "machine/u221_rotated.native.tm", out / "machine/u220.native.tm",
                     "--output", out / "selector.json"], out / "selector.log", optimized=opt)
            print("PASS: " + mode + " reconstruction, source, invariants, selector, blank startup",
                  flush=True)
        for name in ("guard.json", "audit.json", "selector.json"):
            require((work / "normal" / name).read_bytes() ==
                    (work / "optimized" / name).read_bytes(), "optimization-dependent audit")
        for fresh, saved in (("guard.json", "guarded_fold_certificate.json"),
                             ("audit.json", "u220_independent_audit.json"),
                             ("selector.json", "tagged_fold_u220_certificate.json")):
            require(json.loads((work / "normal" / fresh).read_text()) ==
                    json.loads((ROOT / "evidence" / saved).read_text()),
                    "stored structural audit differs: " + saved)
        pairs = [("u221", ROOT / "machine/u221.native.tm", ROOT / "inputs/u222_sites.json"),
                 ("u220", ROOT / "machine/u220.native.tm", ROOT / "machine/sites.json")]
        for kind, table, sites in pairs:
            saved_runtime(kind, table, sites)
        receipt.update({"exact_reconstruction": True, "normal_optimized_byte_identity": True,
                        "guarded_quotient_enabled_rows": 443,
                        "source_primitive_occurrences": 3891,
                        "source_guarded_CFG_identity": True,
                        "changed_leaf_addresses": 103, "startup_steps": 95714,
                        "independent_complete_tape_startup": True,
                        "saved_runtime_cases_per_machine": 5060,
                        "symbolic_runtime_regenerated": args.full,
                        "baseline_archive_identity_checked": True})
        if args.full:
            refused = command([ROOT / "code/validate_native.py", pairs[-1][1], pairs[-1][2],
                               work / "must-refuse"], work / "optimized-refusal.log",
                              optimized=True, expect_failure=True)
            require("requires enabled assertions" in refused, "wrong optimized refusal")
            print("PASS: inherited symbolic checker rejects -O", flush=True)
            print("Checking original U222 reconstruction and all 5,060 cases...", flush=True)
            command([original / "reproduce.py", "--full", "--report", work / "baseline.json"],
                    work / "baseline.log")
            baseline = json.loads((work / "baseline.json").read_text())
            require(baseline["status"] == "U222_FULL_REPRODUCTION_PASS"
                    and baseline["symbolic_cases"] == 5060, "baseline full verification")
            print("PASS: original U222 full verification", flush=True)
            for kind, table, sites in pairs:
                print("Checking " + kind.upper() + ": all 5,060 symbolic cases...", flush=True)
                fresh = work / (kind + "-runtime")
                command([ROOT / "code/validate_native.py", table, sites, fresh],
                        work / (kind + "-runtime.log"))
                compare_runtime(fresh, ROOT / "evidence" / kind)
                print("PASS: " + kind.upper() + " complete symbolic and startup replay", flush=True)
            receipt["all_three_symbolic_case_suites_regenerated"] = True
        receipt["seconds"] = round(time.monotonic() - started, 3)
        receipt["proof_status"] = "Ordinary PA-formalizable proof with executable checks; no new kernel endpoint."
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps(receipt, indent=2), flush=True)


if __name__ == "__main__":
    main()
