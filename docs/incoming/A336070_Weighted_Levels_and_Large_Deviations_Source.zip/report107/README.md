# Report 107 Weighted Weak Ascent Levels and Their Probability Law

Prepared for Vladimir, 2 October 2026. This is a separate, self-contained report;
report 105 has not been modified and is not needed to build or read this report.

## Files

- `report107.pdf`: final 18-page article
- `report107.tex`: complete editable TeX source, including every needed calibration
  and quadratic-corrector lemma and the weighted upper and lower proofs
- `build.sh`: deterministic three-pass pdfLaTeX build
- `replay.sh`: manifest, exact-check, corruption, and PDF-rebuild replay
- `checks/`: the sole finite exact-rational verifier, fixtures, independent
  finite formulations, expected summary, corruption campaign, and logs
- `PROVENANCE.json`: primary-source attribution and fixed input digests
- `VALIDATION.json`: scope and completed validation evidence
- `REPLAY_RESULT.json`: successful fresh-ZIP payload replay and pinned rebuilt PDF
- `MANIFEST.sha256`: SHA-256 for all bundled payload files except itself

The final PDF is included in the ZIP. Rendered page images, TeX intermediate files,
external papers, and analytical review notes are not bundled.

## Main conclusions

For level weight w in any fixed compact subset of (0,infinity),

    log H_n(w) = log(n!) + n log(6/pi^2) + (w/2)(log n)^2
                 + O_W((log n)^2/log log n).

Under this weight, the level count divided by (log n)^2 tends to w/2 in probability
and every fixed L^p. The full LDP has rate

    I_w(x) = x log(2x/w) - x + w/2    for x >= 0,
             infinity               for x < 0.

The exact-zero logarithmic rate is -w/2. Its numerator uses the established
primitive Fishburn asymptotic. The primitive/all ratio exp(-pi^2/6), including the
binomial-transform proof, is already Jelínek Fact 5.2, credited to Drmota; it is
not claimed as new. The report combines that prior result with its positive-weight
theorem.

The threshold inverse has signed correction

    -w (log x)^2 / (2 log((6/pi^2)x)),

and error O_W(log x/log log x), where x is the leading Lambert inverse. Exact
child-weight summation proves monotonicity for every real positive w; integer w
also gives an exact colored-object count.

No total-variation Poisson approximation, mod-Poisson convergence, CLT, local
limit, variance equivalent, sharp tail prefactor, positive-level atom equivalent,
amplitude, full transseries, or uniformity in weights tending to zero is asserted.
The counting estimate is logarithmic, not a relative-error equivalent. The
inverse error is asymptotic, not a certified finite numerical error bar.

## Reproduce

From the extracted directory:

```sh
sha256sum -c MANIFEST.sha256
python3 checks/verify_exact.py
python3 -O checks/verify_exact.py
python3 checks/run_checks.py
./build.sh
```

Or run the complete payload replay:

```sh
bash replay.sh
```

Python 3 uses only its standard library. The PDF build needs pdfTeX/pdfLaTeX,
TeX Live's standard article and AMS packages, Latin Modern, microtype, geometry,
enumitem, fancyhdr, xcolor, and hyperref. No network access or earlier report is
needed. The build script initializes a local format when necessary and uses
`SOURCE_DATE_EPOCH=1790899200`; dates and trailer identifiers are suppressed.
PDF byte identity is verified on the recorded toolchain and may differ with
other TeX/font versions even when mathematical content is identical.

`checks/README.md` explains the exact rational normalization. Rational r and w
with v=r^(-M) make the kernels rational; q=-M log r is symbolic, and the corrector
identities are divided by q. The true q=0 case is separate. There are no floating
mathematical checks labelled exact. Finite checks do not prove asymptotic or
uniform analytical estimates; those are proved in the article.

All 31 deliberate corruptions are rejected at their intended guards both normally
and under Python -O, for 62 nonzero corrupted exits. The guards are explicit
conditionals and exceptions, not removable assertions. The report's mathematical
claims remain the arguments in its text, not these finite tests.
