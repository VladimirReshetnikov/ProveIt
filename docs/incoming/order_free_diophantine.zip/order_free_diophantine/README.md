# Order-Free Diophantine Self-Assembly
## And a Sharp Positivity-Restricted Degree Threshold

Research article prepared for Vladimir Reshetnikov, September 30, 2026.

## Main mathematical results

For a fixed finite tuple of natural inputs, existential representation by
an integer polynomial nonnegative on the **entire real nonnegative orthant,
inputs and witnesses jointly**, has the exact classification:

- Degree at most two and degree at most three represent exactly semilinear sets.
- Every semilinear set has a **single-fold degree-two** representation in this
  class: exactly one natural witness per member.
- Degree at most four represents every computably enumerable set.

The source gives full proofs: a facewise cubic-zero/Hessian lemma, an
arithmetic semilinearity argument, an effective algebraic-sampling
refinement, a direct quadratic semilinear construction, a stronger unique
Presburger-evaluation construction, and quartic circuit normalization.
The square numbers already separate degrees three and four in this class.

For seeded irreversible tile assembly with nonnegative glues, the article
also constructs a globally nonnegative **convex quadratic** with exactly one
natural zero for each producible labelled assembly in a fixed finite domain.
The certificate uses unique earliest-arrival ranks rather than a chosen
assembly order. There is a whole-grid terminality extension, including
interior vacancies and an exterior one-neighbor halo.

The base compiler has exactly

    m   = N(q+6) - 3s + 8K + 10J variables
    ell = 5N - s + 6K + 8J affine equations

where N is the domain size, q the number of real tile types, s the seed
size, K the number of eligible ordered neighbor pairs, and J the number
of positive type-compatibility tuples on those pairs. The polynomial is
the sum of the squares of the affine residuals. The representation is
linear-size for a fixed palette, but its arity grows with the finite domain.

## Contents

- `order_free_diophantine.tex`: self-contained LaTeX article with references.
- `order_free_diophantine.pdf`: compiled article.
- `code/assembly_compiler.py`: exact sparse affine compiler, witness
  constructor, two independent finite dynamics routines, and certificate
  export/checking.
- `code/presburger_gadgets.py`: unique natural witnesses for signed unbounded
  comparison and constant-modulus divisibility. This is not a complete
  Presburger quantifier eliminator.
- `code/verify.py`: complete finite checks and report generator.
- `data/verification_report.json`: exact test results.
- `data/*_certificate.json`: four literal sparse affine systems with natural
  witnesses. These are actual coefficient lists, not merely calls to a compiler.
- `build.sh`: two-pass PDF build.
- `SHA256SUMS`: integrity hashes for the delivered content, excluding itself.

## Reproduce

The Python programs require Python 3.10 or later and only its standard library.
Run without Python's `-O` flag, since test assertions are intentional:

    python code/verify.py

This regenerates the report and all four JSON certificates. It checks 3,830
seed-extending target labelings across four systems. The resulting counts are:

| Fixture | Producible labelled assemblies | Whole-grid terminal assemblies | Orders for the selected full target |
|---|---:|---:|---:|
| Diamond | 7 | 0 | 4 |
| Capped star | 16 | 1 | 24 |
| Alternative north-label star | 24 | 2 | 24 |
| Cooperative square | 5 | 1 | 2 |

Additional tests include 568 bounded comparison cases, all 12 two-/three-input
Boolean conjunction cases, 3,882 rank assignments for producible targets,
125 rank assignments across all diamond targets, 1,304 rejected witness
perturbations, 476,656 assignments for a semilinear quadratic example,
121 signed unbounded comparison cases, and 186 signed divisibility cases.

To check one exported certificate independently of compiler construction:

    python -c "import sys; sys.path.insert(0, 'code'); from assembly_compiler import verify_export; print(verify_export('data/capped_star_certificate.json'))"

The result is `(256, 196)`: variables and affine equations.

Each saved row denotes

    row['constant'] + sum(coefficient * witness[index] for index, coefficient in row['terms']) = 0.

All witness coordinates must be nonnegative integers. The represented
polynomial is exactly the sum of the squares of those rows.

For the PDF, use a standard TeX Live installation with `pdflatex`, `newtx`,
`amsmath`, `amsthm`, `mathtools`, `microtype`, `geometry`, `enumitem`,
`booktabs`, `tikz`, `tcolorbox`, `fancyhdr`, `hyperref`, and `bookmark`:

    sh build.sh

No separate bibliography program is needed. No external fonts, artwork,
or downloaded research papers are required or included.

## Scope and verification status

The article contains mathematical proofs, not a claimed proof-assistant
formalization. The new proofs and compiler have **not** been Lean- or
Rocq-kernel checked. Exact finite tests exercise the implementation; they
do not replace the general proofs. Historical publication priority for
these formulations has not been established.

The cubic theorem is restricted to real-orthant nonnegativity; it does not
solve the unrestricted cubic Diophantine problem. The single-fold result
for semilinear sets and the object-faithful finite assembly compiler do
not solve single-fold or finite-fold MRDP for arbitrary computably
enumerable sets. Quartic normalization preserves uniqueness of added gate
values *relative to an original witness*, not uniqueness of that witness.

Tile assembly uses fixed orientations, matching nonnegative integer glues,
positive temperature, a stable finite seed, and single-tile irreversible
accretion. The prototype checks basic input validity but does not certify
stability of an arbitrary multi-tile seed; all fixtures use singleton
seeds. Negative glues, detachment, concentrations, rates, and resource
consumption are outside the compiled semantics. The article gives an
explicit signed-glue counterexample.

Distinct tile labels remain distinct even when their glues are identical.
Counting polynomial zeros counts labelled objects, not unlabelled shapes
and not construction orders.

## Repository provenance

Inspected ProveIt revision:

    4e128356d0ef75308be8ed405d89aea2ffdb8a57

Relevant inspected paths:

    Computability/HilbertTenthProblem/Lean/Diophantine/MRDP.lean
    Computability/HilbertTenthProblem/README.md
    Computability/HilbertTenthProblem/Lean/STATUS.md
    Logic/PresburgerArithmetic/README.md

The actual unbounded-representation dependency is the MRDP theorem.
The low-degree side has a proposed connection to the repository's
Presburger quantifier eliminator. No optimized operation count or
unrelated repository theorem is assumed. No remote repository file was
modified. The article bibliography contains pinned source links and the
primary literature used for context.
