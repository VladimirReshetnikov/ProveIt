SINGLE-INSTANCE REFUTATIONS FOR SMALL ZFC CONSISTENCY MACHINES
Research report prepared for Vladimir Reshetnikov
Source cutoff: 16 October 2026

READ FIRST

zfc_small_machines.pdf is the complete report. The main LaTeX file is
zfc_small_machines.tex; all included section files are beside it.

The main new result relative to the audited ProveIt materials is finite fusion
of GIC and EPSC schema instances. An arbitrary finite family can be combined
into one effectively constructed instance, giving a complete single-instance
refutation-search specification. The report includes ordinary mathematical
proofs, exact syntax costs, and the required consistency/compilation boundaries.

No new proved blank-tape machine below 253 working states is claimed.
The public253 reference is prior work by mira-emmy, derived from Mira-Cult's
machine verified by Jeff and using Andrew James Wade's framework. The known
252-state body has no certified blank initialization in this report.

CONTENTS

  *.tex                         Complete editable report and bibliography
  zfc_small_machines.pdf         Compiled, visually inspected report
  code/epsc_fusion.py            Hygienic EPSC formula construction and finite tests
  code/gic_fusion.py             Native-schema GIC construction, equality-free syntax
  code/audit_tm.py               Unchanged attributed ProveIt conservative auditor
  evidence/                     Recorded formula and radius-6/radius-7 results
  machines/                     Exact existing 253- and 254-state reference tables
  machine_experiments/           Fixed-gap symbolic audit and literal 1e9-move check
  references/                   Source audit notes and ProveIt license notice
  PROVENANCE.json               Commit pins, input hashes, scope, and attribution
  MANIFEST.sha256               Integrity hashes of the complete deliverable
  reproduce.py                  Offline reproduction driver

BUILD THE PDF

From this directory, run:

  pdflatex -interaction=nonstopmode -halt-on-error zfc_small_machines.tex
  pdflatex -interaction=nonstopmode -halt-on-error zfc_small_machines.tex
  pdflatex -interaction=nonstopmode -halt-on-error zfc_small_machines.tex

The third pass settles the contents and cross-references after initial layout.
A normal TeX Live installation with Latin Modern, AMS math, geometry, microtype,
booktabs, enumitem, listings, fancyhdr, xurl, and hyperref suffices. There is no
external BibTeX dependency or network requirement. A newly generated PDF may
have different metadata or layout under another TeX version and hence a
different byte hash; MANIFEST.sha256 identifies the distributed original.

REPRODUCE THE COMPUTATIONAL EVIDENCE

Python uses only the standard library. Run without -O/-OO, since reference
tests rely on assertions. The driver verifies the exact pinned input hashes.

  python3 reproduce.py --verify-only
      Checks source/data pins and every archived file against the manifest.

  python3 reproduce.py
      Runs both complete finite formula suites, compares the exact generated
      examples with the archived examples, and runs 11 auditor regressions.

  python3 reproduce.py --windows
      Also reruns the radius-6 and radius-7 local-window deletion searches,
      using 512 simulation steps on each side. These are the larger checks;
      allow several minutes and memory for roughly 1.13 million configurations.

  python3 reproduce.py --runtime
      Also reruns all 8,391 branches for each of D=36, D=37, and D=38+n, compiles
      the literal simulator, and checks one billion individual moves of the
      known runtime252 blank start. Requires g++ or clang++ with C++17 support.

  python3 reproduce.py --all
      Runs every check above. Generated outputs and executables go to build/.

The detailed machine_experiments/README.md also gives direct commands and the
exact tape, program-counter, register, and gap conventions. Its symbolic audit
regenerates an identical legal-PC word file from the pinned program tree.

WHAT WAS AND WAS NOT VERIFIED

Both formula suites, their exact generated examples, the conservative auditor
self-tests, both larger-window searches, all three symbolic runtime families,
and the billion-move literal diagnostic were run for this report.

The GIC mathematical theorem also permits native-equality matrices. The Python
formula datatype implements the equality-free sublanguage. Its finite tests
support the implementation; the written proofs justify the unbounded results.
It does not emit first-order proof certificates or implement a TM compiler.

No Lean or Coq rebuild was performed locally. The report distinguishes the
upstream external halting/refutation theorem from the internal-ZFC argument
requested by the project. The supplied machine audits are finite executable
checks, not kernel-certified proofs of their Python/C++ implementations.

The local-window searches found no one-state deletion certificate. The runtime
audit admits D>=36 at its symbolic-checker level. The billion-move diagnostic
found no canonical legal-PC register frame with D>=36. Neither negative result
is a minimality theorem or a proof of infinite nonhalting.

PINS AND ATTRIBUTION

ProveIt:       426592ce97e52d309bfb8f0132411556650b7ac1
Jeff254:      297ab8df7e5de329605c3875b4934643b371a5e3
mira-emmy253: 0d544f2a2e3c18f12278441a74b7879f31cbe856

The 253-state submission was open/unmerged in jeff87654/busy-beaver PR20 when
inspected. The exact table SHA-256 is:
84a21f714017c1d491008d86e9bd19c43cc6c5c9ae99a538b4f2314387827d95

Full primary-source links and the requested commit audit are in the report.
Preserve upstream attributions and source notices when incorporating files.
The ProveIt auditor is covered by the included ProveIt MIT No Attribution
notice. No license is inferred or newly assigned to the other attributed
upstream snapshots; their observed metadata is recorded in the nested
PROVENANCE.json. The report and new reference implementations were prepared
for incorporation into ProveIt.
