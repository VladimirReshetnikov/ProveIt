# Witness-Faithful Diophantine Compilation

**Concurrent traces, priority arithmetic, and context-local rewriting**  
Research article prepared for Vladimir Reshetnikov, September 30, 2026.

## Read

`article.pdf` is the complete article; `article.tex` is its self-contained LaTeX
source, including bibliography. It supplies conventional mathematical proofs,
exact resource counts, ten research questions, and a validation appendix.

The main results are:

- One natural zero of an explicit quartic per independent-swap class of bounded
  Petri-net executions. For p places, r actions, and horizon T, the displayed
  construction uses (p+r)(2T+1) variables and 2p+r+T(2p+2r+2) residuals.
- A bounded FRACTRAN compiler respecting the *first* applicable fraction, with
  exactly one complete witness for an actual run. The counts are T(7r+2)+1
  variables and T(8r+3)+2 residuals, plus 3r variables and 2r residuals for an
  optional terminal test.
- A unique-witness SKI compiler for an externally fixed schedule, using variables
  linear in the number of steps and total selected context depth. Whole subterms
  are represented by natural codes. Large-code bit costs are explicitly bounded
  and are not treated as free.

All witness coordinates are nonnegative integers. Residuals are integer
polynomials; subtraction is NOT truncated natural subtraction. The one-equation
interpretation is the sum of squared residuals. Each residual has degree at most
two, so that polynomial has degree at most four.

## Run the exact checks

Python 3.10+ and its standard library suffice; no packages need to be installed.
From this directory:

```sh
python tests/run_tests.py
python code/verify_certificate.py examples/*.json
```

On a shell that does not expand wildcards, pass the four JSON paths explicitly:

```sh
python code/verify_certificate.py examples/petri_fork_join.json examples/fractran_first_halt.json examples/ski_SKII.json examples/ski_context.json
```

The independent JSON verifier does not import the compiler. It validates and
exactly evaluates the exported residuals and supplied assignment. The test suite
regenerates `tests/results.json` and the example JSON files. Runtime measurements
can differ across machines; the mathematical counts should agree.

The suite checks 90,404 words against independently constructed commutation
classes, the exponential-state lower-bound family through k=7, 1,417 enabled
Petri-run certificates, 4,914 FRACTRAN certificates, and 1,875 SKI certificates.
It also checks exact variable/equation counts, quadratic degrees, and local
witness mutations. These are finite tests, not proofs of universal correctness.

## Use a compiler

```python
import sys
sys.path.insert(0, "code")
from diophantine_compiler import compile_fractran

system = compile_fractran(
    ((3, 2), (5, 3)), start=8, finish=125, horizon=6, terminal=True
)
assert system.energy() == 0
system.dump("my_certificate.json")
```

A compiler constructs the residual system without searching for arbitrary roots.
`compile_fractran(..., witness=False)` and `compile_ski(..., witness=False)`
construct a system without simulating a witness. `compile_petri` constructs a
system without a witness when `word=None`. Supplied candidate endpoints need not
be correct: their endpoint residual detects a mismatch. Attempting to simulate
an invalid prescribed execution raises an error; use the no-witness mode to
construct such an unsatisfiable instance instead.

A Petri candidate firing word can be valid but noncanonical. Its constructed
assignment then has nonzero energy, exactly as intended. SKI schedules are
external rule/path lists; this package does not claim a linear-size compiler for
existentially chosen unbounded paths.

## Build the PDF

A standard TeX Live installation with pdfLaTeX suffices:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `latexmk -pdf article.tex`. There is no external bibliography
file, image asset, or nonstandard font file. An extra LaTeX pass can be needed
after changing pagination. PDF bookmarks and linked contents are included.

## Research and verification status

The exact constructions and proofs were developed for this article. Established
MRDP results, trace normal forms, circuit quadratization, and earlier FRACTRAN
arithmetization are explicitly credited. Global mathematical priority for the
particular constructions has not been established; no independently confirmed
breakthrough claim is made.

These are horizon- or schedule-indexed polynomial families. They do **not** solve
the fixed-arity finite-fold or single-fold representation problem for universal
unbounded computation, nor do their variable counts improve known universal
polynomial pairs. They also do not give a general Diophantine solver.

No new Lean or Rocq/Coq proof was compiled. The existing ProveIt build was not
rerun. See `research/SOURCE_AUDIT.md` for the pinned repository snapshot, inspected
files, and the distinction between inherited results and the present work.

## Files

- `article.pdf`, `article.tex`: mathematical article and source.
- `code/diophantine_compiler.py`: exact sparse-polynomial compilers.
- `code/verify_certificate.py`: standalone exact JSON witness verifier.
- `tests/run_tests.py`, `tests/results.json`: reproducible finite checks and output.
- `tests/certificate_verification.jsonl`: independent verification of the examples.
- `examples/*.json`: four full residual systems and witnesses.
- `research/SOURCE_AUDIT.md`: provenance and scope audit.
- `MANIFEST.sha256`: integrity hashes of all other delivered files.
