# A Staircase of Polynomial Rarity

**Bulk exponents and reciprocal-threshold crossover scales for adjacency-bounded 132-avoiding permutations**

Research manuscript prepared for Vladimir Reshetnikov, 30 September 2026.

## Main results

Let M_n be the largest absolute adjacent difference in a uniform 132-avoiding permutation of size n. For every fixed 0 < theta < 1, the manuscript proves

    P(M_n <= floor(theta*n)) = Theta_theta(n^(-floor(1/theta)/2)).

It also proves, uniformly near each fixed reciprocal threshold 1/q (q >= 2),

    P(M_n <= m) asymp n^(-q/2)
                         + n^(-3*(q-1)/2) * max(q*m-n, 0)^(q-1).

Here `asymp` means bounded above and below by fixed positive multiples, not ratio convergence. The crossover scale in the bound is n^(1 - 1/(2*(q-1))): square root n at n/2, n^(3/4) at n/3, and n^(5/6) at n/4.

The main analytic ingredient is a local truncated-subcritical-renewal theorem for every power-tail index 0 < alpha < 1. The article gives its proof, the permutation constructions, exact recurrence details, and ten proposed further research directions.

## Scope and status

The order theorem resolves the exponent part of the hierarchy left open in the inspected repository README, and the missing order and order-crossover scale at n/2. Exact leading constants and limiting crossover functions are NOT proved. The manuscript does not claim an exhaustive novelty certification, independent peer review, or Lean/Rocq verification. It was prepared with AI assistance.

The proof is independent of the repository's unverified asymptotic reports. Two elementary counting envelopes are rederived and credited; the new analysis transfers matching orders through them. Finite tests are not proofs of the asymptotic assertions.

Repository snapshot: `ffddaa8b9c89e7bf027e1442cc6216bb010906d0`.
See `SOURCES.md` for exact files, blobs, and inspection limits.

## Contents

- `article.tex`, `article.pdf`: complete source and compiled 25-page manuscript.
- `code/model.py`: exact integer counters and explicit lower-construction generator.
- `code/verify.py`: finite tests and exact-count data generation.
- `code/figures.py`: optional reproduction of the two figures.
- `data/*.csv`: exact integer counts with rounded display columns.
- `data/verification_log.txt`: successful finite-check log.
- `figures/*.pdf`: vector figures required for rebuilding the article.
- `figures/*.png`: preview copies of the same figures.
- `Makefile`: convenience build, check, figure, and cleanup targets.
- `SHA256SUMS`: integrity hashes for the deliverable files (excluding the manifest itself).

## Reproduce

Run from the package directory:

```sh
python code/verify.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The exact checks require only Python's standard library (Python 3.10 or later). They enumerate all permutations through n=7 to test avoidance, compare 54 endpoint counts with exhaustive avoiders through n=9, test 13,431 lower-construction objects across 60 cases, check 276 coefficientwise sandwiches through n=24, and generate 38 illustrative larger samples. The delivered run passed all tests.

Rebuilding the PDF requires a LaTeX installation with the packages named in the preamble, including newpx, aliascnt, cleveref, microtype, and latexmk. The vector figures are included; plotting software is not needed to rebuild the PDF.

To regenerate the figures after generating the CSV files:

```sh
python code/figures.py
```

This optional step requires NumPy and Matplotlib. It uses their default plot colors. No external data or network access is needed for any reproduction step.

`make check`, `make pdf`, `make figures`, and `make clean` provide equivalent convenience targets. Regenerating files changes their hashes and invalidates the original SHA256SUMS manifest; that is expected.
