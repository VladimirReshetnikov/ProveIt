#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build article/preorder-gamma-degree-three.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build article/preorder-gamma-degree-three.tex
cp build/preorder-gamma-degree-three.pdf article/preorder-gamma-degree-three.pdf
