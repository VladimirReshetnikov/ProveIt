# Preorder gamma polynomials of actual degree at most three

This package accompanies the mathematical article `article/preorder-gamma-degree-three.tex` and its PDF. It proves, with exact finite computational components:

1. Every finite preorder with actual gamma degree at most three is rank-ultra-log-concave, with normalization by its actual degree
2. Every actual-degree-three preorder on at most fourteen vertices has real-rooted gamma; at fifteen vertices there are exactly two nonreal-rooted isomorphism classes, exchanged by order reversal
3. A general fixed-rank canonical bounded-core normal form, and the real-rooted ordinal-sum family stated in the article

The main theorem is for arbitrarily large ground sets. The proof uses the Gallai–Edmonds reduction, bounded core enumeration, and exact all-population polynomial certificates. The minimum-size theorem uses separate bounded discriminant scans whose completeness follows from the same reduction. There is no proof-assistant formalization or claim of global literature priority.

## Quick verification

Requirements: Python 3, SymPy, and `g++` with C++17 support. This package was verified using Python 3.12.14 and SymPy 1.14.0. No LP/SDP solver or floating-point root calculation is needed. Assertions are part of the verifiers: do not use Python's `-O` option.

From the package root:

```
python3 verify_all.py
```

The runner copies code and data into a temporary directory, recompiles the C++ generators, runs the independent audits and exact certificate checks, and writes fresh logs plus `receipts/verification_summary.json`. It leaves the supplied certificate data unchanged. Runtime depends on hardware; the shipped receipt reports the actual measured run.

Verify the shipped files before rerunning (rerunning intentionally changes receipts):

```
sha256sum -c SHA256SUMS
```

## Files and proof dependencies

- `article/`: the editable LaTeX source and rendered PDF
- `code/small-check/`: complete quotient-poset/block enumeration through order eight, restricted to actual degree at most three, plus an independent Hall checker. Only the order-at-most-seven lemma is needed in the main structural proof
- `code/one-attachment/`: complete marked-core enumeration; all 2050 polynomial pairs; 4236 exact quadratic certificates; independent full tuple/multiplicity audit
- `code/two-attachment/`: 1084 structural templates, 448 distinct polynomial families, 284 binomial-positive gaps, and 994 face certificates for the remaining 164 families; two independent support-count/coverage audits
- `code/cover3_seventeen_templates.json`: the 17 complete three-cover classes, including exact gamma and second-gap polynomials in binomial and monomial bases
- `code/cover3_sos_*.json`, `cover3_sdp_4.json`, `cover3_sdp_7_complete.json`: exact rational face identities, not numerical feasibility claims
- `code/audit_cover3.py`: independently verifies the full template orbit set, all support coefficients, gaps, and face-domain guards
- `code/verify_cover3_*.py`: exact compact, square, and general-square identity checks
- `code/core_templates.py`, `core_certificates.json`: the 11 all-population ordinal-sum cubics and exact discriminants
- `code/verify_layered.py`, `layered.py`, `layered_certificates.json`: the ordinal-antichain specialization, finite residual compositions, and independent direct support checks
- `code/minimum/`: original and separately written minimum-order scans, explicit minimum-size marked-core enumeration, and direct enumeration of the 15-vertex witness
- `receipts/`: exact verification outputs and summary metadata

Class 0 of the three-cover list uses the published ambient-binomial ULC theorem for bimatroids (Röhrle–Ulirsch, Theorem A), applied to a bipartite support relation whose smaller shore has size three. This is an explicit mathematical dependency, not a missing certificate or a weighted actual-rank assumption. The Gallai–Edmonds structure theorem is the other principal external input. Both primary sources and the original ProveIt report pin are cited in the article.

## Certificate data conventions

Preorder row masks omit the reflexive diagonal: bit `j` of row `i` indicates the off-diagonal arc `i -> j`. Two-attachment vertices are 0 and 1; three-cover vertices are 0, 1, and 2. Neighborhood mask `t` is its binary subset of the marked vertices. Sign -1 means attachment-to-exterior and +1 means exterior-to-attachment.

Sparse binomial polynomials are lists `[quota, coefficient]`, representing a coefficient times the product of `binom(population[i], quota[i])`. They count ordered disjoint tail/head supports, once per endpoint pair, not matchings. Rational coefficient strings are read exactly. A face mask specifies the populations made positive; those are replaced by `1+x`, while the other populations are zero. All nonnegative integer population vectors are covered by these faces. No real-population assertion between zero and one is implied.

The one-attachment `pairs.csv` has headers; its independent `audit_pairs.csv` has six integer columns without a header: p1, p2, p3, q1, q2, multiplicity. The minimum-size scan retains a proven least-order core for each five-entry tuple. Its per-order totals count chosen representations, not isomorphism classes or all polynomials at exactly that order.

## Regenerating individual families

Run these commands from the indicated directory. Generators intentionally overwrite their corresponding generated data in that directory. Use a working copy to preserve the shipped checksums.

Small cores (`code/small-check`):

```
g++ -O3 -std=c++17 exhaust.cpp -o exhaust
./exhaust .
python3 independent_verify.py
```

One attachment (`code/one-attachment`):

```
g++ -O3 -std=c++17 certify.cpp -o certify
./certify > pairs.csv
python3 verify.py
g++ -O3 -std=c++17 audit_independent.cpp -o audit_independent
./audit_independent > audit_pairs.csv
```

Two attachments (`code/two-attachment`):

```
python3 generate.py
python3 independent_audit.py
python3 verify_gap2_certificates.py
python3 verify_independent.py
```

Three-cover export and verification (`code`):

```
python3 export_cover3.py
python3 audit_cover3.py
python3 verify_cover3_compact.py
python3 verify_cover3_sos.py
python3 verify_cover3_sdp_complete.py
```

All exact rational positivity certificates are supplied. Regenerating the discovery process is unnecessary to verify them; no optimizer installation or solver output is part of the proof boundary.

Minimum order (`code/minimum`):

```
g++ -O3 -std=c++17 certify_min_size.cpp -o certify_min_size
./certify_min_size > a1_min_size_pairs.csv
cp a1_min_size_pairs.csv independent-audit/a1_pairs.csv
python3 scan_minimum.py
python3 scan_a2.py
python3 independent-audit/audit.py
python3 verify_15_supports.py
```

Ordinal family (`code`):

```
python3 core_templates.py
python3 verify_layered.py
```

## Building the article

Use a normal LaTeX installation containing Latin Modern, AMS packages, geometry, microtype, booktabs, enumitem, fancyhdr, xurl, and hyperref:

```
sh build.sh
```

This runs pdfLaTeX twice. Build files are written to `build/`. Page-by-page inspection of the delivered PDF found no clipped text, missing symbols, overlapping objects, or unresolved references.

## Scope

The minimum-order result concerns actual degree three, not all preorders through fourteen vertices. The general fixed-rank normal form does not prove higher-degree ULC or a decision procedure for integer-polynomial positivity. The first-rank inequality applies to arbitrary directed relations, but the complete cubic result uses transitivity essentially. The unweighted integer-population certificates do not automatically establish weighted or real-activity versions.
