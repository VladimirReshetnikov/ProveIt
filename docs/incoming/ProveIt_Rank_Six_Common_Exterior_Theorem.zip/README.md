# Rank Six With Common Exterior Neighborhoods

A technical note proving one-shore matching-rank ULC for arbitrary 3×3 cores with complete exterior neighborhoods. The general rank-six one-shore question remains unresolved.

## Read

- `article.pdf`: the report
- `article.tex`: editable LaTeX source
- `data/exact_certificate.json`: all 8,964 integer coefficient vectors in the proof

The coefficient vectors are in increasing powers of z=n−3 and are multiplied by 36. Each record identifies the core mask, Newton gap, exponent vector on the three weighted core variables, and counts of exterior variables occurring once and twice. All entries are nonnegative.

## Reproduce

`python3 checks/run_all.py`

Python 3.9 or later is sufficient; no third-party Python package is required. The verifier reconstructs the entire certificate by integer arithmetic and compares every vector with the included file. It also performs 100,352 independent Hall/injection support tests and verifies the explicit coefficient barrier 56−4n.

To rebuild the PDF with a normal TeX installation:

`pdflatex article.tex` (twice)

`build_local.sh` supports the supplied minimal TeX environment. It writes temporary files in `build/` and copies the final PDF to `article.pdf`.

This is an exact computer-assisted mathematical proof with independently reconstructed formulas and certificates. It is not formal theorem-prover verification or an assertion of external peer review. No numerical search output is used in the proof.
