# K221: a 221-state binary Turing machine for Con(ZFC)

This packet constructs a deterministic single-tape, two-symbol Turing machine
with **221 working states**, including blank-tape initialization, plus a
separate halt outcome. It reduces the verified 222-state witness-request/G
construction by one state.

The ordinary mathematical proof, formalizable in ZFC, establishes

\[
\mathrm{ZFC}\vdash\operatorname{Nonhalt}(M_{221},\mathrm{blank})
\longleftrightarrow\operatorname{Con}(\mathrm{ZFC}).
\]

This is an equivalence, not a proof of Con(ZFC) or unconditional nonhalting.
**No newly compiled Rocq or Lean endpoint for the exact 221-state bytes is
claimed.** No new internal PA endpoint, global priority, or minimality is claimed.

## Start here

- `report/report.pdf`: mathematical report and complete canonical transition table.
- `report/report.tex`: editable LaTeX; `report/build.sh` builds the PDF.
- `machine/k221.tm`: preferred canonical machine.
- `machine/k221.native.tm`: identical machine in inherited K labels.
- `machine/sites221.json`: exact source.
- `machine/canonicalization.json`: explicit bijection and full blank-start receipt.
- `portable/reproduce.py`: complete offline reconstruction and certificate replay.
- `verification/`: release verification receipts.
- `PROVENANCE.json`, `NOTICE.md`: exact identities, attribution and proof boundary.

From the packet root, using Python 3.10+ with assertions enabled:

```sh
python3 -B portable/reproduce.py --output-dir /tmp/k221-replay
```

Use an initially empty output directory outside `portable/`. On Windows,
an unused path such as `C:\tmp\k221-replay` can replace the example.
Python's standard library suffices; no network, optimizer or proof-assistant
installation is required. The default freshly proves all 6,167 final runtime
cases. `--quick` instead independently audits stored runtime receipts.
`--full-baseline` also rederives the parent's inherited runtime proof chain.
The distinction between fresh derivation and stored-certificate auditing is
preserved in every replay receipt.

## Exact machine convention

One tape indexed by all integers; alphabet {0,1}; initially every cell is zero;
head and state initially zero. Every transition writes one bit and moves
exactly one cell L or R. Working states are 0 through 220, with separate halt
state 221 and no outgoing halt rows. There are **442 transition rows**.
A row is `state read write direction next_state`; the directive `#! start 0`
records the initial state. The source dispatcher is canonical state 22.
Native K labels are identifiers, not consecutive state counts.

Canonical SHA-256:

```text
6457dce8c91c5975fb405607567158ca92ad97331f2724503edc0d4ff74cab3c
```

## What saves the state

Three closed source-tree rotations change no primitive instruction or guarded
branch target. They rearrange the tape-address tags so native decoder states
172 and 192 can share one state. On read 1 both already have the same action.
On read 0, existing helper 112 distinguishes the immediately preceding bit:
old state 172 has tag 0 and old state 192 tag 1. The retained state simulates
those transitions in five and three steps, respectively. No new state is added.

The source still has 4,744 primitive occurrences and 208 distinct subtrees:
23 primitive types and 185 internal subtrees. Thirteen decoder aliases give
172 decoder states, plus 49 other states, hence **185 - 13 + 49 = 221**.
Maximum source-address depth is 38 and maximum zero run six.

The logical calculus is unchanged from the complete pinned K222 packet:
the merged G equality row and witness-request K remain exactly as before.
The new contribution is the source layout, extra state sharing, literal table,
and independently checked simulation chain, not a new set-theoretic axiom.

## Verification layers

- Exact deterministic reconstruction from the unchanged, hashed K222 ZIP.
- Same 4,744 primitive instructions and all 6,167 guarded CFG cases, including
  entry and halt ordinals, checked by independent control-flow resolvers.
- Exact literal decoder binding at every compound source occurrence.
- Two separately implemented universal fold checkers: all 444 old transition
  rows, positive blocks of length one, three or five, complete tape equality
  at nonhalting endpoints, and no interior halt. The tag facts are inductive
  from an unconstrained initial state, not sampled assumptions.
- Exact canonical/native bijection and complete blank startup in 409,835 steps.
- Fresh unbounded runtime derivation for every one of the 6,167 source cases;
  arbitrary nine natural registers, extra gap and nonempty finite spare list.
- Independent receipt audits and 32,107 exact-source invariant closure checks.
- Deliberately corrupted source/allocation/fold controls are rejected.

The runtime case count is not a bound on register values or computation time.
The source equivalence transports the predecessor's logical calibration;
runtime certificates alone are not presented as a proof of consistency strength.

Two independently constructed decoder allocations are retained. The original
independent receipt and the deterministic builder's freshly checked receipt use
different internal tree-node identifiers; their exact input files and replay
commands are identified in `verification/decoder_receipt_provenance.md`.

## Release replay

The extracted packet passed its quick replay and a fresh full final-runtime
replay. A transport interruption during the first clean runtime was handled
by freshly restarting all 6,167 cases, not by accepting its partial output.
Completed construction/proof phases were preserved after exact manifest
verification; the resumed runtime and independent audits then passed. Every
portable byte in the released packet equals the tested extraction. Details
are in `verification/release_verification.json`.
