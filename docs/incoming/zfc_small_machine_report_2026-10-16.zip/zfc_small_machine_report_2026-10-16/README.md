# Toward a Smaller ZFC Consistency Machine

Research contribution for ProveIt, 16 October 2026.

**No new machine below the public 253-working-state baseline is established.**
The positive machine result is a **29-state blank initializer**, reducing the
editable assembler control from **341 to 315 working states** while preserving
all **572 transitions of its 286-state runtime** as named actions. Its exact
finite handoff was independently replayed in C++ and Python. A general runtime
simulation for the larger gap remains a separate proof obligation.

The report also gives a new total four-slot matrix decoder for the existing
complete EPSC2 reference checker, an exact finite-certificate transport proof,
and a bijective quantified-NAND codec at positive scope. Neither new frontend
has a measured binary state count. The archive records additional unsuccessful
grammar and literal-transition searches with their exact limitations.

## Read the report

- `zfc_small_machine_report.pdf` — complete report, proofs, source audit, results,
  proposal, reproducibility ledger, and pinned references.
- `zfc_small_machine_report.tex` and `sections/` — complete editable LaTeX source.
- `CLAIMS.json` — machine-readable distinction between new results, inherited
  inputs, finite evidence, and uncompleted endpoints.
- `source_snapshot.json` — external source pins and key source identities.
- `SHA256SUMS` — SHA-256 manifest of the delivered files, excluding itself.

All state counts exclude a separate terminal halt state and include blank
initialization when a whole-machine count is stated. A compiler control is not
being presented as a newly proved Con(ZFC) machine.

## Offline verification

Run from the extracted archive root, with Python 3 and assertions enabled:

```sh
python3 verify_artifacts.py
```

The driver copies the relevant artifact directories into a temporary directory,
runs the core checks there, and removes the temporary copy. It does not modify
the delivered evidence or source files. A C++17 compiler accelerates one complete
initializer replay when available; Python is the fallback. The independently
written Python replay is always run as well. No network, repository checkout,
SciPy, Lean, or Coq installation is needed for these core checks.

The core checks include:

1. Regeneration of both initializer tables and a complete literal replay.
2. Independent Python replay of all 47,189,196 transitions, including the full
   intermediate 4,098-one tape and final 11-one tape.
3. The default-index decoder, matrix semantics, wrapper projections, logical
   certificates, and public numeric-candidate tests.
4. Independent adversarial scope, variable-collision, and resource-failure checks.
5. Dense quantified-NAND roundtrips and independent finite-model semantics.

The 124 accepted logical-identity certificates use ordinary contradictory
logical premises to test the engine. They are **not EPSC2 refutations**. No public
EPSC2 refutation was found. The first 10,000 numeric candidates alone do not
reach formerly ill-scoped matrices; 124 targeted higher-code tests supply that
coverage, including 28 such matrices.

To check the bytes of the delivered archive separately:

```sh
sha256sum -c SHA256SUMS
```

The stored `verification/core_checks.json` records the packaged core verification
performed for this report. The primary per-experiment results are retained in
their artifact directories.

## Rebuild the PDF

Use a normal TeX Live installation with pdfLaTeX and latexmk:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error zfc_small_machine_report.tex
```

No external images, online bibliography service, shell-escape, or nonstandard
font files are required. The source includes the complete bibliography. A
rebuild can change the PDF bytes through timestamps while preserving content.

## Artifact directories

| Directory | Contents and claim boundary |
|---|---|
| `initializer_experiments/` | 29-state initializer; combined 315-state table; frozen runtime; table generator; independent C++/Python interpreters; exact endpoints; source extractor. Finite handoff only, no completed unbounded runtime theorem. |
| `theory_scope/` | Byte-preserved incoming EPSC2 checker, default-last variant, finite audit, proof section and result JSON. Ordinary checker-transport proof; no binary state count. |
| `scope_audit/` | Independently written adversarial checks and review notes. Complete instantiation and strict public theory interface retained. |
| `dense_qnand/` | New positive-scope bijection, encoders/decoders, semantics, tests and proof note. Representation artifact, not a refutation machine. |
| `machine_experiments/` | Bounded negative searches; newly rebracketed 268 and MILP 270 controls; grammars, literal tables, DAGs, register certificates and independent verification records. No lower bound or new record. |

## Reproduction with source checkouts

The larger compiler experiments use existing project helpers. Obtain the exact
read-only source snapshots listed in `source_snapshot.json`:

- ProveIt: `4747142d5d15213eb711bdadfa3cc7e769fcb7a7`.
- Jeff's upstream main: `297ab8df7e5de329605c3875b4934643b371a5e3`.
- Public 253 PR head: `0d544f2a2e3c18f12278441a74b7879f31cbe856`.

The 253 table retained inside the pinned ProveIt report host has the same SHA-256
as that PR table. Ordinary archive downloads can be used; Git metadata is not
required by the runtime extractor. The larger grammar tools need the source
paths described in `machine_experiments/README.md`.

To reproduce the frozen runtime from the pinned source and data:

```sh
python3 initializer_experiments/extract_runtime.py \
  --repo /path/to/ProveIt \
  --upstream /path/to/busy-beaver \
  --output /tmp/runtime_rebuild.json
```

This verifies the exact source/data digests before executing the assembler and
compares all 572 named rows and frame metadata. It refuses output inside either
supplied source tree. The included frozen runtime makes this extra step
unnecessary for offline verification of the new initializer itself.

To run the finite saved-grammar validation as well as the runtime rebuild:

```sh
python3 verify_artifacts.py \
  --repo /path/to/ProveIt \
  --upstream /path/to/busy-beaver
```

The full randomized sweeps and radius-six rewrite search are intentionally not
rerun by the default verification command. Their exact commands are in
`machine_experiments/README.md`. SciPy is required only for the time-limited
MILP; a different host may return a different incumbent. The saved grammar and
its finite certificate remain checkable independently of the optimizer.

## Interpretation of the main results

- The requested final theorem is **ZFC ⊢ Nonhalt(M) ↔ Con(ZFC)** for an explicit
  literal blank-start machine. The report also requires correct external finite
  witness maps for the intended standard nonhalting interpretation.
- The public 253 Coq sources state external finite-refutation equivalences.
  Their internal arithmetic presentation is a distinct integration task.
- The 29-state initializer prints `1 0^12287 1 (01)^9`, surrounded by zeros,
  with head immediately right of the left marker and runtime entry state 5.
  The complete 315 table starts in state 0 and has terminal state 315.
- The 315 table is smaller than the previous **341 control**, not the public
  **253 benchmark**. A fully verified runtime from the larger gap is still needed
  to transport arbitrary execution.
- The new decoder uses exactly four matrix slots, then increases scope under
  the matrix's own binders. It does not restrict first-order logic to four
  variables, force values to be distinct, or prove EPSC1.
- No new Lean or Coq theorem was checked in this investigation. New proofs are
  ordinary mathematical arguments, accompanied by explicitly bounded executable
  checks.

## Attribution and terms

The source audit credits Mira-Cult for the original machine/program, Jeff for
the upstream verification, mira-emmy for the public 253 reduction, Andrew James
Wade for the compiler, and the ProveIt contributors and incoming reports for
the current theories and reference checkers. The preprocessor is the published
Marxen–Buntrock five-state machine; the adapter and experiments described as new
are contributions of this report.

`LICENSE.ProveIt` preserves ProveIt's MIT No Attribution text for copied project
material. The new code and text follow the terms in
`initializer_experiments/LICENSE.new-code`. Those terms do not relicense the
pre-existing upstream program or retained transition data. Component READMEs
identify provenance and the boundary of the new work.

No remote repository changes were made. This archive is prepared for review
and incorporation into ProveIt.
