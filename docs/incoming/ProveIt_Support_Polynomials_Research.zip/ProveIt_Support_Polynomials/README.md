# Beyond Real Roots

## Ultra-Log-Concavity, Palindromic Cores, and Efficient Counting for Preorder Support Polynomials

Prepared for Vladimir Reshetnikov, 29 September 2026. AI-assisted research manuscript.

The main article is `support_polynomials.pdf`; its complete, standalone LaTeX source is `support_polynomials.tex`. The bibliography is embedded in the source. The PDF has 23 pages, including the title, contents, references, and certificate appendix.

## Research results and attribution

For a bipartite graph H, let p_H(t) count perfectly matchable **vertex sets**, with exponent half the size of the set. A vertex set is counted once, even if it supports several perfect matchings. Let d be the smaller shore size after isolated vertices have been removed.

1. **Universal coefficient inequalities and the preorder application.** The coefficients divided by binomial(d,k) form a log-concave sequence. The assertion holds with arbitrary positive vertex-product weights. Connecting the established bimatroid theorem with two published root-polytope identities proves ultra-log-concavity for every bipartite Hall-demand support enumerator and every finite preorder support polynomial. In particular it answers the unimodality component of Dai–Hou–Liu–Thawinrak–Wang's Problem 5.3 (arXiv:2608.16037v2). The general bimatroid inequality is due to Röhrle–Ulirsch; it is **not** a new theorem of this package.

2. **Complete palindromicity classification.** The unweighted polynomial is palindromic in its actual degree exactly when the nonisolated graph is a doubled preorder, after identifying its shores along a perfect matching. This extends and reproves the repository's balanced perfect-matching criterion. The top coefficient factors as the number of row bases times the number of column bases and has an explicit lower bound. Recognition uses matching and transitive closure, not coefficient enumeration.

3. **Probability, equality, and algorithms.** Every positive fugacity gives convex-order domination by the binomial distribution with the same mean and shore parameter d. Equality in the sharp variance bound is classified: equal-strength, disjoint stars centered on the smaller shore. For preorders it occurs exactly for antichains. The article gives an explicit matroid oracle and down-up chain, transfers the established matroid mixing/FPRAS theorems, and proves exact-counting hardness by a leaf-extension interpolation, even for height-two preorder lattice counts. Nine further research questions delimit the remaining work.

The contribution is the explicit bridge, classifications, equality analysis, and reductions relative to the inspected repository. Global priority of these applications is not established. The general Lorentzian, bimatroid, convex-order, and matroid-sampling mechanisms are credited rather than claimed as discoveries.

## Scope and trust boundary

These are conventional mathematical proofs, not Lean or Rocq formalizations, and the manuscript is unrefereed. Its source/proof ledger separates published inputs from elementary proofs and new applications. Finite tests are regression evidence, not all-graph proofs.

The package does not classify real-rooted support polynomials, settle flag-polytopal realization, or give a direct demand-vector/matchable-support bijection. The sampler outputs a matchable support; its receiver-support marginal has the correct demand-support distribution, but it does **not** output the positive coordinate values of a demand vector. The full FPRAS is proved and described; its production wrapper is not implemented.

## Repository provenance

Inspected repository: https://github.com/VladimirReshetnikov/ProveIt

Pinned commit: `de2f8fa8c6f0107b1a0f1f77e2e25c343e562180`

Relevant directory:

`SetTheory/Cardinals/docs/reports/enumerative-combinatorics/preorder-root-polytopes/`

Inspected article blob: `d52a2633b58e74aa653e967eb56adc1aa41bc8ae`

Inspected README blob: `846d9f19fadac9cd933b74370cdb8fafa2211c5d`

No repository files were changed. The predecessor's balanced criterion, gamma-positivity proof, and previously credited nonreal-root example are not presented as new discoveries.

## Rebuild the article

Use a TeX Live installation with pdfLaTeX and these packages: `amsmath`, `amsthm`, `amssymb`, `mathtools`, `newpxtext`, `newpxmath`, `geometry`, `microtype`, `booktabs`, `tabularx`, `array`, `enumitem`, `xcolor`, `fancyhdr`, `tcolorbox`, `xurl`, `hyperref`, and `cleveref`.

```sh
sh build.sh
```

Or run pdfLaTeX three times on `support_polynomials.tex`. No BibTeX run, network access, or shell escape is needed. The build script puts intermediate files under `build/` and copies the final PDF to the package root.

## Reproduce the exact checks

Python 3.10 or later is sufficient. All supplied Python programs use **only the standard library**. Run from the package root:

```sh
python code/verify.py --output rerun/verification.json
python code/example_certificate.py --output rerun/example_certificate.json
python code/support_tools.py
```

Use a distinct output path to preserve the recorded results. The verifier's wall-clock field will vary by machine.

The full recorded run covers all 65,536 labelled 4-by-4 graphs, all 4,096 labelled 3-by-4 graphs, all 390 labelled preorders on at most four elements, 300 seeded positive-rational weighted examples at three fugacities, 32 full leaf-transform identities, and 30 sampler feasibility checks. Every check passed. The smaller graph family includes a direct receiver-refined Hall-demand enumeration. The weighted checks use exact fractions, including finite stop-loss tests for convex order.

The separate example certificate computes the quartic discriminant **−5243** using fraction-free integer elimination and confirms exactly two real roots using Sturm's rule. It reconstructs the eight-element height-two polynomial and its exact binomial-normalized inequalities. No floating-point roots are used.

## File guide

- `support_polynomials.tex`, `support_polynomials.pdf`: article and source.
- `PROOF_STATUS.md`: theorem dependencies, novelty boundaries, and limitations.
- `SOURCES.md`: primary-source URLs, theorem locations, and repository identities.
- `code/support_tools.py`: exact graph operations, support enumeration, structural recognition, matroid independence oracle, and rational weighted down-up sampler.
- `code/verify.py`: exhaustive and seeded verification driver.
- `code/example_certificate.py`: standard-library resultant, Sturm, and example certificates.
- `data/verification.json`, `data/verification.log`: recorded full verification.
- `data/example_certificate.json`, `data/example_certificate.log`: exact example certificate and its output.
- `build.sh`: local LaTeX build.

The reference sampler uses a seeded pseudorandom generator for reproducibility and exact rational transition probabilities. Its feasibility tests do not constitute an empirical or formal proof of the imported mixing theorem. Graph enumeration is deliberately exponential and intended for small-instance checks, not as the counting algorithm promised by the FPRAS theorem.
