# Beyond 246 states: research package

**No validated ZFC consistency machine with fewer than 246 working states was found.**
This archive supplies the source and PDF of a detailed research report, a verified
new local arithmetic compression, program invariants, complete symbolic replay,
reproducible searches, and explicit failure evidence for apparent 245-state
reductions. The supported complete machine in `machine/` is the supplied
246-state baseline. Tables below `search/` are labelled experiments and rejected
diagnostics; their filenames do not assert the desired consistency equivalence.

## Main findings

1. The actual blank root `(3,0,0,0,3,0,0,0,0)` yields an inductive interval
   certificate with 6,456 admitted source sites and 8,384 outgoing edges. Two
   decrement sites are always zero; four following instruction occurrences are
   unreachable. A separate verifier checks exact interval images and rejects
   vacuous and missing-successor mutations.
2. Direct symbolic binary replay passes all 8,385 admitted guarded instruction
   cases, with 2,005,266 composed rules, all 492 baseline state/read pairs, and
   a minimum of 13 literal machine steps per case. Primary registers, gap, and
   nonempty finite spare suffix are unbounded. The primary register-operation
   oracle is expanded; proved unary/list induction rules remain trusted
   mathematical rules. Width symbols denote the actual widths of assigned lists.
3. A nine-state arithmetic core has universal local proofs. It saves one local
   state and appends zero-valued spares, but its proposed integration consumes
   the program-counter return. The resulting blank machine enters a closed
   left-moving component after three steps. It is not a consistency construction.
4. Reassociating `178=(23,(24,206))` to `((23,24),206)` reuses existing state 16
   and deletes 208. Its register-program bisimulation passes, but folded binary
   entries fail. One retiming preserves the entire 410,735-step blank startup
   yet fails another runtime context. These results isolate a genuine compiler
   compatibility problem rather than validate a 245-state machine.
5. Shortening the nine-zero marker detector misidentifies a temporary internal
   eight-zero run. The exact trace disproves first-return marker recognition.
   It does not prove that no later recovery is possible, nor that the witness
   is reachable from blank.

The report explains how a successful exact-table simulation and an admitted
initializer would inherit the requested ordinary ZFC-provable equivalence.
It also distinguishes the inherited upstream Rocq verification from the
mathematical and executable proof status of the 246-state adaptations. No
new local Lean/Rocq kernel build or serialized PA proof is claimed.

## Layout

| Path | Contents |
|---|---|
| `report.tex`, `sections/`, `report.pdf` | Complete manuscript sources and PDF |
| `machine/` | Supported 246-state baseline, canonical and original labels |
| `code/`, `results/` | New interval and direct symbolic replay code and results |
| `audit/` | Source/proof audits, independent interval verification, CI evidence |
| `search/reductions/` | Permutation census, fold/core search sources and decisions |
| `search/scanner/` | First-return obstruction, exact tapes/traces, recipe ledgers |
| `search/decoder/` | Decoder reconstruction, program bisimulation, diagnostics |
| `search/grammar/` | Context constraints and grammar optimization experiments |
| `search/reductions/ROTATION_CONTROL.md` | Coordinated repair searches and a near-candidate witness |
| `reference/context246/` | Pristine supplied 246-state research package |
| `reference/jeff/` | Pinned upstream m254 and selected calibration sources |
| `PROVENANCE.json`, `NOTICE.txt`, `SHA256SUMS` | Attribution and archive identity |

## Verification

Python 3, with assertions enabled, suffices for the mathematical replay checks.
Search binaries are compiled from the included C++17 sources when needed. No
third-party Python modules or network access are needed for the packaged checks.

From the extracted archive root:

```sh
python3 code/reproduce.py
python3 code/reproduce.py --skip-integrity --full
```

The first command verifies the delivered manifest and the pristine upstream
manifest, runs the inherited verification suite in a disposable copy, regenerates
the interval certificate, independently checks it, and rechecks the new local
core, scanner witness, register-program bisimulation, saved abstract grammars,
and repaired diagnostic's blank prefix and bounded rejection. The second command
also reruns the direct symbolic proof (about four minutes in the observed
environment). A working copy's timing/result files change when regenerated;
`--skip-integrity` is for that already modified copy. On a fresh extraction,
`python3 code/reproduce.py --full` checks both integrity and all these results.

The stored complete direct replay can be reproduced alone with:

```sh
python3 code/full_symbolic.py
```

Limited runs such as `--limit 10` write a separate `PASS_LIMITED` result. A changed
source can be checked using `--sites PATH --all-values --table PATH`; this proves
only the supplied binary contracts. Program equivalence and startup are separate
obligations and must not be inferred from that option.

Each search subdirectory documents its exact candidate family, seeds, fuel,
fixtures, and reproduction commands. Repeating large synthesis families is
optional. Fuel cutoffs and bounded-screen rejection are not impossibility proofs.

The additional `code/grammar_search.py` and `code/commuting_repair.py` record
optimistic RePair heuristics. The former tested 1,000 seeds per physical/semantic
lane, reaching 130/127 rules. The latter tested 5,000 seeds on commuting normal
forms, reaching 147 rules. Their results are in `results/`; they establish no
binary-machine claim and are separate from the stronger saved annealing runs.

## Build the PDF

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

Ordinary TeX Live packages are used. The top-level manifest intentionally excludes
itself and transient build products. The complete original transition tables
are in machine-readable `.tm` files; the inherited report also supplies its
typeset full baseline transition table.

## Sources

ProveIt was inspected at `8cdc55ff9281b0aaba49bf74b0b225d57f12b893` and Jeff's
`zf-254` branch at `c132d7eae8158cd3a9850ea3eb7251158c3dd821`. Exact source and
machine hashes, inherited theorem names, and limitations are in the manuscript,
audit notes, and provenance files. Newly generated source and prose are intended
for incorporation in ProveIt; upstream attribution is preserved separately.
