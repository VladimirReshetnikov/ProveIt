INDEPENDENTLY WEIGHTED PREORDER SUPPORT POLYNOMIALS
Actual surviving degree at most three
October 1, 2026

THE RESULT
For every finite preorder, assign independent nonnegative tail and head activities
to each vertex. Count every feasible ordered pair of disjoint tail/head supports
once, regardless of how many matching witnesses it has. If the weighted support
polynomial has actual surviving degree d <= 3, its coefficients divided by
binomial(d,k) form a log-concave sequence.

There is no bound on the number of vertices. The theorem includes zero activities
by a preorder-preserving role filter. It does not assert general real-rootedness;
the paper gives the exact cubic 1 + 24z + 162z^2 + 208z^3 with nonreal zeros.

READING THE PACKAGE
- independent-role-degree-three.pdf: the 21-page complete mathematical article
- independent-role-degree-three.tex: editable LaTeX source
- proofs/: readable ordinary proof notes, the complete 1,686-target role ledger,
  the companion role-cover article and the final 32-square rational certificate
- checker/: frozen portable audit packages with all required exact inputs
- audit/: independent mathematical approvals and provenance
- qa/visual-qa.json: all-page visual inspection record
- SHA256SUMS and dependency-pins.json: byte-integrity records

EXACT REPLAY
Run, with assertions enabled:

    python /path/to/package/verify.py

Requirements: Python 3 and a C++17 compiler. No third-party Python libraries,
network access, numerical solvers or precompiled binaries are needed. The C++
compiler is used only by the included role-cover companion. A replay usually
takes a few minutes, depending on the machine. A new local-replay.json records
its results; approved receipts are preserved.

The replay checks the complete finite role domain, rational square certificates
and their declared positive multipliers, all structural and refinement maps,
the two-attachment compression and moment modules, marked-five deletion/gluing,
six-vertex and total-preorder layers, HPP side-matroid maps, published-list
isomorphisms, every proper minor of the final side matroid, and its exact all-real
32-square identity. There is no vertex-only proof dependency.

The complementary last-case checker can also be run alone:

    python proofs/final-rayleigh/verify_side1565_rayleigh.py

It independently recounts 198 bases, reconstructs the 397-monomial Rayleigh
difference, verifies the uniform 37-by-37 Gram matrix and all 32 positive rational
squares, and confirms rank 32 by rational Schur elimination.

PUBLISHED MATROID DEPENDENCY
The proof uses Kummer--Sert's published small-matroid classification and the
certified-positive file n9r4Hpp.txt from Zenodo record 6108027. The official file
is included inside the audit dependency with its published checksum and exact
isomorphism witnesses. The local checker verifies membership in that certified
list. It does not rerun the original authors' Gram certificates for those list
entries. The new ten-element side-matroid Gram certificate is fully replayed
locally. These two kinds of evidence are distinguished in the article.

BUILDING THE PAPER
With a standard LaTeX installation:

    bash build.sh

The mathematical verifier does not require LaTeX. The distributed PDF was built
without warnings and every final page was visually inspected.

PROOF STATUS AND SCOPE
This is an independently audited, computer-assisted proof with ordinary
mathematical reductions and exact finite certificates. It is not a formal
proof-assistant development or a claim of literature-wide novelty. Provenance
notes may retain their historical draft-status wording; the pinned approvals,
complete ledger and final article specify the approved scope. No numerical
search program or speculative candidate is needed to reproduce the result.

This separate independent-role release extends the previously released vertex-
activity theorem. Its proof does not rely on vertex-only certificates.
