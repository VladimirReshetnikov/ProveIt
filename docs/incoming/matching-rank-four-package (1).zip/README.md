# Weighted matching support rank normalization through rank four

For a bipartite graph G, count each pair of equal-size shore subsets admitting a perfect matching ONCE. Give that support the product of its selected vertex activities. Write the resulting polynomial as p_G(t) = sum a_k t^k, and let d be its actual degree after zero activities are accounted for.

## Result

If the matching number of G is at most four, then for arbitrary nonnegative activities on both shores,

    (a_k / binom(d,k)) for k = 0,...,d

is log-concave, with no internal zeros. The normalization uses the surviving degree, not automatically the original graph's matching number.

Equivalently, for 1 <= k < d,

    k*(d-k)*a_k^2 >= (k+1)*(d-k+1)*a_(k-1)*a_(k+1).

At d = 4 the inequalities are 3*a_1^2 >= 8*a_2, 4*a_2^2 >= 9*a_1*a_3, and 3*a_3^2 >= 8*a_2*a_4.

A stronger intermediate theorem holds for graphs admitting a vertex cover with two vertices on each shore: their support polynomials are real-rooted under these activities. This is NOT a real-rootedness theorem for every graph of matching number four. A unit-weight rank-three example already fails real-rootedness: three left centers and four vertices of each pair-neighborhood type have polynomial 1 + 24t + 162t^2 + 208t^3, with discriminant -2592. The known rank-four theta example has polynomial 1 + 9t + 24t^2 + 16t^3 + t^4 and discriminant -5243.

The article gives every core-case proof in full. Pendant compression and the established weighted ambient Lorentzian theorem cover the thin minimum covers. Six two-by-two core orbits are handled by exact weighted-path models, Hermitian cycle phases, and a positive-semidefinite block determinant for the complete core. Zero-activity vertices are deleted before applying the cover reduction.

## Files

- `matching-rank-four.pdf`: 12-page mathematical article with complete proofs and limitations
- `matching-rank-four.tex`: editable standalone LaTeX source
- `check_weighted_rank_four.py`: deterministic exact checker
- `support_kernels.py`: Boolean matching and neighborhood-type support routines used by the checker
- `verification.json`: successful checker receipt
- `requirements.txt`: tested SymPy version
- `SOURCE.txt`: exact repository pin and question/input locations
- `build.sh`: two-pass pdfLaTeX build
- `SHA256SUMS`: package checksums

## Reproduce the verification

Use Python 3.10 or newer and SymPy (tested with 1.14.0), with assertions enabled. Do not use `python -O`.

    python3 check_weighted_rank_four.py > verification-new.json
    diff -u verification.json verification-new.json

The deterministic run took about one second in the preparation environment; runtime depends on the machine. The receipt records the SymPy version, so a different version may change that metadata even when every assertion passes.

The checker performs:

1. Exact rational support enumeration on 128 graphs, eight for each of the sixteen two-by-two core masks, using fixed seed 431 and nonuniform positive rational activities. Each common-neighborhood population has one, two, or three vertices
2. Comparison of three coefficient calculations: labeled-support enumeration, a Boolean cover-type kernel, and a separate shore-imbalance formula
3. Independent matching-cover rank verification and all three rank-four Newton inequalities on those examples
4. Exact symbolic checks of the weighted variance margin, adjacent-core margin, complex PSD block determinant coefficient identity, theta quartic discriminant, and the symbolic pair-neighborhood cubic discriminant formula
5. Direct Boolean support enumeration for the pair-neighborhood family at populations n = 1 through 6

The activities weight supports, not individual matchings. The feasibility routine answers a Boolean question, and a feasible support enters each enumeration only once.

The 128 mixed-cover examples have positive activities and matching rank four; the six pair-neighborhood examples have unit activities and matching rank three. The zero-activity and lower-rank conclusions are proved in the article by deletion and the minimum-cover argument; they are not claimed as exhaustive finite tests here. The phase-existence arguments are analytic proofs, not numerical searches for phases or roots. No floating-point arithmetic is used by the delivered checker. The earlier exploratory large random screen is unnecessary for the proof and is not included in this package.

These computations corroborate identities and finite instances. They do not establish the universal theorem by enumeration and do not constitute Lean or other proof-assistant verification.

## Build the PDF

Install a working pdfLaTeX distribution with amsmath, amssymb, amsthm, lmodern, geometry, booktabs, microtype, and hyperref, then run:

    sh build.sh

The delivered PDF was compiled without unresolved references or layout warnings, and every page was visually inspected.

## Attribution and remaining questions

The motivating ProveIt source is pinned in SOURCE.txt. This article resolves its weighted rank-three and unit-weight rank-four questions, and the rank-three/rank-four portions of its two-shore weighted rank question.

The weighted ambient input is credited to the source's transversal-matroid specialization of Brändén–Huh's Lorentzian theory; the relation-bimatroid ambient result is credited to Röhrle–Ulirsch. The spectral theorem, Newton inequalities, Cauchy–Binet, Schur complements, and König's matching-cover theorem are classical. The exact finite-rank support constructions are proved in the article without a claim of worldwide priority.

The weighted rank-five question remains unresolved here. The inspected source already has a weighted rank-six counterexample, so the least possible weighted counterexample rank is now either five or six. The unit-weight all-rank question remains separate and open in this article. No general real-rootedness or arbitrary-bimatroid actual-rank theorem is claimed.

Prepared 1 October 2026 for Vladimir Reshetnikov.
