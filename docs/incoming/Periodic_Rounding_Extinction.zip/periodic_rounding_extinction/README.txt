MICROSCOPIC SCHEDULES IN ROUNDING EXTINCTION
Averaged ceiling laws, exact Gamma constants, discontinuous perturbations,
and a sharp spectrum of limits

Research article prepared for Vladimir Reshetnikov with OpenAI
5 October 2026

CONTENTS

periodic_rounding_extinction.pdf
    The 29-page research article, including four figures, proofs, references,
    numerical examples, and proposed further research questions.

periodic_rounding_extinction.tex
    The complete LaTeX source. The bibliography is included in this file;
    no separate BibTeX or Biber database is required.

code/verify.py
    Reproducible Python checks, exact integer thresholds, exact rational
    constant enclosures, numerical diagnostics, and figure generation.

figures/
    Four vector PDF figures used by the article, with matching PNG previews:

    normalized_thresholds.pdf
        Normalized thresholds for periodic positive phases and for a family
        of uniformly small perturbations of the weights.

    drift_and_profiles.pdf
        Averaged ceiling drifts and backward trajectories compared with
        their limiting profiles.

    constant_discontinuity.pdf
        The jump in the limiting constant at an exact plateau.

    weak_phase_density.pdf
        Dependence of the constant on the density of active weak phases.

data/
    thresholds.csv
        310 threshold records from ten weight models, with exact integer
        thresholds and rounded weight/normalization diagnostics.

    certificates.json
        22 finite-breakpoint certificate records with exact rational
        numerators and denominators for t(z) and the enclosure endpoints.

    certificate_bounds.csv
        Rounded displays and widths of those rational enclosures.

    gamma_products.json
        Exact rational Gamma-function arguments and numerical evaluations
        of the resulting constant formulas.

    verification.json
        Machine-readable summary of the completed finite checks.

    run_log.txt
        Console output of the completed default run.

    profile_samples.csv
        Exact backward integer states and rounded normalized profiles.

    limiting_profiles.csv
        Floating-point samples of the limiting profiles used in a figure.

VERIFICATION_NOTES.txt
    The scope of the checks, arithmetic conventions, and limitations.

SOURCE_AUDIT.txt
    The pinned repository revision, checked source identities, primary
    references, and the distinction between prior and present results.

SHA256SUMS.txt
    SHA-256 checksums of every other file in the delivered archive.

REBUILDING THE ARTICLE

Run the following commands from the directory containing this README.
Keep the figures/ directory beside the LaTeX source.

With a current TeX distribution and latexmk:

    latexmk -pdf -interaction=nonstopmode -halt-on-error periodic_rounding_extinction.tex

Alternatively, run pdflatex three times to resolve the contents page and
cross-references:

    pdflatex -interaction=nonstopmode -halt-on-error periodic_rounding_extinction.tex
    pdflatex -interaction=nonstopmode -halt-on-error periodic_rounding_extinction.tex
    pdflatex -interaction=nonstopmode -halt-on-error periodic_rounding_extinction.tex

The source uses common packages supplied by current full TeX distributions,
including the AMS packages, mathtools, lmodern, geometry, microtype,
graphicx, booktabs, longtable, xcolor, enumitem, fancyhdr, placeins,
hyperref, and cleveref. Figure generation is not required to rebuild the
article because the finished vector figures are included.

REPRODUCING THE COMPUTATION

Python 3.10 or later is required by the source syntax. The delivered run
used Python 3.12. Exact checks and numerical data generation use Python's
standard library. Creating the figures additionally requires NumPy and
Matplotlib.

To repeat the default run, including the four figures:

    python3 code/verify.py

To repeat all checks and data generation without creating figures:

    python3 code/verify.py --no-figures

The default run uses K values up to 100000 and rational-certificate
endpoints z=100 and z=1000. Available options are described by:

    python3 code/verify.py --help

Both commands regenerate the data files. The command without --no-figures
also regenerates the figure PDFs and PNGs. Neither command compiles the
article. Redirecting the standard output is optional; for example:

    python3 code/verify.py > data/run_log.txt

WHAT WAS CHECKED

The completed run passed 3,200 exact inverse-boundary checks and 2,847
exhaustive small-survival checks across ten weight models. It generated
310 exact threshold records and 22 exact rational certificate records.
The largest computed terminal stage was K=100000.

Integer thresholds and stored rational endpoints are exact. Decimal and
floating-point values are rounded diagnostics; they are not evaluations
with certified outward rounding. The enclosure property of the rational
endpoints relies on the mathematical theorem proved in the article.

The finite computations do not prove an asymptotic theorem or an error
rate, and the manuscript is not formally verified. In particular, the
article's finite Mobius-inversion theorem for every bounded increment law
is a mathematical proof in the manuscript; it is not one of the finite
computation tests. See VERIFICATION_NOTES.txt for further detail.
