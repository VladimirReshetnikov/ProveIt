# A Rational-Normal Dichotomy for Omnific Integer Hulls

**Finite Graver Certificates and Irrational Obstructions in Surreal Polyhedra**

Research draft prepared for Vladimir Reshetnikov, 30 September 2026.

## Read first

`article.pdf` is the complete 28-page manuscript. `article.tex` is its
standalone LaTeX source, with an internal bibliography and an embedded TikZ
figure. No external figure files or bibliography database are required.

The main results are an explicit finite candidate formula for bounded
rational-normal omnific integer hulls, a universal rational normal-fan
refinement, a finite tail/residue compiler, same-matrix ordinary realization
of every face lattice, and a sharp universal rational-normal characterization.
The two irrational examples distinguish missing real-objective suprema from
nonattainment exposed by an infinitesimal objective, even with omnific-integer
right-hand sides. The article also treats arbitrary integer parts, totally
unimodular matrices, and a full six-residue knapsack example.

## Status

This is an AI-assisted, unrefereed mathematical research draft. Proofs are
provided in the manuscript, but no independent correctness or priority
certification is claimed. It does not purport to settle a named long-standing
conjecture. Classical Presburger and Graver theory is explicitly credited.

No new Lean formalization is included or claimed. Repository scope was
inspected, not independently rebuilt. The executable checks are exact finite
ordinary-integer tests, not a general implementation of surreal arithmetic
and not a proof-assistant verification of the theorems.

## Package contents

- `article.tex`, `article.pdf`: source and compiled manuscript.
- `verify.py`: exact finite checks, Python standard library only.
- `verification_results.json`, `verification_output.txt`: actual recorded run.
- `SOURCES_AND_SCOPE.md`: repository pin, source roles, and novelty boundary.
- `PROOF_AUDIT.md`: mathematical dependency and delicate-step audit.
- `build_report.json`: compilation and rendering checks.
- `Makefile`: reproducible build and check commands.
- `SHA256SUMS.txt`: hashes of the distributed files, excluding itself.

## Rebuild

Use a reasonably complete TeX Live installation with pdfLaTeX, newtx,
amsmath/amsthm, mathtools, microtype, TikZ, hyperref, cleveref, xurl, and float.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Three passes settle the contents, cross-references, and bookmarks. `make pdf`
runs these commands. The document contains no external shell-escape step.

## Run the exact checks

Python 3.10 or later; no third-party Python packages are needed.

```sh
python verify.py --output verification_results.json
```

Do not use Python's `-O` flag: the comparisons are implemented as assertions.
Optional `--max-T` and `--radius` arguments change the finite ranges. The
included default run checks 246 hull instances, 234 residue-table cases,
25,920 conformal decompositions, and 77,469 local/global optimality cases.
It enumerates 426,236 lattice points across the hull instances and uses no
floating-point decisions. `make check` regenerates the JSON and console log.

## Navigation

Sections 6–8 contain the positive geometry and candidate compiler. Section 9
contains the rational-normal classification and both irrational counterexamples.
Section 10 gives the explicit example; Section 11 records checks. Section 12
explains formalization boundaries, Section 13 proposes twelve research
questions, and the appendices give ordered-field linear certificates and the
effective finite-atlas consequence.
