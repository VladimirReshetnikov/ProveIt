# A Global 0.49 Lower Bound for OEIS A290268

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October 2026.

## Main theorem

If a(N) is the derivative-term count in OEIS A290268, then

liminf a(N)/N² ≥ 28176/57247 = 0.492182996488898… > 0.49.

Thus a(N) ≥ 0.49 N² for every sufficiently large N. The eventual threshold is not numerical.

The proof establishes global horizontal saddle selection and density one in the wide tail cone 10q>3d. A disjoint explicit triangle, 40k+420q≤91d, has uniform eventual strict positivity. Their candidate areas are exactly 5/46 and 169/19912. Adding the previously proved bulk gives the displayed constant.

The proof is self-contained from the cited source coefficient model and classical hyperbolic partial fractions. The angular-selection lemma needed for the real-positive triangle is included in full. The noncompact step uses compact exhaustion and does not assert a uniform global O(N^(5/3)) error.

The full noncancellation conjecture and the leading asymptotic a(N)~N²/2 remain open. Density one is asserted only in the specified wide cone; the complementary positive triangle is handled separately.

## Files

- `article.pdf`: the 12-page report
- `article.tex`, `positive_triangle.tex`: complete LaTeX sources
- `build_local.sh`: local build wrapper
- `verify_constants.py`, `exact_constants.json`: exact standard-library checks of the Taylor bounds, angular polynomial, height certificate, lattice areas and final rational constant
- `regions.pdf`, `regions.png`: vector and raster versions of the coefficient-region figure
- `plot_regions.py`: figure source; requires Matplotlib

Run `python verify_constants.py` to replay every arithmetic certificate. These checks verify the elementary constants; the global contour and density arguments are proved in the manuscript. On a standard LaTeX installation, run `pdflatex article.tex` twice. The wrapper supplies the local format and font-map setup used in the research environment.

## Verification and scope

The complete proof and final manuscript received independent mathematical review. Every rendered page was visually checked, and the final build has no undefined references or overflows. The work is not Lean-formalized or externally refereed. No exhaustive priority claim is made; the exact inspected ProveIt commit and primary formula references are in the bibliography.
