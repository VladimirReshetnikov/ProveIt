# Sharp Weighted Energy Gaps and the Target Torsion Dichotomy

ProveIt Report 294, prepared for Vladimir Reshetnikov, 7 October 2026.

For EACH fixed F_3-vector space V of dimension at least two (finite or infinite), and EACH fixed nontrivial abelian target H, the maximum weighted energy infimum among full maps outside the affine and translated index-three affine-cut families is exactly:

- 5/9 when H has no nonzero element annihilated by 2
- lambda = (11 + 6 sqrt(6)) / (11 + 6 sqrt(6) + 7 sqrt(6 sqrt(6) - 8)) = 0.5865294215371424... otherwise

Both maxima are attained for every such fixed pair (V,H), with finite attaining weights. The distinction is about the prescribed target, not only about a constant uniform over targets.

For targets with injective doubling, every unfavorable map has an indicator witness on three or nine points. A failed-progression line gives 5/9. Otherwise a suitable outside-family plane has indicator ratio at most 41/81; if its derivatives lack square sum 45, the stronger bound is 361/729. Both weighted and indicator constants 5/9 are sharp for EVERY fixed positive source rank and every fixed nontrivial target with injective doubling. The manuscript includes the Q=45, Q=41 and Q=39 branches and the complete three-fiber complex Fourier lower bound.

For targets containing an order-two element delta, a codimension-two LINEAR pullback spike delta*1_{ker pi} has weighted infimum lambda in every rank at least two. A sharp complex fourth-power inequality for R_9=I-2J/9 proves the all-weight lower bound through nine-frequency Fourier blocks. Any product of the optimal nine-point quotient weight with a nonzero nonnegative finitely supported kernel weight attains equality. The sharp fourth-power lower ratio of the reflection is mu=2lambda-1; its operator norm is mu^(-1/4), not mu.

The arbitrary-target universal upper bound is explicitly imported from Report293. The new target-refined upper bound, qualitative gluing, both Fourier lifts, and reflection inequality are proved in this report. The six-triple group-relation lemma is a complete finite certificate: all 729 midpoint choices have explicit integer combinations giving 6v=0. The public verifier checks those identities without a computer algebra system or a bounded-target extrapolation.

The report does not classify all higher-rank equality maps or weights. It does not assert the analogous fixed-rank indicator dichotomy when two torsion is present. It does not resolve a general matrix-norm conjecture or improve a global Ramsey or Szemeredi bound. Classical moment and complexification inputs are attributed, and no novelty or publication-priority claim is made.

## Contents

- Report294.tex: editable mathematical article
- Report294.pdf: verified PDF in the distribution
- companion/exact_checks.py: bounded exact standard-library diagnostics
- companion/midpoint_certificate.json: all 729 direct integer-combination witnesses
- companion/README.md: exact mathematical scope and validation interfaces
- tests/test_companion.py: mathematical and adversarial regressions
- tests/test_build.py: guarded builder and exact-inventory regressions
- build.py: offline verification, deterministic replay and packaging
- REPRODUCING.md: toolchain, commands and archive contract
- SOURCES.md: provenance, bibliography and inspection boundaries
- MANIFEST.sha256: hashes of all twelve public nonmanifest files

There are eleven authored source files, including companion/__init__.py. The final ZIP has exactly thirteen regular-file members under Report294/. Render images, logs, receipts and exploratory notes are excluded.

## Quick replay

    python3 -I -B build.py verify
    python3 -I -B build.py reproduce --output /tmp/report294-replay

The output must be fresh or empty, absolute and outside the source tree. The builder preserves the input, rejects aliases and unexpected entries, runs checks normally and with -O, and compares their deterministic outputs. In distribution mode, the rebuilt PDF must match the bundled PDF byte for byte. Matching the documented toolchain is required for byte identity. No installation, download, network access or upstream-code execution occurs.

The final separately supplied ZIP SHA-256 pin identifies the actual archive bytes when received through a trusted channel. The internal manifest is not a digital signature. Reports 1-293 remain unchanged.
