"""Report294 exact public companion; standard library only."""
import sys
sys.dont_write_bytecode = True
