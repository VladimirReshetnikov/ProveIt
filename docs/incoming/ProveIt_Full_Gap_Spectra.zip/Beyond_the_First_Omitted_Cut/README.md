# Beyond the First Omitted Cut

**Full gap spectra of old surreal fields, Cohen collapse, and surcomplex real forms**

Prepared for Vladimir Reshetnikov, 28 September 2026.

## Contents

- `article.pdf`: 25-page typeset article (title page, one contents page, 23 numbered pages).
- `article.tex`: standalone LaTeX source with internal bibliography.
- `build.sh`: runs the finite tests and compiles the article with latexmk.
- `PROOF_STATUS.md`: assumptions, imported theorems, proof boundaries, and review priorities.
- `SOURCE_AUDIT.md`: repository snapshot and primary literature provenance.
- `checks/finite_checks.py`: standard-library Python regression checks.
- `checks/results.json`: recorded results of the supplied run.
- `validation.json`: document-build and layout validation summary.
- `SHA256SUMS`: checksums of the delivered substantive files.

## Principal results

Throughout, `g(M,N)` records the infinite cardinal `mu` for each set-presented
Dedekind gap of the old surreal field `No^M` having external character `(mu,mu)`.
All characters are computed in the outer universe `N`.

**Theorem 4.3 — Cofinality pushforward.** The complete gap spectrum is the
image of the actual ground-regular fresh-function spectrum under
`lambda -> cf^N(lambda)`. This explicitly handles cofinality changes and
cardinal collapse; a ground fresh-function index is not automatically an
external gap character.

**Theorems 5.1 and 6.3 — External density and generalized Cohen forcing.**
If a ground dense set has size `tau` in the extension, every external gap
character is at most `tau`. For `Fn_{<kappa}(kappa,A)` with ground regular
infinite `kappa` and any ground alphabet `A` containing at least two letters,
the entire gap spectrum is exactly `{kappa}`. No cardinal-arithmetic
hypothesis is imposed. The proof uses occurrence of every old short word in
the generic word, which makes the ground poset have size `kappa` in the
extension. The first new surreal birthday is also `kappa`.

**Theorem 8.5 — Relative finite-complement spectra.** Under GCH and the
explicit sparseness condition (8.1), remove a finite nonempty set `B` of
coordinates from an Easton product to obtain an intermediate ground `M_B`.
Its spectrum in the full extension is exactly `B`. A separate distributivity
argument is supplied because old Cohen posets cannot simply be recomputed
in the intermediate model.

**Theorems 10.1 and 11.2 — Many fields and real forms with the same saturation.**
For any prescribed infinite set cardinality, one forcing extension contains
that many old surreal fields with spectra `{mu,kappa_xi}`, with `mu` fixed
uncountable regular and the larger regulars distinct. All have the same
saturation spectrum and the same ordinary reals, but are pairwise
nonisomorphic. With Global Choice they give pairwise nonconjugate
involutions of one surcomplex field, agreeing with ordinary conjugation
on the ambient complex numbers.

**Theorem 12.2 — Equal full spectra do not classify the field.** Assuming
a measurable cardinal, a Cohen-real/Prikry tower gives two old surreal
fields in the same ambient universe with full spectrum `{omega}`, but
only one is omega-saturated. They are therefore not isomorphic. This does
not claim that equal gaps *and* equal saturation suffice for, or obstruct,
isomorphism; that stronger classification question remains open here.

The article contains ten further research questions in Section 14.

## Build and reproduce

Requirements: Python 3.10 or newer, latexmk, pdflatex, and a TeX distribution
providing the packages listed in the preamble, including newtx. No network
access is needed to run the tests or compile the article once these are
installed.

```sh
./build.sh
```

To run only the finite regression checks:

```sh
python3 checks/finite_checks.py
```

The supplied run passed **469,107 finite checks**. They test order, prefix
cones, first-disagreement bracketing, and coding identities. They do not
verify forcing, freshness, infinite cofinalities, saturation, or proper-class
arguments. No Lean verification is supplied.

## Provenance and status

The relevant ProveIt report was inspected at commit
`e21766d04c2b8a9b2cdba0cd43e563024b3bd1b9`. Classical sign-gap and saturation
results already in that report are credited and reproved in the needed
forms. Published Easton and Prikry fresh-spectrum results are credited to
Fischer–Koelbing–Wohofsky; small-forcing preservation of measurability is
credited to Lévy–Solovay. See the source audit and bibliography.

This is an AI-assisted research manuscript with conventional proofs. It is
not refereed, not independently machine-verified, and not a certified
priority claim. Its main arguments were checked during drafting, but an
independent mathematical review remains appropriate before treating the
proposed contributions as established literature.
