# The Codimension-One Degeneracies of Gowers Arrangements

**An asymptotically sharp replacement for Lemma 15.4 and explicit random-selection thresholds.**

Research manuscript prepared for Vladimir Reshetnikov; mathematical development
and computational checks with ChatGPT. Dated 6 October 2026.

## Main result

For labelled d-arrangements of k-cubes over a finite field F_q, let

- `D = (2d+1)k + 2d - 1`, `n = 2d * 2^k`;
- `T_m = [z^0](z^-1 + 1 + z)^m`;
- `H_d = (T_(2d) - 2*binomial(2d,d) + 1)/2`;
- `L = k + H_d`, `U = (3^n - 3^(2d))/2`.

For `k >= 1`, `d >= 2`, and **characteristic greater than 2d**, the number
`Z` of arrangements satisfying the full ternary-moment degeneracy condition obeys

```
L*q^(D-1) - binomial(L,2)*q^(D-2) <= Z
Z <= L*q^(D-1) + U*q^(D-2).
```

Thus the leading coefficient is exactly `k + H_d` for fixed k,d.
In the case used by Gowers, `H_8 = 2,585,444`.
The corresponding codimension-one components are explicitly classified.

The manuscript also proves a sharp individual-witness bound, shows that the
remaining degeneracy really has second-order size, gives a characteristic-5
counterexample to weakening the characteristic hypothesis, and proves an
arbitrary-d, finite-field Riesz-product selection theorem with an explicit
ambient-size condition. It ends with eight further research questions.

## Contents

- `arrangement_degeneracy.tex`: standalone LaTeX manuscript, bibliography included.
- `arrangement_degeneracy.pdf`: compiled 17-page article.
- `SOURCE_AUDIT.md`: original-paper passages, pinned formal definitions,
  scope comparison, and limitations.
- `code/verify.py`: reproducible exact finite checks, using only Python's standard library.
- `code/compare_cutoffs.py`: reproduction of the numerical threshold table.
- `data/verification.json`: saved passing exact-check results.
- `data/cutoff_comparison.json`: approximate logarithms of exact sufficient criteria.
- `data/build_summary.json`: compilation and verification record.
- `Makefile`: compilation, checks, and cleanup.

## Reproduction

Run from this directory:

```sh
make all
```

Or run the components separately:

```sh
python3 code/verify.py
python3 code/compare_cutoffs.py
pdflatex -interaction=nonstopmode -halt-on-error arrangement_degeneracy.tex
pdflatex -interaction=nonstopmode -halt-on-error arrangement_degeneracy.tex
pdflatex -interaction=nonstopmode -halt-on-error arrangement_degeneracy.tex
```

The Python scripts require Python 3.10 or later and no third-party packages.
Compilation uses a normal TeX Live installation with the packages listed in the
preamble. The bibliography is embedded: no BibTeX, external image assets, or
network access is required. Checks write their JSON output inside `data/`.

## Verification and status

The exact checks include all 3,240 non-parity ternary sign classes for k=1,d=2
over each of F_5 and F_7, projective hyperplane enumeration through d=5,
1,550 Walsh-identity instances, and 315 minimal-layer rank tests.
They passed. Finite checks are not a substitute for the general proofs.

This is an unrefereed research manuscript. No Lean proof is supplied or claimed;
no full-arrangement census or selection-process simulation is claimed. The
literature search does not establish priority. The result improves the local
arrangement-degeneracy and selection estimates; it does **not** assert an
improved final Szemeredi or van der Waerden bound.

## Suggested integration

```
Combinatorics/Ramsey/Research/GowersSzemeredi/arrangement-degeneracy-codimension/
```

The article gives a crosswalk to the existing definitions in
`Lean/GowersSzemeredi/Sections14_15.lean`. Preserve the wider original theorem
statements: the new sharp count has the additional assumptions d>=2 and
characteristic>2d. The package does not modify any repository file or status ledger.
