REPORT 120
Diagonal fugacity roots and DSASM growth bounds
A partial asymptotic result for A005163
2 October 2026

START HERE

Read report120.pdf. The complete editable mathematical source is
report120.tex. This report concerns a_n, the number of order-n
DSASMs (diagonally symmetric alternating sign matrices), OEIS A005163.
The order starts at n=1; a_0=1 is the empty-matrix convention.

If S counts nonzero main-diagonal entries, then

  Z_n(s) = sum_A s^S = s^(n mod 2) P_n(s^2).

The report proves joint right-half-plane stability of the multivariate
diagonal fugacity polynomial and strictly negative real zeros for P_n.
Multiplicity is allowed. No simple-root, interlacing or arbitrary
r-weighted stability assertion is made. The independent-Bernoulli
consequence concerns the distribution of the total (S-epsilon)/2;
it does not make the actual diagonal-entry indicators independent.

The quantitative asymptotic result is an eventual pair of envelopes:

  alpha n^2 + p n - (5/72) log n - C
    <= log a_n <=
  alpha n^2 + q n - (5/72) log n + C,

where alpha = (1/2) log(3 sqrt(3)/4),
p = 0.2632463454286169293260401267680... and
q = 0.2960487268742950122628240495510... .
The constants p and q are uniquely defined by contracting maps in
the report. Their printed brackets are certified by exact outward
rational arithmetic, not floating-point sign tests.

The proof uses the published triangular six-vertex bijection,
an elementary degree-two specialization of the known Borcea-Branden
MOD operator, finite Pascal/Toeplitz determinant transformations,
a classical shifted Andrews determinant, a parity-safe Stirling
calibration, Jensen and chord inequalities, and a projected two-step
contraction. The exact relation Z_n(2)=a_(n+1) is essential.

This is a partial result. Since p<q, it does not establish a single
linear coefficient, the actual power of n, a leading amplitude, or
the full equivalent and finer corrections in Conjecture 11.1 of
Behrend-Fischer-Koutschan. The quadratic growth rate was already
known. Equality of individual even/odd calibration amplitudes and
a limiting derivative-trace formula are outside the claims.
No bibliographic priority or external peer-review claim is made.

For N(T)=min{n>=1:a_n>=T}, the report proves an eventual two-ceiling
bracket whose unrounded width tends to 0.1253798292...<1. It leaves
at most two consecutive integer candidates eventually. The common
center retains a log(n_0)/n_0 correction, where n_0=sqrt(log(T)/alpha).
Error constants and the starting threshold are existential. This is
not a certified finite-target inversion algorithm. Errors stay
inside the ceilings, including near exact integer thresholds.

FILES

report120.tex                  Standalone mathematical source
report120.pdf                  Rendered report
build.py                       Two clean byte-identical PDF builds
build-environment.txt          Tested Python and PDF toolchain
pack.py                        Deterministic verified ZIP generation
integrity.py                   Closed outer SHA-256 inventory check
CHECKSUMS.sha256                Closed package inventory
checks/                        Independent exact checks and fixtures
checks/MANIFEST.json            Closed inner checker inventory
test_integrity.py              Negative tests for outer inventory
verification_results.json      Successful checker validation summary

No source-paper PDFs, private research notes, rendering intermediates,
or private machine-specific source paths are included.

DEPENDENCIES

All exact checks, schema and integrity checks, and negative tests need
only Python 3.10+ standard library; tested with Python 3.12. No network
or installation is needed.

PDF build: pdfTeX/pdflatex and the standard LaTeX packages geometry,
fontenc, lmodern, amsmath, amssymb, amsthm, mathtools, booktabs,
microtype, hyperref and enumitem. Tested with pdfTeX 1.40.26.

The build creates its TeX format in isolated temporary directories.
Different TeX/font versions may produce different PDF bytes without
changing the mathematics. ZIP byte identity likewise assumes the same
Python/zlib compression toolchain. A fresh-directory replay is not a
newly provisioned operating system. No supplied script installs
software or accesses the network.

CHECK THE RECEIVED PACKAGE

Run from the report120 directory after extracting the ZIP:

  python3 -B integrity.py .
  python3 -B checks/run_checks.py
  python3 -B -O checks/run_checks.py
  python3 -B checks/mutation_tests.py --output /tmp/report120-check-results.json
  python3 -B test_integrity.py

Use -B to prevent Python from adding bytecode-cache files to the
closed package. Put new validation outputs outside the extracted
package. Do not use integrity.py --write when validating a received
package: it replaces the inventory and is only for deliberate
repackaging. The inventories reject missing, changed and unexpected
files, unexpected directories and symlinks. Checksums detect changes;
they are not authenticated signatures.

EXACT CHECK SCOPE

The checker independently enumerates matrices from their original
row/column partial-sum definition for n=1,...,5 and triangular graph
orientations for n=1,...,4, matching the full joint diagonal masks.
The original Pfaffian reproduces 20 published A005163 terms n=1,...,20;
recursive Pfaffian expansion checks n<=8 and Pfaffian-squared equals
the determinant at all 20 sizes. A direct bivariate kernel expansion
is checked on a 21-by-21 coefficient grid.

The degree-at-most-n adjacent determinant polynomials D_n(t) are
reconstructed at n+1 exact interpolation nodes for n=1,...,10 and
agree with independent banded determinants. Original bordered and
both Pascal/Toeplitz forms agree through n=8. Adjacent division gives
P_n through n=11, matching independent matrix enumeration where
available. Finite triangular/binomial identities are checked through
size10; shifted Andrews determinants, double products, ASM factorial
products and the n+1 index agree through size16.

Sparse rational-polynomial identities check the kernel decomposition,
Mobius substitution and t=3 specialization. The exact Stirling
inverse-N contributions sum to -5/36 and the even calibration
logarithm is -5/72. The checker verifies the Jensen parameter/inverse
identities, derivatives and parity cancellation, the odd-calibration
coefficient algebra, formal inverse residual and finite rational
ceiling lemmas. An independent rational interval implementation
certifies all printed p/q/width endpoints, fixed-point signs, map
endpoint gaps, contraction and limiting width below one.

All guards stay active under Python -O. The checks README describes
the closed fixture schema and complete mutation scope. The aggregate
summary records all 82 individually mutated fixture leaves and 198
named cases: 82 leaf, 67 schema, 12 inventory and 37 mathematics/guard
mutations, run normally and under optimization for 396 negative
subprocesses. Normal and optimized baselines and fresh-directory
replays agree. Every negative result must match its intended
diagnostic, and source and mutated-copy bytes stay unchanged.
The outer-inventory suite separately checks 14 named mutations in
both modes, totaling 28 negative runs, in fresh temporary folders.

Finite checks are supplementary. They do not prove the all-size
stability theorem, classical determinant evaluation, controlled
Stirling expansion, projected contraction or asymptotic inverse.
Those arguments and their established inputs are in the report.

REBUILD THE PDF

  python3 -B build.py
  python3 -B integrity.py .

The build fixes timestamps and metadata, compiles three passes in
each of two independent temporary directories, rejects overfull
boxes and unresolved references, and requires byte-identical PDFs.
Each format-generation subprocess is limited to 120 seconds and each
LaTeX pass to 180 seconds, failing closed on timeout. The builder
writes report120.pdf without changing report120.tex. Every page of
the final PDF is rendered and visually checked for clipping, overlap,
legibility and broken references.

RECREATE THE ZIP

  python3 -B pack.py /tmp/report120-reproducibility.zip

The destination must be outside the package. The archive script first
checks the complete inventory, then writes sorted files under
report120/ with fixed timestamps and modes. The delivered archive
is freshly extracted, its PDF rebuilt, its checks replayed and its
ZIP reproduced byte for byte in the tested toolchain.

SOURCES

Primary paper, version 3 dated 1 October 2026:
https://arxiv.org/html/2309.08446v3

Existing MOD stability-preserver theorem, Section 8.4:
https://arxiv.org/abs/0809.3087

Classical determinant, Theorem 34 and equation (3.24):
https://www.mat.univie.ac.at/~kratt/akkomb/detsurv.pdf

Sequence definition:
https://oeis.org/A005163

Full mathematical references are in report120.pdf and report120.tex.
