# Tree-child asymptotics and A213863

This package accompanies the 23-page report in article/tree-child-asymptotics.pdf. Its editable LaTeX source is supplied alongside it.

The report proves a positive limiting amplitude, every finite n^(-1/3) correction, all-orders total-network transfer, weighted deficit-distribution expansions and a sharp total-variation rate, and Lambert-W inversion with valid integer brackets. The exact positive amplitude is defined by convergent limits. All numerical amplitude values are explicitly uncertified finite-index diagnostics.

## Replay

Use Python 3.12 or a compatible Python 3 environment. The tested package versions are pinned in requirements.txt. Install them with your usual virtual-environment tools, then run:

    python reproduce.py

This runs the exact rational and symbolic assertions, including independently written coefficient, inverse and distribution checks. Add --numerical to run the non-certified floating-point diagnostics through n=50000 and the tridiagonal eigenvalue check. Logs and a result JSON are written locally. No network access is required for the replay after dependencies are installed.

The main calculations and the verification calculations use separate algorithms where indicated. Numeric timings and floating-point last digits may vary by platform. The analytical proof is in the report; successful finite checks alone do not establish its limiting arguments.

## Rebuild the report

With a TeX distribution installed, run:

    bash article/build_pdf.sh

This rebuilds the PDF locally. The source is self-contained and does not import files outside this package. SHA256SUMS describes the distributed snapshot; replay-generated results and rebuilt PDFs may change their hashes.

## Package contents

- article/: complete report, editable TeX and PDF build script
- coefficients/: polynomial Airy recursion, natural-coordinate field check, symbolic results and optional numerical diagnostics
- verification/: independent direct solves and inverse/distribution algebra
- sources/: primary-source versions, locations, inspected-byte hashes and bounded literature-status statement
- check_exact_cocycle.py: exact rational recurrence and gauge checks
- verify_total_transfer.py: deficit polynomial and exact finite enumeration checks
- check_inverse.py: generic factorial-power inverse cancellations
- mathematical-verification.md: scope of the completed mathematical verification
- visual-quality.json: rendered-PDF inspection record

Third-party source PDFs are not redistributed. Their verified links and hashes are recorded in sources/. No external publication or submission has been made.
