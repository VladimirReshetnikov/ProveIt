# Borrowed registers and fused congruence

## Result

This research package was prepared for Vladimir Reshetnikov and ProveIt on
17 October 2026, against ProveIt commit
`61e77836565f63582561f54745f633d50efd9c7d`.

**No new machine below the public 253-state comparison point is claimed.**
The package provides new ordinary proofs, complete compiler-control tables,
finite verification artifacts, and a concrete proposal for the next step.

The main contributions are:

1. **Borrowed-register initialization.** Future zero-register markers first
   serve as binary counter bits and are restored by underflow. The final
   private initializer costs are 31 states for a zero seed and 32 for the
   original proof-counter seed two, using a shared runtime return. Complete
   controls for the existing 202-node decoder have **299/300 states**, compared
   with matched prior **309/311-state** controls. All tables and state-map
   certificates are supplied.
2. **Exact logical congruence fusion.** Three old logical axiom families are
   interderivable with one three-parameter family. The source AX word drops
   from 186 to 180 macro calls. An actual **271-state** full-framework
   compilation is included; it remains larger than the prior 268-state
   complete control. A 4,549-pair certificate and exact table regeneration
   check its compression, not the unproved final consistency endpoint.
3. **A stronger unary-theory calibration.** EPSC1 plus exact binary Union is
   deductively equivalent, in the raw equality-free language, to EPSC1 plus
   outgoing-profile adjunction and to unrestricted EPSC. This combines the
   incoming BU repair with the earlier source-26 theorem through direct
   derivations. It does not supply a new compiled state count.
4. **A broader interpretation obstruction.** Every fixed finite-dimensional
   interpretation of Extensionality and Pairing in the incoming unary
   one-support model has trivial induced permutation action, including
   interpretations with finitely many parameters outside their finite base.
   Invariant interpretations remain possible; unary equiconsistency is open.

Read **report.pdf** for the full report and **report.tex** plus **sections/**
for editable source. The report distinguishes new results, inherited facts,
finite checks, ordinary mathematical proofs, and unresolved formal bridges.

## Offline verification

Python 3.10+ and its standard library suffice:

```sh
python3 -B code/verify_all.py
```

This checks SHA-256 integrity, eight complete blank bootstraps and exact
quotients, the fused program's 4,549-pair certificate and all 418 decision
edges, byte-for-byte regeneration of its 542-row table, a separate 4,912-row
equation checker, and the support diagnostic. Corrupted certificates and
rows are rejected. No checkout, network, Coq, Lean, or external Python
packages are needed. Do not use `python -O`.

The command leaves the package unchanged. To save a run:

```sh
python3 -B code/verify_all.py --output /tmp/zfc-research-verification.json
```

These are finite checks. They do not establish the soundness of the inherited
affine executor, a new arbitrary-runtime simulation theorem, or the desired
internal ZFC equivalence for one of the delivered tables.

## Full experiments and report build

The subdirectory READMEs contain exact commands:

- `code/initializer/README.md`: 36 standalone cases, 14 full integrations
  with 8,391 affine cases each, shared-return composition and table regeneration.
- `code/fusion/README.md`: full 20,736-evaluation search, frozen winning recipe,
  checked regeneration and helper provenance.
- `code/theory/README.md`: finite-support diagnostic scope and usage.

Full compiler/search reproduction requires the pinned ProveIt checkout as
read-only input. Both drivers accept `--repo /path/to/ProveIt`; generated
files go outside it. The quick path above is self-contained.

Build the PDF with a standard TeX installation and latexmk:

```sh
make pdf
```

This invokes `latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex`.
No shell escape, bibliography service, image generation, or network is needed.
The delivered PDF was rendered and visually checked. Rebuilding it may change
metadata bytes; regenerate the integrity manifest with `make manifest` if you
intentionally edit or rebuild the package.

## Machine convention

All `.tm` files are complete two-symbol, one-tape, two-way-infinite machines.
The tape is initially zero everywhere; start state and head coordinate are
zero. Each row is `state read write direction next_state`, with direction
`L` or `R`. A table with `s` working states uses labels `0` through `s-1`,
both read rows, and the separate uncounted halt target `s`.

The fused table totalizes one inherited undefined halt transition as an
explicit move into halt. This preserves halting outcome, not that final
undefined-row step count. Its exact convention is documented and checked.
The initializer quotients, by contrast, preserve every literal step on every
input via a total transition homomorphism.

## Repository intake and provenance

The three requested commits, 34 reconciled manuscripts, and five incoming
archives were audited. `data/source_inventory.json` records the frozen
source identities; `NOTICE.md` and the subpackage provenance notes distinguish
the new work from inherited Mira-Cult, Jeff, Wade, mira-emmy, and ProveIt
contributions. Existing license notices are retained with their original scope.

No remote repository was changed. This archive can be added as a research
intake; formal initializer/quotient instances, logical fusion lemmas, and the
literal203 transformation interface are natural separate implementation tasks.

The proposal is to transport proved logical sharing into the actual optimized
public decoder under its path/boot constraints, and to specialize a complete
frontend for the calibrated theory EPSC1+BU. Neither direction is assigned
an unmeasured sub-253 state count.
