# A two-cell proof of the 218-to-157 elimination

Let R be the 212-state table after the eleven listed source rotations, and
let C be the final 211-state table. Native labels are used throughout; the
separate halt label is 254. C is obtained from R by replacing every target
218 by 157 and deleting the two rows of 218. Its SHA-256 is
`72234980bd604524d5cd39e16f0e7f40c8547161334d65045fba5743e26db1c1`.

The exhaustive incoming-edge list for 218 in R is

| Row | Transition |
| --- | --- |
| 158, 0 | 0, R, 218 |
| 163, 0 | 0, R, 218 |
| 211, 0 | 0, R, 218 |
| 216, 0 | 0, R, 218 |

State 218 is not initial. Consequently, every occurrence of state 218 in
an R run starting in state 0 has a zero immediately to the left of the
head, on every initial binary tape. This invariant uses the written bit,
not an assumption about the initial contents of that cell.

Fix head coordinate h, let the current bit be b, and assume T(h-1)=0.
No condition is imposed on any other tape cell. The R transition is

* if b=0: (218,h,T) -> (90,h+1,T);
* if b=1: (218,h,T) -> (86,h+1,T).

The corresponding C paths are

* b=0: (157,h,T) -> (67,h-1,T) -> (151,h,T) -> (90,h+1,T);
* b=1: (157,h,T) -> (148,h-1,T) -> (186,h,T) -> (86,h+1,T).

Each transition on either path rewrites the bit already present. The full
tape, head position, and terminal control state agree, and neither path
visits the halt state. Each R block has length one; each C block has length
three. Only cells h-1 and h are read, so these are whole-tape identities,
with an arbitrary, possibly infinite exterior.

Define the state map f(218)=157 and f(q)=q otherwise. Relate an R
configuration (q,h,T) to (f(q),h,T) in C, imposing T(h-1)=0 only when
q=218. At q != 218, one transition in each machine produces related
configurations: rows have unchanged writes and moves, and their targets
are transformed exactly by f. If the next R state is 218, the complete
incoming-edge list supplies the required predecessor zero. At q=218,
the two paths above supply a 1-to-3 block. Both machines have initial
state 0, so the relation holds initially on every common tape.

Induction on R steps constructs corresponding C blocks. All block lengths
are positive and at most three. Thus an infinite R execution induces an
infinite C execution. Conversely, if C halts, choose enough R steps that
the corresponding positive-length C blocks pass its purported halting
time; this is impossible unless R already halted. The same argument can
be expressed as finite induction bounded by the proposed halting time,
without appealing to an external completed infinite run. Therefore the
literal machines halt equivalently on every common tape from state 0.
For finite-support encoded tapes, including blank, this elementary
finite-trace argument is formalizable in PA.

If both runs halt, let N be the number of R transitions whose source is
218. Then the exact clock relation is

    T_C = T_R + 2 N,

and consequently T_R <= T_C <= 3 T_R. These inequalities concern the
rotated intermediate R, not the original U212 source representation;
source rotations can change address-dependent execution costs.

The rotation and source proof is separate from this local lemma. The
independent checker reconstructs all eleven literal rotations, checks
the unique-inner-entry and bit-preserving-right-moving hypotheses,
reconstructs the new source addresses, and verifies equality of every
source ordinal effect and guarded successor after each rotation. This
gives identity-on-ordinal and identity-on-register source conjugacy.
It also compares the entire 48,140-transition blank startup configurations
and used-row sets against the original U212 table. The universal primitive
runtime proof is still a distinct required gate; source conjugacy alone
does not certify a modified literal decoder.

The independent finite checker is `independent_u211_check.py`. It imports
none of the construction, source-language, symbolic-runtime, or discovery
modules. All checks use explicit exceptions and remain active under
`python -O`. It reports 3,909 source instructions, 5,083 nonhalting guarded
successor arrows, and 5,084 cases after including the CH case; these are
compatible counts. It checks 211 graph-reachable working states and 422
rows. Graph reachability does not claim every state is reached on blank.
