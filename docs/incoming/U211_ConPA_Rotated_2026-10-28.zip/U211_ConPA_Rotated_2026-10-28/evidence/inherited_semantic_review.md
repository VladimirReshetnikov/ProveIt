# Semantic audit of U and the selected U212 lineage

## Source scope

Read the complete principal sections of `pa_unary_power_cover/pa_unary_power_cover`: overview, unary_core, unary_arithmetic, unary_separation, upper_transport, positive_interface, emitter, stream. Read the selected U212_ConU and u212_combined reports and the retained U214 role-emitter and ST-U213 source-comparison arguments.

## Theory calibration

The equality-free theory U has the unary schema

    forall a exists b [(forall x (x in b -> phi(x))) and
                       (forall x (x subseteq a -> (phi(x) -> x in b)))]

with only x free in phi. It is not legitimate to exactify by inserting a into phi. The supplied lower proof avoids this: saturated numerical representatives have endpoint properties; induction for arbitrary ambient formulas is proved before successor totality; then numerical comparison and global least failed tuples support parameter elimination. Bounded numerical comprehension derives successor and numerical powers. Saturated ordered pairs and canonical histories provide addition and multiplication. All uses of graph parameters in filter matrices are bound; arbitrary graph parameters occur only in the already derived induction principle. I found no immediate circularity or illicit free parameter in these proofs.

The upper interpretation sends membership to Ackermann binary membership. PA proves inclusion of bits bounds x by a, and its formula-by-formula finite comprehension produces exact bounded filters. This validates even the unrestricted weak-cover schema W and global irreflexivity IR.

Consequently the machine need not validate unary matrix scope. It can enumerate unrestricted W+IR instances, because U is included in W and PA interprets W+IR. This distinction must be maintained in any report: the machine-facing calculus is calibrated to U, not a literal implementation of precisely the unary input grammar.

## Positive reference interface is a distinct presentation

The first theory packet also gives a positive implication/universal grammar with q0 = E(v0,v0), D = forall v E(v,v), and ordinary theory P + not D. P alone has a one-object total-relation model. Its consistency is therefore not the endpoint; nonderivability of q0 is the endpoint. The native U212 line uses a different inherited numerical calculus with truth and falsity aliases, vacuity bundles, and global irreflexivity. Do not substitute the positive packet's numerical emitter for the native one without a new implementation/calibration proof.

## Exact selected U212 machine

The U212_ConU and u212_combined primary tables are the same artifact:

- native SHA256: 386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4
- dense SHA256: c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e
- 212 working states, 424 binary rows; separate halt
- 197 source DAG nodes and 3909 primitive source occurrences

They compose the direct-transfer ST source with the U214 role-a cover emitter and seven-zero origin detector, then retime native 180/read1 through existing native211, redirect 172/read0 to native67, and delete native112. Using helper167 from the earlier U214 allocation would be incorrect in this source layout.

The local changes have ordinary two-sided finite-block proofs. The first stage is arbitrary-tape equality after positive blocks; the second uses the complete incoming-row invariant that 172 is entered from 116/read0, so native112 has two adjacent zeros. The exact proof scope is stronger than a bounded blank trace. Finite exhaustive checks are useful witnesses for those local identities but do not by themselves establish the entire logical calibration.

## Startup dependency that must survive

The selected table does not reach the older clean N4 source root. Its blank startup reaches native84 after 48140 transitions, head -2, header54, source ordinal136, source address 001100110101010, logical registers

    (N,T,W,A,D,H,X,Y,L) = (1,0,13,0,0,1,0,0,1),

with 43 spares equal to1 and 120 one cells. The origin frame distance is 56+g, not64+g. The inherited suffix bridge begins at ordinal106 with registers (1,0,4,0,0,1,0,0,1), executes141 source steps, and builds nine theorem heads over opaque tail4. Candidate1 has conservative credit2, retaining margin7. The initially cached1 is used as a selector parameter, not as a theorem. A transition-only reduction proved equivalent from initial state0 inherits all these obligations without needing to reconstruct a fresh root calibration.

## Proof status

The U theory packet explicitly supplies ordinary mathematical uniform proof transformations, not an implemented arbitrary-PA proof translator or a Lean/Rocq/MM0 verification. The U212 packets explicitly make ordinary PA-formalizability claims, together with independent finite machine checks and universal source-runtime symbolic checks. They do not supply a freshly kernel-checked PA endpoint for U212.

K215's reported proof-assistant and MM0 endpoint applies to its pinned literal machine and source. It cannot certify a different U source or transition table without the new source/physical/logic transport. Report a smaller descendant as a candidate with the exact new equivalence proof and inherited mathematical calibration, unless a complete new formal certificate is actually built.

## Semantic optimization observations

The native role-a emitter has a guard c != a and c != b because its bundled atomic-vacuity theorem R(a,b) -> forall c R(a,b) needs both exclusions. Removing either test without replacing the logical bundle is unsound in general. Source-output equality a=b is already handled without a rejection branch: under IR the captured subset guard reduces to emptiness, and an empty source supplies the required cover. Matrix code0 and code1 cases are explicitly calibrated. These cases offer no immediate additional deletion.

A logical change should be considered only after its effect on the native source DAG and actual physical allocation is checked; constructor count, emitted polynomial degree, and asymptotic code length alone do not imply any state saving.
