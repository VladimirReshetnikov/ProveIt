# The eleven rotations behind U211

This note explains the deterministic construction in `target218_certificate.py`. Its machine-readable ledger is `target218_verified/construction.json`. The separate full primitive-runtime pass succeeded for all 5,084 guarded cases; its receipt and complete case records are `target218_runtime.json` and `target218_runtime.cases.json`.

## The design idea

The old native state 218 is a pure right-moving decoder:

| Read | Action |
| --- | --- |
| 0 | write 0, R, 90 |
| 1 | write 1, R, 86 |

Native 157 performs the same logical decoding with two extra steps whenever the immediately preceding tape cell is zero. Originally, however, 218 has two zero-writing and two one-writing predecessors. Simply merging it with 157 is invalid.

The new source layout changes the incoming tags, while retaining the source primitive word and its complete control-flow graph. One rotation changes the 158-to-218 edge from the one branch to the zero branch. Ten further rotations carry a fixed closed 78-primitive continuation rightward along a chain of closed factors until the 163-to-218 edge also becomes a zero branch. The other entrances, from 211 and 216, already write zero.

The helper 211 remains in place and keeps its external bypass entrance from 180/read 1. The failed older donor recipes tried to rotate through 211 itself. Here 211 is an unchanged factor, so its extra entrance causes no conflict.

## One rotation

Every step is the right reassociation

`((A,B),C) -> (A,(B,C))`.

In the literal table, before a step the pure decoders are

```
q: 0 -> r, 1 -> z
r: 0 -> x, 1 -> y
```

and after it they are

```
q: 0 -> x, 1 -> r
r: 0 -> y, 1 -> z.
```

Every displayed row writes the scanned symbol and moves right. The complete incoming-edge inventory proves that r has the unique entrance q/read 0. The corresponding source occurrence is found by literal evaluation of its known address from dispatcher 84, without reading unknown exterior cells. Both before and after the reassociation the three factors are the same ordered primitive subprograms.

At source prefix p, the address substitutions are `p00u -> p0u`, `p01u -> p10u`, and `p1u -> p11u`. This changes the code addresses while preserving primitive ordinals and operations. The exact intermediate sources are checked against two independently formulated successor resolvers: one using subtree intervals and ancestor cuts, and one using binary successor arithmetic and cut positions. Both produce exactly the original complete guarded ordinal graph, including control instructions outside the reassociated factors.

## Closedness

For a source factor, let `(beta,gamma,halt)` count breaks and continues escaping its surrounding scope and indicate whether it contains a halt. The leaves have signatures:

- `CI(i)`: `(0,0,false)`.
- `CD(i)`: `(1,0,false)`.
- `CB(k)`: `(k,0,false)`.
- `CC(k)`: `(0,k,false)`.
- `CH`: `(0,0,true)`.

For a pair `(A,B)` the signature is

`(max(beta(A)-1,beta(B),0), max(gamma(A),gamma(B)-1,0), halt(A) or halt(B))`.

All 33 factors used by the eleven rotations have signature `(0,0,false)`. Therefore their internal control behavior does not depend on which of the two displayed outer parenthesizations is used. Normal termination passes through A, B, C in the same order; divergence within a factor remains divergence. The exact complete-CFG comparison additionally verifies every concrete external control edge, rather than relying only on this generic factor argument.

## Rotation ledger

Intervals are zero-based primitive-ordinal intervals `[lo,hi)`. Factor state names identify the three decoder entries before that step. All sides are zero, all factors are closed, and every inner decoder has precisely its displayed outer zero entrance.

| Step | Outer / inner | Ordinal interval | Factor sizes | Factor states | Changed addresses in this step |
| ---: | --- | --- | --- | --- | ---: |
| 1 | 129 / 158 | [3016,3176) | 26,56,78 | 98,218,178 | 160 |
| 2 | 162 / 203 | [640,3736) | 503,2515,78 | 207,223,116 | 3096 |
| 3 | 203 / 223 | [1143,3736) | 401,2114,78 | 67,188,116 | 2593 |
| 4 | 223 / 188 | [1544,3736) | 56,2058,78 | 153,177,116 | 2192 |
| 5 | 188 / 177 | [1600,3736) | 1042,1016,78 | 132,89,116 | 2136 |
| 6 | 177 / 89 | [2642,3736) | 80,936,78 | 155,174,116 | 1094 |
| 7 | 89 / 174 | [2722,3736) | 162,774,78 | 159,185,116 | 1014 |
| 8 | 174 / 185 | [2884,3736) | 292,482,78 | 217,215,116 | 852 |
| 9 | 185 / 215 | [3176,3736) | 160,322,78 | 214,204,116 | 560 |
| 10 | 215 / 204 | [3336,3736) | 163,159,78 | 216,163,116 | 400 |
| 11 | 204 / 163 | [3499,3736) | 103,56,78 | 211,218,116 | 237 |

The fixed continuation in steps 2 through 11 is state 116's 78-primitive factor. Some intermediate layouts have a seven-zero address; no universal runtime theorem is claimed for these intermediates. Their role is to provide a finite source transformation. The final layout restores maximum zero run six, reduces maximum depth from 42 to 41, keeps 197 distinct source subtrees and all 3,909 primitives, and changes 3,096 addresses overall. Only the final literal table needs the new complete runtime certificate.

## Final guarded deletion

In the final rotated 212-state table, the entire incoming inventory of 218 is

```
158/read0 -> write0,R,218
163/read0 -> write0,R,218
211/read0 -> write0,R,218
216/read0 -> write0,R,218.
```

Since the initial state is zero, every visit to state 218 therefore has a zero immediately left of the head, on every initial tape. Under this condition the one-step old actions and three-step replacements have identical endpoints and unchanged complete tapes:

```
read0: 218 -> 90
       157 -> 67 -> 151 -> 90

read1: 218 -> 86
       157 -> 148 -> 186 -> 86.
```

The new path starts with the head in the old scanned cell, moves left, right, right, and finishes one cell to the right. It reads only the preceding zero and the original scanned bit; the exterior is opaque. Redirect all targets 218 to 157 and delete both 218 rows. The resulting table has 211 working states and 422 transitions, all graph reachable.

Let the state correspondence identify old 218 with new 157 and leave every other state unchanged. Ordinary transitions match one for one. Every old step from 218 matches exactly three new transitions. The entry invariant holds on every old run from state zero. Induction on finite blocks yields two-sided halting equivalence between the rotated 212-state table and the final 211-state table. Both simulations use positive bounded blocks and cannot hide an internal halt. For common halting inputs the local deletion alone gives `T_rotated212 <= T_211 <= 3*T_rotated212`. This does not claim that the original pre-rotation U212 and U211 obey that literal bound.

## From the old U212 to the final blank-tape machine

The old and final source programs have the same primitive at each ordinal and exactly the same guarded ordinal successors. Hence their register transition systems coincide under the ordinal identification, for every natural register store. The final source retains the exact interior startup address at ordinal 136. None of the 19 changed retained rows, nor the deleted state, occurs in the complete 48,140-step blank prefix. The new certificate compares every literal prefix row and the full finite-support tape, not merely a selected register projection.

Consequently both machines reach the same source configuration: native dispatcher 84, head -2, header coordinate 54, logical registers `(1,0,13,0,0,1,0,0,1)`, 43 spare values one, and 120 one-cells with zero exterior. The inherited suffix/credit calibration applies unchanged at this ordinal configuration.

The full symbolic primitive-runtime proof for the final layout and final table has now passed, over arbitrary natural primary registers, nonnegative gap and nonempty finite spare lists. Its 5,084 contracts cover all 422 literal rows, use 1,245,944 symbolic inference steps, and have minimum constant duration five. Both literal machines therefore simulate the identical ordinal register system from their common frame, subject to the inherited mathematical soundness of the stated unary/list induction rules. Positive finite durations and coverage of all guarded instructions transfer halting in both directions. This is a conventional argument formalizable in PA. The unchanged inherited numerical-calculus and U/PA interpretation arguments then transfer the consistency endpoint. No new end-to-end proof-assistant certificate is supplied by these executable checks alone.
