"""Deterministically reconstruct U211. No optimizer, network, or third-party package."""
from functools import lru_cache
import importlib.util
import json
from common import ROOT, require, parent, load_table, encode, dump, digest
from common import NATIVE_SHA, DENSE_SHA, NEW_SOURCE_SHA

def is_leaf(node):
    return isinstance(node[0], str)

def parse_source(rows):
    leaves = {p: (op, arg) for p, op, arg in rows}
    require(len(leaves) == len(rows), 'Duplicate source address')
    prefixes = {p[:i] for p in leaves for i in range(len(p))}
    require(not prefixes.intersection(leaves), 'Source prefix conflict')
    def visit(p):
        if p in leaves:
            return leaves[p]
        require(p in prefixes and all(p+b in prefixes or p+b in leaves for b in '01'),
                'Incomplete source tree')
        return visit(p+'0'), visit(p+'1')
    return visit('')

def source_rows(node, p=''):
    if is_leaf(node):
        return [[p, *node]]
    return source_rows(node[0], p+'0') + source_rows(node[1], p+'1')

@lru_cache(None)
def boundary(node):
    if is_leaf(node):
        op, arg = node
        return (1 if op == 'CD' else arg if op == 'CB' else 0,
                arg if op == 'CC' else 0, op == 'CH')
    left, right = boundary(node[0]), boundary(node[1])
    return max(left[0]-1, right[0], 0), max(left[1], right[1]-1, 0), left[2] or right[2]

@lru_cache(None)
def size(node):
    return 1 if is_leaf(node) else size(node[0])+size(node[1])

def subtree(node, path):
    for b in path:
        require(not is_leaf(node), 'Path crosses primitive')
        node = node[int(b)]
    return node

def replace(node, path, new):
    if not path:
        return new
    children = list(node)
    children[int(path[0])] = replace(children[int(path[0])], path[1:], new)
    return tuple(children)

def metrics(node):
    seen = set()
    def walk(n):
        if n in seen:
            return
        seen.add(n)
        if not is_leaf(n):
            walk(n[0]); walk(n[1])
    walk(node)
    rows = source_rows(node)
    return dict(dag_nodes=len(seen), leaf_occurrences=len(rows),
                maximum_depth=max(len(p) for p, _, _ in rows),
                maximum_zero_run=max(len(v) for p, _, _ in rows for v in p.split('1')))

def main():
    baseline = parent()
    # Both parent resolvers are pure syntax utilities; actual reconstruction is here.
    path = baseline / 'baseline/primary_u213/code/source_language.py'
    spec = importlib.util.spec_from_file_location('parent_source_language', path)
    source_language = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source_language)
    before = load_table(baseline / 'machine/u212.native.tm')
    original = json.loads((baseline / 'baseline/primary_u213/machine/sites.json').read_text())
    tree = parse_source(original)
    require(source_rows(tree) == original, 'Source ordering')
    graph = source_language.graph_intervals(original)
    require(source_language.graph_arithmetic(original)[0] == graph, 'Parent CFG mismatch')
    table = dict(before)
    recipe = json.loads((ROOT / 'construction/recipe.json').read_text())
    require(len(recipe['rotations']) == 11, 'Rotation count')
    ledger = []
    for number, item in enumerate(recipe['rotations'], 1):
        q, r = item['q'], item['r']
        require(item['side'] == 0 and table[q, 0] == (0, 1, r), 'Rotation direction')
        require([(p, b) for (p, b), action in table.items() if action[2] == r] == [(q, 0)],
                'Inner decoder has another entrance')
        require(all(table[state, b][:2] == (b, 1) for state in (q, r) for b in (0, 1)),
                'Rotation is not a pure right decoder')
        factor_labels = [table[r, 0][2], table[r, 1][2], table[q, 1][2]]
        factors = []
        for p in item['paths']:
            node = subtree(tree, p)
            require(not is_leaf(node) and not is_leaf(node[0]), 'Source rotation shape')
            a, b, c = node[0][0], node[0][1], node[1]
            require(all(boundary(x) == (0, 0, False) for x in (a, b, c)),
                    'A factor has an escaping control or halt')
            start = next(i for i, row in enumerate(source_rows(tree)) if row[0].startswith(p))
            factors.append(dict(path=p, ordinal_start=start, ordinal_stop=start+size(node),
                                factor_sizes=[size(a), size(b), size(c)]))
            tree = replace(tree, p, (a, (b, c)))
        a, b, c = factor_labels
        table[q, 0], table[q, 1] = (0, 1, a), (1, 1, r)
        table[r, 0], table[r, 1] = (0, 1, b), (1, 1, c)
        rows = source_rows(tree)
        require(source_language.graph_intervals(rows) == graph, 'Interval CFG changed')
        require(source_language.graph_arithmetic(rows)[0] == graph, 'Binary CFG changed')
        ledger.append(dict(number=number, outer=q, inner=r, factor_labels=factor_labels,
                           occurrences=factors, closed=True, both_cfg_resolvers_pass=True))
    require(encode(table) == (ROOT / 'machine/rotated212.native.tm').read_bytes(),
            'Rotated table bytes differ')
    require(recipe['merge'] == {'remove': 218, 'representative': 157}, 'Wrong fold')
    final = {(q, b): (w, d, 157 if z == 218 else z)
             for (q, b), (w, d, z) in table.items() if q != 218}
    states = sorted({q for q, b in final})
    require(len(states) == 211 and len(final) == 422, 'State census')
    mapping = {q: i for i, q in enumerate(states)}
    mapping[254] = 211
    dense = {(mapping[q], b): (w, d, mapping[z]) for (q, b), (w, d, z) in final.items()}
    raw_source = (json.dumps(source_rows(tree), separators=(',', ':'))+'\n').encode()
    target = ROOT / 'build/rebuilt'
    target.mkdir(parents=True, exist_ok=True)
    for name, raw in [('u211.native.tm', encode(final)), ('u211.tm', encode(dense)),
                      ('sites.json', raw_source)]:
        (target / name).write_bytes(raw)
    require(encode(final) == (ROOT / 'machine/u211.native.tm').read_bytes(), 'Native bytes')
    require(encode(dense) == (ROOT / 'machine/u211.tm').read_bytes(), 'Dense bytes')
    require(raw_source == (ROOT / 'source/sites.json').read_bytes(), 'Source bytes')
    require(digest(target / 'u211.native.tm') == NATIVE_SHA, 'Native hash')
    require(digest(target / 'u211.tm') == DENSE_SHA, 'Dense hash')
    require(digest(target / 'sites.json') == NEW_SOURCE_SHA, 'Source hash')
    state_map = json.loads((ROOT / 'machine/state_map.json').read_text())
    require({int(k): v for k, v in state_map['native_to_dense'].items()} == mapping,
            'Native-to-dense map')
    require({int(k): v for k, v in state_map['dense_to_native'].items()} ==
            {v: k for k, v in mapping.items()}, 'Dense-to-native map')
    changes = [dict(state=q, read=b, before=list(before[q, b]), after=list(action))
               for (q, b), action in sorted(final.items()) if before[q, b] != action]
    require(len(changes) == 19, 'Patch census')
    output = dict(status='EXACT_REBUILD_PASS', states=211, rows=422, rotations=ledger,
                  source_metrics=metrics(tree), changed_retained_rows=changes,
                  removed_native_state=218, old_cases=5084,
                  changed_addresses=sum(a[0] != b[0] for a, b in zip(original, source_rows(tree))),
                  native_sha256=NATIVE_SHA, dense_sha256=DENSE_SHA, source_sha256=NEW_SOURCE_SHA)
    dump(ROOT / 'build/rebuild.json', output)
    print('Exact rebuild PASS: 211 states, 422 rows, 11 closed rotations, 19 changed rows.')
    return baseline

if __name__ == '__main__':
    main()
