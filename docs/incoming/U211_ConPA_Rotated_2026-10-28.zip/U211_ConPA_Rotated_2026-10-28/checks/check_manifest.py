"""Verify the released payload bytes; no external dependencies or assertions."""
from pathlib import Path
import hashlib
import json


def main():
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    entries = manifest['files']
    names = set()
    for entry in entries:
        name = entry['path']
        if name in names:
            raise ValueError('Duplicate manifest path: ' + name)
        names.add(name)
        path = (root / name).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError('Missing or unsafe payload: ' + name)
        raw = path.read_bytes()
        if len(raw) != entry['size_bytes']:
            raise ValueError('Size mismatch: ' + name)
        if hashlib.sha256(raw).hexdigest() != entry['sha256']:
            raise ValueError('Hash mismatch: ' + name)
    print(f'MANIFEST_PASS: {len(entries)} payload files verified.')


if __name__ == '__main__':
    main()
