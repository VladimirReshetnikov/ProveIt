"""Pinned input access and small literal table utilities; standard library only."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
INPUT_SHA = '993a97dd787144f7c9fcc7303f33032a392e866ba66ad15eb2aa2ebb1e48f56b'
PARENT_SHA = '386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4'
SOURCE_SHA = '7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00'
NATIVE_SHA = '72234980bd604524d5cd39e16f0e7f40c8547161334d65045fba5743e26db1c1'
DENSE_SHA = 'b7cd1359872334097d7a17c533c52c0aca46e05b0b901136d1b3e0f30fdf2304'
NEW_SOURCE_SHA = '3f74267c84fc31cb7e9c596548dc698e17212a097ebf2f6f0e75c7a67992ec08'

def require(condition, message):
    if not condition:
        raise ValueError(message)

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def parent():
    archive = ROOT / 'inputs/u212_combined_2026-10-29.zip'
    require(digest(archive) == INPUT_SHA, 'Input ZIP digest differs')
    destination = ROOT / 'build/parent'
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as source:
        for member in source.infolist():
            target = (destination / member.filename).resolve()
            require(target.is_relative_to(destination.resolve()), 'Unsafe archive path')
            require((member.external_attr >> 16) & 0o170000 != 0o120000,
                    'Archive symlinks are not accepted')
        source.extractall(destination)
    result = destination / 'u212_combined_2026-10-29'
    require(digest(result / 'machine/u212.native.tm') == PARENT_SHA, 'Parent table')
    require(digest(result / 'baseline/primary_u213/machine/sites.json') == SOURCE_SHA,
            'Parent source')
    return result

def load_table(path, halt=254):
    table = {}
    headers = []
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):
            headers.append(line)
        if not line or line.startswith('#'):
            continue
        q, bit, write, direction, target = line.split()
        q, bit, write, target = map(int, (q, bit, write, target))
        require((q, bit) not in table, 'Duplicate transition')
        require(bit in (0, 1) and write in (0, 1) and direction in ('L', 'R'),
                'Invalid transition')
        table[q, bit] = write, 1 if direction == 'R' else -1, target
    states = {q for q, bit in table}
    require(headers == ['#! start 0'], 'Start declaration')
    require(0 in states and halt not in states, 'Start/halt states')
    require(set(table) == {(q, bit) for q in states for bit in (0, 1)},
            'Incomplete binary table')
    require({z for w, d, z in table.values()} - states == {halt}, 'Target closure')
    return table

def encode(table):
    return ('#! start 0\n' + ''.join(
        f'{q} {bit} {write} {"R" if direction == 1 else "L"} {target}\n'
        for (q, bit), (write, direction, target) in sorted(table.items()))).encode('ascii')

def dump(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, indent=2) + '\n')
