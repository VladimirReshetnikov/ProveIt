"""Check the exact inherited symbolic rules and the explicit native relabeling."""
import ast
import json
from common import ROOT, require, digest, dump

def definitions(path):
    return {node.name: node for node in ast.parse(path.read_text()).body
            if isinstance(node, (ast.FunctionDef, ast.ClassDef))}

class NativeCase(ast.NodeTransformer):
    def visit_Name(self, node):
        if node.id == 'HEADER_BASE':
            return ast.Constant(value=56)
        return node

    def visit_Constant(self, node):
        if node.value == 96:
            return ast.Constant(value=84)
        return node

class NativeBlocks(ast.NodeTransformer):
    mapping = {73: 64, 95: 0, 48: 40, 112: 97}

    def visit_Constant(self, node):
        if type(node.value) is int and node.value in self.mapping:
            return ast.Constant(value=self.mapping[node.value])
        return node

def main():
    folder = ROOT / 'checks/native56'
    provenance = json.loads((folder / 'PROVENANCE.json').read_text())
    for name, value in provenance['files'].items():
        require(digest(folder / name) == value, 'Native inherited file changed: '+name)
    old_folder = ROOT / 'build/parent/u212_combined_2026-10-29/baseline/primary_u213/code'
    old = definitions(old_folder / 'symbolic_runtime.py')
    new = definitions(folder / 'native_symbolic.py')
    names = sorted(old)
    for name in names:
        require(name in new, 'Missing induction rule '+name)
        node = old[name]
        if name == 'case':
            node = NativeCase().visit(node)
        if name == 'prove_blocks':
            node = NativeBlocks().visit(node)
        require(ast.dump(node, include_attributes=False) ==
                ast.dump(new[name], include_attributes=False), 'Changed induction rule '+name)
    old_helpers = definitions(old_folder / 'independent_runtime.py')
    new_helpers = definitions(folder / 'source_ops.py')
    for name in ('inc', 'strip'):
        require(ast.dump(old_helpers[name], include_attributes=False) ==
                ast.dump(new_helpers[name], include_attributes=False), 'Control helper '+name)
    report = dict(status='INHERITED_ENGINE_RELABELING_PASS', definitions=names,
                  header_distance=56, dispatch_relabeling=[96, 84],
                  list_entries={73: 64, 95: 0, 48: 40, 112: 97},
                  scope='Identical inherited symbolic induction functions after the explicit '
                        'native-label and header-constant substitutions. No new proof kernel.')
    dump(ROOT / 'build/engine_provenance.json', report)
    print('Inherited symbolic induction rules and native relabeling PASS.')

if __name__ == '__main__':
    main()
