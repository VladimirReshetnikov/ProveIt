"""Independent finite checks of the targeted 218 elimination.

No constructor, source-language module, symbolic engine, or discovery routine
is imported. All checks fail explicitly even under python -O.
"""
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT / 'build/parent/u212_combined_2026-10-29'

def require(value, message):
    if not value:
        raise ValueError(message)

def table(path):
    result = {}
    for line in Path(path).read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        q, b, w, d, z = line.split()
        key = int(q), int(b)
        require(key not in result, 'Duplicate row')
        require(b in ('0', '1') and w in ('0', '1') and d in ('L', 'R'), 'Bad row')
        result[key] = int(w), 1 if d == 'R' else -1, int(z)
    states = {q for q, _ in result}
    require(set(result) == {(q, b) for q in states for b in (0, 1)}, 'Incomplete table')
    require({z for w, d, z in result.values()} - states == {254}, 'Bad halt/target')
    return result

def graph(sites):
    paths = [p for p, op, arg in sites]
    require(paths == sorted(set(paths)), 'Source order or duplicate')
    intervals = {}
    for ordinal, p in enumerate(paths):
        require(p and set(p) <= {'0', '1'}, 'Bad address')
        for j in range(len(p) + 1):
            prefix = p[:j]
            if prefix not in intervals:
                intervals[prefix] = [ordinal, ordinal + 1]
            else:
                intervals[prefix][1] = ordinal + 1
    leaves = set(paths)
    for p, (start, stop) in intervals.items():
        if p in leaves:
            require(stop == start + 1, 'Leaf has descendants')
            require(p + '0' not in intervals and p + '1' not in intervals, 'Prefix conflict')
        else:
            require(p + '0' in intervals and p + '1' in intervals, 'Nonfull source')
            left, right = intervals[p + '0'], intervals[p + '1']
            require(left[0] == start and left[1] == right[0] and right[1] == stop,
                    'Noncontiguous interval')
    count = len(sites)
    def escape(p, bit, level, right):
        for j in range(len(p) - 1, -1, -1):
            if p[j] == bit:
                level -= 1
                if level == 0:
                    return intervals[p[:j]][int(right)] % count
        return 0
    result = []
    for i, (p, op, arg) in enumerate(sites):
        after = (i + 1) % count
        if op == 'CI':
            targets = [after]
        elif op == 'CD':
            targets = [escape(p, '0', 1, True), after]
        elif op == 'CB':
            targets = [escape(p, '0', arg, True)]
        elif op == 'CC':
            targets = [escape(p, '1', arg, False)]
        elif op == 'CH':
            targets = []
        else:
            raise ValueError('Bad opcode')
        result.append((op, arg, targets))
    return result

def rotate_source(sites, prefixes):
    output = []
    for p, op, arg in sites:
        hits = [prefix for prefix in prefixes if p.startswith(prefix)]
        require(len(hits) <= 1, 'Overlapping rotation sites')
        if hits:
            prefix = hits[0]
            tail = p[len(prefix):]
            if tail.startswith('00'):
                tail = '0' + tail[2:]
            elif tail.startswith('01'):
                tail = '10' + tail[2:]
            elif tail.startswith('1'):
                tail = '11' + tail[1:]
            else:
                raise ValueError('Rotation source shape')
            p = prefix + tail
        output.append([p, op, arg])
    return output

def run_prefix(T, count):
    state = head = 0
    ones = set()
    used = set()
    for _ in range(count):
        b = int(head in ones)
        used.add((state, b))
        w, direction, state = T[state, b]
        if w:
            ones.add(head)
        else:
            ones.discard(head)
        head += direction
        require(state != 254, 'Unexpected startup halt')
    return state, head, ones, used

def local(T, state, bit, steps):
    # Only the cells -1 and 0 exist in this symbolic input. Accessing any other
    # cell before the last step is rejected, leaving the exterior arbitrary.
    memory = {-1: 0, 0: bit}
    head = 0
    trace = []
    for _ in range(steps):
        require(head in memory, 'Read outside the two-cell contract')
        before = state, head, memory.copy()
        w, direction, state = T[state, memory[head]]
        memory[head] = w
        head += direction
        trace.append({'before': before, 'after': [state, head, memory.copy()]})
    return (state, head, memory), trace

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-table', type=Path,
                        default=PARENT / 'machine/u212.native.tm')
    parser.add_argument('--baseline-source', type=Path,
                        default=PARENT / 'baseline/primary_u213/machine/sites.json')
    parser.add_argument('--rotated-table', type=Path,
                        default=ROOT / 'machine/rotated212.native.tm')
    parser.add_argument('--candidate-table', type=Path,
                        default=ROOT / 'machine/u211.native.tm')
    parser.add_argument('--candidate-source', type=Path,
                        default=ROOT / 'source/sites.json')
    parser.add_argument('--recipe', type=Path,
                        default=ROOT / 'construction/recipe.json')
    parser.add_argument('--output', type=Path,
                        default=ROOT / 'build/independent_check.json')
    args = parser.parse_args()
    baseline = table(args.baseline_table)
    sites = json.loads(args.baseline_source.read_text())
    recipe = json.loads(args.recipe.read_text())
    initial_graph = graph(sites)
    current = dict(baseline)
    stages = []
    for i, rotation in enumerate(recipe['rotations']):
        q, r = rotation['q'], rotation['r']
        require(rotation['side'] == 0, 'Unexpected rotation direction')
        require(current[q, 0] == (0, 1, r), 'Outer row differs')
        require([(x, b) for (x, b), a in current.items() if a[2] == r] == [(q, 0)],
                'Inner state has additional incoming edge')
        for state in (q, r):
            for b in (0, 1):
                require(current[state, b][:2] == (b, 1), 'Impure rotation')
        left = current[r, 0][2]
        middle = current[r, 1][2]
        right = current[q, 1][2]
        current[q, 0] = 0, 1, left
        current[q, 1] = 1, 1, r
        current[r, 0] = 0, 1, middle
        current[r, 1] = 1, 1, right
        sites = rotate_source(sites, rotation['paths'])
        require(graph(sites) == initial_graph, 'Source ordinal transition changed')
        stages.append({'index': i + 1, 'outer': q, 'inner': r,
                       'factors': [left, middle, right], 'ordinal_cfg_preserved': True})
    require(current == table(args.rotated_table), 'Rotated table mismatch')
    require(sites == json.loads(args.candidate_source.read_text()),
            'Rotated source mismatch')
    incoming = [(q, b, *a) for (q, b), a in sorted(current.items()) if a[2] == 218]
    require(incoming == [(158, 0, 0, 1, 218), (163, 0, 0, 1, 218),
                         (211, 0, 0, 1, 218), (216, 0, 0, 1, 218)],
            'Wrong complete incoming-edge list')
    candidate = {(q, b): (w, d, 157 if z == 218 else z)
                 for (q, b), (w, d, z) in current.items() if q != 218}
    require(candidate == table(args.candidate_table), 'Fold table mismatch')
    require(len(candidate) == 422, 'Not 211 working states')
    paths = []
    for b in (0, 1):
        old, old_trace = local(current, 218, b, 1)
        new, new_trace = local(candidate, 157, b, 3)
        require(old == new, 'Fold endpoint differs')
        paths.append({'input': {-1: 0, 0: b}, 'old': old_trace, 'new': new_trace})
    old_start = run_prefix(baseline, 48140)
    new_start = run_prefix(candidate, 48140)
    require(old_start == new_start, 'Complete bootstrap differs')
    state, head, ones, used = new_start
    require((state, head, len(ones)) == (84, -2, 120), 'Bootstrap calibration differs')
    changed = {key for key in candidate if candidate[key] != baseline[key]}
    require(not (used & changed), 'Edited bootstrap row')
    require(len(changed) == 19, 'Wrong number of retained-row changes')
    require(sites[136] == ['001100110101010', 'CI', 1], 'Startup ordinal differs')
    reached, pending = set(), [0]
    while pending:
        q = pending.pop()
        if q == 254 or q in reached:
            continue
        reached.add(q)
        pending.extend(candidate[q, b][2] for b in (0, 1))
    require(reached == {q for q, b in candidate}, 'Unreachable working state')
    result = {
        'status': 'PASS', 'states': 211, 'rows': 422,
        'table_sha256': hashlib.sha256(args.candidate_table.read_bytes()).hexdigest(),
        'source_sites': len(sites), 'source_transitions': sum(len(x[2]) for x in initial_graph),
        'source_guard_cases_including_halt': sum(max(1, len(x[2])) for x in initial_graph),
        'changed_retained_rows': len(changed), 'graph_reachable_states': len(reached),
        'rotations': stages, 'incoming_218': incoming, 'fold_paths': paths,
        'startup': {'steps': 48140, 'state': state, 'head': head, 'ones': len(ones),
                    'address': sites[136][0], 'ordinal': 136,
                    'edited_row_visits': 0},
        'proof_scope': 'Finite literal construction, full ordinal CFG equality at every stage, '
                       'whole-tape two-cell fold, exact blank startup. Universal runtime '
                       'and inherited Con(PA) calibration are separate obligations.'}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('rotations', 'fold_paths')}, indent=2))

if __name__ == '__main__':
    main()
