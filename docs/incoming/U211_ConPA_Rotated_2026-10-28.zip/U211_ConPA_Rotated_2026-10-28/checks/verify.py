"""Offline verification. --full also regenerates all universal runtime cases."""
import argparse
import gzip
import json
import subprocess
import sys
import time
from common import ROOT, require, load_table, digest, dump
from common import NATIVE_SHA, DENSE_SHA, NEW_SOURCE_SHA
import rebuild

def run(arguments):
    command = [sys.executable, *map(str, arguments)]
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    if result.returncode:
        print(result.stdout, result.stderr, file=sys.stderr)
        raise RuntimeError('Failed: '+' '.join(command))
    return result.stdout

def controls():
    from independent_check import local
    old = load_table(ROOT / 'machine/rotated212.native.tm')
    new = load_table(ROOT / 'machine/u211.native.tm')
    # A wrong write in a reused helper must destroy the exact tape identity.
    changed = dict(new)
    changed[67, 0] = (1, *changed[67, 0][1:])
    require(local(old, 218, 0, 1)[0] != local(changed, 157, 0, 3)[0],
            'Wrong-write control was not detected')
    # The replacement fails with a predecessor 1: the marker premise is essential.
    def trace(table, state, current, steps):
        head = 0
        tape = {-1: 1, 0: current}
        for _ in range(steps):
            require(head in tape, 'Unspecified exterior in control')
            w, d, state = table[state, tape[head]]
            tape[head] = w; head += d
        return state, head, tape
    require(trace(old, 218, 0, 1) != trace(new, 157, 0, 3),
            'False predecessor premise was not detected')
    return dict(wrong_helper_write_rejected=True, predecessor_one_rejected=True)

def runtime_summary(report_path, cases_path):
    report = json.loads(report_path.read_text())
    cases = json.loads(cases_path.read_text())
    require(report['status'] == 'NATIVE_UNIVERSAL_MATHEMATICAL_PASS', 'Runtime failure')
    require(report['table_sha256'] == NATIVE_SHA and
            report['sites_sha256'] == NEW_SOURCE_SHA, 'Runtime bound to wrong inputs')
    require(len(cases) == report['cases'] == 5084, 'Runtime coverage')
    source = json.loads((ROOT / 'source/sites.json').read_text())
    expected = {(i, positive) for i, (_, op, _) in enumerate(source)
                for positive in ((False, True) if op == 'CD' else (False,))}
    require({(x['site_index'], x['positive']) for x in cases} == expected,
            'Guarded case inventory')
    used = {tuple(row) for case in cases for row in case['rows']}
    for block in report['blocks']:
        for event in block['trace']:
            if event[0] != 'list':
                used.add(tuple(event[1][:2]))
    require(used == set(load_table(ROOT / 'machine/u211.native.tm')), 'Literal row coverage')
    require(all(case['duration'][0] > 0 and all(v >= 0 for v in case['duration'])
                for case in cases), 'Nonpositive or unbounded-sign primitive duration')
    return dict(cases=len(cases), literal_rows_covered=len(used),
                symbolic_steps=sum(c['symbolic_steps'] for c in cases),
                minimum_duration_constant=min(c['duration'][0] for c in cases),
                runtime_seconds=report['seconds'])

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true')
    args = parser.parse_args()
    if args.full:
        require(__debug__ and not sys.flags.optimize, 'Full runtime requires enabled assertions')
    began = time.monotonic()
    baseline = rebuild.main()
    args_independent = [ROOT / 'checks/independent_check.py',
        '--baseline-table', baseline / 'machine/u212.native.tm',
        '--baseline-source', baseline / 'baseline/primary_u213/machine/sites.json',
        '--rotated-table', ROOT / 'machine/rotated212.native.tm',
        '--candidate-table', ROOT / 'machine/u211.native.tm',
        '--candidate-source', ROOT / 'source/sites.json',
        '--recipe', ROOT / 'construction/recipe.json',
        '--output', ROOT / 'build/independent_check.json']
    run(args_independent)
    run(['-O', *args_independent])
    run([ROOT / 'checks/source_startup_check.py'])
    run([ROOT / 'checks/check_engine.py'])
    mutation_controls = controls()
    require(digest(ROOT / 'machine/u211.tm') == DENSE_SHA, 'Dense table hash')
    result = dict(status='FINITE_AND_PROVENANCE_PASS', states=211, rows=422,
                  fresh_full_runtime=False, controls=mutation_controls,
                  native_sha256=NATIVE_SHA, dense_sha256=DENSE_SHA,
                  source_sha256=NEW_SOURCE_SHA)
    if args.full:
        path = ROOT / 'build/runtime.json'
        print('Regenerating all 5,084 symbolic runtime cases...', flush=True)
        runtime_log = run([ROOT / 'checks/native56/check_runtime.py',
                          '--table', ROOT / 'machine/u211.native.tm',
                          '--sites', ROOT / 'source/sites.json', '--output', path])
        (ROOT / 'build/runtime.log').write_text(runtime_log)
        result['runtime'] = runtime_summary(path, path.with_suffix('.cases.json'))
        # Compare with the sealed successful discovery cases, not only their hashes.
        with gzip.open(ROOT / 'evidence/discovery_runtime_cases.json.gz', 'rt') as stream:
            reference_cases = json.load(stream)
        require(json.loads(path.with_suffix('.cases.json').read_text()) == reference_cases,
                'Fresh runtime derivations differ from delivered discovery evidence')
        result.update(status='FULL_VERIFICATION_PASS', fresh_full_runtime=True,
                      exact_fresh_case_equality=True)
    result['seconds'] = time.monotonic()-began
    dump(ROOT / 'build/verification.json', result)
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
