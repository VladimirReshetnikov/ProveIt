# Comparison of the eight incoming U212 packets

## Main result

At repository commit `9d50bf3df8c9e14941b549945c4f8400172d81f4`, eight nominal U212 archives occur in `docs/incoming/`. Seven are complete ZIP files. Their primary native and dense tables are **byte-for-byte identical**. The eighth archive is truncated, but its 50 complete, size/CRC-verified prefix members include a README, builder, manifest and construction/runtime receipts identifying exactly the same patch and hashes. It is not an independently inspected complete machine.

Thus these are presentations of **one 212-state construction**, not eight independent constructions whose state savings can be added. Every packet deletes the same native state 112 from the same U213 parent.

| Original filename | Bytes | Inspection result |
| --- | ---: | --- |
| `U212_ConPA_Stacked_2026-10-28.zip` | 13,737,825 | Complete; table byte identity checked |
| `U212_ConPA_Stacked_2026-10-28 (1).zip` | 10,164,637 | Complete; table byte identity checked |
| `U212_ConPA_Stacked_2026-10-28 (2).zip` | 10,421,949 | Complete; table byte identity checked |
| `U212_ConPA_Stacked_2026-10-28 (3).zip` | 10,243,682 | Complete; table byte identity checked |
| `U212_ConPA_Stacked_2026-10-28 (4).zip` | 14,357,424 | Complete; table byte identity checked |
| `U212_ConPA_Stacked_2026-10-28 (5).zip` | 10,732,898 | Truncated; prefix metadata identifies the same machine |
| `U212_ConU_2026-10-29.zip` | 13,596,431 | Complete; table byte identity checked |
| `u212_combined_2026-10-29.zip` | 2,955,934 | Complete; table byte identity checked |

All archive bytes were downloaded at the pinned commit and verified against their Git blob SHA-1 identities. The exact common identities, computed directly on each complete table, are:

- Native table SHA-256: `386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4`.
- Dense table SHA-256: `c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e`.
- Shared source-sites SHA-256: `7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00`.

The common machine has 212 working states, 424 transitions, two symbols, one two-way infinite tape, a separate halt, start state and head coordinate zero, all-zero initial tape and only L/R moves. The common source has 3,909 primitive occurrences and 197 distinct subtrees.

## The common stack

Every packet selects the original `U213_ConPA_2026-10-28 (1).zip`, whose native table has SHA-256 `bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7`. This parent combines direct transfer with a seven-zero origin detector. It is then combined with the entry-bypass argument from `u213_from_u214_2026-10-28.zip`.

| Native row | U213 parent | U212 |
| --- | --- | --- |
| 180/read 1 | write 1, R, 172 | write 1, R, 211 |
| 172/read 0 | write 0, L, 112 | write 0, L, 67 |

Both rows sourced at native 112 are deleted. No other retained row changes. No source instruction or theory axiom changes. Native halt 254 becomes dense halt 212; native labels are inherited names rather than counts.

The older bypass donor calls its direct decoder 167. In the selected parent's allocation that role is 211, with rows `211 0 0 R 218` and `211 1 1 R 184`. Matching the semantic role, its literal rows and its incoming context is essential; copying label 167 would be invalid.

Four whole-tape path identities have old/new block lengths 2/2, 7/3, 7/3 and 4/2. After bypassing the one-writing entrance, the remaining entrance into 172 leaves zero immediately left of the head, allowing the return helper 112 to be eliminated. Complete incoming-edge inventories justify the invariant. Positive bounded block synchronization gives PA-formalizable halting equivalence with the exact parent, on all finite-support coded tapes from state 0, and the conditional time bound `T212 <= T213 <= 7*T212/3`.

## What differs among presentations

The packets differ in exposition, finite checkers, retained source material and unsuccessful searches. None contributes a different literal saving.

| Packet | Distinctive supporting material inspected |
| --- | --- |
| Stacked, no suffix | Separate readable local proof; partial-tape path checker and independent radius-three check; reports 12 builder and 36 helper mutation controls. |
| Stacked (1) | Report split into validation/calibration/reproduction sections; four-pattern proof and seven mutation controls; full source-runtime replay option. |
| Stacked (2) | 6,768-frame radius-two checkpoint check; separate path-endpoint checker; reports 24 semantic-helper and seven frame-check mutations; selected-parent full replay option. |
| Stacked (3) | Explicit stage-one intermediate table; four-case whole-tape proof; six mutation controls; complete source/runtime bindings. |
| Stacked (4) | Both original construction-input archives retained; 6,768-frame checker, independent paths and eight mutation controls; extensive failed local-rewrite searches. |
| Stacked (5), incomplete | Recoverable checker code and construction/runtime receipts; reports five mutation controls; recovered comparison note gives the most explicit rotation/bypass collision. |
| ConU | Positive stuttering simulations; finite checks under Python optimization; runtime explicitly rejects disabled assertions; detailed interior-startup and credit review. |
| Combined | Compact extracted dependency tree instead of repeated nested archives; 18-command replay including both complete 5,084-case runtime passes; convenient for further inspection. |

These counts describe the inspected supplied artifacts, not an independent rerun of every archived check by this comparison. Repeated runtime records are not independent proof-assistant certificates. The Python induction engines and inherited conventional consistency calibration remain explicit trust boundaries.

## Common initialization and proof dependencies

All packets share an interior startup, not the clean root of the older U214. After 48,140 literal transitions the blank run reaches native state 84, head -2, source ordinal 136, header coordinate 54 (distance 56), primary registers `(N,T,W,A,D,H,X,Y,L)=(1,0,13,0,0,1,0,0,1)`, and 43 spare registers each equal to one. The complete tape has 120 one-cells and zero exterior. Neither edited row appears in this prefix.

The inherited suffix builds nine theorem heads over unsafe tail 4. A conservative credit argument gives maximum deficit two starting from candidate 1, ensuring the unsafe tail is never exposed. A literal halting-equivalence reduction can inherit this calibration. A new source, address layout, header convention or startup must re-establish the affected conditions.

The common runtime receipts state 5,084 primitive contracts over arbitrary naturals and nonempty finite spare lists, 1,275,761 symbolic inference applications and all 424 literal rows covered. These are inductive symbolic contracts rather than bounded numerical input samples, but the checker remains ordinary Python. No packet includes a newly compiled end-to-end Lean, Rocq, MM0 or exported PA consistency endpoint. The separate K215/ZFC endpoint concerns its own fixed machine.

## Why earlier U213 ideas do not automatically stack again

The current packets preserve comparisons of eight genuinely different U213 predecessors:

- The two emitter-reallocation proposals both remove 167 with the same preceding-one reuse of 172. Their physical corrections differ, but their saving cannot be counted twice.
- The implication-antecedent-exchange proposal already removes 112. It cannot gain a second deletion of that state.
- The one-rotation proposal repurposes 112 as a live decoder, with targets 90 and 89 and incoming 78/read 1. Deleting it by the inherited numeric label would remove a different live role.
- The six-rotation and eight-rotation proposals use the preceding tape bit and helper 155 to merge other decoders. Their source reassociations overlap the helper now required by U212's external bypass.

The detailed transplant census in the recoverable `(5)` comparison note records the exact conflict. The first rotation of the six-rotation recipe maps old roles `(188,167)` to U212 `(163,211)`. Its premise requires inner state 211 to have only the source entrance 163/read 0, but the accepted bypass adds `180/read 1 -> 211`. For the eight-rotation recipe the first three mapped rotations are `(185,217)`, `(204,163)`, `(163,216)` and satisfy the local conditions. Its fourth again needs to repurpose 211, now entered both by 180/read 1 and 216/read 1. These particular transplants therefore fail their unique-inner-entry premise.

This does not prove that all multi-entry rotations fail. A new argument could retime the external entrance, reserve an equivalent helper elsewhere, or jointly redesign the roles. Such a change must be verified in the complete edited machine rather than by assuming two independently proved patches remain independent.

Shortening origin recognition is another distinct avenue. Static maximum zero-run counts alone do not justify it: source-counter arithmetic can create longer temporary zero runs. The prior packets contain failed primitive derivations and concrete examples for detector shortcuts. A successful six-zero construction needs a source-specific transient-tape argument and a correct blank startup.

## Prior negative searches and useful unexplored directions

The retained research includes direct state substitutions under fixed-window reachable-state overapproximations, local paths up to 63 transitions, all 44,521 ordered state/representative pairs in one search, 90 independently valid bypasses each followed by another fold search, and a multi-entrance deletion attempt for state 35. Other packets use radius-seven contexts, helper-path limits, bounded random source rotations and donor-recipe transplantation. None reports an accepted 211-state result.

These are bounded search outcomes, not lower bounds. The promising directions require something beyond repeating an identical local fold pass: joint helper changes; longer inductive scan identities; source reassociation that preserves the extra decoder entrance; or source-specific reachability invariants stronger than arbitrary-tape local context. Individually safe bypasses can still depend on helper paths invalidated by their combination.

## Exact diagnosis of archive (5)

`U212_ConPA_Stacked_2026-10-28 (5).zip` matches pinned Git blob SHA-1 `0485679faf40d6f7e94117400ae6cbf2d6c986cf`. It has no central-directory or end-of-central-directory signature. Parsing from its initial local header yields 50 complete members whose uncompressed lengths and CRC-32 values all verify. These complete members occupy bytes before offset 3,753,151. The next member is `inputs/direct_transfer_U213.zip`, declaring uncompressed length 9,506,973 but compressed length zero; its stream continues only to the file's truncated end at 10,732,898 bytes.

The recoverable early manifest lists later `machine/` and `paper/` members, but their complete bytes are not present. The recovered README and construction/runtime receipts identify the common hashes. This supports classifying the intended construction while keeping metadata identification separate from direct inspection of complete machine bytes. No missing bytes were invented or silently replaced from another packet.
