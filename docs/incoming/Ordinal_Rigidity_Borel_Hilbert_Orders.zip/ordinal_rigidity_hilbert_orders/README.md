# Ordinal Rigidity of Borel Hilbert Orders

**Canonical flags, exact oscillation ranks, Polish Presburger models, and omnific realizations**

Prepared for Vladimir Reshetnikov, 4 October 2026.
Research developed and written with ChatGPT. Unrefereed research draft.

## Reading the result

`article.pdf` is the compiled article. `article.tex` is its complete standalone
LaTeX source, with an internal bibliography; no separate BibTeX file is needed.

The central result is a classification of Borel translation-invariant total
orders on a separable real Hilbert space. Every such order comes from a unique
well-ordered orthonormal basis with countable ordinal index theta. The ordinal
controls additive isomorphism, embeddability, the canonical boundary flag, and
the exact oscillation rank theta + 1 of the positive cone's characteristic
function. All the cones are nevertheless simultaneously F_sigma and G_delta.

The article proves the category and flag lemmas in a more general real Polish
topological vector space, then develops the Hilbert classification, automatic
continuity and operator pivot forms, counterexamples to weaker regularity,
Polish Presburger models, and explicit additive omnific realizations. Nine
further research questions close the main text.

The repository already contains positive constructions for Glazer's Question 2.
This report does not claim that existence result as new. The older literature on
Hilbert and Schauder lexicographic cones is credited. In particular, the complete
2012 paper by Kucuk, Soyertem, and Kucuk was not accessible in this session, and
its broad representation claim must be compared with this report before making
an exclusive priority claim. No certified breakthrough or independent referee
review is claimed.

## Contents

- `article.pdf` — compiled research article.
- `article.tex` — complete editable LaTeX source, including bibliography.
- `verify.py` — exact finite diagnostics; Python standard library only.
- `verification_results.json` — the delivered test run and explicit scope limits.
- `PROOF_REVIEW.md` — argument-by-argument internal review and edge cases.
- `SOURCES.md` — source provenance, pinned repository snapshot, and audit limits.
- `build.sh` — run diagnostics and compile the PDF with three LaTeX passes.
- `BUILD_REPORT.json` — page count, compilation status, and artifact checks.
- `SHA256SUMS.txt` — checksums of the other delivered files.

## Rebuild

Requirements: Python 3.10 or newer, and a LaTeX distribution with pdfLaTeX and the
standard packages named in the source (including Latin Modern, AMS packages,
geometry, microtype, hyperref, bookmark, fancyhdr, enumitem and tabularx).

From this directory on a POSIX shell:

```sh
sh build.sh
```

On Windows or without a POSIX shell:

```text
python verify.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The exact diagnostic command can also be run alone:

```sh
python3 verify.py --output verification_results.json
```

The delivered run passed **136,562 explicit assertions** in seven families with
seed `231113699`. These are finite algebraic and perturbation tests. They do not
verify Baire category, infinite sums, transfinite recursion, Presburger quantifier
elimination, or the foundations of surreal normal forms. Those dependencies are
proved in the article or explicitly credited as classical inputs.

## Scope

All classification claims refer to the specified Hilbert-space family, not to
all Polish Presburger models. The topology transported to the omnific image is
not the inherited surreal order topology or the coefficient-product topology.
The package contains no Lean/Rocq formalization and was not independently
refereed. No contribution or endorsement by Elliot Glazer is implied.
