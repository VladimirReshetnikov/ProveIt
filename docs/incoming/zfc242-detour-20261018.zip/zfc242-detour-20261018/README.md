# Detour242: a 242-state machine for Con(ZFC)

This package supplies an exact **242-working-state binary, single-tape Turing
machine**, including initialization, and an ordinary proof that its halting
is equivalent to that of the pinned ProveIt Combined243 machine. Composing
with Combined243's maintained ordinary calibration gives

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halt}(M_{242})\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

The relative theorem is stronger than needed for blank input: it holds from
the common inherited start state 95 for every head position and every binary
tape. Its proof uses a structural tape invariant and a finite detour. No
consistency or source-reachability premise is needed for the new reduction.

**Main report:** `report.pdf`, with editable source `report.tex`. The report
prints the full canonical machine table and also develops an independent
**1,768-bit equational target**, reduced from a complete 2,324-bit packet.

The new binary theorem is an ordinary proof with executable finite
certificates. No new Lean/Rocq endpoint is claimed. The exact Combined243
predecessor has a relative Lean theorem, while its full Lean consistency
bridge remains open at the pinned revision. See `PROVENANCE.md` and
`reference/combined243/README.md` for that distinction.

## Machine convention

| Property | Canonical table | Inherited labels |
| --- | --- | --- |
| Working states | 0 through 241 | 242 retained states |
| Start state | 0 | 95 |
| Halt state, with no outgoing rows | 242 | 254 |
| Dispatcher | 86 | 96 |
| Binary transition rows | 484 | 484 |

The input tape is all zero; the initial head is at 0 on a tape indexed by the
integers. Every transition moves left or right. The separate terminal state
is excluded from the working-state count, following the baseline convention.
There is no external input, auxiliary tape, omitted initializer, or prewritten
program.

Each noncomment table line is `state read write direction next_state`.
The first comment specifies the start state. The canonical and inherited
tables are exactly related by `machine/renumbering.json`.

## The entire patch

Starting with the exact inherited Combined243 table, delete state 27 and
replace four retained rows:

| Row | Combined243 | Detour242 |
| --- | --- | --- |
| 15/0 | `0 R 21` | `0 L 32` |
| 18/0 | `0 L 27` | `0 L 15` |
| 47/0 | `0 L 27` | `0 L 15` |
| 65/0 | `0 L 27` | `0 L 15` |

Remove `27/0 = 0 L 32` and `27/1 = 1 R 39`. The remaining 480 retained
rows are unchanged. All these numbers are **inherited**, not canonical,
labels. `code/build_machine.py` reconstructs and byte-compares both complete
tables and the renumbering file.

## Why the patch preserves halting

In the old machine, every transition into any of states 15, 18, 47 and 65
writes zero and moves right. Thus each of those controls has a zero
immediately left of the head. The only transitions into state 27 move left
from states 18, 47 and 65, and therefore enter 27 on zero. The complete
incoming-row census proves these claims by induction from state 95 on
arbitrary tape. In particular, old row 27/1 is unreachable.

At old state 15 reading zero, both the current and immediately left cells
are zero. The old one-step action `0 R 21` is reproduced by three new steps:

```text
15/0: 0 L 32
32/0: 0 R 45
45/0: 0 R 21
```

They end at the same state and head and preserve the entire tape.
Map old state 27 to new state 15, leaving every other control fixed. Every
other admissible old transition is simulated by one new transition.
The old-side invariant must not be mistaken for an invariant at every new
visit to state 15: some such visits represent old state 27 and use the
ordinary one-step case.

After `n` old transitions, the aligned new time is exactly `n + 2*k`, where
`k` counts old 15/0 transitions among those `n` steps. All blocks have positive
length and no internal halt. Thus an old halt gives a new halt, and an
infinite old run gives arbitrarily long nonhalting new prefixes covering
every finite new time. This proves both halting directions. The ordinary
proof appears in `report.tex` and `proof/detour-proof.tex`.

## Actual verification results

| Check | Result |
| --- | --- |
| Exact table reconstruction | 242 states, 484 total rows; exact byte agreement |
| Local ordinary proof checker | Complete invariant census, 484 mapped one-step cases and one three-step case |
| Independent implementation audit | Same relative theorem and all canonical rows checked |
| Affine symbolic runtime | All 8,390 guarded source cases pass |
| Expanded symbolic runtime | All 8,390 cases; 2,314,880 symbolic rules; all 484 rows covered |
| Blank initialization | 407,979 transitions; two different interpreters agree on the whole tape |
| Finite literal fixtures | All 8,390 cases; 6,473,406 transitions; all 484 rows covered |
| Source loop rotation | Universal loop identity and surrounding control-flow correspondence replayed |
| Equational target | 1,768 bits; codec, transcription and universal Horn certificates pass |

The expanded runtime quantifies nine independent arbitrary natural
registers, an independent gap of at least 64, and an arbitrary nonempty finite
spare suffix. Its unary and finite-list accelerations are table-bound
induction lemmas. The finite fixtures supplement this argument; they do not
establish nonhalting.

The blank prefix reaches inherited dispatcher 96 (canonical 86), head -5,
marker -6, header 176, span 181, logical registers
`(3,0,0,0,3,0,0,0,0)`, and 167 spare blocks of value one. The entire tape has
exactly 351 one-cells and zero elsewhere. The old 407,967-step prefix visits
old 15/0 six times; the independently computed new prefix satisfies
`407979 = 407967 + 2*6`.

## Reproduce

With Python 3.12 and assertions enabled, from this directory:

```sh
python3 -B code/verify_all.py
python3 -B code/verify_all.py --expanded
```

The quick path took about six seconds in the construction environment. The
expanded replay took about six minutes. These are observations, not runtime
guarantees. All main checks use the Python standard library and the supplied
reference inputs; they need no network or solver. Fresh logs go to
`reproduced/` by default. Detailed and optional search commands are in
`REPRODUCING.md`.

```sh
make pdf
```

This rebuilds the report with `pdflatex`. The archive includes a rendered PDF.

## Package map

| Path | Contents |
| --- | --- |
| `machine/` | Exact tables, bijection, complete source leaf lists, LaTeX table |
| `code/` | Construction, local proof, independent audit, blank and runtime checks |
| `proof/` | Standalone local mathematical proof and independent review |
| `evidence/` | Actual successful records, input bindings, source rotation and metrics |
| `reference/` | Pinned predecessor and unchanged checker dependencies with notices |
| `research/equational1768/` | Exact alternative equations, complete packet, proof and verifier |
| `research/local-fold-search/` | Reproducible finite-window invariant and hybrid-fold search |
| `research/source-encodings/` | Bounded grammar, routing and initializer exploration |
| `research/rejected-scanner/` | Reproducible failing scanner-shortening experiment |
| `SHA256SUMS` | Hashes of all other delivered files |

Suggested ProveIt destination:
`Computability/BusyBeaver/Research/ZFC/candidate-detour242/`.

The equational target is a separate result. It saves 556 complete packet bits
(23.9243%) by eliminating definable membership, fusing the Boolean truth
constant with an existing source constant, and trading a variable slot for
an explicitly axiomatized alias. No binary state bound is inferred from
that packet; compilation and initialization remain to be charged.

No minimality, unconditional nonhalting, or two-sided independence from
mere consistency is claimed. The source calculus, original verification,
compiler, preceding reductions, and their attribution remain inherited.
