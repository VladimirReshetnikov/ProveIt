"""Exact longest common substrings of SLP words, with occurrence witnesses.

The cut-pair/periodic-extension framework follows Matsubara et al. (TCS 2009).
Our overlap construction uses dyadic prefix seeds and the existing AP matcher;
our equality backend has different costs from the paper's FM data structure.
All loops depend on grammar size or binary lengths, never expanded word length.
"""
from .compressed_match import MatchTable, _clip, _last
from .compressed_words import CompressedLimit


def adjacent_pairs(arena, nodes):
    """Exact directed signed bigrams: each occurs at some reachable rule cut."""
    pairs = set()
    for node in nodes:
        arena.tick()
        rule = arena.rules[node]
        if rule[0] == 'c':
            pairs.add((arena.last[rule[1]], arena.first[rule[2]]))
    arena.stats['adjacency_rules'] = arena.stats.get('adjacency_rules', 0)+len(nodes)
    return pairs


class CommonSubstring:
    def __init__(self, arena):
        self.arena, self.cache, self.cache_cells = arena, {}, 0

    def suffix(self, x, y):
        return self.arena.lcp(self.arena.inverse(x), self.arena.inverse(y))

    def overlaps(self, x, y):
        """Disjoint APs of positive k with suffix_k(x) == prefix_k(y)."""
        a = self.arena
        a.tick()
        if (x, y) in self.cache:
            return self.cache[x, y]
        nx, ny = a.lengths[x], a.lengths[y]
        limit, result = min(nx, ny), []
        if limit and a.uniform[x] and a.uniform[y]:
            if a.uniform[x] == a.uniform[y]:
                result = [(1, 1 if limit > 1 else 0, limit)]
        else:
            low = 1
            while low <= limit:
                a.tick()
                high = min(2*low-1, limit)
                seed = a.slice(y, 0, low)
                table = MatchTable(a, seed, x)
                for ap in table.local(seed, x, nx-high, nx):
                    a.tick()
                    start, step, count = ap
                    if count == 1:
                        if a.lcp(a.slice(x, start, nx), y) >= nx-start:
                            result.append((nx-start, 0, 1))
                        continue
                    # All starts occupy a span shorter than the seed. Their
                    # common step is therefore a period of the seed and run.
                    xend = start+step+a.lcp(a.slice(x, start, nx), a.slice(x, start+step, nx))
                    yend = step+a.lcp(y, a.slice(y, step, ny))
                    if xend == nx:
                        good = _clip(ap, nx-yend, nx-low)
                        if good is not None:
                            result.append((nx-_last(good), good[1], good[2]))
                    else:
                        # Only coincident departures from the common periodic
                        # word can continue through x's nonperiodic tail.
                        special = xend-yend
                        if (_clip(ap, special, special) is not None
                                and a.lcp(a.slice(x, special, nx), y) >= nx-special):
                            result.append((nx-special, 0, 1))
                low *= 2
        if self.cache_cells+len(result)+1 > a.max_nodes:
            raise CompressedLimit('compressed-LCS overlap cache allowance exhausted')
        self.cache[x, y] = result
        self.cache_cells += len(result)+1
        a.stats['lcs_overlap_aps'] = a.stats.get('lcs_overlap_aps', 0)+len(result)
        return result

    def extension(self, x, y, k):
        """Extend a checked overlap of x's left child and y's right child."""
        a = self.arena
        _, left, right = a.rules[x]
        _, other_left, other_right = a.rules[y]
        cut, other_cut = a.lengths[left], a.lengths[other_left]
        before = self.suffix(a.slice(left, 0, cut-k), other_left)
        after = a.lcp(right, a.slice(other_right, k, a.lengths[other_right]))
        a.stats['lcs_extensions'] = a.stats.get('lcs_extensions', 0)+1
        return k+before+after, cut-k-before, other_cut-before

    def critical(self, x, y, ap):
        """At most six AP members suffice to maximize the extension length."""
        a = self.arena
        start, step, count = ap
        if count == 1:
            return [start]
        _, left, right = a.rules[x]
        _, other_left, other_right = a.rules[y]
        ll, rr = a.lengths[left], a.lengths[right]
        ol, ore = a.lengths[other_left], a.lengths[other_right]
        tail = a.slice(left, ll-step, ll)
        head = a.slice(other_right, 0, step)
        e1 = a.lcp(right, a.power(tail, (rr+step-1)//step))
        e2 = step+self.suffix(a.slice(left, 0, ll-step), a.slice(left, step, ll))
        e3 = step+a.lcp(other_right, a.slice(other_right, step, ore))
        e4 = self.suffix(other_left, a.power(head, (ol+step-1)//step))
        indices = {0, count-1}
        for threshold in (e2-e4, e3-e1):
            q = (threshold-start)//step
            indices.update((max(0, min(count-1, q)), max(0, min(count-1, q+1))))
        a.tick(len(indices))
        return [start+i*step for i in sorted(indices)]

    def offsets(self, root):
        a, positions = self.arena, {root: 0}
        nodes = a._reachable([root])
        for node in reversed(nodes):
            a.tick()
            rule = a.rules[node]
            if rule[0] == 'c':
                left, right = rule[1:]
                for child, offset in ((left, positions[node]), (right, positions[node]+a.lengths[left])):
                    positions[child] = min(positions.get(child, offset), offset)
        return nodes, positions

    def shared_runs(self, nodes, common):
        """Maximum contiguous run using only the shared signed alphabet.

        Terminal ids encode signed letters uniquely within one arena. A letter
        outside common is a separator that no common substring can cross.
        """
        return self._runs(nodes, common, None, 'lcs_bound_nodes')

    def transition_runs(self, nodes, common, transitions):
        return self._runs(nodes, common, transitions, 'lcs_transition_bound_nodes')

    def _runs(self, nodes, common, transitions, counter):
        a, prefix, suffix, longest = self.arena, {}, {}, {}
        for node in nodes:
            a.tick()
            rule = a.rules[node]
            if rule[0] == 't':
                prefix[node] = suffix[node] = longest[node] = int(node in common)
            else:
                left, right = rule[1:]
                join = transitions is None or (a.last[left], a.first[right]) in transitions
                prefix[node] = prefix[left]+prefix[right] if join and prefix[left] == a.lengths[left] else prefix[left]
                suffix[node] = suffix[right]+suffix[left] if join and suffix[right] == a.lengths[right] else suffix[right]
                longest[node] = max(longest[left], longest[right], suffix[left]+prefix[right] if join else 0)
        a.stats[counter] = a.stats.get(counter, 0)+len(nodes)
        return longest

    def extensions(self, u, v):
        """Yield witnesses as soon as checked, so proved bounds can stop work."""
        a = self.arena
        yield self.extension(u, v, 0)
        for left, right, swapped in ((u, v, False), (v, u, True)):
            for ap in self.overlaps(a.rules[left][1], a.rules[right][2]):
                for k in self.critical(left, right, ap):
                    length, first, second = self.extension(left, right, k)
                    yield (length, second, first) if swapped else (length, first, second)

    def small_interval(self, node, start, stop):
        """Read only a caller-bounded seed or tail, without expanding its root."""
        a, result = self.arena, []
        pending = [(node, start, stop)]
        while pending:
            a.tick()
            current, lo, hi = pending.pop()
            if lo == hi:
                continue
            rule = a.rules[current]
            if rule[0] == 't':
                result.append(rule[1])
                continue
            left, right = rule[1:]
            cut = a.lengths[left]
            if hi > cut:
                pending.append((right, max(0, lo-cut), hi-cut))
            if lo < cut:
                pending.append((left, lo, min(hi, cut)))
        a.stats['lcs_seed_letters'] = a.stats.get('lcs_seed_letters', 0)+len(result)
        return result

    def periodic_prefix(self, root, pattern):
        """Exact LCP with an infinite periodic word, by a cycle automaton.

        A state is (grammar node, phase modulo len(pattern)); its value is
        the matching prefix length. There are at most g*len(pattern) states.
        The caller supplies a short explicit pattern, never a large expansion.
        """
        if not pattern:
            raise ValueError('periodic pattern must be nonempty')
        a, period, done = self.arena, len(pattern), {}
        pending = [(root, 0)]
        while pending:
            a.tick()
            node, phase = pending[-1]
            key = node, phase
            if key in done:
                pending.pop()
                continue
            if not node:
                value = 0
            else:
                rule = a.rules[node]
                if rule[0] == 't':
                    value = int(rule[1] == pattern[phase])
                else:
                    left, right = rule[1:]
                    first = left, phase
                    if first not in done:
                        pending.append(first)
                        continue
                    value = done[first]
                    if value == a.lengths[left]:
                        second = right, (phase+a.lengths[left]) % period
                        if second not in done:
                            pending.append(second)
                            continue
                        value += done[second]
            if len(done) >= a.max_nodes:
                raise CompressedLimit('compressed-LCS periodic state allowance exhausted')
            done[key] = value
            pending.pop()
        a.stats['lcs_periodic_states'] = a.stats.get('lcs_periodic_states', 0)+len(done)
        return done[root, 0]

    def near_prefix(self, x, y, prefix, limit, max_alignments=32):
        """Certify nearly full LCS queries using bounded short-shift tests.

        prefix must be the exact common-prefix length and smaller than limit.
        Return None if its two suffix deficits leave too many alignments.
        Otherwise every possible improvement crosses a cut in a short prefix;
        self-comparison of the shared long prefix reduces to small-period
        automata, followed by bounded explicit tail comparisons.
        """
        a = self.arena
        nx, ny = a.lengths[x], a.lengths[y]
        dx, dy = nx-prefix, ny-prefix
        count = dx+dy-1
        if count > max_alignments or prefix < count-1 or min(dx, dy) < 1:
            return None
        a.tick()
        a.stats['lcs_near_prefix_queries'] = a.stats.get('lcs_near_prefix_queries', 0)+1
        head = self.small_interval(x, 0, count-1)
        tail_start = max(0, prefix-count)
        xt = self.small_interval(x, tail_start, nx)
        yt = self.small_interval(y, tail_start, ny)
        cut, best = dx-1, (prefix, 0, 0)
        for delta in range(1-dx, dy):
            a.tick()
            a.stats['lcs_near_prefix_alignments'] = a.stats.get('lcs_near_prefix_alignments', 0)+1
            other = cut+delta
            before = 0
            while before < min(cut, other):
                a.tick()
                if head[cut-before-1] != head[other-before-1]:
                    break
                before += 1
            if not delta:
                after = prefix-cut
            else:
                low, high = min(cut, other), max(cut, other)
                period = high-low
                word = a.slice(x, low, prefix)
                extent = self.periodic_prefix(word, head[low:high])
                after = extent-period
                if extent == prefix-low:
                    # The larger coordinate has reached the shared prefix's
                    # end. All remaining candidate letters lie in short tails.
                    remaining = min(nx-cut, ny-other)
                    while after < remaining:
                        a.tick()
                        if xt[cut+after-tail_start] != yt[other+after-tail_start]:
                            break
                        after += 1
            length = before+after
            if length > best[0]:
                best = min(length, limit), cut-before, other-before
                if best[0] == limit:
                    break
        return best

    def longest(self, x, y, cap=None):
        """Return (min(LCS length, cap), x start, y start); empty uses (0,0,0)."""
        a = self.arena
        if cap is not None and (type(cap) is not int or cap < 0):
            raise ValueError('common substring cap must be a nonnegative integer')
        limit = min(a.lengths[x], a.lengths[y])
        if cap is not None:
            limit = min(limit, cap)
        a.tick()
        if not limit:
            return 0, 0, 0
        prefix = a.lcp(x, y, limit)
        best = prefix, 0, 0
        if prefix == limit:
            return best
        xn, xp = self.offsets(x)
        yn, yp = self.offsets(y)
        xt = {n for n in xn if a.rules[n][0] == 't'}
        yt = {n for n in yn if a.rules[n][0] == 't'}
        common = xt & yt
        if not common:
            return 0, 0, 0
        xb = self.shared_runs(xn, common) if common != xt else a.lengths
        yb = self.shared_runs(yn, common) if common != yt else a.lengths
        limit = min(limit, xb[x], yb[y])
        if not best[0]:
            terminal = min(common)
            best = 1, xp[terminal], yp[terminal]
        if best[0] == limit:
            a.stats['lcs_bound_stops'] = a.stats.get('lcs_bound_stops', 0)+1
            return best
        xe, ye = adjacent_pairs(a, xn), adjacent_pairs(a, yn)
        transitions = xe & ye
        if transitions != xe:
            xb = self.transition_runs(xn, common, transitions)
        if transitions != ye:
            yb = self.transition_runs(yn, common, transitions)
        limit = min(limit, xb[x], yb[y])
        if best[0] == limit:
            a.stats['lcs_transition_stops'] = a.stats.get('lcs_transition_stops', 0)+1
            return best
        near = self.near_prefix(x, y, prefix, limit)
        if near is not None:
            a.stats['lcs_near_prefix_stops'] = a.stats.get('lcs_near_prefix_stops', 0)+1
            return near
        xs = sorted((n for n in xn if a.rules[n][0] == 'c'), key=lambda n: -xb[n])
        ys = sorted((n for n in yn if a.rules[n][0] == 'c'), key=lambda n: -yb[n])
        for u in xs:
            if xb[u] <= best[0]:
                break
            for v in ys:
                a.tick()
                if yb[v] <= best[0]:
                    break
                a.stats['lcs_cut_pairs'] = a.stats.get('lcs_cut_pairs', 0)+1
                pair_limit = min(xb[u], yb[v], limit)
                for length, first, second in self.extensions(u, v):
                    if length > best[0]:
                        best = min(length, limit), xp[u]+first, yp[v]+second
                        if best[0] == limit:
                            return best
                    if best[0] >= pair_limit:
                        a.stats['lcs_pair_stops'] = a.stats.get('lcs_pair_stops', 0)+1
                        break
        return best


def longest_common_substring(arena, x, y, cap=None):
    return CommonSubstring(arena).longest(x, y, cap)
