TOWARD A SMALLER ZFC-CONSISTENCY MACHINE
Research report prepared for Vladimir Reshetnikov
16 October 2026
================================================

START HERE
----------

Open report.pdf for the complete 26-page research report. report.tex is its
self-contained LaTeX source. The target is a deterministic binary machine
on one two-way infinite blank tape, with fewer than 254 working states,
whose nonhalting is provably equivalent in ordinary ZFC to Con(ZFC).
The terminal state is separate; all initialization states count.

The report has three principal findings.

1. A public 253-state construction already exists in upstream PR 20:
   https://github.com/jeff87654/busy-beaver/pull/20
   The PR was open and unmerged when inspected. Its actual successful
   CI log records a complete 160-module Coq rebuild and recursive coqchk
   acceptance. This is prior work by mira-emmy building on Mira-Cult's
   254-state machine and Jeff's verification, not a new machine from
   this report.

2. The mixed local bound in seeded positive image closure can be replaced
   by a pure subset bound. The complete proof needs neither Extensionality
   nor the other set axioms for the schema equivalence. Adding
   Extensionality gives the intended ZF-without-Foundation-or-Choice
   calibration. The equality-free control retains member-profile
   congruence EC. This resolves the membership-arm deletion question in
   the supplied seeded-closure manuscript. The appendix provides exact,
   capture-safe three-label syntax and a collision counterexample.

3. Removing the shared initializer from the 253-state machine leaves a
   252-state runtime body accepted by all 8,391 existing Python symbolic
   instruction cases. It lacks a certified blank initializer. A finite
   certificate covers every possible unchanged blank start: within 44
   moves, 234 starts reach provably infinite blank-ray scans and the other
   18 reach a single configuration up to translation. That common orbit
   has old control state 96, head 0, and one-cells exactly at -1 and 3.
   Its consistency-search meaning remains unresolved. This is a precise
   next optimization target, not a complete 252-state solution.

READING GUIDE
-------------

Section 1    Source pins and outcome.
Section 2    The exact internal ZFC statement and proof-transport contract.
Section 3    What the existing 254- and 253-state proofs establish.
Section 4    Complete pure-subset compression theorem.
Section 5    Calibration to ordinary set theory and equality-free control.
Section 6    Variable collisions, safe enumeration, and target encoding.
Section 7    Reproduced formula-node costs.
Section 8    Machine audits and exact classification of 252 blank starts.
Section 9    Concrete construction and formalization proposal.
Section 10   Prioritized research questions and acceptance criteria.
Section 11   Artifact and verification boundaries.
Appendix A   Exact three-label wrapper, scopes, and countermodel.
References   Immutable primary-source links.

ARCHIVE CONTENTS
----------------

report.tex / report.pdf
    Complete manuscript and compiled report.

Makefile
    PDF build, standalone checks, and clean targets.

machines/zfc_254.tm
machines/zfc_253.tm
    Exact attributed benchmark tables, with published compact labels.
    These are existing machines. No completed new 252-state machine is
    supplied. engineering/bootstrap_search.py defines the precise
    experimental 252-state runtime body in the old labels.

code/verify_benchmarks.py
    Independent table/hash check, inference of the old-to-compact
    bijection, exact four-transition delta, and simulation of all 312,975
    moves of the 253 bootstrap. Compares the entire finite nonblank tape.

code/kernel_reduction.py
    Formula-node counts under the declared source-02 metric; finite
    factoring checks; singleton-switching and transitive-container tests
    on hereditarily finite bit codes; both collision counterexamples.
    These regressions are not finite models of the whole infinite theory.

results/
    Recorded, reproducible outputs of those two standalone checks.

engineering/
    Portable scripts, finite certificates, diagnostic search results,
    immutable upstream input manifest, fetcher, and separate README.

provenance/sources.json
    Requested commits; upstream pins; machine digests; exact PR head,
    tested merge, CI job and decoded-log digest; theorem scope; attribution.
    Upstream Coq sources and the CI log are linked but not bundled.

provenance/report_build.json
    Compilation and document-review metadata.

STATUS.json
    Explicit separation of mathematical results, finite computations,
    upstream verification, proposals, and missing certificates.

MANIFEST.sha256
    Integrity hashes for every other file in this archive.

STANDALONE REPRODUCTION
----------------------

Use Python 3.10 or later, with assertions enabled (do not pass -O).
These checks use only the standard library and need no network.
From this directory:

    python3 code/verify_benchmarks.py --out results/benchmark_verification.json
    python3 code/kernel_reduction.py --out results/kernel_reduction.json
    python3 engineering/blank_start_certificate.py --sources machines --output engineering/blank_start_certificate.json

Alternatively:

    make check

To verify the received files before changing any outputs:

    sha256sum -c MANIFEST.sha256

The third command recomputes the exact classification of all 252 blank
starts using the already bundled 254-state table, without fetching any
additional upstream inputs.

The mathematical proof is in the report. The scripts are transparent
finite checks supporting syntax and implementation claims; they do not
replace the proof or infer nonhalting from a simulation time limit.

EXTENDED ENGINEERING REPRODUCTION
--------------------------------

The two literal tables are already included above. The extended scripts
also need the pinned Prog254.v and symexec.py inputs. Their source manifest
gives immutable public URLs, exact byte lengths, and SHA-256 hashes.
From engineering/:

    python3 fetch_sources.py --output sources
    python3 fetch_sources.py --output sources --verify-only

The first command fetches and verifies the four manifest inputs. The
second verifies existing inputs offline. Read engineering/README.txt for
the audit commands and their precise scopes. Source fetching is separate
from executing the upstream affine design model. No Coq/Lean installation
is downloaded or invoked by these scripts.

The exact blank-start classification is inexpensive:

    python3 blank_start_certificate.py --sources sources --output blank_start_certificate.json

The 56,196-candidate redirection search and longer startup simulations
are optional diagnostics; their results are already recorded. They do
not prove global machine minimality or permanent startup failure.

BUILD THE PDF
-------------

Install a normal LaTeX distribution with latexmk and the common packages
listed in report.tex. The report has no external images or bibliography
processor dependency. From this directory:

    make pdf

or:

    latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

The supplied PDF was built with pdfTeX / TeX Live 2023 and visually
inspected. Rebuilding may change PDF metadata bytes and thus its digest.

VERIFICATION BOUNDARIES
-----------------------

The upstream 253-state endpoint is an external finite halting/refutation
equivalence. Its theorem named ZFC uses the package's ZFc+AC presentation;
the existing ZFCReg_equicons theorem supplies the full
Regularity-plus-Choice comparison by composition.

This archive does not supply:
  * a new complete 252-state blank-tape machine;
  * a compiled machine for the improved closure kernel;
  * a newly kernel-checked Lean proof of that kernel;
  * an exported arithmetized proof inside a fixed ordinary ZFC predicate;
  * a local rebuild of the full upstream Coq proof;
  * an unrestricted state lower bound or exhaustive global record census.

These boundaries are part of the concrete proposal. In particular, the
four saved formula nodes are not asserted to equal four saved TM states.

ATTRIBUTION
-----------

Mira-Cult designed the 254-state machine. Jeff (jeff87654) supplied its
subsequent Coq verification. mira-emmy submitted the 253-state reduction
and its proof in upstream PR 20. The supplied ProveIt closure dossier
contains the predecessor kernels and their reconciliation.

The new report proof, inspection scripts, and derived experiments are
separate from those upstream designs. The ProveIt import explicitly
excludes the upstream verification snapshot from its blanket MIT-0 grant;
no upstream-wide license was declared in the inspected source. This
archive preserves attribution for the literal benchmark data and does
not redistribute or relicense the complete upstream proof/compiler
packages. See provenance/sources.json for exact sources and notices.
