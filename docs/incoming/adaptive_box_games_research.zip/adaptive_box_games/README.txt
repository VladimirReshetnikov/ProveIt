ADAPTIVE BOX GAMES BEYOND CYLINDER MEASURABILITY
Exact extension laws and the atomic-diffuse boundary
Prepared for Vladimir Reshetnikov — October 4, 2026

CONTENTS

adaptive_box_games.pdf       Complete research article with proofs and references
adaptive_box_games.tex       Self-contained LaTeX source, including the exact figure
verify_finite.py             Exact finite verification program; standard library only
finite_results.json         Executed deterministic verification results
finite_checks_README.txt    Methods and scope of the finite checks
README.txt                  This guide

MAIN RESULTS

The article studies blind outputs on Q^I, where Q is a finite alphabet and
the box-label space I is standard Borel. Output maps are measurable for the
completion of the cylinder product probability. Their success events are
not assumed measurable.

1. Finite-team success events have explicitly computed measurable envelopes.
   These envelopes are described by feasible success patterns: internal
   targets have fixed outcomes, while players sharing one diffuse target
   must agree with a common choice of color.

2. All countably additive extensions to the finite success events are
   classified by measurable probability densities supported on those
   feasible patterns. The unconditional joint laws form a finite weighted
   sum of probability simplices, characterized by Hall inequalities.

3. If alpha is the total atomic mass of one blind player's target law, its
   success event has inner measure alpha/q and outer measure
   1 - (q-1)alpha/q. Every value in this interval is attainable by an
   extension. Success is measurable in the completed base exactly when
   alpha = 1. A nonuniform full-support finite-color version is included.

4. Classical completion regularity extends the sharp guaranteed-score bound
   floor(m/q) to full product-topology Borel and universally measurable
   outputs. This resolves those two clauses of Question 2 in the inspected
   ProveIt report, but leaves its Baire-property clause open.

5. The full finite extension theorem resolves Question 5 of that report.
   A probability-kernel version classifies countable teams. The sharp
   guaranteed lower asymptotic success density is 1/q.

REPOSITORY ANCHOR

ProveIt commit:
1afa38bf984377eb85a5569cf6376054994a17a5

Report:
SetTheory/Cardinals/docs/reports/ordinals-and-order-types/
measurable-box-games/article.tex

Title: Countable Information, Uncountably Many Boxes
Questions: Section 15, Q2 and Q5.

These are research questions of that repository report. They are not the
numbered questions of Glazer's Topological Tennenbaum paper. The connection
to Elliot Glazer is his authored box-game paper and dissertation.

STATUS

The article contains complete mathematical proofs, independent proof review,
and exact finite checks. Completion regularity, measure-extension machinery,
and finite random-set selection geometry are classical and are attributed.
The application-specific calculation is the envelope and atomic-mass analysis
for adaptive targets. Historical priority is not established.

The infinite results are not Lean/Rocq certified or externally refereed.
The finite computations do not verify the infinite measure proofs.
Glazer's unrestricted choiceless ZF problem is not resolved.
No repository files were modified.

BUILD THE PDF

Use a standard TeX Live installation with latexmk, amsmath, amsthm, lmodern,
geometry, microtype, booktabs, enumitem, xcolor, fancyhdr, titlesec,
tcolorbox, pgfplots, xurl, and hyperref. From this directory run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error adaptive_box_games.tex

The figure is drawn directly from the theorem's exact formulas in the source.
No external images, bibliography database, or network access are required.

RUN THE FINITE CHECKS

Use Python 3.9 or newer:

    python3 verify_finite.py > finite_results.json

All arithmetic is exact. The checks enumerate every blind binary output
on one, two, and three coordinates, every ordered triple on two coordinates,
several target-collision pattern sets, two rational law polytopes, and
15 specializations of the atomic-mass interval. The detailed companion
file explains what is checked and what is outside computational scope.

