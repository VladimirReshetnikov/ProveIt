# Canonical Diophantine Certificates for Causal Computation

**Exact commuting-block acceleration, quartic trace quotients, and the boundary of single-foldness**

Research report prepared for the ProveIt project, 30 September 2026.

## Main deliverable

`article.pdf` is the compiled mathematical article; `article.tex` is its self-contained source.
The article develops exact natural-witness polynomial representations for box-guarded
integer translations, including weighted Petri transitions and finite-control counter
instructions. Its main results are:

- an exact resource envelope for every serialization of an arbitrary repeated multiset;
- a single-fold quartic accelerator, exact also for existential serialization when the
  active actions commute as partial maps;
- a quartic whose entire natural root set bijects with executable causal trace classes
  at a fixed height bound;
- extensions to fixed phases and arbitrary repetition of fixed noncommuting loop bodies;
- rank/progress criteria for endpoint-level single-/finite-foldness;
- a precise equivalence separating a universal fixed-arity single-fold halting polynomial
  from the restricted constructions actually proved here.

“Single-fold” means at most one complete natural witness tuple per fixed parameter
instance. The causal-history polynomial can have several roots, one per genuine trace;
it removes duplicate interleaving schedules, not distinct histories.

## Files

| Path | Contents |
| --- | --- |
| `article.tex`, `article.pdf` | Full proofs, worked examples, counts, research questions, references |
| `code/causal_diophantine.py` | Exact semantics and four polynomial compiler entry points |
| `code/verify.py` | Deterministic differential tests and example generation |
| `code/verify_exports.py` | Separate JSON coefficient checker; does not import the compiler |
| `code/demo.py` | Minimal executable 11-witness large-count example |
| `data/verification.json`, `data/verification.txt` | Recorded exact finite test results |
| `data/export_verification.json` | Separate exported-polynomial checks |
| `examples/shared_resource_accelerator.json` | 11-witness, 18-residual, 76-monomial quartic plus exact certificate |
| `examples/canonical_history.json` | 32-witness, 48-residual causal-history polynomial plus certificate |
| `SOURCE_AUDIT.md` | Pinned repository revision and source scope |
| `RESEARCH_STATUS.md` | Novelty, verification, and scope qualifications |

## Run

Python 3.10 or later; no third-party Python packages are needed.

```sh
python code/demo.py
python code/verify.py
python code/verify_exports.py
```

The recorded run used Python 3.13.5. Both verification scripts terminate with an exception
on a failed check. The main randomized suite is deterministic, with seed 20260930.
Running it overwrites the generated example JSON and test reports, not the article or code.
Elapsed runtime is environment-dependent; exact test counts should remain the same.

To rebuild the PDF, use a normal TeX installation with pdfLaTeX and the packages named
in the source. Three passes stabilize the contents and references:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

No external `.bib` file or ProveIt checkout is needed.

## Compiler interfaces

`compile_accelerator(actions)` represents **every serialization**. For commuting active
actions it also represents **some serialization**. Counts are parameters, not witnesses.

`compile_history(actions, height, pairs=None)` represents trace classes. The height is a
compiler parameter: it changes the arity. The optional independence relation must be a
subrelation of exact partial-map commutation; the default is the largest such relation.

`compile_blocks(phases, existential_counts=False)` represents a fixed ordered list of
commuting phases. Turning counts into witnesses preserves existence but needs extra
rank or progress hypotheses for single-/finite-fold endpoint claims.

`compile_word_power(actions, word)` represents a fixed, possibly noncommuting word
repeated `n_0` times. Empty execution domains are handled explicitly: only zero
repetitions are then allowed. `word_macro` exposes the exact compiled guard box.

Each `complete_*` function constructs the unique auxiliary completion for its supplied
semantic input. These functions are not general-purpose Diophantine equation solvers.
`System.check` requires a complete assignment with exactly the declared variable names.
All domains are nonnegative integers; residual subtraction is ordinary integer subtraction.

## Polynomial exchange format

The JSON lists parameters, witnesses, labelled residual polynomials, the expanded
sum-of-squares polynomial, and one exact natural certificate. A monomial is an integer
coefficient plus a list of variable names; repeated names are repeated factors. The
single polynomial is **the sum of the squares of all residuals**.

The history example's certificate is one of potentially several roots at its endpoints.
Adding the letter-count equations described in the paper selects the worked trace.

## Research status

This is an unrefereed research development, not a peer-reviewed publication or a
Lean-verified extension. Ordinary mathematical proofs are supplied; finite code tests
are additional checks, not their replacement. The derivations were developed for this
report, but a claim of world-first priority is not made. The general single-fold and
finite-fold MRDP principles are not resolved here. See `RESEARCH_STATUS.md` for detail.
