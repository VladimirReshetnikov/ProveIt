# Rational collapse and universal integrality for directed permutation avoidance

Research report prepared for Vladimir Reshetnikov, 3 October 2026.

## Main result

The article proves the rational-collapse conjecture `spf:conj:collapse` in
ProveIt's `a189281-path-forest-expansions/article.tex`, and proves a general
identity for every fixed pair of positive directed offsets r,s:

    R_h(n) = sum_{j=0}^h w_j * binom(h-r-s, h-j) / n^(fall h+j),
    w_j = (r-1)^(rise j) (s-1)^(rise j) / j!.

For r=s=2 this reduces, for every h>=4, to

    R_h(n) = 24 (n-h+1)^(fall h-4) / n^(fall 2h).

It follows that every inverse-power asymptotic correction coefficient,
and every coefficient in the full generating-function correction
polynomials, is an integer for every directed fixed-offset pair.
The article also proves a single-sum moment formula, an exact eventual
degree law, an entire Borel-transform representation, and an explicit
Lambert-W index reconstruction formula.

## Scope

This is an unrefereed mathematical research draft, not a machine-formalized
proof or an exhaustive historical priority assessment. The original
order-eight, degree-eleven recurrence for the finite A189281 sequence is
NOT proved or assumed. The auxiliary recurrence in this package concerns
inverse-factorial asymptotic coefficients, not the original counts.
The absolute-difference model is not covered by the integrality theorem.
Stable rational moments equal actual moments only in the stated stability
range. Formal hypergeometric and inverse-factorial series are not asserted
to converge. An entire Borel transform does not establish Laplace summability.

## Contents

- `article.tex`, `article.pdf`: the complete article, proofs, references,
  source/novelty ledger, and ten proposed further research projects.
- `code/verify.py`: independent exact finite checks and coefficient generation.
- `code/certify.py`: rational Bonferroni probability and residual certificates.
- `code/inverse_demo.py`: optional numerical, non-certified inverse diagnostics.
- `data/coefficients.json`: full A189281 B_J polynomials, c_J and d_J for
  J=0,...,100; examples for other offset pairs; test counts.
- `data/verification.txt`: executed exact-test receipt.
- `data/b189281_0_30.txt`: credited OEIS b-file excerpt used only as a test target.
- `data/bonferroni.json`, `data/bonferroni.txt`: exact rational endpoints and
  outward-rounded decimal summaries.
- `data/inverse_diagnostics.json`: optional numerical diagnostics.
- `SOURCES.md`: sources inspected and relationship to earlier work.
- `OEIS_proposed_note.md`: an unsubmitted draft note for possible use after review.
- `Makefile`: compilation and test commands.

## Reproduce the exact computations

Python 3.10 or newer; no third-party dependencies for these two commands:

    python3 code/verify.py --order 100 --identity-order 16
    python3 code/certify.py

Run without Python's `-O` flag: the tests use assertions. Both scripts
regenerate data relative to their own location, so the working directory
does not affect output paths. Increasing `--identity-order` adds finite
checks, not a substitute for the arbitrary-order proofs.

The recorded run passed 153 polynomial identities, 81 full histogram
comparisons, 190 stable-moment comparisons, 31 OEIS-value comparisons,
95 auxiliary recurrence equations, 100 Stirling-transform comparisons,
and 178 sharp-degree checks. It also checked the A189281 product identity
for h=4,...,16 and the first seventeen previously computed coefficients.

`B_polynomials[J][h]` is the coefficient of u^h in B_J; coefficients are
stored in ascending powers and trailing zeros are removed. `avoidance_coefficients`
contains c_J=B_J(-1). `inverse_falling_factorial_coefficients` contains d_J.
All these numbers are exact integers. The elapsed-time field is diagnostic
and naturally varies across runs.

The optional inverse diagnostic requires mpmath:

    python3 code/inverse_demo.py

It is not part of the exact verifier and does not certify finite-index rounding.

## Build the PDF

A normal TeX Live installation with the packages listed in the preamble is
sufficient. The source uses standard Latin Modern fonts; no font files are
included. Run `make pdf`, or run pdflatex three times:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

## Interpretation of the proofs and checks

The beta-integral step computes only a finite Taylor jet, with an explicit
endpoint and differentiation argument. The arbitrary-order rational
identity is then proved by an alternating Vandermonde identity. The
asymptotic theorem has its own uniform tail argument. No guessed recurrence,
external numerical fit, or OEIS table is a logical dependency of these proofs.
