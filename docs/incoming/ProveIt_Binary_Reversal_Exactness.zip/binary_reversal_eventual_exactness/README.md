# Eventual Exactness in Binary DFAO Reversal

**Balanced coprime cycles, a uniform quartic threshold, and rank-sensitive obstructions**  
Research draft prepared for Vladimir Reshetnikov, 28 September 2026.

## Main results

Let R_2(n,k) be the maximum reversal state complexity for minimal accessible
n-state binary-input DFAOs using exactly k outputs. Let P_k(a,b) count proper
k-colorings of the complete bipartite graph K_(a,b). The article proves

    R_2(n,k) = k^n - P_k(a_n,b_n) + a_n b_n

for every k >= 4 and n >= N(k), where N(k) is explicitly defined by integer
inequalities and N(k) <= 3 k^4. The split (a_n,b_n) is the coprime split of n
nearest to equality:

- n odd: ((n-1)/2, (n+1)/2);
- n divisible by 4: (n/2-1, n/2+1);
- n congruent to 2 modulo 4: (n/2-2, n/2+2).

Two independently implemented finite checks close all remaining cases for
4 <= k <= 7 and n >= max(7,k+1). The analytic thresholds for these four
output counts are 212, 240, 954, and 840, respectively.

Further results include strict bipartite balancing; necessary extremizer
structure, including singular-letter rank n-1; a matching-based hierarchy of
rank-sensitive upper bounds; a counterexample to sufficiency of the coarse
extremizer conditions; and exact exponential asymptotics of the optimal
deficit. Odd output counts have three distinct residue-dependent leading
constants, whereas even output counts have a constant leading coefficient.
The article ends with ten concrete research questions.

## Status and dependency boundary

The infinite upper-bound theorem has a conventional proof in the article.
Attainability imports Sylvie Davies's published coprime-cycle lower theorem,
arXiv:1705.07150v2, Theorem 3 and Corollary 3. The article does not reprove the
underlying two-generator monoid-generation theorem.

The portions below N(k) for k=4,5,6,7 are **computer-assisted**, supported by
an explicit graph reduction and exact integer comparisons. The programs are
not proof-assistant certificates. Neither the manuscript nor the programs
have been independently refereed or checked in Lean/Rocq.

This does NOT claim the full two-parameter conjecture for k>=8 below N(k),
the k=n boundary, or a necessary-and-sufficient classification of extremizers.
Historical priority beyond the inspected sources has not been established.
See `SOURCE_AUDIT.md` and `RESEARCH_STATUS.md`.

## Files

- `article.pdf`: the 22-page article.
- `article.tex`: complete editable LaTeX source with embedded bibliography.
- `code/theorem_checks.py`: primary exact structural comparison.
- `code/independent_check.py`: independently implemented comparison using
  positive Stirling sums, gcd-scanned splits, and a different order bound;
  does not import the primary implementation or read its result tables.
- `code/supplementary_checks.py`: small literal graph and coloring
  enumerations, formula regression tests, and the nonsaturating example.
- `results/finite_k*.csv`: per-row primary target deficits and strict margins.
- `results/primary_k*.json`, `results/independent.json`: verification summaries.
- `results/supplementary.json`, `results/rank_matching_enumerations.json`:
  supplementary check records.
- `results/thresholds.json`, `results/sample_values.csv`: exact formula data.
- `results/*console.txt`: recorded program outputs.
- `results/pdf_audit.json`: final document audit.
- `Makefile`: build, check, and clean targets.

## Reproduce the mathematics checks

Python 3.10 or newer; standard library only. No network connection or package
installation is required. Run from this directory:

```sh
python3 code/theorem_checks.py
python3 code/independent_check.py
python3 code/supplementary_checks.py
```

The two full-range programs each check 9,247,046 structural comparisons in
2,217 parameter rows. Each finds exactly one distinguished equality per row,
no unexpected equalities, and no failed comparisons. The independent program
also checks original-state minimality through the inequality that the attained
reverse complexity is larger than k^(n-1).

Failures raise exceptions; the checks do not rely on Python `assert` statements.
A rerun overwrites the corresponding generated result records. The finite
checks do not enumerate all n-state automata: the article proves why the
compressed graph comparisons suffice.

To test just one of the finite slices:

```sh
python3 code/theorem_checks.py --k 4
python3 code/independent_check.py --k 4
```

The recorded default results cover k=4,5,6,7. Extending the arguments to larger
k is mathematically permitted, but the required finite computation grows.
No unrun finite range is certified by this package.

## Build the PDF

A standard TeX Live installation with pdfLaTeX, latexmk, Latin Modern,
amsmath/amsthm, mathtools, microtype, booktabs, enumitem, fancyhdr, listings,
and hyperref is sufficient. The bibliography is embedded in the TeX file.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, run `pdflatex` three times. No external fonts, figures, or
bibliography processor are required. `make check` runs all three programs;
`make clean` removes TeX intermediates while preserving the PDF.
