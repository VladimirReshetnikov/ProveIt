# Two 222-state candidates for Con(ZFC)

This research packet constructs two distinct binary, single-tape Turing
machines with **222 working states**, including blank-tape initialization.
For each machine, the supplied ordinary mathematical argument establishes
in ZFC that its nonhalting is equivalent to `Con(ZFC)`. Both complete
transition tables and reproducible mathematical checks are included.

The baseline is ProveIt commit
`076445a2664854d817f8a938731dcacc290dcd7b` (inspected 20 October 2026 UTC).
The new result composes the existing conditional or repeated-witness K
root with the existing merged equality generator, then proves the
contracts of the resulting source and literal binary machine. It does
not claim priority for those predecessor logical ideas individually.

## Exact candidates

| Property | Conditional-G222 | Seed-request-G222 |
|---|---:|---:|
| Canonical table | `machines/conditional/candidate222.tm` | `machines/seed/candidate222.tm` |
| Working states | **222** | **222** |
| Transition rows | 444 | 444 |
| Start / halt target | 0 / 222 | 0 / 222 |
| Primitive source occurrences | 4,581 | 4,744 |
| Distinct source subtrees | 209 | 208 |
| Interior decoder roles | 186 | 185 |
| Contextual state aliases | 13 | 12 |
| State accounting | 49 + 186 − 13 = 222 | 49 + 185 − 12 = 222 |
| Maximum source depth | 38 | 36 |
| Maximum consecutive-zero address run | 6 | 6 |
| Unbounded guarded runtime cases | 5,956 | 6,167 |
| Symbolic runtime proof steps | 1,443,614 | 1,488,390 |
| Exact blank initialization transitions | 409,835 | 409,835 |

Both machines start with the head at the origin of a two-way infinite,
all-zero tape. The alphabet is `{0,1}`; every transition moves one cell
left or right. Working labels are 0 through 221. The halt target 222 is
separate and has no rows. No stationary move, preloaded input, omitted
initializer, or additional uncounted working state is used.

Each noncomment line in a `.tm` file is

```text
state read write direction next_state
```

The `#! start 0` header specifies the initial state. K-label and historical
label serializations are also supplied. Their halt target is 254; these
are exact relabelings, not different machines. Canonical tables and their
CSV versions are independently reconstructed by `code/check_machine.py`.

Canonical SHA-256 values:

```text
Conditional-G222:
60e21a040e58e2a2840b0f3d58ad3ee0e6ef4d0d5cdf1372d5a69355f1198ca1

Seed-request-G222:
3bcf4678c9c576ae99a108c32038f035b42204289267d05a34ba2b37b32b6476
```

## The mathematical idea

Let `d_ab` denote native equality, `Q_i A` universal quantification, and
`kappa(a,b) = R(a,b)` the native membership-formula code. The old equality
row and separate helper are

```text
d_ca -> (d_cb -> d_ab)
H(a,b) = d_ab -> Q_kappa(a,b) d_ab.
```

Replace the row with

```text
G(a,b,c) = d_ca -> (d_cb -> Q_kappa(a,b) d_ab)
```

and remove `H` from the nonlogical bundle. The retained logical rows prove
reflexivity from G, recover H, and then recover the old equality row.
The reverse implication is propositional composition. This proves exact
native deductive equivalence for **any unchanged K root**, including both
roots used here. The report supplies the uniform proof and its noncircular
propositional bridge; the executable finite certificates provide additional
checks of the proof templates.

At source level the new equality row costs 109 primitive occurrences,
while removing H and its conjunction operation saves 327. A closed source
reassociation preserves the complete control flow and repairs the maximum
zero run to six. For Conditional-G222, a 224-state intermediate admits two
certified folds. Seed-request-G222 has a separate fixed table delta with
two added states and three removed states relative to its 223-state parent.

The two parent theories have different ordinary consistency calibrations.
The conditional route uses a two-marker hereditary domain interpretation
to recover an internal empty object and the ordinary K root. The repeated
witness-request route reuses the existing reduction through K0. The native
adapters, low-code cases, coincident labels, matrix/private-code coupling,
and completeness from the actual nonzero search seed are documented, not
replaced by informal syntax assumptions.

## Reproduce the construction and checks

Requirements: Python 3.10 or later, standard library only. Run with
assertions enabled (do not use `-O` or `PYTHONOPTIMIZE`). No network access
or proof-assistant installation is needed for these checks.

From this directory:

```bash
python3 -B reproduce.py --output-dir ../K222-replay --full
```

Use an initially empty output directory outside the packet. The successful
full run ends with `FULL_K222_REPLAY_PASS` and writes `replay.json`, phase
logs, reconstructed tables and sources, and fresh runtime derivations.
The retained clean-run record is under `verification/`.

Without `--full`, the driver still checks the manifest, deterministic
construction, independent emitter binding, finite logic certificates,
fold proof, both exact initialization simulators, and the integrity and
coverage of the retained runtime receipts. It does **not** rederive the
unbounded runtime cases in that mode; the success label is
`QUICK_K222_REPLAY_PASS`.

The full runtime checks use literal transition identities, natural-number
induction over unary runs, and structural induction over arbitrary finite
spare tails. Register values, the extra gap, and spare values are unbounded.
Every nonhalting instruction must return the complete prescribed tape and
head position; halting instructions must reach halt. All 444 rows are
covered across the instruction contracts. The 4,000-step symbolic search
budget bounds proof search, not register values or actual TM duration.

Both independently coded blank simulators reach canonical dispatcher 22
after 409,835 transitions, with logical registers
`[3,0,0,0,3,0,0,0,0]`, 167 spare blocks of value 1, and exactly 351 one-cells.
The comparison is of the complete configuration, with every unlisted cell
zero. The retained proof-search completeness argument explicitly covers
this seed and its cutoff.

## Proof status

The endpoint is an **ordinary mathematical proof formalizable in ZFC**,
supported by executable exact checks and pinned predecessor calibrations.
This packet does not contain a new compiled Rocq or Lean theorem for
either 222-state table. In particular, Python success receipts are not
represented as proof-assistant kernel certificates.

The inspected repository identifies K225 as its smallest table with a
checked Rocq endpoint; K224 and the relevant K223 variants have ordinary
calibrations. The present logical transformations return to the exact
native parent theories. The underlying formal reference is Elliot
Glazer's K230 development at commit
`3142e4dd980f0be12f4abb636c4ae2528afc17eb`.

The asserted equivalence does not prove `Con(ZFC)`, does not assert a
PA-internal endpoint, and does not establish minimality. The unsuccessful
local searches in `code/search/` have explicitly bounded scopes; they are
not lower bounds on possible machine sizes.

## Files and report

| Path | Purpose |
|---|---|
| `report/main.pdf` | Complete report, including both transition tables |
| `report/*.tex` | Report source, generated metrics, and both full tables |
| `machines/` | Exact machine serializations, sources, and canonical maps |
| `code/construct*.py` | Deterministic constructions; no optimization search required |
| `code/check*emitter*.py` | Independent all-natural source/emitter binding |
| `code/support/` | Pinned source semantics, arithmetic macros, and fold tools |
| `code/logic/` | Finite G proof generator and independent checker |
| `code/runtime/` | Unbounded runtime and independent startup checkers |
| `code/search/` | Optional, explicitly scoped unsuccessful search artifacts |
| `evidence/` | Construction, emitter, fold, logic, runtime, and startup receipts |
| `theory/` | Detailed ordinary and native calibration arguments |
| `vendor/` | Frozen predecessor inputs, archives, licenses, and source pins |
| `verification/` | Fresh portable replay receipt and phase logs |
| `MANIFEST.json`, `SHA256SUMS` | Exact member sizes and SHA-256 hashes |
| `PROVENANCE.json`, `NOTICE.md`, `LICENSE` | Input provenance and attribution |

To regenerate the small LaTeX inputs and compile the report:

```bash
python3 -B code/generate_report_inputs.py
cd report
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The PDF uses standard TeX Live packages. Report compilation is separate
from the Python proof replay. The archive is ready for review and
incorporation into ProveIt; no remote repository modification is part of
this delivery. See `NOTICE.md` for inherited attribution.
