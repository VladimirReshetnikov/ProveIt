# Baire-Category Rigidity for Discretely Ordered Rings

**Beyond local compactness, without measurable multiplication**

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov,
3 October 2026. The PDF has 23 pages, including the cover and contents.

## Principal result

Let R be a discretely ordered ring (1 is the least positive element),
with a Hausdorff Baire additive-group topology. Suppose its strict positive
cone has the Baire property. Then there are |R| pairwise disjoint nonempty
open sets, and consequently

    cellularity(R) = density(R) = |R|.

If the topology satisfies the countable chain condition, R is countable
and the topology is discrete. In particular this applies to Polish
additive-group topologies. Multiplication need not be continuous,
measurable, or Borel; no induction scheme or local compactness is assumed.

The result answers the first research question in the earlier project
report *Local Compactness Forces Arithmetic Rigidity*. The new argument
also gives an ambient Haar-measurable version in locally compact groups.
It does not answer Glazer's separate question about ATR_0 or automatically
extend to every topology on a positive arithmetic monoid.

## Contents

- `article.pdf`: the complete typeset manuscript.
- `article.tex`: self-contained LaTeX source with embedded bibliography.
- `verify.py`: deterministic exact-arithmetic checks, using only Python's
  standard library.
- `verification_results.json`: output of the included run; 36,989 checks pass.
- `PROOF_AUDIT.md`: hypotheses, proof dependencies, and non-claims.
- `SOURCES.md`: source provenance, pinned repository revision, and limitations.
- `build.sh`: a clean PDF build recipe.
- `CHECKSUMS.sha256`: checksums for the other packaged files.

## Reproduce

Run the supplementary checks with Python 3.10 or later:

    python verify.py

Build the PDF on a system with `pdflatex` and the packages used in the
preamble (`newpx`, `tcolorbox`, `aliascnt`, `cleveref`, and standard LaTeX
packages):

    sh build.sh

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times. The bibliography is embedded; no BibTeX or network access is
required. Font files are not included.

## Proof status

The manuscript provides conventional mathematical proofs. Historical
priority has not been established, and the manuscript has not been
independently refereed. No new Lean or Rocq development is included or
claimed as checked. The exact tests concern finite polynomial algebra in
Z + t Q[t]; they do not establish Baire-category statements, uncountable
cardinal assertions, or arbitrary-ring theorems.

The formalization section specifies a small algebraic packing module,
a separate category module, and adapters to the relevant ProveIt
interfaces. The repository was read, not built or independently audited.
