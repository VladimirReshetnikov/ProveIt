# Sharp Affine Rigidity from Graph Additive Energy

**Cubic stability, target torsion, and exact non-affine extremizers**  
Research article prepared for Vladimir Reshetnikov, 6 October 2026.

The main deliverable is `article.pdf` (19 pages), with complete LaTeX source in
`article.tex`. It refines the exact-additivity endpoint adjacent to Lemma 6.2
of Gowers's *A new proof of Szemerédi's theorem*, and connects the result to
the high-correlation range of Proposition 6.1.

## Main proved statements

For finite abelian groups G and W, write N = |G|, let E(f) count **ordered**
additive quadruples respected by f (including repetitions), and set
ε = 1 − E(f)/N³. Let d(f) denote normalized Hamming distance from the affine maps.

* When W has no nonzero element of order two, a map differing from an affine
  map on a proportion t < 1/7 satisfies ε ≥ 4t − 10t² + 6t³. Equality, for
  t > 0, is exactly one nonzero error value on a subgroup coset.
* When W contains a nonzero element of order two, the sharp bound is
  ε ≥ 4t − 12t² + 8t³ for t < 1/3. Equality requires an order-two error value
  on a subgroup coset. This includes mixed targets such as Z/6Z.
* The stronger inequalities in Sections 4 and 5 separate the energy deficit
  of the error support from the dispersion and inversion asymmetry of its
  nonzero values.
* If ε < 1/9, the proximity hypothesis is unnecessary: d(f) is bounded by the
  inverse of the applicable cubic on [0,1/7], and the closest affine map is
  unique.
* For N ≥ 34, the largest non-affine energy is exactly
  N³ − 4N² + (10 + 2κ)N − (6 + 2κ), where κ is 1 precisely when W has a
  nonzero involution. All maximizers are one-point modifications of affine
  maps, with the stated restriction on the error value. A second proof
  establishes the same statement for all maps F_p^n → F_p^m, except that
  for p = 2, n = 1 every map is affine.

The article also gives an erasure/partial-domain extension, exact inverse-series
coefficients, an explicit Proposition 6.1 corollary, and nine research questions.
The error radii and the cutoff 34 are sufficient, not asserted optimal.

## Scope and status

The universal claims above have conventional mathematical proofs in the article.
The accompanying computations are independent finite consistency checks, not
substitutes for those proofs. The focused literature comparison does **not**
establish publication priority. No improved global Szemerédi bound, solution of
a previously named global open problem, or completed Lean formalization is
claimed. The majority-correction method and derivative-energy identities are
attributed to the relevant prior literature.

No repository files were changed. The repository discussion is based on the
specified Section 6 interface and relevant statement/proof excerpts, not on a
repo-wide audit. See `sources.json` for the pinned commit and blob identifiers.

## Package contents

| File | Purpose |
| --- | --- |
| `article.pdf` | Compiled 19-page article |
| `article.tex` | Complete source, including bibliography |
| `build.sh` | Run exact checks and compile the PDF |
| `checks/verify.py` | Standard-library Python verification program |
| `checks/verification_results.json` | Full recorded exact-arithmetic results |
| `checks/verification_log.txt` | Human-readable recorded verification output |
| `formalization_plan.md` | Proposed proof decomposition and repository interface |
| `sources.json` | Source provenance and primary literature |
| `validation.md` | Build and rendering checks performed on this package |

## Reproduction

Required: Python 3.9 or later and a standard pdfLaTeX installation with the
packages listed in the article preamble. No network access, external datasets,
or third-party Python packages are needed to run the checks.

On Linux/macOS or a compatible shell:

```sh
bash build.sh
```

On Windows, run the following commands from this directory, with Python and a
LaTeX distribution installed:

```text
python checks/verify.py --output checks/verification_results.json
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Do not run the verification program with Python's `-O` flag: it intentionally uses
assertions and rejects an optimized interpreter. A failing assertion causes a
nonzero exit status. The seeded tests are reproducible.

## Recorded computation coverage

The six exhaustive runs enumerate 17,682 affine-normalized functions representing
846,650 actual scalar-valued maps. Energy and distance to the affine class are
invariant under the normalizing symmetry. Every computed maximizer is checked
to be one point from an affine map.

There are also 4,976 sparse/error-value checks: 2,176 exhaustive two-point
labelings, 1,800 seeded odd-target examples, and 1,000 seeded examples with
even-order targets. Further checks cover three subgroup equality examples, an
explicit two-torsion counterexample to the odd-target formula, and exact
substitution of the first eight inverse-series coefficients.

All recorded exact assertions passed. No Lean build was run; no Lean executable
was available in the working environment. Third-party source PDFs and standalone
font files are not included.
