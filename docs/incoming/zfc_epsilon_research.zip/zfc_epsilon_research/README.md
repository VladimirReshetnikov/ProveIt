# Towards Smaller Consistency Machines

Research report for incorporation in ProveIt, 16 October 2026.

**No new calibrated blank-start binary machine below the attributed public
253-state construction is claimed.** The archive supplies a new complete
finite-certificate proposal, a kernel-checked correction to numerical
completeness, and reproducible state-reduction experiments.

Read **report.pdf** for the complete report. Its source is **report.tex**
and **sections/**.

## Main contribution

The proposed effectively generated propositional theory has two families:

1. Ground epsilon-critical formulas.
2. Epsilon expansions of the EPSC boundedness-to-hull wrapper, for native
   matrices with only x and y free.

Every parameter in the extracted term model is named by a closed epsilon
term. Thus the ground generator recovers full ordinary EPSC with arbitrary
finite parameter lists. The report proves in ordinary ZFC that some finite
generated family is Boolean-unsatisfiable iff ZFC is inconsistent, composing
with the explicitly cited EPSC consistency calibration. The specialized
EPSC2 parameter-packing theorem is sufficient but unnecessary for this final
grounded version.

The reference verifier reconstructs all axioms from certificate data and
checks finite Boolean unsatisfiability. It has no arbitrary-assumption or
claimed-conclusion field. A small register implementation, binary compiler
simulation and blank initializer remain to be constructed. No state count
for this frontend is supplied.

## Contents

| Directory | Role |
|---|---|
| epsilon/ | Primary verifier, typed syntax, substitution, codec, tests, sample DAGs and finite evidence |
| audit/ | Actual Lean diagnosis and repair, minimal repository patches, pinned source closure and build evidence |
| machine/ | New mixed fusions, enlarged pure-fold searches, controls, pinned sources and compressed complete logs |
| grammar/ | 11,200 grammar trial evaluations, selected DAGs, bidirectional register certificates |
| sources/ | Exact attributed source09 helpers used by grammar/ |
| sections/ | Complete report chapters and bibliography |

The baseline table is attributed to Mira-Cult, the public 253-state reduction
to mira-emmy, and the published verification to Jeff Ketchersid. The EPSC,
EPSC2, hereditary-saturation and earlier compiler work are inherited and
cited. The report distinguishes that work from new contributions.

## Source cutoff

- Final ProveIt audit: d74c63b0c8d4f35597f1bd5976d941b9f104f94e
  (2026-10-16, 22:04:08 UTC).
- Machine experiment parent: 6ec2e80dbbe45a99b7812fb5757977307959a51e.
- Merged upstream 254: 297ab8df7e5de329605c3875b4934643b371a5e3.
- Public 253 PR head: 0d544f2a2e3c18f12278441a74b7879f31cbe856.

Later concurrent repository changes are outside the audited claims.
All machine costs include the specified working-state convention; no
prepared-tape or runtime-only body is promoted as a blank-start result.

## Reproduce

The Python artifacts use only the standard library. Python 3.12 was used
for this investigation. Individual scripts also document their supported
versions. The report uses a normal TeX Live installation.

Verify the untouched archive first:

```sh
sha256sum -c SHA256SUMS
```

Build the PDF:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

Run the finite verifier tests and the short experiment replay:

```sh
python3 epsilon/test_epsilon_native.py
python3 machine/reproduce.py --quick
python3 grammar/verify_grammar.py
```

Run the full mixed-fusion affine search:

```sh
python3 machine/reproduce.py
```

Check the actual numerical completeness correction with Lean 4.32.0:

```sh
python3 audit/verify_empty_domain.py --lean /path/to/lean
```

The Lean driver rebuilds an 11-module source closure in a fresh temporary
directory, then checks the separate generic diagnostic. The full ProveIt
53-unit checker and upstream 160-module Coq closure were not rerun here.
The numerical source patch and build-list patch are supplied for review
against the frozen commit; no remote repository is changed.

Replays regenerate evidence and may update execution times, temporary paths
or result files, so run the integrity check before regeneration.
The grammar README records all five complete seeded search commands.

## Concrete experimental outcomes

- Public-table pure folds: all 63,756 ordered pairs at radius 4 / 64 steps
  and radius 6 / 128 steps; no sufficient local certificate.
- New mixed fusions: 50,086 candidates preserving the specified 55 protected
  action rows; no local certificate and no complete affine runtime survivor.
- Affine first failures include 45,443 fuel-limited candidates. Those cases
  remain unresolved by that checker.
- All 11,200 shared-grammar trial evaluations fail to improve the 202-node
  input decoder. Selected candidates have checked register equivalences,
  not binary-machine proofs.

Failures of these bounded checkers are not semantic lower bounds.

## Finite evidence is not a consistency proof

The report's mathematical model argument supplies the ordinary ZFC-level
calibration. Finite tests validate explicit code cases. The generic
unsatisfiable epsilon diagnostic uses additional assumptions and is
explicitly not an EPSC or ZFC refutation. The actual serialized examples
are valid but nonaccepting certificates.

The new Lean correction diagnoses an impossible empty-domain premise in
the original c254_complete, then proves a usable pointed-domain and an
equivalent nonempty-domain version. The corrected theorems depend only on
propext, Classical.choice, and Quot.sound. The diagnosis is axiom-free.

## Licensing and attribution

New report and code material is supplied under the MIT No Attribution
license in LICENSE. This grant does not relicense third-party inputs.
Vendored files retain their source manifests, notices and original terms;
no blanket license is inferred where an upstream source has none.
See audit/LICENSE.ProveIt and machine/source/LICENSE-ProveIt for the
ProveIt license. Exact upstream provenance is retained for Jeff's executor,
the machine tables, the register program, and the source09 helpers.

