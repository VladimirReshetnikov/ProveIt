# The Complete Increasing Spectral Core

**Arbitrary-radius classification, optimal order reduction, and fixed-point
spectra for polynomial iterative equations**

Research draft prepared for Vladimir Reshetnikov, 28 September 2026.

## Read the article

`article.pdf` is the 20-page article. `article.tex` is its complete, self-contained
LaTeX source. It needs no external figures or bibliography processor.

For a polynomial `P(z) = sum a_j z^j`, the notation `P[f]` means
`sum a_j f^{circ j}`: composition, not pointwise powers. The results concern
continuous increasing maps of the whole real line and real polynomials with
nonzero constant coefficient.

## Main results

Theorem 1.2 classifies **exact minimal iterative polynomials with arbitrary
root moduli**. Remove exactly one copy of `z-1`, when present. Except for the
identity case, the remaining spectrum must have its positive real root present
with maximal multiplicity on each extreme modulus circle. If only one circle
remains, that multiplicity must be odd. Interior-circle multiplicities are
unrestricted. These conditions are necessary and sufficient. Every permitted
spectrum has a globally bi-Lipschitz realization, analytic except possibly at
one fixed point.

Theorem 5.3 supplies an explicit root-level formula for the **smallest common
annihilator of all increasing solutions** of a prescribed equation. Whenever
solutions exist, one map attains that entire polynomial as its exact minimal
polynomial, witnessing the sharpness of all retained multiplicities at once.

Theorems 6.1, 7.3, and 7.4 give exact affine-rigidity, fixed-point-free
realizability, and fixed-point realizability criteria. Theorem 8.1 constructs,
for every positive integer m, an everywhere analytic fixed-point-free map with
minimal polynomial `(z-1/2)(z-2)(z^2+1)^m` and derivative between `1/6` and `6`.
Section 10 proposes ten further research projects and a staged Lean program.

## Repository connection and status

This extends the several-circle gap expressly left open in ProveIt's
`nonreal-roots-in-iterative-equations/article.tex`. The inspected source blob
was `ae6ea0aa0566316ba9ed06b1750c6e73275059da`; its full repository path and
bibliography appear in the article and `notes/source_audit.md`.

The package is an **unrefereed AI-assisted research draft**. The proofs are
written out, but are not certified in Lean or another proof assistant. The
finite checks below supplement the proofs; they do not certify the universal
analytic theorems. Historical priority has not been established by an
exhaustive literature review. No change was made to the user's repository.
See `STATUS.md` for the scope and verification boundaries.

## Reproduce the checks

Python 3.9 or later, standard library only:

```text
python code/verify.py
python code/example.py
```

The verifier writes `results/exact_checks.json` and `results/verification.txt`.
The recorded run checked 1,354 finite spectra and 97,281 candidate divisors,
two exact rational recurrence examples, and their nonzero Hankel determinants
`16384/9` and `225/256`. It also checked the displayed degree reduction 32 -> 23.

The implementation accepts **already factored spectra with Gaussian-rational
roots**. It does not factor arbitrary coefficient polynomials. All modulus
comparisons use exact rational squared moduli. Invalid multiplicities, zero
roots, and missing or asymmetric conjugate pairs are rejected.

## Rebuild the PDF

Use a LaTeX installation containing the packages named in the preamble
(standard TeX Live / MiKTeX packages):

```text
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The delivered PDF compiled without undefined references or overfull-box
warnings and was rendered for visual inspection. Rebuilding may update PDF
metadata and pagination depending on the TeX environment.

## Files

- `article.tex`, `article.pdf`: complete article and compiled output.
- `code/spectral_core.py`: exact root-level core and classification routines.
- `code/verify.py`: finite combinatorial and rational example checks.
- `code/example.py`: runnable order-32 to order-23 example.
- `results/`: recorded exact certificates and execution output.
- `STATUS.md`, `notes/source_audit.md`: claim boundaries and source record.
- `MANIFEST.sha256`: checksums of the delivered files, excluding the manifest itself.
