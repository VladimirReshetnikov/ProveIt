# Exact Gap Spectra of Ground-Model Surreal Fields

Research article prepared for Vladimir Reshetnikov, 28 September 2026.

## Files

- `article.tex`: standalone LaTeX source with an internal bibliography.
- `article.pdf`: compiled article.
- `code/check_finite.py`: finite checks for delimiter coding, sign cones, and
  coordinate-profile bookkeeping (Python 3 standard library only).
- `verification_results.json`: recorded finite-check output.
- `PROOF_STATUS.md`: assumptions, dependency boundaries, and review status.
- `Makefile`: reproducible build and check commands.

## Main results

The article proves an external-cofinality transport formula for fresh functions
and old-surreal gaps; computes the exact single-Cohen spectrum without GCH;
applies the published Fischer--Koelbing--Wohofsky Easton-product theorem to obtain
complete multicharacter spectra; and gives an isolated-coordinate localization
argument producing 2^theta pairwise nonisomorphic old fields in one universe.
The fields have the same saturation spectrum and prescribed distinct higher
gap profiles. Under Global Choice, they yield pairwise nonconjugate involutions
of one surcomplex field, with agreement on a common set-sized core.

The quotient construction computes designated isolated characters exactly.
It does NOT claim to compute every accumulation character in every intermediate
quotient. The article also does not claim that equal full gap spectra classify
old surreal fields.

## Build

A TeX Live installation with the standard AMS, New TX, geometry, microtype,
hyperref, cleveref, and supporting packages is sufficient. No BibTeX or network
access is required.

    make
    make check

Alternatively, run pdflatex three times on `article.tex`, and run:

    python3 code/check_finite.py --output verification_results.json

## Provenance and verification

Repository snapshot inspected:
`e21766d04c2b8a9b2cdba0cd43e563024b3bd1b9`

Repository: https://github.com/VladimirReshetnikov/ProveIt

The research target is Questions 19.2, 19.4, and 19.7, including the updated
status note, in:
`Algebra/SurrealNumbers/docs/foundations-and-computation/surreal-fields-across-universes/article.tex`

Written proofs are supplied. No independent referee review, Lean verification,
or certified priority claim is made. The existing fresh-sign correspondence is
reproved and credited; the published Easton-product theorem is imported and
credited. Finite tests do not validate any transfinite or forcing theorem.
No font files or third-party source manuscripts are included.
