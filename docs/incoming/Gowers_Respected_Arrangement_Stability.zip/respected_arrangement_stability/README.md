# Sharp High-Agreement Stability for Gowers's Respected Arrangements

**Full-product decoding, optimal error terms, and erasures**  
Research report prepared for Vladimir Reshetnikov, 6 October 2026.  
Mathematical development and exact computational checks with ChatGPT.

## Results

The article uses `s` for the number of vertical differences, so Gowers's
8-arrangements have `s = 16` and involve 32 point occurrences. Repetitions
and the zero increment are included.

* **A direct supplement to Lemma 12.3.** If there are `theta N^8` respected
  pairs of vertical parallelograms on a possibly partial domain, there are
  at least `max(theta^7, 4 theta - 3) N^32` respected eight-arrangements.
  These are ambient-normalized counts, not conditional fractions. The
  linear coefficient four at complete agreement is optimal. On full
  products the more general relation is `epsilon_4 <= epsilon_s <= (s/4) epsilon_4`.
* **High-agreement repair on arbitrary finite abelian products.** An
  `s`-difference failure rate `epsilon <= 1/(240(s-1))` implies distance
  at most
  `(1 - sqrt(1 - 8(s-1)epsilon/s))/(4(s-1))`
  to a model `a(x) + B(x,y) + ell(y)`, with arbitrary `a`, biadditive `B`,
  and homomorphic `ell`. The arbitrary row function is essential.
  The leading coefficient `1/s` and the next coefficient `2(s-1)/s^2`
  are sharp uniformly over finite abelian groups. The leading coefficient
  is also sharp in the common odd prime setting.
* **A sharp cubic and extensions.** For distance `delta <= 1/4`,
  `epsilon_4 >= 4 delta - 24 delta^2 + 32 delta^3`. An explicit binary
  row-defect family attains the full cubic. The article also proves the
  general local polynomial, retains the row-collision profile, and gives
  an erasure-robust extension.

For `s = 16`, repair starts with `epsilon/16 + 15 epsilon^2/128`, with
explicit threshold `epsilon <= 1/3600`. The manuscript contains twelve
further research questions, including the sharper odd-prime quadratic
coefficient, equality classification, sparse-domain mixing, and actual
propagation through the Gowers structural argument.

## Status and scope

The manuscript includes proofs; it is unrefereed and not Lean-verified.
Literature priority has not been established. The majority-correction
method is classical in origin and is credited in the article. The cycle
argument and all required correction lemmas are proved self-containedly.

The sparse-domain moment supplement is unconditional as stated, but the
**repair theorem requires a full or near-full product**. It does not
replace the general sparse restriction step of Lemmas 12.5--12.6. No new
global bound for progression-free sets, Szemeredi's theorem, or van der
Waerden numbers is claimed. Numerical activation thresholds and the
complete higher-order local envelope are not asserted optimal.

No theorem or proof ledger in ProveIt has been changed. Suggested location:

```
Combinatorics/Ramsey/Research/GowersSzemeredi/respected-arrangement-stability/
```

All LaTeX labels have prefix `ras:`. Macro and theorem-environment names
still require ordinary editorial reconciliation when merging sources.

## Files

`article.tex` and `article.pdf` are the main deliverables. `SOURCE_AUDIT.md`
records the pinned source crosswalk. `FORMALIZATION.md` gives proposed
proof obligations, not completed Lean code.

`code/arrangements.py` provides exact cyclic counting, exact nearest-model
decoding, partial-domain counting, and the extremal-family formulas.
`code/verify.py` is the main exact test suite;
`code/verify_erasures.py` tests erasure bookkeeping independently;
`code/polynomial_checks.py` checks the rational polynomial identities.
Recorded results and an input/output example are in `data/`.

## Reproduce

Python 3.10 or later, using the standard library only:

```sh
python code/verify.py --extended
python code/verify_erasures.py
python code/arrangements.py data/example.json --orders 4 16
```

The extended full-domain run exhausts **25,100** tables, checks **300**
additional seeded tables, and checks the binary and common-prime extremal
families. The erasure run exhausts **729** partial tables. All results use
integer counts and `fractions.Fraction`; no floating-point feasibility
solver is involved. The smallest full cases and every partial case at
`s=4` are also counted by literal enumeration. Corrupted model scores and
invalid inputs are rejected. These finite checks do not prove the general
theorems or constitute kernel verification.

To build the article:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Or use `make pdf`, `make check`, and `make example`. `make clean` removes
LaTeX intermediates but preserves the PDF. The bibliography is embedded
in the TeX file; no BibTeX pass is required.

## Programmatic interface

```python
import sys
sys.path.insert(0, "code")
from arrangements import decode, count, count_partial

phi = [[0, 1], [0, 0], [0, 0], [0, 0], [0, 0]]
model = decode(phi, q=2)
assert str(model.distance) == "1/10"
respected, total = count(phi, q=2, s=4)
assert (respected, total) == (3232, 4000)

partial = [[0, None], [0, 0], [0, 0]]
respected, valid, full_total = count_partial(partial, q=2, s=4)
# A conditional failure probability exists only when valid > 0.
```

The decoder solves the *full cyclic* nearest-model problem exactly. The
partial counter reports counts, not a claimed fast decoder on sparse
domains. JSON command-line input must be a full table with keys `q` and
`table`; erasures are supported through the Python interface above.
