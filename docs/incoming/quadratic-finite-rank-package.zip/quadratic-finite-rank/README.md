# Quadratic finite rank for constrained crossover

This package gives an explicit answer to Question 24.2 of the pinned ProveIt report: the largest finite aligned-fragment rank F(s) for binary, epsilon-free NFAs with at most s states has order Theta(s^2).

For every s >= 4, the construction has exactly s states, possibly several initial states, universal coordinate hull, and exact maximal rank (s - 3)^2. Combining this lower bound with the report's inherited upper bound gives

    (s - 3)^2 <= F(s) <= (2s + 5)^2.

The least parallel and frozen-source stabilization indices of the constructed family are ceil(log2((s - 3)^2)) and (s - 3)^2 - 1. Under a single-initial-state convention, an extra source state gives the lower bound (s - 4)^2 for s >= 5.

## Files

- `quadratic-finite-rank.pdf`: article with proofs, automaton diagram, example, source attribution, and limitations
- `quadratic-finite-rank.tex`: editable standalone LaTeX source
- `check.py`: finite construction/rank checker, Python standard library only
- `verification.json`: expected output from the checker
- `build.sh`: ordinary two-pass PDF build
- `SHA256SUMS`: checksums of the deliverable files

## Reproduce the finite tests

Use Python 3 with assertions enabled:

    python3 check.py > verification-new.json
    diff -u verification.json verification-new.json

Do not run with `python3 -O`, which disables the checker's assertions. A successful run outputs JSON with status PASS and these counts:

- 147,677 gate-length comparisons for 2 <= m <= 60 and 0 <= n <= 2m^2
- 8,184 literal fragment-partition rank computations on all binary words for 2 <= m <= 9 and 0 <= n <= 9
- 8,222 separate exact-length path-rank computations, including alternating extremal witnesses for 2 <= m <= 20 and their next-length counterparts

These finite tests do not prove the all-m theorem, exhaust all bounded-state NFAs, establish the inherited upper bound, or establish global novelty. The article supplies the lower-bound proof. It is not a Lean or other proof-assistant formalization.

## Compile the article

Install a working TeX distribution with pdfLaTeX and these standard packages: amsmath, amssymb, amsthm, lmodern, geometry, booktabs, microtype, hyperref, and pgf/TikZ.

    sh build.sh

This writes the PDF and temporary compilation files to `build/`, then copies the PDF alongside the source. The PDF in the package was compiled and every page visually checked.

## Exact source pin and attribution

Repository: https://github.com/VladimirReshetnikov/ProveIt

Commit: `1bd730779e8bc44c8976dcd9f38cad86a0d21c26`

Article: https://github.com/VladimirReshetnikov/ProveIt/blob/1bd730779e8bc44c8976dcd9f38cad86a0d21c26/SetTheory/Cardinals/docs/reports/automata-and-formal-languages/constrained-crossover-closure/article.tex

Question: Part II, Question 24.2, “The optimal finite rank bound,” source lines 3092–3110.

The upper bound and fragment-clock framework are inherited from the report, with the unary quantitative input due to Anthony Widjaja To. Earlier represented-interval crossover machinery is credited to Manzoni, Vanneschi, and Mauri (2012). The graph is the classical Wielandt digraph. Full citations and source links appear in the article.

The claimed contribution is the explicit quadratic state-count lower family and the resulting resolution of the pinned repository's asymptotic question. The package makes no claim of first discovery in the worldwide literature and does not settle sharp constants, exact F(s), or the analogous DFA extremal problem.

Prepared 1 October 2026 for Vladimir Reshetnikov.
