# Report 53 Ordinary repeated target firing

The editable manuscript is `Research_Report53.tex`; the verified reading copy is `Research_Report53.pdf`.

The exact physical-input theorem represents finite ordinary legal sandpile target firing, with repeated topplings permitted, on a radix-32 periodic tile plus a finite patch and an exact signed target. The frozen polynomial has 3,865 positive witnesses, 2,251 residuals, 17,275 binary arithmetic gates with fixed integer literals free, and exact degree 18. Its number-theoretic dependency is the pinned constructive Pell power theorem. A separate conditional computable-many-one corollary imports the published vertex/alarm simulation with two disclosed initializer repairs. It adds no arithmetic compiler or numeric universal tile to the resource claim.

## What is included

- `Research_Report53.tex` and `.pdf`: the independently readable report, full core proof, all arithmetic macro equations, geometry, exact ledger, and separate computability corollary
- `science/`: the unchanged author source-and-proof packet, including the literal DAG
- `independent_audit/`: the unchanged full adversarial audit, exact source/arithmetic receipts, and separate semantic challenge
- `universality/`: the unchanged physical-interface review, primary-source locators, and source pins
- `dependencies/`: the pinned Pell source as inert Lean text and the exact JSON wrapper consumed by the independent arithmetic auditor
- `audit_replay/`: the portable adapter and its separate portability review
- `verification/`: release-specific scientific replay, source-preservation, manuscript, layout, and deterministic build evidence
- `release.py`: the newly authored isolated-Python integrity, PDF-build, and archive tool
- `MANIFEST.json`: the final exact inventory, SHA256 values, sizes, and POSIX modes

Historical checkers, builders, and manifests retained inside the frozen packets may contain their original absolute paths. They are preserved provenance. Do not run them directly. The supported portable scientific entry point is `audit_replay/replay_audit.py`; it executes only the three pinned, inspected independent auditors as unchanged external copies. No submitted builder, author checker, upstream program, saved schedule, or Lean file is executed by the supported workflows.

## Verify the extracted release

Use Python 3.10 or newer and run in isolated mode without `-O`. Obtain the expected manifest SHA256 from the separate release handoff or trusted sidecar, rather than deriving trust from the unverified archive itself. Substitute that value for `TRUSTED_MANIFEST_SHA256`:

```sh
python3 -I release.py verify --manifest-sha256 TRUSTED_MANIFEST_SHA256
```

The command reads only the release and checks the exact entry inventory, file bytes, sizes, and modes. Symlinks and nonregular entries are rejected. POSIX mode preservation is part of this integrity convention; on other platforms use a POSIX extraction environment. A matching hash confirms byte identity, not the truth of a mathematical theorem.

## Replay the independent scientific checks

After verifying the release, choose a fresh external output directory that does not yet exist:

```sh
python3 -I audit_replay/replay_audit.py --output /absolute/external/new-audit-run
```

The adapter pins the unchanged DAG, three independent checkers, three expected receipts, and Pell JSON wrapper. It copies the checkers outside the release, starts isolated Python children, redirects only their documented data reads, and requires all three output receipts to be byte-identical to the originals. Full release bytes, modes, mtimes, and inventory are checked before and after. All output goes to the new directory. The adapter is specific to these inspected programs; `-I` and the preservation checks are not a general filesystem sandbox.

Finite tests do not replace the proofs or materialize a full physical/Pell witness. See the report and `independent_audit/AUDIT.md` for the theorem and precise dependencies.

## Rebuild the PDF offline

A local TeX Live installation with `pdflatex`, `pdftex`, `kpsewhich`, and the packages named in the TeX preamble is required. Poppler is needed only for visual rendering. The original build used TeX Live 2025/dev/Debian. Reproduction is bit-identical on the recorded toolchain; other TeX/font versions may produce different PDF bytes.

```sh
python3 -I release.py build-pdf --manifest-sha256 TRUSTED_MANIFEST_SHA256 --output /absolute/external/new-pdf-build
```

This first verifies the seal, uses no shell escape, builds three passes with fixed metadata and epoch, and requires byte identity with the packaged PDF. Caches and logs remain in the new external directory. It never modifies the release. `--draft` and `seal` are author-time modes, not needed for a delivered release; `seal` refuses to overwrite a manifest.

## Rebuild the deterministic ZIP

```sh
python3 -I release.py archive --manifest-sha256 TRUSTED_MANIFEST_SHA256 --output /absolute/external/new-Report53.zip
```

The destination must be a new external `.zip` file with an existing parent. Members are sorted, timestamps fixed to 2026-10-04 00:00:00, POSIX modes preserved, and storage is uncompressed (`ZIP_STORED`) to avoid compressor-version variation. CRCs and all member bytes are checked. No source file is changed. This ZIP is a complete standalone release, not a dependency on earlier report archives.

## Review boundaries

The report does not claim novelty, minimality, finite-foldness, real-witness equivalence, a new Lean theorem, an executed universal loader, or a paid raw-program-to-physical-code compiler. The fixed-tile r.e.-complete slice is an existence statement under the imported corrected physical simulation; the release does not identify its huge numeric tile. The two endpoint repairs are explicitly the report's mathematical corrections, not a discovered author-issued erratum.
