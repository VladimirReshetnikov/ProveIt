# A 242-state binary machine by branch borrowing

This package supplies an explicit **242-working-state, binary, single-tape
Turing machine starting on an entirely blank tape**, with initialization
included in the state count. It also supplies a compiled Lean proof of its
halting equivalence to ProveIt's pinned combined243 machine, for arbitrary
integer head positions and arbitrary binary function tapes.

Composing this new relative theorem with the predecessor's ordinary
consistency calibration gives the ordinary mathematical conclusion

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halt}(M_{242})\leftrightarrow
\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

**The complete consistency calibration is inherited, not newly checked in
Lean by this package.** The supplied Lean endpoint is the unconditional
relative binary-machine theorem. The predecessor's complete source/calculus
calibration remains a separate formal dependency. The report explains this
distinction and cites the inherited ordinary argument.

## Exact machine

| Property | Canonical table | Inherited-label table |
|---|---|---|
| File | `machine/zfc242.tm` | `machine/zfc242_old.tm` |
| Working states | 0–241: 242 states | 242 retained labels |
| Initial state | 0 | 95 |
| Dispatcher | 86 | 96 |
| Separate halt state | 242 | 254 |
| Binary transition rows | 484 | 484 |

The head starts at coordinate zero on a two-way infinite all-zero tape.
Every transition moves exactly one cell left or right. The halt state has
no rows. Inherited label **255 is a working state** and is retained.
Each table row is `state read write direction next_state`.

The predecessor is `candidate-combined243` at ProveIt commit
`e58338db7545909907e07a7603e8eb88625c527a`. Delete both rows of inherited
state 15 and change exactly two retained rows:

| Row | Old write/move/target | New write/move/target |
|---|---|---|
| 11 / 0 | `0 R 15` | `0 R 27` |
| 27 / 1 | `1 R 39` | `1 R 22` |

All 482 other retained rows are identical. SHA256 identities are:

```text
reference/zfc_combined243_old.tm
4207fc3d1bb16f3c64c3cff0980eaa1486160c3f467aee7685740a39e3df7300
machine/zfc242_old.tm
6b700aa713418cfe347a6ff2d0a92de7c31810d1cf69814b4684c7fb463876a0
machine/zfc242.tm
64ddeb2c01c3e9c7feffaffaad87266a270716c9307892a0445bf869b988984d
```

## Proof and verification

In the old machine, states 18, 47, and 65 always have zero immediately left
of the head; state 27 always scans zero. Complete predecessor-row checks
prove this invariant from state 95 for arbitrary tape and head. Therefore
the old read-one branch of state 27 can be borrowed to implement state 15.

At state 11 reading zero, a right neighbor of one gives two-step paths
`11 → 15 → 22` and `11 → 27 → 22`. A right neighbor of zero gives the old
two-step path `11 → 15 → 21` and the new four-step path
`11 → 27 → 32 → 45 → 21`. Both endpoints agree on the entire tape and head.
Ordinary checkpoints advance identically. Positive block lengths prove
both directions of halting equivalence.

Lean 4.32.0 compiled all four proof modules with **18 axiom probes,
13 typed callers, and zero warnings**. The reported dependencies are
contained in `{propext, Quot.sound}`. The exact 486/484-row bindings,
including inherited state 255, were checked before compilation. Results
and four compiler logs are under `evidence/formal/`.

Independent literal executions reach the same complete initialization
frame after **407,967 old transitions and 407,979 new transitions**.
The difference is six two-transition delays. The frame has head −5,
marker −6, header 176, logical registers `(3,0,0,0,3,0,0,0,0)`,
167 spare blocks of value one, and 351 one-cells. A separate canonical
dense replay agrees. This finite initialization evidence supplements the
all-tape proof.

## Contents and integration

| Location | Contents |
|---|---|
| `report.tex`, `report.pdf` | Detailed report, references, proofs, complete transition appendix |
| `machine/` | Both exact tables and renumbering |
| `formal/` | Relative Lean proof, table generator, fresh-build verifier |
| `code/`, `discovery/` | Primary and independent checkers, portable discovery tools, PDF builder |
| `evidence/`, `reference/` | Execution records, reviews, and pinned predecessor inputs |
| `alternatives/` | Supplementary source rotation and atomic-orientation research |
| `licenses/` | Preserved inherited license notices |

See [REPRODUCING.md](REPRODUCING.md) and [ATTRIBUTION.md](ATTRIBUTION.md).
`SHA256SUMS` covers the delivered files except itself. Suggested repository
destination: `Computability/BusyBeaver/Research/ZFC/candidate-branchborrow242/`.
Preserve this package's relative directory structure and register it as a
descendant of the pinned combined243 artifact. No minimality, worldwide
priority, or unconditional nonhalting claim is made.
