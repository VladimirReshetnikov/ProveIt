# One Real Dimension, Arbitrarily Complicated Arithmetic

**Order normal forms, Borel-complete classification, and measurable automorphism
rigidity for Polish Presburger models**

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov.
Date: 4 October 2026. Length: 22 PDF pages.

## Read first

The main article is `one_real_dimension.pdf`; its complete, self-contained LaTeX
source is `one_real_dimension.tex`. There is no external bibliography file or
image dependency. The references are embedded in the source.

The article addresses the one-real-dimensional case of Research Question 3 in
the earlier companion manuscript *Local Compactness Forces Arithmetic Rigidity*.
It does not present the earlier affirmative construction for Glazer's Question 2
as a second new discovery. It does not settle his separate ATR_0 question.

## Main results and reading route

- Sections 3–6: complete order normal form on R x E, the countable ordered-extension
  invariant, the Baire-property-to-Delta^0_2 upgrade, all topological isomorphisms,
  and the pair invariant when E = V direct-sum Z.
- Sections 7–9: a fixed real-analytic one-dimensional manifold with boundary,
  continuous coding of arbitrary countable linear orders by its analytic additions,
  and Borel completeness for countable-structure isomorphism in explicit codes.
- Sections 10–11: exact abstract versus Borel automorphism formulas, their cardinal
  counts, and a finite-normal-form embedding into the omnific integers.
- Sections 12–14: test limitations, a formalization plan, and nine further questions.
- Appendices: a model-uniform proof of classical Cooper elimination and a dependency
  ledger distinguishing established background, new arguments, and unverified scope.

## Rebuild

A reasonably complete TeX Live or MiKTeX installation is sufficient. The source
uses standard AMS packages, Latin Modern, microtype, geometry, tcolorbox, xurl,
hyperref, cleveref, and common table/list packages. No font files are distributed.

From this directory:

```sh
pdflatex -halt-on-error -interaction=nonstopmode one_real_dimension.tex
pdflatex -halt-on-error -interaction=nonstopmode one_real_dimension.tex
pdflatex -halt-on-error -interaction=nonstopmode one_real_dimension.tex
```

Alternatively run `sh build.sh`. This also executes the exact checks with Python
3.10 or later. No third-party Python packages are required.

## Exact checks

```sh
python3 checks/verify_finite.py --output checks/results.json
```

The packaged run passed 181,071 explicit exact-rational checks. A separate run
with `python3 -O` produced an identical results file; the test program does not
rely on Python's removable `assert` statements.

These are finite checks of formulas and examples, NOT proofs of the infinite or
topological theorems, a decision procedure for infinite isomorphism, or a theorem-
prover certificate. Counts record individual assertions, not independent theorems.

## Sources and provenance

`SOURCE_MANIFEST.json` records the sources and the actual pinned ProveIt commit:

`a32e1b139db296512a767ea78296ef3db642578e`

Only relevant repository guides were read; the repository was not modified or
rebuilt. The earlier companion manuscripts were consulted to identify prior
claims and the open classification target; their other theorems are not assumed
in the article's proofs. No copies of external research papers are included.

## Status

This is an AI-assisted, unrefereed research manuscript with conventional proofs.
Historical priority of its new formulations has not been established. There is
no claim of independent expert certification or of Lean/Rocq verification.
Classical Presburger elimination, Friedman–Stanley universality, and elementary
ordered-group methods are attributed rather than claimed as new.
