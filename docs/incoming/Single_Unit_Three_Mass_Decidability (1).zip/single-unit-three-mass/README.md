# Three mass units with a single unit symbol

## Result

For each fixed one-dimensional deterministic conservative cellular automaton with a finite alphabet, a unique zero-weight vacuum, positive integer nonzero weights, and at most one weight-one symbol, the mass-at-most-three timed evolution relation is effectively Presburger in all input/output positions. Exact reachability and finite-pattern occurrence are decidable. Ordinary nonnegative integer-state NCCAs satisfy the single-unit-label condition.

Open `single-unit-mass-three.pdf`. The complete editable source is `single-unit-mass-three.tex`.

The proof includes the no-weight-one case, radius-zero rules, the stationary frame, a forward-invariant diameter bound for mass two, first-entry acceleration, a finite three-mass encounter core, and uniform composition across arbitrarily large input gaps. It covers intermediate observations, label changes, merges/splits within bounded clusters, signed motion, and exact output ordering.

The horizon-free quartic corollary reuses the established canonical arithmetic compiler in Section 9 of the companion report *Sparse Diophantine certificates for finite mass lattice dynamics* (2 October 2026). It charges quantifier elimination and the chosen formula/circuit: K = 2I + 6C + B natural auxiliary witnesses, E = 2I + 5C + B + 1 quadratic residuals, and degree at most four. B denotes gate count. It makes no universal numerical arity or nonnegative-real exactness claim. Time is eliminated before compiling untimed reachability.

## Reproduce

The tests require Python 3.10 or newer and a POSIX shell. They use only the standard library, require no network access, and run the shipped scripts in a temporary copied workspace:

    ./run-tests.sh

The runner compares fresh JSON results with both recorded results and leaves the shipped files unchanged. It prints the replay directory.

To verify the shipped checksums:

    sha256sum -c SHA256SUMS

To rebuild the PDF with TeX Live and standard LaTeX packages:

    ./build.sh

Build caches stay in `.build`. Rebuilding with a different TeX version may change PDF bytes without changing the mathematics. TeX is not needed for Python replay.

## Validation

The primary test suite compares actual CA configurations rather than symbolic proof templates:

- 23 sample conservative rules, including all five conservative elementary binary rules, an ordinary numerical 0/1/2/3 NCCA, and a weighted rule with multiple weight-two/three labels
- 7,127 actual orbit cases and 1,140,320 direct-versus-accelerated time comparisons
- 102 mass-two profiles, 5,103 signed linear interval cases, and 2,760 dense conservation tests
- A gap of 10^30 + 17 accelerated with 13 core visits

The separate executable audit adds threshold, reflection, zero/negative drift, ordering, and dense finite-window tests. See `independent/AUDIT.md` and both JSON result files for its exact scope and counts.

The sample-rule conservation arguments are mathematical: disjoint binary swaps; exact de Bruijn potential certificates for elementary rules; and disjoint mass-preserving guarded rewrites. Finite dense tests supplement those arguments. No exhaustive enumeration of all conservative CA rules or machine-checked general proof is claimed.

The sample accelerator names its unique unit symbol `u`; an arbitrary rule interface would need that renaming convention or a unit-label parameter.

The executable package implements and checks the orbit accelerator. It does not implement a complete arbitrary-rule-to-Presburger formula generator, quantifier elimination, or a new quartic compiler.

## Scope and unresolved questions

The obstruction is to a computable finite-support input encoding of mass at most three with exact-configuration or finite-pattern halt observations. It is not an assertion about signed weights, infinite alphabets, nonuniform rules, active zero-weight backgrounds, or noncomputable output interpretations.

Kong’s June 2021 thesis is a direct binary three-particle nonuniversality and periodic-orbit-decomposition precursor. Imai’s 25 June 2021 KAKEN report also announces decidability at particle count at most three, with the decision problem left implicit. The article now attributes both sources precisely. The 2016 Alhazov–Imai abstract supplies a five-particle upper bound. Novelty of the weighted/uniform arithmetic strengthening and the current four-versus-five boundary remain unresolved; the thesis’s four-particle-open statement is historical (2021). See `REVISION.md` for this attribution-only update.

## Contents

- `single-unit-mass-three.pdf` and `.tex`: complete article
- `test_single_unit_acceleration.py` and `test-results.json`: constructive accelerator and recorded main run
- `independent/`: independently written executable audit, result, and mathematical conservation review
- `run-tests.sh`: copied clean replay and result comparison
- `build.sh`: local-cache PDF rebuild
- `SOURCE-PROVENANCE.md`: sources, verified scope, and dependencies
- `REVISION.md`: attribution-only revision and preserved-content ledger
- `SHA256SUMS`: integrity manifest
