# The Decreasing Spectral Core

**Complete minimal spectra, finite-smoothness rigidity, and global polynomial conjugacy**  
Research draft prepared for Vladimir Reshetnikov — 29 September 2026

## Read first

`article.pdf` is the complete article; `article.tex` is its self-contained
LaTeX source, including the bibliography. No external figures are needed.

The equation P[f] = 0 means a linear combination of **iterates** of f,
not a polynomial in the pointwise value f(x). The domain is all of R and
P has a nonzero constant coefficient.

## Main results

1. **Complete decreasing minimal spectra.** Outside the involution case,
   all nonunit roots lie strictly inside or strictly outside the unit circle.
   Negative roots dominate multiplicities on the two extreme circles; a
   single circle imposes an additional odd-multiplicity condition. Optional
   simple factors at +1 and -1 are accounted for exactly. Every permitted
   spectrum has a globally bi-Lipschitz realization analytic away from at
   most two points.
2. **Exact continuous core.** A root-by-root algorithm gives the smallest
   polynomial annihilating every decreasing solution. At most two witness
   maps are required, with an exact criterion for needing two. The article
   credits Draga's earlier special-case disjunctive reduction.
3. **Finite-smoothness rigidity.** Above an explicit finite differentiability
   threshold depending on P, every non-involutive solution has the form
   f(c + H(t)) = c + H(a t), with a < 0, a != -1, and H a polynomial with
   H(0)=0, H'(0)=1, H'>0 everywhere. It is automatically real analytic,
   algebraic, and globally bi-Lipschitz. This applies in particular to all
   C-infinity non-involutive solutions.
4. **Exact smooth core and unbounded witness complexity.** Smooth spectra
   consist of distinct integer powers of one negative multiplier. The
   corresponding core has an exact finite branch formula. Arbitrarily many
   smooth witnesses can be needed even when one C1 witness attains the
   whole continuous core.

The article includes the proofs, explicit examples, affine and rational
rigidity corollaries, ten proposed research directions, and a source and
claim audit.

## Research status

This is an AI-assisted, unrefereed manuscript, not proof-assistant-verified.
The main results are proved in the article without assuming the truth of
unverified repository theorems. Finite computations supplement, and do not
replace, these proofs. Historical priority has not been exhaustively
established; the source audit identifies which full texts and abstracts
were inspected. See `STATUS.md`.

Repository anchor:
https://github.com/VladimirReshetnikov/ProveIt

Inspected commit:
`afb2d1227d8bc5df3beffc1463e958db3544960b`

Relevant report directory:
`SetTheory/Cardinals/docs/reports/log-concavity-and-unimodality/nonreal-roots-in-iterative-equations/`

The prior increasing-spectrum companion was inspected in the user's
Library; it is not asserted to be part of that pinned repository commit.
No repository or Library files were modified.

## Reproduce the exact checks

Python 3.10 or newer; **no third-party package is required**:

```text
python code/verify.py
```

An optional argument selects another output JSON path:

```text
python code/verify.py results/verification-new.json
```

The checker uses exact fractions and explicit exceptions; its checks do
not disappear under Python's `-O` option. It checks:

- 2,693 continuous input-profile instances and 203,149 candidate divisors;
- 1,024 smooth input root sets and 59,049 candidate divisors;
- exact cubic recurrence identities and Hankel determinants;
- 401 rational plateau points and an eight-slope witness example.

All checks passed in the supplied run. Profiles may overlap between
atlases; the counts are test instances, not globally distinct polynomials.
The finite checker verifies consistency of the algebraic rules, not the
all-real analytic construction or the finite-smoothness proof.

## Rebuild the PDF

Use a reasonably complete TeX Live or MiKTeX installation with the packages
listed in `article.tex` (including Latin Modern, AMS packages, microtype,
geometry, hyperref, xurl, titlesec, fancyhdr, and needspace).

```text
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

No bibliography processor is needed. The Makefile supplies equivalent
`verify`, `pdf`, and `clean` targets. The direct commands also work on
Windows when Python and LaTeX are on PATH.

## Files

- `article.tex`, `article.pdf`: source and compiled manuscript.
- `code/verify.py`: exact finite checker, including both core algorithms.
- `results/verification.json`, `results/verification.txt`: recorded output.
- `STATUS.md`: proof scope, validation boundaries, and priority limitations.
- `Makefile`: build and verification targets.
- `CHECKSUMS.sha256`: hashes of package files, excluding itself.
