# Strict Contractions with Diophantine-Complete Transients

Research report for the ProveIt project, 30 September 2026.

## Main result

The article gives a uniform compiler from deterministic two-counter programs
into rational, continuous, positively homogeneous piecewise-linear maps on
R^4 with global sup-norm Lipschitz constant at most 1/2. Every orbit tends to
zero. A fixed universal instance has undecidable half-space reachability,
while point-to-point reachability for each map produced by the compiler is
decidable.

A related peak-value function is uniformly computable and Lipschitz, maps
every rational point of the compact cone to a rational number, and yet has
an undecidable rational-input zero test. Every strictly positive rational
threshold is decidable. Full proofs are in the article.

The bounded integer-circuit compiler constructs canonical natural-witness
quartics. The unbounded fixed-arity polynomial is a separate MRDP existence
result. No unbounded finite-fold theorem, minimal dimension, optimized
universal table, historical priority, or new Lean verification is claimed.

## Files

- `strict_contractions.pdf`: the complete 24-page article.
- `strict_contractions.tex`: self-contained LaTeX source, including bibliography.
- `verify_contraction.py`: exact rational simulator, integer ReLU compiler,
  polynomial exporter, and reproducible tests; Python standard library only.
- `check_export.py`: independent JSON/algebra checker for the exported artifacts.
- `verification/`: a fully expanded example polynomial, its quadratic residuals,
  canonical natural assignment, integer circuit, trace, and test reports.
- `Makefile`: optional build and verification targets.
- `SOURCE_AUDIT.md`: external dependency and reproducibility notes.

The example is a three-state counter-transfer program, not a universal machine.
Its first-hit time is 7, its integer circuit has 26 ReLU gates, and its quartic
has 4 free input variables, 400 natural witnesses, and 2,105 nonzero terms.
The source of the universality theorem is stated separately in the article.

## Reproduce the computations

Requires Python 3.10 or later; no third-party packages are required.

```sh
python verify_contraction.py --self-test --out verification
python check_export.py verification
```

The first command writes the example artifacts and `test_report.json`.
The second independently reconstructs the sum of squares and verifies its
exact symbolic equality with the expanded polynomial, all residual equations
at the supplied assignment, and all 400 one-coordinate witness mutations.
The included `independent_checker_report.json` records the completed check.

Test coverage includes 5,000 exact instruction/integer-lift cases, 1,000
seeded rational global Lipschitz/homogeneity checks, 21 exhaustive small
complementarity tests, the example trajectory, zero-time edge cases,
400 rejected witness mutations, and 9 rejected incorrect first-hit horizons.
These finite tests complement the mathematical proofs; they are not a
formal or exhaustive proof of universality or global correctness.

## Compile another program

Programs are JSON arrays with at least two states. States are numbered by
array position. Only the final state is `halt`. Allowed instructions are:

```json
[
  {"op": "dec", "counter": 1, "zero": 2, "positive": 1},
  {"op": "inc", "counter": 2, "next": 0},
  {"op": "halt"}
]
```

An unconditional jump is `{"op":"jump","next":0}`. Counters are 1 or 2.
The initial state is 0. For example:

```sh
python verify_contraction.py --program verification/example_program.json \
  --counter1 3 --counter2 1 --steps 7 --out another_run
python check_export.py another_run
```

The exporter rejects a claimed first-hit time that does not match the actual
bounded trace. It does not attempt to decide whether a nonhalting program
will eventually halt.

## Polynomial format

A polynomial is a list of terms `[integer_coefficient, variable_indices]`.
The variable-index list is a monomial: `[7,7,11]` means X_7^2 X_11. The empty
list denotes 1. All variables, including witnesses, range over natural
numbers. The first four are free initial integer cone coordinates; subsequent
variables are the canonical trace/gate/slack witnesses. Negative polynomial
coefficients use ordinary signed integer arithmetic, not truncated subtraction.

`certificate_system.json` gives the residual equations before squaring.
`expanded_quartic.json` gives their squared sum. The independently checked
identity proves the equivalence between zero of the expanded polynomial and
simultaneous zero of the residuals over natural assignments. It does not, by
itself, replace the article's proof that the residuals encode the machine.

## Rebuild the PDF

A normal TeX Live installation with pdfLaTeX suffices. The source uses
amsmath, amsthm, mathtools, microtype, booktabs, longtable, enumitem, listings,
hyperref, cleveref, xcolor, geometry, and Latin Modern.

```sh
pdflatex -interaction=nonstopmode -halt-on-error strict_contractions.tex
pdflatex -interaction=nonstopmode -halt-on-error strict_contractions.tex
pdflatex -interaction=nonstopmode -halt-on-error strict_contractions.tex
```

The repository itself is unchanged. No font files or external paper PDFs are
included in this package.
