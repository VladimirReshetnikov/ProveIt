# Report277

## Threshold free polynomial density increments on cyclic groups

This package contains a self-contained mathematical article, editable TeX, and bounded exact Python diagnostics. The written proof establishes the arbitrary-parameter theorem. The diagnostics test finite identities and regressions; they are not numerical proof for all real coefficients, Lean certification, or evidence of priority.

## Main result

Let A have density δ in Z/NZ, N≥2. Suppose M nonempty disjoint proper modular arithmetic progressions cover A, their lengths are pairwise within a factor of two, and coefficient-polynomial phases of degree at most k≥1 have summed balanced correlation at least αN, where α>0. Then some proper progression Q satisfies

    |Q| ≥ max{1, (N/M)^(1/D_k)/8}
    |A ∩ Q| ≥ (δ + α/3)|Q|

Here K_k=(k!)²2^((k+1)²), D_1=4, and D_k=K_k/4+1 for k≥2. There is no minimum correlation, minimum parent scale, prime-modulus, or least-prime-factor hypothesis. Proper means injectively parameterized; wrapping and nonunit steps are allowed. The output need not lie inside the cover.

Since D_k≤K_k, this proves the entire mathematical interface of the pinned Corollary 5.8 for every degree and every nonvacuous cyclic modulus, with stronger density gain. The pinned source gain is α/16; the original printed statement has α/8, while its displayed proof ends with α/16. This is a written source implication, not a repository edit, formal verification, or a new global Ramsey/Szemerédi estimate.

## Explicit proof inputs and alternatives

Every mathematical input is proved in article.tex; no previous report or private research note is needed.

- Quadratic recurrence: p≤2^10 R^5 and ||θp²||<1/R for real θ and integer R≥2
- General recurrence: put s=k−1, w=2^s, γ=3s^(2s+2), A_k=16(w+γ+k²), and B_k=2^k+8; then p≤2^A_k R^B_k and ||θp^k||<1/R
- Sharper cubic recurrence: p≤2^128 R^16
- Real polynomial localization into cells of lengths L through 2L−1 and phase error <1/(4L), for integer L≥2
- Exact localization budgets: (c_2,e_2)=(116,38); for k≥3, m_k=kB_k+1, e_k=B_k+m_k e_(k−1), c_k=A_k+(k+7)B_k+m_k(c_(k−1)+e_(k−1)), with threshold n≥2^c_k L^e_k
- The infinite-degree proof that c_k+e_k≤K_k/4
- Subgroup-coset variance and removal of nonproper directions for every cyclic modulus
- Exact cover mass, integer rounding, and positive-cell extraction joining the regimes without a missing scale premise

The recurrence accuracy R and the progression target L are different parameters. All localization scales are integers. The internal witness p<T/R², or p<512R^4 in the quadratic proof, is manufactured under a contradiction hypothesis; it is not an independently proved better global recurrence bound.

The article retains these alternatives at the same gain α/3, with S=N/M and b=1−δ:

- Affine: max{1,S^(1/3)/8,sqrt(αS/(96πb))}; the square-root alternative can be parent-contained
- Quadratic: max{1,S^(1/39)/17}
- Cubic: max{1,S^(1/4096)/8}, using partition budget 2^7834 L^1878
- Compact degree dependence for k≥2: put P_k=k!2^(k(k+1)/2); then e_k<12P_k and c_k<(k+7)e_k, yielding length max{1,2^(−k−8)S^(1/(12P_k+1))}
- Exact budget: for any proved threshold 2^c L^e, length at least max{1,floor((3S/(8·2^c))^(1/(e+1)))} and hence at least max{1,(3S/(8·2^c))^(1/(e+1))/2}

The compact estimate is proved with an exact eight-row integer certificate plus a universal geometric tail bound; the finite numerical table is not substituted for a tail proof. Its degree factor obeys P_k=2^(−(k+1)/2)sqrt(K_k). A further self-contained corollary defines exact convergent constants λ∈(11,12) and γ with 7−1/1900<γ<7−27/80500, and gives e_k/P_k=λ+O(2^(−k)) and c_k/P_k=λ(k+γ)+O(k2^(−k)), with explicit rational error bounds. These describe the proved construction and do not assert optimality.

The unoptimized general cubic budget is (10986,1878); the sharper specialization is (7834,1878). These are kept separate. One may select whichever full guarantee is largest for an input. The coarse uniform theorem is not claimed to dominate earlier bounds pointwise. No exponent or prefactor is claimed optimal.

## Files

The exact source allowlist is:

- README.md
- SOURCES.md
- article.tex
- build.py
- companion/exact_checks.py
- tests/test_build.py
- tests/test_companion.py

A distribution adds Report277.pdf and MANIFEST.sha256. The ZIP contains exactly these nine files under Report277/. Its manifest lists the eight public files other than itself. The archive SHA-256 is supplied alongside it, avoiding a circular self-hash. No third-party paper, repository source, private review, or temporary file is bundled.

## Run bounded exact diagnostics

From this directory:

    python3 -B companion/exact_checks.py
    python3 -B companion/exact_checks.py --full
    python3 -B companion/exact_checks.py --nmax 6 --kmax 12
    python3 -B tests/test_companion.py
    python3 -O -B tests/test_companion.py
    python3 -B tests/test_build.py
    python3 -O -B tests/test_build.py

The default exhaustive modulus cap is 6 and budget degree cap is 12. --full uses caps 8 and 32. Explicit --nmax and --kmax override their respective defaults; their enforced ranges are 2..8 and 3..32. The CLI accepts at most five arguments, each at most 64 characters. Both normal and optimized runs support -I -B -X int_max_str_digits=640.

The deterministic sorted JSON distinguishes finite diagnostics from universal proofs. It checks symbolic exponent collection in T·H=F_k(L), the recurrence constant comparisons and K-budget induction algebra, ordered factorizations against independent enumeration, weak compositions against word counts, exact repeated-difference coefficients against subset expansions, subgroup-coset pair moments, all-direction variance with multiplicities, bad-direction removal, cover-mass identities, residue chunking and target-2L resplitting, rational polynomial restrictions, and named boundary regressions. It uses no numerical complex exponentials or floating-point roots.

Default / full diagnostic counts are 11 / 31 budget rows, 480 / 2,016 all-subset variance instances, 516 / 3,076 subgroup pair instances, 15 / 28 multiplication kernels, 1,089 / 9,837 cover-mass instances, and 140 / 245 rational recurrence samples. Both profiles also run 288 divisor checks, 198 composition checks, 28 differencing coefficient checks, 28 prefactor checks, 84 independent subset expansions, 367 residue/refinement toys, nine larger variance cases, 27 exact-floor boundaries, 18 source-ceiling boundaries, and three scalar assembly examples. The compact-growth addition checks 11 / 31 degree rows, the same eight exact certificate rows in both modes, and 3 / 23 finite tail-ratio samples. Its output explicitly states that the program does not prove the universal tail. The 51 companion tests and 33 builder tests exercise invalid-input rejection and the documented regressions separately.

The localization examples are structural toys; they do not claim the enormous recurrence-dependent phase partition has been constructed. The program represents theorem budgets by their exponents and avoids constructing huge 2^A or 2^c. Rational recurrence examples search only through the rational denominator, not through a theoretical T, and are not certificates for arbitrary real θ. The universal statements are justified by the article's proofs, not by finite degree checks.

Public helpers include recurrence_parameters, source_constant, density_exponent, source_bridge_length, partition_budget, budget_diagnostic, exact_budget_length, ordered_divisor_count, compose_polynomial, difference_polynomial, chunk_lengths, residue_chunks, localization_structure, restriction_diagnostic, modular_restriction_diagnostic, rational_recurrence_witness, coset_pair_moment, all_step_moments, cover_mass, and run_checks. The compact_budget_scale and compact_budget_diagnostics helpers provide the additional degree-growth certificate checks. Their docstrings state exact domains and semantics. Runtime validation rejects invalid or oversized inputs even under -O.

Key caps: degree 32 for symbolic budgets and rational recurrence; modulus 64 for structural/moment helpers; rational recurrence denominator 512 and accuracy 4096; materialized chain length 4096; polynomial degree 8 and coefficient numerators/denominators at most 128 bits; exact-budget input ratio and symbolic exponents at most 1024 bits. Individual helpers impose smaller domain-specific caps where needed. Bounds concern diagnostic computation, not the scope of the written theorems.

## Rebuild and package offline

Requirements: Linux, Python 3.11 or later, /proc/self/fd, and a trusted system TeX installation containing /usr/bin/pdftex, /usr/bin/pdflatex, lmodern, amsmath, amssymb, amsthm, mathtools, geometry, microtype, enumitem, booktabs, xcolor, and hyperref. Python uses only its standard library. The build downloads nothing and performs no network access.

Check the exact source inventory or a manifest-pinned distribution:

    python3 -B build.py verify

Run normal and optimized tests/diagnostics, compile the article, and create a deterministic PDF and ZIP in a fresh external directory:

    python3 -B build.py reproduce --output /tmp/report277-rebuild

The output must be an absent or empty absolute directory outside the source and protected system locations, and must not be an ancestor of the source. Existing outputs are never overwritten. Source inventory and bytes are checked before and after the operation.

Outputs include Report277.pdf, report277_all_degree_density.zip, its SHA-256 sidecar, MANIFEST.sha256, reproduction_receipt.json, and staging/log files. The ZIP excludes staging and logs. Starting from a manifest-pinned distribution requires rebuilt PDF bytes to equal the pinned PDF. Exact reproduction depends on matching the TeX engine, packages, fonts, and compression toolchain; mismatches are reported instead of silently accepted.

For a manifest-pinned distribution, package existing checked bytes without compiling:

    python3 -B build.py package --output /tmp/report277-package

ZIP names are sorted; timestamps and permissions are fixed; extra fields/comments are empty. The builder verifies CRCs, bytes, and exact inventory. Diagnostic stdout must agree under normal and optimized Python; test-runner timing on stderr is not required to be identical.

## Trust boundary

The builder is for supplied trusted source and installed trusted tools. It uses exact inventory allowlists, bounded reads, no-follow directory/file handles, single-link regular-file checks, exclusive output creation, a minimal child environment, subprocess time/output limits, and disabled TeX shell escape. Tests cover the documented inventory, packaging, and filesystem regressions.

These controls are not a sandbox for arbitrary hostile TeX or Python, and are not a guarantee against an actively malicious concurrent filesystem owner. The compiler and installed TeX resources remain trusted. A manifest verifies byte agreement with a supplied digest list, not authorship or mathematical truth.

## Provenance and scope

SOURCES.md gives the pinned repository interface, source fingerprints, and primary literature links. Classical repeated differencing, recurrence, and localization are credited. No priority, formal-verification, ordinary-integer rectification, or global Ramsey/Szemerédi improvement is asserted. No repository file or previous report was modified for this package.
