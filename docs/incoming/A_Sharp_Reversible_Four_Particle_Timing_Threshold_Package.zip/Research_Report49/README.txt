REPORT 49 - A sharp reversible four particle timing threshold
4 October 2026

Main result
-----------
A completely specified binary one-dimensional number-conserving CA F is globally
reversible on the full shift, with F and F^-1 of radius at most 90. Starting from
{0,5,6,d}, d>=13, the exact anchored word 1000011 on [0,6] occurs precisely at
k^2+(2d-23)k for natural k, including zero. The inherited binary at-most-three
argument proves four is the sharp particle threshold for failure of eventual
periodicity in this model. The report also proves a density-one observation
and the elementary natural/nonnegative-rational exact quartic fiber statement.
This is not a universality, literature-priority, minimum-radius, or arithmetic
arity/degree record claim. Proofs are ordinary mathematics, not formalization.

Contents
--------
report49.pdf                         Main report
manuscript/report49.tex               Editable LaTeX source
figures/clock-spacetime.pdf            Rule-generated figure
figures/clock-spacetime.csv            All plotted particle coordinates and hits
figures/figure-receipt.json            Figure source hash and checks
code/replay.py                       Authenticated, isolated replay helper
code/build_pdf.py                    Offline shell-escape-disabled PDF builder
code/make_figure.py                  Trace and optional figure regeneration
frozen/candidate/                    Candidate specification, checker, receipt
frozen/audit/                        Fourteen independently frozen scientific
                                     files plus their original SHA256SUMS
frozen/manuscript-audit/             Independent manuscript and 14-page render
                                     review, new checker, and receipt
evidence/replay-safety-checks.json    Tamper, extra-file, and symlink rejection
MANIFEST.sha256                      Exact release-file inventory and hashes

The candidate checker and three independent-audit checker source files were
newly authored for this construction/audit and inspected before execution.
The inherited article .tex is inert reference evidence. Never compile or
execute it. The replay allowlist contains only the inspected checker sources.
No original upstream program, binary, schedule, automation, or network service
is required or used. Compiled binaries and interpreter caches are not shipped.

Integrity and source identity
-----------------------------
Obtain the MANIFEST.sha256 digest from the delivery message or another trusted
channel; a manifest supplied only alongside its files does not independently
authenticate its publisher. Hashes provide content integrity, not signatures.
Do not substitute a newly calculated digest for a trusted expected digest when
authenticity matters.

From the unpacked report directory, replace TRUSTED_SHA256 below with that
externally supplied 64-hex-character digest:

  python3 -I -B code/replay.py --verify-only --manifest-sha256 TRUSTED_SHA256

The helper rejects symlinks, special files, path traversal, extra files, missing
files, and digest mismatches. It verifies the original audit manifest against
its separately pinned hash, verifies all its members, recomputes the inherited
Git blob SHA-1 and SHA-256, and reconstructs the exact inherited excerpt from
the recorded article line range. Read-only modes are accidental-write guards,
not a security boundary or a claim of cryptographic immutability.

Full isolated offline replay
----------------------------
Prerequisites: Python 3 standard library, g++ with C++17 support, and a local
TeX Live pdfLaTeX installation with the packages named in report49.tex.
Matplotlib is NOT required for ordinary replay or PDF rebuild because the
figure PDF is already included. The helpers install no packages.

  python3 -I -B code/replay.py --manifest-sha256 TRUSTED_SHA256 \
      --sanitizer --output /tmp/report49-new-replay

The output directory must be new or empty and outside the release. If omitted,
a fresh /tmp directory is created. The helper leaves scratch evidence in place
and prints its exact location. It creates no files in the release. It snapshots
and checks original file/directory bytes, modes, and mtimes before/after replay.

The candidate, independent sparse, overlap-table, corollary, supplementary
manuscript checker, and 64-periodic checks are run. The optional --sanitizer reruns the complete periodic corpus
under UndefinedBehaviorSanitizer. JSON receipts must match the frozen receipts;
only the independent sparse receipt's elapsed_seconds is excluded. The
manuscript checker additionally tests the density-one 100000 observation,
1,804 complete orbit steps with both half-steps, 21 huge-coordinate steps,
and 303 generic finite supports. The reviewed TeX/PDF hashes are also bound
to the frozen manuscript-review verdict. The overlap
tables, periodic/corollary receipts, and regenerated figure trace must match
byte for byte. Python checks and C++ checks use explicit failures that remain
enabled under optimization. The usual run can take several minutes.

The helper then rebuilds the PDF with shell escape disabled and requires byte
identity with report49.pdf. The recorded build uses pdfTeX 1.40.26 from Debian
TeX Live 2025/dev, the installed Latin Modern and DejaVu fonts, and fixed
SOURCE_DATE_EPOCH=1791072000. It omits PDF creation dates and trailer IDs.
Different TeX/font versions may produce a visually identical but byte-different
PDF. Use --skip-pdf to replay mathematics independently when TeX is unavailable
or a different installation causes byte differences; this is not a full PDF
reproduction. The bundled figure is always copied unchanged for PDF builds.

PDF rebuild alone, after successful integrity verification:

  python3 -I -B code/build_pdf.py --output /tmp/report49-new-pdf

The builder makes a new scratch format/font-map cache if needed, copies only
report49.tex and the bundled figure, and compiles three times. It never compiles
the inherited article. All writes are to the external target.

Optional figure regeneration
----------------------------
For the optional vector-figure rebuild only, install matplotlib from a trusted
package source beforehand. No installation is performed by this packet.

  MPLCONFIGDIR=/tmp/report49-mpl-cache python3 -I -B code/make_figure.py \
      --output-dir /tmp/report49-new-figure

Without matplotlib, the standard-library --trace-only option regenerates CSV
and figure-receipt.json. Both are verified during ordinary replay. The plot is
computed by repeated application of the literal rule; the formula is used only
for comparison, never to implement the automaton.

Scientific boundaries
---------------------
The full-shift involution proof, complete all-D orbit proof, and inherited
at-most-three argument are in the manuscript. Tests corroborate them but do
not prove all infinite configurations. The 540 overlap tables exhaust each
specified pairwise predicate interaction; they do not enumerate all radius-45
neighborhoods. The period-64 checker enumerates every padded width-18 word,
not every 64-bit word. The rational trials supplement the monic rational-root
proof, not replace it. Source comparisons in the bibliography distinguish
inherited mathematics, contextual results, and fresh verification.
