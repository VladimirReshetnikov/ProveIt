# Anchored-unit equality and internal-flow contraction

All coordinates are unrestricted integers. Every delivered coefficient array defines a literal polynomial of exact total degree four, constant coefficient one, and nonzero collected coefficients exactly ±1. The polynomials are nonnegative on all real tuples. This file proves the unbounded algebraic equivalence; exact finite expansion checks the stated metrics independently of the construction algorithm.

## 1. Source interface and monic preliminary transformations

`SOURCE_BINDINGS.json` pins the exact original quadratic systems and identifies their surrounding ordinary consistency calibrations. The inherited source theorem is: ordinary ZFC proves that an integer zero exists exactly when a finite ZFC refutation exists. The present package transfers that theorem, and does not prove consistency. The source calibration is an explicit inherited hypothesis/interface, not a consequence of finite tests here.

For each selected rank-one quadratic part ηL(x)², η∈{−1,+1}, introduce the affine coordinate z=L(x)+k. Replace the original row R by ηz²+R−η(L+k)² and retain the monic definition of z. Identical definitions may be shared. Substitution of the unique affine values recovers every original row exactly. Conversely the definitions force those values, so zero sets are in bijection. Fixed selections are certificate data, not final equation parameters.

For positive integer coefficients, introduce triangular monic addition-chain constants and monic scale definitions s=cx as needed. Replace each row by a sum of signed monomial occurrences of degree at most two and coefficient ±1. Substituting all constructor values recovers each source row exactly; all constructor rows vanish. The independent checker verifies every source pullback, unique monic pivot and complete constructor coverage. Multiply any normalized row by its certified sign ε_r∈{−1,+1}; this does not change its zero set.

## 2. Incidence and equality energy

Assign a nonempty vertex block to each normalized row and one to a hub. Each block has independent integral flow coordinates on a spanning tree. Represent each normalized monomial occurrence by an edge from its row block to the hub, or pair identical opposite-sign occurrences in different rows and use one direct edge between those blocks. Every occurrence is bound exactly once. Each prescribed edge has a signed degree-two label in aliases of its logical factors; aliases of one homogenize lower-degree terms.

Let d_v be the signed divergence at vertex v. Set E=½∑_v d_v². Internal tree flows cancel in block sums. After all aliases take their logical values and units take one, the row-block boundary sum is the signed normalized residual T_r and the hub boundary is −∑_rT_r.

For a class with k≥3 aliases use

    C(a_1,…,a_k)=∑a_i²−∑a_i a_(i+1), cyclically.

Then 2C=∑(a_i−a_(i+1))², so its zero set is equality of all aliases. A singleton needs no penalty. For two aliases one may use the quartic penalty

    Q(a,b)=a⁴+b⁴−a³b−ab³=(a−b)²(a²+ab+b²).

It is nonnegative and vanishes exactly at a=b; also 2Q=(a²−b²)²+(a²−ab)²+(ab−b²)². Otherwise the prior construction adds one equality dummy d and uses C(a,b,d).

For unit aliases u_1,…,u_l, l≥2, use

    U=1+∑u_i²−u_1−u_l−∑_(i<l)u_i u_(i+1).

Its double is (u_1−1)²+∑_(i<l)(u_i−u_(i+1))²+(u_l−1)². Thus U is nonnegative and is zero exactly when every unit alias is one. The final polynomial is incidence energy plus the chosen equality penalties plus U.

Same-logical alias identifications preserve the source interface and are accepted only when full coefficient collection passes. The inherited polarization step may change prescribed a² or b² labels to ab within a two-alias logical class and replace C(a,b,d) by Q(a,b), deleting d. At equality the labels have identical values; the complete polynomial is again checked for height one. `INHERITED_POLARIZATION_PROOF.md` and `INHERITED_NETWORK_PROOF.tex` retain the complete prior arguments.

## 3. New operation: replace an equality dummy by an anchored-unit product

Suppose d appears only in C(a,b,d), and u is an already existing unit alias in the unchanged unit path. Substitute d=au. The new penalty is

    G(a,b,u)=C(a,b,au)
             =a²+b²+a²u²−ab−abu−a²u.

It has degree at most four and

    2G=(a−b)²+(b−au)²+(au−a)².

Therefore G≥0 for every real tuple, without assuming u=1. In a zero of the complete energy the independent unit summand forces u=1. Then G=0 is equivalent to a=b. Conversely every old zero has u=1 and d=a=b, so it satisfies d=au; projection deletes d and preserves zero. Every new zero uniquely restores d=a (equivalently au), giving the inverse map. No new coordinate is introduced. One may interchange a and b and use bu instead.

The independent step checker verifies literally that d is an equality dummy in one three-cycle, occurs in no edge or other equality/unit relation, and that the selected u is an existing anchored unit. It substitutes d=au into the entire old literal coefficient array and checks equality to the new array. The final checker reconstructs G from its three square differences independently of the producer.

This operation need not preserve height for an arbitrary choice of u. The finite algorithm tests all eligible anchor/unit choices against the complete current coefficient map, chooses deterministically by support then indices, and accepts only height one. Final full expansion checks height, degree, constant and participation of every coordinate. These finite checks, not an unproved collision heuristic, justify the numeric claims.

## 4. New operation: contract an internal tree edge

Let an internal free edge of a row or hub block run from u to v with its independent flow coordinate w and coefficient +1. Write d_u=A+w and d_v=B−w, where A and B do not involve w. Delete w, identify v with u, and redirect every other endpoint v to u. The merged divergence is A+B. All other divergences and all equality/unit penalties are unchanged. A tree contracted at one edge is again a tree; source-block boundary sums are unchanged.

Projection maps every old zero to a new zero, since d_u=d_v=0 implies A+B=0. Given any new zero, uniquely restore w=B. Then d_v=0 and d_u=A+B=0, so this is the inverse on zero sets, entirely over integers. More strongly, for every remaining tuple,

    P_old(w=B)=P_new,

because ½[(A+B)²+0²]=½(A+B)². The restore polynomial B has degree at most two and integer coefficients. Repeating contractions preserves the bijection; restores compose in reverse order.

The implementation only contracts within one block, never across constraints. The independent step checker verifies the exact edge, retained namespaces and quotient graph, then verifies the full literal off-zero substitution identity above. A contraction is accepted only if the full collected new polynomial still has height one; released profiles may additionally require that support not increase. No theorem says that arbitrary edge contractions preserve height.

After contraction, one may repeat same-logical alias identification on the changed graph and rebuild its equality penalties. Both graphs have the same source zero set with the same unique tree-flow construction. Hence this optional renewed contraction also induces a bijection, and its final source/alias/edge semantics are checked directly.

## 5. Universal lift, inverse and consistency transfer

Given any original source tuple x, evaluate every monic constructor. Assign each alias its logical value, units the value one, and any remaining equality dummy its class value. In each block root the internal tree at the first listed vertex. Let b_v be prescribed divergence and let τ_v=±1 be the sign of the tree edge at child v. Put

    w_v=−τ_v∑_(t in the subtree rooted at v)b_t.

Leaf elimination makes all nonroot divergences zero, leaves signed normalized residual T_r at row root r, and leaves −∑T_r at the hub root. All equality and unit penalties vanish universally on this lift, including G because u=1 and a=b. Constructor residuals vanish and original residuals pull back with their certified signs. Thus, for every original tuple, not merely zeros,

    P(L(x))=[∑_j R_j(x)²+(∑_j δ_j R_j(x))²]/2,

where R_j are the original residuals and δ_j their certified row signs. The hub cross term is essential; this is not generally the bare source sum of squares. The checker verifies the symbolic lift at every vertex and exact source pullbacks, so the full composed identity is checked rather than inferred from samples.

Conversely, P=0 forces every nonnegative summand to vanish. Units equal one; C, Q and G force equality of all aliases in each logical class; all divergences vanish. Summing over each row block gives T_r=0. Monic definitions force their intended values, so projection gives an original source zero. Aliases, constructors and remaining equality dummies have unique values, and tree leaf elimination uniquely determines every flow. Canonical lift and projection are inverse bijections on integer zero sets.

Combining with the pinned source calibration, ordinary ZFC proves

    (∃z∈Z^n, P(z)=0) ↔ (there is a finite ZFC refutation),
    (∀z∈Z^n, P(z)≠0) ↔ Con(ZFC).

No consistency assumption is needed for these equivalences. Neither unsolvability nor Con(ZFC) itself is established. No global minimum, exhaustive Pareto frontier, literature priority, or new complete proof-assistant certificate is claimed.
