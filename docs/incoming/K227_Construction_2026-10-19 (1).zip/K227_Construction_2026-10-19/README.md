# K227 construction: 227-state ZFC-consistency machine candidate

The completed canonical candidate is portable/source_fold227_zerofix/candidate.canonical.tm. It has 227 working states, start 0, separate halt 227, a binary alphabet, one two-way tape, and an initially all-zero tape.

SHA-256: 0264f969f006304840f46f85d5eacb54b70bf968669299ff73c3e0c5221fe09a

The report directory contains the eight-page PDF and all LaTeX source. The portable directory contains the exact construction, source/control-flow checks, startup replay, unbounded runtime proof engine, tables, bijections, and pinned K230 source. Read portable/README.md for the complete proof boundary.

From this directory, run:

    python portable/reproduce.py --full --output-dir ../k227-replay

Python 3.10+ standard library is sufficient. Do not use -O for the runtime proof engine. Fresh outputs are written outside the sealed packet.

The theorem established by the new ordinary mathematical proof chain is blank halting iff ZFC proves a contradiction. It composes with Elliot Glazer's released external Rocq calibration for K230. This delivery does not claim a freshly compiled K227 Rocq theorem, an internal PA proof-code endpoint, unconditional nonhalting, or minimality.

All three completed candidates (229, 228, 227) are retained. The rejected seven-zero precursor is described only as a failed intermediate.

compatibility/ records how all eight historical 243-to-235 reductions behave on K230. theory_review/ includes a separate exploratory equality-helper argument; it contributes no additional machine claim and is not required by K227. independent_parent_checks/ records additional input/startup and clean-extraction checks. Historical paths in receipts are provenance, not replay dependencies.

Credit: Elliot Glazer's K theory/K230 construction and Rocq calibration; the ProveIt historical reductions; Jeff Ketchersid, Mira-Cult, Andrew James Wade, BusyCoq, and the retained upstream libraries/notices. See portable/ATTRIBUTION.md and licenses. No repository push or publication was performed.
