SMALL TURING MACHINES AND Con(ZFC): RESEARCH REPORT AND AUDIT ARTIFACTS
Snapshot: 16 October 2026

Read report.pdf for the complete report; report.tex and its section files
are the editable LaTeX sources. This is a research/audit package, not a
claim that the supplied raw 252-state machine solves the consistency goal.

BUILD THE REPORT

With a standard TeX Live installation and latexmk:

    make pdf

Equivalently run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

The complete LaTeX source is included; no external figure assets, network
downloads, bibliography processor or custom fonts are required. The PDF
is already compiled. Numerical evidence can be checked independently of TeX.

MAIN TECHNICAL OUTCOME

The existing raw equality-free CODE calculus admits an explicit,
ZFC-definable heterogeneous-sort interpretation in which every emitted
axiom is valid and target code 1 is false. Its abstract proof enumerator
therefore has a mathematical nonhalting proof formalizable in ZFC. A
ZFC-formalizable simulation of its literal 252-state table would transfer
that proof to the table, preventing the requested Con(ZFC) calibration
if ZFC is consistent. The missing cross-variable logical machinery must
be repaired before pursuing that source as a consistency-machine record.

The independently published 253-state benchmark is included exactly.
Its upstream Coq check was observed in GitHub Actions; no Coq or Lean
build was performed in this report's environment. The endpoint is an
external equivalence with a finite refutation predicate. A separately
specified internal ZFC proof compiler remains a distinct deliverable.

QUICK OFFLINE VERIFICATION

From this directory, with Python 3.10 or later and no extra packages:

    python verify.py

Run with assertions enabled. The verifier and regression programs refuse
python -O and -OO, which would otherwise skip their assert-based checks.

The command checks pinned source and table hashes, binary table structures,
graph reachability, exact regeneration of the 253 table from 254, exact
normalization of the raw 252 table, the countermodel's finite transcription
regressions, and byte-for-byte regeneration of the three frozen compiler
recipes (raw252, atomic-instantiation diagnostic259, profile diagnostic264).
It writes compiler intermediates only in a temporary directory. It does
not run a proof assistant, download anything, or alter the pinned inputs.

To additionally repeat all 288 sampled diagnostic compilations and the
seven newer PSC fixed recipes with their core checks:

    python verify.py --full

To save a fresh verification record at an explicit path:

    python verify.py --full --output /tmp/zfc-report-verification.json

If a finalized report-wide SHA256SUMS is included, optionally check it too:

    python verify.py --all-hashes

WHAT IS INCLUDED

machines/zfc_253.tm
    Exact external 253-state machine, 506 transitions, start0/terminal253.
    PR20 head 0d544f2a2e3c18f12278441a74b7879f31cbe856. The observed CI job
    checked its synthetic merge into the pinned upstream base.

machines/zfc_254.tm
    Mira-Cult's original 254-state machine, 508 transitions, as preserved
    by jeff87654/busy-beaver at 297ab8df7e5de329605c3875b4934643b371a5e3.

machines/raw-candidate-252.tm
    Exact ProveIt normalized raw candidate, 504 transitions. Uncalibrated;
    the emitted abstract calculus has the countermodel described above.

machines/raw252-named.tm
    Exact public-backend output before numbering/totalization, retained
    so the compiler recipe and normalization can both be reproduced.

machines/diagnostic-U-259-named.tm
    Uncalibrated control adding (forall c, c in a) -> b in a.
    Best sampled layout: C AND (U AND (V AND G)); 197+62 states.

machines/diagnostic-P-264-named.tm
    Uncalibrated control adding
      [forall c, (c in a <-> c in b)] -> [a in c -> b in c].
    Best sampled layout: C AND ((P AND V) AND G); 202+62 states.

Both controls retain rho8,rho2,rho4,dual-rho6, base-three formula coding,
the existing c!=a,b gate and the public Wade compiler. Each excludes the
displayed countermodel; neither has a proof of full logical completeness
or consistency calibration. P is an additional profile-congruence
principle, not a validity of arbitrary nonextensional membership.

The numeric tables are complete binary, one-tape, blank-input machines
with L/R moves and a distinct uncounted terminal. Every initializer and
helper is counted. The named tables preserve the compiler's single missing
edge, 1.inc/read1, which halts in that format. Completing it by write1,R,halt
adds no working state and preserves halting and the final tape; it adds
one final head move. The normalized raw table includes exactly this row.

code/
    Countermodel transcription/regression code, the diagnostic cost
    experiment, and an independently written 253-table regenerator using
    the published numeric bijection and four transition edits.

vendor/proveit/
    A small, byte-exact source subset at ProveIt commit
    83dec60c249ca0f9e1b2e5ee3cf18fd1ce58c373, preserving its relative layout.
    It includes three MIT-0 reconstruction scripts and the minimal pinned
    public backend and functional DAG/AX-spec inputs that they require.
    It is not a full checkout, Coq library or Lean build environment.

evidence/
    Source/table manifests, technical status ledger, exact finite-regression
    results, every sampled diagnostic recipe/cost, and a short exact excerpt
    of the observed upstream 253 CI log with the full decoded log's hash.

supplement/psc-e7c4cadf/
    A dated audit of ProveIt commit e7c4cadf9b180e4b1801755b09777a7572412360
    (19:44:39 UTC), with exact new sources, comparison evidence and a
    DIFFERENT named partial 252-state PSC experiment. Its table hash starts
    76af4b70, whereas the normalized raw C/G table starts 58f8aab7. Both
    calculi are inadequate for the requested consistency calibration.
    All seven fixed recipes and core checks were independently reproduced;
    the upstream 144-variant and 200-seed searches were not rerun. --full
    repeats the seven fixed recipes, not those optional search families.

The default verifier checks exact named diagnostic recipes; --full searches
all 120 component-order/bracketing layouts per control at one logical
order, then all 24 logical orders on the first best bundle. This is a
288-compilation sample, not a complete search over every combination and
not a lower bound on machine size.

STANDALONE REGENERATION

    python code/regenerate_253.py

The following also works entirely offline with the packaged subset:

    python code/repair_cost_experiment.py \
      --repo vendor/proveit \
      --backend /tmp/zfc-repair-backend \
      --output-dir /tmp/zfc-repair-tables \
      --results /tmp/zfc-repair-results.json

The repair script creates any missing pinned backend files in the explicit
backend directory, and refuses existing files whose bytes differ. It does
not modify the vendored snapshot. Numerical results are reproducible;
elapsed times and explicitly selected output paths naturally vary.

PROVENANCE AND RIGHTS

Consult NOTICE.txt and evidence/source_manifest.json. Mira-Cult's machine,
Jeff's verification, the PR20 reduction, Andrew James Wade's backend, and
ProveIt's experiments are separately attributed. No upstream-wide license
is assumed or granted by this report. The original Wade MIT-0 license and
the ProveIt MIT-0 license are retained with their respective source subsets.

No full incoming research archives, upstream proof library, compiled proof
objects, private credentials, or unverified install environment is included.
