# Causality Without Tableaux
## Compact Diophantine Certificates for Queue Universality

Research article prepared for Vladimir Reshetnikov, September 30, 2026.

The package contains the article in editable LaTeX and PDF, exact-integer
polynomial compilers, an independent certificate evaluator, reproducible tests,
and explicit positive and negative examples. All existential coordinates are
nonnegative integers; polynomial evaluation uses signed integers.

## Main results

For a cyclic-tag program, fixed input and endpoint, and a positive horizon T:

- The causal stream polynomial uses T consumed-bit variables and one uniquely
  determined guard slack. It has degree at most max(4, 2T), T+3 residuals, and
  a linear-size arithmetic circuit for a fixed program.
- A zero-slack version uses only T variables but a larger bounded-root guard.
- A local first-emptying polynomial is quartic, with 3T-2 variables and 3T
  quadratic residuals.

For deletion-d tag systems over B symbols, the compiler uses dT+1 variables,
with explicit integer denominator clearing. The article also proves a
consumed-symbol-plus-one construction for fixed-read FIFO networks. A full
network-table compiler is not included; the supplied compilers implement the
cyclic-tag and general one-queue deletion-tag specializations.

A separate theorem proves that faithful word memory with polynomial insertions
at both ends needs at least two natural-number coordinates. Two affine
coordinates suffice. This is an architectural restriction, not an obstruction
to scalar computation with conditional, division, or other nonpolynomial rules.

The horizon T is a parameter of the construction. These results are not
fixed-arity finite-fold or single-fold representations of unbounded halting.
The exact constructions have mathematical proofs and tested code; they are not
new Lean/Rocq kernel-checked theorems. Global historical priority is not claimed.

## Files

```
article.tex                         self-contained LaTeX, including bibliography
article.pdf                         compiled research article
code/queue_certificates.py          cyclic-tag and deletion-tag compilers
code/compile_tag.py                 general tag JSON-specification front end
code/verify_certificate.py          independent exact certificate evaluator
tests/run_tests.py                  exhaustive and seeded finite checks
tests/results.json                  actual reproducible test results
examples/stream_example.json        T=3 stream certificate, four variables
examples/quartic_example.json       same computation, seven-variable quartic
examples/zero_slack_example.json    same computation, three variables
examples/uncausal_counterexample.json  word balance without a legal execution
examples/ternary_tag_spec.json      a 2-tag program over three symbols
examples/ternary_tag_example.json   its five-variable certificate
notes/lean_integration.md           proposed formalization, not completed proofs
notes/provenance.md                 source snapshot and verification boundaries
Makefile                            optional build/test conveniences
```

## Run the exact checks

Python 3.10 or later is sufficient. No third-party Python packages are needed.
Run commands from this directory:

```text
python tests/run_tests.py
python code/verify_certificate.py examples/stream_example.json
python code/verify_certificate.py examples/quartic_example.json
python code/verify_certificate.py examples/zero_slack_example.json
python code/verify_certificate.py examples/ternary_tag_example.json
```

The suite checks 92,610 cyclic-tag candidate bitstrings; 194,940 general-tag
candidate words; 79,631 natural assignments in finite quartic test boxes;
5,916 resource histories; and the additional categories in results.json.
It detects 268 globally balanced but causally invalid candidate executions.
It also checks the full integer-only general-tag compiler on 120 instances
and 4,200 candidate words, including exact interpolation clearing.

Finite tests support the implementation. They do not replace the article's
proofs of soundness, completeness, uniqueness, and the memory lower bound.

## Construct a cyclic-tag certificate

The following command works as a single line in common shells. The empty
quoted string is the second appendant:

```text
python code/queue_certificates.py --appendants 10 "" --initial 1 --time 3 --mode stream --output examples/custom.json
```

Replace `stream` with `quartic` or `zero-slack` for the other constructions.
By default the program also simulates the bounded run to attach a witness
when the requested endpoint is reached. Add `--no-witness` to construct only
the polynomial without running the tag system. The polynomial is identical
in either mode.

The CLI requires T >= 1. For T = 0 the mathematical construction is simply
constant 0 for equal initial and terminal words, and constant 1 otherwise.
The cyclic-tag CLI targets the empty endpoint. The Python `compile_stream`
function also accepts a fixed nonempty terminal word.

## Construct a general deletion-tag certificate

```text
python code/compile_tag.py --spec examples/ternary_tag_spec.json --output examples/custom_tag.json
```

The specification contains arrays of integer digits, one appendant for each
symbol. Its alphabet size is the number of appendants. Example:

```json
{
  "appendants": [[], [2, 0], [0]],
  "deletion": 2,
  "initial": [1, 0],
  "terminal": [0],
  "horizon": 2
}
```

It denotes the execution `10 -> 20 -> 0`, halting with a one-symbol tail.
The consumed symbols are `[1, 0, 2, 0]` and the guard slack is 3.
`--no-witness` is supported here as well.

## Polynomial JSON format

`variables` lists all and only the existential coordinates. The topologically
ordered `nodes` are deterministic polynomial subexpressions, not additional
witnesses. Operations are `var`, `const`, `add`, `sub`, and `mul`.
`residual_roots` selects the residuals. Their sum of squares is the ordinary
integer polynomial denoted by the file. Coefficients and witnesses are decimal
strings to preserve arbitrary-size integers across JSON implementations.

The verifier checks syntax, degree bounds, nonnegative witnesses, and exact
zero evaluation. It does not solve arbitrary Diophantine equations or certify
semantic correctness of an arbitrary untrusted compiler output. Those stronger
properties for the provided constructions are established mathematically in
the article. A formal reflection bridge is proposed, not supplied.

Degree bounds from the DAG are conservative. The stream example reports 6;
its simplified polynomial in the article has degree 4 after cancellation.

## Rebuild the article

A standard pdfLaTeX installation with AMS packages, Latin Modern, microtype,
hyperref, xurl, tocloft, and the other packages listed in article.tex suffices.
Run twice:

```text
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

No BibTeX step, external figure, or bundled font file is required.

## Repository context

The ProveIt snapshot inspected for this article is
`725d2ebb6909fe11a13a92354c0f47367a3cbbf5`.
See the bibliography and notes/provenance.md. No changes were pushed to the
repository, and no repository Lean build was executed for this package.
