# Frozen boundary theorem dependency

`three-core-rayleigh-result.zip` is the complete approved boundary-theorem release, unchanged. Its SHA256 is 718fcbed392be1520ad2fe09313ff18b10b38a5338f5a704cbad2cf7b7b8c488.

The nested ZIP contains editable TeX, a six-page PDF, full coefficient-localization proof notes, two independent exact boundary checkers and all histograms, the four-core obstruction, audit receipts, and a read-only `verify.py`. The outer supplement's driver extracts this archive into a temporary directory and replays all four of its checkers before checking the new assembly.

The PDF beside this file is a convenience copy. The accompanying release-replay approval records the original independent clean-extraction validation. No files of that earlier release have been edited.
