# Rank ultra log concavity under a three vertex physical cover

This standalone proof supplement establishes rank-ULC at the actual surviving degree for every finite loopless directed relation whose underlying physical graph has a vertex cover of size at most three. Internal core arcs are arbitrary, opposite arcs are allowed, and independent nonnegative tail/head activities are retained. Each feasible ordered disjoint endpoint support is counted once.

In particular, the theorem covers the two-tail/three-head role-cover case where both selected physical tail vertices lie among the three selected head vertices. It is not restricted to preorders.

## Proof structure

The only computational dependency is the already approved three-core bipartite boundary theorem. The new internal-core assembly is an ordinary argument:

- Delete internal arcs and use the boundary inequalities for a_i, b_ij, c
- Let H count size-two supports using all three core vertices, and w_ij count their witnesses using internal pair {i,j}
- Prove each w_ij≤H and their sum≤2H, without treating duplicate witnesses as different supports
- Order the three b-values and use the exact nonnegative decomposition displayed in the paper
- Use the universal first-gap argument at the actual degree, including zero-weight degree drops

A separate, explicitly bipartite-only section gives strict negative correlation by positive-weight connected components and the equality characterization for the upper cubic Newton inequality. Those conclusions are not extended to internal core arcs.

## Files

- `article/physical-cover-three.pdf`: typeset supplement
- `article/physical-cover-three.tex`: editable source
- `proof-notes/`: reviewed assembly and strictness source snapshots
- `audits/`: independent assembly review and integrated approval of the full paper, including both strictness results
- `dependency/three-core-rayleigh-result.zip`: the complete previously released boundary theorem package, preserved byte for byte
- `dependency/three-core-rayleigh.pdf`: a convenient readable copy of its manuscript
- `reproducibility/`: new producer and independent assembly checkers with exact receipts
- `qa/visual-qa.json`: inspection record for every final supplement page

The nested dependency ZIP has SHA256 718fcbed392be1520ad2fe09313ff18b10b38a5338f5a704cbad2cf7b7b8c488. It contains the complete 48-type/17,376-graph localization proof, both independent finite checkers, all coefficient histograms, source, audits, and its own read-only verification driver. No earlier frozen release was modified.

## Replay

Python 3.10 or later, standard library only; tested with Python 3.12.14:

    PYTHONDONTWRITEBYTECODE=1 python3 verify.py

The driver checks all release hashes, safely extracts the frozen dependency into a temporary directory and runs its complete replay, then runs temporary copies of the two new assembly checkers. It compares every deterministic receipt field, excluding elapsed times only. No released file is overwritten.

The independent assembly audit checks all 4,096 one-exterior directed graphs for witness multiplicity, 1,600 compatible three-exterior graph cases for the forced-removal inequality, and 10,080 exact integer/zero-activity evaluations for the full assembly. The producer separately verifies 10,496 weighted cases and the exact nonnegative decomposition. These new tests corroborate the ordinary all-size assembly proof; they are not a bounded-population assumption.

Rebuild the PDF with a normal TeX Live or MiKTeX installation:

    sh build.sh

Rebuilding may change PDF metadata and hashes; use a copy if preserving the released bytes matters.

## Boundaries

The result is actual-degree ULC, including degree drops. It does not assert real-rootedness, signed-monomer stability, or negative correlation when internal core arcs are allowed. The general two-tail/three-head problem with four or five physical core vertices remains open. The weights are independent vertex-role activities, not arbitrary independent edge weights.

No theorem is inferred from random search; no proof-assistant verification, literature-wide priority claim, or external publication is asserted. Seeded randomized cases are included only as corroborative checks of the ordinary assembly proof. Source snapshots retain their original status headings where an approval receipt pins their bytes; the later approval receipt is the final review status.
