#!/bin/sh
set -eu
cd "$(dirname "$0")/article"
pdflatex -interaction=nonstopmode -halt-on-error physical-cover-three.tex
pdflatex -interaction=nonstopmode -halt-on-error physical-cover-three.tex
printf '%s\n' 'Built article/physical-cover-three.pdf'
