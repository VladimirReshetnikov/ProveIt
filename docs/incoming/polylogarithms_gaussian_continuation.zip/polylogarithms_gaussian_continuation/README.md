# Gaussian double polylogarithms: research continuation

**Article:** `article.pdf` (23 pages), with editable source `article.tex`.

This package continues Chapter 4 of the ProveIt polylogarithm manuscript at
commit `afed07429d3d37eceb6c8e9e54cf4da2d3f39d53` (9 October 2026 research snapshot).
It is additive: nothing here automatically changes the original repository.

## Main results

The article proves the source's weight-five Gaussian relation and all five
weight-six reductions. The former has the explicit shuffle certificate
`960 R_(1,4) - 224 R_(2,3)`; the latter follow from a branch-safe specialization
of Panzer's known parity theorem. The package generates 64 exact even-weight
formulas through weight 16 and proves a same-point shuffle rank/inverse theorem
in every weight.

The main analytic development is a signed-density representation of
`Li_(a,b)(z,1)`. It proves one simple zero of its imaginary part in the upper
unit semicircle, lying below pi/2, for every integer a >= 1 and real b > 0.
It also proves a four-term zero asymptotic, uniform for b >= 1; an exact,
one-sided Euler enclosure for all integer-index Gaussian values; and a sharp
Euler-error asymptotic with a leading coefficient depending only on weight.

The S4 identity remains a conjecture. Its difference from the proposed right
side is rigorously enclosed in [-10^-118, 10^-118]. A rational separating vector
proves that the target is outside one precisely defined depth-two linear
relation module, not outside all possible polylogarithm relations. The all-odd-
weight rank pattern is also conjectural; it is checked exactly through weight 31.
No independence of surviving numerical periods is claimed.

The parity principle and Euler transformation are established tools, not
novelty claims. Exhaustive priority for the specific analytic formulations is
not asserted. Detailed references and the mathematical proofs are in the article.

## Reproduce

Python 3.10 or newer is expected; the recorded run used Python 3.13.5,
SymPy 1.14.0, and mpmath 1.3.0.

```sh
python -m pip install -r requirements.txt
python code/verify.py
python code/numerics.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The exact suite passes **588 check cases**, including independent rational
interval comparisons for **all 64 generated formulas**, at 400 Euler terms.
The recorded exact-suite runtime is an environment-specific measurement, not
an algorithmic benchmark. See `data/verification_summary.json`.

For a higher-precision replay:

```sh
python code/verify.py --terms 512 --max-weight 16 --rank-max 31
```

`--max-weight` is between 2 and 16; the 64 symbolic formulas are always exported,
while this option controls how many receive the independent interval comparison.
The rank census checks odd weights up to `--rank-max`. Regeneration updates data
and runtime receipts, so it also invalidates the delivered checksum manifest.

A PDF build needs a TeX installation with pdfLaTeX, latexmk, newtx, amsmath,
amsthm, mathtools, microtype, geometry, booktabs, longtable, array, xcolor,
enumitem, fancyhdr, listings, hyperref, and bookmark. `make article`,
`make verify`, and `make numerics` provide equivalent shortcuts.

## File map

| Path | Contents |
|---|---|
| `article.tex`, `article.pdf` | Complete research article, proofs, references, ten research directions |
| `code/gaussian.py` | Signed-Euler evaluator, rational interval arithmetic, parity coefficient compiler, kernel polynomials |
| `code/full_ds.py` | Precisely specified level-four depth-two relation matrices and S4 separating vector |
| `code/verify.py` | Exact algebra, rational enclosures, matrix ranks, table and certificate generation |
| `code/numerics.py` | Separate 120-digit numerical diagnostics for asymptotics and illustrative zeros |
| `data/even_weight_reductions.json` | All 64 even-weight formulas; atoms `B2 = beta(2)`, `Z3 = zeta(3)`, `L = log(2)`, etc. |
| `data/even_weight_tables.tex` | Line-broken LaTeX fragment for the same 64 formulas; requires amsmath |
| `data/gaussian_interval_certificates.json` | Outward-rounded rational enclosures for each formula and its original series |
| `data/weight_five_certificate.json` | Exact shuffle combination and interval comparison |
| `data/weight_seven_identities.json` | Two additional identities with exact shuffle coefficient vectors |
| `data/s4_interval_certificate.json` | Rigorous small discrepancy for the still-conjectural S4 relation |
| `data/s4_linear_module_obstruction.json` | Complete integer matrix, coordinate order, target, and rational witness |
| `data/formal_rank_data.json` | Exact odd-weight rank census, weights 3 through 31 |
| Other `data/*.json` | Numerical diagnostics, zero tables, and run summaries |
| `integration/` | Additive manuscript fragment, bibliography items, and source-label map |
| `INTEGRATION.md` | Recommended integration steps and explicit non-upgrades |
| `RESULTS.md` | Theorem/conjecture/evidence ledger |
| `PROVENANCE.json` | Pinned repository source identifiers and literature consulted |
| `VALIDATION.md` | Executed checks, PDF build, and visual-review record |
| `MANIFEST.sha256` | Checksums of the delivered files, excluding the manifest itself |

## Evaluation contract

The Gaussian enclosure is `[E_N - C_b*2^-N, E_N]`, with `C_1 = 1` and
`C_b = b/(b-1)` for integer b >= 2. Every internal endpoint is a `Fraction`.
Decimal strings are rounded outward; their printed number of decimal places
is not a claim that every displayed right-side digit is uniquely determined.

The depth-one right sides use their own rational enclosures. Pi and log(2)
converge faster than the Euler sums; conservative integer term allocations
avoid excessive precision while retaining rigorous bounds. No floating-point
arithmetic is used by the certificate engine.

Interval overlap is a diagnostic, not proof of an identity. The proofs are in
the article. The numerical root table is expressly not a certified root table.
The code is not a Lean proof and does not assert period independence.

## Integration

Read `INTEGRATION.md` before changing the manuscript. In particular, retain
candidate status for `gauss:eq:S4-closed` and the unaddressed triple reductions.
The package does not push commits, overwrite the chapter, or claim to reproduce
all historical experiments in the source manuscript.
