# Report 134: one classical 1234 occurrence

This is the offline reproducibility companion to `Report134.pdf` and its
self-contained LaTeX source `Report134.tex`. Python 3.10 or newer is required;
all arithmetic and packaging code uses only the standard library. Rebuilding
the PDF additionally requires `pdflatex` and the packages named by the TeX source.
No network access, third-party PDFs, or external data files are needed.

## Tested dependency versions

The release tests used Python 3.12.14; pdfTeX
3.141592653-2.6-1.40.26 (TeX Live 2025/dev/Debian); kpathsea 6.4.0/dev;
LaTeX2e 2024-11-01 patch level 2; and L3 programming layer 2025-01-18.
The article class was 2024/06/29 v1.4n. Direct LaTeX dependencies and observed
versions were geometry 5.9, fontenc 2.0v, lmodern 1.6.1, microtype 3.2a,
amsmath 2.17t, amssymb 3.01, amsthm 2.20.6, booktabs 1.61803398,
TikZ/PGF 3.1.10, and hyperref 7.01l. Their ordinary transitive TeX packages
and Latin Modern/Computer Modern/AMS fonts are also required. The build command
explicitly loads cm.map, cmextra.map, symbols.map, and lm.map. No Python package
installation is needed. These identify the tested environment; they do not
pin or automatically install an entire operating-system image.

## What is certified

The report proves a positive convergent series for the limiting ratio of
one-occurrence permutations to 1234-avoiding permutations. The finite computation
here is an exact rational lower bound, not a numerical estimate of that limit:

    L_(40,10) =
    6958884420052382006187220194732220723168380665062 /
    13915193059764305937984450503671774362956903094027
    > 50009/100000 > 1/2.

Every comparison uses integers or `fractions.Fraction`; floating-point rounding
is never used for a pass/fail decision. The software checks finite identities;
the asymptotic proof, convergence, and combinatorial bijections are established
in the report, rather than inferred from finite tests.

## Offline replay

Run from any directory. Replace `BUNDLE` with this directory and `OUT` with an
existing external directory. Every output target below must be absent.

    python -I -B BUNDLE/verify.py check
    python -I -B BUNDLE/verify.py replay --output OUT/replay
    python -I -B -O BUNDLE/verify.py replay --output OUT/replay-optimized
    python -I -B BUNDLE/verify.py selftest --output OUT/selftest
    python -I -B BUNDLE/verify.py pack --output OUT/Report134.zip
    python -I -B BUNDLE/verify.py build --output OUT/pdf-build

`-I` isolates the interpreter from environment and import-path injection;
`-B` additionally disables bytecode files (the script also disables them).
All guards are explicit exceptions, so `-O` does not remove checks. No command
imports or executes companion code before validating the complete inventory
and hashes. Companion modules execute from the verified in-memory bytes.

Replay reconstructs every required boundary matrix through size 42 twice:

- `certificate.py`: hook dimensions and interlacing horizontal-strip removals
- `independent.py`: Young-lattice partitions, recursive corner-removal tableau
  dimensions, and actual removed-cell column tests, with no hook formula

The complete matrices and half arrays must agree. Each path also reconstructs
the full T=40, I=10 rational certificate: one factors the finite boundary sums,
and the other directly sums the two-index kernel. All 41 partial certificates
must agree. Checks include nonnegativity and zero extension of H, strip bounds,
a Cauchy/Pieri diagonal bound, and closed boundary generating-function
coefficients through index 49. The positive-series first term must be 35/324.
The unrestricted-boundary sum through t=40 is reported as a lower bound only;
no error bound or decimal estimate of the infinite amplitude is claimed.

Replay compares n=0..15 with the frozen OEIS A217057 values. The source is
<https://oeis.org/A217057>, retrieved 2026-10-02; `fixtures.json` records the
sequence identifier, offset, URL, date, description, and exact integer data.
The required n=4..15 range is included. These are a transcribed numeric fixture,
not a bundled third-party document.

Literal permutation enumeration through n=8 checks the classical pattern by
four-position subsets, every F boundary entry, northern-half counts, the twelve
allowed cells, decreasing central cells, and each ordered gluing fiber including
both binomial shuffle factors. Add `--max-permutation-n 9` for the longer test.
Selected arithmetic mutations exercise omitted shuffle factors, a reversed half
subtraction, loss of the horizontal-strip condition, an omitted endpoint factor,
a shifted boundary index, and a wrong series denominator. These finite checks
are diagnostic evidence, not replacements for the report's proof.

Replay can take several minutes, depending on hardware. It writes a deterministic
`replay-result.json`; ordinary and `-O` runs with the same permutation cutoff
should be byte-identical. A failed run may leave a new, incomplete external output
directory for diagnosis. It never replaces a previous result.

## Closed inventory and output safety

The bundle is flat and must contain exactly these eight regular files:

    README.md
    Report134.pdf
    Report134.tex
    certificate.py
    fixtures.json
    independent.py
    manifest.json
    verify.py

The verifier rejects any extra or missing file, directory (even empty), symlink
(including broken links), or nonregular entry. Manifest file names are also a
closed set; duplicate JSON keys are rejected. Fixture schemas are closed at every
level: provenance strings must match exactly, and every count, offset, cutoff,
and threshold must be a JSON integer, with booleans and floats rejected even
when Python would otherwise consider them numerically equal. Every normal
command validates both hashes and these typed fixture schemas. SHA256 and byte lengths cover every
payload file, including the verifier itself, with the manifest necessarily
excluded from its own digest. The manifest is a corruption detector, not a
cryptographic signature or an assertion of third-party authenticity.

Normal commands never write inside the bundle. Before computation they reject an
existing output target, output within the bundle, parent traversal, and any
symlink in the lexical output path or its ancestors. Output parents must already
exist. Output creation uses exclusive mkdir/open, with another ancestor check
immediately before creation. Inputs likewise reject symlink ancestors. This is
not a claim of race-proof isolation against a concurrently hostile filesystem;
run in a directory you control and do not mutate the bundle during execution.

`selftest` works entirely on newly created external copies. It tests ordinary
inventory/hash corruption and rejects extra files/directories, symlinks, broken
symlinks, a FIFO where supported, missing PDF, changed fixture, manifest missing
or extra records, duplicate JSON keys, and unsafe/existing output paths under
`python -O`. It also verifies deterministic ZIP repacking after fresh extraction.
Additional fixture regression tests recompute the local test manifest and still
require rejection of extra nested keys, wrong provenance/description, and
bool/float count, offset, cutoff, or threshold substitutions. Thus these tests
exercise schema validation rather than only changed-file hashes. The arithmetic
replay is separate, so run both commands.

## Deterministic ZIP and PDF build

`pack` fixes ZIP entry ordering, names (`Report134/` prefix), timestamps, Unix
regular-file permissions, and metadata. It uses ZIP_STORED so a different zlib
version cannot change compressed bytes. No directory entries or external output
files are included. Fresh extraction followed by `pack` must produce the same
ZIP bytes, regardless of extraction timestamps or directory name.

`build` copies only the verified TeX source into a new external directory and initializes an external pdfLaTeX format, then runs
`pdflatex` twice with shell escape disabled, UTC, and SOURCE_DATE_EPOCH=1790899200
(2026-10-02 00:00:00 UTC). Build logs, auxiliary files, and explicitly redirected TeX caches stay there. The final TeX log is rejected for overfull boxes, missing characters, unresolved
references/citations, duplicate labels, or a requested additional label pass. The result
JSON says whether the PDF bytes match the frozen PDF. Exact PDF reproduction may
require the same TeX engine, fonts, and package versions; byte-identical ZIP
repacking does not require a TeX rebuild.

## Intentional maintainer seal (not an ordinary replay command)

After the final report source and PDF have been placed in the flat inventory,
and after all software edits are complete, run exactly once:

    python -I -B BUNDLE/verify.py seal
    python -I -B BUNDLE/verify.py check

`seal` is the one intentional in-bundle write. It requires the seven payload
files and no manifest or other entries; it exclusively creates `manifest.json`.
It will not overwrite or reseal an existing manifest. To revise a release, use a
separate controlled working copy, explicitly remove its old manifest, review all
changes, and seal that new release. Never reseal a corrupted distributed bundle
to make a verification failure disappear.

After sealing, test a copied bundle whose files are read-only (and directory is
non-writable), run both replay variants and `selftest` with external outputs,
then `pack`. Do not add logs, build products, Python caches, test outputs, or the
ZIP to this directory: the strict inventory will reject them.
