# Report281 Explicit uniform density square extraction

The article proves a single explicit sufficient threshold N0(a0)=ceil((8/c(a0))^(1/gamma(a0))) uniformly over 0<a0<=a<=1. It retains the actual density a in both quantitative outputs. At that same threshold the selected short-parent construction yields side k>=D(a)N^(4 gamma(a))-1 with D(a)>1/2, hence k>=N^(3 gamma(a)), and mass at least 2^-137 a^704 k^2.

The scalar threshold comparisons and geometric lemmas are proved in article.tex and Report281.pdf. The initial analytic extraction and all-scale coefficient results are imported explicitly from the frozen source. The basic density-uniform square theorem is already upstream. This is a mathematical refinement, not a new Lean implementation, a priority claim, an arbitrary-witness catalogue repair or a global Szemeredi bound.

## Offline verification

Requires Linux, Python 3.11 or later, and a TeX Live installation providing pdftex, pdflatex, Latin Modern, amsmath, amssymb, amsthm, mathtools, geometry, microtype, enumitem, booktabs, longtable, array, xcolor and hyperref. No Python packages, network calls or repository checkout are needed. The curated Lean files are for source inspection and hashing, not a standalone Lean build.

From the Report281 directory:

    python3 -I -B build.py verify
    python3 -I -B build.py reproduce --output /tmp/report281-rebuild

The output directory must be new or empty, absolute, outside the source tree, and not an ancestor of it. Choose a different fresh path for each run. The builder refuses protected system locations, symlinks, hard-link aliases, nonregular entries and any source inventory not on its exact allowlist. It never overwrites an output. Tests run in isolated staged copies, normally and with -O, with a 640-digit integer conversion cap and bounded process logs and timeouts. Validation uses explicit exceptions rather than Python assert statements, so optimization cannot disable it.

A successful build writes the PDF, the deterministic ZIP, a ZIP SHA-256 sidecar, a payload MANIFEST.sha256 and an external reproduction_receipt.json. Build logs and the staged working directories remain outside the distributed payload. The builder compares original and staged source inventories after each test invocation, including failures. It refuses to proceed after mutation or differing normal/optimized stdout.

The internal manifest covers every public payload except itself. The external sidecar covers the actual ZIP bytes. ZIP ordering, paths, timestamps, file modes, compression and bytes are deterministic. The archive root is Report281/. A manifest is an integrity mechanism, not a mathematical certificate or author authentication.

## PDF reproducibility

The reference build uses Python 3.12.14 and pdfTeX 3.141592653-2.6-1.40.26 (TeX Live 2025/dev/Debian), with the installed font and package files. SOURCE_DATE_EPOCH is fixed to 1791331200. PDF dates, trailer identifiers and path metadata are suppressed. Shell escape is disabled; TeX file policies are restrictive. The second pass must contain no overfull boxes, unresolved references, missing citations or rerun warning.

A replay from the pinned distribution requires the regenerated PDF to have the same SHA-256 as the bundled PDF. Different TeX package/font releases may produce a mismatch even when the mathematical content is unchanged. Preserve the supplied distribution and inspect the build logs/toolchain rather than replacing its manifest to disguise a mismatch. The provided source can still be compiled in a separate personal copy if bit-for-bit identity is not needed.

To repack the already verified distribution without compiling:

    python3 -I -B build.py package --output /tmp/report281-repack

## Companion scope

The standard-library companion checks exact exponent identities, 19 all-range coefficient certificates, natural floor/ceiling inequalities and bounded finite geometry. Its fixed diagnostics include 7,632 floor/half cases, 3,824 floor/predecessor cases, 2,056 ceiling cases, 372 short-parent cases, 2,776 rectifications, 3,503 balanced chain partitions, 3,813 aligned parent partitions, 2,079 endpoint-contained covers, 16,150 square fits and 25 exact mass-averaging cases. It also checks clean triple-exponent absorption on exact rational samples. These are finite regression diagnostics, not proofs of the universal mathematical statements.

No astronomical parameter is evaluated, expanded or approximated by floating point. Exponent identities are checked symbolically, and evaluated binary powers have bounded small exponents. The CLI has no parameter overrides. Importable helpers validate their types and bounded ranges; booleans and invalid or oversized models are rejected. Validation uses explicit exceptions, never optimization-removable assertions.

The provenance verifier checks 23 files against exact byte lengths, SHA-256 digests, Git blob SHA-1 digests, canonical repository paths and pinned URLs. It validates the observed-commit and comparison-note record syntax, but does not reperform remote comparisons or certify the mathematical claims in those notes. No network access is used by a build. The source snapshots are sufficient to inspect the cited interfaces; they are not a standalone Lean project or a claimed dependency build.

No repository file was modified or uploaded. The payload contains only the article, reproducibility code/tests and 23 relevant source snapshots with curated provenance. Private research notes, reviews, full third-party papers and raw connector responses are excluded.
