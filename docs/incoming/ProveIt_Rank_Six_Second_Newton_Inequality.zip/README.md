# The Second Newton Inequality at Rank Six

For every bipartite graph of matching rank six with unit left activities and
arbitrary positive right activities, the report proves 8 p2^2 >= 15 p1 p3.
For a genuine 3+3 cover it proves a stronger degree-three Lorentzian marginal
truncation. The general third and fourth rank-six Newton gaps remain open.

The report includes an exact 25-vertex obstruction to the analogous degree-five
Lorentzian route. That obstruction does not refute scalar ULC6.

## Full exact replay

Requirements: Python 3 and SymPy. All polynomial arithmetic is exact. From this
directory run:

    python -O verify.py

The default recomputes all 61 rooted core profiles and all 51 exterior-basis
cones per profile, comparing every coefficient-list hash, count and minimum.
It may take tens of minutes on one processor. The delivered proof was checked
by two independently written reconstructions, agreeing on all 50,037,694
coefficient entries. No floating-point tolerance is used.

A shorter integrity and sample reconstruction is available:

    python -O verify.py --quick

The quick mode runs all auxiliary identity checks and reconstructs one complete
core profile. It checks the records of the other 60 full reconstructions, but
does not recompute their coefficient arrays. It is explicitly not a fresh full
replay.

## Contents

- article.pdf and article.tex: the report and editable source
- verification/core_schur_manifest.json: all primary profile records
- verification/core_schur_J_C1_C2.json: exact normalization and 51 cone hashes
  for each of the 61 rooted cores
- verification/build_core_schur_certificate.py: the original exact generator
- verification/core_R_block_inverses.json: exact rational R-block inverses
- verification/independent/: the independently written Hall reconstruction,
  finite class-compression checks, complete replay records and finalizer
- verification/check_core_endpoint_formulas.py: direct endpoint-state checks
- verification/check_zero_core_schur.py: all 64 empty-column Schur identities
- verification/check_fifth_truncation_barrier.py: the exact stronger-route barrier
- prerequisites/: the unchanged PDFs and full source archives of the two
  structural inputs used by this report
- VERIFICATION.md and SHA256SUMS: scope and integrity information

The primary batch runner preserves its original resume-by-existing-record
behavior and is included as provenance. Use verify.py for a full proof replay;
its independent reconstruction recomputes every profile by default. All checks
use explicit exceptions and remain active under optimized Python.

Ordinary TeX installations can build article.tex with pdflatex twice. The local
helper build_local.sh supplies explicit paths for the original build environment.
No Lean formalization, formal proof-kernel verification, external referee
endorsement or exhaustive priority claim is made.
