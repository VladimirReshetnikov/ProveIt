CONDITIONAL PHASE COEXISTENCE FOR TOURNAMENT SCORE SEQUENCES
Giant blocks, Gamma laws, and stable fluctuations
Research manuscript dated 3 October 2026

START HERE

Open tournament_coexistence.pdf for the complete 25-page article.
tournament_coexistence.tex is the corresponding LaTeX source.
The archive includes all figures needed to compile the article and all
programs and recorded data needed to reproduce its numerical examples.
No ProveIt checkout or network access is needed to read or compile it.

RESEARCH CONTRIBUTION

The article continues the report "Tournament score sequences and weighted
component asymptotics: Explicit corrections and uniform inverse models"
in VladimirReshetnikov/ProveIt at the commit recorded in provenance.json.
It addresses that report's explicitly open conditional component-law
question for OEIS A000571 and A351822.

The main results identify a logistic mixture of a giant-block regime and
a regime with a linear number of blocks under a specified size-dependent
component weight. They include:

* An exact giant-deletion identity and an elementary total variation
  approximation by two independent geometric renewal strings.
* Conditional Gamma laws for the block count and giant deficit.
* A stable limit for the count in the regime without a giant, jointly
  with the largest block and the point process of large block sizes.
* Stable residual fluctuations and a mixed Frechet second-maximum law
  in the giant regime.
* Explicit approximations of the entire conditional residual law to
  every fixed inverse power of log n.
* A refined logarithmic center and nine further research questions.

The enumeration identity and general condensation mechanisms have
established precedents. The article distinguishes these from its
continuation of the pinned report. It is an unrefereed manuscript prepared
with AI assistance, with ordinary mathematical proofs rather than a
Lean or Rocq formalization. Publication priority is not asserted beyond
the specific question documented in that report.

BUILD THE PDF

Requirements: a LaTeX installation with pdfLaTeX and latexmk, including
amsmath, amssymb, amsthm, mathtools, lmodern, microtype, geometry, booktabs,
array, longtable, enumitem, graphicx, xcolor, hyperref, xurl and fancyhdr.
TeX Live 2023 on Debian was used for the supplied PDF.

From this directory on a system with a POSIX shell, run:

    sh build.sh

This compiles in build/ and copies the completed PDF to this directory.
Alternatively run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error tournament_coexistence.tex

The references are embedded in the source; no BibTeX step is needed.
The figures are already supplied, so the Python program need not be run
to compile the PDF.

REPRODUCE THE CALCULATIONS

The generating environment used Python 3.12.14. Exact dependency versions
are listed in code/requirements.txt. Install them in your own environment
if needed:

    python -m pip install -r code/requirements.txt

Then run:

    python code/verify_and_plot.py

The program is deterministic and uses no network access or random
sampling. It writes its data and figures to the existing data/ and
figures/ directories. Default runtime was about six seconds in the
generating environment. See code/README.md for algorithm details,
parameters, precision qualifications and interpretation of every output.

The exact integer checks enumerate all 125,476 nondecreasing candidate
score lists through n=10, apply Landau's inequalities, and check all
coefficients of both block-count and giant-block polynomials.
Larger computations use floating arithmetic and are explicitly labeled
as diagnostics. They are neither interval certificates nor proofs of
the asymptotic results. In particular, visible finite-size corrections
remain substantial in the supplied examples.

CONTENTS

tournament_coexistence.pdf       Complete article.
tournament_coexistence.tex       Editable LaTeX source.
build.sh                        Rebuild command.
README.txt                      This guide.
provenance.json                 Pinned research source and scope.
SHA256SUMS.txt                   Checksums of the archive's other files.
code/                           Verification and plotting program,
                                environment versions, and documentation.
data/                           Exact check summary, numerical tables,
                                normalized renewal masses, and run log.
figures/                        Vector PDF and raster PNG plots.

The supplementary phase_profiles plot shows theoretical limiting
densities. It is not a numerical convergence experiment.
