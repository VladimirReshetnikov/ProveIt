# Independent audit of the universal-sink degree-four reduction

## Scope and verdict

The moment reduction, its inequality direction, all four support coefficient formulas, the scaling of the producer's reduced polynomial, the degree-four normalization, and the first ULC inequality are **approved**. This note is an ordinary-mathematical audit of the reduction. Exhaustive rational certificate expansion and the 4096-to-218 isomorphism coverage have also passed a separate independent verifier. I reviewed that verifier and reran it successfully; the complete all-core middle-gap theorem is now approved.

The previously approved sharp last-gap article and archive are unchanged.

## Model and support formulas

Let `C={0,1,2,3}` be a loopless directed core, let `W` be an independent sink set, and include every arc from `C` to `W` and no other exterior arcs. Give each core vertex independent nonnegative tail and head activities `u_i,v_i`, and each sink a nonnegative head activity `w_x`. Sinks cannot be tails. An ordered pair `(S,T)` of disjoint physical endpoint sets of equal size is counted once when a directed perfect matching from `S` onto `T` exists; the weight is `u_S v_(T cap C) w_(T cap W)`.

Write `e_j=e_j(u)` and `E_j=e_j(w)`. Let

- `a = sum_(i->j in H) u_i v_j`
- `b = sum_({j,k} admissible) v_j v_k u_(C\{j,k})`, where admissible means the two remaining distinct core vertices can cover `{j,k}`
- `c = sum_j v_j sum_(S subset C\{j}, |S|=2, S intersects N^-(j)) u_S`
- `d = sum_(j: N^-(j) nonempty) v_j u_(C\{j})`

The exact formulas are

    gamma_0 = 1
    gamma_1 = a + e_1 E_1
    gamma_2 = b + c E_1 + e_2 E_2
    gamma_3 = d E_2 + e_3 E_3
    gamma_4 = e_4 E_4

To verify them, all tails lie in `C`. A size-`k` pair has at most `4-k` core heads, and any feasible injection onto those core heads extends to a matching onto all selected heads because the other heads are universal sinks. Size one contributes a core arc or a sink head. Size two permits zero, one, or two core heads. Size three permits zero or one core head. Size four permits only sink heads. Internal feasibility is a Boolean indicator, so no term is multiplied by the number of matching witnesses.

All formulas hold even when activities vanish. Opposite internal arcs are permitted, and no transitivity is used.

## Moment envelope and direction

Put `p_l=sum_x w_x^l`. Then

    E_1 = p_1
    2 E_2 = p_1^2 - p_2
    6 E_3 = p_1^3 - 3 p_1 p_2 + 2 p_3

Set

    A = sqrt(p_2) = sqrt(E_1^2 - 2E_2)
    B = p_1 - A

Both variables are nonnegative. Indeed `p_1^2 >= p_2` for nonnegative `w_x`, including the all-zero case. The first two moments become exactly

    E_1 = A+B
    E_2 = AB + B^2/2

For each `x`, `w_x <= sqrt(p_2)=A`. Consequently

    p_3 = sum_x w_x^3 <= A sum_x w_x^2 = A^3

This proves, without a division by any activity,

    E_3 <= AB^2/2 + B^3/6

Let `F=4 gamma_2^2 - 9 gamma_1 gamma_3`. Its dependence on `E_3` is linear, with coefficient

    -9 (a+e_1 E_1) e_3 <= 0

Therefore substituting the upper envelope for `E_3` can only decrease `F`. If the resulting polynomial is nonnegative for every nonnegative `u,v,A,B`, then the actual middle gap is nonnegative for every finite nonnegative sink-head vector. The bound is used in the correct direction.

### Why the relaxed envelope is exact after closure

For fixed `A,B>=0`, take one sink of weight `A` and `n` sinks of weight `B/n`. Their moments satisfy

    p_1(n) = A+B
    p_2(n) = A^2+B^2/n -> A^2
    p_3(n) = A^3+B^3/n^2 -> A^3

Hence their `(E_1,E_2,E_3)` converge to the envelope substitution. These are limits, not in general an exact finite realization of all three target values. By polynomial continuity, nonnegativity for all finite sink multisets also implies nonnegativity on the envelope. Thus the reduction is equivalent after closure for the family with unbounded finite sink counts. Sufficiency alone is enough for the proof.

## Scaling and certificate interpretation

Using variable order

    u_0,u_1,u_2,u_3,v_0,v_1,v_2,v_3,A,B

write

    X = A+B
    2Y = 2AB+B^2
    6Z = 3AB^2+B^3
    G_1 = a+e_1 X
    G_2 = 2b+2cX+e_2(2Y)
    G_3 = 3d(2Y)+e_3(6Z)

Then `G_1=gamma_1`, `G_2=2 gamma_2`, and `G_3=6 gamma_3` at the envelope. Thus

    P = 2 G_2^2 - 3 G_1 G_3
      = 2 (4 gamma_2^2 - 9 gamma_1 gamma_3)

There is no missing factor of two, three, or six.

The stored certificate format is suitable if independently checked exactly: each contribution is a positive rational scalar times a nonnegative monomial times the square of a rational binomial, and the reconstructed remainder is coefficientwise nonnegative. The multiplier exponents must be nonnegative integers, as must the square-monomial exponents; negative binomial coefficients are allowed inside the square. The verifier must reconstruct `P` independently from the graph, expand every square over rational arithmetic, and check the remainder. A numerical LP success status or a stored receipt alone is not proof.

## First degree-four ULC inequality has an ordinary proof

For each possible tail `i in C`, define

    R_i = u_i sum_(j: i->j in D) head_activity(j)

Then `gamma_1=sum_i R_i`. For each feasible size-two endpoint pair with tails `{i,j}`, at least one matching witness contributes its weight to the expansion of `R_i R_j`. The latter expansion may count a pair multiple times and may contain forbidden collisions; all terms are nonnegative. Consequently

    gamma_2 <= sum_(i<j) R_i R_j
            = ((sum_i R_i)^2 - sum_i R_i^2)/2
            <= 3 gamma_1^2/8

The final comparison is Cauchy applied to four nonnegative `R_i`. Hence

    3 gamma_1^2 >= 8 gamma_2

This witness-counting upper bound does not confuse the support polynomial with a witness enumerator: the comparison deliberately overcounts on its right side.

## Combining the inequalities and respecting actual degree

If `gamma_4>0`, the actual degree is four and every coefficient from `gamma_0` through `gamma_4` is positive. Degree-four ULC of `gamma_k/binom(4,k)` asks exactly for

    3 gamma_1^2 >= 8 gamma_0 gamma_2
    4 gamma_2^2 >= 9 gamma_1 gamma_3
    3 gamma_3^2 >= 8 gamma_2 gamma_4

The first follows above, the middle follows if all reduced certificates and coverage pass, and the last follows from the independently approved all-rank sharp universal-sink theorem. Thus a completed exact certificate audit would prove full independent-role ULC for arbitrary loopless four-vertex directed cores with independent universal sinks **at actual degree four**.

If `gamma_4=0`, these indexed inequalities must not be substituted for the stronger normalization at a smaller actual degree. In degree three the required constants include `gamma_1^2>=3 gamma_2` and `gamma_2^2>=3 gamma_1 gamma_3`; the present degree-four constants alone do not give these. Any lower-degree theorem needs its own argument or an explicitly applicable previously established result. No claim about general weighted preorder cores beyond this universal-sink family follows.

The universal-source version follows by reversing every arc and exchanging the activity roles.

## Completed certificate and coverage audit

The independent standard-library checker in `../audit-universal-sink-middle-gap/check.py` was reviewed and rerun. It imports no producer code and uses a different monomial representation. Literal Boolean matching feasibility reconstructed the grouped support polynomials at ranks 0 through 4 for all 4096 labeled loopless cores. Independent relabeling orbits give exactly 218 representatives covering each labeled graph once. All 218 rational identities and coefficientwise remainder checks passed: 45 kernels need no squares, while the other 173 use 2830 strictly positive-weight binomial squares in total. The reconstructed remainders contain 75413 nonzero coefficients, all positive. The fresh full receipt is `fresh-certificate-replay/receipt.json`.

Combined with the ordinary reduction and first-gap proof above, and the already approved sharp last-gap theorem, this establishes full independent-role ULC for this universal-sink family when the actual degree is four. This is a computer-assisted exact-algebra proof of the middle inequality, not a sampling or floating-point claim. Smaller actual degrees retain the stated caveat.
