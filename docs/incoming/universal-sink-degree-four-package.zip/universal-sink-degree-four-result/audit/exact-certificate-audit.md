# Independent audit: universal-sink degree-four middle gap

## Verdict

**PASS.** Every supplied certificate is an exact nonnegative decomposition of
the correctly reconstructed middle-gap kernel. The 218 representative cores
cover all 4096 loopless directed graphs on four labeled vertices. No
mathematical gap or failed certificate was found.

The executable proof checker is `check.py`; exact per-class results and source
SHA-256 hashes are in `receipt.json`. It uses only the Python standard library,
imports no producer code, executes no producer code, and uses integer/rational
arithmetic for all polynomial decisions. The producer's linear program and its
floating-point solver are not logical dependencies of this audit.

## Support formulas and Boolean convention

Only core vertices can be tails. For a support of rank k, let S be its core
tails and H its core heads. These are disjoint, and |S| = k, so |H| <= 4-k.
There must be k-|H| selected sink heads. Once distinct tails cover H along core
arcs, every remaining tail can be matched to a selected universal sink.
Feasibility is an existence indicator, so multiple witnesses contribute once.

Writing e_j for the elementary symmetric polynomial in the four tail
activities and E_j for that in the sink-head activities gives

    gamma0 = 1
    gamma1 = a + e1 E1
    gamma2 = b + c E1 + e2 E2
    gamma3 = d E2 + e3 E3
    gamma4 = e4 E4

Here a is the sum of active core-arc monomials, b counts feasible internal
rank-two supports once, c sums v_j u_S over two-tail sets S disjoint from j
meeting the in-neighborhood of j, and d sums v_j u_(C\{j}) for core heads j
with nonempty combinatorial in-neighborhood. Zero activity values do not change
the graph's Boolean indicators and cause no problem for these polynomial
identities.

The checker verified these identities in two independent ways:

1. For all 4096 labeled cores, it enumerates disjoint core-tail/core-head sets
   and tests Boolean matching existence by checking bijections. Identical
   sink-head choices are grouped into their elementary symmetric polynomial
2. For all 218 representatives and each sink count 0,1,2,3,4, it enumerates full
   physical ordered disjoint endpoint sets and applies Hall's condition to
   every nonempty tail subset. It compares the resulting polynomials in
   distinct sink variables with the expanded grouped formulas

The second check includes sink vertices as possible tails and independently
rejects them by Hall's condition. It covers 372,998 ordered endpoint pairs and
1,090 whole-polynomial comparisons. The grouped all-labeled check contains
152,064 feasible grouped monomials over ranks 0 through 4. Symbolic grouping
and the support argument, rather than a finite numerical sample, extend the
formula to every finite sink cloud.

## Moment reduction

For nonnegative sink weights w, put s = sum w, q = sum w^2 and r = sum w^3.
Set A = sqrt(q) and B = s-A. Since s^2 >= q, both A and B are nonnegative.
Newton's elementary identities give

    E1 = s = A+B
    E2 = (s^2-q)/2 = AB+B^2/2
    E3 = (s^3-3sq+2r)/6

Every w is at most A, so r <= A sum w^2 = A^3. Consequently

    E3 <= AB^2/2 + B^3/6 =: Z

The middle gap D = 4 gamma2^2 - 9 gamma1 gamma3 has E3 coefficient
-9 gamma1 e3, which is nonpositive on the nonnegative orthant. Thus D at the
actual E3 is at least its value at Z. This sign is essential and correct.

The bound has the stated limiting interpretation: one sink of weight A and
n sinks of weight B/n have

    E1 = A+B
    E2 = AB + (n-1)B^2/(2n)
    E3 = A(n-1)B^2/(2n) + (n-1)(n-2)B^3/(6n^2)

These tend to the substituted cone values as n tends to infinity. This is a
closure statement; for positive B the limiting endpoint is not generally
attained by a finite cloud. The proof of the inequality needs only the upper
bound, not finite attainment.

## Exact kernel and certificates

The checker uses variable order

    (u0,u1,u2,u3,v0,v1,v2,v3,A,B)

and independently substitutes the moment expressions into the Boolean support
polynomials. It reconstructs

    P = 2(4 gamma2^2 - 9 gamma1 gamma3)
      = 2 G2^2 - 3 G1 G3,
    G1 = gamma1, G2 = 2 gamma2, G3 = 6 gamma3

with E3 replaced by Z. Both expressions were compared exactly. Every monomial
has degree four in tail variables and degree four in head/sink variables.

Each supplied term is decoded as lambda*x^m*f(x)^2. The checker validates
lambda > 0, nonnegative integral exponent vectors of length 10, and a genuine
two-term binomial f with exact nonzero rational coefficients. It fully expands
each square using `fractions.Fraction`, subtracts all terms from P, and checks
every remaining coefficient, including any monomial outside P's initial
support. No rounding or tolerance enters this verification.

The result is

    P = sum lambda*x^m*f(x)^2 + R,

with R coefficientwise nonnegative in every case. Hence P >= 0 throughout the
nonnegative orthant. There are 2,830 positive-weight binomial squares total,
45 coefficientwise-nonnegative kernels with empty certificate lists, and 173
nonempty certificates. The reconstructed remainders have 75,413 nonzero
coefficients, all strictly positive. The receipt records a canonical hash of
each reconstructed kernel and remainder.

## Coverage

All four row masks were enumerated independently subject only to exclusion of
the diagonal, giving 8^4 = 4096 labeled loopless cores. The checker builds the
24 simultaneous tail/head relabelings of each graph and partitions the entire
set into disjoint orbits. The canonical representative is the least row tuple
in its orbit; the resulting sorted list agrees exactly with both catalogs and
all certificate labels.

The orbit-size histogram is

    size 1: 2 classes
    size 3: 2 classes
    size 4: 6 classes
    size 6: 8 classes
    size 8: 4 classes
    size 12: 60 classes
    size 24: 136 classes

There are 218 classes in total and the weighted orbit sizes sum to 4096.
Exactly 33 representatives are preorders after adding the diagonal, agreeing
with the producer metadata; the proof covers the other 185 classes as well.
Simultaneous permutation of u and v transports each verified inequality to
all labeled members of that representative's orbit.

## Actual degree and full ULC scope

Since gamma4 = e4 E4, actual degree four is equivalent to all four core-tail
activities being positive and at least four sink-head activities being
positive. In this case every gamma_k for 0 <= k <= 4 is positive. Full
rank-ULC is log-concavity of gamma_k/binomial(4,k), namely

    3 gamma1^2 >= 8 gamma2
    4 gamma2^2 >= 9 gamma1 gamma3
    3 gamma3^2 >= 8 gamma2 gamma4

The current certificate audit establishes the middle inequality. Together
with the separately approved universal first-gap argument and universal-sink
last-gap theorem, it gives full rank-ULC in actual degree four. The frozen
last-gap package was read and hashed, not modified; its scope allows arbitrary
loopless core graphs and independent nonnegative role activities.

The polynomial middle inequality remains valid when gamma4 = 0, but its
degree-four normalization is not the normalization at smaller actual degree.
For example, actual degree three requires gamma2^2 >= 3 gamma1 gamma3,
whereas this certificate supplies only the factor 9/4. No smaller-degree
rank-ULC claim, stability claim, real-rootedness claim, sharp middle constant,
or novelty claim is implied by this audit.

## Reproduction and portability

For the release layout with `checker/check.py` and `certificate-data/`, run

    python checker/check.py --source certificate-data --output audit-replay

The source directory must contain the same 222 files: two producer Python
files, two catalogs, and 218 certificates. The Python files are only hashed.
There are no installed-package requirements and no prior ZIP dependency.

Optionally pass `--prior-package PATH` to verify that a separately supplied
frozen prior package remains unchanged. The option defaults to absent and is
never needed for the middle-gap proof. The audit workspace contains two fresh
successful receipts: `receipt.json` includes the optional prior-package
integrity check; `portable-replay/receipt.json` reruns without any prior package.

The frozen prior package's unchanged SHA-256 is
`ff2958bca76ce176e01e1af737167a01a896c5c7bf07888a80fdcd0bb1add51e`.

The final portable checker's SHA-256 is
`49fa90d2753ae23be2a3db556190ca102b2e2ec3e317d6b00160bcb1f23c3181`.
