WEIGHTED DEGREE FOUR RANK ULTRA LOG CONCAVITY FOR UNIVERSAL SINK EXTENSIONS
October 1, 2026

RESULT
Take any loopless directed relation H on a four-vertex core C. Add any finite
independent set W of universal sinks: all arcs C -> W are present, and W has
no outgoing arcs. Assign independent nonnegative tail and head activities.
Count each feasible ordered disjoint endpoint pair once, not its matching
witnesses. If the resulting support polynomial has actual degree four, its
coefficient sequence is rank-ultra-log-concave:

 3 gamma_1^2 >= 8 gamma_2
 4 gamma_2^2 >= 9 gamma_1 gamma_3
 3 gamma_3^2 >= 8 gamma_2 gamma_4

The theorem needs no transitivity. It therefore includes every four-vertex
preorder core with a weighted universal-sink cloud. The universal-source
version follows by reversing arcs and exchanging role activities.

The middle inequality is proved by an ordinary moment reduction plus finite
exact polynomial certificates. The first and last inequalities have ordinary
proofs, included in the self-contained article. The middle inequality itself
holds at zero-activity faces too; degree-four normalization is not substituted
for smaller surviving degrees.

CONTENTS
 article/universal-sink-degree-four.pdf  Five-page theorem and proof
 article/universal-sink-degree-four.tex  Editable mathematical source
 certificate-data/                      All 218 rational certificates,
                                        catalog, and discovery sources
 checker/check.py                       Independent exact verifier
 audit/                                 Ordinary and computational reviews
 proof-notes/                           Expanded moment-reduction note
 qa/                                    All-page rendering and visual review
 verify.py                              Integrity and fresh exact replay driver
 build.sh                               Optional PDF rebuild script
 SHA256SUMS                             Package file hashes

EXACT VERIFICATION
Python 3.10 or later and its standard library suffice. No third-party Python
package, numerical solver, network, prior research ZIP, or producer import is
required. Run:

 python verify.py

The driver validates the file manifest, copies the checker and all certificate
inputs into a fresh temporary directory, and recomputes the entire exact audit.
It does not accept the stored receipt as evidence of a fresh run. To keep a
new full receipt:

 python verify.py --output /tmp/universal-sink-degree-four-replay.json

For integrity alone (not mathematical verification):

 python verify.py --mode hashes

Direct independent-checker invocation is also supported:

 python checker/check.py --source certificate-data --output /tmp/sink-audit

The verifier independently reconstructs Boolean supports for all 4096 labeled
cores, the 218 permutation classes, every reduced polynomial, all 2830 rational
binomial squares, and all 75413 positive remainder monomials. It also checks
ungrouped Hall formulas with explicit sink variables. Every coefficient is
checked exactly, including coefficients at monomials absent from the target.

CERTIFICATE CONVENTION
Variable order is u0,u1,u2,u3,v0,v1,v2,v3,A,B. Each certificate lists its four
row masks; bit j in row i denotes arc i -> j. A square term has schema

 [positive rational weight, [multiplier exponents,
                            [[first exponents, first rational coefficient],
                             [second exponents, second rational coefficient]]]]

The target is P = 2*(4 gamma_2^2 - 9 gamma_1 gamma_3) after substituting
E1=A+B, E2=AB+B^2/2, and E3=AB^2/2+B^3/6. The nonnegative remainder is
reconstructed, not supplied as a trusted input. Empty square lists mean that
the entire target is coefficientwise nonnegative.

DISCOVERY AND PROOF
The optional discovery program pair_certify.py uses NumPy/SciPy linear
programming. These packages are not needed for verification. Floating-point
coefficients were reconstructed as rationals and accepted only after exact
expansion. Solver status and numerical tolerances are not proof inputs.
The finite exact identities are a logical component of the middle-gap proof;
they are not merely activity-grid tests. The ordinary moment reduction covers
arbitrarily many heterogeneous sink activities.

BUILD
The supplied PDF is ready to read. To rebuild on TeX Live:

 bash build.sh

A rebuild changes PDF metadata and therefore its hash. Verify before rebuilding
or rebuild in an extracted working copy. Original-container TeX environment
hints in build.sh are unnecessary on a normally configured installation.

SCOPE
This is an actual-degree-four theorem for the stated universal-sink family.
It does not prove general weighted degree-four preorder ULC, smaller-degree
normalization for arbitrary directed cores, real-rootedness, or stability.
No novelty, priority, formalization, or external-publication claim is made.
The earlier sharp all-rank last-gap archive is unchanged and is not an external
executable dependency of this package. Absolute paths in historical audit notes
record provenance only.
