#!/usr/bin/env python3
"""Independent exhaustive local proof of the U218 -> U217 state deletion.

No imports from construction/search/runtime checkers. Every assignment to five
local cells is checked; a read or write outside them is rejected. Consequently
the checked finite blocks quantify over arbitrary unseen exterior tape.
"""
import argparse
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path

HALT = 254
WINDOW = (-1, 0, 1, 2, 3)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_table(path):
    rows = {}
    starts = []
    raw = path.read_bytes()
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(int(line[9:]))
        elif line and not line.startswith('#'):
            fields = line.split()
            require(len(fields) == 5, 'Malformed row')
            q, b, w, d, z = fields
            q, b, w, z = map(int, (q, b, w, z))
            require((q, b) not in rows, 'Duplicate row')
            require(b in (0, 1) and w in (0, 1) and d in ('L', 'R'), 'Bad row')
            rows[q, b] = (w, -1 if d == 'L' else 1, z)
    states = {q for q, b in rows}
    require(starts == [0], 'Wrong start header')
    require(HALT not in states, 'Halt has outgoing rows')
    require(set(rows) == {(q, b) for q in states for b in (0, 1)}, 'Partial table')
    require({z for w, d, z in rows.values()} - states == {HALT}, 'Unknown target')
    return rows, states, hashlib.sha256(raw).hexdigest()


def state_map(q):
    return 134 if q == 112 else q


def invariant(q, head, tape):
    return q != 112 or tape[head + 1] == 0


def block(table, q, tape, count):
    cells = dict(tape)
    head = 0
    trace = []
    for i in range(count):
        require(q != HALT, 'Premature halt inside block')
        require(head in cells, 'Read outside local window')
        symbol = cells[head]
        require((q, symbol) in table, 'Missing transition')
        w, d, z = table[q, symbol]
        trace.append([q, head, symbol, w, d, z])
        cells[head] = w
        head += d
        q = z
    return q, head, cells, trace


def verify_local(old, new, old_states):
    cases = Counter()
    examples = {}
    checked = 0
    skipped = 0
    for q in sorted(old_states):
        for bits in itertools.product((0, 1), repeat=len(WINDOW)):
            tape = dict(zip(WINDOW, bits))
            if not invariant(q, 0, tape):
                skipped += 1
                continue
            lengths = (1, 1) if q != 112 else ((1, 3) if tape[0] == 0 else (5, 3))
            a = block(old, q, tape, lengths[0])
            b = block(new, state_map(q), tape, lengths[1])
            require(b[:3] == (state_map(a[0]), a[1], a[2]),
                    f'Local endpoint mismatch: q={q}, bits={bits}, lengths={lengths}')
            require(invariant(a[0], a[1], a[2]), 'Original invariant lost')
            require((a[0] == HALT) == (b[0] == HALT), 'Halting mismatch')
            checked += 1
            cases[str(lengths)] += 1
            if q == 112:
                key = f'read{tape[0]}_next2_{tape[2]}'
                examples.setdefault(key, {'old': a[3], 'new': b[3],
                                           'endpoint': [a[0], a[1]],
                                           'tape_unchanged': a[2] == tape})
    return {'checked_local_cases': checked, 'excluded_guard_violations': skipped,
            'cases_by_old_new_lengths': dict(cases), 'special_path_examples': examples}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--old', type=Path, required=True)
    ap.add_argument('--new', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    old, os, oh = read_table(args.old)
    new, ns, nh = read_table(args.new)
    require(len(os) == 218 and len(ns) == 217, 'Wrong state counts')
    require(ns == os - {112}, 'Wrong deleted state')
    incoming = sorted((list(k), list(v)) for k, v in old.items() if v[2] == 112)
    require(incoming == [([172, 0], [0, -1, 112])], 'Guard premise false')
    require(old[112, 0] == (0, 1, 157) and old[112, 1] == (1, 1, 209),
            'Wrong old rows')
    expected = {(q, b): (w, d, state_map(z)) for (q, b), (w, d, z) in old.items()
                if q != 112}
    require(new == expected, 'Candidate is not exactly the target-redirection fold')
    report = verify_local(old, new, os)
    controls = []
    for target in (61, 90, 133, 157, 158, 182, 209, HALT):
        faulty = dict(new)
        w, d, _ = faulty[172, 0]
        faulty[172, 0] = (w, d, target)
        try:
            verify_local(old, faulty, os)
        except ValueError as error:
            controls.append({'mutation': f'172/0 target -> {target}',
                             'rejected': True, 'reason': str(error)})
        else:
            raise ValueError('Fault control was not detected')
    bad_guard = {k: 0 for k in WINDOW}
    bad_guard[1] = 1
    a = block(old, 112, bad_guard, 1)
    b = block(new, 134, bad_guard, 3)
    require(b[:3] != (state_map(a[0]), a[1], a[2]), 'Guard necessity control failed')
    report.update({'status': 'INDEPENDENT_LOCAL_BLOCK_PROOF_PASS',
                   'old_sha256': oh, 'new_sha256': nh,
                   'old_states': len(os), 'new_states': len(ns),
                   'window_offsets': list(WINDOW),
                   'guard': 'q=112 implies tape[head+1]=0',
                   'incoming_rows_to_deleted_state': incoming,
                   'changed_retained_row': [172, 0, 0, 'L', 134],
                   'old_new_block_lengths': [[1, 1], [1, 3], [5, 3]],
                   'all_exterior_cells_opaque_and_unread': True,
                   'guard_necessity_control': {'old_endpoint': a[:2],
                                               'new_endpoint': b[:2], 'rejected': True},
                   'negative_controls': controls,
                   'scope': 'Finite local block theorem for all exterior tapes; ordinary '
                            'arithmetical run induction proves both halting directions. '
                            'Not a proof-assistant kernel certificate.'})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items()
                      if k not in ('special_path_examples', 'negative_controls')}, indent=2))


if __name__ == '__main__':
    main()
