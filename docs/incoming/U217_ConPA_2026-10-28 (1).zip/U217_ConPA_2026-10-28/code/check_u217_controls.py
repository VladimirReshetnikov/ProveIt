#!/usr/bin/env python3
"""Negative controls for the U217 finite local theorem checker.

Mutations to shared rows are applied identically to both tables, so the
old/new exact-fold shape still agrees. Rejection must then come from a
failed invariant or local simulation obligation, rather than byte hashes.
"""
from pathlib import Path
import argparse,json
from check_u217 import parse,certify

CONTROLS=[
    ('wrong_predecessor_write',(172,0),(1,-1,None)),
    ('wrong_predecessor_direction',(172,0),(0,1,None)),
    ('wrong_new_zero_start_write',(134,0),(1,1,182)),
    ('wrong_zero_detour_write',(182,0),(1,-1,209)),
    ('wrong_zero_detour_direction',(182,0),(0,1,209)),
    ('wrong_zero_return_write',(209,0),(1,1,157)),
    ('wrong_old_zero_test_write',(157,0),(1,-1,67)),
    ('wrong_old_one_test_write',(157,1),(0,-1,148)),
    ('wrong_old_zero_relay_write',(67,0),(1,1,151)),
    ('wrong_old_zero_exit_write',(151,0),(1,1,90)),
    ('wrong_new_one_relay_write',(158,0),(1,1,218)),
    ('wrong_new_zero_exit_write',(218,0),(1,1,90)),
    ('wrong_new_one_exit_write',(218,1),(0,1,86)),
    ('wrong_old_one_relay_write',(148,0),(1,1,186)),
    ('wrong_old_one_exit_write',(186,1),(0,1,86)),
]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('old',type=Path);p.add_argument('new',type=Path)
    p.add_argument('--output',type=Path);a=p.parse_args()
    old=parse(a.old);new=parse(a.new);certify(old,new)
    result=[]
    for name,key,action in CONTROLS:
        x=dict(old);y=dict(new)
        w,d,z=action
        x[key]=(w,d,x[key][2] if z is None else z)
        y[key]=(w,d,y[key][2] if z is None else z)
        try:
            certify(x,y)
        except (ValueError,KeyError) as error:
            result.append({'name':name,'row':key,'old_action':x[key],
                           'new_action':y[key],'status':'REJECTED',
                           'reason':str(error)})
        else:
            raise ValueError('Invalid mutation accepted: '+name)
    summary={'status':'ALL_NEGATIVE_CONTROLS_REJECTED',
             'controls':len(result),'results':result}
    text=json.dumps(summary,indent=2)+'\n'
    if a.output:a.output.write_text(text)
    print(text)
if __name__=='__main__':main()
