#!/usr/bin/env python3
"""Deterministically build U217 from its exact U218 parent.

The table format and canonical-label convention follow the supplied U218
packet and the ProveIt K215 construction. This new builder performs one target
redirection and removes one state; it invokes no search, solver, or network.
The separate local block proof supplies the semantic justification.
"""
from pathlib import Path
import argparse
import hashlib
import json

PARENT_SHA256 = '366cf96800bd4299de831355a80092394462278f0b62db1e19c167ca5f8b2a30'
NATIVE_SHA256 = 'fe7b6d449b6b9a57d562b4e6f3ec0a77b27a4b72ccfc41775d57a3e550302d0f'
DENSE_SHA256 = '639da240bdb466f2a50ed40e36355a5677b6ecaaf5ef95e2e5309f4682b55be6'
SOURCE_SHA256 = 'bc70b28ff4628db5b9b0c9bd87f560697223e4887f2568b0ece801906713db8f'
ARCHIVE_SHA256 = '73c7d0774d955c9b003eec0e9e0876e280f028f653a127c7518d132b914c8bc9'
NESTED_ARCHIVE_SHA256 = 'd23e80857214900f8e0806f03f6df752af501dd0108eb92c6ed7a49795802652'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def parse(raw, halt=254):
    table = {}
    starts = []
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(int(line[9:]))
        elif line and not line.startswith('#'):
            fields = line.split()
            need(len(fields) == 5, 'Malformed transition row')
            q, b, w, direction, target = fields
            q, b, w, target = map(int, (q, b, w, target))
            need(q >= 0 and target >= 0, 'Negative state label')
            need(b in (0, 1) and w in (0, 1), 'Nonbinary transition')
            need(direction in ('L', 'R'), 'Invalid head movement')
            need((q, b) not in table, 'Duplicate transition row')
            table[q, b] = w, (-1 if direction == 'L' else 1), target
    states = {q for q, _ in table}
    need(starts == [0], 'Exactly one start-0 header is required')
    need(0 in states and halt not in states, 'Start/halt convention differs')
    need(set(table) == {(q, b) for q in states for b in (0, 1)},
         'Incomplete binary transition table')
    need({z for _, _, z in table.values()} - states == {halt},
         'Undefined target or absent halt')
    todo = [0]
    reached = {0}
    for q in todo:
        for b in (0, 1):
            z = table[q, b][2]
            if z != halt and z not in reached:
                reached.add(z)
                todo.append(z)
    need(reached == states, 'A working state is graph-unreachable')
    return table


def encode(table):
    return ('#! start 0\n' + ''.join(
        f'{q} {b} {w} {"R" if d == 1 else "L"} {z}\n'
        for (q, b), (w, d, z) in sorted(table.items())
    )).encode('ascii')


def construct(parent_raw, source_raw):
    need(digest(parent_raw) == PARENT_SHA256, 'Wrong exact U218 parent')
    need(digest(source_raw) == SOURCE_SHA256, 'Wrong unchanged source')
    old = parse(parent_raw)
    need(len(old) == 436, 'U218 must have 436 rows')
    incoming = sorted((q, b, w, d) for (q, b), (w, d, z) in old.items()
                      if z == 112)
    need(incoming == [(172, 0, 0, -1)], 'Known-zero predecessor premise fails')
    new = {(q, b): (w, d, 134 if z == 112 else z)
           for (q, b), (w, d, z) in old.items() if q != 112}
    need(new[172, 0] == (0, -1, 134), 'Wrong redirected row')
    need(len(new) == 434, 'U217 must have 434 rows')
    native = encode(new)
    need(digest(native) == NATIVE_SHA256, 'Wrong constructed native bytes')
    parse(native)
    rename = {q: i for i, q in enumerate(sorted({q for q, _ in new}))}
    rename[254] = 217
    need(rename[0] == 0 and len(rename) == 218, 'Wrong canonical labeling')
    dense_table = {(rename[q], b): (w, d, rename[z])
                   for (q, b), (w, d, z) in new.items()}
    dense = encode(dense_table)
    need(digest(dense) == DENSE_SHA256, 'Wrong canonical dense bytes')
    parse(dense, 217)
    inverse = {v: k for k, v in rename.items()}
    need({(inverse[q], b): (w, d, inverse[z])
          for (q, b), (w, d, z) in dense_table.items()} == new,
         'State bijection changes a transition')
    mapping = {str(q): r for q, r in rename.items()}
    summary = {
        'status': 'EXACT_U217_RECONSTRUCTION_AND_RELABELING_PASS',
        'working_states': 217, 'transition_rows': 434,
        'graph_reachable_working_states': 217,
        'initial_state': 0, 'native_halt': 254, 'dense_halt': 217,
        'deleted_native_state': 112,
        'changed_retained_row': [172, 0, 0, 'L', 134],
        'parent_native_sha256': PARENT_SHA256,
        'native_sha256': NATIVE_SHA256, 'dense_sha256': DENSE_SHA256,
        'source_sha256': SOURCE_SHA256,
        'source_primitive_occurrences': len(json.loads(source_raw)),
        'source_unchanged': True,
    }
    return native, dense, mapping, summary


def build(parent, source, output):
    source_raw = source.read_bytes()
    native, dense, mapping, summary = construct(parent.read_bytes(), source_raw)
    output.mkdir(parents=True, exist_ok=True)
    (output / 'u217.native.tm').write_bytes(native)
    (output / 'u217.tm').write_bytes(dense)
    (output / 'sites.json').write_bytes(source_raw)
    (output / 'state_map.json').write_text(json.dumps(mapping, indent=2) + '\n')
    (output / 'machine_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    return summary


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--parent', required=True, type=Path)
    ap.add_argument('--source', required=True, type=Path)
    ap.add_argument('--output', required=True, type=Path)
    args = ap.parse_args()
    print(json.dumps(build(args.parent, args.source, args.output), indent=2))


if __name__ == '__main__':
    main()
