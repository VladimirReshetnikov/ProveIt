#!/usr/bin/env python3
"""Generate the exact dense transition-table appendix from the delivered table."""
from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = '639da240bdb466f2a50ed40e36355a5677b6ecaaf5ef95e2e5309f4682b55be6'


def main():
    raw = (ROOT / 'machine/u217.tm').read_bytes()
    if hashlib.sha256(raw).hexdigest() != EXPECTED:
        raise ValueError('Dense table identity mismatch')
    table = {}
    for line in raw.decode('ascii').splitlines():
        if not line or line.startswith('#'):
            continue
        q, b, w, d, z = line.split()
        table[int(q), int(b)] = f'{w}{d}{z}'
    if set(table) != {(q, b) for q in range(217) for b in (0, 1)}:
        raise ValueError('Dense table is not exactly 217 complete working states')
    lines = [r'\begingroup\small\setlength{\tabcolsep}{5.4pt}',
             r'\begin{longtable}{rll@{\hspace{1.3em}}rll@{\hspace{1.3em}}rll}',
             r'\toprule',
             r'State & Read 0 & Read 1 & State & Read 0 & Read 1 & State & Read 0 & Read 1\\',
             r'\midrule\endfirsthead',
             r'\multicolumn{9}{c}{\small Exact U217 dense table, continued}\\',
             r'\toprule',
             r'State & Read 0 & Read 1 & State & Read 0 & Read 1 & State & Read 0 & Read 1\\',
             r'\midrule\endhead',
             r'\midrule\multicolumn{9}{r}{\small Continued on the next page}\\\endfoot',
             r'\bottomrule\endlastfoot']
    for row in range(73):
        cells = []
        for group in range(3):
            q = row + 73 * group
            if q < 217:
                cells += [str(q), r'\texttt{' + table[q, 0] + '}',
                          r'\texttt{' + table[q, 1] + '}']
            else:
                cells += ['', '', '']
        lines.append(' & '.join(cells) + r'\\')
    lines += [r'\end{longtable}', r'\endgroup', '']
    (ROOT / 'paper/transition_table.tex').write_text('\n'.join(lines), encoding='ascii')
    print('Generated complete 217-row dense transition appendix.')


if __name__ == '__main__':
    main()
