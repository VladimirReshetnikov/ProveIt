#!/usr/bin/env python3
"""Finite induction obligations for the U218 -> U217 local block reduction.

This standard-library checker is independent of compiler and register-runtime
internals. Each case denotes every completion of its five-cell tape window.
The finite checks certify local premises of the written induction proof; they
are not a proof-assistant kernel certificate.
"""
from pathlib import Path
import argparse, hashlib, itertools, json

OLD_SHA='366cf96800bd4299de831355a80092394462278f0b62db1e19c167ca5f8b2a30'
NEW_SHA='fe7b6d449b6b9a57d562b4e6f3ec0a77b27a4b72ccfc41775d57a3e550302d0f'
HALT=254

def need(value, message):
    if not value:
        raise ValueError(message)

def parse(path):
    table={}
    for line in path.read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        fields=line.split()
        need(len(fields)==5, 'Malformed table row')
        q,b,w,d,z=fields
        q,b,w,z=map(int,(q,b,w,z))
        need(b in (0,1) and w in (0,1) and d in ('L','R'), 'Malformed action')
        need((q,b) not in table, 'Duplicate table row')
        table[q,b]=(w,1 if d=='R' else -1,z)
    states={q for q,b in table}
    need(set(table)=={(q,b) for q in states for b in (0,1)}, 'Incomplete table')
    need(HALT not in states and 0 in states, 'Start or halt malformed')
    need({z for w,d,z in table.values()}-states=={HALT}, 'Undefined target')
    return table

def rename(q):
    return 134 if q==112 else q

def run_block(table, q, tape, count):
    head=0
    current=dict(tape)
    trace=[]
    for index in range(count):
        need(q!=HALT, 'Unexpected halt inside a certified block')
        need(head in current, 'Reads unknown exterior')
        bit=current[head]
        write,move,target=table[q,bit]
        trace.append([q,head,bit,write,move,target])
        current[head]=write
        head+=move
        q=target
    return q,head,current,trace

def certify(old, new):
    need(len(old)==436 and len(new)==434, 'Wrong state counts')
    incoming=[(q,b,w,d) for (q,b),(w,d,z) in old.items() if z==112]
    need(incoming==[(172,0,0,-1)], 'The necessary known-zero invariant fails')
    expected={(q,b):(w,d,rename(z)) for (q,b),(w,d,z) in old.items() if q!=112}
    need(new==expected, 'The new machine is not the exact stipulated fold')
    need(0!=112, 'Initial invariant is not vacuous')
    counts={}
    examples={}
    checked=0
    for q in sorted({q for q,b in old}):
        for bits in itertools.product((0,1),repeat=5):
            tape=dict(zip(range(-2,3),bits))
            if q==112 and tape[1]!=0:
                continue
            old_steps=5 if q==112 and tape[0]==1 else 1
            new_steps=3 if q==112 else 1
            oq,oh,ot,op=run_block(old,q,tape,old_steps)
            nq,nh,nt,np=run_block(new,rename(q),tape,new_steps)
            need((nq,nh,nt)==(rename(oq),oh,ot), 'Local block mismatch')
            if oq==112:
                need(oh+1 in ot and ot[oh+1]==0, 'Invariant not preserved')
            need((oq==HALT)==(nq==HALT), 'Halting mismatch')
            need(all(row[0]!=112 for row in op[1:]), 'Internal removed-state reentry')
            if q==112:
                key=f'read{tape[0]}_right2_{tape[2]}'
                examples.setdefault(key, {'old':op,'new':np})
            counts[f'{old_steps}:{new_steps}']=counts.get(f'{old_steps}:{new_steps}',0)+1
            checked+=1
    need(checked==6960, 'Incorrect finite obligation census')
    return {'status':'FINITE_BLOCK_SIMULATION_PASS','admissible_frames':checked,
            'radius':2,'clock_pair_counts':counts,'block_examples':examples,
            'old_working_states':218,'new_working_states':217,
            'invariant':'old state 112 implies tape(head+1)=0',
            'initial_scope':'Every binary initial tape in state 0',
            'maximum_old_block_steps':5,'maximum_new_block_steps':3,
            'minimum_old_block_steps':1,'minimum_new_block_steps':1,
            'scope':'Finite local premises for a PA-formalizable block induction; not kernel checked.'}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('old',type=Path)
    parser.add_argument('new',type=Path)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    old_raw=args.old.read_bytes();new_raw=args.new.read_bytes()
    need(hashlib.sha256(old_raw).hexdigest()==OLD_SHA,'Wrong old table bytes')
    need(hashlib.sha256(new_raw).hexdigest()==NEW_SHA,'Wrong new table bytes')
    result=certify(parse(args.old),parse(args.new))
    result['old_sha256']=OLD_SHA;result['new_sha256']=NEW_SHA
    text=json.dumps(result,indent=2)+'\n'
    if args.output:
        args.output.write_text(text)
    print(text)
if __name__=='__main__':
    main()
