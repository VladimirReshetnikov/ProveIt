#!/usr/bin/env python3
"""Literal blank-tape replay, independent of the symbolic runtime executor.

The frame convention is inherited from ProveIt K215/U218: marker h-1,
64 address cells plus a gap, header, then blocks 0 1^(v+1). We reconstruct
its complete finite support and compare every transition in both labelings.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json


def need(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    raw = path.read_bytes()
    if path.suffix == '.gz':
        raw = gzip.decompress(raw)
    return json.loads(raw)


def table(path):
    result = {}
    starts = []
    for line in path.read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(int(line[9:]))
        elif line and not line.startswith('#'):
            f = line.split()
            need(len(f) == 5, 'Malformed table row')
            q, b, w, z = map(int, (f[0], f[1], f[2], f[4]))
            need((q, b) not in result, 'Duplicate transition')
            need(b in (0, 1) and w in (0, 1) and f[3] in ('L', 'R'),
                 'Malformed transition action')
            result[q, b] = w, (1 if f[3] == 'R' else -1), z
    need(starts == [0], 'Wrong blank-tape start')
    return result


def expected_frame(head, gap, registers, spares):
    # Logical (N,T,W,A,D,H,X,Y,L) to physical block positions.
    permutation = (6, 2, 0, 4, 3, 7, 8, 5, 1)
    values = [0] * 9
    for logical, physical in enumerate(permutation):
        values[physical] = registers[logical]
    values.extend(spares)
    ones = {head - 1}
    header = head + 64 + gap
    ones.add(header)
    p = header + 1
    for value in values:
        need(type(value) is int and value >= 0, 'Invalid unary block value')
        ones.update(range(p + 1, p + value + 2))
        p += value + 2
    return ones


def verify(native_path, dense_path, map_path, receipt_path, parent_receipt_path):
    native = table(native_path)
    dense = table(dense_path)
    rename = {int(k): v for k, v in load(map_path).items()}
    receipt = load(receipt_path)
    parent = load(parent_receipt_path)
    need(receipt == parent, 'U217 and U218 startup records differ')
    need(receipt['status'] == 'CALIBRATED_DIRTY_ROOT_SEED', 'Wrong startup status')
    need(receipt['steps'] == len(receipt['trace']) == 95726, 'Wrong startup duration')
    need(receipt['state'] == 84 and receipt['head'] == -8 and receipt['gap'] == 1,
         'Wrong root geometry')
    need(receipt['registers'] == [4, 0, 0, 0, 0, 0, 0, 0, 0],
         'Wrong enumeration register seed')
    need(receipt['spares'] == [1] * 40, 'Wrong actual spare-register tail')
    q = dq = h = dh = 0
    ones = set()
    dones = set()
    rows = set()
    removed_visits = 0
    for tick, expected in enumerate(receipt['trace']):
        b = int(h in ones)
        db = int(dh in dones)
        need((q, b) in native and (dq, db) in dense, 'Premature halt')
        w, move, z = native[q, b]
        dw, dmove, dz = dense[dq, db]
        need(expected == [q, h, b, w, move, z],
             'Native trace disagreement at step ' + str(tick))
        need((dq, dh, db, dw, dmove, dz) ==
             (rename[q], h, b, w, move, rename[z]),
             'Dense trace disagreement at step ' + str(tick))
        rows.add((q, b))
        removed_visits += int(q == 112)
        if w:
            ones.add(h)
        else:
            ones.discard(h)
        if dw:
            dones.add(dh)
        else:
            dones.discard(dh)
        q, h = z, h + move
        dq, dh = dz, dh + dmove
    need((q, h) == (receipt['state'], receipt['head']), 'Wrong final native control')
    need((dq, dh) == (rename[q], h), 'Wrong final dense control')
    need(ones == dones == set(receipt['one_cells']), 'Wrong complete final tape')
    frame = expected_frame(h, receipt['gap'], receipt['registers'], receipt['spares'])
    need(ones == frame, 'Terminal tape does not exactly encode the calibrated frame')
    need(removed_visits == 0 and (172, 0) not in rows,
         'Changed state or redirected transition appears during startup')
    return {
        'status': 'INDEPENDENT_NATIVE_AND_DENSE_BLANK_REPLAY_PASS',
        'startup_steps': 95726, 'native_state': q, 'dense_state': dq,
        'head': h, 'gap': 1, 'registers': receipt['registers'],
        'spares': receipt['spares'], 'nonzero_cells': len(ones),
        'complete_tape_compared': True, 'identical_to_parent_trace': True,
        'removed_state_visits': 0, 'changed_transition_visits': 0,
        'native_sha256': hashlib.sha256(native_path.read_bytes()).hexdigest(),
        'dense_sha256': hashlib.sha256(dense_path.read_bytes()).hexdigest(),
        'scope': 'Exact finite initialization replay; not a nonhalting test.',
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ('native', 'dense', 'mapping', 'startup', 'parent_startup', 'output'):
        ap.add_argument('--' + name.replace('_', '-'), required=True, type=Path)
    a = ap.parse_args()
    result = verify(a.native, a.dense, a.mapping, a.startup, a.parent_startup)
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
