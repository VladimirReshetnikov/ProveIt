Optional research beyond the accepted U217 reduction
====================================================

The accepted machine is ../machine/u217.tm. It uses the unchanged primary
U218 source. Nothing in this directory is needed by its proof or replay.

1. Runtime search
-----------------
runtime_research.txt records the discovery and the exact bounded search
scopes. The successful step was to allow BOTH machines to advance before
their full configurations must meet. An earlier one-old-step criterion
missed the 112-to-134 deletion. The small final theorem depends only on
the right-zero invariant and three explicitly checked paths, not on the
large abstract state-space used for discovery.

Follow-up U217 searches found no verified U216. The final restricted
two-row search considered 10,653 eligible state pairs with radius-six
local invariants and block lengths at most 15. These are incomplete
searches, not lower bounds or optimality results. The fixed-point and
search summary is invariant_search_summary.json. Working-tree file
names in the historical note identify the original research session;
the accepted portable checkers are in ../code/.

2. Emitter-only source experiments
---------------------------------
source_experiments.json and source_research.txt record wider source
parenthesization, reassociation of the full bundle, and finer constructor
splitting. Each retained a minimum of 202 subtrees in its bounded beam.
A correct unary R(t,0) helper reduced primitive occurrences by 27 but
increased the source to 203 subtrees. A quantifier-merging idea cost 206.
These counts concern source trees, not physical Turing-machine states.

3. Five composed 201-subtree register sources
--------------------------------------------
uncompiled_sources/ preserves five prospective sources that combine the
same exact U218 covering emitter with previously investigated K215
transfer/cache enumerators. Four have 3,849 primitive occurrences; the
ST215 composition has 3,872. All have 201 distinct subtrees, maximum
address depth 42, and maximum consecutive-zero address run 6.

They are deliberately labeled UNCOMPILED. No binary transition table,
complete physical allocation, startup, or arbitrary-register runtime
certificate is supplied for them. They are not 201-state Turing machines,
and are not a verified improvement over U217. Their generic proof-search
calibration would also need explicit composition with the U calculus
when developing a new complete candidate.

The exact predecessor source files, original download metadata, and
inherited cache-transfer proof/review notes are in source_parents/.
The notes preserve their historical ZFC context; replacing the nonlogical
emitter does not import the old fixed-machine ZFC theorem as a new U
endpoint. The new source splice replaces the closed primitive interval
[2884,4481) with the exact 737-leaf U218 emitter, retaining all exterior
primitive operands. Its precise result and metric census are in
uncompiled_sources/summary.json.

To reproduce this optional syntax-only construction, without a solver
or network, run from the package root:

  python3 -B research/replay_source_candidates.py

This validates exact output bytes, the closed splice, exterior primitive
words, and the recorded metrics. Its scope is source reconstruction.
The accepted U217 can be reproduced independently with ../reproduce.py.

All inherited code and prose retain their original notices and terms;
see ../NOTICE.txt and ../licenses/.
