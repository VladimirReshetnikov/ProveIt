#!/usr/bin/env python3
"""Reconstruct five optional register-source candidates; no TM claim is made.

This checks the exact closed splice and source metrics only. The accepted
U217 uses none of these sources. The vendored tree operations retain the
U222/ProveIt/Wade attribution in vendor_build_source.py and ../licenses/.
"""
from pathlib import Path
import hashlib
import json
import vendor_build_source as s

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def main():
    source_raw = (ROOT / 'machine/sites.json').read_bytes()
    s.require(hashlib.sha256(source_raw).hexdigest() ==
              'bc70b28ff4628db5b9b0c9bd87f560697223e4887f2568b0ece801906713db8f',
              'Wrong unchanged U218 source')
    replacement = s.parse(json.loads(source_raw))
    for bit in '11010010011101010110111111':
        replacement = replacement[int(bit)]
    s.require(s.size(replacement) == 737 and s.boundary(replacement) == (0, 0, False),
              'The U218 emitter is not the expected closed factor')
    records = json.loads((HERE / 'uncompiled_sources/summary.json').read_text())
    results = []
    for record in records:
        old_rows = json.loads((HERE / record['parent']).read_text())
        old = s.parse(old_rows)
        lo, hi = record['old_interval']
        new = s.splice(old, lo, hi, replacement)
        new_rows = s.sites(new)
        encoded = (json.dumps(new_rows, separators=(',', ':')) + '\n').encode('ascii')
        s.require(encoded == (HERE / record['source']).read_bytes(), 'Candidate bytes differ')
        s.require(hashlib.sha256(encoded).hexdigest() == record['sha256'], 'Digest differs')
        s.require(s.metrics(new) == record['metrics'], 'Source metrics differ')
        s.require(list(s.boundary(new)) == record['boundary'], 'Source boundary differs')
        s.require([x[1:] for x in new_rows[:lo]] == [x[1:] for x in old_rows[:lo]],
                  'Exterior instruction prefix changed')
        s.require([x[1:] for x in new_rows[lo + 737:]] == [x[1:] for x in old_rows[hi:]],
                  'Exterior instruction suffix changed')
        results.append({'source': record['source'], 'sha256': record['sha256'],
                        **record['metrics']})
    print(json.dumps({'status': 'FIVE_UNCOMPILED_SOURCE_SPLICES_RECONSTRUCTED',
                      'scope': 'Exact source syntax only; no literal TM allocation or runtime claim.',
                      'sources': results}, indent=2))


if __name__ == '__main__':
    main()
