U217: a 217-state reduction of the primary U218 consistency machine
=================================================================
Research prepared for Vladimir Reshetnikov, 28 October 2026.

RESULT
------
U217 has 217 working states and 434 binary transitions. It uses one
two-way infinite tape and one head, alphabet {0,1}, blank symbol 0, and
left/right moves only. All blank-tape initialization is included.

The dense machine starts in state 0 at tape coordinate 0; its working
states are 0,...,216, and separate halt is 217. The native-label table
uses start 0 and separate halt 254. Native state 218, which appears in
the proof, is a working state.

The complete native patch to the exact supplied U218 is:

  change  172 0 0 L 112   to   172 0 0 L 134
  delete  112 0 0 R 157
  delete  112 1 1 R 209

Every other retained transition and the complete register source stay
identical. The source still has 202 distinct subtrees and 3,891 primitive
occurrences. This is a literal binary-machine reduction, not a source-node
count or a machine requiring an external program tape.

PROOF
-----
Every old execution from state 0 satisfies:

  old state 112 implies tape(head+1) = 0.

The unique incoming row 172/0 writes that zero and moves left. Under
this invariant, the old state-112 behavior and new state-134 behavior
have three exact block matches, with old/new lengths 1/3, 5/3, and 5/3.
The entire tape, final head, and final control state coincide. Other
old states have a one-step / one-step match. No matched block contains
an intermediate halt.

Induction on these finite matched blocks gives:

  PA proves Halt(U217, blank) iff Halt(U218, blank).

This new relative theorem holds without consistency assumptions. The
all-tape mathematical theorem is stronger: every initial binary tape
in state 0 gives halting equivalence. If old and new first-halting times
are n and m, then 3*n <= 5*m and m <= 3*n.

Composing with the explicit mathematical dependencies in the supplied
U218/U222/unary-power-covering packet yields:

  PA proves not Halt(U217, blank) iff Con(U) iff Con(PA).

This is ordinary mathematical proof formalizable in PA with exact
executable local and symbolic-induction checks. No newly compiled
MM0/Rocq/Lean certificate for the complete U217 endpoint is claimed.
The earlier K215 formal theorem concerns its own exact ZFC machine.
No unconditional consistency, actual nonhalting, priority, or global
minimality is asserted. No verified 216-state machine was obtained.

VERIFICATION
------------
* Two separately written local verifiers each check all 6,960 admissible
  five-cell frames. The unknown exterior is arbitrary and untouched.
* Fifteen consistent mutations of BOTH compared tables are rejected:
  two violate the predecessor guard and thirteen violate block equality.
* The independent checker rejects eight wrong redirection targets and
  demonstrates that the right-zero guard is necessary.
* The complete final table passes all 5,060 arbitrary-register symbolic
  cases and all four finite-list traversal schemas. All 434 rows occur.
* The entire 95,726-step blank initialization trace is identical to U218's.
  It reaches native state 84, head -8, gap 1, registers (4,0,0,0,0,0,0,0,0),
  forty one-valued spare registers, and exactly 95 nonzero tape cells.

The two finite-frame verifiers use different five-cell windows: offsets
[-2,-1,0,1,2] and [-1,0,1,2,3]. Both cover all necessary reads. Runtime
receipts use a separate inherited legacy label map: their traversal
entry 112 is native state 97; deleted native state 112 was legacy 130.

Independent checks were written by separate assistant agents within one
research collaboration; they are not represented as external human review.

START HERE
----------
  paper/report.pdf                  Complete proof and exact table appendix.
  paper/report.tex                  Editable LaTeX source.
  paper/transition_table.tex        Automatically generated exact table.
  machine/u217.tm                   Dense table, working 0,...,216; halt 217.
  machine/u217.native.tm            Historical labels; halt 254.
  machine/state_map.json            Checked native-to-dense bijection.
  machine/sites.json                Exact unchanged U218 register source.
  code/build_u217.py                Deterministic construction.
  code/check_u217.py                First local proof-premise verifier.
  code/verify_u217_independent.py    Independent verifier and controls.
  code/check_u217_controls.py       Fifteen common-table semantic controls.
  evidence/                        Fresh local, runtime, and startup records.
  reviews/                         Mathematical reviews and a second proof.
  research/                        Bounded search notes and unadopted ideas.
  inputs/U218_ConPA_2026-10-28.zip   Exact complete predecessor archive.
  licenses/                        Inherited licenses and notices.

Every transition-table line is:

  state  read_symbol  write_symbol  L_or_R  next_state

OFFLINE REPRODUCTION
--------------------
Python 3.10 or later, standard library only; no solver or network needed.
From this extracted directory:

  python3 -B reproduce.py
  python3 -B reproduce.py --full
  python3 -B reproduce.py --full --report /chosen/path/replay.json

The default checks exact reconstruction, the state bijection, both local
proof certificates, mutation controls, complete blank startup, saved
symbolic case coverage and input identities, and the parent archive's
reconstruction audit. --full additionally regenerates all 5,060 symbolic
cases and exactly compares their records, four traversal schemas, and
startup against the delivered evidence. Allow several minutes for full
replay; the measured duration is not a correctness premise.

All generated checking work is temporary. Only an explicit --report path
is a persistent verification output. Keep the release unchanged for its
SHA256SUMS audit. An edited PDF or source file changes that manifest.

To regenerate the document using a normal pdfLaTeX installation:

  python3 -B code/build_paper_data.py
  cd paper
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

RECORDED RELEASE CHECKS
-----------------------
The integrated full reconstruction and proof replay completed successfully.
Its exact receipt and log are evidence/package_full_replay.json and
evidence/package_full_replay.log. This run preceded manifest assembly, so its
manifest field accurately says NOT_PRESENT_DURING_ASSEMBLY. The delivered
SHA256SUMS binds all final files and is checked before and after every replay.
Document layout and mathematical reviews are retained with the evidence.

EXACT SHA-256 IDENTITIES
-----------------------
U217 native:
fe7b6d449b6b9a57d562b4e6f3ec0a77b27a4b72ccfc41775d57a3e550302d0f
U217 dense:
639da240bdb466f2a50ed40e36355a5677b6ecaaf5ef95e2e5309f4682b55be6
Unchanged source:
bc70b28ff4628db5b9b0c9bd87f560697223e4887f2568b0ece801906713db8f
Exact supplied U218 ZIP:
73c7d0774d955c9b003eec0e9e0876e280f028f653a127c7518d132b914c8bc9
