#!/usr/bin/env python3
"""Offline exact reconstruction and verification of U217.

Python 3.10+, standard library only. The default rechecks the pinned parent,
constructs the new tables, replays two local proofs and their negative controls,
replays the complete blank startup, and audits the saved symbolic case census.
--full additionally rederives all 5,060 arbitrary-register cases and all four
traversal schemas. New work is temporary except an explicit --report file.
The inherited runtime verifier is an executable mathematical checker, not a
proof-assistant kernel. Attribution remains in the exact supplied archives.
"""
from pathlib import Path, PurePosixPath
import argparse
from collections import Counter
import gzip
import hashlib
import json
import os
import stat
import subprocess
import sys
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'code'))
from build_u217 import (build, parse, need, PARENT_SHA256, NATIVE_SHA256,
                        DENSE_SHA256, SOURCE_SHA256, ARCHIVE_SHA256,
                        NESTED_ARCHIVE_SHA256)
from verify_bootstrap import verify as verify_bootstrap

CASES_SHA256 = '1c90db727ed13d02b9a29e2d848bd980429e94ad12fde14edce64b9178b804d4'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def raw_json(path):
    raw = path.read_bytes()
    return gzip.decompress(raw) if path.suffix == '.gz' else raw


def load(path):
    return json.loads(raw_json(path))


def command(script, arguments, cwd, label):
    print(label + ' ...', flush=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONOPTIMIZE', None)
    result = subprocess.run([sys.executable, '-B', str(script), *map(str, arguments)],
                            cwd=cwd, env=env, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    if result.returncode:
        print(result.stdout, end='')
        raise RuntimeError(label + ' failed with exit ' + str(result.returncode))
    print(label + ': PASS', flush=True)


def manifest_check():
    manifest = ROOT / 'SHA256SUMS'
    if not manifest.is_file():
        return {'status': 'NOT_PRESENT_DURING_ASSEMBLY', 'files_checked': 0}
    seen = set()
    for line in manifest.read_text().splitlines():
        if not line:
            continue
        parts = line.split('  ', 1)
        need(len(parts) == 2, 'Malformed SHA256SUMS line')
        expected, name = parts
        rel = PurePosixPath(name)
        need(len(expected) == 64 and set(expected) <= set('0123456789abcdef'),
             'Malformed SHA256 digest')
        need(rel.parts and not rel.is_absolute() and '..' not in rel.parts
             and '\\' not in name and name == str(rel), 'Unsafe manifest path')
        need(name not in seen and name != 'SHA256SUMS', 'Duplicate/self manifest entry')
        seen.add(name)
        path = ROOT.joinpath(*rel.parts)
        need(path.is_file() and not path.is_symlink(), 'Missing/nonregular manifest file')
        need(sha(path) == expected, 'Release hash mismatch: ' + name)
    principal = {'reproduce.py', 'machine/u217.native.tm', 'machine/u217.tm',
                 'machine/sites.json', 'machine/state_map.json',
                 'inputs/U218_ConPA_2026-10-28.zip', 'inputs/u218.native.tm',
                 'code/build_u217.py', 'code/check_u217.py',
                 'code/verify_u217_independent.py', 'code/check_u217_controls.py',
                 'code/verify_bootstrap.py', 'evidence/runtime.json',
                 'evidence/runtime_cases.json.gz', 'evidence/startup.json.gz',
                 'paper/report.tex', 'paper/report.pdf'}
    need(principal <= seen, 'Manifest omits a principal artifact')
    actual = {str(p.relative_to(ROOT).as_posix()) for p in ROOT.rglob('*')
              if p.is_file() and p != manifest}
    need(actual == seen, 'Release contains unmanifested files or missing entries')
    return {'status': 'PASS', 'files_checked': len(seen), 'manifest_sha256': sha(manifest)}


def extract(archive, digest, destination, expected_root):
    need(sha(archive) == digest, 'Wrong pinned archive: ' + archive.name)
    seen = set()
    with zipfile.ZipFile(archive) as z:
        for member in z.infolist():
            name = member.filename
            rel = PurePosixPath(name)
            need(rel.parts and not rel.is_absolute() and '..' not in rel.parts
                 and '\\' not in name, 'Unsafe archive member')
            need(rel.parts[0] == expected_root, 'Unexpected archive root')
            need(name not in seen, 'Duplicate archive member')
            seen.add(name)
            need(not stat.S_ISLNK((member.external_attr >> 16) & 0xffff),
                 'Archive symlink rejected')
            path = destination.joinpath(*rel.parts)
            if member.is_dir():
                path.mkdir(parents=True, exist_ok=True)
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                with z.open(member) as inp, path.open('wb') as out:
                    while True:
                        chunk = inp.read(1024 * 1024)
                        if not chunk:
                            break
                        out.write(chunk)
    parent = destination / expected_root
    need((parent / 'reproduce.py').is_file(), 'Archive reproduction entrypoint absent')
    return parent


def normalize_table(table, checker_parent):
    legacy = load(checker_parent / 'code/inputs/legacy_mapping.json')
    mapping = {int(k): int(v) for k, v in legacy.items()}
    states = {q for q, _ in table} | {254}
    for q in states:
        if q not in mapping:
            mapping[q] = q + 1000
    need(len({mapping[q] for q in states}) == len(states),
         'Legacy runtime labeling is not injective')
    return {(mapping[q], b): (w, d, mapping[z])
            for (q, b), (w, d, z) in table.items()}


def runtime_header(report, sites, checker_parent):
    need(report['status'] == 'UNIVERSAL_MATHEMATICAL_PASS', 'Runtime is not proved')
    need(report['table_sha256'] == NATIVE_SHA256
         and report['sites_sha256'] == SOURCE_SHA256, 'Wrong runtime table/source binding')
    need(report['working_states'] == 217 and report['site_count'] == len(sites) == 3891,
         'Wrong runtime state/source census')
    need(report['expected_cases'] == report['proved_cases'] == 5060
         and report['failures'] == [], 'Incomplete arbitrary-register coverage')
    need(report['startup_status'] == 'CALIBRATED_DIRTY_ROOT_SEED',
         'Wrong runtime startup status')
    need(report['checker_sha256'] == sha(checker_parent / 'code/runtime/symbolic_runtime.py')
         and report['helper_sha256'] == sha(checker_parent / 'code/runtime/independent_runtime.py'),
         'Wrong inherited symbolic checker identities')
    need(len(report['blocks']) == 4, 'Wrong traversal-schema count')


def audit_saved_cases(cases, report, sites, table, checker_parent):
    expected = [(i, positive) for i, site in enumerate(sites)
                for positive in ((False, True) if site[1] == 'CD' else (False,))]
    actual = [(record['site_index'], record['positive']) for record in cases]
    need(actual == expected and len(actual) == 5060, 'Wrong ordered guarded-case inventory')
    literal = normalize_table(table, checker_parent)
    coverage = set()
    steps = 0
    minimum = None
    for record in cases:
        need(type(record['positive']) is bool, 'A guard flag is not Boolean')
        duration, motion = record['duration'], record['motion']
        need(len(duration) == len(motion) == 13, 'Wrong affine-vector dimension')
        need(all(type(v) is int for v in duration + motion), 'Nonnumeric affine coefficient')
        need(duration[0] > 0 and all(v >= 0 for v in duration[1:]),
             'Nonpositive or unbounded-below duration certificate')
        minimum = duration[0] if minimum is None else min(minimum, duration[0])
        rows = [tuple(row) for row in record['rows']]
        need(rows == sorted(set(rows)) and set(rows) <= literal.keys(),
             'Invalid or duplicate normalized transition rows')
        need(type(record['symbolic_steps']) is int and record['symbolic_steps'] > 0,
             'Invalid symbolic-rule count')
        need(sum(record['kinds'].values()) == record['symbolic_steps']
             and set(record['kinds']) <= {'literal', 'unary', 'list'},
             'Wrong symbolic-rule census')
        coverage.update(rows)
        steps += record['symbolic_steps']
    need(coverage == set(literal) and len(coverage) == 434,
         'Saved symbolic records do not cover all literal rows')
    for block in report['blocks']:
        need(block['arbitrary_contexts'] is True and block['steps'] == 'v+2',
             'Wrong traversal-schema contract')
        for event in block['trace']:
            need(event[0] in ('literal', 'unary'), 'Unexpected traversal proof rule')
            q, b, w, d, z = event[1]
            need(literal.get((q, b)) == (w, d, z),
                 'Traversal schema uses a different literal transition')
    return {'cases': len(cases), 'symbolic_rules': steps,
            'covered_literal_rows': len(coverage), 'minimum_duration_constant': minimum,
            'legacy_labels_are_not_native_labels': True}


def compare_parent_cases(cases, old_cases, startup, old_startup):
    need([(x['site_index'], x['positive']) for x in cases] ==
         [(x['site_index'], x['positive']) for x in old_cases], 'Parent guard inventory differs')
    histogram = Counter()
    motions = coefficients = 0
    for old, new in zip(old_cases, cases):
        motions += int(old['motion'] == new['motion'])
        coefficients += int(old['duration'][1:] == new['duration'][1:])
        histogram[tuple(b - a for a, b in zip(old['duration'], new['duration']))] += 1
    return {
        'same_guard_inventory': True, 'total_cases': len(cases),
        'identical_motion_cases': motions, 'identical_variable_coefficients_cases': coefficients,
        'duration_difference_histogram': [{'delta': list(delta), 'cases': count}
                                          for delta, count in sorted(histogram.items())],
        'old_covered_row_count': len({tuple(row) for x in old_cases for row in x['rows']}),
        'new_covered_row_count': len({tuple(row) for x in cases for row in x['rows']}),
        'startup_exact_object_equal': startup == old_startup,
        'startup_old_steps': old_startup['steps'], 'startup_new_steps': startup['steps'],
        'startup_state112_visits': sum(x[0] == 112 for x in startup['trace']),
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--full', action='store_true')
    ap.add_argument('--report', type=Path)
    args = ap.parse_args()
    need(sys.flags.optimize == 0, 'Inherited verification requires Python without -O or -OO')
    began = time.monotonic()
    before = manifest_check()
    sites_path = ROOT / 'machine/sites.json'
    need(sha(sites_path) == SOURCE_SHA256, 'Wrong exact source')
    sites = load(sites_path)
    saved = load(ROOT / 'evidence/runtime.json')
    case_raw = raw_json(ROOT / 'evidence/runtime_cases.json.gz')
    need(hashlib.sha256(case_raw).hexdigest() == CASES_SHA256,
         'Saved case-record bytes differ from the completed U217 run')
    cases = json.loads(case_raw)
    startup = load(ROOT / 'evidence/startup.json.gz')
    with tempfile.TemporaryDirectory(prefix='u217-reproduce-') as dirname:
        tmp = Path(dirname)
        parent = extract(ROOT / 'inputs/U218_ConPA_2026-10-28.zip', ARCHIVE_SHA256,
                         tmp / 'parent', 'U218_ConPA_2026-10-28')
        need((ROOT / 'inputs/u218.native.tm').read_bytes() ==
             (parent / 'machine/u218.native.tm').read_bytes(), 'Parent table copy differs')
        need(sites_path.read_bytes() == (parent / 'machine/sites.json').read_bytes(),
             'U217 source differs from U218')
        command(parent / 'reproduce.py', ['--report', tmp / 'parent_report.json'], parent,
                'Pinned U218 reconstruction, source, proofs, and bootstrap audit')
        parent_result = load(tmp / 'parent_report.json')
        need(parent_result['status'] == 'U218_RECONSTRUCTION_AND_PROOF_AUDIT_PASS'
             and parent_result['native_sha256'] == PARENT_SHA256,
             'Pinned parent replay did not pass')
        machine = tmp / 'machine'
        built = build(ROOT / 'inputs/u218.native.tm', sites_path, machine)
        for name in ('u217.native.tm', 'u217.tm', 'sites.json', 'state_map.json'):
            need((machine / name).read_bytes() == (ROOT / 'machine' / name).read_bytes(),
                 'Deterministic reconstruction differs: ' + name)
        if (ROOT / 'machine/machine_summary.json').is_file():
            need(load(machine / 'machine_summary.json') ==
                 load(ROOT / 'machine/machine_summary.json'), 'Machine summary differs')
        print('Exact 217-state tables, unchanged source, and state bijection: PASS', flush=True)
        checks = [
            ('check_u217.py', [ROOT / 'inputs/u218.native.tm', machine / 'u217.native.tm',
                              '--output', tmp / 'local.json'],
             'local.json', 'local_certificate.json', 'Finite local block induction obligations'),
            ('verify_u217_independent.py', ['--old', ROOT / 'inputs/u218.native.tm',
                                           '--new', machine / 'u217.native.tm',
                                           '--output', tmp / 'independent.json'],
             'independent.json', 'independent_certificate.json',
             'Independent local proof, eight wrong-target controls, and guard necessity'),
            ('check_u217_controls.py', [ROOT / 'inputs/u218.native.tm', machine / 'u217.native.tm',
                                       '--output', tmp / 'controls.json'],
             'controls.json', 'local_controls.json', 'Fifteen shared-table semantic fault controls'),
        ]
        for script, arguments, temporary, published, label in checks:
            command(ROOT / 'code' / script, arguments, tmp, label)
            need(load(tmp / temporary) == load(ROOT / 'evidence' / published),
                 'Local certificate differs: ' + published)
        bootstrap = verify_bootstrap(machine / 'u217.native.tm', machine / 'u217.tm',
                                     machine / 'state_map.json', ROOT / 'evidence/startup.json.gz',
                                     parent / 'evidence/startup.json')
        print('All 95,726 startup steps in native and dense labels, and complete frame: PASS',
              flush=True)
        checker_parent = extract(parent / 'inputs/U222_ConU_2026-10-28.zip',
                                 NESTED_ARCHIVE_SHA256, tmp / 'checker_parent',
                                 'u222_consistency_machine')
        runtime_header(saved, sites, checker_parent)
        stats = audit_saved_cases(cases, saved, sites,
                                  parse((machine / 'u217.native.tm').read_bytes()), checker_parent)
        comparison = compare_parent_cases(cases, load(parent / 'evidence/runtime_cases.json'),
                                          startup, load(parent / 'evidence/startup.json'))
        need(comparison == load(ROOT / 'evidence/comparison.json'),
             'Exact parent/new case-clock comparison differs')
        print('Saved universal cases, literal bindings, traversal schemas, and affine clocks: PASS',
              flush=True)
        if args.full:
            command(checker_parent / 'code/validate_native.py',
                    [machine / 'u217.native.tm', machine / 'sites.json', tmp / 'fresh_runtime'],
                    tmp, 'Rederive all 5,060 arbitrary-register cases and four traversal schemas')
            fresh = load(tmp / 'fresh_runtime/runtime.json')
            runtime_header(fresh, sites, checker_parent)
            need({k: v for k, v in fresh.items() if k != 'seconds'} ==
                 {k: v for k, v in saved.items() if k != 'seconds'},
                 'Regenerated runtime summary or traversal schemas differ')
            need(load(tmp / 'fresh_runtime/runtime_cases.json') == cases,
                 'Regenerated symbolic case records differ')
            need(load(tmp / 'fresh_runtime/startup.json') == startup,
                 'Regenerated exact startup differs')
        result = {
            'status': 'U217_FULL_REPRODUCTION_PASS' if args.full else
                      'U217_RECONSTRUCTION_AND_PROOF_AUDIT_PASS',
            'working_states': 217, 'transition_rows': 434,
            'graph_reachable_working_states': 217,
            'source_occurrences': 3891, 'source_dag_nodes': 202,
            'source_unchanged_from_U218': True,
            'exact_native_dense_and_bijection_reconstructed': True,
            'parent_reproduction_passed': True,
            'both_local_block_checkers_passed': True,
            'shared_table_semantic_controls_rejected': 15,
            'independent_wrong_target_controls_rejected': 8,
            'guard_necessity_control_passed': True,
            'bootstrap': bootstrap, 'runtime_case_audit': stats,
            'comparison_with_U218': comparison,
            'symbolic_cases_freshly_rederived': args.full,
            'native_sha256': NATIVE_SHA256, 'dense_sha256': DENSE_SHA256,
            'source_sha256': SOURCE_SHA256, 'parent_archive_sha256': ARCHIVE_SHA256,
            'scope': 'Ordinary mathematical proof and executable verification. '
                     'No new proof-assistant kernel certificate for the complete endpoint.',
        }
    after = manifest_check()
    need(before == after, 'Release manifest or its files changed during reproduction')
    result['manifest'] = after
    result['seconds'] = round(time.monotonic() - began, 3)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
