# A 217-state blank-tape candidate for Con(ZFC)

This archive supplies an explicit deterministic **binary, single-tape Turing
machine with 217 working states**, a separate halt state, and **434 transitions**.
It starts in state 0 at cell 0 on an entirely zero, two-way infinite tape.
The state count includes the complete initializer.

The ordinary mathematical proof, using the exact inherited ProveIt numerical
calculus calibration, establishes the ZFC-formalizable equivalence

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{BlankHalts}(M_{217})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

Read **k217_exposed_marker.pdf** for the proof, exact construction, verification
scope, and complete canonical transition table. Its LaTeX source is included.
This is an **ordinary mathematical proof with executable induction certificates**.
A new exact-K217 Lean/Rocq endpoint has not been compiled, and an internal PA
equivalence is not claimed. The proof neither assumes nor asserts Con(ZFC).

## The new state saving

Start from the pinned dominated-rho8 K218 table, whose source has 203 distinct
subtrees. At source prefix `11101001001110010`, replace

```text
(A, (((B,C),D),E))
```

by

```text
((A,B), ((C,D),E)).
```

The five factors are closed and halt-free, with 14, 27, 53, 374, and 3,682
primitive leaves. Exactly 94 leaf addresses change; the full primitive word
and complete guarded ordinal control graph remain the same. The source still
has **203 distinct subtrees**. The useful difference is which physical helper
circuit exists.

The following four native rows implement the new source layout:

| Row | Dominated K218 | Reassociated prefold K218 |
|---|---|---|
| `201/0` | `0 R 92` | `0 R 188` |
| `188/0` | `0 R 90` | `0 R 92` |
| `188/1` | `1 R 146` | `1 R 90` |
| `210/0` | `0 R 188` | `0 R 146` |

The old states 69 and 400 agree on read 1. Their read-0 targets are 105 and
104. Their unique predecessors write, respectively, 1 and 0 and move right,
so the cell immediately left of the head contains the missing distinction.
The exposed helper can read that bit and return to the correct target.

Delete state 400, change `224/0` from `0 R 400` to `0 R 69`, and change
`69/0` from `0 R 105` to `0 L 188`. On a scanned zero, this performs:

| Predecessor marker | Three-step route | Old role |
|---|---|---|
| 0 | `69 -> 188 -> 92 -> 104` | 400 |
| 1 | `69 -> 188 -> 90 -> 105` | 69 |

Only the scanned cell and its left neighbor are read. Both are preserved,
and the head ends at the old one-step endpoint. The shared read-1 branch
still takes one step. Thus every old step has a matching positive block
of one or three new steps, on every initial tape from state 0.

The net change from the exact dominated K218 is **six changed retained rows,
two deleted rows, and zero added states**. Source size alone would not have
predicted this saving.

## Exact machine identities

| Artifact | SHA-256 |
|---|---|
| `machine/k217.native.tm` | `c902a3c5e81176230a2213d631e2e691573c167fb03e9bdb09ef5c88154f3099` |
| `machine/k217.tm` | `a2b8bc2d4822962ad32819fe475a7d62b0d483bc4f41977bff292742f70b3e8c` |
| `machine/sites217.json` | `9eac900e83742470893ea433cb0868e9ff6296f905cd6f3359b7a2c0e3114655` |
| `machine/prefold218.native.tm` | `34617022def75d88a4f357589d7a48f468d17b58c910947ed0738aa3c6a5760a` |

The canonical table uses working labels 0–216 and separate halt 217.
The native table uses historical labels, initial 0, and separate halt 254.
The explicit BFS bijection is in `machine/canonicalization.json`.
Every working state is reachable in the transition graph; this does not
claim every state appears on the actual blank run.

## Verification already completed

| Check | Result |
|---|---|
| Exact deterministic reconstruction | All four final table/source hashes reproduced |
| Source semantics | Full guarded ordinal graph equality; all register valuations |
| Source metrics | 203 distinct subtrees; 4,751 primitives; depth 45; zero run 6 |
| Independent fold proof | 432 ordinary mapped rows and four exact local cases |
| Separate inductive window audit | 1,104 invariant contexts; four nontrivial; negative control rejected |
| Quantified primitive runtime | **6,176 / 6,176 cases** |
| Symbolic proof rules used | 1,616,558 |
| Affine clocks | All coefficients nonnegative; every constant at least 13 |
| Native transition coverage | **434 / 434 rows** used by primitive proofs |
| Blank initialization | **312,617 steps**, complete frame and zero exterior |
| Portable full runtime replay | Case and startup receipts reproduced byte for byte |
| Inherited dominated-row proof | Both forward checkers rerun on the 3,728-node certificate |

The runtime proof ranges over independent natural registers, arbitrary natural
gap, arbitrary first spare value, and an arbitrary finite remaining spare list.
It uses induction over unary scans and finite lists. Its proof-construction
limits do **not** bound register values or actual running times. Independent
reviews audit the source, fold, startup, and runtime inventory; they are not
a second independently implemented universal runtime engine.

The blank startup reaches native dispatcher 84 (canonical 23), head −5, gap
80, and

```text
[N,T,W,A,D,H,X,Y,L] = [3,0,0,0,3,0,0,0,0].
```

There are 130 spare blocks, all of value 1, exactly 277 one-cells, and zero
everywhere else. The inherited block compiler provides cofinally many
refuting candidates, so the nonzero initial next-candidate and additive
counters are permitted. The proof does not substitute an initialized core
for the actual blank machine.

## Reproduce offline

Use **Python 3.10 or later, with assertions enabled**:

```sh
python3 -B verify_all.py
python3 -B verify_all.py --runtime
```

The first command authenticates the manifest, extracts the exact parent
archive into scratch, reruns its finite logical/source checks, reconstructs
the candidate, independently audits the source/fold/full startup, reproduces
the typeset table, checks the optional fixed-core experiment, and audits
the stored runtime inventory. The second also regenerates all 6,176
quantified primitive proofs. It usually takes a few minutes, depending
on the host. No network access or nonstandard Python package is needed.

Checks write to a temporary directory by default. To retain local receipts:

```sh
python3 -B verify_all.py --runtime --output ../k217-replay
```

The requested output must be outside this authenticated package. Exact
source/table reproduction alone is:

```sh
python3 -B code/construct217.py \
  --baseline-table machine/baseline218.native.tm \
  --baseline-source machine/baseline_sites218.json \
  --output ../k217-rebuilt
```

To rebuild the main PDF:

```sh
pdflatex -interaction=nonstopmode -halt-on-error k217_exposed_marker.tex
pdflatex -interaction=nonstopmode -halt-on-error k217_exposed_marker.tex
```

A further LaTeX pass may be necessary after pagination changes. The complete
table is generated by `python3 -B code/make_table_tex.py`.

## Archive layout

- `k217_exposed_marker.tex`, `.pdf`: the complete main report and table.
- `machine/`: final native/canonical tables, explicit prefold table, original
  dominated table, both source lists, and canonicalization map.
- `code/`: deterministic constructor, portable runtime driver, independent
  source/startup audit, independent local-fold audit, independent review,
  and complete-table generator.
- `evidence/runtime/`: every guarded case receipt, complete startup trace,
  summaries, and successful portable full-replay receipt.
- `evidence/`: exact construction and independently generated audit receipts.
- `reviews/`: detailed fold and logical-calibration proof reviews.
- `dependency/`: the **unchanged** parent report archive, including the full
  numerical proof certificate, all-natural macro calibration, runtime engine,
  source data, licenses, and notices.
- `appendix/fixed_core/`: a separate equiconsistent fixed-label axiom system,
  exact reviewed source modules, provenance, and source-level pricing.
- `manifest.json`: sizes and SHA-256 of every packaged file except itself.

The 22 MB runtime-case file and 21 MB startup trace are intentionally included
in full. ZIP compression makes them substantially smaller in the archive.

## A separate formalism result

Let `J(a,b,c)=nks222(a,b,c)` be the inherited exact nonlogical core,
`N(X)=I(X,1)`, and `V(a,b,c)=I(R(a,b),Q_c R(a,b))`. The inherited bundle is
`N(I(V(a,b,c),J(a,b,c)))`. It can be replaced, for equiconsistency, by:

1. General membership vacuity `V(a,b,c)` with both original gates
   `c != a` and `c != b`.
2. Only `N(J(1,3,c))` for `c >= 4` as the nonlogical core.

The completeness proof requires this core only at the fixed labels 1 and 3.
The optional appendix supplies the modular proof and exact source evidence.
Its direct source costs 211 distinct subtrees (4,718 primitives, depth 46,
zero run 9), so it does not contribute to the 217-state result. No revised
command compiler, binary runtime, or startup is claimed for this optional
source. Label-0,1 comparison data are separately marked as lacking the
required lower-proof adaptation; they are not premises of any delivered
217-state claim.

## Provenance and integration

Inspected repository commit:

`704b87442afbd571833a628cd558f1d207fd8b2f`

Immediate dependency:

`docs/incoming/K218_Dominated_Rho8_2026-10-20.zip`

Dependency archive SHA-256:

`080b4fe855c109ab77588c01c9e012d9572afa7721682306370ccb2eb22cbea9`

That report pins its own K219 inputs to
`f8ec6158f3bdc885139ee395ae34fe44c3251b9f`. Its dominated-row equivalence
is an inherited result, not a new contribution of this archive.

The directory can be incorporated under a name such as
`Computability/BusyBeaver/Research/ZFC/candidate-k217-exposed-marker/`.
No merge, publication, or modification of the upstream repository was
performed. The next kernel-integration work is identified in the report.
No unconditional nonhalting, optimality, or global priority claim is made.
