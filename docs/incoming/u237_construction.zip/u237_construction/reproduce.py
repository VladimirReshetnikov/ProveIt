#!/usr/bin/env python3
"""Offline reproduction of the delivered 237-state construction.

Uses the Python standard library. It runs finite and symbolic checks, not a
proof-assistant kernel. The mathematical induction arguments are in report.pdf.
By default all generated files go to a temporary directory; the release is
left unchanged. --receipt optionally records the final summary.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

BASE = Path(__file__).resolve().parent
DENSE_SHA = "b6d6b33aed3f42df4a84413faba7bcf4d6035d9f0d91fd693ab1fbdabea7cbbb"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(label, arguments, cwd=None):
    result = subprocess.run(
        [sys.executable, "-B", *map(str, arguments)], cwd=cwd,
        text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        check=False,
    )
    if result.returncode:
        print(result.stdout, end="")
        raise RuntimeError(f"{label} failed with exit status {result.returncode}")
    print(f"PASS: {label}", flush=True)
    return result.stdout


def integrity():
    inventory = BASE / "SHA256SUMS"
    if not inventory.exists():
        # The construction run can precede the final document hash inventory.
        return {"status": "NOT_PRESENT_DURING_INITIAL_PACKAGING", "files": 0}
    count = 0
    for line in inventory.read_text().splitlines():
        digest, relative = line.split("  ", 1)
        p = Path(relative)
        require(not p.is_absolute() and ".." not in p.parts,
                f"unsafe integrity inventory path: {relative}")
        require(sha(BASE / p) == digest, f"release hash mismatch: {relative}")
        count += 1
    return {"status": "PASS", "files": count}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--receipt", type=Path,
                        help="optional path for the final JSON receipt")
    args = parser.parse_args()
    hashes = integrity()
    require(sha(BASE / "machine/pa237.tm") == DENSE_SHA,
            "the final machine is not the claimed frozen table")
    manifest = json.loads((BASE / "construction_manifest.json").read_text())
    steps = []
    with tempfile.TemporaryDirectory(prefix="u237-reproduce-") as temporary:
        temp = Path(temporary)
        for optimized in (False, True):
            target = temp / ("generated-optimized" if optimized else "generated")
            argv = (["-O"] if optimized else []) + [
                BASE / "generate.py", "--output", target,
            ]
            label = "exact regeneration" + (" (python -O)" if optimized else "")
            run(label, argv)
            for relative, digest in manifest["output_sha256"].items():
                require(sha(target / relative) == digest,
                        f"regenerated output differs: {relative}")
            require(json.loads((target / "construction_manifest.json").read_text())
                    == manifest, "regenerated construction manifest differs")
            steps.append(label)

        # Run the portable verifiers from an isolated copy of only their inputs.
        check = temp / "checks"
        check.mkdir()
        for directory in ("data", "machine", "program", "verification"):
            shutil.copytree(BASE / directory, check / directory,
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        (check / "results").mkdir()
        checks = [
            ("literal patch and dense relabeling", "audit_relabeling.py", "relabeling_check.json"),
            ("exact source replacement and remaining control graph", "audit_source.py", "source_check.json"),
            ("bounded helper regression (supporting evidence)", "audit_helpers.py", "helper_regression.json"),
            ("universal affine instruction audit", "audit_runtime.py", "universal_instruction_check.json"),
            ("complete literal blank startup", "audit_bootstrap.py", "blank_bootstrap_check.json"),
        ]
        fresh = {}
        for label, script, receipt in checks:
            run(label, [check / "verification" / script])
            observed = json.loads((check / "results" / receipt).read_text())
            expected = json.loads((BASE / "results" / receipt).read_text())
            require(observed == expected, f"verification receipt differs: {receipt}")
            fresh[receipt] = observed
            steps.append(label)

        source_log = run("pinned upstream PA238 source-only check", [
            BASE / "vendor/pa238/PA/m238/check.py", "--source-only",
        ])
        require("150 PA modules, 192 dependency sources" in source_log,
                "unexpected upstream dependency inventory")
        require("kernel compilation NOT RUN" in source_log,
                "unexpected upstream verification scope")
        steps.append("pinned upstream PA238 source-only check")

        archive = BASE / "vendor/u/pa_unary_power_cover.zip"
        require(sha(archive) == "0fcb1117a5353766a3366bab04e56b4efbd0607833cdc73ffb34b67e6808b0ff",
                "supplied U archive hash mismatch")
        udir = temp / "u-input"
        with zipfile.ZipFile(archive) as z:
            for item in z.infolist():
                p = Path(item.filename)
                require(not p.is_absolute() and ".." not in p.parts,
                        "unsafe U archive entry")
            z.extractall(udir)
        drivers = list(udir.rglob("reproduce.py"))
        require(len(drivers) == 1, "expected one supplied U reproduction driver")
        u_log = run("supplied U package integrated checks", [drivers[0]], cwd=drivers[0].parent)
        steps.append("supplied U package integrated checks")

        result = {
            "status": "PASS_OFFLINE_FINITE_REPRODUCTION",
            "verification_scope": "Executable construction, symbolic tape, literal startup, source and input checks; not a new proof-assistant kernel certificate.",
            "working_states": 237,
            "transition_rows": 474,
            "dense_machine_sha256": DENSE_SHA,
            "universal_instruction_cases": fresh["universal_instruction_check.json"]["universal_cases"],
            "blank_startup_steps": fresh["blank_bootstrap_check.json"]["transitions"],
            "release_integrity": hashes,
            "passed_checks": steps,
            "upstream_source_check_output": source_log,
            "supplied_U_reproduction_output": u_log,
            "new_kernel_certificate": False,
        }
    encoded = json.dumps(result, indent=2) + "\n"
    if args.receipt:
        args.receipt.parent.mkdir(parents=True, exist_ok=True)
        args.receipt.write_text(encoded)
    print(encoded, end="")


if __name__ == "__main__":
    main()
