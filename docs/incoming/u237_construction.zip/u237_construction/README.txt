A 237-state binary Turing machine for Con(U)
===========================================

The delivered machine has 237 working states, a separate halt state, one
two-way infinite tape, alphabet {0,1}, blank 0, and only L/R moves.
Initial state: 0. Working states: 0..236. Halt state: 237.

The mathematical result is

    PA proves: Nonhalt(M_237) <-> Con(U).

U is exactly the equality-free unary weak power-cover theory in the supplied
pa_unary_power_cover.zip, retained unchanged under vendor/u/. The machine
searches the original PA proof stream. Its connection to U uses finite
proof translations whose correctness is provable in PA.

This is an explicit construction and a conventional mathematical proof
formalizable in PA, supported by executable symbolic and finite checks.
It is not a newly exported PA, MM0, or Rocq kernel certificate. The pinned
upstream PA238 kernel development was source-checked but not recompiled here.
The package does not claim global state minimality.

Start here
----------

report.pdf                       Full report and complete transition table
report.tex + sections/            Editable LaTeX proof source
machine/pa237.tm                  Canonical dense transition table
machine/pa237.native.tm           Same machine in original state labels
machine/pa237.csv                 CSV table (H denotes dense halt 237)
construction_manifest.json       Exact patch, state count, hashes, provenance

The SHA-256 of machine/pa237.tm is

  b6d6b33aed3f42df4a84413faba7bcf4d6035d9f0d91fd693ab1fbdabea7cbbb

A transition row is "state read write direction next". A comment beginning
with # is not a transition. The halt state has no outgoing rows.

Reproduction
------------

Python 3.10+ and its standard library suffice. No downloads are required.
From the extracted package directory:

  python3 reproduce.py

The driver checks the release hashes (when present), regenerates all fixed
construction outputs in normal and optimized Python, reruns every packaged
verification, checks the original PA238 source dependency closure, and runs
the original supplied U package's own checks. It uses temporary output and
leaves the delivered files unchanged. To save a fresh receipt:

  python3 reproduce.py --receipt /path/to/reproduction.json

The source and machine alone can be rebuilt with:

  python3 generate.py --output /path/to/fresh-output

The generator is deterministic. All integrity gates remain active under
python -O. Its exact output hashes are in construction_manifest.json.

To rebuild the report, use a LaTeX installation with the packages declared
in report.tex:

  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

What the verification establishes
--------------------------------

* 237 working states; 474 total binary transitions; exact dense relabeling.
* The new source differs only by the proved equality and conditional-clear
  replacements; the rest of its contracted control graph is identical.
* 8,817 affine symbolic instruction cases pass over all 4,409 primitive
  occurrences, arbitrary natural gap, and arbitrary complete register files
  with at least nine blocks. Some non-decrement cases are checked twice.
* Blank execution reaches the exact original PA238 whole-tape checkpoint
  after 817,846 transitions, including all 324 spare register blocks.
* A small bounded helper regression checks the reported instruction-count
  formulas; it is supporting evidence, separate from the all-natural proof.

The universal instruction audit uses four unchanged, proved PA238 register
file contracts. The only altered row in their conservatively listed states,
native state 1 reading 1, is never read by those contracts. The report gives
the exact justification and the boundary between symbolic checking,
mathematical induction, and formal kernel verification.

The source check of the original PA238 proof development reports 150 PA
modules and a 192-source dependency closure. It does not run Coq. Consult
vendor/pa238/PA/m238/README.md for the separate upstream kernel rebuild.

Attribution
-----------

The construction starts from Mira's PA238 machine at commit
9e343e549709e268cabc99f19e7c3d90f29ca4d4 of mira-emmy/busy-beaver.
The K-family work motivated the equality-helper search. The final seven-node
all-left helper, continuation sharing, and literal patch are proved in the
report. The input U manuscript and upstream source notices are preserved.
See NOTICE.txt and the report bibliography for exact sources and scope.
