#!/usr/bin/env python3
"""Independently verify the 237-state table, patch and dense relabeling."""
from pathlib import Path
import json,hashlib
from audit_runtime import read_table

def require(b,m):
    if not b: raise ValueError(m)

def audit(base):
    require(hashlib.sha256((base/'data/pa238.native.tm').read_bytes()).hexdigest()=='ffe370842d70bae96688ad5e290073edffe0bb213cf12fe562a75a74bec966de','reference table hash mismatch')
    old=read_table(base/'data/pa238.native.tm')
    native=read_table(base/'machine/pa237.native.tm')
    dense=read_table(base/'machine/pa237.tm')
    require(set(old)=={(q,b)for q in range(238)for b in(0,1)},'wrong reference table domain')
    patch={(1,1):(0,'R',21),(142,0):(0,'R',153),(142,1):(1,'R',148),
           (143,0):(0,'R',116),(143,1):(1,'R',152),(152,0):(0,'R',153),
           (152,1):(0,'L',130),(153,1):(0,'L',0)}
    expected={k:v for k,v in (old|patch).items()if k[0]!=151}
    require(native==expected,'native table differs from eight-row patch and deletion')
    states=sorted({q for q,b in native});require(len(states)==237,'not237 working states')
    mapping={q:i for i,q in enumerate(states)};mapping[238]=237
    require(mapping[0]==0,'wrong initial-state relabeling')
    converted={(mapping[q],b):(w,d,mapping[t])for(q,b),(w,d,t)in native.items()}
    require(dense==converted,'dense table is not exact relabeling')
    require(set(dense)=={(q,b)for q in range(237)for b in(0,1)},'dense state domain not0..236')
    require(all(0<=t<=237 for w,d,t in dense.values()),'invalid dense target')
    recorded=json.loads((base/'machine/state_map.json').read_text())
    require({int(q):v for q,v in recorded['native_to_dense'].items()}==mapping,'state map mismatch')
    # Static reachability includes both input symbols and counts only nonhalting states.
    seen={0}; todo=[0]
    while todo:
        q=todo.pop()
        for b in(0,1):
            t=dense[q,b][2]
            if t<237 and t not in seen:seen.add(t);todo.append(t)
    require(len(seen)==237,'dense table contains graph-unreachable working states')
    return {'status':'PASS_PATCH_AND_EXACT_STATE_RELABELLING','working_states':237,
            'transition_rows':474,'start':0,'halt':237,'deleted_native_state':151,
            'changed_rows':[[q,b,*old[q,b],*v]for(q,b),v in sorted(patch.items())],
            'all_working_states_statically_reachable':True,
            'native_sha256':hashlib.sha256((base/'machine/pa237.native.tm').read_bytes()).hexdigest(),
            'dense_sha256':hashlib.sha256((base/'machine/pa237.tm').read_bytes()).hexdigest()}

def main():
    base=Path(__file__).resolve().parents[1];r=audit(base)
    (base/'results/relabeling_check.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
