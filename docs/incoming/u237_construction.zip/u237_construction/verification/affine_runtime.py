#!/usr/bin/env python3
"""Exact affine symbolic execution for the PA237 instruction audit.

The path/gap part is checked literally against the transition table. The
register file is quantified universally, via four existing PA238 lemmas:
indexed_mark238, indexed_increment238, indexed_decrement_zero238, and
indexed_decrement_positive238. The only changed row in their conservatively collected state set is
state1/read1; the four file proofs never read that row. This script is independent Python evidence, not a Coq kernel
certificate. The mathematical soundness argument is documented separately.
"""
from pathlib import Path
import re,json,hashlib
from collections import Counter
def require(condition, message):
    if not condition: raise ValueError(message)

ROOT=Path(__file__).resolve().parent
REFERENCE_TABLE=ROOT.parent/'data/pa238.native.tm'
SLOTS=(6,7,0,2,1,8,4,3,5)
SELECTORS={119:0,100:1,80:2,75:3,60:4,71:5,52:6,126:7,147:8}
C=lambda b:('c',int(b))
R=lambda b,a,c:('r',int(b),a,c)
PLAIN=('plain',)

def load_table(path):
    t={}
    for l in path.read_text().splitlines():
        if l.startswith('#') or not l.strip():continue
        q,b,w,d,n=l.split();t[int(q),int(b)]=(int(w),d,int(n))
    require(set(t)=={(q,b) for q in range(238) for b in (0,1)}, 'wrong reference row domain')
    return t

def normalize(segments,trim=False):
    out=[]
    for z in segments:
        b,a,c=(z[1],0,1) if z[0]=='c' else z[1:]
        if not a and not c:continue
        if out and out[-1][1]==b:
            old=out.pop();out.append(R(b,a+old[2],c+old[3]))
        else:out.append(R(b,a,c))
    if trim:
        while out and not out[-1][1]:out.pop()
    return tuple(out)

def fingerprint(s):
    q,on_left,l,r,phase=s
    return q,on_left,normalize(l,True),normalize(r),phase

def advance(table,branch,s):
    q,on_left,l,r,p=s
    # The complete physical file begins at the unexposed right boundary.
    if not on_left and not r:
        if p==PLAIN and q in SELECTORS:
            i=SELECTORS[q]
            return (2 if i==0 else 8,True,l,[],('marked',i)),True,'mark'
        if p[0]=='marked':
            i=p[1]
            require(0<=i<9, 'marked register outside0..8')
            if q==99:
                return (11,True,l,[],('inc',i)),True,'inc'
            if q==78 and branch is not None and branch[0]==i:
                if branch[1]:return(3 if i==0 else 7,True,l,[],PLAIN),True,'dec0'
                return(15 if i==0 else 11,True,l,[],('dec',i)),True,'dec+'
        w,d,n=table.get((q,0),(None,None,None))
        if w==0 and d=='L':return(n,True,l,[],p),True,'filehead'
        raise ValueError(('unproved file entry',q,p,branch))
    if on_left:
        if not l:return(q,False,[],[C(0)]+r,p),False,'expose'
        z,*rest=l
        if z[0]=='c':return(q,False,rest,[z]+r,p),False,'expose'
        _,b,a,c=z
        w,d,n=table.get((q,b),(None,None,None))
        if d=='L' and n==q:
            return(q,True,rest,[R(w,a,c)]+r,p),bool(c),'scanL'
        if c:return(q,True,[C(b),R(b,a,c-1)]+rest,r,p),False,'expose'
        if not a:return(q,True,rest,r,p),False,'expose'
        raise ValueError(('unresolved variable left run',s))
    if not r:raise ValueError(('unreachable empty right',s))
    z,*rest=r
    if z[0]=='c':
        w,d,n=table[q,z[1]]
        if d=='L':return(n,True,l,[C(w)]+rest,p),True,'step'
        return(n,False,[C(w)]+l,rest,p),True,'step'
    _,b,a,c=z
    w,d,n=table.get((q,b),(None,None,None))
    if d=='R' and n==q:
        return(q,False,[R(w,a,c)]+l,rest,p),bool(c),'scanR'
    if c:return(q,False,l,[C(b),R(b,a,c-1)]+rest,p),False,'expose'
    if not a:return(q,False,l,rest,p),False,'expose'
    raise ValueError(('unresolved variable right run',s))

def inc(bits):
    bits=list(bits)
    for i in range(len(bits)-1,-1,-1):
        if not bits[i]:bits[i]=1;break
        bits[i]=0
    return bits

def strip(bit,k,bits):
    bits=list(bits)
    while k and bits:k-=bits.pop()==bit
    return bits

def start(bits,extra=0,phase=PLAIN):
    require(len(bits)<=38+extra, 'instruction path exceeds header gap')
    return(25,False,[C(1)],[C(b) for b in bits]+[R(0,1,38+extra-len(bits)),C(1)],phase)

def route(bits,edge,zero):
    kind,*args=edge.split()
    if kind=='EHalt':return None,None
    i=int(args[0])
    if kind=='EInc':return None,start(inc(bits),int(all(bits)),('inc',SLOTS[i]))
    if kind=='EDecnz':
        j=SLOTS[i]
        if zero:
            v=strip(0,1,bits)
            return(j,True),start(inc(v),int(all(v)),PLAIN)
        return(j,False),start(inc(bits),int(all(bits)),('dec',j))
    if kind=='EBreak':
        v=strip(0,i,bits)
        return None,start(inc(v),int(all(v)),PLAIN)
    if kind=='EContinue':return None,start(strip(1,i,bits))
    raise ValueError(edge)

def check_one(table,bits,edge,zero):
    branch,target=route(bits,edge,zero)
    targetfp=None if target is None else fingerprint(target)
    s=start(bits);moved=False;counts=Counter();states=set()
    for step in range(768):
        if moved and (s[0]==238 if target is None else s[0]==25 and not s[1] and fingerprint(s)==targetfp):
            return step,counts,states
        states.add(s[0])
        s,progress,action=advance(table,branch,s)
        counts[action]+=1;moved|=progress
    raise ValueError(('symbolic fuel exhausted',bits,edge,zero,s,target))
