#!/usr/bin/env python3
"""Universally check a candidate decoder using the PA238 register lemmas.
Input JSON: {"nodes": {"0": ["ENode 1", "..."], ...}, "root":0}.
Input table uses original numeric labels and halt238; unreachable rows may
be omitted. The physical register macros must be byte-for-byte unchanged
on their conservatively listed transition dependencies.
"""
import argparse,hashlib,json
from pathlib import Path
from collections import Counter
import affine_runtime as s
from affine_runtime import require

FILE_STATES={119,100,80,75,60,71,52,126,147,0,1,2,3,4,5,6,7,8,9,10,11,13,15,
             99,118,137,149,78,98,117}

def read_table(path):
    t={}
    for line in Path(path).read_text().splitlines():
        if line.startswith('#') or not line.strip():continue
        q,b,w,d,n=line.split();key=int(q),int(b)
        require(key not in t, ('duplicate table row', key))
        require(int(b) in (0,1) and int(w) in (0,1) and d in ('L','R') and int(q)>=0 and int(n)>=0, 'invalid transition')
        t[key]=int(w),d,int(n)
    return t

def read_nodes(path):
    j=json.loads(Path(path).read_text());n=j.get('nodes',j)
    if isinstance(n,list):n=dict(enumerate(n))
    n={int(q):tuple(pair) for q,pair in n.items()}
    return n,j.get('root',0)

def leaves(nodes,root):
    ans=[]
    def rec(q,p,anc):
        require(q not in anc, 'DAG is cyclic')
        for b,e in enumerate(nodes[q]):
            if e.startswith('ENode '):rec(int(e.split()[1]),p+[b],anc|{q})
            else:ans.append((p+[b],e))
    rec(root,[],set())
    return ans

def audit(table,nodes,root=0):
    if hashlib.sha256(s.REFERENCE_TABLE.read_bytes()).hexdigest() != 'ffe370842d70bae96688ad5e290073edffe0bb213cf12fe562a75a74bec966de':
        raise ValueError('reference table hash mismatch')
    reference=s.load_table(s.REFERENCE_TABLE)
    for q in FILE_STATES:
        for b in(0,1):
            if (q,b)==(1,1): continue
            require(table[q,b]==reference[q,b], ('changed register macro row',q,b))
    paths=leaves(nodes,root)
    checked=maxsteps=0;counts=Counter();states=set();failures=[]
    for bits,e in paths:
        require(len(bits)<=38, 'instruction path exceeds header gap')
        for zero in ([False] if e=='EHalt' else [False,True]):
            try:steps,used,visited=s.check_one(table,bits,e,zero)
            except Exception as ex:
                failures.append({'path':''.join(map(str,bits)),'edge':e,'zero':zero,'error':repr(ex)})
                return {'status':'FAIL','checked_before_failure':checked,'failures':failures}
            checked+=1;maxsteps=max(maxsteps,steps);counts.update(used);states|=visited
    return {'status':'PASS_ALL_SYMBOLIC_INSTRUCTION_CASES','program_leaves':len(paths),
            'universal_cases':checked,'max_symbolic_steps':maxsteps,
            'max_path_length':max(len(p) for p,e in paths),
            'halt_leaves':sum(e=='EHalt' for p,e in paths),
            'all_reachable_register_macro_rows_unchanged':True,
            'unread_macro_row_exception':[1,1],
            'arbitrary_gap':True,'arbitrary_complete_register_file':True,
            'minimum_register_count':9,'minimum_header_distance':39,
            'rule_counts':dict(counts),'visited_states':sorted(states),
            'kernel_certificate':False,
            'macro_exception_justification':'state1 is reached only in zero-register restoration, reading0; selector reaches0 only reading1; other file routines do not enter1'}

def main():
    base=Path(__file__).resolve().parents[1]
    ap=argparse.ArgumentParser();ap.add_argument('--table',default=str(base/'machine/pa237.native.tm'));ap.add_argument('--program',default=str(base/'program/pa237_program.json'));ap.add_argument('--out',default=str(base/'results/universal_instruction_check.json'))
    a=ap.parse_args();t=read_table(a.table);n,r=read_nodes(a.program);result=audit(t,n,r)
    result['table_sha256']=hashlib.sha256(Path(a.table).read_bytes()).hexdigest()
    result['program_sha256']=hashlib.sha256(Path(a.program).read_bytes()).hexdigest()
    Path(a.out).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='visited_states'},indent=2))
    if result['status'].startswith('FAIL'):raise SystemExit(1)
if __name__=='__main__':main()
