#!/usr/bin/env python3
"""Check the exact source edit and the control graph outside the proved macro.
The equality/conditional-clear macro contract is proved in the manuscript.
This check is structural and unbounded; it does not substitute finite samples
for that contract. It independently rebuilds trees from the frozen Coq DAG.
"""
from pathlib import Path
from functools import cache
import re,json,hashlib

def require(b,m):
    if not b:raise ValueError(m)

def leaf(t):return isinstance(t[0],str)

def parse_edge(e):
    p=e.split();return (p[0],int(p[1])if len(p)>1 else None)

def tree_from_nodes(nodes,root):
    @cache
    def visit(q):
        def cv(e):
            k,r=parse_edge(e)
            return visit(r)if k=='ENode' else(k,r)
        return tuple(map(cv,nodes[q]))
    return visit(root),visit

def replace(t,subs):
    @cache
    def rec(t):
        if t in subs:return subs[t]
        return t if leaf(t)else tuple(rec(v)for v in t)
    return rec(t)

def sites(t):
    out=[]
    def rec(n,p):
        if leaf(n):out.append((p,n));return
        rec(n[0],p+(0,));rec(n[1],p+(1,))
    rec(t,());return out

def unique_nodes(t):
    seen=set()
    def rec(n):
        if leaf(n)or n in seen:return
        seen.add(n);rec(n[0]);rec(n[1])
    rec(t);return len(seen)

def inc(p):
    p=list(p)
    for i in range(len(p)-1,-1,-1):
        if p[i]==0:p[i]=1;break
        p[i]=0
    return tuple(p)

def strip(p,b,k):
    p=list(p)
    while k and p:k-=int(p.pop()==b)
    return tuple(p)

def graph(t):
    ss=sites(t);ids={p:i for i,(p,e)in enumerate(ss)}
    def target(p):
        n=t;i=0;actual=[]
        while not leaf(n):
            b=p[i]if i<len(p) else 0;actual.append(b);n=n[b];i+=1
        return ids[tuple(actual)]
    rows=[]
    for p,(k,r)in ss:
        if k=='EHalt':targets=[]
        elif k=='EMacro' and r=='E':targets=[target(inc(p)),target(inc(strip(p,0,1)))]
        elif k in('EInc','EMacro'):targets=[target(inc(p))]
        elif k=='EDecnz':targets=[target(inc(p)),target(inc(strip(p,0,1)))]
        elif k=='EBreak':targets=[target(inc(strip(p,0,r)))]
        elif k=='EContinue':targets=[target(strip(p,1,r))]
        else:raise ValueError(k)
        rows.append([k,r,*targets])
    return rows

def audit(base):
    require(hashlib.sha256((base/'data/Prog238.v').read_bytes()).hexdigest()=='fc88ecc4ab9962617886c6a508d667d95b6729d6aa0e8f85a21123787aa74334','original Prog238 hash mismatch')
    text=(base/'data/Prog238.v').read_text()
    ns={int(q):(a,b)for q,a,b in re.findall(r'\| ([0-9]+) => \((E\w+(?: [0-9]+)?), (E\w+(?: [0-9]+)?)\)',text)}
    require(set(ns)==set(range(185)),'frozen original DAG domain not0..184')
    old,node=tree_from_nodes(ns,0)
    original_json=json.loads((base/'data/pa238_program.json').read_text())
    on={int(k):tuple(v)for k,v in original_json['nodes'].items()}
    require(tree_from_nodes(on,original_json['root'])[0]==old,'referenceJSON differs from frozenCoqDAG')
    # The modified clear1 node is used only in the closed conditional153.
    incoming=[(n,b)for n,pair in ns.items()for b,e in enumerate(pair)if e=='ENode 152']
    require(incoming==[(153,1)],'clear1 has another logical consumer')
    D=lambda r:('EDecnz',r)
    I=lambda r:('EInc',r)
    C=lambda k:('EContinue',k)
    B=lambda k:('EBreak',k)
    P=(D(5),C(2)); A=(P,I(5)); L=(D(6),A); X=(P,B(1))
    cleanup=(node(48),X); T=(D(5),cleanup); E=(L,T)
    old_H=node(153);new_H=(E,(D(1),C(2)))
    require(old_H==(node(151),(D(1),C(1))),'wrong original conditional')
    expected=replace(old,{node(151):E,node(152):(D(1),C(2))})
    payload=json.loads((base/'program/pa237_program.json').read_text())
    n={int(k):tuple(v)for k,v in payload['nodes'].items()};actual,_=tree_from_nodes(n,payload['root'])
    require(actual==expected,'final source is not the proved exact replacement')
    old_contract=replace(old,{old_H:('EMacro','H'),node(151):('EMacro','E')})
    new_contract=replace(actual,{new_H:('EMacro','H'),E:('EMacro','E')})
    require(old_contract==new_contract,'source outside conditional contract changed')
    old_graph,new_graph=graph(old_contract),graph(new_contract)
    require(old_graph==new_graph,'contracted control graphs differ')
    actual_sites=sites(actual)
    frozen_sites=json.loads((base/'program/sites.json').read_text())
    emap={'EInc':'CI','EDecnz':'CD','EBreak':'CB','EContinue':'CC','EHalt':'CH'}
    exported=[{'path':''.join(map(str,p)),'edge':k+('' if r is None else ' '+str(r))}for p,(k,r)in actual_sites]
    require(exported==frozen_sites,'leaf inventory is not exact new source traversal')
    raw=(json.dumps(old_graph,separators=(',',':'))+'\n').encode()
    return {'status':'PASS_EXACT_SOURCE_REPLACEMENT_AND_CONTRACTED_CFG_IDENTITY',
            'original_DAG_nodes':len(ns),'new_DAG_nodes':len(n),
            'original_structural_nodes':unique_nodes(old),'new_structural_nodes':unique_nodes(actual),
            'original_leaf_occurrences':len(sites(old)),'new_leaf_occurrences':len(actual_sites),
            'contracted_control_graph_sites':len(old_graph),
            'conditional_macro_occurrences':sum(r[:2]==['EMacro','H']for r in old_graph),
            'standalone_equality_macro_occurrences':sum(r[:2]==['EMacro','E']for r in old_graph),
            'contracted_CFG_sha256':hashlib.sha256(raw).hexdigest(),
            'original_Prog238_sha256':hashlib.sha256((base/'data/Prog238.v').read_bytes()).hexdigest(),
            'new_program_sha256':hashlib.sha256((base/'program/pa237_program.json').read_bytes()).hexdigest(),
            'semantic_obligation':'The manuscript proves old_E/new_E and old_H/new_H have identical total register-transformer contracts; this script checks their placement and all remaining source control exactly.',
            'kernel_certificate':False},raw

def main():
    base=Path(__file__).resolve().parents[1];r,g=audit(base)
    (base/'results/source_check.json').write_text(json.dumps(r,indent=2)+'\n')
    (base/'results/contracted_control_graph.json').write_bytes(g);print(json.dumps(r,indent=2))
if __name__=='__main__':main()
