#!/usr/bin/env python3
"""Replay every blank-tape transition and compare the entire finite support.
This verifier does not consume a saved trace and has no nonstandard dependency.
"""
from pathlib import Path
import argparse, hashlib, json
from audit_runtime import read_table

STEPS = 817846
ACTIVE = [0, 2, 0, 0, 0, 0, 6, 0, 0]
SPARES = [0] * 5 + [1] + [0] * 318
NATIVE_SHA256 = '7d596afcde7a4150c3cbf71fa89111aa8271116745d22e194250f2b10dc586c8'

def require(condition, message):
    if not condition: raise ValueError(message)

def expected_support():
    result = {-21, 18}
    cursor = 19
    for value in ACTIVE + SPARES:
        result.update(range(cursor + 1, cursor + value + 2))
        cursor += value + 2
    return result

def audit(table):
    table = Path(table)
    require(hashlib.sha256(table.read_bytes()).hexdigest() == NATIVE_SHA256, 'native table hash mismatch')
    rows = read_table(table)
    require(set(rows) == {(q,b) for q in range(238) if q != 151 for b in (0,1)}, 'wrong native state domain')
    q = head = low = high = 0
    ones = set()
    for clock in range(STEPS):
        require((q, int(head in ones)) in rows, f'early halt at {clock}')
        write, direction, q = rows[q, int(head in ones)]
        if write: ones.add(head)
        else: ones.discard(head)
        head += -1 if direction == 'L' else 1
        low, high = min(low, head), max(high, head)
    require((q, head) == (25, -20), 'wrong endpoint state/head')
    require(ones == expected_support(), 'whole tape differs from the original PA238 seed')
    tape_bytes = (json.dumps(sorted(ones), separators=(',', ':')) + '\n').encode('ascii')
    return {'status':'PASS_COMPLETE_RAW_TABLE_BOOTSTRAP', 'working_states':237,
            'start_state':0, 'halt_state_native':238, 'transitions':STEPS,
            'state_native':q, 'head':head, 'marker':-21, 'header':18,
            'header_distance':39, 'active_physical_registers':ACTIVE,
            'total_registers':len(ACTIVE + SPARES), 'spare_registers':len(SPARES),
            'nonzero_spares':[[i,v] for i,v in enumerate(SPARES) if v],
            'one_cells':len(ones), 'visited_head_range':[low,high],
            'one_cells_range':[min(ones),max(ones)],
            'whole_tape_equals_original_PA238_checkpoint':True,
            'table_sha256':NATIVE_SHA256,
            'one_cells_sha256':hashlib.sha256(tape_bytes).hexdigest(),
            'one_cells_sha256_encoding':'ASCII compact JSON sorted coordinates followed by LF',
            'kernel_certificate':False}, tape_bytes

def main():
    base = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser()
    p.add_argument('--table',type=Path,default=base/'machine/pa237.native.tm')
    p.add_argument('--out',type=Path,default=base/'results/blank_bootstrap_check.json')
    a = p.parse_args(); result, tape = audit(a.table)
    a.out.write_text(json.dumps(result,indent=2)+'\n')
    a.out.with_name('blank_checkpoint_ones.json').write_bytes(tape)
    print(json.dumps(result,indent=2))
if __name__ == '__main__': main()
