#!/usr/bin/env python3
"""Bounded regression of the equality and conditional-clearing contracts.

This is optional finite supporting evidence, not a universal verification.
The all-natural-number proof is in the accompanying mathematical report.
"""
from __future__ import annotations
import argparse
from functools import cache
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]

def read_program(path):
    raw = path.read_bytes()
    obj = json.loads(raw)
    return {int(q): tuple(es) for q, es in obj['nodes'].items()}, hashlib.sha256(raw).hexdigest()

def expansion(nodes):
    @cache
    def expand(q):
        return tuple(expand(int(e.split()[1])) if e.startswith('ENode ') else e
                     for e in nodes[q])
    return expand

def execute(nodes, edge, registers, count):
    count[0] += 1
    kind, *args = edge.split()
    if kind == 'EInc':
        registers[int(args[0])] += 1
        return 'Normal', 0
    if kind == 'EDecnz':
        i = int(args[0])
        if registers[i] == 0:
            return 'Break', 1
        registers[i] -= 1
        return 'Normal', 0
    if kind == 'EBreak':
        return 'Break', int(args[0])
    if kind == 'EContinue':
        return 'Continue', int(args[0])
    if kind == 'EHalt':
        return 'Halt', 0
    if kind != 'ENode':
        raise ValueError(edge)
    count[0] -= 1
    left, right = nodes[int(args[0])]
    while True:
        outcome, depth = execute(nodes, left, registers, count)
        if outcome == 'Break':
            return ('Normal', 0) if depth == 1 else ('Break', depth - 1)
        if outcome != 'Normal':
            return outcome, depth
        outcome, depth = execute(nodes, right, registers, count)
        if outcome == 'Continue':
            if depth == 1:
                continue
            return 'Continue', depth - 1
        return outcome, depth

def require(condition, context):
    if not condition:
        raise ValueError(context)

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--bound', type=int, default=16)
    ap.add_argument('--top-bound', type=int, default=8)
    ap.add_argument('--out', type=Path, default=BASE/'results/helper_regression.json')
    args = ap.parse_args()
    require(args.bound >= 0 and args.top_bound >= 0, 'bounds must be nonnegative')
    old, old_hash = read_program(BASE/'data/pa238_program.json')
    new, new_hash = read_program(BASE/'program/pa237_program.json')
    old_expand, new_expand = expansion(old), expansion(new)
    P = ('EDecnz 5', 'EContinue 2')
    F = old_expand(48)
    A = (P, 'EInc 5')
    L = ('EDecnz 6', A)
    X = (P, 'EBreak 1')
    B = (F, X)
    T = ('EDecnz 5', B)
    E = (L, T)
    H = (E, ('EDecnz 1', 'EContinue 2'))
    new_eq = [q for q in new if new_expand(q) == E]
    new_cond = [q for q in new if new_expand(q) == H]
    require(len(new_eq) == len(new_cond) == 1, 'expected helper structures absent')
    equality_cases = conditional_cases = 0
    for x in range(args.bound + 1):
        for y in range(args.bound + 1):
            initial = [i + 7 for i in range(12)]
            initial[6], initial[5] = x, y
            wanted = initial.copy()
            wanted[5] = wanted[6] = 0
            expected = ('Normal', 0) if x == y else ('Break', 1)
            old_count = 3*x + 2 + 2*abs(x-y)
            new_count = 3*y + 2 if x <= y else 6*x - 3*y + 1
            for name, nodes, root, steps in (
                ('old', old, 151, old_count), ('new', new, new_eq[0], new_count)
            ):
                registers, count = initial.copy(), [0]
                got = execute(nodes, f'ENode {root}', registers, count)
                require((got, registers, count[0]) == (expected, wanted, steps),
                        ('equality', name, x, y, got, registers, count[0]))
            equality_cases += 1
            for t in range(args.top_bound + 1):
                initial[1] = t
                wanted[1] = 0 if x == y else t
                for name, nodes, root in (
                    ('old', old, 153), ('new', new, new_cond[0])
                ):
                    registers, count = initial.copy(), [0]
                    got = execute(nodes, f'ENode {root}', registers, count)
                    require((got, registers) == (('Normal', 0), wanted),
                            ('conditional', name, x, y, t, got, registers))
                    if name == 'new':
                        steps = 3*x+4*t+3 if x == y else new_count
                        require(count[0] == steps,
                                ('conditional count', x, y, t, count[0], steps))
                conditional_cases += 1
    result = {
        'status': 'PASS_BOUNDED_HELPER_REGRESSION',
        'scope': 'Bounded supporting evidence only; universal correctness uses the report induction proofs.',
        'counter_range': [0, args.bound], 'topwff_range': [0, args.top_bound],
        'equality_input_pairs': equality_cases,
        'conditional_input_triples': conditional_cases,
        'register_file_length': 12,
        'all_other_registers_preserved_on_checked_inputs': True,
        'exact_instruction_counts_checked': True,
        'old_program_sha256': old_hash, 'new_program_sha256': new_hash,
        'new_equality_node': new_eq[0], 'new_conditional_node': new_cond[0],
        'kernel_certificate': False,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
