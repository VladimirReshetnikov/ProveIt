#!/usr/bin/env python3
"""Run the independent structural, symbolic and exact finite checks.
Run from any working directory. Python3.10+ standard library only.
No network access, no external prover, and no precomputed trace is required.
"""
from pathlib import Path
import argparse,subprocess,sys

def main():
    p=argparse.ArgumentParser();p.add_argument('--helpers',action='store_true',help='also run optional bounded helper regression (not its proof)')
    a=p.parse_args();here=Path(__file__).resolve().parent
    jobs=['audit_relabeling.py','audit_source.py','audit_runtime.py','audit_bootstrap.py']
    if a.helpers:jobs.append('audit_helpers.py')
    for job in jobs:
        print('\nRunning '+job,flush=True)
        subprocess.run([sys.executable,str(here/job)],check=True)
    print('\nALL REQUIRED CHECKS PASSED.',flush=True)
    print('Proof status: conventional mathematical proof plus executable checks; no new kernel certificate.',flush=True)
if __name__=='__main__':main()
