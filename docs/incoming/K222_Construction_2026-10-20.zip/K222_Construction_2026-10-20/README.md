# K222: a 222-state binary Turing machine for Con(ZFC)

This packet constructs a deterministic, one-tape, two-symbol Turing machine
with **222 working states**, initialized on the entirely blank tape. It is one
state smaller than the three 223-state candidates considered in this research.

The ordinary mathematical proof, formalizable in ZFC, establishes

\[
\mathrm{ZFC}\vdash\operatorname{Nonhalt}(M_{222},\mathrm{blank})
\longleftrightarrow\operatorname{Con}(\mathrm{ZFC}).
\]

This is an equivalence, not an unconditional proof of nonhalting or Con(ZFC).
**No new compiled Rocq or Lean endpoint for these exact bytes is claimed.**
The inherited K230 formal development, logical adapters, source correctness,
and executable unbounded induction certificates are identified separately.
No minimality or global priority claim is made.

## Read and reproduce

- `report/report.pdf`: mathematical report, including the complete table.
- `report/report.tex`: editable LaTeX; `report/build.sh` builds the PDF.
- `machine/k222.tm`: preferred, canonical machine.
- `machine/k222.native.tm`: same machine in inherited K labels.
- `machine/sites222.json`: exact primitive source.
- `machine/canonicalization.json`: explicit label bijection and blank-start receipt.
- `portable/reproduce.py`: offline, standard-library Python 3.10+ reproduction.
- `verification/`: fresh replay receipts and independent checks.
- `PROVENANCE.json` and `NOTICE.md`: identities, credits and proof boundary.

From the packet root, with assertions enabled and an initially empty output
path **outside** `portable/`:

```sh
python3 -B portable/reproduce.py --output-dir /tmp/k222-replay
```

On Windows, replace the output path with an unused directory such as
`C:\tmp\k222-replay`. No network access or proof-assistant installation is
needed for this replay. Default mode reconstructs and checks the machine and
freshly derives all **6,167 unbounded final-runtime cases**. `--quick` audits
stored runtime derivations instead of rederiving them. `--full-baseline`
also freshly replays all inherited K224/K225/K226 runtimes. Those are distinct
modes; a quick audit is not a fresh universal derivation.

## Exact convention

There is one two-way infinite tape indexed by integers, alphabet {0,1},
blank symbol 0, head initially at 0, and only unit L/R moves. The initial
state is 0. Working states are 0 through 221. State 222 is the separate
terminal outcome and has no outgoing rows. Initialization is counted.
There are 444 transition rows, one for every working-state/symbol pair.
A row is `state read write direction next_state`; the start directive is
`#! start 0`. The canonical source dispatcher is state 22.

Canonical table SHA-256:

```text
f5b4adcd5e0735a4a26dcc2316e69683df73bee0dbaf9e1082cd1e9318e8082a
```

## The composition

The two incoming constructions save space differently. The merged equality
row G supplies the canonical equality-vacuity helper internally; the
witness-request presentation of K repeats a request already used in closure.
Combining them removes the separate helper from the K bundle while retaining
G as an ungated logical schema. A closed reassociation removes a seven-zero
source address without increasing the number of distinct source subtrees.
A compatible helper allocation retains all twelve contextual decoder aliases.

The final source has 4,744 primitive occurrences and 208 distinct subtrees,
including 23 primitive leaves. Its 185 internal subtrees use 173 decoder
states; 49 other states give **173 + 49 = 222**. Maximum address depth is 36,
and maximum consecutive-zero run is six. Against the pinned K224 table,
the literal construction deletes native states 219 and 226 and changes 49
retained rows. Native labels are identifiers, not a consecutive state count.

## Verification boundary

- Deterministic reconstruction, exact source/table hashes, and all 4,743
  compound decoder-prefix checks.
- Independent symbolic binding of both changed emitters to the intended
  formulas; all-register macro bisimulations; all 6,167 source CFG cases.
- Six semantic/control-flow negative controls, not just hash mismatches.
- Independent uniform Hilbert certificate: 109 proof nodes, 104 formulas,
  nine schematic roots, valid for every natural-label substitution including
  zero and collisions. The retained classical bridge is an explicit dependency.
- Fresh runtime: 6,167 cases, 1,488,390 symbolic rule applications, all 444
  transition rows used; positive instruction duration, minimum 13 steps.
- Exact blank initialization: 409,835 steps, complete tape support checked,
  not merely a bounded window or register summary.
- Exact-source invariant check: 32,107 closure checks, 4,741 reachable source
  leaves of 4,744, with independently resolved control flow.
- Canonical/native table bijection and independent full blank simulations.

The runtime proof quantifies over all nine natural registers, every decrement
guard, arbitrary natural extra gap, and arbitrary nonempty finite spare list.
Its case count is not a finite testing bound on register values or running time.
Runtime alone does not establish the logical calibration; the report and
included theory proofs supply that separate connection.

## Release replay

A clean extracted executable packet completed the full 6,167-case replay.
The final archive also passed its quick-mode replay after its stored runtime
receipt was refreshed from the genuine portable-driver run. All executable,
source, table, case-certificate and logical-proof bytes remained unchanged;
`verification/release_verification.json` records the exact receipt-only delta.
The two incoming 223-state packets also passed independent full replays.
