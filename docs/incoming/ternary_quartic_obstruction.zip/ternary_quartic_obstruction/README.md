# Sharp ternary quartic phase energy

**Exact extremizers, a certified Gram identity, and a dimension-free integration threshold**  
Research manuscript prepared for the ProveIt project, 7 October 2026.

## Results

The article proves the sharp maximum **11/27** for the canonical nonintegrable
symmetric quartic tensor on F_3^2, resolving Conjecture 11.4 in the
project-associated manuscript `finite_cover_phase_repair.tex`. Its prior
certified interval was `[11/27, 1099/2187]`.

The package also supplies a complete classification of all extremizers,
including their continuous phase freedom and explicit cubic gauge group;
an exact feature-space stability inequality; and the sharp dimension-free
conclusion that energy greater than 11/27 forces nonclassical integration
of an **already symmetric, four-linear** tensor over F_3.

The proof is computer-assisted. All finite certificate checks have passed.
It has not been checked by Lean or independently refereed. It does not claim
a complete new Gowers inverse theorem or an improved integer progression bound.
The matrix data are an essential electronic appendix to the article.

## Read and verify

- `ternary_quartic_obstruction.pdf`: the 20-page article.
- `ternary_quartic_obstruction.tex`: complete LaTeX source, including bibliography.
- `verify_exact.py`: the exact, solver-free verifier.
- `data/ternary_quartic_gram.json`: integer matrix witness.
- `checks.json` and `verification.log`: results of a completed verification run.
- `CERTIFICATE.md`: data conventions and proof of the positivity implication.
- `FORMALIZATION_PLAN.md`: proposed kernel-checked development, not a formal proof.
- `PROVENANCE.md`: inspected sources, repository snapshots, and attribution.
- `test_corruption.py`: negative tests showing rejection of modified certificates.
- `MANIFEST.sha256`: checksums of the final package files, excluding the manifest itself.

Run from this directory:

```sh
python3 verify_exact.py --report checks.json
python3 test_corruption.py
```

The verifier uses Python 3.10 or later and its standard library only. It uses no
floating-point arithmetic, numerical optimization, random samples, NumPy, SciPy,
SymPy, or externally supplied cube coefficient table. It also runs under
`python3 -O`; explicit exception-based checks are not disabled by that option.

The main checks reconstruct all 59,049 cubes, verify the exact affine-line
identity and the Gram polynomial identity, establish Hermitian symmetry and the
kernel, and certify positive definiteness with a rational diagonal-dominance
margin greater than 1/5. Equality families and the finite phase quotient are
checked separately. The original phase domain remains continuous throughout.

Build the PDF with:

```sh
make pdf
```

This invokes `pdflatex` twice. The source uses standard LaTeX packages including
`amsmath`, `amsthm`, `mathtools`, `mathrsfs`, `lmodern`, `microtype`, `booktabs`,
`fancyhdr`, `hyperref`, and `cleveref`. No shell escape, external figures, font
files, or bibliography processor is needed.

## Suggested integration

Suggested destination:

```text
Combinatorics/Ramsey/Research/GowersSzemeredi/sharp-ternary-quartic-obstruction/
```

Link this as a resolution of the predecessor's Conjecture 11.4 and a sharp
replacement for its ternary interval. Preserve the predecessor's attribution
for finite-cover realization and the structural reduction. Its general
integration criterion is an established result of Tidor, not a new theorem
of this package.

This package makes no repository write, does not alter a proof-status ledger,
and provides no purported compiled Lean theorem. No new repository license has
been assigned by this package. Authorship and repository integration decisions
remain with the project maintainer.
