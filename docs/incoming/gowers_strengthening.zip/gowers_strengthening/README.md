# Sharp Finite Phase Partitions and Density-Sensitive Increments

Research note prepared for Vladimir Reshetnikov, 6 October 2026.

## Contents

- `article.pdf`: the 18-page article, with full mathematical proofs, comparisons
  against the corrected ProveIt statements and proof-level bounds, a Lean
  integration roadmap, and eight research directions.
- `article.tex`: self-contained LaTeX source; the bibliography is included.
- `code/phase_partitions.py`: exact rational/integer implementations of the
  one-phase, sharp capped, and simultaneous partitions, independent structural
  checking, and optimal continuous allocation of phase tolerances.
- `code/verify.py`: reproducible exact structural tests and high-precision
  numerical Fourier diagnostics.
- `verification_exact.json` and `verification_fourier.json`: outputs of the
  completed test runs, with their different validation levels recorded.
- `SOURCE_AUDIT.md`: repository source identities, inspected ranges, baseline
  comparisons, and research/verification qualifications.

## Principal results

Theorem 2.4 improves the corrected Gowers Lemma 2.3 lower length constant from
1/4 to 1/3 while retaining the upper constant 1. The constant 1/3 is optimal
for that exact formulation, as a nine-point parity obstruction shows.
Corollary 2.6 improves the corrected Corollary 2.4 with the same upper cell
length: the lower denominator 128*pi becomes 36*pi and retained absolute
block correlation increases from alpha/2 to 3*alpha/4.

Theorem 3.4 produces a density increment of delta*alpha/(4*delta-alpha), on
a progression of length at least sqrt(alpha*N/(16*pi*delta*(1-delta))).
An exact floor formula and a popularity bound are stronger parts of the result.
The comparison accounts for the fact that the existing repository proof is
stronger than its exported Corollary 2.5 statement.

Theorems 4.2 and 4.5 give simultaneous phase partitions and the sharp order
1 + (epsilon^m*N)^(1/(m+1)), including an explicit algebraic obstruction.
Theorem 5.2 proves a density-sensitive residual-variance inequality for
spectral energy. Corollary 5.4 gives the necessary Gram-matrix correction
for nonorthogonal phase families. The continuous tolerance-allocation
problem is solved separately from the discrete ceiling optimization problem.

## Build the article

Use a TeX installation with pdfLaTeX, Latin Modern, AMS packages, microtype,
geometry, hyperref, bookmark, fancyhdr, enumitem, and the standard table packages.
From this directory:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times, to stabilize the table of contents and cross-references.
No BibTeX step, network access, external image, or external font file is needed.

## Reproduce the checks

The construction module uses only the Python standard library. The test
runner additionally requires `mpmath`; use Python 3.10 or later.
From this directory:

```sh
python -m pip install mpmath
cd code
python verify.py --part exact --output ../verification_exact.json
python verify.py --part fourier --output ../verification_fourier.json
```

The recorded runs used Python 3.13.5 and mpmath 1.3.0. Fourier calculations use
80 decimal digits. Tests must be run without Python's `-O` flag because the
independent checks use assertions.

Completed exact cases: 13,325 flexible one-phase; 11,440 sharp capped;
320 simultaneous; and 200 tolerance-allocation cases. Completed numerical
cases: 60 Fourier correlation/popularity and 96 spectral-energy examples,
including six genuinely multifrequency examples with a guaranteed minimum
cell length greater than one. The new nonorthogonal Gram corollary is proved
in the article; the supplied spectral diagnostics test the cyclic-character
specialization, not every generalization in the article.

## Minimal exact example

Run from `code/`, or place that directory on the Python import path:

```python
from fractions import Fraction
from phase_partitions import single_partition, check_partition

n = 1000
slope = Fraction(17, 101)
width = Fraction(1, 10)
minimum_length, cells = single_partition(n, slope, width)
check_partition(n, minimum_length, cells, [slope], [width])
print(minimum_length, len(cells), cells[0])
```

The algorithms deliberately emphasize transparent exact decisions. The
single-phase search may examine O(N/L) candidate differences. The simultaneous
construction stores up to the product of its box counts. It is not a claim
of a fast algorithm for extremely large N, nor an exact representation of
arbitrary real slopes.

## Status and scope

The main results have ordinary mathematical proofs in the article. Exact
finite tests and high-precision numerical diagnostics are not replacements
for those proofs. No new Lean theorem was compiled or kernel-checked here,
and this package contains no purported completed Lean implementation.

No new best global Szemeredi bound, historically established priority, or
resolution of a previously catalogued major open problem is claimed. The
sharp finite constant and the explicitly formulated simultaneous minimax
problem are the local optimality results established here. The repository
files, source paper, and font files are not redistributed.
