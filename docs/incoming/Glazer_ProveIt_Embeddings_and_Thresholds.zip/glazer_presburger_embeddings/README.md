# Elementary Embeddings and Polish Submodels of Lexicographic Presburger Arithmetic

## The article

This research manuscript studies the family

    H_alpha = Q^alpha with lexicographic order and discrete-factor product topology
    M_alpha = (H_alpha lex Z)_{>=0}

for countable ordinals alpha. It builds on ProveIt's existing affirmative
construction for Elliot Glazer's Presburger question and its explicit follow-up
questions about endomorphisms and elementary-submodel lattices.

The central conclusions are:

- Every unital additive homomorphism is an elementary embedding.
- Borel embeddings are exactly continuous embeddings, characterized by row-finite
  rational matrices with strictly increasing positive pivots. Their images are closed.
- An elementary submodel has inherited Polish topology exactly when its coefficient
  subspace is closed. Canonical pivot subsets describe normal forms, ambient
  automorphism orbits, quotient topologies, and abstract arithmetic types.
- Every elementary self-embedding is continuous if and only if alpha <= omega.
- Every elementary self-embedding has closed image if and only if alpha < omega*2.
  At omega*2 and above there are dense proper non-Borel elementary self-copies.
- The intersection of all self-copy images is the final finite rational tail,
  together with the standard integer coordinate.

The article also gives an annihilator description of the complete lattice of
Polish elementary submodels, exact automorphism cardinalities, an additive
omnific-integer realization, a formalization plan, and twelve further research
questions.

## Files

- `glazer_presburger_embeddings.pdf`: the complete typeset article.
- `glazer_presburger_embeddings.tex`: self-contained LaTeX source with bibliography.
- `build.sh`: three-pass PDF build plus exact finite-example verification.
- `verify_examples.py`: standard-library-only rational verification script.
- `verification_results.json`: the recorded successful run, with 11,243 checks.
- `SOURCE_AUDIT.md`: exact repository snapshot, source overlap, and priority limits.
- `PROOF_REVIEW.md`: mathematical review scope and the corrections incorporated.
- `BUILD_REPORT.json`: final PDF/build/packaging checks.

## Reproduce

Use Python 3.10 or later and a LaTeX installation providing the packages in the
source preamble. The document uses Palatino (`mathpazo`), standard AMS packages,
`microtype`, `geometry`, `booktabs`, `longtable`, `enumitem`, `xcolor`,
`fancyhdr`, `hyperref`, `xurl`, and `cleveref`. It needs no external bibliography
database, figures, network access, or proprietary fonts.

```sh
sh build.sh
```

To run only the finite exact checks:

```sh
python3 verify_examples.py
```

The script overwrites `verification_results.json` deterministically. Its rational
arithmetic is exact; its random examples have a fixed seed.

## Mathematical and verification status

The complete proofs are in the article. The computational checks cover finite
matrix identities, example normal forms, signs, and standard division. They do
not verify infinite products, ordinal recursion, Baire category, elementarity,
or existence of the non-Borel functional.

This is an AI-assisted research manuscript with internal independent proof
reviews, not a refereed publication or a new Lean/Rocq formalization. The precise
classification and thresholds are the contribution developed here. Existing
Presburger constructions, Hahn-group methods, and linear compactness are
credited explicitly. No independently certified claim of historical priority
or a major breakthrough is made.

All mathematical objects in the proofs are sets in ZFC. The surreal connection
uses set-sized fixed-support images and transported coefficient topologies.
No repository modifications or publication actions are included in this package.
