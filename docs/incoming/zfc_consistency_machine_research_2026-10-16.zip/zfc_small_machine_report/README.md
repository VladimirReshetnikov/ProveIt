# Small Turing Machines for the Consistency of ZFC

Research report prepared for Vladimir Reshetnikov and ProveIt, 16 October 2026.
Read **report.pdf** for the complete mathematical report. `report.tex` and
`sections/` contain its full LaTeX source.

## Outcome

The smallest public construction located in the audit has **253 working
states**, in the existing upstream PR 20. It is prior work. No machine with
fewer than 253 states was established by this contribution.

The archive supplies a **new 253-state four-row variant** with an ordinary
ZFC proof of the same halting behavior as that pinned baseline. Its entire
blank-tape bootstrap reaches the identical interface configuration in
**312,935 steps instead of 312,975**. The evidence includes an exact complete
tape comparison, all **8,391** universal symbolic instruction cases, and a
**2,981-pair** register-program bisimulation replayed by two checkers. The
four unchanged upstream tape-operation proofs are included. No new Coq
proof object was generated or checked for the changed machine.

Additional results:

- A six-element counterinterpretation shows that K and S plus all the other
  genuine-bottom Tarski logical rows do not recover Peirce's law. An exhaustive
  checker verifies 420 finite conditions. This is a logical countermodel,
  not a model of CP/GIC/PSC or the numerical relative-bottom alias.
- Exact finite propositional certificates: 107 rows from the attributed
  public Łukasiewicz proof, a 77-row K/S/Peirce-to-Łukasiewicz proof, and a
  325-row K/B/Peirce-to-S proof.
- Complete three-parameter basis experiments considered 128,000 proposals
  and performed 111,141 actual candidate compilations. K/S/Peirce reaches
  268 states, matching the existing source19 full-logic compiler control;
  K/B/Peirce reaches 269. These changed compiler tables do not have a new
  end-to-end consistency theorem.
- A source-specific ordinary ZFC internalization argument and a concrete
  proposal for joint decoder/bootstrap optimization, followed by a complete
  equality-free PSC frontend. The raw-PSC calibration is explicitly
  attributed to the accepted prior ProveIt material.

## Quick verification

Use Python 3.10 or later, standard library only, with assertions enabled:

```sh
python3 -B code/reproduce.py
```

To also regenerate the three selected compiler tables into temporary scratch:

```sh
python3 -B code/reproduce.py --recompile
```

The combined result is written to `data/verification_summary.json`, with
per-check logs in `data/replay_logs/`. The broad optimization searches are
not necessary to verify the selected results. Their precise commands and
budgets are in the experiment READMEs.

Build the PDF with a standard LaTeX installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

Alternatively run `pdflatex` repeatedly until references stabilize. The PDF
does not need external images, network access, or BibTeX.

## Directory map

| Path | Contents |
|---|---|
| `report.tex`, `sections/`, `report.pdf` | Complete report and source |
| `machines/` | Literal upstream254, upstream253, and new faster253 tables |
| `code/`, `data/` | Independent table and inverse-basis checks, combined driver, results |
| `experiments/logic_certificates/` | Finite logical proofs, countermodel, uncompiled Lean adapters |
| `experiments/machine_search/` | Four-row variant, ordinary proof, universal site and RM certificates, search records |
| `experiments/basis_compiler/` | Frozen 268/268/269 tables, exact recipes, compiler sources, certificates, internalization audit |
| `references/` | Source pins and retained notices |
| `STATUS.json`, `MANIFEST.sha256` | Explicit result status and final file-integrity manifest |

The two `.lean` files are conspicuously marked **uncompiled**. They are
proposed adapters against the pinned ProveIt interfaces. Successful Python
replay is not described as a Lean kernel check. The existing upstream Coq
CI success was observed remotely, not rebuilt here.

## Literal machine convention

One two-way infinite tape, alphabet `{0,1}`, all-zero initial tape, state 0
and head position 0 at start, L/R moves only. An n-state table has working
states `0,...,n-1` and a distinct uncounted terminal state `n`. Every working
state has two explicit transition rows. Initialization is included.

For `machines/faster_253.tm`, SHA-256 is:

```text
d5b7a357dbf4dd9d18c8e1aa04dc0c3c0e1b8f349853b7558d1a096a15684412
```

The source pins are in `references/SOURCE_PINS.json`. The audit uses ProveIt
`4747142d5d15213eb711bdadfa3cc7e769fcb7a7`, merged upstream
`c132d7eae8158cd3a9850ea3eb7251158c3dd821`, and the existing 253 branch
`0d544f2a2e3c18f12278441a74b7879f31cbe856`.

## Attribution and incorporation

The existing 254-state machine is by Mira-Cult, the existing 253-state
reduction is by mira-emmy, and the upstream proof development is maintained
by Jeffrey Ketchersid and contributors. Andrew James Wade's compiler
framework and the prior ProveIt research generators/checkers retain their
source attribution and license notices. The public 107-row derivation is
explicitly attributed to `CD254.v`; only its portable rendering and replay
are contributed here. Detailed per-file attribution is in the experiment
READMEs and manifests.

This archive was prepared for incorporation into ProveIt. It does not
represent a published repository change or a merged pull request. The new
253-state table should be recorded as a same-size variant; the 268/269
tables as compiler controls; and the raw PSC theorem as prior mathematical
calibration. New drivers and analysis follow the project's MIT No Attribution
license, included as `LICENSE.ProveIt`, without overriding inherited notices.
