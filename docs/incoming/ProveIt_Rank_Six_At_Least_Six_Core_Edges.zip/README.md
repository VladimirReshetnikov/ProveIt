# Rank Six Cores with at Least Six Edges

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October 2026.

Read **article.pdf** for the theorem and proof. The editable source is **article.tex**.

## Scope

The graph has matching rank six and a displayed three-plus-three minimum cover. Its core has at least six edges. Exterior neighborhoods are arbitrary, left activities are one, and right activities are positive real numbers. For each fixed graph and set of activities, sufficiently large common scaling of the three right-core activities makes every actual-rank Newton gap strict. The manuscript gives a computable field-dependent threshold.

The new proof handles the triangular core and both orientations of the star-plus-disjoint-edge missing graph. An exhaustive complement classification combines these with the previously proved families. Transposition is not treated as an equivalence under fixed unit-left weights.

This does not prove rank-six ULC for arbitrary finite activities. No uniform threshold, global-priority claim or formal proof-assistant verification is asserted.

## Reproduce the exact checks

Python 3 with the standard library suffices for:

```sh
python3 code/replay_all.py
python3 code/check_triangular.py
python3 code/check_star_edge.py
python3 code/check_star_edge_transpose.py
python3 code/check_core_orbits.py
```

The independently written reconstruction uses SymPy:

```sh
python3 code/independent_reconstruction.py
```

All scripts raise an explicit exception on failure. They write JSON summaries beside their sources; reference results are in **data/**.

The primary replay rebuilds all 75 lower-gap targets and their generators from hardcoded polynomial formulas. It checks 5,617 positive rational terms, nonnegative integer exponents, strict remainder one, and complete profile coverage. It neither imports discovery code nor evaluates stored expression strings. The independent reconstruction uses a different variable order and direct slot-assignment support definitions. Neither replay uses a numerical optimizer.

Each graph regression script directly enumerates endpoint supports on 100 deterministic examples and checks the quantified higher-gap bound. All generator families are checked on the 66 coloop-free examples in each group. The orbit census independently covers all 84 six-edge masks while keeping the two shores distinct. These finite graph checks support the formulas; the unlimited-population and positive-real-activity conclusions follow from the proof and exact certificate identities.

## Files and build

- **data/find_triangular_first.json**: 25 identities, 2,369 terms, 34 generators
- **data/find_star_edge_first.json**: 25 identities, 989 terms, 46 generators
- **data/find_transpose_first.json**: 25 identities, 2,259 terms, 32 generators
- **code/**: portable exact replays, support regressions and orbit census
- **data/**: reference verification outputs

Compile the LaTeX source with two pdflatex passes and the packages named in its preamble. **build_local.sh** supplies the preparation environment's TeX paths and writes temporary files to **build/**.

Run `sha256sum -c SHA256SUMS` to verify all shipped files. Exploratory optimizer scripts, raw audit correspondence and superseded partial certificates are excluded.
