# Report235: Globally optimal parity-conditioned binomial approximation

This is the self-contained source and computational package for the marked
inactive-vertex law associated with OEIS A360592 at its critical parameter.
Read `Report235.pdf` for the definitions, statements, proofs and bibliography.
The source discussion is in `SOURCES.md`. Executable computations supplement the
proofs; they do not establish asymptotic remainder estimates or global optimality
by themselves.

For

    a(n) = sum_{k=0}^{floor(n/2)} (n-k)^k binomial(n-k,k),

choose k proportionally to the summand and put R_n = n-2k. Every reference law
in the approximation statements is conditioned to n's parity. The principal
result concerns the infimum over every defined parity-conditioned binomial,
including arbitrary trial counts, endpoint success probabilities and rare
conditioning events. It is an asymptotic theorem, not a claim that the explicit
parameters are an exact finite-n minimizer. No optimization over all positive
families or a global result for higher residue moduli is claimed.

## Contents

- `article.tex`, `sections/`, `Report235.pdf`: article sources and frozen PDF
- `SOURCES.md`: public-source scope and attribution
- `COMPUTATION.md`: finite algorithms, recurrence and truncation formulas
- `code/algebra.py`: exact defect, scalar, marked-cumulant and signed-density generators
- `code/checks.py`: exact rational and symbolic checks against independent finite formulas
- `code/numerics.py`: direct recurrence fixtures, 205 endpoint/rare-parity mass cases and characteristic-function Jacobians
- `code/coupling.py`: supplementary exact log-concave residue-coupling fixtures
- `code/guard_tests.py`: finite input, filesystem, manifest and archive guard checks
- `code/receipt.json`, `code/numerical_receipt.json`, `code/guard_receipt.json`: frozen expected outputs
- `build.py`: integrity verification and disposable-copy PDF/code rebuild
- `code/reproduce_zip.py`: actual-ZIP extraction and complete normal/optimized rebuild comparison
- `requirements.txt`: exact Python dependency versions
- `MANIFEST.sha256`: hashes of every other packaged regular file

No code imports another report, private working directory, unpublished file or
network resource. The manifest is an integrity record, not a digital signature
or independent proof of authorship.

## Requirements

Use Python 3.12 with SymPy 1.14.0 and mpmath 1.3.0 for the frozen computational
receipts. The pure mathematical algorithms may also work with other versions,
but byte-identical receipts are checked against the stated toolchain. Install
Python dependencies in an environment of your choice:

    python -m pip install -r requirements.txt

PDF rebuilding additionally requires `pdftex` and `pdflatex` from TeX Live and
the packages used in `article.tex`. A matching TeX installation, fonts and
package versions are needed for byte-identical PDF output. An incompatible
installation fails visibly; the build does not silently refresh its reference
PDF or receipts. Build output records the observed Python and pdfTeX versions.
No network is used by the checks, build or replay programs.

## First checks

From this package directory:

    python -B build.py --verify-only
    python -B code/checks.py
    python -B code/numerics.py
    python -B code/guard_tests.py

These commands print JSON to standard output and leave the source tree alone.
Use `-B` as shown. All child Python commands include `-B`, and every executable
sets the integer-to-decimal digit cap to 640. Validation uses explicit exceptions,
so it survives optimized Python:

    python -B -O code/checks.py
    python -B -O code/numerics.py
    python -B -O code/guard_tests.py

Each check also accepts `--output /absolute/new/path.json`. The destination must
be new, its parent must already exist, and it must be outside this package.
The scripts reject symlink destinations or ancestors, dot/dot-dot traversal,
backslash components and any preexisting destination. They never replace a
frozen receipt. A failed guard check terminates with a nonzero exit status.

## Rebuild the frozen package

Choose a nonexistent output directory with an existing parent:

    python -B build.py --output-dir /tmp/report235-build

The build:

1. verifies every source hash and rejects extra, missing, symlink or nonregular entries
2. creates its output directory exclusively, without merging or reusing an old directory
3. reruns exact, numerical and guard checks and compares each output byte-for-byte with its frozen receipt
4. builds a private TeX format in a disposable directory, then compiles the article three times
5. disables shell escape during both format creation and article compilation
6. checks the TeX log for the listed unresolved-reference, missing-character and overfull-box diagnostics
7. requires the rebuilt PDF to match the frozen PDF byte-for-byte
8. writes `Report235.pdf`, `Report235.zip`, three JSON receipts, logs and `build_checks.json`
9. verifies that the source tree did not change

The archive includes every packaged file, including the manifest, original
receipts, all code and TeX sources, requirements and PDF. Members are sorted,
stored without compression, dated 2026-10-05 00:00:00 and assigned regular-file
mode 0644. TeX receives `SOURCE_DATE_EPOCH=1791158400`, UTC and a fixed locale.
The private TeX format, caches and auxiliary files never enter the source tree.

## Replay an actual ZIP, normally and with optimization

After producing the archive:

    python -B code/reproduce_zip.py --archive /tmp/report235-build/Report235.zip --output-dir /tmp/report235-replay

The replay validates archive paths, member types, size and count limits, then
requires the archive's complete member bytes to equal this trusted frozen source
package before executing any extracted Python. It creates two independent
extractions and builds, one under normal Python and one under `-O`.

It compares every member's bytes and metadata, each rebuilt ZIP's entire bytes,
the PDF, all three receipts and build checks. It also checks that the trusted
source, both extracted source trees and input ZIP remain unchanged. The result is
`reproduction_checks.json`. This is an actual-archive comparison, rather than a
comparison of selected outputs or a hash of a directory listing. The input
archive must be trusted; this program is not an arbitrary ZIP execution service.

## Finite mathematical scope

The default exact checks include:

- defects through order five against 50 finite-logarithm coefficients
- scalar coefficients through order four against an independent differential-operator construction
- centered Poisson moments through degree 12 against Touchard-polynomial formulas
- scalar logarithms and the first four cumulant generators through order four
- mean and variance through t² against finite weighted raw-moment calculations
- the complete weight-five logarithmic density difference, including the essential linear term
- exact symbolic characteristic-function derivative identities and 14 signed-moment polynomial identities
- the initial A360592 prefix and full exact marked-weight recurrence fixtures through n=200
- 2,520 supplementary exact log-concave coupling cases for q=2,…,7, including translated and singleton supports, all present residues and every common-quantile cell

`code/algebra.py --order K` prints the generated coefficients for 0 ≤ K ≤ 4.
The proof's all-fixed-order statement is mathematical; the public executable's
intentional finite cutoff is not an unlimited symbolic-computation promise.
Exact finite weights and recurrence functions accept 0 ≤ n ≤ 200. Their output
contains integers and rational expressions without floating-point fitting.

Default numerical fixtures use 80 decimal digits for both parities at
n = 10^4, 10^6 and 10^8. All six reference laws are checked: original and
Lambert-tilted Poisson, fixed-trial binomial, mean-corrected binomial,
moment-matched binomial and TV-tuned binomial. The last two use the recommended
variance approximation through t². Full probabilities on the central window
come from adjacent-mass recurrences, not the asymptotic density expansion.

The supplementary coupling checks are exact rational computations on supports
of 1–21 points. They include uniform weights, geometric ratios 1/100 and 100,
and deterministic decreasing rational ratios, with five shifts for each modulus.
They verify index-CDF interlacing, simultaneous component quantile distances and
distances to the unconditional quantile, including exact CDF breakpoints. They
do not assert any higher-modulus model approximation or global infimum theorem.

The 205 rare-parity/endpoint cases and six Jacobian checks use 90 digits. The
Jacobian is computed from the exact analytic derivative formula and corroborated
against mpmath differentiation; the symbolic derivative identities are checked
separately. None of these finite tests proves a uniform inverse theorem.

For the larger optional fixture, or a selected set:

    python -B code/numerics.py --extended
    python -B code/numerics.py --n 10000000000 10000000001 --digits 100

`--extended` adds both parities at 10^10. Explicit n values must be between
10^4 and 10^10+1, at most 12 per invocation; precision is bounded to 60–120
places. Nondefault output is exploratory and is not compared to the default
frozen numerical receipt. The exact and numerical default checks typically take
seconds on a modern CPU; TeX and the guard subprocesses add overhead.

## Numerical and reproducibility limitations

The displayed outside-window expressions are mathematically justified Chernoff
and finite-normalizer bounds, evaluated numerically. mpmath rounding, log-gamma
anchors, constants and displayed upper-bound values are **not interval-certified**.
A displayed bound smaller than machine arithmetic error does not bound that
arithmetic error. The JSON distinguishes the analytic truncation allowance from
floating-point uncertainty. The signed-density remainder statistics are explicitly
window statistics.

The finite-n tuned error need not be below the moment-matched error at small n;
the theorem compares their asymptotic leading constants. Integer trial rounding
also affects finite-n values and is included in the computations.

Byte reproducibility is a claim relative to the recorded installed toolchain,
not across arbitrary Python, symbolic-library or TeX versions. Finite guard tests
are not a general security proof and do not protect against a hostile process
concurrently changing filesystem ancestors. There is no receipt-refresh mode,
remote execution, automatic dependency installation, upload or publication step.
