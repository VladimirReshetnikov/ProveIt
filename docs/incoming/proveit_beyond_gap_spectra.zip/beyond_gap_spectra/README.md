# Beyond Gap Spectra
## Real traces and embeddability of old surreal fields

**Date:** 28 September 2026  
**Status:** AI-assisted research manuscript with written proofs; unrefereed and
not Lean-verified. Priority has not been independently certified.

## Files

- `article.tex`: complete standalone LaTeX source, including its bibliography.
- `article.pdf`: compiled article.
- `verify_finite.py`: exact finite regression checks, using only Python's standard library.
- `verification_results.json`: recorded successful run of the verifier.
- `SOURCES.md`: source locations and attribution boundaries.

## Principal result

In a Cohen extension N of a ground universe V, choose a reserved generic
coordinate outside a ground index set I. For each ground subset A of I, let
M_A = V[G_A] and F_A = No^(M_A). The article proves

    GapSpec_N(F_A) = {(omega, omega)},
    a unital class field embedding F_A -> F_B exists iff A is a subset of B.

Consequently the fields are pairwise nonisomorphic, although their entire
saturation profiles agree. The proof uses the intrinsic real trace

    Tr_R(No^M) = R^M as a subfield of the ambient real line.

This gives a proposed negative answer to the unrestricted **field-isomorphism**
implication in Question 19.4 (`univ:q:completeness`) of ProveIt's report
*Surreal Fields Across Set-Theoretic Universes*. It does not settle pure
linear-order isomorphism or classify fields with equal real traces.

The same construction represents every ground-model set-sized partial order
by exact field embeddability. One Cohen real already supplies continuum many
nonisomorphic examples, with residue fields all of the same cardinality.
Under Global Choice, the construction yields nonconjugate involutions on one
surcomplex class field, and exactly the same equivariant-embedding order.

A separate theorem computes the full old-surreal gap spectrum after adding
one kappa-Cohen subset as exactly {(kappa, kappa)}, without assuming
kappa^(<kappa) = kappa. Its proof explicitly tracks cardinal/cofinality collapse.

## Scope and proof status

The main construction requires no large cardinal, CH, or GCH. It is a theorem
in the usual same-ordinal ground/forcing-extension setting, not a claim that
ZFC proves the existence of a transitive model of itself or of a generic over
the actual universe. Proper classes and class maps are handled with explicit
class-theoretic conventions. Global Choice is added only for the simultaneous
surcomplex transports.

Classical surreal foundations, the repository's fresh-sign gap dictionary,
and published fresh-function forcing results are credited, not claimed as
new. The newness claim is limited to the proposed classification obstruction
and its precise realization consequences. The report is not a certified
solution of a named published conjecture and has not received independent
proof review.

No existing repository files were modified. No formalization was compiled.
The finite program does not test forcing, freshness, cofinality, saturation,
class recursion, or the main infinite theorems. It tests only local identities
used in the written arguments. In particular there are no finite fresh signs.

## Reproduce

With a standard TeX Live installation including Latin Modern, AMS packages,
`geometry`, `microtype`, `booktabs`, `enumitem`, `xurl`, `fancyhdr`, and `hyperref`:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
python3 verify_finite.py --output verification_results.json
```

The bibliography is internal; BibTeX and network access are not required.
The PDF was compiled and visually checked with a Poppler renderer. No font
files or third-party papers are included in the archive.

## Repository snapshot

`VladimirReshetnikov/ProveIt`

    e21766d04c2b8a9b2cdba0cd43e563024b3bd1b9

Main source location:

    Algebra/SurrealNumbers/docs/foundations-and-computation/
    surreal-fields-across-universes/article.tex

For exact URLs and the forcing literature, see `SOURCES.md` and the article's
linked bibliography.
