# Transition uniform Beta renewal asymptotics

A standalone research addendum for OEIS A047909 and A268485, dated 2 October 2026. The companion central/separated-regime report is unchanged and is not required to build or replay this addendum.

## Main result

For every fixed nonnegative truncation order R and fixed compact positive ratio interval a <= k/m <= b, the approximation has error at most C k^(-(R+1)/2) times the smaller of success and failure. Both tails therefore have the same relative order through the central, moderate-deviation, and fixed-ratio regimes. The exact zero-saddle switch is k=m+1. The proof uses a uniform (1+z^2)-weighted density bound, giving both L1 and L-infinity control, and nonsingular Gaussian-Hermite half-line kernels.

The article explicitly recovers P1 and c1, explains all-fixed-order matching, and includes both Lambert W branches for separated rare-tail inversion. Integer thresholds have qualified ceiling brackets with existential constants, not a certified unconditional rounding formula.

## Files

- `beta-renewal-uniform-addendum.pdf`: finished article
- `beta-renewal-uniform-addendum.tex`: editable, self-contained LaTeX source
- `build.sh`: portable Bash build; produces the PDF
- `replay.sh`: validates file hashes, reproduces checks, and optionally builds the PDF
- `scripts/check_uniform.py`: exact rational probabilities and high-precision tilted-kernel checks
- `scripts/check_symbolic.py`: independent symbolic derivation of saddle, kernel and matching coefficients
- `scripts/check_inverse.py`: symbolic inverse cancellation and finite smooth-carrier branch diagnostics
- `scripts/validate_outputs.py`: comparison with recorded checks
- `scripts/check_manifest.py`: safe-relative-path integrity verifier
- `scripts/make_archive.py`: explicit-allowlist archive generator
- `checks/`: pinned reference outputs
- `SOURCES.md`: bounded primary-source attribution and access scope
- `VALIDATION.md`: checks and limitations
- `source-hashes.json`: provenance hashes of the approved mathematical source notes and unchanged companion report
- `SHA256SUMS`: SHA-256 manifest of all archived files except itself

No external full-text article, credentials, hidden files, build cache, or PDF page image is included.

## Reproduce after ordinary ZIP extraction

Run these commands from the extracted directory containing this README:

    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements.txt
    PYTHON=.venv/bin/python bash replay.sh

This installs only SymPy and mpmath from their normal package registry. An existing Python with the pinned versions may be used instead. Scripts are invoked with `bash` or Python, so ZIP extraction need not preserve executable bits.

To rebuild the PDF as well:

    PYTHON=.venv/bin/python bash replay.sh --with-pdf

The PDF build needs pdfLaTeX, kpsewhich, and the packages used in the source: article, fontenc, inputenc, lmodern, microtype, amsmath, amssymb, amsthm, mathtools, geometry, booktabs, array, enumitem, hyperref, and fancyhdr. A normal full TeX Live or comparable installation supplies them. `build.sh` has a fallback for a minimal TeX installation whose format cache is missing. `OUTPUT_PDF=/path/to/output.pdf bash build.sh` selects a different PDF destination.

Fresh outputs go to `build/replay/`; the pinned reference outputs remain unchanged. PDF byte hashes may differ with toolchain metadata; successful compilation and mathematical replay, not byte-identical PDF output across installations, are the portability claims.

## Scope and attribution

The Esscher-Cramer tilted Edgeworth method is classical. The contribution presented is the family-specific uniform remainder proof and matching calculation. The expression is not literally the standard Lugannani-Rice formula. This bounded source audit does not certify historical priority.

Constants may depend on the fixed ratio interval and fixed expansion order. The work does not prove effective constants, numerical stability, endpoint-ratio uniformity, growing-order validity, convergence of the asymptotic series, optimal truncation, exponentially improved errors, or exact integer rounding. High-precision quadrature is not interval certified. Finite checks support implementation and algebra; they do not replace the proof.
