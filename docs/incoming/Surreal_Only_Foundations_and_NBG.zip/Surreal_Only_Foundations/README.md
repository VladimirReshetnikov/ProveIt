# Surreal-Only Foundations and the Set–Class Boundary

**Explicit axiomatizations, omnific quotient birthdays, bi-interpretations, and the obstruction at NBG**

Research manuscript prepared for Vladimir Reshetnikov with ChatGPT, 4 October 2026.

## Main outcome

There is an explicit recursively axiomatized first-order theory in the language
`{0,1,+,-,*,<,birthday}`, with surreal-number individuals, bi-interpretable with
ZFC. An omnific-integer version uses the additional binary operation
`h(a,b) = birthday(a/b)` for nonzero b, and `h(a,0)=0`.

The NBG target must be distinguished from the ZFC target. Assuming Con(ZFC),
no theory uniformly first-order interpretable in ZFC can interpret the usual
finitely axiomatized NBG theory. The manuscript proves this using reflection
and the second incompleteness theorem. It also gives a separate diagonal
obstruction to uniformly coding every available class by a set-sized number.

A two-sorted numerical/class theory is bi-interpretable with GBC/NBG, and the
construction extends to KM. That positive class-level construction deliberately
retains a class sort; it is not claimed to meet the strict numbers-only ontology.
The negative theorem does not exclude arbitrary external relabelling, unexplained
additional predicates, or changing to a larger universe.

## Contents

- `article.pdf`: 27-page article, including title page, contents, detailed proofs,
  eleven research questions, a formalization plan, proof ledger, and references.
- `article.tex`: standalone LaTeX source with internal bibliography.
- `verify_finite.py`: executable finite sanity checks; Python standard library only.
- `verification.json`: actual successful test results.
- `SOURCES_AND_STATUS.md`: source audit, attribution, limitations, and proof status.
- `build.sh`: rebuild instructions as an executable shell script.
- `build_validation.json`: metadata from the delivered PDF and checks.
- `SHA256SUMS`: checksums of the other package files.

No font files or third-party source manuscripts are included.

## Reading guide

The following are printed page numbers; the PDF viewer number is one larger
because of the unnumbered cover.

| Result | Location | Printed page |
|---|---|---:|
| Main classification | Theorem 1.1 | 3 |
| Rooted graph interpretation of sets | Theorem 5.2 | 8 |
| Explicit surreal axiom system | Definition 6.3 and Theorem 6.4 | 10 |
| Omnific quotient-birthday construction | Theorems 7.2–7.3 | 12–13 |
| No interpretation of NBG in ZFC | Theorem 9.2 and Corollary 9.3 | 14–15 |
| Direct diagonal obstruction | Theorem 10.1 | 16 |
| Exact class correspondence and both round trips | Theorems 11.2–11.3 | 18 |
| Birthday boundedness and set size | Theorem 12.1 | 19 |
| Further research | Section 14 | 21–22 |
| Verification and limitations | Sections 15–16, Appendix B | 22–25 |

## Attribution and proof status

The fundamental birthday-enriched surreal/ZFC bi-interpretation was already
announced by Junhong Chen, Joel David Hamkins, and Ruizhi Yang in 2025–2026;
it is not a new discovery of this report. The report gives a reconstruction,
a round-trip axiomatization, an explicit omnific transport, and further
class-theoretic deductions. Priority for the follow-on results has not been
independently established. No result is advertised as a certified breakthrough.

The proofs are mathematical arguments, not proof-assistant-checked theorems.
Finite checks are designed to catch indexing and quotient errors, not to prove
transfinite facts or consistency. No Lean development or fully serialized
first-order syntax compiler is included. The axiom systems are effectively
specified by fixed formula definitions and translation rules in the manuscript.

## Rebuilding

Install a reasonably complete TeX Live or MiKTeX distribution with pdfLaTeX,
`newtx`, `amsmath`, `amsthm`, `mathtools`, `microtype`, `booktabs`, `longtable`,
`enumitem`, `fancyhdr`, `titlesec`, `tcolorbox`, `xurl`, `hyperref`, and `cleveref`.
Python 3.10 or later is sufficient for the finite checks.

On a Unix-like shell:

```sh
bash build.sh
```

On Windows, run Python and pdfLaTeX from the extracted directory:

```text
python verify_finite.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Use normal Python execution, not `python -O`, because the test program uses
assertions. Rebuilding updates the PDF timestamps, so its checksum need not
match the delivered binary. No shell escape, bibliography server, or internet
access is required for compilation.

## Repository scope

The current repository README was inspected at revision
`bd1de458b7145f535cfcef0bef47d851c2e82463`.
Repository search also exposed excerpts at the earlier indexed revision
`fb2287290fb5b253ec8aa18d996887855119eb9c`.
The audit was targeted; the entire repository was not compiled or independently
verified. No repository files were modified.
