# An Eight-Depth Nonvanishing Theorem for OEIS A290268

**Dominant-root tangents, single-exponential cutoffs, and exact certificates**  
Research manuscript prepared for Vladimir Reshetnikov — October 1, 2026.

## Results and their scope

The article proves the coefficient zero classification for logarithmic deficits
(depths) 1 through 8 in the derivatives of `x^(x^2)`. Depths 1 through 4 were
already established in the inspected maintained ProveIt report. **The new
complete strata are depths 5, 6, 7, and 8, each at every derivative order.**

With

    gamma(k,d,M) = [w^M] (2+w)^k (1+w)^(2d) log(1+w)^d,

for integers `1 <= d <= 8`, `k >= 0`, and `M >= d`, the theorem states

    gamma(k,d,M) = 0  iff  M = k+4*d+1 and k+d is even.

The article also proves an all-depth global tangent minorant for the residual
polynomial. This gives explicit integer cutoffs of size `Theta(d^2 exp(d))`,
a deterministic `2^O(d)` bit-operation algorithm enumerating every exceptional
zero at a chosen depth, and the unconditional lower bound

    a(N) >= 3*N^2/8 + N*log(N)/2 - N*log(log(N)) - C*N

for absolute constants C and N0 and every integer N >= N0. Here log is natural.
The article supplies an explicit threshold-based bound without asymptotic
constants as well. The N log N consequence is analytic; it does not rely on
the large finite rectangles.

**The complete OEIS conjecture is not proved.** Depths 9 and above are not
fully classified, and the proposed leading asymptotic constant 1/2 remains
unproved. The results are unrefereed and not formalized in Lean or Rocq.
Novelty is assessed relative to the inspected maintained A290268 report,
not an exhaustive historical-priority search.

## Finite verification actually executed

The four new rectangles contain **608,785,773 cells**: 11,772 mathematically
forced reflection holes and 608,774,001 nonzero entries. Every nonhole has
nonzero residue modulo 1,000,000,007. A second-modulus fallback is implemented
but was not needed. Zero residues are never accepted as proofs of integer
vanishing.

The exact Python verifier checks all 18 rational moment anchors, 936
independent truncated polynomial identities, all 54 displayed OEIS terms
through derivative order 53, and 10,408 coefficient-bridge identities against
direct differentiation through order 80. It uses no floating-point arithmetic
in a certificate test. Depths 3 and 4 are also independently recertified by
this package's generic method; they are not counted as new classifications.

The finite calculations become all-order depth theorems **only because of
the analytic exhaustion argument proved in the article**. No claim is made
that all coefficients up to order 66,495 have been tested: that is merely the
largest order encountered in the depth-restricted rectangles.

## Files

- `article.tex`, `article.pdf`: complete 24-page article, with proofs, comparison
  to prior work, eight research questions, bibliography, and audit guide.
- `code/verify_exact.py`: standard-library exact Python verifier.
- `code/verify_rectangles.cpp`: standalone C++17 modular rectangle verifier.
- `data/exact_results.json`, `data/rectangle_results.json`: recorded executed
  results, not assumed inputs to the verifiers.
- `data/verification_environment.txt`: implementation and build environment.
- `Makefile`: reproducible verification and PDF targets.

## Reproduce

Python 3.9 or later and a standard C++17 compiler are sufficient for the
verification. No external Python or big-integer library is required.

```sh
make verify
make pdf
```

Or run directly from this directory:

```sh
python3 code/verify_exact.py > data/exact_results.json
c++ -O3 -std=c++17 code/verify_rectangles.cpp -o verify_rectangles
./verify_rectangles > data/rectangle_results.json
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The Makefile writes fresh output to temporary files and replaces recorded
results only after a successful run. `make clean` removes only its build
folder. The analytic arguments are written proofs, not steps that these
programs automatically verify. The compiler, language runtime, and arithmetic
implementation remain part of the computational trust boundary.

## Comparison sources

OEIS: https://oeis.org/A290268 (consulted October 1, 2026).

ProveIt snapshot: `f18afc619224ecccdf93fdf07f1709e56062b9e9`.

Maintained report:
`SetTheory/Cardinals/docs/reports/generating-functions-and-asymptotics/oeis-sequence-asymptotics/power-tower-derivative-term-counts/`.

The corrected README at that snapshot explicitly says that depths 1 through 4
are complete and that the open region starts at depth 5. The article source
blob is `7344f3aa4dc9344fb8648326e74e0d4bcc33eada`.

No OEIS submission, repository commit, or other external write was made.
