# Lexicographic Surreal Well-Orders
## Termination markers, increasing-word obstructions, and transfinite condensation

Research manuscript prepared for Vladimir Reshetnikov, 3 October 2026.

## Files

- `article.pdf`: the 30-page typeset article.
- `article.tex`: self-contained LaTeX source, including bibliography.
- `build.sh`: three-pass pdfLaTeX build with reference and overflow checks.
- `code/finite_checks.py`: Python 3.10+ standard-library diagnostics.
- `data/finite_checks.json`: recorded deterministic run (547,480 checks passed).
- `RESEARCH_STATUS.md`: mathematical and verification boundaries.
- `SOURCE_AUDIT.md`: sources inspected and provenance.
- `SHA256SUMS.txt`: checksums of the distribution files other than itself.

## Main results

Section 5 gives a necessary-and-sufficient termination-marker criterion for
set-cut saturation of arbitrary and injective set-length words. Section 6
computes their point characters and includes both admissible adjacent markers
and a regular-cardinal family of failures. Section 7 proves that no fixed
termination marker saturates the strictly increasing word order.

Sections 10–11 define set-interval condensation with least representatives
and construct explicit finite-support ordinal-polynomial examples with every
prescribed admitted well-ordered hierarchy length. Section 12 places copies
of these raw well-orders inside every lexicographic interval between distinct
set-like global enumerations. The construction works for a given class
well-order parameter and does not collect all class well-orders into a class.

Other sections distinguish the interpretations of the question, re-prove the
fixed-set spectrum and the dense set-supported core results credited to the
repository, give a direct comparison of raw well-orders, explain paradox-free
foundations and bounded-universe models, and propose ten further projects.

## Reading paths

For the new word-order results, read Sections 3–7.
For the condensation hierarchy, read Sections 9–12.
For foundations and implementation, read Sections 13–16.
The taxonomy is Section 2 and the result ledger is Section 17.

## Build and reproduce

From this directory:

```sh
python3 code/finite_checks.py --output data/finite_checks.json
sh build.sh
```

The article uses ordinary TeX Live/MiKTeX packages: lmodern, geometry,
amsmath/amssymb/amsthm, mathtools, mathrsfs, microtype, booktabs, longtable,
tabularx, array, enumitem, xcolor, fancyhdr, hyperref, xurl, and tcolorbox.
No bibliography program, external figure, shell escape, or network access
is required. On Windows, run pdfLaTeX three times or use a shell to run
`build.sh`.

The finite checker uses a fixed seed, 20261003. It does not test proper-class
size, set-cut saturation, or transfinite limits. Recompiled PDFs can have
different metadata and therefore different byte checksums.

## Status

AI-assisted, unrefereed research manuscript. Ordinary mathematical proofs are
provided, but historical priority and Lean kernel verification are not claimed.
No repository write, repository build, or Library mutation was performed.
The repository input is pinned at
`109aaca1505c12d70ae169bdc2011f40bd476f7d`, not asserted to be the latest tip.
