# Quadratic Diophantine certificates for a fixed Waterfall universal machine

Private research article and exact-integer replay package, 2 October 2026.

## Read first

- `waterfall-diophantine.pdf` is the rendered article
- `paper/waterfall-diophantine.tex` and `paper/affine-gap-table.tex` are its editable LaTeX source
- `SOURCE-PROVENANCE.md` records the credited upstream machine, primary paper, and source-data hashes
- `LICENSE-PROVENANCE.md` states the provenance and redistribution limits; no blanket upstream license is assumed

The fixed 46-clock universal Waterfall matrix is Iijil's prior work. The underlying 15-state binary universal Turing machine is due to Neary and Woods. The article gives the complete canonical input interface, symbolic macrostep verification, a direction-group quadratic certificate, and a separate decidable common-column companion.

For each external TM horizon k >= 1, the main equation has exactly 35k natural witnesses, 5k+4 squared linear residuals, and 2k nonnegative quadratic complementarity products. Its natural fiber is empty or a singleton. The equation recognizes first halt at exactly k source instructions and records exact prehalt Waterfall firing count C and halt timestamp tau. The number of witnesses grows with k. This is not a fixed-arity equation for unbounded universal computation. No operation-count frontier, optimality, peer-review, or proof-assistant claim is made.

## Run the complete replay

Requirements: Python 3.9 or newer, standard library only. No network or package installation is needed.

```sh
sh run-replay.sh
```

The runner writes deterministic JSON receipts and readable logs. A successful final line says `All Waterfall replays passed.` Do not run Python with `-O`: the scripts deliberately use assertions as proof obligations.

To check the packaged bytes before running:

```sh
sha256sum -c SHA256SUMS
```

Individual checks:

```sh
python3 replay/verify_matrix_definition.py
python3 replay/verify_frontend.py
python3 replay/verify_frontend_independent.py
python3 replay/grouped_quadratic.py
python3 replay/verify_quadratic_independent.py
python3 replay/verify_halting_example.py
python3 replay/verify_certificates.py
python3 replay/verify_release.py
```

### What each check establishes

1. `verify_matrix_definition.py` reconstructs the article's compact matrix specification and checks all 2,116 entries against the frozen source matrix
2. `verify_frontend.py` proves all 58 defined instruction/residue macrosteps by exact affine first/last-iteration inequalities, covering 43,065 obligations and 64 distinct domain-tagged forms; it also checks every final coordinate
3. `verify_frontend_independent.py` independently proves loop guards by reparameterization into natural orthants, verifies the timing potential, and checks 2,842 concrete macrosteps with deadline/countdown engines
4. `grouped_quadratic.py` constructs the 35k-witness polynomial, exports coefficient-level factors, evaluates the seven-step halting fixture, and runs mutation and arbitrary-assignment checks
5. `verify_quadratic_independent.py` reads the source TM directly, evaluates the formulas separately, and checks 400 arbitrary-assignment alignments with the symbolic compiler
6. `verify_halting_example.py` chooses every event directly from the raw matrix in both deadline and physical-countdown semantics; it confirms 189 prehalt events and halt at timestamp 428 from (L,R)=(6,0)
7. `verify_certificates.py` checks the common-column companion, 22/26-operation ledgers, CRT intersections, domain counterexamples, earlier ties, and nonpositive relative-diagonal locks
8. `verify_release.py` cross-checks the final receipts and evaluates the exported polynomial data at the complete natural witness fixture

## Main reproducible data

- `source/UniversalTM15x2.twm.txt`: exact original matrix serialization, including metadata; only 46 clocks are actual clocks
- `source/UniversalTM15x2.tm.txt`: exact original source TM table with its attribution
- `replay/grouped-quadratic7-certificate.json`: all 39 linear residuals and both factors of all 14 complementarity products, represented as integer coefficient/monomial lists
- `replay/grouped-quadratic7-fixture.json`: all 245 natural witnesses and four parameters for the halting example
- `replay/affine-gap-forms.json`: the 64 raw affine forms with activation bounds and multiplicities
- `receipts/halting-example.json`: the full directly generated event/timestamp trace
- `receipts/release-verification.json`: concise cross-check summary

The polynomial JSON represents the sum of the listed squared linear residuals plus the listed products. It does not omit a black-box predicate or an unexpanded arithmetic primitive. The implementation can expand those sums into a sparse degree-two polynomial if desired.

## Rebuild the PDF

Requirements: a TeX Live installation with pdfLaTeX and the standard packages loaded by the source (AMS, Latin Modern, microtype, geometry, array/booktabs/longtable, enumitem, fancyhdr, xcolor, hyperref).

```sh
sh build.sh
```

The build runs three passes, writes intermediate files only in `.build/`, and places the resulting PDF at the package root. Its small compatibility fallback handles minimal Linux images that have TeX files without a generated filename database or format. The shipped PDF is already rendered and visually reviewed.

## Evidence boundaries

The symbolic cone checks are all-value algebraic certificates, not bounded input experiments. Concrete simulations, mutation tests, and random-assignment alignments are additional implementation checks. The written natural-domain soundness, completeness, and uniqueness proofs are necessary parts of the result. The external TM horizon is never hidden in a variable-length operation. Source-paper PDFs, upstream Go source, and private working notes are not included.
