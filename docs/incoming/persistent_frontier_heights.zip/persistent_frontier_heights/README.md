# Persistent frontiers and exact ordinal heights

Research manuscript and reproducible calculations, 24 September 2026.
Prepared for Vladimir Reshetnikov with ChatGPT.

## Results

The article resolves the **nonuniform-height gap** explicitly left in ProveIt's
`cofinal-strata-of-finitary-powersets` report, and extends the calculation to
all ordinal-chain fibers over a finite poset.

For positive pure fibers alpha_q = omega^(rho_q), rho_q > 0, use the poset of
inclusion-maximal antichains under Hoare domination. A transition A < B has
weight max{alpha_q : q in A minus B}; a terminal frontier A has weight
max{alpha_q : q in A}. The height of the finitely generated downsets is the
maximum **ordinary ordinal sum** of the transition and terminal weights
along a nonempty strict frontier chain. The article proves both an upper
rank bound and an attaining chain.

A general persistent-coordinate theorem supplies this result. CNF block and
phase refinements then handle arbitrary ordinal capacities, finite endpoints,
and exact individual ranks via capped principal ideals.

This is a proved extension relative to the inspected repository. Literature-wide
novelty and priority are not established. The manuscript is unrefereed and has
not been verified in Lean. The code tests finite structures and implementations;
it is not a substitute for the transfinite proofs.

## Files

- `article.pdf`, `article.tex`: complete article, proofs, eight further research
  questions, source provenance, and embedded bibliography.
- `code/ordinals.py`: exact hereditary Cantor normal forms below epsilon_0.
- `code/persistent_height.py`: the solver, independent peeling algorithm,
  phase refinement, and exact point-rank API.
- `code/verify.py`: finite structures, independent arithmetic and path tests.
- `code/check_local_ranks.py`: exact finite-rank checks and symbolic regressions.
- `examples/*.json`: ten small input examples.
- `data/*.json`, `data/*console.txt`: recorded outputs and test counts.
- `PROOF_AUDIT.md`: proof dependencies, delicate points, and limitations.
- `SOURCES.md`: source/version and novelty-search notes.
- `build.py`: optional reproducible PDF build, with optional verification.

## Run

Python 3.10 or later, standard library only. Tested with Python 3.13.5.
Run from this directory:

```sh
python code/verify.py
python code/check_local_ranks.py
python code/persistent_height.py examples/weighted_N.json
python code/persistent_height.py examples/persistent_large_coordinate.json
python code/persistent_height.py examples/successor_product.json
```

The first verifier recorded **129,593 assertions**. Its abstract-system family
accepted 9,714 assignments satisfying no-resurrection and rejected 1,011 that
did not. The second verifier checked 940 finite systems, 6,132 individual finite
ranks and 37 symbolic regressions. See the JSON records for exact breakdowns.
A finite test is not a computation of an infinite rank tree.

## Input format

`n` gives the finite skeleton size; vertices are 0 through n-1.
`edges` contains strict comparisons (Hasse edges suffice). `fibers` is one
ordinal per vertex. `mode` is `pure` or `general` (the default).

An ordinal is a nonnegative JSON integer, or a list of
`[exponent, positive_coefficient]` pairs in strictly decreasing exponent order.
Exponents use the same recursive format. Examples:

```json
[[2,1],[1,2],[0,3]]
```

means omega^2 + omega*2 + 3, whereas

```json
[[[[1,1]],1]]
```

means omega^omega.

The `pure` mode requires nonzero pure powers with positive exponents and uses
maximal frontiers. The `general` mode expands finite CNFs and uses **all**
antichains, including the empty one. It supports zero and finite fibers.

Example:

```json
{
  "n": 4,
  "edges": [[0,2],[1,2],[1,3]],
  "fibers": [[[3,1]],[[1,1]],[[1,1]],[[2,1]]],
  "mode": "pure"
}
```

The result is omega^3 + omega^2. Output includes the exact CNF, a maximizing
state path, its weights, and an independent leading-exponent certificate.

## Size and notation limits

The mathematical proofs cover arbitrary set ordinals. The executable notation
system deliberately stops below epsilon_0. It uses no floating-point arithmetic.

The implementation enumerates antichains by subsets and may be exponential in
skeleton size. CNF coefficients are expanded into individual blocks; they are
not handled in logarithmic time. General lexicographic expansion has a default
18-block guard, configurable with the input field `max_blocks`. This is a
safety ceiling, not a claim that every 18-block instance is fast: antichain-rich
instances can be much more expensive than chains. Begin with small instances.
Coordinate phase refinement separately defaults to at most 4,096 refined states.
Direct validation of a state system checks state triples and can also be costly.

## Exact point ranks

From the `code` directory:

```python
from ordinals import Ordinal as O, OMEGA, ONE
from persistent_height import System, exact_point_rank

alpha = O.power(O.nat(2))
system = System([1], [3], {0: alpha, 1: alpha})
rank = exact_point_rank(system, 0, {0: OMEGA + ONE, 1: OMEGA})
print(rank)  # omega*2 + 1
```

State relations and active sets are bit masks: `le[i]` contains all states above
state i, including itself; `active[i]` contains its active label indices.
Capacities are a label-to-ordinal dictionary. `refine_capacities` accepts any
nonzero ordinal capacities. The direct weighted-path theorem itself requires
positive pure powers. The API validates these distinctions.

**Do not use the compact maximal-frontier model to infer point ranks in the
original downset poset.** That compression is equi-height via two embeddings,
not an exact rank-preserving representation. Use the exact all-antichain model
returned by `general_ordinal_system`, or another exact persistent model.

## Build the PDF

A standard TeX Live installation with pdfLaTeX, AMS, New PX, TikZ, tcolorbox,
microtype, hyperref and the other packages declared in the preamble is sufficient.
No external images, bibliography database, shell escape, or network calls are used.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively:

```sh
python build.py --verify
```

The helper builds in `_build/` and copies the completed PDF to `article.pdf`.
It does not modify the ProveIt repository. Font files and third-party PDFs are
not redistributed in this package.
