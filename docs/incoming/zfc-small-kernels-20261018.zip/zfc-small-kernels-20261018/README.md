# A 999-bit, three-function consistency kernel — sub-245 research

**No Turing machine with fewer than 245 working states was established.**
This contribution provides a new finite consistency formalism, full ordinary
mathematical reductions, exact payloads and reference refuters, and reproducible
machine-level searches that did not improve the supplied 245-state endpoint.

Read **report.pdf** for the complete result and proof. **report.tex** and all
its included sections are supplied and build with a standard LaTeX installation.

## Main new result

The preferred small-signature theory has one constant `d`, three proper
functions `V:2, C:3, A:2`, and four ordinary binary predicates `E, Inc, G, Eq`.
It has **19 universal clauses, 45 literals, at most four local variables,
268 term nodes and exactly 999 flat bits**. The bitstream fits in 125 bytes
with one trailing zero padding bit. Its extensional control has 20 clauses,
49 literals and 1,182 bits.

The proof first quotients membership while keeping assignments and class codes
raw. A truth lemma for ordinary formulas removes update and incidence
congruence. Product models then allow distinct semantic roles to share
constructors. The final model uses three coordinates: object/assignment,
class code, and an injective raw-input identifier. This gives the following
literal substitutions, all fully expanded in the payload:

```text
q = A(d,d)             r = C(d,d,d)          h = C(d,d,q)
N(a,b) = C(d,a,b)      Q(j,a) = C(q,j,a)
H(b,t) = A(C(b,t,d),d) Y(b,t,u) = A(C(b,t,u),q)
W(s,j,a) = A(C(s,j,a),r)
Z(b,t,u) = A(C(b,t,u),h)
```

The four raw markers are proved distinct in the constructed upper model.
No marker-distinctness axiom, pairing symbol, raw decoder or additional
constant is inserted into the theory. The reverse direction is a literal
definitional expansion, followed by the raw-assignment quotient theorem.

Using the explicitly inherited ProveIt EPSC calibration, ZFC proves that this
finite theory is consistent if and only if ZFC is consistent. The extensional
control offers the separate, direct extensional-EPSC bootstrap dependency.
The report identifies exactly which theorems are new and which are inherited.

| Raw presentation | Proper functions | Constants | Clauses / literals | Flat bits |
| --- | ---: | ---: | ---: | ---: |
| Prior completed FC15* reduct | 9 | 1 | 20 / 53 | 1,134 |
| New selective equality | 9 | 2 | 19 / 45 | 971 |
| New hull sharing | 8 | 2 | 19 / 45 | 971 |
| New witness sharing | 6 | 2 | 19 / 45 | 1,011 |
| New witness sharing | 5 | 2 | 19 / 45 | 1,027 |
| **New three-function theory** | **3** | **1** | **19 / 45** | **999** |

The eight-function alternative minimizes the delivered raw flat stream; the
three-function alternative gives a smaller constructor dispatcher, radix-four
ground enumeration, and three-bit term-template tokens. These are distinct
compiler cost measures. Neither is a Turing-machine state bound.

## Exact program specification

The Python reference refuters enumerate every ground substitution into the
finite clause list, including collisions, and decide each resulting finite
CNF using ordinary propositional satisfiability. Endpoint terms are retained
even when their codes exceed the stage's substitution frontier. Equality is
an ordinary predicate; no omitted congruence is restored by the solver.
Herbrand's theorem and compactness prove that the search halts exactly when
the finite theory is inconsistent. Errors propagate and never mean UNSAT.

The 999-bit stream SHA-256, excluding its text newline and packing padding:

```text
666e1e6d4437fa2572bd4f84878e411035fd7a5615647a8460bab83f2043bba7
```

Packed `.bin` SHA-256:

```text
de4954a5ae85242ba65835ce3feacaf57619061f6bbf5ed9d25d96211040b687
```

## Reproduce

Python 3.10+ and the standard library suffice for the default finite checks:

```sh
python3 -B verify.py
```

This checks delivered hashes, regenerates all new payload families, runs their
codec and finite-stage checks, independently recomputes the three-function
substitutions and fixed opcodes, audits 39 retained grammars, and replays the
scanner positive control. Outputs go to a new temporary directory, printed
on completion; the delivered result files are not overwritten. Assertions
must remain enabled.

Run the main reference refuter directly:

```sh
python3 -B three_function/three_function_sharing.py --stage 1
python3 -B three_function/three_function_sharing.py --stage 1 --extensional
```

The optional `--whole-search` is intentionally unbounded and halts only after
finding an exact finite refutation. It is not a practical consistency test.

Rebuild the report with:

```sh
make pdf
```

Optional heuristic/SMT searches have their own commands and C++17/Z3
requirements in `grammar_search/README.txt` and
`transition_search/COMPILER_RESEARCH.txt`. The current fixture extractor
expects the pinned original 245-state package; its 25.5 MB decompressed
trace is intentionally not duplicated.

## Direct state-reduction experiments

- New common-action mergers examined 439 state pairs and tested 23,620 merged
  tables after a bounded continuation-join screen; zero passed the complete
  finite-fixture acceptance conditions. This is a scoped search result.
- General writable seven-state scanner synthesis timed out. One explicitly
  restricted 32-step family was UNSAT; this does not exclude all seven-state
  scanners. Positive and monotone-negative controls passed.
- All 40,320 AX row orders were visited for two source dictionaries. Bounded
  dependency-union parsing and shared parenthesization found no grammar below
  128 rules. Exhaustive row-order enumeration is not exhaustive grammar search.
- A matched basis experiment found 133 grammar rules for K/S/Peirce and 134
  for the shorter K/B/Peirce source, illustrating the effect of shared code.

The inherited 245-state reference passed a fresh default certificate replay,
including 8,391 universal affine cases and the exact 407,915-step blank
initialization. Its canonical table is clearly labelled under `reference/`.
It is included as a control, not a new machine.

## Verification status and integration

The new arguments have full ordinary mathematical proofs and independent
analysis reviews. The finite code checks are not proof-assistant proofs.
No new Lean/Rocq endpoint, serialized PA proof translator, or sub-245 binary
machine is claimed. Novelty is scoped to the inspected supplied sources.

Suggested project location:

```text
Computability/BusyBeaver/Research/ZFC/three-function-kernel999/
```

The research package may also be retained intact in `docs/incoming/`.
`PROVENANCE.json`, the incoming-source manifest, and inherited license/notice
files preserve attribution. The pinned ProveIt commit is
`fd1adfa19f8fe8da41444e3fa43b89a59d891067`.

The unresolved task is concrete: compile one of these exact refuters to a
complete binary table, prove its unbounded simulation, and include blank
initialization while staying below 245 working states.
