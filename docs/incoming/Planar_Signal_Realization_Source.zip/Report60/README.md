# Report60 Planar signal realization and strict validity kernels

The report proves an exactly-five-live-signal realization of every rational positive-determinant planar map, classifies all rational planar strict polygon kernels, and gives explicit positive-integer certificates. The infinite-order elliptic branch has degree twelve with 1+81J witnesses and 1+44J residuals for J fixed contacts. Every remaining rational-input branch has a quadratic certificate with a uniquely forced positive slack tuple. These are explicit upper-bound constructions, not optimality or universal-computation claims.

## Deliverables

- `Report60.pdf`: typeset report
- `Report60.tex`: standalone editable LaTeX, containing the entire report and analytic figure
- `manuscript/`: equivalent modular sources and their exact pin map
- `science/`: four byte-preserved mathematical source packets
- `audits/`: their source-bound independent reviews and exact evidence
- `dependencies/`: pinned Report59 proof, inert Pell source, and its license
- `tools/portable-replay/`: independently reviewed portable replays for three independent checkers; the quadratic companion is authenticated as inert evidence only
- `manuscript-review/`: complete final independent mathematical and all-page review
- `qa/`: assembly, build, preservation and visual-review evidence, including the independent release-tool review

The standalone source is exactly the expansion of the four local inputs in `manuscript/Report60.tex`. The builder verifies this equality and typesets the standalone copy. The figure is analytic geometry, not a physical trajectory simulation.

## Safe release commands

Run from the release directory. Use installed Python 3 and the exact TeX Live/Poppler toolchain recorded in `tools/BUILD_DEPENDENCIES_LOCK.json`. The builder checks executable and TeX-input hashes before executing subprocesses, checks the exact TeX input set after compilation, and rechecks executable bytes afterward. Dynamic libraries are not inventoried. No command installs software or runs a scientific source program.

Every output path must be a new canonical absolute path outside the release, with an existing parent. Symlinks, hardlinked input files, unexpected empty directories, and changes to authenticated scientific inputs are rejected.

Authenticate all frozen science, review and dependency files without executing them:

    python3 -I -S -B tools/release60.py check-inputs

Rebuild in a fresh workspace, require byte equality with the packaged PDF, and render every page:

    python3 -I -S -B tools/build_report60.py --output-dir /tmp/report60-rebuild --require-packaged-match

The build checks the rendered page inventory against the PDF page count and validates PNG headers, dimensions, chunk CRCs and completeness. It rejects final overfull boxes and unresolved references. Manual visual review remains necessary.

Verify the sealed release with its separately supplied trusted manifest digest:

    python3 -I -S -B tools/release60.py verify --manifest-sha256 PIN

Create a deterministic external ZIP only after verification:

    python3 -I -S -B tools/release60.py archive --manifest-sha256 PIN --output /tmp/Report60-source-evidence.zip

The `manifest --output /tmp/new-manifest.json` command creates a prospective manifest externally without rewriting this release. A digest is not a signature: the release pin must come through a trusted separate channel. Success requires exit status zero and the printed PASS receipt. A late failure may leave a partial output for inspection; tools do not overwrite or delete competing outputs.

For independently owned scientific replay, follow `tools/portable-replay/README.md`. Its explicit nine-root invocation works in relocated copies, uses Python with SymPy 1.14.0, and compares seven results byte-for-byte. Author constructors/checkers, saved collision schedules, physical simulators, and upstream Lean programs remain inert. The replay's runtime I/O guard supplements reviewed pinned code; it is not a general sandbox for hostile Python.

## Mathematical and evidence boundaries

This is conventional proof with independent source review and finite exact/static support, not end-to-end formal verification. The Pell module depends on explicitly identified constructive theorems in a pinned inert mathlib source; no Lean build is claimed. The finite checks do not establish universal chronology by themselves.

The physical compiler applies to GL2+(Q), with A and positive rational global scale fixed for each machine. Its larger meta-signal alphabet is separate from its five live strands. The abstract geometric and quadratic-certificate results also include singular and negative-determinant rational matrices; no corresponding physical realization is claimed. No uniform polynomial physical compiler, generic emitted arithmetic DAG, gate count, priority, minimality, unrestricted Turing-completeness, or post-Zeno continuation is claimed.

The irrational stable-line real set can need algebraic coefficients even when its rational-input predicate is zero. A finite sign obstruction on rational or integer inputs does not prohibit an existential-integer certificate. Fixed-A polynomial decision, uniformly polynomial elliptic decision, the credited general counting-hierarchy upper bound, and exponential explicit affine output are different claims.

The arithmetic source remains frozen with minor wording erratum E1 recorded by its audit: there are at most floor(log2 b) successful whole-base divisions and 1+floor(log2 b) recurrence steps, with a final divisibility test if needed. The report uses the corrected wording; no theorem or certificate changes.
