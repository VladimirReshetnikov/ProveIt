# Balanced ballot words over every fixed alphabet

The report proves the fixed-row asymptotic conjecture in OEIS A215561,
specifies its positive algebraic leading constants, and gives a finite
coefficient rule for every algebraic order. It also proves D-finiteness
for every fixed alphabet and supplies a qualified asymptotic inverse.

## Contents

- `article.pdf`, `article.tex`: complete standalone report and LaTeX source
- `checks/`: finite direct enumeration, exact lattice/covariance checks,
  low-alphabet coefficient calculations and general inverse verification
- `audit/structural_review.md`: independent mathematical review
- `run_checks.py`: portable verification entry point
- `build_local.sh`: local TeX Live build, without home-directory writes

## Reproduce

Run `python -O run_checks.py` with Python3 and SymPy available. No check
uses a guessed sequence recurrence or accesses a network. The direct
content-vector enumeration uses only the Python standard library. The
lattice checks use exact rational matrices and phase classes. The
low-alphabet checks reconstruct the first two correction coefficients
from the marked Catalan and Motzkin kernels and check the general inverse
formula symbolically.

The root-product script checks the small explicit constants exactly and
also gives floating-point orientation for larger examples. Those
numerical root values are explicitly labeled as such and are not an
input to the proof or a certificate of a numerical error bound.

Run `bash build_local.sh` to rebuild the PDF. Standard TeX Live is
required. Its format and auxiliary files are generated inside `build/`.

## Scope

The alphabet size is fixed. All correction coefficients are real
algebraic and effectively computable by the finite root-factor and
Gaussian procedure in the paper. The supplied code checks examples of
that procedure; it is not a general-purpose implementation for arbitrary
alphabet size and expansion order.

The expansion covers every algebraic order in the dominant exponential
sector. It does not describe all smaller exponential sectors, prove a
particular guessed recurrence, or provide uniform estimates for a
growing alphabet. The inverse retains its necessary integer-rounding
qualification and does not include explicit numerical remainder constants.

The source check is relative to the current OEIS entries and inspected
primary literature; it is not an exhaustive worldwide priority claim.
