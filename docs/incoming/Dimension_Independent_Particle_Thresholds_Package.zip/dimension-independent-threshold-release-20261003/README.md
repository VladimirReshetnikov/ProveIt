# Report 29 — Dimension independent particle thresholds

3 October 2026

## Result

Exact finite-configuration reachability and finite-pattern occurrence are decidable at conserved mass at most four in every finite spatial dimension, for the finite-range translation-invariant cellular automata specified in the report: a finite alphabet, a unique weight-zero vacuum, positive integer other weights, and at most one weight-one symbol. Both anchored and translated observations, including prescribed zeros, are included. Reversibility is unnecessary.

The full effective proof reduces continuing long-distance interactions to one scalar gap, using actual support contact rays and an exact finite nonparallel-switch exception. The existing one-dimensional five-particle universal construction from Reports 16 and 26 embeds linewise, so its inherited upper bound matches the lower theorem. The report does not reprove all source compilation results or assert novelty or priority.

Appendix A gives canonical fixed-input timed quadratic charts and ordinary quartic natural-witness certificates. It explicitly inherits Report 13's algebraic compiler. Exact-time single-witness fibers do not imply untimed finite-foldness, a uniform witness count over inputs, or exactness over rational or real witnesses.

## Deliverables and evidence

- `report29.pdf`: complete typeset article
- `report29.tex`: editable LaTeX source, with a native vector diagram and direct primary bibliography links
- `scientific/PROOF.md`: portable delivery copy of the frozen main proof
- `scientific/audit.md`: earlier mathematical audit
- `scientific/independent-review.md`: new independent adversarial mathematical review, whose three clarifications are incorporated in the article
- `scientific/literature.md`: bounded primary-source literature check and source-access limitations
- `scientific/audit_arithmetic.py`: unchanged original finite arithmetic audit
- `scientific/check_independent_arithmetic.py`: independent audit, adapted only to bind to the delivered proof hash
- `scientific/timed/`: complete timed-certificate companion proof, independent review, and unchanged finite algebra checker
- `verification/expected-*.json`: deterministic typed expected receipts
- `verification/source-lineage.json`: precise source and delivery hash lineage
- `reproduce.sh`, `replay.py`, `tamper_regression.py`: preflight, isolated replay, and corruption regressions
- `build.sh`: PDF rebuild to an external directory
- `SHA256SUMS`: exact full payload manifest

The core theorem has an ordinary mathematical proof and independent inspection. Neither the finite arithmetic audits nor the quartic fixtures implement a general CA-rule-to-section or CA-rule-to-chart compiler. No proof-assistant formalization is claimed. Copyrighted source-cache PDFs are not included; use the verified primary links.

## Reproduce the arithmetic

Requirements: Python 3.10 or later and a POSIX shell. All tests use only the Python standard library.

From the extracted release:

    sh reproduce.sh --verify-only
    sh reproduce.sh --output-dir ../report29-replay

Choose a new or empty output directory outside this release. The entrypoint first checks an independently hard-coded exact required inventory, rejects symlinks and extra files, checks all manifest hashes, and validates separately pinned scientific and helper hashes. No packaged Python helper executes before this preflight. The manifest is an integrity check, not a signature or a substitute for trusting the entrypoint and distribution hash.

The runner executes each scientific checker twice, normally and with Python `-O`, in separate fresh temporary copies. It checks receipt values and JSON types recursively against the frozen expected schema and compares the two modes. A type-only boolean-versus-integer regression is included. The checkers' output files are created only in those copies. It then checks that release payload bytes, modes, and modification times are unchanged. Logs and receipts are written only to the requested external output directory.

The corruption regression uses fresh copies and calls preflight only. It rejects changed scientific code, changed code with a resealed manifest, missing required code with and without resealing, extra payloads, and symlink replacement, before any helper or altered scientific code executes.

The expected scope is finite arithmetic/formula checking, not exhaustive testing of all cellular automata. The original contact audit uses seed 20261003. See Section 16 and Appendix A of the report for the tested cases and proof-versus-test distinction.

## Rebuild the PDF

Requirements: pdfLaTeX/TeX Live with Latin Modern, AMS packages, geometry, microtype, hyperref, fancyhdr, enumitem, booktabs, and TikZ. Poppler is useful for visual review.

    sh build.sh ../report29-rebuild

The build writes only into a fresh temporary work directory and the specified external output directory. It neither replaces the packaged PDF nor changes the sealed inventory. It disables shell escape, runs three passes, and rejects overfull boxes or unresolved references. It can initialize a writable temporary TeX format if the installed format is absent. The default source date is fixed; byte-identical PDF output across different TeX installations is not promised.

## Source lineage and adaptations

The frozen main proof SHA-256 is `3e8eb41fe43b5b4b61d0e0a5b4bece3b01cf628f834a820ecc369f4da427b30a`. Its delivery copy changes only the introductory delivery description and environment-specific provenance paths; its mathematical sections are unchanged. The independent checker changes only its `EXPECTED` proof digest to that delivery copy's hash. Expected arithmetic values are unchanged; only its receipt's proof-binding hash follows the new delivery digest.

The new independent review's frozen source SHA-256 is `0ee604e8f6ef73788a943802e971bce46a4a54bb5ba386b9d16677aff79e44f0`. Its delivery copy removes coordination wording and updates the portable script and illustrative path references. The timed companion is copied byte-identically from its separately reviewed portable delivery. All exact lineage is recorded in `verification/source-lineage.json`.

Earlier releases remain unchanged. The inherited five-particle upper construction and the one-dimensional timed compiler are attributed to the prior reports, rather than presented as new results of this report.
