# Bounded image-closure and ZFC inconsistency

Research memorandum prepared for Vladimir Reshetnikov, 15 October 2026.

## Main result

The article proves that **Extensionality + an inhabited set + the bounded
image-closure schema (BIC)** is deductively equivalent to ZF with only
Foundation removed, using ordinary functional Replacement (not an unannounced
Collection schema). BIC combines the attached dossier's subset-bounded image
idea with closure under further images, inspired by MathOverflow question
380000.

An elementary membership-congruence axiom gives an equality-free theory QBC.
The article gives uniform proof-translation arguments which, combined with
standard effective Foundation and Choice reductions, yield PA-provable
consistency equivalence with ZFC. All schema parameters and freshness
conditions are explicit.

Start with **article/zfc_closure_kernel.pdf**. Its complete, standalone LaTeX
source is **article/zfc_closure_kernel.tex**.

## Package contents

- `article/`: the report and compiled PDF, including proofs, failure cases,
  comparison with the linked MathOverflow theory, implementation priorities,
  current-machine source audit, and further research questions.
- `code/bic.py`: BIC axiom generator, exact node metrics, strict equality-free
  formula parser, and an assumption-free Hilbert certificate checker.
- `code/logic.py`: syntax utilities retained unchanged from the supplied
  archive, with provenance and hash recorded.
- `code/test_bic.py` and `code/graph_audit.py`: syntax/checker regression tests
  and exhaustive small-graph closure tests.
- `examples/`: a valid proof of a logical theorem and a schematic BIC tree.
  The schematic matrix placeholder is *not* accepted in executing proofs.
- `results/`: actual test transcripts, syntax metrics, graph audit, and PDF QA.
- `notes/`: precise PA and compiler obligations, prior-work changes, and
  certificate-format documentation.
- `provenance/` and `STATUS.json`: input hashes, sources, and status boundaries.

## Reproduce the executable checks

Python 3.10 or newer, standard library only. Run from this directory:

```text
python -m unittest discover -s code -v
python code/graph_audit.py
python code/bic.py --metrics
python code/bic.py examples/identity.json
```

The included run passed 12 test methods. The graph run checks all 66,066
binary relations on labelled domains of size 1 through 4 and all seed subsets:
1,052,740 graph/seed pairs. These are graph tests, not finite models of QBC.
The identity example is valid and is explicitly reported as **not a refutation**.

The formula-node totals are 58 expanded / 56 double-negation-normalized for
QBC, versus 77 / 67 for the dossier's congruence-controlled QCC. Against the
more aggressive RCC, the comparison reverses after normalization: RCC has
60 / 50. None of these numbers is a Turing-machine state count.

## Rebuild the PDF

Install a TeX distribution providing `pdflatex` and the packages named in the
source. Then run:

```text
python build.py
```

This runs three passes in a temporary directory and installs the PDF only
on successful compilation. Alternatively, compile the standalone `.tex`
file directly with pdfLaTeX three times. No BibTeX step is required.

## Certification and novelty boundary

This package supplies ordinary mathematical proofs and uniform formalization
arguments. It does **not** contain a serialized PA proof, a formal verification
of the Python checker, a complete QBC certificate of the set-theory bridge,
or a new TM transition table. It does not assert that ZFC is inconsistent.
No new state bound, global minimality, or historical priority is claimed.
The equality-free variant obtained by deleting congruence remains uncalibrated
here and must not be substituted for QBC in the required equivalence.

External 254-state-machine source was inspected but its Coq development was
not rebuilt. The report separates the upstream theorem's actual axiom list
from its naming and from a PA proof obligation.

The original three uploaded reports and third-party formalization code are
not bundled again. No repository or persistent Library was modified.
