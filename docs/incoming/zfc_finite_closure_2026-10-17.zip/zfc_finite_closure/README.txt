A NINE-FUNCTION CLOSURE KERNEL FOR A ZFC CONSISTENCY MACHINE
==========================================================
Research proposal for Vladimir Reshetnikov / ProveIt, 17 October 2026.

START HERE
----------
report.pdf is the complete research report. report.tex, references.tex and
sections/*.tex rebuild it. This archive contains ordinary mathematical
proofs, exact finite theories, executable reference algorithms and machine
certificates. It contains no new Lean/Coq development and no claimed
blank-start consistency machine with fewer than 253 working states.

MAIN RESULTS
------------
FC15*: 15 universal native clauses / 35 literals; 9 proper functions,
1 constant, and 3 non-equality binary predicates. Ordinary ZFC proves
Con(FC15*) iff Con(ZFC), using the repository's raw EPSC hereditary
interpretation for the lower direction. Complete equality elimination
gives 29 clauses / 82 literals and a 1,616-bit (202-byte) template stream.

FC16*: one additional class-coded Extensionality clause; same 9 functions.
16 native clauses / 39 literals, complete 30 clauses / 86 literals.
Its 1,823-bit stream occupies 228 bytes with one final zero padding bit.
This variant has a direct ZF-without-Foundation lower derivation and
does not use the raw hereditary interpretation. Standard Foundation and
Choice relative-consistency transports remain explicitly identified.

FC17*: the conventional explicit distinguishing-member witness control,
kept for comparison. Both separate-D and derived-member versions are
included. The primary recommendation is FC15* for smallest input, with
FC16* as the direct-calibration control.

The new machine composition retains 253 working states. It combines two
previously attributed changes, with a fresh invariant establishing the
composition. It reaches the exact same complete bootstrap frame in 312855
moves, saving 120 moves from public253 and zero working states.

All 31878 unordered state pairs were considered on each of public253 and
composed253 for arbitrary two-row fusion, with 1012 actions per row.
The formal family has 32647662432 recipes per input. Sound partial
evaluation exhausted the stated radius-six / 64-move local certificate
criterion and found zero certificates. This is not a state lower bound.

QUICK REPRODUCTION
------------------
Python 3.10+ and its standard library suffice for the short checks.
From the archive root:

    python3 code/verify_release.py

This regenerates streams in a temporary directory and compares their exact
bytes, runs independent finite checks, tests the outer reference loops,
checks all three countermodels, validates the finite shortcut invariant
and executes all three complete bootstraps. It writes
data/release_validation.json. It does not rerun optional large searches.

Regenerate the finite inputs:

    python3 code/ground_kernel.py --generate data
    python3 code/coded_extensional.py --output data
    python3 code/baseline_metrics.py --output data

Individual finite demonstrations:

    python3 code/ground_kernel.py --stage 2 --derived-member
    python3 code/refute.py --max-stage 2
    python3 code/refute.py --theory fc16 --max-stage 1
    python3 code/refute.py --theory fc17 --max-stage 1
    python3 code/check_countermodels.py --output data/countermodel_results.json

The unbounded mathematical recognizer is:

    python3 code/refute.py

With unbounded mathematical integers/memory, this halts on a finite
refutation exactly when FC15* is inconsistent. The optional --max-stage
exit, any host exception or resource failure, and the exit of a single
--stage invocation are NOT the halting event in that theorem. Running
the unbounded mode on a finite host is not a practical consistency test.

Rebuild the PDF:

    latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

The preamble lists conventional TeX packages (amsmath, amsthm, mathtools,
booktabs, enumitem, listings, microtype, xurl, fancyhdr, hyperref, lmodern).
No network or shell-escape operation is needed to build the report.

MACHINE EXPERIMENTS
-------------------
machine/README.txt gives the complete source pins, exact invariant proof,
literal row changes and optional search commands. The independent quick
check, from the archive root, is:

    python3 machine/check_composition_certificate.py \
        machine/inputs/public253.tm machine/inputs/faster253.tm --dir machine

The stronger search also needs a C++17 compiler. Source and complete
per-pair ledgers are included; the large intermediate window inputs and
compiled executables are reproducible and omitted.

FILE MAP
--------
report.tex, sections/, references.tex
    Complete LaTeX sources. report.pdf is their rendered deliverable.
code/ground_kernel.py
    Native clauses, full equality completion, arithmetic ground codes,
    template encoding/decoding, exact finite SAT solver and generator.
code/refute.py
    Actual unbounded stage loop; selectable fc15, fc16, fc17.
code/coded_extensional.py
    FC16* generation, independent decoder/instantiator, semantic diagnostics.
code/baseline_metrics.py
    Reconstruct the original 12-function theory and its exact comparison counts.
code/validate_kernel.py
    Deterministic finite encoding, equality, SAT and closure checks.
code/check_countermodels.py
    Independent exact models of three individually weakened FC15* theories.
code/verify_release.py
    Short release verification, with explicit scopes.
data/
    Exact generated clauses, binary/bit-text streams, measurements and results.
machine/
    Pinned input tables, composed253, invariant, independent checker,
    synthesis code, complete ledgers and result summaries.
notes/
    Detailed finite-theory, direct extensional and countermodel proofs.
PROVENANCE.txt
    Attribution, snapshot pins, proof status and third-party provenance.
SHA256SUMS
    Exact delivered-file hashes (excluding the manifest itself).

DATA NAMING AND FORMAT
----------------------
fc15_derived_member.* is the recommended complete FC15* payload.
fc16_coded_extensional.* is the complete FC16* payload.
fc15_equality_free.* is the 10-function control with a separate D symbol.
fc17_derived_member.* is the 10-function extensional control.
fc17_equality_free.* is the 11-function control with both D and X.
Files ending _native describe clauses before equality completion.
The *_native.bin streams alone are not complete equality-free search inputs.

kernel_metrics.json records the four shared FC15/FC17 variants.
fc16_coded_extensional_metrics.json records the new FC16* control.
unshared_initial_metrics.json records the initial 12-function derivation.
Each .bits file is an exact bitstring plus a text newline. The .bin file
pads on the right with zero bits only as needed for byte alignment.
Use template_bits in the corresponding metrics to remove binary padding.
The template format fixes constructor arities; its data size excludes
the decoder, ground arithmetic, search runtime and blank initialization.

SCOPE OF THE EVIDENCE
--------------------
The consistency equivalences are ordinary mathematical proofs formalizable
in ZFC, with explicitly named prior dependencies. The included programs
are not proof assistants and the finite SAT stages do not prove consistency.
No binary compilation of the new arithmetic refuter is included.

The three finite row-deletion models concern FC15* and the explicit-X
FC17* control. They must not be automatically transferred to FC16*, whose
coded Extensionality equivalence uses the Change equations being deleted.
FC16's finite semantic diagnostics are not finite models of its full core.

The composition's unbounded table-to-table theorem follows from the
invariant and positive-progress proof in the report, not merely from the
matching bootstrap. Its full consistency calibration is inherited from
the separately attributed source27 faster253 result.

No historical priority beyond the reviewed sources is claimed. Source
research is pinned through ProveIt 61e77836565f63582561f54745f633d50efd9c7d.
