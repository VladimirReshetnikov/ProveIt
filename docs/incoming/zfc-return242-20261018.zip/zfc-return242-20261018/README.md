# A 242-state ZFC consistency machine

The complete binary, single-tape machine in `machine/zfc_return242.tm` has **242 working states**, including initialization, plus one separate halt state. It starts in state 0, at head coordinate 0, on an all-zero two-way infinite tape. Every transition moves left or right.

The ordinary mathematical proof in `report.pdf` establishes an exact relative halting equivalence with ProveIt's pinned combined243 machine. Composing this with that baseline's documented ordinary calibration gives

\[
\mathrm{ZFC}\vdash\bigl(\neg\operatorname{Halt}(M_{242})\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

The new relative proof covers **every binary function tape and every head position from the shared inherited start 95**, rather than only blank input. It uses a short old-side invariant, two complete-tape block identities, and a positive-block induction. No consistency premise is needed for the equivalence. This archive does not supply a new Lean/Rocq consistency endpoint or a completed internal PA calibration.

## Exact change

All labels below are inherited labels. Delete state 15, and change only these two retained rows:

| State/read | Old action | New action |
|---|---|---|
| 11/0 | `0 R 15` | `0 R 27` |
| 27/1 | `1 R 39` | `1 R 22` |

The removed rows are `15 0 0 R 21` and `15 1 1 R 22`. Every other retained row is unchanged.

The old machine cannot read 1 in state 27: entries into states 18, 47, and 65 leave a zero to the left, and their entries into 27 move onto that zero. The freed branch performs state 15's read-one action. For a read-zero call, the existing route `27 -> 32 -> 45 -> 21` reproduces state 15's action with two additional transitions. Its calling context supplies both required zeros. The endpoint state, head, and entire tape agree.

## Files

| Path | Meaning |
|---|---|
| `report.pdf` | Complete research report, proof, verification record, alternative routes, and printed transition table. |
| `report.tex` and included `.tex` sections | LaTeX source and included sections. |
| `machine/zfc_return242.tm` | Canonical table: working states 0–241, start 0, dispatcher 86, halt 242. |
| `machine/zfc_return242_old.tm` | Same table in inherited labels: start 95, dispatcher 96, halt 254. |
| `machine/renumbering.json` | Exact bijection, verified in both directions. |
| `evidence/combined243-to-return242.diff` | Literal inherited-label patch for review. |
| `machine/sites_logical.json`, `sites_physical.json` | Unchanged combined243 source instruction lists. |
| `code/` | Offline reconstruction, proof-premise audit, sparse/dense execution, and expanded replay. |
| `evidence/` | Actual execution records with hashes and explicit scopes. |
| `reference/combined243/` and other proof folders | Exact pinned predecessor tables, ordinary proofs, and proof-status documents. |
| `reference/runtime/` | Unchanged inherited inputs required by the expanded symbolic checker, with notices. |
| `research/` | Search data and optional source/theory investigations, with their separate limitations. |

## Reproduce

Use Python 3.12 with assertions enabled. No third-party Python packages or network access are needed. From this directory, choose a fresh output directory outside the archive:

```sh
python3 -I -B code/verify_all.py --output /tmp/return242-quick
```

For the expanded universal runtime replay as well:

```sh
python3 -I -B code/verify_all.py --expanded --output /tmp/return242-expanded
```

The latter replay took about 377 seconds in the recorded environment. Actual duration depends on the computer. Each subprocess's output and exit status are preserved. The source files are hashed before and after execution. No proof compiler or dependency installer is invoked.

To compile the report:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

## Actual results

| Check | Result |
|---|---:|
| Working states / binary rows | 242 / 484 |
| Changed retained rows / deleted states | 2 / 1 |
| Ordinary rows checked in relative proof | 482 |
| Exceptional whole-tape block cases | 2 |
| Exact blank prefix | 407,979 transitions |
| Blank endpoint | 351 one-cells, all other cells zero |
| Finite instruction fixtures | 8,390 passed |
| Total literal fixture transitions | 6,473,406 |
| Expanded universal instruction cases | 8,390 passed |
| Expanded symbolic rules | 2,314,880 |
| Covered new transition rows | 484 of 484 |

Both sparse and dense interpreters checked both state numberings. The blank endpoint is the exact inherited frame with head −5, marker −6, header 176, logical registers `(3,0,0,0,3,0,0,0,0)`, and 167 spare blocks of value one. The first visit to the dispatcher is not mistaken for completed initialization.

The exact running-time relation at paired checkpoints is `t_new = t_old + 2*k`, where `k` counts the longer local blocks. Thus any halting time increases by at most a factor of two. The new route visits no new head position within its replaced block.

## Identities and provenance

Canonical table SHA-256:

```text
64ddeb2c01c3e9c7feffaffaad87266a270716c9307892a0445bf869b988984d
```

Inherited table SHA-256:

```text
6b700aa713418cfe347a6ff2d0a92de7c31810d1cf69814b4684c7fb463876a0
```

Pinned baseline: [ProveIt e58338db7545909907e07a7603e8eb88625c527a](https://github.com/VladimirReshetnikov/ProveIt/tree/e58338db7545909907e07a7603e8eb88625c527a), path `Computability/BusyBeaver/Research/ZFC/candidate-combined243`. Upstream verification snapshot: [jeff87654/busy-beaver c132d7eae8158cd3a9850ea3eb7251158c3dd821](https://github.com/jeff87654/busy-beaver/tree/c132d7eae8158cd3a9850ea3eb7251158c3dd821/ZF/m254).

The original compact machine and calculus are credited to Mira-Cult; upstream Rocq verification to Jeff Ketchersid; the compiler framework to Andrew James Wade. ProveIt's earlier initialization, routing, QT rotation, and compensated fold remain inherited work. The new contribution here is the state-15 borrowing transformation and its proof/audits, together with the explicitly identified optional research results. Inherited licenses and notices are retained. New material may be incorporated under the project's MIT No Attribution terms.

No unconditional nonhalting, absolute consistency, minimality, or two-sided independence from bare consistency is claimed. The pinned combined243 ordinary calibration is an explicit dependency. The main table and source were not modified to include the optional semantic extensions.
