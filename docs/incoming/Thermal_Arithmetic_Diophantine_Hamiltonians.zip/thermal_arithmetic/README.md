# Thermal Arithmetic

**Diophantine Witnesses, Effective Excited Spectra, and Undecidable Confinement Boundaries**

Research report prepared for Vladimir Reshetnikov, October 2, 2026.

Start with `article.pdf`; its complete, self-contained LaTeX source is `article.tex`.

## Main construction

For the quadratic residuals of a natural arithmetic circuit, set

    Q(n) = sum_j f_j(n)^2
    H(n) = (1 + sum_i n_i) Q(n).

The circuit includes one marker equation a = 1. Its natural zero tuples project
bijectively onto the roots of the original polynomial. A source circuit with k
witness inputs and g materialized gates gives m = k + g + 1 occupation modes,
r = g + 2 equations, joint polynomial degree at most five, and r(m + 1)
displayed positive terms supported on at most four modes.

Every positive energy obeys H(n) >= 1 + sum(n). The report derives explicit
positive-spectrum cutoffs, effective compact and trace-class remainders,
finite-fold/compact-family equivalences, an unconditional padded compactness
undecidability theorem, an analytic-radius promise gap, and a uniformly
computable critical fugacity with an undecidable exact endpoint.

## Reproduce the checks

Python 3.10 or newer is required. The exact compiler and interval routines use
only the standard library. The verification suite additionally uses SymPy:

```sh
python -m pip install -r requirements.txt
python verify.py
```

The delivered run used Python 3.13.5 and SymPy 1.14.0. It passed **7,936
assertions**. Running the suite regenerates `verification.json` and
`examples.json` in this directory. `verification_console.txt` is the captured
console summary. All important numerical outputs are stored as rational
endpoints; decimal midpoints are for convenience only.

The checks include full small supplied-tuple enumeration (including invalid
gate assignments), canonical witness tests, independent symbolic polynomial
expansion, support and degree checks, exact positive-energy multiplicities,
Pell recurrences, and rational partition/critical-fugacity enclosures.

## Compile a polynomial

Sparse exponent tuples list the **parameters first, then source witnesses**.
Coefficients must be exact Python integers, and exponents nonnegative integers.
Boolean and floating-point substitutes for integers are rejected.

```python
from compiler import compile_polynomial

# P(p; x, y) = xy - p
model = compile_polynomial(
    {(0, 1, 1): 1, (1, 0, 0): -1},
    inputs=2,
    parameters=1,
)
n = model.canonical((2, 3), (6,))
assert n == (2, 3, 6, 1)
assert model.energy(n, (6,)) == 0
print(model.export())
```

Compiled mode order is source witnesses, topologically ordered gate outputs,
and the marker. `penalty` returns Q, and `energy` returns H. A unique gate
completion does **not** remove multiplicity already present among source roots.

## Certified thermal evaluation

```python
from fractions import Fraction as F
from compiler import partition_interval, critical_fugacity

def energy(n):
    x, a = n
    return (1 + x + a) * ((x - 3)**2 + (a - 1)**2)

iv = partition_interval(
    energy, modes=2, q=F(1, 24), t=F(1, 2), tolerance=F(1, 10**6)
)
print(iv.lower, iv.upper)

# This example has exactly one zero (3, 1), so G(t) = t^4.
a, b, calls = critical_fugacity(
    energy, modes=2, tolerance=F(1, 2**30), ground_series=lambda t: t**4
)
print(a, b, calls)
```

`partition_interval` assumes that the supplied energy function returns exact
nonnegative integers and that H(n)>0 implies H(n)>=1+sum(n). It checks these
conditions on visited tuples but cannot establish them globally from a finite
sample. A compiled model satisfies them by the article's theorem.

`excited_only=True` omits zero states and permits t=1. A full unconfined trace
at t=1 is intentionally not accepted as an effective general input.

For `critical_fugacity`, the occupation vacuum must have positive energy. The
optional `ground_series` argument is an **independently justified exact
formula**, not inferred by the program. Leaving it out invokes the general
full-partition algorithm. The general routine is checked against the
accelerated route at modest precision in the verification suite.

Both routines enforce a configurable `max_points` resource limit, defaulting
to 2,000,000 box tuples. Exceeding it raises `RuntimeError`; no incomplete
result is reported as a certificate. Close to t=1, the unaccelerated full
partition algorithm can be expensive. Mathematical computability is not a
claim that the default finite resource budget suffices for every request.

## Build the PDF

A conventional TeX Live installation with the packages used in the preamble
is sufficient. Run:

```sh
sh build.sh
```

The script builds the PDF three times to stabilize references and the table
of contents. No font files are distributed in this package.

## Scope and limitations

This is a proof-focused research report with finite and symbolic executable
checks, not a Lean/Rocq formalization. Historical priority of the proposed
normal-form and boundary results is not established. Classical MRDP
representability and the squared number-operator embedding are attributed in
the article. No numerical universal polynomial is hard-coded or counted.

The report does not resolve finite-fold/single-fold representation conjectures,
does not lower ProveIt's reported 87-operation universal bound, and does not
propose a physical algorithm for the halting problem. The diagonal substrate
is universal for **static representation predicates**, not an autonomous
step-by-step universal quantum evolution.

Four-mode support is not geometric locality, bounded operator norm, or finite
local dimension. Stability under small bounded operator perturbations does
not imply stability under small coefficient errors in unbounded polynomials.

The critical fugacity is a uniformly computable real. Its exact equality to
the boundary value is the undecidable predicate; the real itself must not be
misdescribed as noncomputable.

See `PROVENANCE.md` and the article's dependency ledger for source and claim
boundaries. Ten concrete further-research directions are developed in the
article.
