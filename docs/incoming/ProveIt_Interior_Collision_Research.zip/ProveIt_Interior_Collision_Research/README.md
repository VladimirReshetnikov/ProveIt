# Interior Root Collisions in Catalan Hankel Determinants

**Convergent sector expansions, multiple clusters, and phase-dependent zero motion**

Prepared for Vladimir Reshetnikov, 29 September 2026.

## Main result

The article answers the nonendpoint, reciprocal-size moving-root question in
ProveIt's Catalan-Hankel report and in the later *Two-Endpoint Confluence*
continuation. For fixed total degree d and nonendpoint spectral base w, with
nu = N + d/2 and c_i = 2 + 2 cosh(w + u_i/nu), it proves the exact expansion

    H_N(prod_i(x-c_i))
      = (-1)^(N d) sum_{k=0}^d exp((2k-d) nu w)
          nu^(k(d-k)) F_k(1/nu; u, w).

The amplitudes have convergent inverse-size Taylor series, uniformly on compact
coordinate sets including every root collision. The article gives every leading
amplitude, the complete first correction, an all-orders construction, an explicit
Cauchy remainder, and a multiple-separated-cluster extension.

For two equal-multiplicity interior roots, the leading profile is a classical
oscillatory Jacobi Hankel determinant. The first correction retains a sine phase.
At a simple profile zero, the finite-size root has a genuinely convergent expansion
with Laurent-polynomial coefficients in exp(2 i nu theta). The degree-two example
exhibits periodic and quasiperiodic scaled root motion.

## Files

- `article.pdf`: complete article, proofs, comparison, examples, research agenda.
- `article.tex`: self-contained LaTeX source; bibliography included, no BibTeX needed.
- `code/verify.py`: exact and high-precision verification/reference implementation.
- `data/verification.json`: recorded run, assertion counts, and numerical errors.
- `data/finite_size_corrections.csv`: leading versus first-corrected errors.
- `data/zero_transport.csv`: computed finite-size root displacements.
- `data/jacobi_parity_audit.csv`: classical large-frequency profile checks.
- `data/multiple_clusters.csv`: separated-cluster leading-term experiment.
- `PROOF_STATUS.md`: proved statements, imported mathematics, and limitations.
- `SOURCES.md`: exact repository scope and bounded literature audit.
- `requirements.txt`, `Makefile`: reproduction.
- `SHA256SUMS.txt`: SHA-256 hashes of all other package files.

## Reproduce

Python 3.10 or later and mpmath 1.3.0 are sufficient for the verification script.
The recorded run used Python 3.13.5 and 100 decimal digits.

    python -m pip install -r requirements.txt
    python code/verify.py --out data

The script reports 518 passing assertions: 392 exact-arithmetic and 126 numerical.
It also writes the illustrative CSV datasets. Their values are computed, not
certified interval enclosures. The numerical first-derivative audit intentionally
uses a finite difference, so its error differs from the other high-precision tests.

Build the PDF with a TeX Live installation containing newtx, amsmath/amsthm,
mathtools, tcolorbox, geometry, microtype, fancyhdr, titlesec, tocloft, xurl, and
hyperref:

    make pdf

Or run `pdflatex -interaction=nonstopmode -halt-on-error article.tex` three times.
`make verify` reruns the checks; `make clean` removes LaTeX auxiliary files.
Rebuilding or rerunning changes file hashes, so regenerate SHA256SUMS when needed.

## Status and attribution

AI-assisted and unrefereed. Universal statements rest on the written proofs,
not on the finite tests. No Lean/Rocq formalization or interval certificate is
provided. Classical Christoffel identities, characteristic-polynomial kernel
formulas, sine-kernel limits, and the oscillatory Jacobi/kissing-polynomial family
are credited, not claimed as newly discovered. The contribution is the explicit
repository continuation and finite-size zero-transport package; exhaustive
worldwide novelty is not established. See PROOF_STATUS.md and SOURCES.md.
