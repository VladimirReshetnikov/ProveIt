# A native closure rule for small ZFC consistency machines

Research report prepared for Vladimir Reshetnikov, 16 October 2026.

## Start here

Read **report.pdf**. It gives the current repository audit, the proposed unary
protected-witness rule, its EPSC presentation-equivalence proof, the inherited
EPSC/PSC and hereditary-saturation calibration, a complete de Bruijn Hilbert
frontend, precise code/proof encoding, alternative theories, and the remaining
compiler obligations.

The central new interface accepts a globally proved formula

    forall x exists b forall y (beta(x,b,y;p) -> y subset b)

and produces the empty-input closure hull for

    rho(x,y;p) = forall b beta(x,b,y;p).

The matrix may depend arbitrarily on b. Universal protection makes the rule
sound without a witness-freshness check. It preserves the full EPSC theorem
set, even if every bound premise must have a pure first-order logical proof.

This is a **research proposal with an implemented reference search**. It is
not a new binary transition table, a claimed state record, or a proof-assistant
formalization. The included proofs support the ZFC-level arithmetic endpoint
for ideal execution. A literal small machine still needs its complete
compiler and blank-initializer proof.

## Repository scope

The audit is pinned to ProveIt commit
`c1f2cc90c15fbdcd5f3ddfd7fcbb0b635c93c650` (2026-10-16 20:22:31 UTC).
It includes the requested `6d8bc7f1ba02c83e54757366f019f61b966ed0b7` and
`63c83cf79986f8a92bb75460848a1d4f863b7b15`, the subsequent retirement of
the reduced raw C/G calculus, batch 146, and the late incoming archive.
Full source links are in the report and `data/repository_provenance.json`.

Prior EPSC/PSC equivalence belongs to source 14. The prior equality-free
PSC-only saturation interpretation belongs to source 08. The finite-sort
obstruction belongs to source 12. The 253-state benchmark is attributed to
mira-emmy/Mira-Cult/Jeff, with its inspected upstream scope preserved. None
of those results is claimed as a new theorem of this report.

## Reproduce

Requirements for the checks: **Python 3.10 or later**, standard library only.
Assertions must be enabled; do not use `python -O`.

From this directory:

```sh
python3 reproduce.py
```

This reruns all finite diagnostics and regenerates both 76-line positive
certificates. It does **not** launch the unbounded refutation search. Generated
result JSON is deterministic; execution time is printed separately.

To check only the primary certificate:

```sh
python3 code/rule_search.py data/empty_closure_certificate.json
```

Expected output includes `accepted: true`, `lines: 76`, `refutation: false`.
This certificate proves an empty-hull theorem with a purely logical
boundedness premise. It demonstrates a real closure step and is not a
contradiction certificate.

For the two-argument rule control:

```sh
python3 code/rule_search.py data/empty_basic_closure_certificate.json
```

To rebuild the PDF, install a conventional LaTeX distribution with `latexmk`,
`pdflatex`, AMS packages, Latin Modern, geometry, microtype, booktabs,
longtable, array, xcolor, enumitem, fancyhdr, url/xurl and hyperref. Then use:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

Alternatively, `python3 reproduce.py --pdf` performs both checks and build.
No BibTeX run is needed: the bibliography is included as TeX. No network or
repository access is required for either operation once dependencies exist.

## File map

| File | Purpose |
|---|---|
| `report.tex`, `sections/*.tex` | Complete editable report and bibliography |
| `report.pdf` | Compiled report |
| `code/debruijn_kernel.py` | Complete logical kernel, bijective numeric codec and shared index edit |
| `code/rule_search.py` | Fixed primary unary-rule search; basic-rule and open-axiom controls; strict DAG checker |
| `code/make_empty_certificate.py` | Offline pure logical proof producer; removes all temporary hypotheses before export |
| `code/check_debruijn_kernel.py` | Codec, edit, quantifier, falsity and numeric proof diagnostics |
| `code/check_wrapper_transport.py` | Independent basic EPSC matrix maps and quantified semantics |
| `code/check_protected_rule.py` | Independent protected-witness numeric/semantic transport checks |
| `code/closure_rule_checks.py` | Wrapper counts, finite closure comparisons, deletion and parameter-guard controls |
| `code/protected_rule_checks.py` | Independent exhaustive small-domain protected-bound theorem checks |
| `code/check_integration.py` | Production/control agreement, actual certificates, parser and malformed-proof rejection |
| `data/*.json` | Reproducible results, certificates and pinned source provenance |
| `reproduce.py` | Runs finite diagnostics and optionally builds the PDF |
| `MANIFEST.sha256` | Integrity manifest for the delivered archive contents |

## Implementation conventions

Formula code zero is genuine falsity. Every positive code has exactly one
constructor interpretation:

    Rel(i,j) = 1 + 3*pair(i,j)
    Imp(a,b) = 2 + 3*pair(a,b)
    All(a)   = 3 + 3*a

There are no formula aliases or junk values. Truth `Imp(0,0)` has code 2.
Invalid proofs use `None`, not formula zero.

Each presentation has eight proof productions. In primary `protected` mode
the eighth is `8*p+7`, with only a prior proof code as payload. Basic `rule`
mode uses `8*pair(rho,p)+7`. Comparator `axiom` mode uses `8*rho+7`. These
modes are explicitly separated; the primary search has no external axiom
emitter or user-provided theory data.

All accepted open formulas are global theorems under every assignment.
The checker has no hypothesis production. Its shared reference implementation
records purity metadata for optional comparison; a primary compiler may
erase metadata that the ordinary mode does not inspect.

The mathematical algorithm uses unbounded natural numbers and memory.
Python exceptions, recursion limits, resource exhaustion and interruptions
are not accepting halts. The exhaustive numeric search is a specification
for compilation, not a practical attempt to settle ZFC consistency.

## Verification boundary

The report distinguishes ordinary proofs, finite executable diagnostics,
existing repository formal facts, attributed upstream builds, and the missing
literal-machine endpoint. No new Lean or Rocq build is claimed. No finite
nonhalting prefix is evidence of consistency. The primary positive certificate
does not refute any theory.

All code and report text in this package were prepared for this research.
No upstream binary machine table or third-party source archive is redistributed.
Mathematical predecessors and literature are credited in the report.
