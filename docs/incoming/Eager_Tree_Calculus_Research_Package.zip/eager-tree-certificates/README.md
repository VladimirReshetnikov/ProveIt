# Eager Tree Calculus: exact proof-DAG certificates

A self-contained mathematical report and reproducible code/data release, prepared 2 October 2026.

## Read first

- `eager-tree-certificates.pdf`: complete report with proofs, examples, exact arithmetic ledgers, a literal universal tree, canonical unique-fiber certificates, binary sharing compression, and exact DAG growth
- `eager-tree-certificates.tex`: standalone LaTeX source, including both complete constructor tables
- `code/`: standard-library generators/checkers, two literal fixed programs, full small scalar certificate fixtures, finite symbolic proofs, and machine-readable receipts

The original Tree Calculus semantics is pinned to Barry Jay's commit `baa877d916eb640280ed2df7ef4385ecd5957d19`. Later dialects are not substituted for it. No upstream program is imported or executed.

## Principal statements

For externally fixed N >= 1, the base quartic has 3N^2 + 19N natural witnesses and 23N + 3 quadratic residuals. It accepts exactly computations with at most N distinct reachable application pairs. All pointer lookups and well-foundedness constraints are charged.

The canonical variant has an empty or singleton natural witness fiber at exact size N. For N >= 2 it has 3N^2 + 22N - 3 witnesses, 31N residuals, and 33N^2 + 168N - 11 arithmetic gates. At N = 1 the respective counts are 23, 32, and 195. This is a size-indexed family, not a fixed-arity single-fold Diophantine representation.

A termination-preserving and termination-reflecting strict compiler gives a fixed universal tree U with 175 constructor-DAG nodes (949 unshared constructors). Its scalar code has between 44,926,990,249 and 44,960,544,677 bits and has not been expanded. A charged 175-equation circuit fixes it exactly.

A different literal 108-node fixed program R has unary inputs with n-bit codes, exact unfolded cost H_n = 562*2^n - 468, and canonical DAG sizes D_0 = 44, D_1 = 179, D_n = 64n + 113 for every n >= 2. Its complete natural witnesses have O(n^2) bits, with an enormous fixed constant explicitly retained. R's scalar code has between 1,390,419,544,301 and 4,688,954,427,625 bits. Structural replay does not materialize it or evaluate a giant scalar polynomial zero.

## Reproduce

Use Python 3.10 or newer. Ordinary checking requires only the standard library:

    python3 verify_manifest.py
    python3 reproduce.py

The optional expanded symbolic degree checks require SymPy:

    python3 -m pip install -r requirements-optional.txt
    python3 reproduce.py --symbolic

The supplied mathematical proof does not depend on bounded testing or the optional symbolic expansion. Ordinary replay regenerates receipts and fixtures next to the scripts, and writes execution logs into `replay-output/`. Optional symbolic replay adds N = 1, 2, 3 exact polynomial-degree checks and independent canonical-overlay tests.

To rebuild the PDF, install a normal TeX Live distribution with LaTeX, AMS packages, Latin Modern, geometry, microtype, fancyhdr, listings, booktabs, longtable, hyperref and bookmark, then run:

    python3 build_pdf.py

The build helper supports minimally indexed Linux TeX Live installations by creating a local format/font-map cache in `build/`. It requires no network access and installs no software. On a standard TeX installation, the standalone `.tex` can also be compiled with latexmk.

## Evidence and limitations

The report gives ordinary mathematical proofs, not proof-assistant certification. The kernel fixtures include full exact natural coordinates, including an identity zero and a cyclic counterfeit rejected with SOS value 81. Independent evaluators and residual expanders check the core and compiler. A complete finite symbolic proof plus induction establishes the fixed-R recurrence and bit bounds. Two independently written finite equality classifiers establish its exact all-n canonical DAG count; direct whole-call-set checks are supplementary.

The padded base family has nonunique fibers. The canonical variant is unique only over natural witnesses and at the exact DAG size. A small constructor DAG is not a small scalar integer. Unit-cost arithmetic gate counts are not bit-operation bounds. Input compilation, raw-integer loading and unbounded sequence packing are separate charged obligations; no fixed-arity universal-polynomial record or general single-fold MRDP result is claimed.

The bundle contains no third-party paper PDFs, no external source-code dependencies, and no expanded enormous numerical constants. Primary source links appear in the report and `sources.json`.
