# Report 173 Maximum density kings on a cylinder

This standalone report concerns OEIS A137432: n² nonattacking kings on a labeled
2n × 2n horizontal cylinder. It supplies an all-fixed-order asymptotic expansion,
exact first corrections, a boundary law with rates, and rounded inverse thresholds.
The prior leading constant is credited to Václav Kotěšovec; the prior binary/height
encoding and polynomial-time counting algorithm are credited to Rintaro Matsuo.
This is an unrefereed report, not a claim of exhaustive priority or a formal proof
certificate. No external repository or OEIS entry was changed.

## Read and verify

- `Report173.pdf` is the standalone report
- `Report173.tex` is its editable LaTeX source
- `companion/` contains original reproducible programs and selected attributed data
- `generated/` contains the default results obtained while building this package
- `SHA256SUMS.json` hashes every other packaged file

From the extracted package root:

```sh
python3 -I -B verify_package.py .
python3 -B companion/run_checks.py
python3 -O -B companion/run_checks.py
```

Do not add files to the extracted package before checking the manifest. The
verifier rejects extra files, modified bytes, and symlinks. A manifest supplies
integrity checking, not a signature or outside attestation.

The default companion needs Python 3.10+ and only the standard library. It checks
all binary words through n=7, independent physical-board enumeration through n=5,
and exact rational coefficient certificates through c3. Correctness checks use
explicit exceptions and remain active under optimized Python. The large-n fixture
is selected published data; those large terms are not recomputed by the package.

## Rebuild the entire PDF and ZIP

A complete build needs Python 3.10+ and a working TeX Live installation with
pdfLaTeX, Latin Modern, AMS packages, microtype, mathtools, booktabs, hyperref,
geometry, enumitem and fancyhdr. No network access, installation, C++ compiler,
SymPy or third-party source execution is needed for the default build.

Choose output filenames that do not already exist, whose parent directory exists:

```sh
python3 -I -B build.py --output /tmp/Report173-rebuilt.zip --pdf /tmp/Report173-rebuilt.pdf
```

The script copies an explicit allowlist into a fresh temporary directory, runs
normal and optimized exact checks, evaluates Decimal residuals, checks package
invariants, and builds the PDF with shell escape disabled. It initializes a
missing TeX format locally from installed distribution files if necessary; it
does not alter global TeX settings or caches. Existing output paths are refused.
Any output from a failed run should be inspected and a fresh path chosen for retry.

The ZIP uses sorted entries, fixed timestamps, fixed permissions and no compression.
The PDF suppresses timestamps, random trailer IDs and source-path metadata. Exact
byte identity is expected for the same sources and installed Python/TeX stack;
byte identity across different TeX/font versions is not promised. Generated
verification JSON contains no elapsed times or absolute paths.

To replay from the actual release rather than the working tree, extract the ZIP
to a fresh directory, verify its manifest, run the command above there, and compare
both ZIP and PDF SHA-256 values. The released package underwent this fresh extracted
rebuild. Its exact ordinary and optimized verification results agree byte for byte.

## Optional extended and symbolic checks

See `companion/README.md` for complete details. Examples:

```sh
python3 -B companion/run_checks.py --extended
python3 -B companion/symbolic_all_orders.py --order 3
python3 -B companion/residuals.py --precision 80
```

The extended test enumerates all transfer/Gram/tree identities through n=10 and
the independent actual-board DP through n=7. The generic symbolic engine requires
SymPy and accepts any fixed positive order; order 3 is independently checked.
Runtime and expression growth can be substantial at higher orders. Exact default
coefficient certificates require no CAS. Numerical residuals are diagnostics,
not certified error bounds, fitted proofs, or finite-input inverse guarantees.

## Source and historical scope

`sources/REFERENCES.md` lists primary references and the audit boundary. The package
contains selected factual terms, not full books, papers, or Matsuo's downloaded
implementation. An earlier overlap search was not independently reproduced and is not used as
exhaustive-priority evidence. The exact checks, coefficient identities and residuals
supporting this package were independently regenerated. No exhaustive novelty claim
is made.
