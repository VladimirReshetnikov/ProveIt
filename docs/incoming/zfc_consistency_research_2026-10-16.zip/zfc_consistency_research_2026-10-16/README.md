# Small Turing machines for Con(ZFC)

Research report and reproducible artifacts, 16 October 2026, prepared for
Vladimir Reshetnikov's ProveIt project.

**No new machine smaller than 253 working states is established.** The report
distinguishes the public 253-state construction, new formal results, a certified
same-count variant, bounded negative searches, and the remaining internal ZFC
proof obligations.

## Read first

- `report/report.pdf` — complete detailed report.
- `report/report.tex` and `report/optimization_note.tex` — editable source.
- `notes/THEORY-NOTES.md` — exact new theorem, prior attribution and formal scope.
- `optimization/README.md` — search family, mathematical certificate criterion,
  positive variant, full counts and reproduction.
- `source_manifest.json` — pinned source inputs, SHA-256, attribution and CI scope.

## New contributions

1. `EnumSafeStart254.lean` gives a new checked proof of the previously known
   arbitrary-cutoff/cofinal-padding argument for the exact abstract enumerator.
   The ordinary argument was already ProveIt intake source 09.
2. `DirtyRoot254.lean` proves exact literal-DAG root equivalence after absorbing
   arbitrary initial selector and scratch registers into a virtual clean state.
   It preserves all structured exits and the exact final register file. Together
   with the existing clean bridge, this allows all six nonformula fields to be
   arbitrary. This is not a new blank-tape theorem.
3. `zfc_253_direction_rewrite.tm` changes compact131/read1 from `0 L20` to
   `0 R22`. A standalone verifier checks all 12 local windows under a recomputed
   finite reachability invariant. The variant still has 253 working states.
4. Incoming-edge synthesis performs 597,080 transition-alternative checks across
   three recorded runs and produces no complete state-deletion certificate.
   These are not 597,080 distinct whole machines or a lower-bound proof.
5. A bounded short-gap diagnostic distinguishes an affine-abstraction failure
   from a literally correct instruction, without establishing the runtime252
   candidate's blank correctness or divergence.

## Quick executable checks

Requirements: Python 3.10 or newer, standard library only. From this directory:

```sh
python3 code/quick_checks.py
```

This checks pinned source hashes, 5,096 exact dirty-prefix cases, the concrete
direction-changing variant, and nine adversarial tests. Outputs go into
`replay/quick/`. Do not run the checkers with Python `-O`.

## Fresh Lean proof build

Requirements: **Lean 4.32.0**, official compiler commit
`8c9756b28d64dab099da31a4c09229a9e6a2ef35`. No mathlib or external repository
checkout is required. The bundle includes the 16 existing source dependencies,
two new theorem modules and one statement/axiom-audit module.

```sh
python3 formal/build.py --lean /path/to/lean-4.32.0/bin/lean
```

Alternatively install/select Lean 4.32.0 and omit `--lean`. The script rebuilds
all 19 modules from source, with `LEAN_PATH` pointing only to its build directory.
The bundled original ProveIt imports are checked against `source_manifest.json`.
Use `--build-dir /some/fresh/directory` to choose another output location.

The exact theorem/axiom output is in
`formal/build/BusyBeaver/ZFC/CheckTheory254.log` after a build. Recorded output is
also in `evidence/`. The main theorems depend only on `propext`,
`Classical.choice`, and `Quot.sound`; no `sorryAx` or added axiom is used.
The statements concern the literal register DAG and the abstract enumerator.
They do not assert that the separate binary/ZFC endpoint has been completed.

## Rebuild the PDF

Requirements: pdfLaTeX with common packages (`lmodern`, `microtype`, `geometry`,
`amsmath`, `amsthm`, `mathtools`, `booktabs`, `tabularx`, `enumitem`, `titlesec`,
`fancyhdr`, `listings`, `xurl`, `hyperref`), and `latexmk`.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error -cd report/report.tex
```

Three `pdflatex` passes from `report/` also work. The included PDF is a rendered
and visually reviewed build of the supplied source.

## Replay the full search evidence

The three complete compressed ledgers retain every bounded witness. Replaying
the radius-6 ledger is faster than regenerating the entire research search:

```sh
python3 optimization/verify_edge_evidence.py machines/zfc_253.tm \
  optimization/incoming_synthesis_r6_s128.json \
  --output replay/radius6-replayed.json
```

Create `replay/` first if the quick checks have not been run. The independent
literal interpreter validates positive and negative local witnesses and full
1,012-alternative sets. It shares parsing and abstract reachability with the
search, so only the compact direction-variant verifier is fully standalone.

For full regeneration, see `optimization/README.md`. Run those commands from
`optimization/`, using `../machines/zfc_253.tm` as the input. Retained historical
timings are host-dependent. A negative certificate means failure within the
stated finite, separable criterion, not incorrectness of every rejected machine.

## Replay the short-gap diagnostic

All three pinned upstream inputs it needs are included:

```sh
python3 notes/runtime252_short_gap.py --upstream vendor/busy-beaver \
  --limit 1000000 --output replay/runtime252-short-gap.json
```

This reproduces a literal 999,186-step blank prefix and one literal instruction,
then uses the upstream design-model register-box summaries for the bounded
continuation. It is not one million literal Turing steps, a new kernel proof,
or a nonhalting result. Read `notes/runtime252_short_gap.md` for exact scope.

## Provenance and attribution

- ProveIt snapshot: `426592ce97e52d309bfb8f0132411556650b7ac1`.
- Upstream main: `297ab8df7e5de329605c3875b4934643b371a5e3`.
- Public253 PR20 head: `0d544f2a2e3c18f12278441a74b7879f31cbe856`.
- Public253 table SHA-256:
  `84a21f714017c1d491008d86e9bd19c43cc6c5c9ae99a538b4f2314387827d95`.
- New same-count variant SHA-256:
  `7c2f4cc99706e62330281385605b77001dd0c223bde399501179c055bee0e4f6`.

The public253 construction belongs to mira-emmy and builds on Mira-Cult,
Jeff Ketchersid's verification, and Andrew James Wade's framework. It is not
new work of this report. PR20 was open and unmerged at the audit cutoff.
Its successful CI log was inspected; upstream Rocq was not independently
rebuilt in this session. See `NOTICE.md` for source/licensing boundaries.

The `evidence/` logs record the original verification runs. Absolute paths in
those historical logs identify the run environment and are not reproduction
requirements. Fresh checks derive their paths from the extracted bundle.
