# Well-Orders of the Surreal Numbers and Their Lexicographic Geometry

Research report prepared for Vladimir Reshetnikov, 2 October 2026.

## Contents

- `article.pdf`: the 24-page article, including references and nine proposed research questions.
- `article.tex`: self-contained LaTeX source; the bibliography is embedded.
- `build.sh`: rebuilds the article and reruns the exact finite checks.
- `code/finite_checks.py`: standard-library Python implementation and finite checks of the main coding constructions.
- `data/finite_checks.json`: recorded results; 180,905 comparison cases passed.
- `RESEARCH_STATUS.md`: mathematical scope, assumptions, source audit, and verification limitations.
- `SHA256SUMS.txt`: checksums of the delivered files other than this checksum file itself.

## Reading guide

Sections 2–5 address the foundational question. A class well-order of the entire surreal carrier need not have type Ord. The lexicographic comparison nevertheless extends to arbitrary class well-orders by comparing their largest common **labelled** initial segment. This common prefix can itself be a proper class. The construction is elementary in GBC; it does not require abstract class-order-type comparability or ETR.

Sections 6–8 analyze the global orders. The set-like suborder fills all uniformly set-indexed cuts, has no endpoints, and contains every class linear order even inside each nonempty interval. The unrestricted order has precisely classified adjacent pairs: finite residual permutations after a common prefix. Both are predicates on classes, not ordinary classes whose members are proper classes.

Sections 9–10 give exact set-sized spectra. For an infinite initial cardinal κ, put Sκ = {surreals of birthday < κ} and μ = |Sκ| = 2^{<κ}. Let Bγ be the lexicographic order on binary sequences of length γ. The minimal-length enumeration order Wμ(Sκ) is mutually order-embeddable with:

- B(κ·κ) when κ is a singular strong-limit cardinal;
- Bμ otherwise.

The product κ·κ is **ordinal multiplication**, not cardinal multiplication. At κ = beth_ω this is an unconditional example where the minimal slice has binary coding rank strictly above κ. For the full set-sized order W(Sκ), the binary coding rank is μ⁺, while its ordinal embedding spectrum consists exactly of the ordinals below μ⁺, also in reverse.

Section 11 connects these calculations to the full-class model (Vκ, P(Vκ)) at a strongly inaccessible κ. Sections 12–14 discuss numerical well-ordered subclasses, proof-assistant architecture, universe accounting, and further research.

## Build

Requirements: Python 3.10 or newer and a TeX distribution with pdfLaTeX and the usual LaTeX mathematics packages. Packages used include `lmodern`, `microtype`, `geometry`, `amsmath`, `amssymb`, `amsthm`, `mathtools`, `mathrsfs`, `booktabs`, `longtable`, `array`, `enumitem`, `xcolor`, `fancyhdr`, `hyperref`, `cleveref`, and `listings`.

On Linux/macOS, or Windows with an appropriate shell:

```sh
bash build.sh
```

Direct commands work without the shell script:

```sh
python3 code/finite_checks.py --output data/finite_checks.json
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The build needs no network access, external bibliography processor, or image assets. PDF metadata and compression can vary between TeX distributions, so the rebuilt PDF need not be byte-identical to the supplied one. A build also creates normal temporary LaTeX files, which are not part of the delivered archive.

To rerun only the finite tests:

```sh
python3 code/finite_checks.py --output data/finite_checks.json
```

Do not use Python's `-O` switch: the program deliberately uses assertions.

## Status

The article supplies proofs, but it is AI-assisted, unrefereed research. No historical priority or solution of a previously catalogued open problem is claimed. The finite program verifies finite combinatorial instances only, not the transfinite theorems or foundational consistency. No newly compiled Lean formalization is included. The repository sources were inspected at the pinned commit, but the repository was not rebuilt. See `RESEARCH_STATUS.md` for the precise audit.
