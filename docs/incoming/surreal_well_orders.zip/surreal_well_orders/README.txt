LEXICOGRAPHIC WELL-ORDERS OF THE SURREALS
Residual Codes, Topological Transitions, and Class Reconstruction

Research article prepared for Vladimir Reshetnikov
3 October 2026

CONTENTS

surreal_well_orders.pdf       The complete 47-page article.
surreal_well_orders.tex       Standalone LaTeX source, including bibliography.
build.sh                     Rebuilds the PDF with latexmk.
verify_finite.py              Standard-library finite verification script.
verification_results.json    Reproducible results from the finite checks.
proof_review.txt              Mathematical and technical verification scope.
source_audit.txt              Repository pin, source paths, and evidence scope.

READING GUIDE

Sections 1-3 separate the possible interpretations and state the inherited
foundational tools. Sections 4-5 prove residual coding theorems. Section 6
studies topology and measurability at countable types. Sections 7-8 treat
proper-class relation tables and their scans. Section 9 reconstructs class
realizations from labelled enumeration availability. Sections 10-11 discuss
compactness and rigorous formalization. Section 12 gives the research agenda.

MAIN RESULTS

1. Infinite residual blocks.

Let X = No_{<kappa} and mu = 2^{<kappa}. The article identifies exact binary
lexicographic cube equimorphism types for finite cardinal-block decompositions
of fixed enumeration types. Smaller regular cardinals contribute their ordinal
block length. Smaller singular strong-limit cardinals contribute the ordinal
square of their cardinal per block. Any residual cardinal above kappa has an
uninflated contribution, even if it is singular.

Consequently all fixed types are classified under GCH at every infinite
cardinal cutoff. In ZFC alone, every fixed type alpha = lambda + n at every
infinite initial cutoff kappa < aleph_omega satisfies

    W_alpha(No_{<kappa}) is equimorphic with B_lambda times_lex n!.

Here lambda is a nonzero limit ordinal and n is finite. This includes the
entire fixed-type classification at No_{<omega_1} without CH. Equimorphism
means embeddings in both directions, not necessarily order isomorphism.

2. Four countable topological regimes.

For P_n = Bij(omega+n,Q), the order topology is:
    n = 0: Polish, homeomorphic to Baire space.
    n = 1: second countable and metrizable, but meagre and not Polish.
    n = 2: separable and first countable, but nonmetrizable and nonstandard
           as a Borel space.
    n >= 3: Baire with continuum many isolated points forming a dense open set;
            the closed endpoint derivative is meagre and nonmetrizable.

The map from relation tables to lexicographic enumerations is Borel exactly
for n <= 2 among these strata. The inverse map is Borel exactly for n <= 1.
At n = 2, one additional endpoint-orientation predicate restores precisely
the full standard Borel presentation. The full-product and lex topologies
themselves are incomparable.

3. Global relation-table approximation.

In GBC with a supplied global baseline, a set-sized partial table extends to
any supplied proper-class well-order type exactly when its diagonals are
consistent and the forced oriented relation is well-founded. Finite
observations approximate all linear orders; countable observations already
detect well-foundedness. No set-sized observation detects the global type or
set-likeness. The article also proves scan-dependent order-density and local
character results, including an intrinsic description of the eventual-equality
core for a canonical max-index scan.

4. Class reconstruction.

For two GBC realizations with the same sets, inclusion of admitted labelled
global enumeration families is equivalent to inclusion of their entire class
collections. Independent pair swaps suffice to encode every class. Countable
external pure orders can nevertheless both be isomorphic to Q, even when their
class theories differ. Naming the support core setwise still loses information;
fixing it pointwise recovers the realization. Definability is treated separately
from mere class existence.

BUILD

Unzip the archive, enter its surreal_well_orders directory, and run:

    sh build.sh

Dependencies: a standard TeX Live or MiKTeX installation with latexmk,
pdfLaTeX, Latin Modern, AMS mathematics, mathtools, mathrsfs, geometry,
microtype, booktabs, longtable, array, tabularx, enumitem, xcolor, fancyhdr,
xurl, hyperref, and cleveref. No external images or bibliography database
are needed. The PDF was compiled with TeX Live 2023; layout may vary slightly
with other font/package versions.

FINITE CHECKS

With Python 3.10 or later:

    python3 verify_finite.py

The script defaults to writing verification_results.json beside itself.
It checks all 59,810 partial orientations on carriers of sizes 0 through 5,
110 diagonal/opposite-direction cases, finite surreal sign codes, independent
pair swaps, and the three six-object comparisons. All checks passed.

These are finite convention checks, not proofs of the transfinite or
class-theoretic theorems. The main results have conventional written proofs
and received independent AI-assisted review. They are not claimed to have
been verified in Lean or externally peer reviewed. No historical priority
claim is made.

The ProveIt source revision is:
7ff7736ecf3a0adc8536b2d083cf819e1ba39ace
