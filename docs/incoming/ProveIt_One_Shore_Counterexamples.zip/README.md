# One shore counterexamples to matching rank ultra log concavity

The main result is an exact counterexample to matching-rank-normalized ultra-log-concavity with all activities on one shore equal to one. The other shore uses only two positive integer activity values.

## Main finite examples

- A full Hall graph H_(8,42;44,31), on 125 vertices and of matching rank 50, has activity 10000 on its 42 right-core vertices and activity 1 elsewhere. Its last Newton margin is a positive factor times −39998827. The same margin first fails at the integer activity 6028.
- H_(8,30;32,1000) has matching rank 38. Activity 3000000 on its 30 right-core vertices and 1 elsewhere gives a negative last margin. This supplies a smaller-rank example, without claiming minimality.
- The appendix gives a separate 634-vertex, rank 310 pendant-arm example whose only nonunit activity is 21. It includes an exact graph edge list, matching, vertex cover, and complete coefficient vector.

The report proves the full-Hall endpoint coefficient formulas, an exact quadratic criterion, and a sufficient general finite-parameter construction. No floating-point root estimates are used to establish a counterexample.

## Files and reproduction

- `article.pdf`: complete six-page research note
- `article.tex`, `pendant_appendix.tex`: editable LaTeX sources
- `verify_full_hall.py`: independent full feasibility sum, six Boolean matching checks, 100 parameter regressions, and all four finite full-Hall activity checks
- `full_hall_verification.json`: exact full coefficient vectors and witness data
- `gadget_verification/verify_gadget_identity.py`: 150 independent Boolean-support tests of the pendant identity
- `gadget_verification/verify_explicit_witness.py`: full rank 310 coefficient expansion and rank certificates
- `gadget_verification/exact_gadget_tails.py`: finite center-activity endpoint formula
- `gadget_verification/*.json`: exact verification outputs and graph data
- `build_local.sh`: PDF build wrapper for the research environment

All verification scripts use the Python standard library. Run:

```
python verify_full_hall.py
python gadget_verification/verify_gadget_identity.py
python gadget_verification/verify_explicit_witness.py
```

A standard TeX distribution can compile `article.tex` directly with pdfLaTeX; run twice for cross-references. The build wrapper additionally handles the local format/map configuration used when the report was produced.

## Proof status and scope

The complete written proofs and finite coefficients have received independent mathematical checks. All six PDF pages were rendered and visually inspected. The results are not formally verified in Lean or externally refereed. The report distinguishes actual matching-rank normalization from the known ambient-shore normalization. It does not claim a smallest possible one-shore counterexample or an exhaustive priority search. The examples in this report have nonunit activities.
