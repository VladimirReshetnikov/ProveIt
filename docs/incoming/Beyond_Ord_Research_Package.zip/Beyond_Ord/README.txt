BEYOND ORD
Definable Class Well-Orders, Finite-Support Arithmetic, and Definability Horizons
Research manuscript — October 2026

CONTENTS
  beyond_ord.pdf              The complete research article.
  beyond_ord.tex              Self-contained LaTeX source, including bibliography.
  build.sh                    Rebuilds the PDF with latexmk.
  code/notation_demo.py       Natural-coefficient notation demonstrator.
  code/verification.json      Reproducible finite comparison report.
  code/README.md              Syntax, examples, implementation scope, and tests.
  SOURCE_AUDIT.txt            Repository snapshot and research-source scope.
  DOCUMENT_CHECKS.json        Compilation, reference, rendering, and package checks.

MAIN CONTENT
The article distinguishes explicit class-order presentations, external ordinal
lengths over a transitive set model, and the impossibility of a uniform
same-level evaluator cofinal in all class well-orders.

It supplies proofs of:
  * Choice-free set localization and the canonical Ord initial segment.
  * Finite-support ordinal powers, power laws, exact predecessor decompositions,
    and the complete set-likeness criterion.
  * Hereditary Omega normal forms, strict finite towers, a least exponential
    fixed point, and explicit point-cut addition and multiplication.
  * The epsilon-term extension and exact external epsilon/zeta calibrations.
  * External definable spectra, carrier reduction, cardinal bounds, and
    fixed-point closure of definability horizons.
  * At an inaccessible-height V_kappa with a named enumeration G: countable
    cofinality, parameter-free cofinality, bounded-complexity domination,
    strict truth promotion, and unbounded variation of horizons with G.
  * The full-class cutoff and its relation to unrolling.

The formalization discussion covers first-order schemas, GB/GBC, ETR,
KM with Class Collection, external models, and larger type universes.
Ten research questions and a concrete proof-assistant roadmap conclude
the main text.

REBUILD
Requirements: a standard TeX Live installation with latexmk and the packages
listed in the source. The article uses Latin Modern fonts. It has no external
images, bibliography database, shell-escape requirement, or network dependency.

From this directory:
  sh build.sh

Equivalent command:
  latexmk -pdf -interaction=nonstopmode -halt-on-error beyond_ord.tex

To reproduce the finite notation checks (Python 3.10 or later, standard library):
  python3 code/notation_demo.py --examples-only
  python3 code/notation_demo.py --report code/verification.json

STATUS
The mathematical arguments are conventional written proofs with independent
review during preparation. They have not been certified in Lean, Rocq, or
another proof assistant, and no external referee review is claimed.

The source audit does not establish historical priority or a breakthrough
resolution of a recognized open problem. Established constructions, proved
structural statements, and further questions are distinguished in the article.
The general converse from class-order comparability to ETR is not proved here.

The executable demonstrator handles finite trees with natural coefficients.
Its finite tests do not prove the class-theoretic theorems. No repository
files were modified, and no ProveIt proof-assistant build was performed.

