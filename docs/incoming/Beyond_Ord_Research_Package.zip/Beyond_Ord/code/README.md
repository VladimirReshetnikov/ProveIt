# Hereditary Ω normal-form demonstrator

`notation_demo.py` is a small Python 3.10+ program demonstrating canonical
finite syntax and structural comparison for a **natural-coefficient fragment**
of the article's hereditary Ω normal forms. It uses only the standard library.

Run the examples:

```sh
python3 notation_demo.py --examples-only
```

Run all checks and regenerate the report:

```sh
python3 notation_demo.py --report verification.json
```

## Representation and supported operations

A term is an immutable tuple of pairs `(exponent_term, coefficient)`. Each
coefficient is an exact positive Python integer; the exponent terms must be
strictly decreasing. The same conditions apply recursively to every exponent.
The empty tuple represents zero. There is no second representation for a
natural constant and no silent sorting or normalization of malformed inputs.

```python
from notation_demo import (
    ZERO, ONE, OMEGA, OMEGA_TO_OMEGA,
    compare, height, is_valid, make_term, monomial,
    natural, pretty, tower_boundary, validate,
)

assert ZERO == ()
assert natural(3) == (((), 3),)
assert OMEGA == ((ONE, 1),)

x = make_term(((OMEGA, 2), (natural(3), 4), (ZERO, 3)))
print(pretty(x))                    # Ω^Ω·2 + Ω^3·4 + 3
print(compare(OMEGA, x))            # -1
print(pretty(tower_boundary(2)))    # Ω^(Ω^Ω)
```

The public `compare` function validates both inputs and returns `-1`, `0`, or
`1`. It compares exponent subtrees first, then coefficients, then list length
when one list is a proper prefix. `validate` returns the original immutable
object on success and raises `InvalidTerm` on malformed shape, nonpositive or
nonnatural coefficients, duplicate exponents, or incorrectly ordered exponents.
Mutable lists and boolean coefficients are rejected.

`monomial` builds a syntactic term. It does not implement exponentiation of
arbitrary class-order presentations. There is no addition or multiplication
API. `height` reports finite syntax height, with zero of height zero and
positive constants of height one.

The tower convention is

\[
w_0=\Omega,\qquad w_{n+1}=\Omega^{w_n}.
\]

The paper proves the predecessor-class interpretation of these boundaries in
the **full** grammar. The program constructs the finite codes for the boundaries
but does not enumerate their full predecessor classes.

## What the checks establish

The report in `verification.json` records a reproducible run with random seed
`20261004`. The checks include:

- Zero and equality, both directions of proper-prefix ordering, coefficient
  comparison after equal exponents, and leading-exponent dominance over a
  large finite tail.
- Eight tower boundaries, checked by structural comparison without evaluating
  enormous integer towers.
- Invalid outer and inner containers, wrong pair lengths, invalid coefficients,
  unordered or duplicate exponents, and a malformed nested subtree.
- Exhaustive generation of the 625 shallow terms with natural exponents
  `0, 1, 2, 3` and coefficients in `0, 1, 2, 3, 4`, where a zero coefficient
  means that the digit is absent.
- A further 384 generated terms with bounded nested exponents, followed by
  deduplication, recursive validation, and pairwise comparison across the
  complete combined sample.

The large comparison check uses an **independently implemented exact
ordinary-natural evaluator**. Every occurrence of Ω is replaced by the same
finite radix `b = 7`, and the code directly evaluates

\[
\operatorname{ev}_b\bigl((t_i,c_i)_{i<k}\bigr)
  =\sum_{i<k}b^{\operatorname{ev}_b(t_i)}c_i.
\]

The base is larger than every coefficient at every depth. The evaluator calls
neither the validator nor the structural comparator. The nested test inputs
are ordered using independently evaluated integers, so the input generator
does not use the algorithm being tested to establish exponent order. A strict
exponent cap prevents accidental construction of huge integer towers.

Under these coefficient and normal-form conditions, the ordinary finite-radix
comparison theorem gives an exact expected result for every tested pair. The
article separately supplies the mathematical comparison and localization
arguments. These finite computations are evidence about the Python
implementation; **they do not prove any class-theoretic theorem**.

## Scope and limitations

The article permits arbitrary positive **set-ordinal** coefficients. Python
integers implement only the positive natural coefficients. In particular,
the program has no code for an infinite set-ordinal constant such as ω. The
printed symbol Ω denotes the paper's formal `Ord` symbol and is not that
missing ω constant.

Consequently this restricted language is not closed under the whole ordinal
arithmetic of the article: arbitrary ordinal coefficients and arbitrary
ordinal-indexed sums can leave it. For example, the supremum of the natural
constants is the missing set-ordinal constant ω; similarly, the full grammar
allows the term `Ω·ω`, which this program cannot express. No claim about a
complete arithmetic implementation is made.

This is **not a Lean formalization** or a formalization in another proof
assistant. It does not implement proper classes, class quantifiers, a truth
predicate, general elementary transfinite recursion, or an enumeration of
all set ordinals. Python's ordinary recursion and memory limits apply.

The report's successful outcome means that the listed bounded computations
completed without disagreement. The proofs, foundational assumptions, and
research-status qualifications belong to the accompanying article.
