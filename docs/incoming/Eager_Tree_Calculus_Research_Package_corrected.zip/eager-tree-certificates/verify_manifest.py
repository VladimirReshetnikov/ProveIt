#!/usr/bin/env python3
"""Check the curated release's SHA-256 manifest before regenerating artifacts."""
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parent
count=0
for line in (ROOT/'MANIFEST.sha256').read_text().splitlines():
    digest,name=line.split('  ',1)
    path=ROOT/name
    if not path.is_file():raise SystemExit('Missing: '+name)
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    if actual!=digest:raise SystemExit('Digest mismatch: '+name)
    count+=1
print('Verified '+str(count)+' release files')
