Report209 — A shifted Bell lower bound for sparse graph moments
4 October 2026

RESULT AND LIMITS
For k >= 1, M_(2k) >= 2(B_(k+1)-B_k)-F_(2k), with equality exactly
for k=1,2,3. The report proves the coefficientwise bound, its explicit-family
interpretation, weighted version, and Bell-ratio consequence. A secondary
quantified star estimate is included with its restricted uniform range.
No matching full-moment asymptotic, full-sequence inverse theorem, priority
claim, or global open-problem status is established.

CONTENTS
Report209.tex, Report209.pdf       Report source and compiled report
verify_recurrence.py               Exact Bauer–Golinelli recurrence, k <= 16
verify_lower_bound.py              Independent exhaustive walk DFS, k <= 8;
                                  coefficient/weighted checks, k <= 16
reproduce.py                      Deterministic regeneration and ZIP builder
data/*.json                       Exact generated integer/rational check data
tables/*.tex                      Exact table fragments used by the report
SOURCES.txt                       Public source URLs and access scope
requirements.txt                  Python and TeX requirements

REPRODUCE
From this extracted Report209 directory, run:
  python3 reproduce.py --out ../run-normal
  python3 -O reproduce.py --out ../run-optimized
Each output directory must not exist and must be outside the source directory.
The source tree is read-only input. The output receipt reproduction.json records
SHA-256 hashes for each public member and the entire deterministic ZIP.
Generated data, tables, and PDF must match the bundled baselines exactly.
The package has no network dependency and uses no third-party source code.

The driver invokes both verification scripts with the same optimization flag.
No correctness guard uses Python assert. Probe intentional failure with:
  python3 reproduce.py --out ../must-not-exist --self-test-failure
  python3 -O reproduce.py --out ../must-not-exist --self-test-failure
Both must exit nonzero before creating that output directory. Both verification
scripts independently accept --self-test-failure too.

The --initialize switch is for authoring a new freeze only. It permits missing
generated baselines. Do not use it when verifying a distributed release.

DETERMINISM
The report uses fixed PDF metadata, a fixed SOURCE_DATE_EPOCH, and a ZIP with
sorted members, fixed timestamps/permissions, and no compression. Repeatability
was verified in ordinary and optimized Python modes for every archive member
and the whole ZIP. Byte identity is scoped to the same TeX/font toolchain.
Different installations may produce a valid but byte-different PDF; an exact
baseline mismatch deliberately fails rather than silently accepting it.
The Python-generated integer JSON and tables have no floating-point dependency.

The checks are finite audits. The report itself supplies the all-k proofs.
No private notes, review correspondence, or third-party full texts are included.
