# Weighted matching supports with an arbitrary two plus three core

For disjoint sets P,Q,X,Y with |P|=2 and |Q|=3, take any internal graph H⊆P×Q and the two complete exterior blocks P×Y and X×Q. Give every vertex its own nonnegative activity and count each feasible endpoint support once.

This package proves rank ultra log concavity at the actual surviving degree for all 64 internal masks and arbitrary finite exterior populations. All four Newton inequalities are strict at degree five. If H is empty or a star, an ordinary stable-monomer proof gives the stronger conclusion of real-rootedness.

## What is proved and how

- The support and moment reductions are ordinary all-population arguments
- Two exact middle-gap certificates for each of the 13 core orbits cover all 64 labeled masks
- The 26 certificates contain 915 positive rational binomial-square terms; exact subtraction gives 33,318 positive remainder terms, with every remainder nonempty
- Two independently implemented solver-free checkers reconstruct every target and remainder
- The first and last gaps are ordinary proofs; a direct empty-core last-gap identity is included
- Zero-activity degree drops use the previously approved arbitrary-weight bipartite rank-four theorem
- Empty/star-core stability uses an explicit rank-three exceptional seed, primary polarization, and a support-preserving one-vertex merge

The exterior blocks must be complete. Missing exterior edges, arbitrary directed orientations, independent edge weights and general rank-five graphs remain open here. The full core can have nonreal roots; real-rootedness is not claimed for every internal mask.

## Contents

- `article/all-two-by-three-cores.pdf` and `.tex`: combined standalone paper and editable source
- `certificates/`: all 26 exact rational identities
- `proof-notes/`: approved source snapshots for the all-mask theorem and the ordinary star/kernel results
- `reproducibility/producer/`: standard-library certificate replay and receipt
- `reproducibility/independent-middles/`: separate direct-Hall, packed-exponent reconstruction and receipt
- `reproducibility/independent-stars/`: independent symbolic, Hall, seed and gluing checks
- `audits/`: hash-bound proof reviews and integrated article approval
- `dependency/`: the complete frozen complete-core package, its release approval, and readable copies of both dependency papers
- `qa/visual-qa.json`: final every-page PDF inspection

Historical pending-status headings in source snapshots remain unchanged so their approved hashes stay intact. The later approval receipts state the final review status.

## Verification

Python 3.10 or later and SymPy 1.14.0 are required for the complete replay; tested with Python 3.12.14. The two middle-certificate checkers themselves use only the standard library. Run with assertions enabled:

    PYTHONDONTWRITEBYTECODE=1 python3 verify.py

The driver checks exact manifest coverage and hashes, safely extracts the frozen dependency, and replays all its complete-core and nested rank-four checks. It then runs temporary copies of both new certificate checkers and the star/kernel checker, compares every deterministic receipt field except timings, and verifies all 26 target and remainder hashes independently agree. No released file is overwritten.

The supplied square finder is not needed for proof replay. Numerical optimization was used only for discovery; every retained square and every residual sign is checked with exact rational arithmetic. Independent additional checks include 5,248 selected-subgraph Hall tests, 384 coefficient relabelings, 52 denominator-substitution identities, 2,304 weighted Hall cases, 216 formal gluing identities and 714 exceptional-seed triples. These checks are not population restrictions.

## Frozen dependencies

The outer dependency `complete-two-by-three-result.zip` has SHA-256 1d054c58ce0f18a1418b086a3b4663cc1fdf0b5ecc191ec515e9239f545e1aff. It contains the complete previously approved ordinary full-core theorem and, in turn, the entire earlier rank-four archive. The rank-four archive SHA-256 is 9a60d2a1ab5aa1d932cb1f02fad3e1585356df2212fee264ac56e42fbd3d8e66. Its Theorem 1.1 is the actual-degree fallback. The new release does not modify either archive.

The article cites Borcea–Brändén Proposition 2.4 for polarization, with a direct primary-source link. Its elementary seed and gluing arguments are given in full. No proof-assistant formalization, literature-wide priority claim or external publication is asserted.

Rebuild in a copy with a normal TeX Live or MiKTeX installation:

    sh build.sh

Rebuilding can change PDF metadata and hashes.
