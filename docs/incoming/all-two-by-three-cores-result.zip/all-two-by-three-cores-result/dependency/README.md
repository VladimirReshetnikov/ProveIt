# Frozen dependency chain

`complete-two-by-three-result.zip` is byte-preserved from the approved full independent-weight complete-core release.

SHA-256: 1d054c58ce0f18a1418b086a3b4663cc1fdf0b5ecc191ec515e9239f545e1aff

Inside it, `complete-two-by-three-result/dependency/matching-rank-four-package.zip` is the complete earlier arbitrary-weight bipartite rank-four release, with SHA-256 9a60d2a1ab5aa1d932cb1f02fad3e1585356df2212fee264ac56e42fbd3d8e66. Its Theorem 1.1 supplies correct actual-degree ULC after any drop below degree five.

Readable copies of both PDFs are supplied alongside the archive. The verification driver checks them against the nested released copies, then replays all complete-core and rank-four exact checks in temporary storage. Neither frozen archive is changed.
