# Lexicographic Well-Orders of the Surreals
## Non-Borel boundaries, closed universality, and safe foundations

Research manuscript prepared for Vladimir Reshetnikov, 3 October 2026.
AI-assisted, unrefereed, and not newly verified in Lean.

## Main results

For an infinite initial cardinal kappa and a label set X of that cardinality,
let P_kappa(X) be the bijections kappa -> X and I_kappa(X) the injections,
with neighborhoods specifying bounded initial segments.

* P_kappa(X) is metrizable exactly when cf(kappa) = omega.
* P_kappa(X) is completely metrizable exactly when kappa = omega.
* At uncountable countable-cofinality kappa, it is non-Borel in its complete
  injection space, even on a compact family of injections omitting at most
  one label. This answers Question 13.1 of the earlier Prefix Completions
  draft negatively in ZFC, without CH or GCH.
* When kappa exceeds the continuum, every zero-dimensional separable
  metrizable space occurs as a closed subspace of P_kappa(X). A marker
  version of the construction also preserves binary lexicographic order.
* Bounded forward images alone do not remove the non-Borel obstruction.
  Adding bounded inverse images gives a dense G_delta, completely metrizable
  subgroup inside the closed bounded-image injection space.
* At the birthday cutoff beth_omega, these conclusions concern the actual
  numerical lexicographic order topology of surreal-labelled enumerations.

The statements concern MINIMAL initial-cardinal enumeration length. They do
not assert the same classification for arbitrary ordinal lengths of the same
cardinality: successor-length prefix spaces are discrete.

The article also covers the interpretation taxonomy, raw class comparison,
set-supported codes, noncoding diagonalization, class-indexed approximation,
universe levels, a concrete formalization plan, and twelve research questions.

## Contents

- surreal_lexicographic_boundaries.tex — standalone LaTeX source
- surreal_lexicographic_boundaries.pdf — compiled article
- code/finite_checks.py — finite combinatorial regression tests
- data/finite_checks.json — recorded passing results
- RESEARCH_STATUS.md — scope, proof dependencies, and audit limitations
- build.sh — rerun tests and compile the article
- SHA256SUMS.txt — SHA-256 digests, excluding the manifest itself

## Build

A normal TeX Live installation with pdfLaTeX, latexmk, Latin Modern, amsmath,
amsthm, mathtools, booktabs, tabularx, enumitem, needspace, tcolorbox, listings,
hyperref, and xurl is sufficient. No external figures or bibliography file
are needed. Python 3.10+ with the standard library is used for checks.

From this directory:

    bash build.sh

Or separately:

    python3 code/finite_checks.py --output data/finite_checks.json
    latexmk -pdf -interaction=nonstopmode -halt-on-error \
      surreal_lexicographic_boundaries.tex

## What was and was not verified

The PDF was compiled and rendered for layout inspection. Finite checks passed
5,645,785 assertions. They test release partitions, marker order preservation,
finite common-prefix comparison, and cylinder convexity; they do not prove
transfinite, cardinal, descriptive-set-theoretic, or class-theoretic results.
The main results are supported by written proofs and explicitly identified
standard inputs. No new Lean verification or historical priority is claimed.

The repository was inspected at commit
7ff7736ecf3a0adc8536b2d083cf819e1ba39ace and was not modified.
The large merged article was not independently audited in full. The earlier
Prefix Completions question and relevant surrounding results were retrieved
from the available research draft in the user's file library.
