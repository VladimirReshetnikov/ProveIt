# Odd-order cube stability and sharp subgroup boundaries

Research manuscript prepared for Vladimir Reshetnikov and the ProveIt program,
7 October 2026.

## Main mathematical results

For a finite nonempty set A, C_k(A) counts all labelled additive k-cubes,
including degeneracies, and epsilon_k(A) = 1 - C_k(A)/|A|^(k+1).

- Optimal comparison in every abelian group:
  epsilon_2 <= epsilon_k <= (2^k-k-1) epsilon_2.
- Exact local cubic profile near an odd-order coset, for relative symmetric
  difference delta <= 1/50:
  epsilon_3 >= 4 delta - 10 delta^2 + 8 delta^3.
  Equality at positive distance is exactly deletion of a subcoset.
- Sharp boundary coefficient 2k when G/H has no nonzero two-torsion:
  C_k(H union D) <= h^(k+1) + 2k h s^k + s^(k+1),
  provided s/h <= 2(k-1)/(2(3/2)^k-3).
  In the strict range, equality is exactly an outside subcoset b+K, K <= H.
- Explicit dispersion and energy remainders, a boundary inverse theorem,
  and a quantitative nested-coset rigidity theorem.
- Exact higher-dimensional local profiles under the odd-quotient hypothesis;
  in finite odd-order groups the four-dimensional profile is
  5 delta - 10 delta^2 + 10 delta^3 - 13 delta^4 + 8 delta^5.

See the article for all hypotheses, thresholds, proofs, equality cases, and
normalization conventions. The cubic result proves Conjecture 12.1 of the earlier
`sharp_cube_stability.tex` manuscript. The odd-quotient boundary question is
resolved locally, not at every possible ratio s/h.

## Files

`article.tex` and `article.pdf` are the self-contained source and compiled paper.
`verify.py` checks exact finite cube counts, boundary inequalities, equality
classifications, determinant census, and symbolic identities.
`verify_local.py` directly counts larger cyclic examples and torsion obstructions.
`verification_results.json` and `local_verification_results.json` record the
executed checks. `SOURCE_AUDIT.md`, `PROOF_REVIEW.md`, `FORMALIZATION_PLAN.md`, and
`INTEGRATION.md` document scope and integration. `build.sh` rebuilds the receipts
and PDF; `requirements.txt` lists the tested Python dependencies.
`PDF_QA.json` records the 23-page PDF layout checks. `SHA256SUMS` covers the
distributed files other than itself.

## Reproduction

Use Python 3.10 or later and a TeX installation containing pdfLaTeX, Latin Modern,
amsthm, mathtools, microtype, hyperref, xurl, and the other standard packages named
in the preamble.

```sh
python -m pip install -r requirements.txt
sh build.sh
```

To run only the exact tests:

```sh
python verify.py
python verify_local.py
```

Both scripts were also rerun with `python -O`; their check functions remain
active and their receipts are deterministic. The exhaustive verifier intentionally
uses small groups. It is not a scalable general-purpose cube-counting tool.

## Proof status and scope

The manuscript contains written proofs; no independent referee review or Lean
verification is claimed. Finite tests are supplementary, not the general proof.
The proofs do not assume the global arithmetic-progression theorem stated in the
reviewed openai/math manuscript or successful verification of its ProveIt port.
Historical priority beyond the explicitly compared earlier manuscript is not
certified. The universal rounding mechanism, unrestricted boundary argument,
Boolean-cube census, and singleton ternary sharpness construction have antecedents
in the earlier manuscript and are attributed there.

No GitHub write, pull request, or formal-status change was performed. No upstream
source code or font binaries are bundled. Apply ProveIt's normal licensing and
review policies during integration.
