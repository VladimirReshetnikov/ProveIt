# Parity Reductions and Rational Distribution Ranks

Research continuation for Vladimir Reshetnikov's ProveIt project, prepared 9 October 2026.

The main deliverable is [article.pdf](article.pdf), with editable source in [article.tex](article.tex). It contains complete proofs, explicit identities, a precise account of what remains conjectural, and fourteen proposed research directions.

## Main results

1. The five Gaussian double-polylogarithm identities of weight six in the manuscript are proved. An explicit formula generates the reducible conjugation component for all positive indices, with a table through weight twelve.
2. The Gaussian weight-five numerical relation follows from two ordinary shuffles. The two independent shuffle rows give a stronger conclusion: at most two of the four Gaussian imaginary coordinates remain after the displayed depth-one terms are removed.
3. Four reciprocal-root candidate residuals at weights five and six have explicit depth-one evaluations. A general Fourier and partial-fraction theorem supplies those evaluations and further identities at weights seven, eight, and nine.
4. A character proof determines the rational weighted distribution presentation for every denominator: its complexification is the regular representation of the unit group. Pinning and reflection give the all-denominator Hurwitz-jet and first-Stieltjes rank laws; the parameter-derivative presentation has residual dimension phi(q)-1.
5. For nonzero integer distribution exponent, primitive residues form a rational basis. The package implements and certifies a constructive reduction to this basis.
6. The reciprocal weight-two identity Li_1,1(z,z^-1) = -Li_2(z/(z-1)) is proved separately with its branch convention.

The general polylogarithm parity mechanism and universal-distribution framework are established mathematics, attributed in the article to Panzer, Nakamura, and Kubert. The package documents advances relative to the repository snapshot; it does not claim worldwide priority for these general mechanisms.

## Important status distinctions

- A proved analytic identity is supported by the article's derivation.
- An exact formal rank is the dimension of the explicitly declared relation presentation. It is not a proof of numerical independence of the constants.
- High-precision quadrature is diagnostic, without certified interval error bounds.
- The S4 harmonic-sum reduction remains conjectural. Its equivalent missing relation and numerical evidence are included.
- The source manuscript already proves the complete odd-index family S_(2m+1); this package does not claim that family as a new discovery.
- This package is not a Lean or other proof-assistant formalization.

## Source snapshot and integration

The comparison is pinned to commit:

    0599fe867a0c7d0819b4e9f3cd92ce90a3b62b8d

in:

    VladimirReshetnikov/ProveIt
    Analysis/Polylogarithms/docs/manuscript

[integration_notes.md](integration_notes.md) maps original source labels to the new article's labels and recommends precise status updates. [provenance.json](provenance.json) records the source commit, retrieved-file hashes, literature URLs, and methods. No remote repository modifications are part of this deliverable.

## Contents

| File or directory | Purpose |
| --- | --- |
| article.tex, article.pdf | Complete standalone article and compiled PDF |
| code/gaussian_parity.py | Exact Gaussian parity formulas and weight-six checks |
| code/verify_gaussian.py | Independent Gaussian and general-angle integral checks |
| code/mixed_parity.py | Reciprocal parity coefficients and specializations |
| code/verify_mixed.py | Exact reciprocal checks and independent quadrature |
| code/verify_weight5.py | Independent word-shuffle replay and optional S4 diagnostic |
| code/verify_exact.py | Consolidated exact symbolic replay |
| code/distribution_grids.py | Exact rational ranks and primitive normal-form certificates |
| results/ | Exact formulas, rational matrices, and recorded numerical diagnostics |
| results/status_ledger.json | Validated machine-readable status and source-label mapping |
| integration_notes.md | Statement-by-statement integration guide |
| provenance.json | Source and method provenance |
| validation.json | Final build and artifact checks |
| SHA256SUMS | Package-file checksums |
| Makefile, requirements.txt | Rebuild and verification entry points |

## Build the PDF

Use a standard TeX Live installation with pdflatex and latexmk. The article uses standard mathematical, table, hyperlink, Latin Modern, and microtype packages; it has no external figures, bibliography database, or shell-escape requirement.

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

or:

    make pdf

The Python checks were run with Python 3.12.14, SymPy 1.14.0, and mpmath 1.3.0. To install the recorded Python dependencies in your own environment:

    python -m pip install -r requirements.txt

## Replay exact calculations

    make exact

This runs the consolidated symbolic checks, enumerates the weight-five word shuffles, regenerates the Gaussian table through weight twelve, and recomputes all 1,087 rational matrix ranks and eight primitive normal-form certificates. No numerical integration or internet access is used.

Individual commands:

    python code/verify_exact.py
    python code/verify_weight5.py
    python code/gaussian_parity.py --max-weight 12
    python code/distribution_grids.py

The last command also compares prime-generated and all-divisor-generated row spans on the eight certificate grids. Each reconstruction certificate includes its rational matrix and exact consistency checks.

## Replay numerical diagnostics

    make numerical

Equivalent individual commands:

    python code/verify_gaussian.py --dps 65
    python code/verify_mixed.py --dps 80
    python code/verify_weight5.py --numerical --dps 60

The archived 27 height-one integrals were originally evaluated at 90 decimal digits. To recompute the height-one family as well:

    python code/verify_mixed.py --dps 90 --rerun-height-one

This command records its new checks in mixed_verification.json; the originally archived height_one_quadrature.json is retained as a separate provenance record. Numerical commands overwrite their corresponding result files. Their diagnostic residuals can vary slightly with software versions and working precision.

## Recorded evidence

- 66 exact Gaussian component formulas through weight 12.
- All five source weight-six coefficient comparisons vanish exactly.
- Three additional displayed Gaussian identities and six edge-family cases have independent exact coefficient checks.
- Two weight-five shuffle rows, 15 labelled interleavings, and ten certificate-field comparisons.
- Sixteen exact reciprocal partial-fraction identities and ten displayed reciprocal coefficient checks.
- 23 Gaussian/general-angle quadratures at 65 digits, maximum absolute residual below 4.50e-64.
- 12 general reciprocal-index quadratures at 80 digits, maximum absolute residual below 1.54e-79.
- 27 height-one quadratures at 90 digits, maximum absolute residual below 4.94e-88; 18 Gaussian/Eisenstein projections separately compared with exact-generated expressions.
- 1,087 exact rational rank cases, all passing.
- Eight normal-form certificates, reconstructing 474 symbols, including 312 nonprimitive symbols.
- A four-integral S4 check at 60 digits, residual approximately 1.07e-61, explicitly retained as conjectural.

## Mathematical conventions

Double polylogarithms use descending nested indices:

    Li_(a,b)(x,y) = sum_(n>m>=1) x^n y^m / (n^a m^b).

Thus argument and index order must both be adjusted when using a source with increasing nested indices. The fourth root is i, the third root is rho = exp(2*pi*i/3), and C_(2r) denotes Im Li_(2r)(rho). Formal distribution matrices and all rank decisions use rational arithmetic.

The article explains convergence at first-index-one boundary values, the exact right-hand-side inventory in every grid quotient, and the primitive-conductor convention in the character proof.
