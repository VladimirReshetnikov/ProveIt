# Cube root crossover for unlabeled simplex time consistent galled trees

This revised self-contained report proves an expansion to every fixed order in the compact positive cube-root window for E(n,k), the A399421 triangle whose row sums are A397952. Its leading term is:

E(n,k) = [gamma0/(2 sqrt(pi))] R^(-n) n^(-3/2) (c n)^(2k)/(2k)! exp(-2 gamma0 k^(3/2)/sqrt(n)) [1 + O(n^(-1/3))].

More precisely, with epsilon=n^(-1/3), actual lambda=k*epsilon, and L equal to the leading carrier above, the count is L times [sum from m=0 to M of P_m(lambda)*epsilon^m + O(epsilon^(M+1))] for every fixed M. The report supplies a finite Gaussian-moment generator and

P1(lambda) = gamma0*sqrt(lambda)/4 + B*lambda^2,
B=A*(1-5R)+2R*K/A, K=U'(R^2)+2R^2 U''(R^2).

The uniformity is for actual k/n^(1/3) in each fixed compact subset of (0,infinity). Constants are defined analytically in the manuscript. Numerical values are not interval certified. No convergence of the infinite formal series or uniformity in a growing expansion order is asserted.

## Contents

- `galled_crossover.tex` and `galled_crossover.pdf`: complete fixed-order theorem and proof, finite generator, explicit P1, attribution, numerical comparisons, limited leading normalized-curve inversion, and further questions
- `code/enumerate_rows.py`: exact integer polynomial enumeration through n=160, plus source-fixture and independent gall-free-column checks
- `code/check_algebra.py`: exact symbolic checks of the quartic, both local critical branches through the used orders, pressure expansion, and crossover constant
- `code/numerics.py`: 70-digit constants and 16 finite leading-crossover comparisons, plus precision/cutoff stability checks
- `code/finite_gaussian_generator.py`: generic finite-order Gaussian and Bernoulli transfer functions; the executable check evaluates only P0 and P1 and verifies odd parity and the exact Gamma-ratio recurrence
- `code/verify_p1_symbolic.py`: exact critical-pressure, amplitude, Gaussian/Stirling, and P1-constant identities
- `code/independent_constants.py`: nested-radical constants calculated without input row coefficients; depth/precision checks and comparison with the finite-series method
- `code/exact_truncated_rows.py`: exact integer enumeration modulo u^13 through n=640, checked against the full triangle through n=160
- `code/validate_p1.py`: P1-only diagnostics using those exact integer counts, with no fitted or explicit P2 correction
- `data/reference-rows.json`: exact rows and totals previously computed by the same combinatorial specification, freshly compared on every replay
- `data/reference-truncated-rows.json`: exact reference output through n=640 and gall degree 12
- `data/oeis-numeric-fixture.json`: small explicit numerical source fixture; 49 A399421 cells and 28 A397952 terms
- `results/`: generated exact and numerical outputs, including the table input used by the TeX file
- `reproduce.sh`, `build_pdf.sh`, and `requirements.txt`: replay instructions and dependencies
- `MANIFEST.sha256`: hashes of every release file except the manifest itself

No third-party full texts or hidden inputs are required or included. The archive is self-contained once its standard software dependencies are installed. The reference rows are exact computational outputs; they are not a separate proof of the recurrence. The source fixture and independent scalar recurrence give additional cross-checks.

## Replay

Use Python 3 with mpmath and sympy, Bash, and pdfLaTeX with the packages named in the TeX preamble. This release was tested with Python 3.12.14, mpmath 1.3.0, SymPy 1.14.0, and pdfTeX from TeX Live 2025. Other compatible versions should work, but byte-identical numerical serialization or PDFs across different software stacks is not promised.

From the extracted package directory:

    sha256sum -c MANIFEST.sha256
    bash reproduce.sh

The replay performs the full-triangle and gall-truncated integer checks, symbolic P1 and finite-generator checks, two constant-evaluation methods, numerical diagnostics, and PDF rebuilding. It fails on assertion errors, TeX errors, overfull boxes, or unresolved references. It needs no network access. Build products go into `build/`. The build script also handles a TeX Live installation with missing prebuilt format/font-map files by generating local ones.

For just a PDF rebuild from the supplied table data:

    bash build_pdf.sh

The release ZIP was actually extracted using Python's zipfile module into a fresh temporary directory. Its manifest was verified, `bash reproduce.sh` was run there, and regenerated result files and PDF were compared against the release. All passed. The 18-page PDF was rendered and every page visually inspected before release.

## Prior work and source versions

The exact generating function and fixed-k formula are prior work. The cube-root scale and exponential square-root penalty are also prior phenomena. This report is a class-specific extension/refinement for the nested unlabeled simplex time-consistent galled-tree equation; it is not a claim of a first cube-root law or an exhaustive originality determination.

1. L. Agranat-Tamir, M. Fuchs, B. Gittenberger, N. A. Rosenberg, and K. V. Seetharaman, *Combinatorial comparison of general galled trees, time-consistent galled trees, and simplex time-consistent galled trees*. Inspected arXiv version: https://arxiv.org/html/2601.08062v1 (12 January 2026), especially Sections 2, 3.1, 5.4–5.5, and 7.3. Its equation (47) is the exact bivariate equation. Journal metadata: Advances in Applied Mathematics 180 (2026), 103131, https://doi.org/10.1016/j.aam.2026.103131 . The journal full text was not inspected; its equation numbering is not used interchangeably with the preprint. The OEIS fixed-k comment cites equation (49) in the published article.
2. M. Fuchs and **Hao Yu**, *A Cube-Root Phase Transition in Tree-Child Networks and the Enumeration Threshold for Galled Networks*. Inspected https://arxiv.org/html/2608.20860v1 , submitted 21 August 2026, and https://web.math.nccu.edu.tw/mfuchs/pt-and-enum-sub.pdf , dated 21 August 2026, 16 pages. Author-PDF SHA-256: `939650edac1df4224696cf1e666ed687f62beaa4545f4c17edff6c7db4b005ad`. Relevant: Proposition 1.3; Theorems 1.4 and 1.6; Lemma 2.4 (pp. 5–8); Corollary 2.6 (p. 8); Corollary 3.5. Their exact square-root kernel and nonnegative degree-k polynomial extension do not directly cover the nested equation here. Their Theorem 1.6 error is additive inside the multiplier, whereas Proposition 1.3 supplies a relative asymptotic. Hao Yu is not T.-C. Yu.
3. A399421: https://oeis.org/A399421 . Direct live retrieval was unavailable; inspected the individually retrieved OEIS-data mirror https://raw.githubusercontent.com/oeis/oeisdata/main/seq/A399/A399421.seq , revision #7, 2 September 2026 22:45:42, on 2 October 2026. The indexed entry agreed. The mirror's printed GF has malformed parentheses; the manuscript uses the mathematically well-formed paper equation. The only listed asymptotic comment fixes k.
4. A397952: https://oeis.org/A397952 , inspected on 2 October 2026; its 28 displayed terms n=0 through 27 are the numerical fixture.
5. P. Flajolet and R. Sedgewick, *Analytic Combinatorics*, Cambridge University Press, 2009, Chapters VI and VIII. Authors' site: https://ac.cs.princeton.edu/home/ .

## Scope and numerical limits

The theorem does not prove every slowly diverging k=o(n^(1/3)), a wider growing window, convergence of its infinite formal expansion, or uniformity in a growing expansion order. Only P1 is explicitly evaluated; no explicit P2 formula is included. A normalized multiplier can be inverted on compact positive lambda intervals, but no monotone floor-ray raw-count inverse or exact integer threshold rounding is claimed.

The first constant calculation evaluates finite gall-free polynomials rather than interval-enclosed analytic functions. An independent calculation uses nested radicals at depths 10 and 12 with 65 and 90 working digits. Neither method is interval arithmetic. Cutoff 120 versus 160 and 50 versus 70 working digits agree well beyond the displayed digits. That is a stability check, not a certificate for the analytic constants or finite-n remainder. Exact enumeration and floating-point asymptotics are labeled separately throughout.

## Version history

This version extends the previously released leading-crossover report in place. The prior release is preserved separately in the working archive and is not duplicated inside this reproducibility ZIP. The main additions are the arbitrary-fixed-order transfer and saddle argument, its finite coefficient generator, explicit P1, and exact gall-truncated diagnostics. The previously corrected triangular enumeration order is retained. Exploratory P2 scripts and approximate large-n fixed-k transfer calculations are excluded from this package.
