# Surreal Polytopes
## Affine Residues, Mixed-Volume Scales, and Simultaneous Segment Models

Research article prepared for Vladimir Reshetnikov, 30 September 2026.

## Contents

- `article.pdf`: the 27-page typeset article, including full proofs, examples,
  ten proposed research questions, proof dependencies, and references.
- `article.tex`: self-contained LaTeX source; bibliography and the schematic
  diagram are embedded. No external image or bibliography file is required.
- `verify.py`: standard-library-only exact finite-instance audits.
- `verification.json`: the successful default run, with exact example values.
- `PROVENANCE.md`: repository snapshot, inspected sources, and scope notes.
- `Makefile`: optional commands to typeset and run the audits.
- `SHA256SUMS`: checksums for the delivered files other than this checksum file.

## Principal results

For finite polytopes over a set-sized real closed field containing R, equipped
with its natural convex valuation, the article proves:

1. One segment can be chosen inside each polytope so that *every pure mixed-volume
   valuation* (distinct body labels) is preserved simultaneously. There is a
   successful choice in an explicit finite rational grid.
2. Pure profiles are exactly determinant-valuation configurations realizable
   over the specified field. Labelled segment clones give an exact matrix
   realization criterion for the full profile, including repetitions, and an
   arbitrary-ordered-group proof of the M-convex exchange axiom.
3. The module L(P) = span_O(P - P) has a maximum-vertex-simplex basis. It provides
   a full-dimensional canonical real affine residue even when ordinary standard
   part loses dimension.
4. Mixed-volume values depend only on these embedded modules. After basis
   selection, at most d^d determinants certify a mixed coefficient's valuation.
   All segment probes characterize the module, and a reference-basis comparison
   uses one volume value and d mixed probe values.
5. Finite-support higher-rank certificates can be specialized to one parameter
   while preserving their specified finite order data. This is not an embedding
   of the entire higher-rank ordered group into a rank-one group.

The set-sized surreal application is made explicit in the article. No claim
is made about class-sized integration or a general algorithm for arbitrary
surreal expressions.

## Reproduce the exact audits

Requires Python 3.10 or newer; no third-party packages are needed.

```sh
python3 verify.py
python3 verify.py --pairs 500 --seed 20260930 --output verification-extra.json
```

The default run includes 160 random planar pairs, 320 normalized-residue checks,
320 probe comparisons, 24 affine-covariance checks, 20 simultaneous four-body
segment models and Plucker checks, 12 six-clone models, and 396 exchange checks.
There are additional explicit and degenerate examples. All calculations use
rational sparse Laurent polynomials with lexicographic rank-two exponents.
Mixed areas are independently computed from exact convex hulls and polarization.

The generic choices in the executable audit are searched randomly within the
proved finite grids, with a fixed cap. The universal existence proof instead
justifies exhaustive enumeration of those grids. Passing finite tests does not
replace the mathematical proofs or constitute Lean verification.

## Typeset

A reasonably complete TeX Live installation with pdfLaTeX and the packages used
in `article.tex` is sufficient. The text and mathematical fonts are standard
TeX packages; no separate font files are distributed.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Without latexmk, run pdfLaTeX repeatedly until references and the contents are
stable. `make pdf` and `make verify` provide the same workflows. The supplied
PDF was compiled successfully with no LaTeX warnings and visually inspected
using Poppler rendering. Exact binary PDF reproducibility is not claimed,
since compilation metadata may vary.

## Status and intended use

This is an AI-assisted research manuscript with complete written proofs of its
stated results. Independent correctness review and an exhaustive priority search
remain outstanding. Classical polytope theory, the segment determinant formula,
valuated matroids, and Lorentzian/M-convex connections are credited explicitly.
The combined formulations should not be advertised as established historical
firsts without further literature review. The work does not claim a solution of
the complete real mixed-volume configuration problem, and supplies no new Lean
source or successful Lean build.
