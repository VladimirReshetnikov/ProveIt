# Norm-weighted distinct partitions: A022629 and beyond

Research report prepared for Vladimir Reshetnikov, October 1, 2026.

## Read first

**article.pdf** is the 20-page report. **article.tex** is its complete standalone
LaTeX source; references are embedded in a `thebibliography` environment.
No external figures or bibliography database are required.

For fixed real s > 0, the report studies the coefficients of

    F_s(q) = product_{k >= 1} (1 + k^s q^k).

It supplies a conventional proof of the logarithmic growth conjecture displayed
in OEIS A022629 (s = 1), strengthens it to every fixed inverse-logarithmic order,
and establishes an exact-saddle relative expansion to every fixed algebraic
order. Further results concern Lambert inversion, near-integer threshold
inversion, eventual strict log-concavity, and eventual hyperbolicity of Jensen
polynomials of each fixed degree. The positive integer parameters include
A022629, A092484, A265840, A265841, and A265842, columns of A292189.

The report contains five explicit inverse-logarithmic corrections, a general
finite recipe for all orders, the first two displayed universal saddle
corrections, and code computing the third from the general recipe. Ten further
research directions are discussed.

## Status and limitations

* The mathematical proofs are not independently peer reviewed or formally
  checked in Lean or Rocq. Exact computations verify finite identities and
  examples, not the analytic theorems.
* A targeted literature/repository review found no prior proof of the precise
  fixed-positive-s results reported here. This is not an exhaustive priority
  certification. The report discusses closely related 2025–2026 sources and
  explicitly states the limitations of the literature review.
* All asymptotic statements keep s > 0 fixed. Jensen degree is also fixed.
  No uniform theorem as s tends to zero, s grows with n, or degree grows with n
  is claimed.
* A finite inverse-logarithmic expansion of log a_s(n) is not a relative-error
  approximation to a_s(n). The relative theorem uses the exact saddle and
  exact cumulants. These are separate asymptotic levels.
* The near-integer inverse bound is asymptotic, not a universal rounding rule
  or a certified finite-input algorithm.
* Numerical saddle results use arbitrary precision and a conservative
  exponential cutoff, not directed-rounding interval arithmetic.
* Higher powers can converge slowly. The third-order relative error at
  s = 3, n = 2500 is about 5%; this stress test is included rather than hidden.
* No complete exponentially resolved transseries, explicit universal
  log-concavity threshold, or solution to the A022661 zero question is claimed.

## Files

- `article.pdf`, `article.tex`: report and source.
- `code/verify.py`: exact positive dynamic programming; real saddle and
  cumulant evaluation; general Edgeworth coefficients; numerical comparisons.
- `code/derive_series.py`: exact SymPy verification of the displayed
  forward and inverse logarithmic expansions.
- `code/extra_checks.py`: independent divisor recurrence, exact Jensen
  root counts, precision comparison, and a fully converged Gaussian inverse.
- `data/exact_s1.json`: exact coefficients through n = 10000.
- `data/exact_s2.json`, `data/exact_s3.json`: through n = 2500.
  Coefficients are stored as decimal strings, with the index equal to n.
- `data/exact_audit_s*.json`: all strict-log-concavity failures in the tested
  ranges and exact monotonicity checks.
- `data/saddle_s*_dps*.csv`: approximation errors, cumulants-related values,
  logarithmic approximation errors, and linearized inverse displacements.
- `data/extra_checks.json`: exact recurrence/root-count results, precision
  comparison, and the fully converged inverse experiment.
- `data/symbolic.txt`: symbolic coefficient-verification output.
- `OEIS_PROPOSED_NOTES.md`: draft notes for possible submission after review.
  Nothing has been submitted to or approved by OEIS.
- `BUILD_AND_VALIDATION.txt`: build and computational checks performed.
- `requirements.txt`: tested Python dependency versions.

## Reproduction

Python 3.10 or later is required. The supplied run used Python 3.13.5,
mpmath 1.3.0, and SymPy 1.14.0. From this directory:

```sh
python -m pip install -r requirements.txt
python code/verify.py --exact --s 1 --nmax 10000
python code/verify.py --exact --s 2 --nmax 2500
python code/verify.py --exact --s 3 --nmax 2500
python code/verify.py --s 1 --dps 40
python code/verify.py --s 1 --samples 10000 --dps 60
python code/verify.py --s 2 --samples 1000,2500 --dps 40
python code/verify.py --s 3 --samples 1000,2500 --dps 40
python code/derive_series.py
python code/extra_checks.py
```

No network access is needed after dependency installation. Data already in the
archive are sufficient to inspect the results without recomputation. Exact
coefficient generation is a quadratic dynamic program; integer sizes increase
with n and s. `--exact` replaces that parameter's exact coefficient table.
Numerical runs merge their chosen sample rows into the corresponding CSV.

Build the PDF with a TeX installation supplying the packages named at the top
of `article.tex`, including Latin Modern, amsmath, amsthm, mathtools, microtype,
booktabs, enumitem, fancyhdr, hyperref, and bookmark:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The package does not contain TeX build sidecars, page renders, cached Python
bytecode, or font files. The source repository was read but was not modified.
