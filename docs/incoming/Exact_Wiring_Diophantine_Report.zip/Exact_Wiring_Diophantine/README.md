# Exact Wiring in Diophantine Computation

**Sharp loop-parity separation and a cycle-preserving compiler for interaction combinators**  
Research report prepared for Vladimir Reshetnikov / ProveIt, 2 October 2026.

Start with `article.pdf` (28 pages). `article.tex` is self-contained apart from standard LaTeX packages. The bibliography is embedded in the TeX source.

## Main mathematical results

**Theorem 3.1: sharp one-bit separation.** For any distinct perfect matchings M and N of 2n labelled ports, a uniformly random closing matching Q gives different cyclic-wire parities with probability between 2/5 and 2/3. Both constants are sharp. The lower equality corresponds to a single alternating six-cycle in M union N, apart from common edges; the upper equality corresponds to a single four-cycle. A signed cycle-partition recurrence and a complete induction establish the result for every n.

**Section 4: information and tomography.** Any summary that preserves loop parity under every closing context must be injective on all (2n-1)!! matchings. Consequently it needs order n log n state bits. Order n log n nonadaptive one-bit probes suffice by a probabilistic construction, although an efficient decoder is not supplied. A deterministic two-edge modification gives a separating context modulo every integer r >= 2.

**Theorem 7.1: exact canonical memory.** A proposed bounded random-access history has an exact natural-number certificate with linearly many quadratic equations and unique ancillary witnesses. An explicitly computed large integer makes the product comparison collision-free; it is not a modular or randomized fingerprint.

**Theorem 9.1: bounded interaction-net compilation.** With C0 initial cells, F free ports and external horizon T, exact histories of all six interaction-combinator rules admit a quartic certificate with O(1+C0+F+T) witnesses and sparse monomials. It preserves cyclic components, pays for input validation and terminal checks, and has unique ancillary witnesses for each fixed legal schedule. Large witness heights are accounted for separately.

## Scope and verification status

The article supplies mathematical proofs. Historical priority for the exact sharp separation theorem has not been certified. Known interaction-net gluing and memory-checking frameworks are explicitly credited.

The Python package implements all six interaction rules and two gluing algorithms. It also implements the full sparse-polynomial **memory component** and exports an example quartic. The whole interaction-controller-to-polynomial exporter is not included: its construction and size bounds are proved on paper. No new Lean formalization, Lean build, independent peer review, or claim of a smallest universal polynomial is made.

The horizon is an external family index. These bounded certificates do not establish a fixed-arity history compiler, an ordinary-integer universal input loader, or single-fold MRDP. In particular, they do not improve the repository's separately reported 87-operation universal-polynomial bound.

## Replay

Python 3.10 or later is required by the source syntax. The supplied receipt was generated and replayed with **Python 3.13.5**. There are no third-party Python dependencies.

From this directory:

```sh
python3 code/verify.py
```

The default command recomputes the evidence and compares it with `results/verification.json` and the exported example. It does not modify those files. An explicit intentional regeneration is available:

```sh
python3 code/verify.py --write
```

The test suite includes 121,537 direct closing-graph evaluations, all nonidentity cycle partitions through weight 30, 23,930 splice/component comparisons over all interface-join orders, every four-delta matching on twelve ports, and exact memory-certificate checks. See Section 11 and the JSON receipt for the precise scopes; finite checks are not substitutes for the proofs.

The memory generator uses bounded decimal chunks to export huge natural witnesses without disabling Python's global integer-string safety limit. Its coefficients and example values are exact integers, never floating-point approximations.

## Rebuild the PDF

With a LaTeX distribution containing the packages named in `article.tex`:

```sh
make paper
```

Alternatively run the following command **three times**, so the two-page table of contents and its page references stabilize:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

`make test` runs the finite checks. `make clean` removes LaTeX auxiliary files and Python bytecode, not the PDF or saved results.

## Files

- `article.tex`, `article.pdf`: complete research article, proofs, research agenda, and bibliography.
- `code/wiring.py`: exact net evaluator, independent component gluing, and modular separating contexts.
- `code/parity.py`: partition recurrence and representative pairs of matchings.
- `code/diophantine_memory.py`: quadratic compiler, canonical example witnesses, and quartic expansion.
- `code/verify.py`: reproducible tests and receipt checking.
- `results/verification.json`: detailed counts, traces, and exact source hashes.
- `results/example_memory_certificate.json`: 21 parameters, 167 natural witnesses, 144 residuals, and a 2,496-monomial quartic.
- `results/build_receipt.json`: final PDF/source hashes and build/render checks.
- `SOURCES.md`: pinned repository and primary-literature provenance.

Third-party articles and font files are not redistributed. The repository itself was not modified.
