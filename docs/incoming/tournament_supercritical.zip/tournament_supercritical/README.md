# Beyond Criticality
## Pole–Branch Expansions and Tempered-Stable Crossovers for Tournament Score Sequences

**Research manuscript — 4 October 2026.** Prepared with AI assistance; unrefereed and not formally verified.

The article continues the supercritical question explicitly left open in the ProveIt report on tournament score sequences (Part I question 2 / Part II RQ6). Its OEIS objects are A000571 (all score sequences), A351822 (strong score sequences, with the empty object omitted from the block generating function), and A145855 (the exact auxiliary divisor count).

### Main results

- **Theorem 4.1:** an exact moving-pole contribution plus a branch expansion to every fixed order, uniformly from the critical weight through a fixed small supercritical interval; explicit first two kernels and a finite coefficient generator for all further orders.
- **Theorems 7.2–7.3:** a tempered 3/2-stable block-count window at `t*n^(2/3) = O(1)`, including a compact-frequency `O(n^(-1/3))` estimate, followed by a Gaussian regime when `n*t^(3/2)` diverges.
- **Theorems 8.2 and 9.1:** tempered large-block Poisson processes and maximum laws, followed by a Gumbel law when the lattice spacing shrinks.
- **Section 6:** convergent Puiseux inversion of the free energy, an inverse quadratic block-density response, a separated integer-threshold interpretation, and Lambert-W / incomplete-gamma maximum centerings.

The coefficient correction changes on the different scale `n*t = O(1)`. Keeping these two scales separate is central to the result.

### Credit and scope

The exact enumeration identity is CDFS's, with the divisor evaluation attributed to Alekseyev. Kolesnik's leading enumeration constants and unweighted component law are prior work. Exponential tilting, renewal conditioning, stable laws, and Lambert-W inversion are established methods. Novelty is asserted only as a development beyond the inspected repository report, not as independently established worldwide publication priority.

The manuscript proves separate marginal count and point-process theorems, not a joint count–maximum independence theorem. Its coefficient expansion is at every **fixed** truncation order. It does not certify numerical error constants, finite-size probability intervals, or unrestricted integer rounding. A continuous Gumbel limit is not claimed at fixed positive `t`, where a lattice obstruction remains. Nine further research questions are in Section 11.

### Files

- `article.pdf` — the compiled 27-page article.
- `article.tex` — LaTeX source; it uses the five included `data/*_table.tex` fragments.
- `code/reproduce.py` — integer checks, numerical constants, renewal recurrences, distributions, inverses, and CSV outputs.
- `code/symbolic_audit.py` — exact symbolic checks of the displayed local, kernel, and inverse coefficients.
- `code/make_tables.py` — CSV-to-LaTeX formatting of the recorded tables.
- `data/verification.json` and `data/run.log` — recorded computational checks and environment.
- `data/symbolic_audit.json` — exact symbolic audit results.
- `data/oeis_exact_0_80.csv` — exact coefficients in the article's conventions.
- `data/*.csv` — coefficient, characteristic-function, maximum, Gaussian/Gumbel, and inverse diagnostics.
- `data/build_quality.json` — build and layout preflight record.
- `SOURCE_NOTES.md` — provenance and bounded literature check.
- `build.sh`, `build.ps1`, `requirements.txt` — rebuild instructions and recorded dependency versions.
- `SHA256SUMS.txt` — checksums of distributed files, excluding the checksum file itself.

No fonts or downloaded third-party papers are bundled.

### Reproduce

The recorded environment is Python 3.13.5, NumPy 2.3.5, mpmath 1.3.0, and SymPy 1.14.0. From a **copy** of this package:

```sh
python -m pip install -r requirements.txt
python code/reproduce.py --max-n 4096 --dps 60
python code/symbolic_audit.py
python code/make_tables.py
./build.sh
```

On Windows with pdfLaTeX installed, use `./build.ps1` in PowerShell, or run
`pdflatex -interaction=nonstopmode -halt-on-error article.tex` three times.

The numerical and symbolic scripts overwrite their corresponding data outputs by default. Both accept `--output PATH` to write elsewhere; `make_tables.py` always uses this package's data directory. The PDF can be rebuilt without rerunning Python, because the table fragments are included. Rebuilding needs the ordinary LaTeX packages named in the preamble, but no network, figures, or external bibliography database once those packages are installed.

### What was checked

The integer recurrences were computed through `n=180`, and the displayed OEIS initial terms were matched. An independent Landau-inequality enumeration and the **whole** component-count polynomial were compared through `n=10`. Floating normalized recurrences were checked against the exact coefficients through `n=30`. Integral and erfc forms of the main kernel were independently evaluated at high precision. Numerical asymptotic diagnostics reach `n=4096`; constants and kernels used 60-digit mpmath arithmetic, while large coefficient recurrences used float64.

These are finite checks, not proofs by computation. Distributional convergence is slow: the crude Gumbel-center CDF is still about 0.624 at `n=4096`, compared with the limiting 0.368. The refined center improves it but remains affected by the lattice. The article reports these discrepancies rather than concealing them.
