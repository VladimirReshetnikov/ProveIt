# Beyond all algebraic orders in OEIS A189281

**An explicit Dawson kernel, sharp Borel growth, non-holonomic correction coefficients, and an unavoidable flat remainder**

Prepared for Vladimir Reshetnikov, 4 October 2026.

## Read first

`article.pdf` is the 21-page report; `article.tex` is its complete LaTeX source,
including the bibliography. This is an AI-assisted, unrefereed research manuscript,
not a Lean-checked formalization. Mathematical proofs, exact finite checks, and
floating-point diagnostics are distinguished in the text.

The report continues the pinned ProveIt A189281 path-forest article, rather than
repeating its earlier all-orders coefficient theorem. See `SOURCES.md` for the
exact source revision and the boundary between prior work and this extension.

## Main results

The manuscript gives an explicit Dawson–Volterra formula for the entire Borel
transform of A189281's normalized inverse-power asymptotic sector. It establishes:

- Positive-ray Laplace summation exactly in Re(n)>1, but failure of exponential
  boundedness in any open angular Borel sector around the positive axis. The
  maximal open horizontal-strip half-width is pi/4.
- Sharp double-exponential maximum growth of the Borel transform and the law
  limsup(log(m)*abs(c[m+1]/m!)**(1/m))=2. In particular, the correction coefficients
  are not P-recursive and their ordinary power series has zero convergence radius.
- A positive canonical analytic completion, its meromorphic continuation, and a
  growing-order truncation bound exp(-n*log(n)/2+O(n)). The bound is for the
  completion, NOT yet for the original integer sequence.
- Exact polynomial shift equations for the completion, including a fourth-order
  equation and annihilation by the order-13 operator displayed conjecturally in
  OEIS. This is NOT a proof of the conjectured recurrence for the integer counts.
- A purely arithmetic obstruction: the canonical completion cannot equal all
  four integer counts in any block starting at n>=2. The normalized discrepancy
  is smaller than every inverse power but is necessarily nonzero in each block.

Ten concrete further research questions are included, particularly the leading
flat term, the original counting recurrence, large-order oscillations, optimal
truncation, other offsets, and formal verification.

## Files

- `article.tex`, `article.pdf`: manuscript source and compiled PDF.
- `SOURCES.md`: provenance, source audit, and contribution boundary.
- `build.sh`: LaTeX build, anchored at this directory.
- `requirements-optional.txt`: optional numerical dependency.
- `code/core.py`: exact coefficients, independent path-tiling enumeration, and
  separate numerical kernel/quadrature functions.
- `code/verify.py`: independent exact checks and optional numerical diagnostics.
- `code/factor_certificate.py`: exact polynomial certificate for the order-six
  left factor of the displayed OEIS operator, acting on the analytic completion.
- `data/coefficients.json`: psi[0..400] and c[0..400], exact integers.
- `data/exact_values.json`: independent exact A189281 values for n=0..30.
- `data/verification.txt`: recorded verification output.
- `data/factor_certificate.txt`: zero-polynomial certificate output.
- `data/numerical_diagnostics.csv`: canonical values, counting discrepancies,
  chosen truncation orders, and separate truncation errors.
- `data/numerical_status.json`: precision and explicit non-certification flag.
- `SHA256SUMS.txt`: integrity hashes of the delivery files other than itself.

## Reproduce the exact checks

Python 3.10 or later is sufficient. No third-party package is needed for:

```sh
python code/verify.py --order 400
python code/factor_certificate.py
```

The recorded run checked 401 auxiliary coefficients from two constructions,
399 Green–Volterra Taylor derivative identities, 396 differential-equation
coefficient identities, 11 displayed OEIS asymptotic coefficients, 22 OEIS
integer values, and all 46,234 permutations of sizes 0 through 8. Counts through
n=30 and coefficients through order 400 were generated independently of any
guessed counting recurrence.

The factor certificate is integer polynomial arithmetic, not evaluation at
finitely many numerical points.

## Optional numerical diagnostics

```sh
python -m pip install -r requirements-optional.txt
python code/verify.py --order 400 --numerical --dps 65
```

These calculations use mpmath 1.3.0. They are high-precision quadrature and
consistency checks, NOT interval arithmetic or rigorous numerical enclosures.
No theorem depends on a floating-point residual being rounded to zero.

All output paths are anchored at the scripts. Running verification intentionally
regenerates the corresponding files in `data/`. To preserve the delivered run,
execute in a copy of the extracted directory. The exact-only verification run
updates `verification.txt` without numerical lines; the full command above
restores the complete report.

## Build the PDF

A TeX installation with pdfLaTeX, Latin Modern, AMS packages, microtype,
hyperref, cleveref, booktabs, enumitem and fancyhdr is sufficient.

On a Unix-like shell:

```sh
./build.sh
```

On Windows with TeX Live or MiKTeX, from this directory:

```text
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
three times. There are no external image or bibliography-file dependencies.
Font files are not distributed with the archive.

## Limits of the contribution

Historical priority beyond the sources inspected has not been established.
The exact counting sequence's leading flat correction, its full transseries,
and the proof of its conjectured recurrence remain open in this report.
Neither repository placement nor the included exact checks constitute peer
review or proof-assistant verification. No repository or OEIS page was modified.
