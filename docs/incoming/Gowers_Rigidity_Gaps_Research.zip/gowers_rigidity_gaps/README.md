# Rigidity gaps in Gowers's Szemerédi framework

**Exact additive-energy levels, punctured cosets, and a real fourth-uniformity inequality**

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov, 7 October 2026.

## Main results

1. For every `m >= 5`, the first three distinct energy levels for an `m`-element set in a torsion-free abelian group are `M_m`, `M_m - 4(m-2)`, and `M_m - 8(m-3)`, with `M_m = (2m^3+m)/3`. All sets at the second level are classified. The first gap is credited as a consequence of inverse Pollard theory; the second-level classification and third exclusion interval are the further results proved here. A full classification at the third level is not claimed.
2. The sharp coset-distance envelope extends from the existing report's `epsilon <= 1/100` to `epsilon < 1/9`, in every abelian ambient group. The paper identifies the canonical closest coset and classifies all equality cases. A second envelope gives puncture-repair distance at most `delta * tau(eta/delta^3)` for `eta/delta^3 < 1/9`, where `eta = epsilon - delta(1-delta)` and `tau(s) = (1-sqrt(1-4s))/2`. Its optimal asymptotic leading constant is exactly one, and its positive-excess equality cases have two nested holes; zero excess gives an exact puncture. Positive-defect coordinate-collision equality domains for the original coset-distance envelope are also classified. The validity thresholds `1/9` are not claimed optimal.
3. For real centered functions on finite odd-order abelian groups, `U4(f)^16 >= (4795/832) U2(f)^16`. The resulting exact interval for `c4^odd` is approximately `[0.5574336443, 0.6454070109]`. An exact five-point witness and a cosine dual calculation exclude all real single-character global extremizers. The sharp constant remains unknown.
4. Applications give the improved quartic coefficient `P_d (832/4795)^(1/4)` for centered cube counts in dimensions at least four, and the first three defect levels for complements with rectified holes.

The article includes complete proofs, exact computational certificates, a detailed source/provenance ledger, normalization guidance for the existing Lean development, and sixteen proposed research questions. It does not claim external peer review, Lean verification, global publication priority, or a new global Szemerédi bound.

## Repository pin and integration

The inspected ProveIt revision is:

`6ce33539ea468f51719a211c18aabdde262a24dd`

The relevant base directory is `Combinatorics/Ramsey/`. The consolidated local-refinement article at this pin contains sources 01–14; available materials from sources 15–23 were checked for overlap as described in the source ledger. The new article is standalone. A suggested destination is:

`Combinatorics/Ramsey/Research/GowersSzemeredi/rigidity-gaps/`

Alternatively, its sections may be ingested into the existing thematic report. Preserve the stated hypotheses and credit boundaries during consolidation. No repository files were changed by preparing this package.

## Build

The main source is `gowers_rigidity_gaps.tex`. Keep `sections/` and `references.bib` beside it. Standard pdfLaTeX packages are used; there are no external images, proprietary fonts, or shell-escape requirements.

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error gowers_rigidity_gaps.tex
```

Without `latexmk`, run:

```bash
pdflatex -interaction=nonstopmode -halt-on-error gowers_rigidity_gaps.tex
bibtex gowers_rigidity_gaps
pdflatex -interaction=nonstopmode -halt-on-error gowers_rigidity_gaps.tex
pdflatex -interaction=nonstopmode -halt-on-error gowers_rigidity_gaps.tex
```

The supplied PDF was built from these sources. `data/build_report.json` records the actual build and QA observations.

## Exact mathematical checks

Python 3.10 or later is sufficient. No third-party Python dependencies or network access are needed.

```bash
python3 code/verify_all.py
```

Equivalently:

```bash
python3 code/verify_energy.py --output data/energy_checks.json
python3 code/verify_cosets.py
python3 code/verify_u4.py --json certificates/u4_certificate.json
```

`make all` runs the verifiers and builds the PDF. Mathematical comparisons use integers and rational arithmetic. These scripts certify their explicitly finite computations and provide diagnostics for the universal proofs; exhaustive finite checks do not prove the general theorems. The scripts that use assertions reject Python's `-O` and `-OO` modes.

## Package contents

| Path | Purpose |
| --- | --- |
| `gowers_rigidity_gaps.pdf` | Complete compiled article |
| `gowers_rigidity_gaps.tex`, `sections/*.tex` | Complete modular LaTeX source |
| `references.bib` | Primary sources and pinned repository citation |
| `code/verify_*.py` | Exact, portable mathematical verifiers |
| `data/energy_checks.json`, `data/coset_checks.json` | Recorded finite verification outputs |
| `certificates/u4_certificate.json` | Rational certificate, cosine sign counts, exact five-point cube histograms |
| `data/source_manifest.json` | Audited revision, relevant blob IDs, and source boundaries |
| `data/build_report.json` | Compilation and visual QA observations |
| `data/verification_run.txt` | Complete successful run of the three exact verifiers |
| `reviews/*.md` | Internal AI proof cross-check records |
| `SHA256SUMS` | Checksums for the packaged files |

The proof reviews are internal AI cross-checks, not external referee reports. No third-party paper is redistributed in the package.
