# Research Report46

Exact certificate height and an even-rank obstruction

Date: 4 October 2026

## Deliverables

- `Research_Report46.pdf`: full proof article
- `Research_Report46.tex`: editable LaTeX source
- `packets/`: byte-preserved research, independent audits, manuscript reviews, and authenticated source material
- `checks/`: report-level replay, deterministic build, toolchain, and layout receipts

## Mathematical scope

For each fixed Report45 outer14-coordinate tuple, the displayed positive auxiliary completion uniquely minimizes the maximum of all18 supplied witnesses over every positive i,F_aux,U_aux,y_aux completion. Its height is H=psi_(Delta*c^2)(R), and its exact bit length is (R-1)(2p(p+y+1)-1)+1. The18-row ledger gives11 exact lengths and7 certified upper bounds, enough to prove the exact numerical maximum. Exact cubics and compiler/input envelopes preserve the power-of-five radix jumps. Double-exponential growth refers to the radix exponent t and eventually the numerical input value x, not the binary encoding length of x.

The literal free-coefficient83 interface has no positive auxiliary completion when A>=4 is even, c=psi_A(p) with even p>=2, R is odd, and the retained product P5 is1. This includes all authenticated Report45 outer tuples and treats nonsquarefree Delta, every norm sign and divisor, and unrestricted-sign V.

Current source status: a separate commit-pinned construction, independently audited during this report's final preparation, gives infinitely many full positive free83 zeros for every positive ordinary input on every valid fixed-program slice of the unchanged inherited compiler recipe. It uses prime main indices p=1 modulo4. That odd-rank all-input collapse is compatible with the fixed even-rank nonextension proved here. The source/audit reconciliation packet is included; its upstream executable files remain inert. No impossibility claim about other83-operation circuits or different coefficient recipes follows.

The analytic extensions prove an exact convergent five-argument forward log-height series with a tail, a monotone real interpolation, a convergent algebraic cubic inverse, a first exponential inverse correction with explicit64-bound, and a convergent all-orders Lagrange derivative algorithm with an explicit Cauchy tail. The latter is not a fully sorted canonical transseries. At an arbitrary center r0=100, the local inverse can lie just below100; the actual-R>=100 application stays in its original range.

These are not a global certificate minimum over different outer tuples, a generic free83 soundness theorem, or a new universal operation bound. Finite numerical evidence is corroborative and is not interval certification.

## Reproduce the evidence

Use Python3 with `mpmath==1.3.0` for the two independent analytic checkers. All other bounded checkers use only the standard library. The version is recorded in the frozen analytic receipts; another version can produce different printed high-precision values and will correctly fail byte-exact receipt comparison even if mathematically equivalent.

From this directory:

```sh
python3 verify_release.py
python3 replay.py --output /tmp/report46-replay.json
python3 build_pdf.py --output /tmp/report46-rebuilt.pdf --logs /tmp/report46-build-logs
```

Choose new output paths for the PDF: the build refuses to overwrite existing artifacts. A working TeX Live installation with pdfTeX, the article class, AMS packages, Latin Modern, geometry, microtype, enumitem, hyperref and ordinary support packages is required. The script can generate a private format and font map from already installed vendor files if the image lacks generated caches. Both format initialization and all three LaTeX passes explicitly disable shell escape. No compiler-recipe or research source is run during the PDF build.

The original release was rebuilt byte-identically twice in its recorded toolchain. Different TeX distributions or font versions may alter PDF bytes without altering content. The mathematical replay uses explicit failures rather than `assert`, and runs each of eleven independently authored checkers under both normal and optimized Python. The frozen outputs must match in both parsed types and bytes. The seven negative-control scenarios independently invoke the copied height checker under both modes.

## Strict execution boundary

`replay.py` is a new inspected allowlist wrapper. It authenticates the complete packet inventory, validates nested manifests, copies the packets into a temporary directory, and runs only these independent bounded scripts:

1. Height author checker
2. Auxiliary-minimum checker
3. Height negative-control checker
4. Independent height-audit checker
5. Even-rank free83 nonextension checker
6. Forward/first-inverse author checker
7. Independent forward/first-inverse checker
8. All-orders inverse author checker
9. Independent all-orders inverse checker
10. Independent prime-rank source-reconciliation checker (static source authentication and bounded arithmetic)
11. Report46-only small-norm/odd-polynomial checker

Upstream repository Python, saved arithmetic schedules, compiler recipes, and all executable files in the nested Report45 release remain inert. Source snapshots are only read, hashed, or parsed as JSON data. No genuine full giant witness tuple is materialized. Synthetic outer packing diagnostics and inner Pell fixtures are not combined into a claimed genuine compiled program.

One independent height checker originally hard-codes an absolute Report45 source path. The wrapper checks that exact assignment and replaces only it in a separate temporary executable copy with a relative, portable root. The frozen checker and all scientific packets remain unchanged; the replay records both checker hashes. That executed-copy hash is deterministic and does not depend on the temporary directory name.

## Source history and audit binding

The Report45 release is included in full. Its delivered PDF SHA256 is 8c635d4b4b32e574923b299c93627ca1cd21817d8402e2725970967bd2b72897. The recovered construction proof is a new authenticated text, SHA256690c5a1dc237bd53a9582bfbe01fcd8a176174e6b116089a1842532f83c1770b; it is not claimed byte-identical to a historical lost proof. Original source snapshots retain their independently authenticated pins.

The Report43 collection contains the delivered PDF and LaTeX plus the exact early small-norm proof and literal free83 JSON, not its whole release. The required small-norm lemma is proved in the article itself. Every preserved byte is inventoried in `PACKET_INVENTORY.json`.

Separate independent manuscript reviews pin the exact free83 theorem/proof/dependency excerpts, the forward/first-inverse section, and the all-orders inverse section. `verify_release.py` checks those excerpt bindings as well as the sealed release file inventory. Old source status prose such as "pending audit" is preserved unchanged; completed independent audit packets supply the final verdicts.

## Archive

`MANIFEST.json` hashes every release file except itself. It has no self-hash cycle. The ZIP is outside the release tree and is made deterministically, with stable member ordering, timestamps, and permissions:

```sh
python3 archive_release.py --output /tmp/Research_Report46-rebuilt.zip
```

The archive is CRC-checked, extracted to a new directory, and its release verifier and replay are run again before delivery. The release-level hash is for integrity, not a substitute for the mathematical proofs or independent review.
