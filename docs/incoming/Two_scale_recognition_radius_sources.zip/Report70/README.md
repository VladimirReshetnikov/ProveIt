# Report 70

## Two scale recognition for the binary five particle compiler

4 October 2026. `Report70.pdf` is the complete 21-page article. `Report70.tex` is matching flattened editable LaTeX, with seven readable sources in `manuscript/`.

The full-shift involution lemma separates write radius b, recognition radius a and control radius r. With H=max(2(b+a),b+r), it proves radius at most b+a+H and invariance of every recognition and selection decision. A mutually unique before-and-after guarded choice handles all types at the same integer anchor without irreversible priority. Literal type-specific windows, both signed corridor partitions, exact home guards and old-marker reverse anchors establish agreement on the whole admissible doubled micrograph.

The compiler's sufficient total radius falls from Report26's 180D+258+9J to 108D+149+3J. For the same inherited universal-source ledger the upper bound is 55,027,013 rather than 91,711,698, approximately forty percent smaller. The universal source is absent and was neither re-proved nor executed. The valid encoding still has five binary particles and exactly the same trajectories, clocks, reflections, observer and clean-target behavior. An explicit four-particle input proves the new full-shift rule differs from Report26. Old arbitrary-input evaluators, Diophantine certificates and circuit costs do not transfer automatically.

The independent radius-two appendix gives a complete graph-potential parameterization of conservative binary five-input tables, retains exactly 428, and excludes all 423 nonprojections by explicit periodic collisions. Only the five shifts remain. The count 428 is established literature. No external novelty, minimum universal radius, radius-three construction or universal implementation is claimed. A bounded renewed Schranko–de Oliveira 2011 search verified its bibliography but did not obtain full text; that priority limit is stated.

## Included material and evidence boundaries

- `Report70.pdf`, `Report70.tex`, `manuscript/`: complete article, standalone source, modules and manuscript pins
- `science/proof-packet/`: complete unchanged frozen source proof packet, with original independent proof audit, radius-two certificate and inherited dependencies
- `science/proof-packet/original/report26.zip`: exact authenticated original Report26 archive; all code and historical receipts inside are inert
- `science/frozen-packet-archive/`: exact outer proof-packet archive and its freeze receipt
- `science/report26-readable/`: unchanged original Report26 PDF and LaTeX for convenient inspection
- `audits/fresh-audit-static/` and `audits/fresh-audit-radius2/`: complete fresh accepted audits, retaining their sibling layout and combined manifest
- `INPUT_PINS.json`: fixed original-source mapping and exact frozen copied file and directory metadata
- `qa/`: original preservation, primary-source limits, predecessor tools, build and visual receipts, owned selftest and independent reviews
- `tools/`: Report70-owned presentation-only release, build and synthetic selftest tools
- `RELEASE_MANIFEST.json`: final release inventory, authenticated by its externally supplied digest

The fresh proof audit accepted the entire mathematical construction without a required correction. The radius-two audit independently derived the conservation graph criterion, enumerated all 32,768 tree assignments, retained 428 tables and checked all 4,062 local collision equalities. Its stored results are prior independent static evidence, not newly rerun Report70 checks.

All supplied scientific programs remain inert during report builds and release operations. No source-machine interpreter, physical or trajectory simulator, author/upstream scientific checker, saved schedule or Lean program is executed. Retained audit checkers preserve their original absolute or relative evidence paths and are inert provenance, not portable release runners. The commands below are the supported portable presentation workflow. Typesetting reproducibility does not prove a mathematical theorem.

## Independent manuscript and presentation-tool reviews

The complete final manuscript, all seven modules, and all 21 independently rendered pages passed the independent mathematical-transcription and visual review with no required correction. It explicitly accepts the clean-target equivalence and enlarged-constant timing, all-input versus admissible assertions, and inherited universality boundary. Its complete pinned dossier is in `qa/manuscript-review/`. Two optional layout observations are recorded there without affecting acceptance.

The independent release-tool review passed all 116 independently written checks/operations and separately reproduced all 39 owned synthetic tests. Direct and authenticated relocated locked builds reproduce the PDF and every one of the 21 PNGs exactly, with the complete recorder union matching the dependency lock. All 45 original copied source/audit files and the sealed reviewer candidate remained unchanged. The accepted compact dossier is in `qa/release-tool-review/`. Its review-candidate manifest/archive is distinct from this later final release seal and must not be used as the final archive digest.

## Authenticate a received release

Use Python 3.9 or newer. Inspect `tools/release70.py` before running it. Replace `EXPECTED_MANIFEST_SHA256` with the final digest obtained outside the archive. Hashing a manifest found inside an archive does not authenticate it.

```sh
python3 -I -S -B tools/release70.py verify \
  --manifest-sha256 EXPECTED_MANIFEST_SHA256
```

The verifier checks exact file and directory descendants, regular single-link files, hashes, sizes, modes and nanosecond modification times, plus the fixed inert-input pin map. It rejects symlinks, special files, unexpected entries and empty directories. Manifest bytes are authenticated by the external digest; the manifest's own filesystem metadata and the top-level release root's mode/time are outside its inventory. Per-operation snapshots check current-root preservation. Read-access timestamps are not integrity evidence. Original creation/change timestamps are not transported to a new filesystem.

Ordinary ZIP extractors often discard nanosecond times. Use the supplied metadata-preserving extractor from an already inspected copy of the tools:

```sh
python3 -I -S -B tools/release70.py extract \
  --archive /absolute/path/to/Report70-source-evidence-20261004.zip \
  --output-dir /absolute/path/to/new-report70-copy \
  --manifest-sha256 EXPECTED_MANIFEST_SHA256
```

Before writing, extraction authenticates the manifest, exact member list, payload bytes and file modes, rejects traversal and nonregular entries, then restores authenticated descendant modification times. The fresh root has mode 0700; the manifest receives mode 0644 and the fixed epoch. ZIP timestamps, compression choices, comments and other container metadata are not independently authenticated by extraction. The output must not exist and must lie outside the release and protected source trees. Verify again from the extracted copy.

## Rebuild in a new external directory

Inspect `tools/build_report70.py` and its hash-pinned release helper before execution. The locked build uses a fresh local TeX format, fresh font map, allowlisted environment, disabled shell escape, three passes and the union of the format and every pass's recorder inputs. It checks preservation and every rendered PNG's dimensions, CRC and raster structure. Visual review is separate.

The manuscript-pin map SHA-256 is:

`944b95cbd26caf7bca3967fc8be0c4395b9fd5df3e517fe953767c39cdaf0332`

The dependency-lock SHA-256 is:

`a467e715df8470d46d66d94e64da543bf3aaf4a5e2192cc486ddaf98d913df9c`

After authenticating the release:

```sh
python3 -I -S -B tools/build_report70.py \
  --output-dir /absolute/path/to/new-report70-build \
  --pins-sha 944b95cbd26caf7bca3967fc8be0c4395b9fd5df3e517fe953767c39cdaf0332 \
  --dependency-lock-sha a467e715df8470d46d66d94e64da543bf3aaf4a5e2192cc486ddaf98d913df9c \
  --require-packaged-match
```

The output contains PDF, extracted text, full recorder receipts, dependency receipt, every rendered page, preservation records and build receipt. The PDF must equal the sealed article byte for byte. The lock covers interpreter/executable bytes, recorded system TeX/font inputs and selected maps. It does not inventory shared libraries, Python's standard library or the operating system. A different toolchain should fail preflight rather than be called identical.

The fixed SOURCE_DATE_EPOCH is 1791072000. Variable PDF dates and trailer IDs are omitted. `--bootstrap` is authoring-only: it records a first dependency set and explicitly makes no preflight-lock-verification claim. It does not replace locked replay.

## Deterministic archives and owned selftests

```sh
python3 -I -S -B tools/release70.py archive \
  --manifest-sha256 EXPECTED_MANIFEST_SHA256 \
  --output /absolute/path/to/new-report70.zip
```

Creation sorts entries under `Report70/`, applies one fixed timestamp, preserves authenticated file modes and uses deterministic deflate settings. These are creation guarantees; extraction authenticates the payload boundary above. Original descendant nanosecond times remain in the manifest and are restored by extraction. Repeated creation in the same Python/zlib environment is checked for identical bytes. Do not regenerate the manifest merely to make altered content verify.

The author-owned synthetic selftest is separate from independent review:

```sh
python3 -I -S -B tools/selftest70.py \
  --output-dir /absolute/path/to/new-report70-selftest
```

Its completed receipt records 39 passing tests: accepted/rejected pins, source/output alias guards, frozen metadata, first-pass-only dependency retention, hostile inherited temporary variables, corrupt PNGs, deterministic archives, preserving extraction, relocated verification and exact PDF equality. Fixtures use synthetic TeX and inert evidence copies, never scientific programs.
