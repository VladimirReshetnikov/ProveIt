# Baire Order Forces Arithmetic Rigidity

**Discretely ordered rings with Polish addition and completely unrestricted multiplication**

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov, 3 October 2026.

## Main result

A nonzero discretely ordered ring whose additive group has a Hausdorff Baire
ccc topology and whose positive cone has the Baire property is countable and
discrete. In particular, this holds for any Polish additive-group topology.
Multiplication is not assumed continuous, Borel, or measurable in any sense.

The key algebraic theorem, for an arbitrary ordered ring, is the ordered
additive embedding

    A / Fin(A) -> A / H_a,    x + Fin(A) |-> a*x + H_a,

where Fin(A) consists of elements bounded by an ordinary integer and H_a
consists of elements bounded by an ordinary integer multiple of a > 0.
Both quotients are additive, not ring quotients. For a discretely ordered
ring, Fin(A) is exactly Z*1. Category supplies an open H_a, and ccc makes
its coset space countable.

This resolves the remove-local-compactness question in the earlier project
manuscript *Local Compactness Forces Arithmetic Rigidity*. The theorem is
about signed topological groups. It does not silently give a Polish group
completion to every positive arithmetic monoid.

## Contents

- `article.pdf`: the 23-page article, including complete proofs, applications,
  counterexamples, 12 further research questions, and references.
- `article.tex`: self-contained LaTeX source; references are embedded.
- `verify_examples.py`: standard-library-only exact rational arithmetic checks.
- `verification_results.json`: recorded successful run, seed 20261003.
- `SOURCE_AUDIT.md`: sources, repository snapshot, and trust boundaries.
- `Makefile`: optional build/test commands.
- `SHA256SUMS.txt`: hashes of the package contents other than the hash file itself.

## Main locations in the article

- Theorem 3.4: principal-hull amplification and exact kernel.
- Theorem 5.1 and Corollary 5.2: Baire--ccc rigidity and the exact Polish criterion.
- Theorems 6.1 and 6.3: relative cardinal obstruction and maximal topological size.
- Theorem 7.1: bounded-subgroup direct-sum amplification.
- Corollary 8.1: no ordered-ring expansion of uncountable Polish signed
  Presburger groups with regular order.
- Theorem 10.2: bounded unit-image spectrum for additive order self-embeddings.
- Section 9: counterexamples and a completion that destroys discrete order.
- Section 13: set-sized omnific applications and a formalization plan.
- Section 14: twelve further research questions.
- Appendix A: an abstract semantic Cooper-elimination argument.
- Appendix B: proof and reproducibility audit.

## Build

Use a TeX installation with standard mathematical packages, including newpx,
tcolorbox, cleveref, and aliascnt. No external bibliography processor or image
assets are needed. No font files are included.

    latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build article.tex

The rebuilt PDF will be `build/article.pdf`. Alternatively, run `make pdf`.

## Run the checks

Python 3.10 or later, no third-party packages:

    python3 verify_examples.py --output verification_results.json

The recorded run passed 29,041 reported finite checks. The counts include
multiple checks of the same generated cases, as labeled in the JSON. Tests
cover exact polynomial identities, quotient signs, finite-coordinate standard
division, finite Cooper candidates, and a truncated geometric inverse.
They do not verify topology, Baire category, arbitrary orders, cardinalities,
or the infinite theorems. Assertions are checked explicitly and are not
disabled by Python's optimization flag.

## Status

The mathematical arguments are supplied in full, but this is an unrefereed
AI-assisted research manuscript. Historical priority has not been established.
No new Lean or Rocq theorem is claimed to be machine checked, and no repository
build was run. Existing project manuscripts and classical inputs are credited.
The document is prepared for the user; it does not claim authorship,
endorsement, or participation by Elliot Glazer.
