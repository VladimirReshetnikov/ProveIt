# Restricting equality vacuity in the ZFC machine calculus

Research checkpoint for Vladimir Reshetnikov, 19 October 2026.

## Result

Keep the original rho1–rho8, full membership vacuity, CP and native GIC.
Replace full fresh equality vacuity by the code-specific helper

    Eq(a,b) -> All(weq(a,b), Eq(a,b)).

The resulting theory is equiconsistent with ordinary ZFC in the external
classical metatheory, relative to the precise existing completeness and
model-construction endpoints identified in the article. Equality is interpreted
as two-sided membership indiscernibility. Restricted quantifier-free
specialization and explicit auxiliary-binder transport avoid circular uses of
full substitution or alpha conversion. Equality-free comparison matrices
preserve their literal native GIC output codes.

Appendix A extends the helper to any κ(a,b) distinct from a,b when a≠b,
with no diagonal restriction. All eight native constructor/order choices are
admitted, including κ(0,0)=0 for the implication builders.

This package does not supply a modified native Lean proof relation, proof-assistant verification of the changed
enumerator, or a newly calibrated binary-machine endpoint. A separate ordinary
source/enumerator theorem and 26 exact source identifications are included in
Appendix B and `source_binding/`. No
machine with at most 235 working states has been established. The supplied
236-state machine belongs to inherited commit 0b5fec6980.

The prior Source113 discussion of observational identity in a complete
first-order calculus is explicitly attributed. Observational equality and the
general quotient idea are not claimed as new.

## Contents

- `report.pdf`: the compiled research article
- `source.tex`: editable LaTeX source for the article
- `proofs/`: four proof builders, their exact serialized proof DAGs, and local-rule replay checkers
- `audit/`: independent E edge checks, native-code regressions, positive-V source snapshots and placement checks, and the mathematical audit
- `source_binding/`: ordinary source/enumerator proof, independent graph/formula binding checker, 26 pinned source inputs, and receipt
- `reference_lean/`: selected existing endpoint source files for inspection; not a standalone Lean project
- `frontend/`: one pinned generic 263-state table, the surgical source and closed reassociation certificates, and original/minimal source paths
- `prior_art/`: the exact Source113 README reviewed for attribution
- `tools/`: standard-library package, replay, and pinned frontend validation utilities
- `PROVENANCE.json`: source revisions, locations, and path-only audit adaptations
- `VALIDATION.json`: packaging-time finite replay summary
- `SHA256SUMS`: SHA-256 manifest of all distributed payload files

The mathematical audit is preserved as a historical report. Its original
workspace path references describe provenance; use the commands below for
this standalone package.

## Verify and replay

Run from the extracted package directory with Python 3.10 or later:

    python3 tools/verify_package.py
    python3 tools/replay_all.py

The replay runner works in a fresh temporary copy and does not alter the
hashed package. It regenerates all four proof JSON artifacts and requires
byte-identical output, then runs all independent checkers under Python `-O`.
The classical generator itself runs without `-O` because its construction
checks intentionally use Python assertions. Final acceptance checkers use
explicit conditionals and remain active under optimization.

Expected principal results:

- Main E suite: 51 closed roots, 51,413 proof nodes, 46,674 formulas
- Independent E edge suite: 93 roots, 128,379 nodes, 117,299 formulas
- Source-to-E bridges: 598 combined nodes, canonical and projection helpers
- Six numerical canonical bridge instantiations and four original-rho7 equality instantiations
- Classical bridge: 724 nodes and 502 formulas
- General-helper extension: 169 closed roots and 27,486 nodes, including literal diagonal-zero collisions
- Native positive-code regression: codes 1 through 65,535, plus code-0 truth alias and five literal equality-free GIC samples
- Four positive-V frontend snapshots checked for standalone-row placement
- 26 complete source/enumerator identifications and four rejected adversarial changes
- Pinned table: 263 working states, 526 rows, start 0, separate halt 263
- Source: 201 decisions, 23 terminals, 6,511 instruction occurrences; entire guarded graph equal across the selected closed reassociation

The ordinary source/enumerator theorem handles exact row counts, parser arity,
closed GEN, MP, gate failures, code-zero aliasing, and cofinal x-field padding.
Its finite checker binds complete saved source graphs to the parameterized
reference. It is not a new proof-assistant theorem or a binary runtime proof.

The finite checks are evidence for their exact artifacts. The uniform
arbitrary-label proof is in the article and independent mathematical audit.
The tuple renamer fixes designated F and is not arbitrary raw substitution
on every occurrence of Rel(0,0); the article explains why the E-body fragment
used here is sound.

## Rebuild the article

A normal TeX Live or MiKTeX installation with pdfLaTeX and the preamble's
standard packages is sufficient:

    pdflatex -interaction=nonstopmode -halt-on-error source.tex
    pdflatex -interaction=nonstopmode -halt-on-error source.tex

This produces `source.pdf`; the distributed compiled version is `report.pdf`.
The generated PDF need not have the same byte hash because TeX embeds build
timestamps and IDs. Do not overwrite the distributed `report.pdf` if you wish
to keep validating the original manifest. Auxiliary TeX files and a new
`source.pdf` are excluded from payload coverage by the manifest checker.

## Pinned frontend cost

The selected generic table is `frontend/generic.tm`, SHA-256:

    bf7f459c9489e3c4cef27044d66d30c8a3d54eaff79a38af68348d06c0bb6275

Its structured source is `frontend/source.json`, SHA-256:

    df4e316d1862c2e5345104ce4fa1030948be98aaf7eb5e0908a132cdb80ff455

The minimum-path surgical edit cost 264 generic states; a closed source
reassociation lowers that generic count to 263 while preserving the full
ordered guarded instruction graph. This is not a reduction of the specialized
236-state runtime. No state-count delta may be transferred between those
architectures without the corresponding implementation and correctness proof.

`tools/check_frontend.py` independently checks hashes, literal rows, source
inventory, outside-edit paths, source conversion, and reassociation graph
equality. It does not rerun the generic compiler, certify its runtime
simulation, or prove a new blank-tape halting equivalence. The original
compiler receipt's stronger source-edge claim is preserved with its provenance.

## Reference endpoints

Selected existing Lean files come from clean ProveIt revision
`7ba1598461c6e485c5aeb8f673c0b1d571f8012b`.

The comparison relies on `TarskiComplete.completeness`, the exact container
and named GIC adapters, `ProfileModel.ModelsGIC` (which ranges only over
equality-free matrices), `WFTheory.zf_consistent_of_model`, and
`ChoiceCalibration254.zf_refutation_iff_zfc`. The restricted equality-free
adapter is a mathematical specialization described here; it has not yet been
added as a new Lean theorem. The selected existing files were not rebuilt as
part of this checkpoint, and their full dependency closure is not bundled.

Source113's prior theory README is pinned separately at commit `7fc67b181`.
See `PROVENANCE.json` and the article's references for exact locations.
