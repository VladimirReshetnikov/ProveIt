# A strict pointwise quadratic gain for A290268

The ten-page `article.pdf` proves that there are constants c>0 and N0 such that

    a(N) >= (3/8+c) N^2

for every integer N>=N0. This strictly improves the leading coefficient in the pointwise lower bound. It is not only an average or summatory result. The positive gain, parameter rectangle, and eventual threshold are existential; no numerical values are claimed.

The proof is complete in `article.tex` and `counting_sections.tex`. It includes:

- The exact recurrence generating function and a global inner-saddle harmonic bound
- Uniform analytic prefactors and a controlled outer conjugate-saddle pair
- A global contour comparison and an additive cosine law
- Separation of adjacent lattice phases from multiples of pi
- An exact parity-respecting count of a positive quadratic number of distinct tail terms outside the known bulk

The proof does not assume equidistribution and does not infer exact integer zeros from zeros of a leading cosine. The full support conjecture and the conjectured leading count N^2/2 remain open.

## Reproduction

Compile `article.tex` twice with pdfLaTeX on a standard TeX Live installation. `build_local.sh` is the wrapper used to generate the included PDF.

Run `python3 verify_rational_band.py` to reproduce the exact-fraction Taylor certificate locating the chosen base interval inside the regular saddle branch. It uses only the Python standard library, and its result is recorded in `rational_band_certificate.json`. The infinite theorem rests on the analytic and counting proofs, not on a finite scan.

The complete written argument received independent mathematical review, including both prefactors, branch conventions, the global comparison, and the lattice constant. Every final PDF page was visually checked, the exact rational certificate was rerun, and the source package was checked for ZIP integrity. This is not a Lean formalization or an externally refereed paper, and no exhaustive priority claim is made.

The source comparison is pinned to ProveIt commit `ca81647a9f679e96d49ffdbc54b0c0ab13d10a36`, linked in the bibliography.
