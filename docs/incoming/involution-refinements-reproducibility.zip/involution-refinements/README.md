# Adjacent transpositions in involutions

A reproducible mathematical research note for OEIS A170941 and A217876, dated 2 October 2026.

Start with **involution-refinements.pdf**. Its editable source is **report.tex**.

## What is established

- Every fixed half-integer order of the probability generating function, uniformly on each fixed complex compact set
- The same remainder order in every fixed exponentially weighted l1 norm of the full probability distribution
- Explicit all-finite-orders total-variation and avoidance-count corrections
- A Lambert-W initializer and a fixed number of Newton steps for each prescribed inverse order
- Separate smooth, integer-threshold, and actual log-linear interpolation conventions
- An exact Gaussian/Chebyshev decomposition, with independent Poincare expansions for its two positive sectors and an explicit residual bound

The exponentially small sector is isolated by subtracting the **exact** dominant integral. A fixed finite dominant-sector asymptotic truncation has no claimed remainder below the second sector. Optimal truncation, resurgence, Borel summability, and exhaustive historical novelty are not claimed.

The Poisson limit is credited to Li (2026); enumeration to Haslinger and Stadler (1997 preprint / 1999 publication); and the first absolute correction 31/24 to Kotesovec's 2014 OEIS formula.

## Replay

Requirements: Python 3, the packages in requirements.txt, a standard TeX Live installation including pdfLaTeX, Latin Modern, AMS packages, microtype, booktabs, enumitem, fancyhdr, hyperref and bookmark; sha256sum; bash. Poppler's pdftoppm and pdfinfo are optional for visual review.

Install the Python requirements in your preferred virtual environment, then run:

    python -m pip install -r requirements.txt
    bash replay.sh

Calling the scripts through bash also works when an archive extractor does not restore executable permissions. The replay verifies the packaged hashes, regenerates exact coefficients and all numerical check files, checks them against the reference outputs, and compiles a fresh PDF under build/. It does not download papers, make network requests, or overwrite the reference data or reference PDF. Large-integer recurrence checks run through n=20000 and can use a few hundred MB of memory. Numerical quadrature and coefficient generation may take several minutes.

For the PDF only, run `bash build.sh`. To place that PDF elsewhere, set `OUTPUT_PDF=/path/to/output.pdf` when calling the script. The build helper also supports Debian installations without a populated TeX filename database, using a local writable format cache. It does not require administrator privileges.

To derive more exact coefficients:

    mkdir -p build/higher-order
    cd build/higher-order
    python ../../scripts/derive_coefficients.py --order 10

Order increases symbolic cost; the theorem is for each fixed order. No claim of convergence of the infinite coefficient series is made.

## Contents

- report.tex and involution-refinements.pdf: full proofs, examples, limitations, attribution, and research questions
- scripts/derive_coefficients.py: exact Gaussian, logarithm, factorial-moment, Touchard, and sector extraction
- scripts/verify_counts.py: exact triangle checks and large-n count residuals
- scripts/verify_law_inversion.py: high-precision law, TV, and finite-Newton checks
- scripts/verify_sectors.py: independent two-sign coefficient generator and exact integral checks
- scripts/compare_results.py: exact symbolic and tolerance-aware numerical replay comparison
- data/: reference JSON outputs and the article's numerical table
- supplements/coefficients.md: complete rational coefficients through order eight, with extra sector coefficients through order ten
- supplements/proof-details.md: additional derivation and numerical error details
- sources.json: source URLs, inspected-byte hashes where available, attribution, and inspection limits
- SHA256SUMS: hashes of the packaged content, excluding itself
- build.sh and replay.sh: local build and end-to-end replay

No downloaded third-party full paper, PostScript, screenshot, or Li TeX source is redistributed. External software dependencies remain subject to their own licenses. Mutable source URLs may later serve different bytes; source hashes identify the copies inspected for this note.

## Reading numerical checks

Tests support the proofs; they do not replace them. The TV routine truncates the exact moment polynomial at K <= 90. Its signed coefficient l1 tail is bounded by sum_{k>K} 2^k/k!, and the omitted Poisson tail is separately negligible at the accuracy used in the table. Quadrature is high precision, not validated interval arithmetic. Long decimal output strings are computational records, not certificates of every displayed digit.

The inverse enclosure constants and sufficiently-large thresholds are proved to exist but are not numerically certified in this package. The smooth inverse cannot be substituted for the actual log-linear inverse at arbitrary precision without the chord correction described in Section 9 of the article.
