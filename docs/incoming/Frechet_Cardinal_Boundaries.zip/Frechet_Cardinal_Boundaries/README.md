# Three Cardinal Boundaries for Fréchet-Power Completions

**Subtitle:** Pseudointersections, local decisions, and ultrafilter points  
**Date:** 24 September 2026  
**Length:** 26 PDF pages, including title, contents, and references  
**Foundations:** ZFC  
**Status:** Unrefereed research manuscript with ordinary mathematical proofs.

## Files

- `Frechet_Cardinal_Boundaries.pdf`: the complete article.
- `Frechet_Cardinal_Boundaries.tex`: self-contained LaTeX source, including bibliography.
- `SOURCES.md`: source provenance, repository snapshot, and literature-search limits.
- `PROOF_AUDIT.md`: theorem dependencies and important scope distinctions.
- `build.sh`: optional PDF rebuild command.

No external images, bibliography database, custom fonts, or network downloads are needed to compile the source with a suitably installed TeX distribution.

## Main results

Let F_kappa be the extension-ordered site of proper filters on omega containing the cofinite filter and having base character at most the infinite cardinal kappa. Let D_kappa be its regular-open complete Boolean algebra, and let C be the order-dense Boolean completion of P(omega)/Fin.

1. **Theorem 4.3:** C and D_kappa have a unique complete comparison preserving their distinguished modulo-finite events when kappa < p. For kappa >= p, no unital complete Boolean homomorphism preserving those events exists in either direction.
2. **Theorem 6.2:** h is the first size of a family of completed binary events in C that cannot be jointly decided on a dense collection of local regions.
3. **Theorem 7.3 and Corollaries 7.4, 7.6:** the atoms and complete Boolean points of D_kappa are exactly free ultrafilters of character at most kappa. They first appear at u. An explicit atomic–atomless decomposition is given.
4. **Theorems 9.2 and 10.1:** the associated sheaf is constructed by Boolean mixtures of raw sequences, with full Boolean-valued first-order transfer.
5. **Theorems 11.1 and 11.2:** localized countable type realization holds, and every ordinary ultrafilter specialization is countably saturated in a countable language.
6. **Theorem 12.4:** for 2 <= |A| <= c, the raw global power, countably generated-site sheafification, and full-site sheafification have sizes c, 2^c, and 2^(2^c), respectively.

The paper also gives closure and partition-refinement results, a forcing description of the residual part, and ten further research questions.

## Relationship to ProveIt

The starting point is the existing report `frechet-two-valued-obstruction` in ProveIt, at commit:

`e21766d04c2b8a9b2cdba0cd43e563024b3bd1b9`

The earlier two-valued nongluing result and full-site product sheaf are **not** claimed as new here. The present contribution is a proposed bounded-character continuation, centered on the two-sided complete-comparison barrier. Standard cardinal characteristics and standard Boolean-valued techniques are explicitly credited.

No repository mutation or commit was performed.

## Build

From this directory:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error Frechet_Cardinal_Boundaries.tex
```

Alternatively, run `pdflatex` three times on the source. The bibliography is inline, so BibTeX is unnecessary.

The supplied PDF was compiled successfully and its rendered pages inspected. The final compilation had no undefined references, overfull boxes, or LaTeX warnings. These are artifact checks, not proof-assistant certification.

## Research limitations

This is not an independently refereed or Lean-verified paper. No exhaustive novelty or priority determination has been made. The unresolved questions concerning intermediate abstract isomorphisms, small-character ultrafilter extension, and higher saturation are stated separately; they are not presented as solved. All claimed theorems have proofs in the article rather than relying on numerical experiments.
