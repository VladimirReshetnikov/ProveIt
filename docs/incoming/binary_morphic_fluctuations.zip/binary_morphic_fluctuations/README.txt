EXACT FLUCTUATION LAWS AND SHARP DISCREPANCY IN BINARY MORPHIC WORDS
Research prepared with ChatGPT, 5 October 2026

START HERE

Read binary_morphic_fluctuations.pdf for the complete article.
The editable source is binary_morphic_fluctuations.tex.
This archive includes everything needed to rebuild the PDF, including
the four scientific figures. No remote bibliography or image download
is needed.

RESEARCH QUESTION

The starting point is question 7 in Part II of the ProveIt report
"Sharp discrepancy for two families of binary substitutions":

https://github.com/VladimirReshetnikov/ProveIt/blob/112d6bedeb346034e89d1b1c423371d76e68fb09/SetTheory/Cardinals/docs/reports/generating-functions-and-asymptotics/binary-substitution-discrepancy/article.tex

It asks for exact critical and supercritical normalization for
tau(0)=1, tau(1)=1 0^a 1^b. The article supplies proofs of both:

* Critical a=b+2: the cluster set of (#0-#1)/log N is
  [-(a-1)/(2 log a), (a-1)/(2 log a)].
* Supercritical a>=b+3: the cluster set of (#0-q#1)/N^alpha is
  an explicit symmetric interval, with a closed amplitude formula
  and an explicit graph-directed continuous phase profile.
* At (a,b)=(8,1), the endpoints are +/-sqrt(10), and every prefix
  satisfies the exact integer inequality X(N)^2+5X(N)<=10N.

The critical analysis applies to every word beginning in 1 with
a zeros and a-1 ones. It gives an exact positive convolution formula
for every complete-block prefix histogram; an independent random-sum
representation; exact finite moments; quantitative Gaussian, local,
and large-deviation laws; sharp variance and pressure comparisons;
and a complete classification of attainable zero-height profiles.
Those profiles are counted by (a-1)2^(a-2)=A001787(a-1).

OEIS CONNECTION

A284368 is the word for 0->1, 1->1011.
A284369 is the word for 0->1, 1->1001.
A284370 and A284371 are the zero and one positions in A284369.
These named examples lie in the bounded part of the same family.
The article does not assign their OEIS IDs to the critical word 10001.

CONTENTS

binary_morphic_fluctuations.tex
    Full manuscript, including proofs, embedded bibliography,
    worked examples, computation methods, and ten research projects.
binary_morphic_fluctuations.pdf
    Compiled article with linked contents, equations, and references.
build.sh
    Convenience build command using latexmk.
figures/
    Four figures in vector PDF and 220-dpi PNG formats.
code/verify.py
    Main exact critical histogram, moment, extremum, and arrangement
    checks, plus generation of the three critical figures.
code/general_word_audit.py
    Independent literal-word audit of the general finite formulas.
code/verify_profile_realization.py
    Constructive Euler-trail realization and independent enumeration.
code/verify_supercritical.py
    Integer checks for (a,b)=(8,1) and the supercritical profile figure.
code/requirements.txt
    Versions used for optional numerical diagnostics and plotting.
data/
    Exact histogram coefficients, rational moment values, verification
    summaries, numerical diagnostics, and figure conventions.

BUILD THE ARTICLE

Run from the extracted archive directory:

    latexmk -pdf -interaction=nonstopmode -halt-on-error \
      binary_morphic_fluctuations.tex

or:

    sh build.sh

Without latexmk, run pdflatex on the source repeatedly until references
and page numbers stop changing (normally three passes).
The source uses standard TeX Live packages: geometry, fontenc, inputenc,
lmodern, amsmath, amssymb, amsthm, mathtools, microtype, graphicx,
booktabs, array, longtable, xcolor, enumitem, fancyhdr, hyperref, bookmark.
The supplied PDF was built with TeX Live 2023/Debian and latexmk 4.83.

REPRODUCE EXACT CHECKS WITHOUT PLOTTING DEPENDENCIES

These commands require only Python's standard library:

    python3 code/verify.py --skip-figures
    python3 code/general_word_audit.py
    python3 code/verify_profile_realization.py

They write reports under data/, relative to their script locations.
They do not enumerate the extraordinarily long words represented by
the deeper exact histogram JSON files.

REGENERATE ALL FIGURES AND RUN THE SUPERCRITICAL CHECK

The recorded environment is Python 3.12.14, NumPy 2.3.5,
Matplotlib 3.10.8, and SciPy 1.17.0.
For a separate environment, from the archive directory:

    python3 -m venv .venv
    .venv/bin/python -m pip install -r code/requirements.txt
    .venv/bin/python code/verify.py
    .venv/bin/python code/general_word_audit.py
    .venv/bin/python code/verify_profile_realization.py
    .venv/bin/python code/verify_supercritical.py

The package versions are the ones used for this article, not a claim
that other compatible versions fail. Dependencies are not bundled.

COMPLETED VERIFICATION

* Main critical verifier: 37,129 exact assertions passed.
* Literal canonical words: 106 words, 906,168 symbols.
* General arrangement audit: all 4,081 words for a=2,...,8 at depth 2;
  a deterministic 341-word subset also checked at depth 4.
* Independent moment audit: 1,078 words, 4,312 exact histogram
  comparisons, and 4,312 exact mean/variance comparisons.
* Profile realization: 1,793 profiles compared against the independently
  enumerated profile sets of all 15,521 words for a=2,...,9.
* Supercritical example: all 524,801 prefixes including the empty
  prefix of tau^9(1) satisfy the exact quadratic inequality; the first
  five explicit extremizing prefixes satisfy their exact formulas.

NORMALIZATION AND DATA CONVENTIONS

Critical X=#0-#1; supercritical X=#0-q#1.
A proper-prefix histogram includes the empty prefix and excludes the
complete word: 0<=n<length. Finite envelope statements specify when
the complete prefix is included.
All unqualified logarithms in the article are natural logarithms.
The critical pressure chi and rate I use speed r or log_a N.
Even substitution depth is r=2m; confusing r and m changes factors of 2.
Gaussian figures use the exact finite mean and variance.
The local diagnostic is max_k |sd*p(k)-phi((k-mean)/sd)|.
Floating-point diagnostics and profile plots are illustrative numerical
evaluations, not interval-certified inequalities.

PROOF AND PRIORITY STATUS

The manuscript supplies conventional mathematical proofs; finite
computations corroborate those proofs rather than replace them.
The general substitution central limit theorem and the invariant-section
identity have established precedents that are cited explicitly.
The precise results here were derived for this project and were not found
in the targeted primary sources surveyed. This is not a certification of
global publication priority. No external peer review or proof-assistant
verification is claimed.

The original ProveIt source is linked and cited, not copied into this
archive. No changes were made to the repository or to OEIS.
