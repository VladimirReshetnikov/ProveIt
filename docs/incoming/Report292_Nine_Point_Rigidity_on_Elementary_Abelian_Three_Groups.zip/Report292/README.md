# Nine-Point Rigidity on Elementary Abelian Three-Groups

ProveIt Report 292, prepared for Vladimir Reshetnikov, 7 October 2026.

The report gives a full-domain classification for maps from arbitrary-dimensional vector spaces over F_3 to arbitrary abelian target groups. The condition r(a)>5/8 holds exactly for affine maps and translated index-three affine cuts. The equivalent nine-point indicator cutoff 53/81 is sharp, while the stronger weighted obstruction bound gamma is not asserted sharp. Outside this family there is an indicator obstruction supported on three, six or nine points. Outside the family, a small integer certificate uses only positive weights 5 and 8, and a sharp single-spike indicator calculation is proved analytically. The plane proof and infinite-dimensional gluing are self-contained, as is the finite-Fourier proof that every nonaffine cut has weighted infimum rho, attained by three-point weights (1, tau, 1).

The translated basepoint is essential. The report distinguishes weighted infima from indicator minima, addresses ranks zero and one, and does not classify arbitrary non-exponent-three source groups. Threshold optimality claims are restricted precisely in the manuscript.

## Contents

- Report292.tex: editable mathematical manuscript
- Report292.pdf: compiled report, included in the final distribution
- companion/exact_checks.py: bounded exact diagnostics using only the Python standard library
- companion/README.md: diagnostic details, bounds and limits
- tests/test_companion.py: mathematical and input-validation regressions
- tests/test_build.py: guarded-builder security and identity regressions
- build.py: offline verification, full replay and deterministic packaging
- REPRODUCING.md: commands, toolchain and archive contract
- SOURCES.md: provenance, primary literature and precise inspection limits
- MANIFEST.sha256: canonical hashes of the eleven public files, included in the final distribution

The mathematical proofs do not depend on running the diagnostic or obtaining any external file. The final archive contains exactly twelve regular-file entries under Report292/, including the manifest.

## Quick replay

    python3 -I -B build.py verify
    python3 -I -B build.py reproduce --output /tmp/report292-replay

The output must be fresh or empty, absolute, and outside the source tree. The builder preserves its source, refuses unexpected files and aliases, runs all checks normally and with -O, and compares outputs. In distribution mode the rebuilt PDF must equal the included PDF byte-for-byte. Matching the documented toolchain is needed for byte-identical output. No install, download, network access or upstream execution occurs.

The separately supplied final ZIP SHA-256 authenticates bytes only when obtained through a trusted channel. The manifest alone is not a signature. See REPRODUCING.md for the complete contract.
