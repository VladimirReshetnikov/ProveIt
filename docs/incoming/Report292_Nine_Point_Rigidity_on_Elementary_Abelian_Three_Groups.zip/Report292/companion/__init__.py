"""Bounded, exact, standard-library diagnostics for Report292."""
