# Rank-Three Ultra-Log-Concavity and Exact Kernels for Matching Supports

Research manuscript prepared for Vladimir Reshetnikov, 30 September 2026.

## Main result

For a bipartite graph G with maximum matching size r <= 3, let s_k count
pairs of k-element sets on its two shores admitting a perfect matching.
Each support is counted once, regardless of how many matchings realize it.
The article proves that s_k / binom(r,k) is log-concave.

The mixed rank-three case is proved by an explicit sum-of-squares identity
valid for arbitrary neighborhood populations. The one-shore case uses the
published ambient-normalization theorem of Roehrle and Ulirsch.

This resolves the matching-number normalization question in the inspected
ProveIt report through rank three. It does NOT resolve the question for
arbitrary rank. Historical priority for the extension has not been exhaustively
certified, and the manuscript has not been independently refereed or checked
in a proof assistant.

## Additional results

* A sharp first rank-normalized inequality at every rank, including a weighted
  directed version, with a complete unweighted equality classification.
* A positive integer rank-three matrix M[i,j] = 1 + i*j + i*i*j*j (1 <= i,j <= 9)
  whose regular-minor counts (1,81,1296,7056) violate actual-rank ULC. This is
  not a counterexample for bipartite matching-support polynomials.
* Exact neighborhood-type counting kernels with 2^{O(r^2)} polynomial-input
  complexity, and a directed version parameterized by support degree.
* An exact uniform support sampler, and a mathematical extension to rational
  vertex activities (the weighted interface is not implemented here).
* Complete formulas and strict rank-ULC for a connected rank-four family with
  unbounded shore sizes.
* Polynomial dependence on clone populations and an exact decision procedure
  for any specified one-parameter family's inequalities. The general sign
  procedure is described mathematically, not provided as a general solver.
* Preorder gamma applications using the repository's existing support bridge;
  an exact full-lattice-point sampler is specified by composition with its
  existing two-flow bijection, but that composition is not implemented here.

## Files

- `article.tex`, `article.pdf`: source and compiled article.
- `code/support_kernels.py`: exact counters and unweighted support sampler.
- `code/certificates.py`: dependency-free rational polynomial certificates.
- `code/verify.py`: independent enumerations and reproducible checks.
- `code/export_rank4_templates.py`: exports the 24 mixed rank-four templates.
- `data/verification.json`, `data/verification.log`: actual successful run.
- `data/rank4_templates.json`: exact binomial-product formulas for 24 templates;
  NOT positivity certificates for the unrestricted rank-four conjecture.
- `PROOF_STATUS.md`, `SOURCES.md`: dependencies, limitations, provenance.
- `Makefile`: convenience build and verification targets.
- `SHA256SUMS.txt`: checksums of the delivered files.

## Reproduce

Python 3.10 or later; standard library only:

```sh
python code/verify.py
python code/export_rank4_templates.py
```

Compile using TeX Live with `latexmk`, `newpx`, `tcolorbox`, and the other
packages loaded by `article.tex`:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively use `make verify templates pdf`.

No font files, executable binaries, or third-party article copies are included.

## Verification actually completed

All 4096 labelled bipartite 3-by-4 graphs were checked by two different
counting representations. All 65536 labelled 4-by-4 graphs were separately
checked by direct support enumeration. This includes 3648 rank-three graphs
with no isolated vertices on either shore; the rank-four checks are only
finite evidence. All 4096 loopless directed relations on four vertices were
compared with the directed kernel. Among them, 355 become preorders after
adding loops; their original polytope inequalities were tested directly on
24850 candidate vectors, giving 12310 feasible points in total.

The run also checks 5184 mixed-cover population specializations, formal
polynomial identities, all 1296 order-two and 7056 order-three minors of the
matrix example, large binary population examples, and 400 sampled supports.
See the JSON for exact details. Finite checks supplement, not replace, proofs.

## Repository snapshot

The source snapshot inspected for this work is:

`ffddaa8b9c89e7bf027e1442cc6216bb010906d0`

Main report directory:

`SetTheory/Cardinals/docs/reports/enumerative-combinatorics/preorder-root-polytopes`

The repository can change after that snapshot. The article does not claim to
have audited every file or every later commit.
