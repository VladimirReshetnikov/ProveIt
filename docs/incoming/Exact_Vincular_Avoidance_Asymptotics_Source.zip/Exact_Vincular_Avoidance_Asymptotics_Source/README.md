# Exact vincular avoidance asymptotics

This bundle contains a self-contained research article on OEIS A113226,
the number of permutations avoiding the vincular pattern 12-34.
It proves an exact exponential generating function, complete asymptotics,
and inverse integer-threshold bounds.
It also proves differential algebraicity and non-D-finiteness.

## Read and build

- article.pdf: rendered article
- article.tex: editable LaTeX source
- exact_egf_proof.md and all_orders_proof.md: fuller working derivations
- source_status.md: primary references and bounded priority search
- structural_corollaries.md: the differential equation and singularity lattice
- audit/: separate mathematical checks

Build with a standard TeX installation containing amsmath, amsthm,
mathtools, geometry, lmodern, microtype, hyperref and xurl:

    bash build.sh

## Reproduce the checks

Python3 standard library suffices for the exact enumeration check:

    python -O check_exact.py

This independently compares the new scalar recurrence with the published
discrete insertion tree and block recurrences, and with brute permutation
and excedance-set enumeration. It also produces exact counts through600.

For the symbolic Gaussian coefficients and numerical illustrations:

    python -m pip install -r requirements.txt
    python -O check_saddle.py
    python -O check_structure.py
    python -O check_numerics.py

All logical acceptance tests use explicit exceptions, so optimization mode
does not disable them. Numeric illustrations are not used as analytic proof.
The formula in check_saddle.py uses a for the article's kappa.

The article contains ordinary mathematical proofs and exact checks.
It is not externally refereed or formally verified.
