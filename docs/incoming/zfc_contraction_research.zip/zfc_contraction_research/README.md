# A contraction-complete proof engine for small ZFC-consistency machines

Research report prepared for Vladimir Reshetnikov / ProveIt, 16 October 2026.

**Outcome: no new verified machine below 253 working states was found.** The
253-state machine included for comparison is existing upstream work. This
package supplies a complete mathematical source-program proposal, executable
reference components, and reproducible constrained compression searches.

## Read first

- `report.pdf` is the full report.
- `report.tex` and `sections/*.tex` contain the complete editable source.
- `SOURCE_PINS.json` and `references.bib` record primary sources and exact pins.
- `NOTICE.md` distinguishes original work from retained upstream materials.
- `SHA256SUMS` records the finished package's file hashes.

The report audits the three specifically requested ProveIt commits and later
intake, including the finite-sort obstruction, composite-collision diagnosis,
the public 253-state Coq development, and the corrected dispatcher-depth cost.
It includes ordinary mathematical proofs, not a claimed new formal kernel build.

## Main proposal

Use bound de Bruijn indices and separately tagged signed free names. Add four
whole-theorem free-name operations:

```text
up(a) = a + 1
down(a) = a - 1
swap exchanges 0 and 1
contract sends 0 to 1 and fixes every other name
```

Fresh universal instantiation followed by one conjugated contraction yields
arbitrary colliding instantiation. Together with the explicit classical Hilbert
core, this gives a complete equality-free proof system over closed theories.
Any map on a finite domain S is realized using exactly |S| - |image(S)|
contractions; this is optimal only for words in these map generators.

The fixed public refutation interface emits equality-free CP + GIC, without IR.
It accepts candidates containing matrices and proof instructions, constructs its
own closed axioms, and accepts only a reconstructed genuine Bottom. Equality
erasure through both incoming and outgoing relation profiles calibrates this
theory to upstream S0. Use `S0_equicons` and **`ZFCReg_equicons`** to reach
ordinary ZFC with Foundation and Choice.

The report proves a mathematical ZFC-level equivalence for the specified
unbounded source search. A new complete binary tape implementation and its
simulation theorem remain to be built and measured. The Python programs are
reference implementations subject to host resource limits; errors are not
accepted refutations.

## Concrete implementation results

- `code/contraction_kernel.py`: theorem-only reference Hilbert kernel,
  free-name factorization, and full-UI certificate construction.
- `code/fixed_theory_search.py`: exact main CP/GIC boundary and optional
  prior-work EPSC2 boundary; fixed schema emitters; fair shortlex reference search.
- `code/stream_renaming.py`: explicit binary formula codec and four fixed
  free-name transducers.
- `results/stream_transducers.json`: complete 92-row export of the four tables.
- `results/colliding_ui_certificate.json`: 10-line, one-contraction certificate
  crossing the source19 composite-instantiation diagnostic.

The transducers have **11, 11, 13, and 11 reachable control states**. They may
emit zero to three bits per input step and have an external stream interface.
These are **not ordinary binary Turing-machine state counts** and do not give
a state upper bound for the whole proof-search machine.

## Compression search results

| Experiment | Scope | Outcome |
|---|---|---|
| Exact 253-state quotient certificate | 31,878 state pairs; witnesses up to length 12 | No proper exact transition-structure quotient |
| Contextual runtime folds | 56,448 direct + 49,952 mixed-row specifications | Only the known prepared 252-state runtime survives; no certified blank startup |
| Full-logic compiler grid | 147,456 evaluated DAG recipes | Prior 268-state control unchanged |
| Closed-grammar rotation walk | 201,600 directed evaluations | 268 unchanged |

The quotient result is an exact theorem about transition homomorphisms, not a
lower bound on all equivalent machines. Most fold rejections exhausted the
symbolic budget or encountered an unsupported operation, and do not prove
inequivalence. Recipe/specification counts are not counts of distinct machines.

The `experiments/` READMEs contain exact commands, results, original dependencies,
licenses, and proof-scope qualifications. Full grids were run before path-only
packaging; the packaged fixed winner and independent certificates were replayed.

## Quick offline checks

Python 3.10+ and the standard library suffice. Run without `-O` or `-OO`.

```sh
python3 -B reproduce.py
```

This runs:

1. All **25** kernel, fixed-boundary, and integration tests.
2. The independent stream suite: 4,165 formulas, 16,660 primitive-map cases,
   7,539 finite-map factorizations, signed boundary and conjugation cases,
   complete transition witnesses, and 92 detected output mutations.
3. All 31,878 quotient witnesses against the exact 253-state table.
4. Exact regeneration of the 253 table/state maps and 6,460 instruction sites.
5. The fixed prior 268 recipe, with eight artifacts compared byte-for-byte.
6. Both independently checked 4,533-pair register certificates.

The command does not launch the infinite consistency search, repeat the full
optimization grids, access the network, or invoke Coq/Lean. Its temporary outputs
are cleaned up after comparison. The final executed quick-check report is in
`results/reproduction.json`; to write your own:

```sh
python3 -B reproduce.py --output /tmp/zfc-reproduction.json
```

Detailed full-grid commands are in `experiments/compiler/README.md` and
`experiments/machine_audit/README.txt`. Some of those drivers rewrite result
files beside themselves; run in a copy to preserve the original evidence.

## Build the PDF

```sh
make pdf
```

This invokes `latexmk -pdf`. The report uses standard LaTeX packages. Its
bibliography is embedded in `sections/08_references.tex`, so no BibTeX run is
required; `references.bib` is also supplied for reuse. `make clean` removes
ordinary LaTeX intermediates while retaining the PDF.

To rebuild the ZIP and its content manifest after an intentional edit:

```sh
python3 -B package.py --output /tmp/zfc_contraction_research.zip
```

The packager keeps experimental logs and nested provenance manifests, omits
temporary LaTeX files and Python caches, and fixes ZIP metadata. Its integrity
check covers the resulting archive; PDF producer metadata can change on rebuild.

## Baseline and proof status

The exact 253-state table is at:

```text
experiments/machine_audit/vendor/busy-beaver/ZF/m253/machine/zfc_253.tm
```

SHA-256:

```text
84a21f714017c1d491008d86e9bd19c43cc6c5c9ae99a538b4f2314387827d95
```

It has start state 0, 253 working states, terminal state 253, blank symbol 0,
and 506 transitions. Mira-emmy's reduction reuses Mira-Cult's 254-state
construction, Jeff's verification layers, and Andrew James Wade's framework.
This package does not claim authorship of either baseline machine.

Pinned public PR head:

```text
0d544f2a2e3c18f12278441a74b7879f31cbe856
```

The PR was open and unmerged when inspected. Its full external Coq verification
passed the actual public CI run at that head: 160 modules, 194 closed-context
assumption reports, and recursive `coqchk`. Metadata and a log excerpt are
included. No local Coq compiler was available, so this research does not claim
to have rerun that kernel build. The selected vendored proof sources are not
the complete upstream Coq dependency closure.

The final small-machine endpoint still requires a complete literal binary
implementation of the new frontend, blank initialization, arbitrary-runtime
simulation, fair enumeration, and the stated finite-refutation transports.

## Incorporation

The directory is suitable as a standalone incoming research report or as a new
attributed report directory. No existing repository files or remote branches
were modified. New original text/code follow ProveIt's MIT No Attribution
convention; retained third-party material keeps its original notices and
provenance, as explained in `NOTICE.md`.
