# Report56 Periodic Signal Machine Collision Certificates

4 October 2026. This release contains a 15-page mathematical report, editable self-contained LaTeX, the frozen proof and arithmetic artifacts, two independent audits, and isolated reproducibility tools.

## Main results

For a fixed rational, number-preserving signal machine and a supplied complete finite collision macro that returns to the same outgoing labels and co-location pattern, at most four live signals give a return section of dimension at most two. Validity of every finite repeated prefix has an explicit quadratic-sign formula. A literal sum-of-squares construction yields degree at most four and exactly one natural witness tuple on every accepted encoded input, with word-dependent arity.

The clock is tested as an observable, including exact cancellation, rather than by the spectral radius of the entire return matrix. Rational deadline queries are included. A four-signal spectator example has an included limiting boundary and a Zeno clock despite spectral radius one. For every fixed finite population, valid ultimately periodic rational macros have rational finite accumulation times and rational limiting positions.

## Scope that must remain attached to the results

- The machine and complete word are fixed compiler data; initial gaps are variable inputs
- Each batch includes all simultaneous sites and incident signals, with strictly positive times between batches
- Distinct incoming/outgoing speeds are the standard rule convention
- Arity depends on the word; no uniform arity or optimal operation count is claimed
- Witness uniqueness is per supplied integer encoding, not across all encodings of a rational geometry
- The general machine-and-macro chamber frontend is mathematically specified but not implemented
- The implemented generic stage begins with a quadratic sign formula and emits its literal residuals and expanded ordinary quartic
- All semantics concern finite prefixes before accumulation; no continuation through the accumulation instant is supplied
- No generic MRDP result, arbitrary-order Positivity theorem, general liveness algorithm, population minimality, or literature-priority claim is made

## Files

- `article/Report56.pdf`: complete report with proofs and analytic spacetime diagram
- `article/Report56.tex`: editable, self-contained LaTeX source
- `science/PROOF.md`: original proof, kept byte-for-byte after independent mathematical PASS
- `science/exports/four_signal_quartic.json`: 10-witness, 15-residual, 65-monomial degree-four certificate for the physical spectator example
- `science/exports/quadratic_sign_quartic.json`: 17-witness, 24-residual, 117-monomial degree-four recurrence diagnostic; no signal realization asserted for that matrix
- `science/`: full frozen handoff, exact check receipts, and inert source text used for comparison
- `independent_audit/AUDIT.md`: complete independent mathematical audit
- `independent_audit/emitted-artifact-audit/AUDIT-ADDENDUM.md`: separate exact residual and expanded-coefficient audit of both exported quartics
- `audit_replay/`: newly authored, inspected, byte-pinned four-stage arithmetic replay; execution contract, preserved-provenance evidence, tool safety review, and 44 positive/adversarial tests
- `verification/`: PDF build, layout, and visual-inspection evidence
- `manuscript_review/`: fresh independent report-level PASS, exact export reconstruction, and preserved final-page renders
- `release.py`: exact verification, deterministic PDF build, stored ZIP creation, and one-time author seal
- `MANIFEST.json`: final exact file/directory/byte/mode inventory, excluding itself

The reviewed proof SHA-256 is `df7cefb472a76e6f34ce7fff0b1e8548782a82f4863fac2ecd2d682c69941a77`. Source comparisons are pinned to repository commit `e3e58a8820593857650bb7a0193a11ec32db67d6`. Saved source text hashes are not Git blob identifiers. The full merged upstream article was not obtained; this proof does not rely on an unread theorem from it.

The final manuscript review passes on TeX SHA-256 `8c5f54158e5ca70cc7d92497ee6fb6d32fb1e49d9a03b8aed14e0498e88642b6` and PDF SHA-256 `4853f8c578f42b7273d693199ce768f8b68c95fa8ee64433f959b122751136ea`. Two fresh isolated PDF builds produced identical bytes. All 15 final pages were inspected; the complete independent review is included.

## Reproduce safely

Use Python 3 with isolated mode and assertions enabled. Read `audit_replay/README.md` before executing. Each output must be an absolute new external path with an existing parent; reused, nested, and symlink-routed outputs are rejected.

    python3 -I audit_replay/replay_audit.py --output /absolute/new/report56-replay

The replay runs only the four inspected and immutable new arithmetic programs named by its contract. It reproduces author arithmetic, regenerates both literal quartics, runs independent recurrence algebra, and independently checks the newly generated polynomial coefficients. Original inputs and read-only snapshots are preserved. The new programs are arithmetic checks, not a physical simulator or saved collision schedule. Source snippets from the upstream repository are never executed.

Use the trusted manifest digest from the separate delivery hash record to verify the final release:

    python3 -I release.py verify --manifest-sha256 TRUSTED_SHA256

Rebuild the self-contained PDF in another empty location with installed TeX Live packages and Latin Modern fonts:

    python3 -I release.py build-pdf --manifest-sha256 TRUSTED_SHA256 --output /absolute/new/report56-pdf

The recorded environment is pdfTeX 1.40.26 (TeX Live 2025/dev/Debian). Shell escape is disabled; UTC and source epoch 1791072000 fix the date. All three passes must succeed without unresolved references or overfull boxes. A sealed build requires byte identity with the packaged PDF. Exact byte reproduction depends on matching the installed engine, packages, and fonts.

Build the deterministic archive externally:

    python3 -I release.py archive --manifest-sha256 TRUSTED_SHA256 --output /absolute/new/Report56.zip

The ZIP is sorted, uncompressed (`ZIP_STORED`), and has fixed 2026-10-04 timestamps and pinned Unix modes. Preserve those modes when extracting if you intend to pass the exact mode verifier. The manifest digest must be retained outside the archive as a trust anchor. Hashes alone do not authenticate an untrusted tool or its embedded pins.

## Evidence and limits

The mathematical proof and independent audit establish the infinite statements. The separate artifact audit proves exact coefficient identities and reconstructs all gadgets and gate truth tables. Finite regressions support implementation fidelity but are not the proof of infinite validity or uniqueness. The arithmetic replay is intentionally incompatible with `-O` or `-OO`: the independent checks use assertions. A successfully optimized run would not provide the same evidence.

The analytic figure is derived from rational formulas; no physical trajectory engine, saved computation schedule, upstream program, downloaded executable, or post-accumulation model was run. No public repository was modified or external publication performed.
