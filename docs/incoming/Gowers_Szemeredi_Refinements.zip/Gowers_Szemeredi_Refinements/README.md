# Energy-Sensitive Inverse Steps and Sharp Density Extraction

Quantitative refinements of Gowers's Szemeredi argument.
Research article prepared for Vladimir Reshetnikov, October 6, 2026.

## Contents

- `gowers_refinements.pdf`: the 20-page article, with proofs and references.
- `gowers_refinements.tex`: self-contained LaTeX source; bibliography is inline.
- `verify.py`: finite numerical and exact-rational regression checks.
- `verification_results.json`: results of the recorded verification run.
- `requirements.txt`: Python dependency for the verification script.
- `build.sh`: a small shell wrapper for compiling the article.

## Main results

Theorem 3.1 extends Gowers's Proposition 6.1 to two arbitrary complex functions
and nonnegative weighted, potentially multivalued spectra on any finite abelian
group. It retains exact L2 and U3 factors, with coefficient-one equality examples.
Corollary 4.2 specializes the estimate to balanced indicators and their variance.
Section 5 includes full-spectrum energy certificates, exact Cauchy--Schwarz
loss identities, quantitative alignment, and an exact quadratic-phase endpoint.

Theorem 6.1 proves a sharp real-valued phase-freezing inequality. Theorem 7.1
solves the weighted positive-tail extremal problem relevant to cell selection.
Corollary 7.3 directly strengthens the size conclusion of Gowers's Lemma 5.15.
Sections 8 and 9 combine these statements into a phase-to-density interface and
optimize the uniform phase tolerance in closed form.

Section 11 proposes seven further research directions, with explicit targets.
Appendix A records source blob identifiers and a Fourier-normalization checklist.

## Mathematical and verification status

The weighted-energy, phase-geometry, and moment statements have complete written
proofs. The progression-length specialization explicitly assumes the polynomial
partition input PP(K,R0); its application imports the corrected Corollary 5.6
from the supplied repository. That substantial input is not reproved here.

This work claims local quantitative refinements, not a new best global bound for
Szemeredi's theorem. Publication priority for the exact formulations has not been
established. None of the new proofs has been compiled or kernel-checked in Lean.
The article provides an integration plan, not a purported Lean formalization.

The recorded fixed-seed run checks 490 random energy instances, 2,500 real-phase
instances, 3,000 zero-mean moment instances, 1,500 nonzero-mean moment instances,
and 1,500 phase-budget optimization instances: 8,990 random cases in total.
It also tests three mathematically exact equality families numerically and
checks two rational examples using exact fractions. Numerical tests are
regression checks, not proofs. Optimization tests compare with dense grids;
the continuous optimization proof is in the article.

## Rebuild the PDF

Use a TeX installation containing pdflatex and the standard packages named in
the source. No external bibliography files or graphics are needed.

    latexmk -pdf -interaction=nonstopmode -halt-on-error gowers_refinements.tex

Alternatively run `sh build.sh`. On Windows the latexmk command can be run
directly in a terminal. The script falls back to three pdflatex passes when
latexmk is absent.

## Run the checks

Use Python 3.10 or later and NumPy:

    python -m pip install -r requirements.txt
    python verify.py

Run Python normally, without `-O`, because the verifier uses assertions.
The run overwrites `verification_results.json` next to the script. Random seed:
20261006. Minor floating-point formatting can depend on the numerical runtime.

## Source scope

The source comparison targets the supplied ProveIt paper transcription and
selected files in its GowersSzemeredi Lean development. Exact inspected blob
SHAs and the observed branch ref are recorded in Appendix A. This is not an
exhaustive audit of the repository or a report that the entire development builds.
No third-party paper files, font files, or repository code are redistributed.
