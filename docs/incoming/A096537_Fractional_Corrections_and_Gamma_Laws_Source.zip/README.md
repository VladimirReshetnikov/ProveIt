# Report193

Fractional Corrections and Gamma Laws for Exponential Towers

This sequel proves the first relative fractional correction for the known
shifted family F_y(x)=exp(x y F_(y+1)(x)), uniformly on compact positive real
shift sets. Its common correction is an exact Airy integral; a reproducible
interval certificate proves -0.61 < c1 < -0.25. The report also proves the Gamma
prefactor, the ancestor-root-choice central limit theorem, a local complex
Gamma correction with fixed cumulant constants, a positive-real Borel boundary
expansion, and threshold inverses at the fractional scale.

Files:
- Report193.pdf: full article
- Report193.tex: editable source
- code/: exact finite checks and interval certificate, with its own README
- generated/: deterministic receipts from the release build
- build.py, test_build.py, verify_manifest.py: offline builder and integrity tools
- README_REPRODUCIBILITY.md: commands and trust boundaries
- DATA_SOURCES.md: attribution and the scope of source comparison
- SHA256SUMS.json: closed release inventory with lengths and SHA-256 digests

From an extracted release, the code-only mandatory replay is:

    python -I -S -B code/reproduce.py --output-dir /path/to/fresh-results

It runs both ordinary and optimized Python, regenerates the adaptive partition,
recomputes all 562 terminal panels, and requires byte-identical receipts. No
network, TeX, external Python library, or ordinary floating diagnostic is needed.
The output directory must not exist; its parent must exist and be nonsymlinked.

To rebuild the complete PDF and ZIP into a fresh directory outside this package:

    python -I -S -B build.py --output /path/to/fresh-release

Python 3.12+ and an installed pdfLaTeX stack are required for the full build.
The builder compiles in isolated temporary storage, disables shell escape,
runs all mandatory checks, and verifies the closed source inventory. It does
not overwrite existing files or directories.

To check the received release without changing it:

    python -I -S -B verify_manifest.py

The certified broad interval is not a certified decimal expansion, an effective
finite-n error bound, or a proof of monotonicity of the normalized coefficients.
The ordinary numerical value -0.43652529 is illustrative only. No all-orders
coefficient theorem, global complex row-PGF theorem, row-statistic local limit,
complex Borel-sector expansion, or absolute novelty claim is made.
