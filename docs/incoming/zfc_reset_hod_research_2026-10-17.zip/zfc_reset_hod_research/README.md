# Reset synchronization and HOD calibration

Research prepared for Vladimir Reshetnikov, 17 October 2026.
Source snapshot: `fab89c5d26b81cd2ccab2ee5d213ff23725c7726` in
[VladimirReshetnikov/ProveIt](https://github.com/VladimirReshetnikov/ProveIt).

## Main result and scope

**No machine below 252 working states was obtained.** The main new theorem
proves that the unchanged six-field proof enumerator may start at any of
the counters `{0, 1, 2, 4, 5, 6}` with arbitrary current formula, stack,
additive parameter, and cached formula. It still halts exactly when the
original numerical calculus derives falsity. The report proves a general
finite stack-credit theorem and a finitely computable exact credit for a
conservative command-effect model. A reference classifier certifies 215
of the first 256 clean control counters.

The report also develops the classical HOD interpretation as an alternative
way to close the present Choice-removal interface. It addresses internal
formula codes, internally finite ordinal tuples, the exact selector axiom,
and the separate arithmetic proof-compiler obligation. HOD itself is not
claimed as a new theorem. None of the new mathematics is represented as a
newly compiled Lean or Coq development.

The fresh machine experiments include two complete finite censuses of
arbitrary two-row state fusions at the exact 252-state baseline, all 238
joint decoder rotations, and 66,413 stochastic multi-rotation proposals.
No 251-state candidate was obtained. Both fusion runs exhaust a formal
domain of 32,134,040,064 recipes under their precisely stated bounded
certificate criteria. Partial evaluation prunes that domain; this is not
a claim that 32 billion full tables were individually simulated.

A targeted startup audit finds that all 504 rows are covered by the
current runtime checks or register-box contracts. No startup-only row can
be freely changed while preserving that complete contract footprint.
This is a scoped proof-footprint result, not a semantic lower bound.

## Read and reproduce

- `report.pdf`: complete report.
- `report.tex`, `sections/`, `references.tex`: full LaTeX source.
- `baseline/`: exact canonical baseline and complete boot manifest.
- `reset/`: new reference computations, source inputs and retained evidence.
- `machine/`: portable search packet, complete ledgers and attributed inputs.
- `provenance/`: source and claim-status records.
- `SHA256SUMS`: all distributed file identities except the checksum file itself.

From the unpacked root:

```sh
python3 code/verify_bundle.py
python3 code/verify_bundle.py --full
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

The first command requires Python 3.11+ with its standard library. It
replays the exact complete blank bootstrap, all numerical reset and credit
checks, all 8,391 affine instruction cases, and the startup footprint. The
second additionally requires a C++17 compiler and reproduces both complete
fusion ledgers; allow several minutes. No network, package installation,
Lean or Coq executable is needed for these finite checks. Generated large
window sets, executables and replay output stay in a temporary directory.

The short commands can also be run separately:

```sh
python3 code/audit_baseline.py --output /tmp/zfc252-baseline.json
python3 reset/late_start_credit.py --output /tmp/zfc252-reset.json
python3 machine/code/reproduce.py --quick
python3 reset/startup_protected_audit.py \
  --machine-code machine/code \
  --table machine/inputs/permutation252_old.tm \
  --output /tmp/zfc252-startup.json
```

See `machine/README.md` for exhaustive and stochastic replay options.
The bundled Lean files are immutable source inputs, not a standalone
formal project. The full dependency environment remains at the pinned
ProveIt commit.

## Integration and attribution

The most concrete first formalization target is the six-counter arbitrary
working-data theorem, followed by the general credit interface and the
existing dirty-root correspondence. HOD and arithmetic internalization
remain distinct milestones. This packet does not modify the repository,
make an upstream submission, or declare those milestones completed.

The baseline machine and its proof-search calculus are attributed to
Mira-Cult, Jeff Ketchersid, Andrew James Wade, mira-emmy, and the ProveIt
contributors as specified in the report and source notices. The marked
NIP-to-DROP injection, source27 decoder rotations, affine checker and
incoming fusion algorithm are inherited and explicitly attributed.
The new result strengthens that injection's application to initialization;
the new searches apply and extend the existing methods at the exact252
baseline. Retained licensing is in `LICENSE-ProveIt.txt` and
`machine/LICENSE-Wade.txt`. New original material is supplied on the same
MIT No Attribution terms for incorporation into ProveIt.
