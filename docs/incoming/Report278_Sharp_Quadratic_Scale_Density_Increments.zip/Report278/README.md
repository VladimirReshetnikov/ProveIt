# Report278 Sharp quadratic scale density increments on cyclic groups

This package contains a self-contained mathematical article, its editable TeX source, and an offline reproducible bounded exact companion.

For N >= L >= 2, put m = max{h : h divides N, h < L} and q = N/m. Every nonempty proper subset A of Z/NZ, with density delta, has a proper L-term modular progression with density at least

    delta + (1-delta) max(q-L,0) / (L(q-1)).

The gain (1-delta)/(2L) therefore holds under N >= 2(L-1)^2+1. For each real C > 1, the largest density-uniform coefficient under N >= C L^2 is exactly 1-1/C in front of (1-delta)/L. Prime-quotient sets attain the arithmetic formula exactly. A separate sliding-window theorem gives a density-sensitive gain greater than delta(1-delta)/(2L) whenever N > L(L-1), with a stronger explicit coefficient involving the proportion of short-order steps. Dense examples at N=L(L-1) show that strict threshold cannot be dropped. The endpoint coefficient is not claimed optimal.

Proper means all displayed points are distinct. Wrapping and nonunit steps are allowed. The finite-abelian extension has an explicit admissible-support hypothesis. The bounded-function version uses variance divided by the mean, which cannot in general be replaced by 1-delta.

The article also proves a sparse affine-cover consequence: the earlier independent variance cap (N/8)^(1/3) becomes sqrt(N/2), while the phase-dependent term and gain remain unchanged. This does not change any all-degree phase-localization exponent. The covariance/range tools are classical; the optimal positive-definite zero-step mass is a specialization of Kolountzakis–Révész's Turán packing theorem. No priority, formal-verification, parent-containment, ordinary-integer rectification, or global Ramsey/Szemerédi improvement is claimed.

## Files

- `Report278.pdf`: article
- `article.tex`: complete editable TeX, including bibliography
- `companion/exact_checks.py`: bounded exact arithmetic diagnostics
- `tests/test_companion.py`: mathematical regressions, validation and CLI tests
- `tests/test_build.py`: builder, manifest, filesystem, subprocess and archive regressions
- `build.py`: deterministic offline builder and packager
- `SOURCES.md`: primary references, pinned comparisons and scope limits
- `MANIFEST.sha256`: pins for the other eight public files

## Run the bounded companion

Python 3.11 or later is required by the full build/test workflow; the companion uses only the standard library. From the extracted Report278 directory:

    python3 -I -B -X int_max_str_digits=640 companion/exact_checks.py
    python3 -I -B -X int_max_str_digits=640 companion/exact_checks.py --full
    python3 -I -B -X int_max_str_digits=640 -O companion/exact_checks.py --full
    python3 -I -B -X int_max_str_digits=640 tests/test_companion.py
    python3 -I -B -X int_max_str_digits=640 tests/test_build.py

The package has 35 companion tests and 33 builder tests. The default exhaustive maximum modulus is 8; `--full` uses 12. An explicit `--nmax N` from 2 through 12 overrides the profile maximum. Both profiles use exact integer/Fraction arithmetic and deterministic sorted JSON. Normal and optimized output must agree. These computations are diagnostics, not proofs of universal statements.

Default / full checks include:

- 3,020 / 81,792 nonempty proper subset-length triples (N,L,A) for the arithmetic and geometric increment bounds, including supported-step maxima
- 3,076 / 16,388 candidate admissible supports, at N <= 8 / 10
- 35 / 91 prime-quotient extremizer cases
- 1,310 / 34,038 subset-length triples satisfying the endpoint's two arithmetic hypotheses; 872 / 16,216 meet N > L(L-1)
- 80 / 194 sampled endpoint proof cases, containing 2,216 / 10,850 exact sliding-window identities and the shift-to-coset averaging identity
- 18 / 30 dense prime-boundary cases

Both profiles also check 168 rational bounded-function cases, 672 associated covariance identities, 280 signed square identities, 56 iid collision cases, 28 positive-definite autocorrelation mixtures, 189 half-gain boundaries, 252 coefficient ceilings, 315 rational-C cases, 192 root ceilings, and 13 affine scalar assembly toys. The scalar affine toys verify algebra and exact rounding, not the existence of an actual cover or its complex correlation premise. The inequality pi < 4 is an analytic input, not a computed certificate.

Public helpers include `arithmetic_parameters`, `proper_support`, `maximum_density`, `exhaustive_theorem`, `maximal_support_diagnostics`, `difference_law`, `square_covariance`, `function_diagnostic`, `positive_definite_mixture`, `prime_extremizer`, `endpoint_diagnostic`, `dense_prime_boundary`, `half_gain_length`, `coefficient_budget`, `rational_constant_bound`, `affine_scalar_assembly`, and `run_checks`. Their docstrings state exact domains and semantics. Runtime input validation rejects booleans, floats, oversized collections and unbounded iterables, and remains active under -O.

Key caps: exhaustive modulus 12; structural/explicit-window modulus 64; moment modulus 24; arithmetic-parameter modulus and coefficient-budget length 10^6; selected scalar integers below 2^128; rational numerators/denominators below 2^64; prime diagnostic parameter at most 23. Domain-specific helpers can impose tighter limits. These bounds apply only to the computation, not to the mathematical theorem.

## Rebuild and package offline

Requirements: Linux, Python 3.11 or later, `/proc/self/fd`, and a trusted system TeX installation with `/usr/bin/pdftex`, `/usr/bin/pdflatex`, lmodern, amsmath, amssymb, amsthm, mathtools, geometry, microtype, enumitem, booktabs, xcolor and hyperref. No network or third-party Python package is used.

Verify a source-only inventory or a manifest-pinned distribution:

    python3 -B build.py verify

Run the default diagnostics and both test suites in normal and optimized modes, compile the article and build the deterministic ZIP in a fresh external directory:

    python3 -B build.py reproduce --output /tmp/report278-rebuild

Use an absent or empty absolute directory outside the source, not its ancestor and not a protected system location. Existing outputs are never overwritten. The source inventory and bytes are checked before and after the operation. The full mathematical diagnostic profile is available through the separate `--full` commands above; it is not silently substituted for the builder's default profile.

Outputs include Report278.pdf, report278_sharp_variance.zip, its SHA-256 sidecar, MANIFEST.sha256, reproduction_receipt.json, and staging/log files. Staging and logs are excluded from the nine-member public ZIP. Starting from a manifest-pinned distribution requires reproduced PDF bytes to match the pinned PDF exactly. Reproduction depends on the TeX engine, package versions, fonts and compression toolchain; a mismatch is reported rather than silently accepted.

To package a checked manifest-pinned distribution without compiling:

    python3 -B build.py package --output /tmp/report278-package

Archive member order, timestamps and permissions are fixed; extra fields and comments are empty. CRCs, member bytes and exact inventory are checked. The external ZIP hash sidecar pins the actual archive bytes. Diagnostic stdout must match across normal/optimized Python; test-runner timings on stderr need not match.

## Trust boundary and interpretation

The builder is designed for these supplied trusted sources and installed trusted tools. It uses bounded reads, exact inventory allowlists, no-follow directory and file descriptors, single-link regular-file checks, exclusive output creation, a minimal child environment, process time/output limits and disabled TeX shell escape. Its regression tests exercise documented inventory, packaging and filesystem cases.

These safeguards are not a sandbox for arbitrary hostile TeX/Python or a guarantee against an actively malicious concurrent filesystem owner. The compiler and installed TeX resources remain trusted. A manifest verifies agreement with a supplied digest list, not authorship, literature priority, or mathematical truth. The article's written arguments establish its unrestricted mathematics; neither passing finite checks nor a bounded source screen replaces them.
