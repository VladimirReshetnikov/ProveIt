from pathlib import Path
import json,sys,hashlib
from check_fold213 import read,need
P=Path(sys.argv[1]);BASE=Path(sys.argv[2]);OUT=Path(sys.argv[3])
old=json.load(open(BASE/'u214.sites.json'));T=read(BASE/'u214.native.tm')
def tree(rows):
 D={p:(o,a)for p,o,a in rows}
 def go(p):return D[p]if p in D else(go(p+'0'),go(p+'1'))
 return go('')
def leaf(t):return isinstance(t[0],str)
def sites(t,p=''):return[[p,*t]]if leaf(t)else sites(t[0],p+'0')+sites(t[1],p+'1')
def bound(t):
 if leaf(t):
  o,a=t;return(1 if o=='CD'else a if o=='CB'else 0,a if o=='CC'else 0,o=='CH')
 a,b=bound(t[0]),bound(t[1]);return(max(a[0]-1,b[0],0),max(a[1],b[1]-1,0),a[2]or b[2])
def sub(t,p):
 for b in p:t=t[int(b)]
 return t
def repl(t,p,v):
 if not p:return v
 b=int(p[0]);return(repl(t[0],p[1:],v),t[1])if b==0 else(t[0],repl(t[1],p[1:],v))
def cfg(rows):
 intervals={}
 for i,(p,o,a)in enumerate(rows):
  for n in range(len(p)+1):
   k=p[:n]
   if k not in intervals:intervals[k]=[i,i+1]
   else:intervals[k][1]=i+1
 out=[]
 for i,(p,o,a)in enumerate(rows):
  if o=='CI':dst=(i+1,)
  elif o=='CH':dst=()
  else:
   bit='1'if o=='CC'else'0';n=a if o!='CD'else 1;ix=[k for k,c in enumerate(p)if c==bit];need(n<=len(ix),'escaping');anc=p[:ix[-n]];d=intervals[anc][0 if o=='CC'else 1];dst=(d,i+1)if o=='CD'else(d,)
  out.append((o,a,dst))
 return out
def prefix(T,p):
 cells={-1:1,**{i:int(b)for i,b in enumerate(p)}};before=dict(cells);q=84;h=0
 for _ in range(10000):
  if h==len(p):need(cells==before,'prefix changed');return q
  need(h in cells,'prefix exterior');w,d,q=T[q,cells[h]];cells[h]=w;h+=d
 raise ValueError('prefix timeout')
root=tree(old);originalCFG=cfg(old);records=[]
for rr in json.load(open(P/'recipe.json'))['rotations']:
 q,r,side=rr['q'],rr['r'],rr['side'];need(all(T[x,b][:2]==(b,1)for x in(q,r)for b in(0,1)),'nonpure');need(T[q,side][2]==r,'not child');need([(x,b)for(x,b),v in T.items()if v[2]==r]==[(q,side)],'inner shared')
 for path in rr['paths']:
  need(prefix(T,path)==q and prefix(T,path+str(side))==r,'prefix binding');n=sub(root,path)
  if side:a,(b,c)=n;new=((a,b),c)
  else:(a,b),c=n;new=(a,(b,c))
  need(all(bound(x)==(0,0,False)for x in(a,b,c)),'nonclosed factor');root=repl(root,path,new)
 if side:
  a,b,c=T[q,0][2],T[r,0][2],T[r,1][2];T[q,0]=(0,1,r);T[q,1]=(1,1,c);T[r,0]=(0,1,a);T[r,1]=(1,1,b)
 else:
  a,b,c=T[r,0][2],T[r,1][2],T[q,1][2];T[q,0]=(0,1,a);T[q,1]=(1,1,r);T[r,0]=(0,1,b);T[r,1]=(1,1,c)
 need(cfg(sites(root))==originalCFG,'CFG changed');records.append([q,r,side])
need(T==read(P/'rotated214.tm'),'pre-fold table differs');need(sites(root)==json.load(open(P/'sites.json')),'source differs');out={'status':'PASS','rotations':records,'closed_factors':True,'exact_CFG_equal':True,'primitive_count':len(old),'source_sha256':hashlib.sha256((P/'sites.json').read_bytes()).hexdigest(),'scope':'closed source rotations and exact table reconstruction, not physical runtime proof'}
print(json.dumps(out,indent=2));OUT.write_text(json.dumps(out,indent=2)+'\n')
