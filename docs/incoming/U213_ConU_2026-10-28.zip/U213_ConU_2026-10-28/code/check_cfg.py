#!/usr/bin/env python3
import argparse,json,hashlib
from pathlib import Path
from check_source_invariant import graph,require
p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();B=json.loads(a.baseline.read_text());N=json.loads(a.candidate.read_text());require(len(B)==len(N),'site count');require([x[1:]for x in B]==[x[1:]for x in N],'ordered operations');G=graph(B);require(G==graph(N),'ordered successors');r={'status':'EXACT_ORDERED_CFG_PASS','source_sites':len(B),'successor_edges':sum(map(len,G)),'operation_and_operand_order_equal':True,'arithmetic_successors_equal':True,'original_sha256':hashlib.sha256(a.baseline.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(a.candidate.read_bytes()).hexdigest()};a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(r,indent=2)+'\n');print(r['status'])
