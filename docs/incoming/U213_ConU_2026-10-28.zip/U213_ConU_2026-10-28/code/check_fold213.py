"""Independent tag-fold checker, two-cell opaque exterior, explicit checks under -O."""
from pathlib import Path
import argparse,json,hashlib

def need(v,msg):
 if not v:raise ValueError(msg)
def read(p):
 T={};starts=[]
 for line in p.read_text().splitlines():
  if line.startswith('#! start '):starts.append(int(line[9:]));continue
  if not line or line.startswith('#'):continue
  q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z));need((q,b)not in T and b in(0,1)and w in(0,1)and d in('L','R'),'invalid row');T[q,b]=(w,1 if d=='R'else-1,z)
 need(starts==[0],'start');S={q for q,b in T};need(set(T)=={(q,b)for q in S for b in(0,1)},'partial');need({z for w,d,z in T.values()}-S=={254},'target');return T
def verify(A,B):
 keep,drop,helper,branch=214,115,155,0
 need(len(A)==428 and len(B)==426,'state census')
 f=lambda q:keep if q==drop else q
 E={(q,b):(w,d,f(z))for(q,b),(w,d,z)in A.items()if q!=drop};E[keep,branch]=(branch,-1,helper)
 need(B==E,'not exact quotient')
 incoming={q:[(a,b,w,d)for(a,b),(w,d,z)in A.items()if z==q]for q in(keep,drop)}
 for q,tag in((keep,0),(drop,1)):
  need(q!=0 and incoming[q] and all((w,d)==(tag,1)for a,b,w,d in incoming[q]),'entry guard')
 cases=[]
 for q,tag in((keep,0),(drop,1)):
  for bit in(0,1):
   tape={-1:tag,0:bit};w,d,z=A[q,bit];expected=(f(z),d,{-1:tag,0:w});state=f(q);head=0;cells=dict(tape);trace=[]
   for n in range(1,14):
    need(state!=254 and head in cells,'opaque read or halt')
    rb=cells[head];nw,nd,ns=B[state,rb];trace.append([state,head,rb,nw,nd,ns]);cells[head]=nw;head+=nd;state=ns
    if(state,head,cells)==expected:break
   else:raise ValueError('endpoint mismatch')
   cases.append({'state':q,'preceding':tag,'read':bit,'new_steps':n,'trace':trace,'endpoint':[state,head]})
 return {'incoming':incoming,'cases':cases}
def main():
 p=argparse.ArgumentParser();p.add_argument('directory',type=Path);p.add_argument('--out',type=Path);a=p.parse_args();A=read(a.directory/'rotated214.tm');B=read(a.directory/'u213.native.tm');r=verify(A,B);controls=[]
 for label,key,value in [('wrong helper',(214,0),(0,-1,154)),('wrong unaffected row',(0,0),(0,1,94))]:
  C=dict(B);C[key]=value
  try:verify(A,C)
  except ValueError as e:controls.append([label,str(e)])
  else:raise ValueError('mutation accepted')
 # Alter a helper in both old and new: structural quotient remains, behavior must fail.
 for key in[(155,0),(155,1)]:
  X=dict(A);Y=dict(B);w,d,z=X[key];X[key]=Y[key]=(1-w,d,z)
  try:verify(X,Y)
  except ValueError as e:controls.append([str(key)+' helper-write',str(e)])
  else:raise ValueError('helper mutation accepted')
 r.update(status='PASS',old_states=214,new_states=213,sha256={n:hashlib.sha256((a.directory/n).read_bytes()).hexdigest()for n in('rotated214.tm','u213.native.tm','sites.json')},negative_controls=controls,scope='All runs from state0 on arbitrary initial tape; source/runtime calibration separate')
 s=json.dumps(r,indent=2)+'\n'
 if a.out:a.out.write_text(s)
 print(s,end='')
if __name__=='__main__':main()
