#!/usr/bin/env python3
"""Synthesis-only engine-row filter, with full universal primitive checks."""
import argparse,json,hashlib,time
from pathlib import Path
import check_runtime as c
s=c.s
p=argparse.ArgumentParser();p.add_argument('--table',required=True,type=Path);p.add_argument('--sites',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args();raw=a.table.read_bytes();source=a.sites.read_bytes();T=c.boot.load_table(a.table);S=c.sites_checked(source);L,B=s.prove_blocks(T);rows=set();cases=0;began=time.monotonic()
for cert in B:
 for ev in cert['trace']:
  if ev[0]!='list':rows.add(ev[1][:2])
for i,site in enumerate(S):
 for positive in ((False,True)if site[1]=='CD'else(False,)):
  ans=s.case(T,L,site,positive,keep_trace=True);motion=s.ZERO;engine=False;found=False
  for event in ans['trace']:
   if event[0]!='list' and event[1][0]==84 and motion==s.ZERO:engine=False
   if engine and event[0]!='list':rows.add(event[1][:2])
   if not engine and motion==s.num(len(site[0])-1):engine=True;found=True
   if event[0]=='literal':motion=s.add(motion,s.num(event[1][3]))
   elif event[0]=='unary':motion=s.add(motion,event[2]if event[1][3]==1 else s.neg(event[2]))
   else:motion=s.add(motion,s.var(12)if event[1][1]==1 else s.neg(s.var(12)))
  c.need(found,'selector boundary missing');cases+=1
 if i%500==0:print(i,cases,len(rows),flush=True)
c.need(a.table.read_bytes()==raw and a.sites.read_bytes()==source,'inputs changed');a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps({'status':'UNIVERSAL_RUNTIME_AND_SYNTHESIS_FILTER_PASS','rows':sorted(rows),'cases':cases,'sites':len(S),'table_sha256':c.sha(raw),'sites_sha256':c.sha(source),'seconds':time.monotonic()-began,'scope':'All symbolic primitive cases passed. Row filter is a synthesis aid only, excluding first event at final-selector position; candidates still require full fresh runtime/startup proofs.'},indent=2)+'\n');print('PASS',cases,len(rows),flush=True)
