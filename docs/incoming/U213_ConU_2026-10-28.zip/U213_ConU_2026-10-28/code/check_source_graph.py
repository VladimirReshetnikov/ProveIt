"""Source-only audit independent of the physical table builder.
Two upstream independently specified graph resolvers are reused with attribution.
"""
import argparse,json
from pathlib import Path
from source_language import tree,sites,graph_intervals,graph_arithmetic,metrics

def verify(a,b):
 tree(a);rt=tree(b)
 if [x[1:]for x in a]!=[x[1:]for x in b]:raise ValueError('ordered primitives differ')
 if graph_intervals(a)!=graph_arithmetic(a)[0] or graph_intervals(a)!=graph_intervals(b)or graph_intervals(b)!=graph_arithmetic(b)[0]:raise ValueError('CFG mismatch')
 return {'status':'SOURCE_GRAPH_PASS','sites':len(b),'four_resolvers_equal':True,'metrics':metrics(rt)}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('candidate',type=Path);a=p.parse_args();x=json.loads(a.baseline.read_text());y=json.loads(a.candidate.read_text());r=verify(x,y);mutations={}
 v=json.loads(json.dumps(y));v.pop();mutations['missing leaf']=v
 v=json.loads(json.dumps(y));v.append(v[-1]);mutations['duplicate leaf']=v
 v=json.loads(json.dumps(y));i=next(i for i,z in enumerate(v)if z[1]=='CB');v[i][2]+=1;mutations['changed branch depth']=v
 v=json.loads(json.dumps(y));i=next(i for i,z in enumerate(v)if z[1]=='CI');v[i][2]=(v[i][2]+1)%9;mutations['changed register']=v
 rejected=[]
 for name,v in mutations.items():
  try:verify(x,v)
  except(ValueError,KeyError,IndexError):rejected.append(name)
  else:raise ValueError('negative control accepted: '+name)
 r['negative_controls_rejected']=rejected;print(json.dumps(r,sort_keys=True))
