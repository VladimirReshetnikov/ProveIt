#!/usr/bin/env python3
"""Independent product-category fixed point and explicit postfixed-point verification."""
import argparse,json,hashlib
from pathlib import Path
from collections import deque

def require(b,m):
 if not b:raise ValueError(m)
def graph(rows):
 leaves={p:i for i,(p,o,a)in enumerate(rows)};depth=max(map(len,leaves))
 def first(p):
  w=p+'0'*depth
  for j in range(1,depth+1):
   if w[:j]in leaves:
    require('1'not in p[j:],'stray suffix');return leaves[w[:j]]
  raise ValueError('unresolved source')
 def successor(p):return format((int(p or '0',2)+1)%(2**len(p)),'0'+str(len(p))+'b')if p else''
 def cut(p,b,n):
  loc=[i for i,x in enumerate(p)if x==b];return p[:loc[-n]]if len(loc)>=n else''
 G=[]
 for p,o,a in rows:
  if o=='CH':G.append([])
  elif o=='CI':G.append([first(successor(p))])
  elif o=='CD':G.append([first(successor(cut(p,'0',1))),first(successor(p))])
  elif o=='CB':G.append([first(successor(cut(p,'0',a)))])
  elif o=='CC':G.append([first(cut(p,'1',a))])
  else:raise ValueError('operation')
 require(first('')==0,'initial leaf');return G

def successors(row,targets,box):
 _,op,a=row
 if op=='CH':return []
 if op in('CB','CC'):return [(targets[0],box)]
 out=[]
 if op=='CI':
  b=list(box);b[a]=frozenset(min(k+1,4)for k in box[a]);return[(targets[0],tuple(b))]
 if 0 in box[a]:
  b=list(box);b[a]=frozenset([0]);out.append((targets[0],tuple(b)))
 if box[a]-{0}:
  b=list(box);z=set()
  for k in box[a]-{0}:z.update([3,4]if k==4 else[k-1])
  b[a]=frozenset(z);out.append((targets[1],tuple(b)))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--sites',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args();raw=a.sites.read_bytes();rows=json.loads(raw);G=graph(rows);seed=tuple(frozenset([v])for v in[4,0,0,0,0,0,0,0,0]);inv={0:seed};todo=deque([0]);steps=0
 while todo:
  i=todo.popleft();steps+=1
  for j,b in successors(rows[i],G[i],inv[i]):
   old=inv.get(j,tuple(frozenset()for _ in range(9)));new=tuple(x|y for x,y in zip(old,b))
   if new!=old:inv[j]=new;todo.append(j)
 # Separate postfixed-point verification, without relying on worklist stopping.
 require(all(seed[k]<=inv[0][k]for k in range(9)),'seed excluded');edges=0
 for i,box in inv.items():
  require(len(box)==9 and all(v and v<={0,1,2,3,4}for v in box),'bad product category')
  for j,b in successors(rows[i],G[i],box):
   require(j in inv and all(b[k]<=inv[j][k]for k in range(9)),'not inductive');edges+=1
 claims=[]
 for i,b in inv.items():
  if rows[i][1]=='CD':
   vals=b[rows[i][2]]
   if vals=={0}:claims.append([i,'always zero'])
   elif 0 not in vals:claims.append([i,'always positive'])
 report={'status':'INDUCTIVE_SOURCE_CATEGORY_PASS','sites_sha256':hashlib.sha256(raw).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sites':len(rows),'reachable_sites':len(inv),'worklist_steps':steps,'closure_edges':edges,'dead_sites':[i for i in range(len(rows))if i not in inv],'one_sided_decrements':sorted(claims),'initial_registers':[4,0,0,0,0,0,0,0,0],'category4':'all naturals at least4','scope':'Source execution from calibrated seed only. Product overapproximation; not a claim for arbitrary initial register values.','invariant':{str(i):[sorted(v)for v in b]for i,b in sorted(inv.items())}}
 require(a.sites.read_bytes()==raw,'source changed');a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='invariant'},indent=2))
if __name__=='__main__':main()
