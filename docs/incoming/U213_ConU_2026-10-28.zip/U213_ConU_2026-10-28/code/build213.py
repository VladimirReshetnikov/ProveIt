#!/usr/bin/env python3
"""Deterministic eight-rotation construction; no optimizer or network access.
Requires the separately attributed source_language.py from the U214 input.
Runtime and blank-start correctness are separate verification obligations.
"""
import argparse,hashlib,json
from pathlib import Path
from source_language import tree,sites,leaf,boundary,subtree,replace,graph_arithmetic,graph_intervals,metrics
BASE_TABLE='5fa7d923456ea7fb3e9cb331946e49750970bbffbfa755c0639bdaa9b7afd8a8'
BASE_SOURCE='9428a13d4c228e9760e8f546e43527ee5e196ae667ad2386ddabf961b477d083'
FINAL_TABLE='9bd9145a7e0aebb04ed5376da96f7ab48271c50954b688909f7d172cab1c5ee2'
FINAL_SOURCE='d2ac2ea66ba792394c68f65212de2c9d680088a7c40112eab774ccedfce757e2'
def need(c,m):
 if not c:raise ValueError(m)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def parse(raw):
 t={};starts=[]
 for line in raw.decode().splitlines():
  if line.startswith('#! start '):starts.append(int(line[9:]))
  elif line and not line.startswith('#'):
   q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z));need((q,b)not in t and b in(0,1)and w in(0,1)and d in('L','R'),'bad table row');t[q,b]=w,1 if d=='R'else-1,z
 need(starts==[0],'start');return t
def encode(t):return('#! start 0\n'+''.join(f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'for(q,b),(w,d,z)in sorted(t.items()))).encode()
def entrances(t,q):return sorted(k for k,v in t.items()if v[2]==q)
def local(t,q,tape,steps):
 tape=tape.copy();h=0;trace=[]
 for _ in range(steps):
  need(h in tape,'unspecified exterior');b=tape[h];w,d,z=t[q,b];trace.append([q,h,b,w,d,z]);tape[h]=w;h+=d;q=z
 return(q,h,tape),trace

def build(machine,source,recipe,out):
 raw=machine.read_bytes();sr=source.read_bytes();need(sha(raw)==BASE_TABLE and sha(sr)==BASE_SOURCE,'wrong baseline pins');old=parse(raw);t=old.copy();rs=json.loads(sr);root=tree(rs);spec=json.loads(recipe.read_text());need(len(spec['rotations'])==8,'rotation count');checks=[]
 for item in spec['rotations']:
  q,r,side=item['q'],item['r'],item['side'];paths=item['paths'];need(entrances(t,r)==[(q,side)],'inner entrance');need(all(t[z,b][:2]==(b,1)for z in(q,r)for b in(0,1)),'not pure')
  for p in paths:
   n=subtree(root,p);need(not leaf(n)and not leaf(n[side]),'source shape')
   if side:a,(b,c)=n;new=((a,b),c)
   else:(a,b),c=n;new=(a,(b,c))
   need(all(boundary(v)==(0,0,False)for v in(a,b,c)),'nonclosed factors');need([len(sites(v))for v in(a,b,c)]==item['factor_counts'],'factor census');root=replace(root,p,new)
  u=t.copy()
  if side:u[q,0]=(0,1,r);u[q,1]=(1,1,t[r,1][2]);u[r,0]=(0,1,t[q,0][2]);u[r,1]=(1,1,t[r,0][2])
  else:u[q,0]=(0,1,t[r,0][2]);u[q,1]=(1,1,r);u[r,0]=(0,1,t[r,1][2]);u[r,1]=(1,1,t[q,1][2])
  t=u;intermediate=sites(root);need(graph_intervals(rs)==graph_arithmetic(rs)[0]==graph_intervals(intermediate)==graph_arithmetic(intermediate)[0],'intermediate four CFGs');checks.append({'outer':q,'inner':r,'side':side,'paths':paths,'factor_counts':item['factor_counts'],'all_factors_closed':True})
 ns=sites(root);need([x[1:]for x in rs]==[x[1:]for x in ns],'primitive word');need(graph_intervals(rs)==graph_arithmetic(rs)[0]==graph_intervals(ns)==graph_arithmetic(ns)[0],'four CFGs');need(metrics(root)==dict(dag_nodes=199,leaf_occurrences=3928,maximum_depth=45,maximum_zero_run=6),'source census');rotated=t.copy()
 need(spec['fold']=={'keep':214,'removed':115,'helper':155,'branch':0},'fold spec');need(entrances(t,214)==[(181,0)]and t[181,0]==(0,1,214),'tag0');need(entrances(t,115)==[(167,1)]and t[167,1]==(1,1,115),'tag1');need(t[214,1]==t[115,1]==(1,1,218),'common row');need(t[155,0]==(0,1,85)and t[155,1]==(1,1,150),'selector');need(t[85,0]==t[214,0]and t[150,0]==t[115,0],'helper replay')
 t={(q,b):(w,d,214 if z==115 else z)for(q,b),(w,d,z)in t.items()if q!=115};t[214,0]=(0,-1,155);blocks=[]
 for mark in(0,1):
  for b in(0,1):
   tape={-1:mark,0:b};e0,tr0=local(rotated,214 if mark==0 else 115,tape,1);e1,tr1=local(t,214,tape,3 if b==0 else 1);e0=(214 if e0[0]==115 else e0[0],e0[1],e0[2]);need(e0==e1,'local block');blocks.append({'tag':mark,'read':b,'old':tr0,'new':tr1,'whole_tape_equal':True})
 qs=sorted({q for q,b in t});need(len(qs)==213 and set(t)=={(q,b)for q in qs for b in(0,1)},'state census');need({z for w,d,z in t.values()}-set(qs)=={254},'target closure');nr=encode(t);ss=json.dumps(ns,indent=2).encode();need(sha(nr)==FINAL_TABLE and sha(ss)==FINAL_SOURCE,'final bytes');ren={q:i for i,q in enumerate(qs)};ren[254]=213;dense={(ren[q],b):(w,d,ren[z])for(q,b),(w,d,z)in t.items()};inv={v:k for k,v in ren.items()};need({(inv[q],b):(w,d,inv[z])for(q,b),(w,d,z)in dense.items()}==t,'renaming inverse')
 out.mkdir(parents=True,exist_ok=True)
 for fn,data in [('u213.native.tm',nr),('u213.tm',encode(dense)),('rotated214.tm',encode(rotated)),('sites.json',ss),('renaming.json',(json.dumps(ren,indent=2)+'\n').encode())]:(out/fn).write_bytes(data)
 receipt={'status':'EXACT_CONSTRUCTION_PASS','working_states':213,'rows':426,'native_sha256':sha(nr),'dense_sha256':sha(encode(dense)),'source_sha256':sha(ss),'metrics':metrics(root),'rotations':checks,'four_CFGs_identical':True,'changed_source_addresses':sum(a[0]!=b[0]for a,b in zip(rs,ns)),'local_blocks':blocks,'scope':'Deterministic construction and finite semantic premises; full runtime/startup are separate.'};(out/'construction.json').write_text(json.dumps(receipt,indent=2)+'\n');return receipt
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('machine',type=Path);p.add_argument('source',type=Path);p.add_argument('recipe',type=Path);p.add_argument('output',type=Path);a=p.parse_args();print(json.dumps(build(a.machine,a.source,a.recipe,a.output),indent=2))
