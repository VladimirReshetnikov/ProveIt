"""Independent explicit tree/ordinal-CFG/table audit; imports no optimizer."""
import json,hashlib
from pathlib import Path
from check_fold import read,need
P=Path(__file__).parent

def parse(rows):
 data={p:(op,arg)for p,op,arg in rows};need(len(data)==len(rows),'duplicate')
 def go(p):
  if p in data:return data[p]
  need(any(k.startswith(p+'0')for k in data)and any(k.startswith(p+'1')for k in data),'not full');return(go(p+'0'),go(p+'1'))
 root=go('');need(emit(root)==rows,'order');return root

def isleaf(n):return type(n[0])is str
def emit(n,p=''):return[[p,*n]]if isleaf(n)else emit(n[0],p+'0')+emit(n[1],p+'1')
def get(n,p):
 for b in p:need(not isleaf(n),'bad path');n=n[int(b)]
 return n

def put(n,p,v):
 if not p:return v
 a=list(n);a[int(p[0])]=put(a[int(p[0])],p[1:],v);return tuple(a)
def bounds(n):
 if isleaf(n):
  op,a=n;return(1 if op=='CD'else a if op=='CB'else 0,a if op=='CC'else 0,op=='CH')
 x,y=bounds(n[0]),bounds(n[1]);return(max(x[0]-1,y[0],0),max(x[1],y[1]-1,0),x[2]or y[2])
def cfg(rows):
 spans={};N=len(rows)
 for i,(p,_,_)in enumerate(rows):
  for j in range(len(p)+1):
   k=p[:j]
   if k not in spans:spans[k]=[i,i+1]
   else:spans[k][1]=i+1
 def cut(p,bit,n):
  for j in range(len(p)-1,-1,-1):
   if p[j]==bit:
    n-=1
    if n==0:return spans[p[:j]][1 if bit=='0'else 0]%N
  return 0
 out=[]
 for i,(p,op,a)in enumerate(rows):
  nxt=(i+1)%N
  targets=[nxt]if op=='CI'else[cut(p,'0',1),nxt]if op=='CD'else[cut(p,'0',a)]if op=='CB'else[cut(p,'1',a)]if op=='CC'else[]
  out.append([op,a,targets])
 return out

def placement(T,root):
 M={}
 def go(n,p,q):
  if isleaf(n):return
  M.setdefault(q,[]).append(p)
  for b in(0,1):
   if isleaf(n[b]):continue
   tape={-2:0,-1:1,**{i:int(v)for i,v in enumerate(p+str(b))}};h=len(p);v=q
   for k in range(200):
    need(v!=254 and h in tape,'prefix opaque/halt');w,d,v=T[v,tape[h]];tape[h]=w;h+=d
    if h==len(p)+1:
     need(all(tape[i]==int(x)for i,x in enumerate(p+str(b))),'prefix changed');go(n[b],p+str(b),v);break
   else:raise ValueError('prefix local bound')
 go(root,'',84);return M

def verify(history=None):
 T=read(P/'baseline214.tm',214);rows=json.loads((P/'baseline_sites.json').read_text());root=parse(rows);word=[r[1:]for r in rows];G=cfg(rows);hist=json.loads((P/'recipe.json').read_text())['rotations'] if history is None else history;checks=[]
 for i,rec in enumerate(hist):
  q,r,side,paths=(rec[k]for k in('q','r','side','paths'));M=placement(T,root);need(sorted(M[q])==sorted(paths),'all occurrences');need(T[q,side][2]==r,'child');need([k for k,v in T.items()if v[2]==r]==[(q,side)],'unique incoming')
  need(all(T[v,b][:2]==(b,1)for v in(q,r)for b in(0,1)),'pure decoder')
  nodes=[get(root,p)for p in paths];need(all(n==nodes[0]for n in nodes),'shared same subtree');n=nodes[0]
  if side:a,(b,c)=n;new=((a,b),c)
  else:(a,b),c=n;new=(a,(b,c))
  need(all(bounds(v)==(0,0,False)for v in(a,b,c)),'closed factors')
  old=dict(T)
  if side:T[q,0]=(0,1,r);T[q,1]=(1,1,old[r,1][2]);T[r,0]=(0,1,old[q,0][2]);T[r,1]=(1,1,old[r,0][2])
  else:T[q,0]=(0,1,old[r,0][2]);T[q,1]=(1,1,r);T[r,0]=(0,1,old[r,1][2]);T[r,1]=(1,1,old[q,1][2])
  for p in paths:root=put(root,p,new)
  rows=emit(root);need([v[1:]for v in rows]==word,'primitive word');need(cfg(rows)==G,'full CFG');placement(T,root);checks.append({'index':i,'q':q,'r':r,'side':side,'occurrences':len(paths),'all_checks':True,'intermediate_maximum_zero_run':max(len(s)for p,_,_ in rows for s in p.split('1'))})
 need(max(len(s)for p,_,_ in rows for s in p.split('1'))<=6,'final zero run');need(rows==json.loads((P/'sites.json').read_text()),'final source');need(T==read(P/'rotated214.tm',214),'final literal table')
 return {'status':'INDEPENDENT_ROTATION_AUDIT_PASS','rotations':checks,'primitive_occurrences':len(rows),'cfg_edges':sum(len(v[2])for v in G),'maximum_zero_run':max(len(s)for p,_,_ in rows for s in p.split('1')),'maximum_source_depth':max(len(p)for p,_,_ in rows),'scope':'Exact source word, ordinal control flow, closed factors and physical internal-node binding; arbitrary register primitive runtime and blank startup are separate obligations.'}
if __name__=='__main__':
 r=verify();tests=[]
 for label,field,value in [('wrong side','side',1),('wrong occurrence','paths',['']),('wrong child','r',155)]:
  hist=json.loads((P/'recipe.json').read_text())['rotations'];hist[0][field]=value
  try:verify(hist)
  except (ValueError,KeyError)as e:tests.append([label,str(e)])
  else:raise ValueError('negative control accepted')
 r['negative_controls']=tests;r['sha256']={f:hashlib.sha256((P/f).read_bytes()).hexdigest()for f in ['baseline214.tm','baseline_sites.json','rotated214.tm','sites.json','recipe.json']}
 (P/'rotation_result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
