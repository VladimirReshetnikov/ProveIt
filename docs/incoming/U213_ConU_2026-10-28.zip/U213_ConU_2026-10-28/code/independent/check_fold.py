"""Independent exhaustive opaque-exterior proof of the native115->214 fold."""
from pathlib import Path
import json,itertools,hashlib
P=Path(__file__).parent

def need(v,m):
 if not v:raise ValueError(m)
def read(p,count):
 T={};headers=[]
 for l in p.read_text().splitlines():
  if l.startswith('#! start'):headers.append(l);continue
  if not l or l.startswith('#'):continue
  q,b,w,d,z=l.split();q,b,w,z=map(int,(q,b,w,z));need((q,b)not in T and b in(0,1)and w in(0,1)and d in('L','R'),'row');T[q,b]=(w,1 if d=='R'else-1,z)
 S={q for q,b in T};need(headers==['#! start 0']and len(S)==count,'start/census');need(set(T)=={(q,b)for q in S for b in(0,1)},'total');need({z for w,d,z in T.values()}-S=={254},'halt');return T

def inv(q,h,t):return(q!=214 or t[h-1]==0)and(q!=115 or t[h-1]==1)
def rename(q):return 214 if q==115 else q

def run(T,q,t,n):
 t=t.copy();h=0;trace=[]
 for _ in range(n):
  need(q!=254 and h in t,'halt/opaque');b=t[h];w,d,z=T[q,b];trace.append([q,h,b,w,d,z]);t[h]=w;h+=d;q=z
 return(q,h,t),trace

def verify(O,N):
 expect={(q,b):(w,d,rename(z))for(q,b),(w,d,z)in O.items()if q!=115};expect[214,0]=(0,-1,155);need(N==expect,'exact patch')
 incoming={z:sorted([q,b,w,d]for(q,b),(w,d,v)in O.items()if v==z)for z in(214,115)}
 need(incoming=={214:[[181,0,0,1]],115:[[167,1,1,1]]},'guard entrances')
 cases=[];count=0
 for q in sorted({q for q,b in O}):
  for bits in itertools.product((0,1),repeat=5):
   t=dict(zip(range(-2,3),bits))
   if not inv(q,0,t):continue
   count+=1;w,d,z=O[q,t[0]];a=t.copy();a[0]=w;need(inv(z,d,a),'inductive guard')
   n=3 if q in(214,115)and t[0]==0 else 1
   (oq,oh,ot),tr0=run(O,q,t,1);(nq,nh,nt),tr1=run(N,rename(q),t,n)
   need((rename(oq),oh,ot)==(nq,nh,nt),'endpoint')
   if q in(214,115):cases.append({'state':q,'window':bits,'old':tr0,'new':tr1})
 return {'status':'EXHAUSTIVE_FOLD_PASS','admitted_radius2_frames':count,'incoming':incoming,'old_max_steps':1,'new_max_steps':3,'special_cases':cases,'scope':'All initial tapes at state0; finite positive stuttering blocks, no opaque exterior reads; PA-formalizable ordinary proof, not kernel artifact.'}

def main():
 O=read(P/'rotated214.tm',214);N=read(P/'u213.native.tm',213);r=verify(O,N);controls=[]
 for label,key,val in [('wrong entry tag',(181,0),(1,1,214)),('wrong helper',(155,0),(0,1,150))]:
  A=dict(O);A[key]=val;B={(q,b):(w,d,rename(z))for(q,b),(w,d,z)in A.items()if q!=115};B[214,0]=(0,-1,155)
  try:verify(A,B)
  except ValueError as e:controls.append([label,str(e)])
  else:raise ValueError('negative accepted')
 B=dict(N);B[214,0]=(1,-1,155)
 try:verify(O,B)
 except ValueError as e:controls.append(['wrong fold write',str(e)])
 else:raise ValueError('negative accepted')
 r['negative_controls']=controls;r['sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in[P/'rotated214.tm',P/'u213.native.tm']};(P/'fold_result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='special_cases'},indent=2))
if __name__=='__main__':main()
