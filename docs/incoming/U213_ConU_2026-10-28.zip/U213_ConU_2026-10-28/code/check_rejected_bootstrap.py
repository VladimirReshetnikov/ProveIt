#!/usr/bin/env python3
"""Exact rejection of the unminimized candidate; induction closes outward ray."""
import argparse,json,sys,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from check_startup import load_table,require
p=argparse.ArgumentParser();p.add_argument('--table',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();T=load_table(a.table);q=h=0;ones=set();trace=[]
for tick in range(54):
 if tick==53:break
 b=int(h in ones);w,d,z=T[q,b];trace.append([q,h,b,w,d,z]);ones.add(h)if w else ones.discard(h);q,h=z,h+d
require((q,h)==(35,5),'wrong endpoint');require(T[q,0]==(1,1,q),'not outward selfloop');require(h>max(ones),'not beyond finite support');r={'status':'EXACT_NONHALTING_RAY','steps':53,'state':q,'head':h,'one_cells':sorted(ones),'table_sha256':hashlib.sha256(a.table.read_bytes()).hexdigest(),'trace':trace,'argument':'Every next tape cell is untouched blank, and35/0 writes1,movesright,andremains35; induction proves nohalt.'};a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(r,indent=2)+'\n');print(r['status'])
