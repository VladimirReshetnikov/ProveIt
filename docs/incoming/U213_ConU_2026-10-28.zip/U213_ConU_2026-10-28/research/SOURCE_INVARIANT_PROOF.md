# Seed-relative source invariant

Let the category sets be C0={0}, C1={1}, C2={2}, C3={3}, C4={n:n≥4}. A per-register entry is a nonempty subset of these five indices. A box denotes the Cartesian product of the nine resulting unions. A site omitted from the certificate denotes the empty set. The initial concrete vector(4,0,...,0) is included in site0's box.

Increment sends k<4 to k+1 and C4 into C4. Positive decrement sends k=1,2,3 to k−1, and C4 into C3∪C4. The zero branch intersects with C0 and leaves that register zero. Other registers are preserved. Branch/continue preserve all registers. These explicit category maps prove sound abstract transfer for every natural value; no finite representative sampling is used. Combining incoming boxes by coordinatewise union only enlarges their union and introduces no unjustified relational assumption.

The independently authored checker resolves source successors by binary arithmetic on leaf paths, unlike the original interval/ancestor resolver. It reconstructs a fixed point using set-valued categories rather than bit masks. Afterwards it separately enumerates every possible outgoing abstract edge and checks inclusion in the claimed destination box. Thus validity does not depend on the queue strategy or its termination heuristic. The certificate records all3925boxes and5103closure edges. Induction on source steps proves membership throughout execution from the calibrated initial seed.

At site3848 the register1 category is exactly C0; at3910 register6 is exactly C0. Sites3849,3850,3911 have no box and are unreachable. Consequently replacing those two tests with their zero branches and removing the three dead sites is a valid seed-relative semantic transformation, provided the rewritten source CFG has the required corresponding control transfers. This last rewrite-equivalence obligation is separate from the invariant itself; arithmetic recoding or source reallocation cannot be assumed automatically valid.

No universal claim from arbitrary initial registers, no kernel certificate, and no globally minimal machine is implied.
