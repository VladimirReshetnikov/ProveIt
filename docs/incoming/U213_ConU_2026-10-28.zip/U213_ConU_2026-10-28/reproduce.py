#!/usr/bin/env python3
"""Offline exact replay. Writes only under a fresh temporary directory."""
import argparse,hashlib,json,os,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent

def need(x,m):
 if not x:raise RuntimeError(m)
def hashes():return {str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest()for p in P.rglob('*')if p.is_file()and '__pycache__'not in p.parts and p.name!='MANIFEST.json'}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--full',action='store_true',help='also repeat all5109 arbitrary-register cases (about2minutes)');a=ap.parse_args();expected=json.loads((P/'MANIFEST.json').read_text());before=hashes();need(before==expected,'sealed file integrity');stages=[]
 with tempfile.TemporaryDirectory(prefix='u213-replay-')as d:
  W=Path(d);env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONOPTIMIZE',None)
  def run(label,args):
   r=subprocess.run([sys.executable,*map(str,args)],cwd=W,env=env,capture_output=True,text=True);need(r.returncode==0,label+'\n'+r.stdout[-2000:]+'\n'+r.stderr[-2000:]);stages.append(label);print('PASS',label,flush=True)
  with zipfile.ZipFile(P/'inputs/U214.zip')as z:
   prefix='U214_ConPA_Reduction_2026-10-28/'
   for src,dst in [('machine/u214.native.tm','u214.native.tm'),('machine/sites.json','u214.sites.json'),('evidence/u214/startup.json','u214.startup.json')]:need(z.read(prefix+src)==(P/'inputs'/dst).read_bytes(),'baseline archive binding '+src)
  stages.append('pinned incoming archive binding')
  C=P/'code';I=P/'inputs';M=P/'machine'
  for opt,name in [([], 'normal'),(['-O'],'optimized')]:
   B=W/name;run('deterministic builder '+name,[*opt,C/'build213.py',I/'u214.native.tm',I/'u214.sites.json',I/'recipe.json',B])
   shutil.copyfile(I/'recipe.json',B/'recipe.json')
   for f in ['u213.native.tm','u213.tm','sites.json','renaming.json']:need((B/f).read_bytes()==(M/f).read_bytes(),'rebuilt '+f)
   need((B/'rotated214.tm').read_bytes()==(I/'rotated214.tm').read_bytes(),'pre-fold rebuilt')
   run('independent ordinal CFG '+name,[*opt,C/'check_cfg.py','--baseline',I/'u214.sites.json','--candidate',M/'sites.json','--output',W/(name+'-cfg.json')])
   run('source graph mutation controls '+name,[*opt,C/'check_source_graph.py',I/'u214.sites.json',M/'sites.json'])
   run('two-cell fold proof and controls '+name,[*opt,C/'check_fold213.py',B,'--out',W/(name+'-fold.json')])
   run('independent source reconstruction '+name,[*opt,C/'audit_rotations213.py',B,I,W/(name+'-rotation.json')])
   A=W/('independent-'+name);shutil.copytree(C/'independent',A)
   for src,dst in [(I/'u214.native.tm','baseline214.tm'),(I/'u214.sites.json','baseline_sites.json'),(I/'recipe.json','recipe.json'),(I/'rotated214.tm','rotated214.tm'),(M/'sites.json','sites.json'),(M/'u213.native.tm','u213.native.tm')]:shutil.copyfile(src,A/dst)
   run('exhaustive guarded fold '+name,[*opt,A/'check_fold.py']);run('independent rotation proof and controls '+name,[*opt,A/'check_rotations.py'])
   run('complete blank startup '+name,[*opt,C/'check_startup.py','--table',M/'u213.native.tm','--sites',M/'sites.json','--startup',I/'u214.startup.json','--out',W/(name+'-startup.json')])
  run('rejected predecessor regression',[C/'check_rejected_bootstrap.py','--table',P/'research/rejected16.native.tm','--output',W/'rejection.json'])
  run('input and assertion safeguards',[C/'check_negative.py','--table',M/'u213.native.tm','--sites',M/'sites.json','--output',W/'negative.json'])
  if a.full:
   run('universal whole-tape runtime',[C/'check_runtime.py','--table',M/'u213.native.tm','--sites',M/'sites.json','--output',W/'runtime.json'])
   r=json.loads((W/'runtime.json').read_text());need(r['cases']==5109 and r['working_states']==213,'runtime census')
   need(json.loads((W/'runtime.cases.json').read_text())==json.loads((P/'evidence/runtime.cases.json').read_text()),'all symbolic outputs reproduced')
 need(hashes()==before,'sealed files changed during replay')
 print(json.dumps({'status':'PASS','stages':len(stages),'sealed_files':len(before),'full':a.full,'checks':stages},indent=2))
if __name__=='__main__':main()
