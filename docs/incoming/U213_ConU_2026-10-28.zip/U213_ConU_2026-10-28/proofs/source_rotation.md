# Exact source and table transformation

The immutable baseline is the primary U214 native table (SHA256 5fa7d923456ea7fb3e9cb331946e49750970bbffbfa755c0639bdaa9b7afd8a8) and its 3928-site source (9428a13d4c228e9760e8f546e43527ee5e196ae667ad2386ddabf961b477d083). The final source has199 distinct subtrees, not198: this is physical compression despite a source-DAG increase. Maximum path length45 and maximum zero run6 are unchanged. All3928 ordered primitive operations and their operands are unchanged.

`inputs/recipe.json` lists eight rotations with exact paths and factor sizes. Every three-factor boundary is(0,0,false). This boundary means no uncaught break, no uncaught continue, and no halt within the factor. Thus reassociation preserves sequential execution of the three closed factors, including divergence. All physical inner states have their sole incoming edge from the indicated pure outer node; the four modified rows preserve the bit and move right. This is a decoder construction, not by itself a proof that specialized primitive continuations or the initializer remain correct. Those obligations are discharged separately by the final literal runtime and blank-start checks.

The portable builder checks both independently specified control-flow resolvers at every intermediate source as well as the final source. It proves that ordinal identity maps every instruction and both outcomes of every guarded decrement to the same effect and successor. This directly yields an all-register source transition conjugacy: source states are (instruction ordinal, nine natural registers); the map is identity on both components. It preserves and reflects finite and infinite runs. The two address representations of an ordinal may differ; no identity-on-address assertion is made.

## Explicit address semantics used by the checks

For an instruction address p, increment(p) is fixed-width binary addition modulo2^|p|. For an empty word it is empty. Cut(p,b,k) removes the suffix starting at the kth occurrence of bit b counted from the right, or gives the empty word if fewer than k occurrences exist. Locating a resulting prefix descends through zero branches to the first source leaf. If a leaf is encountered before the prefix ends, every remaining bit must be zero (the checked no-stray-one condition).

CI increments its designated register and uses increment(p). CD, on zero, leaves its register zero and uses increment(Cut(p,0,1)); on a positive register it decrements and uses increment(p). CB(k) uses increment(Cut(p,0,k)), and CC(k) uses Cut(p,1,k); both leave registers unchanged. CH halts. The independent interval resolver avoids this bit arithmetic: each binary subtree has its contiguous leaf interval, and outward zero/one ancestor walking finds its right/left boundary. Complete prefix-free binary coverage and canonical leaf order are validated before either resolver runs.

## Local selector fold

After rotation, native214 has rows0→(0,R,98),1→(1,R,218); native115 has rows0→(0,R,90),1→(1,R,218). Their only entrances are181/read0→214,167/read1→115, respectively, writing0 or1 then moving right. Neither is the initial state. At every actual visit the predecessor cell therefore records the origin.

Delete115, redirect its incoming target to214, and replace214/read0 with(0,L,155). State155 reads and preserves the predecessor bit, moving right to85 on0 or150 on1. Those states' read0 actions equal the original214/read0 and115/read0. Consequently the modified block takes three transitions instead of one on read0, or one unchanged transition on read1, and reaches the same successor state, head, and entire tape. Only the current and predecessor cells are read; all exterior cells are arbitrary. All internal block states are nonhalting. Positive finite block lengths establish halting preservation and reflection by induction on block concatenation, without a consistency premise.

The independent fold checker is separate from the constructor. No proof-assistant verification or state-minimality theorem is claimed. The all-natural binary primitive theorem and exact startup are distinct required gates.

## Reproduction

From the package root, using a fresh output directory:

    python code/build213.py inputs/baseline.native.tm inputs/baseline.sites.json inputs/recipe.json /tmp/u213-rebuilt
    python code/check_source_graph.py inputs/baseline.sites.json machine/sites.json

Both commands are also supported under Python -O. The source utility module is inherited unchanged from U214; its attribution and upstream license chain are retained. The new builder, source-only checker, recipe discovery and minimization are this iteration's work.
