# Independent logical review of U214 role emitter

Input: U214_ConPA_Reduction_2026-10-28, proofs/role_emitter.tex and source198.tex; code/audit_role_source.py inspected, not treated as kernel proof.

## Finding
No logical counterexample or missing exceptional-label case was found. The endpoint remains conditional on the explicit inherited numerical-logic, W+IR/U/PA proof translations. This review is mathematical, not a new formal certificate.

For matrix/output a, source b and test c, the unchanged gate c != a,b ensures test differs from both roles. Every effective label in positive native formula code a is below a; code zero is a closed truth alias. Thus the output is fresh even for codes zero and one. When a != b the guard Q(a,I(R(a,c),R(a,b))) is precisely subset(test,source). When a=b the local a binder captures source, and IR makes the guard equivalent to emptiness(test). W supplies an empty source from a false matrix; its cover instance at that source supplies all selected empty representatives, without unique emptiness or extensionality. The auxiliary source can be freshly renamed. The outer source binder does not accidentally capture the matrix, because a is fresh in its decoded formula.

Code zero gives truth; if a=b=0 the output must contain all empty representatives, which the preceding construction supplies. Code one is R(0,0), hence false under IR; it supplies an empty output. The exceptional cases are therefore covered uniformly, not dismissed by an incorrect strict-size statement at zero.

Completeness uses (a,b,c)=(n,0,1) for a padded native matrix code n>1, followed by retained projection and logical renaming templates. Every atomic vacuity instance remains available through the bundle, independent of the new shell. The proof must retain the inherited equality/indiscernibility treatment rather than claim equality-free shell completeness alone settles all numerical logical rows.

The numerical shell H=Q(a,I(U,I(L,1))) is the negation of existence of an output satisfying both cover clauses; N(I(V,H)) is classically V AND not-H. The postfix source audit computes the same shell and preserves the original gate and exterior CFG. This review did not rerun that audit or the physical runtime verifier; those are separate tasks.

## Shortcuts
The previously recorded a/b role swap and replacing matrix by its uniform negation remain sound (completeness via negated/padded matrix), but no extra state saving follows without compilation. Removing the c!=a test permits output/test capture; removing c!=b permits guard/test capture. Neither deletion is justified by this proof. Choosing the test label itself as the guard binder makes its premise diagonal and, under IR, the guard vacuous; this would demand unrestricted comprehension and is not a sound shortcut. No new emitter improvement is claimed.

## PA formalization obligations
Use explicit primitive-recursive proof translations, including fresh-label choice and padding; the a=b branch adds two fixed W schema derivations. Compose finite refutation translations in both directions, not external equiconsistency alone. The new literal machine must separately be bound to the numerical program for all register values, with blank initialization and positive-duration primitive simulation. Local table folds require an inductive tape guard and finite exact endpoint simulation; bounded execution samples alone are insufficient.

## Bounded implementation experiment (2026-10-28)
Generated the eight combinations of matrix/output role a or b, curried lower-clause order, and upper/lower cover-clause order. The inherited 28-macro parenthesization gives 198 DAG nodes for the baseline and 200 for the role swap; the other six give 202--205 and a seven-zero run. A five-choice-per-interval dynamic-programming reassociation of closed macros reduces same-role upper-first variants to 198, other same-role variants to199, and swapped-role variants to200--201, all with maximum zero run six. All forty were submitted to the adapted protected-row MILP allocator; ten allocated at214states with exact prefix-binding checks, thirty had no allocation in that restricted model. None is accepted as a new machine: no state improvement and no fresh complete runtime proof was requested for these alternative tables.

A second forty-candidate pass uniformly negated the matrix, using the sound interpretation already stated in the inherited report. Its best DP sources have199nodes (other cases200--202). These candidates likewise produced no allocation under the restricted214-state pool. These are bounded synthesis failures, not state-count lower bounds or global optimality claims. The search artifact contains historical upstream and conservative heuristic filters only as search provenance; the final filter used for the finite variants is the independently rederived142-row context census.

The initial erroneous416-row engine filter was detected as overconservative because the census failed to reset its phase on returning to root84; it was superseded by the fresh142-row census. It was never used to accept a candidate.
