# Independent audit of the repaired eight-rotation U213

The frozen input is U214 native SHA
`5fa7d923456ea7fb3e9cb331946e49750970bbffbfa755c0639bdaa9b7afd8a8`.
The rotated214 table is
`b3b059e94c3b9aab91c26dd6f20a4bbaba561dc8cd3eae5a22d573bd0c1ec4fa`;
the folded213 native table is
`9bd9145a7e0aebb04ed5376da96f7ab48271c50954b688909f7d172cab1c5ee2`.

## Source transformation

`check_rotations.py` imports no optimizer. It reconstructs each binary tree
from its ordered primitive list. Each rotation identifies every occurrence
of its physical decoder state by literal prefix simulation, checks that its
child decoder has exactly the one stated incoming transition, and checks
both decoders preserve their read bits and move right. The three factors
have no escaping break, no escaping continue, and no halt. Reassociation
therefore preserves their sequential register-transformer interpretation.

An independently written subtree-interval control-flow resolver verifies
exactly the same ordinal target(s), primitive opcode, and register operand
for every one of3928 primitive occurrences after every rotation. There are
5108 control-flow edges. The exact primitive word is unchanged, not merely
its multiset. Both the final emitted source and final literal214-state table
are byte-value compared with the frozen candidate data.

All eight source rotations are checked. Intermediate source layouts can have
seven consecutive zero bits; no claim is made that those intermediate binary
machines implement every primitive. The final layout has maximum zero-run6
and depth45. The complete arbitrary-register runtime proof for the FINAL
machine remains a separate required obligation. Source CFG preservation
alone does not supply that proof or blank startup calibration.

## Guarded fold

LetO be rotated214 andN folded213. O has only these entrances:

-181/read0 writes0 and moves right to214;
-167/read1 writes1 and moves right to115.

Neither is the initial state0. Thus the predicate
`q=214 => left_bit=0`, `q=115 => left_bit=1`
is initially true for ANY binary tape and one-step inductive. The independent
checker enumerates all6816 five-cell frames admitted by this predicate and
checks closure using the literal table.

Definef(115)=214 andf(q)=q otherwise. N deletes115, redirects every target115
to214, and replaces214/read0 with0 L155. All other rows are unchanged modulof.
For the guarded states, read1 goes directly to218 in both machines with
write1 and moveR. For read0, N first writes0/movesL to155, which reads the
left tag. Tag0 takes0 R85; tag1 takes1 R150. At the original head cell,85/0
is0 R98 and150/0 is0 R90. These are exactly O's214/0 and115/0 outcomes.
The tag and original cell are restored. No other cell is read or written.

For all other admitted states, one N step matches one O step modulof. Thus
from equal tapes and heads, and controls related byf, each O step matches
one or three N steps. Every block is positive and finite, and no interior
state is halting. Induction supplies the forward simulation; because every
N run from the corresponding start is deterministic and partitioned into
these positive finite blocks, a finite N halt occurs at a matching endpoint
of some finite O prefix. Halting is therefore equivalent in both directions,
for arbitrary initial tapes at state0. This argument formalizes in PA using
finite transition facts and ordinary induction. No new kernel artifact is
claimed.

## Evidence boundary

Both checkers run with and without Python optimization and use explicit
exceptions rather than disabled assertions. The fold checker rejects wrong
entry tag, helper target, and modified-row write. The rotation checker rejects
wrong side, wrong occurrence path, and wrong child. Parent runtime/startup
and inherited logical-calculus calibration must be combined separately.
The earlier sixteen-rotation layout has an invalid blank startup and is NOT
this endpoint; the current proof and identities concern the repaired eight-
rotation candidate only.
