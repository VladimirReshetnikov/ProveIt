# Borel Regularity Forces Summability
## Automatic continuity and measurable derivations on left-finite series fields

Research manuscript prepared with ChatGPT, 4 October 2026.

## Contents

- `borel_summability.pdf`: the complete typeset article.
- `borel_summability.tex`: self-contained LaTeX source, including bibliography.
- `verification.py`: standard-library-only exact rational verification code.
- `verification_results.json`: output of the supplied deterministic run.
- `SOURCE_AND_PROOF_AUDIT.md`: source provenance and the proof/novelty boundary.
- `SHA256SUMS.txt`: checksums of the principal package files.

## Mathematical contribution

For countable additive subgroups Gamma and Lambda of the reals, L_Gamma is the
field of real-coefficient formal series with only finitely many support
exponents below any real bound. Borel always refers to the coefficient coding
in the countable product of ordinary real lines, not to an unspecified
non-Archimedean measure theory.

The main theorem equates coefficient-Borel additivity with real linearity and
valuation continuity, and gives a necessary-and-sufficient matrix cutoff
criterion. It proves automatic preservation of left-finite formal sums and a
Baire-class-one bound. This is proved using Polish coefficient slices, not by
assuming that the full additive group is Polishable.

The derivation theorem classifies every Borel derivation by an additive
logarithmic monomial map with a common lower valuation bound. Further results
include rational-rank parameterization, an exact coefficient-continuity
criterion, rank-one integration, non-Borel algebraic derivations with an
explicit lacunary witness, and positive-gain exponential/logarithm theory.

## Status

The article supplies mathematical proofs. It is an AI-assisted, unrefereed
research draft. The exact novelty of the main results has not been independently
certified. It is not a claim to have solved a named remaining question in
Glazer's paper, and it is not a Lean-checked development. Neither Elliot Glazer
nor Vladimir Reshetnikov is represented as a coauthor or endorser.

## Rebuild the PDF

Use a TeX installation containing newtxtext/newtxmath, amsmath/amsthm,
mathtools, microtype, geometry, enumitem, booktabs, hyperref, bookmark,
fancyhdr, and needspace. Standard full TeX Live installations provide these.
No separate bibliography processor or external image is required.

```sh
pdflatex -interaction=nonstopmode -halt-on-error borel_summability.tex
pdflatex -interaction=nonstopmode -halt-on-error borel_summability.tex
pdflatex -interaction=nonstopmode -halt-on-error borel_summability.tex
```

The final supplied PDF was compiled without LaTeX warnings and visually
inspected after rendering. No font files are included in the package.

## Reproduce the exact checks

Requires Python 3.10 or later, with no external packages:

```sh
python verification.py > verification_results.json
```

The supplied run passed 1,640 exact rational checks, using seed 20261004.
It checks finite Leibniz, commutator, truncation, primitive, binomial-flow,
flow-composition, inverse-flow, and flow-multiplicativity identities. Negative
exponents are included; multiplication tests use safe asymmetric cutoffs.

These checks do not verify the Baire theorem, the generic-support argument,
infinite-dimensional automatic continuity, or literature priority. Those
are separate from executable finite algebra and are addressed in the article.
