# Exact asymptotics of OEIS A279619

This archive contains a self-contained article resolving the asymptotic-constant conjecture currently displayed on the OEIS A279619 page.

## Principal results

Let

\[
(n+1)^2c_{n+1}=(26n^2+13n+2)c_n+3(3n-1)(3n-2)c_{n-1},
\qquad c_0=1,\ c_1=2.
\]

The article proves

\[
c_n\sim
\frac{\sqrt{3\pi}}{\Gamma(1/7)\Gamma(2/7)\Gamma(4/7)}
27^n n^{-3/2},
\]

gives the all-orders rational correction expansion, and evaluates

\[
\sum_{n\ge0}\frac{c_n}{27^n}
=\frac{3\Gamma(1/7)\Gamma(2/7)\Gamma(4/7)}{8\pi^2},
\]

\[
\sum_{n\ge0}\frac{c_n}{125^n}
=\frac{5\Gamma(1/7)\Gamma(2/7)\Gamma(4/7)}{16\pi^2}.
\]

## Files

- `A279619_exact_asymptotics.tex` - LaTeX source.
- `A279619_exact_asymptotics.pdf` - compiled article.
- `verify_a279619.py` - exact-integer and symbolic verification script.
- `verification.txt` - captured output from a run through `n = 5000`.
- `OEIS_update.txt` - compact proposed OEIS formula note.

## Reproduce the checks

```bash
python -m pip install mpmath sympy
python verify_a279619.py --max-n 5000
```

The script uses no network access. Recurrence terms are exact Python integers; asymptotic and Frobenius coefficients are exact SymPy rationals.

## Build the paper

A standard TeX Live installation is sufficient:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error A279619_exact_asymptotics.tex
```

The PDF included in the archive was compiled and visually inspected after rendering every page.

## Bibliographic status

The OEIS page, O'Brien's 2016 thesis, Hirschhorn's paper on the square sequence, the relevant Chowla-Selberg source, targeted web searches, and the existing OEIS-asymptotics reports in the ProveIt repository were checked on 1 October 2026. No prior exact identification of the displayed decimal constant was found in that search. This is a limited audit, not a claim of exhaustive global priority.
