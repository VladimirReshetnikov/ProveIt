# Report199

## Quartic Dyck moments and noncrossing cumulants

This package accompanies the 4 October 2026 article on OEIS A338634. It contains the complete mathematical manuscript, its PDF, exact reproducible data, source code, and byte-count/SHA-256 manifests.

The proved raw-moment and cumulant expansion is

    m_n/F(n) = 1 - (1+pi)/(16n) + o(1/n)
    a_n/F(n) = 1 - (1+pi)/(16n) + o(1/n)
    F(n) = sqrt(2/pi) r^(4n+2) (n!)^4 / sqrt(n)
    r = 8 sqrt(pi) / Gamma(1/4)^2

The article separately proves every fixed order in shifted exact moments, the parity criterion, and a second Lambert-W inverse center with a little-o two-ceiling envelope. It does not claim an O(n^-2) target-moment remainder, a full raw inverse-power expansion, effective asymptotic constants or onset, an unconditional single ceiling, or absolute novelty.

Kotěšovec's posted OEIS leading formula, the classical Berg–Valent comparison theorem, and prior cumulant, rapidly-growing-series, and sample-path entropy work are credited in the article. No complete third-party paper, private research notes, or external credentials are included. The source review is bounded as explained in the article.

## Contents

- `Report199.tex`: self-contained LaTeX source, including bibliography; no external figure assets
- `Report199.pdf`: compiled article
- `build.py`: strict package validation, exact replay, deterministic PDF compilation, and deterministic ZIP construction
- `code/exact.py`: standard-library exact computations and explicit checks
- `code/diagnostics.py`: optional high-precision numerical diagnostics using mpmath
- `code/test_guards.py`: finite malformed-input and manifest rejection tests
- `data/exact_values.json`: raw moments through 500, integer-scaled comparison moments through 500, and cumulants through 160
- `data/exact_checks.json`: exact finite-check results
- `data/shifted_polynomials.json`: exact rational coefficients of Q_j(n), through j=8, and cyclic-placement checks
- `manifests/source_manifest.json`: six source files, sizes, hashes, reproducible epoch, and release PDF engine banner
- `manifests/package_manifest.json`: every public file except itself, with sizes and hashes

There are twelve public files. Exact integer values are stored as decimal strings to avoid machine-integer limits. A `four_gamma[n]` value is 4^n b_n, where the unscaled comparison weights are gamma_h=h^2(h^2-1/4). Rational checks are represented exactly, not as floating-point approximations.

## Requirements

Exact computations and guard tests require Python 3.10 or newer and only its standard library. The release was exercised with Python 3.12.14. No internet connection is used by the build or exact replay.

PDF replay requires pdfLaTeX/pdfTeX, `kpsewhich`, and an installed TeX distribution containing the packages used in Report199.tex, notably Latin Modern, microtype, geometry, amsmath, amssymb, amsthm, mathtools, booktabs, array, xcolor, enumitem, fancyhdr, and hyperref. The release engine banner is recorded in the source manifest. Byte-for-byte PDF identity additionally depends on matching TeX package and font versions, not just the engine banner. On a different TeX installation, exact computations can still be checked separately; normal full replay fails explicitly if the regenerated PDF differs.

The builder uses a private temporary home and TeX cache, disables shell escape, fixes SOURCE_DATE_EPOCH to 2026-10-04 00:00:00 UTC, suppresses PDF date and path-bearing metadata, and repeats compilation until PDF bytes stabilize. If the installed distribution lacks a ready pdflatex format, it creates a private format and font-map file from the installed TeX resources. It does not download or install software.

Only the optional diagnostic program needs mpmath (release diagnostics used version 1.3.0 at 85 decimal digits). Floating-point diagnostics are deliberately outside the manifest-covered generated outputs.

## Rebuild an extracted archive

Extract Report199.zip to a fresh directory. It contains one top-level directory, `Report199/`. From that directory:

    python3 build.py --validate-only
    python3 code/test_guards.py
    python3 code/exact.py --check-data data
    python3 build.py --output ../rebuilt-normal --archive ../rebuilt-normal.zip

The last command validates the input package, recomputes all exact data, recompiles the PDF, regenerates the manifests, and requires all twelve public members to match the input byte for byte. It writes only to fresh, non-nested destinations; it refuses to overwrite existing output directories or ZIP files.

For an optimized-Python replay, use fresh output names:

    python3 -O code/test_guards.py
    python3 -O build.py --output ../rebuilt-optimized --archive ../rebuilt-optimized.zip

The checks use explicit exceptions and therefore remain active under `-O`. The normal and optimized archives are expected to be byte-identical to the release archive when built with the matching toolchain. ZIP entries have sorted names, fixed timestamps, fixed regular-file permissions, no extra fields or comments, and stored (uncompressed) payloads; compression-library variations do not enter ZIP identity.

Exact data alone can be regenerated to a separate directory:

    python3 code/exact.py --output ../exact-replay

Optional numerical diagnostics can be generated outside the package:

    python3 code/diagnostics.py --data data --output ../numerical_diagnostics.json

The diagnostic program reports ratios, the regularized integral, and inverse-center residuals. Its finite observations are not asymptotic proofs or certified onset estimates. The small numerical table in the article is rounded from these diagnostics.

## Maintainer initialization

To build a deliberately modified source release, copy the six source files into a separate directory, make the intended edits, and use:

    python3 build.py --initialize --output ../new-release --archive ../new-release.zip

`--initialize` intentionally creates new manifests and outputs. It is not the verification command for an unchanged released package. Ordinary verification uses a build without this flag and enforces equality with the recorded public members.

## Exact-check scope

The computations include:

- weighted prefix-height dynamic programming for 501 quartic moments and 501 integer-scaled comparison moments
- Lagrange power recurrence for 161 cumulants, with exact divisibility checks
- comparison with fourteen displayed OEIS A338634 coefficients at indices 0 through 13; the full OEIS b-file was not successfully retrieved and is not claimed checked
- independent finite continued-fraction and first-block transform checks
- explicit common-opener matching quadruple enumeration through n=3, with explicit least-noncrossing closure rather than ordinary graph connectivity
- exact Dyck enumeration and negative-excursion identities for four positive rational-weight laws
- finite occupation bounds at n=64, 128, and 256 in their stated lower-height range
- parity, moment log-convexity, and the elementary upper ratio bound
- exact rational polynomial identities for Q_j through grade 8 and finite cyclic-placement identities
- exact Stirling coefficient and symbolic inverse-cancellation checks

These finite checks are consistency tests. The manuscript supplies the proofs of uniform occupation, the endpoint-safe entropy limit shape, uniform change of measure, the subtracted regularized integral, the Bonferroni remainder, and threshold rounding.

The guard tests cover their explicitly listed malformed JSON, invalid exact-value data, manifest schema/path/hash/size errors, missing or undeclared files, symlink cases, and deterministic-ZIP behavior. Passing those tests is not a claim of a complete security audit, sandbox, adversarial-code verifier, or safety guarantee for arbitrary archives. Manifests detect inconsistency with their own recorded bytes; they are not digital signatures establishing an author's identity. Inspect code before running material obtained from an untrusted source.
