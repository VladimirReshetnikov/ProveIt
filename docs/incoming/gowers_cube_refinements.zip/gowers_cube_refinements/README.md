# Fourth-order stability of additive cube counts

Torsion-sensitive refinements of Gowers' Lemmas 3.7 and 3.10.
Prepared for Vladimir Reshetnikov, 6 October 2026.

## Files

- `fourth_order_cube_counts.pdf`: the 25-page article.
- `fourth_order_cube_counts.tex`: self-contained LaTeX source, including bibliography.
- `verify_cube_refinements.py`: exact-arithmetic verifier; Python 3.10 or later,
  standard library only.
- `verification_results.json`: captured output from a successful complete run.
- `source_provenance.json`: source references, inspected Git blob IDs, and scope.
- `build.sh`: LaTeX build helper.
- `layout_validation.json`: page count, rendering status, and text-boundary checks.

## Main mathematical results

Theorem 3.3 removes the first three nonconstant terms in the cube expansion.
For p=2^d and a real mean-zero f, the cube excess of delta+f is bounded by
sum_{r=4}^p binom(p,r) delta^(p-r) ||f||_{U^d}^r. This improves the leading
power in Gowers' uniformity parameter from 1/p to 4/p.

Theorem 4.3 gives the exact quartic coefficient on every finite abelian group,
including a separate contribution from nontrivial order-two characters.
Theorem 5.2 gives the complete three-cube polynomial in odd order and improves
its norm-bound coefficients to 12, 8, 28, 8, 1.

Theorem 6.1 disproves the suggested global lower bound with coefficient 12.
An additional finite Fourier certificate supplies the explicit ratio 15337/1296.
Theorem 7.4 proves exponent sharpness for genuine subsets of cyclic groups of
odd prime order, with their densities tending to any prescribed density in (0,1).
Theorem 8.1 and Corollary 8.2 give Fourier stability and a finite-size lower bound.
Sections 9 and 10 treat different vertex weights and the full-support criterion.
Section 13 proposes ten further research questions.

## Reproduce the checks

Run without Python's `-O` flag (the program refuses optimized mode):

    python verify_cube_refinements.py --output verification_results.json

All assertions use integers or fractions.Fraction, not floating-point tolerances.
The default run enumerates 673,227 four-vertex supports in dimensions 2 through 6
and checks 5,580 triples in dimensions 2 through 5. It also checks three-cube
identities on cyclic orders 3 through 9, quartic identities on four product
groups, and two independent exact Fourier certificates for the counterexample.
A shorter quartic enumeration is available with `--max-d 5`.
The script makes no network requests. It writes only the selected JSON output.

## Build the PDF

Use `bash build.sh`, or run:

    pdflatex -interaction=nonstopmode -halt-on-error fourth_order_cube_counts.tex
    pdflatex -interaction=nonstopmode -halt-on-error fourth_order_cube_counts.tex

A standard LaTeX installation with AMS packages, Latin Modern, hyperref,
microtype, listings, geometry, enumitem, and fancyhdr is sufficient.
The bibliography is internal; BibTeX is not needed.

## Scope and verification status

These are local improvements to cube-count estimates, not a new global bound
for Szemeredi's theorem. The general results are supported by mathematical
proofs in the article, not extrapolated from the finite checks.
The finite counterexample identity has an explicit exhaustive certificate.
Bibliographic priority has not been established, and the draft has not received
independent peer review.

No Lean executable was available, no new Lean proof was compiled or kernel-checked,
and no repository files were modified. Section 11 is an integration plan, not a
completed formalization. The existing source files were inspected read-only.
The archive does not include the original copyrighted paper or font files.
