# Nine Bits, Ten Bits
## Sharp dimension boundaries for product-Bernoulli entropy

Research draft prepared for Vladimir Reshetnikov, 29 September 2026.

**Main deliverables:** `article.pdf` and `article.tex`.

### Main theorem

For independent Bernoulli bits, Tsallis entropy of the full joint vector is
jointly concave in the Bernoulli probabilities for **every** real order
`0 < q < 1` if and only if the number of bits is at most **nine**.
The same theorem applies to a weighted sum with distinct subset sums.

For an individual order, an explicit scalar profile gives the exact criterion
`n Psi(q) <= 1`. In particular, `Psi(1/2)=1/10` and `Psi(1/3)=1/11`.
A strictly interior rational counterexample is supplied at `q=20/41` for ten
bits. Another counterexample uses weights `w_i=1+2^(i-1)/1000000` and preserves
the mean of the weighted sum exactly. Both have certified finite Jensen gaps.

The article also proves endpoint asymptotics, strong-concavity estimates,
a fourth-order law at the half-order degenerate points, a block-product
curvature criterion, and an algebraic decision procedure for rational orders.
It contains ten proposed research directions.

### Scope and status

This is about **the joint bit vector / collision-free weighted sums**, not the
ordinary unweighted Bernoulli sum. It does not settle all partially colliding
weight systems. The subunit-order Tsallis counterexamples remain quasiconcave;
they disprove concavity, not quasiconcavity.

The proofs are self-contained mathematical arguments, supplemented by exact
finite arithmetic. They have not been independently refereed or formalized in
Lean. Bibliographic priority is not confirmed. The known one-bit Renyi threshold
and the repository's ordinary-sum counterexample are not claimed as new here.

The baseline repository snapshot was
`VladimirReshetnikov/ProveIt@ac9107d74083fcfe8064b4aaeda7989612e6a5b6`.
No repository files were modified or uploaded.

### Reproduce

From this directory:

```sh
python code/verify_exact.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The exact verifier requires only Python 3.10+ and its standard library. It also
runs from other working directories. Its recorded result is **17,927 exact checks
passed**. No floating-point number is used for an accept/reject decision. Profile
table values at q=1/2 and q=1/3 are based on the article's exact analytic formulas;
the other dimensions are certified with rational intervals.

Optional:

```sh
python code/verify_symbolic.py
python code/make_figures.py
```

These use SymPy and Matplotlib respectively. Versions actually used:
Python 3.13.5, SymPy 1.14.0, Matplotlib 3.10.8, pdfTeX 1.40.26.
The symbolic verifier recorded **14 checks passed**. It is not a formal proof
checker. Figures are numerical illustrations and are not needed to verify the
main theorem. Prebuilt vector figures are included, so optional dependencies are
not needed to rebuild the article.

The general gcd/root-counting branch of the rational-order decision theorem is
not implemented as a general standalone solver in this package. The exact script
implements the strict-interval branch for its tabulated orders; the symbolic
script checks the gcd equality branch for q=1/2 and q=1/3.

### Contents

- `article.tex`, `article.pdf`: complete source and compiled article.
- `code/verify_exact.py`: dependency-free finite arithmetic certificates.
- `code/verify_symbolic.py`: optional symbolic identity checks.
- `code/make_figures.py`: reproducible numerical vector figures.
- `results/certificates.json`: exact root-enclosure certificates and thresholds.
- `results/checks.txt`, `results/symbolic_checks.txt`: recorded outputs.
- `results/profile_table.tex`, `results/profile_plot.csv`: table and plot data.
- `figures/`: prebuilt vector figures.
- `SOURCES_AND_STATUS.md`: provenance, novelty boundaries, and source audit.
- `Makefile`: build and verification commands.

No third-party papers, font files, or software distributions are included.
