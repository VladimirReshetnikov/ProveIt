# Exact Binary Reversal with Three Outputs

**An all-state solution and rigidity of extremizers**  
Research article prepared for Vladimir Reshetnikov, 28 September 2026.

## Main theorem

For every n >= 7, let A < B be the closest coprime positive integers with
A+B=n. Then the exact maximum reversal complexity for an n-state DFAO
with two input letters and three output values is

    R_2(n,3) = 3^n - 3(2^A + 2^B - 2) + B.

The split is (h,h+1) for n=2h+1; (h-1,h+1) for n=2h with h even;
and (h-2,h+2) for n=2h with h odd. The last case starts at n=10.

The article proves the all-n upper bound and necessary extremal structure.
Attainability uses Davies's published lower construction. The earlier
ProveIt collision-coloring report supplied the underlying method and
finite agreement through n=30; the new comparisons remove that finite-range
restriction for three outputs.

Every extremizer has one permutation generator with the specified cycles
and one rank-(n-1) singular generator with exactly one cross-cycle double
fiber. All improper colorings of the corresponding complete bipartite graph
are reached, together with one full-length proper permutation orbit. The
article also gives the orbit inventory of the missing colorings and a
6AB additional-collision penalty under explicitly stated hypotheses.

This is a conventional mathematical research draft, not a Lean-verified or
independently refereed result. It does not settle the four-or-more-output
case or the largest-two-generated-transformation-monoid conjecture.
The literature check does not establish priority.

## Contents

- `article.pdf`: the 19-page article, including title page, full proofs,
  eight further research questions, references, base-case arithmetic, and
  a formalization dependency plan.
- `article.tex`: self-contained editable source; bibliography and all tables
  are embedded. It compiles without any data file or bibliography processor.
- `code/verify.py`: exact structural comparisons, complete small witness
  orbit searches, forbidden-coloring checks, and cyclic orbit inventories.
- `code/independent_check.py`: separate small-base arithmetic, closed-form,
  and recurrence checks. It imports no implementation from `verify.py`.
- `data/`: the exact CSV, JSON records, and console output from the runs.
- `SOURCE_AUDIT.md`: source locations, dependencies, search scope, and claims
  deliberately not made.
- `Makefile`: build/check commands.

## Rebuild the PDF

A standard TeX Live installation with newtx, amsmath/amsthm/mathtools,
microtype, geometry, booktabs, enumitem, tcolorbox, fancyhdr, aliascnt,
hyperref, and cleveref is sufficient. No font files are distributed.

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Equivalently, `make pdf`. Two runs resolve the internal references.

## Reproduce the checks

Python 3.10 or later; standard library only:

```sh
python code/verify.py --max-n 200 --bfs-max-n 11
python code/independent_check.py
```

Run the first command before the second, which compares its independently
computed small table with the first command's JSON record. These commands
rewrite the generated data files. Run `make check` to save their console
output as well.

The recorded run passed 752,291 structural candidates over 194 values of n
(7 through 200), complete witness-orbit searches for n=7 through 11,
three proper-orbit inventory comparisons, and all 72 unique-cross-pair
colorings in the seven-state additional-collision example. The largest
fully explored orbit contained 176,871 states. The independent script
checked all 994 n-values from 7 through 1,000 for the closed formula and
982 recurrence instances.

The search is literal breadth-first exploration, not random sampling.
It raises an error if its state limit is reached and never returns a partial
count as a completed orbit. The algebraic all-n proof is in the article;
these finite computations do not replace it.

## Repository snapshot

Repository: https://github.com/VladimirReshetnikov/ProveIt

Commit: `fbba58593dc0622aa914972896150d4848f935b5`

Relevant directory:

```text
SetTheory/Cardinals/docs/reports/automata-and-formal-languages/
dfao-reversal-coloring-obstruction/
```

The witness array formula follows the published parity-version construction
also implemented in that directory's `code/reversal.py`. The verification
programs in this archive were written for this article. No repository files
were modified.
