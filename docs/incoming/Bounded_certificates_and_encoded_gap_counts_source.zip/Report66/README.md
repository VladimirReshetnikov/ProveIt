# Report 66

## Bounded halting certificates and exact encoded gap counts

4 October 2026. Read `Report66.pdf` for the complete 21-page article. `Report66.tex` is the matching flattened, editable LaTeX source; readable modular sources are in `manuscript/`.

The first part proves exact native clipping at T, or T+1 in shifted positive coordinates. The resulting Q=(T+1)^2 classes yield an explicit integer polynomial with three unique positive witnesses and six residual slots. For T>=1 its joint degree is at most 4Q-4 and support is at most 16Q-5; at T=0 its degree is two. The finite acceptance table costs at most Q*T native transitions in principle, and degree, coefficient height, expanded storage and algebraic construction costs are stated. This is a separately compiled T-indexed family with a uniform effective generator, not a fixed polynomial for unbounded halting or a faster single-instance decision claim.

The native-gap composition pays for two complete POWER modules. It has three external gaps, 57 positive witnesses, 38 residual slots and joint degree max(12, deg P). Its decoded projection is unique, but all nonempty complete fibers are infinite. Its all-exponent equivalence depends on the explicitly pinned constructive Pell theorem pair. Physical transport remains conditional on the retained encoded-input compiler theorem.

The second part counts all encoded positive integer triples, independently of programs and halting. Exact primitive scales give floor and digit formulas, a valuation-based shell count, slope 743/1125 for triples, and density 3/20 for distinct totals. The cumulative deficit has sharp normalized log-base-two-squared liminf zero and limsup one. Exact four-class errors on X_M=10*2^M (M>=1) establish the sharp inverse constants, with multiplicity and slope 1125/743. The primitive-counter index, counting height, distinct totals and repeated triple ranks are kept separate.

Two vector diagrams explain finite clipping classes and exact shell multiplicities. The article contains the complete English proofs, explicit positive-domain POWER adapters, resource ledgers, dependency boundaries and future questions. It makes no OEIS identification, external open-conjecture, novelty, priority, optimality, halting-density or new unbounded-halting claim.

## Included material

- `Report66.pdf` and `Report66.tex`: the article and matching flattened source
- `manuscript/`: five editable modules and their externally pinned hash map
- `science/bounded-certificates/`: the unchanged three-witness continuation, stored evidence and inert dependencies, including licensed mathlib source
- `science/counting/`: the unchanged counting continuation, stored evidence and inert checker
- `audits/bounded-certificates/`: accepted independent audit, independent coefficient-checker source and data-only examples
- `audits/counting/`: accepted independent counting review and independent exact-arithmetic evidence
- `INPUT_PINS.json`: exact source origins and frozen copied file/directory metadata
- `qa/`: source-preservation, typesetting, selftest and independent review receipts
- `tools/`: Report66-owned build, release and synthetic selftest tools, adapted from the completely inspected accepted Report64 contract
- `RELEASE_MANIFEST.json`: final exact release inventory, authenticated by an externally supplied digest

The supplied science and mathematical-audit programs are inert evidence. None is imported or executed by the report tools. No native machine interpreter, physical simulator, saved schedule search, author/upstream mathematical program or Lean execution is performed. Building this article verifies reproducibility of its presentation, not the mathematical truth of its theorems.

## Independent mathematical audits

Both frozen mathematical continuations were accepted without correction. The bounded-certificate audit reconstructs interpolation independently, checks the final support refinement, all domain adapters and the complete gap ledger, and explicitly retains the finite-table limitation. The counting review uses reduced denominator least common multiples and independent positive-triple enumeration, checks all heights through 250,000 and 164,979 tied inverse ranks, and proves the sharp constants in prose. Its divisibility cutoff is stated for M>=1; larger-counter special scales can lie below X_M without dividing it.

The final 21-page manuscript and every page passed a separate mathematical-transcription and visual review. Its only requested wording clarification, explicitly requiring an integer digit base, is resolved. The accepted dossier is in `qa/manuscript-review/`.

The independent release-tool review passed 142 synthetic, adversarial and full-article checks, with independent validation of 42 rendered pages from direct and relocated builds. Both builds reproduce the final PDF exactly. Its compact accepted evidence is in `qa/release-tool-review/`. These verdicts do not turn retained source checkers into independently executed evidence or constitute a new formalization of the inherited compiler or Pell theorem. The reviewer candidate archive is distinct from the later final release seal.

## Authenticate a received release

Use Python 3.9 or newer. Inspect `tools/release66.py` before running it. Replace `EXPECTED_MANIFEST_SHA256` with the final digest obtained outside the archive. Do not infer trust merely by hashing a manifest contained in the archive itself.

From the release directory:

```sh
python3 -I -S -B tools/release66.py verify \
  --manifest-sha256 EXPECTED_MANIFEST_SHA256
```

The tool checks the exact listed file and directory descendants, regular single-link files, hashes, byte sizes, modes and nanosecond modification times, as well as the fixed inert-input pin map. It rejects symlinks, special files, unexpected entries and empty directories. The manifest's own bytes are authenticated by the external digest; its own filesystem metadata and the top-level release root's mode and time are outside the manifest inventory. Per-operation snapshots still check that the current root is preserved. Read-access timestamps are not integrity evidence. Original creation/change timestamps are not transported to a new filesystem.

Because ordinary ZIP extractors often discard original nanosecond times, use the supplied metadata-preserving extraction operation rather than expecting generic extraction to pass exact verification. From an already inspected copy of the tools:

```sh
python3 -I -S -B tools/release66.py extract \
  --archive /absolute/path/to/Report66-source-evidence-20261004.zip \
  --output-dir /absolute/path/to/new-report66-copy \
  --manifest-sha256 EXPECTED_MANIFEST_SHA256
```

Extraction authenticates the manifest and exact archive member list before writing, verifies payload bytes and file modes, rejects traversal and nonregular entries, then restores authenticated descendant file and directory modification times. The new top-level root is mode 0700; the manifest itself is assigned mode 0644 and the fixed epoch. ZIP timestamps, compression choices, comments and other container metadata are not independently authenticated by extraction. The output path must not exist and must lie outside the release and protected source trees. Run verification again from the extracted copy.

## Rebuild the article in a new external directory

Inspect `tools/build_report66.py` and its hash-pinned release helper before execution. The locked build uses a fresh local TeX format, a fresh font map, an allowlisted environment, disabled shell escape, three LaTeX passes, and the union of format and every pass's recorded input files. It does not use the science/audit checkers. It checks source preservation and every rendered PNG's dimensions, CRC and raster structure. Visual review is separate from those automated checks.

The reviewed manuscript-pin map has SHA-256:

`ad42c8401fac8b7f6c7e0e03ad8eb2de792862a39463f7f0e686daef68ec30e1`

The article's dependency lock has SHA-256:

`600f1af2999954df4ce9662cf5317e49867c04b0a613eabb418e0943090f9617`

After authenticating the release, run:

```sh
python3 -I -S -B tools/build_report66.py \
  --output-dir /absolute/path/to/new-report66-build \
  --pins-sha ad42c8401fac8b7f6c7e0e03ad8eb2de792862a39463f7f0e686daef68ec30e1 \
  --dependency-lock-sha 600f1af2999954df4ce9662cf5317e49867c04b0a613eabb418e0943090f9617 \
  --require-packaged-match
```

The output includes a PDF, text, complete recorder receipts, a dependency receipt, rendered pages, preservation records and the build receipt. The PDF must equal the sealed article byte for byte. The lock covers the named interpreter/executable bytes, recorded system TeX/font inputs and selected maps; it does not inventory shared libraries, the Python standard library or the operating system. A different toolchain is expected to fail preflight rather than be called an identical rebuild.

The fixed SOURCE_DATE_EPOCH is 1791072000, and variable PDF dates and trailer IDs are omitted. `--bootstrap` is an authoring-only alternative that records a first dependency set; it explicitly does not claim preflight lock verification and must not be substituted for the locked replay above.

## Deterministic archive and owned selftests

To create a new archive from an authenticated release:

```sh
python3 -I -S -B tools/release66.py archive \
  --manifest-sha256 EXPECTED_MANIFEST_SHA256 \
  --output /absolute/path/to/new-report66.zip
```

Archive creation sorts entries under the fixed `Report66/` prefix, assigns one fixed archive timestamp, preserves authenticated file modes and uses deterministic deflate settings. These are creation guarantees; extraction authenticates the payload boundary described above. Original descendant nanosecond times remain authenticated in the manifest and are restored by the extraction tool. Repeated creation in the same Python/zlib environment is checked for byte identity. Do not regenerate a manifest merely to make a changed release pass verification.

The author-owned synthetic selftest is separate from independent review:

```sh
python3 -I -S -B tools/selftest66.py \
  --output-dir /absolute/path/to/new-report66-selftest
```

Its completed 39-test receipt covers correct and rejected pins, source and output alias guards, frozen metadata, first-pass-only dependency locking, inherited hostile temporary variables, corrupt PNGs, deterministic archives, metadata-preserving extraction, relocated verification and byte-identical PDF rebuilding. It uses synthetic TeX and inert copies of evidence; it does not execute mathematical programs.

## Attribution

The unchanged `pell-source.lean` is from mathlib4 commit `ac77769fabe23cb237559e7f56578dbead91499f`, by Mario Carneiro and contributors under Apache License 2.0. Its original source header, license and notice are retained in `science/bounded-certificates/dependencies/`. The article names the exact source and theorem pair. Earlier research and audit source copies remain provenance material and are not represented as newly authored mathematical software.
