# Invisible Complexity in Surreal Polytopes

**Explicit polygons with identical all-order jets and identical initial slack matrices**  
Research manuscript prepared for Vladimir Reshetnikov — 30 September 2026.

## Files

- `surreal_polytopes.pdf`: the 26-page article.
- `surreal_polytopes.tex`: self-contained LaTeX source, including its bibliography and TikZ diagram.
- `verification/verify.py`: exact symbolic and rational finite checks.
- `verification/results.json`: the recorded successful check results.
- `verification/README.md`: verification scope and the formulation output format.
- `SOURCE_AUDIT.md`: repository snapshot, source provenance, and limits of the audit.
- `requirements.txt` and `build.sh`: reproducible checks and PDF build.

## Main result

For every ordinary finite n >= 4, Theorem 3.1 constructs explicit labeled
surreal n-gons P_n and Q_n. They have the same full-dimensional triangular
real shadow, the same oriented matroid, identical vertex and slack data
modulo every power of rho, and identical entrywise leading slack terms.
Nevertheless, with U(n) = 2 ceil(log_2(n-2)) + 2,

    xc(Q_n) <= U(n),        sxc(Q_n) <= U(n),
    r = xc(P_n)  implies    r(r-1) >= 2n,
    h = sxc(P_n) implies    (h(h+1)/2)^2 >= 2n.

Here xc counts facet inequalities in an exact linear extension, whereas sxc
counts the matrix order of an exact positive-semidefinite lift. Thus both
hard/easy ratios are unbounded. Every coordinate has at most three Conway
monomials, and all n fit one set-sized real closed field of valuation rank
three. A rank-two variant is sharp for the existence of nonzero all-power
jet ambiguity. Iterated pyramids extend the separation to every fixed
finite dimension with a simplex shadow.

The article also proves descent of nonnegative and PSD ranks under any
convex residue map, a set-sized precision-escape theorem, and a finite
real-algebraic conservativity theorem. It includes ten further research
questions and a staged formalization design.

## Scope and status

The manuscript supplies mathematical proofs relative to identified
classical inputs. It is an AI-assisted research manuscript, not an
independently refereed paper or a Lean-verified development. No historical
conjecture is represented as newly resolved. Generic lower bounds,
reflection relations, slack factorization, rank closure, and real-closed-
field transfer are explicitly credited to established work. The candidate
contribution is the explicit multiscale separation and its stated
consequences. Priority has not been established by the limited search.

All-orders agreement refers to the quotients of the finite-element ring
by powers of a chosen infinitesimal. It does NOT mean equality of exact
polynomial zero predicates. Equation (4.5) gives a simple exact linear
expression that distinguishes the two configurations. Very small rational
numbers do not replace the surreal independence or all-orders arguments.

## Rebuild

Requirements: Python 3.10 or later, SymPy, and a TeX distribution with
latexmk, newtx, amsmath/amsthm, mathtools, microtype, TikZ, tcolorbox,
tocloft, fancyhdr, hyperref, and cleveref.

```sh
python -m pip install -r requirements.txt
./build.sh
```

Or build the two outputs separately:

```sh
python verification/verify.py
latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_polytopes.tex
```

The recorded run used Python 3.13.5 and SymPy 1.14.0. No network access is
needed once the dependencies are installed. The article uses no external
image files and no bundled font files.

## Verification evidence

The successful finite run includes 132,088 positive orientation checks,
32,384 slack entries, 4,686 active-basis checks for the binary reflection
lifts, and 636 symbolic slack entries, in addition to symbolic identities
and normalization checks. These are supplementary tests, not a formal
proof of the transcendence or universal complexity statements.
