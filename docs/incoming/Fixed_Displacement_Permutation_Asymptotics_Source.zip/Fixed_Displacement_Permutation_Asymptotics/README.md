# Fixed-displacement permutation asymptotics

This packet proves a complete algebraic asymptotic expansion for a_rs(n)/n!,
where pi(i+r)-pi(i) != s, for each fixed pair of positive integers r,s.
The case (2,2) is OEIS A189281.

It also proves the same expansion for edge-avoiding bijections between
unions of long directed paths, a superfactorially small bound for changes
in their component lengths, and all-orders smooth-model inverse expansions
with rigorous discrete-threshold rounding bounds.

It does not prove the guessed order-eight recurrence or identify every flat
transseries sector. See source_status.md for the primary-source check and
the important August 2026 update to the general-holonomicity question.

## Build the paper

With a standard TeX Live installation:

    sh build.sh

This produces article.pdf. The delivered PDF is the same manuscript under
a descriptive filename.

## Reproduce the checks

Python 3 and SymPy are needed for the main coefficient calculation and the
Bonferroni checker. The direct combinatorial and independent coefficient
checks use the Python standard library only.

    python -O compute_coefficients.py 2 2 10
    python -O check_stable_tilings.py
    python -O check_bonferroni.py
    python -O independent_review/check_coefficients.py
    python -O independent_review/check_order_ten.py

Expected results:

- Normalized A189281 coefficients through order ten:
  1,3,2,1,0,3,26,101,124,-1409,-13266
- 180 direct stable-tiling coefficient equalities
- 48 brute-force permutation checks through n=8
- 13 exact OEIS A189281 terms
- Exact Bonferroni probability intervals at n=100,200,1000
- Independent reconstruction through order ten, agreeing with the full list
- 299 independent finite-difference polynomial checks, 16 general (r,s)
  cases through order three, and 25 additional edge-subset profile checks
- Additional order-ten reconstruction: 139 profiles, 423 polynomial checks

The computation files contain explicit exceptions rather than assertions,
so python -O does not disable the checks. Exact rational intervals are
stored before the decimal summaries; the latter are regression evidence.

The proofs were checked by direct derivation and exact computations.
They are not externally refereed or formally verified.
