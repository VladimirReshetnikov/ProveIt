# Nested Rank Six Families and Conditional Barriers

This addendum proves three distinct results about rank-six matching-support polynomials.

1. With a complete 3×3 core, common unit exterior-left neighborhoods and nested exterior-right neighborhoods, arbitrary one-shore activities give ULC6.
2. A specific 20-vertex graph with a unique 3+3 minimum cover has a right marginal that is not Lorentzian. This obstructs a stronger proof route; it is not a scalar ULC6 counterexample.
3. In the displayed 3+3 minimum-cover class with one unit shore, every quadratic sector obtained by forcing four vertices on the weighted shore satisfies c1²≥3c0c2. The rank-six requirement is only 12/5, so these sectors cannot cause failure.

General finite-activity rank-six one-shore ULC remains open. No sharpness claim is made for the conditional constant 3. The later matrix-conditioning construction is separate and is not used in this report.

Read `article.pdf`. Editable sources are `article.tex` and `conditioning.tex`.

Run all exact checks with:

`python3 checks/run_all.py`

Only Python's standard library is required. The checks reconstruct and compare all 3,391 nested-certificate vectors, perform 80 literal small-graph support checks, verify the 20-vertex marginal obstruction and unique minimum cover, and test 2,071 weighted sector formulas. These finite checks supplement the analytic conditional proof; they do not replace it.

The full nested certificate is `data/exact_certificate.json`, with coefficients scaled by 36 and ordered by increasing powers of z=n−3. The sharp two-row inequality used in the conditional proof is proved in the companion report *Weighted Rank Five and Two Shore Covers*.

A normal TeX installation can build the PDF by running `pdflatex article.tex` twice. `build_local.sh` also supports the supplied minimal TeX environment.

The proofs and certificates were independently reconstructed. This is not formal theorem-prover verification, external peer review, or an exhaustive literature-priority claim.
