BOOLEAN FOURIER CORRELATIONS
Bias Transfer, Growth, and Observation Variance

Research manuscript prepared with OpenAI ChatGPT for Vladimir Reshetnikov
7 October 2026

CONTENTS

article.tex     Complete, self-contained LaTeX source, including bibliography.
article.pdf     Compiled A4 research article.
Makefile        PDF build and exact certificate regeneration.
PROVENANCE.txt  Repository pins, source dependencies, and contribution scope.
code/          Three standard-library Python verification programs.
data/          Their exact JSON certificates.

The article contains full proofs, a reconstruction of the source Gaussian
reporting mechanism, exact finite constructions, and twelve proposed research
directions. It is intended for integration into ProveIt's research collection.

MAIN RESULTS

1. An explicit 18-valued observation of 20 uniform signs with exact cell
   degree 16 and retained variance 16 + 9/34816. A canonical binomial family
   has a closed rational variance formula.

2. One fixed averaging count works at every stage of the source observation
   amplification. Standardized scores have fourth moment at most 6 and
   uniformly bounded moments at every fixed positive order.

3. The extremal Boolean singleton mass has a genuine exponent alpha in
   (1/2,1]. The dimension-restricted exponent alpha(gamma) is nondecreasing
   and concave, equals 1/2 at gamma=1, and is strictly larger for every
   gamma>1. Its initial right derivative has an exact finite-seed variational
   formula.

4. Signed restrictions compare arbitrary interior product-bias profiles at
   the same degree and dimension. A separate quantile-block construction
   yields a square-root gain in block size. The normalized all-level bound
   follows from published maximal-retention restriction identities; the
   article explicitly credits that prior work. Conjunctions establish its
   first-order small-bias sharpness and the sharp boundary blowup power.

5. A weighted retained-variance ceiling D^2 ||a||_infinity^2 holds under
   arbitrary interior product biases, giving D^2 when |a_i| <= 1. For finite
   uniform cubes, V(D) <= D^2 - 1/Q_D for D>=2,
   with Q_D = 2^D lcm(1,...,2^D). Degree-D observations have at most 2^D
   nonempty cells and depend on at most D(2^D-1) coordinates. V(D) is an
   attained rational maximum computable by finite enumeration.

6. The exact uniform degree-two optimum is V(2)=2. A degree-two binary
   observation of three signs under bias p=4/5 instead has normalized
   retained variance 27/13. The least uniform cell degree allowing a strict
   variance surplus is therefore between 3 and 16.

BUILD THE ARTICLE

Requires a standard LaTeX installation with pdfLaTeX, latexmk, Latin Modern,
amsmath, amsthm, mathtools, microtype, booktabs, enumitem, fancyhdr, and xurl.
No external figures, bibliography database, or network access is needed.

    make pdf

Equivalent command:

    latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex

The source can also be compiled with pdfLaTeX repeatedly until references
and the table of contents stabilize.

REGENERATE THE EXACT CERTIFICATES

Requires Python 3.10 or later, with no third-party packages.
Run with assertions enabled (do not use python -O).

    make verify

Or run the three programs individually from this directory:

    python3 code/verify_binomial_reporter.py > data/binomial_reporter_certificate.json
    python3 code/verify_bias_transfer.py > data/bias_transfer_certificate.json
    python3 code/verify_restriction_transfer.py

The last program writes data/restriction_transfer_certificate.json and also
prints its concise JSON summary. The other two print their certificate to
standard output. Normal execution does not require internet access.

The binomial program checks all 3125 weighted block-sum tuples representing
the 20-bit cube, and additional small members of the binomial family. The
quantile program directly evaluates all 4096 twelve-bit inputs for each of
eight gadget choices in each of two examples. The restriction program checks
all 256 three-bit Boolean truth tables for one heterogeneous pair of profiles,
all subset identities, degree preservation, weighted level bounds, and small
conjunction formulas. The detailed scope and counts are in the article and
JSON files.

RESEARCH AND VERIFICATION STATUS

This package contains written mathematical proofs and exact finite checks.
It contains no Lean or Rocq formalization. Repository placement by itself
does not confer formal verification or refereeing.

Classical ingredients, the OpenAI source construction, published restriction
identities, elementary composition consequences, and proposed extensions are
distinguished in the article. The priority search was targeted, not exhaustive.
The exact value of alpha, the optimal dimension frontier, and a small explicit
uniform Boolean square-root counterexample remain unresolved here.

The twenty-bit witness is an observation with eighteen outputs. Its variance
surplus alone does not establish a Boolean square-root counterexample. The
analytic amplification theorem supplies the Boolean unboundedness argument.

INTEGRATION

Keep article.tex, article.pdf, the code and data folders, and these provenance
notes together. The source has no dependency on local scratch files or on the
OpenAI or ProveIt source trees. A proposed formalization order is given in the
article, beginning with rational finite-cube statements and their degree
identities. The general analytic theorems should retain their explicit
classical dependencies when formalization is undertaken.
