# Exact Four-Output Binary Reversal

**Optimal state complexity, collision rigidity, and secondary asymptotics**  
Research manuscript prepared for Vladimir Reshetnikov, 29 September 2026.

## Main result

For every `n >= 7`, let `A < B` be the closest coprime positive integers whose
sum is `n`. The manuscript gives a complete proposed proof of

```text
R_2(n,4) = 4^n - 6*2^n - 4*(3^A + 3^B)
                 + 12*(2^A + 2^B) - 12 + A*B.
```

Here `R_2(n,4)` is the largest reversal state complexity of a minimal
`n`-state deterministic finite automaton with two input letters and four
output symbols. The upper bound holds for arbitrary transformation pairs
and output maps, even without accessibility or surjectivity.

The exact split is:

```text
n = 2h+1:             (A,B) = (h,h+1)
n = 2h, h even:       (A,B) = (h-1,h+1)
n = 2h, h odd:        (A,B) = (h-2,h+2)
```

This addresses the four-output slice of Davies's optimality problem and the
explicit four-or-more-output gap in the inspected ProveIt report. It does
not settle the entire variable-output problem.

## What is included

`article.pdf` is the 21-page typeset manuscript; `article.tex` is its
standalone editable source, including the bibliography and printed tables.
The additional results are necessary extremizer rigidity, a quantified
second-collision penalty, a near-extremal stability theorem, the exact
inventory of missing proper cyclic orbits, three secondary asymptotic
regimes, an order-15 recurrence for the deficit, and eight research questions.

`code/verify.py` is the primary exact-arithmetic verifier.
`code/independent_check.py` imports no primary verifier code and uses different
counting formulas. `code/witness_bfs.cpp` performs literal breadth-first
search on packed four-colorings for the published witness.

`data/base_certificate.csv` is the finite certificate used in the proof.
The other CSV and JSON files record regression checks, witness orbits,
recurrence coefficients, and orbit inventories. `SOURCE_AUDIT.md` records
the exact repository pin and literature dependencies. `PROOF_AUDIT.md`
identifies the main logical and computational boundaries.

## Proof and trust boundary

The upper bound is analytic for all `n >= 26`. The remaining nineteen
indices, `7 <= n <= 25`, use an exhaustive **2,059-entry integer certificate**
over mathematically classified collision structures. Both implementations
checked every entry and the strict uniqueness of the minimizer. This is a
finite computer-assisted component, not a fit to observed automaton maxima.

Attainment uses the published Holzer–König two-generator theorem, as stated
and applied in Davies's paper. That theorem is cited, not reproved. The
four-color orbit count, accessibility, and minimality are proved in the
manuscript. The upper bound does not use that external generation theorem.

The manuscript is AI-assisted and unrefereed. It has not been checked in
Lean, Rocq, or another proof assistant. A targeted literature search did not
identify a later resolution, but is not a priority certification. Repository
research statements are not silently treated as formal theorems.

## Reproduce

Python 3.10 or newer is sufficient; only its standard library is used.
Recorded runs used Python 3.13.5. Run commands from this directory.

```sh
python -O code/verify.py
python -O code/independent_check.py

g++ -O3 -std=c++17 -Wall -Wextra -pedantic \
    code/witness_bfs.cpp -o witness_bfs
./witness_bfs 12 > data/bfs.json

latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The independent checker reads the visible finite certificate and rederives
its minimum, margin, candidate count, split, maximum, and runner-up tag.
Run the primary checker first when regenerating all data. Neither checker
uses removable Python assertions. The C++ executable checks its counts
against the formula and exits unsuccessfully on a mismatch; its memory guard
restricts the endpoint to 12. The largest run needs roughly 85 MB for its
coloring mask and queue, plus runtime overhead.

`make all` runs the two Python checks, the C++ searches, and the PDF build.
`make clean` removes build intermediates and the locally compiled binary,
but retains the article PDF and recorded data. There are no third-party
PDFs, font files, downloaded libraries, or binary executables in the archive.

## Recorded checks

The primary comparison covered `n=7..200` and 752,291 structural entries.
The independent comparison covered `n=7..100` and 101,568 entries. Both
contain the 2,059 proof-certificate entries. All minima were unique.
Brute-force graph counts covered 17 graphs and 180,128 colorings; separate
inventory and unique-edge checks covered 81,920 colorings. Accessibility and
minimality were checked for the explicit witness through `n=200`.

Complete witness searches returned:

| n | A | B | Reverse states |
|---:|---:|---:|---:|
| 7 | 3 | 4 | 15,472 |
| 8 | 3 | 5 | 63,403 |
| 9 | 4 | 5 | 258,360 |
| 10 | 3 | 7 | 1,035,217 |
| 11 | 5 | 6 | 4,179,298 |
| 12 | 5 | 7 | 16,744,863 |

A deliberately nonextremal machine satisfying the local necessary
conditions has only 212 reverse states at `n=7`. The paper proves the
simpler upper bound 256 for that example, which already disproves
sufficiency of those conditions.

The larger sweeps, sequence checks, and witness searches are supplementary
validation. They are not proofs over an infinite range and do not replace
the stated analytic argument or the published generation theorem.
