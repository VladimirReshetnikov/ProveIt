Report210 - Larger tree walk lower bounds for sparse graph moments
4 October 2026

RESULT
For k >= 1, M_(2k) >= G_k+J_k. G counts the complete class whose repeated
edges share one vertex. J counts a disjoint rotation-closed family with a
unique hub and exactly one repeated secondary edge. The report gives exact
Bell convolutions and proves
  G_k = 2 B_(k+1) [1+(1+o(1)) W(k)^2/k],
  J_k ~ W(k)^2 B_k,
  M_(2k) >= 2 B_(k+1) + (1-o(1)) W(k)^2 B_k.
The complete one-hub class itself cannot yield a growing multiplier of
B_(k+1). No full-moment asymptotic, inverse theorem, priority claim, or global
open-problem status is asserted. Report209 is a separate preceding release.

CONTENTS
Report210.pdf, Report210.tex      Complete article and editable source
verify_families.py               Standard-library exact mathematical audits
reproduce.py                     Deterministic data, PDF and ZIP builder
requirements.txt                 Python and TeX requirements
SOURCES.txt                      Public references and source-check scope
data/exact_checks.json           Regenerated integer check data
tables/exact.tex                 Regenerated table actually used by the PDF

REPRODUCE
From this extracted directory:
  python3 reproduce.py --out ../run-normal
  python3 -O reproduce.py --out ../run-optimized
Each output directory must be new and outside the source directory. The source
is read-only input. No network or neighboring research files are required.
The verifier independently generates all normalized walks through k=8, verifies
partition restrictions through n=10, scalar formulas and Catalan convolution
coefficients, and produces exact rows through k=32 and selected k through 512.
It uses only Python's standard library and no floating-point calculations.

The driver propagates Python optimization to the verifier, regenerates all data
and tables, compiles the PDF to byte stability, and compares every generated
baseline with the release. reproduction.json records member and whole-ZIP hashes.
The archive uses sorted members, fixed timestamps and modes, and ZIP_STORED.
PDF byte identity is scoped to the same TeX/font toolchain. Other TeX versions
may typeset correctly but create different bytes; this is reported as a failure
rather than silently accepted. Python-generated integer data are toolchain-free.

No correctness guard uses Python assert. These probes must fail before writing:
  python3 reproduce.py --out ../must-not-exist --self-test-failure
  python3 -O reproduce.py --out ../must-not-exist --self-test-failure
verify_families.py independently accepts --self-test-failure too.
The --initialize switch is for authoring a new freeze only, never for verifying
a distributed release. It permits missing generated baselines.

Public source links and bounded access statements are in SOURCES.txt. No private
notes, review correspondence, or third-party full texts are included. Finite
checks corroborate but do not replace the article's all-k proofs.
