# Eventual One Shore Scaling Through Rank Seven

The report proves the conditional quartic inequality C2² >= (15/8) C1 C3 for every genuine 4+3 cover, with all left activities one and arbitrary positive right activities. Combined with the unchanged structural companion, this proves eventual actual-rank ultra-log-concavity through rank seven under common scaling of the right part of any fixed minimum cover. The new 3+4 and 4+3 cases have strict leading gaps.

This is an eventual-scaling theorem, not a general finite-activity theorem. The minimum persistent-failure rank is now bracketed by [8,38]; the finite one-shore-failure bracket remains [6,38].

## Replay

From this directory run:

    python -O code/replay_all.py

Only the Python standard library is needed. The checker verifies its finite-field modulus, then checks 120 represented configurations against direct endpoint-set counts, including 480 exact sector identities and every auxiliary inequality. Finite regressions support reproducibility; the universal result follows from the mathematical proof.

## Build and companions

Build article.tex with pdflatex twice, or use build_local.sh for the local TeX format/font setup. The sealed structural report and its source archive are bundled unchanged in companion/. They include the full general top-gap proof, lower incidence proof, weighted local equality proof, and the earlier small-cover theorem. The rank-38 upper-witness report and its source are also included unchanged.

The structural companion's open middle-gap statement and unsuccessful numerical searches are historical. The present report resolves that middle-gap question by proof, without using numerical optimization as evidence.

This is ordinary mathematics with exact computational checks, not proof-assistant or externally refereed certification.
