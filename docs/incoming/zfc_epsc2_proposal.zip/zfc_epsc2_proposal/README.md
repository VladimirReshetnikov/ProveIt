# A two-parameter closure kernel for small consistency machines

Research report prepared for Vladimir Reshetnikov, 16 October 2026.

## Main result

The report proposes equality-free empty-seed positive subset closure with
two ordinary matrix parameter slots, EPSC2. It supplies an ordinary
mathematical argument formalizable in ZFC for

    Con(EPSC2) <-> Con(ZFC).

Matrices have four allowed free slots (x, y, p, q) and arbitrarily many
internal binders. This is one infinite recursive schema in classical
first-order logic with a binary relation and genuine logical Bottom. It
is not a finite axiom set or a four-variable logic.

The proof audits every use of the two-parameter budget, obtains Pairing
inside a hereditary saturated quotient before packing arbitrary target
parameters, and interprets full extensional positive subset closure.
The report also gives a complete tableau certificate specification,
fixed matrix-environment projections, and a fair numeric enumeration.

## Scope of the machine artifacts

The supplied dag219-compact-zero.tm and dag219-compact-nextproof2.tm have
341 and 343 working states, respectively. They replace the editable clean
assembler's blank-tape initializer while preserving every runtime row.
They **do not implement the new EPSC2 checker**, and they **do not establish
a new ZFC-consistency-machine state bound**.

The new initializer has an exact all-parameter mathematical proof and
literal full-tape replay. The retained runtime still has its published
register-box contracts and unproved full compiler simulation boundary.
The attributed upstream 253-state construction remains the benchmark.

No proof assistant was rebuilt in this investigation. The new
mathematical proofs, reference checker, finite tests, and component
tables have distinct roles; see the report for their exact scope.

## Read or rebuild the report

- report.pdf: complete report.
- report.tex and sections/*.tex: editable source.
- python3 build.py: rebuilds the PDF in three passes.

The build needs pdflatex and a standard TeX Live or MiKTeX installation
with Latin Modern, microtype, geometry, AMS packages, mathtools, booktabs,
longtable, tabularx, enumitem, xcolor, fancyhdr, needspace, listings, hyperref and
bookmark. Build intermediates go in .build/.

## Reproduce the supplied computations

Python 3.10 or later and its standard library are sufficient. No network
access, repository checkout, Lean, Coq or third-party Python package is
needed.

    python3 -B reproduce.py

The script runs in temporary directories, verifies the pinned vendor
hashes, compares the regenerated checker evidence, rebuilds both
transition tables, and compares the tables byte for byte. It runs the
same checks recorded in data/verification.json. An optional fresh
record can be written with:

    python3 -B reproduce.py --record verification-local.json

Do not use python -O or -OO; the component controls use assertions.
All included commands are finite. They do not run the unbounded
consistency search.

Individual commands, if desired:

    python3 -B checker/test_epsc2_tableau.py
    python3 -B engineering/compact_initializer.py --output /tmp/epsc2-initializer

The checker test command updates its adjacent evidence JSON. The
engineering command must write outside the vendor subtree. The
one-command reproduction above leaves the supplied evidence unchanged.

## Artifact guide

| Directory or file | Purpose |
|---|---|
| checker/epsc2_tableau.py | Strict public EPSC2 refutation checker, virtual wrapper, codecs, search |
| checker/test_epsc2_tableau.py | Direct semantics, expanded-versus-virtual comparisons, negative controls, numeric codecs |
| checker/epsc2_tableau_results.json | Recorded finite checker results |
| checker/demonstrations.json | Two ordinary logical theorem demonstrations; not public EPSC2 refutation certificates |
| engineering/compact_initializer.py | New exact binary blank initializer and integration |
| engineering/results/ | Complete 341/343-state tables and finite engineering evidence |
| engineering/vendor/ | Minimal unchanged source snapshot, license and attribution notice |
| engineering/provenance.json | Exact sizes, SHA-256 hashes and source revisions |
| notes/ | Detailed proof, design, engineering and independent review notes |
| data/source_audit.json | Pinned sources and inspected incoming archive hashes |
| data/verification.json | Successful reproduction from this exact archive layout |

The generic tableau test interface accepts arbitrary signed formulas for
logical demonstrations. The public refutation interface accepts only
matrices and proof, constructs its own positive axioms, and rejects
caller-supplied goals or template holes.

## Source cutoff and prior work

The primary project snapshot is VladimirReshetnikov/ProveIt at
af518abcf8ca2a7c1b795c07973885041aee0d25 (20:10:10 UTC).
Both requested commits, 6d8bc7f1ba02c83e54757366f019f61b966ed0b7 and
63c83cf79986f8a92bb75460848a1d4f863b7b15, are included in the audit,
together with later formalization, compiler work, and six incoming
research archives. Full linked references are in the report.

The empty-seed schema, unrestricted saturation calibration, earlier
environment-tableau prototype, full finite-sort countermodel, three-axiom
SK carrier, and the earlier 248–250/253-state work are credited as prior
work. The new focus is the two-slot calibration, its exact projected
checker interface, and the separate compact initializer.

The upstream source data are pinned at jeff87654/busy-beaver revision
297ab8df7e5de329605c3875b4934643b371a5e3.
The 253-state PR endpoint was inspected at mira-emmy/busy-beaver revision
0d544f2a2e3c18f12278441a74b7879f31cbe856.
See engineering/vendor/NOTICE.txt for attribution and license scope.
