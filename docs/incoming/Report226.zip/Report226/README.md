# Report 226

First logarithmic correction for iterated Euler diagonals

5 October 2026. An unrefereed mathematical research report, not a proof-assistant formalization.

## Results and scope

For A290354 the report proves

    a_n = c (2n/pi)^n n^(-4/3)
          [1 + (-log(n)^2/18 + A log(n) + C)/n + O(n^(-7/5))].

The constants are exact expressions in the normalized positive density h and its first two derivatives. The new clock constant kappa is evaluated in terms of pi, log(2), and Catalan's constant. The proof uses the analytic foundation in the preceding unrefereed Report 225, restates its full interface, and supplies complete new clock, forced-phase, growing-strip, and high-derivative extraction arguments. The unchanged Report225 PDF and TeX are included as supporting references with exact provenance.

The public proof chooses K=floor(sqrt(n)), a strip of height n^(1/20), and derivative order 30. Local matching and phase errors are O(n^(-3/2)); central integration is O(n^(-29/20)); angular tails are O(n^(-3/2)). The stated relative O(n^(-7/5)) deliberately leaves margin. This strengthened rate is justified by the proof's explicit error budget, not by a fit to finite values.

The uniform A290353 correction holds for beta=n/m in a fixed compact positive interval. A Lambert W inverse has error O(X^(-7/5)/log X) at exact sequence values when exact constants are used. There is no certified decimal value, effective onset, arbitrary finite-threshold certificate, endpoint beta uniformity, all-orders theorem, or worldwide priority claim. All numerical examples are explicitly noncertified.

## Requirements

Exact recurrence and formal-coordinate code: Python 3.11+ standard library.
New clock identities: SymPy. Optional diagnostics: NumPy and SciPy.
PDF: pdfTeX/TeX Live with geometry, fontenc, lmodern, microtype, amsmath, amssymb, amsthm, mathtools, booktabs, hyperref, bookmark, enumitem.

Tested toolchain: Python 3.12.14, SymPy 1.14.0, NumPy 2.3.5, SciPy 1.17.0, pdfTeX 1.40.26. No package is installed automatically. The builder creates a private pdfLaTeX format and does not change user-global TeX configuration. Identical toolchains reproduce identical bytes; different fonts or TeX versions may change PDF bytes.

## Exact and symbolic commands

From this directory:

    python -B code/exact_euler.py --max-index 20
    python -B code/exact_euler.py --max-index 20 --height 10
    PYTHONINTMAXSTRDIGITS=640 python -B code/test_exact.py --cap 414
    PYTHONINTMAXSTRDIGITS=640 python -B -O code/test_exact.py --cap 414
    python -B code/coordinate_series.py --order 12
    python -B code/clock_checks.py
    python -B code/test_guards.py
    python -B code/test_guards.py --with-diagnostics

The inherited exact recurrence supports degree and height independently from 0 through 640; the fresh full-diagonal verification in this report is through 414. The builder deliberately uses cap 414. The independent product routine supports degree at most 20 and is compared through degree and height 12. The exact diagonal fixture through 414 is generated arithmetic data; the external OEIS comparison is only its 22 displayed terms n=0..21. Full diagonal computation takes O(N^3) integer arithmetic operations and O(N) stored integers, with growing bit complexity.

The formal-coordinate generator supports all orders 0..12, freshly exercised by the guard suite; known coefficients through 9 are compared exactly. The new symbolic suite checks finite fifth-order forcing and M/N algebra, asymptotics, the kappa evaluation, Fatou/cohomological identities, inverse and proportional-height polynomials, and exact rational exponent arithmetic. These finite checks are not certificates of analytic uniformity or convergence.

The recurrence stores F_h with constant zero; user-facing a_0 and b_(0,h) are separately 1. All validations use explicit exceptions, survive -O, and do not modify Python's global integer-string digit limit. Chunked serialization handles the 1000-digit a414 at PYTHONINTMAXSTRDIGITS=640. Commands write JSON to stdout, not into the source tree; optional --out paths must be new.

## Optional diagnostics

    python -B code/amplitude_diagnostic.py --depth 100 --sigma 0 --cutoff 3000 --step .02 --out /tmp/new_amplitude.json
    python -B code/derivative_diagnostic.py --grid --out /tmp/new_derivatives.json

The derivative script uses a truncated formal coordinate, floating-point Newton inversion, finite forward iteration, and a P''' inversion with rational-tail subtraction. It computes h(1), h'(1), h''(1), and the correction from analytic formulas; nothing is fitted to exact sequence values. It accepts depths 50..200, cutoffs 10..10000, steps 0.005..0.1, at most one million intervals, and exact-fixture comparisons at indices 1..414. See --help for individual-run options. The amplitude program has the same depth/cutoff/step ranges and additionally sigma in [-2,0]. Each script adjusts Simpson intervals to an even number and reports actual spacing. Guard tests with --with-diagnostics require NumPy/SciPy.

The recorded derivative grid and amplitude grids are floating-point diagnostics, not interval enclosures. Parameter stability does not certify a single displayed decimal digit. data/code_validation.json records actual finite test scope; data/symbolic_checks.json records finite exact checks.

## Source preserving build

Choose a NEW output directory outside this source directory, with no symlink ancestor:

    PYTHONINTMAXSTRDIGITS=640 python -B build.py --out /tmp/report226_normal
    PYTHONINTMAXSTRDIGITS=640 python -B -O build.py --out /tmp/report226_optimized

The builder runs cap 414 exact tests, formal/input guards, and symbolic clock tests in the same optimization mode as its parent. NumPy/SciPy are not required for a standard build. The deterministic receipt omits environment-dependent guard metadata, while full raw logs remain outside the archive.

The builder validates MANIFEST.sha256, including absent or unexpected source files, snapshots all sources, runs tests, compiles three times without shell escape, rejects overfull boxes/missing glyphs/unresolved references, and checks source bytes are unchanged. It writes Report226.pdf, Report226.zip, and build_checks.json. ZIP members are sorted, uncompressed, and have fixed timestamps. Logs and private TeX files remain outside the ZIP. Actual whole ZIP bytes and every member are compared between normal and optimized builds. Reproducibility does not replace mathematical review and inspection of all rendered pages.

An extracted ZIP is itself rebuildable. Only root Report226.pdf and build_checks.json are reserved regenerated files excluded from the source manifest; supporting/Report225.pdf is an immutable source reference. Outputs must go to a new directory outside the extracted package.

## Contents

- src/report226.tex: complete editable article
- supporting/Report225.pdf and supporting/report225.tex: unchanged preceding report
- code/: exact recurrence, formal coefficients, clock checks, guard tests, optional diagnostics
- data/: exact414 fixture, finite symbolic checks, validation summary, noncertified diagnostics
- sources/: public provenance and 22 displayed OEIS terms
- build.py and MANIFEST.sha256: deterministic build and source integrity

No private research or review records are included. No script uploads, publishes to OEIS, or changes a repository.
