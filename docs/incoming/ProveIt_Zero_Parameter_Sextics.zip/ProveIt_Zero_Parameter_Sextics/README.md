# The Missing Zero-Parameter Test
## Collision certificates, affine-rank rigidity, and a two-resolvent sextic criterion

Research article prepared for Vladimir Reshetnikov, 30 September 2026.

## Main results

For an irreducible sextic over a characteristic-zero field, the repository's
**compressed** matching resolvent at parameter zero is a safe positive
radical-solvability certificate. Together with one triple resolvent, it decides
solvability. The original bivariate descriptor evaluated on its curve is NOT
usable at zero: its affine multiplier vanishes and all values coincide.

The article also proves that a pentad's five `(A, B, C)` vectors have affine
rank at least two. The exceptional polynomial in the predecessor report can
therefore have degree at most one, not two; any exceptional parameter is
nonzero. Two arbitrary distinct matching parameters suffice when zero is
excluded. The existence of a nonzero exception for a nonsolvable irreducible
sextic is not settled.

The coefficient formulas consist of a denominator-free, order-20 Pfaffian
for the degree-10 complementary-triple product-sum resolvent, and an order-15
cubic matrix polynomial / trace recurrence for the degree-15 matching
pair-product-sum resolvent. The Pfaffian identity generalizes to every odd
middle exterior degree.

## What is and is not new

The general sextic solvability problem and the matching invariant are
classical. Boswell–Glasser's 2005 matching invariant is `e6 * A_P` after
relabeling. This article's claimed contributions are the explicit collision
certificate, the selected-zero result for the inspected ProveIt family, the
affine-rank bound, and the stated coefficient realizations. Historical
priority is not certified. See `SOURCES.md` and article Section 1.

The article has complete written proofs and executed exact checks, but is
AI-assisted, unrefereed, and **not formalized in Lean or Rocq**. The repository
was neither modified nor rebuilt. The programs are not verified extractions.

## Files

`article.tex` and `article.pdf` are the main deliverables. `code/` contains the
coefficient-only evaluator, full exact regression suite, and an independent
standard-library polynomial-certificate checker. `data/` contains the delivered
run records, source metadata, and a build record. `SHA256SUMS` authenticates the
package's payload bytes against accidental changes; it is not a theorem
certificate or digital signature.

## Reproduce the checks

Python 3.10 or later is required. The recorded environment was Python 3.13.5
with SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python code/check_certificate.py
python code/verify.py
```

The full verifier writes to `rerun/verification.json` by default, leaving the
recorded `data/verification.json` intact. An explicit `--output FILE` changes
that destination. Run time depends on the environment. No floating-point root
approximations enter the checks or the decision API.

The suite includes a universal polynomial identity, pentad incidence and sum
identities, affine transformations, seven split-root cases (including zero and
repeated roots), and 48 irreducible examples covering all 16 transitive sextic
group types, with 36 positive and 12 negative solvability answers. The two
implemented criteria agree with SymPy's Galois classifier in every case. The
classifier shares the same arithmetic library: this is an independent route,
not an independent formal verification. No nonsolvable nonzero exception is
exhibited.

## Use the solver

```sh
python code/sextic_resolvents.py 1 0 0 1 0 0 2
```

This tests `x^6 + x^3 + 2`. Seven coefficients are supplied in descending degree
order. They may be exact rational numbers such as `1/2`. The public Boolean
API rejects reducible inputs and nonsextics.

```python
import sys
sys.path.insert(0, 'code')
from sextic_resolvents import (
    X, matching_resolvent, triple_resolvent,
    zero_matching_resolvent, decide_irreducible_sextic,
)

f = X**6 + X**3 + 2
print(decide_irreducible_sextic(f))  # True
print(matching_resolvent(f))
print(triple_resolvent(f, method='pfaffian'))
print(zero_matching_resolvent(f))
```

`matching_resolvent` computes `product_P (Z - A_P)`; this is **not** the
repository's `R_2(0,Z) = product_P (Z + C_P)`.
`zero_matching_resolvent` computes the latter by reciprocal transport and
requires a nonzero constant term. `triple_resolvent` computes
`product_T (Z - b_T)`; the repository's compressed `R_3(0,Z)` has the opposite
root signs. These sign changes preserve base-field root existence.

The default triple algorithm uses exact traces. The optional Pfaffian method
uses 11 exact samples and interpolation, with rational skew elimination. The
mathematical Pfaffian identity is a polynomial without input denominators;
the elimination algorithm itself uses nonzero rational pivot divisions.

## Build the PDF

```sh
bash build.sh
```

A standard TeX Live installation with `pdflatex`, `newtx`, `amsmath`, `amsthm`,
`mathtools`, `microtype`, `booktabs`, `enumitem`, `needspace`, `xurl`, `hyperref`,
and the usual layout packages is sufficient. The source has an internal
bibliography; BibTeX is not required. Intermediate LaTeX files are generated
when rebuilding but are not part of the delivered archive.
