#!/usr/bin/env python3
"""Fresh finite partial-tape proof of U213 -> U212. Uses explicit checks under -O."""
from pathlib import Path
import hashlib,json,argparse
ROOT=Path(__file__).resolve().parent
PIN='bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7'
def need(v,m):
 if not v:raise ValueError(m)
def read(p):
 t={}
 for line in p.read_text().splitlines():
  if not line or line.startswith('#'):continue
  fs=line.split();need(len(fs)==5,'five fields');q,b,w,d,z=fs;q,b,w,z=map(int,(q,b,w,z));need(b in(0,1)and w in(0,1)and d in('L','R'),'binary move');need((q,b)not in t,'duplicate row');t[q,b]=(w,1 if d=='R'else-1,z)
 states={q for q,b in t};need(len(t)==2*len(states),'complete rows');need(0 in states and 254 not in states,'start/halt');need(all(z in states|{254}for w,d,z in t.values()),'target closure');return t
def encode(t):return '#! start 0\n'+''.join(f'{q} {b} {w} {"R"if d==1 else"L"} {z}\n'for(q,b),(w,d,z)in sorted(t.items()))
def trace(t,q,tape,steps):
 h=0;v=dict(tape);log=[]
 for _ in range(steps):
  need(q!=254,'interior halt');need(h in v,'read of unspecified exterior');b=v[h];w,d,z=t[q,b];log.append(dict(state=q,head=h,read=b,write=w,move=d,next=z));v[h]=w;h+=d;q=z
 return (q,h,v),log
def case(a,b,qa,qb,tape,na,nb):
 ea,ta=trace(a,qa,tape,na);eb,tb=trace(b,qb,tape,nb);need(ea==eb,'different endpoint');need(ea[2]==tape,'changed tape');return dict(input=tape,old_steps=na,new_steps=nb,endpoint=ea,old_trace=ta,new_trace=tb)
def incoming(t,z):return sorted([q,b,w,d]for(q,b),(w,d,target)in t.items()if target==z)
def certify(parent,out):
 need(hashlib.sha256(parent.read_bytes()).hexdigest()==PIN,'wrong parent');A=read(parent);need(len(A)==426,'213 states');B=dict(A);need(A[180,1]==(1,1,172),'original row');B[180,1]=(1,1,211)
 first=[case(A,B,180,180,{0:1,1:1},2,2),case(A,B,180,180,{0:1,1:0,2:0},7,3),case(A,B,180,180,{0:1,1:0,2:1},7,3)]
 # State0 is neither marked state. Syntactic entry checks support induction.
 need(incoming(B,112)==[[172,0,0,-1]],'112 entry');need(incoming(B,172)==[[116,0,0,1]],'172 entry')
 # At172 the immediate left cell is zero, from116/0. On172/0 both
 # its current cell and that left cell are zero; moving L enters112
 # on0 with its right neighbor0. No other transition enters112.
 phi=lambda q:67 if q==112 else q
 C={(q,b):(w,d,phi(z))for(q,b),(w,d,z)in B.items()if q!=112}
 need(C[172,0]==(0,-1,67),'redirected row');need(all(C[k]==v for k,v in B.items()if k[0]!=112 and k!=(172,0)),'extra changes')
 second=[case(B,C,112,67,{0:0,1:0},3,1)]
 for(q,b),(w,d,z)in B.items():
  if q==112:continue
  need(C[phi(q),b]==(w,d,phi(z)),'ordinary row does not commute')
 need(len(C)==424,'212 states');out.mkdir(parents=True,exist_ok=True)
 (out/'retimed213.native.tm').write_text(encode(B));(out/'u212.native.tm').write_text(encode(C));mp={q:i for i,q in enumerate(sorted({q for q,b in C}))};mp[254]=212
 dense={(mp[q],b):(w,d,mp[z])for(q,b),(w,d,z)in C.items()};(out/'u212.tm').write_text(encode(dense));(out/'dense_map.json').write_text(json.dumps(mp,indent=2)+'\n')
 info=dict(parent_sha256=PIN,intermediate_sha256=hashlib.sha256(encode(B).encode()).hexdigest(),native_sha256=hashlib.sha256(encode(C).encode()).hexdigest(),dense_sha256=hashlib.sha256(encode(dense).encode()).hexdigest(),states=212,rows=424,stage1=first,stage2=second,marker_incoming={'112':incoming(B,112),'172':incoming(B,172)},ordinary_stage1_rows=425,ordinary_stage2_rows=424,scope='All initial tapes from state0; exact partial-tape identities and syntactic entry invariants. Positive block induction in PA.')
 (out/'CERTIFICATE.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps({k:v for k,v in info.items()if k not in ('stage1','stage2')},indent=2));return info
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--parent',type=Path,default=ROOT.parent/'baseline/primary_u213/machine/u213.native.tm');ap.add_argument('--out',type=Path,default=ROOT.parent/'evidence/reconstructed');a=ap.parse_args();certify(a.parent,a.out)
