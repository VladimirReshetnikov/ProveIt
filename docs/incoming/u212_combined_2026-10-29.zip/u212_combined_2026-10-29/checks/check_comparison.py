from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1]
def need(x,m):
 if not x:raise ValueError(m)
records=json.loads((R/'inputs/COMPARISON_SELECTION.json').read_text());old=json.loads((R/'evidence/TABLE_COMPARISON.json').read_text());known={x['packet']:x for x in old};out=[]
def metrics(rows):
 by={p:(op,arg)for p,op,arg in rows};need(len(by)==len(rows),'duplicate source');prefixes={p[:j]for p in by for j in range(len(p))};need(not prefixes.intersection(by),'source prefix');nodes=set()
 def rec(p):
  if p in by:v=by[p]
  else:
   need(p in prefixes,'missing binary child');v=(rec(p+'0'),rec(p+'1'))
  nodes.add(v);return v
 rec('');return len(rows),len(nodes)
for x in records:
 name=x['archive']['name'][:-4];p=R/'comparison_inputs'/x['id'];table=p/'machine/u213.native.tm';b=table.read_bytes();sha=hashlib.sha256(b).hexdigest();k=known[name];need(sha==k['native_sha'],'native comparison pin')
 rows=[l.split()for l in b.decode().splitlines()if l and not l.startswith('#')];need(len(rows)==426 and len({r[0]for r in rows})==213,'count')
 source=p/'machine/sites.json'
 if not source.exists():source=R/'baseline/u214/machine/sites.json'
 s=source.read_bytes();need(hashlib.sha256(s).hexdigest()==k['source_sha'],'source comparison pin');leaves,dag=metrics(json.loads(s));out.append(dict(packet=name,native_sha256=sha,source_sha256=hashlib.sha256(s).hexdigest(),leaves=leaves,dag=dag))
need(len(out)==8 and len({x['native_sha256']for x in out})==8,'distinct eight')
(R/'evidence/COMPARISON_CHECK.json').write_text(json.dumps(dict(status='PASS',packets=out),indent=2)+'\n');print(json.dumps(out,indent=2))
