from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1]
rows=json.loads((R/'MANIFEST.json').read_text())
for row in rows:
 p=R/row['path'];b=p.read_bytes()
 if len(b)!=row['bytes']or hashlib.sha256(b).hexdigest()!=row['sha256']:raise ValueError(row['path'])
print(json.dumps(dict(status='PASS',manifest_files=len(rows))))
