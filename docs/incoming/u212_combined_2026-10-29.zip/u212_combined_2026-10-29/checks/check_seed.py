"""Literal whole-tape initialization audit, independently authored."""
from pathlib import Path
import json,sys,hashlib
R=Path(__file__).resolve().parent;P=R.parent/'baseline/primary_u213';F=Path(sys.argv[1])if len(sys.argv)>1 else P/'machine/u213.native.tm';out=Path(sys.argv[2])if len(sys.argv)>2 else R.parent/'evidence/PARENT_STARTUP.json'
def need(x,m):
 if not x:raise ValueError(m)
t={}
for line in F.read_text().splitlines():
 if not line or line.startswith('#'):continue
 q,b,w,d,z=line.split();t[int(q),int(b)]=int(w),1 if d=='R'else-1,int(z)
q=h=0;ones=set();edited=0
for i in range(48140):
 b=int(h in ones);edited+=((q,b)in((180,1),(172,0)))
 w,d,q=t[q,b]
 if w:ones.add(h)
 else:ones.discard(h)
 h+=d
need((q,h)==(84,-2),'state/head');pc='001100110101010';logical=[1,0,13,0,0,1,0,0,1];phy=(6,2,0,4,3,7,8,5,1);vals=[0]*9
for i,j in enumerate(phy):vals[j]=logical[i]
expected={h-1,h+56}|{h+i for i,c in enumerate(pc)if c=='1'};pos=h+57
for v in vals+[1]*43:
 pos+=1;expected.update(range(pos,pos+v+1));pos+=v+1
need(ones==expected,'whole tape');need(len(ones)==120,'ones count')
r=dict(status='PASS',table_sha256=hashlib.sha256(F.read_bytes()).hexdigest(),steps=48140,state=q,head=h,header=54,header_distance=56,source_ordinal=136,source_address=pc,logical_registers=logical,spares=[1]*43,one_cells=len(ones),zero_exterior=True,edited_row_visits=edited)
out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
