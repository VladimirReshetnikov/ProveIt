from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1]
def need(x,m):
 if not x:raise ValueError(m)
rows=json.loads((R/'inputs/PRESERVED_FILES.json').read_text())
for row in rows:
 f=R/row['path'];b=f.read_bytes();need(len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'],row['path'])
comparison=json.loads((R/'inputs/COMPARISON_SELECTION.json').read_text())
for p in comparison:
 for row in p['selected']:
  b=(R/row['output_path']).read_bytes();need(len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'],row['output_path'])
orig=R/'baseline/owned_u213_selected/checks/runtime';new=R/'checks/runtime56'
s=(orig/'symbolic_runtime.py').read_bytes();n=(new/'symbolic_runtime.py').read_bytes()
need(hashlib.sha256(s).hexdigest()=='7ca30fd11def00e973d8f30997e51fa2dd87ae2eff311ea8c9fc4ac08c9d774f','owned symbolic origin')
need(n==s.replace(b'num(64-len(pc))',b'num(56-len(pc))').replace(b'num(64+delta+overflow-len(successor))',b'num(56+delta+overflow-len(successor))'),'exact two constant changes')
s=(orig/'independent_runtime.py').read_bytes();need(hashlib.sha256(s).hexdigest()=='0d1dae10b921cc302a2211d9251ca7ec131aa63ecb040ce66720894877700346','independent origin');need(s==(new/'independent_runtime.py').read_bytes(),'unchanged independent helper')
print(json.dumps(dict(status='PASS',preserved=len(rows),comparison_selected=sum(len(p['selected'])for p in comparison),owned_runtime_origin='PASS')))
