from pathlib import Path
import json,hashlib
import certify_u212 as C
R=Path(__file__).resolve().parents[1]
N=R/'machine/u212.native.tm';D=R/'machine/u212.tm'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
C.need(sha(N)=='386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4','native pin');C.need(sha(D)=='c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e','dense pin')
A=C.read(R/'baseline/primary_u213/machine/u213.native.tm');T=C.read(N);expected={k:v for k,v in A.items()if k[0]!=112};expected[180,1]=(1,1,211);expected[172,0]=(0,-1,67);C.need(T==expected and len(T)==424,'delta')
M={int(k):v for k,v in json.loads((R/'machine/dense_map.json').read_text()).items()};states={q for q,b in T};C.need(set(M)==states|{254} and set(M.values())==set(range(213)) and len(M)==213 and M[0]==0 and M[254]==212,'dense map')
dense={}
for l in D.read_text().splitlines():
 if l.startswith('#')or not l:continue
 q,b,w,d,z=l.split();key=int(q),int(b);C.need(key not in dense,'duplicate dense');dense[key]=int(w),1 if d=='R'else-1,int(z)
C.need(dense=={(M[q],b):(w,d,M[z])for(q,b),(w,d,z)in T.items()},'conjugacy')
def render(q,b):
 w,d,z=dense[q,b];return str(w)+('R'if d==1 else'L')+('H'if z==212 else str(z))
text=(R/'transition_table.tex').read_text()
for i in range(71):
 cells=[]
 for q in(i,i+71,i+142):cells += [str(q),render(q,0),render(q,1)]if q<212 else ['','','']
 C.need('&'.join(cells)+'\\\\'in text,('appendix',i))
seen={0};todo=[0]
while todo:
 q=todo.pop()
 for b in(0,1):
  if(q,b)not in T:continue
  z=T[q,b][2]
  if z not in seen:seen.add(z);todo.append(z)
C.need(seen==states|{254},'graph reachability')
print(json.dumps(dict(status='PASS',states=212,rows=424,appendix_rows=71,dense_bijection='PASS',graph_reachable_states=212)))
