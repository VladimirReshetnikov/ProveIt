"""Portable offline replay. Runtime proofs require assertions enabled."""
from pathlib import Path
import sys,subprocess,json,time,os
R=Path(__file__).resolve().parents[1];os.chdir(R)
if not __debug__ or sys.flags.optimize:raise RuntimeError('Run replay without -O; optimized finite subcommands are separate.')
base=[['checks/check_preserved.py'],['checks/check_comparison.py'],['checks/check_direct_source.py','baseline/primary_u213'],['checks/certify_u212.py'],['checks/check_u212_independent.py'],['checks/check_mutations.py'],['checks/check_artifact.py'],['checks/check_seed.py','machine/u212.native.tm','evidence/U212_STARTUP.json']]
steps=[]
for a in base:steps += [a,['-O']+a]
steps += [['checks/check_runtime56.py','baseline/primary_u213/machine/u213.native.tm','evidence/PARENT_RUNTIME.json'],['checks/check_runtime56.py','machine/u212.native.tm','evidence/U212_RUNTIME.json']]
records=[]
for a in steps:
 t=time.monotonic();p=subprocess.run([sys.executable]+a,text=True,capture_output=True);records.append(dict(command=[sys.executable]+a,exit=p.returncode,seconds=round(time.monotonic()-t,3),stdout=p.stdout,stderr=p.stderr));print('PASS'if p.returncode==0 else'FAIL',' '.join(a),flush=True)
 if p.returncode:print(p.stdout,p.stderr);break
status='PASS'if len(records)==len(steps)and all(x['exit']==0 for x in records)else'FAIL'
(R/'evidence/REPLAY.json').write_text(json.dumps(dict(status=status,steps=records),indent=2)+'\n')
if status!='PASS':raise RuntimeError('Replay failed')
