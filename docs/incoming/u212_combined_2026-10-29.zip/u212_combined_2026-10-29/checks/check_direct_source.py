"""Independently authored exact source, arithmetic binding, and seed check.
No supplied programs are imported or executed. Saved call locations are DATA;
all primitive contracts are resolved afresh against the retained Rocq DAG.
"""
from pathlib import Path
import json,re,hashlib,sys
R=Path(__file__).resolve().parent
P=Path(sys.argv[1]) if len(sys.argv)>1 else R.parent/'baseline/primary_u213'
def need(x,m):
 if not x:raise ValueError(m)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cfg(rows):
 bounds={}
 for i,(p,o,a)in enumerate(rows):
  for k in range(len(p)+1):
   prefix=p[:k]
   if prefix not in bounds:bounds[prefix]=[i,i+1]
   else:bounds[prefix][1]=i+1
 ans=[]
 for i,(p,o,a)in enumerate(rows):
  if o=='CI':v=(i+1,)
  elif o=='CH':v=()
  else:
   bit='1' if o=='CC' else '0';n=1 if o=='CD' else a
   locations=[j for j,c in enumerate(p)if c==bit];need(len(locations)>=n,'escaping jump');node=p[:locations[-n]]
   dest=bounds[node][0 if o=='CC' else 1];v=(dest,i+1)if o=='CD'else(dest,)
  ans.append((o,a,v))
 return ans
source=P/'machine/sites.json';need(digest(source)=='7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00','sourcepin');rows=json.loads(source.read_text());whole=cfg(rows)
old=json.loads((P/'inputs/st215.sites.json').read_text());u=json.loads((P/'inputs/u214.sites.json').read_text());oc,uc=cfg(old),cfg(u)
def moved(i):return i if i<4481 else i-823
for i in list(range(2884))+list(range(4481,len(old))):
 o,a,ds=oc[i];need(not any(2884<d<4481 for d in ds),'stray entry');need(whole[moved(i)]==(o,a,tuple(map(moved,ds))),('exterior',i))
for j in range(2885,3659):
 o,a,ds=uc[j];need(all(2885<=d<=3659 for d in ds),'emitter escaping');need(whole[j-1]==(o,a,tuple(d-1 for d in ds)),('emitter',j))
# Expand only finite named nodes, with explicit acyclicity checking.
text=(P/'inputs/DagPerm.v').read_text();edge=r'(?:ENode|EInc|EDecnz|EBreak|EContinue)\s+\d+|EHalt';pat=r'^\s*\|\s*(\d+)\s*=>\s*\(('+edge+r'),\s*('+edge+r')\)\s*$'
nodes={int(n):(a,b)for n,a,b in re.findall(pat,text,re.M)};need(len(nodes)==487,'dagcensus')
def expand(e,p='',anc=()):
 v=e.split();k=v[0]
 if k=='ENode':
  n=int(v[1]);need(n not in anc and n in nodes,'bad DAG');return expand(nodes[n][0],p+'0',anc+(n,))+expand(nodes[n][1],p+'1',anc+(n,))
 return [(p,{'EInc':'CI','EDecnz':'CD','EBreak':'CB','EContinue':'CC','EHalt':'CH'}[k],None if k=='EHalt'else int(v[1]))]
suffix=json.loads((P/'evidence/suffix.json').read_text());commands=json.loads((P/'evidence/commands.json').read_text());calls=suffix['constructor_calls']+suffix['gate_calls']+commands['macro_bindings'];covered=set();swaps=0
lemmas=(P/'references/ProgLibPerm.v').read_text()
for call in calls:
 lo,hi,n=call['start'],call['stop'],call['dag_node'];proof=cfg(expand('ENode '+str(n)));need(hi-lo==len(proof),'macro size');actual=[(o,a,tuple(t-lo for t in ds))for o,a,ds in whole[lo:hi]]
 need(not covered.intersection(range(lo,hi)),'overlap');covered.update(range(lo,hi));need([x[2]for x in actual]==[x[2]for x in proof],'macro destinations');j=0
 while j<len(proof):
  x,y=actual[j],proof[j]
  if x==y:j+=1;continue
  if x[0]==y[0] and x[0]in('CB','CC'):j+=1;continue
  need(x[0]==y[0]=='CI' and j+1<len(proof),'opcode mismatch')
  x2,y2=actual[j+1],proof[j+1];need(x2[0]==y2[0]=='CI' and x[1]==y2[1] and x2[1]==y[1],'not increment commute')
  need(x[2]==(j+1,) and x2[2]==(j+2,),'increment successors')
  need(all(lo+j+1 not in ds for k,(_,_,ds)in enumerate(whole)if k!=lo+j),'branch into swapped pair');j+=2;swaps+=1
 for name in re.findall(r'ProgLibPerm\.(\w+)',call['lemma']):need(re.search(r'\b'+name+r'\b',lemmas),'missing lemma')
for item in commands['single_primitive_controls']:
 i=item['ordinal'];o,a,ds=item['effect'];need(whole[i]==(o,a,tuple(ds)),'control');need(i not in covered,'control overlap');covered.add(i)
need(covered==set(range(3909)),'incomplete primitive audit')
# Independently replay the short primitive bridge; this is not the suffix theorem.
pc=106;store=[1,0,4,0,0,1,0,0,1]
for step in range(141):
 o,a,ds=whole[pc]
 if o=='CI':store[a]+=1;pc=ds[0]
 elif o=='CD':
  if store[a]:store[a]-=1;pc=ds[1]
  else:pc=ds[0]
 elif o in('CB','CC'):pc=ds[0]
 else:raise ValueError('bridge halted')
need(pc==136 and store==[1,0,13,0,0,1,0,0,1],'bridge')
report=dict(status='PASS',source_sha256=digest(source),primitive_count=3909,retained_exterior=3135,copied_emitter=774,constructor_macro_calls=len(suffix['constructor_calls']),gate_macro_calls=len(suffix['gate_calls']),command_macro_calls=len(commands['macro_bindings']),single_controls=len(commands['single_primitive_controls']),commuted_increment_pairs=swaps,all_3909_covered=True,seed_bridge_steps=141,seed_bridge_target=pc,scope='Exact CFG and finite arithmetic-lemma binding; retained ordinary all-natural macro, source compiler, protected-credit and theory-calibration proofs remain mathematical dependencies.')
(R.parent/'evidence/DIRECT_SOURCE.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
