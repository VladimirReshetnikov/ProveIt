from pathlib import Path
import json
import certify_u212 as c
R=Path(__file__).resolve().parent
A=c.read(R.parent/'baseline/primary_u213/machine/u213.native.tm')
B=dict(A);B[180,1]=(1,1,211)
C={(q,b):(w,d,67 if z==112 else z) for(q,b),(w,d,z)in B.items()if q!=112}
cases=[(A,B,180,180,{0:1,1:1},2,2),(A,B,180,180,{0:1,1:0,2:0},7,3),(A,B,180,180,{0:1,1:0,2:1},7,3),(B,C,112,67,{0:0,1:0},3,1)]
rejected=[]
for i,(left,right,ql,qr,bits,nl,nr)in enumerate(cases):
 c.case(left,right,ql,qr,bits,nl,nr)
 for side,table,q,n in [('old',left,ql,nl),('new',right,qr,nr)]:
  _,tr=c.trace(table,q,bits,n)
  for key in sorted({(r['state'],r['read']) for r in tr}):
   w,d,z=table[key]
   for variant in [(1-w,d,z),(w,-d,z),(w,d,254)]:
    bad=dict(table);bad[key]=variant
    try:c.case(bad if side=='old' else left,bad if side=='new' else right,ql,qr,bits,nl,nr)
    except (ValueError,KeyError):rejected.append(dict(case=i,side=side,row=key,replacement=variant))
    else:raise ValueError('Accepted semantic path mutation')
for bits in ({0:1,1:0,2:0},{0:0,1:1}):
 try:c.case(B,C,112,67,bits,3,1)
 except ValueError:rejected.append(dict(case='marker',input=bits))
 else:raise ValueError('Accepted missing marker')
print(json.dumps(dict(status='PASS',rejected=len(rejected),cases=rejected),indent=2))
