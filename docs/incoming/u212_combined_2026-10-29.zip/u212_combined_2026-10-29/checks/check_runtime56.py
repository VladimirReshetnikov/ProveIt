from pathlib import Path
import sys,json,hashlib,time
if not __debug__ or sys.flags.optimize:raise RuntimeError('Runtime proof assertions must remain enabled')
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'runtime56'));import symbolic_runtime as S
P=R.parent/'baseline/primary_u213'
table=Path(sys.argv[1]) if len(sys.argv)>1 else P/'machine/u213.native.tm';out=Path(sys.argv[2]) if len(sys.argv)>2 else R.parent/'evidence/PARENT_RUNTIME.json'
N=S.r.table(table);sites=json.loads((P/'machine/sites.json').read_text());M={int(k):int(v) for k,v in json.loads((P/'inputs/legacy_mapping.json').read_text()).items()}
for q in {q for q,b in N}|{z for w,d,z in N.values()}:M.setdefault(q,q+1000)
assert len(set(M.values()))==len(M) and M[84]==96 and M[254]==254
assert hashlib.sha256((P/'machine/sites.json').read_bytes()).hexdigest()=='7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00'
assert max(len(p)for p,o,a in sites)<56 and len(sites)==3909
working={q for q,b in N}
assert len(N)==2*len(working) and all((q,b) in N for q in working for b in (0,1))
assert {z for w,d,z in N.values()}-working=={254}
assert all(w in (0,1) and d in (-1,1) for w,d,z in N.values())
leaves={p for p,o,a in sites};prefixes={p[:i]for p in leaves for i in range(len(p))}
assert len(leaves)==len(sites) and not leaves.intersection(prefixes)
assert all(p+b in leaves or p+b in prefixes for p in prefixes for b in ('0','1'))
assert all(set(p)<={'0','1'} and o in ('CI','CD','CB','CC','CH') and ((a is None) if o=='CH' else type(a)is int and (0<=a<9 if o in ('CI','CD')else a>=1)) for p,o,a in sites)
T={(M[q],b):(w,d,M[z])for(q,b),(w,d,z)in N.items()};lemmas,blocks=S.prove_blocks(T);start=time.monotonic();count=0;used=set();cases=[]
for i,site in enumerate(sites):
 for positive in ([False,True]if site[1]=='CD'else[False]):
  c=S.case(T,lemmas,site,positive);used.update(c.pop('rows'));c.pop('trace');count+=1;cases.append(dict(index=i,positive=positive,**c))
 if i%500==0:print(i,count,time.monotonic()-start,flush=True)
assert count==5084
r=dict(status='PASS',cases=count,sites=len(sites),working_states=len(N)//2,table_sha256=hashlib.sha256(table.read_bytes()).hexdigest(),source_sha256=hashlib.sha256((P/'machine/sites.json').read_bytes()).hexdigest(),header_base=56,seconds=time.monotonic()-start,rows_covered=len(used));out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
