import pathlib,hashlib,json
ROOT=pathlib.Path(__file__).resolve().parents[1]
P=ROOT/'baseline/primary_u213/machine/u213.native.tm'
def req(x,m):
 if not x: raise ValueError(m)
def parse(p):
 d={}
 for line in p.read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,m,z=line.split();key=(int(q),int(b));req(key not in d,'duplicate'); d[key]=(int(w),1 if m=='R' else -1,int(z))
 return d
A=parse(P);req(hashlib.sha256(P.read_bytes()).hexdigest()=='bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7','pin')
B=dict(A);req(B[180,1]==(1,1,172),'patchA');B[180,1]=(1,1,211)
C=dict(B);req(C[172,0]==(0,-1,112),'patchB');C[172,0]=(0,-1,67)
del C[112,0];del C[112,1]
req([(q,b) for (q,b),(_,_,z) in B.items() if z==172]==[(116,0)],'172 entry')
req([(q,b) for (q,b),(_,_,z) in B.items() if z==112]==[(172,0)],'112 entry')
req(B[116,0]==(0,1,172),'leftmarker')
req(len(C)==424 and len({q for q,b in C})==212,'count')
req(all(z==254 or (z,0) in C for w,d,z in C.values()),'targetclosure')
def run(t,q,bits,n):
 h=0;s=dict(bits);trace=[]
 for i in range(n):
  req(h in s,('unknown-read',q,h)); b=s[h]; trace.append([q,h,b]);w,d,z=t[q,b];s[h]=w;h+=d;q=z;req(q!=254,'interiorhalt')
 return (q,h,s),trace
cases=[]
for bits,n,m,end in [({0:1,1:1},2,2,(184,2)),({0:1,1:0,2:0},7,3,(90,3)),({0:1,1:0,2:1},7,3,(86,3))]:
 a,ta=run(A,180,bits,n);b,tb=run(B,180,bits,m);req(a==b and a[:2]==end and a[2]==bits,'A identity');cases.append(dict(stage='A',bits=bits,old=ta,new=tb,endpoint=end))
bits={-1:0,0:0};a,ta=run(B,172,bits,4);b,tb=run(C,172,bits,2);req(a==b and a[:2]==(151,0) and a[2]==bits,'B identity');cases.append(dict(stage='B',bits=bits,old=ta,new=tb,endpoint=(151,0)))
req({k for k in A if A[k]!=B[k]}=={(180,1)},'ordinaryA');req({k for k in C if B[k]!=C[k]}=={(172,0)},'ordinaryB')
raw='#! start 0\n'+''.join(f'{q} {b} {w} {"R" if d==1 else "L"} {z}\n' for (q,b),(w,d,z) in sorted(C.items()))
raw=raw.encode()
req(raw==(ROOT/'machine/u212.native.tm').read_bytes(),'delivered native table differs')
r={'status':'PASS','native_sha256':hashlib.sha256(raw).hexdigest(),'working_states':212,'rows':424,'cases':cases,'proof_scope':'Four partial-tape path identities with unknown-read rejection. Incoming-marker and exact retained-row checks supply PA finite-checkpoint induction; no claim of kernel formalization.'}
(ROOT/'evidence/U212_INDEPENDENT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
