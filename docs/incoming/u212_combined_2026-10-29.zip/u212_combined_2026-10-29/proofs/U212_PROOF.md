# U212 from the 197-node U213 source

Let A be the native U213 table with SHA256
bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7,
from `U213_ConPA_2026-10-28 (1).zip`. This uses the 197-node source,
not the earlier 198-node U214 source. All labels below are native.

Define B by changing only A(180,1)=(1,R,172) to (1,R,211).
Define C by changing B(172,0)=(0,L,112) to (0,L,67) and deleting112.
There are 212 working states and424 binary transitions in C. Native254
is halt, while dense212 is halt. The source program and its theory are
unchanged. The new native digest is
386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4.

## Three unconditional bypass identities

Place the head at coordinate0 in state180, reading1. Let b=tape[1], and
if b=0 let c=tape[2]. Each listed row writes the symbol already present.
No unspecified cell is read and no interior state is halt.

* b=1:
  A:180@0 ->172@1 ->184@2.
  B:180@0 ->211@1 ->184@2. Lengths2/2.
* b=0,c=0:
  A:180@0 ->172@1 ->112@0 ->209@1 ->157@2 ->67@1 ->151@2 ->90@3.
  B:180@0 ->211@1 ->218@2 ->90@3. Lengths7/3.
* b=0,c=1:
  A:180@0 ->172@1 ->112@0 ->209@1 ->157@2 ->148@1 ->186@2 ->86@3.
  B:180@0 ->211@1 ->218@2 ->86@3. Lengths7/3.

These are exhaustive cases at180/read1. All425 other rows agree.
Thus A and B admit equal-state/head/tape checkpoints with identical
one-step blocks except for these three positive, bounded blocks.

## The strengthened entry invariant

In B the only incoming row to172 is116/read0, writing0 and moving R.
Every entry to172 therefore has zero immediately left of its head.
The only incoming row to112 is172/read0, writing0 and moving L.
Consequently every visit to112 has current bit0 and right-neighbor bit0.
Both assertions hold for every run started in state0 on any tape;
neither marked state is the start state. They follow directly from the
complete incoming-edge lists, not from a bounded simulation.

Under these two zeros, with head coordinate0:
  B:112@0 ->157@1 ->67@0 ->151@1,
  C:67@0 ->151@1.
The old/new lengths are3/1, the entire tape is preserved, and no exterior
cell is read. All424 other B rows commute under112->67, fixing all
other labels and halt. This proves B--C halting equivalence.

## Formalization and time bound

Each synchronized block is positive, bounded, deterministic, and has no
halt internally. Induction on a given finite halting trace transfers a
halting trace in either direction. The incoming-marker proof is itself
a finite-run induction. Finite tape coding, the four fixed identities,
and these inductions can be expressed and proved in PA. Thus PA proves
that A and C halt equivalently on the blank tape (and on coded common
initial tapes). Compose this with the supplied calibration of A to get
PA |- not Halt(C,blank) iff Con(U). This is an ordinary mathematical
proof; no new proof-assistant certificate is claimed.

Each new block is no longer than its predecessor. More sharply, choose
direct A--C equal-state checkpoints excluding112. At a checkpoint172,
the preceding cell is zero: the only ordinary incoming row is116/read0;
180/read1 is swallowed inside its bypass block, whose endpoint is184,
90, or86, not172. The172/read0 direct block has lengths4/2 and ends at
151 at the original head coordinate. The bypass blocks have lengths2/2
or7/3; all other blocks1/1. Therefore every halting common-tape run has
T(C) <= T(A) <= (7/3)T(C). This checkpoint invariant must not be confused
with the false assertion that every raw A visit to172 has a preceding0.

## Why combination is valid

The source reassociation in the selected input changes decoder allocation.
The earlier U214->U213 proof used helper167 with rows(0,R,218),(1,R,184).
The selected 197-node table instead supplies exactly those rows at211.
The local read/write identities and complete incoming lists are rechecked
against the selected literal table. Thus the combination is semantic and
proof-based, not a numerical-label transplant. The 197-node source saving
and the incoming-path bypass are compatible and yield212 states.
