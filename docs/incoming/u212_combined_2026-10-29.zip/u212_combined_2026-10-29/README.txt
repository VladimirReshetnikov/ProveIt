U212 by combining source compression and entry bypass
====================================================
Result: 212 working states, 424 binary transitions, separate halt.
The selected parent is U213_ConPA_2026-10-28 (1).zip at ProveIt commit
6b3145c0bbbf7563bd7bce44c974b4515656a5b0. Two native edits redirect
180/read 1 to 211 and 172/read 0 to 67; state 112 is deleted.
The source and theory are unchanged from that exact selected parent.
The mathematical proof preserves its PA-provable Con(U) endpoint.
This is not a new proof-assistant endpoint or global minimality result.

The report compares all eight supplied U213 proposals. Native state numbers
are allocation labels: the earlier helper 167 is now represented by 211.
The compact dependency tree preserves the 197-subtree source, its interior
AX startup, suffix/credit proof, and the earlier U214/U218/U222 calibration.
Large saved trace dumps and nested archives are intentionally omitted.
Exact selection ledgers record original file hashes and the preserved paths.
Only the authored checks under checks/ are run by the new replay; supplied
source programs are retained as evidence, not silently executed.

From a fresh extraction with Python 3.10 or later and its standard library:
  python3 checks/check_release_manifest.py
  python3 checks/replay.py
The replay runs 18 commands, including both full 5,084-case runtime checks.
Do not run replay under -O. Safe optimized finite checks are already included.
Replay writes new receipts, so check the original manifest before replay.

The runtime helpers are byte-bound to the previously authored modules.
Only two header-distance constants change from 64 to 56, as separately checked.
The origin detector and startup require this exact 56+g frame convention.

For a full TeX installation, run pdflatex twice on report.tex. The included
build_local.sh also supports this workspace's read-only TeX configuration.
The standalone verification JSON delivered beside the PDF and ZIP records
sealed replay, every-page text/pixel comparison, and final file hashes.
