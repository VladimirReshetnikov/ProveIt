# Comparison of the eight supplied U213 packets

Repository pin: 6b3145c0bbbf7563bd7bce44c974b4515656a5b0.
All eight native transition dictionaries are distinct. The exact table,
source hashes and complete deltas from U214 are in TABLE_COMPARISON.json.
Archive names below refer to docs/incoming at that pin; all are dated
2026-10-28. Native labels are not portable semantic identifiers.

| Packet stem | Source leaves/subtrees | Principal idea | Removed labels vs U214 |
|---|---:|---|---|
| U213_ConPA | 3928/198 | Exchange covering antecedents, reallocate with inherited U217 return helper, repair preceding-zero selector |112,501,502; adds156,177|
| U213_ConPA (1) |3909/197|Port role-a emitter to ST215 direct-transfer source, repair146/0 to182, shorten origin detector34/0 to75 |50,501,502; adds156,177|
| U213_ConPA (2) |3928/198|Reassociate emitter, repair arithmetic entrance, fold preceding-one state167 into172 via predecessor214/1|167|
| U213_ConPA (3) |3928/198|One closed reassociation, contextual allocation plus child-reference repair|215|
| U213_ConPA_Reduction |3928/198|Reassociate emitter, zero-tag selector repair101/0 to182, fold167 into172 via predecessor158/1|167|
| U213_ConPA_Reduction (1) |3928/199|Six closed rotations expose opposite preceding-bit decoder roles; share selector and delete214|214|
| U213_ConU |3928/199|Eight closed reassociations expose left-tagged115/214 pair; helper155 and delete115|115|
| u213_from_u214 |3928/198|No source change: bypass180/1 to167, then bypass172/0 to67 and delete112|112|

The two preceding-one167 folds are the same local mechanism but distinct
source/allocation realizations with different incoming predecessors. The
199-subtree packets demonstrate that a smaller physical table need not have
a smaller source DAG. The ST215 packet has the uniquely smallest supplied
source (197 subtrees) and a different startup proof obligation, not merely
a source reassociation of the U214 computation.

## Certified stacking

The 197-subtree packet retains the old112/172 paths and has a decoder211
whose rows are 0 -> 0R218 and 1 -> 1R184. These are exactly the semantic
helper rows that the earlier no-source-change bypass used at label167.
Replacing180/1's target172 with211 gives the same three exhaustive whole-tape
path identities. Afterwards172's only incoming row is116/0, so112 is reached
only on two consecutive zeroes. Redirect172/0 to67 and delete112.

This yields U212, not just a new U213 allocation. The exact tables, dense
renaming, partial-tape traces and independently executable finite checker
are in u212_certificate/ and certify212.py. U212_PROOF.md states the full
PA-formalizable local proof and the inherited dependencies separately.

A fixed-shape helper search tested the same 2/2,7/3,7/3 bypass identities
against each packet. Only the ST215 packet provided an eligible retained
helper in this stencil (211). This is not an exhaustive impossibility
result for the other packets. Source-specific reallocation, longer paths,
or more edits may allow other combinations.

## Noncomposable numeric edits and trust boundaries

Copying native167 from the previous packet is wrong: in the selected ST215
packet it has rows to171 and201, not the required218 and184. Other packets
have already removed112, have repurposed112/172, or have removed167. The
same semantic transformation must therefore be checked against actual
rows and all incoming transitions, as the new checker does.

The ST215 packet also shortens the origin detector by removing50. This
cannot be blindly copied to another U213. Its48140-step startup reaches an
interior AX frame with an opaque tail, rather than the95726-step U214 root
frame; the suffix and scheduler-credit argument must be checked. The
selected baseline asserts5084 universal primitive cases, distinct from the
5109 cases of the3928-instruction sources. The local U212 proof neither
assumes a clean root initialization nor supplies the missing parent audit.

All source programs and supplied proof scripts were read as evidence;
comparison scripts here are newly authored. No supplied external program
was executed by this comparison task. The new local construction does not
change the source, theory, origin detector, or startup logic of its exact
selected parent. It preserves any correctness theorem that parent has.
