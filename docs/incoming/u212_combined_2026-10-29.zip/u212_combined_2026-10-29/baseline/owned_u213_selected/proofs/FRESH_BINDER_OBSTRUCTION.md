# Deterministic fresh test: obstruction and scope

Consider keeping matrix code/output label a, source label b, but replacing the tested variable by c=a+b+2. Every effective label of the normalized decoded matrix phi(a) is <a (code zero is closed truth), so c does not occur in phi. Alpha-renaming cannot turn these constant-in-the-test matrices into arbitrary unary-dependent matrices.

This is more than a failure of the previous quotation recipe. In ordinary first-order logic, the weak-cover schema restricted to matrices phi not containing the tested variable follows from the following finite theory T:

1. Irreflexivity: forall x, not E(x,x).
2. Empty existence: exists e, forall x, not E(x,e).
3. Weak power covering: forall a, exists b, forall x, (Sub(x,a) -> E(x,b)).

Indeed, split on phi. If phi is true, choose a weak power cover of the source. If phi is false, choose an empty object. Since output is fresh in phi and test does not occur in phi, these are valid derivations with all other parameters retained. The coincident source/output exception also follows: its guard becomes Emp(x) under irreflexivity, and a weak power cover of an empty source contains every empty representative.

T is interpreted in PA by E(x,y) = 'bit x of y is one'. Empty has code zero. If Sub(x,a), every bit of x is a bit of a, hence x <= a. Thus b = 2^(a+1)-1 contains every such x. Irreflexivity is the elementary bit bound. This is a fixed finite first-order theory, so its interpreted axioms are proved in some fixed finite fragment of PA. PA proves consistency of each of its fixed finite fragments (formalized bounded-complexity truth, equivalently the standard reflexivity argument). Therefore PA proves Con(T).

Consequently any proposed numerical calculus whose remaining rows are sound under this T interpretation and whose new nonlogical rows are only these test-independent covers has PA-provable consistency. If PA is consistent, it cannot also have a PA proof that its consistency is equivalent to Con(PA), by the second incompleteness theorem. This rules out the straightforward replacement as a route to the requested endpoint, subject to the stated uniform soundness interpretation. It does not rule out changing the matrix encoding so the designated test actually occurs.

# Canonical RV is a separate issue

Suppose instead the cover keeps an independent genuine tested label and only the atomic-vacuity component is restricted to

  R(a,b) -> forall_(a+b+2) R(a,b).

The inherited pure-logic recovery cannot simply be reused: it explicitly requires all fresh-binder RV instances. A finite generalized-quantifier countermodel shows that canonical RV plus the unchanged pure core does not derive every RV instance.

Let worlds consist of a variable assignment into {0,1}, together with a hidden bit h. Equality is ordinary equality of assigned values. Interpret E(x,y) as h=1 and assigned x != assigned y. Quantifier Q_0 ranges over both coordinate 0 and h; every Q_i for i>0 ranges only over coordinate i. Classical implication and falsity are standard. Each Q_i is an S5 universal modality, their equivalence relations commute, and Q_0 does not affect equality except through coordinate 0.

All retained pure rows are valid: quantifier distribution, quantifier commutation, exists_i forall_i A -> A, equality existence, left/right membership congruence, propositional rows, and the merged equality row G. For G, its binder Rcode(a,b) is fresh for a,b and always positive, hence is an ordinary coordinate quantifier; equality is unaffected. The native false code R(0,0) is uniformly false, and the normalized zero truth alias causes no issue.

Every canonical RV binder a+b+2 is >=2 and distinct from a,b, so changing it affects neither h nor the atom's two arguments. Hence every canonical RV is valid.

However RV(2,3,0) fails: at h=1 with v2=0 and v3=1, R(2,3) is true, while Q_0 R(2,3) is false because h may change to zero. Thus full RV recovery from only this pure core and canonical RV is impossible.

Scope: this countermodel does not include arbitrary proposed nonlogical cover axioms, and does not rule out a new interpretation restricting all translated variables away from the exceptional binders. Such an interpretation would require a new, noncircular completeness proof. Merely invoking renaming admissibility from the old calculus would assume the missing RV result.
