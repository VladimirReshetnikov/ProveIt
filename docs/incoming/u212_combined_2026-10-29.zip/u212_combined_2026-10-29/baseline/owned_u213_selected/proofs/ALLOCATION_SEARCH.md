# Independent runtime/allocation exploration

The primary U214 table is pinned by SHA-256 5fa7d923456ea7fb3e9cb331946e49750970bbffbfa755c0639bdaa9b7afd8a8.

Two logically equivalent 198-DAG source alternatives were supplied by the source worker:
- 2e03e532807139814b60999647c66eff8a333c91f16ed08c2235560b55912c27
- 32f9a3da4588 (full digest in the source-worker ledger).

An adapted, previously authored incremental compiler produced 214-state exploration tables with SHA-256 cd60ea3c336d8f33b458dbdbdcfa472a2c69115368c8f4f7ce7c6b9f1c96fd76 and c2f6d28f744a3acd9374a786e6b592320ddc41c9ecb349dc2318e3eca2bf8cb2. Prefix-only checks passed, but the first table failed the universal runtime checker at source site 3 (CI8). The original runtime uses native row11/read0 as a return path; this allocation changed that row. Prefix compatibility is therefore insufficient to establish runtime correctness. The second table was not universally checked.

Protecting native states11,26,37 produced 217-state tables. The first completed at least3250 primitive cases before a later symbolic derivation failure. The diagnostic fallback also failed because the new source PC was not a valid old-source instruction; no completed receipt was produced. Neither 217-state alternative is certified, and neither is a candidate for the requested reduction. Further allocation search was stopped after a separate213-state construction was certified.

A separate discovery-only context collector observes the exact-table symbolic primitive checker. It computes local window overapproximations at literal proof steps, assigns unrestricted windows to unary/list-traversal states, and adds exact startup contexts. This is a candidate-screening tool only: it does not itself prove that a proposed modified machine is correct. Any candidate requires a fresh whole-tape universal runtime certificate and startup proof, or an independent local simulation proof. No smaller machine was established by this collector.

No externally supplied program was executed in this exploration. The executed symbolic checker modules are byte-identical to previously authored modules, pinned in the wrapper. New scripts are local adaptations or independently authored analysis code. No upstream repository changes or publication were made.
