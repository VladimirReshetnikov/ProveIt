# A 213-state successor of the primary U214

## Exact tables

The parent is the supplied complete native table with SHA-256
`5fa7d923456ea7fb3e9cb331946e49750970bbffbfa755c0639bdaa9b7afd8a8`.
Native halt is 254, start is 0, and all native labels other than halt which
have rows are working states. Native labels do not denote state counts.

First form the same-size table B by changing only

    180 1 1 R 172  ->  180 1 1 R 167.

Then form C by changing only

    172 0 0 L 112  ->  172 0 0 L 67

and deleting both rows of state 112. C has 213 working states and 426 rows.
The canonical native SHA-256 is
`483b05ded896fd39b2b51d404e09b2f6013dcddfad8273009dff1b73c0ed45bc`.
Dense labels sort the retained native working labels and send halt254 to213.
The dense SHA-256 is
`3dff657ac389505e75b446237442766925c519a8c680120c25e12401d42bcb0b`.
No source, theory, proof-search program, initialization or other table row is
modified. Both replacement rows preserve their original write and direction.

## First transformation: avoid the one-valued entry to112

All tapes in the following argument are arbitrary, two-way infinite binary
tapes. A local trace states all cells it reads; cells outside the stated set
are unchanged and irrelevant. Number positions relative to the starting head.
At state180 reading1, write the next two bits as a and b. The original and
retimed computations have the following endpoints, with exactly unchanged
tapes:

* a=1: original 180@0 ->172@1 ->184@2; new180@0 ->167@1 ->184@2.
  Both take two steps, and b is never read.
* a=0,b=0: original180@0 ->172@1 ->112@0 ->209@1 ->157@2
  ->67@1 ->151@2 ->90@3. New180@0 ->167@1 ->218@2 ->90@3.
  This is seven steps versus three.
* a=0,b=1: original180@0 ->172@1 ->112@0 ->209@1 ->157@2
  ->148@1 ->186@2 ->86@3. New180@0 ->167@1 ->218@2 ->86@3.
  This is seven steps versus three.

The three cases are exhaustive given the scanned1. Their endpoint states,
head positions, and complete tapes agree. No trace has halt in its interior.
The new paths never execute the changed180/1 row except at their first step.
Every other parent row is literally unchanged. Hence this is a positive
bounded-block simulation in both halting directions, without any entry
invariant or assumption about the proof-search source.

For clarity, this is not merely matching traces in the original table:
all new paths are evaluated in B, the genuinely patched table.

## Second transformation:112 is now a redundant zero-only detour

Inspect B, not the original table. Its only edge into172 is116/read0,
which writes0 and moves R. Therefore every visit to172 from initialstate0
has a zero immediately left of the head. This follows by induction on the
run, since the start state is not172 and each incoming transition supplies
the property. The only edge into112 is172/read0, which writes0 and movesL.
Thus every visit to112 has currentbit0 and rightbit0: the currentbit comes
from the preceding-zero invariant at172, and the rightbit is the0 just
written by172/read0. The start state is not112.

On precisely this two-zero local tape, B at112 and C at67 have identical
complete tapes, head positions and states after these positive paths:

    B:112@0 ->157@1 ->67@0 ->151@1  (three steps)
    C: 67@0 ->151@1                 (one step).

All reads are of the two supplied zero cells; all writes preserve zeros;
neither path can halt internally. Let phi(112)=67 and phi fix every other
state, including halt. For each of B's426 rows whose source is not112,
its image under phi is exactly C's corresponding row. This includes the
changed target of172/read0. The unreachable112/read1 row imposes no condition.
This quotient is valid even though state67 has other existing entry contexts:
those entries are accounted for by ordinary commuting rows, and its table
is not changed.

Again, every short new path is checked in C itself, never by assuming that
a modified helper retains its old behavior.

## PA formalization and the consistency endpoint

These are conventional mathematical proofs, not newly compiled proof-
assistant artifacts. Their ingredients are elementary transition evaluation,
finite case splitting, two syntactic incoming-edge checks, induction on finite
runs and simple bounds. All are formalizable in PA.

Here is an explicit halting argument which avoids an unbounded/infinite-run
assumption. At corresponding cutpoints, apply an ordinary one-step block or
one of the displayed exceptional blocks. Both old and new lengths are positive,
no interior configuration is halting, and the endpoints correspond. Continue
for as many blocks as the length of a hypothesized finite halting trace.
The matching run covers that trace because each block advances time by at
least one. A halt cannot be hidden in a block interior, so it occurs at a
matching endpoint. This proves both directions using finite induction and
bounded simulation. For the second stage, the old-run marker invariant supplies
its exceptional precondition at each cutpoint. No assumption about the child's
unreachable-state invariants is needed.

Each stage also never increases running time: stage1 replaces7/3 or2/2 and
stage2 replaces3/1, while ordinary steps remain1/1. Consequently, when the
machines halt on a common tape, their exact times satisfy

    T(C) <= T(A) <= 21 T(C).

The right-hand constant21 is a deliberately coarse product of the stage
bounds7 and3, not an optimized slowdown ratio. In particular C is no slower
than the supplied parent on any common initial tape fromstate0.

PA therefore proves Halt(A,tape) iff Halt(C,tape), including the blank tape.
Compose with the supplied U214 calibration theorem to conclude

    PA proves: not Halt(C,blank) iff Con(U).

The new local proof does not establish the inherited source/calibration theorem
anew; its dependencies must be separately audited or retained. In particular,
this is not an invocation of the different K215/ZFC endpoint for the modified
machine. No assertion of unconditional nonhalting, Con(U), or global minimality
is made.

## Executable evidence

`certify_u213.py` pins and parses the parent, constructs both tables, checks
three exhaustive first-stage partial-tape cases and one second-stage case,
checks all ordinary rows and the complete incoming-edge sets, verifies dense
relabelling, and emits the literal tables plus JSON traces. All checks use
explicit exceptions and pass normally and with Python `-O`. Unknown exterior
reads fail, so the traces establish equality for every completion of the
specified local tape, not just finite zero-padded samples.

The discovery method explored neutral row retimings before state merging.
A direct pair-fold census of U214 found no acceptable result in its bounded
search family. Among512 neutral row retimings screened at width11,180/read1
exposed the zero-only112 role and hence the reduction. This explains why a
single-pass merge scan missed the saving. These finite negative searches do
not establish minimality or exclude further methods.
