from pathlib import Path
import json,hashlib,sys,re
P=Path(sys.argv[1]); OUT=Path(__file__).resolve().parents[1]/'evidence'
def req(x,m):
 if not x:raise ValueError(m)
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def table(p):
 d={}
 for line in p.read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,m,r=line.split();k=(int(q),int(b));req(k not in d and m in ('L','R') and b in ('0','1') and w in ('0','1'),'row');d[k]=(int(w),1 if m=='R' else -1,int(r))
 return d
n=0
compact='--compact' in sys.argv
for l in (P/'SHA256SUMS').read_text().splitlines():
 h,f=l.split(None,1)
 if compact and not (P/f).is_file():continue
 req(H(P/f)==h,('manifest',f));n+=1
req(n==(68 if compact else 75),'manifest entry count')
req(H(P/'machine/u214.native.tm')=='5fa7d923456ea7fb3e9cb331946e49750970bbffbfa755c0639bdaa9b7afd8a8','native pin')
req(H(P/'machine/sites.json')=='9428a13d4c228e9760e8f546e43527ee5e196ae667ad2386ddabf961b477d083','source pin')
req(H(P/'inputs/u218_sites.json')=='bc70b28ff4628db5b9b0c9bd87f560697223e4887f2568b0ece801906713db8f','parent source pin')
req(H(P/'inputs/k215_sites.json')=='17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba','K215 source pin')
req(H(P/'inputs/DagPerm.v')=='ba2b28487ae978bd27b0d804e9b2bde6d9adcd1dd575de55572465c050b86aa1','DAG pin')
T=table(P/'machine/u214.native.tm'); D=table(P/'machine/u214.tm');M={int(k):v for k,v in json.loads((P/'machine/u214_state_map.json').read_text())['native_to_dense'].items()};M[254]=214
states={q for q,b in T};req(len(states)==214 and len(T)==428,'counts');req(all((q,b)in T for q in states for b in (0,1)),'total');req(set(M)==states|{254} and set(M.values())==set(range(215)),'map');req({(M[q],b):(w,m,M[r])for(q,b),(w,m,r)in T.items()}==D,'dense')
boot=None if compact else json.loads((P/'evidence/u214/startup.json').read_text()); ones=set();q=x=0
for i in range(95726):
 b=int(x in ones);w,m,r=T[q,b]
 if boot is not None:req(boot['trace'][i]==[q,x,b,w,m,r],('trace',i))
 ones.discard(x)
 if w:ones.add(x)
 x+=m;q=r
req((q,x)==(84,-8),'startup')
if boot is not None:req(len(boot['trace'])==95726 and sorted(ones)==boot['one_cells'],'trace endpoint')
phy=(6,2,0,4,3,7,8,5,1);logical=[4]+[0]*8;physical=[0]*9
for i,j in enumerate(phy):physical[j]=logical[i]
row=[0]*65+[1]
for v in physical+[1]*40:row += [0]+[1]*(v+1)
req(ones=={i-8 for i,v in enumerate(row) if v}|{-9},'frame')
def tree(rows):
 d={p:(o,a)for p,o,a in rows};req(len(d)==len(rows),'duplicates')
 def go(p):return d[p]if p in d else(go(p+'0'),go(p+'1'))
 return go('')
def leaf(t):return isinstance(t[0],str)
def count(t):return 1 if leaf(t)else count(t[0])+count(t[1])
def cfg(t):
 out=[]
 def go(t,k,br,co):
  if leaf(t):
   o,a=t;z=(k+1,)if o=='CI'else(br[0],k+1)if o=='CD'else(br[a-1],)if o=='CB'else(co[a-1],)if o=='CC'else();out.append((o,a if o not in('CB','CC')else None,z));return
  m=k+count(t[0]);e=m+count(t[1]);go(t[0],k,[e]+br,co);go(t[1],m,br,[k]+co)
 go(t,0,[],[]);return out
base=json.loads((P/'inputs/k215_sites.json').read_text());old=json.loads((P/'inputs/u218_sites.json').read_text());new=json.loads((P/'machine/sites.json').read_text());bc=cfg(tree(base));oc=cfg(tree(old));nc=cfg(tree(new));lo,hi,stop=2885,3622,3659
for i,(o,a,es)in enumerate(oc):
 if lo<=i<hi:continue
 def f(k):
  req(not lo<k<hi,'exterior into emitter');return k if k<=lo else k+37
 req(nc[f(i)]==(o,a,tuple(f(e)for e in es)),('exterior',i))
recipe=json.loads((P/'inputs/source_recipe.json').read_text());word=[]
def flat(e):
 if isinstance(e,str):word.append(e)
 else:req(len(e)==2,'binary');flat(e[0]);flat(e[1])
flat(recipe['replacement']);ranges={'m166':(26,52),'m121':(52,78),'m168':(107,133),'m119':(78,105),'m180':(78,107),'m181':(695,723),'m218':(995,1042)};expect=[]
for m in word:
 a,b=ranges[m];offset=lo+len(expect)
 for o,r,es in bc[a:b]:req(o!='CH'and all(a<=e<=b for e in es),'closed');expect.append((o,r,tuple(e-a+offset for e in es)))
req(nc[lo:stop]==expect,'macro CFG')
tok={'m166':'a','m121':'b','m168':'c','m119':'I','m180':'Q','m181':'R','m218':'N'};s=[]
for m in word:
 t=tok[m]
 if t in('a','b','c'):s.append(t)
 elif t=='N':s.append(('I',s.pop(),'F'))
 else:
  y=s.pop();x=s.pop();s.append((t,x,y))
a,b,c='a','b','c';e=('R',c,a);g=('Q',a,('I',('R',a,c),('R',a,b)));u=('Q',c,('I',e,a));l=('Q',c,('I',a,('I',g,e)));req(s==[('Q',a,('I',u,('I',l,'F')))],'formula')
unique=set()
def collect(t):
 unique.add(t)
 if not leaf(t):collect(t[0]);collect(t[1])
collect(tree(new));req(len(unique)==198 and len(new)==3928,'metrics')
# Independently bind exact proof DAG fragments, modulo safe straight-line CI commutation.
text=(P/'inputs/DagPerm.v').read_text();edge=r'(?:ENode|EInc|EDecnz|EBreak|EContinue)\s+\d+|EHalt';nodes={int(n):(x,y)for n,x,y in re.findall(r'^\s*\|\s*(\d+)\s*=>\s*\(('+edge+r'),\s*('+edge+r')\)\s*$',text,re.M)};req(len(nodes)==487,'DAG parse')
def expand(e,seen=frozenset()):
 z=e.split();k=z[0]
 if k=='ENode':
  n=int(z[1]);req(n not in seen,'cycle');return tuple(expand(x,seen|{n})for x in nodes[n])
 return ({'EInc':'CI','EDecnz':'CD','EBreak':'CB','EContinue':'CC','EHalt':'CH'}[k],None if k=='EHalt'else int(z[1]))
bindings=[]
for name,(a,b)in ranges.items():
 pc=cfg(expand('ENode '+name[1:]));ac=[(o,r,tuple(e-a for e in es))for o,r,es in bc[a:b]];req(len(pc)==len(ac),'length');i=0
 while i<len(ac):
  if ac[i]==pc[i]:i+=1;continue
  req(i+1<len(ac),'last');o,x,es=ac[i];o2,y,es2=ac[i+1]
  req(o==o2=='CI'and pc[i]==('CI',y,es)and pc[i+1]==('CI',x,es2)and es==(i+1,)and es2==(i+2,),'swap');req(all(i+1 not in dest for j,(_,_,dest)in enumerate(ac)if j!=i),'entry swap');i+=2
 bindings.append(name)
# Literal U215 -> U214 fold independently with unknown-cell rejection.
A=table(P/'inputs/role215.native.tm');req(len(A)==430,'role states');expected={k:v for k,v in A.items()if k[0]!=156};expected[210,0]=(0,1,182);req(expected==T,'fold diff');req([(k,v)for k,v in A.items()if v[2]==156]==[((210,0),(0,1,156))],'incoming')
def run(table,q,t,steps):
 h=0;t=dict(t)
 for _ in range(steps):
  req(h in t,'unknown read');w,d,q=table[q,t[h]];t[h]=w;h+=d;req(q!=254,'internal halt')
 return q,h,t
for bit,steps in [(0,5),(1,1)]:req(run(A,156,{-1:0,0:bit},1)==run(T,182,{-1:0,0:bit},steps),'fold path')
result=dict(status='PASS',manifest_files=n,compact_mode=compact,table_sha256=H(P/'machine/u214.native.tm'),source_sha256=H(P/'machine/sites.json'),states=214,rows=428,startup_steps=95726,startup_frame='N4,other8zero,gap1,40spares1',source_leaves=3928,DAG=198,exterior_primitives=3154,emitter_primitives=774,macro_instances=len(word),macro_bindings=bindings,fold_cases=2,scope='Independent exact data, CFG, symbolic formula, proof-DAG binding, finite local fold and full startup checks; no formal endpoint certificate')
OUT.mkdir(exist_ok=True);(OUT/'DATA_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
