"""Exercise local proof premises directly; no hash rejection counts as a control."""
from pathlib import Path
import json
import certify_u213 as C
R=Path(__file__).resolve().parents[1]
A=C.read(R/'baseline/u214/machine/u214.native.tm');B=C.read(R/'machine/retimed214.native.tm');D=C.read(R/'machine/u213.native.tm')
cases=[(A,B,180,180,{0:1,1:1},2,2),(A,B,180,180,{0:1,1:0,2:0},7,3),(A,B,180,180,{0:1,1:0,2:1},7,3),(B,D,112,67,{0:0,1:0},3,1)]
results=[]
for i,(a,b,qa,qb,t,na,nb)in enumerate(cases):
 original=C.case(a,b,qa,qb,t,na,nb)
 for side,table,q,n in [('old',a,qa,na),('new',b,qb,nb)]:
  _,trace=C.trace(table,q,t,n)
  for row in sorted({(r['state'],r['read'])for r in trace}):
   w,d,z=table[row]
   for what,new in [('write',(1-w,d,z)),('move',(w,-d,z)),('halt',(w,d,254))]:
    edited=dict(table);edited[row]=new
    try:C.case(edited if side=='old'else a,edited if side=='new'else b,qa,qb,t,na,nb)
    except(ValueError,KeyError):results.append(dict(case=i,side=side,row=row,mutation=what))
    else:raise ValueError(('undetected semantic mutation',i,side,row,what))
# Demonstrate that each known zero is a genuine premise, not an assumed blank exterior.
for t in [{0:1,1:0},{0:0,1:1}]:
 try:C.case(B,D,112,67,t,3,1)
 except(ValueError,KeyError):results.append(dict(stage2_invalid_guard=t))
 else:raise ValueError('bad stage2 guard accepted')
# The bypass must remove the alternate incoming state172 edge before the stronger invariant.
C.need(C.incoming(B,172)==[[116,0,0,1]],'valid strengthened entry')
C.need(C.incoming(A,172)!=[[116,0,0,1]],'parent incorrectly satisfies strengthened entry')
results.append(dict(marker_control='parent alternate180entry rejected'))
info=dict(status='PASS',controls=len(results),scope='Direct partial-tape semantic mutations and explicit guard failures, not hash-only tests',tests=results)
(R/'evidence/SEMANTIC_CONTROLS.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps({k:v for k,v in info.items()if k!='tests'}))
