from pathlib import Path
import hashlib,json,sys
p=Path(sys.argv[1]);out=Path(sys.argv[2])
def req(x,m):
 if not x:raise ValueError(m)
req(hashlib.sha256(p.read_bytes()).hexdigest()=='483b05ded896fd39b2b51d404e09b2f6013dcddfad8273009dff1b73c0ed45bc','table pin')
T={}
for line in p.read_text().splitlines():
 if not line or line.startswith('#'):continue
 q,b,w,d,r=line.split();k=(int(q),int(b));req(k not in T,'duplicate');req(d in('L','R')and b in('0','1')and w in('0','1'),'symbol');T[k]=(int(w),1 if d=='R'else -1,int(r))
q=h=0;ones=set();hits={str((180,1)):0,str((172,0)):0}
for t in range(95726):
 b=int(h in ones)
 if str((q,b))in hits:hits[str((q,b))]+=1
 w,d,q=T[q,b];ones.discard(h)
 if w:ones.add(h)
 h+=d
req((q,h)==(84,-8),'endpoint')
phy=(6,2,0,4,3,7,8,5,1);logical=[4]+[0]*8;physical=[0]*9
for i,j in enumerate(phy):physical[j]=logical[i]
bits=[0]*65+[1]
for v in physical+[1]*40:bits.extend([0]+[1]*(v+1))
expect={i-8 for i,b in enumerate(bits)if b}|{-9};req(ones==expect,'complete frame')
r=dict(status='PASS',table_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),steps=95726,state=q,head=h,logical_registers=logical,gap=1,spares=[1]*40,ones=sorted(ones),edited_transition_visits=hits,scope='Exact finite blank startup only, not unbounded halting equivalence')
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k not in('ones','spares')},indent=2))
