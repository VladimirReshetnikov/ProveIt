"""Verify compact baseline provenance without executing external programs."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[1]
def need(value,message):
 if not value:raise ValueError(message)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
v=json.loads((R/'baseline/U214_SELECTION.json').read_text());root=R/'baseline/u214'
need(v['source_archive_sha256']=='b3a520e2181b739fec7257a7935b979acb00400f8d8147b5a2c212fd53a38d2c','archive pin')
seen=set();selected=0
for row in v['files']:
 p=Path(row['path']);need(not p.is_absolute() and '..'not in p.parts and p.as_posix()not in seen,'unsafe/duplicate selection path');seen.add(p.as_posix())
 if row['included']:
  f=root/p;need(f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],('selection',str(p)));selected+=1
 else:need(p.name in ('runtime_cases.json','startup.json','U218_ConPA_2026-10-28.zip'),'unapproved omission')
need(len(v['files'])==76 and selected==69,'selection counts')
u=json.loads((R/'baseline/SELECTED_FILES.json').read_text())
for row in u['files']:
 f=R/row['bundled_path'];need(f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],('U218 selection',str(f)))
p=R/'baseline/u218/inputs/U222_ConU_2026-10-28.zip'
need(sha(p)=='d23e80857214900f8e0806f03f6df752af501dd0108eb92c6ed7a49795802652','U222 pin')
with zipfile.ZipFile(p)as z:need(z.testzip() is None,'U222 archive CRC')
print(json.dumps(dict(status='PASS',selected_U214=selected,total_U214=len(v['files']),selected_U218=len(u['files']),U222_CRC='PASS')))
