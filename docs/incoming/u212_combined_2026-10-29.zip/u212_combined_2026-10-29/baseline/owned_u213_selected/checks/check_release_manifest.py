"""Verify every archived file before replay creates updated result receipts."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1]
def need(x,m):
 if not x:raise ValueError(m)
manifest=R/'SHA256SUMS';seen=set()
for line in manifest.read_text().splitlines():
 h,name=line.split(None,1);p=Path(name)
 need(not p.is_absolute() and '..'not in p.parts and name not in seen,'unsafe or repeated manifest path')
 need(hashlib.sha256((R/p).read_bytes()).hexdigest()==h,('hash mismatch',name));seen.add(name)
actual={str(p.relative_to(R))for p in R.rglob('*')if p.is_file()and p.name!='SHA256SUMS'and'__pycache__'not in p.parts and'build'not in p.parts}
# Nested baseline manifests are ordinary payload and must be covered.
actual.update(str(p.relative_to(R))for p in (R/'baseline').rglob('SHA256SUMS'))
need(seen==actual,('file inventory mismatch',sorted(seen-actual),sorted(actual-seen)))
print(json.dumps(dict(status='PASS',manifest_files=len(seen))))
