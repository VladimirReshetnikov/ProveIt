"""Bind the delivered tables, dense renaming, native patch, and printed appendix."""
from pathlib import Path
import hashlib,json
import certify_u213 as C
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
N=R/'machine/u213.native.tm';D=R/'machine/u213.tm'
C.need(sha(N)=='483b05ded896fd39b2b51d404e09b2f6013dcddfad8273009dff1b73c0ed45bc','native pin')
C.need(sha(D)=='3dff657ac389505e75b446237442766925c519a8c680120c25e12401d42bcb0b','dense pin')
A=C.read(R/'baseline/u214/machine/u214.native.tm');T=C.read(N)
expected={k:v for k,v in A.items()if k[0]!=112};expected[180,1]=(1,1,167);expected[172,0]=(0,-1,67)
C.need(T==expected and len(T)==426,'literal delta')
M={int(k):v for k,v in json.loads((R/'machine/dense_map.json').read_text()).items()};states={q for q,b in T}
C.need(set(M)==states|{254} and set(M.values())==set(range(214)) and len(M)==214 and M[0]==0 and M[254]==213,'dense map')
# Dense parser uses separate halt213 rather than native254.
dense={}
for line in D.read_text().splitlines():
 if not line or line.startswith('#'):continue
 q,b,w,d,z=line.split();key=int(q),int(b);C.need(key not in dense,'duplicate');dense[key]=(int(w),1 if d=='R'else-1,int(z))
C.need(dense=={(M[q],b):(w,d,M[z])for(q,b),(w,d,z)in T.items()},'conjugacy')
text=(R/'transition_table.tex').read_text()
def render(q,b):
 w,d,z=dense[q,b];return str(w)+('R'if d==1 else'L')+('H'if z==213 else str(z))
for i in range(107):
 j=i+107;s=f'{i} & {render(i,0)} & {render(i,1)}'
 s+=f' & {j} & {render(j,0)} & {render(j,1)}'if j<213 else' & & &'
 C.need(s+'\\\\'in text,('appendix',i))
print(json.dumps(dict(status='PASS',states=213,rows=426,appendix_rows=107,dense_bijection='PASS',native_sha256=sha(N),dense_sha256=sha(D))))
