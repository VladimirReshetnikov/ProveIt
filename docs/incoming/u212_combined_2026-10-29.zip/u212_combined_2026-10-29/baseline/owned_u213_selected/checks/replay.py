"""Portable offline U213 replay; run without Python optimization."""
from pathlib import Path
import sys,subprocess,json,time,os
R=Path(__file__).resolve().parents[1];os.chdir(R)
if not __debug__ or sys.flags.optimize:raise RuntimeError('Run replay.py without -O; safe optimized subcommands are checked separately.')
steps=[['checks/check_preserved_sources.py'], ['-O', 'checks/check_preserved_sources.py'], ['checks/check_baseline_data.py', 'baseline/u214', '--compact'], ['-O', 'checks/check_baseline_data.py', 'baseline/u214', '--compact'], ['checks/certify_u213.py'], ['-O', 'checks/certify_u213.py'], ['checks/verify_u213_independent.py'], ['-O', 'checks/verify_u213_independent.py'], ['checks/test_semantic_controls.py'], ['-O', 'checks/test_semantic_controls.py'], ['checks/check_artifact.py'], ['-O', 'checks/check_artifact.py'], ['checks/check_candidate_startup.py', 'machine/u213.native.tm', 'evidence/U213_STARTUP.json'], ['-O', 'checks/check_candidate_startup.py', 'machine/u213.native.tm', 'evidence/U213_STARTUP.json'], ['checks/check_baseline_runtime.py', 'baseline/u214', 'checks/runtime', 'baseline/u222/code/inputs/legacy_mapping.json'], ['checks/check_candidate_runtime.py', 'baseline/u214', 'checks/runtime', 'baseline/u222/code/inputs/legacy_mapping.json', 'machine/u213.native.tm']]
records=[]
for cmd in steps:
 start=time.monotonic();p=subprocess.run([sys.executable]+cmd,text=True,capture_output=True)
 records.append(dict(command=[sys.executable]+cmd,exit=p.returncode,seconds=round(time.monotonic()-start,3),stdout=p.stdout,stderr=p.stderr))
 print('PASS'if p.returncode==0 else'FAIL',' '.join(cmd),flush=True)
 if p.returncode:print(p.stdout,p.stderr);break
status='PASS'if len(records)==len(steps)and all(x['exit']==0 for x in records)else'FAIL'
(R/'evidence/REPLAY.json').write_text(json.dumps(dict(status=status,steps=records),indent=2)+'\n')
if status!='PASS':raise RuntimeError('Replay failed')
