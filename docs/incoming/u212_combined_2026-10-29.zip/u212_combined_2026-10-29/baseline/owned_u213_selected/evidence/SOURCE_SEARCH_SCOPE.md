# Bounded source exploration alongside U214 reduction

## Completed rotation search

`beam_dag.py` is an adaptation of our earlier owned closed-factor source search.
It starts at the pinned U214 source (SHA256
9428a13d4c228e9760e8f546e43527ee5e196ae667ad2386ddabf961b477d083).
It performs 30 deterministic rounds with beam width 80. It visited 341,598
unique roots and did not reduce the 198-node distinct-subtree count.
`BEAM_RECEIPT.json` records each round. This is a bounded negative result,
not a minimum proof or a literal Turing-machine state bound.

Each move reassociates three closed, nonhalting source factors and hence
preserves primitive register behavior. Integer DAG hashing counts shared
subtrees rather than expanded primitive occurrences.

## Equal-size alternatives

Two 198-node candidates have exactly the same complete resolved primitive
control-flow graph as the primary source, including all 3,928 primitive
instructions. An independent interval/address checker establishes this:

- polarity_198_2e03e5328071.sites.json
- polarity_198_32f9a3da4588.sites.json

`check_reassociations.py` uses explicit guards and passes normally and under
Python -O. Its receipt is REASSOCIATION_CHECK.json. Therefore these alternatives
require no new axiom calibration: only literal-machine recompilation needs
certification. Conservative provisional recompilation in
`compile_alternatives.py` produced 214-state tables, not a smaller table.
These allocator outputs are explicitly uncertified. Prefix binding is not
universal runtime verification.

## Incomplete classical-polarity search

A further experiment proposed 128 combinations of the two permitted role
assignments, top and lower implication exchange, pointwise contraposition in
the upper/lower/subset formulas, and uniformly negated matrices. It used
three candidates per dynamic-programming interval. The experimental processes
terminated with exit 137 before a clean complete census was recorded.
No claim of a completed 128-variant search is made. Its log is scratch evidence,
not a sealed verification receipt; it contains overlapping experimental output.
Only the independently checked reassociations above are promoted from it.

The elementary pointwise implication identities used in the experiment have
32 Boolean assignment checks (`check_polarity_logic.py`). These Boolean checks
are not a proof of the full source calculus, PA calibration, or literal
machine correctness. Quantifier congruence, the existing role proof, and the
source/machine verification would still be required for a candidate.

Work on this route stopped after the separate local-table route found U213.
No asymptotic or global-minimality claim is inferred from these experiments.
