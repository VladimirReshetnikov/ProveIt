# U214 predecessor comparison and restricted searches

Snapshot: ProveIt commit `24503cb019c7509ea229e80ef9b7a11a1501203c`.
Primary native table SHA-256:
`5fa7d923456ea7fb3e9cb331946e49750970bbffbfa755c0639bdaa9b7afd8a8`.
All archives were read as data; none of their unfamiliar Python programs was executed.

## What transfers, and what does not

The three newly supplied `U217_ConPA` archives and our earlier
`u217_from_u218` all give the same literal one-row reduction of U218:
redirect172/read0 from112 to134 and delete112. Their presentation differs:
the second numbered archive starts its local comparisons at172, so it
obtains unrestricted retained-state tape comparisons without a separate
entry-invariant premise. This is a useful proof presentation improvement,
not a new machine or additive state saving.

U216 combines that fold with five source-tree reassociations and a second
fold188→78. The source rotations preserve the closed macro instruction
word but alter source addresses and physical allocation. At the final
rotated table, entries into78 carry a preceding0 and entries into188 a
preceding1. Both states have the same0 row. A three-step path through143
and then213 or147 implements the distinct1 rows; delete188. This is a
real additional idea, but not a numeric patch applicable to U214.

U214 changes selector roles and the emitter: its source has3928 leaves,
198 distinct subtrees, and a215-state intermediate. Its fold156→182 is
justified by a preceding0. In the literal U214 table,134 now branches to17
and178,78 to146/302, and188 to167/218. These are not the old U216 roles.
Therefore neither the112→134 nor188→78 edit is justified by the old
proof. Reassociation would require a new source and compiler/runtime proof.

Earlier K215 results provide allocation and context-sharing machinery, but
their fixed ZFC consistency endpoint cannot certify the changed U emitter.
They also cannot supply same-numbered row patches without checking roles.
The earlier U218 exploration's alleged127→8,105→44 and176→52 tag folds
were circular and were rejected. Here every tested helper is evaluated in
the patched table, including all redirections and removed rows.

## Restricted direct-selector searches

`tagfold.py`:4664 candidates, no accepted fold. It considers two states
whose incoming edges uniformly write opposite predecessor bits and move
in the same direction. One scanned-symbol behavior is shared; the other
is routed through an existing helper, reading only the current cell and
its predecessor, at most20 steps. It verifies exact tape preservation,
head and mapped destination for both tags against the patched table.

`tagfold_both.py`:979440 individual helper screens, no compatible pair.
Both scanned-symbol rows may be replaced, at most30 steps per path, the
same two-cell footprint, and identity-writing original rows. Both candidate
rows are tested together before acceptance. These are deliberately narrow
searches; they do not rule out larger footprints, two-sided convergence,
source changes, or other state encodings. No global minimality follows.

## Runtime and initialization coverage

`runtime_coverage.py` reads the saved5109 U214 symbolic-case records and
inverts their explicit legacy state mapping. Missing native labels are
mapped by q→q+1000, as in the supplied wrapper. The case union covers all
428 native rows. The95726-step saved startup uses228 distinct rows, all
already in the runtime union. Thus there are no startup-only or unused
rows under this certificate. This finite accounting is not a new proof
that every row is actually reachable in the consistency search: arbitrary
register certificates can include unreachable source/register combinations.
It does show that deleting a row on the basis of this certificate alone
is unavailable. A separate inductive register invariant would be necessary.

This comparison supplies no below214 machine. It should not be advertised
as a reduction or a proof of minimality.
