# Report280 Composite modulus obstructions to Stage 13.7

This report mathematically refutes two preserved all-moduli Prop definitions at a fixed ProveIt source commit. It does not refute the prime-corrected theorem and does not claim a new Lean proof or a project-wide audit.

The exact step-two construction, genuine initial-stage strengthening, unit-step variants and fixed-prime-power family are proved in article.tex and Report280.pdf. The exact floor-five genuine initial-stage variants have R.length > Q.length. A separate nonunit-step family simultaneously has genuine initial stages, R contained in Q, the exact Section 10 cutoff, and all six numerical budgets, but fails the prime hypothesis and has no Stage 13.7 output. This full package has not been combined with the unit input step of the other examples.

## Offline verification

Requires Linux, Python 3.11 or later, and a TeX Live installation providing pdftex, pdflatex, Latin Modern, amsmath, amssymb, amsthm, mathtools, geometry, microtype, enumitem, booktabs, longtable, array, xcolor and hyperref. No Python packages, network calls or repository checkout are needed. The curated Lean files are for source inspection and hashing, not a standalone Lean build.

From the Report280 directory:

    python3 -I -B build.py verify
    python3 -I -B build.py reproduce --output /tmp/report280-rebuild

The output directory must be new or empty, absolute, outside the source tree, and not an ancestor of it. Choose a different fresh path for each run. The builder refuses protected system locations, symlinks, hard-link aliases, nonregular entries and any source inventory not on its exact allowlist. It never overwrites an output. Tests run in isolated staged copies, normally and with -O, with a 640-digit integer conversion cap and bounded process logs and timeouts. Validation uses explicit exceptions rather than Python assert statements, so optimization cannot disable it.

A successful build writes the PDF, the deterministic ZIP, a ZIP SHA-256 sidecar, a payload MANIFEST.sha256 and an external reproduction_receipt.json. Build logs and the staged working directories remain outside the distributed payload. The builder compares original and staged source inventories after each test invocation, including failures. It refuses to proceed after mutation or differing normal/optimized stdout.

The internal manifest covers every public payload except itself. The external sidecar covers the actual ZIP bytes. ZIP ordering, paths, timestamps, file modes, compression and bytes are deterministic. The archive root is Report280/. A manifest is an integrity mechanism, not a mathematical certificate or author authentication.

## PDF reproducibility

The reference build uses Python 3.12.14 and pdfTeX 3.141592653-2.6-1.40.26 (TeX Live 2025/dev/Debian), with the installed font and package files. SOURCE_DATE_EPOCH is fixed to 1791331200. PDF dates, trailer identifiers and path metadata are suppressed. Shell escape is disabled; TeX file policies are restrictive. The second pass must contain no overfull boxes, unresolved references, missing citations or rerun warning.

A replay from the pinned distribution requires the regenerated PDF to have the same SHA-256 as the bundled PDF. Different TeX package/font releases may produce a mismatch even when the mathematical content is unchanged. Preserve the supplied distribution and inspect the build logs/toolchain rather than replacing its manifest to disguise a mismatch. The provided source can still be compiled in a separate personal copy if bit-for-bit identity is not needed.

To repack the already verified distribution without compiling:

    python3 -I -B build.py package --output /tmp/report280-repack

## Companion scope

The standard-library companion checks small exponent identities, rational floor brackets, exact finite Freiman tuple convolutions, affine-agreement counts, spectral aliases, energy normalization, congruence solvability and curated source bytes. Its CLI has no parameter overrides. Importable helpers reject booleans, non-integers, oversized parameters and invalid models. It does not expand the enormous witnesses, evaluate the real-power thresholds numerically, or use floating-point Fourier tests. The complete proofs are in the article.

No repository file was modified or uploaded. The payload contains only the article, reproducibility code/tests, and five relevant source snapshots with curated provenance. Private research notes, reviews and raw connector receipts are excluded.
