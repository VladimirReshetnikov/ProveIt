# Report275

## Threshold free affine density increments on cyclic groups

This package contains a self-contained mathematical article, its editable TeX, and bounded exact Python diagnostics. The written theorems are the proof. The finite diagnostics check identities and implementation regressions; they are not empirical proofs, Lean certification, or novelty evidence.

## Main results

Let A have density δ in Z/NZ, N≥2. Let nonempty disjoint proper modular progressions cover A, with affine local phases and summed balanced correlation at least αN. Write r for the shortest parent length, τ for the union density, and μ=δ(1+τ−2δ) for its normalized absolute balanced mass.

- A proper progression has density at least δ+α/3 and length at least min{[r(1−δ)/(128μ)]^(1/3), (N/8)^(1/3)}
- A progression contained in one parent has density at least δ+cα and length at least sqrt((1−2c)αr/(8πμ)), for 0<c<1/2
- With two-comparable parents and t=N/M, a progression with gain α/3 has length at least max{t^(1/3)/8, sqrt(αt/(96π(1−δ)))}

The comparable-parent result holds over every cyclic modulus, with N=1 vacuous in the source specialization. It strengthens the entire degree-one specialization of the pinned repository Corollary 5.8. No higher-degree or global Ramsey/Szemerédi result is claimed.

The box appendix retains at least 1−η of a proper D-axis modular box and partitions that retained product into ordinary integer-representative boxes with a common positive step per original box and minimum width 1+floor(η sqrt(m)/(3D)). It does not establish the exact-partition/base-loss Section 16 interface.

## Files

The exact source allowlist is:

- README.md
- SOURCES.md
- article.tex
- build.py
- companion/exact_checks.py
- tests/test_build.py
- tests/test_companion.py

A packaged distribution adds Report275.pdf and MANIFEST.sha256. The ZIP contains exactly these nine files under Report275/. The manifest lists SHA-256 digests for the eight public files other than itself. The actual ZIP digest is written alongside the archive, rather than embedded circularly inside it.

## Run the exact diagnostics

From this directory:

    python3 -B companion/exact_checks.py
    python3 -B companion/exact_checks.py --full
    python3 -B companion/exact_checks.py --nmax 6
    python3 -B tests/test_companion.py
    python3 -O -B tests/test_companion.py
    python3 -B tests/test_build.py

Default exhaustive modulus is 8. The --full option raises it to 12 and extends the fixed box cases. An explicit --nmax takes precedence, with an enforced range 2 through 12. Cover enumeration has its own cap of 9. Output is deterministic JSON with the actual finite coverage and limitations. Exact all-step and fixed large-modulus cases separately exercise the composite-modulus variance mechanism.

The diagnostics include:

1. Exact ordered-pair counts and the variance identity in the least-prime-factor range
2. A counterexample to using that exact identity outside its valid range
3. All-direction coset covariances, removal of nonproper steps, and the sufficient N≥L³ density-gain regime
4. Cover mass μ, nonnegative signed balanced mass, and positive-cell extraction for A⊆U
5. Dirichlet phase selection, disjoint residue cells, lossless balanced chunking, reduced rational phase lifts and midpoint radii
6. A regression where the unreduced midpoint is −1 although the endpoints and reduced midpoint are +1
7. Bounded integer-box checks including reversed orientation, nonunit steps, and exceptional ambient-product mass

Arithmetic uses only integers and fractions. No numerical complex exponential or floating-point root is treated as a certificate. The assertions that control validity remain active under Python optimization.

## Rebuild and package offline

Requirements: Linux, Python 3.11 or later, /proc/self/fd, and a trusted system TeX installation containing /usr/bin/pdftex, /usr/bin/pdflatex, lmodern, amsmath, amssymb, amsthm, mathtools, geometry, microtype, enumitem, booktabs, xcolor, and hyperref. Python needs only its standard library. No dependency download or network access is performed.

Verify the exact source inventory or a pinned distribution:

    python3 -B build.py verify

Compile, run both normal and optimized tests/diagnostics, and produce the PDF and ZIP in a fresh external directory:

    python3 -B build.py reproduce --output /tmp/report275-rebuild

The output directory must be absent or empty, absolute, outside the source directory, and outside protected system locations. It must not be an ancestor of the source. Existing output files are never overwritten. The source is checked before and after the operation.

Outputs include Report275.pdf, report275_ramsey_density.zip, its SHA-256 sidecar, MANIFEST.sha256, reproduction_receipt.json, and separate staging/log files. The ZIP excludes those staging/log files. In an already manifest-pinned distribution, reproduce also requires the rebuilt PDF to match the pinned PDF digest. Exact PDF bytes depend on the TeX engine, packages, fonts and compression toolchain; a mismatch is reported rather than silently accepted.

For a pinned distribution only, package existing checked bytes without recompiling:

    python3 -B build.py package --output /tmp/report275-package

ZIP entries have sorted names, fixed timestamps, fixed permissions, no extra fields or comments, and checked CRC/member bytes. The build verifies normal and optimized diagnostic stdout equality. Test-runner timing on stderr is not expected to be byte-identical.

## Trust and safety boundary

This is an offline builder for supplied trusted source and installed trusted tools. It uses exact inventory allowlists, bounded source reads, no-follow directory/file handles, single-link regular-file requirements, exclusive output creation, a minimal child environment, subprocess time/output bounds, and disabled TeX shell escape. These controls are regression-tested where documented in tests/test_build.py.

They are not a security sandbox for arbitrary hostile Python/TeX or a guarantee against an actively malicious concurrent filesystem owner. The compiler itself and installed TeX resources remain trusted. Do not run untrusted modifications merely because a manifest is present: a hash verifies bytes against a manifest, not authorship or mathematical correctness.

## Provenance and limitations

SOURCES.md gives the repository pin, direct source links, and primary literature context. The article distinguishes modular properness from ordinary integer geometry, keeps every ceiling/floor convention explicit, and explains why the midpoint must be taken after reducing the phase increment. No repository file or earlier report is modified by this package.
