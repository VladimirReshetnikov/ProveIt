CLOSURE FROM EMPTY INPUTS FOR ZFC-CONSISTENCY MACHINES
Research report prepared for Vladimir Reshetnikov, 16 October 2026

START HERE
  report.pdf   Complete research report, proofs, audit and proposal.
  report.tex   Main LaTeX source; section sources are in sections/.

MAIN RESULTS
  * EPSC (empty-input positive subset-bounded closure) is deductively
    equivalent to the inherited equality-free subset-seeded PSC theory.
    Its consistency is ZFC-provably equivalent to Con(ZFC).
  * The four-row equality-free proof engine is incomplete. Explicit Boolean
    valuations prove that the proposed 248-state EPSC search and analogous
    250-state PSC search cannot derive their halting target.
  * The restored original equality engine compiles to a 270-state control.
    Exact register-program compression has a finite operation certificate.
    A new end-to-end compiler/theory/initializer proof is NOT supplied.

THREE MACHINE STATUSES -- THESE MUST NOT BE CONFLATED
  machines/upstream253.tm
    Existing upstream PR 20 construction. Published Coq endpoint: blank-tape
    halting iff finite classical refutation. Its actual upstream CI was
    inspected and its full literal bootstrap was independently rechecked.
    No local Coq rebuild or additional internal ZFC proof object is claimed.

  machines/rejected248.tm
    REJECTED experiment. The intended reduced calculus is provably too weak.
    Retained for reproducibility and as a regression example. It is not a
    certified ZFC-consistency machine. The direct abstract invariant would
    transfer to this table if its compiler simulation were certified.

  machines/full_equality_epsc270.tm
    UNCALIBRATED full-equality EPSC compiler control, 270 working states.
    The register-program compression is checked. The changed theory bridge,
    enumeration transport, binary compiler and initializer need proofs.

All numeric tables start in state 0 on a two-way-infinite all-zero tape,
use symbols 0/1 and L/R moves, and have a separate terminal state n for
n working states. All initialization states count. Lines are
  state read write direction next
The two newly generated tables totalize one undefined halt row. The upstream
253 table is retained byte-for-byte from its published source.

STANDALONE CHECKS (Python 3.10 or later; standard library only)
  python3 build.py
  python3 build.py --manifest

The first command checks the three literal table hashes and complete rows,
the Boolean/coding regression evidence, exact formula metrics, 11 checker
tests (including 9,216 finite substitution cases), the 3,620-pair operation
certificate, and three example theorem certificates. It does not execute
an infinite search or run a full Coq/Lean build.

REBUILD THE PDF
  python3 build.py --pdf
or
  latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

The PDF needs a normal TeX Live installation with article, Latin Modern,
amsmath/amsthm, geometry, booktabs, enumitem, microtype, fancyhdr, listings,
hyperref and xurl. PDF timestamps may differ on rebuilding. --manifest
verifies original packaged bytes before an optional PDF rebuild.

REPRODUCE THE WINNING 270-STATE RECIPE
Use a ProveIt checkout at:
  83dec60c249ca0f9e1b2e5ee3cf18fd1ce58c373
It must contain the unchanged lib/jeff-busy-beaver-zfc254 snapshot.

  python3 code/compress_full_equality.py \
    --repo /absolute/path/to/ProveIt \
    --incoming third_party/one_schema \
    --scratch /tmp/epsc270-rebuild

The script reads the checkout and writes only to the supplied scratch
folder outside that checkout. Its default regenerates one fixed recipe,
not the full search. Expected best_total.tm SHA-256:
  54d631fa31f36b02dd41634de8cadeb2cc8fcfae4bc75fea8812af0794b2a136

Add --search --seeds 128 to repeat the 2,048-choice selected search.
2,045 choices were screened out heuristically; only three were emitted.
There is no exhaustive minimum or lower-bound claim.

The earlier 192-arrangement full-equality experiment is reproducible with:
  python3 code/full_equality_epsc.py \
    --repo /absolute/path/to/ProveIt --scratch /tmp/epsc277-rebuild

The REJECTED reduced-logic experiments are reproducible with:
  python3 code/psc_compile.py --repo /absolute/path/to/ProveIt \
    --scratch /tmp/rejected-epsc --kernel empty --grouped --search
  python3 code/psc_compile.py --repo /absolute/path/to/ProveIt \
    --scratch /tmp/rejected-psc --kernel subset --grouped --search

INDEPENDENT CERTIFICATE CHECK, WITHOUT THE REPO OR GENERATOR
  python3 code/verify_operation_certificate.py \
    --source data/source_dag.json --candidate data/candidate_dag.json \
    --certificate data/rm_bisimulation.json --output /tmp/epsc-rm-check.json

Expected: 3,620 related operation pairs; 5,162 checked successor pairs.
The source is a plain right-comb EPSC program, NOT the original CP/GIC
program and NOT the specific DAG behind the best 277-state measurement.
The verifier itself is not proof-assistant-verified.

GENERIC MACRO CONTROL-EFFECT CHECK
  python3 code/macro_contract.py \
    --dag /absolute/path/to/ProveIt/lib/jeff-busy-beaver-zfc254/ZF/m254/coq/prog/Dag254.v \
    --output /tmp/epsc-macro-contract.json

All 19 AX macros have only normal finite return effects, before and after
the optional base-three helper change. This supports exact-word sharing
and reassociation. It does not prove arithmetic termination or TM compilation.

REFERENCE PROOF CHECKER
  python3 code/epsc_checker.py examples/universal_instantiation.json
  python3 code/epsc_checker.py examples/identity.json
  python3 code/epsc_checker.py examples/epsc_instance.json

The first-order checker uses genuine BOT and capture-avoiding UI.
It is not a minimized binary program. Recursive Python traversals have
host recursion limits; the report distinguishes the abstract unbounded
finite-stack algorithm from this reference implementation.

PROVENANCE AND ATTRIBUTION
  data/provenance.json          Source pins, table and certificate hashes.
  data/upstream253.json         Live PR metadata and selected actual CI lines.
  data/benchmark_recheck.json   Independent literal bootstrap evidence.
  data/incoming_sources.json   Exact hashes of all six inspected ZIP arrivals.
  THIRD_PARTY_NOTICES.txt       Source and helper acknowledgments.
  SHA256SUMS                   Complete packaged-file integrity manifest.

The prior one-schema report already supplied the raw PSC interpretation
and original-theory 269-state grammar experiment. This report's new theorem
removes the seed parameter. No historical priority outside the inspected
material is asserted. No GitHub issue, comment, PR or repository content
was written as part of this research.
