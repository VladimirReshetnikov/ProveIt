# Beyond Geometric Progressions: Supergeometric Sequences and All Infinite Linear Recurrences

Research manuscript and reproducibility package, dated **8 October 2026**.

The article proves two extensions of finite random routing for the Erdős similarity problem: a finite-block criterion allowing logarithmic gaps to grow without bound, and one common avoiding set for all convergent real constant-coefficient linear recurrences. The second extension, combined with classical bounded-recurrence structure, yields one compact set of arbitrarily large measure avoiding every real linear recurrence with infinite range.

**Status.** This is an AI-assisted research manuscript with complete ordinary mathematical proofs, separate AI audit notes, and finite computational checks. The extensions are new relative to the specific source versions inspected. Worldwide priority is not certified. The manuscript has not been externally refereed, and this package contains no Lean, Rocq, or other proof-assistant formalization. The checks support particular finite mechanisms; they do not certify the infinite theorems.

Suggested ProveIt destination:

```text
Analysis/ErdosSimilarity/Research/supergeometric-and-recurrence-avoidance/
```

## Article and results

The main files are [supergeometric_and_recurrence_avoidance.tex](supergeometric_and_recurrence_avoidance.tex) and the **28-page** [supergeometric_and_recurrence_avoidance.pdf](supergeometric_and_recurrence_avoidance.pdf). The [theorem ledger](THEOREM_LEDGER.md) distinguishes the new core lemmas from inherited constructions, classical facts, and consequences.

### 1. Long finite blocks with growing logarithmic gaps

Let a fixed positive sequence tend to zero. Suppose its values contain decreasing finite blocks

$$
b_{j,1}>\cdots>b_{j,L_j}>0,\qquad L_j\longrightarrow\infty,
$$

with one fixed $0<\mu<1$ such that

$$
b_{j,k+1}\le\mu b_{j,k},\qquad
G_j=\max_{k<L_j}\log\frac{b_{j,k}}{b_{j,k+1}}
=o(\log\log L_j).
$$

For every $0<\varepsilon<1$, there is a closed, symmetric, 1-periodic set $F$, of measure greater than $1-\varepsilon$ in every unit interval, that omits infinitely many distinct points from every affine copy of the sequence. Its compact section in $[0,1]$ has the same avoidance property. The blocks need not be consecutive in the original sequence; their positions and the gaps between blocks are unrestricted. Here $F$ may depend on the fixed sequence.

A sufficient prefix condition for a positive decreasing sequence with $a_{n+1}\le\mu a_n$ eventually is

$$
\liminf_{N\to\infty}\frac{G_N}{\log\log N}=0,
\qquad G_N=\max_{n_0\le j<N}\log\frac{a_j}{a_{j+1}}.
$$

The simpler pointwise condition $\log(a_n/a_{n+1})=o(\log\log n)$ implies this criterion. Examples include

$$
a_n=\exp[-n(\log\log n)^\gamma],\quad 0<\gamma<1,
\qquad
a_n=\exp[-n\log\log\log n],
$$

after a fixed initial index shift. Their adjacent ratios tend to zero. The article also gives a completely rational example and an example showing that the local block criterion is stronger than the prefix test.

The new budget argument chooses the branching number from the available block length and proves that the entire construction fits inside that block. Its required span satisfies

$$
\log\sigma_d=O_{p,\mu}\bigl(\sqrt{\log L}\,\log\log\log L\bigr)=o(\log L).
$$

The quantitative appendix gives a sharper sufficient normalized-scale budget, $\log\log L\ge G/p+C G^{3/4}$, with blocker density at most $p+5\tau$ for fixed $p,\tau,\mu$. This refinement does not establish a positive-constant replacement for the zero limit in the all-scale criterion.

### 2. One set for all convergent real linear recurrences

For every $0<\varepsilon<1$, one closed, symmetric, 1-periodic set $F_{\mathrm{rec},\varepsilon}$, of measure greater than $1-\varepsilon$ in every unit interval, simultaneously omits infinitely many distinct points from every affine copy of every convergent real homogeneous constant-coefficient linear recurrence that is not eventually constant.

The set is independent of the recurrence order, coefficients, roots, initial state, translation, and nonzero scale. The proof permits nonreal contracting roots, repeated or colliding roots, exact zero terms, signs, and cancellations. A first crossing of the norm of a consecutive state block supplies separated nonzero scalar samples. Polynomial sign conditions, including zero signs, count the possible routing addresses. Rational compact families of stable companion matrices cover all stable tails without a uniform separation assumption on eigenvalues.

For rational $\varepsilon$, the construction can be made effectively closed with computable Lebesgue measure. The existence proof gives a terminating search using real quantifier elimination; the supplied Python scripts do not implement that search. No practical complexity bound or computable distance function is claimed.

### 3. All infinite-range recurrences, classification, and matrix orbits

The compact section $K=F_{\mathrm{rec},\varepsilon}\cap[0,1]$ is nowhere dense and satisfies

$$
\#\bigl(\{x+sa_n:n\ge0\}\setminus K\bigr)=\infty
$$

for every real constant-coefficient recurrence with infinite range, every $x\in\mathbb R$, and every $s\ne0$. This conclusion has no convergence, boundedness, or spectral restriction. The reduction uses the classical fact that bounded recurrence sequences split into finitely many arithmetic subsequences with compact interval sets of tail limits; the needed bounded case is proved in full.

Consequently, within real constant-coefficient recurrences, the value set is measure universal **if and only if it is finite**, equivalently if and only if the sequence is eventually periodic. A product construction gives the corresponding statement for every infinite image of a finite-dimensional real matrix orbit. A countable prescribed collection of sequences from result 1 can also be avoided together with all infinite-range recurrences by one compact set.

## Scope boundaries

- The general Erdős similarity conjecture is not resolved. The displayed hypotheses do not cover $e^{-n^2}$ or $1/n!$, and the article makes no global literature-status claim about those examples.
- The finite-block theorem uses a maximum logarithmic gap, not an average-gap hypothesis. Its uniform upper ratio $\mu<1$ remains an assumption.
- The supergeometric avoiding set is sequence-dependent. The package does not claim one set for the uncountable class of all arbitrary sequences satisfying that criterion.
- The unrestricted recurrence theorem concerns compact $K$. A nonempty 1-periodic $F$ contains $x+\mathbb Z$ for each $x\in F$ and therefore cannot avoid every unbounded recurrence.
- Finite patterns are measure universal. Infinite range, or non-eventual constancy in the convergent version, is a necessary exclusion.
- In the matrix-orbit consequence, the transformed image must be infinite. A nonzero linear map can annihilate an orbit.

## Build and reproduce the checks

Run these commands from this directory:

```sh
make
make check
```

`make` uses `latexmk` and pdfLaTeX to build the main PDF. A standard TeX Live installation providing the packages declared in the main TeX file is sufficient; these include AMS mathematics, `mathtools`, `microtype`, `hyperref`, `cleveref`, and TikZ. `make clean` removes the usual intermediate TeX files.

The final build has 28 pages and no LaTeX warnings, unresolved references, overfull boxes, or underfull boxes. All pages were rendered and visually inspected. The recorded build checks are in `verification/build_validation.json`. When the archive includes a `SHA256SUMS` manifest, run `sha256sum -c SHA256SUMS` from this directory to verify the recorded file hashes.

`make check` requires Python 3 and only its standard library. There are no Python package-installation or network requirements. It runs exactly these scripts and regenerates their reports:

| Script | Report | Purpose |
| --- | --- | --- |
| [code/verify_routing.py](code/verify_routing.py) | [verification/routing.json](verification/routing.json) | Exact finite probability enumerations, exposure and collision negative controls, grid boundaries, signed first crossings, and finite tree spans; separately labelled floating-point budget sanity checks. |
| [code/verify_recurrences.py](code/verify_recurrences.py) | [verification/recurrences.json](verification/recurrences.json) | Exact rational recurrence states, matrix bounds, zero-root tails, nonzero selection, signed separation, and grid keys: 12,266 checks across seven cases in the supplied report. |
| [code/verify_budget_and_examples.py](code/verify_budget_and_examples.py) | [verification/budget_and_examples.json](verification/budget_and_examples.json) | Exact biased-selector identities, compressed window bounds, rational sequence thresholds, and recurrence examples: 60,982 checks in the supplied report. |

Each script also accepts `--json PATH`. The reports record their scope and arithmetic. Counts are finite regression coverage, not proof scores. In particular, successful checks do not validate the continuum of parameters, prove asymptotic estimates, construct the full universal set, or settle priority.

## Package organization and source attribution

| Location | Contents |
| --- | --- |
| `supergeometric_and_recurrence_avoidance.tex` and `.pdf` | Main article and rendered version. |
| `sections/` | Results and source comparison, finite routing, growing budgets, recurrence proof, consequences, verification and research questions, quantitative appendix, and bibliography. |
| `code/` and `verification/` | The three standard-library checkers and their machine-readable reports. |
| `audits/` | Separate AI mathematical audits and source-comparison notes, with their review limitations stated. |
| [THEOREM_LEDGER.md](THEOREM_LEDGER.md) | Dependency and novelty ledger with stable LaTeX labels. |
| [provenance.json](provenance.json) | Pinned source commits, exact inspected paths, paper versions, and verification metadata. |

The direct antecedents are OpenAI's *The geometric case of the Erdős similarity conjecture* at commit `adc7f1241b42e322a6451854ab7e4b4c146bf78a` and ProveIt's *Uniform geometric avoidance* at commit `368f985942fb4bff05771ee5a4262a042bc151f6`. The finite ordered tree, selector tables, first-default tests, local grid counting, and exceptional-center repair are inherited and explicitly credited. The earlier ProveIt polynomial-family theorem already includes fixed bounded-ratio sequences; those are not claimed as a new result here. Its oscillatory-recurrence question is the direct target of the second extension.

The classical external inputs include the finite sign-condition bound of Basu–Pollack–Roy and the bounded unit-root/Kronecker analysis used by Gerhold. The article reproduces the needed routing and bounded-recurrence arguments and identifies exactly where the sign-condition bound enters. Repository and primary-paper links are recorded in the bibliography and provenance file.

## Integration steps

1. Copy this directory to the suggested research destination, preserving the relative paths used by the main TeX file and `Makefile`.
2. Run `make` and `make check` there; retain the source, PDF, scripts, JSON reports, audits, theorem ledger, and provenance together.
3. Add a descriptive link to the appropriate Erdős similarity research index, identifying this as an AI-assisted manuscript awaiting external review.
4. Cross-reference the earlier uniform-geometric-avoidance report, especially its oscillatory-recurrence question, while retaining that report's independent provenance and attribution. Preserve all applicable repository licensing and source notices.

This package preparation does not modify or publish to the remote ProveIt repository.
