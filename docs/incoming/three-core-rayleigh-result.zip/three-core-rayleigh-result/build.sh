#!/bin/sh
set -eu
cd "$(dirname "$0")/article"
pdflatex -interaction=nonstopmode -halt-on-error three-core-rayleigh.tex
pdflatex -interaction=nonstopmode -halt-on-error three-core-rayleigh.tex
printf '%s\n' 'Built article/three-core-rayleigh.pdf'
