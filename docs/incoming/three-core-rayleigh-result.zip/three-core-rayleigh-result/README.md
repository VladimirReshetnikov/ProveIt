# Coefficientwise Rayleigh inequalities for a three vertex shore

This standalone package proves a coefficientwise negative-dependence theorem for directed endpoint supports on a bipartite physical graph with a three-vertex shore. Both edge directions and independent tail/head activities are allowed. Every feasible ordered pair of disjoint endpoint sets is counted once, irrespective of its number of matching witnesses.

## Results

- The boundary gap b_ij b_ik−a_i c is coefficientwise nonnegative. A complete all-size localization reduces the proof to 48 role-monomial types and 17,376 finite directed graphs. Two independent exact checkers reproduce every coefficient histogram
- Adding one private exterior head upgrades this to coefficientwise positivity of the full Rayleigh differences in the three core monomers. Use of any two core vertices is therefore negatively correlated in the endpoint-support measure under all nonnegative role activities and positive core monomer activities
- A four-core graph already admitting a two-tail/three-head role cover has a negative coefficient in the analogous boundary gap. Its gap nevertheless has an exact positive two-square formula. This refutes only the coefficientwise extension, not ULC or scalar Rayleigh nonnegativity

The boundary theorem is computer-assisted. Its proof includes a complete finite-localization argument; the finite enumeration is part of that proof. The subsequent corollaries and the exact obstruction are ordinary mathematical arguments once the boundary result is established. No random search, floating-point optimization, proof-assistant formalization, or literature-wide priority claim is involved.

## Contents

- `article/three-core-rayleigh.pdf`: typeset research paper
- `article/three-core-rayleigh.tex`: editable source
- `proof-notes/`: source snapshots pinned by the individual audit receipts
- `audits/`: independent mathematical reviews and approval receipts
- `reproducibility/`: producer and independently written exact checkers with recorded outputs
- `qa/visual-qa.json`: inspection record for every final PDF page

The original boundary note retains its proposed-status heading because the later approval receipt pins those exact bytes; the approval receipt records the final decision. Original workspace paths in receipts are provenance, not required replay locations.

## Reproduce

Requirements: Python 3.10 or later; standard library only. The release was tested with Python 3.12.14.

    PYTHONDONTWRITEBYTECODE=1 python3 verify.py

The driver checks every released file hash, copies the four checker programs into temporary directories, and compares all deterministic output fields. Only elapsed times are excluded. It additionally checks that the producer and independent boundary histograms agree in every case. Frozen package files are never overwritten.

The independent boundary program enumerates 228,264 endpoint-support instances. The four-core independent checker uses Hall's condition and an integer denominator-cleared SOS identity, separately from the producer's bijection-based matching test and rational polynomial arithmetic. It also confirms the unit-activity support polynomial 1+9t+24t²+19t³+4t⁴ and four negative-root intervals.

To rebuild the PDF with a normal TeX Live or MiKTeX installation:

    sh build.sh

Rebuilding may change PDF metadata and hashes; do it in a copy if preserving released bytes matters.

## Scope

The core-variable Rayleigh condition is asserted at nonnegative monomer arguments. It is not the all-real Rayleigh condition for real stability. There is no Rayleigh assertion in the exterior or role-activity variables. The probability measure is on endpoint supports, not matchings. All arcs cross the physical bipartition; internal core arcs are excluded. The general two-tail/three-head actual-degree rank-ULC problem remains open.

This is separate from, and does not modify, the earlier bipartite-and-pendant structural paper. No external publication was performed.
