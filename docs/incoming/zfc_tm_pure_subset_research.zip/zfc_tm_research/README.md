# Pure subset closure for a small ZFC-consistency machine

Research report prepared for Vladimir Reshetnikov, 16 October 2026.

Start with **article/report.pdf** (27 pages). The complete source, including
its bibliography, is **article/report.tex**.

## Main mathematical result

The membership arm can be deleted from the mixed bound in the pinned
seeded-positive-closure manuscript. Extensionality plus pure subset-bounded
positive closure, with either point or subset seeding, is deductively
equivalent to ZF without Foundation and Choice (with functional Replacement).

The crucial new step is not a newly invented switching relation. The prior
manuscript already uses the singleton/subset switch in another argument.
Here that switch first supplies a transitive bound **before Separation**;
constant-relation exactness then recovers full Separation, followed by Union,
Replacement, and Infinity. This resolves the prior manuscript's explicitly
open membership-arm deletion question.

The equality-free proposal uses a directed member-profile congruence axiom
plus the pure subset-seeded schema. Independent measurements reproduce the
source's 83-node equality-free control and give 64 nodes for the proposal.
These are formula-tree nodes, **not Turing-machine states**.

## Machine-facing proposal

A total four-tag formula coding keeps truth at code 0 and genuine falsity
at code 1, with self-membership at code 3. It eliminates dependence on the
benchmark's self-membership/falsity alias. The zero implication corner is
handled by explicit normalization, not an incorrect literal round-trip
claim. The numeric codec is separate from the readable reference checker;
no low-level compiler is presented as implemented.

## Contents

- `article/report.tex`, `article/report.pdf`: full report and proofs.
- `code/syntax.py`: strict equality-free syntax, capture-avoiding substitution,
  alpha equivalence, theory generators, finite semantics, metrics, and codec.
- `code/checker.py`: assumption-free constructor-certificate checker and a
  fair reference enumeration specification using JSON byte strings.
- `code/test_reference.py`: 24 unit-test methods.
- `code/experiments.py`: deterministic finite regressions and metric output.
- `data/`: executed results, example certificates, logs, provenance, PDF QA.
- `notes/`: precise status and formalization obligations.
- `build.py`: offline reproduction of tests and PDF.
- `SHA256SUMS`: release-file digests (excluding this manifest itself).

## Reproduction

Python 3.10 or newer and its standard library are sufficient for the tests.
Run without `python -O`; experimental assertions must remain enabled.

```sh
python3 build.py --tests --skip-pdf
python3 code/checker.py data/identity.json
python3 code/checker.py data/schema_example.json
```

Both example certificates are valid and **not refutations**. The second is
a conditional schema axiom, not a proof of its boundedness antecedent.

To build the PDF as well, install `pdflatex` and the standard packages listed
in the article preamble, then run:

```sh
python3 build.py --tests
```

The build uses a temporary directory and leaves the final PDF in `article/`.
No network access or upstream source download is required. Rebuilding may
change the PDF hash due to TeX timestamps or toolchain differences.

## Evidence boundary

The paper contains ordinary mathematical proofs and a certification plan.
The Python checker is a tested executable reference, not a verified kernel.
This package contains **no new TM table, no new state-count bound, no exported
ZFC or PA proof object, and no Lean/Coq formalization**. No upstream Coq build
or complete benchmark-table hash check was rerun here.

The benchmark machine is due to Mira-Cult; its imported Coq verification is
due to Jeff (`jeff87654`). The 254-state benchmark and its reported digest are
attributed to the pinned import, not claimed as new work. No unlicensed
upstream snapshot is redistributed.

See `data/provenance.json` for exact repository pins and inspected sources.
