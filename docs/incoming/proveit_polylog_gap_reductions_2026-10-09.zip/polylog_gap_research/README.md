# Mixed-Point Elimination and Certified Parity Reductions

Research continuation for Vladimir Reshetnikov's ProveIt project, 2026-10-09.

Start with `mixed_polylog_gap_reductions.pdf` (complete article) or its editable
LaTeX source. No remote repository files were changed. This is an additive
research bundle intended for review and integration.

## Main mathematical results

In the decreasing-index convention

\[
\operatorname{Li}_{a,b}(x,y)=\sum_{n>m\ge1}x^ny^m/(n^am^b),
\quad F_{a,b}(z)=\operatorname{Li}_{a,b}(z,1),
\quad D_{a,b}(z)=\operatorname{Li}_{a,b}(z,z^{-1}),
\]

grouping by the index gap yields an explicit all-weight reduction of every D
value to the F family and single-polylogarithm/zeta terms. The integer coefficient
matrix is an involution, proving equality of the two spans modulo those terms.
Thus reciprocal mixed points add no generators to the admitted F family, at
any weight.

Shuffle and stuffle in these coordinates give a half-integral parity solver:
imaginary components at even weight and real components at odd weight reduce
to single values. This proves the manuscript's five Gaussian weight-six
candidates, and two ordinary shuffles prove its weight-five “sporadic” relation.
The four weight-five Gaussian imaginary coordinates already have a spanning
bound of two modulo single-value products; no independence is asserted.

All four proposed extra mixed survivors reduce entirely to single values. For
example, with G = beta(2),

\[
\Re\operatorname{Li}_{4,1}(i,-i)
=\frac{3\pi^4\log2}{512}+\frac{\pi^2\zeta(3)}{64}-\frac{587\zeta(5)}{1024},
\]
\[
\Im\operatorname{Li}_{5,1}(i,-i)
=3\beta(6)-\frac{\pi^2\beta(4)}6-\frac{\pi^4G}{90}
-\frac{5\pi^5\log2}{3072}.
\]

The article also gives the Eisenstein counterparts, all-angle formulas at
every weight for the last-index-one parity components, and a certified
geometric evaluator based on a finite positive measure.

## What is established and what is not

The article contains complete analytic and algebraic proofs, including the
conditionally convergent boundary cases. It is an unrefereed manuscript, not
a proof-assistant formalization. The general parity phenomenon is already
known in the literature; Panzer and Umezawa are credited. Literature-wide
priority for individual formulas is not asserted.

The bundle does not prove transcendence, independence, or minimal depth of
complementary periods. It does not reconstruct the old non-mixed quotient
matrices, and it does not turn numerical residual counts into exact dimensions.
The all-weight theorems are proved on paper; finite tests are separate checks.

## Reproduce

Python 3.13.5, SymPy 1.14.0, and mpmath 1.3.0 were used. The certificate
constructor itself uses only the Python standard library. For the full suite:

```sh
python -m pip install -r requirements.txt
python src/symbolic_checks.py
python src/certify.py
python src/numerical_checks.py
pdflatex -interaction=nonstopmode -halt-on-error mixed_polylog_gap_reductions.tex
pdflatex -interaction=nonstopmode -halt-on-error mixed_polylog_gap_reductions.tex
pdflatex -interaction=nonstopmode -halt-on-error mixed_polylog_gap_reductions.tex
```

The equivalent targets are `make verify` and `make pdf`. LaTeX requires the
standard packages listed in the source, including Latin Modern, AMS packages,
geometry, booktabs, enumitem, microtype, fancyhdr, and hyperref.

The scripts resolve output paths relative to their own location. Run the
LaTeX commands from the bundle root. No network, Wolfram kernel, unpublished
Smithereens scripts, or repository checkout is needed after dependencies are
installed. To confirm that certification has no third-party import dependency:

```sh
python -S src/certify.py
```

## Evidence included

- `verification/exact_checks.json`: 49 rational-function checks, involution and
  parity-matrix checks at weights 2 through 24, six original manuscript identity
  checks, and six additional explicit target coefficient checks.
- `verification/rational_certificates.json`: six exact-rational rectangular
  enclosures for D11, D41, and D51 at i and exp(-2 pi i/3). Each coordinate width
  is below 1e-70. Exact endpoints and exact quadratic-field coefficient vectors
  are included. Truncation error and zeta/square-root uncertainty are bounded.
- `verification/numerical_checks.json`: 39 independent quadrature checks.
  These cross-checks are not interval proofs and are labeled accordingly.
- `generated/parity_tables.tex` and `.json`: 56 consequences at weights 2–8,
  for Gaussian and Eisenstein roots. An eight-page `generated/parity_tables.pdf`
  and its standalone wrapper source are included. See the local README for notation.
- `verification/review.json`: PDF build and layout review metadata.

Rational enclosures certify numerical values, not an exact identity merely
because its residual is small. Exact identities are established by the proofs
and algebraic reductions in the article.

## Integration

Read `integration/INTEGRATION.md` before editing the consolidated manuscript.
The proposed additive location is
`Analysis/Polylogarithms/docs/articles/mixed-gap-reductions/`.

The source checkpoint is `afed07429d3d37eceb6c8e9e54cf4da2d3f39d53`, and the
inspected Chapter 4 blob is `6171912ff7724784cabb789a066c61223ab298bc`.
Do not overwrite a newer chapter wholesale. The integration supplement uses
new `gapcont:` labels and explicitly replaces the interpretation of the
historical mixed-point residuals.

Seven further research directions are developed in the article: formalization,
non-mixed quotient recomputation, complementary components, depth-three gap
methods, endpoint-uniform acceleration, certificate complexity, and comparison
with published parity algorithms.
