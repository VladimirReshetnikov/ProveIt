# Direct negation construction in the ZFC Busy Beaver search

Research packet, 18 October 2026, prepared for Vladimir Reshetnikov.

**Outcome: no machine with fewer than 245 working states is established.**
This packet proves a useful register-source optimization, implements it in a
complete **247-state binary control machine**, and records the search results
and the remaining state cost. It is intended as a successor research intake
for ProveIt, with existing constructions and attributions retained.

## Main result

In the exact fine-token vocabulary of the routed source,

```text
L N P Q M V Q P W  →  L M P W
```

is valid at the proved clean-scratch constructor boundaries. Both sides
terminate and replace formula `t` by `4 π(t,1)`, where
`π(x,y)=(x+y)(x+y+1)/2+y`. They preserve the stack and every other logical
register and return both scratch registers to zero. The original program
pushes a formula and immediately unpairs that stack cell; the replacement
retains the formula in a scratch register.

All **30** original occurrences have the required incoming scratch values.
The AX word shrinks from **1,270 to 1,120** fine tokens. Independent symbolic
replay establishes equality of all nine register outputs, not merely agreement
on small examples. The report includes the loop-invariant proofs and exact
connection to the original command-boundary invariant. It also attributes the
related, distinct pairing-shift negation construction in prior intake source 56.

Changing two source DAG nodes and one physical routing obligation makes `LM`
a built-in terminal without adding framework states. The transported grammar
needs two replacement routing contexts, however, giving **117 framework plus
130 grammar states**. The resulting 247-state control has a complete ordinary
ZFC argument for the same nonhalting/Con(ZFC) equivalence through the inherited
baseline theorem and the new source contract. No new complete Lean/Rocq kernel
endpoint or PA internalization is claimed.

| Quantity | Maintained baseline | New control |
|---|---:|---:|
| Working states | 245 | 247 |
| Framework states | 117 | 117 |
| Paid grammar states | 128 | 130 |
| Ordered source leaves | 6,460 | 5,650 |
| Guarded instruction cases | 8,391 | 7,311 |
| All-values symbolic rules | 2,312,645 | 2,010,611 |
| Maximum source leaf depth | 51 | 52 |
| Maximum zero run | 6 | 6 |
| Exact blank initialization | 407,915 steps | 407,915 steps |

The new runtime proof rederives four block lemmas, three arithmetic macros,
and nine register selectors from the actual table. It covers arbitrary natural
primary registers, arbitrary extra header gap, and an arbitrary nonempty spare
suffix. The independent check covers all source-pointer successors, canonical
renumbering, and the complete tape after initialization. All 247 working states
are graph-reachable and remain distinct under exact transition congruence.

Canonical control table SHA-256:

```text
50c55ea80eaa10f537ff9eeab522124b851e844bbb79f8f839513a361d3906f7
```

Old-label control table SHA-256:

```text
53fc5a9c55102e756e32374a643a03b7983da336074e73253a80694886db1845
```

The exact construction witness is `work/grammar/lm-control/grammar.json`.
The later equal-count annealer output is a different grammar and is not the
input to use when reproducing this particular table. `input-freeze.json`
documents that distinction.

## Report and evidence

- **`report/report.pdf`** — the complete research report.
- **`report/report.tex`**, `results.tex`, and four section files — complete,
  editable LaTeX sources.
- **`work/grammar/lm-control/`** — literal transition tables, frozen grammar,
  allocation, source AST, source sites, source reassociation and exact blank run.
- **`work/runtime/lm-control-validation/`** — all-values runtime, independent
  pointer/blank check, graph audit, and linked validation summary.
- **`work/theory/`** — all-values negation proof and independent checks,
  178 certified token commutations, 135 partial/direct source variants,
  full Church-basis experiments, and the equality-free consistency argument.
- **`work/grammar/`** — trace-ideal search, coordinated constructor compiler,
  normalized-source controls, finite audits, exact seeds and search outcomes.
- **`work/terminal_shadow/`** — orientation-promotion experiments and selective
  negation contractions, with an independently written finite grammar audit.
- **`work/runtime/`** — nonseparable runtime synthesis experiments, their
  exact finite domains, negative results, and reproduction tools.
- **`work/incoming_review/`** — pinned incoming-archive inventory and reviewed
  README extracts.
- **`dependencies/`** — unchanged inherited source/runtime inputs and the
  complete baseline proof archive. `archive-byte-audit.json` identifies exact
  retained archive origins for all 243 unpacked inherited dependency files.
- **`MANIFEST.json`** — size and SHA-256 of each delivered payload file.

The many negative results have deliberately narrow labels. A finite clock
failure is not a semantic counterexample to every possible execution, a
finite grammar search is not a global lower bound, and a coarse compiler count
is not a verified blank-start state bound for a different interpreter.

## Reproduce the retained results

Requirements: **Python 3.10 or newer**, using only its standard library for
the verification below. No network, external repository, proof-assistant
installation, or library download is required. C++17 and LaTeX are needed
only for the separately requested discovery searches and PDF rebuilding.

Run from the extracted packet directory. Choose output paths that do not
already exist and are outside the packet:

```sh
python3 -B verify_packet.py --output /tmp/zfc-direct-negation-check
```

This verifies the payload hashes and exact source linkage, reruns the
symbolic and AST audits on an external copy, audits the retained grammar
witnesses, re-emits the frozen literal control, requires byte-for-byte agreement
of the table and certificates, and independently checks its source pointers,
complete blank initialization and state graph. It verifies the retained full
runtime report's binding but does not recompute every unbounded runtime case.

For that complete recomputation and all 7,500 alternative-basis trials:

```sh
python3 -B verify_packet.py \
  --output /tmp/zfc-direct-negation-full \
  --full-runtime --church-search
```

The complete all-values pass took about 329 seconds during the initial run.
Reproduction times depend on hardware. All new output, copied audit records,
and logs are written beneath the selected output directory. The delivered
files are read only. Assertions are verification gates: do not use Python
`-O` or set `PYTHONOPTIMIZE`.

The individual component READMEs give smaller commands and explain their
scope. Some component scripts regenerate JSON beside themselves; the top-level
runner copies those components before running them so that the packet's
manifest remains valid.

### Repeat the finite runtime discovery searches

This is optional. It does not strengthen the proved source identity or the
already complete runtime certificate. It checks the reported finite search
families using a C++17 compiler and writes results to the selected directory:

```sh
python3 -B work/runtime/reproduce_searches.py \
  --table dependencies/fine_grammar/runtime/machine/zfc245_old.tm \
  --instruction-cases dependencies/fine_grammar/runtime/inputs/state_reduction/candidate245-literal-cases.txt.gz \
  --output /tmp/zfc-direct-negation-runtime-search
```

The nominal seven-row families contain `28^7` assignments each. Lazy search
prunes all extensions of a partial assignment when an already determined
finite trace fails. The records give both nominal family size and actually
visited branches; they do not claim billions of full fixture-suite executions.

### Repeat grammar discovery

See `work/grammar/README.md` and `work/terminal_shadow/README.md`. The exact
retained witnesses are verified independently of the stochastic search.
Wall-clock search budgets make proposal counts machine-dependent. The 121
unsearched selective-negation seeds are regenerable intermediates and are
omitted; their source variants and complete seed census are retained.

### Rebuild the PDF

With TeX Live and `latexmk` installed:

```sh
latexmk -cd -pdf -interaction=nonstopmode -halt-on-error \
  -outdir=/tmp/zfc-direct-negation-pdf report/report.tex
```

The PDF was rendered and visually reviewed. `report/runtime_search_notes.tex`
has one filename-formatting change relative to the same proof fragment under
`work/runtime/`; its mathematical content is identical.

## Pin, provenance, and incorporation

ProveIt pin: **`fd1adfa19f8fe8da41444e3fa43b89a59d891067`**.

The maintained 245-state table and its ordinary ZFC proof are the starting
point. The baseline archive `dependencies/zfc245-proof-20261018.zip` is included
unchanged. The new source constructor does not remove equality axioms, weaken
CP/GIC, assume consistency, or change the original formula encoding.

Credit remains with Mira-Cult for the original machine and calculus, Jeff
Ketchersid and contributors for m254 and its Rocq verification, Andrew James
Wade for the compiler, and ProveIt and the attributed incoming packets for the
inherited runtime and research. Preserve all supplied notices and licenses.
The new code and explanatory proofs do not relicense copied dependencies.

The numerical milestone still needed is **at most 127 grammar states with
the 117-state framework**, or another joint change totaling at most 244. The
report explains why the direct constructor currently costs two additional
routing contexts and which source/physical interfaces must be optimized
together to turn the shorter source into a smaller machine.
