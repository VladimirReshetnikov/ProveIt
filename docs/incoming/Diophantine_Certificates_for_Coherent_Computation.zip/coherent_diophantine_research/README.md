# Diophantine Certificates for Coherent Computation

**Canonical tensor contractions, exact quantum probabilities, and the boundary of effective observation**

Research manuscript prepared for Vladimir Reshetnikov, September 30, 2026.

## Read the article

`article.pdf` is the compiled manuscript. `article.tex` is its complete LaTeX source, including the bibliography. The article proves an explicit natural-witness compiler for integer and cyclotomic tensor contractions, applies it to exact quantum probabilities and adaptive graph-state measurements, and proves complexity and computability limitations. Section 11 proposes twelve further research projects.

The principal cyclotomic base bound is **8L + 64T natural variables**, with quadratic residuals whose sum of squares has degree at most four. A strict rational probability query adds at most **39 variables and 50 equations**. Complete definitions, hypotheses, witness uniqueness, and height bounds are in the article. This is not a claim of a polynomial-size general quantum simulator.

The construction uses the ProveIt MRDP theorem only for its separate unbounded positive-halting consequence. The finite compiler is proved directly. The article does not claim a solution of the general single-fold or finite-fold MRDP conjectures, and historical priority for the combined compiler has not been established. No Lean formalization was performed in this package.

## Files

- `article.tex`, `article.pdf`: source and compiled article.
- `code/coherent.py`: exact cyclotomic arithmetic, quantum and graph-state networks, canonical quadratic constraints, and rational probability queries.
- `code/verify.py`: reproducible exact tests and JSON artifact generation.
- `code/check_certificate.py`: independent checker importing no compiler code.
- `data/verification.json`, `data/verification.log`: recorded test results.
- `data/independent_checker.log`: results for the three exported polynomial artifacts.
- `data/HH_expanded_quartic.json`: full 33-term quartic, nine residuals, and its unique eight-coordinate witness.
- `data/HH_zero_certificate.json`: circuit-native certificate for the zero-probability outcome of HH.
- `data/HTH_zero_certificate.json`: certificate for outcome **0** of HTH, with probability (2 + sqrt(2))/4. Here “zero” names the observed bit, not a zero probability.
- `build.py`: cross-platform build helper.
- `SOURCE_AUDIT.md`: source provenance and status of the claims.
- `BUILD_INFO.txt`: production environment and checks.
- `SHA256SUMS.txt`: hashes of the delivered files except the checksum file itself.

## Run the checks

Use Python 3.10 or later. No third-party Python packages are needed.

```text
python code/verify.py
python code/check_certificate.py data/HH_expanded_quartic.json data/HH_zero_certificate.json data/HTH_zero_certificate.json
```

Do not use Python's `-O` flag: the semantic test suite uses assertions. The independent file checker performs explicit checks and exits nonzero on invalid data.

The recorded run used Python 3.13.5. It passed 3,966 circuit-network comparisons, 592 graph-factor network comparisons, 2,401 exact quadratic-field sign checks, 625 norm identities, 43 quadratic-certificate tests, and the other checks detailed in `verification.json`. Some certificate tests intentionally construct **false** threshold queries and verify that the computed assignment is rejected. The elapsed time is machine-dependent; mathematical outputs and the seeded examples are reproducible.

## Build the PDF

A standard TeX distribution providing the packages in the preamble is required. The bibliography is embedded; BibTeX is not needed.

```text
python build.py
```

Or rerun all checks before building:

```text
python build.py --check
```

The helper keeps LaTeX temporary files in `_build/` and copies the finished PDF to `article.pdf`. Three passes stabilize the table of contents and references.

## A minimal exact-probability query

Run from the `code/` directory, or add it to `PYTHONPATH`:

```python
from coherent import Certificate, Gate, contract, probability_network

# H, then T, then H on |0>; ask whether the probability of outcome 0 is > 1/2.
gates = [Gate("H", (0,)), Gate("T", (0,)), Gate("H", (0,))]
network, hadamards = probability_network(1, gates, measured={0: 0})
certificate = Certificate()
output, profile = contract(network, certificate, order="greedy")
certificate.require_probability_gt(output, hadamards, 1, 2)
assert certificate.valid()
certificate.export("hth_above_half.json")
```

Every exported variable ranges over the **nonnegative integers**. The single Diophantine polynomial is the sum of the squares of the listed quadratic residuals. `export(..., expanded=True)` emits its complete sparse expansion; this is convenient for small examples but can be wasteful for large ones.

## Interpreting the artifacts

A polynomial term is represented by an integer `coefficient` and a list `variables` of zero-based indices. Repeated indices are powers; the empty list denotes a constant. An integer wire has a positive and negative natural coordinate constrained to have product zero.

The large HH and HTH files include circuit/event metadata, final output-coordinate indices, exact expected numerator coefficients, the physical denominator, and four linear output assertions. Their equation counts are respectively 1,330 and 1,810; the base-count table in the article excludes those four assertions. Their variable counts are 1,326 and 1,806.

The prototype uses binary tensor edges and dense local tables. Its `greedy` and `queue` schedules are deterministic heuristics, not optimality claims. It computes a witness while generating the polynomial constraints, so it does not avoid the cost of exact contraction. The mathematical compiler can generate the equation structure without first evaluating its output.

The independent JSON checker establishes that a supplied natural tuple satisfies the exported equations. Its expanded-polynomial check additionally verifies the sum-of-squares identity. It does **not** by itself prove that arbitrary equations describe the claimed physical circuit. That semantic correspondence and general uniqueness are theorems of the article, supported by the finite cross-checks, not inferred from one satisfying tuple.
