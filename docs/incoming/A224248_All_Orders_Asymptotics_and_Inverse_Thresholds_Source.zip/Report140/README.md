# Report140 offline reproducible companion

This bundle accompanies **All orders asymptotics and inverse thresholds for unique 12345** (A224248), dated October 2, 2026. The article proves the analytic statements. Finite arithmetic replay checks specified algebraic identities and examples; it does not prove infinite-dimensional uniformity, convergence of a regularized series, all orders at once, or a numerical threshold.

## Trust and scope

Review the executable source and establish provenance before running it. The manifest checks internal integrity; it is not an author signature and cannot make arbitrarily replaced verifier code trustworthy. No network, package installation, external downloaded execution, shell escape, or third-party Python package is required. Python 3.10 or later is expected. `-I` is mandatory, even for `check`, and is checked before imports that could be shadowed. Explicit requirements remain active under `-O`.

The only mathematical replay implementation is `code/exact.py`, using exact integers and rational numbers from the standard library. `sources/` contains typed historical check receipts and their factual provenance only. Historical working scripts are not included or executed by this verifier. The historical receipt's timing is provenance, never a mathematical datum. The typeset article is the mathematical report of record.

Report138 is a frozen dependency at `dependencies/Report138_reproducible.zip`. Its unchanged PDF, TeX, and corrected companion are identified by hashes in `SOURCES.md`. Verification checks the nested ZIP and its full manifest, and pins the baseline TeX/PDF separately. Report138's own finite combinatorial replay and clean PDF build can be run using its included instructions after separately extracting that dependency. Report140 replay does not silently rerun or take credit for Report138's tests.

No certified decimal amplitude, effective error constant, effective onset, convergence or summability of the infinite asymptotic expansion, or arbitrary-length monotone-pattern theorem is claimed.

## Commands

Run these from the extracted `Report140` directory. The examples use absent absolute paths under `/tmp`, whose parent must already exist and be writable. If a sample destination already exists, replace it with a different absent absolute path; existing destinations, symlinks, parent traversal, ambiguous double-leading slashes, and in-bundle outputs are rejected. None of these commands overwrite an existing output.

    python -I -B verify.py check
    python -I -B verify.py replay --output /tmp/report140-replay
    python -I -B -O verify.py replay --output /tmp/report140-optimized-replay
    python -I -B verify.py selftest --output /tmp/report140-selftest
    python -I -B verify.py pack --output /tmp/Report140-repacked.zip
    python -I -B verify.py build --output /tmp/report140-clean-build
    python -I -B verify.py reproduce --output /tmp/report140-reproduction

`check` checks closed inventories, sizes and SHA256 hashes, typed closed JSON contracts, pinned source provenance, and the bounded nested dependency ZIP. It does not establish the numerical truth of fixtures. `replay` independently computes every exact fixture and then compares the computed result with it. `selftest` exercises every typed JSON field, missing/extra keys, duplicate keys, boolean-as-integer confusion, invalid rationals, nonfinite and overflowing numeric tokens, import-shadowing guards, output path guards, bounded reads, malicious archive names and member types, normal/optimized replay, and deterministic extraction/repacking.

`build` needs the installed `pdftex`/`pdflatex` toolchain and the TeX packages used by the article. It creates a fresh LaTeX format using `pdftex -ini`, a fresh HOME and TeX trees, a fixed source epoch, explicit font maps, shell escape disabled, and three LaTeX passes. It rejects the listed layout/reference warnings and writes a receipt containing the PDF byte-match result. `reproduce` requires two independently clean builds to match the frozen PDF, reruns selftests, and emits a consolidated receipt. A different TeX/font version may produce different PDF bytes even when its rendering is mathematically equivalent; such a mismatch is reported, not hidden.

`seal --output /tmp/report140-reviewed-new-manifest.json` writes a proposed external manifest only after all non-manifest checks pass. It never changes this bundle or establishes provenance for an altered program. Rebuilding a changed article requires a new reviewed release, not merely resealing.

## Safety limits

Inputs are limited to 16 MiB per regular file and 64 MiB in aggregate. ZIPs are limited to 128 stored regular-file members, bounded per-file and aggregate reads, no links, duplicate names, traversal, encryption, comments, or unsupported metadata. Extraction validates all content before making outputs and writes members explicitly rather than using `extractall`. These checks are for offline reproducibility under normal filesystem ownership; they are not a general sandbox against malicious executable replacement, hostile operating systems, or concurrent filesystem races.

## Proof versus finite verification

The exact fixture describes its finite ranges and counts. The Gaussian calculation, character examples, rational gamma recurrence checks, binomial product cancellation tests, discrete Taylor tests, triangular matching, Stirling conversion, shift and ratio identities, and inverse reversion are finite exact computations. They supplement the proofs in the article. The absence of a logarithmic or additional fractional sector at every algebraic order rests on the article's exact model-product identity and remainder estimates, not on checking a finite number of examples.
