SELF-EMBEDDINGS OF THE SURREAL NUMBERS
Structure, Rigidity, and Foundations
Research article dated 3 October 2026

CONTENTS
  surreal_self_embeddings.pdf  - complete 47-page article
  surreal_self_embeddings.tex  - self-contained LaTeX source
  README.txt                    - this guide
  SHA256SUMS.txt                - checksums for the three files above

The article has 10 sections, 22 bibliography entries, and 11 numbered
research questions, plus further formalization and hyperseries topics.
All definitions, proofs, source references, research questions, and the
formalization assessment are included in the TeX and PDF.

COMPILATION
Use a current TeX Live or MiKTeX installation with the standard packages
listed in the preamble. Recommended command:

  latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_self_embeddings.tex

Alternatively run pdflatex repeatedly until references and the table of
contents stabilize (normally three runs from a clean directory):

  pdflatex -interaction=nonstopmode -halt-on-error surreal_self_embeddings.tex

The bibliography is embedded in the source. No BibTeX/Biber run, external
images, downloaded fonts, repository checkout, or shell escape is required.

REPOSITORY SNAPSHOT AND PROVENANCE
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 79049d58cc66341825ac5b1009ad7fd3b7bebf31
Source access date: 3 October 2026

Repository theorems are explicitly credited. The report builds on the
omnific, exponential-rigidity, and large-cardinal/normal-form manuscripts
and inspects the relevant Lean definitions and proof bodies. A consequence
proved in this report is not thereby claimed to be new in the literature.
Exact manuscript labels and pinned links are in the article.

VERIFICATION SCOPE
The final TeX compiled successfully with pdfLaTeX. The final compilation
reported no unresolved references or citations, no LaTeX/package warnings,
and no overfull or underfull boxes. The 47-page PDF was rendered and
visually reviewed, including the tables and bibliography. The archive was
checked by reading every member and comparing the included SHA-256 sums.

The Lean assessment is source-level only. No fresh ProveIt build, kernel
recheck, or transitive axiom audit was run. The article distinguishes actual
surreal implementations, generic theorems needing instantiation, and
manuscript results not located in the inspected Lean mapping.

READING ROUTE
Section 1: Structures, notation, and existing ProveIt results.
Section 2: Order, simplicity, birthdays, fixed points, and topology.
Section 3: Field embeddings, normal forms, explicit copies, and strong sums.
Section 4: Fixed parameters, ordinal fixation, elementarity, definability.
Section 5: Omnific automorphisms, proper embeddings, coefficient drift.
Section 6: Omega-map, exponential, differential, and hyperserial constraints.
Section 7: Class foundations, birthday localization, and large cardinals.
Section 8: Current Lean scope and a concrete continuation.
Section 9: Research questions with statuses and first steps.
Section 10: Source audit and limits of verification.

The displayed omega-powers use Conway's omega-map unless another
exponentiation convention is explicitly stated. This distinction matters
for several examples. Every Hahn support and summable family is set-sized
in the stated ambient framework.
