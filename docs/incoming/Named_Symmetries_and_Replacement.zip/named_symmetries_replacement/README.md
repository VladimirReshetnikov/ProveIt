# Named Symmetries and Replacement

**An exact orbit criterion, a strict kernel hierarchy, and invariance of the pure surreal universe**

Research manuscript prepared for Vladimir Reshetnikov with ChatGPT, 3 October 2026.

## Contents

- `article.tex`: self-contained LaTeX article, with bibliography in the source.
- `article.pdf`: compiled article.
- `verify_orbit_spectra.py`: standard-library finite-action regression checker.
- `verification_results.json`: actual successful checker output.
- `source_audit.md`: source provenance, mathematical dependency boundary, and status.
- `Makefile`: build, verification, and cleanup commands.

## Main results

Inside an ambient well-founded universe with Choice and a set A of infinitely
many urelements, let M consist of every object with finite actual atom kernel.
Name a uniform action of a pure set-sized group Gamma.

1. Expanded Replacement holds exactly when every generated atom orbit is finite
   and the union of the finitely repeated finite transitive orbit types is finite.
2. For k >= 1, Replacement restricted to outputs involving at most k atoms holds
   exactly when the generated atom orbits are finite and only finitely many atoms
   have orbit size at most k under the centralizer of the named action.
3. For every d >= 1, two involutions, each individually preserving full
   Replacement, jointly preserve precisely the fixed finite levels k < d.
   All joint generated atom orbits are finite.
4. One permutation can preserve every fixed finite level while failing full
   Replacement.
5. Expanded Collection for pure-valued relations still holds. All examples keep
   the same pure sets, hence the same canonical pure surreal field.

The article provides complete proofs, explicit failure witnesses, twelve
continuation problems, and a staged formalization roadmap.

## Status

This is an unrefereed mathematical research draft. The finite-kernel model and
its basic symmetry method are classical. The classification and hierarchy are
proved here as proposed refinements; historical priority is not established.
No named published conjecture is claimed solved. No Lean or Rocq verification
of the new metatheorems is claimed. Elliot Glazer is not a coauthor or endorser.

The script passed **203 finite checks**, including **35 independent brute-force
comparisons** on small domains. Those checks validate finite centralizer
calculations only, not the infinite model constructions or Replacement schemes.
A finite truncation of a displayed example does not itself refute Replacement.

## Reproduction

Requires Python 3.10 or newer (no third-party modules) and a LaTeX installation
with `latexmk`, `pdflatex`, `newpxtext`, `newpxmath`, `tcolorbox`, and the other
packages listed in `article.tex`.

```sh
python3 verify_orbit_spectra.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Or run `make all`. Run `make clean` to remove LaTeX intermediates while preserving
the PDF. No font files are distributed.

## Repository context

The source comparison used ProveIt commit
`8dc2592e951b3402951060a15b61d65162aadc0f` and the surreal README blob
`18478d58670c384953fb85dcd1a6d931c644aa32`.
No repository files were modified, no commit was made, and no claim of building
or auditing the full repository is made.
