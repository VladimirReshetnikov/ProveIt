# The sharp rank 38 ULC boundary for full Hall graphs

This companion closes the earlier-gap question for full Hall graphs with one common positive activity on the right core and unit activities elsewhere. Every intermediate Newton gap has positive common-field coefficients through rank 38, for all eligible exterior populations. Together with the previously established endpoint theorem, the first failure of any gap within this precise family occurs at rank 38.

The result does not classify arbitrary individual one-shore fields or arbitrary graphs. The general finite-activity rank-six one-shore problem remains open.

## Contents

- `article.pdf` and `article.tex`: the mathematical report and editable source
- `code/population_coeff.py`: exact finite-population coefficient formula
- `code/difference_coeff.py`: integer finite-difference expansion
- `code/verify_all_populations.py`: exhaustive coefficient verifier
- `code/compare_certificates.py`: comparison with the supplied per-gap records
- `code/independent_replay.py`: separately implemented reconstruction using a support recurrence and inverse Pascal matrix
- `code/check_support_identity.py`: eight exact graph matching enumerations
- `code/check_population_identity.py`: independent direct-support regression checks
- `data/certificate/`: counts and SHA-256 records for every core shape and gap
- `data/population_identity_checks.json`: the 200 exact identity checks
- `build_local.sh`: the local TeX build command used for this report

## Reproduce the complete certificate

Python 3 with its standard library is sufficient. From this directory run:

```sh
python code/verify_all_populations.py --output-dir replay
python code/compare_certificates.py data/certificate replay
python code/check_population_identity.py
python code/independent_replay.py --output independent_replay
python code/check_support_identity.py
```

The first command checks 22,452,529 integer coefficients over 561 core pairs and 13,651 intermediate gaps. All are strictly positive; the smallest is 9. The recorded run took about five minutes in the research environment. The identities in the report make this finite array cover every nonnegative integer population increment and every positive real common field. It is not a finite parameter sample.

Each per-gap SHA-256 digest processes the ASCII lines `s,p,e:c` followed by one newline, in increasing `s`, then `p`, then `e` order, using the exact ranges in the report. The summary digest concatenates those hexadecimal per-gap digests in increasing rank, core-left size and gap order, then applies SHA-256 once. Runtime values are not part of the mathematical certificate.

The report uses two earlier proved companion results: the minimum-cover theorem with at most two vertices on one shore and the sharp endpoint classification. Their exact titles and source-package names are in the bibliography. The new result concerns the intermediate gaps; the earlier delivered reports remain unchanged.

For a normal TeX installation, two runs of `pdflatex article.tex` build the report. The supplied `build_local.sh` also supports the research environment's TeX configuration. No software installation or network access is needed for certificate replay.
