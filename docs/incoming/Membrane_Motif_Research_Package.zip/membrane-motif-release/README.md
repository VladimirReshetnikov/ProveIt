# Exact spatial certificates for active membrane systems

Research release, 2 October 2026

## Main result

The article proves a schema-dependent exact spatial compression theorem for polarizationless, noncooperative active membranes with weak division, dissolution, evolution and communication. Every natural zero for a well-formed fixed schema gives a legal maximally parallel step. Every legal concrete step admits a consistently indexed schema and a natural zero. The residuals are quadratic; their sum of squares is quartic.

Both numeric payloads and clone populations are variables. Source projection retains each parent's context, old-object resource accounting enforces exact inclusion maximality, and bottom-up forest equations handle updated-subtree copying and cascading dissolution.

This is a spatial result. It does not supply a fixed universal polynomial, a literal instantiated universal P-system, a free unbounded-history decoder, or a unique accepting witness. The anti-sharing lower bound concerns quotients merging identical subtrees only. The source discussion credits prior elementary clone grouping and makes no exhaustive novelty claim.

## Read

- `article/membrane_motifs.pdf`: research article with full proofs, worked examples, exact ledgers, limitations and references
- `article/membrane_motifs.tex`: editable LaTeX source
- `RELEASE_NOTES.md`: scope, tested outcomes and file conventions
- `provenance/source-provenance.json`: primary-source URLs and available source hashes; source PDFs are not redistributed

## Replay

From this directory:

    python3 replay/run_all.py

Python 3 standard library only. The exhaustive suite may take several minutes. It rewrites the generated example exports, stdout logs and receipts. The short saved-witness replay is:

    python3 replay/verify_saved_examples.py
    python3 replay/regression_extensions.py
    python3 replay/export_sos.py

Scripts:

- `replay/motif_compiler.py`: exact sparse residual compiler and expanded operational oracle
- `replay/replay_tests.py`: finite candidate-plan comparisons, contextual regressions and infinite-family samples
- `replay/focused_tests.py`: old-topology and normalization checks, deterministic anti-sharing and variable ledgers
- `replay/verify_saved_examples.py`: direct replay of saved schemas and witnesses, exact residual/variable ledgers and coefficient bounds
- `replay/regression_extensions.py`: cascaded dissolution/copying, natural-domain and duplicate-index counterexamples, sharp population identity checks
- `replay/export_sos.py`: literal expanded quartic for the contextual-copy example
- `replay/run_all.py`: ordered complete replay and execution metadata/hash receipt

Data:

- `replay/examples.json`: supplied schemas, rule arrays, natural witnesses and exact ledgers
- `replay/contextual_copy_polynomials.json`: 129 named sparse residuals and the 86-coordinate witness
- `replay/contextual_copy_quartic.json`: their fully expanded degree-four sum of squares, with 282 monomials
- `replay/*receipt.json`: exact-check outcomes; `run_receipt.json` additionally records runtime metadata and file hashes

Each sparse term is `[integer coefficient, sorted variable-name list]`. An empty variable list means a constant. All variables are natural, including zero. The `c` and `m` coordinates encode physical multiplicity minus one. The polynomial alone does not enforce the natural-number domain.

## Build the article

With a standard TeX Live installation:

    cd article
    latexmk -pdf -interaction=nonstopmode -halt-on-error membrane_motifs.tex

The PDF has been compiled and visually checked. Rendering aids and intermediate TeX caches are omitted from this release. The release manifest hashes the curated files; rerunning scripts changes time-stamped receipts and therefore requires a new manifest if you want hashes for your own run.

## Evidence boundary

Finite tests corroborate the English proofs; they are not formal verification. The compiler and oracle share some helpers. Rule-source validity and any frontend repairs are separate obligations. All source code and article text in this package were prepared for this research release. Third-party papers, extracted text, screenshots and private review notes are excluded.
