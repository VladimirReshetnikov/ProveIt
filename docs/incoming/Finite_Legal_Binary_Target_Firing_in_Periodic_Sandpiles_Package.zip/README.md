# Research Report 52

## Result and exact scope

The report gives one literal integer polynomial for existence of a finite legal **binary** sandpile prefix firing a supplied signed target on the infinite three-dimensional cubic lattice. Every site may topple at most once in the prefix. The endpoint need not be stable and later evolution need not terminate.

- One positive input encodes eleven natural physical fields through ten right-associated Cantor pairings
- Six positive dimensions, a periodic base-32 tile with digits 0–5, a finite patch with digits 0–15, and three zigzag-encoded signed target coordinates
- Exactly 3,308 positive witnesses, 1,923 residuals, 14,778 binary arithmetic gates, and total degree 18
- Highest homogeneous part: 48 times the square of the nine-variable product of the six dimensions and three positive padding witnesses
- All 118 POWER, 30 Sub, five AND, and four SPREAD calls expanded into ordinary polynomial gates
- A successful final stream is an actual legal-prefix odometer, not necessarily maximal or globally stabilizing

The positive-integer theorem retains the two specifically pinned constructive Pell theorems from mathlib. The report does not claim ordinary unrestricted target firing, a new universal loader, a raw-program compiler, finite-fold fibers, real-witness exactness, an optimal ledger, or a newly Lean-checked combined theorem. The valid patch [12,4] explicitly separates ordinary target firing from this binary relation.

## Files

- `Research_Report52.tex`: editable, self-contained article, including the full macros and physical tensor lemmas
- `Research_Report52.pdf`: 24-page rendered report
- `science/`: byte-identical author-side science packet, including the literal DAG, construction notes, builder, checker, and receipts
- `independent_audit/`: byte-identical independent source audit, separate semantic review, frozen checkers, manifest, and receipts
- `audit_replay/`: independently prepared portable path-only adapter and its 27-test safety/relocation evidence
- `baseline_report50/`: full authenticated Report 50 release, with its own manifest, report, audit, frozen Pell source, and historical source dependencies
- `verification/`: report-specific replay, preservation, build, layout, and release-tool test evidence
- `verify_release.py`: read-only closed-file-inventory and hash verification, including all nested authenticated manifests
- `build_pdf.py`: deterministic local TeX build into a new external directory
- `archive_release.py`: deterministic stored-ZIP creation into a new external file
- `test_release_tools.py`: integrity, mutation, relocation, archive, and output-boundary tests on fresh copies
- `MANIFEST.json`: complete release file hashes, byte lengths, and modes, excluding the manifest itself

The science packet's notes retain their original construction-stage wording that independent review was pending. The later independent audit gives PASS for the exact binary target-firing relation. Historical absolute workspace paths in scientific manifests are provenance, not active replay input paths.

## Integrity first

Get the trusted final manifest SHA256 from the separate delivery record. A checksum stored only inside the same archive does not authenticate that archive independently.

From the extracted release root:

```sh
python3 -I verify_release.py --manifest-sha256 TRUSTED_MANIFEST_SHA256
```

Use Python 3 in isolated mode, without `-O` or `-OO`. The four root release scripts and `audit_replay/replay_audits.py` enforce these requirements. The separate `audit_replay/test_replay_adapter.py` harness does not itself enforce an isolated invocation; it launches its scientific replay subprocesses with `-I`. The verifier checks the exact file inventory, file hashes, sizes and modes, as well as the separately pinned target-audit, replay-package, and Report 50 manifests. It performs no scientific execution and needs no third-party Python package, network, Lean, or TeX installation.

The final manifest hash intentionally is not printed inside this README, because doing so would create a self-reference. The archive checksum is likewise a separate external file or delivery-record value.

## Replay both independent scientific checks

Use a new output directory outside the release; its parent must already exist:

```sh
python3 -I audit_replay/replay_audits.py \
  --source-root science \
  --audit-root independent_audit \
  --output /tmp/report52-audit-new
```

The adapter authenticates the frozen checker bytes, redirects only their filesystem globals, and executes their original unmodified main bodies. It neither imports nor runs the submitted builder or author checker. Both scientific receipts must reproduce byte-for-byte, and input tree bytes, modes, and mtimes must remain unchanged. Active reads use the provided relocated source/audit directories. Old absolute provenance paths are not used.

The main audit normalizes all 1,923 residuals as exact sparse formal integer polynomials, checks 157 macro interfaces and 36 ports, all witnesses and gates, the complete sum of squares, exact ledger, and exact leading homogeneous terms. Separate finite tests check arithmetic, geometry, recurrence, legality, coordinates, and adversarial examples. The semantic checker provides an independent suite. These finite regressions do not replace the report's all-integer proof or the pinned Pell theorem dependency.

The portable adapter's additional safety and relocation test harness may be replayed with:

```sh
python3 -I audit_replay/test_replay_adapter.py \
  --source-root science \
  --audit-root independent_audit \
  --output /tmp/report52-adapter-tests-new
```

See `audit_replay/README.md` for its exact redirection contract and test coverage. It rejects symlinks, parent traversal, nonregular source files, tampered pins, an existing output, and overlapping output/input directories. If a failed run leaves a partial diagnostic directory, choose a fresh path rather than deleting or overwriting it through these tools.

## Rebuild the PDF offline

Requirements: Python 3 and locally installed pdfLaTeX, its ordinary article/AMS/Latin Modern/hyperref packages, and `kpsewhich`. No packages are downloaded or installed. The tested engine is recorded in `verification/pdf-build.json`.

```sh
python3 -I build_pdf.py \
  --output /tmp/report52-pdf-new \
  --check-packaged \
  --manifest-sha256 TRUSTED_MANIFEST_SHA256
```

The output directory must be new, disjoint from the release, and have an existing parent. Three TeX passes resolve references. Shell escape is disabled; the source epoch and PDF date/trailer controls are fixed. The build checks that the release's bytes, modes, and mtimes did not change and, with `--check-packaged`, that the output PDF is byte-identical to the included PDF. Font/engine changes may alter PDF bytes; the deterministic claim is for the recorded local installation.

Local Poppler `pdftoppm -png` can render pages for a new visual inspection. All 24 final pages were independently inspected. Rendered page images are QA intermediates and are not included in the deliverable.

## Rebuild the archive

```sh
python3 -I archive_release.py \
  --output /tmp/Research_Report52_reproducibility.zip \
  --manifest-sha256 TRUSTED_MANIFEST_SHA256
```

The output file must not exist and must lie outside the release. The tool verifies release integrity, uses sorted paths, timestamp 2026-10-04 00:00:00, Unix regular-file mode 0644, and ZIP_STORED payloads. It reopens the ZIP, checks CRCs, exact membership, and every payload's SHA256 against the source. Two independent creations are required to agree byte-for-byte in the release evidence.

## Release-tool regression tests

```sh
python3 -I test_release_tools.py --output /tmp/report52-release-tool-tests-new
```

This fresh 22-test harness operates on copies, builds a temporary test manifest, verifies a relocated release, checks refusal of tampering and unsafe outputs, and creates two identical archives. It does not regenerate or modify the sealed original release manifest. Actual PDF byte-identity testing is recorded separately.

## Scientific pins

- Literal DAG: `352b6dd9add46ed3c1c8532c21e9725249b28b3afba23003e31330b2503e0504`
- Target audit manifest: `dd6a27229d204f993b36e3f74a794353fa925e34926fd60fa3974eb1c50a33ab`
- Portable replay manifest: `173afc73d4f0850d025e8e0d2f43c39fc23de50970b894d735f1497af23bd2d4`
- Baseline Report 50 manifest: `a0458d81f2ec02b5c75d03c68d64da5a428bbf4304d69e4d94f82384fdb5958d`
- Pinned mathlib commit: `ac77769fabe23cb237559e7f56578dbead91499f`
- Pell source SHA256: `993760c797ad0ff66fa77064a616fce779550bc745cbf6c44e04f392fd0bed0a`

The PDF and TeX hashes are in the final release manifest. A later change to the theorem, literal DAG, macro domain proof, source ledger, or dependencies requires fresh scientific review; passing an old checksum is not a substitute.
