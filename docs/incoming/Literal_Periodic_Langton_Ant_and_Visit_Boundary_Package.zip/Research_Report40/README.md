# Research Report 40

A literal periodic Langton ant U15 interface and the precisely aligned one-visit/two-visit reachability boundary.

## Read

- `Research_Report40.pdf`: full mathematical article
- `Research_Report40.tex` and `figures/`: editable, reproducible article source
- `evidence/literal-interface/`: canonical hardened v2 literal proof/code/data packet
- `evidence/one-visit-companion/`: complete unchanged Report38 lower-side article and proof packet
- `evidence/endpoint/`: separately paid arithmetic endpoint, conditional on the inherited bounded-board history contract
- `evidence/independent-audit/`: independent source audit and independently replayable extra interface checks

The ant has fixed rule color0=right and color1=left. It starts at (288650,75,E) on a background with rectangular periods (576000,481238074400). The finite input words are nearest-head-first. The loader changes exactly 2812+4(popcount left+popcount right) cells. Acceptance is a fixed pre-departure residue/heading event, and the entire infinite trajectory has at most two visits per cell. The article proves a single reachable accepting clause suffices. The qualitative universality and two-visit principle are credited to Maldonado et al. The arbitrary-program-to-U15-pair compiler remains a published dependency.

The endpoint appendix supplies exactly 42=37M+5A with prescribed fixed K,C,D, or 101=94M+7A with only literals1,3. These are endpoint-component costs; no combined174/universal/raw-input or final single-polynomial count is claimed.

## Authenticity first

Obtain the published final ZIP SHA256 independently and verify it using a trusted external hash tool before executing any packaged Python. The release's own manifest or PASS status is not an external trust anchor. Do not reseal a received package to make it pass.

From an authenticated extracted release:

    python3 -I -B verify_release.py --verify-only
    python3 -I -B verify_release.py --replay

The identity gate checks all files, exact paths, types, modes, source pins and approved replay inventory before running any scientific source. Replay stages authenticated mutable copies outside the release. It runs the literal driver, the additional independent interface check, the endpoint driver, and the unchanged Report38 enclosing replay. All original release bytes, modes and mtimes are checked for preservation. Access times are not covered.

IMPORTANT: never run `evidence/literal-interface/replay_all.py` or the endpoint driver in a frozen tree. Each writes its own root receipt even though it also creates an inner generation worktree. The enclosing driver handles that safely. Copied worktree receipt mtimes intentionally change and are not claimed preserved.

The literal source regenerates39 outputs with28 own commands. Its27 explicit guarded entries reject optimized Python. The two standalone entries `copy/translate_anchor.py` and `copy/program_audit/verify_program_index_bounds.py` have unsupported, untested standalone optimized execution. The endpoint similarly has its own explicit optimization contract. Literal and endpoint science run unoptimized only. The enclosing safety checks work in normal and optimized interpreters; that is not optimized scientific verification. Report38's active library has a separate, supported normal/optimized replay.

Python3.10+ and its standard library suffice for scientific replay. A local pdfLaTeX/TeX Live installation with ordinary article, mathematics, TikZ and Latin Modern packages is needed only for PDF rebuilding. No network or package installation occurs in the release tools.

## External artifact rebuilds and checks

Use a new empty directory outside the release:

    python3 -I -B build_pdf.py --output /external/new-build --check-packaged

Create an external deterministic ZIP, or check a supplied ZIP against a separately obtained digest:

    python3 -I -B archive_release.py --create /external/Research_Report40.zip
    python3 -I -B archive_release.py --check /external/Research_Report40.zip --sha256 HASH --replay

Archive checking compares every member's name, type, mode, length and bytes before safe external extraction. It never blindly uses extractall. Repeat builds have fixed member order, timestamp, compression and PDF metadata settings. Tool/version changes may require a new reproducibility review.

Optional integrity regressions:

    python3 -I -B tamper_regression.py
    python3 -I -B archive_regression.py --archive /external/Research_Report40.zip --sha256 HASH

## Source lineage

Active v2 manifest SHA256:
`e31de0a0a06b917c60071d500b72dd7891cd74bea103e449685c0041c9b0f615`

Canonical v2 ZIP SHA256:
`70a2a87ddb1ab018ec8c795dad56d053f66855a9b47ab7f3a9b64cf1164b852f`

The clean canonical v2 ZIP, rather than an unrestricted source-directory copy, supplied the active evidence. Pre-existing excluded bytecode caches were not packaged. V1's six changed-file originals are stored under `evidence/predecessor/`, and unchanged source data are stored once in the active tree. `verification/source-lineage.json` identifies every old/new hash and exact reconstruction location; `verification/loader-v1-v2.diff` shows the loader fix. The old mutable returned-head alias is documented and no historical predecessor source executes. Both independently frozen external versions were left unchanged.

The release includes all own proof/code/data and derived numerical maps. It includes no third-party complete articles, PDFs, source archives, or article screenshots. Published sources have links/hashes and explicit credit. Neither the dense277193130854400000-cell rectangular tile nor the expanded601547591-row program is materialized; finite exact maps, a terminating row grammar, and symbolic geometry supply the proof.
