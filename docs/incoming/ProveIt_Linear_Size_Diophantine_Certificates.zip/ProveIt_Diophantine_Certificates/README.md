# Linear-Size Canonical Diophantine Certificates

Research article prepared for Vladimir Reshetnikov, September 30, 2026.

## Main result

For every finite zero-initialized memory-access log of length L, the linear
backend constructs one integer polynomial of degree at most four. Its 24L
auxiliary variables range over the natural numbers including zero. A valid log
has exactly one auxiliary witness; an invalid log has none. The polynomial is
the sum of squares of exactly 22L+1 quadratic residuals. The 3L event coordinates
are free parameters, separate from those 24L witnesses.

A carry-free large-base product comparison certifies the complete sorted record
multiset. This is an exact integer identity, not a probabilistic hash. All large
bases and powers are uniquely forced by quadratic equations.

The alternative sorting-network backend uses more coordinates but much smaller
integers. The article proves the complete size–height tradeoff, parsimonious RAM
composition, applications to several computational substrates, exact counting,
and first-halting probability formulas. It includes ten further research topics.

## Files

- `article.pdf`: compiled research article.
- `article.tex`: complete self-contained LaTeX source, including bibliography.
- `code/canonical_memory.py`: common sparse polynomial implementation and
  low-height, bitonic-network memory compiler.
- `code/linear_memory.py`: linear-size, large-base-product memory compiler.
- `code/test_certificates.py`: tests of the low-height backend.
- `code/test_linear_memory.py`: tests of the linear backend.
- `artifacts/example/`: four-event bitonic certificate, assignment, and expanded
  polynomial.
- `artifacts/linear_example/`: the same log under the linear backend.
- `artifacts/*test_results.json`, `artifacts/*test_run.txt`: actual test receipts.
- `SOURCE_PROVENANCE.md`: pinned repository revision and consulted sources.
- `Makefile`: optional build and test convenience commands.

## Run

Python 3.10+ and its standard library are sufficient for the code:

```sh
python3 code/test_certificates.py
python3 code/test_linear_memory.py
python3 code/canonical_memory.py artifacts/example/events.json output_bitonic --expanded
python3 code/linear_memory.py artifacts/example/events.json output_linear --expanded
```

Input format is a JSON list of `[address, write_flag, value]` triples, all natural
numbers. Write flag 1 writes a value; flag 0 asserts a read result. Other write
flags fail the certificate. Memory initially contains zero at every address.

The compiler keeps every event coordinate symbolic. The supplied numeric log
is used to generate a candidate witness, not to specialize away the parameters.
An invalid log still compiles, but its candidate has nonzero residuals and the
reported `violations` list is nonempty. A mathematically valid root for an invalid
log cannot exist by the article's proof.

`certificate.json` gives the domain convention, variable roles, candidate
assignment, quadratic residuals, and a summary. A monomial is the product of its
listed variables; the empty list denotes 1. `polynomial.json` is the expanded
sum of squares. Large values are exact integers, not floating point.

The linear backend deliberately generates large integers. Its scalar size is
linear, not its bit cost. Available memory and Python's default decimal-string
conversion limit can restrict very large exports. For locally generated trusted
examples exceeding that conversion limit, Python 3.11+ supports the environment
setting `PYTHONINTMAXSTRDIGITS=0`; this changes serialization limits, not any
mathematical bound. Do not disable resource safeguards for untrusted input.

Compile the article using standard pdfLaTeX packages:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

With Make installed, `make test`, `make example`, and `make pdf` perform these
steps. The archive already includes a compiled PDF.

## Status and boundaries

The memory compilers are implemented and tested. The accompanying mathematical
proofs establish soundness, completeness, uniqueness, and the resource bounds;
finite tests are not substitutes for those proofs. Complete RAM, combinator,
cellular, and probabilistic language frontends are not implemented here.

This is a horizon-indexed family whose number of variables grows with the
trace length. It does not settle the general finite-fold or single-fold
Diophantine conjectures. It contains no new Lean-checked proof. The consulted
ProveIt documents were inspected at a pinned revision; the repository was not
rebuilt. Sorted-memory verification and sorting networks are prior art, and
literature-wide priority for the new combined formulations is not established.
