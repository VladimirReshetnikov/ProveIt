# K220: a 220-state ZFC consistency machine

This packet constructs an explicit **220-working-state, two-symbol, one-tape
Turing machine** whose blank-tape nonhalting is provably equivalent in ZFC to
`Con(ZFC)`, by composition with the pinned K221 construction's calibration.
The successful reduction preserves the original logical calculus and the
entire primitive program. The report is [report/report.pdf](report/report.pdf);
its editable main source is [report/report.tex](report/report.tex).

The machine uses a two-way infinite tape, blank symbol 0, L/R moves, and a
separate terminal outcome. There are exactly 220 working states and 440 rows.
The canonical labels are 0 through 219, start state 0, dispatcher 22, and halt
label 220. The native table retains the parent labels: start 0, dispatcher 84,
halt 254, and state 202 removed.

## The construction

At source prefix `11101001001101`, two closed reassociations transform

```text
((A,B),(C,D)) -> (A,(B,(C,D))) -> (A,((B,C),D)).
```

The four blocks contain 52, 27, 52, and 243 primitive leaves, respectively.
All four are fully closed: no break, continue, or halt escapes a block.
Their native entries are 147, 90, 149, and 201.

The decisive change is to re-encode a previously nonpure decoder edge.
State 132's old read-one transition moves left, so the earlier pure-pair
rotation restriction excludes it. Directly encoding the new child entries
permits the first reassociation and exposes the second one. The resulting
state 202 can share state 171: the preceding source bit distinguishes their
read-zero branches, and their read-one branches agree. Existing helpers
7, 86, and 205 recover the old branch in three literal transitions, restoring
the whole tape and the old successor head position.

Only five retained rows change relative to the pinned K221 native table:

| State / read | K221 action | K220 action |
| --- | --- | --- |
| 132 / 0 | `0 R 147` | `0 R 171` |
| 132 / 1 | `1 L 163` | `1 R 201` |
| 171 / 0 | `0 R 183` | `0 L 7` |
| 203 / 0 | `0 R 132` | `0 R 147` |
| 203 / 1 | `1 R 202` | `1 R 132` |

Both rows of 202 are deleted. The final count is
`49 + 185 - 14 = 220`: 49 states outside the decoder map, 185 interior source
roles, and 14 extra roles supplied by sharing. The source still has 208
distinct subtrees, 23 primitive types, 4,744 primitive occurrences, maximum
depth 38, and maximum consecutive-zero address run six.

## Proof and verification status

The delivered default offline replay completed with `FULL_K220_REPLAY_PASS`.
It performed all of the following:

1. Authenticated and replayed the complete pinned K221 construction and its
   inherited calibration certificates.
2. Reconstructed the exact two reassociations, the direct decoder encoding,
   and the final contextual fold without a discovery optimizer.
3. Compared the entire opcode/argument word and every guarded ordinal
   successor against the original source.
4. Canonicalized the exact final table and independently simulated its blank
   startup with both sparse-native and dense-canonical tape representations.
5. Freshly rederived **all 6,167 unbounded primitive-interface cases** on the
   final 440-row table, using **1,516,421 symbolic rules**.
6. Independently audited the exact ordered case coverage, positive affine
   durations, provenance, source identity, four unary/list block schemas,
   complete blank frame, and source-prefix fold blocks.

These are symbolic induction proofs over arbitrary natural register values,
gap size, first spare value, and arbitrary finite spare tails. The 6,167 cases
are the finite control cases, including both decrement guards; they are not
6,167 finite numerical samples. Every duration has a strictly positive
constant, with minimum 13. All 440 rows occur in the symbolic usage receipt;
all 220 states are reachable in the raw transition graph. Neither statement
asserts that every row or state is reached on the single blank run.

The exact blank frame is reached after **409,835 transitions**, with native
state 84 / canonical state 22, head -5, logical registers
`[3,0,0,0,3,0,0,0,0]`, header coordinate 176, extra gap 117, and 167 spare
values all equal to one. The complete tape has 351 one cells; every other
cell is zero. Their exact coordinates are in the canonicalization receipt.

The final logical conclusion follows by composing blank halting equivalence
with the pinned K221 calibration. **This work does not supply a newly compiled
Rocq/Lean kernel theorem for the literal K220 table.** Its new endpoint is an
ordinary mathematical proof with executable symbolic certificates, formalizable
in ZFC. It does not assume `Con(ZFC)` to establish the equivalence, and it does
not establish unconditional nonhalting or a global 220-state lower bound.

The fold is contextual: its local tag argument applies to valid source-decoder
entries. Some affected decoder states also have arithmetic uses. The complete
final runtime and exact blank-start certificates cover the required semantics;
no arbitrary-initial-tape quotient claim is made.

## Reproduce offline

Use Python 3.10 or newer with the standard library. Keep assertions enabled
(do not use `-O` or `PYTHONOPTIMIZE`). From the extracted packet directory:

```sh
python3 -B portable/reproduce.py --output-dir /tmp/k220-replay
```

The output directory must initially be empty. No network access, compiler
installation, external clone, or discovery search is required. The entire
pinned K221 packet and its recursive predecessors are retained in
`portable/vendor/K221_Construction_2026-10-20.zip`.

The default command freshly proves the final K220 runtime. It replays the
parents using their authenticated stored runtime certificates while rerunning
their construction/calibration checks. To also rederive the inherited runtime
proofs recursively:

```sh
python3 -B portable/reproduce.py --full-baseline --output-dir /tmp/k220-all
```

For stored final runtime integrity and independent block/coverage/startup checks:

```sh
python3 -B portable/reproduce.py --quick --output-dir /tmp/k220-quick
```

`--quick` does not freshly rederive the final symbolic induction. The stored
`cases.json` contains durations and rule counts, not a full standalone proof
trace. The default command regenerates the proof from the pinned symbolic
checker and literal final table. The successful release replay used the
default mode, not `--quick` or `--full-baseline`.

Build the PDF with a conventional TeX Live installation:

```sh
bash report/build.sh
```

The script regenerates the complete canonical table appendix directly from
`machine/k220.tm` and runs `pdflatex` twice. A rebuilt PDF may differ in metadata
and pagination as TeX versions change; exact machine/source bytes are pinned.

## Files

| Location | Contents |
| --- | --- |
| `machine/k220.tm` | Complete canonical 440-row table |
| `machine/k220.native.tm` | Same machine with inherited native labels |
| `machine/sites220.json` | Complete source tree encoded by ordered leaf paths |
| `machine/canonical_map.json` | Complete label bijection and exact startup support |
| `machine/decoder_allocation.json` | Interior source roles and physical decoder states |
| `portable/` | Authenticated deterministic build and verification programs |
| `portable/reference_results/` | Stored final runtime and guarded-case summaries |
| `verification/` | Intermediate source/tables and successful replay receipts/logs |
| `report/` | Compiled PDF, editable TeX sections, and table generator |
| `research/theory/` | Uniform formalism arguments, countermodels, independent source audit |
| `research/encoding/` | Portable finite searches and exact rejected-patch counterexamples |

Each noncomment machine row has five whitespace-separated fields:
`state read_bit write_bit L_or_R next_state`. `#! start 0` identifies the start.
The halt label has no transition rows. The full table is also printed in the
PDF appendix.

The research supplements distinguish proved transformations, failed logical
recoveries, source-only measurements, and open equiconsistency questions.
None changes the logical theory of the accepted K220 candidate. In particular,
an alternative T-based 220-state layout is not presented as a calibrated
candidate, and the two rejected state-deletion patches in the encoding
supplement must not be substituted for the accepted table.

## Exact identities and provenance

Inspected ProveIt revision:
`c011e44bc2df6238940bb600833730873b308334`.
The immediate parent is the new complete archive in `docs/incoming/` at that
revision, not an older tracked candidate directory.

| Artifact | SHA-256 |
| --- | --- |
| Pinned K221 archive | `a06c99b775193d9642a2734b7dd5fe7b72736fbdf9d9d8be438321d5e5d57ba4` |
| K220 canonical table | `f80c57e800d4f999d9b4902a8e96bd36d1b6180b3ad322ca8ed0ab67b47f2a5f` |
| K220 native table | `4466ec4f947a9c5112397c30ca25b0e70e3ac39ee54878b3e4493a0297d732e4` |
| K220 source | `837e92d7b1c107330f160f654f6c36ff0b03dfbf6bc2b89c6f782eb7db4c4ce7` |
| Final guarded cases | `6c2b15b8e3f7b35f3eb37f87510ba3c51a11b9703d42f995f6a695381e12e381` |

`MANIFEST.sha256` covers all delivered files except itself. The portable replay
also enforces its own exact file inventory. Runtime receipt elapsed times and
Python version fields can vary while the machine, source, and guarded-case
bytes remain identical. See [ATTRIBUTION.md](ATTRIBUTION.md) for prior work and
retained license notices.
