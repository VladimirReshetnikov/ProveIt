# Fixed-radius Bohr invariance in Gowers's Szemerédi argument

A self-contained research article prepared for Vladimir Reshetnikov, dated
6 October 2026. Mathematical development and exact checks with ChatGPT.

## Main results

For a rectangular Bohr set B with r listed characters and widths 0 < rho_i <= 1/4,
if ||chi_i(d)|| <= rho_i/(2m) for a positive integer m, then

    2m (|B| - |B ∩ (B+d)|)
        <= |B(rho + m v)| - |B|
        <= |B(3 rho/2)| - |B|
        <= (3^r - 1)|B|,

where v_i = ||chi_i(d)||. The input set B is not replaced by a regular-radius
set. The intrinsic first bound is exactly sharp for rank-one intervals.

At density 7/8 in B, the corrected radius rho^r/(2^(r+4) r) in Gowers's
Corollary 10.11 can, on 0 < rho <= 1/4, be replaced by:

* rho/[8(3^r-1)], preserving the original overlap margins; or
* rho/(6*3^r-4), for the extension conclusion with recalculated margins.

The article also proves an order-k extension with budget
(2k-1) kappa + 2k eta < 1, a finite-fibre compatibility lemma with exact
exception budgets (including sqrt(theta) < 5/14 under its stated hypotheses),
and explicit cyclic counterexamples ruling out universal polynomial-rank
translation constants. The obstruction is for composite cyclic groups;
the prime-order case remains a research question.

## Status and limits

The article contains full mathematical proofs. It is unrefereed, and no new
Lean proof was compiled or kernel checked. The code is a deterministic exact
finite diagnostic suite, not a proof assistant. No claim is made of an improved
global Szemerédi bound, optimal combined exponential base, or literature priority.
The source audit was targeted and did not read every pending research manuscript.

## Files

- `article.tex`, `article.pdf`: the article, including 12 research questions.
- `code/verify.py`: standard-library-only exact verification code.
- `results/verification.json`: exact output, including explicit CRT parameters.
- `results/check_stdout.txt`: short check summary.
- `results/build_validation.json`: build and render validation record.
- `SOURCE_AUDIT.md`: source locations, pin, blob IDs, and comparison limitations.
- `FORMALIZATION.md`: proposed proof obligations and dependency order.
- `Makefile`: portable build and check targets.

## Build and check

Python 3.10+ and a standard TeX Live or MiKTeX installation are sufficient.
The Python checks use only integers and `fractions.Fraction`, and do not use
assert statements. `python -O` therefore does not suppress the tests.

```sh
python3 code/verify.py --output results/verification.json
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Or run `make check` and `make pdf`. The last full check run took approximately
12 seconds in the preparation environment; this is not a hardware-independent
performance guarantee. The test output itself excludes timing information.

The LaTeX bibliography is embedded. No third-party PDF, repository snapshot,
font file, or external figure is needed or redistributed.

## Proposed repository placement

Create a separate directory, for example:

    Combinatorics/Ramsey/Research/GowersSzemeredi/fixed-radius-bohr-invariance/

Preserve the directory layout so the script's default result path continues
to work. Do not overwrite the existing local-quantitative-refinements article,
change the proof-status ledger, or describe these results as formalized merely
because the research package has been added. This delivery did not mutate the
repository.
