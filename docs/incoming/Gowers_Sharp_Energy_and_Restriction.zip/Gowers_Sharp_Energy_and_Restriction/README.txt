SHARP ENERGY GAPS AND EFFICIENT RESTRICTION
Coset rigidity, puncture stability, and Fourier-filter bounds
in Gowers' Szemeredi framework

Research contribution prepared for Vladimir Reshetnikov / ProveIt.
Mathematical derivation and manuscript assisted by OpenAI ChatGPT.
7 October 2026

START HERE

Read gowers_sharp_energy_restriction.pdf. Its complete mathematical text
and bibliography are in gowers_sharp_energy_restriction.tex. The package
also supplies the modular authoring source main.tex and sections/*.tex,
exact finite checks, their recorded outputs, and an integration guide.

The article proves local mathematical strengthenings and answers specific
questions in the inspected ProveIt research sequence. It does not claim
a new global Szemeredi bound, an optimum finite restriction exponent, or
literature-wide priority. The manuscript has full written proofs and
supplementary computational checks; it has not been externally refereed
or verified in Lean. Finite enumeration is evidence about the enumerated
examples, not a substitute for the universal proofs.

MAIN RESULTS

1. Sharp energy gap and overlap spectrum.
   For every nonempty finite A in any abelian group, m=|A|, and every d,

       m*r_A(d)*(m-r_A(d)) <= m^3-E(A).

   The coefficient one is sharp. An exact mixed-set remainder, a
   multilevel refinement from attained overlap values, all set equality
   cases, and a bounded-weight extension using minimum overlap are proved.
   Labels: thm:pointwise, prop:mixed, thm:multilevel,
           thm:pointwise-equality, prop:weighted.

2. Optimal coset existence and uniqueness thresholds.
   Put epsilon=1-E(A)/m^3 and tau(u)=(1-sqrt(1-4u))/2. For epsilon<=1/4,
   H={d:r_A(d)>m/2} is a finite subgroup, and each most occupied H-coset C
   satisfies |A symmetric_difference C|/m <= tau(epsilon).
   The existence/closure threshold 1/4 is optimal even in finite cyclic
   groups. The canonical C is unique for epsilon<1/4; uniqueness among
   closest cosets with arbitrary underlying subgroup has the separate,
   optimal threshold epsilon<2/9. All canonical-envelope equality cases
   are classified.
   Labels: thm:coset, cor:unique, thm:coset-equality,
           prop:threshold-sharp.

3. Sharp puncture repair, including the inner endpoint.
   For epsilon<1/4 use the canonical outer C and put
   delta=|A symmetric_difference C|/m>0,
   eta=epsilon-delta*(1-delta). If s=eta/delta^3<=1/4, then

       min_D |A symmetric_difference (C\D)|/m <= delta*tau(s),

   where D is a nonempty proper subgroup coset inside C. A nearly
   saturated translation, with gap
   theta_d=epsilon-(r_A(d)/m)*(1-r_A(d)/m), gives the same profile with
   theta_d in place of eta, and every minimizing hole has an underlying
   subgroup that excludes d. Equality cases and the exact leading
   constant one are proved. The inner endpoint 1/4 is included in a
   separate proposition; the outer hypothesis epsilon<1/4 must remain
   strict. Hole uniqueness holds below the inner defect 2/9.
   Labels: thm:puncture, thm:puncture-equality, thm:oriented-puncture,
           prop:puncture-sharpness, prop:puncture-endpoint.

4. A fully certified all-cyclic exponent 53.
   Let B be a subset of a finite cyclic group, b=|B|, and let phi map B
   into any abelian group. T_16 counts ordered additive sixteen-tuples,
   including repetitions; G_16 counts those also respected by phi.
   If G_16(B,phi)>=alpha*b^15, 0<alpha,eta<=1, and

       b >= (4/(alpha*eta))^53,

   one subset B' satisfies

       T_16(B') >= (alpha*eta/4)^53*b^15,
       G_16(B',phi) >= (1-eta)*T_16(B').

   A degree-twelve rational filter and exact integer inequalities improve
   source 58's common exponent 54. The underlying all-cyclic expectation
   theorem is explicitly credited to source 58 and reproved. A stronger
   asymmetric size/retention estimate is also stated. The new filter has
   principal cost approximately 51.44505 and certifiably below 52; no
   optimality of that value or of exponent 53 is asserted.
   Labels: rf:thm:expectation, rf:thm:selection, ff:prop:certificates,
           ff:thm:53, ff:cor:asymmetric, prop:moment-interface.

5. Uniform arity/order bounds for the principal filter cost.
   For integers m,a>=2, optimize -log(P_m)/log(P_m/Q_{m,a}) over finite
   even filters 0<=K<=1, K(0)=1, with nonnegative Fourier coefficients.
   The article gives explicit upper and lower bounds uniform in both m
   and a. In particular, a=m^(c+o(1)), c>0, implies

       I_{m,a}/m -> 1+1/(2c).

   If log(a)/log(m) tends to infinity, the limit is one. For fixed a,
   the error in the leading m*log(m)/(2*log(a)) asymptotic improves to
   O_a(m*(1+log(log(log(m))))). For fixed m, I_{m,a} tends to m-1 as a
   tends to infinity. The lower bound applies to the specified principal
   certificate, including independent heterogeneous layers. It does not
   rule out improvements from other selection methods or from additional
   information about the particular input.
   Labels: uf:thm:uniform, uf:prop:concentration, uf:cor:regimes.

The article ends with twelve further research questions and a proposed
formalization order. INTEGRATION.txt identifies which earlier questions
are answered, which are only advanced, and which remain open.

PACKAGE CONTENTS

gowers_sharp_energy_restriction.tex   Complete standalone article source
gowers_sharp_energy_restriction.pdf   Compiled article
main.tex, sections/*.tex             Modular authoring source
README.txt                          This guide
INTEGRATION.txt                     Placement, labels, and claim boundaries
Makefile                            PDF and verification targets
code/build_standalone.py            Regenerate the complete standalone TeX
code/verify_energy.py               Exact finite set/mixed/weighted checks
code/verify_punctures.py             Exact cyclic puncture/orientation checks
code/verify_filter.py               Exact integer filter certificates
code/make_figure.py                 Optional overview-figure generator
figs/overview.pdf                   Supplied vector overview figure
data/energy_checks.json             Recorded set and mixed-check results
data/weighted_energy_checks.json    Recorded rational-weight results
data/puncture_checks.json           Recorded puncture-check results
data/filter_checks.json             Recorded filter certificates/diagnostics
data/source_manifest.json           Source pins, scope, and contribution map
MANIFEST.sha256                     Package-file checksums

Additional validation records may be included. Third-party papers and
previous research archives are cited, not redistributed in this package.

BUILD THE PDF

Run from this directory:

  make pdf

Equivalently:

  pdflatex -interaction=nonstopmode -halt-on-error -file-line-error \
    gowers_sharp_energy_restriction.tex
  pdflatex -interaction=nonstopmode -halt-on-error -file-line-error \
    gowers_sharp_energy_restriction.tex
  pdflatex -interaction=nonstopmode -halt-on-error -file-line-error \
    gowers_sharp_energy_restriction.tex

Three passes stabilize the contents and references from a clean directory.

A conventional TeX Live or MiKTeX installation with the packages in the
preamble is sufficient. The bibliography is embedded. PDF compilation
does not require BibTeX, Python, a package installation command, a network
connection, or regeneration of the supplied figure.

To build the modular source instead, run "make modular"; it writes
main.pdf. The standalone and modular sources describe the same release.
After editing main.tex or sections/*.tex, regenerate the standalone text
and then rebuild its PDF:

  make standalone
  make pdf

The first command runs "python3 code/build_standalone.py" with no
arguments. It expands the section inputs into
gowers_sharp_energy_restriction.tex using only the Python standard
library. The existing standalone source can still be compiled without
Python. The "pdf" and "modular" targets do not regenerate that source
automatically.

"make clean" removes TeX auxiliary files and incomplete temporary JSON
outputs. It preserves the article PDFs, source files, and final data.

REPRODUCE THE EXACT CHECKS

Requirements: Python 3.10 or later; Python standard library only.

  make check

Individual targets:

  make check-energy
  make check-weights
  make check-punctures
  make check-filter

The corresponding direct commands are:

  python3 code/verify_energy.py
  python3 code/verify_energy.py --weights-only
  python3 code/verify_punctures.py > data/puncture_checks.json
  python3 code/verify_filter.py > data/filter_checks.json

Run ordinary Python without -O: the puncture suite uses assertions.
The filter checker uses explicit integer comparisons and also works with
assertion optimization enabled. Its floating-point diagnostics are
separated from the exact acceptance checks and do not certify them.

The energy script accepts --max-cyclic 2..16 and --output PATH; by default
it enumerates cyclic orders 2..16 and eight specified noncyclic groups,
and writes its JSON to this package's data directory. The separate
--weights-only suite checks rational weights in {0,1/2,1}. The puncture
script has no command-line options and prints one JSON summary. Full
finite enumeration can take several minutes; the filter certificate is
small. Timings in the energy reports are machine-dependent.

The optional "make figure" target regenerates the overview using the
installed plotting dependencies imported by code/make_figure.py. It is
not part of either "make pdf" or "make check".

SOURCE STATE AND STATUS

Repository: https://github.com/VladimirReshetnikov/ProveIt
Current-tree comparison pin:
  0d93c1eac2e20c313e7ed0cb7cb74ff705b00101

At this pin, the consolidated report includes sources 01--39. Sources
40--59 are separately placed material. The comparison is targeted:
relevant consolidated sections and later records were read, and the
full manuscripts for sources 45, 58, and 59 were recovered from historical
incoming archives. It is not an audit of every theorem in all 59 sources.
The current comparison pin and the archive retrieval pins are distinct;
data/source_manifest.json records both.

The package reserves no new source number. Integrate it using the normal
repository intake convention. No new Lean theorem is included or claimed
compiled, and no proof-status ledger should be changed on the strength
of this research package alone.
