COUNTABLE GLOBAL CHOICE AND SURREAL CODING OVER ZERMELO SET THEORY
A localized nonconservativity theorem and exact rank-model spectra

Prepared for Vladimir Reshetnikov, 4 October 2026.

CONTENTS

global_choice_surreal_coding.pdf  Complete research article.
global_choice_surreal_coding.tex  Self-contained LaTeX source, including references.
README.txt                      This file.

MAIN RESULTS

1. Global selection from nonempty at-most-countable sets, with Separation
   expanded to mention the selector, is nonconservative over Zermelo set theory
   with Choice. The result holds with or without Foundation. Selection only
   from countably infinite sets also suffices. This is a derived refinement of
   Elliot Glazer's published countermodel theorem.

2. A bounded uniformization theorem converts selection on D-small sets into
   uniform injections into a fixed well-ordered D, without Replacement or
   ordinal collapse. A trace-compression theorem supplies the link to Glazer's
   obstruction.

3. In the full-class rank models (V_lambda, P(V_lambda)), exact thresholds
   distinguish global choice, ordinal sign enumeration, birthday-monotone
   enumeration, universal set coding, ordinal abstraction, and Class Replacement.

4. Class Replacement on a particular internal set a holds exactly when the
   external cardinality of a is less than cf(lambda). The external cardinal
   spectrum of internal proper classes is also determined.

The article contains all additional proofs, explicit separation examples, twelve
further research questions, an axiom ledger, and a source audit. The published
Glazer countermodel is an explicitly cited input; it is not reconstructed here.
The article makes no claim of machine-checked proof or established priority for
every formulation.

BUILD

Use a standard TeX Live or MiKTeX installation containing the packages listed in
the source. No external images, bibliography databases, downloads, or shell
escape are needed.

    latexmk -pdf -interaction=nonstopmode -halt-on-error \
      global_choice_surreal_coding.tex

Alternatively run pdflatex three times to settle the cross-references and table
of contents. The supplied PDF was built with pdfTeX and checked for unresolved
references and layout warnings, and its rendered pages were visually reviewed.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Inspected commit: 2b7b388ba81a3355b19a7c2d2fe797e92f572355
Main source path:
Algebra/SurrealNumbers/docs/foundations-and-computation/surreal-well-orders/article.tex

No repository files were modified.
