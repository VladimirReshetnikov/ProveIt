# Report 124 Logarithmic DSASM asymptotics

This is the standalone proof and exact finite reproducibility package for
A005163, the number a_n of diagonally symmetric alternating sign matrices.

Main proved conclusion, along all positive integer sizes:

    log a_n = alpha n^2 + beta n - (5/72) log n + O(1)
    alpha = (1/2) log(3 sqrt(3)/4), beta = (1/4) log 3

Equivalently, the normalized counts are bounded above and bounded away from
zero at the conjectured full exponential and logarithmic shape. The report
also proves a bounded holomorphic fugacity-pressure error, every fixed diagonal
cumulant with O(1) error, explicitly centered central limit theorems, the first
calibration trace (n+1)(1-sqrt(3)/2)+o(1), and a correctly rounded inverse
threshold bracket including its logarithmic correction.

No limiting DSASM amplitude, convergence of a centered determinant or count,
matching parity amplitudes, full asymptotic equivalent, correction transseries,
or effective numerical inverse threshold is claimed. The constants in the
asymptotic bounds are not computed.

## Read and build

- report124.pdf is the reader-facing report
- report124.tex is its complete editable source
- build.py performs three TeX passes in each of two clean temporary directories,
  rejects overfull boxes and unresolved references/citations, requires the two
  PDFs to be byte-identical, and writes report124.pdf
- build-environment.txt identifies the tested toolchain and metadata settings
- verification_results.json records the finite-check, build and full-page review results
- checks/ is an independently implemented, standard-library exact companion
  with its own closed fixture inventory and detailed scope documentation

The report is self-contained from its explicitly cited published inputs.
No earlier report, downloaded paper, network connection or pre-existing
cache is required to compile it or run the finite checks. Classical input
identities and the precise uniform Jacobi asymptotic estimates remain cited
mathematical inputs, rather than computationally certified theorems.

Python 3.10 or later is required. PDF compilation additionally requires pdfTeX,
pdflatex, and the standard TeX packages listed in the source. The tested setup
uses TeX Live with Latin Modern and Poppler for rendering. Bytewise PDF replay
is a same-toolchain guarantee, not a promise across TeX distributions.

From this package directory:

    python -B integrity.py
    python -B checks/verify.py
    python -B -O checks/verify.py
    python -B checks/negative_tests.py
    python -B test_integrity.py
    python -B build.py
    python -B replay.py

The comprehensive replay verifies the sealed source inventory before and after,
copies the package into an isolated temporary directory, runs normal and
optimized exact checks, runs both negative-test runners normally and under -O,
rebuilds the PDF twice, and verifies all copied bytes remain identical. It then
creates two identical ZIPs and checks the closed ZIP inventory, CRC and
byte-for-byte extracted roundtrip. Its JSON goes to stdout; redirect it outside
the package. The final source-tree comparison also verifies immutability.

To create the deterministic archive at a path outside this directory:

    python -B repack.py ../report124_bundle.zip

The archive has a single report124/ root. Fixed ZIP timestamps, sorted members,
compression settings and POSIX file attributes are used. ZIP byte equality is
also a same-Python/zlib-toolchain guarantee.

## Integrity and deliberately failing controls

CHECKSUMS.sha256 covers every package file except itself, including the complete
checks/inventory.json. integrity.py requires the exact closed file and directory
inventory; extra files, empty directories, links, missing files, malformed
paths and byte changes fail. It supplies explicit guards rather than removable
assertions. test_integrity.py exercises 14 named mutations in both interpreter
modes and requires the designated diagnostics. The checks/ campaign has its own
more detailed schema, algebra and fixture mutations and exact failure contracts.

The companion campaign has 43 selected mutation definitions, 86 expected failures
(normal and optimized), and two identical unmutated positive baselines. All
mutations run in external temporary copies. Mathematical/schema mutations are
resealed to reach the intended mathematical or schema guard instead of merely
tripping an incidental checksum error. See checks/README.md for all ranges,
independent routes and historical fixture provenance.

Finite exact checks are not proofs of all-size analytic bounds. In particular,
they do not certify endpoint Bessel remainders, trace-class or Hilbert-Schmidt
membership, strong convergence, Fredholm nonvanishing, or limiting amplitudes.
Those conclusions, at their stated scope, depend on the report's proofs.

These inventories detect accidental corruption and selected malformed cases.
They are not signatures and cannot resist coordinated replacement of files and
their checking code. To intentionally edit the report, rebuild and then run
integrity.py --write to create a new outer inventory. Changes inside checks/
also require its own independently maintained inventory to be updated; an
outer rehash alone does not make such a change pass its verifier.

## Attribution

Behrend, Fischer and Koutschan, arXiv:2309.08446v3 (1 October 2026), provide the
DSASM determinant, six-vertex model, and Conjecture 11.1. Classical stability
inputs are from Borcea and Branden; determinant and orthogonal-polynomial inputs
are from Krattenthaler and Rosengren; uniform Jacobi analysis is from Frenzen and
Wong and the NIST DLMF; trace-ideal determinant facts are from Simon. Exact
locations and links are in the report bibliography. No global priority claim
is made by this package.
