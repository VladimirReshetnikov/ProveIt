# Ternary Airy research package

2 October 2026. No external publication or edits to earlier delivered packages.

## Current results

1. Positive limiting amplitude for relaxed ternary trees: proved and independently reviewed. See `amplitude-proof-candidate.md` (filename retained for traceability) and `independent-gap-audit/leading-amplitude-verdict.md`.
2. Positive limiting amplitude for minimal DFAs accepting finite ternary languages: transfer proved and independently reviewed, using the relaxed theorem, positive completed-run comparison, and a repaired uniform high-path bound. See `dfa-ratio-transfer.md` and `dfa-transfer-audit/`.
3. Full finite-order expansion for relaxed ternary trees: proved and independently reviewed in `all-orders-reduction.md` and `all-orders-audit/audit.md`. This does not claim a full DFA expansion.

Writing a_1 for the first negative Airy zero, the leading statements are

 R_n ~ C_R (n!)²(27/4)^n exp(3·3^(1/3)a_1 n^(1/3))n^(5/3),
 B_n ~ C_B (n!)²(27/2)^n exp(3·3^(1/3)a_1 n^(1/3))n^(5/3),

with C_R,C_B>0. Also B_n/(2^(n−1)R_n)→ρ∈[P_3,1], so C_B=ρ C_R/2, where P_3=(2sqrt(2)/π)sin(π/sqrt(2)).

The main new device is the exact fixed weight

 ω(j)=[j+4/3+(1/6)(−1/2)^j]/(j+1),

in which the critical transfer and its weighted adjoint have the same boundary harmonic profile j+1. The singular Airy gap is proved on one residue channel, never on the full direct sum of three phases. Explicit evolving Airy profiles have forward residual O(i^−4/3) and adjoint residual O(i^−1), which suffice for endpoint amplitude extraction.

## Reproducibility

- `exact_blocks.py` / `exact-block-checks.json`: rational physical three-step transfer checks
- `audit/verify_frozen_ternary.py`: independent exact frozen-boundary, radial-energy, and moving-deficit checks
- `check_quasimode.py` / `quasimode-checks.json`: floating diagnostic of residual orders, explicitly not a proof
- `formal_recursion.py` / `formal-recursion-checks.json`: exact formal polynomial–Airy recursion through scalar order 6, explicitly not a replacement for analytic remainder estimates
- `repaired-high-path-tail.md`: root's general-arity derivation repairing the printed false bound U≤q; the DFA note contains a complete ternary specialization

The primary 2024 paper supplies the original recurrence and relaxed Theta theorem, not these amplitude statements. No universal novelty or exhaustive literature claim is made here.
