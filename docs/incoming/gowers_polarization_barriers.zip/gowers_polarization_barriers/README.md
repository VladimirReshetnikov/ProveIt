# Sharp Cubical Correlation and Characteristic Barriers in Gowers' Polarization Step

Research package prepared for the ProveIt Ramsey project, 6 October 2026.

## Main mathematical result

For a symmetric trilinear form T on a finite-dimensional F_2-vector space,
let C_T(a,b) = T(a,a,b) + T(a,b,b), and let r be the rank of this alternating
bilinear form. The exact norm of the eight-function T-twisted cubic average,
with all functions bounded in modulus by one, is 2^(-r/2). An extremizer can
be chosen with all eight functions equal to one eighth-root nonclassical
cubic phase. The article gives the full proof and an explicit construction.

Consequences include an exact cube-identity agreement threshold, a spectral
stability identity, and a strengthening of Tidor's symmetric seven-function
restriction proposition: codimension at most 2 log_2(1/delta), instead of
the published 8 log_2(1/delta). The seven-function estimate itself is not
claimed sharp. The paper also classifies exact integration of all
trace-multiplication tensors, computes maximal first-obstruction-degree
integrable subspaces, determines elementary symmetric repair costs, and
provides optimal-order scalar phase-valued polarization in every characteristic.

## Files

- `article.pdf`: the compiled 23-page research article.
- `article.tex`: complete standalone LaTeX source, with embedded bibliography.
- `verify.py`: exact, deterministic finite checks; Python 3.10+ standard library.
- `validation.json`: machine-readable output of those checks.
- `SOURCE_AUDIT.md`: sources, repository blob identifiers, attribution and scope.
- `FORMALIZATION.md`: proposed Lean statement/dependency roadmap, not Lean code.
- `Makefile`: PDF build, verification, and cleanup commands.
- `SHA256SUMS`: hashes of the packaged substantive files, excluding itself.

## Build and verify

To compile, install a LaTeX distribution with pdfLaTeX and the ordinary packages
used in `article.tex`, then run:

```sh
make pdf
```

The bibliography is embedded; no BibTeX, network access, or external assets are
needed. To regenerate the finite-check report:

```sh
python3 verify.py --output validation.json
```

Do not use Python's `-O` / `-OO` options: the verifier intentionally uses
assertions. The script raises an exception if a check fails. Its output contains
`"status": "PASS"` only after completing all check families. A deterministic
seed (172917) is used for the explicitly identified sampled cases.

## Proof and novelty boundaries

The general nonclassical integration criterion is prior work of Tao–Ziegler
and Tidor. Quadratic Fourier analysis, alternating-form decomposition, and
Gowers–Cauchy–Schwarz are established tools, credited in the article.

The universal claims are proved in the article; finite checks are supplementary,
not their proof. No Lean kernel verification or formalized theorem is supplied.
No improvement of a global Szemerédi bound, proof of a general inverse theorem,
or exhaustive first-publication priority is claimed. The source audit explicitly
flags relevant 2026 work that was not exhaustively compared. The main cubical
bound is sharp; the ordinary slice-rank repair bounds and the seven-function
bound are not claimed sharp in general.

## Suggested repository integration

Suggested new directory:

`Combinatorics/Ramsey/Research/GowersSzemeredi/sharp-cubical-polarization/`

This is a suggestion only. The package does not alter any repository file.
The provided source audit can be retained to distinguish this material from
existing local quantitative-refinement notes. Neither the displayed blob hashes
nor the package date should be interpreted as a repository commit pin.
