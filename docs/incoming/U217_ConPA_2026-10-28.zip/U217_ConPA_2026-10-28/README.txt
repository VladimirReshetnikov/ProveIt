U217: a one-transition reduction of the primary U218 candidate
============================================================
Prepared for Vladimir Reshetnikov, 28 October 2026, with AI assistance.

RESULT
------
The exact machine has 217 working states, 434 binary transitions, one
two-way infinite tape, one head, blank symbol 0, and only L/R moves.
Initialization is included. The dense machine starts at state 0 with the
head at position 0 on an all-zero tape; working states are 0..216 and the
separate halt is 217. In the native comparison table the halt is 254.

The construction changes precisely one retained native transition:

    old: 172 0 0 L 112
    new: 172 0 0 L 134

Delete both outgoing rows of native state 112. Every other surviving
native row is unchanged. Native labels are historical names, so native
state 218 remains a working state and is not the halt.

NEW THEOREM
-----------
Ordinary finite-computation reasoning formalizable in PA establishes

    PA |- Halt(U217, blank) <-> Halt(U218, blank).

The sole old predecessor of 112 writes 0 and moves left. Thus at old
state 112 the right neighbor is 0. Three exact local path comparisons
against existing state 134 preserve the complete tape, head and endpoint.
Their positive lengths justify both directions of finite halting by
induction. This local theorem does not depend on any compiler or theory.

Composing with the supplied ordinary U218 correctness theorem gives

    PA |- Nonhalt(U217) <-> Con(U) <-> Con(PA).

The Con(PA) endpoint retains U218's proof status and dependencies. This
package does not supply a newly compiled Lean/Rocq/MM0 certificate of the
full arithmetic endpoint. The separate checked K215 theorem concerns its
own literal ZFC machine. Neither unconditional Con(PA), actual nonhalting,
absolute minimality, nor discovery priority is claimed.

START HERE
----------
paper/report.pdf                 Full report, proof, research questions, table.
paper/report.tex                 Editable LaTeX source.
paper/transition_table.tex        All 217 dense rows (434 actions).
machine/u217.tm                  Dense transition machine.
machine/u217.native.tm           Same machine in inherited native labels.
machine/u217_state_map.json       Native-to-dense bijection.
machine/sites.json               Exact unchanged 202-subtree source.
code/check_reduction.py          Deterministic fold and short-block checker.
code/check_independent.py        Independent longer-block proof checker.
code/check_bootstrap.py          Independent whole-tape startup and census.
evidence/                       Proof receipts and full runtime records.
inputs/U218_ConPA_2026-10-28.zip   Complete unmodified parent dependency.
research/                       Independent proofs, theory review and search notes.
PROVENANCE.json                  Source snapshot, hashes and proof boundaries.
NOTICE.txt, licenses/            Attribution and inherited terms.
SHA256SUMS                       Complete sealed-file inventory.

Table rows have the format

    state  read_symbol  write_symbol  direction  next_state

Directions are L or R. There are no outgoing rows for the separate halt.

REPRODUCE OFFLINE
----------------
Python 3.10 or later, standard library only; no network or solver:

    python3 -B reproduce.py
    python3 -B reproduce.py --full
    python3 -B reproduce.py --full --report /chosen/path/replay.json

The default checks all release hashes, reconstructs the fold, checks both
local proofs and 22 mutation controls, audits complete saved case coverage,
verifies the dense bijection, and replays the entire blank startup.
--full also replays the inherited U218 source/compilation audit and rederives
every arbitrary-register U217 runtime case from the literal table. It
compares all case records, traversal schemas and the entire startup trace.
Allow a few minutes. Do not use -O or PYTHONOPTIMIZE with --full, because
the inherited symbolic runtime uses assertions. The new finite proof
checkers use explicit checks and also work under -O.

Verification work is temporary. An explicitly requested --report path is
the only persistent verification output. The compressed JSON evidence can
be inspected using Python's gzip module or a normal gzip reader.

VERIFICATION COMPLETED
----------------------
- Fresh full U218 baseline replay: PASS.
- Two independent local proof checkers: PASS.
- Eleven mutation controls per checker, 22 total: all rejected.
- Independent native/dense census and bijection: 217 states / 434 rows.
- All 217 working states reachable in the directed transition graph.
- Fresh U217 symbolic runtime: 5,060 / 5,060 guarded cases across 3,891 sites.
- Four unary-block/list-traversal schemas rederived from the exact table.
- Entire blank startup: 95,726 steps, exact same initialized tape as U218.

The symbolic contracts quantify arbitrary natural primary registers,
arbitrary natural gap, and a nonempty arbitrary finite spare list with an
arbitrary tail. They use unary and list induction, not bounded register
sampling. They remain executable mathematical checks outside a proof
assistant's kernel.

Startup reaches native state 84, head -8, header 57, gap 1, logical registers
(4,0,0,0,0,0,0,0,0), forty unit spares, 95 one-cells, and a zero exterior.
The startup never visits old state 112. General runtime does use that
state's behavior: 251 symbolic cases change duration after the reduction.

CLOCK RELATION
--------------
For matched terminating runs, if N0 and N1 count old visits to state 112
reading 0 and 1, then

    T_new = T_old + 2*N0 - 2*N1,
    (3/5)*T_old <= T_new <= (3/2)*T_old.

Of 5,060 guarded primitive cases, 4,809 have unchanged duration, 216 become
shorter, and 35 become longer. These case counts are not a workload-weighted
claim that the complete proof search is faster.

DOCUMENT BUILD
--------------
Requires a normal pdfLaTeX installation:

    python3 -B code/build_paper_data.py
    cd paper
    pdflatex -interaction=nonstopmode -halt-on-error report.tex
    pdflatex -interaction=nonstopmode -halt-on-error report.tex

Rebuilding or editing release files changes their manifest hashes. Use a
copy for edits. PDF bytes can vary with TeX versions and timestamps.

IDENTITIES (SHA-256)
--------------------
Native U217:
fe7b6d449b6b9a57d562b4e6f3ec0a77b27a4b72ccfc41775d57a3e550302d0f
Dense U217:
639da240bdb466f2a50ed40e36355a5677b6ecaaf5ef95e2e5309f4682b55be6
Unchanged source:
bc70b28ff4628db5b9b0c9bd87f560697223e4887f2568b0ece801906713db8f

The primary result is the one-edge U217 table. Bounded follow-up searches
did not establish a smaller machine; their failures are not lower bounds.
