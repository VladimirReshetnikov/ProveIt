#!/usr/bin/env python3
"""Offline reconstruction and proof checks for the exact U217 release.

Python 3.10+ and the standard library suffice. --full also rederives every
arbitrary-register runtime case using the pinned inherited symbolic checker.
No solver, network, proof assistant, or repository checkout is required.
"""
from pathlib import Path, PurePosixPath
import argparse, gzip, hashlib, json, os, stat, subprocess, sys, tempfile, time, zipfile

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'code'))
import check_reduction as reduction
import check_independent as independent
import check_bootstrap as bootstrap

OLD_SHA = '366cf96800bd4299de831355a80092394462278f0b62db1e19c167ca5f8b2a30'
NEW_SHA = 'fe7b6d449b6b9a57d562b4e6f3ec0a77b27a4b72ccfc41775d57a3e550302d0f'
DENSE_SHA = '639da240bdb466f2a50ed40e36355a5677b6ecaaf5ef95e2e5309f4682b55be6'
SOURCE_SHA = 'bc70b28ff4628db5b9b0c9bd87f560697223e4887f2568b0ece801906713db8f'
ARCHIVE_SHA = '73c7d0774d955c9b003eec0e9e0876e280f028f653a127c7518d132b914c8bc9'
PARENT_SHA = 'd23e80857214900f8e0806f03f6df752af501dd0108eb92c6ed7a49795802652'

def need(condition, why):
    if not condition:
        raise RuntimeError(why)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)

def manifest_check():
    seen = set()
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = PurePosixPath(name)
        need(not path.is_absolute() and '..' not in path.parts and '\\' not in name, 'Unsafe manifest path')
        need(name not in seen, 'Duplicate manifest path')
        seen.add(name)
        need(sha(ROOT / name) == digest, 'Digest mismatch: ' + name)
    principal = {'reproduce.py', 'code/check_reduction.py', 'code/check_independent.py',
                 'code/check_bootstrap.py', 'machine/u217.tm', 'machine/u217.native.tm',
                 'machine/sites.json', 'inputs/u218.native.tm', 'inputs/U218_ConPA_2026-10-28.zip',
                 'paper/report.tex', 'paper/report.pdf'}
    need(principal <= seen, 'Manifest omits principal artifact')
    return len(seen)

def extract(archive, destination, expected_root):
    seen = set()
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            name = info.filename
            rel = PurePosixPath(name)
            need(rel.parts and not rel.is_absolute() and '..' not in rel.parts and '\\' not in name, 'Unsafe ZIP path')
            need(rel.parts[0] == expected_root and name not in seen, 'Wrong or duplicate ZIP member')
            need(not stat.S_ISLNK((info.external_attr >> 16) & 0xffff), 'ZIP symlink')
            seen.add(name)
            out = destination.joinpath(*rel.parts)
            if info.is_dir():
                out.mkdir(parents=True, exist_ok=True)
            else:
                out.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src, out.open('wb') as dst:
                    while True:
                        chunk = src.read(1024 * 1024)
                        if not chunk:
                            break
                        dst.write(chunk)
    return destination / expected_root

def command(args, cwd):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    result = subprocess.run([sys.executable, '-B', *map(str, args)], cwd=cwd, env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if result.returncode:
        print(result.stdout)
        raise RuntimeError('Checker process failed')
    return result.stdout

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--full', action='store_true')
    ap.add_argument('--report', type=Path)
    args = ap.parse_args()
    if args.full:
        need(__debug__ and not sys.flags.optimize, '--full requires assertions enabled for inherited runtime')
    started = time.monotonic()
    count = manifest_check()
    for p, digest in [('inputs/u218.native.tm', OLD_SHA), ('machine/u217.native.tm', NEW_SHA),
                      ('machine/u217.tm', DENSE_SHA), ('machine/sites.json', SOURCE_SHA),
                      ('inputs/U218_ConPA_2026-10-28.zip', ARCHIVE_SHA)]:
        need(sha(ROOT / p) == digest, 'Wrong pinned input: ' + p)
    old = reduction.parse(ROOT / 'inputs/u218.native.tm')
    new = reduction.parse(ROOT / 'machine/u217.native.tm')
    need(reduction.encode(reduction.reduced(old)) == (ROOT / 'machine/u217.native.tm').read_text(), 'Native reconstruction')
    proof = reduction.verify(old, new)
    controls = reduction.negative_controls(old, new)
    proof['dense_sha256'] = DENSE_SHA
    need(proof == load(ROOT / 'evidence/u217_certificate.json'), 'Local certificate differs')
    need(controls == load(ROOT / 'evidence/u217_negative_controls.json'), 'Local controls differ')
    other = independent.audit(independent.read(ROOT / 'inputs/u218.native.tm'),
                              independent.read(ROOT / 'machine/u217.native.tm'))
    saved_other = load(ROOT / 'evidence/independent_u217_audit.json')
    other = json.loads(json.dumps(other))  # JSON object keys encode cell offsets as strings.
    need(all(saved_other[k] == v for k, v in other.items()), 'Independent block audit differs')
    other_controls = independent.negative_controls(old)
    need(other_controls == saved_other['negative_controls'], 'Independent controls differ')
    boot = bootstrap.audit(ROOT)
    need(boot == load(ROOT / 'evidence/bootstrap_independent.json'), 'Bootstrap differs')
    print('Exact reconstruction, both block proofs, 22 mutation controls, and blank startup: PASS', flush=True)
    sites = load(ROOT / 'machine/sites.json')
    runtime = load(ROOT / 'evidence/runtime.json')
    cases = load(ROOT / 'evidence/runtime_cases.json.gz')
    startup = load(ROOT / 'evidence/startup.json.gz')
    expected = {(i, positive) for i, x in enumerate(sites)
                for positive in ((False, True) if x[1] == 'CD' else (False,))}
    need(runtime['status'] == 'UNIVERSAL_MATHEMATICAL_PASS' and not runtime['failures'], 'Runtime status')
    need(runtime['table_sha256'] == NEW_SHA and runtime['sites_sha256'] == SOURCE_SHA, 'Runtime identity')
    need(runtime['site_count'] == len(sites) == 3891 and runtime['working_states'] == 217, 'Runtime census')
    need(runtime['proved_cases'] == runtime['expected_cases'] == len(cases) == len(expected) == 5060, 'Runtime count')
    need({(x['site_index'], x['positive']) for x in cases} == expected, 'Runtime coverage')
    need(startup['steps'] == 95726 and startup['state'] == 84 and startup['head'] == -8,
         'Saved startup boundary')
    need(startup['one_cells'] == boot['one_cells'], 'Saved startup whole tape')
    archive = ROOT / 'inputs/U218_ConPA_2026-10-28.zip'
    with zipfile.ZipFile(archive) as z:
        prefix = 'U218_ConPA_2026-10-28/'
        need(z.read(prefix + 'machine/u218.native.tm') == (ROOT / 'inputs/u218.native.tm').read_bytes(), 'Copied baseline differs')
        need(z.read(prefix + 'machine/sites.json') == (ROOT / 'machine/sites.json').read_bytes(), 'Source changed')
    if args.full:
        with tempfile.TemporaryDirectory(prefix='u217-full-') as folder:
            temp = Path(folder)
            baseline = extract(archive, temp / 'u218', 'U218_ConPA_2026-10-28')
            parent_zip = baseline / 'inputs/U222_ConU_2026-10-28.zip'
            need(sha(parent_zip) == PARENT_SHA, 'Wrong embedded U222 archive')
            parent = extract(parent_zip, temp / 'u222', 'u222_consistency_machine')
            need(sha(parent / 'code/runtime/symbolic_runtime.py') == runtime['checker_sha256'], 'Symbolic checker identity')
            need(sha(parent / 'code/runtime/independent_runtime.py') == runtime['helper_sha256'], 'Runtime helper identity')
            print('Replaying inherited U218 source/compilation audit ...', flush=True)
            command([baseline / 'reproduce.py', '--report', temp / 'baseline.json'], baseline)
            need(load(temp / 'baseline.json')['status'] == 'U218_RECONSTRUCTION_AND_PROOF_AUDIT_PASS', 'Baseline audit')
            print('Rederiving all 5060 arbitrary-register U217 cases ...', flush=True)
            log = command([parent / 'code/validate_native.py', ROOT / 'machine/u217.native.tm',
                           ROOT / 'machine/sites.json', temp / 'runtime'], temp)
            fresh = load(temp / 'runtime/runtime.json')
            need(fresh['status'] == 'UNIVERSAL_MATHEMATICAL_PASS' and not fresh['failures'], 'Fresh runtime failed')
            need(fresh['table_sha256'] == NEW_SHA and fresh['sites_sha256'] == SOURCE_SHA,
                 'Fresh runtime identity')
            need(fresh['proved_cases'] == fresh['expected_cases'] == 5060, 'Fresh runtime coverage')
            need(load(temp / 'runtime/runtime_cases.json') == cases, 'Re-derived case records differ')
            need(load(temp / 'runtime/startup.json') == startup, 'Re-derived startup differs')
            need(fresh['blocks'] == runtime['blocks'], 'Traversal induction schemas differ')
            print('Full arbitrary-register runtime replay: PASS', flush=True)
    result = {'status': 'U217_FULL_REPRODUCTION_PASS' if args.full else 'U217_REDUCTION_AND_PACKAGE_AUDIT_PASS',
              'manifest_files_checked': count, 'working_states': 217, 'transition_rows': 434,
              'native_sha256': NEW_SHA, 'dense_sha256': DENSE_SHA, 'unchanged_source_sha256': SOURCE_SHA,
              'source_occurrences': 3891, 'symbolic_cases': 5060, 'symbolic_cases_rederived': args.full,
              'independent_block_proofs': 2, 'negative_controls_rejected': 22,
              'blank_startup_steps': 95726, 'same_complete_initialized_tape': True,
              'seconds': round(time.monotonic() - started, 3),
              'scope': 'Exact local machine reduction and executable mathematical checks. Con(PA) calibration is inherited; no new kernel-checked endpoint.'}
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
