Research notes and scope
========================

The accepted deliverable is the unchanged-source, one-edge U217 reduction.
The root README and paper/report.pdf state its exact proof obligations.

u217_local_proof.tex and independent_stuttering_proof.txt present the two
local proof formulations. Their executable checkers and finite certificates
are included under code/ and evidence/ and are replayed by reproduce.py.

inherited_theory_review.txt records a written review of the supplied theory
and compiler dependencies and earlier proposals. Paths beginning sources/
or work/ describe the research workspace in which the review was performed;
they are historical provenance, not paths required by reproduction. The
complete U218 archive under inputs/ preserves all baseline theory and
runtime dependencies needed for the claimed result.

source_search_summary.txt and source_search_receipt.json record restricted
exploratory searches that found no further accepted reduction. Those search
optimizers are not release prerequisites and are not bundled. The saved
negative receipts are not lower-bound certificates. None is used in the
proof or verification of the exact U217 machine.

The source-compression summary's work/... paths refer to exploratory files,
not additional promised outputs. All artifacts needed to rebuild and check
U217 itself are contained in this package and work offline.
