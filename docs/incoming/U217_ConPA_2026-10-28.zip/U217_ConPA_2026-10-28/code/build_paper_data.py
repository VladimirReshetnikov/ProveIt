#!/usr/bin/env python3
"""Generate the full dense transition appendix from the delivered table."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'code'))
from check_reduction import parse, need

def main():
    T = parse(ROOT / 'machine/u217.tm')
    need(len(T) == 434, 'Wrong table size')
    rows = [r'\begin{longtable}{rll@{\qquad}rll}',
            r'\caption{Complete U217 transition table. Each action is write, move, next state.}\\',
            r'\toprule State & Read 0 & Read 1 & State & Read 0 & Read 1\\\midrule\endfirsthead',
            r'\toprule State & Read 0 & Read 1 & State & Read 0 & Read 1\\\midrule\endhead',
            r'\midrule\multicolumn{6}{r}{Continued on the next page}\\\endfoot',
            r'\bottomrule\endlastfoot']
    def action(q, b):
        w, d, z = T[q, b]
        return f'${w}'+('R' if d == 1 else 'L')+str(z)+'$'
    for q in range(109):
        text = f'{q} & {action(q, 0)} & {action(q, 1)}'
        p = q + 109
        text += f' & {p} & {action(p, 0)} & {action(p, 1)}' if p < 217 else ' & & &'
        rows.append(text + r'\\')
    rows.append(r'\end{longtable}')
    (ROOT / 'paper/transition_table.tex').write_text('\n'.join(rows) + '\n')

if __name__ == '__main__':
    main()
