#!/usr/bin/env python3
"""Independent literal state census and renaming audit; no construction import."""
import hashlib,json,pathlib

def require(x,msg):
    if not x:raise ValueError(msg)

def read(p):
    table={};starts=[]
    for line in p.read_text('ascii').splitlines():
        if line.startswith('#! start '):starts.append(int(line.split()[-1]))
        elif line and not line.startswith('#'):
            q,r,w,d,z=line.split();q,r,w,z=map(int,(q,r,w,z))
            require((q,r)not in table,'duplicate row')
            require(r in(0,1)and w in(0,1)and d in('L','R'),'invalid action')
            table[q,r]=(w,d,z)
    require(starts==[0],'start declaration')
    return table

def census(table,halt):
    states={q for q,r in table}
    require(0 in states and halt not in states,'start/halt convention')
    require(set(table)=={(q,r)for q in states for r in(0,1)},'binary totality')
    require(all(z in states|{halt}for w,d,z in table.values()),'target closure')
    reached={0};todo=[0]
    for q in todo:
        for bit in(0,1):
            z=table[q,bit][2]
            if z!=halt and z not in reached:reached.add(z);todo.append(z)
    require(reached==states,'graph-unreachable working state')
    return states

def main():
    base=pathlib.Path(__file__).resolve().parent.parent/'machine'
    native_path=base/'u217.native.tm';dense_path=base/'u217.tm';map_path=base/'u217_state_map.json'
    native=read(native_path);dense=read(dense_path);rename={int(q):z for q,z in json.loads(map_path.read_text()).items()}
    nstates=census(native,254);dstates=census(dense,217)
    require(len(nstates)==len(dstates)==217,'working-state count')
    require(len(native)==len(dense)==434,'row count')
    require(dstates==set(range(217)),'dense labels')
    require(set(rename)==nstates|{254}and set(rename.values())==set(range(218)),'bijection')
    require(rename[0]==0 and rename[254]==217,'start and halt map')
    require({(rename[q],r):(w,d,rename[z])for(q,r),(w,d,z)in native.items()}==dense,'all-row relabeling')
    inverse={v:q for q,v in rename.items()}
    require({(inverse[q],r):(w,d,inverse[z])for(q,r),(w,d,z)in dense.items()}==native,'inverse relabeling')
    require(112 not in nstates,'removed native state remains')
    result={'status':'INDEPENDENT_MACHINE_CENSUS_AND_BIJECTION_PASS','working_states':217,'binary_transition_rows':434,'dense_labels':[0,216],'start':0,'native_halt':254,'dense_halt':217,'removed_native_state':112,'alphabet':[0,1],'directions':['L','R'],'all_working_states_graph_reachable':True,'renaming_bijective':True,'all_forward_rows_checked':434,'all_inverse_rows_checked':434,'files':{p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in(native_path,dense_path,map_path)},'scope':'Syntactic census, graph reachability, exact relabeling only. No behavioral, initialization, or consistency assertion.'}
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
