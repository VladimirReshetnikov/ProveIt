#!/usr/bin/env python3
"""Independent, finite local proof obligations for U218 -> U217.

The sole changed edge is 172/0: (0,L,112) -> (0,L,134).
State 112 is removed; state 134 keeps both original rows.
Every run of the old table from state 0 on any binary tape satisfies
state 112 => tape(head+1)=0. Three old/new local block identities then
prove halting equivalence by induction over synchronized block endpoints.
Only the Python standard library is used.
"""
from pathlib import Path
from hashlib import sha256
import argparse, json

ROOT=Path(__file__).resolve().parent
DEFAULT_BASE=ROOT.parent/'inputs/u218.native.tm'

def need(test, message):
    if not test: raise ValueError(message)

def parse(path):
    table={}
    for line in Path(path).read_text().splitlines():
        if line.startswith('#') or not line.strip(): continue
        fields=line.split(); need(len(fields)==5,'five columns')
        q,b,w,d,z=fields; q,b,w,z=map(int,(q,b,w,z))
        need(d in ('L','R'),'direction'); need((q,b) not in table,'duplicate row')
        table[q,b]=(w,1 if d=='R' else -1,z)
    return table

def encode(table):
    return '#! start 0\n'+''.join(f'{q} {b} {w} {"R" if d==1 else "L"} {z}\n'
        for (q,b),(w,d,z) in sorted(table.items()))

def reduced(table):
    return {(q,b):(w,d,134 if z==112 else z)
        for (q,b),(w,d,z) in table.items() if q!=112}

def verify(A,B):
    Q={q for q,b in A}; R={q for q,b in B}
    need(len(Q)==218 and len(R)==217 and R==Q-{112},'state sets')
    need(0 in R and 254 not in Q,'start and halt')
    for T,S in ((A,Q),(B,R)):
        need(set(T)=={(q,b) for q in S for b in (0,1)},'binary totality')
        need(all(w in (0,1) and d in (-1,1) and (z in S or z==254)
                 for w,d,z in T.values()),'action closure')
    need({(q,b,w,d) for (q,b),(w,d,z) in A.items() if z==112}
         =={(172,0,0,-1)},'complete predecessor invariant')
    f=lambda q:134 if q==112 else q
    need(B==reduced(A),'exact fold and no unrelated changes')
    need(A[134,0]==(0,1,182) and A[134,1]==(1,1,158),'representative rows')
    need(all(B[f(q),b]==(w,d,f(z)) for (q,b),(w,d,z) in A.items() if q!=112),
         'ordinary transition commutation')
    def run(T,state,tape,steps):
        h=0; tape=dict(tape); trace=[]
        for _ in range(steps):
            need(h in tape,'read outside represented cells')
            need(state!=254,'intermediate halt')
            b=tape[h];w,d,z=T[state,b]
            trace.append([state,h,b,w,d,z]);tape[h]=w;h+=d;state=z
        return (state,h,tape),trace
    records=[]
    for current in (0,1):
        for future in (0,1):
            tape={0:current,1:0,2:future}
            old_steps=1 if current==0 else 5
            u,ut=run(A,112,tape,old_steps);v,vt=run(B,134,tape,3)
            need(u==v,'local block endpoint')
            need(u[2]==tape,'complete tape restoration')
            expected=(157,1) if current==0 else ((90,3) if future==0 else (86,3))
            need(u[:2]==expected,'terminal state and head')
            records.append({'current':current,'future':future,'old_steps':old_steps,
                'new_steps':3,'old_path':ut,'new_path':vt,'endpoint':[u[0],u[1]]})
    return {'status':'PASS','removed_native_state':112,'representative_native_state':134,
        'changed_row':[172,0,0,-1,134],'working_states':217,'transition_rows':434,
        'complete_local_cases':4,'represented_offsets':[0,1,2],
        'premise':'old state 112 implies tape(head+1)=0',
        'old_chunk_steps':[1,5],'new_chunk_steps':[3],
        'native_sha256':sha256(encode(B).encode()).hexdigest(),'records':records}

def negative_controls(A,B):
    mutations=[
      ('predecessor writes wrong tag',[(172,0,(1,-1,112))],[(172,0,(1,-1,134))]),
      ('uncontrolled extra predecessor',[(77,0,(0,1,112))],[(77,0,(0,1,134))]),
      ('wrong old zero target',[(112,0,(0,1,133))],[]),
      ('wrong old one target',[(112,1,(1,1,133))],[]),
      ('shared tag dispatcher direction',[(182,0,(0,1,209))],[(182,0,(0,1,209))]),
      ('shared zero helper wrong target',[(209,0,(0,1,133))],[(209,0,(0,1,133))]),
      ('shared new one entry wrong target',[(158,0,(0,1,90))],[(158,0,(0,1,90))]),
      ('shared tail-zero endpoint',[(218,0,(0,1,86))],[(218,0,(0,1,86))]),
      ('shared tail-one endpoint',[(218,1,(1,1,90))],[(218,1,(1,1,90))]),
      ('unjustified representative rewrite',[],[(134,0,(0,1,157))]),
      ('wrong redirect target',[],[(172,0,(0,-1,133))]),
    ]
    outcomes=[]
    for name,am,bm in mutations:
        X=dict(A);Y=dict(B)
        for q,b,v in am:X[q,b]=v
        for q,b,v in bm:Y[q,b]=v
        try:verify(X,Y)
        except ValueError as e:outcomes.append({'name':name,'status':'REJECTED','reason':str(e)})
        else:raise ValueError('negative control accepted: '+name)
    return {'status':'PASS','rejected':len(outcomes),'controls':outcomes}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline',type=Path,default=DEFAULT_BASE)
    ap.add_argument('--output',type=Path,default=ROOT)
    args=ap.parse_args(); A=parse(args.baseline); B=reduced(A)
    receipt=verify(A,B);controls=negative_controls(A,B)
    states=sorted({q for q,b in B}); rename={q:i for i,q in enumerate(states)};rename[254]=217
    D={(rename[q],b):(w,d,rename[z]) for (q,b),(w,d,z) in B.items()}
    need(len(D)==434 and set(rename.values())==set(range(218)),'dense bijection')
    receipt['dense_sha256']=sha256(encode(D).encode()).hexdigest()
    args.output.mkdir(parents=True,exist_ok=True)
    for name,content in [('u217.native.tm',encode(B)),('u217.tm',encode(D)),
         ('u217_state_map.json',json.dumps(rename,indent=2)+'\n'),
         ('u217_certificate.json',json.dumps(receipt,indent=2)+'\n'),
         ('u217_negative_controls.json',json.dumps(controls,indent=2)+'\n')]:
        (args.output/name).write_text(content)
    print(json.dumps({k:v for k,v in receipt.items() if k!='records'},indent=2))
    print(json.dumps({'negative_controls':controls['rejected'],'status':controls['status']}))

if __name__=='__main__':main()
