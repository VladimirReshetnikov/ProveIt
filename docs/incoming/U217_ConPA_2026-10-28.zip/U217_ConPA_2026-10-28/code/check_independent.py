#!/usr/bin/env python3
"""Independent table-only proof audit for U218 -> U217.

This checker imports no builder, allocator, source interpreter, or upstream
runtime checker. It checks explicit sufficient conditions for the ordinary
two-sided positive-block simulation in u217_stuttering_proof.md. It uses the
longer 4-to-6 zero block, independently of the shortest 1-to-3 certificate.
Python 3.10+, standard library only; checks remain enabled under python -O.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

BASE_SHA = "366cf96800bd4299de831355a80092394462278f0b62db1e19c167ca5f8b2a30"
HALT = 254
DROP = 112
KEEP = 134


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def read(path):
    table = {}
    starts = []
    for line in Path(path).read_text().splitlines():
        if line.startswith("#! start "):
            starts.append(int(line.split()[-1]))
            continue
        if not line or line.startswith("#"):
            continue
        fields = line.split()
        need(len(fields) == 5, "Five columns required")
        q, b, w, direction, dest = fields
        q, b, w, dest = map(int, (q, b, w, dest))
        need(direction in ("L", "R"), "Bad move")
        need((q, b) not in table, "Duplicate row")
        table[q, b] = w, (-1 if direction == "L" else 1), dest
    need(starts == [0], "Expected unique start 0")
    return table


def rename(q):
    return KEEP if q == DROP else q


def encode(table):
    return ("#! start 0\n" + "".join(
        f"{q} {b} {w} {'L' if d == -1 else 'R'} {z}\n"
        for (q, b), (w, d, z) in sorted(table.items())
    )).encode()


def quotient(table):
    return {(q, b): (w, d, rename(z))
            for (q, b), (w, d, z) in table.items() if q != DROP}


def wellformed(table, count, halt):
    states = {q for q, _ in table}
    need(len(states) == count, "Wrong number of working states")
    need(set(table) == {(q, b) for q in states for b in (0, 1)},
         "Missing binary row")
    need(0 in states and halt not in states, "Start/halt convention")
    need({z for w, d, z in table.values()} - states == {halt},
         "Exactly one separate halt required")
    need(all(w in (0, 1) and d in (-1, 1)
             for w, d, z in table.values()), "Alphabet/movement")
    return states


def local_run(table, state, known, steps):
    """Execute only explicitly known cells; reject any exterior observation."""
    tape = dict(known)
    head = 0
    trace = []
    for _ in range(steps):
        need(state != HALT, "Interior halt")
        need(head in tape, "Observed an unconstrained exterior cell")
        bit = tape[head]
        write, move, target = table[state, bit]
        need(write == bit, "Local path must preserve every visited cell")
        trace.append({"state": state, "head": head, "read": bit,
                      "write": write, "move": move, "target": target})
        tape[head] = write
        head += move
        state = target
    need(tape == known, "Local tape changed")
    return state, head, tape, trace


def audit(old, new):
    qs = wellformed(old, 218, HALT)
    rs = wellformed(new, 217, HALT)
    need(rs == qs - {DROP}, "Deleted precisely state112")
    need(new == quotient(old), "Table is not the claimed exact target fold")
    incoming = [(q, b, w, d) for (q, b), (w, d, z) in old.items()
                if z == DROP]
    need(incoming == [(172, 0, 0, -1)], "Unique zero-writing left entry")

    # Invariant: old state112 implies its right neighbor is0. Initial
    # control0 is unconstrained. The sole predecessor writes that neighbor
    # exactly0 and moves left. No premise about other cells is needed.
    need(0 != DROP and HALT != DROP, "Invariant initialization/halt")

    # All ordinary one-step squares commute. Multi-step special blocks
    # below start at old112/new134 with right cell0.
    ordinary = 0
    for (q, bit), (w, d, z) in old.items():
        if q != DROP:
            need(new[rename(q), bit] == (w, d, rename(z)),
                 "Ordinary transition does not commute")
            ordinary += 1
    need(ordinary == 434, "Ordinary row census")

    cases = [
        ("current0", {0: 0, 1: 0}, 4, 6, 90, 2),
        ("current1-next0", {0: 1, 1: 0, 2: 0}, 5, 3, 90, 3),
        ("current1-next1", {0: 1, 1: 0, 2: 1}, 5, 3, 86, 3),
    ]
    records = []
    for label, known, a, b, target, shift in cases:
        oq, oh, ot, trace_old = local_run(old, DROP, known, a)
        nq, nh, nt, trace_new = local_run(new, KEEP, known, b)
        need((oq, oh) == (nq, nh) == (target, shift),
             "Different local endpoints")
        need(ot == nt == known, "Whole-tape local identity")
        need(all(x["state"] != DROP for x in trace_old[1:]),
             "Hidden second deleted-state visit")
        need(target not in (DROP, HALT), "Endpoint safety")
        need(2*b <= 3*a and 3*a <= 5*b, "Sharp clock ratios")
        records.append({"case": label, "known_cells": known,
                        "old_steps": a, "new_steps": b,
                        "target": target, "head_shift": shift,
                        "old_trace": trace_old, "new_trace": trace_new})

    return {
        "status": "INDEPENDENT_U217_BLOCK_PROOF_PREMISES_PASS",
        "old_states": 218, "new_states": 217,
        "old_rows": 436, "new_rows": 434,
        "changed_retained_rows": [[172, 0]],
        "removed_state": DROP, "replacement_state": KEEP,
        "initial_state": 0, "native_halt": HALT,
        "old_invariant": "q=112 implies tape(head+1)=0",
        "ordinary_row_squares": ordinary,
        "symbolic_local_cases": records,
        "clock_identity": "T_new=T_old+2*N0-2*N1",
        "clock_bounds": ["2*T_new <= 3*T_old", "3*T_old <= 5*T_new"],
        "scope": "Finite sufficient premises for the stated ordinary induction proof; no proof-assistant endpoint."
    }


def negative_controls(old):
    controls = []
    tests = [
        ("wrong_establishing_bit", (172, 0), (1, -1, 112)),
        ("wrong_establishing_direction", (172, 0), (0, 1, 112)),
        ("extra_unguarded_predecessor", (0, 0), (0, 1, 112)),
        ("old_zero_continuation", (112, 0), (0, 1, 133)),
        ("old_one_continuation", (112, 1), (1, 1, 134)),
        ("shared_zero_entry", (134, 0), (0, 1, 133)),
        ("shared_one_entry", (134, 1), (1, 1, 157)),
        ("late_zero_provider", (151, 0), (0, 1, 86)),
        ("late_one_provider", (218, 1), (1, 1, 90)),
    ]
    for name, key, value in tests:
        altered = dict(old)
        altered[key] = value
        try:
            audit(altered, quotient(altered))
        except ValueError as exc:
            controls.append({"name": name, "result": "REJECTED", "reason": str(exc)})
        else:
            raise ValueError("Mutation was not rejected: " + name)
    new = quotient(old)
    new[172, 0] = old[172, 0]
    try:
        audit(old, new)
    except ValueError as exc:
        controls.append({"name": "omitted_target_redirection", "result": "REJECTED", "reason": str(exc)})
    else:
        raise ValueError("Missing redirection accepted")
    new = quotient(old)
    w, d, z = new[0, 0]
    new[0, 0] = 1-w, d, z
    try:
        audit(old, new)
    except ValueError as exc:
        controls.append({"name": "unreported_ordinary_mutation", "result": "REJECTED", "reason": str(exc)})
    else:
        raise ValueError("Ordinary mutation accepted")
    return controls


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("baseline", type=Path)
    parser.add_argument("candidate", type=Path, nargs="?")
    parser.add_argument("--dense", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    raw = args.baseline.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == BASE_SHA, "Wrong baseline identity")
    old = read(args.baseline)
    new = read(args.candidate) if args.candidate else quotient(old)
    report = audit(old, new)
    report["old_native_sha256"] = BASE_SHA
    report["new_native_sha256"] = hashlib.sha256(encode(new)).hexdigest()
    mp = {q: i for i, q in enumerate(sorted({q for q, b in new}))}
    mp[HALT] = 217
    dense = {(mp[q], b): (w, d, mp[z])
             for (q, b), (w, d, z) in new.items()}
    wellformed(dense, 217, 217)
    need(set(mp.values()) == set(range(218)) and mp[0] == 0,
         "Dense state bijection")
    if args.dense:
        need(read(args.dense) == dense, "Supplied dense table is not exact conjugacy")
    report["new_dense_sha256"] = hashlib.sha256(encode(dense)).hexdigest()
    report["negative_controls"] = negative_controls(old)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items()
                      if k not in ("symbolic_local_cases", "negative_controls")}, indent=2))
    print("Negative controls rejected:", len(report["negative_controls"]))


if __name__ == "__main__":
    main()
