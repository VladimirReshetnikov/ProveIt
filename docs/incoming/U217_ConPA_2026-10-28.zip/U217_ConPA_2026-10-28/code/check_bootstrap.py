#!/usr/bin/env python3
"""Independent literal replay of native and dense U217 initialization."""
from pathlib import Path
import argparse, hashlib, json

def require(condition, message):
    if not condition:
        raise ValueError(message)

def read(path):
    table = {}
    starts = []
    for line in path.read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
        elif line and not line.startswith('#'):
            q, b, w, d, z = line.split()
            q, b, w, z = map(int, (q, b, w, z))
            require((q, b) not in table, 'Duplicate transition')
            require(d in ('L', 'R') and b in (0, 1) and w in (0, 1), 'Bad action')
            table[q, b] = w, (1 if d == 'R' else -1), z
    require(starts == [0], 'Wrong start')
    return table

def run(table, count):
    q, h, ones = 0, 0, set()
    hits = {112: 0, 134: 0}
    for _ in range(count):
        if q in hits:
            hits[q] += 1
        require((q, int(h in ones)) in table, 'Unexpected early halt')
        w, d, q = table[q, int(h in ones)]
        if w:
            ones.add(h)
        else:
            ones.discard(h)
        h += d
    return q, h, ones, hits

def expected_tape():
    # Physical order: W,L,T,D,A,Y,N,H,X, then forty unit spares.
    values = [0, 0, 0, 0, 0, 0, 4, 0, 0] + [1] * 40
    ones, pos = {-9, 57}, 58
    for v in values:
        pos += 1
        ones.update(range(pos, pos + v + 1))
        pos += v + 1
    require(len(ones) == 95 and max(ones) == 199, 'Frame construction')
    return ones

def audit(root):
    old = read(root / 'inputs/u218.native.tm')
    new = read(root / 'machine/u217.native.tm')
    dense = read(root / 'machine/u217.tm')
    names = {int(k): v for k, v in json.loads((root / 'machine/u217_state_map.json').read_text()).items()}
    require(set(names) == {q for q, b in new} | {254}, 'Map domain')
    require(set(names.values()) == set(range(218)) and names[0] == 0 and names[254] == 217, 'Map range')
    require(dense == {(names[q], b): (w, d, names[z]) for (q, b), (w, d, z) in new.items()}, 'Exact conjugacy')
    reached = {0}
    pending = [0]
    while pending:
        q = pending.pop()
        for b in (0, 1):
            z = new[q, b][2]
            if z != 254 and z not in reached:
                reached.add(z)
                pending.append(z)
    require(reached == {q for q, b in new}, 'Graph-unreachable working state')
    expected = expected_tape()
    runs = []
    for label, table, dispatch in [('baseline', old, 84), ('native', new, 84), ('dense', dense, names[84])]:
        q, h, ones, hits = run(table, 95726)
        require((q, h, ones) == (dispatch, -8, expected), 'Whole initialized tape mismatch: ' + label)
        runs.append({'table': label, 'state': q, 'head': h, 'steps': 95726,
                     'native_label_112_visits': hits[112] if label != 'dense' else None})
    require(runs[0]['native_label_112_visits'] == 0, 'Claimed unchanged startup does visit deleted state')
    return {'status': 'INDEPENDENT_LITERAL_BOOTSTRAP_PASS', 'working_states': 217,
            'transition_rows': 434, 'graph_reachable_working_states': len(reached),
            'runs': runs, 'gap': 1, 'header': 57,
            'logical_registers': [4, 0, 0, 0, 0, 0, 0, 0, 0],
            'spare_count': 40, 'spare_value': 1, 'one_cells': sorted(expected),
            'native_sha256': hashlib.sha256((root / 'machine/u217.native.tm').read_bytes()).hexdigest(),
            'dense_sha256': hashlib.sha256((root / 'machine/u217.tm').read_bytes()).hexdigest()}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
    ap.add_argument('--report', type=Path)
    a = ap.parse_args()
    result = audit(a.root)
    if a.report:
        a.report.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'one_cells'}, indent=2))

if __name__ == '__main__':
    main()
