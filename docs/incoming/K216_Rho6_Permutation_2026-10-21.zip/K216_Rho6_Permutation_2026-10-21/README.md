# A 216-state rho6-permuted ZFC consistency machine

This packet supplies a deterministic binary one-tape machine with **216 working
states**, including blank initialization, and a separate halt. The ordinary
mathematical proof composes the inherited native-calculus calibration with
the new source/compiler argument and exact physical checks to establish:

> ZFC proves: the machine does not halt on blank tape if and only if Con(ZFC).

Read **[report.pdf](report.pdf)** for the article; its complete editable source is
[report.tex](report.tex). The normative dense machine is
[machine/k216-rho6.tm](machine/k216-rho6.tm).

## Attribution and novelty

The investigation started from the accepted 217-state construction. During the
work, ProveIt published and accepted the partial-selector K216 at commit
`e6083665c6826e3a8aef969a8a4a8bc9031bd32b`. Our independently developed rho6
parameter permutation composes with that newly public machine and changes
exactly two transition rows. This is a distinct 216-state variant; it is **not
a reduction below the newest public 216-state record**, and no checked
215-state construction is claimed.

The partial-selector state saving, contextual repair, and 183-to-164 fold are
upstream work. The new contributions here are the parameter-permuted exact
machine, its semantic/compiler argument, independent source and blank audit,
fresh full runtime evidence, and additional formalism/encoding research.
See [NOTICE.md](NOTICE.md) and the preserved original notices and licenses.

## Exact construction

Starting from the pinned public native K216 table, make just these replacements:

| State | Read | Old write/move/next | New write/move/next |
|---|---|---|---|
| 199 | 1 | `1 R 166` | `1 R 12` |
| 206 | 0 | `0 R 186` | `0 R 76` |

The source counterpart exchanges register operands 3 and 5 within zero-based
primitive interval `[902,1185)`, on increments/decrements only. Exactly four
operands change, at ordinals 973, 978, 1151, and 1156. All paths and every other
operation/operand are retained. This changes `rho6(A,C)` to `rho6(A,B)` in one
AX output, with A in register 4, B in register 5, and C in register 3.

Soundness follows because this is another instance of the same universal
scheme. Completeness uses the strong proof compiler's reset counter/cache:
after resetting d=h=0, fields `[a+3,0,b,a]` produce the desired rho6(a,b), with
U=0, A=a, B=b, C=a and a false bundle gate. Its stack position and cleanup
counts are unchanged. This is a local axiom-family argument, not a claim that
the two programs have identical behavior on every arbitrary store.

## Machine convention and identity

Two-way infinite binary tape, initially all zero; head coordinate 0; initial
state 0; only left/right moves. Rows have format `state read write direction next`.
The halt has no outgoing rows and is excluded from the count.

- Canonical: working states 0–215, halt 216, dispatcher 84.
- Native: start 0, dispatcher 84, halt 254.
- All 216 working states are directed-graph reachable. This says nothing about
  visitation of each state during the blank run.
- Source: 4,751 occurrences, 203 distinct DAG nodes, depth 48, maximum zero run 6.

| File | SHA-256 |
|---|---|
| `machine/k216-rho6.native.tm` | `37ec2b16d410f5cde9ee9b28f14033066a33d31bf736f3adc6134979d2658010` |
| `machine/k216-rho6.tm` | `a4f0a4b81ce197f9c1ec7dc88b0c99d8ac1f25a8bf752b5446c4ec89c3a5c8e3` |
| `machine/sites216.json` | `e83df4fb78e288f5fd717b20a0d82419f511dfcb79fa4dfc1b351f3fef6b3730` |

## Verification

| Obligation | Fresh result |
|---|---|
| Exact construction | Two transition replacements; four source operands |
| Source control graph | Two independent resolvers agree on all 6,175 guarded edges |
| Canonicalization | Bijection checked on all 432 rows |
| Complete blank startup | 313,133 transitions; sparse/dense full traces agree |
| Exact endpoint | Dispatcher 84, head −5, gap 80, registers `[3,0,0,0,3,0,0,0,0]` |
| Complete tape | 130 unit spares, 277 one-cells,zero control field and exterior |
| Universal primitive runtime | 6,176 cases; 1,711,040 symbolic rules; all 432 rows used |
| Positive durations | Minimum affine duration constant 13 |

The full symbolic replay quantifies independently over arbitrary natural
register values and gap, and any nonempty finite spare list. It uses ordinary
unary/list induction and checks complete tape endpoints. It is not bounded
sampling. The recorded run took 152.151 seconds; exact timing is not a theorem.

The runtime engine is inherited and pinned. The complete blank/source audit
uses separate implementations. The foundational native-calculus/ZFC
calibration and inherited strong proof compiler are explicit mathematical
premises, not conclusions inferred from a finite machine simulation.

This packet does not contain a newly compiled exact-table Lean/Rocq theorem
or internal-PA proof, and does not claim unconditional nonhalting or minimality.

## Reproduce

Use Python 3 with its standard library. Keep assertions enabled; do not use `-O`.
From this directory:

```sh
python3 -B code/reproduce.py
python3 -B code/reproduce.py --full-runtime
```

The first command reconstructs exact bytes from the pinned parent and checks
source, state renaming, complete blank startup, the 3,728-node dominated-row
certificate, the pairing-change premise, the three-valued matrix, and finite
support for protected-stack credit. It also binds the saved runtime cases to
the exact machine, source, and engine. The second command additionally reruns
every symbolic primitive contract and compares every ordered case with the
saved evidence. Fresh output stays under `reproduced/`.

To rebuild the article:

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

The optional parameter-permutation search is separately reproducible:

```sh
python3 -B code/research/parameter_search.py
python3 -B code/research/parameter_search.py --source inputs/upstream216/sites216.compact.json
python3 -B code/research/parameter_search.py --bundle
```

These price source DAGs only. They are not binary-state lower bounds or
physical correctness proofs.

## Other research in the article

1. **Pairing-parametric native calculus.** Hereditary recoding preserves the
   unrestricted calculus on all natural codes, including private binder/code
   coupling and the zero alias. The dominated calculus remains equiconsistent
   by rechecking the finite subterm certificate. Numerical order itself is not
   preserved; the report gives an explicit counterexample and the correct proof.
2. **A three-valued obstruction to U=A.** All retained rows, inference rules,
   truth, and even the ungated set-theoretic bundle are designated, while native
   falsity is not. This gives elementary-arithmetic consistency and rules out
   the required ZFC-provable equivalence if ZFC is consistent. The broader
   excluded family was already known upstream; this is a smaller certificate.
3. **Finite protected-stack credit.** A finite calculation at an arbitrary
   candidate cutoff suffices to protect an arbitrary tail for the whole future
   Cantor schedule, using the inherited diagonal induction. This can help price
   less restrictive startup endpoints.
4. **Scoped encoding experiments.** Parameter permutations, row orders,
   dictionary reparsing, alternate constructor coding, dyadic arithmetic,
   relocating the falsity detector, source invariants, and physical state folds
   were explored. Source counts, finite filters, rejected candidates, and
   universal proofs are distinguished throughout.

## Pinned public sources

- [Accepted partial-selector216 and its ordinary proof](https://github.com/VladimirReshetnikov/ProveIt/tree/e6083665c6826e3a8aef969a8a4a8bc9031bd32b/Computability/BusyBeaver/Research/ZFC/candidate-k216)
- [Original accepted217 at the investigation's starting snapshot](https://github.com/VladimirReshetnikov/ProveIt/tree/d3d6b8c14e1ddff37eb1417c5448caa41cfd6da7/Computability/BusyBeaver/Research/ZFC/candidate-k217)
- [Source149 inherited numerical-calculus calibration record](https://github.com/VladimirReshetnikov/ProveIt/blob/e6083665c6826e3a8aef969a8a4a8bc9031bd32b/SetTheory/Cardinals/docs/reports/set-theory/zfc-closure-kernels/intake-191.md)

`manifest.json` inventories the final delivered bytes. Generated search logs and
the full proof-assistant ancestry are not needed to reconstruct this two-row
variant; the original upstream reports remain available at the pinned sources.
