# Canonical exponentially small sectors for vincular avoidance

This report continues the exact A113226 EGF established in earlier delivered report 87, Exact Vincular Avoidance Asymptotics. The earlier source is frozen and is identified in dependency.json; it is not overwritten or included as a new deliverable.

## Main result

The report proves an exact, absolutely convergent decomposition into full-cut Hankel sectors, including the essential endpoint loops. It defines an exact dominant sector H0, isolates the first conjugate exponentially small pair with a geometric tail, and proves every fixed sector's all-orders complex saddle expansion. Explicit coefficients c1 and c2 are included.

## Contents

- article.pdf: the 11-page report
- article.tex: editable TeX source
- proof_notes.md: expanded derivation notes
- dependency.json: exact prior-report dependency and frozen input checksum
- source_status.md: bounded source comparison, with verified primary links
- check_sector_coefficients.py: exact circle and independently parameterized chord Gaussian checks through c2
- check_sector_numerics.py: high-precision contour regressions with explicit omitted-bank tail bounds
- checks/: reproducible JSON outputs
- audit/: separate global-contour and local-remainder reviews
- qa/visual_review.md: rendering and clean-replay record
- manifest.json: sizes and SHA-256 values for bundled files

## Reproduce

Install Python dependencies if needed:

    python -m pip install -r requirements.txt

Run all checks and rebuild in a clean temporary directory:

    bash replay.sh

An explicit fresh destination may also be passed as the first argument. The script prints the resulting directory. It runs both mathematical check scripts with Python optimization enabled; their acceptance tests use explicit exceptions rather than assert statements. It then builds the PDF twice and rejects overfull boxes or unresolved references.

For a PDF-only build in this directory:

    bash build.sh

The build uses a local TeX format/cache so it also works in read-only-home Linux environments. Standard pdfLaTeX packages are listed in the report. No external requests are made by the checks or build.

To render the rebuilt PDF for visual inspection:

    pdftoppm -r 100 -png article.pdf page

## Scope

The generating function's combinatorial proof belongs to report 87. The present analytic sector proofs start from that identity. Numerical quadrature is regression evidence rather than interval certification; the all-orders and global-tail claims rest on the mathematical proofs. The source comparison is bounded and does not establish worldwide priority. This is not an externally refereed or formally verified result.
