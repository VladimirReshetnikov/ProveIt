"""Independent exact blank initialization, baseline and reduced table."""
from pathlib import Path
import json,hashlib,gzip
from check_stacking import read,require
P=Path(__file__).parent
pc='001100110101010';logical=[1,0,13,0,0,1,0,0,1];physical=[None]*9
for i,j in enumerate((6,2,0,4,3,7,8,5,1)):physical[j]=logical[i]
head=-2;expected={-3,54}|{head+i for i,b in enumerate(pc)if b=='1'};pos=55
for v in physical+[1]*43:expected.update(range(pos+1,pos+v+2));pos+=v+2
receipts=[]
for filename,count in [('baseline213.native.tm',213),('retimed213.native.tm',213),('u212.native.tm',212)]:
 T=read(P/filename,count);q=h=0;ones=set();trace=[]
 for k in range(48141):
  if(q,h,ones)==(84,head,expected):break
  require(k<48140,'matching startup not reached');require(q!=254,'premature halt');b=int(h in ones);w,d,z=T[q,b];trace.append([q,h,b,w,d,z]);q=z
  if w:ones.add(h)
  else:ones.discard(h)
  h+=d
 raw=(json.dumps(trace,separators=(',',':'))+'\n').encode();(P/(filename+'.startup.json.gz')).write_bytes(gzip.compress(raw,mtime=0))
 receipts.append({'table':filename,'sha256':hashlib.sha256((P/filename).read_bytes()).hexdigest(),'steps':k,'state':q,'head':h,'trace_sha256':hashlib.sha256(raw).hexdigest(),'used_modified_rows':{str(key):sum(r[0]==key[0]and r[2]==key[1]for r in trace)for key in[(180,1),(172,0)]}})
r={'status':'EXACT_WHOLE_TAPE_STARTUP_PASS','receipts':receipts,'source_ordinal':136,'source_address':pc,'logical_registers':logical,'spares':[1]*43,'header_distance':56,'extra_gap':0,'one_cells':sorted(expected),'scope':'Literal finite initialization identity; inherited ST213 source, suffix and calibration are separately retained.'}
(P/'startup_result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k not in('one_cells','spares')},indent=2))
