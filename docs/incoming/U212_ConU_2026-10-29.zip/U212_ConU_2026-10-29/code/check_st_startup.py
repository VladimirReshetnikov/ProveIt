#!/usr/bin/env python3
"""Replay literal blank execution to the inherited ST interior-source frame."""
import argparse,json,hashlib,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'code56'))
from check_startup import load_table,require
p=argparse.ArgumentParser();p.add_argument('--table',type=Path,required=True);p.add_argument('--sites',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();raw=a.table.read_bytes();src=a.sites.read_bytes();T=load_table(a.table);Q={q for q,b in T};require(set(T)=={(q,b)for q in Q for b in(0,1)},'totality');require({z for w,d,z in T.values()}-Q=={254},'halt');S=json.loads(src);pc='001100110101010';require(S[136][0]==pc,'source entry');regs=[1,0,13,0,0,1,0,0,1];phy=(6,2,0,4,3,7,8,5,1);phys=[0]*9
for i,j in enumerate(phy):phys[j]=regs[i]
want={-3,54}|{-2+i for i,c in enumerate(pc)if c=='1'};pos=55
for n in phys+[1]*43:want.update(range(pos+1,pos+n+2));pos+=n+2
q=h=0;ones=set();tracehash=hashlib.sha256();trace=[]
for tick in range(2000001):
 if(q,h,ones)==(84,-2,want):break
 require((q,int(h in ones))in T,'early halt');b=int(h in ones);w,d,z=T[q,b];row=[tick,q,h,b,w,d,z];tracehash.update((json.dumps(row,separators=(',',':'))+'\n').encode());trace.append(row)
 if w:ones.add(h)
 else:ones.discard(h)
 q,h=z,h+d
else:raise RuntimeError('target not reached within bound')
require(a.table.read_bytes()==raw and a.sites.read_bytes()==src,'inputs changed');r={'status':'EXACT_ST_INTERIOR_STARTUP_PASS','states':len(Q),'rows':len(T),'steps':tick,'state':q,'head':h,'header_distance':56,'gap':0,'source_ordinal':136,'source_address':pc,'registers':regs,'spares':[1]*43,'one_cells':sorted(ones),'trace_sha256':tracehash.hexdigest(),'table_sha256':hashlib.sha256(raw).hexdigest(),'sites_sha256':hashlib.sha256(src).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Exact blank run to complete inherited interior-entry tape. Source suffix calibration remains separate.'};a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(r,indent=2)+'\n');a.output.with_suffix('.trace.json').write_text(json.dumps(trace)+'\n');print(json.dumps({k:v for k,v in r.items()if k not in('one_cells','spares')},indent=2))
