from pathlib import Path
import json,hashlib
from check_stacking import read,require
P=Path(__file__).parent;T=read(P/'u212.native.tm',212);M={int(q):v for q,v in json.loads((P/'renaming.json').read_text()).items()};S={q for q,b in T};require(set(M)==S|{254}and set(M.values())==set(range(213))and M[0]==0 and M[254]==212,'bijection');D={};headers=[]
for l in(P/'u212.tm').read_text().splitlines():
 if l.startswith('#! start '):headers.append(l);continue
 if not l or l.startswith('#'):continue
 q,b,w,d,z=l.split();q,b,w,z=map(int,(q,b,w,z));require((q,b)not in D and d in('L','R'),'dense row');D[q,b]=(w,1 if d=='R'else-1,z)
require(headers==['#! start 0'],'dense initial');require(D=={(M[q],b):(w,d,M[z])for(q,b),(w,d,z)in T.items()},'conjugacy');r={'status':'EXACT_DENSE_CONJUGACY_PASS','working_states':212,'halt':212,'sha256':hashlib.sha256((P/'u212.tm').read_bytes()).hexdigest()};(P/'dense_result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
