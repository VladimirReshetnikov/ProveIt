#!/usr/bin/env python3
"""Input rejection controls; finite tests, not a soundness proof."""
import argparse,json,subprocess,sys,tempfile
from pathlib import Path
import check_runtime as c

def main():
 a=argparse.ArgumentParser();a.add_argument('--table',type=Path,required=True);a.add_argument('--sites',type=Path,required=True);a.add_argument('--output',type=Path,required=True);x=a.parse_args();results=[]
 def rejected(name,f):
  try:f()
  except Exception:results.append(name);return
  raise RuntimeError('accepted bad input: '+name)
 raw=x.sites.read_bytes();ss=json.loads(raw)
 rejected('duplicate site',lambda:c.sites_checked(json.dumps(ss+[ss[0]])))
 rejected('incomplete source',lambda:c.sites_checked(json.dumps(ss[:-1])))
 bad=json.loads(raw);bad[0][1]='BAD';rejected('invalid opcode',lambda:c.sites_checked(json.dumps(bad)))
 with tempfile.TemporaryDirectory()as d:
  p=Path(d)/'bad.tm';p.write_text(x.table.read_text()+'\n'+next(z for z in x.table.read_text().splitlines()if z and not z.startswith('#'))+'\n')
  rejected('duplicate transition',lambda:c.boot.load_table(p))
 r=subprocess.run([sys.executable,'-O',str(Path(__file__).with_name('check_runtime.py')),'--help'],capture_output=True,text=True)
 if r.returncode==0 or 'requires enabled assertions'not in r.stderr:raise RuntimeError('optimized interpreter not rejected')
 results.append('optimized interpreter refusal');x.output.parent.mkdir(parents=True,exist_ok=True);x.output.write_text(json.dumps({'status':'PASS','controls':results},indent=2)+'\n');print('PASS',len(results),'negative controls')
if __name__=='__main__':main()
