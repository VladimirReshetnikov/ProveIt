"""Two independent finite whole-tape stuttering certificates, no runtime import."""
from pathlib import Path
import itertools,json,hashlib
P=Path(__file__).parent

def require(p,m):
 if not p:raise ValueError(m)

def read(path,count):
 T={};start=[]
 for l in path.read_text().splitlines():
  if l.startswith('#! start '):start.append(l);continue
  if not l or l.startswith('#'):continue
  q,b,w,d,z=l.split();q,b,w,z=map(int,(q,b,w,z));require((q,b)not in T and b in(0,1)and w in(0,1)and d in('L','R'),'row');T[q,b]=(w,1 if d=='R'else-1,z)
 S={q for q,b in T};require(start==['#! start 0']and len(S)==count and 0 in S,'start/count');require(set(T)=={(q,b)for q in S for b in(0,1)},'total');require({z for w,d,z in T.values()}-S=={254},'halt');return T

def run(T,q,t,n):
 t=dict(t);h=0;trace=[]
 for k in range(n):
  require(q!=254 and h in t,'interior halt/opaque');b=t[h];w,d,z=T[q,b];trace.append([q,h,b,w,d,z]);t[h]=w;h+=d;q=z
 return(q,h,t),trace

def verify(A,B,C):
 expected=dict(A);expected[180,1]=(1,1,211);require(B==expected,'exact first edit')
 expected=dict(B);expected[172,0]=(0,-1,67);del expected[112,0];del expected[112,1];require(C==expected,'exact second edit')
 require(sorted((q,b,w,d)for(q,b),(w,d,z)in B.items()if z==172)==[(116,0,0,1)],'172 guard entrance')
 require(sorted((q,b,w,d)for(q,b),(w,d,z)in B.items()if z==112)==[(172,0,0,-1)],'112 sole entrance')
 counts={'A':0,'B':0};duration={};examples={}
 for q in sorted({q for q,b in A}):
  for bits in itertools.product((0,1),repeat=5):
   t=dict(zip(range(-2,3),bits));n=m=1
   if q==180 and t[0]==1:n,m=(2,2)if t[1]else(7,3)
   a,ta=run(A,q,t,n);b,tb=run(B,q,t,m);require(a==b,'stage A endpoint')
   counts['A']+=1;duration['A '+str(n)+':'+str(m)]=duration.get('A '+str(n)+':'+str(m),0)+1
   if q==180 and t[0]==1:examples.setdefault('A '+str(t[1])+str(t[2]),{'old':ta,'new':tb,'endpoint':a[:2]})
 for q in sorted({q for q,b in C}):
  for bits in itertools.product((0,1),repeat=5):
   t=dict(zip(range(-2,3),bits))
   if q==172 and t[-1]!=0:continue
   n,m=(4,2)if q==172 and t[0]==0 else(1,1)
   a,ta=run(B,q,t,n);b,tb=run(C,q,t,m);require(a==b,'stage B endpoint');z,h,u=a
   require(z!=112 and(z!=172 or u[h-1]==0),'boundary invariant')
   counts['B']+=1;duration['B '+str(n)+':'+str(m)]=duration.get('B '+str(n)+':'+str(m),0)+1
   if n==4:examples.setdefault('B',{'old':ta,'new':tb,'endpoint':a[:2]})
 return {'status':'TWO_STAGE_WHOLE_TAPE_STUTTERING_PASS','frames':counts,'durations':duration,'examples':examples,'scope':'All initial tapes at state0. Stage A holds from every state/configuration; stage B uses q!=112 and q=172=>left_bit=0 at block boundaries. Finite positive blocks, no exterior access and no interior halt imply two-sided halting equivalence; ordinary PA-formalizable proof.'}

def main():
 A=read(P/'baseline213.native.tm',213);B=read(P/'retimed213.native.tm',213);C=read(P/'u212.native.tm',212);r=verify(A,B,C);negative=[]
 for label,stage,key,row in [('wrong first target','B',(180,1),(1,1,167)),('wrong second target','C',(172,0),(0,-1,68)),('wrong first write','B',(180,1),(0,1,211))]:
  BB,CC=dict(B),dict(C)
  (BB if stage=='B'else CC)[key]=row
  try:verify(A,BB,CC)
  except ValueError as e:negative.append([label,str(e)])
  else:raise ValueError('mutation accepted')
 for label,key,row in [('guard entry writes one',(116,0),(1,1,172)),('helper corrupts tape',(67,0),(1,1,151))]:
  AA,BB,CC=dict(A),dict(B),dict(C)
  for T in(AA,BB,CC):T[key]=row
  try:verify(AA,BB,CC)
  except ValueError as e:negative.append([label,str(e)])
  else:raise ValueError('semantic mutation accepted')
 r['negative_controls']=negative;r['sha256']={f:hashlib.sha256((P/f).read_bytes()).hexdigest()for f in['baseline213.native.tm','retimed213.native.tm','u212.native.tm']};(P/'stacking_result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
