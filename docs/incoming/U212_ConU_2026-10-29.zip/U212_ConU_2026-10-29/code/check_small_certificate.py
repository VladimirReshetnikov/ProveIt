#!/usr/bin/env python3
"""Separate four-case proof with an opaque exterior; no project checker imports."""
import argparse,json
from pathlib import Path
def need(x,m):
 if not x:raise RuntimeError(m)
def parse(p):
 t={}
 for l in p.read_text().splitlines():
  if not l or l.startswith('#'):continue
  q,b,w,d,z=l.split();k=int(q),int(b);need(k not in t,'duplicate');t[k]=(int(w),1 if d=='R'else-1,int(z))
 return t
def execute(t,q,cells,n):
 h=0;cells=dict(cells)
 for _ in range(n):
  need(h in cells and q!=254,'opaque exterior or halt');w,d,q=t[q,cells[h]];cells[h]=w;h+=d
 return q,h,cells
def check(a,b,c):
 d=dict(a);d[180,1]=(1,1,211);need(d==b,'first patch');d=dict(b);d[172,0]=(0,-1,67);del d[112,0];del d[112,1];need(d==c,'second patch')
 tests=[({0:1,1:1},2,2,184,2),({0:1,1:0,2:0},7,3,90,3),({0:1,1:0,2:1},7,3,86,3)]
 for tape,n,m,q,h in tests:need(execute(a,180,tape,n)==execute(b,180,tape,m)==(q,h,tape),'stage1 case')
 need(execute(b,172,{-1:0,0:0},4)==execute(c,172,{-1:0,0:0},2)==(151,0,{-1:0,0:0}),'stage2 case')
 need([(q,r,w,d)for(q,r),(w,d,z)in b.items()if z==172]==[(116,0,0,1)],'172 entry')
 need([(q,r,w,d)for(q,r),(w,d,z)in b.items()if z==112]==[(172,0,0,-1)],'112 entry')
 need(0 not in(112,172),'initial guard');return True
p=argparse.ArgumentParser();p.add_argument('directory',type=Path);p.add_argument('--out',type=Path);x=p.parse_args();a,b,c=[parse(x.directory/n)for n in('baseline213.native.tm','retimed213.native.tm','u212.native.tm')];check(a,b,c);bad=dict(c);bad[67,0]=(1,1,151)
try:check(a,b,bad)
except RuntimeError:pass
else:raise RuntimeError('corrupt helper accepted')
r={'status':'FOUR_OPAQUE_EXTERIOR_CASES_PASS','stage1_cases':3,'stage2_cases':1,'negative_control':'rejected','scope':'Exact table patches, explicit finite paths and sole-entry guard; ordinary PA induction supplies global halting equivalence.'};s=json.dumps(r,indent=2)+'\n'
if x.out:x.out.write_text(s)
print(s,end='')
