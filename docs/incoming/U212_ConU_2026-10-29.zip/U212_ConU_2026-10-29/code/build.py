#!/usr/bin/env python3
"""Deterministic two-row bypass composition; no heuristic search."""
import json,hashlib,argparse
from pathlib import Path
BASE='bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7'
FINAL='386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4'
def need(x,m):
 if not x:raise ValueError(m)
def emit(t):return '#! start 0\n'+''.join(f'{q} {b} {w} {d} {z}\n' for(q,b),(w,d,z)in sorted(t.items()))
def main():
 p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('out',type=Path);a=p.parse_args();raw=a.baseline.read_bytes();need(hashlib.sha256(raw).hexdigest()==BASE,'baseline hash');T={}
 for l in raw.decode().splitlines():
  if l.startswith('#')or not l:continue
  q,b,w,d,z=l.split();k=int(q),int(b);need(k not in T,'duplicate');T[k]=(int(w),d,int(z))
 T[180,1]=(1,'R',211);mid=emit(T);T[172,0]=(0,'L',67);del T[112,0];del T[112,1];native=emit(T);need(hashlib.sha256(native.encode()).hexdigest()==FINAL,'final hash');Q=sorted({q for q,b in T});need(len(Q)==212 and set(T)=={(q,b)for q in Q for b in(0,1)},'census');need({z for w,d,z in T.values()}-set(Q)=={254},'target closure');ren={q:i for i,q in enumerate(Q)};ren[254]=212;dense={(ren[q],b):(w,d,ren[z])for(q,b),(w,d,z)in T.items()};inv={v:k for k,v in ren.items()};need({(inv[q],b):(w,d,inv[z])for(q,b),(w,d,z)in dense.items()}==T,'renaming');a.out.mkdir(parents=True,exist_ok=True)
 for n,s in [('retimed213.native.tm',mid),('u212.native.tm',native),('u212.tm',emit(dense)),('renaming.json',json.dumps(ren,indent=2)+'\n')]:(a.out/n).write_text(s)
 print(json.dumps({'status':'PASS','states':len(Q),'rows':len(T),'native_sha256':FINAL,'dense_sha256':hashlib.sha256(emit(dense).encode()).hexdigest()},indent=2))
if __name__=='__main__':main()
