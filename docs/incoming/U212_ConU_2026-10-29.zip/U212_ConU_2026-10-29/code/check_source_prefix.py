import argparse,json,hashlib
from pathlib import Path
def need(b,m):
 if not b:raise ValueError(m)
def source_graph(rows):
    indices={p:i for i,(p,_,_)in enumerate(rows)}
    need(len(indices)==len(rows),'duplicate source address')
    ints={}
    def visit(p):
        if p in indices:ans=(indices[p],indices[p]+1)
        else:
            a,b=visit(p+'0'),visit(p+'1');need(a[1]==b[0],'tree order');ans=a[0],b[1]
        ints[p]=ans;return ans
    need(visit('')==(0,len(rows)),'source coverage')
    def jump(p,bit,n):
        for j in range(len(p)-1,-1,-1):
            if p[j]==bit:
                n-=1
                if n==0:return ints[p[:j]][1 if bit=='0'else 0]%len(rows)
        return 0
    graph=[]
    for i,(p,op,arg)in enumerate(rows):
        nxt=(i+1)%len(rows)
        if op=='CD':graph.append([jump(p,'0',1),nxt])
        elif op=='CB':graph.append([jump(p,'0',arg)])
        elif op=='CC':graph.append([jump(p,'1',arg)])
        elif op=='CI':graph.append([nxt])
        else:need(op=='CH','opcode');graph.append([])
    return graph


p=argparse.ArgumentParser();p.add_argument('--sites',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();raw=a.sites.read_bytes();rows=json.loads(raw);G=source_graph(rows);ip=106;R=[1,0,4,0,0,1,0,0,1];trace=[]
for tick in range(141):
 old=ip;before=R.copy();_,op,v=rows[ip]
 if op=='CI':R[v]+=1;ip=G[ip][0]
 elif op=='CD':positive=R[v]>0;R[v]-=int(positive);ip=G[ip][int(positive)]
 elif op in('CB','CC'):ip=G[ip][0]
 else:raise ValueError('early halt')
 trace.append([old,before,ip,R.copy()])
need((ip,R)==(136,[1,0,13,0,0,1,0,0,1]),'endpoint');r={'status':'SOURCE_PREFIX_PASS','steps':141,'initial_ordinal':106,'final_ordinal':ip,'final_registers':R,'source_sha256':hashlib.sha256(raw).hexdigest(),'trace':trace};a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(r,indent=2)+'\n');print(r['status'])
