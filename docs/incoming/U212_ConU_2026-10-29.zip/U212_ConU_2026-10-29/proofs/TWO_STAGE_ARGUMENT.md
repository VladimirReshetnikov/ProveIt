# U212 by stacking two published, compatible reductions

Parent: the ST-transfer U213 in archive `U213_ConPA_2026-10-28 (1)`, native
SHA256 `bb4f5ac12b29d07d1080109af9bb564e9e11a4783efc48cd73b8f826789d01f7`.
It already deletes native50 and implements the 3909-primitive transfer source.
The source-preserving entry bypass from `u213_from_u214_2026-10-28` can be
adapted to this parent because native211, not167, implements its required
selector. This is a composition of credited ideas, not a novel bypass lemma.

Changes:180/read1 becomes1 R211;172/read0 becomes0 L67; delete112.
No source or theory change. Candidate native SHA256
`386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4`.

## Stage A: retime one entrance

Let A be the parent and B differ only at180/read1. All configurations not
reading1 in180 agree for one step. On that branch, both paths leave the
entire tape unchanged and have the same head/control endpoint:

- next bit1: two steps in each machine, endpoint184, head+2;
- next bit0, following bit0: seven A steps versus three B steps, endpoint90,
  head+3;
- next bit0, following bit1: seven versus three steps, endpoint86, head+3.

The literal local traces in `stacking_result.json` read only these explicitly
specified cells. No assumption on exterior tape or prior reachability is used.
Therefore A and B are halting-equivalent from every corresponding configuration
by positive finite paired-block induction. Their exact halting times can differ.

## Stage B: remove the now-redundant entrance

After stage A, the sole incoming172 edge is116/read0, writing0 and movingR.
The sole incoming112 edge is172/read0, writing0 and movingL. Thus at every
reachable172 the left cell is0. Choose comparison boundaries excluding112.
At172/read0, B takes four steps through112 while C takes two through67; both
restore the two known zero cells and end at151 at the original head position.
Every other boundary takes one unchanged step and cannot enter112. Endpoints
again exclude112 and retain the172-left-zero invariant. State0 initially
satisfies this for ANY initial tape. Both blocks have positive finite length
and no interior halt. Determinism and induction partition both runs into
matching blocks, proving halting in either machine iff halting in the other.

The independent checker exhausts6816 five-cell frames for stage A and6768
admitted boundary frames for stage B, rejecting unknown exterior reads. It
checks literal total tables, exact edits/deletion, unique entrances, all
endpoints, and invariant closure. Five mutation controls are rejected.
All checks use explicit exceptions and agree under normal and optimized Python.
These finite facts and elementary inductions are formalizable in PA; no
compiled proof-assistant endpoint or exported PA derivation is claimed.

## Startup and inherited calibration

All three tables execute the identical48140-step blank prefix, never using
either modified row. The exact full tape reaches q84, head-2, header distance56,
source ordinal136/address001100110101010, registers(1,0,13,0,0,1,0,0,1),
43 spare registers equal1, and120 one-cells. The zero exterior is exact.
Compressed traces and independent reconstruction are included.

Since the relative halting theorem is whole-run, not merely primitive runtime,
the parent's complete source/runtime/safe-AX-suffix/credit/Con(U)/Con(PA)
calibration transports directly. No new logical theorem about the transfer
source is needed. The parent's calibration must remain explicit and retained;
the fixed K215/ZFC formal endpoint does not itself certify these new bytes.

No unconditional consistency, unconditional nonhalting, or global minimality
claim is made. Search for still fewer states is separate from this certificate.
