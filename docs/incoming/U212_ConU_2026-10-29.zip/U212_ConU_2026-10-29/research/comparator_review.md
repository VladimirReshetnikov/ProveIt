# Eight incoming U213 approaches: independent classification

Read at ProveIt pin 6b3145c0bbbf7563bd7bce44c974b4515656a5b0. Folder names below refer to the outer extraction directory; duplicate titles are not duplicate constructions. U214 is the common predecessor, not one of the eight new U213 proposals. This review reads reports/proofs and table rows; it does not claim a full replay of all eight.

| Extraction directory | Distinct contribution | Source/calibration change |
|---|---|---|
| U213_ConPA_2026-10-28 | Exchange lower-clause implication antecedents; retain198-node source; allocate with inherited U217 return helper and preceding-zero repair | Numerical emitted bundle changes by proved logical exchange; supplied372-line schematic equivalence proof. Same ordinary consistency endpoint, not merely same source CFG. Native table38767d55… |
| U213_ConPA_2026-10-28 (1) | Direct-transfer ST source plus U214 emitter, then seven-zero detector deleting50 | Major scheduler/command/startup change:3909primitives,197nodes,5084cases, header56. Interior AX startup and protected opaque tail require new credit/compiler proof. Nativebb4f5ac1… |
| U213_ConPA_2026-10-28 (2) | Emitter reassociation/reallocation; repair204/0 to182; delete167 via172 | Same3928primitive CFG and constructor word; different physical layout. Initialization95752steps. |
| U213_ConPA_2026-10-28 (3) | One closed reassociation; contextual reallocation repairs parent reference and deletes215 | Same3928primitive CFG;198nodes;36retained-row changes. Native94081dc0… |
| U213_ConPA_Reduction_2026-10-28 | Emitter reassociation/reallocation; repair101/0 to182; delete167 via172 | Same3928primitive CFG. Different physical layout from (2); initialization95714steps. Native536872eb… |
| U213_ConPA_Reduction_2026-10-28 (1) | Six closed rotations expose tag-separated211/214;155 selector deletes214 | Same3928primitive CFG,199nodes,15changed rows. Native310364de… |
| U213_ConU_2026-10-28 | Eight closed rotations expose tag-separated214/115;155 selector deletes115 | Same3928primitive CFG,199nodes. Earlier16rotation route rejected for bad startup. Native9bd9145a… |
| u213_from_u214_2026-10-28 | Bypass180/1 through167; then known two-zero context eliminates112 via67 | Source and theory literally unchanged; only two retained rows edited,112deleted. Gives direct arbitrary-tape halting equivalence. |

## Compositions worth testing

The bypass112 transformation is a good independent component, but its literal target167 cannot be pasted into the other tables. Its shortcut needs167/read0=(0,R,218) and167/read1=(1,R,184); all seven other proposals alter/remove167 or already delete/reassign112 and172. This was checked against each incoming literal native table, not inferred from prose. Retiming through an equivalent extant decoder is necessary.

The two delete167 proposals are alternate layouts of the same fold mechanism, not two savings to add. Likewise the six/eight-rotation routes use the same155 selector interface with different representatives and preparatory reassociations; their row edits must be recomposed and verified, not counted independently.

The ST direct-transfer route is genuinely complementary: it already saves a detector state through a source-specific header56 proof, leaving112 available. A retimed bypass112 preserving the exact literal ST213 machine gives a clean new212 route without a second arithmetic/compiler calibration. That is the current promising composition; the finite shortcut proof must use the actual ST table, its complete incoming lists, and no hidden halt.

## ST213 inherited endpoint review

Read proofs/startup_suffix.tex, command_semantics.tex, compiler.tex, source_transport.tex, runtime_checker_review.txt in ConPA(1). No gap identified in the ordinary mathematical chain, with the following dependencies explicit:

1. The physical blank frame is at ordinal136 after48140steps, header distance56, not a clean N4 root or the old ST215 startup. It has registers(1,0,13,0,0,1,0,0,1),43one-valued spares and an exact finite-support tape.
2. A finite141-source-step prefix from ordinal106 and registers(1,0,4,0,0,1,0,0,1) reaches the same logical interior frame. The suffix contract is proved for all natural inputs using the pinned arithmetic macros and exact source binding, not sampled giant integer evaluations.
3. Two actual residual-pointer reads yield a=0,b=2,L=0. The incoming cache1 is used only as an arithmetic parameter; it is not generalized as a theorem. The gate is disabled because c=a=0. The suffix yields nine explicit theorem heads over arbitrary tail4, zero top/cache, and next candidate1.
4. Ghost stack length avoids assuming that Cantor code0 identifies an empty list. Credit analysis gives maximum conservative debt2 starting at candidate1, leaving margin7. Thus unsafe tail4 is never exposed. The diagonal induction uses only previous candidates and handles W0,W1,W2 explicitly.
5. The strong compiler permits arbitrary top/stack but resets counter/cache with AX. Generated implication/quantifier tags prevent unintended falsity tests in helper macros. The raw I(0,0)=0 exception is explicitly handled by J0 being the empty word. Cofinal successful candidate codes and decreasing residual parsing prove completeness from every finite candidate cutoff.
6. The literal all-natural runtime must use header56+g (not64+g); the reviewed report explicitly parameterizes both initial and target frames and preserves the lower-bound gap invariant.

Consequently a PA-formalizable exact literal212/ST213 halting equivalence can inherit the endpoint directly. It does not need a new interior-startup theorem or a claim that the212 table implements identical primitive boundaries. Fresh baseline replay is valuable verification of the inherited artifacts. These remain ordinary mathematical proofs and executable certificates; no new kernel-checked PA/Lean/Rocq/MM0 endpoint follows merely from this audit.
