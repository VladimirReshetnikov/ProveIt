#!/usr/bin/env python3
"""Offline release replay; sealed package is never modified."""
import argparse,hashlib,json,os,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent
def need(x,m):
 if not x:raise RuntimeError(m)
def hashes():return{str(f.relative_to(P)):hashlib.sha256(f.read_bytes()).hexdigest()for f in P.rglob('*')if f.is_file()and '__pycache__'not in f.parts and f.name!='MANIFEST.json'}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--full',action='store_true');a=ap.parse_args();before=hashes();need(before==json.loads((P/'MANIFEST.json').read_text()),'sealed file integrity');stages=[]
 with tempfile.TemporaryDirectory(prefix='u212-release-')as d:
  W=Path(d);env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONOPTIMIZE',None)
  def run(label,args):
   r=subprocess.run([sys.executable,*map(str,args)],cwd=W,env=env,capture_output=True,text=True);need(r.returncode==0,label+'\n'+r.stdout[-2000:]+'\n'+r.stderr[-2000:]);stages.append(label);print('PASS',label,flush=True)
  C=P/'code';I=P/'inputs';M=P/'machine'
  with zipfile.ZipFile(I/'ST_U213.zip')as z:
   for n in z.namelist():need((W/n).resolve().is_relative_to(W),'unsafe archive path')
   z.extractall(W)
  B=W/'U213_ConPA_2026-10-28';need((B/'machine/u213.native.tm').read_bytes()==(I/'baseline213.native.tm').read_bytes(),'baseline binding');need((B/'machine/sites.json').read_bytes()==(M/'sites.json').read_bytes(),'unchanged source')
  run('inherited ST213 replay'+(' full'if a.full else' finite'),[B/'reproduce.py',*(['--full']if a.full else[]),'--report',W/'baseline.json'])
  for opts,n in[([], 'normal'),(['-O'],'optimized')]:
   R=W/n;run('deterministic construction '+n,[*opts,C/'build.py',I/'baseline213.native.tm',R])
   for f in('u212.native.tm','u212.tm','renaming.json'):need((R/f).read_bytes()==(M/f).read_bytes(),'build output '+f)
   need((R/'retimed213.native.tm').read_bytes()==(I/'retimed213.native.tm').read_bytes(),'intermediate table');shutil.copyfile(I/'baseline213.native.tm',R/'baseline213.native.tm')
   for f in('check_stacking.py','check_startup_blocks.py','check_dense.py'):shutil.copyfile(C/f,R/f)
   run('two global stuttering certificates '+n,[*opts,R/'check_stacking.py'])
   run('independent dense conjugacy '+n,[*opts,R/'check_dense.py'])
   run('four opaque-exterior cases '+n,[*opts,C/'check_small_certificate.py',R,'--out',W/(n+'-small.json')])
   run('three-table exact startup '+n,[*opts,R/'check_startup_blocks.py'])
   run('independent interior startup '+n,[*opts,C/'check_st_startup.py','--table',M/'u212.native.tm','--sites',M/'sites.json','--output',W/(n+'-startup.json')])
   run('independent source prefix '+n,[*opts,C/'check_source_prefix.py','--sites',M/'sites.json','--output',W/(n+'-prefix.json')])
  run('input safeguards and optimized-runtime refusal',[C/'code56/check_negative.py','--table',M/'u212.native.tm','--sites',M/'sites.json','--output',W/'negative.json'])
  if a.full:
   run('new U212 universal runtime',[C/'code56/check_runtime.py','--table',M/'u212.native.tm','--sites',M/'sites.json','--output',W/'runtime.json'])
   need(json.loads((W/'runtime.cases.json').read_text())==json.loads((P/'evidence/runtime.cases.json').read_text()),'universal outputs changed');r=json.loads((W/'runtime.json').read_text());need(r['cases']==5084 and r['working_states']==212,'runtime count')
 need(hashes()==before,'sealed files changed');print(json.dumps({'status':'PASS','full':a.full,'stages':len(stages),'sealed_files':len(before),'checks':stages},indent=2))
if __name__=='__main__':main()
