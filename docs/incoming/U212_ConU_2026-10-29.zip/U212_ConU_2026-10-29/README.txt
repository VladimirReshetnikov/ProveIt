U212 ConU reduction — 29 October 2026

212 working states,424 binary transitions, separate halt. One head, one
bi-infinite initially-zero tape; initial state0; every move L or R.
Dense working labels0..211, halt212. Native halt254 is not a working state.

NEW RESULT
Two row changes and one state deletion combine two distinct incoming U213
proposals. The ST-transfer machine already contains helper211 with the
required behavior; copying the other proposal's helper167 would be wrong.
The source, theory, and startup program are otherwise unchanged.

  180/read1 -> 1 R211
  172/read0 -> 0 L67
  remove native112

The new ordinary proof establishes PA-provable halting equivalence with the
exact ST-U213 table, on arbitrary binary tapes in initial state0. Its two
positive finite stuttering simulations also give conditional non-slowdown
on every halting input. Composing with the explicitly inherited ST-U213
calibration gives nonhalting iff Con(U), equivalently Con(PA), provably in PA.
No new kernel certificate, unconditional consistency, or minimality claim.

IMPORTANT CALIBRATION
The inherited startup is NOT the older N4 root. It takes48140steps to an
interior AX frame at ordinal136, header56, logical registers
[1,0,13,0,0,1,0,0,1],43sparesall1. The inherited suffix proof wraps unsafe
tail4 under9 theorem heads; candidate1 has conservative credit2, leaving
margin7. The new literal equivalence does not change these dependencies.

REPLAY (Python3 standard library, offline)
  python3 reproduce.py
  python3 reproduce.py --full
The full command freshly replays the inherited ST-U213 packet (including
5084 universal cases) and all5084 new U212 cases. Finite independent checks
also run under -O; the assertion-dependent runtime engine refuses -O and
this refusal is checked. Replay writes only to a temporary directory and
checks all sealed package files remain unchanged.

CONTENTS
paper/: editable TeX, PDF, complete dense table.
machine/: native and dense tables, exact renaming, unchanged source.
inputs/: immutable ST-U213 and bypass-U213 archives plus native inputs.
code/: deterministic builder, finite proof checkers, startup/source checks,
       inherited symbolic engine adapted to native labels/header56.
evidence/: recorded receipts; research/: eight-proposal comparison and hashes.
proofs/: readable proof arguments and evidence boundaries.

NATIVE SHA256
386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4
DENSE SHA256
c979e55e6a6f75b08effdf67067cceb460e30a4c28aef9c79797d0a6d32a074e
