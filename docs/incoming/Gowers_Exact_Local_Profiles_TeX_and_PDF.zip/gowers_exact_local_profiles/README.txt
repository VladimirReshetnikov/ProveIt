EXACT LOCAL PROFILES AND STRUCTURAL BARRIERS
IN GOWERS' SZEMEREDI FRAMEWORK
Research manuscript prepared with ChatGPT for Vladimir Reshetnikov
7 October 2026

START HERE

gowers_exact_local_profiles.pdf is the complete article.
gowers_exact_local_profiles.tex is the complete assembled TeX source.
The figures/ directory contains its two required PDF figures.

The manuscript proves four families of local results:

1. An exact missing-arc formula for unequal Fourier budgets on a stated
   strict matrix-certificate region, including an open neighbourhood of
   every interior common-budget point in the first window. It includes
   the fixed-certificate optimality polytope, exact Hessian rank, a rational
   example, and an aligned finite-grid O(N^-2) approximation.

2. The full positive cubic affine-error profile for elementary abelian
   3-targets, with color/rank remainders and equality cases; sharp strict
   recovery thresholds 1/4 (arbitrary finite abelian domains) and 4/9
   (elementary abelian 3-domains); and the exact non-affine energy maximum
   N^3-4N^2+10N-6 for N >= 13. The cutoff 13 is optimal.

3. The exact local interpolation candidate cost E_t(L_1,...,L_r), removing
   the redundant sum L_i. Dense examples prove optimality within the
   specified interface, including robust deletion and partition tradeoffs.

4. Complete independent norm-block classification with no degree cap for
   symmetric progression lengths 4, 6, 8, or general length 2m when
   q >= (2m-1)^2. The maximum dimension is r*m^2. Eleven exact degree-nine
   irreducibility certificates close the eight-term small-field cases.

The article distinguishes these results from previously proved inputs,
states all scopes, and proposes eleven main further-research questions,
with additional specialized interpolation problems. It
does not establish a new global quantitative Szemeredi bound, solve the
unrestricted scalar quintic-colouring problem, or assert exhaustive
historical priority. Independent internal mathematical reviews were
performed; no external peer review or Lean verification is claimed.

BUILD

From this directory:

  bash build.sh

This runs:

  latexmk -pdf -interaction=nonstopmode -halt-on-error \
    gowers_exact_local_profiles.tex

Alternatively, run pdflatex three times. A conventional TeX Live installation
with the packages listed in the preamble suffices. There is no external
bibliography file or network requirement for compilation.

The editable assembly sources are frontmatter.tex, endmatter.tex, and the
four files under sections/. After editing those, regenerate the complete
source with:

  python3 code/assemble.py

Do not run the assembler after editing only the complete TeX file unless
you intend to replace those edits with the section sources.

VERIFICATION

Run from this directory without Python's -O flag:

  python3 verification/verify_fourier.py
  python3 verification/verify_rigidity.py
  python3 code/verify_interpolation.py
  python3 code/verify_order13.py
  python3 code/norm_blocks_verify.py --full

The exact rigidity, interpolation, and norm programs use Python's
standard library. The order-thirteen enumeration uses numpy with integer
arrays. The Fourier diagnostics need numpy, scipy, and sympy. Optional
figure regeneration additionally needs matplotlib:

  python3 verification/make_figures.py

requirements.txt lists those optional scientific dependencies. The
order-thirteen enumeration and full norm counts are the longer checks.
The recorded JSON results are included.

General theorem proofs are in the article. Only the eleven irreducibility
certificates form a finite computation used in a theorem. The exhaustive
tests and floating-point diagnostics do not prove the general statements.
The Fourier output is explicitly numerical, except for its SymPy identity.

PROVENANCE AND INTEGRATION

SOURCE_LEDGER.json records the inspected repository blobs and hashes of
recent project working manuscripts. INTEGRATION.txt maps results to their
baseline locations and explains the intended formalization boundaries.
reviews/REVIEW_SUMMARY.txt records the internal review coverage.
VALIDATION.json records the final build and inspection status.
SHA256SUMS.txt covers the distributable files other than itself.

No repository commit, pull request, or external publication is made by
this package. It is the reviewable article and supporting material for
subsequent integration into ProveIt.
