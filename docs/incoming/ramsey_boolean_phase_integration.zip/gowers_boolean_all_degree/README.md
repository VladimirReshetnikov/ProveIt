# Sharp All-Degree Boolean Phase Integration

**Contraction radicals, extremal flags, and optimal finite-dimensional obstruction models**

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov and the ProveIt project, 6 October 2026.

## Main results

For symmetric genuinely d-linear tensors on F_2^n, with the normalized selected derivative energy defined in the article:

1. The exact maximum energy of a nonintegrable tensor is `1 - (d+1)/2^d` for every `d >= 3`, `n >= 2`. This closes the degree-seven question and all higher-degree gaps left by the identified source-47 manuscript. Its canonical all-degree computation is credited and reproved, not presented as new.
2. For `d >= 4`, all extremal tensor classes modulo integrable tensors are canonical classes indexed by flags `line < plane` in the dual space. Every noncanonical nonintegrable tensor has energy at most `1 - 3d/2^(d+1)`; the difference `(d-2)/2^(d+1)` is a proved separation, not a claimed optimal second extremal gap.
3. The contraction-integrability radical `R(T) = {z : T_z is integrable}` yields the rank-sensitive energy bound `1 - d*(1-2^(-rho))/2^(d-1)`, where `rho = codim R(T)`.
4. The exact minimal quotient dimension modulo integrable tensors is `codim K(T)`, where K is the radical of the repeated defect in every slot. It is at most `rho + sum(binomial(rho,j), j=1..min(rho,d-2))`. Explicit tensors attain this dimension for every pair `d >= 4`, `rho >= 1`.
5. For a prescribed splitting `V = H + R_0` with `R_0` contained in the contraction radical, the space of obstruction classes is exactly the direct sum of the obstruction classes on H and `Hom(R_0, I_(d-2)(H))`. This is a linear normal form, not classification up to all coordinate changes.

The paper includes complete proofs, an explicit primitive, exact noisy-selector margins, an algorithm for quotient certificates, a formalization roadmap, and ten further research questions.

## Files

- `article.tex`: standalone source, with embedded bibliography.
- `article.pdf`: compiled from that source, 25 pages.
- `code/verify.py`: exact finite regression verifier, standard library only.
- `data/verification.json`: output of the delivered verifier.
- `SOURCES.md`: inspected sources, comparison, and novelty boundaries.
- `FORMALIZATION.md`: proposed definitions and dependency order; no Lean proof-status claim.
- `Makefile`: build and verification commands.

## Reproduction

```sh
python3 code/verify.py --max-degree 12
python3 -O code/verify.py --output /tmp/boolean-verification-optimized.json
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Python 3.10 or later is sufficient. The code uses integers, Gaussian integers, exact rational numbers, and GF(2) row reduction; no floating-point optimizer, network access, or nonstandard Python dependency is needed. pdfLaTeX requires ordinary TeX Live packages including `lmodern`, `amsmath`, `amssymb`, `amsthm`, `mathtools`, `microtype`, `booktabs`, `enumitem`, `fancyhdr`, `hyperref`, `xurl`, and `bookmark`.

## Verification scope

The default verifier checks 16,368 symmetric binary tensors across degrees 3–12; all 32,768 symmetric quartic tensors on F_2^3; 12 sharp model constructions; 100 fixed-radical normal-form dimension cases; 2,040 integrable lowering/contraction cases; and exact small-group complex-function, slicing, and period identities. It also checks the rational induction formulas through degree 1000.

The binary energies are constant-function energies, **not** continuous optimizations. The general theorems are proved in the manuscript. A test report is not a proof-assistant certificate. Checks remain active with Python's `-O` flag.

## Integration into ProveIt

Suggested destination is a new standalone subdirectory of:

```text
Combinatorics/Ramsey/Research/GowersSzemeredi/
```

Alternatively, use the repository's next available source number in the local-quantitative-refinements collection. Do not overwrite sources 43 or 47; this is a continuation of their results. Theorem labels use the `bad:` prefix to reduce collisions during editorial merging.

No repository file was changed. No existing Lean theorem is replaced. The Boolean homogeneous multilinear model differs from the cyclic multiaffine interface of `proposition_17_2`. A proof-status ledger should not mark this article as formalized.

## Status

Unrefereed research manuscript. The new statements are improvements relative to the inspected project baseline. Historical first priority has not been certified. No improved global bound for Szemerédi's theorem, low-energy inverse theorem, arbitrary-selector symmetrization, or general optimizer-descent principle is claimed.
