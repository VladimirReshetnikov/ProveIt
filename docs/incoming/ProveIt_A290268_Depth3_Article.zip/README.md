# Depth Three Is Complete for OEIS A290268

This package contains a research article and an exact certificate for the theorem

```text
gamma(k, 3, M) = 0  iff  M = k + 13 and k is odd
```

for all integers `k >= 0`, `M >= 3`, where

```text
gamma(k,D,M) = [w^M] (2+w)^k ((1+w)^2 log(1+w))^D.
```

The theorem resolves the complete `D = 3` stratum of the coefficient-support problem described in the ProveIt repository at commit
`a02ab3567fef25793b27a68248b58a7b69694342`.

## Files

- `proveit_a290268_depth3.tex` - article source.
- `proveit_a290268_depth3.pdf` - compiled article.
- `verify_depth3.py` - exact standard-library verifier.
- `depth3_certificate.txt` - deterministic verifier output.

## Verify the exact certificate

```bash
python3 verify_depth3.py
```

The script uses `fractions.Fraction` only. No floating-point value is used in an assertion. It rewrites `depth3_certificate.txt` and exits with status 0 on success.

## Build the PDF

From this directory:

```bash
pdflatex -interaction=nonstopmode -halt-on-error proveit_a290268_depth3.tex
pdflatex -interaction=nonstopmode -halt-on-error proveit_a290268_depth3.tex
```

The article is not yet formalized in Lean or Rocq and has not been independently peer reviewed. Its finite proof component is explicitly isolated and reproducible.
