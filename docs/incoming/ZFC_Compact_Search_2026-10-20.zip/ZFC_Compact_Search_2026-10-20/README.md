# Compact ZFC consistency machines: DN4 and searches below 225

**The requested strict improvement was not attained. No machine with fewer
than 225 states is claimed to satisfy the goal in this packet.**

The positive construction is a new **225-state**, two-symbol, single-tape,
blank-input machine. A double-negation normalization of its numeric axiom
constructor removes 376 primitive source occurrences while preserving the
consistency calibration. The complete table still needs 225 working states,
including initialization. A separate halt state is excluded from that count.

Read [report/report.pdf](report/report.pdf) for the full mathematical argument,
exact transition-table delta, complete table, verification scope, and measured
alternative routes. The editable TeX sources are next to the PDF.

## Exact accepted machine

| File | Working labels | Start | Dispatcher | Halt |
|---|---|---:|---:|---:|
| `machine/k225_dn.tm` | 0 through 224 | 0 | 83 | 225 |
| `machine/k225_dn.klabels.tm` | 225 distinct K-labels, with gaps | 0 | 84 | 254 |
| `machine/k225_dn.legacy.tm` | 225 distinct legacy labels, with gaps | 95 | 96 | 254 |

All three tables describe the same machine up to the checked bijections in
`machine/renumbering.json`. A row `q b w D t` means: in state `q`, reading `b`,
write `w`, move left or right as specified by `D`, and enter `t`.

The canonical table SHA-256 is:

```text
07d778756d4a061933ecc726ccca4c1f321122380c707e9a2638ab24fdfb7048
```

The tape is indexed by the integers, initially all zero, with the head at 0.
There are no stationary moves, extra symbols, supplied input program, or
uncounted startup states.

## Reproduce the construction

Python 3.10 or later and its standard library suffice. Keep assertions enabled.
Choose an output directory **outside this unpacked packet**.

```sh
python3 reproduce.py --output-dir /tmp/zfc-dn4-quick
python3 reproduce.py --full --output-dir /tmp/zfc-dn4-full
```

The default command performs exact source and table reconstruction, checks the
source-level formula obligations, audits the retained universal runtime
certificate, and recomputes the whole blank startup using two independent tape
representations. It does not rerun the universal symbolic runtime proof.

`--full` also rederives every universal primitive contract from the literal new
table. The recorded fresh run proves 6,168 guarded cases, uses all 450 table
rows, and takes 1,483,121 symbolic proof steps. Primary counters, gap, and spare
list are unbounded; the finite symbolic proof-construction limit is not a bound
on the represented computation. Full replay also reconstructs the exact
409,835-transition blank startup and all 351 nonzero tape cells at its endpoint.

Add `--baseline-audit` to freshly replay the original K225 construction and its
6,656 universal runtime cases as well:

```sh
python3 reproduce.py --full --baseline-audit \
  --output-dir /tmp/zfc-dn4-with-baseline
```

Everything required for these commands is retained in the packet. The original
`inputs/K225_Construction_2026-10-19.zip` is pinned by SHA-256 and extracted
locally. No network access is used. `receipts/portable_full_replay.json` and
`receipts/replay_logs/` record a fresh successful run of the portable script.

## What is proved, and what is not

The complete argument has three components:

1. The inherited calibration connects K230's numeric calculus to contradiction
   proofs in ordinary ZFC. The original exact 230-state endpoint is an external,
   axiom-free Rocq theorem.
2. `report/full_dn_proof.tex` proves that the changed axiom constructor yields
   exactly the same numeric theorems. Its two directions are effective finite
   proof translations. `verification/verify_full_dn_semantics.py` checks the
   finite syntactic obligations for the exact source and macros.
3. The fresh ordinary mathematical runtime certificate connects the new literal
   225-state binary table to that changed source, for unbounded counters and
   spare lists, from the exact inherited seed.

Together these give an ordinary mathematical proof, formalizable in ZFC, that
the new machine does not halt exactly when ZFC is consistent. **This packet does
not contain a newly kernel-checked end-to-end theorem for the new table.**
The generic positive-block transport theorem and arithmetic pairing lemma in
`proofs/` were independently compiled and kernel-checked; their narrower scope
is recorded explicitly. They do not replace the complete new endpoint.

## Other useful results

The research packet includes:

- An inductive finite abstraction of the unbounded source registers, checked
  against 6,162 nonempty control edges. It proves that the general comparison in
  NIP is a test against the constant 1 on every reachable entry.
- A mathematically correct source specialization of that test, and a concrete
  counterexample showing why its first binary compilation is wrong.
- Exact failed scanner and arithmetic-negation reductions. Experimental tables
  are clearly marked; no rejected 224-state table is presented as a solution.
- A conditional proof of 6,083 universal primitive cases for the shortened
  scanner, with the 85 excluded cases and a separate seven-zero startup
  obstruction stated explicitly. The completed layout walk reduces six-zero
  source leaves from 43 to 39, but does not remove them.
- Measured K/S/Peirce, parameter-permutation, and command-permutation encodings,
  with their distinct verification scopes.
- A new ordinary calibration argument connecting the repository's existing
  canonical equality-vacuity idea to the exact current K230 source. The direct
  source probe costs 227 states. A finite NBG front end is also considered;
  unimplemented routes have no asserted state count.
- Reproducible C++ fold searches, including a restricted-domain pass examining
  747,955,300 helper combinations with no reduction in that bounded family.

See `experiments/README.md` and the separate handoff READMEs for the scripts,
input pins, and exact limitations. These are finite search results, not a lower
bound on possible consistency machines.

## Rebuild the PDF

The table appendix is derived from the literal canonical machine:

```sh
python3 report/build_report_assets.py
cd report
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

## Provenance and integration

This packet was prepared against ProveIt commit
`ad8cbe8249445f43408617e88a0edb668b00248d`, using the K225 archive introduced at
commit `680f05870`. The inherited K230 formal development is pinned at
`3142e4dd980f0be12f4abb636c4ae2528afc17eb`.

It can be incorporated as a standalone research subdirectory. No public commit,
pull request, or repository modification was made. Retain the original archive
and its attribution notices if redistributing this packet. `PROVENANCE.md`
distinguishes new artifacts from unchanged upstream dependencies.
