# Report188 Sequential Power Rounding

This package contains the self-contained English article, editable LaTeX source,
original exact Python code, and bounded attributed OEIS integer fixtures for
sequential rounding down to multiples of `j^p`, for a fixed real `p>0`.

## Main result

If `A_p(n)` is the first zero index and `B_p(k)` is the least integer initial
mass surviving level `k`, then

- `B_p(k) = K_p k^(p+1) + O_p(k^((p+1)^2/(p+2)))`
- `A_p(n) = (c_p n)^(1/(p+1)) + O_p(n^(1/((p+1)(p+2))))`
- `c_p = 1/K_p = p Gamma(p/(p+1))^(p+1)`

The report proves explicit all-index threshold envelopes, a globally uniform
minimal mass profile, positive-terminal-mass thresholds, and their limiting
inverse curve. The exact code implements rational powers using integer
comparisons and checks the threshold conventions independently.

OEIS A082527 and A082528 are the square- and cube-power cases. The all-real-power
leading conjecture is recorded in A082528. For `p=1`, the leading threshold and
`O(k^(4/3))` error are classical; no stronger first-power result is claimed.
The positive-terminal threshold theorem requires `h>=1`: `B_p(k,0)=0`, whereas
the limiting cost of positive mass at zero normalized quotient is `Phi_p(0)=K_p`.

No bounded stopping-index error, all-orders discrete-threshold expansion,
growing-parameter uniformity, or worldwide priority claim is made. The report's
Gamma parameter expansion is classical and separate from discrete rounding
fluctuations. Optional floating diagnostics are not interval certificates.

## Quick exact replay

Python 3.10+ and its standard library suffice. From this directory:

```sh
python3 -I -B reproduce.py
python3 -I -B test_build.py
```

The first command runs the mathematical checker normally and under `-O`, requires
byte-identical results, and prints a deterministic summary. The second runs
adversarial package checks. Neither needs TeX or network access.

To save results, choose a fresh destination outside this directory, whose parent
already exists:

```sh
python3 -I -B reproduce.py --output-dir "$(dirname "$PWD")/report188-replay"
```

For individual checks and their full finite domains, see `code/README.md`.
The required suite includes 342 OEIS terms, independent forward threshold search,
exact rational Gamma-product identities, and explicit invalid-input/corruption
checks. Finite computation supports the conventions and identities; the article
contains the all-real-parameter proofs.

## Offline release build

An installed pdfLaTeX distribution, packages, and fonts are additionally needed.
No downloads occur. The output parent must exist and the output directory must
be new:

```sh
python3 -I -B build.py --output "$(dirname "$PWD")/report188-release"
```

The output contains `Report188.pdf`, `Report188.tex`, `Report188_code.zip`, and
`ARTIFACTS.json`. The builder runs the exact and adversarial suites normally and
under optimization, compiles three times, rejects every final TeX warning and
bad box, checks source immutability, and writes a closed-inventory deterministic
archive. An extracted release can be verified with:

```sh
python3 -I -B verify_manifest.py
```

See `README_REPRODUCIBILITY.md` for exact schemas, toolchain requirements,
path/output guards, extracted rebuilds, and the limits of byte reproducibility.
No arbitrary-toolchain byte identity or security sandbox is claimed.

## Contents and attribution

- `Report188.tex`: full definitions, results, proofs, historical scope, and references
- `code/`: exact rational implementation, required checker, separate float diagnostic
- `data/`: bounded integer fixtures with source and license attribution
- Build/verification scripts and reproducibility documentation

`DATA_SOURCES.md` identifies the references. OEIS-derived fixtures are licensed
CC BY-SA 4.0 with attribution in `data/README.md` and the fixture JSON.
The manuscript and Python implementation are original authored material. Full
OEIS records, external papers, private research notes, and transient build files
are not distributed.
