# K228: transferring ProveIt reductions to Glazer's K230

**Result: an explicit 228-state, two-symbol, one-tape Turing machine whose blank-tape nonhalting is equivalent to `Con(ZFC)`.** The archive provides an ordinary mathematical proof, universal executable runtime certificates, exact initialization proofs, deterministic construction, and an editable LaTeX/PDF report.

The new transfer composes two ProveIt reductions with Elliot Glazer's released K230 construction. It deletes K230 states **79 and 140**, changes eight retained transition rows, and adds no states. The theory K and its numerical axiom encoding remain Glazer's released encoding. The inherited logical endpoint is his Rocq theorem for K230; **this release does not claim a newly compiled Rocq theorem for K228**.

## Primary artifacts

- `report/k228-transfer.pdf` and `report/k228-transfer.tex`: complete report, ordinary proof, exact transfer accounting, source and runtime semantics, reproduction instructions, and all 456 canonical transition rows. The other `.tex` files are included source sections and generated table/hash data.
- `machines/k228.tm`: **primary canonical table**, working states `0..227`, initial state `0`, separate halt `228`. The tape is indexed by the integers, initially all zero; the head starts at cell zero. Every row writes a bit and moves one cell `L` or `R`.
- `machines/k228_original_labels.tm`: the same machine in K230 labels, retaining `0..229` except `79,140`; initial state `0`, dispatcher `84`, separate halt `230`.
- `machines/renumbering228.json`: complete bijection between these representations. The canonical dispatcher is `83`.
- `machines/sites228.json`: complete 5,121-leaf structured register source.
- `code/`: standard-library-only construction and mathematical verification.
- `evidence/`: complete construction, initialization, local fold, composition, and universal runtime receipts, including all per-case affine time/motion certificates.
- `exploration/shared_decoder228/`: a second fully verified **228-state** layout, with portable builder, full runtime proof and restricted-search logs. It is a research lead at the same state count.
- `provenance/`: exact upstream revision, preserved local K230 source ZIP, attribution, source audit and historical independent audit notes.

## Exact identity

Canonical `machines/k228.tm` SHA-256:

```text
06726bd731f3a42e3ccd1c4189d80af74ba2d486e333045097480fcaa3313001
```

Original-label table SHA-256:

```text
2b791ed22523b9610d43d7440631b27063089d2d1a24cf3bfbe5ace6cf416ea2
```

The baseline is [elliotglazer/k230-rocq](https://github.com/elliotglazer/k230-rocq) at commit `3142e4dd980f0be12f4abb636c4ae2528afc17eb`; its exact `k230.tm` and `sites230.json` bytes are under `inputs/`. The ProveIt comparison is commit `0128d662fd46f72dc84505176ae8ec28affb2d9d` (235-state package). See `PROVENANCE.md` for the original compiler and verification lineage and license scope.

## What transferred

| Earlier ProveIt reduction | K230 result |
|---|---|
| `27 -> 15` | Already represented by folded K state 11. |
| `39 -> 17` | Already represented by folded K state 13. |
| `90 -> 72`, after the transfer-plus-one loop rotation | Newly applied as **K79 -> K63**. |
| Context split deleting 218 | Not ported: caller tags and helper contexts differ. |
| `169 -> 80`, with a coordinated helper edit | Newly applied as **K140 -> K71**. |
| `235 -> 98` | Not ported: corresponding decoder pair absent. |
| Repurposed `223 -> 182` after rotation | Depends on preceding transformations that were not ported. |
| `193 -> 74` after seven rotations | Required large source fragments and decoder pair do not match. |

The established saving is **230 - 2 = 228**. The four unported reductions remain open; no impossibility or state-minimality result is claimed.

At four exact source positions the construction replaces

```text
((CD6,(CI5,CC2)),CI5) -> (CI5,(CD6,CC2)).
```

Both closed fragments terminate for all natural register values, send `(R5,R6)=(a,b)` to `(a+b+1,0)`, preserve every other register, and have the same normal exit. This is a contextual source macro equivalence. The report proves it by induction and then checks the complete final binary implementation.

## Reproduce

Use Python **3.10 or later**, with assertions enabled. No external Python packages, network, Rocq compiler, or source optimizer is needed for the new ordinary verification. Run from this directory:

```sh
python3 -B code/reproduce.py
```

This reconstructs and checks all primary artifacts, repeats the exact initialization with independent implementations, repeats the optional local loop fold, **recomputes all 6,656 universal runtime cases**, and checks source/frame composition. New receipts go to `rerun/`. Typical universal runtime proof time in the research environment was about 140 seconds.

For a short check that repeats structural/startup proofs and validates the identity and completeness of the already recorded runtime evidence:

```sh
python3 -B code/reproduce.py --quick
```

To recompute the baseline's full 6,660-case universal runtime as well:

```sh
python3 -B code/reproduce.py --baseline
```

To construct fresh standalone machine/source artifacts without modifying this package:

```sh
python3 -B code/build_k228.py --output-dir rebuilt
```

The builder supports `--k230-dir PATH` or explicit `--machine FILE --sites FILE`; it rejects any input whose exact pinned bytes differ. `--check` rebuilds in memory and compares all eight generated artifacts against this package, including the canonical state bijection.

To regenerate the report data and compile the PDF:

```sh
python3 -B code/render_report_data.py
cd report
pdflatex -interaction=nonstopmode -halt-on-error k228-transfer.tex
pdflatex -interaction=nonstopmode -halt-on-error k228-transfer.tex
```

The primary verification does not execute the archived upstream Rocq build scripts. Reproducing Glazer's separate kernel proof requires that release's pinned dependencies and toolchain; follow its preserved README. Its recorded versions are Rocq 9.1.0, `rocq-stdlib` 9.0.0, and OCaml 4.14.2.

## Completed evidence

| Quantity | K230 baseline | Primary K228 |
|---|---:|---:|
| Working states | 230 | 228 |
| Source leaves | 5,125 | 5,121 |
| Guarded instruction cases | 6,660 | 6,656 |
| Symbolic induction rule applications | 1,605,903 | 1,614,426 |
| Maximum proof rules per case | 415 | 415 |
| Minimum concrete instruction duration | 13 | 13 |
| Covered transition rows | 460/460 | 456/456 |
| Exact blank initialization steps | 408,419 | 409,835 |

Both boots reach precisely the same entire tape: dispatcher `84`, head `-5`, marker `-6`, header `176`, 351 one-cells, physical primary registers `[0,0,0,3,0,0,3,0,0]`, and 167 spare blocks of value `1`.

The runtime proof quantifies over nine independent natural primary values, both decrement guards, arbitrary nonnegative extra gap, an arbitrary first spare and an arbitrary finite spare tail. Its unary and list traversals have induction proofs rederived on each exact table. The 4,000-rule per-case cap bounds **proof construction**, not register values or concrete runtime.

An independent source/frame checker verifies all 6,655 nonhalting successor identities, including implicit zero padding and all three counter-overflow cases. Every simulated instruction has positive finite duration, so the runtime boundaries are cofinal in time. These facts establish both directions of the halting equivalence, including the actual nonzero seed.

## Mathematical and formal status

The ordinary proof composes

```text
Halt(K228, blank) <-> Halt(K230, blank) <-> ZFC proves a contradiction.
```

The finite computation, natural/list induction and particular finite-proof translation arguments are formalizable in ZFC, giving the requested ordinary proof of `Nonhalt(K228) <-> Con(ZFC)`. The report states this scope explicitly. No assertion that ZFC is consistent, no new formalized internal PA proof, and no new Rocq kernel check is made.

Glazer's K theory and the released 230-state axiom-free Rocq endpoint are prior work. The new contribution is the verified transfer and composition of two previous ProveIt reductions on that baseline. No existing repository was modified or published by this research session.
