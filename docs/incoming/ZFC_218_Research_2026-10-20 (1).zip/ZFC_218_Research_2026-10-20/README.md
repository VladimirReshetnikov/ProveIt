# Research toward a 218-state ZFC machine

**Status: the requested ≤218-state construction has not been established.**

This packet contains rigorous partial results, an alternative calibrated
219-state construction, and explicitly uncalibrated experiments. Do not cite
the enclosed 218-state table as a machine whose blank non-halting is proved
equivalent to Con(ZFC), and do not use it to assert a new BB(218) bound.

The main deliverable is `report.pdf`, with all sources in `report.tex` and
the included section files. The report distinguishes mathematical proofs,
finite diagnostics, unbounded symbolic primitive proofs, and blank startup.

## Main results

1. **An unbounded formalism obstruction.** The full native calculus,
   including the support-bearing set-theoretic seed, has a model provable
   in ZFC when the independent fourth field of its Łukasiewicz scheme is
   replaced by any finite implication term in the first three fields,
   truth, falsum, and arbitrary Boolean-valued side expressions. The
   obstruction covers all such terms simultaneously. It is not merely a
   failure of propositional completeness. Two additional full-calculus
   countermodels cover precise restrictions augmented by Peirce's law.

2. **A sound residual-parameter proof search.** An asymmetric equality test
   always clears the cache register but can leave another scratch counter
   dirty. Clearing that counter between the two freshness tests and
   transferring later residuals into the free additive command parameter
   gives a sound and complete consistency search. Explicit reset and proof
   compiler blocks establish the source theorem. The source has 208 DAG
   nodes, so this has not yet improved the binary state bound.

3. **An exact clean 219-state variation.** Replacing selected breaks by
   decrements whose counters are locally known to be zero preserves the
   clean equality contract. Two literal transition changes suffice. Its
   6,175 unbounded primitive interfaces and complete blank startup have
   been verified; it inherits the baseline consistency calibration.

4. **A genuinely 218-state specimen with a rejected caller contract.** One
   transition change and deletion of state 88 produces a 218-state table.
   All 6,143 primitive interfaces pass, but its weak equality comparator can
   forge cached falsum and corrupt freshness tests. Exact full-tape traces
   reproduce both failures. These are valid-interface counterexamples;
   their reachability from blank is not claimed. The specimen's blank
   consistency calibration remains unestablished.

5. **A different pairing codec measured end to end at source level.** The
   bijection `P2(a,b) = 2^a(2b+1)-1` preserves the useful zero alias and
   decreasing-tail property. Its matched pairer/reader source has 225 DAG
   nodes and 5,958 leaves under the present sharing scheme. This is a
   measured alternative encoding, with explicit helper preconditions;
   no full-program calibration or binary-machine theorem is claimed.

## Machine ledger

All tables are deterministic, binary, single-tape, with native start state
0, source dispatcher 84, and halting state 254. The halt state is excluded
from the count and has no transition rows. Native state labels need not be
consecutive.

| Folder | Working states | Rows | Source DAG | Primitive cases | Status |
|---|---:|---:|---:|---:|---|
| `machine/weak218_rejected` | 218 | 436 | 204 | 6,143 | Exact primitive implementation; caller invariant fails; no blank consistency theorem |
| `machine/zero_guard219` | 219 | 438 | 206 | 6,175 | Clean source equivalence, full primitive proof, and complete calibrated startup |
| `machine/counter_salt223_interface` | 223 | 446 | 208 | 6,162 | Sound source and full primitive proof; required blank startup remains unresolved |

Each folder supplies `machine.native.tm`, the full source leaf list,
an exact transition delta from pinned K219, hashes and counts, startup
evidence, and the complete guarded-case ledger. Primitive proofs cover
arbitrary allowed natural register values, gaps, and finite spare tails.
The 223-state proof uses 445 of its 446 rows; row 103/0 is not used by a
primitive interface. This is disclosed, and its startup is not calibrated.

The **uncorrected asymmetric 205-DAG raw compile** discussed in the report
is a separate 218-state experiment from the **two-sided weak 204-DAG
specimen** supplied in `machine/weak218_rejected`. Neither establishes the
requested consistency construction.

## Pinned baseline and provenance

The baseline is ProveIt commit
`26d5de6d21fa354d50e0b84fe851c289925b8d72`, with the unchanged archive
`vendor/K219_Construction_2026-10-20.zip`. It recursively contains the K220,
K221, and earlier construction material. The original licenses and
attribution remain inside that archive.

- Repository: <https://github.com/VladimirReshetnikov/ProveIt/tree/26d5de6d21fa354d50e0b84fe851c289925b8d72/Computability/BusyBeaver/Research/ZFC>
- Pinned archive: <https://github.com/VladimirReshetnikov/ProveIt/blob/26d5de6d21fa354d50e0b84fe851c289925b8d72/docs/incoming/K219_Construction_2026-10-20.zip>

The baseline final K219 runtime was freshly rederived in this investigation.
Its inherited parent calibration was replayed in the original quick mode.
The receipt is in `evidence/baseline219/`. This does not mean that every
ancestor proof-assistant source was freshly compiled.

The exact K219 archive SHA-256 is:

```text
04813567f393b6c4015a96aba092159e9021703b4b662c7be69bd2a86497e31b
```

## Reproduce the packet

Use Python 3.10 or later with assertions enabled. The default path requires
only the standard library and no network connection. Keep the output
directory outside the extracted packet.

```bash
python3 -B portable/reproduce.py --output-dir ../zfc218-replay
```

This verifies the exact packet manifest; safely extracts the three pinned
dependency archives; reruns the finite-algebra, arithmetic, and source
checks; reconstructs all three literal tables; audits the integrity and
coverage of stored primitive-proof receipts; independently replays the
clean blank-startup witnesses; and reproduces the weak-gate and reset-state
counterexamples. A PASS means only that these stated research artifacts
passed. The replay receipt retains `requested_218_state_goal: UNMET`.

To freshly rederive all three new unbounded primitive proofs, add:

```bash
python3 -B portable/reproduce.py --full-runtime --output-dir ../zfc218-full-runtime
```

The three fresh proofs were run before this packet was released. The
default receipt audit checks exact hashes, the ordered complete guard
ledger, transition coverage, and positive duration formats. It does **not**
substitute for rerunning the symbolic case proofs.

To invoke the unchanged K219 driver's default reconstruction and calibration
mode as well, add `--full-baseline`. That option means a fresh final K219
runtime with its inherited quick calibration. To request deeper ancestral
runtime rederivation, use the unchanged extracted K219 driver's own
`--full-baseline` option; its documentation states the inherited boundaries.

Optional C++ local-merge searches are available through `--search` and are
documented in `experiments/README.md`. They are bounded heuristic searches,
not state lower-bound proofs.

## Build the report

```bash
sh build_report.sh
```

A normal `pdflatex` installation is required, with Latin Modern, geometry,
AMS math, mathtools, booktabs, tabularx, xcolor, microtype, enumitem, fancyhdr,
hyperref, and xurl. The script writes local intermediate files to
`.report-build` and the final document to `report.pdf`. The PDF in the
release was rendered and visually inspected.

## Layout

| Path | Contents |
|---|---|
| `report.tex`, `report.pdf` | Main mathematical report and rendered document |
| `theory/` | Complete HC models, residual-parameter proof, standalone checkers |
| `encoding/` | Exact repaired source generator, arithmetic macros, independent actual-source audit |
| `machine/` | Literal tables, source lists, exact deltas, whole-tape proof drivers, counterexamples |
| `experiments/` | Additional encoding searches and concrete rejected-edit evidence |
| `evidence/` | Fresh baseline and runtime integrity receipts |
| `portable/` | Root manifest verifier and offline orchestration |
| `vendor/` | Unchanged pinned K219 archive and its recursive provenance |
| `manifest.json` | Byte sizes and SHA-256 of every distributed payload member |

No new proof-assistant kernel endpoint, priority claim, or machine-state
minimality claim is made. `LICENSE` and `ATTRIBUTION.md` describe reuse.
