# Report241: factorial logarithmic growth of pattern avoiding ascent sequences

This package accompanies `Report241.pdf`. It treats ordinary ascent sequences,
with strict adjacent ascents and classical arbitrary-subsequence avoidance.
A202059 counts 100-avoiding words and A202060 counts 110-avoiding words; both
are indexed by length starting at zero. The common subclass avoids
000, 100, and 110 simultaneously.

The article proves matching bounds for each of the three counting sequences u_n:

    log u_n = n log n - 2n log log n + O(n),
    (u_n/n!)^(1/n) = Theta(1/(log n)^2) -> 0.

An exactly counted fresh-label block family gives the lower bound inside the
common subclass. A separate increasing-run subset encoding gives the upper
bound: mark non-first occurrences for 110 and non-last occurrences for 100.
In both cases the marked labels are weakly increasing.

Thus log u_n / (n log n) tends to 1. This contradicts the fixed 3/4-factorial
exponent conjectured for both single-pattern classes in the final 2022 paper
of Conway, Conway, Elvey Price, and Guttmann. It does not dispute the paper's
finite counts. The doubled seed is credited to that paper; the iterative
fresh-label continuation supplies the stronger lower bound.

The result determines two logarithmic orders and the zero factorial-normalized
root limit, not a relative equivalent. The linear-order constant, existence
of a limiting constant after multiplying the normalized root by (log n)^2,
relative prefactors, and consecutive ratios are not settled by these bounds.
The inverse has a determined first correction and a growing additive error:
for L=log X and w=W_0(L), it is L/w + 2L log(w)/w^2 + O(L/w^2).
A self-contained analytic corollary also proves non-P-recursiveness over the
complex numbers: the exponential generating functions are entire of infinite
order, whereas entire D-finite functions have finite order. The ordinary
generating series are non-D-finite as formal series, despite radius zero.
No external peer review, formal verification, or historical priority is claimed.

## Contents

- `article.tex`, `sections/`: full proof and bibliography
- `Report241.pdf`: frozen reproducible PDF
- `code/`: bounded exact verifiers, fixed receipts, guards, and ZIP replay
- `build.py`: immutable-source builder and deterministic archive assembly
- `MANIFEST.sha256`: complete inventory of all other package files
- `SOURCES.md`: exact models, source locations, attribution, and limits
- `COMPUTATION.md`: verification coverage, algorithms, bounds, and build details
- `requirements.txt`: Python and TeX requirements

No third-party paper, private audit, research correspondence, credential,
network dependency, or repository history is included. Source-linked number
prefixes are finite regression fixtures.

## Reproduce

Use Python 3.11 or later and the matching pdfTeX/LaTeX toolchain. Python uses
only its standard library. From the extracted `Report241/` directory:

```sh
python -B build.py --verify-only
python -B build.py --output-dir /absolute/existing-parent/new-build
python -B code/reproduce_zip.py \
  --archive /absolute/existing-parent/new-build/Report241.zip \
  --output-dir /absolute/existing-parent/new-replay
```

Output directories must be new, outside the frozen package, and have existing
parents. Existing output directories are never reused or merged. The optional
report-number argument must be 241. No upload or publication is performed.

The builder checks the full manifest and file/directory inventory, regenerates
the four receipts, compiles a disposable TeX copy with a private format and
shell escape disabled, requires the PDF and receipts to match the frozen
versions, and emits a ZIP with deterministic member order, timestamps, and
modes. It verifies that no source bytes changed. Toolchain versions are recorded
in its external build receipt; arbitrary versions need not give identical PDF
bytes.

The ZIP replay accepts only the exact package trusted by the running verifier.
It extracts two actual copies and rebuilds with normal Python and with `-O`.
It compares every member's bytes and metadata, complete ZIP bytes, PDFs,
receipts, and build-check bytes. The trusted tree, extracted source trees, and
input archive must remain unchanged.

## What the checks establish

Exact checks independently compare literal forbidden triples with linear-time
predicates, recompute source recurrence prefixes, enumerate the common class,
test the finite construction's exact cardinality and padding injection,
and reconstruct both occurrence encodings used for the upper bound.
These finite checks support the implementation; the all-length theorem rests
on the written proof. No floating-point asymptotic fit is used as evidence.

Python child commands explicitly disable bytecode writes and enforce a
640-digit decimal conversion cap. Every process also sets that cap directly.
Validation uses explicit exceptions, so optimization cannot remove it.
Documented finite cutoffs and state budgets prevent unbounded enumeration.
The manifest establishes integrity, not authorship or independent provenance.
Filesystem guards are finite regression tests, not a security boundary against
hostile concurrent changes.
