LEXICOGRAPHIC ORDERS OF SURREAL WELL-ORDERS
Coherent Limits, Nonextendible Symmetries, and Countable Models
Research manuscript prepared for Vladimir Reshetnikov
3 October 2026

CONTENTS
surreal_orders_limits_symmetries_models.pdf -- the complete 50-page article
surreal_orders_limits_symmetries_models.tex -- self-contained LaTeX source
finite_diagnostics.py -- independent finite operational checks (Python 3)
finite_diagnostics_results.json -- saved passing run
README.txt -- this file

REPOSITORY BASIS
https://github.com/VladimirReshetnikov/ProveIt
Pinned commit: d5bd4a67b41b89688a079997574a94bcd855bb83
Primary report:
Algebra/SurrealNumbers/docs/foundations-and-computation/surreal-well-orders/article.tex
The article also identifies an earlier separately delivered continuation and
cites the inspected foundational Lean files. No repository changes are included.

SUBJECTS
- Natural interpretations of lexicographic well-order spaces
- Uniform coherent birthday profiles and eventual native comparison
- Club detection of set-likeness from minimum local ordinal types
- A coherent append-tail direct system realizing the bounded-support core
- Cut automorphism orbits and localized failure of extension
- Local set/class coding dichotomy and convex residual blocks
- Complete condensation histories and exact ordinal-power heights
- The two external countable-model shuffles, elementary equivalence,
  and a decision procedure for their common pure-order theory
- Baire-space topology and Dedekind completion at the first infinite cutoff
- GB/GBC, ETR/KM, explicit models, universe levels, and a route into Lean
- Twelve further research questions and a theorem/foundation status ledger

REBUILDING
A conventional TeX Live installation with latexmk and pdfLaTeX is sufficient.
The source uses standard packages listed in its preamble. No external figures,
bibliography database, network fetches, or generated source files are required.
From the extracted directory, run:

  latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_orders_limits_symmetries_models.tex

FINITE DIAGNOSTICS
Requires Python 3 and its standard library only. Run:

  python3 finite_diagnostics.py --output finite_diagnostics_results.json

The saved run passes 58,255 decisive-pair restriction checks, 609,862 nested
witness checks, and 28,920 independently evaluated dyadic word comparisons.
It also reproduces an explicit reversal under restriction.

PROOF AND VERIFICATION STATUS
This is an AI-assisted research continuation with conventional mathematical
proofs and independent written mathematical review. It is not a refereed
publication, a claim of literature priority, or a machine-checked development.
The finite diagnostics do not verify the transfinite, cardinal, automorphism,
class-recursion, or model-theoretic results. No Lean build was run for this
article. The PDF was compiled with no reported TeX layout or reference warnings
and all pages were inspected in rendered contact sheets, with detail checks
of representative pages.

The article itself states the assumptions and scope of each result. In
particular, collections of class relations are not silently treated as classes
of ordinary elements, and internal well-foundedness is distinguished from
external well-foundedness in nonstandard models.
