# Rank five ultra log concavity for five vertex cores with universal sinks

## Result and scope

The article proves rank ultra log concavity at **actual degree five** for every arbitrary loopless directed five-vertex core, with any finite independent cloud of universal sinks, under independent nonnegative tail and head activities. Every feasible ordered pair of disjoint endpoint sets is counted once, regardless of its matching witnesses.

The theorem includes all preorder cores. It uses exact rational certificates for gamma2² >= 2 gamma1 gamma3, ordinary proofs for gamma3² >= 2 gamma2 gamma4, the universal actual-degree first bound, and the stronger last bound gamma4² >= (25/8) gamma3 gamma5. No claim of lower-actual-degree closure for five-core instances is made. A counterexample in the article refutes only the stronger cubic constant 3, not rank-five ultra log concavity.

## Read

- `article/universal-sink-five-core.pdf`: complete six-page theorem and proof
- `article/universal-sink-five-core.tex`: editable mathematical source
- `ORDINARY_PROOFS.md`: expanded support, moment, and ordinary second-gap proofs
- `audits/`: exact audit receipts and independent reviews

## Fresh proof replay

Run from any working directory with Python 3.10 or later:

    python /path/to/universal-sink-five-core-result/verify.py

Optional arguments:

    python verify.py --workers 4 --output /tmp/fresh-receipt.json
    python verify.py --mode hashes

Full replay uses only the Python standard library. It checks file integrity, copies proof inputs to a fresh temporary directory, independently reconstructs all 9,608 Boolean support targets, expands 57,089 rational binomial squares, checks every remainder coefficient, and verifies disjoint coverage of all 1,048,576 labeled directed cores. It also freshly checks the stronger-constant counterexample by literal endpoint-pair matching enumeration. Neither a prior research archive, a solver, third-party Python modules, network access, nor the discovery code is needed. Hash-only mode checks integrity and is not a proof replay.

The two-parameter sink substitution is an ordinary theorem. Certificate positivity on its closed nonnegative orthant proves the first interior coefficient inequality for every finite nonnegative sink vector, including zeros. The actual-degree-five ULC conclusion still requires five positive core tails and at least five positive sink heads.

## Optional discovery and typesetting

`discovery/` contains the candidate generator. It uses NumPy and SciPy; these are optional and are not verifier dependencies. `orbits.cpp` generates the core catalog, while the independent checker verifies the catalog's completeness without trusting that generator. From `discovery/`, `python discover.py /tmp/new-candidates` recreates candidate certificates using exact acceptance after linear programming. Different solver versions may choose different valid certificates.

`bash build.sh` typesets the article with a standard TeX installation. The optional environment hints in that script support the original research container. Rebuilding can change PDF metadata and therefore hashes. The supplied PDF was rendered and all pages visually inspected.

No external publication, novelty/priority, real-rootedness, stability, or general weighted-preorder theorem is claimed.
