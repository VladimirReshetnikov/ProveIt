% Finite class/closure kernel. Genuine equality; no finite-domain assumption.
% A research proposal, not a TM state-count certificate.
cnf(k01,axiom,(v(upd(S,J,Z),J) = Z)).
cnf(k02,axiom,(K = J | v(upd(S,J,Z),K) = v(S,K))).
cnf(k03,axiom,(~eps(S,n(A,B)) | ~eps(S,A) | ~eps(S,B))).
cnf(k04,axiom,(eps(S,n(A,B)) | eps(S,A))).
cnf(k05,axiom,(eps(S,n(A,B)) | eps(S,B))).
cnf(k06,axiom,(~eps(S,a(J,K)) | e(v(S,J),v(S,K)))).
cnf(k07,axiom,(eps(S,a(J,K)) | ~e(v(S,J),v(S,K)))).
cnf(k08,axiom,(~eps(S,q(J,A)) | eps(upd(S,J,w(J,A,S)),A))).
cnf(k09,axiom,(~eps(upd(S,J,Z),A) | eps(S,q(J,A)))).
cnf(k10,axiom,(flag(B) = c0 | eps(upd(upd(B,c0,bad(B)),n(c0,c0),out(B,Q)),v(B,c0)))).
cnf(k11,axiom,(flag(B) = c0 | e(mem(B,Q),out(B,Q)))).
cnf(k12,axiom,(flag(B) = c0 | ~e(mem(B,Q),Q))).
cnf(k13,axiom,(flag(B) != c0 | e(pick(X),X) | ~eps(upd(upd(B,c0,X),n(c0,c0),Y),v(B,c0)) | e(Y,h(B)))).
cnf(k14,axiom,(flag(B) != c0 | ~e(X,h(B)) | ~eps(upd(upd(B,c0,X),n(c0,c0),Y),v(B,c0)) | e(Y,h(B)))).
cnf(k15,axiom,(flag(B) != c0 | ~e(Y,h(B)) | eps(upd(upd(B,c0,sup(B,Y)),n(c0,c0),Y),v(B,c0)))).
