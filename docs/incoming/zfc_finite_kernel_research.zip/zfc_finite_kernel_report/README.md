# Finite closure kernels for small consistency machines

Research prepared for Vladimir Reshetnikov, 17 October 2026 UTC.

**Main result:** an explicit finite assignment/class/closure theory with a
15-clause, 35-literal universal presentation. Using the inherited full raw-EPSC
calibration, the report gives ordinary mathematical proofs formalizable in ZFC of

`Con(K_cl) <-> Con(U_cl) <-> Con(ZFC)`.

The preferred presentation has nine proper functions, one constant, three
non-equality predicates, 174 term occurrences, maximum depth three, and at most
four universal variables in a clause. Other measured variants include a
ten-function, two-relation form with 186 term occurrences and a six-function,
two-relation form with 639 occurrences. These are logical-payload measurements.

**Machine result:** no new calibrated blank-tape binary TM below 253 working
states was obtained. The separate bounded search tested 226,688 alternatives for
individual incoming edges and found no certified state deletion. The included
253-state table is attributed public prior work, not a new result of this report.

## Read first

- `zfc_finite_kernel_report.pdf` — complete report.
- `zfc_finite_kernel_report.tex`, `sections/`, `references.bib` — complete source.
- `data/packed_predicate_shared_derived.p` — preferred 15-clause TPTP input.
- `data/packed_predicate_shared_derived.txt` — same payload in readable notation.
- `data/kernel_metrics.json` — all fifteen presentations and exact size metrics.
- `engineering/ENGINEERING_NOTES.md` — public-table audit and new negative search.

All clause macros are expanded in the JSON, text, and TPTP payloads. Equality is
genuine first-order equality. Function `C` is named `upd` in TPTP; constant `c` is
named `c0`. There is no finite-domain assumption.

## What is proved, checked, and still missing

| Layer | Delivered status |
|---|---|
| Full raw-EPSC consistency calibration | Inherited ordinary theorem, cited precisely to ProveIt |
| New five-block finite kernel | Ordinary proof, including uniform schema representation and countable-model upper expansion |
| Clause conversion and witness compressions | Ordinary equisatisfiability proofs and literal generated payloads |
| Ideal unbounded ground search | Complete mathematical soundness/completeness proof |
| Finite interfaces | Executable checks, recorded in `data/verification.json` |
| Public 253 table | Exact finite bootstrap and affine replay using upstream register-box oracles |
| New bounded local search | Reproducible negative result with coverage limits |
| New Lean/Coq/ZFC proof certificate | Not supplied |
| New register program or binary TM for the finite kernel | Not supplied |
| New machine-size record | Not claimed |

The paper does not prove the original one-relation, one-parameter EPSC schema
alone equiconsistent with ZFC. The expanded assignment language is essential.
Neither an equality predicate without congruence nor a finite-model-only search
is a sound substitute for the described ground procedure.

## Reproduce

From this directory, with Python 3.10 or newer:

```sh
python3 code/finite_kernel.py
python3 code/verify_kernel.py
python3 code/reify.py
python3 baselines/34-k12-theory-finite_assignment_kernel.py --out baselines/generated
python3 engineering/audit.py
```

The Python code uses only the standard library. The full finite checks enumerate
all 262,404 pairs of binary relations on domains of size at most three; they take
about five seconds in the development environment. These are closure-interface
controls, not finite models of the entire theory. `--quick` on the verification
program limits the relation controls to size two and overwrites the recorded
verification output accordingly.

The machine deletion experiment also requires `g++` with C++17:

```sh
python3 engineering/reproduce_search.py --radius 20 --fuel 128
```

It creates large disposable context files and a compiled executable. These are
excluded from the delivered archive because the scripts regenerate them exactly
from the retained inputs. The compact radius-20 and radius-10 results are included.
The old 253/254 tables and selected Coq inputs are unchanged upstream material.
A full Coq build requires the complete pinned upstream checkout; this archive
does not contain its dependency closure, and the proof suite was not rebuilt.

Build the report with a conventional TeX installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error zfc_finite_kernel_report.tex
```

The Makefile offers `report`, `verify`, `machine-audit`, and `search` targets.
None of the reproduction commands needs network access.

### Ground search resource boundary

The reference `ideal_search` means an unbounded mathematical algorithm. Its
success event is a normal return after an unsatisfiable finite ground stage.
The literal Python runtime can exhaust memory or recursion limits. Exceptions,
interruptions, process failures, and resource exhaustion are never refutation
events. No whole-kernel search was run. `--run-whole-search` is an explicit opt-in
to an impractical reference computation, not a practical consistency test.

## Source snapshots and attribution

- ProveIt cutoff: `8cf840b8a26d002041e7a26dc9688ce7ce5fd751`, 16 October 2026,
  23:55:11 UTC; includes the three requested commits and the 34-source intake.
- Main upstream: `297ab8df7e5de329605c3875b4934643b371a5e3`.
- Public 253 PR head: `0d544f2a2e3c18f12278441a74b7879f31cbe856` in
  `mira-emmy/busy-beaver`, PR 20 to `jeff87654/busy-beaver`.
- Source-34 baseline: the unchanged generator and original ProveIt MIT-0 license
  are retained under `baselines/`.

Assignment/class coding and general free-function-slice techniques are prior
work of Harvey Friedman, cited in the paper. The new local combination, explicit
selector and header constructions, measured payload variants, and bounded
engineering experiment are described with their scope. No global priority or
minimality claim is made.

`SOURCES.json` and `engineering/SOURCES.json` give direct pinned URLs and provenance.
`SHA256SUMS` records the delivered file contents; it excludes itself. Regenerating
timestamped/timed outputs or rebuilding a PDF can change checksums without
changing the mathematical payload.

For incorporation, keep this contribution distinct from upstream machine authorship
and describe it as an ordinary mathematical proposal with executable finite checks.
