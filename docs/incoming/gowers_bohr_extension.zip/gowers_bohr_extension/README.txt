SHARP FREIMAN EXTENSION AND POLYNOMIAL BOHR RADII
Explicit refinements of Section 10 of Gowers's Szemeredi argument
Prepared 6 October 2026

START HERE
  gowers_bohr_extension.pdf is the complete research article.
  gowers_bohr_extension.tex is its full editable LaTeX source.

MAIN RESULTS
  * Exact Freiman extension under 3 epsilon + 2 kappa < 1, with
    counterexamples on every rational point of the boundary.
  * Directional collision-based repair and higher-order extensions.
  * Elementary finite selection of an ambient Bohr radius, yielding an
    inner radius rho/(8d) for density 7/8 (and rho/(6d) in Section 10).
  * A fourth-moment estimate which enlarges the starting spectral radius
    while preserving Gowers's original large spectrum.
  * A complete local-model theorem with explicit all-density parameters.
    For 0 < alpha <= 1/6 and the original spectrum, the guaranteed radius
    is alpha^19/(3*pi*2^149), with retained fraction alpha^5/20000.

SCOPE
  The article gives complete proofs of its refinements and explicitly
  states the established component-extraction lemmas it uses. It cites
  the corrected repository proof of the extraction step. It does not
  claim a new global quantitative Szemeredi bound, historical priority
  over all literature, or new Lean certification. The universal sharpness
  family does not establish sharpness for the prime cyclic same-target
  specialization or for regular Bohr sets alone.

SOURCE SNAPSHOT
  VladimirReshetnikov/ProveIt
  Commit: 9ea383e9b28d885a936d5d681cd5584fffd2cb29
  Inspected source paths and primary references appear in the article.
  The repository was read, not modified.

CONTENTS
  gowers_bohr_extension.tex       Full article source
  gowers_bohr_extension.pdf       Compiled article
  extension_frontier.pdf          Vector figure required by the source
  make_figure.py                  Recreates that figure
  verify_extension.py            Exact finite intersection/frontier/repair checks
  extension_validation.json      Executed report from verify_extension.py
  verify_bohr_fourier.py          Bohr, Fourier, and parameter checks
  verification_bohr_fourier.json  Executed report from verify_bohr_fourier.py
  parameter_ledger.json          Exact formulas and sample comparisons
  build_report.json              PDF compilation and validation summary
  SHA256SUMS.txt                  Checksums of the package files

BUILD
  Use a standard TeX Live installation with the packages declared in
  gowers_bohr_extension.tex. No BibTeX or network access is needed.
  From this directory:

    pdflatex -interaction=nonstopmode -halt-on-error gowers_bohr_extension.tex
    pdflatex -interaction=nonstopmode -halt-on-error gowers_bohr_extension.tex

  If a cross-reference rerun is requested, run pdflatex once more.
  Alternatively, run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error gowers_bohr_extension.tex

REPRODUCE CHECKS AND FIGURE
  Python 3 is required. verify_extension.py uses the standard library;
  verify_bohr_fourier.py uses NumPy; make_figure.py uses NumPy and Matplotlib.
  The supplied PDF figure means these libraries are not needed to build
  the article from LaTeX.

    python3 verify_extension.py
    python3 verify_bohr_fourier.py
    python3 make_figure.py

  These scripts check finite cases. The article's proofs are the basis
  of the general mathematical conclusions. Floating-point tolerances in
  Fourier tests are recorded in the corresponding report and do not
  enter the proofs.
