# Theorem and proposition index

Generated from the delivered standalone LaTeX build. Rebuilding regenerates this index.

| Result | Page | Label |
|---|---:|---|
| Lemma 2.1 | 5 | `tlbc:lem:weighted` |
| Proposition 2.2 | 6 | `tlbc:prop:transform` |
| Definition 2.3 | 6 | `tlbc:def:admissible` |
| Theorem 2.4 | 6 | `tlbc:thm:tiltedtransform` |
| Theorem 3.1 | 7 | `tlbc:thm:master` |
| Lemma 3.2 | 8 | `tlbc:lem:DD` |
| Lemma 3.3 | 8 | `tlbc:lem:annihilator` |
| Theorem 3.4 | 8 | `tlbc:thm:Hermite` |
| Corollary 3.5 | 9 | `tlbc:cor:central` |
| Theorem 4.1 | 9 | `tlbc:thm:branches` |
| Corollary 4.2 | 10 | `tlbc:cor:sharpstrip` |
| Theorem 5.1 | 11 | `tlbc:thm:jets` |
| Corollary 5.2 | 11 | `tlbc:cor:pair` |
| Corollary 5.3 | 12 | `tlbc:cor:half` |
| Corollary 5.4 | 13 | `tlbc:cor:purepolylog` |
| Lemma 6.1 | 14 | `tlbc:lem:anchor` |
| Theorem 6.2 | 14 | `tlbc:thm:anchor` |
| Corollary 6.3 | 15 | `tlbc:cor:independentjets` |
| Theorem 6.4 | 16 | `tlbc:thm:finite` |
| Example 6.5 | 16 | `tlbc:ex:finite` |
| Theorem 7.1 | 17 | `tlbc:thm:moments` |
| Proposition 7.2 | 17 | `tlbc:prop:conservation` |
| Theorem 8.1 | 18 | `tlbc:thm:primitives` |
| Corollary 8.2 | 19 | `tlbc:cor:GammaPrimitive` |
| Theorem 9.1 | 20 | `tlbc:thm:binary` |
| Corollary 9.2 | 21 | `tlbc:cor:dyadic` |
| Corollary 9.3 | 21 | `tlbc:cor:firstdepth` |
| Theorem 9.4 | 21 | `tlbc:thm:family` |
| Proposition 10.1 | 22 | `tlbc:prop:arithmetic` |
| Theorem 10.2 | 22 | `tlbc:thm:explicit` |
