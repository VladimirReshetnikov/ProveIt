# Claim status

## Proved in this article

1. **Finite matched-shift master** (Theorem 3.1): arbitrary complex source orders, admissible complex shifts/tilts, ordinary absolutely convergent integrals on the real displacement axis. Finite ordinary-Lerch output is asserted in this matched sector, not for arbitrary unmatched parameters.
2. **Confluence and branches** (Theorem 3.4, Corollary 3.5, Theorem 4.1): all partial tilt collisions; full collision operators; interior branch cancellation; explicit first boundary germs. The equal-tilt central formulas already exist in the inspected predecessor and are recovered, not claimed anew.
3. **Stieltjes–Gamma consequences** (Section 5): all-index Stieltjes identities, Gamma/polygamma specializations, rational-shift harmonic formulas, and a mixed negative-axis/odd-part polylogarithm pairing. The predecessor's odd-part/odd-part Gaussian formula is explicitly distinguished.
4. **Independent-shift expansion and all jets** (Theorem 6.2, Corollary 6.3): a strict-ratio anchor exists locally at every admissible point, giving normal convergence with all parameter derivatives.
5. **Finite single-anchor closure** (Theorem 6.4): a necessary-and-sufficient functional criterion for one specified basis, not for arbitrary multianchor formulas or special-value independence.
6. **Moments and anchored primitives** (Theorems 7.1 and 8.1): all raw moments, the necessary matched-shift derivative correction, and every anchored integration resonance.
7. **Arithmetic criterion and obstruction** (Theorem 9.1, Corollaries 9.2–9.3): a complete finite polynomial-inverse test, the exact mod-two obstruction, full cancellation classification at depths 2^h+1, and the first possible mixed depth.
8. **Infinite mixed-parity family** (Theorem 9.4): certified by one identity in Q[k,x], not by finite samples.
9. **Elementary depth-seven evaluation** (Theorem 10.2): finite rational harmonic arithmetic plus a proof of ordinary integral convergence.

## Existing questions addressed with explicit boundaries

- Predecessor **Q1, full multivariate tilt**: a finite matched-sector formula and a normally convergent general generating formula are proved. An unrestricted finite closed form in ordinary Lerch values is not asserted.
- Predecessor **Q2, unequal shifts and independent jets**: answered on the stated admissible contour domain, with a globally available anchor and all source-order derivatives. A one-anchor finite-closure classification is also supplied.
- Predecessor **Q3, integer-shift cancellation**: a necessary-and-sufficient algebraic decision criterion, an infinite depth classification, and a symbolic mixed-parity family are proved. All mixed-parity zero sets at other depths are not parametrized.

## Numerical/exact-computation boundary

- 2,185 exact finite assertions passed (four are negative controls).
- Two 57-case floating-point replays passed; each contains 56 comparisons and one negative control.
- No certified intervals, proof-assistant checks, or numerical proofs of transcendental equality are claimed.
- The exact modular-inverse routine uses SymPy rational polynomial algebra. It is reproducible symbolic evidence for the instances, not an independently verified proof kernel.

## Unchanged / not claimed

- The canonical S4 result is already proved upstream.
- The short S6 reduction is not proved or disproved here.
- The revised S8 vector remains conjectural; it is not the earlier rejected vector.
- Nonzero alternating-zeta coefficient does not prove arithmetic independence from Q[pi^2].
- No complete parametrization of all cancellation sets, no general same-direction arbitrary-order Mellin theorem, and no exhaustive incoming-archive audit.
- No historical priority guarantee for every displayed special case.
- No repository write, persistent Library write, or consolidated-book rebuild.
