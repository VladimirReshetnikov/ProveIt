# Beyond Finite Surreal Polytopes

**Exposed faces, sharp infinitesimal depth, and finite-description rigidity**  
Prepared for Vladimir Reshetnikov with ChatGPT — 30 September 2026

## Read the article

`article.pdf` is the 26-page compiled manuscript. `article.tex` is its
standalone LaTeX source, including an internal bibliography and two TikZ
figures. No external image or bibliography files are needed.

The principal results are:

- **Theorem 6.2:** if a surreal convex class in ordinary finite dimension is
  both a hull of a set of points and an intersection of a set of halfspaces,
  both original presentations reduce to finite subpresentations.
- **Theorems 4.1, 4.3, and 5.2:** uniform separation of disjoint small hulls;
  exposure of every nonempty proper face of a small hull; finite active-row
  descriptions for every nonempty proper face of a small H-class.
- **Theorem 7.1:** a full-dimensional small hull containing the origin in its
  interior has a small-generated polar exactly when it is a finite polytope.
- **Theorems 8.2 and 9.2:** the degree of an exposing polynomial in one fixed
  infinitesimal equals the classical degree of non-exposedness, with an
  explicit compact family attaining the bound in every codimension.
- **Theorems 10.1 and 10.2:** complete face classifications of the rational
  moment-curve hull and its polar. The former has no facets; the latter has
  no vertices and no nonempty faces below dimension ceil(d/2).

The article includes eight proposed research questions, cardinal versions,
a universe-sensitive Lean implementation route, and elementary examples
showing why all size and scalar-extension hypotheses are necessary.

## Status and important distinctions

This is an AI-assisted, unrefereed proof manuscript. Its main conclusions
have written proofs, but they are not Lean-certified or independently
refereed. Priority of the proposed geometric formulations and consequences
has not been established. No named longstanding conjecture is claimed solved.

Martínez-Legaz's 1997 lexicographical exposure theorem, classical degree of
non-exposedness, and codimension bound are credited as prior results. The
new polynomial notation does not create a new real invariant. Saturation,
real closedness, finite Farkas theory, and the compactness mechanism are
also prior mathematical tools.

“Small” means externally set-indexed in one fixed universe. The convex
classes themselves are generally proper classes. Convex combinations have
ordinary finite support. A hull of the real points of a convex body is NOT
its full semialgebraic extension to all surreal points.

## Rebuild

A TeX Live installation with `latexmk`, `newpx`, `amsmath`, `amsthm`,
`mathtools`, `microtype`, `booktabs`, `enumitem`, `tikz`, `tcolorbox`,
`fancyhdr`, `hyperref`, `aliascnt`, and `cleveref` suffices:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

The supplied `Makefile` provides `make pdf`, `make verify`, and `make clean`.
No external network access is required to build the article.

## Reproduce the finite checks

Python 3.10 or later, standard library only:

```sh
python3 code/verify.py --output data/verification_results.json
```

The recorded run passed **28,890 exact rational checks**. These count finite
algebraic test cases, not independent theorems. The code checks square-product
slacks, Vandermonde determinants, exact polar active sets and ranks on finite
samples, leading-coefficient signs in the recursive family, an exact
counterexample identity, and cube Farkas/active-face examples. It does not
prove saturation or enumerate infinitely many faces.

## Package contents

- `article.tex`, `article.pdf`: manuscript and compiled document.
- `code/verify.py`: exact rational regression program.
- `data/verification_results.json`, `data/verification_stdout.txt`: recorded run.
- `notes/SOURCES_AND_SCOPE.md`: repository provenance and literature roles.
- `notes/PROOF_AUDIT.md`: internal proof review and exclusions.
- `notes/BUILD_REPORT.md`: compilation and PDF inspection record.
- `Makefile`: local build and verification commands.
- `SHA256SUMS.txt`: checksums of the delivered content, excluding itself.

No repository files were modified, and no build of the ProveIt repository
was performed.
