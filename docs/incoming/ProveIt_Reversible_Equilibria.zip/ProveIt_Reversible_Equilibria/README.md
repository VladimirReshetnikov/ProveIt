# Arithmetic of Rapidly Mixing Reversible Computation

**Diophantine cuts, Liouville equilibria, and exact-symbolic barriers**  
Research manuscript prepared for Vladimir Reshetnikov, 30 September 2026.

## Read first

`article.pdf` is the complete 25-page manuscript; `article.tex` is its
standalone LaTeX source with an internal bibliography. The archive also
contains exact-arithmetic code, symbolic polynomial examples, a test receipt,
and a provenance/claim-boundary record. The source requires no external
figures or downloaded bibliography files.

## Mathematical contents

For a binary environment b, the birth probability at n is (2-b[n])/8, the
death probability is 1/2 away from zero, and the remaining probability is
holding. These reversible chains all have exponential stationary tails,
mean return time to zero at most 2, and spectral gap at least

    delta = (3 - 2 sqrt(2))/4.

Their total-variation distance from stationarity, **when started at zero**,
is at most `(1/2) * (1-delta)^t`. This is not a uniform bound over all
starting states.

The article proves a faithful symbolic coding of the normalizing constant,
rationality exactly for eventually periodic environments, and a Cantor-set
range of dimension `log_2((1+sqrt(5))/2)`. A single first-halting defect gives
rational masses but undecidable exact equality. Sparse defects give a
rational-versus-Liouville dichotomy, establishing Sigma^0_2 completeness of
rationality and algebraicity and Pi^0_2 completeness of irrationality and
transcendence for primitive-recursive environment codes.

A separate application of Adamczewski--Bugeaud's digit-complexity theorem
gives a transcendental Thue--Morse equilibrium. Strict rational cuts have
complete finite-prefix witnesses and, by MRDP, fixed-polynomial existence.
The compact fixed-horizon arithmetic certificate has N+1 natural witnesses,
2N+1 squared residuals, and total degree at most four. The recurrence
presentation uses 3N+4 witnesses and 4N+4 residuals instead, retaining small
recurrence coefficients. Neither count includes the input parameters, and
neither includes a universal evaluator for the environment program.

The manuscript contains twelve proposed research questions and a staged
formalization plan.

## Status and limitations

The mathematical arguments are in the manuscript. The work is not
independently refereed or Lean/Rocq-verified, and historical priority is not
asserted. Earlier undecidability of stationary distributions is explicitly
credited to Gamarnik; reversible history methods, self-similar-set theory,
and the imported transcendence theorem are also credited.

The existing ProveIt MRDP interface is used only for its stated existential
polynomial result. No Lean build or universal polynomial expansion was
performed here. Unique witnesses are proved for the **fixed-horizon
arithmetic layer**, not for a fixed-arity universal single-fold polynomial.
The local counter lift is proved generally and tested on small examples;
a full universal interpreter is not included.

## Files

- `article.tex`, `article.pdf`: manuscript and compiled PDF.
- `code/equilibria.py`: standard-library exact arithmetic, interval bounds,
  rational membership decoder, both certificate checkers, and reversible
  counter-history lift.
- `code/verify.py`: deterministic finite verification and SymPy expansion.
- `results/examples.json`: exact examples, eighty-bit Thue--Morse enclosure,
  factorial defect truncations, and a counter history.
- `results/quartic_N3.json`, `results/quartic_N3.txt`: the recurrence quartic
  (13 witnesses, 16 residuals, 63 expanded monomials).
- `results/compact_quartic_N3.json`, `results/compact_quartic_N3.txt`: compact
  quartic (4 witnesses, 7 residuals, 51 expanded monomials).
- `verification/checks.json`: recorded 113,686 passing finite checks.
- `verification/pdf_preflight.json`: PDF production checks; not math checks.
- `PROVENANCE.md`: pinned repository inspection, primary literature and scope.
- `requirements.txt`, `Makefile`: reproduction dependencies and commands.

## Reproduce

Python 3.10 or newer is required. The core module has no third-party
dependencies. The complete symbolic check uses SymPy 1.14.0.

```sh
python -m pip install -r requirements.txt
python code/verify.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively, `make check` and `make pdf` perform the last two operations.
The recorded run used Python 3.13.5 and SymPy 1.14.0, seed 20260930. Reruns
rewrite the generated result JSON/text files and `verification/checks.json`;
the interpreter-version field may differ. Finite checks do not establish
the infinite-state, universality, hierarchy, or transcendence theorems.

LaTeX uses common TeX Live/MiKTeX packages: lmodern, amsmath, amssymb, amsthm,
mathtools, microtype, booktabs, tabularx, enumitem, xcolor, fancyhdr, listings,
tikz, xurl, hyperref and cleveref.

## Minimal API examples

Run from the archive root:

```python
import sys
from fractions import Fraction
sys.path.insert(0, 'code')
from equilibria import (
    prefix_data, compact_witness, compact_residuals,
    periodic_normalizer, decode_rational_mass, single_defect_mass,
)

p = prefix_data((0, 1, 0))
assert p.interval == (Fraction(4, 7), Fraction(24, 41))
witness = compact_witness(p, 1, 2, 'lower')
assert witness == {'W1': 2, 'W2': 2, 'W3': 4, 'eta': 15}
assert all(x == 0 for x in compact_residuals((0, 1, 0), 1, 2, 'lower', witness))
assert 1 / periodic_normalizer((), (0, 1)) == Fraction(7, 12)
assert single_defect_mass(4) == Fraction(32, 63)
assert decode_rational_mass(Fraction(5, 8), max_steps=None) is None
```

`None` from a threshold-witness constructor means only that the supplied
prefix does not certify the comparison. It is not a verdict about the
infinite limit. The rational membership decoder's optional budget raises
`SearchBudgetExceeded` on exhaustion, never a false nonmembership result.
