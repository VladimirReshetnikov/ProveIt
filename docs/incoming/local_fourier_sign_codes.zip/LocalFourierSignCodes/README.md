# Local Fourier Sign Codes

**Exact Obstructions, Robust Sidorenko Bounds, and Sharp Girth Forcing**  
Research manuscript prepared for ProveIt, 7 October 2026.

## Start here

Read `article.pdf`. The complete, self-contained LaTeX source is
`article.tex`; it includes its tables and bibliography and needs no downloaded
source files. `verify.py` is a standard-library exact-arithmetic checker.

The paper develops results at the intersection of finite Fourier/additive
relations in ProveIt's Gowers–Szemerédi program and the explicit incidence
pattern in the `openai/math` Sidorenko manuscript. It does not assume that
repository's counterexample theorem.

## Main results

1. **Exact obstruction threshold and binary code.** The first negative
   zero-sum relation in the Fourier-sign spectrum is exactly the first
   one-sided degree threshold at which a negative conserved Fourier term
   can occur. A simple theta graph realizes the obstruction. Safe sign
   assignments form the orthogonal complement of a binary relation code.
   A breadth-first search in a two-sheeted Cayley cover produces a shortest
   witness. The general cutoff is the order of the generated subgroup;
   in a Boolean group of rank k, the sharp cutoff is k+1.
2. **Robust cycle inventory.** A difference of products of local moments
   bounds all negative full-flow mass. The density lower bound keeps the
   random-density term and every simple-cycle contribution, with that
   explicit error subtracted.
3. **Sharp forcing.** For a cyclic graph of girth g with c_g shortest cycles,
   the set-cut norm is at most p(delta+epsilon)^(1/g)/(4 c_g^(1/g)). Both the
   exponent and the leading constant are optimal in the weighted scalar
   Cayley class. Forests are explicitly excluded.
4. **The 35/66 incidence pattern.** The source graph has exactly 33
   four-cycles and 88 six-cycles. Zero cubic sign defect implies a surplus
   at least 33 p^62 times the fourth power of the normalized U2 norm of
   w-p. Any scalar Cayley deficit forces a quantitatively nonzero mass of
   negative frequency triples. A typed sign-gauge sufficient criterion and
   a complete one-character density polynomial are also included.

The exact mathematical statements and all hypotheses are in the paper.
In particular, a negative term is not a counterexample to the total-density
inequality; an explicit nonnegative theta example demonstrates the difference.

## Build and check

Requirements: Python 3.10 or later and a LaTeX installation providing
`pdflatex` and the standard packages listed in `article.tex`.

```sh
python3 verify.py --output verification_results.json
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

Or run:

```sh
bash build.sh
```

The supplied JSON records an actual successful run: 56 graph–host instances,
11 sign-code cases, six shortest-relation cases, three theta cases, and the
incidence-graph certificate. All assertions use exact integers or fractions.
The checker precomputes arithmetic tables for its small test groups; the
paper's BFS complexity is stated for supplied constant-time group operations.

## Files

- `article.tex`, `article.pdf`: the manuscript and its compiled 25-page PDF.
- `verify.py`, `verification_results.json`: checker and recorded output.
- `faces.json`: complete incidence data, with disjoint point/face indexing.
- `SOURCE_AUDIT.md`, `source_manifest.json`: provenance, limited review scope,
  pinned repository heads, and source references.
- `INTEGRATION.md`: proposed repository location and formalization plan.
- `VALIDATION.md`: actual checks, PDF quality control, and trust boundaries.
- `results_manifest.json`: machine-readable statement/status inventory.
- `build.sh`, `checksums.sha256`: reproducible build entry point and integrity data.

## Status and limits

The package contains complete written proofs of the stated results and
finite computational checks. It is an AI-assisted research draft, not an
independently refereed or Lean-kernel-verified article. Priority of the
combined refinements has not been established by an exhaustive literature
search. Familiar ingredients are explicitly identified rather than claimed
as inventions.

No unrestricted Sidorenko counterexample is claimed here. In particular,
the typed activation kernel in the source repository has not been identified
with a scalar convolution kernel. The paper does not improve general
Szemerédi or van der Waerden bounds. These are new candidate research
contributions for expert review, not certified resolutions of those broader
problems.

No repository has been modified. The proposed integration path is a new
research directory, not an assertion that such a directory currently exists.
