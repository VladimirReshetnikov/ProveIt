# Report 31 — A binary planar four particle shuttle

Start with `report31.pdf`; `report31.tex` is the editable article source.

The report gives a standalone binary mass-four planar construction, its all-input conservation and locality proof, exact orbit phases, stationary and drifted spatial counts, first arrivals and inverse estimates. The specified rules have exact radius six, 78 essential input cells and Boolean degree 45. A separate one-step quartic has 614 canonical nonnegative-integer auxiliaries, 693 residuals, 79 external variables and 3403 collected terms. The one-step certificate is not an unbounded-time reachability certificate.

The one-dimensional patterns are attributed to Report 12. Only the two bounce outputs are changed transversely. Report 30's weighted example and separate complete-target theorem are cited, not rewritten. No reversibility, universality, minimal-radius-among-constructions, or general finite-fold claim is made.

## Contents

- `report31.tex`, `report31.pdf`: full article and verified rendering
- `figures/`: vector rule and actual simulation figures, exact trace data, regeneration source
- `scientific/PROOF.md`, `scientific/LOCAL_ALGEBRA.md`: reviewed source proofs
- `scientific/code/`: direct component model, independent local cylinders, exact formulas, finite checks, quartic builder and separate artifact reader
- `scientific/local-rule-certificate.json`: sixteen exact birth/removal cylinder masks
- `scientific/local-quartic-certificate.json`: literal 3403-term sparse quartic, variable order, all gates and residuals
- `scientific/audit/`: independent component, drift, implementation and quartic reconstruction checks, all 78 explicit essentiality flip witnesses, reviews and assertion-hardening lineage
- `verification/`: fixed expected receipts and exact source provenance
- `replay.py`, `reproduce.sh`: identity-gated isolated replay
- `tamper_regression.py`: bounded integrity and strict-type tests
- `build.sh`: external-copy PDF build, with optional figure regeneration
- `SHA256SUMS`: whole-release file checksum list, excluding itself

## Requirements

Scientific replay requires Python 3.10 or later and only the standard library. It was verified with CPython 3.12. There is no network dependency, package installation, numerical solver, symbolic-algebra dependency or external source-cache requirement. Each scientific command has a 900-second timeout; a full normal/optimized replay may take several minutes.

PDF rebuilding additionally requires a POSIX shell, TeX Live or equivalent with `pdflatex`, `pdftex`, `kpsewhich`, and these LaTeX packages: `fontenc`, `lmodern`, `amsmath`, `amssymb`, `amsthm`, `mathtools`, `booktabs`, `array`, `longtable`, `geometry`, `microtype`, `graphicx`, `fancyhdr`, `enumitem`, `hyperref`. Figure regeneration additionally requires Matplotlib; the supplied vector figures make that optional. Poppler `pdfinfo` and `pdftoppm` are useful for independent visual inspection, not required by scientific replay.

## Verify before executing scientific code

From this release directory:

    sha256sum -c SHA256SUMS
    python3 -I -B replay.py --verify-only

The first check is a conventional transport check. The second checks the exact required file set and SHA-256 values embedded in the verifier before scientific execution. Editing the public checksum file together with a payload does not defeat those embedded pins. As with any delivered code, the verifier and published archive checksum are the bootstrap trust boundary; this is not a signature or defense against replacement of the entire archive and verifier together.

## Run all finite checks

Choose a fresh output directory outside the release:

    ./reproduce.sh /tmp/report31-replay
    python3 -I -B tamper_regression.py --output-dir /tmp/report31-tamper

An existing output directory must be empty. Scientific scripts run only in fresh external copies, with Python isolated mode and bytecode disabled. The reconstruction script writes an adjacent receipt only inside its temporary copy. No delivered file is rewritten. The replay checks original payload bytes, modes and modification times before and after execution, compares normal and optimized receipts exactly, and compares JSON types recursively. In particular, `true` is not accepted in place of integer `1`.

Primary output, cylinder certificate, rebuilt quartic, quartic checks and independent geometry-to-quartic reconstruction are compared with the fixed expected artifacts. The independent component, drift, cross-implementation and essentiality text receipts are compared byte for byte. The three early assertion-based audits were mechanically hardened; their recorded source lineage confirms unchanged check expressions and original counts. Every scientific checker used in replay remains active under `-O`.

The quartic reader checks 350 binary local fixtures and wrong outputs, all 614 upward unit perturbations of the vacuum auxiliary witness, and 60 nonbinary identity fixtures. These finite tests do not prove universal witness uniqueness; the triangular-chain proof does. The independent geometric reconstruction proves artifact agreement by exact finite symbolic expansion for this pinned circuit. Neither checker is advertised as a validator for arbitrary untrusted replacement certificates.

Bounded tamper cases alter code, remove the certificate, alter the certificate while refreshing the public checksum file, and add an unexpected file. All must fail at the pre-execution identity gate. Five strict JSON-type mismatches are separately rejected. No scientific code from a tampered copy is executed.

## Rebuild the PDF

    ./build.sh /tmp/report31-build

To regenerate the figures from actual simulation as well:

    ./build.sh /tmp/report31-build-with-figures --regenerate-figures

The build verifies identity first, copies sources to a fresh external workspace, disables TeX shell escape, and writes only to the requested external output. TeX format/font-map recovery is confined to a temporary cache. PDF metadata dates are fixed to 3 October 2026; binary equality can still depend on the TeX/font/Matplotlib versions. No byte-identical PDF claim is made across different toolchains. The mathematical simulation data are exact integers and portable.

Do not run the individual source scripts directly inside the release if they write adjacent files. Use the isolated replay or an independently made external copy. No previous release is needed to run the checks or verify the standalone construction; citation identities are recorded without copying previous-release source material.

## Interpretation

The all-input theorem concerns finite or infinite malformed configurations and is established by local exact-component recognition and a bounded-displacement bijection. Finite regression coverage is evidence for the implementation, not exhaustive enumeration of the binary full shift. The local quartic has a unique auxiliary tuple over both the nonnegative integers and reals; this particular fact does not transfer to arbitrary unbounded-time Diophantine encodings.
