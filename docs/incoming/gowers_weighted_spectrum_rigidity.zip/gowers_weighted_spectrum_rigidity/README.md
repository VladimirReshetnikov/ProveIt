# Weighted Derivative Spectra and Sharp Local Rigidity

**Explicit Freiman restriction, an optimal near-extremal U³ profile, and the limits of stability for correlation weights**

Research article prepared for Vladimir Reshetnikov, 6 October 2026, with mathematical development and computational verification using ChatGPT.

## Article and package

The complete article is `gowers_weighted_spectrum_rigidity.pdf`; its self-contained source is `gowers_weighted_spectrum_rigidity.tex`. The source includes the bibliography and needs no external figures, bibliography database, downloaded files, or shell escape. The archive also contains:

| File | Purpose |
| --- | --- |
| `Makefile` | Compile the PDF and reproduce the diagnostic runs |
| `requirements.txt` | Python dependency for the numerical spectral program |
| `code/verify_spectral_rigidity.py` | Weyl identities, extremal subgroup diagnostics, quartic envelope, and exact two-point equality |
| `code/verify_weighted_extraction.py` | Exact finite weighted BSG and Freiman restriction diagnostics |
| `code/verify_weight_defects.py` | Exact weight examples, selected-graph diagnostics, and exact-coset transfer diagnostics |
| `data/*.json` | Recorded results, actual ranges, seeds, and tolerances |
| `SOURCE_LEDGER.json` | Pinned repository sources, input hashes, published prerequisites, and attribution |
| `VALIDATION.json` | Build and review scope, environment, and verification summary |
| `SHA256SUMS` | Checksums of the delivered files, excluding this checksum list itself |

## Principal results

Use normalized averages on a finite abelian group G. For nonzero f define

\[
\kappa=\|f\|_{U^3}^8/\|f\|_2^8,\qquad \delta=1-\kappa.
\]

Let F(f) be the largest squared normalized correlation with a quadratic phase supported on a subgroup coset, with that phase normalized to have L² norm one. Quadratic means that all third multiplicative derivatives are one; this definition includes the phases required in even torsion.

1. **Exact local fidelity profile (Theorem 4.4).** If δ < 1/120, then

   \[
   1-F(f)\le\frac{1-\sqrt{(1+\sqrt{1-4\delta})/2}}2.
   \]

   This bound, and its associated squared L²-distance bound, are attained for every δ in the stated interval by a two-point example. The proof first recovers a maximal isotropic subgroup without a group-exponent loss and then derives a quartic envelope. The leading infidelity constant is 1/4. The cutoff 1/120 is sufficient, and is not claimed optimal.

2. **Quartic deficit and an odd-order improvement (Theorem 4.3).** At fidelity 1−t, t ≤ 1/6,

   \[
   \kappa\le(1-t)^4+14(1-t)^2t^2+t^4.
   \]

   An explicit nonnegative deficit controls concentration of the remaining eigenbasis probabilities and their order-two symmetry. In odd order the coefficient 14 improves to 12; that odd-order bound is not claimed optimal.

3. **Sharp selected-graph stability (Theorem 5.1).** For normalized squared derivative coefficients q and a partial selected graph of score at least 1−ε, ε ≤ 1/400, the best comparison phase has full support. Its derivative labels form a symmetric homomorphism. Missing directions and wrong labels together occupy at most an ε fraction of the group, and its phase infidelity is at most (1−√(1−2ε))/2. Both separate bounds are sharp. A joint inequality is also proved, without a claim of joint optimality.

4. **Weighted exact Freiman restriction (Theorems 7.1 and 7.2).** A graph with difference ratio at most C admits an order-k exact Freiman restriction retaining at least 1/(k C^(2k+1)) of any prescribed nonnegative weight. A finer formula uses the actual vertical defect set and includes exact finite rounding. The smaller mixed-sumset mechanism is credited to Green–Tao. A bounded-fiber weighted energy extraction composes with this restriction, giving retention

   \[
   \frac{c^{20k+11}}{k\,2^{42k+24}K^{2k+2}}.
   \]

   Here the original weight is at most one, has mass M and energy at least cM³, 0 < c ≤ 1, and each first-coordinate fiber contains at most K support points. At k=8 the factor is 2^-363 c^171 K^-18.

5. **Preservation of the original derivative correlation (Theorem 8.1).** The weighted extraction is applied to a specified region of the derivative spectrum over a prime cyclic group. It retains the original squared correlations on an exact Freiman graph, with a bound in terms of the threshold spectrum's mass, fourth-moment mass, largest coefficient, and fiber cap. This supplies a precise local answer to the prior report's correlation-preservation question.

6. **The appropriate topology for weight stability (Theorem 9.1 and Proposition 9.4).** The energy defect controls U² oscillation on the extremal subgroup and the squared masses of other cosets. The total variation distance of a general derivative spectrum from an exact coset-phase spectrum is exactly its mass outside that subgroup. This gives linear bounded-weight transfer and a coupled defect estimate. Explicit bent-function and diffuse-coset examples rule out unrestricted, dimension-independent L¹ stability. Fourier and coset complexity assumptions restore an L¹ conclusion.

7. **A weighted square-root-mass corollary (Appendix A).** From Reiher–Schoen one obtains weight mass at least (1−ε)√c M and difference ratio at most 2^60 ε^-11 c^-11/2. This is presented as a derived consequence of published work, not as a new weighted BSG principle.

The article concludes with thirteen specific research questions, including the full critical-norm profile, sharp odd-order constants, the exact joint graph tradeoff, torsion-sensitive restriction, improved fiber-profile bounds, compatible restrictions across slices, and formal quantitative integration.

## Quantitative comparison with Gowers

For an unweighted graph with M points and at least cM³ additive quadruples, the order-eight guarantees are:

| Route | Retained domain size |
| --- | --- |
| Gowers, Corollary 7.6 | 2^-1882 c^1164 M |
| Elementary route in this article | 2^-363 c^171 M |
| Reiher–Schoen plus the restriction, with η=1/4 | 3·2^-872 c^(137/2) M |

The latter two guarantees are not uniformly ordered because their numerical constants differ. One may take their maximum or optimize the modern parameter η. None of these local estimates has been propagated through the complete Szemerédi argument in this package.

## Build and reproduce

From this directory:

```sh
make pdf
make verify
```

The PDF requires a standard TeX Live installation with pdfLaTeX, latexmk, AMS packages, mathpazo, mathrsfs, microtype, booktabs, longtable, enumitem, needspace, fancyhdr, xurl, hyperref, and bookmark. The checked build used TeX Live 2023 and latexmk 4.83.

The diagnostics require Python 3.10 or later. Only the spectral program needs NumPy; the other two use Python's standard library. If NumPy is absent, install the requirement in an appropriate Python environment. The recorded run used Python 3.12.14 and NumPy 2.3.5. Exact checks are distinguished from floating-point diagnostics, whose residuals can vary slightly across platforms.

Individual programs can run from any working directory. By default their JSON results go to the package's `data/` directory. The weighted extraction and weight-defect programs also accept `--output PATH`. `make clean` removes LaTeX auxiliary files and preserves the PDF and recorded JSON files.

## Verification scope

The included proofs justify the universal statements. The programs are supplementary diagnostics, not proofs of the general theorems and not proof-assistant certification.

The recorded runs include 108 near-coset examples on nine finite abelian groups; direct cube identities on the six smaller groups; 7,846 nonempty partial prime-field graphs; 31,384 weighted or unweighted restrictions; 364,560 symmetric defect-set/order cases; 85 weighted BSG inputs; 343,587 injective path checks; and 255 composed restrictions. The weight program includes exact rational counterexamples and defect decompositions, 861 selected-graph checks, and 33 coset-transfer states with 528 bounded-weight comparisons.

Separate ChatGPT work streams reviewed the spectral arguments, weighted extraction, and attribution/weight-defect arguments. This is internal AI-assisted checking, not independent human peer review. The authorial and proof-status disclosures should remain with the article when it is integrated.

## Repository integration

The inspected checkpoint is:

`e3125e6982abe2d44bd7cb9369063d4e69d41a2d`

Repository: https://github.com/VladimirReshetnikov/ProveIt/tree/e3125e6982abe2d44bd7cb9369063d4e69d41a2d/Combinatorics/Ramsey

The package is suitable for a new research subdirectory such as `Combinatorics/Ramsey/Research/GowersSzemeredi/weighted-spectrum-rigidity/`, or for the repository's existing research-report intake process. No repository files were changed and no pull request was opened.

Useful integration anchors are:

| Existing interface | Article interface |
| --- | --- |
| Gowers Proposition 6.1 / existing weighted refinement | Proposition 2.2, a credited prerequisite with a phase-space proof |
| `lemma_7_5` and `lemma_7_5_holds` | Theorem 7.1, using the vertical-defect injection into (k+1)Γ−kΓ |
| `corollary_7_6` | Theorem 7.2 and the comparison in Section 7.2 |
| Theme II correlation-preservation question | Theorem 8.1, with prime-cyclic and fiber hypotheses explicit |
| Exact graph/phase rigidity and near-equality questions | Theorems 4.3, 4.4, 5.1, 9.1 and Proposition 9.4 |

Section 10 gives a dependency-ordered formalization plan. This delivery contains no new Lean files, and no Lean build was run. The proof-status ledger should not be promoted on the basis of this report. The source audit and the bounded literature review support the stated attributions; historical priority for the exact local profile remains unverified.
