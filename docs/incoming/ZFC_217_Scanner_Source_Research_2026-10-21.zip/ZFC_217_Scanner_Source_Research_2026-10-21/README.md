# Toward a 217-state ZFC consistency machine

**Status: the requested construction has not been achieved.** This is a research
packet with proved components and rejected integrations. It does not contain a
new machine with at most 217 states whose non-halting has been proved equivalent
in ZFC to Con(ZFC). All new literal 217-state tables are explicitly marked
`rejected` because their intended source-simulation contracts fail.

The complete manuscript is `report.pdf`, built from `report.tex` and its included
TeX files. The repository snapshot used is
`704b87442afbd571833a628cd558f1d207fd8b2f`:

<https://github.com/VladimirReshetnikov/ProveIt/tree/704b87442afbd571833a628cd558f1d207fd8b2f/Computability/BusyBeaver/Research/ZFC>

The dominated-rho8 source was already in the incoming reports at this snapshot.
It is an inherited input, not a new result of this investigation.

## New results

1. **Exact local scanner reduction.** Delete native state 50 and set
   `34/0 = 1L196`, `77/1 = 0L75`. At a state 34 entry scanning zero, assume that a
   zero in the immediately preceding cell implies a zero in the cell before it.
   The old and new computations then join with exactly the same entire tape.
   The proof covers arbitrary bi-infinite completions of the unspecified cells.
   Its premise is verified throughout all 6,167 quantified primitive interfaces
   of the primary input and all 6,176 of the dominated input. The ordinary
   equality-decoder use of 77/1 remains an integration conflict.

2. **Five exact source recodings.** Five supplied sources have 206 distinct DAG
   nodes, 4,751 primitive occurrences, and maximum zero run 5, compared with 203
   nodes and maximum zero run 6 in the dominated input. They preserve the exact
   primitive word and every guarded successor. Two separate CFG constructions
   check this statement. It gives a one-step bisimulation for all natural
   register vectors. A source DAG node is not a physical TM state.

3. **Safe alternative seed.** A checked 79-node closed proof derives native
   formula code 3. A clean-seed invariant and cofinality argument show that the
   unchanged abstract source remains a refutation search when started with
   logical registers `(4,3,0,0,3,0,0,0,0)`. The inherited K/S derivability and
   source/compiler contracts are explicit premises. This does not certify the
   rejected shortened-scanner binary table.

4. **Explicit logical obstructions.** Three-valued matrices obstruct recovering
   S or K from several restrictions of the fourth parameter of rho8. They
   include the retained quantified/equality logical rows and literal native
   numerical codes, including the zero alias. The full gated set-theoretic
   bundle is excluded: each matrix fails an explicit permitted bundle instance.
   These are not equiconsistency impossibility results for the full theories.

## Small checks

Run from the archive root with Python 3.10 or later, assertions enabled:

```sh
python3 -B code/check_packet.py
python3 -B proofs/scanner/check_scanner.py inputs/primary218.native.tm
python3 -B source-layout/verify_sources.py
python3 -B formalism/verify_all.py
```

These commands need only the standard library. The first uses a separate sparse
tape simulator and checks literal state counts, the exact patch deltas, the
complete 104,082-step blank startup of the rejected short scanner, and its
ordinal 40 full-frame counterexample. It compares the entire tape, not merely
register values or a visit to dispatch state 84. The second checks all local
scanner branches on partial tapes. The source and formalism commands replay
their finite mathematical certificates.

The startup observation and the failed interface are deliberately both kept:
successful initialization alone does not establish the later simulation.

## Quantified runtime and scanner-premise replay

```sh
python3 -B code/audit_runtime_premise.py \
  inputs/primary218.native.tm inputs/primary-sites.json replay/primary
python3 -B code/audit_runtime_premise.py \
  inputs/dominated218.native.tm inputs/dominated-sites.json replay/dominated
```

The symbolic input allows arbitrary natural registers, gap, first spare, and an
arbitrary finite remaining spare list. Its 4,000-rule construction limit does not
bound the values or concrete execution time represented by a completed proof.
The underlying runtime modules are copied unchanged from the inherited report.

Expected totals:

| Input | Guarded interfaces | Symbolic rules | State 34 entries |
|---|---:|---:|---:|
| Primary |6,167|1,515,158|15,850|
| Dominated |6,176|1,616,989|15,881|

The only recorded three-bit prefix languages are the singletons
`000`, `010`, `011`, `100`, `101`, `110`, `111`. The forbidden prefix `001`
is absent. Original receipts are in `proofs/scanner/`; fresh runs of the portable
drivers are in `verification/portable-primary/` and
`verification/portable-dominated/`. Elapsed times and path-edited driver hashes
can differ. Input hashes, cases, rule totals, and scanner-prefix conclusions
must agree. Case summaries are stored as losslessly compressed JSON.

These are ordinary mathematical certificates checked by Python. The packet
does not add a completed proof-assistant theorem for a new consistency machine.
The inherited calculus-to-ZFC translations remain dependencies in the repository.

## Source reconstruction

From `source-layout/`:

```sh
python3 -B zero5_dp.py --source data/seed205.json --out replayed_dp --beam 4
```

Use an output directory that does not already exist. The four reconstructed
files match `data/zero5_dp0.json` through `data/zero5_dp3.json` byte for byte.
The fifth source was obtained by a separate reassociation search; the fixed
output checker, rather than its discovery history, is the certificate.

## Literal tables and their status

| File | Working states | Status |
|---|---:|---|
| `inputs/primary218.native.tm` |218|Inherited primary input|
| `inputs/dominated218.native.tm` |218|Inherited dominated-rho8 input|
| `experiments/rejected-short-scanner217.native.tm` |217|Wrong complete source frame at ordinal 40|
| `experiments/rejected-scanner-relay217.native.tm` |217|Local scanner proof; ordinary equality use conflicts|
| `experiments/rejected-equality-relay220.native.tm` |220|Prefix relation passes; seven finite primitive interfaces fail|

A row has the form `state read write direction next`, with directions `L`/`R`.
Both symbols are binary. The tape is bi-infinite, initially all zero for a blank
run. The native input label is 0, the main dispatch label is 84, and terminal
label 254 has no outgoing transitions and is excluded from the working-state
count. Labels need not be consecutive. Some inherited receipts use legacy
dispatch label 96; the mapping is supplied in `vendor/inputs/legacy_mapping.json`.

Failure of a specific arbitrary-input simulation interface is not, by itself,
a proof that a table's ultimate blank-run behavior cannot admit a different
interpretation. No such alternative calibration is established here.

## Optional experiments and proof scope

`experiments/discovery/` contains bounded exploratory search and allocation
programs. Consult its README for supported invocations and limitations. Their
negative results exclude only the stated finite templates. No allocation
optimum or failed search in this packet is a universal state lower bound.
The optional allocators use NumPy/SciPy; C++ searches require a compiler.

The most concrete remaining design problem is to allocate one of the actual
five-zero sources within 218 states while respecting contextual decoder detours
and primitive-entry phases. Removing scanner state 50 would then still require
the complete runtime and blank-start proofs.

## Build and integrity

```sh
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
sha256sum -c MANIFEST.sha256
```

The manifest describes the delivered files before any replay writes receipts.
`inputs/provenance.json` pins the exact inherited tables and source bytes. The
subdirectory manifests identify source and formalism certificates. The copied
upstream files retain their attribution; the applicable upstream license texts
are under `LICENSES/`.
