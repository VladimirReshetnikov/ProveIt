# Self-Embeddings of the Surreal Numbers
## A structural and foundational atlas

Prepared 3 October 2026.

## Reading

Start with `surreal_self_embeddings.pdf`. The complete editable source is
`surreal_self_embeddings.tex`; its bibliography is self-contained (no BibTeX
run or external image assets are needed).

The article distinguishes order, simplicity, birthday, field, strong Hahn
summation, valuation, exponential, differential, and elementary embeddings.
It treats the full proper class, set-sized birthday cutoffs, and
universe-relative carriers separately. It includes conventional proofs,
explicit examples, a source-level ProveIt integration roadmap, and fourteen
research questions. A proof-obligation/status ledger and a catalogue of
common invalid arguments are included as appendices.

Particularly useful entry points:
- The twice-iterated Hahn lift and explicit bounded/cofinal proper images.
- Fixed fields, iterated-image cores, and continuity versus strong summation.
- Bounded and proper cofinal elementary exponential embeddings, with stated
  class-theoretic assumptions.
- Exponential value-action rigidity, and the limits of that rigidity.
- Paradox-free foundations and the proposed Lean implementation layers.

## Status

This is an unrefereed research manuscript, not a Lean-certified development.
No exhaustive novelty or priority claim is made. Established background,
proofs supplied in this article, repository proposals, and further questions
are distinguished. The ProveIt repository was inspected selectively and was
not rebuilt. The article does not claim a complete classification for every
possible expansion of the surreal structure.

`SOURCE_AUDIT.md` records the repository snapshot, the actual files inspected,
important source limitations, and principal external references.

## Build the PDF

Requirements: a recent TeX Live or equivalent distribution with pdfLaTeX and
the standard packages used in the source, including newtxtext/newtxmath,
microtype, tcolorbox, xurl, hyperref, cleveref, and listings.

On a Unix-like system:

```sh
./build.sh
```

Or, on any system with pdfLaTeX installed:

```sh
pdflatex -interaction=nonstopmode -halt-on-error surreal_self_embeddings.tex
pdflatex -interaction=nonstopmode -halt-on-error surreal_self_embeddings.tex
pdflatex -interaction=nonstopmode -halt-on-error surreal_self_embeddings.tex
```

The script places intermediate build files in `.build/` and copies the
finished PDF beside the source. The font packages must be installed through
normal TeX distribution channels; no font files are included in this package.

## Reproduce the finite regression checks

Python 3.10 or newer; standard library only:

```sh
python finite_checks.py
```

The included `finite_check_results.json` records 22,169 successful exact
finite checks, with random seed 20261003. These check rational compression,
finite sign-sequence embeddings, and finite Hahn-polynomial identities.
They are regression tests, NOT proofs of transfinite summability, class
recursion, elementary embedding theorems, or any Lean declarations. Those
claims are addressed by the mathematical proofs and their stated inputs.

## Contents

- `surreal_self_embeddings.pdf`: compiled article.
- `surreal_self_embeddings.tex`: complete source and bibliography.
- `SOURCE_AUDIT.md`: provenance and trust boundaries.
- `finite_checks.py`: exact finite tests.
- `finite_check_results.json`: recorded test result.
- `build.sh`: reproducible PDF build command.
- `README.md`: this guide.
- `SHA256SUMS.txt`: integrity hashes for the other package files.
