# Three mass units in a reversible weighted cellular automaton

This release contains a mathematical report, editable LaTeX sources, a finite collision-rule generator, literal example rules, natural-number quadratic certificates, and reproducible verification scripts.

## Result and scope

Exactly three conserved typed mass units suffice for a fixed globally reversible one-dimensional weighted Boolean-channel CA with undecidable committed-halt-pattern occurrence. The transparent native construction has radius at most four; spatial blocking gives radius one with four times the types and the same physical ticks. An alternative internal four-phase dilation preserves old coordinates and uses four times the types and ticks. Both preserve the mass. A separate general proof makes mass at most two decidable under a unique vacuum and positive integer weights.

Many types have weight one. This is not the ordinary single-integer-state NCCA mass convention. Universality uses the classical existence of a universal reversible two-counter source in the stated separated syntax. This release does not contain its expanded universal source table or assert literature-wide novelty. Close three-agent geometric arithmetic prior art is credited in the report.

The quadratic certificate is over natural numbers at an externally fixed source horizon. It certifies the reconstructed canonical trajectory up to first committed halt; it does not take an arbitrary physical history as its input. Its arity grows with the horizon. The report separately counts input coordinates, output coordinates, loader variables and core auxiliaries.

## Files

- `three-mass-report.pdf`: full report, proofs, model boundaries, source-critical references and questions left open
- `three-mass-report.tex`: standalone combined LaTeX source
- `tex/`: editable modular source used by `build.sh`
- `code/`: pure standard-library Python implementations and independent checks; `code/legacy/` contains the two pre-clock source snapshots used only for byte-compatibility regression
- `examples/`: exact finite local-rule exports and certificate requests, polynomials, witnesses and check receipts
- `receipts/`: published verification receipts for this source revision
- `SOURCE_PROVENANCE.md`: frozen generator identity and source/receipt conventions
- `SHA256SUMS`: SHA-256 of every published file other than the manifest itself
- `verify_manifest.py`: portable integrity verification, including missing/extra-file checks
- `replay.sh`: full fresh replay into `.replay/`

`code/spatial_radius_one.py` implements time-preserving spatial blocking; `code/radius_one.py` implements coordinate-preserving internal phase dilation. Their encoded lane labels have different meanings and are not interchangeable.

The cycle rule is a four-operation test source with an unused final state, not a universal machine. The mixed certificate source is a nine-instruction halting chain, also not a universal machine.

## Quick start

Requirements: Python 3.10 or newer with its standard library, a POSIX shell, and enough disk space for the literal rules (about 20 MB uncompressed plus replay outputs). No network, third-party Python packages, accounts or credentials are needed. The full suite uses assertions: do not set `PYTHONOPTIMIZE` or run the full suite with `-O`. The replay separately runs the explicit-check clock, spatial-blocking and strict-input tests under `-O` as well.

From the extracted directory:

    python3 verify_manifest.py
    sh replay.sh

The replay fails immediately on a failed check. It writes fresh receipts under `.replay/`, leaves the published source/examples/receipts intact and checks literal exports against the stored bytes. The longest checks enumerate collision support and physical microsteps; expect several minutes depending on hardware. Timing fields in runtime receipts may vary without changing the verified results.

## Direct certificate use

First create the output directory, then run:

    mkdir -p .replay
    python3 code/certificate.py export examples/mixed_request.json .replay/mixed.json --expanded
    python3 code/certificate.py witness .replay/mixed.json .replay/mixed-witness.json
    python3 code/checker.py .replay/mixed.json .replay/mixed-witness.json

The native nine-step fixture has final raw integer 1 at tick 5,340. It has 180 core auxiliaries and two extracted output coordinates, hence 182 natural variables, 30 affine-square slots and 90 nonnegative affine-product slots. Its native expansion has 16,593 nonzero monomials. The phase-dilated radius-one clock variant has physical time 21,360 with the same variable and slot ledger. The spatially blocked radius-one realization keeps the native time 5,340 and reduces the canonical gap from 12N old cells to 3N new blocks.

The request's optional `clock_scale` is 1 for native or spatially blocked radius-one ticks, or 4 for the four-phase radius-one realization. Omission means 1. `examples/mixed_radius_one_request.json` shows the four-phase convention. Choose a clock before constraining or extracting physical time; the checker verifies it against the schema.

The certificate exporter supports fixed positive raw input, free positive raw input through N=x+1, and an explicitly paid finite bounded counter loader. An arbitrary raw N may contain a cofactor coprime to 6; it is not silently tested for 2-and-3 smoothness. Consult the full report before interpreting variable counts.

## Rebuild the PDF

Install a normal TeX Live distribution with `article`, `fontenc`, `lmodern`, `geometry`, `amsmath`, `amssymb`, `amsthm`, `mathtools`, `booktabs`, `longtable`, `array`, `microtype`, `xcolor`, `hyperref`, `fancyhdr`, `enumitem`, `listings`, and `pict2e`. Then:

    sh build.sh

The build uses three LaTeX passes, puts intermediates in `.build/` and replaces the local PDF. It requires no shell escape. The source date is fixed to 3 October 2026 UTC; exact PDF bytes also depend on TeX and font versions. Rebuilding can therefore cause the original manifest check for the PDF to fail even when the rendered content is unchanged.

To rebuild from the single-file source instead, use `pdflatex` on `three-mass-report.tex` three times in a writable working directory.

## Integrity and evidence

The archive contains only regular files with relative paths. No third-party papers are redistributed; verified source URLs are in the bibliography. Published receipts are evidence of finite checks against their recorded source hashes, not formal proofs or claims of novelty. The full mathematical arguments are in the report.
