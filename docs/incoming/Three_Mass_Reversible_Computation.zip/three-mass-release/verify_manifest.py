#!/usr/bin/env python3
"""Verify the published SHA256SUMS without external tools or network access."""
import hashlib
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
expected = {}
for line in (ROOT / 'SHA256SUMS').read_text(encoding='utf-8').splitlines():
    digest, name = line.split('  ', 1)
    p = PurePosixPath(name)
    if (p.is_absolute() or '..' in p.parts or not name or name in expected
            or p.as_posix() != name or '\\' in name or name == 'SHA256SUMS'):
        raise SystemExit('Unsafe or duplicate manifest path: ' + name)
    if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
        raise SystemExit('Invalid digest for ' + name)
    path = ROOT.joinpath(*p.parts)
    if any(ROOT.joinpath(*p.parts[:i]).is_symlink() for i in range(1, len(p.parts)+1)) or not path.is_file():
        raise SystemExit('Missing or non-regular file: ' + name)
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != digest:
        raise SystemExit('Hash mismatch: ' + name)
    expected[name] = digest
allowed_generated = {'.build', '.replay', '__pycache__'}
extra = []
for p in ROOT.rglob('*'):
    relative = p.relative_to(ROOT)
    if any(part in allowed_generated for part in relative.parts):
        continue
    name = relative.as_posix()
    if p.is_symlink() or (not p.is_dir() and not p.is_file()):
        raise SystemExit('Non-regular published entry: ' + name)
    if p.is_file() and name != 'SHA256SUMS' and name not in expected:
        extra.append(name)
if extra:
    raise SystemExit('Unlisted files: ' + ', '.join(sorted(extra)))
print('PASS: verified ' + str(len(expected)) + ' published files')
