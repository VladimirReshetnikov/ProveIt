# The Leading Asymptotic of OEIS A293239

This report proves that the number a(N) of nonzero monomials in the Nth derivative of x^x satisfies a(N)=N^2/2+o(N^2). Equivalently, the zeros of the first-kind Lehmer–Comtet triangle have density zero.

The proof is self-contained: it gives the exact coefficient integral, its tanh-coordinate differential, the full real/complex saddle classification, global contour selection, compact-uniform additive cosine law, explicit nonzero phase curvature, the integer-triangle lemma, and the final compact exhaustion.

The exact term-count formula and complete classification of zeros remain open. The report does not claim a global quantitative error rate or numerical threshold. It is a conventional analytic proof, not a formal proof-assistant development or an externally refereed publication.

## Files

- `article.pdf`: eight-page report
- `article.tex`: complete LaTeX source
- `build_local.sh`: build helper for the provided execution environment
- `verify_coefficients.py`: standard-library exact coefficient/derivative checker
- `coefficient_checks.json`: recorded exact verification results
- `check_saddle_normalization.py`: optional mpmath numerical diagnostics
- `saddle_normalization.json`: recorded diagnostics, not proof certificates

## Reproduce

Run `python verify_coefficients.py` for 510 exact tanh coefficient identities and independently matched derivative/Lehmer recurrences through order 200. Run `python check_saddle_normalization.py` for optional numerical orientation; this needs mpmath. A normal LaTeX installation can compile `article.tex` twice, or use `bash build_local.sh` in the supplied environment.

The exact checks supplement the analytic proof and do not establish the conjectured exact zero classification.

## Source position

The live OEIS A293239 entry, checked 1 October 2026, labels a(N)~N^2/2 a conjecture attributed to Vaclav Kotesovec (5 October 2017). Part I of ProveIt's `power-tower-derivative-term-counts/article.tex`, inspected at commit ca81647a9f679e96d49ffdbc54b0c0ab13d10a36, proves only quadratic-order growth and explicitly leaves the leading asymptotic open. The report records a bounded comparison with this source, OEIS A008296, and Jeong's 2026 primary paper on Lehmer–Comtet identities; it does not claim an exhaustive worldwide priority search.
