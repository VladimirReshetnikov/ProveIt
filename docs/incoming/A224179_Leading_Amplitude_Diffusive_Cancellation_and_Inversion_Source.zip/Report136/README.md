# Report 136 — exactly one classical 1243

This is the self-contained research and reproducibility bundle for OEIS
A224179, counting permutations with exactly one classical 1243 occurrence.
Additional 1234 occurrences are allowed.

## Results and limits

Report136.pdf and the editable Report136.tex prove:

- An exact marked-avoider bijection and a shared decreasing-spine formula
- An explicit positive convergent series for the leading amplitude ratio R
- b_n/A_n = R + o(n^(-1/2)), hence
  b_n = (81 sqrt(3)/(16 pi)) R 9^n n^(-4)(1+o(n^(-1/2)))
- The diffusive J profile exp(-u^2/2), an exact endpoint density/tail
  equivalent, and cancellation of the relative square-root correction
- A 23-index binomial-sum construction, rational-diagonal and D-finite
  consequences, and nonalgebraicity
- An explicit 40-variable rational constant term with convergent contours;
  this particular Laurent-period integrand is not called an origin-regular
  rational diagonal
- A rounding-safe inverse threshold with an eventual inside-ceiling width
  o((log x)^(-1/2))

The amplitude ratio R=149/160 remains unresolved. Finite positive partials
are lower bounds only. No certified decimal enclosure, effective onset or
numerical error constant, first nonzero correction coefficient, O(n^(-1)) rate, or all-orders
expansion is supplied. The nearby joint-pattern sequence A224292 already
has an algebraic generating function in Hou–Mansour (2008); it is not the
main target and no new-result claim is made for that known formula.

The report contains the full marked/corner/spine, tableau, fixed-boundary,
Gaussian, endpoint, quantitative, diffusive-profile/cancellation, binomial,
and inversion arguments.
West's underlying avoidance bijection and Regev's strip asymptotic are
attributed to their primary sources. The inherited ingredients from
Reports 134 and 135 are proved again in this report; neither companion
is needed to read or build it. This is a scoped prior-art assessment,
not a claim of worldwide historical priority.

## Reader files

- Report136.pdf: complete article
- Report136.tex: its LaTeX source
- certificate/: offline standard-library Python checks, exact typed fixtures,
  deterministic expected output, and its integrity manifest
- bundle-manifest.json: final bundle inventory, byte counts, and SHA-256 digests

No private working notes, audit correspondence, third-party PDFs, generated
page images, cached Python files, or TeX build products belong in the bundle.
See certificate/README.md for exact finite ranges, commands, and limitations.

## Quick mathematical replay

Python 3.9+ with no third-party packages is sufficient:

    python3 -I -B certificate/verify.py check
    python3 -I -B certificate/verify.py replay
    python3 -I -B -O certificate/verify.py replay
    python3 -I -B certificate/verify.py guard-test
    python3 -I -B -O certificate/verify.py guard-test

Isolated mode (-I) is required; the verifier rejects non-isolated startup
before importing shadowable standard-library modules. Here normal and
optimized mean isolated runs without and with -O, respectively.

Replay is offline. It checks published coefficients through n=25,
exhaustive permutation maps through n=8, three independent tableau-dimension
methods through size37, F/H/J counts, the support-reduced 23-index algebra,
and finite Gaussian/interlacing diagnostics. No infinite theorem is inferred
from finite checks. The 666-term k+t<=35 partial is exactly

    55999844944982350869187286355724963 /
    90113598179756697647360591499090564

This is only a lower bound for R.

## Deterministic PDF builds and fresh packing

The integrated commands in certificate/README.md create external, previously
nonexistent output directories/files, so the sealed bundle remains unchanged.
A TeX Live installation with pdfTeX, AMS, Latin Modern, microtype, geometry,
booktabs and hyperref is required for PDF building; Poppler is needed only
for optional PDF rendering. The builder uses private TeX configuration/cache
paths, no shell escape, two clean LaTeX passes, fixed SOURCE_DATE_EPOCH,
and suppressed volatile PDF metadata. A rebuilt PDF must match the frozen
PDF byte for byte in the tested TeX environment. Different TeX releases or
font versions may produce different PDF bytes; that is an environment
comparison, not a mathematical discrepancy.

Manifest digests detect accidental changes relative to the supplied inventory.
They do not establish external authenticity if both verifier and manifest
have been maliciously replaced. Guard tests deliberately corrupt external
throwaway copies and require fail-closed rejection, including under Python -O.

## Further research

Resolve 149/160 or certify R numerically; make finite-T tails effective;
determine the first nonzero correction after the square-root cancellation;
and compute a usable annihilating equation. These remain open in this report.
