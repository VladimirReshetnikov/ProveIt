# Report191: square Spiro-Fibonacci growth and threshold inversion

This package accompanies the proof of a full asymptotic equivalent for OEIS
A078510, with its exact square-spiral predecessor A265409. The model is prior
work; attribution and the bounded literature-review scope are in
[DATA_SOURCES.md](DATA_SOURCES.md).

With the prescribed seeds a(0)=0, a(1)=1, write r=sqrt(n), w=W_0(4r). The article
proves that a positive constant C exists and

    a(n) = C exp{ r(w-1+1/w)/2 + w^2/32 + w/2 } / sqrt(1+w)
           * [1 + O(w^3/r)].

It also proves a quantitative threshold inversion with O(w_0^2) absolute error,
and an inverse-log expansion to every fixed order through an analytic germ.
The auxiliary Bernoulli-phase correction controls the proof's local defects;
it is not asserted to be a sharp first relative correction of the sequence.

## What is included

- The self-contained article, `Report191.tex`, and the PDF in a built release
- Exact recurrence code and an independent step-generated coordinate check
- Two structurally independent rational inverse-series calculations
- The 64 displayed OEIS terms, indices 0..63, as a bounded attributed fixture
- An offline reproducible builder, closed manifest verifier, and adversarial tests
- A separate optional mpmath diagnostic, explicitly non-certifying

The mandatory checker uses Python's standard library only. It checks geometry
through index 250000, full all-earlier-point brute force through index 4096,
127 complete pre-corner rectangles, all 64 listed terms, and independent exact
inverse-germ coefficients through order 12, including the six displayed terms.
Every invariant remains active under Python optimization.

## Quick start

Python 3.10 or later:

    python3 -I -S -B code/check_exact.py
    python3 -I -S -B -O code/check_exact.py
    python3 -I -S -B reproduce.py
    python3 -I -S -B test_build.py

For a full build, install the manuscript's ordinary pdfLaTeX dependencies,
then choose a fresh output directory outside this package:

    python3 -I -S -B build.py --output "$(dirname "$PWD")/report191-release"

`README_REPRODUCIBILITY.md` explains commands, domains, safeguards, manifest
format, deterministic metadata, extraction, and independent rebuilds.
`code/README.md` explains the mathematical checks.

## Limits

Finite checks supplement the article's all-index and asymptotic proofs. They
do not prove a theorem by numerical sampling. No certified numerical digits
of C, effective asymptotic onset, sharp relative phase term, all-orders relative
expansion of a(n), or exact ceiling of an asymptotic approximation is claimed.
The exact inverse of the piecewise-linear interpolation is distinguished from
any asymptotic estimate. A bounded source review is not worldwide novelty
clearance; general comparison, Lambert-W, and inverse-error methods are prior.

The archive includes no full OEIS records, downloaded third-party programs,
private working notes, transient logs, or research copies of articles.
