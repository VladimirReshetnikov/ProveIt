# Small Turing machines for Con(ZFC)

Research report prepared for Vladimir Reshetnikov, 16 October 2026.

**No new blank-start consistency machine below 253 working states is claimed.**
The archive contains a shorter proposed source theory with an ordinary
consistency-calibration proof, a checked completion of ProveIt's logical engine,
an executable reference refutation checker, and finite machine experiments.

Start with **report.pdf**. Its complete source is report.tex, sections/, and
references.tex. The PDF explains the exact hypotheses, proofs, measurements,
negative results, and remaining compiler obligations.

## Principal contributions

1. **The raw inhabited subworld kernel SR₂⁺.** One joined schema in membership,
   actual equality, and a shared constant W. The matrix has only three free
   slots a,b,z, but unrestricted bound variables. Inhabited separation absorbs
   nonemptiness. Exact Kuratowski tuples recover every parameter arity without
   Extensionality. A set-coded bisimulation quotient interprets extensional
   set theory. The ordinary mathematical argument establishes, in ZFC,
   Con(SR₂⁺) iff Con(ZFC). This theory proof is not yet a Lean/Coq development.
2. **A completed Lean logical engine.** Three new modules supply explicit K/S/
   Peirce derivations from the existing Łukasiewicz row, derive primitive-Bottom
   elimination using the existing rho6, and discharge both hypotheses of the
   repository's named-variable first-order completeness theorem. Ten modules
   freshly compile and 17 theorem roots were audited.
3. **A reference semidecision procedure.** Finite axiom pools share one
   existential world witness. A signed tableau checker handles identity
   equality, capture/shadowing, fresh parameters, and complete instantiation.
   Total bijective natural codecs enumerate formulas, lists, and certificates.
   This is tested reference Python, not a compiled or formally verified TM.
4. **Concrete machine evidence.** All 504 transitions of the existing
   252-state prepared runtime are reached by explicit instruction inputs.
   The independent witness replay takes 26,035 moves. A new bounded
   218,872-candidate initializer-reuse search has no certified survivor.
5. **Measured compiler controls.** A broader 80,000-proposal original-basis
   search retains the prior 268-state control. A 40,000-proposal protected
   quantifier-basis search reaches 269 states. Fixed recipes reproduce exact
   tables; neither table is presented as a calibrated new consistency machine.

## Pins and attribution

| Source | Pinned revision |
|---|---|
| ProveIt | 4747142d5d15213eb711bdadfa3cc7e769fcb7a7 |
| jeff87654/busy-beaver | 297ab8df7e5de329605c3875b4934643b371a5e3 |
| mira-emmy's prior 253 submission | 0d544f2a2e3c18f12278441a74b7879f31cbe856 |

The report reviews requested commits 6d8bc7f1, 63c83cf7, and 0301aa64,
as well as subsequent completeness and intake corrections at the pinned state.
The public 253 machine is prior work by mira-emmy, based on Mira-Cult's 254
construction and Jeff's verification. Its complete Coq build was not rerun here.
The 252 table in this archive is only the existing prepared runtime body.

Primary source links are in the report bibliography and the component provenance
files. THIRD_PARTY.md and the retained license files describe ownership.
The included material is prepared for incorporation; no repository push or merge
was performed.

## Build and quick verification

Requirements: Python 3.10 or later using only its standard library, and a
pdfLaTeX/latexmk installation for the report. Lean 4.32.0 is required only for
the optional formal build.

~~~sh
sha256sum -c MANIFEST.sha256
make report.pdf
python3 -B reproduce.py --output /tmp/zfc-reproduction.json
~~~

The quick driver verifies pinned compiler inputs, recomputes all syntax counts,
exhausts the one-to-four-object tuple regression, runs seven reference-checker
test groups, independently replays all 504 transition witnesses, and regenerates
both selected compiler controls into temporary directories. Four compiler artifacts
per control must be byte-identical to the delivered versions. Assertions must be
enabled; do not run Python with -O.

data/reproduction.json records the successful packaged run. Component folders
carry their more detailed records. No quick command tries to determine whether
ZFC is consistent or waits for an actual refutation.

### Lean

~~~sh
cd lean
python3 reproduce_lean.py --lean /path/to/lean \
  --output /tmp/zfc-lean-verification.json
~~~

The script builds ten modules serially in a fresh temporary directory, checks
the seven pinned dependency Git blobs, and audits 17 theorem roots.
The reconstruction/bridge roots are axiom-free. The two closed completeness
roots depend exactly on propext, Classical.choice, and Quot.sound; no custom
axioms, sorry, or native_decide are used.

The nested lean/lean/ tree preserves the namespace layout expected by its driver.
Only three modules are additions for repository integration:

~~~text
Computability/BusyBeaver/Lean/BusyBeaver/ZFC/
  Lukasiewicz.lean
  TarskiClassicalBridge.lean
  TarskiCompleteClosed.lean
~~~

The seven original modules are snapshots for reproduction. The separate
tarski-documentation-correction.patch changes comments only.

### Optional full bootstrap search

~~~sh
cd machine_experiments
python3 -B search_boot_relocation_complete.py
~~~

This reruns the 218,872-candidate bounded family and writes its JSON record.
It is neither an exhaustive search over all 252-state machines nor a
state-minimality proof. See the component README for the exact restrictions.

## Measurements

| Template, in a common primitive tree grammar | Formula nodes | Matrix holes | Postfix tokens |
|---|---:|---:|---:|
| Open raw SR₂⁺ | 56 | 4 | 77 |
| Raw SR₂⁺ plus the original two atomic vacuity components | 74 | 4 | 105 |
| Original 254-lineage C/G/V bundle | 101 | 3 | 145 |

The common grammar is Bottom, Member, Equal, Imp, All, and opaque matrix holes.
Conjunction and existential abbreviations are expanded. Postfix counts add
explicit term/binder labels; repeated subtrees are counted repeatedly.
The comparable source saving is 27 nodes and 40 tokens. These are **not
machine-state savings**: matrix admissibility, constant treatment, finite-pool
generation, data motion, and grammar/dispatcher effects must be compiled.

The final prepared-runtime coverage uses 8,432 instruction cases,
2,783,994 literal moves, at most 526 moves per case, and only zero spare
blocks. Every row has a separately replayable witness. It does not assert
reachability from the actual blank run.

## Directory map

| Directory or file | Contents |
|---|---|
| report.tex, sections/, references.tex, report.pdf | Complete report |
| lean/ | Checked logical contribution and full minimal source closure |
| reference_checker/ | Exact proposed checker, tests, and synthetic certificate |
| machine_experiments/ | Pinned tables, prepared body, row witnesses, bounded search |
| compiler_experiments/ | Search driver, selected recipes/tables, provenance |
| sources/ | Minimal pinned compiler dependency closure |
| code/, data/ | Syntax/tuple checks and consolidated verification |
| notes/ | Detailed ordinary proof notes and independent review |
| MANIFEST.sha256 | Integrity manifest for the complete delivered tree |

The next concrete objective is a literal complete-frontend compilation of SR₂⁺
with a control using the same backend, followed by the proof that its blank run
halts exactly when its finite refutation checker accepts a candidate.
