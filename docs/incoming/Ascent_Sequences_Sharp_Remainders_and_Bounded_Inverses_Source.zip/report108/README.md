# Report 108

Sharp logarithmic remainders and bounded error inverses for weighted weak ascent sequences and fixed difference ascent sequences. The weak unweighted count is OEIS A336070.

## Deliverables

- `report108.pdf`: the final, self-contained 24-page report
- `report108.tex`: standalone editable TeX, with all proofs and bibliography
- `source/`: eight readable source sections; `assemble.py` deterministically concatenates them
- `checks/`: standalone integer/rational fixtures, explicit-guard verifiers, and deliberate corruption campaigns
- `validation/`: mathematical review status, input provenance hashes, visual review, and build environment
- `manifest.json`: SHA256 and byte count for each packaged payload file

No earlier report is needed to build or understand the proof. No external file is downloaded by the checks or build. The accompanying ZIP includes the final PDF as well as every listed source/check file.

## Conclusions and limits

For fixed positive weights on a compact interval,

    log H_n(w) = log(n!) + n log(6/pi^2) + (w/2) log^2 n + O(log n).

For each fixed integer d >= 1, the corresponding unrestricted difference-ascent count has coefficient d/2 and remainder O_d(log n). The two models are distinct. Their threshold inverse, after the leading Lambert-W term, has a signed logarithmic correction and bounded error. The report also proves improved bounds for the mean and all fixed absolute moments of the number of levels.

The counts are determined only up to polynomial factors. No amplitude, relative-error equivalent, smaller log coefficient, formal transseries, exact integer recovery, or uniform growing-parameter theorem is asserted. Finite checks are not the analytic proof and are not Lean or another proof-assistant formalization.

## Requirements

- Python 3.10 or later; the exact checks use only the standard library
- pdfTeX/pdflatex, standard LaTeX packages listed in the source, and Latin Modern fonts
- `pdfinfo` from Poppler for build metadata
- Bash

The reference environment is recorded in `validation/build_environment.json`. Byte-identical replay is checked in that environment; a different TeX or font distribution may change PDF bytes without changing mathematics.

## Rebuild and verify

From this directory:

    python3 verify_package.py
    python3 -O verify_package.py
    python3 checks/run_checks.py
    bash build.sh
    python3 verify_package.py

The exact campaign itself runs both ordinary and optimized Python and requires corruptions to fail at named substantive guards. See `checks/README.md` for its exact scope. A complete campaign may take several minutes.

`build.sh` rebuilds a local TeX format when needed, fixes the source date, runs three passes, and rejects overfull boxes or unresolved references. The final PDF is copied to the top level. The page renders used for visual QA are not included in the ZIP.

For a genuinely fresh archive replay, choose an output directory that does not yet exist:

    python3 replay.py --archive report108_source_checks.zip --out /tmp/report108-fresh-replay

The replay checks safe archive membership and the manifest, runs the full exact campaign, rebuilds the PDF, checks the manifest again, and requires both the PDF and assembled TeX to match their packaged bytes. It creates detailed logs and `replay_result.json` in the chosen output directory.

`seal.py` regenerates the manifest and deterministic ZIP only after matching visual review and analytic-review gates have passed. Running it after an intentional edit requires renewed review records. `FINAL_SHA256.txt`, distributed alongside the ZIP, hashes the PDF, standalone TeX, manifest, and ZIP; it is intentionally outside the archive to avoid a circular self-hash.
