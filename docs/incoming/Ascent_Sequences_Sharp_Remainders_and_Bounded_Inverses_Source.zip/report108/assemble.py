#!/usr/bin/env python3
"""Assemble the standalone TeX file in a deterministic order."""
from pathlib import Path
ROOT = Path(__file__).resolve().parent
parts = sorted((ROOT / 'source').glob('[0-9][0-9]_*.tex'))
if len(parts) != 8:
    raise RuntimeError(f'Expected eight source sections, got {len(parts)}')
text = ''.join(p.read_text(encoding='utf-8').rstrip() + '\n\n' for p in parts)
(ROOT / 'report108.tex').write_text(text, encoding='utf-8')
print(f'Assembled {len(parts)} sections, {len(text)} characters')
