# Full Gap Spectra of Old Surreal Fields

**Forcing transfer, Easton realization, and continuum many nonisomorphic fields
with identical gap spectra**

Research manuscript, 28 September 2026. Prepared with ChatGPT.

## Contents

- `article.pdf`: the compiled 23-page article.
- `article.tex`: standalone LaTeX source, including the bibliography.
- `verify_finite.py`: dependency-free finite sign/order and block-code checks.
- `verification_results.json`: recorded output of those checks.
- `PROOF_STATUS.md`: attribution, assumptions, and verification boundaries.
- `Makefile`: build and check commands.

## Main results

Theorem 3.4 proves the external-cofinality transfer identity: the full
set-presented gap characters of the old field No^M in N are the outer
cofinalities of ground regular cardinals carrying fresh ordinal functions.
This combines the repository's fresh-sign classification with explicit
coding lemmas, and is not claimed as a new forcing-spectrum theorem.

Theorem 4.3 deduces exact Easton-closed surreal gap spectra under GCH from
the published theorem of Fischer, Koelbing, and Wohofsky.

Theorem 5.4 proves invariance of fresh-function existence under common
small forcing over a fixed inner/outer pair, above the forcing's size in
outer cofinality. The proof uses canonical ground graph names.

Theorem 7.1 is the principal classification result. From a no-new-reals
extension with a new countable ordinal sequence, countably many Cohen
coordinates produce continuum many old surreal fields in one final
universe. All have the same entire set-presented gap spectrum, but no two
are isomorphic as pure fields. Their realized rational cuts distinguish them.

Corollaries 8.2 and 8.4 give exact common spectra: {(omega,omega)} using
Prikry forcing at a measurable cardinal; and
{(omega,omega),(omega_1,omega_1)} using Namba forcing under CH. The latter
requires no large-cardinal assumption. Theorem 9.2 transports the family
to nonconjugate involutions of a single surcomplex field under Global Choice.

Section 11 proposes nine further research questions.

## Repository target

Repository: VladimirReshetnikov/ProveIt
Inspected commit: e21766d04c2b8a9b2cdba0cd43e563024b3bd1b9
Commit timestamp: 2026-09-25T00:26:54Z
Inspection date: 2026-09-28

Main source:
`Algebra/SurrealNumbers/docs/foundations-and-computation/surreal-fields-across-universes/article.tex`

The article computes families requested by Question 19.2, disproves
unrestricted field-isomorphism completeness in Question 19.4, and gives
same-spectrum infinite real-form families relevant to Question 19.7.
It does not settle the pure-order version or agreement on all final
complex constants.

## Build

A standard TeX Live installation with latexmk, pdflatex, newtx, amsthm,
mathtools, microtype, hyperref, cleveref, aliascnt, tikz-cd, booktabs, and xurl suffices.
No bibliography processor or external image assets are needed.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
python3 verify_finite.py --output verification_results.json
```

Or run `make`. Python 3.9 or later is sufficient; no third-party Python
packages are required.

## Evidence and limits

This is an AI-assisted manuscript with written proofs, not an independently
refereed or Lean-verified paper. Published forcing theorems are imported and
credited. Priority in the wider literature is not certified. The finite
checks cannot verify forcing, freshness, cardinal preservation, saturation,
or proper-class constructions. See PROOF_STATUS.md for the exact boundaries.
