# Finite-Output Open-Query Games
## Sharp synchronization and a complexity dichotomy

The main deliverable is `article.pdf` (22 pages). Its editable, self-contained
LaTeX source is `article.tex`. The bibliography is embedded; no remote assets,
external figures, or BibTeX run are required.

## Main results

- Ordered-layer normal form for finite-output open-query algorithms on any
  topological space; optimal depth is the ceiling of the logarithm of minimum
  layer count.
- Exact shortest-common-supersequence representation for colored posets and
  compact countable metrizable realizations of reduced-word profiles.
- Sharp finite Cantor–Bendixson bound `(q-1)h+s`, where `h` is the last
  nonempty derivative rank and `s` counts its colors.
- Exact worst-case q-label query invariant of `t` convergent towers `K_m`:
  `ceil(log2((q-1)(m-1)+min(q,t)))`. Here `K_1` is a singleton and `K_m` is the
  one-point compactification of countably many copies of `K_(m-1)`.
- Sharp sum synchronization: components with at most `m` layers need at most
  `(q-1)m+1` layers jointly. For fixed colorings of depth at most `d`, the exact
  maximal overhead is `ceil(log2(q))` questions. Sharp examples are also compact
  and metrizable.
- Polynomial exact optimization for two labels, versus NP-complete exact
  decision problems for three labels, even on disjoint chains. The existing
  Lagoutte–Tavenas modified-SCS hardness theorem is credited and imported; the
  exact reduction to a power-of-two depth budget is proved in the article.
- A polynomial-time algorithm within `ceil(log2(q-1))` extra questions; in
  particular, within one question for three labels.

Fixed-coloring depth and the supremum over all colorings of a space are
explicitly distinguished. These are finite worst-case results, not claims
about transfinite game determinacy. See `RESEARCH_STATUS.md` for the novelty
and verification boundaries and `SOURCES.md` for the source audit.

## Files

- `article.pdf`, `article.tex`: article and source.
- `code/verify.py`: independent exact minimax, ideal-state search, chain-word
  search, greedy feasibility, closure elimination, and construction tests.
- `results/verification.json`: machine-readable full recorded result.
- `results/verification.log`: recorded console output.
- `results/poset_counts.csv`: exhaustive enumeration counts.
- `results/sharp_families.csv`: universal-family examples. The column `h` here
  means word/chain length, not Cantor–Bendixson rank.
- `results/restricted_start_families.csv`: restricted-initial-color examples.
- `results/strategy_certificate.json`: an optimal three-question strategy on
  the twelve-point, six-chain ternary example.
- `Makefile`: PDF build, verification, smoke test, and cleanup targets.

## Rebuild the PDF

Run `make pdf`, or run this command twice:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

A normal TeX Live or MiKTeX installation with the packages in the preamble is
sufficient. No font files are included.

## Reproduce all finite checks

Python 3.10 or later; standard library only:

```sh
python3 code/verify.py --max-n 5 --brute-n 4
```

Do not run with Python's `-O` flag: assertions are verification conditions.
The recorded run checks 407 naturally labeled posets and all binary and ternary
colorings, for 102,331 colored-poset instances. It additionally checks 4,156
chain-language instances, 416,432 candidate-word equivalences, 36 restricted
universal-word parameter triples (15 with independent brute-force optimization),
and 1,176 prefix-padding instances. All checks passed. These counts are not
counts of non-isomorphic posets.

The full run took about 12 seconds in the recorded environment; actual runtime
varies. Defaults are the recorded full-run parameters. The six-point option is
much more expensive and was not run for this deliverable.

For a smoke test that does not replace the full-run data:

```sh
python3 code/verify.py --max-n 3 --brute-n 3 --output /tmp/open-query-smoke
```

The results on infinite compact spaces are established by the written proofs,
not by approximating them with finite Hausdorff subspaces.

## Strategy encoding

Masks use bit `i` for point `i` (zero-based). Predecessor masks contain strict
predecessors. Layer ranks are one-based. At an internal node, ask membership in
`open_mask` and follow `yes` or `no`. Leaves report `color` and `layer`.
The certificate word is `01201`, with the chains `01,02,10,12,20,21` in that
order. Every question is checked to be an upper set and every point is checked
to reach a correctly colored leaf.
