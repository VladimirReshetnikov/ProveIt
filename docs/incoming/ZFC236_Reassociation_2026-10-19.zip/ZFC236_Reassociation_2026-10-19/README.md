# A 236-state binary machine for ZFC consistency

This archive contains a complete candidate with **236 working states**, including blank-tape initialization, and a separate halt state. Its ordinary mathematical proof is formalizable in ZFC and gives

\[
\mathrm{ZFC}\vdash
\bigl(\text{the machine does not halt from the blank tape}
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

The proof uses the inherited, explicitly identified ProveIt source calibration. There is **no new Lean or Rocq endpoint for the 236-state table**, and this package does not supply an internal PA proof-code translation. The archive does contain the complete new source equivalence, all-tape local fold argument, exact startup, and direct unbounded symbolic runtime certificates.

## Read first

- [report.pdf](report.pdf): complete mathematical report, with every canonical transition in the appendix.
- [report.tex](report.tex): main LaTeX source; all imported sections are included.
- [Canonical machine](candidate236/zfc_reassociate236.tm): 236 working states, 472 rows, start 0, dispatcher 84, halt 236.
- [Inherited labels](candidate236/zfc_reassociate236_old.tm): same machine, start 95, dispatcher 96, halt 254.
- [Provenance and attribution](PROVENANCE.md): pinned baseline, inherited proof boundary, code adaptations, and credits.

The tape is binary and two-way infinite, initially all zero, with head at 0. Every transition moves left or right. Each non-comment table row is **state read write direction next_state**. There are no extra tape symbols, supplied program string, uncounted interpreter states, or omitted startup.

Canonical table SHA-256:

    d4302309401891d68b93c393e4ad6e24d2abf993dede4a61baa2d3e0c1c53c8e

Inherited-label table SHA-256:

    ff059535876bc9e1e1e63174ebfd1c10a91c1a818ba0c3f8c4ef2ac51a3cfcc3

## What saves the state

The baseline is [composed237](https://github.com/VladimirReshetnikov/ProveIt/blob/1b27f052d770f4c7d435e82e779bf21f5a1f66ed/Computability/BusyBeaver/Research/ZFC/candidate-composed237/README.md) at commit **1b27f052d770f4c7d435e82e779bf21f5a1f66ed**.

One closed reassociation at source prefix **1110100100110110101010011100001** changes P;(Q;R) to (P;Q);R. The chunks have 245, 160, and 132 leaves. Their ordered operations, operands, and all successors are preserved. The source DAG stays at **224 total nodes = 201 interior nodes + 23 leaf kinds**, while maximum depth increases from 48 to 49.

The rearrangement makes an existing decoder route useful for merging inherited states 182 and 223. The complete retained-row changes against composed237 are:

| Row | Old | New |
|---|---|---|
| 177/0 | 0 R 165 | 0 R 185 |
| 177/1 | 1 R 185 | 1 R 212 |
| 185/0 | 0 R 192 | 0 R 165 |
| 185/1 | 1 R 212 | 1 R 192 |
| 182/0 | 0 R 187 | 0 L 198 |
| 182/1 | 1 R 212 | 1 L 210 |
| 237/0 | 0 R 223 | 0 R 182 |

Delete both rows of 223. Exactly 465 retained rows remain unchanged.

In the reassociated intermediate, the only incoming rows are 76/1 → 1 R 182 and 237/0 → 0 R 223. Hence old state 182 always has left bit 1 and old state 223 always has left bit 0, by induction on **every binary initial tape**. With the map 223 → 182, four old steps expand as follows:

| Old state/read | Left bit | New path |
|---|---:|---|
| 182/0 | 1 | 182 → 198 → 136 → 187 |
| 182/1 | 1 | 182 → 210 → 177 → 212 |
| 223/0 | 0 | 182 → 198 → 206 → 23 |
| 223/1 | 0 | 182 → 210 → 114 → 70 |

Every path reads only offsets −1 and 0, preserves every tape bit, and ends one cell right at the exact mapped old target. All 470 other intermediate rows commute in one step. The positive clock is τ(t)=t+2A(t), where A counts old visits to 182 or 223; thus t≤τ(t)≤3t.

The source change itself saves no state. It changes 177/1 to enter212, completing the route that makes the extra sharing possible. This is a composition with the previous three savings; it is not a recount of them.

## Verification

| Check | Fresh result |
|---|---|
| Literal build and canonical numbering | 236 working states, 472 rows, exact pinned bytes, all working states graph-reachable |
| New source graph | 6,455 leaves; 8,385 nonhalting edges and one halt; all operation labels and operands preserved |
| Inherited Source103 source graph | 13 stages / 25 rotations replayed; identical boundary-source bytes |
| Local fold | Complete predecessor lists, 470 ordinary rows, four exact blocks, all 32 compatible five-cell windows |
| Final universal runtime | **8,386 cases, 2,267,815 symbolic rules, all 472 rows, minimum actual duration 13** |
| Intermediate237 universal runtime | 8,386 cases, 2,262,455 symbolic rules |
| Fresh baseline237 universal runtime | 8,386 cases, 2,261,369 symbolic rules |
| Blank startup | **409,835 transitions**, independently sparse and dense, full tape equality |
| Independent reviews | Source successors reconstructed by a different interval method; runtime input/induction audit; E639 relative model review |

The runtime is quantified over all natural register values, arbitrary extra gap and first spare, and an arbitrary finite spare tail. Unary runs and lists are crossed by induction. Its 4,000-rule fuel bounds proof construction, not machine time or input magnitude.

The exact startup frame is head −5, marker −6, header 176, 351 one-cells, logical registers (3,0,0,0,3,0,0,0,0), and 167 spare blocks of value 1. Every other tape cell is zero.

The theorem relies on the inherited endpoint **CalibratedRotation240.halts_iff_zfc_refutation**, whose actual statement uses the repository's BProv/ZFCax_s/fBot proof calculus. The new source transformations preserve its calibrated seed. The saved Lean files are provenance snapshots; the ancestor proof hierarchy was not rebuilt in this session.

## Reproduce

Python 3.10+ standard library only. Run without optimization flags.

~~~sh
python3 -B reproduce.py
python3 -B reproduce.py --full --output /tmp/zfc236-replay
~~~

The quick command verifies the manifest and cross-file identities, replays both source certificates, rebuilds the literal table, checks the fold and exact canonical startup, and independently rebuilds all five equational checkpoints. The full command additionally repeats the 8,386 unbounded runtime cases. It compares every resulting symbolic duration and semantic receipt field with the delivered result. On the delivery environment the full runtime took about 3–4 minutes.

Checks run on copies. With --output, choose a new directory; it retains copies, logs, and fresh receipts. Otherwise temporary copies are removed after a successful run. MANIFEST.sha256 covers every delivered file except the manifest itself.

To rebuild the PDF:

~~~sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
~~~

The original search is optional:

~~~sh
cd candidate236
python3 -B discovery/rerun_fold_search.py ingredients/reassociated237_old.tm \
  --mode all --radius 9 --fuel 101 --output /tmp/zfc236-discovery
~~~

Acceptance does not require that search; the much shorter independent local proof suffices.

## Supplement: a 639-bit equational frontend

The **equational/** folder gives a second concrete research result: a complete **639-bit** packet with **seven equations, nine operations, four local variable slots, 144 equation-term nodes**, and the ground query **Q(d)=d**. The signature and query are counted. The transport is 80 bytes with one zero padding bit.

It starts from the exact E692 packet in the pinned incoming archive. The three changes are:

1. Derive the explicit truth equation from the retained closure and Boolean basis: save 25 bits. This preserves the whole equational theory.
2. Let the descriptor carry its own class code, with a protected parameter tail: save 24 bits. This has a relative model proof, not identical models.
3. Replace the four-node Boolean-collapse query by Q(d)=d: save 4 bits. The two queries have the same derivability.

The 639-bit packet's logical bit-string SHA-256, excluding its text file's newline, is:

    15c8bde20963ac71ff9015556c52e88ac3158e9d0b585f056cd11f018ed006a8

All equations are expanded in [E639.equations](equational/generated/E639.equations), and exact JSON, bits, binary transport, bitlength, builders, and proof sections are supplied. The ordinary relative proof retains the inherited E692/raw-EPSC/ZFC calibration and the published Sh1 Boolean basis as explicit premises. It has no complete binary TM state count and is not needed for the 236-state result.

The report also compares the calibrated structured source, raw EPSC, finite equations, GBC, and the pinned 299-state equational-generator cost control. No smaller binary machine is inferred by subtracting packet bits from states.

## Integration and scope

The candidate can be incorporated under **Computability/BusyBeaver/Research/ZFC/candidate-reassociate236/**, with proof/support files placed through the repository's normal intake process. Keep the full archive as a reproducibility record.

The contribution establishes a strict improvement over the pinned237-state candidate. It does not assert absolute consistency, unconditional nonhalting, global minimality, or two-sided independence from bare consistency. The optional negative-search record distinguishes completed from interrupted searches.

Original Mira-Cult, Jeff Ketchersid, Andrew James Wade, ProveIt, and earlier incoming-report credits are preserved in [PROVENANCE.md](PROVENANCE.md) and [licenses/](licenses/).

