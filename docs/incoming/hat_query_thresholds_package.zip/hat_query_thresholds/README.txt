TWO QUERIES IN EXPECTATION
Sharp Information Thresholds for Infinite Hat Guessing
Research article and reproducibility package — October 4, 2026

START HERE

Read hat_query_thresholds.pdf. Its self-contained source is
hat_query_thresholds.tex. The article includes full proofs, a bibliography,
a contribution ledger, and twelve proposed research directions.

The main result is an exact deterministic threshold:

  inf over successful strategies of sup_i E[Q_i] = 2,

where hats are independent fair bits, every player must guess, Q_i counts
observations of other players' hats, and success means that the number of
correct guesses among the first n players minus n/2 tends to +infinity.
The equality holds whether success is required with positive probability
or almost surely. A construction attains 2, although E[Q_i] < 2 for every
individual player.

Other results include null and meager divergence under a common finite
adaptive query bound; a finite-chromatic visibility obstruction; the exact
qualitative classification of eventually positive query-count budgets;
a distinction between query count and query distance; finite Fourier/orbit
bounds; the one-query success optimum 3/4; exact growth equivalents; and
private-randomness sufficiency under every expected cap greater than 1.

FILES

  hat_query_thresholds.pdf        Finished article.
  hat_query_thresholds.tex        Complete editable LaTeX source.
  verify_hat_queries.py           Exact block and query-algorithm verifier.
  hat_query_verification.json     Recorded output of that verifier.
  verify_orbit_bounds.py          One-query enumeration and orbit verifier.
  orbit_verification.json         Recorded output of that verifier.
  SOURCE_NOTES.txt                Source snapshot, attribution, and scope.
  README.txt                     This guide.
  SHA256SUMS.txt                  Checksums of the other package files.

COMPILE THE ARTICLE

A normal TeX Live or MiKTeX installation with pdfLaTeX is sufficient.
The source uses standard packages, including lmodern, amsmath, amsthm,
mathtools, geometry, microtype, booktabs, longtable, enumitem, xcolor,
xurl, fancyhdr, listings, and hyperref.

Run from this directory:

  latexmk -pdf -interaction=nonstopmode -halt-on-error hat_query_thresholds.tex

Alternatively, run the following command twice:

  pdflatex -interaction=nonstopmode -halt-on-error hat_query_thresholds.tex

No BibTeX run, downloaded images, network access, or external bibliography
database is needed. Bibliographic entries are included in the TeX source.

REPRODUCE THE FINITE CHECKS

Python 3.10 or later is required. No third-party Python packages are used.

  python3 verify_hat_queries.py
  python3 verify_orbit_bounds.py

The programs write their JSON reports next to their source files.
Use --output PATH to choose another destination. The block verifier also
offers --help for its finite-range parameters.

Both programs were also executed successfully with Python's -O option:

  python3 -O verify_hat_queries.py
  python3 -O verify_orbit_bounds.py

All verification conditions are explicit runtime checks and remain active
under -O. The orbit report records elapsed execution time; that field will
normally differ between runs.

The block checker exhausts m = 1,...,8:

  87,380 physical hat assignments;
  1,339,848 primary player executions;
  1,339,848 reexecutions with the owner's hat flipped;
  2,009,628 queries in the primary executions.

It checks legal queries, blindness to the owner's hat, the declarative
rule, individual fairness, the block law, prefix bounds, query histograms,
geometric tails, and exact stage accounting through stage 80.
The checker calls the second partner role D; the article calls it T.

The orbit checker exhausts all one-query profiles for n = 1,...,5:

  104,330 strategy profiles;
  3,267,332 profile/assignment pairs.

The minimum probabilities of a nonpositive score are respectively
1/2, 1/2, 1/4, 1/2, and 1/4. Three additional nonlinear examples verify
Walsh reconstruction, support-density certificates, nonzero binary
support labels, and actual group-orbit cancellation. These examples
include 5,120 assignment/group pairs.

INTERPRETATION AND STATUS

The finite computations supplement the proofs. They do not replace the
all-parameter arguments or prove infinite almost-sure statements.
This package contains no completed proof-assistant formalization.

The existing block mechanism is explicitly credited to Nathaniel
Eldredge. Hypercontractivity and the textbook sign bound are classical.
The sharp threshold and other stated deductions are proved in this
article as responses to questions in the inspected ProveIt report.
Historical priority has not been established, and the article is
unrefereed. Elliot Glazer has not reviewed or endorsed this work.

IMPORTANT HYPOTHESES

The threshold 2 is for deterministic algorithms without free random
seeds. The count-budget classification assumes only finitely many
zero-budget players. Unbounded query count and unbounded query distance
are different conditions. The paper states each hypothesis at its use.

For exact provenance and source URLs, see SOURCE_NOTES.txt and the
article's bibliography.
