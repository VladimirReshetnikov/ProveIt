NO UNIVERSAL SUBLINEAR BOUND FOR MEASURABLE HAT GUESSING
Research report prepared for Vladimir Reshetnikov, October 3, 2026

MAIN RESULT

For every prescribed positive g(n)=o(n), there is a legal compulsory
binary hat-guessing strategy, each player's guess depending on finitely
many other hats, such that

    (S_n - n/2) / g(n) -> +infinity almost surely,
    S_n / n -> 1/2 almost surely.

A simpler computable schedule gives S_n - n/2 = log_2(n) + O_omega(1).
The article also proves an exact finite-team optimum, bounded random
tracking error, quantitative stabilization bounds, and a measure/category
separation.

ATTRIBUTION AND STATUS

The questions addressed appear in Nathaniel Eldredge,
"A probabilistic look at the infinite hat-guessing game,"
arXiv:2508.02828v2 (2025), Remark 6.8. The excess-growth topic is credited
there to Elliot Glazer and Charles Wang.

The coding mechanism and XOR amplification have substantial prior art
in Todd Ebert, Wolfgang Merkle, and Heribert Vollmer, "On the
Autoreducibility of Random Sequences," SIAM Journal on Computing 32(6)
(2003), 1542-1569, especially Theorem 6.6. This package provides a direct
compulsory-guess construction and proofs of the stated consequences.
It does not claim historical priority for the mechanism or the general
slow-density phenomenon. Priority of this exact formulation is unverified.

The finite verification is exhaustive only for the listed cases. The
infinite theorems have complete written proofs but are not machine-checked
in Lean, Rocq, or another proof assistant.

FILES

hat_guessing_growth.tex      Complete LaTeX article with inline bibliography
hat_guessing_growth.pdf      Compiled article
code/verify_hat_strategy.py  Standard-library finite verifier
code/make_figures.py         Exact explanatory figure generation
code/README.txt              Verifier conventions and scope
code/LICENSE.txt             License for original code
data/verification.json      Executed exact finite results
data/examples.json          Explicit good and bad assignments
data/example_prefix.csv     Complete example prefix path
figures/block_prefix.pdf    Vector figure included in the article
figures/block_prefix.png    Image version of the figure
source_audit.txt             Sources, scope, and review notes
Makefile                    Build commands

BUILD

Use a TeX installation with pdfLaTeX and the packages named in the source.
The article uses Latin Modern and standard AMS/graphics/table packages.

    pdflatex -interaction=nonstopmode -halt-on-error hat_guessing_growth.tex
    pdflatex -interaction=nonstopmode -halt-on-error hat_guessing_growth.tex
    pdflatex -interaction=nonstopmode -halt-on-error hat_guessing_growth.tex

The source remains mathematically complete when copied without its figure;
it conditionally includes the figure when that file is present.

FINITE VERIFICATION

Python 3.10 or newer is sufficient; no third-party package is needed.

    python3 code/verify_hat_strategy.py

This rewrites the finite verification JSON and example files.
The packaged run passed 9 cases covering 284,052 exhaustive hat assignments,
5,010,248 individual prediction crosschecks, 10,020,496 own-hat toggle checks,
and 3,997,918 good-prefix checks.

FIGURE REGENERATION

Python with Matplotlib and NumPy:

    python3 code/make_figures.py

No Monte Carlo simulation is used in the article's figure.

SOURCE SNAPSHOT

ProveIt commit: 7c0f2d9f92c3d51ec85703bed1022924a4b7359b
Relevant report:
SetTheory/Cardinals/docs/reports/ordinals-and-order-types/measurable-box-games

No repository files were modified. No authorship or endorsement by any
referenced mathematician is implied.
