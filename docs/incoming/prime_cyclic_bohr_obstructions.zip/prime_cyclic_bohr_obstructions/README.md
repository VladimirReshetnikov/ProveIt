# Prime-Cyclic Bohr Boundary Obstructions

**Exponential rank dependence from near-parallel frequencies**  
Research manuscript, 7 October 2026. Prepared for the ProveIt research collection.

## Main result

For each defining rank r >= 2 and epsilon > 0, there are fixed distinct integer frequencies and a fixed rational radius such that every sufficiently large prime cyclic group contains the associated Bohr set B_p with exactly 2^r - 1 cyclic runs. For the step d = 1, writing eta for the maximum character displacement divided by the radius,

    |B_p \ (B_p + 1)| / (eta |B_p|) > (1 - epsilon)(2^r - 1)/2.

Here eta tends to zero as p tends to infinity. All defining constraints are individually essential. The frequency representatives can be arbitrarily close in relative size. The radius is fixed with respect to p, not uniformly with respect to r and epsilon.

The article also proves an exact component classification, a closed Haar-measure formula, finite-prime error bounds, persistence on a nonzero interval of radii, the exact rank-one asymptotic constant, and a quantitative total-variation approximation/translation tradeoff.

## Relation to the repositories

The construction is motivated by ProveIt's fixed-radius Bohr interface in the Gowers program and the sharp-versus-smoothed/padded cell distinction in OpenAI's progression manuscript. In the targeted comparison with the earlier ProveIt product/CRT spike family, it improves the lower exponential rank base from sqrt(3) to 2 and establishes the obstruction at prime order.

The universal upper comparison retained from the earlier package has base 3. Closing that gap remains a research question. This package does not prove a new all-length Szemeredi bound, refute OpenAI's progression manuscript, or complete a Lean formalization.

## Files

- `article.pdf` and `article.tex`: complete manuscript, references and further research questions.
- `code/verify.py`: standard-library exact-arithmetic verification program.
- `verification.json`, `arc_certificates.json`, `verification-run.txt`: actual executed results and rational certificates.
- `SOURCE_AUDIT.md`: pinned repositories, inspected source ranges and scope of the comparison.
- `VERIFICATION.md`: what was checked and what was not.
- `FORMALIZATION_PLAN.md`: suggested finite-lemma formalization sequence; no unchecked Lean proof is included.
- `INTEGRATION.md`: suggested ProveIt placement and index wording.
- `Makefile`: PDF build and verification commands.
- `MANIFEST.sha256`: checksums of the delivered files other than the manifest itself.

## Reproduce

From this directory, with Python 3.10 or later:

```sh
python3 code/verify.py --output verification.json --certificates arc_certificates.json
```

The Python verifier uses only the standard library. It is also safe to run under `python3 -O`: its checks are explicit and are not disabled by optimization. Its decimals are for display only; pass/fail decisions use integers and exact rational arithmetic.

With a TeX Live installation containing the AMS, newtx, geometry, microtype, hyperref, fancyhdr and booktabs packages:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Alternatively run `pdflatex -interaction=nonstopmode -halt-on-error article.tex` three times. `make all` builds the PDF and regenerates the verification results.

## Research status

The main results have complete conventional proofs in the manuscript and exact supplementary checks. They are not proof-assistant verified and have not received independent referee review. The literature/repository comparison was targeted, not exhaustive; priority is not certified. Repository audit counts cited in the paper are attributed to the pinned repository and were not reproduced here. No third-party source manuscripts or font files are redistributed.
