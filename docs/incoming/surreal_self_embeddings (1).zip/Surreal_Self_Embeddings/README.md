# Self-Embeddings of the Surreal Numbers

**Order, simplicity, algebra, analysis, and paradox-free foundations**  
Prepared for Vladimir Reshetnikov, 3 October 2026.

## Contents

- `surreal_self_embeddings.pdf`: the 36-page article, including proofs, a source audit, 15 research questions, and an internal bibliography.
- `surreal_self_embeddings.tex`: standalone LaTeX source; no external bibliography or image files are needed.
- `validate.py`: deterministic exact finite regression checks using only Python's standard library.
- `validation_results.json`: results of the delivered run (198,220 assertions, all passing).
- `build.sh`: rebuilds the finite checks and PDF from this directory.
- `PROOF_STATUS.md`: scope of proofs, source inspection, and limitations of verification.
- `build_validation.json`: document and package validation metadata.

## Main mathematical themes

The article distinguishes order embeddings, simplicity embeddings, canonical-cut morphisms, additive and field embeddings, strongly additive maps, elementary embeddings, and embeddings preserving additional named structure.

The normal-form lift L_f of an order embedding f transports exponents in Conway normal forms. It is a strongly real-linear ordered additive embedding; it is a field embedding precisely when f is additive. Iterating this construction produces the field embedding E_f = L_(L_f). The article proves composition, image, cofinality, and fixed-field formulas for this construction.

For f(x) = x/(1+|x|), the resulting E_f is a proper field self-embedding with a bounded image, fixes the real numbers and omega, and has exactly the Hahn field of real-exponent series as its fixed field. Other explicit examples are proper cofinal field embeddings fixing every ordinal. These examples distinguish preservation of Hahn sums from continuity for the ambient numerical order topology.

The rigidity sections treat birthday nonincrease, canonical cuts, initial ranges, exact natural valuations combined with exponentiation or the omega-map, and internally definable endomorphisms. Later sections address omnific integers, a specified surreal derivation, set-sized birthday fragments, conditional large-cardinal transport, and a dependency-ordered Lean formalization plan.

## Rebuild

Requirements: Python 3.10 or later; `latexmk`; a LaTeX installation containing the packages used by the source, including `newpxtext`, `newpxmath`, `amsmath`, `amsthm`, `geometry`, `microtype`, `hyperref`, `bookmark`, `xurl`, `enumitem`, `booktabs`, `longtable`, `array`, `fancyhdr`, and `xcolor`.

From this directory:

```sh
./build.sh
```

Or separately:

```sh
python3 validate.py
latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_self_embeddings.tex
```

The article contains its bibliography internally, so BibTeX and network access are unnecessary. A rebuild may differ byte-for-byte because PDF metadata can include build timestamps.

## Proof and provenance boundary

Repository statements are pinned to ProveIt commit
`af04de3fa423f8f3253ee28db9afeb7fc6171604`.
Appendix A records the actual inspected files and ranges. The entire repository was not audited and its Lean build was not rerun. No new Lean-checked result is claimed by this package.

The transfinite and proper-class claims are supported by written mathematical proofs, not by the finite Python checks. Conditional large-cardinal constructions retain their stated hypotheses. The article separates established literature, repository material, proofs developed in this treatment, and further questions; no claim of independently certified novelty or priority is made.
