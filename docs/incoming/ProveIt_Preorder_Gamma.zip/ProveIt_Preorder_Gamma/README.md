# The Gamma-Vector of Every Finite Preorder

**Disjoint matching supports, Boolean expansions, and sharp degree laws**  
Research manuscript prepared with ChatGPT for Vladimir Reshetnikov.  
29 September 2026.

## Main result

For a finite preorder tau on n labeled elements, let h_tau(t) count the
nonnegative integer points satisfying x(I) <= |I| for every lower ideal I,
weighted by the number of nonzero coordinates. The manuscript proves

    h_tau(t) = sum_k g_k(tau) t^k (1+t)^(n-2k),

where g_k counts ordered disjoint k-subsets U,V for which a bijection
f: U -> V satisfies u <=_tau f(u). A support pair is counted ONCE even if
several witnessing bijections exist. This is a proof of the full statement
of Athanasiadis--Chapoton Conjecture 5.2 in arXiv:2605.26916v1.

The result applies to arbitrary height and arbitrary equivalence-class sizes.
The proof generalizes the full-zero-set reduction underlying the repository's
height-two work. Its only shared non-elementary counting input is explicitly
derived from the published root-polytope results of Kalman--Postnikov and
Ohsugi--Tsuchiya (the latter stated in the required form by Davis--Kohl).
No unrefereed geometric theorem from ProveIt is assumed.

## Additional theorems

The manuscript proves a multivariate support refinement, transitive overlap
cancellation and a Boolean action on an auxiliary pair model, complement-duality,
coefficientwise gamma-monotonicity under relation extension, sharp extremal
bounds, and a weighted formula on the equivalence-class quotient.

The gamma degree is the maximum matching size of the UNDIRECTED comparability
graph; the root -1 of h has multiplicity equal to the matching deficiency.
It also proves the deletion identity

    (1-t) sum_v h_(tau-v)(t) = n h_tau(t) - 2t h_tau'(t),

and consequently reconstructs h from the one-element polynomial deletion deck
when n is odd. Ten further research questions are included.

## Contents

- `article.pdf`: the compiled 22-page manuscript.
- `article.tex`: complete LaTeX source, with embedded bibliography.
- `code/verify.py`: independent, exact finite checks; standard library only.
- `results/verification.json`: machine-readable output of the completed run.
- `results/verification.txt`: console output of that run.
- `build.sh`: two-pass PDF build command.
- `SHA256SUMS`: hashes of the supplied files other than the hash manifest itself.

## Reproduce the computations

Requires Python 3.10 or later. From this directory run:

```sh
python3 code/verify.py --max-n 5 --output results/verification.json
```

The exhaustive suite checks every labeled preorder on 0 through 5 elements:
1, 1, 4, 29, 355, and 6,942 cases respectively (7,332 total).
It also checks all bipartite graphs on fixed shores of sizes (3,3), (3,4),
and (2,3), empty-shore cases, 119 distinct seeded preorder closures on 6 or 7
elements, 87 block-profile cases, and five named examples. The JSON records
the exact properties checked and the distinction between exhaustive and
sampled cases. Any failed equality raises an exception before a success
record is written.

Lattice enumeration uses only the original ideal inequalities. Matching
feasibility uses recursive assignments, not those inequalities. The deletion
identity is tested against direct lattice enumeration of the deleted preorders.
Every computation uses exact integers. No internet access or third-party
Python packages are required.

## Compile the article

A TeX Live installation with the packages named in the preamble is required,
including newpx, amsmath/amsthm, microtype, tcolorbox, TikZ, and hyperref.

```sh
sh build.sh
```

Alternatively, run `pdflatex -interaction=nonstopmode -halt-on-error article.tex`
twice. The bibliography is embedded; BibTeX is not required.
No font files are distributed in this package.

## Provenance and boundaries

The inspected ProveIt snapshot is commit
`077672c84f743ff5de82ce6becc3ad6b2ff8787a`, particularly
`SetTheory/Cardinals/docs/reports/enumerative-combinatorics/preorder-root-polytopes/`.
The source/version ledger and full references are in the article.

The article supplies ordinary mathematical proofs, not a proof-assistant
certificate. It has not been independently refereed or formally verified.
The finite tests support the audit but are not proofs of universal statements.
The literature comparison is bounded and does not certify worldwide priority.
Previously proved special cases and univariate duality are credited.
Flag simplicial-polytope realization is not established. A natural bijection
transporting the Boolean action to actual lattice points is not constructed.
