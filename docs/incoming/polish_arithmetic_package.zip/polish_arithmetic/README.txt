POLISH ARITHMETIC:
MULTIPLICATION OBSTRUCTIONS AND LOCAL COMPACTNESS

Research manuscript prepared for Vladimir Reshetnikov with AI assistance.
Source snapshot: 4 October 2026 UTC.

CONTENTS

  polish_arithmetic.pdf    The complete, typeset article (32 pages).
  polish_arithmetic.tex    Self-contained LaTeX source with inline bibliography.
  build.sh                A small build script for a standard TeX installation.
  source_manifest.json    Pinned repository files, hashes, URLs, and source status.
  proof_audit.txt          Claims, dependencies, verification, and novelty limits.
  README.txt              This file.

RESEARCH TOPIC

The article connects Elliot Glazer's work on topological models of arithmetic
with the Presburger and omnific-integer materials in Vladimir Reshetnikov's
ProveIt repository. The basic affirmative construction for Glazer's Question 2
was already present in the inspected project manuscript. This article develops
structural follow-up results rather than presenting that construction as new.

PRINCIPAL RESULTS

1. Locally compact inherited positive cones in Borel ordered Polish abelian
   groups are classified. In the uncountable discretely ordered case their
   common carrier is a countable disjoint union of real lines and closed rays.
2. The intrinsic manifold boundary of an inherited locally compact Presburger
   cone is a countable elementary initial submodel. Every countable Presburger
   model can occur as that boundary.
3. The one carrier supports exactly continuum many nonisomorphic full
   Presburger models, even with the boundary fixed to the standard naturals.
4. An algebraic subgroup-versus-quotient cardinality theorem forbids every
   unital semiring multiplication on these inherited locally compact cones,
   without any measurability assumption.
5. A positive-endomorphism adaptation of Glazer's zero-one-law mechanism rules
   out separately Borel multiplier maps on nondiscrete Polish additive groups
   with Borel discrete order.

The article also gives finite normal-form realizations in the omnific integers,
a locally compact Polish polynomial semiring showing the precise limit of the
group-topology hypothesis, a formalization roadmap, and eleven research
questions. Full Presburger induction in the additive language is carefully
distinguished from open induction in a language containing multiplication.

BUILD

Extract the archive, then run:

  sh build.sh

The script uses latexmk when available and otherwise invokes pdflatex three
times. You can also run:

  latexmk -pdf polish_arithmetic.tex

A standard TeX Live or MiKTeX installation with the following ordinary packages
is sufficient: amsmath, amssymb, amsthm, mathtools, lmodern, mathpazo, geometry,
microtype, enumitem, booktabs, longtable, array, xcolor, fancyhdr, xurl, hyperref,
cleveref, listings, and needspace. No external images, bibliography database,
network access, or custom fonts are required to rebuild the article.

SOURCE AND PROOF STATUS

The source comparison is pinned to ProveIt commit:

  0f084afa9be466593ffa6aff37749e78c0adc733

The repository was inspected without modifications. The document includes
ordinary mathematical proofs, checked in separate AI-assisted review passes.
It does not claim a new Lean/Rocq kernel certificate, external human refereeing,
or independently established historical publication priority. The classical
ingredients and the earlier project construction are explicitly credited.
Glazer's original Question 1 about ATR_0 is not resolved by this article.

VALIDATION

The final source compiled with no LaTeX warnings, unresolved references,
unresolved citations, or overfull boxes. The rendered PDF was visually reviewed
across all sections; changed pages were reviewed again after layout corrections.
The archive was checked for CRC integrity and for exact inclusion of its TeX
and PDF bytes. SHA-256 hashes of the two main deliverables are recorded in the
source manifest.
