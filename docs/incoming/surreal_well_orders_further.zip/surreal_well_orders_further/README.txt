LEXICOGRAPHIC ORDERS OF SURREAL WELL-ORDERS
Cuts, Canonical Blocks, and the Limits of Set-Sized Coding
3 October 2026

CONTENTS

surreal_well_orders_further.pdf
    The complete 33-page article (title page, two-page contents, and
    30 numbered pages of mathematics, formalization discussion, research
    questions, proof-status notes, and references).

surreal_well_orders_further.tex
    Standalone LaTeX source. The bibliography is included in this file;
    no external .bib file, images, or repository checkout is required.

finite_checks.py
    Standard-library Python diagnostics for the finite coding examples
    and for relation-based first-disagreement comparison.

finite_check_results.json
    Machine-readable results of the included finite diagnostics.

SOURCE_STATUS.txt
    Repository snapshot, inspected source locations, and the limits of
    the mathematical and computational verification.

BUILD

With a standard TeX Live or MiKTeX installation containing the packages
listed in the source preamble:

    latexmk -pdf -interaction=nonstopmode surreal_well_orders_further.tex

Alternatively run pdflatex on the source three times to resolve contents,
cross-references, and citations. The included PDF was built using pdfTeX
from TeX Live 2023 and latexmk 4.83. No network access is required.

Run the finite diagnostics using Python 3:

    python3 finite_checks.py

READING GUIDE

Sections 1-3 map the interpretations and fix foundational conventions.
Sections 4-6 treat well-orders on a set alphabet, enumeration length,
topology, incompleteness, and regular-stage gap characters.
Sections 7-8 treat set-length words, increasing words, and the complete
termination-symbol classification for unrestricted and injective words.
Sections 9-10 compare arbitrary class well-orders directly and prove the
simultaneous canonical block decomposition.
Sections 11-12 construct the bounded-support core and characterize its
cuts represented by global injective or exhaustive branches.
Sections 13-14 separate coding levels, prove a sufficient comprehension
bound for uniform nonembedding, and explain full and Henkin models.
Section 15 proposes a formalization path using actual ProveIt primitives.
Section 16 proposes eleven further research questions with concrete targets.
Section 17 records proof status, assumptions, and reproducibility.

New results are extensions relative to the inspected ProveIt report.
The article does not assert worldwide historical priority. These are
ordinary mathematical proofs, not new Lean theorems or peer-reviewed
results. The finite checks are diagnostics, not proofs of the transfinite
or class-theoretic statements.
