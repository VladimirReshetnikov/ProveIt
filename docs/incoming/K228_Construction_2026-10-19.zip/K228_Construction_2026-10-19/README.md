# K228: transferring ProveIt's reductions to Glazer's K230

This archive supplies an explicit **228-working-state, two-symbol, blank-start
Turing machine**, including its initializer. It is two states below the released
K230 and seven below the ProveIt 235-state candidate at commit `0128d662fd`.

An ordinary mathematical proof, formalizable in ZFC, establishes

\[
\mathrm{ZFC}\vdash
\bigl(\text{K228 does not halt from blank tape}
\leftrightarrow \mathrm{Con}(\mathrm{ZFC})\bigr).
\]

The proof uses the pinned K230 calibration, exact source transformation,
the final machine's unbounded symbolic runtime theorem, exact blank startup,
and explicit state renaming. **There is no newly compiled Rocq or Lean endpoint
for K228 in this archive.** The new evidence is an ordinary proof with executable
induction certificates. The upstream K230 repository supplies the existing
Rocq endpoint.

## Machine identity

Use `machine/k228.tm`.

| Quantity | Value |
|---|---|
| Working states | 0 through 227 |
| Initial state and head | State 0, head 0 |
| Initial tape | Every integer cell contains 0 |
| Alphabet | 0, 1 |
| Moves | L, R |
| Dispatcher | 83 |
| Unique external halt label | 228 |
| Transition rows | 456 |
| SHA-256 | `06726bd731f3a42e3ccd1c4189d80af74ba2d486e333045097480fcaa3313001` |

The complete table is also printed in `report.pdf`. Every non-comment machine
line is `state read write direction next_state`.

## What was transferred

The first two ProveIt local folds are already represented in K230's layout.
Two further reductions work:

1. The transfer-plus-one source identity changes exactly four K230 subprograms.
   With its shared decoder adjusted, K state **79 merges into 63**, giving H229.
2. The delayed-erasure fold merges K state **140 into 71**, giving **K228**.

Those are released K230 labels, retained in `machine/k228_oldlabels.tm`.
Eight surviving rows change and four rows are deleted. The final dense
renumbering is supplied explicitly.

The remaining templates do not transfer unchanged. The boundary route
exposes a one-node source saving but creates seven consecutive address zeros,
and a required zero-tag role has an additional incoming one-tag port.
Several later fold/rotation source subtrees no longer occur. The report and
`notes/` identify those preconditions; they do not claim a lower bound or
rule out different adaptations.

## Reproduce offline

Requirements: Python 3.10 or newer, standard library only, assertions enabled.
The pinned machine and source inputs are included.

From the extracted package directory:

~~~sh
python3 -B reproduce.py
~~~

Full symbolic checking is the default. Success finishes with
`K228_FULL_REPLAY_PASS`. It regenerates the H source and machine stage, verifies
local fold and startup identities, reconstructs and renumbers K228, executes
canonical startup, proves all **6,656** guarded runtime cases, and runs the
independent source/table/interface audit.

Outputs go to `reproduced/`, leaving the delivered evidence under `receipts/`
intact. Use `--output` to select another destination.

For a fast source/table construction and startup check:

~~~sh
python3 -B reproduce.py --quick
~~~

Quick mode does **not** rerun the universal instruction theorem. Its independent
audit may inspect the included complete runtime certificate; that is not a
fresh full runtime replay. The included full portable runtime replay took
about two minutes in the preparation environment.

Do not use `-O`, `-OO`, or an environment configuration that disables assertions.
The main entry points reject those modes.

## Verification results

| Check | Result |
|---|---|
| Exact input pins and table reconstruction | Pass |
| Canonical/normalized table conjugacies | Pass for every transition |
| H source replacement inventory | Exactly four disjoint occurrences |
| Contracted source context | 5,113 leaves, 6,644 guarded cases; identical |
| Independent outside-edge audit | 6,639 nonhalting guarded edges preserved |
| Old/new implicit-zero successors | All 13,314 nonhalting edges checked |
| Canonical blank initialization | 409,835 transitions |
| Common frame | Logical seed `(3,0,0,0,3,0,0,0,0)` and 167 spares |
| Direct runtime | All 6,656 guarded cases |
| Symbolic rules | 1,614,426 |
| Maximum rules in one case | 415 |
| Minimum constant in actual-duration expressions | 13 |
| Transition coverage | All 456 rows |

The instruction theorem quantifies over arbitrary natural register values,
nonnegative extra gap, arbitrary first spare value, and arbitrary finite spare
tail. Unary and list scans use induction. The 4,000-rule per-case cap bounds
symbolic proof construction, not execution time or machine data.

The local delayed-erasure identity has an extra old-state/right-neighbor
premise. Startup checks its encountered instances. **The main proof does not
assume a global version of that premise:** it verifies K228's runtime directly.

## Contents

- `report.tex`, `report.pdf`: report and full canonical table.
- `machine/`: canonical, released-label and verifier-label tables and bijections.
- `source/sites_logical.json`: transformed 5,121-leaf source.
- `verification/`: portable builders/checkers and symbolic kernels.
- `receipts/replay/`: full portable replay and every case record.
- `receipts/audit/`: independent source, table, initialization and coverage audit.
- `receipts/discovery/`: earlier construction and runtime evidence.
- `upstream/k230/`: exact inputs and selected calibration sources.
- `upstream/proveit/`: pinned 235-state archive and selected template inputs.
- `notes/`: mathematical audits and precise portability observations.
- `exploratory/E639/`: separate 639-bit equational packet and representation
  argument; **no Turing-machine state-count claim**.
- `PROVENANCE.json`, `ATTRIBUTION.md`, `licenses/`, `SHA256SUMS`: identities and notices.

The selected Rocq sources document the calibration interface; this is not a
vendored copy of every Rocq dependency. Rebuilding the original K230 endpoint
uses the pinned upstream repository's own instructions and manifest. No Rocq
installation is required for this archive's offline Python replay.

## Build the PDF

The PDF is included. To rebuild with a conventional TeX installation:

~~~sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
~~~

Regenerate the table appendix from the canonical machine:

~~~sh
python3 -B verification/generate_table_tex.py \
  --machine machine/k228.tm --output generated/machine_table.tex
~~~

## Research scope

The biconditional does not assume consistency while being proved. Actual
nonhalting follows if ZFC is consistent. No global minimality, unconditional
nonhalting, or two-sided independence from bare consistency is claimed.

The practical next target is a K-specific boundary repair preserving the
six-zero address limit and required incoming tags while retaining the exposed
source sharing. This archive provides a frozen 228-state reference for that work.
