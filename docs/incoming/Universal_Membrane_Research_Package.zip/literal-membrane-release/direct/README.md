# Direct three-register active membranes

A separate, smaller variant of the literal universal frontend:

- 528 register instructions, 2,544 rules, 1,296 symbols, five labels
- Raw half tapes L,R>=0 load affinely into populations L+1,R+1,1 plus delay and skin
- Global halting exists exactly when the audited U15,2 source table halts
- At fixed register-instruction horizon h, a degree-two outcome polynomial uses 2,811h coordinates, 5h+1 squares and 761h nonnegative products
- The fixed-input, fixed-horizon zero fiber is empty or a singleton over both naturals and nonnegative reals

Start with `PROOF.md`. The fully replayed L=6,R=0 example has 328 register instructions, 1,013 membrane steps, maximum 30 membranes/three objects, and final registers (0,11,0). Its full quadratic certificate has 922,008 coordinate slots, 922 nonzero coordinates, 1,641 squares and 249,608 products, all evaluated exactly.

## Reproduce

    python build_direct.py
    python verify_direct.py
    python build_quadratic.py --steps 1
    python make_accepting_witness.py
    python verify_accepting_quadratic.py
    python verify_membrane.py
    python load_input.py 6 0

`verify_direct.py` independently checks every source/register row and all 2,544 exported membrane rules. `virtual3.txt` is the complete literal register table. `membrane_rules.jsonl` and `object_alphabet.txt` fully specify the fixed membrane rules. `quadratic_schema_T1.json` is a literal degree-two arithmetic export. `quadratic_core.py` is a library; use the direct wrapper `build_quadratic.py`, which explicitly fixes the scratch input to zero.

`accepting_counter_trace.json`, `accepting_membrane_trace.json` and `accepting_quadratic_witness.json` are the full accepting fixtures. Missing sparse witness coordinates mean zero, not omitted existential variables. The bulky h=328 polynomial is optionally generated with `python build_quadratic.py --steps 328`; the saved witness is checked without storing that entire unrolled file.

No fixed-arity unbounded-time Diophantine equation, arbitrary membrane-history verification by the outcome polynomial, unrestricted-real result, or machine-size/operation record is claimed. Third-party primary papers are linked in the proof and not redistributed. The separate prime-coded variant's density theorem is not an unweighted density theorem for this pair-input variant.
