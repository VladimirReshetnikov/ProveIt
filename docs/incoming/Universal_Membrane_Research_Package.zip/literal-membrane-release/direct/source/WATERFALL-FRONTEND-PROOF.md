# A fixed 46-clock Waterfall frontend, and macrostep compression

## Result and credit

The fixed matrix in `source/UniversalTM15x2.twm.txt` is **prior work by Iijil**,
not a newly discovered universal machine. Its 15-state binary source machine
is the Neary–Woods machine in Table 16 of *Four Small Universal Turing Machines*.
The contribution of this packet is an independently checked, explicit
two-half-tape loading interface, a complete affine macrostep certificate for
this particular matrix, and a bounded-TM-step Diophantine compiler that removes
all repetitions internal to each Waterfall macrostep. Literature priority of
this particular arithmetic presentation has not been established.

This is not a fixed-arity Diophantine equation for arbitrary unbounded runs.
The trace certificate below has size linear in an externally supplied number
of **TM steps**, although independent of the potentially exponentially larger
number of Waterfall firings. No 75/87-operation frontier claim is made.

## 1. Exact standard-Waterfall convention

There are 46 actual clocks. The 47th row/column in the source serialization
is metadata. Source row `i+1`, after its first entry, is the increment vector
added when actual clock `i` fires. Thus our mathematical destination-row,
source-column matrix is the transpose of the source trigger submatrix.

Let `a>0` be the integer initial values and let `p` be the vector of counts
of already fired nonhalting clocks. Absolute deadlines are

    d = a + M p.

The next event is the unique minimum coordinate of `d`. If it is the halt
clock, stop before applying any update. Otherwise add the selected column.
This is exactly the simultaneous-decrement physical semantics: at physical
time `t`, value `v_i` has deadline `t+v_i`; advancing to the next minimum leaves
deadlines unchanged, and a trigger adds its increments to them. Nonnegative
increments and a positive selected self-reset make the next event later.
With integers there is no finite-time accumulation of infinitely many events.
A minimum tie is undefined, and is never silently broken.

In this matrix every trigger entry lies in `0..12`; every nonhalt diagonal is
positive. Exactly one row is all zero: one-based clock 28, named `TransJ1`.
The complete macrostep proof below establishes that no minimum tie is reached
from any canonical input, for any `L,R>=0`.

## 2. Canonical state and ordinary input

Write states as `A,...,O` (numeric `0,...,14`) and symbols as `0,1`.
The current head symbol is stored in finite control. `L,R` are ordinary
nonnegative integers whose binary digits, least significant first, are the
successive tape symbols strictly left and strictly right of the head.
Zeros outside the finite binary expansions are blank. Trailing blank digits
need no separate tape-length coordinate.

At a canonical cut before the next transition firing, normalize the active
transition deadline to 1. The 46 deadlines are:

- `LeftTape=2+2L`, `RightTape=2+2R`
- `LeftDiv_j=RightDiv_j=2+[j!=s]`
- `Trans_{q',s'}=1+[q'!=q]+[s'!=s]`
- every remaining clock has deadline 2

For the universal initial condition, `q=A,s=0`. All coefficients and control
initial values are fixed; only the two tape entries vary. Loading `2+2L` and
`2+2R` takes 2 multiplications by the fixed constant 2 and 2 additions. This
four-operation loader takes the **raw half-tape integers**, not an unpaid
opaque history code.

If a syntactically valid source-file metadata bound is also required, use
header `2(L+R)+47`, computed as `LeftTape+RightTape+43`: two more additions.
This is strictly larger than every initial value, every trigger entry, and
the metadata clock count 46. The operational loader is four operations; the
whole valid serialization loader is six. The header is never an actual clock
in the semantics used here.

The primary paper's initial U15,2 head is over the rightmost `c` of `G=bc`,
with `c=0`, and starts in `u1=A`. The encoded bi-tag program lies to its left.
Consequently a universal input interface must allow **both** half tapes;
varying only the right tape in the creator's example is insufficient to infer
the full standard universal-input contract. The paper's finite encoding gives
finite binary `L,R` effectively from a TM program and input. Its universality
theorem, together with the exact simulation here, makes halting for this fixed
matrix on `(L,R)` a c.e.-complete set. No small arithmetic compiler from a
different external program-number convention is claimed or charged here.

## 3. Complete macrostep

Consider any defined transition `(q,s)->(w,D,q')`. Let `X` be the half tape
in movement direction `D`, let `Y` be the other half tape, and write uniquely

    X = 2Q+r,  Q>=0, r in {0,1}.

Write `O` for the opposite direction. The exact firing word before the next
transition event is

    Trans_{q,s}
    (D_Div0 D_Div1)^Q
    D_Div0^r
    D_Tape
    D_Trans^Q
    D_Temp
    O_Mult^Y
    O_Tape
    O_Trans^(2Y)
    O_Temp
    O_Write_w.

Zero exponents omit the block. After this word, the absolute deadline vector
is exactly the new canonical state plus a common scalar:

    q_new=q', s_new=r,
    popped half=Q, pushed half=2Y+w,
    delta = 19+6Q+2r+6Y.

The number of nonhalting Waterfall firings in the word is

    C_step = 6+3Q+r+3Y,
    delta = 2 C_step+7.

`delta` is the difference between the **consecutive transition-event
timestamps**. It is not the elapsed time to the immediate post-Write state.
For example with `L=R=0`, the first Trans event is at 1, the final Write is at
10, and the next Trans event is at 20. The absolute deadline identity remains
valid during the intervening idle decrement period.

The unique undefined TM instruction is `(J,1)`; its Waterfall row is all zero.
If the next canonical state is `(J,1)`, the next event is exactly the halt event.
If a TM halts after `k` executed instructions and `C` preceding Waterfall
firings, the physical halt timestamp is therefore

    tau = 1+2C+7k.

The halt observation itself is not included in `C`.

## 4. Why the symbolic replay proves all input sizes

For a fixed block word `w` with count vector `v`, starting deadline vector
`d`, and `K>=1` repetitions, the deadline gap before a selected letter `i`
in repetition `ell` is

    d_j-d_i + (M prefix)_j-(M prefix)_i
      + ell*((M v)_j-(M v)_i).

It is affine in `ell`. All repetitions choose exactly the intended unique
minimum iff every such gap is strictly positive at `ell=0` and `ell=K-1`.
This is an iff: an affine function on an interval attains its minimum at an
endpoint. Every prefix position of the block must be checked; merely checking
the endpoints of the whole firing word would be false.

`verify_frontend.py` applies this theorem to each displayed block, each of
the 29 defined source instructions, and each of the two values of `r`.
The starting deadlines and every endpoint gap have form `c+aQ+bY`. On blocks
repeated `Q` times, their nonempty domain is `Q>=1`; on blocks repeated `Y` or
`2Y` times it is `Y>=1`. After this shift, the checker verifies nonnegative
coefficients and constant term at least 1. It also symbolically verifies all
46 final-coordinate identities, not only the control and tape coordinates.
Thus these are exhaustive algebraic certificates over unbounded natural
`Q,Y`, rather than finite-grid extrapolation.

The replay checked 58 macrostep cases, 43,065 strict-minimum inequalities
(64 distinct affine forms), and every full final-state identity. The program
uses exact Python integers and has no arbitrary time or tape bound in this
symbolic proof. It is not a proof-assistant formalization.

## 5. Direct Diophantine compression of k TM steps

Fix an external integer `k>=1`. The supplied parameters are `L_0,R_0,C,tau`
in the naturals. For each step `j=0,...,k-1`, introduce:

- 29 natural selectors `e_{j,q,s}`, one for each defined TM instruction
- natural `Q_j,Y_j,r_j`
- natural `L_{j+1},R_{j+1}`

There are exactly `34k` witnesses. Let `A_j,S_j,B_j,D_j,W_j` be the fixed
linear forms in these selectors giving respectively current state, current
symbol, next state, right-move bit, and written symbol. These are arithmetic
expressions, not extra witnesses or black-box functions. Use these seven
equations per step:

    sum e_j = 1
    A_j = (0 if j=0 else B_{j-1})
    S_j = (0 if j=0 else r_{j-1})
    D_j R_j + (1-D_j)L_j = 2Q_j+r_j
    Y_j = L_j+R_j-2Q_j-r_j
    L_{j+1} = D_j(2Y_j+W_j)+(1-D_j)Q_j
    R_{j+1} = D_j Q_j+(1-D_j)(2Y_j+W_j).

Finally add four equations:

    B_{k-1}=9,  r_{k-1}=1,
    C=6k+sum_j(3Q_j+r_j+3Y_j),
    tau=1+2C+7k.

The `7k+4` residuals have degree at most two. Their sum of squares is a single
integer polynomial of degree at most four. No powers with variable exponents,
products of variable length, packed history decoder, minimum oracle, or
implicit execution predicate occur in it.

Why no explicit Boolean constraints are missing: natural selectors summing
to one are one-hot; thus `D_j,W_j,S_j` are Boolean and `A_j,B_j` are the
selected states. For `j<k-1`, `r_j=S_{j+1}`; the final `r` is 1. Hence every
`r_j` is Boolean too. Euclidean division then makes `Q_j,r_j` unique. The
other half, both updated halves, and the next control are uniquely forced.
By induction a solution is exactly the first `k` nonhalting TM steps, followed
by halt. A halt at an earlier step cannot select a row because `(J,1)` is
absent. Every halting computation supplies the unique witnesses, and the
macrostep theorem supplies its exact Waterfall count and time. Thus for fixed
inputs and outputs the natural fiber is either empty or a singleton.

At `k=0` the fixed initial state is `(A,0)`, so first halt is impossible; use
the constant polynomial 1. The changing number of witnesses as `k` varies is
exactly why this is **not** a fixed-arity universal equation.

## 6. Compression is quantitatively substantial

The preferred degree-two certificate with `35k` witnesses, and the degree-three
certificate with `34k` witnesses, are proved in `LOWER-DEGREE-PROOF.md`.
The quartic in Section 5 is retained as an explicit baseline, not the best degree.

Take initial `L=2^m,R=0`. The first U15,2 instruction is `A0 -> 0,R,B`.
It has `Q=r=0,Y=2^m`, and therefore uses exactly `6+3*2^m` Waterfall firings
and a transition-to-transition time increment `19+6*2^m`. The left half-tape
integer has only `m+1` binary digits. A macrostep certificate uses the same
fixed number of coordinates for every `m`. This is exponential compression
relative to the input's bit length; it does not assert every universal run
has such a separation or that the final unbounded arithmetization is paid.

## Sources

- Creator matrix: https://github.com/Iijil1/MTGPrograms/blob/main/Examples/UniversalTM15x2.twm.txt
- Creator source TM: https://github.com/Iijil1/MTGPrograms/blob/main/Examples/UniversalTM15x2.tm.txt
- Compiler: https://github.com/Iijil1/MTGPrograms/blob/main/TMtoTWM/TMtoTWM.go
- Primary paper: https://dna.hamilton.ie/assets/dw/NearyWoods-FI09.pdf
- Author-deposited archive: https://mural.maynoothuniversity.ie/id/eprint/12416/

The primary Table 16 image confirms `u15,b -> b,R,u14`, matching the creator
table. A secondary transcription with `u1` is not used. The same primary
table leaves `(u10,b)` undefined; its later halting prose says `(u10,c)`, which
conflicts with the table. This packet uses the explicitly displayed table,
including its unique missing `(u10,b)` instruction, not that prose typo.
