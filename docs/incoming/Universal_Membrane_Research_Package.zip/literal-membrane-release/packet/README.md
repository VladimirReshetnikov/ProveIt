# Literal active-membrane universal frontend

This packet closes the literal-program and input-interface gap in the separate active-membrane motif research packet. It does not modify that release.

The fixed frontend has 8,408 two-counter ADD/SUB instructions, 34,605 polarizationless membrane rules, 19,162 object symbols and four labels. On every positive raw input A, its structural loader makes A+4 membranes. A globally halting maximally parallel branch exists exactly when the audited Neary–Woods U15,2 machine halts on half tapes (v_2(A),v_3(A)).

Its accepted raw inputs have a natural density that is left-computably enumerable but noncomputable; the exact weighted-halting corollary is in `PROOF.md` §9.

For each fixed physical instruction count T, an explicit quadratic outcome certificate uses 29,904T natural witnesses, 4T+1 affine squares and 10,748T nonnegative products. The input-and-T fiber is empty or a singleton; unknown T remains unpaid.

Start with `PROOF.md`. The acceptance condition is actual global halting, not merely a HALT object. The membrane simulator is nondeterministic even though the counter program is deterministic.

## Main artifacts

- `literal2.txt`, `literal2.json`: complete fixed two-counter program, with no macros or unresolved aliases
- `virtual3.txt`, `virtual3.json`: transparent three-counter intermediate
- `tm_table.json`, `source/UniversalTM15x2.tm.txt`: audited source table
- `membrane_rules.jsonl`: all 34,605 literal sparse rules, sequential IDs
- `object_alphabet.txt`, `frontend_metadata.json`: exact alphabet, labels, structural-input contract and counts
- `macro_certificates.json`: finite correspondence between source rows and literal macro control graphs
- `load_input.py`: executable sparse structural loader; `--A` is the raw interface and `--halves` explicitly pays exponentiation preprocessing
- `build_frontend.py`: deterministic generator of the saved literal tables
- `verify_frontend.py`: all-input affine path checks covering every literal instruction, plus direct finite replay
- `verify_membrane.py`: all-branch small-state gadget checks and the essential halt-control/live-trap regression
- `quadratic_outcome.py`, `semantic_branches.json`, `quadratic_schema_T1.json`: fully explicit degree-two fixed-time outcome polynomial family
- `verify_quadratic.py`, `quadratic_small_fixtures.json`, `quadratic_verification_receipt.json`: independent arithmetic evaluation, branch checks and adversarial tests
- `verify_density.py`, `density_lower_bounds.json`: exact rational lower approximants to the noncomputable acceptance density
- `replay_example.py`, `accepting_example.json`: exact, macro-counted accepting example A=64
- `verification_receipt.json`, `membrane_verification_receipt.json`: test coverage and results
- `source/`: small source-TM serialization and the previously established input-contract reference proof; primary papers are linked, not redistributed
- `MANIFEST.json`: file sizes and SHA-256 digests, excluding the manifest itself

## Reproduce

Python 3 standard library only, from this directory:

    python build_frontend.py
    python verify_frontend.py
    python verify_membrane.py
    python replay_example.py
    python verify_density.py
    python quadratic_outcome.py --steps 1
    python verify_quadratic.py
    python load_input.py --A 64

The all-input proof combines exact symbolic loop-body identities with decreasing loop ranks. Concrete finite grids are supplementary. The very long accepting microtrace is counted by these proved macros, not physically enumerated.

## Boundaries

This is a fixed-rule **structural-input acceptor**. Its initial expanded tree varies with input. The map from externally supplied half tapes to raw input, A=2^L3^R, is paid effective preprocessing. No fixed-arity Diophantine polynomial, small-witness bound, efficiency record, 75/87-operation claim or new generic counter-machine universality theorem is asserted. The explicit construction is intentionally large and slow.
