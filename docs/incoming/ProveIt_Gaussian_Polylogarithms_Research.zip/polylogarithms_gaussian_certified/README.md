# Gaussian reductions and certified polylogarithm evaluation

**Research continuation for ProveIt — 9 October 2026.**

Read `article.pdf` (20 pages). The canonical source is `article.tex`, with
its two exact generated tables in `generated/`. `article-standalone.tex`
contains those tables inline and can be compiled as a single file.

## Mathematical results

Six candidates in the source manuscript are proved: the weight-five Gaussian
relation and all five weight-six Gaussian double-polylogarithm rows. The former
belongs to an explicit infinite odd-weight shuffle family. The latter follow
from a carefully regularized specialization of Panzer's published depth-two
parity formula. The package adds exact weight-eight and weight-ten tables,
and machine-readable parity specializations through weight twelve.

A separate analytic development gives a Chebyshev–moment expansion of
`Li_{a,b}(x,y)` with a geometric error bound that remains valid when `x*y=1`.
Every moment is a finite expression in classical polylogarithms and harmonic
sums. A matching exponential-rate lower bound concerns **uniform polynomial
approximation of the integration kernel**, not every possible evaluation
algorithm. The large-conductor term-count estimate is not a full bit-complexity
claim.

The `S4` identity is still a conjecture. Its small certified residual is not a
proof. No numerical independence, minimal-depth theorem, first-publication
priority, peer review, or proof-assistant verification is claimed.

## Reproduce

Tested with Python 3.13.5, SymPy 1.14.0, and mpmath 1.3.0. Python 3.11 or later
is recommended. The core interval evaluator itself uses only the standard
library; SymPy compiles exact formulas, and mpmath supplies independent,
non-rigorous integral comparisons.

```sh
python -m pip install -r requirements.txt
python code/test_arithmetic.py
python code/verify.py
python code/audit_certificates.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

`make all` runs the same checks, produces the standalone TeX, and builds the
PDF. Run without Python's `-O` flag: the verification programs deliberately
require their assertions. `verify.py --quick` omits independent quadrature
and rewrites the verification data; the delivered record is a **full** run.

The full verification run takes about 20 seconds in the delivery environment;
this is a local observation, not a portable performance guarantee. It creates
89 interval certificates, all with residual-coordinate widths below `1e-35`,
using 73 spectral terms and 246 working decimal places. Nine interval-primitive
regression methods, 80 exact symbolic checks, 640 cleared-denominator polynomial
identities, and eight independent integral comparisons also pass.

## Files and integration

`code/certified.py` is the outward-rounded evaluator. Root arguments are
integer **exponents**, not raw complex numbers: `double(a,b,q,r,s)` means
`Li_{a,b}(exp(2*pi*i*r/q), exp(2*pi*i*s/q))`. Its supported root levels are
2, 3, and 4, with nontrivial outer argument. The analytic theorem has the
wider domain stated in the article.

`data/certificates.json` stores exact integer endpoints and decimal scales.
`data/identities.json` stores exact formulas; `P`, `L`, `B2`, and `Z3` mean
pi, log(2), beta(2), and zeta(3), respectively. The endpoint-only auditor is
not a substitute for re-running the evaluator or checking the analytic proofs.

`INTEGRATION.md` maps source labels to proofs. `CLAIMS.json` separates theorem,
computation, and conjecture status. `PROVENANCE.json` pins the inspected source.
`RESEARCH_QUESTIONS.json` lists nine concrete continuations. `BUILD_REPORT.json`
records PDF and test validation.

The ProveIt repository was not changed. This is a new, unrefereed AI-assisted
research bundle intended for mathematical review and subsequent integration.
