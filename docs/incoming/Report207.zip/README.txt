Report207: First kind Stirling Catalan asymptotics and inversion
4 October 2026

A086662: exact integral, resummed inverse-n expansion, divergent inverse-log
series and convergent incomplete-gamma completion, shrinking inverse estimates,
local cycle law, Ewens total variation, and the size-dependent mixing boundary.

BUILD
  Python >=3.10; mpmath==1.3.0; pdflatex with packages used by Report207.tex.
  python build.py
  python -O build.py
The exact checker has no third-party Python dependency. Numeric diagnostics use
mpmath. The TV table uses a deliberately noncertified float recurrence with a
220-cycle cutoff; its mass residual is printed in diagnostics.json.

CONTENTS
  Report207.tex / Report207.pdf          editable source and rendered report
  verify_exact.py / exact_results.json  1253 exact finite checks
  diagnostics.py / diagnostics.json    90-digit-working scalar/log diagnostics
  supplementary.py / supplementary.json marked/Newton/boundary diagnostics
  build.py / requirements.txt          deterministic build and dependency pin
  tables.tex / table_cells.json        every numeric table cell tied to data
  checks.json / MANIFEST.json          finite guards and SHA-256 member pins

Every guard uses explicit exceptions, including deliberate negative probes in
normal and optimized modes. The build propagates -O to calculation scripts.
Tables and all results are recomputed, not copied from frozen expected output.
The PDF is compiled to byte stability with fixed dates and no shell escape.
The archive has sorted members, fixed timestamps and permissions, and no archive
self-hash cycle. MANIFEST.json pins all other archive members. The complete ZIP
hash is reported by the build rather than embedded in the archive.

Reproducibility is exact within the tested Python/mpmath/TeX environment; other
versions may produce different floating or PDF bytes. Extracting the actual
ZIP and rebuilding it under both modes is the final public replay test.

The analytic proofs establish the asymptotic remainder orders. Finite checks do
not certify asymptotic constants, effective onsets, discrete rounding, or all
printed floating-point digits. No optimal truncation theorem or global priority
claim is made. Barry's integral and the classical methods and Ewens results are
credited in the report. No third-party paper PDFs are distributed.
