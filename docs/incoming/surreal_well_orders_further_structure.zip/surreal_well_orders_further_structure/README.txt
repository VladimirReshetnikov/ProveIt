LEXICOGRAPHIC ORDERS OF SURREAL WELL-ORDERS
Further Structure, Automorphism Obstructions, and Model Dependence

Prepared for Vladimir Reshetnikov, 3 October 2026.

CONTENTS

surreal_well_orders_further_structure.pdf
    The complete 44-page article, with proofs, an internal bibliography,
    a source audit, and twelve proposed research questions.

surreal_well_orders_further_structure.tex
    Standalone LaTeX source for the PDF. No external figures, bibliography
    database, repository checkout, or network access is needed to compile it.

SOURCE_AUDIT.txt
    The pinned ProveIt revision, exact source locations, and the scope of
    the repository and literature audit.

LEAN_INTERFACE_AUDIT.txt
    Detailed source-level audit of four existing Lean foundation files.
    This records actual declarations, universes, assumptions, and limits.

HOW TO COMPILE

From this directory, run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error surreal_well_orders_further_structure.tex

Alternatively, run pdflatex on that source three times to settle references.
The source uses standard TeX Live packages: Latin Modern, AMS mathematics,
mathtools, mathrsfs, geometry, microtype, booktabs, longtable, tabularx,
array, enumitem, xcolor, fancyhdr, hyperref, xurl, and cleveref.
BibTeX and Biber are unnecessary: the bibliography is in the source.

READING GUIDE

Sections 1-2: Interpretations, logical size, and the relation to prior work.
Sections 3-4: Set-sized enumeration spaces, residual fibers, and closure.
Sections 5-6: Noncardinal birthday stages and coherent stage embeddings.
Section 7: The countable-alphabet example, topology, and homogeneity.
Section 8: Class comparison, canonical blocks, and a genuine dense core.
Section 9: Cut reconstruction and the automorphism extension obstruction.
Section 10: Finite condensation and countable standard/nonstandard models.
Section 11: Model dependence and changes of the admitted class collection.
Section 12: A concrete route to rigorous formalization.
Section 13: Twelve research questions and proposed verification milestones.
Appendix A: Repository provenance and the verification record.

SELECTED RESULTS

Theorem 4.1 and Corollary 4.4: First-cardinality fiber decomposition and
the closure of the minimum-length stratum under the stated hypotheses.

Theorem 5.4 and Corollary 5.5: Exact basic invariants for noncardinal
birthday bounds and the resulting obstruction to interval self-similarity.

Theorem 6.1: Minimum-length embeddings within a cardinality band that
compose exactly, with an explicit description of their images.

Theorems 7.1 and 7.3, Corollary 7.4, and Theorem 7.5: Baire topology,
finite homogeneity, failure of intrinsic prefix recovery, and omitted cuts.

Theorems 9.2 and 9.4: Elementary cut reconstruction and the exact
set-like automorphism extension criterion.

Theorem 9.12: Some automorphisms of the dense core do not extend even
to order embeddings from set-like enumerations into all class well-orders.

Corollary 10.7, Theorem 10.11, and Proposition 10.13: Different exact
countable classifications for standard and nonstandard natural numbers;
the resulting pure linear orders nevertheless have the same first-order
theory.

Theorems 11.5 and 11.7: Class expansions add represented cuts, while the
external set-like enumeration order of any countable GBC model is rational.

PROOF STATUS

This is an AI-assisted research manuscript with written mathematical
proofs. Principal arguments received independent internal proof checks.
These checks are not refereeing or proof-assistant verification. Results
presented as extensions are developed and proved in this manuscript;
no historical priority claim is made. Repository results and classical
background are identified separately.

No new Lean theorem was implemented. The four audited Lean sources were
read, but their dependencies were not recursively audited and the
repository was not built. Source inspection is not a fresh kernel check.
No repository files were modified.

The final PDF compiled successfully with references settled and without
unresolved-reference or overfull/underfull-box warnings. All pages were
rendered and inspected for layout; key pages were inspected at full size.

FOUNDATIONAL CONVENTION

The set-sized sections use ZFC. Class-theoretic sections state their
GB/GBC assumptions explicitly. In a two-sorted theory, collections of
class well-orders are handled by predicates and uniform operators on
class parameters, not by an undeclared class whose members are classes.
External countable and universe-relative interpretations are identified
separately. The PDF gives the full axiom and size ledger.
