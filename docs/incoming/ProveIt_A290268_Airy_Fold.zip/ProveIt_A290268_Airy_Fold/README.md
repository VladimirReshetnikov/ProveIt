# The Airy transition at the A290268 critical ratio

`article.pdf` is the ten-page standalone report. The complete source is `article.tex` and `airy_sections.tex`.

The main theorem gives an additive Airy expansion in every bounded critical window k−kappa_c d=O(d^(1/3)), for each fixed central offset b=q−2d. Its exact finite-depth normalization includes parity, rounding, and bounded parameter shifts. It proves:

- Eventual noncancellation at every nearest integer k to kappa_c d, for every fixed b, apart from the known reflection holes
- The same conclusion for every displacement k−kappa_c d=o(d^(1/3))
- Uniform noncancellation on compact scaled windows avoiding zeros of the leading Airy factor

The expansion remains additive at Airy zeros. It does not assert that any integer coefficient vanishes there. Growing offsets and the full support conjecture remain outside the result, and no numerical depth threshold is supplied.

The proof is analytic and algebraic. It contains the uniform O(1) trace estimate, exact finite-depth centering, quartic modulus bound, bounded-variation oscillatory-tail argument, Airy multiplier theorem, and full fixed-offset phase restoration. It uses no finite scan or numerical certificate.

Compile `article.tex` twice with pdfLaTeX on a standard TeX Live installation. `build_local.sh` is the wrapper used in preparation. The final source received independent mathematical review, and every PDF page was visually inspected. The report is not a Lean formalization or an externally refereed paper; no exhaustive priority claim is made.

The source comparison is pinned to ProveIt commit `ca81647a9f679e96d49ffdbc54b0c0ab13d10a36`. The bibliography identifies that coefficient model and the classical Airy integral and value at zero. All other ingredients needed for the stated theorem are proved in the report.
