# Positive amplitude and all orders for finite binary languages

This package proves a positive amplitude and an arbitrary finite-order n^(-1/3) expansion for OEIS A331120, including a constructive coefficient generator and a precisely selected smooth inverse. The 16-page standalone article includes all shared Jacobi lemmas and their proofs in its appendix.

## Read

- article/dfa-finite-languages.pdf: complete mathematical report
- article/dfa-finite-languages.tex: editable standalone source
- review/integrated-review.md: independent mathematical review, pinned to the exact TeX hash
- review/independent-delay-audit.md: detailed analytic, boundary and inverse audit
- review/visual-qa.json: all-page visual review receipt
- sources/literature-status.md: established baseline and bounded novelty/overlap checks

## Replay offline

Python 3.10 or newer, SymPy and mpmath are required. The tested environment used the versions in requirements.txt. No network access is needed by the scripts.

    python run_all.py

To also rebuild the PDF using an installed TeX distribution:

    python run_all.py --pdf

Generated files go under output/. Supplied files are checked before and after replay and remain unchanged. The PDF build creates local formats and font maps if the installed distribution lacks generated ones; it does not download packages.

The generator code/formal_dfa.py accepts --order K, K>=4, and generates forward logarithmic coefficients through depth K-3. Default K=6 yields the three coefficients printed in the article. Higher orders may be costly. Run it from a copied directory if you want to preserve the supplied inputs.

## Mathematical scope

The constant is proved finite and positive, but its decimal digits are not certified. Numerical amplitude ratios in the article are diagnostic only. Inverse tests use explicitly stated trial amplitudes and do not certify the unknown true constant or arbitrary discrete thresholds. The work proves a finite-order Poincare expansion, not a full exponentially improved transseries. No general weighted-parameter theorem is asserted.

The known Airy scale and exponent7/8 are credited to Elvey Price, Fang and Wallner, AofA2020. The additional result is the convergent positive amplitude and all finite correction orders. This is a research report with independent mathematical checks, not a claim of external publication or peer review.
