from pathlib import Path
from functools import lru_cache
import sys,json,time,random,heapq,argparse
P=Path(__file__).resolve().parents[2]/'code';sys.path.insert(0,str(P));import source_language as S
@lru_cache(None)
def props(t):
 if S.leaf(t):return (0,0,0,0)
 al,az,ah,ad=props(t[0]);bl,bz,bh,bd=props(t[1]);ll=1+al
 return ll,max(ll,az,bz),ah+bh+(1 if ll==6 else 0)-(1 if al==6 else 0),1+max(ad,bd)
def nodes(t):
 z=set()
 def go(n):
  if n in z:return
  z.add(n)
  if not S.leaf(n):go(n[0]);go(n[1])
 go(t);return z

def repl(t,a,b):
 @lru_cache(None)
 def go(n):
  if n==a:return b
  return n if S.leaf(n)else(go(n[0]),go(n[1]))
 return go(t)
def closed(n):return S.boundary(n)[:2]==(0,0)
def rotations(t):
 for n in nodes(t):
  if S.leaf(n):continue
  a,b=n
  if not S.leaf(a):
   x,y=a
   if all(map(closed,(x,y,b))):yield n,(x,(y,b))
  if not S.leaf(b):
   y,z=b
   if all(map(closed,(a,y,z))):yield n,((a,y),z)

def score(t):
 p=props(t);n=len(nodes(t));return (p[1],p[2],n,p[3])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('source');ap.add_argument('--seconds',type=float,default=40);ap.add_argument('--budget',type=int,default=206);ap.add_argument('--out',required=True);ap.add_argument('--seed',type=int,default=1981);a=ap.parse_args();rng=random.Random(a.seed)
 rows=json.loads(Path(a.source).read_text());base=S.tree(rows);g,_=S.graph_arithmetic(rows);root=base;best=base;ss=score(root);print('base',ss,flush=True)
 start=time.monotonic();seen={root};bestvalue=(ss[1],ss[2]);history=[];it=0
 while time.monotonic()-start<a.seconds:
  pool=[]
  for x,y in rotations(root):
   q=repl(root,x,y)
   if q in seen:continue
   v=score(q)
   if v[0]>6 or v[2]>a.budget or v[3]>55:continue
   pool.append((v,q))
  if not pool:root=base;seen={base};continue
  pool.sort(key=lambda z:(z[0][1]*3+max(0,z[0][2]-201)*2,z[0][2],z[0][3]))
  pick=0 if rng.random()<.85 else rng.randrange(min(8,len(pool)))
  ss,root=pool[pick];seen.add(root);it+=1
  if (ss[1],ss[2])<bestvalue:
   best=root;bestvalue=ss[1],ss[2];r=S.sites(best);gg,_=S.graph_arithmetic(r);assert gg==g;assert S.graph_intervals(r)==g
   Path(a.out).write_text(json.dumps(r,separators=(',',':'))+'\n');history.append(dict(iteration=it,score=ss,seconds=time.monotonic()-start));print('best',history[-1],flush=True)
   if ss[0]<=5:break
 print(json.dumps(dict(status='MAX5_FOUND'if props(best)[1]<=5 else'NO_MAX5',best=score(best),iterations=it,seen=len(seen),seconds=time.monotonic()-start,history=history)),flush=True)
if __name__=='__main__':main()
