# Scanner experiment: valid source transformation, no smaller machine

The included `max5_206.sites.json` has maximum zero run five, 206 distinct
subtrees, 4,775 primitive occurrences, and depth42. Its entire ordered guarded
control-flow graph equals `input.sites.json` under two independent resolvers.
This is a genuine source transformation, not a 214-state construction. Five
extra shared source nodes are not paid for by a proposed one-state scanner saving.

The two logs record the bounded search. Re-running the time-bounded search may
produce a different trajectory; the fixed final source is independently checked
by the main verifier, which does not rerun the search.

Example optional exploration:
`python3 -B research/scanner/search.py research/scanner/input.sites.json --seconds 50 --budget 206 --out /tmp/new-source.json`
