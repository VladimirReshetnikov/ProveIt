#!/usr/bin/env python3
import sys,json,hashlib,time,itertools
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import check_joint_fold as check,filter_source as filt
p=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=True);old,start=check.read(p);Q=sorted({q for q,b in old});R=5;fuel=97;I=check.domain(old,start,R);paths={};t=time.monotonic();count=0;hits=[];partial=False;digest=hashlib.sha256();npair=0
pairs=list(itertools.permutations(Q,2));pairs.sort(key=lambda v:(-sum(old[v[0],b]==old[v[1],b]for b in(0,1)),v))
for keep,drop in pairs:
 phi=lambda q:keep if q==drop else q;new={(q,b):(w,d,phi(z))for(q,b),(w,d,z)in old.items()if q!=drop};actions=[sorted({(old[q,b][0],old[q,b][1],phi(old[q,b][2]))for q in(keep,drop)})for b in(0,1)];common=[b for b in(0,1)if len(actions[b])==1]
 variants=[(a0,a1)for a0 in actions[0]for a1 in actions[1]]
 if len(common)==1:
  fixed=common[0];other=1-fixed
  for a in itertools.product((0,1),(-1,1),sorted((set(Q)-{drop})|{254})):
   if a in actions[other]:continue
   v=[None,None];v[fixed]=actions[fixed][0];v[other]=a;variants.append(tuple(v))
 for a0,a1 in variants:
  count+=1;new[keep,0]=a0;new[keep,1]=a1;bad=filt.local_filter(old,new,I,keep,drop,paths,fuel,R)
  digest.update(json.dumps([keep,drop,a0,a1,bad],separators=(',',':')).encode()+b'\n')
  if bad is not None:continue
  try:proof=check.check(old,new,start,phi(start),keep,drop,R,fuel,I)
  except ValueError as e:continue
  name=f'hit{len(hits):03}';(out/(name+'.native.tm')).write_bytes(filt.encode(new,phi(start)));(out/(name+'.proof.json')).write_text(json.dumps(proof,indent=2)+'\n');hits.append({'keep':keep,'drop':drop,'rows':[a0,a1],'file':name+'.native.tm'});print('HIT',hits[-1],flush=True)
 npair+=1
 if npair%5000==0:print('PAIR',npair,'COUNT',count,'SECONDS',time.monotonic()-t,flush=True)
result={'status':'TIME_CAP'if partial else'COMPLETE_BOUNDED_SEARCH','seed_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'input':str(p),'radius':R,'fuel':fuel,'pair_count':npair,'candidate_count':count,'hits':hits,'ordered_rejections_sha256':digest.hexdigest(),'seconds':time.monotonic()-t,'scope':'All working-state orderedpairs, inheritedactions plus allonecommonaction folds; radius5all-tape inductivewindow. No failed search impliesminimality.'};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
