#!/usr/bin/env python3
"""Portable, deterministic reconstruction of four short-transfer experiments.

No optimizer and no external package is required. The default run reconstructs
source and machine bytes, checks exact CFG transformations, and replays the
three recorded symbolic-runtime failures. --runtime scratch-biased rederives
all quantified primitive cases for that experiment. It does NOT prove logical
calibration, scheduler cofinality, or protected-stack safety.
"""
from pathlib import Path
import argparse,hashlib,json,sys,time,gzip,tempfile
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'checks'))
import source_utils as U
import symbolic_runtime as S
import independent_runtime as I

def at(t,p):
    for b in p:t=t[int(b)]
    return t

def put(t,p,n):
    if not p:return n
    return tuple(put(x,p[1:],n) if i==int(p[0]) else x for i,x in enumerate(t))

def cfg(t):
    return [["JUMP" if op in ("CB","CC") else op,arg,edges] for op,arg,edges in U.cfg(U.flatten(t))]

def count(n):
    nodes=set()
    def go(t):
        nodes.add(t)
        if not U.leaf(t):go(t[0]);go(t[1])
    go(n)
    return len(nodes)

def table_encoding(table,start):
    return U.encode(table).replace(b'#! start 0',f'#! start {start}'.encode())

def rebuild():
    assert U.sha(ROOT/'inputs/parent.sites.json')=='05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922'
    assert U.sha(ROOT/'inputs/parent.native.tm')=='1f8194fa49a638857ecf5b4f69b1ae92cb47d11d1a74e952bbb91049c893a836'
    P=U.tree(json.loads((ROOT/'inputs/parent.sites.json').read_text()))
    transfer=at(P,'111');D,N=transfer[0];assert transfer[1]==N
    assert len(U.flatten(D))==len(U.flatten(N))==26
    load=D[1];assert len(U.flatten(load))==7
    clear=(('CD',1),('CC',1));short=((clear,load),N)
    simple=put(P,'111',short)
    mp=at(simple,'110101')
    permuted=put(put(simple,'110101',short),'111',mp)
    # Move the clear loop across the selector boundary. The escaping CB gains
    # one zero ancestor and therefore changes from CB1 to CB2.
    sel=at(simple,'110');assert at(sel,'11')==('CB',1)
    sel=put(sel,'11',('CB',2))
    context=put(simple,'11',((sel,clear),(load,N)))
    assert cfg(context)==cfg(simple)
    # Rotate the outer Scheduler/Read composition and retag the selector's
    # CB2 as CC3. This preserves the entire ordinal CFG but did not preserve
    # the context assumptions of the physical CC3 entry inherited by synthesis.
    schedule,(read,dispatch)=context
    context=((schedule,read),dispatch)
    assert at(context,'10011')==('CB',2)
    context=put(context,'10011',('CC',3))
    assert cfg(context)==cfg(simple)
    biased=put(context,'10011',(('CI',6),('CC',3)))
    trees={'simple':simple,'simple-permuted':permuted,'context-root':context,'scratch-biased':biased}
    parent=U.parse_table(ROOT/'inputs/parent.native.tm');results=[]
    for name,tree in trees.items():
        dest=ROOT/'candidates'/name
        recipe=json.loads((dest/'recipe.json').read_text())
        source=U.compact(U.flatten(tree))
        assert source==(dest/'source.sites.json').read_bytes(),name
        assert hashlib.sha256(source).hexdigest()==recipe['source_sha256']
        table=dict(parent)
        for q,b,w,d,z in recipe['rows']:table[q,b]=(w,d,z)
        raw=table_encoding(table,recipe['start'])
        assert raw==(dest/'machine.native.tm').read_bytes(),name
        assert hashlib.sha256(raw).hexdigest()==recipe['table_sha256']
        assert len(table)==430 and len({q for q,b in table})==215
        results.append({'name':name,'states':215,'dag_nodes':count(tree),'leaf_occurrences':len(U.flatten(tree)),'source_sha256':recipe['source_sha256'],'table_sha256':recipe['table_sha256']})
    return results

def legacy_table(path):
    T=U.parse_table(path)
    mapping={int(q):int(v) for q,v in json.loads((ROOT/'inputs/native-to-legacy.json').read_text()).items()}
    for q in sorted({q for q,b in T}|{z for w,d,z in T.values()}):
        if q not in mapping:mapping[q]=max(mapping.values())+1
    N={(mapping[q],b):(w,d,mapping[z]) for(q,b),(w,d,z) in T.items()}
    return N

def replay_failures():
    results=[]
    for name,index in [('simple',4697),('simple-permuted',4590),('context-root',4696)]:
        dest=ROOT/'candidates'/name
        N=legacy_table(dest/'machine.native.tm');lemmas,_=S.prove_blocks(N)
        site=json.loads((dest/'source.sites.json').read_text())[index]
        try:S.case(N,lemmas,site,False)
        except AssertionError as err:
            message=str(err);assert 'Unknown run may be empty' in message
            results.append({'name':name,'site_index':index,'site':site,'status':'RECORDED_FAILURE_REPRODUCED','reason':message})
        else:raise AssertionError(('Expected failure unexpectedly passed',name))
    return results


def bootstrap():
    dest=ROOT/'candidates/scratch-biased'
    T=U.parse_table(dest/'machine.native.tm');sites=json.loads((dest/'source.sites.json').read_text())
    f=json.loads((ROOT/'evidence/simple_offset6_zero_startup.json').read_text())['startup_frames'][0]
    assert f['steps']==69744 and f['logical']==[1,4,0,0,0,0,3,10,0]
    expected={x-2 for x in I.frame(sites[64][0],f['logical'],f['spares'],0)}
    assert expected==set(f['one_cells'])
    q=74;h=0;ones=set()
    for step in range(69744):
        b=int(h in ones);w,d,q=T[q,b]
        if w:ones.add(h)
        else:ones.discard(h)
        h+=d
    assert (q,h,ones)==(84,-2,expected)
    cfg=U.cfg(sites);pc=25;regs=[1,0,3,0,0,0,0,0,0]
    for step in range(172):
        op,arg,edges=cfg[pc]
        if op=='CI':regs[arg]+=1;pc=edges[0]
        elif op=='CD':
            positive=regs[arg]>0;regs[arg]-=int(positive);pc=edges[int(positive)]
        elif op in ('CC','CB'):pc=edges[0]
        else:raise AssertionError('Unexpected halt in AX prefix')
    assert pc==64 and regs==f['logical']
    return {'status':'WHOLE_BLANK_FRAME_AND_AX_PREFIX_PASS','steps':69744,'state':84,'head':-2,'header':62,'source_ordinal':64,'source_address':sites[64][0],'logical':regs,'spare_count':len(f['spares']),'spare_values':sorted(set(f['spares'])),'source_AX_entry':25,'source_AX_seed':[1,0,3,0,0,0,0,0,0],'source_primitive_steps':172,'logical_scheduler_calibration':'OPEN'}

def runtime(name,output_dir=None):
    dest=ROOT/'candidates'/name;source=dest/'source.sites.json';machine=dest/'machine.native.tm'
    before=(U.sha(source),U.sha(machine));N=legacy_table(machine)
    sites=json.loads(source.read_text());lemmas,blocks=S.prove_blocks(N)
    start=time.monotonic();cases=[];rows=set();append=0 if name=='scratch-biased' else 1
    for i,site in enumerate(sites):
        for positive in ((False,True) if site[1]=='CD' else (False,)):
            try:answer=S.case(N,lemmas,site,positive,append=append)
            except Exception as e:
                return {'status':'RUNTIME_FAILED','name':name,'site_index':i,'site':site,'positive':positive,'proved_cases':len(cases),'reason':repr(e)}
            rows.update(answer.pop('rows'));answer.pop('trace')
            cases.append({'site_index':i,'positive':positive,**answer})
        if i and i%1000==0:print('Proved',len(cases),'cases',flush=True)
    assert before==(U.sha(source),U.sha(machine))
    stored=json.loads(gzip.decompress((ROOT/'verification'/(name+'-ordered-cases.json.gz')).read_bytes()))
    assert json.loads(json.dumps(cases))==stored, 'Fresh case summaries differ'
    out=output_dir or Path(tempfile.mkdtemp(prefix='short-transfer-runtime-'))
    if output_dir:out.mkdir(parents=True,exist_ok=False)
    with gzip.open(out/(name+'-ordered-cases.json.gz'),'wt') as f:json.dump(cases,f,separators=(',',':'))
    report={'status':'ALL_NATURAL_RUNTIME_PASS','logical_calibration':'OPEN' if name=='scratch-biased'else'REJECTED_PHYSICAL_IMPLEMENTATION','name':name,'states':len(N)//2,'cases':len(cases),'symbolic_rules':sum(c['symbolic_steps']for c in cases),'minimum_duration':min(c['duration'][0]for c in cases),'covered_rows':sorted(rows),'row_coverage':len(rows),'blocks':blocks,'source_sha256':before[0],'table_sha256':before[1],'append':append,'seconds':time.monotonic()-start,'checker_sha256':U.sha(Path(S.__file__)),'scope':'All natural primary register values, natural extra gap, nonempty finite spare list, complete tape and blank exterior. This is an executable mathematical checker, not a proof-assistant kernel artifact.'}
    (out/(name+'-runtime.json')).write_text(json.dumps(report,indent=2)+'\n')
    return report

def main():
    if not __debug__ or sys.flags.optimize:raise RuntimeError('Assertions must be enabled')
    p=argparse.ArgumentParser();p.add_argument('--runtime',choices=['simple','simple-permuted','context-root','scratch-biased']);p.add_argument('--out',type=Path);a=p.parse_args()
    result={'status':'RESEARCH_RECONSTRUCTION_PASS','candidates':rebuild(),'rejected_runtime_witnesses':replay_failures(),'scratch_biased_bootstrap':bootstrap(),'scope':'Reconstruction and rejection evidence only; scratch-biased logical equivalence and protected-credit obligations remain open.'}
    if a.runtime:result['runtime']=runtime(a.runtime,a.out)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
