# Binary research evidence

These files accompany the accepted transfer candidate in `machine/`. They distinguish exact findings from bounded unsuccessful searches. The main machine remains the fully checked 215-state transfer construction; the smaller runtime-only core and the direct 35-leaf command allocations below are research inputs, not accepted blank-tape candidates.

Run the independent research checker from the packet root:

```sh
python3 -B code/check_binary_evidence.py --out /tmp/binary-research.json
```

It uses only the Python standard library. Its importable `verify()` function returns a deterministic dictionary and does not write any files. The main verifier calls this function. Assertions must remain enabled; running Python with `-O` is rejected.

## Exact comparison with prior tables

`comparison-tables/manifest.json` records the pinned repository commit, the SHA-256 of each of the six incoming ZIP archives, every selected member's path and aliases, and the raw hash of each copied table. The collection includes every valid 215-working-state `.tm` table found below `candidate-k215`, in every `docs/incoming` ZIP, and in the extracted transfer201 parent. Duplicate byte strings are stored once: there are 47 raw tables and 23 distinct rooted transition graphs.

The checker parses all literal tables and performs a breadth-first traversal from each declared initial state, always taking the read-0 edge before the read-1 edge. This gives a canonical numbering for the reachable deterministic graph. Edge labels retain the read bit, written bit, and movement direction. Halting is a distinguished terminal vertex. It then compares the entire canonical row sequence, both directly and after reversing every movement direction. This proves that the new candidate is not any of those prior rooted labelled machines under arbitrary renaming of states or global tape reflection. All 215 states of the new candidate are graph-reachable. Some comparison tables have only 214 graph-reachable states and are distinguished for that reason as well.

This establishes a precise relative novelty claim. It neither proves that the machines have different mathematical partial functions nor purports to search all historical Turing machines. The provenance manifest pins the archive bytes consulted; the archives themselves need not be redistributed to rerun the comparison because the exact table bytes are included.

## A specific 214-state core cannot be initialized by choosing another old state

`negative-controls/runtime214-zero.native.tm` is the previous runtime fold of native states 88 and 301, composed with the zero-spare row `198/0 = 0 L40`. The folded decoder uses `88/0 = 0 L51` and `51/0 = 0 R122`; state 301 is removed. Two exact certificate files classify blank execution from every one of its 214 possible initial states, for append values 0 and 1.

A blank execution either follows a cycle of zero-writing transitions forever or reaches a first transition that writes 1. The former case is proved by the repeated state: the tape is still identically zero, so head translation cannot change the future reads. There are only seven first-write states for append 0 and eight for append 1. The certificate follows each of those executions to an outward self-loop on a zero half-line. The largest such finite prefix has 78 steps for append 0 and 85 for append 1. Induction on the number of subsequent steps proves divergence. The verifier replays every recorded transition and checks the whole finite set of 1-cells at the ray endpoint; all unlisted cells are zero.

Thus every old initial state of each specified core has a provable nonhalting blank execution. This is a restricted obstruction to reusing that runtime fold as the desired consistency tester. It does not exclude other 214-state machines, other row edits, or other startup designs.

## One additional initial state also has completely classified outcomes

`onebit-proof.json.gz` covers both append variants, every old state, and both initial head positions adjacent to a sole 1 at cell 0. There are 856 configurations. Exact replay gives 854 outward rays and two explicit halts, with at most 379 transitions before the certified endpoint.

This also classifies what one newly added initial state can do while every old row is unchanged. Its first zero-read transition either enters an old state with blank tape, enters an old state next to one written 1, halts, or returns to itself. A self-loop immediately continues on fresh zero cells in a fixed direction and is an outward ray. The other possibilities are exactly the blank and one-bit cases already classified, up to translation. The statement is about these concrete execution outcomes. It is not a general lower bound on the size of a machine whose nonhalting expresses consistency.

## A genuine counterexample to a tempting 35-leaf allocation

The abstract transfer can be shortened from a composite 78-leaf source body to a direct 35-leaf `COPY_clear; NIP` body. One allocation keeps 201 shared source nodes and 215 binary states and passes a decoder-prefix binding check. That is insufficient: a primitive alias can depend on the bit immediately before its address.

`simple35-permuted-invalid.native.tm` and its full source are included with a literal counterexample. At source occurrence 4590, address `110101000`, the command is `CD 1`. The logical input is `[0,0,0,0,0,1,0,0,0]`, the sole spare is 0, and the extra gap is 0. The specified top register is zero, so correct execution must leave every register unchanged and continue at address `11010101`. Actual execution returns after 634 binary transitions with a different whole tape: it decrements cache register 5 and selects a different successor. The certificate records all transitions; the checker independently constructs the initial and specified final frames and confirms the mismatch.

This refutes this allocation, not the abstract shortened command. A subsequent context-rebracketed allocation also failed at a continue alias whose address had only two trailing 1s although the reused action required three. These failures justify retaining the fully checked composite command in the primary machine.

## Bounded searches, preserved for extension

`bounded-fold-search/` contains four exact seed tables, four discovery receipts, and a portable runner. The two underlying finite-window routines are copied unchanged from the pinned repository's `k218-continuation-search` directory. Each seed search considers all 46,010 ordered pairs of working states. It tries inherited outgoing actions and, when one read action is common, every write/direction/target action for the other read bit. A radius-5 invariant window and a fuel of 97 are used to seek positive common endpoints.

| Seed | Tested specifications | Surviving folds |
| --- | ---: | ---: |
| Accepted permuted transfer | 629,160 | 0 |
| Direct 35-leaf transfer | 625,736 | 0 |
| Permuted direct 35-leaf transfer | 625,736 | 0 |
| Context-rebracketed direct transfer | 620,600 | 0 |
| Total | 2,501,232 | 0 |

The default research verifier checks the seed hashes and receipt bindings; it does not rerun these searches. To rerun one search, choose an output directory outside the packet:

```sh
python3 -B research/bounded-fold-search/run_search.py \
  research/bounded-fold-search/permuted/seed.native.tm \
  /tmp/transfer-fold-search
```

Compare `candidate_count` and `ordered_rejections_sha256` with the included receipt. The portable runner removes the discovery wall-clock cutoff so completion depends only on finishing the finite enumeration. The failed searches are not minimality arguments: a different invariant, more proof-construction fuel, or a transformation outside this action family may succeed.
