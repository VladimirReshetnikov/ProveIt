# Well-Conditioned Diophantine Computation

**Connected Resistor Networks, Compact Support, and a Prime-Localization Barrier**  
Research manuscript prepared for Vladimir Reshetnikov, 2 October 2026.

## Main result

A fixed computably presented connected graph of maximum degree three has
conductance operator `A = 5I - adjacency`, satisfying `2I <= A <= 8I`.
For a computable two-terminal source `b_x`, halting is equivalent to

```
exists positive integer q and finite-support integer array z: A z = q b_x.
```

The analytic equation `A u = b_x` always has a unique uniformly computable
square-summable solution. Exact finite support, not analytic inversion, is
undecidable. The graph is an infinite computable presentation, not a finite
physical halting oracle.

A run with `L = T+1` configurations has least charge `D_L`, where
`D_0=1`, `D_1=5`, and `D_(j+1)=5 D_j-D_(j-1)`. The primitive certificate is
unique. The effective resistance is rational on halting inputs and equals
`5-sqrt(21)` on nonhalting inputs.

For every supplied **finite** prime set S, membership of the **unit-source
solution** in the finite-support module over `Z[S^-1]` is decidable. This is
not the problem with an arbitrary scaling charge q: allowing arbitrary q
already makes integral certificates universal. The localization result is
specific to this constructed family, not a decision theorem for arbitrary
Diophantine equations over those rings.

The article also proves a sharp four-nonzero connected-row threshold under
its scalar rational presentation assumptions, and gives a single quadratic
natural-number polynomial at every externally selected horizon.

## Contents

- `article.pdf`: the 26-page article, including proofs, ten further research
  questions, limitations, bibliography, and formalization plan.
- `article.tex`: complete editable source; bibliography is embedded.
- `src/substrate.py`: exact generic counter-machine, graph, recurrence,
  localization, and quadratic-polynomial compiler APIs.
- `verify.py`: deterministic exact-arithmetic checks and example exporter.
- `verification.json`: actual receipt, with 38,524 passed assertions in 26 groups.
- `examples/countdown_T3_polynomial.json`: complete residual representation
  and the full expanded 105-monomial quadratic polynomial.
- `examples/countdown_T3_witness.json`: every input/witness coordinate and
  all eight nonzero network coordinates.
- `examples/localization_bounds.json`: computed rank constants, stopping
  bounds, and finite-prime examples.
- `sources.md`: source audit, pinned references, and trust boundary.
- `build.sh`: verification plus PDF rebuilding.
- `SHA256SUMS`: checksums of the delivered files, excluding this checksum file.

## Reproduce the checks

Python 3.10 or newer is sufficient; no third-party packages or network access
are required. From the unpacked directory run:

```sh
python3 verify.py
```

The script writes the example JSON files and `verification.json`. It checks
full exterior rows, inverse history uniqueness, graph neighbor symmetry,
exact recurrence denominators, independent rational determinants, rank and
valuation formulas, natural routing gates, all-coordinate witness mutations,
and polynomial identities on signed test assignments. Signed identity tests
are not used as evidence for signed zero-set equivalence.

The checked example is one-counter countdown from input 2. It halts after
three transitions, with history `1, 5, 17, 52`. At m=5, positive-rail values
are `115, 24, 5, 1`; source charge is 551; resistance is `230/551`.
The complete horizon polynomial has 32 natural witnesses, 33 linear
residuals, six cross-term occurrences, and 105 collected nonzero monomials.

## Use the compiler

```python
import sys
sys.path.insert(0, "src")
from substrate import (
    countdown, compile_certificate, canonical_assignment,
    canonical_network_certificate, apply_operator,
    localization_bound, localized_membership,
)

p = countdown()
cert = compile_certificate(p, T=3, m=5)
witness = canonical_assignment(p, (2,), T=3, m=5)
assert cert.energy(witness) == 0

charge, z = canonical_network_certificate(p, (2,), horizon=3, m=5)
assert charge == 551
assert apply_operator(p, z, m=5) == {24: 551, 25: -551}

assert localized_membership(p, (2,), (19, 29), m=5)
assert not localized_membership(p, (2,), (2, 3, 5), m=5)
print(localization_bound(5, (2, 3, 5)))
```

Define other finite programs using the immutable `Program` and `Instruction`
records. `INC(j,target)` increments counter j. `TEST(j,zero,positive)`
branches on zero, decrementing only on the positive branch. Exactly one
HALT state is required. Natural arguments are genuine Python integers;
booleans and floats are rejected. The reference APIs deliberately restrict
m to odd integers at least 3; connected-network operations require m>=5.
Some analytic proofs in the article work for even m as well, but the stated
prime-two valuation proof uses odd m.

`canonical_assignment` requires the exact first halting time, while
`canonical_network_certificate` accepts a horizon at least that halting
time. Neither routine can manufacture a certificate from an unhalted trace.
`apply_operator` evaluates every row affected by the finite array, including
neighbors outside its listed support.

The positive guard slacks are deliberately retained in the literal compiler
for transparent correspondence with the article. The article explains their
possible elimination; the delivered counts are not optimality claims.

## Rebuild the PDF

Use a standard TeX Live installation with the packages named in the source.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

Without latexmk, run pdfLaTeX twice. Alternatively:

```sh
sh build.sh
```

The delivered PDF was compiled successfully, checked for LaTeX warnings,
rendered, and visually inspected. No font files or third-party PDFs are
included in the archive.

## Research status

The article supplies ordinary mathematical proofs and executable finite
checks. It is not independently refereed or formally verified in Lean/Rocq.
Historical priority of the combined theorems is not established. The code is
an effective generic compiler; the demonstration programs are not numerical
universal-machine tables. Fixed-universal existence composes the compiler
with the classical finite-counter universality theorem, as explained in the
article.

The quasi-Diophantine witness is an unbounded finite-support array. The
quadratic polynomial family has externally selected horizon and growing
arity. Neither construction is a claimed fixed-arity single-fold MRDP
representation, an improvement to the repository's 87-operation universal
bound, or a solution of a named classical open conjecture.
