#!/usr/bin/env python3
"""Reproduce construction, source transport, graph comparisons and exact blank run.
Default audits saved quantified runtime evidence; --full derives every case anew.
Python3.10+, standard library only; assertions must remain enabled; no network.
"""
from pathlib import Path
import argparse,gzip,hashlib,json,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'checker'))
import graph_audit as graph

def load(p):
 p=Path(p);return json.loads(gzip.decompress(p.read_bytes())if p.suffix=='.gz'else p.read_bytes())
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def replay(T,record):
 q=h=0;ones=set()
 for tick,e in enumerate(record['trace']):
  assert e[:3]==[q,h,int(h in ones)],('trace precondition',tick)
  w,d,z=T[q,int(h in ones)];assert e[3:]==[w,d,z],('trace transition',tick)
  if w:ones.add(h)
  else:ones.discard(h)
  q=z;h+=d
 assert len(record['trace'])==record['steps']
 assert(q,h,sorted(ones))==(record['state'],record['head'],record['one_cells'])
 return q,h,ones

def audit():
 for name,sha in load(HERE/'manifest.json').items():assert digest(HERE/name)==sha,name
 T,start,halt=graph.table(HERE/'k215-zr34-q50.native.tm');P,_,_=graph.table(HERE/'precursor.native.tm');B,_,_=graph.table(HERE/'parent.native.tm')
 assert(start,halt,len(T))==(0,254,430)
 assert{q for q,b in T}=={q for q,b in B}
 assert T[50,0]==(0,1,75)and P[50,0]==(0,-1,75)and T[75,0]==(0,1,75)
 expected=P.copy();expected[50,0]=(0,1,75);assert T==expected
 assert sum(T[k]!=B[k]for k in T)==16
 rows,m,paths=graph.canonical(T,start,halt)
 dense,ds,dh=graph.table(HERE/'k215-zr34-q50.tm')
 assert(ds,dh,set(q for q,b in dense))==(0,215,set(range(215)))
 assert dense=={(q,b):(w,d,z)for q,b,w,d,z in rows}
 assert m=={int(k):v for k,v in load(HERE/'canonicalization.json')['native_to_dense'].items()}
 # No search: reproduce all six literal rewrites and prove the complete source CFG identity.
 with tempfile.TemporaryDirectory(prefix='k215-zr34-source-')as tmp:
  out=Path(tmp)/'reconstruction'
  subprocess.run([sys.executable,'-B',str(HERE/'checker/replay_rotations.py'),'--table',str(HERE/'parent.native.tm'),'--source',str(HERE/'source/parent-sites.json'),'--output',str(out),'--accelerate50'],check=True,stdout=subprocess.PIPE,text=True)
  assert(out/'candidate.native.tm').read_bytes()==(HERE/'k215-zr34-q50.native.tm').read_bytes()
  assert(out/'sites.json').read_bytes()==(HERE/'source/sites.json').read_bytes()
  transport=load(out/'source-transport.json');assert transport==load(HERE/'evidence/source-transport.json')
 assert transport['changed_leaf_addresses']==4525
 assert(transport['initial']['six_zero_leaf_paths'],transport['final']['six_zero_leaf_paths'])==(37,34)
 # Exact labelled graph comparisons, independently repeated from each pinned table.
 comparisons=load(HERE/'evidence/novelty.json')
 for name,item in comparisons.items():
  other=HERE/'parent.native.tm'if name=='parent'else HERE/'comparison'/f'{name}.native.tm'
  for key,filename in [('combined','k215-zr34-q50.native.tm'),('precursor','precursor.native.tm')]:
   result=graph.compare(HERE/filename,other);assert result==item[key]
   assert not result['rooted_labelled_graph_isomorphic'],name
 # Blank replay is independent of the symbolic runtime simulator.
 a=load(HERE/'evidence/precursor-startup.json.gz');b=load(HERE/'evidence/startup.json.gz')
 before=replay(P,a);after=replay(T,b);assert before==after
 db=dict(b);db['state']=m[b['state']];db['trace']=[[m[q],h,v,w,d,m[z]]for q,h,v,w,d,z in b['trace']]
 assert replay(dense,db)==(m[after[0]],after[1],after[2])
 i=j=contracted=0
 while i<len(a['trace']):
  e=a['trace'][i]
  if(e[0],e[2])==(50,0):
   h=e[1];assert a['trace'][i:i+3]==[[50,h,0,0,-1,75],[75,h-1,0,0,1,75],[75,h,0,0,1,75]]
   assert b['trace'][j]==[50,h,0,0,1,75];i+=3;j+=1;contracted+=1
  else:assert e==b['trace'][j];i+=1;j+=1
 assert(i,j,contracted)==(716307,712569,1869)
 assert(b['state'],b['head'],b['gap'],b['registers'],b['spares'])==(84,-9,152,[4,0,0,0,1,0,0,0,0],[1]*185)
 # Independently reconstruct every one-cell, including zero PC and zero exterior.
 phy=(6,2,0,4,3,7,8,5,1);physical=[None]*9
 for k,p in enumerate(phy):physical[p]=b['registers'][k]
 guard=b['head']-1;header=b['head']+64+b['gap'];ones={guard,header};pos=header+1
 for n in physical+b['spares']:
  pos+=1;ones.update(range(pos,pos+n+1));pos+=n+1
 assert(guard,header,len(ones))==(-10,207,386)and ones==after[2]
 assert min(ones)==guard and min(x for x in ones if x>guard)==header
 # Saved universal proof inventory, exact source order and all-natural durations.
 report=load(HERE/'evidence/runtime.json');cases=load(HERE/'evidence/runtime-cases.json.gz');sites=load(HERE/'source/sites.json')
 order=[(i,pos)for i,x in enumerate(sites)for pos in((False,True)if x[1]=='CD'else(False,))]
 assert order==[(x['site_index'],x['positive'])for x in cases]
 assert report['status']=='UNIVERSAL_MATHEMATICAL_PASS'and not report['failures']
 assert len(sites)==report['site_count']==4751
 assert len(cases)==report['proved_cases']==report['expected_cases']==6176
 assert sum(x['symbolic_steps']for x in cases)==1706554
 assert all(x['duration'][0]>0 and all(v>=0 for v in x['duration'])for x in cases)
 assert min(x['duration'][0]for x in cases)==6
 lm={int(k):int(v)for k,v in load(HERE/'checker/inputs/legacy_mapping.json').items()}
 for q in {q for q,b in T}|{254}:lm.setdefault(q,q+1000)
 used={tuple(row)for x in cases for row in x['rows']};assert used=={(lm[q],bit)for q,bit in T}
 assert report['table_sha256']==digest(HERE/'k215-zr34-q50.native.tm')
 assert report['sites_sha256']==digest(HERE/'source/sites.json')
 assert report['checker_sha256']==digest(HERE/'checker/runtime/symbolic_runtime.py')
 assert report['helper_sha256']==digest(HERE/'checker/runtime/independent_runtime.py')
 return {'status':'PASS','working_states':215,'rows':430,'changed_native_rows':16,'changed_source_addresses':4525,'primitive_cases':6176,'symbolic_rules':1706554,'all_rows_covered':True,'blank_steps':712569,'precursor_blank_steps':716307,'exact_boot_contractions':1869,'blank_steps_saved_from_precursor':3738,'guard':-10,'header':207,'unit_spares':185,'one_cells':386,'prior_rooted_graph_comparisons':len(comparisons),'scope':'Exact construction, source transport, whole-tape bootstrap, graph comparison and saved symbolic-evidence audit. --full regenerates all quantified primitive cases.'}

def main():
 if not __debug__ or sys.flags.optimize:raise RuntimeError('Assertions must be enabled')
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--full',action='store_true');ap.add_argument('--out',type=Path);a=ap.parse_args()
 result=audit()
 if a.full:
  if a.out is None:raise ValueError('--full requires --out NEW_DIRECTORY')
  a.out.mkdir(parents=True,exist_ok=False)
  subprocess.run([sys.executable,'-B',str(HERE/'checker/validate_native.py'),str(HERE/'k215-zr34-q50.native.tm'),str(HERE/'source/sites.json'),str(a.out)],check=True,timeout=600)
  report=load(a.out/'runtime.json');assert report['status']=='UNIVERSAL_MATHEMATICAL_PASS'and report['proved_cases']==report['expected_cases']==6176 and not report['failures']
  assert load(a.out/'startup.json')==load(HERE/'evidence/startup.json.gz')
  assert load(a.out/'runtime_cases.json')==load(HERE/'evidence/runtime-cases.json.gz')
  result['fresh_quantified_runtime']='PASS'
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
