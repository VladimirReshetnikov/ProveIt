#!/usr/bin/env python3
"""Literal replay of six closed source-DAG rotations and their decoder rewiring.

Python >=3.10; standard library only. Keep source_language.py beside this file.
Input hashes are pinned; output without --accelerate50 is also hash pinned.
The checker proves exact complete ordinal guarded-CFG equality and physical
prefix binding. Physical primitive refinement and blank startup are separate
certificates and are intentionally not inferred from this source check.
"""
from pathlib import Path
from collections import defaultdict
from functools import cache
import argparse,json,hashlib
import source_language as s
HALT=254
def need(x,m):
    if not x: raise ValueError(m)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read_table(raw):
    rows = {}
    starts = []
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(int(line[9:])); continue
        if not line or line.startswith('#'):
            continue
        q, b, w, d, target = line.split()
        q, b, w, target = map(int, (q, b, w, target))
        need((q, b) not in rows and b in (0, 1) and w in (0, 1) and d in ('L', 'R'), 'Bad table row')
        rows[q, b] = (w, 1 if d == 'R' else -1, target)
    need(starts == [0], 'Expected K-labelled start0')
    states = {q for q, b in rows}
    need(set(rows) == {(q, b) for q in states for b in (0, 1)}, 'Partial table')
    need({t for w, d, t in rows.values()} - states == {HALT}, 'Unexpected terminal state')
    return rows


def table_bytes(rows, start=0):
    return (f'#! start {start}\n' + ''.join(
        f'{q} {b} {w} {"R" if d == 1 else "L"} {target}\n'
        for (q, b), (w, d, target) in sorted(rows.items()))).encode('ascii')


def decoder_map(table, tree):
    """Read every internal-node prefix using only its actual known tape bits.

    The caller must also compare the returned q/subtree relation to the intended
    relation. Merely reaching an arbitrary state is not sufficient validation.
    """
    groups = defaultdict(set)
    paths = defaultdict(list)
    def visit(node, prefix, state):
        if s.leaf(node):
            return
        groups[state].add(node); paths[state].append(prefix)
        for bit in (0, 1):
            if s.leaf(node[bit]):
                continue
            tape = {i: int(value) for i, value in enumerate(prefix + str(bit))}
            tape[-1] = 1
            before = tape.copy()
            head, q = len(prefix), state
            for tick in range(100):
                if head == len(prefix) + 1:
                    break
                need(head in tape, 'Decoder read outside known prefix')
                w, d, q = table[q, tape[head]]
                tape[head] = w; head += d
            need(tape == before and head == len(prefix) + 1, 'Decoder prefix changed or did not advance')
            visit(node[bit], prefix + str(bit), q)
    visit(tree, '', 84)
    return groups, paths



BASE_TABLE = '9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2'
BASE_SOURCE = '17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba'
RESULT_TABLE = 'faf3c52e3b41587cd9b4707f91e0cd0423481e6ae53ca1118dcf7830ee87c6da'
RESULT_SOURCE = '9ef30a33fa40b6b4dca09266b98d57b1ed34828e63f112da1e2e8da63f5fb2c7'
ROTATIONS = [(135,221,0),(223,132,0),(78,100,0),(132,158,1),(223,132,1),(132,222,0)]


def transform(root, before, after):
    @cache
    def visit(node):
        if node == before: return after
        return node if s.leaf(node) else (visit(node[0]), visit(node[1]))
    return visit(root)


def source_stats(tree):
    rows=s.sites(tree)
    return dict(**s.metrics(tree),six_zero_leaf_paths=sum('000000' in p for p,op,a in rows),
                total_leaf_path_length=sum(len(p) for p,op,a in rows))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--table',type=Path,required=True)
    ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--accelerate50',action='store_true')
    a=ap.parse_args()
    raw_t=a.table.read_bytes();raw_s=a.source.read_bytes()
    need(sha(raw_t)==BASE_TABLE and sha(raw_s)==BASE_SOURCE,'Pinned input hash mismatch')
    table=read_table(raw_t);initial=dict(table);tree=s.tree(json.loads(raw_s));oldrows=s.sites(tree)
    oldword=[r[1:] for r in oldrows];oldgraph=s.graph_intervals(oldrows)
    need(s.graph_arithmetic(oldrows)[0]==oldgraph,'Parent CFG resolvers disagree')
    begin_stats=source_stats(tree);records=[]
    for stage,(q,z,d) in enumerate(ROTATIONS,1):
        groups,paths=decoder_map(table,tree)
        need(len(groups[q])==1,'Rotating state has multiple syntax roles')
        node=next(iter(groups[q]));need(not s.leaf(node[d]),'Missing internal middle child')
        A,B,C=(*node[0],node[1]) if d==0 else (node[0],*node[1])
        need(all(s.boundary(n)==(0,0,False)for n in(A,B,C)),'Nonclosed rotation factor')
        need(all(table[x,b][:2]==(b,1)for x in(q,z)for b in(0,1)),'Nonpure decoder row')
        need(table[q,d][2]==z and paths[z]==[p+str(d)for p in paths[q]],'Middle-state sharing mismatch')
        newnode=(A,(B,C)) if d==0 else ((A,B),C)
        newtree=transform(tree,node,newnode);newtable=dict(table)
        if d==1:
            aa,bb,cc=table[q,0][2],table[z,0][2],table[z,1][2]
            newtable[q,0]=(0,1,z);newtable[q,1]=(1,1,cc)
            newtable[z,0]=(0,1,aa);newtable[z,1]=(1,1,bb)
        else:
            aa,bb,cc=table[z,0][2],table[z,1][2],table[q,1][2]
            newtable[q,0]=(0,1,aa);newtable[q,1]=(1,1,z)
            newtable[z,0]=(0,1,bb);newtable[z,1]=(1,1,cc)
        actual,newpaths=decoder_map(newtable,newtree)
        expected={state:{transform(n,node,newnode)for n in ns}for state,ns in groups.items()}
        expected[q]={newnode};expected[z]={newnode[1-d]}
        need(dict(actual)==expected,'Complete decoder role relation mismatch')
        rows=s.sites(newtree)
        need([r[1:]for r in rows]==oldword,'Primitive word changed')
        need(s.graph_intervals(rows)==oldgraph==s.graph_arithmetic(rows)[0],'Complete guarded ordinal CFG changed')
        need(len(newtable)==430,'State count changed')
        records.append(dict(stage=stage,q=q,z=z,direction=d,paths=paths[q],
                            changed_rows=[[*k,*v]for k,v in sorted(newtable.items())if table[k]!=v],
                            prefix_count=sum(map(len,newpaths.values())),**source_stats(newtree)))
        table,tree=newtable,newtree
    result_t=table_bytes(table);result_s=s.compact(s.sites(tree))
    need(sha(result_t)==RESULT_TABLE and sha(result_s)==RESULT_SOURCE,'Pinned output hash mismatch')
    if a.accelerate50:
        need(table[50,0]==(0,-1,75)and table[75,0]==(0,1,75),'q50 acceleration precondition')
        table[50,0]=(0,1,75);result_t=table_bytes(table)
    a.output.mkdir(parents=True,exist_ok=False)
    (a.output/'candidate.native.tm').write_bytes(result_t)
    (a.output/'sites.json').write_bytes(result_s)
    finalrows=s.sites(tree)
    receipt=dict(status='EXACT_SOURCE_TRANSPORT_AND_PREFIX_PASS',
                 scope='Complete guarded ordinal CFG and primitive word equality, plus complete literal decoder prefix binding. Runtime and bootstrap are separate obligations.',
                 baseline_table_sha256=BASE_TABLE,baseline_source_sha256=BASE_SOURCE,
                 table_sha256=sha(result_t),source_sha256=sha(result_s),
                 unaccelerated_table_sha256=RESULT_TABLE,accelerate50=a.accelerate50,
                 states=len(table)//2,guarded_primitive_cases=sum(2 if op=='CD' else 1 for p,op,arg in finalrows),
                 changed_table_rows=[[*k,*v]for k,v in sorted(table.items())if initial[k]!=v],
                 changed_leaf_addresses=sum(p!=q for (p,*_),(q,*__)in zip(oldrows,finalrows)),
                 initial=begin_stats,final=source_stats(tree),rotations=records,
                 checker_sha256=sha(Path(__file__).read_bytes()),
                 source_language_sha256=sha(Path(s.__file__).read_bytes()))
    (a.output/'source-transport.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items()if k not in('rotations','changed_table_rows')},indent=2))


if __name__=='__main__':main()
