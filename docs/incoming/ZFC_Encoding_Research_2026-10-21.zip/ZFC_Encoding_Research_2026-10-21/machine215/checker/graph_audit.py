#!/usr/bin/env python3
"""Exact rooted labelled transition-graph comparison; no graph library."""
from pathlib import Path
from collections import deque,Counter
import json,hashlib

def table(path):
    t={};starts=[]
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):starts.append(int(line[9:]));continue
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z));assert (q,b)not in t and b in(0,1)and w in(0,1)and d in('L','R');t[q,b]=(w,1 if d=='R'else-1,z)
    working={q for q,b in t};assert len(t)==2*len(working)
    assert all((q,b)in t for q in working for b in(0,1))
    terminal={z for w,d,z in t.values()}-working;assert len(terminal)==1
    start=starts[0]if starts else 0;assert len(starts)<=1 and start in working
    return t,start,next(iter(terminal))

def canonical(t,start,halt):
    ids={start:0};paths={start:''};queue=[start]
    for q in queue:
        for b in(0,1):
            z=t[q,b][2]
            if z!=halt and z not in ids:ids[z]=len(ids);paths[z]=paths[q]+str(b);queue.append(z)
    assert set(ids)=={q for q,b in t},'All working states must be graph-reachable from start'
    ids[halt]=len(ids)
    rows=[(ids[q],b,w,d,ids[z])for q in queue for b in(0,1)for w,d,z in[t[q,b]]]
    return rows,ids,paths

def compare(candidate,other):
    a,sa,ha=table(candidate);b,sb,hb=table(other);ca,ma,pa=canonical(a,sa,ha);cb,mb,pb=canonical(b,sb,hb)
    result={'candidate_sha256':hashlib.sha256(Path(candidate).read_bytes()).hexdigest(),'comparison_sha256':hashlib.sha256(Path(other).read_bytes()).hexdigest(),'candidate_states':len(a)//2,'comparison_states':len(b)//2,'rooted_labelled_graph_isomorphic':ca==cb,'candidate_left_rows':sum(d==-1 for w,d,z in a.values()),'comparison_left_rows':sum(d==-1 for w,d,z in b.values()),'native_literal_row_differences':sum(a.get(k)!=b.get(k)for k in a.keys()|b.keys())}
    if ca!=cb:
        for i,(aa,bb)in enumerate(zip(ca,cb)):
            if aa!=bb:
                qa=next(q for q,j in ma.items()if j==aa[0]);qb=next(q for q,j in mb.items()if j==bb[0]);result['canonical_first_conflict']={'row_index':i,'candidate':list(aa),'comparison':list(bb),'candidate_native_state':qa,'comparison_native_state':qb,'candidate_access_word':pa[qa],'comparison_access_word':pb[qb]};break
    result['unrooted_isomorphism_excluded_by_direction_count']=result['candidate_left_rows']!=result['comparison_left_rows']
    return result

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('candidate',type=Path);p.add_argument('comparison',type=Path);a=p.parse_args();print(json.dumps(compare(a.candidate,a.comparison),indent=2))
