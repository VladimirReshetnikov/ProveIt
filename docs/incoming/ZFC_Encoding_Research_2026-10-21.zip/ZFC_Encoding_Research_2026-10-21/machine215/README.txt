K215-ZR34-q50: a distinct 215-state encoding with a shortened return scan
======================================================================

The complete binary blank-tape candidate is k215-zr34-q50.tm: working
states 0,...,214, initial 0, halt 215. The native table preserves inherited
labels, initial 0 and halt 254. Table SHA256:
016e81a555c9c5f34590d5f9f0c7740252c1d6c1d6bbe1959f34c9c7199b57a7
(native form). Source SHA256:
9ef30a33fa40b6b4dca09266b98d57b1ed34828e63f112da1e2e8da63f5fb2c7.

Construction and scope
----------------------
Starting from ProveIt K215 at commit ead95b5b336818a53c89b8c3d5249822e0570939,
replay six closed source-tree rotations with matching decoder rewiring,
then change native 50/0 from 0L75 to 0R75. This changes 16 transition rows and
4525 of 4751 instruction addresses, while retaining 202 source DAG nodes
and exactly the same complete guarded ordinal/register semantics. The
number of addresses containing six consecutive zeros changes 37→34; the
maximum zero run remains 6. Total address length increases 160305→163438.
This is a different physical encoding, not a new numerical calculus, a
214-state construction, or an overall speed improvement over the parent.

The combined table and its unaccelerated precursor are each nonisomorphic
as rooted labelled transition graphs to the pinned parent and six prior
215-state alternatives, including the published alternative reencoding,
rho6 sampler, wrapper, transfer-pop, zero-spare and commands120 machines.
The precursor comparison shows that the distinction is not solely the
single q50 direction change. No state-minimality or broad novelty claim
is made. Complete comparison tables and reproducible receipts are local.

Verified results
----------------
* A fresh all-natural runtime derivation proves 6176/6176 primitive cases,
  using 1706554 symbolic proof-construction rules. All 430 rows occur;
  actual-duration polynomials are positive (minimum constant 6).
* Quantifiers cover nine natural primary values at each guard, arbitrary
  natural gap, and every nonempty finite spare list, with zero exterior.
* Exact blank execution takes 712569 transitions to native dispatcher 84,
  head −9, guard −10, header 207, gap 152, registers
  (N,T,W,A,D,H,X,Y,L)=(4,0,0,0,1,0,0,0,0), and 185 unit spares.
  The complete tape has 386 one-cells and every other cell is zero.
* The unaccelerated six-rotation precursor takes 716307 steps to exactly
  the same entire configuration. Each of 1869 certified local contractions
  saves two steps, for 3738 steps saved from that precursor.
* The safe theorem-store invariant permits arbitrary additive counter D;
  seed-calibration.tex supplies the explicit soundness and cofinal strong
  compiler argument for the nonzero valueD=1.

Together with the inherited numerical-calculus/ZFC comparison theorem,
these ordinary mathematical arguments establish the same equivalence
between blank nonhalting and Con(ZFC). The evidence is executable symbolic
induction, not a new Lean/Rocq kernel-checked endpoint. The inherited
calculus theorem is a dependency, not reproved by finite simulation.

Reproduce
---------
  python3 -B verify.py

Reconstructs the exact source/table from six literal rewrites, checks both
complete guarded-CFG resolvers, native/dense bijection,215 graph-reachable
working states, all graph comparisons, every transition of both blank
traces, all 1869 contractions, the entire calibrated tape, and the stored
quantified proof inventory and exact byte bindings.

  python3 -B verify.py --full --out NEW_DIRECTORY

Additionally derives every arbitrary-natural primitive proof afresh with
the unchanged parent runtime checker and compares all cases and startup
with the supplied evidence. NEW_DIRECTORY must not exist. Python 3.10+
and the standard library suffice; no network, optimizer or search is used.
Assertions must be enabled. The default audits saved symbolic evidence;
--full reruns its construction. A fresh proof usually takes a few minutes.

proof.tex is the standalone mathematical note. It includes
seed-calibration.tex, row-changes.tex and full-table.tex from this directory.
comparison/ contains small pinned prior tables solely for novelty audit.
research/ contains the requested scoped negative214-state direct-merge
screen, not an impossibility theorem. Inherited notices are in licenses/.
