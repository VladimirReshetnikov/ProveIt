#!/usr/bin/env python3
"""Audit the exact q50 table, native/dense trace, and supplied runtime receipt.
Use --full --out NEW_DIRECTORY to rerun all quantified primitive proofs.
Python3.10+, standard library only. No network or solver is used.
"""
from pathlib import Path
import argparse,gzip,hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent

def load(path):
 p=Path(path)
 return json.loads(gzip.decompress(p.read_bytes())if p.suffix=='.gz'else p.read_bytes())
def table(path):
 d={}
 for line in Path(path).read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,b,w,move,z=line.split();q,b,w,z=map(int,(q,b,w,z))
  assert(q,b)not in d and b in(0,1)and w in(0,1)and move in('L','R')
  d[q,b]=(w,1 if move=='R'else-1,z)
 return d
def replay(T,record):
 q=h=0;ones=set()
 for e in record['trace']:
  assert e[:3]==[q,h,int(h in ones)]
  w,d,z=T[q,int(h in ones)];assert e[3:]==[w,d,z]
  if w:ones.add(h)
  else:ones.discard(h)
  q=z;h+=d
 assert len(record['trace'])==record['steps']
 assert(q,h,sorted(ones))==(record['state'],record['head'],record['one_cells'])
 return q,h,ones

def audit():
 manifest=load(HERE/'manifest.json')
 for name,digest in manifest.items():assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==digest,name
 old=table(HERE/'parent.native.tm');new=table(HERE/'k215-q50.native.tm');dense=table(HERE/'k215-q50.tm')
 assert old[50,0]==(0,-1,75)and old[75,0]==(0,1,75)
 expected=old.copy();expected[50,0]=(0,1,75);assert new==expected
 assert(sum(v[1]==-1 for v in old.values()),sum(v[1]==-1 for v in new.values()))==(82,81)
 working={q for q,b in new};assert len(working)==215 and len(new)==430
 assert all((q,b)in new for q in working for b in(0,1))
 assert{z for w,d,z in new.values()}-working=={254}
 seen={0};front=[0]
 while front:
  q=front.pop()
  for b in(0,1):
   z=new[q,b][2]
   if z!=254 and z not in seen:seen.add(z);front.append(z)
 assert seen==working
 m={int(k):v for k,v in load(HERE/'canonicalization.json')['native_to_dense'].items()}
 assert dense=={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in new.items()}
 a=load(HERE/'evidence/parent-startup.json.gz');b=load(HERE/'evidence/startup.json.gz')
 oldend=replay(old,a);newend=replay(new,b);assert oldend==newend
 denseb=dict(b);denseb['state']=m[b['state']];denseb['trace']=[[m[q],h,v,w,d,m[z]]for q,h,v,w,d,z in b['trace']]
 assert replay(dense,denseb)==(m[newend[0]],newend[1],newend[2])
 i=j=contractions=0
 while i<len(a['trace']):
  e=a['trace'][i]
  if e[0]==50 and e[2]==0:
   h=e[1];assert a['trace'][i:i+3]==[[50,h,0,0,-1,75],[75,h-1,0,0,1,75],[75,h,0,0,1,75]]
   assert b['trace'][j]==[50,h,0,0,1,75];i+=3;j+=1;contractions+=1
  else:assert e==b['trace'][j];i+=1;j+=1
 assert(j,contractions)==(len(b['trace']),659)
 assert(a['steps'],b['steps'])==(95714,94396)
 assert(b['state'],b['head'],b['gap'],b['registers'],b['spares'])==(84,-8,1,[4,0,0,0,0,0,0,0,0],[1]*40)
 # Reconstruct the entire calibrated tape independently, including zero exterior.
 phy=(6,2,0,4,3,7,8,5,1);physical=[None]*9
 for k,p in enumerate(phy):physical[p]=b['registers'][k]
 ones={-9,57};p=58
 for n in physical+b['spares']:
  p+=1;ones.update(range(p,p+n+1));p+=n+1
 assert ones==newend[2]
 report=load(HERE/'evidence/runtime.json');cases=load(HERE/'evidence/runtime_cases.json.gz');sites=load(HERE/'sites215.json')
 order=[(i,pos)for i,x in enumerate(sites)for pos in((False,True)if x[1]=='CD'else(False,))]
 assert order==[(x['i'],x['positive'])for x in cases]
 assert report['status']=='UNIVERSAL_MATHEMATICAL_PASS'and not report['failures']
 assert len(cases)==report['cases']==report['expected_cases']==6176
 assert sum(x['symbolic_steps']for x in cases)==report['symbolic_steps']==1683115
 assert all(x['duration'][0]>0 and all(v>=0 for v in x['duration'])for x in cases)
 lm={int(k):int(v)for k,v in load(HERE/'checker/inputs/legacy_mapping.json').items()}
 for q in working|{254}:
  if q not in lm:lm[q]=q+1000
 assert{tuple(x)for x in report['used_rows']}=={(lm[q],v)for q,v in new}
 assert report['table_sha256']==hashlib.sha256((HERE/'k215-q50.native.tm').read_bytes()).hexdigest()
 return {'status':'PASS','working_states':215,'rows':430,'primitive_cases':6176,'symbolic_rules':1683115,'blank_steps':94396,'blank_steps_saved':1318,'exact_boot_contractions':659,'all_rows_covered':True,'state_renaming_excluded_by_direction_census':True,'scope':'Exact artifact and saved-evidence audit; --full regenerates the quantified runtime evidence.'}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--full',action='store_true');p.add_argument('--out',type=Path);a=p.parse_args()
 r=audit()
 if a.full:
  assert a.out is not None,'--full requires --out NEW_DIRECTORY'
  a.out.mkdir(parents=True,exist_ok=False)
  proc=subprocess.run([sys.executable,'-B',str(HERE/'checker/validate_native.py'),str(HERE/'k215-q50.native.tm'),str(HERE/'sites215.json'),str(a.out)],check=True,timeout=600)
  rr=load(a.out/'runtime.json');assert rr['status']=='UNIVERSAL_MATHEMATICAL_PASS'and rr['proved_cases']==rr['expected_cases']==6176 and rr['working_states']==215 and not rr['failures']
  assert load(a.out/'startup.json')==load(HERE/'evidence/startup.json.gz')
  r['fresh_full_runtime']='PASS'
 print(json.dumps(r,indent=2))
if __name__=='__main__':main()
