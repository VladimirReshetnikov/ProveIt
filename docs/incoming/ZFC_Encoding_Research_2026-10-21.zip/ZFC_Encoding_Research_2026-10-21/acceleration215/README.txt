K215-q50: a context-certified acceleration of K215
=================================================

This bundle contains a complete 215-state, binary, blank-tape machine, its
unchanged source-site enumeration, exact bootstrap evidence, the copied
quantified runtime checker, and reproducibility scripts.  It is a modest
physical optimization.  It does not claim a 214-state construction or a
new consistency calculus.

Parent: VladimirReshetnikov/ProveIt, commit
  ead95b5b336818a53c89b8c3d5249822e0570939
  Computability/BusyBeaver/Research/ZFC/candidate-k215/k215.native.tm

Only change (native state labels):
  delta(50,0) = (0,R,75), formerly (0,L,75).
Every other transition is byte-semantically unchanged.  The source program,
register representation, spare policy, initial state 0, and halt state 254
are inherited.  The dense .tm file uses states 0,...,214 and halt 215.

Verification
------------
  python3 -B verify.py
checks the manifest, exact one-row edit, native/dense bijection, all 215
reachable working states, two independently replayed blank traces, all 659
three-to-one bootstrap contractions, the complete final tape, and the
saved runtime receipt.

  python3 -B verify.py --full --out fresh-verification
additionally regenerates all 6176 quantified primitive proofs with the
unmodified parent checker and replays the blank bootstrap.  The output
directory must not exist.  Python standard library only; no network.
The default audit checks saved evidence, while --full reruns the proof
construction.  Assertions must remain enabled.

Evidence scope
--------------
6176/6176 symbolic cases passed, using 1683115 proof-construction rules.
The arguments quantify over every natural register value and gap and
an arbitrary nonempty finite spare list; all 430 table rows are covered.
Proof rules are literal transitions, induction over unary natural-length
runs, and structural induction over arbitrary finite block lists.  They
are executable ordinary mathematical evidence, not a Lean/Rocq kernel
certificate.  The source-level ZFC-consistency reduction is inherited
from the cited parent construction; this bundle changes only its physical
implementation.

The blank bootstrap reaches exactly the same calibrated configuration as
the parent in 94396 steps instead of 95714, saving 1318 literal steps.
The final state is 84, head -8, guard -9, header 57, gap 1, logical registers
[4,0,0,0,0,0,0,0,0], and forty unit spare registers; every exterior cell is 0.
The direction census changes from 82 to 81 left-moving transition rows,
so the two tables cannot be related merely by a permutation of states.

See proof.tex for the local argument and its exact limits.  Inherited
licenses and source notices are in licenses/.  All paths are relative.
