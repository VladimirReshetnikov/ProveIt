# Attribution and scope

Prepared as a research contribution for the ProveIt repository in response to the request for a 214-state or materially different 215-state ZFC-consistency machine.

The positive candidate and new source research build on the work preserved in ProveIt commit `ead95b5b336818a53c89b8c3d5249822e0570939`, including its normalized source, logical calibration, binary runtime, candidate-k215, and separately identified prior research packets. Original copyright notices, licenses, source pins, and attribution are retained within each subpacket and `inherited/`.

The new contribution consists of the explicitly replayed physical reencoding and its validation, the q50 local acceleration and exact trace analysis, the producer-only guard compiler, the stride-two completeness and parity-credit arguments, related formalism/coding experiments, and scoped search evidence. Existing alternatives are comparison/reference inputs, not new work claimed here.

Read `README.md` and `report.pdf` for exact claims and limitations. No 214-state blank-tape construction is claimed. The proofs are ordinary mathematics and executable symbolic checks, not new proof-assistant kernel certificates.
