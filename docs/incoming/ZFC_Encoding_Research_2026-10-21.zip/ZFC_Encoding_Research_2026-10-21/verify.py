#!/usr/bin/env python3
"""Verify the frozen research archive; optionally rederive the main runtime.

Python 3.10+, standard library only. No network or external solver is used.
Default: hashes, exact construction/startup/graph audits, saved runtime inventory,
source/CFG audits, finite corroboration, and two fixed proof certificates.
--full additionally reconstructs all 6,176 quantified runtime cases for machine215.
The mathematical proof texts and inherited ZFC calibration are separate premises.
"""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys, tempfile

ROOT = Path(__file__).resolve().parent

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def manifest():
    data = json.loads((ROOT / 'MANIFEST.json').read_text())
    for entry in data['files']:
        name = Path(entry['path'])
        require(not name.is_absolute() and '..' not in name.parts, 'Unsafe manifest member')
        path = ROOT / name
        require(path.is_file(), 'Missing file: ' + str(name))
        require(path.stat().st_size == entry['bytes'], 'Wrong size: ' + str(name))
        require(hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256'],
                'Wrong hash: ' + str(name))
    return len(data['files'])

def verify(args, output):
    count = manifest()
    print('PASS: SHA-256 manifest (' + str(count) + ' files)', flush=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    steps = []
    commands = [
        ('machine215', [str(ROOT / 'machine215/verify.py')] +
         (['--full', '--out', str(output / 'fresh-runtime')] if args.full else [])),
        ('acceleration215', [str(ROOT / 'acceleration215/verify.py')]),
        ('formalism', [str(ROOT / 'formalism/verify.py'), '--output', str(output / 'formalism')]),
        ('research', [str(ROOT / 'research/verify_research.py'), '--output', str(output / 'research.json')]),
        ('physical-research', [str(ROOT / 'research/physical/audit.py')]),
    ]
    for name, command in commands:
        log = output / (name + '.log')
        with log.open('w') as stream:
            process = subprocess.run([sys.executable, '-B'] + command, cwd=ROOT,
                                     env=env, stdout=stream, stderr=subprocess.STDOUT)
        require(process.returncode == 0, name + ' failed; see ' + str(log))
        steps.append({'name': name, 'status': 'PASS', 'log': log.name})
        print('PASS: ' + name, flush=True)
    result = {'status': 'PASS', 'manifest_files': count,
              'fresh_main_quantified_runtime': bool(args.full), 'checks': steps,
              'scope': 'Artifact and source/certificate audits, exact blank replay; '
                       'main unbounded runtime is freshly regenerated only with --full. '
                       'No proof-assistant kernel certification or 214-state claim.'}
    (output / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

def main():
    require(__debug__ and not sys.flags.optimize, 'Run Python with assertions enabled; do not use -O.')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true', help='rederive all main quantified runtime cases')
    parser.add_argument('--out', type=Path, help='new directory for persistent logs and generated evidence')
    args = parser.parse_args()
    require(not args.full or args.out is not None, '--full requires --out NEW_DIRECTORY')
    if args.out is not None:
        output = args.out.resolve()
        output.mkdir(parents=True, exist_ok=False)
        verify(args, output)
    else:
        with tempfile.TemporaryDirectory(prefix='zfc-encoding-audit-') as temporary:
            verify(args, Path(temporary))

if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError, AssertionError) as error:
        print('FAIL: ' + str(error), file=sys.stderr)
        sys.exit(1)
