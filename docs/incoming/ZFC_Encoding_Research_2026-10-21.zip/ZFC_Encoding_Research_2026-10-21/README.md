# New encodings for ZFC consistency search

Research contribution for `ProveIt/Computability/BusyBeaver/Research/ZFC/`, 21 October 2026.

## Positive result and exact status

This packet supplies **K215-ZR34-q50**, a deterministic one-tape, two-symbol Turing machine with **215 working states**, a separately counted halt state, and the all-zero initial tape. Its ordinary mathematical proof establishes, using the pinned inherited numerical-calculus calibration,

> ZFC proves: this machine does not halt on the blank tape if and only if Con(ZFC).

**No 214-state blank-tape machine is claimed.** The positive machine is a different physical encoding of the inherited consistency search, with a fully transported source control-flow graph. It does not change the logical axiom system. The source-level producer-only guard and stride-two scheduler below have complete calibration arguments, but neither currently has an accepted compact physical blank-tape implementation.

The repository snapshot is pinned to commit `ead95b5b336818a53c89b8c3d5249822e0570939`:
https://github.com/VladimirReshetnikov/ProveIt/tree/ead95b5b336818a53c89b8c3d5249822e0570939/Computability/BusyBeaver/Research/ZFC

Read `report.pdf` for the complete report, or `machine215/proof.pdf` for the machine-specific argument and full transition-table appendix. The `.tex` sources are included.

## Delivered machine

| Property | Value |
|---|---:|
| Working states / binary transition rows | 215 / 430 |
| Source DAG nodes / primitive occurrences | 202 / 4,751 |
| Changed native transition rows relative to K215 | 16 |
| Changed source addresses | 4,525 of 4,751 |
| Quantified primitive cases proved | 6,176 of 6,176 |
| Symbolic proof-construction rules | 1,706,554 |
| Rows used by the complete primitive proofs | All 430 |
| Exact blank startup | 712,569 transitions |
| Start / halt in dense presentation | 0 / 215 |
| Start / dispatcher / halt in native presentation | 0 / 84 / 254 |

The canonical dense table is `machine215/k215-zr34-q50.tm`; the native table is `machine215/k215-zr34-q50.native.tm`. Both use one row per `(state, read_bit)`, written as `state read_bit write_bit direction next_state`. The native labels are sparse; the maximum label is not the state count.

Native table SHA-256:

```
016e81a555c9c5f34590d5f9f0c7740252c1d6c1d6bbe1959f34c9c7199b57a7
```

Source SHA-256:

```
9ef30a33fa40b6b4dca09266b98d57b1ed34828e63f112da1e2e8da63f5fb2c7
```

Six closed source-tree rotations preserve the ordered primitive word and its entire guarded ordinal CFG. They change the physical decoder layout. Both the precursor and final machine fail exact rooted labelled-graph isomorphism checks against K215 and six pinned prior alternatives. This proves a difference from those concrete tables, not a universal priority claim. The local q50 acceleration is separately audited and is not the sole reason the precursor differs.

The new startup is **longer than K215's 95,714 steps**. The rotations also increase total source-address length. There is no overall speedup claim. The q50 edit reduces this particular rotated precursor from 716,307 to 712,569 steps by exactly 1,869 certified three-to-one trace contractions.

At startup completion, the logical registers `(N,T,W,A,D,H,X,Y,L)` are `(4,0,0,0,1,0,0,0,0)`, with head −9, guard −10, header 207, gap 152, 185 unit spares, and 386 one-cells. The independent replay reconstructs the entire tape. The nonzero numerical parameter `D=1` is justified by a separate all-natural source theorem; it is not silently treated as zero.

## Two further compression ideas

### 1. Test falsity at its successful MP producer

Keep the entire inherited raw numerical calculus and its gated set-theory bundle. Replace guarded structural transfer by an unguarded operation `S(t,[x]w,d,h) = (h,w,d,x)`. A successful MP halts precisely when its newly produced consequent is 1; other successful cases return a normalized parameter/cache and do not push a dummy zero. Failed MP continues to produce truth and preserve its numerical counter.

The arbitrary-store refutation compiler is proved over all natural codes, including the aliases `I(0,0)=0` and `[0]0=0`. Exact source and guarded-CFG audits bind the proof to a source with **202 DAG nodes and 4,706 primitive occurrences**, 45 fewer leaves than K215. The current physical allocations remain unresolved or fail literal entry tests. No physical 215-state or 214-state claim is attached to this source.

See `formalism/proofs/producer_only_guard_proof.tex`, its standalone PDF, source, audits, and finite interface corroboration.

### 2. Enumerate every second candidate

A fixed universally halting command prefix has encodings cofinally in every residue class modulo any power of two. The proof uses the exact Cantor-pairing diagonal identity and the fact that `z(2z+1)` permutes residues modulo `2^k`. Thus the fresh-candidate counter can advance by two while retaining refutation completeness.

For the three-command transfer interpreter, a new parity-sensitive stack-credit proof handles arbitrary protected numerical tails: all odd-schedule prefixes have nonnegative structural balance, while the even schedule needs at most three credits. The explicit source has **202 DAG nodes, 4,776 primitive occurrences, and 6,210 guarded cases**. A folded 215-state physical table passes a finite primitive screen but fails every blank/one-bit starter in the specified screen. It is retained only as a rejected research artifact.

See `formalism/proofs/stride_two_calibration.tex`, its standalone PDF, exact source audits, and finite corroboration. The number-theoretic and credit arguments are unbounded mathematical proofs; their finite checks are corroboration, not substitutes.

## Other explored directions

- **Parity-first formula constructors:** a full raw-code algebra isomorphism, with truth 0 and falsity 1 retained. Implication and quantification become cheaper, but relation construction becomes more expensive: the measured source rises to 208 DAG nodes and 4,835 primitive occurrences. Numeric domination is reproved in the new algebra rather than presumed invariant under translation.
- **Successor MP:** eliminates a wire argument by generating the trial consequent from `d+1`. An arbitrary-store compiler is supplied; the measured transfer source has 203 DAG nodes. The investigated physical table is not a successful blank-tape machine.
- **Restricted classical schema:** an independently replayed 19-node condensed-detachment certificate derives identity, K, and Peirce from `L(I(V,U),B,C,U)`. Completeness, distribution, and the native zero specialization remain unresolved. Search failures are not nonderivability results.
- **A recovered 200-node source DAG:** exact replay preserves the transfer interpreter's 4,775 leaves and full guarded CFG, but maximum zero-run length rises from the supported six to eight. It is a source compression result without a physical table, not a 214-state machine.
- **Physical folding and initialization:** direct row-supplier merges, fixed spare-count variants, and bootstrap repair classes are recorded with their exact scope. They yield no accepted 214-state machine. None is a global lower bound.

## Reproduction

Use Python 3.10 or later, with assertions enabled. The accepted-machine and formalism checks need only the standard library. They do not use a network, solver, or proof assistant.

From the extracted top-level directory:

```bash
python3 -B verify.py
```

This verifies all frozen file hashes and runs:

1. Exact construction, full guarded source transport, graph comparisons, whole-tape blank replay, and saved quantified-runtime inventory for the main machine.
2. The independent original-layout q50 acceleration packet.
3. Source audits, finite interface/credit corroboration, constructor regeneration, and complete checks of the two fixed proof certificates.
4. Exact exploratory-source regeneration, recovery of the 200-node source, and literal rejection certificates for the producer218 allocation and all 645 stride215 starts. Historical annealing searches are not repeated.
5. Integrity and analytic-endpoint audits for the scoped physical-search packet, without repeating the expensive search screens.

The default audit does **not** regenerate the quantified runtime derivations. To regenerate all 6,176 main-machine primitive proofs:

```bash
python3 -B verify.py --full --out fresh-verification
```

The output directory must not exist. This takes a few minutes depending on hardware. It includes the default checks. Logs and all fresh evidence are kept in that directory.

The standalone machine command is:

```bash
python3 -B machine215/verify.py --full --out fresh-machine-runtime
```

To independently regenerate the original-layout acceleration proofs:

```bash
python3 -B acceleration215/verify.py --full --out fresh-acceleration-runtime
```

To rerun formalism audits and compile their three standalone proof PDFs:

```bash
python3 -B formalism/verify.py --output build/formalism-check --compile-pdfs
```

To compile the main report, run `pdflatex` twice from this directory:

```bash
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

A normal LaTeX installation is needed only for typesetting. Historical search programs may additionally require a C++ compiler or SciPy/HiGHS; they are not needed to verify the accepted candidate. See each research README before replaying a bounded search.

## Archive map

| Path | Contents |
|---|---|
| `report.tex`, `report.pdf`, `sections/` | Main report and full typesetting source |
| `machine215/` | New machine, source, exact recipe, proof, full table, traces, quantified checker and receipts |
| `acceleration215/` | Independent one-row acceleration of original K215 |
| `formalism/` | New command/scheduler proofs, alternate codec, certificates, source generators and audits |
| `research/` | Explicitly rejected tables and bounded search/allocation evidence |
| `inherited/` | Pinned proof dependencies, provenance, original notices and licenses |
| `MANIFEST.json` | SHA-256 and byte lengths of all frozen archive members except itself |
| `verify.py` | Top-level portable verification entry point |

## Trust boundary and attribution

This is an ordinary mathematical construction formalizable in ZFC. It is **not** a new Lean/Rocq exact-table kernel theorem, a proof of Con(ZFC), or an unconditional nonhalting proof. The inherited numerical calculus/ZFC equivalence is an explicit premise, supported by the included pinned proof expositions and prior certificates. The binary runtime is checked using literal transition rules and induction over arbitrary unary blocks and arbitrary finite block lists; the finite number of symbolic cases does not bound the natural register values.

Inherited material is attributed and licensed in the packet notices. New work is intended for incorporation into the ProveIt research directory. Original accepted alternatives are retained as comparison inputs and are not claimed as new constructions.
