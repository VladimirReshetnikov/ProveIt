# Inherited logical and source boundary

These are unmodified proof expositions and metadata from ProveIt commit `ead95b5b336818a53c89b8c3d5249822e0570939`. Exact repository paths and hashes appear in `provenance.json`. Original licenses and notices are retained in `licenses/`. The new report uses the inherited raw numerical calculus/ZFC calibration and the four-command strong compiler. It supplies a new source-CFG transport, binary runtime proof replay, and actual blank-seed calibration for the delivered table. These files are proof dependencies, not new work claimed by this contribution.
