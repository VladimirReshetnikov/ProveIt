# A 19-node abstract certificate for the reverse strict row

Use implication notation `a -> b`, with uniform substitution and modus ponens. Consider the single schema

    R = ((C -> U) -> (V -> U))
        -> (((V -> U) -> C) -> (B -> C)).

This is the Łukasiewicz row

    L(A,B,C,U) = ((C -> U) -> A) -> ((A -> C) -> (B -> C))

restricted to `A = V -> U`. In the usual numerical encoding `I(a,b)=4P(a,b)`, this choice satisfies `U < A` unless `V=U=0`. That exceptional native zero alias must be handled before treating the abstract schema as a calibrated strict numerical calculus.

The file `inputs/reverse_R/reverse_R_ID_K_P_certificate.json` contains exactly 19 formula nodes. Node 0 is a variable-renamed instance of R. Every later node lists earlier major and minor premises for condensed detachment. The goals are:

| Goal | Formula | Node |
|---|---|---:|
| ID | `a -> a` | 9 |
| K | `a -> (b -> a)` | 16 |
| Peirce | `((a -> b) -> a) -> a` | 18 |

The checker standardizes the minor premise's variables apart, unifies it with the major premise's antecedent using an occurs check, applies the resulting substitution to the consequent, and canonicalizes variable names. It verifies every listed edge and exact target formula. This is a finite derivation check of these three abstract schemata; each condensed-detachment step expands into uniform substitution and modus ponens.

The checker uses a recursive substitution implementation independently of the search program that found the certificate. The packet deliberately contains only the small fixed certificate and this checker.

These positive results do not establish the S schema, a complete implication basis, or equiconsistency with ZFC. No result is inferred from the failure of a bounded search to find another schema. In particular, the 19-node abstract certificate is not a certificate for the native zero-alias calculus or for a binary Turing machine.
