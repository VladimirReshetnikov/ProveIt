# Successor detachment with the three-command transfer-pop interpreter

This combines the new successor-MP rule with the already published transfer-pop command language. It is an ordinary source-level proof, separate from any particular physical allocation.

Use the same numerical state(t,w,d,h) and unchanged AX contract as step_mp_proof.md. Let M increment d to e=d+1, test I(t,e)=h, and return(e,[0]w,e,0) on success or(0,w,e,0) on failure. Let T be the actual composite old DROP;NIP;NIP: it halts if h=1 or t=1 and otherwise returns(h,v,d,x), where unP(w)=(x,v). This extra current-falsity guard is sound on safe runs and only adds early halts to the strong compiler contracts.

The new raw tags are T=0, M=1, AX(c;x,y)=[c+2,y,x]. Both T and M have one input field total. The calculus and AX batch remain unchanged.

## Structural macros

Put A0=AX(0;0,0) and H=A0;T^11. The inherited exact transfer calculation gives: H(t,[x]w,d,h) halts when t=1, and otherwise returns(t,w,0,x). Its first ten shifts test only nonfalsity constructor values. Its final shift tests saved t. This holds on every numerical store and preserves the entire old tape-encoded stack tail.

Define

    PUSH* = A0 ; T^9 ; M ; AX(1;0,0) ; H^10.

After A0;T^9 the state is(r8,[t]w,0,Q_d(h)). The displayed quantifier code has tag2. M compares a tag0 implication I(r8,1) with this tag2 cache, so it necessarily fails and returns(0,[t]w,1,0). AX(1;0,0) then has U=A=c=1 and gate0, resets d/h, and puts its ten safe entries (last saved0) above[t]w. Ten applications of H preserve the top0 and remove precisely those ten entries. Therefore PUSH* never halts and returns exactly(0,[t]w,0,0) for every(t,w,d,h). The old arbitrary t is protected beneath the prefix and never tested.

Define

    DISCARD* = M ; AX(1;0,0) ; H^10.

From(t,w,0,0), the first comparison I(t,1)=0 fails. The same zero-gate and ten-pop argument then gives(0,w,0,0), without a halt. Define J(n)=M^n, including empty J(0); as already proved, J(n)(0,w,0,0)=(0,w,n,0).

## Strong compiler

The contract is B_X(t,w,0,0) either halts or returns(X,w,0,0), for all natural t,w. For truth, use DISCARD*. The inherited transfer-pop axiom/compiler recipes now work with DISCARD*, PUSH* and J in place of their old definitions:

- Retained row j at(a,b,c),1<=j<=7:
  DISCARD*;AX(c;a,b);T^(j+1);H^(9-j).
- Dominated rho8(a,b,c,u),u<=a:
  DISCARD*;J(u);AX(c;a-u,b);T^9;H.
- Enabled full bundle(a,b,c):
  DISCARD*;AX(c;a,b);H^10.
- GEN of X at i:
  B_X;PUSH*;J(i);T;AX(i;0,0);T^10.

These counts follow the unchanged ten-entry AX prefix, not an informal list encoding assumption. In particular P(0,0)=0 and all zero cases remain valid by exact unpair(P(x,w))=(x,w).

For MP with consequent Y=0, use DISCARD* because0 is an axiom. For Y>0, write I=I(A,Y) and use

    B_I;PUSH*;B_A;PUSH*;J(Y-1);T;T;M;
    AX(Y;0,0);T^11.

Before J, the state is(0,[A,I]w,0,0). J sets d=Y-1 and leaves the formula fields/stack unchanged. The first T returns(0,[I]w,Y-1,A). The next T either halts when A=1 or returns(A,w,Y-1,I). M increments the counter toY and succeeds, yielding(Y,[0]w,Y,0). AX(Y;0,0) has gate0 and puts its nine generated rows and saved Y over the successful-MP zero. Eleven transfers either halt at Y=1 or leave exactly(Y,w,0,0). Thus the strong compiler holds by induction on the native derivation. The additional top guard of T can only cause earlier allowed halts; generated AX rows and the gate are never1.

A refutation block B_1;H halts. Prepending START_Y=AX(0;1,Y) resets d/h from any numerical work state, and the resulting initial candidate code P(2,P(Y,P(1,R))) is at leastY, where R is the fixed encoded refutation tail. Candidate success is cofinal above any cutoff. Every nonhalting candidate still drains its positive continuation cursor.

For precision, if F(fields,r) is right-nested Cantor pairing of the command fields above r, define the continuation encoding by tail([])=0 and tail(k::L)=1+F(fields(k),tail(L)). A new candidate executes its first command from F(fields(k),tail(L)), without that outer successor; only later positive cursors are decremented first. This is the inherited deterministic encoding convention.

## Protected arbitrary-tail startup with changed MP arity

The previous transfer-pop credit proof used field arities1,2,3. The new arities are1,1,3, so its MP recurrence must change; it is not literally the same parser. Let f be the right Cantor projection, R(0) empty, R(r)=W(r-1) for r>0. If unpair(n)=(a,y), the exact new recurrences are

    W(n)=T;R(y)             if a=0,
    W(n)=M;R(y)             if a=1,
    W(n)=AX;R(f(f(y)))      if a>=2.

Assign conservative balances T=-1,M=0,AX=10. An actual successful M adds a zero head, which the conservative count ignores. Let b(n) be total balance, B(k)=sum(n<k)b(n), g(0)=0,g(r)=b(r-1), and q(r)=g(r)+1. The same prefix-pullback lemma for f applies: f enumerates[0],[0,1],[0,1,2],..., so any nonnegative initial sums of q give nonnegative initial sums of q composed with f or f squared.

Here is a full verification that the diagonal proof survives. The first candidates remain W(0)=[T], W(1)=[M], W(2)=[T,T], giving B(0..3)=0,-1,-1,-3. Prove jointly that B(k)+k>=0 at completed candidate boundaries and every Cantor diagonal of index s>=2 is prefix-safe relative to its own beginning. On diagonal s, the first s-1 candidates begin AX at y=0,...,s-2. Their k-candidate total is

    10k+sum(y<k)g(f(f(y))) >= 9k,

by the pullback lemma applied to q; only earlier-index inequalities are used. During AX candidate y its continuation has at most f(f(y))<=y commands, so balance is at least9y+10-y>=0. After the AX portion the balance is at least9(s-1).

The next candidate starts M at y=s-1. Its NEW continuation is R(s-1), instead of R(f(s-1)). It has at most s-1 commands, so its entire prefix loss is still at most s-1. Thus the old lower bound8(s-1) remains valid without change. The last candidate starts T at y=s, and its continuation R(s) loses at most s, so every prefix is at least8(s-1)-1-s=7s-9>0. The full diagonal is therefore prefix-safe and ends nonnegatively. Since its starting B is at least-3 and every new candidate boundary has index>=3, this also gives B(k)+k>=0, closing the induction.

Consequently the infinite syntactic schedule from candidate0 has global conservative minimum-3. From cutoff1, the initial exceptional words M,T,T need credit2 and every later diagonal is prefix-safe; exact credit is therefore2. At a root with N=1, empty proof pointer, theorem current/cache, and ten explicit theorem heads above an arbitrary tail, at least eight protected theorem heads remain at every future command boundary. The same exact protected-wrapper proof applies to the composite T: its internal DROP adds a temporary theorem and its first old NIP removes it; the second removes the one guaranteed protected head.

This proves that the prior ten-head dirty-tail bootstrap remains semantically adequate for the changed parser, provided its physical/source prefix reaches the same partial AX frame. That exact binding and the complete binary runtime remain separate. Other finite-cutoff d(N) values from the old parser must be recomputed rather than copied.

## Evidence boundary

The command equations and diagonal argument above are all-natural mathematical proofs. A finite interface checker can corroborate bookkeeping but does not establish the native axiom semantics or replace these inductions. A lower source-DAG count alone does not establish a smaller state table, and a table needs its own complete startup and runtime proof.

## Optional cache-return success composition

A further compatible variant changes only the successful M return to(0,w,0,e), moving the consequent e to the cache and clearing d. Failure remains(0,w,e,0). The source proposal is the already known cache-return suffix (transfer numeric register D to cache H), combined here with successor parameter generation. J(n), DISCARD*, PUSH*, H, and every axiom/GEN compiler remain valid: their uses of M are forced failures, so they retain the same exact contracts.

For a positive MP conclusion Y, replace the strong compiler by

    DISCARD*;PUSH*;B_I;PUSH*;B_A;PUSH*;J(Y-1);T;T;M;T.

The first DISCARD*;PUSH* installs a literal protected zero over the arbitrary old stack. The two premise blocks and their PUSH* macros then produce(0,[A,I(A,Y),0]w,0,0). J and two transfers give(A,[0]w,Y-1,I(A,Y)), or halt when A=1. The successful M now returns(0,[0]w,0,Y). The final T halts when Y=1 and otherwise returns(Y,w,0,0). Thus the exact strong compiler survives. For Y=0 use DISCARD*. This variant no longer pushes a success zero at runtime; the compiler explicitly installs the one it later needs. The conservative M balance remains0, so the protected-tail proof above applies unchanged.

In the four-command language, the same cache-success variant has a simpler final restoration: after arranging its premises using the compiler in step_mp_proof.md, append DROP;NIP to successful M. DROP pushes current0 and makes Y current; NIP either halts at Y=1 or removes that zero and clears the cache. Again no AX cleanup is required. This is a separate candidate command contract; a source/table must explicitly bind whichever success convention it uses.

## Prior-work distinction

The recovered incoming packet ZFC_214_State_Investigation_2026-10-21 already contains a calibrated increment-DROP parameter-free MP interface and source search (research/source/increment-drop/increment_drop_compiler.tex). That work must receive credit for unary parameter generation by command repetition. The present construction differs by incrementing the MP command itself; its parameter-setting repetitions are forced failures and add no stack padding. Its combination with transfer-pop is available when DROP is not a primitive command at all. The prior transfer-pop compiler, protected-credit diagonal proof, and cache-return MP convention are separately inherited ingredients, with the changed MP-arity proof and new compiler compositions supplied here.
