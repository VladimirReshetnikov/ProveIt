# Successor detachment: eliminating the MP numeric reader

## Scope and inherited inputs

This is an ordinary all-natural proof for a new command interpreter obtained from the accepted K215 interpreter by replacing the MP numeric input read with one increment of register D. AX, its emitted numerical calculus, all gate conditions, DROP, NIP and the increasing outer proof search are unchanged. This result calibrates the changed source language; an allocated binary table still needs an exact source binding, complete runtime and blank initialization. No proof-assistant check or absolute novelty claim is made.

The inherited numerical calculus uses Cantor pairing P(a,b)=(a+b)(a+b+1)/2+b, implication I(a,b)=4P(a,b), truth0, falsity1, quantification Q_i(a)=4P(i,a)+2, the seven retained native rows, the exact gated theory bundle, and rho8(A,B,C,U) with U<=A. Its existing ordinary proof identifies derivability of1 with ZFC refutability. None of that calculus or calibration changes here.

Write [x]w=P(x,w). All equations below concern actual natural codes, including [0]0=0 and I(0,0)=0. They do not assume that stacks are injective cons lists with a separate nil tag.

## 1. Exact command contracts

A work state is (t,w,d,h), consisting of current theorem, paired stack, numeric parameter, and cached theorem. Let D denote DROP, N denote NIP, S denote the new successor-MP command, and A(c;x,y) denote AX.

- D(t,w,d,h)=(h,[t]w,d,h).
- N halts if h=1; otherwise, writing unP(w)=(u,v), it returns (t,v,d,u).
- S first sets e=d+1. If I(t,e)=h it returns (e,[0]w,e,0); otherwise it returns (0,w,e,0).
- A(c;x,y) sets U=d, A=d+x, B=h+y and C=c from its incoming state. It returns (g,[r1,r2,...,r8,Q_U(h),t]w,0,0), where each rj is the unchanged emitted native row, r8 is the dominated rho8 instance, and g is the exact native bundle when its gate permits it and0 otherwise. The gate fails when c=A or c=B.

Every emitted rj, Q_U(h), and g differs from1 by its outer numerical constructor tag, for all natural inputs. U<=A follows from x>=0. No formula decoding condition is imposed.

The command wire tags are unchanged: N=0, D=1, S=2, and AX uses fields [c+3,y,x]. S has no additional field. The old MP(x) consumed [2,x]; its new S replacement consumes only [2].

## 2. Soundness

Call a work state safe when t, h, and every successively decoded head of w are derivable in the unchanged dominated native calculus. The zero stack is safe because every repeated unpair of0 yields(0,0), and0 is truth.

D and nonhalting N only rearrange derivable codes. Successful S applies exact numerical modus ponens to t and I(t,d+1)=h; unsuccessful S returns truth. AX emits valid native rows and the theorem-only generalization Q_U(h), and either truth or an enabled native bundle. The numeric d has no theorem invariant. Thus every nonhalting command preserves safety, and a halt implies that1 was derivable. This covers every raw proof candidate, including malformed or undecodable formula codes.

## 3. Counter generation without an input field

For n>=0, let J(n)=S repeated n times, with J(0) empty. For every w,

    J(n)(0,w,0,0)=(0,w,n,0).

Indeed, at the j-th command, the new counter is j>=1. Its comparison is I(0,j)=0, which is false since P(0,j)>=j>0. Hence every command fails without pushing a stack cell. Induction proves the exact statement, including n=0. More generally the same failure behavior holds from (0,w,d,0), but only the displayed contract is needed.

Define

    Discard = S ; AX(1;0,0) ; N^10.

From every (t,w,0,0), S compares I(t,1) with0 and necessarily fails. AX then has U=A=c=1, so its gate is zero. Its nine new safe rows followed by saved current0 are popped by N^10. Therefore Discard returns exactly (0,w,0,0) and cannot halt. It does not inspect an old stack head or the original t.

## 4. Strong compiler contract

For every derivable code X, construct a finite block B_X such that on every natural t,w,

    B_X(t,w,0,0) either halts or returns (X,w,0,0).

This statement intentionally permits an early halt; in particular a block for X=1 may halt while cleaning up its temporary stack. Its exact preservation of w makes recursive proof compilation possible even over a protected stack containing arbitrary non-theorems.

Truth: use Discard. In particular whenever the requested conclusion is0, this block can be used irrespective of how that truth was derived.

Axiom selection: after Discard and J(U), AX(c;A-U,B) has exactly the desired inputs whenever U<=A. It returns g above a prefix [r1,...,r9,0], where r9=Q_U(0), followed by the protected old stack. For1<=j<=9,

    N^j ; D ; N^(11-j)

selects rj and restores the old stack exactly: the final pops remove the pushed g, the9-j unselected rows, and the saved0. All popped/tested temporary rows are safe. For retained rows1 through7 take U=0. For rho8 use its actual dominated U. Thus its block is

    Discard ; J(U) ; AX(c;A-U,B) ; N^8 ; D ; N^3.

A permitted bundle at(A,B,c) uses

    Discard ; AX(c;A,B) ; N^10.

It leaves the bundle current and restores zero counter/cache and the old stack.

Generalization: from B_X use

    B_X ; D ; J(i) ; N ; AX(i;0,0) ; N^9 ; D ; N^2.

Immediately before AX the state is(0,w,i,X). Hence U=A=c=i makes the gate0, and the ninth new row is exactly Q_i(X), constructed before the incoming cache is changed. The displayed suffix selects this row and restores(w,0,0). This includes i=0 and X=0.

Modus ponens with zero conclusion: if Y=0, use Discard. This is valid because0 is already an axiom; the premises of this particular derivation node need not be compiled. It avoids trying to reach0 by a strictly increasing counter operation.

Modus ponens with positive conclusion: suppose Y>0 and there are blocks B_A and B_I for A and I(A,Y). Use

    B_I ; D ; B_A ; D ; J(Y-1) ; N ; D ; N ; N ; S
    ; AX(Y;0,0) ; N^10 ; D ; N ; N.

If either recursive block halts, the result holds. Otherwise, before J(Y-1) the state is(0,[A,I(A,Y)]w,0,0). The next four commands after J give:

    (0,[A,I]w,Y-1,0)
       N -> (0,[I]w,Y-1,A)
       D -> (A,[0,I]w,Y-1,A)
       N -> (A,[I]w,Y-1,0), unless A=1 causes a halt
       N -> (A,w,Y-1,I).

Now S increments the counter toY and succeeds, returning(Y,[0]w,Y,0). The cleanup AX has U=A=c=Y and gate0. N^10 removes its nine generated rows and saved Y, leaving(0,[0]w,0,Y). DROP gives(Y,[0,0]w,0,Y); the two NIPs either halt when Y=1 or pop the two temporary zero entries and return(Y,w,0,0). This verifies every stack cell and cache test. The argument remains valid for A=0, I(0,0)=0, and w=0; the Y>0 branch itself cannot have I(A,Y)=0.

Structural induction on the finite numerical derivation proves the strong compiler. All repetition counts are finite numerical codes. The compiler is allowed to be extremely inefficient: repeated S may be far longer than one decoded parameter read, but proof-search runtime is not the machine state-count objective.

For precision, if F(fields,r) is right-nested Cantor pairing of the command fields above r, define the continuation encoding by tail([])=0 and tail(k::L)=1+F(fields(k),tail(L)). A new candidate executes its first command from F(fields(k),tail(L)), without that outer successor; only later positive cursors are decremented first. This is the inherited deterministic encoding convention.

## 5. Refutations and arbitrary candidate cutoffs

Given a derivation of1, append D;N;N to B_1. If B_1 halts early, the block already halts. Otherwise B_1 would return(1,w,0,0); DROP pushes1 and sets current0, the first NIP loads1, and the next NIP halts. No old stack cell is required.

The strong contract requires incoming d=h=0. A dummy prefix

    START_Y=AX(0;1,Y)

establishes those conditions from every numerical incoming work state, since every AX resets d and h. Its new current and stack need not be safe for this completeness argument: the strong block preserves the entire resulting stack and handles arbitrary current t. Soundness is separately applied only to the actual safe initial state and its safe descendants.

Let R be the finite positive continuation encoding of the fixed halting block. Initial candidate codes for START_Y followed by that block are

    P(3,P(Y,P(1,R))) >= Y.

The AX wire order is[c+3,y,x]; the displayed prefix has c=0,y=Y,x=1. Thus successful candidates occur above every finite cutoff. All nonhalting candidates drain: each positive continuation first decrements its cursor, and every Cantor projection read is at most the decremented cursor. The changed S reads fewer fields and does not invalidate this argument. All arithmetic macros terminate by their inherited elementary loop arguments.

Consequently increasing proof enumeration from the accepted safe K215 root with cutoff4 halts exactly when1 is derivable in the unchanged numerical calculus. By the inherited calibration, its halting is equivalent in ZFC to not Con(ZFC).

## 6. Exact implementation opportunity

The exact accepted source SHA-256 is17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba. In its210 command order, the old MP numeric read is the closed interval[4591,4605), consisting of14 primitive leaves. Replace that whole interval with CI4, one increment of numeric register D. The following MP comparison, success zero-push, failure behavior and AX gate code remain unchanged. This changes4751 primitive leaves to4738. Complete source edge/splice validation, physical allocation and universal binary runtime are independent tasks. The leaf reduction by itself is not a physical-state saving.

## 7. What this changes conceptually

The consequence parameter need not be decoded as a field of the proof certificate. It can instead be generated by repetition of the same instruction that later uses it. The zero case, which would obstruct a positive successor, is handled by the permanent truth axiom. The compiler protects both premises while the repetition burns through failed comparisons. This exact successor-MP construction was derived here. A subsequent check of the incoming packet ZFC_214_State_Investigation_2026-10-21 found an earlier increment-DROP parameter-free compiler, so unary parameter generation itself is prior work and is not claimed as new. The present change puts the increment in MP, generates parameters by failed comparisons without stack padding, separates the zero conclusion using truth, and also works when DROP has been removed entirely. Global priority over all repository experiments has not been established.
