# A corrected parity-and-Cantor constructor codec

## Mathematical result

Let P(a,b)=(a+b)(a+b+1)/2+b. Preserve all four constructors of the current native numerical calculus by defining

    I'(a,b) = 2P(a,b),
    Q'(i,a) = 2P(i+1,a)+1,
    R'(i,j) = 2P(0,2P(i,j))+1,
    E'(i,j) = 2P(0,2P(i,j)+1)+1.

Here R is the native membership constructor and E is native equality. Truth is0 and the designated refutation code remains1=R'(0,0). The earlier three-constructor proposal, with a single membership constructor and separate bottom1, would not directly transport the current native rows: it omitted equality and changed the role of R(0,0). This corrected version avoids those changes.

Every positive even code belongs uniquely to I'. For an odd n, unpair((n-1)/2)=(u,v). If u>0, n is Q'(u-1,v). If u=0 and v is even, unpair(v/2)=(i,j) gives n=R'(i,j). If u=0 and v is odd, unpair((v-1)/2)=(i,j) gives n=E'(i,j). Thus the four constructor images partition the naturals, with the single zero normalization I'(0,0)=0. Every constructor is injective and the images are pairwise disjoint.

For every positive constructor output, BOTH numerical arguments are strictly smaller than the output. For I', this follows from P(a,b)>=max(a,b) and 2P(a,b)>P(a,b) when P(a,b)>0. For Q', the outer pair contains i+1 and a; doubling and adding1 dominates both i and a. For R' and E', the nested pair and outer doubling dominate the original two arguments; the least R' value1 still strictly dominates its zero arguments. The decomposition above is therefore well-founded even when the same number is used as a formula code, a variable label, or both.

Consequently this raw constructor algebra is isomorphic to the usual four-tag algebra I=4P, R=4P+1, Q=4P+2, E=4P+3. Define h(0)=0 and, recursively on each positive old code,

    h(C(a,b)) = C'(h(a),h(b)).

The strict-child property makes h total. Define its inverse using the displayed new-code decomposition. Induction on the numerical argument proves that the maps are inverse. They fix0 and1, commute with every constructor, and preserve all equalities and disequalities. In particular they transport the code-as-label use Q_{R(A,B)} in growG and the simultaneous formula/label use of C in the private theory bundle. No separately sorted variable-renaming assumption is needed.

Finite proofs in the UNRESTRICTED native calculus transport in both directions by applying h or its inverse to every proof code and every parameter. MP, theorem GEN, all constructor-polynomial axiom instances, and the gate C!=A,B are preserved. The final refutation code1 is fixed. These effective finite-proof translations are formalizable in ZFC.

## The numerical domination restriction must be handled separately

h need not preserve numerical order. For example old2=Q(0,0) maps to3, whereas old4=I(1,0) maps to2. Thus old2<=4 becomes3>2. One must not transport the condition U<=A directly.

Instead, use the inherited3728-node certificate deriving unrestricted rho8 from dominated instances. The existing constructor-domination audit identifies each fourth argument as0, the first argument itself, or an implicational subterm of it. The inequality U<=A therefore holds independently in the new codec because every implication constructor weakly dominates its children, including the zero alias. The same certificate establishes equality of the dominated and unrestricted theorem sets separately in both algebras. Combining those two results with the unrestricted proof transport gives refutation equivalence for the actual dominated numerical calculi.

This reuses the prior constructor-transport argument and its explicit Source149 certificate. It is not a new proof of the underlying native-calculus/ZFC equivalence. With that inherited calibration, the corrected codec is equiconsistent with ZFC and its finite proof translations are formalizable in ZFC.

## Literal source construction and cost

The source experiment starts from accepted K215 source SHA256
17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba.
It adapts the prior `build_constructor_variants.py` workflow. Six equality intervals are first isolated, preserving the complete primitive word and every guarded edge. This normalization changes202 distinct DAG nodes to205 while retaining4751 leaves; its maximum zero run is10.

The constructor arithmetic uses the inherited pair-scale macro. Its initial unpair places the first constructor argument in scratch6 and retains the second in current register1. Its core clears its scratches and computes a scaled Cantor pair. Thus Q' inserts CI6 between the unpair and scale2 core, then increments the result. R' first computes2P(i,j), then applies the same scale2 core with first argument0, then increments. E' inserts one increment before that outer core as well. Each replacement is a closed source block.

|Constructor|Old primitives|New primitives|Occurrences|Contribution to leaf change|
|---|---:|---:|---:|---:|
|I|27|25|42|-84|
|Q|29|27|21|-42|
|R|28|40|12|+144|
|E|30|41|6|+66|

The resulting source has208 DAG nodes,4835 leaves,6332 guard cases, depth46 and maximum zero run10. Its SHA256 is
a91196bd614a18a9fd3c9200033cbe189d8b5406febc66266da4df4c00bc9bdd.
All42 implication constructors are changed, including MP's comparison construction. The builder checks both source CFG resolvers, all3268 retained outside guarded edges, and that no outside edge enters a replaced block's interior.

This is a source-only measurement. No physical allocation, complete binary runtime, startup theorem, proof-assistant certificate, smaller-state result, or lower bound is asserted for it. The normalization and chosen associations are part of the measurement; the numbers do not prove that every implementation of this codec must be larger.

## Prior-work comparison

The incoming `zfc214-research` report already proves a general constructor-transport theorem allowing junk generators and measures four-tag permutations, binary/ternary prefix tags, and nested Cantor tags. The corrected codec is an application of that existing theorem, with a concrete different constructor assignment. Its source-only measurement here is distinct from the recorded binary-Huffman source, which has I=2P, R=4P+1, Q=8P+3, E=8P+7 and216 nodes.

The pinned repository intake193 also records Source154's shifted-even codec I*=max(0,4P-2), Q*=4P. That codec deliberately shares code0 and needs a special semantic truth argument rather than a bijective transport. The present corrected codec has disjoint constructor images and a global algebra isomorphism. No global priority over all repository experiments is claimed.

References are the incoming `zfc214-research/sections/junk_constructors.tex`, `data/actual_calculus_inventory.md`, `code/build_constructor_variants.py`, `code/audit_constructor_domination.py`, and the pinned repository file `SetTheory/Cardinals/docs/reports/set-theory/zfc-closure-kernels/intake-193.md` at commit ead95b5b336818a53c89b8c3d5249822e0570939.
