# Portable formalism and source-calibration packet

This packet contains ordinary mathematical proofs and reproducible source-level experiments for the ProveIt ZFC consistency search. It is a supplement to the final machine report, not an independent certification of an exploratory binary table.

The repository baseline is pinned to commit `ead95b5b336818a53c89b8c3d5249822e0570939` of [VladimirReshetnikov/ProveIt](https://github.com/VladimirReshetnikov/ProveIt/tree/ead95b5b336818a53c89b8c3d5249822e0570939/Computability/BusyBeaver/Research/ZFC). Exact source files, the small shared source utility, constructor inputs, inherited finite-certificate inputs, and their notices are bundled. Reproduction needs Python 3 and its standard library; rebuilding the three PDFs additionally needs `pdflatex` with the packages named in their wrappers. No network access or original scratch directory is needed.

## Claim status

| Item | Established here | Separate or unresolved obligation |
|---|---|---|
| Initial parameter `D=1` | The original four-command K215 source is calibrated from `(N,T,W,A,D,H,X,Y,L)=(4,0,0,0,1,0,0,0,0)`. Soundness permits arbitrary natural `D`; a fixed AX reset supplies cofinal completeness. | The main machine report supplies the exact guarded source identity, quantified binary runtime, and blank-start certificate. |
| Producer-only falsity guard | An ordinary all-natural proof for direct transfer `S` and normalized, **no-push** MP success; exact source/CFG binding; finite interface corroboration. | No accepted 214- or 215-state binary implementation is claimed here. |
| Stride-two enumeration | Every fixed parser prefix has cofinal encodings in every dyadic residue class; both exact fetch rewrites implement stride two; a parity-sensitive protected-tail theorem handles the three-command interpreter. | Each physical implementation still needs its own runtime and startup certificates. A different continuation/flag source is not covered merely because it has the same intended scheduler. |
| Successor MP | All-natural strong compiler proofs for four-command and transfer interpreters, including zero consequent and optional cache-return cases; changed-arity protected credit proof; finite probes. | No binary state-count claim. Parameter generation by command repetition has explicit prior-work attribution. |
| Corrected parity codec | A raw constructor-algebra isomorphism; separate treatment of the numerical domination restriction using the bundled 3,728-node inherited certificate; a reproducible **208-DAG-node** source experiment. | This measured construction is not a state saving. No physical table, complete binary runtime, or lower bound is inferred from its source cost. |
| Reverse strict row `R` | A fixed 19-node abstract condensed-detachment certificate deriving identity, K, and Peirce. | S and full propositional completeness are not established. The native zero alias and strict domination calibration remain open. |

These results allow arbitrary numerical formula codes. The arguments do not add a well-formedness filter. The inherited comparison between the native dominated numerical calculus and ZFC is an explicit premise, supplied by the pinned ProveIt development. The packet checks the additional finite propositional dependency needed by the codec; it does not recheck the entire historical ZFC calibration in a proof assistant.

## Contents

- `proofs/nonzero_parameter_seed.tex`: include-only source theorem for the verified candidate's nonzero initial parameter.
- `proofs/producer_only_guard_proof.tex`: include-only producer-guard proof. Its exact success contract is `(Y,w,0,0)` for `Y != 1`, with no extra stack zero; it halts on `Y=1`.
- `proofs/stride_two_calibration.tex`: include-only stride theorem, parser embedding, and protected-tail proof.
- `proofs/*_standalone.tex` and matching `.pdf`: standalone wrappers and compiled versions of those three proofs. The include files require `amsmath` and `amssymb` and can be inserted directly into the main report.
- `proofs/step_mp_proof.md` and `proofs/step_mp_transfer_proof.md`: successor-MP proofs and exact interface conventions.
- `proofs/corrected_parity_codec.md`: codec proof, measured costs, and prior-work comparison.
- `proofs/reverse_R_certificate.md`: statement and exact limits of the small abstract certificate.
- `sources/`: exact old and changed structured source lists. `sources/k215/source_language.py` supplies tree operations and two independent CFG resolvers.
- `checks/`: finite source audits, finite certificate checkers, and finite corroboration programs. Their scope statements distinguish these uses.
- `inputs/source149/`: the minimal pinned 3,728-node certificate, both inherited checkers, provenance and licenses.
- `inputs/constructor/`: exact constructor-recognition inputs used by the generator.
- `inputs/reverse_R/`: the 19-node certificate.
- `generated/corrected_parity_split.json`: exact output of the corrected codec generator.
- `receipts/`: deterministic reference results. `source_costs.json` reports source metrics, never physical state counts.
- `provenance/`: current origins and verbatim inherited proof/attribution documents. Links inside historical documents retain their original repository context.
- `MANIFEST.json`: SHA-256 and byte length of every fixed packet member other than the manifest itself.

## One-command verification

From this directory run:

```sh
python3 verify.py
```

The command validates every manifest member, reruns both stride source audits, the producer source audit, the small reverse-R proof checker, both inherited propositional checkers and the domination audit, the codec generator, and the finite interface/scheduler probes. It compares every regenerated receipt with the bundled reference and checks that the regenerated codec source is byte-identical. Results go to `build/verification/verification.json` by default. A successful run reports `PASS` with an explicit scope statement.

This is **not an unbounded binary runtime checker** and is not a proof-assistant verification of the ordinary mathematical proofs. The 200,001 stride cases and 500,000 successor-parser cases corroborate those proofs; the all-natural conclusions come from the stated invariants and inductions. The finite proof certificates are checked by inspecting every listed inference, which establishes those fixed finite derivations.

To rerun the same checks and rebuild all three standalone PDFs:

```sh
python3 verify.py --compile-pdfs
```

To choose a different output directory:

```sh
python3 verify.py --output build/recheck
```

Individual checks can also be run directly:

```sh
python3 checks/audit_producer_source.py --reference sources/transfer201.sites.json --source sources/sharedmatch0_0.sites.json --output build/producer_source.json
python3 checks/audit_stride_source.py --old sources/transfer201.sites.json --source sources/transfer_original2.sites.json --language sources/k215/source_language.py --out build/stride_source.json
python3 checks/check_reverse_R.py --certificate inputs/reverse_R/reverse_R_ID_K_P_certificate.json --out build/reverse_R.json
python3 checks/audit_constructor_domination.py --source149 inputs/source149 --output build/domination.json
python3 generators/build_corrected_parity_codec.py --parent sources/k215 --inputs inputs/constructor --output build/codec
```

Create `build/` before these individual commands if it does not exist. The unified verifier creates its directories itself.

## Source identities and limits

| Exact source | SHA-256 |
|---|---|
| K215 reference | `17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba` |
| Accepted transfer reference | `05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922` |
| Producer-only guard | `fc9f915fd113eba4ac3b3ab49b5bacdf564344418f772ff1ebb660e4c2f240c5` |
| Stride two, restore increment | `044f5dddfeda13c3de40aa3d96566f694a9dca443157eee3ce9fb79b15c0ae09` |
| Stride two, copy rearrangement | `cd2fdf18bbcbe3ae85185b2dfe6d34488918c415da243c26d8a784303de46012` |
| Corrected parity codec | `a91196bd614a18a9fd3c9200033cbe189d8b5406febc66266da4df4c00bc9bdd` |

Only these exact source inputs are bound by the packaged source audits. In particular a continued-source/flag experiment is not proved by the stride theorem without an additional exact source argument. No conclusion is drawn from a finite nonhalting prefix. A smaller DAG, a finite source audit, and a successful bounded simulation each leave the complete physical runtime and blank-start obligations separate.

## Attribution

The research combines new proofs and source experiments with substantial existing ProveIt, Mira-Cult, Jeff Ketchersid and Andrew James Wade material. The incoming transfer-pop compiler, its protected-credit argument, the constructor-transport framework, and the dominated-row recovery certificate are inherited components. See `NOTICE.md`, `licenses/`, `provenance/inherited/`, and the separate Source149 provenance. No claim of global priority over all prior experiments is made.
