#!/usr/bin/env python3
"""Rerun the portable finite audits and certificate checks in this packet.

This does not check an unbounded binary runtime or certify the ordinary
all-natural proofs in a proof assistant. See README.md for the precise scope.
"""
import argparse,hashlib,json,os,subprocess,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True

def require(value,message):
    if not value:raise RuntimeError(message)

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path('build/verification'))
    parser.add_argument('--compile-pdfs',action='store_true')
    args=parser.parse_args()
    require(__debug__ and not sys.flags.optimize,'Do not run Python with -O: bundled checkers use assertions.')
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    for entry in manifest['files']:
        path=Path(entry['file'])
        require(not path.is_absolute() and '..' not in path.parts,'Unsafe manifest member')
        member=ROOT/path
        require(member.is_file(),'Missing packet member: '+str(path))
        require(member.stat().st_size==entry['bytes'] and digest(member)==entry['sha256'],
                'Manifest mismatch: '+str(path))
    print('PASS: manifest, {} fixed members'.format(len(manifest['files'])),flush=True)
    out=args.output if args.output.is_absolute() else ROOT/args.output
    out.mkdir(parents=True,exist_ok=True)
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    steps=[]
    def run(name,script,arguments,generated,reference):
        command=[sys.executable,script]+[str(x)for x in arguments]
        process=subprocess.run(command,cwd=ROOT,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (out/(name+'.log')).write_text(process.stdout)
        require(process.returncode==0,name+' failed; see '+str(out/(name+'.log')))
        actual=json.loads(generated.read_text())
        expected=json.loads((ROOT/reference).read_text())
        require(actual==expected,name+' produced a different receipt')
        steps.append({'name':name,'status':'PASS','receipt':str(generated.relative_to(out)),
                      'reference':reference,'receipt_sha256':digest(generated)})
        print('PASS: '+name,flush=True)
    run('producer_source','checks/audit_producer_source.py',[
        '--reference','sources/transfer201.sites.json','--source','sources/sharedmatch0_0.sites.json',
        '--output',out/'producer_source.json'],out/'producer_source.json','receipts/producer_source_audit.json')
    for short,source,reference in [
        ('stride_restore','transfer_original2.sites.json','stride_source_audit.json'),
        ('stride_copy','transfer_bias2.sites.json','stride_bias_source_audit.json')]:
        result=out/(short+'.json')
        run(short,'checks/audit_stride_source.py',[
            '--old','sources/transfer201.sites.json','--source','sources/'+source,
            '--language','sources/k215/source_language.py','--out',result],result,'receipts/'+reference)
    run('producer_interfaces','checks/check_producer_interfaces.py',[
        '--output',out/'producer_interfaces.json'],out/'producer_interfaces.json','receipts/producer_interfaces.json')
    run('successor_interfaces','checks/check_successor_interfaces.py',[
        '--output',out/'successor_interfaces.json','--candidates','500000'],out/'successor_interfaces.json','receipts/successor_interfaces.json')
    run('stride_credit','checks/check_stride_credit.py',[
        '--through','200000','--out',out/'stride_credit.json'],out/'stride_credit.json','receipts/stride_credit_check.json')
    run('reverse_R','checks/check_reverse_R.py',[
        '--certificate','inputs/reverse_R/reverse_R_ID_K_P_certificate.json','--out',out/'reverse_R.json'],
        out/'reverse_R.json','receipts/reverse_R_certificate_check.json')
    run('constructor_domination','checks/audit_constructor_domination.py',[
        '--source149','inputs/source149','--output',out/'constructor_domination.json'],
        out/'constructor_domination.json','receipts/constructor_domination.json')
    run('corrected_parity_codec','generators/build_corrected_parity_codec.py',[
        '--parent','sources/k215','--inputs','inputs/constructor','--output',out/'codec'],
        out/'codec/summary.json','receipts/corrected_parity_codec.json')
    require((out/'codec/corrected_parity_split.json').read_bytes()==(ROOT/'generated/corrected_parity_split.json').read_bytes(),
            'Regenerated codec source is not byte-identical')
    run('source_costs','checks/check_source_costs.py',[
        '--output',out/'source_costs.json'],out/'source_costs.json','receipts/source_costs.json')
    pdfs=[]
    if args.compile_pdfs:
        pdfdir=out/'pdfs';pdfdir.mkdir(exist_ok=True)
        for stem in ['producer_only_guard','stride_two','nonzero_parameter_seed']:
            tex=stem+'_standalone.tex'
            for iteration in range(2):
                command=['pdflatex','-interaction=nonstopmode','-halt-on-error','-output-directory='+str(pdfdir),tex]
                process=subprocess.run(command,cwd=ROOT/'proofs',env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
                (out/(stem+'_pdflatex_'+str(iteration+1)+'.log')).write_text(process.stdout)
                require(process.returncode==0,'PDF compilation failed for '+tex)
            target=pdfdir/(stem+'_standalone.pdf')
            require(target.is_file(),'PDF output missing: '+tex)
            pdfs.append({'file':str(target.relative_to(out)),'sha256':digest(target)})
            print('PASS: PDF '+stem,flush=True)
    result={'status':'PASS','manifest_members_checked':len(manifest['files']),'checks':steps,
            'codec_regenerated_byte_identically':True,'compiled_pdfs':pdfs,
            'scope':'Portable finite source/CFG audits, complete checks of two fixed finite proof certificates, source regeneration, and finite corroboration. This is not an unbounded binary-runtime checker, a proof-assistant check of the all-natural mathematical arguments, or a standalone proof of the inherited native-calculus/ZFC calibration.'}
    (out/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('PASS: all portable checks. See '+str(out/'verification.json'))

if __name__=='__main__':
    try:main()
    except (OSError,ValueError,RuntimeError,AssertionError) as error:
        print('FAIL: '+str(error),file=sys.stderr);sys.exit(1)
