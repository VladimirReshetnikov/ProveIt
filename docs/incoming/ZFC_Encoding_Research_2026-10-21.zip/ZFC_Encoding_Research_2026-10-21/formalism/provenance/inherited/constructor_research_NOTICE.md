# Attribution and status

Research prepared for Vladimir Reshetnikov and the ProveIt project, 21 October 2026.

This packet inherits the accepted K215 source, transition table and runtime checker from ProveIt commit `c8029f50d324910a36694c39a1e62f5720c36f4c`. The original compact numerical calculus and machine are attributed to Mira-Cult; upstream verification is attributed to Jeff Ketchersid and contributors; the compiler framework is attributed to Andrew James Wade. The inherited notices and licenses are retained without alteration under `licenses/`, including their historical dates and state-count claims. Those historical notices describe their own earlier submissions. The additional Source149 certificate has its own exact provenance and attribution under `data/source149/`.

The new research, prose, source variants, local runtime fold and supplementary checks were prepared for this request with ChatGPT. They are intended for incorporation in the user's repository. The new packet does not claim a completed blank-start machine with at most 214 working states or an exact-table Lean/Rocq theorem. Read `STATUS.json` and `report.pdf` before reusing any table. In particular, the 214-state runtime table has a proved outward ray from its specified blank start.
