# Notice and provenance

This research packet was prepared with ChatGPT for Vladimir Reshetnikov's ProveIt investigation on 2026-10-21. Its new contributions are the separately stated source-calibration arguments, source rewrites, finite checks and measured experiments. They inherit the native calculus, source representation, runtime framework, and prior compiler and certificate results identified in the proofs and README.

The upstream compact calculus and machine work is attributed in the inherited materials to Mira-Cult; upstream verification work to Jeff Ketchersid and contributors; and the register-machine/binary-machine compiler to Andrew James Wade. The ProveIt repository and the incoming transfer-pop and constructor research supply additional proofs and implementation artifacts. The original licenses and attribution documents have been retained without alteration.

- `licenses/LICENSE.ProveIt` and `licenses/LICENSE.Wade` are the inherited licenses.
- `licenses/NOTICE-normalized-source.txt` and `licenses/NOTICE-original245.txt` preserve source notices.
- `provenance/inherited/K215_NOTICE.md` identifies the pinned K215 composition.
- The transfer provenance documents and proof files are verbatim inherited dependencies, not new claims about the exploratory sources in this packet.
- `inputs/source149/provenance.json` pins every member of the inherited finite propositional certificate package.
- `provenance/inherited/constructor_research_NOTICE.md` and `junk_constructors.tex` preserve attribution and proof context for constructor transport.

The compact source utility is copied unchanged from the pinned K215 candidate. The constructor-domination audit is copied with only its default input path adapted to this packet. The corrected parity generator adapts the prior constructor-variant workflow to one measured assignment; its exact output and input identities are recorded. No historical binary acceptance statement is extended to a changed source without the separate obligations stated in README.md.
