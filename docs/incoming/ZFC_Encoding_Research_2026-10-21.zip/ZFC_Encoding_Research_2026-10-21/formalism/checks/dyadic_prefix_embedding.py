#!/usr/bin/env python3
"""Construct a dyadic tail class for a fixed fresh-candidate command prefix.

Example:
  python dyadic_prefix_embedding.py --commands '[[2,0,1],[1,1]]' --bits 5 --residue 7
The argument gives literal wire fields, not logical formula strings.
The mathematical proof is in dyadic_parser_completeness.tex.
"""
import argparse,json

def pair(a,b):return (a+b)*(a+b+1)//2+b

def inverse_pair_residue(a,target,bits):
    """A residue b modulo 2**(bits+1) forcing P(a,b)=target mod2**bits."""
    z=0
    target=(target+a+1)%(1<<bits)
    for j in range(bits):
        if ((target-z*(2*z+1))>>j)&1:z+=1<<j
    assert z*(2*z+1)%(1<<bits)==target
    return (2*z-a-1)%(1<<(bits+1))

def operations(commands):
    if not commands or any(not c or any(type(x)is not int or x<0 for x in c)for c in commands):
        raise ValueError('Each prefix command must have at least one natural field')
    result=[]
    for i,c in enumerate(commands):
        if i:result.append(('add',1))
        result.extend(('pair',a)for a in c)
    return result

def embed(commands,bits,residue):
    if bits<0:raise ValueError('bits must be nonnegative')
    ops=operations(commands);r=residue%(1<<bits);precision=bits
    for op,a in ops:
        if op=='add':r=(r-a)%(1<<precision)
        else:r=inverse_pair_residue(a,r,precision);precision+=1
    return r,1<<precision

def encode(commands,tail):
    for op,a in reversed(operations(commands)):
        tail=pair(a,tail)if op=='pair'else tail+a
    return tail

def main():
    p=argparse.ArgumentParser();p.add_argument('--commands',required=True);p.add_argument('--bits',type=int,required=True);p.add_argument('--residue',type=int,required=True);a=p.parse_args()
    commands=json.loads(a.commands);r,period=embed(commands,a.bits,a.residue)
    examples=[]
    for j in range(3):
        tail=r+j*period;n=encode(commands,tail)
        assert n%(1<<a.bits)==a.residue%(1<<a.bits)
        examples.append({'tail':tail,'candidate':n})
    print(json.dumps({'fixed_fields':commands,'bits':a.bits,'target_residue':a.residue%(1<<a.bits),'tail_residue':r,'tail_period':period,'examples':examples,'scope':'Constructive residue witness; no altered physical machine or strided protected-tail claim.'},indent=2))
if __name__=='__main__':main()
