#!/usr/bin/env python3
"""Finite compiler bookkeeping only; not a native-calculus or TM proof.
The three AX mocks satisfy the precise constructor-tag and batch interfaces.
HOLE(X) is a strong-compiler induction premise and HOLE(1) therefore halts.
The zero Cantor alias is represented explicitly by the lazy stack constructor.
"""
from dataclasses import dataclass
from pathlib import Path
import argparse,json,math
@dataclass(frozen=True)
class Pair:
    head:int
    tail:object

def p(a,b):return (a+b)*(a+b+1)//2+b

def unp(n):
    s=(math.isqrt(8*n+1)-1)//2;b=n-s*(s+1)//2;return s-b,b

def push(x,w):return 0 if x==w==0 else Pair(x,w)

def pop(w):return (w.head,w.tail)if isinstance(w,Pair)else unp(w)

def I(a,b):return 4*p(a,b)

def Q(i,a):return 4*p(i,a)+2

def AX(c,x,y):return ('A',c,x,y)

def M(x):return ('M',x)
S=('S',);A0=AX(0,0,0);H=[A0]+[S]*11;PUSH=[A0]+[S]*9+[M(0)]
DISCARD=[M(0)]

def J(u):return [M(u)]

def HOLE(x):return('H',x)

def rows(mode,d,h):return[4*(j+mode*11)for j in range(8)]+[Q(d,h)]

def execute(word,store,mode,kappa):
    t,w,d,h=store
    for cmd in word:
        if cmd[0]=='S':
            x,w=pop(w);t,h=h,x
        elif cmd[0]=='M':
            y=d+cmd[1]
            if I(t,y)==h:
                if y==1:return None
                t,w,d,h=y,w,0,0
            else:t,d,h=0,y,0
        elif cmd[0]=='A':
            _,c,x,y=cmd;aa,bb=d+x,h+y
            for x in reversed(rows(mode,d,h)+[t]):w=push(x,w)
            t=0 if c in(aa,bb)else 4*(mode+1);d=h=0
        elif cmd[0]=='H':
            assert d==h==0
            if cmd[1]==1:return None
            t=cmd[1]
        else:raise AssertionError(cmd)
    return(t,w,d,h)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    counts={key:0 for key in['H','PUSH','DISCARD','J','axiom','GEN','MP','producer_guard']}
    modes={'normalized_no_push':lambda y:0}
    for name,kappa in modes.items():
        for mode in range(3):
            for w in[0,1,2,4,9,push(1,4)]:
                for u in range(5):
                    assert execute(J(u),(0,w,0,0),mode,kappa)==(0,w,u,0);counts['J']+=1
                for t in range(4):
                    assert execute(DISCARD,(t,w,0,0),mode,kappa)==(0,w,0,0);counts['DISCARD']+=1
                    for d in range(3):
                        for h in range(3):
                            x,v=pop(w)
                            assert execute(H,(t,w,d,h),mode,kappa)==(t,v,0,x);counts['H']+=1
                            assert execute(PUSH,(t,w,d,h),mode,kappa)==(0,push(t,w),0,0);counts['PUSH']+=1
                    for i in range(4):
                        for X in range(5):
                            out=execute([HOLE(X)]+PUSH+J(i)+[S,AX(i,0,0)]+[S]*10,(t,w,0,0),mode,kappa)
                            assert out is None if X==1 else out==(Q(i,X),w,0,0)
                            counts['GEN']+=1
                    for aa in range(5):
                        for y in range(6):
                            word=[HOLE(I(aa,y))]+PUSH+[HOLE(aa)]+PUSH+[S,S,M(y)]
                            out=execute(word,(t,w,0,0),mode,kappa)
                            assert out is None if y==1 or aa==1 else out==(y,w,0,0)
                            counts['MP']+=1
                for j in range(1,8):
                    word=DISCARD+[AX(2,3,4)]+[S]*(j+1)+H*(9-j)
                    assert execute(word,(3,w,0,0),mode,kappa)==(rows(mode,0,0)[j-1],w,0,0);counts['axiom']+=1
                for t in range(4):
                    for y in range(5):
                        actual=execute([M(y)],(t,w,0,I(t,y)),mode,kappa)
                        assert actual is None if y==1 else actual==(y,w,0,0)
                        counts['producer_guard']+=1
                    assert execute([M(1)],(t,w,0,0),mode,kappa)==(0,w,1,0)
                    counts['producer_guard']+=1
    result={'status':'PASS','counts':counts,'success_parameter_conventions':list(modes),'AX_mock_interfaces':3,'scope':'Finite command bookkeeping with exact Q and safe AX constructor tags; HOLEs are induction premises. Does not implement the native emitter, prove calibration, verify the binary table, or replace the all-natural mathematical proof.'}
    a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
