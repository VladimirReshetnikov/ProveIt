#!/usr/bin/env python3
"""Exact finite source binding for the two producer-only macro changes.

This verifies all literals and all control-flow edges using two independent
address resolvers. The unbounded mathematical macro proof is in the companion
LaTeX file. Finite execution probes below only corroborate that proof.

Standard-library only. Supply the exact old transfer source and new source.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path

NEW_SHA = 'fc9f915fd113eba4ac3b3ab49b5bacdf564344418f772ff1ebb660e4c2f240c5'
REF_SHA = '05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922'


def need(c, m):
    if not c:
        raise ValueError(m)


def interval_graph(rows):
    ix = {p:i for i,(p,op,a) in enumerate(rows)}
    need(len(ix)==len(rows), 'duplicate paths')
    intervals = {}
    def visit(p):
        if p in ix:
            lo,hi=ix[p],ix[p]+1
        else:
            a,b=visit(p+'0'),visit(p+'1')
            need(a[1]==b[0], 'noncontiguous full binary tree')
            lo,hi=a[0],b[1]
        intervals[p]=(lo,hi)
        return lo,hi
    need(visit('')==(0,len(rows)), 'root interval')
    def target(p, bit, n):
        while p:
            b,p=p[-1],p[:-1]
            if b==bit:
                n-=1
                if not n:
                    return (intervals[p][1] if bit=='0' else intervals[p][0])%len(rows)
        return 0
    graph=[]
    for i,(p,op,a) in enumerate(rows):
        if op=='CI': ts=[(i+1)%len(rows)]
        elif op=='CD': ts=[target(p,'0',1),(i+1)%len(rows)]
        elif op=='CB': ts=[target(p,'0',a)]
        elif op=='CC': ts=[target(p,'1',a)]
        elif op=='CH': ts=[]
        else: raise ValueError(op)
        graph.append((op,a,ts))
    return graph


def binary_graph(rows):
    ix={p:i for i,(p,op,a) in enumerate(rows)}
    depth=max(map(len,ix))
    def locate(p):
        w=p+'0'*depth
        for j in range(1,depth+1):
            if w[:j] in ix:
                need('1' not in p[j:], 'stray successor suffix')
                return ix[w[:j]]
        raise ValueError('missing leaf')
    def inc(p):
        return '' if not p else format((int(p,2)+1)%(1<<len(p)),f'0{len(p)}b')
    def cut(p,bit,n):
        positions=[j for j,c in enumerate(p) if c==bit]
        return p[:positions[-n]] if len(positions)>=n else ''
    graph=[]
    for p,op,a in rows:
        if op=='CI': ts=[locate(inc(p))]
        elif op=='CD':ts=[locate(inc(cut(p,'0',1))),locate(inc(p))]
        elif op=='CB':ts=[locate(inc(cut(p,'0',a)))]
        elif op=='CC':ts=[locate(cut(p,'1',a))]
        elif op=='CH':ts=[]
        else:raise ValueError(op)
        graph.append((op,a,ts))
    return graph


def pairing(x,y):
    return (x+y)*(x+y+1)//2+y


def unpair(n):
    s=(math.isqrt(8*n+1)-1)//2
    y=n-s*(s+1)//2
    return s-y,y


def execute(graph,pc,registers,exit_pc):
    r=list(registers)
    for steps in range(1000000):
        if pc==exit_pc:return 'return',r,steps
        op,a,ts=graph[pc]
        if op=='CH':return 'halt',r,steps
        if op=='CI':r[a]+=1;pc=ts[0]
        elif op=='CD':
            if r[a]:r[a]-=1;pc=ts[1]
            else:pc=ts[0]
        else:pc=ts[0]
    raise ValueError('finite probe exceeded bound')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--reference',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args()
    raw=a.source.read_bytes();oldraw=a.reference.read_bytes()
    need(hashlib.sha256(raw).hexdigest()==NEW_SHA,'unexpected new source bytes')
    need(hashlib.sha256(oldraw).hexdigest()==REF_SHA,'unexpected reference source bytes')
    rows=json.loads(raw);old=json.loads(oldraw)
    need(len(rows)==4706 and len(old)==4775,'source sizes')
    g=interval_graph(rows);og=interval_graph(old)
    need(g==binary_graph(rows),'new two-resolver disagreement')
    need(og==binary_graph(old),'reference two-resolver disagreement')
    need(rows[:4670]==old[:4670], 'changed inherited prefix literal')
    need(rows[4686]==old[4696], 'changed common command exit')
    relocation={i:i for i in range(4671)}
    relocation.update({4696:4686,4697:4687})
    for i in list(range(4670))+[4696]:
        ni=relocation[i]
        op,reg,targets=og[i]
        need(g[ni]==(op,reg,[relocation[t] for t in targets]),f'prefix edge {i}')
    guard=[
        ('CD',4,[4674,4671]),('CI',1,[4672]),('CI',6,[4673]),('CC',3,[4670]),
        ('CI',5,[4675]),('CD',5,[4679,4676]),('CD',6,[4678,4677]),('CC',2,[4675]),
        ('CB',1,[4680]),('CD',6,[4685,4680]),('CD',5,[4682,4681]),('CC',1,[4680]),
        ('CD',6,[4684,4683]),('CC',2,[4680]),('CB',1,[4686]),('CH',None,[])]
    direct_s=[
        ('CD',1,[4689,4688]),('CC',1,[4687]),('CD',5,[4692,4690]),
        ('CI',1,[4691]),('CC',2,[4689]),('CD',2,[4700,4693]),
        ('CI',7,[4694]),('CD',6,[4696,4695]),('CB',1,[4699]),
        ('CD',7,[4699,4697]),('CI',6,[4698]),('CC',2,[4696]),
        ('CC',3,[4692]),('CD',7,[4703,4701]),('CI',2,[4702]),
        ('CC',2,[4700]),('CD',6,[0,4704]),('CI',5,[4705]),('CC',2,[4703])]
    need(g[4670:4686]==guard,'producer macro literals or successors')
    need(g[4687:4706]==direct_s,'direct S literals or successors')
    need([i for i,(op,_,_) in enumerate(g) if op=='CH']==[4685],'unexpected halt')
    need(g[4669]==('CB',1,[4686]),'failed comparison enters guard')
    need(g[4664]==('CD',6,[4670,4665]),'successful comparison entry')
    need([x[1:] for x in rows[4675:4685]]==[x[1:] for x in old[4660:4670]],'comparator word was not reused')
    need([x[1:] for x in rows[4692:4706]]==[x[1:] for x in old[4761:4775]],'unpair word was not reused')
    probes={'producer':0,'direct_S':0}
    for y in list(range(65))+[127,128,255,1024]:
        for w in [0,1,2,9,12345]:
            r=[7,0,w,11,y,0,0,13,17]
            status,out,_=execute(g,4670,r,4686)
            wanted=[7,y,w,11,0,0,0,13,17]
            need(out==wanted and status==('halt' if y==1 else 'return'), 'producer probe')
            probes['producer']+=1
    for w in list(range(129))+[255,256,1024]:
        for t in [0,1,2,17]:
            for h in [0,1,2,31]:
                r=[7,t,w,11,19,h,0,0,17]
                status,out,_=execute(g,4687,r,0)
                x,v=unpair(w)
                need(status=='return' and out==[7,h,v,11,19,x,0,0,17], 'S probe')
                probes['direct_S']+=1
    result={
        'status':'PASS','source_sha256':NEW_SHA,
        'reference_sha256':hashlib.sha256(oldraw).hexdigest(),
        'source_leaf_occurrences':len(rows),
        'two_cfg_resolvers_agree':True,
        'unchanged_prefix_and_exit_contracts':4671,
        'producer_success_span':[4670,4686],
        'direct_S_span':[4687,4706],
        'only_halt_ordinal':4685,
        'finite_probe_counts':probes,
        'scope':'Exact finite source/CFG binding plus corroborating finite natural-register probes. All-natural termination and macro semantics are established by the companion mathematical proof; no physical-TM or blank-start claim is made by this checker.'
    }
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
