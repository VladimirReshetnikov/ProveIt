#!/usr/bin/env python3
"""Finite command-interface corroboration, not a native-calculus or TM proof.
Three safe AX-row interfaces instantiate the exact assumed batch contract.
HOLE(X) denotes the induction hypothesis for a protected-stack theorem block.
Stack pairing is represented lazily so its huge integer need not be expanded;
the exceptional P(0,0)=0 case is normalized explicitly.
"""
import argparse, json, math
from dataclasses import dataclass
from pathlib import Path
@dataclass(frozen=True)
class Pair:
    head: int
    tail: object

def p(a,b): return (a+b)*(a+b+1)//2+b

def unp(n):
    s=(math.isqrt(8*n+1)-1)//2
    b=n-s*(s+1)//2
    return s-b,b

def push(a,b): return 0 if a==0 and b==0 else Pair(a,b)

def pop(w): return (w.head,w.tail) if isinstance(w,Pair) else unp(w)

def I(a,b): return 4*p(a,b)

def Q(i,x): return 4*p(i,x)+2

def ax(c,x,y): return ('AX',c,x,y)

M=('M',);T=('T',)
A0=ax(0,0,0)
H=[A0]+[T]*11
PUSH=[A0]+[T]*9+[M,ax(1,0,0)]+H*10
DISCARD=[M,ax(1,0,0)]+H*10

def J(n): return [M]*n

def hole(x): return ('HOLE',x)

def rows(mode,d,h):
    return [4*(j+mode*11) for j in range(8)]+[Q(d,h)]

def execute(word,s,mode,cache_success=False):
    t,w,d,h=s
    for command in word:
        op=command[0]
        if op=='T':
            if t==1 or h==1: return None
            u,w=pop(w)
            t,h=h,u
        elif op=='M':
            e=d+1
            if I(t,e)==h:
                if cache_success:t,d,h=0,0,e
                else:t,w,d,h=e,push(0,w),e,0
            else:t,d,h=0,e,0
        elif op=='AX':
            _,c,x,y=command
            aa,bb=d+x,h+y
            emitted=rows(mode,d,h)+[t]
            for v in reversed(emitted):w=push(v,w)
            t=0 if c==aa or c==bb else 4*(mode+1)
            d,h=0,0
        elif op=='HOLE':
            assert d==h==0
            t=command[1]
        else:raise AssertionError(op)
    return t,w,d,h

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--candidates',type=int,default=500000);a=ap.parse_args()
    counts={k:0 for k in ['J','H','PUSH','DISCARD','axiom_selection','GEN','MP','MP_cache','protected_credit_candidates','explicit_parser_words']}
    for mode in range(3):
        for w in [0,1,2,4,9,push(1,4)]:
            for n in range(9):
                assert execute(J(n),(0,w,0,0),mode)==(0,w,n,0);counts['J']+=1
            for t in range(4):
                assert execute(DISCARD,(t,w,0,0),mode)==(0,w,0,0);counts['DISCARD']+=1
                for d in range(3):
                    for h in range(3):
                        out=execute(H,(t,w,d,h),mode)
                        u,v=pop(w)
                        assert out is None if t==1 else out==(t,v,0,u)
                        counts['H']+=1
                        assert execute(PUSH,(t,w,d,h),mode)==(0,push(t,w),0,0);counts['PUSH']+=1
                for i in range(4):
                    for X in range(5):
                        word=[hole(X)]+PUSH+J(i)+[T,ax(i,0,0)]+[T]*10
                        out=execute(word,(t,w,0,0),mode)
                        assert out is None or out==(Q(i,X),w,0,0)
                        counts['GEN']+=1
                for A in range(5):
                    for Y in range(6):
                        if Y==0:word=DISCARD
                        else:word=[hole(I(A,Y))]+PUSH+[hole(A)]+PUSH+J(Y-1)+[T,T,M,ax(Y,0,0)]+[T]*11
                        out=execute(word,(t,w,0,0),mode)
                        assert out is None or out==(Y,w,0,0)
                        if Y>1 and A!=1:assert out==(Y,w,0,0)
                        counts['MP']+=1
                        if Y==0:cacheword=DISCARD
                        else:cacheword=DISCARD+PUSH+[hole(I(A,Y))]+PUSH+[hole(A)]+PUSH+J(Y-1)+[T,T,M,T]
                        cached=execute(cacheword,(t,w,0,0),mode,cache_success=True)
                        assert cached is None or cached==(Y,w,0,0)
                        if Y>1 and A!=1:assert cached==(Y,w,0,0)
                        counts['MP_cache']+=1
            for j in range(1,8):
                word=DISCARD+[ax(2,3,4)]+[T]*(j+1)+H*(9-j)
                assert execute(word,(3,w,0,0),mode)==(rows(mode,0,0)[j-1],w,0,0)
                counts['axiom_selection']+=1
    # Exact parser/balance for every candidate below the stated finite cutoff.
    count=a.candidates; b=[];m=[];cumulative=0;minimum=0;from1minimum=0;diagmin=0;diagtotal=0;diagonal=0;nexttri=1;checked_diagonals=0
    for n in range(count):
        tag,y=unp(n)
        if tag==0:delta=-1;r=y
        elif tag==1:delta=0;r=y
        else:delta=10;r=unp(unp(y)[1])[1]
        v=delta+(b[r-1] if r else 0)
        low=min(0,delta+(m[r-1] if r else 0))
        b.append(v);m.append(low)
        minimum=min(minimum,cumulative+low)
        if n>=1:from1minimum=min(from1minimum,cumulative+1+low)
        cumulative+=v
        if n>=3:assert cumulative>=-3
        assert cumulative+n+1>=0
        diagmin=min(diagmin,diagtotal+low);diagtotal+=v
        if n+1==nexttri:
            if diagonal>=2:
                assert diagmin>=0 and diagtotal>=0;checked_diagonals+=1
            diagonal+=1;nexttri=(diagonal+1)*(diagonal+2)//2;diagmin=0;diagtotal=0
    assert minimum==-3 and from1minimum==-2
    counts['protected_credit_candidates']=count
    def word(n):
        tag,y=unp(n)
        if tag==0:r=y;cmd='T'
        elif tag==1:r=y;cmd='M'
        else:r=unp(unp(y)[1])[1];cmd='AX'
        return [cmd]+(word(r-1) if r else [])
    for n in range(min(count,1000)):
        balance=0;lo=0
        for cmd in word(n):balance+= {'T':-1,'M':0,'AX':10}[cmd];lo=min(lo,balance)
        assert (balance,lo)==(b[n],m[n]);counts['explicit_parser_words']+=1
    result={'status':'PASS','counts':counts,'completed_diagonals_s_ge_2':checked_diagonals,'global_conservative_minimum':minimum,'cutoff_1_credit':-from1minimum,'AX_interfaces':3,'scope':'Finite interface and parser checks only. AX row models have safe constructor tags and exact Q, but do not implement the full native emitter. HOLEs are compiler induction premises. The separate ordinary induction proves the all-natural compiler/credit theorems. No binary runtime or calibration follows from these finite checks.'}
    a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
