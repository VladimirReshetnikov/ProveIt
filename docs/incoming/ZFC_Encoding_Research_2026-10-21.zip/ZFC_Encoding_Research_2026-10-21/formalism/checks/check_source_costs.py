#!/usr/bin/env python3
"""Recompute exact source sizes; no physical state-count inference."""
import argparse,hashlib,importlib.util,json
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args()
    spec=importlib.util.spec_from_file_location('packet_source_language',a.root/'sources/k215/source_language.py')
    s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
    results=[]
    for name in ['sources/k215/sites215.json','sources/transfer201.sites.json',
                 'sources/sharedmatch0_0.sites.json','sources/transfer_original2.sites.json',
                 'sources/transfer_bias2.sites.json','generated/corrected_parity_split.json']:
        raw=(a.root/name).read_bytes();rows=json.loads(raw)
        graph,guards=s.graph_arithmetic(rows)
        if graph!=s.graph_intervals(rows):raise ValueError('CFG disagreement: '+name)
        results.append({'file':name,'sha256':hashlib.sha256(raw).hexdigest(),
                        'metrics':s.metrics(s.tree(rows)),
                        'guarded_cases':sum(2 if op=='CD'else 1 for _,op,_ in rows),
                        'two_cfg_resolvers_agree':True})
    result={'status':'PASS','sources':results,
            'scope':'Exact finite source metrics and resolver agreement. A DAG node is not a Turing-machine state; no physical allocation or runtime follows from this census.'}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
