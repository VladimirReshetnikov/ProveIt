#!/usr/bin/env python3
"""Literal fetch-only rewrite and two-resolver CFG audit for stride-two sources.
The all-natural loop/command/schedule proofs are in stride_two_calibration.tex.
"""
import argparse,hashlib,importlib.util,json
from pathlib import Path

PINS={
 '05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922':'accepted transfer201',
 '17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba':'pinned primary K215'}

def require(x,m):
    if not x:raise ValueError(m)

def run(graph,pc,registers,end):
    r=list(registers)
    for n in range(100000):
        if pc==end:return r,n
        effect,targets=graph[pc]
        if effect[0]=='increment':r[effect[1]]+=1;pc=targets[0]
        elif effect[0]=='decrement':
            k=effect[1]
            if r[k]:r[k]-=1;pc=targets[1]
            else:pc=targets[0]
        elif effect[0]=='identity':pc=targets[0]
        else:raise ValueError('unexpected halt in fetch')
    raise ValueError('finite corroboration bound exceeded')

def main():
    p=argparse.ArgumentParser();p.add_argument('--old',type=Path,required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--language',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    spec=importlib.util.spec_from_file_location('stride_source_language',a.language);s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
    oldraw=a.old.read_bytes();newraw=a.source.read_bytes();oh=hashlib.sha256(oldraw).hexdigest();nh=hashlib.sha256(newraw).hexdigest()
    require(oh in PINS,'unrecognized reference source pin')
    old=json.loads(oldraw);new=json.loads(newraw);ot=s.tree(old);nt=s.tree(new)
    oldcopy=(('CD',0),(('CI',8),(('CI',6),('CC',3))))
    oldrestore=(('CI',0),(('CD',6),('CC',2)))
    require(s.subtree(ot,'010')==oldcopy and s.subtree(ot,'011')==oldrestore,'inherited fetch shape')
    explicit=s.replace(ot,'011',(('CI',0),oldrestore))
    bias=s.replace(ot,'010',(('CI',6),(('CD',0),(('CI',8),('CC',3)))))
    if nt==explicit:mode='extra_initial_restore_increment';end=10
    elif nt==bias:mode='copy_increment_before_zero_test';end=9
    else:raise ValueError('not one of the two exact fetch-only rewrites')
    og,oc=s.graph_arithmetic(old);ng,nc=s.graph_arithmetic(new)
    require(og==s.graph_intervals(old),'old resolver disagreement')
    require(ng==s.graph_intervals(new),'new resolver disagreement')
    if mode=='extra_initial_restore_increment':
        shift=lambda i:i if i<6 else i+1
        for i,(effect,targets) in enumerate(og):
            wanted=[shift(t)for t in targets]
            if i==2:wanted[0]=6
            require(ng[shift(i)]==[effect,wanted],f'CFG transport at old ordinal{i}')
        require(ng[6]==[['increment',0],[7]],'inserted increment')
        require(new[:6]==old[:6] and new[10:]==old[9:],'changed literal exterior')
    else:
        require(new[:2]==old[:2] and new[5:]==old[5:],'changed literal exterior')
        require(ng[2:6]==[[['increment',6],[3]],[['decrement',0],[6,4]],[['increment',8],[5]],[['identity'],[2]]],'biased copy CFG')
        for i in list(range(2))+list(range(6,len(old))):require(ng[i]==og[i],f'unchanged CFG ordinal{i}')
    fetchprobes=0
    for n in list(range(257))+[1024,4096]:
        regs=[n,17,42,0,11,7,0,0,0];out,_=run(ng,2,regs,end)
        require(out==[n+2,17,42,0,11,7,0,0,n],'fetch corroboration')
        fetchprobes+=1
    cursorprobes=0
    for n in range(8):
        for cursor in range(1,11):
            regs=[n,17,42,0,11,7,0,0,cursor];out,_=run(ng,0,regs,end)
            require(out==[n,17,42,0,11,7,0,0,cursor-1],'positive cursor corroboration')
            cursorprobes+=1
    report={'status':'PASS','mode':mode,'reference':PINS[oh],'reference_sha256':oh,'source_sha256':nh,'source_metrics':s.metrics(nt),'two_cfg_resolvers_agree':True,'guarded_cases':sum(2 if op=='CD'else 1 for _,op,_ in new),'all_command_bodies_unchanged':True,'fresh_fetch_finite_probes':fetchprobes,'positive_cursor_finite_probes':cursorprobes,'scope':'Exact finite source rewrite and complete CFG transport, plus finite corroboration. The companion loop invariants prove all-natural stride2 semantics. This is not a binary runtime or blank-start certificate.'}
    a.out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
