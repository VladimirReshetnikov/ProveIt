#!/usr/bin/env python3
"""Independent recursive-substitution checker for a fixed CD certificate.

This checks abstract formula-schema derivations. It does not by itself
handle the numerical zero alias or prove completeness of a strict native row.
"""
import argparse,json
from pathlib import Path

def freeze(t):return t if isinstance(t,int)else tuple(map(freeze,t))
def variables(t):return {t}if isinstance(t,int)else variables(t[0])|variables(t[1])
def shift(t,k):return t+k if isinstance(t,int)else(shift(t[0],k),shift(t[1],k))
def canonical(t):
    names={}
    def walk(t):
        if isinstance(t,int):
            if t not in names:names[t]=len(names)
            return names[t]
        return(walk(t[0]),walk(t[1]))
    return walk(t)
def detach(major,minor):
    if isinstance(major,int):raise ValueError('major is not an implication')
    minor=shift(minor,max(variables(major))+1);sub={}
    def apply(t):
        if isinstance(t,int):return apply(sub[t])if t in sub else t
        return(apply(t[0]),apply(t[1]))
    def unify(a,b):
        a,b=apply(a),apply(b)
        if a==b:return
        if isinstance(a,int):
            if a in variables(b):raise ValueError('occurs check')
            sub[a]=b
        elif isinstance(b,int):
            if b in variables(a):raise ValueError('occurs check')
            sub[b]=a
        else:unify(a[0],b[0]);unify(a[1],b[1])
    unify(major[0],minor)
    assert apply(major[0])==apply(minor)
    return canonical(apply(major[1]))
def main():
    p=argparse.ArgumentParser();p.add_argument('--certificate',type=Path,required=True);p.add_argument('--out',type=Path);a=p.parse_args()
    d=json.loads(a.certificate.read_text());ts=[]
    ax=canonical((((0,1),(2,1)),(((2,1),0),(3,0))))
    for i,node in enumerate(d['nodes']):
        t=freeze(node['formula']);parents=node['parents']
        if parents==['axiom']:
            assert i==0 and t==ax
        else:
            ma,mi=parents;assert 0<=ma<i and 0<=mi<i
            assert detach(ts[ma],ts[mi])==t,(i,'invalid condensed detachment')
        ts.append(t)
    expected={'ID':(0,0),'K':(0,(1,0)),'P':(((0,1),0),0)}
    for name,target in expected.items():assert ts[d['goals'][name]]==target
    r={'status':'PASS','nodes':len(ts),'goals':d['goals'],'scope':'Fixed abstract reverse-R derivations of identity,K,Peirce by uniform substitution and MP. No S proof, no complete strict native-calculus calibration, and no binary machine claim.'}
    if a.out:a.out.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps(r,indent=2))
if __name__=='__main__':main()
