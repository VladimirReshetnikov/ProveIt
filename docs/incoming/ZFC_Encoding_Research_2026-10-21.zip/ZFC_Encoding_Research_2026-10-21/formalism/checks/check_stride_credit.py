#!/usr/bin/env python3
"""Finite corroboration for the all-natural stride-two credit proof.

The proof in stride_two_calibration.tex, not this finite run, establishes
all diagonals and all candidate cutoffs. Standard library only.
"""
import argparse,json,math
from pathlib import Path
from dyadic_prefix_embedding import embed,encode

def right(n):
    s=(math.isqrt(8*n+1)-1)//2
    return n-s*(s+1)//2

def params(n):
    s=(math.isqrt(8*n+1)-1)//2;y=n-s*(s+1)//2
    return s-y,y

def explicit_word(n):
    """Literal sequential field reader, using a different unpair algorithm."""
    def unpair(v):
        s=0
        while v>s:v-=s+1;s+=1
        return s-v,v
    result=[]
    while True:
        a,r=unpair(n)
        if a==0:result.append(-1)
        elif a==1:
            result.append(0);_,r=unpair(r)
        else:
            result.append(10);_,r=unpair(r);_,r=unpair(r)
        if r==0:return result
        n=r-1

def aggregate(word):
    s=0;m=0
    for x in word:s+=x;m=min(m,s)
    return s,m

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--through',type=int,default=200000);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    nmax=a.through;b=[];mins=[];length=[]
    for n in range(nmax+1):
        aa,r=params(n)
        if aa==0:lead=-1
        elif aa==1:lead=0;r=right(r)
        else:lead=10;r=right(right(r))
        sb,sm,sl=(b[r-1],mins[r-1],length[r-1])if r else(0,0,0)
        b.append(lead+sb);mins.append(min(0,lead+sm));length.append(1+sl)
        assert length[-1]<=n+1
    explicit_count=min(2000,nmax+1)
    for n in range(explicit_count):
        w=explicit_word(n)
        assert aggregate(w)==(b[n],mins[n]) and len(w)==length[n]
    diagcount=0
    for s in range(2,nmax+1):
        lo=s*(s+1)//2;hi=(s+1)*(s+2)//2
        if hi>nmax+1:break
        for parity in [0,1]:
            running=0;minimum=0
            for n in range(lo,hi):
                if n%2==parity:
                    minimum=min(minimum,running+mins[n]);running+=b[n]
            assert minimum==0 and running>=0,(s,parity,minimum,running)
        diagcount+=1
    totals=[]
    for parity in [0,1]:
        running=0;minimum=0
        for n in range(parity,nmax+1,2):
            minimum=min(minimum,running+mins[n]);running+=b[n]
        totals.append({'parity':parity,'minimum_prefix':minimum,'final_balance':running})
    assert totals[0]['minimum_prefix']==-3 and totals[1]['minimum_prefix']==0
    cutoffs=[]
    for n in range(min(128,nmax)):
        s=(math.isqrt(8*n+1)-1)//2;end=max(3,(s+1)*(s+2)//2)
        value=minimum=0
        for j in range(n,end,2):minimum=min(minimum,value+mins[j]);value+=b[j]
        credit=-minimum
        fullv=fullm=0
        for j in range(n,nmax+1,2):fullm=min(fullm,fullv+mins[j]);fullv+=b[j]
        assert credit==-fullm
        cutoffs.append(credit)
    embeddings=0
    for commands in [[[0]],[[2,0,1]],[[2,0,1],[1,1]],[[0],[1,4],[0]]]:
        for bits in range(7):
            for residue in range(1<<bits):
                r,period=embed(commands,bits,residue)
                for j in [0,1,3]:assert encode(commands,r+j*period)%(1<<bits)==residue
                embeddings+=1
    result={'status':'PASS','candidate_range_inclusive':[0,nmax],'explicit_decoder_comparisons':explicit_count,'complete_diagonals_tested':diagcount,'parity_aggregates':totals,'finite_horizon_cutoffs_compared':len(cutoffs),'first_cutoff_credits':cutoffs[:16],'dyadic_prefix_residue_classes_checked':embeddings,'scope':'Finite corroboration only. The companion simultaneous induction proves all-natural parity prefix safety, and its modular argument proves all dyadic embeddings.'}
    a.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
