#!/usr/bin/env python3
"""Reproduce four stride-two scheduler source encodings from either pinned parent.

Standard library only; keep generate_producer_sources.py beside this file.
This verifies exact CFG resolution and a bounded arithmetic smoke test. The
all-natural scheduler lemma, global logical calibration, physical runtime and
blank-tape startup remain separate obligations.
"""
from pathlib import Path
import argparse,json,hashlib
import generate_producer_sources as s
PARENTS={
 '17af207195179b2508bf91154cd00739374f8862207ca21b9a3cb9098aa6f5ba':('four-command',202,4751),
 '05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922':('transfer',201,4775),
}
def smoke(root,delta):
 rows=s.sites(root);cfg=s.graph_intervals(rows);stop=s.size(s.subtree(root,'0'));maximum=0
 for n in range(101):
  r=[0]*9;r[0]=n;i=0;steps=0
  while i!=stop and steps<10000:
   op,arg=rows[i][1:];targets=cfg[i][1]
   if op=='CI':r[arg]+=1;i=targets[0]
   elif op=='CD':
    if r[arg]:r[arg]-=1;i=targets[1]
    else:i=targets[0]
   elif op in('CB','CC'):i=targets[0]
   else:raise AssertionError('Unexpected scheduler halt')
   steps+=1
  s.require(i==stop and r[0]==n+2 and r[8]==n+delta and r[6]==0,'Scheduler arithmetic smoke test failed')
  s.require(all(r[j]==0 for j in range(9)if j not in(0,8)),'Scheduler corrupted another register')
  maximum=max(maximum,steps)
 return dict(inputs=101,maximum_source_steps=maximum,not_an_unbounded_proof=True)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--input',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();raw=a.input.read_bytes();digest=s.sha(raw);s.require(digest in PARENTS,'Unrecognized parent source hash');label,dag,count=PARENTS[digest];old=s.tree(json.loads(raw));s.require(s.metrics(old)['dag_nodes']==dag and s.size(old)==count,'Parent metrics');s.require(s.subtree(old,'010')==(('CD',0),(('CI',8),(('CI',6),('CC',3)))),'Parent scheduler copy');s.require(s.subtree(old,'011')==(('CI',0),(('CD',6),('CC',2))),'Parent restore loop')
 a.output.mkdir(parents=True,exist_ok=False);records=[]
 copies=[('bias2',0,(('CI',6),(('CD',0),(('CI',8),('CC',3))))),('bias2b',1,(('CI',6),(('CI',8),(('CD',0),('CC',3))))),('bias2c',1,(('CI',8),(('CI',6),(('CD',0),('CC',3)))))]
 variants=[(name,delta,s.replace(old,'010',copy))for name,delta,copy in copies]
 variants.append(('original2',0,s.replace(old,'011',(('CI',0),s.subtree(old,'011')))))
 for name,delta,new in variants:
  rows=s.sites(new);s.require(s.graph_intervals(rows)==s.graph_arithmetic(rows)[0],'CFG disagreement');raw=s.compact(rows);(a.output/(name+'.sites.json')).write_bytes(raw);records.append(dict(name=name,sha256=s.sha(raw),cursor_offset=delta,**s.metrics(new),guarded_primitive_cases=sum(2 if op=='CD' else 1 for p,op,arg in rows),smoke=smoke(new,delta)))
 result=dict(status='SOURCE_ONLY',parent=label,parent_sha256=digest,generator_sha256=s.sha(Path(__file__).read_bytes()),records=records);(a.output/'manifest.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
