#!/usr/bin/env python3
"""Reproduce the producer-only falsity-test source family.

Usage: python generate_producer_sources.py --input transfer201.sites.json --output OUTPUT
       Add --optimize to reproduce the bounded 50-wide source-parenthesization search.

Python >=3.10, standard library only. The input is hash pinned. This program
checks source well-formedness and two independent exact control-flow resolvers.
It does NOT certify any physical Turing machine, startup, or consistency theorem.
The mathematical calibration and the physical runtime proof are separate artifacts.

Original inherited source-language utility attribution follows.
"""
# Source-language utilities excerpted from the pinned K225/K226 packet.
# Original file: baseline226/verification/reconstruct227.py.
# Used unchanged below for tree syntax, closure bounds and two CFG resolvers.
# Original attribution and MIT No Attribution notice are preserved in the
# vendored K224/K225 archives; this adaptation adds no source optimization.
from __future__ import annotations
from collections import Counter
from functools import cache
from pathlib import Path
import argparse
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
START, DISPATCH, HALT = 95, 96, 254


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def compact(data):
    return (json.dumps(data, separators=(',', ':')) + '\n').encode('ascii')


def dump(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def leaf(node):
    return isinstance(node[0], str)


def tree(rows):
    root = {}
    for path, op, arg in rows:
        require(path and set(path) <= {'0', '1'}, 'Invalid source path')
        require(op in ('CI', 'CD', 'CB', 'CC', 'CH'), 'Invalid opcode')
        require((op == 'CH' and arg is None) or
                (op != 'CH' and type(arg) is int and arg >= 0), 'Invalid operand')
        require(op not in ('CI', 'CD') or arg < 9, 'Invalid register')
        require(op not in ('CB', 'CC') or arg >= 1, 'Invalid control depth')
        at = root
        for bit in path:
            require('instruction' not in at, 'Overlapping source paths')
            at = at.setdefault(bit, {})
        require(not at, 'Duplicate or overlapping source path')
        at['instruction'] = (op, arg)
    def visit(node):
        if 'instruction' in node:
            require(set(node) == {'instruction'}, 'Leaf has children')
            return node['instruction']
        require(set(node) == {'0', '1'}, 'Source tree is not full')
        return visit(node['0']), visit(node['1'])
    result = visit(root)
    require(sites(result) == rows, 'Source rows are not in canonical ordinal order')
    return result


def sites(node, prefix=''):
    if leaf(node):
        return [[prefix, *node]]
    return sites(node[0], prefix + '0') + sites(node[1], prefix + '1')


@cache
def boundary(node):
    if leaf(node):
        op, arg = node
        if op == 'CD': return 1, 0, False
        if op == 'CB': return arg, 0, False
        if op == 'CC': return 0, arg, False
        return 0, 0, op == 'CH'
    a, b = boundary(node[0]), boundary(node[1])
    return (max(max(a[0] - 1, 0), b[0]),
            max(a[1], max(b[1] - 1, 0)), a[2] or b[2])


def metrics(root):
    seen = set()
    def visit(node):
        if node in seen: return
        seen.add(node)
        if not leaf(node):
            visit(node[0]); visit(node[1])
    visit(root)
    rows = sites(root)
    return {'dag_nodes': len(seen), 'leaf_occurrences': len(rows),
            'maximum_depth': max(len(p) for p, _, _ in rows),
            'maximum_zero_run': max(len(z) for p, _, _ in rows for z in p.split('1'))}


def graph_arithmetic(rows):
    """Binary successor/cut resolver, including the no-stray-suffix premise."""
    leaves = {p: i for i, (p, _, _) in enumerate(rows)}
    depth = max(map(len, leaves))
    checks = 0
    def locate(prefix):
        nonlocal checks
        word = prefix + '0' * depth
        for length in range(1, depth + 1):
            if word[:length] in leaves:
                require('1' not in prefix[length:], 'Stray one beyond successor leaf')
                checks += 1
                return leaves[word[:length]]
        raise ValueError('Successor has no leaf')
    def increment(path):
        if not path: return ''
        return format((int(path, 2) + 1) % (1 << len(path)), '0' + str(len(path)) + 'b')
    def cut(path, edge, level):
        positions = [i for i, bit in enumerate(path) if bit == edge]
        return path[:positions[-level]] if len(positions) >= level else ''
    graph = []
    for path, op, arg in rows:
        if op == 'CI':
            effect, targets = ['increment', arg], [locate(increment(path))]
        elif op == 'CD':
            effect = ['decrement', arg]
            targets = [locate(increment(cut(path, '0', 1))), locate(increment(path))]
        elif op == 'CB':
            effect, targets = ['identity'], [locate(increment(cut(path, '0', arg)))]
        elif op == 'CC':
            effect, targets = ['identity'], [locate(cut(path, '1', arg))]
        else:
            effect, targets = ['halt'], []
        graph.append([effect, targets])
    require(locate('') == 0, 'Initial ordinal leaf is not zero')
    return graph, checks


def graph_intervals(rows):
    """Independent resolver: subtree intervals and outward ancestor walking."""
    indices = {path: i for i, (path, _, _) in enumerate(rows)}
    intervals = {}
    def visit(path):
        if path in indices:
            answer = indices[path], indices[path] + 1
        else:
            a, b = visit(path + '0'), visit(path + '1')
            require(a[1] == b[0], 'Noncontiguous source subtree')
            answer = a[0], b[1]
        intervals[path] = answer
        return answer
    require(visit('') == (0, len(rows)), 'Source interval census')
    def unwind(path, edge, count):
        while path:
            last, path = path[-1], path[:-1]
            if last == edge:
                count -= 1
                if count == 0:
                    return intervals[path][1] % len(rows) if edge == '0' else intervals[path][0]
        return 0
    graph = []
    for i, (path, op, arg) in enumerate(rows):
        after = (i + 1) % len(rows)
        if op == 'CI':
            effect, targets = ['increment', arg], [after]
        elif op == 'CD':
            effect, targets = ['decrement', arg], [unwind(path, '0', 1), after]
        elif op == 'CB':
            effect, targets = ['identity'], [unwind(path, '0', arg)]
        elif op == 'CC':
            effect, targets = ['identity'], [unwind(path, '1', arg)]
        else:
            effect, targets = ['halt'], []
        graph.append([effect, targets])
    return graph


def subtree(root, path):
    for bit in path:
        require(not leaf(root), 'Stage path extends past a leaf')
        root = root[int(bit)]
    return root


def replace(root, path, node):
    if not path: return node
    bit = int(path[0]); children = list(root)
    children[bit] = replace(children[bit], path[1:], node)
    return tuple(children)




PINNED_SOURCE_SHA256 = '05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922'


def node_set(root):
    result = set()
    def visit(n):
        if n in result: return
        result.add(n)
        if not leaf(n):
            visit(n[0]); visit(n[1])
    visit(root)
    return result


def size(root):
    return 1 if leaf(root) else size(root[0]) + size(root[1])


def producer_sources(old):
    """Literal closed macro replacements; exact loops are reused from the parent."""
    clear_t = (('CD', 1), ('CC', 1))
    move_h_to_t = (('CD', 5), (('CI', 1), ('CC', 2)))
    unpair_w_to_h = subtree(old, '111111')
    compare_h_x = subtree(old, '11010110')
    copy_d_to_t_x = subtree(old, '1101011110')
    require(size(unpair_w_to_h) == 14 and boundary(unpair_w_to_h) == (0, 0, False),
            'Pinned direct-S unpair macro')
    require(size(compare_h_x) == 10 and boundary(compare_h_x) == (1, 0, False),
            'Pinned equality comparator')
    require(copy_d_to_t_x == (('CD', 4), (('CI', 1), (('CI', 6), ('CC', 3)))),
            'Pinned four-leaf consuming copy')
    halt_if_equal = (compare_h_x, ('CH', None))
    before = (copy_d_to_t_x, (('CI', 5), halt_if_equal))
    after = ((copy_d_to_t_x, ('CI', 5)), halt_if_equal)
    for shape in (0, 1):
        direct_s = ((clear_t, move_h_to_t), unpair_w_to_h) if shape == 0 else (clear_t, (move_h_to_t, unpair_w_to_h))
        for j, success in enumerate((before, after, before)):
            new = replace(replace(old, '111', direct_s), '11010111', success)
            yield f'sharedmatch{shape}_{j}', new
    direct_s = ((clear_t, move_h_to_t), unpair_w_to_h)
    for j, success in enumerate(((('CI', 5), (copy_d_to_t_x, halt_if_equal)),
                                 ((('CI', 5), copy_d_to_t_x), halt_if_equal), after)):
        new = replace(replace(old, '111', direct_s), '11010111', success)
        yield f'sharedcommute{j}', new


def closed_atoms(n):
    if leaf(n): return [n]
    if all(boundary(ch)[:2] == (0, 0) for ch in n):
        return closed_atoms(n[0]) + closed_atoms(n[1])
    return [n]


@cache
def source_depth(n):
    return 0 if leaf(n) else 1 + max(map(source_depth, n))


def optimize_closed(root, path, width=50):
    atoms = closed_atoms(subtree(root, path))
    outside = node_set(replace(root, path, ('CI', 5)))
    @cache
    def extra(n): return frozenset(node_set(n) - outside)
    dynamic = {(i, i + 1): [x] for i, x in enumerate(atoms)}
    for length in range(2, len(atoms) + 1):
        for i in range(len(atoms) - length + 1):
            j = i + length
            candidates = {(l, r) for k in range(i + 1, j)
                          for l in dynamic[i, k] for r in dynamic[k, j]}
            dynamic[i, j] = sorted(candidates,
                                  key=lambda n: (len(extra(n)), source_depth(n), str(n)))[:width]
    result = [replace(root, path, n) for n in dynamic[0, len(atoms)]]
    extra.cache_clear()
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--optimize', action='store_true')
    args = parser.parse_args()
    raw = args.input.read_bytes()
    require(sha(raw) == PINNED_SOURCE_SHA256, 'Input SHA-256 does not match transfer201')
    old = tree(json.loads(raw))
    require(metrics(old)['dag_nodes'] == 201 and size(old) == 4775, 'Pinned source metrics')
    args.output.mkdir(parents=True, exist_ok=False)
    records = []
    def emit(name, root, relative=''):
        rows = sites(root)
        graph = graph_intervals(rows)
        require(graph == graph_arithmetic(rows)[0], 'Independent source CFG resolvers disagree')
        raw = compact(rows)
        path = args.output / relative / (name + '.sites.json')
        path.parent.mkdir(exist_ok=True)
        path.write_bytes(raw)
        record = dict(name=name, file=str(path.relative_to(args.output)),
                      sha256=sha(raw), **metrics(root),
                      guarded_primitive_cases=sum(2 if op == 'CD' else 1 for p, op, arg in rows),
                      cfg_sha256=sha(compact(graph)),
                      word_sha256=sha(compact([[op, arg] for p, op, arg in rows])))
        records.append(record)
        return graph
    generated = dict(producer_sources(old))
    for name, root in generated.items(): emit(name, root)
    if args.optimize:
        current = generated['sharedmatch0_0']
        reference_graph = graph_intervals(sites(current))
        reference_word = [[op, arg] for p, op, arg in sites(current)]
        for path in ('111', '11010111', '110101', ''):
            variants = optimize_closed(current, path, 50)
            variants.sort(key=lambda n: (metrics(n)['dag_nodes'], metrics(n)['maximum_zero_run'], metrics(n)['maximum_depth']))
            for i, root in enumerate(variants):
                if metrics(root)['dag_nodes'] <= 202:
                    rows = sites(root)
                    require([[op, arg] for p, op, arg in rows] == reference_word, 'Changed primitive word')
                    require(graph_intervals(rows) == reference_graph, 'Changed ordinal guarded CFG')
                    emit(f'path{path or "root"}_{i}', root, 'optimized')
            current = variants[0]
    manifest = dict(status='SOURCE_ONLY', input_sha256=sha(args.input.read_bytes()),
                    generator_sha256=sha(Path(__file__).read_bytes()),
                    scope='Exact deterministic source construction, two CFG resolvers, and bounded reassociation search. No physical machine or startup certification.',
                    records=records)
    (args.output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(dict(status=manifest['status'], variants=len(records),
                         primary=next(r for r in records if r['name'] == 'sharedmatch0_0')), indent=2))


if __name__ == '__main__':
    main()
