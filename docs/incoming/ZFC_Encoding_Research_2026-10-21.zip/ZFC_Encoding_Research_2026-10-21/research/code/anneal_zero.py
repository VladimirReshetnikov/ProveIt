#!/usr/bin/env python3
"""Global all-occurrence closed-associativity annealing. Synthesis only."""
from pathlib import Path
import sys,json,random,math,time,argparse
sys.path.insert(0,str(Path(__file__).parent/'vendor'));import source_language as s
class DAG:
 def __init__(self):self.nodes=[];self.by={};self.bound=[];self.left=[];self.depth=[]
 def intern(self,n):
  if n in self.by:return self.by[n]
  i=len(self.nodes);self.by[n]=i;self.nodes.append(n)
  if isinstance(n[0],str):
   op,arg=n;b=(1,0,False)if op=='CD'else(arg,0,False)if op=='CB'else(0,arg,False)if op=='CC'else(0,0,op=='CH');self.left.append(0);self.depth.append(0)
  else:
   a,b=map(self.bound.__getitem__,n);b=(max(a[0]-1,0,b[0]),max(a[1],b[1]-1,0),a[2]or b[2]);self.left.append(1+self.left[n[0]]);self.depth.append(1+max(map(self.depth.__getitem__,n)))
  self.bound.append(b);return i
 def load(self,n):return self.intern(n)if s.leaf(n)else self.intern(tuple(map(self.load,n)))
 def internal(self,i):return isinstance(self.nodes[i][0],int)
 def reachable(self,r):
  out=set();todo=[r]
  while todo:
   q=todo.pop()
   if q in out:continue
   out.add(q)
   if self.internal(q):todo.extend(self.nodes[q])
  return out
 def ast(self,r):
  memo={}
  def f(q):
   if q not in memo:memo[q]=tuple(map(f,self.nodes[q]))if self.internal(q)else self.nodes[q]
   return memo[q]
  return f(r)
 def repl(self,r,target,new):
  memo={target:new}
  def f(q):
   if q not in memo:memo[q]=self.intern(tuple(map(f,self.nodes[q])))if self.internal(q)else q
   return memo[q]
  return f(r)
 def opts(self,reach):
  out=[]
  for q in reach:
   if not self.internal(q):continue
   x,y=self.nodes[q]
   if self.internal(x):
    a,b=self.nodes[x];c=y
    if all(self.bound[v]==(0,0,False)for v in(a,b,c)):out.append((q,a,b,c,0))
   if self.internal(y):
    a=x;b,c=self.nodes[y]
    if all(self.bound[v]==(0,0,False)for v in(a,b,c)):out.append((q,a,b,c,1))
  return out
 def rotate(self,r,opt):
  q,a,b,c,d=opt;new=self.intern((a,self.intern((b,c))))if d==0 else self.intern((self.intern((a,b)),c));return self.repl(r,q,new)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--steps',type=int,default=100000);ap.add_argument('--seed',type=int,default=1);ap.add_argument('--target',type=int,default=200);ap.add_argument('--zero-target',type=int,default=6);ap.add_argument('--zero-weight',type=float,default=.7);a=ap.parse_args();a.out.mkdir(exist_ok=True);D=DAG();source=s.tree(json.loads(a.source.read_text()));start=D.load(source);base=D.reachable(start);word=[[o,x]for p,o,x in s.sites(source)];cfg=s.graph_intervals(s.sites(source));rnd=random.Random(a.seed);cur=start;reach=base;score=len(base);best=score;opts=D.opts(reach);begin=time.monotonic();accepted=0;low=[]
 def emit(r,k,why):
  root=D.ast(r);rows=s.sites(root);assert [[o,x]for p,o,x in rows]==word and s.graph_intervals(rows)==cfg==s.graph_arithmetic(rows)[0]
  name=f'seed{a.seed}_step{k}_{len(D.reachable(r))}';(a.out/(name+'.sites.json')).write_bytes(s.compact(rows));v=dict(name=name,reason=why,**s.metrics(root));low.append(v);print('BEST',json.dumps(v),'elapsed',round(time.monotonic()-begin,2),flush=True)
 for k in range(a.steps):
  if not opts:cur=start;reach=base;score=len(base);opts=D.opts(reach)
  prop=D.rotate(cur,rnd.choice(opts));rr=D.reachable(prop);count=len(rr);zero=max(D.left[v]for v in rr);penalty=sum(max(D.left[v]-a.zero_target,0)for v in rr);energy=count+penalty*a.zero_weight+max(D.depth[prop]-55,0)*.1;oldzero=max(D.left[v]for v in reach);oldpenalty=sum(max(D.left[v]-a.zero_target,0)for v in reach);oldenergy=score+oldpenalty*a.zero_weight+max(D.depth[cur]-55,0)*.1
  temperature=.9*(1-(k%10000)/10000)+.04
  if count<=len(base)+3 and (energy<=oldenergy or rnd.random()<math.exp((oldenergy-energy)/temperature)):
   cur=prop;reach=rr;score=count;opts=D.opts(reach);accepted+=1
   if (count<best and zero<=6) or (zero<=a.zero_target and count<=a.target):
    best=count;emit(cur,k,'strict DAG improvement')
    if count<=a.target and zero<=a.zero_target:break
  if k%10000==9999:
   print('PROGRESS',k+1,'current',score,'best',best,'zero',zero,'penalty',penalty,'interned',len(D.nodes),'accepted',accepted,'seconds',round(time.monotonic()-begin,2),flush=True)
   cur=start;reach=base;score=len(base);opts=D.opts(reach)
 (a.out/f'seed{a.seed}.summary.json').write_text(json.dumps(dict(steps=k+1,best=best,accepted=accepted,seconds=time.monotonic()-begin,candidates=low),indent=2)+'\n')
if __name__=='__main__':main()
