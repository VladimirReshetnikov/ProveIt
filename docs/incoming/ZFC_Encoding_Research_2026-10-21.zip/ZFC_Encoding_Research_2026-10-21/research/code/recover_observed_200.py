#!/usr/bin/env python3
"""Replay only the historical seed-2 segment ending at proposal 10,000.

This is extraction from an already-recorded trajectory, not a new search.
The final accepted count, interned count and DAG size are checked against the
historical log before the unqualified 200-node source is exported.
"""
from pathlib import Path
import argparse,hashlib,json,math,random
from anneal_closed import DAG,s

def need(v,m):
 if not v:raise ValueError(m)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--input',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 raw=a.input.read_bytes();need(sha(raw)=='05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922','Unrecognized parent source')
 source=s.tree(json.loads(raw));D=DAG();start=D.load(source);base=D.reachable(start);cur=start;reach=base;score=len(base);opts=D.opts(reach);rnd=random.Random(2);accepted=0
 for k in range(10000):
  if not opts:cur=start;reach=base;score=len(base);opts=D.opts(reach)
  prop=D.rotate(cur,rnd.choice(opts));rr=D.reachable(prop);count=len(rr);zero=max(D.left[v]for v in rr);energy=count+max(zero-6,0)*.7+max(D.depth[prop]-55,0)*.1;oldzero=max(D.left[v]for v in reach);oldenergy=score+max(oldzero-6,0)*.7+max(D.depth[cur]-55,0)*.1
  temperature=.9*(1-(k%10000)/10000)+.04
  if count<=len(base)+3 and (energy<=oldenergy or rnd.random()<math.exp((oldenergy-energy)/temperature)):
   cur=prop;reach=rr;score=count;opts=D.opts(reach);accepted+=1
 need((score,len(D.nodes),accepted)==(200,300826,3583),'Historical trajectory did not reproduce')
 root=D.ast(cur);rows=s.sites(root);oldrows=s.sites(source)
 need([[op,arg]for pc,op,arg in rows]==[[op,arg]for pc,op,arg in oldrows],'Primitive word changed')
 cfg=s.graph_intervals(rows);need(cfg==s.graph_intervals(oldrows)==s.graph_arithmetic(rows)[0],'Guarded ordinal CFG changed')
 metrics=s.metrics(root);need(metrics['dag_nodes']==200 and metrics['maximum_zero_run']>6,'Unexpected historical candidate')
 a.output.mkdir(parents=True,exist_ok=False);data=s.compact(rows);(a.output/'source.sites.json').write_bytes(data)
 result=dict(status='SOURCE_ONLY_UNQUALIFIED_ZERO_RUN',scope='Exact extraction from the first 10000 proposals of historical seed2, complete primitive-word and guarded ordinal CFG equality. No physical allocation, runtime, startup or state-count claim.',input_sha256=sha(raw),source_sha256=sha(data),generator_sha256=sha(Path(__file__).read_bytes()),proposals=10000,accepted=accepted,interned_nodes=len(D.nodes),metrics=metrics,changed_leaf_addresses=sum(x[0]!=y[0]for x,y in zip(oldrows,rows)),cfg_sha256=sha(s.compact(cfg)),guarded_primitive_cases=sum(2 if op=='CD' else 1 for pc,op,arg in rows),long_zero_path_counts={str(n):sum('0'*n in pc for pc,op,arg in rows)for n in range(6,metrics['maximum_zero_run']+1)})
 (a.output/'recovery.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
