#!/usr/bin/env python3
"""Replay the historical synthesis filter, including its documented limitation.

Requires NumPy/SciPy. PREFIX_PASS is not a runtime certificate. The parent
allocator does not enforce the q122 leaf-context rule; its 218-state output
is deliberately retained as a rejected example. This wrapper changes paths
only and leaves the original allocator bytes intact.
"""
from pathlib import Path
import importlib.util
here=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("historical",here/"allocate_historical.py")
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.LATE=here.parent/"inputs/transfer"
module.ENGINE=here.parent/"inputs/engine.json"
module.main()
