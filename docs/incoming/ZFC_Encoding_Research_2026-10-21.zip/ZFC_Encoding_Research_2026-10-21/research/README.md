# Compiler research packet — 2026-10-21

This packet preserves several source-construction directions and their exact physical status. It does **not** contain a successful new 214-state blank-tape machine. The accepted 215-state result and its universal runtime and bootstrap certificates are delivered separately in `zero_run_q50_packet`. A standalone copy of the six-rotation source replay is included here for convenience.

## Status at handoff

| Construction | Hash-consed source DAG nodes | Primitive leaf occurrences | Physical result |
|---|---:|---:|---|
| Six closed reassociations of K215 | 202 | 4,751 | Accepted as a source/control-layout change; combined with q50 acceleration and fully checked in the separate machine packet. |
| Producer-only falsity checking, direct transfer-pop, normalized no-push MP | 202 | 4,706 | Source semantics audited and calibrated in the formalism packet. No accepted physical realization at 215. Historical 218-state prefix allocation has an explicit runtime counterexample. |
| Transfer-pop with stride-two enumeration | 202 | 4,776 | Source arithmetic and equiconsistency proved in the formalism packet. A literal 215-state physical table passes 6,210 finite primitive cases but its blank start is an exact outward ray after 85 steps. Rejected. |
| Recovered historical 200-node reassociation | 200 | 4,775 | Exact source semantics preserved, but maximum zero run is 8. No physical allocation attempted. |
| All-occurrence closed-rotation annealing | 201 or 202 input | Unchanged | Four bounded 100,000-proposal searches found no qualifying smaller/shorter-zero-run source. These are search negatives, not lower bounds. |

“Source DAG nodes” counts distinct AST nodes including primitive leaf types. It is not a count of physical states or even just decoder states. Formula calibration, source semantics, decoder prefix binding, arbitrary-value primitive runtime, and blank-tape initialization are separate obligations.

## The producer-only source idea

The new three-command interface moves the test for falsity code 1 to the successful detachment producer. AX never produces code 1. The stack/transfer operation therefore needs no local falsity guards:

- `S(t,w,d,h) = (h, tail(w), d, head(w))`, with an empty head/tail interpreted as zero.
- Successful `MP` with consequent `y` halts exactly when `y = 1`; otherwise it returns `(y,w,0,0)`. It does not push an extra zero.
- The original axiom generator is unchanged.

The implementation reuses the existing equality comparator to test the freshly produced consequent against 1. Its 16-leaf success block copies `D` into `T` and scratch `X`, sets `H = 1`, then invokes the original comparator and a single halt leaf. Its direct transfer/pop block uses 19 leaves. The full source has 202 DAG nodes and 4,706 leaves.

`producer202/independent_source_audit.json` records an independent exact CFG audit of the source. The complete mathematical proof, source-audit tool, and interface audit are in the accompanying formalism packet. `code/generate_producer_sources.py` reproduces the source and nearby reassociations from the pinned transfer parent using only the Python standard library.

### Why the 218-state physical table is rejected

The historical allocator proved only the internal-prefix binding. It omitted a context condition for native state 122:

- At a prefix ending in `0`, state 122 realizes `(CD5, CC1)`.
- At a prefix ending in `1`, state 122 realizes `(CD1, CC1)`.

The new direct-S block placed `(CD1, CC1)` at prefix `11100`. The reused state therefore performs the wrong decrement. The finite primitive screen found the concrete failure at its case index 6092: positive `CD1`, source PC `111000`, logical register 1 equal to 1, all other logical registers zero, gap zero, and spare list `[0]`.

`producer202/rejected218.native.tm` and `counterexample_trace.json.gz` preserve the exact 646-step counterexample. `verify_research.py` replays every transition of that trace, derives the expected CD1 endpoint independently, and checks that the actual endpoint differs. The `PREFIX_PASS` receipt is retained to document precisely why prefix checks cannot substitute for runtime validation. It is not an accepted machine, even at 218 states.

The 215- and 217-state allocation receipts record infeasibility of this particular conservative integer-programming allocation model. They do not prove that no such physical implementation exists. The original allocator remains byte-for-byte intact in `code/allocate_historical.py`; the wrapper changes its data paths only. Its missing state-122 condition is intentionally not concealed or silently repaired.

## The stride-two source idea

The original fetch-and-restore scheduler copies counter `N` into cursor `L` and temporary register `X`, then restores `N = X + 1`. Inserting one `CI0` before the restore loop gives `L = old(N)`, `N = old(N) + 2`, `X = 0`.

Equiconsistency needs a completeness argument for enumerating only one parity class. The accompanying formalism packet proves a stronger modular prefix theorem: the relevant nested Cantor encodings of each fixed instruction prefix hit every residue modulo every power of two. The proof uses the permutation property of `z(2z+1)` modulo powers of two. Protected-tail credit for the two parity schedules is proved separately there. This is a new source-level enumeration option; it is not made into a valid blank machine by the finite primitive tests.

`code/generate_stride_sources.py` reproduces four arithmetic variants from either pinned parent. Its built-in check on inputs 0 through 100 is explicitly a smoke test, not the all-natural scheduler proof.

### Why the concrete 215-state table is rejected

The table `stride215/rejected.native.tm` combines the old runtime-only delete-301 fold with the new scheduler and reuses the released label 301. The exact construction is:

```
51/0  := 0 R 122
87/0  := 0 R 88
88/0  := 0 L 51
110/1 := 1 R 301
301/0 := 0 R 14
301/1 := 1 R 8
```

All other rows equal the pinned transfer215 parent. This is exactly 215 working states. All 6,210 finite primitive test cases pass, but that is not a quantified runtime proof. More decisively, its designated blank start 0 reaches state 35 after 85 steps, head 7, with the only one-cells at -3 and -2. State 35 on blank writes 1, moves right, and returns to state 35. Because the head lies strictly right of all existing ones, the same blank transition repeats forever. It can never enter the proof enumerator.

`start_classifications.txt` extends this exact obstruction: all 215 blank initial states and two one-bit seeds for each state are classified. Of 645 starts, 644 reach outward rays and one halts; there are no bounded unknowns. The seeds are blank/head 0; one at cell 0/head 1; and one at cell 0/head -1. `verify_research.py` independently replays all 645 finite certificates and checks the outward-ray or halt condition at each endpoint. The one-bit seeds are exploratory variations, not the standard blank-machine convention.

## Six-rotation transport

`rotations/replay_rotations.py` applies exactly six literal tree/decoder rotations to the pinned K215 inputs. It checks closed factors, complete primitive-word equality, both independent guarded ordinal CFG resolvers, and every internal decoder prefix. It uses no optimizer or third-party package.

The six rotations change 4,525 of 4,751 leaf addresses and 15 native transition rows, preserving 202 source DAG nodes. The number of leaf paths containing six consecutive zero selectors drops from 37 to 34, but the maximum zero run remains six. Total leaf-path length increases from 160,305 to 163,438, so this change is not claimed as a global decoder-speed improvement. The separate q50 acceleration changes one additional transition row and supplies the measured blank-bootstrap speed improvement in the machine packet.

## Bounded negative global searches

The scripts replace *all* occurrences of a selected closed AST rotation, preserving the complete primitive word and guarded control-flow graph. They hash-cons the resulting DAG and permit small temporary increases in size. The historical runs were:

| Script | Parent | Seed | Proposals | Target | Outcome |
|---|---|---:|---:|---|---|
| `anneal_closed.py` | transfer201 | 1 | 100,000 | at most 200 nodes; maximum zero run at most 6 | none |
| `anneal_closed.py` | transfer201 | 2 | 100,000 | at most 200 nodes; maximum zero run at most 6 | none |
| `anneal_closed.py` | carried-flag stride202 | 3 | 100,000 | at most 201 nodes; maximum zero run at most 6 | none |
| `anneal_zero.py` | transfer201 | 4 | 100,000 | at most 201 nodes and maximum zero run at most 5 | none |

The `best` field in the original summaries means best qualifying size, with the zero-run filter applied; it is not the smallest size ever visited. In particular, the second transfer log visits a 200-node source and the carried-flag log visits a 201-node source, but these fail the maximum-six-zero condition and were not exported. The exact carried-flag wrapper used for the historical seed-3 run was not captured by that run's receipt, so no exact input-bound reproduction is claimed for it. The transfer inputs and runnable search scripts are supplied.

The zero-run search used `--zero-target 5 --zero-weight 2`. The other scripts use their recorded defaults. Search iteration order and optimizer behavior are implementation dependent; seeds are useful for reproduction in the original environment, not a machine-independent proof. Logs and JSON summaries are included. Neither these searches nor the allocation failures establish a state lower bound.

## Recovered 200-node source, with an eight-zero obstruction

`observed200/source.sites.json` is the exact unqualified 200-DAG-node source recorded at the first 10,000-proposal checkpoint of historical seed 2. The extraction script checks that the replay has exactly 300,826 interned nodes and 3,583 accepted moves, matching the saved log. It then verifies the full primitive word and both independent guarded ordinal CFG resolvers against the transfer201 parent.

This source has 4,775 primitive leaves, maximum depth 50, and maximum zero run **8**. Of its leaf paths, 53 contain seven consecutive zero selectors and seven contain eight. It changes 4,621 leaf addresses. Its source hash is `5619aea70fce373a99e5cfdbffe7fb6072e194f1adbd9dcca9b82607c8e6bb89`.

Thus the historical search did find a smaller source when the marker-depth constraint is relaxed. Under the existing linear marker-recognition design, increasing the allowable zero run from 6 to 8 requires two extra depth positions. Saving one DAG node therefore does not by itself pay for that expansion. Even that accounting is conditional: an abstract DAG reduction need not release an unrestricted physical state because arithmetic and decoder roles share transition rows. No physical allocation or runtime/bootstrap proof is claimed for this source.

To recover only this already-recorded search segment:

```sh
python code/recover_observed_200.py --input inputs/transfer/source/transfer201.sites.json --output build/observed200
```

This runs the first 10,000 recorded proposals only, exports the checkpoint, and stops. It does not initiate a new annealing search.

## Reproduction

From this packet directory, run the exact receipt checks and source replay:

```sh
python verify_research.py --output verification.json
```

This uses only the standard library, validates the manifest, reproduces the primary sources, replays the literal six rotations, recovers the recorded 200-node checkpoint, and verifies the exact producer and startup counterexamples. It does not rerun optional stochastic searches or claim fresh universal runtime proofs.

To obtain all 23 producer source variants:

```sh
python code/generate_producer_sources.py --input inputs/transfer/source/transfer201.sites.json --output build/producer --optimize
```

To obtain the four transfer stride variants:

```sh
python code/generate_stride_sources.py --input inputs/transfer/source/transfer201.sites.json --output build/stride
```

To replay the historical allocation model (requires NumPy and SciPy):

```sh
python code/replay_historical_allocation.py --source producer202/source.sites.json --output build/historical218 --fresh 3
```

Its success status remains prefix-only, and the documented context defect still applies. MILP tie choices can select different equally scored witnesses. The pinned rejected table and its literal runtime counterexample are the authoritative evidence here.

To rerun a bounded annealing search:

```sh
python code/anneal_closed.py --source inputs/transfer/source/transfer201.sites.json --out build/anneal --steps 100000 --seed 1 --target 200
python code/anneal_zero.py --source inputs/transfer/source/transfer201.sites.json --out build/zero --steps 100000 --seed 4 --target 201 --zero-target 5 --zero-weight 2
```

Output directories must not already exist for the deterministic source generators and allocator; create `build` before the optional annealers. The archive contains no search binaries or large exploratory traces. `manifest.json` pins every delivered source, input, tool, and receipt.
