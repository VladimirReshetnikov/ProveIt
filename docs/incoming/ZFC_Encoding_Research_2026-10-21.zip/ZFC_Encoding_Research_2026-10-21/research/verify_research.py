#!/usr/bin/env python3
"""Exact source replay and negative-control verification; standard library only.

No finite primitive screen is treated as an all-natural runtime proof. The
accepted machine's quantified runtime and bootstrap checks live in its own
packet. This checker verifies the claims made by this research packet.
"""
from pathlib import Path
from collections import Counter
import argparse,gzip,hashlib,json,subprocess,sys,tempfile

HERE=Path(__file__).resolve().parent
PHY=(6,2,0,4,3,7,8,5,1)

def need(value,message):
    if not value:raise ValueError(message)

def sha(data):return hashlib.sha256(data).hexdigest()

def table(path):
    out={};starts=[]
    for line in path.read_text().splitlines():
        if line.startswith('#! start '):starts.append(int(line[9:]));continue
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
        need((q,b) not in out and b in (0,1) and w in (0,1) and d in ('L','R'),'Malformed table')
        out[q,b]=(w,1 if d=='R' else -1,z)
    states={q for q,b in out}
    need(starts==[0] and set(out)=={(q,b)for q in states for b in (0,1)},'Bad total table/start')
    need({z for w,d,z in out.values()}-states=={254},'Bad terminal state')
    return out

def frame(pc,logical,spares,gap=0):
    physical=[0]*9
    for i,j in enumerate(PHY):physical[j]=logical[i]
    ones={-1,64+gap}|{i for i,b in enumerate(pc)if b=='1'}
    pos=65+gap
    for value in physical+list(spares):
        pos+=1;ones.update(range(pos,pos+value+1));pos+=value+1
    return ones

def advance(T,q,h,ones):
    b=int(h in ones);w,d,z=T[q,b]
    if w:ones.add(h)
    else:ones.discard(h)
    return z,h+d,(q,h,b,w,d,z)

def describe(q,h,ones):return dict(state=q,head=h,ones=sorted(ones))

def producer_counterexample():
    T=table(HERE/'producer202/rejected218.native.tm')
    need(len(T)==436,'Expected rejected 218-state witness')
    source=json.loads((HERE/'producer202/source.sites.json').read_text())
    need(['111000','CD',1] in source,'Counterexample does not name CD1')
    proof=json.loads(gzip.decompress((HERE/'producer202/counterexample_trace.json.gz').read_bytes()))
    regs=[0]*9;regs[1]=1;q=84;h=0;ones=frame('111000',regs,[0])
    for tick,row in enumerate(proof['trace']):
        q,h,actual=advance(T,q,h,ones)
        need([tick,*actual]==row,'Counterexample trace mismatch')
    need(len(proof['trace'])==proof['steps']==646,'Unexpected counterexample length')
    got=describe(q,h,ones);want=describe(84,0,frame('111001',[0]*9,[0],gap=1))
    need(got==proof['actual'] and want==proof['expected'],'Counterexample endpoints differ from the independently derived CD1 contract')
    need(got!=want,'Rejected counterexample unexpectedly passed')
    need(T[122,0]==(0,-1,137),'Expected contextual q122 entry')
    return dict(status='EXACT_RUNTIME_COUNTEREXAMPLE_REPLAYED',steps=646,source_pc='111000',opcode='CD',register=1,expected=want,actual=got)

def stride_rejection():
    T=table(HERE/'stride215/rejected.native.tm')
    old=table(HERE/'inputs/transfer/machine/transfer215.native.tm');want=dict(old)
    for key,action in {
        (51,0):(0,1,122),(87,0):(0,1,88),(88,0):(0,-1,51),
        (110,1):(1,1,301),(301,0):(0,1,14),(301,1):(1,1,8)
    }.items():want[key]=action
    need(T==want and len(T)==430,'Stride table is not the literal 215-state construction')
    states={q for q,b in T};seen=set();counts=Counter();designated=None;maximum=0
    for line in (HERE/'stride215/start_classifications.txt').read_text().splitlines():
        start,seed,status,ticks,endq,endh,lo,hi=line.split();start,seed,ticks,endq,endh,lo,hi=map(int,(start,seed,ticks,endq,endh,lo,hi))
        need((start,seed)not in seen and start in states and seed in(0,1,2),'Malformed seed enumeration');seen.add((start,seed))
        q=start;h=0 if seed==0 else 1 if seed==1 else -1;ones=set()if seed==0 else{0}
        for _ in range(ticks):q,h,_=advance(T,q,h,ones)
        need((q,h)==(endq,endh),'Bootstrap endpoint mismatch')
        need((min(ones),max(ones))==(lo,hi)if ones else lo>hi,'Bootstrap support bounds mismatch')
        if status=='HALT':need(q==254,'Bad halt certificate')
        elif status=='OUTWARD_RAY':
            need(h not in ones,'Ray endpoint is not blank');w,d,z=T[q,0]
            need(z==q and (not ones or(d>0 and h>max(ones))or(d<0 and h<min(ones))),'Bad outward-ray certificate')
        else:raise ValueError('Unproved or bounded bootstrap classification')
        counts[status]+=1;maximum=max(maximum,ticks)
        if(start,seed)==(0,0):
            need((ticks,q,h,sorted(ones))==(85,35,7,[-3,-2]),'Designated blank start changed')
            designated=dict(steps=ticks,**describe(q,h,ones),blank_transition=list(T[q,0]))
    need(seen=={(q,b)for q in states for b in(0,1,2)},'Incomplete seed coverage')
    need(counts=={'OUTWARD_RAY':644,'HALT':1},'Unexpected bootstrap census')
    return dict(status='REJECTED_BY_EXACT_BOOTSTRAP_CERTIFICATES',states=215,seeds=len(seen),classifications=dict(counts),maximum_certificate_steps=maximum,designated_blank_start=designated,finite_primitive_screen_cases=6210,finite_primitive_screen_is_not_universal_proof=True)

def run_script(path,args):
    result=subprocess.run([sys.executable,str(path),*map(str,args)],cwd=HERE,capture_output=True,text=True)
    need(result.returncode==0,'Replay failed: '+str(path)+'\n'+result.stdout+'\n'+result.stderr)
    return result

def source_replays():
    with tempfile.TemporaryDirectory(prefix='zfc-source-research-')as work:
        work=Path(work);producer=work/'producer';stride=work/'stride';rotations=work/'rotations';recovery=work/'observed200'
        run_script(HERE/'code/generate_producer_sources.py',['--input',HERE/'inputs/transfer/source/transfer201.sites.json','--output',producer,'--optimize'])
        manifest=json.loads((producer/'manifest.json').read_text());pinned=json.loads((HERE/'producer202/generated_variants_manifest.json').read_text())
        need(manifest==pinned,'Producer variants do not reproduce the pinned manifest')
        need((producer/'sharedmatch0_0.sites.json').read_bytes()==(HERE/'producer202/source.sites.json').read_bytes(),'Producer source byte mismatch')
        run_script(HERE/'code/generate_stride_sources.py',['--input',HERE/'inputs/transfer/source/transfer201.sites.json','--output',stride])
        need((stride/'original2.sites.json').read_bytes()==(HERE/'stride215/source.sites.json').read_bytes(),'Stride source byte mismatch')
        stride_manifest=json.loads((stride/'manifest.json').read_text())
        run_script(HERE/'rotations/replay_rotations.py',['--table',HERE/'inputs/k215.native.tm','--source',HERE/'inputs/k215.sites.json','--output',rotations])
        rotation=json.loads((rotations/'source-transport.json').read_text());old_rotation=json.loads((HERE/'rotations/source-transport.json').read_text())
        need(rotation==old_rotation,'Six-rotation source transport receipt changed')
        run_script(HERE/'code/recover_observed_200.py',['--input',HERE/'inputs/transfer/source/transfer201.sites.json','--output',recovery])
        recovered=json.loads((recovery/'recovery.json').read_text())
        need(recovered==json.loads((HERE/'observed200/recovery.json').read_text()),'Historical checkpoint receipt changed')
        need((recovery/'source.sites.json').read_bytes()==(HERE/'observed200/source.sites.json').read_bytes(),'Historical checkpoint source changed')
    return dict(status='EXACT_SOURCE_GENERATIONS_REPLAYED',producer_variants=len(manifest['records']),stride_variants=len(stride_manifest['records']),producer_sha256=sha((HERE/'producer202/source.sites.json').read_bytes()),stride_sha256=sha((HERE/'stride215/source.sites.json').read_bytes()),rotations=dict(states=rotation['states'],changed_leaf_addresses=rotation['changed_leaf_addresses'],guarded_primitive_cases=rotation['guarded_primitive_cases'],final=rotation['final']),observed200=recovered,not_a_physical_runtime_proof=True)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path);args=ap.parse_args()
    manifest=json.loads((HERE/'manifest.json').read_text())
    for row in manifest['files']:
        path=HERE/row['path'];raw=path.read_bytes()
        need(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'Manifest mismatch: '+row['path'])
    anneal=[]
    for name,best in [('transfer_seed1',201),('transfer_seed2',201),('flag_seed3',202),('zero_seed4',201)]:
        receipt=json.loads((HERE/'annealing'/f'{name}.json').read_text())
        need(receipt['steps']==100000 and receipt['best']==best and not receipt['candidates'],'Unexpected bounded search receipt')
        anneal.append(dict(run=name,proposals=receipt['steps'],best_qualifying_dag_nodes=best,qualification_maximum_zero_run=5 if name=='zero_seed4' else 6,status='HISTORICAL_BOUNDED_NEGATIVE_NOT_RERUN'))
    result=dict(status='PASS',scope='Exact delivered-input integrity, source construction replay, and literal counterexample certificates. No new accepted 214-state machine and no universal runtime claim for rejected tables.',manifest_files=len(manifest['files']),source_replays=source_replays(),producer218=producer_counterexample(),stride215=stride_rejection(),annealing=anneal)
    raw=json.dumps(result,indent=2)+'\n'
    if args.output:args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(raw)
    print(raw,end='')
if __name__=='__main__':main()
