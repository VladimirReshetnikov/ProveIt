#!/usr/bin/env python3
"""Replay one explicitly selected historical physical screen; never runs by default."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--list', action='store_true', help='list screen names and exact scopes')
    p.add_argument('--screen', help='one named screen from replay_screens.json')
    p.add_argument('--out', type=Path, help='new or empty directory for executable and fresh logs')
    p.add_argument('--cxx', default='g++', help='GCC-compatible compiler, default g++')
    a = p.parse_args()
    screens = json.loads((ROOT / 'replay_screens.json').read_text())
    if a.list:
        for name, s in screens.items():
            print(name + ': ' + s['scope'])
        return
    if not a.screen or a.out is None:
        p.error('use --list, or provide --screen NAME --out EMPTY_DIRECTORY')
    if a.screen not in screens:
        p.error('unknown screen: ' + a.screen)
    out = a.out.resolve()
    if out.exists() and any(out.iterdir()):
        p.error('--out must be empty or absent')
    out.mkdir(parents=True, exist_ok=True)
    s = screens[a.screen]
    exe = out / 'screen'
    compile_cmd = [a.cxx, '-O3', '-std=c++20', str(ROOT / s['harness']), '-o', str(exe)]
    run_cmd = [str(exe)] + [str(ROOT / x) if '/' in x else x for x in s['arguments']]
    (out / 'command.json').write_text(json.dumps({'screen': a.screen, 'compile': compile_cmd, 'run': run_cmd, 'scope': s['scope']}, indent=2) + '\n')
    with (out / 'compile.stdout').open('w') as so, (out / 'compile.stderr').open('w') as se:
        subprocess.run(compile_cmd, stdout=so, stderr=se, check=True)
    with (out / 'stdout.log').open('w') as so, (out / 'stderr.log').open('w') as se:
        completed = subprocess.run(run_cmd, stdout=so, stderr=se, check=False)
    got_out, got_err = (out / 'stdout.log').read_text(), (out / 'stderr.log').read_text()
    want_out = (ROOT / s['saved_stdout']).read_text() if s.get('saved_stdout') else s.get('expected_stdout', '')
    want_err = (ROOT / s['saved_stderr']).read_text() if s.get('saved_stderr') else s['expected_stderr']
    result = {'screen': a.screen, 'returncode': completed.returncode,
              'stdout_matches_saved_result': got_out == want_out,
              'stderr_matches_saved_result': got_err == want_err}
    if s.get('cleanup') and completed.returncode == 0:
        sys.path.insert(0, str(ROOT / 'code'))
        from classify_cleanup import classify
        result['analytic_closure'] = classify(ROOT / s['arguments'][0], out / 'stdout.log', out / 'stderr.log')
    result['status'] = 'REPLAY_MATCH' if completed.returncode == 0 and got_out == want_out and got_err == want_err else 'REPLAY_DIFFERENCE'
    (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if result['status'] != 'REPLAY_MATCH':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
