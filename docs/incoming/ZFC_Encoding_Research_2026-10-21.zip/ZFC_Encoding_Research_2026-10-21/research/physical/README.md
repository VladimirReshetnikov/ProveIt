# Physical search evidence and portable replay

This packet supports the negative physical-search claims in the report's
`sections/physical_search.tex`. It contains rejected allocations and scoped
search evidence. **None of these rejected tables is the accepted 215-state
machine.** The accepted machine and its universal runtime proof are packaged
separately under `machine215/` in the enclosing deliverable.

## Quick audit and selected replay

The quick audit uses Python 3 and its standard library:

```sh
python3 audit.py
python3 replay.py --list
```

`audit.py` checks file hashes, all 26 unchanged pins in the original receipt,
case counts, saved merge summaries, and literal nonhalting certificates for
all saved bootstrap endpoints. It also replays the 646-transition q122
counterexample. It does **not** repeat the mass searches or independently
recompute all prefixes leading to their saved endpoints.

To repeat one particular screen, select it explicitly. A GCC installation
with C++20 support is required; the historical harnesses use GNU
`std::bitset::_Find_first`. There are no repository imports or absolute
workspace paths in the executable replay path.

```sh
python3 replay.py --screen final-merge --out /tmp/zfc-final-merge
python3 replay.py --screen final-unit40 --out /tmp/zfc-final-unit40
python3 replay.py --screen constant54 --out /tmp/zfc-cleanup54
python3 replay.py --screen constant66-accel --out /tmp/zfc-cleanup66-accel
```

Use a new or empty output directory for each replay. The wrapper compiles the
exact saved harness, records its command line, saves stdout and stderr, and
compares them with the saved results. For the four cleanup searches it also
checks the analytic closure of every bounded remainder. Other available
choices include the finite no-append check, both stride bootstrap screens,
the stride pair-merge variants, and the three q301 action screens. Mass
screens can take substantial time; none runs merely by opening this packet
or invoking the quick audit.

## Provenance and contents

`late_search_receipt.json` is preserved verbatim. Its 26 `files` entries resolve
under `historical/`, with exactly their original relative names and SHA-256
hashes. Paths elsewhere in that original receipt, such as
`../source_search/...`, are historical provenance labels, not execution
dependencies. The referenced rejected 218-state table is separately included
as `inputs/producer218_rejected.native.tm`.

`replay_screens.json` is the authoritative mapping from a screen name to its
literal table, concrete cases, C++ harness, arguments, and saved output.
`source_case_provenance.json` pins the full source-list hashes and the converted
case-list counts. The four source lists were compared with the packaged case
lists when this packet was assembled. `code/prepare_sites.py` regenerates the
finite input format from a supplied complete source JSON list; a `CH` argument
of JSON `null` is explicitly converted to `-1` so the C++ integer parser does
not stop early.

The preserved `noappend_shared301_deep.log` records an earlier 5,920-case
helper discovery. It is historical discovery evidence, not the claimed
6,176-case finite check. The latter uses `constant54-finite`, the complete
`inputs/baseline_cases.txt`, and `code/finite_noappend.cpp`.

## Exact finite primitive and merge screen

The logical register order is `(N,T,W,A,D,H,X,Y,L)`. The physical index for
each logical register is `(6,2,0,4,3,7,8,5,1)`. A numeric field is represented
by `B(n) = 0 1^(n+1)`. Each input starts in native dispatcher 84 with head at
zero, guard at -1, source address starting at zero, and the header at
`64 + gap`. Halt is native state 254.

Each complete source list contributes one case per primitive occurrence and
an additional positive case per `CD`. The standard concrete representative
has all nine primary values zero, except that the selected positive `CD`
register equals one; gap is zero and the spare list is `[0]`. Baseline and
final recompiled sources each give 6,176 cases; the baseline-derived stride
source gives 6,177; the transfer-derived stride source gives 6,210. These are
concrete representatives, not quantification over arbitrary register values.

The ordinary postcondition increments the selected value for CI and appends
a unit spare, decrements the positive CD value and increases the gap by one,
and applies the exact source-address operation for CI/CD/CC/CB. CH must halt.
The no-append harness changes only CI's spare-list postcondition. The
published zero-spare harness instead expects CI to append a zero-valued
spare; these are different policies.

The finite tape has 512 cells, offset 64. The harness stops at the next
recognized clean dispatcher return or halt. A clean return requires the
leftmost one at `head-1` and the first one found from `head+52` at or beyond
`head+64`; the whole resulting bitset, head, and state must match the expected
frame. The unmodified table is first checked with a 10,000-transition limit
per case. Each altered table is then given `3 * baseline_steps + 100` steps
for that case. Head positions at the finite window boundary are rejected.

For each unordered pair of working states other than dispatcher 84, the
lower native identifier is retained, all incoming references to the deleted
state are redirected to it, and each of the two read-symbol rows is selected
independently from either member of the pair. Thus a 215-state input has
`4 * choose(214,2) = 91,164` choices; a 216-state input has
`4 * choose(215,2) = 92,020`. Cases whose original executions visit neither
state need not be rerun. This is an exact enumeration of that transformation
class with the stated finite acceptance criterion.

A rejection may mean a wrong result, an unexpected halt, a time-bound
failure, or a tape-window failure. The harness does not retain or classify a
semantic counterexample for every rejected merge. Zero survivors do not
prove a lower bound on states, rule out slower equivalent implementations,
or establish a universal runtime theorem for any altered table.

The `unit1` and `unit40` variants use initial gap one and respectively one or
forty unit-valued spare fields. The q301 `invariant4` variant additionally
sets `X=L=4, N=0` at the extra CI0 site `0110`. These are stronger concrete
representatives motivated by reachable invariants, not new universal
invariant proofs. All other constants and limits remain as above.

## Stride bootstrap and q301 actions

`stride_transfer_fold215.native.tm` passes the 6,210-case finite primitive
screen. Its blank-start screen uses each of 215 working states with each of
three seeds: (0) entirely blank, head zero; (1) one at coordinate zero, head
one; (2) one at coordinate zero, head minus one. The bound is 1,000,000 steps.
The 645 saved cases comprise 644 exact outward rays and one halt. The variant
with `301/0 = 0 L 301` has the same classification.

An outward ray certificate means the current read bit is zero, the current
state's zero transition returns to that same state, and its movement points
strictly away from all nonzero tape support. Repeating that literal
transition forever is an exact nonhalting argument for the endpoint, even
if it writes ones behind the advancing head.

Each q301 row-action screen tests both read rows independently, both writes,
both directions, and each of 215 working targets plus halt: 1,728 actions.
Three finite survivors include the two identity actions. The sole
nonidentity survivor is `301/0 = 0 L 301`. The unit-spare and `X=L=4` screens
produce no additional survivors.

## Constant-spare bootstrap cross product and closure

Relative to the baseline native table, the helper-54 input changes precisely:

| Read row | Replacement action |
|---|---|
| 88/0 | 0 L 51 |
| 51/0 | 0 R 122 |
| 87/0 | 0 R 88 |
| 198/0 | 0 L 301 |
| 301/0 | 0 R 0 (placeholder; overwritten by the search) |
| 301/1 | 0 L 54 |

The older decoder fold frees 301 for cleanup. The helper-66 variant changes
only `301/1` to `0 L 66`. The accelerated versions also change `50/0` to
`0 R 75`. The finite no-append check and this initialization search are
separate obligations; no all-natural runtime theorem is asserted here.

For each table, the free row `301/0` ranges over 216 targets (all working
states plus halt), two writes, and two directions: 864 actions. Each action
is crossed with the same 215 starting states and three seeds, giving
557,280 trajectories. The literal harness uses 4,096 tape cells with offset
2,048 and a 250,000-step bound. It records `SPACE_BOUND` when head or support
reaches its reserved edge, rather than interpreting the edge as a blank
infinite tape.

The frame detector checks dispatcher 84, left guard, a header at least 64
cells to the right of the head, at least nine primary fields plus one spare,
and physical fields 0, 2 and 7 equal to zero (logical W, T and H). A calibrated
frame was a search target only. No such target remains, because every case
is instead a halt or has an exact nonhalting endpoint certificate.

| Cleanup helper (with or without acceleration) | Outward rays | Halts | Time bounds | Space bounds |
|---|---:|---:|---:|---:|
| 54 | 556,374 | 894 | 4 | 8 |
| 66 | 553,764 | 894 | 4 | 2,618 |

All remainders close by one of three literal fragments:

1. Four endpoints with `301/0 = 0 R 198` are exact two-transition cycles,
   using `198/0 = 0 L 301`. Both inspected cells are zero and remain zero;
   the entire configuration returns.
2. Eight endpoints with `301/0 = w L 198` are leftward two-state rays.
   Both transitions move into fresh blank cells left of the existing support.
3. In the helper-66 variants, 2,610 additional endpoints are in state 66
   with the current cell and its right neighbor blank and left of all
   support. The fragment `66/0 = 1 R 198`, `198/0 = 0 L 301`,
   `301/1 = 0 L 66` restores the entire tape and moves the head one cell left.
   The same precondition therefore holds again.

`code/classify_cleanup.py` checks those literal rows and the endpoint support
inequalities for every saved remainder. The reported zero unresolved cases
is exact for this class of starts and free-row actions, conditional on the
logged finite prefixes, which the explicit replay command recomputes.
