#!/usr/bin/env python3
"""Convert a source-site JSON list to the finite discovery harness format."""
from pathlib import Path
import argparse,json
p=argparse.ArgumentParser();p.add_argument('sites',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
sites=json.loads(a.sites.read_text());out=[]
for pc,op,arg in sites:
 assert pc and set(pc)<=set('01') and op in ('CI','CD','CC','CB','CH')
 assert isinstance(arg,int) or (op=='CH' and arg is None)
 for pos in ((False,True) if op=='CD' else (False,)):
  out.append(f'{pc} {op} {arg if arg is not None else -1} {int(pos)}\n')
a.output.write_text(''.join(out));print(json.dumps({'sites':len(sites),'primitive_cases':len(out)}))
