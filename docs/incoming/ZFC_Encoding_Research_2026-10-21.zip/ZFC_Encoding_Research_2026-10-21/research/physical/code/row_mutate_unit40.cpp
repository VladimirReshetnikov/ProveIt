#include <bits/stdc++.h>
using namespace std;
struct Act{int w,d,z;};
struct Case{string pc,op;int arg,pos;bitset<512> init,want;int wantq,wanth;bitset<4096> used;long steps;};
Act T[4096][2];vector<int> states;vector<Case> cs;int phy[]={6,2,0,4,3,7,8,5,1};
const int OFF=64;
bitset<512> frame(string pc,vector<int> r,int gap=1,int shift=0,bool extra=false){bitset<512>t;auto set=[&](int x){if(x+OFF-shift<0||x+OFF-shift>=512)abort();t.set(x+OFF-shift);};set(-1);set(64+gap);for(int i=0;i<(int)pc.size();i++)if(pc[i]=='1')set(i);vector<int>v(9);for(int i=0;i<9;i++)v[phy[i]]=r[i];for(int sparei=0;sparei<40;sparei++)v.push_back(1);if(extra)v.push_back(1);int p=65+gap;for(int n:v){p++;for(int k=0;k<=n;k++)set(p++);}return t;}
pair<string,int> inc(string pc){for(int i=(int)pc.size()-1;i>=0;i--)if(pc[i]=='0'){pc[i]='1';return{pc,0};}else pc[i]='0';return{pc,1};}
string strip(string pc,char b,int n){for(int i=(int)pc.size()-1;i>=0;i--)if(pc[i]==b&&!--n)return pc.substr(0,i);return "";}
bool run(Case &c,int a=-1,int b=-1,int choice=0,bool baseline=false){auto t=c.init;int q=84,h=0;long lim=baseline?10000:c.steps*3+100;for(long step=0;step<=lim;step++){if(h+OFF<=0||h+OFF>=511)return false;bool clean=q==84 && t[h+OFF-1] && (int)t._Find_first()==h+OFF-1; if(clean){int first=-1;for(int j=h+OFF+52;j<512;j++)if(t[j]){first=j;break;}clean=first>=h+OFF+64;} if(step&&(clean||q==254)){if(baseline)c.steps=step;return q==c.wantq&&(q==254||(h==c.wanth&&t==c.want));}if(q==b)q=a;if(baseline)c.used.set(q);int bit=t[h+OFF];Act ac;if(q==a){int from=(choice&(1<<bit))?b:a;ac=T[from][bit];}else ac=T[q][bit];if(ac.z<0)return false;if(ac.w)t.set(h+OFF);else t.reset(h+OFF);h+=ac.d;q=ac.z;if(q==b)q=a;if(h+OFF<0||h+OFF>=512)return false;}return false;}
int main(int argc,char**argv){for(auto &row:T)for(auto &v:row)v={-1,-1,-1};ifstream tin(argv[1]);string line;while(getline(tin,line)){if(line.empty()||line[0]=='#')continue;istringstream in(line);int q,b,w,z;char d;in>>q>>b>>w>>d>>z;T[q][b]={w,d=='R'?1:-1,z};if(b==0)states.push_back(q);}ifstream sin(argv[2]);string pc,op;int arg,pos;while(sin>>pc>>op>>arg>>pos){Case c;c.pc=pc;c.op=op;c.arg=arg;c.pos=pos;vector<int>r(9);if(pos)r[arg]=1;c.init=frame(pc,r);int gap=1,shift=0;string nxt;bool extra=false;c.wantq=84;if(op=="CI"){r[arg]++;tie(nxt,shift)=inc(pc);extra=true;}else if(op=="CD"&&pos){r[arg]--;tie(nxt,shift)=inc(pc);gap++;}else if(op=="CD"||op=="CB")tie(nxt,shift)=inc(strip(pc,'0',op=="CB"?arg:1));else if(op=="CC")nxt=strip(pc,'1',arg);else{c.wantq=254;nxt="";}c.wanth=-shift;c.want=frame(nxt,r,gap+shift,shift,extra);cs.push_back(c);}for(int i=0;i<(int)cs.size();i++)if(!run(cs[i],-1,-1,0,true)){cerr<<"BAD BASE "<<i<<" "<<cs[i].pc<<" "<<cs[i].op<<"\n";return 1;}cerr<<"baseline cases "<<cs.size()<<"\n";long tested=0,surv=0;
int a=atoi(argv[3]);
vector<int> targets=states;targets.push_back(254);
for(int bit=0;bit<2;bit++){Act keep=T[a][bit];
for(int z:targets)for(int w=0;w<2;w++)for(int d:{-1,1}){
 T[a][bit]={w,d,z};bool ok=true;tested++;int failure=-1;
 for(int k=0;k<(int)cs.size();k++)if(cs[k].used[a])if(!run(cs[k])){ok=false;failure=k;break;}
 if(ok){cout<<"SURVIVOR "<<a<<" "<<bit<<" "<<w<<" "<<d<<" "<<z<<"\n";cout.flush();surv++;}
}
T[a][bit]=keep;}
cerr<<"tested "<<tested<<" survived "<<surv<<"\n";}
