#!/usr/bin/env python3
"""Check analytic nonhalting closures of saved constant-spare endpoints.

This checks endpoint descriptors and literal transition fragments. It does not
recompute the prefixes of all 557,280 bootstrap trajectories.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def read_table(path):
    table = {}
    for line in Path(path).read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        q, b, w, d, z = line.split()
        key = (int(q), int(b))
        assert key not in table and int(b) in (0, 1) and int(w) in (0, 1)
        assert d in ('L', 'R')
        table[key] = (int(w), -1 if d == 'L' else 1, int(z))
    states = {q for q, b in table}
    assert 254 not in states
    assert all((q, b) in table for q in states for b in (0, 1))
    assert all(z in states or z == 254 for w, d, z in table.values())
    return table, states


def classify(table_path, log_path, stderr_path):
    table, states = read_table(table_path)
    assert len(states) == 215
    words = Path(stderr_path).read_text().split()
    assert words[:4] == ['LIMIT', '250000', 'CASES', '557280']
    counts = {k: int(v) for k, v in (item.split('=') for item in words[4:])}
    assert sum(counts.values()) == 557280
    assert table[198, 0] == (0, -1, 301)
    helper = table[301, 1][2]
    assert table[301, 1] == (0, -1, helper) and helper in (54, 66)
    expected = {'BOUND': 4, 'HALT': 894, 'OUTWARD_RAY': 556374, 'SPACE_BOUND': 8}
    if helper == 66:
        expected.update(OUTWARD_RAY=553764, SPACE_BOUND=2618)
    assert counts == expected
    seen = set()
    closed = Counter()
    statuses = Counter()
    for line in Path(log_path).read_text().splitlines():
        f = line.split()
        assert len(f) == 14 and f[0] == 'ACTION' and f[4] == 'START' and f[6] == 'SEED'
        w, d, target = map(int, f[1:4])
        start, seed = int(f[5]), int(f[7])
        status = f[8]
        tick, q, h, lo, hi = map(int, f[9:])
        assert w in (0, 1) and d in (-1, 1) and target in states | {254}
        assert start in states and seed in (0, 1, 2)
        assert status in ('BOUND', 'SPACE_BOUND') and 0 <= tick <= 250000
        key = (w, d, target, start, seed)
        assert key not in seen
        seen.add(key)
        statuses[status] += 1
        blank = lo > hi
        def zero_at(x):
            return blank or x < lo or x > hi
        if (w, d, target) == (0, 1, 198) and q in (198, 301):
            other = h - 1 if q == 198 else h + 1
            assert status == 'BOUND' and tick == 250000
            assert zero_at(h) and zero_at(other)
            closed['exact_period_two'] += 1
        elif d == -1 and target == 198 and q in (198, 301):
            assert status == 'SPACE_BOUND' and (blank or h < lo)
            closed['left_two_state_ray'] += 1
        elif q == 66 and helper == 66:
            assert table[66, 0] == (1, 1, 198)
            assert status == 'SPACE_BOUND' and (blank or h + 1 < lo)
            closed['left_three_step_translation'] += 1
        else:
            raise AssertionError('Unclosed endpoint: ' + line)
    assert dict(statuses) == {k: counts[k] for k in ('BOUND', 'SPACE_BOUND')}
    assert closed['exact_period_two'] == 4 and closed['left_two_state_ray'] == 8
    assert closed['left_three_step_translation'] == (2610 if helper == 66 else 0)
    return {
        'status': 'ALL_SAVED_REMAINDERS_ANALYTICALLY_CLOSED',
        'table_sha256': hashlib.sha256(Path(table_path).read_bytes()).hexdigest(),
        'helper_target': helper, 'saved_cases': 557280,
        'saved_summary': counts, 'remainder_certificates': dict(closed),
        'calibrated_starts': 0, 'unresolved_saved_endpoints': 0,
        'scope': 'Conditional on the saved exact prefix endpoints; use replay.py to recompute prefixes.'
    }


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('table', type=Path)
    p.add_argument('log', type=Path)
    p.add_argument('stderr', type=Path)
    a = p.parse_args()
    print(json.dumps(classify(a.table, a.log, a.stderr), indent=2))
