#!/usr/bin/env python3
"""Quick package/log audit, with literal closures; does not repeat search screens."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'code'))
from classify_cleanup import classify, read_table


def check_boot(table_path, log_path):
    table, states = read_table(table_path)
    seen, counts = set(), Counter()
    for line in log_path.read_text().splitlines():
        f = line.split()
        assert len(f) == 8
        start, seed = map(int, f[:2])
        status = f[2]
        tick, q, head, lo, hi = map(int, f[3:])
        assert start in states and seed in (0, 1, 2) and 0 <= tick <= 1000000
        assert (start, seed) not in seen
        seen.add((start, seed))
        if status == 'HALT':
            assert q == 254
        else:
            assert status == 'OUTWARD_RAY'
            w, d, target = table[q, 0]
            assert target == q
            assert lo > hi or (d < 0 and head < lo) or (d > 0 and head > hi)
        counts[status] += 1
    assert len(states) == 215 and len(seen) == 645
    assert counts == {'HALT': 1, 'OUTWARD_RAY': 644}
    return dict(counts)


def check_q122_counterexample():
    table, states = read_table(ROOT / 'inputs/producer218_rejected.native.tm')
    assert len(states) == 218
    record = json.loads((ROOT / 'historical/producer218_cd1_1.json').read_text())
    ones = {-1, 64, 0, 1, 2}
    values = [0] * 10
    values[2] = 1  # Logical register 1 occupies physical position 2.
    p = 65
    for n in values:
        p += 1
        for k in range(n + 1):
            ones.add(p)
            p += 1
    q, head = 84, 0
    for tick in range(record['steps']):
        w, d, q = table[q, int(head in ones)]
        if w:
            ones.add(head)
        else:
            ones.discard(head)
        head += d
    actual = {'state': q, 'head': head, 'ones': sorted(ones)}
    assert actual == record['actual'] and actual != record['expected']
    return {'literal_steps_replayed': record['steps'], 'actual_differs_from_expected': True}


def main():
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    for rel, digest in manifest['files'].items():
        assert hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() == digest, rel
    receipt = json.loads((ROOT / 'late_search_receipt.json').read_text())
    for rel, digest in receipt['files'].items():
        assert hashlib.sha256((ROOT / 'historical' / rel).read_bytes()).hexdigest() == digest, rel
    sources = json.loads((ROOT / 'source_case_provenance.json').read_text())
    case_counts = {}
    for name, meta in sources.items():
        rows = [line.split() for line in (ROOT / meta['packaged_case_file']).read_text().splitlines()]
        assert len(rows) == meta['finite_cases']
        assert all(len(r) == 4 and set(r[0]) <= {'0', '1'} and r[1] in ('CI', 'CD', 'CC', 'CB', 'CH') and r[3] in ('0', '1') for r in rows)
        assert all(int(r[2]) == -1 if r[1] == 'CH' else int(r[2]) >= 0 for r in rows)
        assert sum(r[3] == '0' for r in rows) == meta['source_sites']
        case_counts[name] = len(rows)
    screens = json.loads((ROOT / 'replay_screens.json').read_text())
    cleanups, boots, merges = {}, {}, {}
    for name, screen in screens.items():
        assert (ROOT / screen['harness']).is_file()
        for arg in screen['arguments']:
            if '/' in arg:
                assert (ROOT / arg).is_file(), arg
        for field in ('saved_stdout', 'saved_stderr'):
            if screen.get(field):
                assert (ROOT / screen[field]).is_file()
        if screen.get('cleanup'):
            cleanups[name] = classify(ROOT / screen['arguments'][0], ROOT / screen['saved_stdout'], ROOT / screen['saved_stderr'])
        elif screen['harness'].endswith('boot_search.cpp'):
            boots[name] = check_boot(ROOT / screen['arguments'][0], ROOT / screen['saved_stdout'])
        elif 'merge' in Path(screen['harness']).name:
            lines = (ROOT / screen['saved_stderr']).read_text().splitlines()
            assert len(lines) == 2 and lines[0].startswith('baseline cases ')
            f = lines[1].split()
            assert f[0] == 'tested' and f[2:] == ['survived', '0']
            table, states = read_table(ROOT / screen['arguments'][0])
            assert int(f[1]) == 2 * (len(states)-1) * (len(states)-2)
            assert (ROOT / screen['saved_stdout']).read_text() == ''
            merges[name] = {'cases': int(lines[0].split()[-1]), 'tested': int(f[1]), 'saved_survivors': 0}
    baseline, states = read_table(ROOT / 'inputs/baseline215.native.tm')
    constant, cstates = read_table(ROOT / 'historical/constant_spare_fold215.native.tm')
    expected = {(88, 0): (0, -1, 51), (51, 0): (0, 1, 122), (87, 0): (0, 1, 88), (198, 0): (0, -1, 301), (301, 0): (0, 1, 0), (301, 1): (0, -1, 54)}
    assert cstates == states and len(states) == 215
    assert {key: constant[key] for key in constant if constant[key] != baseline[key]} == expected
    result = {'status': 'PACKET_AUDIT_PASS', 'manifest_files': len(manifest['files']), 'original_pins_checked': len(receipt['files']), 'source_case_counts': case_counts, 'saved_merge_summaries': merges, 'saved_boot_endpoint_certificates': boots, 'cleanup_endpoint_certificates': cleanups, 'q122_counterexample': check_q122_counterexample(), 'scope': 'Hash, saved-log, and endpoint-certificate audit. Mass searches are not rerun by this command.'}
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
