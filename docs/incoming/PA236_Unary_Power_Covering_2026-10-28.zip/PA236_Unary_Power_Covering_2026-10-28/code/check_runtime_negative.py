"""Reject malformed literal tables and disabled assertion checking."""
import json,tempfile,subprocess,sys
from pathlib import Path
import pa_symbolic as p
ROOT=Path(__file__).resolve().parents[1]
raw=(ROOT/'machines/pa236.native.tm').read_text();results=[]
for name,content in [('duplicate_row',raw+raw.splitlines()[1]+'\n'),('missing_row','\n'.join(raw.splitlines()[:-1])+'\n'),('bad_direction',raw.replace(' L ',' X ',1))]:
 with tempfile.NamedTemporaryFile('w',suffix='.tm') as f:
  f.write(content);f.flush()
  try:p.read_table(f.name)
  except ValueError:results.append({'test':name,'rejected':True})
  else:raise ValueError('negative accepted: '+name)
r=subprocess.run([sys.executable,'-O',str(ROOT/'code/pa_symbolic.py')],capture_output=True,text=True)
if r.returncode==0 or 'Universal checking requires enabled assertions' not in r.stderr:raise ValueError('optimized execution guard failed')
results.append({'test':'optimized_python_disabled_assertions','rejected':True})
(ROOT/'results/runtime_negative_controls.json').write_text(json.dumps(results,indent=2)+'\n')
print('PASS: four runtime negative controls')
