import argparse,json,time,hashlib
from pathlib import Path
import pa_symbolic as p
def validate_sites(sites):
 if not isinstance(sites,list) or not sites:raise ValueError('empty source')
 leaves=set();prefixes=set()
 for row in sites:
  if not isinstance(row,list) or len(row)!=3:raise ValueError('bad site')
  path,op,arg=row
  if not isinstance(path,str) or not path or len(path)>38 or set(path)-{'0','1'} or path in leaves:raise ValueError('bad path')
  if op not in ('CI','CD','CB','CC','CH'):raise ValueError('bad opcode')
  if op=='CH':
   if arg is not None:raise ValueError('bad halt')
  elif type(arg)!=int or (op in ('CI','CD') and not 0<=arg<9) or (op in ('CB','CC') and arg<1):raise ValueError('bad operand')
  leaves.add(path);prefixes.update(path[:i] for i in range(len(path)))
 if leaves&prefixes or any(x+b not in leaves|prefixes for x in prefixes for b in '01'):raise ValueError('incomplete source')
 if sum(r[1]=='CH' for r in sites)!=1:raise ValueError('halt count')

ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--table',default=str(ROOT/'machines/pa236.native.tm'));ap.add_argument('--sites',default=str(ROOT/'sources/sites236.json'));ap.add_argument('--output',default=str(ROOT/'results/runtime236.json'));a=ap.parse_args()
table_bytes=Path(a.table).read_bytes();source_bytes=Path(a.sites).read_bytes();checker_bytes=Path(__file__).read_bytes();engine_bytes=Path(p.__file__).read_bytes()
T=p.read_table(a.table);sites=json.loads(source_bytes);validate_sites(sites);L,C=p.find_blocks(T);start=time.monotonic();results=[];used=set()
for i,s in enumerate(sites):
 for b in ((False,True) if s[1]=='CD' else (False,)):
  for spare in (False,True):
   try:r=p.case(T,L,s,b,spare)
   except Exception as e:
    Path(a.output).write_text(json.dumps({'status':'FAIL','index':i,'site':s,'positive':b,'spares':spare,'reason':repr(e)},indent=2)+'\n');raise
   used.update(tuple(x)for x in r.pop('rows'));results.append({'site':i,'positive':b,'spares':spare,**r})
 if i%500==0:print(i,len(results),round(time.monotonic()-start,2),flush=True)
if Path(a.table).read_bytes()!=table_bytes or Path(a.sites).read_bytes()!=source_bytes or Path(__file__).read_bytes()!=checker_bytes or Path(p.__file__).read_bytes()!=engine_bytes:raise ValueError('files changed during check')
report={'checker_sha256':hashlib.sha256(checker_bytes).hexdigest(),'engine_sha256':hashlib.sha256(engine_bytes).hexdigest(),'status':'PASS','cases':len(results),'sites':len(sites),'seconds':time.monotonic()-start,'table_sha256':hashlib.sha256(Path(a.table).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(Path(a.sites).read_bytes()).hexdigest(),'used_rows':sorted(used),'block_certificates':C,'minimum_steps':min(x['duration'][0]for x in results),'scope':'Symbolic arbitrary nine register values, both guarded decrement cases, arbitrary extra gap, empty or nonempty arbitrary spare list. Ordinary mathematical checker, not kernel certificate.'}
Path(a.output).write_text(json.dumps(report,indent=2)+'\n');Path(a.output+'.cases.json').write_text(json.dumps(results)+'\n');print(report['status'],report['cases'],report['seconds'])
