"""Independent owned replay: deterministic builders, ordinal CFG and dense labels."""
import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def need(x,m):
 if not x:raise ValueError(m)
def cfg(rows):
 """Resolve control flow by intervals of source prefixes, not numeric PC arithmetic."""
 span={}
 for i,(p,op,arg) in enumerate(rows):
  for k in range(len(p)+1):
   key=p[:k]
   if key not in span:span[key]=[i,i+1]
   else:span[key][1]=i+1
 result=[]
 for i,(p,op,arg) in enumerate(rows):
  following=(i+1)%len(rows)
  def jump(bit,count):
   places=[j for j,b in enumerate(p)if b==bit]
   if len(places)<count:return 0
   lo,hi=span[p[:places[-count]]]
   return (hi%len(rows)) if bit=='0'else lo
  if op=='CI':v=['increment',arg,[following]]
  elif op=='CD':v=['decrement',arg,[jump('0',1),following]]
  elif op=='CB':v=['identity',None,[jump('0',arg)]]
  elif op=='CC':v=['identity',None,[jump('1',arg)]]
  else:need(op=='CH','opcode');v=['halt',None,[]]
  result.append(v)
 return result
def graph_numeric(rows):
 labels={p:i for i,(p,op,a)in enumerate(rows)};size=len(rows)
 def locate(p):
  choices=[(k,i)for k,i in labels.items()if p.startswith(k)or k.startswith(p)]
  need(bool(choices),'missing successor')
  k,i=min(choices,key=lambda x:x[0])
  if p.startswith(k):need('1'not in p[len(k):],'stray successor bits')
  else:need('1'not in k[len(p):],'not leftmost')
  return i
 def increment(p):
  if not p:return ''
  return format((int(p,2)+1)%(1<<len(p)),f'0{len(p)}b')
 out=[]
 for p,op,a in rows:
  def cut(bit,n):
   positions=[j for j,v in enumerate(p)if v==bit]
   return p[:positions[-n]]if len(positions)>=n else ''
  nxt=locate(increment(p))
  if op=='CI':v=['increment',a,[nxt]]
  elif op=='CD':v=['decrement',a,[locate(increment(cut('0',1))),nxt]]
  elif op=='CB':v=['identity',None,[locate(increment(cut('0',a)))]]
  elif op=='CC':v=['identity',None,[locate(cut('1',a))]]
  else:v=['halt',None,[]]
  out.append(v)
 return out

def run():
 with tempfile.TemporaryDirectory(prefix='pa237-construction-')as d:
  d=Path(d)
  subprocess.run([sys.executable,*(['-O'] if sys.flags.optimize else []),str(ROOT/'code/build_machine.py'),str(ROOT/'machines/pa238.tm'),str(d/'machine')],check=True,capture_output=True)
  subprocess.run([sys.executable,*(['-O'] if sys.flags.optimize else []),str(ROOT/'code/build_source.py'),str(ROOT/'sources/sites238.json'),str(d/'source')],check=True,capture_output=True)
  for f in('pa237.native.tm','pa237.tm','rotated238.tm','renaming.json'):need((d/'machine'/f).read_bytes()==(ROOT/'machines'/f).read_bytes(),f)
  need((d/'source/sites.json').read_bytes()==(ROOT/'sources/sites237.json').read_bytes(),'source bytes')
 a=json.loads((ROOT/'sources/sites238.json').read_text());b=json.loads((ROOT/'sources/sites237.json').read_text())
 need([r[1:]for r in a]==[r[1:]for r in b],'primitive order')
 need(cfg(a)==cfg(b)==graph_numeric(a)==graph_numeric(b),'four control graphs')
 return {'status':'pass','working_states':237,'transition_rows':474,'primitive_occurrences':len(a),'four_control_graphs_identical':True,'dense_sha256':hashlib.sha256((ROOT/'machines/pa237.tm').read_bytes()).hexdigest()}
if __name__=='__main__':print(json.dumps(run(),sort_keys=True))
