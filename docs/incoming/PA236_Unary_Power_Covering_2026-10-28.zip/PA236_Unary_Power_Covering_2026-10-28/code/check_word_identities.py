"""Finite regression tests for identities separately justified by induction."""
from itertools import product
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
def blocks(a,f):
 return ''.join(('0'+'1'*(v+1))if f=='B' else ('10'+'1'*v)if f=='C' else ('1'*(v+1)+'0')for v in a)
n=0
for k in range(5):
 for a in product(range(4),repeat=k):
  B,C,D=(blocks(a,f)for f in 'BCD')
  if C+'1'!='1'+B or '0'+D!=B+'0' or B[::-1]+'1'!='1'+C[::-1] or D[::-1]+'0'!='0'+B[::-1]:raise ValueError(('word identity',a))
  n+=1
(ROOT/'results/word_identities.json').write_text(json.dumps({'status':'PASS','lists':n,'identities_per_list':4,'scope':'Finite regression tests only; arbitrary-list validity follows by induction.'},indent=2)+'\n')
print('PASS',n,'lists and four identities each')
