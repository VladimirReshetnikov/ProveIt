from pathlib import Path
import json,hashlib
import pa_symbolic as p
H=Path(__file__).resolve().parents[1]
expected_word='0'*38+'1'+''.join('0'+'1'*(v+1)for v in [0,2,0,0,0,0,6,0,0]+[0]*5+[1]+[0]*318)
expected={i for i,b in enumerate(expected_word)if b=='1'}|{-1}
results=[]
for file in ['machines/pa238.tm','machines/pa237.native.tm','machines/pa236.native.tm']:
 raw=(H/file).read_bytes();T=p.read_table(H/file);tape=set();q=0;head=0;used=set()
 for n in range(799504):
  if q==238:raise ValueError('early halt')
  b=int(head in tape);used.add((q,b));w,d,q=T[q,b]
  if w:tape.add(head)
  else:tape.discard(head)
  head+=d
 shifted={i-head for i in tape}
 if q!=25 or shifted!=expected:raise ValueError(('checkpoint mismatch',file,q,head,len(tape),len(expected),sorted(shifted^expected)[:20]))
 results.append({'table':file,'sha256':hashlib.sha256(raw).hexdigest(),'steps':799504,'state':q,'head':head,'ones':len(tape),'relative_tape_match':True,'active_registers':[0,2,0,0,0,0,6,0,0],'spare_registers':324,'gap':38,'used_rows':sorted(used)})
print(json.dumps([{k:v for k,v in x.items()if k!='used_rows'}for x in results],indent=2))
(H/'results/startup_results.json').write_text(json.dumps(results,indent=2)+'\n')
