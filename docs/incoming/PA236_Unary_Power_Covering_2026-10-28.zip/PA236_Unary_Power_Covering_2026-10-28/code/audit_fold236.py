"""Independent finite-window proof certificate for the second PA236 fold.
Python standard library only. No generator modules are imported.
"""
from pathlib import Path
from collections import deque
import argparse, json, hashlib

EXPECTED_SHA256 = "dca55c1cf0a0d4e603194b7ae7a2128aa8870e368a8ace303433689316b28879"

def req(value, message):
 if not value: raise ValueError(message)

def table(path):
 out={}
 for line in path.read_text().splitlines():
  if not line or line.startswith('#'):continue
  q,s,w,d,z=line.split();q,s,w,z=map(int,(q,s,w,z))
  req((q,s)not in out,'duplicate transition');req(s in(0,1)and w in(0,1)and d in('L','R'),'bad transition')
  out[q,s]=(w,1 if d=='R'else -1,z)
 return out

def check(P):
 j=json.loads((P/'sources/construction_recipe236.json').read_text())
 T=table(P/'machines/rotated237.tm')
 req(T=={(q,b):(w,1 if d=='R'else -1,z)for q,b,w,d,z in j['table']},'recipe/intermediate mismatch')
 U=table(P/'machines/pa236.native.tm');keep,drop=j['merge'];h=j['helper'];b=j['branch'];r=3;k=2*r+1;mask=(1<<k)-1
 S={(0,0)};Q=deque(S)
 while Q:
  q,x=Q.popleft()
  if q==238:continue
  w,d,n=T[q,(x>>r)&1];y=(x&~(1<<r))|w<<r
  a=y>>1 if d==1 else (y<<1)&mask
  for z in(a,a|(1<<(k-1)if d==1 else 1)):
   if(n,z)not in S:S.add((n,z));Q.append((n,z))
 counts={}
 for tag,q in enumerate((keep,drop)):
  X=[x for p,x in S if p==q];req(X,'unreachable');req(all((x>>(r-1))&1==tag for x in X),'tag')
  counts[q]=len(X)
  for x in X:
   read=(x>>r)&1;w,d,z=T[q,read];expected=(keep if z==drop else z,(x&~(1<<r))|w<<r,r+d)
   state,y,pos=keep,x,r
   for _ in range(3 if read==b else 1):
    req(0<=pos<k,'outside read');w,d,state=U[state,(y>>pos)&1];y=(y&~(1<<pos))|w<<pos;pos+=d
   req((state,y,pos)==expected,'macro mismatch')
 # Every other transition exactly relabels only drop targets.
 for(q,s),(w,d,z)in T.items():
  if q in(keep,drop):continue
  req(U[q,s]==(w,d,keep if z==drop else z),'unexpected change')
 req(len(U)==472,'not236states');req({q for q,s in U}==set(range(238))-{drop,208},'states')
 ren={int(k):v for k,v in json.loads((P/'machines/renaming236.json').read_text()).items()}
 V={(ren[q],s):(w,d,ren[z])for(q,s),(w,d,z)in U.items()}
 req(V==table(P/'machines/pa236.tm'),'renaming')
 res={'status':'pass','radius':r,'invariant_nodes':len(S),'guarded_state_windows':counts,'macro_cases':sum(counts.values()),'new_states':236,'table_sha256':hashlib.sha256((P/'machines/pa236.tm').read_bytes()).hexdigest(),'scope':'rotated237 to236 all reachable configurations by finite inductive window invariant; rotations require separate source-level proof'}
 req(res['table_sha256']==EXPECTED_SHA256,'unexpected final table identity')
 return res

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--output',type=Path);args=ap.parse_args()
 result=check(args.root);encoded=json.dumps(result,indent=2,sort_keys=True)+'\n'
 if args.output:args.output.write_text(encoded)
 print(encoded,end='')
