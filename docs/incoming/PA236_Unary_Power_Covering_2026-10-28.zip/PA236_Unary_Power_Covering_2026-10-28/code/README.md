# PA236 and PA237 deterministic construction

The final construction is PA236. PA237 is retained as its checked intermediate. Run both stages from the extracted package root:

    python code/check_construction.py
    python code/check_construction236.py
    python -O code/check_construction.py
    python -O code/check_construction236.py

To rebuild the second stage separately:

    python code/build_machine236.py machines/pa237.native.tm rebuilt-machine236
    python code/build_source236.py sources/sites237.json rebuilt-source236

The second stage performs four further closed source rotations followed by a second predecessor-tag selector fold. Native labels omit180 and208 and retain halt238. Dense PA236 has working states0..235 and separate halt236, with472 transition rows. The output renaming.json corresponds to the sealed machines/renaming236.json. All second-stage source and table files use distinct names; the PA237 intermediate is unchanged.

The construction checks alone do not establish arbitrary-tape runtime correctness. The report and dedicated runtime audit record that separate gate and its validation status.

## First stage details

Python 3.10 or later; standard library only. Run from the extracted package root:

    python code/check_construction.py
    python -O code/check_construction.py

To rebuild the individual artifacts into fresh directories:

    python code/build_machine.py machines/pa238.tm rebuilt-machine
    python code/build_source.py sources/sites238.json rebuilt-source

The machine builder pins the exact original PA238 table, performs two explicit decoder rotations, and folds one tagged state through an existing selector. It writes the rotated238 table, native237 table retaining original labels, densely numbered237 table, and renaming map. Native halt is238; dense halt is237. All checks use explicit exceptions, remaining active under optimized Python.

The source builder pins the original physical source inventory and performs the matching three occurrence-level rotations: physical182/200 occurs twice and physical159/164 occurs once. It checks closed source factors, unchanged primitive instruction order, and maximum instruction-pointer zero run6. It writes sites.json and source_rotation_checks.json.

The replay checker compares rebuilt bytes against the sealed artifacts and independently resolves source control flow in two ways: subtree intervals and binary successor/cut arithmetic. The original and transformed graphs must all agree. These are construction checks, not the full Turing runtime verification. Runtime evidence and its scope are documented separately in the report.

These three Python files were authored for this investigation. They execute no incoming archive scripts and use no external Python packages. The baseline table and physical source inventory remain attributed to Mira-Cult's PA238 construction and Jeff Ketchersid's upstream verification. The new tables and source inventory are deterministic modifications of that attributed baseline. Source-level reassociation and predecessor-tag state sharing are inherited techniques; the contribution is their particular checked composition for PA237, not invention of either technique.

Do not substitute the earlier one-rotation candidate. It generated an invalid7-zero instruction-pointer path. The second rotation is required, and the rejected version is not part of these machine artifacts.
