"""Owned deterministic PA237-to-PA236 construction; no search."""
import json,hashlib,argparse
from pathlib import Path

def need(x,m):
 if not x:raise ValueError(m)
def construct(raw):
 need(hashlib.sha256(raw).hexdigest()=='697556f8521096771380c0e220190c9ad5b9915ea5c40149579185442bebda95','PA237 SHA')
 T={}
 for l in raw.decode().splitlines():
  if not l or l.startswith('#'):continue
  q,b,w,d,z=l.split();T[int(q),int(b)]=(int(w),d,int(z))
 for q,r,side,ends in [(206,222,1,(198,222,230,199)),(163,169,0,(169,170,103,39)),(203,219,1,(89,219,230,221)),(169,170,1,(39,170,180,181))]:
  need([T[q,0],T[q,1],T[r,0],T[r,1]]==[(b,'R',v)for b,v in zip((0,1,0,1),ends)],'rotation rows')
  need(sorted((a,b)for(a,b),v in T.items()if v[2]==r)==[(q,side)],'inner entrance')
  U=T.copy()
  if side==0:
   U[q,0]=(0,'R',T[r,0][2]);U[q,1]=(1,'R',r);U[r,0]=(0,'R',T[r,1][2]);U[r,1]=(1,'R',T[q,1][2])
  else:
   U[q,0]=(0,'R',r);U[q,1]=(1,'R',T[r,1][2]);U[r,0]=(0,'R',T[q,0][2]);U[r,1]=(1,'R',T[r,0][2])
  T=U
 pre=T.copy();need(T[222,0]==T[180,0]==(0,'R',198),'common branch')
 need(sorted((q,b)for(q,b),v in T.items()if v[2]==222)==[(206,0)],'tag0');need(T[206,0]==(0,'R',222),'tag0 write')
 need(sorted((q,b)for(q,b),v in T.items()if v[2]==180)==[(170,1)],'tag1');need(T[170,1]==(1,'R',180),'tag1 write')
 need(T[203,0]==(0,'R',219)and T[203,1]==(1,'R',221),'selector')
 need(T[219,1]==T[222,1]and T[221,1]==T[180,1],'branch replay')
 T[222,1]=(1,'L',203);T={(q,b):(w,d,222 if z==180 else z)for(q,b),(w,d,z)in T.items()if q!=180}
 qs=sorted({q for q,b in T});need(len(qs)==236 and len(T)==472,'size');need({z for w,d,z in T.values()}-set(qs)=={238},'halt')
 ren={q:i for i,q in enumerate(qs)};ren[238]=236;return pre,T,ren
def render(T,r):return ('#! start 0\n'+''.join(f'{r[q]} {b} {w} {d} {r[z]}\n'for(q,b),(w,d,z)in sorted(T.items()))).encode()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('output',type=Path);a=p.parse_args();pre,T,ren=construct(a.baseline.read_bytes());a.output.mkdir(parents=True,exist_ok=True)
 for f,t,r in [('rotated237.tm',pre,{q:q for q in range(239)}),('pa236.native.tm',T,{q:q for q in range(239)}),('pa236.tm',T,ren)]:(a.output/f).write_bytes(render(t,r))
 (a.output/'renaming.json').write_text(json.dumps(ren,indent=2)+'\n');print(json.dumps({'working_states':236,'native_sha256':hashlib.sha256(render(T,{q:q for q in range(239)})).hexdigest(),'dense_sha256':hashlib.sha256(render(T,ren)).hexdigest()}))
