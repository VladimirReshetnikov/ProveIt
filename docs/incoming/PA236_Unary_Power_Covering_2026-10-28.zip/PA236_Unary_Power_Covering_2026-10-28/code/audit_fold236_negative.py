"""Three isolated mutation controls for the independent fold verifier."""
from pathlib import Path
import argparse, tempfile, shutil, json
from audit_fold236 import check, req

def test(root):
 results=[]
 controls=[('fold-direction','222 1 1 L 203','222 1 1 R 203','macro mismatch'),('helper-target','203 0 0 R 219','203 0 0 R 218','macro mismatch'),('unrelated-transition','0 0 1 L 1','0 0 0 L 1','unexpected change')]
 for name,old,new,expected in controls:
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)
   for directory in ('machines','sources'):
    shutil.copytree(root/directory,p/directory)
   f=p/'machines/pa236.native.tm';s=f.read_text();req(old in s,'missing mutation target');f.write_text(s.replace(old,new,1))
   try:check(p)
   except ValueError as e:
    req(str(e)==expected,'wrong rejection reason');results.append({'mutation':name,'rejected':str(e)})
   else:raise ValueError('negative control accepted')
 return results

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--output',type=Path);args=ap.parse_args()
 encoded=json.dumps(test(args.root),indent=2,sort_keys=True)+'\n'
 if args.output:args.output.write_text(encoded)
 print(encoded,end='')
