"""Owned deterministic physical source transformation, standard library only."""
import json,hashlib,argparse
from pathlib import Path
from functools import cache

def require(x,m):
 if not x:raise ValueError(m)
def leaf(n):return isinstance(n[0],str)
def parse(rows):
 trie={}
 for p,op,arg in rows:
  require(p and set(p)<={'0','1'},'path')
  t=trie
  for b in p:
   require('leaf' not in t,'overlap');t=t.setdefault(b,{})
  require(not t,'duplicate');t['leaf']=(op,arg)
 def rec(t):
  if 'leaf'in t:require(len(t)==1,'overlap');return t['leaf']
  require(set(t)=={'0','1'},'full tree');return rec(t['0']),rec(t['1'])
 return rec(trie)
def rows(n,p=''):
 if leaf(n):return[[p,*n]]
 return rows(n[0],p+'0')+rows(n[1],p+'1')
@cache
def boundary(n):
 if leaf(n):
  op,a=n
  return (1,0,False)if op=='CD'else(a,0,False)if op=='CB'else(0,a,False)if op=='CC'else(0,0,op=='CH')
 a,b=boundary(n[0]),boundary(n[1]);return max(max(a[0]-1,0),b[0]),max(a[1],max(b[1]-1,0)),a[2]or b[2]
def at(n,p):
 for b in p:n=n[int(b)]
 return n
def replace(n,p,v):
 if not p:return v
 a=list(n);b=int(p[0]);a[b]=replace(a[b],p[1:],v);return tuple(a)
def construct(raw):
 require(hashlib.sha256(raw).hexdigest()=='6a363fea1c71fd7ba59b5996cfdd59f3893568ca3a4e30b8a59a844251cbd5df','baseline source SHA')
 original=json.loads(raw);r=parse(original);require(rows(r)==original,'canonical rows');proof=[]
 for outer,inner,paths in [(182,200,['111010010011001100','1110100100110011101']),(159,164,['111010010011001'])]:
  for p in paths:
   n=at(r,p);require(not leaf(n)and not leaf(n[1]),'rotation shape');a,(b,c)=n
   require(all(boundary(v)==(0,0,False)for v in(a,b,c)),'closed factors')
   proof.append({'outer':outer,'inner':inner,'path':p,'factor_leaf_counts':[len(rows(v))for v in(a,b,c)]})
   r=replace(r,p,((a,b),c))
 final=rows(r);require([v[1:]for v in final]==[v[1:]for v in original],'primitive sequence')
 maxzero=max(len(z)for p,op,a in final for z in p.split('1'));require(maxzero==6,'delimiter bound')
 return final,{'rotations':proof,'primitive_occurrences':len(final),'maximum_zero_run':maxzero}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('baseline_sites',type=Path);p.add_argument('output',type=Path);a=p.parse_args();r,e=construct(a.baseline_sites.read_bytes());a.output.mkdir(parents=True,exist_ok=True);raw=json.dumps(r,indent=2).encode();(a.output/'sites.json').write_bytes(raw);(a.output/'source_rotation_checks.json').write_text(json.dumps(e,indent=2)+'\n');print(hashlib.sha256(raw).hexdigest())
