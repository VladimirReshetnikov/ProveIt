"""Deterministic two-rotation/one-fold construction from original PA238.
No search and no incoming-code execution. Python 3 standard library only.
The mathematical source/runtime transport is a separate proof obligation.
"""
import argparse,hashlib,json
from pathlib import Path

def require(x,m):
 if not x:raise ValueError(m)
def read(raw):
 T={}
 for l in raw.decode('ascii').splitlines():
  if not l or l.startswith('#'):continue
  q,b,w,d,z=l.split();key=int(q),int(b)
  require(key not in T,'duplicate row');T[key]=int(w),d,int(z)
 return T
def render(T,ren=None):
 if ren is None:ren={q:q for q in range(239)}
 return ('#! start 0\n'+''.join(f'{ren[q]} {b} {w} {d} {ren[z]}\n'for(q,b),(w,d,z)in sorted(T.items()))).encode('ascii')
def construct(raw):
 require(hashlib.sha256(raw).hexdigest()=='ffe370842d70bae96688ad5e290073edffe0bb213cf12fe562a75a74bec966de','baseline SHA')
 T=read(raw);require(set(T)=={(q,b)for q in range(238)for b in(0,1)},'baseline totality')
 expect={(182,0):(0,'R',83),(182,1):(1,'R',200),(200,0):(0,'R',217),(200,1):(1,'R',198)}
 require(all(T[k]==v for k,v in expect.items()),'rotation rows')
 require([(q,b)for(q,b),v in T.items()if v[2]==200]==[(182,1)],'inner sole incoming')
 T.update({(182,0):(0,'R',200),(182,1):(1,'R',198),(200,0):(0,'R',83),(200,1):(1,'R',217)})
 require(T[159,0]==(0,'R',163) and T[159,1]==(1,'R',164) and T[164,0]==(0,'R',171) and T[164,1]==(1,'R',172),'repair rotation rows')
 require(sorted((q,b)for(q,b),v in T.items()if v[2]==164)==[(159,1)],'repair sole incoming')
 T.update({(159,0):(0,'R',164),(159,1):(1,'R',172),(164,0):(0,'R',163),(164,1):(1,'R',171)})
 pre=T.copy()
 require(T[200,1]==T[208,1]==(1,'R',217),'shared branch')
 require(T[230,0]==(0,'R',202)and T[230,1]==(1,'R',234),'selector')
 require(T[202,0]==T[200,0]and T[234,0]==T[208,0],'emulated branch')
 require(sorted((q,b)for(q,b),v in T.items()if v[2]==200)==[(182,0)],'tag0 incoming')
 require(sorted((q,b)for(q,b),v in T.items()if v[2]==208)==[(188,1)],'tag1 incoming')
 require(T[188,1]==(1,'R',208),'tag1 written')
 T[200,0]=(0,'L',230)
 T={(q,b):(w,d,200 if z==208 else z)for(q,b),(w,d,z)in T.items()if q!=208}
 qs=sorted({q for q,b in T});require(len(qs)==237,'working states')
 require(set(T)=={(q,b)for q in qs for b in(0,1)},'totality')
 require({v[2]for v in T.values()}-set(qs)=={238},'unique halt')
 ren={q:i for i,q in enumerate(qs)};ren[238]=237
 return pre,T,ren
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('output',type=Path);a=p.parse_args();pre,T,ren=construct(a.baseline.read_bytes());a.output.mkdir(parents=True,exist_ok=True)
 for name,raw in [('rotated238.tm',render(pre)),('pa237.native.tm',render(T)),('pa237.tm',render(T,ren)),('renaming.json',(json.dumps(ren,indent=2)+'\n').encode())]:(a.output/name).write_bytes(raw)
 print(json.dumps({'working_states':237,'transition_rows':474,'native_sha256':hashlib.sha256(render(T)).hexdigest(),'dense_sha256':hashlib.sha256(render(T,ren)).hexdigest()},sort_keys=True))
