"""Replay the second fold and four preceding source rotations independently."""
import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
from check_construction import need,cfg,graph_numeric
ROOT=Path(__file__).resolve().parents[1]
def run():
 with tempfile.TemporaryDirectory(prefix='pa236-construction-')as d:
  d=Path(d)
  subprocess.run([sys.executable,*(['-O'] if sys.flags.optimize else []),str(ROOT/'code/build_machine236.py'),str(ROOT/'machines/pa237.native.tm'),str(d/'machine')],check=True,capture_output=True)
  subprocess.run([sys.executable,*(['-O'] if sys.flags.optimize else []),str(ROOT/'code/build_source236.py'),str(ROOT/'sources/sites237.json'),str(d/'source')],check=True,capture_output=True)
  for f in('pa236.native.tm','pa236.tm','rotated237.tm'):need((d/'machine'/f).read_bytes()==(ROOT/'machines'/f).read_bytes(),f)
  need((d/'machine/renaming.json').read_bytes()==(ROOT/'machines/renaming236.json').read_bytes(),'renaming')
  need((d/'source/sites.json').read_bytes()==(ROOT/'sources/sites236.json').read_bytes(),'source bytes')
 a=json.loads((ROOT/'sources/sites237.json').read_text());b=json.loads((ROOT/'sources/sites236.json').read_text())
 need([r[1:]for r in a]==[r[1:]for r in b],'primitive order');need(cfg(a)==cfg(b)==graph_numeric(a)==graph_numeric(b),'four control graphs')
 return {'status':'pass','working_states':236,'transition_rows':472,'primitive_occurrences':len(a),'four_control_graphs_identical':True,'dense_sha256':hashlib.sha256((ROOT/'machines/pa236.tm').read_bytes()).hexdigest()}
if __name__=='__main__':print(json.dumps(run(),sort_keys=True))
