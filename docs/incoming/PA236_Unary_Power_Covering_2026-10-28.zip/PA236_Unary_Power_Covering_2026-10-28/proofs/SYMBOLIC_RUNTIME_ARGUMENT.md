# Symbolic runtime verification argument

This is an ordinary finite symbolic derivation checker, not a proof-assistant kernel certificate.

A tape is represented by two nearest-cell-first lists and a direction saying which list is currently under the head. Segments are finite constant-bit runs of affine lengths, an arbitrary finite list of unary register blocks, opaque contexts (for local macro proofs), or infinite blank exterior. Affine variables denote natural numbers. Nonnegative coefficients certify nonnegative lengths; a positive constant term certifies nonempty length for a literal transition. The spare-tail width variable denotes its actual total block width, not a second independently chosen tape.

Three register block families have equal width v+2:
B(v)=0 1^(v+1), C(v)=1 0 1^v, D(v)=1^(v+1) 0.
For any finite sequence A of natural values, concatenated block words satisfy C(A)1=1B(A) and 0D(A)=B(A)0. The empty case is immediate; the cons case follows by cancellation and concatenation. Reversals are also valid. These identities justify normalization and the on-demand boundary exposure rev(B(A))1=1rev(C(A)).

The only execution rules are:
1. One literal table transition on a provably present cell.
2. A same-state, same-direction scan over an arbitrary homogeneous run. Its validity is induction on the natural run length, including zero.
3. A finite-list traversal. Before use, the checker symbolically proves the exact one-block transformation at the specified state and direction, retaining arbitrary left and right opaque contexts and returning to the same state/direction. It checks time v+2 and displacement of that signed width. Induction on the finite list yields the list rule.

All such block rules are freshly discovered and proved from the supplied table. They are not imported as unchecked PA238 state signatures.

The case checker starts with nine independently variable logical registers, permuted into the actual physical order. Each decrement is split into zero and successor cases. Spare registers are covered by two exhaustive cases: no spares; one arbitrary first spare followed by an arbitrary finite tail. Each case starts with gap 38 minus path length plus an arbitrary natural extra gap. The target preserves the complete tape, with the correct register update, successor program counter, and overflow adjustment. A positive decrement appends a zero spare. An increment does not append a spare in PA238.

Success requires exact symbolic normalization equality with that complete target and a duration whose constant term is positive. A halt site must reach terminal state 238 after positive time. The construction-loop bound of 4000 limits only proof search: natural register values, gap, and spare-list length remain unbounded.

For a modified source, separately establish complete source coverage, the intended control-flow graph, and source equivalence. For a modified table, separately establish literal blank startup and all source-site cases. Positive per-instruction durations and deterministic execution then establish reflection of a finite literal halt, by induction on the length of the literal halting computation. A forward register halting computation composes the finite positive site segments. These give an ordinary mathematical halting equivalence, provided all listed premises are checked.
