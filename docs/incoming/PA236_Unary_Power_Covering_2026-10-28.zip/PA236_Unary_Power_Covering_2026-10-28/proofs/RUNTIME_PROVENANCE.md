# Runtime-checker provenance

The new PA checker adapts the earlier self-authored `baseline226/vendor/proveit/symbolic_runtime.py` mathematical checker from our K225 proof packet. Its generic affine-run zipper, unary induction, and finite-list induction are retained. No downloaded executable code or proof-assistant kernel is imported.

The present version removes the old external runtime helper; derives block traversal rules from the actual supplied PA table; introduces the D(v)=1^(v+1)0 block family and its exact boundary identities; uses the PA physical register permutation, state25 dispatcher, gap38, terminal238, and PA-specific spare behavior; covers empty and nonempty spare lists separately; and validates table/source inputs and byte immutability during each complete run.

The wrappers, PA case specification, startup replay, and negative controls are newly authored for this construction. The symbolic checker deliberately refuses optimized Python because proof obligations use runtime assertions. This refusal is tested as a negative control. It is not an optimized-mode verification pass.

The source and machine ancestry is independently recorded in the main report. Successful symbolic checks are ordinary mathematical evidence whose soundness is explained in SYMBOLIC_RUNTIME_ARGUMENT.md, not a fresh Rocq or Lean kernel certificate.
