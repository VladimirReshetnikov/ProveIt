# PA236 and unary power covering consistency

Start with report.pdf. Its editable source is report.tex and proofs/main.tex.

Main artifact: machines/pa236.tm is a complete deterministic binary machine
with 236 working states, 472 transitions, initial state 0 and separate halt236.
Initialization on a two-way infinite blank tape is included. The native-label
companion is machines/pa236.native.tm, with terminal238 and two deleted labels.
The earlier verified237-state construction is retained as an intermediate.

Claim: PA proves nonhalting of this machine on blank tape iff Con(U), where U
is the unary weak power-covering theory in the user-designated manuscript.
The new machine proof is ordinary mathematics supported by finite symbolic
certificates. The underlying PA238 endpoint and U/PA proof translations are
explicit inherited dependencies. No new kernel-checked full formalization,
complete generated PA derivation, or global state minimum is claimed.

## Reproduce

Python3 standard library is sufficient. From this directory:

    python replay.py --receipt /tmp/pa236-replay.json

The replay checks hashes and complete file inventory; uses a temporary copy;
rebuilds both machines and sources in normal and optimized Python; audits both
contextual folds and negative controls; checks exact799504-step blank startup;
and checks all11464 symbolic runtime cases for each of238,237,236 in parallel.
All sealed original files remain unchanged. Runtime verification deliberately
rejects Python -O because its symbolic derivation engine uses assertions.
This refusal is checked as a negative control. Do not confuse it with the
successful -O tests of the separate construction/fold checkers.

The full symbolic checks may take several minutes. They quantify over all
natural register values, all admissible gaps, and every finite spare list.
The execution limit bounds symbolic proof search, not those values.

Build the PDF in a standard TeXLive installation with:

    pdflatex -no-shell-escape report.tex
    pdflatex -no-shell-escape report.tex

## Evidence and attribution

Sources and machine hashes are in sources/ and manifest.json. The report gives
human-readable proofs; proofs/SYMBOLIC_RUNTIME_ARGUMENT.md gives more detail
on the symbolic derivation rules. Results include exact source/control-flow,
construction, fold, startup, block identity, and runtime receipts. Dynamic
elapsed times need not reproduce byte-for-byte.

The original PA238 machine is credited to Mira; its public formal verification
is from jeff87654/busy-beaver. Closed source reassociations and contextual
selector sharing build on the earlier K-machine work. The linked U manuscript
is an inherited theory proof and is reproduced as TeX under sources/U.
See sources/NOTICE.txt and sources/baseline_provenance.json.

An initial one-rotation237-state candidate failed the runtime verification
because it introduced a seven-zero instruction address. It is discussed in
the report, but its table is NOT supplied as a verified construction. The
second rotation repairs this issue before the accepted237 and236 reductions.
