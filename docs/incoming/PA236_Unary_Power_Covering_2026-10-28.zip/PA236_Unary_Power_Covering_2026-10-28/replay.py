#!/usr/bin/env python3
"""Replay in a disposable copy; sealed archive files are never modified."""
import argparse,hashlib,json,pathlib,shutil,subprocess,sys,tempfile,concurrent.futures
ROOT=pathlib.Path(__file__).resolve().parent

def seal(root):
 m=json.loads((root/'manifest.json').read_text())
 if not m or 'report.pdf' not in m or 'report.tex' not in m or 'replay.py' not in m:raise ValueError('incomplete manifest')
 actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts}
 if actual!=set(m):raise ValueError('file inventory mismatch')
 for name,want in m.items():
  p=pathlib.PurePosixPath(name)
  if p.is_absolute() or '..'in p.parts or (root/name).is_symlink():raise ValueError('unsafe path')
  if hashlib.sha256((root/name).read_bytes()).hexdigest()!=want:raise ValueError('hash mismatch: '+name)
 return len(m)

def run(root,args):
 r=subprocess.run([sys.executable,*args],cwd=root,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(' '.join(args)+'\n'+r.stdout+'\n'+r.stderr)
 return {'command':args,'status':'PASS','stdout':r.stdout[-1500:]}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--receipt',type=pathlib.Path);a=ap.parse_args();n=seal(ROOT);stages=[]
 with tempfile.TemporaryDirectory(prefix='pa-machine-replay-')as d:
  work=pathlib.Path(d)/'work';shutil.copytree(ROOT,work,ignore=shutil.ignore_patterns('__pycache__'))
  for mode in ([],['-O']):
   for name in ('check_construction.py','check_construction236.py','audit_fold.py','audit_fold_negative.py','audit_fold236.py','audit_fold236_negative.py'):
    stages.append(run(work,[*mode,'code/'+name]))
  for name in ('check_startup.py','check_runtime_negative.py','check_word_identities.py'):stages.append(run(work,['code/'+name]))
  jobs=[]
  for count in (238,237,236):
   table=work/'machines'/('pa238.tm'if count==238 else f'pa{count}.native.tm')
   source=work/'sources'/f'sites{count}.json'
   if table.exists() and source.exists():jobs.append(['code/check_runtime.py','--table',str(table),'--sites',str(source),'--output',str(work/'results'/f'replay_runtime{count}.json')])
  with concurrent.futures.ThreadPoolExecutor(max_workers=3)as e:
   stages.extend(e.map(lambda x:run(work,x),jobs))
  controls=[]
  for kind in ('changed','missing','extra','empty_manifest'):
   bad=pathlib.Path(d)/kind;shutil.copytree(ROOT,bad,ignore=shutil.ignore_patterns('__pycache__'))
   if kind=='changed':(bad/'report.tex').write_text('corrupt')
   elif kind=='missing':(bad/'report.tex').unlink()
   elif kind=='extra':(bad/'unexpected.txt').write_text('extra')
   else:(bad/'manifest.json').write_text('{}')
   try:seal(bad)
   except ValueError:controls.append({'mutation':kind,'rejected':True})
   else:raise ValueError('accepted corruption '+kind)
 if seal(ROOT)!=n:raise ValueError('seal changed')
 result={'status':'PASS','sealed_files':n,'stages':stages,'integrity_negative_controls':controls,'scope':'Normal and optimized construction/fold checks; universal runtime uses normal Python and deliberately rejects -O.'}
 if a.receipt:a.receipt.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
