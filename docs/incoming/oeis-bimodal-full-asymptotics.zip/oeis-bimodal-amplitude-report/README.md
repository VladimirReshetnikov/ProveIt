# Limiting amplitudes for corner polyhedra and Schnyder labelings

Research addendum dated 2 October 2026

## Current conclusions

This addendum establishes finite positive limiting amplitudes:

- A377922: p_n ~ kappa_P (9/2)^n n^(-1-pi/arccos(9/16))
- A377920: s_n ~ kappa_S (16/3)^n n^(-1-pi/arccos(22/27))
- A377921: tilde_s_n ~ (16/19)^3 kappa_S (16/3)^n n^(-1-pi/arccos(22/27))

The constants are characterized by positive killed-harmonic and Brownian heat-kernel formulas. The universal Brownian factors are evaluated explicitly, but no numerical digits of the model-dependent counting amplitudes are certified.

The addendum also proves Lambert-W inverse centering with a vanishing-width two-ceiling bracket for the first threshold. It does not assert an unconditional exact ceiling formula or provide an effective forward remainder or higher coefficient correction terms.

## Relationship to the Foundation

The complete, unchanged 30-file earlier report is included under `foundation/`. Its statements that amplitude convergence remained unresolved describe the scope of that first note. The present addendum establishes those limits. The current conclusions of this combined package are the full equivalents above; the original Foundation bytes and its historical review remain unchanged.

Read `addendum.pdf` for the upgrade, and `foundation/article.pdf` for the exact walk models, covariance calculations, fixed cycle buffer, free Fourier local theorem, two-sided bounds and non-D-finiteness consequences. The addendum repeats the key definitions and gives precise Foundation references, avoiding duplication of the full earlier proof.

This is a mathematical research manuscript supported by exact checks and a separate mathematical review. It is not external journal peer review, machine formal verification, or a publication-priority claim. Finite computations verify algebraic identities and coefficients; the limiting theorems are proved in the manuscript.

## Package contents

- `addendum.pdf`: 14-page full-amplitude research addendum
- `addendum.tex`: editable LaTeX source
- `build.sh`: portable two-pass addendum build
- `requirements.txt`: Python dependency
- `foundation/`: all 30 original Foundation files, including its 15-page PDF, editable source, scripts, results, source data, receipts and original checksum manifest
- `scripts/verify_foundation.py`: read-only integrity check of every Foundation file and its source-bound receipt
- `scripts/verify_addendum.py`: exact new algebra and normalization checks
- `scripts/run_all.py`: complete verification, including all four Foundation programs in an isolated temporary copy
- `results/`: exact symbolic output, Foundation integrity receipt and replay results
- `audit/`: integrated mathematical review and final visual validation receipts
- `sources/`: source provenance and bounded public literature-status record
- `SHA256SUMS`: delivery checksums for the combined package

## Reproduce the exact checks

Use Python 3.9 or newer and SymPy. The recorded versions are in `results/verification-summary.json`.

    python3 scripts/run_all.py

If needed, install the declared dependency in an environment you control:

    python3 -m pip install -r requirements.txt

The command first verifies the Foundation without writing to it. It then runs the new exact algebra checks and replays all four Foundation programs in an isolated temporary copy, comparing the regenerated mathematical JSON results byte-for-byte. New verification output is written only under the top-level `results/` directory.

The new checks cover covariance determinants, Brownian survival normalization, the entrance-semigroup integral, cycle-to-counted-time factors, half-plane and quadrant normalization examples, the 361/192 Schnyder multiplier, the (16/19)^3 rigid multiplier, signed-convolution coefficients and majorant, and the Lambert inverse transformation. They do not numerically determine the unknown discrete harmonic values.

## Rebuild the addendum

A standard TeX Live installation with pdfLaTeX, Latin Modern, AMS packages, geometry, microtype, enumitem, booktabs, xcolor and hyperref is required.

    bash build.sh

This rebuilds `addendum.pdf`, keeping temporary files in `build/`. The script includes fallback configuration for incomplete TeX Live filename and font-map databases. PDF metadata use the manuscript date. Byte-identical rendering can depend on the TeX engine and fonts; exact source and delivery PDF hashes are recorded separately.

To rebuild the Foundation without altering the included original, copy its directory to a temporary location and run that copy's `build.sh`. The delivered Foundation source and PDF retain their original hashes:

- article.tex: 849e515056a5b296221d6fe1a0ca09c1a7fd78a19d776256ee25143070128bb2
- article.pdf: 9a95af196db80e86e1048497eef200888d89ee781362d0d5b60c6eeb731bb6da

To verify the complete delivery before regenerating outputs:

    sha256sum -c SHA256SUMS

To render the addendum with Poppler for visual inspection:

    mkdir -p qa
    pdftoppm -r 120 -png addendum.pdf qa/page

## Source credits and limits of the literature check

The counting bijections and conjectured equivalents are due to Éric Fusy, Erkan Narmanli and Gilles Schaeffer. The ordinary iid cone results are due to Denis Denisov and Vitali Wachtel. The Brownian spectral kernel is cited to Rodrigo Bañuelos and Robert G. Smits. Precise published references and links appear in the addendum and `sources/provenance.json`.

The public literature-status record is a bounded snapshot of the checked sources. It does not establish global novelty, exclude unpublished work or certify this proof. The mathematical review is recorded separately.

The Foundation preserves the official OEIS data excerpts and contributor credits. Its README and source provenance record the source, export commit and OEIS license information. No third-party source paper is redistributed in this package.
