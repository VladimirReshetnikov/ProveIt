# All-Degree Classification of Affine-in-z Weighted Keller Maps

**Constant-slope rigidity and obstructed nilpotent deformations**  
Prepared for Vladimir Reshetnikov, 29 September 2026.

## Main result

Over every characteristic-zero field, let t = xy, v = x²z, and let

    F = (p(t,v)/x², q(t,v)/x, x r(t,v))

be a polynomial map with all three numerators affine in v. If its Jacobian
is a nonzero constant, then r_v is constant. This answers the explicit
question in Section 10.2 of the repository's earlier weighted-Keller report.
The theorem has no bound on ordinary degree.

The complete normal forms follow: either an explicit tame automorphism, or
the known noninjective core up to diagonal scalings and one equivariant
source shear. The article provides an inverse or ground-field collision
certificate, the exact noninjective degree spectrum, and a coefficient-only
recognition algorithm.

A separate result describes the nonreduced boundary. Nonconstant slopes
exist over dual numbers, but every nonzero slope direction at (z,y,x) is
obstructed at second order inside the affine class, independently of every
second-order correction. A single quadratic term repairs each displayed
direction at second order, and a divergence-free formal flow integrates it
once the degree cap is removed. Finite coefficient schemes therefore have
genuine nonzero nilpotent slope coordinates.

## Files

- `article.pdf`: the complete 22-page article.
- `article.tex`: standalone LaTeX source, with inline bibliography.
- `code/weighted_keller.py`: exact rational normal-form recognition and certificates.
- `code/verify_results.py`: twelve groups of exact symbolic and rational checks.
- `data/verification.json`, `data/verification.txt`: recorded results.
- `requirements.txt`: computational dependency pin.
- `SOURCES.md`: repository snapshot, source locations, and attribution ledger.
- `STATUS.md`: precise theorem, verification, and novelty boundaries.

## Reproduce

Use Python 3.10 or later. The recorded environment was Python 3.13.5 and
SymPy 1.14.0; the JSON file is the authoritative recorded version report.

```sh
python -m pip install -r requirements.txt
python code/verify_results.py
latexmk -pdf -interaction=nonstopmode -halt-on-error article.tex
```

To try the classifier from the package root:

```python
from code.weighted_keller import t, normal_form, classify, normalized_collision
p, q, r = normal_form(1, 1, 1 + t + t**2 + t**3)
result = classify(p, q, r)
print(result.kind)                 # noninjective
print(normalized_collision(result))
# ((1, 0, -1), (0, -9, -10))
```

The classifier accepts rational coefficients only; the theorem holds over
all characteristic-zero fields. Out-of-class inputs raise ValueError.
The implementation uses the classification, not a bounded search or a
numerical Jacobian test. The O(D) bound in the article concerns an abstract
coefficient-array implementation, not a timing guarantee for SymPy.

## Status

The package contains complete written mathematical proofs and executed
exact checks. It is an AI-assisted, unrefereed research draft, not a
Lean/Rocq formalization or an independently certified priority claim.
The constant-slope normal forms and original counterexample are inherited
and credited; the new claim is the removal of the constant-slope assumption
and the stated deformation results. No unrestricted Keller classification
or global minimum-degree claim is made.

No live repository files were modified. The source snapshot is
`9b24a3a8d545af9624f6ac455f5b548be62818b6`.
