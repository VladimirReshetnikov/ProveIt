# Three alternative 219-state constructions

This self-contained packet provides three distinct deterministic, single-tape,
two-symbol machines with exactly **219 working states and a separate halt
outcome**. Every machine includes its blank-tape initialization. No external
input, interpreter, or uncounted startup apparatus is required.

The constructions are:

- **zero_terminal**: replace eight guarded break leaves in four equality
  macros by failed decrements of register 6 and change nine physical rows.
- **retagged**: make 81 disjoint source right reassociations, retag 81
  continue-2 leaves to continue-3, and change three physical rows. The complete
  ordinal source control-flow graph remains exactly the same.
- **composed**: combine the zero-terminal source substitution with the same
  source reassociation, using a different physical decoder realization.
  This changes twelve rows. It is not the literal union of the first two
  tables: its row `(139,0)` is `0 L 139`, whereas retagged uses `0 R 99`.

These are 219-state alternatives, not a construction with 218 or fewer states.
No failed reduction candidate or finite-only specimen is presented as proved.

## Run the complete verification

Requirements: Python 3.10 or later with the standard library, several hundred
MB of free disk space, and assertions enabled. No network, compiler, solver,
third-party Python package, proof assistant, or paid service is needed.

From the extracted directory, run:

```
python3 -B portable/reproduce.py --output-dir /absolute/path/to/empty/replay
```

The output directory must be outside this packet and initially empty. Default
mode freshly reconstructs every source and table, checks all-natural source
transport, independently canonicalizes and simulates each complete blank
startup, freshly proves every generic unbounded primitive interface, audits
coverage and exact-table block lemmas, and runs negative controls. It also
replays the inherited construction/calibration chain, auditing its stored
runtime certificates. Allow minutes to tens of minutes, depending on hardware.

Successful default completion prints
`SELF_CONTAINED_THREE_ALTERNATIVES_REPLAY_PASS` and writes `replay.json`.
The packet is not changed by verification. Run with `-B` to avoid adding
unmanifested bytecode cache files to the packet.

Optional modes:

- `--quick`: fresh reconstruction, source proofs and whole-tape startups, but
  audit stored variant runtime evidence instead of rederiving all symbolic
  traces. Success is `QUICK_THREE_ALTERNATIVES_AUDIT_PASS`. It is deliberately
  not described as a fresh unbounded replay.
- `--full-baseline`: additionally rederive the upstream K219 runtime.
- `--deep-baseline`: additionally request fresh ancestral runtime derivations.
  This can be much slower. Neither switch replaces variant checking.

## Tables, source and labeling

`machine/<variant>/sites.json` is the complete 4,744-leaf source program.
Each machine directory contains three equivalent table labelings:

- `k219.native.tm`: the release-native **normalized/search labeling**, with
  labels 102 and 120, start 0, source dispatcher 84, and halt 254. This is the
  literal table certified by the runtime. “Native” here does not mean the
  original upstream numbering.
- `k219.upstream-labels.tm`: the same table with 102 mapped to 301 and 120
  mapped to 302, matching the upstream label convention. This is a bijective
  renaming only, not another alternative.
- `k219.tm`: deterministic breadth-first canonical labeling, working labels
  0 through 218 and halt 219, visiting the 0-edge before the 1-edge.

`canonicalization.json` records the complete bijection, separate hashes, exact
startup configuration, and register encoding. Every table uses rows
`state read write direction next_state`; alphabet is {0,1}, blank is 0,
direction is L or R, and every working state has exactly two rows. The halt
label has no outgoing rows. State 0 starts with head 0 on an entirely blank,
two-way infinite tape. All 219 working states are graph reachable.

`machine/construction.json` declares the exact source rotations, control
ordinals, zero-terminal ordinals and table patches from normalized upstream
K219. `portable/construct.py` deterministically applies them and requires
byte-for-byte output equality with the distributed source and tables.

## Complete initialization and generic proof census

- zero_terminal: 313,845 blank transitions and 6,175 generic primitive cases.
- retagged: 312,707 blank transitions and 6,167 generic primitive cases.
- composed: 314,043 blank transitions and 6,175 generic primitive cases.

All reach release-native dispatcher 84 at head -5, with exactly 277 specified
one cells and all other cells zero, logical primary registers
`[3,0,0,0,3,0,0,0,0]`, 130 spare registers of value 1, header 139 and extra gap
80. Separate sparse and dense interpreters compare the entire tape support,
not merely a checksum or finite window.

The runtime covers independent arbitrary natural primary-register values,
an arbitrary natural blank gap, an arbitrary first spare value, and an
arbitrary finite spare tail. Exact unary and finite-list induction proves
positive finite duration. All generic decrement guards are checked, including
the eight positive cases unreachable under the zero-terminal source guard.
No failing case is excluded. The 4,000 symbolic-rule bound limits proof
construction, not represented register values, machine runtime, or list size.

## Evidence and inherited calibration

- `certificates/<variant>/`: source transport, startup, complete runtime census,
  per-case symbolic summaries, and independent coverage/block/integrity audit.
- `verification/`: independently implemented release checks, negative controls,
  and immutable historical upstream replay evidence.
- `report/report.pdf` and `report/report.tex`: mathematical exposition,
  construction details, state accounting, theorem composition and limitations.
- `vendor/K219_Construction_2026-10-20.zip`: unchanged pinned upstream archive,
  recursively containing the baseline calculus calibration and predecessors.
- `manifest.json` and `SHA256SUMS`: exact packet inventory and file integrity.

The theorem composition needs all three links: source equivalence, complete
blank initialization, and unbounded physical refinement. Source paths and
controls change, so neutral physical-table diamonds alone would not suffice.
The inherited logical calibration is replayed through operative manifests and
construction checkers. Historical receipts are labeled as such; see `NOTICE.md`.

This is ordinary executable mathematical certification, not a newly compiled
exact-byte Rocq/Lean endpoint. It transfers the upstream conditional theorem
that ZFC proves blank nonhalting equivalent to Con(ZFC). It does not prove
Con(ZFC), unconditional nonhalting, minimality, or a result below 219 states.
