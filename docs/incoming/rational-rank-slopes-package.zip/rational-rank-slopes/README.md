# Rational rank slopes for constrained crossover

This research package resolves the three parts of Question 24.3 in the pinned ProveIt report and sharpens the finite-rank upper bound.

## Main results

For any epsilon-free NFA seed language L and every live residue r of a common eventual period p of exact-length forward/backward reachability,

    M_L(n) = lambda_r * n + O(1), for n congruent to r modulo p.

The slope lambda_r is rational and effectively computable as the maximum reachable cycle mean of an explicit deterministic zero-one subset-reset graph. It is positive exactly on obstructed residues. No refinement of p is needed for convergence of M_L(n)/n.

The key lemma proves that taking the longest available aligned fragment greedily exactly minimizes the fragment count. This resolves the maximum/minimum order issue and gives an O((alphabet_size + n) * s^2) fixed-word rank algorithm with O(n*s + s^2) auxiliary Boolean storage. If the unlabelled transition matrix is supplied, the corresponding bounds are O(n*s^2) time and O(n*s) storage.

A separate application of Schwarz's classical relation-power theorem gives

    finite R(L) implies R(L) <= 2*(s - 1)^2 + 3.

With the earlier quadratic lower family, this yields

    (s - 3)^2 <= F(s) <= 2*(s - 1)^2 + 3, for s >= 4.

The leading-constant interval is now [1, 2]; no sharp constant or limit is claimed.

## Contents

- `rational-rank-slopes.pdf`: detailed article, including proofs, examples, attribution, and limitations
- `rational-rank-slopes.tex`: standalone editable LaTeX source
- `verify_greedy.py`: independent literal seed-partition oracle versus subset-reset parser
- `verification.json`: parser test receipt
- `check_boundaries.py`: independent checks of the two transient-bound counterexamples
- `boundary-verification.json`: counterexample test receipt
- `build.sh`: ordinary two-pass pdfLaTeX build
- `SHA256SUMS`: checksums of package files

## Reproduce the tests

Python 3 and its standard library suffice. Assertions must stay enabled; do not use `python3 -O`.

    python3 verify_greedy.py > verification-new.json
    diff -u verification.json verification-new.json
    python3 check_boundaries.py > boundary-verification-new.json
    diff -u boundary-verification.json boundary-verification-new.json

The parser test covers all binary two-state NFAs with nonempty initial/final sets through length six, plus 300 seeded random NFAs on three to five states through length eight. Seed: 20261001. It records 2,604 automata, 14,407 nonempty slices, and 309,574 rank comparisons. It tests hull targets only; it is not an exhaustive check of infinite-rank inputs or the empty-word branch.

The boundary checker computes relation-power and pair-reachability orbits, explicitly enumerates the indicated seed slices, and verifies their rank witnesses. These finite checks do not prove the universal slope theorem or Schwarz's classical theorem. The article gives mathematical proofs of its applications and clearly marks the imported input.

## Build the PDF

Use a working TeX distribution with pdfLaTeX, amsmath, amssymb, amsthm, lmodern, geometry, booktabs, microtype, and hyperref:

    sh build.sh

The PDF in this package was compiled and every page visually inspected.

## Sources and scope

Pinned repository commit: 1bd730779e8bc44c8976dcd9f38cad86a0d21c26

https://github.com/VladimirReshetnikov/ProveIt/blob/1bd730779e8bc44c8976dcd9f38cad86a0d21c26/SetTheory/Cardinals/docs/reports/automata-and-formal-languages/constrained-crossover-closure/article.tex

Relevant question: Part II, Question 24.3, “Exact residue-wise rank slope.”

The greedy-parsing background is credited to Crochemore, Langiu, and Mignosi (2014), with related factorial-language discussion by De Luca and Fici (2025). Cycle means are classical, including Karp (1978). The finite-rank improvement imports Schwarz, “On the semigroup of binary relations on a finite set,” Czechoslovak Mathematical Journal 20(95) (1970), Theorem 4.3 on printed p.653, with the index definition on p.634. The earlier quadratic lower bound is credited to the companion note delivered separately. Full links are in the article.

No global first-discovery claim, formal Lean verification, tight slope-computation complexity, exact eventual affine periodicity, or sharp extremal constant is asserted.

Prepared 1 October 2026 for Vladimir Reshetnikov.
