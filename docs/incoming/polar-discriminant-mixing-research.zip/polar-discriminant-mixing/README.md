# Exact restriction laws and Fourier cancellation on hyperbolic quadrics

**Sharp polar averaging and two-family discriminant discrepancies**  
Research manuscript prepared with ChatGPT for the ProveIt project, 7 October 2026.

## Main results

Let `H` be a split nondegenerate symmetric form on `F_q^(2r)`, with `q` odd,
and let `Q` be a uniformly random symmetric form. Let `G+` and `G-` be the
two classical families of maximal `H`-isotropic subspaces. Write `D(C)` for
`chi(det C)`, extended by zero on singular matrices, and let `Delta_D` be
the difference between the two family averages of this statistic.

The article proves the exact identity

    E[Delta_D^2] = (4 p_r / N_r) q^(-floor(r/2)),
    p_r = product over odd j <= r of (1 - q^(-j)),
    N_r = 2 product from j=1 to r-1 of (q^j + 1).

Thus the fixed-rank variance exponent is `floor(r^2/2)`. In contrast, the
variance of the average over all generators has sharp leading term
`q^(-(r-1))` for `r >= 2`.

The article also proves:

- Exact conditional extension and two-subspace joint-sign laws, retaining
  every singular common block; sharp polar and Grassmannian averaging.
- A general incidence-to-Fourier transfer theorem, exact top-rank energy,
  and uniqueness of the universal full-rank filter on all generators.
- Exact two-family nonsingularity and individual-sign covariance formulas.
- A pointwise even-rank character identity, and an odd-rank nonsingularity
  identity, in terms of the signed count of common `H,Q` generators.
  These contrasts vanish except on an event of probability
  `(2 + O_r(1/q)) q^(-r)`. Nonzero contrast forces the characteristic
  polynomial of `H^(-1) Q` to be a square. Variance-normalized contrasts
  converge to zero in probability in these parities, not to a
  nondegenerate Gaussian law.
- The complete finite-`q` five-point discrepancy law for `r = 2`.
- Relative conditioning estimates for invertibility constraints along
  a pencil, and an `O_r(q^(-1))` local transverse approximation for
  `r >= 3`, replacing the source manuscript's `O_r(q^(-1/2))` estimate.

Nine further research questions appear in the article. They distinguish
questions resolved here from remaining parity, distribution, geometry,
conditioning, and formalization problems.

## Files

- `polar-discriminant-mixing.tex`: self-contained article source.
- `polar-discriminant-mixing.pdf`: compiled article.
- `code/exact_formulas.py`: exact rational formulas.
- `code/verify.py`: direct enumeration and exact formula checks.
- `verification-results.txt`: actual successful verification transcript.
- `SOURCE_AUDIT.md`: pinned source crosswalk, literature, and review scope.
- `THEOREM_LEDGER.md`: proved statements, classical ingredients, and limits.
- `Makefile`, `requirements.txt`: build and test entry points.
- `SHA256SUMS`: integrity manifest for the delivery.

## Build and verify

Compile the article with a standard LaTeX installation containing the
packages named in its preamble:

    latexmk -pdf -interaction=nonstopmode -halt-on-error polar-discriminant-mixing.tex

Run the tests from this directory:

    python code/verify.py

Do not use Python's `-O` option: the suite uses assertions. The verifier
also explicitly rejects execution with assertions disabled. Python 3.10+
and NumPy are required. The recorded run used Python 3.13.5 and NumPy 2.3.5.
`make pdf` and `make check` are equivalent entry points.

All pass/fail comparisons use integers, rational numbers, or exact
cyclotomic coefficient counts. There is no Monte Carlo and no
floating-point tolerance. The suite includes all 59,049 symmetric forms
on `F_3^4`, every generator there, and an explicitly described 19,683-form
slice of `Sym_6(F_3)` using all 80 generators. The latter is **not** the
whole six-dimensional ambient form space. Formula evaluations at `q=9`
and `q=25` are prime-power counting formulas, not arithmetic modulo 9 or 25.
See the article and transcript for all test scopes.

## Research status and integration

This is an AI-assisted research manuscript with written proofs and exact
finite checks. It has not received independent human referee review or
proof-assistant certification. Classical rank/type counts, full-rank
Fourier ingredients, and the Latin–Greek halving are attributed in the
article; historical priority for the assembled research results is not
certified. No human authorship or endorsement is assigned.

The repository review was scoped to inventories and selected sources.
The direct local theorem interface is in the OpenAI rank-layer manuscript;
the ProveIt connection is its quantitative restriction and counting
research program. No unverified ProveIt result is used as a theorem premise.
This delivery does not certify the global Sidorenko claim or a new global
Szemeredi bound.

For integration, place this folder in a new research directory chosen by
the ProveIt maintainer and link it from the appropriate finite-field /
combinatorics index. Keep its research status distinct from a Lean proof
ledger. No existing repository files, theorem labels, or formal status
records were modified during preparation.
