# Quadratic Counting Errors and Sharp Directional Bounds
## in Gowers's Szemeredi Argument

Prepared for Vladimir Reshetnikov, 6 October 2026.

## Contents

- `article.pdf`: the 21-page article, including complete mathematical proofs,
  quantitative comparisons, twelve research questions, and source audit.
- `article.tex`: standalone editable LaTeX source, with inline bibliography.
- `verify.py`: finite verification program. Exact tests use Python's standard
  library; the optional Gauss-sum check requires NumPy.
- `verification_report.json`: executed results, with exact and floating-point
  calculations identified separately.
- `source_manifest.json`: inspected source identifiers and primary references.
- `BUILD_REPORT.txt`: build and validation information.
- `Makefile`: commands for compilation and verification.
- `SHA256SUMS.txt`: checksums of package files other than the checksum list.

## Main results

1. Two marked functions survive the generalized von Neumann argument, giving
   the product of two directional Gowers seminorms and one L2 norm.
2. For s >= 2, the optimal directional-to-global norm conversion constant is
   (product of the subgroup indices)^(1/2^s). Coset-supported functions give
   equality for every fixed tuple of subgroups.
3. Symmetric progression-counting error is at most B_k(delta) u^2, where
   u = ||1_A-delta||_{U^(k-1)} and the explicit density coefficient satisfies
   B_k(delta) <= sqrt(delta)/(1-delta)^2. The article gives a sharper formula,
   unequal-density versions, subgroup-index costs, and proper-count bounds.
4. For three-term progressions, no higher uniform exponent is possible for
   indicator sets over the family F_29^(2m). The proof uses an exact
   quadratic-phase calculation followed by a moment-based rounding argument.

The comparison is with the specified local estimates in Gowers's paper and
an inspected ProveIt research manuscript. The original asymmetric counting
corollary does not assume uniformity of its first two sets; the quadratic
estimate must not be substituted there without its additional hypotheses.

The manuscript does not claim worldwide priority, a new best global bound
in Szemeredi's theorem, sharpness of its general density coefficient, or
sharpness of the counting exponent for k >= 4 or prime cyclic groups.
No Lean code was compiled or kernel checked. No repository was modified.
Finite checks supplement the proofs; they are not proofs of the general
statements. The rounded indicator examples are an asymptotic existence
construction, not generated explicit lists of points in this archive.

## Compile

Use a usual TeX installation with pdfLaTeX and the packages named in the
preamble (amsmath, amssymb, amsthm, mathtools, lmodern, geometry, microtype,
booktabs, tabularx, longtable, xcolor, enumitem, fancyhdr, hyperref, bookmark).
No external figures, bibliography processor, or shell escape is required.

    make pdf

Or run the following command three times:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex

## Reproduce exact tests

    python3 -S verify.py --output exact_verification_report.json

This runs 10,389 exact rational/integer checks. Random tests use the fixed
seed 20261006. The generated coefficient table uses ordinary floating-point
arithmetic and is marked accordingly; no exact inequality test uses it.

## Also reproduce the optional numerical check

With NumPy installed:

    python3 verify.py --gauss --output verification_report.json

The extra test directly averages the quadratic-phase example on F_29^2
and compares it with the formula proved in the article.

## Source handling

The repository was active during inspection. The source manifest records
individual inspected blobs and the observed branch checkpoint rather than
assuming that all material came from a single immutable checkout. The
original Gowers paper, repository, and third-party font files are not
redistributed here.
