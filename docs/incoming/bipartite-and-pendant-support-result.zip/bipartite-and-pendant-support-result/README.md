# Lorentzian and real stable directed support polynomials

This compact standalone package contains two proved structural results for directed matching supports with independent nonnegative tail/head activities. Every feasible ordered pair of physically disjoint endpoint sets is counted once, regardless of matching multiplicity.

## Main results

1. The physical orientation-support polynomial of any directed relation on a bipartite physical graph is Lorentzian. The coefficient sequence is ultra-log-concave at the chosen shore order. It is actual-degree rank-ULC when a positive-weight matching saturates that shore. An independent overlapping role cover uses physical-core order |P union Q|, not the number of role copies.
2. A stable selected-head transversal seed remains real stable after inserting uncovered heads of indegree at most one at arbitrarily many different tail hubs, then merging physical role copies. Its support polynomial has only negative real zeros and is actual-degree rank-ULC, including activity-induced degree drops. Singleton-or-universal selected-head neighborhoods supply an explicit stable seed in arbitrary rank.

The paper includes an overlapping two-tail/three-head example whose physical graph contains a triangle and whose support polynomial is 1+16t+47t²+31t³+4t⁴. Its 99 supports differ from its 163 matching witnesses.

## Read the paper

- `article/support-polynomials.pdf`: typeset paper
- `article/support-polynomials.tex`: editable source
- `proof-notes/`: exact theorem-note snapshots reviewed before integration
- `audits/`: independent mathematical audits and approval receipts
- `qa/visual-qa.json`: page-by-page visual inspection record

The proofs are ordinary, unbounded mathematical arguments relying on explicitly cited classical stability and Lorentzian theorems. The computational checks corroborate them; finite tests are not substituted for proof. No proof-assistant formalization or literature-wide novelty claim is made.

## Reproduce the exact checks

Requirements: Python 3.10 or later and SymPy 1.14.0 (the version used here). Only the independent pendant checker uses SymPy; the other three checkers use Python's standard library. Install the optional dependency in your preferred environment with `python3 -m pip install -r requirements.txt`.

Run:

    PYTHONDONTWRITEBYTECODE=1 python3 verify.py

The driver checks every file in `SHA256SUMS`, copies the four checker programs into a fresh temporary directory, runs them there, and compares all deterministic receipt fields. Recorded elapsed times are ignored. It does not overwrite the frozen receipts or any package file.

The independent bipartite checker covers 5,120 weighted cases and 13,152 exact quadratic Hessian-inertia tests. The independent pendant checker covers 1,884 weighted cases, including 880 activity-induced degree drops, and performs 70,752 exact Rayleigh evaluations as supplemental checks. The producer checkers provide separate support enumerations and exact negative-root tests. All seeds and scope details are stored in the receipts.

## Rebuild the PDF

A normal TeX Live or MiKTeX installation with pdflatex and the packages named in the source is sufficient:

    sh build.sh

The delivered PDF is already built and visually inspected. Rebuilding may change PDF metadata and therefore its hash; reproduce in a copy if you wish to preserve the released manifest.

## Important boundaries

- Shore-order ULC does not automatically imply actual-degree ULC when Hall deficiency or zero activities lower the matching degree
- Real-rootedness in the pendant theorem requires the stated stable-seed hypothesis; arbitrary transversal matroids are not assumed stable
- The activity model is a product of vertex-role activities, not arbitrary independent edge weights
- The general two-tail/three-head role-cover rank-ULC problem remains open
- The package excludes floating-point exploratory searches; none is used as proof

The primary references and exact theorem numbers are in the paper. The copied audit receipts preserve their original reviewed source hashes; those source snapshots are included under `proof-notes/`. A receipt's original workspace path is provenance, not a required replay location.

No external publication was performed.
