#!/bin/sh
# Rebuild with a normal TeX Live or MiKTeX installation.
set -eu
cd "$(dirname "$0")/article"
pdflatex -interaction=nonstopmode -halt-on-error support-polynomials.tex
pdflatex -interaction=nonstopmode -halt-on-error support-polynomials.tex
printf '%s\n' 'Built article/support-polynomials.pdf'
