# A 238-state binary Turing machine for ZFC consistency

This contribution supplies an explicit machine with **238 working states**, two symbols, one two-way infinite tape, an all-zero initial tape, and a separate halt state. Its complete blank initializer is counted. Using the identified inherited ProveIt source calibration, the report gives an ordinary mathematical proof, formalizable in ZFC, of

```text
Halt(M238, blank)  iff  there exists a finite ZFC proof of contradiction.
Not Halt(M238, blank)  iff  Con(ZFC).
```

The result is a verified composition of two different 239-state reductions already in the repository's incoming research. The coordinated helper reuse removes inherited state 169. The boundary source/decoder construction removes inherited state 218. The new compatibility argument proves that the helper's extra tape guard survives the changed decoder; three retained-row edits then produce the exact 238-state table.

## Start here

- `report.pdf`: complete report, ordinary proofs, exact transition table and supplementary equational result.
- `report.tex` and `sections/`: editable LaTeX source.
- `machines/zfc238.tm`: canonical table, working states 0–237, start 0, dispatcher 84, halt 238.
- `machines/zfc238_old.tm`: the same table in inherited labels, start 95, dispatcher 96, halt 254.
- `machines/renumbering.json`: the exact state bijection.
- `build.py`: deterministic reconstruction from the pinned boundary-239 input.
- `reproduce.py`: default full proof replay.
- `evidence/full_replay/replay.json`: completed packaged replay receipt.
- `PROVENANCE.json` and `ATTRIBUTION.md`: new and inherited contributions, pinned commits and archive identities.

The canonical machine's SHA-256, including its start header and final newline, is:

```text
909f29c493e0ccc5d6a481fd7a20a9a82eb934ab2aa7df17b5ec3789255a8c08
```

The text format begins with `#! start 0`; every remaining row is

```text
current_state read_bit write_bit L_or_R next_state
```

All 476 working-state transitions are explicitly present. The designated halt state has no outgoing row. There is no prescribed nonblank input or uncounted tape-writing stage.

## Reproduce

Python 3 with its standard library is sufficient; Python 3.12 was used for the retained replay. Do not use `-O` or `-OO`, and leave `PYTHONOPTIMIZE` unset. The scripts reject disabled assertions. The replay performs no network access and resolves package inputs relative to its own location.

From the extracted directory, choose a new or empty output directory:

```sh
python3 -B reproduce.py --output /tmp/zfc238-replay
```

The default must conclude with `FULL_238_REPLAY_PASS`. It checks the final SHA-256 manifest and runs the exact construction, source extraction and seed identity, independent source-control proof, boundary context split, guarded local reduction, open-tape block proof, sparse/dense blank initializer, retained rejected-edit counterexample, equational packet regeneration, and both unbounded runtime proofs. The universal proofs take minutes; their running time is independent of any execution of the potentially nonhalting consistency machine.

For finite checks and integrity only:

```sh
python3 -B reproduce.py --quick --output /tmp/zfc238-quick
```

This deliberately reports `QUICK_238_REPLAY_PASS` and `unbounded_proofs_rerun: false`. It does not replay the two universal proofs.

To rebuild the exact machines alone:

```sh
python3 -B build.py --out /tmp/zfc238-built
```

To compile the report with a normal TeX Live installation:

```sh
latexmk -pdf report.tex
```

Compile output and replay output can be kept outside the research directory. `SHA256SUMS` covers the delivered files, not newly generated output directories.

## Exact evidence

| Check | Completed result |
|---|---|
| Canonical census | 238 working states, 476 transition rows, separate halt |
| Literal retained-row construction | Delete 169; edit 80/0, 91/1 and 147/0 on the boundary-239 table |
| Source comparison | 6,455 identical instruction labels; all 8,385 nonhalt guarded successor indices agree |
| Source pointer/frame compatibility | Every successor has the same infinite zero-padded word as its decoded leaf |
| Finite predecessor invariant | 121,024 admitted state/window combinations |
| Exceptional positive blocks | 5, 3, 5 and 9 transitions; whole tape and head preserved at endpoints |
| Independent open-tape proof | Reads only the forced cells; arbitrary exterior remains untouched |
| Complete blank initializer | 409,835 steps; head −5; 351 one-cells; exact calibrated logical seed |
| Direct 238-state universal runtime | 8,386 guarded cases; 2,255,513 symbolic rules; all 476 rows |
| Boundary-239 universal guard | 8,386 guarded cases; 2,247,513 rules; all 478 rows |
| Extra old-169/read-one guard | 32 runtime visits; minimum one-run constant 23; six initializer visits |
| Positive instruction progress | Minimum duration constant 13 |

The symbolic arguments quantify over arbitrary natural primary values, gap and first spare value, and an arbitrary finite remaining spare list. Unary-loop and list traversals are justified by induction from the literal table. The 4,000-rule case cap bounds construction of a proof, not register values, spare length or actual machine running time. The entire tape and head motion are checked at each nonhalting instruction endpoint.

## Proof status and dependencies

The exact new binary machine, source correspondence, blank initialization and helper compatibility have fresh ordinary mathematical certificates. The logical endpoint is inherited from the pinned `CalibratedRotation240.halts_iff_zfc_refutation` and its native/ZF/ZFC comparisons. `reference/CALIBRATION_INTERFACE.md` identifies the proof predicate and axiom presentation. Selected source snapshots and status notes are retained under `reference/`; they are not the entire transitive ancestor Lean project.

This is **not a newly kernel-checked Lean/Rocq endpoint**, not a serialized object-theory ZFC derivation, and not an internal PA theorem. The complete ancestor calibration was not rebuilt in this work. The two universal replay drivers share one attributed induction engine; they should not be described as independently implemented universal verifiers. The local, source, initializer and adversarial reviews supply independent checks at their stated interfaces.

No consistency assumption is needed to establish the biconditional. Actual nonhalting follows if ZFC is consistent. No minimality claim is made. Bare consistency suffices for the usual second-incompleteness obstruction to proving this nonhalting assertion; two-sided independence requires the separate soundness qualification explained in the report.

## Supplementary research

`research/stack937/` contains a complete **937-bit, 14-equation** packet specialized from the inspected 946-bit parent. Three closure-witness functions share existing structural constructors. The report proves the new model construction using a free tagged carrier and a weighted raw-value recursion, while retaining the inherited raw-EPSC/ZFC calibration as an explicit dependency. The packet's calibrated question is nonderivability of a designated ground equality. The bit count includes the full packet under its codec, but no equational interpreter or binary initializer. It supplies no additional Turing-machine state saving.

`research/source_search/rejected_rotation/` preserves a different syntactic 238-state edit that failed the universal instruction-frame specification. The replay reproduces its exact tape discrepancy. It is kept as a rejected experiment, separate from the accepted machine in `machines/`.

## Incorporating into ProveIt

A suitable location is `Computability/BusyBeaver/Research/ZFC/candidate-composed238/`. Preserve the exact machine bytes, manifest and attribution. The incoming archive hashes are recorded in `PROVENANCE.json`. The inspected repository head is `ce192939372ac7944fe2a0208c68a96d49fb5e3b`; the component calibration snapshots are pinned to `13ec39ed43148b1807f51ed6e6528e1c84659562`.

The natural next formalization is a theorem for this exact table in the external Lean binary interface, followed separately by any stronger internal arithmetization project. This archive makes no remote repository change.
