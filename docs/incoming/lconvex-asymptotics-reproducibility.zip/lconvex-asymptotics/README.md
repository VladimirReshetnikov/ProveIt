# L-convex area asymptotics: article and portable replay

This package contains the 11-page report **All order asymptotics and inversion for L convex polyominoes**, its LaTeX source, mathematical reviews, exact coefficient data, and a small offline reproducibility program.

The main result is an all-fixed-orders expansion for the area coefficients, with

- κ = 13π²/24, C = 13√2/768, and N = n − 1/6
- aₙ = C N^(−3/2) exp(2√(κN)) [Σ_(r=0)^(M−1) cᵣ N^(−r/2) + O(N^(−M/2))]

The report also treats continuous inverse models, integer threshold brackets, eventual strict log-concavity, and an exponentially smaller exact generating-function remainder. Its enumerative premise is the known area generating function cited in the article. The numerical checks below do not replace the complex-analytic proof, certify a finite starting index for eventual conclusions, or establish literature priority. The reviews are internal mathematical checks, not external peer review or machine-checked formal verification.

## Start here

Open `article/lconvex-asymptotics.pdf`. The frozen source and final PDF hashes are:

- TeX SHA-256: `97170bff99f656f8e9af8ef0f909035eab4fb6fff9831610bb76e00f24f4fd0d`
- PDF SHA-256: `e4d7640f90a73369bde6b6bfa44283c9bb7c6b7651563bab15458493d74e432c`

From the extracted package root, verify the complete file inventory and hashes:

```sh
python3 code/verify_package.py
```

The standard-library-only replay requires Python 3.10 or later. The recorded run used Python 3.12.14. Choose a destination that does **not** exist:

```sh
python3 code/replay.py --output-dir ../lconvex-replay-core
```

For inverse reversion and floating-point diagnostics, install the optional versions in `requirements-optional.txt` through your usual trusted package-management process, then run:

```sh
python3 code/replay.py --output-dir ../lconvex-replay-full --extras
```

The replay itself performs no network calls, dependency installations, shell commands, or writes outside the specified output directory. Both Python entry points reject `-O` and `-OO`. Existing output destinations are refused. Run outputs are intentionally separate from the immutable package: putting them inside the package would make its complete-inventory manifest check fail.

Default work: exact integers through n = 2000; exact q-series identities through q⁹⁶; rational local/forward expansion through order 12; optional inverse order 4 and 90-decimal-digit numerical diagnostics. A default full run is small enough for an ordinary laptop; symbolic higher-order inverse reversion is substantially more expensive than the exact forward calculation.

## What the checks establish

1. **Exact local expansion.** Fraction arithmetic starts with T₀ = 1/(1 + exp(−z)) and iterates
   T_(j+1) = −exp(−jz)(1 − exp(−(j+1)z))/(1 + exp(−(2j+3)z)) Tⱼ.
   Since Tⱼ has z-adic order j, computing through degree M uses only 0 ≤ j ≤ M. The program squares D = ΣTⱼ to obtain the rational bₘ. It then computes hᵣ = (2√κ)ʳ cᵣ as a rational polynomial in κ. No symbolic square roots or fitted constants are needed.
2. **Two independent area computations.** The small-degree test directly expands the original f recurrence and its original generating-function denominator. It checks every coefficient against the transformed g recurrence. The latter generates all 2001 integers a₀ through a₂₀₀₀, comparing them with the archived exact reference data.
3. **Exact generating-function identities.** Integer truncated polynomial arithmetic independently constructs the partial-theta B, the rational-summand D, the product P, and the literal finite-product E in R = 1 + E/(q;q)∞. It verifies B = D and A = P B² + R through q⁹⁶. These finite regression checks do not by themselves prove the identities for all q.
4. **Optional inverse reversion.** SymPy derives the logarithmic coefficients and both logarithmic and Lambert-centered inverse corrections through order 4. Substitution gives zero residual through that order. The displayed article coefficients are explicitly compared with the derived ones.
5. **Optional numerical diagnostics.** mpmath compares the asymptotic truncations with exact integers at n = 100, 200, 500, 1000, 2000. It also evaluates the original generating function, D, the partial-theta B, and the independent E expression at three positive-real and three nonreal q values. These are floating-point diagnostics with extra truncation terms, not interval-certified error bounds.

At n = 2000 the nine-term shifted approximation has relative error approximately −1.114997216 × 10⁻⁹. The default pointwise decomposition checks agree to about 90 decimal digits in normalized error.

## Output files

- `forward-series.json`: rational coefficients of D(exp(−z)), its square, and hᵣ polynomials in κ. Coefficient arrays use increasing degree; recover cᵣ = hᵣ/(2√κ)ʳ
- `exact-identities.json`: exact q-series check outcomes and initial terms
- `coefficients.txt`: index/value pairs a₀ through a_N
- `inverse-series.json`: optional exact logarithmic and Lambert-centered inverse coefficients
- `numerical-diagnostics.json`: optional approximate relative errors and pointwise diagnostics
- `receipt.json`: parameters, software versions, reference-data hash, pass status, and output hashes

`receipts/` contains the recorded default full run. Mathematical outputs are deterministic for the recorded versions. Across library versions, expression rendering, floating-point last digits, and version fields can change without changing the identities. Exact integer/rational outputs should agree. The archived reference file has no final newline; the generated coefficient file has one, so their byte hashes intentionally differ although every index/value pair matches.

To request further finite forward coefficients, for example:

```sh
python3 code/replay.py --output-dir ../lconvex-order-20 --series-order 20
```

Other options are `--max-n`, `--q-degree`, `--inverse-order`, and `--precision`; use `--help`. Each fixed forward order uses finite exact arithmetic. This is not a convergence claim for the full formal asymptotic series, nor an optimal-truncation theorem.

## Rebuild the article

Use a locally installed TeX Live or compatible `pdflatex` setup with `geometry`, `fontenc`, `lmodern`, `microtype`, `amsmath`, `amssymb`, `amsthm`, `mathtools`, `booktabs`, and `hyperref`. No network or package download is attempted. A Linux fallback locates already-installed TeX resources when format/map discovery is incomplete.

```sh
sh article/build.sh ../lconvex-pdf-build
```

The destination must be fresh. The script runs two passes with shell escape disabled and keeps build products out of the source directory. PDF bytes need not be identical across builds or TeX versions because timestamps, identifiers, fonts, and engine metadata may differ. The bundled PDF is the separately reviewed final rendering of the exact frozen TeX source; every page was visually inspected.

## Integrity and safe ZIP extraction

`MANIFEST.json` lists all distributed regular files except itself, with sizes and SHA-256 hashes. It proves consistency with the manifest, not authenticity of a publisher. The delivered archive's SHA-256 is supplied separately to avoid a circular self-hash.

To extract a ZIP using the included verifier, first obtain this script from a trusted copy of the package, then run:

```sh
python3 code/verify_package.py --archive /path/to/lconvex-asymptotics-reproducibility.zip --extract-to ../fresh-extraction
```

The helper refuses an existing destination, unsafe names, traversal, links, duplicate or encrypted members, nonregular files, and oversized archives. It then verifies the extracted manifest. Ordinary extraction tools can also be used, followed by the manifest check above.

## Audits and provenance

- `audit/mathematical-audit.md`: the earlier substantive mathematical audit, retained verbatim with its reviewed research-source hash
- `audit/final-source-review.md`: explicit comparison and approval of the integrated final TeX source, including the new inverse, threshold, remainder, and log-concavity claims
- `audit/final-pdf-visual-approval.json`: final source/PDF hashes and visual-review scope
- `audit/computational-review.md`: code review, finite-check scope, and safety tests
- `receipts/`: executable-replay results, not proof certificates

The earlier research draft and exploratory scripts are deliberately not distributed. Their relevant mathematical content is integrated into the article, and the archived coefficient data retain their original bytes. No private conversation context, workspace-specific paths, third-party article PDFs, or TeX build byproducts are included.

## Primary references

- Guttmann–Kotěšovec, *A numerical study of L-convex polyominoes and 201-avoiding ascent sequences* (2023): https://arxiv.org/abs/2109.09928
- OEIS A126764: https://oeis.org/A126764
- Heine's first transformation, DLMF 17.6.6: https://dlmf.nist.gov/17.6#E6
- Fine's second transformation, DLMF 17.6.10: https://dlmf.nist.gov/17.6#E10

The article contains the full bibliography and precise analytic argument.
