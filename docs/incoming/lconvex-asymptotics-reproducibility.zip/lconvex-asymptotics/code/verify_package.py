#!/usr/bin/env python3
"""Verify the complete package manifest, optionally safely extract its ZIP.

No network calls. An extraction destination must not exist. ZIP traversal,
symlinks, duplicate names, nonregular entries, encryption, and oversized
archives are refused. This checks integrity, not publisher authenticity.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile

if sys.flags.optimize:
    raise SystemExit("Refusing optimized Python (-O/-OO): run with checks enabled.")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def safe_name(name):
    p = PurePosixPath(name)
    return (name and not p.is_absolute() and "\\" not in name
            and not any(x in ("", ".", "..") for x in name.split("/"))
            and p.as_posix() == name and ":" not in name)


def extract(archive, destination):
    require(not destination.exists() and not destination.is_symlink(), "extraction destination already exists")
    with zipfile.ZipFile(archive) as z:
        infos = z.infolist()
        require(len(infos) <= 1000, "too many ZIP members")
        require(sum(i.file_size for i in infos) <= 128*1024*1024, "ZIP expands beyond 128 MiB")
        seen = set()
        for info in infos:
            require(safe_name(info.filename), "unsafe ZIP member: "+info.filename)
            require(info.filename.startswith("lconvex-asymptotics/"), "unexpected ZIP root")
            require(info.filename not in seen, "duplicate ZIP member")
            seen.add(info.filename)
            mode = info.external_attr >> 16
            require(not info.is_dir() and stat.S_IFMT(mode) in (0,stat.S_IFREG), "nonregular ZIP entry")
            require(not (info.flag_bits & 1), "encrypted ZIP entry")
        destination.mkdir(parents=True,exist_ok=False)
        for info in infos:
            target = destination.joinpath(*PurePosixPath(info.filename).parts)
            target.parent.mkdir(parents=True,exist_ok=True)
            with target.open("xb") as f:
                f.write(z.read(info))
    return destination/"lconvex-asymptotics"


def verify(root):
    require(root.is_dir() and not root.is_symlink(), "package root is not a regular directory")
    paths = list(root.rglob("*"))
    require(not any(p.is_symlink() for p in paths), "package contains a symlink")
    require(all(p.is_file() or p.is_dir() for p in paths), "package contains a nonregular entry")
    manifest = root/"MANIFEST.json"
    value = json.loads(manifest.read_text(encoding="utf-8"))
    entries = value["files"]
    require(all(safe_name(name) and name != "MANIFEST.json" for name in entries), "unsafe manifest path")
    found = {p.relative_to(root).as_posix() for p in paths if p.is_file()}
    require(found == set(entries)|{"MANIFEST.json"}, "package file inventory differs from manifest")
    for name, expected in entries.items():
        data = (root/name).read_bytes()
        require(len(data) == expected["bytes"], "wrong size: "+name)
        require(hashlib.sha256(data).hexdigest() == expected["sha256"], "wrong SHA-256: "+name)
    return len(entries)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--archive",type=Path)
    parser.add_argument("--extract-to",type=Path)
    args = parser.parse_args()
    require(bool(args.archive) == bool(args.extract_to), "--archive and --extract-to must be supplied together")
    root = extract(args.archive,args.extract_to) if args.archive else args.root
    count = verify(root)
    print("PASS: verified "+str(count)+" manifest entries in "+str(root.resolve()))


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError,ValueError,KeyError,OSError,zipfile.BadZipFile) as error:
        raise SystemExit(str(error)) from error
