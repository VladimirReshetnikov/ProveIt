# A pointwise three-halves correction for A290268

The nine-page `article.pdf` proves that there are constants C>0 and N0 such that

    a(N) >= beta(N) + C N^(3/2) >= 3N^2/8 + C N^(3/2)

for every integer N>=N0. Here a(N) is the number of nonzero derivative terms in OEIS A290268, and beta(N) is the source's known bulk count. This is a pointwise theorem at each sufficiently large order. Neither C nor N0 is evaluated numerically.

The proof combines a uniform growing-offset phase estimate for |b| of order sqrt(d) with an elementary monotone-phase count. Both integer parity conditions are imposed exactly. The new cells are distinct derivative monomials and lie outside the known bulk. No equidistribution assumption, numerical experiment, or finite-scan extrapolation is used.

The full noncancellation conjecture and the conjectured leading term N^2/2 remain open. The report does not claim exact zeros from a vanishing asymptotic phase.

## Files and reproduction

- `article.tex` and `counting_sections.tex` are the complete proof source
- `build_local.sh` is the pdfLaTeX wrapper used to build the included PDF
- `verify_rational_band.py` uses exact Python fractions to check the rational Taylor certificate locating the chosen interval inside the regular saddle branch
- `rational_band_certificate.json` records that exact certificate

Run the certificate with `python3 verify_rational_band.py`; it requires only the Python standard library. On a standard TeX Live installation, compile `article.tex` twice with pdfLaTeX.

The full written proof received independent mathematical review, every final PDF page was visually checked, and the exact certificate was rerun. These are ordinary mathematical proofs, not Lean formalizations or externally refereed results. No exhaustive priority claim is made. The source comparison is pinned to ProveIt commit `ca81647a9f679e96d49ffdbc54b0c0ab13d10a36`, linked in the bibliography.
