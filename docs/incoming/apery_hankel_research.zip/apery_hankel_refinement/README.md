# Sharp Szegő asymptotics for Apéry Hankel determinants

Research article prepared for the ProveIt project, 1 October 2026.

Start with **apery_hankel_refinement.pdf**. The editable source is
**apery_hankel_refinement.tex**. All mathematical notation, proofs, numerical
qualifications, references, and further research questions appear there.

## Main results

For A_k = sum_j binom(k,j)^2 binom(k+j,j)^2 and
D_n = det(A_{i+j}) for 0 <= i,j <= n (OEIS A228143), set
C = 17 + 12 sqrt(2) and Lambda = C/4. If phi is Edgar's positive moment
density on [0,C], define

    K = (pi C/2) exp[(1/pi) integral_0^C log(phi(x))/sqrt(x(C-x)) dx].

The article proves

    D_n/D_{n-1} ~ K Lambda^(2n),
    log D_n = n(n+1) log Lambda + (n+1) log K + o(n).

In particular, the ratio plotted in the OEIS entry converges to
Lambda*K, numerically about **5.379471608281**. The numerical value of K
is about **0.633427435172**.

A second result constructs interleaved finite Hankel expressions E_m with
E_m decreasing to K. They are algebraic upper bounds computable from Apéry
moments alone. The original oscillating ratios are expressed exactly using
these envelopes and square-summable reflection coefficients.

Further proved results cover fixed nonnegative polynomial modifications,
fixed strides and shifts, a two-term inverse-index law, and a conditional
transfer theorem for higher-order terms. The hypothesis of the higher-order
transfer theorem is NOT established for the Apéry density in this report.

## Status and boundaries

* The repository's earlier Apéry article already proves quadratic
  logarithmic growth. This package refines that result rather than claiming
  its leading limit again.
* Edgar's positive moment-density theorem is a credited analytic input.
  The unit-circle method is classical Szegő theory, not a new general theorem.
* The sharp-ratio specialization and envelope construction are proved in the
  article. Absolute bibliographic priority is not established by the bounded
  literature search. The report has not been independently peer reviewed or
  formalized in a proof assistant.
* The logarithmic formula does NOT imply D_n ~ K^(n+1) Lambda^(n(n+1)).
  Polynomial/logarithmic prefactors and a full all-orders expansion remain
  further problems.
* Numerical decimals are not rigorously interval enclosed. Agreement at two
  working precisions is a stability check, not an error certificate.
* No changes were made to ProveIt or OEIS. The included OEIS text is an
  unsubmitted draft for editorial review.

## Contents

- `apery_hankel_refinement.tex`, `.pdf`: article and complete source.
- `code/verify_exact.py`: finite exact checks in Q(sqrt(2)), Python standard library.
- `code/moment_norms.cpp`: GMP high-precision Hankel minimum norms through n=200.
- `code/density_constant.py`: independent hypergeometric density quadrature.
- `code/make_figures.py`: regenerate both figures from the stored data.
- `figures/`: vector PDF and PNG figures used in the article.
- `data/exact_checks.json`: exact test results.
- `data/norms.csv`, `data/norms_3072.csv`: 4096-bit and 3072-bit moment calculations.
- `data/constant.json`: density quadrature, constant, and moment diagnostics.
- `data/precision_check.json`: comparison of both numerical precision runs.
- `sources.md`: source audit, repository revision, and literature-search scope.
- `oeis_update_draft.txt`: proposed text; not submitted.
- `Makefile`: convenience commands.

There are no bundled font files, third-party papers, or compiled executables.

## Reproduction

Run commands from this directory. Python 3.10 or newer is recommended.
The exact checks require no additional Python packages. For numerical
quadrature and figures, install `mpmath` and `matplotlib` in your environment.

### Article

A TeX installation with `latexmk`, `pdflatex`, Libertinus, and the packages
named in the preamble is required:

    latexmk -pdf -interaction=nonstopmode -halt-on-error apery_hankel_refinement.tex

The supplied vector figures suffice for this build; no computation needs to
be rerun. Font packages are dependencies, not distributed in this archive.

### Exact finite checks

    python code/verify_exact.py

This writes `data/exact_checks.json`. All assertions passed in the included
run: seven independent Bareiss determinants, fourteen circle minimum norms,
thirteen norm recurrences, and all applicable envelope identities.
Do not run Python with `-O`, which disables its assertions.

### Numerical moments

With a C++17 compiler and the GMP development libraries:

    g++ -O3 -std=c++17 code/moment_norms.cpp -lgmpxx -lgmp -o moment_norms
    ./moment_norms 200 4096 > data/norms.csv
    ./moment_norms 200 3072 > data/norms_3072.csv

Both included runs agree in every emitted 70-significant-digit field. The
program rejects nonpositive pivots and violations of interleaved envelope
monotonicity. Increasing the matrix size requires increasing precision;
passing those checks alone is not a proof of numerical accuracy.

### Independent constant calculation

    python code/density_constant.py --dps 40 --output data/constant.json

This is slower than the finite exact tests. It evaluates the continuation
sheet explicitly, uses endpoint asymptotics below angular distance 1e-8,
and checks the first five moments by independent quadrature. The endpoint
approximation error is not rigorously bounded in the implementation.

### Figures

    python code/make_figures.py

The script reads the stored CSV/JSON and writes the two vector PDFs and PNGs.
Plotting uses ordinary machine-precision coordinates; this does not replace
the high-precision computations from which those coordinates were obtained.

Equivalent convenience commands are `make pdf`, `make exact`, `make moments`,
`make density`, and `make figures`. The default `make` only builds the PDF.
