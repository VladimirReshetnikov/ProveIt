# Reset Petri Nets and Canonical Quadratic Certificates

Read report/reset-net-certificates.pdf or its editable LaTeX source. The report proves a concrete fixed reset-net reachability reduction, an exact accepting-word normal form, canonical quadratic minimum-outcome certificates, a real-domain parity obstruction, and a separate arbitrary-reset-trace compiler.

## Main result

The main unit-weight net has 539 places, 771 transitions, 2608 ordinary arcs and 233 reset arcs from three places. Its initial marking is L=L, R=R, T=0, reserve=0, budget=L+R, START=1, and zero elsewhere. Its exact target is DONE=1 and every other place zero. The initial expanded population is 2(L+R)+1.

If the deterministic source halts after h instructions, with initial counter mass B, final mass H and peak mass M, minimum pump fuel is M-B and minimum duration is h+H+2M-B+5. All accepting lengths are N_min+2z for natural z, with exactly one transition word at each length.

For each external source horizon h, the minimum-outcome quadratic has 2813h witnesses, 6h+2 affine squares and 762h nonnegative products. For natural parameters its natural and nonnegative-real zero fibers coincide and are empty or singletons. The natural-only all-duration variant adds one padding variable; allowing that variable to be real loses parity.

The generic reset-trace certificate handles consume, then reset, then produce, including weighted overlapping arcs. The main net's checked control projection has 4626N witnesses, 7N+6 squares and 771N products for external firing horizon N.

## Examples and optional variants

- Main L=6,R=0: 328 source instructions, peak 25, fuel 19, minimum 388 net firings. Every firing and every polynomial summand is checked
- Shared-arc three-counter variant: 778 places, 1007 transitions, 3546 ordinary arcs and exactly 3 reset arcs. The corresponding full 446-firing run is stored and checked
- Direct two-counter prime-coded variant: 8417 places, 10756 transitions, 38336 ordinary arcs and 2340 reset arcs from two places
- Shared-arc two-counter variant: 10761 places, 13098 transitions, 47700 ordinary arcs and exactly 2 reset arcs

For raw_A=64, the two-counter minimum durations are 857788604036216584 (direct) and 857788604036217896 (shared). These huge durations are established by exact proved macro accounting, not by enumerating the physical runs or full-horizon witnesses. The affine reset loader takes raw_A; the external completeness reduction a=2^L*3^R is separately charged.

## Reproduce

Python 3.9 or newer with its standard library is sufficient for the checks; the release was tested with Python 3.12. Run without Python optimization flags, because the checkers use assertions:

    ./run-checks.sh

The script runs source checks, regenerates both literal direct nets, replays the full examples, verifies every arithmetic witness term, exercises independent coefficient/semantic checks, reconstructs all 8408 prime-source rows, and rebuilds the shared-arc variants. Detailed commands and scope are in the report. Checkers write their receipts into the packet; no network access is needed.

To rebuild the PDF with TeX Live:

    ./build-pdf.sh

The LaTeX build uses only the report source and standard packages. Intermediate files go to .build, which is not part of the delivered archive. The PDF is report/reset-net-certificates.pdf.

To verify the delivered bytes before rerunning generation:

    python3 verify-manifest.py

## Complete exports

- source/: full 15-state table, literal 528-row source in JSON and readable text, macro metadata, source trace and source proof
- reset_net.json and net_ledger.json: all 771 labelled transitions and all arcs
- source_quadratic.py, peak_quadratic.py and reset_quadratic.py: finite-horizon polynomial compilers
- canonical_peak_schema_h1.json, projected_trace_schema_T1.json and all_duration_schema_h1.json: complete one-step affine-squares-and-products exports
- accepting_* files: full traces and sparse witnesses; every omitted declared witness coordinate is zero
- checks/: independent JSON, coefficient, rational-domain and generic-input checks
- two-counter/: complete literal 8408-row source, direct net, horizon-one schemas and source checks
- two-reset-audit/: independent prime-macro reconstruction, exact cost/peak accounting and incidence comparison
- shared-reset-arcs/: complete shared-arc nets, horizon-one source-outcome schemas, full 446-step example and macro-counted large example
- shared-checks/: independent routing, invariant, full-witness and prime-macro checks

## Credit and claim boundaries

The budget/loss reduction and reset-net decidability boundaries are classical; the report explicitly credits BFHMO 2024 Proposition 3.2, Schnoebelen, and the established one-versus-two reset-arc/place literature. ProveIt already contains bounded Petri and Diophantine certificate work. This package contributes a concrete assembly, exact interfaces and word/length/fuel formulas, inverse witness maps, and checked quantitative costs.

These are externally indexed finite-horizon certificate families. They do not establish a fixed-arity unknown-time polynomial, finite-/single-fold MRDP theorem, global novelty, size record, or 87-operation improvement. The continuous domain here means nonnegative-real polynomial witnesses; the Petri-net firing semantics is discrete. The proofs plus exact finite checks are not a proof-assistant formalization.

Third-party papers are linked in the bibliography and are not redistributed. Source data and serialization are attributed in SOURCE_PROVENANCE.json.
