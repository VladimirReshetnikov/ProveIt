REPORT 113
Order five B tree histories
Convergent psi series and coefficient asymptotics
2 October 2026

START HERE

Read report113.pdf. The standalone source is report113.tex.
This report proves the m=2 case of Burghart and Wagner's B-tree history
conjecture for OEIS A333497. It includes a convergent local psi series,
coefficient expansions at every fixed order, corrected smooth inverse
models, all-fixed-order Lambert W corrections, and threshold-rounding
bounds. It does not settle the conjecture for all m.

The source convention is important: h_n counts reduced 5-historic trees
with n internal vertices, equivalently histories of length n+2.
The leading law is 30(n+2)! rho^(-n-3).
The rigorous bound is 180^(1/4) <= rho <= 60^(1/3).
All additional decimal estimates of rho or C are EXPLORATORY and are not
certified intervals or justified counts of trustworthy digits.

FILES

report113.tex                  Standalone mathematical source
report113.pdf                  Rendered report
build.py                       Two clean, byte-identical PDF builds
pack.py                        Deterministic verified ZIP generation
MANIFEST.json                  Closed SHA-256 and byte-size inventory
checks/                        Exact checks, data, mutations and numerical fits

The local psi series is convergent. The large-n coefficient and inverse
expansions are asserted only at arbitrary fixed finite order. Do not sum
an infinite number of transferred sectors at a fixed index.

DEPENDENCIES

Exact checks: Python 3.10 or later and SymPy (tested with 1.14.0).
Exploratory fits only: mpmath (tested with 1.3.0).
Manifest checking: Python standard library only.
PDF building: pdfTeX/pdflatex, with the standard LaTeX packages geometry,
fontenc, lmodern, amsmath, amssymb, amsthm, mathtools, booktabs, microtype,
hyperref and enumitem. The delivered build was tested with pdfTeX 1.40.26.
A different TeX/font distribution can produce different PDF bytes without
changing the mathematical content. The reproducibility claim is byte
identity in the tested toolchain, including independent clean directories.
The scripts do not install software or access the network.

INTEGRITY AND BUILD

Run from the report113 directory after extracting the archive:

  python3 -B checks/check_manifest.py .
  python3 -B build.py
  python3 -B checks/check_manifest.py .

build.py creates its TeX formats and intermediates in temporary directories,
compiles twice from independent clean states, checks references and overfull
boxes, compares the resulting bytes, and writes report113.pdf. It does not
modify report113.tex. It fixes build timestamps and PDF metadata.

Never use --write to validate a received archive. That option creates a new
manifest and is intended only for an author deliberately repackaging files.
A manifest detects changes relative to its own inventory; it is not an
authenticated digital signature and does not establish source trust.

EXACT CHECKS

  python3 -B checks/exact_check.py
  python3 -B -O checks/exact_check.py

Both runs must return PASS_EXACT_FINITE_CHECKS. The checker uses explicit
exceptions, so optimization does not remove its checks. It verifies the
29 displayed OEIS values independently retrieved during preparation and
regenerates all 501 terms from the exact recurrence. The supplied 501-term
file is a generated recurrence fixture, not a downloaded OEIS b-file.
The exact checker and finite fixtures supplement the analytic proof; they
do not establish continuation, infinite-series convergence or transfer
hypotheses by finite testing.

OPTIONAL EXPLORATORY NUMERICS

  python3 -B checks/exploratory_fit.py

This runs at 100 decimal digits by default and prints the fitted results.
Use --output with a path outside this extracted directory if saving fresh
results; adding files here intentionally makes the closed inventory fail.
The supplied exploratory_results.json records a reference run. Repeating
the fit is not interval verification or a proof of a numerical enclosure.

All original sources are cited and linked in the report. Downloaded papers
and temporary page-render images are not included in the archive.

FULL VALIDATION AND MUTATION REPLAY

  python3 -B checks/validate.py --with-numerics --output /tmp/report113-validation.json

The harness copies the check files to a fresh directory, runs the exact
checker normally and with -O from an unrelated working directory, compares
reference results, tests deliberately damaged fixtures and manifests, and
optionally repeats the separate exploratory numerical fits. It requires
specific error diagnostics for its negative controls and confirms that the
delivered source bytes are unchanged. Its summary is validation_results.json
inside checks/. See checks/README.txt for the detailed check scope.

FINAL PACKAGE REVIEW

The PDF was rendered and every one of its 13 pages was visually reviewed.
No clipped text, overlap, unreadable formulas or broken references were
observed. The deterministic build also rejects overfull boxes and unresolved
references. These layout checks do not replace mathematical proof review.

RECREATE THE ZIP

  python3 -B pack.py /tmp/report113-reproducibility.zip

The output path must be outside the package directory. pack.py first verifies
the closed manifest, then writes all files beneath report113/ with sorted
paths, fixed timestamps and fixed file modes. ZIP byte identity also assumes
the same Python/zlib compression toolchain.
