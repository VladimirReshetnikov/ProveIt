# Direct Diophantine Certificates for Rational Signal Machines

A 15-page research article with complete proofs and exact-arithmetic replay code.

## Result

For each externally supplied finite collision schema, the compiler produces a sum of squares of integer affine residuals. Natural zeros are exactly its geometric realizations. The witness is unique, the witness Hessian is positive definite when nonempty, and the sparse representation is linear in initial support and event count for a fixed bounded-arity machine.

The article proves typed endpoint completeness, denominator divisibility, a four-speed witness-height bound, and a denominator-growth example showing why exponential clearing scales can be necessary. It distinguishes fixed-schema semilinear feasibility from unbounded halting.

## Read and edit

- `article.pdf`: compiled article
- `article.tex`: editable LaTeX source
- `build.sh`: repeatable local PDF build

To rebuild, run `sh build.sh`. A working TeX Live installation with the packages named in Appendix A is required. Generated TeX intermediates stay in `build/`. No external source PDFs are bundled.

## Replay

Python 3.10 or later, standard library only:

    python3 scripts/run_replay.py

Keep assertions enabled; do not use Python's `-O` option. The runner performs all tests in a temporary directory, compares exact JSON results with `expected_receipts/`, verifies the generated coefficient examples against `examples/`, and writes results to `replay-output/`. An alternate result directory may be specified with `--output DIR`.

The expected results include 122 full-layer certificates, 444 sparse certificates, and 878 additional certificates, plus the worked examples and 64 exact batches of the denominator-growth shuttle. Certificate totals include prefix/halting variants and are not numbers of universal-machine programs.

## Scope

- The machine, initial labels and length, and finite schema are compiler data
- The replay collision tables are identity-completed: absent rules are transparent
- The universal 13-meta-signal, 21-non-blank-rule table is cited but has not been transcribed or replayed
- No fixed-arity unbounded quadratic, improved 75/87 operation count, exhaustive novelty, or proof-assistant formalization is claimed
- No semantics past a Zeno accumulation are asserted

See `manifest.json` for the build/replay inventory, and `CHECKSUMS.sha256` for artifact integrity. File hashes establish the distributed bytes; finite replay tests supplement rather than replace the proofs.
