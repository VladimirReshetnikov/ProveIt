# Every Countable Turing Ideal Is a Coarse Core

**Effective perfect exact pairs and rich fibres of the core map**

Research draft prepared for Vladimir Reshetnikov, 28 September 2026.

## Read the article

- `article.pdf`: the complete article, including proofs and eight proposed research questions.
- `article.tex`: self-contained LaTeX source, with an internal bibliography.
- `PROOF_AUDIT.md`: theorem dependencies, important quantifiers, and limitations.
- `SOURCES.md`: pinned repository provenance and primary-source literature.
- `code/verify.py`: deterministic finite verification using the Python standard library.
- `data/verification.json`: output of the executed verifier.
- `build.sh`: verification and PDF build.

## Results

For a binary sequence X, Core(X) is the collection of sets computable from every
coarse description of X. Theorem 1.1 proves that its possible values are exactly
the countable nonempty Turing ideals. The proof constructs a two-level code from
any countable sequence of generators. Its coarse descriptions have a computable
normal form: arrays that are finite variants of the generators in each row.

Theorem 1.2 constructs a perfect family of descriptions of that same code, with
the prescribed ideal as the common lower cone of any two distinct members.
If B_m is the finite join of the first m generators and H is the countable join
of the B_m', two descriptions can be chosen with both jumps below H. The family
has an H-computable common density-zero error envelope and an H-computable
modulus. An arbitrary member has a bound using H together with its branch
parameter; the claim is not that uncountably many sets are computable in H.

Theorems 7.3 and 7.5 show that every core fibre contains an order-embedded upper
cone of the Turing degrees, for both uniform and nonuniform coarse reducibility.
In a suitable class in that fibre one can construct an exact pair whose two
jumps equal any prescribed degree above the jump of the uniform generator join.
Corollary 7.6 realizes every countable ideal in continuum many coarse degrees
having no least Turing-degree representative.

## Relationship to ProveIt

Inspected revision:

`1a1396d4d3a2ac6812692df520517d86ba3a4785`

The coarse-degree synthesis explicitly leaves countable-core realization
unclassified. This draft answers that question, rather than repeating the
repository's negative answer to its earlier least-representative target C1.
The repository already contains non-effective perfect exact-pair results for
arbitrary targets. The present family construction is included for its concrete
normal form, oracle bound, and effective common envelope.

## Status

These are ordinary mathematical proofs supplied in this draft. The work is not
independently refereed and is not Lean-certified. The finite checks are not
proofs of the infinitary computability theorems.

The classification also follows from published cone-avoiding compactness once
the two-level code is chosen. Ordinary exact-pair existence, the no-splitting
method, the limit lemma, and jump inversion are classical. The article does not
claim global priority for the combined refinements. It resolves the explicit
repository classification target but does not classify all spectra, exclude
minimal elements, or solve the general effective-dense problem.

## Reproduce

From this directory:

```sh
python3 code/verify.py --output data/verification.json
sh build.sh
```

The verifier needs only Python 3.10 or later. The PDF build needs a LaTeX
installation containing the packages listed at the top of `article.tex`,
including `newpx`, `amsmath`, `mathtools`, `microtype`, `tcolorbox`, and `hyperref`.
The delivered PDF is already compiled. Running `pdflatex article.tex` three
times is an alternative to the shell script after running the finite verifier.

The delivered run passed 552,927 finite check cases. These cover arithmetic,
majority bounds, finite masks, normalizer identities, and finite no-cross-
disagreement rectangles. No external oracle, theorem prover, or online service
is used by the verifier.
