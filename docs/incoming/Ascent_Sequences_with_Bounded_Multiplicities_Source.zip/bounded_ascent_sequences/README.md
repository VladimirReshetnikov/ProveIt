# Ascent sequences with bounded multiplicities

This package contains a self-contained mathematical report, editable LaTeX source, and reproducible exact checks for ascent sequences in which each value occurs at most a fixed cap r.

## Mathematical scope

For each fixed integer r >= 2, the report proves factorial-normalized root growth and consecutive-ratio convergence with the constant

mu_r = 1 / integral_0^infinity [log(E_r(w))/(E_r(w)-1)] dw,
E_r(w) = sum_(j=0)^r w^j/j!.

It also proves exact sorted-capacity enumeration in O(N^(r+2)) arithmetic operations, the full positive-terminal-mark exponential growth limit, multiplicity and ascent laws, exponential concentration, and a full endpoint large-deviation principle. The large counting-threshold inverse uses the principal Lambert branch W_0 with argument mu_r*log(y)/e.

A separate analytic chapter studies r -> infinity for the constants themselves. It gives exact positive Taylor sectors, fixed-sector expansions to every fixed inverse-cap order, the gap from 6/pi^2, and cap-threshold inversion using W_-1 and carefully stated integer-boundary qualifications.

These are not claims about a word-length prefactor, amplitude, Gaussian fluctuation law, a full word-length transseries, or a uniform limit when r grows with N. The two asymptotic variables are kept distinct.

## Contents

- article.pdf: the complete report
- article.tex and section .tex files: editable source
- article_standalone.tex: the same report with section inputs expanded
- build_local.sh: reproducible local pdfLaTeX build
- run_checks.sh and checks/: exact standard-library Python verification and fail-closed validator regression tests
- PROVENANCE.json: source URLs, coverage, verification results, and hashes
- MANIFEST.sha256: checksums for all packaged payload files

No network access is needed to rebuild the report or replay its exact checks. Optional high-precision numerical diagnostics, clearly separated from the exact tests, may need mpmath. Exact symbolic sector-coefficient diagnostics may additionally need SymPy; the mathematical proofs do not depend on either library.

## Build

A TeX Live installation should include pdfLaTeX, amsmath, amsthm, mathtools, lmodern, microtype, geometry, hyperref, xurl, booktabs, and array. Run:

    ./build_local.sh

The script creates a local format and font-map environment, compiles three passes, and copies the resulting PDF to article.pdf. A standard installation can also compile article.tex directly three times. The standalone source removes the need for separate section files.

## Verify

Run:

    ./run_checks.sh

See checks/README.md for exact declared coverage, source attribution, and optional diagnostics. Correctness checks use explicit exceptions so that Python optimization cannot remove them. Parser and validator regression tests deliberately supply malformed, missing, duplicate, out-of-range, and incorrect data in normal Python and Python -O; such inputs must be rejected.

The finite computations corroborate the formulas. They are not substitutes for the ordinary mathematical proofs in the PDF.

## Integrity

From the package directory, run:

    sha256sum -c MANIFEST.sha256

This verifies payload integrity against the distributed manifest. It is not a cryptographic authorship signature. Rebuilding a file may legitimately change its checksum if the TeX distribution differs; exact computation results should remain unchanged.
