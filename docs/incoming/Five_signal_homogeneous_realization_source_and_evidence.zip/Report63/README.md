# Report63: Exact local homogeneous realization with five live signals

This release presents the exact local full-section realization criterion: a rational matrix N is realizable on some nonempty full-dimensional open chamber exactly when det N is nonzero and C intersect N^(-1) C is nonempty. The physically implemented translations, exact intermediate-corner guards, rational endpoint decision, non-eigenray example, and positive-integer certificate are included with their precise limitations.

## Contents

- `Report63.pdf`: typeset research article, including two analytic diagrams and the full native arithmetic DAG transcription
- `Report63.tex`: standalone editable source, deterministically flattened from the ten modules in `manuscript/`
- `science/frozen-proof/`: complete unchanged Report63 scientific packet, including inert author checker, literal DAGs and original recorded evidence
- `audits/scientific/`: complete unchanged accepted independent audit, including its fresh core checker and separate sparse-polynomial/DAG checker
- `dependencies/proofs/`: unchanged dependency proof/review text and copy provenance
- `INPUT_PINS.json`: exact frozen inventories with bytes, SHA-256, modes and nanosecond modification times
- `tools/`: owned report-bound typesetting, integrity, packaging and synthetic selftest helpers
- `qa/` and `manuscript-review/`: fresh release-tool, build, preservation, manuscript and direct model visual-review evidence

All files under `science/`, `audits/`, and `dependencies/` are frozen. The original scientific README predates its independent audit and is preserved verbatim; the accepted review under `audits/scientific/` gives the later assessment. Later review evidence is assembled outside those roots. Nothing in the typesetting or packaging tools invokes the author mathematical script, earlier constructor, physical simulator, stored collision schedule, or Lean. The independent static checkers have a separate execution boundary described below.

## Trust boundary

Use the installed Python and TeX Live/Poppler tools recorded in the build dependency lock. The release helpers require Python `-I -S -B`, without optimization; they install nothing. All destinations must be new canonical absolute paths with an existing parent, outside the release and protected original source roots. Symlinks, hardlinked input files, path aliases, unexpected entries and overlaps are rejected. An unsuccessful run can leave its new output directory for diagnosis; existing outputs are not overwritten.

Obtain the final manifest, manuscript-pin-map and dependency-lock digests from the separately supplied reviewed receipts. Hashes are integrity commitments, not digital signatures; an untrusted file and a digest delivered beside it do not independently authenticate one another.

The build lock covers interpreter/executable bytes, selected font maps and the union of system inputs recorded by the fresh-format run and all three TeX passes. It does not cover shared libraries, Python's standard library or the operating system, and is not a sandbox for hostile source. It is intended for the inspected owned manuscript and pinned installed packages.

## Authenticate and build

From this release directory:

    python3 -I -S -B tools/release63.py check-inputs

Rebuild with the separately supplied pins:

    python3 -I -S -B tools/build_report63.py \
      --pins-sha MANUSCRIPT_PINS_SHA256 \
      --dependency-lock-sha BUILD_DEPENDENCIES_LOCK_SHA256 \
      --require-packaged-match --output-dir /tmp/report63-rebuild-new

The builder checks locked bytes before launching subprocesses, creates a fresh format in its new external workspace, disables shell escape and automatic font generation, and compiles three times. Every recorder is retained before a later pass can overwrite it, so a first-pass-only package remains in the authenticated union. Dependency receipts must equal the lock. Every PDF page is rendered; PNG signatures, chunk order, CRCs, dimensions and complete decompressed rasters are checked. Final overfull boxes or unresolved references are rejected. Direct model all-page visual review remains a separate check.

The external output keeps the PDF/text/log, complete command outputs, four recorder files, dependency union, page inventory and before/after preservation receipts. A successful bootstrap is labeled BOOTSTRAP and is not a preflight-lock-verified build. PASS requires the reviewed lock.

For owned preparation or a deliberate new package set:

    python3 -I -S -B tools/release63.py prepare --output-dir /tmp/report63-prepared-new
    python3 -I -S -B tools/build_report63.py \
      --pins-sha INSPECTED_MANUSCRIPT_PINS_SHA256 \
      --bootstrap --output-dir /tmp/report63-bootstrap-new

`prepare` writes standalone TeX and its source pin map externally; the manuscript owner copies them into their respective release locations after inspection. Promote the inspected bootstrap's exact BUILD_DEPENDENCIES.json bytes to the lock and acquire its independent digest before a locked build. Helpers never rewrite their inputs.

## Separate independent static replay

The frozen audit's README gives the accepted scientific scope. The core requires SymPy 1.14.0; the separate certificate checker uses the standard library. Read and inspect those checkers before executing them. From the release root, with fresh outputs outside the entire release:

    python3 -I -B audits/scientific/independent_static_audit.py \
      --source "$PWD/science/frozen-proof" \
      --output /tmp/report63-core-replay-new --archived-source

    python3 -I -S -B audits/scientific/certificate_audit/check_certificate.py \
      --source "$PWD/science/frozen-proof" \
      --output /tmp/report63-certificate-replay-new

These read source proof/code/JSON as inert data. No physical next-event selection, saved schedule, author-script import, or Lean run occurs. Archived core mode records 832 named assertions, retaining all mathematical checks and included dependency authentication. The source-bound 840 run additionally authenticates four historical original files through eight assertions. Portable mode intentionally does not reopen those absolute locations. The certificate checker records 737 assertions. The different overlapping assertion counts are not theorem counts and must not be added as an evidence-strength total.

The checkers protect their source packet; their output guards do not claim to protect every surrounding release directory. Keep outputs external as shown, and verify release preservation separately. Their historical initial versions/results are retained honestly as history, not substituted for the final accepted versions.

## Owned release tests and deterministic archive

Run the owned synthetic suite with a fresh external destination:

    python3 -I -S -B tools/selftest63.py --output-dir /tmp/report63-selftest-new

The 39 owned cases are self-testing, distinct from independent acceptance. They cover fresh format and lock use, first-pass-only inputs, TMPDIR/TEMP/TMP isolation, source and metadata corruption, path/alias rejection, malformed PNGs, deterministic archives, restored metadata and relocated PDF equality. Only synthetic TeX is used in these tests.

After all evidence is assembled, create a prospective manifest externally, inspect it, and copy its exact bytes to RELEASE_MANIFEST.json:

    python3 -I -S -B tools/release63.py manifest --output /tmp/report63-manifest-new.json
    python3 -I -S -B tools/release63.py verify --manifest-sha256 MANIFEST_SHA256
    python3 -I -S -B tools/release63.py archive \
      --manifest-sha256 MANIFEST_SHA256 --output /tmp/Report63-source-evidence-new.zip

The manifest excludes itself and release-root metadata, but includes every other file and every subdirectory's metadata. A post-seal change needs a new manifest and trusted pin. Archive order, timestamps, regular-file modes and compression parameters are deterministic; repeated archives of one seal must be byte-identical.

Restore exact authenticated metadata with the supplied extractor:

    python3 -I -S -B tools/release63.py extract \
      --manifest-sha256 MANIFEST_SHA256 \
      --archive /tmp/Report63-source-evidence-new.zip \
      --output-dir /tmp/report63-relocated-new

The extractor authenticates the archived manifest before writing, rejects duplicate or unexpected entries, checks every payload and CRC, and restores modes and nanosecond mtimes. Ordinary unzip is not claimed to retain those exact metadata. In the relocation, repeat `verify`, the locked PDF build and the independent static replays with external output directories. Separate terminal QA provides a final archive roundtrip.

## Scientific scope

The theorem supplies some exact local chamber for the specified full homogeneous N, not every compatible input, a prescribed chamber, or an invariant domain. Local existence does not imply an infinitely valid input; the escaping-gap example rules that out explicitly. The endpoint property is polynomial-time decidable, whereas the selected physical compiler may have large output size. Clock conclusions assume all repeated-word guards.

The certificate has eight positive-integer witnesses, five squared residuals, and exact joint degree six in matrix inputs and witnesses. Its witness fibers are infinite under simultaneous scaling of g and h. Native signed/positive gap-input DAGs use 48/57 binary operations; these counts exclude the explicitly displayed centered conversion SMB and are not collision counts or minima. No Turing universality, priority, exhaustive novelty, global reversibility, or continuation beyond accumulation is claimed.

## Final manuscript integrity pins

The final manuscript has 18 pages, with modular and standalone sources pinned to the exact rendered text:

- PDF: `eb8d4d7c0cc0c98a7b706efe5e262d6b17699e21be7976957725f836420ad3ed`
- Standalone TeX: `232bac78b073aa9b3896aa1dade2a5f6372a000240ec67e9923dc6287555eb65`
- Manuscript pin map: `8dbeb0e7bdcbf949ebba9a699ab262dbb84b0111d9bb60d85c4c2a69aa10cbf1`
- Build dependency lock: `c92b3fb240739cfbd8617e9e14407288c7e60c62fb41c433684c9e5f44541d74`
- Frozen input pin map: `b078c2b3b0f3582461fb9a250795dab1ecaa69b4920f80187daa946337e377b3`

The build recorded at `qa/final-locked-build/` produced this PDF under the verified lock; its packaged-match field is false because the then-packaged PDF was the earlier draft. The owner subsequently promoted these exact locked output bytes to the release root. Separately reviewed final locked rebuild and relocation evidence bind the promoted PDF. The author-side all-page model review is at `qa/AUTHOR_VISUAL_REVIEW.md`; independent acceptance has its own dossiers.

## Independent acceptance

- The unchanged scientific audit accepts the conventional mathematics and scope without a required correction; its recorded assertion counts are 840 source-bound, 832 archived-source, and 737 for the separate native certificate/DAG checker
- `manuscript-review/REVIEW.md` accepts the exact final source and 18-page PDF after an independent 150-dpi render, direct inspection of every page, and 283 finite binding/transcription assertions
- `qa/independent-tools/REVIEW.md` accepts the exact report-bound helper sources after 103 independent diagnostics, a fresh execution of the 39 owned tests, exact locked PDF rebuilding, independent reconstruction of all 274 system dependencies, deterministic diagnostic archives, and metadata-preserving relocation with identical PDF and all 18 PNGs
- `qa/promoted-pdf-rebuild/` records a final owner-side locked build after review integration with required equality to the packaged PDF

These checks overlap and do not add up to independent mathematical theorem counts. Review-dossier diagnostic archive hashes are not the final publication archive pin. The complete release receives a separate final manifest and external integrity commitment after all intended evidence is assembled.
