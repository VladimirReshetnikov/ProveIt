# Cache-result modus ponens: a new 252-state research variant

**Outcome: 252 working states. This archive does not contain a verified machine below 252 states.** It contains a different complete proof-search interface, an exact blank-tape machine implementing it, an ordinary mathematical proof of the ZFC equivalence, and reproducible finite certificates. It also records the unsuccessful minimization experiments and their precise limits.

The baseline is ProveIt commit [`43026ff42f0939f09b9e95495248cfadcad38e38`](https://github.com/VladimirReshetnikov/ProveIt/tree/43026ff42f0939f09b9e95495248cfadcad38e38), especially `Computability/BusyBeaver/Research/ZFC/candidate-permutation252`. All state counts exclude the separate halt label.

## Read first

- `report/cachemp252_research.pdf` — the complete mathematical report and experiment ledger.
- `report/cachemp252_research.tex`, `cache_result_proof.tex`, and `search_results.tex` — editable LaTeX sources.
- `machine/cache_mp252.tm` — the complete canonical binary table, 504 transition rows.
- `verify.py` — the four positive certificate checks, using only Python's standard library.
- `experiments/REPRODUCE.md` — optional search reruns, dependencies, and bounded-search limitations.
- `PROVENANCE.json` and `ATTRIBUTION.md` — exact source identities and authorship/license boundaries.

## The change that matters

Write a command-boundary state as `(T, S, d, H)`: current formula, theorem-stack code, additive numerical parameter, and cached formula. Let `P` be the original unshifted Cantor pairing and `I(a,b) = 4 P(a,b)`. For `b = d + x`, a successful MP checks `I(T,b) = H`.

| Successful MP result | Original | New |
|---|---:|---:|
| Current formula | `b` | `0` |
| Theorem stack | `P(0,S)` | `S` |
| Numerical parameter | `b` | `0` |
| Cached formula | `0` | `b` |

Only the second edge of source DAG node 130 changes: its target becomes existing helper 197 instead of helper 166. The other uses of helper 166 remain unchanged. Before the physical register permutation, the entire binary change is the old-label row `(204,1): (1,R,113) -> (1,R,151)`.

The new successful MP no longer has to copy the conclusion back into `T`, restore the disposable parameter, or push a dummy truth entry. A new proof block restores the original *block* contract. Soundness and completeness retain all twelve constructors of the original numerical calculus, including the eight logical rows, native equality, the freshness gates, and the complete CP/GIC bundle. The formula code `0` is a theorem and the stack code `0` is an infinite zero stream; the proof explicitly includes these cases.

The report proves, in ordinary mathematics with the retained proof-specific calculus calibration,

\[
\mathrm{ZFC}\vdash\neg\mathrm{Halt}_{\mathrm{blank}}(M)
\;\longleftrightarrow\;\mathrm{Con}(\mathrm{ZFC}).
\]

This is not a new Lean or Coq kernel certification, nor a serialized derivation in a fixed ZFC proof-code format. No local Lean or Coq build of the modified machine was run. The standard set-coded reconstruction in ZFC and the stronger PA-internalization project are distinct matters. The imported `.lean` files are unchanged reference extracts, not a standalone formal project or a newly verified dependency closure.

## Exact machine specification

The model is one two-way infinite tape, symbols `0` and `1`, blank symbol `0`, and only left/right moves. Initially the state and head coordinate are both `0`, and the entire tape is zero. The table format is:

```text
#! start 0
current_state read_symbol write_symbol direction next_state
```

The second line above describes the five columns; it is not a table row. The actual file contains only its start header and numeric transition rows. Entering the halt label terminates after performing that row's write and move.

| Item | Value |
|---|---|
| Working states | `0..251` |
| Halt label | `252` |
| Actual start | canonical `0`, old `0` |
| Unique canonical halting row | `(75,1) -> (1,R,252)` |
| Canonical dispatcher | `94`, old `96` |
| Transition rows | `504` |
| Old working labels | `{0..253} \ {5,8}` |
| Logical-to-physical slots `(N,T,W,A,D,H,X,Y,L)` | `(4,5,0,8,6,2,1,7,3)` |
| Changed rows relative to pinned old-label table | `14` |
| Preserved supporting register-box rows | all `55` |

Canonical table SHA-256:

```text
8fe5abce4a8cdb2d95de82c25c4d218830e4adf93dbde737a9ecc9333251ff39
```

Old-label table SHA-256:

```text
9ba862d15e0f689525281e1c96083acf7f389157bd56d6a2676f223106dc07a9
```

These hashes include the exact text bytes and start header. The old-label representation, renumbering map, source patch, row differences, and complete bootstrap certificate are included. The new actual start is old **0**; the baseline's old **64** must not be substituted for it.

## Positive evidence and proof dependencies

| Layer | Included result |
|---|---|
| Source command | One-edge patch; exact destructive-transfer proof; 588 literal original/changed MP cases and 128 helper cases |
| Proof blocks | Ordinary derivation induction and cofinal completeness; 3,600 finite contract calculations and 1,056 exact-repair cases |
| Source-to-decoder correspondence | Fresh 2,998-entry segment bisimulation, all 5,995 branches checked; source well-formedness and exact expanded-tree comparison |
| Literal binary simulation | All 8,361 guarded affine cases pass; arbitrary natural register values and gaps `40+n`, not a sample-size bound |
| Arithmetic operations | The four retained unbounded register-box proofs; all 55 supporting rows literally unchanged |
| Blank startup | 707,393 transitions, independently replayed with two different tape representations |
| Entire startup tape | Exact support equality, including 295 zero spare blocks and both blank exterior tails |
| Standard ZFC | Ordinary proof-specific set-coded calculus/refutation comparison and the constructible-model consistency comparison |

At the startup endpoint, the head is `-13`, the marker is `-14`, the register header is `27`, the path is empty, and the gap is `40`. The nine logical primary values are `(6,0,0,0,2,0,0,0,0)`. This is a safe state because the current formula, theorem stack, and cache are all zero; the candidate number and additive parameter need not be zero. The complete support has 314 one cells, ending at coordinate `643`.

The finite checkers are reviewable programs, not themselves newly verified proof assistants. The unbounded result uses the report's invariants, induction, exact case interpretation, and attributed general lemmas. The report makes each link explicit rather than inferring a consistency statement from a long simulation.

## Reproduce the positive certificates

Python 3.12 was used. No third-party Python package or network access is needed.

```sh
python3 -B verify.py
```

Expected stage output:

```text
bootstrap: PASS
source_commands: PASS
source_binding: PASS
affine: PASS
```

The final JSON identifies the exact table, 252 working states, 707,393 blank steps, 2 independent replays, 2,998 source-binding entries, and 8,361 affine cases. Assertions must remain enabled; do not use Python `-O`. The wrapper checks `SHA256SUMS` and writes intermediate outputs to a temporary directory, leaving the archived records intact. An optional `--output /path/outside/this/archive/result.json` stores the aggregate result. `results/release_verification.json` records the initial successful check before the final manifest was generated; its null manifest count is intentional. The delivered archive was also extracted and checked independently before release.

To rebuild the PDF, use a LaTeX installation containing the packages listed in the main source:

```sh
make -C report
```

This runs `pdflatex` twice. Rebuilding or editing files can change their byte hashes, so the release manifest applies to the delivered files, not to a locally edited or rebuilt variant.

## Search results are restricted to their recorded families

No candidate below 252 survived the required checks. The completed families include mixed-row arithmetic-box merges in both layouts, several decoder-rotation families, phase-aware folds, vector-effect folds, and 132,048 one-incoming full-action deletions. A separate two-incoming family is explicitly partial: 583,834 of 1,008,016 planned assignments were not examined. Compiler graph costs, fuel cutoffs, and failed local invariants are not lower bounds on all Turing machines.

One existing gap-19 continuation reaches an intended decoder path of depth 20; the archive gives the exact finite diagnostic. It refutes that candidate's proposed gap-19 simulation interface, without claiming to determine the mutant's eventual halting behavior.

The positive idea is to optimize the contract of a compiled proof block, allowing different temporary result locations. The current compiler/table still costs 252 states. More permissive scratch-register variants need a fairness proof because they can change which candidate codes are visited; they are not certified alternatives.

## Suggested ProveIt placement

Place this directory under:

```text
Computability/BusyBeaver/Research/ZFC/candidate-cachemp252/
```

Keep its status as a research construction with an ordinary proof and finite certificates. The pinned baseline's maintained formal status does not automatically transfer to the new source edge, table, register assignment, or startup. The report identifies the source proof, new source-binding certificate, reindexed instruction cases, and exact bootstrap that a new formal integration must connect.

Prepared on 17 October 2026 with AI assistance. No independent human proof review is claimed. See `ATTRIBUTION.md` for the original machine, calculus, compiler, and verification authors.
