# Polish Presburger Arithmetic

**A positive construction for Glazer's question, an effective Baire-space
model, and exact regularity boundaries.**

Research manuscript prepared for Vladimir Reshetnikov, 3 October 2026.

## Main result

The nonnegative cone of the lexicographically ordered group `R x Z`, with
coordinatewise addition and arithmetic unit `(0,1)`, is a perfect, locally
compact, uncountable Polish model of full Presburger arithmetic when given
the subspace topology from usual `R` and discrete `Z`.

Replacing the divisible coordinate by lexicographically ordered `Q^N`, with
**discrete rational coordinates**, gives an explicit model on Baire space.
Its addition and fixed-integer quotient/remainder operations have executable
Type-2 stream algorithms. The manuscript supplies full proofs, including
model-uniform quantifier elimination, exact monus discontinuity, automatic
continuity and classification of all unital self-embeddings, and algebraic
obstructions to semiring expansions. It includes eleven proposed research
questions and a concrete ProveIt formalization plan.

This gives an affirmative construction for Question 2 as printed in Elliot
Glazer, *A Topological Tennenbaum Theorem*, arXiv:2311.13699v1 (2023), p. 8.
Historical priority has not been established. This is an unrefereed research
draft; the new results are not claimed to be Lean/Rocq kernel-checked.

## Files

- `polish_presburger.tex`: complete, self-contained LaTeX source and bibliography.
- `polish_presburger.pdf`: compiled article.
- `verification.py`: exact finite diagnostics and usable infinite-stream operations.
- `verification_results.json`: the delivered deterministic test run.
- `source_provenance.json`: primary sources and pinned repository file hashes.
- `Makefile`: build, test, and cleanup commands.

No third-party font files or third-party paper copies are included.

## Build

A standard TeX Live or MiKTeX installation with the packages named in the
preamble is sufficient. In particular, the PDF uses the NewTX text/math
packages. Install these through the TeX distribution, not from this archive.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error polish_presburger.tex
```

Alternatively run `pdflatex` three times to settle the contents and references.
The Python program requires Python 3.10+ and the standard library only:

```sh
python3 verification.py --output verification_results.json
```

The recorded run, with seed `20261003`, passed **75,079 assertions**. These
are finite checks, not a proof of the infinite or topological statements.
The manuscript's Appendix A describes their exact scope.

## Stream API example

```python
from verification import Stream, baire_add, baire_quotient, baire_remainder

# Every total sequence of natural numbers is a valid Baire-space input.
u = Stream(lambda i: (3 * i + 2) % 11)
v = Stream(lambda i: (5 * i + 1) % 7)

print(baire_add(u, v).prefix(12))
print(baire_quotient(u, 3).prefix(12))
print(baire_remainder(u, 3).prefix(12))
```

Baire coordinates encode the arithmetic structure; they are not ordinary
base digits. Reading any output coordinate makes finitely many input-oracle
calls. Do not pass a partial oracle, a negative entry, or a noninteger entry.
The API cannot decide totality of an arbitrary caller-supplied oracle.

## Repository scope

The source audit was limited to the relevant Presburger and surreal files
at commit `3ad5f878c26d2d82c092190af2f3edc50d6feb06`. No repository files were
modified, and no repository-wide build was performed. The difference between
standard one-step periodicity and model-uniform residue invariance is a
porting requirement, not a reported bug in the existing integer proof.
