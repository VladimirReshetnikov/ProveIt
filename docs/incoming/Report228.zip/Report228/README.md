# Report 228

**Logarithmic height crossover for iterated Euler transforms**

This archive contains the complete editable mathematical article, exact finite
recurrence and symbolic reproduction, unvalidated decimal comparisons, and the
unchanged complete proofs of Reports 225 and 226 used as analytic foundations.
Nothing in this package is a proof-assistant formalization or a certified
floating-point enclosure. The article states the dependency interfaces and
proves the additional results in full.

## Main results and scope

For A(n,m) in OEIS A290353 and T=pi/2,

    A(n,m) / (2*T^(-n)*m^(n-1)) -> exp[-1/(3*lambda)]
    when m/(n*log n) -> lambda in (0,infinity).

The proof gives quantitative transfer for every fixed logarithmically
shrinking degree-to-height band, a one-sided smooth endpoint germ
`t^(t/3)*h(t)`, every fixed inverse-logarithm correction, and smooth
suppression-ratio height prescriptions. In the article the inverse scale is
`chi_n=log(n)/3-K`, distinct from the rational Fatou coefficients `a_j`.
Kaneiwa's exact leading monomial uses height `m-1`, changing `K` to `K+1`.
Every fixed order means a finite asymptotic truncation. There is no asserted
convergent infinite Taylor series, all-orders expansion in 1/m, effective
onset, discrete ratio monotonicity, least-height threshold, or exact integer
height recovery. Classical parabolic methods and earlier unforced branching
crossover mechanisms are explicitly credited; no worldwide priority is claimed.

## Contents

- `src/report228.tex`: complete article source
- `Report228.pdf`: compiled article in the built ZIP
- `code/`: exact recurrence, rational coefficient generator, symbolic inverse
  checks, and unvalidated numerical diagnostics
- `results/reproduction.json`: exact counts and finite algebra, with numerical
  scope labels for constants, floors, ratios, and approximations
- `results/crossover_table.tex`: generated nine-row comparison table
- `supporting/`: unchanged Reports 225 and 226, each as TeX and PDF
- `sources/SOURCE_LEDGER.md`: references, attribution, exact dependency hashes,
  public IBD snapshot provenance, and source-review limitations
- `MANIFEST.sha256`: source file hashes
- `build.py`: deterministic source-preserving builder
- `build_checks.json`: generated receipt in the built ZIP

The IBD source is linked, not redistributed. Its connector representation had
one terminal LF beyond the raw Git blob; the ledger distinguishes those
representations.

## Rebuild in a new external directory

Requirements: CPython 3.11+, mpmath 1.3.0, SymPy 1.14.0, and TeX Live with
pdfTeX, the LaTeX format sources, Latin Modern, AMS packages, microtype,
geometry, hyperref, bookmark, enumitem, mathtools, and booktabs. Poppler is
needed only for visual inspection. The distributed build used CPython 3.12.14.
Install Python dependencies in your chosen isolated environment if necessary:

```sh
python -m pip install -r code/requirements.txt
```

From the directory containing `build.py`, choose a path that does not exist
and is outside this package:

```sh
PYTHONINTMAXSTRDIGITS=640 python -B build.py --out ../report228-normal
PYTHONINTMAXSTRDIGITS=640 python -B -O build.py --out ../report228-optimized
cmp ../report228-normal/Report228.zip ../report228-optimized/Report228.zip
```

The build verifies the manifest and exact results, runs all explicit checks,
creates a private LaTeX format, compiles three passes without shell escape,
and writes the PDF, ZIP, logs, and receipt under the requested new output
folder. It rejects source overlap, existing output directories, and symlink
ancestors. No distributed source is rewritten. A mismatch in numerical
library output is a build failure, not silently adopted as a new reference.

The finite recurrence caps are degree <=640 and height <=640. The comparisons
use n=20,40,80, and maximum height 525. Formal coordinate computation is capped
at order 12 and endpoint generation at order 7; the analytic theorem is not
restricted to those tested orders. Arithmetic checks use explicit exceptions,
so optimization does not disable them. Chunked decimal serialization works
under CPython's minimum configurable digit limit 640 and never changes the
global limit. Numerical precision is local rather than process-wide.

To reproduce only the finite scientific results into an external directory:

```sh
PYTHONINTMAXSTRDIGITS=640 python -B code/reproduce.py --check --output-dir ../report228-data
```

The exact n=20 counts are independently checked by finite products, and every
entry of a smaller degree 12 by height 12 table is also checked. The nine table
heights use 80-digit Decimal floors cross-checked at 160 digits; these floor
computations and all normalized decimal values are not interval certificates.

## Actual ZIP reproduction

Extract a built ZIP into a fresh directory, then run its own builder. For
example, from the parent of the output directories above:

```sh
mkdir report228-extracted
python -m zipfile -e report228-normal/Report228.zip report228-extracted
PYTHONINTMAXSTRDIGITS=640 python -B report228-extracted/Report228/build.py --out report228-rebuilt
cmp report228-normal/Report228.zip report228-rebuilt/Report228.zip
```

Repeat with `python -B -O` and another fresh output directory if desired.
Sorted ZIP members use fixed timestamps and permissions, and PDF dates and
random trailer IDs are suppressed. Full ZIP and member identity is expected
on the same toolchain; arbitrary TeX, font, or library versions need not
produce identical bytes. The distributed PDF is rendered and all pages
visually checked separately from the deterministic build.
