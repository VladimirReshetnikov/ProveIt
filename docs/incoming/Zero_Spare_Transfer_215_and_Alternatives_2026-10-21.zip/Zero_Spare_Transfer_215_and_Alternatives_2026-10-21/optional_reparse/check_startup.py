#!/usr/bin/env python3
"""Fresh literal blank run and exact source-prefix check for latest reparse."""
from pathlib import Path
import sys, os
if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'): raise RuntimeError('Assertions must be enabled')
import hashlib
import json
from check_source_variants import guarded_graph

D = Path(__file__).resolve().parent
R = D.parent
tp = D / 'machine.native.tm'
sp = D / 'source.sites.json'
sites = json.loads(sp.read_text())
graph = guarded_graph(sites)
bridge = json.loads((D / 'bridge.json').read_text())['attempts'][0]
registers = bridge['entry_registers'].copy()
ordinal = bridge['entry_ordinal']
for tick in range(bridge['steps']):
    assert bridge['trace'][tick] == [ordinal, registers]
    event = graph[ordinal]
    if event[0] == 'CI':
        registers[event[1]] += 1
        ordinal = event[2]
    elif event[0] == 'CD':
        positive = bool(registers[event[1]])
        if positive:
            registers[event[1]] -= 1
        ordinal = event[3 if positive else 2]
    else:
        assert event[0] == 'CONTROL'
        ordinal = event[1]
assert ordinal == 119 and registers == [0, 6, 0, 0, 1, 1, 10, 1, 0]
table = {}
for line in tp.read_text().splitlines():
    if not line or line.startswith('#'):
        continue
    q, bit, write, direction, target = line.split()
    key = (int(q), int(bit))
    assert key not in table and direction in ('L', 'R')
    table[key] = (int(write), 1 if direction == 'R' else -1, int(target))
assert len(table) == 430 and table[198, 0] == (0, -1, 40)
q, h, tape = 74, 0, set()
for _ in range(73172):
    write, direction, q = table[q, int(h in tape)]
    if write:
        tape.add(h)
    else:
        tape.discard(h)
    h += direction
assert q == 84 and h == -2
physical = [None] * 9
for i, j in enumerate((6, 2, 0, 4, 3, 7, 8, 5, 1)):
    physical[j] = registers[i]
spares = [0, 0, 1] + [0] * 62
pc = sites[ordinal][0]
expected = {h - 1, h + 64} | {h + i for i, bit in enumerate(pc) if bit == '1'}
position = h + 65
for value in physical + spares:
    expected.update(range(position + 1, position + value + 2))
    position += value + 2
assert tape == expected and len(tape) == 107
receipt = {
    'status': 'PASS',
    'table_sha256': hashlib.sha256(tp.read_bytes()).hexdigest(),
    'source_sha256': hashlib.sha256(sp.read_bytes()).hexdigest(),
    'start_state': 74,
    'working_states': 215,
    'blank_steps': 73172,
    'whole_frame_exact': True,
    'head': h,
    'header': h + 64,
    'one_cells': sorted(tape),
    'source_ordinal': ordinal,
    'source_address': pc,
    'logical_registers': registers,
    'spares': spares,
    'source_prefix_steps': bridge['steps'],
    'source_prefix_entry_ordinal': bridge['entry_ordinal'],
    'source_prefix_entry_registers': bridge['entry_registers'],
    'scope': 'Fresh exact source-prefix and whole-frame startup checks; full source effects/CFG equivalence checked by check_source_variants.py. Separate universal runtime proof required.'
}
(D / 'LATEST_REPARSE_STARTUP_BRIDGE_CHECK.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k not in ('one_cells', 'spares')}, indent=2))
