#!/usr/bin/env python3
"""Owned non-mutating portable wrapper for the append-zero reparse component."""
from pathlib import Path
import argparse,gzip,hashlib,json,os,shutil,subprocess,sys,time
R=Path(__file__).resolve().parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'): raise RuntimeError('Assertions must be enabled')
 ap=argparse.ArgumentParser();ap.add_argument('--runtime',action='store_true');ap.add_argument('--work',type=Path,required=True);a=ap.parse_args()
 for name,digest in json.loads((R/'MANIFEST.json').read_text()).items():assert H(R/name)==digest,name
 W=a.work.resolve();W.mkdir(parents=True,exist_ok=False);D=W/'replay-inputs';shutil.copytree(R,D,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));beg=time.monotonic()
 env=dict(os.environ);env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None);env['PYTHONDONTWRITEBYTECODE']='1'
 # The owned checker imports its sibling module. Explicit path insertion is
 # required under -I; no surrounding repository is imported or executed.
 command='import sys,runpy;sys.path.insert(0,sys.argv[1]);runpy.run_path(sys.argv[2],run_name="__main__")'
 subprocess.run([sys.executable,'-I','-B','-c',command,str(D),str(D/'check_startup.py')],check=True,cwd=W,env=env)
 j=lambda p:json.loads(p.read_text())
 assert j(D/'LATEST_REPARSE_STARTUP_BRIDGE_CHECK.json')==j(R/'evidence/LATEST_REPARSE_STARTUP_BRIDGE_CHECK.json')
 equiv=j(D/'SOURCE_VARIANTS_EQUIVALENCE.json');ref=j(R/'evidence/SOURCE_VARIANTS_EQUIVALENCE.json')
 for k in ref:
  if k!='sources':assert equiv[k]==ref[k],k
 assert len(equiv['sources'])==len(ref['sources'])==3
 for x,y in zip(equiv['sources'],ref['sources']):
  assert {k:v for k,v in x.items()if k!='path'}=={k:v for k,v in y.items()if k!='path'}
 out={'status':'FINITE_REPLAY_PASS','working_states':215,'appended_spare_value':0,'source_graph_equivalence':'PASS','blank_steps':73172,'source_bridge_steps':177,'unsafe_tail':171,'safe_heads':8,'conservative_debt':3,'permanent_margin':5}
 if a.runtime:
  subprocess.run([sys.executable,'-I','-B',str(D/'replay_runtime.py')],check=True,cwd=W,env=env)
  raw=(D/'REPLAY_RUNTIME_CASES.json').read_bytes();assert raw==gzip.decompress((R/'evidence/runtime_cases.json.gz').read_bytes())
  actual=j(D/'REPLAY_RUNTIME.json');old=j(R/'evidence/LATEST_REPARSE_APPEND0_RUNTIME.json')
  for k,v in old.items():
   if k!='seconds':assert json.loads(json.dumps(actual[k]))==v,k
  assert j(D/'REPLAY_RUNTIME_ROW_COVERAGE.json')==j(R/'evidence/LATEST_REPARSE_APPEND0_RUNTIME_ROW_COVERAGE.json')
  assert actual['status']=='ALL_NATURAL_RUNTIME_PASS'and actual['cases']==6209 and actual['symbolic_rules']==1665757 and actual['row_coverage']==430
  out.update(status='FULL_REPLAY_PASS',runtime=actual)
 out['seconds']=time.monotonic()-beg;(W/'replay.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='runtime'},indent=2))
if __name__=='__main__':main()
