# Optional latest-reparse 215-state construction

This is a third zero-spare transfer construction, with a new source reparse and helper26 protected. It is not a214-state result.

The source has4,775 leaves and6,209 guarded primitive cases. The full owned runtime replay passed1,665,757 symbolic rules and all430 table rows, with minimum duration7. The evidence pins the table/source/kernel hashes and the entire case census.

Run `python3 -I -B verify.py --work /absolute/new/output` for non-mutating fresh source-CFG equivalence, exact73,172-step blank frame, and177-source-primitive bridge. Add `--runtime` to rederive all6,209 arbitrary-natural cases (about2minutes), compare the full census and every runtime/row-coverage field, and obtain FULL_REPLAY_PASS. Assertions must remain enabled. The wrapper copies its inert inputs and owned checker code into the fresh output directory; no packet input is overwritten. The lower-level drivers are libraries/working-copy entrypoints. The primary component supplies the shared written compiler, AX contract, protected-credit proof and inherited licenses; those mathematical premises are distinct from this exact runtime replay.

The source graph/effects equal the calibrated primary at every ordinal. The exact bridge is therefore the same AX entry atordinal25 with registers[0,0,0,0,1,1,0,0,0], reachingordinal119 with[0,6,0,0,1,1,10,1,0]. Completing that AX supplies eight safe heads over opaque suffix171. The primary calibration theorem's debt3/margin5 argument applies unchanged; cache1 and Q_1(1)=18 are not presumed theorems. See the main release's zero-spare startup proof.

This packet is executable mathematical evidence, not a proof-assistant certification.

Preparation: a fresh isolated complete runtime replay also passed, with exact census and aggregate equality (evidence/isolated_full_replay.json). Subsequent entry-guard hardening changes no mathematical check. The final release-wide replay tests the final bytes again. Only the append-zero table pinned here is calibrated; no append-one reparse claim is made.
