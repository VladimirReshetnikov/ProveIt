#!/usr/bin/env python3
"""Owned structural source comparison; source JSON files are inert data."""
from pathlib import Path
import sys, os
if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'): raise RuntimeError('Assertions must be enabled')
import hashlib
import json

D = Path(__file__).resolve().parent
R = D.parent
paths = [D / 'primary.sites.json',
         D / 'association1.sites.json',
         D / 'source.sites.json']
sources = [json.loads(p.read_text()) for p in paths]

def guarded_graph(sites):
    leaves = {pc: i for i, (pc, op, reg) in enumerate(sites)}
    prefixes = {pc[:k] for pc in leaves for k in range(len(pc) + 1)}
    def first(pc):
        while pc not in prefixes:
            assert pc.endswith('0')
            pc = pc[:-1]
        while pc not in leaves:
            pc += '0'
        return leaves[pc]
    def after(pc):
        pc = pc.rstrip('1')
        return pc[:-1] + '1' if pc else ''
    def ancestor(pc, bit, count):
        for _ in range(count):
            j = pc.rfind(bit)
            if j < 0:
                return ''
            pc = pc[:j]
        return pc
    graph = []
    for pc, op, reg in sites:
        if op == 'CI':
            graph.append([op, reg, first(after(pc))])
        elif op == 'CD':
            graph.append([op, reg, first(after(ancestor(pc, '0', 1))), first(after(pc))])
        elif op == 'CB':
            graph.append(['CONTROL', first(after(ancestor(pc, '0', reg)))])
        elif op == 'CC':
            graph.append(['CONTROL', first(ancestor(pc, '1', reg))])
        else:
            assert op == 'CH', (pc, op, reg)
            graph.append(['HALT'])
    return graph

graphs = [guarded_graph(sites) for sites in sources]
assert graphs[0] == graphs[1] == graphs[2]
def subtree(sites, prefix):
    return [(pc[len(prefix):], op, reg) for pc, op, reg in sites if pc.startswith(prefix)]

# The two final command subtrees are ((DROP,NIP),NIP) and (DROP,(NIP,NIP)).
assert sources[0][:4697] == sources[1][:4697]
for a, b in [('11100', '1110'), ('11101', '11110'), ('1111', '11111')]:
    assert subtree(sources[0], a) == subtree(sources[1], b)
receipt = {
    'status': 'PASS',
    'guarded_ordinal_graph_and_arithmetic_effects_identical': True,
    'sites': len(sources[0]),
    'variant1_relation': 'Only reassociates final S command from ((DROP,NIP),NIP) to (DROP,(NIP,NIP)); all three literal macro subtrees preserved.',
    'variant1_first_changed_ordinal': 4697,
    'sources': [{'path': str(p.relative_to(R)),
                 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                 'changed_addresses_from_primary': sum(a[0] != b[0] for a, b in zip(sources[0], sites))}
                for p, sites in zip(paths, sources)],
    'scope': 'Exact source control/effect equivalence only; separate binary runtime and blank-frame proofs required.'
}
(D / 'SOURCE_VARIANTS_EQUIVALENCE.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
