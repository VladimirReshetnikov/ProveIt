#!/usr/bin/env python3
"""Owned universal runtime replay; external tables/source are inert data only."""
from pathlib import Path
import hashlib,json,sys,time,argparse
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(D/'runtime'));import symbolic_runtime as S
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--table',type=Path,default=D/'machine.native.tm');ap.add_argument('--source',type=Path,default=D/'source.sites.json');ap.add_argument('--stem',default='REPLAY_RUNTIME');args=ap.parse_args()
pt,ps=args.table,args.source;N=S.r.table(pt);sites=json.loads(ps.read_text())
M={int(a):int(b)for a,b in json.loads((D/'native_to_legacy.json').read_text()).items()}
assert len(set(M.values()))==len(M)and M[84]==96 and M[254]==254
# Extend injectively for new decoder labels, preserving all historical mappings.
for q in sorted({q for q,b in N}|{n for w,d,n in N.values()}):
 if q not in M:M[q]=max(M.values())+1
T={(M[q],b):(w,d,M[n])for(q,b),(w,d,n)in N.items()}
lemmas,blocks=S.prove_blocks(T);started=time.monotonic();cases=[];rows=set();failure=None
for i,site in enumerate(sites):
 for pos in((False,True)if site[1]=='CD'else(False,)):
  try:c=S.case(T,lemmas,site,pos,append=0)
  except(AssertionError,KeyError)as e:failure=dict(index=i,site=site,positive=pos,error=repr(e));break
  rows.update(c.pop('rows'));c.pop('trace');cases.append(dict(index=i,positive=pos,**c))
 if failure:break
 if i%500==0:print(args.stem,'proved',len(cases),'seconds',round(time.monotonic()-started,2),flush=True)

for block in blocks:
 for event in block['trace']:
  if event[0]!='list':rows.add(event[1][:2])
inv={v:q for q,v in M.items()}
native_rows=sorted((inv[q],b)for q,b in rows)
coverage=dict(used_rows=native_rows,unused_rows=sorted(set(N)-set(native_rows)),all_table_rows=len(N),used_count=len(native_rows),fresh_list_schema_rows_included=True)
(D/(args.stem+'_ROW_COVERAGE.json')).write_text(json.dumps(coverage,indent=2)+'\n')
out=D/(args.stem+'_CASES.json');out.write_text(json.dumps(cases,indent=2)+'\n')
expected=sum(2 if x[1]=='CD'else 1 for x in sites)
receipt=dict(status='ALL_NATURAL_RUNTIME_PASS'if failure is None and len(cases)==expected else'INCOMPLETE',append_spare_value=0,table_sha256=H(pt),source_sha256=H(ps),working_states=len(N)//2,table_rows=len(N),source_sites=len(sites),cases=len(cases),expected_cases=expected,symbolic_rules=sum(c['symbolic_steps']for c in cases),row_coverage=len(rows),minimum_duration=min(c['duration'][0]for c in cases),failure=failure,cases_sha256=H(out),fresh_block_certificates=blocks,kernel_sha256=H(D/'runtime/symbolic_runtime.py'),helper_sha256=H(D/'runtime/independent_runtime.py'),seconds=time.monotonic()-started,runtime_adapter='S.case(...,append=0) changes only the exact expected CI appended block to B(0)=01; every transition proof is rederived on this table.',scope='All independent natural register values at each guard, arbitrary extra gap and arbitrary nonempty finite spare lists; complete tape and zero exteriors. Does not separately calibrate source to Con(ZFC).')
(D/(args.stem+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items()if k!='fresh_block_certificates'},indent=2),flush=True)
