#!/usr/bin/env python3
"""Fresh all-natural MP0 case census using the unchanged owned proof kernel."""
from pathlib import Path
import argparse,gzip,hashlib,json,os,sys,time
R=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(R/'checks'))
import source_utils as B
import symbolic_runtime as S
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def mapped(T):
 m={int(a):int(b)for a,b in json.loads((R/'inputs/NATIVE_TO_LEGACY.json').read_text()).items()}
 assert len(set(m.values()))==len(m)
 assert m[84]==96 and m[254]==254
 for q in sorted({q for q,b in T}|{z for w,d,z in T.values()}):
  if q not in m:m[q]=max(m.values())+1
 return {(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()},m

def generate():
 if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'):
  raise RuntimeError('Verification requires enabled assertions; disable -O, -OO and PYTHONOPTIMIZE.')
 sites=json.loads((R/'source/mp0_201.sites.json').read_text())
 native=B.parse_table(R/'machine/mp0_216.native.tm');T,m=mapped(native)
 lemmas,blocks=S.prove_blocks(T);cases=[];rows=set();start=time.monotonic()
 for i,site in enumerate(sites):
  for pos in ((False,True)if site[1]=='CD'else(False,)):
   c=S.case(T,lemmas,site,pos);rows.update(c.pop('rows'));c.pop('trace');cases.append(dict(index=i,positive=pos,**c))
  if i%1000==0:print('Runtime:',len(cases),'cases',flush=True)
 data=(json.dumps(cases,indent=2)+'\n').encode()
 inv={b:a for a,b in m.items()};native_rows=sorted((inv[q],b)for q,b in rows)
 assert len(cases)==6184 and rows==set(T) and len(rows)==432
 receipt={'status':'ALL_NATURAL_RUNTIME_PASS','cases':len(cases),'symbolic_rules':sum(c['symbolic_steps']for c in cases),'row_coverage':len(rows),'minimum_duration':min(c['duration'][0]for c in cases),'cases_sha256':hashlib.sha256(data).hexdigest(),'table_sha256':H(R/'machine/mp0_216.native.tm'),'source_sha256':H(R/'source/mp0_201.sites.json'),'kernel_sha256':H(R/'checks/symbolic_runtime.py'),'helper_sha256':H(R/'checks/independent_runtime.py'),'fresh_block_certificates':blocks,'covered_native_rows':native_rows,'scope':'All independent natural primary values at every source guard, arbitrary natural additional gap, arbitrary first spare value and arbitrary finite remaining spare list, whole tape including zero exterior. CI appends one spare of value 1. Executable mathematical evidence, not a proof-assistant endpoint. Source semantics and blank calibration are separate premises.'}
 print('Proved',len(cases),'cases in',round(time.monotonic()-start,2),'seconds',flush=True)
 return data,json.loads(json.dumps(receipt))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 data,receipt=generate();(a.output/'runtime_cases.json.gz').write_bytes(gzip.compress(data,compresslevel=9,mtime=0));(a.output/'runtime.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt['cases_sha256'],receipt['symbolic_rules'],receipt['row_coverage'],flush=True)
