# Exact MP0 source surgery and the proof boundary

This component is MP0-216. The separate append-zero transfer experiment is not
this source, table, or runtime policy. Here every physical CI still appends a
spare of value one. The change is instead at the command level: successful MP
no longer pushes a dummy zero onto the numerical logical stack.

## Exact syntactic identification

The inert baseline is the previously delivered 201-node transfer source,
4,775 primitive occurrences, SHA-256
05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922.
At binary tree path 11010111 it contains (push, copy), where push has nineteen
primitive leaves and copy seven. Replacing that pair by its old right child
produces exactly the 201-node, 4,756-occurrence MP0 source, SHA-256
2ec05ced11603aa1cac306d5c30460c446bf8b7480e22216929d7239a12970bb.
The deleted interval is [4670,4689) in baseline primitive ordinals. The prefix
through ordinal 4669 is byte-for-byte unchanged.

The replay does more than compare these hashes. It rebuilds the tree surgery,
checks full binary-tree structure, independently derives the structured CFG
with a recursive break/continue environment, and compares it with a second
prefix-derived CFG. It preserves every surviving primitive and checks every
edge under the contraction, redirecting only entry to the omitted block to
its old exit. Every exterior entry to that block is checked to enter at its
first primitive, and every exit is checked to use its end. No internal branch
or nonlocal control target is silently changed. The exact deleted local CFG
is in checks/source_recipe.json.

## The deleted nineteen-leaf arithmetic block

Write T, W, X, Y for registers 1, 2, 6, 7. Its local CFG is numbered 0 through
18 in the recipe, with EXIT at 19. All other registers are untouched. Its
usual precondition is X=Y=0, and its exact arithmetic contract is

    (T=t, W=w, X=0, Y=0) -> (T=0, W=P(t,w), X=0, Y=0),
    P(t,w)=(t+w)(t+w+1)/2+w.

This follows by ordinary loop induction:

1. Nodes 0-2 transfer all t units from T to X. Nodes 3-5 transfer all w units
   from W to T. Nodes 6-9 then transfer T to X while also incrementing Y.
   At the first visit to node 10, T=W=0, X=t+w and Y=w.
2. At node 10, if X=n>0, decrement X once and increment Y at node 11.
   Nodes 12-14 transfer the remaining n-1 units of X into T. Node 15 returns
   to node 6, and nodes 6-9 transfer those units back into X while adding
   n-1 to Y. Thus one whole iteration maps (X=n,Y=y) to
   (X=n-1,Y=y+n), with T=W=0 again at node 10. Natural-number induction gives
   X=0 and Y=w+(t+w)(t+w+1)/2. The zero case exits immediately.
3. Nodes 16-18 transfer Y into W, leaving T=X=Y=0.

Every loop decreases its natural counter, so the block terminates for all
natural inputs satisfying its scratch-register precondition. This is a
written mathematical induction, not a claim that finitely many tests prove
it.

The inherited exact MP source/macro contract places this block only on MP's
successful branch, with T=0 and clean X,Y. Its old effect is therefore
W=P(0,W), precisely a zero push. The retained seven-leaf block copies the
selected counter value D into T while preserving D via scratch X. Removing
only the pair block yields the displayed MP0 equation in mp0_compiler.md:
the successful branch changes the top to y and leaves W unchanged. The
failure branch and all other commands retain their inherited contracts.
The inherited source/macro calibration, including these branch-entry facts,
is identified in provenance/inherited_source_calibration.tex and
provenance/baseline_compiler_review.md. It is not inferred from the finite
blank run.

## Physical primitive binding

For every one of the 6,184 guarded primitive cases, verify.py separately
resolves the physical binary-prefix successor used by symbolic_runtime.py
to the intended structured CFG edge. It verifies native-to-legacy label
mapping, exact table rows, the full canonical state bijection, and the
native dispatch frame. The optional runtime replay rederives all four
finite-list one-block schemas on the actual MP0 table and proves each
primitive case for independent natural register values, arbitrary extra
gap, and arbitrary nonempty finite spare lists, including the zero exterior.
Its case census, aggregate digest and all-row coverage are distinct from
source compilation and blank calibration.

## From blank startup to command calibration

The three literal startup replays agree after exactly 68,442 steps at native
state 84, head -2, source ordinal 55, logical registers
(1,11,2,0,0,0,0,0,0), 59 spare registers of value one, and 150 one-cells.
All three compare the entire nonzero tape, not a cropped window. An exact
174-primitive abstract trace starts at ordinal 25 and registers
(1,0,4,0,0,0,0,0,0) and reaches this same partial AX frame.
The initial AX code is unchanged by the MP surgery. Its inherited
all-natural macro contract completes the AX and supplies ten theorem heads
above the fixed arbitrary tail 4. The copied protected-credit induction
needs two heads at cutoff 1 and ignores all old successful-MP zero pushes,
so it applies unchanged and leaves margin eight for MP0. Physical spare
registers are not these logical protected stack heads.

## What is and is not established

The new MP0 compiler induction in mp0_compiler.md explicitly reserves a zero
below the MP premises. It retains soundness, completeness, the original full
gated bundle and generalization. Together with the identified inherited
numerical-calculus and arithmetic-macro calibration, exact source binding,
all-natural primitive runtime and blank bridge, these are ordinary
mathematical evidence for the MP0-216 blank-start consistency-equivalence
claim. They do not produce a new proof-assistant endpoint, an unconditional
nonhalting proof, a 215-state improvement, or a state lower bound.
