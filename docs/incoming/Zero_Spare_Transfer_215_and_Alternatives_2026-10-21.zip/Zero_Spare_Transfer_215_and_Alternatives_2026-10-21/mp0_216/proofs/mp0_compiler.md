# Complete transfer-pop compiler without the successful-MP zero push

Date: 2026-10-21. This is a new command-system variant, not a resubmission of the delivered transfer-pop machine. Source allocation, complete runtime, and actual blank startup remain separate obligations.

## Changed interface

Retain the delivered composite transfer command S=oldDROP;oldNIP;oldNIP, its exact AX command, the unchanged numerical calculus, and fields S=[0], MP(x)=[1,x], AX(c;x,y)=[c+2,y,x]. Replace MP by MP0, which does not push a dummy zero on success:

    y=d+x;
    MP0(x)(t,w,d,h)=(y,w,y,0) if I(t,y)=h,
                       (0,w,y,0) otherwise.

The stack is now unchanged in both branches. All parameters and stacks range over the naturals. I(0,0)=0 remains an intentional numerical alias.

## Soundness

The safe invariant is unchanged: top, cache, and every explicitly accessible stack head are native theorems. A successful MP0 applies exact numerical MP to theorem top t and theorem cache I(t,y); a failure supplies theorem 0. Neither branch changes the stack. S and AX are unchanged and already sound, including S's extra top-falsity guard. Therefore every halt from a safe or properly protected seed implies a native refutation.

## Auxiliary macros survive

In every old compiler word below, substitute MP0 for MP.

- D=AX(0;0,0).
- H=D;S^11 either halts or maps (t,[x;w],d,h) to (t,w,0,x). Its proof uses no MP.
- PUSH=D;S^9;MP0(0) maps every (t,w,d,h) exactly to (0,[t;w],0,0), without halting. After nine shifts the top is the dominated row, the cache is Q_d h, and only saved t remains over w. The final target is 0, so either MP0 branch gives top/cache/counter zero and leaves that stack unchanged. The old tag-mismatch proof also establishes failure, but is no longer necessary.
- DISCARD=MP0(1);AX(1;0,0);S^10;MP0(0) still maps every (t,w,0,0) exactly to (0,w,0,0), without halting. Its first MP is forced to fail by I(t,1)>0. The final MP0 again leaves the stack unchanged and gives top zero.
- J(u) can retain the former definition: empty if u=0, MP0(u) if u>0. It still maps (0,w,0,0) to (0,w,u,0). Alternatively MP0(u) works for every u, including zero: the successful zero-alias branch no longer pushes an unwanted zero. Keeping J(0) empty preserves the existing compiler words.

Thus truth, every retained axiom row, the dominated row, the full original gated bundle, and GEN retain the previously proved strong blocks. The exact original bundle is unchanged. In particular, GEN with X=1 and index 0 remains valid or halts early, and all protected underlying-stack arguments still hold.

## The only compiler repair: explicitly reserve a zero below MP premises

For each native theorem X, the required strong contract remains

    B_X(t,w,0,0) halts or returns (X,w,0,0)

for arbitrary natural incoming t,w.

Given strong blocks for A and M=I(A,B), define

    B_B = DISCARD; PUSH;
          B_M; PUSH; B_A; PUSH; S; S;
          MP0(B); AX(B;0,0); S^11.

Ignoring permitted earlier halts, the states are:

1. DISCARD;PUSH gives (0,[0;w],0,0). This explicit zero replaces the old successful-MP side effect.
2. B_M;PUSH gives (0,[M,0;w],0,0).
3. B_A;PUSH gives (0,[A,M,0;w],0,0).
4. The two S commands give (A,[0;w],0,M), unless A=1 has already caused a sound early halt.
5. MP0(B) succeeds by I(A,B)=M and gives (B,[0;w],B,0).
6. This is exactly the post-MP tuple used by the delivered compiler. AX(B;0,0) gates to zero, saves B as its tenth generated head, and resets counter/cache. Ten S commands give (Q_B 0,[0;w],0,B). The eleventh halts if B=1; otherwise it returns (B,w,0,0).

This verifies the strong contract. The inserted zero is a theorem, and its creation uses only already established structural macros, not a new logical inference or atom substitution.

## Zero aliases and arbitrary stacks

For A=B=0, M=I(0,0)=0. Step5 succeeds intentionally but inserts no new head. The explicit zero from step1 remains and is removed in step6. No double zero is assumed or accidentally left behind.

When w=0, the explicit saved zero may have the same numerical encoding as the empty tail because P(0,0)=0. The exact identity unpair(P(x,v))=(x,v) still justifies each specified push and pop. The invariant tracks an explicit finite wrapper list over a fixed suffix, not an injectively encoded length.

All calls to B_M and B_A use their universal arbitrary-stack contract, so the extra protected zero does not constrain either premise. Major-first compilation is well-founded on finite proof trees or finite DAGs expanded into trees. Induction therefore constructs B_X for every native theorem.

## Enumeration, refutation, and startup credit

The refutation suffix B_1;H is still successful from every (t,w,0,0). Packing it after AX(0;1,Y) gives the same cofinal candidate numbers

    N_Y=P(2,P(Y,P(1,R))),  R=tail(B_1;H).

The positive proof-list residual decreases strictly after every command, exactly as before. Hence completeness holds above every finite candidate cutoff.

The protected-credit theorem also transfers without modification: it already assigned conservative weights S=-1, MP=0, AX=10 and deliberately ignored successful-MP zero pushes. For MP0 these weights are exact at command boundaries. In particular, a proved root with next candidate1, zero proof pointer, theorem top/cache, and ten theorem heads over an arbitrary tail still has a permanent conservative margin of eight heads.

This last statement does not assert that any newly allocated table reaches that root. Its own literal blank initialization and all-natural physical runtime must be checked independently.

## Conclusion

MP's dummy-zero push is not necessary for command-level soundness or completeness. The new three-command system has a full all-natural refutation compiler and the same protected-tail scheduler theorem, with one local and explicit change to each MP proof block. It is ready for source pricing and physical verification, but no state count or completed binary construction is asserted by this proof alone.
