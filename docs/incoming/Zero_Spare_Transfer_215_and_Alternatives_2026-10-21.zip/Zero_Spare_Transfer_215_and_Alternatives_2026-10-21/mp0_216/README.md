# MP0-216 reproducibility component

This is a compact standalone component for the no-successful-MP-zero-push
alternative. It remains labeled MP0-216 regardless of other experiments:
201 source DAG nodes, 4,756 primitive occurrences, 6,184 guards, and 216
working states plus a separate halt label. It is not a 215-state result.
The old transfer215 files are inert baseline inputs, not a newly promoted
candidate. This component does not determine the parent report's outcome.

## Replay

Python 3, standard library only, assertions enabled. No network, installation,
received-code execution, or external repository is required.

    python3 -B verify.py --runtime --work /absolute/path/to/new/output

The output directory must not already exist. Omit --runtime for the finite
checks. The full run takes about two minutes on the preparation machine;
speed varies. Successful full replay writes FULL_REPLAY_PASS to replay.json.
The default manifest check authenticates exact sizes and SHA-256 hashes of
all shipped inputs, checker code, proofs and evidence.

The replay rebuilds the source from a single explicit subtree surgery and
the table from one redirected row plus a new two-row selector. It checks
independent source CFG derivations, contraction of every surviving edge,
6,184 physical/source successor bindings, all graph-reachable states, and
the canonical state relabeling. It independently executes sparse-native,
dense-native and sparse-canonical blank startup for all 68,442 transitions,
then verifies the exact 174-primitive source AX prefix.

The optional runtime step uses the unchanged owned symbolic kernel. It
rederives four one-block schemas, then checks all 6,184 arbitrary-natural
primitive cases with 1,607,116 symbolic rules and all 432 literal rows used.
The complete per-case census is included as a deterministic gzip file; its
uncompressed SHA-256 is
41d7d9027835478fb9b6cd9e00179d96e7a5cdc0ff4316359be082ba1cfedc82.
CI appends one spare of value 1. This is not the separate append-zero policy.

## Evidence and mathematical scope

- source/ and machine/: exact MP0 source, native table, canonical table and
  full state-label map. Native halt is 254; canonical halt is 216. Neither
  halt label is counted among the 216 working states.
- checks/ and verify.py: owned executable checkers and literal recipes.
- inputs/: dependency-closed inert baseline data, label map and the fixed
  dominated-row certificate. The latter is checked without proof search.
- evidence/: full runtime census, aggregate and row coverage, exact blank
  witness, AX trace, finite credit corroboration and isolated replay receipt.
- proofs/source_binding.md: the exact source surgery, deleted arithmetic
  block's all-natural loop proof, and explicit separation of obligations.
- proofs/mp0_compiler.md: the repaired ordinary mathematical compiler proof.
  proofs/protected_credit.md is the unchanged conservative credit induction.
- Other proof/provenance files: inherited calculus/macro premises, prior
  compiler arguments used by the MP0 repair, and unchanged attribution.
  Historical names and state counts inside those texts describe their
  original scope, not this candidate. Their paths are archival references,
  never executable replay dependencies. licenses/ retains original notices.

The full blank frame is source ordinal 55, native state 84, head -2,
logical registers (1,11,2,0,0,0,0,0,0), gap 0, 59 spares of value 1 and
150 one-cells. It is identified with a partial initial AX by the exact
174-primitive prefix from ordinal 25 and registers (1,0,4,0,0,0,0,0,0).
Completing that unchanged AX relies on its inherited all-natural macro
contract, not merely on a finite trace. Physical spare cells and the ten
logical protected theorem heads are distinct resources.

This is executable ordinary mathematical evidence, conditional on the
identified inherited numerical-calculus and arithmetic-macro calibration.
It is not a new Lean/Rocq endpoint or unconditional nonhalting proof.
The written compiler and protected-credit inductions are separate from
finite corroboration and from symbolic whole-tape primitive checking.
