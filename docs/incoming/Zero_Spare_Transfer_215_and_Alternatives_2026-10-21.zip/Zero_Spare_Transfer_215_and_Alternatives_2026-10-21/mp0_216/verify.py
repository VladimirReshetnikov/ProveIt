#!/usr/bin/env python3
"""Owned offline MP0-216 replay; inert inputs, Python standard library only.
Source binding, exact finite startup, and all-natural primitive contracts are
separate checks. Written compiler/credit inductions are not formal endpoints.
"""
from pathlib import Path
import argparse,gzip,hashlib,json,os,sys,tempfile,time,subprocess,shutil
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'checks'))
import source_utils as B
import independent_runtime as I
import check_fixed_certificate as C
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def at(t,p):
 for b in p:t=t[int(b)]
 return t
def replace(t,p,n):
 if not p:return n
 return (replace(t[0],p[1:],n),t[1])if p[0]=='0'else(t[0],replace(t[1],p[1:],n))
def unique(t):
 found=set()
 def go(n):
  if n in found:return
  found.add(n)
  if not B.leaf(n):go(n[0]);go(n[1])
 go(t);return len(found)
def structured(t):
 from functools import lru_cache
 @lru_cache(None)
 def length(n):return 1 if B.leaf(n)else length(n[0])+length(n[1])
 N=length(t);rows=[]
 def go(n,i,bs,cs):
  if B.leaf(n):
   op,k=n;target=lambda a,j:a[-j]%N if len(a)>=j else 0
   e=[]if op=='CH'else[target(bs,k)]if op=='CB'else[target(cs,k)]if op=='CC'else[target(bs,1),(i+1)%N]if op=='CD'else[(i+1)%N]
   assert len(rows)==i;rows.append([op,None if op in ('CB','CC')else k,e]);return
  mid=i+length(n[0]);go(n[0],i,bs+[i+length(n)],cs);go(n[1],mid,bs,cs+[i])
 go(t,0,[],[]);return rows

def main():
 if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'):
  raise RuntimeError('Verification requires enabled assertions; disable -O, -OO and PYTHONOPTIMIZE.')
 ap=argparse.ArgumentParser();ap.add_argument('--runtime',action='store_true');ap.add_argument('--work',type=Path);ap.add_argument('--no-manifest',action='store_true',help=argparse.SUPPRESS);args=ap.parse_args()
 if not args.no_manifest:
  for x in json.loads((R/'MANIFEST.json').read_text())['files']:
   p=R/x['path'];assert p.is_file()and p.stat().st_size==x['bytes']and H(p)==x['sha256'],x['path']
 W=args.work.resolve() if args.work else Path(tempfile.mkdtemp(prefix='mp0-216-replay-',dir=R))
 if args.work:W.mkdir(parents=True,exist_ok=False)
 started=time.monotonic();out={'status':'RUNNING','candidate':'MP0-216','working_states':216,'halt_labels':1,'received_code_executed':False,'formal_proof_assistant_endpoint':False}
 # Rebuild MP0 source by one literal tree surgery on the delivered transfer
 # baseline. The old baseline is inert input, not promoted as a new result.
 recipe=json.loads((R/'checks/source_recipe.json').read_text())
 assert H(R/'inputs/transfer201_baseline.sites.json')==recipe['input_sha256']
 oldsites=json.loads((R/'inputs/transfer201_baseline.sites.json').read_text());old=B.tree(oldsites)
 assert unique(old)==201 and len(oldsites)==4775
 oldpart=at(old,'11010111');assert not B.leaf(oldpart)
 assert len(B.flatten(oldpart[0]))==19 and len(B.flatten(oldpart[1]))==7
 new=replace(old,'11010111',oldpart[1]);sites=B.flatten(new)
 assert B.compact(sites)==(R/'source/mp0_201.sites.json').read_bytes()
 assert H(R/'source/mp0_201.sites.json')==recipe['output_sha256']=='2ec05ced11603aa1cac306d5c30460c446bf8b7480e22216929d7239a12970bb'
 assert unique(new)==201 and len(sites)==4756
 leaves={x[0]for x in sites};prefixes={p[:j]for p in leaves for j in range(len(p))}
 assert not leaves&prefixes and len(prefixes)==len(leaves)-1
 assert all(p+b in leaves|prefixes for p in prefixes for b in '01')
 assert max(map(len,leaves))==44 and all(set(p)<={'0','1'}and len(p)<=64 for p in leaves)
 assert sum(2 if op=='CD'else 1 for p,op,k in sites)==6184
 assert all(op in ('CI','CD','CB','CC','CH') and (k is None if op=='CH'else type(k)is int and (0<=k<9 if op in ('CI','CD')else k>=1))for p,op,k in sites)
 G=B.cfg(sites);oldG=B.cfg(oldsites)
 assert structured(new)==G and structured(old)==oldG
 # Bind every surviving primitive and edge under omission/contraction. All
 # entries into the omitted block must use its first node; no partial skip.
 removed=[i for i,x in enumerate(oldsites)if x[0].startswith('110101110')];a,b=min(removed),max(removed)+1
 assert removed==list(range(4670,4689)) and sites[:a]==oldsites[:a]
 survivor=[i for i in range(len(oldsites))if i not in removed]
 ren={j:i for i,j in enumerate(survivor)}
 incoming=[]
 for i in survivor:
  op,k,edges=oldG[i];j=ren[i]
  assert oldsites[i][1:]==sites[j][1:]
  expected_path=oldsites[i][0]
  if expected_path.startswith('110101111'):expected_path='11010111'+expected_path[len('110101111'):]
  assert sites[j][0]==expected_path
  mapped=[]
  for z in edges:
   if z in removed:
    assert z==a;incoming.append([i,z]);z=b
   mapped.append(ren[z])
  assert G[j]==[op,k,mapped],(i,j)
 local=[]
 for i in removed:
  op,k,edges=oldG[i];assert all(a<=z<b or z==b for z in edges)
  local.append([op,k,[z-a if z<b else 'EXIT'for z in edges]])
 assert incoming and local==recipe['removed_local_cfg']
 # Independently bind the physical prefix successor used by the runtime
 # kernel to the structured source graph at every primitive guard.
 first={}
 for i,(p,op,k)in enumerate(sites):
  for j in range(len(p)+1):first.setdefault(p[:j],i)
 def resolve(p):
  while p not in first:assert p.endswith('0');p=p[:-1]
  return first[p]
 bindings=[]
 for i,(p,op,k)in enumerate(sites):
  for positive in ((False,True)if op=='CD'else(False,)):
   if op=='CH':dest=None
   elif op=='CI'or(op=='CD'and positive):dest=resolve(I.inc(p)[0])
   elif op in ('CD','CB'):dest=resolve(I.inc(I.strip(p,'0',1 if op=='CD'else k))[0])
   else:dest=resolve(I.strip(p,'1',k))
   expected=None if op=='CH'else G[i][2][int(positive)]if op=='CD'else G[i][2][0]
   assert dest==expected,(i,op,positive,dest,expected)
   bindings.append([i,positive,dest])
 assert len(bindings)==6184
 binding_bytes=B.compact(bindings)
 assert binding_bytes==(R/'evidence/source_contract_bindings.json').read_bytes()
 out['source_binding']={'status':'PASS','source_nodes':201,'primitive_occurrences':4756,'guards':6184,'independent_cfg_match':True,'all_surviving_primitives_and_edges_match_contraction':True,'removed_occurrences':19,'removed_ordinal_interval':[a,b],'removed_entry_edges':incoming,'physical_source_contract_bindings':len(bindings),'bindings_sha256':hashlib.sha256(binding_bytes).hexdigest(),'maximum_source_depth':44}
 (W/'source_contract_bindings.json').write_bytes(binding_bytes)
 # Exact three-row delta: redirect native 100/1 and append selector 313.
 recipe=json.loads((R/'checks/table_recipe.json').read_text())
 assert H(R/'inputs/transfer215_baseline.native.tm')==recipe['input_sha256']
 T=B.parse_table(R/'inputs/transfer215_baseline.native.tm')
 for x in recipe['rows']:
  key=tuple(x['key']);assert T.get(key)==(None if x['old']is None else tuple(x['old']))
  T[key]=tuple(x['new'])
 assert B.encode(T)==(R/'machine/mp0_216.native.tm').read_bytes()
 assert H(R/'machine/mp0_216.native.tm')==recipe['output_sha256']=='d44da580aa85271f7d459aa3e93997b986150a4390ec4d990dbc832ff1670fe3'
 qs={q for q,b in T};assert len(qs)==216 and len(T)==432 and 254 not in qs
 assert all((q,b)in T for q in qs for b in (0,1))and all(z in qs|{254}for w,d,z in T.values())
 m={q:i for i,q in enumerate(sorted(qs))};m[254]=216
 assert m=={int(q):z for q,z in json.loads((R/'machine/canonicalization.json').read_text()).items()}
 K=I.table(R/'machine/mp0_216.tm');assert K=={(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()}
 assert set(q for q,b in K)==set(range(216))
 reach={0};todo=[0]
 for q in todo:
  for b in (0,1):
   z=T[q,b][2]
   if z!=254 and z not in reach:reach.add(z);todo.append(z)
 assert reach==qs
 out['literal_table']={'status':'PASS','working_states':216,'transition_rows':432,'native_halt_label':254,'canonical_halt_label':216,'all_working_states_graph_reachable':True}
 # All 68,442 blank transitions: sparse native, dense native and canonical
 # sparse implementations agree. Compare the entire finite nonzero tape.
 f=json.loads((R/'evidence/blank_frame.json').read_text())[0]['frames'][0]
 assert f['steps']==68442 and f['logical']==[1,11,2,0,0,0,0,0,0]and f['spares']==[1]*59
 assert sites[55][0]=='110100100101010'
 expected={x-2 for x in I.frame(sites[55][0],f['logical'],f['spares'],0)}
 assert expected==set(f['one_cells'])and len(expected)==150
 q=h=cq=ch=q2=h2=0;ones=set();con=set();left=bytearray(4096);right=bytearray(4096)
 for tick in range(68442):
  w,d,q=T[q,int(h in ones)]
  if w:ones.add(h)
  else:ones.discard(h)
  h+=d;cw,cd,cq=K[cq,int(ch in con)]
  if cw:con.add(ch)
  else:con.discard(ch)
  ch+=cd;assert(cq,ch,con)==(m[q],h,ones)
  cells,i=(right,h2)if h2>=0 else(left,-1-h2);assert 0<=i<len(cells)
  w,d,q2=T[q2,cells[i]];cells[i]=w;h2+=d
  assert(q2,h2)==(q,h)
 dense={i for i,b in enumerate(right)if b}|{-i-1 for i,b in enumerate(left)if b}
 assert(q,h)==(q2,h2)==(84,-2)and ones==dense==expected
 out['startup']={'status':'EXACT_FRAME_PASS','steps':68442,'source_ordinal':55,'native_state':84,'head':h,'logical':f['logical'],'spares':59,'spare_value':1,'one_cells':150,'gap':0,'sparse_dense_and_canonical_agree':True}
 # Independent abstract 174-primitive replay of the initial partial AX.
 rec=json.loads((R/'evidence/ax_bootstrap_match.json').read_text());pc=25;reg=[1,0,4,0,0,0,0,0,0];trace=[]
 for tick in range(174):
  trace.append([pc,reg.copy()]);op,k,edges=G[pc]
  if op=='CI':reg[k]+=1;pc=edges[0]
  elif op=='CD':
   if reg[k]:reg[k]-=1;pc=edges[1]
   else:pc=edges[0]
  else:assert op in ('CB','CC');pc=edges[0]
 assert pc==55 and reg==f['logical']
 assert rec['trace']==trace and rec['entry_ordinal']==25 and rec['exit_ordinal']==55 and rec['steps']==174
 bridge=json.loads((R/'evidence/ax_bridge_prior.json').read_text())
 assert bridge['trace_matches_original']and bridge['exit_registers']==reg and bridge['blank_native_steps']==68442
 out['ax_prefix']={'status':'EXACT_SOURCE_PREFIX_MATCH','steps':174,'entry_ordinal':25,'exit_ordinal':55,'entry_registers':[1,0,4,0,0,0,0,0,0],'exit_registers':reg}
 # Reproduce the inherited fixed logical certificate, without running the
 # prover that discovered it. Its calculus calibration remains inherited.
 cert=C.verify(C.read_json(R/'inputs/dominated_rho8_full_certificate.json'),True)[0]
 assert cert['verified']and cert['proof_nodes']==3728 and cert['term_table_nodes']==5160
 out['inherited_dominated_certificate']=cert
 # This finite calculation corroborates, but does not replace, the copied
 # written protected-credit induction (which already ignores MP pushes).
 shutil.copy2(R/'checks/check_transfer_credit.py',W/'check_transfer_credit.py')
 subprocess.run([sys.executable,str(W/'check_transfer_credit.py')],check=True,cwd=W,stdout=subprocess.DEVNULL)
 assert json.loads((W/'TRANSFER_CREDIT_CHECK.json').read_text())==json.loads((R/'evidence/credit_finite.json').read_text())
 out['finite_credit_corroboration']={'status':'PASS','candidates':500000,'diagonals':997,'not_a_substitute_for_induction':True}
 print('PASS: exact MP0 source/table, independent CFG and source contracts, full blank frame, AX prefix, inherited fixed certificate and finite credit corroboration',flush=True)
 if args.runtime:
  from generate_runtime import generate
  data,r=generate()
  assert data==gzip.decompress((R/'evidence/runtime_cases.json.gz').read_bytes())
  assert r==json.loads((R/'evidence/runtime.json').read_text())
  assert r['cases']==6184 and r['row_coverage']==432
  (W/'runtime_cases.json.gz').write_bytes(gzip.compress(data,compresslevel=9,mtime=0));dump(W/'runtime.json',r)
  out['runtime']={k:r[k]for k in ('status','cases','symbolic_rules','row_coverage','minimum_duration','cases_sha256','table_sha256','source_sha256','kernel_sha256','helper_sha256','scope')}
 out.update(status='FULL_REPLAY_PASS'if args.runtime else'FINITE_REPLAY_PASS',seconds=time.monotonic()-started)
 dump(W/'replay.json',out);print(json.dumps({k:v for k,v in out.items()if k!='inherited_dominated_certificate'},indent=2));print('Receipts:',W)
if __name__=='__main__':main()
