# Optional secondary 215-state association

This component packages the alternate association of the same transfer
source: S = (DROP; (NIP; NIP)) instead of ((DROP; NIP); NIP). It is not a
new proof language, a new axiom system, or a 214-state machine.

## Exact files and result

- `source/secondary201.sites.json`: 4,775 primitive occurrences, SHA-256
  eb74b6919ad6f740241c11904a9af1410fa61a71dc10174e998804dabd919024.
- `machine/secondary215.native.tm`: 215 working states, 430 rows, native
  start 74, halt 254, SHA-256
  b49dd77f055ed4e988da919d25529bc7f604c13379c2a64dd9ab645f66daec8c.
- Only 78 source addresses change. All guarded ordinal successors and
  arithmetic effects remain exactly equal to the primary source.
- Its own append-zero universal runtime census has 6,209 cases,
  1,611,366 symbolic rule applications, all 430 rows, and minimum duration 8.
- Its own 73,172-step blank run reaches the exact complete frame at source
  ordinal 119, state 84, head -2. The 177-step AX prefix is separately
  replayed on this source. The frame has 65 spares and 107 one-cells.
- The rooted labeled binary graph is nonisomorphic to the primary graph.

## Offline replay

Python 3 and its standard library are sufficient. Assertions must be enabled.
The package executes only the included owned checkers. No supplied Python
program or downloaded software is imported or run. The source-site array and
binary table are interpreted as inert data by the owned checkers.

    python -I -B verify.py
    python -I -B verify.py --runtime

The first command checks all packaged hashes, exact single source rotation,
two independent source-CFG constructions, exact blank frame in two tape
representations, all 177 source-prefix steps, binary graph distinction,
and integrity of the saved runtime census. It does not rederive the
universal runtime result. The second command additionally rederives every
symbolic runtime case and its arbitrary-spare-list schemas on this table,
checks the complete census byte for byte, and checks every covered row.
The full option normally takes about two minutes, depending on hardware.

Use `--work /path/to/new-directory` to select a fresh receipt directory;
otherwise a new temporary directory is created. No network, repository,
installed third-party package, search process, or sibling Python import is
needed. Both large reference inputs are deterministically gzip-compressed.

## Scope and shared mathematical dependencies

The replay is standalone for the source equivalence, physical startup,
source-prefix bridge, graph distinction and binary runtime obligations.
The full ZFC calibration inherits the primary component's ordinary
mathematical proofs and dominated-row certificate. For that statement,
keep this directory beside `primary/` in the final bundle (the development
name `zero_spare_component/` is also recognized in the dependency list),
and run the primary component's `verify.py --runtime` as well.

MANIFEST.json pins both the local files and the inherited proof dependencies.
When a recognized sibling is present, its pinned dependencies are hash-checked
too. Use `--require-primary` to reject an absent primary, or `--primary PATH`
to select it explicitly. These hash checks do not rerun its proof obligations.
See `proofs/association_transport.md` for why the inherited arguments apply.
The current initializer has eight safe heads above opaque tail 171, starts
at cutoff N=0, incurs credit debt three and preserves margin five. Historical
append-one initializers in inherited documents are not used here.

The kernel uses literal binary steps, natural-length unary induction and
finite-list structural induction. This is executable mathematical evidence,
not a newly compiled proof-assistant endpoint. The finite startup traces,
source bridge, and receipt hashes alone do not establish the universal
runtime theorem or independently prove Con(ZFC).
