# Exact association transport, not a new proof language

Let A be the pinned primary source `primary201.sites.json.gz`, and B the
pinned secondary source `secondary201.sites.json`. The source arrays each
contain 4,775 primitive occurrences in the same order, with identical
primitive opcodes and arguments. Exactly 78 binary addresses differ.

At prefix 111, A is ((DROP,NIP),NIP), while B is (DROP,(NIP,NIP)). The
three literal subtree/address correspondences are 11100 -> 1110,
11101 -> 11110, and 1111 -> 11111. Everything outside this command is
unchanged. `verify.py` reconstructs the two full binary trees and checks
this exact single rotation, not only the equality of their leaf lists.

Reassociation alone is not assumed to preserve structured CB/CC control.
For every primitive occurrence, the replay computes the guarded ordinal
successor graph by physical prefix navigation, and independently by
structured prefix interval endpoints. All four resulting graphs (two
sources, two constructions) are identical. For CD, the zero and positive
guards remain distinct, in that order. Register updates and CH occurrences
are identical. Induction on source transitions therefore gives lockstep
ordinal/register behavior for every initial register vector, including
termination and halt tests. This is stronger than a finite trajectory test.

The primary command compiler, protected scheduler credit, and numerical
calculus calibration consequently apply unchanged to B. There is no new
proof system, arithmetic encoding, axiom set, compiler word, or proof-code
claim. The shared proof dependencies are listed in MANIFEST.json; the
primary's historical append-one initializer is not substituted for the
current append-zero initializer.

Physical source addresses do change, so the primary binary runtime theorem
is not silently reused. `verify.py --runtime` rederives all 6,209 guarded
whole-tape contracts on the secondary table itself, using independent
natural register lengths, arbitrary extra gap, arbitrary nonempty finite
spare lists, and complete zero exteriors. The CI contract appends B(0)=01.
It matches the secondary census byte for byte, covers all 430 rows, and
has 1,611,366 symbolic rule applications and minimum duration eight.

Likewise the actual secondary table is simulated for all 73,172 blank
transitions from native state 74. Sparse and dense tape representations
agree, and the entire tape equals the reconstructed source frame at
ordinal 119, state 84, head -2, with all 65 spare blocks and zero exterior.
The 177-step AX prefix is replayed on B from ordinal 25, matching every
intermediate ordinal and register vector. The inherited startup argument
then gives eight safe heads over the unsafe opaque tail 171, debt three,
and permanent margin five. These finite physical checks do not replace
the universal runtime or the inherited arithmetic/credit arguments.

The secondary and primary rooted labeled transition graphs are not
isomorphic. A forced state mapping collides at read word
0000000100100000000111101. Graph novelty is separate from the source
semantic equivalence and is not evidence of a smaller machine: both have
215 working states, plus a halt state. No 214-state result or newly compiled
proof-assistant endpoint is claimed.
