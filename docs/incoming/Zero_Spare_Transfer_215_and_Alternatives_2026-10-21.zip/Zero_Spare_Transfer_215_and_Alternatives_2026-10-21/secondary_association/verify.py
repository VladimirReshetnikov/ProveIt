#!/usr/bin/env python3
"""Owned offline checks for the reassociated append-zero transfer215.
All source/table inputs are inert data. Standard library only; enable assertions.
"""
from pathlib import Path
import argparse,gzip,hashlib,json,os,sys,tempfile,time
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'checks'))
import source_utils as B
import independent_runtime as I
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def digest(b):return hashlib.sha256(b).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def guarded_graph(sites):
 leaves={pc:i for i,(pc,op,reg)in enumerate(sites)}
 prefixes={pc[:k]for pc in leaves for k in range(len(pc)+1)}
 def first(pc):
  while pc not in prefixes:assert pc.endswith('0');pc=pc[:-1]
  while pc not in leaves:pc+='0'
  return leaves[pc]
 def after(pc):
  pc=pc.rstrip('1');return pc[:-1]+'1'if pc else''
 def ancestor(pc,bit,count):
  for _ in range(count):
   j=pc.rfind(bit)
   if j<0:return''
   pc=pc[:j]
  return pc
 graph=[]
 for pc,op,reg in sites:
  if op=='CI':graph.append([op,reg,[first(after(pc))]])
  elif op=='CD':graph.append([op,reg,[first(after(ancestor(pc,'0',1))),first(after(pc))]])
  elif op=='CB':graph.append([op,None,[first(after(ancestor(pc,'0',reg)))]])
  elif op=='CC':graph.append([op,None,[first(ancestor(pc,'1',reg))]])
  else:assert op=='CH';graph.append(['CH',None,[]])
 return graph
def main():
 if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'):
  raise RuntimeError('Enable assertions: do not use -O or PYTHONOPTIMIZE')
 ap=argparse.ArgumentParser();ap.add_argument('--runtime',action='store_true');ap.add_argument('--work',type=Path);ap.add_argument('--primary',type=Path,help='Optional shared primary proof component');ap.add_argument('--require-primary',action='store_true',help='Require and hash-check shared mathematical proof dependencies');ap.add_argument('--no-manifest',action='store_true',help=argparse.SUPPRESS);args=ap.parse_args()
 inherited={'present':False,'checked_files':0}
 if not args.no_manifest:
  manifest=json.loads((R/'MANIFEST.json').read_text())
  for x in manifest['files']:
   p=R/x['path'];assert p.is_file()and p.stat().st_size==x['bytes']and H(p)==x['sha256'],x['path']
  primary=args.primary or next((R.parent/name for name in('primary','zero_spare_component')if(R.parent/name).is_dir()),None)
  if primary is not None:
   for x in manifest['inherited_proof_dependencies']['files']:
    p=primary/x['path'];assert p.is_file()and p.stat().st_size==x['bytes']and H(p)==x['sha256'],str(p)
   inherited={'present':True,'checked_files':len(manifest['inherited_proof_dependencies']['files']),'scope':'Hashes checked; run primary verify.py --runtime for its executable obligations.'}
  assert not args.require_primary or inherited['present'],'Primary proof component required but not found'
 W=args.work or Path(tempfile.mkdtemp(prefix='secondary215-replay-'))
 if args.work:W.mkdir(parents=True,exist_ok=False)
 started=time.monotonic()
 a_bytes=gzip.decompress((R/'inputs/primary201.sites.json.gz').read_bytes());a=json.loads(a_bytes)
 b_bytes=(R/'source/secondary201.sites.json').read_bytes();b=json.loads(b_bytes)
 assert digest(a_bytes)=='05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922'
 assert digest(b_bytes)=='eb74b6919ad6f740241c11904a9af1410fa61a71dc10174e998804dabd919024'
 assert len(a)==len(b)==4775 and a[:4697]==b[:4697]
 assert all(x[1:]==y[1:]for x,y in zip(a,b))
 assert sum(x[0]!=y[0]for x,y in zip(a,b))==78
 def sub(s,p):return [(pc[len(p):],op,k)for pc,op,k in s if pc.startswith(p)]
 for x,y in [('11100','1110'),('11101','11110'),('1111','11111')]:assert sub(a,x)==sub(b,y)
 # Literal tree rotation and independent ordinal-control reconstructions.
 old=B.tree(a);new=B.tree(b)
 def at(t,p):
  for x in p:t=t[int(x)]
  return t
 def replace(t,p,n):
  if not p:return n
  return(replace(t[0],p[1:],n),t[1])if p[0]=='0'else(t[0],replace(t[1],p[1:],n))
 command=at(old,'111');assert command[0][1]==command[1]
 assert new==replace(old,'111',(command[0][0],(command[0][1],command[1])))
 assert B.flatten(new)==b and B.compact(b)==b_bytes
 def nodes(t):
  seen=set()
  def walk(n):
   if n in seen:return
   seen.add(n)
   if not B.leaf(n):walk(n[0]);walk(n[1])
  walk(t);return len(seen)
 assert nodes(old)==nodes(new)==201
 G=guarded_graph(b);assert G==guarded_graph(a)==B.cfg(a)==B.cfg(b)
 leaves={pc for pc,op,k in b};prefixes={p[:k]for p in leaves for k in range(len(p))}
 assert not leaves&prefixes and len(prefixes)==len(leaves)-1
 assert all(p+c in leaves|prefixes for p in prefixes for c in '01')
 assert sum(2 if op=='CD'else 1 for pc,op,k in b)==6209
 assert max(map(len,leaves))==44
 association={'status':'PASS','unique_source_nodes':201,'sites':4775,'guards':6209,'first_changed_ordinal':4697,'changed_addresses':78,'opcodes_and_arguments_unchanged':True,'guarded_ordinal_graph_identical':True,'independent_cfg_match':True,'literal_subtrees_preserved':[['11100','1110'],['11101','11110'],['1111','11111']],'rotation':'((DROP,NIP),NIP) -> (DROP,(NIP,NIP))','source_sha256':digest(b_bytes),'primary_source_sha256':digest(a_bytes)}
 dump(W/'source_association.json',association)
 T=I.table(R/'machine/secondary215.native.tm');A=I.table(R/'inputs/primary215.native.tm')
 assert H(R/'machine/secondary215.native.tm')=='b49dd77f055ed4e988da919d25529bc7f604c13379c2a64dd9ab645f66daec8c'
 assert H(R/'inputs/primary215.native.tm')=='29a6ed4a594d7f974cf267a9e6b665af34c9afd8dd7abbbecf0b538ecab151e0'
 qs={q for q,bit in T};assert len(qs)==215 and len(T)==430 and 254 not in qs
 assert all((q,bit)in T for q in qs for bit in(0,1))and all(z in qs|{254}for w,d,z in T.values())
 assert T[198,0]==(0,-1,40)
 assert (R/'machine/secondary215.native.tm').read_text().splitlines()[0]=='#! start 74'
 reach={74};todo=[74]
 for q in todo:
  for bit in(0,1):
   z=T[q,bit][2]
   if z!=254 and z not in reach:reach.add(z);todo.append(z)
 assert reach==qs
 # A two-sided rooted labeled graph bijection is forced by the read alphabet.
 mapping={74:74};inverse={74:74};todo=[(74,74,'')];noniso=None
 for u,v,word in todo:
  if u==254 or v==254:
   if u!=v:noniso={'word':word,'reason':'halt mismatch'};break
   continue
  for bit in(0,1):
   wa,da,ua=A[u,bit];wb,db,vb=T[v,bit];s=word+str(bit)
   if(wa,da)!=(wb,db):noniso={'word':s,'reason':'edge output mismatch'};break
   if ua in mapping and mapping[ua]!=vb:noniso={'word':s,'reason':'forced map not functional'};break
   if vb in inverse and inverse[vb]!=ua:noniso={'word':s,'reason':'forced map not injective'};break
   if ua not in mapping:mapping[ua]=vb;inverse[vb]=ua;todo.append((ua,vb,s))
  if noniso:break
 assert noniso is not None
 graph={'isomorphic':False,**noniso};assert graph==json.loads((R/'evidence/primary_graph_comparison.json').read_text())
 # Run every binary step from the actual all-zero tape and reconstruct every 1.
 q=74;head=0;ones=set();q2=74;h2=0;left=bytearray(4096);right=bytearray(4096)
 for tick in range(73172):
  w,d,q=T[q,int(head in ones)]
  if w:ones.add(head)
  else:ones.discard(head)
  head+=d
  cells,i=(right,h2)if h2>=0 else(left,-1-h2);assert 0<=i<len(cells)
  w,d,q2=T[q2,cells[i]];cells[i]=w;h2+=d;assert(q,head)==(q2,h2)
 dense={i for i,v in enumerate(right)if v}|{-i-1 for i,v in enumerate(left)if v}
 f=json.loads((R/'evidence/blank_frames.json').read_text())[1]['frames'][0]
 assert f['logical']==[0,6,0,0,1,1,10,1,0]and f['spares']==[0,0,1]+[0]*62
 assert(q,head)==(84,-2)and f['steps']==73172 and f['head']==head and f['header']==62
 expected={x+head for x in I.frame(b[119][0],f['logical'],f['spares'],0)}
 assert ones==dense==set(f['one_cells'])==expected and len(ones)==107
 # Replay the 177-step AX source prefix on the secondary source itself.
 bridge=json.loads((R/'evidence/ax_prefix.json').read_text());rec=bridge['attempts'][0]
 assert bridge['source_sha256']==digest(a_bytes)
 pc=25;reg=[0,0,0,0,1,1,0,0,0];trace=[]
 for tick in range(177):
  trace.append([pc,reg.copy()]);op,k,edges=G[pc]
  if op=='CI':reg[k]+=1;pc=edges[0]
  elif op=='CD':
   if reg[k]:reg[k]-=1;pc=edges[1]
   else:pc=edges[0]
  else:assert op in('CB','CC');pc=edges[0]
 assert pc==119 and reg==f['logical']and trace==rec['trace']
 assert(rec['entry_ordinal'],rec['exit_ordinal'],rec['steps'])==(25,119,177)
 assert rec['entry_registers']==[0,0,0,0,1,1,0,0,0]and rec['exit_registers']==reg
 ir=json.loads((R/'evidence/independent_startup.json').read_text());iv=ir['variants'][1]
 assert ir['status']=='PASS'and iv['source_sha256']==digest(b_bytes)and iv['table_sha256']==H(R/'machine/secondary215.native.tm')
 assert iv['blank_steps']==73172 and iv['full_frame_exact']and iv['source_ordinal']==119 and iv['source_address']==b[119][0]and iv['logical']==reg
 assert(ir['protected_heads'],ir['opaque_tail'],ir['known_credit_debt_at_N0'],ir['permanent_margin'])==(8,171,3,5)
 startup={'status':'EXACT_FRAME_AND_AX_PREFIX_PASS','binary_steps':73172,'native_start':74,'exit_state':84,'head':-2,'source_ordinal':119,'source_address':b[119][0],'one_cells':107,'spares':65,'logical':reg,'gap':0,'full_sparse_dense_frame_agreement':True,'source_prefix_steps':177}
 original=json.loads((R/'evidence/runtime.json').read_text());census=gzip.decompress((R/'evidence/runtime_cases.json.gz').read_bytes());stored=json.loads(census)
 assert digest(census)==original['cases_sha256']=='f4d95096d0bf9597c0dcd0edeea360f962a22c48418d381388f816e20624a25a'
 assert original['status']=='ALL_NATURAL_RUNTIME_PASS'and original['append_spare_value']==0 and original['failure']is None
 assert(original['cases'],original['expected_cases'],original['symbolic_rules'],original['row_coverage'],original['minimum_duration'])==(6209,6209,1611366,430,8)
 assert original['source_sha256']==digest(b_bytes)and original['table_sha256']==H(R/'machine/secondary215.native.tm')
 assert original['kernel_sha256']==H(R/'checks/symbolic_runtime.py')and original['helper_sha256']==H(R/'checks/independent_runtime.py')
 assert len(stored)==6209 and sum(c['symbolic_steps']for c in stored)==1611366
 out={'status':'FINITE_REPLAY_PASS','inherited_dependencies':inherited,'candidate':'secondary-association-transfer215','target214_met':False,'source_association':association,'graph_comparison':graph,'startup':startup,'stored_runtime_census_integrity':'PASS','runtime_rederived':False,'received_code_executed':False,'proof_assistant_endpoint_claimed':False}
 print('PASS: exact source reassociation, full blank startup, AX prefix, graph distinction and census integrity',flush=True)
 if args.runtime:
  import symbolic_runtime as S
  M={int(a):int(b)for a,b in json.loads((R/'inputs/NATIVE_TO_LEGACY.json').read_text()).items()}
  assert len(set(M.values()))==len(M)and M[84]==96 and M[254]==254
  for q in sorted(qs|{z for w,d,z in T.values()}):
   if q not in M:M[q]=max(M.values())+1
  legacy={(M[q],bit):(w,d,M[z])for(q,bit),(w,d,z)in T.items()}
  lemmas,blocks=S.prove_blocks(legacy);cases=[];rows=set()
  for i,site in enumerate(b):
   for pos in((False,True)if site[1]=='CD'else(False,)):
    c=S.case(legacy,lemmas,site,pos,append=0);rows.update(c.pop('rows'));c.pop('trace');cases.append(dict(index=i,positive=pos,**c))
   if i%500==0:print('Runtime:',len(cases),'cases',flush=True)
  data=(json.dumps(cases,indent=2)+'\n').encode();assert data==census
  schema_rows={tuple(event[1][:2])for block in blocks for event in block['trace']if event[0]!='list'}
  assert rows==set(legacy)and rows|schema_rows==set(legacy)
  inverse={v:q for q,v in M.items()};native_rows=sorted((inverse[q],bit)for q,bit in rows|schema_rows)
  coverage=dict(used_rows=native_rows,unused_rows=sorted(set(T)-set(native_rows)),all_table_rows=len(T),used_count=len(native_rows),fresh_list_schema_rows_included=True)
  assert json.loads(json.dumps(coverage))==json.loads((R/'evidence/runtime_row_coverage.json').read_text())
  r={'status':'ALL_NATURAL_RUNTIME_PASS','cases':len(cases),'symbolic_rules':sum(c['symbolic_steps']for c in cases),'row_coverage':len(rows),'minimum_duration':min(c['duration'][0]for c in cases),'cases_sha256':digest(data),'fresh_block_certificates':blocks}
  for k in r:assert json.loads(json.dumps(r[k]))==original[k],k
  (W/'runtime_cases.json').write_bytes(data);dump(W/'runtime_row_coverage.json',coverage);dump(W/'runtime.json',r)
  out.update(status='FULL_REPLAY_PASS',runtime_rederived=True,runtime={k:v for k,v in r.items()if k!='fresh_block_certificates'})
 out['seconds']=time.monotonic()-started;dump(W/'replay.json',out)
 print(json.dumps(out,indent=2));print('Receipts:',W)
if __name__=='__main__':main()
