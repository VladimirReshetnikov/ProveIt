# Supplementary mathematical results and bounded checks

These files accompany the zero-spare transfer215 construction. They do not
promote any rejected experiment to a calibrated machine. In particular,
negative_controls/rejected_old_delete301_214.native.tm is a rejected old-policy
214-state table, not a solution; its source-runtime separator is the subject
of one narrowly stated theorem.

## Offline replay

Python 3, standard library, assertions enabled. Every --work directory must
be a new path. No network or received executable code is needed.

    python3 -I -B checks/check_prefix_encoding.py --work /tmp/fresh-prefix
    python3 -I -B checks/check_constructor_mismatch.py --work /tmp/fresh-correction
    python3 -I -B checks/check_graph_distinction.py --work /tmp/fresh-graphs
    python3 -I -B checks/check_state35_left_bound.py --work /tmp/fresh-state35

The first three are quick. The fourth repeats all 6,209 arbitrary-natural
cases and takes about three minutes on the preparation machine. It rebuilds
the exact 16,722 width-19 window cover from the proof, without a large scratch
trace. Its written theorem includes all unary/list induction interiors.

For the additional bounded local action search, use any C++17 compiler:

    c++ -std=c++17 -O2 checks/synthesize_state35.cpp -o /tmp/state35-search
    /tmp/state35-search negative_controls/rejected_old_delete301_214.native.tm /tmp/fresh-state35/state35_replay_windows19.txt

The output must end with SUMMARY 1 BEST 16722 STEPS 292312 and identify only
the original action, 1 R 35. Bounds are old catch-up 40/new catch-up 256,
856 one-row actions on the sound cover. This is not a general impossibility
result. The 85-step blank separator applies to this exact old resource
policy, not to later append-zero tables.

## What is and is not recomputed

- Prefix checker: independent 3,728-node dominated-row certificate, its
  1,260 domination witnesses, plus finite arithmetic corroboration. The
  all-natural constructor-isomorphism proof is a separate written argument.
- Constructor correction: literal inert-source census and exact missed
  split-Q interval in the named upstream source experiment. It does not
  invalidate unrelated published 215-state tables.
- Graph comparison: authenticates all 19 inert tables and their real starts,
  then regenerates all 171 exact comparisons, including all 18 target
  rejections. Two additional inert tables support the exact primary/secondary
  comparison and reparse comparison against all 20 others. Write-one row
  counts separately distinguish both parents.
- The 93-table upstream packet census is an archived audit receipt, not a
  claim that the compact runner downloads or reconstructs those packets.
- Source-pricing and exhaustive fixed-family optimization receipts summarize
  bounded experiments. The compact packet does not rerun all 4,194,304
  orientation choices, 559,872 row combinations or source allocation searches.
  These are distinct from the calibrated main machine's complete replay.
- The modal theorem-equality claim is explicitly withdrawn. Only the valid
  countermodel/correction is included, not the obsolete purported proof.
  Refutation equivalence remains open.

The source and prefix consolidation notes retain original working paths as
historical references, never as executable dependencies. Comparison tables,
source JSON, formula certificates and macro JSON are inert inputs. All shipped
Python/C++ programs are owned checkers. Underlying machine/source authorship
and licenses are retained in the primary and MP0 components. This supplement
makes no claim to a new proof-assistant endpoint.
