# CORRECTION: modal-B theorem-set calibration withdrawn

The theorem-set equality claimed below is FALSE. The source construction and finite pricing receipts remain syntactically valid, but no equiconsistency claim is established for these sources. The obsolete argument is retained below only to identify the precise failed step.

Countermodel on the ORIGINAL four-tag raw algebra: interpret native0 as true, native1=R(0,0) as true, all E atoms as false, all other R atoms arbitrarily (for example false), Q_i as the identity operation, and I as ordinary Boolean implication. The zero alias I(0,0)=0 is respected. Every retained logical row, new modal-B row, and full gated bundle is true: rho1 and the bundle end in native negations, which are always true when native1 is true; equality-premised rows are vacuous; normality and commutation are valid. Old rho6 at C=E(0,0)=3 is false. In particular old rho6 derives1->3 whereas this is false in the model.

The failed premise was double-negation elimination relative to native1. Pure classical implication does not provide it for an arbitrary atom. Original rho6 derives explosion1->A, which supplies the missing bottom behavior; replacing rho6 cannot silently inherit that fact. Whether a weaker refutation-only translation can salvage modal-B is left OPEN and is not claimed here.

This correction does not affect the separate binary-cover obstruction (which retains original rho6), or the four-constructor binary-prefix proposal (which transports original rho6 exactly).


The superseded argument is deliberately omitted from this packet. Refutation equivalence remains open; see modal_refutation_open.md.
