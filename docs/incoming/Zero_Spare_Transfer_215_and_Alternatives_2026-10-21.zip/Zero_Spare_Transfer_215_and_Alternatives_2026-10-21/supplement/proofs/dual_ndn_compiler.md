# A complete NDN interface obtained by dualizing both logical commands

Date: 2026-10-21. Status: complete command-level compiler and safe-run calibration; the measured literal implementation is too large. This does not certify a new <=215-state machine or its blank initialization.

## 1. Why reversing only the MP comparison is not the established result

Let R=oldNIP;oldDROP;oldNIP. For unpair(w)=(x,v), its exact behavior is:

- halt if incoming cache h=1 or popped head x=1;
- otherwise (t,w,d,h) -> (x,v,d,t).

The previously proved adjacency obstruction applies to R with the unchanged AX order and unchanged MP orientation. Merely reversing MP's comparison can escape that invariant, but no complete compiler for that one-change interface is asserted here. The construction below changes both logical commands in a precise, stronger way.

## 2. Exact new commands

Keep the same pairing, logical calculus, numerical parameters, command fields and scheduler. Keep R exactly as above. Define J(t,w,d,h)=(h,w,d,t), a swap of top and cache.

For MP*(x), let y=d+x. Test I(h,y)=t. On success return (0,[0;w],y,y); on failure return (0,w,y,0). Thus the result is in the cache, not the top.

For AX*(c;x,y), set U=d, A=d+x, B=t+y, C=c. Let G(A,B,C) be the original gated full bundle, or 0 when its gate fails. Return

(0,[R1(A,B,C),...,R7(A,B,C),L(A,B,C,U),Q_U(t),h;w],0,G(A,B,C)).

The logical rows and their order are unchanged. Incoming top is generalized and incoming cache is saved. Both commands are obtained by swapping register1 and register5 literally throughout the entire closed original MP or AX body, including scratch uses of those registers. They are exactly J MP J and J AX J. The scheduler and R body are not swapped.

## 3. Total normal-map conjugacy

Temporarily forget the halt tests and regard each command as its displayed total normal state map. The old transfer-pop S map is

S(t,[x;v],d,h)=(h,v,d,x).

Direct calculation gives J S J=R's normal map. Together with the two logical command identities, every finite old command word W has dual word W* satisfying

W*=J W J

as total normal state maps. This statement applies to all natural tuples and all numerical stacks, not merely safe inputs. Pairing zero causes no issue: unpair(P(x,v))=(x,v), including x=v=0, validates the same calculations.

The old transfer compiler's stronger algebraic fact is important here: when every S halt guard is ignored, its compiled proof block B_X returns exactly (X,w,0,0) from every (t,w,0,0). This follows from the already audited block equations, not from pretending that a halted execution has a final state. Those equations hold even if selected formulas are 1. In particular the GEN block has no special exception for X=1, and the major-first MP cleanup remains an exact equation for A=1 or B=1. The old optional guards only interrupted some of these otherwise exact paths.

Consequently the dual block B*_X has the exact total normal-map contract

(0,w,0,h) -> (0,w,0,X)

for every natural w,h. Every actual execution of B*_X either halts at one of R's real guards or follows this same finite normal-map computation to its displayed result. This proves the required halt-or-exact-return contract without asserting that the two interfaces have identical halt sets.

## 4. Strong completeness and all zero/one cases

Compile the exact same finite proof tree and command parameters as in the transfer compiler, replacing command names by their duals. Thus all truth, logical-row, dominated-rho8, full-bundle, GEN and major-first MP constructions transport together. No new induction on a non-well-founded proof order is introduced.

The premise compiler is universal in the arbitrary underlying numerical stack, so prior saved premises and temporary zeros are covered. The deliberately successful raw-zero MP case I(0,0)=0 is retained, including its pushed dummy zero and subsequent cleanup. If a proof block touches a 1 at an R guard it has already achieved the required halt. If it does not, the total-map calculation still applies. A refutation block B*_1 therefore either halts or returns cache1; appending one R halts immediately on that cache. This gives a fixed successful suffix from every clean tuple with top0 and counter0, regardless of cache and stack.

For a cofinal family of candidates, prefix this suffix with AX*(0;1,Y). From an arbitrary incoming tuple AX* resets top and counter to zero. Its output cache and stack may be arbitrary, exactly as allowed by the strong suffix contract. The same nested pairing encoding used by the three-command transfer scheduler gives a candidate number at least Y. Candidate residuals strictly decrease after each later decoded command. Hence every cutoff is followed by a successful candidate whenever a finite numerical refutation exists.

## 5. All-natural soundness and protected tails

On an actual safe run, top, cache and every available safe stack head are theorem values.

- R either halts on theorem-valued cache1 or theorem-valued popped head1, or returns a theorem head as top and old theorem top as cache.
- MP* succeeds only with theorem-valued h and theorem-valued major t=I(h,y), so its cached conclusion is a theorem; failure supplies truth. Any pushed head is truth0.
- AX* inserts the same axiom instances, a dominated row because d<=d+x, a generalization of theorem-valued top, and saved theorem-valued cache. Its returned cache is the permitted full bundle or truth.

Thus from any safe seed a halt implies a native refutation, including malformed raw candidate words. Starting at the abstract zero tuple is safe. The underlying numerical stack may be represented as an explicitly chosen finite theorem-valued wrapper over an unsafe tail; the representation need not be unique because P(0,0)=0. Each R consumes one such head, MP* never removes one, and AX* adds ten. In the literal R implementation, the initial pop consumes one safe head, then the push uses safe old top and the final pop consumes that temporary head. There is no hidden extra access to the unsafe tail.

The previous three-command protected-credit theorem therefore applies unchanged at command boundaries: weights R=-1, MP*=0, AX*=10, including all command-prefix lower bounds. Its cutoff1 result requires only two initial safe wrapper heads, so ten give a permanent margin of eight. However this is a conditional startup bridge: a new physical table still needs its own exact blank-to-AX-prefix match. The old transfer215 blank trace cannot simply be reused after the changed closed bodies.

## 6. Pricing and scope

The source worker materialized `research214_source/dual_ndn_0.sites.json`, `_1`, and `_2`, with exact closed-body swaps and unchanged NDN/scheduler. `DUAL_NDN_PRICES.json` records source-subtree counts 219,219,220. These are source counts, not physical-state counts. No favorable physical allocation or blank runtime is claimed.

The interface proves that the fixed-order NDN adjacency obstruction must not be generalized to all possible MP/AX interfaces. It also shows why merely flipping the MP comparison is not the complete repair: the result location, GEN input, saved incoming register, and AX output register all participate in the conjugacy. The total normal maps are algebraically dual to the accepted transfer interface, while the actual guards differ; this is not a claim of an independently new logical foundational calculus.
