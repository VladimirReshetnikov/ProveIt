# Modal-B: relative translation progress and the exact open obligation

Date: 2026-10-21. Status: theorem-set equality is disproved; REFUTATION EQUIVALENCE REMAINS OPEN. The countermodel with native1=true is not a counterexample to equiconsistency. No impossibility claim is made.

Work in the proposed modal-B calculus with F=1 and B_i(A): A->Q_i X_i A, where X_i A=NQ_iNA. All pure classical implicational tautologies, MP and theorem GEN remain available. Write jA=NNA. This is a relative closure, not an assertion of DNE.

## Facts that do close

1. Q_iF->F follows without oldrho6. Put D=E(i,0). Rho1 gives Q_i(D->F)->F. K gives F->(D->F); GEN/distribution and composition yield Q_iF->F.

2. F->Q_iF follows from newB. NF=F->F is a theorem, so Q_iNF is a theorem. Therefore X_iF=(Q_iNF->F) is equivalent toF, using MP/deduction in one direction and K in the other. NewB atF gives F->Q_iX_iF; normality lifts X_iF->F, yielding F->Q_iF. Thus Q_iF<->F.

3. Call A regular when F->A is a theorem. Every native negation is regular by K. Every jA is regular. If B is regular then A->B is regular; Q_iA is regular whenever A is, by point2 and normality. For a regularA, jA->A follows from Peirce and F->A; A->jA is a pure implicational tautology. This is CONDITIONAL DNE, not arbitrary DNE.

4. Original rho6 is derivable for regular matricesA. Instantiate newB atNA, obtaining NA->Q_iNQ_iNNA. By conditional DNE and normality, replace NNA withA. Contraposition then gives NQ_iNQ_iA->NNA, and conditional DNE gives NQ_iNQ_iA->A. This is exactly X_iQ_iA->A.

5. Regularizing raw atomic R/E by j, preserving implication, and applying Q to translated matrices gives a regular fragment with classical implication and originalrho6. Rho1 survives because N(jE)<->NE is a pure implicational triple-negation law. Pure equality/membership implication rows lift underj. The merged G row lifts using normality on E->jE and the regularity of the quantified consequent. Distribution and quantifier commutation instantiate directly on the translated matrices.

These facts show why the earlier theorem-set countermodel does not settle the desired consistency question.

## What does NOT follow merely from these facts

Do not assert Q_i jA <-> j Q_iA. Normality gives Q_iA->Q_i jA and point2 makes Q_i jA regular, but the converse needed for that equivalence is not automatic.

For a semantic witness to this non-automatic step, consider a two-world modal frame w->w,w->v,v->v, with F false atw and true atv. Let all Q_i use this same reflexive transitive relation. F<->Q_iF holds everywhere. Relative modal-B holds for every valuation ofC: atw, a trueC is witnessed atw for its non-F successor, while the F-successor satisfies the relative existential automatically; atv all relative existentials are true. Set A true atw and false atv. Then Q_i jA is true atw, while jQ_iA is false there. This witnesses the insufficiency of relative normality/B/rigidF alone, not a model of the complete numerical seed/equality calculus.

## Precise full-seed obstruction to the attempted translation

The original subset subformula is

  S(a,b,c)=Q_c(R(c,a)->R(c,b)).

Atomic regularization makes it

  S*(a,b,c)=Q_c(jR(c,a)->jR(c,b))
          <-> Q_c j(R(c,a)->R(c,b)).

OriginalS implies S*, but the original core uses S in the antecedent of S->B. That polarity needs the reverse direction (or a more sophisticated whole-core proof). Thus merely observing that the regularized quantifier ignores F-worlds does not justify transporting the full K core.

The B0 subexpression is easier: its membership atom occurs under native negation, so replacing R byjR leaves it provably equivalent. This does not remove the S obstacle in C0.

There is also the code/private-label obligation. A formula-only translation changes the actual matrix c to T(c), while the original seed binds the private label literally c. One cannot silently invoke the seed at T(c) and treat that binder as c, nor assume that a mixed-role numeric translation preserves the gate. A successful proof must either establish enough of the regularized seed schema directly at each actual regularized code, or give a finite mixed-role embedding with all equalities/disequalities and the private-code identity accounted for.

No argument currently proves that full membership vacuity and all original seed instances repair these two obligations. Conversely, no model currently refutes such a repair. The correct conclusion is an open, sharply identified refutation-calibration problem, not impossibility and not an established candidate.
