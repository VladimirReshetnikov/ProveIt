# Deleting the first AX push: compiler transport

This is a command-level proposal, not a verified physical machine. Exact raw AX semantics and physical price remain separately required.

Let D and N be the unchanged old DROP and NIP. Define AXdel by deleting only AX's first push-and-clear of incoming top. The next operation must be checked from literal source; preliminary macro analysis says the quantifier index becomes t+d instead of d. This is sound because theorem generalization permits every natural index. Other row/gate parameters must be checked independently, not inferred.

Two exact interface facts suffice for completeness:

1. When incoming cache h=0, D;AXdel has exactly old AX's behavior. D sends (t,w,d,0) to (0,[t;w],d,0). This is exactly the store after the deleted push-and-clear; the remaining AX body is identical.
2. When incoming top t=0, AXdel has old AX's behavior except omitting the final saved zero beneath the nine generated entries. The remaining body starts in the same nonstack store, so all nine generated values and the gate agree.

Use the complete four-command strong-block compiler in the prior215 report. Every AX call outside GEN has incoming cache0. Replace each such AX call by D;AXdel. This transports reset, truth, all retained rows, dominated row, full bundle, and MP cleanup exactly, including zero aliases and early halts.

For generalization, replace the old block by

    B_X; D; J(i); N; AXdel(i;0,0); N^9; D; N.

After B_X returns, its store is (X,w,0,0). D gives (0,[X;w],0,0). J(i) sets d=i with top/cache0; J(0) is empty, preventing the I(0,0)=0 success alias. N loads cacheX and restores underlying w, with top0. AXdel therefore supplies the original eight implication-coded rows and Q_i X, but no saved zero; its top gate is0 since c=A=i. Nine N commands leave (0,w,0,Q_i X). They test only initial cache0 and eight implication codes, never X. D gives (Q_i X,[0;w],0,Q_i X); one N tests the positive tag2 quantifier (not1), pops zero, and yields (Q_i X,w,0,0). This also covers X=1 and i=0.

Thus the unchanged inductive strong contract holds: from every (t,w,0,0), halt early or return (X,w,0,0). The final refutation suffix D;N;N remains unchanged. Raw junk stack codes need not be decoded.

For cofinal scheduling, a first AXdel(0;1,Y) still resets d=h=0 and leaves some top/stack, which the strong refutation block accepts universally. Exact Cantor packing and draining should be verified against unchanged field arities; the generated top/stack do not affect completeness. Soundness from the actual blank startup, including any buried unsafe tail, remains a separate physical-and-credit obligation.
