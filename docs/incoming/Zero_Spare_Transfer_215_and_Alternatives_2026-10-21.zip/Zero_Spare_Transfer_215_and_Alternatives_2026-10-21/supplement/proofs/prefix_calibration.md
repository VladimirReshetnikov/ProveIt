# Independent review: Q-priority binary-prefix encoding

Date: 2026-10-21. Verdict: **PASS for logical calibration**, relative to the same inherited numerical-calculus/ZFC bridge as the accepted machines. No physical state bound, source implementation, or blank-start claim is certified here.

Reviewed proposal: `research214_alternative_axioms/BINARY_PREFIX_Q_PRIORITY.md`. The new constructors, with Cantor pairing P, are

- I'(a,b)=2P(a,b),
- R'(a,b)=8P(a,b)+1,
- Q'(a,b)=4P(a,b)+3,
- E'(a,b)=8P(a,b)+5.

The old constructors are I=4P, R=4P+1, Q=4P+2, E=4P+3. All four constructors must change together, including the implication built by the MP command. This is not a mere change to tags in the printed logical definitions.

## 1. All-natural algebra isomorphism, including zero

The new images are respectively the even numbers, 1 modulo 8, 3 modulo 4, and 5 modulo 8. These are pairwise disjoint and partition all natural numbers. Each constructor is injective. The only zero constructor value is I'(0,0)=0. Since P(a,b)>=a,b, every positive constructor value strictly exceeds both children: for I', positive output implies P>=1 and multiplication by 2 is strict; the other constructors have positive offsets and multipliers at least 4. In particular R'(0,0)=1, so the literal halt number is preserved.

Define F(0)=0. For n>0 uniquely decode n=C(a,b) in the old algebra and set F(n)=C'(F(a),F(b)). The children are less than n, so this is a total recursion. The same construction in the other direction gives G. Their defining equations also hold at zero, because I(0,0)=I'(0,0)=0. Induction on positive input proves G(F(n))=n and F(G(n))=n. Thus F is a bijective constructor homomorphism on the entire carrier N, not merely on a purported subset of well-formed formula codes. It fixes 0 and 1.

This argument can equivalently be stated in normalized finite ground terms with the sole rewrite I(0,0)=0. The zero self-decomposition must be stopped explicitly; it does not introduce an additional equation or invalidate uniqueness. Every other constructor decomposition descends strictly.

## 2. Unrestricted finite proofs transport exactly

The unrestricted calculus uses 0 and 1, constructor-polynomial axiom expressions, literal numerical MP, theorem-only GEN, and equality/disequality side conditions. Apply F to every proof line and every numerical parameter. Because it is a constructor homomorphism, MP and GEN remain exact instances of those rules; every logical row and the full private bundle remain exact instances of their defining expressions. Because F is injective, every equality and disequality gate is preserved in both directions.

A parameter used both as formula and as binder/private label receives the *same* F-value in every occurrence. In particular this covers the coupled roles inside the full private bundle and R(A,B) when it is used as a binder. No independent label permutation, conventional formula decoder, substitution closure of the private theory, double-negation principle, or explosion from raw code 1 is being assumed.

The inverse G gives the reverse proof transport. Since 1 is fixed, the unrestricted old and new calculi are refutation-equivalent. These operations on finite proofs are arithmetically definable, so this is the appropriate logical bridge for the existing ZFC calibration, rather than a semantic argument about a selected external model.

## 3. Numerical domination is restored separately

It would be incorrect to transport U<=A through F. Indeed 3<4 but F(3)=5>2=F(4).

Instead, in each encoding separately, recover unrestricted rho8 from its dominated instances using the same finite symbolic certificate. Its implication operation needs only I(0,0)=0 and I(a,b)>=a,b. These both hold for I'=2P. Every dominated leaf's fourth argument is either truth 0 or an actual implication subterm of its first argument; following the exhibited subterm path proves the needed numerical inequality under every assignment. This includes all-zero assignments and intermediate implications collapsing to zero.

The certificate uses only universally quantified implicational schemas, truth, explicit schema instantiation/variable renaming, and MP. Hence its instantiations are legitimate numerical theorem instances in the new encoding. They are not arbitrary substitutions into the private bundle. Each unrestricted rho8 leaf in a transported proof can therefore be replaced by a finite new dominated proof. Doing the same in the other direction yields:

old dominated refutation <=> old unrestricted refutation <=> new unrestricted refutation <=> new dominated refutation.

The middle equivalence is the algebra isomorphism; the outer two are separate finite-certificate theorems. Their composition is valid despite the failure of order preservation.

## 4. Fresh independent finite audit

`audit_prefix_encoding_owned.py` is a new standard-library checker. It reads the certificate as inert JSON; no received repository program is imported or executed. It constructs its own canonical implication DAG, normalizes only I(T,T)=T, verifies every proof dependency refers to an earlier node, checks all explicit substitutions and MP instances, and permits only bijective first-occurrence renaming of universal schema variables when comparing conclusions.

It checks all 3,728 proof nodes and 5,160 stored term nodes, including the exact final unrestricted rho8 root 3,727. The 1,260 dominated leaves have these independently extracted witnesses:

- U=0: 224;
- U=A: 164;
- proper subterm at depth 1: 755;
- depth 2: 112;
- depth 3: 3;
- depth 4: 2.

The pinned certificate SHA-256 is `3cf18a5fe9f187b50b79d97b84535ce9bf776305728b0cdfe17285e94f028452`.

The same checker corroborates both inverse identities for the first 4,096 inputs in each direction and 4,096 constructor equations. These bounded arithmetic tests are not the universal isomorphism proof, which is the recursion/induction argument above. Receipt: `PREFIX_ENCODING_REVIEW_CHECK.json`.

## 5. Scope and remaining obligations

No mathematical gap was found in the proposal's calibration. This conclusion does not rescue its measured implementation: the worker reports a best 215 *source-subtree* count, not a 215-state table. Exact constructor implementation, simultaneous MP conversion, source compilation, physical guarded runtime verification, and blank bootstrap remain independent obligations. The original numerical-calculus/ZFC foundational comparison remains an explicitly inherited premise; this review does not claim a new proof-assistant formalization of that comparison.
