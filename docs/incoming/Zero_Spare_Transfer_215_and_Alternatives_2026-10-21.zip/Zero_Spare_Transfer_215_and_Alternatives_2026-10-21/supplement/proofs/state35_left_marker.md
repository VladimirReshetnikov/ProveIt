# A runtime-only left-marker separator at native state 35

## Exact statement

For `research214_runtime/composite_delete301_214.native.tm`, every configuration reached during an initialized source-primitive execution with native state 35 and scanned symbol 0 has a 1 at one of the seven cells immediately to the left of the head. The maximum distance 7 is attained.

This is a theorem about represented source-runtime frames, not a claim about all configurations or blank startup. The source is `research214_commands/composite_transfer_0.sites.json`.

## Complete coverage, including induction interiors

The owned symbolic runtime checker proves all 6,209 primitive guards, with arbitrary natural registers, gap, first spare value, and arbitrary finite remaining spare list. A targeted observer checks every explicit state35/read0 configuration before the kernel advances it. The completed capture contained 9,546 such symbolic entries. Each had a constant zero prefix followed by a guaranteed 1; none required a bound on an unknown affine length or an opaque list. The maximum left-marker distance was 7.

The observer is not mistaken for a literal expansion of accelerated runs. The skipped cases are covered separately:

1. Native35/0 is literally `1 R 35`. The first point of each accelerated unary run is observed. At every strictly later point of that run, the preceding iteration has just written 1 immediately to the left. Hence its left-marker distance is 1, for every natural run length.
2. Every other unary induction preserves its own state, which is not35, and therefore hides no35 visit.
3. All four finite-list traversal lemmas are rebuilt on the exact table. Every event in each one-block schema is inspected, including unary events. None has state35. Structural induction over the arbitrary list therefore hides no35 visit.

The distance-7 witness is source ordinal25, zero-CD1 at address `1101001000000`. At that entry the symbolic scanner direction is left, so the leading left-side zero run of length7 includes the current cell: six zero cells lie strictly left, followed by the marker1 at distance7.

## Genuine separation from blank startup

An independent literal replay of85 steps from the designated blank start gives state35, head7, and exactly the one-cells{-3,-2}. The nearest left1 is at distance9. Thus this particular startup configuration is excluded by the initialized-runtime invariant. This observation alone does not supply a repair.

## Targeted repair search and its limits

Only state35 contexts were widened. Exact affine-entry prefixes plus overapproximated strict unary interiors give16,722 width19 windows. Unknown suffix bits are independently expanded, so this is a cover, not a finite register sample. No whole-machine width19 closure was constructed.

The one-row search tests all856 actions obtained by choosing a write bit, direction, and one of the214 existing nonhalting target states for35/0. The modified row is used on every recurrence. A replacement must catch an exact original configuration within at most40 original steps and256 modified steps while both computations remain in the finite patch. Only the original action `1 R 35` passes every covered context.

This is a negative result for that bounded local one-row certificate family. It does not prove that a cooperative rewrite, a longer excursion, another initialized context invariant, or another blank-start construction is impossible.

## Compact independent replay

Run:

    python research215_alternatives_runtime/verify_state35_left_bound.py

The checker depends only on the pinned table/source, the native-to-legacy map, and the already owned `symbolic_runtime.py` / `independent_runtime.py` kernel. It re-proves all primitive guards, checks the induction coverage, reconstructs the width19 cover, and replays the85-step blank prefix. It does not read the119MB scratch capture.

Outputs are the compact `STATE35_BOUND_REPLAY.json` and `state35_replay_windows19.txt`. The latter must hash to `b10b76f8a4af00ffc322f6e0819c8042034c121d9c66678ccdda603d0ae5cf4e`, exactly the independently generated targeted cover. The repair search is reproduced by the owned `research215_alternatives_omit/synthesize35.cpp`; its pinned receipt is `STATE35_SYNTHESIS19.json` in that directory.

The executable mathematical checks are not represented as a proof-assistant kernel certification.
