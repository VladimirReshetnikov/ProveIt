# Independent review of the AX saved-top deletion compiler

Date: 2026-10-21.

Reviewed proposal: `research215_alternatives/AX_SAVED_TOP_DELETION_COMPILER.md`.

## Outcome

PASS for the proposed completeness transport, conditional on its two explicitly stated exact interface facts. No error was found in the GEN cleanup, zero-alias handling, arbitrary-stack strong contract, or cofinal-reset argument.

This is not yet an independent all-natural soundness approval for arbitrary AXdel inputs. The literal deleted-source semantics must show valid row/gate instances, the dominated condition U<=A, arbitrary-index theorem generalization, reset behavior, and unchanged field arities.

## Non-GEN calls

In the prior four-command strong compiler, every AX call outside GEN has incoming cache zero:

- DISCARD's preceding MP sets cache zero.
- Every retained/dominated/bundle axiom block follows DISCARD and optional J, both ending with cache zero.
- MP cleanup follows MP, which sets cache zero on either branch.

At such a call, old DROP maps (t,w,d,0) to (0,[t;w],d,0), exactly the retained-store effect of the deleted original AX push-and-clear prefix. Therefore DROP;AXdel has the full old AX effect under interface fact1. Replacing each such call transports all previous calculations literally.

## Generalization

After B_X;DROP;J(i);NIP, the state is (0,w,i,X), unless the proof block has already halted. J(0) is correctly empty because ordinary MP still has the successful zero-push alias.

With incoming top0, interface fact2 says AXdel supplies the old nine generated heads, but omits the saved zero. Its gate is zero because c=A=i. Nine NIPs yield (0,w,0,Q_i X); their tested caches are initial zero and the eight implication heads, never X. Thus X=1 is harmless at this stage.

DROP then gives (Q_i X,[0;w],0,Q_i X). One NIP tests the non1 quantifier code and removes exactly that zero, giving (Q_i X,w,0,0). The proposed NIP^9;DROP;NIP suffix is correct; using the old second final NIP would over-pop the arbitrary suffix.

The numerical alias P(0,0)=0 does not invalidate the explicit zero push/pop because unpair(P(x,v))=(x,v) holds for all natural x,v.

## Induction and enumeration

These replacements preserve the universal strong contract from every (t,w,0,0), with earlier halts allowed. Finite proof induction, the unchanged refutation suffix DROP;NIP;NIP, and initial AXdel reset therefore give completeness, provided AXdel resets d,h as asserted for all raw inputs. Unchanged command fields give unchanged predecessor-tail draining and cofinal Cantor packing.

## Soundness boundary worth retaining

The proposed quantifier index t+d is not itself a problem: theorem-only GEN permits every natural index. However, that observation alone is insufficient. If the deletion also changed the dominated row's U without changing its A compatibly, the U<=A condition could fail; if it altered logical row/gate parameters inconsistently, they would need a separate argument. The proposal correctly leaves those literal all-natural semantics as an explicit independent obligation.

No binary state count, runtime, or blank-start calibration follows from this review alone.
