# NIP;DROP;NIP has no nontrivial MP: an all-natural obstruction

Date: 2026-10-21. Exact command-level result for the unchanged AX output order. It is not a claim about an unverified binary initializer.

## Result

The command R=oldNIP;oldDROP;oldNIP is sound, and it admits useful PUSH and CLEAN macros. Nevertheless, replacing standalone NIP/DROP by this one command destroys completeness for the unchanged numerical calculus: from the clean zero seed, every successful MP produces only truth 0, and the source is provably nonhalting.

The obstruction is not the earlier ND invariant h in {0,t}; that invariant is false for R. A different adjacency invariant proves the result.

## Exact R equation

For w=[x;v], R halts if incoming h=1 or popped head x=1. Otherwise

    R(t,[x;v],d,h)=(x,v,d,t).

Thus R removes the first element of the chain [t;w], moves it into cache, and makes the old first stack head the new top. It neither swaps nor preserves top.

## An adjacency relation excluding nontrivial MP

Define E(u,v) by

    for every z, if u=I(v,z), then u=v=z=0.

In particular E(0,v) holds for every natural v, since I(v,z)=0 forces v=z=0. This uses the exact zero alias rather than excluding it.

Maintain these two properties at command boundaries:

1. E(h,t), relating cache to top.
2. Every adjacent pair in the infinite decoded chain [t;w] satisfies E. The zero suffix has all entries zero, so it also satisfies the relation.

These properties hold at the all-zero seed. They immediately imply that any successful numerical MP has t=y=h=0.

## Why every new AX adjacency satisfies E

The unchanged AX outputs top G and stack

    [R1,R2,R3,R4,R5,R6,R7,L,Q_U h,t;w].

Its cache is zero, giving E(0,G). The last link from saved t to the old head of w is exactly an old invariant link. Every other new adjacency has no MP match at all, as follows. All arguments below range over arbitrary naturals.

- G -> R1: if G=0, R1 is nonzero, so I(R1,z) cannot be zero. Otherwise G is the full bundle I(I(V,J),1), where J has quantifier tag 2. R1 is I(Q_a N E(a,b),1). For R1 to equal G's antecedent I(V,J), implication injectivity would require 1=J, impossible by its tag.
- R1 -> R2: R1's antecedent is quantifier-coded, tag 2; R2 is implication-coded, tag 0.
- R2 -> R3: R2's antecedent is quantifier-coded, tag 2; R3 has tag 0.
- R3 -> R4: R3's antecedent is equality-coded, tag 3; R4 has tag 0.
- R4 -> R5: R4's antecedent is quantifier-coded, tag 2; R5 has tag 0.
- R5 -> R6: R5's antecedent is equality-coded, tag 3; R6 has tag 0.
- R6 -> R7: write R6=I(Exists_a Q_a c,c), with the literal row's appropriate matrix parameter c. Its antecedent Exists_a Q_a c is I(Q_a N Q_a c,1). R7 is I(E(c,a),I(E(c,b),Q_(R(a,b)) E(a,b))). Equality of R7 with that antecedent would force its implication-coded consequent to equal 1, impossible. The argument is unchanged if the row is universally reparameterized to another matrix variable.
- R7 -> L: R7's antecedent has equality tag 3; L has implication tag 0.
- L -> Q_U h: L's antecedent is I(I(c,U),A), tag 0; Q_U h has tag 2.
- Q_U h -> saved t: the major itself has tag 2, whereas any I(t,z) has tag 0.

The tag statements remain true when an implication aliases raw zero. I is injective on pairs of natural arguments, including I(0,0)=0, so the consequent comparisons introduce no hidden well-formedness assumption.

## Preservation under R and MP

If R returns, its new cache/top pair is (old t,old stack head). That was an adjacent pair in the old chain, so it satisfies E. The new top/stack chain is the old chain with its first node removed, so all remaining adjacency relations hold.

If MP fails, it makes top/cache zero and leaves the stack unchanged. E(0,0) and E(0,old head) hold, and deeper links are preserved. If MP succeeds, the cache/top E relation forces t=y=h=0. The original MP then makes top/cache zero and pushes one zero. Both inserted zero links satisfy E, and deeper links are preserved. The same proof works if MP's successful zero push is omitted.

Together with the AX argument, this proves the invariant by induction over all natural candidate command sequences, with no restriction on selector/payload encodings.

## Why no halt occurs at the clean seed

Inductively, every value in top, cache, and the decoded stack differs from 1. This is true at the zero seed. AX inserts implication-coded rows, a quantifier-coded head, saved old top, and a gate that is either an implication or zero. MP only returns/pushes zero by the adjacency invariant. R merely moves existing values.

Hence neither R halt guard can see 1. Every arithmetic macro terminates, and the scheduler drains/enumerates as usual, so this source is provably nonhalting from the clean seed. It cannot implement the intended nontrivial finite-refutation compiler for the unchanged calculus and row order.

For a protected arbitrary tail, the same conclusion follows whenever the accessible prefix satisfies E and contains only non1 values, and a separately proved credit bound prevents R from exposing the tail. The existing new-tag credit theorem uses only balances R=-1, MP>=0, AX=10 and therefore supplies such a bound when its seed hypotheses hold. This does not identify the actual initializer of any new physical table.

## Why PUSH and CLEAN do not contradict the obstruction

Let D1=AX(1;0,0). Then D1;R^9 puts Q_d h on top, L in cache, and saved t above the original w. L's consequent is I(I(A,1),I(B,1)), which is nonzero, while the putative MP(0) implication I(Q_d h,0) has consequent zero. Thus MP(0) fails and

    PUSH = D1;R^9;MP(0)

returns (0,[t;w],0,0) without halting, including arbitrary incoming t=1 or h=1. PUSH;R consequently returns (t,w,0,0), or halts if t=1.

These are real structural macros. They do not create a nontrivial adjacent MP pair. The invariant explains why further attempts to preserve a selected axiom while removing the remaining generated entries cannot yield the required complete compiler without changing the AX interface, row order, or another operation.

## Scope and repair directions

The theorem uses the exact current AX order. Reordering rows can break an adjacency mismatch and must be separately analyzed; no obstruction to every possible R-based calculus is claimed. Likewise it is not a state lower bound or a nonhalting theorem for a particular unverified binary blank run. A dirty initial cache, exposed head1, or a pre-invariant physical entry can behave differently.
