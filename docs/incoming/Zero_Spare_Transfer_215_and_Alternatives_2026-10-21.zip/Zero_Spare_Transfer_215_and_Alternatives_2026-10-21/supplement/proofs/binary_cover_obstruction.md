# Why the atom-free binary-cover encoding collapses

Date: 2026-10-21. Status: ordinary finite-derivation argument. No source or physical state claim.

## Proposed algebra and precise hypothesis

Let I(a,b)=2P(a,b)+2 and Q(a,b)=2P(a,b)+3, with truth0 and designated contradictionF=1. These two injective images partition all integers >=2. Both arguments of either constructor are strictly smaller than its result. Let R,E be ANY total functions from pairs of naturals to naturals; no disjointness or special formula shape is required for this negative result.

Retain the intended full classical implicational schema family, theorem-only GEN, distribution rho2, existence rho1, both membership substitution rows rho3/rho5, ORIGINAL rho6, and every original gated seed/V bundle. Then this numerical calculus provesF, regardless of the choices of R/E. Thus simply packing everything into these two covering constructors does not yield the intended consistency search.

The assumption about full implicational strength is explicit. The old dominated certificate cannot silently be transplanted across loss of I(0,0)=0; if the proposed restricted basis fails that strength, its original calibration already requires a separate replacement proof. The theorem here refutes the intended full-strength version, not every conceivable two-constructor calculus.

## 1. The retained rows supply explosion and seriality

Write N A=I(A,F), X_i A=N Q_i N A. All equations here denote native constructors, not arithmetic equality to a Boolean value.

Original rho6 is X_i Q_i A -> A. Pure implicational K supplies F -> (Y -> F) for arbitraryY. Put Y=Q_i N Q_i A. Composing gives F->A for EVERY naturalA. Thus explosion is already a theorem of the original calculus. Together with the classical implicational basis, this licenses ordinary classical reasoning relative toF, including double-negation elimination. This fact must not be assumed when rho6 itself is replaced.

For seriality take rho1 at(i,0), setting D=E(i,0):

  Q_i(D->F) -> F.

Pure implicational K supplies F->(D->F). GEN and rho2 yield Q_iF -> Q_i(D->F). Composition proves Q_iF->F, for everyi.

## 2. Every code is a constant Boolean formula

Strong induction on the natural code gives an effective finite derivation of either A or N A.

- At0, use the truth axiom.
- At1, N1 is the identity theorem1->1.
- A positive even code>=2 uniquely decomposes as I(B,C), with smaller B,C. If C is a theorem, K yields B->C. If NB is a theorem, compose B->F with explosionF->C. In the remaining case B and NC are theorems, composition/deduction yields N(B->C).
- An odd code>=3 decomposes as Q_iB, with B smaller. If B is a theorem, use GEN. If NB is a theorem, GEN/rho2 gives Q_iB->Q_iF, and seriality gives N Q_iB.

No independent atomic generators remain. Binder indices need not be interpreted semantically: the induction only needs the matrix child to be smaller.

This dichotomy implies that Q_iA <-> A is derivable for EVERY pairi,A. If A is a theorem, so is Q_iA, and K gives both implications. If NA is a theorem, so is NQ_iA; compose these with explosion to obtain both implications. Hence quantification is eliminable on every raw code, not merely on a parsed subset.

## 3. All equality atoms and uniform membership

With quantifiers eliminable, rho1 X_a E(a,b) yields NN E(a,b), hence E(a,b). Therefore every native equality atom is a theorem.

Rho3 and rho5 now give arbitrary replacement of both membership endpoints. Thus every R(a,b) is provably equivalent to r=R(0,0). No assumption that r is numerically1 is used.

## 4. Two allowed bundles contradict one another

Use the exact original seed definitions from the report. Replace quantifiers by their proven identities and membership atoms by their proven common value r. Let x denote the actual matrix code c. In this classical calculation:

  V = r->r = truth.
  S = r->r = truth.
  B = x -> N(x -> N r).
  C = r -> N(x -> N(S -> B)).
  J = C -> N B.
  Bundle = N(V -> J).

At x=truth0 this simplifies to Bundle <-> r. At x=F1 it simplifies to Bundle <-> N r. These are routine finite classical reductions, now justified by the explosion theorem above.

Both required native instances pass the original gate:

- (a,b,c)=(1,1,0) has c different from both a,b, and its matrix is truth0. Its axiom therefore proves r.
- (a,b,c)=(0,0,1) has c different from both a,b, and its matrix is F1. Its axiom therefore proves N r.

MP provesF. This is an explicit finite-refutation construction in the metatheory, not merely failure to find an ordinary set-theoretic semantics.

## Scope

The obstruction is lack of any independent atomic generators combined with the retained logical/seed strength. It does NOT prohibit variable-length binary tags reserving separate R/E images, a genuinely different inference system, or junk-bearing constructor algebras satisfying the four-image embedding theorem.
