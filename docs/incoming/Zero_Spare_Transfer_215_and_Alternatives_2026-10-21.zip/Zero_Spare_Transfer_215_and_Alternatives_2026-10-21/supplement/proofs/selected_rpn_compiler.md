# Two-command selected-AX / automatic-stack MP

## Result

A genuinely changed two-command abstract proof machine has a complete all-natural compiler. A concrete guarded-source implementation has exactly **225 distinct source nodes and 4,996 primitive occurrences**, versus the transfer baseline's 201 nodes and 4,775 occurrences. This is a negative pricing result for this explicit implementation, not a <=215-state candidate or a physical lower bound.

The owned script `price_selected_rpn.py` only reads the inert baseline source JSON. It does not import or execute received programs. `SELECTED_RPN_PRICE.json` and `selected_rpn.sites.json` contain its exact outputs. The preliminary 223-node figure omitted the conditional removal of the saved premise on GEN; the corrected complete design costs225.

## Interface

At command boundaries use `(t,w,0,0)` for top, numerical Cantor stack, zero counter, and zero cache. Define `[a;w]=P(a,w)`. Preserve the inherited numerical calculus and all eight row families, including L's independent dominated fourth parameter U.

There are two commands:

* `A(c;u,y,x,j)`. Set A=u+x, B=y, C=c. Let v0=gate(A,B,C), v1,...,v7 be the seven retained rows, v8=L(A,B,C,u), and v9=Q_u t. For j<=9 return `(v_j,[t;w],0,0)`. For j>=10 return `(v9,w,0,0)`. Thus j>=10 is consuming GEN; j9 optionally pushes the old premise. Every numerical j has a defined sound meaning.
* `M(b)`. Unpair w=(m,v). If m=I(t,b), halt when b=1, otherwise return `(b,v,0,0)`. If equality fails, return `(0,v,0,0)`.

Unlike the old interface, A performs its own bounded row selection and removes all other generated rows. M loads and pops its major premise automatically. There is no transfer, DROP, or NIP command available to the proof compiler. A uses four fields in addition to its tag; M uses one.

All-natural soundness from an all-theorem stack is immediate: A emits axioms or theorem-only GEN and optionally saves a theorem; M either applies exact numerical MP or emits truth. The zero pairing/implication aliases cause no exception: unpair0=(0,0) and I(0,0)=0 are intentional.

## Complete compiler

For each finite dominated-calculus derivation of X construct B_X satisfying, for every natural t,w:

`(t,w,0,0) -> halt or (X,[t;w],0,0)`.

This is a completeness contract, so t and the buried w need not be theorems. Commands never inspect the unknown buried w.

1. Truth: `A(0;0,0,0,0)` has A=C=0, hence gate0, and pushes the incoming top.
2. Row R_j(a,b,c), j1..7: `A(c;0,b,a,j)`.
3. L(a,b,c,u), u<=a: `A(c;u,b,a-u,8)`.
4. Enabled bundle(a,b,c): `A(c;0,b,a,0)`.
5. GEN: execute B_X, then `A(i;i,0,0,10)`. Its gate is disabled by A=C=i; its selected value is Q_i X. Crucially j10 removes the saved X, so the final stack is the one from B_X, exactly `[t;w]`.
6. MP from M=I(A,B) and A: execute `B_M; B_A; M(B)`. Before the final command the configuration is `(A,[M,t;w],0,0)`. If B=1 it halts; otherwise it returns `(B,[t;w],0,0)`.

Every derivation of1 ends in MP because truth, the retained axioms, the bundle, and Q-values cannot be1. Hence B_1 always halts. An early halt inside a premise block is also sufficient. This proves completeness for every finite derivation, with no size bound and including raw-zero aliases.

The two tags are M=0 and A(c)=c+1. Actual field orders are M: `[0,b]`; A: `[c+1,u,y,x,j]`. Cantor packing uses the same decrement-before-next-command scheduler. Each residual right projection is bounded by its input, so every nonhalting candidate drains. Cofinal successful candidates follow by prefixing B_1 with `A(0;0,Y,0,0)` and varying Y. This prefix has gate0, leaves counter/cache0, and creates only a new arbitrary top/stack for the strong B_1 contract; its packed integer is at least Y.

## Concrete source construction and cost

Start with the literal transfer201 source. Replace its three-way dispatch by a single decrement on selector3: zero goes to M, positive goes to A with c=selector-1.

A:

1. Read an additional u field into zero register4, using the existing selector reader with register3 renamed4.
2. Copy incoming top1 to zero cache5.
3. Run the existing AX prelude through Q_U h, now Q_u t. Immediately clear cache5 before the remaining AX field-reader/body, so its B parameter is y rather than t+y. Preserve the original independent U and dominated A=u+x.
4. Remove only AX's final old branch-escape CB1; do not alter its gate arithmetic.
5. Read j into selector3 after the original AX body clears its temporaries.
6. Execute nine copies of a closed round: clear cache5; unpair stack2 into cache5; if selector3 is positive, decrement it, clear top1, and copy cache5 to top1. The nine rounds are represented using doubled 2/4/8 subtrees and one final round.
7. If selector3 remains positive (original j>=10), decrement it and pop the saved incoming top without changing selected top. Finally clear selector3 and cache5.

After j rounds the selected top stops changing; later rounds only remove unwanted generated heads. For j>=9 the ninth selected value is Q_u t. Step7 is necessary for consuming GEN and costs two extra distinct source nodes in this assembly.

M:

1. Pop one original stack head into zero cache5.
2. Run existing MP with its success dummy-zero PUSH removed.
3. On the success arm only, after copying the conclusion to top, run the existing halt-if-cache1 test with register5 renamed4, hence testing the successful conclusion b. It may destroy counter4 but preserves top1.
4. Clear counter4 on all returning paths. The old equality branch already clears cache5.

The isolated A body has198 distinct nodes /4856 occurrences and no escaping break/continue/halt. M has85 distinct nodes /115 occurrences, no escaping break/continue, and an intended halt. The complete source has225 nodes /4996 occurrences and no escaping break/continue. These are exact tree/DAG counts, not provisional physical-state counts.

## Unclosed implementation obligations

The source splice is based on the inherited closed-macro arithmetic contracts and the literal reader ordering. Its generated control boundary calculation is checked, but no new complete symbolic source execution certificate or physical allocation was performed. In particular, the AX prelude splice and the post-AX zero-selector invariant should be independently checked before treating the emitted source as calibrated implementation evidence. The abstract compiler does not depend on that unperformed check.

The old 215-state machine's blank initializer does not reach an all-zero abstract store. No transport of its partial-AX startup or old protected-stack-credit theorem to the new scheduler is claimed. Thus this artifact is not a new blank-start binary consistency machine even apart from its unattractive source price.

## Fused transfer/inference alternative

A second considered map was F(y)(t,[x;w],d,h) = `(y,w,d+y,x)` when x=I(h,d+y), otherwise `(h,w,d+y,x)`, halting only on successful conclusion1. It genuinely combines stack exposure and MP. The literal old H cleanup is not universally valid: for example, choosing a head I(h,0) with nonzero h makes a y0 step return0 instead of h. This does NOT prove the interface incomplete: compiler-known heads, zero separators, and tracked counters may repair the compiler. No complete such compiler or calibrated exact source was obtained in this lane. Retaining both old cache and popped head through the destructive equality comparison also creates a concrete extra-storage requirement absent from old MP. This remains an honestly unclosed alternative, not a negative theorem.
