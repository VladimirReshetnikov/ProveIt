# Complete four-leaf prefix families and source-association follow-up

Date: 2026-10-21. No new <=215-state machine is established.

## Exact encoding scope

Every complete ordered binary prefix tree with four leaves has depth at most3; there are exactly five such tree shapes. Read prefix bits least-significant-bit first. In each tree the unique all-zero leaf must label I (tag0), and the unique leaf with value1 must label R (tag1). Assign Q,E to the two remaining leaves in either order. This gives exactly ten codings of the required complete-prefix kind, not a claim about all arithmetic encodings.

Each constructor has form2^d P(a,b)+tag. Its canonical residue class is disjoint from the other three, the classes coverN, each constructor is injective, onlyI(0,0)=0, every positive output dominates both children, andR(0,0)=1. The same ground-term isomorphism and separate dominated-rho8 certificate argument used in BINARY_PREFIX_Q_PRIORITY.md applies to all ten. The independent Q-priority algebra/certificate review is at ../research215_alternatives_calibration/Q_PRIORITY_PREFIX_INDEPENDENT_REVIEW.md; a new binary table does not follow from that review.

## Complete-tag scan, bounded source implementations

price_all_binary_prefixes.py checks all ten codings with eighteen rebuilt macro associations each. ALL_BINARY_PREFIX_PRICES.json records180 implementations. The unchanged original encoding control prices205 source nodes, revealing the exact four-node penalty caused by whole-constructor isolation. Uniform Q/E swap also prices205 in this implementation. The eight nonuniform codings have minima213 or215. Those are implementation measurements, not lower bounds.

To remove that artificial penalty, price_prefix_preserving.py changes only closed scale loops and distributes additional tag increments among existing tag leaves while preserving their surrounding source AST. It checks513 distinct edit configurations across the same ten codings. Every retained exterior edge and every replacement's local CFG are checked. PREFIX_PRESERVING_PRICES.json confirms the unchanged control is exactly201 nodes. The direct Q-priority implementation improves to214 nodes. Best nonuniform source remains213. No nonuniform candidate reaches the original201-node source.

## Uniform Q/E swap and exact tag skeletons

The uniform code I=4P,R=4P+1,Q=4P+3,E=4P+2 is a genuinely different but calibrated numerical encoding. A further source-preserving scan tries both global Q-tag insertion orientations and all3^6 independent choices of which old E-tag increment to delete. All1458 configurations are counted. Minimum202 occurs128 times but those minimizers collapse to exactlyTWO distinct complete ASTs, the two global Q orientations. Their exact words and full CFGs are checked.

SWAP_QE_SKELETON_PRICES.json contains unique_count=2 and the corresponding SHA256 values. They are saved as swap_qe_unique_00_202.sites.json and swap_qe_unique_01_202.sites.json. The earlier first16 exported skeletons were duplicates of orientation0; no claim of sixteen distinct candidates remains.

Independent role permutations of all seven logical rows were then enumerated for each of these two ASTs:2*6^7=559,872 exact configurations. SWAP_QE_JOINT_ROW_PRICES.json records a202-node minimum, with four minima per orientation. Physical worker pricing covered all eight, deduplicating the unchanged orientations. Its separate research215_alternatives_qe/QE_JOINT_PRICES.json reports protected allocations219 or221 states, not215.

## All22 Q orientations, not just global orientations

Holding the optimal E skeleton fixed, the exact mixed-orientation scan covers ALL2^22=4,194,304 independent Q-tag insertion orientations. It finds minimum202 at exactly two assignments, all-left and all-right. Thus mixed Q association alone cannot supply the hoped-for201-node source on this fixed E skeleton.

The owned catalog proves its cost formula structurally. Fixed and single-Q-dependent subtrees form176 interned known nodes. There are44 mixed-Q-dependent source nodes. Their possible primitive words are disjoint from all known-node words; only one pair of mixed nodes can have equal words. That pair depends on only four Q choices, so its exact structural equality is resolved by a16-entry truth table. The complete DAG count is therefore the bit-union cardinality of selected known subtrees, plus44, minus that single equality indicator. There is no additive-independence assumption.

Owned C++ enumeration checks the resulting exact formula on all4,194,304 assignments. An independent full nested-AST reconstruction agrees on224 controls/random assignments, including both extrema and all single flips. Files:

- catalog_q_orientation.py and Q_ORIENTATION_CATALOG.json
- emit_q_orientation_search.py and q_orientation_search.cpp
- Q_ORIENTATION_COUNT_PROOF.json
- ALL_Q_ORIENTATION_PRICES.json
- check_q_orientation_catalog.py and Q_ORIENTATION_CATALOG_CHECK.json

This exhaustive22-choice result is conditional on the selected E skeleton. It does not claim exhaustion over jointly varied E skeletons, arbitrary source associations, arithmetic implementations, physical allocator choices, or other numerical encodings.

## Corrections and limitations

The old modal-B theorem-set claim was withdrawn after its hidden use of unconditional native DNE was found. Its countermodel does not settle equiconsistency. MODAL_B_RELATIVE_TRANSLATION_STATUS.md proves the available regular-fragment facts and identifies the remaining subset-polarity/private-code obligations; refutation calibration remains open.

The prefix search uses the unchanged originalrho6 and is unaffected by that correction. It identifies all81 literal constructor applications, including the split secondQ in rho4:41I,22Q,12R,6E. The discrepancy with a prior upstream42I/21Q count is being separately reviewed. No received program was executed by these owned builders or checkers.
