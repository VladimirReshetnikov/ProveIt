# New source/formalism alternatives after transfer-pop215

This pass tested genuinely changed command or parser designs, plus a new bounded MP assembly family. It found no new candidate at215 states or below. Counts below are source-DAG counts, not automatic physical lower bounds; quoted physical prices are provisional allocations unless a separate runtime audit says otherwise. No received executable was run.

## 1. AX without saving the incoming top

The earliest AX macro is the26-leaf PUSH19 followed by copy-counter-to-top7. Removing PUSH alone does **not** implement ordinary AX with just one fewer stack entry: PUSH also clears top. The literal deletion leaves incoming top t in R1, so its first copy produces t+d; the following constructor emits Q_(t+d)(h), rather than Q_d(h). The other parameter registers are not changed by this edit. The parent's independent compiler handles this altered GEN output by ensuring top0 where necessary.

- Replacing PUSH by the2-leaf clearTop macro, then retaining the copy:205 source nodes,218 allocated states, on both verified original215 layouts.
- Clearing through scratch6 or a zero-scratch guard:206–207 nodes,219–220 states.
- Literal PUSH deletion:204 nodes,217 states on each original215 layout.
- All132 associations of the seven AX prelude/tail factors, on each literal-deletion source: exact complete guarded CFG preserved in all cases; minimum204 nodes.

Receipts: `AX_NO_SAVED_TOP_PRICES.json`, `AX_ADDITIVE_GEN_PRICES.json`, `AX_ADDITIVE_GEN_ASSOCIATIONS.json`. Owned programs: `price_ax_saved_top.py`, `price_ax_additive_gen.py`, `associate_ax_additive_gen.py`.

## 2. Longer guarded transfer commands

Replace transfer D;N;N by D;N^k, retaining the old closed DROP D and NIP N. Normally this puts old cache on top, removes k-1 original stack heads, and caches the last removed head. Additional existing falsity tests remain sound. Completeness is not assumed from this normal equation.

All Catalan associations were source-priced:5 for k3,14 for k4,42 for k5, and1,430 for k8. Minima:

- k3 and k4:202 source nodes,216 states from the protected transfer215 allocation.
- k5 and k8:203 source nodes,217 states.

All best k3/k4 layouts, and bounded representatives of the larger tied minima, were allocated. Receipt: `MULTIPOP_PRICES.json`; program: `price_multi_pop.py`.

## 3. A common additive field before three-command dispatch

Move MP's14-leaf field reader to before dispatch. MP remains MP(x); transfer becomes S(x), which first adds x to the counter; AX gains a common z field, with U=d+z. Known compiler blocks can set the extra S/AX field to zero, but no complete new runtime is claimed here. This moves an existing reader rather than simply duplicating it.

Five top associations for each of the two small-command tag orders all cost204 source nodes. Best allocation is218 states. Receipt: `COMMON_FIELD_TRANSFER_PRICES.json`; program: `price_common_field_transfer.py`.

## 4. Dirty-counter AX field reader

This implements the independently documented dirty-unpair idea on the current transfer source. Move the ordinary Y read before the partial copy of old counter U. Omit the counter-restoration loop, leaving R6=U and R4=0. Read X before the following implication constructor, so the reader consumes P(U,0)+rawPayload, returns its first projection into R4, and clears scratch before arithmetic resumes. The saved U remains the intended fourth argument of the implicational row.

The nine-factor reconstruction includes the complete unchanged tail. All1,430 associations were source-priced; minimum206 nodes. Five saved minimizers have the same guarded CFG as the independently reconstructed new schedule and pass both CFG resolvers. Physical allocation was not pursued. The older dirty-reader calibration supports the arithmetic idea; exact current compiler/runtime composition remains a separate obligation.

Receipt: `DIRTY_TRANSFER_PRICES.json`; program: `price_dirty_transfer.py`.

## 5. Direct MP implication arithmetic

Current MP pushes old top onto the formula stack, copies counter y to top, then immediately unpairs that saved top to compute I(oldtop,y). The replacement avoids this stack round trip:

1. Move R1 to R6, clearing R1.
2. Copy R4 to R1 using R7 as restoration scratch; this leaves R6 untouched and restores R4.
3. Run the complete existing16-leaf Cantor-plus-scale core.

Its output is exactly I(oldtop,y); the stack and unrelated registers are unchanged, and both arithmetic scratches are zero. The variant using selector register R3 as restoration scratch has the same contract when R3 initially0, as it does on the selected MP branch. Each implementation passes81 owned finite arithmetic checks with unrelated nonzero registers. The uniform justification is composition of the move, duplicate/restore, and complete Cantor-core contracts, not the finite test alone.

This saves27 primitive leaves but loses DAG sharing. For each scratch choice, both original four-command and transfer baselines, and both retaining/omitting MP's dummy push, all132 seven-factor associations were source-priced:

- Transfer source: minimum210 nodes.
- Original four-command source: minimum211 nodes.

No physical table was allocated for these large source prices. Receipts: `DIRECT_MP_PRICES.json`, `DIRECT_MP_SCRATCH3_PRICES.json`; programs: `price_direct_mp.py`, `price_direct_mp_scratch3.py`.

## 6. Dual MP/AX with unchanged NDN

Rename register1↔5 only within MP and AX, leaving the NDN command and scheduler literal. This is the audit worker's new dual interface, not the earlier incomplete unchanged-MP/AX NDN design. The source check confirms unchanged control flow, only intended register operands changed, and exact unchanged NDN.

The two201-node NDN layouts become219 nodes; the layout exposing firstCI6 becomes220 nodes. Physical allocation was not attempted. Receipt: `DUAL_NDN_PRICES.json`; program: `price_dual_ndn.py`.

## 7. Expanded omitted-MP source associations

The runtime worker's clean omitted-MP table costs216 and differs from protected215 in only100/1 plus fresh313=(0R77,1R114). Beyond its earlier11 local rotations and two root associations, this pass enumerated every binary assembly of eight MP factors:

read/unpair11; move field to counter3; PUSH19; copy counter7; implication27; move top to scratch3; equality test10; success copy7.

There are429 associations. A second429-place family moves PUSH before the complete field-reading operation. Those closed operations have disjoint live-register effects and begin/end with zero scratches, so this is a real primitive-order change with the same MP map. Every association is checked against the complete CFG of its respective fixed-order reference.

Results across858 assemblies:

- 5 layouts:201 source nodes,216 states.
- 9 layouts:202 nodes,217 states.
- 28 layouts:203 nodes,218 states.
- 90 layouts:204 nodes,219 states.
- 726 layouts:205 nodes,220 states.

All five best tables were saved and independently passed literal source-prefix binding. Arithmetic protection26 is inherited from the protected allocation. The exhaustive pricing stage skipped final prefix validation for unretained rows; it did not label those rows verified. Full binary runtime is separate.

Receipt: `MP_FINE_FACTOR_ASSEMBLIES.json`; program: `price_mp_fine_factor_assemblies.py`. The earlier coarser264-layout screen forced the14-leaf field reader to remain an indivisible subtree and therefore lost existing sharing; its minimum219 is not the best result for this broader family.

## 8. Consume the MP counter on success

Replace successful MP's7-leaf counter copy by the3-leaf move R4→R1. Failure is unchanged at(0,w,y,0); success without the dummy push becomes exactly(y,w,0,0), simplifying proof-block cleanup.

Two MP root associations were priced with and without the dummy push. Retaining it costs203 nodes/218 states; omitting it costs202/217. This is a new command equation, but not a competitive state reduction. Receipt: `MP_CONSUME_COUNTER_PRICES.json`; program: `price_mp_consume_counter.py`.

## Scope

These are bounded negative results for explicitly described source families. They are not a proof that214 states is impossible. The five216-state omitted-MP layouts are the closest source/layout handoff from this pass; the physical/runtime worker has them. Other prototypes are retained as source-level evidence, not presented as validated machines.
