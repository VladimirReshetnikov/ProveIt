"""Owned literal-word witness for a received constructor translation gap."""
from pathlib import Path
import json,sys,hashlib
ROOT=Path(__file__).resolve().parent.parent
import argparse,os
if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'): raise RuntimeError('Assertions must be enabled')
ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args();OUT=args.work;OUT.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(ROOT/'checks'))
from source_utils import tree,flatten,leaf
R=OUT;D=ROOT
A=json.loads((ROOT/'inputs/prior215.sites.json').read_text());B=json.loads((ROOT/'inputs/rejected_swap_Q_E.sites.json').read_text());mac=json.loads((ROOT/'inputs/macros215.json').read_text())
def tup(x):return tuple(map(tup,x))if isinstance(x,list)else x
M={k:tup(v)for k,v in mac.items()};W=[tuple(r[1:])for r in A]
def word(t):return [tuple(r[1:])for r in flatten(t)]
Q=word(M['Q']);I=word(M['I']);assert len(Q)==29 and len(I)==27 and Q==I+[('CI',1),('CI',1)]
def census(w,tags):
 out=[];i=0
 while i<len(w):
  for k,j in sorted(tags.items(),key=lambda x:-x[1]):
   v=I+[('CI',1)]*j
   if w[i:i+len(v)]==v:out.append((i,i+len(v),k));i+=len(v);break
  else:i+=1
 return out
oldc=census(W,{'I':0,'R':1,'Q':2,'E':3})
spans=[(i,j)for i,j,k in oldc if k=='Q'];assert len(spans)==22
AT=tree(A);sub={};
def go(t,p,lo):
 n=len(word(t));sub[lo,lo+n]=(p,t)
 if not leaf(t):go(t[0],p+'0',lo);go(t[1],p+'1',lo+len(word(t[0])))
go(AT,'',0)
miss=[(a,b)for a,b in spans if (a,b)not in sub or sub[a,b][1]!=M['Q']];assert len(miss)==1
lo,hi=miss[0];assert (lo,lo+27)in sub and sub[lo,lo+27][1]==M['I'];ip=sub[lo,lo+27][0]
# Incoming builder replaces I by the exact same I under swap_Q_E and does not isolate this Q.
# Equality-only normalization changes paths but leaves the primitive word exactly fixed.
# Verify the same three-part output remains in the purported new source by its local semantic context.
BW=[tuple(r[1:])for r in B];newc=census(BW,{'I':0,'R':1,'Q':3,'E':2});assert len(oldc)==len(newc)==81
wrong=[(i,a,b)for i,(a,b)in enumerate(zip(oldc,newc))if a[2]!=b[2]];assert len(wrong)==1
idx,a,b=wrong[0];assert a==(lo,hi,'Q')and b[2]=='E';j=b[0]
# Context includes both operands already on formula stack; no extra increment follows.
assert W[hi:hi+26]==BW[j+29:j+55]
out={'commit':'b74074eacb936164d85e0f1aea5a8254412ade48','archive':'docs/incoming/zfc214-research.zip','builder':'code/build_constructor_variants.py','source':'data/constructor-variants/swap_Q_E.json','source_sha256':hashlib.sha256((ROOT/'inputs/rejected_swap_Q_E.sites.json').read_bytes()).hexdigest(),'old_source_sha256':hashlib.sha256((ROOT/'inputs/prior215.sites.json').read_bytes()).hexdigest(),'old_Q_intervals':spans,'missed_old_Q_interval':[lo,hi],'missed_I_interval':[lo,lo+27],'missed_I_source_path':ip,'new_wrong_Q_interval':[j,j+29],'old_Q_macro_word':Q,'expected_constructor':'Q_new(a,b)=4P(a,b)+3','actual_constructor':'4P(a,b)+2=E_new(a,b)','specific_assignment':{'a':0,'b':0,'expected':3,'actual':2},'remaining_26_primitive_context_equal':True,'advertised_215_dependency':'None identified. This rejected-target research packet supplies source-only changed-constructor experiments. Its runtime-only214 uses unchanged17af source and already fails blank startup. All inspected current215 primary/secondary machines retain the native4P tags; none uses these swapped/prefix/nested sources.','scope':'Exact literal source arithmetic mismatch, not a failure of the abstract finite-proof junk-code theorem or of unrelated215 tables.'}
(R/'CONSTRUCTOR_TRANSLATION_MISMATCH.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items()if k not in ['old_Q_macro_word','old_Q_intervals']})

expected=json.loads((ROOT/'evidence/CONSTRUCTOR_TRANSLATION_MISMATCH.json').read_text())
assert json.loads(json.dumps(out))==expected
print('CONSTRUCTOR_MISMATCH_REPLAY_PASS')
