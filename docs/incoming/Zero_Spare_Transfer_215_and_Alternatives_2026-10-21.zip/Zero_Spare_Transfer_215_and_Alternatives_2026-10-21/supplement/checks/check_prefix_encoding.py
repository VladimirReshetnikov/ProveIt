"""Independent standard-library checker: input certificates are inert JSON only."""
from pathlib import Path
from functools import lru_cache
from math import isqrt
import json, hashlib, collections
import argparse, sys, os
if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'): raise RuntimeError('Assertions must be enabled')
ROOT=Path(__file__).resolve().parent.parent
ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args()
OUT=args.work;OUT.mkdir(parents=True,exist_ok=False)
path=ROOT/'inputs/dominated_rho8_full_certificate.json'
c=json.loads(path.read_text())
# Build our own normalized symbolic implication algebra, never numeric giant terms.
D=[]; ids={}
def add(x):
 if x not in ids: ids[x]=len(D); D.append(x)
 return ids[x]
T=add(('T',))
def imp(a,b): return T if a==b==T else add(('I',a,b))
def var(n): return add(('v',n))
def split(i):
 if i==T:return T,T
 x=D[i]; assert x[0]=='I'; return x[1:]
terms=[]
for x in c['term_table']:
 if x=='T': z=T
 elif isinstance(x,dict):
  assert set(x)=={'var'} and type(x['var']) is int and x['var']>=0
  z=var(x['var'])
 else:
  assert type(x) is list and len(x)==2 and all(type(a) is int and 0<=a<len(terms) for a in x)
  z=imp(*(terms[a] for a in x))
 terms.append(z)
@lru_cache(None)
def depth(a,u):
 if a==u:return 0
 x=D[a]
 if x[0]!='I':return None
 ds=[z for v in x[1:] if (z:=depth(v,u)) is not None]
 return min(ds)+1 if ds else None
def instantiate(n,m):
 subst={int(k):terms[v] for k,v in m.items()}
 @lru_cache(None)
 def go(t):
  x=D[t]
  if x[0]=='T':return T
  if x[0]=='v':return subst.get(x[1],t)
  return imp(go(x[1]),go(x[2]))
 return go(n)
def canonical(n):
 mapping={}
 @lru_cache(None)
 def go(t):
  x=D[t]
  if x[0]=='T':return T
  if x[0]=='v':
   if x[1] not in mapping:mapping[x[1]]=len(mapping)
   return var(mapping[x[1]])
  return imp(go(x[1]),go(x[2]))
 return go(n)
proof=[];counts=collections.Counter(); witnesses=collections.Counter()
for n in c['nodes']:
 assert n['id']==len(proof)
 target=terms[n['term']];r=n['rule'];k=r['kind'];counts[k]+=1
 def previous(field):
  j=r[field];assert type(j) is int and 0<=j<len(proof);return proof[j]
 if k=='truth':assert target==T
 elif k=='dominated_rho8':
  left,right=split(target);cu,a=split(left);cc,u=split(cu)
  ac,bc=split(right);aa,ccc=split(ac);b,cccc=split(bc)
  assert a==aa and cc==ccc==cccc
  witness='zero' if u==T else depth(a,u)
  assert witness is not None
  witnesses[str(witness)]+=1
 elif k=='substitution':assert canonical(instantiate(previous('parent'),r['substitution']))==canonical(target)
 elif k in ('mp','mp_substitution'):
  major=previous('major');minor=previous('minor')
  if k=='mp_substitution':
   major=instantiate(major,r['major_substitution']);minor=instantiate(minor,r['minor_substitution'])
  premise,conclusion=split(major)
  assert premise==minor and canonical(conclusion)==canonical(target), n["id"]
 else:raise AssertionError(k)
 proof.append(target)
a,b,cc,u=(var(i) for i in range(4))
expected=imp(imp(imp(cc,u),a),imp(imp(a,cc),imp(b,cc)))
assert c['roots']['rho8']==3727 and proof[3727]==expected
# Independent bounded arithmetic corroboration of the universal recursive isomorphism.
def P(a,b):return (a+b)*(a+b+1)//2+b
def unpair(n):
 s=(isqrt(8*n+1)-1)//2;b=n-s*(s+1)//2;return s-b,b
def new(tag,a,b):return (2,8,4,8)[tag]*P(a,b)+(0,1,3,5)[tag]
def decnew(n):
 if n%2==0:return 0,*unpair(n//2)
 if n%4==3:return 2,*unpair((n-3)//4)
 if n%8==1:return 1,*unpair((n-1)//8)
 assert n%8==5;return 3,*unpair((n-5)//8)
@lru_cache(None)
def F(n):
 if n==0:return 0
 p,tag=divmod(n,4);a,b=unpair(p);assert a<n and b<n
 return new(tag,F(a),F(b))
@lru_cache(None)
def G(n):
 if n==0:return 0
 tag,a,b=decnew(n);assert a<n and b<n
 return 4*P(G(a),G(b))+tag
for n in range(4096):assert G(F(n))==n and F(G(n))==n
for a in range(32):
 for b in range(32):
  for tag in range(4):assert F(4*P(a,b)+tag)==new(tag,F(a),F(b))
assert F(0)==0 and F(1)==1
nonmonotone=next(({'a':a,'b':a+1,'F(a)':F(a),'F(b)':F(a+1)} for a in range(4095) if F(a)>F(a+1)),None)
r={'status':'PASS','scope':'Full symbolic rho8 certificate replay, all leaf domination witnesses, plus bounded corroboration of separately proved all-natural prefix algebra isomorphism. No source/runtime/blank audit.', 'certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'proof_nodes':len(proof),'source_term_nodes':len(terms),'rules':dict(counts),'domination_witness_counts':dict(witnesses),'root_rho8':3727,'isomorphism_inverse_checks_each_direction':4096,'constructor_identity_checks':32*32*4,'fixed_truth_and_falsity':True,'nonmonotonicity_witness':nonmonotone}
(OUT/'PREFIX_ENCODING_REVIEW_CHECK.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))

assert r==json.loads((ROOT/'evidence/PREFIX_ENCODING_REVIEW_CHECK.json').read_text())
