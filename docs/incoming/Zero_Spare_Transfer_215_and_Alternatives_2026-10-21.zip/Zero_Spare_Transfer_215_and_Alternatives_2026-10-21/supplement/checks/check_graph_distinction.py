#!/usr/bin/env python3
"""Owned deterministic graph comparisons on nineteen inert pinned tables.
Uses each table's declared start, including both append-zero tables at74.
"""
from pathlib import Path
from collections import deque
import json,hashlib,itertools,sys,os,argparse
def read(p):
    t = {}
    start = 0
    for s in p.read_text().splitlines():
        if s.startswith('#! start'):
            start = int(s.split()[-1])
            continue
        if not s.strip() or s.startswith('#'):
            continue
        q, a, b, d, z = s.split()
        key = (int(q), int(a))
        assert key not in t
        t[key] = (int(b), d, int(z))
    Q = {q for q, a in t}
    assert len(Q) == 215 and len(t) == 430 and all(((q, a) in t for q in Q for a in (0, 1)))
    assert {z for b, d, z in t.values()} - Q == {254}
    seen = {start}
    todo = [start]
    for q in todo:
        if q == 254:
            continue
        for a in (0, 1):
            z = t[q, a][2]
            if z not in seen:
                seen.add(z)
                todo.append(z)
    assert seen == Q | {254}
    return (t, start)

def compare(a, b):
    A, x = T[a]
    B, y = T[b]
    f = {x: y}
    g = {y: x}
    todo = deque([(x, y, '')])
    while todo:
        q, r, word = todo.popleft()
        if q == 254 or r == 254:
            if q != r:
                return dict(isomorphic=False, word=word, reason='halt mismatch')
            continue
        for v in (0, 1):
            w, d, s = A[q, v]
            w2, d2, t = B[r, v]
            if (w, d) != (w2, d2):
                return dict(isomorphic=False, word=word + str(v), reason='write/direction mismatch', left=[q, v, w, d, s], right=[r, v, w2, d2, t])
            if s in f:
                if f[s] != t:
                    return dict(isomorphic=False, word=word + str(v), reason='forced map not functional')
            elif t in g:
                return dict(isomorphic=False, word=word + str(v), reason='forced map not injective')
            else:
                f[s] = t
                g[t] = s
                todo.append((s, t, word + str(v)))
    assert len(f) == 216 and f[254] == 254
    assert all((B[f[q], v] == (w, d, f[s]) for (q, v), (w, d, s) in A.items()))
    return dict(isomorphic=True, map=f)

def main():
 global T
 if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'): raise RuntimeError('Assertions must be enabled')
 root=Path(__file__).resolve().parent.parent
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args();out=args.work;out.mkdir(parents=True,exist_ok=False)
 pins=json.loads((root/'evidence/COMPARISON_INPUTS.json').read_text())
 old=json.loads((root/'evidence/LATEST_EXACT_GRAPH_COMPARISON.json').read_text())
 assert len(pins)==19 and set(pins)==set(old['tables'])
 T={}
 for name,pin in pins.items():
  p=root/pin['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256']
  assert pin['sha256']==old['tables'][name]['sha256'] and pin['original_path']==old['tables'][name]['path']
  T[name]=read(p);assert T[name][1]==pin['start']
  assert sum(v[0]for v in T[name][0].values())==pin['one_writing_rows']
 comparisons={a+'__'+b:compare(a,b)for a,b in itertools.combinations(T,2)}
 assert json.loads(json.dumps(comparisons))==old['comparisons']
 # Two newly completed layouts are kept separate from the19-table snapshot.
 extra=json.loads((root/'evidence/REPARSE_GRAPH_COMPARISON.json').read_text())
 assert set(extra['tables'])==set(T)|{'zero_spare_secondary','zero_spare_reparse'}
 for name in ('zero_spare_secondary','zero_spare_reparse'):
  p=root/'comparison_inputs'/(name+'.native.tm');pin=extra['tables'][name]
  assert hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256']
  T[name]=read(p);assert T[name][1]==pin['start']==74
 for name in pins:assert extra['tables'][name]['sha256']==pins[name]['sha256'] and extra['tables'][name]['start']==pins[name]['start']
 actual={name:compare('zero_spare_reparse',name)for name in T if name!='zero_spare_reparse'}
 assert json.loads(json.dumps(actual))==extra['reparse_comparisons']
 assert all(not x['isomorphic']for x in actual.values())and len(actual)==20
 assert compare('zero_spare_transfer','zero_spare_secondary')==json.loads((root/'evidence/SECONDARY_GRAPH_COMPARISON.json').read_text())
 target='zero_spare_transfer'
 assert all(not compare(target,n)['isomorphic'] for n in pins if n!=target)
 assert pins['transfer215']['one_writing_rows']==190
 assert pins['zero_spare']['one_writing_rows']==188
 assert pins[target]['one_writing_rows']==189
 result={'status':'EXACT_GRAPH_COMPARISON_PASS','pinned_tables':19,'additional_completed_layouts':2,'additional_reparse_comparisons':20,'pairwise_comparisons':171,'target_nonisomorphic_to':18,'true_designated_starts_used':True,'one_writing_rows':{n:pins[n]['one_writing_rows']for n in ('transfer215','zero_spare','zero_spare_transfer')},'scope':'Start/read/write/direction/halt-preserving graph isomorphism. Three differing write-one counts also rule out unrooted state renaming and global tape reflection between the two parents and new composition. The separate93-member archived audit is not re-retrieved by this checker.'}
 (out/'GRAPH_COMPARISON_REPLAY.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
