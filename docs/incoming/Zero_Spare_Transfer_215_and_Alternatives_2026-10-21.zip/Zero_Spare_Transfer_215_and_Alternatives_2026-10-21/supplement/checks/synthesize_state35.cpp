// Owned exact one-row35/0 catch-up over a supplied sound width19 cover.
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <array>
#include <algorithm>
#include <string>
using namespace std;
struct A{int w,d,z;bool operator==(const A&o)const{return w==o.w&&d==o.d&&z==o.z;}};
struct P{int q,h,x;bool operator==(const P&o)const{return q==o.q&&h==o.h&&x==o.x;}};
A t[512][2];bool valid[512];vector<int>qs,xs;int K=9;long long steps=0;
P step(P p,A a){p.x=(p.x&~(1<<(p.h+K)))|(a.w<<(p.h+K));p.h+=a.d;p.q=a.z;steps++;return p;}
int main(int argc,char**argv){if(argc!=3)return 2;ifstream in(argv[1]);string line;while(getline(in,line)){if(line.empty()||line[0]=='#')continue;istringstream s(line);int q,b,w,z;char d;s>>q>>b>>w>>d>>z;t[q][b]={w,d=='R'?1:-1,z};valid[q]=true;}for(int q=0;q<512;q++)if(valid[q])qs.push_back(q);ifstream win(argv[2]);int q,x;while(win>>q>>x){if(q!=35||x<0||x>=(1<<19)||((x>>9)&1))return 3;xs.push_back(x);}if(xs.empty())return 4;
 vector<vector<P>> goals;for(int x:xs){P p={35,0,x};vector<P>g;for(int k=0;k<40;k++){if(p.h<-K||p.h>K||!valid[p.q])break;p=step(p,t[p.q][(p.x>>(p.h+K))&1]);g.push_back(p);}goals.push_back(g);}
 cout<<"CONTEXTS "<<xs.size()<<" OLD40 NEW256\n";int best=-1,hits=0;vector<array<int,5>>near;
 for(int w=0;w<2;w++)for(int d:{-1,1})for(int z:qs){A a={w,d,z};int passed=0,maxlen=0;for(int i=0;i<(int)xs.size();i++){P p={35,0,xs[i]};vector<P>seen;bool good=false;for(int k=1;k<=256;k++){if(p.h<-K||p.h>K||!valid[p.q])break;int b=(p.x>>(p.h+K))&1;p=step(p,(p.q==35&&b==0)?a:t[p.q][b]);if(find(goals[i].begin(),goals[i].end(),p)!=goals[i].end()){good=true;maxlen=max(maxlen,k);break;}if(find(seen.begin(),seen.end(),p)!=seen.end())break;seen.push_back(p);}if(!good)break;passed++;}
 cout<<"ACTION "<<w<<" "<<d<<" "<<z<<" PASSED "<<passed<<" FAILED "<<(passed<(int)xs.size()?xs[passed]:-1)<<" MAXLEN "<<maxlen<<"\n";
 if(passed==(int)xs.size()){hits++;cout<<"HIT "<<w<<" "<<d<<" "<<z<<" MAXLEN "<<maxlen<<" ORIGINAL "<<(a==t[35][0])<<"\n";}
 if(passed>best){best=passed;near.clear();}if(passed==best)near.push_back({w,d,z,passed,passed<(int)xs.size()?xs[passed]:-1});}
 cout<<"SUMMARY "<<hits<<" BEST "<<best<<" STEPS "<<steps<<"\n";for(auto a:near)cout<<"NEAR "<<a[0]<<" "<<a[1]<<" "<<a[2]<<" "<<a[3]<<" "<<a[4]<<"\n";
}
