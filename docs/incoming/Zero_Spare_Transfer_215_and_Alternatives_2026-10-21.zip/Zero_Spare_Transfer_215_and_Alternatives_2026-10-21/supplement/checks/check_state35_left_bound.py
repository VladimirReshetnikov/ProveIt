"""Replay the source-runtime35/0 left-marker theorem without large trace files.

Every primitive guard is proved over independent natural register values, gap,
first spare value, and arbitrary finite spare tail by the owned symbolic kernel.
This checker observes all explicit35/0 entries. Its treatment of skipped unary
and finite-list interiors is checked below, rather than inferred from samples.
"""
from pathlib import Path
import sys,json,time,hashlib,collections
import argparse,os
if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'): raise RuntimeError('Assertions must be enabled')
R=Path(__file__).resolve().parent.parent
ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args()
D=args.work;D.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(R/'checks'))
import symbolic_runtime as S
TP=R/'negative_controls/rejected_old_delete301_214.native.tm'
SP=R/'inputs/transfer201.sites.json'
MP=R/'inputs/NATIVE_TO_LEGACY.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(TP)=='724c7eb1c1e72854781e4eec5e4d4b8453c3d04af11325cece46e4f843cd6e10'
assert sha(SP)=='05e7caa159d95cdf9ee254d313c44c52369ac91e52cbc23d54b15f0b64b95922'
N=S.r.table(TP);sites=json.load(open(SP));M={int(a):int(b)for a,b in json.load(open(MP)).items()}
for q in sorted({q for q,b in N}|{z for w,d,z in N.values()}):
 if q not in M:M[q]=max(M.values())+1
T={(M[q],b):(w,d,M[z])for(q,b),(w,d,z)in N.items()};Q=M[35]
assert N[35,0]==(1,1,35)
lemmas,blocks=S.prove_blocks(T)
# List traversal induction repeats one of these actual-table one-block traces.
# None contains35, either literally or as a unary self-loop.
assert len(blocks)==4
for block in blocks:
 for event in block['trace']:
  assert event[0]!='list'
  assert event[1][0]!=Q,('35_hidden_in_list_schema',block)
original=S.State.step;current=None;hist=collections.Counter();witness=None;unary=0;visits=0;stream=hashlib.sha256()
def distance(st):
 # State.left is nearest-first; it includes the scanned cell only if d=-1.
 left=list(st.left)
 if st.direction==-1:
  assert left[0][0]=='run'and left[0][1]==0 and left[0][2][0]>=1
  left[0]=S.run(0,S.minus1(left[0][2]));left=S.normal(left)
 zeros=0
 for atom in left:
  assert atom[0]=='run',('no_finite_left_marker',current,st.key())
  b,n=atom[1:]
  if b==1:
   assert n[0]>=1,('optional_marker',current,st.key())
   return zeros+1
  assert not any(n[1:]),('unbounded_zero_run',current,st.key())
  zeros+=n[0]
 raise AssertionError(('missing_marker',current,st.key()))
K=9;MASK=(1<<19)-1;patterns=set();interior_shapes=set()
def fixed(atoms,n):
 out=[]
 for atom in atoms:
  if atom[0]=='blank':return out+[0]*(n-len(out))
  if atom[0]!='run':return out
  assert all(x>=0 for x in atom[2])
  out.extend([atom[1]]*min(atom[2][0],n-len(out)))
  if len(out)==n or any(atom[2][1:]):return out
 return out
def addpattern(left,right,d):
 bits={}
 for i,b in enumerate(left):
  h=-i-int(d==1)
  if -K<=h<=K:bits[h]=b
 for i,b in enumerate(right):
  h=i+int(d==-1)
  if -K<=h<=K:bits[h]=b
 assert 0 not in bits or bits[0]==0
 bits[0]=0
 patterns.add((sum(1<<(h+K)for h in bits),sum(b<<(h+K)for h,b in bits.items())))
def capturepattern(st):
 d=st.direction;L=st.left;Rr=st.right
 addpattern(fixed(L,K+int(d==-1)),fixed(Rr,K+int(d==1)),d)
 if d==1:
  sf=tuple(fixed(Rr[1:],K+1));df=tuple(fixed(L,K+1));shape=(sf,df)
  if shape not in interior_shapes:
   interior_shapes.add(shape)
   for k in range(1,K+2):
    for j in range(1,K+2):addpattern(([1]*k+list(df))[:K],([0]*j+list(sf))[:K+1],1)
def observed(st,table,lem,clock,motion):
 global visits,witness,unary
 st.key()
 if st.q==Q:
  src=st.right if st.direction==1 else st.left
  if src[0][0]=='run'and src[0][1]==0:
   capturepattern(st)
   d=distance(st);assert 1<=d<=7,(current,d,st.key());hist[d]+=1;visits+=1
   item=dict(current,left_marker_distance=d,state=st.key())
   stream.update(json.dumps(item,separators=(',',':')).encode()+b'\n')
   if witness is None or d>witness['left_marker_distance']:witness=item
 clock,motion,event=original(st,table,lem,clock,motion)
 if event[0]=='unary'and event[1][0]==Q:
  # Its first point was observed above. Every strict interior is entered after
  # writing1 and moving right, so has a1 immediately to the left, regardless
  # of the arbitrary natural run length. Other unary loops retain another q.
  assert event[1]==(Q,0,1,1,Q)
  unary+=1
 return clock,motion,event
S.State.step=observed;start=time.monotonic();cases=0
try:
 for index,site in enumerate(sites):
  for positive in([False,True]if site[1]=='CD'else[False]):
   current=dict(index=index,site=site,positive=positive)
   S.case(T,lemmas,site,positive);cases+=1
  if index%1000==0:print('proved',cases,'observed35',visits,flush=True)
finally:S.State.step=original
assert cases==sum(2 if site[1]=='CD'else 1 for site in sites)==6209
# Independently replay the exact blank prefix that the theorem excludes.
q=h=0;ones=set()
for tick in range(85):
 w,d,q=N[q,int(h in ones)]
 if w:ones.add(h)
 else:ones.discard(h)
 h+=d
assert(q,h,ones)==(35,7,{-3,-2})
startup_distance=h-max(x for x in ones if x<h);assert startup_distance==9
minimal=[]
for m,v in sorted(patterns,key=lambda x:(x[0].bit_count(),x)):
 if not any((m&m0)==m0 and(v&m0)==v0 for m0,v0 in minimal):minimal.append((m,v))
windows=set()
for m,v in minimal:
 unknown=MASK^m;sub=unknown
 while True:
  windows.add(v|sub)
  if sub==0:break
  sub=(sub-1)&unknown
assert all(not(x>>K)&1 and any((x>>(K-j))&1 for j in range(1,8))for x in windows)
WP=D/'state35_replay_windows19.txt';WP.write_text(''.join(f'35 {x}\n'for x in sorted(windows)))
assert sha(WP)=='b10b76f8a4af00ffc322f6e0819c8042034c121d9c66678ccdda603d0ae5cf4e'
out=dict(status='UNIFORM_RUNTIME35_LEFT_MARKER_DISTANCE_AT_MOST7_PROVED',primitive_cases=cases,width19_patterns=len(patterns),width19_minimal_patterns=len(minimal),width19_windows=len(windows),width19_window_sha256=sha(WP),observed_symbolic35_zero_entries=visits,histogram=dict(sorted(hist.items())),maximum_distance=max(hist),observed35_unary_accelerations=unary,list_block_schemas_checked=len(blocks),list_schemas_containing35=0,strict_unary_interior_distance=1,entry_stream_sha256=stream.hexdigest(),maximum_distance_witness=witness,blank_start_comparison=dict(steps=85,state=q,head=h,one_cells=sorted(ones),nearest_left_one_distance=startup_distance),files={str(p.relative_to(R)):sha(p)for p in[TP,SP,MP,Path(S.__file__),Path(S.r.__file__),Path(__file__)]},seconds=time.monotonic()-start,scope='All initialized source-runtime35/0 visits, including induction interiors. Does not prove that blank startup can or cannot be repaired.')
(D/'STATE35_BOUND_REPLAY.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items()if k not in('maximum_distance_witness','files')},flush=True)

expected=json.loads((R/'evidence/STATE35_BOUND_REPLAY.json').read_text())
for key in expected:
 if key not in ('seconds','files'): assert json.loads(json.dumps(out[key]))==expected[key],key
print('STATE35_COMPLETE_REPLAY_PASS')
