# Prefix250: a 250-state blank-tape machine calibrated to Con(ZFC)

This contribution gives an explicit deterministic binary, single-tape Turing
machine with **250 working states**, including initialization, and a separate
halt state. Its ordinary mathematical correctness argument establishes

\[
\mathrm{ZFC}\vdash
\bigl(\neg\operatorname{Halt}(M_{250},\mathrm{blank})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

The construction reduces the pinned ProveIt permutation252 baseline by two
states. It retains the full original proof-search program and logical
calibration. No prepared input tape or additional initializer is supplied.

**Proof status:** the package contains a conventional mathematical proof,
executable exhaustive symbolic checks under explicitly proved register
contracts, and independent finite literal audits. It does **not** contain a
new kernel-checked Lean or Rocq endpoint for this exact 250-state table, a
serialized internal ZFC proof, or a PA-internal proof-code comparison. The
existing inherited source proofs are identified and reused as mathematical
results; their full proof-assistant dependency closures were not rebuilt.

## Read the result

- `zfc-prefix250-report.pdf`: consolidated report, including the universal
  register identities, global simulation, precise consistency calibration,
  verification boundary, and complete canonical transition table.
- `zfc-prefix250-report.tex`: main LaTeX source; it includes
  `proof/report-continuation.tex` and `machine/canonical-table.tex`.
- `proof/prefix_carry_lemmas.tex`, `proof/retimingproof.tex`, and
  `proof/independent_audit.tex`: supporting derivations and independent review.

## Exact machine

| Convention | Canonical table | Original-label table |
|---|---|---|
| File | `machine/zfc_prefix250.tm` | `machine/zfc_prefix250_old.tm` |
| Working states | 0 through 249 | `{0,...,253} - {5,8,43,59,85} + {255}` |
| Start | 0 | 97 |
| Separate halt | 250 | 254 |
| Dispatcher | 92 | 96 |
| Rows | 500 | 500 |

The tape is bi-infinite and initially all zero; the head starts at 0. A row
`state read write L-or-R next` writes, moves, and then enters its successor.
The final halting row's write and movement are part of the semantics. The
header line `#! start n` specifies the initial state.

Canonical SHA-256:

```text
0626819c4842f224001e7685366d8061897a7bc9470c015129a1d1cf22efb36e
```

Original-label SHA-256:

```text
fd455304bad82a6da7ab83149352d0b1db27557582c4cc6312de003c96ff4e43
```

## Why the reduction works

Increment and decrement share a rightward carry circuit. Positive decrement
shifts the register prefix and moves the header right one cell. A zero
decrement rolls back that shift. Increment appends a spare block of value
one. The simulation allows an increasing head-to-header distance and
maintains at least one spare after the nine primary registers.

Three old states (43, 59, 85) disappear and one new state (255) is added.
A three-transition retiming then ensures that every recurrent entry to
state 97 reads one. Its read-zero row initializes the blank tape, avoiding
another working state. The incoming-edge proof holds for the entire future
execution, not only the observed startup.

After exactly **585,431** literal transitions, the machine reaches state 96,
head -3, marker -4, header 225, empty PC, and gap 228. Its first nine physical
register values are `[0,2,0,4,0,0,1,0,0]`, followed by 210 value-one spare
blocks. There are exactly 438 one-cells; every other cell is blank.

The unchanged permutation gives logical state
`(N,T,W,A,D,H,X,Y,L) = (1,0,0,0,4,0,0,0,2)`. The precise existing specialization
`DirtyProgram254.six_nonformula_path_iff 1 0 4 0 0 2` admits this root.
`Bisim254.prog254_halts_iff` is universal in the initial register file, so it
applies to this same vector. The existing native/ZF/ZFC refutation comparisons
then give the required consistency calibration.

## Reproduce all checks

Use Python 3.10 or later, with assertions enabled. No dependency installation
or network access is required.

```sh
python3 -B code/verify_all.py
```

Do not pass `-O` or set `PYTHONOPTIMIZE`: assertions are part of these finite
certificates. The driver verifies both exact table hashes and their
renumbering; freshly parses all source leaves; directly runs the canonical
blank machine; checks retiming and the complete startup in independent
representations; reruns all 8,391 affine cases; and runs the independent
33,564 instruction cases, 16,200 exact-time macro cases, and 3,600 additional
box regressions. A full run took approximately 15 seconds in the preparation
environment. The command updates `evidence/` with its results.

The 8,391 symbolic cases denote arbitrary nonnegative extra gap, arbitrary
primary register values satisfying the named guard, and arbitrary finite
nonempty spare suffixes. Their unbounded meaning follows from the proved
local identities and the soundness of each explicit symbolic rule. The
finite literal suites corroborate this proof; they do not establish it by
sampling. The full source PC cleanliness/zero-completion bridge is explained
in report Section 5.3.

`evidence/affine-cases.jsonl` records each accepted case, its guard and target
effect, and rule counts. `code/check_prefix_affine.py` deterministically
reconstructs the symbolic execution for every case. `evidence/reproduction.json`
summarizes the fresh command. The baseline252 audit is historical evidence
from this investigation; it is not rerun by the new-machine reproduction
driver.

Build the report from the extracted archive root:

```sh
pdflatex -interaction=nonstopmode -halt-on-error zfc-prefix250-report.tex
pdflatex -interaction=nonstopmode -halt-on-error zfc-prefix250-report.tex
```

## Suggested integration

Place the directory under
`Computability/BusyBeaver/Research/ZFC/candidate-prefix250/`. The report's
formalization plan isolates the new table, local register contracts, spare
invariant, boundary shift, symbolic replay, and bootstrap proof. The source
decoder and safe-root logical calibration can be retained.

The canonical graph has 250 reachable working states and 250 ordinary exact
bisimulation classes. These finite diagnostics do not prove optimality or
rule out further semantic reductions. No global priority claim is made.

## Source pins and attribution

- ProveIt baseline and inherited Lean declarations:
  `a3f06a2059dd786ad385079106454efb84b87d3c`.
- ProveIt's imported upstream source:
  `297ab8df7e5de329605c3875b4934643b371a5e3`.
- Upstream `zf-254` snapshot inspected here:
  `c132d7eae8158cd3a9850ea3eb7251158c3dd821`.

Original machine and compact calculus: Mira-Cult. Verification and original
symbolic rules: Jeff. Compiler framework: Wade. Public 253-state reduction:
mira-emmy. Register permutation252, source-27 strict affine checker, and the
inherited calibration: ProveIt, with its retained upstream acknowledgments.
This contribution supplies the shared prefix carry, rollback and spare
invariants, initializer retiming, final blank prefix, and new checks.

See `NOTICE.txt`, `sources/provenance.json`, and
`sources/README.upstream-attribution.md`. Included Lean files are pinned
reference snapshots, not a self-contained Lean project. `SHA256SUMS` covers
all delivered files except the manifest itself.

