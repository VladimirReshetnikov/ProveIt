#!/usr/bin/env python3
"""Build the report's complete literal table and byte-identity appendix."""
from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    rows = {}
    starts = []
    for line in (ROOT / 'machine/u221.tm').read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(int(line[9:]))
        elif line and not line.startswith('#'):
            q, b, w, d, z = line.split()
            key = int(q), int(b)
            if key in rows:
                raise ValueError('Duplicate table row')
            rows[key] = f'{w}{d}{z}'
    if starts != [0] or set(rows) != {(q, b) for q in range(221) for b in (0, 1)}:
        raise ValueError('Unexpected dense machine')
    lines = [r'\begingroup\small', r'\setlength{\tabcolsep}{10pt}',
             r'\renewcommand{\arraystretch}{1.13}',
             r'\begin{longtable}{rll@{\hspace{1.6em}}rll}',
             r'\toprule', r'State & Read 0 & Read 1 & State & Read 0 & Read 1\\',
             r'\midrule', r'\endfirsthead', r'\toprule',
             r'State & Read 0 & Read 1 & State & Read 0 & Read 1\\',
             r'\midrule', r'\endhead', r'\midrule',
             r'\multicolumn{6}{r}{\small Continued on the next page}\\',
             r'\endfoot', r'\bottomrule', r'\endlastfoot']
    for q in range(111):
        z = q + 111
        right = (f'{z} & {rows[z, 0]} & {rows[z, 1]}' if z < 221 else '& &')
        lines.append(f'{q} & {rows[q, 0]} & {rows[q, 1]} & {right}\\\\')
    lines += [r'\end{longtable}', r'\endgroup']
    (ROOT / 'paper/transition_table.tex').write_text('\n'.join(lines) + '\n')
    identities = [
        ('Dense U221 table', 'machine/u221.tm'),
        ('Native U221 table', 'machine/u221.native.tm'),
        ('Original native U222 table', 'inputs/u222.native.tm'),
        ('Unchanged main source', 'inputs/u222.sites.json'),
        ('Intact original U222 archive', 'upstream/U222_ConU_2026-10-28.zip'),
        ('Supplementary 203-node source', 'research/source203/sites203.json'),
    ]
    lines = ['The following are SHA-256 identities in the exact supplied file formats.']
    for title, path in identities:
        lines += ['', r'\Needspace{4\baselineskip}',
                  r'\par\medskip\noindent\textbf{' + title + r'}\par\nopagebreak',
                  r'{\small\noindent\nolinkurl{' + path + r'}\par\nopagebreak',
                  r'\noindent\nolinkurl{' + sha(ROOT / path) + r'}\par}']
    (ROOT / 'paper/identities.tex').write_text('\n'.join(lines) + '\n')


if __name__ == '__main__':
    main()
