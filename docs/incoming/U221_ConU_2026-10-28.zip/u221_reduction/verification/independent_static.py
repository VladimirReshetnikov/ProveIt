#!/usr/bin/env python3
"""Independent static certificate checker for the U222 -> U221 local quotient.

No simulation, register invariants, or external modules are used. The finite
checks bind the exact tables to the two elementary induction proofs in
'guarded_quotient_proof.tex'. A successful run is not a proof-assistant receipt.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

BASELINE_SHA256 = '88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427'


def require(condition, description):
    if not condition:
        raise ValueError(description)


def load_table(path):
    data = path.read_bytes()
    rows = {}
    start = None
    for line in data.decode('ascii').splitlines():
        if line.startswith('#! start '):
            require(start is None, 'duplicate start declaration')
            start = int(line.removeprefix('#! start '))
        elif not line or line.startswith('#'):
            continue
        else:
            fields = line.split()
            require(len(fields) == 5, 'malformed transition row')
            q, b, w, direction, r = fields
            q, b, w, r = map(int, (q, b, w, r))
            require(b in (0, 1) and w in (0, 1), 'nonbinary symbol')
            require(direction in ('L', 'R'), 'invalid direction')
            require((q, b) not in rows, 'duplicate transition row')
            rows[q, b] = (w, direction, r)
    working = {q for q, _ in rows}
    require(start in working, 'start is not a working state')
    require(len(rows) == 2 * len(working), 'incomplete working state')
    require(all((q, b) in rows for q in working for b in (0, 1)), 'partial table')
    require({r for _, _, r in rows.values()} - working == {254}, 'halt convention')
    return rows, working, start, hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('candidate', type=Path)
    args = parser.parse_args()
    old, old_states, old_start, old_hash = load_table(args.baseline)
    new, new_states, new_start, new_hash = load_table(args.candidate)
    require(old_hash == BASELINE_SHA256, 'baseline does not match frozen U222')
    require(old_start == new_start == 0, 'start must remain 0')
    require(len(old_states) == 222 and len(new_states) == 221, 'incorrect state counts')
    require(new_states == old_states - {200}, 'wrong removed state')
    require(old[172, 0] == (0, 'L', 112), 'marker-creation row differs')
    require(old[112, 1] == (1, 'R', 200), 'marker-return row differs')
    require(old[112, 0] == old[200, 0] == (0, 'R', 157), 'merged zero rows differ')
    incoming112 = sorted(key for key, row in old.items() if row[2] == 112)
    incoming200 = sorted(key for key, row in old.items() if row[2] == 200)
    require(incoming112 == [(172, 0)], 'additional entry to state112')
    require(incoming200 == [(112, 1)], 'additional entry to state200')
    expected = {key: row for key, row in old.items() if key[0] != 200}
    expected[112, 1] = (1, 'R', 112)
    require(new == expected, 'candidate is not the exact stated patch')
    def f(q):
        return 112 if q == 200 else q
    commuting = 0
    for (q, b), (w, direction, r) in old.items():
        if (q, b) == (200, 1):
            continue
        require(new[f(q), b] == (w, direction, f(r)), f'noncommuting row {(q,b)}')
        commuting += 1
    require(f(254) == 254, 'halt label not fixed')
    require(all(f(q) != 254 for q in old_states), 'working state maps to halt')
    report = {
        'status': 'STATIC_GUARDED_QUOTIENT_PASS',
        'baseline_sha256': old_hash,
        'candidate_sha256': new_hash,
        'baseline_states': len(old_states),
        'candidate_states': len(new_states),
        'candidate_rows': len(new),
        'start_state': 0,
        'halt_label': 254,
        'removed_state': 200,
        'representative': 112,
        'incoming112': incoming112,
        'incoming200': incoming200,
        'guarded_transition_squares': commuting,
        'excluded_row': [200, 1],
        'invariant': ['q=112 implies tape(head+1)=0', 'q=200 implies tape(head)=0'],
        'scope': 'All initial binary tapes and head positions with initial state 0; exact time, tape, and head preservation. Ordinary induction proof, not kernel certificate.'
    }
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
