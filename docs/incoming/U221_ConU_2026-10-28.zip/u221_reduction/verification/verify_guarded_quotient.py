#!/usr/bin/env python3
"""Check U222 -> U221 by an inductive local tape invariant.

No proof-search semantics, runtime fixtures, symbolic execution engine, or
startup certificate is imported. All tapes starting at state 0 are covered.
The finite invariant checks quantify over every relevant four-cell window;
unseen cells are arbitrary. Induction on time supplies the unbounded theorem.
"""
from pathlib import Path
import argparse
import hashlib
import itertools
import json

BASE_SHA = '88a9c5ea637560bf58dba612d598663213884d7bb7981230164bc058babaa427'
CANDIDATE_SHA = '5b6ec891b5fa573123a8dbdcf479a30d744d8539dc0a16d11c1c5871fd84657c'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_table(path):
    table, starts = {}, []
    for line in path.read_text(encoding='ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
        elif line and not line.startswith('#'):
            q, b, w, d, z = line.split()
            q, b, w, z = map(int, (q, b, w, z))
            require((q, b) not in table, 'Duplicate transition')
            require(b in (0, 1) and w in (0, 1) and d in ('L', 'R'),
                    'Invalid transition alphabet')
            table[q, b] = w, (-1 if d == 'L' else 1), z
    states = {q for q, _ in table}
    require(starts == [0], 'Wrong start')
    require(set(table) == {(q, b) for q in states for b in (0, 1)},
            'Incomplete transition table')
    require({z for _, _, z in table.values()} - states == {254},
            'Wrong halt target')
    return table, states


def image(q):
    return 112 if q == 200 else q


def guard(q, tape, head=0):
    return ((q != 112 or tape[head + 1] == 0)
            and (q != 200 or tape[head] == 0))


def verify(baseline, candidate):
    require(digest(baseline) == BASE_SHA, 'Unrecognized baseline bytes')
    require(digest(candidate) == CANDIDATE_SHA, 'Unrecognized candidate bytes')
    old, old_states = read_table(baseline)
    new, new_states = read_table(candidate)
    require(len(old_states) == 222 and len(new_states) == 221, 'Wrong counts')
    require(new_states == old_states - {200}, 'Unexpected removed states')
    expected = {(q, b): (w, d, image(z))
                for (q, b), (w, d, z) in old.items() if q != 200}
    require(new == expected, 'Candidate is not the exact quotient')
    incoming = {q: sorted([p, b] for (p, b), (_, _, z) in old.items() if z == q)
                for q in (112, 200)}
    require(incoming == {112: [[172, 0]], 200: [[112, 1]]},
            'Incoming-edge guard changed')
    require(old[172, 0] == (0, -1, 112), 'Wrong predecessor write')
    require(old[112, 1] == (1, 1, 200), 'Wrong return to the guarded cell')
    require(old[200, 0] == old[112, 0] == (0, 1, 157),
            'Guarded rows do not coincide')

    # Only offsets -1, 0, 1, 2 can be read by the pre/post invariant.
    # Every bi-infinite tape restricts to one of these sixteen windows.
    windows, commutations = 0, 0
    for q in sorted(old_states):
        for bits in itertools.product((0, 1), repeat=4):
            tape = dict(zip((-1, 0, 1, 2), bits))
            if not guard(q, tape):
                continue
            w, d, z = old[q, tape[0]]
            tape[0] = w
            require(guard(z, tape, d), 'Invariant is not inductive')
            windows += 1
    require(windows == 3536, 'Wrong invariant case count')
    for (q, b), (w, d, z) in sorted(old.items()):
        if (q, b) == (200, 1):
            continue  # Excluded by the just-checked invariant.
        require(new[image(q), b] == (w, d, image(z)),
                'Guarded transition square does not commute')
        commutations += 1
    require(commutations == 443, 'Wrong transition-square count')
    require(image(0) == 0 and image(254) == 254, 'Endpoint mismatch')
    require(all((image(q) == 254) == (q == 254)
                for q in old_states | {254}), 'Halting is not reflected')
    return {
        'status': 'GUARDED_QUOTIENT_PASS',
        'baseline_sha256': digest(baseline),
        'candidate_sha256': digest(candidate),
        'baseline_working_states': 222,
        'candidate_working_states': 221,
        'candidate_transition_rows': 442,
        'merged_state': {'200': 112},
        'incoming_edges': incoming,
        'inductive_local_windows': windows,
        'commuting_guarded_rows': commutations,
        'excluded_unreachable_row': [200, 1],
        'initial_state': 0,
        'scope': 'Every binary initial tape at state 0; exact step-for-step '
                 'simulation, with identical tape, head and halting time.',
        'proof_status': 'Ordinary inductive mathematical proof, checked by '
                        'this finite local certificate; no new kernel proof.',
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = verify(args.baseline, args.candidate)
    encoded = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(encoded)
    print(encoded, end='')


if __name__ == '__main__':
    main()
