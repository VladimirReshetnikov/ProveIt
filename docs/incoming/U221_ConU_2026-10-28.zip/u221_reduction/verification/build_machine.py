#!/usr/bin/env python3
"""Deterministically construct the exact U221 quotient and its dense labels."""
from pathlib import Path
import argparse
import hashlib
import json
import verify_guarded_quotient as quotient


def encode(table):
    return ('#! start 0\n' + ''.join(
        f'{q} {b} {w} {"R" if d == 1 else "L"} {z}\n'
        for (q, b), (w, d, z) in sorted(table.items()))).encode('ascii')


def build(baseline):
    quotient.require(quotient.digest(baseline) == quotient.BASE_SHA,
                     'Unrecognized baseline bytes')
    old, states = quotient.read_table(baseline)
    new = {(q, b): (w, d, quotient.image(z))
           for (q, b), (w, d, z) in old.items() if q != 200}
    kept = sorted(states - {200})
    rho = {q: i for i, q in enumerate(kept)}
    rho[254] = len(kept)
    dense = {(rho[q], b): (w, d, rho[z])
             for (q, b), (w, d, z) in new.items()}
    native_raw, dense_raw = encode(new), encode(dense)
    quotient.require(hashlib.sha256(native_raw).hexdigest() == quotient.CANDIDATE_SHA,
                     'Native reconstruction differs')
    quotient.require(hashlib.sha256(dense_raw).hexdigest() ==
                     'c23c796f9275fd407e29c32d59293e077d00700ecc77114914a90ad4ecf702ba',
                     'Dense reconstruction differs')
    quotient.require(set(rho.values()) == set(range(222)), 'Nonbijective dense map')
    quotient.require(rho[0] == 0 and rho[254] == 221, 'Wrong endpoint labels')
    inverse = {z: q for q, z in rho.items()}
    quotient.require({(inverse[q], b): (w, d, inverse[z])
                      for (q, b), (w, d, z) in dense.items()} == new,
                     'Dense transition correspondence failed')
    reached, todo = {0}, [0]
    for q in todo:
        for b in (0, 1):
            z = new[q, b][2]
            if z != 254 and z not in reached:
                reached.add(z)
                todo.append(z)
    quotient.require(reached == set(kept), 'Graph-unreachable working state')
    mapping = {
        'native_to_dense': rho,
        'old_native_to_new_native': {q: quotient.image(q) for q in sorted(states | {254})},
        'old_native_to_new_dense': {q: rho[quotient.image(q)] for q in sorted(states | {254})},
        'native_start': 0, 'native_halt': 254, 'dense_start': 0, 'dense_halt': 221,
    }
    summary = {
        'status': 'EXACT_U221_CONSTRUCTION_PASS',
        'working_states': 221, 'transition_rows': 442,
        'graph_reachable_working_states': len(reached),
        'native_sha256': hashlib.sha256(native_raw).hexdigest(),
        'dense_sha256': hashlib.sha256(dense_raw).hexdigest(),
        'baseline_native_sha256': quotient.BASE_SHA,
        'source_sha256': '1d258cfe56f8b845826a63af57de8134fbc4886b47f95312cf6d49424f3f3072',
        'source_changed': False,
        'deleted_native_state': 200,
        'changed_retained_row': {'key': [112, 1], 'before': [1, 'R', 200],
                                 'after': [1, 'R', 112]},
    }
    return native_raw, dense_raw, mapping, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    native, dense, mapping, summary = build(args.baseline)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'u221.native.tm').write_bytes(native)
    (args.output / 'u221.tm').write_bytes(dense)
    for name, obj in [('state_map.json', mapping), ('summary.json', summary)]:
        (args.output / name).write_text(json.dumps(obj, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
