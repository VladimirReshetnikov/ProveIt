#!/usr/bin/env python3
"""Check the exact 203-node source layout; no solver or TM claim is needed."""
from pathlib import Path
import argparse
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'vendor'))
import source_language as source


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, default=ROOT.parents[1] / 'inputs/u222.sites.json')
    parser.add_argument('--candidate', type=Path, default=ROOT / 'sites203.json')
    args = parser.parse_args()
    before = json.loads(args.baseline.read_text())
    after = json.loads(args.candidate.read_text())
    if sha(args.baseline) != '1d258cfe56f8b845826a63af57de8134fbc4886b47f95312cf6d49424f3f3072':
        raise ValueError('Unexpected baseline source')
    if sha(args.candidate) != '1b9b735aae8aa8c703c02f63cd596a7183117ff2c8850c0e5e25c71a92e7de5e':
        raise ValueError('Unexpected candidate source')
    if [row[1:] for row in before] != [row[1:] for row in after]:
        raise ValueError('Primitive word changed')
    graphs = [source.graph_arithmetic(rows)[0] for rows in (before, after)]
    graphs += [source.graph_intervals(rows) for rows in (before, after)]
    if not all(graph == graphs[0] for graph in graphs):
        raise ValueError('Source control flow changed')
    result = {
        'status': 'SOURCE_CONTROL_FLOW_EQUIVALENCE_PASS',
        'scope': 'Source semantics only; no new literal TM or state-count claim',
        'baseline_sha256': sha(args.baseline),
        'candidate_sha256': sha(args.candidate),
        'baseline_metrics': source.metrics(source.tree(before)),
        'candidate_metrics': source.metrics(source.tree(after)),
        'identical_primitive_word': True,
        'identical_guarded_ordinal_cfg': True,
        'two_independent_cfg_resolvers': True,
        'guarded_cases': sum(2 if row[1] == 'CD' else 1 for row in before),
    }
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
