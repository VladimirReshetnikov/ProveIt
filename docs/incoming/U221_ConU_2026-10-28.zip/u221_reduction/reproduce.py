#!/usr/bin/env python3
"""Offline U221 verification. --full regenerates both symbolic runtime checks.

Python 3.10+ and its standard library suffice. The elementary new transfer proof
does not depend on the optional runtime checks or on any source-theory claim.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'verification'))
import build_machine
import verify_guarded_quotient as quotient


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(script, *args):
    command = [sys.executable, '-B', str(script), *map(str, args)]
    completed = subprocess.run(command, check=True, capture_output=True, text=True,
                               env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
    return completed.stdout


def check_manifest():
    seen = set()
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ', 1)
        relative = Path(name)
        need(not relative.is_absolute() and '..' not in relative.parts,
             'Unsafe manifest path')
        need(name not in seen, 'Duplicate manifest entry')
        seen.add(name)
        need(sha(ROOT / relative) == expected, 'Hash mismatch: ' + name)
    need({'reproduce.py', 'machine/u221.tm', 'machine/u221.native.tm',
          'verification/verify_guarded_quotient.py', 'paper/u221_report.tex',
          'paper/u221_report.pdf', 'upstream/U222_ConU_2026-10-28.zip'} <= seen,
         'A principal artifact is absent from the manifest')
    return len(seen)


def unpack_baseline(destination):
    archive = ROOT / 'upstream/U222_ConU_2026-10-28.zip'
    need(sha(archive) == 'd23e80857214900f8e0806f03f6df752af501dd0108eb92c6ed7a49795802652',
         'Wrong original U222 archive')
    with zipfile.ZipFile(archive) as zipped:
        for item in zipped.infolist():
            need((destination / item.filename).resolve().is_relative_to(destination.resolve()),
                 'Unsafe archive member')
        zipped.extractall(destination)
    base = destination / 'u222_consistency_machine'
    need((base / 'machine/u.native.tm').read_bytes() ==
         (ROOT / 'inputs/u222.native.tm').read_bytes(), 'Baseline table copy differs')
    need((base / 'machine/sites.json').read_bytes() ==
         (ROOT / 'inputs/u222.sites.json').read_bytes(), 'Baseline source copy differs')
    return base


def dense_bootstrap(base, mapping):
    # Independently replay the released DENSE table against the published trace.
    table = {}
    starts = []
    for line in (ROOT / 'machine/u221.tm').read_text().splitlines():
        if line.startswith('#! start '):
            starts.append(int(line[9:]))
        elif line and not line.startswith('#'):
            q, b, w, d, z = line.split()
            key = int(q), int(b)
            need(key not in table and d in ('L', 'R'), 'Bad dense table')
            table[key] = int(w), (1 if d == 'R' else -1), int(z)
    need(starts == [0] and set(table) == {(q, b) for q in range(221) for b in (0, 1)},
         'Incomplete dense table')
    receipt = json.loads((base / 'evidence/startup.json').read_text())
    rho = mapping['old_native_to_new_dense']
    q, h, ones = 0, 0, set()
    visited = set()
    for old_q, old_h, old_b, old_w, old_d, old_z in receipt['trace']:
        read = int(h in ones)
        need((q, h, read) == (rho[old_q], old_h, old_b),
             'Dense startup configuration differs')
        write, direction, target = table[q, read]
        need((write, direction, target) == (old_w, old_d, rho[old_z]),
             'Dense startup transition differs')
        visited.add(old_q)
        if write:
            ones.add(h)
        else:
            ones.discard(h)
        q, h = target, h + direction
    need(len(receipt['trace']) == receipt['steps'] == 95714, 'Wrong prefix length')
    need((q, h, sorted(ones)) ==
         (rho[receipt['state']], receipt['head'], receipt['one_cells']),
         'Dense startup endpoint differs')
    need(200 not in visited, 'Unexpected removed state in startup')
    need(receipt['registers'] == [4, 0, 0, 0, 0, 0, 0, 0, 0], 'Wrong logical seed')
    need(receipt['spares'] == [1] * 40 and receipt['gap'] == 1, 'Wrong physical seed')
    return {'status': 'DENSE_LITERAL_STARTUP_PASS', 'steps': 95714,
            'dense_dispatch': q, 'head': h, 'one_cells': len(ones),
            'gap': 1, 'logical_registers': receipt['registers'],
            'spare_count': 40, 'spare_value': 1,
            'complete_finite_tape_support_matches': True,
            'removed_state_visited': False}


def check_runtime_report(base, folder):
    sites = json.loads((ROOT / 'inputs/u222.sites.json').read_text())
    summary = json.loads((folder / 'runtime.json').read_text())
    cases = json.loads((folder / 'runtime_cases.json').read_text())
    expected = [(i, positive) for i, row in enumerate(sites)
                for positive in ((False, True) if row[1] == 'CD' else (False,))]
    need(summary['status'] == 'UNIVERSAL_MATHEMATICAL_PASS', 'Runtime check failed')
    need(summary['table_sha256'] == sha(ROOT / 'machine/u221.native.tm'),
         'Wrong runtime table')
    need(summary['sites_sha256'] == sha(ROOT / 'inputs/u222.sites.json'),
         'Wrong runtime source')
    need(summary['working_states'] == 221 and summary['site_count'] == 3891,
         'Wrong runtime census')
    need(summary['expected_cases'] == summary['proved_cases'] == len(expected) == 5060,
         'Incomplete symbolic coverage')
    need(not summary['failures'], 'Runtime failures')
    need(summary['startup_status'] == 'CALIBRATED_DIRTY_ROOT_SEED', 'Startup failed')
    need([(c['site_index'], c['positive']) for c in cases] == expected,
         'Missing, extra, or reordered symbolic case')
    need(summary['checker_sha256'] == sha(base / 'code/runtime/symbolic_runtime.py') and
         summary['helper_sha256'] == sha(base / 'code/runtime/independent_runtime.py'),
         'Runtime checker identity differs')
    return len(cases)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    need(__debug__ or not args.full,
         'The inherited symbolic checker requires assertions; rerun without -O')
    started = time.monotonic()
    nfiles = check_manifest()
    native, dense, mapping, construction = build_machine.build(ROOT / 'inputs/u222.native.tm')
    need(native == (ROOT / 'machine/u221.native.tm').read_bytes(), 'Native bytes differ')
    need(dense == (ROOT / 'machine/u221.tm').read_bytes(), 'Dense bytes differ')
    canonical_map = json.loads(json.dumps(mapping))
    need(canonical_map == json.loads((ROOT / 'machine/state_map.json').read_text()),
         'Published state map differs')
    core = quotient.verify(ROOT / 'inputs/u222.native.tm', ROOT / 'machine/u221.native.tm')
    print('PASS: exact quotient, 3536 inductive windows, 443 commuting rows', flush=True)
    independent = json.loads(run(ROOT / 'verification/independent_static.py',
                                 ROOT / 'inputs/u222.native.tm', ROOT / 'machine/u221.native.tm'))
    need(independent['status'] == 'STATIC_GUARDED_QUOTIENT_PASS', 'Independent audit failed')
    source203 = json.loads(run(ROOT / 'research/source203/verify_source_layout.py',
                               '--baseline', ROOT / 'inputs/u222.sites.json',
                               '--candidate', ROOT / 'research/source203/sites203.json'))
    with tempfile.TemporaryDirectory(prefix='u221-verify-') as folder:
        temp = Path(folder)
        base = unpack_baseline(temp)
        boot = dense_bootstrap(base, mapping)
        cases = check_runtime_report(base, ROOT / 'evidence')
        print('PASS: released dense table, full blank startup, saved runtime coverage', flush=True)
        baseline_receipt = None
        if args.full:
            print('Rechecking the original U222 source and all symbolic cases...', flush=True)
            run(base / 'reproduce.py', '--full', '--report', temp / 'baseline_full.json')
            baseline_receipt = json.loads((temp / 'baseline_full.json').read_text())
            need(baseline_receipt['status'] == 'U222_FULL_REPRODUCTION_PASS',
                 'Baseline full reproduction failed')
            print('Rechecking all 5060 symbolic cases for U221...', flush=True)
            output = temp / 'candidate_full'
            run(base / 'code/validate_native.py', ROOT / 'machine/u221.native.tm',
                ROOT / 'inputs/u222.sites.json', output)
            check_runtime_report(base, output)
            need(json.loads((output / 'startup.json').read_text()) ==
                 json.loads((base / 'evidence/startup.json').read_text()),
                 'Regenerated startup differs from U222')
            need(json.loads((output / 'runtime_cases.json').read_text()) ==
                 json.loads((ROOT / 'evidence/runtime_cases.json').read_text()),
                 'Regenerated symbolic cases differ')
            print('PASS: both full reproductions and every regenerated case', flush=True)
    report = {
        'status': 'U221_FULL_REPRODUCTION_PASS' if args.full else 'U221_LOCAL_REPRODUCTION_PASS',
        'manifest_files_checked': nfiles, 'construction': construction,
        'local_quotient': core, 'independent_static_status': independent['status'],
        'dense_bootstrap': boot, 'symbolic_cases': cases,
        'symbolic_cases_rerun': args.full, 'baseline_full_rerun': args.full,
        'supplementary_source203': source203,
        'seconds': round(time.monotonic() - started, 3),
        'scope': 'The all-tape exact-step reduction is proved by the elementary '
                 'local invariant. Con(U)/Con(PA) calibration is inherited from '
                 'U222. No new Lean, Rocq, or MM0 endpoint certificate.',
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
