# Weighted matching support rank normalization through rank four

For a bipartite graph G, count each pair of equal-size shore subsets admitting a perfect matching ONCE. Give that support the product of its selected vertex activities. Write the resulting polynomial as p_G(t) = sum a_k t^k, and let d be its actual degree after zero activities are accounted for.

## Result

If the matching number of G is at most four, then for arbitrary nonnegative activities on both shores,

    (a_k / binom(d,k)) for k = 0,...,d

is log-concave, with no internal zeros. The normalization uses the surviving degree, not automatically the original graph's matching number.

Equivalently, for 1 <= k < d,

    k*(d-k)*a_k^2 >= (k+1)*(d-k+1)*a_(k-1)*a_(k+1).

At d = 4 the inequalities are 3*a_1^2 >= 8*a_2, 4*a_2^2 >= 9*a_1*a_3, and 3*a_3^2 >= 8*a_2*a_4.

A stronger intermediate theorem holds for graphs admitting a vertex cover with two vertices on each shore: their support polynomials are real-rooted under these activities. This is NOT a real-rootedness theorem for every graph of matching number four. A unit-weight rank-three example already fails real-rootedness: three left centers and four vertices of each pair-neighborhood type have polynomial 1 + 24t + 162t^2 + 208t^3, with discriminant -2592. The known rank-four theta example has polynomial 1 + 9t + 24t^2 + 16t^3 + t^4 and discriminant -5243.

The article gives every core-case proof in full. Pendant compression and the established weighted ambient Lorentzian theorem cover the thin minimum covers. Six two-by-two core orbits are handled by exact weighted-path models, Hermitian cycle phases, and a positive-semidefinite block determinant for the complete core. Zero-activity vertices are deleted before applying the cover reduction.

## Sharp unit-weight rank-three minimum

The revised article proves a global computer-assisted minimality statement within matching number exactly three and unit vertex activities: fifteen vertices are necessary and sufficient for a non-real-rooted support polynomial. Up to isomorphism and shore exchange, the unique fifteen-vertex graph has three centers and four opposite vertices of each pair-neighborhood type.

A direct rooted-path lemma excludes every cover split 1+2. König's theorem then reduces all possible counterexamples to a three-center shore and seven opposite neighborhood populations. Two independent exact-integer implementations check every population vector through total opposite population 12. They find 30,699 rank-three vectors through total 11, with none negative, and 18,288 at total 12, with the unique negative vector (0,0,4,0,4,4,0). Its polynomial is 1 + 24t + 162t^2 + 208t^3 and its discriminant is -2592.

This is an exhaustive finite proof after a structural reduction, not a random screen or formal proof-assistant verification. The matching-number-three and unit-weight restrictions matter: the known rank-four theta graph has only eight vertices.

## A restricted strict rank-five theorem

The graph has shores A union X and B union Y, with |A| = 2, |B| = 3, |X| = n >= 3, and |Y| = m >= 2. Its edges are exactly A x B, A x Y, and X x B. Each of the four blocks has its own constant positive vertex activity. For this family, all four degree-five Newton inequalities are strict.

The proof gives an exact support formula and an exhaustive two-branch parameter substitution. The resulting eight Newton-gap polynomials have only positive nonzero rational coefficients. Their complete coefficient lists are included and verified independently using sparse Fraction arithmetic; a SymPy generator reproduces the same certificate. Positive boundary terms establish strictness throughout the unbounded family.

This does not address varying activities within a block, incomplete core edges, or general rank-five graphs. It rules out the direct complete-core deletion family within the stated activity class.

## Files

- `matching-rank-four.pdf`: 16-page mathematical article with complete proofs and limitations
- `matching-rank-four.tex`: editable standalone LaTeX source
- `check_weighted_rank_four.py`: deterministic exact checker
- `support_kernels.py`: Boolean matching and neighborhood-type support routines used by the checker
- `verification.json`: successful rank-four checker receipt
- `check_rank_three_minimum.py` and `rank-three-minimum-verification.json`: independent Hall-formula classification and complete per-population counts
- `check_rank_three_bijections.py` and `rank-three-bijections-verification.json`: separate bijection-table classification
- `rank-five-certificate.json`: all eight exact rational coefficient lists in exponent order x,y,a,z
- `check_rank_five_certificate.py` and `rank-five-verification.json`: independent standard-library certificate verification and three direct four-block Hall checks
- `generate_rank_five_certificate.py` and `rank-five-generation.json`: SymPy certificate regeneration and summary
- `REVISION.md`: description of the bounded second edition
- `requirements.txt`: tested SymPy version
- `SOURCE.txt`: exact repository pin and question/input locations
- `build.sh`: two-pass pdfLaTeX build
- `SHA256SUMS`: package checksums

## Reproduce the verification

Use Python 3.10 or newer and SymPy (tested with 1.14.0), with assertions enabled. Do not use `python -O`.

    python3 check_weighted_rank_four.py > verification-new.json
    diff -u verification.json verification-new.json

The original rank-four run took about one second in the preparation environment; runtime depends on the machine. The receipt records the SymPy version, so a different version may change that metadata even when every assertion passes.

The checker performs:

1. Exact rational support enumeration on 128 graphs, eight for each of the sixteen two-by-two core masks, using fixed seed 431 and nonuniform positive rational activities. Each common-neighborhood population has one, two, or three vertices
2. Comparison of three coefficient calculations: labeled-support enumeration, a Boolean cover-type kernel, and a separate shore-imbalance formula
3. Independent matching-cover rank verification and all three rank-four Newton inequalities on those examples
4. Exact symbolic checks of the weighted variance margin, adjacent-core margin, complex PSD block determinant coefficient identity, theta quartic discriminant, and the symbolic pair-neighborhood cubic discriminant formula
5. Direct Boolean support enumeration for the pair-neighborhood family at populations n = 1 through 6

The activities weight supports, not individual matchings. The feasibility routine answers a Boolean question, and a feasible support enters each enumeration only once.

The 128 mixed-cover examples have positive activities and matching rank four; the six pair-neighborhood examples have unit activities and matching rank three. The zero-activity and lower-rank conclusions are proved in the article by deletion and the minimum-cover argument; they are not claimed as exhaustive finite tests here. The phase-existence arguments are analytic proofs, not numerical searches for phases or roots. No floating-point arithmetic is used by the delivered checker. The earlier exploratory large random screen is unnecessary for the proof and is not included in this package.

The rank-four checker corroborates identities and finite instances. It does not establish the universal rank-four theorem by enumeration and does not constitute Lean or other proof-assistant verification.

## Reproduce the two new proof certificates

The two classification scripts and the independent rank-five checker use only Python's standard library. The coefficient generator additionally uses SymPy. Run from this directory, with assertions enabled:

    python3 check_rank_three_minimum.py > rank-three-minimum-new.json
    diff -u rank-three-minimum-verification.json rank-three-minimum-new.json
    python3 check_rank_three_bijections.py > rank-three-bijections-new.json
    diff -u rank-three-bijections-verification.json rank-three-bijections-new.json
    python3 check_rank_five_certificate.py > rank-five-new.json
    diff -u rank-five-verification.json rank-five-new.json
    mkdir -p build
    python3 generate_rank_five_certificate.py --output build/rank-five-certificate.generated.json > rank-five-generation-new.json
    diff -u rank-five-generation.json rank-five-generation-new.json
    cmp rank-five-certificate.json build/rank-five-certificate.generated.json

These commands finish in seconds to tens of seconds on the preparation machine; the symbolic regeneration is the slowest. The original coefficient lists are not overwritten. The independent rank-five checker verifies identity with every supplied coefficient, its positivity, and the nonzero positive boundary polynomials; the table in the article summarizes the eight certified expansions.

The Hall-based minimum checker enumerates all weak compositions by separator combinations, asserts the stars-and-bars count at each total, and filters rank by the cubic coefficient. The second implementation uses bijection feasibility tables and recursive compositions. They agree on all 48,987 rank-three profiles and the unique negative discriminant. The finite exhaustive classification proves the stated vertex minimum; it does not enumerate arbitrary larger graphs or nonconstant activities.

These two new results differ from merely checking examples: the minimality computation exhausts the reduced finite domain, and the positive-coefficient certificate proves the specified rank-five family for all its allowed parameters. They remain computer-assisted mathematical proofs, not proof-assistant formalizations.

## Build the PDF

Install a working pdfLaTeX distribution with amsmath, amssymb, amsthm, lmodern, geometry, booktabs, microtype, and hyperref, then run:

    sh build.sh

The delivered PDF was compiled without unresolved references or layout warnings, and every page was visually inspected.

## Attribution and remaining questions

The motivating ProveIt source is pinned in SOURCE.txt. This article resolves its weighted rank-three and unit-weight rank-four questions, and the rank-three/rank-four portions of its two-shore weighted rank question.

The weighted ambient input is credited to the source's transversal-matroid specialization of Brändén–Huh's Lorentzian theory; the relation-bimatroid ambient result is credited to Röhrle–Ulirsch. The spectral theorem, Newton inequalities, Cauchy–Binet, Schur complements, and König's matching-cover theorem are classical. The exact finite-rank support constructions are proved in the article without a claim of worldwide priority.

The general weighted rank-five question remains unresolved here, beyond the restricted four-block family just proved. The inspected source already has a weighted rank-six counterexample, so the least possible weighted counterexample rank is now either five or six. The unit-weight all-rank question remains separate and open in this article. No general real-rootedness or arbitrary-bimatroid actual-rank theorem is claimed.

Revised 1 October 2026 for Vladimir Reshetnikov.
