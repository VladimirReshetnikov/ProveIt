# Raw-profile closure and routing freedom at the 245-state frontier

**Outcome: this delivery does not establish a machine with fewer than 245 working states.** It provides a new **18-clause finite universal theory equiconsistent with ZFC**, exact static encodings as small as **787 bits**, new general compiler-entry contracts, a completely verified combined **245-state control**, and reproducible bounded searches.

The machine convention is a deterministic, single-tape, two-symbol Turing machine on a two-way infinite all-zero tape, using only left/right moves. The separate halt state is excluded from the count. A successful strict improvement requires at most 244 working states and a ZFC proof of `Nonhalt(M) <-> Con(ZFC)` for the exact blank-start table. No artifact in this package is represented as having reached that endpoint.

Read **research.pdf** for the integrated mathematical argument, proof boundaries, results and reproduction instructions. **research.tex** includes the complete mathematical and machine TeX sections shipped in the archive.

## Main mathematical result

The new interpretation keeps assignments and class codes as raw terms. It quotients only data values and membership. All function-congruence clauses, including the last evaluation-congruence clause, can be omitted.

The key additional proof uses only three selector coordinates to construct relative power objects. Beginning with an empty object, their iterates have strictly increasing predecessor sets. This produces arbitrarily many distinct quotient values and therefore all selectors required for the full formula interpretation. The proof avoids assuming an infinite selector supply before constructing it.

The resulting theory has two constants, four binary predicates, and at most four variables in any clause. `Eq` is an ordinary predicate; no equality solver silently supplies the congruence rules that were removed.

| Target | Clauses | Literals | Proper functions | Fixed-opcode bits | Plain Huffman bits | Selective dictionary bits |
|---|---:|---:|---:|---:|---:|---:|
| RP18D | 18 | 43 | 10 | **902** | 798 | 790 |
| RP18Z | 18 | 43 | 9 | 910 | 796 | **787** |
| RP18V | 18 | 43 | 9 | 906 | **795** | 788 |
| RP19ED | 19 | 47 | 10 | 1069 | 972 | 956 |
| RP19EZ | 19 | 47 | 9 | 1077 | 971 | 953 |

The ordinary consistency proofs are internalizable in ZFC. The lower bridge to ZFC is the explicitly identified **full raw EPSC** calibration from the supplied repository. The quotient itself is not asserted to satisfy ZFC. The extensional controls retain the separate extensional EPSC calibration.

RP18Z shares a member-selector function with a counterexample function under complementary guards. RP18V uses `V(x,d)` as its member-selector term, with a separate upper construction in a model of ZFC + V=L. Its assignment records contain their designated coordinate value as a literal member.

The 787-bit stream charges 71 header bits, 41 dictionary-definition bits, and 675 clause-body/terminator bits. It occupies 99 bytes when padded. The signature and arities are part of the specified decoder protocol. The decoder program, refuter, binary-machine backend and blank initializer have not been given state counts. These are static data measurements.

The report also proves a boundary: deleting the remaining distinct-constants clause gives a seventeen-clause theory with a model on hereditarily finite sets whose existence ZFC proves. Thus that deletion does not achieve the intended strength, subject to consistency of ZFC.

## Machine results

The original 245-state baseline passed a fresh complete `verify_all.py --whole-frame --literal` replay, including all 8,391 guarded symbolic cases, 407,915 blank steps, and 8,385 independent literal fixtures.

The newly combined 245-state control joins inherited DNE mask32 with the inherited four-projection bootstrap relaxation. It has 117 framework states and 128 grammar states. Its complete table is `grammar/control245/machine.tm`; the canonical start is 0 and the separate halt label is 245. Its SHA-256 is:

```
6b3c24a9f1f3261246217ba90460701f7b30aa5c18d65901f9b36addea1d8dd3
```

Fresh checks cover all 8,269 guarded symbolic cases, a 3,085-pair source bisimulation, the exact 407,995-step blank initialization, and an independent whole-frame proof on the actual table with arbitrary nine-register values, header slack and nonempty spare suffix. Its source/calculus transfer uses the inherited DNE theorem. No new final Lean or Rocq endpoint is claimed.

The general orientation lemma permits both incoming bits at existing increment states 39, 72 and 93, without changing a transition or adding a state. A broader fourteen-entry survey is explicitly limited to concrete short control prefixes and compatible internal zero-six paths. The final context-sensitive addendum treats state 18 separately.

Six simultaneous dictionary-repair runs made **28,707,797 proposals** and retained at least 128 grammar rules. A separate joint scanner/grammar run made **6,826,542 proposals**, retaining prospective cost 129 rather than the required 128. The bounded two-incoming-action deletion family comprised **51,439,104 action pairs**; after sound prefix pruning, 9,555,040 branches were executed and none passed all affected finite fixtures. These results are not lower bounds.

A fully unlocked candidate passed source bisimulation but failed composition. Its blank run reaches state 42 after 51 steps, then repeats `(42,0) -> (1,R,42)` forever on a blank right ray. The rejected table and exact trap certificate are retained under `grammar/rejected245/`; they are clearly separated from the verified control.

## Reproduction

Python 3 with assertions enabled is sufficient for the default checks:

```sh
python3 -B reproduce.py
```

This verifies the delivery manifest, regenerates all five theory payloads, checks 2,048 ground-code round trips per target, checks all stage-zero valuations and the RP18D stage-one valuation, decodes all five saved best dictionary streams and their packed bytes, audits saved grammars and the rejected blank trap, checks the contextual state-18 grammar and literal increment-row premises, and regenerates both 96-target symbolic source families from the pinned offline archive. The finite SAT results are implementation checks, not proofs of consistency.

To repeat every declared selective-dictionary subset search:

```sh
python3 -B reproduce.py --codecs --output /tmp/zfc-codec-replay
```

To rerun the several-minute independent whole-frame theorem for the combined control:

```sh
python3 -B reproduce.py --whole-frame --output /tmp/zfc-whole-frame-replay
```

Individual machine rebuild, optimizer and finite-edit commands are documented in `grammar/README.md`, `runtime/README-runtime.md`, and the context addenda. C++17 is required for those compiled tools; the optional finite MILP requires NumPy and SciPy. A time limit, process termination or resource exception is never an UNSAT result or an infeasibility proof.

Build the integrated report with a TeX installation containing latexmk, pdfLaTeX and the ordinary packages in the preamble:

```sh
make pdf
```

PDF metadata timestamps may change on recompilation. The delivered hashes identify delivered bytes; numerical theory payloads and literal transition tables have deterministic checks.

## Integration and attribution

The inspected ProveIt checkout is pinned to `fd1adfa19f8fe8da41444e3fa43b89a59d891067`. The baseline and source-search input archives are retained in `reference/` with their original contents. The raw EPSC/full finite-class source note and reference code are retained in `formalism/reference/`. Copied licenses and attribution remain with the relevant sources.

The underlying numerical calculus is attributed to Mira-Cult, the upstream formalization to Jeff Ketchersid and contributors, and the compiler framework to Andrew James Wade. The 245-state foundation, DNE equivalences, equality orientations, selector compiler and prior closure interpretations are inherited ProveIt work. The raw-profile interpretation, power-chain removal of the last function-congruence clause, RP18V record construction, new combined encoding measurements, increment interface proofs, larger dictionary moves and explicitly scoped new experiment combinations are the research additions in this delivery. No broader historical-priority claim is made.

There is no new proof-assistant serialization of the finite-theory equivalence, no represented PA endpoint, no proof of consistency of ZFC, and no certified binary table below245. The archive is intended as reproducible research for the next compiler or state-reduction attempt.
