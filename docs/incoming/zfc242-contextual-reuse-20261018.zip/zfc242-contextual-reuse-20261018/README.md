# A 242-state ZFC consistency machine

This archive provides a **242-working-state**, binary, single-tape machine,
including initialization, with one separate halt state. Every transition moves
left or right. It starts in state 0 at head 0 on the all-zero two-way infinite
tape. The canonical dispatcher is 86, and the halt label is 242.

The exact ordinary mathematical conclusion is

\[
\mathrm{ZFC}\vdash\bigl(\neg\operatorname{Halt}(M_{242})
\leftrightarrow\operatorname{Con}(\mathrm{ZFC})\bigr).
\]

It follows by an explicit arbitrary-tape halting-equivalence theorem with the
pinned Combined243 construction and that construction's inherited ordinary
calibration. The new relative theorem and all its local premises are given in
`report.pdf` and `report.tex`. No new Lean/Rocq endpoint or complete internal PA
consistency calibration is claimed.

## Exact change

From Combined243 in ProveIt commit
`e58338db7545909907e07a7603e8eb88625c527a`, delete inherited state 27 and change:

| Old row | Old action | New action |
|---|---|---|
| 15 / 0 | `0 R 21` | `0 L 32` |
| 18 / 0 | `0 L 27` | `0 L 15` |
| 47 / 0 | `0 L 27` | `0 L 15` |
| 65 / 0 | `0 L 27` | `0 L 15` |

All 480 other retained rows are unchanged. No transition targets deleted 27.
Inherited start/dispatcher/halt are 95/96/254. The complete dense renumbering is
in `machine/renumbering.json`.

The prior QT source rotation makes every incoming transition to state 18
write zero and move right. Together with the analogous facts at 15, 47, and 65,
this proves the old-side invariant: these four states have a zero immediately
left of the head, and state 27 always scans zero. Mapping old 27 to new 15
simulates every old step in one new step except old 15/0, which uses the
three-step path `15 -> 32 -> 45 -> 21`. Its two visited tape cells are zero,
and it has exactly the original complete endpoint.

If `k(n)` counts old 15/0 visits before time `n`, synchronized times satisfy
`theta(n) = n + 2*k(n)`. Thus infinite old runs give infinite new runs; halts
correspond exactly. The proof works for arbitrary initial tapes at old start
95 or dispatcher 96, without a consistency assumption.

## Executed verification

| Check | Result |
|---|---|
| Complete finite premises for invariant and state map | 7,696 admissible five-cell/control cases; all 484 mapped row identities |
| Independent checkpoint proof audit | Four exceptional blocks and 480 ordinary rows |
| Blank startup, sparse and dense simulators, both numberings | 407,979 transitions; identical complete baseline frame |
| Affine runtime | All 8,390 source cases |
| Expanded symbolic runtime | All 8,390 cases; 2,314,880 symbolic rules; all 484 rows |
| Literal instruction fixtures | All 8,390 cases; 6,473,406 transitions; all 484 rows |

The universal mathematical statement follows from the explicit invariant and
induction proof. The finite execution controls and the inherited Python
symbolic-induction checker have their respective scopes recorded separately.

## Reproduce

Python 3.12 was used; no nonstandard Python dependency or network is needed.
Run with assertions enabled. Choose an output directory outside this package
that does not already exist:

```sh
python3 -B code/reproduce.py --output /tmp/zfc242-check
python3 -B code/reproduce.py --expanded --output /tmp/zfc242-full
```

The expanded replay takes several minutes. The supplied executed record is in
`evidence/expanded-runtime.json`; its driver hashes its exact inputs before
and after execution. The archive includes the unchanged small dependency
closure of the inherited expanded checker, its source table, and notices.

Build the report using `make pdf`, or run `pdflatex report.tex` twice.

## Independent formalism result

`research/formalism_dispatch/` includes an additional precise satisfiability
equivalence and a complete serialization experiment: 2,324 bits become 2,194
bits, with 18 equations. It replaces four operations by a dispatch function
whose selector coordinate stays outside the interpreted equality quotient.
All 203 function partitions were checked. This is a finite equational input
for another possible backend; it is **not** another TM state reduction.

## Exact machine hashes

- Canonical:
  `ef8c07f372c76a73c021f51801f16f28f1e4ca5ead2d4ce6780c2a245a0db245`
- Inherited:
  `c8ef2f44d25fee6813164cc59ec05061799397da8cf7f0ea7baab63d32d76e02`
- Pinned Combined243 inherited input:
  `4207fc3d1bb16f3c64c3cff0980eaa1486160c3f467aee7685740a39e3df7300`

## Attribution and scope

The original 254-state calculus/program and interpreter are credited to
Mira-Cult, the end-to-end Rocq development to Jeff Ketchersid, and the compiler
to Andrew James Wade. The intervening ProveIt source, routing, initialization,
QT rotation, and compensation contributions remain credited to their prior
sources. This report adds the contextual return fold and its proof, independent
audits, and the separate dispatch-packing experiment. Inherited licenses and
notices are preserved under `reference/`.

No absolute consistency, unconditional nonhalting, global minimality, or
two-sided independence from bare consistency is claimed.
