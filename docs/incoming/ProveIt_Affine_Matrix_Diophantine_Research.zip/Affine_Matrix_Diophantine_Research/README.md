# Affine Matrix Inputs and Diophantine Universality

**Sharp rigidity, exact period bounds, and computation with existential witnesses**  
Research report prepared for Vladimir Reshetnikov — October 2, 2026.

## Files

- `article.pdf`: the 25-page research article.
- `article.tex`: complete standalone LaTeX source, with its bibliography embedded.
- `verify.py`: exact-arithmetic reference implementation and finite verification suite.
- `verification.json`: the recorded successful run (91,142 cases).
- `SOURCE_AUDIT.md`: repository snapshot, source interfaces, claim provenance, and limitations.

## Principal results

For an affine integral curve `L(n)=C+nD` that is unimodular identically, and any fixed subgroup of `SL_d(Z)`, the integer membership set is either finite or exactly periodic. If `C^-1 D` has nilpotency index `k+1`, its finite membership set has at most `k <= d-1` elements. Every prescribed nonempty finite set of at most `k` integers is attainable in dimension `k+1`.

The curve's evaluations generate a free abelian group with the exact basis `I+N, I+2N, ..., I+kN`. Their canonical exponent coordinates are

    lambda_i(n) = binomial(n,i) * binomial(k-n,k-i).

In the full-rank intersection case, if the quotient exponent is `e`, the sharp universal period is

    P_k(e) = product over primes p dividing e of p^(v_p(e) + floor(log_p(k))).

Combining the all-dimensional affine lower bound with the *existing* quadratic matrix-input construction in ProveIt makes input degree two sharp even when dimension is unrestricted. The upper bound is attributed and reconstructed, not claimed as new.

A separate explicit gadget represents multiplication by a jointly affine `6 x 6` unimodular matrix tested against a fixed free abelian subgroup, with one uniquely determined auxiliary coordinate. It compiles a circuit with `g` multiplication gates into dimension `6g+2`, with `2g` uniquely determined added integer coordinates and an explicit quartic sum-of-squares certificate. Together with MRDP this explains how existentially quantified affine inputs recover universal computation even in a commutative unipotent substrate.

The article also proves the commuting-polynomial extension, single-fold certificates for the rigid languages, a uniformity obstruction, and one-witness decidability in the printed block-cyclic model. It proposes ten continuation projects.

## Reproduce the finite checks

Python 3.10 or later; standard library only:

    python3 verify.py --output verification.replayed.json

On Windows, use `python` instead of `python3` when appropriate. Run without `-O`; the suite relies on assertions and refuses optimized execution. All arithmetic is integral or exact rational arithmetic using `fractions.Fraction`. No network connection, numerical solver, or computer-algebra package is required.

A successful run prints `"status": "PASS"` and `"total_cases": 91142`. Each recorded case can contain several assertions. The receipt is deterministic, with seed `20261002`.

The `Circuit`, `Gate`, and `Affine` objects in `verify.py` provide a readable executable source format, causal validation, witness construction, matrix-block evaluation, and a quartic checker. They are not a general symbolic circuit optimizer.

## Rebuild the PDF

Use a normal TeX Live or MiKTeX installation containing the packages in the preamble:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

A further run may be needed after an edit that changes the table of contents. No BibTeX run or external bibliography file is necessary.

## Status and limits

The main lower-bound and period proofs are given in ordinary mathematics. The new results have not been compiled in Lean or Rocq. The finite checks support the implementation and examples; they do not prove the unbounded theorems.

The report extends the inspected ProveIt source boundary. Global publication priority is not established. It does not claim to lower the repository's reported 87-operation fixed universal-polynomial benchmark, to instantiate a universal Higman matrix subgroup, to certify arbitrary matrix words with a newly counted fixed polynomial, or to settle finite-fold/single-fold MRDP. Additional circuit coordinates are unique conditional on the source witnesses; source-witness multiplicities are not removed.

No repository files were modified. The ZIP is a standalone research package.
