# Divisor marked assemblies and their factorial core inverse

This package studies OEIS A294363,

    a_n = n! [z^n] exp(sum_{k>=1} d(k) z^k).

The main deliverable is `divisor_assembly_asymptotics.pdf`, with editable LaTeX in `divisor_assembly_asymptotics.tex`.

## Results

- An explicit multiplicative equivalent for a_n/n!, retaining the entire nested-log hierarchy through Lambert W
- Arbitrary finite saddle/Edgeworth corrections with a minor-arc proof and a rational coefficient generator
- First and second relative corrections in closed form; exact coefficients through fifth order in the replay
- An explicit all-orders factorial-core inversion, including an absolute-o(1) inverse with a +1/4 term
- Smooth upper/lower envelopes and the required qualification at discrete threshold jumps

The methods are classical. The note does not claim priority, a new general method, effective remainder constants, exponentially small secondary sectors, or formal proof-assistant verification.

## Reproduce the checks

Requirements: Python 3, SymPy, and mpmath.

    python verify_divisor_assembly.py

The script computes exact integers through n=1200, generates coefficients symbolically through t^5, independently verifies the two-loop formula, checks Mellin signs, and evaluates the inverse. It rewrites `coefficients.txt` and `verification.json` in its own directory. The recurrence calculations use exact integers; floating-point diagnostics use 90 decimal digits.

To rebuild the PDF on a standard TeX installation:

    pdflatex -interaction=nonstopmode -halt-on-error divisor_assembly_asymptotics.tex
    pdflatex -interaction=nonstopmode -halt-on-error divisor_assembly_asymptotics.tex

Packages used: geometry, amsmath, amssymb, amsthm, mathtools, booktabs, fontenc, lmodern, microtype, hyperref.

## Provenance and scope

Primary references and theorem-level prior-art distinctions appear in the PDF. `provenance.json` records the public literature links and the bounded read-only repository duplicate checks. No repository or OEIS write was made.

Independent audit details are supplied separately in the final release package. Numerical agreement supplements, but does not replace, the mathematical proof.
