# Polynomial-loss restriction in Gowers's Szemerédi argument

**Fejér filters, density-sensitive moments, and finite-field systems**  
Research manuscript prepared for the ProveIt project, 6 October 2026.

## Contents

- `article.pdf`: the 21-page typeset manuscript.
- `article.tex`: self-contained LaTeX source, including its bibliography.
- `verify.py`: reproducible finite arithmetic and numerical audits.
- `verification_results.json`: results of the completed audit run.
- `build.sh`: reruns the audits and compiles the manuscript three times.
- `source_manifest.json`: source provenance and the inspected repository snapshot.

## Main result

Write T_m(B) for the number of ordered solutions of the balanced additive
relation with m = 2r >= 4 variables, and G_m(B, phi) for the number also
respected by phi. Both counts include repeated entries.

For prime N, a nonempty B in F_N of density beta, and 0 < alpha, eta <= 1,
assume G_m(B, phi) >= alpha |B|^(m-1). Set

    L = ceiling((m+1)/(alpha eta)).

If

    N >= 2 L^m (2L-1)^(m-1) beta^(-(m-1)),

there is B' contained in B with

    G_m(B', phi) >= (1-eta) T_m(B')
    T_m(B') >= |B|^(m-1)/(2 eta L^m)
            >= alpha^m eta^(m-1) |B|^(m-1) / (2 (m+2)^m).

For m = 16, this gives a polynomial-loss quantitative replacement for the
printed Lemma 9.3 in its prime-modulus setting. The manuscript proves the
weighted and vector-valued version with a separate characteristic condition.

The exact graph-moment inequality removes an additional density loss from
the input to Corollary 9.4. A separate theorem in fixed characteristic
handles translation-invariant systems and records the rank of the relations
broken by phi. The manuscript also proves a limitation of a specified
scalar expectation certificate, not of all restriction methods.

## Scope

This is an unrefereed mathematical manuscript with written proofs.
Bibliographic priority has not been established. It does not claim a new
global bound for Szemerédi's theorem or that the extremal extraction problem
has been settled. The new results were not compiled or kernel-checked in
Lean. No unverified Lean module is included.

The repository's inspected `lemma_9_3` has an all-moduli interface. The new
cyclic estimate has a primality hypothesis and is not a drop-in proof of
that broader statement. Section 9 of the manuscript explains this difference
and gives a staged formalization plan.

The finite computations check particular instances and identities; they do
not replace the general proofs. The displayed sufficient size thresholds
are very large and are not claimed to be optimal or practical.

## Reproduction

Requirements: Python 3.10 or newer, and a LaTeX installation with pdfLaTeX
and the packages named in `article.tex` (including AMS packages, Latin
Modern, microtype, booktabs, enumitem, hyperref, xurl, and fancyhdr).
NumPy is optional: without it, the exact standard-library audits still run,
but the independent direct numerical phase averages are marked skipped.

From the directory containing these files:

    python3 verify.py
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

On a Unix-like system, the equivalent command is:

    bash build.sh

The seed is 20261006. A successful audit ends with `"status": "PASS"` and
rewrites `verification_results.json`. Small differences in floating-point
rounding are possible across NumPy versions. All other listed arithmetic
checks are exact.

## Completed checks

The supplied run completed 1,016 exact Fejér signal checks, 4,109 graph-moment
inequalities, 3,522 equality classifications, 48 exact generic good/bad
survival checks, 16 independent direct phase averages, and 96 exhaustive
scalar-linear-functional rank checks. The direct phase discrepancies were
below 2.1e-17 in that run. Collision and low-characteristic counterexamples
are discussed explicitly in the manuscript.

The final PDF was compiled successfully with resolved references and no
reported overfull/underfull boxes. All pages were rendered for layout
inspection. These build and layout checks are distinct from mathematical
formal verification.

## Sources

The principal mathematical source is W. T. Gowers, *A new proof of
Szemerédi's theorem*, Geometric and Functional Analysis 11 (2001), 465–588,
DOI 10.1007/s00039-001-0332-9, especially Section 9, pages 515–518.
The repository snapshot is
`dca9f06383ccdfc2ed208ccb7c9882214fdb09ac`.
See the in-document bibliography and `source_manifest.json` for exact URLs.
No copy of the original paper, repository source, or font files is included.
