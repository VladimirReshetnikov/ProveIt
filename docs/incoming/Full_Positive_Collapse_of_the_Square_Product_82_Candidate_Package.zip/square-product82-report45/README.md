# Research Report 45

## Result

For every fixed genuine compiler tuple inherited by the auxiliary
square/product 82-operation candidate, and every positive ordinary input,
there are infinitely many strictly positive 18-witness tuples that zero
the complete candidate polynomial. All fixed numerals and the input are
preserved. Every constructed tuple has even main Pell coordinate c, a
main Pell index different from the actual packed index, and nonsquare
auxiliary coordinate F_aux.

Specializing to the genuine compiler of the empty computably enumerable
set proves failure of this candidate's inherited input-language
representation. This does not rule out a different, unprovided compiler.
It is not a new universal-operation bound or a priority claim.

This is distinct from Report41's first-index deletion and Report43's
free-coefficient83 candidate. The latter's ordinary-input language question
remains open. The validated baseline stays 84 = 47M + 37A, with 18 strictly
positive witnesses and exact degree 187. The present failed candidate is
82 = 45M + 37A, degree 185.

## Read the article

- Research_Report45.pdf is the complete standalone article
- Research_Report45.tex is its editable LaTeX source
- source_pins.tex and source_rows.txt are local inputs for source provenance
  and the complete inert 82-row appendix
- packets/ contains the research proof/checker and separate independent
  audit/checker as a path-preserving pair
- checks/ records the fresh release checks and toolchain
- RECOVERY.json distinguishes recovered source bytes, reconstructed
  research files, and newly authored report files
- MANIFEST.json authenticates all final release files except itself

The article includes the all-input theorem and empty-set specialization,
all three fixed-mask residues modulo three, exact power-of-five CRT,
packing bounds, full Pell estimates, the shared input loader, the matched
negative index/transport branch, even-c auxiliary completion, the strict
nonsquare interval, all 18 witnesses, source identity and research questions.

## Source identity

Repository: VladimirReshetnikov/ProveIt

Commit: 6ce2dcaaf49d28de43ce9396a094643308fb0595

Candidate:
https://github.com/VladimirReshetnikov/ProveIt/blob/6ce2dcaaf49d28de43ce9396a094643308fb0595/Computability/HilbertTenthProblem/Papers/research-wip/native-stream-queue/complete82_auxiliary_square_product_chart.md

Repository review:
https://github.com/VladimirReshetnikov/ProveIt/blob/6ce2dcaaf49d28de43ce9396a094643308fb0595/Computability/HilbertTenthProblem/Papers/research-wip/native-stream-queue/review_complete82_auxiliary_square_product_chart.md

The candidate, its gate ledger, formal degree, forward identity, and
earlier conditional auxiliary results are credited to those sources.
The later full counterfamily and its independent audit are separately
identified in the research packets.

A workspace replacement interrupted authoring. All eight immutable
repository snapshots were fetched again and matched their prior SHA-256
pins exactly. Local research files were recovered from retained records,
freshly reviewed and rechecked. Reconstructed files receive fresh hashes;
a historical pin authenticates a recovered file only when its bytes
actually match. The recovery record makes those distinctions explicit.

## Replay from any working directory

Keep the complete extracted folder structure. Replace REPORT45 with its
absolute path:

    python3 REPORT45/replay.py
    python3 -O REPORT45/replay.py

The wrapper checks the complete packet inventory, copies both sibling
packets into a private temporary directory, and runs each inspected
independent checker and the three-case tamper checker both normally and with -O.
It verifies both packet manifests and checks exact receipts
and verifies that neither the temporary packet bytes nor the release
packet bytes changed. The audit checker's receipt write occurs only in
that temporary copy. The relative sibling names are preserved.

These are bounded corroborative tests. Necessary-mask diagnostic numerals
are not asserted to be genuine compiled programs. Large outer checks do
not construct X = 2^p or its Pell coordinates. Small exact Pell fixtures
test component lemmas rather than a full compiler instance. The complete
unbounded theorem is proved in the article.

Only inspected independently authored checkers and the new report
utilities execute. Upstream Python, saved circuit schedules and compiler
recipes are read only as source bytes or JSON. There is no repository
write, physical experiment or public publication.

## Rebuild and authenticate

Python 3.8 or later with its standard library is sufficient for arithmetic
replay and ZIP inventory checks. The tested Python, zlib, TeX and Poppler
versions are recorded in checks/toolchain.json.

A PDF rebuild needs pdflatex with the packages named in the source:

    python3 REPORT45/build_pdf.py --output /tmp/Report45-rebuilt.pdf

Use a new output path; the script preserves existing files. If the managed
image has TeX package sources but no generated format/font caches, the
builder creates private temporary caches from the already installed
vendor files. It does not download or install software, and disables TeX
shell escape. It performs three LaTeX passes and rejects overfull boxes or
unresolved references.

Verify and rebuild the archive:

    python3 REPORT45/verify_release.py
    python3 REPORT45/archive_release.py --output /tmp/Report45-rebuilt.zip

The final PDF and archive are reproducible byte for byte on the recorded
toolchain. The build fixes the source epoch and suppresses volatile PDF
metadata. The ZIP uses sorted entries, fixed timestamps/permissions and
fixed compression. Different TeX/font or compression versions may change
output bytes without changing the proof or source pins.

The top-level manifest excludes only its own bytes. The archive's own
SHA-256 is supplied outside the ZIP to avoid a self-referential digest.
Page renders and temporary TeX intermediates are intentionally excluded.

