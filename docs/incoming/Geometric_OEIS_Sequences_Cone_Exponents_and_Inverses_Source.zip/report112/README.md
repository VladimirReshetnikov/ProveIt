# Logarithmic asymptotics for geometric counting sequences

Report 112, 2 October 2026

## Main results

This package contains a self-contained research report and reproducible exact checks for:

- A377922: p_n = (9/2)^n n^(-1-pi/acos(9/16)+o(1))
- A377920: s_n = (16/3)^n n^(-1-pi/acos(22/27)+o(1))
- A377921: b_n has the same logarithmic power as A377920, using an explicit rooted six-face sleeve injection and s_(n-6) <= b_n <= s_n for n >= 8

All three generating functions are not D-finite. The first-threshold index has the expansion log(y)/log(Gamma) + alpha*loglog(y)/log(Gamma) + o(loglog(y)), without assuming monotonicity.

The exponential growth constants for the first two families were proved in 2023 by Fusy, Narmanli and Schaeffer. This report establishes the logarithmic powers. It does not establish multiplicative constants, full equivalents, limiting ratios, correction expansions, or an O(1) inverse remainder. A377923 counts different objects and is excluded.

## Read first

- `report112.pdf`: complete mathematical report
- `report112.tex`: editable source, with references embedded
- `validation/sources.json`: source ledger and exact roles
- `checks/README.md`: what each exact check does and does not prove
- `validation/quality_summary.json`: reader-facing validation scope
- `manifest.json`: strict inventory with SHA-256 hashes and byte sizes

The archive contains only reader-facing files. It contains no third-party paper PDFs. Source links are included in the report and source ledger.

## Requirements

- Python 3.10 or newer
- SymPy 1.14.0, recorded in `checks/requirements.txt`
- pdfTeX / pdfLaTeX and a normal TeX distribution with the packages named at the top of `report112.tex`, including Latin Modern, AMS mathematics, geometry, microtype, enumitem, fancyhdr and hyperref
- Poppler is optional for independently rendering the final PDF

No command below installs software or accesses the network. Install the dependencies in your preferred environment before running the checks. The supplied PDF is ready to read without installing TeX.

## Exact checks

From the extracted `report112` directory:

    python3 integrity.py
    python3 -O integrity.py
    python3 checks/validate.py
    python3 -O checks/validate.py

The main checker uses explicit guards that remain active under Python optimization. It reconstructs the kernels and original-walk finite counts independently of the displayed decimal exponents. The suite also checks finite sleeve topology, rotations and root recovery. These finite tests support the algebra and examples; the all-map injection and analytic asymptotics are proved in the report, not certified by enumeration.

Run the named mathematical and schema mutations, with an isolated fresh-copy replay, using:

    python3 checks/run_validation.py --output tmp/local-check-results

The runner requires each mutated fixture to fail with its expected diagnostic, rather than accepting a crash or syntax error as success. The unmodified inputs must retain their hashes. Supplied baseline results are in `checks/results`.

Run package-level corruption tests using:

    python3 integrity_corruption_test.py
    python3 -O integrity_corruption_test.py

These tests operate only on temporary copies. They check altered source/PDF/checker/fixture bytes, missing and unexpected files, malformed manifests, unsafe paths and symbolic links.

## Rebuild the PDF

    python3 build.py

The builder performs two clean builds and requires byte-identical PDFs. It uses a fixed source epoch, removes variable PDF date/identifier metadata, supplies writable TeX caches and generates its own pdfLaTeX format. Each clean build runs three LaTeX passes. Undefined references/citations and overfull boxes are fatal quality-gate failures.

Byte equality is expected with the same TeX engine, package and font versions. Different TeX distributions can produce a visually equivalent PDF with different bytes; that is a tooling difference, not a mathematical discrepancy. The recorded build used pdfTeX 1.40.26 (TeX Live 2025/dev/Debian), Python 3.12.14 and SymPy 1.14.0.

## Fresh archive replay

Given the original ZIP and a destination that does not yet exist:

    python3 replay.py --archive /path/to/report112_source_checks.zip --out /path/to/new-replay-directory

This validates archive paths and exact inventory before extraction. In the fresh extraction it runs ordinary and optimized integrity checks, exact checks, mutation campaigns, package corruption tests, and a double-clean PDF rebuild. It requires the rebuilt PDF to equal the packaged PDF, rechecks package integrity, and verifies that the ZIP itself did not change. Results and stdout/stderr logs are written outside the extracted package.

`seal.py` recreates a deterministic ZIP from an already verified manifest. `integrity.py --generate` deliberately replaces the manifest from current deliverable bytes; it is a maintenance operation, not a substitute for verifying the supplied manifest. Build/cache/render folders named `build`, `tmp` and `qa` at package root, and Python `__pycache__` directories, are excluded from delivery. Unexpected files elsewhere are rejected.

## Boundary and initialization cautions

- Corner finite pruning for horizontal-axis endpoints cannot blindly be reused for fixed endpoint (1,1) at the truncation edge. The checker uses the enlarged endpoint-safe budget described in its README
- Schnyder time is the number of SE-plus-faces aggregates, not the number of elementary face steps
- The formal auxiliary s'_0 = 1 is a walk initialization outside the genuine size-zero family. Actual s_0 through s_3 are 0, 0, 3, 2, and the positive shift relation begins at n = 4
- A377921's all-index lower bound comes from the rooted sleeve injection. The generating-function convolution alone would yield only a fixed-window lower bound

## Proof and validation scope

The report presents the full probabilistic argument, exact model hypotheses, boundary equivalence, phase covariance correction, original-versus-aggregate time, rooted sleeve construction, non-D-finiteness proof and inverse analysis. Exact finite arithmetic cannot prove an FCLT, local limit theorem, cone asymptotic, or all-map injection. A source ledger, proof review and reproducible calculations are complementary forms of validation, not interchangeable ones.
