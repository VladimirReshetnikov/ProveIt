ONE INSPECTION IN EXPECTATION
Exact randomness thresholds for infinite hat guessing,
endpoint separation, and arbitrarily small shared entropy
Prepared 4 October 2026 for Vladimir Reshetnikov.

MAIN RESULT

Countably many players receive independent fair binary hats and each
guesses their own hat by adaptively inspecting other hats. They cannot
communicate. External randomness is free; each individual hat inspection
is charged. Cost means sup_i E Q_i, averaged over hats and all seeds.
Success means correct-guess excess D_n tends to +infinity almost surely.

Admissible uniform expected caps:
* Deterministic algorithms: [2, infinity).
* Independent private seeds: (1, infinity).
* A finite-valued public seed plus private seeds: (1, infinity).
* A countably infinite supported public seed plus private seeds: [1, infinity).

The endpoint construction has E Q_i < 1 for every individual player,
with supremum 1. The shared variable can have arbitrarily small positive
Shannon entropy. A prescribed countably supported public seed permits
the endpoint exactly when its positive-probability support is infinite.

The deterministic threshold and private sufficiency above 1 were already
in ProveIt. The article proves the remaining almost-sure endpoint
distinctions, finite sign bounds, cumulative-cost necessities, and the
shared-support/entropy refinements. It leaves the positive-probability
private-success threshold open. See SOURCE_AUDIT.txt and the article.

CONTENTS

hat_randomness_frontier.tex  Complete LaTeX article with bibliography.
hat_randomness_frontier.pdf  Compiled article.
verify_finite.py             Exact finite verifier; Python standard library.
results.json                Reproducible results from the verifier.
VERIFY_NOTES.txt            Scope and limitations of the finite checks.
SOURCE_AUDIT.txt             Sources, prior results, and contribution boundary.
Makefile                    Convenience commands for verification and PDF build.

REPRODUCTION

Run from this directory with Python 3.10+ and a standard TeX installation:

    python3 verify_finite.py
    latexmk -pdf -interaction=nonstopmode -halt-on-error hat_randomness_frontier.tex

Alternatively use: make all

The recorded verification run passed 499,552 exact checks. No Monte Carlo
results, network access, or third-party Python dependencies are required.
The finite verifier does not prove the infinite theorems: the article
supplies their English proofs. No Lean or Rocq certificate is included.

The source file is self-contained and uses standard LaTeX packages.
Intermediate LaTeX build files and source-repository copies are excluded
from the ZIP. The audited upstream repository has not been modified.
