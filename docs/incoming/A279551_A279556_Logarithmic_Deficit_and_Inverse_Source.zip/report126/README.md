# Report 126: Commitment trees and the logarithmic stretched exponential scale

This reader package contains the standalone proof, editable LaTeX source,
and an independently implemented exact finite companion for
A279551 (Class 247) and A279556 (Class 759). With mu=8 and mu=9,
respectively, the theorem is

    c n^(1/3)(log n)^(2/3) <= n log(mu) - log a(n)
                            <= C n^(1/3)(log n)^(2/3)

for positive constants c,C and all sufficiently large integers n.
The growth constants are exactly 8 and 9. The result excludes a literal
full equivalent having a fixed negative nonzero n^(3/8) term in its
logarithm. It relies on and credits the exact commitment trees in
Britt and Beaton, arXiv:2512.21943v3, Sections 3.8-3.9. Their Section 4.2
clearly presents the earlier forms as nonrigorous numerical estimates.
The result does not invalidate their finite enumerations.

The proof includes the decorated auxiliary model and completed-path
injectivity, both critical tilts, exact cycle factorizations, a uniform
moderate-local lower estimate, the logarithmic staircase with rounded
heights and exact all-integer length filling at a fixed final state,
exact joint renewal transforms (including zero commitments), a uniform
Catalan estimate, a global spatial barrier, and original-time positive
coefficient extraction under a time tilt.

For N(T)=min{n:a(n)>=T} and s=log(T)/log(mu), it also proves

    ceil(s+d psi(s)) <= N(T) <= ceil(s+D psi(s)),
    psi(s)=s^(1/3)(log s)^(2/3),  0<d<D,

for every sufficiently large real T. The inverse correction is positive.
Both generating functions have smooth boundary values, sharp Gevrey
order 3, and are non-D-finite over C(z). For the boundary derivative
norm and radial derivatives at the positive radius, the logarithm is
3k log k - 2k loglog(k+2) + O(k). The proof includes the exact
Gevrey convention and the arithmetic regular-singular obstruction.
No unique dominant singularity or exterior Delta expansion is asserted.

No exact leading deficit constant, coefficient equivalent, effective onset, calibrated
constant, ratio expansion, all-orders expansion, transseries, or new
numerical fit is asserted. No global priority claim is made.

## Read

- `report126.pdf`: complete standalone mathematical proof
- `report126.tex`: editable source; no downloaded papers are needed
- `checks/README.md`: exact finite-check ranges and provenance
- `data/verification_results.json`: authoritative exact checker output
- `data/negative_results.json`: mathematical/schema mutation output

The finite checks supplement the analytic arguments. They do not prove
uniform analytic estimates or asymptotic limits by finite computation.

## Quick verification

Python 3.10 or newer is required. The authoritative checker uses the
standard library, without network access or installation. Run:

    python3 -B integrity.py
    python3 -B checks/verify.py --output ../report126-results.json
    python3 -B checks/negative_tests.py --output ../report126-negative.json
    python3 -B test_integrity.py

Guards remain active under optimized Python (`python3 -B -O`). The checks
subtree and whole package have closed inventories that reject extra files
or directories, missing members, changed bytes, and symlinks. Inventories
are integrity records, not signatures; they do not protect against
simultaneous malicious replacement of verifier and inventory.

## Complete immutable replay

    python3 -B reproduce.py --output ../report126-replay.json

This verifies the outer inventory, compares exact checks in normal and
optimized Python bytewise, runs mathematical/schema and outer inventory
mutation tests, and builds the PDF twice in clean external directories.
It creates a deterministic ZIP, extracts a fresh copy, repeats exact
checks in both modes and double-clean PDF rebuilding, and requires
byte-identical repacking. Original source inventories are checked again
at the end. All work products stay outside the reader directory.

Without TeX, the following records a checks-only replay:

    python3 -B reproduce.py --skip-pdf --output ../report126-checks-only.json

The complete replay can take several minutes.

## PDF build

Requires pdfTeX/pdflatex and geometry, fontenc, Latin Modern, amsmath,
amssymb, amsthm, mathtools, booktabs, microtype, hyperref, and enumitem.

    bash build.sh
    python3 -B build.py --output ../rebuilt-report126.pdf

The default destination is `../build/report126.pdf`. The builder creates
fresh TeX formats in temporary directories, runs three passes in each
of two clean builds, rejects overfull boxes and unresolved references,
and requires identical bytes. It never overwrites the delivered PDF.
Exact byte replay is tested for the versions in `build-environment.txt`;
other TeX versions may give equivalent content with different bytes.

## Deterministic packaging

    python3 -B repack.py ../report126_reproducibility.zip

The ZIP contains one `report126/` directory. Member order, timestamps,
permissions, and compression settings are fixed. The zlib version is
recorded because it can affect bytes. No intermediate renders, build
logs, downloaded papers, private development notes, or fits are included.

After an intentional author-side edit, regenerate the outer inventory with
`python3 -B integrity.py --write`. This is not validation of an unexpected
change. Changes in `checks/` need that companion's separately reviewed
closed inventory updated as well.
