RANK ULTRA LOG CONCAVITY FOR FOUR VERTEX CORES WITH UNIVERSAL SINKS
October 1, 2026

RESULT
Let H be any loopless directed relation on a four-vertex core C. Add any finite
independent set W of universal sinks: all arcs C -> W, with no other exterior
arcs. Give each physical vertex independent nonnegative tail/head activities.
Count each feasible ordered pair of disjoint endpoint sets once, irrespective
of its number of perfect-matching witnesses.

The support polynomial is rank-ultra-log-concave at EVERY ACTUAL SURVIVING
DEGREE 0 through 4, including all zero-activity faces. No transitivity is needed.
The key strengthening, proved for every finite weighted sink cloud, is

 gamma_2^2 >= 3 gamma_1 gamma_3.

The first-coefficient bound is used with its actual-degree constant, and the
quartic last inequality has an ordinary proof. This is not a renormalization
of the earlier degree-four result. A zero tail activity does not remove that
physical vertex's possible head role.

The same theorem holds for universal sources by arc reversal and role exchange.
When H is the off-diagonal relation of a preorder, adding the diagonal to the
extension yields a preorder, so this includes every such preorder family.

PROOF STATUS
The stronger cubic inequality is computer-assisted: an ordinary, sharp
sink-moment reduction leads to 218 exact rational polynomial certificates.
Their verification covers all 4096 labeled loopless core digraphs. The support
formulas, moment reduction, first and last inequalities, and degree-by-degree
normalization argument are ordinary proofs given in the five-page article.

CONTENTS
 article/universal-sink-all-degrees.pdf  Theorem and complete proof
 article/universal-sink-all-degrees.tex  Editable mathematical source
 certificate-data/                      218 exact certificates and core catalog
 checker/check.py                       Independent standard-library verifier
 discovery/                             Optional numerical discovery scripts
 audit/                                 Independent mathematical/code reviews
 proof-notes/                           Expanded actual-degree closure note
 qa/                                    Final five-page rendering and visual QA
 verify.py                              Integrity and fresh exact replay driver
 build.sh                               Optional PDF rebuilding script
 SHA256SUMS                             Package file hashes

EXACT VERIFICATION
Python 3.10 or later and its standard library suffice. No prior research
archive, network, numerical solver, third-party Python package, or producer
code import is required. Run:

 python verify.py

The driver verifies package integrity and copies the independent checker and
certificate inputs into a fresh temporary directory, then replays every exact
identity and all coverage checks. It does not accept old receipts as evidence
of a new run. To retain the newly generated complete report:

 python verify.py --output /tmp/universal-sink-all-degrees-replay.json

For integrity only, without mathematical verification:

 python verify.py --mode hashes

The independent checker may also be run directly:

 python checker/check.py --source certificate-data --output /tmp/sink-audit

It reconstructs Boolean support formulas for all 4096 labeled cores and their
218 permutation classes, as well as explicit-sink Hall formulas. It then
reconstructs every target and expands 3532 positive rational weighted
polynomial squares exactly, leaving 64298 positive remainder coefficients.
All exponent vectors and signs are checked; coefficients at monomials absent
from the target are checked too. The remainder is reconstructed, not trusted
as a separate input. Numerical discovery is not part of verification.

CERTIFICATE CONVENTION
Variables: u0,u1,u2,u3,v0,v1,v2,v3,A,B. Bit j in row mask i denotes arc i -> j.
The boundary moment substitution is

 E1=A+B, E2=AB+B^2/2, E3=AB^2/2+B^3/6.

Writing G1=gamma_1, G2=2gamma_2 and G3=6gamma_3 at this substitution,

 Q = G2^2 - 2 G1 G3 = 4*(gamma_2^2 - 3 gamma_1 gamma_3).

Each square has schema

 [positive rational weight, [multiplier exponents,
                            [[monomial exponents, rational coefficient], ...]]].

The inner polynomial may have 2 through 24 monomials. Of the 218 certificates,
127 are binomial-only and 91 also contain larger squared polynomials.
All exponents are nonnegative integers and all numbers are exact rational
strings. Large exact denominators do not represent floating-point tolerances.

DISCOVERY
Optional scripts in discovery/ use NumPy, SciPy, and SymPy. Floating-point LP
proposals were reconstructed over the rationals, including exact solutions
of active linear systems, and accepted only after exact expansion succeeded.
These numerical dependencies and producer scripts are NOT required to check
the theorem. Regeneration may find different valid certificates.

BUILD
The supplied PDF is ready to read. Rebuilding requires a standard TeX Live:

 bash build.sh

A PDF rebuild changes metadata and therefore its recorded hash. Verify first,
or rebuild in an extracted working copy. Container-specific TeX path hints
are optional and do not introduce a proof dependency.

BOUNDARIES
The theorem concerns exactly a four-vertex directed core with a finite
universal-sink cloud (or its reversed universal-source family). It makes no
claim for non-universal exterior neighborhoods, larger cores, real-rootedness,
stability, formalization, or global novelty/priority. General independent-role
weighted degree-four preorder ULC remains open outside established families.
All previously approved archives are unchanged and unnecessary for replay.
