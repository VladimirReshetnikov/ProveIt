# Balanced Late-Growing Permutations

**Algebraic constants, D-finiteness, and complete asymptotic expansions**  
Research report prepared for Vladimir Reshetnikov, October 1, 2026.

## Main result

Let T_r(n) count words with n copies of each letter 1,...,r whose every prefix
has average at most (r+1)/2. This is the fixed-row family of OEIS A215561.
For every fixed r >= 2 the article proves

    T_r(n) ~ E_r (rn)! / (rn (n!)^r).

E_r is a positive algebraic number specified by the small roots of a finite
polynomial. In the OEIS normalization, c(r) = E_r / (sqrt(r) 2^((r-1)/2)).

The article also proves D-finiteness for every fixed row, an all-orders
expansion with algebraic correction coefficients, a size-biased geometric
limit law for the number of primitive factors, a single giant primitive
component with independent finite decorations, and eventual strict
log-convexity. It gives a Lambert-W inverse with a discrete rounding bound.
For A215570 (r=5), the first relative correction is

    d_1(5) = -13/10 + 13 sqrt(5)/50.

## Status and boundaries

This is an AI-assisted mathematical research draft, not a refereed article or
a Lean/Rocq formalization. The kernel identity and diagonal-closure theorem
are classical and are attributed in the article. The proofs of the
fixed-composition results are given in full in the manuscript.

The specific conjectured order-three recurrence for A215570 is NOT proved
here, and no explicit recurrence for A215562 is supplied. D-finiteness is an
existence theorem, not a claim to have certified a guessed operator.
The asymptotic expansion is to every fixed algebraic order for fixed r;
there is no claim of uniformity for growing r or of all exponentially
smaller transseries sectors. Numerical root values are not certified
interval enclosures. Literature priority has not been exhaustively checked.

## Contents

- `article.pdf`: 22-page article, with proofs, references, and ten research projects.
- `article.tex`: complete LaTeX source; no external figure or font files needed.
- `code/verify.py`: exact composition DP, bridge/excursion coefficient checks,
  sextic elimination identity, and high-precision numerical diagnostics.
- `code/first_correction.py`: exact algebraic/Gaussian-moment derivation of
  d_1(3) and d_1(5); no recurrence guess or numerical fitting.
- `data/exact_counts.csv`: exact counts, primitive counts, and sums of return counts.
- `data/constants.csv`: algebraic kernel polynomials and numerical evaluations.
- `data/asymptotic_diagnostics.csv`: finite-index comparisons with the limits.
- `data/verification.txt`, `data/first_correction.txt`: recorded successful runs.
- `requirements.txt`: versions used for the recorded Python computations.
- `SHA256SUMS.txt`: checksums of the delivered files, excluding the checksum file itself.

## Reproduce

Use Python 3.10 or later with the packages in requirements.txt. From this folder:

    python code/verify.py
    python code/first_correction.py

The full independent DP covers r=4 through n=30, r=5 through n=15,
r=6 through n=9, and r=7 through n=5. It stores arrays in a box of size
(n+1)^r; use `python code/verify.py --quick` for smaller boxes. That option
overwrites the diagnostic data with the smaller run. Neither mode needs
network access. All assertions passed in the full recorded run.

Build the PDF using a conventional TeX installation with the standard
packages loaded by article.tex:

    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex
    pdflatex -interaction=nonstopmode -halt-on-error article.tex

The extra pass stabilizes the table of contents and cross-references.
The delivered PDF was rendered and visually inspected. The final build
reported no overfull boxes, undefined references, or LaTeX warnings.

## Source audit

Primary sources used include OEIS A215561, A215562, and A215570 (inspected
October 1, 2026); Kauers--Koutschan, Journal of Integer Sequences 26 (2023),
Article 23.4.5, Section 6.1; Banderier--Flajolet, Theoretical Computer Science
281 (2002), 37--80; and Lipshitz, Journal of Algebra 113 (1988), 373--378.
Full bibliographic information is in the article.

The ProveIt repository was inspected at commit
bc4d1fa2b849b644461e3b8c597d77aa1c54b9fe. No unverified theorem from that
repository is assumed by the proofs in this package.
