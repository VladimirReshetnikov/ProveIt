# Subset-only closure kernels for a small ZFC-consistency machine

Research report for Vladimir Reshetnikov, 16 October 2026.

Read **report.pdf**. The complete LaTeX article is **report.tex**; it has an
embedded bibliography and does not depend on separately generated figures.

## Main mathematical contribution

For the reflexively seeded, range-pure closure schema of the pinned seeded
manuscript, the fiber bound `y in b OR y subset b` can be replaced by
`y subset b`. The bound-absorption theorem does not need Extensionality.
Single-element sets and the source manuscript's singleton/subset switch
produce a transitive **superset** of the root before Separation or Union.
That is enough to absorb the membership arm.

Adding Extensionality gives point- and subset-seeded theories deductively
equivalent to full functional-Replacement ZF without Foundation or Choice.
Replacing Extensionality by member-profile congruence gives a directly
calibrated equality-free theory. The paper explains the standard consistency
bridge to ordinary ZFC and the exact remaining machine-proof obligations.

The source switch and other predecessor constructions are credited, not
presented as newly invented. Historical priority and global minimality are
not claimed.

## Results and limits

Under the pinned source's formula-tree metric, the new point/subset/
equality-free subset theories have 65/68/79 nodes, versus 69/72/83 for the
mixed-bound versions. Currying independently saves four further nodes in
both old and new versions. **These are not Turing-machine state counts.**

The reference implementation passed 28 unit tests and the recorded finite
regressions. Our independent audit of the exact pinned 254-state table found
254 strong-bisimulation classes. This excludes only that particular kind
of direct state merge; it is not a global minimality theorem.

**No new smaller TM, compiled TM for the new kernel, exported ZFC/PA proof,
Lean development, or independently rerun Coq end-to-end build is supplied.**
The report contains ordinary mathematical proofs and a concrete implementation
proposal, not a claim that these remaining layers have already been completed.
None of the provided example certificates is a refutation.

## Reproduce

Use Python 3.10 or later; no third-party Python dependencies are needed.
Run without `-O` or `PYTHONOPTIMIZE`, because some regression checks use assertions.

```sh
python reproduce.py
python code/check_certificate.py --file examples/identity.json
python code/check_certificate.py --start 0 --count 10000
python build.py
```

The last command requires `pdflatex` and the standard LaTeX packages in the
preamble. It builds in a temporary directory and writes `report.pdf` plus
`results/pdf-build.log`. The bounded search prints no consistency conclusion.
Resource exhaustion in a Python process is not a logical rejection or an
execution theorem about the idealized unbounded search.

To rerun the independent table audit, supply the pinned table from ProveIt:

```sh
python reproduce.py --table /path/to/zfc_254.tm
```

The repository path is
`lib/jeff-busy-beaver-zfc254/ZF/m254/machine/zfc_254.tm`, at commit
`67086c8d8802ea7b3625a2fc0765d39e2181e335`.
The exact expected SHA-256 is
`d655ce2cf8cccebd21caa21a49f0f9f010960a44b95c17aae6cc425c518954eb`.
Without `--table`, the script explicitly reports that it has not rerun the
TM audit; the delivered `results/tm-audit.json` remains the authoring-session
record. No table is downloaded automatically.

## Files

- `report.tex`, `report.pdf`: the report and source.
- `code/kernel.py`, `code/codec.py`: reference equality-free syntax/checker and finite coding.
- `code/check_certificate.py`: JSON checking and finite-interval search CLI.
- `code/metrics.py`, `code/experiments.py`, `code/test_kernel.py`: measurements and regressions.
- `code/audit_tm.py`: exact-hash guarded, supplied-table audit.
- `examples/`: valid non-refutations and a malformed rejection example.
- `results/`: executed logs, measurements, example verdicts, and PDF QA metadata.
- `notes/CONTRACTS.md`: theorem interfaces and formalization boundary.
- `provenance/sources.json`: exact repository pins, relevant blobs, attribution and scope.
- `reproduce.py`, `build.py`, `SHA256SUMS`: reproducibility scripts and release integrity.

## Attribution and distribution boundary

The 254-state machine is by Mira-Cult; its imported Coq verification is by
Jeff (`jeff87654`). The imported upstream snapshot has its own license
boundary and is excluded from ProveIt's blanket grant according to its README.
This archive includes **no third-party benchmark table or proof sources**.
Our audit results identify the precise input; the audit script accepts the
copy already in the user's repository. The mathematical predecessor is
source 02 of the closure-kernel collection, pinned as documented in the report.
