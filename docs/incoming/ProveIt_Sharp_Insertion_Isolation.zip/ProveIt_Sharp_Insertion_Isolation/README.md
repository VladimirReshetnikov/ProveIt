# Sharp Isolation Thresholds for Binary Insertion

**Exact parameter ranges, extremal centers, mandatory targets, and a complete degree-three classification**

Research manuscript prepared with ChatGPT for Vladimir Reshetnikov, 30 September 2026.

## Main results

The inserted source is the single word `a^m`. Its shuffle with a finite binary target language must fill the entire class with `T` copies of `a` and `g-1` copies of `b`. Exactly one output must have insertion degree `m`; all other outputs must have degree one.

For `m >= 3`, a realization exists exactly when

```
g >= m
T >= max(g*(m-1) + 1, tau(m))
tau(3) = 12
tau(m) = 5*m - 2  for m >= 4.
```

This yields minimum output lengths 14, 21, and 27 for degrees 3, 4, and 5, and recovers the repository's previously known `m^2` value for every `m >= 6`. Degree 2 has minimum length 3.

The paper also proves a complete linear-operation-count feasibility test for arbitrary exceptional gap vectors, a classification and exact enumeration of shortest centers, the precise boundary alternative to the earlier strict escape criterion, and an explicit characterization of mandatory targets. For degree 3 at shortest length, every target language consists of 28 mandatory targets plus a nonempty selection from each of nine disjoint pairs. There are exactly 19,683 languages, with minimum size 37 attained by exactly 512 of them.

## Repository continuation

Pinned ProveIt commit:

```
176e31c5c7ee369edf51edd815463dc029e3faed
```

Continues:

```
SetTheory/Cardinals/docs/reports/automata-and-formal-languages/
  insertion-degree-spectra/article.tex
```

The exact small minima answer Question 21.3. The center classification and mandatory-target theorem answer the explicit questions within Question 21.4. Every realizing target language is characterized by finite predecessor-covering constraints; the entire remaining covering problem is explicitly solved for the shortest degree-three case, not for all degrees.

Suggested integration: an addition to that existing report, not a duplicate standalone report. No repository files were modified or uploaded.

## Status and limits

This is an unrefereed mathematical manuscript with written proofs and reproducible exact finite checks. No theorem in this package has been formalized in Lean or Rocq. The finite checks do not substitute for the universal proofs. Historical priority has not been exhaustively established.

The full-coverage hypothesis, the unary inserted source, the unique exception, and its *maximum* degree are essential. The paper does not solve the unrestricted both-singleton conjecture, general minimum target cardinality, or the shortest-witness problem without full coverage. The minimum target size 37 is proved at the shortest degree-three output length, not at arbitrary lengths.

## Files

- `article.tex`, `article.pdf`: standalone source and compiled 21-page article, with internal bibliography and ten further research questions.
- `code/isolation.py`: exact algorithms, independent finite tests, counting formulas, literal mask enumeration.
- `code/verify.py`: reproducible verification driver.
- `data/verification.json`, `data/verification_run.txt`: executed audit receipt and console output.
- `data/extremal_center_counts.csv`: ordered-center counts through degree 12.
- `data/extremal_orbits_m3_m6.json`: all center orbits through degree 6.
- `data/complete_examples.csv`: full-output example checks.
- `data/degree3_pair_constraints.json`: all nine degree-three pair constraints.
- `data/minimal_degree3_targets.csv`: an explicit minimum 37-word language.
- `data/provenance.json`: repository and source record.
- `SOURCE_AUDIT.md`, `PROOF_AUDIT.md`: attribution, assumptions, and verification boundaries.
- `Makefile`: build and verification commands.

## Reproduction

Requirements: Python 3.10 or later (standard library only); a reasonably complete TeX Live or MiKTeX installation with pdfLaTeX. LaTeX packages include `newtx`, `amsmath`, `amsthm`, `mathtools`, `shuffle`, `microtype`, `tcolorbox`, `xurl`, and `cleveref`.

Compile from the package root:

```sh
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

No BibTeX step is needed. To rerun checks without overwriting shipped evidence:

```sh
python3 code/verify.py --output-dir audit-output
```

Alternatively, `make pdf` builds in `build/` and `make verify` writes to `audit-output/`. The verifier's default output directory is the shipped `data/` directory, so use `--output-dir` when preserving delivered evidence.

The recorded run used Python 3.13.5 and passed every suite. There is no network access or third-party Python dependency in the verifier. The generated files include a fixed-seed sampled suite, explicitly distinguished from the exhaustive suites.
