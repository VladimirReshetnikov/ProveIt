# Polynomial Spectral Blocks for Cigler's Hankel Determinants

This package contains a research draft resolving the coefficient-structure
problem left open around Johann Cigler's Conjecture 17 for the third polynomial
extension of the middle binomial coefficients.

## Main result

For the normalized shifted Hankel determinants

\[
H_K(n;t)=s_{(n^a)}(1^a,t,(t^2)^b),\qquad
 a=\lfloor K/2\rfloor,\quad b=\lfloor(K-1)/2\rfloor,
\]

the article proves a unique decomposition

\[
H_K(n;t)=\frac{1}{(1-t)^a(1-t^2)^{ab}}
 \sum_{q=0}^{K-1}(-1)^q C_{K,q}(n,t)t^{qn+\binom{q+1}{2}},
\]

with `C_{K,q}(n,t)` integer-valued in `n` and polynomial in `t`. It proves

\[
\deg_t C_{K,q}=q(K-1-q),\qquad
\deg_n C_{K,q}=\left\lfloor\frac{q(K-1-q)}2\right\rfloor,
\]

gives explicit leading coefficients in `n`, and corrects the reciprocity sign:

\[
C_{K,K-1-q}(n,t)=\varepsilon_K t^{q(K-1-q)}C_{K,q}(n,t^{-1}),
\]

where `epsilon_K = -1` exactly when `K` is divisible by four. In particular,
the universally printed sign in Cigler's equation (83) fails at the central
block for `K=5`; the displayed polynomial in the source is palindromic, not
anti-palindromic.

## Package contents

- `article.tex` - complete LaTeX source.
- `article.pdf` - compiled 20-page article.
- `code/verify.py` - exact symbolic verifier.
- `data/verification.json` - machine-readable verification record.
- `data/verification.log` - concise recorded run.
- `STATUS.md` - claim and trust boundaries.
- `SOURCES.md` - source and provenance audit.
- `requirements.txt` - Python dependency pin.
- `Makefile` - convenience targets.

## Reproduction

```bash
python -m pip install -r requirements.txt
python code/verify.py --output data/verification.json
python /home/oai/skills/pdfs/scripts/latex_to_pdf.py \
  article.tex -o article.pdf
```

The verifier uses exact symbolic polynomial and rational arithmetic. It checks
finite ranges and examples; the all-index conclusions depend on the proofs in
the article.
