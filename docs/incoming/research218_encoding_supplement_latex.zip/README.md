# Encoding search toward 218 states

The requested target remains unmet: no verified machine with at most 218 working states was constructed. This is a research supplement, not a final machine certificate and not a state-count lower bound.

## Read first

`research218_encoding_supplement.pdf` is the 11-page report. `supplement.tex` is its editable LaTeX. The earlier delivered mathematical companion remains a separate artifact and is identified by its PDF hash in the appendix; it is not replaced or duplicated here.

Key distinctions:
- The exact baseline has a recorded complete 6,167-case arbitrary-natural primitive-interface replay. Its initialization, source-calculus calibration, and a new proof-assistant endpoint are separate obligations.
- The fixed cooperative family has 872 actions. An owned literal filter rejects 834; three further divergence certificates are independently accepted; 35 remain unknown. The four detailed wrong-branch counterexamples have independent replay. No independent full replay of all 834 filter results is claimed.
- Direct09 and direct13 have all-natural source proofs and independently checked focused 115/131-case pilots. Their raw tables each have 220 states and are not certified complete machines.
- The different shared-cancellation raw 220 table remains NOT_PROVED, not concretely refuted.

## Contents and provenance

`replay/` preserves exact owned checkers and inert tables, source lists, maps, and JSON evidence in their original relative directory layout. No received executables are included. `PROVENANCE.json` gives every frozen replay file's SHA256 and source-relative origin. Upstream textual proof notes are hash-identified but omitted; the report contains the relevant arguments. `SHA256SUMS.txt` covers all packaged files except itself. `PACKAGE_CHECKS.json` records the actual portable targeted replay and PDF checks done for this delivery.

## Verify and replay

Use Python 3 with assertions enabled, without `-O`. All checker dependencies are standard-library modules or the included owned Python modules. Unix signal-based watchdogs are used by some search drivers.

First, from this archive root:

    python3 verify_package.py
    sha256sum -c SHA256SUMS.txt

The first command is read-only. It checks byte integrity and cross-receipt consistency, not the underlying universal theorems.

Most substantive replays overwrite their output JSON receipts. Make a copy of the extracted archive before running these commands:

    cd replay
    python3 research218_baseline_audit/replay_cooperative27_counterexamples.py
    python3 research218_baseline_audit/check_27_divergence_certificates.py
    python3 research218_baseline_audit/check_direct_candidates.py
    python3 research218_baseline_audit/check_direct_runtime_pilots.py
    python3 research218_baseline_audit/check_27_tags.py
    python3 research218_baseline_audit/check_27_overlap.py
    python3 research218_baseline_audit/check_27_disjoint.py
    python3 research218_encoding/concrete_filter_cooperative27.py
    python3 research218_encoding/classify_cooperative27_caps.py

These nine portable checkers were actually replayed for the package. Substantive receipt contents agreed after excluding elapsed time and path-dependent input pins. The final cap-classification receipt pins the just-generated concrete-filter receipt, so its hash changes when timings change.

The complete baseline replay is included, hash-pinned, and was not redundantly rerun during packaging:

    python3 research218_encoding/return_contracts.py

It took about 152 seconds in the recorded run. Do not confuse `--limit` partial runs with the full result. Other exact bounded-search drivers and receipts are included for inspection and reproduction; their limits and semantic boundaries are documented in the PDF. These are not open-ended instructions to expand a search.

## Build the PDF

A normal TeX Live installation with pdfLaTeX and the listed standard packages suffices:

    pdflatex -interaction=nonstopmode -halt-on-error supplement.tex
    pdflatex -interaction=nonstopmode -halt-on-error supplement.tex

The output is `supplement.pdf`; the delivered copy is named `research218_encoding_supplement.pdf`. The PDF has been rendered and every page inspected. No received compiler script is invoked by the build or replay commands.
