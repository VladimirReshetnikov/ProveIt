# Optimal Shared-Anchor Interpolation and Labelled Slice Refinement

A research manuscript prepared with ChatGPT for Vladimir Reshetnikov, dated
6 October 2026, for the Ramsey/Gowers development in ProveIt.

## Main results

The article isolates the shared-column interpolation step of Gowers's
Lemma 16.10. A target is certified when it is sampled itself or its class
contains at least `t` distinct sampled columns. Each row has at most `q`
pairwise-disjoint classes on a partial domain of an `m`-column set.

1. A sample of exactly `r` distinct columns, shared by every row, leaves
   at most `t*q*(m-r)/(m*(r+1))` ambient mass uncertified. Arbitrary
   nonnegative row weights and a mean class-count bound are allowed.
   In the affine case, `min(m, ceil(2*q/sigma))` anchors suffice for loss
   at most `sigma`, with no minimum class size.
2. The exact finite minimax loss is the maximum of the sum of one-class
   hypergeometric losses over disjoint size profiles. A finite family of
   all coordinate permutations of an optimal profile attains equality
   against **every** anchor set.
3. The finite optimization is solved explicitly: an optimal profile is
   balanced, with its sizes capped at the first maximum of the one-class
   loss. Exact second differences prove the required initial concavity.
   For affine reconstruction, the cap is the ceiling of an explicit
   quadratic root. No profile search is needed.
4. A uniform Poisson limit gives a sharp sample-complexity law. In the
   affine sparse-sampling regime the coefficient is
   `phi^3 * exp(-phi) = 0.839962094657...`, where `phi` is the golden ratio.
   The article also proves the transition to the column-budget-saturated
   regime, rather than only the low-loss limit.
5. Polynomial and unisolvent-space extensions, additive robustness to
   corrupted points, exact deterministic anchor selection, and labelled
   common refinement are proved. Per-cell candidate lists have size at
   most `r*L + binomial(r,t)*L^t`; the affine case uses `t=2`.

## Scope and status

These are local sampling/interpolation and extremal results. The minimax
lower bound concerns the explicitly specified **certification rule**, not
arbitrary algebraic reconstruction or the complete inverse theorem.

The manuscript does **not** resolve the separate closing-parameter
obstruction in Lemma 16.10, establish a new global Szemeredi bound, or assert
historical priority. It is an unrefereed research draft. No new Lean proof was
compiled or kernel-checked. Existing source improvements are credited,
including sampled-or-anchored recovery and geometric synchronization.

The source comparison is pinned to:

`869289aa38d59354e8dac2213df08ae0dd256415`

No repository files were changed by this delivery.

## Contents

- `article.tex` — standalone LaTeX manuscript with proofs, references,
  source comparison, ten further research questions, and appendices.
- `article.pdf` — compiled 31-page manuscript.
- `code/anchor_selection.py` — exact loss formulas, independent dynamic
  program, closed balanced formula, integer-square-root affine cap,
  weighted sampling model, conditional-expectation algorithm.
- `code/verify.py` — original exact finite and interpolation checks.
- `code/verify_balanced.py` — curvature, shape, closed-profile and cap checks.
- `code/poisson_constants.py` — illustrative constants using Decimal.
- `certificates/verification.json` and `balanced_verification.json` —
  executed exact-arithmetic results: **11,212 cases in total, all passed**.
- `certificates/build_validation.json` — build, reference, and layout checks.
- `data/exact_profiles.csv` and `poisson_constants.csv` — reproducible data.
- `SOURCE_AUDIT.md` — source pins, baselines, and attribution boundaries.
- `FORMALIZATION_PLAN.md` — proposed Lean interfaces and proof dependencies.
- `Makefile` — build and verification commands.

## Reproduction

Python 3.10 or newer is sufficient. The code uses only the Python standard
library. Run from this directory:

```sh
make verify
make constants
make pdf
```

Alternatively:

```sh
python3 code/verify.py
python3 code/verify_balanced.py
python3 code/poisson_constants.py
pdflatex -interaction=nonstopmode -halt-on-error article.tex
pdflatex -interaction=nonstopmode -halt-on-error article.tex
```

The LaTeX source uses standard TeX Live packages, including `newtxtext`,
`newtxmath`, `amsmath`, `amsthm`, `mathtools`, `microtype`, `geometry`,
`booktabs`, `longtable`, `enumitem`, `xurl`, `hyperref`, and `fancyhdr`.
There are no external figures or bibliography-processor requirements.

The finite verification programs use integer and rational arithmetic only.
The decimal constants are approximations, not interval certificates. Finite
checks supplement the general proofs and are not themselves a formal proof.

## Suggested placement

A possible new directory is:

`Combinatorics/Ramsey/Research/GowersSzemeredi/shared-anchor-interpolation/`

This is a suggested placement, not a change already made to ProveIt. Keep the
source audit and status distinctions when incorporating or merging the paper.
The LaTeX labels are currently local to this standalone manuscript and should
be prefixed if merging its source into a larger multi-article document.
