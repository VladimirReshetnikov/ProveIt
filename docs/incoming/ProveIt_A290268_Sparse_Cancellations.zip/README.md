# Sparse Cancellations in the A290268 Tail

Research note prepared for Vladimir Reshetnikov with OpenAI, 1 October 2026.

## Results

- For each fixed offset b=q−2d and compact regular-ratio interval, an absolute O(1/d) phase estimate confines all extra zeros to finitely many bounded-width strips |k−ζd|≤C. There are O(1) candidate zeros per depth, and O(1) in the admissible fixed-order, fixed-offset segment.
- In one fixed positive-area patch of the tail, the nonzero support has density one. There are O(d^(2/3)) actual cancellations per row and O(N^(5/3)) at order N, among C_patch N²+O(N) candidates.
- The derivative term count consequently satisfies a(N)≥β(N)+C_patch(N−1)²−O(N^(5/3)), with C_patch>0.

These results do not settle the full support conjecture, eliminate every exact zero in the patch, or assert global density one. Constants and eventual thresholds are nonnumerical.

## Contents

- `article.pdf`: the complete 10-page companion
- `article.tex`, `geometric_counting.tex`: its LaTeX sources
- `build_local.sh`: build script for the supplied execution environment
- `inputs/Explicit_Finite_Ratio.pdf`: the regular-saddle input with full proofs
- `inputs/Strict_Quadratic_Gain.pdf`: the uniform additive cosine input with full proofs

The two prerequisite PDFs are unchanged copies of the previously reviewed reports. The current article states precisely which analytic results it uses and proves the new rate, curvature, geometric, and density arguments. The exact A290268 source and its inspected repository commit are cited in the bibliography.

## Proof and verification status

The new proofs received independent mathematical review. Every rendered page was visually inspected; the final build has no undefined references or overfull boxes. No experimental finite enumeration is used to prove the results. These arguments are not Lean-formalized or externally refereed, and no exhaustive priority claim is made.

On a standard LaTeX installation, run `pdflatex article.tex` twice. The local wrapper additionally supplies the environment-specific format and font maps.
