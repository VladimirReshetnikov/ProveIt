DIOPHANTINE DEFINABILITY AND TOPOLOGICAL ARITHMETIC
Research manuscript prepared with ChatGPT
4 October 2026

WHAT THIS PACKAGE CONTAINS

glazer_atr0_topological_arithmetic.tex
    Complete standalone LaTeX source, including the bibliography.

glazer_atr0_topological_arithmetic.pdf
    Compiled article with theorem statements, full mathematical proofs,
    a reverse-mathematical coding audit, the repository comparison, eight
    research directions, and two appendices.

verify_finite_lemmas.py
finite_check_results.txt
    Reproducible exact-integer and rational checks of finite algebraic
    details. These checks do not prove the infinite topological theorem
    or constitute a proof-assistant formalization.

SOURCE_AUDIT.txt
PROOF_AUDIT.txt
    Source provenance, research scope, and the in-session proof-review
    record. No external peer review is implied.

Makefile
SHA256SUMS.txt
    Build commands and checksums for the packaged files.

MAIN RESULTS

1. An affirmative proof of Question 1 in Elliot Glazer's 2023 paper
   "A Topological Tennenbaum Theorem", under the explicit coded-model
   convention in Section 2: the theorem is provable in ATR_0.

2. The cofinal strengthening: in an uncountable Polish Borel arithmetic
   presentation, discontinuous additive translations occur above every
   arithmetic threshold under Q + IOpen. Under Q + IDelta_0 + Exp,
   discontinuous multiplications by internal powers of two occur for
   exponents above every arithmetic threshold.

3. An explicit nonsplit, uncountable, locally compact, perfect Polish
   Presburger model with continuous addition. It has a unit-preserving
   ordered additive embedding into the surreals, but no unit-preserving
   additive map into the canonical omnific integers. If preservation of
   the unit is dropped, a displayed shift embeds it into the omnific
   integers. All definable relations in the presentation are Delta^0_2.

The main bridge uses internally provable MRDP over IDelta_0 + ordinary
Exp. A representation proved only on standard natural numbers does not
suffice. The relevant existing ProveIt Lean and Coq modules are compared
with this internal obligation; no repository file has been modified.

STATUS AND LIMITS

The article supplies mathematical proofs and explicitly identifies its
classical arithmetic and coded descriptive-set-theoretic inputs.
Separate in-session audits checked the arithmetic/Borel bridge and the
metric/category argument. The manuscript is not mechanically verified,
externally peer-reviewed, or a claim of exhaustive bibliographic priority.
It gives an ATR_0 upper bound, not a reverse-mathematical equivalence.

The surreal construction is supplementary ordinary set-theoretic
mathematics. The ATR_0 claim concerns the coded topological-arithmetic
theorem and the explicitly stated coding arguments.

BUILD

From this directory:

    latexmk -pdf -interaction=nonstopmode -halt-on-error \
      glazer_atr0_topological_arithmetic.tex

Alternatively:

    make pdf

The source uses standard packages in TeX Live: article, geometry,
fontenc, inputenc, lmodern, microtype, amsmath, amssymb, amsthm,
mathtools, booktabs, longtable, tabularx, array, enumitem, needspace,
xcolor, hyperref, bookmark, and fancyhdr.

No external illustrations, bibliography database, special fonts,
network connection, or shell-escape capability are required.

FINITE CHECKS

    python3 verify_finite_lemmas.py

Python 3's standard library is sufficient. The saved results record the
actual tested finite ranges. An ordinary finite integer cannot model the
external uncountability of an interval in a nonstandard structure, so the
program checks the elementary estimates only where their finite
preconditions hold.

SOURCES AND VERSION

Repository snapshot:
6fef5383b126be343cccc9baf47081ef37ab5afe

Primary motivating paper:
https://arxiv.org/html/2311.13699v1

The source audit lists permanent repository paths, the inspected
historical archives, the exact internal-MRDP citation, and limitations
of the literature search. Third-party source articles and original
repository archives are not redistributed in this ZIP.
