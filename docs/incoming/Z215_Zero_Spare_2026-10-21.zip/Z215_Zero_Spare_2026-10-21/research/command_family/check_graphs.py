#!/usr/bin/env python3
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
def table(p):
 T={}
 for line in p.read_text().splitlines():
  if line and not line.startswith('#'):
   q,b,w,d,z=line.split();T[int(q),int(b)]=(int(w),1 if d=='R'else-1,int(z))
 return T
def canonical(T,mirror=False):
 mapping={0:0};queue=[0];rows=[]
 for q in queue:
  for bit in(0,1):
   w,d,z=T[q,bit]
   if z!=254 and z not in mapping:mapping[z]=len(mapping);queue.append(z)
   rows.append([mapping[q],bit,w,-d if mirror else d,'HALT'if z==254 else mapping[z]])
 assert len(queue)==len(T)//2
 return rows
refs=[ROOT/'baseline/k215.native.tm']+sorted((ROOT/'comparisons').glob('*.tm'));results=[]
for name in('012','021','102','120','201','210','partialcb120'):
 p=ROOT/name/'candidate.native.tm';can=canonical(table(p))
 for ref in refs:
  other=table(ref);rcan=canonical(other);differ=next((i for i,(x,y)in enumerate(zip(can,rcan))if x!=y),None)
  results.append({'candidate':name,'reference':str(ref.relative_to(ROOT)),'candidate_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'reference_sha256':hashlib.sha256(ref.read_bytes()).hexdigest(),'isomorphic':can==rcan,'isomorphic_after_reflection':can==canonical(other,True),'first_differing_canonical_row':differ,'candidate_row':can[differ]if differ is not None else None,'reference_row':rcan[differ]if differ is not None else None})
(ROOT/'graph_audit.json').write_text(json.dumps({'status':'PASS','scope':'Complete rooted deterministic edge-labelled graph canonicalization, read0 before read1; start and halt distinguished. Reflection flips every head direction.','comparisons':results},indent=2)+'\n')
print(json.dumps([r for r in results if r['candidate']=='partialcb120'],indent=2))
