#!/usr/bin/env python3
"""Independent all-row/ordered-case/blank-frame audit. Imports no supplied checker.
This audits saved theorem receipts and the complete concrete startup traces;
it does not reconstruct the full symbolic induction derivations from scratch.
"""
from pathlib import Path
import gzip,json,hashlib
ROOT=Path(__file__).resolve().parent
PHY=(6,2,0,4,3,7,8,5,1)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def table(path):
 T={};start=None
 for line in path.read_text().splitlines():
  if line.startswith('#! start '):start=int(line[9:])
  elif line and not line.startswith('#'):
   q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z));assert(q,b)not in T;assert b in(0,1)and w in(0,1)and d in('L','R');T[q,b]=(w,1 if d=='R'else-1,z)
 states={q for q,b in T};assert all((q,b)in T for q in states for b in(0,1));return T,start
results=[]
for name in ('120','partialcb120'):
 C=ROOT/name;T,start=table(C/'candidate.native.tm');D,ds=table(C/'candidate.tm');m={int(k):v for k,v in json.loads((C/'canonicalization.json').read_text())['map'].items()};assert m[start]==ds
 assert{(m[q],b):(w,d,m[z])for(q,b),(w,d,z)in T.items()}==D
 report=json.loads((C/'runtime/runtime.json').read_text());comp=json.loads((C/'runtime/compression.json').read_text());raws={}
 for fn,rec in comp['outputs'].items():
  zz=(C/'runtime'/rec['compressed_file']).read_bytes();raw=gzip.decompress(zz);assert sha(zz)==rec['gzip_sha256']and sha(raw)==rec['raw_sha256']and len(raw)==rec['raw_bytes'];raws[fn]=raw
 assert report['status']=='UNIVERSAL_MATHEMATICAL_PASS'and not report['failures']
 assert report['table_sha256']==sha((C/'candidate.native.tm').read_bytes())and report['sites_sha256']==sha((C/'sites.json').read_bytes())
 sites=json.loads((C/'sites.json').read_bytes());cases=json.loads(raws['runtime_cases.json']);expected=[(i,positive)for i,(_,op,_)in enumerate(sites)for positive in((False,True)if op=='CD'else(False,))]
 assert [(r['site_index'],r['positive'])for r in cases]==expected
 assert report['proved_cases']==report['expected_cases']==len(expected)
 legacy={int(k):v for k,v in json.loads((ROOT/'runtime-code/inputs/legacy_mapping.json').read_text()).items()}
 for q in {q for q,b in T}|{254}:legacy.setdefault(q,q+1000)
 L={(legacy[q],b):(w,d,legacy[z])for(q,b),(w,d,z)in T.items()};covered={tuple(row)for r in cases for row in r['rows']}
 assert covered<=L.keys();assert all(len(r['duration'])==13 and r['duration'][0]>0 and all(v>=0 for v in r['duration'][1:])for r in cases)
 for block in report['blocks']:
  assert block['arbitrary_contexts']and block['steps']=='v+2'
  for event in block['trace']:
   q,b,w,d,z=event[1];assert L[q,b]==(w,d,z);covered.add((q,b))
 assert covered==L.keys()
 st=json.loads(raws['startup.json']);ones=set();q=start;h=0
 for q0,h0,b,w,d,z in st['trace']:
  assert(q,h)==(q0,h0)and b==int(h in ones)and T[q,b]==(w,d,z)
  assert D[m[q],b]==(w,d,m[z])
  if w:ones.add(h)
  else:ones.discard(h)
  q=z;h+=d
 assert len(st['trace'])==st['steps']and(q,h)==(st['state'],st['head'])and sorted(ones)==st['one_cells']
 assert q==84 and st['status']=='CALIBRATED_DIRTY_ROOT_SEED'
 phys=[None]*9
 for logical,j in enumerate(PHY):phys[j]=st['registers'][logical]
 header=h+64+st['gap'];frame={h-1,header};p=header+1
 for value in phys+st['spares']:
  frame.update(range(p+1,p+value+2));p+=value+2
 assert frame==ones
 results.append({'name':name,'status':'PASS','scope':'Saved ordered cases, affine durations, row coverage, literal block rows and complete blank native/dense trace plus exact frame. The symbolic theorem executor remains a separate ordinary verifier.','states':len(T)//2,'cases':len(cases),'symbolic_rules':sum(r['symbolic_steps']for r in cases),'minimum_duration_constant':min(r['duration'][0]for r in cases),'covered_rows':len(covered),'blank_steps':st['steps'],'head':h,'gap':st['gap'],'registers':st['registers'],'spares_count':len(st['spares']),'spares_all_one':all(x==1 for x in st['spares']),'one_cells':len(ones),'zero_exterior':True,'table_sha256':report['table_sha256'],'source_sha256':report['sites_sha256']})
(ROOT/'verified_output_audit.json').write_text(json.dumps({'status':'PASS','results':results},indent=2)+'\n');print(json.dumps(results,indent=2))
