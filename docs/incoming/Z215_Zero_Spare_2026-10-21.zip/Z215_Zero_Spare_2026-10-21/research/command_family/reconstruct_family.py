#!/usr/bin/env python3
"""Reconstruct command-order research tables from pinned K215 and literal recipes.
No numerical allocator or optimizer is needed. A reconstructed table alone is
not an assertion of blank consistency calibration; consult research_status.json.
"""
from pathlib import Path
import argparse,json,hashlib
import source_language as s
import build221 as b
ROOT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
PATHS=('111','110101','110100101')
def replace_bodies(root,bodies,p=''):
 if p in PATHS:return bodies[PATHS.index(p)]
 if s.leaf(root):return root
 return replace_bodies(root[0],bodies,p+'0'),replace_bodies(root[1],bodies,p+'1')
def rebuild(name,out):
 recipe=json.loads((ROOT/name/'recipe.json').read_bytes())
 source_raw=(ROOT/'baseline/sites215.json').read_bytes();table_raw=(ROOT/'baseline/k215.native.tm').read_bytes()
 assert sha(source_raw)==recipe['base_source_sha256'] and sha(table_raw)==recipe['base_table_sha256']
 base=s.tree(json.loads(source_raw));oldbodies=[s.subtree(base,p)for p in PATHS]
 # The pinned baseline uses NIP,DROP,MP. Recover the named MP,DROP,NIP bodies.
 original=[oldbodies[2],oldbodies[1],oldbodies[0]]
 target=replace_bodies(base,[original[i]for i in recipe['command_permutation']])
 if recipe['refill_cb1']:
  g,(f,(ci,h))=target[0]
  assert ci==('CI',0) and h==(('CD',6),('CC',2))
  target=((g,(f,(ci,(h,('CB',1))))),target[1])
 U=b.read_table(table_raw)
 for q in recipe['removed_states']:
  for bit in(0,1):del U[q,bit]
 for q,bit,w,d,z in recipe['replacement_rows']:U[q,bit]=(w,1 if d=='R'else-1,z)
 raw=b.table_bytes(U);sr=s.compact(s.sites(target))
 assert sha(raw)==recipe['output_table_sha256'] and sha(sr)==recipe['output_source_sha256']
 assert s.graph_arithmetic(s.sites(target))[0]==s.graph_intervals(s.sites(target))
 out.mkdir(parents=True,exist_ok=False);(out/'candidate.native.tm').write_bytes(raw);(out/'sites.json').write_bytes(sr)
 return {'name':name,'working_states':len(U)//2,'rows':len(U),'metrics':s.metrics(target),'source_sha256':sha(sr),'table_sha256':sha(raw)}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--name',default='partialcb120');a=p.parse_args();print(json.dumps(rebuild(a.name,a.out),indent=2))
