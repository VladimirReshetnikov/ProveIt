#!/usr/bin/env python3
"""Independent complete blank-halt replay for rejected command order021."""
from pathlib import Path
import gzip,json,hashlib
ROOT=Path(__file__).resolve().parent;C=ROOT/'021'
def table(p):
 T={}
 for line in p.read_text().splitlines():
  if line and not line.startswith('#'):
   q,b,w,d,z=line.split();T[int(q),int(b)]=(int(w),1 if d=='R'else-1,int(z))
 return T
T=table(C/'candidate.native.tm');D=table(C/'candidate.tm');m={int(k):v for k,v in json.loads((C/'canonicalization.json').read_text())['map'].items()};summ=json.loads((C/'rejected_startup_summary.json').read_bytes());zz=(C/'rejected_startup.json.gz').read_bytes();raw=gzip.decompress(zz)
assert hashlib.sha256(zz).hexdigest()==summ['gzip_sha256']and hashlib.sha256(raw).hexdigest()==summ['raw_sha256']and len(raw)==summ['raw_bytes']
s=json.loads(raw);assert hashlib.sha256((C/'candidate.native.tm').read_bytes()).hexdigest()==s['table_sha256'];q=h=0;ones=set()
for q0,h0,b,w,d,z in s['trace']:
 assert(q,h)==(q0,h0)and b==int(h in ones)and T[q,b]==(w,d,z)and D[m[q],b]==(w,d,m[z]);ones.add(h)if w else ones.discard(h);q=z;h+=d
assert len(s['trace'])==s['steps']==31714 and q==s['halt']==254 and h==s['head']==6 and sorted(ones)==s['one_cells']
print(json.dumps({'status':'REJECTED_ORDER021_BLANK_HALT_REPLAY_PASS','steps':len(s['trace']),'native_halt':q,'dense_halt':m[q],'head':h,'one_cells':len(ones),'zero_exterior':True},indent=2))
