#!/usr/bin/env python3
"""Portable manifest, reconstruction, source, graph and saved-evidence checks."""
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'manifest.json').read_text())
for name,pin in manifest['files'].items():
 raw=(ROOT/name).read_bytes();assert len(raw)==pin['size']and hashlib.sha256(raw).hexdigest()==pin['sha256'],name
for script in('audit_sources.py','audit_verified_outputs.py','audit_rejected_startup.py','check_graphs.py'):
 result=subprocess.run([sys.executable,'-B',str(ROOT/script)],cwd=ROOT,text=True,capture_output=True)
 if result.returncode:raise RuntimeError(script+'\n'+result.stdout+'\n'+result.stderr)
with tempfile.TemporaryDirectory(prefix='zfc-family-reconstruction-')as temp:
 for name in('012','021','102','120','201','210','partialcb120'):
  dest=Path(temp)/name;result=subprocess.run([sys.executable,'-B',str(ROOT/'reconstruct_family.py'),'--name',name,'--out',str(dest)],cwd=ROOT,text=True,capture_output=True)
  if result.returncode:raise RuntimeError(name+'\n'+result.stdout+'\n'+result.stderr)
  for fn in('candidate.native.tm','sites.json'):assert(dest/fn).read_bytes()==(ROOT/name/fn).read_bytes(),(name,fn)
print(json.dumps({'status':'PASS','manifest_files':len(manifest['files']),'exact_reconstructions':7,'source_graphs':'both readers, all six command orders plus scheduler composition','saved_runtime_audits':['120','partialcb120'],'rejected021':'complete native/dense blank-halt trace','graph_comparisons':'exact current table bytes; rooted graph and reflected graph','scope':'No rerun of the symbolic theorem executor; use run_runtime_gzip.py for that.'},indent=2))
