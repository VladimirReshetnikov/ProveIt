# Scheduler/command-order research packet

This packet contains one substantive additional **215-state** consistency machine, `partialcb120`, and the exact successes and failures of a bounded six-command-order search. It does **not** claim a 214-state machine.

## Verified machine

The successful new composition combines the shared-CB1 refill scheduler with command order DROP/NIP/MP. It has 215 working states, 430 rows, 4,752 source primitives and 202 distinct subtrees. The complete runtime proves all 6,177 guarded cases over arbitrary natural registers, gaps and nonempty finite natural spare lists. The complete blank prefix reaches a calibrated root in 88,746 transitions. The saved-output audit checks every case, all 430 rows, positive affine durations, and the entire native/dense startup trace and terminal tape. The source audit checks the exact scheduler tail and the 65-primitive reduction of the actual seed by harmless MP(0).

The ordinary mathematical proof, with the explicitly inherited numerical-calculus and strong compiler theorems, establishes in ZFC that blank nonhalting is equivalent to Con(ZFC). This is not a newly compiled Lean/Rocq theorem.

- [Native machine](partialcb120/candidate.native.tm): start0, dispatcher84, halt254.
- [Dense machine](partialcb120/candidate.tm): working states0-214, start0, dispatcher83, halt215.
- [Exact source](partialcb120/sites.json).
- [Mathematical proof and search accounting](FAMILY_PROOF.md).
- [LaTeX section](family_section.tex).
- [Explicit status of every attempted order](research_status.json).
- [Source audit](source_audit.json), [saved-output audit](verified_output_audit.json), [graph audit](graph_audit.json).

The native machine hash is `4f21c5836598482195191cf3a4f5926062cd14259c25713979e663848b09c584`; the source hash is `5f2df4a6c25098d27b20b744b5f8ab3db6ebc8a37e1f01a9abdafc035297563f`.

## Quick portable verification

Run from this directory with Python3.10 or later. Only the standard library is needed; no optimizer, network, or third-party package is used.

```sh
python3 -B verify.py
```

This checks the complete manifest; reconstructs all seven tables and sources on fresh temporary paths; runs both source graph readers; checks graph nonisomorphism against exact pinned comparison tables; audits the successful outputs; and replays the exact 31,714-step halt of the rejected order021 machine. It does not rerun the expensive symbolic theorem executor.

Individual commands are:

```sh
python3 -B reconstruct_family.py --name partialcb120 --out /tmp/new-partialcb120
python3 -B audit_sources.py
python3 -B audit_verified_outputs.py
python3 -B audit_rejected_startup.py
python3 -B check_graphs.py
```

`reconstruct_family.py` refuses an existing output directory. The other audits reproduce their small saved receipts in place.

## Full quantified runtime reproduction

Choose a nonexistent output directory. This executes the unchanged semantic checker and keeps the two large original JSON outputs in deterministic gzip containers.

```sh
python3 -B run_runtime_gzip.py partialcb120 --out /tmp/new-partialcb120-runtime
```

Require `UNIVERSAL_MATHEMATICAL_PASS`, 6,177 expected and proved cases, 215 working states, no failures, and `CALIBRATED_DIRTY_ROOT_SEED`. The exact saved case and startup JSON bytes are deterministic; compare the resulting gzip files with `partialcb120/runtime/runtime_cases.json.gz` and `partialcb120/runtime/startup.json.gz`. The timing field in `runtime.json` is expected to differ.

The direct uncompressed entry point is also retained:

```sh
python3 -B runtime-code/validate_native.py partialcb120/candidate.native.tm partialcb120/sites.json /tmp/new-uncompressed-runtime
```

The inherited checker uses induction over symbolic unary scans and finite spare-list length. Its finite execution bound is a bound on certificate construction, not on the natural values in the proved domain. It remains an ordinary mathematical verifier, not a proof-assistant kernel. The output audit checks saved theorem receipts and concrete traces and does not reconstruct every symbolic derivation independently.

## Status boundaries

All six command-order sources are consistency-calibrated at safe register roots; that fact does not establish blank initialization of their allocated binary tables. The compact source recipes and tables are retained for all six.

- `120` also has a complete fresh 6,176-case runtime and safe blank prefix. It is a different allocation of the already known order120 source.
- `210` is isomorphic to the accepted composed allocation.
- `012` passes all 6,176 arbitrary-register primitive cases but reaches no calibrated root within ten million tested blank steps. It is research only.
- `021` actually halts after 31,714 blank steps and is rejected. Its complete trace and independent native/dense replay are included.
- `102` and `201` reach no calibrated root within 500,000 tested blank steps. They are research only.

The 18 source-scheduler allocation trials produced no214 result. Unused experimental tables and environment-specific solver scripts are intentionally excluded; the delivered machine/source recipes reconstruct every retained result without a numerical solver.

## Provenance and attribution

The baseline is the accepted primary K215 at repository commit `32498004963846db7655eedce7e94f8c88f6fa8a`. Its native table hash is `9683d6ed9628e6ce407c315b08f5da3d063da94e92706f275ca0f33e8272e4b2`. Exact comparison tables are the accepted order120, composed/source162, source164, and latest q13_cb constructions; their hashes are in the graph audit and manifest.

The shared-CB1 scheduler proof is inherited from the investigation archive introduced at that same commit. Its exact reviewed source sections are preserved under `provenance/`. The numerical calculus, compiler, runtime induction checker, field-reader transformation, source syntax, and previous marker folds retain their original attribution and terms. See `baseline/NOTICE.md`, `provenance/`, and `licenses/`. The current contribution is the explicit composition/allocation, fresh full runtime and blank checks, source and graph audits, and bounded search accounting. No upstream theorem is claimed as newly proved here.
