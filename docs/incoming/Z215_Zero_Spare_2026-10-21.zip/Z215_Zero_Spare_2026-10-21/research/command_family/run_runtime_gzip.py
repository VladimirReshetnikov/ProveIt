#!/usr/bin/env python3
"""Run unchanged native verifier with byte-identical large output sent to gzip.
This changes output transport only, not checker control flow or semantics.
"""
from pathlib import Path
import sys,runpy,gzip,json,hashlib,time,argparse
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('name');ap.add_argument('--out',type=Path);args=ap.parse_args()
name=args.name
OUT=args.out.resolve() if args.out else ROOT/name/'runtime';OUT.mkdir(parents=True,exist_ok=False)
old=Path.write_text
records={}
def save(path,text,*a,**kw):
 if path.parent==OUT and path.name in ('runtime_cases.json','startup.json'):
  raw=text.encode(kw.get('encoding') or 'utf-8')
  with path.with_suffix(path.suffix+'.gz').open('wb') as f:
   with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as g:g.write(raw)
  records[path.name]={'raw_bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'compressed_file':path.name+'.gz','gzip_sha256':hashlib.sha256(path.with_suffix(path.suffix+'.gz').read_bytes()).hexdigest()}
  return len(text)
 return old(path,text,*a,**kw)
Path.write_text=save
sys.argv=[str(ROOT/'runtime-code/validate_native.py'),str(ROOT/name/'candidate.native.tm'),str(ROOT/name/'sites.json'),str(OUT)]
started=time.monotonic()
try:runpy.run_path(sys.argv[0],run_name='__main__')
finally:
 Path.write_text=old
 (OUT/'compression.json').write_text(json.dumps({'scope':'Exact original output text encoded as utf-8 and deterministically gzip-compressed. Checker program/functions unchanged.','outputs':records,'seconds':time.monotonic()-started},indent=2)+'\n')
