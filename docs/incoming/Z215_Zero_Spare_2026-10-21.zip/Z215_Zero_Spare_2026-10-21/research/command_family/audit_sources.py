#!/usr/bin/env python3
"""Finite exact source premises for the six command orders and CB1 composition.
Independent structured and binary-counter CFG resolvers are inherited verbatim
from audit_command_permutation.py, whose original notices are retained.
"""
from pathlib import Path
import json,hashlib
import audit_command_permutation as a
from reconstruct_family import replace_bodies,PATHS
ROOT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
base=a.parse(json.loads((ROOT/'baseline/sites215.json').read_bytes()))
bodies=[a.at(base,p)for p in PATHS];unpermuted=replace_bodies(base,[bodies[2],bodies[1],bodies[0]])
results=[]
for name in ('012','021','102','120','201','210'):
 raw=(ROOT/name/'sites.json').read_bytes();t=a.parse(json.loads(raw));perm=tuple(map(int,name));assert t==a.permute(unpermuted,perm)
 assert a.structured_graph(t)==a.counter_graph(a.sites(t))
 external=lambda r:[x for x in a.sites(r)if not any(x[0].startswith(p)for p in PATHS)]
 assert external(t)==external(unpermuted);assert a.at(t,a.AX_PATH)==a.at(unpermuted,a.AX_PATH)
 selectors,fields,packed=a.selector_audit(t,perm);returns=a.return_audit(t,perm)
 results.append({'name':name,'status':'FINITE_SOURCE_PREMISES_PASS','sha256':sha(raw),'metrics':a.metrics(t),'body_bounds':[a.boundary(a.at(t,p))for p in PATHS],'selectors':selectors,'command_fields':fields,'packed_commands':packed,'normal_returns':returns})
old=json.loads((ROOT/'120/sites.json').read_bytes());new=json.loads((ROOT/'partialcb120/sites.json').read_bytes());ng=a.counter_graph(new);og=a.counter_graph(old)
actions=[['CD',8],['CB',1],['CD',0],['CI',8],['CI',6],['CC',3],['CI',0],['CD',6],['CC',2],['CB',1]]
assert [x[1:]for x in new[:10]]==actions
assert [list(g[2])for g in ng[:10]]==[[2,1],[10],[6,3],[4],[5],[2],[7],[9,8],[6],[0]]
assert new[10:]==old[9:]
shift=lambda i:i+1 if i>=9 else i
for i in range(9,len(old)):assert ng[i+1][2]==tuple(shift(x)for x in og[i][2])
assert all(op not in ('CI','CD')or reg!=0 for _,op,reg in new[10:])
r=[5,0,0,0,0,0,0,0,4];pc=steps=0
while steps==0 or pc!=0:
 assert steps<100000;_,op,k=new[pc];assert op!='CH'
 if op=='CD':bit=int(r[k]>0);r[k]-=bit;pc=ng[pc][2][bit]
 elif op=='CI':r[k]+=1;pc=ng[pc][2][0]
 else:pc=ng[pc][2][0]
 steps+=1
assert r==[5,0,0,0,0,0,0,0,0]
results.append({'name':'partialcb120','status':'FINITE_SCHEDULER_SOURCE_PREMISES_PASS','sha256':sha((ROOT/'partialcb120/sites.json').read_bytes()),'metrics':a.metrics(a.parse(new)),'tail_literal_identity':True,'all_tail_control_edges_preserved':True,'tail_does_not_touch_counter':True,'seed_reduction':{'initial':[5,0,0,0,0,0,0,0,4],'final':r,'source_steps':steps,'command':'MP(0)'}})
out={'status':'PASS','scope':'Exact finite source premises. All-natural command and scheduler proofs are separate ordinary mathematical dependencies. No blank binary startup claim for the unverified orders.','records':results}
(ROOT/'source_audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps([{k:r[k]for k in('name','status','metrics')}for r in results],indent=2))
