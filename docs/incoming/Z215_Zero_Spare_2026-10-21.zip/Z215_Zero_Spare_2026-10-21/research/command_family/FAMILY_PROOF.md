# Verified scheduler/command-order composition and bounded six-order research

## Main secondary result

`partialcb120` is a deterministic binary Turing machine with 215 working states, 430 rows, native start 0, native dispatcher 84, and native halt 254. The separate dense table has labels 0 through 214 and halt 215. It combines the shared-CB1 refill scheduler with command order DROP/NIP/MP. The old command-order variant used the ordinary refill scheduler; the latest shared-CB1 machine used NIP/DROP/MP. This composition has a different source and a different rooted transition graph from both, including after global tape reflection.

The source has 4,752 primitive occurrences, 202 distinct subtrees, maximum address depth 47, and maximum zero run 6. No 214-state result was obtained. The work supplies an additional ordinary-verified 215-state machine and explicit finite search outcomes.

Native table SHA-256:
`4f21c5836598482195191cf3a4f5926062cd14259c25713979e663848b09c584`

Source SHA-256:
`5f2df4a6c25098d27b20b744b5f8ab3db6ebc8a37e1f01a9abdafc035297563f`

## Command permutations preserve consistency calibration

Let the names MP, DROP, NIP be indexed 0, 1, 2. A permutation pi assigns command tag j to command pi(j). AX retains tags c+3. The three command bodies are closed source subtrees at paths `111`, `110101`, `110100101`; their sizes in the original order are 106, 26, 26. The independent structured and binary-counter CFG readers check the whole source, the three selector cases and the symbolic residual case c>=3. They check that each normal command-return wrapper reaches the root and that the AX body and every source path outside the three moved bodies are unchanged.

For any permutation, a finite abstract command word has an exact numerical encoding: replace the tag of each non-AX command by its inverse-permutation tag, keeping its fields and the AX encoding unchanged. Each arithmetic macro and command body therefore implements the same abstract command operation as before. This transport is uniform over arbitrary natural register values; it is not a claim limited to well-formed formula codes. The all-natural soundness invariant inherited from the dominated numerical calculus is unchanged.

The inherited strong compiler is translated command by command by the same tag substitution. Its reset prefix is similarly translated. Its cofinal family starts with an AX tag 3, so the family `P(3,P(Y,P(1,R)))` remains available, with the fixed suffix R replaced by its translated encoding. The pairing function is the inherited Cantor pairing `P(a,b)=(a+b)(a+b+1)/2+b`. For every finite cutoff, choose Y sufficiently large. Thus every command ordering retains consistency calibration from each safe source root under the established source semantics.

This theorem concerns the register source. It says nothing about whether an arbitrarily reallocated binary table reaches such a source root from blank tape.

## The shared-CB1 refill scheduler

Write the logical registers `(N,T,W,A,D,H,X,Y,L)` as indices 0 through 8. At a normal root, A=X=Y=0. Define

- G = (CD8, CB1),
- F = (CD0, (CI8, (CI6, CC3))),
- H0 = (CD6, CC2).

The ordinary source has outer form `((G,(F,(CI0,H0))),B)`. The new source is `((G,(F,(CI0,(H0,CB1)))),B)`, where B is the entire decoder and command body tail.

If L>0, G decreases L and enters B. If L=0 and N=n>0, F transfers n to L and X, the increment/continuation loop restores N=n+1 and X=0, and the new CB1 returns to G. G then decreases L to n-1 and enters B. If n=0, one additional refill produces counter 2 and raw candidate 0. Every case terminates. Only N,L,X change, and X is restored to zero. The exact first ten source actions and every guarded edge in the tail are checked in `source_audit.json`; the tail never changes N.

Once a candidate is underway, each nonhalting command strictly decreases a positive residual list, because the leading list decrement is followed only by unpairing tails no larger than their inputs. Thus each candidate drains. From refill counter n>0, the new scheduler enumerates n-1,n,n+1,..., and from n=0 it enumerates 0,1,2,.... These are cofinal tails. Soundness is unchanged because the scheduler never manufactures a theorem. Completeness follows from the translated strong compiler and its cofinal successful-code family.

Equivalently, at command boundaries relate old counter No and new counter Nn=No+1, with all other registers identical. Their positive-list cases agree. Their empty-list cases enter B with the same list No and preserve the counter difference. The extra root visit is finite. This provides a stuttering simulation with the previously calibrated command-order source.

## Binary realization and actual initialization

The unchanged quantified primitive verifier proves all 6,177 guarded cases of `partialcb120`. Its induction domain includes arbitrary natural primary registers and gap, arbitrary nonempty finite lists of natural spares, and the complete zero exterior. There are 1,698,860 symbolic rule applications; the minimum affine duration constant is 9. All 430 transition rows are covered. This is an ordinary mathematical certificate, not a new proof-assistant kernel theorem.

The complete blank trace reaches native dispatcher 84 in 88,746 steps, head -12, gap 5, with logical registers `(5,0,0,0,0,0,0,0,4)`, 45 unit-valued spare words, exactly 110 one cells, and zero exterior. The independent audit replays every transition in both native and dense tables, reconstructs the full terminal tape from the declared frame, and compares the entire one-cell set.

The first source command is harmless MP(0): the leading decrement makes L=3=P(2,0), and tag 2 still denotes MP in order 120. Its cached implication and operands are zero, so it returns to `(5,0,0,0,0,0,0,0,0)` after exactly 65 source primitives. The source audit checks this finite reduction without invoking the Turing-machine verifier. The counter-offset relation identifies this root with the ordinary order-120 root `(4,0,0,0,0,0,0,0,0)`.

Combining the finite blank prefix, positive-duration arbitrary-register simulation, source calibration, and the repository's numerical-calculus consistency theorem yields the ordinary theorem formalizable in ZFC:

`Halt(partialcb120,blank) iff not Con(ZFC)`.

The nonhalting equivalence follows by negation. This does not assert unconditional nonhalting or a minimum state count.

## What the six-order search did and did not establish

All six command permutations were allocated at 215 states with the same source metrics (202 subtrees, 4,751 primitives, depth 47, maximum zero run 6). Finite decoder-prefix checks passed for each. These synthesis gates did not establish blank initialization.

| Order | Fresh quantified primitive result | Blank initialization result |
|---|---|---|
| 012: MP/DROP/NIP | All 6,176 cases proved | No calibrated root within 10,000,000 tested steps |
| 021: MP/NIP/DROP | Not run | Actually halts after 31,714 steps; rejected |
| 102: DROP/MP/NIP | Not run | No calibrated root within 500,000 tested steps |
| 120: DROP/NIP/MP | All 6,176 cases proved | Exact safe seed in 96,308 steps |
| 201: NIP/MP/DROP | Not run | No calibrated root within 500,000 tested steps |
| 210: NIP/DROP/MP | Transferred graph already accepted | Exact safe seed in 95,726 steps; isomorphic to accepted composed allocation |

The new 120 allocation is nonisomorphic to the accepted 120 allocation, though its source is identical. It has 1,698,845 symbolic rules, minimum duration constant 9, and full 430-row coverage. The more substantive new variant is `partialcb120`, whose refill semantics also change.

A further bounded synthesis sweep combined the shared-CB1 scheduler with the six command orders using three baselines. Every feasible output still had 215 states. Some fresh scheduler/order tables also halted during initialization. These are research failures, not consistency candidates. No exhaustive lower bound was proved. Choosing another existing start state did not rescue order 012 within the 300,000-step-per-state search bound.

## Reproduction

`reconstruct_family.py --name partialcb120 --out NEW_DIRECTORY` uses only the standard library, frozen baseline source/table, and literal recipes. It reproduces exact source and table bytes without an optimizer. `audit_sources.py` checks the finite source premises. `run_runtime_gzip.py partialcb120` invokes unchanged inherited semantic checker functions and deterministically compresses only the two large output JSON files; it refuses an existing runtime output directory. `audit_verified_outputs.py` audits saved ordered cases, affine durations, block rows, complete row coverage and both blank traces. `check_graphs.py` checks complete rooted labelled graph canonicalizations and reflections.

The compression wrapper preserves the original UTF-8 JSON bytes, raw hashes, compressed hashes and sizes. Its output transport does not change the checker functions or induction rules. The independent saved-output audit checks theorem receipts and concrete traces; it does not reconstruct every symbolic induction derivation from scratch. Re-running the unchanged verifier remains the direct reproduction of those derivations.

## Provenance

The command bodies, numerical calculus, compiler, primitive runtime prover and old marker constructions are inherited. Preserve `baseline/NOTICE.md` and the repository's original license/attribution files when integrating this packet. The command-permutation utility is copied unchanged from the `K216_Permuted_Commands_2026-10-21` packet. The shared refill scheduler and q13_cb215 are from the latest investigation archive introduced at commit 32498004963846db7655eedce7e94f8c88f6fa8a. This work contributes the explicit combined allocation, fresh complete runtime, independent source and output checks, graph comparisons, and transparent six-order search accounting.
