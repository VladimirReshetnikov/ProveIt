# Alias-free identity, weakening, and Peirce from two restricted rho8 schemas

Let X be an arbitrary set with any binary operation I, written a→b, and let T be a predicate closed under modus ponens. Suppose T contains all instances of the following two schemas, with every displayed letter universally quantified:

1. L(u,b,c,u).
2. L(z→u,b,c,u).

Here L(a,b,c,u)=((c→u)→a)→((a→c)→(b→c)). Then T contains every instance of

- I: p→p;
- K: p→(q→p);
- P: ((p→q)→p)→p.

No truth constant, zero code, equation I(0,0)=0, injectivity, formula decoder, semantic interpretation, or linear order is assumed. The theorem is proved by the attached22-node finite derivation: two universally quantified axiom leaves and20 explicit-substitution modus-ponens steps. check_alias_free_ikp.py verifies the whole certificate by forward syntactic evaluation alone, with no unification or external prover. Variables in the certificate are metavariable indices, not numerical formula codes.

For numerical coding I_j(a,b)=4P(a,b)+j with j>=0, the operation dominates both arguments. Hence each of the two schema families meets U<=A under every assignment of natural codes. The theorem applies uniformly to every such coding, including the proposed I3/R1/Q0/E2 tag arrangement. It removes dependence on the truth alias for these three particular logical principles.

This result does not yet establish S, implication composition, unrestricted rho8, or the full alternate-encoding consistency calibration. Bounded subsequent searches with more subterm contexts did not produce a checked proof of those missing targets before termination. Their partial search logs are not proof of impossibility. The main215-state zero-spare candidate retains the original implication coding and does not depend on this additional research theorem.

## Reproduction and attribution

Run: python3 -B check_alias_free_ikp.py

The finite certificate is alias_free_ikp.json, SHA-256 feb436894cb3b3bbe65261ede872fed310fc3a4da04c9a1c4148494ab59993da. The22-line search proof is ikp-proof.txt. subterm_search.cpp adapts the ProveIt repository public helper lukasiewicz_search.cpp by replacing its single unrestricted axiom with four subterm families. The successful certificate in fact uses only the first two. The exact successful command is:

subterm_search 43 5 200 I=Cpp K=CpCqp P=CCCpqpp

The explicit substitutions were reconstructed with the separately written repository helper lukasiewicz_cd.py and then checked by the new forward-only checker. The mathematical contribution here is the alias-free two-schema derivation, not the inherited search engine or numerical pairing convention. The unused depth-three families and later broader search do not appear in the proof certificate.
