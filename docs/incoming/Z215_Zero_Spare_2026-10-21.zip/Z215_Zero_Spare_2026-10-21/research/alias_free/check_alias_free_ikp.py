#!/usr/bin/env python3
"""Forward-check the alias-free I/K/Peirce certificate. Standard library only.
No search, unification, implication normalization, truth constant, or numerical
formula decoding is used. A formula is a nonnegative metavariable index or a
binary implication pair. Universal instantiation is explicit in every MP node.
"""
import argparse, hashlib, json
from pathlib import Path

def term(x):
    if type(x) is int:
        assert x >= 0
        return x
    assert isinstance(x,list) and len(x)==2
    return term(x[0]),term(x[1])

def variables(x):
    return {x} if type(x) is int else variables(x[0])|variables(x[1])

def subst(x, env):
    if type(x) is int:
        assert x in env
        return env[x]
    return subst(x[0],env),subst(x[1],env)

def subterm(u,a):
    return u==a or (isinstance(a,tuple) and (subterm(u,a[0]) or subterm(u,a[1])))

def split(x):
    assert isinstance(x,tuple) and len(x)==2
    return x

def row(x):
    pre,post=split(x)
    cu,a=split(pre)
    c,u=split(cu)
    ac,bc=split(post)
    aa,cc=split(ac)
    b,ccc=split(bc)
    assert a==aa and c==cc==ccc
    assert subterm(u,a)
    return a,b,c,u

def parse(s):
    pos=0;names={}
    def go():
        nonlocal pos
        ch=s[pos];pos+=1
        if ch=='C':return go(),go()
        if ch not in names:names[ch]=len(names)
        return names[ch]
    t=go();assert pos==len(s)
    return t

def check(path):
    data=json.loads(path.read_text())
    assert data['format']=='free_implication_explicit_substitution_v1'
    assert data['normalization']=='none' and data['truth_axioms'] is False
    proof=[];counts={};axioms=[]
    for i,n in enumerate(data['nodes']):
        assert n['id']==i
        f=term(n['term']);r=n['rule'];k=r['kind'];counts[k]=counts.get(k,0)+1
        if k=='subterm_rho8':axioms.append(row(f))
        else:
            assert k=='mp_substitution'
            ma,mi=r['major'],r['minor']
            assert type(ma)is int and type(mi)is int and 0<=ma<i and 0<=mi<i
            es=[]
            for label,idx in [('major_substitution',ma),('minor_substitution',mi)]:
                env={int(v):term(t)for v,t in r[label].items()}
                assert set(env)==variables(proof[idx])
                es.append(subst(proof[idx],env))
            ante,cons=split(es[0])
            assert ante==es[1] and cons==f,('MP',i)
        proof.append(f)
    wanted={'I':parse('Cpp'),'K':parse('CpCqp'),'P':parse('CCCpqpp')}
    assert set(data['roots'])==set(wanted)
    for name,t in wanted.items():
        i=data['roots'][name]
        assert type(i)is int and 0<=i<len(proof) and proof[i]==t
    return {'status':'ALIAS_FREE_IKP_FORWARD_CHECK_PASS','proof_nodes':len(proof),'rules':counts,'roots':data['roots'],'normalization':'none','truth_axioms':False,'certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'scope':'I,K,Peirce only; no S, full classical basis, or alternate-encoding calibration claimed'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('certificate',nargs='?',type=Path,default=Path(__file__).with_name('alias_free_ikp.json'));a=p.parse_args()
    print(json.dumps(check(a.certificate),indent=2))
