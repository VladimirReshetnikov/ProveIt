# A complete 218-state construction

This is the **contextual alternative** release. A separate public 218-state
construction was identified during final review; no priority or unique
state-count record is claimed. See `PROVENANCE_ADDENDUM.md` for the exact
comparison and the distinct outer archive name.

This packet specifies a deterministic, single-tape, two-symbol Turing machine
with **218 working states and a separate halt outcome**. It starts on an
entirely blank, two-way infinite tape. All initialization is performed by the
counted states: there is no prewritten input, external interpreter or excluded
startup apparatus.

The source and exact machine refinement preserve the pinned upstream K219
calibration: ZFC proves that blank nonhalting of this machine is equivalent to
Con(ZFC). This is a conditional consistency characterization, not a proof of
Con(ZFC), unconditional nonhalting or minimality. The proof boundary is ordinary
executable mathematical certification, not a newly compiled exact-byte
Rocq/Lean endpoint.

## Reproduce offline

Use Python 3.10 or newer with only the standard library and assertions enabled.
No network, search process, SAT/SMT solver, proof assistant, C compiler or
third-party Python package is required.

```
python3 -B portable/reproduce.py --output-dir /absolute/path/to/empty/replay
```

The output directory must be initially empty and outside this packet. The
command leaves the released packet unchanged; `-B` prevents bytecode caches
from becoming unmanifested packet members. Allow several minutes, depending on
hardware. Successful default completion prints `FULL_K218_REPLAY_PASS` and
writes a detailed `replay.json` and phase logs in the output directory.

Default mode performs:

1. Exact inventory checks and extraction of the unchanged pinned upstream
   K219 ZIP, followed by recursive construction/calibration replay. Inherited
   runtime certificates are audited, not freshly rederived by default.
2. Independent reconstruction of the complete source and an all-natural
   ordinal/register-store bisimulation with upstream K219, using two complete
   guarded control-flow resolvers.
3. Complete deterministic table lineage from upstream K219, including all
   intermediate source grammars, literal row changes, state accounting and
   source-prefix contracts. No unexplained construction seed is assumed.
4. Canonicalization, explicit inverse label maps, exact state census and two
   whole-blank-tape initialization simulations.
5. Fresh exact-table list-block lemmas and all **6,167 unbounded generic
   primitive-interface proofs**, with no excluded cases, followed by coverage,
   affine-duration, table-row and independent block audits.
6. Thirteen negative controls for malformed source, case/block/startup data,
   same-cardinality tape corruption, and disabled assertions.

Options:

- `--quick`: freshly reconstructs the source/table and complete startup, but
  audits the stored final runtime evidence instead of regenerating symbolic
  proofs. Its distinct success status is `QUICK_K218_REPLAY_PASS`.
- `--full-baseline`: additionally freshly rederives the upstream K219 runtime.
- `--deep-baseline`: also requests fresh runtime derivations for ancestors;
  this may take substantially longer.

The separate supplementary research ZIP is checked for pinned bytes and CRC
only. Its theorem and checker are not premises of the machine proof.

## Exact machine files

All table files use rows `state read write direction next_state`, alphabet
{0,1}, blank 0, and direction L or R. State 0 starts with head at position 0.
Every working state has exactly two transitions; the halt label has none.

- `machine/k218.normalized.tm`: proof/search labels, including 102 and 120;
  start 0, source dispatcher 84, halt 254.
- `machine/k218.native.tm`: the same table in upstream label convention,
  replacing 102 by 301 and 120 by 302; all other labels remain unchanged.
- `machine/k218.tm`: deterministic breadth-first canonical labels 0 through
  217, start 0 and halt 218, discovering the 0-edge before the 1-edge.
- `machine/sites218.json`: all 4,744 ordered primitive source occurrences.
- `machine/canonicalization.json`: forward and inverse label maps, separate
  hashes, census and the complete initialized tape/register frame.

These are three labelings of one construction, not three different machines.
There are exactly 436 binary transition rows; all 218 working states are
reachable in the directed transition graph.

## Initialization and unbounded proof scope

The complete blank prefix is **312,701 transitions**. It reaches normalized
state 84 at head -5 with exactly 277 specified one cells and all other cells
zero. The frame represents logical registers `[3,0,0,0,3,0,0,0,0]`, permutation
`(6,2,0,4,3,7,8,5,1)`, header 139, extra blank gap 80, and 130 spare registers
of value 1. Sparse and dense interpreters agree on the entire tape support and
all transition-use counts, not merely a bounded window or checksum.

The runtime proof covers independent arbitrary natural primary-register
values, arbitrary natural extra gap and first spare value, and any finite
remaining spare tail. It proves all zero/positive decrement branches without
reachability exclusions. Every primitive has positive finite affine duration;
the minimum constant is 13. The successful run has 1,514,325 symbolic rule
applications and directly covers all 436 literal rows. The symbolic proof
construction bound does not bound represented natural values, concrete runtime
or spare-list length.

## Construction and source theorem

The exact state accounting is

`219 → 219 → 220 → 219 → 219 → 219 → 218`.

It proceeds through the startup-preserving source reparse, a temporary
single-role allocation, direct188, reuse of existing decoder states 12 and
150, and the contextual fold of state 96 into 85. The source has 205 distinct
DAG nodes, including 182 interiors; this is not the physical state count.
`portable/lineage/LINEAGE.md` and the report explain the construction.

The final source preserves the primitive operation and argument at every
ordinal and its complete guarded successor relation. The two source resolvers
check 6,166 nonhalting guarded edges and 6,167 targets including source entry.
Hence corresponding source configurations with any equal natural register
vector are in strong step-for-step bisimulation. This source result, complete
blank initialization and fresh unbounded physical refinement are all required
before transporting the inherited calibration.

## Contents and trust boundary

- `portable/`: executable reconstruction and verification drivers.
- `certificates/source/`: complete ordinal correspondence and source theorem
  receipt; `certificates/runtime/`: exact startup, all case summaries, runtime
  certificate and independent coverage/block integrity audit.
- `verification/`: independent audits, negative controls and explicitly
  labeled historical baseline evidence.
- `vendor/K219_Construction_2026-10-20.zip`: unchanged upstream packet pinned
  at commit `26d5de6d21fa354d50e0b84fe851c289925b8d72`, recursively containing
  its inherited calibration and predecessors.
- `report/report.pdf`, TeX sources and build script: mathematical exposition,
  exact state/row accounting, artifact hashes and verification boundary.
- `supplementary/Membership_Fourth_Parameter_Obstruction_2026-10-20.zip`:
  separately audited research supplement, unchanged and not part of the
  machine theorem. See its own README for its narrower scope and verifier.
- `manifest.json` and `SHA256SUMS`: complete released-file inventory.

The original K219 construction and its logical calibration belong to the
upstream ProveIt work. This packet's contribution is the explicit 218-state
source/allocation construction and its exact refinement, reconstruction,
independent audits and report. See `NOTICE.md` and `PROVENANCE.json`.
