#!/usr/bin/env python3
"""Strict table I/O and elementary finite-state checks (Python standard library)."""
from pathlib import Path
import hashlib


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def read_table(path):
    table = {}
    starts = []
    for line in Path(path).read_text(encoding='ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
        if not line or line.startswith('#'):
            continue
        fields = line.split()
        require(len(fields) == 5, 'Transition arity')
        q, bit, write, direction, target = fields
        q, bit, write, target = map(int, (q, bit, write, target))
        require(q >= 0 and target >= 0 and bit in (0, 1) and write in (0, 1),
                'Transition numeric domain')
        require(direction in ('L', 'R') and (q, bit) not in table,
                'Transition direction or duplicate row')
        table[q, bit] = write, (-1 if direction == 'L' else 1), target
    require(starts == [0], 'Expected one start-state header, at zero')
    return table


def encode(table):
    return ('#! start 0\n' + ''.join(
        f'{q} {bit} {write} {"R" if direction == 1 else "L"} {target}\n'
        for (q, bit), (write, direction, target) in sorted(table.items())
    )).encode('ascii')


def census(table, count, halt=254):
    states = {q for q, bit in table}
    require(len(states) == count and 0 in states and halt not in states,
            'Working-state or start/halt census')
    require(set(table) == {(q, bit) for q in states for bit in (0, 1)},
            'Binary transition completeness')
    require(all(write in (0, 1) and direction in (-1, 1)
                for write, direction, target in table.values()), 'Action domain')
    require({target for write, direction, target in table.values()} - states == {halt},
            'Target closure')
    todo = [0]
    seen = {0}
    for q in todo:
        for bit in (0, 1):
            target = table[q, bit][2]
            if target not in seen and target != halt:
                todo.append(target)
                seen.add(target)
    require(seen == states, 'A working state is graph-unreachable')
    return states


def incoming(table, state):
    return sorted((q, bit, write, direction)
                  for (q, bit), (write, direction, target) in table.items()
                  if target == state)
