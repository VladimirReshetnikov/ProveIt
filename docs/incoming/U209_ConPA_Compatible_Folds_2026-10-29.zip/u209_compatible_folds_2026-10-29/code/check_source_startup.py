#!/usr/bin/env python3
"""Independent U209 source, literal-prefix, engine-entry and blank-frame audit.

No builder, symbolic-runtime engine, or saved receipt is imported. The input
source programs are complete leaf-address/opcode/operand lists. The source
control graph is reconstructed from prefix intervals, and every primitive
entry is followed in the literal tables with opaque exterior cells.
"""
from pathlib import Path
import argparse, hashlib, json

def need(ok,message):
    if not ok: raise ValueError(message)

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def table(path,count):
    t={};starts=[]
    for line in Path(path).read_text().splitlines():
        if line.startswith('#! start '):starts.append(int(line.split()[-1]))
        if not line or line.startswith('#'):continue
        q,b,w,d,z=line.split();q,b,w,z=map(int,(q,b,w,z))
        need((q,b)not in t and b in (0,1) and w in (0,1) and d in ('L','R'),'table syntax')
        t[q,b]=(w,1 if d=='R' else -1,z)
    states={q for q,b in t}
    need(starts==[0] and len(states)==count and set(t)=={(q,b)for q in states for b in (0,1)},'table census')
    need(254 not in states and {z for w,d,z in t.values()}-states=={254},'target closure')
    return t

def analyze(rows):
    leaves={p:(op,arg)for p,op,arg in rows};need(len(leaves)==len(rows),'duplicate address')
    intervals={};branches={};boundary={};serial=[];subtrees={}
    max_depth=max(map(len,leaves))
    def walk(p):
        lo=len(serial)
        if p in leaves:
            op,arg=leaves[p];serial.append([p,op,arg]);subtrees[p]=(op,arg)
            need(op in ('CI','CD','CB','CC','CH'),'opcode')
            boundary[p]=(1 if op=='CD'else arg if op=='CB'else 0,arg if op=='CC'else 0,op=='CH')
        else:
            need(len(p)<max_depth,'incomplete source tree')
            walk(p+'0');walk(p+'1');branches[p]=(p+'0',p+'1')
            a,b=boundary[p+'0'],boundary[p+'1']
            boundary[p]=(max(a[0]-1,b[0],0),max(a[1],b[1]-1,0),a[2]or b[2])
            subtrees[p]=(subtrees[p+'0'],subtrees[p+'1'])
        intervals[p]=(lo,len(serial))
    walk('');need(serial==rows,'source order')
    def jump(p,bit,n):
        hits=[i for i,b in enumerate(p)if b==bit]
        need(n>0 and len(hits)>=n,'unbound source control')
        return intervals[p[:hits[-n]]][0 if bit=='1' else 1]%len(rows)
    cfg=[]
    for i,(p,op,arg)in enumerate(rows):
        nxt=(i+1)%len(rows)
        edge=(nxt,)if op=='CI'else(jump(p,'0',1),nxt)if op=='CD'else(jump(p,'0',arg),)if op=='CB'else(jump(p,'1',arg),)if op=='CC'else()
        cfg.append((op,arg,edge))
    metrics=dict(primitives=len(rows),control_edges=sum(len(x[2])for x in cfg),
                 guarded_contracts=sum(2 if op=='CD'else 1 for p,op,arg in rows),
                 dag_nodes=len(set(subtrees.values())),maximum_depth=max_depth,
                 maximum_zero_run=max(len(v)for p in leaves for v in p.split('1')))
    return cfg,metrics,intervals,boundary

def prefixes(t,rows):
    bindings=[];max_steps=0
    for leafword,op,arg in rows:
        # The last leaf edge may begin a primitive by writing or moving left.
        # Decode its proper prefix, then record the exact terminal action.
        word=leafword[:-1]
        q,h=84,0;known={-1:1,**dict(enumerate(map(int,word)))}
        for step in range(2000):
            if h==len(word):break
            need(h in known and q!=254,('prefix reads exterior or halts',word,q,h))
            b=known[h];w,d,q=t[q,b]
            need(w==b,('prefix overwrites tape',word,h))
            h+=d
        else:raise ValueError(('prefix fails to finish',word))
        bindings.append(t[q,int(leafword[-1])]);max_steps=max(max_steps,step+1)
    return bindings,max_steps

def literal_run(t,n):
    ones=set();q=h=0;trace=hashlib.sha256();used=set()
    for i in range(n):
        b=int(h in ones);w,d,z=t[q,b];used.add((q,b))
        trace.update((json.dumps([i,q,h,b,w,d,z],separators=(',',':'))+'\n').encode())
        if w:ones.add(h)
        else:ones.discard(h)
        q,h=z,h+d
    return(q,h,ones),trace.hexdigest(),used

def known_path(t,q,cells,steps):
    memory=dict(cells);head=0;trace=[]
    for _ in range(steps):
        need(head in memory,'engine-entry exterior read')
        b=memory[head];w,d,z=t[q,b];trace.append([q,head,b,w,d,z]);memory[head]=w;head+=d;q=z
    return(q,head,memory),trace

def check(parent_table,parent_sites,prefold_table,candidate_table,candidate_sites):
    old=table(parent_table,212);prefold=table(prefold_table,212);new=table(candidate_table,209)
    rows0=json.loads(Path(parent_sites).read_text());rows=json.loads(Path(candidate_sites).read_text())
    cfg0,metrics0,_,_=analyze(rows0);cfg,metrics,_,_=analyze(rows)
    need(cfg==cfg0,'source primitive word or ordinal CFG changed')
    need(metrics==dict(primitives=3909,control_edges=5083,guarded_contracts=5084,dag_nodes=197,maximum_depth=42,maximum_zero_run=6),'source metric contract')
    old_bind,old_max=prefixes(old,rows0);pre_bind,pre_max=prefixes(prefold,rows);new_bind,new_max=prefixes(new,rows)
    need(old_bind==pre_bind==new_bind,'primitive handler entries changed')
    need(len(old_bind)==3909,'primitive prefix census')
    # The changed native7 decoder also serves an engine entry. Check both
    # possible preceding bits without assuming an exterior tape value.
    repair=[]
    for left in (0,1):
        cells={-1:left,0:0};n=2+left
        a,ta=known_path(old,171,cells,n);b,tb=known_path(new,171,cells,n)
        need(a==b and a[2]==cells,'engine-entry repair')
        need(a[:2]==((86,0)if left==0 else(164,1)),'engine-entry endpoint')
        repair.append(dict(left=left,steps=n,old_trace=ta,new_trace=tb,unread_exterior=True))
    A,ha,used=literal_run(old,48140);B,hb,_=literal_run(new,48140)
    need(A==B and ha==hb,'blank prefix mismatch')
    need(A[:2]==(84,-2),'blank startup position')
    delta={k for k in set(old)|set(new)if old.get(k)!=new.get(k)}
    need(not used&delta,'startup visits an edited row')
    need(rows[136][0]=='001100110101010','startup source address')
    regs=[1,0,13,0,0,1,0,0,1];physical=[0]*9
    for i,j in enumerate((6,2,0,4,3,7,8,5,1)):physical[j]=regs[i]
    expected={-3,54}|{-2+i for i,c in enumerate(rows[136][0])if c=='1'};pos=55
    for value in physical+[1]*43:
        expected.update(range(pos+1,pos+value+2));pos+=value+2
    need(A[2]==expected,'complete initial logical frame')
    start=[1,0,4,0,0,1,0,0,1];R=start.copy();ip=106;source_trace=[]
    for i in range(141):
        before=(ip,R.copy());op,arg,edges=cfg[ip]
        if op=='CI':R[arg]+=1;ip=edges[0]
        elif op=='CD':positive=R[arg]>0;R[arg]-=int(positive);ip=edges[int(positive)]
        elif op in('CB','CC'):ip=edges[0]
        else:raise ValueError('source prefix unexpectedly halts')
        source_trace.append([*before,ip,R.copy()])
    need(ip==136 and R==regs,'source seed prefix')
    return dict(status='INDEPENDENT_SOURCE_PREFIX_STARTUP_PASS',metrics=metrics,
                changed_source_addresses=sum(a[0]!=b[0]for a,b in zip(rows0,rows)),
                unchanged_primitive_handler_entries=len(new_bind),proper_prefix_tape_unchanged=True,proper_prefix_exterior_unread=True,terminal_primitive_actions_identical=True,
                maximum_prefix_steps=dict(parent=old_max,prefold=pre_max,candidate=new_max),
                engine_entry_repair=repair,
                startup=dict(steps=48140,state=84,head=-2,header=54,trace_sha256=ha,
                             identical_to_parent=True,edited_rows_visited=0,logical_registers=regs,
                             spares=[1]*43,one_cells=sorted(expected),zero_exterior=True,
                             source_ordinal=136,source_seed_ordinal=106,source_seed=start,
                             source_prefix_steps=141,source_prefix_trace=source_trace),
                input_sha256={name:digest(path)for name,path in dict(parent_table=parent_table,parent_sites=parent_sites,prefold_table=prefold_table,candidate_table=candidate_table,candidate_sites=candidate_sites).items()},
                scope='Exact source CFG, all literal primitive-prefix entries, local engine repair, and canonical finite blank frame; unbounded primitive runtime and logical calibration are separate.')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('parent-table','parent-sites','prefold-table','candidate-table','candidate-sites','output'):p.add_argument('--'+name,required=True,type=Path)
    a=p.parse_args();r=check(a.parent_table,a.parent_sites,a.prefold_table,a.candidate_table,a.candidate_sites)
    a.output.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({k:v for k,v in r.items()if k not in ('startup','engine_entry_repair')},indent=2))
if __name__=='__main__':main()
