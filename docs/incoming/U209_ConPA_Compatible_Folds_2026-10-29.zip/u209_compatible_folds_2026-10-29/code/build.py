#!/usr/bin/env python3
"""Rebuild U209 from the frozen U212 table/source, without search or network.

The finite construction preserves the ordered primitive word and every guarded
ordinal successor. Its literal/source simulation and local fold proofs are
separate obligations, checked by the other delivered scripts.
"""
from pathlib import Path
from collections import Counter
import argparse
import json
import source_language as L
from table_io import require, sha256, read_table, encode, census, incoming

ROOT = Path(__file__).resolve().parents[1]
PARENT_TABLE_SHA = '386ce16259d4c97e4af31b3ba494feaff11a0a1a066e0235dddc154b4cea38c4'
PARENT_SOURCE_SHA = '7b6539dc67b66ff73f22554018d7af5985d85574460a73fea5f025103c523d00'
SOURCE_UTILITIES_SHA = '4b355b81373a06ce2d8d99f56ac88afee8bbbd934d21f4f2729d864d9807683f'
EXPECTED_NATIVE_SHA = 'd0a155d3c683789f3bf5327c0cfb2a0cfd78076af8f1654d4ca426ccbb604d16'
EXPECTED_SOURCE_SHA = 'cddbed7f20e7a8b085b7ca0e76811d07b021522375643b5d1134eec0d2d23164'

# Nine Research rotations, then eight rotations transporting continuation 116.
ROTATIONS = [
    (215, 204, 1), (217, 181, 1), (185, 217, 0), (174, 185, 1),
    (129, 158, 0), (217, 215, 1), (204, 214, 0), (215, 129, 0),
    (216, 220, 1), (162, 203, 0), (203, 223, 0), (223, 188, 0),
    (188, 177, 0), (177, 89, 0), (89, 174, 0), (174, 217, 0),
    (217, 163, 0),
]

# One parenthesization of eleven closed factors, using the same ten nodes.
LAYOUT = {
    174: (98, 129), 129: (158, 204), 158: (218, 178), 204: (147, 214),
    214: (146, 216), 216: (220, 217), 220: (218, 176), 217: (163, 215),
    163: (90, 211), 215: (218, 116),
}
EXTERNAL_ROTATIONS = [(206, 199, 1), (205, 206, 1), (7, 205, 1)]


def source_bytes(rows):
    return (json.dumps(rows, separators=(',', ':')) + '\n').encode('ascii')


def leaf_count(node):
    return 1 if L.leaf(node) else leaf_count(node[0]) + leaf_count(node[1])


def occurrences(root, table, target):
    found = []
    def visit(node, state, path):
        if state == target:
            found.append((path, node))
            return
        if L.leaf(node):
            return
        for bit in (0, 1):
            write, direction, child = table[state, bit]
            if (write, direction) == (bit, 1):
                visit(node[bit], child, path + str(bit))
    visit(root, 84, '')
    return found


def check_source(root, original_rows, original_graph):
    rows = L.sites(root)
    require([row[1:] for row in rows] == [row[1:] for row in original_rows],
            'Ordered primitive word changed')
    require(L.graph_intervals(rows) == original_graph, 'Interval source CFG changed')
    require(L.graph_arithmetic(rows)[0] == original_graph, 'Arithmetic source CFG changed')
    return rows


def rotate(table, root, outer, inner, side):
    require(side in (0, 1), 'Rotation side')
    places = occurrences(root, table, outer)
    require(places and len({node for path, node in places}) == 1,
            'Outer occurrences have different source factors')
    require(table[outer, side] == (side, 1, inner), 'Rotation inner child')
    require(incoming(table, inner) == [(outer, side, side, 1)],
            'Inner decoder has another physical entrance')
    require(all(table[q, bit][:2] == (bit, 1)
                for q in (outer, inner) for bit in (0, 1)), 'Non-pure decoder')
    node = places[0][1]
    if side == 0:
        a, b = node[0]
        c = node[1]
        replacement = a, (b, c)
        x, y, z = table[inner, 0][2], table[inner, 1][2], table[outer, 1][2]
        edits = {(outer, 0): (0, 1, x), (outer, 1): (1, 1, inner),
                 (inner, 0): (0, 1, y), (inner, 1): (1, 1, z)}
    else:
        a = node[0]
        b, c = node[1]
        replacement = (a, b), c
        x, y, z = table[outer, 0][2], table[inner, 0][2], table[inner, 1][2]
        edits = {(outer, 0): (0, 1, inner), (outer, 1): (1, 1, z),
                 (inner, 0): (0, 1, x), (inner, 1): (1, 1, y)}
    require(all(L.boundary(n) == (0, 0, False) for n in (a, b, c)),
            'A rotated factor has escaping control or halt')
    rows_before = L.sites(root)
    record = dict(outer=outer, inner=inner, side=side, paths=[p for p, n in places],
                  factor_labels=[x, y, z], factor_sizes=[leaf_count(n) for n in (a, b, c)],
                  closed=True, intervals=[
                      [next(i for i, row in enumerate(rows_before) if row[0].startswith(p)),
                       sum(row[0].startswith(p) for row in rows_before)] for p, n in places])
    for path, node in places:
        root = L.replace(root, path, replacement)
    table.update(edits)
    return root, record


def reparent_emitter(table, root):
    places = occurrences(root, table, 174)
    require(places and len({node for path, node in places}) == 1, 'Emitter occurrences')
    factors = []
    interior_visits = Counter()
    def flatten(node, state):
        if state not in LAYOUT:
            factors.append((state, node))
            return
        interior_visits[state] += 1
        require(not L.leaf(node), 'Internal emitter label at primitive leaf')
        for bit in (0, 1):
            write, direction, child = table[state, bit]
            require((write, direction) == (bit, 1), 'Emitter interior is not pure')
            flatten(node[bit], child)
    flatten(places[0][1], 174)
    require(interior_visits == Counter({q: 1 for q in LAYOUT}), 'Emitter interior is not a tree')
    expected_word = [98, 218, 178, 147, 146, 218, 176, 90, 211, 218, 116]
    require([q for q, node in factors] == expected_word, 'Closed-factor word changed')
    require(all(L.boundary(node) == (0, 0, False) for q, node in factors),
            'An emitter factor has escaping control or halt')
    leaves = dict(factors)
    require(all(node == leaves[q] for q, node in factors), 'Repeated factor disagreement')
    entrances = {q: incoming(table, q) for q in LAYOUT}
    require(all(q == 174 or all(p in LAYOUT for p, bit, write, direction in entrances[q])
                for q in LAYOUT), 'External entrance into replaced emitter interior')
    visited = Counter()
    new_word = []
    def new_tree(state):
        if state not in LAYOUT:
            new_word.append(state)
            return leaves[state]
        visited[state] += 1
        require(visited[state] == 1, 'New emitter cycle or interior sharing')
        a, b = LAYOUT[state]
        return new_tree(a), new_tree(b)
    replacement = new_tree(174)
    require(new_word == expected_word and visited == interior_visits, 'New emitter word/interior')
    for path, node in places:
        root = L.replace(root, path, replacement)
    for q, (a, b) in LAYOUT.items():
        table[q, 0], table[q, 1] = (0, 1, a), (1, 1, b)
    record = dict(root=174, paths=[p for p, n in places], layout=LAYOUT,
                  complete_old_incoming=entrances,
                  factors=[dict(label=q, primitives=leaf_count(n), boundary=L.boundary(n))
                           for q, n in factors])
    return root, record


def build(output):
    output = Path(output).resolve()
    require(output != (ROOT / 'machine').resolve() and (ROOT / 'machine').resolve() not in output.parents,
            'Do not overwrite the frozen machine directory; use build/machine')
    require(output != (ROOT / 'inputs').resolve() and (ROOT / 'inputs').resolve() not in output.parents,
            'Do not overwrite the frozen inputs directory')
    table_path, source_path = ROOT / 'inputs/u212.native.tm', ROOT / 'inputs/u212.sites.json'
    require(sha256(table_path.read_bytes()) == PARENT_TABLE_SHA, 'Parent table hash')
    require(sha256(source_path.read_bytes()) == PARENT_SOURCE_SHA, 'Parent source hash')
    require(sha256(Path(L.__file__).read_bytes()) == SOURCE_UTILITIES_SHA, 'Source utilities hash')
    table = read_table(table_path)
    census(table, 212)
    original_table = dict(table)
    original_rows = json.loads(source_path.read_text())
    root = L.tree(original_rows)
    original_graph = L.graph_intervals(original_rows)
    require(L.graph_arithmetic(original_rows)[0] == original_graph, 'Original CFG resolvers')
    payload = {}
    ledger = []
    for number, (outer, inner, side) in enumerate(ROTATIONS, 1):
        root, record = rotate(table, root, outer, inner, side)
        rows = check_source(root, original_rows, original_graph)
        record.update(number=number, both_cfg_resolvers=True)
        ledger.append(record)
    census(table, 212)
    payload['combined212.native.tm'] = encode(table)
    payload['combined210.sites.json'] = source_bytes(rows)
    root, emitter = reparent_emitter(table, root)
    check_source(root, original_rows, original_graph)
    payload['emitter212.native.tm'] = encode(table)
    payload['emitter.sites.json'] = source_bytes(L.sites(root))
    external = []
    for outer, inner, side in EXTERNAL_ROTATIONS:
        root, record = rotate(table, root, outer, inner, side)
        rows = check_source(root, original_rows, original_graph)
        record['both_cfg_resolvers'] = True
        external.append(record)
    # Rotation through native 7 moves its old runtime entry to native 205.
    require(table[171, 0] == (0, -1, 7), 'Unexpected engine entrance')
    table[171, 0] = (0, -1, 205)
    census(table, 212)
    prefold = dict(table)
    payload['prefold212.native.tm'] = encode(table)
    require(table[220, 0] == (0, 1, 218) and table[181, 0] == (0, 1, 147), 'First-fold zero branches')
    require(table[220, 1] == table[181, 1] == (1, 1, 176), 'First-fold common branch')
    require(incoming(table, 220) == [(216, 0, 0, 1)], 'First-fold zero tag')
    require(incoming(table, 181) == [(185, 1, 1, 1)], 'First-fold one tag')
    table = {(q, bit): (write, direction, 220 if target == 181 else target)
             for (q, bit), (write, direction, target) in table.items() if q != 181}
    table[220, 0] = (0, -1, 129)
    census(table, 211)
    payload['prefold211.native.tm'] = encode(table)
    entries218 = incoming(table, 218)
    require(entries218 and all(write == 0 and direction == 1
                               for q, bit, write, direction in entries218), 'Second-fold zero tags')
    table = {(q, bit): (write, direction, 157 if target == 218 else target)
             for (q, bit), (write, direction, target) in table.items() if q != 218}
    census(table, 210)
    payload['prefold210.native.tm'] = encode(table)
    require(table[163, 0] == (0, 1, 90) and table[180, 0] == (0, 1, 152), 'Third-fold zero branches')
    require(table[163, 1] == table[180, 1] == (1, 1, 211), 'Third-fold common branch')
    require(incoming(table, 163) == [(217, 0, 0, 1)], 'Third-fold zero tag')
    require(incoming(table, 180) == [(132, 1, 1, 1), (199, 1, 1, 1)], 'Third-fold one tags')
    table = {(q, bit): (write, direction, 163 if target == 180 else target)
             for (q, bit), (write, direction, target) in table.items() if q != 180}
    table[163, 0] = (0, -1, 211)
    states = census(table, 209)
    mapping = {q: i for i, q in enumerate(sorted(states))}
    mapping[254] = 209
    dense = {(mapping[q], bit): (write, direction, mapping[target])
             for (q, bit), (write, direction, target) in table.items()}
    census(dense, 209, 209)
    inverse = {v: k for k, v in mapping.items()}
    require({(inverse[q], bit): (write, direction, inverse[target])
             for (q, bit), (write, direction, target) in dense.items()} == table,
            'Dense table isomorphism')
    payload['u209.native.tm'], payload['u209.tm'] = encode(table), encode(dense)
    payload['sites.json'] = source_bytes(rows)
    payload['sites.tsv'] = ''.join(f'{p}\t{op}\t{-1 if arg is None else arg}\n'
                                    for p, op, arg in rows).encode('ascii')
    require(sha256(payload['u209.native.tm']) == EXPECTED_NATIVE_SHA, 'Final native hash')
    require(sha256(payload['sites.json']) == EXPECTED_SOURCE_SHA, 'Final source hash')
    state_map = dict(native_to_dense=mapping, dense_to_native=inverse,
                     native_halt=254, dense_halt=209)
    payload['state_map.json'] = (json.dumps(state_map, indent=2) + '\n').encode('ascii')
    summary = dict(status='EXACT_U209_REBUILD_PASS', working_states=209, transition_rows=418,
                   start=0, native_halt=254, dense_halt=209, source_metrics=L.metrics(root),
                   initial_rotations=ledger, emitter_reparenting=emitter,
                   external_rotations=external, engine_repair=[171, 0, 0, -1, 205],
                   fold_order=[[181, 220], [218, 157], [180, 163]],
                   prefold_guard_incoming={q: incoming(prefold, q) for q in (220, 181, 218, 163, 180)},
                   changed_addresses_from_U212=sum(x[0] != y[0] for x, y in zip(rows, original_rows)),
                   changed_retained_rows=[dict(row=key, before=original_table[key], after=value)
                                          for key, value in sorted(table.items()) if value != original_table[key]],
                   source_primitives=len(rows), source_cases=sum(2 if op == 'CD' else 1 for p, op, arg in rows),
                   file_hashes={name: sha256(raw) for name, raw in payload.items()},
                   scope='Finite literal construction, source CFG preservation, exact hashes. '
                         'Local simulation, startup and unbounded runtime have separate checks.')
    payload['construction.json'] = (json.dumps(summary, indent=2) + '\n').encode('ascii')
    payload['rotations.json'] = (json.dumps(ROTATIONS, indent=2) + '\n').encode('ascii')
    output.mkdir(parents=True, exist_ok=True)
    for name, raw in payload.items():
        (output / name).write_bytes(raw)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'build/machine')
    args = parser.parse_args()
    result = build(args.output)
    print(json.dumps({key: result[key] for key in
          ('status', 'working_states', 'transition_rows', 'source_metrics',
           'changed_addresses_from_U212', 'source_cases')}, indent=2))


if __name__ == '__main__':
    main()
