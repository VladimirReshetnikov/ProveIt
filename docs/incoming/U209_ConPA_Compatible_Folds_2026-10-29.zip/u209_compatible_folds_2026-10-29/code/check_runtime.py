#!/usr/bin/env python3
"""Reprove all 5,084 U209 primitive contracts with the pinned inherited engine.

The rules use natural-number and finite-list induction. This executable
mathematical verification is not a Lean, Rocq, MM0, or PA kernel certificate.
"""
from pathlib import Path
import argparse
import gzip
import importlib
import json
import sys
import time
from table_io import require, sha256, read_table, census

ROOT = Path(__file__).resolve().parents[1]
NATIVE_SHA = 'd0a155d3c683789f3bf5327c0cfb2a0cfd78076af8f1654d4ca426ccbb604d16'
SOURCE_SHA = 'cddbed7f20e7a8b085b7ca0e76811d07b021522375643b5d1134eec0d2d23164'
ENGINE_PINS = {
    'native_symbolic.py': 'b4ffbf783ee2895a3f4584ae72b4c5498bfd518aa6d774765f8d1e65ed7a3f9a',
    'source_ops.py': '53f079d7d742c0fb67be7cd20abe1912410a1825901844a3107c59edae8921aa',
}


def check_sites(raw):
    rows = json.loads(raw)
    require(isinstance(rows, list) and len(rows) == 3909, 'Source occurrence census')
    leaves, prefixes = set(), set()
    for row in rows:
        require(isinstance(row, list) and len(row) == 3, 'Source row arity')
        path, op, arg = row
        require(isinstance(path, str) and 0 < len(path) <= 56 and set(path) <= {'0', '1'},
                'Source address')
        require(path not in leaves, 'Repeated source address')
        leaves.add(path)
        prefixes.update(path[:i] for i in range(len(path)))
        require(op in ('CI', 'CD', 'CB', 'CC', 'CH'), 'Source operation')
        if op == 'CH':
            require(arg is None, 'Halt argument')
        elif op in ('CI', 'CD'):
            require(type(arg) is int and 0 <= arg < 9, 'Source register')
        else:
            require(type(arg) is int and arg >= 1, 'Source loop level')
    require(not leaves & prefixes, 'Source prefix conflict')
    require(all(p + bit in leaves | prefixes for p in prefixes for bit in '01'),
            'Incomplete binary source tree')
    require([row[0] for row in rows] == sorted(leaves), 'Noncanonical source ordinals')
    require(sum(row[1] == 'CH' for row in rows) == 1, 'Halt-source census')
    require(sum(2 if op == 'CD' else 1 for path, op, arg in rows) == 5084, 'Guarded-case census')
    return rows


def verify(table_path, source_path, output, compare=None):
    require(__debug__ and not sys.flags.optimize,
            'Assertions must be enabled: do not use -O or PYTHONOPTIMIZE')
    output = Path(output).resolve()
    frozen_evidence = (ROOT / 'evidence').resolve()
    require(output != frozen_evidence and frozen_evidence not in output.parents,
            'Do not overwrite frozen evidence; use build/evidence')
    runtime = ROOT / 'code/runtime'
    for name, expected in ENGINE_PINS.items():
        require(sha256((runtime / name).read_bytes()) == expected,
                'Pinned induction engine differs: ' + name)
    sys.path.insert(0, str(runtime))
    symbolic = importlib.import_module('native_symbolic')
    require(Path(symbolic.__file__).resolve() == (runtime / 'native_symbolic.py').resolve()
            and Path(symbolic.r.__file__).resolve() == (runtime / 'source_ops.py').resolve(),
            'An unrelated cached runtime module was imported')
    require(symbolic.r.PHY == (6, 2, 0, 4, 3, 7, 8, 5, 1), 'Physical register permutation')
    table_path, source_path = Path(table_path), Path(source_path)
    raw_table, raw_source = table_path.read_bytes(), source_path.read_bytes()
    require(sha256(raw_table) == NATIVE_SHA, 'Final literal table hash')
    require(sha256(raw_source) == SOURCE_SHA, 'Final source hash')
    table = read_table(table_path)
    census(table, 209)
    sites = check_sites(raw_source)
    started = time.monotonic()
    lemmas, blocks = symbolic.prove_blocks(table)
    cases, used = [], set()
    for index, site in enumerate(sites):
        for positive in ((False, True) if site[1] == 'CD' else (False,)):
            result = symbolic.case(table, lemmas, site, positive)
            used.update(result['rows'])
            result['rows'] = sorted(result['rows'])
            result.pop('trace')
            cases.append(dict(site_index=index, positive=positive, **result))
        if index % 500 == 0:
            print(f'Runtime: {index + 1}/3909 sites; {len(cases)} contracts', flush=True)
    for block in blocks:
        for event in block['trace']:
            used.add(tuple(event[1][:2]))
    require(len(blocks) == 4 and len(cases) == 5084, 'Complete contract census')
    require(used == set(table) and len(used) == 418, 'Complete literal row coverage')
    require(all(len(case['duration']) == 13 and case['duration'][0] > 0
                and all(coefficient >= 0 for coefficient in case['duration'])
                for case in cases), 'Positive affine duration certificates')
    steps = sum(case['symbolic_steps'] for case in cases)
    minimum = min(case['duration'][0] for case in cases)
    require(steps == 1250049 and minimum == 5, 'Expected deterministic derivation changed')
    require(table_path.read_bytes() == raw_table and source_path.read_bytes() == raw_source,
            'Input changed during verification')
    # JSON normalization allows exact comparison with the saved discovery data.
    case_bytes = (json.dumps(cases, separators=(',', ':')) + '\n').encode('ascii')
    if compare is not None:
        compare = Path(compare)
        with (gzip.open(compare, 'rt') if compare.suffix == '.gz' else compare.open()) as stream:
            require(json.loads(case_bytes) == json.load(stream), 'Saved case records differ')
    result = dict(
        status='NATIVE_UNIVERSAL_MATHEMATICAL_PASS', working_states=209,
        literal_rows=418, row_coverage=418, sites=3909, cases=5084,
        symbolic_steps=steps, minimum_duration_constant=minimum,
        header_base=56, arbitrary_natural_primary_registers=9,
        arbitrary_natural_extra_gap=True, arbitrary_nonempty_finite_spare_list=True,
        entire_tape_including_zero_exterior=True, table_sha256=NATIVE_SHA,
        sites_sha256=SOURCE_SHA, engine_sha256=ENGINE_PINS, blocks=blocks,
        saved_records_compared=compare is not None,
        seconds=round(time.monotonic() - started, 6),
        scope='Every source guard, arbitrary natural registers and extra header gap, '
              'arbitrary nonempty finite spare list; inherited unary/list induction. '
              'This is executable mathematical evidence, not a PA kernel certificate.')
    output.mkdir(parents=True, exist_ok=True)
    (output / 'runtime.json').write_text(json.dumps(result, indent=2) + '\n', encoding='ascii')
    with gzip.GzipFile(filename=str(output / 'runtime_cases.json.gz'), mode='wb', mtime=0) as stream:
        stream.write(case_bytes)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--table', type=Path, default=ROOT / 'machine/u209.native.tm')
    parser.add_argument('--sites', type=Path, default=ROOT / 'machine/sites.json')
    parser.add_argument('--output', type=Path, default=ROOT / 'build/evidence')
    parser.add_argument('--compare', type=Path)
    args = parser.parse_args()
    result = verify(args.table, args.sites, args.output, args.compare)
    print(json.dumps({key: value for key, value in result.items() if key != 'blocks'}, indent=2))


if __name__ == '__main__':
    main()
