#!/usr/bin/env python3
"""Recheck the three source proposals and the pinned downloaded archives."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile
from check_source_startup import analyze

ROOT = Path(__file__).resolve().parents[1]


def require(ok, message):
    if not ok:
        raise ValueError(message)


def parse(raw):
    result, starts = {}, []
    for line in raw.decode('ascii').splitlines():
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
        if not line or line.startswith('#'):
            continue
        q, bit, write, direction, target = line.split()
        q, bit, write, target = map(int, (q, bit, write, target))
        require((q, bit) not in result and bit in (0, 1) and write in (0, 1)
                and direction in ('L', 'R'), 'Transition syntax')
        result[q, bit] = write, 1 if direction == 'R' else -1, target
    require(starts == [0], 'Start convention')
    return result


def one_member(archive, suffix):
    names = [name for name in archive.namelist() if name.endswith(suffix)]
    require(len(names) == 1, 'Expected one archive member: ' + suffix)
    return archive.read(names[0])


def check(output):
    spec = json.loads((ROOT / 'comparison/input_manifest.json').read_text())
    expected = json.loads((ROOT / 'comparison/proposal_comparison.json').read_text())
    require(spec['revision'] == expected['snapshot'], 'Repository revision')
    parent = parse((ROOT / 'inputs/u212.native.tm').read_bytes())
    parent_source = json.loads((ROOT / 'inputs/u212.sites.json').read_text())
    parent_graph = analyze(parent_source)[0]
    records, archives = {}, []
    for item in spec['archives']:
        filename = item['filename']
        require(Path(filename).name == filename, 'Archive filename')
        raw = (ROOT / 'reference' / filename).read_bytes()
        require(len(raw) == item['size_bytes'], 'Archive byte length: ' + filename)
        require(hashlib.sha256(raw).hexdigest() == item['sha256'], 'Archive SHA256: ' + filename)
        blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        require(blob == item['git_blob_sha1'], 'Git blob identity: ' + filename)
        archives.append(dict(filename=filename, bytes=len(raw), sha256=item['sha256']))
        if not filename.startswith('U211_'):
            continue
        label = filename.split('_')[2]
        with zipfile.ZipFile(ROOT / 'reference' / filename) as archive:
            native = one_member(archive, '/machine/u211.native.tm')
            dense = one_member(archive, '/machine/u211.tm')
            source = one_member(archive, '/source/sites.json' if label == 'Rotated'
                                else '/machine/sites.json')
        table = parse(native)
        states = {q for q, bit in table}
        require(len(states) == 211 and set(table) == {(q, b) for q in states for b in (0, 1)},
                '211-state complete table: ' + label)
        require({z for w, d, z in table.values()} - states == {254}, 'Target closure')
        reached, todo = {0}, [0]
        for q in todo:
            for bit in (0, 1):
                z = table[q, bit][2]
                if z != 254 and z not in reached:
                    reached.add(z)
                    todo.append(z)
        require(reached == states, 'Graph reachability')
        rows = json.loads(source)
        graph, metrics, _, _ = analyze(rows)
        require(graph == parent_graph, 'Source control flow: ' + label)
        record = dict(native_sha256=hashlib.sha256(native).hexdigest(),
                      dense_sha256=hashlib.sha256(dense).hexdigest(),
                      source_sha256=hashlib.sha256(source).hexdigest(),
                      deleted_vs_U212=sorted({q for q, b in parent} - states),
                      changed_retained_rows_vs_U212=sum(parent[k] != v for k, v in table.items()),
                      source_addresses_changed_vs_U212=sum(a[0] != b[0] for a, b in zip(rows, parent_source)),
                      source_control_flow_matches_U212=True,
                      metrics={key: metrics[key] for key in
                               ('primitives', 'dag_nodes', 'maximum_depth', 'maximum_zero_run')},
                      states=211, rows=len(table))
        require(record == expected['records'][label], 'Saved comparison differs: ' + label)
        records[label] = record
    require(set(records) == {'Contextual', 'Research', 'Rotated'}, 'Proposal coverage')
    result = dict(status='PINNED_INPUT_COMPARISON_PASS', snapshot=spec['revision'],
                  archives=archives, records=records,
                  scope='Exact source archives, table census, source CFG, and recorded differences; '
                        'not a rerun of each original package proof or a consistency certificate.')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + '\n')
    print('All four archives and all three U211 table/source comparisons passed.')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'build/evidence/comparison.json')
    check(parser.parse_args().output)
