#!/usr/bin/env python3
"""Certify the direct three-fold 212-to-209 simulation on opaque tapes.

Usage:
  python3 check_local.py PREFOLD212 FINAL209 --output evidence/local.json

Both arguments are native-label binary transition tables with initial state0
and halt254.  No builder, source parser, or runtime engine is imported.  Every
check uses an explicit exception and remains active under python3 -O.
"""
import argparse
import hashlib
import json
from pathlib import Path

SPECIAL = {181: 1, 220: 0, 218: 0, 163: 0, 180: 1}
EXPECTED_INCOMING = {
    181: [(185, 1, 1, 1)],
    220: [(216, 0, 0, 1)],
    218: [(158, 0, 0, 1), (211, 0, 0, 1), (215, 0, 0, 1), (220, 0, 0, 1)],
    163: [(217, 0, 0, 1)],
    180: [(132, 1, 1, 1), (199, 1, 1, 1)],
}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def image(q):
    return {181: 220, 218: 157, 180: 163}.get(q, q)

def validate(t, count):
    states = {q for q, _ in t}
    require(len(states) == count, 'Working-state count')
    require(0 in states and 254 not in states, 'Start and halt domain')
    require(set(t) == {(q, bit) for q in states for bit in (0, 1)}, 'Complete binary domain')
    for (q, bit), (write, move, target) in t.items():
        require(write in (0, 1) and move in (-1, 1), 'Bad row action')
        require(target in states or target == 254, 'Undefined target')

def read_table(path, count):
    t = {}
    starts = []
    for lineno, line in enumerate(path.read_text().splitlines(), 1):
        if line.startswith('#! start '):
            starts.append(int(line.split()[-1]))
        if not line.strip() or line.startswith('#'):
            continue
        fields = line.split()
        require(len(fields) == 5, 'Malformed row at line ' + str(lineno))
        q, bit, write, direction, target = fields
        q, bit, write, target = map(int, (q, bit, write, target))
        require(direction in ('L', 'R'), 'Unknown direction')
        require((q, bit) not in t, 'Duplicate row')
        t[q, bit] = write, (-1 if direction == 'L' else 1), target
    require(starts == [0], 'The table must declare start0 exactly once')
    validate(t, count)
    return t

def incoming(t, state):
    return sorted((q, bit, write, move)
                  for (q, bit), (write, move, target) in t.items() if target == state)

def run_partial(t, state, known_cells, ticks):
    tape = dict(known_cells)
    head = 0
    trace = []
    for _ in range(ticks):
        require(state != 254, 'An internal path reached halt')
        require(head in tape, 'A path inspected the opaque exterior')
        bit = tape[head]
        write, move, target = t[state, bit]
        trace.append([state, head, bit, write, move, target])
        tape[head] = write
        head += move
        state = target
    return (state, head, tape), trace

def block_length(state, read):
    if state == 163 and read == 0:
        return 5
    if state == 218 or (state in (181, 220, 180) and read == 0):
        return 3
    return 1

def certify(old, new):
    validate(old, 212)
    validate(new, 209)
    require(set(old) - set(new) == {(q, b) for q in (181, 218, 180) for b in (0, 1)},
            'Wrong deleted-state set')
    require(not set(new) - set(old), 'New state introduced')
    for q, expected in EXPECTED_INCOMING.items():
        require(incoming(old, q) == expected, 'Complete predecessor inventory for ' + str(q))
        require(all(write == SPECIAL[q] and move == 1 for p, bit, write, move in expected),
                'Entry does not establish its tag')
    ordinary = 0
    for (q, bit), (write, move, target) in old.items():
        if q not in SPECIAL:
            require(new[q, bit] == (write, move, image(target)),
                    'Ordinary row fails to commute: ' + str((q, bit)))
            ordinary += 1
    paths = []
    for q, tag in sorted(SPECIAL.items()):
        for bit in (0, 1):
            initial = {-1: tag, 0: bit}
            old_end, old_trace = run_partial(old, q, initial, 1)
            ticks = block_length(q, bit)
            new_end, new_trace = run_partial(new, image(q), initial, ticks)
            require(new_end == (image(old_end[0]), old_end[1], old_end[2]),
                    'Special path mismatch: ' + str((q, bit)))
            require(old_end[2] == initial, 'A special block altered the tape')
            # Every end state with its own synchronization predicate receives
            # the required predecessor bit.  This matters for220/0 ->218.
            if old_end[0] in SPECIAL:
                require(old_end[2][old_end[1] - 1] == SPECIAL[old_end[0]],
                        'End tag missing')
            paths.append({'old_state': q, 'left_bit': tag, 'read': bit,
                          'old_steps': 1, 'new_steps': ticks,
                          'old_trace': old_trace, 'new_trace': new_trace,
                          'old_endpoint_state': old_end[0],
                          'new_endpoint_state': new_end[0],
                          'endpoint_head': new_end[1]})
    # Retained helper entries are ordinary simulation steps.  The proof adds
    # no predecessor constraint to their original invocations.
    require(incoming(old, 157) == [(65, 1, 1, 1), (209, 0, 0, 1)], 'Original157 entries')
    for bit in (0, 1):
        require(new[157, bit] == old[157, bit], 'Original157 semantics changed')
    require(incoming(old, 211) == [(163, 1, 1, 1), (180, 1, 1, 1)], 'Original211 entries')
    return ordinary, paths

def negative_controls(old, new):
    # Mutating a helper or predecessor in BOTH machines preserves its ordinary
    # correspondence.  The tag/path proof must reject it independently.
    cases = [
        ('wrong220 predecessor tag', 'both', (216, 0), 0, 1),
        ('wrong181 predecessor tag', 'both', (185, 1), 0, 0),
        ('wrong163 predecessor tag', 'both', (217, 0), 0, 1),
        ('wrong180 predecessor tag', 'both', (132, 1), 0, 0),
        ('wrong218 predecessor tag', 'both', (215, 0), 0, 1),
        ('helper129 changes zero tag', 'both', (129, 0), 0, 1),
        ('helper157 changes current bit', 'both', (157, 0), 0, 1),
        ('helper211 changes one tag', 'both', (211, 1), 0, 0),
        ('wrong218 quotient target', 'new', (211, 0), 2, 90),
        ('wrong163 entry direction', 'new', (163, 0), 1, 1),
        ('wrong220 entry direction', 'new', (220, 0), 1, 1),
        ('wrong181 redirection', 'new', (185, 1), 2, 163),
    ]
    rejected = []
    for name, which, key, field, value in cases:
        a, b = dict(old), dict(new)
        targets = (a, b) if which == 'both' else (b,)
        for t in targets:
            row = list(t[key])
            row[field] = value
            t[key] = tuple(row)
        try:
            certify(a, b)
        except (ValueError, KeyError) as error:
            rejected.append({'name': name, 'rejection': str(error)})
        else:
            raise ValueError('Negative control accepted: ' + name)
    return rejected

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('prefold212', type=Path)
    parser.add_argument('final209', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    old = read_table(args.prefold212, 212)
    new = read_table(args.final209, 209)
    ordinary, paths = certify(old, new)
    rejected = negative_controls(old, new)
    result = {
        'status': 'DIRECT_THREE_FOLD_LOCAL_PASS',
        'prefold_sha256': hashlib.sha256(args.prefold212.read_bytes()).hexdigest(),
        'final_sha256': hashlib.sha256(args.final209.read_bytes()).hexdigest(),
        'old_states': 212, 'new_states': 209,
        'ordinary_rows_checked': ordinary, 'special_cases_checked': len(paths),
        'state_map': {'181': 220, '218': 157, '180': 163, 'otherwise': 'identity'},
        'incoming': {str(k): v for k, v in EXPECTED_INCOMING.items()},
        'paths': paths,
        'clock_identity': 'T209 = T212 + 2*N3 + 4*N5',
        'N3': 'old218 at either read, or old181/220/180 reading0',
        'N5': 'old163 reading0',
        'clock_bound': 'T212 <= T209 <= 5*T212',
        'retained_helpers_unrestricted': [157, 211],
        'negative_controls_rejected': rejected,
        'scope': 'Universal finite local identities with opaque exterior; all common initial tapes '
                 'from state0 via the accompanying induction proof. Source re-layout and '
                 'PA consistency calibration are separate dependencies. No proof-assistant kernel.'
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('paths', 'incoming')}, indent=2))

if __name__ == '__main__':
    main()
