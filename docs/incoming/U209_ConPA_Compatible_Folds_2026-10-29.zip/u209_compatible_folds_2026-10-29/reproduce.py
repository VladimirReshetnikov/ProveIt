#!/usr/bin/env python3
"""Reproduce the frozen U209 construction and its executable proof evidence."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def require(ok, message):
    if not ok:
        raise ValueError(message)


def manifest():
    data = json.loads((ROOT / 'MANIFEST.json').read_text())
    records = data['files']
    for item in records:
        name = item['path']
        path = ROOT / name
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,
                'Unsafe manifest path')
        raw = path.read_bytes()
        require(len(raw) == item['size_bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256'],
                'Manifest mismatch: ' + name)
    print(f'Manifest: {len(records)} frozen files verified.', flush=True)
    return len(records)


def run(name, args):
    print(f'\n{name}', flush=True)
    result = subprocess.run([sys.executable, '-B', *args], cwd=ROOT,
                            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = ROOT / 'build/logs' / (name.replace(' ', '_').replace('/', '_') + '.log')
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(result.stdout)
    if result.returncode:
        print(result.stdout, flush=True)
        raise RuntimeError(name + ' failed; see ' + str(log.relative_to(ROOT)))
    print('PASS', flush=True)
    return str(log.relative_to(ROOT))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--quick', action='store_true', help='Explicitly skip universal primitive replay')
    args = parser.parse_args()
    require(args.quick or (__debug__ and not sys.flags.optimize and not os.environ.get('PYTHONOPTIMIZE')),
            'The full runtime needs enabled assertions; do not use -O or PYTHONOPTIMIZE.')
    started = time.monotonic()
    count = manifest()
    logs = []
    logs.append(run('Pinned proposal comparison', ['code/check_comparison.py']))
    logs.append(run('Deterministic rebuild', ['code/build.py', '--output', 'build/machine']))
    frozen = ROOT / 'machine'
    rebuilt = ROOT / 'build/machine'
    machine_files = sorted(p.name for p in frozen.iterdir() if p.is_file())
    require(set(machine_files) == {p.name for p in rebuilt.iterdir() if p.is_file()},
            'Machine output inventory differs')
    for name in machine_files:
        require((frozen / name).read_bytes() == (rebuilt / name).read_bytes(),
                'Rebuilt artifact differs: ' + name)
    print(f'Exact machine/source rebuild: {len(machine_files)} files match.', flush=True)
    local_args = ['code/check_local.py', 'build/machine/prefold212.native.tm',
                  'build/machine/u209.native.tm', '--output', 'build/evidence/local.json']
    logs.append(run('Independent local quotient', local_args))
    logs.append(run('Local quotient with assertions disabled', ['-O', *local_args[:-1],
                                                               'build/evidence/local_optimized.json']))
    source_args = ['code/check_source_startup.py', '--parent-table', 'inputs/u212.native.tm',
                   '--parent-sites', 'inputs/u212.sites.json', '--prefold-table',
                   'build/machine/prefold212.native.tm', '--candidate-table',
                   'build/machine/u209.native.tm', '--candidate-sites',
                   'build/machine/sites.json', '--output', 'build/evidence/source_startup.json']
    logs.append(run('Independent source and blank startup', source_args))
    logs.append(run('Source startup with assertions disabled', ['-O', *source_args[:-1],
                                                                'build/evidence/source_startup_optimized.json']))
    for name in ['local.json', 'source_startup.json']:
        require(json.loads((ROOT / 'evidence' / name).read_text()) ==
                json.loads((ROOT / 'build/evidence' / name).read_text()),
                'Saved independent evidence differs: ' + name)
    if args.quick:
        print('\nSKIPPED: universal symbolic runtime (--quick was requested).', flush=True)
    else:
        logs.append(run('Universal primitive runtime', [
            'code/check_runtime.py', '--table', 'build/machine/u209.native.tm',
            '--sites', 'build/machine/sites.json', '--output', 'build/evidence',
            '--compare', 'evidence/runtime_cases.json.gz']))
    result = dict(status='QUICK_CHECKS_PASS_RUNTIME_SKIPPED' if args.quick else 'FULL_U209_REPLAY_PASS',
                  manifest_files=count, exact_rebuilt_files=len(machine_files), logs=logs,
                  working_states=209, transition_rows=418, universal_runtime_replayed=not args.quick,
                  native_sha256=hashlib.sha256((frozen / 'u209.native.tm').read_bytes()).hexdigest(),
                  seconds=round(time.monotonic() - started, 6),
                  proof_status='Executable mathematical and symbolic-induction evidence; '
                               'no new proof-assistant endpoint certificate.')
    evidence = ROOT / 'build/evidence'
    evidence.mkdir(parents=True, exist_ok=True)
    (evidence / 'replay.json').write_text(json.dumps(result, indent=2) + '\n')
    print('\n' + json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
