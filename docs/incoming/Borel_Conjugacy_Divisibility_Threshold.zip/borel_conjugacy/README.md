# A Divisibility Threshold for Borel Conjugacy

**Explicit normal forms, measurable classification, and analytic flows on
left-finite series fields**

Research manuscript prepared with ChatGPT, 4 October 2026.

## Contents

- `borel_conjugacy.pdf`: the compiled, 25-page article, including references.
- `borel_conjugacy.tex`: self-contained LaTeX source with embedded bibliography.
- `verify_jets.py`: exact rational finite-jet regression tests; standard library only.
- `verification_report.json`: the principal recorded test run.
- `MANIFEST.sha256`: integrity hashes for the other five files, excluding the manifest itself.

## Mathematical scope

Fix an additive subgroup Z <= Gamma <= Q. L_Gamma consists of real-coefficient
series whose support has finite intersection with every left half-line.
Borelness refers to coefficient coding in the countable product R^Gamma.
The coordinate group consists of Borel ordered-field automorphisms. The order
restriction is automatic when Gamma is 2-divisible, including Gamma = Q.

The central results are:

1. Explicit Borel tangent normalization and complete full-conjugacy invariants
   for the derivations D_a = a(t) t d/dt (Theorems 5.1 and 6.1).
2. A Borel choice of a conjugating coordinate for every supplied conjugate pair,
   including in the nonsmooth cases (Theorem 6.2).
3. Conjugacy is Borel-smooth if and only if at most one prime p satisfies
   p^(-n) in Gamma for every n >= 0 (Theorem 7.4). All nonsmoothness is in
   the zero-gain stratum.
4. Exact nonzero centralizers (Theorem 8.2) and the analytic-flow criterion
   a = 0 or v(a) >= 0 (Theorem 9.3).
5. Borel time dependence of the single coordinate Phi_s(t) already forces
   entire coefficient dependence on time for every field input. Differentiability
   at time zero of these coordinate functions also suffices (Theorem 9.8).
   Borel real vector-group actions factor through one real parameter
   (Corollary 9.9).

The article includes five worked examples, an explicit set-sized surreal
interpretation, a proof-assistant implementation plan, a scope audit, and ten
further research projects.

## Build the PDF

A current TeX Live installation with `latexmk`, `newtx`, `amsmath`, `amsthm`,
`mathtools`, `microtype`, `geometry`, `fancyhdr`, `titlesec`, `enumitem`,
`tcolorbox`, `listings`, `xurl`, and `hyperref` is sufficient.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error borel_conjugacy.tex
```

Alternatively, run `pdflatex borel_conjugacy.tex` three times. There is no
external bibliography database, figure asset, or network dependency.
The supplied PDF was compiled with pdfTeX / TeX Live 2025 and visually checked.

## Reproduce the exact checks

Python 3.10 or newer; no third-party packages:

```sh
python verify_jets.py --degree 24 --seed 20261004 \
  --random-cases 48 --output verification_report.json
```

The included run reports **143 passing checks modulo z^25**, with z=t^(1/d)
for each test's chosen grid. The tests cover normalization residuals, residue
covariance, positive-flow composition and inverses, unit exp/log identities,
and the explicit zero-gain flow. All arithmetic uses `fractions.Fraction`.
The JSON includes exact coefficients of the worked normalizers.

The default command-line settings reproduce the included run. A smaller degree
or fewer random cases can be requested; degrees below 12 are rejected to retain
the explicit test examples.

## Trust and novelty boundary

This is an AI-assisted, unrefereed manuscript with mathematical proofs, not a
Lean- or Rocq-checked development. Finite-jet tests do not establish infinite
support arguments, Borel uniformity, nonsmoothness, or automatic time regularity.
They are regression checks, not proof certificates for the whole article.

Classical normal-form, exponential/logarithm, and dense-orbit mechanisms have
substantial antecedents, credited in the article. Historical priority for the
exact assembled classification, divisibility threshold, and automatic-regularity
formulation has not been independently certified. No remaining published open
question in Elliot Glazer's paper is claimed to have been solved.

The connection to Glazer is his primary paper *A Topological Tennenbaum Theorem*.
The connection to ProveIt is its surreal-series and differential-algebra program.
The article follows up Questions 13.4 and 13.5 in the user's earlier manuscript
*Borel Regularity Forces Summability*, but re-proves the needed rank-one inputs.
Neither Glazer nor the ProveIt maintainer is represented as a coauthor or endorser.

Repository snapshot inspected:
`715a716a3002b1e9f28daa2d81c009a392851b94`.
Relevant documentation: `Algebra/SurrealNumbers/README.md` and root `README.md`.
No repository or Library file was changed. Bibliographic references and the
source review record are embedded in the article.
