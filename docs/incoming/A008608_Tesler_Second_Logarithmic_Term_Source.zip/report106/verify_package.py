#!/usr/bin/env python3
"""Check every shipped asset against its manifest, before rebuilding outputs."""
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent

def fail(message):
    raise ValueError(message)

def main():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    if set(manifest) != {'schema_version','report','files'}:
        fail('Unexpected manifest schema')
    if manifest['schema_version'] != 1 or manifest['report'] != 106:
        fail('Wrong manifest version or report')
    files=manifest['files']
    if not isinstance(files,list) or not files:
        fail('Empty manifest')
    seen=set()
    for item in files:
        if set(item) != {'path','bytes','sha256'}:
            fail('Malformed manifest record')
        name=item['path']
        rel=Path(name)
        if not isinstance(name,str) or rel.is_absolute() or '..' in rel.parts or name in seen:
            fail('Unsafe or duplicate asset path')
        seen.add(name)
        data=(ROOT/rel).read_bytes()
        if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            fail('Mismatch: '+name)
    print('PASS: '+str(len(files))+' shipped assets match manifest')

if __name__=='__main__':
    try:
        main()
    except Exception as exc:
        print('FAIL: '+str(exc),file=sys.stderr)
        sys.exit(1)
