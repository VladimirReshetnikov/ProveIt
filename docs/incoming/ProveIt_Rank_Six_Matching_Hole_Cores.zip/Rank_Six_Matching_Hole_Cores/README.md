# Rank-six cubic sectors for matching-hole cores

The report treats a genuine 3+3 minimum cover whose core is K3,3 with a matching of zero, one, two or three edges removed. Exterior neighborhoods are arbitrary, left activities are one, and right activities are positive.

It proves strict shifted ULC6 for the all-right-core sector in the flag regime and eventual strict ULC6 under common right-core scaling. The complementary case has a 4+2 minimum cover and is already covered at every positive field. This does not prove finite-activity ULC6 in the new cases or cover two holes in a single row or column.

## Files

- `article.pdf` and `article.tex`: six-page report and editable source
- `data/first_gap_certificate.json`: all 25 exact coefficient identities
- `code/verify_first_gap.py`: independent standard-library rational-polynomial replay
- `code/verify_support_counts.py`: 160 direct conditioned-support enumerations
- `data/first_gap_replay.json` and `data/support_checks.json`: recorded results
- `build_local.sh`: local TeX build helper

## Reproduce

Python 3 and its standard library are sufficient:

```sh
python code/verify_first_gap.py
python code/verify_support_counts.py
```

The first command reconstructs the 25 target polynomials and every certificate term, checks exact equality, nonnegative rational weights, complete pair coverage and strict remainder one. It does not run a numerical optimizer. The second command verifies endpoint-support counts directly, with 40 graphs for each number of missing matching edges.

Neighborhoods use bit masks 1 through 7, with the low bit denoting the first left-core slot. The variable order is `(n,p,q,d1,d2,d3)`. Generator indices in each exponent vector are exactly the 18 polynomials listed in Section 2 of the report. Every certificate proves `(n-2)J=1+sum(weight*generator_product)`, with all weights nonnegative rational numbers. The full data contain 1,165 nonzero terms.

The certificate uses the ground-set-normalized Mason theorem through its explicitly stated count inequalities. Its finite cases cover all exterior populations and positive right fields because the identities hold algebraically under those constraints; this is not a bounded population scan.

Two ordinary `pdflatex article.tex` runs build the report on a standard TeX installation. The included helper also supports the research environment's TeX setup.
