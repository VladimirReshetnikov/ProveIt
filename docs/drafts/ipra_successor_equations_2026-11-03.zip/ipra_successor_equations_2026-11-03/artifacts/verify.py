#!/usr/bin/env python3
"""Finite, dependency-free diagnostics for the successor-equation presentation.

These checks are not a proof assistant formalization.  They check the stated AST
ledger, numerical instances of the recursion compiler and equality reflection,
and small propositional calculations.  The report supplies the general proofs.
Run: python3 artifacts/verify.py
"""

from dataclasses import dataclass
from itertools import product
import json
from math import factorial
from pathlib import Path


@dataclass(frozen=True)
class Node:
    tag: str
    children: tuple = ()
    name: str = ""
    descriptor: object = None


def var(name):
    return Node("var", name=name)


ZERO = Node("zero")
X = var("x")


def successor(term):
    return Node("S", (term,))


def eq(left, right):
    return Node("eq", (left, right))


def disjoin(left, right):
    return Node("or", (left, right))


def implies(left, right):
    return Node("implies", (left, right))


def forall(name, formula):
    return Node("forall", (formula,), name=name)


def size(node):
    """One node per constructor, plus the full frozen descriptor of each call."""
    frozen = 0 if node.descriptor is None else size(node.descriptor)
    return 1 + frozen + sum(size(child) for child in node.children)


def occurrences(node, name):
    """Count only active variables; frozen descriptors do not participate."""
    here = int(node.tag == "var" and node.name == name)
    return here + sum(occurrences(child, name) for child in node.children)


def subst_qf(node, name, replacement):
    """Active substitution on quantifier-free syntax, leaving labels frozen."""
    if node.tag in ("forall", "exists"):
        raise ValueError("This helper only accepts quantifier-free syntax.")
    if node.tag == "var" and node.name == name:
        return replacement
    return Node(
        node.tag,
        tuple(subst_qf(child, name, replacement) for child in node.children),
        node.name,
        node.descriptor,
    )


def closure_axiom(equation, parameters, keep_successor_zero):
    rooted = disjoin(eq(X, ZERO), equation)
    successor_case = subst_qf(equation, "x", successor(X))
    if keep_successor_zero:
        successor_case = disjoin(eq(successor(X), ZERO), successor_case)
    result = implies(
        forall("x", implies(rooted, successor_case)),
        forall("x", rooted),
    )
    for parameter in reversed(parameters):
        result = forall(parameter, result)
    return result


class Checks:
    def __init__(self):
        self.count = 0

    def check(self, condition, message):
        self.count += 1
        if not condition:
            raise AssertionError(message)


def check_ast_ledger():
    checks = Checks()
    c = var("c")
    d = var("d")
    descriptor = successor(Node("R", (var("w"), var("v")), descriptor=var("w")))
    call = Node("R", (X, c, d), descriptor=descriptor)
    nested = Node(
        "R", (X, Node("R", (X, c), descriptor=var("w"))),
        descriptor=successor(var("v")),
    )
    cases = [
        ("reflexive", eq(X, X), ()),
        ("one parameter", eq(X, c), ("c",)),
        ("multiple occurrences", eq(nested, successor(X)), ("c",)),
        ("no active x", eq(c, successor(c)), ("c", "d")),
        ("frozen recursor descriptor",
         eq(call, Node("R", (X, d), descriptor=var("w"))), ("c", "d")),
    ]
    rows = []
    for name, equation, parameters in cases:
        f = size(equation)
        k = occurrences(equation, "x")
        p = len(parameters)
        old_size = size(closure_axiom(equation, parameters, True))
        new_size = size(closure_axiom(equation, parameters, False))
        checks.check(old_size == 3 * f + k + p + 17, name + ": old ledger")
        checks.check(new_size == 3 * f + k + p + 12, name + ": new ledger")
        checks.check(old_size - new_size == 5, name + ": saving")
        rows.append({
            "case": name, "equation_nodes": f, "active_x_occurrences": k,
            "parameters": p, "old_nodes": old_size, "new_nodes": new_size,
            "saved_nodes": old_size - new_size,
        })

    # A local formal slot can be printed x; its scope is the frozen descriptor.
    local_descriptor = successor(var("x"))
    scoped_call = Node("R", (X, c), descriptor=local_descriptor)
    replaced = subst_qf(scoped_call, "x", successor(X))
    checks.check(replaced.descriptor is local_descriptor, "label was substituted")
    checks.check(replaced.children[0] == successor(X), "argument not substituted")
    checks.check(size(replaced) == size(scoped_call) + 1, "active/frozen cost")
    return {"checks": checks.count, "cases": rows, "status": "passed"}


def recurse(update, counter, initializer, *parameters):
    if counter < 0:
        raise ValueError("Natural-number counters are required.")
    value = initializer
    for previous_counter in range(counter):
        value = update(value, previous_counter, *parameters)
    return value


def compile_recursion(initial, step):
    """f(0,c)=g(c), f(n+1,c)=k(n,f(n,c),c) becomes R_H(n,g(c),c)."""
    def compiled(counter, *parameters):
        def update(value, previous_counter, *frozen_parameters):
            return step(previous_counter, value, *frozen_parameters)

        return recurse(update, counter, initial(*parameters), *parameters)

    return compiled


def check_recursion_compiler():
    checks = Checks()
    add = compile_recursion(lambda a: a, lambda n, value, a: value + 1)
    multiply = compile_recursion(lambda a: 0, lambda n, value, a: value + a)
    power = compile_recursion(lambda a: 1, lambda n, value, a: value * a)
    fact = compile_recursion(lambda: 1, lambda n, value: (n + 1) * value)
    squares = compile_recursion(lambda: 0, lambda n, value: value + (n + 1) ** 2)
    affine = compile_recursion(
        lambda a, b, c: a,
        lambda n, value, a, b, c: b * value + c * (n + 1),
    )
    for n in range(8):
        for a in range(6):
            checks.check(add(n, a) == a + n, "addition compiler")
            checks.check(multiply(n, a) == a * n, "multiplication compiler")
            checks.check(power(n, a) == a ** n, "power compiler")
        checks.check(fact(n) == factorial(n), "factorial compiler")
        checks.check(squares(n) == n * (n + 1) * (2 * n + 1) // 6, "squares")
    for n, a, b, c in product(range(6), range(3), range(3), range(3)):
        expected = b ** n * a + c * sum(j * b ** (n - j) for j in range(1, n + 1))
        checks.check(affine(n, a, b, c) == expected, "explicit frozen parameters")
    return {
        "checks": checks.count, "status": "passed",
        "sample_functions": ["addition", "multiplication", "power", "factorial",
                             "sum of squares", "parameterized affine recursion"],
        "scope": "Standard natural-number inputs in the explicit finite ranges.",
    }


def q(counter, initializer):
    return recurse(lambda value, previous_counter: previous_counter, counter, initializer)


def case(counter, zero_value, successor_value):
    return recurse(lambda value, n, b: b, counter, zero_value, successor_value)


def monus(a, b):
    return recurse(lambda value, n: q(value, 0), b, a)


def equality_bit(s, t):
    return case(q(monus(s + 1, t), 1), 0, 1)


def check_equality_reflection():
    checks = Checks()
    for n, a, b in product(range(13), range(4), range(4)):
        checks.check(q(n, a) == (a if n == 0 else n - 1), "Q computation")
        checks.check(case(n, a, b) == (a if n == 0 else b), "C computation")
    for s, t in product(range(13), repeat=2):
        checks.check(monus(s, t) == max(s - t, 0), "monus computation")
        residual = monus(s, t)
        checks.check(case(residual, s, t + residual) == s, "residual identity")
        bit = equality_bit(s, t)
        checks.check(bit in (0, 1), "equality bit range")
        checks.check((bit == 0) == (s == t), "equality reflection")
        checks.check((bit == 1) == (s != t), "inequality reflection")
    return {
        "checks": checks.count, "status": "passed", "input_bound_inclusive": 12,
        "formula": "beta(s,t) = C(Q(d(Ss,t),1),0,1)",
        "scope": "Finite arithmetic instances; no nonstandard-model check.",
    }


def check_boolean_reflection():
    checks = Checks()
    rows = []
    for left, right in product((0, 1), repeat=2):
        conjunction = case(left, right, 1)
        disjunction = case(left, 0, right)
        implication = case(left, right, 0)
        a, b = left == 0, right == 0
        checks.check((conjunction == 0) == (a and b), "conjunction reflection")
        checks.check((disjunction == 0) == (a or b), "disjunction reflection")
        checks.check((implication == 0) == ((not a) or b), "implication reflection")
        rows.append({
            "left_bit": left, "right_bit": right, "and_bit": conjunction,
            "or_bit": disjunction, "implies_bit": implication,
        })
    return {
        "checks": checks.count, "status": "passed", "truth_tables": rows,
        "scope": "Decided quantifier-free subformulas only; 0 means true.",
    }


def heyting_implication(a, b):
    return 2 if a <= b else b


def check_three_element_heyting_chain():
    checks = Checks()
    for a, b in product(range(3), repeat=2):
        old = heyting_implication(a, max(0, b))
        new = heyting_implication(a, b)
        checks.check(old == new, "remove a proved-false disjunct")
    for z, p, q_value in product(range(3), repeat=3):
        premises = min(heyting_implication(z, p), heyting_implication(p, q_value))
        conclusion = heyting_implication(max(z, p), q_value)
        checks.check(heyting_implication(premises, conclusion) == 2, "rooted step")
    middle = 1
    excluded_middle = max(middle, heyting_implication(middle, 0))
    checks.check(excluded_middle != 2, "negative control: unrestricted LEM")
    return {
        "checks": checks.count, "status": "passed", "chain": [0, 1, 2],
        "bottom": 0, "top": 2,
        "negative_control": "At p=1, p OR NOT p has value 1, not top.",
        "scope": "One finite Heyting algebra; this is not a completeness argument.",
    }


def main():
    suites = {
        "ast_ledger": check_ast_ledger(),
        "recursion_compiler": check_recursion_compiler(),
        "equality_reflection": check_equality_reflection(),
        "boolean_reflection": check_boolean_reflection(),
        "heyting_chain": check_three_element_heyting_chain(),
    }
    result = {
        "title": "Finite diagnostics for iPRA successor equations",
        "status": "passed",
        "total_checks": sum(suite["checks"] for suite in suites.values()),
        "qualification": (
            "These are finite diagnostics, not a Lean/Rocq formalization, a proof of "
            "bi-interpretability, or an exhaustive model check. See report.tex for proofs."
        ),
        "suites": suites,
    }
    destination = Path(__file__).with_name("results.json")
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "checks": result["total_checks"],
                      "results_file": destination.name}))


if __name__ == "__main__":
    main()
