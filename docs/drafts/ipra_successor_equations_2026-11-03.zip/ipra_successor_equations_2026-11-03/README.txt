iPRA by successor equations
Research package prepared for Vladimir Reshetnikov
3 November 2026
=================================================

Start with report.pdf. AXIOMS.txt is a standalone exact specification.

RESULT
Use genuine intuitionistic first-order equality logic, 0 != S0,
complete primitive-recursion equations, and the schema

 [forall x ((x=0 or E(x,c)) -> E(Sx,c))]
   -> forall x (x=0 or E(x,c)),

universally closed over the other parameters, for every equation E.

The report proves whole-carrier bi-interpretability with full
first-order iPRA, internally identity round trips, and equiconsistency.
The new schema removes an impossible successor-zero branch from the
best inspected foundational core. It is a modest same-language
presentation simplification, not a new arithmetic strength or a claim
of absolute cognitive minimality.

CONTENTS
  report.pdf               Compiled research report
  report.tex + sections/   Complete LaTeX source
  AXIOMS.txt               Exact language and axioms
  artifacts/verify.py      Finite syntax and arithmetic diagnostics
  artifacts/results.json  Recorded check results
  artifacts/build_summary.json
                          Compilation and diagnostics status
  provenance/             Pinned input inventory, hashes, audit
  build.py                Reproduce checks and PDF
  SHA256SUMS.txt           Integrity manifest

REPRODUCTION
From this directory:
  python3 build.py

Requires Python 3.10+ and pdflatex with the standard packages listed
in report.tex. The diagnostics themselves use only Python's standard
library. Run just those with:
  python3 artifacts/verify.py

The 1,650 finite checks support the calculations and exact size ledger.
They are not a Lean/Rocq formalization and do not prove statements
about all nonstandard models. The mathematical proof is in the report.

SOURCE SNAPSHOT
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 77e7fdf4a46344cc79cc9c88d78954bab1764ec5
Directory: docs/drafts, including its archived subdirectory.
Four active and four archived ZIP files were inspected. The input ZIPs
are not duplicated here; provenance files identify them exactly.

No repository write or publication was performed.
