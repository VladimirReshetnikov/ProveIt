#!/usr/bin/env python3
"""Reproduce the finite diagnostics, compiled report, and integrity manifest."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def main() -> None:
    root = Path(__file__).resolve().parent
    artifacts = root / "artifacts"
    logs = artifacts / "build_logs"
    logs.mkdir(parents=True, exist_ok=True)
    if shutil.which("pdflatex") is None:
        raise SystemExit("pdflatex is required; the diagnostics can run independently.")
    check = subprocess.run(
        [sys.executable, str(artifacts / "verify.py")],
        cwd=root, text=True, capture_output=True, check=False,
    )
    (logs / "diagnostics.txt").write_text(check.stdout + check.stderr, encoding="utf-8")
    if check.returncode:
        raise SystemExit("Finite diagnostics failed; see artifacts/build_logs/diagnostics.txt.")
    passes = []
    for number in range(1, 4):
        run = subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=root, text=True, capture_output=True, check=False,
        )
        (logs / f"latex_pass_{number}.txt").write_text(
            run.stdout + run.stderr, encoding="utf-8"
        )
        passes.append({"pass": number, "exit_code": run.returncode})
        if run.returncode:
            raise SystemExit(f"LaTeX pass {number} failed; inspect its build log.")
    log = (root / "report.log").read_text(encoding="utf-8", errors="replace")
    problems = [
        line for line in log.splitlines()
        if "Overfull" in line or "undefined" in line.lower()
        or "multiply defined" in line.lower()
    ]
    summary = {
        "diagnostics_exit_code": check.returncode,
        "latex_passes": passes,
        "layout_or_reference_warnings": problems,
        "proof_status": "Written mathematical proof; finite diagnostics only.",
    }
    (artifacts / "build_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    for suffix in (".aux", ".log", ".out", ".toc"):
        (root / ("report" + suffix)).unlink(missing_ok=True)
    paths = [
        p for p in sorted(root.rglob("*"))
        if p.is_file() and p.name != "SHA256SUMS.txt"
        and "__pycache__" not in p.parts
    ]
    manifest = "\n".join(
        f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(root).as_posix()}"
        for p in paths
    ) + "\n"
    (root / "SHA256SUMS.txt").write_text(manifest, encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
