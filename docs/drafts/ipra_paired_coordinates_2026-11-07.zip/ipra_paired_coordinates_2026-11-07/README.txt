PAIRED COORDINATES: A SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026

RESULT

The smallest complete checker has 444 normalized significant Python tokens,
457 AST nodes, and 1,316 normalized UTF-8 bytes. It accepts closed sentences.
The companion accepting arbitrary free numerical parameters has 448 tokens,
462 AST nodes, and 1,338 normalized bytes.

Both beat every coordinate of the 457 / 469 / 1,352 current lower envelope
across all ten root checker variants in the six ProveIt draft archives at:

  8b00e6ea50c664476e3a3289a78287946e5e0a34

The metric includes the complete program: grammar data, input, checking,
exception handling, and verdicts. It is pinned to CPython 3.12.14. The
original narrower exception policy still leaves both winners below the old
envelope. This is a strict reduction relative to a finite corpus, not a
global shortestness theorem.

THE NEW IDEA AND ITS LIMITS

Positive raw coordinates 2j-1 and 2j both name bound variable j. The packed
sort-and-scope state then locates an opening slot directly. All permitted
alias spellings are handled by a syntactic normalization theorem, including
recursor updates: internal recursion uniqueness supplies real equality
proofs where literal comparison alone is insufficient.

The arithmetic and logical basis is inherited and credited. The report
states all six rules and both recursion schemas, reconstructs full
intuitionistic first-order logic and quantifier-free induction, and gives
whole-domain ordinary bi-interpretations with iPRA. Both composite
isomorphisms are internally defined by x=y, including at nonstandard
recursion counters. No new smaller arithmetic axiom basis is claimed.

A second new invariant obtains fresh names from context length. Its two
complete checkers also beat the old envelope, but are larger than the new
global-name winners. They are included as a proved alternative with explicit
cost ablations. The open context implementation uses O(N) root-budget memory;
dense names are advisable. The source-size result is not a speed claim.

START HERE

  report.pdf                    Complete self-contained paper
  report.tex, sections/*.tex     All LaTeX sources
  checker_declared.py           Smallest checker, closed-sentence interface
  checker_scanned.py            Arbitrary free parameters, no root budget
  checker.py                    Alternative context-capacity open interface
  checker_closed.py             Context-capacity closed companion
  FORMAT.txt                    Exact grammar, instructions, and four interfaces
  examples/                     Positive and negative certificates
  comparison/                   All ten frozen current kernels, hashes, metrics
  validation/                   Proof transport, named oracle, independent audits
  results/                      Measurements and complete validation records
  reproduce.py                  Re-run executable evidence without a network
  build.py                      Recompile report.pdf with pdfLaTeX
  package.py                    Rebuild the clean ZIP and integrity manifest
  ATTRIBUTION.txt                Precise inherited/new contribution boundary
  LICENSE_SOURCE.txt            Preserved source MIT No Attribution license
  MANIFEST.sha256               Hashes of all other delivered files

RUN

  python3 checker_declared.py examples/reflexivity.json
  python3 checker_scanned.py examples/open_reflexivity.json
  python3 checker.py examples/context_reflexivity.json
  python3 reproduce.py
  python3 build.py

The first three print ACCEPT and exit 0. Rejection prints REJECT and exits 1.
The checkers require Python 3.10+ syntax and only the standard library.
The delivered PDF is already compiled.

FORMATS

Declared, scanned, and context-closed checkers:
  [proof instructions in reverse consumption order, goal]

Context-open checker.py only:
  [proof instructions in reverse consumption order, N, goal]

N is a declaration budget, not a list of logical assumptions. Integer-zero
context markers cannot be used as formula hypotheses. Canonical budgets are
nonnegative integers; Python's negative-integer and Boolean aliases are
harmless metadata spellings described in FORMAT.txt.

All programs validate every used substitution image at its own depth zero.
Wholly unused witness annotations and unread prefixes can be inert. No
arbitrary source evaluator or external trusted logical library is imported.

EVIDENCE

The scanned-name program replays 45 original roots; the declared-name
program replays 45 closed specializations, with 20 scoped-name audits, 20 real CLI
checks, four explicit mixed-alias proof checks, and 66 independently checked
eigenparameter allocations. Ten closed roots remain unchanged; 35 are
explicit zero specializations.

The context suite replays 180 instances of 45 source proofs under four alias
policies, stored as 119 distinct certificates. It includes named substitution
and freshness checks, malformed-data and capture tests, and real CLI runs.
A second independent audit adds boundary, randomized opening, whole-packet,
and deliberate-defect sensitivity checks. Exact counts and overlaps are in
the report and JSON results; they are not a count of distinct theorems.

The general proofs are mathematical and independently reviewed, not
formalized in Lean/Rocq. Finite tests do not prove consistency. Very large
valid certificates may exceed a particular Python process's resources.

COMBINATORS

The paper proves scoped obstacles for stable-only logic, deletion of equality
transport, total numerical SK, universal primitive-recursive evaluators, and
the natural reduct-based round trip for abstract partial application.
These are not a universal impossibility result for combinator presentations.
A smaller complete combinator arithmetic remains unestablished.
