CERTIFICATE EXAMPLES

Open-interface example:

    python3 checker.py examples/alias_examples/alias_requires_derivation_proved.json

This returns ACCEPT. The companion one-instruction shortcut
examples/alias_examples/alias_requires_derivation.json returns REJECT.

The open checker reads a JSON array

    [last_instruction, ..., first_instruction, parameter_budget, goal]

and consumes it from right to left. Canonical parameter_budget values are
nonnegative integers. The metadata creates that many inert zero entries in
the proof context; the entries are not formulas or assumptions. Parameters
-1 through -parameter_budget are thereby permitted at the root. Every
negative integer in numerical syntax is a symbolic parameter name, not a
negative natural number. Positive coordinate aliases {2j-1,2j} both denote
bound coordinate j. Numerical zero remains integer 0.

The implementation's list-repetition operation treats Boolean metadata as
0/1 and negative integer metadata as budget zero. This harmless enlargement
of certificate metadata does not add assumptions or arithmetic axioms.

corpus/ stores 119 distinct certificates representing 180 checks of 45
inherited theorem proofs under four alias policies. A particular variant
may share the stored file of an earlier identical variant; the full mapping
is in results/validation.json.

audits/ contains 36 deliberately varied accepted and rejected certificates.
Consult results/validation.json for expected outcomes; do not expect every
file under examples/ to be a proof.

alias_examples/ contains the three explicitly described alias examples.
Their valid longer derivations preserve the literal raw goal formulas.

closed/ is for checker_closed.py. It omits parameter_budget:

    [last_instruction, ..., first_instruction, goal]

The closed companion is not intended to accept free root parameters.
There are 45 checked zero specializations and one deliberate rejection.

OTHER COMPLETE CHECKERS

checker_declared.py is the smallest executable and uses a global monotone
supply for closed roots. checker_scanned.py accepts free root parameters and
scans used syntax to keep its global supply fresh. Both consume packets
without a parameter-budget entry:

    [last_instruction, ..., first_instruction, goal]

Their examples are under global_variants/declared/ and
 global_variants/scanned/, respectively. Records in
results/global_variants.json map all 45 source proofs to the stored files;
identical serialized outputs are deduplicated within each variant.

The global_variants/*_audits/ directories contain both positive and negative
controls. Some identical packets intentionally have different outcomes in
the scanned and declared interfaces: an undeclared free name is permitted
by the scanned interface and rejected by the closed declared interface.
The *_aliases/ directories contain the explicit alias proofs for each
variant. The closed variant specializes the displayed free root parameter
to zero; the scanned variant preserves that root parameter literally.
