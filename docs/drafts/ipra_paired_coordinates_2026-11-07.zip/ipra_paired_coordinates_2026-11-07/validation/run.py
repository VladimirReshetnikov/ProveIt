"""Untrusted audits for paired-coordinate iPRA with context-derived names.

The checker is supplied separately and never imports this file. The named
syntax/substitution oracle comes from the pinned scope draft; its explicit
constructor parser is independent of the candidate's packed-depth table.
The proof oracle below uses named substitution and explicit native rules.
"""
from __future__ import annotations
import argparse
import hashlib
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import types

sys.dont_write_bytecode = True

from transport_resource import Replay, PairedReplay, compile_resource


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def negative(a):
    if type(a) is int:
        return {a} if a < 0 else set()
    if type(a) is list:
        return set().union(*(negative(b) for b in a))
    return set()


def paired(a, parity=lambda j: 0):
    if type(a) is int and a > 0:
        return 2*a - 1 + parity(a)
    if type(a) is list:
        return [paired(b, parity) for b in a]
    return a


def decoded(a):
    if type(a) is int and a > 0:
        return (a + 1)//2
    if type(a) is list:
        return [decoded(b) for b in a]
    return a


class ContextOracle:
    """Named binder oracle; no packed-depth traversal or global fresh supply."""
    def __init__(self, reference):
        self.reference = reference
        self.stack = []
        self.allocations = []

    def opening(self, a, images=(), formula=True, lower=0):
        r = self.reference
        syntax = r.NamedSyntax()
        tree = (syntax.formula if formula else syntax.term)(a, holes=len(images))
        names = r.negative_names(tree)
        if any(x < lower for x in names):
            raise ValueError('undeclared parameter in fixed syntax')
        replacements = {}
        for i in sorted(r.used_holes(tree)):
            replacements[i] = syntax.term(images[i])
            if any(x < lower for x in r.negative_names(replacements[i])):
                raise ValueError('undeclared parameter in used image')
        result = r.substitute_names(tree, replacements)
        return (syntax.formula_data if formula else syntax.term_data)(result)

    def eigen(self, a, g, major=None):
        relevant = [a, *(h for h in g if type(h) is list)]
        if major is not None:
            relevant.append(major)
        names = set().union(*(negative(h) for h in relevant))
        e = -len(g) - 1
        if e in names or any(e >= n for n in names):
            raise AssertionError(('not fresh', e, names))
        self.allocations.append({'context_size': len(g), 'eigen': e,
                                 'relevant_names': sorted(names)})
        return e

    def check(self, a, g):
        lower = -len(g)
        self.opening(a, lower=lower)
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, g):
                if len(major) == 3:
                    e = self.eigen(a, g, major)
                    assumption = self.opening(major[0], [e], lower=e)
                    return self.check(a, [*g, assumption])
                if len(major) == 1:
                    motive, images = major[0], (0, annotation)
                else:
                    motive, images = annotation, major
                base, result = (self.opening(motive, [v], lower=lower) for v in images)
                return result == a and self.check(base, g)
            return a in g
        if len(a) == 1 and instruction == []:
            body = a[0]
            local = [self.opening(body, [0], lower=lower)]
            if len(body) == 2:
                local.append(body)
            e = self.eigen(a, g)
            goal = self.opening(body, [[e]], lower=e)
            assumptions = [self.opening(b, [e], lower=e) for b in local]
            return self.check(goal, [*g, *assumptions])
        if len(a) == 3 and type(instruction) is list and len(instruction) == 1:
            return self.check(self.opening(a[0], [instruction[0]], lower=lower), g)
        if (len(a) == 2 and type(a[0]) is list and len(a[0]) == 3
                and instruction == []):
            n, initial, update = a[0]
            expected = initial
            if n != 0:
                if type(n) is not list or len(n) != 1:
                    raise ValueError('counter not zero or successor')
                n = n[0]
                expected = self.opening(update, [[n, initial, update], n],
                                        formula=False, lower=lower)
            return a[1] == expected
        return a in g

    def verdict(self, certificate):
        self.allocations = []
        try:
            raw = deepcopy(certificate)
            goal = decoded(raw.pop())
            declaration = raw.pop()
            g = [0] * declaration
            self.stack = [decoded(x) for x in raw]
            return bool(self.check(goal, g))
        except Exception:
            return False


def candidate_verdict(module, certificate):
    try:
        data = deepcopy(certificate)
        goal = data.pop()
        g = [0] * data.pop()
        module.take = data.pop
        return bool(module.check(goal, g))
    except Exception:
        return False


def ordered(goal, instructions, budget=0):
    return list(reversed(instructions)) + [budget, goal]


def refl(t):
    axiom = [[0, t, 0], t]
    return [[axiom, [1, t]], [], []]


def fixed_audits():
    audits = []
    def put(name, goal, instructions, expected, budget=0):
        audits.append({'name': name, 'certificate': ordered(goal, instructions, budget),
                       'expected': expected})
    put('zero_reflexivity', [0, 0], refl(0), True)
    put('declared_parameter', [-1, -1], refl(-1), True, 1)
    put('undeclared_root_parameter', [-1, -1], refl(-1), False, 0)
    put('parameter_below_declaration', [-2, -2], refl(-2), False, 1)
    put('dummy_zero_is_not_a_formula', 0, [None], False, 10)
    put('literal_contradiction', [0, [0]], [None], False)
    put('Boolean_is_not_a_term', [[0, True, 0], True], [[]], False)
    put('binary_term_rejected', [[0, [0, 0], 0], [0, 0]], [[]], False)
    for h in (1, 2, 3, 4):
        rhs = [0, 0, h] if h <= 2 else 0
        put(f'recursor_slot_alias_{h}', [[[0], 0, h], rhs], [[]], True)
    for h in (5, 6):
        put(f'free_coordinate_in_update_{h}', [[0, 0, h], 0], [[]], False)
    for h in (1, 2):
        put(f'root_coordinate_rejected_{h}', [h, h], [None], False)
    for h in (3, 4):
        put(f'coordinate_beyond_Q_{h}', [[h, h]], [[]], False)
    # The aliases in this matrix differ syntactically but open to the same term.
    put('mixed_alias_reflexivity_under_Q', [[1, 2]], [[]] + refl([-1]), True)
    # Used malformed witnesses must not become bound during insertion.
    body = [[1, 3]]
    goal = [body, [0, 0], [0, 0]]
    for witness in (1, 2):
        put(f'capture_under_Q_{witness}', goal, [[witness], []] + refl([-1]), False)
    term = [0, 0, 1]
    goal = [[[0, 0, 5], term], [0, 0], [0, 0]]
    put('capture_under_recursor', goal, [[1]] + refl(term), False)
    # A dummy induction assumption for compound formulas would admit this proof.
    body = [[3, 3], [0, 0], [0, 0]]
    major = [[-1, -1], [0, 0], [0, 0]]
    goal = [body]
    put('compound_IH_unavailable', goal,
        [[], [major, None], None, [0]] + refl([-1]), False)
    # Demand validation ignores only truly unused images.
    vacuous = [[0, 0, 0], 0]
    used = [[0, 1, 0], 1]
    for i, witness in enumerate((None, True, 1, 2, [1], [0, 0, 5])):
        put(f'unused_bad_witness_{i}', [vacuous, [0, 0], [0, 0]], [[witness], []], True)
        put(f'used_bad_witness_{i}', [used, [0, 0], [0, 0]], [[witness], []], False)
    put('invalid_existential_padding', [vacuous, True, [0, 0]], [[0], []], False)
    return audits


def capture_inst(module, source, budget):
    source = source.replace('    b = inst(a)\n', '    capture(inst)\n    b = inst(a)\n', 1)
    namespace = {'__name__': 'opening_instrumentation'}
    captured = []
    namespace['capture'] = captured.append
    exec(compile(source, '<instrumented checker>', 'exec'), namespace)
    stream = [None]
    namespace['take'] = stream.pop
    namespace['check']([0, 0], [0] * budget)
    return captured[0]


def random_openings(checker_source, reference, samples=384):
    rng = random.Random(2026110719)
    inst = capture_inst(None, checker_source, 8)
    oracle = ContextOracle(reference)
    def term(size, depth=0, holes=0):
        if not size or rng.randrange(3) == 0:
            return rng.choice([0, -1, -5, -8, *range(1, depth+holes+1)])
        if rng.randrange(2):
            return [term(size-1, depth, holes)]
        return [term(size-1, depth, holes), term(size-1, depth, holes),
                term(size-1, depth+2, holes)]
    def formula(size, depth=0, holes=0):
        if not size or rng.randrange(3) == 0:
            return [term(2, depth, holes), term(2, depth, holes)]
        if rng.randrange(2):
            return [formula(size-1, depth+1, holes)]
        return [formula(size-1, depth+1, holes),
                formula(max(0,size-2), depth+1, holes),
                formula(max(0,size-2), depth+1, holes)]
    comparisons = 0
    for holes in (0, 1, 2):
        for is_formula in (False, True):
            for _ in range(samples//6):
                a = (formula if is_formula else term)(4, holes=holes)
                images = [term(3) for _ in range(holes)]
                expected = oracle.opening(a, images, formula=is_formula, lower=-8)
                # Different occurrences may use different aliases in this opening audit.
                randomized = lambda j: rng.randrange(2)
                actual = inst(paired(a, randomized), [paired(t, randomized) for t in images],
                              d=0 if is_formula else 1)
                if decoded(actual) != expected:
                    raise AssertionError(('named-opening discrepancy', a, images, actual, expected))
                if inst(actual, d=0 if is_formula else 1) != actual:
                    raise AssertionError('opening output is not locally closed')
                comparisons += 1
    return {'seed': 2026110719, 'named_substitution_comparisons': comparisons,
            'result_closure_checks': comparisons}


def main():
    here = Path(__file__).resolve().parent
    root = here.parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, default=root/'checker.py')
    parser.add_argument('--closed-checker', type=Path, default=root/'checker_closed.py')
    parser.add_argument('--reference', type=Path, default=here/'reference')
    parser.add_argument('--output', type=Path, default=root/'examples')
    parser.add_argument('--results', type=Path, default=root/'results'/'validation.json')
    parser.add_argument('--alias-proofs', type=Path, default=here/'reference'/'alias_inputs')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((args.reference/'provenance.json').read_text())
    for item in manifest['frozen_files'] + manifest['new_alias_inputs']:
        if hashlib.sha256((args.reference/item['file']).read_bytes()).hexdigest() != item['sha256']:
            raise AssertionError(('Reference source changed', item['file']))
    reference = load(args.reference/'named_oracle.py', 'frozen_named_reference')
    module = load(args.checker, 'paired_context_candidate')
    source = args.checker.read_text()
    oracle = ContextOracle(reference)
    records = []
    sources = sorted((args.reference/'theorems').glob('*.json'))
    unique_certificates = {}
    for source_file in sources:
        tree = Replay(json.loads(source_file.read_text())).theorem()
        names = negative(tree.goal)
        budget = -min(names) if names else 0
        mapping = {n: n for n in names}
        native = compile_resource(tree, 'context', mapping, budget)
        for variant, parity in [('odd',lambda j:0),('even',lambda j:1),
                                ('alternating',lambda j:j%2),('opposite',lambda j:(j+1)%2)]:
            certificate = [paired(x,parity) for x in native[:-1]] + [budget, paired(native[-1],parity)]
            accepted = candidate_verdict(module, certificate)
            named_accepted = oracle.verdict(certificate)
            preserved = decoded(certificate[-1]) == tree.goal
            if not (accepted and named_accepted and preserved):
                raise AssertionError(('corpus failure', source_file.name, variant,
                                      accepted, named_accepted, preserved))
            serialized = json.dumps(certificate,separators=(',',':'))+'\n'
            digest = hashlib.sha256(serialized.encode()).hexdigest()
            if digest in unique_certificates:
                target = unique_certificates[digest]
            else:
                target = args.output/'corpus'/variant/source_file.name
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_text(serialized)
                unique_certificates[digest] = target
            records.append({'source':source_file.name, 'alias_variant':variant,
                            'example_file':str(target.relative_to(args.output)), 'sha256':digest,
                            'accepted':accepted, 'named_oracle_accepted':named_accepted,
                            'root_preserved_after_decoding':preserved,
                            'instructions':len(certificate)-2,
                            'fresh_allocations_checked':len(oracle.allocations)})
    closed_module = load(args.closed_checker, 'closed_paired_candidate')
    closed_records = []
    for source_file in sources:
        tree = Replay(json.loads(source_file.read_text())).theorem()
        native = compile_resource(tree, 'context')
        certificate = [paired(x) for x in native]
        stack = deepcopy(certificate)
        goal = stack.pop()
        closed_module.take = stack.pop
        accepted = bool(closed_module.check(goal, []))
        semantic = oracle.verdict(certificate[:-1]+[0,certificate[-1]])
        if not accepted or not semantic:
            raise AssertionError(('closed companion failure', source_file.name))
        destination = args.output/'closed'/source_file.name
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_text(json.dumps(certificate,separators=(',',':'))+'\n')
        closed_records.append({'source':source_file.name, 'accepted':True,
                               'named_oracle_accepted':True,
                               'original_root_preserved':decoded(certificate[-1])==tree.goal,
                               'example_file':str(destination.relative_to(args.output))})
    alias_examples = []
    if args.alias_proofs is not None:
        for name, expected in [('recursor_update_alias_identity', True),
                               ('alias_requires_derivation_proved', True),
                               ('alias_requires_derivation', False)]:
            original = json.loads((args.alias_proofs/(name+'.json')).read_text())
            names = negative(original[-1])
            budget = -min(names) if names else 0
            if expected:
                tree = PairedReplay(original).theorem()
                raw = compile_resource(tree, 'context', {n:n for n in names}, budget)
                certificate = raw[:-1] + [budget, raw[-1]]
            else:
                certificate = original[:-1] + [budget, original[-1]]
            actual = candidate_verdict(module, certificate)
            semantic = oracle.verdict(certificate)
            if actual != expected or certificate[-1] != original[-1]:
                raise AssertionError(('alias-proof transport failure', name, actual, expected))
            if expected and not semantic:
                raise AssertionError(('alias proof rejected after decoding', name))
            destination = args.output/'alias_examples'/(name+'.json')
            destination.parent.mkdir(parents=True,exist_ok=True)
            destination.write_text(json.dumps(certificate,separators=(',',':'))+'\n')
            alias_examples.append({'name':name,'expected':expected,'candidate':actual,
                                   'named_oracle_after_decoding':semantic,
                                   'literal_root_preserved':True,
                                   'instructions':len(certificate)-2})
    audits = fixed_audits()
    audit_results = []
    for audit in audits:
        actual = candidate_verdict(module,audit['certificate'])
        named = oracle.verdict(audit['certificate'])
        if actual != audit['expected'] or named != audit['expected']:
            raise AssertionError(('audit failure',audit['name'],actual,named,audit['expected']))
        target = args.output/'audits'/(audit['name']+'.json')
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(json.dumps(audit['certificate'],separators=(',',':'))+'\n')
        audit_results.append({'name':audit['name'],'expected':audit['expected'],
                              'candidate':actual,'named_oracle':named})
    # Positive-control mutant: removing image closure validation must be detected.
    old = 'inst(env[a - d >> 1], d=1)'
    if source.count(old) != 1:
        raise AssertionError('capture mutation site changed')
    mutant = types.ModuleType('unsafe_capture_mutant')
    exec(compile(source.replace(old,'env[a - d >> 1]'), '<capture-mutant>', 'exec'),mutant.__dict__)
    controls = []
    for audit in audits:
        if audit['name'].startswith('capture_'):
            accepted = candidate_verdict(mutant,audit['certificate'])
            if not accepted:
                raise AssertionError(('capture positive control did not fire',audit['name']))
            controls.append({'name':audit['name'],'unsafe_mutant_accepted':True,
                             'candidate_rejected':True})
    openings = random_openings(source,reference)
    # Exercise the actual CLI, including declaration parsing and fail-closed output.
    cli_results=[]
    cli_paths=[(args.output/records[0]['example_file'],True)]
    cli_paths += [(args.output/'audits'/(a['name']+'.json'),a['expected']) for a in audits]
    cli_paths += [(args.output/'alias_examples'/(r['name']+'.json'),r['expected']) for r in alias_examples]
    for path,expected in cli_paths:
        completed=subprocess.run([sys.executable,str(args.checker),str(path)],capture_output=True,text=True)
        ok=completed.returncode==0 and completed.stdout.strip()=='ACCEPT'
        rejected=completed.returncode==1 and completed.stdout.strip()=='REJECT'
        if ok!=expected or (not expected and not rejected):
            raise AssertionError(('CLI failure',path.name,completed.returncode,completed.stdout))
        cli_results.append({'file':str(path.relative_to(args.output)), 'expected':expected,
                            'returncode':completed.returncode,'stdout':completed.stdout.strip()})
    closed_cli_results = []
    closed_jobs = [(args.output/'closed'/sources[0].name,True)]
    invalid_closed = args.output/'closed'/'undeclared_root_parameter.json'
    invalid_closed.write_text(json.dumps(ordered([-1,-1],refl(-1))[:-2]+[[-1,-1]],separators=(',',':'))+'\n')
    closed_jobs.append((invalid_closed,False))
    for path,expected in closed_jobs:
        completed=subprocess.run([sys.executable,str(args.closed_checker),str(path)],capture_output=True,text=True)
        ok=completed.returncode==0 and completed.stdout.strip()=='ACCEPT'
        rejected=completed.returncode==1 and completed.stdout.strip()=='REJECT'
        if ok!=expected or (not expected and not rejected):
            raise AssertionError(('closed CLI failure',path.name,completed.returncode,completed.stdout))
        closed_cli_results.append({'file':str(path.relative_to(args.output)), 'expected':expected,
                                   'returncode':completed.returncode,'stdout':completed.stdout.strip()})
    result={'source_theorems':len(sources),'transported_alias_certificates':len(records),
            'distinct_corpus_files':len(unique_certificates),
            'checker_sha256':hashlib.sha256(args.checker.read_bytes()).hexdigest(),
            'closed_checker_sha256':hashlib.sha256(args.closed_checker.read_bytes()).hexdigest(),
            'closed_companion_checks':closed_records,
            'closed_cli_checks':closed_cli_results,
            'root_preservation_checks':sum(r['root_preserved_after_decoding'] for r in records),
            'named_oracle_fresh_allocations':sum(r['fresh_allocations_checked'] for r in records),
            'audits':audit_results,'alias_examples':alias_examples,'capture_positive_controls':controls,
            'random_openings':openings,'cli_checks':cli_results,'corpus':records,
            'all_passed':True,
            'limitations':'Finite executable checks, not a formal proof of soundness, completeness, or bi-interpretability.'}
    args.results.parent.mkdir(parents=True,exist_ok=True)
    args.results.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('audits','corpus','cli_checks','closed_companion_checks')},indent=2))

if __name__=='__main__':
    sys.setrecursionlimit(max(100000,sys.getrecursionlimit()))
    main()
