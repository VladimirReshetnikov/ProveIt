"""Independent adversarial audit of the context-capacity iPRA checker.

Run: python3 audit_final_context.py --checker /path/to/checker.py --output /tmp/audit
Only the Python standard library is required. The audit imports the supplied
checker without running its CLI. It extracts the actual nested inst function
unchanged for comparison with an explicit, independently written traversal.
Finite tests complement, and do not mechanize, the metatheoretic proof.
"""
from pathlib import Path
import argparse
import ast
import copy
import hashlib
import importlib.util
import json
import random
import subprocess
import sys


def load_checker(path, name='context_audit_kernel'):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def extracted_inst(source):
    """Expose exactly the production inner traversal with a supplied lower bound."""
    tree = ast.parse(source)
    check = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'check')
    inner = next(n for n in check.body if isinstance(n, ast.FunctionDef) and n.name == 'inst')
    factory = ast.FunctionDef(
        name='make_inst',
        args=ast.arguments(posonlyargs=[], args=[ast.arg(arg='k')], kwonlyargs=[],
                           kw_defaults=[], defaults=[]),
        body=[copy.deepcopy(inner), ast.Return(value=ast.Name(id='inst', ctx=ast.Load()))],
        decorator_list=[])
    module = ast.fix_missing_locations(ast.Module(body=[factory], type_ignores=[]))
    namespace = {}
    exec(compile(module, '<unchanged-production-inst>', 'exec'), namespace)
    return namespace['make_inst']


def decode(a):
    if type(a) is int:
        return (a + 1) // 2 if a > 0 else a
    return [decode(b) for b in a]


def encode(a):
    if type(a) is int:
        return 2 * a - 1 if a > 0 else a
    return [encode(b) for b in a]


def ordinary_open(a, images=(), depth=0, numeric=False, capacity=0):
    """Independent explicit standard-index syntax oracle, without width tables."""
    if numeric and type(a) is int:
        if a < -capacity:
            raise ValueError('undeclared rigid parameter')
        if a <= depth:
            return a
        return ordinary_open(images[a - depth - 1], (), 0, True, capacity)
    if type(a) is not list:
        raise ValueError('expected list or numerical integer')
    if numeric:
        if len(a) == 1:
            return [ordinary_open(a[0], images, depth, True, capacity)]
        if len(a) == 3:
            return [ordinary_open(a[0], images, depth, True, capacity),
                    ordinary_open(a[1], images, depth, True, capacity),
                    ordinary_open(a[2], images, depth + 2, True, capacity)]
    else:
        if len(a) == 1:
            return [ordinary_open(a[0], images, depth + 1, False, capacity)]
        if len(a) == 2:
            return [ordinary_open(x, images, depth, True, capacity) for x in a]
        if len(a) == 3:
            return [ordinary_open(x, images, depth + 1, False, capacity) for x in a]
    raise ValueError('invalid constructor arity')


def raw_open(a, images=(), depth=0, numeric=False):
    """Untrusted proof-builder substitution, preserving each protected alias."""
    if numeric and type(a) is int:
        if a <= 0 or (a + 1) // 2 <= depth:
            return a
        return copy.deepcopy(images[(a + 1) // 2 - depth - 1])
    if type(a) is not list:
        raise ValueError('bad builder expression')
    if numeric and len(a) == 1:
        return [raw_open(a[0], images, depth, True)]
    if numeric and len(a) == 3:
        return [raw_open(a[0], images, depth, True),
                raw_open(a[1], images, depth, True),
                raw_open(a[2], images, depth + 2, True)]
    if not numeric and len(a) == 1:
        return [raw_open(a[0], images, depth + 1, False)]
    if not numeric and len(a) == 2:
        return [raw_open(x, images, depth, True) for x in a]
    if not numeric and len(a) == 3:
        return [raw_open(x, images, depth + 1, False) for x in a]
    raise ValueError('bad builder arity')


class Proof:
    def __init__(self, goal, instruction, *children):
        self.goal, self.instruction, self.children = goal, instruction, children
    def events(self):
        return [self.instruction] + [e for p in self.children for e in p.events()]
    def packet(self, capacity=0):
        return self.events()[::-1] + [capacity, self.goal]


def ax(l, r):
    return Proof([l, r], [])


def transport(major, motive, minor):
    l, r = major.goal
    before = raw_open(motive, [l])
    after = raw_open(motive, [r])
    if before != minor.goal:
        raise ValueError(('builder premise mismatch', before, minor.goal))
    return Proof(after, [major.goal, motive], major, minor)


def refl(t):
    p = ax([0, t, 0], t)
    return transport(p, [1, t], p)


def sym(p):
    return transport(p, [1, p.goal[0]], refl(p.goal[0]))


def trans(p, q):
    if p.goal[1] != q.goal[0]:
        raise ValueError('builder transitivity mismatch')
    return transport(q, [p.goal[0], 1], p)


T = [0, 0]
D = [0, [0]]


def truth_with_scope(capacity):
    fresh = -(capacity + 1)
    # The two aliases of the bound variable intentionally differ.
    q = Proof([[1, 2]], [], refl([fresh]))
    return Proof(T, [q.goal, 0], q, refl(0))


def alias_identity():
    # One external parameter (-1); the closure eigenparameter is -2.
    fresh = -2
    matrix = [[1, 0, 1], [2, 0, 2]]
    u0, v0 = [fresh, 0, 1], [fresh, 0, 2]
    su, sv = [[fresh], 0, 1], [[fresh], 0, 2]
    ih = Proof([u0, v0], 0)
    step = trans(trans(ax(su, u0), ih), sym(ax(sv, v0)))
    major = Proof([matrix], [], step)
    base = trans(ax([0, 0, 1], 0), sym(ax([0, 0, 2], 0)))
    u, v = [-1, 0, 1], [-1, 0, 2]
    identity = Proof([u, v], [major.goal, -1], major, base)
    target = trans(ax([0, u, 0], u), identity)
    return identity, target, Proof([[0, u, 0], v], [])


def run_packet(kernel, packet):
    work = copy.deepcopy(packet)
    try:
        kernel.take = work.pop
        verdict = bool(kernel.check(kernel.take(), [0] * kernel.take()))
        return verdict, len(work)
    except BaseException:
        return False, len(work) if type(work) is list else None


def run_sequent(kernel, goal, events, context):
    work = copy.deepcopy(events[::-1])
    try:
        kernel.take = work.pop
        return bool(kernel.check(copy.deepcopy(goal), copy.deepcopy(context)))
    except BaseException:
        return False


def opening_audit(make_inst):
    rng = random.Random(408211)
    counts = {'integer_boundary_comparisons': 0, 'random_alias_commutations': 0,
              'canonical_embedding_equalities': 0, 'malformed_opening_comparisons': 0}
    def result(call):
        try:
            return True, call()
        except Exception:
            return False, None
    def vary(a):
        if type(a) is int:
            return 2 * a - rng.randrange(2) if a > 0 else a
        return [vary(b) for b in a]
    def term(capacity, depth, size, external=0):
        if size <= 0 or rng.randrange(4) == 0:
            return rng.choice(list(range(-capacity, depth + external + 1)))
        if rng.randrange(3) == 0:
            return [term(capacity, depth, size - 1, external)]
        return [term(capacity, depth, size - 1, external),
                term(capacity, depth, size - 1, external),
                term(capacity, depth + 2, size - 1, external)]
    def formula(capacity, depth, size, external=0):
        if size <= 0 or rng.randrange(3) == 0:
            return [term(capacity, depth, size, external), term(capacity, depth, size, external)]
        if rng.randrange(2):
            return [formula(capacity, depth + 1, size - 1, external)]
        return [formula(capacity, depth + 1, size - 1, external) for _ in range(3)]
    for capacity in range(4):
        inst = make_inst(-capacity)
        for depth in range(5):
            for q in range(4):
                images = [-min(i, capacity) for i in range(q)]
                for a in range(-6, 33):
                    got = result(lambda: inst(a, images, 2 * depth + 1))
                    want = result(lambda: ordinary_open(decode(a), images, depth, True, capacity))
                    assert got[0] == want[0], (capacity, depth, q, a, got, want)
                    if got[0]:
                        assert decode(got[1]) == want[1]
                    counts['integer_boundary_comparisons'] += 1
    for _ in range(1200):
        capacity, depth, q, numeric = rng.randrange(5), rng.randrange(5), rng.randrange(4), rng.randrange(2)
        size = rng.randrange(4)
        a = (term if numeric else formula)(capacity, depth, size, q)
        images = [term(capacity, 0, rng.randrange(4)) for _ in range(q)]
        inst = make_inst(-capacity)
        expected = ordinary_open(a, images, depth, bool(numeric), capacity)
        actual = inst(vary(a), [vary(b) for b in images], 2 * depth + numeric)
        assert decode(actual) == expected
        counts['random_alias_commutations'] += 1
        canonical = inst(encode(a), [encode(b) for b in images], 2 * depth + numeric)
        assert canonical == encode(expected)
        counts['canonical_embedding_equalities'] += 1
    bad = [True, False, None, 0.0, 1.0, '', 'x', {}, [], [0, 0], [0, 0, 0, 0]]
    for a in bad:
        for d in range(8):
            got = result(lambda: make_inst(0)(a, (), d))
            want = result(lambda: ordinary_open(a, (), d // 2, bool(d % 2), 0))
            assert got[0] == want[0], (a, d, got, want)
            counts['malformed_opening_comparisons'] += 1
    return counts


def boundary_packets():
    cases = []
    def add(name, proof, capacity, expected, category):
        cases.append({'name': name, 'packet': proof.packet(capacity),
                      'expected': expected, 'category': category})
    add('truth_at_capacity_zero', refl(0), 0, True, 'positive control')
    add('contradiction_is_not_a_hypothesis', Proof(D, 0), 0, False, 'contradiction')
    add('undeclared_root_parameter', refl(-1), 0, False, 'root declaration')
    add('declared_root_parameter', refl(-1), 1, True, 'root declaration')
    add('last_declared_parameter', refl(-4), 4, True, 'root declaration')
    add('first_undeclared_parameter', refl(-5), 4, False, 'root declaration')
    for a in [1, 2, 3, 4]:
        add('unbound_positive_term_' + str(a), Proof([a, a], 0), 8, False, 'positive variable')
    for a in [0, False, True, 1, 2]:
        add('scalar_goal_' + repr(a), Proof(a, 0), 3, False, 'dummy assumption/formula sort')
    malformed = [[], [0], [0, 0, 0, 0], [[0, 0], 0], [[0, 0, 0, 0], 0],
                 [T, 0, T], [False, 0], [True, 0], ['', 0], [{}, 0]]
    for i, a in enumerate(malformed):
        add('invalid_shape_' + str(i), Proof(a, 0), 3, False, 'formation')
    ex_used = [[1, 1], T, T]
    add('used_future_witness', Proof(ex_used, [-1], refl(-1)), 0, False, 'future parameter')
    add('declared_used_witness', Proof(ex_used, [-1], refl(-1)), 1, True, 'future parameter')
    ex_unused = [T, T, T]
    add('unused_future_annotation_is_ignored', Proof(ex_unused, [-1], refl(0)), 0, True, 'demand policy')
    add('unused_malformed_annotation_is_ignored', Proof(ex_unused, [False], refl(0)), 0, True, 'demand policy')
    # Witnesses with free positive indices must not become captured in R's update.
    t = [0, 0, 5]
    ex_rec = [[t, t], T, T]
    for witness in [1, 2]:
        fake = [0, 0, witness]
        add('capture_under_recursion_alias_' + str(witness),
            Proof(ex_rec, [witness], refl(fake)), 0, False, 'nested capture')
    valid_t = [0, 0, -1]
    add('closed_witness_under_recursion', Proof(ex_rec, [-1], refl(valid_t)), 1, True, 'nested capture')
    # Also protect an existential image under a logical binder.
    ex_q = [[[3, 4]], T, T]
    fake_q = Proof([[1, 2]], [], refl([-1]))
    add('capture_under_closure', Proof(ex_q, [1], fake_q), 0, False, 'nested capture')
    valid_q = Proof([[-1, -1]], [], refl(-1))
    add('closed_witness_under_closure', Proof(ex_q, [-1], valid_q), 1, True, 'nested capture')
    # A would-be existential eigenvariable occurs in the conclusion before allocation.
    exists_zero = [[1, 0], T, T]
    major = Proof(exists_zero, [0], refl(0))
    escape = Proof([-1, 0], [major.goal, 0], major, Proof([-1, 0], 0))
    add('existential_eigenparameter_escape', escape, 0, False, 'eigenparameter escape')
    # Ordinary E elimination is still usable when its conclusion is independent.
    valid_elim = Proof(T, [major.goal, 0], major, refl(0))
    add('existential_elimination_valid', valid_elim, 0, True, 'eigenparameter escape')
    # Q introduction on a compound matrix must not make the whole B(y) an IH.
    b = [[1, 3], T, T]
    by = raw_open(b, [-1])
    bsy = raw_open(b, [[-1]])
    leaf = Proof(bsy, [[-1]], refl([-1]))
    false_step = Proof(bsy, [by, 0], Proof(by, 0), leaf)
    full_induction = Proof([b], [], false_step)
    add('attempted_full_formula_induction', full_induction, 0, False, 'induction restriction')
    # Two sibling scopes deliberately reuse the SAME local parameter name.
    for capacity in [0, 1, 3]:
        p = truth_with_scope(capacity)
        siblings = transport(p, [1, 0], truth_with_scope(capacity))
        add('sibling_name_reuse_capacity_' + str(capacity), siblings, capacity, True, 'sibling scope reuse')
    # An unsuccessful speculative major enters a scope, then falls back to an
    # actual hypothesis. A following sibling scope must use context capacity,
    # independently of the failed attempt's internal allocations.
    failing_q = Proof([[1, 0]], [], Proof([[-3], 0], 0))
    speculative_hypothesis = Proof(T, [failing_q.goal, 0], failing_q)
    continuation = truth_with_scope(2)
    body = transport(speculative_hypothesis, [1, 0], continuation)
    speculative = Proof([T], [], body)
    add('failed_major_has_no_fresh_state_leakage', speculative, 0, True, 'speculative scope')
    identity, repaired, naive = alias_identity()
    add('noncanonical_update_alias_identity', identity, 1, True, 'alias normalization')
    add('noncanonical_alias_target_with_derivation', repaired, 1, True, 'alias normalization')
    add('noncanonical_alias_target_naive_R0', naive, 1, False, 'alias normalization')
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    checker = args.checker.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    (output / 'fixtures').mkdir(exist_ok=True)
    source = checker.read_text()
    kernel = load_checker(checker)
    opening = opening_audit(extracted_inst(source))
    cases = boundary_packets()
    results = []
    for case in cases:
        verdict, unread = run_packet(kernel, case['packet'])
        assert verdict == case['expected'], (case['name'], verdict, case['expected'])
        if verdict:
            assert unread == 0, (case['name'], unread)
        path = output / 'fixtures' / (case['name'] + '.json')
        path.write_text(json.dumps(case['packet'], separators=(',', ':')) + '\n')
        proc = subprocess.run([sys.executable, str(checker), str(path)],
                              capture_output=True, text=True, timeout=15)
        expected_output = 'ACCEPT' if case['expected'] else 'REJECT'
        assert proc.stdout.strip() == expected_output and proc.returncode == (0 if case['expected'] else 1), \
            (case['name'], proc.returncode, proc.stdout, proc.stderr)
        results.append({'name': case['name'], 'category': case['category'],
                        'expected': case['expected'], 'in_process': verdict,
                        'cli': expected_output, 'unread': unread,
                        'proof_events': len(case['packet']) - 2})
    dummy_checks = []
    for dummy in [0, False]:
        for goal in [0, False, True, D]:
            accepted = run_sequent(kernel, goal, [0], [dummy])
            assert accepted is False, (dummy, goal)
            dummy_checks.append({'dummy': dummy, 'goal': goal, 'accepted': accepted})
    # Deliberate defects establish that the relevant negative fixtures are live.
    by_name = {c['name']: c for c in cases}
    defects = [
        ('omit_early_goal_validation', 'b = inst(a)', 'b = a',
         'existential_eigenparameter_escape'),
        ('omit_capacity_guard', 'and a >= k', 'and True', 'undeclared_root_parameter'),
        ('permit_compound_induction', '[:2 - len(b) % 2]', '[:2]',
         'attempted_full_formula_induction'),
    ]
    controls = []
    for name, before, after, fixture in defects:
        assert source.count(before) == 1, (name, 'source no longer matches control')
        namespace = {'__name__': 'deliberately_defective_audit_copy'}
        exec(compile(source.replace(before, after), '<' + name + '>', 'exec'), namespace)
        class Defect:
            pass
        defect = Defect()
        # exec-defined functions close over their namespace, so set the reader there.
        work = copy.deepcopy(by_name[fixture]['packet'])
        namespace['take'] = work.pop
        verdict = bool(namespace['check'](namespace['take'](), [0] * namespace['take']()))
        assert verdict is True, (name, 'negative fixture missed the defect')
        controls.append({'defect': name, 'fixture': fixture, 'defective_copy_accepts': verdict})
    report = {
        'status': 'PASS', 'checker_sha256': hashlib.sha256(checker.read_bytes()).hexdigest(),
        'opening': opening, 'packet_cases': len(results),
        'in_process_runs': len(results), 'cli_runs': len(results),
        'internal_dummy_boundary_checks': len(dummy_checks),
        'defect_sensitivity_controls': len(controls),
        'accepted_packets': sum(c['expected'] for c in cases),
        'rejected_packets': sum(not c['expected'] for c in cases),
        'cases': results, 'dummy_checks': dummy_checks, 'controls': controls,
        'limits': 'Finite tests do not prove consistency or mechanize the normalization and bi-interpretability theorems.'
    }
    (output / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
    summary = {k: v for k, v in report.items() if k not in ('cases', 'dummy_checks', 'controls')}
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
