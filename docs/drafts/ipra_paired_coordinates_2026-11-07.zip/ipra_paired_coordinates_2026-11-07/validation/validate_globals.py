"""Validate the global-supply paired-coordinate variants, offline.

The open scanned variant is compared with the frozen explicit named oracle.
The closed declared variant is compared with that oracle plus an explicit
predeclaration check. No packed-depth traversal is copied into the oracle.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
from run import decoded, load, paired
from transport_resource import Replay, PairedReplay, compile_resource


def verdict(module, certificate):
    try:
        stream = deepcopy(certificate)
        module.k = 0
        module.take = stream.pop
        return bool(module.check(stream.pop(), []))
    except Exception:
        return False


def named_verdict(oracle, certificate):
    stream = [decoded(x) for x in deepcopy(certificate)]
    goal = stream.pop()
    return oracle.verdict([goal, stream])[0]


def main():
    root = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=root)
    args = parser.parse_args()
    root = args.root.resolve()
    reference = root/'validation'/'reference'
    manifest = json.loads((reference/'provenance.json').read_text())
    for item in manifest['frozen_files'] + manifest['new_alias_inputs'] + manifest['derived_inputs']:
        if hashlib.sha256((reference/item['file']).read_bytes()).hexdigest() != item['sha256']:
            raise AssertionError(('source hash changed',item['file']))
    source = load(reference/'named_oracle.py','frozen_global_named_reference')

    class DeclaredOracle(source.NamedOracle):
        """Explicitly reject names below the already declared global supply."""
        def opening(self, a, images=(), formula=True):
            syntax = source.NamedSyntax()
            tree = (syntax.formula if formula else syntax.term)(a,holes=len(images))
            if any(n < self.k for n in source.negative_names(tree)):
                raise ValueError('future fixed parameter')
            for i in sorted(source.used_holes(tree)):
                image = syntax.term(images[i])
                if any(n < self.k for n in source.negative_names(image)):
                    raise ValueError('future parameter in used image')
            return super().opening(a,images,formula)

    variants={'scanned':load(root/'checker_scanned.py','scanned_checker'),
              'declared':load(root/'checker_declared.py','declared_checker')}
    oracles={'scanned':source.NamedOracle('demand'), 'declared':DeclaredOracle('demand')}
    records=[]
    written={}
    def save(group,name,certificate):
        text=json.dumps(certificate,separators=(',',':'))+'\n'
        digest=hashlib.sha256(text.encode()).hexdigest()
        key=group,digest
        if key in written:
            return written[key]
        p=root/'examples'/'global_variants'/group/name
        p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
        written[key]=str(p.relative_to(root))
        return written[key]
    theorems=sorted((reference/'theorems').glob('*.json'))
    for path in theorems:
        original=json.loads(path.read_text())
        tree=Replay(original).theorem()
        for name,module in variants.items():
            native=(original if name=='scanned'
                    else compile_resource(tree,'declared'))
            certificate=[paired(x) for x in native]
            accepted=verdict(module,certificate)
            named=named_verdict(oracles[name],certificate)
            preserved=decoded(certificate[-1])==original[-1]
            if not accepted or not named or (name=='scanned' and not preserved):
                raise AssertionError(('theorem failure',name,path.name,accepted,named,preserved))
            file=save(name,path.name,certificate)
            records.append({'variant':name,'source':path.name,'accepted':accepted,
                            'named_oracle':named,'original_root_preserved':preserved,
                            'zero_specialization':name=='declared' and not preserved,
                            'fresh_allocations_checked':len(oracles[name].allocations),
                            'file':file})
    audits=[]
    expected=json.loads((reference/'closed_cases.json').read_text())['cases']
    for case in expected:
        original=json.loads((reference/'closed_audits'/(case['name']+'.json')).read_text())
        certificate=[paired(x) for x in original]
        for name,module in variants.items():
            want=case['expected_'+name]
            accepted=verdict(module,certificate)
            named=named_verdict(oracles[name],certificate)
            if accepted!=want or named!=want:
                raise AssertionError(('scope audit failure',name,case['name'],accepted,named,want))
            file=save(name+'_audits',case['name']+'.json',certificate)
            audits.append({'variant':name,'name':case['name'],'expected':want,
                           'candidate':accepted,'named_oracle':named,'file':file})
    aliases=[]
    for stem in ('recursor_update_alias_identity','alias_requires_derivation_proved'):
        original=json.loads((reference/'alias_inputs'/(stem+'.json')).read_text())
        tree=PairedReplay(original).theorem()
        for name,module in variants.items():
            certificate=original if name=='scanned' else compile_resource(tree,'declared')
            accepted=verdict(module,certificate)
            named=named_verdict(oracles[name],certificate)
            if not accepted or not named:
                raise AssertionError(('alias proof failure',name,stem,accepted,named))
            file=save(name+'_aliases',stem+'.json',certificate)
            aliases.append({'variant':name,'name':stem,'accepted':accepted,
                            'named_oracle':named,'literal_root_preserved':certificate[-1]==original[-1],
                            'instructions':len(certificate)-1,'file':file})
    cli=[]
    for record in audits:
        program=root/('checker_'+record['variant']+'.py')
        completed=subprocess.run([sys.executable,str(program),str(root/record['file'])],capture_output=True,text=True)
        accepted=completed.returncode==0 and completed.stdout.strip()=='ACCEPT'
        rejected=completed.returncode==1 and completed.stdout.strip()=='REJECT'
        if accepted!=record['expected'] or (not record['expected'] and not rejected):
            raise AssertionError(('CLI failure',record,completed.returncode,completed.stdout))
        cli.append({'variant':record['variant'],'name':record['name'],
                    'exit_code':completed.returncode,'stdout':completed.stdout.strip()})
    result={'status':'PASS','source_theorems':len(theorems),
            'scanned_theorem_checks':sum(r['variant']=='scanned' for r in records),
            'declared_theorem_checks':sum(r['variant']=='declared' for r in records),
            'scanned_roots_preserved':sum(r['variant']=='scanned' and r['original_root_preserved'] for r in records),
            'declared_roots_preserved':sum(r['variant']=='declared' and r['original_root_preserved'] for r in records),
            'declared_zero_specializations':sum(r['zero_specialization'] for r in records),
            'scope_audit_checks':len(audits),'cli_checks':len(cli),
            'alias_proof_checks':len(aliases),
            'named_oracle_fresh_allocations':sum(r['fresh_allocations_checked'] for r in records),
            'checker_sha256':{name:hashlib.sha256((root/('checker_'+name+'.py')).read_bytes()).hexdigest() for name in variants},
            'theorems':records,'scope_audits':audits,'alias_proofs':aliases,'cli':cli,
            'limits':'Finite implementation and transport checks, not machine formalization of the metatheorems.'}
    (root/'results').mkdir(exist_ok=True)
    (root/'results'/'global_variants.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('theorems','scope_audits','alias_proofs','cli')},indent=2))

if __name__=='__main__':
    sys.setrecursionlimit(max(100000,sys.getrecursionlimit()))
    main()
