"""Untrusted transport from the pinned native demand kernel to resource naming.

Proof reconstruction follows the old checker; output certificates must be
accepted independently by a target checker. Free numerical parameters that
are not active eigenparameters are specialized to zero. This preserves
closed root conclusions. Original invalid major branches used only before a
hypothesis fallback are omitted.
"""
from dataclasses import dataclass
import json
from pathlib import Path
import sys

@dataclass
class Node:
    goal: object
    command: object
    premises: list
    eigen: int | None = None
    assumptions_added: int = 0

    def size(self):
        return 1 + sum(n.size() for n in self.premises)

class Replay:
    def __init__(self, certificate):
        self.stream = list(certificate)
        self.k = 0

    def inst(self, a, env=(), d=0):
        if type(a) is int and d % 2:
            self.k = min(self.k, a)
            return a if a <= d // 2 else self.inst(env[a - d // 2 - 1], d=1)
        return [self.inst(b, env, d + w) for b, w in zip(a + [], ((None, b'\2', b'\1\1', b'\2\2\2'), (None, b'\0', b'', b'\0\0\4'))[d % 2][len(a)], strict=True)]

    def check(self, a, g):
        b = self.inst(a)
        command = self.stream.pop()
        premises = []
        match (a, command):
            case [_, [m, t]]:
                major = self.check(m, g)
                if major is None:
                    return Node(a, None, []) if a in g else None
                premises.append(major)
                if len(m) == 3:
                    h = m[:1]
                else:
                    if len(m) == 1:
                        t, m = m[0], [0, t]
                    b, c = (self.inst(t, [v]) for v in m)
                    if c != a:
                        return None
                    minor = self.check(b, g)
                    return Node(a, command, premises + [minor]) if minor else None
            case [[b], []]:
                h = [self.inst(b, [0]), b][:2 - len(b) % 2]
            case [[b, _, _], [t]]:
                child = self.check(self.inst(b, [t]), g)
                return Node(a, command, [child]) if child else None
            case [[[n, t, h], b], []]:
                if n:
                    n, = n
                    t = self.inst(h, ([n, t, h], n), d=1)
                return Node(a, command, []) if b == t else None
            case _:
                return Node(a, None, []) if a in g else None
        self.k -= 1
        eigen = self.k
        child = self.check(self.inst(b, [[eigen]]), g + [self.inst(c, [eigen]) for c in h])
        return Node(a, command, premises + [child], eigen, len(h)) if child else None

    def theorem(self):
        goal = self.stream.pop()
        result = self.check(goal, [])
        if result is None:
            raise ValueError('Old proof rejected')
        return result


class PairedReplay(Replay):
    """Read the paired-coordinate, globally fresh predecessor without decoding.

    Keeping aliases literal is necessary for examples whose root formulas
    deliberately distinguish the two raw coordinate spellings.
    """
    def inst(self, a, env=(), d=0):
        if type(a) is int and d % 2:
            self.k = min(self.k, a)
            return a if a < d else self.inst(env[(a-d)//2], d=1)
        widths = ((None, bytes([2]), bytes([1,1]), bytes([2,2,2])),
                  (None, bytes([0]), None, bytes([0,0,4])))
        return [self.inst(b, env, d+w)
                for b,w in zip(a+[], widths[d%2][len(a)])]


def rename(value, mapping):
    if type(value) is int and value < 0:
        return mapping.get(value, 0)
    if type(value) is list:
        return [rename(x, mapping) for x in value]
    return value


def compile_resource(tree, policy='context', root_mapping=None, initial_context_size=0):
    count = tree.size()
    instructions = []
    declared_supply = 0

    def visit(n, mapping, context_size):
        nonlocal declared_supply
        instructions.append(rename(n.command, mapping))
        position = len(instructions)
        if n.eigen is None:
            for child in n.premises:
                visit(child, mapping, context_size)
        else:
            for major in n.premises[:-1]:
                visit(major, mapping, context_size)
            if policy == 'declared':
                declared_supply -= 1
                eigen = declared_supply
            else:
                eigen = (-context_size - 1 if policy == 'context'
                         else len(instructions) - count - 1)
            visit(n.premises[-1], mapping | {n.eigen: eigen},
                  context_size + n.assumptions_added)

    root_mapping = {} if root_mapping is None else root_mapping
    visit(tree, root_mapping, initial_context_size)
    assert len(instructions) == count
    return list(reversed(instructions)) + [rename(tree.goal, root_mapping)]


def main():
    policy, source, target = sys.argv[1:]
    tree = Replay(json.loads(Path(source).read_text())).theorem()
    result = compile_resource(tree, policy)
    Path(target).write_text(json.dumps(result, separators=(',', ':')) + '\n')

if __name__ == '__main__':
    sys.setrecursionlimit(max(100000, sys.getrecursionlimit()))
    main()
