VALIDATION SUPPORT (UNTRUSTED)

From the archive root, run:

    python3 validation/run.py

The command validates checker.py and checker_closed.py, regenerates the
examples, and writes results/validation.json. Python 3.10 or later and the
standard library suffice. No network request or external file is needed.
Neither acceptance checker imports anything in this directory.

BOUNDARIES AND SOURCES

reference/named_oracle.py is an unchanged copy of validation/run.py from
ipra_scope_2026-11-07.zip at ProveIt commit
8b00e6ea50c664476e3a3289a78287946e5e0a34. Only its explicit named syntax and
substitution helpers are called; its original validation CLI is not run.
reference/theorems/ contains the 45 theorem certificates used from that same
archive. reference/provenance.json records the archive Git blob identifier,
original archive member paths, and SHA-256 hashes of every retained source.
These hashes are checked before validation starts.

reference/alias_inputs/ contains three NEW examples from this report's
independent alias investigation. They are not represented as repository
baseline files. Their hashes and origin are recorded separately.

WHAT IS CHECKED

1. transport_resource.py replays the source proof and changes its free-name
   convention. It specializes any auxiliary free parameters not occurring
   in the root to zero, renames each eigenparameter to the target context's
   fresh name, and preserves all original root parameters. It may discard a
   failed major proof when the source checker ultimately uses a hypothesis
   fallback. This compiler is untrusted: all emitted certificates must be
   accepted again by the target checker.

2. All 45 source root formulas are preserved after coordinate decoding.
   Four coherent alias policies yield 180 checked proof instances. Duplicate
   serialized certificates are stored once: there are 119 distinct corpus
   files, with the complete mapping in results/validation.json.

3. A separate proof oracle uses explicit native logical rules, uniquely
   named bound variables, and named substitution. It independently checks
   each fresh eigenparameter against the retained context and conclusion.
   It checks 132 eigenparameter allocations across the 180 proof instances.

4. There are 36 fixed audits: 13 expected acceptances and 23 expected
   rejections. They cover declared/free names, Boolean and malformed terms,
   both coordinate aliases, recursor slots, out-of-scope coordinates,
   compound induction hypotheses, malformed existential padding, and used
   versus unused substitution images.

5. Removing closure validation from substitution images creates an unsafe
   in-memory mutant. Three capture attacks are accepted by that mutant and
   rejected by the actual checker. The mutant is never written as a checker
   artifact or imported by the real acceptance program.

6. A deterministic random generator supplies 384 term/formula opening
   problems, using zero, one, or two substitution images and mixed coordinate
   aliases. Decoding the actual result agrees with named substitution in
   every case. Every result is also checked for local closure.

7. The independent alias investigation supplies 18- and 20-instruction
   proofs whose literal, noncanonical root formulas are preserved. A
   one-instruction computation shortcut is rejected. The named oracle accepts
   the DECODED shortcut because decoding identifies its aliases; this is an
   intentional certificate-language refinement, not evidence that the raw
   shortcut is valid. The longer accepted proof supplies the missing raw
   derivation.

8. The closed companion accepts 45 zero specializations of the source
   proofs. Ten already had closed roots and retain those original roots;
   the other 35 specialize the original free parameters to zero. These are
   reported separately from the open checker's root-preserving tests.

9. The real command-line wrappers are exercised on 40 open-interface cases
   and two closed-interface cases, checking both return code and stdout.

LIMITATIONS

These are finite implementation and transport checks. They are not a
machine-formalized proof of soundness, completeness, consistency, or
bi-interpretability. The general arguments are in the accompanying paper.
The named oracle deliberately checks decoded native meaning; raw coordinate
aliases are not a primitive conversion rule in either acceptance checker.

The public interface is the standalone CLI. The internal check(a,g) function
can of course check consequences of the supplied assumptions; calling that
function with user-selected formula assumptions is not theorem acceptance.

GLOBAL-SUPPLY VARIANTS

Run:

    python3 validation/validate_globals.py

This writes results/global_variants.json. checker_scanned.py accepts free
root parameters and updates a global lower bound by scanning used syntax.
checker_declared.py is the smallest complete executable in this package;
it accepts closed root sentences and declares one new global name at each
numerical eigenparameter rule. Neither uses the explicit root-budget field
of checker.py.

The open global variant is checked on the 45 directly converted inherited
certificates, preserving every root after coordinate decoding. The closed
global variant is checked on 45 recompiled zero specializations, including
ten unchanged closed roots. Both variants are also checked on ten frozen
scope-control cases: 20 candidate/oracle comparisons and 20 actual CLI runs.
The cases distinguish prior declarations from future names, allow inert
unused annotations, and check sibling and failed-major behavior. Four more
checks cover the two explicit alias derivations in each variant. Named
oracles check 66 fresh allocations across the theorem corpus.

reference/closed_audits/ stores the ten additional frozen source fixtures.
reference/closed_cases.json contains their expected outcomes selected from
the frozen scope report; the original source report path, field, and SHA-256
are recorded there. This selected metadata is marked as derived input in
provenance.json, not as an unchanged repository file.

INDEPENDENT CONTEXT AUDIT

Run:

    python3 validation/independent_context_audit.py --checker checker.py --output validation/independent_context

The independent script is copied without modification from the separate
investigation for this report. Its results and 44 packet fixtures are in
validation/independent_context/. It checks 3,120 integer-boundary cases,
1,200 random alias/substitution commutations, 1,200 canonical embedding
identities, and 88 malformed-opening comparisons. Its 44 packet cases are
checked in process and through the actual CLI; it also checks eight inert
context boundaries and three deliberately defective positive controls.
This audit concerns checker.py (context capacity), whose recorded SHA-256
matches the delivered file. It does not by itself validate the distinct
global naming conventions; validate_globals.py covers those differences.
