"""Create a clean deliverable ZIP and SHA-256 integrity manifest."""
import hashlib
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent
EXCLUDED_SUFFIXES={'.aux','.log','.out','.toc','.pyc','.synctex.gz'}


def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts
                  and p.suffix not in EXCLUDED_SUFFIXES
                  and not any(part.startswith('.') for part in p.relative_to(ROOT).parts)
                  and p.name!='MANIFEST.sha256')


def main():
    items=files()
    manifest=ROOT/'MANIFEST.sha256'
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in items))
    destination=ROOT.parent/(ROOT.name+'.zip')
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for p in [*items,manifest]:
            info=zipfile.ZipInfo((Path(ROOT.name)/p.relative_to(ROOT)).as_posix(), date_time=(2026,11,7,12,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o644<<16
            archive.writestr(info,p.read_bytes())
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise AssertionError('ZIP integrity check failed')
    print(destination)
    print('Files:',len(items)+1,'Bytes:',destination.stat().st_size)


if __name__=='__main__':
    main()
