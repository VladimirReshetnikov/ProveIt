"""Compile the self-contained report with pdfLaTeX."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    subprocess.run([sys.executable, str(ROOT/'measure.py')], cwd=ROOT, check=True, stdout=subprocess.DEVNULL)
    for _ in range(3):
        run = subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','report.tex'], cwd=ROOT, capture_output=True, text=True)
        if run.returncode:
            print(run.stdout[-10000:])
            raise SystemExit(run.returncode)
    log=(ROOT/'report.log').read_text(errors='replace')
    bad=[line for line in log.splitlines() if 'Overfull' in line or 'undefined' in line]
    if bad:
        print('\n'.join(bad))
        raise SystemExit('Review LaTeX warnings before delivery')
    print('Compiled report.pdf successfully.')


if __name__ == '__main__':
    main()
