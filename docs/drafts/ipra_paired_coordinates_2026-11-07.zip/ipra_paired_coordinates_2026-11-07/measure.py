"""Reproduce the whole-program comparison against all ten pinned root kernels."""
import csv
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    spec = importlib.util.spec_from_file_location('frozen_metric', ROOT/'comparison/source_measure.py')
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    manifest = json.loads((ROOT/'comparison/manifest.json').read_text())
    rows = []
    for entry in manifest['programs']:
        measured = metric.metrics(ROOT/'comparison'/entry['path'])
        if measured['sha256'] != entry['sha256']:
            raise ValueError('Changed pinned source: ' + entry['label'])
        rows.append({**entry, **measured})
    names = {
        'declared_closed': 'checker_declared.py',
        'scanned_open': 'checker_scanned.py',
        'context_open': 'checker.py',
        'context_closed': 'checker_closed.py',
    }
    candidates = {label: {'file': name, **metric.metrics(ROOT/name)} for label, name in names.items()}
    envelope = {key: min(row[key] for row in rows) for key in KEYS}
    core_envelope = {key: min(row['core'][key] for row in rows) for key in KEYS}
    results = ROOT/'results'
    results.mkdir(exist_ok=True)
    ablation_dir = ROOT/'comparison/ablations'
    ablation_dir.mkdir(exist_ok=True)
    ablations = []
    for label, name in names.items():
        source = (ROOT/name).read_text()
        experiments = {
            'exception_only': source.replace('    except:\n', '    except Exception:\n'),
            'ordinary_coordinates': source.replace('a < d', 'a <= d // 2').replace('env[a - d >> 1]', 'env[a - d // 2 - 1]'),
        }
        for change, text in experiments.items():
            path = ablation_dir/(label+'__'+change+'.py')
            path.write_text(text)
            ablations.append({'label': label+'/'+change, 'file': str(path.relative_to(ROOT)), **metric.metrics(path)})
    result = {
        'snapshot': manifest['commit'], 'python': platform.python_version(),
        'archive_count': len(manifest['files']), 'program_count': len(rows),
        'coordinatewise_minimum': envelope, 'core_coordinatewise_minimum': core_envelope,
        'programs': rows, 'candidates': candidates, 'ablations': ablations,
        'strict_whole_program_reduction': {name: all(m[key] < envelope[key] for key in KEYS) for name, m in candidates.items()},
        'strict_core_reduction': {name: all(m['core'][key] < core_envelope[key] for key in KEYS) for name, m in candidates.items()},
    }
    if len(rows) != 10 or len(manifest['files']) != 6:
        raise AssertionError('Unexpected current comparison corpus')
    if not all(result['strict_whole_program_reduction'].values()):
        raise AssertionError('A stated complete-program reduction no longer holds')
    if not all(result['strict_core_reduction'].values()):
        raise AssertionError('A stated core reduction no longer holds')
    (results/'metrics.json').write_text(json.dumps(result, indent=2)+'\n')
    with (results/'metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ['label', 'source_tokens', *KEYS, 'raw_bytes', 'sha256'], extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
        writer.writerows({'label': 'new/'+name, **m} for name,m in candidates.items())
    macros = {'BaseTokens':envelope[KEYS[0]], 'BaseAST':envelope[KEYS[1]], 'BaseBytes':envelope[KEYS[2]],
              'OldCoreTokens':core_envelope[KEYS[0]], 'OldCoreAST':core_envelope[KEYS[1]], 'OldCoreBytes':core_envelope[KEYS[2]],
              'PythonVersion':platform.python_version()}
    for name,prefix in [('declared_closed','New'),('scanned_open','Open'),('context_open','Context'),('context_closed','ContextClosed')]:
        m = candidates[name]
        for suffix,key in [('Tokens',KEYS[0]),('AST',KEYS[1]),('Bytes',KEYS[2])]:
            macros[prefix+suffix] = m[key]
            macros[prefix+'Core'+suffix] = m['core'][key]
    (results/'numbers.tex').write_text(''.join('\\newcommand{\\'+key+'}{'+str(value)+'}\n' for key,value in macros.items()))
    titles = {'arity_parameters/checker.py':'Arity parameters, demand',
              'arity_parameters/checker_strict.py':'Arity parameters, strict',
              'combined/checker.py':'Combined', 'fresh_arity/checker.py':'Fresh arity',
              'integrated/checker.py':'Integrated', 'integrated_1/checker.py':'Integrated (1)',
              'integrated_1/checker_separate.py':'Integrated (1), separate',
              'scope/checker.py':'Scope, open', 'scope/checker_strict.py':'Scope, strict',
              'scope/checker_closed.py':'Scope, closed'}
    table = ['\\begin{tabular}{@{}lrrr@{}}','\\toprule','Complete program & Tokens & AST & Bytes\\\\','\\midrule']
    for row in rows:
        table.append(titles[row['label']]+' & '+' & '.join(str(row[key]) for key in KEYS)+r'\\')
    table += ['\\midrule','Current coordinatewise minimum & '+' & '.join(str(envelope[key]) for key in KEYS)+r'\\','\\midrule']
    for name,title in [('declared_closed','New: declared, closed'),('scanned_open','New: scanned, open'),('context_closed','New: context, closed'),('context_open','New: context, open')]:
        table.append(r'\textbf{'+title+'} & '+' & '.join(r'\textbf{'+str(candidates[name][key])+'}' for key in KEYS)+r'\\')
    table += ['\\bottomrule','\\end{tabular}']
    (results/'comparison_table.tex').write_text('\n'.join(table)+'\n')
    abtable=['\\begin{tabular}{@{}lrrr@{}}','\\toprule','Complete program / ablation & Tokens & AST & Bytes\\\\','\\midrule']
    for name,title in [('declared_closed','Declared, closed'),('scanned_open','Scanned, open'),('context_open','Context, open')]:
        m=candidates[name]
        abtable.append(title+' & '+' & '.join(str(m[key]) for key in KEYS)+r'\\')
        for change,desc in [('ordinary_coordinates','ordinary coordinates'),('exception_only','except Exception')]:
            row=next(r for r in ablations if r['label']==name+'/'+change)
            abtable.append(r'\quad '+desc+' & '+' & '.join(str(row[key]) for key in KEYS)+r'\\')
    abtable += ['\\bottomrule','\\end{tabular}']
    (results/'ablation_table.tex').write_text('\n'.join(abtable)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('programs','ablations')}, indent=2))


if __name__ == '__main__':
    main()
