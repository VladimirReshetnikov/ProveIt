"""Re-run source measurements and all packaged finite implementation evidence."""
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent


def main():
    jobs=[('measure.py',[]),('validation/run.py',[]),('validation/validate_globals.py',[]),
          ('validation/independent_context_audit.py', ['--checker', str(ROOT/'checker.py'),
                                                     '--output', str(ROOT/'validation/independent_context')])]
    for name, arguments in jobs:
        path=ROOT/name
        if not path.is_file():
            raise SystemExit('Missing packaged reproduction step: '+name)
        run=subprocess.run([sys.executable,str(path),*arguments],cwd=ROOT,capture_output=True,text=True)
        if run.returncode:
            print(run.stdout[-5000:])
            print(run.stderr[-5000:])
            raise SystemExit(run.returncode)
        print(name+': PASS')
    if '--pdf' in sys.argv:
        subprocess.run([sys.executable,str(ROOT/'build.py')],cwd=ROOT,check=True)


if __name__=='__main__':
    main()
