#!/usr/bin/env python3
"""Measure the current eleven iPRA draft archives without executing their code.

Usage:
  python3 compare_current.py --archives reference_archives \
      --manifest reference_manifest.json --output current_baseline_metrics.json

Inputs are the original ZIP bytes. Every ZIP's Git blob SHA-1 is verified
against the pinned repository listing. Selected complete acceptance programs
include their JSON drivers and all imported local helpers. Whole source files
are charged, without inlining, code golfing, renaming, or dead-code removal.
Python, the standard library, proof builders, tests, and this measurement
program are excluded equally. Normalized metrics strip only Python docstrings
(the initial string expression of a module, function, or class), apply
ast.unparse, and count the resulting text/tokens/tree. This makes the exact
normalization convention explicit; it is not a universal size lower bound.
"""

import argparse
import ast
import hashlib
import io
import json
import platform
from pathlib import Path, PurePosixPath
import sys
import tokenize
import zipfile


# Each file path is relative to the one top-level package in its ZIP.
# The first eleven entries select the presentation recommended by that
# archive. The positive certificate alternative is separately labelled.
PRINCIPAL = [
    ("arithmetic_logic", "ipra_arithmetic_logic_kernel_2026-11-06.zip",
     "Full ordinary logic, arithmetic bridge",
     ["kernel.py", "check_json.py"], "genuine_falsity", "check_json.py"),
    ("block_matrix", "ipra_block_kernel_2026-11-03.zip",
     "Finite P/D matrices", ["code/matrix_checker.py"],
     "genuine_falsity", "code/matrix_checker.py"),
    ("case_schema", "ipra_case_elimination_2026-11-06.zip",
     "Numerical case elimination, schema presentation",
     ["kernel_work/candidate_schema.py"], "genuine_falsity",
     "kernel_work/candidate_schema.py"),
    ("fused_k", "ipra_kernel_2026-11-06.zip",
     "Fused Pi/Sigma K, open ambient variables", ["code/checker.py"],
     "genuine_falsity", "code/checker.py"),
    ("native_hilbert_positive", "ipra_small_checker_2026-11-03 (1).zip",
     "Native Hilbert, designated arithmetic contradiction",
     ["native/checker.py"], "positive_encoding_of_genuine_falsity_realization",
     "native/checker.py"),
    ("scoped_pi_sigma", "ipra_small_checker_2026-11-03.zip",
     "Pi/Sigma with explicit ambient arity", ["checker.py"],
     "genuine_falsity", "checker.py"),
    ("finite_rows", "ipra_small_kernel_2026-11-03(1).zip",
     "Universal implication and existential choice rows",
     ["rows_common.py", "rows_kernel.py"], "genuine_falsity", "rows_kernel.py"),
    ("frozen_hilbert_genuine", "ipra_small_kernel_2026-11-03.zip",
     "Frozen Hilbert H_bot, recommended ordinary theory",
     ["artifacts/kernel_genuine.py", "artifacts/check_json.py"],
     "genuine_falsity", "artifacts/check_json.py --kernel kernel_genuine"),
    ("frozen_hilbert_nov6", "ipra_small_kernel_2026-11-06 (2).zip",
     "Frozen Hilbert, genuine falsity",
     ["code/syntax.py", "code/arithmetic.py", "code/hilbert.py", "code/check.py"],
     "genuine_falsity", "code/check.py"),
    ("ordinary_nd_bridge", "ipra_small_kernel_2026-11-06.zip",
     "Ordinary natural deduction, two bridge implications",
     ["kernel.py", "check_certificate.py"], "genuine_falsity", "check_certificate.py"),
    ("two_binders", "ipra_two_binders_2026-11-06.zip",
     "Two logical binders, shared checking layer",
     ["code/shared.py", "code/check.py"], "genuine_falsity", "code/check.py"),
]

# Complete standalone comparators actually supplied inside the strongest
# archive can improve individual metrics over its advertised recommendation.
# Count them rather than silently equating 'recommended' with 'smallest'.
K_COMPARATORS = [
    "previous_k.py", "previous_k_open.py", "previous_k_open_pattern.py",
    "nd_nat_bridge_open.py", "nd_nat_open.py", "nd_nat_reduced_open.py",
    "nd_sc_open.py", "nd_sc_original.py", "nd_sc_reduced_open.py",
    "nd_sc_reduced_original.py",
]

SUPPLEMENTARY = [
    ("k_comparator_" + name[:-3], "ipra_kernel_2026-11-06.zip",
     "Supplied K comparison: " + name,
     ["comparisons/" + name], "genuine_falsity", "comparisons/" + name)
    for name in K_COMPARATORS
] + [
    ("frozen_hilbert_positive", "ipra_small_kernel_2026-11-03.zip",
     "Frozen Hilbert H_plus, smaller positive certificate alternative",
     ["artifacts/kernel.py", "artifacts/check_json.py"],
     "positive_encoding_of_genuine_falsity_realization",
     "artifacts/check_json.py --kernel kernel"),
]

METRICS = (
    "raw_utf8_bytes", "normalized_utf8_bytes", "normalized_python_tokens",
    "ast_nodes_without_docstrings", "raw_physical_lines", "normalized_physical_lines",
)


class RemoveDocstrings(ast.NodeTransformer):
    def visit_Module(self, node):
        return self.clean(node)

    def visit_FunctionDef(self, node):
        return self.clean(node)

    def visit_AsyncFunctionDef(self, node):
        return self.clean(node)

    def visit_ClassDef(self, node):
        return self.clean(node)

    def clean(self, node):
        if node.body and isinstance(node.body[0], ast.Expr):
            value = node.body[0].value
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                node.body.pop(0)
        return self.generic_visit(node)


def source_metrics(data):
    source = data.decode("utf-8")
    tree = RemoveDocstrings().visit(ast.parse(source))
    normalized = ast.unparse(tree) + "\n"
    ignored = {
        tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
        tokenize.NEWLINE, tokenize.NL, tokenize.INDENT, tokenize.DEDENT,
    }
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
              if t.type not in ignored]
    return {
        "sha256": hashlib.sha256(data).hexdigest(),
        "raw_utf8_bytes": len(data),
        "normalized_utf8_bytes": len(normalized.encode("utf-8")),
        "normalized_python_tokens": len(tokens),
        "ast_nodes_without_docstrings": len(list(ast.walk(tree))),
        "raw_physical_lines": len(source.splitlines()),
        "normalized_physical_lines": len(normalized.splitlines()),
    }


def imports_of(data):
    tree = ast.parse(data.decode("utf-8"))
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                raise ValueError("Relative imports need an explicit audit")
            imports.append(node.module)
    return sorted(set(imports))


def load_archives(directory, manifest):
    loaded = {}
    for item in manifest["drafts"]:
        path = directory / item["name"]
        data = path.read_bytes()
        git_sha = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if git_sha != item["sha"] or len(data) != item["size"]:
            raise ValueError("Archive differs from pinned repository object: " + str(path))
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            contents = {name: archive.read(name) for name in archive.namelist()
                        if name.endswith(".py")}
        roots = {name.split("/", 1)[0] for name in contents}
        if len(roots) != 1:
            raise ValueError("Expected one source package root in " + str(path))
        loaded[item["name"]] = {
            "manifest": item,
            "archive_sha256": hashlib.sha256(data).hexdigest(),
            "root": next(iter(roots)),
            "contents": contents,
        }
    return loaded


def measure_variant(spec, principal, loaded, head):
    identifier, archive_name, label, files, falsity, command = spec
    archive = loaded[archive_name]
    prefix = archive["root"] + "/"
    selected = {prefix + name for name in files}
    measured = []
    for name in files:
        entry = prefix + name
        data = archive["contents"][entry]
        imported = imports_of(data)
        local = []
        standard = []
        for module in imported:
            candidate = str(PurePosixPath(entry).parent / (module.replace(".", "/") + ".py"))
            if candidate in archive["contents"]:
                if candidate not in selected:
                    raise ValueError("Uncounted local helper: " + candidate + " in " + identifier)
                local.append(candidate)
            elif module.split(".", 1)[0] in sys.stdlib_module_names:
                standard.append(module)
            else:
                raise ValueError("Unclassified import " + module + " in " + entry)
        measured.append({
            "archive_entry": entry,
            "package_relative_path": name,
            "local_imports_counted": local,
            "standard_library_imports": standard,
            **source_metrics(data),
        })
    total = {key: sum(file[key] for file in measured) for key in METRICS}
    dynamic = None
    if "artifacts/check_json.py" in files:
        dynamic = (
            "The complete generic adapter is counted. The selected --kernel argument "
            "is fixed by the listed invocation; its selected kernel module is counted. "
            "Other unselected implementations are not acceptance dependencies."
        )
    item = archive["manifest"]
    return {
        "id": identifier,
        "principal_recommendation": principal,
        "label": label,
        "archive": archive_name,
        "repository_path": item["path"],
        "pinned_commit": head,
        "archive_git_blob_sha1": item["sha"],
        "archive_sha256": archive["archive_sha256"],
        "archive_bytes": item["size"],
        "falsity_status": falsity,
        "entry_point": command,
        "dynamic_import_audit": dynamic,
        "trusted_files": measured,
        "totals": total,
    }


def minima(variants):
    result = {}
    for key in METRICS:
        value = min(v["totals"][key] for v in variants)
        result[key] = {
            "value": value,
            "variants": [v["id"] for v in variants if v["totals"][key] == value],
        }
    return result


def pareto_frontier(variants):
    axes = METRICS[:4]
    return [a["id"] for a in variants if not any(
        all(b["totals"][key] <= a["totals"][key] for key in axes)
        and any(b["totals"][key] < a["totals"][key] for key in axes)
        for b in variants)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives", type=Path, default=Path("reference_archives"))
    parser.add_argument("--manifest", type=Path, default=Path("reference_manifest.json"))
    parser.add_argument("--output", type=Path, default=Path("current_baseline_metrics.json"))
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    if {s[1] for s in PRINCIPAL} != {d["name"] for d in manifest["drafts"]}:
        raise ValueError("Principal comparison does not cover exactly the manifest's archives")
    loaded = load_archives(args.archives, manifest)
    variants = [measure_variant(s, True, loaded, manifest["head"]) for s in PRINCIPAL]
    variants += [measure_variant(s, False, loaded, manifest["head"]) for s in SUPPLEMENTARY]
    principal = [v for v in variants if v["principal_recommendation"]]
    result = {
        "repository": "VladimirReshetnikov/ProveIt",
        "pinned_commit": manifest["head"],
        "python_version": platform.python_version(),
        "normalization": (
            "Read original ZIP entry UTF-8 bytes. Strip only the initial string "
            "expression of each module, function, async function, and class. Use "
            "ast.unparse plus one trailing newline separately for each complete "
            "trusted source file. Exclude whitespace/layout, comments, and end markers "
            "from tokens. Count every remaining ast.walk node. Sum each full file once. "
            "Do not rename identifiers, inline imports, prune unused code, or remove fixed axiom data."
        ),
        "trusted_boundary": (
            "All syntax checks, substitutions, inference checks, fixed axiom data, "
            "local imported helpers, and JSON entry points are included. Python and "
            "its standard library are the same excluded runtime. Proof producers, "
            "tests, reports, and this measurement program are outside acceptance."
        ),
        "scope": (
            "All eleven principal archive recommendations; also ten supplied standalone "
            "K comparators, and the frozen H_plus alternative. This is not a search "
            "over all possible checkers. The raw positive presentations are marked "
            "as encodings of their genuine-falsity realizations, not silently assigned "
            "ordinary model-theoretic bi-interpretability."
        ),
        "no_source_executed": True,
        "archive_hashes_verified": True,
        "principal_archive_count": len(principal),
        "measured_variant_count": len(variants),
        "variants": variants,
        "principal_minima": minima(principal),
        "all_measured_minima": minima(variants),
        "principal_pareto_frontier": pareto_frontier(principal),
        "all_measured_pareto_frontier": pareto_frontier(variants),
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    for v in principal:
        t = v["totals"]
        print(f'{v["id"]:29} {t["raw_utf8_bytes"]:6} {t["normalized_utf8_bytes"]:6}'
              f' {t["normalized_python_tokens"]:5} {t["ast_nodes_without_docstrings"]:5}')
    print("All-measured frontier:", ", ".join(result["all_measured_pareto_frontier"]))
    print(json.dumps(result["all_measured_minima"], indent=2))
    print("Wrote", args.output)


if __name__ == "__main__":
    main()
