A SMALL CHECKER FOR iPRA
Inferring existential conclusions from a witness equation
6 November 2026
========================================================

RESULT

The main proposal is calculus W, specified completely in report.pdf and
AXIOMS.txt. Its ordinary first-order realization is bi-interpretable with
full first-order intuitionistic primitive recursive arithmetic, with all
fixed finite primitive recursive descriptions and quantifier-free induction.
The interpretations use the whole number domain and internally identify
both composites with the identity. Genuine falsity is retained through the
EXPLICIT nonlogical conversion bottom == (0=S0).

The principal new rule is existential introduction from a fresh witness
equation:

    Gamma, y=t |- A(y)      Gamma, y=t |- B(y)
    ------------------------------------------------
                 Gamma |- Sigma_y(A(y), B(y)).

y is fresh for Gamma and t. Both uses of the equation are discharged.
The checker infers A and B from the branch proofs. This removes the old
principal-formula annotation and the two witness-instance comparisons.
Both directions of admissibility are proved in the report. Certificate
construction can become longer; the requested objective is checker size.

FINAL MEASURED CHECKER

    code/checker.py: 3,817 raw UTF-8 bytes
                    3,486 normalized executable bytes
                    1,125 normalized significant Python tokens
                    1,203 AST nodes after docstring removal

The coordinate minima of the 22 measured supplied baseline variants are
4,170 / 3,806 / 1,167 / 1,248, respectively. Those minima come from two
different supplied programs, not one fictitious combined checker. The new
candidate is smaller in every coordinate. The 3,486-byte normalized count
is 8.41% below the supplied minimum; token and AST reductions are 3.60% and
3.61%. The archive does not claim an encoding-independent global minimum.

The new Sigma rule alone also beats the previous four-coordinate frontier
when applied to its open-scope comparator, retaining genuine falsity and
the original explicit bridge: 4,118 raw bytes, 3,754 normalized bytes,
1,154 tokens, and 1,223 AST nodes. Matched controls isolate this change.
The same final calculus with the original pattern validator has a different
tradeoff: 3,640 normalized bytes, 1,122 tokens, and 1,201 AST nodes. The
table-based main implementation minimizes normalized bytes, while that
included alternative minimizes tokens and AST nodes among these variants.

SOURCE SNAPSHOT

Repository: VladimirReshetnikov/ProveIt
Directory: docs/drafts
Commit: b079e5787b1d708049ff0643ce1b534c1a225198

All eleven current archive recommendations and eleven additional supplied
variants are represented. Original ZIP bytes were verified against Git
blob hashes. The exact selected trusted source entries and their hashes
are included for offline remeasurement. The candidate is an attributed
adaptation of the pinned ipra_kernel_2026-11-06/code/checker.py.

FILES

report.tex, sections/*.tex, report.pdf
    Complete mathematical specification, proofs, comparison, further
    research questions, and a full listing of the trusted checker.
AXIOMS.txt
    Compact but exhaustive calculus specification.
code/checker.py
    Entire trusted acceptance program, including the JSON input boundary.
code/translate_baseline.py
    Untrusted general translation from the pinned K proof format.
code/test_translation.py
    Translation tests and reproduction of the translated certificates.
code/measure.py
    Offline full-source size measurements and hash/import audits.
code/checker_conversion.py, code/controls/
    Matched implementation controls; see validation/metrics.json.
certificates/example_witness.json
    Small direct example of the new witness-equation rule.
certificates/translated/
    Translated original baseline certificates.
provenance/
    Pinned baseline, original certificates, full comparison metadata,
    exact source extracts, optional original-ZIP verification script.
validation/
    Machine-readable results and independent executable/mathematical audits.
build.py
    Reproduce tests, metrics, and the PDF; requires Python and TeX.

RUN

From the extracted archive directory, with Python 3.10 or later:

    python3 code/checker.py certificates/example_witness.json
    python3 code/test_translation.py
    python3 validation/independent_audit.py
    python3 code/measure.py
    python3 build.py

The last command also builds report.pdf, using pdflatex and the packages
listed in report.tex. Exact normalized-source counts use the Python version
recorded in validation/metrics.json; ast.unparse can vary across versions.

To translate an arbitrary valid certificate in the pinned baseline format:

    python3 code/translate_baseline.py INPUT.json OUTPUT.json
    python3 code/checker.py OUTPUT.json

The translator validates the input before any erasure and validates the
output afterward. Neither the translator nor any test/measurement program
is imported by code/checker.py.

VALIDATION AND LIMITS

165 positive translation checks: 53 original certificates, 106 systematic
nested-witness variants, and six fresh dependent examples. Four negative
translation checks also pass. The independent suite has 38 checks (15
accepts, 23 rejects), plus four CLI checks including Python -O.

These are finite executable regression checks. Soundness, full sequent
equivalence, recursion coherence, and bi-interpretability are established
by written mathematical proofs in the report, not by a claimed Lean/Rocq
formalization. All input canonicalization is counted as trusted code.

No primitive excluded middle, unrestricted induction, arithmetic evaluator,
or semantic equality test for primitive recursive programs is present.
