#!/usr/bin/env python3
"""Reproduce the finite checks, complete-source measurements, and PDF."""
from pathlib import Path
import json
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
logs = root / "validation" / "build_logs"
logs.mkdir(parents=True, exist_ok=True)
steps = [
    ("translation", [sys.executable, "code/test_translation.py"]),
    ("independent_audit", [sys.executable, "validation/independent_audit.py"]),
    ("metrics", [sys.executable, "code/measure.py"]),
    ("example", [sys.executable, "code/checker.py", "certificates/example_witness.json"]),
]
if not shutil.which("pdflatex"):
    raise SystemExit("pdflatex is required to reproduce the compiled report")
for number in range(1, 4):
    steps.append((f"latex_{number}", ["pdflatex", "-interaction=nonstopmode",
                                     "-halt-on-error", "report.tex"]))
results = []
for name, command in steps:
    run = subprocess.run(command, cwd=root, text=True, stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT)
    (logs / (name + ".txt")).write_text(run.stdout)
    results.append({"step": name, "exit_code": run.returncode})
    print(name, "PASS" if run.returncode == 0 else "FAIL")
    if run.returncode:
        print(run.stdout)
        raise SystemExit(run.returncode)
(root / "validation" / "build_results.json").write_text(
    json.dumps({"status": "PASS", "steps": results}, indent=2) + "\n")
