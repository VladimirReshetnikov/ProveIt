"""Independent focused audit of conversion and witness-equation introduction.

These hand-written certificates target scope capture, malformed numerical
witnesses, illicit induction hypotheses, and the exact conversion relation.
They do not use the baseline translator or infer their expected results from
the tested implementation. This is regression evidence, not a formal proof
of the checker's universal soundness or the interpretation metatheorems.
"""

from pathlib import Path
import importlib.util
import json
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("independently_audited_kernel", ROOT / "code/checker.py")
KERNEL = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(KERNEL)

Z = ["z"]
F = ["false"]
T = ["=", Z, Z]
D = ["=", Z, ["s", Z]]


def s(t):
    return ["s", t]


def eq(a, b):
    return ["=", a, b]


def pi(a, b):
    return ["pi", a, b]


def sig(a, b):
    return ["sig", a, b]


def hyp(i):
    return ["hyp", i]


def document(g, a, p):
    return {"assumptions": g, "goal": a, "proof": p}


def cases():
    """Each tuple is (name, expected acceptance, raw JSON document)."""
    yield "delta_to_genuine_bottom", True, document([D], F, hyp(0))
    yield "genuine_bottom_to_delta", True, document([F], D, hyp(0))
    yield "negative_pi_conversion", True, document([pi(F, T)], pi(D, T), hyp(0))
    yield "positive_pi_conversion", True, document([pi(T, F)], pi(T, D), hyp(0))
    yield "both_sigma_children_conversion", True, document([sig(F, F)], sig(D, D), hyp(0))
    yield "nested_conversion", True, document([pi(sig(F, T), pi(T, F))], pi(sig(D, T), pi(T, D)), hyp(0))
    yield "raw_bottom_proof_annotation", True, document([], pi(F, F), ["pi", F, hyp(0)])
    yield "bottom_constant_induction", True, document([F], F, ["nat", F, Z, hyp(0), hyp(1)])
    yield "wrong_bottom_induction_base", False, document([T], F, ["nat", F, Z, hyp(0), hyp(1)])
    yield "no_unproved_bottom", False, document([], F, hyp(0))
    yield "reflexive_equation_is_not_bottom", False, document([T], F, hyp(0))
    yield "reversed_clash_needs_symmetry", False, document([eq(s(Z), Z)], F, hyp(0))
    yield "unknown_false_spelling", False, document([D], ["False"], hyp(0))
    yield "malformed_false_arity", False, document([D], ["false", Z], hyp(0))
    yield "formula_is_not_a_proof_tag", False, document([], F, F)

    # The witness is S(x), with x the outer free slot 0. The new bound
    # variable y is slot 0 inside Sigma, so the old x MUST become slot 1.
    pair_successor = ["pair", s(0), hyp(0), hyp(0)]
    good_guard = eq(0, s(1))
    bad_guard = eq(0, s(0))
    yield "fresh_witness_successor", True, document([], sig(good_guard, good_guard), pair_successor)
    yield "reject_self_successor_capture", False, document([], sig(bad_guard, bad_guard), pair_successor)
    yield "zero_witness_guard", True, document([], sig(eq(0, Z), eq(0, Z)), ["pair", Z, hyp(0), hyp(0)])
    yield "forged_witness_equation", False, document([], sig(eq(0, s(Z)), eq(0, s(Z))), ["pair", Z, hyp(0), hyp(0)])

    # Retain x=0 while constructing y=S(x). A missing context shift would
    # let the first branch assert y=0, producing a false existential.
    parameter_pair = ["pair", s(0), hyp(0), hyp(1)]
    yield "retained_parameter_is_shifted", True, document([eq(0, Z)], sig(eq(1, Z), good_guard), parameter_pair)
    yield "reject_retained_parameter_capture", False, document([eq(0, Z)], sig(eq(0, Z), good_guard), parameter_pair)

    nested_pi = ["pair", s(0), ["pi", T, hyp(0)], hyp(0)]
    yield "nested_pi_in_witness_branch", True, document([], sig(pi(T, eq(1, s(2))), good_guard), nested_pi)
    yield "reject_nested_pi_capture", False, document([], sig(pi(T, eq(0, s(1))), good_guard), nested_pi)
    nested_sig = ["pair", s(0), ["pair", 0, hyp(0), hyp(1)], hyp(0)]
    yield "nested_sigma_in_witness_branch", True, document([], sig(sig(eq(1, s(2)), eq(0, 1)), good_guard), nested_sig)

    # A recursion body has two protected local slots, unlike Pi/Sigma's
    # one. Test both protected state and a free parameter in the body.
    state_witness = ["r", s(0), 0, s(0)]
    shifted_state = ["r", s(1), 1, s(0)]
    yield "native_recursion_state_protected", True, document([], sig(eq(0, shifted_state), eq(0, shifted_state)), ["pair", state_witness, hyp(0), hyp(0)])
    parameter_witness = ["r", Z, 0, 2]
    shifted_parameter = ["r", Z, 1, 3]
    yield "native_recursion_parameter_shifted", True, document([], sig(eq(0, shifted_parameter), eq(0, shifted_parameter)), ["pair", parameter_witness, hyp(0), hyp(0)])
    captured_parameter = ["r", Z, 1, 2]
    yield "reject_native_parameter_capture", False, document([], sig(eq(0, captured_parameter), eq(0, captured_parameter)), ["pair", parameter_witness, hyp(0), hyp(0)])

    zero_pair = ["pair", Z, hyp(0), hyp(0)]
    yield "sigma_witness_cannot_escape", False, document([], eq(0, Z), ["let", zero_pair, eq(0, Z), hyp(0)])
    for label, witness in [("formula", F), ("boolean", True), ("negative", -1), ("unknown_constructor", ["q"]), ("ill_typed_recursion", ["r", Z, Z, F])]:
        yield "reject_" + label + "_witness", False, document([], sig(T, T), ["pair", witness, hyp(0), hyp(0)])
    yield "reject_legacy_pair_shape", False, document([], sig(T, T), ["pair", sig(T, T), Z, hyp(0), hyp(0)])
    yield "bottom_is_not_a_number", False, document([T], eq(F, Z), hyp(0))
    yield "boolean_is_not_numerical_zero", False, document([eq(0, Z)], eq(False, Z), hyp(0))

    # A non-equational invariant receives NO induction assumption. The
    # base is a retained hypothesis; slot 1 would exist only if an illicit
    # additional induction hypothesis were appended to the step context.
    quantified = pi(T, F)
    yield "no_quantified_induction_hypothesis", False, document([quantified], quantified, ["nat", quantified, Z, hyp(0), hyp(1)])
    existential = sig(F, T)
    yield "no_existential_induction_hypothesis", False, document([existential], existential, ["nat", existential, Z, hyp(0), hyp(1)])


def accepted(data):
    # Round-trip to enforce the advertised JSON boundary, without permitting
    # Python objects that supply arbitrary custom equality behavior.
    raw = json.loads(json.dumps(data))
    try:
        return KERNEL.check(raw) is True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError):
        return False


def run():
    rows = []
    fixtures = list(cases())
    for name, expected, data in fixtures:
        actual = accepted(data)
        if actual != expected:
            raise RuntimeError(f"audit failure: {name}: expected {expected}, got {actual}")
        rows.append({"name": name, "expected": expected, "observed": actual})

    cli = []
    selected = [fixtures[0], next(c for c in fixtures if c[0] == "reject_self_successor_capture")]
    with tempfile.TemporaryDirectory(prefix="ipra-independent-audit-") as directory:
        for name, expected, data in selected:
            path = Path(directory) / (name + ".json")
            path.write_text(json.dumps(data), encoding="utf-8")
            for optimized in (False, True):
                cmd = [sys.executable, *(["-O"] if optimized else []), str(ROOT / "code/checker.py"), str(path)]
                result = subprocess.run(cmd, text=True, capture_output=True)
                expected_code = 0 if expected else 1
                if result.returncode != expected_code or result.stdout.strip() != ("ACCEPT" if expected else "REJECT"):
                    raise RuntimeError((name, optimized, result.returncode, result.stdout, result.stderr))
                cli.append({"name": name, "optimized": optimized, "exit_code": result.returncode, "output": result.stdout.strip()})

    report = {
        "accepted": sum(expected for _, expected, _ in fixtures),
        "rejected": sum(not expected for _, expected, _ in fixtures),
        "total": len(fixtures),
        "cli_checks": cli,
        "cases": rows,
        "scope": "Independent hand-written finite certificates; not a machine-checked universal soundness proof.",
    }
    (ROOT / "validation/independent_audit_results.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("accepted", "rejected", "total")}, indent=2))
    return report


if __name__ == "__main__":
    run()
