#!/usr/bin/env python3
"""Recompute complete-source checker comparisons, entirely offline.

Run from any directory:
    python3 path/to/code/measure.py

This program reads the exact supplied baseline sources under provenance,
checks their recorded SHA-256 hashes, audits local imports, and measures all
22 baseline implementations and the local matched comparison programs. It
does not execute any proof checker. Its outputs are validation/metrics.json
and metrics_table.tex, both beneath this package's root.
"""

import argparse
import ast
import hashlib
import io
import json
import platform
from pathlib import Path
import sys
import tokenize


METRICS = (
    "raw_utf8_bytes", "normalized_utf8_bytes", "normalized_python_tokens",
    "ast_nodes_without_docstrings", "raw_physical_lines", "normalized_physical_lines",
)
SIZE_AXES = METRICS[:4]

LOCAL_VARIANTS = (
    ("candidate", "Final candidate", "code/checker.py"),
    ("conversion_only", "Bottom conversion with the old Sigma introduction rule",
     "code/checker_conversion.py"),
    ("matched_baseline", "Verbatim supplied fused K", "provenance/baseline_checker.py"),
    ("sigma_only", "Supplied K with only the Sigma introduction branch replaced",
     "code/controls/checker_sigma_only.py"),
    ("sigma_only_frontier", "Smallest-byte supplied comparator with only Sigma replaced",
     "code/controls/checker_sigma_only_frontier.py"),
    ("conversion_sigma_oldfreeze", "Conversion plus new Sigma, original conversion spelling",
     "code/controls/checker_conversion_sigma_oldfreeze.py"),
    ("conversion_sigma", "Conversion plus new Sigma, final input conversion, original validation",
     "code/controls/checker_conversion_sigma.py"),
)

PRINCIPAL_LABELS = {
    "arithmetic_logic": "Arithmetic/logic bridge",
    "block_matrix": "P/D matrix blocks",
    "case_schema": "Numerical case schema",
    "fused_k": "Fused K",
    "native_hilbert_positive": "Native positive Hilbert",
    "scoped_pi_sigma": r"Scoped $\Pi/\Sigma$",
    "finite_rows": "Finite existential rows",
    "frozen_hilbert_genuine": "Frozen Hilbert, genuine falsity",
    "frozen_hilbert_nov6": "Hilbert, November 6 (2)",
    "ordinary_nd_bridge": "Ordinary deduction bridge",
    "two_binders": "Two logical binders",
}


class RemoveDocstrings(ast.NodeTransformer):
    def visit_Module(self, node):
        return self.clean(node)

    def visit_FunctionDef(self, node):
        return self.clean(node)

    def visit_AsyncFunctionDef(self, node):
        return self.clean(node)

    def visit_ClassDef(self, node):
        return self.clean(node)

    def clean(self, node):
        if node.body and isinstance(node.body[0], ast.Expr):
            value = node.body[0].value
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                node.body.pop(0)
        return self.generic_visit(node)


def source_metrics(data):
    source = data.decode("utf-8")
    tree = RemoveDocstrings().visit(ast.parse(source))
    normalized = ast.unparse(tree) + "\n"
    ignored = {
        tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
        tokenize.NEWLINE, tokenize.NL, tokenize.INDENT, tokenize.DEDENT,
    }
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
              if t.type not in ignored]
    return {
        "sha256": hashlib.sha256(data).hexdigest(),
        "raw_utf8_bytes": len(data),
        "normalized_utf8_bytes": len(normalized.encode("utf-8")),
        "normalized_python_tokens": len(tokens),
        "ast_nodes_without_docstrings": len(list(ast.walk(tree))),
        "raw_physical_lines": len(source.splitlines()),
        "normalized_physical_lines": len(normalized.splitlines()),
    }


def audited_imports(path, data, counted_paths, dynamic_allowed):
    tree = ast.parse(data.decode("utf-8"))
    modules = set()
    dynamic = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                raise ValueError("Relative import requires an explicit audit: " + str(path))
            modules.add(node.module)
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == "__import__":
                dynamic.append(node.lineno)
            if isinstance(node.func, ast.Attribute) and node.func.attr == "import_module":
                dynamic.append(node.lineno)
    if dynamic and not dynamic_allowed:
        raise ValueError("Unaudited dynamic import in " + str(path))
    local = []
    standard = []
    for module in sorted(modules):
        candidate = path.parent / (module.replace(".", "/") + ".py")
        if candidate.is_file():
            if candidate.resolve() not in counted_paths:
                raise ValueError("Uncounted imported checking helper: " + str(candidate))
            local.append(str(candidate))
        elif module.split(".", 1)[0] in sys.stdlib_module_names:
            standard.append(module)
        else:
            raise ValueError("Missing or unclassified imported helper " + module + " in " + str(path))
    return {"local_imports": local, "standard_library_imports": standard,
            "dynamic_import_call_lines": dynamic}


def safe_path(root, relative):
    path = root / relative
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError("Path escapes the package: " + relative)
    return path


def measure_files(root, records, dynamic_allowed=False, verify_hashes=True):
    counted = {safe_path(root, r["local_path"]).resolve() for r in records}
    if len(counted) != len(records):
        raise ValueError("A source file was counted twice in one implementation")
    result = []
    for record in records:
        path = safe_path(root, record["local_path"])
        data = path.read_bytes()
        metrics = source_metrics(data)
        if verify_hashes and metrics["sha256"] != record["sha256"]:
            raise ValueError("Baseline source hash mismatch: " + record["local_path"])
        imports = audited_imports(path, data, counted, dynamic_allowed)
        imports["local_imports"] = [str(Path(p).relative_to(root))
                                    for p in imports["local_imports"]]
        result.append({
            "local_path": record["local_path"],
            "archive_entry": record.get("archive_entry"),
            **metrics, **imports,
        })
    return result, {key: sum(r[key] for r in result) for key in METRICS}


def minima(variants):
    result = {}
    for key in METRICS:
        value = min(v["totals"][key] for v in variants)
        result[key] = {"value": value,
                       "variants": [v["id"] for v in variants if v["totals"][key] == value]}
    return result


def pareto_frontier(variants):
    return [a["id"] for a in variants if not any(
        all(b["totals"][key] <= a["totals"][key] for key in SIZE_AXES)
        and any(b["totals"][key] < a["totals"][key] for key in SIZE_AXES)
        for b in variants)]


def difference(before, after):
    return {key: {
        "before": before[key], "after": after[key],
        "absolute_saving": before[key] - after[key],
        "saving_percent": round(100 * (before[key] - after[key]) / before[key], 6),
    } for key in SIZE_AXES}


def verify_controls(root):
    """Require the controls to differ by exactly the stated source edits."""
    def read(path):
        return (root / path).read_text()

    def block(source, start, stop):
        begin = source.index(start)
        end = source.index(stop, begin)
        return source[begin:end]

    def pair(source):
        return block(source, '        case ("pair",', '        case ("let",')

    def freeze(source):
        return block(source, 'def freeze(a):', '\n\ndef check(data):')

    def validation(source):
        start = '\n\nARITIES =' if '\n\nARITIES =' in source else '\n\ndef wf('
        return block(source, start, '\n\ndef walk(')

    baseline = read("provenance/baseline_checker.py")
    conversion = read("code/checker_conversion.py")
    final = read("code/checker.py")
    frontier = read("provenance/baselines/k_comparator_previous_k_open_pattern/"
                    "comparisons/previous_k_open_pattern.py")
    old_pair, new_pair = pair(baseline), pair(final)
    if pair(conversion) != old_pair or pair(frontier) != old_pair:
        raise ValueError("Old Sigma branch changed; regenerate and audit matched controls")
    expected = {
        "checker_sigma_only.py": baseline.replace(old_pair, new_pair, 1),
        "checker_sigma_only_frontier.py": frontier.replace(old_pair, new_pair, 1),
        "checker_conversion_sigma_oldfreeze.py": conversion.replace(old_pair, new_pair, 1),
    }
    expected["checker_conversion_sigma.py"] = expected["checker_conversion_sigma_oldfreeze.py"].replace(
        freeze(conversion), freeze(final), 1)
    for name, content in expected.items():
        if read("code/controls/" + name) != content:
            raise ValueError("Control is not the stated exact edit: " + name)
    no_table = expected["checker_conversion_sigma.py"]
    rebuilt_final = no_table.replace(validation(no_table), validation(final), 1).replace(
        '1 if a[0] in ("pi", "sig") else 0', '1 if a[0] in BINDERS else 0', 1)
    if rebuilt_final != final:
        raise ValueError("Final checker differs by more than table validation and the shared binder constant")
    return {
        "sigma_only": "Exact original K source with only its pair branch replaced; bottom and bridge retained.",
        "sigma_only_frontier": "Exact supplied open-pattern comparator with only its pair branch replaced.",
        "conversion_sigma_oldfreeze": "Exact conversion-only source with only its pair branch replaced.",
        "conversion_sigma": "Previous control with only freeze changed to the final if-list spelling.",
        "candidate": "Previous control with validation tables/wf and the shared BINDERS reference only.",
        "all_exact_source_edit_checks_passed": True,
    }


def latex_row(label, totals):
    return label + " & " + " & ".join(f"{totals[key]:,}" for key in SIZE_AXES) + r" \\"


def write_latex(path, result):
    local = {v["id"]: v for v in result["local_variants"]}
    minima_values = {key: result["all_baseline_minima"][key]["value"] for key in METRICS}
    strongest = next(v for v in result["baselines"]
                     if v["id"] == "k_comparator_previous_k_open_pattern")
    macros = []
    suffixes = {"raw_utf8_bytes": "RawBytes", "normalized_utf8_bytes": "NormalizedBytes",
                "normalized_python_tokens": "Tokens", "ast_nodes_without_docstrings": "ASTNodes"}
    for name, data in [("Candidate", local["candidate"]["totals"]),
                       ("Conversion", local["conversion_only"]["totals"]),
                       ("SigmaOnly", local["sigma_only"]["totals"]),
                       ("SigmaFrontier", local["sigma_only_frontier"]["totals"]),
                       ("NoTable", local["conversion_sigma"]["totals"]),
                       ("MatchedBaseline", local["matched_baseline"]["totals"]),
                       ("BaselineMin", minima_values)]:
        for key, suffix in suffixes.items():
            macros.append(r"\providecommand{\Metric" + name + suffix + "}{" + str(data[key]) + "}")
    for key, suffix in suffixes.items():
        saving = result["comparisons"]["coordinate_minima_to_candidate"][key]
        macros.append(r"\providecommand{\Metric" + suffix + "SavingFromMin}{"
                      + str(saving["absolute_saving"]) + "}")
        macros.append(r"\providecommand{\Metric" + suffix + "SavingPercent}{"
                      + f'{saving["saving_percent"]:.2f}' + "}")
    lines = [
        "% Generated by code/measure.py; do not edit numerical entries by hand.",
        "% Requires the booktabs package. All values include full JSON interfaces.",
        *macros, "",
        r"\begin{table}[htbp]", r"\centering", r"\small",
        r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
        r"Implementation & Source bytes & Norm. bytes & Tokens & AST \\",
        r"\midrule",
        latex_row("Supplied fused K", local["matched_baseline"]["totals"]),
        latex_row("Supplied open-scope comparator", strongest["totals"]),
        latex_row("Coordinate minima of supplied code", minima_values),
        r"\midrule",
        latex_row(r"K with only new $\Sigma I$", local["sigma_only"]["totals"]),
        latex_row(r"Open comparator with only new $\Sigma I$", local["sigma_only_frontier"]["totals"]),
        r"\midrule",
        latex_row(r"Conversion only, original $\Sigma I$", local["conversion_only"]["totals"]),
        latex_row(r"As above, new $\Sigma I$ only", local["conversion_sigma_oldfreeze"]["totals"]),
        latex_row(r"As above, final input conversion", local["conversion_sigma"]["totals"]),
        latex_row(r"Final candidate: table validation", local["candidate"]["totals"]),
        r"\bottomrule", r"\end{tabular}",
        r"\caption{Complete checking programs under one normalization. The coordinate-minimum row",
        r"takes each column's minimum over the 22 supplied implementations; it does not describe",
        r"a single program. The matched controls separate the new rule, the input-conversion spelling,",
        r"and the table-based validation refactor. Both Sigma-only controls retain genuine falsity",
        r"and their original bridge.}",
        r"\label{tab:checker-frontier}", r"\end{table}", "",
        r"\begin{table}[htbp]", r"\centering", r"\small",
        r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
        r"Principal archive recommendation & Source bytes & Norm. bytes & Tokens & AST \\",
        r"\midrule",
    ]
    for variant in result["baselines"]:
        if variant["principal_recommendation"]:
            lines.append(latex_row(PRINCIPAL_LABELS[variant["id"]], variant["totals"]))
    lines += [
        r"\bottomrule", r"\end{tabular}",
        r"\caption{All eleven current principal recommendations at the pinned repository commit.",
        r"Shared checking modules and command-line JSON drivers are included in every row.",
        r"The native positive Hilbert row checks an encoding of its genuine-falsity realization;",
        r"the raw positive theory is not assigned ordinary model-theoretic bi-interpretability.}",
        r"\label{tab:eleven-drafts}", r"\end{table}", "",
    ]
    path.write_text("\n".join(lines))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.root.resolve()
    index_path = root / "provenance/baselines_manifest.json"
    index = json.loads(index_path.read_text())
    snapshot = json.loads((root / "provenance/current_baseline_metrics.json").read_text())
    if index["pinned_commit"] != snapshot["pinned_commit"]:
        raise ValueError("Baseline provenance commits disagree")
    snapshot_by_id = {v["id"]: v for v in snapshot["variants"]}
    if set(snapshot_by_id) != {v["id"] for v in index["variants"]}:
        raise ValueError("Included variants differ from the complete source snapshot")
    baselines = []
    for variant in index["variants"]:
        original = snapshot_by_id[variant["id"]]
        expected = {(r["archive_entry"], r["sha256"]) for r in original["trusted_files"]}
        present = {(r["archive_entry"], r["sha256"]) for r in variant["trusted_files"]}
        if expected != present:
            raise ValueError("Baseline file selection changed: " + variant["id"])
        files, totals = measure_files(root, variant["trusted_files"],
                                      dynamic_allowed=bool(variant["dynamic_import_audit"]))
        baselines.append({
            **{k: variant[k] for k in [
                "id", "label", "principal_recommendation", "archive", "repository_path",
                "pinned_commit", "archive_git_blob_sha1", "archive_sha256", "falsity_status",
                "entry_point", "dynamic_import_audit",
            ]},
            "trusted_files": files, "totals": totals,
        })
    principal = [v for v in baselines if v["principal_recommendation"]]
    if len(principal) != 11 or len(baselines) != 22:
        raise ValueError("Expected all eleven recommendations and 22 complete variants")
    local = []
    for identifier, label, path in LOCAL_VARIANTS:
        files, totals = measure_files(root, [{"local_path": path}], verify_hashes=False)
        local.append({"id": identifier, "label": label, "trusted_files": files, "totals": totals})
    local_by_id = {v["id"]: v for v in local}
    supplied_k = next(v for v in baselines if v["id"] == "fused_k")
    if local_by_id["matched_baseline"]["trusted_files"][0]["sha256"] != supplied_k["trusted_files"][0]["sha256"]:
        raise ValueError("The matched K baseline is not the exact supplied source")
    source_edits = verify_controls(root)
    current_minima = minima(baselines)
    min_totals = {key: current_minima[key]["value"] for key in METRICS}
    cand = local_by_id["candidate"]["totals"]
    conversion = local_by_id["conversion_only"]["totals"]
    matched = local_by_id["matched_baseline"]["totals"]
    sigma_only = local_by_id["sigma_only"]["totals"]
    sigma_frontier = local_by_id["sigma_only_frontier"]["totals"]
    conversion_sigma_oldfreeze = local_by_id["conversion_sigma_oldfreeze"]["totals"]
    conversion_sigma = local_by_id["conversion_sigma"]["totals"]
    strongest = next(v for v in baselines if v["id"] == "k_comparator_previous_k_open_pattern")["totals"]
    decomposition = {
        "exact_source_edit_verification": source_edits,
        "sigma_rule_only_in_supplied_K": difference(matched, sigma_only),
        "sigma_rule_only_in_open_comparator": difference(strongest, sigma_frontier),
        "bottom_conversion_initial": difference(matched, conversion),
        "sigma_rule_only_after_conversion": difference(conversion, conversion_sigma_oldfreeze),
        "freeze_spelling_only": difference(conversion_sigma_oldfreeze, conversion_sigma),
        "table_validation_and_binder_constant_only": difference(conversion_sigma, cand),
        "coordinate_minima_to_sigma_only_open_comparator": difference(min_totals, sigma_frontier),
        "qualification": (
            "The conversion-only to final-candidate transition contains three edits. "
            "Only the pair-branch controls isolate the Sigma rule. The final if-list freeze "
            "spelling and table-based validation are separate representation edits; savings "
            "may be negative when a metric increases. The final table variant can be shorter "
            "in normalized bytes while using more tokens or AST nodes than the no-table control."
        ),
    }
    chain = ["bottom_conversion_initial", "sigma_rule_only_after_conversion",
             "freeze_spelling_only", "table_validation_and_binder_constant_only"]
    decomposition["additive_chain"] = {
        "steps": chain,
        "sum_of_savings": {key: sum(decomposition[step][key]["absolute_saving"] for step in chain)
                           for key in SIZE_AXES},
        "matched_K_to_final_savings": {key: matched[key] - cand[key] for key in SIZE_AXES},
    }
    if decomposition["additive_chain"]["sum_of_savings"] != decomposition["additive_chain"]["matched_K_to_final_savings"]:
        raise ValueError("Controlled source-edit decomposition is not additive")
    snapshot_totals_match = all(v["totals"] == snapshot_by_id[v["id"]]["totals"] for v in baselines)
    if platform.python_version() == snapshot["python_version"] and not snapshot_totals_match:
        raise ValueError("Same Python version produced different baseline normalization")
    result = {
        "repository": index["repository"], "pinned_commit": index["pinned_commit"],
        "python_version": platform.python_version(),
        "normalization": snapshot["normalization"],
        "trusted_boundary": snapshot["trusted_boundary"],
        "scope": snapshot["scope"],
        "all_baseline_source_hashes_verified": True,
        "local_import_audit_passed": True,
        "matched_baseline_is_verbatim_supplied_K": True,
        "no_checker_code_executed": True,
        "source_snapshot_python_version": snapshot["python_version"],
        "baseline_totals_match_source_snapshot": snapshot_totals_match,
        "baseline_variants_count": len(baselines), "principal_archive_count": len(principal),
        "baselines": baselines, "local_variants": local,
        "principal_baseline_minima": minima(principal),
        "all_baseline_minima": current_minima,
        "baseline_pareto_frontier": pareto_frontier(baselines),
        "frontier_with_local_variants": pareto_frontier(baselines + [v for v in local if v["id"] != "matched_baseline"]),
        "controlled_decomposition": decomposition,
        "comparisons": {
            "matched_K_to_conversion_only": difference(matched, conversion),
            "conversion_only_to_candidate": difference(conversion, cand),
            "matched_K_to_candidate": difference(matched, cand),
            "coordinate_minima_to_candidate": difference(min_totals, cand),
        },
        "candidate_at_or_below_each_baseline_coordinate": {
            key: cand[key] <= min_totals[key] for key in SIZE_AXES},
        "candidate_strictly_below_each_baseline_coordinate": {
            key: cand[key] < min_totals[key] for key in SIZE_AXES},
        "sigma_only_open_comparator_strictly_below_each_baseline_coordinate": {
            key: sigma_frontier[key] < min_totals[key] for key in SIZE_AXES},
        "qualification": (
            "These are exact implementation-relative comparisons with the recorded supplied "
            "sources. They are not a proof of universal checker minimality, proof-length "
            "improvement, runtime improvement, or kernel soundness. The coordinate minima "
            "may come from different baseline programs."
        ),
    }
    validation = root / "validation"
    validation.mkdir(exist_ok=True)
    (validation / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    write_latex(root / "metrics_table.tex", result)
    print("Verified", len(baselines), "supplied complete implementations from", len(principal), "archives.")
    for variant in local:
        print(variant["id"], json.dumps({key: variant["totals"][key] for key in SIZE_AXES}))
    print("Baseline coordinate minima:", json.dumps({key: min_totals[key] for key in SIZE_AXES}))
    print("Candidate below each baseline coordinate:",
          all(result["candidate_strictly_below_each_baseline_coordinate"].values()))
    print("Wrote validation/metrics.json and metrics_table.tex")


if __name__ == "__main__":
    main()
