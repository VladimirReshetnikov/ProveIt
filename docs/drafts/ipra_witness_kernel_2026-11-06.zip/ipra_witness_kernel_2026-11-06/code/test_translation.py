"""Reproduce old-to-new translations and stress the witness binder.

All generated proofs are untrusted.  Both standalone kernels check every
successful translation.  The wrapper checks place every old regression
proof under one and two new Sigma witness binders, exercising numerical
lifting and relocation of local hypotheses throughout the proof grammar.
"""

from pathlib import Path
import json

import checker as new
import translate_baseline as tr


ROOT = Path(__file__).resolve().parents[1]
old = tr.old
Z = old.ZERO


def eq(s, t):
    return ("=", s, t)


def document(goal, proof, assumptions=()):
    result = {"assumptions": list(assumptions), "goal": goal, "proof": proof}
    old.check(result)
    return result


def wrap(source, witness):
    """Ordinary Sigma introduction with an unused first-body witness slot."""
    goal = old.freeze(source["goal"])
    principal = ("sig", old.shift(goal), eq(0, 0))
    return document(principal,
                    ("pair", principal, witness, old.freeze(source["proof"]),
                     tr.reflexivity(witness)),
                    [old.freeze(a) for a in source["assumptions"]])


def fresh_cases():
    # The witness depends on two outer parameters and contains nested
    # two-slot recursion bodies.  The first matrix depends on the witness.
    witness = ("r", ("s", 0), 1, ("r", 1, 0, ("s", 0)))
    recursive = ("r", 0, 1, ("s", 0))
    principal = ("sig", eq(0, old.shift(witness)), eq(recursive, recursive))
    yield "dependent_recursion_witness", document(
        principal, ("pair", principal, witness, tr.reflexivity(witness),
                    tr.reflexivity(old.inst(recursive, witness))))

    # A local Pi hypothesis must move past the inserted witness equation.
    witness = ("s", 4)
    matrix = ("pi", eq(0, 1), eq(0, 1))
    principal = ("sig", matrix, eq(0, 0))
    context = [eq(2, Z)]
    left = ("pi", eq(0, old.shift(witness)), ("hyp", 1))
    yield "dependent_pi_and_local_assumption", document(
        principal, ("pair", principal, witness, left, tr.reflexivity(witness)), context)

    # The inner Sigma introduction will itself become a witness binder,
    # and that complete derived proof must be lifted for the outer one.
    witness = ("s", 0)
    matrix = ("sig", eq(0, 1), eq(1, 1))
    principal = ("sig", matrix, eq(0, 0))
    inner = old.inst(matrix, witness)
    left = ("pair", inner, witness, tr.reflexivity(witness), tr.reflexivity(witness))
    yield "dependent_nested_sigma", document(
        principal, ("pair", principal, witness, left, tr.reflexivity(witness)))

    # Sigma elimination appends two local hypotheses.  The first is used
    # to transport the second, so both indices must shift under wrapping.
    witness = ("s", 0)
    existence = ("sig", eq(0, old.shift(witness)), eq(0, 0))
    conclusion = eq(witness, witness)
    branch = ("eq", ("hyp", 1), eq(0, 0), ("hyp", 2))
    eliminated = ("let", ("hyp", 0), conclusion, branch)
    principal = ("sig", eq(0, 0), eq(0, 0))
    yield "sigma_elimination_local_assumptions", document(
        principal, ("pair", principal, witness, eliminated, tr.reflexivity(witness)),
        [existence])

    # The equation-induction hypothesis is actually used in this step.
    witness = ("r", ("s", 3), 0, ("s", 0))
    invariant = eq(0, 0)
    step = ("eq", ("hyp", 0), eq(("s", 0), ("s", 1)),
            tr.reflexivity(("s", 0)))
    induction = ("nat", invariant, witness, tr.reflexivity(Z), step)
    principal = ("sig", invariant, invariant)
    yield "equation_induction_hypothesis_lifting", document(
        principal, ("pair", principal, witness, induction, tr.reflexivity(witness)))

    # Bottom normalization would add an induction hypothesis.  A local
    # Pi hypothesis has a different formula, so naive index preservation
    # would fail.  The universal translator replaces this Nat by its base.
    truth = eq(Z, Z)
    assumption = ("pi", truth, old.FALSE)
    base = ("app", ("hyp", 0), Z, tr.reflexivity(Z))
    identity = ("app", ("pi", truth, ("hyp", 1)), Z, tr.reflexivity(Z))
    step = ("app", ("hyp", 0), Z, identity)
    yield "bottom_nat_local_hypothesis", document(
        old.FALSE, ("nat", old.FALSE, 7, base, step), [assumption])


def rejected_by(function, data):
    try:
        function(data)
    except (ValueError, TypeError, IndexError, KeyError, RecursionError):
        return True
    return False


def main():
    baseline_dir = ROOT / "provenance" / "baseline_certificates"
    translated_dir = ROOT / "certificates" / "translated"
    fresh_dir = ROOT / "certificates" / "translation_stress"
    source_dir = ROOT / "provenance" / "translation_stress"
    for directory in (translated_dir, fresh_dir, source_dir):
        directory.mkdir(parents=True, exist_ok=True)

    successes = []
    inputs = sorted(baseline_dir.glob("*.json"))
    if len(inputs) != 53:
        raise RuntimeError("expected the 53 pinned baseline certificates")
    for path in inputs:
        source = json.loads(path.read_text())
        translated = tr.certificate(source)
        (translated_dir / path.name).write_text(json.dumps(translated, separators=(",", ":")) + "\n")
        successes.append("baseline/" + path.stem)
        # These wrappers are regenerated rather than duplicating all
        # large certificate trees in the archive.
        for depth, witness in enumerate((13, ("r", ("s", 2), 5, ("r", 1, 0, ("s", 0)))), 1):
            source = wrap(source, witness)
            tr.certificate(source)
            successes.append(f"wrapped_{depth}/" + path.stem)

    for name, source in fresh_cases():
        translated = tr.certificate(source)
        (source_dir / (name + ".json")).write_text(json.dumps(source, separators=(",", ":")) + "\n")
        (fresh_dir / (name + ".json")).write_text(json.dumps(translated, separators=(",", ":")) + "\n")
        successes.append("fresh/" + name)

    # The translator checks before deleting bridge/Nat syntax; invalid
    # branches therefore cannot disappear from an accepted source proof.
    invalid_sources = {
        "bad_bridge_cannot_be_erased": {
            "assumptions": [eq(Z, Z)], "goal": old.FALSE,
            "proof": ("bridge", ("hyp", 0))},
        "unused_bad_bottom_step_cannot_be_erased": {
            "assumptions": [old.FALSE], "goal": old.FALSE,
            "proof": ("nat", old.FALSE, Z, ("hyp", 0), ("hyp", 99))},
        "wrong_sigma_instance": {
            "assumptions": [], "goal": ("sig", eq(0, Z), eq(0, Z)),
            "proof": ("pair", ("sig", eq(0, Z), eq(0, Z)), ("s", Z),
                      tr.reflexivity(("s", Z)), tr.reflexivity(("s", Z)))},
    }
    rejections = []
    for name, source in invalid_sources.items():
        if not rejected_by(tr.certificate, source):
            raise RuntimeError("invalid old certificate survived translation: " + name)
        rejections.append(name)

    # A direct free-variable witness distinguishes y=x from y=y.  This
    # negative goal would be accepted by a pair rule that forgot shift(t).
    capture = {"assumptions": [], "goal": ("sig", eq(0, 0), eq(0, 0)),
               "proof": ("pair", 0, ("hyp", 0), ("hyp", 0))}
    if not rejected_by(new.check, capture):
        raise RuntimeError("capturing a free witness was accepted")
    rejections.append("free_witness_capture")

    summary = {
        "status": "PASS",
        "baseline_certificates": len(inputs),
        "wrapped_certificates": 2 * len(inputs),
        "fresh_certificates": len(successes) - 3 * len(inputs),
        "positive_checks": len(successes),
        "negative_checks": len(rejections),
        "positive_names": successes,
        "negative_names": rejections,
        "boundary": "finite regression tests; the translator is not part of the trusted checker",
    }
    output = ROOT / "validation" / "translation_results.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if not k.endswith("_names")}, indent=2))


if __name__ == "__main__":
    main()
