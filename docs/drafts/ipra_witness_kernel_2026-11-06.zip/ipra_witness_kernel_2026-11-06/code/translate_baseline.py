"""Untrusted, syntax-directed translation from the pinned K checker.

Every old certificate is checked before translation, and every result is
checked by the new kernel.  Neither checker imports this module.  The
translation works for arbitrary finite valid old proofs, not a list of
selected examples.  In particular, it lifts all numerical and assumption
binders when replacing ordinary Sigma introduction by witness-equation
introduction.  A bottom-matrix number rule is replaced by its base proof:
bottom has no free numerical slot, and this avoids changing the old
step's hypothesis indices when bottom normalizes to an equation.
"""

from pathlib import Path
import importlib.util
import json
import sys

import checker as new


_path = Path(__file__).resolve().parents[1] / "provenance" / "baseline_checker.py"
_spec = importlib.util.spec_from_file_location("pinned_baseline", _path)
old = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(old)


def normalize(a):
    """Canonical syntax translation, also accepting already frozen trees."""
    if type(a) in (list, tuple):
        if tuple(a) == old.FALSE:
            return new.CLASH
        return tuple(map(normalize, a))
    return a


def insert_number(a, protected=0):
    """Insert a fresh free number below `protected` local numerical slots."""
    return new.walk(a, lambda i, d: i + d + 1, protected)


def lift(proof, ambient_hypotheses, protected=0):
    """Add one fresh number and one new ambient assumption.

    The new hypothesis is inserted after the original ambient context;
    hypotheses introduced locally inside the proof are shifted past it.
    `protected` counts local proof-level number binders.  The syntax
    walker separately protects binders internal to each term/formula.
    """
    def syntax(a, extra=0):
        return insert_number(a, protected + extra)

    def subproof(p, extra=0):
        return lift(p, ambient_hypotheses, protected + extra)

    match proof:
        case ("hyp", i):
            return ("hyp", i + (i >= ambient_hypotheses))
        case ("pi", a, p):
            return ("pi", syntax(a, 1), subproof(p, 1))
        case ("app", p, t, q):
            return ("app", subproof(p), syntax(t), subproof(q))
        case ("pair", t, p, q):
            return ("pair", syntax(t), subproof(p, 1), subproof(q, 1))
        case ("let", p, a, q):
            return ("let", subproof(p), syntax(a), subproof(q, 1))
        case ("eq", p, a, q):
            return ("eq", subproof(p), syntax(a, 1), subproof(q))
        case ("rec", r):
            return ("rec", syntax(r))
        case ("nat", a, t, p, q):
            return ("nat", syntax(a, 1), syntax(t),
                    subproof(p), subproof(q, 1))
        case _:
            raise ValueError("unknown new proof in untrusted lifting")


def reflexivity(t):
    """R0 twice and equality replacement; no Sigma or falsity rules."""
    p = ("rec", ("r", new.ZERO, t, new.ZERO))
    return ("eq", p, ("=", 0, new.shift(t)), p)


def symmetry(proof, left):
    return ("eq", proof, ("=", 0, new.shift(left)), reflexivity(left))


def sigma_intro(principal, witness, left, right, context_size):
    """Compile the old ordinary Sigma rule into the new witness rule."""
    # In each new branch, numerical slot 0 is y and the last hypothesis
    # is y = witness.  Reverse it and transport the lifted old premises.
    witness_backwards = symmetry(("hyp", context_size), 0)

    def branch(matrix, premise):
        template = insert_number(matrix, 1)
        return ("eq", witness_backwards, template, lift(premise, context_size))

    return ("pair", witness,
            branch(principal[1], left), branch(principal[2], right))


def translate(proof, context):
    """Translate a valid frozen old proof under its original old context."""
    def subproof(p):
        return translate(p, context)

    match proof:
        case ("hyp", i):
            return ("hyp", i)
        case ("rec", r):
            return ("rec", r)
        case ("bridge", p):
            return subproof(p)
        case ("pi", a, p):
            extended = (*map(old.shift, context), a)
            return ("pi", normalize(a), translate(p, extended))
        case ("app", p, t, q):
            return ("app", subproof(p), t, subproof(q))
        case ("pair", a, t, p, q):
            return sigma_intro(normalize(a), t, subproof(p), subproof(q), len(context))
        case ("let", p, c, q):
            principal = old.infer(p, context)
            extended = (*map(old.shift, context), principal[1], principal[2])
            return ("let", subproof(p), normalize(c), translate(q, extended))
        case ("eq", p, a, q):
            return ("eq", subproof(p), normalize(a), subproof(q))
        case ("nat", a, t, p, q):
            if a == old.FALSE:
                return subproof(p)
            extra = (a,) if a[0] == "=" else ()
            extended = (*map(old.shift, context), *extra)
            return ("nat", normalize(a), t, subproof(p), translate(q, extended))
        case _:
            raise ValueError("unknown old proof in untrusted translation")


def certificate(document):
    old.check(document)
    context = tuple(map(old.freeze, document["assumptions"]))
    result = {
        "assumptions": [normalize(a) for a in context],
        "goal": normalize(old.freeze(document["goal"])),
        "proof": translate(old.freeze(document["proof"]), context),
    }
    new.check(result)
    return result


if __name__ == "__main__":
    if len(sys.argv) not in (2, 3):
        raise SystemExit("usage: translate_baseline.py INPUT.json [OUTPUT.json]")
    result = certificate(json.loads(Path(sys.argv[1]).read_text()))
    encoded = json.dumps(result, separators=(",", ":")) + "\n"
    if len(sys.argv) == 3:
        Path(sys.argv[2]).write_text(encoded)
    else:
        print(encoded, end="")
