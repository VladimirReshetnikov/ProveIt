MATCHED SOURCE CONTROLS
=======================

These are complete checking programs copied from their corresponding
baseline and changed only as specified below. Original headers, comments,
formatting, and other source text are retained. They are not imported by
the final candidate. All have the same Python/standard-library boundary
as their baselines.

checker_sigma_only.py
    Start from provenance/baseline_checker.py, the exact supplied K.
    Replace only its pair proof-constructor branch with the final
    candidate's new Sigma-introduction branch. Retain genuine falsity,
    its bridge, the original wf function, and the original freeze.

checker_sigma_only_frontier.py
    Make the identical one-branch replacement in the supplied comparator
    provenance/baselines/k_comparator_previous_k_open_pattern/comparisons/
    previous_k_open_pattern.py. This baseline has the smallest raw byte,
    normalized byte, and AST count among the supplied measured programs.
    Genuine falsity and that comparator's original bridge remain present.

checker_conversion_sigma_oldfreeze.py
    Start from code/checker_conversion.py and replace only the pair branch.
    This isolates the Sigma rule under the bottom-conversion presentation,
    independently of the two subsequent representation edits.

checker_conversion_sigma.py
    Start from the preceding control and replace only freeze with the final
    candidate's if-list conversion spelling. Keep the original pattern-based
    wf validation and hard-coded binder pair in walk.

The final code/checker.py then replaces that validation region by explicit
arity/sort tables and wf, and shares BINDERS with walk. This is a separate
representation refactor. A smaller byte count need not mean fewer tokens
or AST nodes; every effect is reported with its actual sign.

The main Sigma change is from a certificate carrying the whole intended
Sigma formula and two checked instances to a certificate carrying a witness
and two branch proofs checked under a fresh equation tying the local variable
to that witness. The result's two bodies are inferred from those branch proofs.
The mathematical equivalence is addressed in the report, not inferred from
these source counts.

REPRODUCTION

    python3 code/measure.py

Run from the package root, or invoke measure.py by its absolute path.
The measurement script checks the exact full-text source transformations,
every baseline hash, and imported-helper accounting. It measures these
controls and all other listed implementations without executing a checker.
The results appear in validation/metrics.json and metrics_table.tex.

The controlled_decomposition JSON object distinguishes:

    bottom_conversion_initial
    sigma_rule_only_in_supplied_K
    sigma_rule_only_in_open_comparator
    sigma_rule_only_after_conversion
    freeze_spelling_only
    table_validation_and_binder_constant_only

The recorded additive chain checks that the separate effects sum exactly
to the total change. These source audits do not replace proof-checker tests
or the mathematical metatheory.
