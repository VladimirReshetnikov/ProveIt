"""Measure both complete kernels against every pinned current root checker.

The inherited source normalizer is unchanged. Controls rename only the
two shared function names and optionally install one identical driver.
"""
import ast
import hashlib
import json
from pathlib import Path
import platform
import tempfile

from source_measure import metrics

ROOT = Path(__file__).resolve().parents[1]
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
DRIVER = '''try:
    take = json.load(sys.stdin).pop
    1 / test(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
'''


class CommonNames(ast.NodeTransformer):
    names = {'inst': 'sub', 'check': 'test'}

    def visit_Name(self, node):
        node.id = self.names.get(node.id, node.id)
        return node

    def visit_FunctionDef(self, node):
        node.name = self.names.get(node.name, node.name)
        return self.generic_visit(node)


def profiles(path, temporary):
    answer = {'as_delivered': {key: metrics(path)[key] for key in FIELDS}}
    for name, common_driver in [('common_names', False),
                                ('common_names_and_driver', True)]:
        tree = CommonNames().visit(ast.parse(path.read_text()))
        if common_driver:
            boundary = next(i for i, item in enumerate(tree.body)
                            if isinstance(item, ast.Try))
            tree.body = tree.body[:boundary] + ast.parse(DRIVER).body
        temporary.write_text(ast.unparse(ast.fix_missing_locations(tree)) + '\n')
        measured = metrics(temporary)
        answer[name] = {key: measured[key] for key in FIELDS}
    return answer


def envelope(rows, profile):
    return {key: min(row['measurements'][profile][key] for row in rows)
            for key in FIELDS}


def dominance(candidate, baseline, profile, strong):
    left = candidate['measurements'][profile]
    right = baseline['measurements'][profile]
    if strong:
        return all(left[key] < right[key] for key in FIELDS)
    return (all(left[key] <= right[key] for key in FIELDS)
            and any(left[key] < right[key] for key in FIELDS))


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    with tempfile.TemporaryDirectory() as directory:
        temporary = Path(directory) / 'controlled.py'
        baselines = []
        for entry in manifest['programs']:
            path = ROOT / 'comparison' / entry['local_file']
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if digest != entry['sha256']:
                raise ValueError('Changed pinned baseline: ' + entry['label'])
            baselines.append({**entry, 'measurements': profiles(path, temporary)})
        candidates = []
        for name in ('checker.py', 'checker_structural.py'):
            path = ROOT / name
            candidates.append({'label': name,
                               'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                               'measurements': profiles(path, temporary)})
    envelopes = {}
    coverage = {}
    for profile in candidates[0]['measurements']:
        old = envelope(baselines, profile)
        new = envelope(candidates, profile)
        envelopes[profile] = {
            'baseline': old, 'portfolio': new,
            'strict_each_coordinate': {key: new[key] < old[key] for key in FIELDS},
        }
        witnesses = []
        for baseline in baselines:
            witnesses.append({
                'baseline': baseline['label'],
                'strict_in_all_three': [candidate['label'] for candidate in candidates
                    if dominance(candidate, baseline, profile, True)],
                'pareto': [candidate['label'] for candidate in candidates
                    if dominance(candidate, baseline, profile, False)],
            })
        coverage[profile] = {
            'every_baseline_strictly_better_in_all_three':
                all(row['strict_in_all_three'] for row in witnesses),
            'every_baseline_pareto_dominated': all(row['pareto'] for row in witnesses),
            'witnesses': witnesses,
        }
    result = {
        'status': 'PASS', 'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'archive_count': len(manifest['archives']), 'program_count': len(baselines),
        'coordinates': list(FIELDS),
        'normalizer_sha256': hashlib.sha256(
            (ROOT / 'comparison/source_measure.py').read_bytes()).hexdigest(),
        'baselines': baselines, 'candidates': candidates,
        'envelopes': envelopes, 'coverage': coverage,
        'limitations': 'No single candidate is below every coordinate of the baseline '
            'envelope. Under the identical-driver control, the portfolio ties the '
            'AST floor; all baselines are Pareto dominated, but context_blocks is '
            'not strictly improved in all three coordinates. These are complete '
            'implementation comparisons, not a mathematical minimum theorem.'
    }
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = [r'\begin{tabular}{@{}lrrr@{}}',
             r'\toprule Program & Tokens & AST & Bytes\\', r'\midrule']
    for row in baselines + candidates:
        name = row['label'].replace('ipra_', '').replace('_2026-11-08', '')
        name = name.replace('_', r'\_')
        measured = row['measurements']['as_delivered']
        lines.append(name + ' & ' + ' & '.join(str(measured[key]) for key in FIELDS)
                     + r'\\')
    lines += [r'\bottomrule', r'\end{tabular}']
    (ROOT / 'results/checker_table.tex').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'status': result['status'], 'envelopes': envelopes,
                      'coverage': {name: {key: value for key, value in row.items()
                                         if key != 'witnesses'}
                                   for name, row in coverage.items()}}, indent=2))


if __name__ == '__main__':
    main()
