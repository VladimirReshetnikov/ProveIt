"""Build the mathematical report with a local TeX installation."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
               "-no-shell-escape", "report.tex"]
    for _ in range(2):
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        if result.returncode:
            print(result.stdout[-12000:])
            print(result.stderr[-2000:], file=sys.stderr)
            raise SystemExit(result.returncode)
    log = (ROOT / "report.log").read_text(errors="replace")
    warnings = [line for line in log.splitlines()
                if "Overfull" in line or "undefined" in line.lower()]
    if warnings:
        print("\n".join(warnings))
        raise SystemExit("Resolve TeX overflow or undefined references before delivery.")
    pdf = ROOT / "report.pdf"
    info = subprocess.run(["pdfinfo", str(pdf)], capture_output=True, text=True)
    receipt = {
        "command": command,
        "passes": 2,
        "bytes": pdf.stat().st_size,
        "sha256": hashlib.sha256(pdf.read_bytes()).hexdigest(),
        "pdfinfo": info.stdout,
        "overfull_or_undefined_warnings": warnings,
    }
    (ROOT / "results/build.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in
                      ("passes", "bytes", "sha256",
                       "overfull_or_undefined_warnings")}, indent=2))


if __name__ == "__main__":
    main()
