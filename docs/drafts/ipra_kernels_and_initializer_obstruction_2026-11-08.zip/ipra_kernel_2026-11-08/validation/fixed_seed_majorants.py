"""Construct PR majorants for fixed-seed scalar-iterator terms.

This is an executable illustration of the structural proof in
fixed_seed_obstruction.tex, not a proof-assistant formalization.
All syntax is finite.  No claim of a primitive-recursive universal
evaluator is made: each generated bound is a finite PR description.

Run: python3 fixed_seed_majorants.py > fixed_seed_majorants.json
Only Python's standard library is used.
"""

import itertools
import json


def variable(name):
    return {"term": "variable", "name": name}


def constant(value):
    assert type(value) is int and value >= 0
    return {"term": "constant", "value": value}


def successor(body):
    return {"term": "successor", "body": body}


def iterate(seed, counter, binder, update):
    assert type(seed) is int and seed >= 0
    return {"term": "iterate", "seed": seed, "counter": counter,
            "binder": binder, "update": update}


def bound_constant(value):
    return {"bound": "constant", "value": value}


def bound_add(left, right):
    return {"bound": "add", "left": left, "right": right}


def bound_compose(outer, inner):
    return {"bound": "compose", "outer": outer, "inner": inner}


IDENTITY = {"bound": "identity"}


def majorant(term):
    """Return (selected free variable or None, a monotone unary PR bound).

    A certificate with coordinate None has a bound independent of its
    dummy unary input.  No object-language term is assumed for a bound.
    """
    kind = term["term"]
    if kind == "constant":
        return None, bound_constant(term["value"])
    if kind == "variable":
        return term["name"], IDENTITY
    if kind == "successor":
        coordinate, bound = majorant(term["body"])
        return coordinate, bound_add(bound, bound_constant(1))
    if kind != "iterate":
        raise ValueError("Unknown term constructor")

    coordinate, bound = majorant(term["update"])
    seed_bound = bound_constant(term["seed"])
    if coordinate != term["binder"]:
        # The update is bounded by a fixed parameter, or by a constant.
        return coordinate, bound_add(seed_bound, bound)

    # The update is bounded solely in its iterated state.
    step_bound = bound_add(bound_add(seed_bound, IDENTITY), bound)
    orbit_bound = {"bound": "iterate", "seed": term["seed"],
                   "step": step_bound}
    counter_coordinate, counter_bound = majorant(term["counter"])
    return counter_coordinate, bound_compose(orbit_bound, counter_bound)


def evaluate_term(term, environment):
    kind = term["term"]
    if kind == "constant":
        return term["value"]
    if kind == "variable":
        return environment[term["name"]]
    if kind == "successor":
        return 1 + evaluate_term(term["body"], environment)
    if kind == "iterate":
        count = evaluate_term(term["counter"], environment)
        value = term["seed"]
        for _ in range(count):
            local = dict(environment)
            local[term["binder"]] = value
            value = evaluate_term(term["update"], local)
        return value
    raise ValueError("Unknown term constructor")


def evaluate_bound(bound, argument):
    kind = bound["bound"]
    if kind == "constant":
        return bound["value"]
    if kind == "identity":
        return argument
    if kind == "add":
        return (evaluate_bound(bound["left"], argument)
                + evaluate_bound(bound["right"], argument))
    if kind == "compose":
        return evaluate_bound(bound["outer"],
                              evaluate_bound(bound["inner"], argument))
    if kind == "iterate":
        value = bound["seed"]
        for _ in range(argument):
            value = evaluate_bound(bound["step"], value)
        return value
    raise ValueError("Unknown bound constructor")


def free_variables(term):
    kind = term["term"]
    if kind == "constant":
        return set()
    if kind == "variable":
        return {term["name"]}
    if kind == "successor":
        return free_variables(term["body"])
    if kind == "iterate":
        return (free_variables(term["counter"])
                | (free_variables(term["update"]) - {term["binder"]}))
    raise ValueError("Unknown term constructor")


def examples():
    x, y, u = variable("x"), variable("y"), variable("u")
    zero = constant(0)
    return {
        "identity": x,
        "closed_term": iterate(1, constant(3), "u", successor(u)),
        "zero_test": iterate(1, x, "u", zero),
        "guarded_parameter": iterate(1, x, "u", y),
        "double_plus_one": iterate(1, x, "u", successor(successor(u))),
        "parity_from_one": iterate(1, x, "u", iterate(1, u, "v", zero)),
        "state_bound_despite_parameter": iterate(
            1, x, "u", iterate(1, y, "v", successor(u))),
        "parameter_bound_despite_state": iterate(
            1, x, "u", successor(iterate(1, u, "v", y))),
        "correlated_counter_and_parameter": iterate(
            1, successor(x), "u", successor(iterate(1, u, "v", x))),
        "zero_seed_identity": iterate(0, x, "u", successor(u)),
    }


def run():
    rows = []
    total = 0
    for name, term in examples().items():
        coordinate, bound = majorant(term)
        variables = sorted(free_variables(term))
        assert coordinate is None or coordinate in variables
        checked = 0
        values = []
        for inputs in itertools.product(range(5), repeat=len(variables)):
            environment = dict(zip(variables, inputs))
            actual = evaluate_term(term, environment)
            upper = evaluate_bound(bound, environment.get(coordinate, 0))
            assert 0 <= actual <= upper, (name, environment, actual, upper)
            values.append({"inputs": environment, "value": actual,
                           "upper_bound": upper})
            checked += 1
        for n in range(5):
            assert evaluate_bound(bound, n) <= evaluate_bound(bound, n + 1)
        total += checked
        rows.append({"name": name, "term": term, "coordinate": coordinate,
                     "majorant": bound, "finite_instances_checked": checked,
                     "sample_values": values[:5]})
    print(json.dumps({
        "claim": "Effective PR-majorant construction for fixed-seed terms",
        "scope": "Finite examples validate the implementation only; the general theorem has a separate written proof.",
        "range_per_free_variable": [0, 4],
        "total_finite_instances_checked": total,
        "examples": rows,
    }, indent=2))


if __name__ == "__main__":
    run()
