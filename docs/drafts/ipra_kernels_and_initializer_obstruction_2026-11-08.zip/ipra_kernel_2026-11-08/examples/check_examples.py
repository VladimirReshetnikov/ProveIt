"""Check every public example through each complete command-line program."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
INDEX = json.loads((ROOT / "examples/index.json").read_text())


def main():
    rows = []
    for checker in ("checker.py", "checker_structural.py"):
        for optimized in (False, True):
            for item in INDEX:
                command = [sys.executable]
                if optimized:
                    command.append("-O")
                command.append(str(ROOT / checker))
                packet = (ROOT / "examples" / item["file"]).read_text()
                result = subprocess.run(command, input=packet, text=True,
                                        capture_output=True, timeout=10)
                expected = ("ACCEPT", 0) if item["accept"] else ("REJECT", 1)
                observed = result.stdout.strip(), result.returncode
                if observed != expected or result.stderr:
                    raise RuntimeError((checker, item["file"], optimized,
                                        observed, expected, result.stderr))
                rows.append({"checker": checker, "example": item["file"],
                             "optimized": optimized,
                             "accepted": item["accept"]})
    receipt = {"status": "PASS", "cli_runs": len(rows), "rows": rows}
    (ROOT / "results/public_examples.json").write_text(
        json.dumps(receipt, indent=2) + "\n")
    print(f"PASS: {len(rows)} public-example CLI runs.")


if __name__ == "__main__":
    main()
