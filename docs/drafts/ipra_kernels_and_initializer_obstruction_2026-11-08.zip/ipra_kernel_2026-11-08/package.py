"""Create a clean offline ZIP and an integrity manifest."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".fls", ".fdb_latexmk",
                     ".synctex.gz", ".pyc"}


def files():
    return sorted(path for path in ROOT.rglob("*")
                  if path.is_file()
                  and "__pycache__" not in path.parts
                  and path.suffix not in EXCLUDED_SUFFIXES
                  and path.name != "SHA256SUMS.txt"
                  and not path.name.endswith(".zip"))


def main():
    paths = files()
    digest = "".join(
        hashlib.sha256(path.read_bytes()).hexdigest() + "  "
        + path.relative_to(ROOT).as_posix() + "\n"
        for path in paths)
    manifest = ROOT / "SHA256SUMS.txt"
    manifest.write_text(digest)
    archive = ROOT.parent / "ipra_kernels_and_initializer_obstruction_2026-11-08.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as z:
        for path in paths + [manifest]:
            name = ROOT.name + "/" + path.relative_to(ROOT).as_posix()
            item = zipfile.ZipInfo(name, date_time=(2026, 11, 8, 0, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            item.external_attr = 0o644 << 16
            z.writestr(item, path.read_bytes())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError("ZIP integrity failure")
    print(json.dumps({
        "archive": str(archive.resolve()), "files": len(paths) + 1,
        "bytes": archive.stat().st_size,
        "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()
    }, indent=2))


if __name__ == "__main__":
    main()
