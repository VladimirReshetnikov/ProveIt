SMALLER iPRA CERTIFICATE KERNELS AND AN INITIALIZER OBSTRUCTION
=============================================================
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date).

START WITH report.pdf.
Complete editable LaTeX is report.tex, sections/, appendices/, and results/*.tex.

STATUS
------
This is a verified implementation advance plus a mathematical obstruction.
It is NOT the requested significant positive mathematical simplification.
The arithmetic basis and logical reconstruction remain inherited.

Pinned current repository snapshot:
  VladimirReshetnikov/ProveIt
  6fac3001a902d6666186fc4692a96de0ef296cf7
  Six current November 8 archives, nine complete root checker programs.

COMPLETE-PROGRAM MEASUREMENTS
-----------------------------
                                        Tokens     AST     Normalized bytes
Current coordinatewise minima               322     350                  903
checker.py (byte-oriented)                  318     352                  885
checker_structural.py                       317     348                  908
New two-profile coordinatewise minima       317     348                  885

No individual new checker beats all three current coordinatewise minima.
Every individual current checker is strictly improved in all three coordinates
by at least one of the two delivered profiles. An envelope is not one program.

Common helper names retain this result. With common names AND identical public
drivers, the current envelope is 323/350/879 and the new envelope is 318/350/861.
The AST minimum then ties at 350. Every current checker remains Pareto dominated,
but the context-block checker is not strictly improved in its AST coordinate.

All trusted project code, imports, input/output and rejection handling count.
The inherited normalizer is unchanged. Counts use CPython 3.12.14.

MATHEMATICAL RESULT
-------------------
Every term built from numerical constants, successor, composition, and scalar
iteration from fixed numeral seeds is bounded by a nondecreasing primitive-
recursive function of one selected input coordinate (or by a constant).
The proof gives an effective majorant-construction algorithm.

Therefore deleting the variable initializer loses term definitions of addition,
injective pairing, and the general selector, even with arbitrary fixed
parameters in update terms. Fixed seed 1 supplies a zero-test but does not
remove this stronger obstruction.

This concerns term definability. It does not rule out all relational
interpretations or different domains. No historical priority claim is made.

COMPLETE THEORY
---------------
The report states every native term/formula constructor, both iteration
computation schemas, all five inference patterns and side conditions.
It gives the boxed and padded certificate normal form, reconstructs full
intuitionistic first-order logic, reproduces the internal scalar arithmetic,
and supplies whole-domain bi-interpretations with iPRA. Both composites have
the internal identity isomorphism. Genuine falsity is explicitly bridged.

These are written proofs, not a Lean or Rocq formalization.

RUN
---
  python3 checker.py < examples/zero_computation.json
  python3 checker_structural.py < examples/zero_plus_theorem.json
  python3 checker.py < examples/false_computation.json

The first two ACCEPT/exit 0; the last REJECTs/exits 1. FORMAT.txt specifies
the public protocol and decoding. The programs use only the standard library
and Python 3.10+; sufficient finite resources are assumed for completeness.

REPRODUCE OFFLINE
-----------------
  python3 reproduce.py
  python3 reproduce.py --pdf
  python3 package.py

The first command regenerates all finite measurements and tests.
The second also needs pdfLaTeX and the packages declared in report.tex.
No network downloads occur. package.py rebuilds the ZIP and checksum manifest.

FINITE VALIDATION
-----------------
Each profile passes 35,280 opener comparisons, 17 named cases, 3,000 random
packets, 147/147 inherited positives, 1,176 mutations, and 9 full CLI tests.
A separate public-example runner verifies 40 CLI runs across both checkers,
including optimized Python. Majorant examples cover 106 finite instances.
These support implementation correctness; they do not prove the metatheorems.

CONTENTS
--------
report.pdf / report.tex       Paper and main source
sections/ / appendices/       Complete editable mathematical development
checker.py                   Byte-oriented complete verifier
checker_structural.py        Structural complete verifier
FORMAT.txt / examples/       Certificate protocol and runnable examples
comparison/                  Nine unchanged baselines, metric, provenance
validation/                  Separate sorted oracle, tests, majorant algorithm
results/                     Reproducible measurements and validation receipts
build.py / reproduce.py       Offline build and evidence reproduction
package.py                   ZIP and integrity-manifest generation
ATTRIBUTION.txt               Precise inherited/new contribution boundaries
comparison/licenses/         All supplied licenses and attribution notices
SHA256SUMS.txt                Package-integrity manifest

No changes have been pushed to GitHub.
