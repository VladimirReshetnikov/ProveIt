"""Generate the report's tables from recorded reproduction receipts."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def main():
    result = json.loads((ROOT / "results/measurements.json").read_text())
    rows = result["baselines"] + result["candidates"]
    macros = []
    for prefix, candidate in zip(("Main", "Structural"), result["candidates"]):
        measured = candidate["measurements"]["as_delivered"]
        for suffix, field in zip(("Tokens", "AST", "Bytes"), FIELDS):
            macros.append("\\newcommand{\\" + prefix + suffix + "}{"
                          + str(measured[field]) + "}")
    (ROOT / "results/metrics_macros.tex").write_text("\n".join(macros) + "\n")
    labels = {
        "ipra_boxed_witnesses_2026-11-08/checker.py": "Boxed witnesses",
        "ipra_boxed_witnesses_2026-11-08/checker_compatible.py": "Boxed witnesses, compatible",
        "ipra_clausal_kernel_2026-11-08/checker.py": "Clausal kernel",
        "ipra_context_blocks_2026-11-08/checker.py": "Context blocks",
        "ipra_context_pairs_2026-11-08/checker.py": "Context pairs",
        "ipra_context_pairs_2026-11-08/checker_exact_list.py": "Context pairs, exact-list",
        "ipra_fixed_contexts_2026-11-08/checker.py": "Fixed contexts",
        "ipra_normalized_elimination_2026-11-08/checker.py": "Normalized elimination",
        "ipra_normalized_elimination_2026-11-08/checker_readable.py": "Normalized elimination, readable",
        "checker.py": "New byte-oriented profile",
        "checker_structural.py": "New structural profile",
    }
    lines = [r"\begin{center}", r"\begin{tabular}{@{}lrrr@{}}",
             r"\toprule Complete checker & Tokens & AST & Bytes\\", r"\midrule"]
    for row in rows:
        if row["label"] == "checker.py":
            baseline = result["envelopes"]["as_delivered"]["baseline"]
            lines += [r"\midrule", "Current coordinatewise minima & "
                      + " & ".join(str(baseline[f]) for f in FIELDS) + r"\\",
                      r"\midrule"]
        data = row["measurements"]["as_delivered"]
        lines.append(labels[row["label"]] + " & "
                     + " & ".join(str(data[f]) for f in FIELDS) + r"\\")
    new = result["envelopes"]["as_delivered"]["portfolio"]
    lines += ["New two-profile envelope & "
              + " & ".join(str(new[f]) for f in FIELDS) + r"\\",
              r"\bottomrule", r"\end{tabular}", r"\end{center}"]
    (ROOT / "results/comparison_table.tex").write_text("\n".join(lines) + "\n")

    controls = [r"\begin{center}", r"\begin{tabular}{@{}lrr@{}}",
                r"\toprule Control & Current envelope & New envelope\\", r"\midrule"]
    for key, label in [("as_delivered", "As delivered"),
                       ("common_names", "Common helper names"),
                       ("common_names_and_driver", "Common names and driver")]:
        item = result["envelopes"][key]
        values = [" / ".join(str(item[name][f]) for f in FIELDS)
                  for name in ("baseline", "portfolio")]
        controls.append(label + " & " + " & ".join(values) + r"\\")
    controls += [r"\bottomrule", r"\end{tabular}", r"\end{center}"]
    (ROOT / "results/controls_table.tex").write_text("\n".join(controls) + "\n")
    print("Generated report tables from measurement receipts.")


if __name__ == "__main__":
    main()
