"""Reproduce all finite evidence; optionally rebuild the PDF."""
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(*arguments):
    subprocess.run([sys.executable, *arguments], cwd=ROOT, check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pdf", action="store_true")
    args = parser.parse_args()
    run("comparison/measure.py")
    run("validation/validate_kernels.py", "checker.py")
    run("validation/validate_kernels.py", "checker_structural.py")
    with (ROOT / "results/fixed_seed_majorants.json").open("w") as stream:
        subprocess.run([sys.executable, "validation/fixed_seed_majorants.py"],
                       cwd=ROOT, check=True, stdout=stream)
    run("make_tables.py")
    run("examples/check_examples.py")
    if args.pdf:
        run("build.py")
    print("All requested reproduction steps passed.")


if __name__ == "__main__":
    main()
