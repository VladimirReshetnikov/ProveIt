"""Build the modular report and its fully expanded single-file LaTeX source."""
from pathlib import Path
import json
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
STEM = 'ipra_witnesses_and_seeds_2026-11-09'


def expand(path):
    source = path.read_text()
    def child(match):
        relative = match.group(1)
        if not Path(relative).suffix:
            relative += '.tex'
        return expand(ROOT / relative)
    source = re.sub(r'\\input\{([^}]+)\}', child, source)
    def listing(match):
        options, relative = match.groups()
        content = (ROOT / relative).read_text()
        return '\\begin{lstlisting}' + (options or '') + '\n' + content + '\\end{lstlisting}'
    return re.sub(r'\\lstinputlisting(\[[^\]]*\])?\{([^}]+)\}', listing, source)


def main():
    target = ROOT / (STEM + '.tex')
    target.write_text(expand(ROOT / 'report.tex'))
    if not shutil.which('pdflatex'):
        raise SystemExit('pdfLaTeX is required; the expanded TeX source was generated.')
    command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
               '-jobname=report', target.name]
    transcripts = []
    for number in range(3):
        run = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=60)
        transcripts.append(run.stdout + run.stderr)
        if run.returncode:
            (ROOT / 'evidence/build_output.txt').write_text('\n'.join(transcripts))
            print(run.stdout[-6000:])
            raise SystemExit(run.returncode)
    log = (ROOT / 'report.log').read_text(errors='replace')
    unresolved = [line for line in log.splitlines() if
                  'undefined' in line.lower() or 'multiply defined' in line.lower()]
    boxes = [line for line in log.splitlines() if 'Overfull' in line]
    result = {'status': 'PASS' if not unresolved else 'UNRESOLVED REFERENCES',
              'pdf': 'report.pdf', 'standalone_tex': target.name,
              'passes': 3, 'unresolved': unresolved, 'overfull_boxes': boxes}
    (ROOT / 'evidence/build_output.txt').write_text('\n'.join(transcripts))
    (ROOT / 'evidence/build.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if unresolved:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
