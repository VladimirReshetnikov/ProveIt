"""Reproduce the witness restriction evidence and matched complete-source sizes."""
import copy
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

import baseline_checker as baseline
import bounded_checker as bounded
import lift_atomic_witness as producer
from source_measure import metrics

ROOT = Path(__file__).resolve().parent
CERTIFICATES = ROOT / "certificates"


def nodes(proof):
    yield proof
    for field in ("premise", "major", "base", "equality", "before"):
        if field in proof:
            yield from nodes(proof[field])


def accepted(module, packet):
    try:
        if "scope" in packet:
            receipt = module.Checker(packet["declarations"]).check(
                packet["proof"], packet["context"], set(packet["scope"]), packet["goal"])
        else:
            receipt = module.check_packet(packet)
        return True, receipt
    except Exception as error:
        return False, {"error": str(error), "class": type(error).__name__}


def write(name, packet):
    (CERTIFICATES / (name + ".json")).write_text(
        json.dumps(packet, separators=(",", ":")) + "\n")


def simple_witness(witness):
    b = producer.Builder({"a", "x", "y", "outer_x", "outer_y", "b"})
    inner = producer.D("x", "y", producer.Eq(producer.V("x"), producer.V("x")))
    p = b.di(inner, witness, "b", b.refl(witness))
    goal = producer.D("outer_x", "outer_y", inner)
    p = b.di(goal, producer.Z, "a", p)
    return {"declarations": [], "goal": goal, "proof": p}


def progress_example():
    declarations = copy.deepcopy(producer.DECLARATIONS) + [
        {"name": "last2", "kind": "proj", "arity": 2, "index": 1},
        {"name": "R", "kind": "rec", "arity": 1, "base": "0", "step": "last2"},
    ]
    b = producer.Builder({"x", "y"})
    witness = producer.S(producer.Z)
    goal = producer.D("x", "y", producer.Eq(["R", producer.V("y")],
                       ["C", producer.V("x"), producer.Z, producer.Z]))
    z = b.fresh()
    v = producer.V(z)
    ih = producer.sub(goal[3], {"x": witness, "y": v})
    step = b.trans(b.comp(["R", producer.S(v)], ["last2", v, ["R", v]]),
                   b.comp(["last2", v, ["R", v]], ["R", v]))
    step = b.trans(step, b.hyp([ih], 0))
    old = b.di(goal, witness, z, step, "ind")
    new = producer.AtomicLifter(b, goal).lift(old, [])
    return ({"declarations": declarations, "goal": goal, "proof": old},
            {"declarations": declarations, "goal": goal, "proof": new})


def scoped_case_example():
    b = producer.Builder({"a", "p", "x", "y"})
    context = [producer.Eq(producer.V("a"), producer.V("a"))]
    target = producer.D("x", "y", producer.Eq(producer.V("x"), producer.V("p")))
    witness = producer.S(producer.S(producer.V("a")))
    base = producer.sub(target[3], {"x": witness, "y": producer.Z})
    eigen = b.fresh()
    old = b.di(target, witness, eigen, b.hyp(context + [base], 1))
    new = producer.AtomicLifter(b, target).lift(old, context)
    header = {"declarations": producer.DECLARATIONS, "scope": ["a", "p"],
              "context": context, "goal": target}
    return ({**header, "proof": old}, {**header, "proof": new})


def main():
    CERTIFICATES.mkdir(exist_ok=True)
    producer.main()
    cases = []
    for number in (1, 2):
        for prefix, expectation in (("direct", False), ("lifted", True)):
            name = prefix + "_witness_" + str(number)
            cases.append((name, json.loads((CERTIFICATES / (name + ".json")).read_text()),
                          True, expectation))

    for name, witness, valid in (
        ("zero_witness", producer.Z, True),
        ("variable_witness", producer.V("a"), True),
        ("successor_variable_witness", producer.S(producer.V("a")), False),
        ("forbidden_one_witness", producer.S(producer.Z), False),
        ("forbidden_double_successor", producer.S(producer.S(producer.V("a"))), False),
        ("forbidden_projection_witness", ["id", producer.V("a")], False),
    ):
        cases.append((name, simple_witness(witness), True, valid))

    old, new = progress_example()
    cases += [("direct_progress", old, True, False), ("lifted_progress", new, True, True)]
    old, new = scoped_case_example()
    cases += [("direct_scoped_case", old, True, False), ("lifted_scoped_case", new, True, True)]

    p = simple_witness(producer.V("a"))
    bad = copy.deepcopy(p)
    bad["proof"]["premise"]["witness"] = producer.V("out_of_scope")
    cases.append(("invalid_scope", bad, False, False))
    bad = copy.deepcopy(p)
    bad["proof"]["premise"]["eigen"] = "a"
    cases.append(("invalid_freshness", bad, False, False))
    bad = copy.deepcopy(p)
    bad["proof"]["mode"] = "ind"
    cases.append(("invalid_compound_induction", bad, False, False))
    bad = copy.deepcopy(p)
    bad["goal"] = producer.Eq(producer.Z, producer.S(producer.Z))
    cases.append(("invalid_goal", bad, False, False))

    forged = copy.deepcopy(cases[1][1])
    first_comp = next(n for n in nodes(forged["proof"]) if n["rule"] == "comp")
    first_comp["conclusion"][2] = producer.S(first_comp["conclusion"][2])
    cases.append(("invalid_lifted_computation", forged, False, False))
    forged = copy.deepcopy(cases[1][1])
    first_hyp = next(n for n in nodes(forged["proof"]) if n["rule"] == "hyp")
    first_hyp["index"] = True
    cases.append(("invalid_boolean_hypothesis", forged, False, False))

    results = []
    for name, packet, want_baseline, want_bounded in cases:
        write(name, packet)
        rb, eb = accepted(baseline, packet)
        rw, ew = accepted(bounded, packet)
        if (rb, rw) != (want_baseline, want_bounded):
            raise RuntimeError((name, rb, rw, eb, ew))
        witnesses = [n["witness"] for n in nodes(packet["proof"]) if n["rule"] == "di"]
        results.append({"name": name, "baseline_accepted": rb, "bounded_accepted": rw,
                        "bounded_receipt": ew,
                        "paired_introductions": len(witnesses),
                        "permitted_witnesses_only": all(
                            bounded.bounded_witness(t) for t in witnesses)})

    # Exercise the strict public JSON and exit-status boundary in both normal
    # and optimized Python. The scoped examples use the separately validated API.
    public_results = []
    for optimize in (False, True):
        for checker in ("baseline_checker.py", "bounded_checker.py"):
            for name, packet, wb, ww in cases:
                if "scope" in packet:
                    continue
                command = [sys.executable] + (["-O"] if optimize else []) + [str(ROOT / checker)]
                result = subprocess.run(command, input=json.dumps(packet), text=True,
                                        capture_output=True, timeout=20)
                desired = wb if checker.startswith("baseline") else ww
                expected = (0, "ACCEPT\n") if desired else (1, "REJECT\n")
                if (result.returncode, result.stdout) != expected or result.stderr:
                    raise RuntimeError((checker, optimize, name, result))
                public_results.append({"checker": checker, "optimized": optimize,
                                       "certificate": name, "accepted": desired})

    measured = {name: metrics(ROOT / name) for name in ("baseline_checker.py", "bounded_checker.py")}
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    receipt = {"python": platform.python_version(), "api_cases": len(results),
               "public_cli_runs": len(public_results), "results": results,
               "public_results": public_results, "complete_source_metrics": measured,
               "bounded_minus_matched_baseline": {
                   field: measured["bounded_checker.py"][field] - measured["baseline_checker.py"][field]
                   for field in fields},
               "scope": "Finite proof certificates plus written universal theorem; no formalization of metatheory.",
               "compiler_scope": "Atomic DI matrices only; generic compound-matrix translation is described mathematically."}
    (ROOT / "verification.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: value for key, value in receipt.items()
                      if key not in ("results", "public_results")}, indent=2))


if __name__ == "__main__":
    main()
