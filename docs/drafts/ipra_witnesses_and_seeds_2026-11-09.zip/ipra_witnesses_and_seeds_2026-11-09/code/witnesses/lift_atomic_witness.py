"""Untrusted primitive-proof producer for the bounded-witness theorem.

This implements the J(t) construction for literal-equation DI matrices.
It emits only the inherited primitive rules, never a new trusted macro.
The universal theorem for all matrices is a written theorem in the report;
this producer deliberately claims only the atomic-matrix case.
The complete checkers do not import this file.
"""
import copy
import json
from pathlib import Path
import bounded_checker as syntax

Z = ["0"]


def V(x):
    return ["$", x]


def S(x):
    return ["S", x]


def Eq(a, b):
    return ["=", a, b]


def Q(y, b):
    return ["Q", y, b]


def D(x, y, b):
    return ["D", x, y, b]


def sub(formula, mapping):
    return syntax.subst_formula(formula, mapping)


def weaken(proof, at, count=1):
    """Insert assumptions immediately after the proof's ambient context."""
    result = copy.deepcopy(proof)
    if result["rule"] == "hyp" and result["index"] >= at:
        result["index"] += count
    for field in ("premise", "major", "base", "equality", "before"):
        if field in result:
            result[field] = weaken(result[field], at, count)
    return result


class Builder:
    def __init__(self, reserved=()):
        self.used = set(reserved)
        self.counter = 0

    def fresh(self):
        while True:
            label = "_bw" + str(self.counter)
            self.counter += 1
            if label not in self.used:
                self.used.add(label)
                return label

    def hyp(self, context, index):
        return {"rule": "hyp", "conclusion": context[index], "index": index}

    def comp(self, left, right):
        return {"rule": "comp", "conclusion": Eq(left, right)}

    def tr(self, equality, before, make_motive):
        v = self.fresh()
        motive = make_motive(V(v))
        return {"rule": "tr", "conclusion": sub(motive, {v: equality["conclusion"][2]}),
                "equality": equality, "before": before, "variable": v,
                "motive": motive}

    def refl(self, t):
        p = self.comp(["id", t], t)
        return self.tr(p, p, lambda h: Eq(h, t))

    def sym(self, p):
        return self.tr(p, self.refl(p["conclusion"][1]),
                       lambda h: Eq(h, p["conclusion"][1]))

    def trans(self, p, q):
        return self.tr(q, p, lambda h: Eq(p["conclusion"][1], h))

    def selector(self, control, left, right):
        value = ["C", control, left, right]
        if control == Z:
            middle = ["first2", left, right]
            return self.trans(self.comp(value, middle), self.comp(middle, left))
        assert control[0] == "S"
        n = control[1]
        middle = ["last4", n, ["C", n, left, right], left, right]
        return self.trans(self.comp(value, middle), self.comp(middle, right))

    def predecessor(self, argument):
        if argument == Z:
            return self.comp(["P", Z], Z)
        assert argument[0] == "S"
        value = argument[1]
        middle = ["first2", value, ["P", value]]
        return self.trans(self.comp(["P", argument], middle), self.comp(middle, value))

    def di(self, target, witness, eigen, premise, mode="case"):
        return {"rule": "di", "conclusion": target, "witness": witness,
                "eigen": eigen, "mode": mode, "premise": premise}

    def qe(self, major, base, term):
        _, y, body = major["conclusion"]
        return {"rule": "qe", "conclusion": sub(body, {y: term}),
                "major": major, "base": base, "term": term}

    def de(self, major, eigen, premise):
        return {"rule": "de", "conclusion": premise["conclusion"],
                "major": major, "eigen": eigen, "premise": premise}

    def qi(self, context, y, body, step_builder, mode="case"):
        unused, eigen = self.fresh(), self.fresh()
        assumption = sub(body, {y: Z if mode == "case" else V(eigen)})
        step = step_builder(context + [assumption], eigen)
        major = self.di(D(unused, y, body), Z, eigen, step, mode)
        opened = self.fresh()
        target = Q(y, body)
        return self.de(major, opened, self.hyp(context + [target], len(context)))

    def qi_from_existing(self, context, y, body, eigen, premise, mode):
        unused = self.fresh()
        major = self.di(D(unused, y, body), Z, eigen, premise, mode)
        opened = self.fresh()
        target = Q(y, body)
        return self.de(major, opened, self.hyp(context + [target], len(context)))

    def q_to_unused_d(self, p, target, context):
        _, x, y, body = target
        z = self.fresh()
        base = sub(body, {x: Z, y: Z})
        ctx = context + [base]
        step = self.qe(weaken(p, len(context)), self.hyp(ctx, len(context)), S(V(z)))
        return self.di(target, Z, z, step)

    def unused_d_to_q(self, p, target, context):
        a = self.fresh()
        return self.de(p, a, self.hyp(context + [target], len(context)))

    def map_d(self, p, target, context, forward, reverse):
        """Uniform matrix congruence; callbacks receive actual term instances."""
        _, ox, oy, old_body = p["conclusion"]
        _, nx, ny, new_body = target
        a, z = self.fresh(), self.fresh()
        old_q = sub(Q(oy, old_body), {ox: V(a)})
        ctx1 = context + [old_q]
        new_base = sub(new_body, {nx: V(a), ny: Z})
        ctx2 = ctx1 + [new_base]
        old_base = reverse(self.hyp(ctx2, len(ctx1)), V(a), Z, ctx2)
        old_step = self.qe(self.hyp(ctx2, len(context)), old_base, S(V(z)))
        new_step = forward(old_step, V(a), S(V(z)), ctx2)
        inner = self.di(target, V(a), z, new_step)
        return self.de(p, a, inner)

    def eq_endpoint(self, p, control, left_eq, right_eq, expand):
        lp = self.selector(control, left_eq[1], right_eq[1])
        rp = self.selector(control, left_eq[2], right_eq[2])
        if expand:
            left, right = lp["conclusion"][2], rp["conclusion"][2]
            first = self.tr(self.sym(lp), p, lambda h: Eq(h, right))
            return self.tr(self.sym(rp), first,
                           lambda h: Eq(lp["conclusion"][1], h))
        first = self.tr(lp, p, lambda h: Eq(h, rp["conclusion"][1]))
        return self.tr(rp, first, lambda h: Eq(lp["conclusion"][2], h))


class AtomicLifter:
    """A fixed matrix E(x,y) and its directly generated J(v) proof family."""
    def __init__(self, builder, conclusion):
        self.b = builder
        self.F = conclusion
        _, self.x, self.y, self.E = conclusion
        assert self.E[0] == "="
        self.u, self.w, self.r = builder.fresh(), builder.fresh(), builder.fresh()

    def instance(self, witness, counter):
        return sub(self.E, {self.x: witness, self.y: counter})

    def A(self, witness):
        return Q(self.y, sub(self.E, {self.x: witness}))

    def N(self, witness):
        return D(self.u, self.w, self.instance(witness, V(self.w)))

    def M(self, witness, control):
        left = self.instance(witness, V(self.w))
        right = self.instance(V(self.u), V(self.w))
        return D(self.u, self.w,
                 Eq(["C", control, left[1], right[1]],
                    ["C", control, left[2], right[2]]))

    def J(self, witness):
        return Q(self.r, self.M(witness, V(self.r)))

    def endpoint(self, p, witness, control, context, expand):
        b = self.b
        is_left = control == Z
        plain = self.N(witness) if is_left else self.F
        merged = self.M(witness, control)
        if expand and is_left:
            p = b.q_to_unused_d(p, plain, context)

        def convert(q, a, y, ctx, reverse=False):
            return b.eq_endpoint(q, control, self.instance(witness, y),
                                 self.instance(a, y), expand != reverse)

        p = b.map_d(p, merged if expand else plain, context,
                    lambda q, a, y, ctx: convert(q, a, y, ctx),
                    lambda q, a, y, ctx: convert(q, a, y, ctx, True))
        if not expand and is_left:
            p = b.unused_d_to_q(p, self.A(witness), context)
        return p

    def direct_J(self, witness, context):
        """Called at witness0 or a variable; constructs rather than substitutes."""
        b = self.b

        def successor_proof(ctx1, z):
            # The outer QI supplies M(witness,0).
            pA = self.endpoint(b.hyp(ctx1, len(context)), witness, Z, ctx1, False)
            w = b.fresh()
            atomic_base = self.instance(witness, Z)
            ctx2 = ctx1 + [atomic_base]
            pF_step = b.qe(weaken(pA, len(ctx1)), b.hyp(ctx2, len(ctx1)), S(V(w)))
            pF = b.di(self.F, witness, w, pF_step)
            return self.endpoint(pF, witness, S(V(z)), ctx1, True)

        return b.qi(context, self.r, self.M(witness, V(self.r)), successor_proof)

    def lift(self, source_di, context):
        """Replace one atomic DI node; its premise must already be restricted.

        This is a local compiler pass, not an automatic recursive translation
        of arbitrary source proofs. The final emitted certificate is checked
        independently, including every node of that supplied premise.
        """
        b = self.b
        witness = source_di["witness"]
        body_t = sub(self.E, {self.x: witness})
        source_closure = b.qi_from_existing(context, self.y, body_t,
            source_di["eigen"], source_di["premise"], source_di["mode"])

        # NC applied to K(v)=J(P(v)); endpoint proofs are generated directly.
        v = b.fresh()

        def shifted_J(argument, ctx):
            plain = Z if argument == Z else argument[1]
            direct = self.direct_J(plain, ctx)
            return b.tr(b.sym(b.predecessor(argument)), direct, self.J)

        cases_closure = b.qi(context, v, self.J(["P", V(v)]),
            lambda ctx, z: shifted_J(S(V(z)), ctx))
        zero_case = shifted_J(Z, context)
        at_successor = b.qe(cases_closure, zero_case, S(witness))
        at_t = b.tr(b.predecessor(S(witness)), at_successor, self.J)
        base = self.endpoint(source_closure, witness, Z, context, True)
        conclusion = b.qe(at_t, base, S(Z))
        return self.endpoint(conclusion, witness, S(Z), context, False)


DECLARATIONS = [
    {"name": "first2", "kind": "proj", "arity": 2, "index": 0},
    {"name": "last4", "kind": "proj", "arity": 4, "index": 3},
    {"name": "C", "kind": "rec", "arity": 3, "base": "first2", "step": "last4"},
    {"name": "P", "kind": "rec", "arity": 1, "base": "0", "step": "first2"},
]


def source_existential(number):
    """Native existential x=number; direct DI needs the forbidden numeral."""
    b = Builder({"x", "y", "a"})
    target_term = Z
    for _ in range(number):
        target_term = S(target_term)
    body = Eq(["C", V("y"), Z, V("x")], ["C", V("y"), Z, target_term])
    goal = D("x", "y", body)
    z = b.fresh()
    value = ["C", S(V(z)), Z, target_term]
    p = b.di(goal, target_term, z, b.refl(value))
    return b, {"declarations": DECLARATIONS, "goal": goal, "proof": p}


def main():
    directory = Path(__file__).resolve().parent / "certificates"
    directory.mkdir(exist_ok=True)
    for number in (1, 2):
        builder, packet = source_existential(number)
        source = directory / ("direct_witness_" + str(number) + ".json")
        source.write_text(json.dumps(packet, separators=(",", ":")) + "\n")
        transformed = AtomicLifter(builder, packet["goal"]).lift(packet["proof"], [])
        result = {"declarations": DECLARATIONS, "goal": packet["goal"], "proof": transformed}
        output = directory / ("lifted_witness_" + str(number) + ".json")
        output.write_text(json.dumps(result, separators=(",", ":")) + "\n")
        receipt = syntax.check_packet(result)
        print(json.dumps({"file": output.name, **receipt}))


if __name__ == "__main__":
    main()
