Bounded-witness implementation and evidence
===========================================

Run:
  python verify.py

Run a closed certificate:
  python bounded_checker.py < certificates/lifted_witness_2.json

Both complete checkers import only Python's standard json module. They contain
the full numerical declaration validator, formula parser, scope and freshness
checks, capture-avoiding substitution, alpha comparison, computation schema
matcher, primitive inference checker, and public JSON/exit-status boundary.

Numerical basis of these readable programs: fixed finite primitive-recursive
descriptions (projections, composition, primitive recursion). This is inherited
from the readable comparator. These programs do not implement the tiny scalar
iterator encoding used by the current 299-token reference kernel. The written
restriction theorem applies to either basis when the displayed numerical
selector and predecessor equations are available; the paper states the scalar
native version, including its independent predecessor bootstrap.

baseline_checker.py is the frozen inherited Eq/Q/D Choice-DI checker.
It is an exact copy of the explicit-Q, ordinary-formula-context adaptation in
the closure-induction archive, not the older D-only clause-context checker in
the original choice archive. provenance.json identifies the exact source/hash.
bounded_checker.py adds exactly the condition that a validated DI witness is
0 or an available variable a. No successor term, including S(a) or S(0), is a
permitted primitive witness.
Malformed terms and free variables are rejected before this condition is used.

lift_atomic_witness.py is an UNTRUSTED proof producer. It implements the shifted
J(P(v)) argument for literal-equation matrices. P is a declared finite primitive
recursive predecessor description. Every emitted proof is expanded into
comp, hyp, di, de, qe, tr nodes. The trusted checker does not import the producer.
The producer uses the checker's syntactic substitution helper while constructing
data, but construction never counts as verification: final packets are checked
in separate complete-checker executions by verify.py.

The producer's lifting function replaces one atomic DI node and assumes that
its supplied premise is already a restricted proof. The complete output is
checked again, so violating that precondition cannot bypass verification.
The general arbitrary-matrix theorem is a written proof in bounded_witnesses.tex.
The producer is NOT advertised as a generic arbitrary-matrix compiler or a formal
verification of the universal theorem.

Important positive certificates:
- lifted_witness_1.json and lifted_witness_2.json each prove
    D_xy(C(y,0,x)=C(y,0,numeral))
  for numeral1 and numeral2. This is the native existential x=numeral.
  Each uses 224 primitive inference nodes, 13 paired introductions, and only
  permitted witnesses. Their direct source certificates use forbidden witnesses
  and are accepted by the unrestricted checker but rejected by the bounded one.
- lifted_progress.json exercises an actual atomic induction hypothesis.
- lifted_scoped_case.json retains a nonempty arbitrary context and a compound
  witness depending on a free parameter in its source. Its output uses only
  permitted witnesses. Scoped examples are checked through the explicitly
  validated Checker.check API; they intentionally are not public closed packets.

Other cases test acceptance of 0 and a variable; rejection of a successor of
a variable, S0, a double
successor, and a projection application as direct witnesses; invalid scope,
freshness, compound induction, conclusion, computation, and hypothesis index.

verification.json records 20 API cases and 72 public CLI runs under ordinary and
optimized Python. All matched expected accept/reject outcomes. The public tests
also check exact ACCEPT/REJECT output, exit status, and empty stderr.

Source-size measurement strips docstrings/comments using the inherited script.
Complete baseline: 2904 normalized tokens, 3195 AST nodes, 14124 normalized bytes.
Complete bounded: 2932 normalized tokens, 3226 AST nodes, 14284 normalized bytes.
Difference: +28 tokens, +31 AST nodes, +160 bytes. This is an increased size, not
a below-frontier result. The report must not present this readable checker as
outperforming the compact native programs.

Attribution and the exact inherited source hash are in provenance.json;
the inherited source attribution and license are retained separately.
