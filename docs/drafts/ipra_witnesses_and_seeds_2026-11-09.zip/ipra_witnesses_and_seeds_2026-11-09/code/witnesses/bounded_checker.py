"""Complete standalone Eq/Q/D checker with bounded DI witnesses.

Derived from the attributed full-PR Choice-DI checker in the current corpus.
The only logical change is the validated-term predicate bounded_witness:
DI accepts precisely 0 or an available variable a; no successor term is
accepted directly as a witness.
This readable implementation uses full staged PR declarations, unlike the
small scalar reference kernel. See bounded_witnesses.tex for the theorem.

All numerical declarations, formulas, scopes, alpha comparison, capture-free
substitution, inference rules and strict JSON decoding are included here.
There are no local imports and no assertion controls acceptance.
"""

import json


class ProofError(ValueError):
    """A declaration, syntax tree, scope, or inference is invalid."""


def require(condition, message):
    if not condition:
        raise ProofError(message)


def fields(value, names, description):
    require(type(value) is dict, description + " must be an object")
    require(set(value) == set(names), description + " has incorrect fields")


def name(value):
    return type(value) is str and value.isidentifier()


def variable(value):
    return ["$", value]


def zero():
    return ["0"]


def successor(term):
    return ["S", term]


def bounded_witness(term):
    """The caller has already validated the complete term and its scope."""
    return term == zero() or term[0] == "$"


def truth_formula():
    return ["=", ["id", zero()], zero()]


def fv_term(term):
    if term[0] == "$":
        return {term[1]}
    result = set()
    for child in term[1:]:
        result.update(fv_term(child))
    return result


def binders_and_body(formula):
    return (formula[1:2], formula[2]) if formula[0] == "Q" else (formula[1:3], formula[3])


def fv_formula(formula):
    if formula[0] == "=":
        return fv_term(formula[1]) | fv_term(formula[2])
    binders, body = binders_and_body(formula)
    return fv_formula(body) - set(binders)


def all_names(formula):
    if formula[0] == "=":
        return fv_formula(formula)
    binders, body = binders_and_body(formula)
    return set(binders) | all_names(body)


def fresh_name(used, prefix="_v"):
    number = 0
    while prefix + str(number) in used:
        number += 1
    return prefix + str(number)


def subst_term(term, mapping):
    if term[0] == "$":
        return mapping.get(term[1], term)
    return [term[0], *(subst_term(child, mapping) for child in term[1:])]


def subst_formula(formula, mapping):
    """Simultaneous substitution, alpha-renaming conflicting binders first."""
    if formula[0] == "=":
        return ["=", subst_term(formula[1], mapping), subst_term(formula[2], mapping)]
    old_binders, body = binders_and_body(formula)
    active = {key: value for key, value in mapping.items() if key not in old_binders}
    image_names = set()
    for term in active.values():
        image_names.update(fv_term(term))
    used = all_names(body) | image_names | set(active) | set(old_binders)
    renaming = {}
    binders = list(old_binders)
    for index, old in enumerate(old_binders):
        if old in image_names:
            new = fresh_name(used)
            used.add(new)
            binders[index] = new
            renaming[old] = variable(new)
    if renaming:
        body = subst_formula(body, renaming)
    return [formula[0], *binders, subst_formula(body, active)]


def alpha_key(formula):
    """Canonical alpha-equivalence key; free names remain actual names."""
    def term_key(term, environment):
        if term[0] == "$":
            item = term[1]
            return ("bound", environment[item]) if item in environment else ("free", item)
        return ("function", term[0], tuple(term_key(child, environment) for child in term[1:]))
    def formula_key(item, environment, depth):
        if item[0] == "=":
            return ("=", term_key(item[1], environment), term_key(item[2], environment))
        binders, body = binders_and_body(item)
        extended = dict(environment)
        for offset, binder in enumerate(binders):
            extended[binder] = depth + offset
        return (item[0], formula_key(body, extended, depth + len(binders)))
    return formula_key(formula, {}, 0)


def alpha_equal(left, right):
    return alpha_key(left) == alpha_key(right)



class Checker:
    def __init__(self, declarations):
        self.functions = {
            "0": {"kind": "zero", "arity": 0},
            "S": {"kind": "successor", "arity": 1},
            "id": {"kind": "proj", "arity": 1, "index": 0},
        }
        require(type(declarations) is list, "declarations must be an array")
        for declaration in declarations:
            self.declare(declaration)
        self.nodes = 0
        self.max_depth = 0
        self.rule_counts = {}

    def declare(self, declaration):
        require(type(declaration) is dict, "declaration must be an object")
        kind = declaration.get("kind")
        required = {
            "proj": ("name", "kind", "arity", "index"),
            "comp": ("name", "kind", "arity", "outer", "inners"),
            "rec": ("name", "kind", "arity", "base", "step"),
        }
        require(type(kind) is str and kind in required, "unknown declaration kind")
        fields(declaration, required[kind], "declaration")
        symbol = declaration["name"]
        arity = declaration["arity"]
        require(name(symbol) and symbol not in self.functions,
                "function name is invalid or already declared")
        require(type(arity) is int and arity >= 0, "arity must be a nonnegative integer")
        if kind == "proj":
            index = declaration["index"]
            require(type(index) is int and 0 <= index < arity,
                    "projection index is outside its arity")
        elif kind == "comp":
            outer = declaration["outer"]
            inners = declaration["inners"]
            require(type(outer) is str and outer in self.functions,
                    "composition outer function must be earlier")
            require(type(inners) is list
                    and len(inners) == self.functions[outer]["arity"],
                    "composition has the wrong number of inner functions")
            for inner in inners:
                require(type(inner) is str and inner in self.functions
                        and self.functions[inner]["arity"] == arity,
                        "composition inner function is absent or has wrong arity")
        else:
            base = declaration["base"]
            step = declaration["step"]
            require(arity >= 1, "recursive function needs a counter argument")
            require(type(base) is str and base in self.functions
                    and self.functions[base]["arity"] == arity - 1,
                    "recursion base is absent or has wrong arity")
            require(type(step) is str and step in self.functions
                    and self.functions[step]["arity"] == arity + 1,
                    "recursion step is absent or has wrong arity")
        self.functions[symbol] = dict(declaration)

    def term(self, value, scope):
        require(type(value) is list and len(value) >= 1, "term must be a nonempty array")
        head = value[0]
        require(type(head) is str, "term head must be a string")
        if head == "$":
            require(len(value) == 2 and name(value[1]) and value[1] in scope,
                    "numerical variable is malformed or outside the scope")
            return
        require(head in self.functions, "unknown numerical function")
        require(len(value) == self.functions[head]["arity"] + 1,
                "numerical application has wrong arity")
        for child in value[1:]:
            self.term(child, scope)

    def formula(self, value, scope):
        require(type(value) is list and len(value) >= 1,
                "formula must be a nonempty array")
        head = value[0]
        require(type(head) is str, "formula head must be a string")
        if head == "=":
            require(len(value) == 3, "equation has wrong arity")
            self.term(value[1], scope)
            self.term(value[2], scope)
        else:
            require((head == "D" and len(value) == 4)
                    or (head == "Q" and len(value) == 3), "unknown formula constructor")
            binders, body = binders_and_body(value)
            require(all(name(item) for item in binders) and len(set(binders)) == len(binders),
                    "logical binders must have distinct valid names")
            self.formula(body, scope | set(binders))

    def computation(self, term):
        """One defining equation; the input term has already been validated."""
        require(term[0] != "$", "a variable has no defining equation")
        description = self.functions[term[0]]
        kind = description["kind"]
        arguments = term[1:]
        if kind == "proj":
            return arguments[description["index"]]
        if kind == "comp":
            return [description["outer"],
                    *([inner, *arguments] for inner in description["inners"])]
        require(kind == "rec", "zero and successor have no computation axiom")
        counter, *parameters = arguments
        if counter == zero():
            return [description["base"], *parameters]
        require(counter[0] == "S", "recursion counter is neither zero nor a successor term")
        previous = counter[1]
        recursive_value = [term[0], previous, *parameters]
        return [description["step"], previous, recursive_value, *parameters]

    def computes(self, formula):
        """Recognize one literal computation axiom; syntax is already validated."""
        try:
            return formula[0] == "=" and self.computation(formula[1]) == formula[2]
        except ProofError:
            return False

    def check(self, proof, context=(), scope=frozenset(), expected=None):
        """Check a derivation in an explicit validated ordinary-formula context."""
        require(type(scope) in (set, frozenset) and all(name(item) for item in scope),
                "scope must be a set of variable names")
        scope = set(scope)
        require(type(context) in (tuple, list), "context must be a sequence of formulas")
        for formula in context:
            self.formula(formula, scope)
        if expected is not None:
            self.formula(expected, scope)
        self._check(proof, tuple(context), scope, expected, 0)
        return {"accepted": True, "proof_nodes": self.nodes,
                "maximum_depth": self.max_depth, "rule_counts": dict(self.rule_counts),
                "declared_functions": len(self.functions) - 3}

    def _check(self, proof, context, scope, expected, depth):
        require(type(proof) is dict, "proof node must be an object")
        rule = proof.get("rule")
        required = {
            "comp": ("rule", "conclusion"),
            "hyp": ("rule", "conclusion", "index"),
            "qe": ("rule", "conclusion", "major", "base", "term"),
            "di": ("rule", "conclusion", "witness", "eigen", "mode", "premise"),
            "de": ("rule", "conclusion", "major", "eigen", "premise"),
            "tr": ("rule", "conclusion", "equality", "before", "variable", "motive"),
            
        }
        require(type(rule) is str and rule in required, "unknown inference rule")
        fields(proof, required[rule], "proof node")
        conclusion = proof["conclusion"]
        self.formula(conclusion, scope)
        if expected is not None:
            require(alpha_equal(conclusion, expected), "premise has the wrong conclusion")
        self.nodes += 1
        self.max_depth = max(self.max_depth, depth)
        self.rule_counts[rule] = self.rule_counts.get(rule, 0) + 1

        if rule == "comp":
            require(self.computes(conclusion), "conclusion is not a single defining equation")
            return

        if rule == "hyp":
            index = proof["index"]
            require(type(index) is int and 0 <= index < len(context),
                    "hypothesis index is outside the context")
            require(alpha_equal(conclusion, context[index]), "wrong hypothesis conclusion")
            return

        if rule == "qe":
            self._check(proof["major"], context, scope, None, depth + 1)
            closure = proof["major"]["conclusion"]
            require(closure[0] == "Q", "closure elimination needs a Q major")
            argument = proof["term"]
            self.term(argument, scope)
            binder, body = closure[1:]
            require(alpha_equal(conclusion, subst_formula(body, {binder: argument})),
                    "closure specialization has wrong conclusion")
            base = subst_formula(body, {binder: zero()})
            self._check(proof["base"], context, scope, base, depth + 1)
            return

        if rule == "di":
            require(conclusion[0] == "D", "paired introduction needs a paired conclusion")
            witness = proof["witness"]
            eigen = proof["eigen"]
            self.term(witness, scope)
            require(bounded_witness(witness),
                    "paired witness must be 0 or a variable")
            require(name(eigen) and eigen not in scope, "introduction eigenvariable is not fresh")
            x, y, body = conclusion[1:]
            base = subst_formula(body, {x: witness, y: zero()})
            step = subst_formula(body, {x: witness, y: successor(variable(eigen))})
            mode = proof["mode"]
            require(type(mode) is str and mode in ("case", "ind"), "invalid DI mode")
            require(mode == "case" or body[0] == "=", "induction needs an equation")
            retained = (base if mode == "case" else
                        subst_formula(body, {x: witness, y: variable(eigen)}))
            self._check(proof["premise"], context + (retained,), scope | {eigen}, step, depth + 1)
            return

        

        if rule == "de":
            self._check(proof["major"], context, scope, None, depth + 1)
            paired = proof["major"]["conclusion"]
            require(paired[0] == "D", "paired elimination needs a paired major")
            eigen = proof["eigen"]
            require(name(eigen) and eigen not in scope, "elimination eigenvariable is not fresh")
            x, y, body = paired[1:]
            opened = subst_formula(["Q", y, body], {x: variable(eigen)})
            self._check(proof["premise"], context + (opened,), scope | {eigen},
                        conclusion, depth + 1)
            return

        equality = proof["equality"]
        self._check(equality, context, scope, None, depth + 1)
        equation = equality["conclusion"]
        require(equation[0] == "=", "transport major must be an equation")
        placeholder = proof["variable"]
        require(name(placeholder) and placeholder not in scope,
                "transport placeholder must be a fresh variable name")
        motive = proof["motive"]
        self.formula(motive, scope | {placeholder})
        old = subst_formula(motive, {placeholder: equation[1]})
        target = subst_formula(motive, {placeholder: equation[2]})
        require(alpha_equal(conclusion, target), "transport has the wrong result")
        self._check(proof["before"], context, scope, old, depth + 1)


def check_packet(packet):
    fields(packet, ("declarations", "goal", "proof"), "proof packet")
    checker = Checker(packet["declarations"])
    checker.formula(packet["goal"], set())
    return checker.check(packet["proof"], expected=packet["goal"])


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON object key")
        result[key] = value
    return result


def reject_constant(value):
    raise ProofError("nonfinite JSON numeric constant: " + value)


def load_packet(stream):
    return json.load(stream, object_pairs_hook=unique_object,
                     parse_constant=reject_constant)


if __name__ == "__main__":
    try:
        with open(0, encoding="utf-8") as stream:
            check_packet(load_packet(stream))
        print("ACCEPT")
    except Exception:
        print("REJECT")
        raise SystemExit(1)
