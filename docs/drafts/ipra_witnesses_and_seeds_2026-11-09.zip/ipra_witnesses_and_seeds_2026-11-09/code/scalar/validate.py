"""Reproduce bounded-witness scalar checker metrics and scoped CLI checks."""
import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import platform
import subprocess
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def metrics(path):
    raw = path.read_bytes()
    tree = ast.fix_missing_locations(StripDocstrings().visit(ast.parse(raw)))
    normalized = ast.unparse(tree) + '\n'
    return {'file': path.name, 'sha256': hashlib.sha256(raw).hexdigest(),
            'normalized_tokens': sum(t.type not in IGNORED for t in
                                    tokenize.generate_tokens(io.StringIO(normalized).readline)),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode()), 'raw_bytes': len(raw)}


def term(t, scope=()):
    """Encode named canonical terms using the inherited sorted decoder."""
    if t == 0:
        return 0
    if isinstance(t, str):
        return 2 * scope.index(t) + 1
    if t[0] == 'S':
        return [term(t[1], (None,) + scope)]
    tag, counter, seed, state, update = t
    if tag != 'I':
        raise ValueError(tag)
    return [term(counter, (None, None) + scope),
            term(seed, (None, None) + scope),
            term(update, (state, state) + scope)]


def formula(a, scope=()):
    if a[0] == '=':
        return [term(a[1], scope), term(a[2], scope)]
    tag, witness, counter, body = a
    if tag != 'D':
        raise ValueError(tag)
    return [0, 0, formula(body, (counter, witness) + scope)]


def witness_packet(witness, outer_witness=None):
    # Outer DI makes numerical eigenparameter -1 available. The inner
    # witness actually occurs in its equation. Both introduction steps
    # have a syntactically distinct base and successor goal, and the
    # remaining equation is an actual I0 computation.
    seed = ('I', 0, 'x', 'u', 'n')
    equation = ('=', ('I', 0, seed, 'v', 'm'), seed)
    goal = formula(('D', 'a', 'n', ('D', 'x', 'm', equation)))
    if outer_witness is None:
        outer_witness = [0, 0]
    return [[0, 0], [[], witness], [[], outer_witness], goal]


def decoded_zero_packet():
    # D_xy(C(y,0,x)=C(y,0,0)) directly uses the decoded zero witness.
    # Its successor goal is R=R. A pair of I0 computation proofs and
    # equality transport establish that reflexive equation.
    goal = formula(('D', 'x', 'y',
                    ('=', ('I', 'y', 0, 'u', 'x'), ('I', 'y', 0, 'u', 0))))
    r = [[-1], 0, 0]
    source = [[0, r, 0], r]
    return [[0, 0], [0, 0], [source, [1, r]], [[], [0, 0]], goal]


def adapt_boxed_zero(packet):
    # Only instruction payloads are changed. Formula/term occurrences
    # of the old boxed iterator are left untouched.
    packet = copy.deepcopy(packet)
    for cell in packet[:-1]:
        if isinstance(cell, list) and len(cell) == 2 and not cell[0] and cell[1] == [0, 0, 0]:
            cell[1] = [0, 0]
    return packet


def main():
    cases = []
    for name, witness in [('annotated_zero', [0, 0]),
                          ('available_variable', -1),
                          ('successor_of_available_variable', [-1])]:
        cases.append({'name': name, 'packet': witness_packet(witness),
                      'baseline_accept': True, 'bounded_accept': True})
    for name, witness in [('forbidden_successor_zero', [0]),
                          ('forbidden_double_successor', [[-1]]),
                          ('forbidden_iterator', [0, 0, 0]),
                          ('forbidden_float_variable', -1.0),
                          ('forbidden_float_successor', [-1.0]),
                          ('forbidden_boolean_annotation', [False, 0]),
                          ('forbidden_float_annotation', [0.0, 0]),
                          ('forbidden_noncanonical_zero_annotation', [[0], 0])]:
        cases.append({'name': name, 'packet': witness_packet(witness),
                      'baseline_accept': True, 'bounded_accept': False})
    cases.append({'name': 'future_parameter', 'packet': witness_packet(-2),
                  'baseline_accept': False, 'bounded_accept': False})
    cases.append({'name': 'unallocated_outer_parameter',
                  'packet': witness_packet([0, 0], outer_witness=-1),
                  'baseline_accept': True, 'bounded_accept': False})
    cases.append({'name': 'instruction_zero_is_decoded_to_scalar_zero',
                  'packet': decoded_zero_packet(),
                  'baseline_accept': False, 'bounded_accept': True})

    inherited = json.loads((ROOT / 'inherited_fixtures.json').read_text())['cases']
    for case in inherited:
        has_old_witness = any(isinstance(cell, list) and len(cell) == 2
                              and not cell[0] and cell[1] == [0, 0, 0]
                              for cell in case['packet'][:-1])
        cases.append({'name': 'original_' + case['name'], 'packet': case['packet'],
                      'baseline_accept': case['accept'],
                      'bounded_accept': case['accept'] and not has_old_witness})
        cases.append({'name': 'canonical_zero_' + case['name'],
                      'packet': adapt_boxed_zero(case['packet']),
                      'baseline_accept': case['accept'],
                      'bounded_accept': case['accept']})
    (ROOT / 'fixtures.json').write_text(json.dumps({'cases': cases}, indent=2) + '\n')
    receipts = []
    for filename, field in [('baseline_choice.py', 'baseline_accept'),
                            ('checker.py', 'bounded_accept'),
                            ('checker_variables.py', 'bounded_accept')]:
        for optimized in (False, True):
            for case in cases:
                command = [sys.executable] + (['-O'] if optimized else []) + [str(ROOT / filename)]
                result = subprocess.run(command, input=json.dumps(case['packet']), text=True,
                                        capture_output=True, timeout=10)
                expected_accept = case[field]
                if filename == 'checker_variables.py' and case['name'] == 'successor_of_available_variable':
                    expected_accept = False
                expected = (0, 'ACCEPT') if expected_accept else (1, 'REJECT')
                receipts.append({'program': filename, 'optimized': optimized,
                                 'case': case['name'], 'expected_accept': expected_accept,
                                 'exit_code': result.returncode,
                                 'stdout': result.stdout.strip(),
                                 'passed': (result.returncode, result.stdout.strip()) == expected})
    rows = [metrics(ROOT / p) for p in ('baseline_choice.py', 'checker.py', 'checker_variables.py')]
    fields = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
    result = {'python': platform.python_version(), 'programs': rows,
              'added_cost': [{k: row[k] - rows[0][k] for k in fields} for row in rows[1:]],
              'case_count': len(cases), 'execution_count': len(receipts),
              'failures': sum(not r['passed'] for r in receipts), 'receipts': receipts,
              'scope': 'Restricted witness instructions with explicit zero decoding added to a complete scalar checker; finite CLI tests supplement the written soundness/completeness argument. Not an accepted-packet subset claim.'}
    (ROOT / 'validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'receipts'}, indent=2))
    if result['failures']:
        print(json.dumps([r for r in receipts if not r['passed']], indent=2))
        raise SystemExit(1)


if __name__ == '__main__':
    main()
