"""Complete scalar native iPRA checker with DI witnesses restricted to 0, a, Sa.

Derived from the complete Choice-DI token profile; the only operative
changes are a DI witness guard and instruction-level zero decoding. See README.txt and FORMAT.txt.

Inherited description:

A paired introduction retains exactly one local assumption. Canonical
instruction heads are 0 for equation induction and [] for base cases.
The numerical syntax, Eq/Q/D meanings, computation and eliminations are
inherited; the certificate interface differs from the original checker.
A truthy elimination major must have a successful proof. See report.pdf
and code/native/FORMAT.txt for the decoding and correctness boundaries.
Only the standard json module is imported by this standalone program.
"""
import json
k = 0


i = lambda a, t=None, d=0: [i(b, t, d + b' \2\1\4'[len(a)]) for b in a] if isinstance(a,list) else a if k <= a < d else d % 2 and i(t, d=1)


def permitted_witness(t):
    """Recognize exactly annotated zero, an available variable, or its successor."""
    if type(t) is int:
        return k <= t < 0
    if type(t) is list:
        if len(t) == 1:
            return type(t[0]) is int and k <= t[0] < 0
        return len(t) == 2 and all(type(a) is int and a == 0 for a in t)
    return False


def c(a, g, s=1):
    global k
    if i(a) in g:
        return 1
    m, t = q()
    if m:
        1 / c(m, g)
        try:
            h = [m[2]]
        except:
            u = t
            try:
                s = 0
                t, = m
            except:
                s, u = m
            return i(t, u) == a and c(i(t, s), g)
    elif t:
        if not permitted_witness(t):
            raise ValueError("restricted DI witness")
        if t == [0, 0]:
            t = 0
        h = a = i(a[2], t, 2)
        s = len(a) % 2 == m
    else:
        (n, t, r), b = a
        if n:
            n, = n
            t = i(r, [n, t, r], 1)
        return b == t
    k -= 1
    return c(i(a, [k]), g + [i(h, k * s)])


try:
    q = json.load(open(0)).pop
    1 / c(q(), [])
    print('ACCEPT')
except:
    print('REJECT')
    raise SystemExit(1)
