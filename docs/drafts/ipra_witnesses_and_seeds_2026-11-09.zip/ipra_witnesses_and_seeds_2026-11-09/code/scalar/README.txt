SCALAR CHECKERS WITH RESTRICTED PAIRED-INTRODUCTION WITNESSES
===========================================================

These are complete standalone scalar native checker implementations,
subject to the written restricted-witness equivalence theorems in the
accompanying report. They are direct changes to the inherited complete
Choice-DI tokens.py profile from ProveIt's ipra_choice_2026-11-09 archive.
The numerical basis is the original 0,S,initialized scalar iterator basis;
no full primitive-recursive function registry or arithmetic oracle is used.

PROGRAMS
--------
baseline_choice.py: exact inherited Choice-DI tokens.py comparator.
checker.py: DI witnesses 0, an available variable a, or Sa.
checker_variables.py: DI witnesses 0 or an available variable a.

Only the standard json module is imported by each checker. Each source
includes parsing, normalization, all proof rules, acceptance output and
rejection exit. No producer or validation program is a checker dependency.

The two operative changes are:
1. A direct, explicitly typed guard on a DI instruction's witness field.
2. Instruction-level decoding of the nonempty field [0,0] to scalar zero
   before the inherited opening routine is called.

That second step is substantive for the certificate interface. [0,0] is
an instruction annotation denoting the witness 0; it is NOT passed as a
literal numerical binary node to the opening routine. The old decoder's
semantic reading of such a binary numerical node as zero would not by
itself establish raw-premise agreement or the required completeness proof.
We make no accepted-packet subset claim relative to baseline_choice.py.

The sources and the report distinguish numerical term substitution in
syntax from arbitrary numerical substitution through a restricted proof.
Completeness uses the proved bounded-witness derivation translation, then
the ordinary finite canonical encoding described in correctness.tex.

MEASURED IMPLEMENTATION COST
---------------------------
CPython 3.12.14, whole modules, comments/docstrings stripped, ast.unparse:

                            tokens   AST nodes   normalized bytes
baseline_choice.py             299         345                880
checker.py                     407         476               1284
checker_variables.py           380         441               1205

The explicit W={0,a} guard/decoder adds 81 tokens, 96 AST nodes, 325 bytes
to this matched baseline. W={0,a,Sa} adds 108/131/404. Neither beats the
current corpus coordinate envelope 299/340/815. These straightforward
implementations quantify the cost of the new proof-rule restriction;
they are not a source-minimization claim.

EXECUTABLE EVIDENCE
-------------------
Run:
    python3 validate.py

The script runs 56 cases against each of three complete checkers, in
normal and optimized Python, for 336 public CLI executions. All passed
in the recorded run. It also reproduces the complete-source metrics.

The cases include the three permitted witness forms in an actual-use
setting, prohibited S0/double-successor/iterator witnesses, explicit float
and Boolean exclusions in witness fields, scope failures, and a theorem
whose direct zero-witness packet demonstrates the new zero decoder.
It replays all 21 inherited focused fixtures with correct changed
expectations, plus all 21 after changing ONLY their old boxed-zero DI
instruction payloads to the new zero annotation. Formula and term
occurrences of old iterator boxes are not rewritten.

In the variables-only program the Sa case is expected to reject. This
does not contradict completeness: its theorem remains provable by the
derivation translation, while that particular instruction is forbidden.
The tests do not mechanically verify the universal mathematical theorem.

FILES
-----
FORMAT.txt: exact changed instruction boundary and retained public protocol.
correctness.tex: branch soundness and canonical-encoding proof argument.
validate.py: independent encoding of focused fixtures, replay and measures.
fixtures.json: the generated 56 packets with expected profile behavior.
inherited_fixtures.json: unchanged source 21-case fixture collection.
validation.json: full metrics, hashes and every public execution receipt.
LICENSE-inherited.txt: unchanged inherited license.

ATTRIBUTION
-----------
Pinned source repository commit:
  aac8216be66b1a6f043fed87a8d515bc5b5d0790
Source archive:
  docs/drafts/ipra_choice_2026-11-09.zip
Source member:
  ipra_choice_2026-11-09/code/native/tokens.py
Source SHA-256:
  b2b3fe22cc787e8150757df73e86e1d702882699f5d632773a7f68f4f9f1a045

The old numerical language, raw sorted decoder, Choice-DI rule semantics,
proof interface and completeness background are inherited. The explicit
restricted witness fields and zero instruction decoder are the new
implementation changes. Written mathematical proof and finite regression
testing should not be described as a Lean/Rocq formal verification.
