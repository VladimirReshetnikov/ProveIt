"""Finite checks accompanying, not proving, the fixed-seed normal-form theorem.

Only the finite-orbit lemma is exhaustively tested on bounded finite maps.
The mixed-seed terms demonstrate why the old separate invariants do not apply.
The universal normal-form and interpretation results require their written proofs.
"""

from itertools import product
from math import lcm
import json


def iterate(seed, count, update):
    value = seed
    for _ in range(count):
        value = update(value)
    return value


def reduce_counter(bound, count):
    period = lcm(*range(1, bound + 1))
    return count if count < bound else bound + (count - bound) % period


def zero_indicator(n):
    # J_1(n; u.0): both a positive seed and fixed constant update.
    return iterate(1, n, lambda _: 0)


def gate(n, value):
    # J_0(n; u.value): zero seed with passive parameter value.
    return iterate(0, n, lambda _: value)


def nonzero_or(a, b):
    # NOT( (NOT a) AND (NOT b) ), using only J_0 and J_1.
    return zero_indicator(gate(zero_indicator(a), zero_indicator(b)))


def validate():
    maps = seeds = comparisons = 0
    per_bound = []
    for bound in range(1, 6):
        period = lcm(*range(1, bound + 1))
        max_count = 3 * bound + 3 * period
        local_maps = local_seeds = local_comparisons = 0
        for mapping in product(range(bound), repeat=bound):
            maps += 1
            local_maps += 1
            for seed in range(bound):
                seeds += 1
                local_seeds += 1
                orbit = [seed]
                for _ in range(max_count):
                    orbit.append(mapping[orbit[-1]])
                for count in range(max_count + 1):
                    reduced = reduce_counter(bound, count)
                    assert orbit[count] == orbit[reduced]
                    assert 0 <= reduced < bound + period
                    comparisons += 1
                    local_comparisons += 1
        per_bound.append({"bound": bound, "maps": local_maps,
                          "seeded_orbits": local_seeds,
                          "max_counter": max_count,
                          "comparisons": local_comparisons})

    boolean_checks = 0
    for a, b in product(range(16), repeat=2):
        assert nonzero_or(a, b) == int(a != 0 or b != 0)
        boolean_checks += 1
    # Prior R_1 is positive-square union {0,1}-square.
    related = lambda a, b: (a > 0 and b > 0) or (a <= 1 and b <= 1)
    assert related(0, 1) and related(2, 2)
    assert not related(gate(0, 2), gate(1, 2))

    # Finite orbit update active in passive x; state only picks a unary piece.
    # This is a representative normal-form map, not claimed minimal native syntax.
    passive_checks = 0
    for x, flag, seed, count in product(range(20), range(2), range(4), range(40)):
        update = lambda u: (x if u % 2 == 0 else x + 1 + flag)
        # Two possible update outputs plus the initial seed give bound 3.
        assert iterate(seed, count, update) == iterate(
            seed, reduce_counter(3, count), update)
        passive_checks += 1

    return {
        "status": "PASS",
        "finite_maps": maps,
        "seeded_orbits": seeds,
        "orbit_comparisons": comparisons,
        "by_bound": per_bound,
        "mixed_seed_boolean_or_checks": boolean_checks,
        "positive_seed_relation_regression": {
            "inputs": [[0, 2], [1, 2]], "outputs": [0, 2], "relation": "R_1"
        },
        "passive_update_finite_orbit_checks": passive_checks,
        "scope": [
            "Exhaustive finite-orbit checks cover maps on sets of size 1 through 5.",
            "Counters run through the exact finite limits recorded per bound.",
            "Mixed-seed examples defeat the separate old support/relation invariants.",
            "These finite checks do not prove the universal normal-form theorem.",
            "No finite test establishes the ordinary bi-interpretability obstruction."
        ]
    }


if __name__ == "__main__":
    print(json.dumps(validate(), indent=2))
