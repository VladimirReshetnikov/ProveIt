Constructor witnesses and the fixed-seed barrier for iPRA
=========================================================

STATUS
------
This package does NOT supply a complete axiomatization below the current
proof-checker frontier. It supplies a complete equivalent restricted-witness
presentation and two mathematical advances relative to the inspected drafts:

1. In Choice-DI, every paired-introduction witness can be restricted to zero
   or an available variable. Even successor witnesses are eliminable.
   The effective proof transformation preserves every native end sequent.
   The resulting presentation is equiconsistent and whole-domain
   bi-interpretable with full first-order intuitionistic PRA.

2. Scalar iteration with arbitrary fixed numeral seeds, including mixed zero
   and positive seeds, cannot combine independent unbounded inputs in terms.
   Every term has a finite unary section normal form. The theorem still holds
   with every unary primitive recursive function available as a helper.
   A transfer to an attributed earlier model gives a scoped obstruction to
   ordinary first-order bi-interpretability, including tuple domains, quotients,
   finite parameters, and full quantifier-free induction.

The second result is not an obstruction to every theory in every language.
Additional multi-input existence axioms and nonordinary logical translations
are outside its scope. Neither result is a global proof-checker lower bound.
No literature-wide priority, proof-assistant formalization, or human peer review
is claimed. The separate proof audits were performed by assistant agents.

START HERE
----------
report.pdf             The complete 36-page mathematical report.
report.tex             The modular LaTeX entry point.
ipra_witnesses_and_seeds_2026-11-09.tex
                       A standalone expanded LaTeX source, including the
                       comparison program listing; no external inputs needed.
sections/              New arguments, target/interpretation bridge, evidence.
appendices/            Attributed inherited internal arithmetic proofs.
reference/             Selected unchanged source sections, bootstrap audit,
                       original license, and historical-model provenance.

The report first proves an intermediate 0/a/Sa witness theorem and then the
final 0/a theorem. The intermediate theorem is not the final restriction.

EXACT COMPARISON
----------------
Pinned repository:
https://github.com/VladimirReshetnikov/ProveIt/tree/aac8216be66b1a6f043fed87a8d515bc5b5d0790/docs/drafts

All 30 current top-level archives were retrieved and checked against their
Git blob hashes and byte lengths. The inventory contains 809 Python source
occurrences and 302 distinct raw-source hashes.

Complete program                    Tokens    AST nodes    Normalized bytes
Choice-DI tokens.py                    299          345                 880
Choice-DI structure.py                 304          340                 902
Choice-DI bytes.py                     307          353                 815
New scalar zero-or-variable            380          441                1205
Matched readable unrestricted         2904         3195               14124
New readable zero-or-variable         2932         3226               14284

The coordinate envelope 299/340/815 is attained by three different programs.
It is an attained upper bound on implementation size, not a proved absolute
minimum. The new implementations are larger. Measurements charge complete
sources, including imports, parser, output, and rejection exit. Comments and
genuine docstrings are stripped, then the AST is unparsed. Names are retained.
The recorded environment is CPython 3.12.14; byte counts can vary by version.

RUN THE EVIDENCE
----------------
From this directory:

    python3 reproduce.py

This replays 126 inherited-frontier CLI cases, 336 scalar CLI cases,
20 readable API cases and 72 readable CLI cases. It also runs the stated
finite-orbit experiment and measures the six complete sources listed above.
It writes evidence/reproduction.json and component receipts.

    python3 build.py

This expands the modular source and runs pdfLaTeX three times. It writes
report.pdf, the standalone .tex source, and evidence/build.json. A normal
TeX Live installation with the packages in report.tex is required. Python
scripts otherwise use only the standard library. Run the reproduction driver
without -O; individual proof checkers are tested under both ordinary and
optimized Python. Finite experiments use ordinary Python assertions.

COMPLETE CHECKERS AND PROOF PRODUCER
-----------------------------------
code/frontier/          Unchanged compact reference programs and 21 fixtures.
code/scalar/            Final scalar checker_variables.py, controlled baseline,
                       intermediate checker.py, format and correctness notes,
                       and 56 packet cases.
code/witnesses/         Readable complete checkers, untrusted atomic-DI proof
                       producer, 20 concrete certificates, source measurement,
                       and public/API verification.
code/fixed_seeds/       Finite-orbit validation and mixed-seed regression cases.

Example:

    python3 code/witnesses/bounded_checker.py < code/witnesses/certificates/lifted_witness_2.json

The lifted certificates use only zero or variable witnesses. The executable
producer replaces one atomic-DI node whose premise is already restricted.
The arbitrary-matrix transformation is given as a written structural proof;
a universal executable translator is not supplied. The complete checkers
themselves accept arbitrary well-formed native formulas.

In the scalar final checker, [0,0] is a checked witness instruction explicitly
decoded to scalar zero before opening its matrix. It is not simply a raw
numerical tree used as a witness. See code/scalar/FORMAT.txt and correctness.tex.
No subset relation between the old and new accepted packet encodings is claimed.

PROVENANCE AND VALIDATION LIMITS
--------------------------------
evidence/repository_snapshot.json records all archive identities.
evidence/all_source_metrics.json records the source inventory.
evidence/comparator_provenance.json identifies the exact comparison members.
evidence/mathematical_review.txt records the separate proof audits and scope.
ATTRIBUTION.txt separates inherited material from the new work.
MANIFEST.sha256.json lists the files and hashes in the final distribution.

Passing concrete certificates is not a formal verification of the universal
metatheorems or of Python. The finite-orbit experiment does not prove the
normal-form theorem; that theorem has a separate structural proof. The report
preserves these distinctions throughout.
