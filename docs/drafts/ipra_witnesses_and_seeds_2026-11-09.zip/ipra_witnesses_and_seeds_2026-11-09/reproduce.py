"""Reproduce the supplied measurements and finite certificate evidence.

This is an untrusted reproduction driver, not a theorem checker. The
universal metatheorems are proved in the manuscript, not by these tests.
"""
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import subprocess
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    raw = path.read_bytes()
    tree = ast.fix_missing_locations(StripDocstrings().visit(ast.parse(raw)))
    normalized = ast.unparse(tree) + '\n'
    return {'file': str(path.relative_to(ROOT)),
            'sha256': hashlib.sha256(raw).hexdigest(),
            'normalized_tokens': sum(t.type not in IGNORED for t in
                                    tokenize.generate_tokens(io.StringIO(normalized).readline)),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode())}


def replay_frontier():
    directory = ROOT / 'code/frontier'
    cases = json.loads((directory / 'focused_certificates.json').read_text())['cases']
    receipts = []
    for name in ('tokens.py', 'structure.py', 'bytes.py'):
        for optimized in (False, True):
            command = [sys.executable] + (['-O'] if optimized else []) + [str(directory / name)]
            for case in cases:
                run = subprocess.run(command, input=json.dumps(case['packet']), text=True,
                                     capture_output=True, timeout=20)
                expected = (0, 'ACCEPT') if case['accept'] else (1, 'REJECT')
                observed = (run.returncode, run.stdout.strip())
                if observed != expected:
                    raise RuntimeError((name, optimized, case['name'], expected, observed))
                receipts.append({'program': name, 'optimized': optimized,
                                 'case': case['name'], 'passed': True})
    return receipts


def run_json(script):
    run = subprocess.run([sys.executable, str(script)], cwd=script.parent,
                         text=True, capture_output=True, timeout=120)
    if run.returncode:
        raise RuntimeError(f'{script.name} failed:\n{run.stdout}\n{run.stderr}')
    # Some producers emit individual certificate receipts before the final
    # summary. Parse the complete JSON stream, retaining those receipts too.
    remaining = run.stdout.strip()
    decoder = json.JSONDecoder()
    records = []
    while remaining:
        value, end = decoder.raw_decode(remaining)
        records.append(value)
        remaining = remaining[end:].lstrip()
    if not records or not isinstance(records[-1], dict):
        raise RuntimeError(f'{script.name} produced no summary object')
    result = records[-1]
    if len(records) > 1:
        result['preceding_producer_receipts'] = records[:-1]
    return result


def main():
    files = [ROOT / 'code/frontier' / name
             for name in ('tokens.py', 'structure.py', 'bytes.py')]
    files += [ROOT / 'code/scalar/checker_variables.py',
              ROOT / 'code/witnesses/baseline_checker.py',
              ROOT / 'code/witnesses/bounded_checker.py']
    measurements = [measure(path) for path in files]
    fields = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
    envelope = {field: min(row[field] for row in measurements[:3]) for field in fields}
    if platform.python_version().startswith('3.12.'):
        if envelope != dict(zip(fields, (299, 340, 815))):
            raise RuntimeError('Pinned Python 3.12 frontier changed')
    frontier = replay_frontier()
    scalar = run_json(ROOT / 'code/scalar/validate.py')
    readable = run_json(ROOT / 'code/witnesses/verify.py')
    seeds = run_json(ROOT / 'code/fixed_seeds/validate.py')
    result = {'status': 'PASS', 'python': platform.python_version(),
              'commit': 'aac8216be66b1a6f043fed87a8d515bc5b5d0790',
              'measurements': measurements, 'frontier_envelope': envelope,
              'frontier_cli_executions': len(frontier),
              'scalar_cli_executions': scalar['execution_count'],
              'scalar_failures': scalar['failures'],
              'readable_summary': readable, 'fixed_seed_summary': seeds,
              'scope': 'Finite executable evidence and source measurements; no claim of formalized metatheory.'}
    (ROOT / 'evidence/reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
