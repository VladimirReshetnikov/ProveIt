Three partial results on Frankl's union-closed sets conjecture
November 25, 2026

1. prescribed_edge.pdf and prescribed_edge.tex
   Exact minimum of the larger endpoint frequency at a prescribed edge in
   a graph-generated union-closed family with bounded maximum degree.
   The tree extremum from the ProveIt drafts is the unrestricted graph
   extremum. Theorem 1 characterizes equality, and Proposition 4 gives
   an explicit gap for every other marked component. The proof is analytic
   and combinatorial. The graph census is an independent check.

2. entropy/nine_billion.pdf and entropy/nine_billion.tex
   Every nontrivial union-closed family with at most nine billion distinct
   members has an element in strictly more than 39 percent of its sets.
   The proof uses the Chase-Lovett entropy inequality. The script certifies
   its finite numerical inequalities with rational arithmetic.

3. private-generators.pdf and private-generators.tex
   Frankl's half-frequency conclusion holds when all but at most five
   generators have a private element, with no restriction on generator size
   or on the total number of generators. A finite exhaustion enters the proof.
   The example with six exceptional generators demonstrates the limit of the
   theorem's localization of an abundant element.

The three notes are independent. All probabilities on families use uniform
distinct members, so different choices producing one union count only once.
The general half-frequency conjecture remains open.

Reproduce the checks
   Use standard Python 3.10 or later, with assertions enabled.
   From the directory containing this README, run
       python3 check_graphs.py
       python3 check_private.py
       python3 entropy/verify.py
   Compare with verification.txt. The graph census checks every graph on
   two through seven vertices up to isomorphism and every eligible edge in
   each representative. Local erasure inequalities are checked separately.

Build the papers
   With a standard TeX Live installation and latexmk, run
       latexmk -pdf prescribed_edge.tex
       latexmk -pdf private-generators.tex
       cd entropy
       latexmk -pdf nine_billion.tex
   Each source is standalone. The graph illustration is drawn in TikZ.

Repository baseline
   VladimirReshetnikov/ProveIt, docs/drafts, revision
   986dce91ff909ef94b12bb9553e22a719887168d.
   union_closed_frequency_bounds.zip poses the graph question and gives the
   earlier one-billion bound. The notes distinguish earlier results from
   the extensions proved here. Historical priority remains provisional.
