"""Rational certificates for the nine-billion theorem. Python 3, standard library."""
from fractions import Fraction as F


def log_interval(x):
    """Enclose ln(x) by power-of-two reduction and the atanh series."""
    x = F(x)
    if x < 1:
        low, high = log_interval(1 / x)
        return -high, -low
    exponent = 0
    while x > 2:
        exponent += 1
        x /= 2

    def reduced(value):
        z = (value - 1) / (value + 1)
        terms = 25
        low = 2 * sum(z ** k / k for k in range(1, 2 * terms, 2))
        tail = 2 * z ** (2 * terms + 1) / ((2 * terms + 1) * (1 - z*z))
        return low, low + tail

    low, high = reduced(x)
    l2, h2 = reduced(F(2))
    return low + exponent * l2, high + exponent * h2


def polynomial(s, a, q):
    target = F(".298") + min(0, s - F(".61"))
    return (-F(".62") + F("1.95")*s + F("1.5779")*a
            - (F(".7463")+q)*s*s - F(".95807")*a*(2*s+a-2*s*q) - target)


def main():
    for t, bound in [(".61", "-.49430"), (".9821", "-.01807"), ("2.56", ".94000")]:
        assert log_interval(t)[0] > F(bound)
    for s in map(F, [".505", ".61", ".619"]):
        endpoints = [polynomial(s, a, F(".39")) for a in [s*F(".39"), 1-s]]
        assert min(endpoints) > F(".00021")
        print("s =", s, "endpoint margins", *endpoints)
    assert F("1.5779")-(F("2.91614")-F("1.91614")*F(".39"))*F(".619") > 0
    assert F("1.91614")-F("2.91614")*F(".619") > 0
    assert F("1.1363") > F(".95807")*F(".22")
    assert log_interval(2)[0] - F(1, 2) > F(".193")
    # Verify reliable lower bounds for gamma and tau by squaring.
    gamma, tau = F(".381966011250"), F(".618033988749")
    assert (3-2*gamma)**2 > 5 > (2*tau+1)**2
    assert 1-gamma < F(".619")
    for size, deficit in [(100, F(8,81)), (10**5, F(".163")),
                          (9*10**9, F(".298")-F(3, 10**5))]:
        bound = gamma + tau*deficit/log_interval(size)[1]
        assert bound > F(".39")
        print("range ending at", size, "certified p >", int(bound*10**9)/10**9)
    print("All rational inequalities verified.")


if __name__ == "__main__":
    main()
