"""Check the finite incidence inequality for five exceptional generators (Python 3.10+)."""

def check(degree):
    """Columns are nonempty subsets of [5]. Cells partition the 32 generator selections."""
    high = [s for s in range(1, 32) if s.bit_count() == degree]
    low = [s for s in range(1, 32) if s.bit_count() < degree]
    types = high + low
    masks = {
        s: sum(1 << i for i in range(32) if i & s)
        for s in types
    }
    tested = equal = 0
    cutoff = 2 ** (6 - degree)

    def visit(first, cells, marks):
        nonlocal tested, equal
        for j in range(first, len(types)):
            if not marks and j >= len(high):
                break
            column = masks[types[j]]
            parts = [part for cell in cells for part in (cell & column, cell & ~column) if part]
            if len(parts) >= cutoff:
                # Each high column is absent from at most 2**(5-degree)
                # distinct rows. Further columns only refine the partition.
                continue
            current = (*marks, column) if j < len(high) else marks
            incidence = sum(sum(bool(cell & mark) for cell in parts) for mark in current)
            surplus = 2 * incidence - len(parts) * len(current)
            if surplus < 0:
                raise ArithmeticError((types[j], parts, current))
            tested += 1
            equal += surplus == 0
            visit(j + 1, parts, current)
    visit(0, [(1 << 32) - 1], ())
    return tested, equal

def closure(generators):
    family = {frozenset()}
    for g in generators:
        family.update([s | set(g) for s in family])
    return family

if __name__ == "__main__":
    for degree, expected in [(2, (5720, 240)), (3, (6900, 225))]:
        counts = check(degree)
        assert counts == expected
        print("degree, below-cutoff systems, equalities:", degree, *counts)
    six = ["xya", "xyb", "xzc", "xzd", "y", "z"]
    good = ["abcd" + t for t in "01234"]
    family = closure(six + good)
    containing_x = sum("x" in s for s in family)
    assert (containing_x, len(family)) == (114, 242)
    print("six-generator sharpness:", containing_x, "/", len(family))
