"""Exact finite checks for the prescribed-edge theorem. Standard Python 3.10+."""
from collections import defaultdict
from fractions import Fraction
from itertools import combinations, permutations

def bound(delta):
    d = delta - 1
    a = 2 ** (d*d)
    b = (1 + 2**d)**d
    q = a + b
    m = q*q + (q-1)**2 + 2*b*(q-1)
    return Fraction(2*q-1, 2*m)

def unlabelled(n):
    """Take one graph in each orbit of the S_n action on edge masks."""
    pairs = list(combinations(range(n), 2))
    edge_bit = {edge: 1 << j for j, edge in enumerate(pairs)}
    # Split edge masks into blocks of seven bits to make permutation lookup fast.
    all_actions = []
    for p in permutations(range(n)):
        images = [edge_bit[tuple(sorted((p[x], p[y])))] for x,y in pairs]
        blocks = []
        for start in range(0, len(images), 7):
            bits = images[start:start+7]
            table = [0]
            for b in bits:
                table += [v | b for v in table]
            blocks.append(table)
        all_actions.append(blocks)
    seen = bytearray(1 << len(pairs))
    for mask in range(len(seen)):
        if seen[mask]:
            continue
        indices = [(mask >> j) & 127 for j in range(0,len(pairs),7)]
        for blocks in all_actions:
            v = 0
            for b, i in zip(blocks, indices):
                v |= b[i]
            seen[v] = 1
        yield [edge for j,edge in enumerate(pairs) if mask >> j & 1]

def adjacency(n, edges):
    hood = [0] * n
    for x,y in edges:
        hood[x] |= 1 << y
        hood[y] |= 1 << x
    return hood

def unsupported(s, hood):
    return sum(1 << v for v, h in enumerate(hood) if s >> v & 1 and not s & h)

def check_graph(n, edges):
    hood = adjacency(n, edges)
    members = [s for s in range(1 << n) if not unsupported(s, hood)]
    counts = [sum(s >> v & 1 for s in members) for v in range(n)]
    tests = 0
    for x,y in edges:
        if hood[x].bit_count() == hood[y].bit_count() == 1:
            continue
        delta = max(h.bit_count() for h in hood)
        target = bound(delta)
        excess = Fraction(2*max(counts[x],counts[y])-len(members), 2*len(members))
        assert excess >= target
        if n <= 7:
            # The smallest equality component has eight vertices.
            d = delta - 1
            q = 2**(d*d) + (1 + 2**d)**d
            assert excess >= target * (1 + Fraction(1, 32*q))
        tests += 1
        endpoints = (1 << x) | (1 << y)
        roots = (hood[x] | hood[y]) & ~endpoints
        # Each base is an exterior trace when both endpoints are present.
        bases = [s & ~endpoints for s in members if s & endpoints == endpoints]
        iso = [unsupported(t, hood) for t in bases]
        for z in range(n):
            bit = 1 << z
            if not roots & bit:
                continue
            nb = hood[z] & ~endpoints
            distance_two = nb
            for w in range(n):
                if nb >> w & 1:
                    distance_two |= hood[w] & ~endpoints
            d = delta-1
            a, b = 2**(d*d), (1+2**d)**d
            if distance_two & (roots ^ bit):
                denominator = (1+2**(d-1)) * (Fraction(a,2**d)+Fraction(b,1+2**d))
            else:
                denominator = a+b
            count_iso = sum(bool(t & bit) for t in iso)
            assert count_iso * denominator >= len(bases)
            if hood[x] & hood[y] & bit:
                common_bound = Fraction(a, 2**d) + Fraction(b, 1+2**d)
                assert count_iso * common_bound >= len(bases)
            # Every restriction to sets of states is a union of exact states
            # for all the distant roots, so check the finest partition.
            far = roots & ~(bit | distance_two)
            groups = defaultdict(lambda: [0, 0, 0])
            for outside, isolated_roots in zip(bases, iso):
                key = outside & far, isolated_roots & far
                state = 2 if bit & isolated_roots else int(bool(outside & bit))
                groups[key][state] += 1
            for absent, supported, isolated in groups.values():
                assert absent <= a * isolated
                assert supported <= (b - 1) * isolated
            present = sum(bool(t & bit) for t in bases)
            assert present <= (1 << nb.bit_count())*(len(bases)-present)
        # Every prescribed exact profile decreases in multiplicity when a
        # further root is required isolated (compare with the deleted profile).
        profiles = {m:iso.count(m) for m in set(iso)}
        for m,count in profiles.items():
            for z in range(n):
                if m >> z & 1:
                    assert profiles.get(m ^ (1 << z),0) >= count
    return tests

def sharp_example(delta):
    d = delta-1
    # One entire side beyond its endpoint. Directly enumerate its induced sets.
    edges = [(0,1+i) for i in range(d)]
    edges += [(1+i, 1+d+d*i+j) for i in range(d) for j in range(d)]
    n = 1+d+d*d
    hood = adjacency(n,edges)
    both = only = absent = 0
    for s in range(1 << n):
        u = unsupported(s,hood)
        if not u & ~1:   # Only the root can use the parent.
            both += 1
            only += s & 1
            absent += u == 0
    total = both**2 + 2*only*absent + absent**2
    marked = both**2 + only*absent
    assert Fraction(marked,total) - Fraction(1,2) == bound(delta)
    return marked, total

if __name__ == "__main__":
    for n, expected in zip(range(2,8), (2,4,11,34,156,1044)):
        count = tests = 0
        for edges in unlabelled(n):
            count += 1
            tests += check_graph(n, edges)
        assert count == expected
        print(f"{n} vertices: {count} unlabelled graphs, {tests} eligible marked edges.")
    for delta in (2,3,4):
        marked, total = sharp_example(delta)
        print(f"Sharp example at degree {delta}: {marked}/{total} at each endpoint.")
