#!/usr/bin/env python3
"""Reproduce transparent schematic AST counts for five PRA presentations.

This is a syntax diagnostic, not a proof of any arithmetic equivalence.
Every counted total is obtained by traversing an explicitly built tree.
No downloaded program is imported or executed.  Python 3.10+ only.

Convention: count one node for each variable/constant occurrence, function
or schematic application, equality, logical connective, falsity, and
individual quantifier.  Expand 1 as S(0) and negation as implication to
falsity.  Trees are not DAGs: repeated subexpressions are charged again.
Universally close every computation equation and every arithmetic schema.
The formula placeholder A is counted as one application plus its explicit
arguments in the QFI row; its internal formula syntax is not charged there.
Term-only rows expand every displayed equality and disjunction.

k = number of frozen recursion parameters, excluding the active seed.
q = number of frozen parameters of the arithmetic schema.
These are independent interfaces: neither is silently identified with the
other.  Selected update bodies required by a displayed schema are charged
separately.  Proof-only auxiliary programs are not mandatory selected bodies.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    label: str
    children: tuple["Node", ...] = ()

    def size(self) -> int:
        return 1 + sum(child.size() for child in self.children)


def node(label: str, *children: Node) -> Node:
    return Node(label, tuple(children))


def forall(variables: tuple[Node, ...], body: Node) -> Node:
    for variable in reversed(variables):
        body = node("forall " + variable.label, body)
    return body


def eq(left: Node, right: Node) -> Node:
    return node("=", left, right)


def imp(left: Node, right: Node) -> Node:
    return node("implies", left, right)


def either(left: Node, right: Node) -> Node:
    return node("or", left, right)


ZERO, N, A, V = (node(name) for name in ("0", "n", "a", "v"))


def succ(value: Node) -> Node:
    return node("S", value)


def separation() -> Node:
    return imp(eq(ZERO, succ(ZERO)), node("false"))


def computation(k: int, *, swap: bool, seed_in_update: bool) -> tuple[Node, Node]:
    frozen = tuple(node(f"b{i}") for i in range(k))
    initial = forall((A,) + frozen, eq(node("R", ZERO, A, *frozen), A))
    recursive_arguments = (A, N) if swap else (N, A)
    previous = node("R", *recursive_arguments, *frozen)
    update_arguments = (N, A) if seed_in_update else (N,)
    following = node("h", *update_arguments, *frozen, previous)
    step = forall((N, A) + frozen, eq(node("R", succ(N), A, *frozen), following))
    return initial, step


def induction(q: int, *, width_two: bool) -> Node:
    parameters = tuple(node(f"c{i}") for i in range(q))

    def matrix(value: Node) -> Node:
        if not width_two:
            return node("A_formula", value, *parameters)
        terms = [node(name, value, *parameters) for name in ("s", "t", "u", "v")]
        return either(eq(terms[0], terms[1]), eq(terms[2], terms[3]))

    premise = node("and", matrix(ZERO), forall((N,), imp(matrix(N), matrix(succ(N)))))
    return forall(parameters, imp(premise, forall((N,), matrix(N))))


def zero_anchored(q: int) -> Node:
    parameters = tuple(node(f"c{i}") for i in range(q))

    def equation(value: Node) -> Node:
        return eq(node("s", value, *parameters), node("t", value, *parameters))

    anchored = either(eq(N, ZERO), equation(N))
    premise = forall((N,), imp(anchored, equation(succ(N))))
    return forall(parameters, imp(premise, forall((N,), anchored)))


def fresh_comparison(q: int, *, inline_successor: bool) -> Node:
    parameters = tuple(node(f"c{i}") for i in range(q))

    def f(value: Node) -> Node:
        return node("f", value, *parameters)

    stationary = forall((N,), eq(f(succ(N)), f(N)))
    if inline_successor:
        first = eq(node("C", node("D", A, f(ZERO)), f(ZERO), A), A)
        second = eq(succ(f(N)), A)
    else:
        first = eq(node("T", f(ZERO), A), A)
        second = eq(f(N), A)
    conclusion = forall((A, N), either(first, second))
    return forall(parameters, imp(stationary, conclusion))


def helper_bodies(*, inline_successor: bool) -> tuple[Node, ...]:
    # C: h = b; D: h = v; T: h = C(D(a,n),n,a).
    basic = (node("b"), V)
    return basic if inline_successor else basic + (node("C", node("D", A, N), N, A),)


def row(name: str, k: int, q: int) -> dict[str, object]:
    if name in ("qfi_formula_schema", "two_equation_induction", "zero_anchored_equation"):
        equations = computation(k, swap=False, seed_in_update=False)
        if name == "zero_anchored_equation":
            schema = zero_anchored(q)
        else:
            schema = induction(q, width_two=name == "two_equation_induction")
        helpers: tuple[Node, ...] = ()
    elif name in ("fresh_probe_comparator", "fresh_inline_successor"):
        inline = name == "fresh_inline_successor"
        equations = computation(k, swap=True, seed_in_update=not inline)
        schema = fresh_comparison(q, inline_successor=inline)
        helpers = helper_bodies(inline_successor=inline)
    else:
        raise ValueError(name)
    base, step = (tree.size() for tree in equations)
    ground, arithmetic = separation().size(), schema.size()
    bodies = sum(tree.size() for tree in helpers)
    displayed = base + step + ground + arithmetic
    return {
        "presentation": name,
        "frozen_recursion_parameters_k": k,
        "arithmetic_parameters_q": q,
        "computation_base": base,
        "computation_step": step,
        "separation": ground,
        "arithmetic_schema": arithmetic,
        "displayed_total": displayed,
        "selected_helper_bodies": bodies,
        "display_plus_selected_bodies": displayed + bodies,
    }


PRESENTATIONS = (
    "qfi_formula_schema",
    "two_equation_induction",
    "fresh_probe_comparator",
    "zero_anchored_equation",
    "fresh_inline_successor",
)


def affine_coefficients(name: str, field: str) -> dict[str, int]:
    # Infer the displayed affine formula from AST counts at (0,0),(1,0),(0,1),
    # then independently verify it on a larger rectangle.  Coefficients and
    # totals are not entered as inputs to any count.
    constant = int(row(name, 0, 0)[field])
    k_coefficient = int(row(name, 1, 0)[field]) - constant
    q_coefficient = int(row(name, 0, 1)[field]) - constant
    for k in range(7):
        for q in range(7):
            assert row(name, k, q)[field] == constant + k_coefficient * k + q_coefficient * q
    return {"constant": constant, "k": k_coefficient, "q": q_coefficient}


def results() -> dict[str, object]:
    profiles = [row(name, 0, q) for q in range(3) for name in PRESENTATIONS]
    formulas = {
        name: {
            field: affine_coefficients(name, field)
            for field in ("displayed_total", "selected_helper_bodies", "display_plus_selected_bodies")
        }
        for name in PRESENTATIONS
    }
    differences = []
    for q in range(5):
        anchored = int(row("zero_anchored_equation", 0, q)["display_plus_selected_bodies"])
        comparator = int(row("fresh_probe_comparator", 0, q)["display_plus_selected_bodies"])
        inline = int(row("fresh_inline_successor", 0, q)["display_plus_selected_bodies"])
        differences.append({
            "q": q,
            "zero_anchored_minus_fresh_probe": anchored - comparator,
            "zero_anchored_minus_fresh_inline_successor": anchored - inline,
        })
    return {
        "status": "passed",
        "scope": "Exact finite template AST accounting only; not a theorem of global minimality or a proof-assistant certificate.",
        "node_convention": "One node per leaf, application, equality, connective, falsity, and individual quantifier. Negation is implication to falsity; 1 is S0. Trees are unshared and universally closed.",
        "parameters": {"k": "Frozen recursion parameters, excluding the seed.", "q": "Frozen parameters of the arithmetic schema; independent of k."},
        "formula_placeholders": "Only qfi_formula_schema counts a whole quantifier-free matrix as the schematic application A_formula(n,c). All other rows expand their displayed equality/disjunction matrices.",
        "profiles_k0_q0_to_q2": profiles,
        "affine_formulas_from_AST_counts": formulas,
        "verified_parameter_rectangle": {"k_min": 0, "k_max": 6, "q_min": 0, "q_max": 6},
        "differences_at_fixed_k": differences,
        "interpretation": [
            "The zero-anchored basis has no mandatory designated helper descriptions in its axiom display and uses ordinary initialized recursion.",
            "The fresh-probe comparator uses initialized swap recursion and three designated helper bodies C,D,T.",
            "The fresh inline-successor variant combines the fresh-variable restriction with the inline two-helper comparison; it is included as a separate variant, not mislabeled as a pre-existing draft total.",
            "The QFI formula-placeholder row and the fully expanded term-schema rows have different schema grammars; their raw totals do not establish an encoding-independent ranking.",
            "The zero-anchored row is one node smaller than the fresh-probe row when q=0, but one node larger when q=1 and grows two additional nodes per arithmetic parameter.",
            "The fresh inline-successor row has a smaller partial ledger than the zero-anchored row for every displayed q; the zero-anchored recommendation rests on its simpler ordinary-recursion proof and restricted induction form.",
            "These ledgers omit complete syntax enumerators, binding encodings, and proof length. They are not total theory description lengths.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_suffix(".json"))
    arguments = parser.parse_args()
    output = results()
    arguments.output.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": output["status"],
        "output": str(arguments.output.resolve()),
        "totals_at_k0": {
            name: [row(name, 0, q)["display_plus_selected_bodies"] for q in range(3)]
            for name in PRESENTATIONS
        },
    }, indent=2))


if __name__ == "__main__":
    main()
