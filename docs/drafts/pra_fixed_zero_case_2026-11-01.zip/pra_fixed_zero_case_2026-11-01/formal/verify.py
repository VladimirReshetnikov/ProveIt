#!/usr/bin/env python3
"""Recheck the zero-anchored arithmetic kernel with Lean 4.19."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("--lean", default="lean", help="Lean executable")
args = parser.parse_args()
root = Path(__file__).resolve().parent
source = root / "ZeroAnchored.lean"
version = subprocess.run([args.lean, "--version"], capture_output=True,
                         text=True, check=True).stdout.strip()
result = subprocess.run([args.lean, str(source)], capture_output=True,
                        text=True, cwd=root)
output = result.stdout + result.stderr
(root / "ZeroAnchored.log").write_text(output)
endpoints = [line for line in output.splitlines()
             if "does not depend on any axioms" in line]
record = {
    "compiler_version": version,
    "returncode": result.returncode,
    "source_file": source.name,
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "log_sha256": hashlib.sha256(output.encode()).hexdigest(),
    "axiom_free_endpoints": endpoints,
    "expected_endpoint_count": 16,
    "scope_file": "SCOPE.txt",
    "interpretation": "Conditional kernel theorem over explicit Basis fields; "
                      "not an end-to-end first-order bi-interpretation certificate."
}
(root / "verification.json").write_text(json.dumps(record, indent=2) + "\n")
print(output, end="")
if result.returncode != 0:
    raise SystemExit(result.returncode)
if len(endpoints) != 16 or "sorryAx" in output or "Classical.choice" in output:
    raise SystemExit("Unexpected proof-dependency report")
print("Verified 16 endpoints with no global Lean axiom dependencies.")
