PRA WITH A FIXED ZERO CASE
Research package for Vladimir Reshetnikov, 1 November 2026

START HERE

pra_fixed_zero_case.pdf is the complete mathematical report.
pra_fixed_zero_case.tex is its standalone editable LaTeX source.
AXIOMS.txt states both theories without TeX notation.

MAIN RESULT

With initialized ordinary recursion and 0 != S0, it suffices to use

  [forall n ((n=0 OR E(n)) -> E(Sn))]
       -> forall n (n=0 OR E(n)),

where E(n) is any equation s(n,c)=t(n,c), with arbitrary finite parameters.
This scheme is constructively equivalent to equation induction plus
constructor coverage, and to full quantifier-free induction.

The key proof uses two independent recursive counters and two separate
equation inductions to recover native equality reflection. It removes
the previous drafts' disjunctive comparison induction. Both classical
and intuitionistic versions have explicit whole-domain bi-interpretations
with matching first-order PRA and internally proved identity round trips.

SECOND RESULT AND HONEST COUNTS

Combining the current fresh-probe interface with the current inline
successor comparison gives a 52-node partial subtotal, versus 54 in the
reviewed fresh-comparator basis, at zero frozen schema parameters.
The main fixed-zero basis has subtotal 53 at that profile. Its main
advantage is a substantially simpler restricted induction specification
and ordinary-recursion proof, not the least subtotal among all variants.
Against the expanded two-equation induction basis, it saves 24+10q nodes
at every frozen-parameter count q (94 to 60 at q=1).

The report gives all parameter-dependent counts. The ordinary full-QFI
formula-placeholder basis remains shorter in a different schema grammar.
No finite axiom list or global shortestness theorem is asserted.

CONTENTS

pra_fixed_zero_case.tex / .pdf   Complete manuscript and compiled PDF
AXIOMS.txt                      Exact standalone specifications
build.py                        Offline build/check entry point
formal/ZeroAnchored.lean         Verified constructive arithmetic kernel
formal/ZeroAnchored.log          Sixteen successful global-axiom audits
formal/verification.json         Compiler version and exact source/log hashes
formal/verify.py                 Reproducible Lean verification
formal/SCOPE.txt                 Formalization assumptions and limits
formal/lean-toolchain            Lean 4.19.0
artifacts/schema_metrics.py      Actual-AST partial size calculation
artifacts/schema_metrics.json    Reproducible exact count results
audit/source_manifest.json       Six pinned input archives and source hashes
audit/validation.json            Build and PDF inspection record
MANIFEST.sha256                  Release payload hashes

REBUILD

Python 3 and a standard TeX Live installation are sufficient:
  python3 build.py

To rerun just the exact syntax checks:
  python3 build.py --checks-only

To rebuild just the PDF:
  python3 build.py --pdf-only

To additionally replay the Lean kernel with Lean 4.19.0 installed:
  python3 build.py --lean /absolute/path/to/lean

There are no Python third-party dependencies. TeX uses the standard
packages listed in its preamble. No network access or shell escape is
needed. Temporary LaTeX output goes under _build. The PDF is copied to
the package root only after a successful build.

Before rebuilding, the delivered bytes can be checked with:
  sha256sum -c MANIFEST.sha256

Rebuilding may change PDF metadata and validation logs, so it may change
release checksums without changing the mathematical contents.

VERIFICATION BOUNDARY

The Lean kernel is checked over an arbitrary carrier, with explicit
admitted-term closure, selected recursion equations, separation, and the
exact fixed-zero schema. It assumes no induction over arbitrary carrier
predicates, uses no classical axioms, and has no placeholders. Its sixteen
audited endpoints have no global Lean axiom dependencies; the Basis
assumptions remain explicit parameters.

The complete syntax generator, both PRA compilers, first-order proof
translation, and the identity round trips are proved in the manuscript,
not claimed as an end-to-end proof-assistant formalization. The optional
52-node result uses the cited successor-comparison draft's theorem,
together with the completely proved fresh-variable transformation.

PROVENANCE

All six current docs/drafts archives were reviewed at ProveIt commit
9db1e0b1a625767ac54321715f5669d75002360e. The source manifest records
immutable URLs and checked Git blob/SHA-256 hashes. Original archives
are not duplicated and their scripts were not run. The Lean kernel
adapts, with attribution, the prior initialized-induction kernel and
replaces its central induction assumption and comparison proof.

The manuscript includes Further research questions. In particular, the
older coverage-plus-stationary-constancy proposal remains unproved;
the new theorem must not be substituted across that remaining gap.
