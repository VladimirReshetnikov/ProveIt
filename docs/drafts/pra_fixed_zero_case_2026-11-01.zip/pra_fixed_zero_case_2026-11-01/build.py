#!/usr/bin/env python3
"""Rebuild the delivered checks and PDF without network or shell escape."""
from __future__ import annotations
import argparse
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent


def run(args: list[str], cwd: pathlib.Path = ROOT) -> None:
    subprocess.run(args, cwd=cwd, check=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--checks-only', action='store_true')
    mode.add_argument('--pdf-only', action='store_true')
    parser.add_argument('--lean', help='Optional path to a Lean 4.19.0 executable')
    args = parser.parse_args()
    if not args.pdf_only:
        run([sys.executable, str(ROOT / 'artifacts' / 'schema_metrics.py')])
    if args.lean:
        lean = str(pathlib.Path(args.lean).resolve())
        run([sys.executable, str(ROOT / 'formal' / 'verify.py'), '--lean', lean])
    if not args.checks_only:
        compiler = shutil.which('pdflatex')
        if compiler is None:
            raise SystemExit('pdflatex is required to rebuild the PDF.')
        build = ROOT / '_build'
        build.mkdir(exist_ok=True)
        command = [compiler, '-interaction=nonstopmode', '-halt-on-error',
                   '-no-shell-escape', '-output-directory=' + str(build),
                   str(ROOT / 'pra_fixed_zero_case.tex')]
        for _ in range(3):
            result = subprocess.run(command, cwd=ROOT, text=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            (build / 'console.log').write_text(result.stdout)
            if result.returncode:
                print(result.stdout)
                raise SystemExit(result.returncode)
        log = (build / 'pra_fixed_zero_case.log').read_text()
        failures = ['Overfull \\hbox', 'Overfull \\vbox', 'undefined references',
                    'undefined citations', 'Rerun to get cross-references right']
        if any(marker in log for marker in failures):
            raise SystemExit('LaTeX requires attention; inspect _build/pra_fixed_zero_case.log')
        shutil.copy2(build / 'pra_fixed_zero_case.pdf', ROOT / 'pra_fixed_zero_case.pdf')
        print('PDF built successfully; no overfull boxes or unresolved references.')


if __name__ == '__main__':
    main()
