#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
cd -- "$(dirname -- "$0")"
python3 artifacts/check_two_step.py > audit/two_step_certificates.json
python3 artifacts/schema_metrics.py > audit/schema_metrics.json
bash formal/check.sh
printf '%s\n' 'All syntax, formula-metric, and Lean checks passed.'
