#!/usr/bin/env python3
"""Exact formula-tree metrics. Admission algorithms and program bodies excluded.

One node per variable/constant/application/equality/connective/quantifier.
Negation is implication to bottom. Quantifier names are metadata.
Schematic term applications have the induction input and one parameter.
"""
import json
from collections import Counter


def node(kind, *children):
    return (kind, *children)


def counts(t):
    result = Counter({t[0]: 1})
    for child in t[1:]:
        result.update(counts(child))
    return result


def main():
    n, a, z = node("variable"), node("variable"), node("constant")
    succ = lambda t: node("function", t)
    eq = lambda s, t: node("equality", s, t)
    imp = lambda s, t: node("implies", s, t)
    con = lambda s, t: node("and", s, t)
    dis = lambda s, t: node("or", s, t)
    all_ = lambda t: node("forall", t)
    f = lambda t: node("function", t, a)
    g = lambda t: node("function", t, a)
    E = lambda t: eq(f(t), g(t))
    guard = lambda t: dis(eq(t, z), E(t))
    sep = imp(eq(z, succ(z)), node("bottom"))
    guarded_step = all_(imp(guard(n), E(succ(n))))
    positive_step = all_(imp(E(n), E(succ(n))))
    positive_out = all_(guard(n))
    schemas = [
        ("existing_G_plus_separation", [all_(imp(guarded_step, positive_out)), sep],
         42, 6, 4, None),
        ("existing_packaged_K", [all_(imp(guarded_step, con(sep, positive_out)))],
         43, 6, 3, None),
        ("existing_PB3", [all_(imp(positive_step, con(sep, positive_out)))],
         39, 5, 3, 3),
        ("new_PB2", [all_(imp(positive_step, con(sep, positive_out)))],
         39, 5, 3, 2),
        ("new_PB2_separated", [all_(imp(positive_step, positive_out)), sep],
         38, 5, 4, 2),
    ]
    rows = []
    for name, formulas, expected_nodes, expected_eq, templates, bound in schemas:
        total = Counter()
        for formula in formulas:
            total.update(counts(formula))
        assert sum(total.values()) == expected_nodes, (name, total)
        assert total["equality"] == expected_eq, (name, total)
        rows.append({
            "name": name,
            "AST_nodes": sum(total.values()),
            "equality_occurrences": total["equality"],
            "templates_including_two_computation_templates": templates,
            "rewrite_bound_per_side": bound,
            "counts_by_kind": dict(sorted(total.items())),
            "formula_trees": formulas,
        })
    print(json.dumps({"status": "all assertions passed", "scope": __doc__,
                      "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
