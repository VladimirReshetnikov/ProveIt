#!/usr/bin/env python3
"""Raw computation certificates for the two-step PRA presentation.

The term representation and finite rewrite engine below are adapted from
ProveIt pra_positive_base_2026-10-31/artifacts/check_rewrites.py, pinned in
audit/source_manifest.json. New cases certify the two-step bootstrap.
The checker is syntactic and does not prove the full equivalence theorem.

Python 3.10+, standard library only. Run: python3 check_rewrites.py

This is a syntactic certificate checker and demonstration. It does not
enumerate arithmetic models or claim to prove PRA equivalence. Its only
computation rules are the two displayed rules for a declared seed iterator:

    I_h(0, a)    -> a
    I_h(S n, a)  -> h(n, I_h(n, a)).

Macros p(x) and B(x,y) are expanded to seed calls before counting steps.
The symbol u is an opaque binary application representing a term context.
No rule is supplied for u. Admission certificates discard its entire
application and are therefore uniform for every expanded earlier term.
The helper-identity traces work at this schematic application level:
their step counts are not asserted to be uniform when an expanded term
duplicates an argument. The identities themselves transport through any
term context by equality congruence.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import json
from typing import Iterator, Union


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    arg: Term


@dataclass(frozen=True)
class SeedCall:
    name: str
    index: Term
    initial: Term


@dataclass(frozen=True)
class OpaqueApp:
    name: str
    args: tuple[Term, ...]


Term = Union[Var, Zero, Succ, SeedCall, OpaqueApp]
ZERO = Zero()
ONE = Succ(ZERO)


@dataclass(frozen=True)
class SeedDeclaration:
    name: str
    step: Term


def children(term: Term) -> tuple[Term, ...]:
    if isinstance(term, Succ):
        return (term.arg,)
    if isinstance(term, SeedCall):
        return (term.index, term.initial)
    if isinstance(term, OpaqueApp):
        return term.args
    return ()


def rebuild(term: Term, parts: tuple[Term, ...]) -> Term:
    if isinstance(term, Succ):
        return Succ(parts[0])
    if isinstance(term, SeedCall):
        return SeedCall(term.name, parts[0], parts[1])
    if isinstance(term, OpaqueApp):
        return OpaqueApp(term.name, parts)
    if parts:
        raise ValueError("A leaf cannot acquire children")
    return term


def substitute(term: Term, values: dict[str, Term]) -> Term:
    if isinstance(term, Var):
        return values.get(term.name, term)
    return rebuild(term, tuple(substitute(c, values) for c in children(term)))


def free_variables(term: Term) -> set[str]:
    if isinstance(term, Var):
        return {term.name}
    result: set[str] = set()
    for child in children(term):
        result.update(free_variables(child))
    return result


def show(term: Term) -> str:
    if isinstance(term, Var):
        return term.name
    if isinstance(term, Zero):
        return "0"
    if isinstance(term, Succ):
        return "S(" + show(term.arg) + ")"
    if isinstance(term, SeedCall):
        return f"{term.name}({show(term.index)}, {show(term.initial)})"
    if isinstance(term, OpaqueApp):
        return f"{term.name}(" + ", ".join(map(show, term.args)) + ")"
    raise TypeError(term)


def check_step_term(term: Term, earlier: set[str]) -> None:
    if not free_variables(term) <= {"n", "v"}:
        raise ValueError("A seed update has a forbidden free variable")
    if isinstance(term, OpaqueApp):
        raise ValueError("Opaque placeholders are not seed declarations")
    if isinstance(term, SeedCall) and term.name not in earlier:
        raise ValueError("A seed update uses a symbol not previously declared")
    for child in children(term):
        check_step_term(child, earlier)


class RewriteSystem:
    def __init__(self, declarations: tuple[SeedDeclaration, ...]):
        self.declarations: dict[str, SeedDeclaration] = {}
        for declaration in declarations:
            if declaration.name in self.declarations:
                raise ValueError("Duplicate seed declaration")
            check_step_term(declaration.step, set(self.declarations))
            self.declarations[declaration.name] = declaration

    def root_reduct(self, term: Term) -> tuple[Term, str] | None:
        if not isinstance(term, SeedCall):
            return None
        declaration = self.declarations.get(term.name)
        if declaration is None:
            raise ValueError("Undeclared seed call: " + term.name)
        if isinstance(term.index, Zero):
            return term.initial, term.name + ":zero"
        if isinstance(term.index, Succ):
            previous = SeedCall(term.name, term.index.arg, term.initial)
            return substitute(
                declaration.step, {"n": term.index.arg, "v": previous}
            ), term.name + ":successor"
        return None

    def one_steps(self, term: Term) -> Iterator[tuple[Term, tuple[int, ...], str]]:
        root = self.root_reduct(term)
        if root is not None:
            yield root[0], (), root[1]
        parts = children(term)
        for position, child in enumerate(parts):
            for next_child, child_path, rule in self.one_steps(child):
                next_parts = parts[:position] + (next_child,) + parts[position + 1 :]
                yield rebuild(term, next_parts), (position,) + child_path, rule

    def reachable(self, start: Term, bound: int) -> dict[Term, list[dict]]:
        if bound < 0:
            raise ValueError("The rewrite bound must be nonnegative")
        paths: dict[Term, list[dict]] = {start: []}
        queue = deque([start])
        while queue:
            current = queue.popleft()
            trace = paths[current]
            if len(trace) == bound:
                continue
            for nxt, position, rule in self.one_steps(current):
                if nxt in paths:
                    continue
                paths[nxt] = trace + [{
                    "rule": rule,
                    "position": list(position),
                    "before": show(current),
                    "after": show(nxt),
                }]
                queue.append(nxt)
        return paths

    def certificate(self, start: Term, target: Term, bound: int) -> dict:
        reached = self.reachable(start, bound)
        if target not in reached:
            raise AssertionError(
                f"No certificate within {bound}: {show(start)} -> {show(target)}"
            )
        trace = reached[target]
        # Replay every step against the exact local rewrite relation.
        current = start
        for entry in trace:
            choices = [
                nxt for nxt, pos, rule in self.one_steps(current)
                if list(pos) == entry["position"] and rule == entry["rule"]
                and show(nxt) == entry["after"]
            ]
            if len(choices) != 1:
                raise AssertionError("Ambiguous or invalid certificate replay")
            current = choices[0]
        if current != target:
            raise AssertionError("Certificate does not end at its claimed target")
        return {
            "start": show(start),
            "target": show(target),
            "steps": len(trace),
            "bound": bound,
            "trace": trace,
        }

    def common_reduct(self, left: Term, right: Term, bound: int) -> dict:
        left_paths = self.reachable(left, bound)
        right_paths = self.reachable(right, bound)
        shared = set(left_paths) & set(right_paths)
        if not shared:
            return {"admitted": False, "bound_per_side": bound}
        target = min(shared, key=lambda t: (
            len(left_paths[t]) + len(right_paths[t]), show(t)
        ))
        return {
            "admitted": True,
            "bound_per_side": bound,
            "common_reduct": show(target),
            "left": self.certificate(left, target, bound),
            "right": self.certificate(right, target, bound),
        }


def predecessor(term: Term) -> Term:
    return SeedCall("I_counter", term, ZERO)


def gate(index: Term, initial: Term) -> Term:
    return SeedCall("I_zero", index, initial)


def mask(index: Term, value: Term) -> Term:
    return gate(gate(index, ONE), value)


def opaque_u(index: Term, parameter: Term, name: str = "u") -> Term:
    return OpaqueApp(name, (index, parameter))


def padding(index: Term, parameter: Term, name: str = "u") -> Term:
    return mask(predecessor(index),
                opaque_u(predecessor(predecessor(index)), parameter, name))


def delay(index: Term, parameter: Term) -> Term:
    return mask(index, opaque_u(predecessor(index), parameter))


