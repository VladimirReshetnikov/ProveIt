#!/usr/bin/env python3
"""Reproduce and replay the raw two-step admission certificates.

All macros are expanded to initialized iterator calls. No derived equation
is used as a rewrite. The new proof uses four fixed pairs and the literal
reflexivity family for constant-target induction. Python 3.10+, no packages.
"""
from __future__ import annotations

import json
from check_rewrites import (
    Var, Succ, SeedCall, SeedDeclaration, RewriteSystem, ZERO, ONE,
    OpaqueApp, predecessor, gate, padding, show,
)


def add(x, y):
    return SeedCall("I_add", x, y)


def monus(x, y):
    return SeedCall("I_monus", x, y)


def pad_constant(n, value):
    return gate(gate(predecessor(n), ONE), value)


def main():
    system = RewriteSystem((
        SeedDeclaration("I_counter", Var("n")),
        SeedDeclaration("I_zero", ZERO),
        SeedDeclaration("I_add", Succ(Var("v"))),
        SeedDeclaration("I_monus", predecessor(Var("v"))),
    ))
    a = Var("a")
    fixed = [
        ("constructor_coverage", ONE, Succ(predecessor(ONE)), (0, 1)),
        ("addition_right_zero", add(ONE, ZERO), ONE, (2, 0)),
        ("addition_right_successor", add(ONE, Succ(a)),
         Succ(add(ONE, a)), (2, 2)),
        ("predecessor_commutation", monus(ONE, predecessor(a)),
         predecessor(monus(ONE, a)), (2, 2)),
    ]
    certificates = {}
    for name, left, right, expected in fixed:
        cert = system.common_reduct(left, right, 2)
        assert cert["admitted"], name
        actual = (cert["left"]["steps"], cert["right"]["steps"])
        assert actual == expected, (name, actual, expected)
        certificates[name] = cert

    # At n=1 this family is literally reflexive. There is no reduction
    # inside u and no assumption about how many times u uses its argument.
    common = OpaqueApp("u", (predecessor(ONE), a))
    constant_target = system.common_reduct(common, common, 0)
    assert constant_target["admitted"]
    assert constant_target["left"]["steps"] == 0
    assert constant_target["right"]["steps"] == 0

    # The old padding is genuinely not admitted at budget two, even for
    # the concrete constant terms 0 and 1. This is a finite exhaustive
    # syntactic check for these two terms, not a global lower bound.
    old_left = pad_constant(ONE, ZERO)
    old_right = pad_constant(ONE, ONE)
    rejected_old_padding = system.common_reduct(old_left, old_right, 2)
    accepted_old_padding = system.common_reduct(old_left, old_right, 3)
    assert not rejected_old_padding["admitted"]
    assert accepted_old_padding["admitted"]
    assert accepted_old_padding["left"]["steps"] == 3
    assert accepted_old_padding["right"]["steps"] == 3

    # This alternative orientation is NOT a two-step certificate. The
    # selected commutation pair above avoids counting a derived shortcut.
    direct_shift_left = predecessor(monus(ONE, Succ(a)))
    direct_shift_right = monus(ONE, a)
    direct_two = system.common_reduct(direct_shift_left, direct_shift_right, 2)
    direct_three = system.common_reduct(direct_shift_left, direct_shift_right, 3)
    assert not direct_two["admitted"]
    assert direct_three["admitted"]

    malformed_rejected = False
    try:
        RewriteSystem((SeedDeclaration("bad", Var("a")),))
    except ValueError:
        malformed_rejected = True
    assert malformed_rejected

    report = {
        "artifact": "PRA from two computation steps: syntactic certificates",
        "status": "all assertions passed",
        "scope": "Finite raw term rewriting, not a semantic model test or a full proof checker",
        "counting": "One D0 or DS equation applied at one tree address is one rewrite",
        "declarations": [
            {"name": d.name, "step": show(d.step)}
            for d in system.declarations.values()
        ],
        "four_fixed_pairs": certificates,
        "constant_target_family_at_one": constant_target,
        "old_concrete_padding_rejected_at_two": rejected_old_padding,
        "old_concrete_padding_admitted_at_three": accepted_old_padding,
        "direct_shift_orientation_rejected_at_two": direct_two,
        "direct_shift_orientation_at_three": direct_three,
        "forbidden_frozen_parameter_rejected": malformed_rejected,
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
