# Two Computation Steps Suffice for Primitive Recursive Arithmetic

This research package gives a common nonlogical axiomatization for classical
and intuitionistic PRA and proves an improvement over the strongest current
ProveIt draft: **two raw computation rewrites per side suffice where its
positive-base presentation used three**. The restricted binary-iteration
language, one-parameter limit, and five-equality arithmetic formula are
unchanged. The reduction is in the admission bound; no absolute minimality
claim is made.

Start with `0`, `S`, and variables. For each earlier finite term `h(n,v)`
with only those two variables free, introduce a binary iterator `I_h` with
the universally closed computation equations

```text
I_h(0,a)  = a
I_h(Sn,a) = h(n,I_h(n,a)).
```

For `E(n,a) := f(n,a) = g(n,a)`, admit the arithmetic schema

```text
forall a, (forall n, E(n,a) -> E(Sn,a))
          -> (0 != 1 and forall n, n = 0 or E(n,a)),
```

exactly when `f(1,a)` and `g(1,a)` have a common literal reduct in at most
two raw defining-equation rewrites **on each side**. The update term cannot
refer separately to the iterator's initial parameter. All syntactic
abbreviations are expanded before counting rewrites. These are two
computation templates and one arithmetic template, not three individual
axioms in a finite signature.

Use classical first-order equality logic for classical PRA and intuitionistic
first-order equality logic for intuitionistic PRA. The paper also states the
corresponding native quantifier-free sequent rule. It proves the equivalence
for each logic separately; it does not identify their full first-order
consequences.

## Main proof

A delayed equation is literally reflexive at one and yields induction toward
a fixed target with zero boundary rewrites. Three fixed two-step instances
then establish the required addition and subtraction identities. Two
fixed-target inductions prove complementarity and reversed reconstruction,
which reflect native equality in an arbitrary model. Only then is general
quantifier-free induction recovered. Internally verified tuple coding and a
state simulation recover arbitrary parameters and ordinary primitive
recursion. The result is a conservative definitional equivalence with PRA,
not merely equiconsistency or agreement in the standard natural numbers.

The one-rewrite variant remains unresolved. The paper does not reduce the
arithmetic formula below five equality occurrences and does not remove Shift
from the older one-term guarded presentation. An appendix gives a separate
binary-digit coding result for that older presentation.

## Contents

- `pra_two_steps.pdf`: complete paper.
- `pra_two_steps.tex` and `sections/*.tex`: editable LaTeX sources.
- `formal/*.lean`: five Lean 4 certificates, including the connected equality
  bootstrap and the separate binary-coding appendix.
- `formal/README.md`: exact hypotheses, dependencies, and formalization scope.
- `formal/*.check.txt` and `formal/*.log`: successful compiler/axiom audits.
- `artifacts/check_two_step.py`: checks the raw bounded-rewrite certificates,
  the old padding counterexamples, and a disallowed frozen-parameter update.
- `artifacts/check_rewrites.py`: finite term/rewrite engine, adapted from the
  supplied positive-base draft with attribution retained in the source.
- `artifacts/schema_metrics.py`: constructs and counts the actual formula
  trees used in the comparison.
- `audit/*.json`: certificates, exact formula metrics, source identities, and
  verification summary; `audit/check_output.txt`: combined successful check.
- `SHA256SUMS`: hashes for the packaged files, excluding the manifest itself.
- `build.sh` and `check.sh`: reproducible build and verification entry points.

## Reproduce

The Python checks require Python 3.10 or later and no external packages.
The Lean certificates were checked with Lean **4.19.0**, without Mathlib.
Run from this directory:

```sh
python3 artifacts/check_two_step.py
python3 artifacts/schema_metrics.py
LEAN=/absolute/path/to/lean bash check.sh
```

If the intended Lean executable is already on `PATH`, use `bash check.sh`.
The script compiles the imported modules in a temporary directory and leaves
no compiled Lean modules in the package. To rebuild the PDF with a standard
TeX Live installation containing the packages listed in the preamble:

```sh
bash build.sh
```

This runs `latexmk`/`pdflatex` in a temporary output directory and writes the
finished `pra_two_steps.pdf` beside its source. The supplied PDF was compiled
and every rendered page visually inspected. To verify the packaged hashes,
run `sha256sum -c SHA256SUMS` before regenerating any reports or the PDF.

## Verification boundary

`formal/Bootstrap.lean` connects the constructor, fixed-target induction,
subtraction, and reconstruction certificates. It proves native equality
reflection and decidability from explicit computation equations and exactly
nine named positive-base instances. These nine suffice for that bootstrap;
the later recovery of arbitrary induction uses the infinite delayed-instance
family. Across the five files, all **51** printed declarations have no
global Lean axiom dependencies. Their arithmetic and local-schema
hypotheses remain explicit theorem inputs.

The complete object-language grammar, general formula compiler, tuple
coding, and conservative-extension theorem have written mathematical proofs
in the paper. They are **not** claimed as fully formalized Lean theorems.
The independent Python checker validates finite raw syntactic certificates,
not numerical experiments masquerading as proof. There are no `sorry` or
`admit` proof placeholders.

## Source snapshot and attribution

The comparison uses all six draft ZIP archives at ProveIt commit
`cb7be7c1b0b39cc05b1d54a3001e54b1159cc000`. The source manifest records their
paths, immutable URLs, Git blob identities, and SHA-256 hashes. The incoming
directory inventory and its index were inspected; no additional PRA-labelled
entry was found. Unrelated Busy Beaver archives were not unpacked.

The initialized-iteration grammar, positive-base schema, and several coding
ideas come from the supplied drafts. The new contribution relative to those
drafts is the two-rewrite completeness proof, especially its fixed-target
native-equality bootstrap. The appendix's binary-digit argument is a separate
partial result. The package makes no exhaustive historical-priority claim.

The paper includes primary references and links to every compared archive.
