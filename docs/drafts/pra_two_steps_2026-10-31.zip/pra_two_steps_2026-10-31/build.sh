#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
build_dir="$(mktemp -d)"
trap 'rm -rf -- "$build_dir"' EXIT
latexmk -pdf -interaction=nonstopmode -halt-on-error \
  -outdir="$build_dir" pra_two_steps.tex
cp -- "$build_dir/pra_two_steps.pdf" pra_two_steps.pdf
