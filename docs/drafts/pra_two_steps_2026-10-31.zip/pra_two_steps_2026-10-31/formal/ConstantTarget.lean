import Lean

/-!
# Constant-target induction from positive-base propagation

All carriers below are arbitrary. No theorem invokes induction on natural
numbers, classical equality, excluded middle, or an equality oracle.

`PositiveBaseInstance zero succ E` is an assumption for ONE specified
instance of the arithmetic schema. It is not a postulate for all Lean
predicates. Likewise `ConstantTargetInstance` names one induction formula.
In the intended syntactic application every displayed function is the
interpretation of a finite term, with at most one fixed numerical parameter.

For a term t(n,a), the delayed equation

  t(p(n),a) = t(p(S0),a)

is literally reflexive at n = S0. Its positive base therefore has a
zero-rewrite certificate regardless of the size or form of t. Constructor
coverage transfers its propagation premise to the desired constant-target
induction step. The conclusion is evaluated at Sx.

The raw certificates at the end check the two addition instances used in
the bootstrap. The defining addition equations are

  A(0,a) = a,    A(Sn,a) = S(A(n,a)).

Thus A(S0,0) -> S(A(0,0)) -> S0, and both sides of
  A(S0,Sa) = S(A(S0,a))
reach SSa in exactly two raw defining rewrites each.
-/

namespace ConstantTarget

universe u

def PositiveBaseInstance {A : Type u} (zero : A) (succ : A → A)
    (matrix : A → Prop) : Prop :=
  (∀ n, matrix n → matrix (succ n)) →
    (zero ≠ succ zero ∧ ∀ n, n = zero ∨ matrix n)

def ConstantTargetInstance {A : Type u} (zero : A) (succ : A → A)
    (term : A → A) (target : A) : Prop :=
  term zero = target →
    (∀ n, term n = target → term (succ n) = target) →
    ∀ n, term n = target

/-- The one-rewrite-admitted predecessor instance supplies coverage. -/
theorem constructor_coverage {A : Type u} (zero : A) (succ pred : A → A)
    (pred_succ : ∀ n, pred (succ n) = n)
    (positive_base : PositiveBaseInstance zero succ
      (fun n => n = succ (pred n))) :
    zero ≠ succ zero ∧ ∀ n, n = zero ∨ n = succ (pred n) := by
  apply positive_base
  intro n _
  exact (congrArg succ (pred_succ n)).symm

theorem successor_injective {A : Type u} (succ pred : A → A)
    (pred_succ : ∀ n, pred (succ n) = n) :
    ∀ x y, succ x = succ y → x = y := by
  intro x y equality
  exact (pred_succ x).symm.trans
    ((congrArg pred equality).trans (pred_succ y))

theorem successor_nonzero {A : Type u} (zero : A) (succ pred : A → A)
    (pred_zero : pred zero = zero)
    (pred_succ : ∀ n, pred (succ n) = n)
    (separated : zero ≠ succ zero) :
    ∀ n, succ n ≠ zero := by
  intro n equality
  have n_zero : n = zero :=
    (pred_succ n).symm.trans ((congrArg pred equality).trans pred_zero)
  apply separated
  exact equality.symm.trans (congrArg succ n_zero)

theorem zero_decidability {A : Type u} (zero : A) (succ pred : A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (nonzero_succ : ∀ n, succ n ≠ zero) :
    ∀ n, n = zero ∨ n ≠ zero := by
  intro n
  cases coverage n with
  | inl is_zero => exact Or.inl is_zero
  | inr is_successor =>
    apply Or.inr
    intro is_zero
    exact nonzero_succ (pred n) (is_successor.symm.trans is_zero)

/-- Remove the zero exception when the actual zero case is available. -/
theorem close_zero_case {A : Type u} (zero : A) (succ : A → A)
    (matrix : A → Prop)
    (positive_base : PositiveBaseInstance zero succ matrix)
    (base : matrix zero)
    (step : ∀ n, matrix n → matrix (succ n)) :
    ∀ n, matrix n := by
  intro n
  cases (positive_base step).2 n with
  | inl is_zero =>
    subst n
    exact base
  | inr established => exact established

/-- The delayed reflexive-base instance proves constant-target induction. -/
theorem induction_from_delayed_instance {A : Type u}
    (zero : A) (succ pred : A → A)
    (pred_zero : pred zero = zero)
    (pred_succ : ∀ n, pred (succ n) = n)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (term : A → A) (target : A)
    (positive_base : PositiveBaseInstance zero succ
      (fun n => term (pred n) = term (pred (succ zero)))) :
    ConstantTargetInstance zero succ term target := by
  intro base step
  have anchor : term (pred (succ zero)) = target :=
    (congrArg term (pred_succ zero)).trans base
  have recover : ∀ n,
      term (pred n) = term (pred (succ zero)) →
      term n = term (pred (succ zero)) := by
    intro n current
    cases coverage n with
    | inl is_zero =>
      subst n
      exact base.trans anchor.symm
    | inr is_successor =>
      have at_pred : term (pred n) = target := current.trans anchor
      have at_successor : term (succ (pred n)) = target := step (pred n) at_pred
      exact (congrArg term is_successor).trans
        (at_successor.trans anchor.symm)
  have propagate : ∀ n,
      term (pred n) = term (pred (succ zero)) →
      term (pred (succ n)) = term (pred (succ zero)) := by
    intro n current
    exact (congrArg term (pred_succ n)).trans (recover n current)
  have conclusion := positive_base propagate
  have no_zero := successor_nonzero zero succ pred pred_zero pred_succ conclusion.1
  intro n
  cases conclusion.2 (succ n) with
  | inl impossible => exact False.elim (no_zero n impossible)
  | inr established =>
    exact (congrArg term (pred_succ n)).symm.trans (established.trans anchor)

/-! The fixed addition instances need no general induction theorem. -/

theorem addition_right_zero {A : Type u} (zero : A) (succ : A → A)
    (add : A → A → A)
    (add_zero : ∀ a, add zero a = a)
    (add_succ : ∀ n a, add (succ n) a = succ (add n a))
    (positive_base : PositiveBaseInstance zero succ (fun n => add n zero = n)) :
    ∀ n, add n zero = n := by
  apply close_zero_case zero succ (fun n => add n zero = n) positive_base
  · exact add_zero zero
  · intro n current
    exact (add_succ n zero).trans (congrArg succ current)

theorem addition_right_successor {A : Type u} (zero : A) (succ : A → A)
    (add : A → A → A)
    (add_zero : ∀ a, add zero a = a)
    (add_succ : ∀ n a, add (succ n) a = succ (add n a))
    (positive_base : ∀ a, PositiveBaseInstance zero succ
      (fun n => add n (succ a) = succ (add n a))) :
    ∀ n a, add n (succ a) = succ (add n a) := by
  intro n a
  apply close_zero_case zero succ
    (fun k => add k (succ a) = succ (add k a)) (positive_base a) ?_ ?_ n
  · exact (add_zero (succ a)).trans (congrArg succ (add_zero a)).symm
  · intro k current
    calc
      add (succ k) (succ a) = succ (add k (succ a)) := add_succ k (succ a)
      _ = succ (succ (add k a)) := congrArg succ current
      _ = succ (add (succ k) a) := (congrArg succ (add_succ k a)).symm

/-! The actual selector term, rather than an assumed decision operator. -/

def computedSelector {A : Type u} (zero : A) (succ : A → A)
    (add gate : A → A → A) (x left right : A) : A :=
  add (gate x left) (gate (gate x (succ zero)) right)

theorem selector_zero {A : Type u} (zero : A) (succ : A → A)
    (add gate : A → A → A)
    (gate_zero : ∀ a, gate zero a = a)
    (gate_succ : ∀ n a, gate (succ n) a = zero)
    (add_zero_right : ∀ n, add n zero = n) :
    ∀ left right, computedSelector zero succ add gate zero left right = left := by
  intro left right
  change add (gate zero left) (gate (gate zero (succ zero)) right) = left
  calc
    add (gate zero left) (gate (gate zero (succ zero)) right) =
        add left (gate (gate zero (succ zero)) right) :=
      congrArg (fun v => add v (gate (gate zero (succ zero)) right)) (gate_zero left)
    _ = add left (gate (succ zero) right) :=
      congrArg (fun v => add left (gate v right)) (gate_zero (succ zero))
    _ = add left zero := congrArg (add left) (gate_succ zero right)
    _ = left := add_zero_right left

theorem selector_successor {A : Type u} (zero : A) (succ : A → A)
    (add gate : A → A → A)
    (gate_zero : ∀ a, gate zero a = a)
    (gate_succ : ∀ n a, gate (succ n) a = zero)
    (add_zero_left : ∀ a, add zero a = a) :
    ∀ n left right,
      computedSelector zero succ add gate (succ n) left right = right := by
  intro n left right
  change add (gate (succ n) left) (gate (gate (succ n) (succ zero)) right) = right
  calc
    add (gate (succ n) left) (gate (gate (succ n) (succ zero)) right) =
        add zero (gate (gate (succ n) (succ zero)) right) :=
      congrArg (fun v => add v (gate (gate (succ n) (succ zero)) right))
        (gate_succ n left)
    _ = add zero (gate zero right) :=
      congrArg (fun v => add zero (gate v right)) (gate_succ n (succ zero))
    _ = add zero right := congrArg (add zero) (gate_zero right)
    _ = right := add_zero_left right

/-! Three constant-target instances establish the required monus facts. -/

theorem monus_right_zero {A : Type u} (zero : A) (succ pred : A → A)
    (monus : A → A → A)
    (pred_zero : pred zero = zero)
    (monus_zero : ∀ a, monus zero a = a)
    (monus_succ : ∀ n a, monus (succ n) a = pred (monus n a))
    (induct : ConstantTargetInstance zero succ (fun n => monus n zero) zero) :
    ∀ n, monus n zero = zero := by
  apply induct
  · exact monus_zero zero
  · intro n current
    exact (monus_succ n zero).trans ((congrArg pred current).trans pred_zero)

theorem monus_diagonal {A : Type u} (zero : A) (succ : A → A)
    (monus : A → A → A)
    (monus_zero : ∀ a, monus zero a = a)
    (shift : ∀ n a, monus (succ n) (succ a) = monus n a)
    (induct : ConstantTargetInstance zero succ (fun n => monus n n) zero) :
    ∀ n, monus n n = zero := by
  apply induct
  · exact monus_zero zero
  · intro n current
    exact (shift n n).trans current

theorem monus_successor_diagonal {A : Type u} (zero : A) (succ : A → A)
    (monus : A → A → A)
    (monus_zero : ∀ a, monus zero a = a)
    (shift : ∀ n a, monus (succ n) (succ a) = monus n a)
    (induct : ConstantTargetInstance zero succ
      (fun n => monus n (succ n)) (succ zero)) :
    ∀ n, monus n (succ n) = succ zero := by
  apply induct
  · exact monus_zero (succ zero)
  · intro n current
    exact (shift n (succ n)).trans current

namespace RawAddition

inductive Term where
  | zero : Term
  | parameter : Term
  | succ : Term → Term
  | add : Term → Term → Term
  deriving DecidableEq, Repr

open Term

inductive Rewrite : Term → Term → Prop where
  | add_zero (a) : Rewrite (add zero a) a
  | add_succ (n a) : Rewrite (add (succ n) a) (succ (add n a))
  | in_succ {s t} : Rewrite s t → Rewrite (succ s) (succ t)
  | in_add_left {s t} (a) : Rewrite s t → Rewrite (add s a) (add t a)
  | in_add_right (a) {s t} : Rewrite s t → Rewrite (add a s) (add a t)

def TwoRewrites (s t : Term) : Prop :=
  ∃ middle, Rewrite s middle ∧ Rewrite middle t

theorem right_zero_base : TwoRewrites (add (succ zero) zero) (succ zero) := by
  exact ⟨succ (add zero zero), Rewrite.add_succ zero zero,
    Rewrite.in_succ (Rewrite.add_zero zero)⟩

theorem right_succ_base_left :
    TwoRewrites (add (succ zero) (succ parameter)) (succ (succ parameter)) := by
  exact ⟨succ (add zero (succ parameter)), Rewrite.add_succ zero (succ parameter),
    Rewrite.in_succ (Rewrite.add_zero (succ parameter))⟩

theorem right_succ_base_right :
    TwoRewrites (succ (add (succ zero) parameter)) (succ (succ parameter)) := by
  exact ⟨succ (succ (add zero parameter)),
    Rewrite.in_succ (Rewrite.add_succ zero parameter),
    Rewrite.in_succ (Rewrite.in_succ (Rewrite.add_zero parameter))⟩

end RawAddition

#print axioms constructor_coverage
#print axioms successor_injective
#print axioms successor_nonzero
#print axioms zero_decidability
#print axioms close_zero_case
#print axioms induction_from_delayed_instance
#print axioms addition_right_zero
#print axioms addition_right_successor
#print axioms selector_zero
#print axioms selector_successor
#print axioms monus_right_zero
#print axioms monus_diagonal
#print axioms monus_successor_diagonal
#print axioms RawAddition.right_zero_base
#print axioms RawAddition.right_succ_base_left
#print axioms RawAddition.right_succ_base_right

end ConstantTarget
