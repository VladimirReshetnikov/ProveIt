/-
Binary coding before subtraction Shift: a constructive auxiliary certificate.
Lean 4.19.0; standalone, with no imports.

The carrier A is arbitrary. No natural-number induction, arithmetic on Nat,
decidable equality, or Classical namespace is used for this carrier.

The record Arithmetic exposes constructor coverage and the computation laws
for zero test, selector, parity, halving, and doubling. These operations are
the initialized-iteration descriptions given in the accompanying paper.
Their formation in that description grammar is not formalized here.

The record InductionInputs supplies exactly three induction instances:
  * identity-target induction for half(double(n)) = n;
  * zero-equation induction for parity(double(n)) = 0;
  * identity-target induction for binary reconstruction.
It does not quantify an induction principle over all semantic predicates.
Each of the three displayed functions is a term in the stated grammar.

The current one-term guarded schema derives Cov, J, ZI, and the selector
without Shift. That earlier derivation is a dependency of the mathematical
application, not re-certified in this independent file. This file certifies
the new binary-coding implication once those exact instances are provided.

No general pairing of two numbers, native-equality comparator, subtraction
Shift, or full equivalence with PRA is asserted by this certificate.
-/

namespace BinaryCodingWithoutShift

universe u

structure Arithmetic (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  separation : zero ≠ succ zero
  coverage : ∀ n, n = zero ∨ n = succ (pred n)
  zeroTest : A → A
  zeroTest_zero : zeroTest zero = succ zero
  zeroTest_succ : ∀ n, zeroTest (succ n) = zero
  select : A → A → A → A
  select_zero : ∀ x y, select zero x y = x
  select_succ : ∀ n x y, select (succ n) x y = y
  parity : A → A
  parity_zero : parity zero = zero
  parity_succ : ∀ n, parity (succ n) = zeroTest (parity n)
  half : A → A
  half_zero : half zero = zero
  half_succ : ∀ n, half (succ n) = select (parity n) (half n) (succ (half n))
  double : A → A
  double_zero : double zero = zero
  double_succ : ∀ n, double (succ n) = succ (succ (double n))

variable {A : Type u} (C : Arithmetic A)

/-- One explicit identity-target induction instance. -/
def IdentityInduction (f : A → A) : Prop :=
  f C.zero = C.zero →
  (∀ n, f n = n → f (C.succ n) = C.succ n) →
  ∀ n, f n = n

/-- One explicit zero-equation induction instance. -/
def ZeroInduction (f : A → A) : Prop :=
  f C.zero = C.zero →
  (∀ n, f n = C.zero → f (C.succ n) = C.zero) →
  ∀ n, f n = C.zero

def reconstruct (n : A) : A :=
  C.select (C.parity n) (C.double (C.half n))
    (C.succ (C.double (C.half n)))

/-- Only the three term instances actually used below. -/
structure InductionInputs : Prop where
  half_double : IdentityInduction C (fun n => C.half (C.double n))
  parity_double : ZeroInduction C (fun n => C.parity (C.double n))
  reconstruction : IdentityInduction C (reconstruct C)

theorem zeroTest_range (n : A) :
    C.zeroTest n = C.zero ∨ C.zeroTest n = C.succ C.zero := by
  rcases C.coverage n with hz | hs
  · rw [hz, C.zeroTest_zero]
    exact Or.inr rfl
  · rw [hs, C.zeroTest_succ]
    exact Or.inl rfl

theorem parity_range (n : A) :
    C.parity n = C.zero ∨ C.parity n = C.succ C.zero := by
  rcases C.coverage n with hz | hs
  · rw [hz, C.parity_zero]
    exact Or.inl rfl
  · rw [hs, C.parity_succ]
    exact zeroTest_range C _

theorem parity_two_successors (n : A) :
    C.parity (C.succ (C.succ n)) = C.parity n := by
  rcases parity_range C n with hz | ho
  · rw [C.parity_succ, C.parity_succ, hz, C.zeroTest_zero, C.zeroTest_succ]
  · rw [C.parity_succ, C.parity_succ, ho, C.zeroTest_succ, C.zeroTest_zero]

theorem half_two_successors (n : A) :
    C.half (C.succ (C.succ n)) = C.succ (C.half n) := by
  rcases parity_range C n with hz | ho
  · rw [C.half_succ, C.parity_succ, hz, C.zeroTest_zero, C.select_succ,
      C.half_succ, hz, C.select_zero]
  · rw [C.half_succ, C.parity_succ, ho, C.zeroTest_succ, C.select_zero,
      C.half_succ, ho, C.select_succ]

theorem half_double (I : InductionInputs C) (n : A) :
    C.half (C.double n) = n := by
  apply I.half_double
  · change C.half (C.double C.zero) = C.zero
    rw [C.double_zero, C.half_zero]
  · intro k ih
    change C.half (C.double k) = k at ih
    change C.half (C.double (C.succ k)) = C.succ k
    rw [C.double_succ, half_two_successors, ih]

theorem parity_double (I : InductionInputs C) (n : A) :
    C.parity (C.double n) = C.zero := by
  apply I.parity_double
  · change C.parity (C.double C.zero) = C.zero
    rw [C.double_zero, C.parity_zero]
  · intro k ih
    change C.parity (C.double k) = C.zero at ih
    change C.parity (C.double (C.succ k)) = C.zero
    rw [C.double_succ, parity_two_successors, ih]

theorem half_successor_double (I : InductionInputs C) (n : A) :
    C.half (C.succ (C.double n)) = n := by
  rw [C.half_succ, parity_double C I, C.select_zero, half_double C I]

theorem parity_successor_double (I : InductionInputs C) (n : A) :
    C.parity (C.succ (C.double n)) = C.succ C.zero := by
  rw [C.parity_succ, parity_double C I, C.zeroTest_zero]

theorem reconstruction (I : InductionInputs C) (n : A) :
    reconstruct C n = n := by
  apply I.reconstruction
  · change C.select (C.parity C.zero) (C.double (C.half C.zero))
      (C.succ (C.double (C.half C.zero))) = C.zero
    rw [C.parity_zero, C.half_zero, C.double_zero, C.select_zero]
  · intro k ih
    rcases parity_range C k with hz | ho
    · have ihEven : C.double (C.half k) = k := by
        change C.select (C.parity k) (C.double (C.half k))
          (C.succ (C.double (C.half k))) = k at ih
        rw [hz, C.select_zero] at ih
        exact ih
      change C.select (C.parity (C.succ k)) (C.double (C.half (C.succ k)))
        (C.succ (C.double (C.half (C.succ k)))) = C.succ k
      rw [C.parity_succ, hz, C.zeroTest_zero, C.select_succ,
        C.half_succ, hz, C.select_zero]
      exact congrArg C.succ ihEven
    · have ihOdd : C.succ (C.double (C.half k)) = k := by
        change C.select (C.parity k) (C.double (C.half k))
          (C.succ (C.double (C.half k))) = k at ih
        rw [ho, C.select_succ] at ih
        exact ih
      change C.select (C.parity (C.succ k)) (C.double (C.half (C.succ k)))
        (C.succ (C.double (C.half (C.succ k)))) = C.succ k
      rw [C.parity_succ, ho, C.zeroTest_succ, C.select_zero,
        C.half_succ, ho, C.select_succ, C.double_succ]
      exact congrArg C.succ ihOdd

theorem binary_decomposition (I : InductionInputs C) (n : A) :
    n = C.double (C.half n) ∨ n = C.succ (C.double (C.half n)) := by
  rcases parity_range C n with hz | ho
  · apply Or.inl
    have hr := reconstruction C I n
    change C.select (C.parity n) (C.double (C.half n))
      (C.succ (C.double (C.half n))) = n at hr
    rw [hz, C.select_zero] at hr
    exact hr.symm
  · apply Or.inr
    have hr := reconstruction C I n
    change C.select (C.parity n) (C.double (C.half n))
      (C.succ (C.double (C.half n))) = n at hr
    rw [ho, C.select_succ] at hr
    exact hr.symm

theorem even_reflection (I : InductionInputs C) (n : A) :
    C.parity n = C.zero ↔ n = C.double (C.half n) := by
  constructor
  · intro hz
    have hr := reconstruction C I n
    change C.select (C.parity n) (C.double (C.half n))
      (C.succ (C.double (C.half n))) = n at hr
    rw [hz, C.select_zero] at hr
    exact hr.symm
  · intro hn
    exact (congrArg C.parity hn).trans (parity_double C I (C.half n))

theorem odd_reflection (I : InductionInputs C) (n : A) :
    C.parity n = C.succ C.zero ↔ n = C.succ (C.double (C.half n)) := by
  constructor
  · intro ho
    have hr := reconstruction C I n
    change C.select (C.parity n) (C.double (C.half n))
      (C.succ (C.double (C.half n))) = n at hr
    rw [ho, C.select_succ] at hr
    exact hr.symm
  · intro hn
    exact (congrArg C.parity hn).trans (parity_successor_double C I (C.half n))

theorem even_injective (I : InductionInputs C) {x y : A}
    (h : C.double x = C.double y) : x = y := by
  have hh := congrArg C.half h
  rw [half_double C I, half_double C I] at hh
  exact hh

theorem odd_injective (I : InductionInputs C) {x y : A}
    (h : C.succ (C.double x) = C.succ (C.double y)) : x = y := by
  have hh := congrArg C.half h
  rw [half_successor_double C I, half_successor_double C I] at hh
  exact hh

theorem tags_disjoint (I : InductionInputs C) (x y : A) :
    C.double x ≠ C.succ (C.double y) := by
  intro h
  have hp := congrArg C.parity h
  rw [parity_double C I, parity_successor_double C I] at hp
  exact C.separation hp

#print axioms zeroTest_range
#print axioms parity_range
#print axioms parity_two_successors
#print axioms half_two_successors
#print axioms half_double
#print axioms parity_double
#print axioms half_successor_double
#print axioms parity_successor_double
#print axioms reconstruction
#print axioms binary_decomposition
#print axioms even_reflection
#print axioms odd_reflection
#print axioms even_injective
#print axioms odd_injective
#print axioms tags_disjoint

end BinaryCodingWithoutShift
