import ConstantTarget
import TwoStepShift
import PBTwoReflection

/-!
# Composing the constructive PB2 bootstrap

This file connects the three companion certificates. The inputs are raw
computation equations and nine explicitly displayed positive-base instances:
four fixed admitted pairs, three delayed monus instances, and two delayed
selector terms. The latter five use the same zero-rewrite admission pattern.

There is no assumption of general induction, induction for all semantic
predicates, a universal family of semantic functions, decidable native
equality, or a primitive selector. The selector is the actual gate/addition
term. Native equality reflection and equality decidability follow from the
listed inputs over any carrier.

The file verifies composition of the mathematical bootstrap. It does not
formalize the complete infinite PR-description grammar or the subsequent
formula compiler, pairing, and conservative definitional-extension theorem.
-/

namespace Bootstrap

universe u

structure Computations (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  pred_zero : pred zero = zero
  pred_succ : ∀ n, pred (succ n) = n
  gate : A → A → A
  gate_zero : ∀ a, gate zero a = a
  gate_succ : ∀ n a, gate (succ n) a = zero
  add : A → A → A
  add_zero : ∀ a, add zero a = a
  add_succ : ∀ n a, add (succ n) a = succ (add n a)
  monus : A → A → A
  monus_zero : ∀ a, monus zero a = a
  monus_succ : ∀ n a, monus (succ n) a = pred (monus n a)

variable {A : Type u}

def selectTerm (B : Computations A) : A → A → A → A :=
  ConstantTarget.computedSelector B.zero B.succ B.add B.gate

def complementaryTerm (B : Computations A) (n a : A) : A :=
  selectTerm B (B.monus n a) a (B.add n (B.monus n a))

def reconstructionTerm (B : Computations A) (n a : A) : A :=
  selectTerm B (B.monus n a) (B.monus (B.monus a n) n) a

def delayedMatrix (B : Computations A) (term : A → A) (n : A) : Prop :=
  term (B.pred n) = term (B.pred (B.succ B.zero))

/-- Each field is one specified finite-term instance, with parameters shown. -/
structure PositiveInstances (B : Computations A) : Prop where
  constructor_pair : ConstantTarget.PositiveBaseInstance B.zero B.succ
    (fun n => n = B.succ (B.pred n))
  addition_zero_pair : ConstantTarget.PositiveBaseInstance B.zero B.succ
    (fun n => B.add n B.zero = n)
  addition_successor_pair : ∀ a,
    ConstantTarget.PositiveBaseInstance B.zero B.succ
      (fun n => B.add n (B.succ a) = B.succ (B.add n a))
  monus_commutation_pair :
    TwoStepShift.CommutationInstance B.zero B.succ B.monus B.pred
  monus_zero_delayed : ConstantTarget.PositiveBaseInstance B.zero B.succ
    (delayedMatrix B (fun n => B.monus n B.zero))
  monus_diagonal_delayed : ConstantTarget.PositiveBaseInstance B.zero B.succ
    (delayedMatrix B (fun n => B.monus n n))
  monus_adjacent_delayed : ConstantTarget.PositiveBaseInstance B.zero B.succ
    (delayedMatrix B (fun n => B.monus n (B.succ n)))
  complementary_delayed : ∀ a, ConstantTarget.PositiveBaseInstance B.zero B.succ
    (delayedMatrix B (fun n => complementaryTerm B n a))
  reconstruction_delayed : ∀ a, ConstantTarget.PositiveBaseInstance B.zero B.succ
    (delayedMatrix B (fun n => reconstructionTerm B n a))

theorem constructors (B : Computations A) (I : PositiveInstances B) :
    B.zero ≠ B.succ B.zero ∧
      ∀ n, n = B.zero ∨ n = B.succ (B.pred n) :=
  ConstantTarget.constructor_coverage B.zero B.succ B.pred B.pred_succ
    I.constructor_pair

/-- This is a proved metatheorem; it assumes only its one supplied instance. -/
theorem delayed_induction (B : Computations A) (I : PositiveInstances B)
    (term : A → A) (target : A)
    (admitted : ConstantTarget.PositiveBaseInstance B.zero B.succ
      (delayedMatrix B term)) :
    ConstantTarget.ConstantTargetInstance B.zero B.succ term target :=
  ConstantTarget.induction_from_delayed_instance B.zero B.succ B.pred
    B.pred_zero B.pred_succ (constructors B I).2 term target admitted

/-- Every field of the reflection certificate is derived from the listed inputs. -/
def derivedArithmetic (B : Computations A) (I : PositiveInstances B) :
    PBTwoReflection.Arithmetic A := by
  let ctor := constructors B I
  let add_right_zero := ConstantTarget.addition_right_zero B.zero B.succ
    B.add B.add_zero B.add_succ I.addition_zero_pair
  let add_right_succ := ConstantTarget.addition_right_successor B.zero B.succ
    B.add B.add_zero B.add_succ I.addition_successor_pair
  let shift := TwoStepShift.subtraction_shift B.zero B.succ B.pred B.monus
    B.pred_succ B.monus_zero B.monus_succ I.monus_commutation_pair
  exact {
    zero := B.zero
    succ := B.succ
    pred := B.pred
    separation := ctor.1
    pred_zero := B.pred_zero
    pred_succ := B.pred_succ
    coverage := ctor.2
    zero_decision := ConstantTarget.zero_decidability B.zero B.succ B.pred
      ctor.2 (ConstantTarget.successor_nonzero B.zero B.succ B.pred
        B.pred_zero B.pred_succ ctor.1)
    select := selectTerm B
    select_zero := ConstantTarget.selector_zero B.zero B.succ B.add B.gate
      B.gate_zero B.gate_succ add_right_zero
    select_succ := ConstantTarget.selector_successor B.zero B.succ B.add B.gate
      B.gate_zero B.gate_succ B.add_zero
    add := B.add
    zero_add := B.add_zero
    add_zero := add_right_zero
    succ_add := B.add_succ
    add_succ := add_right_succ
    monus := B.monus
    monus_zero := B.monus_zero
    monus_succ := B.monus_succ
    monus_zero_right := ConstantTarget.monus_right_zero B.zero B.succ B.pred
      B.monus B.pred_zero B.monus_zero B.monus_succ
      (delayed_induction B I (fun n => B.monus n B.zero) B.zero I.monus_zero_delayed)
    monus_shift := shift
    monus_diagonal := ConstantTarget.monus_diagonal B.zero B.succ B.monus
      B.monus_zero shift
      (delayed_induction B I (fun n => B.monus n n) B.zero I.monus_diagonal_delayed)
    monus_adjacent := ConstantTarget.monus_successor_diagonal B.zero B.succ B.monus
      B.monus_zero shift
      (delayed_induction B I (fun n => B.monus n (B.succ n)) (B.succ B.zero)
        I.monus_adjacent_delayed)
  }

theorem derivedInductionInputs (B : Computations A) (I : PositiveInstances B) :
    PBTwoReflection.InductionInputs (derivedArithmetic B I) := by
  constructor
  · intro a
    change ConstantTarget.ConstantTargetInstance B.zero B.succ
      (fun n => complementaryTerm B n a) a
    exact delayed_induction B I (fun n => complementaryTerm B n a) a
      (I.complementary_delayed a)
  · intro a
    change ConstantTarget.ConstantTargetInstance B.zero B.succ
      (fun n => reconstructionTerm B n a) a
    exact delayed_induction B I (fun n => reconstructionTerm B n a) a
      (I.reconstruction_delayed a)

def errorTerm (B : Computations A) (x y : A) : A :=
  selectTerm B (B.monus x y) (B.monus y x) (B.succ B.zero)

/-- Native equality reflection from raw computations and named PB2 instances. -/
theorem native_equality_reflection (B : Computations A) (I : PositiveInstances B)
    (x y : A) : errorTerm B x y = B.zero ↔ x = y := by
  exact PBTwoReflection.error_zero_iff (derivedArithmetic B I)
    (derivedInductionInputs B I) x y

/-- Equality decidability is an output of the bootstrap, not an input. -/
theorem native_equality_decidable (B : Computations A) (I : PositiveInstances B)
    (x y : A) : x = y ∨ x ≠ y :=
  PBTwoReflection.equality_decidable (derivedArithmetic B I)
    (derivedInductionInputs B I) x y

#print axioms constructors
#print axioms delayed_induction
#print axioms derivedArithmetic
#print axioms derivedInductionInputs
#print axioms native_equality_reflection
#print axioms native_equality_decidable

end Bootstrap
