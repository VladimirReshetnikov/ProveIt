/-
Native equality reflection from two constant-target induction instances.
Lean 4.19.0; standalone, with no imports.

This certificate checks the new complementary-reconstruction argument over
an arbitrary carrier. The only induction inputs are the two explicit
constant-target instances in InductionInputs. General equation induction,
induction for all semantic predicates, decidable native equality, and
classical logic are not assumed.

The record Arithmetic lists the constructor, selector, addition, and monus
facts used in this argument. Their derivation from the two-step admitted
positive-base schema is a separate dependency, addressed by the manuscript
and the companion certificates. In particular, this file explicitly takes
monus Shift, its zero and diagonal identities, and zero decidability as
inputs; it does not claim to derive them independently.

The final error_zero_iff and equality_decidable theorems recover the
carrier's native equality, not merely an intended numerical comparison.
-/

namespace PBTwoReflection

universe u

structure Arithmetic (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  separation : zero ≠ succ zero
  pred_zero : pred zero = zero
  pred_succ : ∀ n, pred (succ n) = n
  coverage : ∀ n, n = zero ∨ n = succ (pred n)
  zero_decision : ∀ n, n = zero ∨ n ≠ zero
  select : A → A → A → A
  select_zero : ∀ x y, select zero x y = x
  select_succ : ∀ n x y, select (succ n) x y = y
  add : A → A → A
  zero_add : ∀ n, add zero n = n
  add_zero : ∀ n, add n zero = n
  succ_add : ∀ n a, add (succ n) a = succ (add n a)
  add_succ : ∀ n a, add n (succ a) = succ (add n a)
  monus : A → A → A
  monus_zero : ∀ a, monus zero a = a
  monus_succ : ∀ n a, monus (succ n) a = pred (monus n a)
  monus_zero_right : ∀ n, monus n zero = zero
  monus_shift : ∀ n a, monus (succ n) (succ a) = monus n a
  monus_diagonal : ∀ n, monus n n = zero
  monus_adjacent : ∀ n, monus n (succ n) = succ zero

variable {A : Type u} (C : Arithmetic A)

/-- One supplied constant-target induction instance, for a displayed term. -/
def ConstantTargetInduction (f : A → A → A) : Prop :=
  ∀ a, f C.zero a = a →
    (∀ n, f n a = a → f (C.succ n) a = a) →
    ∀ n, f n a = a

def complementaryTerm (n a : A) : A :=
  C.select (C.monus n a) a (C.add n (C.monus n a))

def reconstructionTerm (n a : A) : A :=
  C.select (C.monus n a) (C.monus (C.monus a n) n) a

/-- Exactly the two term instances needed in this certificate. -/
structure InductionInputs : Prop where
  complementary : ConstantTargetInduction C (complementaryTerm C)
  reconstruction : ConstantTargetInduction C (reconstructionTerm C)

theorem select_nonzero {n : A} (hn : n ≠ C.zero) (x y : A) :
    C.select n x y = y := by
  rcases C.coverage n with hz | hs
  · exact False.elim (hn hz)
  · rw [hs, C.select_succ]

theorem select_same (n x : A) : C.select n x x = x := by
  rcases C.zero_decision n with hz | hn
  · rw [hz, C.select_zero]
  · exact select_nonzero C hn x x

theorem monus_pred_shift (n a : A) :
    C.pred (C.monus n (C.succ a)) = C.monus n a := by
  calc
    C.pred (C.monus n (C.succ a)) = C.monus (C.succ n) (C.succ a) :=
      (C.monus_succ n (C.succ a)).symm
    _ = C.monus n a := C.monus_shift n a

theorem complementary_identity (I : InductionInputs C) (n a : A) :
    complementaryTerm C n a = a := by
  apply I.complementary a
  · change C.select (C.monus C.zero a) a
      (C.add C.zero (C.monus C.zero a)) = a
    rw [C.monus_zero, C.zero_add]
    exact select_same C a a
  · intro k ih
    change C.select (C.monus k a) a (C.add k (C.monus k a)) = a at ih
    change C.select (C.monus (C.succ k) a) a
      (C.add (C.succ k) (C.monus (C.succ k) a)) = a
    rcases C.zero_decision (C.monus (C.succ k) a) with hz | hn
    · rw [hz, C.select_zero]
    · have hrNonzero : C.monus k a ≠ C.zero := by
        intro hr
        have hzNext : C.monus (C.succ k) a = C.zero := by
          rw [C.monus_succ, hr, C.pred_zero]
        exact hn hzNext
      have hrSucc : C.monus k a = C.succ (C.monus (C.succ k) a) := by
        rcases C.coverage (C.monus k a) with hr | hs
        · exact False.elim (hrNonzero hr)
        · exact hs.trans (congrArg C.succ (C.monus_succ k a).symm)
      rw [select_nonzero C hrNonzero] at ih
      rw [select_nonzero C hn]
      calc
        C.add (C.succ k) (C.monus (C.succ k) a) =
            C.succ (C.add k (C.monus (C.succ k) a)) := C.succ_add _ _
        _ = C.add k (C.succ (C.monus (C.succ k) a)) :=
          (C.add_succ _ _).symm
        _ = C.add k (C.monus k a) := congrArg (C.add k) hrSucc.symm
        _ = a := ih

theorem complementarity (I : InductionInputs C) (n a : A)
    (hn : C.monus n a ≠ C.zero) : C.add n (C.monus n a) = a := by
  have h := complementary_identity C I n a
  change C.select (C.monus n a) a (C.add n (C.monus n a)) = a at h
  rw [select_nonzero C hn] at h
  exact h

theorem reconstruction_identity (I : InductionInputs C) (n a : A) :
    reconstructionTerm C n a = a := by
  apply I.reconstruction a
  · change C.select (C.monus C.zero a)
      (C.monus (C.monus a C.zero) C.zero) a = a
    rw [C.monus_zero, C.monus_zero_right]
    rcases C.zero_decision a with hz | hn
    · rw [hz, C.select_zero]
    · exact select_nonzero C hn C.zero a
  · intro k ih
    change C.select (C.monus k a) (C.monus (C.monus a k) k) a = a at ih
    change C.select (C.monus (C.succ k) a)
      (C.monus (C.monus a (C.succ k)) (C.succ k)) a = a
    rcases C.zero_decision (C.monus (C.succ k) a) with hzNext | hnNext
    · rw [hzNext, C.select_zero]
      rcases C.zero_decision (C.monus k a) with hz | hn
      · rw [hz, C.select_zero] at ih
        have huNonzero : C.monus a (C.succ k) ≠ C.zero := by
          intro huZero
          have hu := monus_pred_shift C a k
          rw [huZero, C.pred_zero] at hu
          have hk : k = a := by
            have hi := ih
            rw [hu.symm, C.monus_zero] at hi
            exact hi
          have huOne : C.monus a (C.succ k) = C.succ C.zero := by
            rw [← hk, C.monus_adjacent]
          exact C.separation (huZero.symm.trans huOne)
        have huSucc : C.monus a (C.succ k) = C.succ (C.monus a k) := by
          rcases C.coverage (C.monus a (C.succ k)) with huZero | huSucc
          · exact False.elim (huNonzero huZero)
          · exact huSucc.trans (congrArg C.succ (monus_pred_shift C a k))
        calc
          C.monus (C.monus a (C.succ k)) (C.succ k) =
              C.monus (C.succ (C.monus a k)) (C.succ k) :=
            congrArg (fun v => C.monus v (C.succ k)) huSucc
          _ = C.monus (C.monus a k) k := C.monus_shift _ _
          _ = a := ih
      · have hc := complementarity C I k a hn
        have hpZero : C.pred (C.monus k a) = C.zero :=
          (C.monus_succ k a).symm.trans hzNext
        have hrOne : C.monus k a = C.succ C.zero := by
          rcases C.coverage (C.monus k a) with hrZero | hrSucc
          · exact False.elim (hn hrZero)
          · exact hrSucc.trans (congrArg C.succ hpZero)
        have hk : C.succ k = a := by
          calc
            C.succ k = C.succ (C.add k C.zero) :=
              congrArg C.succ (C.add_zero k).symm
            _ = C.add k (C.succ C.zero) := (C.add_succ k C.zero).symm
            _ = C.add k (C.monus k a) := congrArg (C.add k) hrOne.symm
            _ = a := hc
        have huZero : C.monus a (C.succ k) = C.zero := by
          rw [hk, C.monus_diagonal]
        rw [huZero, C.monus_zero]
        exact hk
    · exact select_nonzero C hnNext _ a

theorem mutual_zero_reflects_equality (I : InductionInputs C) (x y : A)
    (hxy : C.monus x y = C.zero) (hyx : C.monus y x = C.zero) : x = y := by
  have h := reconstruction_identity C I x y
  change C.select (C.monus x y) (C.monus (C.monus y x) x) y = y at h
  rw [hxy, C.select_zero, hyx, C.monus_zero] at h
  exact h

theorem mutual_zero_iff (I : InductionInputs C) (x y : A) :
    (C.monus x y = C.zero ∧ C.monus y x = C.zero) ↔ x = y := by
  constructor
  · intro h
    exact mutual_zero_reflects_equality C I x y h.1 h.2
  · intro h
    subst y
    exact ⟨C.monus_diagonal x, C.monus_diagonal x⟩

def error (x y : A) : A :=
  C.select (C.monus x y) (C.monus y x) (C.succ C.zero)

theorem error_zero_iff (I : InductionInputs C) (x y : A) :
    error C x y = C.zero ↔ x = y := by
  constructor
  · intro he
    change C.select (C.monus x y) (C.monus y x) (C.succ C.zero) = C.zero at he
    rcases C.zero_decision (C.monus x y) with hz | hn
    · rw [hz, C.select_zero] at he
      exact mutual_zero_reflects_equality C I x y hz he
    · rw [select_nonzero C hn] at he
      exact False.elim (C.separation he.symm)
  · intro h
    subst y
    change C.select (C.monus x x) (C.monus x x) (C.succ C.zero) = C.zero
    rw [C.monus_diagonal, C.select_zero]

theorem equality_decidable (I : InductionInputs C) (x y : A) :
    x = y ∨ x ≠ y := by
  rcases C.zero_decision (error C x y) with hz | hn
  · exact Or.inl ((error_zero_iff C I x y).mp hz)
  · apply Or.inr
    intro he
    exact hn ((error_zero_iff C I x y).mpr he)

#print axioms select_nonzero
#print axioms select_same
#print axioms monus_pred_shift
#print axioms complementary_identity
#print axioms complementarity
#print axioms reconstruction_identity
#print axioms mutual_zero_reflects_equality
#print axioms mutual_zero_iff
#print axioms error_zero_iff
#print axioms equality_decidable

end PBTwoReflection
