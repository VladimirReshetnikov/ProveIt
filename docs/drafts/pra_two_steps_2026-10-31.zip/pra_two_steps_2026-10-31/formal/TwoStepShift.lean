import Lean

/-!
# Two-step admission and the subtraction shift

This file checks a constructive semantic consequence of one explicit
positive-base propagation instance. It does not formalize all of PRA.

The abstract autonomous-iterator theorem assumes that the relevant instance
has been admitted. This assumption is essential: an arbitrary term used as
an update can duplicate its input, so its positive-base computation need
not have a two-rewrite certificate.

For predecessor iteration the certificate really does use two RAW defining
rewrites per side. `P` and `M` below denote binary iterator symbols, not
abbreviations that silently evaluate their zero arguments:

  P(0,a) = a,             P(Sn,a) = n,
  M(0,a) = a,             M(Sn,a) = P(M(n,a),0).

The admitted equation is M(n,P(a,0)) = P(M(n,a),0). At n = S0:

  M(S0,P(a,0)) -> P(M(0,P(a,0)),0) -> P(P(a,0),0),
  P(M(S0,a),0) -> P(P(M(0,a),0),0) -> P(P(a,0),0).

These two exact-length certificates are checked below over finite syntax.
Only one occurrence is rewritten at each step. The semantic proofs use
neither natural-number induction nor classical reasoning.
-/

namespace TwoStepShift

universe u

/-- The positive-base instance for the autonomous-iterator commutation law. -/
def CommutationInstance {A : Type u} (zero : A) (succ : A → A)
    (iter : A → A → A) (update : A → A) : Prop :=
  ∀ a,
    (∀ n, iter n (update a) = update (iter n a) →
      iter (succ n) (update a) = update (iter (succ n) a)) →
    (zero ≠ succ zero ∧
      ∀ n, n = zero ∨ iter n (update a) = update (iter n a))

/-- An admitted commutation instance proves commutation on every input. -/
theorem autonomous_commutation {A : Type u} (zero : A) (succ : A → A)
    (iter : A → A → A) (update : A → A)
    (iter_zero : ∀ a, iter zero a = a)
    (iter_succ : ∀ n a, iter (succ n) a = update (iter n a))
    (positive_base : CommutationInstance zero succ iter update) :
    ∀ n a, iter n (update a) = update (iter n a) := by
  intro n a
  have propagate : ∀ k, iter k (update a) = update (iter k a) →
      iter (succ k) (update a) = update (iter (succ k) a) := by
    intro k equality
    calc
      iter (succ k) (update a) = update (iter k (update a)) :=
        iter_succ k (update a)
      _ = update (update (iter k a)) := congrArg update equality
      _ = update (iter (succ k) a) :=
        congrArg update (iter_succ k a).symm
  have covered := (positive_base a propagate).2 n
  cases covered with
  | inl is_zero =>
    subst n
    exact (iter_zero (update a)).trans (congrArg update (iter_zero a)).symm
  | inr equality => exact equality

/-- The predecessor instance yields the monus shift without induction. -/
theorem subtraction_shift {A : Type u} (zero : A) (succ pred : A → A)
    (monus : A → A → A)
    (pred_succ : ∀ a, pred (succ a) = a)
    (monus_zero : ∀ a, monus zero a = a)
    (monus_succ : ∀ n a, monus (succ n) a = pred (monus n a))
    (positive_base : CommutationInstance zero succ monus pred) :
    ∀ n a, monus (succ n) (succ a) = monus n a := by
  have commute := autonomous_commutation zero succ monus pred
    monus_zero monus_succ positive_base
  intro n a
  calc
    monus (succ n) (succ a) = pred (monus n (succ a)) :=
      monus_succ n (succ a)
    _ = monus n (pred (succ a)) := (commute n (succ a)).symm
    _ = monus n a := congrArg (monus n) (pred_succ a)

namespace RawCertificate

/-- A finite fragment of the actual binary-iterator term syntax. -/
inductive Term where
  | zero : Term
  | parameter : Term
  | succ : Term → Term
  | predIter : Term → Term → Term
  | monus : Term → Term → Term
  deriving DecidableEq, Repr

open Term

/-- One raw computation rewrite, with closure under application contexts. -/
inductive Rewrite : Term → Term → Prop where
  | pred_zero (a) : Rewrite (predIter zero a) a
  | pred_succ (n a) : Rewrite (predIter (succ n) a) n
  | monus_zero (a) : Rewrite (monus zero a) a
  | monus_succ (n a) :
      Rewrite (monus (succ n) a) (predIter (monus n a) zero)
  | in_succ {s t} : Rewrite s t → Rewrite (succ s) (succ t)
  | in_pred_left {s t} (a) :
      Rewrite s t → Rewrite (predIter s a) (predIter t a)
  | in_pred_right (a) {s t} :
      Rewrite s t → Rewrite (predIter a s) (predIter a t)
  | in_monus_left {s t} (a) :
      Rewrite s t → Rewrite (monus s a) (monus t a)
  | in_monus_right (a) {s t} :
      Rewrite s t → Rewrite (monus a s) (monus a t)

/-- Exactly two raw rewrites, not a normalization or a derived equation. -/
def TwoRewrites (s t : Term) : Prop :=
  ∃ middle, Rewrite s middle ∧ Rewrite middle t

def left_at_one : Term :=
  monus (succ zero) (predIter parameter zero)

def right_at_one : Term :=
  predIter (monus (succ zero) parameter) zero

def common_reduct : Term :=
  predIter (predIter parameter zero) zero

theorem left_certificate : TwoRewrites left_at_one common_reduct := by
  refine ⟨predIter (monus zero (predIter parameter zero)) zero, ?_, ?_⟩
  · exact Rewrite.monus_succ zero (predIter parameter zero)
  · exact Rewrite.in_pred_left zero (Rewrite.monus_zero (predIter parameter zero))

theorem right_certificate : TwoRewrites right_at_one common_reduct := by
  refine ⟨predIter (predIter (monus zero parameter) zero) zero, ?_, ?_⟩
  · exact Rewrite.in_pred_left zero (Rewrite.monus_succ zero parameter)
  · exact Rewrite.in_pred_left zero
      (Rewrite.in_pred_left zero (Rewrite.monus_zero parameter))

end RawCertificate

#print axioms autonomous_commutation
#print axioms subtraction_shift
#print axioms RawCertificate.left_certificate
#print axioms RawCertificate.right_certificate

end TwoStepShift
