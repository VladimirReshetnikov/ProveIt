#!/usr/bin/env bash
set -euo pipefail

# Use LEAN=/absolute/path/to/lean to select a compiler explicitly.
# The certificates were checked with Lean 4.19.0.
lean_executable="${LEAN:-lean}"
formal_directory="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
proof_build_directory="$(mktemp -d "${TMPDIR:-/tmp}/pra-pb2-lean.XXXXXX")"
trap 'rm -rf -- "$proof_build_directory"' EXIT

for module in ConstantTarget TwoStepShift PBTwoReflection; do
  "$lean_executable" -o "$proof_build_directory/$module.olean" \
    "$formal_directory/$module.lean"
done

LEAN_PATH="$proof_build_directory${LEAN_PATH:+:$LEAN_PATH}" \
  "$lean_executable" "$formal_directory/Bootstrap.lean"

if [[ -f "$formal_directory/BinaryCodingWithoutShift.lean" ]]; then
  "$lean_executable" "$formal_directory/BinaryCodingWithoutShift.lean"
fi
