# Constructive Lean certificates

These files target Lean 4.19.0 and use only its standard distribution, with
no Mathlib or external packages. The accompanying logs record compilation
and the `#print axioms` audits. The main combined certificate is
`Bootstrap.lean`: it connects the constructor, constant-target induction,
subtraction, and reconstruction proofs and derives native equality reflection
from computation equations and nine explicitly named positive-base instances.
`PBTwoReflection.lean` contains the new complementary-reconstruction argument
at the center of that connected proof.

The certificates deliberately expose their hypotheses. An axiom-audit result
of "does not depend on any axioms" concerns Lean's global axiom dependencies;
the displayed computation, propagation, or induction hypotheses remain
theorem inputs. It does not mean that arithmetic follows from no assumptions
or that the entire equivalence with PRA has been formalized in Lean.

## ConstantTarget.lean: constructors and constant-target induction

`PositiveBaseInstance` supplies one specified propagation instance. It is not
an assumption of the schema for all semantic predicates. The file checks the
following constructive implications over an arbitrary carrier:

* the predecessor instance yields separation and constructor coverage;
* predecessor equations yield the usual successor facts;
* constructor coverage yields zero decidability;
* a delayed equation, literally reflexive at one, yields constant-target
  induction;
* the specified addition instances yield right-zero and right-successor laws;
* the actual gate/addition term satisfies the selector equations;
* three specified constant-target instances yield the needed monus identities.

The delay is `t(p(n),a) = t(p(S0),a)`. At `n = S0` its two sides are identical,
so admission needs zero computation rewrites. The file also formalizes the
finite raw syntax and the two-rewrite certificates for the fixed addition
instances. The broader initialized-iteration language and its complete
admission decision procedure are not formalized in this file.

## TwoStepShift.lean: predecessor commutation and subtraction Shift

The semantic part proves that an admitted autonomous-iteration commutation
instance yields commutation, and specializes that result to derive the monus
Shift identity. Admission of an arbitrary autonomous update is an explicit
hypothesis, since an update term can duplicate its input and need more than
two rewrites.

For the specific predecessor update, the file checks both raw two-rewrite
certificates over an inductively defined finite syntax. The predecessor
iterator is binary and its zero-case equation is the initialized-iteration
equation `P(0,a) = a`; no derived unary predecessor law is silently counted
as a raw computation step. Each rewrite changes one occurrence.

## PBTwoReflection.lean: the new native equality bootstrap

This file uses an arbitrary arithmetic carrier with explicit constructor
coverage, zero decision, selector equations, addition equations, and the
monus facts established in the preceding mathematical bootstrap. In
particular, Shift, monus at zero, and the two monus diagonals are inputs to
this certificate, rather than conclusions claimed again here.

The only induction inputs are exactly these two constant-target instances,
where `M(n,a)` has the intended orientation `a` minus `n`, truncated at zero:

```text
C(n,a) = select(M(n,a), a, add(n,M(n,a))) = a
R(n,a) = select(M(n,a), M(M(a,n),n), a) = a
```

The first establishes complementarity when `M(n,a)` is nonzero. The second
uses that result to establish reconstruction. From reconstruction the file
proves:

```text
M(x,y) = 0 and M(y,x) = 0   if and only if   x = y.
```

It then constructs the equality-error term, proves that its being zero is
equivalent to native equality on the carrier, and derives native equality
decidability from zero decision. No general equation induction, equality
oracle, classical logic, or induction over all semantic predicates is assumed.

The ten audited theorems in this file compile with no global axiom
dependencies. Its successful compilation log is included. The subsequent
quantifier-free formula compilation and the complete language translation
to ordinary PRA are written proofs in the manuscript, not Lean theorems
claimed by this file.

## Bootstrap.lean: the connected main proof

This file imports the three preceding certificates and checks that their
interfaces compose. Its `Computations` record contains only the constructor,
gate, addition, and monus operations with their computation equations. The
selector is defined as the gate/addition term; it is not an independent
primitive operation or equality oracle.

`PositiveInstances` lists exactly nine positive-base instances. The first
four have the following matrices:

1. `n = S(p(n))`.
2. `add(n,0) = n`.
3. `add(n,S(a)) = S(add(n,a))`.
4. `M(n,p(a)) = p(M(n,a))`.

The other five use the delayed matrix `t(p(n),a) = t(p(S0),a)`, for these
specified terms (unused parameters are omitted):

5. `t(n) = M(n,0)`.
6. `t(n) = M(n,n)`.
7. `t(n) = M(n,S(n))`.
8. `t(n,a) = select(M(n,a),a,add(n,M(n,a)))`.
9. `t(n,a) = select(M(n,a),M(M(a,n),n),a)`.

Their induced constant targets are respectively `0`, `0`, `1`, `a`, and
`a`. Every delayed matrix is literally reflexive at one, so these five
instances require zero base rewrites. Parameters are universally quantified
in the relevant individual instance; no hypothesis ranges over all semantic
predicates or all semantic functions.

`derivedArithmetic` proves every field of the arithmetic interface used by
`PBTwoReflection`, including zero decidability, the selector laws, and the
monus identities. `derivedInductionInputs` obtains its two reconstruction
induction inputs from the corresponding delayed instances. The resulting
`native_equality_reflection` and `native_equality_decidable` theorems depend
only on the explicit computation equations and those nine propagation
instances. All six printed declarations in this file have empty global
axiom dependencies.

Nine instances suffice for this equality bootstrap, not for all of PRA.
The later derivation of arbitrary quantifier-free induction still uses the
infinite delayed-instance family. The complete PR grammar, the general
admission recognizer, formula compilation, pairing, and the conservative
definitional-extension theorem are proved in the manuscript and are not
claimed as fully formalized by this file.

## BinaryCodingWithoutShift.lean: separate auxiliary result

This appendix certificate concerns the older one-term guarded schema and
is independent of the main two-rewrite equality bootstrap. It verifies
binary coding before subtraction Shift is available, using explicit
constructor coverage and computation laws for the zero test, selector,
parity, halving, and doubling.

Its induction input consists of exactly three specified term instances:

1. Identity-target induction for `half(double(n)) = n`.
2. Zero-equation induction for `parity(double(n)) = 0`.
3. Identity-target induction for the displayed binary reconstruction term.

The certificate proves Boolean range, two-successor parity and halving
identities, four tag/retraction identities, binary reconstruction, tag
reflection, injectivity of each tag, and disjointness of their ranges. Its
fifteen audited theorems compile with no global axiom dependencies.

The initialized-iteration descriptions and the earlier derivation of its
constructor and induction inputs from the one-term guarded schema are
mathematical dependencies explained in the written argument. Their full
object-language derivations are not reimplemented in this certificate.
It codes a number together with one Boolean digit. It does not assert a
pairing of two arbitrary numbers or removal of Shift from the older one-term
PRA basis.

## Reproducing the checks and understanding their scope

Run from this directory with Lean 4.19.0 on the executable path:

```sh
bash check.sh
```

Or select the compiler explicitly:

```sh
LEAN=/absolute/path/to/lean bash check.sh
```

The script compiles the three imported modules to a temporary directory,
checks `Bootstrap.lean` using those modules, and checks the independent binary
coding appendix when it is present. It removes the temporary compiled files
on exit. The standalone companion files can also be checked directly.

The four main files now certify a connected constructive equality bootstrap.
They do not formalize the entire object-language axiom system or its PRA
equivalence. Finite raw rewrite certificates are checked where stated; no
claim is made that the Python rewrite implementation itself has been
verified in Lean.

No arithmetic-carrier theorem invokes induction on Lean's natural numbers,
`Classical`, or an equality oracle. Derived decidability of arithmetic equality
is a conclusion of `PBTwoReflection.lean` and the assembled `Bootstrap.lean`.
Any decidable equality used for
finite rewrite syntax concerns syntax trees, not the arithmetic carrier.
These are constructive implications over explicit interfaces, with no
`sorry` or `admit` placeholders.
