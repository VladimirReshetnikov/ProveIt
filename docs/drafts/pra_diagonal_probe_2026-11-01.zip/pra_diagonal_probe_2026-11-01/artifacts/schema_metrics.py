#!/usr/bin/env python3
"""Reproduce the report's disclosed partial formula/body tree ledgers.

This is a syntactic counter, not a correctness proof or a complete byte-size
measure. Variable/constant occurrences, applications, connectives, equality,
falsehood, and individual quantifiers each count one. Quantifier binders are
labels, not extra children. Negation is implication to falsehood. Designated
program bodies are charged separately; names, arities, binding data, and the
schema enumerator are not assigned costs.
"""

import argparse
import json
from pathlib import Path


def node(label, *children):
    return (label, *children)


def size(tree):
    return 1 + sum(size(child) for child in tree[1:])


def app(label, *args):
    return node(label, *args)


def eq(left, right):
    return node("=", left, right)


def arrow(left, right):
    return node("->", left, right)


def neq(left, right):
    return arrow(eq(left, right), node("bottom"))


def disj(left, right):
    return node("or", left, right)


def forall(variables, body):
    for var in reversed(variables):
        body = node("forall " + var[0], body)
    return body


zero, n, a, x, y, v = [node(s) for s in ["0", "n", "a", "x", "y", "v"]]


def succ(t):
    return app("S", t)


one = succ(zero)


def templates(m):
    if m < 1:
        raise ValueError("The matched displayed-parameter convention uses m >= 1")
    params = [a] + [node("b" + str(i)) for i in range(1, m)]
    frozen = params[1:]
    fn = app("f", n, *params)
    fs = app("f", succ(n), *params)
    f0 = app("f", zero, *params)
    stationary = forall([n], eq(fs, fn))
    lhs0 = app("R", zero, *params)
    lhss = app("R", succ(n), *params)
    base_ordinary = forall(params, eq(lhs0, app("g", *params)))
    base_initialized = forall(params, eq(lhs0, a))
    step_ordinary = forall([n] + params,
        eq(lhss, app("h", n, app("R", n, *params), *params)))
    step_substitution = forall([n] + params,
        eq(lhss, app("h", n, *params,
            app("R", n, app("k", a), *frozen))))
    step_fixed_predecessor = forall([n] + params,
        eq(lhss, app("h", n, *params,
            app("R", n, app("p", a), *frozen))))
    step_swap = forall([n] + params,
        eq(lhss, app("h", n, *params, app("R", a, n, *frozen))))
    sep = neq(zero, one)
    off = forall([x, y], disj(eq(app("E", x, y), zero), eq(x, y)))
    relative_off = forall([x, y], disj(eq(app("R", x, y), y), eq(x, y)))
    ss = forall(params, arrow(stationary,
        forall([n], neq(succ(fn), f0))))
    probe = forall(params, arrow(stationary,
        forall([n], disj(eq(fn, a), eq(app("E", f0, a), zero)))))
    uniform = forall(params, arrow(stationary,
        disj(forall([n], eq(fn, a)), eq(app("E", f0, a), zero))))
    relative_probe = forall(params, arrow(stationary,
        forall([n], disj(eq(app("R", f0, a), a), eq(fn, a)))))
    agreement = forall(params, arrow(stationary,
        forall([n], neq(app("E", fn, f0), zero))))
    return {
        "ordinary_computation": [base_ordinary, step_ordinary],
        "substitution_computation": [base_ordinary, step_substitution],
        "fixed_predecessor_computation": [base_ordinary, step_fixed_predecessor],
        "initialized_substitution_computation": [base_initialized, step_substitution],
        "initialized_swap_computation": [base_initialized, step_swap],
        "separation": [sep],
        "off_diagonal": [off],
        "relative_off_diagonal": [relative_off],
        "stationary_separation": [ss],
        "probe_comparison": [probe],
        "uniform_comparison": [uniform],
        "relative_probe_comparison": [relative_probe],
        "stationary_agreement": [agreement],
    }


def bodies():
    p = lambda t: app("P", t, zero)
    expanded_selector = lambda z, u, w: app("P", app("B", z, succ(u)), w)
    selector = lambda z, u, w: app("C", z, u, w)
    d = lambda u, w: app("D", u, w)
    common_old = {
        "P": [a, n, a], "B": [a, zero, a],
        "E": [app("B", y, one), expanded_selector(y, zero, v), p(y)],
    }
    probe = {
        "P": [a, n, a], "C": [a, node("b"), a],
        "E": [selector(y, one, zero), selector(y, zero, v), p(y)],
    }
    fixed = {
        "p": [zero, n], "C": [a, node("b")],
        "E": [selector(y, one, zero), selector(y, zero, v)],
    }
    swap = {"C": [node("b")], "D": [v],
        "T": [selector(d(a, n), selector(d(n, a), a, zero), a)]}
    new = {"C": [node("b")], "D": [v],
        "R": [selector(d(a, n), n, a)]}
    initialized = {
        "P": [n, a], "B": [zero, a], "M": [v, p(a)],
        "R": [expanded_selector(a, zero,
            succ(expanded_selector(n, succ(p(p(a))), v))), p(a)],
    }
    agreement = {
        "p": [zero, n], "M": [a, app("p", v)],
        "Z": [one, zero], "H": [zero, app("Z", n)],
        "E": [app("Z", a), app("H", app("M", n, a))],
    }
    return {
        "pointed_constancy": common_old,
        "stationary_comparison": common_old,
        "probe_constancy": probe,
        "stationary_comparison_variant1": fixed,
        "initialized_swap": swap,
        "initialized_biinterpretation": initialized,
        "stationary_agreement": agreement,
        "diagonal_probe": new,
    }


def compute():
    rows = [
        ("initialized_swap", "pra_initialized_swap_2026-10-31.zip",
         ["initialized_swap_computation", "relative_off_diagonal", "stationary_separation"]),
        ("stationary_comparison_variant1", "pra_stationary_comparison_2026-10-31 (1).zip",
         ["fixed_predecessor_computation", "separation", "probe_comparison"]),
        ("probe_constancy", "pra_probe_constancy_2026-10-31.zip",
         ["substitution_computation", "separation", "probe_comparison"]),
        ("pointed_constancy", "pra_pointed_constancy_2026-10-31.zip",
         ["substitution_computation", "separation", "probe_comparison"]),
        ("stationary_comparison", "pra_stationary_comparison_2026-10-31.zip",
         ["substitution_computation", "separation", "uniform_comparison"]),
        ("initialized_biinterpretation", "pra_initialized_biinterpretation_2026-11-01.zip",
         ["initialized_substitution_computation", "relative_off_diagonal", "stationary_separation"]),
        ("stationary_agreement", "pra_stationary_agreement_2026-10-31.zip",
         ["ordinary_computation", "off_diagonal", "stationary_agreement"]),
        ("diagonal_probe", "This report",
         ["initialized_swap_computation", "separation", "relative_probe_comparison"]),
    ]
    programs = bodies()
    metrics = []
    for ident, source, parts in rows:
        per_arity = []
        for m in range(1, 9):
            trees = templates(m)
            costs = {part: sum(map(size, trees[part])) for part in parts}
            per_arity.append({"m": m, "components": costs, "total": sum(costs.values())})
        program_costs = {name: list(map(size, terms))
                         for name, terms in programs[ident].items()}
        body_total = sum(sum(values) for values in program_costs.values())
        metrics.append({"id": ident, "archive": source, "formula_by_arity": per_arity,
                        "body_sizes": program_costs, "body_total": body_total,
                        "partial_sum_at_m1": per_arity[0]["total"] + body_total})
    expected = {"initialized_swap": (52, 13), "stationary_comparison_variant1": (52, 13),
        "probe_constancy": (52, 18), "pointed_constancy": (52, 19),
        "stationary_comparison": (52, 19), "initialized_biinterpretation": (53, 28),
        "stationary_agreement": (54, 17), "diagonal_probe": (50, 8)}
    for row in metrics:
        assert (row["formula_by_arity"][0]["total"], row["body_total"]) == expected[row["id"]]
        for arity in row["formula_by_arity"]:
            if row["id"] == "diagonal_probe":
                assert arity["total"] == 39 + 11 * arity["m"]
            if row["id"] == "initialized_swap":
                assert arity["total"] == 41 + 11 * arity["m"]
    return {
        "source_commit": "e6474c41337c6495c4589970d8d1bfdcfce65b66",
        "metric": "one node per AST constructor; negation expanded; all universal closures counted",
        "scope": [
            "Representative displays have m>=1; all actual theories allow every stated finite arity.",
            "The fixed-predecessor presentation also has a separate empty-parameter grammar case.",
            "Only designated dependencies of the axioms count in the body ledger; proof-only terms do not.",
            "Names, arities, binding data, grammar implementation, and axiom enumerator are uncharged.",
            "This is not an absolute minimum or a complete description-length claim.",
            "The classical-only biconditional variant of stationary_agreement is outside the common basis table; its total is 47 with primitive iff, or 63 after expansion.",
        ],
        "rows": metrics,
        "new_formula_trees_at_m1": templates(1),
        "new_body_trees": programs["diagonal_probe"],
        "checks_passed": True,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("schema_metrics.json"))
    args = parser.parse_args()
    result = compute()
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "checks_passed": True,
        "rows": [{"id": row["id"], "display_m1": row["formula_by_arity"][0]["total"],
                  "bodies": row["body_total"]} for row in result["rows"]]}, indent=2))


if __name__ == "__main__":
    main()
