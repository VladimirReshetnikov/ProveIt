#!/usr/bin/env python3
"""Finite diagnostics for the PRA diagonal-probe presentation.

This is deliberately not a proof checker.  It compares two independent
standard-natural-number implementations of initialized swap recursion,
checks the designated descriptions and the ordinary-recursion embedding,
and exhaustively checks a bounded collection of Boolean formula trees.
The manuscript, not these finite computations, supplies the arguments for
arbitrary and nonstandard elements and for first-order bi-interpretability.

Only the Python standard library is required.  Run from any directory:
    python3 check_constructions.py
The default output is check_results.json next to this script.
"""

from __future__ import annotations

import argparse
from functools import cache
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
from typing import Callable


Parameters = tuple[int, ...]
Update = Callable[[int, int, Parameters, int], int]
Swap = Callable[[int, int, Parameters], int]


def direct_swap(update: Update) -> Swap:
    """Evaluate R(0,a,b)=a; R(n+1,a,b)=h(n,a,b,R(a,n,b))."""

    @cache
    def evaluate(x: int, a: int, parameters: Parameters = ()) -> int:
        assert x >= 0 and a >= 0 and all(p >= 0 for p in parameters)
        if x == 0:
            return a
        n = x - 1
        # This call decreases the sum of the two active arguments by one.
        return update(n, a, parameters, evaluate(a, n, parameters))

    return evaluate


def diagonal_fold(update: Update, x: int, y: int,
                  parameters: Parameters = ()) -> int:
    """The explicit ordinary-PR compiler; no call to direct_swap occurs.

    d = x monus y, e = y monus x, j = min(x,y).
    V(0,d,e,b) = e if d=0, otherwise h(pred(d),0,b,pred(d)).
    V(j+1,d,e,b) = h(d+j,e+j+1,b,h(e+j,d+j,b,V(j,d,e,b))).
    """
    d = max(x - y, 0)
    e = max(y - x, 0)
    value = e if d == 0 else update(d - 1, 0, parameters, d - 1)
    for j in range(min(x, y)):
        inner = update(e + j, d + j, parameters, value)
        value = update(d + j, e + j + 1, parameters, inner)
    return value


# These are literal instances of the single initialized-swap constructor.
_case = direct_swap(lambda n, a, b, value: b[0])
_difference = direct_swap(lambda n, a, b, value: value)


def case(z: int, u: int, v: int) -> int:
    return _case(z, u, (v,))


def difference(x: int, y: int) -> int:
    return _difference(x, y, ())


_bump = direct_swap(
    lambda n, a, b, value: case(difference(a, n), n, a)
)


def bump(x: int, a: int) -> int:
    return _bump(x, a, ())


def equality_error(x: int, y: int) -> int:
    return difference(y, bump(x + 1, y + 1))


def zero_error(z: int) -> int:
    return equality_error(z, 0)


def select(z: int, u: int, v: int) -> int:
    return case(zero_error(z), u, v)


def ordinary_embedding(base: Callable[[Parameters], int],
                       step: Callable[[int, int, Parameters], int]):
    """Compile ordinary F(0,b)=g(b), F(n+1,b)=H(n,F(n,b),b).

    h(n,a,b,v) = C(e(a,n), v, J(n,g(b),H(pred(n),v,b))).
    F(n,b) = R_h(n+1,n+1,b).
    """

    def update(n: int, a: int, parameters: Parameters, value: int) -> int:
        return case(
            equality_error(a, n), value,
            select(n, base(parameters), step(max(n - 1, 0), value, parameters))
        )

    swapped = direct_swap(update)

    @cache
    def evaluate(n: int, parameters: Parameters = ()) -> int:
        return swapped(n + 1, n + 1, parameters)

    return evaluate


def check_swap_compiler() -> dict:
    updates: list[tuple[str, Update]] = [
        ("zero", lambda n, a, p, v: 0),
        ("counter", lambda n, a, p, v: n),
        ("initial_argument", lambda n, a, p, v: a),
        ("recursive_value", lambda n, a, p, v: v),
        ("successor_value", lambda n, a, p, v: v + 1),
        ("first_parameter", lambda n, a, p, v: p[0]),
        ("second_parameter", lambda n, a, p, v: p[1]),
        ("ordered_affine", lambda n, a, p, v: n + 3*a + 5*v + 7*p[0] + p[1]),
        ("bounded_mixed", lambda n, a, p, v: (n*a + v + 2*p[0] + p[1]) % 19),
        ("branch", lambda n, a, p, v: p[0] if v == 0 else n + a + p[1]),
    ]
    parameter_tuples = tuple(product(range(3), repeat=2))
    comparisons = 0
    equation_checks = 0
    for _, update in updates:
        direct = direct_swap(update)
        for x, y, parameters in product(range(13), range(13), parameter_tuples):
            result = diagonal_fold(update, x, y, parameters)
            assert result == direct(x, y, parameters)
            comparisons += 1
            if x == 0:
                assert result == y
            else:
                expected = update(
                    x - 1, y, parameters,
                    diagonal_fold(update, y, x - 1, parameters)
                )
                assert result == expected
            equation_checks += 1
    return {
        "updates": [name for name, _ in updates],
        "active_argument_range": [0, 12],
        "frozen_parameter_tuples": len(parameter_tuples),
        "direct_vs_fold_comparisons": comparisons,
        "compiled_equation_checks": equation_checks,
    }


def check_designated_descriptions() -> dict:
    checks = 0
    for x, y in product(range(17), repeat=2):
        expected_d = max(y - x, 0) + max(x - y - 1, 0)
        assert difference(x, y) == expected_d
        expected_r = max(y - 1, 0) if x == y else y
        assert bump(x, y) == expected_r
        assert bump(x, y) == y or x == y
        assert equality_error(x, y) == int(x != y)
        checks += 4
    for x in range(17):
        assert difference(x, x) == 0
        assert difference(x, x + 1) == 1
        assert bump(x + 1, x + 1) == x
        assert zero_error(x) == int(x != 0)
        checks += 4
    for z, u, v in product(range(9), repeat=3):
        expected = u if z == 0 else v
        assert case(z, u, v) == expected
        assert select(z, u, v) == expected
        checks += 2
    # The probe's numerical instance is sound for every constant sequence.
    # This is a finite semantic check, not a test of universal stationarity.
    for value, comparison in product(range(17), repeat=2):
        assert bump(value, comparison) == comparison or value == comparison
        checks += 1
    return {"checks": checks, "main_argument_range": [0, 16],
            "selector_argument_range": [0, 8]}


def check_ordinary_embedding() -> dict:
    add = ordinary_embedding(lambda p: p[0], lambda n, v, p: v + 1)
    multiply = ordinary_embedding(
        lambda p: 0, lambda n, v, p: add(p[0], (v,))
    )
    power = ordinary_embedding(
        lambda p: 1, lambda n, v, p: multiply(v, (p[0],))
    )
    affine_sum = ordinary_embedding(
        lambda p: p[1], lambda n, v, p: v + p[0]*n + p[1]
    )
    totals = {"addition": 0, "multiplication": 0, "exponentiation": 0,
              "two_parameter_indexed_sum": 0}
    for n, a in product(range(11), repeat=2):
        assert add(n, (a,)) == n + a
        assert multiply(n, (a,)) == n * a
        totals["addition"] += 1
        totals["multiplication"] += 1
    for n, a in product(range(6), range(4)):
        assert power(n, (a,)) == a**n
        totals["exponentiation"] += 1
    for n, a, b in product(range(9), range(5), range(5)):
        expected = b + a*n*(n - 1)//2 + b*n
        assert affine_sum(n, (a, b)) == expected
        totals["two_parameter_indexed_sum"] += 1
    return {"examples": totals, "total_comparisons": sum(totals.values()),
            "nested_compilation": "multiplication uses compiled addition; "
                "exponentiation uses compiled multiplication"}


Formula = tuple


def formula_truth(formula: Formula, values: tuple[bool, bool]) -> bool:
    tag = formula[0]
    if tag == "atom":
        return values[formula[1]]
    if tag == "false":
        return False
    if tag == "true":
        return True
    left = formula_truth(formula[1], values)
    right = formula_truth(formula[2], values)
    if tag == "and":
        return left and right
    if tag == "or":
        return left or right
    assert tag == "implies"
    return (not left) or right


def formula_error(formula: Formula, values: tuple[bool, bool]) -> int:
    tag = formula[0]
    if tag == "atom":
        # Realize the two possible atom values as the native equations 0=0
        # and 0=1, then use the computed equality description.
        return equality_error(0, 0 if values[formula[1]] else 1)
    if tag == "false":
        return 1
    if tag == "true":
        return 0
    left = formula_error(formula[1], values)
    right = formula_error(formula[2], values)
    if tag == "and":
        return select(left, right, 1)
    if tag == "or":
        return select(left, 0, right)
    assert tag == "implies"
    return select(left, right, 0)


def check_boolean_compiler() -> dict:
    atoms = {("atom", 0), ("atom", 1), ("false",), ("true",)}
    formulas = atoms
    for _ in range(2):
        formulas = atoms | {
            (operator, left, right)
            for operator in ("and", "or", "implies")
            for left, right in product(formulas, repeat=2)
        }
    checks = 0
    for formula, values in product(formulas, product((False, True), repeat=2)):
        value = formula_error(formula, values)
        assert value in (0, 1)
        assert (value == 0) == formula_truth(formula, values)
        checks += 1
    latch_checks = 0
    for current_bit, next_bit, previous in product(range(2), repeat=3):
        if current_bit == 0 and next_bit != 0:
            continue  # This is exactly the assumed induction-step condition.
        current = select(current_bit, previous, 0)
        following = select(next_bit, current, 0)
        assert following == current
        latch_checks += 1
    return {"maximum_connective_depth": 2, "formula_trees": len(formulas),
            "valuations_per_formula": 4, "truth_table_comparisons": checks,
            "local_shifted_latch_checks": latch_checks,
            "interpretation": "Truth tables are valid for the decidable "
                "bits proved in the manuscript; this check does not assert "
                "excluded middle for arbitrary quantified formulas."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("check_results.json"))
    options = parser.parse_args()
    result = {
        "status": "passed",
        "scope": "Finite diagnostics over standard natural numbers only. "
            "Not a formal proof certificate, not a verification of nonstandard "
            "models, and not a machine-checked bi-interpretability theorem.",
        "script_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "swap_compiler": check_swap_compiler(),
        "designated_descriptions": check_designated_descriptions(),
        "ordinary_recursion_embedding": check_ordinary_embedding(),
        "boolean_compiler": check_boolean_compiler(),
    }
    options.output.parent.mkdir(parents=True, exist_ok=True)
    options.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
