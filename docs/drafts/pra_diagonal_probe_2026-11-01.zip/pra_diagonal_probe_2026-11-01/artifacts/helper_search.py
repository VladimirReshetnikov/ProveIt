#!/usr/bin/env python3
"""Exhaust a precisely restricted update-term grammar and retain witnesses.

Terms have leaves n,a,v,0 and constructors S(t), D(t,u), C(t,u,w).
Every AST node has cost one. For each term h, R_h is defined numerically by
R_h(0,a)=a and R_h(n+1,a)=h(n,a,R_h(a,n)). Its dependency decreases the sum
of the two active arguments, so the numerical table has an exact finite
evaluation order. D and C are interpreted as the previously specified helpers:
D(x,y)=max(y-x,0)+max(x-y-1,0), C(0,u,w)=u, C(z+1,u,w)=w.

A failing finite instance disproves a universal property. Passing the finite
grid proves nothing universal. The restricted lower bound is asserted only
if EVERY term of size <=5 has a concrete failing witness for either
R_h(1,1)=0 or R_h(x,a)=a OR x=a. It does not address other grammars,
other comparison programs, other arithmetic schemas, or global minimality.
"""

import argparse
import hashlib
import json
from pathlib import Path


LEAVES = [(name,) for name in ("n", "a", "v", "0")]


def generate(max_size):
    by_size = {1: LEAVES.copy()}
    for total in range(2, max_size + 1):
        terms = [("S", t) for t in by_size[total - 1]]
        for left_size in range(1, total - 1):
            right_size = total - 1 - left_size
            for left in by_size[left_size]:
                for right in by_size[right_size]:
                    terms.append(("D", left, right))
        for first_size in range(1, total - 2):
            for second_size in range(1, total - first_size - 1):
                third_size = total - 1 - first_size - second_size
                if third_size < 1:
                    continue
                for first in by_size[first_size]:
                    for second in by_size[second_size]:
                        for third in by_size[third_size]:
                            terms.append(("C", first, second, third))
        by_size[total] = terms
    return by_size


def count_by_recurrence(max_size):
    counts = {1: 4}
    for total in range(2, max_size + 1):
        count = counts[total - 1]
        count += sum(counts[i] * counts[total - 1 - i] for i in range(1, total - 1))
        count += sum(counts[i] * counts[j] * counts[total - 1 - i - j]
                     for i in range(1, total - 2)
                     for j in range(1, total - i - 1)
                     if total - 1 - i - j >= 1)
        counts[total] = count
    return counts


def pretty(term):
    return term[0] if len(term) == 1 else term[0] + "(" + ",".join(map(pretty, term[1:])) + ")"


def evaluate(term, n, a, v):
    op = term[0]
    if op == "n":
        return n
    if op == "a":
        return a
    if op == "v":
        return v
    if op == "0":
        return 0
    if op == "S":
        return evaluate(term[1], n, a, v) + 1
    if op == "D":
        x, y = evaluate(term[1], n, a, v), evaluate(term[2], n, a, v)
        return max(y - x, 0) + max(x - y - 1, 0)
    if op == "C":
        branch = 2 if evaluate(term[1], n, a, v) == 0 else 3
        return evaluate(term[branch], n, a, v)
    raise ValueError("Unknown AST constructor")


def table(term, bound):
    values = {(0, a): a for a in range(bound + 1)}
    for total in range(1, 2 * bound + 1):
        for x in range(1, bound + 1):
            a = total - x
            if 0 <= a <= bound:
                values[x, a] = evaluate(term, x - 1, a, values[a, x - 1])
    return values


def first_failure(term, bound):
    values = table(term, bound)
    if values[1, 1] != 0:
        return {"property": "R(1,1)=0", "x": 1, "a": 1, "value": values[1, 1]}
    for total in range(2 * bound + 1):
        for x in range(bound + 1):
            a = total - x
            if 0 <= a <= bound and x != a and values[x, a] != a:
                return {"property": "R(x,a)=a or x=a", "x": x, "a": a,
                        "value": values[x, a]}
    return None


def validate_witness(term, witness):
    values = table(term, max(1, witness["x"], witness["a"]))
    value = values[witness["x"], witness["a"]]
    assert value == witness["value"]
    if witness["property"] == "R(1,1)=0":
        assert value != 0
    else:
        assert witness["x"] != witness["a"] and value != witness["a"]


def necessary_probe_vectors(max_size):
    """Independent finite-algebra check of four necessary update values.

    Off-diagonal correctness at (1,0),(2,0),(1,2) and R(1,1)=0 imply
    h(0,0,0)=0, h(1,0,1)=0, h(0,1,0)=0, h(0,2,0)=2.
    The induction here stores sets of value vectors, not syntax trees.
    """
    inputs = [(0, 0, 0), (1, 0, 1), (0, 1, 0), (0, 2, 0)]
    target = (0, 0, 0, 2)
    vectors = {1: {tuple(point[j] for point in inputs) for j in range(3)}
                   | {(0, 0, 0, 0)}}
    for total in range(2, max_size + 1):
        current = {tuple(x + 1 for x in vec) for vec in vectors[total - 1]}
        for i in range(1, total - 1):
            for left in vectors[i]:
                for right in vectors[total - 1 - i]:
                    current.add(tuple(max(y - x, 0) + max(x - y - 1, 0)
                                      for x, y in zip(left, right)))
        for i in range(1, total - 2):
            for j in range(1, total - i - 1):
                k = total - 1 - i - j
                for condition in vectors[i]:
                    for first in vectors[j]:
                        for second in vectors[k]:
                            current.add(tuple(u if z == 0 else w
                                              for z, u, w in zip(condition, first, second)))
        vectors[total] = current
    return {
        "inputs_n_a_v": inputs,
        "required_vector": target,
        "counts_of_distinct_vectors_by_exact_size": {k: len(v) for k, v in vectors.items()},
        "required_vector_absent_below_6": all(target not in vectors[k] for k in range(1, 6)),
        "first_size_containing_required_vector": next(
            (k for k, values in vectors.items() if target in values), None),
        "value_vectors_by_exact_size": {k: sorted(v) for k, v in vectors.items()},
    }


def search(max_size=6, bound=12):
    if max_size < 5 or bound < 1:
        raise ValueError("Need max_size>=5 and bound>=1 for the declared experiment")
    by_size = generate(max_size)
    expected = count_by_recurrence(max_size)
    records, survivors, actual = [], [], {}
    for size, terms in by_size.items():
        assert len(terms) == expected[size]
        assert len(set(terms)) == len(terms)
        actual[size] = len(terms)
        for term in terms:
            witness = first_failure(term, bound)
            record = {"size": size, "term": pretty(term), "ast": term, "witness": witness}
            if witness is None:
                survivors.append(record)
            else:
                validate_witness(term, witness)
            records.append(record)
    lower_bound = not any(record["size"] <= 5 for record in survivors)
    proposed = ("C", ("D", ("a",), ("n",)), ("n",), ("a",))
    assert proposed in by_size[6] if max_size >= 6 else True
    assert first_failure(proposed, bound) is None
    probe_check = necessary_probe_vectors(max_size)
    assert probe_check["required_vector_absent_below_6"] == lower_bound
    digest_input = "\n".join(record["term"] for record in records).encode()
    result = {
        "grammar": {"leaves": ["n", "a", "v", "0"],
                    "constructors": {"S": 1, "D": 2, "C": 3}, "node_cost": 1},
        "max_size": max_size, "grid_bound_inclusive": bound,
        "counts_by_size": actual, "total_terms": len(records),
        "ordered_term_list_sha256": hashlib.sha256(digest_input).hexdigest(),
        "restricted_size_at_least_6_proved_by_witnesses": lower_bound,
        "proposed_update": pretty(proposed), "proposed_size": 6,
        "independent_necessary_probe_check": probe_check,
        "scope": [
            "Each failed term has an independently re-evaluated concrete natural-number witness.",
            "Induction on AST size and the recurrence count establish that the generator covers this grammar.",
            "Only failures are proofs of universal impossibility; finite-grid survivors are candidates.",
            "The report supplies a mathematical proof for the proposed update.",
            "The restricted lower bound concerns a single update with these fixed primitive helpers and the two stated properties.",
            "No global minimality of PRA axiomatizations is implied.",
        ],
        "finite_grid_survivors": survivors,
        "records": records,
    }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-size", type=int, default=6)
    parser.add_argument("--bound", type=int, default=12)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("helper_search.json"))
    args = parser.parse_args()
    result = search(args.max_size, args.bound)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in ["counts_by_size", "total_terms",
        "restricted_size_at_least_6_proved_by_witnesses", "proposed_update"]}, indent=2))
    print(json.dumps({"survivors": [{"size": x["size"], "term": x["term"]}
                                   for x in result["finite_grid_survivors"]]}, indent=2))


if __name__ == "__main__":
    main()
