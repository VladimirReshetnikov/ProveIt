#!/usr/bin/env python3
"""Rebuild the report and its diagnostics without network access.

Requires Python 3.10+ and pdfLaTeX with the packages declared in the TeX file.
Diagnostics are finite checks; they do not formalize the mathematical proof.
"""

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
STEM = "pra_diagonal_probe"


def run_diagnostics():
    for name in ("schema_metrics.py", "helper_search.py", "check_constructions.py"):
        result = subprocess.run(
            [sys.executable, str(ROOT / "artifacts" / name)],
            cwd=ROOT, text=True, capture_output=True, check=False,
        )
        if result.returncode:
            raise RuntimeError(name + " failed:\n" + result.stdout + result.stderr)
        print(name + ": passed")


def build_pdf():
    engine = shutil.which("pdflatex")
    if engine is None:
        raise RuntimeError("pdfLaTeX is required to compile the report.")
    with tempfile.TemporaryDirectory(prefix="pra_diagonal_probe_") as tmp:
        for _ in range(3):
            result = subprocess.run(
                [engine, "-interaction=nonstopmode", "-halt-on-error",
                 "-file-line-error", "-output-directory=" + tmp,
                 str(ROOT / (STEM + ".tex"))],
                cwd=ROOT, text=True, capture_output=True, check=False,
            )
            if result.returncode:
                raise RuntimeError(result.stdout[-14000:] + result.stderr)
        log = (Path(tmp) / (STEM + ".log")).read_text(errors="replace")
        problems = [line for line in log.splitlines() if any(
            word in line for word in (
                "Overfull", "Underfull", "undefined", "multiply defined",
                "pdfTeX warning", "LaTeX Warning", "Missing character",
            )
        )]
        if problems:
            raise RuntimeError("Layout or reference warnings:\n" + "\n".join(problems))
        final_pdf = ROOT / (STEM + ".pdf")
        shutil.copyfile(Path(tmp) / (STEM + ".pdf"), final_pdf)
        # TeX wraps long output paths at fixed columns, even inside 'pages'.
        pages = re.search(r"\(\s*(\d+)\s*pages?\s*,", log.replace("\n", ""))
        if pages is None:
            raise RuntimeError("Could not extract the PDF page count from the TeX log.")
        summary = {
            "status": "passed",
            "engine": subprocess.check_output([engine, "--version"], text=True).splitlines()[0],
            "passes": 3,
            "pages": int(pages.group(1)),
            "overfull_boxes": 0,
            "underfull_boxes": 0,
            "unresolved_references": 0,
            "duplicate_destinations": 0,
            "pdf_sha256": hashlib.sha256(final_pdf.read_bytes()).hexdigest(),
            "tex_sha256": hashlib.sha256((ROOT / (STEM + ".tex")).read_bytes()).hexdigest(),
            "scope": "Compilation and log checks. Visual inspection is recorded separately.",
        }
        (ROOT / "audit" / "build_summary.json").write_text(
            json.dumps(summary, indent=2) + "\n", encoding="utf-8"
        )
        print("PDF: " + str(summary["pages"]) + " pages; no layout/reference warnings")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks-only", action="store_true")
    parser.add_argument("--pdf-only", action="store_true")
    args = parser.parse_args()
    if args.checks_only and args.pdf_only:
        parser.error("Choose at most one of --checks-only and --pdf-only.")
    if not args.pdf_only:
        run_diagnostics()
    if not args.checks_only:
        build_pdf()


if __name__ == "__main__":
    main()
