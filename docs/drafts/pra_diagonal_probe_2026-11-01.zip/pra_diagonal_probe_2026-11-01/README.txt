PRIMITIVE RECURSIVE ARITHMETIC FROM A DIAGONAL PROBE
Prepared for Vladimir Reshetnikov, 1 November 2026

READ FIRST

pra_diagonal_probe.pdf is the complete mathematical report.
pra_diagonal_probe.tex is its editable, standalone LaTeX source.

The new theory uses initialized swap recursion, 0 != S0, and one
stationary-function probe schema. It is proved bi-interpretable, with
explicit provably inverse term translations, with first-order PRA in
each matching logic: classical or intuitionistic.

MATCHED IMPROVEMENT

Compared with the initialized-swap draft at the pinned ProveIt snapshot:
  displayed basis:          52 -> 50 formula-tree nodes;
  designated helper bodies: 13 -> 8 term-tree nodes;
  sum of these ledgers:     65 -> 58 nodes.

The new comparison update is C(D(a,n),n,a), six nodes. It changes a to
its predecessor when the two active inputs agree and otherwise returns a.
No update below six nodes in the stated fixed helper grammar meets the
two required numerical properties; an exhaustive witness file is included.
This is a restricted computational lower bound, not a global minimality
claim about all PRA axiomatizations, alphabets, or encodings.

CONTENTS

  pra_diagonal_probe.tex / .pdf
    Full specification, constructive reconstruction, both compilers,
    full-language uniqueness, identity round trips, comparison, limitations.
  build.py
    Offline rebuild of diagnostics and the PDF.
  artifacts/schema_metrics.py / .json
    Exact AST counting and the comparison with all seven current drafts.
  artifacts/helper_search.py / .json
    Exhaustive small-update enumeration, exclusion witnesses, and an
    independent finite-algebra necessary-value check.
  artifacts/check_constructions.py / check_results.json
    Numerical compiler checks, ordinary PR embeddings, Boolean and latch checks.
  audit/sources.json
    Repository commit, exact archive hashes, and inspected TeX source hashes.
  audit/build_summary.json
    PDF compilation and reference/layout checks.
  audit/verification.json
    Verification scope and visual QA record.
  SHA256SUMS.txt
    Checksums for the delivered package contents, excluding this checksum file.

REPRODUCE

Run from any working directory:
  python3 build.py

Optional:
  python3 build.py --checks-only
  python3 build.py --pdf-only

Python dependencies: standard library only, Python 3.10 or newer.
PDF dependency: pdfLaTeX, with the common packages listed in the TeX preamble.
No network access or original draft archives are needed for rebuilding.
PDF byte hashes can change between builds because of TeX metadata.

PROOF STATUS

The report provides mathematical proofs of the general first-order
bi-interpretability statements. Numerical checks alone would not prove
those statements, particularly on nonstandard carriers. No complete
Lean, Rocq, or other proof-assistant certification is claimed.

The two logical answers use the same nonlogical axioms. The result does
not identify classical and intuitionistic first-order consequence relations.
It uses an effective infinite axiom family, not finitely many sentences.

SOURCE SNAPSHOT

https://github.com/VladimirReshetnikov/ProveIt/tree/e6474c41337c6495c4589970d8d1bfdcfce65b66/docs/drafts

The old initialized-swap computation grammar and diagonal-fold compiler
are retained and explicitly credited. The new contribution is the
relative-decrement comparator, its integration with the probe schema,
the shorter constructive bootstrap, and the restricted helper lower bound.
