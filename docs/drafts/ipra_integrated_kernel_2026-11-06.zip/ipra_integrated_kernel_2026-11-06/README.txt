A STRICTLY SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov -- 6 November 2026

RESULT

The complete acceptance checker has 650 Python AST nodes, 617 significant
source tokens, 615 normalized tokens, and 1,936 normalized UTF-8 bytes.
It is strictly below the coordinatewise minima of all six inspected current
ProveIt drafts: 675, 636, 634, and 2,053 respectively. Exact original source
bytes and reproducible measurements are included. Raw size is 2,042 bytes,
below the current raw-byte minimum 2,205; unlike the primary metrics, that
supplementary measure includes documentation.

The mathematical basis is inherited from the supplied draft series. The
contribution is a smaller integrated presentation and executable acceptance
program, with explicit soundness and certificate-translation arguments.
The native calculus is a faithful presentation of an ordinary first-order
theory bi-interpretable with full intuitionistic primitive recursive arithmetic.
Both ordinary interpretations use the full number domain, preserve ordinary
logic and equality, and have composite isomorphism x=y. Equiconsistency follows.

This is a strict improvement over a pinned finite implementation benchmark.
It is not a proof of absolute minimality among all axiomatizations or runtimes.

START HERE

  report.pdf                  Compiled, self-contained mathematical paper.
  report.tex                  Main LaTeX source; includes the other *.tex files.
  checker.py                  The entire application-specific acceptance code.
  reproduce.py                Offline measurements and validation, plus tables.
  results/summary.json        Concise recorded evidence.
  comparison/README.txt       Measurement definitions, provenance, and ablation.
  examples/                   18 executable theorem certificates.
  validation/migrated/        All 256 translated frozen fixtures and provenance.
  MANIFEST.sha256             Checksums for the delivered files.

The checker imports only Python's standard json and sys modules. It does not
import proof builders, validators, comparison programs, or any arithmetic
library. Every public hypothesis and goal is fully syntax-checked. The only
unused-field convention is for a universal witness which occurs in neither
component of its principal formula; that unused field denotes witness zero.

REPRODUCE

Use Python 3.10 or later. Measurements were recorded with CPython 3.12.14;
AST/unparse metrics can change with the Python release, and every comparison
run measures all sources with the same runtime.

  python3 reproduce.py
  python3 checker.py examples/reflexivity.json
  python3 checker.py examples/forall_exists_successor.json

The complete reproduction uses only the Python standard library, all files
are local, and no network connection is needed. The expected checker output
on the examples is ACCEPT, with exit code 0. Rejection is REJECT, exit code 1.
Python -O does not remove checks because the acceptance program uses no assert.

Rebuild the already supplied PDF with a standard LaTeX installation:

  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

The LaTeX source uses conventional packages listed in report.tex. Runtime
resource limits can reject very large proof certificates; mathematical
completeness refers to ideal unbounded execution of the specified calculus.

CERTIFICATE FORMAT

  [goal, proof, hypothesis_0, hypothesis_1, ...]

Number terms:
  -1                         zero
  integer i >= 0             de Bruijn variable i
  ["s",t]                    successor
  ["r",n,a,h]                initialized recursion, update binds value/counter

Formulas:
  ["=",s,t]                  numerical equality
  ["pi",A,B]                 forall x (A -> B), x bound in both components
  ["ex",A]                   exists x A

Proofs:
  k                          context selector (signed integer; bool aliases)
  ["lam",A,q]                guarded introduction under fresh number and A
  ["pack",t,q]               existential introduction under fresh y=t
  ["nat",A,q]                equation induction / general numerical cases
  [p,a,q]                    equality or guarded application
  [p,q]                      existential application
  ["r",-1,a,h]               zero computation equation
  ["r",["s",n],a,h]          successor computation equation

Exact binder conventions, side conditions, and every derived logical rule
are in the paper. In particular, numerical booleans and floats are rejected
as terms even when Python would equate them with integers. Proof-index aliases
do not affect that numerical syntax requirement.

EVIDENCE AND LIMITATIONS

  * 5,056 independent checks, zero failures.
  * 182 explicit certificate cases, with 1,702 accepted proof-rule nodes
    replayed by a separate strict reference interpreter.
  * 256 migrated frozen fixtures: 194 acceptances and 62 rejections,
    matching the previous primary checker on every case.
  * All six current primary sources retained unchanged.
  * All 194 distinct nested infer/check sources retained and remeasured.
  * Whole-archive scan: 1,042 Python occurrences / 272 exact-byte sources.

The named-binder oracle and explicit-rule interpreter are algorithmically
separate from the target's substitution routine and scope table. The audit
credits its predecessor in the supplied shared-transition draft. These are
finite implementation checks, not a proof-assistant verification of the
metatheorem or a consistency proof. The mathematical argument is in report.pdf.

SNAPSHOT AND ATTRIBUTION

Repository: VladimirReshetnikov/ProveIt
Commit:     0a86fcbd7c5e0d6a541291b4ac06c7dc77989161
Directory:  docs/drafts
URL: https://github.com/VladimirReshetnikov/ProveIt/tree/0a86fcbd7c5e0d6a541291b4ac06c7dc77989161/docs/drafts

The native calculus and logical/arithmetic derivations are credited to the
supplied draft series, particularly its shared-transition treatment. The new
checker integrates its shared fresh-number transition with the other drafts'
compatible application and guard simplifications and a variadic public
certificate interface. The paper identifies this contribution precisely.
comparison/manifest.json contains the exact original archive identities and
source-member paths. examples_manifest.json and the migrated-fixture manifest
record certificate provenance and transformations.
