"""Migrate and recheck the shared-transition draft's 256 frozen fixtures.

Migration changes the root from [context,goal,proof] to
[goal,proof,*hypotheses] and removes 'use' only at certificate positions.
It does not normalize formulas, numerical terms, equality motives, or witness
payloads. Invalid fields remain invalid. The fixture files are parsed as JSON;
they are never evaluated or imported as Python.

The source corpus and expected results are credited to ProveIt's supplied
ipra_shared_transition_2026-11-06/validation/manifest.json and its fixture
files. Source manifest/checker hashes are pinned below. This new migration
runner is untrusted support; the candidate checker never imports it.

Create the migrated corpus and compare old/new outcomes:
  python3 fixture_regression.py --baseline SOURCE_DRAFT --checker checker.py \
      --output validation/migrated

Recheck the delivered corpus without the original draft:
  python3 fixture_regression.py --verify validation/migrated --checker checker.py

This is finite regression evidence, not a proof-assistant verification.
"""

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys


SOURCE_MANIFEST_SHA256 = "f04333aa4e513940fb2cc6a7476f64656f961bd59b39d798d83e14c71406a22d"
SOURCE_PRIMARY_SHA256 = "85fdff0eade03c0c74e864a083f4ee2ecea79b78a8a64656c16cfc0d958f40f2"
SOURCE_STRICT_SHA256 = "d49c8cd1ed1cff892908cf097df5e28b13abcd2911f87b28c52edb18e59df837"
SOURCE_COUNT = 256


def ensure(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(data):
    return (json.dumps(data, ensure_ascii=True, separators=(",", ":")) + "\n").encode("utf-8")


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")


def load_checker(name, path, expected_sha256=None):
    path = path.resolve()
    actual = sha256(path.read_bytes())
    if expected_sha256 is not None:
        ensure(actual == expected_sha256, "Changed checker: " + str(path))
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, actual


def accepts(checker, data, old_interface=False):
    try:
        if old_interface:
            # The frozen source contract explicitly returns True on success.
            return checker.check(data) is True
        checker.check(*data)
        return True
    except Exception:
        return False


def migrate_proof(proof, counts):
    """Visit known proof children only; never rewrite embedded syntax/payloads."""
    if type(proof) is not list or not proof:
        return proof
    tag = proof[0]
    if tag in ("lam", "pack", "nat") and len(proof) == 3:
        counts["introduction_nodes"] += 1
        return [tag, proof[1], migrate_proof(proof[2], counts)]
    if tag == "use":
        counts["removed_use_tags"] += 1
        parts = list(proof[1:])
        if parts:
            parts[0] = migrate_proof(parts[0], counts)
        # There are two well-formed elimination layouts. A three-item tail has
        # a motive or witness in its middle slot, which must remain untouched.
        if len(parts) in (2, 3):
            parts[-1] = migrate_proof(parts[-1], counts)
        return parts
    # A computation certificate is also a numerical term. Its subexpressions
    # are not proofs. Unknown/malformed proof forms are preserved verbatim.
    return proof


def migrate_data(data):
    counts = Counter()
    if type(data) is not list or len(data) != 3 or type(data[0]) is not list:
        # No source sequent is declared by a malformed root. Preserve it without
        # repairing or silently flattening an invalid context. An accidental
        # new acceptance would be reported as a regression. The pinned 256-file
        # corpus has no malformed roots; separate CLI tests cover that boundary.
        return data, {"root": "unchanged_malformed_root", "removed_use_tags": 0}
    context, goal, proof = data
    result = [goal, migrate_proof(proof, counts), *context]
    ensure(result[0] == goal and result[2:] == context, "Migration changed the declared sequent")
    return result, {"root": "flattened", **dict(counts)}


def source_path(root, relative):
    path = (root / "validation" / relative).resolve()
    ensure(path.is_relative_to(root), "Source path escapes the selected draft")
    return path


def fixture_relative(value):
    path = Path(value)
    ensure(not path.is_absolute() and len(path.parts) >= 2,
           "Fixture path must be relative")
    ensure(path.parts[0] == "fixtures" and ".." not in path.parts and path.suffix == ".json",
           "Unexpected fixture path: " + value)
    return path


def summary(checker_sha256, rows, failures):
    return {
        "status": "passed" if not failures else "failed",
        "checker_sha256": checker_sha256,
        "total": len(rows),
        "accepted": sum(row["candidate_accepted"] for row in rows),
        "rejected": sum(not row["candidate_accepted"] for row in rows),
        "failures": failures,
    }


def migrate(options):
    root = options.baseline.resolve()
    destination = options.output.resolve()
    manifest_path = root / "validation" / "manifest.json"
    manifest_raw = manifest_path.read_bytes()
    ensure(sha256(manifest_raw) == SOURCE_MANIFEST_SHA256, "Changed frozen source manifest")
    original = json.loads(manifest_raw)
    ensure(original["total"] == SOURCE_COUNT and len(original["fixtures"]) == SOURCE_COUNT,
           "Unexpected frozen fixture count")
    ensure((destination / "manifest.json").resolve() != manifest_path.resolve(),
           "Output would overwrite the source manifest")

    original_primary, primary_hash = load_checker(
        "frozen_fixture_primary", source_path(root, original["kernels"]["primary"]["file"]),
        SOURCE_PRIMARY_SHA256)
    original_strict, strict_hash = load_checker(
        "frozen_fixture_strict", source_path(root, original["kernels"]["strict"]["file"]),
        SOURCE_STRICT_SHA256)
    candidate, candidate_hash = load_checker("fixture_candidate", options.checker)
    entries, rows, failures = [], [], []
    groups = {}
    seen = set()

    for entry in original["fixtures"]:
        relative = fixture_relative(entry["file"])
        ensure(str(relative) not in seen, "Duplicate fixture path")
        seen.add(str(relative))
        original_file = source_path(root, str(relative))
        raw = original_file.read_bytes()
        ensure(sha256(raw) == entry["sha256"], "Changed source fixture: " + entry["name"])
        data = json.loads(raw)
        old_ok = accepts(original_primary, data, True)
        old_strict_ok = accepts(original_strict, data, True)
        if old_ok != entry["expected"]["primary"]:
            failures.append({"name": entry["name"], "check": "source_primary_status"})
        if old_strict_ok != entry["expected"]["strict"]:
            failures.append({"name": entry["name"], "check": "source_strict_status"})

        migrated, conversion = migrate_data(data)
        new_ok = accepts(candidate, migrated)
        expected = entry["expected"]["primary"]
        if new_ok != expected:
            failures.append({"name": entry["name"], "check": "candidate_status"})
        migrated_raw = encode(migrated)
        new_file = destination / relative
        ensure(new_file.resolve() != original_file, "Output would overwrite a source fixture")
        new_file.parent.mkdir(parents=True, exist_ok=True)
        new_file.write_bytes(migrated_raw)
        entries.append({
            "name": entry["name"], "group": entry["group"],
            "file": relative.as_posix(), "sha256": sha256(migrated_raw),
            "expected": expected, "source_sha256": entry["sha256"],
            "source_expected": entry["expected"], "migration": conversion,
        })
        rows.append({"name": entry["name"], "source_primary_accepted": old_ok,
                     "source_strict_accepted": old_strict_ok, "candidate_accepted": new_ok})
        group = groups.setdefault(entry["group"],
                                  {"count": 0, "source_primary_accept": 0,
                                   "source_strict_accept": 0, "candidate_accept": 0})
        group["count"] += 1
        group["source_primary_accept"] += old_ok
        group["source_strict_accept"] += old_strict_ok
        group["candidate_accept"] += new_ok

    for name, previous in original["groups"].items():
        group = groups.get(name, {})
        if (group.get("count") != previous["count"]
                or group.get("source_primary_accept") != previous["primary_accept"]
                or group.get("source_strict_accept") != previous["strict_accept"]):
            failures.append({"group": name, "check": "source_group_totals"})

    provenance = {
        "repository": original["repository"], "draft": "ipra_shared_transition_2026-11-06",
        "source_manifest_sha256": sha256(manifest_raw),
        "source_primary_sha256": primary_hash, "source_strict_sha256": strict_hash,
        "historical_snapshot_in_source_manifest": original.get("snapshot_commit"),
        "earlier_corpus_provenance": original.get("source_provenance"),
    }
    manifest = {
        "format_version": 1, "checker_sha256": candidate_hash,
        "migration_script_sha256": sha256(Path(__file__).read_bytes()),
        "source_provenance": provenance,
        "encoding": "UTF-8 JSON; [goal,proof,*hypotheses]; bare proof application; one newline",
        "migration": "Only root layout and elimination proof tags change. Formulas, terms, motives, witnesses, invalid fields, and context order remain unchanged.",
        "total": len(entries), "groups": groups, "fixtures": entries,
        "qualification": "Frozen finite regression evidence. The runner and fixture migration are untrusted support, not part of the acceptance kernel.",
    }
    write_json(destination / "manifest.json", manifest)
    report = {**summary(candidate_hash, rows, failures),
              "python_version": platform.python_version(),
              "manifest_sha256": sha256((destination / "manifest.json").read_bytes()),
              "source_provenance": provenance, "groups": groups, "rows": rows}
    write_json(options.report or destination / "results.json", report)
    print(json.dumps(summary(candidate_hash, rows, failures), indent=2))
    return not failures


def verify(options):
    root = options.verify.resolve()
    manifest_raw = (root / "manifest.json").read_bytes()
    manifest = json.loads(manifest_raw)
    candidate, candidate_hash = load_checker("fixture_candidate", options.checker,
                                              manifest["checker_sha256"])
    rows, failures = [], []
    for entry in manifest["fixtures"]:
        path = root / fixture_relative(entry["file"])
        raw = path.read_bytes()
        ensure(sha256(raw) == entry["sha256"], "Changed migrated fixture: " + entry["name"])
        accepted = accepts(candidate, json.loads(raw))
        if accepted != entry["expected"]:
            failures.append({"name": entry["name"], "check": "candidate_status"})
        rows.append({"name": entry["name"], "candidate_accepted": accepted})
    ensure(len(rows) == manifest["total"] == SOURCE_COUNT, "Fixture count changed")
    report = {**summary(candidate_hash, rows, failures),
              "python_version": platform.python_version(),
              "manifest_sha256": sha256(manifest_raw), "rows": rows}
    if options.report:
        write_json(options.report, report)
    print(json.dumps(summary(candidate_hash, rows, failures), indent=2))
    return not failures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    operation = parser.add_mutually_exclusive_group(required=True)
    operation.add_argument("--baseline", type=Path,
                           help="Original extracted shared-transition draft root")
    operation.add_argument("--verify", type=Path,
                           help="Previously migrated directory containing manifest.json")
    parser.add_argument("--checker", required=True, type=Path)
    parser.add_argument("--output", type=Path, help="Migrated corpus output directory")
    parser.add_argument("--report", type=Path, help="Optional JSON result path")
    options = parser.parse_args()
    if options.baseline and not options.output:
        parser.error("--baseline requires --output")
    if options.verify and options.output:
        parser.error("--output is only used for migration")
    return migrate(options) if options.baseline else verify(options)


if __name__ == "__main__":
    raise SystemExit(0 if main() else 1)
