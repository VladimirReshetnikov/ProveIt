"""Independent finite validation of a reduced full-iPRA certificate checker.

Adapted from the supplied shared-transition draft's standalone auditor, which
credits the inferred-elimination draft for the named-binder oracle design.
There is no runtime dependency on either source. The separate reference rule
interpreter, strict-witness reconstruction, and boundary tests cover the local
numerical rule, uniform application, inferred existential elimination, and
demanded-only universal witness validation. This auditor never calls the
target's substitution or inference routine while deriving reference results.

Only the target checker is imported for comparison; the oracle does not use
its substitution, scope table, inference code or any proof generator.
Finite tests support code review; they are not a formal correctness proof.
"""

import argparse
import hashlib
import importlib.util
import itertools
import json
import random
import subprocess
import sys
import tempfile
from pathlib import Path


ZERO = -1
ONE = ["s", ZERO]
TRUE = ["=", ZERO, ZERO]
FALSE = ["=", ZERO, ONE]


def valid(a, formula):
    if not formula and type(a) is int:
        return a >= -1
    if type(a) is not list or not a or type(a[0]) is not str:
        return False
    tag = a[0]
    if formula:
        if tag == "=":
            return len(a) == 3 and valid(a[1], False) and valid(a[2], False)
        if tag == "pi":
            return len(a) == 3 and valid(a[1], True) and valid(a[2], True)
        if tag == "ex":
            return len(a) == 2 and valid(a[1], True)
    else:
        if tag == "s":
            return len(a) == 2 and valid(a[1], False)
        if tag == "r":
            return len(a) == 4 and all(valid(t, False) for t in a[1:])
    return False


fresh = itertools.count()


def named(a, stack=()):
    """Resolve indices into fresh binder identities and named free variables."""
    if type(a) is int:
        if a == ZERO:
            return ("zero",)
        return ("bound", stack[a]) if a < len(stack) else ("free", a - len(stack))
    tag = a[0]
    if tag == "s":
        return ("succ", named(a[1], stack))
    if tag == "r":
        state, counter = next(fresh), next(fresh)
        return ("rec", named(a[1], stack), named(a[2], stack), state, counter,
                named(a[3], (state, counter, *stack)))
    if tag == "=":
        return ("equal", named(a[1], stack), named(a[2], stack))
    variable = next(fresh)
    if tag == "pi":
        return ("all", variable, named(a[1], (variable, *stack)),
                named(a[2], (variable, *stack)))
    if tag == "ex":
        return ("exists", variable, named(a[1], (variable, *stack)))
    raise ValueError("invalid named input")


def indices(a, stack=()):
    tag = a[0]
    if tag == "zero":
        return ZERO
    if tag == "bound":
        return stack.index(a[1])
    if tag == "free":
        return a[1] + len(stack)
    if tag == "succ":
        return ["s", indices(a[1], stack)]
    if tag == "rec":
        return ["r", indices(a[1], stack), indices(a[2], stack),
                indices(a[5], (a[3], a[4], *stack))]
    if tag == "equal":
        return ["=", indices(a[1], stack), indices(a[2], stack)]
    if tag == "all":
        return ["pi", indices(a[2], (a[1], *stack)),
                indices(a[3], (a[1], *stack))]
    if tag == "exists":
        return ["ex", indices(a[2], (a[1], *stack))]
    raise ValueError("invalid named expression")


def replace_named(a, replacements, delta):
    tag = a[0]
    if tag == "free":
        i = a[1]
        if i < len(replacements):
            if replacements[i] is None:
                raise ValueError("deleted variable occurs")
            return replacements[i]
        return ("free", i + delta)
    if tag in ("zero", "bound"):
        return a
    if tag in ("succ",):
        return (tag, replace_named(a[1], replacements, delta))
    if tag == "rec":
        return (tag, replace_named(a[1], replacements, delta),
                replace_named(a[2], replacements, delta), a[3], a[4],
                replace_named(a[5], replacements, delta))
    if tag == "equal":
        return (tag, replace_named(a[1], replacements, delta),
                replace_named(a[2], replacements, delta))
    if tag == "all":
        return (tag, a[1], replace_named(a[2], replacements, delta),
                replace_named(a[3], replacements, delta))
    if tag == "exists":
        return (tag, a[1], replace_named(a[2], replacements, delta))
    raise ValueError("invalid named expression")


def oracle(a, env=(1,), depth=0, formula=True):
    if not valid(a, formula):
        raise ValueError("invalid syntax")
    stack = tuple(next(fresh) for _ in range(depth))
    replacements = [None if t is None else named(t) for t in env[:-1]]
    return indices(replace_named(named(a, stack), replacements, env[-1]), stack)


def term(rng, height=3):
    if height == 0 or rng.randrange(3) == 0:
        return rng.randrange(-1, 9)
    if rng.randrange(2) == 0:
        return ["s", term(rng, height - 1)]
    return ["r", term(rng, height - 1), term(rng, height - 1),
            term(rng, height - 1)]


def formula(rng, height=3):
    if height == 0 or rng.randrange(3) == 0:
        return ["=", term(rng, 2), term(rng, 2)]
    if rng.randrange(2) == 0:
        return ["pi", formula(rng, height - 1), formula(rng, height - 1)]
    return ["ex", formula(rng, height - 1)]


def succeeds(function, *args, **kwargs):
    try:
        return True, function(*args, **kwargs)
    except Exception:
        return False, None


from collections import Counter
import platform


def ensure(condition):
    if not condition:
        raise ValueError("independent reference rejected certificate")


def checked(expression, is_formula):
    ensure(valid(expression, is_formula))
    return expression


def free_zero_in_named(expression):
    if not isinstance(expression, tuple):
        return False
    if expression[0] == "free":
        return expression[1] == 0
    return any(free_zero_in_named(child) for child in expression[1:])


def reference_infer(proof, context, counts, strict_witness):
    """Explicit rule interpreter; all variable operations use named binders."""
    if type(proof) in (int, bool):
        ensure(-len(context) <= proof < len(context))
        counts["assumption"] += 1
        return context[proof]
    ensure(type(proof) is list and proof and type(proof[0]) is str)
    tag = proof[0]
    if tag == "lam":
        ensure(len(proof) == 3)
        guard = checked(proof[1], True)
        local = [oracle(a) for a in context] + [guard]
        result = reference_infer(proof[2], local, counts, strict_witness)
        counts["guarded_universal_introduction"] += 1
        return ["pi", guard, result]
    if tag == "pack":
        ensure(len(proof) == 3)
        witness = checked(proof[1], False)
        guard = ["=", 0, oracle(witness, formula=False)]
        local = [oracle(a) for a in context] + [guard]
        result = reference_infer(proof[2], local, counts, strict_witness)
        counts["existential_introduction"] += 1
        return ["ex", result]
    if tag == "nat":
        ensure(len(proof) == 3)
        matrix = checked(proof[1], True)
        base = oracle(matrix, [ZERO, 0])
        guard = matrix if matrix[0] == "=" else base
        local = [oracle(a) for a in context] + [guard]
        expected_step = oracle(matrix, [["s", 0], 0])
        ensure(reference_infer(proof[2], local, counts, strict_witness) == expected_step)
        counts["equation_induction" if matrix[0] == "=" else "numerical_cases"] += 1
        return ["pi", base, matrix]
    if tag == "use":
        ensure(len(proof) >= 2)
        principal = reference_infer(proof[1], context, counts, strict_witness)
        if principal[0] == "ex":
            ensure(len(proof) == 3)
            local = [oracle(a) for a in context] + [principal[1]]
            branch = reference_infer(proof[2], local, counts, strict_witness)
            result = oracle(branch, [None, -1])
            counts["existential_elimination"] += 1
            return result
        ensure(len(proof) == 4)
        if principal[0] == "pi":
            used = any(free_zero_in_named(named(child)) for child in principal[1:])
            if strict_witness or used:
                witness = checked(proof[2], False)
            else:
                # An unused payload is not an object-language term. Choosing
                # zero reconstructs an ordinary, fully typed proof of this rule.
                witness = ZERO
            antecedent = oracle(principal[1], [witness, -1])
            result = oracle(principal[2], [witness, -1])
            counts["guarded_universal_elimination"] += 1
        else:
            ensure(principal[0] == "=")
            motive = checked(proof[2], True)
            antecedent = oracle(motive, [principal[1], -1])
            result = oracle(motive, [principal[2], -1])
            counts["equality_transport"] += 1
        ensure(reference_infer(proof[3], context, counts, strict_witness) == antecedent)
        return result
    if tag == "r":
        checked(proof, False)
        counter, initial, update = proof[1:]
        if counter == ZERO:
            result = initial
            counts["recursor_zero"] += 1
        else:
            ensure(type(counter) is list and len(counter) == 2 and counter[0] == "s")
            predecessor = counter[1]
            previous = ["r", predecessor, initial, update]
            result = oracle(update, [previous, predecessor, -2], formula=False)
            counts["recursor_successor"] += 1
        return ["=", proof, result]
    raise ValueError("unrecognized proof constructor")


def reference_check(data, strict_witness=False):
    ensure(type(data) is list and len(data) == 3)
    context, goal, proof = data
    ensure(type(context) is list)
    for expression in context + [goal]:
        checked(expression, True)
    counts = Counter()
    ensure(reference_infer(proof, context, counts, strict_witness) == goal)
    return counts


def reflexivity(t):
    """A finite derived proof, built without calling the checker under audit."""
    rec = ["r", ZERO, t, ZERO]
    motive = ["=", 0, oracle(t, (1,), formula=False)]
    return ["use", rec, motive, rec]


def application_proof(proof, application_format="bare"):
    """Translate only certificate positions; formula and term data stay exact."""
    if type(proof) is not list or not proof:
        return proof
    if proof[0] in ("lam", "pack", "nat") and len(proof) == 3:
        return [proof[0], proof[1], application_proof(proof[2], application_format)]
    if proof[0] != "use":
        return proof
    parts = proof[1:]
    if parts:
        parts[0] = application_proof(parts[0], application_format)
    if len(parts) >= 2:
        parts[-1] = application_proof(parts[-1], application_format)
    return parts if application_format == "bare" else ["use", *parts]


def tagged_proof(proof, application_format="bare"):
    """Inverse presentation translation for well-formed corpus certificates."""
    if application_format == "tagged" or type(proof) is not list or not proof:
        return proof
    if proof[0] in ("lam", "pack", "nat") and len(proof) == 3:
        return [proof[0], proof[1], tagged_proof(proof[2], application_format)]
    if proof[0] == "r":
        return proof
    parts = list(proof)
    parts[0] = tagged_proof(parts[0], application_format)
    if len(parts) >= 2:
        parts[-1] = tagged_proof(parts[-1], application_format)
    return ["use", *parts]


def normalize_strict(proof, context, replacements):
    """Reconstruct a typed witness at every vacuous universal elimination.

    All rule inspection and scope operations here use the separate named oracle.
    The returned tagged proof is subsequently checked with strict_witness=True.
    """
    if type(proof) in (int, bool):
        return proof
    ensure(type(proof) is list and proof)
    tag = proof[0]
    if tag in ("lam", "pack", "nat"):
        ensure(len(proof) == 3)
        annotation = proof[1]
        if tag == "pack":
            guard = ["=", 0, oracle(checked(annotation, False), formula=False)]
        else:
            checked(annotation, True)
            guard = (oracle(annotation, [ZERO, 0])
                     if tag == "nat" and annotation[0] != "=" else annotation)
        local = [oracle(a) for a in context] + [guard]
        return [tag, annotation, normalize_strict(proof[2], local, replacements)]
    if tag == "use":
        principal_proof = normalize_strict(proof[1], context, replacements)
        principal = reference_infer(principal_proof, context, Counter(), True)
        if principal[0] == "ex":
            ensure(len(proof) == 3)
            local = [oracle(a) for a in context] + [principal[1]]
            return [tag, principal_proof,
                    normalize_strict(proof[2], local, replacements)]
        ensure(len(proof) == 4)
        annotation = proof[2]
        if principal[0] == "pi":
            used = any(free_zero_in_named(named(a)) for a in principal[1:])
            if not used:
                if not valid(annotation, False):
                    replacements["malformed_vacuous_witnesses"] += 1
                replacements["vacuous_witnesses"] += 1
                annotation = ZERO
        return [tag, principal_proof, annotation,
                normalize_strict(proof[3], context, replacements)]
    ensure(tag == "r")
    return proof


def run(options):
    path = options.checker.resolve()
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("checker_under_audit", path)
    target = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(target)
    counts = Counter()
    failures = []
    reference_rules = Counter()
    reconstruction_counts = Counter()
    certificate_records = []

    def target_input(data):
        context, goal, proof = data
        return [goal, application_proof(proof, options.application_format), *context]

    def target_check(data):
        return target.check(*target_input(data))

    def test(category, name, condition):
        counts[category] += 1
        if not condition:
            failures.append({"category": category, "name": name})

    def certificate(name, data, expected, category="certificates"):
        accepted, _ = succeeds(target_check, data)
        test(category, name, accepted == expected)
        ref_ok, rules = succeeds(reference_check, data, options.strict_witness)
        test("reference_rule_interpreter", name, ref_ok == expected)
        if ref_ok:
            reference_rules.update(rules)
            context, goal, proof = data
            normalized_ok, normalized = succeeds(normalize_strict, proof, context,
                                                  reconstruction_counts)
            strict_ok, strict_counts = (succeeds(reference_check,
                [context, goal, normalized], True) if normalized_ok else (False, None))
            test("strict_witness_reconstruction", name, strict_ok)
            normalized_target_ok, _ = (succeeds(target_check,
                [context, goal, normalized]) if normalized_ok else (False, None))
            test("reconstructed_candidate", name, normalized_target_ok)
        certificate_records.append({"name": name, "expected": expected,
                                    "candidate_accepted": accepted,
                                    "reference_accepted": ref_ok})

    rng = random.Random(617352)
    expressions = []
    for _ in range(64):
        expressions.extend([(term(rng, 3), False), (formula(rng, 3), True)])
    for index, (expression, sort) in enumerate(expressions):
        for depth in range(4):
            environments = [(0,), (1,), [ZERO, -1],
                            [term(rng, 2), term(rng, 2), -2]]
            for j, environment in enumerate(environments):
                expected = oracle(expression, environment, depth, sort)
                ok, actual = succeeds(target.subst, expression, environment, depth, formula=sort)
                test("named_substitution", f"{index}:{depth}:{j}", ok and actual == expected)
            ref_ok, expected = succeeds(oracle, expression, [None, -1], depth, sort)
            ok, actual = succeeds(target.subst, expression, [None, -1], depth, formula=sort)
            test("partial_variable_deletion", f"{index}:{depth}",
                 ok == ref_ok and (not ok or actual == expected))
            lifted = oracle(expression, (1,), depth, sort)
            ok, actual = succeeds(target.subst, lifted, [None, -1], depth, formula=sort)
            test("lift_delete_roundtrip", f"{index}:{depth}", ok and actual == expression)

    bad_atoms = [None, True, False, -2, -100, -1.0, 0.0, 1.0, 0.5,
                 "", "s", "r", "=", "pi", "ex", {}, {"s": -1}]
    seeds = [ZERO, 0, 1, TRUE, ["s", ZERO], ["ex", TRUE], [], *bad_atoms]
    grammar_cases = list(seeds) + [a for a, _ in expressions]
    shapes = {"s": [ZERO], "r": [ZERO, ZERO, ZERO],
              "=": [ZERO, ZERO], "pi": [TRUE, TRUE], "ex": [TRUE]}
    for tag, parts in shapes.items():
        grammar_cases.extend([[tag], [tag, *parts], [tag, *parts, ZERO], [tag, *parts[:-1]]])
        for position in range(len(parts)):
            for bad in seeds:
                changed = parts.copy()
                changed[position] = bad
                grammar_cases.append([tag, *changed])
        grammar_cases.extend([["unknown", *parts], {tag: parts}])
    # Strings/dictionary keys are not object-language leaves, even though the
    # compact walker uses general unpacking rather than an explicit list test.
    grammar_cases.extend(["ss", "rr", "ex=", {"s": 0, "r": 1},
                          {"=": 0, "pi": 1, "ex": 2}])
    for index, expression in enumerate(grammar_cases):
        for sort in (False, True):
            ok, _ = succeeds(target.subst, expression, formula=sort)
            test("syntax_grammar", f"{index}:{sort}", ok == valid(expression, sort))
        if not valid(expression, True):
            ok, _ = succeeds(target_check, [[expression], TRUE, 0])
            test("malformed_statement_boundary", f"context:{index}", not ok)
            ok, _ = succeeds(target_check, [[TRUE], expression, 0])
            test("malformed_statement_boundary", f"goal:{index}", not ok)

    proof_true = reflexivity(ZERO)
    certificate("literal hypothesis", [[TRUE], TRUE, 0], True)
    certificate("negative hypothesis index", [[FALSE, TRUE], TRUE, -1], True)
    certificate("boolean hypothesis index", [[FALSE, TRUE], TRUE, True], True)
    certificate("float hypothesis index rejected", [[TRUE], TRUE, 0.0], False)
    certificate("out of range hypothesis", [[TRUE], TRUE, 1], False)
    certificate("empty context cannot assert falsity", [[], FALSE, 0], False)
    certificate("derived closed reflexivity", [[], TRUE, proof_true], True)
    certificate("derived parameter reflexivity", [[], ["=", 0, 0], reflexivity(0)], True)
    certificate("guarded universal identity", [[], ["pi", ["=", 0, ZERO], ["=", 0, ZERO]],
                ["lam", ["=", 0, ZERO], -1]], True)
    certificate("retained context shifted", [[["=", 0, ZERO]], ["pi", TRUE, ["=", 1, ZERO]],
                ["lam", TRUE, 0]], True)
    certificate("retained context capture rejected", [[["=", 0, ZERO]], ["pi", TRUE, ["=", 0, ZERO]],
                ["lam", TRUE, 0]], False)
    certificate("existential witnessed equation", [[], ["ex", ["=", 0, ONE]],
                ["pack", ONE, -1]], True)
    certificate("parameter witness shifted", [[], ["ex", ["=", 0, 1]],
                ["pack", 0, -1]], True)
    certificate("parameter witness capture rejected", [[], ["ex", ["=", 0, 0]],
                ["pack", 0, -1]], False)

    ex = ["ex", ["=", 0, ZERO]]
    certificate("existential witness escape rejected", [[ex], TRUE, ["use", 0, -1]], False)
    certificate("existential retains old parameter", [[ex, ["=", 0, ZERO]], ["=", 0, ZERO],
                ["use", 0, 1]], True)
    certificate("existential vacuous conclusion", [[ex], TRUE, ["use", 0, proof_true]], True)
    certificate("existential missing branch", [[ex], TRUE, ["use", 0]], False)
    certificate("existential extra conclusion annotation", [[ex, TRUE], TRUE, ["use", 0, TRUE, 1]], False)
    nested_bodies = [["pi", TRUE, ["=", 1, ZERO]], ["ex", ["=", 1, ZERO]],
                     ["=", ["r", ZERO, ZERO, 2], ZERO],
                     ["ex", ["=", ["r", ZERO, ZERO, 3], ZERO]],
                     ["pi", ["=", 1, ZERO], TRUE]]
    for index, body in enumerate(nested_bodies):
        escaped_goal = oracle(body, [ZERO, -1])
        certificate(f"nested witness escape {index}", [[["ex", body]], escaped_goal,
                    ["use", 0, -1]], False, "nested_scope_deletion")
        vacuous = ["ex", oracle(body, (1,))]
        certificate(f"nested old variable retained {index}", [[vacuous], body,
                    ["use", 0, -1]], True, "nested_scope_deletion")

    rec0 = ["r", ZERO, 0, ["r", 1, 0, ["s", 2]]]
    certificate("recursion zero nested update", [[], ["=", rec0, 0], rec0], True)
    old = ["r", 2, 1, ["r", 1, 0, ["s", 2]]]
    rec1 = ["r", ["s", 2], 1, ["r", 1, 0, ["s", 2]]]
    lifted_old = ["r", 4, 3, ["r", 1, 0, ["s", 2]]]
    updated = ["r", 2, old, ["s", lifted_old]]
    certificate("recursion successor simultaneous binding", [[], ["=", rec1, updated], rec1], True)
    for counter in (0, 1, ["r", ZERO, ZERO, ZERO]):
        rec = ["r", counter, ZERO, ZERO]
        certificate("nonconstructor counter " + repr(counter), [[], ["=", rec, ZERO], rec], False)
    for index, bad in enumerate(bad_atoms + [TRUE, ["s"], ["r", ZERO, ZERO]]):
        malformed = ["r", ZERO, ZERO, bad]
        certificate(f"unused bad recursor body cannot disappear {index}",
                    [[], TRUE, ["use", malformed, TRUE, proof_true]], False, "strict_formation")
        certificate(f"unused malformed packed witness {index}",
                    [[], ["ex", TRUE], ["pack", bad, proof_true]], False, "strict_formation")

    # Explicit equation induction whose step uses the local hypothesis.
    identity = ["r", 0, ZERO, ["s", 0]]
    matrix = ["=", identity, 0]
    successor = ["r", ["s", 0], ZERO, ["s", 0]]
    motive = ["=", oracle(successor, (1,), formula=False), ["s", 0]]
    certificate("local equation induction uses its hypothesis",
                [[], ["pi", oracle(matrix, [ZERO, 0]), matrix],
                 ["nat", matrix, ["use", -1, motive, successor]]], True, "numerical_rules")

    matrices = [["=", 0, 1], ["=", identity, 0], ["ex", ["=", 1, 2]],
                ["pi", TRUE, ["=", 1, 1]], ["pi", ["=", 1, ZERO], TRUE]]
    for _ in range(12):
        matrices.append(formula(rng, 2))
    for index, matrix in enumerate(matrices):
        base = oracle(matrix, [ZERO, 0])
        successor = oracle(matrix, [["s", 0], 0])
        goal = ["pi", base, matrix]
        local_guard = matrix if matrix[0] == "=" else base
        correct_step = ["pi", local_guard, successor]
        # The retained hypothesis is a quantified step. It is opened at the
        # fresh local number and applied to the freshly added local guard.
        certificate(f"correct local numerical guard {index}",
                    [[correct_step], goal, ["nat", matrix, ["use", 0, 0, -1]]],
                    True, "numerical_rules")
        if matrix[0] != "=" and matrix != base:
            forbidden_step = ["pi", matrix, successor]
            certificate(f"quantified induction rejected {index}",
                        [[forbidden_step], goal, ["nat", matrix, ["use", 0, 0, -1]]],
                        False, "numerical_rules")
    certificate("missing local numerical premise", [[], ["pi", TRUE, TRUE],
                ["nat", TRUE]], False, "numerical_rules")

    # Broad proof annotations are harmless only when the universal binder is
    # absent from both components. Invalid syntax is never allowed in a claim.
    malformed_witnesses = [None, False, True, -2, -1.0, 0.0, "unused", {}, [],
                           TRUE, ["s"], ["r", ZERO, ZERO, None]]
    vacant = ["pi", TRUE, TRUE]
    for index, bad in enumerate(malformed_witnesses):
        certificate(f"vacuous universal ignores payload {index}",
                    [[vacant, TRUE], TRUE, ["use", 0, bad, 1]],
                    not options.strict_witness, "witness_demand")
        antecedent_only = ["pi", ["=", 0, ZERO], TRUE]
        certificate(f"antecedent demands valid witness {index}",
                    [[antecedent_only, TRUE], TRUE, ["use", 0, bad, 1]],
                    False, "witness_demand")
        consequent_only = ["pi", TRUE, ["=", 0, 0]]
        certificate(f"consequent demands valid witness {index}",
                    [[consequent_only, TRUE], TRUE, ["use", 0, bad, 1]],
                    False, "witness_demand")
        nested = ["pi", TRUE, ["ex", ["=", 1, ZERO]]]
        certificate(f"nested binder demands valid witness {index}",
                    [[nested, TRUE], ["ex", TRUE], ["use", 0, bad, 1]],
                    False, "witness_demand")
        update = ["=", ["r", ZERO, ZERO, 2], ZERO]
        nested_update = ["pi", TRUE, update]
        certificate(f"semantically unused update demands witness {index}",
                    [[nested_update, TRUE], oracle(update, [ZERO, -1]),
                     ["use", 0, bad, 1]], False, "witness_demand")
    old_parameter = ["=", 1, 1]
    certificate("vacuous witness still lowers old parameters",
                [[["pi", old_parameter, old_parameter], ["=", 0, 0]], ["=", 0, 0],
                 ["use", 0, None, 1]], not options.strict_witness, "witness_demand")
    inner_only = ["ex", ["=", 0, ZERO]]
    certificate("inner bound variable does not demand outer witness",
                [[["pi", TRUE, inner_only], TRUE], inner_only, ["use", 0, None, 1]],
                not options.strict_witness, "witness_demand")
    certificate("well formed witness in nonvacuous implication",
                [[["pi", ["=", 0, ZERO], ["=", 0, 0]], TRUE], TRUE,
                 ["use", 0, ZERO, 1]], True, "witness_demand")

    corpus_records = []
    if options.corpus:
        for file in sorted(options.corpus.rglob("*.json")):
            data = json.loads(file.read_text())
            if options.corpus_format == "current":
                goal, proof, *context = data
                data = [context, goal, tagged_proof(proof, options.application_format)]
            certificate("corpus " + str(file.relative_to(options.corpus)), data, True, "corpus")
            corpus_records.append({"file": str(file.relative_to(options.corpus)),
                                   "sha256": hashlib.sha256(file.read_bytes()).hexdigest()})

    cli_cases = [
        ("valid", json.dumps(target_input([[TRUE], TRUE, 0])), True),
        ("falsity", json.dumps(target_input([[], FALSE, 0])), False),
        ("truncated", "[", False),
        ("null", "null", False),
        ("nan in claim", '[["=",NaN,0],0,["=",0,0]]', False),
        ("infinity in context", '[["=",0,0],0,["=",Infinity,0]]', False),
        ("boolean proof index", json.dumps(target_input([[FALSE, TRUE], TRUE, True])), True),
        ("vacuous null witness", json.dumps(target_input([[vacant, TRUE], TRUE, ["use", 0, None, 1]])),
         not options.strict_witness),
        ("empty root array", "[]", False),
        ("one-element root array", json.dumps([TRUE]), False),
        ("string root", '"not a certificate"', False),
        ("dictionary root", '{"goal":0,"proof":0}', False),
        ("float alias in goal", '[["=",0.0,0],0,["=",0,0]]', False),
        ("boolean alias in goal", '[["=",true,true],0,["=",1,1]]', False),
        ("unused malformed context", json.dumps(target_input([[TRUE, ["=", False, False]], TRUE, 0])), False),
    ]
    with tempfile.TemporaryDirectory(prefix="ipra-candidate-audit-") as temp:
        for label, source, expected in cli_cases:
            certificate_path = Path(temp) / "certificate.json"
            certificate_path.write_text(source)
            for flags, category in (([], "json_cli"), (["-O"], "optimized_json_cli")):
                result = subprocess.run([sys.executable, *flags, str(path), str(certificate_path)],
                                        text=True, capture_output=True, timeout=20)
                test(category, label, result.returncode == (0 if expected else 1)
                     and result.stdout.strip() == ("ACCEPT" if expected else "REJECT"))
        for flags, category in (([], "json_cli"), (["-O"], "optimized_json_cli")):
            for label, extra in (("missing filename", []),
                                 ("extra filename", [str(certificate_path), str(certificate_path)]),
                                 ("missing file", [str(Path(temp) / "does_not_exist.json")])):
                result = subprocess.run([sys.executable, *flags, str(path), *extra],
                                        text=True, capture_output=True, timeout=20)
                test(category, label, result.returncode == 1 and result.stdout.strip() == "REJECT")

    report = {
        "checker": str(path), "checker_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "audit_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "python_version": platform.python_version(), "seed": 617352,
        "strict_witness_mode": options.strict_witness,
        "application_format": options.application_format,
        "counts": dict(counts), "total_checks": sum(counts.values()),
        "certificate_cases": len(certificate_records),
        "reference_rule_nodes_in_accepted_certificates": sum(reference_rules.values()),
        "reference_rule_counts": dict(reference_rules),
        "reconstruction_counts": dict(reconstruction_counts),
        "failures": failures, "certificate_records": certificate_records,
        "corpus": corpus_records,
        "scope": "Finite implementation checks and an independently written explicit-rule interpreter with a named-binder substitution oracle. No proof-assistant verification or foundational correctness proof is claimed.",
        "oracle_attribution": "Adapted from ProveIt's supplied ipra_shared_transition_2026-11-06/validation/independent_audit.py, which credits ipra_inferred_elimination_2026-11-06/validation/audit.py at snapshot 02b045f9f8d7887b27b853520f2cbfa374725a76. Independent named-binder oracle and rule interpreter retained; strict witness reconstruction and reduced-interface checks added. No runtime import from either source.",
    }
    options.output.parent.mkdir(parents=True, exist_ok=True)
    options.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in (
        "checker_sha256", "strict_witness_mode", "counts", "total_checks",
        "certificate_cases", "reference_rule_nodes_in_accepted_certificates", "failures")}, indent=2))
    return not failures


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--strict-witness", action="store_true",
                        help="Use the strict control's eager witness validation contract")
    parser.add_argument("--corpus", type=Path,
                        help="Optional directory of additional positive JSON certificates")
    parser.add_argument("--corpus-format", choices=("legacy", "current"), default="legacy",
                        help="Legacy [context,goal,proof] or current [goal,proof,*hypotheses]")
    parser.add_argument("--application-format", choices=("bare", "tagged"), default="bare",
                        help="Candidate application [principal,...] or ['use',principal,...]")
    raise SystemExit(0 if run(parser.parse_args()) else 1)

