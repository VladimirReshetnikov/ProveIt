EXAMPLE CERTIFICATES

Each JSON file has the public format [goal, proof, *hypotheses]. Run it with:

    python3 checker.py examples/NAME.json

All 18 examples are accepted. They were mechanically translated from the
shared-transition draft's certificate set by deleting the application tag in
proof positions and repacking the outer sequent. All terms, formulas, motives,
witness payloads, and hypothesis order were preserved. Exact source and
translated hashes are in ../examples_manifest.json.

The examples cover the theory's nontrivial derived facts: equality reflexivity,
successor injectivity, coverage, a universally quantified existential theorem,
addition and truncated-difference identities, the residual equation, and both
directions of the arithmetic equality detector. Further logical and malformed
input examples are included in ../validation/migrated/fixtures/.
