"""Write checksums and a ZIP of the complete, already built deliverable."""

import hashlib
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex"}


def deliverable(path):
    return (path.is_file() and "__pycache__" not in path.parts
            and path.suffix not in EXCLUDED_SUFFIXES
            and not path.name.endswith(".synctex.gz"))


def main():
    required = ("report.pdf", "report.tex", "checker.py", "results/summary.json")
    for name in required:
        if not (ROOT / name).is_file():
            raise FileNotFoundError(name)
    manifest = ROOT / "MANIFEST.sha256"
    files = sorted(p for p in ROOT.rglob("*") if deliverable(p) and p != manifest)
    manifest.write_text("".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  "
                                + p.relative_to(ROOT).as_posix() + "\n" for p in files),
                        encoding="utf-8")
    files.append(manifest)
    target = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files):
            name = (Path(ROOT.name) / path.relative_to(ROOT)).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC verification failed")
        prefix = ROOT.name + "/"
        for line in archive.read(prefix + "MANIFEST.sha256").decode().splitlines():
            digest, name = line.split("  ", 1)
            if hashlib.sha256(archive.read(prefix + name)).hexdigest() != digest:
                raise ValueError("Archived manifest mismatch: " + name)
    print(target)
    print("files", len(files), "bytes", target.stat().st_size)
    print("sha256", hashlib.sha256(target.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
