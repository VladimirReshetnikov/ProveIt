REPRODUCIBLE SIZE COMPARISON

Place this directory at comparison/ beside the delivered checker.py. Run:

    python3 comparison/measure.py

This remeasures the complete delivered checker, all six unchanged current
primary sources, all retained ablation stages, and all 194 distinct nested
sources whose top-level function names include both infer and check. It uses
only the Python standard library and does not execute any measured program.
Its outputs are comparison/results/measurements.json and a compact console
summary. To measure another checker, pass --candidate PATH.

The recorded reference runtime is CPython 3.12.14. The exact runtime is written
into every result. Python AST and ast.unparse conventions are version-dependent;
reproducing on a different Python release may change normalized counts. All
files in a run are measured by the same parser and tokenizer.

PROVENANCE

The comparison is pinned to ProveIt commit:

    0a86fcbd7c5e0d6a541291b4ac06c7dc77989161

manifest.json records each original ZIP's exact filename, byte size, SHA-256,
Git blob SHA-1, commit-pinned URL, primary source member, and source SHA-256.
baselines/ contains the unchanged primary checker bytes. inventory.json records
all 1,042 Python source occurrences from those six archives, deduplicated into
272 exact-byte sources. The infer/check inventory filter selects 874 occurrences
and 194 distinct sources. inventory_sources/ retains those 194 source files,
named by their SHA-256. The normal comparison verifies and remeasures every one.
The filter is an inventory aid, not a claim that every selected source is a
sound, complete, or even intended production checker.

To independently reproduce archive provenance, put the original six ZIPs in a
directory under their exact filenames from manifest.json, then run:

    python3 comparison/measure.py --archives path/to/original-zips

That optional mode verifies every archive's byte size, SHA-256 and Git blob ID,
verifies each retained primary against the original member, and rescans every
Python member. It writes results/source_inventory.json. No network access is
used. Original ZIPs are unnecessary for the ordinary offline source comparison.

METRICS AND TRUST BOUNDARY

Every metric counts the whole standalone checker: imports, syntax tables,
literal constants, formation and scope checks, inference code, and the JSON/CLI
boundary. The standard Python runtime is treated identically for all programs.
No source is renamed, optimized, reduced to a fragment, or executed to measure
it. The four primary measures exclude comments and docstrings:

  ast_nodes: all nodes from ast.walk after removal of module/function/class
             docstrings, including the entire remaining application source;
  source_tokens: significant lexical tokens in the original source;
  normalized_tokens: significant tokens after ast.unparse;
  normalized_bytes: UTF-8 bytes of ast.unparse(tree) plus one final newline.

Significant tokens exclude comments, whitespace/layout tokens, and the removed
docstring spans. Exact raw bytes and hashes are also reported. Raw byte counts
include documentation and therefore are a secondary diagnostic.

All six primary sources have coordinatewise minimum:

    AST nodes 675; source tokens 636; normalized tokens 634;
    normalized bytes 2053; raw bytes 2205.

The included 194-source inventory has the same coordinatewise minimum. The
new normalized checker measures 650, 617, 615, and 1936 respectively. This is
a strict comparison with a finite set of supplied implementations. It is not
an absolute lower bound on all axiomatizations or all possible proof checkers.

ABLATION

Every ablation stage keeps the original shared-transition docstring, so changes
in its normalized counts cannot be explained by deleting documentation.
The exact shared source is stage 00. The retained subsequent files implement:

  01: variadic root [goal, proof, *hypotheses] and normal-return acceptance;
  02: the uniform draft's untagged application syntax;
  03: the local draft's direct guard expression;
  04: reuse the original input p instead of two recursor pattern aliases;
  05: omit an unused rejection diagnostic while preserving ValueError rejection.

ablation/steps.diff shows every transition. Already stage 01 is strictly below
all four primary minima. The final candidate's normalized hash is checked
against stage 05; a shorter published module docstring does not affect that
comparison. All stages retain validation of every public hypothesis and the
goal, full recursor validation, and the eigenvariable deletion check.

Every file in this directory is development evidence. The acceptance checker
imports none of these sources, manifests, measurement utilities, or results.
