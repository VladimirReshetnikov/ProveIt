"""Measure complete checker sources without executing any of them.

Default: measure the six frozen originals, retained ablation stages, and
../checker.py. With --archives DIR, also verify and scan the six original ZIPs.
Only the Python standard library is required. This file is development support;
no acceptance checker imports it.
"""

import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tokenize
import zipfile


ROOT = Path(__file__).resolve().parent
FIELDS = ("ast_nodes", "source_tokens", "normalized_tokens", "normalized_bytes", "raw_bytes")
PRIMARY = FIELDS[:-1]
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def count_tokens(source, omitted=()):
    return sum(token.type not in IGNORED and not any(
        start <= token.start and token.end <= end for start, end in omitted
    ) for token in tokenize.generate_tokens(io.StringIO(source).readline))


def measure_bytes(data):
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef)) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                spans.append(((first.lineno, first.col_offset),
                              (first.end_lineno, first.end_col_offset)))
                node.body = node.body[1:]
    normalized = ast.unparse(tree) + "\n"
    return {
        "sha256": hashlib.sha256(data).hexdigest(),
        "normalized_sha256": hashlib.sha256(normalized.encode("utf-8")).hexdigest(),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "source_tokens": count_tokens(source, spans),
        "normalized_tokens": count_tokens(normalized),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "raw_bytes": len(data),
        "top_level_functions": [n.name for n in tree.body if isinstance(n, ast.FunctionDef)],
        "top_level_imports": [ast.unparse(n) for n in tree.body
                              if isinstance(n, (ast.Import, ast.ImportFrom))],
    }


def frozen_source(item):
    result = measure_bytes((ROOT / item["source"]).read_bytes())
    if result["sha256"] != item["source_sha256"]:
        raise ValueError("Frozen source changed: " + item["source"])
    return {**item, **result}


def envelope(rows):
    return {key: min(row[key] for row in rows) for key in FIELDS}


def measure_inventory(manifest):
    data = (ROOT / manifest["inventory_file"]).read_bytes()
    if hashlib.sha256(data).hexdigest() != manifest["inventory_sha256"]:
        raise ValueError("Frozen inventory changed")
    inventory = json.loads(data)
    selected = [row for row in inventory["all_sources"]
                if {"infer", "check"} <= set(row["top_level_functions"])]
    measured = []
    for row in selected:
        path = ROOT / manifest["inventory_source_directory"] / (row["sha256"] + ".py")
        result = measure_bytes(path.read_bytes())
        if result["sha256"] != row["sha256"]:
            raise ValueError("Frozen inventory source changed: " + str(path))
        measured.append(result)
    return {
        "source": manifest["inventory_file"],
        "source_sha256": manifest["inventory_sha256"],
        "selected_occurrences": sum(len(row["occurrences"]) for row in selected),
        "selected_unique_hashes": len(measured),
        "selected_envelope": envelope(measured),
        "frozen_metrics_match_current_runtime": all(
            all(old[key] == new[key] for key in FIELDS + ("normalized_sha256",))
            for old, new in zip(selected, measured, strict=True)),
        "qualification": "Every selected distinct checker source is included and remeasured. Original archive occurrence counts are retained in the hash-verified inventory; use --archives to reconstruct their provenance from the six ZIPs.",
    }


def scan_archives(directory, manifest):
    sources = {}
    occurrences = 0
    for item in manifest["baselines"]:
        data = (directory / item["archive"]).read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        git_blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if (digest != item["archive_sha256"] or git_blob != item["archive_git_blob_sha1"]
                or len(data) != item["archive_bytes"]):
            raise ValueError("Archive identity mismatch: " + item["archive"])
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            if archive.read(item["member"]) != (ROOT / item["source"]).read_bytes():
                raise ValueError("Primary source differs from archive: " + item["archive"])
            for member in archive.namelist():
                if not member.endswith(".py"):
                    continue
                source = archive.read(member)
                digest = hashlib.sha256(source).hexdigest()
                if digest not in sources:
                    sources[digest] = {**measure_bytes(source), "occurrences": []}
                sources[digest]["occurrences"].append({"archive": item["archive"], "member": member})
                occurrences += 1
    rows = sorted(sources.values(), key=lambda row: (row["ast_nodes"], row["sha256"]))
    selected = [row for row in rows if {"infer", "check"} <= set(row["top_level_functions"])]
    return {
        "snapshot_commit": manifest["snapshot_commit"],
        "python_source_occurrences": occurrences,
        "unique_python_source_hashes": len(rows),
        "selected_occurrences": sum(len(row["occurrences"]) for row in selected),
        "selected_unique_hashes": len(selected),
        "selection": "Top-level function names include infer and check; deduplication uses exact source SHA-256. This is an inventory filter, not a soundness/completeness certification.",
        "selected_envelope": envelope(selected),
        "all_sources": rows,
    }


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, default=ROOT.parent / "checker.py")
    parser.add_argument("--output", type=Path, default=ROOT / "results/measurements.json")
    parser.add_argument("--archives", type=Path, help="Directory containing all six original ZIP filenames")
    parser.add_argument("--inventory-output", type=Path, default=ROOT / "results/source_inventory.json")
    args = parser.parse_args()
    manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
    baselines = [frozen_source(item) for item in manifest["baselines"]]
    ablation = [frozen_source(item) for item in manifest["ablation"]]
    inventory_measurement = measure_inventory(manifest)
    candidate = measure_bytes(args.candidate.read_bytes())
    bound = envelope(baselines)
    result = {
        "snapshot_commit": manifest["snapshot_commit"],
        "runtime": {"implementation": platform.python_implementation(),
                    "python": platform.python_version(), "build": sys.version,
                    "platform": platform.platform()},
        "metric_definition": "Count the entire standalone checker including imports, literals, syntax tables, validation, and JSON/CLI wrapper. Remove only module/function/class docstrings for AST and token normalization. Significant tokens exclude comments and layout tokens. Normalized bytes use ast.unparse(tree) plus a final newline. No renaming or program optimization is performed. Raw bytes include comments/docstrings and are a secondary diagnostic.",
        "qualification": "Strict finite-source comparison under declared metrics; not an absolute lower bound or proof-assistant verification. All measured files are parsed, never executed by this script.",
        "baselines": baselines,
        "coordinatewise_envelope": bound,
        "candidate": {"path": str(args.candidate), **candidate},
        "strictly_below_envelope": {key: candidate[key] < bound[key] for key in FIELDS},
        "reduction_percent": {key: 100 * (bound[key] - candidate[key]) / bound[key] for key in FIELDS},
        "ablation": ablation,
        "first_ablation_strict_in_all_primary_metrics": next(
            (row["name"] for row in ablation if all(row[key] < bound[key] for key in PRIMARY)), None),
        "candidate_matches_final_ablation_after_normalization": (
            candidate["normalized_sha256"] == ablation[-1]["normalized_sha256"]),
        "included_inventory_measurement": inventory_measurement,
    }
    result["included_inventory_measurement"]["selected_envelope_matches_primary"] = (
        inventory_measurement["selected_envelope"] == bound)
    if args.archives:
        inventory = scan_archives(args.archives, manifest)
        write_json(args.inventory_output, inventory)
        result["archive_inventory"] = {key: value for key, value in inventory.items() if key != "all_sources"}
        result["archive_inventory"]["selected_envelope_matches_primary"] = inventory["selected_envelope"] == bound
    write_json(args.output, result)
    print(json.dumps({key: result[key] for key in (
        "coordinatewise_envelope", "candidate", "strictly_below_envelope",
        "first_ablation_strict_in_all_primary_metrics",
        "candidate_matches_final_ablation_after_normalization")}, indent=2))


if __name__ == "__main__":
    main()
