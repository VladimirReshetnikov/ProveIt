"""Reproduce the offline measurements, corpus checks, audit, and paper tables."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


def run(*arguments):
    subprocess.run([sys.executable, *map(str, arguments)], cwd=ROOT, check=True)


def write_tables(measurements, audit, fixtures):
    candidate = measurements["candidate"]
    values = {
        "CandidateAST": candidate["ast_nodes"],
        "CandidateTokens": candidate["source_tokens"],
        "CandidateNormTokens": candidate["normalized_tokens"],
        "CandidateBytes": candidate["normalized_bytes"],
        "CandidateRawBytes": candidate["raw_bytes"],
        "IndependentChecks": audit["total_checks"],
        "IndependentCases": audit["certificate_cases"],
        "ReplayedNodes": audit["reference_rule_nodes_in_accepted_certificates"],
        "MigratedCount": fixtures["total"],
        "MigratedAccepted": fixtures["accepted"],
        "MigratedRejected": fixtures["rejected"],
    }
    (RESULTS / "numbers.tex").write_text("".join(
        "\\newcommand{\\" + name + "}{" + f"{value:,}" + "}\n"
        for name, value in values.items()), encoding="utf-8")
    labels = {
        "demand": "Demand kernel",
        "demand_v2": "Demand kernel, second archive",
        "demand2": "Demand kernel, second archive",
        "local": "Local kernel",
        "scoped": "Scoped rules",
        "shared": "Shared transition",
        "uniform": "Uniform kernel",
    }
    fields = ("ast_nodes", "source_tokens", "normalized_tokens", "normalized_bytes", "raw_bytes")
    rows = ["\\begin{tabular}{lrrrrr}", "\\toprule",
            "Program & AST & Tokens & Norm. tokens & Norm. bytes & Raw bytes\\\\", "\\midrule"]
    for row in measurements["baselines"]:
        name = labels.get(Path(row["source"]).stem, row.get("label", row.get("name", "Baseline")))
        rows.append(name + " & " + " & ".join(f"{row[key]:,}" for key in fields) + "\\\\")
    rows.append("\\midrule")
    for name, row in (("Coordinatewise minimum", measurements["coordinatewise_envelope"]),
                      ("Integrated checker", candidate)):
        rows.append("\\textbf{" + name + "} & " + " & ".join(
            "\\textbf{" + f"{row[key]:,}" + "}" for key in fields) + "\\\\")
    rows.extend(["\\bottomrule", "\\end{tabular}"])
    (RESULTS / "comparison_table.tex").write_text("\n".join(rows) + "\n", encoding="utf-8")
    names = ["Shared-transition original", "Variadic root and normal return", "Untagged applications",
             "Direct guard expression", "Reuse recursor input", "Omit unused diagnostic"]
    rows = ["\\begin{tabular}{lrrrr}", "\\toprule",
            "Integration stage & AST & Tokens & Norm. tokens & Norm. bytes\\\\", "\\midrule"]
    for name, row in zip(names, measurements["ablation"], strict=True):
        rows.append(name + " & " + " & ".join(f"{row[key]:,}" for key in fields[:-1]) + "\\\\")
    rows.extend(["\\bottomrule", "\\end{tabular}"])
    (RESULTS / "ablation_table.tex").write_text("\n".join(rows) + "\n", encoding="utf-8")


def main():
    RESULTS.mkdir(exist_ok=True)
    run("comparison/measure.py")
    run("validation/fixture_regression.py", "--verify", "validation/migrated",
        "--checker", "checker.py", "--report", "results/fixture_verification.json")
    run("validation/independent_audit.py", "--checker", "checker.py", "--corpus", "examples",
        "--corpus-format", "current", "--output", "results/independent_audit.json")
    measurements = json.loads((ROOT / "comparison/results/measurements.json").read_text())
    fixtures = json.loads((RESULTS / "fixture_verification.json").read_text())
    audit = json.loads((RESULTS / "independent_audit.json").read_text())
    if not all(measurements["strictly_below_envelope"].values()):
        raise RuntimeError("Candidate is not strictly below every recorded envelope coordinate")
    if audit["failures"] or fixtures["failures"]:
        raise RuntimeError("Validation failure")
    digest = hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest()
    if not all(record["checker_sha256"] == digest for record in (audit, fixtures)):
        raise RuntimeError("Results refer to different candidate bytes")
    write_tables(measurements, audit, fixtures)
    summary = {
        "status": "passed", "checker_sha256": digest,
        "strictly_below_envelope": measurements["strictly_below_envelope"],
        "independent_checks": audit["total_checks"],
        "certificate_cases": audit["certificate_cases"],
        "independently_replayed_rule_nodes": audit["reference_rule_nodes_in_accepted_certificates"],
        "migrated_fixtures": fixtures["total"], "accepted": fixtures["accepted"],
        "rejected": fixtures["rejected"], "failures": [],
    }
    (RESULTS / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
