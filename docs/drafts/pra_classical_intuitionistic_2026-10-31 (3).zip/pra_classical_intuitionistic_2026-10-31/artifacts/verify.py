#!/usr/bin/env python3
"""Run finite diagnostics for pra_reference.py and save an explicit scope report.

Usage: python3 verify.py [--out DIRECTORY]
The mathematical equivalence and infinite countermodel proofs are in the paper.
"""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
import random
import sys

from pra_reference import (
    BOTTOM, FUTURES, NODES, ONE, TOP, ZERO, Formula, Registry, Term,
    app, arithmetic_registry, check_formula, compile_error, connective,
    distance, equation, force, formula_data, registry_data, successor,
    term_data, truth, var,
)


def run() -> tuple[dict, dict]:
    registry = arithmetic_registry()
    counts: dict[str, int] = {}

    def check(group: str, condition: bool, description: str) -> None:
        if not condition:
            raise AssertionError(f"{group}: {description}")
        counts[group] = counts.get(group, 0) + 1

    def rejected(description: str, operation) -> None:
        before = registry.definitions
        try:
            operation()
        except ValueError:
            check("invalid_syntax_rejected", True, description)
        else:
            raise AssertionError(f"Invalid construction accepted: {description}")
        check("failed_declarations_are_atomic", registry.definitions == before,
              description)

    invalid = [
        ("negative parameter count", lambda: registry.declare("bad", -1, ZERO, ZERO)),
        ("out-of-scope base variable", lambda: registry.declare("bad", 0, var(0), ZERO)),
        ("out-of-scope step variable", lambda: registry.declare("bad", 0, ZERO, var(2))),
        ("forward reference", lambda: registry.declare("bad", 0, ZERO, app("future", ZERO))),
        ("self reference", lambda: registry.declare("self", 0, ZERO, app("self", var(0)))),
        ("wrong program arity", lambda: registry.declare("bad", 0, ZERO, app("p", ZERO, ZERO))),
        ("duplicate declaration", lambda: registry.declare("p", 0, ZERO, ZERO)),
        ("malformed successor", lambda: registry.check(Term("succ"), 0)),
        ("negative variable index", lambda: registry.check(var(-1), 1)),
        ("unknown constructor", lambda: registry.check(Term("oracle"), 0)),
        ("non-natural input", lambda: registry.evaluate(var(0), (-1,))),
        ("boolean input", lambda: registry.evaluate(var(0), (True,))),
        ("wrong formula arity", lambda: check_formula(registry, Formula("and"), 0)),
        ("quantifier outside QF grammar", lambda: check_formula(registry, Formula("forall"), 0)),
    ]
    for description, operation in invalid:
        rejected(description, operation)

    x, y, z = var(0), var(1), var(2)
    for n in range(13):
        check("arithmetic_values", registry.evaluate(app("p", x), (n,)) == max(n - 1, 0),
              "predecessor")
        check("arithmetic_values", registry.evaluate(app("z", x), (n,)) == int(n == 0),
              "zero test")
        for m in range(13):
            values = (n, m)
            alpha = registry.evaluate(app("alpha", x, y), values)
            beta = registry.evaluate(app("beta", x, y), values)
            d = registry.evaluate(distance(x, y), values)
            check("arithmetic_values", alpha == max(m - n, 0), "countdown")
            check("arithmetic_values", beta == max(n - m, 0), "overflow")
            check("arithmetic_values", registry.evaluate(app("add", x, y), values) == n + m,
                  "addition")
            check("arithmetic_values", d == abs(n - m), "distance")
            check("arithmetic_identities", n + alpha == m + beta, "balance invariant")
            check("arithmetic_identities", (d == 0) == (n == m), "equality test")
            for name in ("alpha", "beta"):
                shifted = registry.evaluate(app(name, successor(x), successor(y)), values)
                unshifted = registry.evaluate(app(name, x, y), values)
                check("arithmetic_identities", shifted == unshifted, f"{name} shift")
        for name in ("alpha", "beta"):
            check("arithmetic_identities", registry.evaluate(app(name, x, x), (n,)) == 0,
                  f"{name} diagonal")
    for values in itertools.product(range(5), repeat=3):
        expected = values[1] if values[0] == 0 else values[2]
        check("arithmetic_values", registry.evaluate(app("C", x, y, z), values) == expected,
              "selector")

    # These declarations test extension of the grammar rather than hard-coded arithmetic.
    extended = arithmetic_registry()
    extended.declare("mul", 1, ZERO, app("add", var(2), var(1)))
    extended.declare("power", 1, ONE, app("mul", var(2), var(1)))
    for n, m in itertools.product(range(5), repeat=2):
        check("additional_programs", extended.evaluate(app("mul", x, y), (n, m)) == n * m,
              "multiplication declaration")
        check("additional_programs", extended.evaluate(app("power", x, y), (n, m)) == m ** n,
              "power declaration, including 0^0=1")

    atoms = [equation(x, y), equation(x, ZERO), equation(app("p", x), y),
             equation(app("add", x, y), successor(y)), TOP, BOTTOM]
    formulas = list(atoms)
    formulas.extend(connective("not", atom) for atom in atoms)
    for kind in ("and", "or", "imp", "iff"):
        formulas.extend(connective(kind, left, right)
                        for left, right in itertools.product(atoms, repeat=2))
    random_source = random.Random(20261031)

    def random_formula(depth: int) -> Formula:
        if depth == 0 or random_source.randrange(4) == 0:
            return random_source.choice(atoms)
        kind = random_source.choice(("not", "and", "or", "imp", "iff"))
        arguments = (random_formula(depth - 1),)
        if kind != "not":
            arguments += (random_formula(depth - 1),)
        return connective(kind, *arguments)

    formulas.extend(random_formula(3) for _ in range(150))
    for formula in formulas:
        check_formula(registry, formula, 2)
        error = compile_error(formula)
        registry.check(error, 2)
        for values in itertools.product(range(6), repeat=2):
            check("compiler_numeric_cases",
                  (registry.evaluate(error, values) == 0) == truth(registry, formula, values),
                  "zero of error term agrees with numerical truth")

    cover = connective("or", equation(x, ZERO), equation(x, successor(app("p", x))))
    equal_zero = equation(x, ZERO)
    not_equal_zero = connective("not", equal_zero)
    zero_test_law = connective("iff", equation(app("z", x), ZERO), not_equal_zero)
    predecessor_law = connective("iff", equation(successor(app("p", x)), x), not_equal_zero)
    equality_test_law = connective(
        "iff", equation(app("z", distance(x, y)), ZERO),
        connective("not", equation(x, y)),
    )
    pairs = tuple(itertools.product(range(4), repeat=2))
    for pair in pairs:
        for node in NODES:
            check("kripke_finite_laws", force(registry, node, zero_test_law, (pair,)),
                  "negative zero-test law")
            check("kripke_finite_laws", force(registry, node, predecessor_law, (pair,)),
                  "negative exact-predecessor law")
            successor_pair = (pair[0] + 1, pair[1] + 1)
            check("kripke_finite_laws", force(registry, node, cover, (successor_pair,)),
                  "coverage at a successor")
        for other in pairs:
            for node in NODES:
                check("kripke_finite_laws",
                      force(registry, node, equality_test_law, (pair, other)),
                      "negative equality-test law")
            atomic = equation(x, y)
            for literal in (atomic, connective("not", atomic)):
                root_value = force(registry, "root", literal, (pair, other))
                leaf_value = all(force(registry, leaf, literal, (pair, other))
                                 for leaf in ("left", "right"))
                check("kripke_literal_reflection", root_value == leaf_value,
                      "literal reflection at specified argument pairs")

    witness = (0, 1)
    check("countermodel_witness", force(registry, "root", cover, ((0, 0),)), "coverage base")
    check("countermodel_witness", not force(registry, "root", cover, (witness,)),
          "root fails positive coverage")
    check("countermodel_witness", not force(registry, "root", equal_zero, (witness,)),
          "root fails witness=0")
    check("countermodel_witness", not force(registry, "root", not_equal_zero, (witness,)),
          "root also fails witness!=0")
    double_negated_cover = connective("not", connective("not", cover))
    check("countermodel_witness", force(registry, "root", double_negated_cover, (witness,)),
          "root forces double-negated coverage")
    compiled_cover = compile_error(cover)
    error_pair = tuple(registry.evaluate(compiled_cover, (coordinate,)) for coordinate in witness)
    check("countermodel_witness", error_pair == (0, 0),
          "compiled coverage error is coordinatewise zero")
    check("countermodel_witness",
          force(registry, "root", equation(compiled_cover, ZERO), (witness,)),
          "root forces compiled equation although it fails the native disjunction")

    # Static product uses literal componentwise equality and ordinary classical OR.
    reconstructed = tuple(registry.evaluate(successor(app("p", x)), (coordinate,))
                          for coordinate in witness)
    product_coverage = witness == (0, 0) or witness == reconstructed
    check("countermodel_witness", not product_coverage, "static product fails coverage")

    sample = connective("imp", connective("or", equation(x, ZERO), equation(x, y)),
                        equation(x, y))
    examples = {
        "core_registry": registry_data(registry),
        "sample_formula": formula_data(sample),
        "compiled_sample_error": term_data(compile_error(sample)),
        "coverage_formula": formula_data(cover),
        "compiled_coverage_error": term_data(compiled_cover),
        "witness": list(witness),
        "witness_successor_predecessor": list(reconstructed),
        "witness_error_value_in_product": list(error_pair),
        "witness_forcing": {
            node: {
                "coverage": force(registry, node, cover, (witness,)),
                "double_negated_coverage": force(registry, node, double_negated_cover, (witness,)),
                "equal_zero": force(registry, node, equal_zero, (witness,)),
                "not_equal_zero": force(registry, node, not_equal_zero, (witness,)),
                "compiled_coverage_equals_zero": force(
                    registry, node, equation(compiled_cover, ZERO), (witness,)),
            } for node in NODES
        },
    }
    report = {
        "status": "passed",
        "python_version": sys.version.split()[0],
        "scope": "Finite numerical, syntax, and quantifier-free forcing diagnostics only.",
        "not_claimed": [
            "No machine-checked proof of theory equivalence.",
            "No finite test proves validity of an infinite axiom scheme.",
            "The Python evaluator is not claimed to be a primitive-recursive universal evaluator.",
            "Numerical compiler correctness does not establish internal correctness in a weak theory.",
        ],
        "proof_source": "The accompanying LaTeX/PDF paper contains the general mathematical proofs.",
        "tested_ranges": {
            "arithmetic_n_m": "0..12 inclusive",
            "selectors": "0..4 inclusive in all three arguments",
            "additional_programs": "0..4 inclusive in each argument",
            "compiler_arguments": "0..5 inclusive in each of two arguments",
            "formula_count": len(formulas),
            "formula_generation_seed": 20261031,
            "kripke_input_coordinates": "0..3 inclusive",
        },
        "checks_by_group": counts,
        "total_checks": sum(counts.values()),
        "witness": examples["witness_forcing"],
    }
    return report, examples


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent)
    arguments = parser.parse_args()
    report, examples = run()
    arguments.out.mkdir(parents=True, exist_ok=True)
    for name, data in (("verification.json", report), ("examples.json", examples)):
        (arguments.out / name).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    lines = ["PASS: finite PRA companion diagnostics", report["scope"],
             f"Python: {report['python_version']}"]
    lines.extend(f"{name}: {count}" for name, count in report["checks_by_group"].items())
    lines.append(f"Total checks: {report['total_checks']}")
    lines.extend(report["not_claimed"])
    log = "\n".join(lines) + "\n"
    (arguments.out / "verification.txt").write_text(log, encoding="utf-8")
    print(log, end="")


if __name__ == "__main__":
    main()
