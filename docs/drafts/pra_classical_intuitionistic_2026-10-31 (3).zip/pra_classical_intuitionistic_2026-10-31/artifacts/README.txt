EXECUTABLE COMPANION

Run with Python 3.10 or later, using only the standard library:

    python3 verify.py

The command writes verification.json, verification.txt, and examples.json
beside the scripts. Use --out DIRECTORY to write them elsewhere.

pra_reference.py implements an explicit primitive-recursion term grammar.
A base term's variables are the fixed parameters. A step term's variables
are, in order, the recursion index, the old value, and the fixed parameters.
Every program reference in a declaration must refer to an earlier program;
arity and variable scope are checked before inserting the declaration.
Projections and composition are ordinary variables and term substitution.

The six core descriptions are p, z, C, add, alpha, and beta, with precisely
the defining equations used in the paper. Distance is the term
add(alpha(x,y), beta(x,y)); it is not a primitive comparison operation.
The QF compiler uses zero to represent truth. It supports equality, top,
bottom, negation, conjunction, disjunction, implication, and equivalence.
Equivalence is expanded as the conjunction of the two implications, since
general error terms are not normalized Boolean values.

The evaluator is an ordinary Python metaprogram. It is not claimed to be
primitive recursive uniformly in a program description and its input.

The diagnostics check numerical identities, all compiler connectives,
invalid arities, variable scope, forward and self references, and concrete
QF forcing computations in the three-node Kripke countermodel. There is no
quantifier evaluator and no assertion that a finite test verifies an
infinite induction scheme. The full proofs belong to the paper.

One diagnostic is especially instructive: at the product element (0,1),
the compiled error term for x=0 OR x=S(p(x)) has value (0,0). Nevertheless
the native disjunction fails in the static product and is not forced at
the Kripke root. Internal correctness of Boolean compilation in a weak
theory therefore needs a proof; correctness in standard N alone is not
enough.
