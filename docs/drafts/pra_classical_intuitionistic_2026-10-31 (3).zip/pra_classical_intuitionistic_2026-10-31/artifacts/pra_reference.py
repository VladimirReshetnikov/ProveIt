"""Executable syntax and numerical reference for the PRA research note.

This is not a proof assistant or a formal verification of the paper.  The
registry checks a finite, well-founded primitive-recursion description.
Evaluation is a Python metaprogram; no claim is made that a universal
evaluator for primitive-recursive descriptions is itself primitive recursive.
Only the Python standard library is used.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence


@dataclass(frozen=True)
class Term:
    """A variable, zero, successor application, or named recursor application."""

    kind: str
    args: tuple[Term, ...] = ()
    index: int | None = None
    name: str | None = None


def var(index: int) -> Term:
    return Term("var", index=index)


ZERO = Term("zero")


def successor(term: Term) -> Term:
    return Term("succ", (term,))


ONE = successor(ZERO)


def app(name: str, *args: Term) -> Term:
    return Term("app", tuple(args), name=name)


@dataclass(frozen=True)
class Recursion:
    """Base context: parameters; step context: index, old value, parameters."""

    name: str
    parameter_count: int
    base: Term
    step: Term

    @property
    def arity(self) -> int:
        return self.parameter_count + 1


class Registry:
    """Earlier descriptions alone may occur in a new base or step term."""

    def __init__(self) -> None:
        self._definitions: dict[str, Recursion] = {}

    @property
    def definitions(self) -> tuple[Recursion, ...]:
        return tuple(self._definitions.values())

    def check(self, term: Term, variable_count: int) -> None:
        if type(variable_count) is not int or variable_count < 0:
            raise ValueError("The variable count must be a nonnegative integer.")
        if not isinstance(term, Term):
            raise ValueError("Expected a Term object.")
        if type(term.args) is not tuple:
            raise ValueError("Term arguments must be a tuple.")
        if term.kind == "var":
            if (type(term.index) is not int or not 0 <= term.index < variable_count
                    or term.args or term.name is not None):
                raise ValueError("Malformed or out-of-scope variable.")
            return
        if term.kind == "zero":
            if term.args or term.index is not None or term.name is not None:
                raise ValueError("Malformed zero.")
            return
        if term.kind == "succ":
            if len(term.args) != 1 or term.index is not None or term.name is not None:
                raise ValueError("Malformed successor.")
        elif term.kind == "app":
            if term.index is not None or term.name not in self._definitions:
                raise ValueError("Unknown, forward, or self reference.")
            if len(term.args) != self._definitions[term.name].arity:
                raise ValueError("Wrong function arity.")
        else:
            raise ValueError("Unknown term constructor.")
        for argument in term.args:
            self.check(argument, variable_count)

    def declare(self, name: str, parameter_count: int, base: Term, step: Term) -> None:
        if not isinstance(name, str) or not name.isidentifier():
            raise ValueError("A program name must be an identifier.")
        if name in self._definitions:
            raise ValueError("A program name cannot be redeclared.")
        if type(parameter_count) is not int or parameter_count < 0:
            raise ValueError("The parameter count must be a nonnegative integer.")
        self.check(base, parameter_count)
        self.check(step, parameter_count + 2)
        # Insert only after both checks: failed declarations leave no partial entry.
        self._definitions[name] = Recursion(name, parameter_count, base, step)

    def evaluate(self, term: Term, arguments: Sequence[int] = ()) -> int:
        values = tuple(arguments)
        if any(type(value) is not int or value < 0 for value in values):
            raise ValueError("Inputs must be natural numbers, not booleans.")
        self.check(term, len(values))
        return self._evaluate(term, values)

    def _evaluate(self, term: Term, values: tuple[int, ...]) -> int:
        if term.kind == "var":
            return values[term.index]
        if term.kind == "zero":
            return 0
        if term.kind == "succ":
            return self._evaluate(term.args[0], values) + 1
        definition = self._definitions[term.name]
        arguments = tuple(self._evaluate(argument, values) for argument in term.args)
        count, *parameters = arguments
        parameters = tuple(parameters)
        result = self._evaluate(definition.base, parameters)
        for index in range(count):
            result = self._evaluate(definition.step, (index, result, *parameters))
        return result


def arithmetic_registry() -> Registry:
    registry = Registry()
    registry.declare("p", 0, ZERO, var(0))
    registry.declare("z", 0, ONE, ZERO)
    registry.declare("C", 2, var(0), var(3))
    registry.declare("add", 1, var(0), successor(var(1)))
    registry.declare("alpha", 1, var(0), app("p", var(1)))
    registry.declare(
        "beta", 1, ZERO,
        app("C", app("alpha", var(0), var(2)), successor(var(1)), var(1)),
    )
    return registry


def distance(left: Term, right: Term) -> Term:
    return app("add", app("alpha", left, right), app("beta", left, right))


@dataclass(frozen=True)
class Formula:
    """Finite quantifier-free syntax; iff is included as an abbreviation."""

    kind: str
    args: tuple[Formula, ...] = ()
    terms: tuple[Term, ...] = ()


def equation(left: Term, right: Term) -> Formula:
    return Formula("eq", terms=(left, right))


def connective(kind: str, *args: Formula) -> Formula:
    return Formula(kind, tuple(args))


TOP = Formula("top")
BOTTOM = Formula("bottom")


def check_formula(registry: Registry, formula: Formula, variable_count: int) -> None:
    if not isinstance(formula, Formula):
        raise ValueError("Expected a Formula object.")
    if type(formula.args) is not tuple or type(formula.terms) is not tuple:
        raise ValueError("Formula arguments and terms must be tuples.")
    if formula.kind == "eq":
        if formula.args or len(formula.terms) != 2:
            raise ValueError("Malformed equation.")
        for term in formula.terms:
            registry.check(term, variable_count)
        return
    arities = {"top": 0, "bottom": 0, "not": 1, "and": 2, "or": 2,
               "imp": 2, "iff": 2}
    if (formula.terms or formula.kind not in arities
            or len(formula.args) != arities[formula.kind]):
        raise ValueError("Unknown or malformed formula constructor.")
    for argument in formula.args:
        check_formula(registry, argument, variable_count)


def compile_error(formula: Formula) -> Term:
    """Compile validated QF syntax to the paper's error term: zero means true."""
    if formula.kind == "eq":
        return distance(*formula.terms)
    if formula.kind == "top":
        return ZERO
    if formula.kind == "bottom":
        return ONE
    errors = tuple(compile_error(argument) for argument in formula.args)
    if formula.kind == "not":
        return app("z", errors[0])
    left, right = errors
    if formula.kind == "and":
        return app("add", left, right)
    if formula.kind == "or":
        return app("C", left, ZERO, right)
    if formula.kind == "imp":
        return app("C", left, right, ZERO)
    if formula.kind == "iff":
        return app("add", app("C", left, right, ZERO), app("C", right, left, ZERO))
    raise ValueError("Formula must be checked before compilation.")


def truth(registry: Registry, formula: Formula, values: Sequence[int]) -> bool:
    """Ordinary numerical truth, for testing the compiler only."""
    if formula.kind == "eq":
        return registry.evaluate(formula.terms[0], values) == registry.evaluate(
            formula.terms[1], values)
    if formula.kind == "top":
        return True
    if formula.kind == "bottom":
        return False
    arguments = tuple(truth(registry, argument, values) for argument in formula.args)
    if formula.kind == "not":
        return not arguments[0]
    left, right = arguments
    operations = {"and": left and right, "or": left or right,
                  "imp": not left or right, "iff": left == right}
    return operations[formula.kind]


NODES = ("root", "left", "right")
FUTURES = {"root": NODES, "left": ("left",), "right": ("right",)}


def force(registry: Registry, node: str, formula: Formula,
          values: Sequence[tuple[int, int]]) -> bool:
    """Exact QF forcing at specified arguments in the three-node Kripke model.

    This routine has no quantifier constructor: it does not certify a
    universally quantified axiom or an infinite induction scheme.
    """
    if node not in FUTURES:
        raise ValueError("Unknown Kripke node.")
    if formula.kind == "eq":
        equalities = tuple(
            registry.evaluate(formula.terms[0], tuple(value[i] for value in values))
            == registry.evaluate(formula.terms[1], tuple(value[i] for value in values))
            for i in (0, 1)
        )
        return all(equalities) if node == "root" else equalities[NODES.index(node) - 1]
    if formula.kind == "top":
        return True
    if formula.kind == "bottom":
        return False
    if formula.kind == "not":
        return all(not force(registry, future, formula.args[0], values)
                   for future in FUTURES[node])
    left, right = formula.args
    if formula.kind == "and":
        return force(registry, node, left, values) and force(registry, node, right, values)
    if formula.kind == "or":
        return force(registry, node, left, values) or force(registry, node, right, values)
    if formula.kind == "imp":
        return all(not force(registry, future, left, values)
                   or force(registry, future, right, values) for future in FUTURES[node])
    if formula.kind == "iff":
        return (force(registry, node, connective("imp", left, right), values)
                and force(registry, node, connective("imp", right, left), values))
    raise ValueError("Unknown formula constructor.")


def term_data(term: Term) -> dict:
    result = {"kind": term.kind}
    if term.index is not None:
        result["index"] = term.index
    if term.name is not None:
        result["name"] = term.name
    if term.args:
        result["args"] = [term_data(argument) for argument in term.args]
    return result


def formula_data(formula: Formula) -> dict:
    result = {"kind": formula.kind}
    if formula.args:
        result["args"] = [formula_data(argument) for argument in formula.args]
    if formula.terms:
        result["terms"] = [term_data(term) for term in formula.terms]
    return result


def registry_data(registry: Registry) -> list[dict]:
    return [{"name": entry.name, "arity": entry.arity,
             "parameter_count": entry.parameter_count,
             "base_context": "parameters",
             "step_context": "index, old_value, parameters",
             "base": term_data(entry.base), "step": term_data(entry.step)}
            for entry in registry.definitions]
