A COMMON SMALL AXIOMATIZATION OF PRIMITIVE RECURSIVE ARITHMETIC
Classical and intuitionistic logic
31 October 2026

MAIN RESULT
The same nonlogical basis works in both logics:
  primitive-recursion defining equations;
  0 != S(0);
  one schema, for each equation E(n,a):

  [forall n ((n=0 OR E(n,a)) -> E(S(n),a))]
       -> forall n (n=0 OR E(n,a)),

universally closed over all fixed parameters a.

The paper proves exact first-order equivalence to the conventional
quantifier-free-induction presentation in each respective logic.
It also gives explicit classical and intuitionistic countermodels to
several tempting further deletions, and audits six prior GitHub drafts.

CONTENTS
  pra_classical_intuitionistic.tex  Complete self-contained LaTeX source.
  pra_classical_intuitionistic.pdf  Compiled paper.
  axioms.txt                       Standalone precise specification.
  source_manifest.json             Pinned sources and archive hashes.
  Makefile                         Rebuild and diagnostic commands.
  artifacts/pra_reference.py        PR syntax, evaluator, formula compiler.
  artifacts/verify.py               Reproducible finite checks.
  artifacts/verification.json       Machine-readable verification results.
  artifacts/verification.txt        Human-readable verification results.
  artifacts/examples.json          Program and formula examples, countermodel.
  artifacts/README.txt              Implementation conventions and scope.
  SHA256SUMS                       SHA-256 digests of deliverable files.

REBUILD THE PAPER
Requires a normal LaTeX installation with latexmk, pdflatex, Latin Modern,
AMS packages, microtype, geometry, enumitem, tcolorbox, TikZ and hyperref.
From this directory:
  make pdf

Without latexmk, run pdflatex on pra_classical_intuitionistic.tex three
times. All references are embedded in the source; BibTeX is not required.

RUN THE COMPANION
Requires Python 3.10 or later; no third-party Python packages.
  make check
or
  python3 artifacts/verify.py

VALIDATION SCOPE
The saved run passed 14,055 finite checks, including 11,016 compiler cases
covering 306 formulas, arithmetic identities, malformed descriptions,
and exact quantifier-free forcing at selected arguments of the three-node
Kripke model.

These checks are not a formal verification in Lean, Rocq, or another
proof assistant. They do not prove validity of an infinite axiom scheme.
The full constructive and countermodel proofs are in the paper.

The external Python evaluator is not claimed to be primitive recursive
jointly in program code and input. Actual execution is resource-limited.

SOURCE PROVENANCE
The six existing drafts were fetched from ProveIt/docs/drafts at commit
ffbbfd31452e7188a9e3ba62c81a3bdb64072b82 and checked against their Git blob
identifiers. The countdown/overflow comparator proof is adapted from the
pra_minimal_2026-10-31 draft. The paper identifies what is retained and
what changes for intuitionistic logic. Original reference PDFs and prior
archives are not bundled.

CLAIMS
This is a compact exact axiomatization under an explicitly stated
simplicity criterion, not a theorem of absolute shortest encoding.
Classical and intuitionistic PRA have the same quantifier-free and
universal-quantifier-free theorems, but not all first-order theorems.
