COPIED SOURCE COMPARISON
========================

These are byte-identical copies from the eleven current ProveIt draft ZIPs
at commit b079e5787b1d708049ff0643ce1b534c1a225198. They are comparison
sources, not dependencies of the new checker in code/checker.py.

There are 53 inventoried complete checker variants and 85 counted file
copies. The original archive inventory contains 141 Python members. Every
copied file has its original archive member, size, and SHA-256 recorded in
../provenance/current_source_manifest.json. ZIP SHA-256 and Git blob SHA-1
identities are recorded for all eleven archives. The source ZIPs themselves
need not be bundled to reproduce the source metrics.

Each directory Dxx/variant contains the full selected trust boundary:
mathematical checker, required local modules, and supplied JSON adapter.
The mathematical source contents have not been refactored or reformatted.
The D00 and D09 adapters import a module literally called kernel. For each
of those variants the selected original source has therefore been copied
as kernel.py; the contents remain byte-identical. The manifest records the
original member name and the new copy path. D01's modular and D07's shared
drivers select a module by command-line option; only the selected module
and its dependencies are present in each individual comparison directory.

Program variants are not 53 independent theories or 53 claims of novelty.
They include the authors' controlled comparisons, modular/standalone
versions, and repeated historical implementations. Byte-identical source
duplicates inside a single archive are identified in the member inventory
rather than padded into additional variants.

REPRODUCE

From the package root:

    python3 audit_sources.py
    python3 audit_sources.py --check

The script hashes and parses these sources; it does not import or execute
them. It uses the same executable normalization as code/measure.py,
charges every local dependency and supplied adapter exactly once per
program, and records both raw and executable metrics. Python 3.12.14
produced the delivered counts; ast.unparse is version dependent.

Optional verification against locally downloaded original ZIPs:

    python3 audit_sources.py --archives /path/to/original/zip/directory

The optional directory may use the original archive filenames or the
acquisition names draft_0.zip through draft_9.zip and two_binders.zip.

BOUNDARY AND LIMITATIONS

Python and its standard library are fixed external runtimes. All local
arithmetic, logical, syntax-validation, substitution, and JSON-adapter
source is counted. Test suites, proof producers, translations, source
counters, exporters, and paper builders are excluded from every checker
boundary because the checker does not import them.

The counts establish a finite comparison among these supplied programs,
not a global minimum and not formal certification of every earlier
mathematical proposal. Each program uses its own native certificate
syntax. The strict-deletion comparison with D03.kernel is stronger:
apart from the identified removal of the falsity machinery, its executable
source is identical to the new checker. The designated CLASH declaration
remains included and charged.

