"""Recount the copied complete checkers without importing or executing them.

Run: python3 audit_sources.py
Optional original-ZIP verification: python3 audit_sources.py --archives DIR
Use --check to compare with the saved JSON instead of rewriting audit outputs.
Python 3.12.14 produced the delivered counts; ast.unparse is version sensitive.
This is untrusted audit tooling, not a dependency of code/checker.py.
"""

import argparse
import ast
import copy
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
PROVENANCE = ROOT / "provenance"
SKIP = {tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE, tokenize.ENCODING,
        tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
MEASURES = ("raw_utf8_bytes", "raw_physical_lines", "raw_lexical_tokens",
            "raw_ast_nodes", "executable_utf8_bytes", "meaningful_python_tokens",
            "executable_ast_nodes", "executable_nonempty_lines")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def executable(source):
    """Identical executable normalization to code/measure.py."""
    tree = ast.parse(source)
    for n in ast.walk(tree):
        if isinstance(n, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if n.body and isinstance(n.body[0], ast.Expr) and isinstance(n.body[0].value, ast.Constant) and isinstance(n.body[0].value.value, str):
                n.body.pop(0)
    return tree


def token_count(source):
    return sum(t.type not in SKIP
               for t in tokenize.generate_tokens(io.StringIO(source).readline))


def measure(path):
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    original = ast.parse(source)
    tree = executable(source)
    normalized = ast.unparse(tree) + "\n"
    imports = []
    for n in ast.walk(original):
        if isinstance(n, ast.Import):
            imports.extend(a.name.split(".")[0] for a in n.names)
        elif isinstance(n, ast.ImportFrom) and n.module:
            imports.append(n.module.split(".")[0])
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "raw_utf8_bytes": len(raw),
        "raw_physical_lines": len(source.splitlines()),
        "raw_lexical_tokens": token_count(source),
        "raw_ast_nodes": len(list(ast.walk(original))),
        "executable_utf8_bytes": len(normalized.encode("utf-8")),
        "meaningful_python_tokens": token_count(normalized),
        "executable_ast_nodes": len(list(ast.walk(tree))),
        "executable_nonempty_lines": sum(bool(s.strip()) for s in normalized.splitlines()),
        "imports": sorted(set(imports)),
    }


def first_pattern_literal(case):
    p = case.pattern
    if isinstance(p, ast.MatchSequence) and p.patterns:
        q = p.patterns[0]
        if isinstance(q, ast.MatchValue) and isinstance(q.value, ast.Constant):
            return q.value.value
    return None


def verify_strict_deletion(baseline_path, candidate_path):
    old = executable(baseline_path.read_text())
    new = executable(candidate_path.read_text())
    reduced = copy.deepcopy(old)
    constants = [n for n in reduced.body if isinstance(n, ast.Assign)
                 and any(isinstance(t, ast.Name) and t.id == "FALSE" for t in n.targets)]
    require(len(constants) == 1, "expected exactly one FALSE declaration in baseline")
    reduced.body.remove(constants[0])
    removed = {}
    for function, tag in (("wf", "false"), ("infer", "bridge")):
        f = next(n for n in reduced.body if isinstance(n, ast.FunctionDef) and n.name == function)
        matches = [n for n in f.body if isinstance(n, ast.Match)]
        require(len(matches) == 1, "unexpected rule-dispatch layout")
        cases = matches[0].cases
        selected = [c for c in cases if first_pattern_literal(c) == tag]
        require(len(selected) == 1, "missing or duplicated deletion case: " + tag)
        cases.remove(selected[0])
        removed[function] = tag
    require(ast.dump(reduced, include_attributes=False) == ast.dump(new, include_attributes=False),
            "candidate has executable changes beyond the specified three deletions")
    require(any(isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "CLASH"
                for t in n.targets) for n in new.body), "designated absurdity datum must be charged")
    return {"verified": True, "method": "AST equality after removing exactly the FALSE declaration, the false grammar case, and the bridge inference case from the exact baseline; docstrings alone are ignored.",
            "retained_designated_formula": "CLASH = ('=', ZERO, ('s', ZERO))",
            "new_acceptance_cases": 0}


def verify_archives(manifest, directory):
    """An optional acquisition check; the final archive need not contain source ZIPs."""
    for a in manifest["archives"]:
        index = int(a["id"][1:])
        choices = [directory/a["archive_name"], directory/("two_binders.zip" if index == 10 else f"draft_{index}.zip")]
        path = next((p for p in choices if p.is_file()), None)
        require(path is not None, "original ZIP unavailable for " + a["id"])
        raw = path.read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        require(len(raw) == a["archive_size_bytes"] and blob == a["git_blob_sha1"]
                and hashlib.sha256(raw).hexdigest() == a["archive_sha256"],
                "original ZIP integrity mismatch: " + a["id"])


def metric_minima(rows):
    fields = ("raw_utf8_bytes", "executable_utf8_bytes", "meaningful_python_tokens", "executable_ast_nodes")
    return {field: {"value": min(r["totals"][field] for r in rows),
                    "program_ids": [r["id"] for r in rows if r["totals"][field] == min(q["totals"][field] for q in rows)]}
            for field in fields}


def recount(manifest):
    files, rows = {}, []
    for program in manifest["programs"]:
        paths = [f["path"] for f in program["files"]]
        require(len(paths) == len(set(paths)), "duplicate file within trust boundary")
        require(program["entrypoint"] in paths, "entry point omitted from trust boundary")
        stems = {Path(p).stem for p in paths}
        standard, local = set(), set()
        for source in program["files"]:
            p = (ROOT / source["path"]).resolve()
            require(p.is_relative_to(ROOT), "source path escapes package")
            metrics = measure(p)
            require(metrics["sha256"] == source["sha256"], "source fingerprint mismatch: " + source["path"])
            require(metrics["raw_utf8_bytes"] == source["raw_utf8_bytes"], "source byte count mismatch")
            files[source["path"]] = metrics
            for name in metrics["imports"]:
                if name in sys.stdlib_module_names:
                    standard.add(name)
                else:
                    require(name in stems, "uncounted local import: " + name + " in " + program["id"])
                    local.add(name)
        rows.append({"id": program["id"], "archive_id": program["archive_id"],
                     "label": program["label"], "files": paths,
                     "totals": {k: sum(files[p][k] for p in paths) for k in MEASURES},
                     "standard_library_imports": sorted(standard),
                     "accounted_local_imports": sorted(local)})

    candidate = measure(ROOT/manifest["candidate"]["path"])
    alias = measure(ROOT/manifest["candidate"]["baseline_alias"])
    selected = {r["id"]: r for r in rows}
    baseline = selected[manifest["candidate"]["baseline_program_id"]]
    nearest = selected[manifest["candidate"]["nearest_ast_program_id"]]
    require(len(baseline["files"]) == 1 and alias["sha256"] == files[baseline["files"][0]]["sha256"],
            "code/baseline_checker.py differs from the pinned source")
    strict = verify_strict_deletion(ROOT/alias["path"], ROOT/candidate["path"])
    # Check agreement with the independently supplied narrow comparison script.
    narrow = json.loads((ROOT/"code/metrics.json").read_text())
    for label, metrics in (("baseline", alias), ("candidate", candidate)):
        for key in ("sha256", "raw_utf8_bytes", "executable_utf8_bytes", "meaningful_python_tokens", "executable_ast_nodes", "executable_nonempty_lines"):
            require(narrow[label][key] == metrics[key], "code/metrics.json is stale or disagrees: " + label + "/" + key)

    archive_rows = []
    for a in manifest["archives"]:
        own = [r for r in rows if r["archive_id"] == a["id"]]
        require(own, "archive has no inventoried checker")
        archive_rows.append({"id": a["id"], "archive_name": a["archive_name"], "program_count": len(own),
                             "python_member_count": len(a["python_members"]), "minima": metric_minima(own),
                             "audit_conclusion": a["audit_conclusion"]})

    tests_path = ROOT/"code/test_results.json"
    tests = json.loads(tests_path.read_text())
    require(tests["checker_sha256"] == candidate["sha256"] and tests["baseline_sha256"] == alias["sha256"],
            "test result fingerprints do not identify the measured kernels")
    outcomes = tests["outcomes"]
    require(sum(o["expected"] is True for o in outcomes) == tests["accepted_count"], "acceptance tally mismatch")
    require(sum(o["expected"] is False for o in outcomes) == tests["rejected_count"], "rejection tally mismatch")
    require(len(list((ROOT/"code/baseline_certificates").glob("*.json"))) == tests["baseline_fixtures_translated"],
            "baseline-fixture inventory tally mismatch")
    require(tests["baseline_cross_checks"] == tests["accepted_count"], "baseline cross-check tally mismatch")
    require(tests["cli_checks"] == 2*len(outcomes), "CLI tally mismatch")
    require(all(o[k] == "pass" for o in outcomes for k in ("api", "cli", "optimized_cli")), "a reported test failed")
    test_summary = {k:v for k,v in tests.items() if k != "outcomes"}
    test_summary["result_file_sha256"] = hashlib.sha256(tests_path.read_bytes()).hexdigest()
    minima = metric_minima(rows)
    below = {key: candidate[key] < record["value"] for key, record in minima.items()}
    return {"python_version": sys.version.split()[0], "repository_commit": manifest["repository_commit"],
            "source_manifest_sha256": hashlib.sha256((PROVENANCE/"current_source_manifest.json").read_bytes()).hexdigest(),
            "scope": manifest["comparison_scope"], "runtime_policy": manifest["runtime_policy"],
            "normalization": "Per file, raw source metrics retain docstrings; executable metrics remove module/function/class docstring statements, then use ast.unparse plus a final newline. Tokens exclude comments, whitespace/layout, encoding and end markers. AST counts include all nodes. Whole-program totals sum every trusted file exactly once.",
            "copied_file_count": len(files), "prior_program_count": len(rows),
            "candidate": candidate, "baseline_alias": alias, "strict_deletion": strict,
            "baseline_program_id": baseline["id"], "nearest_ast_program_id": nearest["id"],
            "programs": rows, "files": files, "archives": archive_rows,
            "prior_lower_envelope": minima, "candidate_strictly_below_envelope": below,
            "test_result_summary": test_summary,
            "limitations": "The counts establish a finite source comparison. Earlier authors' metatheorems are not automatically certified by inventory; the universal soundness/completeness and bi-interpretability claims rely on written proofs. No global shortest-checker theorem is asserted."}


def tex_text(value):
    translation = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}
    return "".join(translation.get(c,c) for c in value)


def tex_filename(name):
    return r"\texttt{" + tex_text(name).replace(r"\_", r"\_\allowbreak{}") + "}"


def write_outputs(result):
    target = PROVENANCE/"source_comparison.json"
    target.write_text(json.dumps(result, indent=2) + "\n")
    with (PROVENANCE/"source_comparison.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["program", "archive", "files", *MEASURES])
        writer.writerow(["candidate", "new", 1, *(result["candidate"][k] for k in MEASURES)])
        for row in result["programs"]:
            writer.writerow([row["id"], row["archive_id"], len(row["files"]), *(row["totals"][k] for k in MEASURES)])
    rows = {r["id"]:r for r in result["programs"]}
    old = rows[result["baseline_program_id"]]["totals"]
    near = rows[result["nearest_ast_program_id"]]["totals"]
    new = result["candidate"]
    macros = {"AuditCandidateTokens":new["meaningful_python_tokens"], "AuditCandidateNodes":new["executable_ast_nodes"],
              "AuditCandidateBytes":new["executable_utf8_bytes"], "AuditProgramCount":result["prior_program_count"],
              "AuditSourceCount":result["copied_file_count"],
              "AuditTokenSaving":old["meaningful_python_tokens"]-new["meaningful_python_tokens"],
              "AuditNodeSaving":old["executable_ast_nodes"]-new["executable_ast_nodes"],
              "AuditNearestNodeSaving":near["executable_ast_nodes"]-new["executable_ast_nodes"],
              "AuditByteSaving":old["executable_utf8_bytes"]-new["executable_utf8_bytes"],
              "AuditTokenPercent":f'{100*(old["meaningful_python_tokens"]-new["meaningful_python_tokens"])/old["meaningful_python_tokens"]:.2f}',
              "AuditNodePercent":f'{100*(old["executable_ast_nodes"]-new["executable_ast_nodes"])/old["executable_ast_nodes"]:.2f}',
              "AuditBytePercent":f'{100*(old["executable_utf8_bytes"]-new["executable_utf8_bytes"])/old["executable_utf8_bytes"]:.2f}'}
    for key, field in (("AuditAccepted","accepted_count"),("AuditRejected","rejected_count"),
                       ("AuditCLI","cli_checks"),("AuditTranslated","baseline_fixtures_translated"),
                       ("AuditBaselineCross","baseline_cross_checks")):
        macros[key] = result["test_result_summary"][field]
    (PROVENANCE/"comparison_metrics.tex").write_text("% Generated by audit_sources.py.\n" +
        "".join("\\newcommand{\\" + key + "}{" + str(value) + "}\n" for key,value in macros.items()))
    table = [r"\begin{center}", r"\small", r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
             r"Complete checker & Raw bytes & Exec. bytes & Tokens & AST nodes \\", r"\midrule"]
    for title, metrics in (("Pinned main baseline (D03)",old),("Closest AST comparator (D03)",near),("Proposed arithmetic-falsity kernel",new)):
        table.append(title + " & " + " & ".join(str(metrics[k]) for k in ("raw_utf8_bytes","executable_utf8_bytes","meaningful_python_tokens","executable_ast_nodes")) + r" \\")
    table += [r"\bottomrule",r"\end{tabular}",r"\end{center}"]
    (PROVENANCE/"comparison_table.tex").write_text("\n".join(table)+"\n")

    table = [r"\begin{longtable}{@{}p{0.065\linewidth}p{0.57\linewidth}rrr@{}}",r"\toprule",
             r"ID & Exact archive filename & Variants & Tokens & AST \\",r"\midrule",r"\endfirsthead",
             r"\toprule",r"ID & Exact archive filename & Variants & Tokens & AST \\",r"\midrule",r"\endhead",
             r"\midrule",r"\multicolumn{5}{r}{\footnotesize Continued on the next page.}\\",r"\endfoot",r"\bottomrule",r"\endlastfoot"]
    for row in result["archives"]:
        lo=row["minima"]
        table.append(row["id"]+" & "+tex_filename(row["archive_name"])+" & "+str(row["program_count"])+" & "+str(lo["meaningful_python_tokens"]["value"])+" & "+str(lo["executable_ast_nodes"]["value"])+r" \\*")
        table.append(r"\multicolumn{5}{@{}p{0.985\linewidth}@{}}{\footnotesize " + tex_text(row["audit_conclusion"]) + r"}\\[6pt]")
    table.append(r"\end{longtable}")
    (PROVENANCE/"archive_audit_table.tex").write_text("\n".join(table)+"\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives", type=Path, help="optional directory containing the original source ZIPs")
    parser.add_argument("--check", action="store_true", help="verify saved JSON instead of rewriting audit outputs")
    args = parser.parse_args()
    manifest = json.loads((PROVENANCE/"current_source_manifest.json").read_text())
    if args.archives:
        verify_archives(manifest, args.archives)
    result = recount(manifest)
    if args.check:
        expected = json.loads((PROVENANCE/"source_comparison.json").read_text())
        require(result == expected, "saved source comparison differs; rerun without --check to update")
    else:
        write_outputs(result)
    print(json.dumps({"status":"PASS", "archives":len(result["archives"]),
                      "prior_programs":result["prior_program_count"],
                      "copied_files":result["copied_file_count"],
                      "candidate":{k:result["candidate"][k] for k in ("raw_utf8_bytes","executable_utf8_bytes","meaningful_python_tokens","executable_ast_nodes")},
                      "strict_deletion":result["strict_deletion"]["verified"],
                      "below_observed_envelope":result["candidate_strictly_below_envelope"]},indent=2))


if __name__ == "__main__":
    main()
