"""Reproduce finite certificate evidence and complete-source measurements."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run():
    for relative in ('code/test_kernel.py', 'code/measure.py', 'audit_sources.py'):
        subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT, check=True)


if __name__ == '__main__':
    run()
