iPRA WITH ARITHMETIC FALSITY
Research package -- 6 November 2026
=================================

Start with report.pdf. The complete source is report.tex plus
comparison_section.tex and the code listing code/checker.py.
SPECIFICATION.txt states the entire native calculus independently.

RESULT
------
A complete native proof presentation of full first-order intuitionistic
primitive recursive arithmetic with just three formula constructors:
equality, guarded Pi, and guarded Sigma. Logical absurdity is DEFINED as
0=S0. There is no primitive false node, bridge, reflexivity rule, or explosion
rule. Arithmetic and the two binders derive the omitted logical operations.

Primitive ingredients:
  - six logical inference patterns;
  - two initialized-recursion computation axiom schemas;
  - one number rule, supplying an induction hypothesis only for equations
    and zero/successor cases without an induction hypothesis otherwise.

The whole candidate acceptance program has 1,129 meaningful Python tokens
and 1,215 executable AST nodes, including syntax validation, substitution,
every rule, JSON CLI, and the declaration of the designated absurd formula.
It deletes 38 tokens and 37 AST nodes from the
smallest inspected token baseline, without introducing another rule.

The critical qualification is explicit: this is a calculus with DEFINED
absurdity and a faithful ordinary full-logic presentation T+. T+ includes
genuine separation and is bi-interpretable with iPRA on the whole carrier.
It is not the bare positive theory obtained by leaving an unrelated bottom
unused and omitting separation. The latter has singleton models.

All of the full-language axioms and rules of T+ translate to native proofs;
separation translates to the identity implication (0=S0)=>(0=S0).
The report proves both interpretation round trips, internal recursion
uniqueness, quantifier-free reflection, and syntactic equiconsistency.

REPRODUCE
---------
Python 3.10 or later and its standard library suffice for the code:

  python3 reproduce.py

This replays certificates and adversarial checks, recomputes the complete
candidate/baseline measurements, and reproduces the copied-source comparison.

For one certificate:

  python3 code/checker.py code/certificates/derived_reflexivity.json

For an intentionally invalid certificate:

  python3 -O code/checker.py code/certificates/forbidden_non_equation_induction.json

The valid one prints ACCEPT with exit status 0. The invalid one prints REJECT
and exits 1. An accepted certificate with nonempty assumptions proves only
that sequent; use an empty assumptions list for an unconditional theorem.

To rebuild the PDF and ZIP, also install pdflatex and the packages named in
report.tex, then run:

  python3 build.py

The rebuilt PDF's metadata may change. Executable source metrics and proof
outcomes are reproducible under the stated Python accounting convention.

CONTENTS
--------
report.pdf, report.tex          Full mathematical paper and source
comparison_section.tex         Exact source comparison included by the paper
SPECIFICATION.txt              Entire calculus in plain text
code/checker.py                Complete trusted candidate checker
code/baseline_checker.py       Exact current baseline from the pinned archive
code/kernel_deletion.patch     Full source difference
code/derived.py                Untrusted proof builders
code/translate_baseline.py     Untrusted translation of baseline proof trees
code/test_kernel.py            Regression and adversarial replay
code/test_results.json         Exact observed outcomes
code/measure.py                Reproducible complete-checker measurements
code/metrics.json              Counts, conventions, and source hashes
code/certificates/             Accepted and intentionally rejected inputs
code/baseline_certificates/    Exact source proof fixtures
comparisons/                  Copied complete checker sources for recounting
provenance/                   Pinned source manifest and independent audits
audit_sources.py              Recounts copied source implementations
reproduce.py, build.py         Reproduction and packaging entry points
SHA256SUMS.txt                 File checksums, excluding this hash list itself

PROVENANCE AND CREDIT
---------------------
The source comparison is pinned to VladimirReshetnikov/ProveIt commit
b079e5787b1d708049ff0643ce1b534c1a225198, docs/drafts, all eleven archives.
The immediate baseline is ipra_kernel_2026-11-06.zip, Git blob
0bee2393b3753b941f6f38980c85ac398196a077. Its exact checker and 53 proof
fixtures are included with provenance. The binder design, native recursion,
arithmetic reflection, and interpretation technique are inherited and
explicitly credited. Earlier drafts also discuss arithmetic absurdity with
full-logic completion. The present advance is the strict falsity/bridge
deletion from the smallest two-binder implementation, with its exact
measurements and a complete explanation of its full-logic meaning.

VERIFICATION STATUS
-------------------
The package provides written general mathematical proofs plus 73 accepted
proof trees, 29 rejected certificates, and 204 command-line replays across
ordinary and optimized Python. It translates 53 baseline proofs, and all
73 candidate positive proofs also pass the unchanged baseline checker.

These finite checks are not a Lean/Rocq proof of the metatheory or a formally
verified Python implementation. The result is below the inspected complete
checker envelope under the reported metrics, not a global minimum over all
programming languages and encodings. No source repository was modified.
