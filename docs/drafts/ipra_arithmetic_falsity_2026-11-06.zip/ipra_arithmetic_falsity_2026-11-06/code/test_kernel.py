"""Replay real derivations and reject malformed/eigenvariable violations.

No finite test suite proves the general interpretation or kernel soundness.
The candidate and baseline are independently called on every positive tree.
"""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

import checker as k
import baseline_checker as b
import derived as d
import translate_baseline as tr

ROOT = Path(__file__).resolve().parent
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)


def document(g, a, p):
    return {"assumptions": list(g), "goal": a, "proof": p}


def accepted(data):
    try:
        return k.check(json.loads(json.dumps(data))) is True
    except ERRORS:
        return False


def run():
    positive = {}
    source_rows = []
    for path in sorted((ROOT / 'baseline_certificates').glob('*.json')):
        old = json.loads(path.read_text())
        new = tr.certificate(old)
        positive['translated_' + path.stem] = new
        source_rows.append(path.name)
    positive['derived_reflexivity'] = d.certificate(d.eq(0, 0), d.refl(0))
    positive['arbitrary_equation_explosion'] = d.certificate(
        d.eq(0, 1), d.collapse(('hyp', 0), 0, 1), [d.FALSE])
    compound = ('pi', d.eq(0, 1), ('sig', d.eq(2, 1), ('pi', d.FALSE, d.eq(1, 3))))
    positive['compound_pi_sigma_explosion'] = d.certificate(
        compound, d.explode(('hyp', 0), compound, 1), [d.FALSE])
    positive['general_successor_separation'] = d.certificate(
        d.FALSE, d.separate(0, ('hyp', 0)), [d.eq(d.Z, d.suc(0))])
    formula = d.eq(d.rec(0, 1, 0), 1)
    left = d.rec(d.suc(0), 1, 0)
    step = d.trans(('rec', left), ('hyp', 0), left)
    proof = ('nat', formula, 1, ('rec', d.rec(d.Z, 0, 0)), step)
    positive['parameterized_recursion_uniqueness_example'] = d.certificate(
        d.eq(d.rec(1, 0, 0), 0), proof)
    triples = [(d.TRUE, d.FALSE, d.TRUE),
               (d.eq(0, d.Z), d.eq(1, d.ONE), d.eq(2, 0)),
               (('pi', d.eq(0, 1), d.eq(2, 0)), ('sig', d.eq(0, 1), d.FALSE),
                ('sig', ('pi', d.eq(0, 2), d.eq(1, 3)), d.TRUE))]
    for i, (a, bb, c) in enumerate(triples):
        positive[f'direct_or_left_{i}'] = d.certificate(d.disjunction(a, bb), d.or_left(a, bb), [a])
        positive[f'direct_or_right_{i}'] = d.certificate(d.disjunction(a, bb), d.or_right(a, bb), [bb])
        positive[f'direct_or_elimination_{i}'] = d.certificate(
            c, d.or_eliminate(a, bb, c), [d.disjunction(a, bb), d.implies(a, c), d.implies(bb, c)])
    # The baseline FALSE case has no IH; its translation has an extra unused
    # equation IH. New assumptions introduced inside its branch must move.
    source = document([('false',)], ('false',),
        ('nat', ('false',), 0, ('hyp', 0),
         ('app', ('pi', ('false',), ('hyp', 1)), d.Z, ('hyp', 0))))
    positive['translated_bottom_case_context_alignment'] = tr.certificate(source)
    positive['pi_parameter_lift'] = document([d.eq(0, d.Z)], ('pi', d.TRUE, d.eq(1, d.Z)),
                                             ('pi', d.TRUE, ('hyp', 0)))
    sigma = ('sig', d.eq(0, d.Z), d.TRUE)
    positive['sigma_closed_result'] = document([sigma], d.TRUE,
        ('let', ('hyp', 0), d.TRUE, ('hyp', 2)))
    a = ('pi', d.TRUE, d.eq(1, 0))
    positive['transport_under_pi'] = document([d.eq(0, 1), k.inst(a, 0)], k.inst(a, 1),
                                               ('eq', ('hyp', 0), a, ('hyp', 1)))
    h = d.eq(('r', d.Z, d.Z, 2), d.Z)
    positive['transport_under_rec'] = document([d.eq(0, 1), k.inst(h, 0)], k.inst(h, 1),
                                               ('eq', ('hyp', 0), h, ('hyp', 1)))
    positive['large_free_support'] = document([d.eq(10**50, d.Z)], d.eq(10**50, d.Z), ('hyp', 0))
    negative = {}
    def reject(name, g, a, p):
        negative[name] = document(g, a, p)
    reject('pi_capture', [d.eq(0, d.Z)], ('pi', d.TRUE, d.eq(0, d.Z)), ('pi', d.TRUE, ('hyp', 0)))
    reject('sigma_witness_escape', [sigma], d.eq(0, d.Z), ('let', ('hyp', 0), d.eq(0, d.Z), ('hyp', 1)))
    sh = ('sig', h, d.TRUE)
    reject('sigma_escape_beneath_rec', [sh], h, ('let', ('hyp', 0), h, ('hyp', 1)))
    reject('transport_pi_capture', [d.eq(0, 1), k.inst(a, 0)], ('pi', d.TRUE, d.eq(0, 0)),
           ('eq', ('hyp', 0), a, ('hyp', 1)))
    reject('transport_rec_capture', [d.eq(0, 1), k.inst(h, 0)], d.eq(('r', d.Z, d.Z, 1), d.Z),
           ('eq', ('hyp', 0), h, ('hyp', 1)))
    a = ('pi', d.TRUE, d.eq(1, d.Z))
    reject('forbidden_non_equation_induction', [k.inst(a, d.Z)], k.inst(a, 0),
           ('nat', a, 0, ('hyp', 0), ('hyp', 1)))
    # An existing ambient parameter must not become the induction counter.
    reject('induction_captures_parameter', [d.eq(0, d.Z)], d.eq(0, d.Z),
           ('nat', d.eq(0, d.Z), 0, d.refl(d.Z), ('hyp', 0)))
    reject('induction_hypothesis_escape', [], d.FALSE,
           ('nat', d.TRUE, d.Z, d.refl(d.Z), ('hyp', 0)))
    r = ('r', 0, d.Z, 0)
    reject('unknown_recursion_counter', [], d.eq(r, d.Z), ('rec', r))
    reject('recursive_formula_body', [], d.TRUE, ('rec', ('r', d.Z, d.Z, d.TRUE)))
    reject('wrong_rec_arity', [], d.TRUE, ('rec', ('r', d.Z, d.Z)))
    reject('rec_not_a_term', [], d.TRUE, ('rec', 0))
    reject('boolean_variable', [d.eq(True, d.Z)], d.eq(True, d.Z), ('hyp', 0))
    reject('boolean_hypothesis_index', [d.TRUE], d.TRUE, ('hyp', False))
    reject('negative_variable', [d.eq(-1, d.Z)], d.eq(-1, d.Z), ('hyp', 0))
    reject('negative_hypothesis_index', [d.TRUE], d.TRUE, ('hyp', -1))
    reject('unproved_absurdity', [], d.FALSE, ('hyp', 0))
    reject('primitive_reflexivity_absent', [], d.TRUE, ('refl', d.Z))
    reject('primitive_abort_absent', [d.FALSE], d.TRUE, ('abort', ('hyp', 0), d.TRUE))
    reject('primitive_bridge_absent', [d.FALSE], d.FALSE, ('bridge', ('hyp', 0)))
    reject('primitive_false_absent', [('false',)], ('false',), ('hyp', 0))
    reject('malformed_eq_template', [d.TRUE], d.TRUE, ('eq', ('hyp', 0), ('=', 0), ('hyp', 0)))
    reject('boolean_nat_target', [d.FALSE], d.FALSE, ('nat', d.FALSE, True, ('hyp', 0), ('hyp', 0)))
    negative['extra_root_key'] = {**document([d.TRUE], d.TRUE, ('hyp', 0)), 'scope': 0}
    negative['non_list_assumptions'] = {'assumptions': None, 'goal': d.TRUE, 'proof': ('hyp', 0)}
    reject('wrong_app_guard', [('pi', d.FALSE, d.TRUE), d.TRUE], d.TRUE,
           ('app', ('hyp', 0), d.Z, ('hyp', 1)))
    reject('wrong_sigma_component', [d.TRUE], ('sig', d.TRUE, d.FALSE),
           ('pair', ('sig', d.TRUE, d.FALSE), d.Z, ('hyp', 0), ('hyp', 0)))
    reject('formula_as_witness', [d.TRUE], ('sig', d.TRUE, d.TRUE),
           ('pair', ('sig', d.TRUE, d.TRUE), d.TRUE, ('hyp', 0), ('hyp', 0)))
    reject('wrong_eq_source', [d.eq(0, 1), d.eq(2, 2)], d.eq(1, 0),
           ('eq', ('hyp', 0), d.eq(0, 1), ('hyp', 1)))
    out = ROOT / 'certificates'
    out.mkdir(exist_ok=True)
    outcomes = []
    for expected, rows in [(True, positive), (False, negative)]:
        for name, data in rows.items():
            if accepted(data) != expected:
                raise AssertionError(('API outcome', name, expected))
            if expected:
                b.check(json.loads(json.dumps(data)))
            path = out / (name + '.json')
            path.write_text(json.dumps(data, separators=(',', ':')) + '\n')
            for optimized in (False, True):
                cmd = [sys.executable, *(['-O'] if optimized else []), str(ROOT/'checker.py'), str(path)]
                run = subprocess.run(cmd, text=True, capture_output=True)
                if run.returncode != (0 if expected else 1) or run.stdout.strip() != ('ACCEPT' if expected else 'REJECT'):
                    raise AssertionError(('CLI outcome', name, run.returncode, run.stdout, run.stderr))
            outcomes.append({'name': name, 'expected': expected, 'api': 'pass', 'cli': 'pass', 'optimized_cli': 'pass'})
    result = {'checker_sha256': hashlib.sha256((ROOT/'checker.py').read_bytes()).hexdigest(),
              'baseline_sha256': hashlib.sha256((ROOT/'baseline_checker.py').read_bytes()).hexdigest(),
              'accepted_count': len(positive), 'rejected_count': len(negative),
              'baseline_fixtures_translated': len(source_rows),
              'baseline_cross_checks': len(positive), 'cli_checks': 2*len(outcomes),
              'outcomes': outcomes,
              'scope': 'Finite proof replays and rejection tests; no proof-assistant formalization of universal metatheorems.'}
    (ROOT/'test_results.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({key: result[key] for key in ('accepted_count', 'rejected_count', 'baseline_fixtures_translated', 'baseline_cross_checks', 'cli_checks')}, indent=2))
    return result


if __name__ == '__main__':
    run()
