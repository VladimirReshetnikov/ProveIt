"""Measure complete kernels under identical lexical/AST conventions."""
import ast
import hashlib
import io
import json
from pathlib import Path
import tokenize
import sys

ROOT = Path(__file__).resolve().parent
SKIP = {tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE, tokenize.ENCODING,
        tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def executable(source):
    tree = ast.parse(source)
    for n in ast.walk(tree):
        if isinstance(n, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if n.body and isinstance(n.body[0], ast.Expr) and isinstance(n.body[0].value, ast.Constant) and isinstance(n.body[0].value.value, str):
                n.body.pop(0)
    return tree


def measure(path):
    raw = path.read_bytes()
    tree = executable(raw.decode('utf-8'))
    normalized = ast.unparse(tree) + '\n'
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(normalized).readline) if t.type not in SKIP]
    return {'file': path.name, 'sha256': hashlib.sha256(raw).hexdigest(),
            'raw_utf8_bytes': len(raw), 'executable_utf8_bytes': len(normalized.encode()),
            'meaningful_python_tokens': len(tokens), 'executable_ast_nodes': len(list(ast.walk(tree))),
            'executable_nonempty_lines': len([s for s in normalized.splitlines() if s.strip()])}


def run():
    old, new = (measure(ROOT/name) for name in ('baseline_checker.py', 'checker.py'))
    metrics = ('raw_utf8_bytes', 'executable_utf8_bytes', 'meaningful_python_tokens', 'executable_ast_nodes', 'executable_nonempty_lines')
    result = {'python': sys.version.split()[0], 'baseline': old, 'candidate': new,
              'savings': {m: {'absolute': old[m]-new[m], 'percent': round(100*(old[m]-new[m])/old[m], 6)} for m in metrics},
              'trust_boundary': 'Entire standalone checker, including JSON adapter, validation, binding operations, all rule clauses and fixed data. Python/json/sys are common runtimes.',
              'scope': 'Strict deletion comparison with the pinned draft_3 program. Excludes generators, translator, certificates, tests, reports. Docstrings are removed only for executable metrics; no executable statement is removed. No global minimum theorem.'}
    (ROOT/'metrics.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    run()
