"""Untrusted certificate builders; never imported by the checker.

Adapted from the pinned draft's derived.py. Falsity is the equation 0=S0.
Every output is an ordinary proof tree checked by checker.py.
"""

import checker as k

Z = k.ZERO
ONE = ("s", Z)
TRUE = ("=", Z, Z)
FALSE = ("=", Z, ONE)


def eq(s, t):
    return ("=", s, t)


def suc(t):
    return ("s", t)


def rec(n, a, h):
    return ("r", n, a, h)


def implies(a, b):
    return ("pi", k.shift(a), k.shift(b))


def conjunction(a, b):
    return ("sig", k.shift(a), k.shift(b))


def disjunction(a, b):
    return ("sig", ("pi", eq(1, Z), k.shift(a, 2)),
            ("pi", eq(1, suc(0)), k.shift(b, 2)))


def refl(t):
    p = ("rec", rec(Z, t, Z))
    return ("eq", p, eq(0, k.shift(t)), p)


def sym(p, left):
    return ("eq", p, eq(0, k.shift(left)), refl(left))


def trans(p, q, left):
    return ("eq", q, eq(k.shift(left), 0), p)


def collapse(clash_proof, s, t):
    h = k.shift(t, 2)
    r1 = rec(ONE, s, h)
    template = eq(rec(0, k.shift(s), k.shift(t, 3)), k.shift(s))
    moved = ("eq", clash_proof, template, ("rec", rec(Z, s, h)))
    return trans(sym(moved, r1), ("rec", r1), s)


def separate(n, zero_successor_proof):
    r1 = rec(suc(n), Z, ONE)
    moved = ("eq", zero_successor_proof, eq(rec(0, Z, ONE), Z),
             ("rec", rec(Z, Z, ONE)))
    return trans(sym(moved, r1), ("rec", r1), Z)


def lift(p, context_size, bound=0):
    def term(a, extra=0):
        return k.walk(a, lambda i, d: i + d + 1, bound + extra)

    def proof(q, extra=0):
        return lift(q, context_size, bound + extra)

    match p:
        case ("hyp", i):
            return ("hyp", i + (i >= context_size))
        case ("pi", a, q):
            return ("pi", term(a, 1), proof(q, 1))
        case ("app", p, t, q):
            return ("app", proof(p), term(t), proof(q))
        case ("pair", a, t, p, q):
            return ("pair", term(a), term(t), proof(p), proof(q))
        case ("let", p, a, q):
            return ("let", proof(p), term(a), proof(q, 1))
        case ("eq", p, a, q):
            return ("eq", proof(p), term(a, 1), proof(q))
        case ("rec", r):
            return ("rec", term(r))
        case ("nat", a, t, p, q):
            return ("nat", term(a, 1), term(t), proof(p), proof(q, 1))
        case _:
            raise ValueError("unknown proof")


def explode(clash_proof, formula, context_size):
    match formula:
        case ("=", s, t):
            return collapse(clash_proof, s, t)
        case ("pi", a, b):
            return ("pi", a, explode(lift(clash_proof, context_size), b, context_size + 1))
        case ("sig", a, b):
            return ("pair", formula, Z,
                    explode(clash_proof, k.inst(a, Z), context_size),
                    explode(clash_proof, k.inst(b, Z), context_size))
        case _:
            raise ValueError("unknown formula")


def or_left(a, b, assumption=0, context_size=1):
    first = ("pi", TRUE, ("hyp", assumption))
    second = ("pi", eq(Z, suc(0)),
              explode(separate(0, ("hyp", context_size)), k.shift(b), context_size + 1))
    return ("pair", disjunction(a, b), Z, first, second)


def or_right(a, b, assumption=0, context_size=1):
    first = ("pi", eq(ONE, Z),
             explode(sym(("hyp", context_size), ONE), k.shift(a), context_size + 1))
    second = ("pi", eq(ONE, suc(0)), ("hyp", assumption))
    return ("pair", disjunction(a, b), ONE, first, second)


def or_eliminate(a, b, c):
    predicate = implies(eq(1, 0), k.shift(c, 2))
    base = ("pi", eq(1, Z),
            ("app", ("hyp", 1), Z,
             ("app", ("hyp", 3), Z, ("hyp", 5))))
    step = ("pi", eq(2, suc(1)),
            ("app", ("hyp", 2), Z,
             ("app", ("hyp", 4), 1, ("hyp", 5))))
    cases = ("nat", predicate, 0, base, step)
    return ("let", ("hyp", 0), c, ("app", cases, Z, refl(0)))


def certificate(goal, proof, assumptions=()):
    result = {"assumptions": list(assumptions), "goal": goal, "proof": proof}
    k.check(result)
    return result
