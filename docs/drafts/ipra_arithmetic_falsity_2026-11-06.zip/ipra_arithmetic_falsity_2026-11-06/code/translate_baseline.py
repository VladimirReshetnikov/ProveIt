"""Untrusted translation: replace baseline falsity by 0=S0 and erase bridge.

The proof checker never imports this module. The additional unused equation
IH introduced when a FALSE number-rule matrix becomes an equation is tracked
explicitly in the context map; local hypothesis indices are adjusted.
"""

import baseline_checker as b
import checker as k

Z = k.ZERO
CLASH = ("=", Z, ("s", Z))


def expression(a):
    if type(a) is int:
        return a
    if a == ("false",):
        return CLASH
    return (a[0], *map(expression, a[1:]))


def proof(p, old_context, new_context, indices):
    def go(q):
        return proof(q, old_context, new_context, indices)

    match p:
        case ("hyp", i):
            return ("hyp", indices[i])
        case ("bridge", q):
            return go(q)
        case ("pi", a, q):
            old = (*map(b.shift, old_context), a)
            new = (*map(k.shift, new_context), expression(a))
            return ("pi", expression(a), proof(q, old, new, (*indices, len(new_context))))
        case ("app", p, t, q):
            return ("app", go(p), expression(t), go(q))
        case ("pair", a, t, p, q):
            return ("pair", expression(a), expression(t), go(p), go(q))
        case ("let", p, c, q):
            a = b.infer(p, old_context)
            old = (*map(b.shift, old_context), a[1], a[2])
            new = (*map(k.shift, new_context), expression(a[1]), expression(a[2]))
            m = len(new_context)
            return ("let", go(p), expression(c), proof(q, old, new, (*indices, m, m+1)))
        case ("eq", p, a, q):
            return ("eq", go(p), expression(a), go(q))
        case ("rec", r):
            return ("rec", expression(r))
        case ("nat", a, t, p, q):
            aa = expression(a)
            oh = (a,) if a[0] == "=" else ()
            nh = (aa,) if aa[0] == "=" else ()
            old = (*map(b.shift, old_context), *oh)
            new = (*map(k.shift, new_context), *nh)
            mapping = (*indices, len(new_context)) if oh else indices
            return ("nat", aa, expression(t), go(p), proof(q, old, new, mapping))
        case _:
            raise ValueError("unknown source proof")


def certificate(data):
    b.check(data)
    old = tuple(map(b.freeze, data["assumptions"]))
    new = tuple(map(expression, old))
    result = {"assumptions": list(new), "goal": expression(b.freeze(data["goal"])),
              "proof": proof(b.freeze(data["proof"]), old, new, tuple(range(len(old))))}
    k.check(result)
    return result
