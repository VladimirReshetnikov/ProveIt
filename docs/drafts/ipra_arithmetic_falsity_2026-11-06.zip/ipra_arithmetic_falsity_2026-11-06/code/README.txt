EXECUTABLE ARTIFACTS: iPRA WITH ARITHMETIC ABSURDITY
=================================================

Trusted acceptance program: checker.py only.
Python 3.10+ and standard-library json/sys are its only runtime dependencies.
Run:

  python3 code/checker.py code/certificates/derived_reflexivity.json
  python3 -O code/checker.py code/certificates/forbidden_non_equation_induction.json

The first exits 0 and prints ACCEPT. The second exits 1 and prints REJECT.
A nonempty assumptions list certifies a sequent, not an unconditional theorem.
The supported input boundary is check(data), or the CLI. infer is internal.
Direct Python callers supply finite JSON-shaped plain data (or recursively
frozen tuples), not host-language objects with custom equality or indexing.

To reproduce measurements and regression evidence:

  python3 code/test_kernel.py
  python3 code/measure.py

baseline_checker.py is an exact copy of code/checker.py from
  VladimirReshetnikov/ProveIt
  commit b079e5787b1d708049ff0643ce1b534c1a225198
  docs/drafts/ipra_kernel_2026-11-06.zip
  archive member ipra_kernel_2026-11-06/code/checker.py
Its SHA-256 is
  4228564e6bbebbab98246f7879f01cedf80c566edbf814b14afb0cba6d2af0d2.
The 53 baseline_certificates/*.json are exact copies from the same archive.
Adapted helper code and test ideas are identified in module docstrings.

Relative to that exact baseline, the executable candidate deletes only:
  1. the FALSE global declaration;
  2. the false constructor's syntax-recognition clause;
  3. the bridge inference clause.
The original CLASH declaration is retained verbatim and counted, although
infer never special-cases this formula. This charges the designated
absurdity datum to the checker source.
The module docstring is updated to describe the new calculus.
kernel_deletion.patch records the complete source difference.
No new axiom, proof rule, syntax case, hidden normalizer, input translator,
or arithmetic engine is added to acceptance.

The ordinary full-logic encoder is NOT part of the native checker. It is an
untrusted elaborator: its outputs must be checked as native certificates.
This boundary is identical to the baseline native-language checker boundary.
The report supplies the general logic reconstruction and interpretation.

JSON has exactly keys assumptions, goal, proof. Terms and formulas are:
  nonnegative integer        variable index (NOT an object-level numeral)
  ["z"]                      zero
  ["s",t]                    successor
  ["r",n,a,h]                initialized recursion; h binds state0/counter1
  ["=",s,t]                  equation
  ["pi",A,B]                 binds number0 in both A and B
  ["sig",A,B]                binds number0 in both A and B
No primitive falsity constructor exists. The expression ["=",["z"],["s",["z"]]]
is designated absurdity. All finite nonnegative variable indices are legal;
bound variables are managed by shifting all ambient assumptions.

Proof constructors (premise proofs are recursive trees):
  ["hyp",i]
  ["pi",antecedent_template,body_proof]
  ["app",pi_proof,witness_term,antecedent_proof]
  ["pair",sigma_formula,witness_term,first_proof,second_proof]
  ["let",sigma_proof,outer_goal,branch_proof]
  ["eq",equality_proof,formula_template,source_proof]
  ["rec",recursor_term]
  ["nat",formula_template,target_term,base_proof,step_proof]

The nat template has its induction variable at slot 0. Its equation case
adds the template as the last shifted-context assumption. Its non-equation
case adds no assumption. The target is substituted for slot 0. rec unfolds
one syntactic zero or successor clause; it cannot evaluate an unknown counter.

Testing evidence
----------------
73 accepted proof trees, 29 rejected certificates, 204 CLI replays (all in both
ordinary and -O modes), 53 source proofs translated, and all 73 candidate
positive proof trees also accepted by the unchanged baseline. See the complete
outcomes in test_results.json. Sources include full disjunction introduction
and elimination with quantified formulas, arithmetic collapse, structural
explosion, successor laws, equation induction, and parameterized recursion.
The translation replaces source false with 0=S0 and deletes every bridge
node. It correctly accounts for the extra unused equation induction hypothesis
when a source false matrix becomes an equation. The dedicated alignment
fixture requires a local source hypothesis at index 1 to move to index 2.

Verification boundary
---------------------
The tests are finite executable evidence. They are not a formal proof of the
Python implementation, the general soundness theorem, the source transformer,
or the general bi-interpretation theorem. Those are mathematical arguments in
the report. Inputs are parsed as JSON, not evaluated as executable code.
Memory/recursion limits can reject sufficiently large valid proofs. No assert
statement influences acceptance; optimized Python uses the same checker.

Final counted source, including the designated absurdity datum
-------------------------------------------------------------
                              baseline       candidate       saving
Raw UTF-8 source bytes             4334            4093          241
Normalized executable bytes        3807            3648          159
Meaningful Python tokens           1167            1129           38
Executable AST nodes               1252            1215           37
Executable nonempty lines           102              97            5

The retained source line is exactly:
  CLASH = ("=", ZERO, ("s", ZERO))
It has no special inference semantics. Its bytes, lexical tokens and AST
nodes are nevertheless included in every candidate measurement.
Final checker SHA-256:
  30946dea902ae933cc7be75a3462410d83bd2d60b6e4234e2dc333428b451dcc
The same hash is recorded in metrics.json and test_results.json.
