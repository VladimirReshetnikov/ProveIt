"""Reproduce checks, compile the paper, and package the complete deliverable."""
from pathlib import Path
import hashlib
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
PACKAGE = 'ipra_arithmetic_falsity_2026-11-06'
OMIT_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc'}


def included():
    return [p for p in sorted(ROOT.rglob('*')) if p.is_file()
            and '__pycache__' not in p.parts
            and p.suffix not in OMIT_SUFFIXES
            and not any(x.startswith('.') for x in p.relative_to(ROOT).parts)]


def package():
    records = [hashlib.sha256(p.read_bytes()).hexdigest() + '  ' +
               p.relative_to(ROOT).as_posix() for p in included()
               if p.name != 'SHA256SUMS.txt']
    (ROOT / 'SHA256SUMS.txt').write_text('\n'.join(records) + '\n')
    destination = ROOT.parent / (PACKAGE + '.zip')
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for p in included():
            info = zipfile.ZipInfo(PACKAGE + '/' + p.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 6, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, p.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('Archive integrity check failed')
    print(destination)
    return destination


def main():
    subprocess.run([sys.executable, str(ROOT / 'reproduce.py')], cwd=ROOT, check=True)
    for _ in range(3):
        subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                        'report.tex'], cwd=ROOT, check=True, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT)
    package()


if __name__ == '__main__':
    main()
