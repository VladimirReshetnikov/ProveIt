# An Arity Calculus for iPRA

Research prepared for Vladimir Reshetnikov, 10 November 2026.

## Result

This package presents a new certificate grammar and complete proof checkers for an inherited, full intuitionistic primitive recursive arithmetic presentation. A paired formula is unary; its closure is three copies of its body. Every array uses the same opening-depth increment, `5 - len(node)`. Surplus arities have an explicitly constant interpretation, which makes the shorter traversal mathematically meaningful.

The written argument establishes equivalence of the canonical consequence relation with the inherited Choice-DI calculus, and transfers its full-domain bi-interpretation with iPRA. The arithmetic basis, reconstruction of ordinary logic, and primitive-recursion bridge are inherited and attributed. The new contribution is the representation, scope traversal, conservative decoding, and resulting complete implementations.

**Scope of the result:** this is a structural simplification with small measured savings. It does not establish an absolute simplest axiomatization, a new arithmetic foundation, or a major breakthrough. The proofs have not been checked in a proof assistant. No single delivered program beats all three previous coordinate minima simultaneously.

## Read first

- `report.pdf`: complete 38-page report, including the native rules, interpretations, checker proof, comparison, limitations, and attributed arithmetic appendices.
- `report.tex`: editable main source; it includes `theory/checker.tex`, generated tables in `evidence/`, and the attributed proofs in `reference/`.
- `CLAIMS.json`: machine-readable statement of claims and limits.
- `code/checker.py`: preferred complete checker, with an explicit list test and a structurally terminating opening recursion on finite JSON trees.
- `code/readable_checker.py`: annotated expansion of the same construction.

## Exact measurements

Measurements below use Python 3.12.14 and zlib 1.3.2. The entire module is counted, including JSON input, scope checks, logical and arithmetic rules, and the verdict driver. Normalization removes comments and genuine docstrings, applies `ast.unparse`, and appends a newline. Tokens are significant normalized Python tokens; AST counts include the full module.

| Complete implementation | Tokens | AST nodes | Normalized UTF-8 bytes | Raw bytes | Gzip-9 of raw source |
|---|---:|---:|---:|---:|---:|
| Existing corpus coordinate minima, from different programs | 277 | 311 | 672 | — | — |
| `code/checker.py` | 274 | 320 | 667 | 667 | 391 |
| `code/checker_bytes.py` | 274 | 322 | 659 | 659 | 387 |
| `code/checker_tokens.py` | 273 | 311 | 692 | 692 | 383 |
| `code/checker_ast.py` | 275 | 308 | 690 | 689 | 384 |

The new family reaches coordinate minima **273 / 308 / 659**, again using different programs. The old minima are observed best implementations in this snapshot, not a proved mathematical lower bound. Gzip is informational and was not used as an optimization target. It is computed as `gzip.compress(source_bytes, compresslevel=9, mtime=0)`; the corresponding `.py.gz` files are included.

The token and AST profiles use a generic exception-based traversal and retain a malformed-string/resource-limit qualification discussed in the report. The primary program avoids that qualification. The byte profile uses the inherited exact-JSON-type zero-product list predicate.

## Run and reproduce

The checkers and verification scripts require only Python's standard library. The recorded measurements are for Python 3.12; `ast.unparse` output and zlib output can differ across versions.

From this directory:

```sh
python3 code/checker.py < examples/state_update.json
python3 code/checker.py < examples/zero_witness_induction.json
python3 code/checker.py < examples/false_equation.json
```

The first two should print `ACCEPT` and exit with status zero. The third should print `REJECT`, emit the underlying exception traceback, and exit nonzero. Each input is a JSON proof stack, whose last element is the goal. The public driver begins with no assumptions. Certificates can contain unused stack prefixes; the checked suffix is the proof. Do not count mere presence of `ACCEPT` in arbitrary output as a successful verdict: the verification harness checks both exact output and exit status.

To reproduce all supplied measurements and finite checks:

```sh
python3 verify.py
```

This runs:

1. `measure.py`: remeasures the supplied programs and all 297 distinct frozen historical sources without executing historical checker code.
2. `tests/test_checkers.py`: 400 complete CLI runs across five programs, normal Python and `-O`, including positive, adversarial, and malformed-input examples.
3. `tests/independent_audit.py`: 529,562 evaluations of generated zero-instance equations and 216 independent binder-substitution comparisons.
4. `tests/mutation_controls.py`: three deliberately unsafe temporary mutations, each admitting an explicit false equation that the correct checker rejects, under normal Python and `-O`.

Results are written to `evidence/`. Finite testing supports the implementation review; universal soundness, completeness, and bi-interpretability rest on the written proofs. The producer in `tests/producer.py` handles the supplied named proof examples and is outside the checker. It is not a complete automatic compiler from arbitrary ordinary-iPRA derivations.

To rebuild the PDF after verification, install a standard TeX distribution with `latexmk`, `pdflatex`, and the packages listed in `report.tex`, then run:

```sh
python3 build.py
```

## Construction in brief

Numerical terms are `x`, `0`, `S(t)`, and the scalar iterator `I(n,a;v.h)`, governed by the zero and successor equations. Iteration binds one state variable in its update, with passive parameters fixed. It is a finite staged syntax, not a total evaluator for arbitrary program codes.

The native formula constructors are equality and the paired binder

```text
D(x,y).B  :=  exists x (B(x,0) -> forall y B(x,y)).
Q(y).B    :=  B(0) -> forall y B(y).
```

The report gives the precise complementary case/progress introductions, elimination rules, equality transport, and local computation supply. Progress is restricted to literal equations. Ordinary intuitionistic connectives and quantifiers are internally reconstructed.

The new raw encodings are equality `[s,t]`, paired binder `[B]`, and canonical closure `[B,B,B]`. At formula positions, an array of length at least four means the fixed truth `0=0`; at numerical positions it means zero. The first two fields of a general ternary formula are ignored annotations, while its third field carries the closure body. Canonical closures repeat that body three times.

Multiplying a checked major array by three exports precisely the desired closure from a unary paired formula and a harmless truth from every other nonempty array. With numerical roots at depth three, `5 - len(node)` gives the necessary increments for paired binders, equations, closures, and state binding. The report proves why opening, freshness, supply, and the resulting accepted proofs respect that decoding.

The universal invariant is semantic opening at meaningful sorted roots, conditional on successful calls. A blanket raw revalidation or idempotence claim is false below ignored high-arity nodes. The report includes the counterexample and the corrected invariant.

## Costs and limits

- The smaller source can produce larger certificates. Nested explicitly serialized triplicate closures can grow as `3^r` with nesting depth `r`.
- The arithmetic computation supply needs a proved zero instance. It is not assumed true for every value of a newly allocated parameter.
- Full-domain bi-interpretability includes actual equality and provable round trips; it is stronger than agreement on standard numerals or equiconsistency alone.
- Python, its JSON decoder, standard library, and runtime remain the shared execution environment used in the supplied drafts' comparison convention. Their implementations are not included in the reported Python-source size.
- No absolute size lower bound, literature-wide novelty claim, or proof-assistant formalization is supplied.

## Provenance and archive contents

The comparison is pinned to `VladimirReshetnikov/ProveIt`, commit:

```text
0300a290bedee5019c974291850b798378438b2e
```

Source URL: <https://github.com/VladimirReshetnikov/ProveIt/tree/0300a290bedee5019c974291850b798378438b2e/docs/drafts>

All 16 direct archives were inspected. Recursive inventory found 2,249 Python occurrences representing 297 distinct source hashes. `sources/python/` retains those exact bytes, and `sources/python_index.json` maps occurrences to hashes. `evidence/boundary_classification.json` classifies the 28 distinct sources at or below at least one observed complete-checker boundary: five complete checkers and 23 supporting programs.

`reference/ATTRIBUTION.json` and `tests/ATTRIBUTION.json` identify inherited material. The upstream license is retained as `reference/ProveIt_LICENSE.txt`. Report references distinguish inherited mathematical results from the new encoding argument. `SHA256SUMS` covers the delivered package files except itself.
