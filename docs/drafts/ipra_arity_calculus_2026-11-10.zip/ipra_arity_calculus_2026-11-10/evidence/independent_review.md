# Independent audit: triplicated closure and reversed binder arities

Reviewed principal source: `code/checker_bytes.py`, SHA-256 `486de999d1aa46b6b9dbda0ca625f86c6cc0f134134a377542e23fdcabc75e21`. The try/AST variants were also read, and the historical malformed-input counterexample was submitted to all three complete programs under normal Python and `-O`.

This review concerns the final triplicate protocol. It supersedes the earlier uniform-depth experiment review for purposes of the proposed deliverable. No independent proof-assistant certification is claimed. The final AST profile additionally folds the reader binding into the first checker call; the assignment and calls retain their order, and the delivered CLI suite covers this final spelling.

## Structural change and decoder

A paired binder D has one raw child. A closure Q has three copies of its body. Equations retain two children. Thus the common elimination continuation can use `major * 3`:

- one-child D yields the three-copy Q closure;
- every other nonempty array yields arity at least six, with formula meaning truth.

The opener's depth increment is `5 - len(node)`, giving increments 4, 3, and 2 at the three meaningful arities. Numerical roots use depth 3. The numerical syntax still has zero, successor, and an initialized scalar iterator, but successor now contributes two dummy zero slots and the iterator contributes one local slot. Its counter and seed see one dummy zero; its update sees one previous-state variable. This removes the former duplicated numerical state slot.

Numerical arity zero, two, or at least four denotes zero; unary nodes denote successor; ternary nodes denote iteration. Formula arity zero or at least four denotes truth; one denotes D; two denotes equality; three denotes Q (its third child carries the meaningful body, with the remaining annotations ignored in the general raw decoder). The canonical Q representation repeats its body three times. All children are still traversed operationally, including ignored annotations.

Numerical coordinates below 3 denote zero. Protected coordinates then occur in pairs, with the nearest variable represented by 3 or 4. Canonical certificates use integer labels. The finite numerical diagnostic also tests several fractional aliases.

## Logical branch audit

For a genuine unary D goal, `i(*a, t, 2)` supplies exactly the expected three arguments. Goals of arity at least two supply too many arguments and reject. The empty-array case can make a shorter legal call because of defaults, but its original conclusion already means truth. Therefore the old dangerous positional-unpack shortcut becomes harmless in this new shape convention.

The historical certificate `[[0,0,0,[0,0]],[0,[0]]]`, which proved 0=1 in an earlier unsafe experiment, is rejected by every final variant. Its binary equality goal supplies too many positional arguments.

For a unary D major, triplication creates the canonical Q body and the shared opening substitutes the fresh witness while retaining the Q-bound coordinate. For any other nonempty array major, the added array is a truth constant, so an administrative continuation is sound. This is stronger and simpler than the earlier high-arity-as-absurdity experiment: no explosion argument is needed for a spurious larger major here.

Equality and Q endpoint agreement still matter. The kernel checks the major against the actual equality endpoints or exactly the triplicated closure body, and verifies the requested target before switching to the minor premise. The general raw Q decoder does not make unchecked annotations meaningful; the repeated pattern is the public specialization interface.

The parity guard continues to permit genuine progress only for literal equations, plus constant-truth matrices of even arity. The latter are harmless. D and Q both have odd arities, so their matrices do not acquire unrestricted compound induction.

## Nonvacuous binder and state checks

`tests/independent_audit.py` implements a separate named abstract syntax, capture-avoiding substitution for its globally distinct names, and an independent encoder. It does not import the production producer or checker-derived translation functions. It compares actual opener results with independently encoded expected substitutions.

All **216 exact syntactic comparisons** passed. They cover:

- witness substitution into D with both witness and successor variables genuinely used;
- fresh successor, zero-case, and current-variable openings;
- D elimination into a Q closure, with both bound coordinates present;
- arbitrary-term Q specialization;
- nested Q and D binders;
- numerical terms containing successor, nested iterators, and old passive parameters;
- recursive-state substitution inside nested updates.

These checks target the changed binder increments and the removal of the duplicate iterator state slot. They are finite examples, not the universal opening lemma.

## Generated computation assumptions

The independent numerical evaluator interprets the raw result of the arithmetic branch. It never calls the checker opener to evaluate numerical meaning. The new fresh parameter is set to zero, while four previously allocated parameters receive two distinct, nonconstant value assignments. Thus the test does not accidentally identify all old parameters with the new zero witness.

The audit considers **155,106 raw source triples** in both base and successor modes, for **310,212 supplies**. It includes integer coordinates from -6 through 11, several fractional coordinates, unary/binary padding, raw arrays of arity four through ten, nested iterator terms, and 80,000 deterministic random compound triples.

- 45,431 supplies rejected during generation;
- 264,781 supplies successfully generated;
- 529,562 equations evaluated, using two old-parameter valuations per successful supply;
- zero limited or undefined evaluations;
- **zero false evaluated equations**.

This supports the H(0) discharge obligation. It does not establish H(w) uniformly for arbitrary w; the known-zero-instance argument remains essential. It also does not replace the universal written supply proof.

## Semantic opening is the correct invariant

The expression `5 - len(node)` can produce negative traversal depth beneath ignored high-arity nodes. Consequently blanket raw syntactic revalidation or idempotence is false.

At floor -1:

    i([0,0,0,0,0,0], -1) == [-1,-1,-1,-1,-1,-1]

succeeds, but reopening the result without an image rejects: its leaves are visited at depth -1, where the interval test does not protect the label -1. Both arrays decode to truth. The receipt explicitly records this behavior as a qualification, not a soundness failure.

The proof must therefore state the opening theorem on meaningful decoded structure, conditional on successful calls. Ignored annotations may cause additional rejection or change their spelling without changing meaning. The arithmetic recursive-image argument should use semantic closedness and substitution, not a claimed literal identity `i(i(s)) == i(s)` for every raw tree.

Canonical D/Q/equality/iterator proofs remain the completeness language. Completeness need not require every noncanonical spelling of a truth constant to revalidate or be provable.

## Three unsafe controls

`tests/mutation_controls.py` temporarily creates three deliberately incorrect variants. For each, the correct kernel rejects an explicit false conclusion, and the modified kernel accepts it. Every contrast was verified under ordinary Python and `-O`, giving **12 complete process runs**:

1. Removing unary-D introduction arity enforcement admits `0 = 1`.
2. Removing major endpoint agreement admits `0 = 1`.
3. Removing recursive-state substitution admits `I(1,1;v.v) = 0`.

The exact certificates and verdicts are in `evidence/mutation_controls.json`. Temporary mutated programs are deleted after testing and are not deliverable kernels.

## Evidence files and limits

- `tests/independent_audit.py`
- `evidence/independent_result.json`
- `tests/mutation_controls.py`
- `evidence/mutation_controls.json`

These are independent finite diagnostics and a scoped mathematical/code review. They do not establish absolute simplicity, literature-wide novelty, or universal formal correctness of Python or the inherited iPRA bridge. The byte profile uses the exact-JSON-type zero-product list predicate; its correctness argument is inherited from the same specified-runtime comparison convention. The preferred primary kernel uses an explicit list test and the same proof protocol. The try variants retain the malformed-string/resource-limit qualifications already present in the corpus.
