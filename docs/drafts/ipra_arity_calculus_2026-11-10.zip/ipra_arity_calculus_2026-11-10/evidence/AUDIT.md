# Current iPRA draft comparison audit

Snapshot: `VladimirReshetnikov/ProveIt`, commit `0300a290bedee5019c974291850b798378438b2e`.

## Current attainable envelope

The 16 current direct ZIP archives contain complete standalone checker programs attaining the coordinatewise minimum **277 normalized significant Python tokens / 311 whole-module AST nodes / 672 normalized UTF-8 bytes**. Different programs attain the coordinates. A single new source must have at most **276 / 310 / 671** to be strictly below all three current coordinate minima.

| Complete documented source | Tokens | AST | Normalized bytes | Raw bytes | Gzip -9 raw bytes | Lines |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| constructed_computation/code/checker_explicit.py | 277 | 317 | 684 | 684 | 403 | 28 |
| scalar_successor/reference/old_generated_source_bytes_matched.py | 277 | 319 | 679 | 679 | 401 | 28 |
| transient_seed/code/checker_structure.py | 280 | 311 | 705 | 705 | 393 | 33 |
| counter_congruence/ancillary/zero_product.py | 281 | 322 | 672 | 672 | 397 | 28 |

These programs are included even where labeled reference or ancillary: a record is still a current corpus program. Conversely, a utility named checker or verify is not counted merely because of its filename.

The local_rewriting byte profile is **628 raw bytes**, but **685 normalized bytes**. It is not a 628-byte improvement under the established normalized comparison. This distinction is necessary to avoid rewarding reformatting. Older paper tables use 281/315/685 or still earlier envelopes and are no longer the current target.

An attained record is an upper bound on the unknown optimum, not a mathematical lower bound on all possible theories or checkers. Neither the baseline nor a new record establishes an absolute simplest axiomatization. Gzip is reported for information, not optimized.

## Reproduction

`measure_corpus.py` statically reads every Python member of every current ZIP and every nested ZIP. It executes no checker, producer, build script, or imported upstream source. It independently implements the inherited normalization: parse Python, remove genuine module/function/class docstrings, run `ast.unparse`, append one newline, count significant tokens and all AST nodes, measure UTF-8 bytes. The entire module is counted, including import, JSON parser invocation, input access, and public ACCEPT/REJECT driver. It does not use a core-only count.

Runtime: CPython 3.12.14; zlib 1.3.2. Gzip sizes are measured with `len(gzip.compress(source_bytes, compresslevel=9, mtime=0))`; no filename is put in the gzip header. Both raw-source and normalized-source gzip values are retained in `corpus_metrics.json`. Significant tokens exclude ENCODING, COMMENT, NL, NEWLINE, INDENT, DEDENT, and ENDMARKER.

The directly extracted tree contains 393 Python source occurrences / 262 distinct SHA-256 hashes; recursively traversing nested archives gives 2,249 occurrences / 297 distinct hashes. All 393 direct Python files parse. Nested historical archives add 35 distinct byte strings but no lower complete record. Exact path, hash, raw/normalized/gzip sizes, token counts, AST counts, and line counts are retained for every occurrence.

Every distinct source that improves at least one proposed boundary coordinate (tokens <278, AST <312, or normalized bytes <673) is individually extracted in `boundary_sources/` and classified in `boundary_classification.json`. There are 28 distinct such sources. Five are complete checkers (three distinct token variants plus the AST and byte records); the remainder are build, packaging, source-measurement, proof-conversion, manifest-validation, or test-orchestration helpers. Such helpers require other trusted modules or do not check object-theory proofs, so they are not standalone checker records. This scan includes filenames without checker/kernel substrings and hashes in historical nested archives.

## Qualification about the baseline

This audit verifies source sizes and reads the complete current record sources and their relevant explanatory claims. It does not independently formalize every inherited iPRA soundness/completeness/bi-interpretability theorem. The metric denominator is a complete program documented by its author as checking full iPRA, not an independently machine-certified implementation.

The AST-minimal transient_seed profile uses exception-driven generic iteration. Its own report explains that malformed nonempty strings may terminate only through Python's recursion limit; canonical array/integer inputs are structural. Including this source in the numerical envelope is conservative for a new competitor, but it must not be advertised as an idealized total parser on all JSON values. The 672-byte `zero_product.py` tests listhood by `a * 0 == []`, an incidental Python spelling supported by its report's exact-JSON-type argument; its size reduction is not a new arithmetic axiom system. Exact type tests in other variants have no subclass distinction because the public entry point is the standard JSON decoder.

The constructed-computation 277-token record constructs the recursive source rather than taking arbitrary predecessor data on trust; its eager guards and the admissibility of generated local assumptions are mathematical soundness conditions, not dispensable formatting.

All compared complete programs trust a Python interpreter and standard JSON implementation. Neither their full runtime nor the standard-library implementation is charged, consistently across sources. Supporting producers, arithmetic diagnostics, proof translations, and test suites are not imported by those standalone kernels. A new implementation must not hide extra trusted rules in a producer or generator while claiming this same boundary.

## Recommended claims

A defensible result says it is below the inspected corpus envelope under a pinned comparison protocol, specifies whether this holds in one source or in different variants, and separately explains the conceptual change. It should not equate byte savings with mathematical significance, or finite tests with universal soundness or bi-interpretability. If improvements merely combine existing techniques, call them a synthesis or implementation reduction. The user explicitly requests a significant new idea, so satisfying the size inequality alone does not establish the whole request.
