#!/usr/bin/env python3
"""Compile the complete report with pdfLaTeX; fail on errors or bad references."""
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    for pass_number in range(1, 4):
        run = subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=ROOT, capture_output=True, text=True)
        (ROOT / "results" / f"pdflatex_pass_{pass_number}.txt").write_text(run.stdout + run.stderr)
        if run.returncode:
            print(run.stdout[-7000:] + run.stderr, file=sys.stderr)
            raise SystemExit(run.returncode)
    log = (ROOT / "report.log").read_text(errors="replace")
    bad = [line for line in log.splitlines()
           if re.search(r"Overfull \\[hv]box|undefined references|Citation .* undefined|Reference .* undefined", line)]
    if bad:
        print("\n".join(bad), file=sys.stderr)
        raise SystemExit("PDF needs layout/reference correction")
    print("Built report.pdf; no overfull boxes or undefined references.")


if __name__ == "__main__":
    main()
