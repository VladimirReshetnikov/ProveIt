"""Reproduce inherited full-program metrics and isolated integration ablations.

Metric convention: Python ast.parse; remove syntactic leading docstrings;
ast.unparse plus LF; count significant tokens, every AST node, UTF-8 bytes.
Normalized metric implementation independently cross-checked by frontier_audit.
"""
import ast
from hashlib import sha256
import io
import itertools
import json
from pathlib import Path
import tokenize

ROOT = Path(__file__).resolve().parent
IGNORED = {tokenize.COMMENT, tokenize.ENCODING, tokenize.ENDMARKER,
           tokenize.INDENT, tokenize.DEDENT, tokenize.NEWLINE, tokenize.NL}


class Strip(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant) and isinstance(node.body[0].value.value, str):
            node.body.pop(0)
        return node
    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def metrics(source):
    tree = Strip().visit(ast.parse(source))
    normalized = ast.unparse(tree) + '\n'
    return {'tokens': sum(t.type not in IGNORED for t in tokenize.generate_tokens(io.StringIO(normalized).readline)),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode()),
            'sha256': sha256(source.encode()).hexdigest(),
            'normalized_sha256': sha256(normalized.encode()).hexdigest()}


def main():
    scalar = (ROOT / 'checker.py').read_text()
    full = (ROOT / 'checker_full.py').read_text()
    current_driver = scalar[scalar.index('try:\n'):]
    old_driver = '''try:
    take = json.load(open(sys.argv[1])).pop
    accepted = check(take(), [])
except:
    accepted = False
print('ACCEPT' if accepted else 'REJECT')
sys.exit(not accepted)
'''
    rows = []
    for complement, raw, compact in itertools.product((False, True), repeat=3):
        source = scalar
        if not complement:
            source = source.replace('if type(a) is int and d % 2:',
                                    'if type(a) is int and d % 2 and a >= k:')
            source = source.replace('a if k <= a < d else', 'a if a < d else')
        if not raw:
            source = source.replace('case t:', 'case [t]:')
        if not compact:
            source = source.replace(current_driver, old_driver)
        rows.append({'scope_complement': complement, 'raw_witness': raw,
                     'staged_driver': compact, 'merged_imports': True,
                     **metrics(source)})
    core = ast.parse(scalar)
    core.body = [n for n in core.body if isinstance(n, (ast.FunctionDef, ast.Assign))]
    core_source = ast.unparse(core) + '\n'
    common = 'import json\nimport sys\n' + core_source + current_driver
    result = {'convention': __doc__, 'scalar': metrics(scalar), 'full_companion': metrics(full),
              'uniform_core': metrics(core_source), 'common_driver': metrics(common),
              'isolated_ablations': rows,
              'split_import_ablation': metrics(scalar.replace('import json, sys', 'import json\nimport sys')),
              'exact_references': {p.name: metrics(p.read_text()) for p in (ROOT / 'validation/references').glob('*.py')}}
    (ROOT / 'results/integration_metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
