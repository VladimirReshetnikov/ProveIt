#!/usr/bin/env python3
"""Package the complete deliverable and verify its file hashes and ZIP CRCs."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".fls", ".fdb_latexmk"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    pdf = ROOT / "report.pdf"
    if not pdf.read_bytes().startswith(b"%PDF-"):
        raise SystemExit("Missing or invalid report.pdf")
    for source in ROOT.rglob("*.tex"):
        for name in re.findall(r"\\input\{([^}]+)\}", source.read_text()):
            target = ROOT / name
            if not target.suffix:
                target = target.with_suffix(".tex")
            if not target.is_file():
                raise SystemExit(f"Missing LaTeX input: {target}")
    for record in json.loads((ROOT / "PROVENANCE.json").read_text())["files"]:
        if digest((ROOT / record["file"]).read_bytes()) != record["sha256"]:
            raise SystemExit(f"Provenance mismatch: {record['file']}")

    files = sorted(p for p in ROOT.rglob("*") if p.is_file()
                   and "__pycache__" not in p.parts
                   and p.suffix not in EXCLUDED_SUFFIXES
                   and p.name != "SHA256SUMS")
    if any(p.is_symlink() for p in files):
        raise SystemExit("Unexpected symlink in deliverable")
    manifest = "".join(f"{digest(p.read_bytes())}  {p.relative_to(ROOT).as_posix()}\n"
                       for p in files)
    manifest_file = ROOT / "SHA256SUMS"
    manifest_file.write_text(manifest)
    files.append(manifest_file)

    archive = ROOT.parent / f"{ROOT.name}.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as z:
        for p in sorted(files):
            info = zipfile.ZipInfo(f"{ROOT.name}/{p.relative_to(ROOT).as_posix()}",
                                   date_time=(2026, 11, 7, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, p.read_bytes(), compresslevel=9)

    with zipfile.ZipFile(archive) as z:
        bad = z.testzip()
        if bad is not None:
            raise SystemExit(f"ZIP CRC failure: {bad}")
        prefix = ROOT.name + "/"
        for line in z.read(prefix + "SHA256SUMS").decode().splitlines():
            expected, name = line.split("  ", 1)
            if digest(z.read(prefix + name)) != expected:
                raise SystemExit(f"ZIP hash mismatch: {name}")
        if len(z.namelist()) != len(files):
            raise SystemExit("ZIP file count mismatch")

    standalone_pdf = ROOT.parent / f"{ROOT.name}.pdf"
    shutil.copyfile(pdf, standalone_pdf)
    print(json.dumps({
        "status": "PASS", "files": len(files),
        "archive": str(archive), "archive_bytes": archive.stat().st_size,
        "archive_sha256": digest(archive.read_bytes()),
        "pdf": str(standalone_pdf), "pdf_bytes": standalone_pdf.stat().st_size,
        "pdf_sha256": digest(standalone_pdf.read_bytes()),
    }, indent=2))


if __name__ == "__main__":
    main()
