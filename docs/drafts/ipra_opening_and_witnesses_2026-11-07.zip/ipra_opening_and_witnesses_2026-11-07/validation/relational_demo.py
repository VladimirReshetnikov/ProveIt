#!/usr/bin/env python3
"""Finite arithmetic replay for the Pi_2-domain example, not its proof.

The pairing function here is part of the external standard-model evaluator.
It is deliberately NOT a term constructor of the unary source language.
The universal mathematical argument is in report.tex, Section 3.
"""
from math import isqrt
import json
from pathlib import Path


def pair(x, y):
    return (x + y) * (x + y + 1) // 2 + y


def left(z):
    diagonal = (isqrt(8 * z + 1) - 1) // 2
    return diagonal - (z - diagonal * (diagonal + 1) // 2)


def right(z):
    diagonal = (isqrt(8 * z + 1) - 1) // 2
    return z - diagonal * (diagonal + 1) // 2


def base(y):
    return pair(0, y)


def successor_lift(v):
    return pair(left(v) + 1, right(v))


def associate(v):
    return pair(pair(left(v), left(right(v))), right(right(v)))


def main():
    counts = {"pair_inverse_checks": 0, "unary_axiom_checks": 0,
              "domain_closure_replays": 0}
    for x in range(64):
        for y in range(64):
            z = pair(x, y)
            if (left(z), right(z)) != (x, y):
                raise AssertionError((x, y, z))
            counts["pair_inverse_checks"] += 1
    for v in range(4096):
        identities = [
            left(base(v)) == 0,
            right(base(v)) == v,
            left(successor_lift(v)) == left(v) + 1,
            right(successor_lift(v)) == right(v),
            left(left(associate(v))) == left(v),
            right(left(associate(v))) == left(right(v)),
            right(associate(v)) == right(right(v)),
            pair(left(v), right(v)) == v,
        ]
        if not all(identities):
            raise AssertionError((v, identities))
        counts["unary_axiom_checks"] += len(identities)
    for x in range(16):
        for y in range(16):
            z = pair(x, y)
            for u in range(16):
                w = pair(y, u)
                v = pair(x, w)
                q = associate(v)
                if (left(q), right(q)) != (z, u):
                    raise AssertionError((x, y, u, z, w, v, q))
                counts["domain_closure_replays"] += 1
    # An illustration of the finite-grid argument, not a replacement for it.
    candidates = [lambda x, y: x, lambda x, y: y,
                  lambda x, y: x + 1, lambda x, y: y + 1]
    grid_size = len(candidates) + 1
    uncovered = [(x, y) for x in range(grid_size) for y in range(grid_size)
                 if all(f(x, y) != x + y for f in candidates)]
    if not uncovered:
        raise AssertionError("The illustrative grid has no uncovered entry")
    result = {
        "status": "PASS", "failures": 0, **counts,
        "illustrative_grid_size": grid_size,
        "illustrative_uncovered_addition_inputs": uncovered,
        "limitation": "Finite standard-model replay only. The proof of the general witness and quotient theorems is written mathematics, not this enumeration.",
        "external_pairing_is_not_a_native_term": True,
    }
    root = Path(__file__).resolve().parents[1]
    (root / "results").mkdir(exist_ok=True)
    (root / "results/relational_demo.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
