# Adaptation for the integrated scope-complement/raw-witness candidate.
# The only semantic change from staged oracle: undeclared negatives are template holes.
"""Independent named-binder oracle for the full and scalar recursor kernels.

Adapted, after inspection, from the pinned ProveIt one-hole draft's
validation/named_oracle.py and the absorbed-scalar draft's raw-witness oracle.
The new full-recursion computation uses simultaneous substitution of two named
variables, NOT the production kernel's two sequential openings. This module
has no packed sort/depth field, constructor-width byte table, structural match,
or dependency on either production checker. All support here is untrusted.
"""
from copy import deepcopy


class Syntax:
    def __init__(self, lower=0, width=2):
        self.lower, self.width, self.serial = lower, width, 0

    def fresh(self):
        self.serial += 1
        return self.serial

    def term(self, value, bound=(), template=False):
        if type(value) is int:
            if value <= 0:
                if value < self.lower:
                    if template:
                        return ('hole',)
                    raise ValueError('undeclared numerical parameter')
                return ('constant', value)
            slot = (value + 1) // 2
            if slot <= len(bound):
                return ('variable', bound[slot - 1], 1 - value % 2)
            if template:
                return ('hole',)
            raise ValueError('unbound positive coordinate')
        if type(value) is not list:
            raise ValueError('term must be an integer or list')
        if len(value) == 1:
            return ('successor', self.term(value[0], bound, template))
        if len(value) == 3:
            names = tuple(self.fresh() for _ in range(self.width))
            return ('recursor', self.term(value[0], bound, template),
                    self.term(value[1], bound, template), names,
                    self.term(value[2], names + bound, template))
        raise ValueError('invalid term arity')

    def formula(self, value, bound=(), template=False):
        if type(value) is not list:
            raise ValueError('formula must be a list')
        if len(value) == 2:
            return ('equal', self.term(value[0], bound, template),
                    self.term(value[1], bound, template))
        if len(value) == 1:
            variable = self.fresh()
            return ('closure', variable,
                    self.formula(value[0], (variable,) + bound, template))
        if len(value) == 3:
            first, second = self.fresh(), self.fresh()
            return ('paired', first, second,
                    *(self.formula(v, (second, first) + bound, template) for v in value))
        raise ValueError('invalid formula arity')

    def term_data(self, tree, bound=(), emit_hole=False):
        tag = tree[0]
        if tag == 'constant':
            return tree[1]
        if tag == 'variable':
            return 2 * bound.index(tree[1]) + 1 + tree[2]
        if tag == 'hole' and emit_hole:
            return 2 * len(bound) + 1
        if tag == 'successor':
            return [self.term_data(tree[1], bound, emit_hole)]
        if tag == 'recursor':
            _, count, initial, names, body = tree
            return [self.term_data(count, bound, emit_hole),
                    self.term_data(initial, bound, emit_hole),
                    self.term_data(body, names + bound, emit_hole)]
        raise ValueError('unsubstituted hole')

    def formula_data(self, tree, bound=(), emit_hole=False):
        tag = tree[0]
        if tag == 'equal':
            return [self.term_data(tree[1], bound, emit_hole),
                    self.term_data(tree[2], bound, emit_hole)]
        if tag == 'closure':
            return [self.formula_data(tree[2], (tree[1],) + bound, emit_hole)]
        if tag == 'paired':
            return [self.formula_data(t, (tree[2], tree[1]) + bound, emit_hole)
                    for t in tree[3:]]
        raise ValueError('invalid formula tree')


def children(tree):
    tag = tree[0]
    if tag in ('constant', 'variable', 'hole'):
        return ()
    if tag == 'successor':
        return (tree[1],)
    if tag == 'recursor':
        return (tree[1], tree[2], tree[4])
    if tag == 'equal':
        return tree[1:]
    if tag == 'paired':
        return tree[3:]
    return tree[2:]


def transform(tree, leaf):
    tag = tree[0]
    if tag in ('constant', 'variable', 'hole'):
        return leaf(tree)
    if tag == 'successor':
        return (tag, transform(tree[1], leaf))
    if tag == 'recursor':
        return (tag, transform(tree[1], leaf), transform(tree[2], leaf),
                tree[3], transform(tree[4], leaf))
    if tag == 'equal':
        return (tag, *(transform(t, leaf) for t in tree[1:]))
    if tag == 'paired':
        return (tag, tree[1], tree[2], *(transform(t, leaf) for t in tree[3:]))
    return (tag, tree[1], transform(tree[2], leaf))


def has_hole(tree):
    return tree[0] == 'hole' or any(has_hole(t) for t in children(tree))


def names_in(tree):
    if tree[0] == 'constant' and tree[1] < 0:
        return {tree[1]}
    return set().union(*(names_in(t) for t in children(tree)))


def variables_in(tree):
    if tree[0] == 'variable':
        return {tree[1]}
    return set().union(*(variables_in(t) for t in children(tree)))


def opening(value, image=None, *, formula=True, depth=0, lower=0, width=2):
    """One-hole opening by named parsing, substitution, and re-encoding."""
    syntax = Syntax(lower, width)
    bound = tuple(syntax.fresh() for _ in range(depth))
    parse = syntax.formula if formula else syntax.term
    emit = syntax.formula_data if formula else syntax.term_data
    tree = parse(value, bound, template=True)
    replacement = syntax.term(image) if has_hole(tree) else None
    return emit(transform(tree, lambda t: replacement if t[0] == 'hole' else t), bound)


def computation_rhs(lhs, *, lower=0, width=2):
    """Direct simultaneous named substitution, independent of unary opening."""
    syntax = Syntax(lower, width)
    node = syntax.term(lhs)
    if node[0] != 'recursor':
        raise ValueError('computation needs a recursor')
    count, initial, names, body = node[1:]
    if count == ('constant', 0):
        return deepcopy(lhs[1])
    if count[0] != 'successor':
        raise ValueError('counter is neither zero nor a syntactic successor')
    previous = [deepcopy(lhs[0][0]), deepcopy(lhs[1]), deepcopy(lhs[2])]
    raw_images = (previous, lhs[0][0])[:width]
    used = variables_in(body)
    images = {name: syntax.term(raw) for name, raw in zip(names, raw_images) if name in used}
    result = transform(body, lambda t: images[t[1]]
                       if t[0] == 'variable' and t[1] in images else t)
    return syntax.term_data(result)


def embed_scalar(value, *, formula=True, depth=0, lower=0, template=False):
    """Add an unused counter to every iterator, using named alpha conversion."""
    syntax = Syntax(lower, 1)
    bound = tuple(syntax.fresh() for _ in range(depth))
    parse = syntax.formula if formula else syntax.term
    emit = syntax.formula_data if formula else syntax.term_data
    tree = parse(value, bound, template=template)

    def add_counter(node):
        tag = node[0]
        if tag in ('constant', 'variable', 'hole'):
            return node
        if tag == 'recursor':
            return (tag, add_counter(node[1]), add_counter(node[2]),
                    (*node[3], syntax.fresh()), add_counter(node[4]))
        if tag == 'successor':
            return (tag, add_counter(node[1]))
        if tag == 'equal':
            return (tag, *(add_counter(n) for n in node[1:]))
        if tag == 'paired':
            return (tag, node[1], node[2], *(add_counter(n) for n in node[3:]))
        return (tag, node[1], add_counter(node[2]))

    return emit(add_counter(tree), bound, emit_hole=template)


class Oracle:
    def __init__(self, width=2):
        self.width = width
        self.lower = 0
        self.stack = []
        self.allocations = []
        self.rule_counts = {}
        self.annotations = {}
        self.failed_spans = []
        self.frames = []

    def open(self, value, image=None, formula=True, depth=0):
        return opening(value, image, formula=formula, depth=depth,
                       lower=self.lower, width=self.width)

    def rule(self, name):
        self.rule_counts[name] = self.rule_counts.get(name, 0) + 1

    def fresh(self, relevant, index=None):
        syntax = Syntax(self.lower, self.width)
        names = set().union(*(names_in(syntax.formula(a)) for a in relevant))
        self.lower -= 1
        if self.lower in names or any(self.lower >= n for n in names):
            raise AssertionError('oracle eigenparameter is not fresh')
        self.allocations.append({'eigenparameter': self.lower,
                                 'instruction_index': index,
                                 'relevant_names': sorted(names)})
        return self.lower

    def check(self, goal, context):
        frame = {'goal': deepcopy(goal), 'context': deepcopy(context),
                 'start': len(self.stack)}
        self.frames.append(frame)
        accepted = self.check_node(goal, context)
        frame.update(end=len(self.stack), accepted=accepted)
        return accepted

    def check_node(self, goal, context):
        self.open(goal)
        if goal in context:
            self.rule('hypothesis')
            return True
        index = len(self.stack) - 1
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, context):
                self.annotations[index] = {'kind': 'elimination', 'lower': self.lower,
                                           'major_kind': len(major)}
                if len(major) == 3:
                    self.rule('paired_elimination')
                    eigen = self.fresh([goal, *context, major], index)
                    assumption = self.open([major[0]], eigen)
                    return self.check(goal, [*context, assumption])
                if len(major) == 1:
                    self.rule('closure_elimination')
                    matrix, left, right = major[0], 0, annotation
                else:
                    self.rule('equality_transport')
                    matrix, (left, right) = annotation, major
                if self.open(matrix, right) != goal:
                    return False
                return self.check(self.open(matrix, left), context)
            # A failed Python match guard falls through. Exceptions do not.
            self.failed_spans.append({'start': len(self.stack), 'stop': index})
            self.rule('failed_elimination_fallback')
        if type(instruction) is list and instruction == []:
            self.annotations[index] = {'kind': 'computation', 'lower': self.lower}
            if len(goal) != 2:
                raise ValueError('computation instruction on a nonequation')
            expected = computation_rhs(goal[0], lower=self.lower, width=self.width)
            self.rule('recursion_zero' if goal[0][0] == 0 else 'recursion_successor')
            return goal[1] == expected
        if len(goal) not in (1, 3):
            raise ValueError('numerical term cannot be a formula matrix')
        self.annotations[index] = {'kind': 'introduction', 'lower': self.lower}
        self.rule('closure_introduction' if len(goal) == 1 else 'paired_introduction')
        body = self.open(goal[0], instruction, depth=1)
        assumptions = [self.open(body, 0)]
        if len(body) == 2:
            assumptions.insert(0, body)
        eigen = self.fresh([goal, *context, [body]], index)
        conclusion = self.open(body, [eigen])
        instantiated = [self.open(a, eigen) for a in assumptions]
        return self.check(conclusion, [*context, *instantiated])

    def run(self, packet, lower=0):
        self.lower = lower
        self.allocations = []
        self.rule_counts = {}
        self.annotations = {}
        self.failed_spans = []
        self.frames = []
        self.stack = deepcopy(packet)
        try:
            accepted = bool(self.check(self.stack.pop(), []))
            error = None
        except Exception as exc:
            if isinstance(exc, AssertionError):
                raise
            accepted, error = False, type(exc).__name__
        return {'accepted': accepted,
                'remaining': len(self.stack) if type(self.stack) is list else None,
                'final_k': self.lower, 'error': error,
                'allocations': self.allocations, 'rules': self.rule_counts,
                'failed_spans': self.failed_spans}


def embed_packet(packet):
    """Compile an accepted scalar raw-witness packet to full recursion."""
    oracle = Oracle(1)
    result = oracle.run(packet)
    if not result['accepted']:
        raise ValueError('embedding needs an accepted scalar packet')
    if result['rules'].get('failed_elimination_fallback'):
        raise ValueError('extract failed-guard fallback first; not an embedding fixture')
    converted = deepcopy(packet)
    converted[-1] = embed_scalar(packet[-1])
    for index, information in oracle.annotations.items():
        lower, kind = information['lower'], information['kind']
        if kind == 'computation':
            continue
        if kind == 'introduction':
            try:
                converted[index] = embed_scalar(packet[index], formula=False, lower=lower)
            except ValueError:
                # A malformed witness in an accepted introduction was unused.
                converted[index] = 0
            continue
        major, argument = packet[index]
        major = embed_scalar(major, lower=lower)
        if information['major_kind'] == 2:
            argument = embed_scalar(argument, lower=lower, template=True)
        elif information['major_kind'] == 1:
            try:
                argument = embed_scalar(argument, formula=False, lower=lower)
            except ValueError:
                argument = 0
        converted[index] = [major, argument]
    return converted
