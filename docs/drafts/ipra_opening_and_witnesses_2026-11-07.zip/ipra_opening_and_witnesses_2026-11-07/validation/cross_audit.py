"""Cross-check the integrated checker and untrusted certificate translations.

The three reference checkers and inherited fixture inventories are frozen exact
copies from ProveIt commit 25e16049bbc73c92703296181e0696370c987577.
Run after verify.py. No network is used; no reference source is modified.
"""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import random
from named_oracle import Oracle
from translate import translate, unwrap_legacy, holes
from verify import load_kernel, run, require, agreement, cli, mutate

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
REFERENCES = HERE / 'references'


def main():
    scalar = load_kernel(ROOT / 'checker.py')
    full = load_kernel(ROOT / 'checker_full.py')
    scope = load_kernel(REFERENCES / 'scope_complement.py')
    staged = {1: load_kernel(REFERENCES / 'staged_scalar.py'),
              2: load_kernel(REFERENCES / 'staged_full.py')}
    examples = []
    counts = Counter()

    def translated(packet, width, name):
        outputs = [translate(packet, width=width)]
        targets = [staged[width]]
        if width == 1:
            outputs.append(translate(packet, width=1, wrapped=True))
            targets.append(scope)
        for output, target in zip(outputs, targets):
            verdict = run(target, output['packet'])
            require(verdict['accepted'], ('translated target rejects', name, target.__name__, output, verdict))
            require(verdict['final_k'] == output['target_final_k'],
                    ('translated allocation trace', name, output, verdict))
            require(verdict['remaining'] == output['remaining'],
                    ('translated stack trace', name, output, verdict))
            counts['accepted_translations'] += 1
            counts['pruned_failed_or_hypothesis_cells'] += output['discarded_cells']
            counts['removed_parameters'] += output['discarded_parameters']
            if output['discarded_cells']:
                examples.append({'name': name, 'width': width, 'target': target.__name__, **output})
        return outputs

    # A discarded major allocates -1; a surviving redundant transport uses it.
    # Replacing this dead parameter by zero makes its major equal an existing
    # base hypothesis, so a correct flat-stream compiler MUST prune that major.
    false_major = [[[1, 0, [1]], 0]]
    step_lhs = [[-2], 0, 1]
    step_goal = [step_lhs, 0]
    induction_hypothesis = [[-2, 0, 1], 0]
    redundant_major = [[0, -1, 1], -1]
    cells = [[false_major, None], 0, [], [redundant_major, step_goal], [],
             [induction_hypothesis, [step_lhs, 1]], []]
    pruning_packet = list(reversed(cells)) + [[[[1, 0, 1], 0]]]
    pruning_cases = HERE / 'cases' / 'translation'
    pruning_cases.mkdir(exist_ok=True)
    pruning_path = pruning_cases / 'discarded_parameter_creates_hypothesis.json'
    pruning_path.write_text(json.dumps(pruning_packet) + '\n')
    for width, module, filename in ((1, scalar, 'checker.py'), (2, full, 'checker_full.py')):
        actual, oracle = agreement(module, pruning_packet, width, 'fixed_point_pruning')
        require(actual['accepted'], ('pruning source rejected', width))
        outputs = translated(pruning_packet, width, 'discarded_parameter_creates_hypothesis')
        require(all(output['hypothesis_pruning_rounds'] > 0 for output in outputs),
                ('hypothesis pruning control not exercised', width))
        cli(ROOT / filename, pruning_path, True)
        cli(ROOT / filename, pruning_path, True, optimized=True)
        counts['targeted_pruning_cli_invocations'] += 2

    generated = json.loads((HERE / 'cases.json').read_text())
    for name, width, module in [('scalar', 1, scalar), ('full', 2, full)]:
        rows = generated[name]
        for row in rows:
            actual, oracle = agreement(module, row['packet'], width, name + '/' + row['name'])
            if actual['accepted']:
                translated(row['packet'], width, name + '/' + row['name'])
        eligible = [row['packet'] for row in rows if row['expected'] and len(row['packet']) < 150]
        rng = random.Random(2026110810 + width)
        for index in range(2000):
            packet = mutate(rng.choice(eligible), rng)
            actual, oracle = agreement(module, packet, width, name + '/mutation_' + str(index))
            counts['cross_audit_mutations'] += 1
            if actual['accepted']:
                counts['accepted_mutations_translated'] += 1
                translated(packet, width, name + '/mutation_' + str(index))

    imported = []
    for filename in ('inherited_fixtures.json', 'new_fixtures.json', 'new_scope_cases.json'):
        for row in json.loads((REFERENCES / filename).read_text()):
            old = run(scope, row['packet'])
            counts['legacy_packets_checked'] += 1
            if not old['accepted']:
                continue
            packet = unwrap_legacy(row['packet'])
            actual, oracle = agreement(scalar, packet, 1, 'legacy/' + row['name'])
            require(actual['accepted'], ('legacy unwrapping rejected', row['name']))
            for field in ('remaining', 'final_k'):
                require(actual[field] == old[field], ('legacy trace', row['name'], field))
            translated(packet, 1, 'legacy/' + row['name'])
            counts['accepted_legacy_translated'] += 1
            imported.append({'name': filename + '/' + row['name'], 'packet': packet})

    # Three independent spellings of every active motive hole. Major proofs may
    # allocate before the motive is read, so use the recorded post-major floor.
    alias_cases = HERE / 'cases' / 'scope_aliases'
    alias_cases.mkdir(exist_ok=True)
    for row in imported + [r for r in generated['scalar'] if r['expected']]:
        source = Oracle(1)
        require(source.run(row['packet'])['accepted'], 'alias source rejected')
        for variant in ('next_unknown', 'huge_unknown', 'mixed_signed'):
            packet = deepcopy(row['packet'])
            touched = False
            for index, info in source.annotations.items():
                if info['kind'] != 'elimination' or info['major_kind'] != 2:
                    continue
                lower = info['lower']
                serial = 0
                def alias():
                    nonlocal serial, touched
                    serial += 1
                    touched = True
                    if variant == 'next_unknown':
                        return lower - 1
                    if variant == 'huge_unknown':
                        return lower - 10 ** 80
                    return lower - serial - 1 if serial % 2 else 10 ** 60 + serial
                packet[index][1] = holes(packet[index][1], lower, alias=alias)
            if not touched:
                continue
            actual, oracle = agreement(scalar, packet, 1, 'alias/' + row['name'] + '/' + variant)
            require(actual['accepted'], ('alias failed', row['name'], variant))
            translated(packet, 1, 'alias/' + row['name'] + '/' + variant)
            counts['aliased_certificates'] += 1
            if counts['aliased_certificates'] <= 9:
                path = alias_cases / ('alias_' + str(counts['aliased_certificates']) + '.json')
                path.write_text(json.dumps(packet) + '\n')
                cli(ROOT / 'checker.py', path, True)
                cli(ROOT / 'checker.py', path, True, optimized=True)
                counts['alias_public_cli_invocations'] += 2

    result = {'status': 'PASS', 'counts': dict(counts),
              'references': {p.name: sha256(p.read_bytes()).hexdigest()
                             for p in REFERENCES.iterdir() if p.is_file()},
              'compilers_are_untrusted': True,
              'finite_tests_are_not_metatheorems': True,
              'translation_examples_with_erased_proof_search': examples[:20]}
    (HERE / 'cross_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if not k.endswith('examples_with_erased_proof_search')}, indent=2))


if __name__ == '__main__':
    main()
