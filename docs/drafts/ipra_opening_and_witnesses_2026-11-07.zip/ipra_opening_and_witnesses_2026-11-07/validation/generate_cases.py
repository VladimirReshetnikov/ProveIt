"""Untrusted certificate producer for ordinary and scalar primitive recursion.

The checked programs never import this producer or the named-binder oracle.
Adapted proof-builder methods are credited in ATTRIBUTION.txt. Computation
certificates are independently assembled by simultaneous named substitution.
"""
from copy import deepcopy
import json
from pathlib import Path
from named_oracle import opening, computation_rhs, embed_packet

TRUTH = [0, 0]


def numeral(n):
    value = 0
    for _ in range(n):
        value = [value]
    return value


class Builder:
    def __init__(self, goal, width=2):
        self.goal, self.width = goal, width
        self.lower = 0
        self.context = []
        self.cells = []

    def open(self, value, image=None, formula=True, depth=0):
        return opening(value, image, formula=formula, depth=depth,
                       lower=self.lower, width=self.width)

    def leaf(self):
        return self.goal in self.context

    def prove(self, goal, action):
        previous = self.goal
        self.goal = goal
        action()
        self.goal = previous

    def hyp(self):
        if not self.leaf():
            raise AssertionError(('missing producer hypothesis', self.goal, self.context))

    def computation(self):
        if self.leaf():
            return
        left, right = self.goal
        expected = computation_rhs(left, lower=self.lower, width=self.width)
        if right != expected:
            raise AssertionError(('incorrect produced computation', self.goal, expected))
        self.cells.append(('computation', []))

    def transport(self, major, motive, major_proof, minor_proof):
        if self.leaf():
            return
        target = self.goal
        self.cells.append(('elimination', [major, motive]))
        self.prove(major, major_proof)
        if self.open(motive, major[1]) != target:
            raise AssertionError(('producer transport endpoint', target, major, motive))
        self.prove(self.open(motive, major[0]), minor_proof)

    def reflexivity(self):
        if self.leaf():
            return
        term, right = self.goal
        if term != right:
            raise AssertionError(('not reflexivity', self.goal))
        recursor = [0, term, 0]
        self.transport([recursor, term], [1, term], self.computation, self.computation)

    def intro(self, witness, step):
        if self.leaf():
            return
        goal = self.goal
        if len(goal) not in (1, 3):
            raise AssertionError('introduction requires a closure or paired binder')
        if witness == []:
            raise AssertionError('raw empty instructions are reserved for computation')
        self.cells.append(('introduction', deepcopy(witness)))
        body = self.open(goal[0], witness, depth=1)
        base = self.open(body, 0)
        self.lower -= 1
        eigen = self.lower
        hypothesis = self.open(body, eigen)
        conclusion = self.open(body, [eigen])
        old_context = self.context
        self.context = [*old_context, base]
        if len(body) == 2:
            self.context.insert(len(old_context), hypothesis)
        self.prove(conclusion, lambda: step(eigen, hypothesis, base))
        self.context = old_context

    def q_elim(self, major, instance, major_proof, base_proof):
        if self.leaf():
            return
        goal = self.goal
        self.cells.append(('elimination', [major, instance]))
        self.prove(major, major_proof)
        if self.open(major[0], instance) != goal:
            raise AssertionError('closure elimination endpoint mismatch')
        self.prove(self.open(major[0], 0), base_proof)

    def d_elim(self, major, major_proof, continuation):
        if self.leaf():
            return
        goal = self.goal
        self.cells.append(('elimination', [major, None]))
        self.prove(major, major_proof)
        self.lower -= 1
        eigen = self.lower
        assumption = self.open([major[0]], eigen)
        old_context = self.context
        self.context = [*old_context, assumption]
        self.prove(goal, lambda: continuation(eigen, assumption))
        self.context = old_context

    def equals_one_from_false(self):
        """Use a retained 0=1, and primitive computations, to prove term=1."""
        term, one = self.goal
        if one != [0]:
            raise AssertionError('expected target term=1')
        recursor = [[0], [0], term]

        def inner():
            self.transport([0, [0]], [[1, [0], term], [0]],
                           self.hyp, self.computation)

        self.transport([recursor, term], [1, [0]], self.computation, inner)

    def packet(self):
        return [deepcopy(cell) for _, cell in reversed(self.cells)] + [deepcopy(self.goal)]

    def normalize(self):
        """Construct a proof by computations, congruence and transitivity."""
        if self.leaf():
            return
        term, expected = self.goal
        if term == expected:
            self.reflexivity()
            return
        redex, reduct, context = first_reduction(term, self.width, self.lower)
        reduced = self.open(context, reduct, formula=False)

        def one_step():
            self.transport([redex, reduct], [term, context],
                           self.computation, self.reflexivity)

        self.transport([reduced, expected], [term, 1], self.normalize, one_step)


def first_reduction(term, width, lower):
    """Find a computation redex without descending into a bound update."""
    if type(term) is not list:
        raise AssertionError(('term is already numerical normal form', term))
    if len(term) == 1:
        redex, reduct, context = first_reduction(term[0], width, lower)
        return redex, reduct, [context]
    counter, initial, update = term
    if counter == 0 or type(counter) is list and len(counter) == 1:
        return term, computation_rhs(term, lower=lower, width=width), 1
    redex, reduct, context = first_reduction(counter, width, lower)
    return redex, reduct, [context, initial, update]


def generated(width=2):
    result = []

    def make(name, goal, action, note=''):
        builder = Builder(goal, width)
        action(builder)
        result.append({'name': name, 'packet': builder.packet(), 'expected': True,
                       'producer_allocations': -builder.lower, 'note': note})

    def computation(name, lhs):
        rhs = computation_rhs(lhs, width=width)
        make(name, [lhs, rhs], lambda b: b.computation())

    computation('zero_initialization', [0, numeral(3), 1])
    computation('zero_checks_unused_update', [0, 0, [0, 0, 1]])
    computation('successor_uses_state', [numeral(3), numeral(5), 1])
    computation('successor_uses_state_alias', [numeral(2), numeral(1), 2])
    computation('successor_constant_update', [numeral(2), numeral(3), numeral(4)])
    if width == 2:
        computation('successor_uses_counter', [numeral(3), numeral(5), 3])
        computation('successor_uses_counter_alias', [numeral(2), numeral(1), 4])
        computation('successor_uses_both_arguments', [numeral(3), numeral(5), [3, 1, [1]]])
        computation('successor_under_two_nested_recursors',
                    [numeral(2), numeral(3), [3, 1, [5, 7, [1]]]])
    else:
        computation('successor_nested_outer_state', [numeral(2), numeral(3), [1, 0, [3]]])

    for i, term in enumerate([0, numeral(2), [0, 0, 1], [numeral(2), 0, [1]]]):
        make('reflexivity_%02d' % i, [term, term], lambda b: b.reflexivity())

    q_refl = [[1, 1]]
    make('Q_bound_reflexivity', q_refl, lambda b: b.intro(0, lambda *_: b.reflexivity()))
    make('Q_unused_witness_object', [TRUTH],
         lambda b: b.intro({'unused': True}, lambda *_: b.hyp()))
    make('D_used_successor_witness', [[3, 3], TRUTH, TRUTH],
         lambda b: b.intro([0], lambda *_: b.hyp()))
    make('D_unused_malformed_witness', [[1, 1], TRUTH, TRUTH],
         lambda b: b.intro({'unused': None}, lambda *_: b.reflexivity()))
    make('nested_Q_introductions', [[[3, 3]]],
         lambda b: b.intro(0, lambda *_: b.intro(0, lambda *_: b.hyp())))

    term = [numeral(2), [0], [1]]
    make('Q_elimination_at_recursion_term', [term, term],
         lambda b: b.q_elim(q_refl, term,
             lambda: b.intro(0, lambda *_: b.reflexivity()), b.reflexivity))
    paired = [[1, 1], TRUTH, TRUTH]
    make('D_elimination_then_Q_elimination', [term, term],
         lambda b: b.d_elim(paired,
             lambda: b.intro(0, lambda *_: b.reflexivity()),
             lambda eigen, assumption: b.q_elim(assumption, term, b.hyp, b.reflexivity)))

    p, q = [0, 0, 1], 0
    make('transport_under_Q', [[q, q]],
         lambda b: b.transport([p, q], [[3, 3]], b.computation,
             lambda: b.intro(0, lambda *_: b.hyp())))
    make('transport_under_D_and_Q', [[[q, q]], TRUTH, TRUTH],
         lambda b: b.transport([p, q], [[[7, 7]], TRUTH, TRUTH], b.computation,
             lambda: b.intro(0, lambda *_: b.hyp())))

    # The induction hypothesis is explicitly consumed in the step certificate.
    induction_matrix = [[1, 0, [1]], 1]
    def induction_step(builder, eigen, hypothesis, base):
        lhs = [[eigen], 0, [1]]
        builder.transport(hypothesis, [lhs, [1]], builder.hyp, builder.computation)
    make('atomic_induction_recursion_identity', [induction_matrix],
         lambda b: b.intro(0, lambda e, h, z: induction_step(b, e, h, z)))
    make('induction_and_specialization', [[numeral(3), 0, [1]], numeral(3)],
         lambda b: b.q_elim([induction_matrix], numeral(3),
             lambda: b.intro(0, lambda e, h, z: induction_step(b, e, h, z)),
             b.computation))
    make('retained_false_base_is_used', [[1, [0]]],
         lambda b: b.intro(0, lambda *_: b.equals_one_from_false()))

    add23 = [numeral(2), numeral(3), [1]]
    multiply23 = [numeral(2), 0, [numeral(3), 1, [1]]]
    # In the outer recursion body: state=1. Multiplication by two is
    # R(2,0;state_inner + state_outer). An inner summation's update ignores
    # its own counter and state_outer is shifted by the middle binder width.
    outer_state_in_middle = 2 * width + 1
    multiply_state_by_two = [numeral(2), 0,
                             [outer_state_in_middle, 1, [1]]]
    power23 = [numeral(3), [0], multiply_state_by_two]
    for name, term, answer in [('addition_two_three', add23, 5),
                               ('multiplication_two_three', multiply23, 6),
                               ('power_two_three', power23, 8)]:
        make(name, [term, numeral(answer)], lambda b: b.normalize(),
             'A complete computation/transport certificate; not just numerical evaluation.')

    # A false elimination major returns False (rather than raising), so the
    # same raw instruction becomes a wholly unused introduction witness.
    result.append({'name': 'failed_major_falls_back_to_unused_witness',
                   'packet': [[], [[[0, 0, 0], [0]], None], [TRUTH]],
                   'expected': True, 'producer_allocations': 1})
    false_major = [[[1, 0, [1]], 0]]
    result.append({'name': 'failed_major_retains_consumed_allocation',
                   'packet': [[], 0, [false_major, None], [TRUTH]],
                   'expected': True, 'producer_allocations': 2})

    # The capture mutant validates an inserted image under local binders.
    # Its false existential claim then has a spurious reflexivity proof.
    outer_y = 2 * width + 1
    outer_x = outer_y + 2
    capture_goal = [[[1, 0, outer_x], [1, 0, outer_y]], TRUTH, TRUTH]
    captured_term = [[-1], 0, [-1]]
    capture = Builder([captured_term, captured_term], width)
    capture.lower = -1
    capture.reflexivity()
    result.append({'name': 'contextual_capture_attack',
                   'packet': capture.packet()[:-1] + [outer_y, capture_goal],
                   'expected': False,
                   'note': 'Accepted by the deliberately capture-allowing mutant.'})

    compound_goal = [[[[3, 0, 1], 0]]]
    previous, current = [-1, 0, 1], [[-1], 0, 1]
    base, illegal_hypothesis = [[[0, 0, 1], 0]], [[previous, 0]]
    compound = Builder([[current, 0]], width)
    compound.lower = -1
    compound.context = [base, illegal_hypothesis]
    def symmetry():
        compound.transport([current, previous], [1, current],
                           compound.computation, compound.reflexivity)
    compound.transport([previous, current], [[3, 0]], symmetry, compound.hyp)
    result.append({'name': 'compound_induction_hypothesis_attack',
                   'packet': compound.packet()[:-1] + [0, compound_goal],
                   'expected': False,
                   'note': 'The certificate is invalid; the sentence may have a different proof.'})

    dangling = 2 * width + 1
    bad = [
        ('wrong_zero_initializer', [[], [[0, 0, 0], [0]]]),
        ('wrong_successor_value', [[], [[[0], 0, 1], 0]]),
        ('dangling_update_coordinate', [[], [[[0], 0, dangling], 0]]),
        ('future_parameter_in_unused_update', [[], [[0, 0, -1], 0]]),
        ('future_parameter_in_goal', [[], [[0, -1, 0], -1]]),
        ('future_witness', [-1, [[3, 3], TRUTH, TRUTH]]),
        ('bound_coordinate_as_witness', [1, [[3, 3], TRUTH, TRUTH]]),
        ('future_parameter_in_padding', [0, [TRUTH, [-1, -1], TRUTH]]),
        ('invalid_padding', [0, [TRUTH, None, TRUTH]]),
        ('formula_in_term_sort', [0, [0, [0]]]),
        ('recursor_is_not_formula_matrix', [0, [[0, 0, 0], [0]]]),
        ('false_equality', [[], [0, [0]]]),
        ('false_Q_coverage', [0, [[1, 0]]]),
        ('empty_packet', []),
        ('object_packet', {}),
        ('empty_raw_witness_reserved_for_computation', [[], [TRUTH]]),
        ('float_zero_is_not_numerical', [[], [[0.0, 0, 0], 0]]),
        ('boolean_zero_is_not_numerical', [[], [[False, 0, 0], 0]]),
        ('boolean_unused_update_is_invalid', [[], [[0, 0, True], 0]]),
        ('counter_is_not_syntactic_successor', [[], [[[0, 0, 0], 0, 0], 0]]),
        ('global_template_hole_is_not_zero', [[], [[0, 99, 0], 0]]),
        ('global_unused_update_hole', [[], [[0, 0, 999], 0]]),
        ('unused_counter_update_coordinate', [[], [[0, 0, dangling], 0]]),
        ('nonarray_term', [[], [[0, {'x': 0}, 0], 0]]),
    ]
    if width == 2:
        lhs = [numeral(3), numeral(5), 3]
        bad.append(('counter_and_state_swapped', [[], [lhs, [numeral(2), numeral(5), 3]]]))
    for name, packet in bad:
        result.append({'name': name, 'packet': packet, 'expected': False})
    return result


def write_cases(root):
    root.mkdir(exist_ok=True, parents=True)
    inventories = {}
    for label, width in [('full', 2), ('scalar', 1)]:
        rows = generated(width)
        out = root / label
        out.mkdir(exist_ok=True)
        for row in rows:
            (out / (row['name'] + '.json')).write_text(json.dumps(row['packet']) + '\n')
        inventories[label] = rows
    embedded = []
    for row in inventories['scalar']:
        if row['expected'] and not row['name'].startswith('failed_major_'):
            embedded.append({'name': row['name'], 'packet': embed_packet(row['packet']),
                             'expected': True})
    out = root / 'embedded'
    out.mkdir(exist_ok=True)
    for row in embedded:
        (out / (row['name'] + '.json')).write_text(json.dumps(row['packet']) + '\n')
    inventories['embedded'] = embedded
    (root.parent / 'cases.json').write_text(json.dumps(inventories, indent=2) + '\n')
    return inventories


if __name__ == '__main__':
    cases = write_cases(Path(__file__).resolve().parent / 'cases')
    print({label: len(rows) for label, rows in cases.items()})
