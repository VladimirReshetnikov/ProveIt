"""Untrusted proof-certificate translations; all output needs independent checking.

This producer is new integration support, based on the named-binder trace from
staged_opening (modified only for the already published scope-complement
convention). It does not execute inside the trusted checker.

Successful raw-witness certificates translate to the published wrapped-witness
scope-complement checker and to the published raw-witness staged checker.
Failed-major attempts are discarded. Their allocated parameters are uniformly
replaced by zero in the surviving proof, and surviving parameters are renamed
in allocation order. Any newly automatic hypothesis subproof is pruned to a
fixed point, with deleted allocation events treated in the same way. Template holes are canonicalized BEFORE that renaming.
"""
from copy import deepcopy
from named_oracle import Oracle, Syntax


def holes(value, lower, width=1, formula=True, depth=0, alias=None):
    """Explicit-grammar single-hole normalization, independent of byte table."""
    if not formula and type(value) is int:
        if value < lower or value > 2 * depth:
            return 2 * depth + 1 if alias is None else alias()
        return value
    if type(value) is not list:
        raise ValueError('invalid template container')
    if formula:
        if len(value) == 2:
            return [holes(v, lower, width, False, depth, alias) for v in value]
        if len(value) not in (1, 3):
            raise ValueError('invalid formula arity')
        binders = 1 if len(value) == 1 else 2
        return [holes(v, lower, width, True, depth + binders, alias) for v in value]
    if len(value) == 1:
        return [holes(value[0], lower, width, False, depth, alias)]
    if len(value) != 3:
        raise ValueError('invalid term arity')
    return [holes(value[0], lower, width, False, depth, alias),
            holes(value[1], lower, width, False, depth, alias),
            holes(value[2], lower, width, False, depth + width, alias)]


def translate(packet, *, width=1, wrapped=False):
    oracle = Oracle(width)
    trace = oracle.run(packet)
    if not trace['accepted']:
        raise ValueError('requires independently accepted certificate')
    removed = set()
    for span in trace['failed_spans']:
        removed.update(range(span['start'], span['stop']))
    renaming = {}
    target_lower = 0

    def rename(value):
        if type(value) is int:
            return renaming.get(value, value)
        if type(value) is list:
            return [rename(v) for v in value]
        return deepcopy(value)

    rounds = 0
    while True:
        target_lower = 0
        renaming = {}
        for entry in trace['allocations']:
            name = entry['eigenparameter']
            if entry['instruction_index'] in removed:
                renaming[name] = 0
            else:
                target_lower -= 1
                renaming[name] = target_lower
        # Substituting zero can turn a formerly nontrivial child proof into an
        # automatic hypothesis. Remove that child's entire instruction span.
        # Repeat because doing so can delete additional allocation events.
        extra = set()
        for frame in oracle.frames:
            if frame['accepted'] and rename(frame['goal']) in rename(frame['context']):
                extra.update(range(frame['end'], frame['start']))
        extra -= removed
        if not extra:
            break
        removed.update(extra)
        rounds += 1

    def witness(value, lower):
        try:
            Syntax(lower, width).term(value)
        except (ValueError, TypeError, IndexError):
            # Invalid active images could not have been accepted. The annotation
            # was unused. Use zero to avoid activating a reserved target shape.
            return 0
        return rename(value)

    cells = []
    for index, value in enumerate(packet[:-1]):
        if index in removed:
            continue
        info = oracle.annotations.get(index)
        if info is None:
            cells.append(deepcopy(value))  # irrelevant unconsumed prefix
            continue
        kind, lower = info['kind'], info['lower']
        if kind == 'introduction':
            value = witness(value, lower)
            cells.append([value] if wrapped else value)
        elif kind == 'elimination':
            major, annotation = value
            if info['major_kind'] == 2:
                annotation = rename(holes(annotation, lower, width))
            elif info['major_kind'] == 1:
                annotation = witness(annotation, lower)
            else:
                annotation = None  # inert paired-elimination annotation
            cells.append([rename(major), annotation])
        else:
            cells.append([])
    cells.append(rename(packet[-1]))
    return {'packet': cells, 'source_final_k': trace['final_k'],
            'target_final_k': target_lower,
            'discarded_cells': len(removed), 'hypothesis_pruning_rounds': rounds,
            'discarded_parameters': sum(v == 0 for v in renaming.values()),
            'remaining': trace['remaining']}


def unwrap_legacy(packet):
    """Every accepted wrapped certificate maps to a raw certificate.

    Only standalone instruction cells are unwrapped. The final goal and all
    formulas/terms inside elimination instructions retain their exact syntax.
    Reserved raw annotation shapes are invalid numerical terms; if accepted in
    the wrapped source, those annotations were unused, so zero is admissible.
    """
    result = []
    for cell in packet[:-1]:
        if type(cell) is list and len(cell) == 1:
            value = cell[0]
            if type(value) is list and len(value) in (0, 2):
                value = 0
            result.append(deepcopy(value))
        else:
            result.append(deepcopy(cell))
    return result + [deepcopy(packet[-1])]
