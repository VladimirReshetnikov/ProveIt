#!/usr/bin/env python3
"""Recompute the pinned iPRA source frontier without executing comparator code.

Usage: python3 audit_frontier.py [--corpus EXTRACTED_DIRECTORY] [--output DIRECTORY]
The default uses ten frozen root programs included beside this script.
--corpus also scans all historical complete-looking checker programs.
Only standard-library parsing, tokenization, hashing, and file I/O are used.
"""
import argparse
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

MEASURES = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
COMMIT = '25e16049bbc73c92703296181e0696370c987577'

class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node
    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean

def normalized_tree(source):
    return ast.fix_missing_locations(StripDocstrings().visit(ast.parse(source)))

def tree_metrics(tree):
    normalized = ast.unparse(tree) + '\n'
    return {
        'normalized_tokens': sum(t.type not in IGNORED for t in tokenize.generate_tokens(io.StringIO(normalized).readline)),
        'ast_nodes': sum(1 for _ in ast.walk(tree)),
        'normalized_bytes': len(normalized.encode('utf-8')),
        'normalized_sha256': hashlib.sha256(normalized.encode('utf-8')).hexdigest(),
        'ast_sha256': hashlib.sha256(ast.dump(tree, include_attributes=False).encode('utf-8')).hexdigest(),
    }

def metrics(path):
    raw = path.read_bytes()
    tree = normalized_tree(raw.decode('utf-8'))
    return {'raw_bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), **tree_metrics(tree)}

def current_core_tree(path):
    # Verified common boundary for the ten CURRENT programs: declarations plus
    # initial global state; all module imports and public input/verdict code gone.
    tree = normalized_tree(path.read_text())
    allowed = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Assign, ast.AnnAssign)
    return ast.Module(body=[node for node in tree.body if isinstance(node, allowed)], type_ignores=[])

COMMON_DRIVER = '''import json
import sys
try:
    take = json.load(open(sys.argv[1])).pop
    if not check(take(), []):
        raise ValueError
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
'''

def uniform_metrics(path):
    core = current_core_tree(path)
    body = ast.parse(COMMON_DRIVER).body
    common = ast.Module(body=body[:2] + core.body + body[2:], type_ignores=[])
    return {'uniform_core': tree_metrics(core), 'common_driver': tree_metrics(common)}

def complete_looking(path):
    source = path.read_text()
    tree = ast.parse(source)
    names = {node.name for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    # This intentionally broad sensitivity inventory is NOT a correctness claim.
    return bool({'check', 'verify'} & names) and ('json.load' in source or 'json.loads' in source) and 'ACCEPT' in source

def envelope(rows, field=None):
    values = [row if field is None else row[field] for row in rows]
    return {name: min(row[name] for row in values) for name in MEASURES}

def pareto(rows, field=None):
    def val(row): return row if field is None else row[field]
    unique = {row['normalized_sha256']: row for row in rows}.values()
    return [row['path'] for row in unique if not any(
        all(val(other)[name] <= val(row)[name] for name in MEASURES)
        and any(val(other)[name] < val(row)[name] for name in MEASURES)
        for other in rows)]

def counts(rows):
    return {'paths': len(rows), 'byte_distinct': len({r['sha256'] for r in rows}),
            'normalized_distinct': len({r['normalized_sha256'] for r in rows}),
            'ast_distinct': len({r['ast_sha256'] for r in rows})}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--corpus', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent / 'results')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    manifest = json.loads((base/'root_manifest.json').read_text())
    current = []
    for item in manifest:
        path = base / item['frozen_path']
        row = {**item, **metrics(path), **uniform_metrics(path)}
        if row['sha256'] != item['expected_sha256']:
            raise ValueError('Frozen comparator changed: ' + item['frozen_path'])
        current.append(row)
    result = {
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'commit': COMMIT, 'archives': 6,
        'metric': 'Delete only docstrings/comments, ast.unparse, significant tokens excluding whitespace; AST nodes via ast.walk; UTF-8 normalized bytes. Complete acceptance program counted.',
        'current_counts': counts(current),
        'current_envelope': envelope(current), 'current_pareto': pareto(current),
        'uniform_core_envelope': envelope(current, 'uniform_core'),
        'uniform_core_pareto': pareto(current, 'uniform_core'),
        'common_driver_envelope': envelope(current, 'common_driver'),
        'common_driver_pareto': pareto(current, 'common_driver'),
        'current': current,
    }
    if args.corpus:
        broad, excluded = [], []
        for path in sorted(args.corpus.rglob('*.py')):
            try:
                if complete_looking(path):
                    broad.append({'path': str(path.relative_to(args.corpus)), **metrics(path)})
            except (SyntaxError, UnicodeError) as error:
                excluded.append({'path': str(path), 'error': str(error)})
        result.update({'broad_counts': counts(broad), 'broad_envelope': envelope(broad),
                       'broad_pareto': pareto(broad), 'broad': broad, 'parse_errors': excluded})
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output/'frontier.json').write_text(json.dumps(result, indent=2)+'\n')
    with (args.output/'current.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream, ('path',*MEASURES,'raw_bytes','sha256'), extrasaction='ignore')
        writer.writeheader(); writer.writerows(current)
    print(json.dumps({k:v for k,v in result.items() if k not in ('current','broad')},indent=2))

if __name__ == '__main__':
    main()
