#!/usr/bin/env python3
"""Reproduce all delivered measurements and finite evidence offline."""
from pathlib import Path
import importlib.util
import json
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


def run(script, *args):
    process = subprocess.run([sys.executable, str(ROOT / script), *args],
                             cwd=ROOT, capture_output=True, text=True)
    (RESULTS / (Path(script).stem + "_run.txt")).write_text(process.stdout + process.stderr)
    if process.returncode:
        print(process.stdout[-6000:] + process.stderr[-6000:], file=sys.stderr)
        raise SystemExit(process.returncode)


def main():
    RESULTS.mkdir(exist_ok=True)
    run("comparison/audit_frontier.py", "--output", str(RESULTS / "frontier"))
    run("measure.py")
    run("validation/verify.py")
    run("validation/cross_audit.py")
    run("validation/relational_demo.py")
    frontier = json.loads((RESULTS / "frontier/frontier.json").read_text())
    integration = json.loads((RESULTS / "integration_metrics.json").read_text())
    validation = json.loads((ROOT / "validation/summary.json").read_text())
    detailed = json.loads((ROOT / "validation/results.json").read_text())
    cross = json.loads((ROOT / "validation/cross_results.json").read_text())
    demo = json.loads((RESULTS / "relational_demo.json").read_text())
    spec = importlib.util.spec_from_file_location("independent_metric", ROOT / "comparison/audit_frontier.py")
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    candidate = metric.metrics(ROOT / "checker.py")
    controlled = metric.uniform_metrics(ROOT / "checker.py")
    names = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    for name in names:
        alternate_name = "tokens" if name == "normalized_tokens" else name
        if candidate[name] != integration["scalar"][alternate_name]:
            raise AssertionError(("independent metric mismatch", name))
        if candidate[name] >= frontier["current_envelope"][name]:
            raise AssertionError(("not strictly below current frontier", name))
        for field, baseline in (("uniform_core", "uniform_core_envelope"),
                                ("common_driver", "common_driver_envelope")):
            if controlled[field][name] >= frontier[baseline][name]:
                raise AssertionError(("common-boundary comparison failed", field, name))
    if any(result["status"] != "PASS" for result in (validation, cross, demo)):
        raise AssertionError("Validation campaign did not pass")
    summary = {
        "status": "PASS", "python": platform.python_version(),
        "commit": frontier["commit"], "current_archives": 6, "current_programs": 10,
        "baseline": frontier["current_envelope"], "candidate": candidate,
        "common_driver_baseline": frontier["common_driver_envelope"],
        "common_driver_candidate": controlled["common_driver"],
        "uniform_core_baseline": frontier["uniform_core_envelope"],
        "uniform_core_candidate": controlled["uniform_core"],
        "strict_improvement_in_all_three_measures": True,
        "failures": 0,
        "fixture_packets": sum(p["fixture_count"] for p in validation["profiles"].values()),
        "public_cli_checks": sum(len(f["cli"]) for p in detailed["profiles"].values() for f in p["fixtures"]),
        "opening_comparisons": sum(sum(p["opening_audit"].values()) for p in validation["profiles"].values() if "opening_audit" in p),
        "mutated_packet_oracle_comparisons": sum(p["mutation_agreement"]["cases"] for p in validation["profiles"].values() if "mutation_agreement" in p),
        "sensitivity_controls": sum(len(p["sensitivity_controls"]) for p in validation["profiles"].values() if "sensitivity_controls" in p),
        "sequential_opening_comparisons": validation["sequential_opening"]["cases"],
        "scalar_embedding_comparisons": validation["embedding_opening"]["cases"],
        "cross_audit": cross["counts"],
        "mathematical_status": "Written proofs and independent audits; no proof-assistant formalization claimed.",
    }
    (RESULTS / "metrics.json").write_text(json.dumps(summary, indent=2) + "\n")
    macros = "\n".join("\\newcommand{\\%s}{%s}" % (label, candidate[field])
                       for label, field in (("NewTokens", "normalized_tokens"),
                                            ("NewNodes", "ast_nodes"),
                                            ("NewBytes", "normalized_bytes")))
    (RESULTS / "numbers.tex").write_text(macros + "\n")
    labels = {
        "ipra_context_freshness_2026-11-07": "Context freshness",
        "ipra_kernel_2026-11-07": "Kernel",
        "ipra_scope_complement_2026-11-07": "Scope complement",
        "ipra_scope_interval_2026-11-07": "Scope interval",
        "ipra_smaller_kernel_2026-11-07": "Smaller kernel",
        "ipra_staged_opening_2026-11-07": "Staged opening",
    }
    table = [r"\begin{longtable}{@{}p{.59\linewidth}rrr@{}}",
             r"\toprule Complete current program & Tokens & Nodes & Bytes\\\midrule",
             r"\endhead"]
    for row in frontier["current"]:
        archive = next(label for name, label in labels.items() if name in row["path"])
        filename = Path(row["path"]).name.replace("_", r"\_")
        table.append(archive + r" / \texttt{" + filename + "} & " +
                     " & ".join(str(row[name]) for name in names) + r"\\")
    table += [r"\midrule", r"\textbf{Delivered scalar checker} & " +
              " & ".join(str(candidate[name]) for name in names) + r"\\",
              r"\bottomrule", r"\end{longtable}"]
    (RESULTS / "current_table.tex").write_text("\n".join(table) + "\n")
    def triple(values):
        return "/".join(str(values[name]) for name in names)
    paragraphs = [
        "With the identical public driver attached, the current minimum is " +
        r"\(" + triple(summary["common_driver_baseline"]) + r"\), and the candidate is \(" +
        triple(summary["common_driver_candidate"]) + r"\). With the uniformly delimited checking core alone, the corresponding figures are \(" +
        triple(summary["uniform_core_baseline"]) + r"\) and \(" + triple(summary["uniform_core_candidate"]) +
        r"\). Thus the improvement is not solely a change to the public driver.",
        "The finite audit completed with zero failures. It includes " + str(summary["fixture_packets"]) +
        " explicit packets across the scalar, full-recursion, and embedded-scalar profiles, " +
        str(summary["public_cli_checks"]) + " direct public-command checks, " +
        format(summary["opening_comparisons"], ",") + " independently decoded opening comparisons, and " +
        format(summary["mutated_packet_oracle_comparisons"], ",") + " perturbed-packet comparisons with a named-syntax oracle. " +
        str(summary["sensitivity_controls"]) + " intentionally faulty variants are detected by targeted fixtures.",
        "The cross-check campaign records " + format(cross["counts"]["accepted_translations"], ",") +
        " successful accepted-certificate translations into frozen reference checkers, " +
        str(cross["counts"]["legacy_packets_checked"]) + " inherited packets checked, and " +
        str(cross["counts"]["aliased_certificates"]) + " certificate-alias cases. These are campaign counts; overlapping replays are not claimed as disjoint new samples. " +
        "The full-recursion companion is additionally checked by " +
        format(summary["sequential_opening_comparisons"], ",") + " sequential-versus-simultaneous opening comparisons and " +
        format(summary["scalar_embedding_comparisons"], ",") + " scalar-embedding comparisons.",
    ]
    (RESULTS / "validation_summary.tex").write_text("\n\n".join(paragraphs) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
