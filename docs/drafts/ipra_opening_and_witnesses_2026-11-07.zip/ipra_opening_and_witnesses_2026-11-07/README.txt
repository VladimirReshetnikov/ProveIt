A SMALLER iPRA CHECKER AND THE LIMITS OF INITIALIZER ELIMINATION
=============================================================
Prepared for Vladimir Reshetnikov, 7 November 2026.

START HERE

Read report.pdf. Its complete editable source is report.tex, with sections/
and the small generated tables in results/. All source files needed for
the report are included. This package runs offline after extraction.

THE RESULTS

1. A complete scalar-iteration acceptance program strictly improves all
   three inherited source measures over every current supplied checker:

                         tokens    AST nodes    normalized UTF-8 bytes
   current frontier         375          403                     1117
   checker.py               372          399                     1107

   Common-driver comparison: 372/400/1113 versus 374/401/1115.
   Uniform-core comparison:  318/343/922 versus 320/344/924.

   This is a modest integration of existing opening and certificate ideas.
   It is not a new arithmetic axiom basis, a mathematical lower-bound
   violation, or a proof of absolute shortestness. The benchmark is pinned
   to the six active draft archives at Git commit
   25e16049bbc73c92703296181e0696370c987577, containing ten complete
   root-level checkers. Older 389/413/1159 figures are not the target here.

2. A restricted noninterpretability theorem strengthens the inherited
   obstruction to eliminating the independent iterator initializer. The
   new finite-witness argument removes the finite-term-cover assumption
   for arbitrary operation graphs on existential-free domains and domains
   with a leading existential block. Finite-dimensional quotients are
   allowed. A fully explicit quantified-domain example shows why this
   argument does not cover every possible changed-domain interpretation.

3. The complete inherited arithmetic construction is included: numerical
   syntax, two computation schemas, five inference patterns, reconstruction
   of ordinary intuitionistic logic, predecessor and primitive-recursive
   coding, and a whole-domain bi-interpretation with full first-order iPRA.
   Ordinary logical falsity requires the explicit bridge (0 = S0) -> false.
   The native calculus instead designates 0 = S0 as its contradiction.

WHAT IS IN THE PACKAGE

report.pdf / report.tex / sections/
    The mathematical report and its complete LaTeX source.
checker.py
    The entire primary trusted acceptance program (Python 3.10+).
checker_full.py
    Full-primitive-recursion validation companion: 379/405/1119.
    This companion is not the size-improvement candidate.
FORMAT.txt
    Complete JSON syntax, binder/opening rules, instruction dispatch,
    eigenvariable allocation, failed-guard behavior, and trust boundary.
examples/
    Small accepted and rejected proof packets.
comparison/
    Ten byte-for-byte frozen current checkers, independent measurement,
    source manifests, and the broader historical inventory.
validation/
    Independent named oracle, generated fixtures, adversarial mutations,
    untrusted certificate translator, legacy fixtures, mathematical audits,
    and a finite standard-model replay of the quantified-domain example.
results/
    Recorded metrics, validation results, source comparisons, and build logs.
reproduce.py / measure.py / build.py / package.py
    Reproduction entry points; none is imported by either checker.
ATTRIBUTION.txt / LICENSE_SOURCE.txt / PROVENANCE.json
    Inherited and new contributions, source license, and checker hashes.
repository_snapshot.json / SHA256SUMS
    Retrieved source archive provenance and final package integrity hashes.

QUICK START

  python3 checker.py examples/zero_initialization.json
  python3 checker.py examples/addition_two_three.json
  python3 checker.py examples/atomic_induction_recursion_identity.json

Each should print ACCEPT and exit 0. This deliberate attack should print
REJECT and exit 1:

  python3 checker.py examples/compound_induction_hypothesis_attack.json

Run the complete offline reproduction:

  python3 reproduce.py

It independently measures the frozen comparison set, measures the candidate
and controls, exercises valid/invalid certificates and opening semantics,
cross-checks translated certificates, and replays a finite part of the
relational boundary example. The standard library is sufficient. Exact
measurements in this package use Python 3.12.14. Python AST/unparse versions
can affect metrics, so compare candidates within the same interpreter.

Compile the report (pdfLaTeX with the packages declared in report.tex):

  python3 build.py

The build performs three passes and fails on LaTeX errors, undefined
references, or overfull boxes. The supplied PDF was also visually inspected.
Run python3 package.py to regenerate the ZIP and SHA256SUMS manifest after
any intentional changes (update PROVENANCE.json if a recorded source changes).

VALIDATION AND LIMITS

Recorded verification has zero failures: 135 fixture packets across three
profiles, 146 public
CLI invocations, 15,664 opening-oracle comparisons, 4,000 mutated-packet
comparisons, 17 deliberately defective variants detected, 3,000 staged
substitution comparisons, and 2,000 scalar-embedding comparisons. A separate
cross-audit checked 1,510 accepted translated outputs against frozen exact
reference programs, 312 alias certificates, and targeted scope-pruning
regressions. Some test populations overlap; these are not summed into one
purported count of distinct proofs. See the machine-readable results.

These finite checks do not replace the mathematical proofs, and those proofs
have not been formalized in Lean, Rocq, or another independently checked
proof assistant. The accepted language has a direct soundness/completeness
argument in the report. Resource limits in real Python execution can reject
large proofs; completeness is the usual unbounded finite-resource claim.

The report deliberately excludes an apparently smaller unfused-existential
candidate because it fails a basic existence theorem. It does not claim
unrestricted noninterpretability for every tied-initializer theory, or an
absolute optimum across all languages, encodings, runtimes, or domains.

SOURCE

https://github.com/VladimirReshetnikov/ProveIt/tree/25e16049bbc73c92703296181e0696370c987577/docs/drafts
