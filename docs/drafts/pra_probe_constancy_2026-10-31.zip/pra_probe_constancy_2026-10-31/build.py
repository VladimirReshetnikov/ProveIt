#!/usr/bin/env python3
"""Rebuild this report and its diagnostics using local tools only."""

from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path


def run(command: list[str], directory: Path, log: Path | None = None) -> None:
    result = subprocess.run(command, cwd=directory, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if log is not None:
        log.write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        print(result.stdout)
        raise SystemExit(result.returncode)
    print("Passed:", " ".join(command))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Path to a Lean4.19.0 executable")
    parser.add_argument("--skip-pdf", action="store_true")
    parser.add_argument("--skip-diagnostics", action="store_true")
    arguments = parser.parse_args()
    directory = Path(__file__).resolve().parent
    build = directory / "build"
    build.mkdir(exist_ok=True)
    if not arguments.skip_diagnostics:
        for script in ("schema_metrics.py", "finite_diagnostics.py"):
            run(["python3", str(directory / "artifacts" / script)], directory,
                build / (script + ".log"))
    if arguments.lean:
        run([arguments.lean, "--version"], directory, build / "lean-version.txt")
        run([arguments.lean, "formal/ProbeConstancy.lean"], directory,
            build / "lean-check.log")
    if not arguments.skip_pdf:
        command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                   "-output-directory=build", "pra_probe_constancy.tex"]
        for number in range(1, 4):
            run(command, directory, build / f"pdflatex-pass-{number}.txt")
        shutil.copyfile(build / "pra_probe_constancy.pdf",
                        directory / "pra_probe_constancy.pdf")
        print("PDF:", directory / "pra_probe_constancy.pdf")


if __name__ == "__main__":
    main()
