#!/usr/bin/env python3
"""Reconstruct formula AST counts; these are not encoded theory lengths."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class Tree:
    symbol: str
    arguments: tuple["Tree", ...] = ()

    def nodes(self) -> int:
        return 1 + sum(argument.nodes() for argument in self.arguments)

    def display(self) -> str:
        if not self.arguments:
            return self.symbol
        return self.symbol + "(" + ",".join(x.display() for x in self.arguments) + ")"


def tree(symbol: str, *arguments: Tree) -> Tree:
    return Tree(symbol, arguments)


def universal(variables: tuple[Tree, ...], body: Tree) -> Tree:
    for variable in reversed(variables):
        body = tree("forall " + variable.symbol, body)
    return body


ZERO, FALSE, N, A, X, Y, V = map(Tree, ("0", "false", "n", "a", "x", "y", "v"))
ONE = tree("S", ZERO)


def equality(left: Tree, right: Tree) -> Tree:
    return tree("=", left, right)


def separation() -> Tree:
    return tree("implies", equality(ZERO, ONE), FALSE)


def definitions(parameters: tuple[Tree, ...]) -> tuple[Tree, Tree]:
    changed = (tree("k", parameters[0]), *parameters[1:])
    base = universal(parameters, equality(
        tree("R", ZERO, *parameters), tree("g", *parameters)))
    step = universal((N, *parameters), equality(
        tree("R", tree("S", N), *parameters),
        tree("h", N, *parameters, tree("R", N, *changed))))
    return base, step


def probe(parameters: tuple[Tree, ...]) -> Tree:
    anchor = parameters[0]
    f = lambda index: tree("f", index, *parameters)
    premise = universal((N,), equality(f(tree("S", N)), f(N)))
    conclusion = universal((N,), tree("or",
        equality(f(N), anchor),
        equality(tree("e", f(ZERO), anchor), ZERO)))
    return universal(parameters, tree("implies", premise, conclusion))


def stationary_separation(parameters: tuple[Tree, ...]) -> Tree:
    f = lambda index: tree("f", index, *parameters)
    premise = universal((N,), equality(f(tree("S", N)), f(N)))
    conclusion = universal((N,), tree("implies",
        equality(tree("S", f(N)), f(ZERO)), FALSE))
    return universal(parameters, tree("implies", premise, conclusion))


def off_diagonal() -> Tree:
    return universal((X, Y), tree("or",
        equality(tree("e", X, Y), ZERO), equality(X, Y)))


def record(expression: Tree) -> dict[str, object]:
    return {"nodes": expression.nodes(), "expanded_tree": expression.display()}


def main() -> None:
    base, step = definitions((A,))
    current = {
        "D_base": record(base),
        "D_step": record(step),
        "Sep": record(separation()),
        "Probe": record(probe((A,))),
    }
    old = {
        "D_base": record(base),
        "D_step": record(step),
        "O": record(off_diagonal()),
        "SS": record(stationary_separation((A,))),
    }
    assert [entry["nodes"] for entry in current.values()] == [7, 14, 6, 25]
    assert [entry["nodes"] for entry in old.values()] == [7, 14, 11, 22]

    parameter_table = []
    for count in range(1, 9):
        parameters = (A, *(Tree(f"b{j}") for j in range(1, count)))
        d0, d1 = definitions(parameters)
        d_count = d0.nodes() + d1.nodes()
        p_count = probe(parameters).nodes()
        old_count = stationary_separation(parameters).nodes() + off_diagonal().nodes()
        assert d_count == 7 * count + 14
        assert p_count == 5 * count + 20
        assert old_count == 5 * count + 28
        new_total = d_count + p_count + separation().nodes()
        old_total = d_count + old_count
        assert (new_total, old_total) == (12 * count + 40, 12 * count + 42)
        parameter_table.append({
            "m_including_probe_parameter": count,
            "D_sub": d_count,
            "Probe": p_count,
            "Sep": separation().nodes(),
            "new_total": new_total,
            "previous_substitution_descent_total": old_total,
            "saving": old_total - new_total,
        })

    # Actual stored descriptors, not names for unexpanded p or 1.
    # P: g(a)=a, h(n,a,v)=n, k(a)=a.
    # C: g(a,b)=a, h(n,a,b,v)=b, k(a)=a. The recursive result is ignored.
    # e: g(y)=C(y,S0,0), h(n,y,v)=C(y,0,v), k(y)=P(y,0).
    b = Tree("b")
    bodies = {
        "P": {"g": A, "h": N, "k": A},
        "C": {"g": A, "h": b, "k": A},
        "e": {
            "g": tree("C", Y, ONE, ZERO),
            "h": tree("C", Y, ZERO, V),
            "k": tree("P", Y, ZERO),
        },
    }
    descriptor_report = {
        symbol: {
            "bodies": {name: record(value) for name, value in entries.items()},
            "total_body_nodes": sum(value.nodes() for value in entries.values()),
        }
        for symbol, entries in bodies.items()
    }
    assert descriptor_report["e"]["total_body_nodes"] == 12
    descriptor_total = sum(entry["total_body_nodes"] for entry in descriptor_report.values())
    assert descriptor_total == 18

    result = {
        "status": "passed",
        "metric": (
            "One node per variable, constant, function application, equality, "
            "connective, falsity symbol, and single-variable quantifier. The "
            "bound variable's name is not counted as another child of its quantifier."
        ),
        "scope": (
            "Exact counts of explicitly generated ASTs. An f-call includes its "
            "displayed arguments, not the body substituted for f. These counts "
            "are not encoded theory lengths and omit grammar implementation, "
            "symbol-name encodings, descriptor tags, and arity metadata."
        ),
        "one_parameter_new": current,
        "one_parameter_previous_substitution_descent": old,
        "one_parameter_totals": {"new": 52, "previous": 54, "saving": 2},
        "parameter_convention": (
            "m>=1 counts all displayed parameters, including the distinguished "
            "probe a; the frozen tuple b has length m-1. No upper bound is imposed "
            "by the theory. Eight displayed cases are checked here."
        ),
        "uniform_formulas": {
            "D_sub": "7*m + 14",
            "Probe": "5*m + 20",
            "new_total": "12*m + 40",
            "previous_total": "12*m + 42",
        },
        "parameter_table": parameter_table,
        "designated_descriptors": descriptor_report,
        "all_designated_descriptor_body_nodes": descriptor_total,
        "descriptor_convention": (
            "Each g,h,k body is counted once; p(t) is expanded to P(t,0), "
            "and 1 to S(0). P,C,e are genuine designated description symbols. "
            "The identity k bodies of P and C are counted even though their "
            "updates ignore the recursive result."
        ),
    }
    destination = Path(__file__).with_name("schema_metrics.json")
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "display_totals": result["one_parameter_totals"],
                      "descriptor_body_total": descriptor_total}))


if __name__ == "__main__":
    main()
