#!/usr/bin/env python3
"""Deterministic finite diagnostics, not proofs of universal equivalence."""

from __future__ import annotations

import itertools
import json
import platform
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Callable


def predecessor_seed(n: int, a: int) -> int:
    return a if n == 0 else n - 1


def predecessor(n: int) -> int:
    return predecessor_seed(n, 0)


def choose(n: int, a: int, b: int) -> int:
    return a if n == 0 else b


@lru_cache(maxsize=None)
def equality_bit(x: int, y: int) -> int:
    if x == 0:
        return choose(y, 1, 0)
    return choose(y, 0, equality_bit(x - 1, predecessor(y)))


def check_comparator() -> dict[str, object]:
    pairs = corners = probes = 0
    for x, y in itertools.product(range(49), repeat=2):
        value = equality_bit(x, y)
        assert value in (0, 1)
        assert (value == 1) == (x == y)
        assert (value == 0) == (x != y)
        assert equality_bit(x + 1, y + 1) == value
        assert equality_bit(0, y + 1) == 0
        assert equality_bit(x + 1, 0) == 0
        pairs += 1
        corners += 3
        # A constant f has a reflexive stationarity premise. This is its
        # Probe consequent with x as the constant and y as the probe.
        assert x == y or equality_bit(x, y) == 0
        probes += 1
    diagonal = [equality_bit(n, n) for n in range(65)]
    assert diagonal == [1] * 65
    assert all(d == 1 or equality_bit(diagonal[0], 1) == 0 for d in diagonal)
    return {"status": "passed", "domain_per_argument": [0, 48],
            "exact_comparator_pairs": pairs, "corner_checks": corners,
            "constant_probe_instances": probes, "diagonal_samples": len(diagonal)}


# Small syntax trees are tuples. The semantic evaluator and compiler use
# separate dispatch tables, so a truth-table error in a compiler row is visible.
Term = tuple
Formula = tuple


def term_value(term: Term, assignment: tuple[int, int]) -> int:
    head, *args = term
    if head == "number":
        return args[0]
    if head == "x":
        return assignment[0]
    if head == "y":
        return assignment[1]
    values = [term_value(arg, assignment) for arg in args]
    if head == "S":
        return values[0] + 1
    if head == "P":
        return predecessor_seed(*values)
    if head == "e":
        return equality_bit(*values)
    if head == "C":
        return choose(*values)
    raise ValueError(head)


def formula_value(formula: Formula, assignment: tuple[int, int]) -> bool:
    head, *args = formula
    if head == "equal":
        return term_value(args[0], assignment) == term_value(args[1], assignment)
    if head == "false":
        return False
    if head == "true":
        return True
    left = formula_value(args[0], assignment)
    right = formula_value(args[1], assignment)
    if head == "and":
        return left and right
    if head == "or":
        return left or right
    if head == "implies":
        return (not left) or right
    raise ValueError(head)


def compile_bit(formula: Formula) -> Term:
    head, *args = formula
    zero, one = ("number", 0), ("S", ("number", 0))
    if head == "equal":
        return ("e", args[0], args[1])
    if head == "false":
        return zero
    if head == "true":
        return one
    left, right = (compile_bit(arg) for arg in args)
    if head == "and":
        return ("C", left, zero, right)
    if head == "or":
        return ("C", left, right, one)
    if head == "implies":
        return ("C", left, one, right)
    raise ValueError(head)


def check_formula_compiler() -> dict[str, object]:
    x, y, zero = ("x",), ("y",), ("number", 0)
    atoms = [("equal", x, y), ("equal", x, zero),
             ("equal", ("S", x), y), ("false",), ("true",)]
    connectives = ("and", "or", "implies")
    level_one = atoms + [(c, left, right) for c in connectives
                         for left in atoms for right in atoms]
    formulas = atoms + [(c, left, right) for c in connectives
                        for left in level_one for right in level_one]
    assignments = list(itertools.product(range(5), repeat=2))
    checked = top_implications = 0
    for formula in formulas:
        compiled = compile_bit(formula)
        for assignment in assignments:
            actual = term_value(compiled, assignment)
            expected = formula_value(formula, assignment)
            assert actual in (0, 1)
            assert (actual == 1) == expected, (formula, assignment, actual)
            assert (actual == 0) == (not expected)
            checked += 1
            top_implications += formula[0] == "implies"
    assert len(formulas) == 19205

    # Check every implication input pair directly as well. The compiler's
    # antecedent-zero branch must be 1, not 0.
    truth_rows = []
    for left, right in itertools.product((0, 1), repeat=2):
        bit = choose(left, 1, right)
        assert bit == int((not bool(left)) or bool(right))
        truth_rows.append({"antecedent": left, "consequent": right, "bit": bit})
    return {"status": "passed", "maximum_logical_depth": 2,
            "atomic_formulas": len(atoms), "formulas": len(formulas),
            "assignments": len(assignments), "formula_assignment_checks": checked,
            "top_level_implication_checks": top_implications,
            "implication_truth_table": truth_rows,
            "scope": "Natural-number semantic checks of finitely many compiled formulas; "
                     "the constructive proof in the manuscript is still necessary."}


def latch(bits: tuple[int, ...]) -> tuple[int, ...]:
    values = [1]
    for bit in bits:
        assert bit in (0, 1)
        values.append(choose(bit, 0, values[-1]))
    return tuple(values)


def check_latch() -> dict[str, object]:
    sequences = progressing = valid = 0
    for bits in itertools.product((0, 1), repeat=9):
        run = latch(bits)
        shifted = run[1:]
        progress = all(first == 0 or second == 1
                       for first, second in zip(bits, bits[1:]))
        sequences += 1
        if progress:
            progressing += 1
            assert len(set(shifted)) == 1
            if bits[0] == 1:
                valid += 1
                assert shifted == (1,) * len(bits)
                assert bits == (1,) * len(bits)
                assert all(value == 1 or equality_bit(shifted[0], 1) == 0
                           for value in shifted)

    # Nontrivial arithmetic expressions whose resulting bits satisfy the
    # base and progression hypotheses on each stated finite window.
    numeric_families = {
        "predecessor_successor": lambda n, a, b: equality_bit(
            predecessor_seed(n + 1, a), n),
        "addition_commutes": lambda n, a, b: equality_bit(n + a, a + n),
        "multiplication_distributes": lambda n, a, b: equality_bit(
            (n + a) * (b + 1), n * (b + 1) + a * (b + 1)),
    }
    numeric_checks = []
    for name, bit_function in numeric_families.items():
        count = 0
        for a, b in itertools.product(range(4), repeat=2):
            bits = tuple(bit_function(n, a, b) for n in range(25))
            assert bits[0] == 1
            assert all(first == 0 or second == 1
                       for first, second in zip(bits, bits[1:]))
            assert latch(bits) == (1,) * 26
            count += 1
        numeric_checks.append({"name": name, "parameter_pairs": count,
                               "indices_per_pair": 25})

    missing_step = (1, 1, 0, 1, 1, 1)
    run = latch(missing_step)
    shifted = run[1:]
    bad_step_indices = [n for n in range(len(missing_step) - 1)
                        if missing_step[n] == 1 and missing_step[n + 1] == 0]
    bad_stationarity_indices = [n for n in range(len(shifted) - 1)
                                if shifted[n] != shifted[n + 1]]
    assert bad_step_indices == [1]
    assert bad_stationarity_indices == [1]
    assert shifted == (1, 1, 0, 0, 0, 0)
    no_base = (0, 0, 1, 1, 1)
    assert latch(no_base)[1:] == (0,) * 5
    return {"status": "passed", "exhaustive_bit_stream_length": 9,
            "bit_streams": sequences, "streams_with_progression": progressing,
            "streams_with_base_and_progression": valid,
            "numeric_examples": numeric_checks,
            "missing_step_negative_control": {
                "bits": missing_step, "latch_including_seed": run,
                "shifted_latch": shifted, "failed_step_indices": bad_step_indices,
                "failed_stationarity_indices": bad_stationarity_indices,
                "finding": "Omitting progress permits loss of stationarity and loss of truth."},
            "missing_base_negative_control": {
                "bits": no_base, "shifted_latch": latch(no_base)[1:],
                "finding": "Progression alone permits a stationary zero latch."}}


Frozen = tuple[int, ...]


@dataclass(frozen=True)
class RecursionCase:
    name: str
    frozen_arity: int
    g: Callable[[int, Frozen], int]
    h: Callable[[int, int, Frozen, int], int]
    k: Callable[[int], int]


def ordinary_fold(case: RecursionCase, n: int, a: int,
                  frozen: Frozen) -> tuple[int, list[int], list[int]]:
    orbit = [a]
    for _ in range(n):
        orbit.append(case.k(orbit[-1]))
    values = [case.g(orbit[-1], frozen)]
    for j in range(n):
        values.append(case.h(j, orbit[n - j - 1], frozen, values[-1]))
    return values[-1], orbit, values


def check_substitution_compiler() -> dict[str, object]:
    cases = [
        RecursionCase("identity_transform", 1,
                      lambda a, b: a + 3 * b[0],
                      lambda n, a, b, v: v + b[0] + n * n,
                      lambda a: a),
        RecursionCase("equality_description", 0,
                      lambda a, b: choose(a, 1, 0),
                      lambda n, a, b, v: choose(a, 0, v),
                      predecessor),
        RecursionCase("growing_parameter", 1,
                      lambda a, b: a + b[0] + 1,
                      lambda n, a, b, v: (n + 1) * v + a * (b[0] + 1),
                      lambda a: 2 * a + 1),
        RecursionCase("noninjective_parameter_two_frozen", 2,
                      lambda a, b: a * a + b[0] + 2 * b[1],
                      lambda n, a, b, v: (v + a + n + b[0]) * (b[1] + 1),
                      lambda a: a // 2),
        RecursionCase("cyclic_parameter_nonlinear_update", 2,
                      lambda a, b: a * b[0] + b[1],
                      lambda n, a, b, v: (v * v + n + a + b[0]) % 101 + b[1],
                      lambda a: (3 * a + 2) % 11),
        RecursionCase("selector_and_two_frozen_parameters", 2,
                      lambda a, b: choose(a, b[0], b[1]),
                      lambda n, a, b, v: choose((a + n) % 3,
                                                b[0] + v, b[1] + n + a),
                      lambda a: (a * a + 1) % 13),
    ]
    reports = []
    for case in cases:
        @lru_cache(maxsize=None)
        def direct(n: int, a: int, frozen: Frozen) -> int:
            if n == 0:
                return case.g(a, frozen)
            return case.h(n - 1, a, frozen, direct(n - 1, case.k(a), frozen))

        comparisons = traces = recurrences = 0
        for frozen in itertools.product(range(4), repeat=case.frozen_arity):
            for a, n in itertools.product(range(7), range(8)):
                computed, orbit, values = ordinary_fold(case, n, a, frozen)
                assert computed == direct(n, a, frozen)
                comparisons += 1
                for j in range(n + 1):
                    assert direct(j, orbit[n - j], frozen) == values[j]
                    traces += 1
                next_value = ordinary_fold(case, n + 1, a, frozen)[0]
                inner = ordinary_fold(case, n, case.k(a), frozen)[0]
                assert next_value == case.h(n, a, frozen, inner)
                recurrences += 1
                if case.name == "equality_description":
                    assert computed == equality_bit(n, a)
        reports.append({"name": case.name, "frozen_arity": case.frozen_arity,
                        "direct_comparisons": comparisons,
                        "guarded_trace_checks": traces,
                        "successor_equation_checks": recurrences,
                        "status": "passed"})

    sensitive = RecursionCase("negative_controls", 1,
                              lambda a, b: a * a + b[0],
                              lambda n, a, b, v: a + 2 * v + n + 3 * b[0],
                              lambda a: a + 1)
    n, a, frozen = 3, 2, (5,)
    correct, orbit, prefixes = ordinary_fold(sensitive, n, a, frozen)
    stale = sensitive.g(orbit[-1], frozen)
    forward_order = stale
    for j in range(n):
        stale = sensitive.h(j, a, frozen, stale)
        forward_order = sensitive.h(j, orbit[j], frozen, forward_order)
    changed_frozen = ordinary_fold(sensitive, n, a, (frozen[0] + n,))[0]
    assert stale != correct
    assert forward_order != correct
    assert changed_frozen != correct
    totals = {key: sum(report[key] for report in reports)
              for key in ("direct_comparisons", "guarded_trace_checks",
                          "successor_equation_checks")}
    return {"status": "passed", "maximum_direct_depth": 7,
            "initial_changed_parameter_values": [0, 6],
            "frozen_parameter_values": [0, 3],
            "cases": reports, "totals": totals,
            "negative_controls": {
                "initial_input": {"n": n, "a": a, "frozen": frozen},
                "parameter_orbit": orbit, "fold_prefixes": prefixes,
                "correct_result": correct, "incorrect_stale_parameter": stale,
                "incorrect_forward_orbit_order": forward_order,
                "incorrect_changed_frozen_tuple": changed_frozen,
                "all_three_errors_detected": True},
            "scope": "Checks the explicit ordinary-PR compiler on finite inputs, "
                     "including its bounded trace invariant; not a uniqueness proof "
                     "in arbitrary or nonstandard models."}


def componentwise(function: Callable[..., int], *pairs: tuple[int, int]) -> tuple[int, int]:
    return tuple(function(*(pair[index] for pair in pairs)) for index in range(2))


def check_product_witness() -> dict[str, object]:
    zero, witness = (0, 0), (0, 1)
    pred_witness = componentwise(predecessor, witness)
    succ_pred = componentwise(lambda x: x + 1, pred_witness)
    eq_to_zero = componentwise(equality_bit, witness, zero)
    assert witness != zero
    assert witness != succ_pred
    assert eq_to_zero == (1, 0)
    assert not (witness == zero or eq_to_zero == zero)

    # This samples one stationary term e(n,n). The accompanying README
    # gives the mathematical argument for ALL term-constancy instances.
    samples = [componentwise(equality_bit, pair, pair)
               for pair in itertools.product(range(8), repeat=2)]
    assert samples == [(1, 1)] * 64
    return {"status": "passed", "structure": "N x N, all operations componentwise",
            "mixed_element": witness, "zero": zero, "successor_of_predecessor": succ_pred,
            "constructor_coverage_fails": True,
            "constant_probe_instance": {"f_value": witness, "probe": zero,
                                        "e_f0_probe": eq_to_zero,
                                        "stationarity_premise": True,
                                        "probe_consequent": False},
            "sampled_diagonal_stationary_values": len(samples),
            "scope": "These are explicit counterexample values. The universal "
                     "claim that the product validates ordinary term constancy "
                     "uses the separate coordinatewise argument in README.txt."}


def main() -> None:
    results = {
        "status": "passed",
        "python_version": platform.python_version(),
        "scope": (
            "Deterministic finite natural-number diagnostics and an explicit "
            "product counterexample. These do not prove the axiom schemas, "
            "intuitionistic derivability, equiconsistency, or bi-interpretability."
        ),
        "comparator": check_comparator(),
        "formula_compiler": check_formula_compiler(),
        "shifted_latch": check_latch(),
        "substitution_compiler": check_substitution_compiler(),
        "ordinary_constancy_is_insufficient": check_product_witness(),
    }
    destination = Path(__file__).with_name("finite_diagnostics.json")
    destination.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed",
                      "formula_assignment_checks": results["formula_compiler"]["formula_assignment_checks"],
                      "compiler_totals": results["substitution_compiler"]["totals"]}))


if __name__ == "__main__":
    main()
