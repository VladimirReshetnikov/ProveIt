SUPPORTING ARTIFACTS: PROBE CONSTANCY
====================================

Both scripts use only the Python 3 standard library and run from any
working directory. Each writes its JSON report next to the script.

  python3 artifacts/schema_metrics.py
  python3 artifacts/finite_diagnostics.py

WHAT THE METRICS CHECK
---------------------
schema_metrics.py constructs the displayed formulas as explicit syntax
trees and counts them. Every variable, constant, application, equality,
connective, falsity symbol, and single-variable quantifier counts once.
Negation is implication to falsity. The abbreviation 1 is expanded to S(0).
The name of a bound variable is metadata of its quantifier, not another
variable-occurrence node.

m counts all displayed schema parameters, including the distinguished
probe a. The frozen tuple has length m-1. The actual theory has no finite
upper bound on m; the script evaluates the stated formulas at m=1,...,8.

  D_sub = 7m+14; Probe = 5m+20; Sep = 6.
  New displayed total = 12m+40, hence 52 at m=1.
  Prior substitution-descent total = 12m+42, hence 54 at m=1.

The designated descriptions are charged separately. Their g,h,k bodies
are counted once each, including unused identity k bodies. The predecessor
abbreviation p(t) is expanded to P(t,0), not treated as a free unary name.
The comparator's three body counts are 5,4,3, totaling 12. Including P and
the direct selector C gives 18 designated body nodes. This is not an
encoded length of the theory: grammar implementation, symbol-name lengths,
descriptor tags, arity metadata, and the arbitrary term substituted into
a schema are not counted as if they were free finite data.

WHAT THE FINITE DIAGNOSTICS CHECK
--------------------------------
1. The specified comparator is evaluated from its substitution recurrence.
   Exact Boolean equality, the corner equations, constant Probe instances,
   and diagonal instances are checked on stated finite natural-number
   ranges.

2. A separate formula evaluator is compared with the arithmetic truth-bit
   compiler for all formulas of logical depth at most two over five fixed
   atomic formulas (including falsity and truth), on 25 assignments. The
   compiler includes conjunction, disjunction, and implication. All four
   implication input pairs are also listed explicitly.

3. All 512 Boolean streams of length nine are checked against the shifted
   latch. The report distinguishes progression from the base hypothesis.
   Arithmetic examples supply additional streams. Two negative controls
   show why the step and the base cannot be dropped: a missing step can
   destroy stationarity, while a missing base permits a stationary zero
   latch.

4. The general parameter-substitution compiler is compared with a direct
   evaluator on identity, predecessor, growing, cyclic, and noninjective
   parameter transformations. Examples retain zero, one, or two frozen
   parameters. Every tested bounded trace is checked, as are the translated
   successor equations. Negative controls deliberately retain a stale
   changing parameter, reverse the required fold order, or change a frozen
   parameter; all three errors are detected.

5. An explicit element of N x N demonstrates the obstruction to replacing
   Probe by ordinary term constancy. The exact numbers are checked below;
   a finite search is not offered as a proof about an infinite model.

THE PRODUCT OBSTRUCTION: MATHEMATICAL ARGUMENT
---------------------------------------------
Interpret 0, S, and every described function componentwise in N x N.
The defining equations and 0 != S0 hold coordinatewise. Every term is a
pair of ordinary natural-number term functions, with no coordinate mixing.
If a term f satisfies f(Sn)=f(n) for every pair n, each coordinate function
is stationary on N. Ordinary external induction on N makes that coordinate
function constant. Thus the product validates every ordinary term-constancy
instance, including all finite parameter tuples.

Nevertheless x=(0,1) is neither (0,0) nor S(p(x))=(1,1), so constructor
coverage fails. For the constant term f(n)=x with probe a=(0,0), the new
Probe premise is reflexive but both consequent disjuncts fail:

  f(n) != a, and e(f(0),a)=(1,0) != (0,0).

The product is therefore a countermodel to recovering PRA by replacing
Probe with ordinary constancy while retaining D_sub and Sep. It is not a
countermodel to ordinary constancy itself: ordinary constancy holds there.

LIMITS
------
The formula-tree counts are exact counts of the generated finite syntax.
All numerical and compiler checks are finite diagnostics. They are not
formal first-order derivations, do not quantify over all PR descriptions,
do not settle behavior in nonstandard models, and do not prove intuitionistic
soundness or either round trip of the bi-interpretation. Those claims rely
on the mathematical proofs in the manuscript and the precisely scoped
formal certificate, if included elsewhere in the package.
