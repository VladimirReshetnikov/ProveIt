PRA FROM PROBE CONSTANCY
Research package prepared for Vladimir Reshetnikov
31 October 2026
================================================

RESULT
The same nonlogical basis works in classical and intuitionistic first-order
logic, separately:

  two effective parameter-substitution computation templates;
  0 != S0;
  one stationary probe schema.

For each finite term f(n,a,b_bar), the schema says

  [forall n, f(Sn,a,b_bar)=f(n,a,b_bar)] ->
  [forall n, f(n,a,b_bar)=a OR e(f(0,a,b_bar),a)=0].

The comparator e is an explicitly specified finite recursive program.
Constant, diagonal, and running-test instances recover native equality and
all quantifier-free induction constructively. The paper proves a reverse
compiler, its internal uniqueness, and identity-domain round trips. Thus
the corresponding theories are definitionally equivalent, bi-interpretable,
and equiconsistent with ordinary PRA in the matching logic.

IMPROVEMENT
The display decreases from 54 to 52 formula-tree nodes compared with the current
substitution-descent draft in exactly its recursion grammar. The comparator
bootstrap is shorter, and the designated program-body count decreases from 19
to 18 by using a direct selector. These are modest, specified improvements.
There is no claim of an absolute shortest encoding, a strict binary language,
or a one-parameter sufficiency theorem.

READ FIRST
  pra_probe_constancy.pdf       Complete report, including all mathematical proofs.
  pra_probe_constancy.tex       Complete self-contained LaTeX source.
  SPECIFICATION.txt            Standalone exact language and axioms.

SUPPORTING FILES
  formal/ProbeConstancy.lean    Constructive local kernel, Lean 4.19.0.
  formal/README.txt            Precise verified scope and limitations.
  formal/check.log             Successful compiler output and six axiom audits.
  artifacts/schema_metrics.py  Reconstructs formula and descriptor AST counts.
  artifacts/finite_diagnostics.py
                              Comparator, formula, latch, and compiler diagnostics.
  artifacts/*.json             Recorded reproducible results.
  artifacts/README.txt         Exact scope of finite checks and negative controls.
  audit/source_manifest.json   Pinned GitHub sources and cryptographic digests.
  audit/proof_review.txt       Mathematical review scope and findings.
  audit/validation.json        Build and verification record.
  build.py                    Rebuild PDF, run diagnostics, optionally replay Lean.
  SHA256SUMS                  Delivered-file checksums, excluding this manifest.

REPRODUCE
From this directory:
  python3 build.py

Optional Lean replay:
  python3 build.py --lean /absolute/path/to/lean

Diagnostics without rebuilding the PDF:
  python3 build.py --skip-pdf

Requirements: Python 3.10+ (standard library only); pdfLaTeX with the ordinary
TeX Live packages named in the source preamble; Lean 4.19.0 for formal replay.
No Mathlib, network access, or external bibliography processor is needed.

To verify the delivered files before rebuilding:
  sha256sum -c SHA256SUMS
Rebuilding may change PDF metadata and diagnostic files; the delivered checksum
manifest is deliberately not rewritten by build.py. The build/ directory is
temporary and is excluded from the delivered archive.

VERIFICATION BOUNDARY
The report gives the entire written equivalence proof. The checked Lean kernel
does not formalize the first-order calculus, complete PR descriptor syntax,
reverse compiler, or bi-interpretation metatheorem. Its mathematical hypotheses
remain explicit theorem parameters. Finite Python tests are diagnostics, not
universal or intuitionistic proofs. No external peer review is asserted.

PROVENANCE
Compared all six current ProveIt/docs/drafts archives at commit
392757d09455930d2b090b26bd1537799451c91a. Checked the docs/incoming inventory
and index; no additional PRA archive was identified. The supplied sources'
historical comparison tables were not treated as the current inventory.
Original reference archives are not redistributed. No repository changes
are part of this deliverable.
