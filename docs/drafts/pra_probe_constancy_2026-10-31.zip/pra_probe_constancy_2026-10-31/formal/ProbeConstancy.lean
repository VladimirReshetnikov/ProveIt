import Init

/-!
# A constructive kernel for the stationary probe principle

This file checks local mathematics over an arbitrary carrier.  `ProbeInstance`
is one particular schema instance, not an axiom for all carrier functions.
The two instances needed for the bootstrap, and the shifted latch instance
needed for induction, are explicit hypotheses.  Formation of the source
term language, the primitive-recursion compiler, and first-order proof
translations are proved in the accompanying paper, not in this file.
-/

universe u v

namespace ProbeConstancy

structure Operations (Carrier : Type u) where
  zero : Carrier
  succ : Carrier → Carrier
  pred : Carrier → Carrier
  eqb : Carrier → Carrier → Carrier
  select : Carrier → Carrier → Carrier → Carrier

def Operations.one {Carrier : Type u} (ops : Operations Carrier) : Carrier :=
  ops.succ ops.zero

structure Computation {Carrier : Type u} (ops : Operations Carrier) : Prop where
  pred_zero : ops.pred ops.zero = ops.zero
  pred_succ : ∀ x, ops.pred (ops.succ x) = x
  eq_zero_zero : ops.eqb ops.zero ops.zero = ops.one
  eq_zero_succ : ∀ y, ops.eqb ops.zero (ops.succ y) = ops.zero
  eq_succ_zero : ∀ x, ops.eqb (ops.succ x) ops.zero = ops.zero
  eq_succ_succ : ∀ x y, ops.eqb (ops.succ x) (ops.succ y) = ops.eqb x y
  select_zero : ∀ x y, ops.select ops.zero x y = x
  select_succ : ∀ n x y, ops.select (ops.succ n) x y = y

def ProbeInstance {Carrier : Type u} (ops : Operations Carrier)
    (termValue : Carrier → Carrier) (probe : Carrier) : Prop :=
  (∀ n, termValue (ops.succ n) = termValue n) →
    ∀ n, termValue n = probe ∨ ops.eqb (termValue ops.zero) probe = ops.zero

structure BootstrapInstances {Carrier : Type u} (ops : Operations Carrier) : Prop where
  constant : ∀ x a, ProbeInstance ops (fun _ => x) a
  diagonal : ProbeInstance ops (fun n => ops.eqb n n) ops.one

section Bootstrap

variable {Carrier : Type u} (ops : Operations Carrier)
variable (comp : Computation ops) (separation : ops.zero ≠ ops.one)
variable (instances : BootstrapInstances ops)

include separation in
theorem one_ne_zero : ops.one ≠ ops.zero := by
  intro equality
  exact separation equality.symm

include comp in
theorem succ_injective {x y : Carrier}
    (equality : ops.succ x = ops.succ y) : x = y := by
  have image := congrArg ops.pred equality
  exact (comp.pred_succ x).symm.trans (image.trans (comp.pred_succ y))

include comp separation in
theorem succ_ne_zero (x : Carrier) : ops.succ x ≠ ops.zero := by
  intro equality
  have image := congrArg ops.pred equality
  have x_zero : x = ops.zero :=
    (comp.pred_succ x).symm.trans (image.trans comp.pred_zero)
  have one_zero : ops.one = ops.zero := by
    rw [x_zero] at equality
    exact equality
  exact separation one_zero.symm

include instances in
theorem off_diagonal (x y : Carrier) :
    x = y ∨ ops.eqb x y = ops.zero := by
  exact instances.constant x y (fun _ => rfl) ops.zero

include comp separation instances in
theorem diagonal (x : Carrier) : ops.eqb x x = ops.one := by
  have one_one : ops.eqb ops.one ops.one = ops.one :=
    (comp.eq_succ_succ ops.zero ops.zero).trans comp.eq_zero_zero
  have alternative := instances.diagonal (fun n => comp.eq_succ_succ n n) x
  cases alternative with
  | inl equality => exact equality
  | inr zero_value =>
    have one_zero : ops.one = ops.zero := by
      change ops.eqb (ops.eqb ops.zero ops.zero) ops.one = ops.zero at zero_value
      rw [comp.eq_zero_zero, one_one] at zero_value
      exact zero_value
    exact False.elim (separation one_zero.symm)

include comp separation instances in
theorem equality_bit (x y : Carrier) :
    ops.eqb x y = ops.zero ∨ ops.eqb x y = ops.one := by
  cases off_diagonal ops instances x y with
  | inl equality =>
    apply Or.inr
    cases equality
    exact diagonal ops comp separation instances x
  | inr zero_value => exact Or.inl zero_value

include comp separation instances in
theorem equality_iff_one (x y : Carrier) :
    x = y ↔ ops.eqb x y = ops.one := by
  constructor
  · intro equality
    cases equality
    exact diagonal ops comp separation instances x
  · intro one_value
    cases off_diagonal ops instances x y with
    | inl equality => exact equality
    | inr zero_value =>
      exact False.elim (separation (zero_value.symm.trans one_value))

include comp separation instances in
theorem disequality_iff_zero (x y : Carrier) :
    x ≠ y ↔ ops.eqb x y = ops.zero := by
  constructor
  · intro disequality
    cases off_diagonal ops instances x y with
    | inl equality => exact False.elim (disequality equality)
    | inr zero_value => exact zero_value
  · intro zero_value equality
    have one_value := (equality_iff_one ops comp separation instances x y).mp equality
    exact separation (zero_value.symm.trans one_value)

include comp separation instances in
theorem equality_decidable (x y : Carrier) : x = y ∨ x ≠ y := by
  cases off_diagonal ops instances x y with
  | inl equality => exact Or.inl equality
  | inr zero_value =>
    exact Or.inr ((disequality_iff_zero ops comp separation instances x y).mpr zero_value)

include comp separation instances in
theorem contextual_constancy (termValue : Carrier → Carrier)
    (probeInstance : ProbeInstance ops termValue (termValue ops.zero))
    (stationary : ∀ n, termValue (ops.succ n) = termValue n) :
    ∀ n, termValue n = termValue ops.zero := by
  intro n
  cases probeInstance stationary n with
  | inl equality => exact equality
  | inr zero_value =>
    have one_value := diagonal ops comp separation instances (termValue ops.zero)
    exact False.elim (separation (zero_value.symm.trans one_value))

end Bootstrap

/- `Term` is an abstract type of atom labels, interpreted at a valuation.
The recursive datatype below checks the full propositional formula compiler.
It does not itself implement the PR descriptor grammar. -/
inductive Formula (Term : Type v) where
  | equal : Term → Term → Formula Term
  | falsum : Formula Term
  | verum : Formula Term
  | conjunction : Formula Term → Formula Term → Formula Term
  | disjunction : Formula Term → Formula Term → Formula Term
  | implication : Formula Term → Formula Term → Formula Term

def Formula.holds {Carrier : Type u} {Term : Type v}
    (valuation : Term → Carrier) : Formula Term → Prop
  | .equal left right => valuation left = valuation right
  | .falsum => False
  | .verum => True
  | .conjunction left right => left.holds valuation ∧ right.holds valuation
  | .disjunction left right => left.holds valuation ∨ right.holds valuation
  | .implication left right => left.holds valuation → right.holds valuation

def Formula.bit {Carrier : Type u} {Term : Type v} (ops : Operations Carrier)
    (valuation : Term → Carrier) : Formula Term → Carrier
  | .equal left right => ops.eqb (valuation left) (valuation right)
  | .falsum => ops.zero
  | .verum => ops.one
  | .conjunction left right =>
      ops.select (left.bit ops valuation) ops.zero (right.bit ops valuation)
  | .disjunction left right =>
      ops.select (left.bit ops valuation) (right.bit ops valuation) ops.one
  | .implication left right =>
      ops.select (left.bit ops valuation) ops.one (right.bit ops valuation)

def CorrectBit {Carrier : Type u} (ops : Operations Carrier)
    (statement : Prop) (value : Carrier) : Prop :=
  (value = ops.zero ∨ value = ops.one) ∧ (statement ↔ value = ops.one)

section Compiler

variable {Carrier : Type u} (ops : Operations Carrier)
variable (comp : Computation ops) (separation : ops.zero ≠ ops.one)

theorem correct_of_value {statement : Prop} {left right : Carrier}
    (equality : left = right) (correct : CorrectBit ops statement right) :
    CorrectBit ops statement left := by
  cases equality
  exact correct

theorem correct_of_iff {left right : Prop} {value : Carrier}
    (equivalent : left ↔ right) (correct : CorrectBit ops right value) :
    CorrectBit ops left value :=
  ⟨correct.1, equivalent.trans correct.2⟩

theorem correct_one {statement : Prop} (proof : statement) :
    CorrectBit ops statement ops.one := by
  constructor
  · exact Or.inr rfl
  · exact ⟨fun _ => rfl, fun _ => proof⟩

include separation in
theorem correct_zero {statement : Prop} (refutation : ¬ statement) :
    CorrectBit ops statement ops.zero := by
  constructor
  · exact Or.inl rfl
  · constructor
    · intro proof
      exact False.elim (refutation proof)
    · intro equality
      exact False.elim (separation equality)

include separation in
theorem refute_of_zero {statement : Prop} {value : Carrier}
    (correct : CorrectBit ops statement value) (zero_value : value = ops.zero) :
    ¬ statement := by
  intro proof
  exact separation (zero_value.symm.trans (correct.2.mp proof))

include comp separation in
theorem correct_conjunction {left right : Prop} {x y : Carrier}
    (left_correct : CorrectBit ops left x) (right_correct : CorrectBit ops right y) :
    CorrectBit ops (left ∧ right) (ops.select x ops.zero y) := by
  cases left_correct.1 with
  | inl zero_value =>
    have output : ops.select x ops.zero y = ops.zero := by
      rw [zero_value, comp.select_zero]
    apply correct_of_value ops output
    apply correct_zero ops separation
    intro pair
    exact refute_of_zero ops separation left_correct zero_value pair.1
  | inr one_value =>
    have output : ops.select x ops.zero y = y := by
      rw [one_value]
      exact comp.select_succ ops.zero ops.zero y
    apply correct_of_value ops output
    apply correct_of_iff ops _ right_correct
    exact ⟨fun pair => pair.2, fun proof => ⟨left_correct.2.mpr one_value, proof⟩⟩

include comp separation in
theorem correct_disjunction {left right : Prop} {x y : Carrier}
    (left_correct : CorrectBit ops left x) (right_correct : CorrectBit ops right y) :
    CorrectBit ops (left ∨ right) (ops.select x y ops.one) := by
  cases left_correct.1 with
  | inl zero_value =>
    have output : ops.select x y ops.one = y := by
      rw [zero_value, comp.select_zero]
    apply correct_of_value ops output
    apply correct_of_iff ops _ right_correct
    constructor
    · intro choice
      cases choice with
      | inl proof =>
        exact False.elim (refute_of_zero ops separation left_correct zero_value proof)
      | inr proof => exact proof
    · exact Or.inr
  | inr one_value =>
    have output : ops.select x y ops.one = ops.one := by
      rw [one_value]
      exact comp.select_succ ops.zero y ops.one
    apply correct_of_value ops output
    exact correct_one ops (Or.inl (left_correct.2.mpr one_value))

include comp separation in
theorem correct_implication {left right : Prop} {x y : Carrier}
    (left_correct : CorrectBit ops left x) (right_correct : CorrectBit ops right y) :
    CorrectBit ops (left → right) (ops.select x ops.one y) := by
  cases left_correct.1 with
  | inl zero_value =>
    have output : ops.select x ops.one y = ops.one := by
      rw [zero_value, comp.select_zero]
    apply correct_of_value ops output
    apply correct_one ops
    intro proof
    exact False.elim (refute_of_zero ops separation left_correct zero_value proof)
  | inr one_value =>
    have output : ops.select x ops.one y = y := by
      rw [one_value]
      exact comp.select_succ ops.zero ops.one y
    apply correct_of_value ops output
    apply correct_of_iff ops _ right_correct
    exact ⟨fun implication => implication (left_correct.2.mpr one_value),
      fun proof _ => proof⟩

variable (instances : BootstrapInstances ops)

include comp separation instances in
theorem bit_correct {Term : Type v} (valuation : Term → Carrier)
    (formula : Formula Term) :
    CorrectBit ops (formula.holds valuation) (formula.bit ops valuation) := by
  induction formula with
  | equal left right =>
    exact ⟨equality_bit ops comp separation instances (valuation left) (valuation right),
      equality_iff_one ops comp separation instances (valuation left) (valuation right)⟩
  | falsum => exact correct_zero ops separation (fun proof => proof)
  | verum => exact correct_one ops True.intro
  | conjunction left right left_induction right_induction =>
    exact correct_conjunction ops comp separation left_induction right_induction
  | disjunction left right left_induction right_induction =>
    exact correct_disjunction ops comp separation left_induction right_induction
  | implication left right left_induction right_induction =>
    exact correct_implication ops comp separation left_induction right_induction

include comp separation instances in
theorem false_iff_bit_zero {Term : Type v} (valuation : Term → Carrier)
    (formula : Formula Term) :
    ¬ formula.holds valuation ↔ formula.bit ops valuation = ops.zero := by
  have correct := bit_correct ops comp separation instances valuation formula
  constructor
  · intro refutation
    cases correct.1 with
    | inl zero_value => exact zero_value
    | inr one_value => exact False.elim (refutation (correct.2.mpr one_value))
  · intro zero_value
    exact refute_of_zero ops separation correct zero_value

end Compiler

section Induction

variable {Carrier : Type u} (ops : Operations Carrier)
variable (comp : Computation ops) (separation : ops.zero ≠ ops.one)
variable (instances : BootstrapInstances ops)

include comp in
theorem select_zero_zero (value : Carrier)
    (is_bit : value = ops.zero ∨ value = ops.one) :
    ops.select value ops.zero ops.zero = ops.zero := by
  cases is_bit with
  | inl zero_value =>
    rw [zero_value]
    exact comp.select_zero ops.zero ops.zero
  | inr one_value =>
    rw [one_value]
    exact comp.select_succ ops.zero ops.zero ops.zero

include comp separation instances in
theorem quantifier_free_induction {Term : Type v}
    (formula : Formula Term) (valuation : Carrier → Term → Carrier)
    (runningTest : Carrier → Carrier)
    (test_zero : runningTest ops.zero = ops.one)
    (test_succ : ∀ n, runningTest (ops.succ n) =
      ops.select (formula.bit ops (valuation n)) ops.zero (runningTest n))
    (shifted_probe : ProbeInstance ops
      (fun n => runningTest (ops.succ n)) (runningTest (ops.succ ops.zero)))
    (base : formula.holds (valuation ops.zero))
    (progress : ∀ n, formula.holds (valuation n) →
      formula.holds (valuation (ops.succ n))) :
    ∀ n, formula.holds (valuation n) := by
  have correct (n : Carrier) :=
    bit_correct ops comp separation instances (valuation n) formula
  have base_bit : formula.bit ops (valuation ops.zero) = ops.one :=
    (correct ops.zero).2.mp base
  have bit_progress (n : Carrier)
      (one_value : formula.bit ops (valuation n) = ops.one) :
      formula.bit ops (valuation (ops.succ n)) = ops.one :=
    (correct (ops.succ n)).2.mp (progress n ((correct n).2.mpr one_value))
  have shifted_zero : runningTest (ops.succ ops.zero) = ops.one := by
    rw [test_succ ops.zero, base_bit]
    exact (comp.select_succ ops.zero ops.zero (runningTest ops.zero)).trans test_zero
  have stationary (n : Carrier) :
      runningTest (ops.succ (ops.succ n)) = runningTest (ops.succ n) := by
    cases (correct n).1 with
    | inl zero_value =>
      have next_zero : runningTest (ops.succ n) = ops.zero := by
        rw [test_succ n, zero_value]
        exact comp.select_zero ops.zero (runningTest n)
      calc
        runningTest (ops.succ (ops.succ n)) =
            ops.select (formula.bit ops (valuation (ops.succ n))) ops.zero
              (runningTest (ops.succ n)) := test_succ (ops.succ n)
        _ = ops.select (formula.bit ops (valuation (ops.succ n)))
              ops.zero ops.zero := congrArg
                (ops.select (formula.bit ops (valuation (ops.succ n))) ops.zero) next_zero
        _ = ops.zero := select_zero_zero ops comp _ (correct (ops.succ n)).1
        _ = runningTest (ops.succ n) := next_zero.symm
    | inr one_value =>
      rw [test_succ (ops.succ n), bit_progress n one_value]
      exact comp.select_succ ops.zero ops.zero (runningTest (ops.succ n))
  have constant := contextual_constancy ops comp separation instances
    (fun n => runningTest (ops.succ n)) shifted_probe stationary
  intro n
  have next_one : runningTest (ops.succ n) = ops.one :=
    (constant n).trans shifted_zero
  apply (correct n).2.mpr
  cases (correct n).1 with
  | inl zero_value =>
    have next_zero : runningTest (ops.succ n) = ops.zero := by
      rw [test_succ n, zero_value]
      exact comp.select_zero ops.zero (runningTest n)
    exact False.elim (separation (next_zero.symm.trans next_one))
  | inr one_value => exact one_value

end Induction

#print axioms diagonal
#print axioms equality_decidable
#print axioms contextual_constancy
#print axioms bit_correct
#print axioms false_iff_bit_zero
#print axioms quantifier_free_induction

end ProbeConstancy
