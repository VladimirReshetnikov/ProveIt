CONSTRUCTIVE LEAN KERNEL
=======================

File: ProbeConstancy.lean
Compiler checked: Lean 4.19.0. No Mathlib or other package is required.

Reproduce from this directory:

    lean ProbeConstancy.lean

The complete compiler output is recorded in check.log, and the exact
compiler identification is recorded in lean-version.txt.

WHAT IS VERIFIED

The proof works over an arbitrary carrier with explicitly supplied operations.
Its assumptions are theorem parameters, not global axioms:

1. The predecessor equations, four comparison corner equations, and selector
   equations collected in Computation.
2. Ground separation, zero != successor(zero).
3. The constant and diagonal instances of the stationary probe schema,
   collected in BootstrapInstances.
4. For contextual_constancy, the one probe instance for the term being used.
5. For quantifier_free_induction, the equations of its chosen running test and
   the one probe instance for its shifted observer.

From these hypotheses Lean verifies successor injectivity and nonzeroness,
the comparison diagonal, exact equality and disequality bits, propositional
decidability of native equality, and contextual term constancy. It then
verifies the recursive compiler for every finite quantifier-free formula
constructed from equality atoms, false, true, conjunction, disjunction, and
implication. Negation is implication to false.

The endpoint quantifier_free_induction proves the full base-and-progress
induction implication for the interpreted formula, using the running test.
Fixed arithmetic parameters can be included in the valuation of atom labels.
No unproved range assertion about the running test is assumed.

EXACT SCOPE LIMITS

ProbeInstance denotes one specific formula instance. The certificate does
NOT postulate a schema for all functions on the carrier. In particular,
contextual_constancy and quantifier_free_induction require the exact instances
they use as explicit hypotheses. In the source theory these are instances for
finite terms; their syntactic admissibility is proved in the paper.

Formula is a finite recursive syntax for the propositional layer. Its atom
labels have an abstract type Term and are interpreted by a supplied valuation.
The file does NOT formalize the primitive-recursive description grammar,
term formation, parameter substitution, first-order deduction, the reverse
compiler into ordinary primitive recursion, or the bi-interpretation
metatheorem. Those components have written proofs in the paper. Thus this is
a checked local constructive kernel, not a machine-checked formalization of
the entire first-order equivalence theorem.

The theorem equality_decidable establishes x=y OR x!=y in Prop. It does not
claim to extract a computational Lean DecidableEq instance from an arbitrary
propositional disjunction.

LOGICAL DEPENDENCIES

The file imports only Init and uses no global axiom declarations, sorry,
admit, Classical choice, propositional extensionality, or quotient principles.
The six printed endpoints all report that they do not depend on any axioms:

    diagonal
    equality_decidable
    contextual_constancy
    bit_correct
    false_iff_bit_zero
    quantifier_free_induction

This output means the results are kernel-checked proofs from their explicit
hypotheses. It does not mean that the mathematical assumptions above have
disappeared or that the source theory itself has no nonlogical axioms.
