/-
A linear diagonal arithmetic schema: constructive core certificate.
Lean 4.19.0; no imports or external packages.

This certificate refines the kernel of ReflexiveBasePRA.lean in
pra_reflexive_base_2026-10-31.zip, ProveIt commit
66372d99e4f4e1d3a48822b9d322ae9e9ae7e7e3. Its term syntax and the delayed
equation-induction context are adapted from that certificate. The new
selector uses initialized predecessor directly. Three fixed linear diagonal
contexts provide separation, zero decisions, and constructor coverage. The
schema requires exactly one occurrence of its first distinguished variable in
the expanded application tree. Addition and subtraction are absent from the
entire bootstrap.

The arithmetic carrier is arbitrary. Induction below is only structural
induction on finite syntax; no induction principle on the carrier is supplied
by Lean. The four displayed computation equations are explicit hypotheses,
as is the new one-term linear diagonal schema. Other binary symbols may have any
interpretations, so the result applies to every further language expansion.

Scope: first-variable occurrence counts; literal diagonal boundaries; separation;
zero decision; the new selector; constructor coverage; successor laws;
all one-parameter equation-induction instances; and the converse diagonal
instance from its usual quantifier-free induction instance. The zero-occurrence
variant is proved equivalent to separation alone. This is not a
formalization of the whole first-order derivation calculus, comparator, tuple
coding, or definitional-equivalence theorem. The manuscript states the exact
axiom-family comparison.
-/

namespace DiagonalPRA

universe u

inductive Fn where
  | predecessor
  | gate
  | other (index : Nat)

inductive Term where
  | first
  | second
  | parameter
  | zero
  | succ (argument : Term)
  | app (function : Fn) (left right : Term)

def firstCount : Term → Nat
  | .first => 1
  | .second | .parameter | .zero => 0
  | .succ t => firstCount t
  | .app _ s t => firstCount s + firstCount t

def instantiate : Term → Term → Term → Term → Term
  | .first, x, _, _ => x
  | .second, _, y, _ => y
  | .parameter, _, _, a => a
  | .zero, _, _, _ => .zero
  | .succ t, x, y, a => .succ (instantiate t x y a)
  | .app f s t, x, y, a =>
      .app f (instantiate s x y a) (instantiate t x y a)

theorem instantiate_no_first (t x y a : Term)
    (hx : firstCount x = 0) (hy : firstCount y = 0) (ha : firstCount a = 0) :
    firstCount (instantiate t x y a) = 0 := by
  induction t with
  | first => exact hx
  | second => exact hy
  | parameter => exact ha
  | zero => rfl
  | succ t ih => exact ih
  | app f s t ihs iht =>
      change firstCount (instantiate s x y a) + firstCount (instantiate t x y a) = 0
      rw [ihs, iht]

def one : Term := .succ .zero
def predTerm (t : Term) : Term := .app .predecessor t .zero
def gateTerm (s t : Term) : Term := .app .gate s t
def selectorTerm (z v w : Term) : Term :=
  .app .predecessor (gateTerm z (.succ v)) w

def diagonalLeft (h : Term) : Term := instantiate h .first .first .parameter
def diagonalRight (h : Term) : Term := instantiate h one .first .parameter
def boundary (t : Term) : Term := instantiate t one .zero .parameter

theorem instantiate_comp (t x y a z w b : Term) :
    instantiate (instantiate t x y a) z w b =
      instantiate t (instantiate x z w b) (instantiate y z w b)
        (instantiate a z w b) := by
  induction t with
  | first | second | parameter | zero => rfl
  | succ t ih => exact congrArg Term.succ ih
  | app f s t ihs iht =>
      have q := congr (congrArg (Term.app f) ihs) iht
      exact q

theorem boundary_reflexive (h : Term) :
    boundary (diagonalLeft h) = boundary (diagonalRight h) := by
  unfold boundary diagonalLeft diagonalRight
  rw [instantiate_comp, instantiate_comp]
  rfl

structure Arithmetic (A : Type u) where
  zero : A
  succ : A → A
  function : Fn → A → A → A
  predecessor_zero : ∀ a, function .predecessor zero a = a
  predecessor_succ : ∀ n a, function .predecessor (succ n) a = n
  gate_zero : ∀ a, function .gate zero a = a
  gate_succ : ∀ n a, function .gate (succ n) a = zero

def pred {A : Type u} (C : Arithmetic A) (x : A) : A :=
  C.function .predecessor x C.zero
def gate {A : Type u} (C : Arithmetic A) : A → A → A := C.function .gate
def select {A : Type u} (C : Arithmetic A) (z v w : A) : A :=
  C.function .predecessor (gate C z (C.succ v)) w

def eval {A : Type u} (C : Arithmetic A) : Term → A → A → A → A
  | .first, x, _, _ => x
  | .second, _, y, _ => y
  | .parameter, _, _, a => a
  | .zero, _, _, _ => C.zero
  | .succ t, x, y, a => C.succ (eval C t x y a)
  | .app f s t, x, y, a =>
      C.function f (eval C s x y a) (eval C t x y a)

def value {A : Type u} (C : Arithmetic A) (t : Term) (n a : A) : A :=
  eval C t n C.zero a

variable {A : Type u} (C : Arithmetic A)

theorem eval_instantiate (t x y b : Term) (n m a : A) :
    eval C (instantiate t x y b) n m a =
      eval C t (eval C x n m a) (eval C y n m a) (eval C b n m a) := by
  induction t with
  | first | second | parameter | zero => rfl
  | succ t ih => exact congrArg C.succ ih
  | app f s t ihs iht =>
      have q := congr (congrArg (C.function f) ihs) iht
      exact q

theorem eval_no_first (t : Term) (x x' y a : A) :
    firstCount t = 0 → eval C t x y a = eval C t x' y a := by
  induction t with
  | first => intro bad; cases bad
  | second | parameter | zero => intro _; rfl
  | succ t ih => intro ht; exact congrArg C.succ (ih ht)
  | app f s t ihs iht =>
      intro ht
      have hs := Nat.eq_zero_of_add_eq_zero_right ht
      have ht' := Nat.eq_zero_of_add_eq_zero_left ht
      have q := congr (congrArg (C.function f) (ihs hs)) (iht ht')
      exact q

theorem pred_zero : pred C C.zero = C.zero := C.predecessor_zero C.zero
theorem pred_succ (x : A) : pred C (C.succ x) = x := C.predecessor_succ x C.zero
theorem gate_zero (x : A) : gate C C.zero x = x := C.gate_zero x
theorem gate_succ (x y : A) : gate C (C.succ x) y = C.zero := C.gate_succ x y

def Diagonal (h : Term) (n a : A) : Prop :=
  eval C h n n a = eval C h (C.succ C.zero) n a

def LinearDiagonalSchema : Prop :=
  ∀ h, firstCount h = 1 → ∀ a, (∀ n, Diagonal C h n a → Diagonal C h (C.succ n) a) →
    C.zero ≠ C.succ C.zero ∧ ∀ n, n = C.zero ∨ Diagonal C h n a

def gateContext : Term := gateTerm .first .parameter
def classificationContext : Term := gateTerm (predTerm .second) .first
def coverageContext : Term :=
  selectorTerm (predTerm .first) .second (.succ (predTerm .second))
def equationContext (s t : Term) : Term :=
  selectorTerm (predTerm .first)
    (instantiate t (predTerm .second) .zero .parameter)
    (instantiate s (predTerm .second) .zero .parameter)

theorem equation_context_count (s t : Term) : firstCount (equationContext s t) = 1 := by
  have hs := instantiate_no_first s (predTerm .second) .zero .parameter rfl rfl rfl
  have ht := instantiate_no_first t (predTerm .second) .zero .parameter rfl rfl rfl
  change (1 + firstCount (instantiate t (predTerm .second) .zero .parameter)) +
    firstCount (instantiate s (predTerm .second) .zero .parameter) = 1
  rw [hs, ht]

theorem select_zero (v w : A) : select C C.zero v w = v := by
  unfold select
  rw [gate_zero C, C.predecessor_succ]

theorem select_succ (z v w : A) : select C (C.succ z) v w = w := by
  unfold select
  rw [gate_succ C, C.predecessor_zero]

theorem eval_selector (z v w : Term) (x y a : A) :
    eval C (selectorTerm z v w) x y a =
      select C (eval C z x y a) (eval C v x y a) (eval C w x y a) := rfl

variable (H : LinearDiagonalSchema C)
include H

theorem separation_and_gate (a : A) :
    C.zero ≠ C.succ C.zero ∧ ∀ n, n = C.zero ∨ gate C n a = C.zero := by
  have h := H gateContext (by rfl) a (by
    intro n _
    change gate C (C.succ n) a = gate C (C.succ C.zero) a
    rw [gate_succ C, gate_succ C])
  refine ⟨h.1, ?_⟩
  intro n
  rcases h.2 n with hz | he
  · exact Or.inl hz
  · change gate C n a = gate C (C.succ C.zero) a at he
    rw [gate_succ C] at he
    exact Or.inr he

theorem separation : C.zero ≠ C.succ C.zero :=
  (separation_and_gate C H C.zero).1

theorem zero_decision (x : A) : x = C.zero ∨ x ≠ C.zero := by
  rcases (separation_and_gate C H (C.succ C.zero)).2 x with hz | hg
  · exact Or.inl hz
  · apply Or.inr
    intro hz
    rw [hz, gate_zero C] at hg
    exact separation C H hg.symm

theorem select_nonzero {z : A} (hz : z ≠ C.zero) (v w : A) :
    select C z v w = w := by
  rcases (separation_and_gate C H (C.succ v)).2 z with bad | hg
  · exact False.elim (hz bad)
  · unfold select
    rw [hg, C.predecessor_zero]

theorem select_self (z v : A) : select C z v v = v := by
  rcases zero_decision C H z with hz | hz
  · rw [hz, select_zero C]
  · exact select_nonzero C H hz v v

theorem gate_nonzero {x : A} (hx : x ≠ C.zero) (a : A) :
    gate C x a = C.zero := by
  rcases (separation_and_gate C H a).2 x with bad | good
  · exact False.elim (hx bad)
  · exact good

theorem root_classification (x : A) (hx : pred C x = C.zero) :
    x = C.zero ∨ x = C.succ C.zero := by
  have h := H classificationContext (by rfl) C.zero (by
    intro n _
    change gate C (pred C (C.succ n)) (C.succ n) =
      gate C (pred C (C.succ n)) (C.succ C.zero)
    rw [pred_succ C]
    rcases zero_decision C H n with hz | hz
    · rw [hz]
    · rw [gate_nonzero C H hz, gate_nonzero C H hz])
  rcases h.2 x with hz | he
  · exact Or.inl hz
  · change gate C (pred C x) x = gate C (pred C x) (C.succ C.zero) at he
    rw [hx, gate_zero C, gate_zero C] at he
    exact Or.inr he

omit H in
theorem coverage_context_iff (x a : A) :
    Diagonal C coverageContext x a ↔
      select C (pred C x) x (C.succ (pred C x)) = x := by
  unfold Diagonal coverageContext
  rw [eval_selector C, eval_selector C]
  change select C (pred C x) x (C.succ (pred C x)) =
    select C (pred C (C.succ C.zero)) x (C.succ (pred C x)) ↔ _
  rw [pred_succ C, select_zero C]

theorem coverage (x : A) : x = C.zero ∨ x = C.succ (pred C x) := by
  have h := H coverageContext (by rfl) C.zero (by
    intro n _
    apply (coverage_context_iff C (C.succ n) C.zero).2
    rw [pred_succ C, select_self C H])
  rcases h.2 x with hz | he
  · exact Or.inl hz
  · rcases zero_decision C H (pred C x) with hp | hp
    · rcases root_classification C H x hp with hz | ho
      · exact Or.inl hz
      · apply Or.inr
        rw [ho, pred_succ C]
    · have hc := (coverage_context_iff C x C.zero).1 he
      rw [select_nonzero C H hp] at hc
      exact Or.inr hc.symm

omit H in
theorem successor_injective {x y : A} (h : C.succ x = C.succ y) : x = y := by
  have hp := congrArg (pred C) h
  rw [pred_succ C, pred_succ C] at hp
  exact hp

theorem successor_ne_zero (x : A) : C.succ x ≠ C.zero := by
  intro bad
  have hx := congrArg (pred C) bad
  rw [pred_succ C, pred_zero C] at hx
  have hOne : C.succ C.zero = C.zero := (congrArg C.succ hx).symm.trans bad
  exact separation C H hOne.symm

omit H in
theorem eval_equation_context (s t : Term) (x y a : A) :
    eval C (equationContext s t) x y a =
      select C (pred C x) (value C t (pred C y) a) (value C s (pred C y) a) := by
  unfold equationContext
  rw [eval_selector C, eval_instantiate C, eval_instantiate C]
  rfl

theorem equation_context_iff (s t : Term) (a : A)
    (base : value C s C.zero a = value C t C.zero a) (n : A) :
    Diagonal C (equationContext s t) n a ↔
      value C s (pred C n) a = value C t (pred C n) a := by
  unfold Diagonal
  rw [eval_equation_context C, eval_equation_context C, pred_succ C, select_zero C]
  rcases zero_decision C H (pred C n) with hz | hz
  · rw [hz, select_zero C]
    exact ⟨fun _ => base, fun _ => rfl⟩
  · rw [select_nonzero C H hz]

theorem equation_induction (s t : Term) (a : A)
    (base : value C s C.zero a = value C t C.zero a)
    (step : ∀ n, value C s n a = value C t n a →
      value C s (C.succ n) a = value C t (C.succ n) a) :
    ∀ n, value C s n a = value C t n a := by
  have hs := H (equationContext s t) (equation_context_count s t) a (by
    intro n hn
    have he := (equation_context_iff C H s t a base n).1 hn
    apply (equation_context_iff C H s t a base (C.succ n)).2
    rw [pred_succ C]
    rcases coverage C H n with hz | hnSucc
    · rw [hz]
      exact base
    · rw [hnSucc] at he ⊢
      rw [pred_succ C] at he
      exact step (pred C n) he)
  intro n
  rcases hs.2 (C.succ n) with bad | good
  · exact False.elim (successor_ne_zero C H n bad)
  · have he := (equation_context_iff C H s t a base (C.succ n)).1 good
    rw [pred_succ C] at he
    exact he

omit H in
def GuardedDiagonalInduction (h : Term) (a : A) : Prop :=
  (C.zero = C.zero ∨ Diagonal C h C.zero a) →
  (∀ n, (n = C.zero ∨ Diagonal C h n a) →
    (C.succ n = C.zero ∨ Diagonal C h (C.succ n) a)) →
  ∀ n, n = C.zero ∨ Diagonal C h n a

omit H in
theorem reverse_instance (h : Term) (a : A)
    (sep : C.zero ≠ C.succ C.zero)
    (ind : GuardedDiagonalInduction C h a)
    (step : ∀ n, Diagonal C h n a → Diagonal C h (C.succ n) a) :
    C.zero ≠ C.succ C.zero ∧ ∀ n, n = C.zero ∨ Diagonal C h n a := by
  refine ⟨sep, ind (Or.inl rfl) ?_⟩
  intro n hn
  apply Or.inr
  rcases hn with hz | he
  · rw [hz]
    exact Eq.refl _
  · exact step n he

omit H in
def ZeroDiagonalSchema : Prop :=
  ∀ h, firstCount h = 0 → ∀ a,
    (∀ n, Diagonal C h n a → Diagonal C h (C.succ n) a) →
    C.zero ≠ C.succ C.zero ∧ ∀ n, n = C.zero ∨ Diagonal C h n a

omit H in
theorem zero_occurrence_schema_iff : ZeroDiagonalSchema C ↔ C.zero ≠ C.succ C.zero := by
  constructor
  · intro h
    exact (h .zero rfl C.zero (by intro n _; rfl)).1
  · intro sep h hh a _
    refine ⟨sep, ?_⟩
    intro n
    exact Or.inr (eval_no_first C h n (C.succ C.zero) n a hh)

#print axioms boundary_reflexive
#print axioms instantiate_no_first
#print axioms equation_context_count
#print axioms eval_instantiate
#print axioms eval_no_first
#print axioms separation_and_gate
#print axioms separation
#print axioms zero_decision
#print axioms select_zero
#print axioms select_succ
#print axioms select_nonzero
#print axioms select_self
#print axioms gate_nonzero
#print axioms root_classification
#print axioms coverage_context_iff
#print axioms coverage
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms equation_context_iff
#print axioms equation_induction
#print axioms reverse_instance
#print axioms zero_occurrence_schema_iff

end DiagonalPRA
