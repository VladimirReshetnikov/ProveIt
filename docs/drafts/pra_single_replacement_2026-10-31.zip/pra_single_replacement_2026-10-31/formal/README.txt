FORMAL CERTIFICATE SCOPE
========================

Compiler: Lean 4.19.0.
File: SingleReplacement.lean.
No imports, Mathlib, or external packages.

The arithmetic carrier is an arbitrary Type, not Lean's Nat.
Induction appears only in finite syntax infrastructure.

Explicit arithmetic hypotheses:
  P(0,a)=a; P(Sn,a)=n.
  B(0,a)=a; B(Sn,a)=0.
  LinearDiagonalSchema for finite terms whose first-slot count is exactly one.

The only generated functions needed in this bootstrap are initialized
predecessor and gate. Other binary function symbols have arbitrary
interpretations. This is sufficient to apply the result inside any further
primitive-recursive language expansion.

Every schema application supplies a checked count certificate.
The general delayed equation compiler has exactly one first-slot occurrence,
proved structurally even when its target terms repeat their inputs.

Checked:
  finite substitution and literal boundary reflexivity;
  substitution/evaluation compatibility;
  zero-occurrence independence and equivalence with separation;
  separation and zero decisions;
  selector laws for C(z,u,v)=P(B(z,Su),v);
  predecessor-zero classification;
  constructor coverage;
  successor injectivity and nonzeroness;
  arbitrary one-parameter equation induction for finite target terms;
  the reverse diagonal instance from ordinary guarded formula induction.

The final log has 22 printed dependency audits, all reporting no axioms.
The computation equations and schema are explicit theorem inputs.
No classical choice, propext, sorryAx, or additional global axioms are used.

Not claimed formalized:
  the complete well-founded declaration grammar;
  a first-order derivation calculus;
  native comparator reflection and the formula compiler;
  pairing, tuple coding, and general primitive-recursion translation;
  the entire conservative definitional-equivalence theorem.

Those are proved mathematically in the paper. The artifact checks the new
restricted kernel, not a theorem that silently assumes induction on its
arithmetic carrier.

Attribution for adapted finite syntax and delayed induction is retained in
the Lean header. The source comparison snapshot is recorded in the audit
manifest.
