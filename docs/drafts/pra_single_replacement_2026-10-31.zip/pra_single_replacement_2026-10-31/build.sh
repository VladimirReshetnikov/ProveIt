#!/usr/bin/env bash
set -euo pipefail
task_root="$(cd -- "$(dirname -- "$0")" && pwd)"
build_dir="$(mktemp -d)"
trap 'rm -rf -- "$build_dir"' EXIT
cd -- "$task_root"
latexmk -pdf -interaction=nonstopmode -halt-on-error \
  -outdir="$build_dir" pra_single_replacement.tex
cp -- "$build_dir/pra_single_replacement.pdf" "$task_root/pra_single_replacement.pdf"
mkdir -p "$task_root/audit"
cp -- "$build_dir/pra_single_replacement.log" "$task_root/audit/pdf_final.log"
