#!/usr/bin/env bash
set -eo pipefail
task_root="$(cd -- "$(dirname -- "$0")" && pwd)"
cd -- "$task_root"
lean_bin=lean
if [[ -n "$LEAN" ]]; then lean_bin="$LEAN"; fi
python3 artifacts/check_diagonal.py > audit/syntax_results.json
"$lean_bin" --version > audit/lean_verification.log
"$lean_bin" formal/SingleReplacement.lean >> audit/lean_verification.log
cat audit/lean_verification.log
