#!/usr/bin/env python3
"""Finite syntax certificates for the one-hole PRA schema.

The main schema requires exactly one distinguished hole.  The unrestricted
diagonal schema is included as a comparison.  This program checks literal
finite term syntax, declaration dependencies, context synthesis, and
formula-tree sizes.  It does not establish the
arithmetical equivalence theorem and does not test arithmetic numerically.

Every numeral 1 in a syntax certificate means the actual term S(0).
The alternative size column treats 1 as a named one-node constant solely
to make the dependence of size comparisons on that convention explicit.
"""

from __future__ import annotations

from dataclasses import dataclass
import json


@dataclass(frozen=True)
class Term:
    kind: str
    name: str = ""
    args: tuple["Term", ...] = ()


def var(name: str) -> Term:
    return Term("var", name)


ZERO = Term("zero")


def succ(term: Term) -> Term:
    return Term("succ", args=(term,))


ONE = succ(ZERO)


def app(name: str, *args: Term) -> Term:
    return Term("app", name, tuple(args))


def subst(term: Term, mapping: dict[str, Term]) -> Term:
    if term.kind == "var":
        return mapping.get(term.name, term)
    return Term(term.kind, term.name, tuple(subst(t, mapping) for t in term.args))


def free_vars(term: Term) -> set[str]:
    if term.kind == "var":
        return {term.name}
    result: set[str] = set()
    for arg in term.args:
        result.update(free_vars(arg))
    return result


def occurrences(term: Term, name: str) -> int:
    return int(term.kind == "var" and term.name == name) + sum(
        occurrences(arg, name) for arg in term.args
    )


def show(term: Term) -> str:
    if term.kind == "var":
        return term.name
    if term.kind == "zero":
        return "0"
    if term.kind == "named_one":
        return "1"
    if term.kind == "succ":
        return f"S({show(term.args[0])})"
    if term.kind == "app":
        return f"{term.name}({','.join(show(t) for t in term.args)})"
    raise ValueError(f"Unknown term constructor: {term.kind}")


# These are actual initialized-iterator descriptions, in declaration order.
# Their update terms contain only counter k and current state v.
DECLARATIONS = (
    ("P", var("k")),
    ("B", ZERO),
    ("A", succ(var("v"))),
)


def validate_term(term: Term, known: set[str]) -> None:
    if term.kind in {"var", "zero"}:
        assert not term.args
    elif term.kind == "succ":
        assert len(term.args) == 1
    elif term.kind == "app":
        assert term.name in known, term.name
        assert len(term.args) == 2, term
    else:
        raise AssertionError(f"Unexpected term kind: {term.kind}")
    for arg in term.args:
        validate_term(arg, known)


def declaration_certificates() -> list[dict]:
    known: set[str] = set()
    result = []
    for name, update in DECLARATIONS:
        validate_term(update, known)
        assert free_vars(update) <= {"k", "v"}
        known.add(name)
        result.append({
            "symbol": name,
            "arity": 2,
            "update": show(update),
            "update_free_variables": sorted(free_vars(update)),
            "only_earlier_symbols": True,
            "no_frozen_initial_seed": True,
        })
    return result


def pred(term: Term) -> Term:
    return app("P", term, ZERO)


def select(test: Term, left: Term, right: Term) -> Term:
    # C(z,u,v) := P(B(z,S(u)),v).  Every macro is expanded here.
    return app("P", app("B", test, succ(left)), right)


class NotSpecialization(ValueError):
    pass


def synthesize_context(source: Term, target: Term) -> tuple[Term, int]:
    """Recognize replacing selected n occurrences by literal S(0).

    The returned context H(x,y,a) marks a changed occurrence with x and
    an unchanged n occurrence with y.  Function-symbol indices are opaque:
    this algorithm never rewrites or substitutes inside their descriptions.
    """
    if not (free_vars(source) | free_vars(target)) <= {"n", "a"}:
        raise NotSpecialization("Unexpected free variable")

    def visit(left: Term, right: Term) -> tuple[Term, int]:
        if left == right:
            return subst(left, {"n": var("y")}), 0
        if left == var("n") and right == ONE:
            return var("x"), 1
        if (left.kind, left.name, len(left.args)) != (
            right.kind, right.name, len(right.args)
        ) or not left.args:
            raise NotSpecialization("Not an oriented occurrence replacement")
        children = [visit(l, r) for l, r in zip(left.args, right.args)]
        return Term(left.kind, left.name, tuple(c[0] for c in children)), sum(
            c[1] for c in children
        )

    context, changes = visit(source, target)
    assert free_vars(context) <= {"x", "y", "a"}
    assert occurrences(context, "x") == changes
    assert subst(context, {"x": var("n"), "y": var("n")}) == source
    assert subst(context, {"x": ONE, "y": var("n")}) == target
    return context, changes


def is_specialization(source: Term, target: Term, exactly_one: bool = False) -> bool:
    try:
        _, changes = synthesize_context(source, target)
        return changes == 1 if exactly_one else True
    except NotSpecialization:
        return False


def diagonal_pair(context: Term) -> tuple[Term, Term]:
    return (
        subst(context, {"x": var("n"), "y": var("n")}),
        subst(context, {"x": ONE, "y": var("n")}),
    )


def context_certificate(label: str, context: Term, expected_holes: int) -> dict:
    validate_term(context, {name for name, _ in DECLARATIONS})
    assert free_vars(context) <= {"x", "y", "a"}
    assert occurrences(context, "x") == expected_holes
    source, target = diagonal_pair(context)
    assert subst(source, {"n": ONE}) == subst(target, {"n": ONE})
    recovered, changes = synthesize_context(source, target)
    assert recovered == context
    assert changes == expected_holes
    return {
        "label": label,
        "expanded_context": show(context),
        "free_variables": sorted(free_vars(context)),
        "distinguished_hole_occurrences": changes,
        "left": show(source),
        "right": show(target),
        "literal_boundary_at_one": True,
        "synthesis_reconstructs_context": True,
        "admitted_by_one_hole_schema": changes == 1,
    }


@dataclass(frozen=True)
class Formula:
    kind: str
    args: tuple["Formula | Term", ...] = ()


def eq(left: Term, right: Term) -> Formula:
    return Formula("eq", (left, right))


def imp(left: Formula, right: Formula) -> Formula:
    return Formula("imp", (left, right))


def forall(body: Formula) -> Formula:
    # The bound-variable name is not a separate formula-tree node.
    return Formula("forall", (body,))


def count_nodes(tree: Formula | Term) -> int:
    return 1 + sum(count_nodes(arg) for arg in tree.args)


def count_equalities(tree: Formula | Term) -> int:
    return int(isinstance(tree, Formula) and tree.kind == "eq") + sum(
        count_equalities(arg) for arg in tree.args
    )


def arithmetic_formula(pattern: str, expand_one: bool) -> Formula:
    numeral_one = ONE if expand_one else Term("named_one")
    n, a = var("n"), var("a")

    def equation(index: Term) -> Formula:
        if pattern == "literal_boundary":
            return eq(app("s", index, a), app("t", index, a))
        if pattern == "swap":
            return eq(
                app("H", index, numeral_one, a),
                app("H", numeral_one, index, a),
            )
        if pattern == "diagonal":
            return eq(
                app("H", index, index, a),
                app("H", numeral_one, index, a),
            )
        raise ValueError(pattern)

    progress = forall(imp(equation(n), equation(succ(n))))
    separation = imp(eq(ZERO, numeral_one), Formula("bottom"))
    conclusion = Formula("and", (
        separation,
        forall(Formula("or", (eq(n, ZERO), equation(n)))),
    ))
    return forall(imp(progress, conclusion))


def metrics() -> dict:
    result = {}
    expected = {
        True: {"literal_boundary": 39, "swap": 51, "diagonal": 49},
        False: {"literal_boundary": 38, "swap": 44, "diagonal": 45},
    }
    for expand_one in (True, False):
        key = "one_expanded_as_S0" if expand_one else "one_named_constant"
        result[key] = {}
        for pattern in ("literal_boundary", "swap", "diagonal"):
            formula = arithmetic_formula(pattern, expand_one)
            size = count_nodes(formula)
            equalities = count_equalities(formula)
            assert size == expected[expand_one][pattern]
            assert equalities == 5
            result[key][pattern] = {"nodes": size, "equality_occurrences": equalities}
    return result


def main() -> None:
    x, y, a, n = (var(name) for name in ("x", "y", "a", "n"))
    gate = app("B", x, a)
    classification = app("B", pred(y), x)
    coverage = select(pred(x), y, succ(pred(y)))
    combined_coverage = select(pred(y), x, select(pred(x), y, succ(pred(y))))

    # Sample input terms repeat n.  They use actual previously declared
    # iterator symbols rather than opaque arbitrary-function placeholders.
    sample_s = app("P", app("B", n, succ(a)), pred(n))
    sample_t = succ(app("P", app("B", pred(n), succ(n)), app("B", a, n)))
    delayed_s = subst(sample_s, {"n": pred(y)})
    delayed_t = subst(sample_t, {"n": pred(y)})
    compiler = select(pred(x), delayed_t, delayed_s)
    zero_hole_control = select(pred(y), a, y)

    contexts = [
        context_certificate("zero_gate", gate, 1),
        context_certificate("predecessor_zero_classification", classification, 1),
        context_certificate("coverage_after_classification", coverage, 1),
        context_certificate("combined_coverage_unrestricted_diagonal", combined_coverage, 2),
        context_certificate("delayed_equation_induction_compiler", compiler, 1),
        context_certificate("zero_hole_reflexive_control", zero_hole_control, 0),
    ]
    zero_left, zero_right = diagonal_pair(zero_hole_control)
    assert zero_left == zero_right
    assert not is_specialization(zero_left, zero_right, exactly_one=True)

    # This current-draft swap is admitted by literal agreement at 1, but
    # neither orientation can be obtained by replacing only n by 1.
    left = app("A", n, ONE)
    right = app("A", ONE, n)
    assert subst(left, {"n": ONE}) == subst(right, {"n": ONE})
    assert not is_specialization(left, right)
    assert not is_specialization(right, left)

    # A two-occurrence diagonal pair separates arbitrary partial
    # specialization from the strictly smaller one-hole family.
    twice_left = app("A", n, n)
    twice_right = app("A", ONE, ONE)
    assert is_specialization(twice_left, twice_right)
    assert not is_specialization(twice_left, twice_right, exactly_one=True)
    _, twice_count = synthesize_context(twice_left, twice_right)
    assert twice_count == 2

    report = {
        "status": "all finite syntax and size assertions passed",
        "scope": [
            "Finite syntax only; no arithmetic model testing is performed.",
            "No claim that this script proves the PRA-equivalence theorem.",
            "Negation is expanded as implication to bottom in every formula size.",
            "Generated iterator indices are opaque during term substitution.",
            "The three one-hole bootstrap contexts and induction compiler each use the hole once.",
            "The one-hole admission condition is exactly one n-to-S(0) occurrence replacement.",
            "The 49-node diagonal formula has the same size with or without the one-hole restriction.",
        ],
        "metric_conventions": [
            "Each term or formula constructor contributes one node.",
            "An application contributes one node plus its argument trees.",
            "A quantifier contributes one node; its bound-variable name is not a separate node.",
            "Term placeholders s, t, and H are counted as applications, before instance substitution.",
            "The two common computation templates are excluded from arithmetic-formula sizes.",
            "All negative signs mean implication to an explicit bottom node.",
        ],
        "declarations": declaration_certificates(),
        "contexts": contexts,
        "strict_inclusion_witnesses": {
            "literal_boundary_not_partial_specialization": {
                "left": show(left),
                "right": show(right),
                "literal_agreement_at_one": True,
                "forward_specialization": False,
                "reverse_specialization": False,
            },
            "partial_specialization_not_one_hole": {
                "left": show(twice_left),
                "right": show(twice_right),
                "changed_occurrences": twice_count,
            },
            "zero_hole_control": {
                "left": show(zero_left),
                "right": show(zero_right),
                "literally_identical": True,
                "one_hole_admitted": False,
            },
        },
        "formula_metrics": metrics(),
    }
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
