# PRA from a Single Replacement

Research package prepared for Vladimir Reshetnikov, 31 October 2026.

## Result

The strongest supplied drafts allow an equation whenever its two sides
become literally identical at n=1. This report proves that it suffices
to replace **exactly one selected occurrence of n by 1**.

The equivalent diagonal equation is

    E_H(n,a) := H(n,n,a)=H(1,n,a),

where H(x,y,a) contains exactly one x. Keep the same arithmetic formula:

    forall a, [forall n, E_H(n,a) -> E_H(Sn,a)]
              -> [0!=1 and forall n, n=0 or E_H(n,a)].

The two initialized binary-iteration templates are unchanged:

    I_h(0,a)  = a
    I_h(Sn,a) = h(n,I_h(n,a)).

Updates have only counter and current state free. Every generated primitive
symbol remains binary; the arithmetic schema has one fixed numerical parameter.
Use classical or intuitionistic first-order equality logic, respectively.

The paper proves conservative definitional equivalence to ordinary PRA in
each logic. Within the specified occurrence-replacement hierarchy, one is
optimal: zero replacements give only separation, while one gives full PRA.
This is not a global shortest-axiomatization claim.

## Start here

- pra_single_replacement.pdf: the complete paper.
- axioms.txt: exact self-contained specification.
- pra_single_replacement.tex and sections/*.tex: complete editable source.

## Verification artifacts

- formal/SingleReplacement.lean: finite syntax, explicit one-occurrence
  restriction, constructive P/B bootstrap, general equation induction, and
  the zero-occurrence endpoint; no imports or external packages.
- formal/README.txt: exact assumptions and formalization boundary.
- audit/lean_verification.log: successful Lean 4.19.0 check and 22
  axiom-dependency audits.
- artifacts/check_diagonal.py: independent finite syntax, replacement,
  declaration, compiler-context, strictness, and formula-tree checks.
- audit/syntax_results.json: actual checker output.
- audit/source_manifest.json: immutable repository snapshot and source hashes.
- audit/validation.json: recorded validation scope.
- SHA256SUMS: package integrity manifest.

## Reproduce

Requires Python 3.10+, Lean 4.19.0, and a normal TeX Live installation with
pdfLaTeX/latexmk and the packages named in the LaTeX preamble.

    python3 artifacts/check_diagonal.py
    LEAN=/absolute/path/to/lean bash check.sh
    bash build.sh

If Lean is already on PATH, bash check.sh is enough for the code checks.
The build script builds in a temporary directory and copies the finished PDF
beside its source. The check script updates the two recorded verification
outputs. Verify sha256sum -c SHA256SUMS before rebuilding or modifying.

## Comparison and qualifications

At ProveIt commit 66372d99e4f4e1d3a48822b9d322ae9e9ae7e7e3, all four current
draft ZIPs were reviewed. The single-replacement family is strictly smaller
than their best literal-base family. The common arithmetic formula remains
39 AST nodes and five equality occurrences under their metric.
The one-term diagonal has 49 nodes versus transposition's 51 when 1=S0 is
expanded. That numerical advantage reverses when 1 is a primitive one-node
constant, so the main advance is the one-occurrence restriction.

The new short selector is C(z,u,v)=P(B(z,S(u)),v), where P is initialized
predecessor and B is the zero gate. It is linear in each argument and
removes addition from the induction bootstrap.

The complete first-order calculus, native equality reflection, formula
compiler, pairing, and definitional-equivalence theorem have written proofs
in the paper. The Lean file checks the new kernel and the zero-occurrence
endpoint; it does not claim a full object-theory formalization.
The Python artifact checks finite syntax and counts, not universal arithmetic
by finite numerical experiments.

The native quantifier-free classical and intuitionistic calculi agree;
their arbitrary quantified first-order theorems are not identified.
No repository commit or push was performed.
