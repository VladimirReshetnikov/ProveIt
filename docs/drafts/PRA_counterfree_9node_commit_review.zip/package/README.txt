PRA: a smaller counter-free basis and limits of further compression
Research iteration pinned to commits 5e7cbe46ea2d9e3301371a64cafe2080d7526437
and 8dc884c9db3e3a9bf1c54d6e89892b13e23f2e6a, 2026-11-01.

START HERE: report.pdf (10 pages); editable source report.tex.
Main new update: C(D(a,S(v)),S(S(v)),a), nine syntax-tree nodes.
It reduces the counter-free branch's display-plus-selected-body subtotal
63 to 60. The best reviewed counter-reading branch remains 58. These are
partial ledgers, not full theory encoding lengths; no global minimum claimed.
Both matching classical and intuitionistic theories have constructive
identity-domain bi-interpretations with PRA. The report supplies the proof
chain and expressly credits inherited compiler/uniqueness architecture.
The local nine-node lower bound is exhaustive in its stated grammar only.

BUILD PDF
A standard TeX Live installation with pdflatex, lmodern, amsmath, amssymb,
amsthm, geometry, hyperref, booktabs, array and microtype suffices:
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
No network, bibliography tool or shell escape is required.

REPLAY CHECKS (Python 3 standard library only)
  python3 replay.py
This runs the newly authored exhaustive generator and a separately authored
parser/evaluator; compares regenerated JSON with the supplied artifacts;
checks all manifest hashes; and prints the exact counts and controls.
It does not run any downloaded repository scripts. No Lean/Rocq kernel
certificate is claimed. The finite recurrence diagnostic is not a substitute
for the universal mathematical proof; the bounded syntax exhaustion is a
separate local lower-bound certificate.

CONTENTS AND PROVENANCE
artifacts/: new generator, independent verifier, 30,957 rejection witnesses,
results, and verification record. Counter-free U recurrence checked on 8,385
pairs with x+a<=128; verifier rejects missing-tree and wrong-value controls.
sources/source_review.txt: review of all eight surviving archives.
sources/source_hashes.json: eight archive SHA-256 and verified Git blob IDs.
sources/inventory*.json: pinned GitHub archive inventories.
sources/counterfree.tex, roundtrips.tex: unchanged excerpts from
  pra_counterfree_swap_2026-11-01.zip.
sources/forward.tex, interpretations.tex, local_minimality.tex: unchanged
  excerpts from pra_relative_swap_2026-11-01.zip.
These inherited TeX excerpts are evidence, not standalone compilable reports.
sources/kernel_research.md, counterfree_optimality.md,
  classical_schema_audit.txt: this iteration's research and proof notes.
MANIFEST.sha256: SHA-256 of all package files except the manifest itself.

Independent mathematical review passed the bootstrap, QFI/order/compiler,
reverse interpretation/round trips, local certificate necessity, and
parameter-free product automorphism obstruction. All ten PDF pages were
rendered and visually inspected; compilation had no overfull-box warnings.
The negative product result explicitly does not cover arbitrary externally
named-parameter interpretations. Exploratory disequality-induction results
are not asserted to axiomatize PRA.
