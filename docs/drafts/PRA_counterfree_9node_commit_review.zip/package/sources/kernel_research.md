# Counter-free selector simplification

Replace counterfree draft's selected update
U(a,v)=C(D(a,v),C(D(v,a),a,Sa),a)
by V(a,v)=C(a,0,C(D(a,v),Sa,a)).
The defining swap equations remain V(0,a)=a and V(Sn,a)=h_V(a,V(a,n)). No recursion counter is read.

## Exact saving
C and D bodies cost one node each. Old U body costs12. New V costs10: outer C1 + a1 + 0one + inner C1 + D3 + Sa2 + a1. Selected ledger14 becomes12; unchanged display49 yields subtotal61. This improves counterfree49 branch by2 but does NOT dominate latest counter-reading relative_swap50+8=58. Compare matched m=1 counts only.

## Constructive bootstrap
All counterfree proof steps retain the same equations they use. V(1,0)=0 because outer C is at zero. V(1,1)=2 since recursive V(1,0)=0 and D(1,0)=0. Hence pointed constancy at1 preserves stationary1 and successor injectivity transfers this to stationary0. The proofs D(n,n)=0 and D(n,Sn)=1 are unchanged. D(Sx,x)=D(x,x)=0 is a defining rewrite followed by the first identity. Off-classification, obtained from constant pointed instances, gives V(Sx,x)=x because Sx≠x. Then V(Sx,Sx)=h_V(Sx,x)=SSx: outer C at successor selects inner; D(Sx,x)=0 selects SSx. Equality bit D(Sy,V(Sx,Sy)) thus has exactly the same constructive proof. Latch induction, order, bounded witness construction and PR compiler are untouched.

## Reverse standard/PRA proof
D(a,v)=(v monus a)+pred(a monus v). Thus D(a,v)=0 iff a=v or a=Sv, provably in PRA with decidable order. Let target V(x,y)=Sy if x=y≠0, else y. In swap recurrence:
- a=n≠0: recursive value V(a,n)=Sn. Then D(a,Sn)=1, so update returns a.
- a=n=0: outer zero selector returns0.
- a≠n: recursive value is n. At a=0 outer selector returns0. At a≠0 the inner condition is a=n or a=Sn; first excluded, so output Sa exactly when a=Sn, otherwise a.
These are exactly target values at (Sn,a). Swap uniqueness gives identification, so existing reverse interpretation and identity roundtrip proofs apply without any standard-model-only leap.

Finite diagnostic: independently authored test_new_kernel.py checks6400 pairs x,y<80 with literal recursive definitions. Finite checking is not the all-model proof.

## Additional restriction explored
Dropping changing parameter a from update entirely still admits C and D and produces diagonal folds R(n,n)=h^(2n)(0). A square-root/phase simulation could encode arbitrary iteration, but needs internally justified phase states/pairing and equality before arithmetic bootstrap. No complete construction established. Merely deleting that argument from V is invalid.

## Why a tempting six-node counter-free update fails
h(a,v)=C(D(a,v),v,a) yields target predecessor-on-diagonal only if recursive off/diagonal cases can be distinguished. At an off-diagonal input (Sn,n), recursive value from (n,n) is pred n and D(n,pred n)=0, incorrectly returning pred n. This is a collision of recursive state, not just a proof omission. The bump target avoids this collision at the price of an explicit zero guard.

# Independent audit of improved nine-node update

The challenge worker discovered h9(a,v)=C(D(a,Sv),SSv,a). Count: C1+D1+a1+S1+v1+S1+S1+v1+a1=9. C,D selected bodies add2, giving11 selected nodes; counterfree display49 gives60, versus original63. This is better than my h10, but still not the counter-reading58.

Pure source rewrite: U(1,0)=h9(0,U(0,0))=C(D(0,1),2,0)=0 since D(0,1)=1. U(1,1)=h9(1,U(1,0))=C(D(1,1),2,1)=2, as D(1,1)=D(1,0)=D(0,0)=0. Existing pointed-constancy bootstrap gives D(n,n)=0, D(n,Sn)=1, hence no successor fixed point. Constant pointed instances yield U(Sx,x)=x. Thus U(Sx,Sx)=h9(Sx,x)=C(D(Sx,Sx),SSx,Sx)=SSx. The native equality-bit proof and all later compiler proofs remain unchanged.

Internal reverse recurrence audit for F(x,y)=Sy if x=y≠0, and y otherwise:
1. a=n>0: recursive v=F(a,n)=Sn. D(a,Sv)=D(n,SSn)=2, so update returns a, the desired off-diagonal result F(Sn,n).
2. a=n=0: v=0 and D(0,1)=1, so output0.
3. a≠n: recursive v=n. D(a,Sn)=0 iff a=Sn or a=SSn. Output SSn in both cases, which is Sa in the first (desired bump) and a in the second (desired off-diagonal). In every other case output a. All comparisons are internally decidable in PRA; this is not only a standard-model check.
The swap-recursion uniqueness theorem identifies the compiled function with F in every model. Therefore the original reverse arithmetic-axiom proof and identity roundtrips apply.

# A broader impossibility result for tempting disequality replacement

Replacing the comparator disjunct by native disequality makes pointed constancy into
St(f) -> [f(0)≠a or f(n)=a].
This provides equality decidability from constant f and ordinary constancy by taking a=f(0). Its tree cost matches the previous positive-comparator atom after negation expansion, apparently saving the comparator program. It is not adequate.

The coordinatewise product N×N satisfies the computation equations, separation and this principle classically: any stationary term function has stationary coordinate functions, which are constant on N. It fails constructor coverage at (0,1). More strongly, this is not just a same-carrier problem. The product has a nonidentity automorphism of order2 interchanging coordinates. Every model of PRA has a definable strict linear order, and an order automorphism of finite order must be the identity (a<x image or image<x creates a strict finite cycle). Parameter-free biinterpretations induce automorphism-group isomorphisms via the definable roundtrip maps. Thus this product model rules out ANY parameter-free biinterpretation with PRA, including domain changes and quotients. An intuitionistically provable biinterpretation would hold in classical models too, so is equally ruled out.

This general square-automorphism obstruction applies to other product-stable bases containing a nontrivial square; in particular a purely equational replacement cannot by itself solve the requested biinterpretability problem. It does not cover interpretations using arbitrary external parameters, nor does it prohibit adding genuinely non-product-preserved arithmetic axioms.

The same product obstruction defeats D-asymmetry pointed constancy:
St(f) -> [D(f(0),a)≠D(a,f(0)) or f(n)=a].
In N², equality of the two D terms is equivalent to tuple equality, coordinate by coordinate. Stationarity implies coordinatewise constancy. Classical excluded middle therefore verifies this whole schema in N², so the order-two obstruction still applies.

For the stronger interface restriction h(v) with no frozen parameters either, a direct bump comparator is impossible by two equations alone. R_h(1,a)=h(R_h(a,0)). A bump comparator has R_h(a,0)=0 for all a, forcing R_h(1,a)=h(0) constant, whereas desired values at a=0 and1 are0 and2. This narrow obstruction does not exclude composed terms, frozen copies of the original changing parameter, or different arithmetic axioms.
