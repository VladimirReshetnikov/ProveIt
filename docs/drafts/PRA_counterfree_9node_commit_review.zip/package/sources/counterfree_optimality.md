# A nine node counterfree comparator and its exact local minimum

## Definitions and established construction

Work over standard natural numbers for the local synthesis theorem. C(z,u,w) selects u at z=0 and w otherwise. The swap distance is D(x,y)=y-x when x<=y and x-y-1 otherwise. This follows by induction on x+y from D(0,a)=a and D(Sn,a)=D(a,n). In particular D(x,y)=0 iff x=y or x=y+1.

Choose h(a,v)=C(D(a,Sv),SSv,a), with nine nodes. Define U(0,a)=a and U(Sn,a)=h(a,U(a,n)). Then U(x,a)=Sa when x=a>0 and U(x,a)=a otherwise. Proof by induction on x+a: if n!=a, recursive U(a,n)=n and h(a,n) differs from a only when a=n+1, in which case it is a+1. Indeed D(a,n+1)=0 iff a=n+1 or a=n+2; its return n+2 equals a in the latter case. If n=a>0, the recursive value is a+1, so D(a,a+2)=2 and h returns a. If n=a=0, the recursive value is zero, D(0,1)=1 and h returns zero. This covers every successor case. The base is immediate.

For native constructive bootstrap, no standard-model inference is needed: h(0,0)=0 and h(1,0)=2 follow by finite rewriting. Thus U(1,0)=0, U(1,1)=2. The counterfree draft's relative-constancy argument then proves stationary preservation of one and zero, D(x,x)=0, D(x,Sx)=1, and Sx!=x. Its offdiagonal disjunction gives U(Sx,x)=x. Consequently U(Sx,Sx)=h(Sx,x)=C(D(Sx,Sx),SSx,Sx)=SSx. This is exactly the positive-diagonal identity used by the draft's equality bit, QFI latch, and internal compiler. No new axiom or auxiliary description is required. The rest of that draft's constructive proof may be reused with U replaced by this description. Body ledger changes from C:1,D:1,U:12 to C:1,D:1,U:9. Display49 unchanged, subtotal60 instead of63. Relative-swap's58 remains smaller overall.

## Collision obstruction

No counterfree h(a,v) can implement the predecessor-diagonal target T(x,a)=a offdiagonal and T(a,a)=a-1 for a>0. Fix a>0. T(a,a)=h(a,T(a,a-1))=h(a,a-1)=a-1. But T(a+1,a)=h(a,T(a,a))=h(a,a-1)=a-1, contradicting its required offdiagonal value a. This is independent of the term vocabulary and update-body size.

## Exact local lower bound by exhaustive finite certificate

Assume any h in grammar 0 | a | v | S(h) | D(h,h) | C(h,h,h), and its swap recursion satisfies U(x,a)=a for every x!=a and U(1,1)!=1. Then:
1. h(0,v)=0 for every v, because U(v+1,0)=h(0,U(0,v))=h(0,v).
2. h(2,0)=2 and h(3,0)=3, since U(1,a)=h(a,U(a,0))=h(a,0) for a>=2.
3. q=h(1,0)=U(1,1) differs from1. It also differs from0: if q=0, U(2,1)=h(1,U(1,1))=h(1,0)=q=0, contradicting U(2,1)=1. Therefore q>=2 in standard naturals.

Eight necessary evaluations thus suffice: (0,0),(0,1),(0,2),(0,3),(0,4),(1,0),(2,0),(3,0). The certificate enumerates every raw syntax tree through8 nodes and records a violated necessary condition for each. Counts by size are3,3,12,57,219,1038,5052,24573, total30957. These counts obey the exact grammar recurrence N1=3 and Nn=N(n-1)+sum_i N_i*N(n-1-i)+sum_(i,j,k positive,i+j+k=n-1) N_i*N_j*N_k. No semantic quotient or pruning is used.

The script counterfree_minimum_certificate.py emits counterfree_rejection_witnesses.json, one full expression, size, failed test index, and observed value per syntax tree. It verifies the nine-node update on8385 pairs with sum<=128 as a supplementary diagnostic; the all-natural proof is above. The local lower bound is a finite exhaustive computation, not a proof-assistant kernel theorem, a general minimum for axiomatizations, or a claim about richer update vocabularies/parameters.

## Further restriction omitting the changing argument

Consider R_h(0,a,b)=a and R_h(Sn,a,b)=h(b,R_h(a,n,b)). In the standard model, with b fixed and H(v)=h(b,v), expansion gives R_h(n,a,b)=H^(2n)(a-n) if n<=a, and H^(2a+1)(n-a-1) if n>a. This is proved by induction on n+a. In particular H(v)=Sv yields n+a, while H(v)=v yields D. This restriction is not obviously computationally weak: it already defines addition directly, and frozen parameters allow more than an unparameterized unary update.

There is a very narrow impossibility without frozen parameters: no comparator itself satisfying U(0,a)=a, U(Sn,a)=h(U(a,n)) can have the required offdiagonal law. Offdiagonal U(1,0)=0 forces h(0)=0, giving U(1,1)=0 and then U(2,1)=0, contrary to offdiagonal value1. This says nothing about building a comparator by a larger term, using frozen copies of a, or a different representation.

For a frozen diagonal construction U(n,a)=R_h(n,a,a), write H_a(v)=h(a,v). Offdiagonal n>a forces H_a^(2a+1)(r)=a for all r, while the required diagonal separation asks H_a^(2a)(0)!=a. The smaller offdiagonal n<a cases impose H_a^(2n)(a-n)=a. These are exact necessary standard-model synchronization conditions, not a demonstrated contradiction. They identify the next design problem; no bi-interpretability or minimality result for this further-restricted language is claimed.
