#!/usr/bin/env python3
"""Replay only this iteration's self-authored checks; Python standard library."""
import hashlib, pathlib, subprocess, sys
root = pathlib.Path(__file__).resolve().parent
outputs = sorted((root/'artifacts').glob('*.json'))
before = {p: p.read_bytes() for p in outputs}
for name in ('counterfree_minimum_certificate.py','verify_counterfree_certificate.py'):
    subprocess.run([sys.executable, str(root/'artifacts'/name)], check=True)
for p,data in before.items():
    assert p.read_bytes() == data, f'Replay changed {p.name}'
for line in (root/'MANIFEST.sha256').read_text().splitlines():
    digest, name = line.split('  ',1)
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, name
print('PASS: exact artifact replay, two negative controls, and complete package manifest')
