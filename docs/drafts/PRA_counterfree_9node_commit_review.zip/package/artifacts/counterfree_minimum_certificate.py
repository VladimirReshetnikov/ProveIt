#!/usr/bin/env python3
"""Exhaustive bounded syntax certificate, not a global axiomatization minimum."""
import json,hashlib
from functools import lru_cache
from pathlib import Path
PTS=tuple((0,v) for v in range(5))+((1,0),(2,0),(3,0))
def d(x,y): return y-x if x<=y else x-y-1
LEVELS={1:[('0',tuple(0 for _ in PTS)),('a',tuple(a for a,v in PTS)),('v',tuple(v for a,v in PTS))]}
def failed(s):
 for i in range(5):
  if s[i]!=0:return i
 if s[5]<2:return 5
 if s[6]!=2:return 6
 if s[7]!=3:return 7
 return None
rows=[];witnesses=[]
for n in range(1,9):
 if n>1:
  L=[]
  for t,s in LEVELS[n-1]:L.append(('S('+t+')',tuple(x+1 for x in s)))
  for i in range(1,n-1):
   for t,s in LEVELS[i]:
    for u,r in LEVELS[n-1-i]:L.append(('D('+t+','+u+')',tuple(d(x,y) for x,y in zip(s,r))))
  for i in range(1,n-2):
   for j in range(1,n-i-1):
    k=n-1-i-j
    for t,s in LEVELS[i]:
     for u,r in LEVELS[j]:
      for w,z in LEVELS[k]:L.append(('C('+t+','+u+','+w+')',tuple(y if x==0 else q for x,y,q in zip(s,r,z))))
  LEVELS[n]=L
 for t,s in LEVELS[n]:
  k=failed(s)
  if k is None:raise RuntimeError('Unexpected candidate '+t)
  witnesses.append([n,t,k,s[k]])
 rows.append({'nodes':n,'raw_trees':len(LEVELS[n])})
def h(a,v):return v+2 if d(a,v+1)==0 else a
@lru_cache(None)
def U(x,a):return a if x==0 else h(a,U(a,x-1))
count=0
for total in range(129):
 for x in range(total+1):
  a=total-x
  want=a+1 if x==a and x>0 else a
  if U(x,a)!=want:raise RuntimeError(('bad',x,a))
  count+=1
w=Path(__file__).with_name('counterfree_rejection_witnesses.json')
w.write_text(json.dumps(witnesses,separators=(',',':'))+'\n')
out={'grammar':'0 | a | v | S(t) | D(t,u) | C(t,u,w)','points':PTS,'necessary_conditions':'h(0,v)=0 for v<=4; h(1,0)>=2; h(2,0)=2; h(3,0)=3','counts':rows,'total_rejected':len(witnesses),'nine_node_update':'C(D(a,S(v)),S(S(v)),a)','recurrence_cases':count,'witness_sha256':hashlib.sha256(w.read_bytes()).hexdigest()}
Path(__file__).with_name('counterfree_minimum_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
