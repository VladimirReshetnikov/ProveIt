#!/usr/bin/env python3
"""Independent parser/evaluator validation of exhaustive counterfree rejection list."""
import json,re,copy
from pathlib import Path
P=Path(__file__).with_name('counterfree_rejection_witnesses.json')
PTS=[(0,v) for v in range(5)]+[(1,0),(2,0),(3,0)]
COUNTS={1:3}
for n in range(2,9):COUNTS[n]=COUNTS[n-1]+sum(COUNTS[i]*COUNTS[n-1-i] for i in range(1,n-1))+sum(COUNTS[i]*COUNTS[j]*COUNTS[n-1-i-j] for i in range(1,n-2) for j in range(1,n-i-1))
def parse(s):
 toks=re.findall(r'[0avSDC(),]',s)
 if ''.join(toks)!=s:raise ValueError('bad characters')
 pos=0
 def rec():
  nonlocal pos
  op=toks[pos];pos+=1
  if op in ('0','a','v'):return (op,)
  ar={'S':1,'D':2,'C':3}[op]
  if toks[pos]!='(':raise ValueError('missing open')
  pos+=1;args=[]
  for i in range(ar):
   args.append(rec())
   if i+1<ar:
    if toks[pos]!=',':raise ValueError('missing comma')
    pos+=1
  if toks[pos]!=')':raise ValueError('missing close')
  pos+=1;return (op,*args)
 t=rec()
 if pos!=len(toks):raise ValueError('trailing')
 return t
def size(t):return 1+sum(size(c) for c in t[1:])
def ev(t,a,v):
 o=t[0]
 if o=='0':return 0
 if o=='a':return a
 if o=='v':return v
 xs=[ev(c,a,v) for c in t[1:]]
 if o=='S':return xs[0]+1
 if o=='C':return xs[1] if xs[0]==0 else xs[2]
 x,y=xs
 # Evaluate D independently by its terminating swap recursion.
 while x>0:x,y=y,x-1
 return y

def check(rows):
 seen=set();counts={n:0 for n in COUNTS}
 for n,s,k,value in rows:
  if s in seen:raise ValueError('duplicate')
  seen.add(s);t=parse(s)
  if size(t)!=n or n not in counts:raise ValueError('size')
  counts[n]+=1
  if not isinstance(k,int) or not 0<=k<8:raise ValueError('test index')
  got=ev(t,*PTS[k])
  if got!=value:raise ValueError('value')
  fail=got!=0 if k<5 else got<2 if k==5 else got!=k-4
  if not fail:raise ValueError('not a rejection')
 if counts!=COUNTS:raise ValueError('incomplete enumeration')
 return counts
rows=json.loads(P.read_text());counts=check(rows)
controls=[]
for label,bad in [('missing_tree',rows[:-1]),('wrong_value',copy.deepcopy(rows))]:
 if label=='wrong_value':bad[0][3]+=1
 try:check(bad)
 except ValueError:controls.append(label)
 else:raise RuntimeError('control accepted')
result={'raw_counts':counts,'total_verified':len(rows),'rejected_controls':controls,'evaluator':'literal terminating D swap recursion, independent parser'}
print(json.dumps(result,indent=2))
Path(__file__).with_name('counterfree_independent_verification.json').write_text(json.dumps(result,indent=2)+'\n')
