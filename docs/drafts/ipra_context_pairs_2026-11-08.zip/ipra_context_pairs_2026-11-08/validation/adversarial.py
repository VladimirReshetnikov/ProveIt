"""Deterministic adversarial validation; finite evidence, not a soundness proof."""

import ast
import argparse
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import random

from oracle_pair import Oracle

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
FIXTURE = HERE / 'fixtures/positive_certificates.json'
LEGACY = ROOT / 'comparison/frozen/ipra_compact_kernel_2026-11-07__checker_retained.py'


def definitions(path):
    parsed = ast.parse(path.read_text())
    assert isinstance(parsed.body[-1], ast.Try)
    parsed.body.pop()
    scope = {}
    exec(compile(parsed, str(path), 'exec'), scope)
    return scope


def run(scope, packet):
    scope['k'] = 0
    stack = deepcopy(packet)
    try:
        scope['take'] = stack.pop
        accepted = bool(scope['check'](stack.pop(), []))
        error = None
    except Exception as exc:
        accepted = False
        error = type(exc).__name__
    return {'accepted': accepted, 'final_k': scope['k'],
            'remaining': len(stack) if type(stack) is list else None,
            'error': error}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', default='checker.py',
                        choices=('checker.py', 'checker_exact_list.py'))
    args = parser.parse_args()
    candidate = ROOT / args.checker
    scope, oracle = definitions(candidate), Oracle()
    fixtures = json.loads(FIXTURE.read_text())['records']
    randomizer = random.Random(20261108)
    leaves = [-8, -3, -2, -1, 0, 1, 2, 3, 4, 8, True, False, None,
              '', 'abc', {}, {'x': 0}, .5, -1.5, float('nan'),
              float('inf'), -float('inf')]

    def tree(depth=3):
        if depth == 0 or randomizer.randrange(3) == 0:
            return deepcopy(randomizer.choice(leaves))
        return [tree(depth - 1) for _ in range(randomizer.randrange(6))]

    counts, accepted_counts = {}, {}
    rules = {}
    checked = 0
    evaluated_equations = 0
    oversized_equations = 0

    def evaluate(term, slots=(), budget=None):
        # Direct standard-number semantics, independent of both traversals.
        if budget is None:
            budget = [20000]
        budget[0] -= 1
        if budget[0] < 0:
            raise OverflowError('evaluation budget')
        if type(term) is not list:
            if not isinstance(term, (int, float)) or not math.isfinite(term):
                raise ValueError('non-numerical meaningful leaf')
            coordinate = math.floor(term)
            if coordinate == 0:
                return 0
            if coordinate > 0:
                return slots[(coordinate - 1) // 2]
            raise ValueError('free numerical variable in closed equation')
        if len(term) in (0, 2):
            return 0
        if len(term) == 1:
            value = 1 + evaluate(term[0], (0,) + slots, budget)
        elif len(term) == 3:
            count = evaluate(term[0], (0, 0) + slots, budget)
            value = evaluate(term[1], (0, 0) + slots, budget)
            if count > 5000:
                raise OverflowError('iteration budget')
            for _ in range(count):
                value = evaluate(term[2], (value, value) + slots, budget)
        else:
            raise ValueError('constructor arity')
        if value > 1000000:
            raise OverflowError('value budget')
        return value

    def verify(packet, cohort, expected=None):
        nonlocal checked, evaluated_equations, oversized_equations
        before, after = run(scope, packet), oracle.run(packet)
        fields = ('accepted', 'final_k', 'remaining')
        if any(before[k] != after[k] for k in fields):
            (HERE / 'counterexample.json').write_text(json.dumps(
                {'cohort': cohort, 'packet': packet,
                 'candidate': before, 'oracle': after}, indent=2))
            raise AssertionError(('reference mismatch', cohort, before, after))
        if expected is not None and before['accepted'] != expected:
            (HERE / 'counterexample.json').write_text(json.dumps(
                {'cohort': cohort, 'packet': packet,
                 'candidate': before, 'expected': expected}, indent=2))
            raise AssertionError(('unexpected verdict', cohort, before, expected))
        if before['accepted'] and type(packet[-1]) is list and len(packet[-1]) == 2:
            try:
                left, right = map(evaluate, packet[-1])
                if left != right:
                    raise AssertionError(('false accepted equation', packet, left, right))
                evaluated_equations += 1
            except OverflowError:
                oversized_equations += 1
        checked += 1
        counts[cohort] = counts.get(cohort, 0) + 1
        accepted_counts[cohort] = accepted_counts.get(cohort, 0) + before['accepted']
        for name, value in after['rules'].items():
            rules[name] = rules.get(name, 0) + value

    for record in fixtures:
        verify(record['packet'], 'canonical', True)
    for _ in range(50000):
        packet = [tree(2) for _ in range(randomizer.randrange(9))]
        verify(packet, 'raw random')
    for record in fixtures:
        for _ in range(60):
            packet = deepcopy(record['packet'])
            packet[randomizer.randrange(len(packet))] = tree(3)
            verify(packet, 'canonical cell mutation')
    false_goals = [[0, [0]], [[0], 0], [[0], [[0]]],
                   [[[0], 0, [3]], 0], [[0, [0], 0], 0]]
    for goal in false_goals:
        for record in fixtures:
            packet = deepcopy(record['packet'])
            packet[-1] = deepcopy(goal)
            verify(packet, 'false equation replacing canonical goal', False)
        for _ in range(2000):
            packet = [tree(2) for _ in range(randomizer.randrange(10))]
            packet.append(deepcopy(goal))
            verify(packet, 'false equation with random proof', False)
    # Establish a paired truth theorem, eliminate it to install padding,
    # then try to use each scalar as an elimination major for 0=S0.
    # D(x,y).(0=0) has a one-instruction induction proof with witness zero.
    major = [0, 0, [0, 0]]
    for scalar in leaves:
        packet = [[], [scalar, [1, [0]]], 0, [major, 0], [0, [0]]]
        verify(packet, 'scalar major after truth padding', False)
    legacy = definitions(LEGACY)
    divergence_results = []
    for case in json.loads((HERE/'fixtures/raw_divergences.json').read_text()):
        packet = case['packet']
        verify(packet, 'documented raw divergence', case['new_accepts'])
        previous = run(legacy, packet)
        if previous['accepted'] != case['old_accepts']:
            raise AssertionError(('legacy divergence changed', case, previous))
        divergence_results.append({
            'name': case['name'], 'old_accepts': previous['accepted'],
            'new_accepts': run(scope, packet)['accepted'],
            'decoded_goal': case['decoded_goal']})
    receipt = {
        'status': 'PASS', 'seed': 20261108,
        'packet_comparisons': checked, 'cohorts': counts,
        'accepted_by_cohort': accepted_counts, 'rule_visits': rules,
        'accepted_closed_equations_semantically_evaluated': evaluated_equations,
        'accepted_closed_equations_exceeding_evaluation_budget': oversized_equations,
        'profile': args.checker,
        'candidate_sha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
        'oracle_sha256': hashlib.sha256((HERE/'oracle_pair.py').read_bytes()).hexdigest(),
        'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'compared': ['acceptance', 'fresh-name floor', 'remaining packet cells'],
        'raw_divergences': divergence_results,
        'qualification': 'Finite differential and targeted rejection tests, not a machine-checked proof of soundness.'
    }
    (ROOT / 'results' / f'adversarial_{candidate.stem}.json').write_text(
        json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
