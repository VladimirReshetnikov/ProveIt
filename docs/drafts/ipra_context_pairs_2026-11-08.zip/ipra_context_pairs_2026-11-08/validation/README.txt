PAIRED-CONTEXT VALIDATION
=========================

Run from the package root:

  python3 validation/adversarial.py --checker checker.py
  python3 validation/adversarial.py --checker checker_exact_list.py

Only Python's standard library is required. The fixed seed is 20261108.
Each invocation writes results/adversarial_<checker-stem>.json and includes
the current candidate, oracle, and runner SHA-256 hashes. The candidate is
loaded with its final command-line try/except removed, then run with exactly
the same empty-context, k=0 boundary. Actual command-line smoke checks are
separate from these differential checks.

The separately written oracle uses explicit numerical/formula traversals,
protected-slot counts, and named rules. It imports no production kernel and
does not use its packed scope table or shared context-container traversal.

Each profile checks these fixed populations:
  147 inherited canonical positive certificates;
  50,000 arbitrary raw packets;
  8,820 mutations of canonical certificate cells;
  735 false equations replacing canonical final goals;
  10,000 false equations with arbitrary proposed proofs;
  22 scalar-major attacks after truth padding is introduced;
  2 documented raw-behavior divergence packets.

Comparison covers acceptance, final fresh-name floor, and remaining packet
cells. Successful closed equations are additionally evaluated directly in
the standard natural numbers under a stated finite resource budget. This is
finite validation evidence, not a proof-assistant formalization or a proof
of the universal soundness theorem.

The two divergence cases are intentional. Truth padding can close a proof
earlier and therefore change instruction consumption. The new and old
checkers have the same decoded theorem set, but arbitrary raw packet
verdicts agree in neither direction. Both documented final goals denote
intuitionistic theorems.

FIXTURE ORIGIN AND LICENSE

fixtures/positive_certificates.json is copied unchanged from the current
compact-kernel draft. Its 147 records preserve prior translation origins.
fixtures/immediate_provenance.json records the pinned immediate archive;
fixtures/provenance.json preserves the earlier provenance chain, and
fixtures/LICENSE-inherited.txt preserves the MIT-0 license.

The named-rule organization follows the credited predecessor oracle
ipra_compact_kernel_2026-11-07/validation/validation_sources/oracle_erasure.py.
The present oracle separately states retained scalar-label semantics and
the two-entry context extension. The adversarial runner and raw-divergence
fixtures are new to this package, under the package's license.
