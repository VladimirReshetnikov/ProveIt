"""Reproducible finite validation of fixed-pair-context iPRA checkers.

The reference evaluator uses separate term/formula visitors and named rules.
The production function is never imported by the oracle. These checks are
finite implementation evidence, not a formalization of the metatheorems.
"""
import argparse
import ast
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / 'fixtures'
PACKAGE = ROOT.parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_reference(path):
    spec = importlib.util.spec_from_file_location('pair_context_reference', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.Oracle


def definitions(path):
    tree = ast.parse(path.read_text())
    if not isinstance(tree.body[-1], ast.Try):
        raise ValueError('Expected the complete explicit stdin driver')
    tree.body = tree.body[:-1]
    namespace = {}
    exec(compile(tree, str(path), 'exec'), namespace)
    return namespace


def trace(namespace, packet, contexts=None):
    namespace['k'] = 0
    stack = deepcopy(packet)
    original = namespace['check']
    if contexts is not None:
        def observe(goal, context):
            contexts.append({'goal': deepcopy(goal), 'context': deepcopy(context)})
            return original(goal, context)
        namespace['check'] = observe
    try:
        namespace['take'] = stack.pop
        accepted = bool(namespace['check'](stack.pop(), []))
    except Exception:
        accepted = False
    finally:
        namespace['check'] = original
    return accepted, namespace['k'], len(stack) if type(stack) is list else None


def opening(namespace, value, image, depth, lower):
    namespace['k'] = lower
    try:
        return True, namespace['inst'](value, image, depth)
    except Exception:
        return False, None


def reference_opening(reference, value, image, depth, lower):
    reference.lower = lower
    try:
        visitor = reference.term if depth % 2 else reference.formula
        return True, visitor(value, image, depth // 2)
    except Exception:
        return False, None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('candidates', nargs='*', type=Path)
    parser.add_argument('--output', type=Path, default=PACKAGE / 'results/targeted.json')
    args = parser.parse_args()
    candidates = args.candidates or [PACKAGE / 'checker.py', PACKAGE / 'checker_exact_list.py']
    fixture_path = INPUTS / 'positive_certificates.json'
    focused_path = INPUTS / 'targeted_packets.json'
    records = json.loads(fixture_path.read_text())['records']
    focused = json.loads(focused_path.read_text())
    Oracle = load_reference(ROOT / 'oracle_pair.py')
    reference = Oracle()
    predecessor_path = PACKAGE / 'comparison/frozen/ipra_compact_kernel_2026-11-07__checker_retained.py'
    predecessor = definitions(predecessor_path)
    values = [None, False, True, -3, -2, -1, -.25, 0, .25, 1, 1.9, 2, 3, 4, 5, 7, 50,
              '', 'x', {}, {'': 0}, [], [0], [None], [None, None], [1, 3],
              [[None]], [3, 3, 3], [0, [0]], [[1, 3], 0, 1],
              float('inf'), float('-inf'), float('nan')]
    profiles = []
    for path in candidates:
        path = path.resolve()
        namespace = definitions(path)
        source_sha = digest(path)
        for record in records:
            actual = trace(namespace, record['packet'])
            old = trace(predecessor, record['packet'])
            ref = reference.run(record['packet'])
            wanted = ref['accepted'], ref['final_k'], ref['remaining']
            if not actual[0] or actual != wanted or actual != old:
                raise AssertionError(('canonical packet', path.name, record['id'], actual, wanted, old))
        observations = []
        for case in focused:
            contexts = []
            actual = trace(namespace, case['packet'], contexts)
            ref = reference.run(case['packet'])
            wanted = ref['accepted'], ref['final_k'], ref['remaining']
            if actual != wanted or actual[0] != case['accepted']:
                raise AssertionError(('focused packet', path.name, case['name'], actual, wanted))
            observations.append({'name': case['name'], 'trace': actual,
                                 'old_trace': trace(predecessor, case['packet']),
                                 'contexts': contexts if case['name'].startswith(('DI_', 'DE_')) else []})
        opening_count = 0
        for value in values:
            for image in (None, 0, [0]):
                for depth, lower in ((0, 0), (0, -2), (1, 0), (1, -2), (2, 0), (3, -2), (4, -2), (5, 0)):
                    actual = opening(namespace, value, image, depth, lower)
                    wanted = reference_opening(reference, value, image, depth, lower)
                    if actual != wanted:
                        raise AssertionError(('opening', path.name, value, image, depth, lower, actual, wanted))
                    opening_count += 1
        frame_count = 0
        for left in values[:30]:
            for right in values[:30]:
                for image in (-3, 0, [0]):
                    for lower in (0, -2):
                        actual = opening(namespace, [left, right], image, -1, lower)
                        namespace['k'] = lower
                        try:
                            wanted = True, [namespace['inst'](left, image), namespace['inst'](right, image)]
                        except Exception:
                            wanted = False, None
                        if actual != wanted:
                            raise AssertionError(('synthetic frame', path.name, left, right, image, lower, actual, wanted))
                        frame_count += 1
        cli_runs = 0
        for case in focused:
            for flags in ([], ['-O']):
                result = subprocess.run([sys.executable, *flags, str(path)], input=json.dumps(case['packet']),
                                        text=True, capture_output=True, timeout=10)
                wanted = ('ACCEPT\n', 0, '') if case['accepted'] else ('REJECT\n', 1, '')
                if (result.stdout, result.returncode, result.stderr) != wanted:
                    raise AssertionError(('CLI', path.name, case['name'], flags, result.stdout, result.returncode, result.stderr))
                cli_runs += 1
        if source_sha != digest(path):
            raise AssertionError('Candidate source changed during validation')
        profiles.append({'candidate': path.name, 'source_sha256': source_sha, 'status': 'PASS',
                         'canonical_positive_certificates': len(records), 'focused_packets': len(focused),
                         'focused_openings': opening_count, 'synthetic_frame_checks': frame_count,
                         'public_cli_runs': cli_runs, 'focused_observations': observations})
    receipt = {'status': 'PASS', 'python': platform.python_version(),
               'compared': ['acceptance', 'final_parameter_floor', 'unread_cells'],
               'profiles': profiles,
               'hashes': {'runner': digest(Path(__file__)), 'oracle': digest(ROOT / 'oracle_pair.py'),
                          'fixtures': digest(fixture_path), 'focused': digest(focused_path),
                          'predecessor': digest(predecessor_path)},
               'limitations': 'Finite implementation evidence. Native theorem equivalence does not imply equal acceptance of all redundant or malformed packets; the explicit DE truth example distinguishes the new profile.'}
    args.output.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'status': receipt['status'], 'python': receipt['python'],
                      'profiles': [{k: v for k, v in p.items() if k != 'focused_observations'} for p in profiles]}, indent=2))


if __name__ == '__main__':
    main()
