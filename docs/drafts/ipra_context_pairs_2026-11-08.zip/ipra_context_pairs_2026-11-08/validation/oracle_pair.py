"""Independent named-rule reference for the paired-context scalar checker.

This interpreter uses separately written formula and term traversals, explicit
protected-slot counts, and named proof rules.  It never imports the checker.
Its mathematical basis follows the retained-label scalar native calculus;
one extra truth assumption is stored where the production checker pads a pair.
"""

from copy import deepcopy


class Oracle:
    def __init__(self):
        self.lower = 0
        self.rules = {}

    def rule(self, name):
        self.rules[name] = self.rules.get(name, 0) + 1

    def formula(self, value, image=None, slots=0):
        if type(value) is not list:
            if self.lower <= value < 2 * slots:
                return value
            return 0
        if len(value) == 0:
            return []
        if len(value) == 1:
            return [self.formula(value[0], image, slots + 1)]
        if len(value) == 2:
            return [self.term(value[0], image, slots),
                    self.term(value[1], image, slots)]
        if len(value) == 3:
            return [self.formula(value[0], image, slots + 2),
                    self.formula(value[1], image, slots + 2),
                    self.formula(value[2], image, slots + 2)]
        raise ValueError('formula constructor arity')

    def term(self, value, image=None, slots=0):
        if type(value) is not list:
            if self.lower <= value < 2 * slots + 1:
                return value
            return self.term(image)
        if len(value) == 0:
            return []
        if len(value) == 1:
            return [self.term(value[0], image, slots + 1)]
        if len(value) == 2:
            return [self.formula(value[0], image, slots + 1),
                    self.formula(value[1], image, slots + 1)]
        if len(value) == 3:
            return [self.term(value[0], image, slots + 2),
                    self.term(value[1], image, slots + 2),
                    self.term(value[2], image, slots + 2)]
        raise ValueError('term constructor arity')

    def fresh(self):
        self.lower -= 1
        return self.lower

    def check(self, goal, context):
        normalized = self.formula(goal)
        if normalized in context:
            self.rule('hypothesis')
            return True
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, context):
                if type(major) is not list:
                    # A newly accepted scalar truth major is not a binder.
                    raise ValueError('scalar major cannot eliminate')
                if len(major) == 3:
                    self.rule('paired elimination')
                    eigen = self.fresh()
                    minor = self.formula(goal, [eigen])
                    assumption = self.formula([major[2]], eigen)
                    return self.check(minor, context + [0, assumption])
                if len(major) == 1:
                    self.rule('closure elimination')
                    matrix, left, right = major[0], 0, annotation
                elif len(major) == 2:
                    self.rule('equality transport')
                    matrix, left, right = annotation, major[0], major[1]
                else:
                    raise ValueError('empty major cannot eliminate')
                if self.formula(matrix, right) != goal:
                    return False
                return self.check(self.formula(matrix, left), context)
            self.rule('failed major fallthrough')
        if type(instruction) is list and len(instruction) == 0:
            if type(goal) is not list or len(goal) != 2:
                raise ValueError('computation requires an equation')
            left, right = goal
            if type(left) is not list or len(left) != 3:
                raise ValueError('computation requires an iterator')
            count, initial, update = left
            if not count:
                self.rule('zero computation')
                expected = initial
            elif type(count) is list and len(count) == 1:
                self.rule('successor computation')
                expected = self.term(update, [count[0], initial, update])
            else:
                raise ValueError('counter is neither zero nor successor')
            return right == expected
        if type(goal) is not list or len(goal) != 3:
            raise ValueError('introduction requires a paired binder')
        self.rule('paired introduction')
        matrix = self.formula(goal[2], instruction, slots=1)
        if type(matrix) is not list:
            raise ValueError('scalar matrix has no induction shape')
        if len(matrix) in (0, 2):
            induction = matrix
        else:
            induction = 0
        base = self.formula(matrix, 0)
        eigen = self.fresh()
        successor = self.formula(matrix, [eigen])
        assumptions = [self.formula(induction, eigen),
                       self.formula(base, eigen)]
        return self.check(successor, context + assumptions)

    def run(self, packet):
        self.lower, self.rules = 0, {}
        self.stack = deepcopy(packet)
        try:
            accepted = bool(self.check(self.stack.pop(), []))
            error = None
        except Exception as exc:
            accepted = False
            error = type(exc).__name__
        return {'accepted': accepted, 'final_k': self.lower,
                'remaining': len(self.stack) if type(self.stack) is list else None,
                'error': error, 'rules': dict(self.rules)}
