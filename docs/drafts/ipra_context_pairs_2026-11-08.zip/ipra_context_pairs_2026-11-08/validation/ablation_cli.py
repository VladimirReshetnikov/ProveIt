"""Small reproducible CLI check for the controlled mapped-context ablation."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
NAMES = {'zero_computation', 'successor_computation', 'DI_equation_context',
         'DI_closure_context', 'DE_truth_padding_used',
         'DE_truth_cannot_prove_false_equation'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    fixture = ROOT / 'validation/fixtures/targeted_packets.json'
    reference = ROOT / 'validation/checker_mapped_reference.py'
    production = ROOT / 'checker.py'
    expected_source = production.read_text().replace(
        'g + inst(h, k, -1)', 'g + [inst(c, k) for c in h]')
    if reference.read_text() != expected_source:
        raise ValueError('Reference is not the claimed single-change ablation')
    cases = [case for case in json.loads(fixture.read_text()) if case['name'] in NAMES]
    if len(cases) != len(NAMES):
        raise ValueError('A targeted ablation case is missing')
    count = 0
    for case in cases:
        for flags in ([], ['-O']):
            actual = subprocess.run([sys.executable, *flags, str(reference)],
                                    input=json.dumps(case['packet']), text=True,
                                    capture_output=True, timeout=10)
            expected = ('ACCEPT\n', 0, '') if case['accepted'] else ('REJECT\n', 1, '')
            if (actual.stdout, actual.returncode, actual.stderr) != expected:
                raise AssertionError((case['name'], flags, actual.stdout, actual.returncode, actual.stderr))
            count += 1
    receipt = {'status': 'PASS', 'python': platform.python_version(),
               'cases': [case['name'] for case in cases],
               'normal_and_optimized_cli_runs': count,
               'reference_sha256': sha(reference), 'production_sha256': sha(production),
               'fixture_sha256': sha(fixture), 'runner_sha256': sha(Path(__file__))}
    (ROOT / 'results/ablation_cli.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
