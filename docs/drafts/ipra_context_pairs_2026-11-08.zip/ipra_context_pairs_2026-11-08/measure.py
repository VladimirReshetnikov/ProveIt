"""Measure every current complete root checker and both new candidates.

The upstream metric implementation is copied unchanged. Controls replace
only the public driver and/or the two helper identifiers, uniformly in every
program. Complete parsing, validation, inference, and output remain charged.
"""
import argparse
import ast
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
COMPARISON = ROOT / 'comparison'
RESULTS = ROOT / 'results'
NORMALIZER_SHA256 = 'f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc'
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
DRIVER = """try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
"""


class Rename(ast.NodeTransformer):
    def __init__(self, names):
        self.names = names
    def visit_Name(self, node):
        node.id = self.names.get(node.id, node.id)
        return node
    def visit_FunctionDef(self, node):
        node.name = self.names.get(node.name, node.name)
        return self.generic_visit(node)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def transformed(source, common_driver, common_names):
    tree = ast.parse(source)
    functions = [node.name for node in tree.body if isinstance(node, ast.FunctionDef)]
    if len(functions) != 2:
        raise ValueError('The current corpus has exactly two named helpers per checker')
    if common_driver:
        start = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Try))
        suffix = tree.body[start:]
        # Every current root checker ends with one driver try and optionally
        # its separate ACCEPT print. Do not silently discard another suffix.
        if len(suffix) not in (1, 2) or (len(suffix) == 2 and not isinstance(suffix[1], ast.Expr)):
            raise ValueError('Unexpected public driver suffix')
        driver = ast.parse(DRIVER)
        driver = Rename({'check': functions[1]}).visit(driver)
        tree.body = tree.body[:start] + driver.body
    if common_names:
        tree = Rename(dict(zip(functions, ('s', 'c')))).visit(tree)
    return ast.unparse(tree) + '\n'


def write_tables(output):
    rows = []
    for control, data in output['controls'].items():
        for kind in ('baselines', 'candidates'):
            for row in data[kind]:
                rows.append({'control': control, 'kind': kind, 'label': row['label'],
                             'source_sha256': row['source_sha256'],
                             **{field: row['metrics'][field] for field in FIELDS}})
    with (RESULTS / 'measurements.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ('control', 'kind', 'label', *FIELDS, 'source_sha256'))
        writer.writeheader()
        writer.writerows(rows)
    delivered = output['controls']['delivered']
    main, exact = delivered['candidates']
    baseline = delivered['baseline_minimum']
    names = output['controls']['common_stdin_and_helper_names']
    macros = {'MainTokens': main['metrics']['normalized_tokens'],
              'MainAST': main['metrics']['ast_nodes'], 'MainBytes': main['metrics']['normalized_bytes'],
              'ExactTokens': exact['metrics']['normalized_tokens'],
              'ExactAST': exact['metrics']['ast_nodes'], 'ExactBytes': exact['metrics']['normalized_bytes'],
              'BaseTokens': baseline['normalized_tokens'], 'BaseAST': baseline['ast_nodes'],
              'BaseBytes': baseline['normalized_bytes'],
              'NamedMainBytes': names['candidates'][0]['metrics']['normalized_bytes'],
              'NamedBaseBytes': names['baseline_minimum']['normalized_bytes']}
    (RESULTS / 'numbers.tex').write_text(''.join('\\newcommand{\\'+name+'}{'+str(value)+'}\n' for name, value in macros.items()))
    lines = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             r'Complete program & Tokens & AST nodes & Bytes \\', r'\midrule']
    for row in delivered['baselines']:
        folder, program = row['label'].split('/')
        label = folder.removeprefix('ipra_').removesuffix('_2026-11-07').replace('_', ' ').capitalize()
        profile = program.removeprefix('checker').removesuffix('.py').strip('_').replace('_', ' ') or 'main'
        values = [str(row['metrics'][field]) for field in FIELDS]
        lines.append(label+' ('+profile+') & '+' & '.join(values)+r' \\')
    lines.append(r'\midrule')
    lines.append('Current coordinate minima & '+' & '.join(str(baseline[field]) for field in FIELDS)+r' \\')
    for label, row in [('New main checker', main), ('New exact-list companion', exact)]:
        lines.append(label+' & '+' & '.join(str(row['metrics'][field]) for field in FIELDS)+r' \\')
    lines.extend([r'\bottomrule', r'\end{tabular}'])
    (RESULTS / 'measurements.tex').write_text('\n'.join(lines)+'\n')
    (RESULTS / 'current_table.tex').write_text('\n'.join(lines)+'\n')


def ablation(metric):
    main_path = ROOT / 'checker.py'
    reference_path = ROOT / 'validation/checker_mapped_reference.py'
    production = main_path.read_text()
    old = 'g + inst(h, k, -1)'
    new = 'g + [inst(c, k) for c in h]'
    if production.count(old) != 1 or reference_path.read_text() != production.replace(old, new):
        raise ValueError('The mapped reference must differ only in the final context traversal')
    main = metric.metrics(main_path)
    reference = metric.metrics(reference_path)
    return {'description': 'Controlled removal of the dedicated context-list traversal. Padding, closure caching, type test, and public driver remain byte-for-byte identical.',
            'production_file': 'checker.py', 'reference_file': 'validation/checker_mapped_reference.py',
            'production': main, 'mapped_reference': reference,
            'saving': {field: reference[field] - main[field] for field in FIELDS},
            'equivalence': 'The fixed binary frame identity gives exact raw-packet equivalence in idealized execution; finite CLI checks are recorded separately.',
            'normalizer_sha256': sha(COMPARISON / 'source_measure.py')}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('candidates', nargs='*', type=Path)
    parser.add_argument('--output', type=Path, default=RESULTS / 'measurements.json')
    args = parser.parse_args()
    candidates = args.candidates or [ROOT / 'checker.py', ROOT / 'checker_exact_list.py']
    manifest = json.loads((COMPARISON / 'manifest.json').read_text())
    normalizer_path = COMPARISON / 'source_measure.py'
    if sha(normalizer_path) != NORMALIZER_SHA256:
        raise ValueError('The inherited metric implementation changed')
    spec = importlib.util.spec_from_file_location('unchanged_source_metric', normalizer_path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    baseline_paths = []
    for entry in manifest['programs']:
        path = COMPARISON / entry['local_file']
        if sha(path) != entry['sha256']:
            raise ValueError('The frozen comparator changed: ' + entry['label'])
        baseline_paths.append((entry['label'], path))
    candidates = [(path.name, path.resolve()) for path in candidates]
    output = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'repository': manifest['repository'], 'commit': manifest['commit'],
              'archive_count': len(manifest['archives']), 'baseline_program_count': len(baseline_paths),
              'normalizer_sha256': sha(normalizer_path), 'manifest_sha256': sha(COMPARISON / 'manifest.json'),
              'definition': 'Complete source, after genuine docstrings are removed and ast.unparse normalizes formatting; normalized significant tokens, AST nodes, and normalized UTF-8 bytes. The normalizer does not rename identifiers.',
              'controls': {}}
    with tempfile.TemporaryDirectory() as temp:
        for control, driver, names in [('delivered', False, False), ('common_stdin', True, False),
                                       ('common_helper_names', False, True), ('common_stdin_and_helper_names', True, True)]:
            rows = []
            for index, (label, path) in enumerate(baseline_paths + candidates):
                if not driver and not names:
                    measured = metric.metrics(path)
                else:
                    transformed_path = Path(temp) / (str(index) + '.py')
                    transformed_path.write_text(transformed(path.read_text(), driver, names))
                    measured = metric.metrics(transformed_path)
                rows.append({'label': label, 'source_sha256': sha(path), 'metrics': measured})
            baseline_rows = rows[:len(baseline_paths)]
            candidate_rows = rows[len(baseline_paths):]
            minimum = {field: min(row['metrics'][field] for row in baseline_rows) for field in FIELDS}
            for row in candidate_rows:
                row['strictly_below_coordinate_minima'] = {field: row['metrics'][field] < minimum[field] for field in FIELDS}
                row['absolute_saving'] = {field: minimum[field] - row['metrics'][field] for field in FIELDS}
                if not all(row['strictly_below_coordinate_minima'].values()):
                    raise AssertionError(('Improvement control failed', control, row))
            output['controls'][control] = {'baseline_minimum': minimum, 'baselines': baseline_rows, 'candidates': candidate_rows}
    output['ablation'] = ablation(metric)
    output['runner_sha256'] = sha(Path(__file__))
    RESULTS.mkdir(exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2) + '\n')
    (RESULTS / 'ablation.json').write_text(json.dumps(output['ablation'], indent=2) + '\n')
    write_tables(output)
    print(json.dumps({key: {'baseline_minimum': value['baseline_minimum'],
                            'candidates': [{k: v for k, v in row.items() if k != 'source_sha256'} for row in value['candidates']]}
                      for key, value in output['controls'].items()}, indent=2))


if __name__ == '__main__':
    main()
