"""Compile the supplied mathematical report with a local pdfLaTeX installation."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
previous_aux = None
for _ in range(5):
    result = subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','report.tex'],
                            cwd=ROOT,capture_output=True,text=True)
    if result.returncode:
        print(result.stdout)
        print(result.stderr)
        raise SystemExit(result.returncode)
    aux = (ROOT/'report.aux').read_bytes()
    log = (ROOT/'report.log').read_text(errors='replace')
    if aux == previous_aux and 'Rerun to get cross-references right' not in log:
        break
    previous_aux = aux
log = (ROOT/'report.log').read_text(errors='replace')
if ('undefined references' in log or 'Citation `' in log or 'Reference `' in log
        or 'Rerun to get cross-references right' in log):
    raise SystemExit('Unresolved references; inspect report.log')
print('Built report.pdf')
