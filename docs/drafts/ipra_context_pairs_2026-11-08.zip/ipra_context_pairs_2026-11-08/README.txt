REIFYING PROOF CONTEXTS: A SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific time)
================================================================

START HERE

report.pdf is the complete mathematical paper. report.tex, sections/,
appendices/, and results/*.tex are its complete editable LaTeX source.
The archive is self-contained for offline reproduction.

MEASURED RESULT

Current snapshot: VladimirReshetnikov/ProveIt commit
ce3371c9025b5c0ba12543acc2e6475d13ff7a3c, all five current docs/drafts ZIPs.
Ten complete root checker programs are compared, frozen without alteration.

                                      Tokens   AST nodes   Normalized bytes
Current coordinatewise minima            328         356                957
checker.py                               325         352                952
checker_exact_list.py                    325         354                948

Each candidate is strictly below every coordinate of the current envelope.
The result survives a common stdin driver and common helper names. With
common helper names, the byte minimum is 904; the new programs are 899/895.
Counts use the unchanged inherited source metric on CPython 3.12.14, including
the entire acceptance/rejection driver and all project-specific trusted code.

WHAT IS NEW

Every local assumption block is a pair. A missing induction or elimination
assumption is padded with the already derivable truth 0=0. Binary syntax
adds one to the opening depth, so

  inst([A,B], t, -1) = [inst(A,t,0), inst(B,t,0)].

The existing expression traversal therefore also opens the whole assumption
block. It replaces a separate context list comprehension. A controlled
reference differing only in that traversal measures 328/355/961; the change
itself saves 3 tokens, 3 AST nodes, and 9 normalized bytes.

This is a measured complete-checker simplification, not a new arithmetic
axiom basis or a foundational breakthrough. No absolute minimum is proved.
The native two computation schemas and five inference patterns are inherited
and fully stated, attributed, and accompanied by their mathematical proofs.

MATHEMATICAL CONTENT

The target is full intuitionistic first-order arithmetic with all fixed
primitive-recursive descriptions and quantifier-free induction with parameters,
as specified in Section 1. The ordinary realization and iPRA are bi-interpretable
on their whole numerical domains, with internal identity composites. Native
contradiction is explicitly connected to ordinary falsity. Scalar predecessor,
reflection, pairing, and the general recursion compiler are reproduced in full.

The new representation has a written all-raw-input soundness argument and
canonical completeness proof. New and old raw packet acceptance sets differ
in both directions; their decoded theorem languages agree. Concrete divergence
packets are supplied. No Lean or Rocq formalization is claimed.

The report also gives three precise obstructions: equation induction alone
admits a componentwise N x N model without numerical coverage; deleting the
retained atomic base changes the native closure theory; deleting initialization
leaves a shifted-initializer countermodel. These explain why the reduction
preserves all actual logical and arithmetic premises.

RUN A CERTIFICATE

  python3 checker.py < examples/zero_computation.json
  python3 checker.py < examples/truth_padding.json
  python3 checker.py < examples/equation_induction.json

The input is one JSON list. Its final cell is the closed goal. Instructions
are consumed from the end of the preceding cells. ACCEPT has exit code 0;
REJECT has exit code 1. Both checkers use only Python's standard library and
require Python 3.10 or later. FORMAT.txt summarizes the representation.

REPRODUCE

  python3 reproduce.py
  python3 reproduce.py --pdf

The second command also rebuilds the paper with an installed pdfLaTeX.
Individual commands:

  python3 measure.py
  python3 validation/targeted.py
  python3 validation/adversarial.py --checker checker.py
  python3 validation/adversarial.py --checker checker_exact_list.py
  python3 validation/ablation_cli.py
  python3 build.py
  python3 package.py

Exact source metrics were recorded on CPython 3.12.14. Finite real processes
may reject proofs exceeding their resources; mathematical completeness is
stated under sufficient-resource semantics, as in the existing corpus.

VALIDATION

For EACH profile, 69,726 deterministic packets agree with an independent
named-rule oracle on acceptance, final fresh-name floor, and remaining cells.
The population includes 147 inherited positives, 50,000 arbitrary packets,
8,820 mutations, 10,735 explicitly false-equation attempts, 22 scalar-major
attacks, and 2 documented raw divergences. All 369 accepted closed equations
encountered also evaluate true in an independent standard-number evaluator.

Additional targeted evidence covers 21 boundary packets, 792 sorted openings,
5,400 pair-frame identities, and 42 actual CLI runs/profile, including -O.
The mapped reference has 12 further CLI checks. Suites overlap; counts are
not a tally of distinct mathematical theorems. These finite checks support
the implementation and do not replace the written universal metatheorems.

CONTENTS

  report.pdf / report.tex       Full mathematical paper and main LaTeX source
  sections/, appendices/        All axioms, rules, interpretations and proofs
  checker.py                   Primary standalone complete acceptance program
  checker_exact_list.py        Equivalent byte-smaller profile
  FORMAT.txt                   Public representation and internal pair frame
  examples/                    Positive and negative demonstration packets
  validation/                  Independent oracle, fixtures and runners
  comparison/frozen/           All ten unchanged current root checker sources
  comparison/licenses/         Preserved licenses and contribution notices
  comparison/manifest.json     Exact pinned source and archive identities
  source_snapshot.json         Current GitHub snapshot and payload hashes
  results/                     Reproducible measurements and validation receipts
  measure.py / reproduce.py     Offline evidence reproduction
  build.py / package.py         PDF build and clean archive generation
  ATTRIBUTION.txt / LICENSE     New/inherited contribution boundary and license
  SHA256SUMS.txt                Integrity of all packaged files
