DEMONSTRATION PACKETS
====================

All samples except false_successor_computation.json are expected to ACCEPT
under either delivered checker. That false equation is expected to REJECT.

  zero_computation.json             Zero iterator equation
  successor_computation.json        Successor iterator equation
  false_successor_computation.json  Deliberately false arithmetic equation
  zero_plus_theorem.json            Inherited arithmetic certificate
  implication_nested_identity.json  Inherited logical certificate
  equation_induction.json           Explicit equation induction
  implication_reflexivity.json      Derived implication
  retained_atomic_base.json         Atomic step using its retained base
  compound_numerical_cases.json     Cases at a compound matrix
  truth_padding.json               New noncanonical proof of scalar truth

The inherited samples come from the compact-kernel archive and its canonical
fixture collection. Their original provenance is preserved under
validation/fixtures/. truth_padding.json is the new explicit example used in
the paper; it intentionally differs in raw acceptance from the old verifier.

Example:
  python3 checker.py < examples/truth_padding.json
