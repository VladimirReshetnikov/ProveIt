"""Reproduce source comparisons, certificate checks, and optionally the PDF.

Only this driver and the PDF builder orchestrate subprocesses. Neither is
imported by the measured standalone proof checkers.
"""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pdf', action='store_true')
    args = parser.parse_args()
    commands = [
        ['measure.py'],
        ['validation/targeted.py'],
        ['validation/adversarial.py', '--checker', 'checker.py'],
        ['validation/adversarial.py', '--checker', 'checker_exact_list.py'],
        ['validation/ablation_cli.py'],
    ]
    if args.pdf:
        commands.append(['build.py'])
    observations = []
    for command in commands:
        result = subprocess.run([sys.executable, *command], cwd=ROOT,
                                text=True, capture_output=True)
        name = Path(command[0]).stem
        suffix = '_' + Path(command[-1]).stem if '--checker' in command else ''
        log_path = ROOT / 'results' / (name + suffix + '.log')
        log_path.write_text(result.stdout + result.stderr)
        observations.append({'command': command, 'exit_code': result.returncode,
                             'log': str(log_path.relative_to(ROOT))})
        if result.returncode:
            print(result.stdout)
            print(result.stderr)
            raise SystemExit(result.returncode)
        print('PASS ' + ' '.join(command), flush=True)
    measurement = json.loads((ROOT/'results/measurements.json').read_text())
    targeted = json.loads((ROOT/'results/targeted.json').read_text())
    hashes = {}
    for index, filename in enumerate(('checker.py', 'checker_exact_list.py')):
        actual = digest(ROOT/filename)
        hashes[filename] = actual
        measured = measurement['controls']['delivered']['candidates'][index]
        if measured['source_sha256'] != actual:
            raise ValueError('Stale source measurement: ' + filename)
        if targeted['profiles'][index]['source_sha256'] != actual:
            raise ValueError('Stale targeted receipt: ' + filename)
        receipt = json.loads((ROOT/'results'/('adversarial_'+Path(filename).stem+'.json')).read_text())
        if receipt['candidate_sha256'] != actual:
            raise ValueError('Stale adversarial receipt: ' + filename)
    output = {'status': 'PASS', 'python': platform.python_version(),
              'commands': observations, 'verified_checker_hashes': hashes,
              'pdf_rebuilt': args.pdf,
              'qualification': 'Finite implementation evidence; universal metatheorems are written proofs in report.pdf.'}
    (ROOT/'results/reproduction.json').write_text(json.dumps(output, indent=2)+'\n')
    print('All reproduction stages passed and source receipts match.')


if __name__ == '__main__':
    main()
