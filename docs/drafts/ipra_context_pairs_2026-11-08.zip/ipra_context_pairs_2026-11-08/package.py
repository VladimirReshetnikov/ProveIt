"""Build a clean ZIP with all final sources, evidence, and the compiled paper."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {'.aux', '.out', '.toc', '.pyc'}


def members():
    return sorted(path for path in ROOT.rglob('*')
                  if path.is_file() and '__pycache__' not in path.parts
                  and path.suffix not in EXCLUDED_SUFFIXES
                  and not path.name.endswith('.synctex.gz')
                  and (path.suffix != '.log' or path.parent == ROOT/'results')
                  and path.name != 'SHA256SUMS.txt')


def main():
    if not (ROOT/'report.pdf').is_file():
        raise SystemExit('Run python3 build.py before packaging.')
    files = members()
    sums = ''.join(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+
                   path.relative_to(ROOT).as_posix()+'\n' for path in files)
    manifest = ROOT/'SHA256SUMS.txt'
    manifest.write_text(sums)
    destination = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted(files+[manifest]):
            info = zipfile.ZipInfo((Path(ROOT.name)/path.relative_to(ROOT)).as_posix(),
                                   date_time=(2026,11,8,12,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=9)
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise SystemExit('ZIP integrity check failed.')
    print(destination)
    print('SHA256 '+hashlib.sha256(destination.read_bytes()).hexdigest())
    print(str(len(files)+1)+' archive members')


if __name__ == '__main__':
    main()
