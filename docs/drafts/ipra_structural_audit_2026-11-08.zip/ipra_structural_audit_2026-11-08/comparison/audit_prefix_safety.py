"""Independent regression packets for the direct prefix/clausal prototype.

These are concrete semantic and scope checks, not a proof of kernel
soundness or completeness. They run the public JSON/ACCEPT interface.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CHECKER = ROOT.parent / "prototypes" / "checker_prefix.py"


def reflexivity_instructions(term):
    boxed = [[], term, []]
    equality = [0, boxed, term]
    motive = [0, 0, term]
    return [[3, equality, motive], [], []]


def packet(goal, instructions):
    return list(reversed(instructions)) + [goal]


def main():
    cases = []

    def add(name, goal, instructions, expected, reason):
        cases.append({"name": name, "expected_accept": expected,
                      "reason": reason, "packet": packet(goal, instructions)})

    false = [0, [], [[]]]
    prefixed_false = [1, [], [[]]]
    prefixed_false_proof = [[1, []], [0, 0, []], []]
    add("constant_false_under_D", prefixed_false, prefixed_false_proof, True,
        "D(false) is valid: the retained base already is the constant matrix.")
    add("false_after_D_elimination", false,
        [[2, prefixed_false]] + prefixed_false_proof + [[0, 0, []], []], False,
        "Using the opened clause still requires false as its source; its computation attempt fails.")

    # At the atomic leaf of D(x,y)D(u,v), the four variables are x=3,
    # y=2, u=1, v=0. Each iterator body adds its own state slot.
    # The term is I(x,y; r.I(u,r; s.I(v,s; q.Sq))).
    nested_open = [3, 2, [2, 0, [2, 0, [0]]]]
    one = [[]]
    # Outer witness x=1, outer successor y=S(-1), inner witness
    # u=S(-1), inner successor v=S(-2).
    nested_instantiated = [one, [-1], [[-1], 0, [[-2], 0, [0]]]]
    nested_proof = [[1, one], [1, [-1]]] + reflexivity_instructions(nested_instantiated)
    add("two_prefixes_all_four_variables_nested_iterators",
        [2, nested_open, nested_open], nested_proof, True,
        "Exercises both paired binders, both eigenparameters, both witnesses, and three nested state binders.")
    add("two_prefixes_tampered_equation",
        [2, nested_open, [nested_open]], nested_proof, False,
        "The same certificate cannot prove the successor of its original right endpoint.")

    # Outer update h(r)=I(Sr,0; s.Ss). In the IS axiom the result
    # contains the unreduced previous iterate, not its evaluated value.
    update = [[0], [], [0]]
    previous = [[], one, update]
    left = [[[]], one, update]
    right = [[previous], [], [0]]
    add("nested_state_substitution_IS", [0, left, right], [[]], True,
        "Substitution replaces the outer state while protecting the inner iterator state.")
    wrong_right = [[previous], [], [previous]]
    add("nested_state_capture_attempt", [0, left, wrong_right], [[]], False,
        "Replacing the protected inner state as well is not an IS instance.")

    # A proposed motive has one free numerical placeholder outside a D.
    # Its available slots are 0,1 for the D binders and 2 for the hole.
    major = [0, [[], [], []], []]
    valid_motive = [1, 2, 2]
    minor = [1, [[], [], []], [[], [], []]]
    minor_proof = [[1, []], [0, 0, []], []]
    add("transport_beneath_paired_prefix", [1, [], []],
        [[3, major, valid_motive], []] + minor_proof, True,
        "The transport hole lies beyond both bound variables of D.")
    invalid_motive = [1, 3, 3]
    add("transport_extra_free_slot", [1, [], []],
        [[3, major, invalid_motive], []] + minor_proof, False,
        "A motive may expose only its one declared placeholder, not a second free slot.")

    outputs = []
    for case in cases:
        result = subprocess.run([sys.executable, str(CHECKER)],
                                input=json.dumps(case["packet"]), text=True,
                                capture_output=True, timeout=10)
        accepted = result.returncode == 0 and result.stdout.strip() == "ACCEPT"
        if accepted != case["expected_accept"]:
            raise AssertionError((case["name"], accepted, case["expected_accept"],
                                  result.returncode, result.stdout, result.stderr))
        outputs.append({"name": case["name"], "expected_accept": case["expected_accept"],
                        "actual_accept": accepted, "passed": True,
                        "reason": case["reason"]})
    (ROOT / "prefix_safety_cases.json").write_text(json.dumps(cases, indent=2) + "\n")
    report = {"checker": str(CHECKER.relative_to(ROOT.parent)),
              "checker_sha256": hashlib.sha256(CHECKER.read_bytes()).hexdigest(),
              "passed": len(outputs), "total": len(outputs), "cases": outputs,
              "scope": "Finite public-interface regression tests; no proof-assistant verification claimed."}
    (ROOT / "prefix_safety_results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
