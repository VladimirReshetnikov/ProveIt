"""Reproduce the current nine-program comparison without network access.

The frozen source copies are byte-for-byte copies of the current archive
roots at the commit in manifest.json. The metric is imported unchanged
from the supplied clausal-kernel draft, with its provenance recorded below.
"""
import csv
import hashlib
import json
import platform
from pathlib import Path

from source_measure import metrics

ROOT = Path(__file__).resolve().parent
COORDINATES = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def main():
    manifest = json.loads((ROOT / "manifest.json").read_text())
    rows = []
    for entry in manifest["programs"]:
        path = ROOT / entry["frozen_path"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
            raise ValueError("Changed frozen source: " + entry["frozen_path"])
        rows.append({**entry, **metrics(path)})
    minimum = {key: min(row[key] for row in rows) for key in COORDINATES}
    frontier = []
    for row in rows:
        dominated = any(
            all(other[key] <= row[key] for key in COORDINATES)
            and any(other[key] < row[key] for key in COORDINATES)
            for other in rows
        )
        row["pareto_frontier"] = not dominated
        if not dominated:
            frontier.append(row["frozen_path"])
    result = {
        "repository": manifest["repository"],
        "commit": manifest["commit"],
        "snapshot_url": manifest["snapshot_url"],
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "archive_count": manifest["archive_count"],
        "program_count": len(rows),
        "selection": manifest["selection"],
        "metric_source": "Unchanged comparison/source_measure.py from ipra_clausal_kernel_2026-11-08.zip",
        "coordinatewise_minimum": minimum,
        "minimum_attainers": {
            key: [row["frozen_path"] for row in rows if row[key] == minimum[key]]
            for key in COORDINATES
        },
        "pareto_frontier": frontier,
        "programs": rows,
        "interpretation": "Finite-corpus source measurements, not a mathematical lower bound on possible iPRA theories or checkers.",
    }
    (ROOT / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    columns = ("archive", "source_path", *COORDINATES, "raw_bytes", "pareto_frontier", "sha256")
    with (ROOT / "results.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({key: result[key] for key in (
        "commit", "python", "archive_count", "program_count",
        "coordinatewise_minimum", "pareto_frontier")}, indent=2))


if __name__ == "__main__":
    main()
