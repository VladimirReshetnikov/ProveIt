CURRENT DRAFT AUDIT
===================

Snapshot: ProveIt commit 6fac3001a902d6666186fc4692a96de0ef296cf7.
The current docs/drafts directory contains six ZIP archives and nine
checker*.py programs directly at their extracted roots. All nine are
included. Historical comparators nested within these archives are not
current proposals. The readable normalized-elimination checker is included
because it is a complete root acceptance program.

Run:
    python3 audit.py

This verifies every frozen program's SHA-256 and writes results.json and
results.csv. The metric implementation in source_measure.py is copied
UNCHANGED from comparison/source_measure.py in the clausal-kernel archive.
It removes genuine docstrings, parses and unparses the complete Python
program, and counts normalized lexical tokens, AST nodes, and UTF-8 bytes.
Imports, input/output, and rejection remain in the principal measure.
The common Python runtime and its standard library are outside this
source boundary, exactly as in the supplied drafts. Raw source sizes and
SHA-256 values are also recorded.

Current coordinatewise minima:
    322 normalized tokens / 350 AST nodes / 903 normalized bytes.

The minima do not belong to one program. Five programs are Pareto
undominated: boxed-witnesses checker.py (322/355/903), context-blocks
checker.py (324/350/954), clausal-kernel checker.py (326/351/938),
context-pairs checker.py (325/352/952), and context-pairs
checker_exact_list.py (325/354/948). The other four programs are dominated.
Removing them does not change the coordinatewise minima.

All six current reports compare a preceding five-archive, ten-program
snapshot, whose stated minima are 328/356/957. Those figures must not be
used as the current target. These are observed finite-corpus minima, not
a proved universal lower bound on theory or proof-checker complexity.

MATHEMATICAL AUDIT
------------------

All six drafts inherit the same arithmetic foundation: one numerical
sort; 0, successor, initialized scalar iteration; and two computation
schemas. The auxiliary logic has equations, unary closure Q, and the
paired binder D, with five inference patterns: Hyp, DI, QE, DE, and
equality transport. DI permits its induction hypothesis only when its
matrix is literally an equation. All ordinary intuitionistic first-order
connectives are subsequently reconstructed using arithmetic gates and
formula selectors.

The ordinary realization is a staged first-order theory T_I with the
iterator computation equations, equation induction, numerical coverage
x=0 or x=S(y), and the essential falsity bridge 0=S0 -> bottom. Its
interpretation of D is

    D_(x,y) B(x,y) = exists x (B(x,0) -> forall y B(x,y)).

The scalar bootstrap constructs predecessor, then successor injectivity,
quantifier-free reflection, pairing/projections, and finally every fixed
primitive-recursive description. The written proofs explicitly hold
parameters fixed during internal induction. Internal recursion uniqueness
then supplies identity composites for the two whole-domain interpretations.
This audit found no immediate circularity in those arguments; that is not
a proof-assistant verification of their universal claims.

Two structural changes are already present in the corpus. Normalized
elimination eliminates primitive Q by D with an unused witness. Clausal
kernel uses reusable contextual clauses, giving one logical constructor
and four primitive inference patterns. Its delivered small checker still
implements the auxiliary five-pattern certificate language; its source
savings therefore do not measure a direct four-pattern implementation.

For the D-only language, every formula is literally a linear chain
D^k(s=t). Flattening this to a rank and two terms is a valid syntactic
normalization. It does not by itself prove a smaller checker. A direct
prefix/clausal prototype is assessed separately in ../logic_prefix.

The basic semantic regression pair is especially useful:
    D(0=S0) is a theorem, because its constant matrix is assumed as base.
    0=S0 is not thereby a theorem: elimination must still prove the base.
Likewise, induction is permitted at remaining prefix rank zero, not at
every chain merely because its final leaf is an equation.

ATTRIBUTION AND REPRODUCTION
----------------------------

frozen/ contains unmodified source copies from the six named repository
drafts. Their supplied license and attribution files are copied into
licenses/. manifest.json records the ZIP Git blob identities, archive
SHA-256 values, source locations, and individual checker SHA-256 values.
The archive bytes were checked against git ls-tree at the pinned commit
before extraction. The audit script is new; the measurement implementation
and frozen comparator programs are inherited from the indicated drafts.

No claim is made that a significant foundational breakthrough or a
strictly smaller validated iPRA checker was obtained by this audit.
