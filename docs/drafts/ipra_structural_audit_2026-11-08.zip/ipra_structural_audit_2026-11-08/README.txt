iPRA: canonical contexts and a fixed-seed obstruction
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date)

STATUS
The requested construction below the current complexity frontier has NOT
been obtained. The report contains proved structural reductions, a broad
fixed-initializer term-expressiveness obstruction, and fully disclosed
negative implementation measurements. It must not be described as a new
minimum or a successful positive breakthrough.

MAIN FILES
  ipra_structural_audit.pdf   Compiled report.
  ipra_structural_audit.tex   Main LaTeX source.
  sections/                  New mathematical results and comparison.
  appendices/                Attributed inherited arithmetic development.
  prototypes/                Three standalone direct proof checkers and tests.
  comparison/                All nine frozen current checkers, original metric,
                             source identities, results, and audit cases.
  reproduce.py               Re-run measurements and the four diagnostic suites.
  ATTRIBUTION.txt             Provenance and distinction of old/new results.
  MANIFEST.json              SHA-256 identities for the completed package.

REPRODUCTION
From this directory, with CPython 3.12 and assertions enabled:
  python3 reproduce.py

To rebuild the paper, using standard TeX Live packages:
  latexmk -pdf -interaction=nonstopmode -halt-on-error ipra_structural_audit.tex

The report was built with pdfLaTeX. The checkers use only Python's standard
library. Do not run the direct checkers with Python's -O flag: assertions
are part of their explicit validation code and their execution contract.
No project-specific runtime, theorem oracle, or external producer is imported
by any standalone checker. The tests are finite diagnostics, not a formal
proof of soundness or a proof-assistant formalization.

PINNED REPOSITORY
  VladimirReshetnikov/ProveIt
  6fac3001a902d6666186fc4692a96de0ef296cf7
  docs/drafts, six current ZIPs, nine root checker programs.

CURRENT ENVELOPE
  322 normalized Python tokens / 350 AST nodes / 903 normalized bytes.
  Five nondominated programs; the minima occur in different programs.

CANDIDATES
  checker_prefix.py            613 / 709 / 2215
  checker_atomic_transport.py  605 / 700 / 2184
  checker_canonical.py         680 / 785 / 2381

STRONGEST MATHEMATICAL OBSTRUCTION
Any collection of unary functions, constants, and projections closed under
composition and fixed-seed scalar iteration with passive parameters remains
almost unary. Addition, maximum, injective pairing, and a general numerical
selector therefore have no term definitions in that language. The result
also allows finite-range initializers and survives scalar bijective recoding.
This is NOT a theorem excluding every relational interpretation or domain
change; the report explains this limitation explicitly.
