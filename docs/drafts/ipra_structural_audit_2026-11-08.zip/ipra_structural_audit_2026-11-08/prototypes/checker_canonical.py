"""Direct checker for D-prefix iPRA.

A formula [d,s,t] means d nested paired binders over s=t. A term is a
(nonnegative bound or negative eigenparameter) integer, [] for zero,
[t] for successor, or [n,a,h] for initialized scalar iteration. The update
h binds slot zero. All replacements are closed in the de Bruijn slots.
The final input array item is a closed goal. Earlier items are consumed
in reverse order as instructions: [], [0,clause,witness], [1,witness],
[2,major], [3,equation,[left_motive,right_motive]]. A context contains only numerical formula families B, with the implicit
clause B(0) implies B(t). Local ordinary assumptions F are stored as G_y F. No producer or proof library is trusted.
"""
import json, sys
fresh = 0


def term(a, replacement=None, depth=0):
    if type(a) is int:
        if fresh <= a < depth:
            return a
        assert a == depth and replacement is not None
        return replacement
    assert type(a) is list and len(a) in (0, 1, 3)
    return [term(b, replacement, depth + (len(a) == 3 and i == 2))
            for i, b in enumerate(a)]


def formula(a):
    d, s, t = a
    assert type(d) is int and d >= 0
    return [d, term(s, depth=2*d), term(t, depth=2*d)]


def inst(a, t, offset=0):
    d, s, r = a
    return [d, term(s, t, 2*d + offset), term(r, t, 2*d + offset)]


def shift(a, depth=0):
    if type(a) is int:
        return a + (a >= depth)
    return [shift(b, depth + (len(a) == 3 and i == 2))
            for i, b in enumerate(a)]


def gate(a):
    d, s, t = a
    return [d, [2*d, [], shift(s)], [2*d, [], shift(t)]]


def check(a, context):
    global fresh
    a = formula(a)
    match take():
        case []:
            d, left, right = a
            assert d == 0
            n, initial, update = left
            if n:
                n, = n
                initial = term(update, [n, initial, update])
            return right == initial
        case [0, index, witness]:
            assert type(index) is int and 0 <= index < len(context)
            family = context[index]
            return a == inst(family, term(witness)) and check(inst(family, []), context)
        case [1, witness]:
            d, s, t = a
            assert d > 0
            family = inst([d-1, s, t], term(witness), 1)
            base = inst(family, [])
            fresh -= 1
            local = [gate(base)]
            if d == 1:
                local += [gate(inst(family, fresh))]
            return check(inst(family, [fresh]), context + local)
        case [2, major] if check(major, context):
            d, s, t = formula(major)
            assert d > 0
            fresh -= 1
            family = inst([d-1, s, t], fresh, 1)
            return check(a, context + [family])
        case [3, major, motive] if check(major, context):
            d, s, t = formula(major)
            assert d == 0
            motive = [0, *motive]
            return a == inst(motive, t) and check(inst(motive, s), context)


try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
