"""Focused soundness-regression cases for the direct prefix prototype."""
import json, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parent
H=[0,[[],[],[]],[]]

def run(goal,instructions):
    packet=list(reversed(instructions))+[goal]
    p=subprocess.run([sys.executable,str(ROOT/'checker_prefix.py')],input=json.dumps(packet),text=True,capture_output=True)
    return p.returncode==0

def refl(t):
    r=[[],t,[]]
    major=[0,r,t]
    motive=[0,0,t]
    return [[3,major,motive],[],[]]

cases=[]
cases.append(('I0',run(H,[[]]),True))
cases.append(('reflexivity',run([0,[[]],[[]]],refl([[]])),True))
cases.append(('DI equality',run([1,0,0],[[1,[]]]+refl([-1])),True))
cases.append(('constant clause',run([1,1,1],[[1,[]],[0,0,[]],[]]),True))
major=[1,0,0]
instructions=[[2,major],[1,[]]]+refl([-1])+[[0,0,[]]]+refl([])
cases.append(('DE canonical clause',run([0,[],[]],instructions),True))
d_false=[1,[],[[]]]
d_false_proof=[[1,[]],[0,0,[]],[]]
cases.append(('vacuous false closure theorem',run(d_false,d_false_proof),True))
cases.append(('false closure cannot supply its base',run([0,[],[[]]],[[2,d_false]]+d_false_proof+[[0,0,[]],[]]),False))
cases.append(('false computation',run([0,[],[[]]],[[]]),False))
cases.append(('free eigenparameter',run([0,-1,-1],refl(-1)),False))
cases.append(('free bound index',run([0,0,0],refl(0)),False))
cases.append(('negative prefix',run([-1,[],[]],[[]]),False))
cases.append(('boolean prefix',run([False,[],[]],[[]]),False))
cases.append(('invalid term arity',run([0,[[],[]],[]],[[]]),False))
cases.append(('nonatomic computation',run([1,[[],[],[]],[]],[[]]),False))
cases.append(('missing context clause',run([0,[],[]],[[0,0,[]]]),False))
for name,got,want in cases:
    assert got==want,(name,got,want)
print(json.dumps({'passed':len(cases),'cases':[name for name,_,_ in cases]},indent=2))
