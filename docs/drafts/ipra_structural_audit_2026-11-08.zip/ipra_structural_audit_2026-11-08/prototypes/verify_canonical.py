"""Focused checks of canonical clauses, including genuine equation induction."""
import json, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parent
Z=[]
ONE=[Z]

def packrun(goal,instructions):
    packet=list(reversed(instructions))+[goal]
    p=subprocess.run([sys.executable,str(ROOT/'checker_canonical.py')],input=json.dumps(packet),text=True,capture_output=True)
    return p.returncode==0

def eq(s,t,instructions):
    return ([0,s,t],instructions)

def comp(s,t):
    return eq(s,t,[[]])

def refl(t):
    r=[[],t,[]]
    major=[0,r,t]
    return eq(t,t,[[3,major,[0,t]],[],[]])

def sym(p):
    a,steps=p
    _,s,t=a
    return eq(t,s,[[3,a,[0,s]]]+steps+refl(s)[1])

def trans(p,q):
    a,pa=p;b,pb=q
    assert a[2]==b[1]
    return eq(a[1],b[2],[[3,b,[a[1],0]]]+pb+pa)

def gate0(s,t):
    left=[[],[],s]
    right=[[],[],t]
    return trans(comp(left,[]),sym(comp(right,[])))

def ordinary_hyp(s,t,index):
    left=[ONE,[],s]
    right=[ONE,[],t]
    use=eq(left,right,[[0,index,ONE]]+gate0(s,t)[1])
    # Equality left=s turns left=right into s=right.
    mid=eq(s,right,[[3,[0,left,s],[0,right]],[]]+use[1])
    # Equality right=t turns s=right into s=t.
    return eq(s,t,[[3,[0,right,t],[s,0]],[]]+mid[1])

cases=[]
def expect(name,goal,instructions,want=True):
    actual=packrun(goal,instructions)
    assert actual==want,(name,actual,want)
    cases.append(name)

expect('I0',[0,[[],[],[]],[]],[[]])
p=refl(ONE);expect('atomic transport reflexivity',*p)
expect('DI reflexive equation',[1,0,0],[[1,[]]]+refl([-1])[1])
expect('gated ordinary assumption',[1,1,1],[[1,[]]]+ordinary_hyp([],[],0)[1])
D_FALSE=[1,[],ONE]
D_FALSE_STEPS=[[1,[]]]+ordinary_hyp([],ONE,0)[1]
expect('false closure theorem',D_FALSE,D_FALSE_STEPS)
expect('false closure does not yield false',[0,[],ONE],[[2,D_FALSE]]+D_FALSE_STEPS+[[0,0,[]],[]],False)
major=[1,0,0]
steps=[[2,major],[1,[]]]+refl([-1])[1]+[[0,0,ONE]]+refl([])[1]
expect('canonical DE instance',[0,ONE,ONE],steps)
# Equation induction: I(n,0;u.u)=0. The step genuinely uses the IH.
previous=[-1,[],0]
following=[[-1],[],0]
ih=ordinary_hyp(previous,[],1)
reverse_step=sym(comp(following,previous))
step=eq(following,[],[[3,reverse_step[0],[0,[]]]]+reverse_step[1]+ih[1])
expect('induction using gated hypothesis',[1,[0,[],0],[]],[[1,[]]]+step[1])
expect('two prefix levels',[2,0,0],[[1,[]],[1,[]]]+refl([-2])[1])
# Compound gate extraction: DI -1, zero-gate proof DI -2, DE -3, DI -4.
gated_major=[1,[ONE,[],1],[ONE,[],1]]
major_steps=[[0,0,ONE],[1,[]]]+refl([[],[],[-2]])[1]
sz=[-4]
left=[ONE,[],sz]
source_steps=[[0,1,sz]]+refl([ONE,[],[]])[1]
mid_steps=[[3,[0,left,sz],[0,left]],[]]+source_steps
ungated_steps=[[3,[0,left,sz],[sz,0]],[]]+mid_steps
compound_steps=[[1,[]],[2,gated_major]]+major_steps+[[1,-3]]+ungated_steps
expect('compound gated assumption extraction',[2,0,0],compound_steps)
# Bound logical variables occur below a numerical iterator binder; gate shifts them.
expect('logical variable under iterator',[2,[0,[],1],[0,[],1]],[[1,[]],[1,[]]]+refl([[-2],[],[-2]])[1])
expect('captured iterator variable rejected',[2,[0,[],1],[0,[],1]],[[1,[]],[1,[]]]+refl([[-2],[],0])[1],False)
expect('false computation',[0,[],ONE],[[]],False)
expect('undeclared eigenparameter',[0,-1,-1],refl(-1)[1],False)
expect('free bound slot',[0,0,0],refl(0)[1],False)
expect('negative prefix',[-1,[],[]],[[]],False)
expect('boolean prefix',[False,[],[]],[[]],False)
expect('invalid numerical arity',[0,[[],[]],[]],[[]],False)
expect('nonatomic computation',[1,[[],[],[]],[]],[[]],False)
print(json.dumps({'passed':len(cases),'cases':cases},indent=2))
