"""Reproduce the finite comparison and diagnostic suites without network access."""
import hashlib
import importlib.util
import json
import platform
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run_json(relative):
    completed = subprocess.run(
        [sys.executable, str(ROOT / relative)], cwd=ROOT,
        text=True, capture_output=True, check=True,
    )
    return json.loads(completed.stdout)


def main():
    if not __debug__:
        raise RuntimeError("Run with assertions enabled; do not use Python -O.")
    audit = run_json("comparison/audit.py")
    specification = importlib.util.spec_from_file_location(
        "inherited_source_measure", ROOT / "comparison/source_measure.py"
    )
    measure = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(measure)
    prototypes = []
    for filename in (
        "checker_prefix.py", "checker_atomic_transport.py", "checker_canonical.py"
    ):
        path = ROOT / "prototypes" / filename
        prototypes.append({"file": "prototypes/" + filename, **measure.metrics(path)})
    suites = {}
    for relative in (
        "prototypes/verify_prefix.py",
        "prototypes/verify_atomic_transport.py",
        "prototypes/verify_canonical.py",
        "comparison/audit_prefix_safety.py",
    ):
        suites[relative] = run_json(relative)
    keys = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    envelope = audit["coordinatewise_minimum"]
    result = {
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "assertions_enabled": __debug__,
        "source_commit": audit["commit"],
        "baseline": audit,
        "prototypes": prototypes,
        "suites": suites,
        "all_suites_passed": True,
        "any_prototype_below_all_coordinates": any(
            all(row[key] < envelope[key] for key in keys) for row in prototypes
        ),
        "status": "Equivalent structural candidates; requested size improvement not achieved.",
        "verification_scope": "Written mathematical proofs and finite diagnostics; no Lean/Rocq formalization.",
    }
    (ROOT / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({
        "source_commit": result["source_commit"],
        "envelope": envelope,
        "prototypes": [{"file": p["file"], **{k: p[k] for k in keys}} for p in prototypes],
        "suite_pass_counts": {name: value["passed"] for name, value in suites.items()},
        "status": result["status"],
    }, indent=2))


if __name__ == "__main__":
    main()
