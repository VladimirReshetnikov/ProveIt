"""Generate measured LaTeX macros and compile the report with pdflatex."""

import json
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def metric_macros():
    native = json.loads((ROOT / "native/verification.json").read_text())["source_metrics"]
    hilbert = json.loads((ROOT / "hilbert/verification.json").read_text())["source_metrics"]
    nd = json.loads((ROOT / "natural_deduction/test_results.json").read_text())["metrics"]
    families = [
        ("Native", native["checker.py"]),
        ("NativeBaseline", native["baseline.py"]),
        ("Hilbert", hilbert["checker.py"]),
        ("HilbertBaseline", hilbert["baseline.py"]),
        ("ND", nd["checker.py"]),
        ("NDBaseline", nd["baseline_checker.py"]),
    ]
    keys = {
        "Bytes": "raw_source_bytes",
        "CodeBytes": "canonical_code_bytes",
        "Tokens": "significant_python_tokens",
        "AST": "python_ast_nodes",
        "Lines": "canonical_nonblank_lines",
    }
    values = {
        prefix + suffix: item[key]
        for prefix, item in families
        for suffix, key in keys.items()
    }
    values["HilbertSaving"] = hilbert["candidate_saving"]["raw_source_bytes"]
    values["NDSaving"] = nd["baseline_minus_proposal"]["raw_source_bytes"]
    values["NativeSaving"] = native["candidate_saving"]["raw_source_bytes"]
    values["NativeVsFrozenSaving"] = hilbert["checker.py"]["raw_source_bytes"] - native["checker.py"]["raw_source_bytes"]
    macros = "".join(
        "\\newcommand{\\" + name + "}{" + str(value) + "}\n"
        for name, value in values.items()
    )
    (ROOT / "artifacts/metrics.tex").write_text(macros)
    return values


def main():
    if shutil.which("pdflatex") is None:
        raise SystemExit("pdflatex is required to rebuild report.pdf")
    (ROOT / "artifacts").mkdir(exist_ok=True)
    values = metric_macros()
    outputs = []
    for number in range(1, 4):
        process = subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
             "-file-line-error", "report.tex"],
            cwd=ROOT,
            capture_output=True,
            text=True,
        )
        outputs.append(process.stdout + process.stderr)
        if process.returncode != 0:
            (ROOT / "artifacts/build_output.txt").write_text("\n".join(outputs))
            raise SystemExit("LaTeX failed; see artifacts/build_output.txt")
    final_log = (ROOT / "report.log").read_text()
    result = {
        "latex_passes": 3,
        "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
        "overfull_boxes": re.findall(r"Overfull .*", final_log),
        "undefined_references": "There were undefined references" in final_log,
        "metrics": values,
    }
    (ROOT / "artifacts/build_output.txt").write_text("\n".join(outputs))
    (ROOT / "artifacts/build_results.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
