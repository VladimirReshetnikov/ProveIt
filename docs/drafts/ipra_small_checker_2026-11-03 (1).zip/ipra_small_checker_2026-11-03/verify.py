"""Regenerate and check the supplied certificates; collect exact measurements."""

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(relative):
    completed = subprocess.run(
        [sys.executable, str(ROOT / relative)],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=True,
    )
    return completed.stdout


def collect():
    logs = {}
    for family in ("native", "hilbert", "natural_deduction"):
        logs[family + "_certificates"] = run(family + "/certificates.py")
        logs[family + "_tests"] = run(family + "/test_checkers.py")
    native = json.loads((ROOT / "native/verification.json").read_text())
    hilbert = json.loads((ROOT / "hilbert/verification.json").read_text())
    nd = json.loads((ROOT / "natural_deduction/test_results.json").read_text())
    result = {
        "native_named_checks": native["named_checks"],
        "native_all_passed": native["all_tests_passed"],
        "native_metrics": native["source_metrics"],
        "native_certificate_lines": native["certificates"],
        "hilbert_named_checks": hilbert["named_checks"],
        "hilbert_all_passed": hilbert["all_tests_passed"],
        "natural_deduction_checks": nd["tests_passed"],
        "hilbert_metrics": hilbert["source_metrics"],
        "natural_deduction_metrics": nd["metrics"],
        "hilbert_certificate_lines": hilbert["certificates"],
        "scope": "Execution checks and measured source size, not a formal soundness proof.",
    }
    destination = ROOT / "artifacts"
    destination.mkdir(exist_ok=True)
    (destination / "verification_summary.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    (destination / "test_stdout.json").write_text(json.dumps(logs, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    collect()
