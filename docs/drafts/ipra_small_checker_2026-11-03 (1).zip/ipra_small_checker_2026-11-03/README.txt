A SMALLER COMPLETE PROOF CHECKER FOR iPRA
=======================================
3 November 2026

MAIN RESULT
-----------

This package gives a complete small Hilbert presentation of intuitionistic
primitive recursive arithmetic, actual Python proof checkers, explicit proof
certificates, and a full mathematical report.

Preferred checker: native/checker.py (6,013 source bytes).
Matched native baseline: native/baseline.py (6,358 bytes).
The controlled logical reduction is 345 source bytes, 64 significant Python
tokens, 63 Python AST nodes, and four pattern-match cases.

Native arithmetic binders and de Bruijn quantifiers share one substitution
routine. This saves another 1,013 raw bytes compared with the reduced
frozen-descriptor Hilbert checker (7,026 bytes). The mathematical report proves
the necessary elaboration and substitution-coherence theorems; no elaborator
is called by the small checker.

An independent natural-deduction implementation gives the same reduction:
7,488 versus 7,850 bytes, with a controlled saving of 362 bytes.

The small kernel represents logical falsity by q := 0=S0. Its complete theory
uses positive intuitionistic first-order logic, formula equality substitution,
initialized primitive recursion, and equation-indexed successor closure.
Reflexivity and explosion are derived. The ordinary theory with genuine
falsity is recovered conservatively by q <-> bottom; it is fully
bi-interpretable with first-order iPRA with quantifier-free induction.

This is not an absolute optimality theorem over all proof languages or all
programming conventions. It is a complete attainable checker and a controlled
improvement over the shared core of the six current proposals.

CONTENTS
--------

report.pdf                 Full paper, including every logical/nonlogical
                           schema and rule, arithmetic reconstruction,
                           full round trips, comparison, and limitations.
report.tex + sections/      Complete compilable LaTeX source.
native/SPECIFICATION.txt    Preferred complete theory and certificate format.
native/checker.py           Preferred standalone trusted checker.
native/baseline.py          Matched native baseline.
native/certificates/        Nine actual Hilbert proof certificates.
native/test_checkers.py     Tests and exact source-size measurements.
native/verification.json    Executed results: 62 named checks pass.
native/INDEPENDENT_REVIEW.txt Separate implementation review.
native/substitution_probe.py Independent finite binding-substitution probes.
hilbert/SPECIFICATION.txt   Frozen reference theory and certificate format.
hilbert/checker.py          Frozen-descriptor Hilbert checker.
hilbert/baseline.py         Matched conventional baseline.
hilbert/certificates.py     Untrusted producer of explicit proofs.
hilbert/certificates/       Nine genuine axiom/MP/Gen theorem certificates.
hilbert/test_checkers.py    Validation and reproducible size measurements.
hilbert/verification.json   Executed results and exact metrics.
natural_deduction/         Independent complete proof-tree implementation,
                           its matched baseline, five substantive certificates,
                           test suite, results, and detailed README.
verify.py                  Rerun all three suites and aggregate measurements.
build.py                   Regenerate metric macros and compile the paper.
artifacts/                 Aggregate results, build logs, independent review,
                           and PDF inspection summary.
provenance/                Pinned source manifest, six archive hashes, and
                           draft comparison.
SHA256SUMS.txt              Checksums for all other delivered files.

REPRODUCE
---------

Python 3.10 or later is required for structural pattern matching.
The checkers use only the standard library.

From this package directory:

  python3 verify.py

To check one concrete proof in the preferred format:

  python3 native/checker.py < native/certificates/constructor_coverage.json

To regenerate the nine native Hilbert certificates:

  python3 native/certificates.py

To rerun the independent 2,400 finite substitution probes:

  python3 native/substitution_probe.py

The natural-deduction format differs and includes an explicit context.
For example:

  python3 natural_deduction/checker.py \
    < natural_deduction/certificates/derived_explosion_quantified.json

The checker CLIs print ACCEPT or REJECT and return status 0 or 1.
See the corresponding specification/README for every certificate constructor.

To rebuild the PDF, with pdflatex and the packages named in report.tex:

  python3 build.py

The original PDF is included, so LaTeX is unnecessary for reading or testing.

TRUST AND MATHEMATICAL SCOPE
---------------------------

All mathematical checking is contained in the selected standalone checker.
Proof producers, comparison programs, tests, and this report are not imported
by the checker. The standard Python/JSON runtime is common to the comparison.
The designated contradiction is explicitly charged as the FALSITY constant.

The algorithms use finite structural recursion and a forward scan of proofs.
Python can reject valid inputs exceeding its recursion limit. Memory exhaustion
or operating-system termination can stop the process without printing REJECT.
Rejection is not a proof of mathematical unprovability.

Written proofs establish the general mathematical claims. Executed tests
exercise the implementations but are not a Lean/Rocq formalization or a
machine-checked proof of the Python kernels' soundness.

The positive singleton-model caveat is addressed explicitly in the paper:
ordinary bi-interpretability is asserted for the stated genuine-falsity
realization, and the kernel checks exactly its translated proof system.
Consistency of the kernel means nonderivability of q.

SOURCES
-------

The six current drafts were read at ProveIt commit
3c85f4fc1c678b20fd7bbb44f9f5c17362baab8e.
Their exact paths, Git blob identifiers, verified SHA-256 hashes, and pinned
URLs are in provenance/source_manifest.json. All six archive bytes matched
their Git blob hashes. The repository was not modified.
