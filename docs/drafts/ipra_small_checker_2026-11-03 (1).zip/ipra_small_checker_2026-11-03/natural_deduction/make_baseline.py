"""Emit the exact matched ND baseline; this generator is not a checker."""

from pathlib import Path


source = Path(__file__).with_name("checker.py").read_text()
source = source.replace(
    'FALSITY = ["=", ["0"], ["S", ["0"]]]', 'FALSITY = ["false"]'
)
source = source.replace(
    'def formula(node):\n    match node:\n',
    'def formula(node):\n    match node:\n'
    '        case ["false"]:\n            return True\n'
)
source = source.replace(
    '    raise Invalid\n\n\n' + 'def check(document):',
    '        case ["refl", value]:\n'
    '            require(term(value))\n'
    '            return ["=", value, value]\n'
    '        case ["abort", result, premise]:\n'
    '            require(formula(result) and infer(premise, context) == FALSITY)\n'
    '            return result\n'
    '        case ["sep"]:\n'
    '            return ["imp", ["=", ["0"], ["S", ["0"]]], FALSITY]\n'
    '    raise Invalid\n\n\ndef check(document):'
)
Path(__file__).with_name("baseline_checker.py").write_text(source)
