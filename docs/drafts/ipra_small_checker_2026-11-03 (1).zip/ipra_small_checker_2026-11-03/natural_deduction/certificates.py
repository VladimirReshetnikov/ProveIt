"""Untrusted certificate construction; every output is checked by checker.py."""

import json
from pathlib import Path

import checker as kernel


ZERO = ["0"]


def var(index):
    return ["v", index]


def succ(value):
    return ["S", value]


def eq(left, right):
    return ["=", left, right]


def rec(update, counter, initial, *parameters):
    return ["R", update, counter, initial, *parameters]


def names(node):
    if node[0] == "v":
        return {node[1]}
    if node[0] in ("all", "ex"):
        return {node[1]} | names(node[2])
    if node[0] == "R":
        return set().union(*(names(value) for value in node[2:]))
    return set().union(*(names(value) for value in node[1:]))


def fresh(*nodes):
    return 1 + max(set().union({-1}, *(names(node) for node in nodes)))


def reflexive(value):
    computation = ["compute", rec(var(1), ZERO, value)]
    placeholder = fresh(value)
    return ["eq", computation, placeholder, eq(var(placeholder), value), computation]


def symmetric(proof, context):
    _, left, right = kernel.infer(proof, context)
    placeholder = fresh(left, right, *context)
    return ["eq", proof, placeholder, eq(var(placeholder), left), reflexive(left)]


def transitive(first, second, context):
    _, left, middle = kernel.infer(first, context)
    _, repeated, right = kernel.infer(second, context)
    if middle != repeated:
        raise ValueError("Mismatched transitivity endpoints")
    placeholder = fresh(left, middle, right, *context)
    return ["eq", second, placeholder, eq(left, var(placeholder)), first]


def congruence(proof, placeholder, template, context):
    _, left, _ = kernel.infer(proof, context)
    instance = kernel.substitute(template, {placeholder: left})
    return ["eq", proof, placeholder, eq(instance, template), reflexive(instance)]


def collapse(value, context, contradiction_index):
    """From context[contradiction_index] = (0=S0), prove value=0."""
    placeholder = fresh(value, *context)
    left_call = rec(var(1), ZERO, value)
    right_call = rec(var(1), succ(ZERO), value)
    bridge = congruence(
        ["hyp", contradiction_index], placeholder,
        rec(var(1), var(placeholder), value), context
    )
    first = transitive(symmetric(["compute", left_call], context), bridge, context)
    return transitive(first, ["compute", right_call], context)


def explosion(target, context, contradiction_index):
    """Compile the structural admissibility proof of explosion into a tree."""
    tag = target[0]
    if tag == "=":
        left = collapse(target[1], context, contradiction_index)
        right = collapse(target[2], context, contradiction_index)
        return transitive(left, symmetric(right, context), context)
    if tag == "and":
        return ["pair", explosion(target[1], context, contradiction_index),
                explosion(target[2], context, contradiction_index)]
    if tag == "or":
        return ["in", 0, target[2], explosion(target[1], context, contradiction_index)]
    if tag == "imp":
        return ["lam", target[1], explosion(
            target[2], context + [target[1]], contradiction_index
        )]
    if tag == "all":
        eigenvariable = fresh(target, *context)
        instance = kernel.substitute(target[2], {target[1]: var(eigenvariable)})
        return ["all", target, eigenvariable,
                explosion(instance, context, contradiction_index)]
    if tag == "ex":
        instance = kernel.substitute(target[2], {target[1]: ZERO})
        return ["pack", target, ZERO, explosion(instance, context, contradiction_index)]
    raise ValueError("Not a positive formula")


def record(goal, proof, context=None):
    result = {"context": context or [], "goal": goal, "proof": proof}
    if not kernel.check(result):
        raise ValueError("Generated certificate was rejected")
    return result


def examples():
    x, y = var(0), var(1)
    result = {"derived_reflexivity": record(eq(x, x), reflexive(x))}

    assumption = eq(succ(x), succ(y))
    context = [assumption]
    placeholder = fresh(*context)
    bridge = congruence(
        ["hyp", 0], placeholder, rec(var(1), var(placeholder), ZERO), context
    )
    first = transitive(symmetric(["compute", rec(var(1), succ(x), ZERO)], context),
                       bridge, context)
    conclusion = transitive(first, ["compute", rec(var(1), succ(y), ZERO)], context)
    result["successor_injective"] = record(
        ["imp", assumption, eq(x, y)], ["lam", assumption, conclusion]
    )

    predecessor = rec(var(1), x, ZERO)
    equation = eq(succ(predecessor), x)
    boundary = ["or", eq(x, ZERO), equation]
    successor_equation = kernel.substitute(equation, {0: succ(x)})
    placeholder = fresh(equation)
    progress = congruence(["compute", rec(var(1), succ(x), ZERO)],
                          placeholder, succ(var(placeholder)), [boundary])
    universal_progress = ["all", 0, ["imp", boundary, successor_equation]]
    progress_proof = ["all", universal_progress, 0, ["lam", boundary, progress]]
    result["predecessor_coverage"] = record(
        ["all", 0, boundary], ["app", ["closure", 0, equation], progress_proof]
    )

    target = ["all", 0, ["ex", 1, ["and",
        ["or", eq(x, y), eq(x, ZERO)],
        ["imp", eq(succ(x), ZERO), ["all", 2, eq(var(2), y)]]
    ]]]
    context = [kernel.FALSITY, eq(x, ZERO)]
    result["derived_explosion_quantified"] = record(
        target, explosion(target, context, 0), context
    )

    # A genuinely nested descriptor with a frozen inner local variable 1.
    update = rec(var(1), var(1), var(0))
    call = rec(update, succ(x), y)
    previous = rec(update, x, y)
    expected = eq(call, rec(var(1), x, previous))
    result["frozen_nested_descriptor"] = record(expected, ["compute", call])
    return result


if __name__ == "__main__":
    destination = Path(__file__).with_name("certificates")
    destination.mkdir(exist_ok=True)
    for name, document in examples().items():
        (destination / (name + ".json")).write_text(json.dumps(document, indent=2) + "\n")
        print(name + ": ACCEPT")
