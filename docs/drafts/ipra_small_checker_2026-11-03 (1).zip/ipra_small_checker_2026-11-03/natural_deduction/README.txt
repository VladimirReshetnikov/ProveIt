EXECUTABLE NATURAL-DEDUCTION CHECKERS
===================================

checker.py is the proposed checker. baseline_checker.py is a matched
implementation of the common unfiltered draft calculus. Both are standalone
Python 3.10+ programs using only json and sys from the standard library.

Run a certificate:
  python3 checker.py < certificates/predecessor_coverage.json

Reproduce every certificate and the comparison:
  python3 make_baseline.py
  python3 certificates.py
  python3 test_checkers.py

Only checker.py (or, separately, baseline_checker.py) is trusted to accept
proofs. The constructors, baseline generator, tests, metrics, and JSON
certificates are untrusted inputs or tools. The matched baseline is delivered
as a complete independent source file; it does not call the proposed checker.

DESIGNATED FALSITY

The proposed checker's FALSITY constant is the equation 0=S0. It is charged
in all size measurements, although no inference rule special-cases it.
The mathematical consistency statement uses this designated formula.
The one-element model of the purely positive presentation is therefore not
a model with its designated falsity false. Ordinary first-order equivalence
is obtained by the report's conservative expansion identifying 0=S0 with
genuine intuitionistic falsity.

NUMERICAL SYNTAX

Terms are finite JSON trees:
  ["v", i]                  free numerical variable, i a nonnegative integer
  ["0"]                     zero
  ["S", t]                  successor
  ["R", h, n, a, c1, ...]   initialized primitive recursion

For m displayed parameters, h's active variable indices must be less than
m+2. Its slots are 0=previous state, 1=counter, and 2,...,m+1=parameters.
The symbol is determined by the frozen descriptor h and its arity. Distinct
declared arities with an identical update are permitted. Unused slots and
identity updates are permitted, avoiding normalization or support tests.

Every descriptor is finite syntax. Nested R descriptors have independent
local slots. Substitution and free-variable analysis traverse a call's actual
arguments but never its frozen label. There is no numerical program code,
universal evaluator, cyclic declaration, or semantic-equivalence test.

FORMULAS

  ["=", s, t]
  ["and", A, B], ["or", A, B], ["imp", A, B]
  ["all", i, A], ["ex", i, A]

Quantifier i binds the numerical variable ["v",i]. Only free occurrences
are substituted. An attempted substitution that captures a variable is
rejected. Fresh variable names suffice for every legitimate derivation;
alpha-renaming is derivable using the stated quantifier rules, not supplied
by an uncharged equality oracle.

INPUT AND PROOF CONSTRUCTORS

An input has exactly three fields:
  {"context": [A,...], "goal": B, "proof": p}

The checker validates the context and goal, infers the conclusion of p, and
compares the two finite trees literally. Contexts are lists; assumptions can
be reused, and rule premises retain the entire context. Thus contraction,
exchange up to index changes, and weakening by proof freshening are
admissible and require no separate trusted rule.

Proof constructors, with the current context G:

  ["hyp", k]
      Infer G[k]; k must be a nonnegative integer in range.

  ["pair", p, q]
      Infer A AND B from p:A and q:B.

  ["proj", k, p]
      From p:A AND B infer component k, where k is 0 or 1.

  ["in", k, B, p]
      From p:A infer A OR B if k=0, and B OR A if k=1.

  ["case", p, q, r]
      From p:A OR B, check q under G,A and r under G,B. Their inferred
      conclusions must be literally equal; infer that common conclusion.

  ["lam", A, p]
      If p under G,A infers B, infer A IMPLIES B.

  ["app", p, q]
      From p:A IMPLIES B and q:A infer B.

  ["all", Q, j, p]
      Q must be forall i A. The numerical eigenvariable j must be free
      in neither Q nor G. Check p:A[j/i] and infer Q.

  ["at", p, t]
      From p:forall i A infer A[t/i], provided substitution is capture free.

  ["pack", Q, t, p]
      Q must be exists i A. Check p:A[t/i] and infer Q.

  ["unpack", p, j, q]
      From p:exists i A, check q:B under G,A[j/i]. The eigenvariable j
      must be free in neither G, exists i A, nor B. Infer B.

  ["eq", p, i, A, q]
      From p:s=t and q:A[s/i], infer A[t/i]. Both substitutions must be
      capture free. A is any formula. Reflexivity is not a primitive rule.

  ["compute", t]
      t must be an R call with counter syntactically 0 or S n. Infer
      t=a in the zero case, and
      t=h(R_h(n,a,c),n,c) in the successor case. This is one defining
      equation, never an arbitrary evaluation or normalization.

  ["closure", i, E]
      E must be a single equation. Let D be (i=0 OR E). Infer
      [forall i (D IMPLIES E[Si/i])] IMPLIES forall i D.
      Other active free variables are unrestricted numerical parameters.
      These open axiom instances are equivalent to universal closures.

The baseline alone additionally admits ["false"] as a formula and:
  ["refl", t]               infer t=t
  ["abort", A, p]           from p:false infer A
  ["sep"]                  infer (0=S0) IMPLIES false

These three proof branches, the falsity syntax branch, and the designated
formula data are the complete difference between the measured checkers.
The extra filters/normalizers in optimized draft variants are not silently
counted as free; the baseline uses their simpler unfiltered common core.

VALIDATION AND LIMITS

The included 44 tests check real certificates for reflexivity, successor
injectivity, predecessor coverage, quantified explosion, and frozen nested
descriptors. They also check all positive logical rule families and reject
capture, escaping eigenvariables, wrong implication premises, disagreeing
case branches, malformed descriptors, non-equational closure requests,
invalid variable and hypothesis indices, and malformed proof constructors.
Checks remain active under Python -O: the kernel uses no Python assertions.

The mathematical algorithm is structural recursion over finite syntax and
finite proof trees. The concrete Python implementation rejects excessive
recursion depth rather than accepting unchecked input. Like every concrete
program it is subject to interpreter and memory limits. The tests are not
a Lean/Rocq verification or a formal proof of checker soundness.

SIZE MEASUREMENTS

Every byte of each standalone checker, including syntax validation,
substitution, designated falsity, the arithmetic schema generators, and
the JSON command-line interface, is counted. The shared Python runtime and
standard library are common to both implementations.

At the delivered revision:
                           proposed    baseline    reduction
  full UTF-8 source bytes      7488        7850          362
  canonical code bytes        6777        7139          362
  canonical nonblank lines     146         156           10
  significant Python tokens   1545        1616           71
  Python AST nodes            1664        1736           72
  match cases                   24          28            4

Canonical code removes docstrings, runs ast.unparse, and appends one newline.
Token counts omit comments, layout, encoding, and end-marker tokens.
All metrics and individual test outcomes are regenerated in test_results.json.
These are controlled implementation comparisons, not a theorem asserting an
absolute minimum over all programming languages, encodings, or architectures.
