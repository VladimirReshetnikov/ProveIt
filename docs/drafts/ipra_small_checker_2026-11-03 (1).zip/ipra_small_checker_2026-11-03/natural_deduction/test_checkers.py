"""Focused soundness-boundary tests and reproducible source-size accounting."""

import ast
import copy
import io
import json
import subprocess
import sys
import tokenize
from pathlib import Path

import baseline_checker as baseline
import certificates as build
import checker


HERE = Path(__file__).parent
ZERO = build.ZERO
V = build.var
S = build.succ
E = build.eq
R = build.rec


def document(goal, proof, context=None):
    return {"context": context or [], "goal": goal, "proof": proof}


def size_metrics(path):
    source = path.read_text()
    tree = ast.parse(source)
    for node in ast.walk(tree):
        body = getattr(node, "body", None)
        if isinstance(body, list) and body and isinstance(body[0], ast.Expr):
            value = body[0].value
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                del body[0]
    canonical = ast.unparse(tree) + "\n"
    ignored = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.INDENT,
               tokenize.DEDENT, tokenize.NEWLINE, tokenize.NL, tokenize.COMMENT}
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(canonical).readline)
              if t.type not in ignored]
    return {
        "raw_source_bytes": len(source.encode()),
        "canonical_code_bytes": len(canonical.encode()),
        "canonical_nonblank_lines": sum(bool(line.strip()) for line in canonical.splitlines()),
        "significant_python_tokens": len(tokens),
        "python_ast_nodes": sum(1 for _ in ast.walk(tree)),
        "match_cases": sum(isinstance(node, ast.match_case) for node in ast.walk(tree)),
    }


def main():
    results = []

    def test(name, data, expected, implementation=checker):
        actual = implementation.check(data)
        if actual != expected:
            raise SystemExit(f"{name}: expected {expected}, got {actual}")
        results.append({"name": name, "checker": implementation.__name__,
                        "expected_accept": expected, "actual_accept": actual})

    for name, data in build.examples().items():
        test(name, data, True)
        test(name + "_baseline", data, True, baseline)

    a, b = E(V(0), ZERO), E(V(1), ZERO)
    test("conjunction_exchange", document(["and", b, a],
        ["pair", ["proj", 1, ["hyp", 0]], ["proj", 0, ["hyp", 0]]],
        [["and", a, b]]), True)
    test("disjunction_exchange", document(["or", b, a],
        ["case", ["hyp", 0], ["in", 1, b, ["hyp", 1]],
         ["in", 0, a, ["hyp", 1]]], [["or", a, b]]), True)
    universal = ["all", 0, ["all", 1, E(V(0), V(1))]]
    test("capture_free_specialization", document(["all", 1, E(V(2), V(1))],
        ["at", ["hyp", 0], V(2)], [universal]), True)
    existential = ["ex", 0, a]
    renamed = ["ex", 1, b]
    test("existential_bound_renaming", document(renamed,
        ["unpack", ["hyp", 0], 7, ["pack", renamed, V(7), ["hyp", 1]]],
        [existential]), True)

    test("primitive_reflexivity_removed", document(E(ZERO, ZERO), ["refl", ZERO]), False)
    test("primitive_reflexivity_baseline", document(E(ZERO, ZERO), ["refl", ZERO]),
         True, baseline)
    test("primitive_falsity_removed", document(["false"], ["hyp", 0], [["false"]]), False)
    test("primitive_explosion_baseline", document(a, ["abort", a, ["hyp", 0]],
         [["false"]]), True, baseline)
    separation = ["imp", checker.FALSITY, ["false"]]
    test("separation_removed", document(separation, ["sep"]), False)
    test("separation_baseline", document(separation, ["sep"]), True, baseline)

    test("descriptor_out_of_scope", document(E(ZERO, ZERO),
        ["compute", R(V(2), ZERO, ZERO)]), False)
    test("nested_descriptor_out_of_scope", document(E(ZERO, ZERO),
        ["compute", R(R(V(3), V(0), V(1)), ZERO, ZERO)]), False)
    test("nonconstructor_computation", document(E(ZERO, ZERO),
        ["compute", R(V(1), V(0), ZERO)]), False)
    test("quantified_induction_forbidden", document(E(ZERO, ZERO),
        ["closure", 0, ["all", 1, E(V(0), V(1))]]), False)
    test("nonequational_induction_forbidden", document(E(ZERO, ZERO),
        ["closure", 0, ["or", a, b]]), False)
    test("negative_hypothesis_index", document(a, ["hyp", -1], [a]), False)
    test("boolean_hypothesis_index", document(a, ["hyp", False], [a]), False)
    test("boolean_variable_index", document(E(V(True), ZERO), ["hyp", 0],
        [E(V(True), ZERO)]), False)
    test("negative_variable_index", document(E(V(-1), ZERO), ["hyp", 0],
        [E(V(-1), ZERO)]), False)
    test("unknown_proof_constructor", document(a, ["magic", a]), False)
    test("extra_proof_fields", document(E(ZERO, ZERO),
        ["compute", R(V(1), ZERO, ZERO), "ignored"]), False)

    quantified = ["all", 0, a]
    test("universal_eigenvariable_in_context", document(quantified,
        ["all", quantified, 7, ["hyp", 0]], [E(V(7), ZERO)]), False)
    leaking = ["all", 0, E(V(0), V(7))]
    test("universal_eigenvariable_in_conclusion", document(leaking,
        ["all", leaking, 7, build.reflexive(V(7))]), False)
    test("universal_substitution_capture", document(["all", 1, E(V(1), V(1))],
        ["at", ["hyp", 0], V(1)], [universal]), False)
    test("existential_witness_escape", document(E(V(7), ZERO),
        ["unpack", ["hyp", 0], 7, ["hyp", 1]], [existential]), False)
    open_existential = ["ex", 0, E(V(0), V(7))]
    test("existential_eigenvariable_in_context", document(E(ZERO, ZERO),
        ["unpack", ["hyp", 0], 7, build.reflexive(ZERO)], [open_existential]), False)
    template = ["all", 1, E(V(0), V(1))]
    test("equality_substitution_capture", document(["all", 1, E(V(1), V(1))],
        ["eq", ["hyp", 0], 0, template, ["hyp", 1]],
        [E(V(0), V(1)), template]), False)
    test("modus_ponens_mismatch", document(b,
        ["app", ["hyp", 0], ["hyp", 1]], [["imp", a, b], b]), False)
    test("case_branches_disagree", document(a,
        ["case", ["hyp", 0], ["hyp", 1], ["hyp", 1]], [["or", a, b]]), False)

    malformed = copy.deepcopy(build.examples()["derived_reflexivity"])
    malformed["untrusted_override"] = True
    test("unexpected_document_field", malformed, False)
    test("malformed_document", [], False)
    cycle = ["S"]
    cycle.append(cycle)
    test("cyclic_python_object_rejected", document(E(cycle, ZERO), ["magic"]), False)

    # Python -O must not remove kernel checks. Certificates never use Python eval.
    good = build.examples()["predecessor_coverage"]
    bad = document(quantified, ["all", quantified, 7, ["hyp", 0]], [E(V(7), ZERO)])
    for name, data, status in [("optimized_python_accept", good, 0),
                               ("optimized_python_reject", bad, 1)]:
        process = subprocess.run([sys.executable, "-O", str(HERE / "checker.py")],
            input=json.dumps(data), text=True, capture_output=True, check=False)
        if process.returncode != status:
            raise SystemExit(name + ": unexpected exit status")
        results.append({"name": name, "exit_status": process.returncode,
                        "stdout": process.stdout.strip()})

    metrics = {name: size_metrics(HERE / name)
               for name in ["checker.py", "baseline_checker.py"]}
    metrics["baseline_minus_proposal"] = {
        key: metrics["baseline_checker.py"][key] - metrics["checker.py"][key]
        for key in metrics["checker.py"]
    }
    report = {
        "tests_passed": len(results), "tests": results, "metrics": metrics,
        "scope": "Executable certificate and rejection tests, not a formal soundness proof."
    }
    (HERE / "test_results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"tests_passed": len(results), "metrics": metrics}, indent=2))


if __name__ == "__main__":
    main()
