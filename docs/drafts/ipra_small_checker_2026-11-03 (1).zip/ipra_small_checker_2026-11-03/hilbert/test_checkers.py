"""Certificate tests, soundness-boundary rejections, and source-size accounting."""

import ast
import io
import json
import random
import subprocess
import sys
import tokenize
from pathlib import Path

import baseline
import certificates as build
import checker


HERE = Path(__file__).parent
ZERO, ONE = build.ZERO, build.ONE
V, S, E, I, R = build.var, build.successor, build.equal, build.implies, build.recursor


def document(goal, *records):
    return {"goal": goal, "proof": list(records)}


def size_metrics(path):
    source = path.read_text()
    tree = ast.parse(source)
    for node in ast.walk(tree):
        body = getattr(node, "body", None)
        if isinstance(body, list) and body and isinstance(body[0], ast.Expr):
            value = body[0].value
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                del body[0]
    canonical = ast.unparse(tree) + "\n"
    ignored = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.INDENT,
               tokenize.DEDENT, tokenize.NEWLINE, tokenize.NL, tokenize.COMMENT}
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(canonical).readline)
              if t.type not in ignored]
    return {
        "raw_source_bytes": len(source.encode()),
        "canonical_code_bytes": len(canonical.encode()),
        "canonical_nonblank_lines": sum(bool(line.strip()) for line in canonical.splitlines()),
        "significant_python_tokens": len(tokens),
        "python_ast_nodes": sum(1 for _ in ast.walk(tree)),
        "match_cases": sum(isinstance(node, ast.match_case) for node in ast.walk(tree)),
    }


def main():
    results = []

    def test(name, data, expected, implementation=checker):
        actual = implementation.check(data)
        if actual != expected:
            raise SystemExit(f"{name}: expected {expected}, got {actual}")
        results.append({"name": name, "checker": implementation.__name__,
                        "expected_accept": expected, "actual_accept": actual})

    examples = build.examples()
    for name, data in examples.items():
        test(name, data, True)
        test(name + "_baseline", data, True, baseline)

    zz, a, b = E(ZERO, ZERO), E(V(0), ZERO), E(V(1), ZERO)
    test("primitive_reflexivity_removed", document(zz, ["reflexivity", ZERO]), False)
    test("primitive_reflexivity_baseline", document(zz, ["reflexivity", ZERO]), True, baseline)
    test("primitive_false_removed", document(I(["false"], a), ["false_elim", a]), False)
    test("primitive_false_baseline", document(I(["false"], a), ["false_elim", a]),
         True, baseline)
    separation = I(checker.FALSITY, ["false"])
    test("separation_removed", document(separation, ["separation"]), False)
    test("separation_baseline", document(separation, ["separation"]), True, baseline)

    call = R(V(2), ZERO, ZERO)
    test("descriptor_parameter_out_of_scope", document(E(call, ZERO), ["compute", call]), False)
    nested = R(R(V(2), V(0), V(1), V(0)), ZERO, ZERO)
    test("nested_descriptor_separate_scope", document(E(nested, ZERO), ["compute", nested]), True)
    invalid_nested = R(R(V(3), V(0), V(1), V(0)), ZERO, ZERO)
    test("nested_descriptor_invalid_scope", document(E(invalid_nested, ZERO),
         ["compute", invalid_nested]), False)
    call = R(V(0), ZERO, ONE, V(42))
    test("unused_parameters_and_identity_update_allowed", document(E(call, ONE),
         ["compute", call]), True)
    call = R(V(1), V(0), ZERO)
    test("nonconstructor_computation_rejected", document(E(call, ZERO), ["compute", call]), False)

    body = ["all", 1, E(V(0), V(1))]
    expected = I(["all", 0, body], ["all", 1, E(V(2), V(1))])
    test("capture_free_universal_elimination", document(expected,
         ["forall_elim", 0, body, V(2)]), True)
    wrong = I(["all", 0, body], ["all", 1, E(V(1), V(1))])
    test("universal_elimination_capture", document(wrong,
         ["forall_elim", 0, body, V(1)]), False)
    wrong = I(["all", 1, E(V(1), V(1))], ["ex", 0, body])
    test("existential_introduction_capture", document(wrong,
         ["exists_intro", 0, body, V(1)]), False)
    vacuous = ["all", 1, E(V(2), V(1))]
    test("vacuous_substitution_ignores_irrelevant_capture", document(
        I(["all", 0, vacuous], vacuous), ["forall_elim", 0, vacuous, V(1)]), True)

    wrong = I(["all", 0, I(a, zz)], I(a, ["all", 0, zz]))
    test("universal_shift_free_guard", document(wrong, ["forall_shift", 0, a, zz]), False)
    wrong = I(["all", 0, I(zz, a)], I(["ex", 0, zz], a))
    test("existential_shift_free_conclusion", document(wrong,
         ["exists_shift", 0, zz, a]), False)
    wrong = I(E(V(0), V(1)), I(body, ["all", 1, E(V(1), V(1))]))
    test("equality_substitution_capture", document(wrong,
         ["equality", 0, body, V(0), V(1)]), False)

    call = R(V(0), ZERO, V(0))
    equation = E(call, V(0))
    instantiated = E(R(V(0), ZERO, V(7)), V(7))
    test("substitution_preserves_frozen_descriptor", document(instantiated,
        ["compute", call], ["gen", 0, 0],
        ["forall_elim", 0, equation, V(7)], ["mp", 2, 1]), True)

    quantified = ["all", 1, a]
    boundary = ["or", E(V(0), ZERO), quantified]
    successor = ["all", 1, E(S(V(0)), ZERO)]
    goal = I(["all", 0, I(boundary, successor)], ["all", 0, boundary])
    test("quantified_closure_matrix_rejected", document(goal,
         ["closure", 0, quantified]), False)
    nonequation = ["or", a, b]
    boundary = ["or", E(V(0), ZERO), nonequation]
    successor = ["or", E(S(V(0)), ZERO), b]
    goal = I(["all", 0, I(boundary, successor)], ["all", 0, boundary])
    test("propositional_closure_matrix_rejected", document(goal,
         ["closure", 0, nonequation]), False)

    call = build.selector(ZERO, ZERO)
    computation = E(call, ZERO)
    test("modus_ponens_mismatch", document(I(b, a),
         ["logic", 0, a, b, zz], ["compute", call], ["mp", 0, 1]), False)
    test("forward_reference_rejected", document(computation,
         ["gen", 0, 1], ["compute", call]), False)
    test("negative_reference_rejected", document(["all", 0, computation],
         ["compute", call], ["gen", 0, -1]), False)
    test("boolean_reference_rejected", document(["all", 0, computation],
         ["compute", call], ["gen", 0, False]), False)
    test("boolean_variable_rejected", document(["all", True, computation],
         ["compute", call], ["gen", True, 0]), False)
    test("negative_variable_rejected", document(E(V(-1), V(-1)),
         ["reflexivity", V(-1)]), False, baseline)
    s_instance = I(I(a, I(b, zz)), I(I(a, b), I(a, zz)))
    test("boolean_schema_index_rejected", document(s_instance,
         ["logic", True, a, b, zz]), False)
    test("out_of_range_schema_rejected", document(I(a, I(b, a)),
         ["logic", 8, a, b, zz]), False)
    test("malformed_unused_schema_parameter", document(I(a, I(b, a)),
         ["logic", 0, a, b, None]), False)
    test("extra_record_fields_rejected", document(computation,
         ["compute", call, "ignored"]), False)
    test("unknown_rule_rejected", document(a, ["magic", a]), False)
    test("empty_proof_rejected", document(zz), False)
    test("extra_document_fields_rejected", {"goal": computation,
         "proof": [["compute", call]], "context": []}, False)

    rng = random.Random(20261103)
    atoms = [None, False, True, -1, 0, 1, 2, "v", "=", "R", "logic", "mp", "gen"]

    def random_json(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return rng.choice(atoms)
        return [random_json(depth - 1) for _ in range(rng.randrange(7))]

    for _ in range(3000):
        data = document(zz, random_json(4))
        if checker.check(data):
            raise SystemExit("An unstructured fuzz record unexpectedly established 0=0")
    results.append({"name": "3000_malformed_records_terminate_and_reject", "passed": True})

    encoded = json.dumps(examples["constructor_coverage"])
    for flags in ([], ["-O"]):
        run = subprocess.run([sys.executable, *flags, str(HERE / "checker.py")],
                             input=encoded, text=True, capture_output=True, check=False)
        if run.returncode != 0 or run.stdout.strip() != "ACCEPT":
            raise SystemExit("CLI certificate check failed")
    run = subprocess.run([sys.executable, str(HERE / "checker.py")], input="{broken",
                         text=True, capture_output=True, check=False)
    if run.returncode != 1 or run.stdout.strip() != "REJECT":
        raise SystemExit("Malformed JSON was not rejected by the CLI")
    results.append({"name": "cli_normal_optimized_and_malformed_json", "passed": True})

    metrics = {name: size_metrics(HERE / name) for name in ("checker.py", "baseline.py")}
    metrics["candidate_saving"] = {
        key: metrics["baseline.py"][key] - metrics["checker.py"][key]
        for key in metrics["checker.py"]
    }
    report = {"all_tests_passed": True, "named_checks": len(results), "tests": results,
              "source_metrics": metrics,
              "certificates": {name: len(data["proof"]) for name, data in examples.items()},
              "scope": "Finite execution checks; universal soundness and bi-interpretability "
                       "are mathematical proofs, not consequences of the tests."}
    (HERE / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"named_checks": len(results), "source_metrics": metrics}, indent=2))


if __name__ == "__main__":
    main()
