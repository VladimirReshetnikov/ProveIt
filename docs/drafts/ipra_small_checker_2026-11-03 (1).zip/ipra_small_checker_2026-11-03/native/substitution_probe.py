"""Independent finite semantic probes of the native de Bruijn substitution lemma."""

import importlib.util
import json
import random
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location("native_checker", ROOT / "checker.py")
kernel = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kernel)
rng = random.Random(20261103)


class Exhausted(Exception):
    pass


def evaluate(node, environment, budget):
    budget[0] -= 1
    if budget[0] < 0:
        raise Exhausted
    tag = node[0]
    if tag == "v":
        return environment[node[1]]
    if tag == "0":
        return 0
    if tag == "S":
        return 1 + evaluate(node[1], environment, budget)
    if tag == "R":
        counter = evaluate(node[1], environment, budget)
        if counter > 20:
            raise Exhausted
        state = evaluate(node[2], environment, budget)
        for index in range(counter):
            state = evaluate(node[3], (state, index, *environment), budget)
        return state
    if tag == "=":
        return evaluate(node[1], environment, budget) == evaluate(node[2], environment, budget)
    if tag == "and":
        return evaluate(node[1], environment, budget) and evaluate(node[2], environment, budget)
    if tag == "or":
        return evaluate(node[1], environment, budget) or evaluate(node[2], environment, budget)
    if tag == "imp":
        return not evaluate(node[1], environment, budget) or evaluate(node[2], environment, budget)
    if tag == "all":
        return all(evaluate(node[1], (value, *environment), budget) for value in range(3))
    if tag == "ex":
        return any(evaluate(node[1], (value, *environment), budget) for value in range(3))
    raise ValueError(node)


def term(depth):
    choice = rng.randrange(4 if depth else 2)
    if choice == 0:
        return ["v", rng.randrange(6)]
    if choice == 1:
        return ["0"]
    if choice == 2:
        return ["S", term(depth - 1)]
    counter = ["0"]
    for _ in range(rng.randrange(4)):
        counter = ["S", counter]
    if rng.randrange(3) == 0:
        counter = ["v", rng.randrange(3)]
    return ["R", counter, term(depth - 1), term(depth - 1)]


def formula(depth):
    choice = rng.randrange(6 if depth else 1)
    if choice == 0:
        return ["=", term(3), term(3)]
    if choice in (1, 2, 3):
        return [["and", "or", "imp"][choice - 1], formula(depth - 1), formula(depth - 1)]
    return [["all", "ex"][choice - 4], formula(depth - 1)]


def main():
    counts = Counter()
    skipped = 0
    for kind in ("term", "formula"):
        for protected in range(4):
            for width in range(4):
                accepted = 0
                while accepted < 75:
                    node = term(4) if kind == "term" else formula(3)
                    values = [term(3) for _ in range(width)]
                    extra = rng.randrange(4)
                    target_environment = tuple(rng.randrange(4) for _ in range(40))
                    transformed = kernel.substitute(node, values, extra, protected)
                    try:
                        replacement_values = tuple(
                            evaluate(value, target_environment[protected:], [100000])
                            for value in values
                        )
                        source_environment = (
                            target_environment[:protected] + replacement_values
                            + target_environment[protected + extra:]
                        )
                        left = evaluate(node, source_environment, [100000])
                        right = evaluate(transformed, target_environment, [100000])
                    except Exhausted:
                        skipped += 1
                        continue
                    if left != right:
                        failure = {"kind": kind, "node": node, "values": values,
                                   "depth": protected, "extra": extra,
                                   "transformed": transformed,
                                   "environment": target_environment,
                                   "left": left, "right": right}
                        raise RuntimeError(json.dumps(failure))
                    if not (kernel.term(transformed) if kind == "term"
                            else kernel.formula(transformed)):
                        raise RuntimeError("Substitution produced malformed syntax")
                    accepted += 1
                    counts[f"{kind}:depth={protected}:prefix={width}"] += 1
    report = {
        "all_passed": True, "accepted_semantic_checks": sum(counts.values()),
        "skipped_evaluation_budget": skipped, "buckets": dict(counts),
        "scope": "Independent finite probes of the substitution lemma, not a proof. "
                 "Quantifiers are evaluated over {0,1,2} solely for substitution identity."
    }
    (ROOT / "substitution_probe_results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
