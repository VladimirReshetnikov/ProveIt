"""Untrusted construction of explicit Hilbert certificates.

The output contains only the axiom records and MP/Gen references checked by
checker.py. These helpers are conveniences; none belongs to the trusted kernel.
"""

import json
from pathlib import Path

import checker


ZERO = ["0"]
ONE = ["S", ZERO]


def var(index):
    return ["v", index]


def successor(value):
    return ["S", value]


def equal(left, right):
    return ["=", left, right]


def implies(left, right):
    return ["imp", left, right]


def recursor(counter, initial, update):
    return ["R", counter, initial, update]


def lift(value, amount=1):
    return checker.substitute(value, [], amount)


def selector(counter, initial):
    return recursor(counter, initial, var(1))


class Proof:
    def __init__(self):
        self.records = []
        self.theorems = []

    def add(self, record, expected=None):
        theorem = checker.infer(record, self.theorems)
        if expected is not None and theorem != expected:
            raise ValueError("The producer constructed an unexpected formula")
        self.records.append(record)
        self.theorems.append(theorem)
        return len(self.records) - 1

    def logic(self, index, a, b, c=None):
        return self.add(["logic", index, a, b, c or equal(ZERO, ZERO)])

    def mp(self, function, argument):
        return self.add(["mp", function, argument])

    def lift(self, theorem, assumption):
        """From a proved A, produce assumption -> A using K and MP."""
        a = self.theorems[theorem]
        return self.mp(self.logic(0, a, assumption), theorem)

    def apply_under(self, function, argument):
        """From G -> (A -> B) and G -> A, produce G -> B using S."""
        guard, implication = self.theorems[function][1:]
        a, b = implication[1:]
        schema = self.logic(1, guard, a, b)
        return self.mp(self.mp(schema, function), argument)

    def identity(self, a):
        first = self.logic(0, a, implies(a, a))
        second = self.logic(0, a, a)
        schema = self.logic(1, a, implies(a, a), a)
        return self.mp(self.mp(schema, first), second)

    def reflexive(self, value):
        """Derive value=value from computation and equality substitution."""
        call = selector(ZERO, value)
        computation = self.add(["compute", call])
        equality = self.add(["equality", equal(var(0), lift(value)), call, value])
        result = self.mp(self.mp(equality, computation), computation)
        if self.theorems[result] != equal(value, value):
            raise ValueError("Reflexivity construction failed")
        return result

    def zero_under_collapse(self, value):
        """Derive (0=S0) -> 0=value without any induction instance."""
        contradiction = equal(ZERO, ONE)
        at_zero, at_one = selector(ZERO, value), selector(ONE, value)
        base = self.add(["compute", at_zero])
        change_counter = self.add([
            "equality", equal(selector(var(0), lift(value)), lift(value)), ZERO, ONE
        ])
        changed = self.apply_under(change_counter, self.lift(base, contradiction))
        successor_case = self.add(["compute", at_one])
        collapse = self.add([
            "equality", equal(var(0), lift(value)), at_one, ZERO
        ])
        collapse = self.mp(collapse, successor_case)
        return self.apply_under(self.lift(collapse, contradiction), changed)

    def collapse(self, left, right):
        """Derive (0=S0) -> left=right from the two Q equations."""
        contradiction = equal(ZERO, ONE)
        zero_left = self.zero_under_collapse(left)
        zero_right = self.zero_under_collapse(right)
        substitution = self.add([
            "equality", equal(var(0), lift(right)), ZERO, left
        ])
        lifted = self.lift(substitution, contradiction)
        return self.apply_under(self.apply_under(lifted, zero_left), zero_right)

    def document(self, goal):
        if not self.theorems or self.theorems[-1] != goal:
            raise ValueError("The final line does not establish the requested goal")
        return {"goal": goal, "proof": self.records}


def examples():
    result = {}
    a, b = equal(var(0), ZERO), equal(var(1), ZERO)

    proof = Proof()
    proof.identity(a)
    result["implication_identity"] = proof.document(implies(a, a))

    proof = Proof()
    reflexive = proof.reflexive(var(0))
    proof.add(["gen", reflexive])
    result["derived_reflexivity"] = proof.document(["all", equal(var(0), var(0))])

    proof = Proof()
    proof.collapse(var(0), var(1))
    result["equation_explosion"] = proof.document(implies(checker.FALSITY,
                                                        equal(var(0), var(1))))

    proof = Proof()
    collapse = proof.collapse(var(0), ZERO)
    generalized = proof.add(["gen", collapse])
    shift = proof.add(["forall_shift", checker.FALSITY, equal(var(0), ZERO)])
    proof.mp(shift, generalized)
    result["universal_explosion"] = proof.document(
        implies(checker.FALSITY, ["all", equal(var(0), ZERO)]))

    proof = Proof()
    conjunction = ["and", a, b]
    project_a = proof.logic(3, a, b)
    project_b = proof.logic(4, a, b)
    introduce = proof.logic(2, b, a)
    lifted = proof.lift(introduce, conjunction)
    proof.apply_under(proof.apply_under(lifted, project_b), project_a)
    result["conjunction_exchange"] = proof.document(implies(conjunction, ["and", b, a]))

    proof = Proof()
    target = ["or", b, a]
    left = proof.logic(6, b, a)
    right = proof.logic(5, b, a)
    eliminate = proof.logic(7, a, b, target)
    proof.mp(proof.mp(eliminate, left), right)
    result["disjunction_exchange"] = proof.document(implies(["or", a, b], target))

    proof = Proof()
    universal, existential = ["all", a], ["ex", a]
    specialize = proof.add(["forall_elim", a, ZERO])
    package = proof.add(["exists_intro", a, ZERO])
    proof.apply_under(proof.lift(package, universal), specialize)
    result["universal_to_existential"] = proof.document(implies(universal, existential))

    proof = Proof()
    xx, zz = equal(var(0), var(0)), equal(ZERO, ZERO)
    reflexive = proof.reflexive(ZERO)
    constant = proof.mp(proof.logic(0, zz, xx), reflexive)
    generalized = proof.add(["gen", constant])
    shift = proof.add(["exists_shift", xx, zz])
    proof.mp(shift, generalized)
    result["existential_elimination"] = proof.document(implies(["ex", xx], zz))

    proof = Proof()
    x = var(0)
    call = selector(successor(x), ZERO)
    equation = equal(successor(selector(x, ZERO)), x)
    next_equation = equal(successor(call), successor(x))
    computation = proof.add(["compute", call])
    reflexive = proof.reflexive(successor(call))
    substitution = proof.add([
        "equality", equal(lift(successor(call)), successor(var(0))), call, x
    ])
    step = proof.mp(proof.mp(substitution, computation), reflexive)
    boundary = ["or", equal(x, ZERO), equation]
    progress = proof.mp(proof.logic(0, next_equation, boundary), step)
    universal_progress = proof.add(["gen", progress])
    closure = proof.add(["closure", equation])
    proof.mp(closure, universal_progress)
    result["constructor_coverage"] = proof.document(["all", boundary])
    return result


if __name__ == "__main__":
    destination = Path(__file__).parent / "certificates"
    destination.mkdir(exist_ok=True)
    for name, document in examples().items():
        (destination / (name + ".json")).write_text(json.dumps(document, indent=2) + "\n")
        print(name, len(document["proof"]), "proof lines")
