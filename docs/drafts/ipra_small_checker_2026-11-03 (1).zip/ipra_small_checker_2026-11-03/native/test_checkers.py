"""Certificate tests, soundness-boundary rejections, and source-size accounting."""

import ast
import io
import json
import random
import subprocess
import sys
import tokenize
from pathlib import Path

import baseline
import certificates as build
import checker


HERE = Path(__file__).parent
ZERO, ONE = build.ZERO, build.ONE
V, S, E, I, R = build.var, build.successor, build.equal, build.implies, build.recursor


def document(goal, *records):
    return {"goal": goal, "proof": list(records)}


def size_metrics(path):
    source = path.read_text()
    tree = ast.parse(source)
    for node in ast.walk(tree):
        body = getattr(node, "body", None)
        if isinstance(body, list) and body and isinstance(body[0], ast.Expr):
            value = body[0].value
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                del body[0]
    canonical = ast.unparse(tree) + "\n"
    ignored = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.INDENT,
               tokenize.DEDENT, tokenize.NEWLINE, tokenize.NL, tokenize.COMMENT}
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(canonical).readline)
              if t.type not in ignored]
    return {
        "raw_source_bytes": len(source.encode()),
        "canonical_code_bytes": len(canonical.encode()),
        "canonical_nonblank_lines": sum(bool(line.strip()) for line in canonical.splitlines()),
        "significant_python_tokens": len(tokens),
        "python_ast_nodes": sum(1 for _ in ast.walk(tree)),
        "match_cases": sum(isinstance(node, ast.match_case) for node in ast.walk(tree)),
    }


def main():
    results = []

    def test(name, data, expected, implementation=checker):
        actual = implementation.check(data)
        if actual != expected:
            raise SystemExit(f"{name}: expected {expected}, got {actual}")
        results.append({"name": name, "checker": implementation.__name__,
                        "expected_accept": expected, "actual_accept": actual})

    def same(name, actual, expected):
        if actual != expected:
            raise SystemExit(f"{name}: unequal syntax trees")
        results.append({"name": name, "passed": True})

    examples = build.examples()
    for name, data in examples.items():
        test(name, data, True)
        test(name + "_baseline", data, True, baseline)

    zz, a, b = E(ZERO, ZERO), E(V(0), ZERO), E(V(1), ZERO)
    test("primitive_reflexivity_removed", document(zz, ["reflexivity", ZERO]), False)
    test("primitive_reflexivity_baseline", document(zz, ["reflexivity", ZERO]), True, baseline)
    test("primitive_false_removed", document(I(["false"], a), ["false_elim", a]), False)
    test("primitive_false_baseline", document(I(["false"], a), ["false_elim", a]),
         True, baseline)
    separation = I(checker.FALSITY, ["false"])
    test("separation_removed", document(separation, ["separation"]), False)
    test("separation_baseline", document(separation, ["separation"]), True, baseline)

    call = R(ZERO, V(0), V(100))
    test("arbitrary_implicit_parameters", document(E(call, V(0)), ["compute", call]), True)
    invalid = ["R", ZERO, ZERO, V(0), V(1)]
    test("recursion_arity_checked", document(E(invalid, ZERO), ["compute", invalid]), False)
    call = R(V(0), ZERO, V(1))
    test("nonconstructor_computation_rejected", document(E(call, ZERO), ["compute", call]), False)
    call = R(S(V(0)), V(1), V(2))
    test("recursion_captured_parameter", document(E(call, V(0)), ["compute", call]), True)
    call = R(S(V(0)), V(1), S(V(0)))
    previous = R(V(0), V(1), S(V(0)))
    test("recursion_state_slot", document(E(call, S(previous)), ["compute", call]), True)

    update = R(V(1), V(0), S(V(2)))
    previous = R(V(0), V(1), update)
    call = R(S(V(0)), V(1), update)
    expected = R(V(0), previous, S(R(V(2), V(3), update)))
    test("nested_recursion_shifts_inserted_state", document(E(call, expected),
         ["compute", call]), True)
    bad = R(V(0), previous, S(previous))
    test("nested_recursion_capture_rejected", document(E(call, bad), ["compute", call]), False)

    body = ["all", E(V(1), V(0))]
    proper = I(["all", body], ["all", E(V(1), V(0))])
    test("quantifier_substitution_avoids_capture", document(proper,
         ["forall_elim", body, V(0)]), True)
    captured = I(["all", body], ["all", E(V(0), V(0))])
    test("captured_universal_instance_rejected", document(captured,
         ["forall_elim", body, V(0)]), False)
    proper = I(["all", E(V(1), V(0))], ["ex", body])
    test("existential_instantiation_avoids_capture", document(proper,
         ["exists_intro", body, V(0)]), True)
    captured = I(["all", E(V(0), V(0))], ["ex", body])
    test("captured_existential_instance_rejected", document(captured,
         ["exists_intro", body, V(0)]), False)
    proper = I(E(V(0), V(1)),
               I(["all", E(V(1), V(0))], ["all", E(V(2), V(0))]))
    test("equality_template_lifts_under_quantifier", document(proper,
         ["equality", body, V(0), V(1)]), True)

    dependent = E(V(0), V(1))
    proper = I(["all", I(b, dependent)], I(a, ["all", dependent]))
    test("universal_sidecondition_built_by_lifting", document(proper,
         ["forall_shift", a, dependent]), True)
    captured = I(["all", I(a, dependent)], I(a, ["all", dependent]))
    test("unlifted_universal_guard_rejected", document(captured,
         ["forall_shift", a, dependent]), False)
    proper = I(["all", I(dependent, b)], I(["ex", dependent], a))
    test("existential_sidecondition_built_by_lifting", document(proper,
         ["exists_shift", dependent, a]), True)
    captured = I(["all", I(dependent, a)], I(["ex", dependent], a))
    test("unlifted_existential_conclusion_rejected", document(captured,
         ["exists_shift", dependent, a]), False)

    same("lift_preserves_local_recursion_slots",
         checker.substitute(R(V(0), V(1), R(V(0), V(2), V(0))), [], 1),
         R(V(1), V(2), R(V(0), V(3), V(0))))
    same("two_slots_pop_and_outer_parameters_reindex",
         checker.substitute(R(V(1), V(2), S(V(4))), [V(7), V(8)]),
         R(V(8), V(0), S(V(2))))
    same("nested_quantifier_and_recursion_cutoffs",
         checker.substitute(["all", E(R(V(0), V(1), V(3)), V(2))], [V(5)]),
         ["all", E(R(V(0), V(6), V(8)), V(1))])

    equation = E(R(V(0), V(1), V(2)), V(1))
    boundary = ["or", E(V(0), ZERO), equation]
    successor = E(R(S(V(0)), V(1), S(V(2))), V(1))
    goal = I(["all", I(boundary, successor)], ["all", boundary])
    test("closure_preserves_parameters_and_changes_captured_counter", document(goal,
         ["closure", equation]), True)
    quantified = ["all", a]
    boundary = ["or", E(V(0), ZERO), quantified]
    goal = I(["all", I(boundary, quantified)], ["all", boundary])
    test("quantified_closure_matrix_rejected", document(goal,
         ["closure", quantified]), False)
    nonequation = ["or", a, b]
    boundary = ["or", E(V(0), ZERO), nonequation]
    successor = ["or", E(S(V(0)), ZERO), b]
    goal = I(["all", I(boundary, successor)], ["all", boundary])
    test("propositional_closure_matrix_rejected", document(goal,
         ["closure", nonequation]), False)

    call = build.selector(ZERO, ZERO)
    computation = E(call, ZERO)
    test("modus_ponens_mismatch", document(I(b, a),
         ["logic", 0, a, b, zz], ["compute", call], ["mp", 0, 1]), False)
    test("forward_reference_rejected", document(computation,
         ["gen", 1], ["compute", call]), False)
    test("negative_reference_rejected", document(["all", computation],
         ["compute", call], ["gen", -1]), False)
    test("boolean_reference_rejected", document(["all", computation],
         ["compute", call], ["gen", False]), False)
    test("boolean_variable_rejected", document(E(V(True), V(True)),
         ["reflexivity", V(True)]), False, baseline)
    test("negative_variable_rejected", document(E(V(-1), V(-1)),
         ["reflexivity", V(-1)]), False, baseline)
    s_instance = I(I(a, I(b, zz)), I(I(a, b), I(a, zz)))
    test("boolean_schema_index_rejected", document(s_instance,
         ["logic", True, a, b, zz]), False)
    test("out_of_range_schema_rejected", document(I(a, I(b, a)),
         ["logic", 8, a, b, zz]), False)
    test("malformed_unused_schema_parameter", document(I(a, I(b, a)),
         ["logic", 0, a, b, None]), False)
    test("extra_record_fields_rejected", document(computation,
         ["compute", call, "ignored"]), False)
    test("named_quantifier_syntax_rejected", document(["all", 0, computation],
         ["compute", call], ["gen", 0]), False)
    test("unknown_rule_rejected", document(a, ["magic", a]), False)
    test("empty_proof_rejected", document(zz), False)
    test("extra_document_fields_rejected", {"goal": computation,
         "proof": [["compute", call]], "context": []}, False)

    rng = random.Random(20261103)
    atoms = [None, False, True, -1, 0, 1, 2, "v", "=", "R", "logic", "mp", "gen"]

    def random_json(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return rng.choice(atoms)
        return [random_json(depth - 1) for _ in range(rng.randrange(7))]

    for _ in range(3000):
        if checker.check(document(zz, random_json(4))):
            raise SystemExit("An unstructured fuzz record unexpectedly established 0=0")
    results.append({"name": "3000_malformed_records_terminate_and_reject", "passed": True})

    encoded = json.dumps(examples["constructor_coverage"])
    for flags in ([], ["-O"]):
        run = subprocess.run([sys.executable, *flags, str(HERE / "checker.py")],
                             input=encoded, text=True, capture_output=True, check=False)
        if run.returncode != 0 or run.stdout.strip() != "ACCEPT":
            raise SystemExit("CLI certificate check failed")
    run = subprocess.run([sys.executable, str(HERE / "checker.py")], input="{broken",
                         text=True, capture_output=True, check=False)
    if run.returncode != 1 or run.stdout.strip() != "REJECT":
        raise SystemExit("Malformed JSON was not rejected by the CLI")
    results.append({"name": "cli_normal_optimized_and_malformed_json", "passed": True})

    metrics = {name: size_metrics(HERE / name) for name in ("checker.py", "baseline.py")}
    metrics["candidate_saving"] = {
        key: metrics["baseline.py"][key] - metrics["checker.py"][key]
        for key in metrics["checker.py"]
    }
    report = {"all_tests_passed": True, "named_checks": len(results), "tests": results,
              "source_metrics": metrics,
              "certificates": {name: len(data["proof"]) for name, data in examples.items()},
              "scope": "Finite execution checks; universal soundness and bi-interpretability "
                       "are mathematical proofs, not consequences of the tests."}
    (HERE / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"named_checks": len(results), "source_metrics": metrics}, indent=2))


if __name__ == "__main__":
    main()


