A SMALLER COMPLETE CHECKER FOR iPRA
Prepared for Vladimir Reshetnikov, 6 November 2026

START HERE

  ipra_premise_kernel_2026-11-06.pdf   Full report and complete primary source
  report.tex + sections/*.tex        Rebuildable LaTeX sources
  code/checker.py                    Recommended genuine-falsity checker
  code/encoded_checker.py            Smaller optional encoded proof presentation

RESULT

  Current smallest draft:      1167 significant tokens, 1252 AST nodes
  Genuine-falsity candidate:   1149 significant tokens, 1230 AST nodes
  Optional encoded candidate:  1110 significant tokens, 1193 AST nodes

All syntax handling, fixed arithmetic data, validation, inference rules and
the CLI are counted. The common Python interpreter and standard library are
outside every count. Comments, docstrings and layout are excluded from the
significant-token and AST columns. Complete raw-byte counts are also provided.

The main mathematical calculus is the best ordinary basis already consolidated
in the current drafts. The new contribution is a smaller complete checker:
four formula annotations are validated by checked premises, with one shared
tuple guard preventing malformed syntax from being repaired by substitution.
The report proves exact equivalence of accepted certificate languages.

The ordinary theory has genuine falsity, is bi-interpretable with full
first-order iPRA with quantifier-free induction, and has the whole number
carrier in both interpretations. Every logical and nonlogical schema and
rule is specified. The report includes the arithmetic reconstruction,
substitution coherence, formula round trips, and further research questions.

ENCODED PRESENTATION

The optional checker represents falsity by 0=S0 and omits the separate
falsity token and bridge. The report proves an exact sequent correspondence
with the genuine-falsity theory. Its ordinary realization is that theory;
the raw positive first-order reduct is not claimed to be ordinarily
bi-interpretable with iPRA. In particular, the singleton-model issue is
explicitly addressed. This optional interface does not weaken the primary
result, which already improves the measured frontier with genuine falsity.

REPRODUCE (Python 3.10+, tested with Python 3.12.14)

  python3 run_checks.py
  python3 verification/independent_boundary_checks.py
  python3 measure.py
  python3 code/checker.py certificates/valid/legacy_reflexivity_derived.json
  python3 code/encoded_checker.py certificates/encoded/legacy_reflexivity_derived.json
  python3 code/encode_certificate.py certificates/valid/nat_false_guard_reindexing.json
  python3 build.py

build.py requires pdflatex and the packages listed in report.tex. It can
generate a local pdflatex format when a minimal TeX installation lacks one.
It compiles three passes, checks for overfull boxes and unresolved references,
and packages the deliverable with a SHA-256 manifest. The build/ directory
contains temporary build files and is excluded from the ZIP.

COMPARISON SOURCES

  Repository: VladimirReshetnikov/ProveIt
  Commit: b079e5787b1d708049ff0643ce1b534c1a225198
  Directory: docs/drafts
  Inputs: all eleven current ZIP archives, verified against Git blob hashes

Two exact frontier control files are included under comparisons/. The full
thirteen-variant inventory covers all eleven archives and charges local
dependencies and CLI adapters. For fresh full-corpus reproduction:

  python3 comparisons/fetch_sources.py --destination /path/to/sources
  python3 measure.py --sources /path/to/sources --all-drafts

The source downloader is optional and public. It checks sizes, Git blob SHAs
and SHA-256 hashes. It does not execute downloaded code. The measurement
script reads selected Python source members directly from verified ZIPs.
Without the source archives it reports unavailable rows, never cached counts.

VALIDATION

  53 original frontier valid certificates, each checked against its source hash
  1 new valid compiler reindexing regression
  All 54 accepted by primary and frontier; all 54 compiled encoded proofs accepted
  28 negative fixtures rejected by each checker
  4 focused valid cases and 12 focused malformed cases
  4 counterexamples to unguarded validator deletion
  10944 bounded reflection operations; 680 wellformed outputs reflected
  12 CLI runs, including Python -O
  6 additional independent boundary probes

These are finite implementation checks. The universal mathematical arguments
are written proofs, not Lean/Rocq formalizations. Neither checker is claimed
to be an absolute minimum across all programming languages or encodings.

CONTENTS

  code/             Two standalone checkers, compiler, targeted tests
  certificates/     Valid, encoded and rejected proof examples
  comparisons/      Verbatim controls, metrics and optional source downloader
  provenance/       Exact archive, source-member and certificate identities
  verification/     Test results, independent review, metrics and PDF checks
  SHA256SUMS.txt    Integrity manifest for all packaged deliverable files

ATTRIBUTION

The frontier controls and original 53 certificate fixtures are from the
pinned ProveIt draft ipra_kernel_2026-11-06.zip. The new checkers modify that
source by exactly the reductions described in the report. Earlier arithmetic
and logical reductions are credited to the inspected draft corpus, including
the encoded-falsity Hilbert presentation from November 3. No new discovery
is claimed for those existing foundations.
