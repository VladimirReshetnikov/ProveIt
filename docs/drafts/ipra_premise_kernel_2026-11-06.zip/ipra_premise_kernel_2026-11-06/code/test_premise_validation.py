"""Focused executable checks of the premise-validation optimization.

The checker never imports this file. The four naive-deletion examples
show that the tuple guard is needed for the stated syntax invariant.
They demonstrate acceptance of malformed annotations, not a derivation
of a false arithmetic theorem. Finite samples supplement the proof of
syntax reflection; they are not a machine-checked universal theorem.
"""

import json
from pathlib import Path
import types

import checker as k


Z = k.ZERO
T = ("=", Z, Z)
BAD_T = ("=", "z", "z")
SIG_T = ("sig", T, T)
H = ("hyp", 0)
REJECTIONS = (ValueError, TypeError, IndexError, KeyError, RecursionError)


def demand(condition, explanation):
    if not condition:
        raise AssertionError(explanation)


def accepted(module, document):
    """Use the same JSON data model and rejection errors as the CLI."""
    document = json.loads(json.dumps(document))
    try:
        return module.check(document) is True
    except REJECTIONS:
        return False


def document(proof, assumptions=(T,), goal=T):
    return {"assumptions": list(assumptions), "goal": goal, "proof": proof}


def naive_checker():
    """A deliberately broken syntax-validation variant used only by tests."""
    source = Path(k.__file__).read_text(encoding="utf-8")
    guard = "    require(type(a) is tuple)\n"
    demand(source.count(guard) == 1, "the shared tuple guard moved")
    module = types.ModuleType("unguarded_counterexample")
    exec(compile(source.replace(guard, ""), "unguarded_counterexample", "exec"),
         module.__dict__)
    return module


def counterexamples():
    bad_pair = ("pair", ("sig", BAD_T, T), Z, H, H)
    bad_let = ("let", ("hyp", 1), BAD_T, H)
    return {
        "equality_template_raw_string": document(("eq", H, BAD_T, H)),
        "induction_template_raw_string": document(("nat", BAD_T, Z, H, H)),
        # The outer elimination discards the malformed first component.
        "sigma_target_raw_string": document(("let", bad_pair, T, ("hyp", 2))),
        # Equality transport subsequently normalizes the malformed result.
        "sigma_conclusion_raw_string": document(
            ("eq", bad_let, ("=", 0, Z), H), (T, SIG_T)),
    }


def local_regressions():
    valid = {
        "equality_template_from_premise": document(("eq", H, ("=", 0, Z), H)),
        "equation_induction_template_from_base": document(("nat", T, Z, H, H)),
        "sigma_target_from_two_premises": document(
            ("pair", SIG_T, Z, H, H), goal=SIG_T),
        "sigma_conclusion_from_branch": document(
            ("let", ("hyp", 1), T, ("hyp", 2)), (T, SIG_T)),
    }
    invalid = {
        "equality_boolean_variable": document(("eq", H, ("=", True, Z), H)),
        "equality_float_variable": document(("eq", H, ("=", 0.0, Z), H)),
        "induction_negative_variable": document(("nat", ("=", -1, Z), Z, H, H)),
        "sigma_target_extra_child": document(
            ("pair", ("sig", T, T, T), Z, H, H), goal=SIG_T),
        "sigma_target_missing_child": document(
            ("pair", ("sig", T), Z, H, H), goal=SIG_T),
        "sigma_conclusion_boolean_variable": document(
            ("let", ("hyp", 1), ("=", True, Z), H), (T, SIG_T)),
        "sigma_conclusion_float_variable": document(
            ("let", ("hyp", 1), ("=", 0.0, Z), H), (T, SIG_T)),
        "empty_template": document(("eq", H, (), H)),
        "unknown_template_tag": document(("eq", H, ("unknown", Z, Z), H)),
        "dictionary_template": document(("eq", H, {"0": "="}, H)),
        "false_used_as_term": document(("eq", H, ("=", k.FALSE, Z), H)),
        "term_used_as_formula": document(("nat", Z, Z, H, H)),
    }
    for name, item in valid.items():
        demand(accepted(k, item), "rejected valid focused example: " + name)
    for name, item in invalid.items():
        demand(not accepted(k, item), "accepted malformed example: " + name)
    return {"accepted": list(valid), "rejected": list(invalid)}


def mutations(node, replacements):
    """Every single-subtree mutation of a small fixed tree family."""
    yield node
    yield from replacements
    if type(node) is tuple:
        for index, child in enumerate(node):
            for replacement in mutations(child, replacements):
                yield (*node[:index], replacement, *node[index + 1:])


def reflection_samples():
    replacements = [None, False, True, 0.0, 1.0, -1, "z", "false", "=", (),
                    {}, {"0": "z"}, ("z", 0), ("=", Z), ("pi", T),
                    ("sig", T, T, T), ("r", Z, Z), ("unknown",)]
    terms = [Z, 0, 1, 10**50, ("s", 0),
             ("r", ("s", 0), 2, ("r", 1, 2, ("s", 0)))]
    formulas = [T, ("=", 0, 1), k.FALSE,
                ("pi", ("=", 0, 1), ("sig", ("=", 1, 2), T)),
                ("=", terms[-1], ("r", 3, Z, 1))]
    checked, completed, wellformed_results = 0, 0, 0
    for formula, trees in ((False, terms), (True, formulas)):
        for seed in trees:
            for original in mutations(seed, replacements):
                operations = [lambda a: k.shift(a), lambda a: k.shift(a, 3)]
                operations += [lambda a, term=term: k.inst(a, term) for term in terms]
                for operation in operations:
                    checked += 1
                    try:
                        result = operation(original)
                    except REJECTIONS:
                        continue
                    completed += 1
                    if k.wf(result, formula):
                        wellformed_results += 1
                        demand(k.wf(original, formula),
                               "syntax reflection counterexample: " + repr(original))
    return {"operations_attempted": checked, "operations_completed": completed,
            "wellformed_outputs_checked": wellformed_results,
            "method": "Fixed term/formula family with single-subtree malformed mutations."}


def run():
    naive = naive_checker()
    examples = counterexamples()
    for name, item in examples.items():
        demand(accepted(naive, item), "naive-deletion counterexample stopped working: " + name)
        demand(not accepted(k, item), "tuple guard failed to reject: " + name)
    result = {
        "naive_deletion_accepts_malformed": list(examples),
        "guarded_checker_rejects_all_four": True,
        "focused_regressions": local_regressions(),
        "reflection_samples": reflection_samples(),
        "scope": "Finite executable checks; universal syntax-reflection proof is in the report.",
    }
    return result


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
