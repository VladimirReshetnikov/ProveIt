"""Untrusted proof compiler: genuine falsity to the designated equation 0=S0.

The encoded checker does not import this module. The compiler checks its input
and output for convenience, but these checks are not part of the proof system.
Extra equation induction hypotheses created by erasure require reindexing every
later hypothesis introduced in that branch.
"""

import json
import sys

import checker
import encoded_checker


def encode(a):
    if a == checker.FALSE:
        return checker.CLASH
    if type(a) is tuple:
        return tuple(encode(child) for child in a)
    return a


def proof(p, mapping, size):
    match p:
        case ("hyp", i):
            return ("hyp", mapping[i])
        case ("bridge", q):
            return proof(q, mapping, size)
        case ("pi", a, q):
            return ("pi", encode(a), proof(q, (*mapping, size), size + 1))
        case ("app", p, t, q):
            return ("app", proof(p, mapping, size), t, proof(q, mapping, size))
        case ("pair", a, t, p, q):
            return ("pair", encode(a), t, proof(p, mapping, size), proof(q, mapping, size))
        case ("let", p, c, q):
            return ("let", proof(p, mapping, size), encode(c),
                    proof(q, (*mapping, size, size + 1), size + 2))
        case ("eq", p, a, q):
            return ("eq", proof(p, mapping, size), encode(a), proof(q, mapping, size))
        case ("rec", r):
            return p
        case ("nat", a, t, p, q):
            extra = int(encode(a)[0] == "=")
            step_map = (*mapping, size) if a[0] == "=" else mapping
            return ("nat", encode(a), t, proof(p, mapping, size),
                    proof(q, step_map, size + extra))
        case _:
            raise ValueError("invalid source proof")


def translate(data):
    checker.check(data)
    g = tuple(map(checker.freeze, data["assumptions"]))
    result = {
        "assumptions": list(map(encode, g)),
        "goal": encode(checker.freeze(data["goal"])),
        "proof": proof(checker.freeze(data["proof"]), tuple(range(len(g))), len(g)),
    }
    encoded_checker.check(result)
    return result


if __name__ == "__main__":
    with open(sys.argv[1], encoding="utf-8") as stream:
        result = translate(json.load(stream))
    print(json.dumps(result, separators=(",", ":")))
