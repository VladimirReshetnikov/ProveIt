"""Independent adversarial and eigenvariable checks for the final kernel."""
import checker as K

z, f = K.ZERO, K.FALSE
T = ("=", z, z)


def eq(a, b):
    return ("=", a, b)


cases = []


def add(name, g, a, p, expected=False):
    cases.append((name, {"assumptions": g, "goal": a, "proof": p}, expected))


# Pi introduction must lift old parameters and cannot capture them.
add("pi_capture", [eq(0, z)], ("pi", T, eq(0, z)), ("pi", T, ("hyp", 0)))
add("pi_valid_parameter_lift", [eq(0, z)], ("pi", T, eq(1, z)),
    ("pi", T, ("hyp", 0)), True)
# A Sigma witness may not escape as an ambient free variable.
S = ("sig", eq(0, z), T)
add("sigma_witness_escape", [S], eq(0, z),
    ("let", ("hyp", 0), eq(0, z), ("hyp", 1)))
add("sigma_valid_closed_goal", [S], T,
    ("let", ("hyp", 0), T, ("hyp", 2)), True)
# Catch escape beneath a native recursor's two bound slots.
H = eq(("r", z, z, 2), z)
SH = ("sig", H, T)
add("sigma_escape_under_rec", [SH], H, ("let", ("hyp", 0), H, ("hyp", 1)))
# Transport protects a Pi-bound variable from capture.
a = ("pi", T, eq(1, 0))
source, dest = K.inst(a, 0), K.inst(a, 1)
add("transport_valid_under_pi", [eq(0, 1), source], dest,
    ("eq", ("hyp", 0), a, ("hyp", 1)), True)
add("transport_capture_under_pi", [eq(0, 1), source], ("pi", T, eq(0, 0)),
    ("eq", ("hyp", 0), a, ("hyp", 1)))
# Transport protects both native recursor slots.
a = H
source, dest = K.inst(a, 0), K.inst(a, 1)
add("transport_valid_under_rec", [eq(0, 1), source], dest,
    ("eq", ("hyp", 0), a, ("hyp", 1)), True)
add("transport_capture_rec_counter", [eq(0, 1), source], eq(("r", z, z, 1), z),
    ("eq", ("hyp", 0), a, ("hyp", 1)))
# A non-equation nat template receives no induction hypothesis.
a = ("pi", T, eq(1, z))
base = K.inst(a, z)
add("non_equation_induction", [base], K.inst(a, 0),
    ("nat", a, 0, ("hyp", 0), ("hyp", 1)))
# Closed bridge recognizes only the exact clash.
add("bridge_reflexive_equation", [T], f, ("bridge", ("hyp", 0)))
add("bridge_reversed_clash", [eq(("s", z), z)], f, ("bridge", ("hyp", 0)))
add("bridge_false_to_clash", [f], K.CLASH, ("bridge", ("hyp", 0)), True)
# One computation clause only: no symbolic unknown-counter evaluation.
r = ("r", 0, z, 0)
add("unknown_recursion_counter", [], eq(r, z), ("rec", r))
# JSON booleans must not masquerade as integer variable/hypothesis indices.
add("boolean_variable", [eq(True, z)], eq(True, z), ("hyp", 0))
add("boolean_hypothesis_index", [T], T, ("hyp", False))
add("negative_variable", [eq(-1, z)], eq(-1, z), ("hyp", 0))
# Large finite free-variable support is intentionally accepted.
add("large_ambient_variable", [eq(10**50, z)], eq(10**50, z), ("hyp", 0), True)


if __name__ == "__main__":
    for name, data, expected in cases:
        try:
            actual = K.check(data)
        except (ValueError, TypeError, IndexError, KeyError, RecursionError):
            actual = False
        assert actual == expected, (name, actual, expected)
    print(f"{len(cases)} independent scope/adversarial cases passed: "
          f"{sum(c[2] for c in cases)} accepted, "
          f"{sum(not c[2] for c in cases)} rejected.")
