"""Retrieve the pinned comparison ZIPs and verify their complete identities.

This optional research utility is outside every trusted proof-checker count.
It never executes or extracts downloaded source and refuses mismatched files.
"""

import argparse
import hashlib
import json
from pathlib import Path
import urllib.request


ROOT = Path(__file__).resolve().parents[1]


def verify(data, item):
    actual = {
        "size_bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob_sha1": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    }
    for key, value in actual.items():
        if value != item[key]:
            raise ValueError(f"Identity mismatch: {item['name']}: {key}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=Path, default=ROOT.parent / "sources")
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    manifest = json.loads((ROOT / "provenance/source_manifest.json").read_text(encoding="utf-8"))
    args.destination.mkdir(parents=True, exist_ok=True)
    for item in manifest["archives"]:
        if Path(item["name"]).name != item["name"]:
            raise ValueError("Archive name is not a single filename")
        path = args.destination / item["name"]
        if path.exists():
            verify(path.read_bytes(), item)
            print("VERIFIED " + item["name"])
            continue
        if args.verify_only:
            raise FileNotFoundError(path)
        with urllib.request.urlopen(item["pinned_download_url"], timeout=60) as response:
            data = response.read(item["size_bytes"] + 1)
        verify(data, item)
        temporary = path.with_name(path.name + ".download")
        temporary.write_bytes(data)
        temporary.replace(path)
        print("FETCHED AND VERIFIED " + item["name"])
    print(f"Verified all {len(manifest['archives'])} pinned archives.")


if __name__ == "__main__":
    main()
