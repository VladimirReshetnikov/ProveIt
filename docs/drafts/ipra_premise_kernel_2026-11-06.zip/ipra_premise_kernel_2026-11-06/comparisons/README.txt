REPRODUCIBLE CHECKER MEASUREMENTS

The complete trusted candidates are code/checker.py and, when supplied,
code/encoded_checker.py. The proof generators, certificate translators,
measurement scripts, tests, and download helper are untrusted utilities;
their output must pass the chosen standalone checker.

Two controls are included verbatim from the pinned source archive:

  frontier.py
    ipra_kernel_2026-11-06/code/checker.py
    1,167 significant source tokens; 1,252 AST nodes; 4,334 raw bytes.

  alternate_frontier.py
    ipra_kernel_2026-11-06/comparisons/previous_k_open_pattern.py
    1,171 significant source tokens; 1,248 AST nodes; 4,170 raw bytes.

Their source hashes are recorded in provenance/draft_inventory.json.
measure.py refuses to measure a changed control under those identities.
The primary candidate is smaller in token and AST counts than both controls.
Its documented raw source can be larger than the alternative control;
raw-byte domination of every prior implementation is not claimed.

To recompute candidate and control measurements, run from this package:

  python3 measure.py

If a sibling sources/ directory contains the pinned ZIP archives, the
same command also measures the current eleven archives. No archived count
is copied from an old JSON result: unavailable source inputs are explicitly
reported as missing. To require the complete comparison:

  python3 measure.py --sources /absolute/path/to/sources --all-drafts

To obtain the exact public comparison inputs first:

  python3 comparisons/fetch_sources.py --destination /absolute/path/to/sources

The helper verifies size, SHA-256, and the Git blob SHA-1 of every complete
ZIP. Existing matching files are reused; existing mismatched files cause
failure. It does not execute or extract downloaded code. --verify-only
checks available archives without network access.

measure.py reads selected Python members directly from the verified ZIPs,
checks each member's recorded SHA-256, and measures their original source.
Every selected local dependency and every CLI adapter is included. The
inventory lists exact source members, static imports, and entry points.
For the configurable small-kernel adapter, the --kernel option selects the
charged module; the entire shared adapter is counted in each variant.

The comparison covers all eleven ZIP archives at ProveIt commit
b079e5787b1d708049ff0643ce1b534c1a225198. There are thirteen archive rows:
one main representative per archive plus the encoded-falsity and bridge
alternatives in D08. Encoded-falsity rows are explicitly marked and their
genuine-falsity realization is not silently treated as free trusted code.

Outputs (all recreated from source on every successful invocation):

  comparisons/metrics.json       Policy, per-file hashes, counts, differences.
  comparisons/metrics.csv        One row per measured complete implementation.
  comparisons/metrics.tex        Numeric macros for available delivered variants.
  comparisons/table.tex          Full comparison table with literal values.
  verification/metrics_table.tex Candidate/control table with literal values.

The main token measure uses Python's tokenize on ORIGINAL source. Comments,
layout, and syntactic module/function/class docstrings are excluded. AST
counts exclude the same docstring statements and include operator/context
nodes. Raw bytes include all documentation and formatting. Token spelling
bytes omit whitespace. Normalized code bytes use ast.unparse after removing
docstrings; this secondary measure can vary with Python version, recorded
in the JSON output. The scripts never reformat source before token counting.

Python and its standard library are common excluded runtime dependencies.
Cross-archive code uses different representations, certificate formats,
and coding conventions. These are reproducible attained implementation
sizes, not invariant mathematical complexity measures or lower-bound
theorems. The two verbatim frontier controls provide the most direct
comparison for the new premise-validation implementation.
