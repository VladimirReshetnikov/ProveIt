import importlib.util,json,pathlib,types,hashlib
root=pathlib.Path(__file__).resolve().parents[1]
p=root/'code/checker.py'
spec=importlib.util.spec_from_file_location('audited_kernel',p)
k=importlib.util.module_from_spec(spec);spec.loader.exec_module(k)
Z=('z',)
E=lambda s,t:('=',s,t)
T=E(Z,Z)
H=lambda i:('hyp',i)
errors=(ValueError,TypeError,IndexError,KeyError,RecursionError)
def accept(mod,d):
    d=json.loads(json.dumps(d))
    try:return mod.check(d) is True
    except errors:return False

def doc(proof,goal,assumptions=()):
    return dict(proof=proof,goal=goal,assumptions=list(assumptions))

def refl(t):
    rec=('rec',('r',Z,t,0))
    return ('eq',rec,E(0,k.shift(t)),rec)

sig=('sig',E(0,0),E(0,Z))
nested=('pi',E(0,0),E(1,1))
legit_let=doc(('let',H(0),nested,H(1)),nested,(sig,nested))
leaked=('pi',E(0,0),E(1,Z))
leak_proof=('let',H(0),leaked,('pi',E(0,0),H(2)))
leak=doc(leak_proof,leaked,(sig,))
source=('pi',E(0,0),E(1,1))
target=('pi',E(0,0),E(('s',1),1))
nested_template=('pi',E(0,0),E(1,2))
transport=doc(('eq',H(0),nested_template,H(1)),target,(E(0,('s',0)),source))
false_alias=doc(H(0),E(False,False),(E(0,0),))
float_alias=doc(H(0),E(0.0,0.0),(E(0,0),))
sigma_p=('pair',sig,Z,refl(Z),refl(Z))
formula_as_term=doc(('eq',sigma_p,0,refl(0)),E(0,Z))
checks={
 'nested_existential_elimination_preserves_ambient_parameter':(legit_let,True),
 'nested_existential_witness_escape_rejected':(leak,False),
 'equality_transport_under_pi_binder':(transport,True),
 'boolean_goal_alias_rejected':(false_alias,False),
 'float_goal_alias_rejected':(float_alias,False),
 'formula_used_as_numerical_equality_premise_rejected':(formula_as_term,False),
}
rows=[]
for name,(d,want) in checks.items():
    got=accept(k,d)
    assert got==want,(name,want,got)
    rows.append(dict(name=name,accepted=got,expected=want))

source_text=p.read_text()
def variant(old,new,name):
    assert source_text.count(old)==1,(name,source_text.count(old))
    m=types.ModuleType(name)
    exec(compile(source_text.replace(old,new),name,'exec'),m.__dict__)
    return m

no_goal_validation=variant('require(all(wf(b, True) for b in g) and wf(a, True))',
                           'require(all(wf(b, True) for b in g))','unsafe_no_goal_validation')
assert accept(no_goal_validation,false_alias)
assert accept(no_goal_validation,float_alias)
no_equality_tag=variant('            require(e[0] == "=")\n','', 'unsafe_no_equality_tag')
assert accept(no_equality_tag,formula_as_term)
result=dict(reviewed_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),checks=rows,
 further_deletion_counterexamples={
   'remove_goal_wf':'Accepts Boolean and floating-point aliases for integer variable indices.',
   'remove_equality_premise_tag':'Accepts closed proof tree of the open false theorem v0=0 with no assumptions; formula template is integer 0 and Sigma components are wrongly substituted as terms.'
 },scope='Independent finite boundary tests plus separately written universal invariant argument. Deliberately unsafe variants existed only in memory.')
(root/'verification').mkdir(exist_ok=True)
(root/'verification/independent_boundary_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
