"""Compile the report and create a verified source-and-PDF ZIP archive."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
NAME = ROOT.name


def compile_pdf():
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    env = os.environ.copy()
    existing = subprocess.run(["kpsewhich", "pdflatex.fmt"], text=True,
                              capture_output=True, cwd=build)
    if not existing.stdout.strip() and not (build / "pdflatex.fmt").exists():
        with (build / "format_creation.log").open("w") as stream:
            subprocess.run(["pdftex", "-ini", "-etex", "-jobname=pdflatex",
                            "-progname=pdflatex", "pdflatex.ini"], cwd=build,
                           stdout=stream, stderr=subprocess.STDOUT, check=True)
    if (build / "pdflatex.fmt").exists():
        env["TEXFORMATS"] = str(build) + os.pathsep + env.get("TEXFORMATS", "")
    command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
               "-jobname=" + NAME, "-output-directory=" + str(build), "report.tex"]
    for index in range(1, 4):
        with (build / ("latex_pass_%d.txt" % index)).open("w") as stream:
            subprocess.run(command, cwd=ROOT, env=env, stdout=stream,
                           stderr=subprocess.STDOUT, check=True)
    log = (build / (NAME + ".log")).read_text()
    bad = [line for line in log.splitlines()
           if "Overfull" in line or "undefined references" in line
           or "undefined citations" in line or "Rerun to get" in line]
    if bad:
        raise RuntimeError("PDF needs review: " + " | ".join(bad))
    target = ROOT / (NAME + ".pdf")
    shutil.copyfile(build / (NAME + ".pdf"), target)
    result = {"status": "compiled", "file": target.name,
              "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
              "size_bytes": target.stat().st_size, "passes": 3,
              "overfull_boxes": 0, "undefined_references_or_citations": 0}
    (ROOT / "verification/build.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


def package():
    if not (ROOT / (NAME + ".pdf")).is_file():
        raise FileNotFoundError("Compile the PDF before packaging")
    excluded_dirs = {"build", "qa", "__pycache__", ".git"}
    excluded_suffixes = {".zip", ".pyc", ".aux", ".log", ".out", ".toc", ".fmt"}
    selected = sorted(p for p in ROOT.rglob("*") if p.is_file()
                      and not any(part in excluded_dirs for part in p.relative_to(ROOT).parts)
                      and p.suffix not in excluded_suffixes and p.name != "SHA256SUMS.txt")
    checksums = "".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  "
                        + p.relative_to(ROOT).as_posix() + "\n" for p in selected)
    manifest = ROOT / "SHA256SUMS.txt"
    manifest.write_text(checksums)
    archive = ROOT.parent / (NAME + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in [*selected, manifest]:
            info = zipfile.ZipInfo(NAME + "/" + path.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError("ZIP integrity failure")
        for line in checksums.splitlines():
            digest, name = line.split("  ", 1)
            if hashlib.sha256(z.read(NAME + "/" + name)).hexdigest() != digest:
                raise RuntimeError("ZIP checksum failure: " + name)
    print(json.dumps({"archive": str(archive), "files": len(selected) + 1,
                      "size_bytes": archive.stat().st_size,
                      "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-only", action="store_true")
    parser.add_argument("--pdf-only", action="store_true")
    args = parser.parse_args()
    if not args.package_only:
        compile_pdf()
    if not args.pdf_only:
        package()
