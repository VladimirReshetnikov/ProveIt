"""Run bounded certificate, scope, syntax, translation and CLI regressions.

Nothing in this file is imported by either trusted checker. The tests validate
finite executable certificates and reject specific malformed inputs; they do
not constitute a formal proof of universal soundness or bi-interpretability.
"""

import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import traceback


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "code"))

import checker as primary
import encoded_checker as encoded
import encode_certificate as compiler
import adversarial
import test_premise_validation as focused


REJECTIONS = (ValueError, TypeError, IndexError, KeyError, RecursionError)
REGRESSION_NAME = "nat_false_guard_reindexing"


def demand(condition, message):
    if not condition:
        raise AssertionError(message)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def roundtrip(document):
    return json.loads(json.dumps(document, separators=(",", ":")))


def accepts(module, document):
    try:
        return module.check(roundtrip(document)) is True
    except REJECTIONS:
        return False


def save_certificate(path, document):
    data = (json.dumps(document, separators=(",", ":")) + "\n").encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return {"path": path.relative_to(ROOT).as_posix(),
            "sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)}


def source_regression():
    """A false N matrix inserts an unused equation IH only after encoding.

    The source Pi guard is hypothesis 2; in the encoded branch it is 3.
    A naive falsity erasure leaves 2 and tries to apply an equality as Pi.
    """
    z, false = primary.ZERO, primary.FALSE
    truth = ("=", z, z)
    guard = ("pi", truth, false)
    recursor = ("r", z, z, z)
    computation = ("rec", recursor)
    reflexivity = ("eq", computation, ("=", 0, z), computation)
    step = ("app", ("pi", guard, ("app", ("hyp", 2), z, reflexivity)),
            z, ("hyp", 1))
    return {"assumptions": [false, guard], "goal": false,
            "proof": ("nat", false, z, ("hyp", 0), step)}


def naive_erasure(value):
    """Deliberately incomplete compiler: erase bridges, never adjust indices."""
    if value == primary.FALSE:
        return primary.CLASH
    if type(value) is tuple:
        if len(value) == 2 and value[0] == "bridge":
            return naive_erasure(value[1])
        return tuple(naive_erasure(child) for child in value)
    return value


def erase_document(document, operation=compiler.encode):
    result = dict(document)
    result["assumptions"] = [operation(primary.freeze(a)) for a in document["assumptions"]]
    result["goal"] = operation(primary.freeze(document["goal"]))
    result["proof"] = operation(primary.freeze(document["proof"]))
    return result


def extra_rejections():
    z, false = primary.ZERO, primary.FALSE
    truth = ("=", z, z)
    return {
        "no_bridge_axiom_leaf": {"assumptions": [], "goal": false, "proof": ["bridge"]},
        "primitive_reflexivity_absent": {"assumptions": [], "goal": truth,
                                         "proof": ["refl", z]},
        "primitive_explosion_absent": {"assumptions": [false], "goal": truth,
                                       "proof": ["abort", ["hyp", 0], truth]},
        "rec_term_is_variable": {"assumptions": [], "goal": truth, "proof": ["rec", 0]},
        "rec_wrong_arity": {"assumptions": [], "goal": truth,
                            "proof": ["rec", ["r", z, z]]},
        "rec_false_body": {"assumptions": [], "goal": truth,
                           "proof": ["rec", ["r", z, z, false]]},
        "boolean_goal": {"assumptions": [("=", 1, z)], "goal": ("=", True, z),
                         "proof": ["hyp", 0]},
        "extra_root_field": {"assumptions": [truth], "goal": truth,
                             "proof": ["hyp", 0], "arity": 0},
        "boolean_nat_target": {"assumptions": [false], "goal": false,
                               "proof": ["nat", false, True, ["hyp", 0], ["hyp", 0]]},
        "negative_hypothesis_index": {"assumptions": [truth], "goal": truth,
                                      "proof": ["hyp", -1]},
        "unproved_false": {"assumptions": [], "goal": false, "proof": ["hyp", 0]},
        "malformed_equation_template": {"assumptions": [truth], "goal": truth,
                                        "proof": ["eq", ["hyp", 0], ["=", 0], ["hyp", 0]]},
    }


def cli_checks(valid_source, valid_encoded, invalid_source, invalid_encoded):
    runs = []
    programs = (
        ("primary", ROOT / "code/checker.py", valid_source, invalid_source),
        ("frontier", ROOT / "comparisons/frontier.py", valid_source, invalid_source),
        ("encoded", ROOT / "code/encoded_checker.py", valid_encoded, invalid_encoded),
    )
    for label, program, accepted_path, rejected_path in programs:
        for optimize in (False, True):
            command = [sys.executable, *(["-O"] if optimize else []), str(program)]
            for path, expected_code, expected_text in (
                (accepted_path, 0, "ACCEPT"), (rejected_path, 1, "REJECT"),
            ):
                process = subprocess.run([*command, str(path)], capture_output=True,
                                         text=True, timeout=30)
                demand(process.returncode == expected_code and process.stdout.strip() == expected_text,
                       f"CLI regression: {label}, optimized={optimize}, {path.name}: "
                       f"{process.returncode}, {process.stdout}, {process.stderr}")
                runs.append({"checker": label, "python_optimized": optimize,
                             "certificate": path.relative_to(ROOT).as_posix(),
                             "exit_code": process.returncode, "stdout": process.stdout.strip()})
    return runs


def run():
    frontier = load_module("frontier_control", ROOT / "comparisons/frontier.py")
    inventory = json.loads((ROOT / "provenance/certificate_inventory.json").read_text())
    demand(inventory["count"] == len(inventory["fixtures"]) == 53,
           "The pinned baseline corpus must contain 53 original certificates")
    results = {
        "status": "running", "python_version": sys.version.split()[0],
        "scope": "Bounded executable regression checks; no formal universal metatheorem is asserted.",
        "original_fixture_count": inventory["count"], "valid_replays": [],
        "rejected_certificates": [], "adversarial_positive_replays": [],
    }

    def replay(name, document, original=None):
        document = roundtrip(document)
        demand(accepts(primary, document), "Primary rejected valid certificate: " + name)
        demand(accepts(frontier, document), "Frontier rejected valid certificate: " + name)
        converted = roundtrip(compiler.translate(document))
        demand(accepts(encoded, converted), "Encoded checker rejected compiled certificate: " + name)
        stored = save_certificate(ROOT / "certificates/encoded" / (name + ".json"), converted)
        results["valid_replays"].append({
            "name": name, "primary": True, "frontier": True, "encoded_after_compilation": True,
            "original_fixture": original, "encoded_certificate": stored,
        })
        return converted

    for item in inventory["fixtures"]:
        path = ROOT / item["path"]
        data = path.read_bytes()
        demand(len(data) == item["size_bytes"] and hashlib.sha256(data).hexdigest() == item["sha256"],
               "Original fixture changed: " + item["path"])
        replay(path.stem, json.loads(data), item)

    source = source_regression()
    source_path = ROOT / "certificates/valid" / (REGRESSION_NAME + ".json")
    save_certificate(source_path, source)
    converted = replay(REGRESSION_NAME, source)
    naive = erase_document(source, naive_erasure)
    demand(not accepts(encoded, naive), "Naive falsity erasure unexpectedly passed the reindexing regression")
    bad_naive_path = ROOT / "certificates/invalid_encoded" / ("naive_" + REGRESSION_NAME + ".json")
    save_certificate(bad_naive_path, naive)
    source_index = primary.freeze(source["proof"])[4][1][2][1][1]
    target_index = encoded.freeze(converted["proof"])[4][1][2][1][1]
    demand(source_index == 2 and target_index == 3,
           "The extra encoded induction hypothesis did not reindex the later Pi guard")
    results["compiler_reindexing_regression"] = {
        "name": REGRESSION_NAME, "source_guard_index": source_index,
        "encoded_guard_index": target_index, "source_accepted": True,
        "correct_translation_accepted": True, "naive_erasure_rejected": True,
        "explanation": "The source N matrix is genuine falsity and has no IH. Its encoding is an equation and inserts an unused IH before the subsequent Pi guard.",
    }

    negatives = {}
    for name, document, expected in adversarial.cases:
        if expected:
            demand(accepts(primary, document) and accepts(frontier, document),
                   "Adversarial positive case failed: " + name)
            demand(accepts(encoded, compiler.translate(roundtrip(document))),
                   "Encoded adversarial positive case failed: " + name)
            results["adversarial_positive_replays"].append(name)
        else:
            negatives[name] = document
    negatives.update(extra_rejections())
    negatives.update(focused.counterexamples())
    for name, document in negatives.items():
        demand(not accepts(primary, document), "Primary accepted invalid certificate: " + name)
        demand(not accepts(frontier, document), "Frontier accepted invalid certificate: " + name)
        encoded_document = erase_document(document)
        demand(not accepts(encoded, encoded_document), "Encoded checker accepted invalid input: " + name)
        source_meta = save_certificate(ROOT / "certificates/invalid" / (name + ".json"), document)
        encoded_meta = save_certificate(ROOT / "certificates/invalid_encoded" / (name + ".json"), encoded_document)
        results["rejected_certificates"].append({"name": name, "primary_rejected": True,
            "frontier_rejected": True, "encoded_rejected": True,
            "source_certificate": source_meta, "encoded_certificate": encoded_meta})

    results["premise_validation"] = focused.run()
    trusted = []
    for relative in ("code/checker.py", "code/encoded_checker.py",
                     "comparisons/frontier.py", "comparisons/alternate_frontier.py"):
        data = (ROOT / relative).read_bytes()
        tree = ast.parse(data.decode("utf-8"))
        count = sum(isinstance(node, ast.Assert) for node in ast.walk(tree))
        demand(count == 0, "A trusted checker uses assert: " + relative)
        trusted.append({"path": relative, "sha256": hashlib.sha256(data).hexdigest(),
                        "assert_statements": count})
    results["trusted_source_checks"] = trusted
    results["cli_checks"] = cli_checks(
        source_path, ROOT / "certificates/encoded" / (REGRESSION_NAME + ".json"),
        ROOT / "certificates/invalid/equality_template_raw_string.json",
        ROOT / "certificates/invalid_encoded/equality_template_raw_string.json",
    )
    results["counts"] = {
        "original_valid_certificates": inventory["count"],
        "new_valid_compiler_regressions": 1,
        "primary_valid_replays": len(results["valid_replays"]),
        "frontier_valid_replays": len(results["valid_replays"]),
        "compiled_encoded_valid_replays": len(results["valid_replays"]),
        "adversarial_positive_cases": len(results["adversarial_positive_replays"]),
        "negative_cases_per_checker": len(results["rejected_certificates"]),
        "naive_compiler_negative_cases": 1,
        "focused_valid_cases": len(results["premise_validation"]["focused_regressions"]["accepted"]),
        "focused_negative_cases": len(results["premise_validation"]["focused_regressions"]["rejected"]),
        "naive_checker_counterexamples": len(results["premise_validation"]["naive_deletion_accepts_malformed"]),
        "cli_runs": len(results["cli_checks"]),
    }
    results["status"] = "passed"
    return results


def main():
    output = ROOT / "verification"
    output.mkdir(exist_ok=True)
    try:
        results = run()
    except Exception as error:
        results = {"status": "failed", "error": str(error), "traceback": traceback.format_exc()}
        (output / "results.json").write_text(json.dumps(results, indent=2) + "\n")
        raise
    (output / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    summary = {"status": results["status"], **results["counts"],
               "syntax_reflection_samples": results["premise_validation"]["reflection_samples"]}
    text = json.dumps(summary, indent=2) + "\n"
    (output / "test_output.txt").write_text(text)
    print(text, end="")


if __name__ == "__main__":
    main()
