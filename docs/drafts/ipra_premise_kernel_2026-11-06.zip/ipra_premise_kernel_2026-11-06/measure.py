"""Recompute exact-source checker measurements; never reuse cached counts.

The delivered candidates and the two exact frontier snapshots are always
measured. With --sources, the selected members of all eleven pinned ZIP
archives are measured directly without executing or extracting their code.
Use --all-drafts to require a complete archive comparison.
"""

import argparse
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize
import zipfile


ROOT = Path(__file__).resolve().parent
METRICS = (
    "raw_utf8_bytes", "physical_lines", "significant_source_lines",
    "significant_tokens", "token_spelling_utf8_bytes", "ast_nodes",
    "normalized_code_utf8_bytes",
)
POLICY = {
    "significant_tokens": "Exact original Python tokenize tokens, excluding comments, layout, encoding, end marker, and syntactic module/function/class docstrings; no source reformatting precedes this count.",
    "ast_nodes": "Every ast.walk node, including operator and context nodes, after removal of syntactic docstring statements.",
    "raw_utf8_bytes": "Original file bytes, including comments, docstrings and formatting.",
    "token_spelling_utf8_bytes": "Sum of UTF-8 byte lengths of significant token spellings, without intervening whitespace.",
    "normalized_code_utf8_bytes": "UTF-8 size of ast.unparse after docstring removal, followed by one newline. This is secondary and Python-version dependent.",
    "significant_source_lines": "Number of original physical lines touched by significant tokens, including all lines of executable multiline strings.",
    "trusted_boundary": "All selected checker files, fixed data, input validation, substitution and binding machinery, inference checks, and their JSON/CLI entry point are charged. Each shared local dependency is counted once per variant.",
    "external_runtime": "The Python interpreter and Python standard library are common excluded runtime dependencies. No third-party proof checker, evaluator, compiler or theorem database is excluded.",
    "qualification": "Cross-archive entries are literal attained implementation sizes with different certificate formats and coding conventions. The two frontier snapshots are exact matched controls. These measurements are not mathematical lower bounds or universal minimality proofs.",
}


def measure_bytes(data):
    """Return source counts without importing or running the measured code."""
    source = data.decode("utf-8")
    lines = source.splitlines(keepends=True)
    tree = ast.parse(source)
    docstrings = []

    def character_column(line_number, byte_column):
        return len(lines[line_number - 1].encode("utf-8")[:byte_column].decode("utf-8"))

    for node in list(ast.walk(tree)):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body.pop(0)
                docstrings.append((
                    (doc.lineno, character_column(doc.lineno, doc.col_offset)),
                    (doc.end_lineno, character_column(doc.end_lineno, doc.end_col_offset)),
                ))
    ignored = {
        tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
        tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
    }
    tokens = [
        token for token in tokenize.generate_tokens(io.StringIO(source).readline)
        if token.type not in ignored
        and not any(start <= token.start and token.end <= end for start, end in docstrings)
    ]
    touched = {line for token in tokens for line in range(token.start[0], token.end[0] + 1)}
    return {
        "sha256": hashlib.sha256(data).hexdigest(),
        "raw_utf8_bytes": len(data),
        "physical_lines": len(source.splitlines()),
        "significant_source_lines": len(touched),
        "significant_tokens": len(tokens),
        "token_spelling_utf8_bytes": sum(len(token.string.encode("utf-8")) for token in tokens),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_code_utf8_bytes": len((ast.unparse(tree) + "\n").encode("utf-8")),
    }


def aggregate(metadata, members):
    return {
        **metadata,
        "files": members,
        "totals": {metric: sum(member[metric] for member in members) for metric in METRICS},
    }


def load_archive(path, expected):
    data = path.read_bytes()
    actual = {
        "size_bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob_sha1": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    }
    for key, value in actual.items():
        if value != expected[key]:
            raise ValueError(f"Archive identity mismatch: {path.name}: {key}")
    return zipfile.ZipFile(io.BytesIO(data))


def read_json(relative):
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))


def latex_escape(text):
    return text.replace("_", r"\_").replace("%", r"\%").replace("&", r"\&")


def write_outputs(result):
    destination = ROOT / "comparisons"
    destination.mkdir(exist_ok=True)
    (destination / "metrics.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    fields = ("id", "label", "group", "semantics", *METRICS)
    rows = [{key: variant.get(key, "") for key in fields[:4]} | variant["totals"]
            for variant in result["variants"]]
    with (destination / "metrics.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    macros = []
    names = {"candidate": "Candidate", "encoded_candidate": "EncodedCandidate",
             "frontier": "Frontier", "alternate_frontier": "AlternateFrontier"}
    suffixes = {"raw_utf8_bytes": "Bytes", "significant_tokens": "Tokens", "ast_nodes": "AST",
                "token_spelling_utf8_bytes": "TokenBytes", "normalized_code_utf8_bytes": "CodeBytes"}
    for variant in result["variants"]:
        if variant["id"] in names:
            for metric, suffix in suffixes.items():
                macros.append(r"\newcommand{\Measured" + names[variant["id"]] + suffix + "}{"
                              + str(variant["totals"][metric]) + "}")
    (destination / "metrics.tex").write_text("\n".join(macros) + "\n", encoding="utf-8")
    table = [r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
             r"Implementation & Tokens & AST nodes & Bytes\\", r"\midrule"]
    for variant in result["variants"]:
        values = variant["totals"]
        table.append(latex_escape(variant["label"]) + " & " + " & ".join(
            str(values[metric]) for metric in ("significant_tokens", "ast_nodes", "raw_utf8_bytes")) + r"\\")
    table += [r"\bottomrule", r"\end{tabular}"]
    (destination / "table.tex").write_text("\n".join(table) + "\n", encoding="utf-8")
    verification = ROOT / "verification"
    verification.mkdir(exist_ok=True)
    selected = {variant["id"]: variant for variant in result["variants"]}
    compact = [r"\begin{center}\small", r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
               r"Complete implementation & Tokens & AST nodes & Raw bytes & Code bytes\\",
               r"\midrule"]
    labels = (("candidate", "Premise kernel"), ("frontier", "Current frontier"),
              ("alternate_frontier", "Alternative frontier"),
              ("encoded_candidate", "Optional encoded variant"))
    for identifier, label in labels:
        if identifier in selected:
            totals = selected[identifier]["totals"]
            compact.append(label + " & " + " & ".join(str(totals[metric]) for metric in
                           ("significant_tokens", "ast_nodes", "raw_utf8_bytes",
                            "normalized_code_utf8_bytes")) + r"\\")
    compact += [r"\bottomrule", r"\end{tabular}", r"\end{center}"]
    (verification / "metrics_table.tex").write_text("\n".join(compact) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sources", type=Path, default=ROOT.parent / "sources",
                        help="Directory containing the eleven original ZIP archives.")
    parser.add_argument("--all-drafts", action="store_true",
                        help="Fail instead of reporting missing archive inputs.")
    args = parser.parse_args()
    manifest = read_json("provenance/source_manifest.json")
    inventory = read_json("provenance/draft_inventory.json")
    variants = []
    missing = []
    for item in inventory["delivered_variants"]:
        members = []
        for selected in item["trusted_files"]:
            path = ROOT / selected["path"]
            if not path.is_file():
                if item.get("optional", False):
                    break
                raise FileNotFoundError(path)
            measured = measure_bytes(path.read_bytes())
            if selected.get("sha256") and measured["sha256"] != selected["sha256"]:
                raise ValueError(f"Verbatim control was changed: {selected['path']}")
            members.append({"path": selected["path"], **measured})
        else:
            variants.append(aggregate({key: value for key, value in item.items()
                                       if key != "trusted_files"}, members))
    for archive in manifest["archives"]:
        path = args.sources / archive["name"]
        if not path.is_file():
            missing.append(archive["name"])
            continue
        with load_archive(path, archive) as opened:
            for item in inventory["archive_variants"]:
                if item["archive_id"] != archive["id"]:
                    continue
                members = []
                for selected in item["trusted_files"]:
                    measured = measure_bytes(opened.read(selected["member_path"]))
                    if measured["sha256"] != selected["sha256"]:
                        raise ValueError(f"ZIP member identity mismatch: {selected['member_path']}")
                    members.append({"path": selected["member_path"], **measured})
                variants.append(aggregate({key: value for key, value in item.items()
                                           if key != "trusted_files"}, members))
    if missing and args.all_drafts:
        raise FileNotFoundError("Missing pinned source archives: " + ", ".join(missing))
    candidate = next((row for row in variants if row["id"] == "candidate"), None)
    if candidate:
        for row in variants:
            row["candidate_savings"] = {
                metric: {
                    "absolute": row["totals"][metric] - candidate["totals"][metric],
                    "percent": round(100 * (1 - candidate["totals"][metric] / row["totals"][metric]), 6),
                } for metric in METRICS if row["totals"][metric]
            }
    result = {
        "python_version": sys.version.split()[0], "policy": POLICY,
        "snapshot_commit": manifest["snapshot_commit"],
        "archives_expected": manifest["archive_count"],
        "archives_measured": manifest["archive_count"] - len(missing),
        "missing_archives": missing, "variants": variants,
    }
    write_outputs(result)
    for row in variants:
        totals = row["totals"]
        print(f"{row['id']:30} {totals['significant_tokens']:5} tokens  "
              f"{totals['ast_nodes']:5} AST  {totals['raw_utf8_bytes']:6} bytes  {row['semantics']}")
    print(f"Archives measured: {result['archives_measured']}/{result['archives_expected']}")
    if missing:
        print("Archive counts were not reused: unavailable inputs are listed in metrics.json.")
    return result


if __name__ == "__main__":
    main()
