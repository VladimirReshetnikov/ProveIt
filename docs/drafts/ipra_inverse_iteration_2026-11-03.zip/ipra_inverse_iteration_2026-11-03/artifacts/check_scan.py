#!/usr/bin/env python3
"""Exhaustive bounded diagnostics for the written witnessed-boundary scan.

Not a formal proof or a verification on nonstandard models. Each Boolean
table is the predicate row for one fixed target and parameter assignment.
"""
from __future__ import annotations
import argparse
import itertools
import json
from pathlib import Path


def run(max_target: int = 10) -> dict:
    tables = 0
    invariant_states = 0
    for target in range(max_target + 1):
        for values in itertools.product((False, True), repeat=target + 1):
            d = 0
            for n in range(target + 1):
                assert 0 <= d <= n
                assert d == 0 or (max(d - 1, 0) + 1 == d and values[d - 1])
                assert not values[d] or d == n
                invariant_states += 1
                if n < target:
                    d = n + 1 if values[d] else d
            b = d
            predecessor_witness = b - 1 if b else None
            assert b == 0 or (
                predecessor_witness is not None
                and predecessor_witness + 1 == b
                and values[predecessor_witness]
            )
            assert not values[b] or b == target
            tables += 1
    return {
        "status": "passed",
        "scope": "Exhaustive finite predicate rows only; not a proof-assistant verification.",
        "max_target": max_target,
        "predicate_rows_checked": tables,
        "invariant_states_checked": invariant_states,
        "each_row_models": "one fixed target and arbitrary fixed numerical parameters",
        "invariants": [
            "d_n=0 or (S(p(d_n))=d_n and E(p(d_n)))",
            "E(d_n) implies d_n=n",
        ],
        "boundary_witness": "b=d_target, shared by both boundary clauses",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = json.dumps(run(), indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(result, encoding="utf-8")
    print(result, end="")


if __name__ == "__main__":
    main()
