#!/usr/bin/env python3
"""Finite diagnostics for counter-shifted fusion, not formal metatheorem proof."""
from dataclasses import dataclass
import json

@dataclass(frozen=True)
class Sym:
    name: str
    body: object = None
    params: tuple = ()

@dataclass(frozen=True)
class T:
    op: object
    args: tuple = ()


def V(x): return T(('var', x))
def F(op, *xs): return T(op, tuple(xs))
Z = F('0')
def S(x): return F('S', x)
def size(t):
    return 1 + sum(map(size, t.args)) + (size(t.op.body) if isinstance(t.op, Sym) else 0)
def sub(t, env):
    if isinstance(t.op, tuple) and t.op[0] == 'var': return env.get(t.op[1], t)
    return T(t.op, tuple(sub(a, env) for a in t.args))
def occurrences(t, x):
    return int(t.op == ('var', x)) + sum(occurrences(a, x) for a in t.args)
def eq(x,y): return F('=',x,y)
def con(x,y): return F('and',x,y)
def forall(x,p): return F(('forall',x),p)
def close(xs,p):
    for x in reversed(xs): p=forall(x,p)
    return p

def module(sym):
    n,a=V('n'),V('a')
    pars=[V(p) for p in sym.params]
    base=eq(F(sym,Z,a,*pars),a)
    rn=F(sym,n,a,*pars)
    st=eq(F(sym,S(n),a,*pars),sub(sym.body,{'v':rn,'w':n,**dict(zip(sym.params,pars))}))
    return close(('a',)+sym.params,con(base,forall('n',st)))

v,w,d,c,n,a=map(V,['v','w','d','c','n','a'])
A=Sym('A',S(v))
def add(n,a): return F(A,n,a)
def suc(j,t):
    for _ in range(j): t=S(t)
    return t

records=[]
for j in range(1,65):
    h=Sym('h'+str(j),add(w,suc(j,v)))
    hp=Sym('hp'+str(j),add(add(w,d),suc(j,v)),('d',))
    qbody=F(hp,w,F(h,c,v),c)
    rbody=F(h,add(w,c),v)
    q=Sym('q'+str(j),qbody,('c',))
    r=Sym('r'+str(j),rbody,('c',))
    values={
      'j':j,'h':size(h.body),'hplus':size(hp.body),
      'q_body':size(qbody),'r_body':size(rbody),
      'q_module':size(module(q)),'r_module':size(module(r)),
      'q_call':size(F(q,n,a,c)),'r_call':size(F(r,n,a,c))
    }
    assert values['h']==j+5
    assert values['hplus']==j+9
    assert values['q_body']==2*j+20
    assert values['r_body']==j+12
    assert values['q_module']==8*j+99
    assert values['r_module']==4*j+67
    assert values['q_call']==2*j+24
    assert values['r_call']==j+16
    assert occurrences(qbody,'v')==occurrences(rbody,'v')==1
    assert occurrences(h.body,'w')==occurrences(hp.body,'w')==1
    records.append(values)

# Arbitrarily large actual arguments cannot invalidate the savings because
# the fixed interpretation retains each actual argument once in the same slot.
sub_checks=0
for j in range(1,8):
    h=Sym('h'+str(j),add(w,suc(j,v)))
    hp=Sym('hp'+str(j),add(add(w,d),suc(j,v)),('d',))
    q=Sym('q'+str(j),F(hp,w,F(h,c,v),c),('c',))
    r=Sym('r'+str(j),F(h,add(w,c),v),('c',))
    for ni in range(7):
      for ai in range(7):
        for ci in range(7):
          args=(suc(ni,n),suc(ai,a),suc(ci,c))
          assert size(F(q,*args))-size(F(r,*args))==j+8
          sub_checks+=1

def iterate(update,n,a):
    for k in range(n): a=update(a,k)
    return a

def run(j,n,a): return iterate(lambda v,w:v+j+w,n,a)
def shifted(j,n,a,d): return iterate(lambda v,w:v+j+w+d,n,a)
checks=0
for j in range(1,10):
  for n0 in range(9):
    for m0 in range(9):
      for a0 in range(6):
        assert shifted(j,n0,run(j,m0,a0),m0)==run(j,n0+m0,a0)
        checks+=1

# The unsafely unshifted and incorrectly shifted variants must be rejected.
assert run(1,1,run(1,1,0))!=run(1,2,0)
assert shifted(1,1,run(1,1,0),0)!=run(1,2,0)

result={
  'status':'passed',
  'scope':'Finite AST and numerical diagnostics only; internal-induction proof is written separately.',
  'size_instances':len(records),
  'arbitrary_argument_size_checks':sub_checks,
  'numerical_shifted_fusion_checks':checks,
  'negative_controls':2,
  'sample':records[:5],
  'last':records[-1],
}
if __name__ == '__main__':
    import argparse
    from pathlib import Path
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    rendered = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding='utf-8')
    print(rendered, end='')
