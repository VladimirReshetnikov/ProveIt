#!/usr/bin/env python3
"""Finite diagnostics for inverse-iterator pruning of iPRA descriptions.

Python 3.10+; standard library only.  This is not a proof assistant.
Actual term/formula trees are counted, including recursively frozen labels.
Internal induction and nonstandard-input claims are proved in the report.

Run: python3 check_inverse.py --output inverse_checks.json
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path


@dataclass(frozen=True)
class Symbol:
    body: "Node"
    parameters: tuple[str, ...] = ()


@dataclass(frozen=True)
class Node:
    tag: str
    children: tuple["Node", ...] = ()
    name: str = ""
    symbol: Symbol | None = None


def var(name):
    return Node("var", name=name)


def node(tag, *children):
    return Node(tag, tuple(children))


ZERO, BOTTOM = node("0"), node("bottom")


def successor(t):
    return node("S", t)


def call(symbol, *args):
    assert len(args) == 2 + len(symbol.parameters)
    return Node("rec", tuple(args), symbol=symbol)


def eq(a, b):
    return node("=", a, b)


def bind(tag, names, matrix):
    for name in reversed(tuple(names)):
        matrix = Node(tag, (matrix,), name=name)
    return matrix


@lru_cache(maxsize=None)
def size(t):
    result = 1 + sum(size(a) for a in t.children)
    if t.tag == "rec":
        assert t.symbol is not None
        result += size(t.symbol.body)
    return result


def active_substitute(t, mapping):
    """Active term substitution; a frozen symbol object is preserved verbatim."""
    assert t.tag not in {"forall", "exists", "J"}
    if t.tag == "var":
        return mapping.get(t.name, t)
    return Node(t.tag, tuple(active_substitute(a, mapping)
                             for a in t.children), t.name, t.symbol)


def occurrences(t, name):
    return int(t.tag == "var" and t.name == name) + sum(
        occurrences(a, name) for a in t.children)


v, w, n, a, x, b, target = map(var, ("v", "w", "n", "a", "x", "b", "t"))
Q = Symbol(w)
A = Symbol(successor(v))
P = Symbol(call(Q, v, ZERO))


def eta(j):
    t = v
    for _ in range(j):
        t = call(P, w, call(A, w, t))
    return t


def eta_index(t):
    """Decidable literal family matcher; zero means the bare state variable."""
    j = 0
    while (t.tag == "rec" and t.symbol == P and len(t.children) == 2
           and t.children[0] == w):
        inner = t.children[1]
        if not (inner.tag == "rec" and inner.symbol == A
                and inner.children[0] == w):
            return None
        t = inner.children[1]
        j += 1
    return j if t == v else None


def is_erased(symbol):
    return (not symbol.parameters
            and (j := eta_index(symbol.body)) is not None and j >= 1)


def tau(t):
    """Fixed homomorphic symbol map.  Retained labels keep their full charge."""
    if t.tag == "rec" and is_erased(t.symbol):
        return tau(t.children[1])
    return Node(t.tag, tuple(tau(c) for c in t.children), t.name, t.symbol)


def ordinary_module(symbol):
    cs = tuple(var(c) for c in symbol.parameters)
    rn = call(symbol, n, a, *cs)
    update = active_substitute(symbol.body, {"v": rn, "w": n})
    base = eq(call(symbol, ZERO, a, *cs), a)
    step = bind("forall", ("n",), eq(call(symbol, successor(n), a, *cs), update))
    return bind("forall", ("a",) + symbol.parameters, node("and", base, step))


def boundary(equation, parameters=("a",), mode="WB"):
    """E uses the active probe x; t is retained even when absent from E."""
    first_zero = eq(b, ZERO)
    edge = eq(successor(x), b)
    destination = eq(b, target)
    at_b = active_substitute(equation, {"x": b})
    if mode == "WB":
        local = node("and",
                     node("or", first_zero,
                          bind("exists", ("x",), node("and", edge, equation))),
                     node("implies", at_b, destination))
    elif mode == "J":
        # J_x(A,B,P;v,C) pays its concrete five arguments exactly once.
        local = Node("J", (first_zero, edge, equation, b, destination), name="x")
    elif mode == "scoped":
        local = node("and", bind("forall", ("x",), node("implies", edge, equation)),
                     node("implies", at_b, destination))
    elif mode == "K4":
        local = bind("forall", ("x",),
                     node("K4", edge, equation, eq(x, b), destination))
    else:
        raise ValueError(mode)
    return bind("forall", ("t",) + tuple(parameters),
                bind("exists", ("b",), local))


def evaluate(t, environment):
    """Interpret a finite PR description on standard finite natural inputs."""
    if t.tag == "var":
        return environment[t.name]
    if t.tag == "0":
        return 0
    if t.tag == "S":
        return 1 + evaluate(t.children[0], environment)
    assert t.tag == "rec" and t.symbol is not None
    counter, value, *params = (evaluate(c, environment) for c in t.children)
    for k in range(counter):
        local = {"v": value, "w": k}
        local.update(zip(t.symbol.parameters, params))
        value = evaluate(t.symbol.body, local)
    return value


def successor_power(k, t):
    for _ in range(k):
        t = successor(t)
    return t


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        help="Optional JSON receipt path; otherwise print only")
    args = parser.parse_args()

    support = {name: size(ordinary_module(s)) for name, s in (("Q", Q), ("A", A), ("P", P))}
    assert support == {"Q": 16, "A": 23, "P": 31}
    assert (size(Q.body), size(A.body), size(P.body)) == (1, 2, 4)

    # The generic binder record, with B(x), P(x) charged as templates.
    formal_a, formal_c = node("formal_A"), node("formal_C")
    formal_bx, formal_px = node("formal_B", x), node("formal_P", x)
    formal_pv = node("formal_P", v)
    formal_lhs = Node("J", (formal_a, formal_bx, formal_px, v, formal_c), name="x")
    formal_rhs = node("and", node("or", formal_a,
                                  bind("exists", ("x",), node("and", formal_bx, formal_px))),
                      node("implies", formal_pv, formal_c))
    j_definition = size(formal_lhs) + size(formal_rhs) + 1
    assert (size(formal_lhs), size(formal_rhs), j_definition) == (8, 13, 22)

    sep = node("implies", eq(ZERO, successor(ZERO)), BOTTOM)
    assert size(sep) == 6

    matrices = {
        "predecessor_shift": eq(call(P, successor(x), successor(a)), call(P, x, a)),
        "inverse_iteration": eq(call(P, x, call(A, x, a)), a),
    }
    matrix_records = {}
    for name, e in matrices.items():
        record = {"matrix": size(e),
                  **{mode: size(boundary(e, mode=mode))
                     for mode in ("WB", "J", "scoped", "K4")}}
        f = size(e)
        assert record["WB"] == 2*f + 18
        assert record["J"] == record["K4"] == f + 15
        assert record["scoped"] == 2*f + 14
        matrix_records[name] = record
    assert matrix_records["predecessor_shift"] == {
        "matrix": 17, "WB": 52, "J": 32, "scoped": 48, "K4": 32}
    assert matrix_records["inverse_iteration"] == {
        "matrix": 13, "WB": 44, "J": 28, "scoped": 40, "K4": 28}

    records = []
    argument_checks = 0
    for j in range(1, 65):
        h = eta(j)
        symbol = Symbol(h)
        source_module = ordinary_module(symbol)
        image_module = tau(source_module)
        expected_image = bind("forall", ("a",), node("and", eq(a, a),
            bind("forall", ("n",), eq(a, active_substitute(h, {"v": a, "w": n})))))
        assert image_module == expected_image
        assert eta_index(h) == j
        assert occurrences(h, "v") == 1
        assert occurrences(h, "w") == 2*j
        assert size(h) == 10*j + 1
        assert size(call(symbol, n, a)) == 10*j + 4
        assert size(source_module) == 40*j + 19
        assert size(image_module) == 10*j + 9
        assert size(source_module)-size(image_module) == 30*j + 10
        erased_eq = eq(call(symbol, x, a), a)
        assert size(erased_eq) == 10*j + 6
        assert size(boundary(erased_eq, mode="WB")) == 20*j + 30
        assert size(boundary(erased_eq, mode="J")) == 10*j + 21
        records.append({"j": j, "body": size(h), "call": size(call(symbol, n, a)),
                        "ordinary_module": size(source_module),
                        "exact_image_module": size(image_module),
                        "module_saving": size(source_module)-size(image_module)})
        for counter_size in range(5):
            for initial_size in range(5):
                counter = successor_power(counter_size, n)
                initial = successor_power(initial_size, a)
                term = call(symbol, counter, initial)
                assert tau(term) == initial
                assert size(term)-size(tau(term)) == size(h)+1+size(counter)
                assert size(term)-size(tau(term)) >= 10*j + 3
                argument_checks += 1

    # Frozen metadata must remain unchanged, even if it names an erased symbol.
    erased = Symbol(eta(2))
    retained = Symbol(call(erased, v, w))
    test = call(retained, call(erased, n, a), successor(a))
    image = tau(test)
    assert not is_erased(retained)
    assert image.symbol is retained and image.symbol.body == retained.body
    assert image.children == (a, successor(a))
    assert size(image) == 1 + size(retained.body) + size(a) + size(successor(a))
    substituted = active_substitute(test, {"v": ZERO, "w": successor(ZERO), "a": successor(n)})
    assert substituted.symbol is retained
    assert tau(substituted) == active_substitute(tau(test), {
        "v": ZERO, "w": successor(ZERO), "a": successor(n)})

    # All four boundary interfaces are transported homomorphically, preserving
    # quantifiers and concrete binder arguments; no fresh active normalization.
    transport_checks = 0
    for j in range(1, 17):
        symbol = Symbol(eta(j))
        e = eq(call(symbol, x, a), a)
        for mode in ("WB", "J", "scoped", "K4"):
            source = boundary(e, mode=mode)
            assert tau(source) == boundary(tau(e), mode=mode)
            assert size(tau(source)) < size(source)
            transport_checks += 1

    numeric_matrix_checks = 0
    for ni in range(17):
        for ai in range(17):
            environment = {"x": ni, "a": ai}
            for e in matrices.values():
                assert evaluate(e.children[0], environment) == evaluate(e.children[1], environment)
                numeric_matrix_checks += 1

    numeric_body_checks = 0
    numeric_recursor_checks = 0
    for j in range(1, 13):
        h = eta(j)
        symbol = Symbol(h)
        for vi in range(9):
            for wi in range(9):
                assert evaluate(h, {"v": vi, "w": wi}) == vi
                numeric_body_checks += 1
        for ni in range(7):
            for ai in range(7):
                assert evaluate(call(symbol, n, a), {"n": ni, "a": ai}) == ai
                numeric_recursor_checks += 1

    # Reversing the cancellation is false when the decrement underflows.
    negative_controls = 0
    for ni in range(1, 11):
        for ai in range(ni):
            opposite = call(A, n, call(P, n, a))
            result = evaluate(opposite, {"n": ni, "a": ai})
            assert result == ni and result != ai
            negative_controls += 1

    receipt = {
        "status": "passed",
        "scope": "Finite syntax, frozen-label transport, and standard numerical diagnostics only; not a proof-assistant verification or a test of nonstandard models.",
        "family_size_instances": len(records),
        "arbitrary_argument_checks": argument_checks,
        "boundary_transport_checks": transport_checks,
        "numerical_matrix_checks": numeric_matrix_checks,
        "numerical_body_checks": numeric_body_checks,
        "numerical_erased_recursor_checks": numeric_recursor_checks,
        "negative_opposite_cancellation_checks": negative_controls,
        "support_module_sizes": support,
        "J_definition_record": j_definition,
        "induction_matrices": matrix_records,
        "shared_certificate_packet": {
            "ordinary_WB": size(sep) + sum(support.values()) + sum(r["WB"] for r in matrix_records.values()),
            "J_WB": size(sep) + j_definition + sum(support.values()) + sum(r["J"] for r in matrix_records.values()),
            "qualification": "Includes the two displayed induction boundaries. Individual source erasure/uniqueness certificates require further boundary instances when absent from a finite packet."},
        "samples": records[:4],
        "last_size_instance": records[-1],
    }
    assert receipt["shared_certificate_packet"]["ordinary_WB"] == 172
    assert receipt["shared_certificate_packet"]["J_WB"] == 158
    output = json.dumps(receipt, indent=2) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output)
    print(output, end="")


if __name__ == "__main__":
    main()
