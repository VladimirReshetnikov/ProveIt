#!/usr/bin/env python3
"""Finite diagnostics for numeral folding and autonomous finite powers.

This checks finite syntax, literal unfoldings, sizes, metadata scope, and bounded
standard-number examples. It is not a formal proof of iPRA bi-interpretability,
termination of every possible normalizer, or retention by arbitrary source code.
Only the Python standard library is required.
"""
from __future__ import annotations
import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

@dataclass(frozen=True)
class Symbol:
    name: str
    descriptor: 'Term'
    arity: int

@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple['Term', ...] = ()
    name: str = ''
    symbol: Optional[Symbol] = None

@dataclass(frozen=True)
class Formula:
    tag: str
    terms: tuple[Term, ...] = ()
    children: tuple['Formula', ...] = ()
    variable: str = ''

def V(name): return Term('var', name=name)
def Z(): return Term('zero')
def S(t): return Term('successor', (t,))
def call(symbol, *args):
    assert len(args) == symbol.arity
    return Term('call', tuple(args), symbol=symbol)
def eq(t, u): return Formula('equality', (t, u))
def conj(f, g): return Formula('and', children=(f, g))
def all_(name, f): return Formula('forall', children=(f,), variable=name)
def numeral(k):
    t = Z()
    for _ in range(k): t = S(t)
    return t

def size(t):
    """Full TREE size: repeated/shared immutable subtrees count repeatedly."""
    frozen = size(t.symbol.descriptor) if t.tag == 'call' else 0
    return 1 + frozen + sum(size(u) for u in t.args)

def fsize(f):
    return 1 + sum(size(t) for t in f.terms) + sum(fsize(g) for g in f.children)

def subst(t, env):
    """Active simultaneous substitution; never traverses symbol metadata."""
    if t.tag == 'var': return env.get(t.name, t)
    if not t.args: return t
    return Term(t.tag, tuple(subst(u, env) for u in t.args), t.name, t.symbol)

def active_occurrences(t, name):
    return int(t.tag == 'var' and t.name == name) + sum(
        active_occurrences(u, name) for u in t.args)

def free_vars(t):
    if t.tag == 'var': return {t.name}
    return set().union(*(free_vars(u) for u in t.args)) if t.args else set()

def unfold(symbol, k, initial):
    """Finite ordinary computation; this reference family has no parameters."""
    t = initial
    for i in range(k):
        t = subst(symbol.descriptor, {'v': t, 'w': numeral(i)})
    return t

def ordinary_module(symbol):
    a, n = V('a'), V('n')
    base = eq(call(symbol, Z(), a), a)
    step_rhs = subst(symbol.descriptor, {'v':call(symbol, n, a), 'w':n})
    step = eq(call(symbol, S(n), a), step_rhs)
    return all_('a', conj(base, all_('n', step)))

v, w, n, a = V('v'), V('w'), V('n'), V('a')
A = Symbol('A', S(v), 2)
M = Symbol('M', call(A, v, v), 2)

def apply_image(t, images):
    """Fixed symbol images extended homomorphically to active terms."""
    if t.tag != 'call':
        return Term(t.tag, tuple(apply_image(u, images) for u in t.args), t.name, t.symbol)
    args = tuple(apply_image(u, images) for u in t.args)
    if t.symbol.name in images:
        # Image is specified in formal argument slots N,A, not by renormalizing.
        return subst(images[t.symbol.name], {'N':args[0], 'A':args[1]})
    return call(t.symbol, *args)

def formula_image(f, images):
    return Formula(f.tag, tuple(apply_image(t, images) for t in f.terms),
        tuple(formula_image(g, images) for g in f.children), f.variable)

def evaluate(t, env):
    if t.tag == 'var': return env[t.name]
    if t.tag == 'zero': return 0
    if t.tag == 'successor': return evaluate(t.args[0], env) + 1
    args = [evaluate(u, env) for u in t.args]
    count, initial = args
    # Closed forms for already defined helpers keep finite diagnostics small.
    if t.symbol == A: return count + initial
    if t.symbol == M: return (2 ** count) * initial
    result = initial
    for counter in range(count):
        result = evaluate(t.symbol.descriptor, {'v':result, 'w':counter})
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    opts = parser.parse_args()
    assert size(A.descriptor) == 2
    assert size(M.descriptor) == 5
    assert fsize(ordinary_module(A)) == 23
    assert fsize(ordinary_module(M)) == 42
    records = []
    actual_checks = metadata_checks = standard_checks = image_module_checks = 0
    samples = [n, a, Z(), S(n), S(S(a)), call(A,n,a), call(M,n,a),
               call(A,call(M,n,a),S(n))]
    g = v
    for j in range(1,9):
        g = call(A,g,g)
        if j < 2: continue
        b = call(M,numeral(j),v)
        G = Symbol(f'G_{j}',g,2)
        B = Symbol(f'B_{j}',b,2)
        stride = v
        for _ in range(j): stride = S(stride)
        P = Symbol(f'P_{j}',stride,2)
        power_image = call(M,call(P,V('N'),Z()),V('A'))
        fold_image = call(B,V('N'),V('A'))
        count = 2**j
        assert unfold(M,j,v) == g
        assert size(g) == 4*count-3
        assert active_occurrences(g,'v') == count
        assert size(b) == j+8
        assert active_occurrences(b,'v') == 1
        assert active_occurrences(g,'w') == 0
        assert active_occurrences(b,'w') == 0
        assert fsize(ordinary_module(G)) == 4*count**2+11*count+4
        assert fsize(ordinary_module(B)) == 4*j+47
        assert fsize(ordinary_module(P)) == 4*j+19
        assert size(call(G,n,a)) == 4*count
        assert size(call(B,n,a)) == j+11
        assert size(subst(power_image,{'N':n,'A':a})) == j+11
        saved = 4*count-j-11
        assert saved > 0
        for nn in samples:
            for aa in samples:
                old = call(G,nn,aa)
                for image in [fold_image,power_image]:
                    translated = apply_image(old,{G.name:image})
                    assert size(old)-size(translated) == saved
                    assert free_vars(translated) <= free_vars(old)
                    actual_checks += 1
                altered = subst(old,{'v':S(Z()),'w':Z(),'n':S(a),'a':M.descriptor})
                assert altered.symbol is G
                assert altered.symbol.descriptor is g
                assert free_vars(old) == free_vars(nn)|free_vars(aa)
                metadata_checks += 1
        for image in [fold_image,power_image]:
            old_module = ordinary_module(G)
            new_module = formula_image(old_module,{G.name:image})
            assert fsize(new_module) < fsize(old_module)
            image_module_checks += 1
        # Finite standard-number checks complement, but do not replace, induction.
        for nn in range(5):
            for aa in range(6):
                env = {'n':nn,'a':aa}
                expected = (2**(j*nn))*aa
                assert evaluate(call(G,n,a),env) == expected
                assert evaluate(call(B,n,a),env) == expected
                assert evaluate(subst(power_image,{'N':n,'A':a}),env) == expected
                standard_checks += 1
        records.append({
            'j':j,'state_occurrences_old':count,
            'descriptor_old':size(g),'descriptor_folded':size(b),
            'call_old':size(call(G,n,a)),'call_folded':size(call(B,n,a)),
            'call_powered':size(subst(power_image,{'N':n,'A':a})),
            'per_call_saving_for_arbitrary_arguments':saved,
            'ordinary_module_old':fsize(ordinary_module(G)),
            'ordinary_module_folded':fsize(ordinary_module(B)),
            'ordinary_stride_module':fsize(ordinary_module(P)),
            'literal_unfolding_matches':True,
        })
    result = {
        'status':'passed',
        'scope':'finite syntax/count/metadata and bounded standard-number diagnostics; not proof-assistant verification',
        'helpers':{'A_descriptor':2,'A_ordinary_module':23,'M_descriptor':5,'M_ordinary_module':42},
        'families':records,
        'checks':{'j_values':7,'arbitrary_actual_term_sample_pairs_and_two_images':actual_checks,
                  'metadata_freezing_samples':metadata_checks,
                  'standard_number_triples':standard_checks,
                  'literal_source_axiom_image_size_checks':image_module_checks},
        'not_checked':['full infinite bi-interpretability theorem','arbitrary source-normalizer code',
                       'global shortestness','all finite proof package support costs']
    }
    serialized = json.dumps(result,indent=2)+'\n'
    if opts.output:
        opts.output.parent.mkdir(parents=True,exist_ok=True)
        opts.output.write_text(serialized,encoding='utf-8')
    print(serialized,end='')

if __name__ == '__main__': main()
