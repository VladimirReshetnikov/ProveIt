A SMALLER PRESENTATION OF INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
3 November 2026

Start with report.pdf. SPECIFICATION.txt gives the complete exact theory
without requiring the explanatory prose.

The report preserves the smallest current witnessed-boundary fixed core,
retains its published reference deletions, and proves three further
reductions: inverse iteration at variable counters, correctly shifted
fusion for counter-dependent updates, and elimination of autonomous finite
powers. It proves full first-order intuitionistic bi-interpretability and
equiconsistency, including identity round trips on nonstandard inputs.

For every surviving current source, a separate exact homomorphic image
preserves its complete interface and never enlarges a finite axiom packet.
This is a source-wise lower-envelope theorem, not a mixture of incompatible
prefixes. The fixed arithmetic record is matched, while infinite families
of descriptions improve strictly. No absolute shortestness or universal
proof-length bound is claimed.

CONTENTS
  report.tex, sections/*.tex   Complete mathematical manuscript
  report.pdf                  Compiled manuscript
  SPECIFICATION.txt           Exact standalone axiomatization and maps
  artifacts/check_*.py        Standard-library diagnostic programs
  artifacts/*_results.json    Reproducible diagnostic receipts
  provenance/                 Pinned source inventory, hashes, audit table
  build.py                    Checks, LaTeX compilation, checksums, ZIP
  SHA256SUMS.txt               Delivery file checksums

REBUILD
  python3 build.py
  python3 build.py --checks-only
  python3 build.py --archive

Requires Python 3.10+ and pdflatex with the standard packages listed in
report.tex. No third-party Python packages are needed by the checkers.
Build intermediates and logs go into build/ and are excluded from the ZIP.

VERIFICATION SCOPE
The unrestricted mathematical claims are established by written proofs.
The Python checks validate finite syntax and full occurrence counts,
metadata scope, bounded arithmetic identities, and scan invariants.
They do not formally verify the infinite theorem or nonstandard models.

SOURCES
ProveIt commit bb3a54d599619c8c0795bcf107811cbbe47ea7b0.
Four current and three archived proposals were reviewed. All four current
ones improve on some aspect of the immediately preceding iteration.
Original source archives are referenced by exact identifiers, not copied
into this delivery. Source-dependent audit receipts are supplementary;
the bundled checkers run without downloading those archives.
