#!/usr/bin/env python3
"""Rebuild the diagnostics, manuscript, checksums, and optional ZIP."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
CHECKS = [
    ("check_inverse.py", "inverse_results.json"),
    ("check_shifted_fusion.py", "shifted_fusion_results.json"),
    ("check_folding.py", "folding_results.json"),
    ("check_scan.py", "scan_results.json"),
]


def deliverable_files() -> list[Path]:
    return sorted(
        p for p in ROOT.rglob("*")
        if p.is_file()
        and "build" not in p.relative_to(ROOT).parts
        and "__pycache__" not in p.relative_to(ROOT).parts
        and p.suffix != ".pyc"
        and p.name != "SHA256SUMS.txt"
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks-only", action="store_true")
    parser.add_argument("--archive", action="store_true")
    args = parser.parse_args()
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    for script, output in CHECKS:
        result = subprocess.run(
            [sys.executable, str(ROOT / "artifacts" / script),
             "--output", str(ROOT / "artifacts" / output)],
            cwd=ROOT, text=True, capture_output=True, check=True,
        )
        (build / (script + ".log")).write_text(result.stdout + result.stderr)
        receipt = json.loads((ROOT / "artifacts" / output).read_text())
        if receipt.get("status") != "passed":
            raise RuntimeError(f"Checker did not pass: {script}")
        print(f"PASS {script}")
    if args.checks_only:
        return
    latex = shutil.which("pdflatex")
    if not latex:
        raise RuntimeError("pdflatex is required to build report.pdf")
    for pass_number in range(1, 4):
        result = subprocess.run(
            [latex, "-interaction=nonstopmode", "-halt-on-error",
             "-file-line-error", "-output-directory", str(build), "report.tex"],
            cwd=ROOT, text=True, capture_output=True,
        )
        (build / f"latex_pass_{pass_number}.txt").write_text(result.stdout + result.stderr)
        if result.returncode:
            print(result.stdout[-5000:])
            raise RuntimeError(f"LaTeX pass {pass_number} failed")
    log = (build / "report.log").read_text(errors="replace")
    if "undefined references" in log.lower() or "undefined citations" in log.lower():
        raise RuntimeError("Unresolved LaTeX references remain")
    shutil.copy2(build / "report.pdf", ROOT / "report.pdf")
    checksums = "".join(
        f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}\n"
        for p in deliverable_files()
    )
    (ROOT / "SHA256SUMS.txt").write_text(checksums)
    print("Built report.pdf and SHA256SUMS.txt")
    if args.archive:
        archive = ROOT.parent / (ROOT.name + ".zip")
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for p in deliverable_files() + [ROOT / "SHA256SUMS.txt"]:
                z.write(p, ROOT.name + "/" + p.relative_to(ROOT).as_posix())
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None:
                raise RuntimeError("ZIP CRC validation failed")
        print(f"Created {archive.name}")


if __name__ == "__main__":
    main()
