#!/usr/bin/env python3
"""Build the primary paper offline; requires a local pdflatex installation."""
from pathlib import Path
import shutil
import subprocess


def main():
    root = Path(__file__).resolve().parent
    engine = shutil.which("pdflatex")
    if engine is None:
        raise SystemExit("pdflatex is required; the already compiled PDF is included.")
    command = [engine, "-no-shell-escape", "-interaction=nonstopmode",
               "-halt-on-error", "report.tex"]
    for _ in range(3):
        result = subprocess.run(command, cwd=root, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if result.returncode:
            print(result.stdout[-14000:])
            raise SystemExit(result.returncode)
    log = (root / "report.log").read_text(errors="replace")
    problems = [line for line in log.splitlines()
                if "undefined" in line.lower() or "Overfull" in line]
    print("PDF built:", root / "report.pdf")
    if problems:
        print("Layout/reference diagnostics:")
        print("\n".join(problems))
    else:
        print("No undefined references or overfull boxes reported.")


if __name__ == "__main__":
    main()
