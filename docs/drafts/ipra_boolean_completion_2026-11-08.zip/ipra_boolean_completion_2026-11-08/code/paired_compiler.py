#!/usr/bin/env python3
"""Direct one-binder compilation and symbolic endpoint certificates.

This is a syntax/compiler verifier, not an iPRA proof checker.  The endpoint
certificate verifier instantiates three proof schemes established in the
paper: numerical selector endpoints, paired-binder congruence, and transparent
padding D[x,y] G[y] A <-> A (x,y fresh for A).  No truth evaluator, oracle,
finite numerical approximation, or external Python package is used.

Run from any directory:
    python3 paired_compiler.py

The script writes results/paired_compiler.json and
results/paired_compiler_example.json relative to this package.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from pathlib import Path
import json


# Immutable, explicitly tagged syntax.  Application names denote arbitrary
# fixed numerical functions; they are deliberately not evaluated here.
def V(name):
    return ("v", name)


ZERO = ("0",)


def S(t):
    return ("s", t)


def C(n, a, b):
    return ("c", n, a, b)


def P(t):
    return ("p", t)


def App(name, *args):
    return ("app", name, *args)


def Eq(a, b):
    return ("eq", a, b)


def D(x, y, body):
    if x == y:
        raise ValueError("The two binders must be distinct")
    return ("D", x, y, body)


def term_vars(t):
    if t[0] == "v":
        return {t[1]}
    if t[0] == "0":
        return set()
    children = t[2:] if t[0] == "app" else t[1:]
    return set().union(*(term_vars(a) for a in children))


def free_vars(a):
    if a[0] == "eq":
        return term_vars(a[1]) | term_vars(a[2])
    if a[0] == "D":
        return free_vars(a[3]) - {a[1], a[2]}
    raise ValueError("Not a native formula")


def all_names(a):
    if a[0] == "eq":
        return free_vars(a)
    if a[0] == "D":
        return {a[1], a[2]} | all_names(a[3])
    raise ValueError("Not a native formula")


def depth(a):
    if a[0] == "eq":
        return 0
    if a[0] == "D":
        return 1 + depth(a[3])
    raise ValueError("Not a native formula")


class Fresh:
    def __init__(self, avoid=()):
        self.used = set(avoid)
        self.index = 0

    def take(self):
        while True:
            name = "_b" + str(self.index)
            self.index += 1
            if name not in self.used:
                self.used.add(name)
                return name


def term_subst(t, env):
    """Simultaneous substitution: replacement terms are not resubstituted."""
    if t[0] == "v":
        return env.get(t[1], t)
    if t[0] == "0":
        return t
    if t[0] == "app":
        return ("app", t[1], *(term_subst(a, env) for a in t[2:]))
    return (t[0], *(term_subst(a, env) for a in t[1:]))


def subst(a, env):
    """Capture-avoiding simultaneous substitution in a native formula."""
    env = dict(env)
    if a[0] == "eq":
        return Eq(term_subst(a[1], env), term_subst(a[2], env))
    if a[0] != "D":
        raise ValueError("Not a native formula")
    _, x, y, body = a
    env.pop(x, None)
    env.pop(y, None)
    replacement_vars = set().union(*(term_vars(t) for t in env.values()))
    supply = Fresh(all_names(a) | replacement_vars | set(env))
    names = [x, y]
    for i, old in enumerate(names):
        if old in replacement_vars:
            new = supply.take()
            body = subst(body, {old: V(new)})
            names[i] = new
    return D(names[0], names[1], subst(body, env))


def aligned_body(a, x, y):
    """Caller supplies names fresh for the entire input formula."""
    if a[0] != "D":
        raise ValueError("Paired root required")
    return subst(a[3], {a[1]: V(x), a[2]: V(y)})


def gate(control, a):
    if a[0] == "eq":
        return Eq(C(control, ZERO, a[1]), C(control, ZERO, a[2]))
    _, x, y, body = a
    if {x, y} & term_vars(control):
        supply = Fresh(all_names(a) | term_vars(control))
        xx, yy = supply.take(), supply.take()
        body = aligned_body(a, xx, yy)
        x, y = xx, yy
    return D(x, y, gate(control, body))


def alpha_key(a):
    """Independent de Bruijn-style key for alpha-equivalence checks."""
    def term_key(t, stack):
        if t[0] == "v":
            for i, name in enumerate(reversed(stack)):
                if name == t[1]:
                    return ("bound", i)
            return ("free", t[1])
        if t[0] == "0":
            return t
        if t[0] == "app":
            return ("app", t[1], *(term_key(b, stack) for b in t[2:]))
        return (t[0], *(term_key(b, stack) for b in t[1:]))

    def go(f, stack):
        if f[0] == "eq":
            return ("eq", term_key(f[1], stack), term_key(f[2], stack))
        return ("D", go(f[3], stack + [f[1], f[2]]))

    return go(a, [])


@dataclass(frozen=True)
class SelectorCertificate:
    left: tuple
    right: tuple
    control: str
    output: tuple
    rule: str
    binders: tuple = ()
    child: SelectorCertificate | None = None


def selector(a, b, z):
    if z in all_names(a) | all_names(b):
        raise ValueError("Selector control must be fresh for both operands")
    supply = Fresh(all_names(a) | all_names(b) | {z})

    def go(left, right):
        if left[0] == right[0] == "eq":
            out = Eq(C(V(z), left[1], right[1]), C(V(z), left[2], right[2]))
            return out, SelectorCertificate(left, right, z, out, "leaf")
        x, y = supply.take(), supply.take()
        aa = aligned_body(left, x, y) if left[0] == "D" else gate(V(y), left)
        bb = aligned_body(right, x, y) if right[0] == "D" else gate(V(y), right)
        body, child = go(aa, bb)
        rule = "both" if left[0] == right[0] == "D" else (
            "left_padding" if left[0] == "eq" else "right_padding"
        )
        out = D(x, y, body)
        return out, SelectorCertificate(left, right, z, out, rule, (x, y), child)

    return go(a, b)


def verify_selector(cert):
    """Replay the endpoint proof schemas and exact maximum-depth proof.

    Rejection is by False, including malformed or altered certificate data.
    This verifier trusts the three explicitly stated mathematical schemes,
    not an assertion that arbitrary semantic equivalences are decidable.
    """
    try:
        a, b, z, out = cert.left, cert.right, cert.control, cert.output
        if z in all_names(a) | all_names(b):
            return False
        if cert.rule == "leaf":
            expected = Eq(C(V(z), a[1], b[1]), C(V(z), a[2], b[2]))
            return (
                a[0] == b[0] == "eq" and cert.child is None
                and not cert.binders and out == expected and depth(out) == 0
            )
        if len(cert.binders) != 2 or cert.child is None:
            return False
        x, y = cert.binders
        if x == y or {x, y} & (all_names(a) | all_names(b) | {z}):
            return False
        expected_rule = "both" if a[0] == b[0] == "D" else (
            "left_padding" if a[0] == "eq" and b[0] == "D" else (
                "right_padding" if a[0] == "D" and b[0] == "eq" else None
            )
        )
        if cert.rule != expected_rule:
            return False
        aa = aligned_body(a, x, y) if a[0] == "D" else gate(V(y), a)
        bb = aligned_body(b, x, y) if b[0] == "D" else gate(V(y), b)
        child = cert.child
        return (
            alpha_key(child.left) == alpha_key(aa)
            and alpha_key(child.right) == alpha_key(bb)
            and child.control == z and verify_selector(child)
            and out == D(x, y, child.output)
            and depth(out) == max(depth(a), depth(b))
        )
    except (AttributeError, IndexError, TypeError, ValueError, RecursionError):
        return False


def normalize_term(t):
    """Only the exact C and predecessor computation equations are used."""
    if t[0] in ("v", "0"):
        return t
    if t[0] == "app":
        return ("app", t[1], *(normalize_term(a) for a in t[2:]))
    args = tuple(normalize_term(a) for a in t[1:])
    if t[0] == "c":
        n, a, b = args
        if n == ZERO:
            return a
        if n[0] == "s":
            return b
    if t[0] == "p":
        if args[0] == ZERO:
            return ZERO
        if args[0][0] == "s":
            return args[0][1]
    return (t[0], *args)


def strip_gate(a, control_name):
    """Recognize an exact syntactic gate; return None when it is absent."""
    if a[0] == "eq":
        sides = a[1:]
        if all(t[0] == "c" and t[1] == V(control_name) and t[2] == ZERO for t in sides):
            return Eq(sides[0][3], sides[1][3])
        return None
    if control_name in a[1:3]:
        return None
    inner = strip_gate(a[3], control_name)
    return None if inner is None else D(a[1], a[2], inner)


def normalize_formula(a):
    """Selector endpoints plus the proved transparent-padding equivalence."""
    if a[0] == "eq":
        return Eq(normalize_term(a[1]), normalize_term(a[2]))
    _, x, y, body = a
    body = normalize_formula(body)
    stripped = strip_gate(body, y)
    if stripped is not None and not ({x, y} & free_vars(stripped)):
        return normalize_formula(stripped)
    return D(x, y, body)


def source_names(a):
    if a[0] == "eq":
        return free_vars(a)
    if a[0] == "bottom":
        return set()
    if a[0] in ("all", "ex"):
        return {a[1]} | source_names(a[2])
    return source_names(a[1]) | source_names(a[2])


def source_free_vars(a):
    if a[0] == "eq":
        return free_vars(a)
    if a[0] == "bottom":
        return set()
    if a[0] in ("all", "ex"):
        return source_free_vars(a[2]) - {a[1]}
    return source_free_vars(a[1]) | source_free_vars(a[2])


def source_height(a):
    if a[0] in ("eq", "bottom"):
        return 0
    if a[0] in ("all", "ex"):
        return 1 + source_height(a[2])
    return 1 + max(source_height(a[1]), source_height(a[2]))


def compile_source(source):
    supply = Fresh(source_names(source))
    certificates = []

    def merge(a, b, z):
        result, certificate = selector(a, b, z)
        # Reserve every newly created bound name before creating outer binders.
        supply.used.update(all_names(result))
        certificates.append(certificate)
        return result

    def go(a):
        tag = a[0]
        if tag == "eq":
            return a
        if tag == "bottom":
            return Eq(ZERO, S(ZERO))
        if tag in ("all", "ex"):
            x, body = a[1], go(a[2])
            y = supply.take()
            if tag == "ex":
                return D(x, y, gate(V(y), body))
            u = supply.take()
            return D(u, y, gate(V(y), subst(body, {x: P(V(y))})))
        if tag not in ("imp", "and", "or"):
            raise ValueError("Unknown first-order connective")
        left, right = go(a[1]), go(a[2])
        z = supply.take()
        matrix = merge(left, right, z)
        other = supply.take()
        if tag == "imp":
            return D(other, z, matrix)
        if tag == "or":
            return D(z, other, gate(V(other), matrix))
        # Use a distinct bound gate variable to make the substitution explicit.
        gate_name = supply.take()
        matrix = subst(matrix, {z: P(V(gate_name))})
        return D(other, gate_name, gate(V(gate_name), matrix))

    return go(source), certificates


def generic_formula(level, family):
    """Uninterpreted leaf functions leave all arithmetic parameters symbolic."""
    names = [(f"x{family}_{i}", f"y{family}_{i}") for i in range(level)]
    args = [V("a"), V("b")] + [V(n) for pair in names for n in pair]
    a = Eq(App("f" + str(family), *args), App("g" + str(family), *reversed(args)))
    for x, y in reversed(names):
        a = D(x, y, a)
    return a


def main():
    endpoint_checks = 0
    selector_certificates = 0
    altered_rejections = 0
    depth_records = []
    for left_depth in range(6):
        for right_depth in range(6):
            left = generic_formula(left_depth, 0)
            right = generic_formula(right_depth, 1)
            out, cert = selector(left, right, "control")
            assert verify_selector(cert)
            selector_certificates += 1
            assert depth(out) == max(left_depth, right_depth)
            expected = [(ZERO, left), (S(V("n")), right)]
            for control_term, original in expected:
                actual = normalize_formula(subst(out, {"control": control_term}))
                assert alpha_key(actual) == alpha_key(normalize_formula(original))
                endpoint_checks += 1
            broken = replace(cert, output=Eq(ZERO, S(ZERO)))
            assert not verify_selector(broken)
            altered_rejections += 1
            if cert.binders:
                broken = replace(cert, binders=(cert.binders[0], cert.binders[0]))
                assert not verify_selector(broken)
                altered_rejections += 1
            depth_records.append([left_depth, right_depth, depth(out)])

    # Independent scope regressions: free input x must not become bound.
    original = D("x", "y", Eq(V("a"), V("x")))
    replaced = subst(original, {"a": V("x")})
    expected = D("u", "v", Eq(V("x"), V("u")))
    assert alpha_key(replaced) == alpha_key(expected)
    assert free_vars(replaced) == {"x"}
    assert term_subst(App("f", V("x"), V("y")), {"x": V("y"), "y": V("x")}) == App("f", V("y"), V("x"))
    gated = gate(V("x"), D("x", "y", Eq(V("x"), V("y"))))
    assert free_vars(gated) == {"x"}
    assert gated[1] != "x" and depth(gated) == 1

    atom_a = Eq(App("f", V("x"), V("a")), V("y"))
    atom_b = Eq(V("x"), App("g", V("a")))
    samples = [atom_a, ("bottom",)]
    for binary in ("imp", "and", "or"):
        samples.append((binary, atom_a, atom_b))
        samples.append((binary, ("all", "x", atom_a), ("ex", "y", atom_b)))
    samples += [
        ("all", "x", ("ex", "x", atom_a)),
        ("ex", "x", ("all", "y", ("imp", atom_a, atom_b))),
        ("all", "x", ("and", ("or", atom_a, ("bottom",)), ("ex", "y", atom_b))),
    ]
    nested = atom_a
    for i in range(12):
        nested = (("imp", "and", "or")[i % 3], atom_b, nested)
        samples.append(nested)
    logical_depth_records = []
    compiled = None
    for source in samples:
        compiled, certs = compile_source(source)
        assert depth(compiled) == source_height(source)
        assert free_vars(compiled) == source_free_vars(source)
        assert all(verify_selector(c) for c in certs)
        logical_depth_records.append([source_height(source), depth(compiled), len(certs)])

    report = {
        "status": "PASS",
        "purpose": "Direct paired-binder syntax compilation and symbolic endpoint certificates",
        "selector_certificates": selector_certificates,
        "symbolic_endpoint_checks": endpoint_checks,
        "altered_certificates_rejected": altered_rejections,
        "scope_regressions": 3,
        "source_formula_examples": len(samples),
        "selector_depth_records": depth_records,
        "source_height_and_output_depth_records": logical_depth_records,
        "trusted_mathematical_schemes": [
            "C(0,s,t)=s and C(Sn,s,t)=t",
            "paired-binder congruence for uniform interderivability",
            "D[x,y] G[y] A is interderivable with A when x,y are fresh for A",
        ],
        "limits": [
            "The universal correctness statements are proved by induction in the paper.",
            "These are finite symbolic schema instances, not full native proof-tree replays.",
            "No Lean/Rocq formalization or new complete iPRA checker is claimed.",
            "The exact depth result is an output bound, not an optimality theorem.",
        ],
    }
    results = Path(__file__).resolve().parent.parent / "results"
    results.mkdir(parents=True, exist_ok=True)
    (results / "paired_compiler.json").write_text(json.dumps(report, indent=2) + "\n")
    example_source = samples[9]
    example, proofs = compile_source(example_source)
    (results / "paired_compiler_example.json").write_text(json.dumps({
        "source": example_source,
        "native": example,
        "source_height": source_height(example_source),
        "native_depth": depth(example),
        "selector_certificates": [asdict(c) for c in proofs],
    }, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in (
        "status", "selector_certificates", "symbolic_endpoint_checks",
        "altered_certificates_rejected", "source_formula_examples"
    )}, indent=2))


if __name__ == "__main__":
    main()
