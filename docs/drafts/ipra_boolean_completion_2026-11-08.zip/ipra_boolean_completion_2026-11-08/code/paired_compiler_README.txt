DIRECT PAIRED-BINDER COMPILER

Run:
  python3 code/paired_compiler.py

No third-party packages or network access are needed. The program writes
results/paired_compiler.json and results/paired_compiler_example.json.

What is implemented
  * Explicit tagged syntax for numerical terms and formulas A ::= s=t | D[x,y] A.
  * Capture-avoiding simultaneous substitution and an independent alpha-key.
  * Gating, direct transparent padding, and a selector that never introduces
    an auxiliary existential or closure constructor into native formulas.
  * Direct compilation of implication, conjunction, disjunction, universal
    quantification, existential quantification, and falsity.
  * Endpoint proof-schema certificates, replayed independently of the
    selector constructor, and symbolic endpoint normalization.

What the check establishes
  All 36 pairs of generic symbolic operand depths 0 through 5 produce valid
  endpoint-schema certificates. Their output depth is the maximum of the
  two input depths. Both symbolic endpoints are normalized and compared up
  to alpha-equivalence (72 checks). Altered formulas and repeated-binder
  certificates are rejected (71 negative examples). Scope regressions cover
  capture avoidance, simultaneous substitutions, and a gate whose control
  name collides with an input binder. The 23 source formulas check all five
  ordinary connectives, quantifier shadowing, skewed formula trees, exact
  height-to-depth compilation, and preservation of free numerical variables.

Trusted mathematical schemes and limits
  The certificate replay uses the selector computation equations, paired
  binder congruence, and the transparent-padding equivalence proved in
  Section 5 of the paper. It is a small verifier of these proof schemas.
  The symbolic normalizer additionally knows the already established
  predecessor equations. It never evaluates uninterpreted leaf functions.
  The universal correctness of the algorithms is established by the paper's
  structural-induction arguments. Finite symbolic instances do not replace
  those arguments. No full native proof-tree replay, Lean/Rocq formalization,
  complete iPRA checker, minimal-depth theorem for individual formulas, or
  reduction below the benchmark checker sizes is claimed.

The example JSON contains one complete source formula, its native output,
and the selector certificates used during that compilation. All arithmetic
function names in its leaves are fixed symbolic names, not code numbers for
a universal evaluator.
