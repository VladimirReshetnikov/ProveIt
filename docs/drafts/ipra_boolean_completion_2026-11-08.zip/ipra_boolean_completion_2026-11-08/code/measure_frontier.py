"""Reproduce the whole-program iPRA source frontier without network access.

The inherited source normalizer and all comparator sources are hash checked.
The measured checkers are parsed, never imported or executed. Their correctness
is a separate mathematical claim; this script measures only source size.
"""

from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import platform


ROOT = Path(__file__).resolve().parents[1]
MEASURES = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def verified_path(entry):
    path = ROOT / entry["file"]
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != entry["sha256"]:
        raise ValueError(f"Changed frozen source: {entry['file']}")
    return path


def import_boundary(path):
    modules = set()
    for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
        if isinstance(node, ast.Import):
            modules.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            modules.add(node.module)
    if modules != {"json", "sys"}:
        raise ValueError(f"Unexpected trusted imports: {path.name}: {modules}")
    return sorted(modules)


def main():
    manifest = json.loads((ROOT / "reference/checker_manifest.json").read_text())
    metric_path = verified_path(manifest["metric"])
    spec = importlib.util.spec_from_file_location("frozen_source_measure", metric_path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    rows = []
    for entry in manifest["programs"]:
        path = verified_path(entry)
        imports = import_boundary(path)
        measured = metric.metrics(path)
        if measured["sha256"] != entry["sha256"]:
            raise ValueError(f"Measurement hash mismatch: {entry['file']}")
        rows.append({**entry, **measured, "trusted_imports": imports})
    baseline = [row for row in rows if row["role"] == "complete_inherited_standalone"]
    prototypes = [row for row in rows if row["role"] == "exploratory_prototype"]
    if len(baseline) != 12 or len(prototypes) != 1:
        raise ValueError("Unexpected comparison inventory")
    minima = {key: min(row[key] for row in baseline) for key in MEASURES}
    receipt = {
        "status": "PASS",
        "scope": "Whole-source measurements only; no new checker and no universal correctness test.",
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "repository": manifest["repository"],
        "current_commit": manifest["commit"],
        "current_archive_count": manifest["current_archive_count"],
        "historical_frontier_commit": manifest["historical_frontier_commit"],
        "complete_program_count": len(baseline),
        "prototype_count": len(prototypes),
        "metric_source": manifest["metric"],
        "coordinatewise_minimum": minima,
        "attainers": {
            key: [row["label"] for row in baseline if row[key] == minima[key]]
            for key in MEASURES
        },
        "programs": rows,
    }
    results = ROOT / "results"
    results.mkdir(exist_ok=True)
    (results / "frontier.json").write_text(json.dumps(receipt, indent=2) + "\n")
    lines = [
        r"\begin{center}",
        r"\begin{tabular}{@{}lrrr@{}}",
        r"\toprule",
        r"Inherited complete checker & Tokens & AST nodes & Bytes\\",
        r"\midrule",
    ]
    for row in baseline:
        values = [
            r"\textbf{" + str(row[key]) + "}" if row[key] == minima[key] else str(row[key])
            for key in MEASURES
        ]
        lines.append(row["label"] + " & " + " & ".join(values) + r"\\")
    lines.extend([r"\midrule", r"Current exploratory prototype & Tokens & AST nodes & Bytes\\"])
    for row in prototypes:
        lines.append(row["label"] + " & " + " & ".join(str(row[key]) for key in MEASURES) + r"\\")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{center}"])
    (results / "frontier_table.tex").write_text("\n".join(lines) + "\n")
    print(json.dumps({
        "status": receipt["status"],
        "complete_program_count": len(baseline),
        "prototype_count": len(prototypes),
        "coordinatewise_minimum": minima,
        "prototype": {key: prototypes[0][key] for key in MEASURES},
    }, indent=2))


if __name__ == "__main__":
    main()
