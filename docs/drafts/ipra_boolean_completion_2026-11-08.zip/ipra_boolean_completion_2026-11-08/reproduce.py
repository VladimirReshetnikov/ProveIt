#!/usr/bin/env python3
"""Reproduce the finite evidence; this is not a full metatheorem verifier."""
from pathlib import Path
import json
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parent
    for script in ("code/measure_frontier.py", "code/paired_compiler.py"):
        subprocess.run([sys.executable, str(root / script)], cwd=root, check=True)
    print(json.dumps({
        "status": "PASS",
        "verified": ["frozen source identities and whole-program measurements",
                     "direct paired-binder compiler symbolic instances"],
        "not_formalized": ["general first-order partial cut elimination",
                           "universal localized proof translation",
                           "global conservation theorem",
                           "full arithmetic bi-interpretation"]
    }, indent=2))


if __name__ == "__main__":
    main()
