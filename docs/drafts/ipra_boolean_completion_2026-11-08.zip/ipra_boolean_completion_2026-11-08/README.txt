BOOLEAN COMPLETION AND A DIRECT PAIRED-BINDER CALCULUS FOR iPRA
============================================================
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date).

STATUS
------
The requested strict improvement in complete proof-checker complexity has
NOT been achieved. No absolute simplestness claim or new record checker
is advertised. The current observed coordinate minima remain 317 normalized
Python tokens / 348 AST nodes / 885 bytes, with different attainers.

The primary deliverable is report.pdf, compiled from report.tex and sections/.
It gives new mathematical results relative to the six inspected current
archives, an explicit complete inherited reference axiomatization, both
interpretation composites, and a precise account of what remains unresolved.

MAIN NEW RESULTS RELATIVE TO THE INSPECTED CORPUS
------------------------------------------------
1. Quotient-local falsity repairs the previous Boolean-gluing restriction.
   Translate bottom to E_p(0,1), the collapse of that quotient, and likewise
   for the complementary quotient. Explosion and the falsity bridge then
   translate soundly. This is a syntactic localization, not an ordinary
   falsity-preserving interpretation into a nontrivial factor.

2. Gluing extends to positive retained assumptions and conclusions H generated
   by equations, bottom, conjunction, both quantifiers, and P -> H with P
   positive. There is also a separately delimited local double-negation result.

3. GLOBAL CONSERVATION: scalar computation + literal-equation induction +
   the falsity bridge proves exactly the same positive-context/H sequents as
   the completed scalar theory with Boolean range. First eliminate compound
   cuts, leaving atomic cuts; the polarity invariant makes every remaining
   context positive; then eliminate every Boolean branch by localized gluing.
   The theorem yields equiconsistency with full iPRA, but NOT bi-interpretability.
   The inherited Kripke-fan symmetry argument excludes that stronger conclusion.

4. Direct transparent padding D[x,y] G[y] A is equivalent to A. It gives a
   selector directly in the one-binder grammar, with output depth exactly
   max(d(A),d(B)). All five ordinary connectives/quantifiers can be compiled
   with one additional paired level each. The scalar arithmetic bootstrap
   and the earlier existential-universal fusion remain attributed to the drafts.

COMPLETE BASIS
--------------
Section 2 lists all ordinary logical rules, the scalar schemas, literal-equation
induction, Boolean range, and the falsity bridge. It also states the inherited
four-pattern native clausal calculus and every side condition. Section 6 gives
both whole-domain interpretations and both identity composites. The exact
inherited scalar arithmetic report is retained as reference/equational_core/.

Do not confuse the four-pattern native clausal presentation with the five-pattern
auxiliary calculus implemented by the minimum frozen Python programs. Their
context and formula representations differ; the report explicitly accounts for it.

FILES
-----
report.pdf / report.tex / sections/     Primary research paper and editable source
code/paired_compiler.py                Direct syntax compiler and symbolic schemas
code/paired_compiler_README.txt        Exact certificate trust boundary
code/measure_frontier.py               Offline whole-program source comparison
reference/checkers/                   12 unchanged complete sources + 1 prototype
reference/checker_manifest.json        Current archive/source identities
reference/equational_core/             Unchanged inherited mathematical reference
results/                              Reproducible evidence and comparison tables
build.py                              Offline PDF compilation
reproduce.py                          Re-run finite executable evidence
package.py                            Rebuild manifest and ZIP after deliberate edits
MANIFEST.json                         SHA-256 of every other packaged payload file
ATTRIBUTION.txt                        Contribution and provenance boundaries

REPRODUCE
---------
Use Python 3.10+ for the scripts; CPython 3.12.14 was used for the recorded
source metrics. No nonstandard Python dependencies or network access are needed.

    python3 reproduce.py

This verifies source identities, recomputes the 13 comparison rows, and checks
36 selector certificates / 72 symbolic endpoints, rejects 71 altered certificates,
and checks 23 source formulas for exact depth and free-variable preservation.
The scripts do NOT implement general first-order cut elimination, do NOT verify
the universal metatheorems by finite testing, and are NOT a new competitive kernel.
No Lean or Rocq formalization is included.

To rebuild the primary PDF with local TeX Live/MiKTeX:

    python3 build.py

Packages required: fontenc, inputenc, lmodern, microtype, geometry, amsmath,
amssymb, amsthm, mathtools, booktabs, longtable, array, enumitem, xcolor,
fancyhdr, needspace, hyperref. Shell escape is disabled. A compiled PDF is included.

After deliberate changes, regenerate checksums and the archive:

    python3 package.py

PINNED SOURCE
-------------
Repository: VladimirReshetnikov/ProveIt
Commit:     9773e5e0376fdaf953567d0e1e6f19570d566bc6
Directory:  docs/drafts (six current ZIPs, all verified by Git blob hash)
https://github.com/VladimirReshetnikov/ProveIt/tree/9773e5e0376fdaf953567d0e1e6f19570d566bc6/docs/drafts

The twelve complete comparison sources are retained by these current archives
from predecessor snapshot 06e097f723c659030816e0194e5eb7e8c607ba9b. No remote
repository changes were made. No claim of historical priority beyond the
inspected corpus is made for the new mathematical refinements.
