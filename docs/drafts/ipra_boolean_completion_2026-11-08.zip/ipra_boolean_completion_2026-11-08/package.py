#!/usr/bin/env python3
"""Generate an integrity manifest and ZIP of the complete deliverable."""
from pathlib import Path
import hashlib
import json
import zipfile


def main():
    root = Path(__file__).resolve().parent
    unwanted = {".aux", ".log", ".out", ".toc", ".fls", ".fdb_latexmk", ".synctex.gz"}
    files = sorted(p for p in root.rglob("*") if p.is_file()
                   and p.suffix not in unwanted
                   and "__pycache__" not in p.parts
                   and p.name != "MANIFEST.json")
    records = [{"path": str(p.relative_to(root)), "bytes": p.stat().st_size,
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
    manifest = root / "MANIFEST.json"
    manifest.write_text(json.dumps({"algorithm": "SHA-256", "files": records},
                                  indent=2) + "\n")
    target = root.with_suffix(".zip")
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in files + [manifest]:
            z.write(p, root.name + "/" + str(p.relative_to(root)))
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
    print(json.dumps({"archive": str(target), "files": len(files) + 1,
                      "bytes": target.stat().st_size,
                      "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}, indent=2))


if __name__ == "__main__":
    main()
