A SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 6 November 2026

Start with report.pdf. Its complete source is report.tex and sections/.
The only trusted acceptance implementation is checker.py.

RESULT

The full native calculus uses numerical equality, a guarded universal binder,
and existence, with initialized primitive recursion, equation induction and
numerical cases. The report specifies every primitive logical/nonlogical
rule, derives full intuitionistic logic and quantifier-free induction, and
proves a faithful ordinary realization bi-interpretable with first-order
intuitionistic PRA with quantifier-free induction. Both interpretation
domains are the entire number sort, with equality as both internally
definable round-trip isomorphisms.

The mathematical basis is inherited and credited to the supplied draft
series. The new checker reduction uses demand validation of elimination
annotations and direct hypothesis indexing, together with two simple API
and context-handling changes. Its measures, including the complete CLI, are:

                              Current draft envelope    This checker
  Significant source tokens             664                   637
  Normalized tokens                     662                   635
  AST nodes                             712                   675
  Normalized source bytes             2,150                 2,055
  Raw source bytes                    2,441                 2,205

The comparison includes 158 distinct standalone checkers in 741 occurrences
from all six archives at ProveIt commit:
  02b045f9f8d7887b27b853520f2cbfa374725a76
The comparison uses current sources, not the older minima quoted inside
the drafts. It is a finite-corpus improvement, not an absolute minimality
theorem. The full four-step ablation retains the original documentation and
already beats the raw-byte envelope; shorter documentation is reported
separately.

REPRODUCE OFFLINE

Python 3.12 reproduces the recorded normalization metrics. The checker itself
requires Python 3.10 or newer. No third-party Python packages or network
access are required for checking, tests or measurement.

  python3 reproduce.py
  python3 checker.py examples/zero_plus_n.json
  python3 reproduce.py --pdf

The PDF option needs pdfLaTeX and the packages listed in report.tex. build.py
can generate a temporary local format when needed; it downloads nothing.

Certificates are finite JSON arrays [context, goal, proof]. The API is
check(context, goal, proof). Numerical zero is -1, while nonnegative integers
in terms are de Bruijn variables. A proof leaf is a context index. The
designated contradiction is ["=", -1, ["s", -1]].

CERTIFICATE NORMALIZATION

The new checker has the same derivable sequents as the strict baseline, but
not exactly the same accepted certificate strings. It allows an arbitrary
unused instantiation annotation when neither child of a guarded universal
depends on its bound number. Such an annotation normalizes to numerical zero.
If the number is used, substitution traverses and validates the entire term.
Equality templates always undergo full formula validation.

Signed negative context indices and Boolean aliases for 0/1 are accepted
lookup spellings. They select actual validated context formulas. They do
not introduce a new axiom or permit a malformed assumption or conclusion.

The untrusted normalizer preserves the exact context and goal and checks its
result with the appropriate complete checker:

  python3 normalize.py to-strict examples/vacuous_null.json strict.json
  python3 strict_control.py strict.json
  python3 normalize.py to-index strict.json indexed.json
  python3 checker.py indexed.json

The optional strict_control.py retains the prior formula-hypothesis format
and eager validation while also beating the current envelope: 692 AST nodes,
650 normalized tokens and 2,106 normalized bytes.

EXECUTED EVIDENCE

- 549 frozen unique triples, with exact archive/member provenance.
- All 159 accepted by the strict baseline translated in both directions
  and rechecked, preserving context and conclusion.
- The strict control agrees with the baseline on all 549 triples.
- Dedicated invalid-witness, nested-scope, selector, context and goal tests.
- 390 composed normalization checks; 21 portable example certificates.
- Eight CLI checks, including ordinary Python and python -O.
- Independent demand audit: 528 matrices, 2,640 valid substitutions,
  4,927 unused-invalid successes equal to zero substitution, and 1,937
  used-invalid rejections, plus full-certificate checks.
- Frozen-source hashes, all five size measures, and a four-step ablation.

The report gives general mathematical proofs. These tests are finite
implementation evidence; no Lean/Rocq formalization is claimed. The Python
runtime's finite memory/recursion limits can reject sufficiently large
otherwise valid certificates.

DIRECTORY GUIDE

checker.py                  Complete trusted acceptance source
strict_control.py           Strict same-format smaller control
normalize.py                Untrusted bidirectional proof translator
report.tex, sections/       Complete LaTeX source
report.pdf                  Compiled report
examples/                   21 accepted certificates
validation/                 Frozen baseline, corpus, tests and audit
comparison/                 158 exact competitor sources and measurement
results/                    Executed verification, metrics and PDF QA
reproduce.py                Offline reproduction entry point
build.py                    Offline PDF builder
package.py                  Deterministic ZIP and hash-manifest builder
LICENSE_SOURCE.txt          Source repository's MIT-0 license
MANIFEST.sha256             Delivered file hashes (excluding itself)

The checker imports only Python's standard json and sys modules. It imports
no proof generator, scanner, normalizer, baseline, comparison code, or test.
