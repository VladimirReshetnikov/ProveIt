"""Reproduce the complete offline comparison and finite verification evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CHECKER_SHA256 = "67d0fa6095dfa8c2d59de42bccc7d296f5c455158802815785e6cdc3a177b1a8"


def run(script, *args):
    result = subprocess.run([sys.executable, str(ROOT / script), *map(str, args)],
                            cwd=ROOT, capture_output=True, text=True)
    if result.returncode:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        raise RuntimeError("Reproduction failed: " + script)
    print(script + ": passed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true", help="also rebuild report.pdf")
    args = parser.parse_args()
    digest = hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest()
    if digest != CHECKER_SHA256:
        raise RuntimeError("Frozen checker changed; audit before reusing the recorded claims.")
    run("comparison/measure.py", "--candidate", ROOT / "checker.py", "--require-strict")
    run("comparison/ablation.py")
    run("validation/run_tests.py")
    run("validation/independent_review.py")
    if args.pdf:
        run("build.py")
    result = {"status": "all requested checks passed",
              "python_version": platform.python_version(),
              "checker_sha256": digest, "pdf_built": args.pdf,
              "qualification": "Finite implementation evidence; mathematical metatheorems are not formally verified."}
    (ROOT / "results/reproduction.json").write_text(json.dumps(result, indent=2) + "\n")
    print("All requested reproduction steps passed.")


if __name__ == "__main__":
    main()
