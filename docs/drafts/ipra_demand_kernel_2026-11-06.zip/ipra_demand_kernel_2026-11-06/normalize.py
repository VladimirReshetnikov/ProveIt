"""Untrusted, terminating translations between certificate formats.

normalize_data converts accepted indexed/demand certificates to strict
formula-leaf certificates. index_data translates in the reverse direction.
The checker imports none of this module.
"""
import checker as kernel


def shift_context(g):
    return list(map(kernel.subst, g))


def to_strict(p, g):
    match p:
        case [('lam' | 'pack') as tag, a, q]:
            h = a if tag == 'lam' else ['=', 0, kernel.subst(a, formula=False)]
            return [tag, a, to_strict(q, shift_context(g) + [h])]
        case ['use', major, *args]:
            principal = kernel.infer(major, g)
            tag, *parts = principal
            converted = to_strict(major, g)
            if tag == 'ex':
                q, = args
                return ['use', converted, to_strict(q, shift_context(g) + parts)]
            a, q = args
            if tag == 'pi':
                try:
                    kernel.subst(a, formula=False)
                except Exception:
                    # Successful demand-checking proves the witness is absent
                    # from both binder children. Zero has the same instances.
                    a = -1
            return ['use', converted, a, to_strict(q, g)]
        case ['r', _, _, _]:
            return p
        case ['nat', a, q]:
            return ['nat', a, to_strict(q, g)]
        case _:
            return g[p]


def normalize_data(data):
    kernel.check(*data)
    g, a, p = data
    return [g, a, to_strict(p, g)]


def to_index(p, g):
    match p:
        case [('lam' | 'pack') as tag, a, q]:
            h = a if tag == 'lam' else ['=', 0, kernel.subst(a, formula=False)]
            return [tag, a, to_index(q, shift_context(g) + [h])]
        case ['use', major, *args]:
            converted = to_index(major, g)
            tag, *parts = kernel.infer(converted, g)
            if tag == 'ex':
                q, = args
                return ['use', converted, to_index(q, shift_context(g) + parts)]
            a, q = args
            return ['use', converted, a, to_index(q, g)]
        case ['r', _, _, _]:
            return p
        case ['nat', a, q]:
            return ['nat', a, to_index(q, g)]
        case _:
            return g.index(p)


def index_data(data):
    g, a, p = data
    return [g, a, to_index(p, g)]


def main():
    import argparse
    import json
    from pathlib import Path
    import strict_control

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("direction", choices=("to-strict", "to-index"))
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding="utf-8"))
    if args.direction == "to-strict":
        converted = normalize_data(data)
        strict_control.check(*converted)
    else:
        strict_control.check(*data)
        converted = index_data(data)
        kernel.check(*converted)
    args.output.write_text(json.dumps(converted, separators=(",", ":")) + "\n",
                           encoding="utf-8")
    print("Converted certificate:", args.output)


if __name__ == "__main__":
    main()
