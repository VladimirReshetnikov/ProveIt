"""Build a deterministic ZIP and verify its complete file manifest."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex.gz"}


def included(path):
    relative = path.relative_to(ROOT)
    return (path.is_file() and "__pycache__" not in relative.parts
            and not any(part.startswith(".") for part in relative.parts)
            and path.suffix not in EXCLUDED_SUFFIXES
            and path.name != "MANIFEST.sha256")


def main():
    files = sorted(p for p in ROOT.rglob("*") if included(p))
    manifest = ROOT / "MANIFEST.sha256"
    manifest.write_text("".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  "
                                + p.relative_to(ROOT).as_posix() + "\n" for p in files))
    destination = ROOT.with_suffix(".zip")
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted([*files, manifest]):
            name = ROOT.name + "/" + path.relative_to(ROOT).as_posix()
            entry = zipfile.ZipInfo(name, date_time=(2026, 11, 6, 0, 0, 0))
            entry.external_attr = 0o100644 << 16
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("ZIP integrity failure")
        for row in manifest.read_text().splitlines():
            digest, name = row.split("  ", 1)
            data = archive.read(ROOT.name + "/" + name)
            if hashlib.sha256(data).hexdigest() != digest:
                raise RuntimeError("Archive hash mismatch: " + name)
    print(f"Verified {len(files)} manifest entries and ZIP integrity.")
    print(destination)


if __name__ == "__main__":
    main()
