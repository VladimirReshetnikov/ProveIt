"""Independent finite checks of the annotation-demand substitution lemma.

This tests a concrete risk of deleting eager witness validation. It is not a
formal verification or a general proof of the kernel metatheory.
"""
from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parent
CANDIDATE = ROOT.parent / 'checker.py'
spec = importlib.util.spec_from_file_location('reviewed_kernel', CANDIDATE)
kernel = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kernel)


def free_zero(node, depth=0):
    """Independent occurrence predicate for the distinguished free variable."""
    if type(node) is int:
        return node == depth
    match node:
        case ['s', term]:
            return free_zero(term, depth)
        case ['r', counter, initial, step]:
            return (free_zero(counter, depth) or free_zero(initial, depth)
                    or free_zero(step, depth + 2))
        case ['=', left, right]:
            return free_zero(left, depth) or free_zero(right, depth)
        case ['pi', antecedent, consequent]:
            return free_zero(antecedent, depth + 1) or free_zero(consequent, depth + 1)
        case ['ex', matrix]:
            return free_zero(matrix, depth + 1)
        case _:
            raise ValueError('Unexpected generated syntax')


terms = [-1, 0, 1, 2, 3, 4]
terms += [['s', n] for n in terms]
terms += [['r', n, a, h] for n in [-1, 0, ['s', -1]]
          for a in [-1, 0, 1] for h in [-1, 0, 1, 2, 3, 4]]
truth = ['=', -1, -1]
matrices = [['=', t, -1] for t in terms]
matrices += [['ex', a] for a in matrices[:]]
matrices += [['pi', a, truth] for a in matrices[:]]
matrices += [['pi', truth, a] for a in matrices[:]]
valid = [-1, 0, 3, ['s', 0], ['r', 0, -1, 2]]
invalid = [None, False, True, -2, 0.0, '', '0', [], {}, ['s'],
           ['s', True], ['=', 0, 0], ['r', -1, -1, None]]
counts = {'wellformed_substitutions': 0, 'unused_invalid_annotations': 0,
          'used_invalid_annotation_rejections': 0}
for matrix in matrices:
    kernel.subst(matrix)
    zero_instance = kernel.subst(matrix, [-1, -1])
    for annotation in valid:
        result = kernel.subst(matrix, [annotation, -1])
        kernel.subst(result)
        counts['wellformed_substitutions'] += 1
    for annotation in invalid:
        used = free_zero(matrix)
        try:
            result = kernel.subst(matrix, [annotation, -1])
        except Exception:
            assert used, (matrix, annotation)
            counts['used_invalid_annotation_rejections'] += 1
        else:
            assert not used, (matrix, annotation)
            assert result == zero_instance, (matrix, annotation)
            counts['unused_invalid_annotations'] += 1

# Full certificates separating occurrence in antecedent versus consequent.
# Failures may not be hidden by a vacuous other child.
for a, b in [(truth, ['=', 0, 0]), (['=', 0, 0], truth),
             (truth, ['ex', ['=', 1, 1]]),
             (truth, ['=', ['r', -1, -1, 2], -1])]:
    g = [['pi', a, b], truth]
    for annotation in invalid:
        try:
            kernel.infer(['use', 0, annotation, 1], g)
        except Exception:
            continue
        raise AssertionError(('used bad annotation accepted', a, b, annotation))

# For a genuinely vacuous Pi, malformed payloads normalize to ZERO.
for annotation in invalid:
    data = [[['pi', truth, truth], truth], truth, ['use', 0, annotation, 1]]
    assert kernel.check(*data)
    zero_data = [data[0], data[1], ['use', 0, -1, 1]]
    assert kernel.check(*zero_data)

result = {
    'candidate_sha256': hashlib.sha256(CANDIDATE.read_bytes()).hexdigest(),
    'formula_matrices': len(matrices), 'valid_annotations': len(valid),
    'invalid_annotations': len(invalid), **counts,
    'full_certificate_used_annotation_rejections': 4 * len(invalid),
    'full_certificate_vacuous_normalizations': len(invalid),
    'qualification': 'Finite tests support the structural substitution lemma; they are not its proof.'
}
(ROOT.parent / 'results/independent_review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
