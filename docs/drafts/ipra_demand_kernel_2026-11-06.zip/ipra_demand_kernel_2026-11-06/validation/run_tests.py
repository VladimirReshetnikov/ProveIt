"""Offline tests of the complete checker, strict control and translations.

This runner and every file it imports are outside the trusted checker.
The frozen corpus is intentionally broader than valid proof certificates.
"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import io
import json
import subprocess
import sys
import tempfile
import tokenize

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from normalize import normalize_data, index_data, to_index, kernel
import strict_control


def ensure(condition, message):
    if not condition:
        raise AssertionError(message)


def load_reference():
    spec = importlib.util.spec_from_file_location("strict_reference", ROOT / "validation/baseline.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


baseline = load_reference()


def accepts(module, data, direct=False):
    try:
        return bool(module.check(*data) if direct else module.check(data))
    except Exception:
        return False


def check_roundtrip(data):
    ensure(accepts(kernel, data, True), "Indexed certificate was rejected")
    result = normalize_data(data)
    ensure(result[:2] == data[:2], "Normalization changed the sequent")
    ensure(accepts(baseline, result), "Strict reference rejected the normalized proof")
    ensure(accepts(strict_control, result, True), "Strict control rejected normalized proof")
    ensure(accepts(kernel, index_data(result), True), "Reverse translation was rejected")
    return result


def metrics(path):
    program = path.read_text(encoding="utf-8")
    tree = ast.parse(program)
    if (tree.body and isinstance(tree.body[0], ast.Expr)
            and isinstance(tree.body[0].value, ast.Constant)
            and isinstance(tree.body[0].value.value, str)):
        tree.body.pop(0)
    normalized = ast.unparse(tree) + "\n"
    skip = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT, tokenize.NL,
            tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}
    return {"raw_bytes": len(program.encode()),
            "normalized_bytes": len(normalized.encode()),
            "normalized_tokens": sum(t.type not in skip for t in
                                     tokenize.generate_tokens(io.StringIO(normalized).readline)),
            "ast_nodes": sum(1 for _ in ast.walk(tree)),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def run():
    provenance = json.loads((ROOT / "validation/corpus_provenance.json").read_text())
    corpus_path = ROOT / "validation/corpus.jsonl"
    ensure(hashlib.sha256(corpus_path.read_bytes()).hexdigest() == provenance["corpus_sha256"],
           "Frozen corpus digest mismatch")
    baseline_provenance = json.loads((ROOT / "validation/baseline_provenance.json").read_text())
    ensure(hashlib.sha256((ROOT / "validation/baseline.py").read_bytes()).hexdigest()
           == baseline_provenance["source_sha256"], "Frozen reference checker digest mismatch")
    records = [json.loads(line) for line in corpus_path.read_text().splitlines()]
    ensure(len(records) == 549, "The frozen corpus must contain exactly 549 unique triples")
    digests = set()
    accepted = []
    rejected_count = 0
    for record in records:
        digest, data = record["sha256"], record["data"]
        actual = hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()
        ensure(digest == actual and digest not in digests, "Duplicate or corrupted corpus record")
        digests.add(digest)
        original = accepts(baseline, data)
        control = accepts(strict_control, data, True)
        ensure(original == record["baseline_accepts"], "Reference acceptance changed")
        ensure(control == original, "Strict control differs from original certificate language")
        if not original:
            rejected_count += 1
            continue
        indexed = index_data(data)
        check_roundtrip(indexed)
        accepted.append(indexed)
    ensure(len(accepted) == 159 and rejected_count == 390, "Unexpected corpus acceptance totals")

    valid_annotations = [-1, 0, ["s", -1], ["r", -1, -1, 0]]
    invalid_annotations = [None, False, True, -2, 0.0, "", "abc", {}, [],
                           ["s"], ["s", True], ["=", 0, 0], ["r", -1, -1, None]]
    truth = ["=", -1, -1]
    contradiction = ["=", -1, ["s", -1]]
    vacuous = ["pi", truth, truth]
    bound = ["pi", ["=", 0, 0], ["=", 0, 0]]
    for annotation in valid_annotations + invalid_annotations:
        check_roundtrip([[vacuous, truth], truth, ["use", 0, annotation, 1]])
    for annotation in invalid_annotations:
        ensure(not accepts(kernel, [[bound, truth], truth, ["use", 0, annotation, 1]], True),
               "Used malformed witness annotation was accepted")

    selectors = [0, 1, -1, -2, False, True]
    for selector in selectors:
        context = [truth, contradiction]
        check_roundtrip([context, context[selector], selector])
    invalid_selectors = [None, 2, -3, 0.0, "0", [], {}, ["=", -1, -1]]
    for selector in invalid_selectors:
        ensure(not accepts(kernel, [[truth, contradiction], truth, selector], True),
               "Invalid hypothesis selector was accepted")

    recursor = ["r", -1, -1, 0]
    equation = ["=", recursor, -1]
    malformed_contexts = [None, False, True, 0, -1, 0.0, "", "abc", {}, {"x": []}]
    for context in malformed_contexts:
        ensure(not accepts(kernel, [context, equation, recursor], True),
               "A malformed top-level context was accepted")
    for term in invalid_annotations:
        ensure(not accepts(kernel, [[["=", term, term]], ["=", term, term], 0], True),
               "A malformed term survived context or conclusion validation")

    # Demand checking must find the exiting variable under both formula
    # binders and beneath both slots introduced by a recursor body.
    nested_roots = [
        ["pi", truth, ["ex", ["=", 2, 2]]],
        ["ex", ["=", ["r", -1, -1, 3], ["r", -1, -1, 3]]],
        ["=", ["r", -1, -1, 2], ["r", -1, -1, 2]],
    ]
    for matrix in nested_roots:
        principal = ["pi", matrix, matrix]
        for annotation in invalid_annotations:
            try:
                kernel.infer(["use", 0, annotation, 1], [principal, truth])
            except (TypeError, ValueError, KeyError, IndexError):
                continue
            raise AssertionError("Nested witness occurrence escaped demand validation")

    composition_count = 0
    for indexed in accepted:
        context, conclusion, proof = indexed
        if context:
            continue
        lifted = kernel.subst(conclusion)
        principal = ["pi", lifted, lifted]
        # Converting from stored formula leaves also moves assumption
        # indices correctly when the new premise extends the outer context.
        strict_proof = normalize_data(indexed)[2]
        reindexed = to_index(strict_proof, [principal])
        for annotation in invalid_annotations:
            check_roundtrip([[principal], conclusion, ["use", 0, annotation, reindexed]])
            composition_count += 1
    ensure(composition_count == 390, "Unexpected composed-normalization total")

    example_paths = sorted((ROOT / "examples").glob("*.json"))
    ensure(len(example_paths) == 21, "Expected 21 packaged example certificates")
    for path in example_paths:
        check_roundtrip(json.loads(path.read_text()))

    # Exercise the actual public command-line boundaries, including -O.
    # This also checks useful normalizer CLI paths from an unrelated cwd.
    cli_runs = 0
    with tempfile.TemporaryDirectory(prefix="ipra-certificate-check-") as temporary:
        temporary = Path(temporary)
        normalized_path = temporary / "strict.json"
        indexed_path = temporary / "indexed.json"
        rejected_path = temporary / "rejected.json"
        rejected_path.write_text(json.dumps([[], contradiction, recursor]) + "\n")
        source_path = ROOT / "examples/vacuous_null.json"
        for options in ([], ["-O"]):
            for path, expected in ((source_path, True), (rejected_path, False)):
                proc = subprocess.run([sys.executable, *options, str(ROOT / "checker.py"), str(path)],
                                      cwd=temporary, capture_output=True, text=True)
                ensure((proc.returncode == 0) == expected,
                       "Checker CLI exit status disagreed with expectation")
                ensure(proc.stdout.strip() == ("ACCEPT" if expected else "REJECT"),
                       "Checker CLI output disagreed with expectation")
                cli_runs += 1
        for direction, source, destination, checker in (
            ("to-strict", source_path, normalized_path, "strict_control.py"),
            ("to-index", normalized_path, indexed_path, "checker.py"),
        ):
            proc = subprocess.run([sys.executable, str(ROOT / "normalize.py"), direction,
                                   str(source), str(destination)],
                                  cwd=temporary, capture_output=True, text=True)
            ensure(proc.returncode == 0, "Normalizer CLI failed: " + proc.stderr)
            proc = subprocess.run([sys.executable, str(ROOT / checker), str(destination)],
                                  cwd=temporary, capture_output=True, text=True)
            ensure(proc.returncode == 0 and proc.stdout.strip() == "ACCEPT",
                   "Checker rejected CLI-normalized certificate")
            cli_runs += 2

    result = {
        "python": sys.version,
        "snapshot_commit": provenance["commit"],
        "unique_inputs": len(records),
        "strict_control_agrees_with_baseline": len(records),
        "baseline_accepted_translated_and_normalized": len(accepted),
        "baseline_rejected": rejected_count,
        "vacuous_annotation_tests": len(valid_annotations) + len(invalid_annotations),
        "used_invalid_annotation_rejections": len(invalid_annotations),
        "selector_tests": len(selectors) + len(invalid_selectors),
        "malformed_context_rejections": len(malformed_contexts),
        "malformed_statement_rejections": len(invalid_annotations),
        "nested_bad_annotation_rejections": len(nested_roots) * len(invalid_annotations),
        "composed_normalizations": composition_count,
        "packaged_examples_replayed": len(example_paths),
        "cli_subprocess_checks": cli_runs,
        "checker_metrics": metrics(ROOT / "checker.py"),
        "strict_control_metrics": metrics(ROOT / "strict_control.py"),
        "reference_metrics": metrics(ROOT / "validation/baseline.py"),
        "corpus_sha256": provenance["corpus_sha256"],
        "status": "all checks passed",
    }
    output = ROOT / "results/validation.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    run()
