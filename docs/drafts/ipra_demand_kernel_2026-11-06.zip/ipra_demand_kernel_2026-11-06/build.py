"""Build report.pdf offline, initializing a temporary pdfLaTeX format if needed."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def run(args, cwd, env=None):
    process = subprocess.run(args, cwd=cwd, env=env, capture_output=True, text=True)
    if process.returncode:
        raise RuntimeError(process.stdout[-16000:] + process.stderr[-3000:])


def main():
    if not shutil.which("pdflatex"):
        raise RuntimeError("A TeX installation providing pdfLaTeX is required.")
    with tempfile.TemporaryDirectory(prefix="ipra-format-") as directory:
        env = os.environ.copy()
        existing = subprocess.run(["kpsewhich", "pdflatex.fmt"],
                                  capture_output=True, text=True)
        local_format = not existing.stdout.strip()
        if local_format:
            run(["pdftex", "-ini", "-jobname=pdflatex", "-progname=pdflatex",
                 "-etex", "-interaction=nonstopmode", "-halt-on-error", "pdflatex.ini"],
                directory)
            env["TEXFORMATS"] = directory + os.pathsep + env.get("TEXFORMATS", "")
        for _ in range(3):
            run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                 "-file-line-error", "report.tex"], ROOT, env)
    log = (ROOT / "report.log").read_text(errors="replace")
    warnings = [line for line in log.splitlines() if "Overfull" in line
                or "undefined" in line.lower() or "Rerun to get" in line
                or "Label(s) may have changed" in line]
    result = {"pdf": "report.pdf", "passes": 3,
              "local_format_initialized": local_format,
              "layout_or_reference_warnings": warnings}
    (ROOT / "results/latex.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    if warnings:
        raise RuntimeError("Resolve the reported layout or reference warnings before delivery.")


if __name__ == "__main__":
    main()
