OFFLINE COMPARISON AGAINST THE SIX CURRENT DRAFTS

Snapshot: VladimirReshetnikov/ProveIt commit
02b045f9f8d7887b27b853520f2cbfa374725a76, directory docs/drafts.

This folder freezes 158 byte-distinct complete-checker candidate sources,
covering 741 occurrences within the six supplied ZIP archives. Every source
is stored under its original SHA-256 digest and remains byte-for-byte equal
to its archived original. manifest.json gives each exact archive filename
and ZIP member path, archive SHA-256 and Git blob SHA-1, and source identity.
snapshot_manifest.json is copied unchanged from the retrieved repository
snapshot manifest.

Reproduce the baseline comparison from any working directory:

  python3 /absolute/path/to/comparison/measure.py

Compare a new checker:

  python3 /absolute/path/to/comparison/measure.py \
    --candidate /absolute/path/to/checker.py --require-strict

The script writes metrics.json and primary_table.tex beside itself. Optional
--output and --table arguments choose other paths. It requires only Python's
standard library. All compared source is parsed; none is imported or run.
The SHA-256 of every frozen comparator is checked before measurement.

The five current coordinatewise minima are:
  significant source tokens        664
  significant normalized tokens    662
  executable AST nodes             712
  normalized source bytes        2,150
  original source bytes          2,441

Inferred elimination holds the first four minima. The unsuffixed compact
kernel holds the raw-byte minimum. The six primary rows are included in
primary_table.csv. Unlike the older comparisons embedded in these drafts,
this comparison includes the six new primary checkers themselves.

ACCOUNTING AND SELECTION

A broad syntactic filter selected every parseable Python source containing
__main__, defining check/check_proof/accept at module scope, and importing
only json and sys (or neither). Variants and controls are included, not only
recommended root checkers. The complete inventory had 890 Python-file
occurrences, 241 byte-distinct sources, and no parse failures.

all_python_inventory.json records metadata for every distinct parsed source.
excluded_small_sources.txt lists every excluded individual file beating at
least one selected coordinate minimum. Inspection identifies those files as
support programs, adapters/translators, or incomplete modular components.
A project-local import must be counted together with its dependencies and
input adapter; a small component alone is not a complete proof checker. The
original drafts also record modular dependency groups; their complete sizes
exceed the present minima. This bundle does not repackage all support code.

The measurement boundary is the entire standalone checker: syntax/sorts,
binding/substitution, arithmetic, logic, hypothesis handling, final judgment
comparison, JSON/file input and command-line error handling. The interpreter
and standard-library json/sys implementations are common runtime dependencies.

ASTs lose only module/function/class docstrings. Source tokens omit comments,
structural whitespace and those docstrings. Normalization uses ast.unparse
of that stripped tree plus one newline. Raw bytes include documentation.
Python version is recorded because normalization can vary between versions.

These are reproducible comparisons against a pinned finite corpus. They are
not lower bounds on all possible axiomatizations or proof-checking programs,
and do not establish absolute minimality. The envelope combines minima from
several files; it need not be achieved by one existing checker.

SEQUENTIAL ABLATION

  python3 /absolute/path/to/comparison/ablation.py

This starts from the exact frozen inferred-elimination primary checker and
replays four exact edits: direct API, context concatenation, indexed
hypotheses, and demand validation. The baseline docstring remains unchanged
through all stages. Sources are written to ablations/; the delivered checker
must have the same executable AST as the final stage. The script writes
results/ablation.json, results/ablation_table.tex, and results/numbers.tex in
the package root. Documentation-byte savings are reported separately.
