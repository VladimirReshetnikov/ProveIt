"""Reproduce four exact edits from the strongest current primary baseline.

All four stages retain the baseline's original docstring. The final staged
executable AST must equal the delivered checker after removing docstrings.
This program does not execute any staged or compared checker source.
"""
import ast
import hashlib
import json
from pathlib import Path
import sys

import measure

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT.parent
STAGES = ROOT / 'ablations'
RESULTS = PACKAGE / 'results'
FIELDS = measure.FIELDS


def replace_once(source, before, after):
    if source.count(before) != 1:
        raise ValueError('Expected exactly one occurrence of edit: ' + repr(before))
    return source.replace(before, after, 1)


def executable_ast(source):
    tree = ast.parse(source)
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                node.body.pop(0)
    return ast.dump(tree, include_attributes=False)


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    matches = [source for source in manifest['sources'] if any(
        origin['role'] == 'primary' and origin['archive'] == 'ipra_inferred_elimination_2026-11-06.zip'
        for origin in source['origins'])]
    if len(matches) != 1:
        raise ValueError('Ambiguous or missing inferred-elimination baseline')
    baseline = matches[0]
    source = (ROOT / baseline['file']).read_text()
    if hashlib.sha256(source.encode()).hexdigest() != baseline['sha256']:
        raise ValueError('Baseline source identity changed')
    edits = [
        ('Direct API', '01_direct_api.py', [
            ('def check(data):\n    g, a, p = data\n', 'def check(g, a, p):\n'),
            ('check(json.load(stream))', 'check(*json.load(stream))'),
        ]),
        ('Context concatenation', '02_context_concatenation.py', [
            ('    require(type(g) is list)\n    for b in [*g, a]:\n', '    for b in g + [a]:\n'),
        ]),
        ('Indexed hypotheses', '03_indexed_hypotheses.py', [
            ('return g[g.index(p)]', 'return g[p]'),
        ]),
        ('Demand validation', '04_demand_validation.py', [
            ('            subst(a, formula=tag != "pi")\n', ''),
        ]),
    ]
    STAGES.mkdir(exist_ok=True)
    RESULTS.mkdir(exist_ok=True)
    rows = []
    def record(label, filename, previous=None):
        path = STAGES / filename
        path.write_text(source)
        row = {'label': label, 'file': str(path.relative_to(PACKAGE)), **measure.measure(path)}
        if previous:
            row['saving_from_previous'] = {field: previous[field] - row[field] for field in FIELDS}
        rows.append(row)
    record('Inferred-elimination baseline', '00_baseline.py')
    edit_records = []
    for label, filename, replacements in edits:
        for before, after in replacements:
            source = replace_once(source, before, after)
        record(label, filename, rows[-1])
        edit_records.append({'label': label, 'replacements': [
            {'before': before, 'after': after} for before, after in replacements]})
    candidate_path = PACKAGE / 'checker.py'
    candidate_source = candidate_path.read_text()
    if executable_ast(source) != executable_ast(candidate_source):
        raise ValueError('Four exact edits do not yield the delivered executable AST')
    candidate = measure.measure(candidate_path)
    if any(rows[-1][field] != candidate[field] for field in FIELDS if field != 'raw_bytes'):
        raise ValueError('Executable measurements disagree with delivered checker')
    result = {
        'python_version': sys.version.split()[0], 'snapshot_commit': manifest['snapshot_commit'],
        'baseline_sha256': baseline['sha256'], 'candidate_sha256': candidate['sha256'],
        'stages_preserve_original_docstring': True, 'exact_edits': edit_records,
        'stages': rows, 'candidate': candidate,
        'final_executable_ast_equals_candidate': True,
        'final_documentation_and_formatting_raw_byte_saving': rows[-1]['raw_bytes'] - candidate['raw_bytes'],
        'qualification': ('A sequential implementation ablation. Direct API and context concatenation '
                          'preserve accepted finite JSON certificates. Indexed hypotheses change proof syntax. '
                          'Demand validation admits unused payloads normalized to zero. The report proves '
                          'preservation of derived sequents; raw documentation savings are shown separately.'),
    }
    (RESULTS / 'ablation.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = [r'\begin{tabular}{@{}lrrrrr@{}}', r'\toprule',
             r'Stage & Source tok. & Norm. tok. & AST & Norm. bytes & Raw bytes \\', r'\midrule']
    for row in rows:
        lines.append(row['label'] + ' & ' + ' & '.join(f'{row[field]:,}' for field in FIELDS) + r' \\')
    lines += [r'\midrule', 'Delivered documentation & '
              + ' & '.join(f'{candidate[field]:,}' for field in FIELDS) + r' \\',
              r'\bottomrule', r'\end{tabular}', '']
    (RESULTS / 'ablation_table.tex').write_text('\n'.join(lines))
    numbers = {
        'CandidateAST': candidate['ast_nodes'],
        'CandidateNormTokens': candidate['normalized_tokens'],
        'CandidateNormBytes': candidate['normalized_bytes'],
        'CandidateTokens': candidate['source_tokens'],
        'CandidateRawBytes': candidate['raw_bytes'],
        'BaselineCount': manifest['unique_source_count'],
        'BaselineOccurrences': manifest['source_occurrence_count'],
    }
    macros = ['% Generated by comparison/ablation.py from the final checker and frozen manifest.',
              '% Candidate SHA-256: ' + candidate['sha256']]
    macros.extend('\\newcommand{\\' + name + '}{' + f'{value:,}' + '}'
                  for name, value in numbers.items())
    (RESULTS / 'numbers.tex').write_text('\n'.join(macros) + '\n')
    print(json.dumps({key: result[key] for key in (
        'baseline_sha256', 'candidate_sha256', 'final_executable_ast_equals_candidate',
        'final_documentation_and_formatting_raw_byte_saving')}, indent=2))
    print(json.dumps([{key: row[key] for key in ('label', *FIELDS)} for row in rows], indent=2))


if __name__ == '__main__':
    main()
