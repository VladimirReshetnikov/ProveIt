ONE ASSUMPTION AT A TIME
A smaller iPRA proof kernel through complementary introductions
Research report prepared for Vladimir Reshetnikov, November 10, 2026.

START HERE

  report.pdf                 Complete mathematical and implementation report.
  report.tex                 Main TeX source, with sections/ and appendices/.
  report_standalone.tex      The same paper in one independently compilable file.
  code/native/               Three complete standalone scalar proof checkers.
  code/native/FORMAT.txt     Exact public packet grammar and correctness boundaries.
  code/native/validation/    Untrusted producers, explicit certificates, test receipts.
  code/readable/             Explicit full-PR proof-tree checker and old-to-new compiler.
  comparison/               Frozen old checkers, matched control, original normalizer.
  evidence/                 Measurements, corpus audit, source identities, replay receipts.
  reference/                Attributed original fixtures and inherited license.

MATHEMATICAL RESULT

Choice DI replaces the old simultaneous base/induction context by a choice
retaining one assumption. The base choice is allowed for every native formula;
the induction choice is allowed only when the matrix is literally an equation.
An outer case introduction and an inner induction introduction with an UNUSED
existential coordinate recover every old two-assumption introduction.

This is equivalence of the full consequence relation in arbitrary retained
contexts, in the identical native language. A finite proof with N inference
nodes and r atomic paired introductions translates to exactly N+5r nodes.
Formula and numerical interpretations are both provided. The numerical domain
and actual equality remain unchanged. The whole-domain internal composites,
not standard-numeral agreement alone, establish bi-interpretability with full
first-order intuitionistic PRA. The ordinary realization explicitly includes
the falsity bridge (0=S0) -> false.

COMPARISON

The snapshot is ProveIt commit 08edc6964d8990d2230179a9d65355ac1eee7a9e,
whose docs/drafts directory contains 22 ZIP archives. Complete-program counts
under CPython 3.12.14 and the unchanged supplied source_measure.py are:

  Program                          Tokens       AST nodes       Normalized bytes
  comparison/indexed_305.py           305             345                    860
  comparison/strict_341.py            308             341                    894
  comparison/padded_820.py            311             352                    820
  comparison/iterable_340.py          306             340                    859
  code/native/tokens.py               299             345                    880
  code/native/structure.py            304             340                    902
  code/native/bytes.py                307             353                    815

Different programs attain the coordinate minima. No single new program is
claimed to dominate the old coordinate envelope in all three measurements.
For mathematically terminating guarded traversals the envelope improves
305/341/820 -> 299/340/815. Including the old runtime-dependent iterable
traversal makes the old AST minimum 340, so that coordinate is tied.
The older identifier-renaming control was 816 bytes; byte counts preserve
identifier spelling and do not establish a naming-invariant lower bound.

All imports, validation, input, verdicts and rejection are counted. Only
comments/docstrings are omitted by the inherited normalizer. Each compact
checker imports only the Python standard json module. Producers and decoders
in this archive are not imported by those checkers.

The readable implementation is a separate audit representation, with named
choice modes and full staged PR declarations; it is not the source-size
record. Its size is explicitly reported. Its general untrusted compiler
implements the N+5r proof transformation.

RUNNING AND REPRODUCING

From this directory, with Python 3.12 (3.12.14 used for the recorded results):

  python3 reproduce.py

This needs only the Python standard library and no network. It replays all
147 converted inherited packets through all three final checkers, focused
positive/negative controls, normal and -O CLI runs, the separate readable
suite, the compiler node bounds, and the frozen whole-module measurements.
The native CLI suite has 1,032 runs. The readable suite has 169 passing
records, including 13 compiler receipts. Detailed records are retained.

To rebuild the PDF and standalone TeX as well, install a LaTeX distribution
with pdflatex, lmodern, microtype, geometry, the AMS packages, mathtools,
booktabs, enumitem, fancyhdr, xcolor, url and hyperref, then run:

  python3 reproduce.py --pdf

Alternatively, run python3 build.py, or compile report_standalone.tex with
pdflatex in any directory. The build script disables shell escape.

To recreate and verify the ZIP:

  python3 package.py

This writes a sibling ZIP with fixed member timestamps, excludes caches and
temporary LaTeX files, and checks every CRC and every manifest payload hash.
MANIFEST.sha256.json covers all payload files other than itself. ZIP hashes
depend on the retained evidence and PDF bytes; rebuilding with another
Python or TeX distribution can change these even when the mathematics and
checker source are unchanged.

Minimal compact-checker example, a zero computation certificate:

  echo '[[0,0],[[0,0,0],0]]' | python3 code/native/tokens.py

Output: ACCEPT. See FORMAT.txt for the exact grammar. Introduction head 0
selects induction at a literal equation; [] selects the base case. The
certificate interface has changed from the old simultaneous-assumption
checker. Completeness does not mean unchanged old packets always pass.

EVIDENCE AND LIMITS

The written metatheorems are accompanied by executable finite evidence,
not a Lean/Rocq formalization. This package does not assert absolute
minimality, a universal source-size lower bound, literature-wide priority,
smaller proof files in every case, or faster execution. The new result is
the complementary single-assumption rule and its identity-language proof
equivalence, new relative to the inspected draft corpus. The scalar basis,
logical reconstruction framework, arithmetic bootstrap and PR compiler
are inherited and attributed in ATTRIBUTION.txt and the paper.

The complete repository audit is recorded in evidence/. The comparator
sources needed to reproduce the displayed records are included; the full
22 third-party draft archives are not duplicated in this ZIP. Their pinned
Git blob and SHA-256 identities permit independent retrieval and audit.
