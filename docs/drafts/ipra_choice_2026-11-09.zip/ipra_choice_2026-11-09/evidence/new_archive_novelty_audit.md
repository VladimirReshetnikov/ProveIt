# Bounded novelty audit of two newly supplied archives

Date: 10 November 2026. Repository refresh reported by the parent: commit
`08edc6964d8990d2230179a9d65355ac1eee7a9e`, 22 archives.

## Scope

Read the adjacent-symmetry README, abstract, scope and novelty sections,
rule factorization, and two-valued restriction theorem. Read the exact-depth
README, scope and objective section, exact-depth and sharp-selector theorem
statements, and the complete native-basis section. Performed targeted text
searches of both reports' mathematical sources for introduction rules,
retained assumptions, one-assumption progression, and lower-bound claims.
This is a bounded mathematical novelty assessment, not a fresh verification
of either report's entire metatheory or an independent source-size audit.

## Adjacent symmetry

The presentation retains ordinary full intuitionistic first-order logic and
the complete PR-description grammar. Its new arithmetic rule derives
`f(t)=f(0)` from equality of opposite observations of adjacent trajectory
values. The advertised refinements are equality calibration, a coverage-free
latch, factorization into probe antisymmetry and zero stationarity, and a
restriction to two-valued templates.

This does not supply or state the Choice-DI reduction. In particular it does
not replace the two simultaneous local assumptions in native atomic DI by
an explicit choice of Case or Ind, or reconstruct old atomic DI by nested
introduction and elimination while retaining the original paired-binder
meaning.

The report and README explicitly state that the resulting complete checker
remains above the existing native frontier. Its numerical measurements must
be handled by the separate implementation audit; no new mathematical lower
bound on checker length is claimed.

Primary local sources:

- `reference/extracted/ipra_adjacent_symmetry_2026-11-09/ipra_adjacent_symmetry_2026-11-09/README.txt`
- `reference/extracted/ipra_adjacent_symmetry_2026-11-09/ipra_adjacent_symmetry_2026-11-09/ipra_adjacent_symmetry_2026-11-09.tex`

## Exact logical depth

The new results concern exact minimum formula depth in the fixed native
paired-binder grammar and sharp oracle thresholds for realizer selectors.
The report expressly distinguishes these from proof-checker source-size
lower bounds. Its native-basis section explicitly retains the old rule:

```
Gamma, B(t,0), [B(t,z)]_at |- B(t,Sz)
----------------------------------
Gamma |- D_{x,y} B(x,y)
```

Thus equations still receive both the base and induction hypothesis in the
single primitive introduction premise. The complete basis is identified as
inherited rather than a new part of the report.

The objective section mentions that "one-assumption progression" was
examined without establishing a successful new complete record. That is
relevant prior exploration and should not be hidden. It does not present
the Case/Ind choice rule or its same-language, same-meaning equivalence
proof. Accordingly, the defensible novelty statement is that our specific
Choice-DI reduction and corresponding completeness construction were not
found in the inspected corpus, not that nobody in the corpus considered
reducing the number of assumptions.

The depth/oracle theorems remain compatible with Choice-DI. Our change
preserves the formulas, their ordinary decoding, and every native sequent;
therefore it preserves the equivalence relation used to define minimum
formula depth. It makes no fixed-depth representation claim and changes
the inference interface rather than the formula grammar.

Primary local sources:

- `reference/extracted/ipra_exact_depth_2026-11-09/ipra_exact_depth_2026-11-09/README.txt`
- `reference/extracted/ipra_exact_depth_2026-11-09/ipra_exact_depth_2026-11-09/sections/01_scope.tex`
- `reference/extracted/ipra_exact_depth_2026-11-09/ipra_exact_depth_2026-11-09/sections/02_exact_depth.tex`
- `reference/extracted/ipra_exact_depth_2026-11-09/ipra_exact_depth_2026-11-09/sections/02b_sharp_selector.tex`
- `reference/extracted/ipra_exact_depth_2026-11-09/ipra_exact_depth_2026-11-09/sections/03_basis.tex`

## Conclusion

Neither newly examined archive establishes the Choice-DI construction.
Neither introduces a mathematical lower bound contradicted by the proposed
checker-interface reduction. The claim of a specific new reduction relative
to the inspected corpus survives this bounded check. Literature-wide
priority and absolute minimum checker size remain unproved.
