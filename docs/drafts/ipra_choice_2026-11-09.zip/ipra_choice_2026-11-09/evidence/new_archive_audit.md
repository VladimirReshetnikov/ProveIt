# Addendum: the five archives added at the final repository check

This addendum preserves and supplements `baseline_audit.md`. The original
audit pinned commit `195e4becb0a1f99c5598f7e39e2cdeb81461b2e4`, containing
17 archives. The final check found 22 archives at
`08edc6964d8990d2230179a9d65355ac1eee7a9e`. All original 17 Git blob identities
are unchanged. The five additional archives are audited here.

## Outcome

**The complete-checker comparison envelope is unchanged:**

| Comparison contract | Normalized tokens | AST nodes | Normalized bytes |
|---|---:|---:|---:|
| Strictly guarded, unrenamed complete sources | 305 | 341 | 820 |
| Including the qualified iterable-alias source | 305 | 340 | 820 |

The coordinate minima have different attainers. The older uniform-renaming
control at 816 bytes remains a separate qualification; these unrenamed
measurements are not naming-invariant bounds.

No complementary case/progress introduction with unchanged elimination was
found in the five new contribution texts or checkers. This is a comparison
against the inspected drafts, not a literature-wide priority assertion.

## Acquisition and measurement boundary

All five new ZIPs were independently checked against the Git blob SHA-1
reported in `evidence/snapshot.json`. SHA-256 and byte size were
also computed. Every extracted Python source was compared byte-for-byte with
its archive member. `new_source_inventory.json` records those checks and the
full measurements of **143 Python source occurrences**:

| Additional archive | Python sources |
|---|---:|
| `ipra_adjacent_symmetry_2026-11-09.zip` | 35 |
| `ipra_exact_depth_2026-11-09.zip` | 42 |
| `ipra_feedback_2026-11-09.zip` | 34 |
| `ipra_orbit_pulse_2026-11-09.zip` | 16 |
| `ipra_stationarity_envelope_2026-11-09.zip` | 16 |

Measurements use the already frozen repository `source_measure.py`, with
whole-module `ast.unparse` normalization, actual docstring/comment removal,
and the same Python 3.12 runtime. No new checker or proof producer was
executed merely to obtain its source size.

Every source potentially below an old coordinate was inspected by purpose.
The sub-305-token files are PDF builders, reproduction/packaging drivers, or
measurement utilities. They do not contain a complete acceptance engine.
The only complete source below the strict 341-AST coordinate is another
byte-identical copy of the already qualified 340-AST iterable checker.

## Contribution and checker findings

Paths below are relative to each archive's repeated top-level directory under
`reference/extracted/`. Full member paths and hashes appear in the inventory.

| Archive | Relevant new result | Complete new checker / metrics (tokens, AST, bytes) |
|---|---|---|
| Adjacent symmetry | An opposite-observation equality rule calibrates actual equality, and a successor-tail Boolean latch recovers QFI without a coverage axiom. | `code/checker.py`: **3242, 3447, 12919**. |
| Exact depth | Sharp native formula-depth and oracle-realizer selector bounds in the existing paired grammar. It expressly does not produce a smaller complete checker. | Republished complete comparators include the existing **305, 345, 860** indexed-major and **311, 352, 820** padded-major files. The new syntax/fusion compilers are not complete proof checkers. |
| Feedback | A reset rule forces the range and equality-reflection behavior of an initially unspecified comparison operation. | `code/feedback_checker.py`: **3316, 3526, 13382**; anchored variant: **3318, 3528, 13390**. |
| Orbit pulse | A closed-update equality detector shrinks from 70 to 52 expanded numerical nodes by restricting attention to the useful finite orbit. | `code/checker52.py`: **2665, 2906, 7809**. Its claimed improvement is against a matched ordinary-logic checker, not the native frontier. |
| Stationarity envelope | A definable directed-kernel quotient for recurrence candidates, with observational preservation results. The quotient-to-iPRA equivalence remains explicitly open. | Its seven compact comparison programs are unchanged copies. The new finite equational replay utility is not a complete iPRA checker. |

The primary statements were read in:

- Adjacent symmetry: `ipra_adjacent_symmetry_2026-11-09.tex`, abstract and
  result/comparison sections, together with `code/checker.py`.
- Exact depth: `report.tex`, `sections/01_scope.tex`, the exact-depth and
  selector sections, and the complete comparator inventory.
- Feedback: `ipra_feedback.tex`, its rule and implementation sections,
  Appendix `app:rejected`, and both feedback checkers.
- Orbit pulse: `report.tex`, the closed-update grammar, detector construction,
  explicit limitation statement, and `code/checker52.py`.
- Stationarity envelope: `report.tex`, `sections/stationarity_envelope.tex`,
  the scope/evidence sections, and `code/comparators/`.

## Relevant prior obstruction: progress alone is insufficient

The feedback archive contains an especially relevant appendix titled
“Why the tempting one-assumption binder reduction was rejected.” It examines
deleting the atomic zero base while keeping only progress introduction and
the old elimination. Its standard-natural-number interpretation reads an
atomic paired binder as an existentially witnessed progression. That model
separates the progression-only system from the intended conditional-closure
reading, using the formula `D x y (y=1)` with unused `x`.

This is **not** the ChoiceDI construction. ChoiceDI also retains case
introduction at equations. In the displayed counterexample its false zero
base supplies the successor equation by native explosion, so case DI proves
the paired formula. More generally, the unused-witness construction derives
the entire old two-assumption rule. The new archive therefore strengthens
the motivation for preserving the complementary case choice; it does not
invalidate the identity-language equivalence proof.

The exact-depth report also lists one-assumption progression among explored
but unsuccessful minimization directions. Neither text states the combined
case/progress rule and its unchanged-elimination proof simulation.

## Effect on the delivered report

The snapshot and archive count must be updated to the final 22-archive
commit while preserving the original audit and this addendum. The compact
comparison numbers, strict/runtime distinction, matched-control figures,
and ChoiceDI equivalence claim need no correction as a consequence of the
five additions. The feedback obstruction is appropriate additional
attribution; it is not evidence of an absolute novelty or minimality theorem.

The separate audit of `sections/results.tex`, `sections/evidence.tex`, and
`sections/ordinary_bridge.tex` found their source measurements and scope
qualifications consistent with the actual receipts. The ordinary bridge
includes actual equality, the explicit falsity bridge, full-domain numerical
composites, and the paired-formula composite. No substantive mathematical
correction beyond the snapshot update was identified in that review.
