# Independent current-draft audit

Snapshot: `VladimirReshetnikov/ProveIt`, commit `195e4becb0a1f99c5598f7e39e2cdeb81461b2e4` (17 current root ZIP archives). This is an assistant audit of source and selected written arguments, not a formal verification of all inherited arithmetic metatheory.

## Correct complete-source benchmark

I read the actual compact programs and their decoder/dispatch arguments, then independently ran the inherited unchanged `source_measure.metrics` normalizer under CPython 3.12.14 over every extracted `.py` source smaller than 8,000 raw bytes. Deduplication uses SHA-256. `small_source_inventory.json` records all results below 600 normalized tokens, including auxiliary scripts that are deliberately not counted as proof checkers. Only genuine docstrings and comments are excluded; imports, JSON input, rejection, verdicts, exit status, and all validation remain charged.

| Complete checker | Normalized tokens | AST nodes | Normalized bytes |
|---|---:|---:|---:|
| `recurrence_projections/code/native/indexed_major.py` | 305 | 345 | 860 |
| `clock_and_kernel/code/native/checker.py` | 306 | 340 | 859 |
| `progress_closure/code/kernel_variants/lambda_instance.py` | 307 | 347 | 839 |
| `clock_and_kernel/code/native/strict_checker.py` | 308 | 341 | 894 |
| `progress_closure/code/kernel_variants/local_s.py` | 308 | 346 | 869 |
| inherited `complete_kernel.py` | 309 | 344 | 864 |
| `recurrence_projections/code/native/padded_major.py` | 311 | 352 | 820 |

Here the shortened archive label expands to `reference/extracted/ipra_LABEL_2026-11-09/ipra_LABEL_2026-11-09/`.

**Current strict-array coordinate envelope: 305 / 341 / 820.** Including the explicitly qualified iterable-alias checker gives **305 / 340 / 820**. Different files attain different minima. No single supplied checker attains either tuple. Most included reports compare against the older commit `572c3ef...` and quote 306/340/839 or 307/341/839; those numbers are stale at current HEAD because `recurrence_projections` adds the 305-token and 820-byte sources.

The byte metric preserves identifier names. An already supplied uniform identifier-renaming control for `compact_open.py` is 816 bytes, retaining 317 tokens and 351 AST nodes. Literal-source byte records are therefore not naming-invariant claims. All these finite-corpus values are attainable implementation upper bounds, not universal mathematical lower bounds.

## Why the strict new sources are credible comparators

The compact checker is a genuine complete inherited native proof calculus, not a fragment certificate replayer. It imports only `json`; no encoded program, theorem oracle, producer, or external axiom file belongs to its acceptance path. Its public packet is a JSON array, with the last element the goal and earlier instruction cells consumed from the end. Unread prefixes are inert by design. The goal is validated before use. Its numerical/formula syntax shares arities 0 through 3 with scope offsets 0,2,1,4; formula constructors mean truth, conditional closure, equality, paired binder. Numerical constructors mean zero, successor, annotated zero, scalar iteration. Negative labels implement eigenparameters.

The native mathematical theory has unshifted initialized scalar iteration with passive ambient parameters, conditional closure Q, paired binder D, Hyp, DI, QE, DE, transport, and two iterator computation schemas. DI gets an induction hypothesis only when its matrix is literally an equation. Full intuitionistic logic and quantifier-free induction are reconstructed in the inherited proof. This grammar must not be conflated with the closed-unary-update arithmetic variants or the full-staged-PR readable kernels.

In `indexed_major.py`, a successfully checked active array major can have only length 1, 2, or 3. Trying `h = [0, [m[2]]]` creates exactly the old context at length 3; at lengths 1 or 2, indexing fails and invokes the unchanged closure/equality path. A truthy scalar cannot complete either old slicing/unpacking or new indexing/unpacking. Other malformed active kinds fail the unchanged strict traversal. This is a transparent finite dispatch equivalence argument.

In `padded_major.py`, a unary major `[B]` with payload `p` becomes triple `(0,p,B)`; a binary major `[s,u]` becomes `(s,u,p)`; a three-entry major gives four entries and fails exact triple unpacking, entering the unchanged paired branch. Its remaining acceptance path is unchanged. Both sources traverse only proper subtrees and have the usual sufficient-finite-resource completeness qualification.

I independently replayed all 147 supplied positive packets through both new sources versus the 309-token reference, comparing acceptance, final freshness floor, and remaining proof stack: **294 comparisons, zero failures**. Receipt: `baseline_independent_replay.json`. This checks implementation regression only; it is not a substitute for the metatheory.

The 306/340/859 source omits the list guard. It admits disclosed empty-string/object aliases, including an object with a sole empty key as a unary-tree alias. A nonempty string revisits one-character strings and rejects through CPython's recursion guard; idealized unbounded-stack execution need not terminate. It has successful-trace soundness and canonical-input completeness, not strict all-input packet equivalence. Keep this operational qualification visible.

## Mathematical changes already present

### Local, left, and forward-left rewriting

`local_rewriting/sections/02_theory.tex` uses full staged PR descriptions and native equations/D formulas, with reusable local clauses `A -> forall y B(y)`. Its primitive patterns are computation, clause Use, DI, DE, and a one-occurrence rewrite with neutral source (computation or direct atomic clause use), either orientation, either equation side. Two-stage normalization gives the unrestricted native consequence relation. Its complete readable checker is 3287/3650/16192.

`left_rewriting/02_rewriting.tex` observes that an arbitrary proved equation E can be re-exposed as a permitted clause source using the vacuous theorem D E and DE, introducing the clause E -> E. The clause's antecedent may have an arbitrary proof; this fact is essential. It then removes provenance checking and derives deep congruence using only root or immediate-argument rewriting on the left. Its shallow checker is **3160/3501/15674**, smaller than forward_left's later 3218-token checker. An exact old-to-shallow proof-node formula is supplied: |T Pi| = |Pi| + 4V + 8W + 8P, with P summing max(0, depth-1).

`forward_left/report.tex` independently uses vacuous paired closure to restrict full-motive transport to direct forward clause-source use. Translation adds exactly 5 nodes per source transport, hence N+5r <= 6N. A later lowering keeps only forward rewriting on the left of literal equations, one numerical occurrence at a time; it proves complete consequence equivalence. Its readable checker is 3218/3562/15789, a local saving against 3287/3650/16192 but no global record. This deliberate DI-DE detour is not cut-free normalization.

### Arithmetic and recurrence presentations

`one_fixed_recurrence`: ordinary intuitionistic FOL/equality + all PR equations + coverage + separation + one fixed signed-update uniqueness rule suffices. Retraction is derived. This is already available and must not be presented as novel.

`recurrence_boundary`: for a fixed update h with right inverse j, uniqueness gives R_0(a)=a and R_{Sn}(a)=R_n(a), with R_t(a)=L(t,A(t,a)). Full stationarity is equivalent to R_t=id, which is not established for the bouncing predecessor W0=1, W(Sa)=a.

`recurrence_projections/sections/recurrence_projections.tex`: proves L_t F R_t = L_t F and R_t F R_t = R_t F for every fixed term context F, so R_t is idempotent and ker R_t is a congruence. In a classical model ker R_t is the largest congruence contained in ker L_t. Finite compositions form a left regular band, with kernel join behavior. These are substantive already-present theorems. The image preserves defining equations, but uniqueness is not shown to descend; no full first-order bi-interpretability or stationarity completion follows.

`pulse_calibration`: already shrinks the fixed closed-iteration Boolean comparator from 182 expanded nodes to 70 using a transient equality pulse; both arguments occur once. Its matched complete ordinary checkers shrink 3247/3327/8874 -> 2743/2963/7950. This is not close to the compact native frontier.

`progress_closure`: one local assumption per DI is already achieved via atomic progression and compound closure, but a compensating local progression-elimination rule is required. Readable complete checker 2380/2640/9682; the 307-token source is a separate refactor of the old native calculus.

`clock_and_kernel`: shorter derived predecessor clock, 22 declarations/130 body nodes -> 16/93, while the primitive arithmetic basis stays unchanged. Its compact 306-token and strict 308-token refinements are separate.

`boolean_bootstrap`, `two_diagonal`, `raw_reset`, and reconstructed reset remove guards/axioms and calibrate equality in different closed/full-PR presentations; these must not be confused with a smaller logical kernel. `unbounded_depth` proves unbounded iPRA-provable-equivalence depth for native formulas, which is not a source-size lower bound.

## Known failed shortcuts relevant to a new proposal

1. Removing initial goal traversal is unsound; the corpus supplies a three-instruction certificate for 0=S0.
2. Giving DI an induction hypothesis for every matrix yields induction for arbitrary translated formulas (HA-strength behavior), not merely iPRA.
3. Per-standard-counter or per-standard-seed rotation does not prove a uniform law at all elements of nonstandard models.
4. A numerical quotient preserving defining equations need not preserve contextual recurrence uniqueness, nor give whole-domain interpretation composites.
5. Moving all computation axioms into rewrite sources still requires an equality-producing leaf such as reflexivity.
6. Restricting every paired-elimination major to neutral hypotheses removes the introduction/elimination combination implementing induction.

## Assessment

The correct immediate challenge is to simplify the compact native rule/scope mechanism itself while preserving its full intuitionistic formula translation and both internally provable composites. Merely shrinking one ordinary-arithmetic schema, a PR compiler term, or a scoped proof replayer cannot meet the currently measured frontier. I found no new defect invalidating the strict indexed/padded source comparisons. The inherited long arithmetic interpretation proof remains an assumption of this implementation audit rather than an independently formalized theorem.
