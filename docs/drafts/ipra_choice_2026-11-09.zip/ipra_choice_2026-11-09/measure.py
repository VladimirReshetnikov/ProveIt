"""Reproduce whole-module metrics using the unchanged inherited normalizer.

This supporting audit program is not imported by any proof checker.
"""
import csv
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")
EXPECTED = {
    "comparison/indexed_305.py": (305, 345, 860),
    "comparison/strict_341.py": (308, 341, 894),
    "comparison/padded_820.py": (311, 352, 820),
    "comparison/iterable_340.py": (306, 340, 859),
    "comparison/lambda_839.py": (307, 347, 839),
    "comparison/padded_matched_control.py": (313, 357, 820),
    "code/native/tokens.py": (299, 345, 880),
    "code/native/structure.py": (304, 340, 902),
    "code/native/bytes.py": (307, 353, 815),
}


def main():
    spec = importlib.util.spec_from_file_location(
        "frozen_source_measure", ROOT / "comparison/source_measure.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    comparators = json.loads((ROOT / "evidence/comparators.json").read_text())
    for entry in comparators:
        actual = module.metrics(ROOT / entry["local"])["sha256"]
        if actual != entry["sha256"]:
            raise ValueError("Changed inherited file: " + entry["local"])
    rows = []
    for name, expected in EXPECTED.items():
        measured = module.metrics(ROOT / name)
        actual = tuple(measured[k] for k in FIELDS)
        if actual != expected:
            raise ValueError((name, actual, expected, platform.python_version()))
        rows.append({"file": name, **measured})
    for name in ("code/readable/checker.py", "code/readable/matched_baseline.py"):
        if (ROOT / name).exists():
            rows.append({"file": name, **module.metrics(ROOT / name)})
    result = {
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "snapshot_commit": "08edc6964d8990d2230179a9d65355ac1eee7a9e",
        "archive_count": 22,
        "measurement_boundary": "Entire standalone module; comments and docstrings excluded by the inherited normalizer.",
        "strict_old_coordinate_envelope": dict(zip(FIELDS, (305, 341, 820))),
        "runtime_inclusive_old_coordinate_envelope": dict(zip(FIELDS, (305, 340, 820))),
        "new_coordinate_envelope": dict(zip(FIELDS, (299, 340, 815))),
        "single_program_attains_envelope": False,
        "programs": rows,
        "all_expected_compact_metrics_match": True,
    }
    destination = ROOT / "evidence"
    (destination / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    with (destination / "metrics.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream,
            fieldnames=("file", "source_tokens", *FIELDS, "raw_bytes", "sha256"),
            extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({k: v for k, v in result.items() if k != "programs"}, indent=2))


if __name__ == "__main__":
    main()
