"""Build the manuscript and expand a standalone TeX source, without network."""
import os
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUT = re.compile(r"\\input\{([^}]+)\}")


def expand(path, active=()):
    path = path.resolve()
    if path in active or not path.is_relative_to(ROOT):
        raise ValueError("Invalid TeX input: " + str(path))
    def insert(match):
        member = ROOT / match.group(1)
        if not member.suffix:
            member = member.with_suffix(".tex")
        return "\n% BEGIN " + match.group(1) + "\n" + expand(member, active + (path,)) + "\n% END " + match.group(1) + "\n"
    return INPUT.sub(insert, path.read_text())


def main():
    (ROOT / "report_standalone.tex").write_text(expand(ROOT / "report.tex"))
    if not shutil.which("pdflatex"):
        raise SystemExit("pdflatex is required to rebuild the PDF; the standalone TeX was generated.")
    env = dict(os.environ)
    env.update(SOURCE_DATE_EPOCH="1794268800", FORCE_SOURCE_DATE="1", TZ="UTC")
    build = ROOT / ".build"
    build.mkdir(exist_ok=True)
    for suffix in ("aux", "out", "toc"):
        (build / ("report." + suffix)).unlink(missing_ok=True)
    command = ["pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
               "-halt-on-error", "-output-directory", str(build), "report.tex"]
    for _ in range(3):
        run = subprocess.run(command, cwd=ROOT, env=env, text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if run.returncode:
            print(run.stdout[-14000:])
            raise SystemExit(run.returncode)
    log = (build / "report.log").read_text(errors="replace")
    unresolved = [line for line in log.splitlines()
                  if "undefined" in line.lower() or "multiply defined" in line.lower()]
    if unresolved:
        raise RuntimeError("Unresolved TeX references: " + "\n".join(unresolved))
    shutil.copy2(build / "report.pdf", ROOT / "report.pdf")
    warnings = [line for line in log.splitlines()
                if "Overfull" in line or "Warning" in line]
    print("Built report.pdf and report_standalone.tex")
    if warnings:
        print("\n".join(warnings))


if __name__ == "__main__":
    main()
