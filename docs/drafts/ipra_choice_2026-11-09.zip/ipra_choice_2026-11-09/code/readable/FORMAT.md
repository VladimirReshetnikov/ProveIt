# Complete readable ChoiceDI checker

**Each introduction retains exactly one local assumption.** A certificate
explicitly chooses the zero base ("case") or the induction hypothesis ("ind").
The induction choice is permitted only for a literal equation matrix. There is
no computation-base requirement and no restricted formula grammar.

The complete standalone checker includes the full primitive-recursive
numerical signature, equations and paired formulas, computation, retained
clause use, paired introduction/elimination, and unrestricted equality
transport. The comparison baseline retains the original base-plus-IH rule.
The two numerical languages, formula languages and retained contexts coincide.

The mathematical proof is in the report. It recovers every old atomic
introduction by an outer case introduction, an inner induction introduction
with an unused witness coordinate, and elimination. The original premise
appears once. The included general untrusted compiler implements that
construction and outputs independently checked proof trees.

## Reproduction

Use Python 3.9 or later; no third-party package is required.

Run these commands from this directory:

```sh
python3 producer.py
python3 checker.py < fixtures/choice/progress_induction.json
python3 -O checker.py < fixtures/choice/progress_noncomputation_base.json
python3 matched_baseline.py < fixtures/baseline/both_assumptions_nested.json
python3 compiler.py --receipt compiler_example_receipt.json \
  < fixtures/baseline/both_assumptions_nested.json > compiled_example.json
python3 checker.py < compiled_example.json
python3 run_tests.py
```

Each checker writes exactly ACCEPT with exit status 0, or REJECT with exit
status 1. It imports only Python's json module. No assert controls acceptance.

The test harness copies each complete checker into an otherwise empty
temporary directory and runs its public CLI normally and under -O. It writes
validation.json, compiler_receipts.json, and explicit fixtures. The producer,
compiler and tests are outside the acceptance boundary.

## Numerical syntax and primitive recursion

Terms are arrays. A variable is ["$", "x"], zero is ["0"], successor is
["S", term], and an application is [function_name, argument, ...]. The built-in
unary projection is id.

A public packet has exactly declarations, goal and proof. Descriptions are
fixed finite syntax; numerical variables do not range over descriptions.
A description may reference only an earlier function. The supported forms
are:

```json
{"name":"p","kind":"proj","arity":2,"index":0}
{"name":"f","kind":"comp","arity":1,"outer":"S","inners":["id"]}
{"name":"r","kind":"rec","arity":1,"base":"0","step":"p"}
```

Projection indices start at zero. For composition of arity k, every inner
function has arity k and their number equals the outer function's arity.
For recursion of arity k+1, the first argument is the counter, the base has
arity k, and the step has arity k+2. Step arguments are predecessor, previous
recursive value, then fixed parameters.

The computation axioms are exactly one defining projection, composition,
recursion-at-zero, or recursion-at-successor equation. They are oriented
from application to defining expansion. Multi-step evaluation is not a
single computation certificate. Reflexivity is derived using computation
and transport, not accepted as an extra primitive computation schema.

Function and variable names must be Python identifiers. Arities, projection
indices and clause indices must be actual integers, excluding JSON booleans.
The checker rejects incorrect fields, unknown symbols, incorrect arities,
forward references, duplicate JSON keys and nonfinite JSON numeric constants.

## Formulas, scopes and retained clauses

An equation is ["=", left_term, right_term]. A paired formula is
["D", "x", "y", body], with distinct bound variables x and y. The body may
be any native formula, including an arbitrary nested paired formula.

Public packet goals are closed and use an empty retained context.
The internal Checker.check API additionally accepts, and validates, an
explicit scope and retained context. A retained clause is
[antecedent, binder, body], representing antecedent implies all instances
of body. Its binder must not occur freely in its antecedent.

An ordinary assumption F is represented by the constant clause from the fixed
computation theorem id(0)=0 to F. Using this assumption therefore has two proof
nodes: the computation and clause use.

Substitution is simultaneous and avoids variable capture. Inserted terms are
not recursively substituted again. Formulas are compared up to bound-variable
renaming. All numerical free variables must belong to the current scope.
Eigenvariables and transport placeholders satisfy their scope freshness
conditions.

## Proof-node interface

Every node has rule and conclusion, plus exactly the fields below:

| Rule | Other fields | Condition |
|---|---|---|
| comp | none | One literal defining computation equation. |
| use | clause, term, premise | Prove the indexed antecedent and instantiate its consequent. |
| di | witness, eigen, mode, premise | Introduce a paired formula under its one chosen ordinary assumption. |
| de | major, eigen, premise | Open a paired major as a fresh-witness retained clause and discharge that clause. |
| tr | equality, before, variable, motive | From s=t and F(s), obtain F(t) for any native formula template F. |

For a DI conclusion D x y B, witness t, and fresh eigenvariable z, its premise
must prove B(t,Sz):

- mode "case" retains only B(t,0), for every matrix B;
- mode "ind" retains only B(t,z), and requires B itself to have an equation
  root.

An equation underneath a paired binder is not an equation root. An induction
choice at such a compound matrix is rejected. Unknown, absent or non-string
modes are rejected.

The baseline DI has no mode field. It retains B(t,0) and, when B is an
equation, also B(t,z). The different public certificate interfaces are
intentional. Equivalence concerns the native consequence relation, not
identical JSON packet acceptance.

## General baseline-to-choice compiler

compiler.py transforms an arbitrary valid old proof tree. It does not
validate the input and must not be treated as an acceptance oracle. Its output
is independently checked by checker.py.

For an old atomic introduction with premise

  Gamma, E(t,0), E(t,z) proves E(t,Sz),

the compiler constructs an outer case introduction. Within its retained
E(t,0), it introduces D u y E(t,y) by induction mode, with u fresh and unused.
Its premise is the old premise with z renamed to a fresh inner eigenvariable.
Elimination opens precisely the clause E(t,0) implies all E(t,y), because
u is unused. A use of the retained base supplies its antecedent; specializing
at Sz gives the outer successor premise.

The fixed witness term t remains a parameter of the inner matrix. Rebinding
its original witness coordinate would be incorrect: elimination would then
provide an arbitrary witness instead of the original t.

Each transformed old premise sees the same ordered context slots:
Gamma, base, IH. Thus its clause indices remain unchanged. Fresh names are
chosen outside the entire input, including retained data in the scoped API.
The compiler handles full transport motives, nested DI/DE and capture-avoiding
substitution.

If the old proof has N inference nodes and r atomic DI nodes, the output has
exactly N+5r nodes. Computation and Use are counted separately, including
ordinary-hypothesis use. This is a bound on inference-tree nodes, not
serialized bytes, formula sizes or runtime.

## Validation results

The archived run records **169 passing checks and zero failures**:

| Group | Recorded checks |
|---|---:|
| Positive CLI runs, ordinary and -O | 64 |
| Rejection controls, ordinary and -O | 84 |
| Wrong certificate-interface rejections | 4 |
| Before/after numerical-substitution contracts | 4 |
| Compiler preservation and exact-count receipts | 13 |

There are 10 direct ChoiceDI closed packets, 11 baseline packets, and 11
compiled ChoiceDI packets. All 32 pass their corresponding public checker
both normally and with optimization enabled.

The positive cases cover all numerical computation forms; actual induction
hypothesis use; a progress introduction whose base is not a computation
axiom; explicit zero-base use; compound introduction/elimination;
capture-avoiding transport across a deliberately conflicting binder; and
derived reflexivity.

The extra baseline source both_assumptions_nested explicitly consumes both
the old base and the old IH and contains another atomic introduction inside
its premise. It has N=24 and r=2. The compiled certificate checks at 34 nodes,
exactly N+5r. Another compiler case uses the witness S0, verifying that the
inner unused-witness construction preserves a nonzero original witness.

The 13 compiler receipts comprise all 11 closed baseline packets and two
scoped derivations. Closed receipts compare the compiler's counts with the
independent checker counters, and verify that the goal and numerical
declarations are unchanged.

Negative controls reject malformed declarations, scopes, JSON and transport;
forged or multistep computations; unknown or missing DI choices; induction
at a compound matrix; and attempts to retag a base-dependent certificate as
induction or an IH-dependent certificate as case mode.

### Substitution requires no branch repair

The scoped fixtures use

  B(a,y) := C(a,y,0) = first2(y,0).

Before substituting a:=0, the zero instance is not a single computation;
after substitution it is. Both derivations nevertheless use the same
explicit case choice, retain the same base slot and are accepted unchanged
in structure. Formula roots and certificate choices are stable under
numerical substitution. The former computation-selected proposal required
a special guard-flip repair; ChoiceDI has no such guard.

## Measurements and scope of the size claim

metrics.json uses the repository's whole-source normalization. The readable
ChoiceDI file has 2,912 normalized tokens, 3,201 AST nodes and 14,125 normalized
bytes. Its unchanged matched baseline has 2,881 tokens, 3,160 AST nodes and
13,926 bytes.

This readable checker intentionally spells out mode names and validation
errors; it is larger than its readable baseline. The compact verified kernels
elsewhere in the deliverable carry the source-size comparison. These files
are supplied for inspection, explicit certificate examples and the general
proof compiler, not as a smallest-source claim.

The calculus equivalence is proved mathematically in the report. These finite
checks do not prove universal metatheorems or the full iPRA interpretation by
themselves. No proof-assistant verification is claimed.

The checker operates within Python's finite runtime resources. Malformed
input, resource exhaustion or another raised exception results in rejection.
The provenance and inherited license are recorded in ATTRIBUTION.txt and
LICENSE-inherited.txt.

