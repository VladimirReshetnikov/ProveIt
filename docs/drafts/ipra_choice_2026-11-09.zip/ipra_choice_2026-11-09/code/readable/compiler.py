"""Untrusted, general old-DI to ChoiceDI proof-tree compiler.

The input must be a valid baseline proof. This module does not import a
checker. Its output is independently checked by checker.py. It preserves
the goal and declarations, inserts the old premise once, and has exactly
N + 5*r inference nodes, where r counts old atomic DI nodes.
"""

import argparse
import copy
import json
import sys

import producer as P


def strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, (list, tuple)):
        for child in value:
            yield from strings(child)
    elif isinstance(value, dict):
        for key, child in value.items():
            yield key
            yield from strings(child)


def renamed(proof, old, new):
    """Rename a free eigenparameter, respecting formula and rule binders."""
    result = copy.deepcopy(proof)
    mapping = {old: P.v(new)}
    result["conclusion"] = P.substitute(proof["conclusion"], mapping)
    rule = proof["rule"]
    if rule == "use":
        result["term"] = P.substitute_term(proof["term"], mapping)
        result["premise"] = renamed(proof["premise"], old, new)
    elif rule == "di":
        result["witness"] = P.substitute_term(proof["witness"], mapping)
        if proof["eigen"] != old:
            result["premise"] = renamed(proof["premise"], old, new)
    elif rule == "de":
        result["major"] = renamed(proof["major"], old, new)
        if proof["eigen"] != old:
            result["premise"] = renamed(proof["premise"], old, new)
    elif rule == "tr":
        result["equality"] = renamed(proof["equality"], old, new)
        result["before"] = renamed(proof["before"], old, new)
        if proof["variable"] != old:
            result["motive"] = P.substitute(proof["motive"], mapping)
    elif rule != "comp":
        raise ValueError("Unknown baseline inference rule")
    return result


def counts(proof):
    nodes = 1
    atomic_di = int(proof["rule"] == "di" and proof["conclusion"][3][0] == "=")
    for key in ("premise", "major", "equality", "before"):
        if key in proof:
            child_nodes, child_atomic = counts(proof[key])
            nodes += child_nodes
            atomic_di += child_atomic
    return nodes, atomic_di


class Compiler:
    def __init__(self, all_retained_data):
        self.occupied = set(strings(all_retained_data))
        self.counter = 0

    def fresh(self):
        while True:
            candidate = "_compile" + str(self.counter)
            self.counter += 1
            if candidate not in self.occupied:
                self.occupied.add(candidate)
                return candidate

    def proof(self, old, context_size=0):
        result = copy.deepcopy(old)
        rule = old["rule"]
        if rule == "comp":
            return result
        if rule == "use":
            result["premise"] = self.proof(old["premise"], context_size)
            return result
        if rule == "tr":
            result["equality"] = self.proof(old["equality"], context_size)
            result["before"] = self.proof(old["before"], context_size)
            return result
        if rule == "de":
            result["major"] = self.proof(old["major"], context_size)
            result["premise"] = self.proof(old["premise"], context_size + 1)
            return result
        if rule != "di":
            raise ValueError("Unknown baseline inference rule")
        x, y, body = old["conclusion"][1:]
        result["mode"] = "case"
        if body[0] != "=":
            result["premise"] = self.proof(old["premise"], context_size + 1)
            return result

        # Original context: Gamma, base, IH. New outer case DI contributes
        # the same base slot; inner progress DI contributes the same IH slot.
        # Consequently every original clause index can remain unchanged.
        witness = old["witness"]
        outer_eigen = old["eigen"]
        unused_witness, inner_counter, inner_eigen, opened_eigen = [self.fresh() for _ in range(4)]
        fixed_matrix = P.substitute(body, {x: witness, y: P.v(inner_counter)})
        inner_goal = P.paired(unused_witness, inner_counter, fixed_matrix)
        inner_premise = self.proof(renamed(old["premise"], outer_eigen, inner_eigen),
                                  context_size + 2)
        inner = P.introduction(inner_goal, P.ZERO, inner_eigen, inner_premise, "ind")
        base = P.substitute(body, {x: witness, y: P.ZERO})
        target = P.substitute(body, {x: witness, y: P.s(P.v(outer_eigen))})
        specialized = {"rule": "use", "conclusion": target,
                       "clause": context_size + 1, "term": P.s(P.v(outer_eigen)),
                       "premise": P.hypothesis(base, context_size)}
        result["premise"] = {"rule": "de", "conclusion": target, "major": inner,
                             "eigen": opened_eigen, "premise": specialized}
        return result


def compile_packet(packet):
    result = copy.deepcopy(packet)
    result["proof"] = Compiler(packet).proof(packet["proof"])
    return result


def compile_scoped(fixture):
    result = copy.deepcopy(fixture)
    result["proof"] = Compiler(fixture).proof(fixture["proof"], len(fixture["context"]))
    return result


def receipt(before, after):
    old_nodes, atomic = counts(before)
    new_nodes, _ = counts(after)
    return {"old_nodes": old_nodes, "old_atomic_di": atomic, "new_nodes": new_nodes,
            "predicted_nodes": old_nodes + 5 * atomic,
            "exact_node_bound": new_nodes == old_nodes + 5 * atomic}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--receipt", help="Optional JSON node-count receipt path")
    arguments = parser.parse_args()
    before = json.load(sys.stdin)
    after = compile_packet(before)
    if arguments.receipt:
        with open(arguments.receipt, "w", encoding="utf-8") as stream:
            json.dump(receipt(before["proof"], after["proof"]), stream, indent=2, sort_keys=True)
            stream.write("\n")
    json.dump(after, sys.stdout, indent=2, sort_keys=True)
    sys.stdout.write("\n")
