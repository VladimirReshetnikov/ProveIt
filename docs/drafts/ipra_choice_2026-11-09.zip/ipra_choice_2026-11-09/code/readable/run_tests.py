"""Focused independent certificates, rejection controls, and compiler receipts.

The public acceptance boundary is each complete copied checker process. The
producer, compiler, fixtures and this harness are untrusted. Ordinary and -O
Python runs are both exercised in an otherwise empty temporary directory.
"""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

import compiler
import producer


ROOT = Path(__file__).resolve().parent


def load_checker(path, label):
    specification = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def changed(packet, change):
    result = copy.deepcopy(packet)
    change(result)
    return result


def rejection_controls(positive, choice):
    zero = positive["recursion_zero"]
    base = positive["noncomputation_base"]
    compound = positive["compound_di_de"]
    capture = positive["capture_avoiding_transport"]
    negatives = {}

    def add(label, source, mutation):
        negatives[label] = json.dumps(changed(source, mutation))

    def wrong_computation(packet):
        packet["goal"][2] = producer.numeral(1)
        packet["proof"]["conclusion"][2] = producer.numeral(1)

    add("forged_computation", zero, wrong_computation)
    add("boolean_arity", zero, lambda p: p["declarations"][0].update(arity=True))
    add("out_of_range_projection", zero, lambda p: p["declarations"][0].update(index=2))
    add("forward_reference", zero, lambda p: p["declarations"][3].update(step="missing"))
    add("duplicate_function", zero, lambda p: p["declarations"].append(copy.deepcopy(p["declarations"][0])))
    add("extra_packet_field", zero, lambda p: p.update(context=[]))
    add("extra_proof_field", zero, lambda p: p["proof"].update(oracle=True))
    add("unknown_rule", zero, lambda p: p["proof"].update(rule="rw"))
    add("free_witness", base, lambda p: p["proof"].update(witness=producer.v("free")))
    add("compound_fake_IH", compound, lambda p: p["proof"]["major"]["premise"].update(clause=1))
    add("reused_eigenvariable", capture,
        lambda p: p["proof"]["premise"]["before"].update(eigen="z"))
    add("nonfresh_transport_hole", capture,
        lambda p: p["proof"]["premise"].update(variable="z"))

    def captured_result(packet):
        packet["proof"]["premise"]["conclusion"] = producer.paired(
            "z", "b", producer.equation(producer.s(producer.v("z")), producer.v("z")))

    add("captured_transport_result", capture, captured_result)
    multistep = producer.computation(["R", producer.numeral(1)], producer.ZERO)
    negatives["multistep_is_not_comp"] = json.dumps(producer.packet(multistep))
    reflexive = producer.computation(producer.ZERO, producer.ZERO)
    negatives["reflexivity_is_not_comp"] = json.dumps(producer.packet(reflexive))
    unbound = producer.computation(["id", producer.v("free")], producer.v("free"))
    negatives["free_numerical_variable"] = json.dumps(producer.packet(unbound))
    raw = json.dumps(zero)
    negatives["duplicate_json_key"] = raw[:-1] + ', "goal": ' + json.dumps(zero["goal"]) + '}'
    negatives["nonfinite_json_number"] = raw.replace('"arity": 2', '"arity": NaN', 1)
    if choice:
        add("unknown_di_mode", base, lambda p: p["proof"].update(mode="both"))
        add("boolean_di_mode", base, lambda p: p["proof"].update(mode=True))
        add("missing_di_mode", base, lambda p: p["proof"].pop("mode"))
        add("compound_ind_mode", compound, lambda p: p["proof"]["major"].update(mode="ind"))
        add("ind_proof_retagged_case", positive["progress_induction"],
            lambda p: p["proof"]["major"].update(mode="case"))
        add("case_proof_retagged_ind", base, lambda p: p["proof"].update(mode="ind"))
    return negatives


def main():
    manifest = producer.generate(ROOT / "fixtures")
    groups = ("positive", "negative", "cross_interface", "substitution_contract", "compiler_receipts")
    results = {key: [] for key in groups}
    results.update(python=sys.version, standalone=True, source_sha256={})
    modes = {"choice": "checker.py", "baseline": "matched_baseline.py"}
    packets = {mode: {Path(path).stem: json.loads((ROOT / "fixtures" / path).read_text())
                      for path in manifest["positive"][mode]} for mode in modes}
    packets["compiled"] = {}
    manifest["positive"]["compiled"] = []
    for label, original in packets["baseline"].items():
        translated = compiler.compile_packet(original)
        path = Path("compiled") / (label + ".json")
        producer.write_json(ROOT / "fixtures" / path, translated)
        packets["compiled"][label] = translated
        manifest["positive"]["compiled"].append(str(path))
    producer.write_json(ROOT / "fixtures" / "manifest.json", manifest)

    def record(target, item, condition):
        item["passed"] = bool(condition)
        results[target].append(item)
        if not condition:
            raise RuntimeError("Unexpected test result: " + json.dumps(item))

    with tempfile.TemporaryDirectory(prefix="ipra-choice-checkers-") as isolated:
        isolated = Path(isolated)
        for filename in modes.values():
            shutil.copyfile(ROOT / filename, isolated / filename)
            results["source_sha256"][filename] = hashlib.sha256((ROOT / filename).read_bytes()).hexdigest()

        def run(mode, optimized, raw):
            command = [sys.executable]
            if optimized:
                command.append("-O")
            command.append(str(isolated / modes[mode]))
            response = subprocess.run(command, input=raw, text=True, capture_output=True,
                                      cwd=isolated, timeout=10, check=False)
            return response.returncode, response.stdout.strip(), response.stderr.strip()

        for group in ("choice", "baseline", "compiled"):
            mode = "choice" if group == "compiled" else group
            for optimized in (False, True):
                for label, packet in packets[group].items():
                    result = run(mode, optimized, json.dumps(packet))
                    record("positive", {"checker": mode, "certificate_group": group,
                                        "optimized": optimized, "case": label, "result": list(result)},
                           result == (0, "ACCEPT", ""))
        for mode in modes:
            negative = rejection_controls(packets[mode], choice=mode == "choice")
            for label, raw in negative.items():
                path = ROOT / "fixtures" / "negative" / mode / (label + ".json")
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(raw + "\n", encoding="utf-8")
            for optimized in (False, True):
                for label, raw in negative.items():
                    result = run(mode, optimized, raw)
                    record("negative", {"checker": mode, "optimized": optimized,
                                        "case": label, "result": list(result)},
                           result == (1, "REJECT", ""))
                opposite = "baseline" if mode == "choice" else "choice"
                result = run(mode, optimized, json.dumps(packets[opposite]["progress_induction"]))
                record("cross_interface", {"checker": mode, "optimized": optimized,
                                            "certificate_interface": opposite, "result": list(result)},
                       result == (1, "REJECT", ""))

        modules = {mode: load_checker(isolated / filename, "standalone_" + mode)
                   for mode, filename in modes.items()}
        for mode, module in modules.items():
            for label, path in manifest["scoped_substitution"][mode].items():
                fixture = json.loads((ROOT / "fixtures" / path).read_text())
                module.Checker(fixture["declarations"]).check(
                    fixture["proof"], context=fixture["context"], scope=set(fixture["scope"]),
                    expected=fixture["goal"])
                record("substitution_contract", {"checker": mode, "case": label,
                                                  "accepted": True}, True)

        for label, before in packets["baseline"].items():
            after = packets["compiled"][label]
            old_stats = modules["baseline"].check_packet(before)
            new_stats = modules["choice"].check_packet(after)
            receipt = compiler.receipt(before["proof"], after["proof"])
            receipt.update(case=label, checked_old_nodes=old_stats["proof_nodes"],
                           checked_new_nodes=new_stats["proof_nodes"],
                           goal_preserved=before["goal"] == after["goal"],
                           declarations_preserved=before["declarations"] == after["declarations"])
            record("compiler_receipts", receipt,
                   receipt["exact_node_bound"] and receipt["goal_preserved"]
                   and receipt["declarations_preserved"]
                   and receipt["old_nodes"] == receipt["checked_old_nodes"]
                   and receipt["new_nodes"] == receipt["checked_new_nodes"])

        for label, path in manifest["scoped_substitution"]["baseline"].items():
            original = json.loads((ROOT / "fixtures" / path).read_text())
            translated = compiler.compile_scoped(original)
            producer.write_json(ROOT / "fixtures" / "scoped" / "compiled" / (label + ".json"), translated)
            modules["choice"].Checker(translated["declarations"]).check(
                translated["proof"], context=translated["context"], scope=set(translated["scope"]),
                expected=translated["goal"])
            receipt = compiler.receipt(original["proof"], translated["proof"])
            record("compiler_receipts", {"case": "scoped_" + label, **receipt},
                   receipt["exact_node_bound"])

    results["summary"] = {key: len(results[key]) for key in groups}
    results["summary"]["failures"] = sum(not item["passed"] for key in groups for item in results[key])
    producer.write_json(ROOT / "validation.json", results)
    producer.write_json(ROOT / "compiler_receipts.json", results["compiler_receipts"])
    print(json.dumps(results["summary"], sort_keys=True))


if __name__ == "__main__":
    main()

