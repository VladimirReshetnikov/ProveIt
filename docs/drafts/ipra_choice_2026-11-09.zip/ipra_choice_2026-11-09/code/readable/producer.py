"""Untrusted, independently written examples for complementary DI and its baseline.

This file imports neither checker. It constructs explicit finite proof trees;
the checkers do not import it. Run it to reproduce fixtures/ and manifest.json.
"""

import argparse
import copy
import json
from pathlib import Path


ZERO = ["0"]


def v(identifier):
    return ["$", identifier]


def s(term):
    return ["S", copy.deepcopy(term)]


def equation(left, right):
    return ["=", copy.deepcopy(left), copy.deepcopy(right)]


def paired(x, y, body):
    return ["D", x, y, copy.deepcopy(body)]


def numeral(number):
    term = ZERO
    for _ in range(number):
        term = s(term)
    return term


def variables(term):
    if term[0] == "$":
        return {term[1]}
    result = set()
    for child in term[1:]:
        result |= variables(child)
    return result


def names(formula):
    if formula[0] == "=":
        return variables(formula[1]) | variables(formula[2])
    return {formula[1], formula[2]} | names(formula[3])


def substitute_term(term, mapping):
    if term[0] == "$":
        return copy.deepcopy(mapping.get(term[1], term))
    return [term[0], *(substitute_term(child, mapping) for child in term[1:])]


def substitute(formula, mapping):
    """Producer-side capture avoidance, independently of trusted checking."""
    if formula[0] == "=":
        return equation(substitute_term(formula[1], mapping),
                        substitute_term(formula[2], mapping))
    binders = list(formula[1:3])
    active = {key: term for key, term in mapping.items() if key not in binders}
    images = set()
    for term in active.values():
        images |= variables(term)
    body = copy.deepcopy(formula[3])
    occupied = names(formula) | images | set(active)
    for position, old in enumerate(binders):
        if old in images:
            counter = 0
            while "_free" + str(counter) in occupied:
                counter += 1
            new = "_free" + str(counter)
            occupied.add(new)
            body = substitute(body, {old: v(new)})
            binders[position] = new
    return paired(*binders, substitute(body, active))


DECLARATIONS = [
    {"name": "last2", "kind": "proj", "arity": 2, "index": 1},
    {"name": "first2", "kind": "proj", "arity": 2, "index": 0},
    {"name": "last4", "kind": "proj", "arity": 4, "index": 3},
    {"name": "R", "kind": "rec", "arity": 1, "base": "0", "step": "last2"},
    {"name": "C", "kind": "rec", "arity": 3, "base": "first2", "step": "last4"},
    {"name": "constant_zero", "kind": "comp", "arity": 1, "outer": "0", "inners": []},
]


def computation(left, right):
    return {"rule": "comp", "conclusion": equation(left, right)}


def hypothesis(formula, index):
    return {"rule": "use", "conclusion": copy.deepcopy(formula),
            "clause": index, "term": copy.deepcopy(ZERO),
            "premise": computation(["id", ZERO], ZERO)}


def introduction(conclusion, witness, eigen, premise, mode=None):
    result = {"rule": "di", "conclusion": copy.deepcopy(conclusion),
              "witness": copy.deepcopy(witness), "eigen": eigen, "premise": premise}
    if mode is not None:
        result["mode"] = mode
    return result


def packet(proof):
    return {"declarations": copy.deepcopy(DECLARATIONS),
            "goal": copy.deepcopy(proof["conclusion"]), "proof": proof}


class Builder:
    def __init__(self, baseline=False):
        self.baseline = baseline
        self.fresh = 0

    def di(self, conclusion, witness, eigen, premise, mode="case"):
        return introduction(conclusion, witness, eigen, premise,
                            None if self.baseline else mode)

    def transport(self, equality, before, motive_builder):
        placeholder = "_transport" + str(self.fresh)
        self.fresh += 1
        motive = motive_builder(v(placeholder))
        return {"rule": "tr",
                "conclusion": substitute(motive, {placeholder: equality["conclusion"][2]}),
                "equality": equality, "before": before,
                "variable": placeholder, "motive": motive}

    def reflexivity(self, term):
        identity = computation(["id", term], term)
        return self.transport(identity, copy.deepcopy(identity),
                              lambda hole: equation(hole, term))

    def transitivity(self, first, second):
        left = first["conclusion"][1]
        return self.transport(second, first, lambda hole: equation(left, hole))

    def symmetry(self, equality):
        left = equality["conclusion"][1]
        return self.transport(equality, self.reflexivity(left),
                              lambda hole: equation(hole, left))

    def selector_zero(self, left, right):
        expanded = ["first2", left, right]
        return self.transitivity(computation(["C", ZERO, left, right], expanded),
                                 computation(expanded, left))

    def selector_successor(self, predecessor, left, right):
        expanded = ["last4", predecessor, ["C", predecessor, left, right], left, right]
        return self.transitivity(computation(["C", s(predecessor), left, right], expanded),
                                 computation(expanded, right))

    def guarded_induction(self, tag=""):
        # R(0)=0, R(Sz)=last2(z,R(z)); the certificate chooses progress DI.
        # An arbitrary R(z) cannot compute. This certificate must use the IH.
        eigen = tag + "induction_parameter"
        z = v(eigen)
        recursive_step = computation(["R", s(z)], ["last2", z, ["R", z]])
        projection = computation(["last2", z, ["R", z]], ["R", z])
        successor_to_previous = self.transitivity(recursive_step, projection)
        ih = hypothesis(equation(["R", z], ZERO), 1 if self.baseline else 0)
        step = self.transitivity(successor_to_previous, ih)
        body = equation(["R", v("n")], ZERO)
        major = self.di(paired("unused", "n", body), ZERO, eigen, step, mode="ind")
        target = equation(["R", numeral(3)], ZERO)
        minor = {"rule": "use", "conclusion": target, "clause": 0,
                 "term": numeral(3), "premise": computation(["R", ZERO], ZERO)}
        return {"rule": "de", "conclusion": target, "major": major,
                "eigen": tag + "opened_witness", "premise": minor}

    def both_assumptions_nested(self):
        """An old certificate explicitly using both local assumptions, twice nested."""
        if not self.baseline:
            raise ValueError("This source fixture uses old two-assumption DI")

        def weaken(proof, added):
            result = copy.deepcopy(proof)
            if result["rule"] == "use":
                result["clause"] += added
            for key in ("premise", "major", "equality", "before"):
                if key in result:
                    result[key] = weaken(result[key], added)
            return result

        result = self.guarded_induction()
        step = result["major"]["premise"]
        base_use = hypothesis(equation(["R", ZERO], ZERO), 0)
        nested = weaken(self.guarded_induction(tag="nested_"), 2)
        fixed_truth = equation(["id", ZERO], ZERO)
        base_use["premise"] = self.transport(nested, computation(["id", ZERO], ZERO),
                                              lambda unused: fixed_truth)
        result["major"]["premise"] = self.transport(base_use, step,
                                                      lambda unused: step["conclusion"])
        return result

    def base_only(self, offset=0):
        # C(y,1,1)=0 follows at successors from the retained C(0,1,1)=0.
        # This certificate explicitly consumes its zero base, not its IH.
        one = numeral(1)
        z = v("base_parameter")
        base = equation(["C", ZERO, one, one], ZERO)
        one_is_zero = self.transitivity(self.symmetry(self.selector_zero(one, one)),
                                        hypothesis(base, offset))
        step = self.transitivity(self.selector_successor(z, one, one), one_is_zero)
        matrix = equation(["C", v("b"), v("a"), v("a")], ZERO)
        return self.di(paired("a", "b", matrix), one, "base_parameter", step)

    def compound_elimination(self):
        # Outer DI has a compound matrix and its single ordinary base is itself
        # a paired formula. DE opens that major and Use returns the paired goal.
        inner = self.base_only()["conclusion"]
        major = self.di(paired("outer_witness", "outer_counter", inner),
                             ZERO, "compound_parameter", hypothesis(inner, 0))
        minor = {"rule": "use", "conclusion": inner, "clause": 0,
                 "term": numeral(1), "premise": self.base_only(offset=1)}
        return {"rule": "de", "conclusion": inner, "major": major,
                "eigen": "compound_witness", "premise": minor}

    def capture_avoiding_transport(self):
        # The motive's bound name "z" deliberately collides with the free z in
        # the transported term. Correct substitution must rename that binder.
        z = v("z")
        old_term = ["id", s(z)]
        old_inner = paired("a", "b", equation(old_term, v("a")))
        old_base = equation(old_term, ZERO)
        before = self.di(old_inner, ZERO, "inner_parameter",
                              hypothesis(old_base, 1))
        equality = computation(old_term, s(z))
        step = self.transport(equality, before,
                              lambda hole: paired("z", "b", equation(hole, v("z"))))
        goal = paired("outer_a", "outer_n",
                      paired("a", "b", equation(v("outer_n"), v("a"))))
        return self.di(goal, ZERO, "z", step)

    def progress_noncomputation_base(self):
        # id(R(0))=0 is not a single defining equation, yet progress DI is legal.
        z = v("noncomp_parameter")
        successor_r = ["R", s(z)]
        previous_r = ["R", z]
        expanded = ["last2", z, previous_r]
        recursion = self.transitivity(computation(successor_r, expanded),
                                       computation(expanded, previous_r))
        congruence = self.transport(recursion, self.reflexivity(["id", successor_r]),
                                    lambda hole: equation(["id", successor_r], ["id", hole]))
        ih = hypothesis(equation(["id", previous_r], ZERO), 1 if self.baseline else 0)
        step = self.transitivity(congruence, ih)
        body = equation(["id", ["R", v("n")]], ZERO)
        major = self.di(paired("unused", "n", body), ZERO,
                        "noncomp_parameter", step, mode="ind")
        base = self.transitivity(computation(["id", ["R", ZERO]], ["R", ZERO]),
                                  computation(["R", ZERO], ZERO))
        target = equation(["id", ["R", numeral(3)]], ZERO)
        minor = {"rule": "use", "conclusion": target, "clause": 0,
                 "term": numeral(3), "premise": base}
        return {"rule": "de", "conclusion": target, "major": major,
                "eigen": "noncomp_witness", "premise": minor}

    def cases(self):
        return {
            "projection": computation(["first2", numeral(2), numeral(1)], numeral(2)),
            "composition": computation(["constant_zero", numeral(3)], ZERO),
            "recursion_zero": computation(["R", ZERO], ZERO),
            "recursion_successor": computation(["R", numeral(1)], ["last2", ZERO, ["R", ZERO]]),
            "progress_induction": self.guarded_induction(),
            "noncomputation_base": self.base_only(),
            "compound_di_de": self.compound_elimination(),
            "capture_avoiding_transport": self.capture_avoiding_transport(),
            "progress_noncomputation_base": self.progress_noncomputation_base(),
            "derived_reflexivity": self.reflexivity(numeral(2)),
        }


def substitution_stability(parameter, baseline=False):
    """Case DI remains case DI after parameter := 0; no proof repair is needed."""
    def body(counter):
        return equation(["C", parameter, counter, ZERO], ["first2", counter, ZERO])

    base = body(ZERO)
    context = [[base, "clause_parameter", body(s(v("clause_parameter")))]]
    antecedent = hypothesis(base, 1)
    step = {"rule": "use", "conclusion": body(s(v("z"))), "clause": 0,
            "term": v("z"), "premise": antecedent}
    proof = introduction(paired("unused", "n", body(v("n"))), ZERO, "z", step,
                         None if baseline else "case")
    return {"declarations": copy.deepcopy(DECLARATIONS), "scope": sorted(variables(parameter)),
            "context": context, "goal": copy.deepcopy(proof["conclusion"]), "proof": proof}


def write_json(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(content, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def generate(output):
    manifest = {"positive": {}, "scoped_substitution": {}}
    for mode in ("choice", "baseline"):
        paths = []
        builder = Builder(baseline=mode == "baseline")
        cases = builder.cases()
        if mode == "baseline":
            cases["both_assumptions_nested"] = builder.both_assumptions_nested()
        for label, proof in cases.items():
            relative = Path(mode) / (label + ".json")
            write_json(output / relative, packet(proof))
            paths.append(str(relative))
        manifest["positive"][mode] = paths
    for mode in ("choice", "baseline"):
        manifest["scoped_substitution"][mode] = {}
        for label, parameter in (("before", v("parameter")), ("after", ZERO)):
            relative = Path("scoped") / mode / (label + ".json")
            write_json(output / relative, substitution_stability(parameter, baseline=mode == "baseline"))
            manifest["scoped_substitution"][mode][label] = str(relative)
    write_json(output / "manifest.json", manifest)
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "fixtures")
    arguments = parser.parse_args()
    result = generate(arguments.output)
    print(json.dumps({"output": str(arguments.output),
                      "closed_packets": sum(map(len, result["positive"].values())),
                      "scoped_contracts": sum(map(len, result["scoped_substitution"].values()))}, sort_keys=True))
