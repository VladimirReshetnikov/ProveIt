# Independent review of complementary introductions

Reviewed source: ../../sections/choice_basis.tex.

## Verdict

The identity-language equivalence proof is valid with the stated eigenvariable
conditions and the literal-equation restriction on induction mode. The selected mode is stable under capture-free numerical substitution. No numerical facts, coverage theorem, logical macro
or arithmetic compiler is needed for this rule-equivalence proof.

## Critical binding point

Under the outer retained E(t,0), the inner formula must be

    D u y E(t,y),

with u absent from the matrix. It must not be the original D x y E(x,y).
In the correct formula, t is a fixed parameter. DE substitutes a fresh witness
only into the unused coordinate, so it opens E(t,0) -> all E(t,y), precisely
the clause needed to finish the outer case introduction.

The executable compiler chooses both inner binders freshly and substitutes
x:=t and y:=the fresh inner counter simultaneously. This also handles witnesses
containing variables whose names coincide with original bound names. It
renames the old premise's eigenparameter before nesting it under the outer
case eigenparameter.

## Ordered retained contexts

The translated old atomic premise is reached under exactly the ordered slots

    Gamma, E(t,0), E(t,v).

The outer case contributes the old base slot; inner induction contributes the
old IH slot. Therefore every original Use index is preserved. The compiler
tracks the current context length through DE and compound DI. This is a
literal ordered-context construction, not an appeal to exchange while leaving
certificate indices unchanged.

The isolated tests check examples with full transport, a nonzero witness,
nested atomic introductions, and explicit uses of both old local assumptions.

## Exact size

An old atomic DI is replaced by six nodes: outer case DI, inner induction DI,
DE, Use of the opened clause, Use of the retained base, and that last use's
computation premise. The old premise subtree occurs once. Other old nodes
occur once. Hence the exact count is N+5r, with r the old number of atomic DI
nodes.

This statement is for explicit inference trees. It is not a byte-size or
runtime bound and does not presume shared proof DAG nodes.

## Structural operations and reverse direction

Numerical substitution preserves equation versus paired roots and does not
change the explicit choice. Ordinary-assumption cut does not alter it either.
Thus the direct structural induction has no guard-flip case.

A new case introduction at an equation becomes old DI by weakening with the
unused IH. A new induction introduction becomes old DI by weakening with the
unused zero base. A compound case introduction is already old DI.

The translation therefore preserves the entire native consequence relation
in arbitrary retained contexts. Any full-iPRA interpretation of the original
native calculus transfers unchanged. The arithmetic-to-iPRA bridge remains a
separate premise, and theorem equivalence must not be confused with identical
raw JSON certificate acceptance.

## Implementation limits

The readable ChoiceDI checker's only logic changes from its matched baseline
are the DI field schema, explicit choice validation and chosen single local
assumption. Full PR declarations and all syntax, scope, capture, alpha and
transport checks remain present.

The independent producer and general compiler import neither checker. All
acceptance is independently verified by the complete checker. The finite
validation receipts substantiate these examples and the exact count, not a
formalized proof of the universal theorem.

