"""Supporting certificate generation and replay for the choice-DI kernels.

This file is an untrusted producer/test harness, not part of any measured
proof checker. It does not certify universal soundness by finite testing.
"""
import ast
import copy
import hashlib
import itertools
import json
import platform
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PACKAGE = ROOT.parent.parent
REFERENCE = PACKAGE / "reference/native_validation"
BASELINE = REFERENCE / "baseline.py"
FIXTURES = REFERENCE / "positive_fixtures.json"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def load(path, instrument=False):
    tree = ast.parse(path.read_text())
    require(isinstance(tree.body[-1], ast.Try), "CLI driver must be final try")
    tree.body.pop()
    if instrument:
        class Mark(ast.NodeTransformer):
            def visit_If(self, node):
                node = self.generic_visit(node)
                if isinstance(node.test, ast.Name) and node.test.id == "t":
                    call = ast.Expr(ast.Call(ast.Name("_mark_di", ast.Load()),
                                             [ast.Name(x, ast.Load()) for x in ("a", "m", "t")], []))
                    node.body.insert(0, ast.copy_location(call, node))
                return node
        tree = Mark().visit(tree)
        ast.fix_missing_locations(tree)
    ns = {}
    exec(compile(tree, str(path), "exec"), ns)
    return ns


def evaluate(ns, packet):
    data = copy.deepcopy(packet)
    ns["k"] = 0
    try:
        ns["q"] = data.pop
        result = bool(ns["c"](data.pop(), []))
        error = None
    except BaseException as exc:
        result = False
        error = type(exc).__name__
    return result, ns["k"], len(data), error


def source_introductions(packet):
    """Observe which existing packet cells perform DI on its successful run."""
    ns = load(BASELINE, instrument=True)
    data = copy.deepcopy(packet)
    stack = []
    introductions = []
    original = ns["c"]

    def pop():
        index = len(data) - 1
        value = data.pop()
        if stack:
            stack[-1]["cell_index"] = index
        return value

    def wrapper(a, g, s=0):
        stack.append({"cell_index": None})
        try:
            return original(a, g, s)
        finally:
            stack.pop()

    def mark(a, m, t):
        index = stack[-1]["cell_index"]
        if m == 0:
            introductions.append(index)

    ns.update(c=wrapper, q=pop, _mark_di=mark, k=0)
    require(bool(wrapper(pop(), [])), "Inherited positive fixture did not validate")
    return sorted(set(introductions))


def convert_modes(ns, packet):
    """Find a same-tree certificate using Case/Ind choices when one exists.

    This is not the general nested-introduction compiler. If the old proof
    actually needs both local assumptions, this restricted search can fail.
    """
    indices = source_introductions(packet)
    if len(indices) > 18:
        return None, len(indices), "mode-search limit"
    for bits in itertools.product((0, 1), repeat=len(indices)):
        candidate = copy.deepcopy(packet)
        for index, bit in zip(indices, bits):
            candidate[index][0] = 0 if bit else []
        if evaluate(ns, candidate)[0]:
            return candidate, len(indices), None
    return None, len(indices), "requires more than mode-only translation"


def focused_fixtures(records):
    # Q_n [I(n,1;u.u)=1], with an actual induction-hypothesis use.
    equation = [[5, [0], 2], [0]]
    paired = [equation, equation, equation]
    hypothesis = [[-1, [0], 2], [0]]
    motive = [[[-1], [0], 2], 1]
    identity = [[0, 0], [hypothesis, motive], [0, [0, 0, 0]],
                [paired, 0], [equation]]
    wrong_case = copy.deepcopy(identity)
    wrong_case[2][0] = []
    absent_minor = copy.deepcopy(identity)
    absent_minor.pop(0)
    bad_target = copy.deepcopy(identity)
    bad_target[-1][0][1] = [0, 0, 0]
    retained_base = copy.deepcopy(records[141]["packet"])
    require(records[141]["name"] == "retained_false_base_is_used", "Unexpected source fixture 141")
    retained_base[4][0] = []
    wrong_induction = copy.deepcopy(retained_base)
    wrong_induction[4][0] = 0
    # A nested-closure theorem with an arbitrary captured initializer.
    # Outer Case DI allocates -1; inner Ind DI allocates -2.
    param_equation = [[5, 7, 2], 3]
    inner_equation = [[5, [-1], 2], [-1]]
    param_hypothesis = [[-2, [-1], 2], [-1]]
    param_motive = [[[-2], [-1], 2], 1]
    parameter_identity = [[0, 0], [param_hypothesis, param_motive],
                          [0, [0, 0, 0]],
                          [[inner_equation, inner_equation, inner_equation], 0],
                          [[], [0, 0, 0]],
                          [[[param_equation], [param_equation], [param_equation]], 0],
                          [[param_equation]]]
    captured_counter = copy.deepcopy(parameter_identity)
    captured_counter[1][0][0][0] = -1

    cases = [
        {"name": "identity_iterator_induction", "packet": identity, "accept": True,
         "meaning": "Q_n [I(n,1;u.u)=1]; its atomic DI uses the Ind mode and its IH."},
        {"name": "same_induction_with_wrong_case_mode", "packet": wrong_case, "accept": False,
         "meaning": "The supplied proof requires the IH; choosing only the base invalidates it."},
        {"name": "induction_missing_computation_minor", "packet": absent_minor, "accept": False,
         "meaning": "Deleting the successor-computation premise invalidates the certificate."},
        {"name": "induction_changed_conclusion", "packet": bad_target, "accept": False,
         "meaning": "The changed raw conclusion does not match the proved closure."},
        {"name": "retained_false_base_case_mode", "packet": retained_base, "accept": True,
         "meaning": "Q_y(y=1), the conditional closure with false base, is obtained by Case mode."},
        {"name": "retained_false_base_wrong_ind_mode", "packet": wrong_induction, "accept": False,
         "meaning": "Replacing its required Case mode by Ind does not provide the false base."},
        {"name": "identity_iterator_parameter_and_counter", "packet": parameter_identity, "accept": True,
         "meaning": "Q_a Q_n [I(n,a;u.u)=a], with outer Case and inner Ind, and an arbitrary captured initializer."},
        {"name": "captured_induction_counter", "packet": captured_counter, "accept": False,
         "meaning": "Confusing the inner induction counter with the outer captured parameter invalidates the IH premise."},
        {"name": "failed_numeric_one_major_before_compound_intro",
         "packet": [[0, 0], [[[0, 0, 0], 0], 0], [1, [0, 0, 0]], [0, 0, [[0, 0]]]],
         "accept": False,
         "meaning": "A false-returning proof of major 1 must not fall through to compound Ind via the numeric mode comparison."},
        {"name": "failed_major_before_valid_computation",
         "packet": [[0, 0], [[[0, 0, 0], [0]], 0], [[0, 0, 0], 0]],
         "accept": False,
         "meaning": "The strict major contract rejects a failed major even when a computation fallback would otherwise be valid."},
        {"name": "canonical_false", "packet": [[0, 0], [0, [0]]], "accept": False},
        {"name": "changed_zero_computation", "packet": [[0, 0], [[0, 0, 0], [0]]], "accept": False},
        {"name": "malformed_four_child_goal", "packet": [[0, 0], [0, 0, 0, 0]], "accept": False},
        {"name": "negative_free_parameter", "packet": [[0, 0], [[0, -1, 0], -1]], "accept": False},
        {"name": "zero_computation", "packet": [[0, 0], [[0, 0, 0], 0]], "accept": True},
        {"name": "successor_computation", "packet": [[0, 0], [[[0], 0, [3]], [[0, 0, [3]]]]], "accept": True},
    ]
    for name, value in [("null", None), ("empty_object", {}), ("empty_string", "")]:
        alias = copy.deepcopy(retained_base)
        alias[4][0] = value
        cases.append({"name": "case_mode_falsy_marker_" + name, "packet": alias, "accept": True,
                      "meaning": "A falsy certificate marker unequal to numeric zero selects Case; it is not formula syntax."})
    for name, value in [("false", False), ("zero_float", 0.0)]:
        alias = copy.deepcopy(identity)
        alias[2][0] = value
        cases.append({"name": "ind_mode_zero_marker_" + name, "packet": alias, "accept": True,
                      "meaning": "A marker equal to numeric zero selects Ind at an equation and Case at a compound matrix."})
    return cases


def cli(job):
    path, data, mode, expected, name = job
    command = [sys.executable] + (["-O"] if mode else []) + [str(path)]
    p = subprocess.run(command, input=data, text=True, capture_output=True, timeout=15)
    target = ("ACCEPT\n", "", 0) if expected else ("REJECT\n", "", 1)
    require((p.stdout, p.stderr, p.returncode) == target,
            repr((path.name, name, mode, p.stdout, p.stderr, p.returncode, target)))
    return {"checker": path.name, "fixture": name, "optimized": mode, "accepted": expected}


def main():
    paths = [ROOT / name for name in
             ("tokens.py", "structure.py", "bytes.py")]
    require(all(p.exists() for p in paths), "A final choice kernel is missing")
    namespaces = {p.name: load(p) for p in paths}
    records = json.loads(FIXTURES.read_text())["records"]
    converted = []
    unresolved = []
    primary = namespaces["tokens.py"]
    cache = {}
    for record in records:
        key = json.dumps(record["packet"], separators=(",", ":"))
        if key not in cache:
            cache[key] = convert_modes(primary, record["packet"])
        packet, count, reason = cache[key]
        if packet is None:
            unresolved.append({"id": record["id"], "name": record["name"], "introductions": count,
                               "reason": reason})
            continue
        for name, ns in namespaces.items():
            require(evaluate(ns, packet)[0], "Variant rejected converted fixture: " + repr((name, record["name"])))
        converted.append({"id": record["id"], "name": record["name"], "packet": packet,
                          "source_introductions": count})

    cases = focused_fixtures(records)
    for case in cases:
        for name, ns in namespaces.items():
            actual = evaluate(ns, case["packet"])[0]
            require(actual == case["accept"], "Focused in-process mismatch: " + repr((name, case["name"], actual)))

    jobs = [(path, json.dumps(case["packet"]), optimized, case["accept"], case["name"])
            for path in paths for case in cases for optimized in (False, True)]
    jobs += [(path, json.dumps(record["packet"]), optimized, True, record["name"])
             for path in paths for record in converted for optimized in (False, True)]
    for path in paths:
        for data in ("", "[] []", "null", '"not a packet"'):
            for optimized in (False, True):
                jobs.append((path, data, optimized, False, "parser_" + repr(data)))
    with ThreadPoolExecutor(max_workers=8) as pool:
        cli_results = list(pool.map(cli, jobs))

    (HERE / "focused_certificates.json").write_text(json.dumps({"cases": cases}, indent=2) + "\n")
    (HERE / "converted_inherited_certificates.json").write_text(json.dumps({"records": converted}, indent=2) + "\n")
    result = {
        "python": platform.python_version(),
        "checker_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        "reference_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (BASELINE, FIXTURES)},
        "inherited_source_fixture_count": len(records),
        "same_tree_mode_converted_fixture_count": len(converted),
        "same_tree_mode_search_unresolved": unresolved,
        "focused_positive_count": sum(c["accept"] for c in cases),
        "focused_negative_count": sum(not c["accept"] for c in cases),
        "variant_count": len(paths),
        "in_process_converted_replays": len(converted) * len(paths),
        "in_process_focused_replays": len(cases) * len(paths),
        "cli_replays_normal_and_optimized": len(cli_results),
        "all_checks_passed": True,
        "scope": "Concrete canonical certificates, mode choices, malformed controls, and complete CLI replay. This is not a formal proof of the metatheorem or a complete old-proof compiler.",
        "packetwise_old_new_equivalence_claimed": False,
    }
    (HERE / "validation_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
