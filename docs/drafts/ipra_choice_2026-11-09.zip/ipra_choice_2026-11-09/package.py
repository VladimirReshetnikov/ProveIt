"""Create a deterministic ZIP, then check its CRCs and every payload hash."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED_DIRS = {".build", "__pycache__"}
MANIFEST = "MANIFEST.sha256.json"


def members():
    return sorted(p for p in ROOT.rglob("*")
                  if p.is_file() and not any(x in EXCLUDED_DIRS for x in p.relative_to(ROOT).parts)
                  and p.name != MANIFEST and p.suffix != ".pyc")


def main():
    required = ("report.pdf", "report.tex", "report_standalone.tex", "evidence/reproduction.json")
    if not all((ROOT / name).is_file() for name in required):
        raise SystemExit("Run python3 reproduce.py --pdf before packaging.")
    files = members()
    manifest = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    (ROOT / MANIFEST).write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    files.append(ROOT / MANIFEST)
    destination = ROOT.with_suffix(".zip")
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files):
            name = ROOT.name + "/" + str(path.relative_to(ROOT))
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 10, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(destination) as archive:
        corrupt = archive.testzip()
        if corrupt:
            raise RuntimeError("ZIP CRC failure: " + corrupt)
        for name, expected in manifest.items():
            actual = hashlib.sha256(archive.read(ROOT.name + "/" + name)).hexdigest()
            if actual != expected:
                raise RuntimeError("ZIP payload hash mismatch: " + name)
    result = {"archive": str(destination), "files": len(files), "bytes": destination.stat().st_size,
              "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
              "all_crcs_and_payload_hashes_match": True}
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
