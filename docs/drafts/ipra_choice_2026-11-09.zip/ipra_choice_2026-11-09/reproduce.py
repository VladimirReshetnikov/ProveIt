"""Run all included certificate validation and complete-source measurements."""
import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(relative):
    print("Running " + relative, flush=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    command = [sys.executable, str(ROOT / relative)]
    completed = subprocess.run(command, cwd=ROOT, env=env, text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if completed.returncode:
        print(completed.stdout)
        raise SystemExit(completed.returncode)
    return completed.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true", help="Also rebuild the PDF using pdflatex.")
    args = parser.parse_args()
    logs = {}
    for script in ("code/native/validation/validate.py", "code/readable/run_tests.py", "measure.py"):
        logs[script] = run(script)
    if args.pdf:
        logs["build.py"] = run("build.py")
    native = json.loads((ROOT / "code/native/validation/validation_results.json").read_text())
    readable = json.loads((ROOT / "code/readable/validation.json").read_text())
    metrics = json.loads((ROOT / "evidence/metrics.json").read_text())
    receipt = {
        "python": platform.python_version(),
        "all_commands_passed": True,
        "commands": list(logs),
        "native": native,
        "readable": readable,
        "metrics_match": metrics["all_expected_compact_metrics_match"],
        "pdf_rebuilt": args.pdf,
        "checkers": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted((ROOT / "code/native").glob("*.py"))},
    }
    (ROOT / "evidence/reproduction.json").write_text(json.dumps(receipt, indent=2) + "\n")
    (ROOT / "evidence/reproduction_log.txt").write_text(
        "\n\n".join(name + "\n" + output for name, output in logs.items()))
    print("PASS: compact certificates, readable compiler, rejection controls, and whole-source metrics.")
    print("Detailed receipts: evidence/reproduction.json and evidence/metrics.json")


if __name__ == "__main__":
    main()
