#!/usr/bin/env python3
"""Exact finite tests and obstruction checker; all sets are integer bitmasks."""
import argparse, json, random
from itertools import combinations
from math import comb


def check(ok,*details):
    if not ok: raise AssertionError(details)


def closure(types,top):
    c={top}
    for a in types: c |= {d&a for d in c}
    return c


def meet(types,top):
    for a in types: top &= a
    return top


def outside(d,t,s): return bool(d&~t) and bool(d&~s)


def gap(k,t,s,aux):
    c=closure(aux,k)
    return len({d&t&s for d in c}),sum(outside(d,t,s) for d in c)


def private_labels(r,aux):
    return [meet((b for j,b in enumerate(aux) if i!=j),r)&~a for i,a in enumerate(aux)]


def obstruction(k,t,s,aux,cap=None):
    """Shortest obstruction or None; capped search is complete if cap >= |T & S|."""
    if k<=0 or k&(k+1) or not(0<=t<k and 0<=s<k and t!=s):
        raise ValueError('invalid full mask or marked types')
    aux=sorted(set(aux)-{t,s})
    if any(not 0<=a<k for a in aux): raise ValueError('invalid auxiliary type')
    r=t&s
    cap=r.bit_count() if cap is None else min(cap,r.bit_count())
    for j in range(1,min(len(aux),cap)+1):
        for seq in combinations(aux,j):
            if all(private_labels(r,seq)) and not outside(meet(seq,k),t,s):
                return list(seq)
    return None


def union_family(k,types):
    """Independent direct enumeration in original language."""
    gs=[sum(1<<j for j,t in enumerate(types) if not(t>>i&1)) for i in range(k.bit_length())]
    f={0}
    for g in gs: f|={a|g for a in f}
    return f,gs


def counts(k,t,s,aux):
    f,_=union_family(k,[t,s]+list(aux))
    return len(f),sum(bool(a&1) for a in f),sum(bool(a&2) for a in f)


def ranks(r,aux):
    out={r:0}
    for a in aux:
        for d,v in list(out.items()):
            e=d&a;out[e]=min(out.get(e,len(aux)+1),v+1)
    return out


def exhaustive(n,minimal):
    k=(1<<n)-1
    pairs=cases=bad_count=min_count=rank_checks=0
    for t,s in combinations(range(k),2):
        if minimal and (t&s in (t,s)): continue
        aux=[a for a in range(k) if a not in (t,s) and (not minimal or outside(a,t,s))]
        r=t&s;m=len(aux);pairs+=1
        cl=[{k}]; shortest=[m+1]; shortest_irred=[m+1]
        for mask in range(1<<m):
            if mask:
                bit=mask&-mask;prev=cl[mask^bit];a=aux[bit.bit_length()-1]
                cl.append(prev|{d&a for d in prev})
            cs=cl[mask];c=len({d&r for d in cs});q=sum(outside(d,t,s) for d in cs)
            seq=[aux[i] for i in range(m) if mask>>i&1];size=len(seq)
            bad=c>q;irred=bool(seq) and c==1<<size
            invalid=irred and not outside(meet(seq,k),t,s)
            check(irred==(bool(seq) and all(private_labels(r,seq))),n,t,s,seq)
            if mask:
                kids=[mask^(1<<i) for i in range(m) if mask>>i&1]
                old=min(shortest[j] for j in kids);oldi=min(shortest_irred[j] for j in kids)
                shortest.append(min(old,size if bad else m+1))
                shortest_irred.append(min(oldi,size if invalid else m+1))
                check(shortest[mask]==shortest_irred[mask],n,t,s,seq)
                if bad and old==m+1:
                    min_count+=1
                    check(irred and invalid and size<=r.bit_count() and q==c-1,n,t,s,seq)
            else: check(not bad)
            bad_count+=bad;cases+=1
            rr=ranks(r,seq);good={d&r for d in cs if outside(d,t,s)}
            for h in range(r.bit_count()+1):
                if shortest[mask]==m+1 or shortest[mask]>h:
                    check({d for d,v in rr.items() if v<=h}<=good)
                    check(c-q<=sum(v>h for v in rr.values())<=sum(comb(r.bit_count(),i) for i in range(h+1,r.bit_count()+1)))
                    rank_checks+=1
    return dict(labels=n,minimal_marks_only=minimal,marked_pairs=pairs,auxiliary_collections=cases,bad_collections=bad_count,inclusion_minimal_bad_collections=min_count,rank_checks=rank_checks)


def sharp(t,h):
    r=(1<<t)-1;u,v=1<<t,1<<(t+1);bs=list(combinations(range(t),h))
    k=(1<<(t+2+len(bs)))-1
    a=[(r^(1<<i))|sum(1<<(t+2+j) for j,b in enumerate(bs) if i in b) for i in range(t)]
    return k,r|u,r|v,a


def sharp_audit():
    out=[]
    for t in range(2,10):
        for h in range(1,t):
            k,a,b,aux=sharp(t,h);c,q=gap(k,a,b,aux);q0=sum(comb(t,j) for j in range(h+1))
            check((c,q)==(1<<t,q0),t,h)
            w=obstruction(k,a,b,aux);check(w is not None and len(w)==h+1)
            n,nx,ny=counts(k,a,b,aux)
            check((n,nx,ny)==((1<<t)+q0+2,q0+1,q0+1))
            for j in range(t+1):
                for seq in combinations(aux,j):
                    check(gap(k,a,b,seq)==(1<<j,sum(comb(j,i) for i in range(min(j,h)+1))))
            out.append(dict(overlap=t,tested_order=h,shortest_obstruction=h+1,members=n,marked_counts=[nx,ny],deficit=c-q))
    return out


def layered(n,m):
    r=(1<<(n*m))-1;u,v=1<<(n*m),1<<(n*m+1);k=(1<<(n*m+2+m))-1
    aux=[]
    for j in range(m):
        p=(1<<((j+1)*n))-1;z=1<<(n*m+2+j)
        for i,l in combinations(range(n),2):
            aux.append((p^(1<<(j*n+i))^(1<<(j*n+l)))|z)
    return k,r|u,r|v,aux


def layered_audit(rng):
    out=[]
    for n,m in [(5,2),(6,2),(8,2),(8,3),(9,4),(10,2)]:
        k,t,s,aux=layered(n,m);types=[t,s]+aux;f,gs=union_family(k,types)
        a=(1<<n)-n-1;expected=2*m*a+4
        check(len(f)==expected and sum(bool(x&1) for x in f)*2==expected and sum(bool(x&2) for x in f)*2==expected)
        check(min(g.bit_count() for g in gs)==n-1 and len(set(gs))==len(gs))
        for g in gs:
            lower=0
            for h in gs:
                if h!=g and h&~g==0: lower|=h
            check(lower!=g,n,m,g)
        check(min((k^a).bit_count() for a in types)>=2)
        check(all(a&b not in (a,b) for a,b in combinations(types,2)))
        check(min((a&b).bit_count() for a,b in combinations(types,2))>=n-4)
        r=t&s
        for a,b in combinations(aux,2):
            if a&b&r not in (a&r,b&r): check(outside(a&b,t,s))
        check(all((a&~t).bit_count()==(a&~s).bit_count()==1 for a in aux))
        for _ in range(60):
            sub=[a for a in aux if rng.randrange(2)];nn,nx,ny=counts(k,t,s,sub);check(nx+ny>=nn)
        out.append(dict(block_size=n,blocks=m,generator_count=len(gs),distinct_types=len(types),members=expected,marked_counts=[expected//2]*2,smallest_nonempty_member=n-1,erasure_checks=60))
    return out


def random_audit(rng,rounds=400):
    out=dict(cases=0,bad=0,rank_checks=0,robust=0,direct_subcollection_checks=0)
    for _ in range(rounds):
        n=rng.randrange(4,13);k=(1<<n)-1
        t,s=(k^1,k^2) if rng.randrange(2) else rng.sample(range(k),2)
        aux=rng.sample([a for a in range(k) if a not in (t,s)],rng.randrange(1,min(k-2,9)+1))
        c,q=gap(k,t,s,aux);nn,nx,ny=counts(k,t,s,aux);check(nx+ny-nn==q-c)
        w=obstruction(k,t,s,aux);out['bad']+=c>q;out['robust']+=w is None;out['cases']+=1
        if w is not None:
            c1,q1=gap(k,t,s,w);check(c1==1<<len(w) and q1==c1-1 and len(w)<=(t&s).bit_count())
        else: check(c<=q)
        rr=ranks(t&s,aux)
        for h in range((t&s).bit_count()+1):
            if w is None or len(w)>h:
                check(c-q<=sum(v>h for v in rr.values())<=sum(comb((t&s).bit_count(),j) for j in range(h+1,(t&s).bit_count()+1)))
                if h==(t&s).bit_count()-1 and nn%2==0: check(2*max(nx,ny)>=nn)
                out['rank_checks']+=1
        if len(aux)<=7:
            bad=[]
            for h in range(len(aux)+1):
                for seq in combinations(aux,h):
                    nf,fx,fy=counts(k,t,s,seq);out['direct_subcollection_checks']+=1
                    if fx+fy<nf: bad.append(h)
            check((min(bad) if bad else None)==(len(w) if w else None))
    return out


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--quick',action='store_true');p.add_argument('--input',help='JSON with full_mask, T, S, auxiliaries');args=p.parse_args()
    if args.input:
        with open(args.input) as f:d=json.load(f)
        k,t,s,aux=(d[x] for x in ('full_mask','T','S','auxiliaries'));w=obstruction(k,t,s,aux)
        out=dict(overlap=(t&s).bit_count(),robust=w is None,shortest_obstruction=w)
        if w is not None:out.update(c_q=gap(k,t,s,w),private_labels=private_labels(t&s,w),intersection=meet(w,k))
        print(json.dumps(out,indent=2));return
    rng=random.Random(20261125)
    out=dict(exhaustive=[exhaustive(n,False) for n in range(1,4)],sharp=sharp_audit(),random=random_audit(rng),layered=layered_audit(rng))
    if not args.quick:out['exhaustive'].append(exhaustive(4,True))
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
