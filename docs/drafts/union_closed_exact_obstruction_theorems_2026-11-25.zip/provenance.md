# Sources and novelty audit

Date: 25 November 2026.

## Repository

The GitHub connector retrieved the directory at https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts . The directory included 30 ZIP research archives. The closest predecessor's complete LaTeX source was retrieved by decoding `union_closed_five_type_obstructions_2026-11-25.zip` from its GitHub base64 file response. Its Section 2 gives the trace-compression bound min(2^t-2,b(t)), Section 3 gives the optimal overlap-three result and the general lower construction, and the final paragraph explicitly asks for the optimal witness size at overlap four and beyond (4 versus 7). Section 5 proves the higher-order intersection condition only as a sufficient criterion for general s. The present paper credits those results and supplies the missing upper bound t, a classification of every minimal obstruction, and the necessity direction for the higher-order condition.

Ten related archives were examined through extracted README content and/or TeX section inventories (not an exhaustive full-text review):

- `union_closed_signature_interfaces_2026-11-25.zip`
- `union_closed_rank_transport_2026-11-25.zip`
- `union_closed_dense_core_2026-11-25.zip`
- `union_closed_redundant_core_2026-11-25.zip`
- `union_closed_antichain_shadows_2026-11-25.zip`
- `union_closed_lopsided_certificates_2026-11-25.zip`
- `union_closed_five_type_obstructions_2026-11-25.zip` (full principal TeX inspected)
- `union_closed_joint_laws_2026-11-25.zip`
- `union_closed_trace_entropy_2026-11-25.zip`
- `union_closed_uniform_threshold_2026-11-25.zip`

The predecessor attributes the distinct-union model, pair-gap identity and transfer through distinguishable translates to the dense-core draft. These are restated and credited; they are not claimed as new. The overlap-t lower-bound example is also inherited (the general binomial-deficit family extends it). The new proof compresses a single trace lacking an outside-both preimage, rather than compressing the whole trace closure. The private-label argument is elementary; the novelty claim is about the resulting exact theorem in this specific setting, not irredundant covers or Helly's theorem themselves.

## Public literature

- Bruhn & Schaudt, *The journey of the union-closed sets conjecture*, https://arxiv.org/abs/1309.3297 . Background and classical cases.
- Poonen, *Union-closed families*, https://doi.org/10.1016/0097-3165(92)90068-6 . Frankl-completeness framework, distinct from robustness under translates.
- Bruhn, Charbit, Schaudt & Telle, *The graph formulation of the union-closed sets conjecture*, https://arxiv.org/abs/1212.4175 . Graph formulation and generating sets of size at most three.
- Costa & Sadhu, *Beyond Liu's 0.382709 threshold for the union-closed sets conjecture*, https://doi.org/10.5281/zenodo.22727713 (v3, Sept. 12, 2026); https://arxiv.org/abs/2610.02295 . Reports unrestricted lower bound 0.3828852549667978. No entropy claim in this package depends on the preprint.
- Background: https://en.wikipedia.org/wiki/Union-closed_sets_conjecture and https://mathworld.wolfram.com/Union-ClosedSetsConjecture.html .

Targeted searches included combinations of “union closed families”, “robust pair”, “generator missing types”, “irredundant intersection”, “Frankl abundance”, “Helly”, and “translate generators intersection closure”. They did not locate the exact theorem. Searches are not a proof of novelty, and the other archives in the repository were not fully audited. Publication priority and independence from all existing results remain unconfirmed. The restricted theorem is compared concretely to the cited predecessor, not asserted to be the first result of its kind in all mathematical literature.

No changes were made to the repository. All claimed mathematical conclusions are given with proofs and are separate from finite validation. No proof-assistant verification or independent peer review is claimed.
