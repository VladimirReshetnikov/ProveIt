# Exact linear obstruction bounds for robust abundance

Research note, 25 November 2026. Start with **paper.pdf**. This package answers the optimal obstruction-size question in ProveIt's `union_closed_five_type_obstructions_2026-11-25.zip`: the worst-case minimum witness size at marked overlap t is exactly t for t >= 2, not merely bounded by the number of meet-irreducible traces. The marked points are certified in every distinct-union translate when no obstruction exists.

Further results:
- Exact characterization of all inclusion-minimal bad subcollections, with c = 2^j and q = 2^j - 1.
- Rank-sensitive frequency bounds, sharp binomial deficits, and an exact even-size half-frequency criterion when only tests through order t-1 pass.
- Helly reduction to low-order tests independent of t; a quadratic interval test and exact higher-order missing-label class characterization.
- Unbounded ordered-layer examples with no private points, arbitrarily large minimum member size and overlap, and a robust pair at exact half-frequency.
- Quantitative transfer across distinguishable translates.

## Files and reproduction

- `paper.tex`, `paper.pdf`: self-contained proofs and compiled manuscript.
- `verify.py`, `verification.json`: exact integer finite tests and recorded full output.
- `example_overlap4.json`, `example_overlap4_result.json`: an actual shortest-obstruction input and result.
- `provenance.md`: review scope, attribution, and novelty limitations.
- `Makefile`, `SHA256SUMS`: build commands and integrity checks.

Run from this directory with Python 3.10+ and TeX Live:

```sh
sha256sum -c SHA256SUMS
python3 verify.py > verification-new.json
diff -u verification.json verification-new.json
python3 verify.py --input example_overlap4.json
make pdf
```

`--quick` skips the exhaustive four-label minimal-mark sweep. The checker accepts JSON containing `full_mask` = 2^k-1, two distinct proper type masks `T`, `S`, and `auxiliaries` (a list of proper type masks). It returns the shortest obstruction and private label masks, or `robust: true` if no obstruction exists. A bad witness refutes robustness for the specified pair only, not Frankl's conjecture. A PDF rebuild can change its metadata and checksum.

All general results are proved in the manuscript, not inferred from finite tests. No Lean/Rocq formalization, independent refereeing, or established publication priority is claimed. This is not a proof of the unrestricted conjecture, nor a new universal numerical frequency record. No GitHub files were modified.
