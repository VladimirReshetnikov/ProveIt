A 52-NODE EQUALITY DETECTOR FOR iPRA
Prepared for Vladimir Reshetnikov, 9 November 2026

RESULT AND LIMIT
The fixed equality detector in the current closed-iteration pulse theory
shrinks from 70 to 52 fully expanded numerical tree nodes. Its three-cycle
update is replaced by a smaller update with the same reachable states, and
one exact iterator computation removes another three nodes.

The source theory remains equiconsistent and whole-domain bi-interpretable
with full intuitionistic first-order PRA, using the explicitly inherited
generic calibration and internal compiler. The report gives every source
axiom/schema and logical rule, the new target proof, the source calibration,
both interpretation composites, comparisons and further research questions.

The requested construction below the complete native checker frontier was
NOT achieved. This is a verified local mathematical improvement, not a claim
of the simplest axiomatization or a significant completed minimum breakthrough.
The full modified checker has 2665 normalized tokens / 2906 AST nodes /
7809 normalized bytes. The matched old pulse checker has 2743/2963/7950.
Existing native programs attain the coordinate envelope 306/340/839.

START HERE
report.pdf                      Main compiled report.
report.tex                      Standalone editable LaTeX source.
CLAIMS.json                     Machine-readable results and explicit limits.
code/checker52.py                Complete modified ordinary-logic checker.
code/pulse52.py                  Independent term construction and diagnostics.
code/measure.py                  Exact whole-source measurements and AST match.
code/test_checker.py             Attributed complete-checker validation suite.
code/CHECKER.md                  Exact inherited proof format and rules.
calibration/                    Explicit 1888-step source certificate,
                                adapted producer and unchanged replayer.
evidence/                       Executed receipts, source identities and reviews.
reference/                      Leading complete native comparison programs,
                                previous pulse checker, unchanged normalizer,
                                inherited notices and original pulse archive.

The original pulse archive in reference/ preserves the full mathematical
compiler dependency, its TeX/PDF and original provenance. Its historical
claims and dates are not silently attributed to this new report.

REPRODUCE
  python3 reproduce.py
  python3 build.py

To rebuild the archive and refresh its SHA-256 manifest:
  python3 package.py

Python 3.12.14 was used for exact normalization metrics. Evidence programs
need only Python's standard library. Building the PDF needs pdfLaTeX and the
standard packages listed at the beginning of report.tex. Shell escape is off.
The complete checker itself imports only json and reads one packet on stdin:
  python3 code/checker52.py < certificate.json

The evidence includes 48 finite numeral-pair diagnostics, exact tree counts,
an exact symbolic computation rewrite, a finite source-calibration replay,
and matched complete-checker tests. These are not a Lean/Rocq formalization
of the universal equivalence theorem. The paper identifies all dependencies.

SOURCE SNAPSHOT
VladimirReshetnikov/ProveIt
2afdf8f5df47a2c7f3da6cdf4b4130dd34d7fa91
All 15 current docs/drafts archives were retrieved at this fixed commit.

See ATTRIBUTION.txt and MANIFEST.json for provenance and payload integrity.
