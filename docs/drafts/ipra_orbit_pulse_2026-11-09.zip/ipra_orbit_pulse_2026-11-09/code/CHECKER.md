# Complete matched checker contract

`checker_template.py` is the complete engine for the ordinary intuitionistic
closed-iteration theory with BR, separation, and the raw anchored-reset rule.
Generate a runnable checker by replacing **only** the line
`E = @@COMPARATOR@@` with `E = <expanded comparator tree>`. The comparator's
only free names are `a` and `b`. Its expanded tree, all numerical and formula
validation, substitution, alpha equivalence, every inference, JSON parsing,
failure handling and verdict output belong to the measured complete source.

The engine imports only `json`. It does not import the term-definition
compiler, producer, measurements, tests, any arithmetic evaluator or another
proof checker. It never executes input as code. It matches raw syntactic
computation axioms; it does not use an uncharged reduction oracle.

## Numerical and formula syntax

Names are nonempty strings. Numerical terms are:

| Tree | Meaning |
|---|---|
| `["0"]` | Zero |
| `["v",x]` | Numerical variable x |
| `["S",t]` | Successor |
| `["I",h,n,a]` | Closed iteration `I_h(n,a)` |

In every I node the update h is a finite numerical tree whose free names are
contained in `{u}`. Its `u` is implicitly bound by that node. Nested updates
obey the same condition, and their own u is independently bound. Numerical
substitution changes n and a, and never enters h. Since an update is a proper
finite subtree, this is a staged closed-description grammar; no program-code
evaluator is introduced.

Formulas are `["eq",s,t]`, `["false"]`, the binary trees
`["and",A,B]`, `["or",A,B]`, `["imp",A,B]`, and binders
`["all",x,A]`, `["ex",x,A]`. Formula substitution is capture avoiding;
it alpha-renames conflicting inner binders. Formula matching is modulo alpha
equivalence, with the implicit u binder in a numerical update handled
separately from all outer numerical names.

The public packet has exactly the keys `context`, `goal`, `proof`. The
context must be `[]`, and the goal must be a closed well-formed formula.
Proof inference starts with the empty context. The inferred formula must
match the stated goal modulo alpha equivalence. A successful run prints
`ACCEPT` and exits zero; rejection prints `REJECT` and exits one. No unused
prefix, unparsed rule field, alternate axiom list, or comparator override is
accepted. Real resource limits can reject large valid proofs, as in the
comparison corpus; each idealized recursive operation is structurally finite.

## Proof instructions

Contexts are lists with zero-based indices. A discharged assumption is
appended to the context in its indicated branch. Every proof node has exactly
the displayed number of fields.

| Instruction | Inferred formula or condition |
|---|---|
| `["hyp",i]` | Context entry i; integer index in range |
| `["refl",t]` | `t=t` |
| `["zero",h,a]` | `I_h(0,a)=a` |
| `["step",h,n,a]` | `I_h(Sn,a)=h[I_h(n,a)/u]` |
| `["br",t]` | `Z(t)=0 or Z(t)=1`, where `Z(t)=I_0(t,S0)` |
| `["sep"]` | `0=S0 -> false` |
| `["eqE",p,x,F,q]` | p proves `s=t`, q proves `F[s/x]`; returns `F[t/x]` |
| `["falseE",A,p]` | p proves false; returns A |
| `["andI",p,q]` | Conjunction of the two inferred formulas |
| `["andE",i,p]` | Component i=0 or 1 of a proved conjunction |
| `["orI",0,B,p]` | If p proves A, returns `A or B` |
| `["orI",1,A,p]` | If p proves B, returns `A or B` |
| `["orE",p,q,r]` | p proves `A or B`; q under A and r under B prove the same result |
| `["impI",A,p]` | If p under appended A proves B, returns `A -> B` |
| `["impE",p,q]` | p proves `A -> B`, q proves A; returns B |
| `["allI",x,p]` | Returns `forall x A` from p proving A; x absent from retained context |
| `["allE",p,t]` | Instantiates p's universal formula at t |
| `["exI",x,B,t,p]` | p proves `B[t/x]`; returns `exists x B` |
| `["exE",p,z,q]` | Opens p's existential at fresh z; q proves a result not containing z |
| `["reset",x,f,z,t,p]` | Raw anchored-reset rule described below |

For existential elimination, z must be absent from all retained formulas,
all free parameters of the existential major, and the final conclusion.
Formula substitution handles the bound variable of the major automatically.

For reset, f is a fixed numerical template with its distinguished name x.
Put `c=f[1/x]`, `v=f[z/x]`, `r=I_0(E[v/a,c/b],Sz)`.
The premise p must infer precisely `f[r/x]=c`, modulo formula alpha
equivalence. The conclusion is `f[t/x]=c`. The eigenname z must differ from x
and be absent from the retained context, t, and all free names of f except x.
Comparator substitution is simultaneous: a replacement containing a or b
cannot be traversed again by substitution for the other placeholder.

No induction rule is primitive. Quantifier-free induction, equality
reflection, the clock identity, predecessor and pairing remain theorems of
the stated mathematical theory. The fixed arithmetic axiom inventory is
exactly I0, IS, BR and separation, together with reset as the only additional
arithmetic inference schema.

## Correctness argument and its limit

`term` and `formula` validate the displayed finite grammars and calculate
their free names by structural recursion. `replace` is simultaneous
numerical substitution, respecting every closed update binder. `subst`
renames an inner binder only when substitution would capture a free name;
its newly selected name occurs nowhere in the old body or replacement.
`canonical` identifies exactly alpha-equivalent validated formulas; free
names remain named and closed update variables have their own one-slot
environment.

Induction on a successful `infer` call proves that its result is a
well-formed derivable formula under its supplied well-formed context. Each
branch is precisely the inference shown in the table. The quantified branches
check their eigenvariable conditions. The reset branch constructs the exact
fixed instance and checks its eigenvariable conditions without accepting
arbitrary additional assumptions. Each child proof is a proper subtree,
and every field used as syntax is validated.

Conversely, a finite derivation in the stated ND presentation can be encoded
by the corresponding instruction at each node, using context indices for
assumptions. Alpha-renaming eigenvariables beforehand meets the explicit
freshness convention; the alpha matcher preserves the original final closed
formula. This is completeness for the displayed theory and finite proof
syntax, with sufficient finite resources. The separate mathematical paper
proves that theory's iPRA bi-interpretation; finite tests of this engine alone
do not prove that metatheorem.

Use `python3 test_checker.py PATH_TO_FIXED_CHECKER [SECOND_CHECKER]` for the
tests. Tests and generated certificates do not belong to the trusted kernel.
