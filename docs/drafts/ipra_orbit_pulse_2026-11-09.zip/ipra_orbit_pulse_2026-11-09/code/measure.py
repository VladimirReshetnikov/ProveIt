"""Whole-program measurements and exact matching of the old/new engines."""
import ast
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("source_measure", ROOT / "reference/source_measure.py")
normalizer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(normalizer)


def erased_tree(path):
    tree = ast.parse(path.read_text())
    found = 0
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target, ast.Name) and target.id == "E":
                node.value = ast.Constant(None)
                found += 1
    if found != 1:
        raise ValueError("Expected exactly one fixed comparator")
    return ast.dump(tree, include_attributes=False)


def main():
    paths = ["reference/native_operational.py", "reference/native_strict.py",
             "reference/native_lambda.py", "reference/native_original.py",
             "reference/checker_pulse.py", "code/checker52.py"]
    rows = [{"file": name, **normalizer.metrics(ROOT / name)} for name in paths]
    old, new = rows[-2:]
    same = erased_tree(ROOT / paths[-2]) == erased_tree(ROOT / paths[-1])
    if not same:
        raise ValueError("An executable change besides E was introduced")
    coordinates = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    result = {
        "python": platform.python_version(),
        "whole_program_measurement": True,
        "same_engine_after_erasing_E": same,
        "rows": rows,
        "matched_saving": {k: old[k] - new[k] for k in coordinates},
        "leading_native_coordinate_envelope": {
            k: min(r[k] for r in rows[:-2]) for k in coordinates},
        "new_below_native_envelope": all(new[k] < min(r[k] for r in rows[:-2])
                                         for k in coordinates),
        "scope": "Selected leading complete sources, not a universal minimality theorem"
    }
    (ROOT / "evidence/measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
