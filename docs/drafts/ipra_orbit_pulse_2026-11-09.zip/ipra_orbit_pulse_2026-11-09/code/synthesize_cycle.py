"""Bounded search for a closed-unary term with orbit 0 -> 1 -> 2 -> 0.

Unknown values are never accepted as a concrete result. This searches only
the bounded evaluation fragment and proves no unrestricted lower bound.
"""
import argparse
from time import monotonic

p=argparse.ArgumentParser()
p.add_argument('--bound',type=int,default=3)
p.add_argument('--size',type=int,default=12)
a=p.parse_args(); B=a.bound; U=B+1
levels=[{}, {tuple(range(B+1)): 'x', (0,)*(B+1): '0'}]
seen=dict(levels[1]); started=monotonic()

def iteration(h,n,v):
    result=[]
    for count,initial in zip(n,v):
        if count==U or initial==U:
            result.append(U); continue
        val=initial
        for _ in range(count):
            if val==U: break
            val=h[val]
        result.append(val)
    return tuple(result)

for size in range(2,a.size+1):
    new={}
    def keep(values,term):
        if values in seen or values in new: return
        new[values]=term
        if values[:3]==(1,2,0):
            print('FOUND',size,values,term,flush=True)
            raise SystemExit
    for t,e in levels[size-1].items():
        keep(tuple(min(x+1,U) for x in t),f'S({e})')
    for nh in range(1,size-2):
        for nn in range(1,size-nh-1):
            na=size-1-nh-nn
            if na<1: continue
            for h,eh in levels[nh].items():
                for n,en in levels[nn].items():
                    for v,ev in levels[na].items():
                        values=iteration(h,n,v)
                        if values not in seen and values not in new:
                            keep(values,f'I[{eh}]({en},{ev})')
    levels.append(new); seen.update(new)
    print(size,len(new),len(seen),round(monotonic()-started,3),flush=True)
print('No witness in bounded evaluation fragment.')
