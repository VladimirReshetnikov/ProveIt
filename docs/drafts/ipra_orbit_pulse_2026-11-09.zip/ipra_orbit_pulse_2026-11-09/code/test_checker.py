"""Exercise every rule and genuine capture/freshness/malformed-input risks."""
import json
from pathlib import Path
import subprocess
import sys


Z = ["0"]
O = ["S", Z]
V = lambda x: ["v", x]
EQ = lambda a, b: ["eq", a, b]
A = EQ(Z, Z)
B = EQ(O, O)


def load_engine(path):
    text = Path(path).read_text()
    prefix = text.rsplit("\ntry:\n", 1)[0]
    env = {}
    exec(compile(prefix, str(path), "exec"), env)
    env["require"](env["term"](env["E"]) <= {"a", "b"})
    return env


positive = []


def add(label, proof, goal):
    positive.append((label, {"context": [], "goal": goal, "proof": proof}))


add("reflexivity", ["refl", Z], A)
add("zero_compute", ["zero", ["S", V("u")], O],
    EQ(["I", ["S", V("u")], Z, O], O))
add("step_compute", ["step", ["S", V("u")], Z, O],
    EQ(["I", ["S", V("u")], O, O], ["S", ["I", ["S", V("u")], Z, O]]))
add("boolean_range", ["br", Z],
    ["or", EQ(["I", Z, Z, O], Z), EQ(["I", Z, Z, O], O)])
add("separation", ["sep"], ["imp", EQ(Z, O), ["false"]])
add("implication", ["impI", A, ["hyp", 0]], ["imp", A, A])
add("modus_ponens", ["impE", ["impI", A, ["hyp", 0]], ["refl", Z]], A)
add("conjunction", ["andI", ["refl", Z], ["refl", O]], ["and", A, B])
add("projection", ["andE", 1, ["andI", ["refl", Z], ["refl", O]]], B)
add("disjunction_left", ["orI", 0, B, ["refl", Z]], ["or", A, B])
add("disjunction_right", ["orI", 1, A, ["refl", O]], ["or", A, B])
add("disjunction_cases", ["impI", ["or", A, A],
    ["orE", ["hyp", 0], ["hyp", 1], ["hyp", 1]]], ["imp", ["or", A, A], A])
add("forall_and_alpha", ["allI", "x", ["refl", V("x")]],
    ["all", "a", EQ(V("a"), V("a"))])
add("forall_elimination", ["allE", ["allI", "x", ["refl", V("x")]], O], B)
ex = ["exI", "x", EQ(V("x"), V("x")), Z, ["refl", Z]]
add("exists_introduction", ex, ["ex", "x", EQ(V("x"), V("x"))])
add("exists_elimination", ["exE", ex, "z", ["refl", Z]], A)
left = ["I", Z, Z, Z]
add("equality_transport", ["eqE", ["zero", Z, Z], "x",
    EQ(V("x"), left), ["refl", left]], EQ(Z, left))
add("explosion", ["impI", ["false"], ["falseE", A, ["hyp", 0]]],
    ["imp", ["false"], A])
add("capture_avoidance", ["allI", "y", ["allE",
    ["allI", "x", ["allI", "y", ["refl", V("x")]]], V("y")]],
    ["all", "a", ["all", "b", EQ(V("a"), V("a"))]])
add("reset_constant", ["reset", "x", Z, "z", O, ["refl", Z]], A)
add("reset_passive_parameter", ["allI", "a", ["reset", "x", V("a"),
    "z", O, ["refl", V("a")]]], ["all", "a", EQ(V("a"), V("a"))])

negative = []


def bad(label, proof, goal=A):
    negative.append((label, {"context": [], "goal": goal, "proof": proof}))


bad("invented_axiom", ["axiom", A])
bad("open_hypothesis", ["hyp", 0])
bad("negative_index", ["hyp", -1])
bad("boolean_index", ["andE", True, ["andI", ["refl", Z], ["refl", O]]])
bad("extra_rule_field", ["refl", Z, "ignored"])
bad("captured_update", ["zero", V("a"), Z])
bad("invalid_update_shape", ["zero", ["I", V("a"), Z, Z], Z])
bad("bad_term_arity", ["refl", ["S", Z, O]])
bad("wrong_goal", ["refl", Z], B)
bad("mismatched_minor", ["eqE", ["refl", Z], "x", EQ(V("x"), Z), ["refl", O]])
bad("or_branch_mismatch", ["orE", ["orI", 0, B, ["refl", Z]],
    ["refl", Z], ["refl", O]])
bad("all_eigenparameter_in_context", ["allI", "x", ["impI", EQ(V("x"), Z),
    ["allI", "x", ["hyp", 0]]]],
    ["all", "x", ["imp", EQ(V("x"), Z), ["all", "y", EQ(V("y"), Z)]]])
bad("exists_witness_escape", ["allI", "z", ["exE", ex, "z", ["refl", V("z")]]],
    ["all", "z", EQ(V("z"), V("z"))])
bad("exists_eigenparameter_in_context", ["allI", "z", ["impI", EQ(V("z"), Z),
    ["exE", ex, "z", ["refl", Z]]]], ["all", "z", ["imp", EQ(V("z"), Z), A]])
bad("exists_eigenparameter_in_major", ["allI", "z", ["exE",
    ["exI", "x", EQ(V("x"), V("z")), V("z"), ["refl", V("z")]],
    "z", ["refl", Z]]], ["all", "z", A])
bad("reset_wrong_premise", ["reset", "x", Z, "z", O, ["refl", O]])
bad("reset_fixed_parameter_capture", ["allI", "z", ["reset", "x", V("z"),
    "z", O, ["refl", V("z")]]], ["all", "z", EQ(V("z"), V("z"))])
bad("reset_target_capture", ["allI", "z", ["reset", "x", Z,
    "z", V("z"), ["refl", Z]]], ["all", "z", A])
bad("reset_context_capture", ["allI", "z", ["impI", EQ(V("z"), Z),
    ["reset", "x", Z, "z", O, ["refl", Z]]]], ["all", "z", ["imp", EQ(V("z"), Z), A]])
bad("reset_placeholder_collision", ["reset", "x", Z, "x", O, ["refl", Z]])
negative.append(("nonempty_public_context", {"context": [A], "goal": A, "proof": ["hyp", 0]}))
negative.append(("comparator_override", {"context": [], "goal": A, "proof": ["refl", Z], "E": Z}))
negative.append(("open_public_goal", {"context": [], "goal": EQ(V("x"), V("x")), "proof": ["refl", V("x")]}))


def public_run(path, packet, optimized):
    command = [sys.executable] + (["-O"] if optimized else []) + [str(path)]
    result = subprocess.run(command, input=json.dumps(packet), text=True, capture_output=True)
    return result.returncode, result.stdout, result.stderr


def reset_packets(comparator):
    """An actual varying template, two distinct arguments, and a free b.

    The outer one-step zero update makes this function provably constant,
    so its reset premise has a short derivation with no assumed interface.
    Its argument still occurs in the exact trusted matcher, and its free b
    detects accidental sequential substitution in the comparator.
    """
    def inst(t, mapping):
        if t[0] == "v":
            return mapping.get(t[1], t)
        if t[0] == "S":
            return ["S", inst(t[1], mapping)]
        if t[0] == "I":
            return ["I", t[1], inst(t[2], mapping), inst(t[3], mapping)]
        return t

    f = ["I", Z, O, ["I", ["S", V("u")], V("x"), V("b")]]
    anchor = inst(f, {"x": O})
    at_z = inst(f, {"x": V("z")})
    exact = inst(comparator, {"a": at_z, "b": anchor})
    sequential = inst(inst(comparator, {"a": at_z}), {"b": anchor})
    if exact == sequential:
        raise RuntimeError("the comparator-alias negative control is ineffective")

    def packet(test):
        rho = ["I", Z, test, ["S", V("z")]]
        fr = inst(f, {"x": rho})
        anchor_zero = ["step", Z, Z, anchor[3]]
        zero_anchor = ["eqE", anchor_zero, "w", EQ(V("w"), anchor), ["refl", anchor]]
        fr_zero = ["step", Z, Z, fr[3]]
        premise = ["eqE", zero_anchor, "w", EQ(fr, V("w")), fr_zero]
        target = ["S", O]
        return {"context": [],
                "goal": ["all", "b", EQ(inst(f, {"x": target}), anchor)],
                "proof": ["allI", "b", ["reset", "x", f, "z", target, premise]]}

    return packet(exact), packet(sequential), packet(Z)


def test(path):
    engine = load_engine(path)
    actual_reset, wrong_substitution, wrong_comparator = reset_packets(engine["E"])
    good_cases = positive + [("reset_nonconstant_template", actual_reset)]
    bad_cases = negative + [("reset_sequential_comparator_substitution", wrong_substitution),
                            ("reset_changed_comparator", wrong_comparator)]
    for label, packet in good_cases:
        inferred = engine["infer"](packet["proof"], [])
        if not engine["same"](inferred, packet["goal"]):
            raise RuntimeError((label, inferred, packet["goal"]))
    # Direct checks of the two critical substitution contracts.
    nested = ["I", V("u"), V("u"), Z]
    if engine["replace"](nested, {"u": O}) != ["I", V("u"), O, Z]:
        raise RuntimeError("substitution entered a nested update binder")
    if engine["replace"](EQ(V("a"), V("b"))[1], {"a": V("b"), "b": Z}) != V("b"):
        raise RuntimeError("substitution was not simultaneous")
    checks = 0
    for optimized in (False, True):
        for expected, cases in ((True, good_cases), (False, bad_cases)):
            target = (0, "ACCEPT\n", "") if expected else (1, "REJECT\n", "")
            for label, packet in cases:
                actual = public_run(path, packet, optimized)
                if actual != target:
                    raise RuntimeError((path, label, optimized, target, actual))
                checks += 1
        for raw in ("null", "[]", "{broken", "{\"context\":[],\"goal\":null,\"proof\":[]}"):
            command = [sys.executable] + (["-O"] if optimized else []) + [str(path)]
            r = subprocess.run(command, input=raw, text=True, capture_output=True)
            if (r.returncode, r.stdout, r.stderr) != (1, "REJECT\n", ""):
                raise RuntimeError(("malformed JSON/interface", raw, r.returncode, r.stdout, r.stderr))
            checks += 1
    return {"checker": str(path), "positive_packets": len(good_cases),
            "negative_packets": len(bad_cases), "public_subprocess_checks": checks,
            "substitution_contract_checks": 2, "status": "passed"}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("usage: test_checker.py FIXED_CHECKER [SECOND_CHECKER]")
    print(json.dumps([test(Path(x).resolve()) for x in sys.argv[1:]], indent=2))
