"""Reproduce the mathematical diagnostics and complete-checker comparison."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(arguments, output):
    completed = subprocess.run([sys.executable, *arguments], cwd=ROOT,
                               capture_output=True, text=True, check=True)
    (ROOT / "evidence" / output).write_text(completed.stdout)
    if completed.stderr:
        raise RuntimeError(completed.stderr)
    print(output + ": passed")


run(["code/pulse52.py"], "detector_check.json")
run(["code/measure.py"], "measurement_receipt.json")
run(["calibration/make_pulse_certificate.py"], "calibration_receipt.json")
run(["code/test_checker.py", "reference/checker_pulse.py", "code/checker52.py"],
    "checker_tests.json")
print("All reproduction steps passed. See report.tex for evidence limitations.")
