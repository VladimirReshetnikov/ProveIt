"""Create the delivery ZIP and verify its CRCs and per-file SHA-256 manifest.

Run from any directory. Temporary TeX products and bytecode caches are omitted.
The manifest deliberately excludes itself; every other delivered file is hashed.
ZIP entry timestamps are fixed, so an unchanged payload packages reproducibly.
"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT.parent / (ROOT.name + ".zip")
OMIT_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".pyo", ".synctex.gz"}


def delivered(path):
    return (path.is_file()
            and "__pycache__" not in path.parts
            and path.name != "MANIFEST.json"
            and path.suffix not in OMIT_SUFFIXES
            and not path.name.endswith(".synctex.gz"))


files = sorted(path for path in ROOT.rglob("*") if delivered(path))
entries = []
for path in files:
    data = path.read_bytes()
    entries.append({
        "path": path.relative_to(ROOT).as_posix(),
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
    })
manifest = {
    "format": "sha256-payload-manifest-v1",
    "root": ROOT.name,
    "manifest_excludes_itself": True,
    "source_commit": "2afdf8f5df47a2c7f3da6cdf4b4130dd34d7fa91",
    "files": entries,
}
manifest_path = ROOT / "MANIFEST.json"
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

with zipfile.ZipFile(DESTINATION, "w", compression=zipfile.ZIP_DEFLATED,
                     compresslevel=9) as archive:
    for path in sorted(files + [manifest_path]):
        info = zipfile.ZipInfo(ROOT.name + "/" + path.relative_to(ROOT).as_posix(),
                               date_time=(2026, 11, 9, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                         compresslevel=9)

with zipfile.ZipFile(DESTINATION) as archive:
    assert archive.testzip() is None, "ZIP CRC verification failed"
    assert len(archive.namelist()) == len(entries) + 1
    for entry in entries:
        data = archive.read(ROOT.name + "/" + entry["path"])
        assert len(data) == entry["bytes"]
        assert hashlib.sha256(data).hexdigest() == entry["sha256"]

print(json.dumps({
    "archive": str(DESTINATION),
    "files": len(entries) + 1,
    "bytes": DESTINATION.stat().st_size,
    "sha256": hashlib.sha256(DESTINATION.read_bytes()).hexdigest(),
    "crc_and_manifest_verified": True,
}, indent=2))
