"""Compile the standalone manuscript; no shell escape or network is used."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
logs = []
for _ in range(3):
    result = subprocess.run(
        ["pdflatex", "-no-shell-escape", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
        cwd=ROOT, text=True, capture_output=True)
    logs.append(result.stdout + result.stderr)
    if result.returncode:
        (ROOT / "evidence/latex_build.txt").write_text("\n".join(logs))
        raise SystemExit(logs[-1][-6000:])
(ROOT / "evidence/latex_build.txt").write_text("\n".join(logs))
print("Compiled report.pdf successfully.")
