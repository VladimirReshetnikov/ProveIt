"""Replay finite source calibration in the explicitly stated closed-iteration theory.

This is a fragment verifier, not a full iPRA checker and not a size competitor.
The licensed arithmetic axioms are closed-iterator computation, acyclic macro
expansion and BR. The single arithmetic inference is the raw AR_e rule, whose
actual premise and eigenvariable condition are checked here. No induction,
coverage, clock identity, equality-characteristic oracle, numerical evaluator,
or asserted spike/diagonal lemma is available.
"""
import hashlib
import json
from collections import Counter
from pathlib import Path

ZERO = ['0']
ONE = ['S', ZERO]
TWO = ['S', ONE]


def V(name): return ['v', name]
def A(name, *args): return ['call', name, *args]
def I(name, n, a): return ['I', name, n, a]
def Eq(a, b): return ['eq', a, b]
def Or(a, b): return ['or', a, b]
def Imp(a, b): return ['imp', a, b]
def All(x, p): return ['all', x, p]


class InvalidCertificate(ValueError): pass


def require(condition, message):
    if not condition:
        raise InvalidCertificate(message)


def subst(term, variable, image):
    tag = term[0]
    if tag == 'v':
        return image if term[1] == variable else term
    if tag == '0': return term
    if tag == 'S': return ['S', subst(term[1], variable, image)]
    if tag == 'call': return ['call', term[1], *[subst(t, variable, image) for t in term[2:]]]
    if tag == 'I': return ['I', term[1], subst(term[2], variable, image), subst(term[3], variable, image)]
    raise InvalidCertificate('Bad term in substitution')


def variables(term):
    tag = term[0]
    if tag == 'v': return {term[1]}
    if tag == '0': return set()
    children = term[1:] if tag == 'S' else term[2:]
    return set().union(*(variables(t) for t in children))


def fv(formula):
    tag = formula[0]
    if tag == 'eq': return variables(formula[1]) | variables(formula[2])
    if tag == 'all': return fv(formula[2]) - {formula[1]}
    return fv(formula[1]) | fv(formula[2])


def fsubst(formula, variable, image):
    tag = formula[0]
    if tag == 'eq': return Eq(subst(formula[1], variable, image), subst(formula[2], variable, image))
    if tag in ('or', 'imp'):
        return [tag, fsubst(formula[1], variable, image), fsubst(formula[2], variable, image)]
    if tag == 'all':
        if formula[1] == variable: return formula
        require(formula[1] not in variables(image) or variable not in fv(formula[2]),
                'Capture in formula substitution')
        return All(formula[1], fsubst(formula[2], variable, image))
    raise InvalidCertificate('Bad formula in substitution')


def validate_term(term, table, allowed=None):
    require(type(term) is list and bool(term), 'Term must be a nonempty array')
    tag = term[0]
    if tag == 'v':
        require(len(term) == 2 and type(term[1]) is str and term[1].isidentifier(), 'Bad variable')
        require(allowed is None or term[1] in allowed, 'Captured/undeclared update variable')
        return
    if tag == '0':
        require(len(term) == 1, 'Malformed zero'); return
    if tag == 'S':
        require(len(term) == 2, 'Malformed successor')
        validate_term(term[1], table, allowed); return
    if tag == 'call':
        require(len(term) >= 2 and term[1] in table, 'Unknown macro')
        require(len(term) == len(table[term[1]]['parameters']) + 2, 'Macro arity mismatch')
    elif tag == 'I':
        require(len(term) == 4 and term[1] in table, 'Unknown iterator update')
        require(len(table[term[1]]['parameters']) == 1, 'Iterator update is not unary')
    else:
        raise InvalidCertificate('Unknown numerical constructor')
    for child in term[2:]: validate_term(child, table, allowed)


def declarations_table(declarations):
    require(type(declarations) is list, 'Declarations must be an array')
    table = {}
    for row in declarations:
        require(type(row) is dict and set(row) == {'name', 'parameters', 'body'}, 'Malformed declaration')
        name, params = row['name'], row['parameters']
        require(type(name) is str and name.isidentifier() and name not in table, 'Bad declaration name')
        require(type(params) is list and all(type(p) is str and p.isidentifier() for p in params)
                and len(set(params)) == len(params), 'Bad parameter list')
        validate_term(row['body'], table, set(params))
        table[name] = row
    return table


def validate_formula(formula, table):
    require(type(formula) is list and len(formula) == 3, 'Malformed formula')
    tag = formula[0]
    if tag == 'eq':
        validate_term(formula[1], table); validate_term(formula[2], table)
    elif tag in ('or', 'imp'):
        validate_formula(formula[1], table); validate_formula(formula[2], table)
    elif tag == 'all':
        require(type(formula[1]) is str and formula[1].isidentifier(), 'Bad binder')
        validate_formula(formula[2], table)
    else: raise InvalidCertificate('Unknown formula constructor')


def expand(call, table):
    require(call[0] == 'call', 'Expansion requires a macro application')
    validate_term(call, table)
    row = table[call[1]]
    # Simultaneous substitution, so parameter names do not capture other arguments.
    images = dict(zip(row['parameters'], call[2:]))
    def walk(term):
        if term[0] == 'v': return images.get(term[1], term)
        if term[0] == '0': return term
        if term[0] == 'S': return ['S', walk(term[1])]
        return [term[0], term[1], *[walk(t) for t in term[2:]]]
    return walk(row['body'])


def expected_claims():
    a,b,z=V('a'),V('b'),V('z')
    q=lambda t:A('spike_bit',t)
    e=lambda x,y:A('pulse_equality',x,y)
    return {
        'q_zero': Eq(q(ZERO), ZERO),
        'q_one': Eq(q(ONE), ZERO),
        'q_two': Eq(q(TWO), ONE),
        'q_successor': All('z',Imp(Eq(q(z),ONE),Eq(q(['S',z]),ZERO))),
        'comparator_endpoint': Eq(e(ONE,ZERO),ONE),
        'failed_diagonal_collapse': All('a',All('b',Imp(Eq(e(a,a),ONE),Eq(A('clock',b),a)))),
        'diagonal': All('a',Eq(e(a,a),ZERO)),
    }


def verify(certificate, declarations):
    table = declarations_table(declarations)
    digest = hashlib.sha256(json.dumps(declarations,separators=(',',':'),sort_keys=True).encode()).hexdigest()
    require(certificate.get('format') == 'pulse-source-calibration-v1', 'Unknown certificate format')
    require(certificate.get('declarations_sha256') == digest, 'Declaration digest mismatch')
    steps=certificate.get('steps')
    require(type(steps) is list, 'Missing proof steps')
    conclusions=[]; dependencies=[]; counts=Counter()
    for index, node in enumerate(steps):
        require(type(node) is dict and type(node.get('rule')) is str, 'Malformed proof step')
        rule=node['rule']; counts[rule]+=1
        def prior(ref):
            require(type(ref) is int and 0 <= ref < index, 'Non-earlier proof reference')
            return conclusions[ref], dependencies[ref]
        def hypothesis(ref):
            p,d=prior(ref)
            require(steps[ref]['rule']=='hyp', 'Discharge reference is not a hypothesis')
            return p
        d=set()
        if rule=='hyp':
            p=node['formula']; validate_formula(p,table); d={index}
        elif rule=='refl':
            t=node['term']; validate_term(t,table); p=Eq(t,t)
        elif rule=='definition':
            t=node['term']; p=Eq(t,expand(t,table))
        elif rule=='compute':
            t=node['term']; validate_term(t,table)
            require(t[0]=='I','Computation requires an iterator')
            name,n,seed=t[1:]
            if n==ZERO: value=seed
            else:
                require(n[0]=='S','Counter is neither zero nor an explicit successor')
                value=A(name,I(name,n[1],seed))
            p=Eq(t,value)
        elif rule=='BR':
            t=node['term']; validate_term(t,table)
            p=Or(Eq(A('Z',t),ZERO),Eq(A('Z',t),ONE))
        elif rule=='sym':
            e,d=prior(node['proof']); require(e[0]=='eq','Symmetry needs equality'); p=Eq(e[2],e[1])
        elif rule=='trans':
            e,d1=prior(node['left']); f,d2=prior(node['right'])
            require(e[0]==f[0]=='eq' and e[2]==f[1],'Transitivity middle mismatch')
            p=Eq(e[1],f[2]); d=d1|d2
        elif rule=='congruence':
            e,d=prior(node['proof']); require(e[0]=='eq','Congruence needs equality')
            t=node['template']; variable=node['variable']; validate_term(t,table)
            require(type(variable) is str and variable.isidentifier(),'Invalid motive variable')
            p=Eq(subst(t,variable,e[1]),subst(t,variable,e[2]))
        elif rule=='transport':
            e,d1=prior(node['equality']); body,d2=prior(node['body'])
            require(e[0]=='eq','Transport needs equality')
            template=node['template']; variable=node['variable']; validate_formula(template,table)
            require(type(variable) is str and variable.isidentifier(),'Invalid motive variable')
            require(body==fsubst(template,variable,e[1]),'Transport source mismatch')
            p=fsubst(template,variable,e[2]);d=d1|d2
        elif rule=='or_elim':
            major,dm=prior(node['major']);left,dl=prior(node['left']);right,dr=prior(node['right'])
            lh,rh=node['left_hypothesis'],node['right_hypothesis']
            require(major[0]=='or' and hypothesis(lh)==major[1] and hypothesis(rh)==major[2],
                    'Disjunction hypotheses mismatch')
            require(left==right,'Disjunction branch conclusions differ')
            p=left;d=dm|(dl-{lh})|(dr-{rh})
        elif rule=='imp_intro':
            h=node['hypothesis']; premise=hypothesis(h);p0,d0=prior(node['body'])
            p=Imp(premise,p0);d=d0-{h}
        elif rule=='imp_elim':
            major,d1=prior(node['major']);minor,d2=prior(node['minor'])
            require(major[0]=='imp' and major[1]==minor,'Implication premise mismatch')
            p=major[2];d=d1|d2
        elif rule=='all_intro':
            p0,d=prior(node['body']);variable=node['variable']
            require(type(variable) is str and variable.isidentifier(),'Invalid eigenvariable')
            require(all(variable not in fv(conclusions[h]) for h in d),'Universal eigenvariable in assumptions')
            p=All(variable,p0)
        elif rule=='all_elim':
            p0,d=prior(node['proof']);require(p0[0]=='all','Universal premise missing')
            t=node['term'];validate_term(t,table);p=fsubst(p0[2],p0[1],t)
        elif rule=='AR':
            matrix=node['template'];variable=node['variable'];z=node['eigenvariable'];target=node['target']
            validate_term(matrix,table);validate_term(target,table)
            require(type(variable) is str and variable.isidentifier() and type(z) is str and z.isidentifier()
                    and variable!=z,'Bad reset variables')
            premise,d=prior(node['premise'])
            require(z not in variables(matrix) and z not in variables(target),'Reset variable in fixed data/target')
            require(all(z not in fv(conclusions[h]) for h in d),'Reset eigenvariable in retained assumption')
            f=lambda t:subst(matrix,variable,t)
            anchor=f(ONE)
            reset=A('mask',A('pulse_equality',f(V(z)),anchor),['S',V(z)])
            require(premise==Eq(f(reset),anchor),'Exact raw reset premise mismatch')
            p=Eq(f(target),anchor)
        else: raise InvalidCertificate('Unlicensed rule: '+rule)
        validate_formula(p,table)
        conclusions.append(p); dependencies.append(set(d))
    expected=expected_claims(); exports=certificate.get('claims')
    require(type(exports) is dict and set(exports)==set(expected),'Export set mismatch')
    for name,ref in exports.items():
        require(type(ref) is int and 0 <= ref < len(steps),'Invalid export reference')
        require(conclusions[ref]==expected[name], 'Exported formula mismatch: '+name)
        require(not dependencies[ref], 'Export depends on undischarged hypotheses: '+name)
    return {'accepted':True,'proof_steps':len(steps),'rules':dict(sorted(counts.items())),
            'claims':list(expected),'declarations_sha256':digest,
            'scope':'Finite source spike and diagonal calibration only; no iPRA proof-checker-size claim.',
            'trusted_arithmetic':['acyclic macro definitions','closed iterator equations','BR','raw AR_e with checked freshness']}


if __name__=='__main__':
    import sys
    base=Path(__file__).resolve().parent
    certificate_path=Path(sys.argv[1]) if len(sys.argv)>1 else base/'pulse_certificate.json'
    declaration_path=Path(sys.argv[2]) if len(sys.argv)>2 else base/'term_definitions.json'
    try:
        result=verify(json.loads(certificate_path.read_text()),json.loads(declaration_path.read_text()))
        print(json.dumps(result,indent=2))
    except (InvalidCertificate,KeyError,TypeError,IndexError,ValueError,RecursionError) as error:
        print(json.dumps({'accepted':False,'error':str(error)}))
        raise SystemExit(1)
