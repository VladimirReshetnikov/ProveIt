A SMALL COMPLETE PROOF CHECKER FOR INTUITIONISTIC PRA
Prepared for Vladimir Reshetnikov, 3 November 2026
===================================================

Start with ipra_small_kernel.pdf. Its complete editable LaTeX source is
ipra_small_kernel.tex; generated and explanatory LaTeX inputs are in
artifacts/. AXIOMS.txt is a standalone exact specification.

RESULT

The ordinary recommended theory H_bot is genuinely bi-interpretable and
equiconsistent with full first-order iPRA. It keeps ordinary logical
falsity. Its small Hilbert checker has no primitive equality reflexivity:
that theorem follows from a recursion equation and equality replacement.

The smaller positive presentation H_plus additionally represents falsity
by 0=S0. Its exact proof translation and conservative ordinary completion
are proved in the paper. Its consistency means nonderivability of that
designated equation. The raw positive theory is NOT silently called
ordinarily model-theoretically bi-interpretable with iPRA.

The fixed-bridge alternative is mathematically valid but slightly larger
than the ordinary recommended kernel in the matched measurements.

FILES

  ipra_small_kernel.tex / ipra_small_kernel.pdf
    Complete theory, proof of arithmetic reconstruction and ordinary
    bi-interpretability, source comparison, measurements, and limitations.

  AXIOMS.txt
    Every syntax convention, logical/nonlogical schema, and inference rule.

  artifacts/kernel_genuine.py
    Recommended ordinary-falsity complete proof checker (H_bot).
  artifacts/kernel.py
    Smaller positive certificate checker (H_plus).
  artifacts/kernel_bridge.py
    Ordinary checker using the fixed two-way falsity bridge.
  artifacts/kernel_reference.py
    Matched baseline with native equality reflexivity restored.

  artifacts/check_json.py
    Shared file adapter. JSON arrays become finite tuple trees.
    Files must contain exactly the keys "proof" and "conclusion".
  artifacts/FORMAT.txt
    Exact term, formula, and certificate encodings and instruction arguments.

  artifacts/certificates/
    Actual checked Hilbert certificates for reflexivity, atomic explosion,
    quantified explosion, constructor coverage, and bridge explosion.

  artifacts/proof_builders.py
    Untrusted proof generator; its output is checked by the actual kernel.
    No kernel accepts hypotheses, a theorem registry, or an oracle.

  artifacts/test_kernels.py / artifacts/test_results.json
    Accepted proofs and adversarial syntax/side-condition rejection tests.
  artifacts/independent_review.txt
    Additional independent mathematical and implementation review findings.

  artifacts/measure.py / artifacts/checker_metrics.json
    Complete source bytes, lexical tokens, AST-node counts, lines, hashes.
  artifacts/kernel_template.py.txt / artifacts/generate_matched.py
    Reproduce the four matched modules by explicit component deletion.

  provenance/source_manifest.json
    Exact six current input archives, pinned URLs, sizes, and verified hashes.

  build.py
    Regenerate matched kernels and certificates, run tests and measurements,
    and compile the PDF. Requires Python >=3.10 and pdflatex.
  SHA256SUMS.txt
    Integrity hashes for the delivered files (excluding this file itself).

CHECK A CERTIFICATE

Run this as one shell command from the archive root:

  python3 artifacts/check_json.py artifacts/certificates/coverage.json --kernel kernel_genuine

For the positive presentation:

  python3 artifacts/check_json.py artifacts/certificates/quantified_explosion.json --kernel kernel

For the bridge certificate:

  python3 artifacts/check_json.py artifacts/certificates/bridge_explosion.json --kernel kernel_bridge

The output's final formula is the theorem checked. Quantified explosion
proves an implication from 0=S0; it does not prove its consequent alone.
Checking is offline and needs no LaTeX or proof-assistant installation.

REBUILD

  python3 build.py

To rerun only the Python work, run the following from artifacts/:

  python3 generate_matched.py
  python3 proof_builders.py
  python3 test_kernels.py
  python3 measure.py

MEASUREMENT AND VERIFICATION LIMITS

The metric counts each whole kernel, including syntax validation,
descriptor checks, substitutions, axiom data, and side conditions.
The equal optional JSON adapter is separately measured. The same Python
runtime and standard JSON parser are assumed in every comparison.

The source drafts supplied diagnostic programs, not complete proof
checkers, so their script lengths are not numerical baselines. The paper
separates a source-wide safe deletion theorem from the actual measured
common-core comparison. No global minimum over unspecified programming
languages or encodings is claimed. The complete bi-interpretability
argument is a written mathematical proof, not a Lean or Rocq formalization.

SOURCE SNAPSHOT

  https://github.com/VladimirReshetnikov/ProveIt
  3c85f4fc1c678b20fd7bbb44f9f5c17362baab8e
  docs/drafts: six archives, all dated 2026-11-03

The pinned input repository was read only. This deliverable is an archive;
its contents are not automatically committed to the repository.
