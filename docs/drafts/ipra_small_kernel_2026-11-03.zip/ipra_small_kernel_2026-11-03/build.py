"""Reproduce the proof checks, size measurements, and LaTeX paper."""

import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
ARTIFACTS = ROOT / "artifacts"


def run(command, directory, log_name):
    result = subprocess.run(command, cwd=directory, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (ARTIFACTS / log_name).write_text(result.stdout)
    if result.returncode:
        print(result.stdout)
        raise SystemExit(result.returncode)


def write_metric_macros():
    measurements = json.loads((ARTIFACTS / "checker_metrics.json").read_text())
    tests = json.loads((ARTIFACTS / "test_results.json").read_text())
    entries = measurements["kernels"]
    values = {}
    for prefix, filename in (("Ref", "kernel_reference.py"),
                             ("Ord", "kernel_genuine.py"),
                             ("Bridge", "kernel_bridge.py"),
                             ("Pos", "kernel.py")):
        record = entries[filename]
        for suffix, key in (("Bytes", "utf8_bytes"), ("Tokens", "python_tokens"),
                            ("Ast", "python_ast_nodes"), ("Lines", "source_lines")):
            values[prefix + suffix] = record[key]
        if prefix in ("Ord", "Pos"):
            for suffix, key in (("Bytes", "utf8_bytes"), ("Tokens", "python_tokens"),
                                ("Ast", "python_ast_nodes")):
                values[prefix + "Saving" + suffix] = record["saving_from_reference"][key]
    transport = measurements["shared_optional_json_transport"]
    for suffix, key in (("Bytes", "utf8_bytes"), ("Tokens", "python_tokens"),
                        ("Ast", "python_ast_nodes"), ("Lines", "source_lines")):
        values["Json" + suffix] = transport[key]
    for prefix in ("Ord", "Pos"):
        values[prefix + "TotalBytes"] = values[prefix + "Bytes"] + transport["utf8_bytes"]
    values["TestCount"] = tests["unittest_cases"]
    macros = ["% Generated from the complete measured modules and test results."]
    for name, value in values.items():
        formatted = f"{value:,}".replace(",", "{,}")
        macros.append("\\newcommand{\\" + name + "}{" + formatted + "}")
    (ARTIFACTS / "metrics.tex").write_text("\n".join(macros) + "\n")


def main():
    for name in ("generate_matched.py", "proof_builders.py", "test_kernels.py", "measure.py"):
        print("Running", name)
        run([sys.executable, name], ARTIFACTS, name.removesuffix(".py") + "_stdout.txt")
    run([sys.executable, "check_json.py", "certificates/coverage.json",
         "--kernel", "kernel_genuine"], ARTIFACTS, "json_check_stdout.txt")
    write_metric_macros()
    engine = shutil.which("pdflatex")
    if not engine:
        raise SystemExit("Checks passed; pdflatex is required to rebuild the paper.")
    for pass_number in range(1, 4):
        run([engine, "-interaction=nonstopmode", "-halt-on-error",
             "ipra_small_kernel.tex"], ROOT, f"latex_pass_{pass_number}.txt")
    pdf_bytes = (ROOT / "ipra_small_kernel.pdf").read_bytes()
    if not pdf_bytes.startswith(b"%PDF-") or b"%%EOF" not in pdf_bytes[-1024:]:
        raise SystemExit("The generated PDF is incomplete; rebuild before delivery.")
    report = {"status": "passed", "python": platform.python_version(),
              "pdf": "ipra_small_kernel.pdf", "latex_passes": 3,
              "scope": "Reproducible finite certificate checks, measurements, and compilation; "
                       "the metatheory is proved in the paper, not machine-formalized."}
    (ARTIFACTS / "build_results.json").write_text(json.dumps(report, indent=2) + "\n")
    print("Checks and PDF build passed.")


if __name__ == "__main__":
    main()
