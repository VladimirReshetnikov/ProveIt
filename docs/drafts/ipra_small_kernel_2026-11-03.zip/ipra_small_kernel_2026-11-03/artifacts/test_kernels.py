"""Acceptance and adversarial rejection tests for the complete checking kernels."""

import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import check_json
import generate_matched
import kernel
import kernel_bridge
import kernel_genuine
import kernel_reference
import proof_builders as build

ROOT = Path(__file__).resolve().parent
CORES = (kernel, kernel_genuine, kernel_bridge, kernel_reference)
ZERO = ("0",)
ONE = ("S", ZERO)
A = ("=", ZERO, ZERO)
B = ("=", ONE, ONE)
C = ("=", "p", "q")
BOT = ("bot",)


class KernelTests(unittest.TestCase):
    def reject(self, lines, core=kernel, expected=None):
        with self.assertRaises(core.InvalidProof):
            core.check(lines, expected)

    def test_all_eight_propositional_schemas(self):
        for core in CORES:
            for index, (arity, _) in enumerate(core.PROPOSITIONAL[:8]):
                result = core.check([("prop", index, (A, B, C)[:arity])])
                self.assertTrue(core.formula(result))

    def test_bad_propositional_arguments(self):
        for step in (("prop", 0, (A,)), ("prop", 0, (A, B, C)),
                     ("prop", -1, (A,)), ("prop", True, (A, B, C)),
                     ("prop", 0, (A, ("unknown",)))):
            self.reject([step])

    def test_modus_ponens_and_identity(self):
        proof = build.Proof()
        proof.identity(C)
        self.assertEqual(kernel.check(proof.lines), (">", C, C))

    def test_modus_ponens_rejects_wrong_antecedent(self):
        self.reject([("prop", 0, (A, B)), ("prop", 0, (B, A)), ("mp", 0, 1)])

    def test_references_are_strictly_earlier_integers(self):
        initial = [("prop", 0, (A, B))]
        for reference in (-1, 1, 10, True, False, "0", 0.0):
            self.reject(initial + [("gen", reference, "x")])

    def test_generalization_binds_only_free_occurrences(self):
        proof = build.reflexivity_certificate("x")
        result = kernel.check(proof["proof"] + [("gen", 3, "x")])
        self.assertEqual(result, ("all", ("=", 0, 0)))

    def test_generalization_rejects_invalid_variable(self):
        self.reject([("prop", 0, (A, B)), ("gen", 0, 0)])
        self.reject([("prop", 0, (A, B)), ("gen", 0, "")])

    def test_universal_elimination_avoids_capture(self):
        universal = ("all", ("ex", ("=", 1, 0)))
        expected = (">", universal, ("ex", ("=", "y", 0)))
        kernel.check([("all_e", universal, "y")], expected)
        wrong = (">", universal, ("ex", ("=", 0, 0)))
        self.reject([("all_e", universal, "y")], expected=wrong)

    def test_existential_introduction_instance(self):
        existential = ("ex", ("=", 0, "a"))
        kernel.check([("ex_i", existential, ONE)],
                     (">", ("=", ONE, "a"), existential))

    def test_universal_shift_valid(self):
        result = kernel.check([("all_shift", "x", A, ("=", "x", "x"))])
        expected = (">", ("all", (">", A, ("=", 0, 0))),
                    (">", A, ("all", ("=", 0, 0))))
        self.assertEqual(result, expected)

    def test_existential_shift_valid(self):
        body = ("=", "x", "x")
        result = kernel.check([("ex_shift", "x", body, A)])
        expected = (">", ("all", (">", ("=", 0, 0), A)),
                    (">", ("ex", ("=", 0, 0)), A))
        self.assertEqual(result, expected)

    def test_quantifier_side_conditions_cannot_leak(self):
        self.reject([("all_shift", "x", ("=", "x", ZERO), A)])
        self.reject([("ex_shift", "x", A, ("=", "x", ZERO))])

    def test_wrong_quantifier_kinds_and_unbound_witness(self):
        self.reject([("all_e", ("ex", ("=", 0, 0)), ZERO)])
        self.reject([("ex_i", ("all", ("=", 0, 0)), ZERO)])
        self.reject([("all_e", ("all", ("=", 0, 0)), 0)])

    def test_equality_transport_under_binders(self):
        pattern = ("all", ("=", "z", 0))
        expected = (">", ("=", "y", "x"),
                    (">", ("all", ("=", "y", 0)),
                     ("all", ("=", "x", 0))))
        kernel.check([("eq", "y", "x", pattern, "z")], expected)

    def test_equality_transport_rejects_bad_syntax(self):
        self.reject([("eq", 0, ZERO, A, "z")])
        self.reject([("eq", ZERO, ZERO, ("=", 0, 0), "z")])
        self.reject([("eq", ZERO, ZERO, A, True)])

    def test_recursion_base_for_arbitrary_initializer(self):
        call = ("R", 0, ZERO, "t", ())
        kernel.check([("r0", call)], ("=", call, "t"))

    def test_recursion_step_parameter_instantiation(self):
        call = ("R", 2, ("S", "n"), "a", ("b",))
        kernel.check([("rs", call)], ("=", call, "b"))

    def test_recursion_step_preserves_nested_descriptor_scope(self):
        descriptor = ("R", 0, 1, 0, ())
        call = ("R", descriptor, ("S", "n"), "a", ())
        old = ("R", descriptor, "n", "a", ())
        expected_rhs = ("R", 0, "n", old, ())
        kernel.check([("rs", call)], ("=", call, expected_rhs))

    def test_logical_substitution_does_not_enter_descriptors(self):
        call = ("R", 0, 0, 0, ())
        universal = ("all", ("=", call, 0))
        instance = ("=", ("R", 0, "x", "x", ()), "x")
        kernel.check([("all_e", universal, "x")], (">", universal, instance))

    def test_descriptor_free_names_and_escaped_slots_rejected(self):
        invalid = (
            ("R", "outside", ZERO, ZERO, ()),
            ("R", 2, ZERO, ZERO, ()),
            ("R", -1, ZERO, ZERO, ()),
            ("R", ("R", 2, 1, 0, ()), ZERO, ZERO, ("c",)),
            ("R", 0, 0, ZERO, ()),
        )
        for call in invalid:
            self.reject([("r0", call)])

    def test_bool_is_never_a_de_bruijn_index(self):
        self.reject([("all_e", ("all", ("=", True, 0)), ZERO)])
        self.reject([("r0", ("R", False, ZERO, ZERO, ()))])

    def test_wrong_recursion_counter_rejected(self):
        self.reject([("r0", ("R", 0, ONE, ZERO, ()))])
        self.reject([("rs", ("R", 0, ZERO, ZERO, ()))])
        self.reject([("r0", "r")])

    def test_sc_has_exact_guard_and_successor(self):
        equation = ("=", "x", "a")
        expected = (
            ">", ("all", (">", ("|", ("=", 0, ZERO), ("=", 0, "a")),
                           ("=", ("S", 0), "a"))),
            ("all", ("|", ("=", 0, ZERO), ("=", 0, "a"))))
        kernel.check([("sc", "x", equation)], expected)

    def test_sc_accepts_vacuous_equations_and_unused_parameters(self):
        kernel.check([("sc", "x", A)])
        kernel.check([("r0", ("R", 0, ZERO, ZERO, ("unused",)))])

    def test_sc_rejects_non_equation_induction(self):
        for candidate in (("all", ("=", 0, 0)), (">", A, B), ("|", A, B)):
            self.reject([("sc", "x", candidate)])

    def test_bottom_variants(self):
        self.reject([("prop", 0, (BOT, A))])
        self.reject([("prop", 8, (A,))])
        for core in (kernel_reference, kernel_genuine):
            core.check([("prop", 8, (A,))], (">", BOT, A))
        self.reject([("prop", 8, (A,))], core=kernel_bridge)

    def test_reflexivity_is_derived_in_all_reduced_kernels(self):
        certificate = build.reflexivity_certificate("t")
        for core in CORES:
            core.check(certificate["proof"], certificate["conclusion"])
        kernel_reference.check([("refl", "t")], ("=", "t", "t"))
        for core in (kernel, kernel_genuine, kernel_bridge):
            self.reject([("refl", "t")], core=core)

    def test_atomic_explosion_certificate_and_corruption(self):
        certificate = build.atomic_explosion_certificate()
        for core in CORES:
            core.check(certificate["proof"], certificate["conclusion"])
        damaged = list(certificate["proof"])
        index = next(i for i, step in enumerate(damaged) if step[0] == "rs")
        call = damaged[index][1]
        damaged[index] = ("rs", (call[0], call[1], ZERO, call[3], call[4]))
        self.reject(damaged)

    def test_quantified_explosion_certificate(self):
        certificate = build.quantified_explosion_certificate()
        expected = (">", build.FALSE_EQUATION,
                    ("all", ("ex", ("=", 1, ("S", 0)))))
        self.assertEqual(certificate["conclusion"], expected)
        for core in CORES:
            core.check(certificate["proof"], expected)

    def test_coverage_is_a_checked_theorem(self):
        certificate = build.coverage_certificate()
        for core in CORES:
            core.check(certificate["proof"], certificate["conclusion"])

    def test_bridge_explosion_is_checked(self):
        certificate = build.bridge_explosion_certificate()
        kernel_bridge.check(certificate["proof"], (">", BOT, ("=", "x", "y")))
        self.reject(certificate["proof"])

    def test_separation_is_a_closed_template(self):
        expected = (">", build.FALSE_EQUATION, BOT)
        for core in (kernel_reference, kernel_genuine):
            core.check([("prop", 9, ())], expected)
        self.reject([("prop", 9, ())])

    def test_json_transport_round_trip(self):
        certificate = build.coverage_certificate()
        serialized = json.loads(json.dumps(certificate))
        kernel.check(check_json.tuples(serialized["proof"]),
                     check_json.tuples(serialized["conclusion"]))

    def test_json_transport_rejects_null_conclusion(self):
        payload = {"proof": [("prop", 0, (A, B))], "conclusion": None}
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "null.json"
            path.write_text(json.dumps(payload))
            with patch("sys.argv", ["check_json.py", str(path)]):
                with self.assertRaises(kernel.InvalidProof):
                    check_json.main()

    def test_generated_sources_match(self):
        source = (ROOT / "kernel_template.py.txt").read_text()
        for filename, enabled in generate_matched.VARIANTS.items():
            self.assertEqual((ROOT / filename).read_text(),
                             generate_matched.render(source, enabled))

    def test_no_temporary_hypothesis_or_weakening_in_kernel(self):
        for tag in ("hyp", "assume", "weak", "anything"):
            self.reject([(tag, A)])

    def test_expected_conclusion_is_validated(self):
        self.reject([("prop", 0, (A, B))], expected=("=", 0, 0))

    def test_empty_and_malformed_proofs_rejected(self):
        for lines in ([], (), [()], [("mp",)], [None], [True], [("prop",)]):
            self.reject(lines)

    def test_deduction_refuses_a_nonfresh_generalization(self):
        proof = build.Proof()
        hypothesis = proof.assume(("=", "x", ZERO))
        proof.add(("gen", hypothesis, "x"))
        with self.assertRaises(ValueError):
            build.discharge(proof, ("=", "x", ZERO))


def main():
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(KernelTests)
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    report = {
        "status": "passed" if result.wasSuccessful() else "failed",
        "unittest_cases": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "kernels": [core.__name__ for core in CORES],
        "scope": "Concrete proof checking and adversarial syntax/side-condition tests. "
                 "The metatheory and bi-interpretability arguments are not machine-formalized.",
    }
    (ROOT / "test_results.json").write_text(json.dumps(report, indent=2) + "\n")
    if not result.wasSuccessful():
        raise SystemExit(1)


if __name__ == "__main__":
    main()
