"""Untrusted Hilbert proof constructors. Every exported certificate is rechecked.

The temporary 'hyp' constructor is supported only by this proof-producing
utility. It is absent from every checking kernel. Discharge expands each
temporary assumption using K, S, and the quantifier-shift axiom.
Reflexivity uses Q=R_w, matching the paper. The sample explosion certificates
use a constant-step selector; the paper also gives a shorter Q-based argument.
"""

import json
from pathlib import Path

import kernel
import kernel_bridge

ZERO = ("0",)
ONE = ("S", ZERO)
FALSE_EQUATION = ("=", ZERO, ONE)


def equal(left, right):
    return ("=", left, right)


def implies(left, right):
    return (">", left, right)


def successor(value):
    return ("S", value)


def recursor(body, counter, initial, *parameters):
    return ("R", body, counter, initial, tuple(parameters))


class Proof:
    def __init__(self, core=kernel):
        self.core = core
        self.lines = []
        self.formulas = []

    def add(self, step):
        value = self.core.infer(step, self.formulas)
        if not self.core.formula(value):
            raise ValueError("builder produced an ill-formed formula")
        self.lines.append(step)
        self.formulas.append(value)
        return len(self.lines) - 1

    def assume(self, value):
        if not self.core.formula(value):
            raise ValueError("ill-formed temporary hypothesis")
        self.lines.append(("hyp", value))
        self.formulas.append(value)
        return len(self.lines) - 1

    def prop(self, number, *values):
        return self.add(("prop", number, tuple(values)))

    def mp(self, arrow, argument):
        return self.add(("mp", arrow, argument))

    def fresh(self, *formulas):
        occupied = set().union(*(self.core.free_names(a) for a in formulas))
        index = 0
        while f"aux{index}" in occupied:
            index += 1
        return f"aux{index}"

    def identity(self, value):
        first = self.prop(0, value, implies(value, value))
        second = self.prop(0, value, value)
        third = self.prop(1, value, implies(value, value), value)
        return self.mp(self.mp(third, first), second)

    def equality_elimination(self, equality, pattern, variable, instance):
        _, left, right = self.formulas[equality]
        axiom = self.add(("eq", left, right, pattern, variable))
        return self.mp(self.mp(axiom, equality), instance)

    def reflexivity(self, value):
        call = recursor(1, ZERO, value)
        computation = self.add(("r0", call))
        variable = self.fresh(equal(value, value))
        return self.equality_elimination(
            computation, equal(variable, value), variable, computation)

    def certificate(self):
        if any(step[0] == "hyp" for step in self.lines):
            raise ValueError("temporary assumptions remain")
        result = {"proof": self.lines, "conclusion": self.formulas[-1]}
        self.core.check(result["proof"], result["conclusion"])
        return result


def discharge(source, assumption):
    """Produce assumption -> last_formula, preserving any other hypotheses."""
    target = Proof(source.core)
    translated = {}
    identity = None
    for number, step in enumerate(source.lines):
        conclusion = source.formulas[number]
        if step[0] == "hyp" and conclusion == assumption:
            if identity is None:
                identity = target.identity(assumption)
            translated[number] = identity
        elif step[0] == "mp":
            arrow, argument = step[1:]
            antecedent = source.formulas[argument]
            schema = target.prop(1, assumption, antecedent, conclusion)
            translated[number] = target.mp(
                target.mp(schema, translated[arrow]), translated[argument])
        elif step[0] == "gen":
            premise, variable = step[1:]
            if variable in source.core.free_names(assumption):
                raise ValueError("deduction theorem requires a fresh generalization variable")
            generalized = target.add(("gen", translated[premise], variable))
            shift = target.add(("all_shift", variable, assumption, source.formulas[premise]))
            translated[number] = target.mp(shift, generalized)
        else:
            original = (target.assume(conclusion) if step[0] == "hyp"
                        else target.add(step))
            lift = target.prop(0, conclusion, assumption)
            translated[number] = target.mp(lift, original)
    return target


def explode_equation(proof, false_premise, left, right):
    """From 0=S0 obtain left=right using a constant-step initialized recursor."""
    if proof.formulas[false_premise] != FALSE_EQUATION:
        raise ValueError("wrong falsity premise")
    first = recursor(2, ZERO, left, right)
    second = recursor(2, ONE, left, right)
    base = proof.add(("r0", first))
    step = proof.add(("rs", second))
    variable = proof.fresh(equal(left, right))
    pattern = equal(recursor(2, variable, left, right), left)
    intermediate = proof.equality_elimination(false_premise, pattern, variable, base)
    reversed_equality = proof.equality_elimination(
        step, equal(variable, left), variable, intermediate)
    reflexive = proof.reflexivity(right)
    return proof.equality_elimination(
        reversed_equality, equal(variable, right), variable, reflexive)


def reflexivity_certificate(value="t"):
    proof = Proof()
    proof.reflexivity(value)
    return proof.certificate()


def atomic_explosion_certificate():
    proof = Proof()
    premise = proof.assume(FALSE_EQUATION)
    explode_equation(proof, premise, "x", "y")
    return discharge(proof, FALSE_EQUATION).certificate()


def quantified_explosion_certificate():
    proof = Proof()
    premise = proof.assume(FALSE_EQUATION)
    equality = explode_equation(proof, premise, "u", ONE)
    existential = ("ex", equal("u", successor(0)))
    witness = proof.add(("ex_i", existential, ZERO))
    introduced = proof.mp(witness, equality)
    proof.add(("gen", introduced, "u"))
    return discharge(proof, FALSE_EQUATION).certificate()


def coverage_certificate():
    proof = Proof()
    counter = "x"
    predecessor_at_successor = recursor(1, successor(counter), ZERO)
    step = proof.add(("rs", predecessor_at_successor))
    first = successor(predecessor_at_successor)
    reflexive = proof.reflexivity(first)
    variable = proof.fresh(equal(first, successor(counter)))
    conclusion = proof.equality_elimination(
        step, equal(first, successor(variable)), variable, reflexive)
    equation = equal(successor(recursor(1, counter, ZERO)), counter)
    guard = ("|", equal(counter, ZERO), equation)
    introduction = proof.prop(0, proof.formulas[conclusion], guard)
    conditional = proof.mp(introduction, conclusion)
    universal = proof.add(("gen", conditional, counter))
    closure = proof.add(("sc", counter, equation))
    proof.mp(closure, universal)
    return proof.certificate()


def bridge_explosion_certificate():
    proof = Proof(kernel_bridge)
    bottom = ("bot",)
    premise = proof.assume(bottom)
    bridge = proof.add(("prop", 8, ()))
    left, right = proof.formulas[bridge][1:]
    project = proof.prop(4, left, right)
    bottom_to_false = proof.mp(project, bridge)
    false_equation = proof.mp(bottom_to_false, premise)
    explode_equation(proof, false_equation, "x", "y")
    return discharge(proof, bottom).certificate()


def main():
    root = Path(__file__).resolve().parent / "certificates"
    root.mkdir(exist_ok=True)
    certificates = {
        "reflexivity": reflexivity_certificate(),
        "atomic_explosion": atomic_explosion_certificate(),
        "quantified_explosion": quantified_explosion_certificate(),
        "coverage": coverage_certificate(),
        "bridge_explosion": bridge_explosion_certificate(),
    }
    for title, certificate in certificates.items():
        (root / f"{title}.json").write_text(json.dumps(certificate, indent=2) + "\n")
        print(f"{title}: {len(certificate['proof'])} checked lines")


if __name__ == "__main__":
    main()
