"""Exact source metrics; these are implementation measurements, not lower bounds."""

import ast
import hashlib
import io
import json
from pathlib import Path
import tokenize

ROOT = Path(__file__).resolve().parent
FILES = ("kernel_reference.py", "kernel_genuine.py", "kernel_bridge.py", "kernel.py")


def metrics(path):
    data = path.read_bytes()
    source = data.decode()
    ignored = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NL, tokenize.NEWLINE,
               tokenize.INDENT, tokenize.DEDENT, tokenize.COMMENT}
    tokens = tokenize.generate_tokens(io.StringIO(source).readline)
    return {
        "utf8_bytes": len(data),
        "python_tokens": sum(t.type not in ignored for t in tokens),
        "python_ast_nodes": sum(1 for _ in ast.walk(ast.parse(source))),
        "source_lines": len(source.splitlines()),
        "sha256": hashlib.sha256(data).hexdigest(),
    }


def main():
    result = {
        "scope": "Entire standalone mathematical checking modules, including syntax, "
                 "descriptor validation, substitution, schema data, and inference checking.",
        "caveat": "Same Python runtime and equal transport overhead; no absolute "
                  "minimality or machine-independent complexity lower bound is claimed.",
        "kernels": {name: metrics(ROOT / name) for name in FILES},
        "shared_optional_json_transport": metrics(ROOT / "check_json.py"),
    }
    reference = result["kernels"][FILES[0]]
    for name in FILES[1:]:
        result["kernels"][name]["saving_from_reference"] = {
            key: reference[key] - result["kernels"][name][key]
            for key in ("utf8_bytes", "python_tokens", "python_ast_nodes", "source_lines")
        }
    (ROOT / "checker_metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
