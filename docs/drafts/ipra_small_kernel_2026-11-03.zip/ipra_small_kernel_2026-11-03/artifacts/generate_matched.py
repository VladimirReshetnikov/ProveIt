"""Reproduce the matched kernels by deleting explicitly marked components."""

from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
VARIANTS = {
    "kernel_reference.py": {"BOTTOM", "EXPLOSION", "REFLEXIVITY", "SEPARATION"},
    "kernel_genuine.py": {"BOTTOM", "EXPLOSION", "SEPARATION"},
    "kernel_bridge.py": {"BOTTOM", "BRIDGE"},
    "kernel.py": set(),
}


def render(source, enabled):
    pattern = r"(?m)^([ ]*)# BEGIN ([A-Z]+)\n(.*?)^[ ]*# END \2\n"
    return re.sub(pattern, lambda m: m.group(3) if m.group(2) in enabled else "",
                  source, flags=re.S)


def main():
    source = (ROOT / "kernel_template.py.txt").read_text()
    for filename, enabled in VARIANTS.items():
        result = render(source, enabled)
        compile(result, filename, "exec")
        (ROOT / filename).write_text(result)
        print(filename)


if __name__ == "__main__":
    main()
