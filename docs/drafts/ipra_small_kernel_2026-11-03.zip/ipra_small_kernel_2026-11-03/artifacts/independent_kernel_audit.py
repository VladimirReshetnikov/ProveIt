import importlib, sys, json, random, itertools, hashlib, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
mods={name:importlib.import_module(name) for name in ['kernel','kernel_genuine','kernel_reference','kernel_bridge']}
k=mods['kernel']; Z=('0',); one=('S',Z); Eq=lambda a,b:('=',a,b)
rng=random.Random(3678301)
results={'checks':{},'defects':[]}
def count(kind): results['checks'][kind]=results['checks'].get(kind,0)+1
def good(kind,value):
 assert value, kind
 count(kind)
def rejects(module,proof,expected=None):
 try: module.check(proof,expected)
 except module.InvalidProof: return True
 return False
bad_steps=[None,(),[],('bogus',),('prop',True,(Eq(Z,Z),Eq(Z,Z))),('prop',-1,()),('prop',0,()),('prop',0,[Eq(Z,Z),Eq(Z,Z)]),('prop',0,(Eq(Z,Z),Eq(0,0))),('mp',0,0),('mp',-1,-1),('mp',True,False),('gen',0,''),('gen',0,0),('gen',-1,'x'),('all_e',('ex',Eq(0,0)),Z),('all_e',('all',Eq(0,0)),0),('all_e',('all',Eq(1,1)),Z),('ex_i',('all',Eq(0,0)),Z),('eq',Z,Z,Eq(0,0),'x'),('eq',True,Z,Eq('x','x'),'x'),('eq',Z,Z,Eq('x','x'),0),('sc','x',('all',Eq(0,0))),('sc',0,Eq(Z,Z)),('sc','x',Eq(True,Z)),('sc','x',Eq(0,0)),('r0',('R',2,Z,Z,())),('r0',('R',-1,Z,Z,())),('r0',('R',True,Z,Z,())),('r0',('R','escaped',Z,Z,())),('r0',('R',0,Z,Z,[])),('r0',('R',0,one,Z,())),('rs',('R',0,Z,Z,())),('rs',('R',('R',2,0,0,()),one,Z,('p',))),('rs',('R',('R',0,'escape',0,()),one,Z,())),('rs',('R',('R',0,0,0,('escape',)),one,Z,())),('r0',('R',0,Z,Z,(0,))),('prop',0,(('bot',),Eq(Z,Z))),('prop',0,(Eq(1.0,Z),Eq(Z,Z))),('all_shift','x',Eq('x',Z),Eq('y',Z)),('ex_shift','x',Eq('y',Z),Eq('x',Z)),('all_shift','x',Eq(('R',0,'x',Z,()),Z),Eq('y',Z)),('ex_shift','x',Eq('y',Z),Eq(('R',0,Z,Z,('x',)),Z))]
for name,module in mods.items():
 for i,step in enumerate(bad_steps):
  if i==37 and name!='kernel': continue
  good('malformed_proof_rejection',rejects(module,[step]))
 for badexpected in [(),[],True,0,'x',Eq(0,0),('all',Eq(1,1))]:
  good('malformed_expected_rejection',rejects(module,[('r0',('R',1,Z,Z,()))],badexpected))
# Frozen labels, alpha abstraction, and elimination under nested quantifiers.
desc=('R',0,1,0,())
call=('R',desc,'x','y',())
f=('all',('ex',Eq(('R',desc,'x',1,()),0)))
b=k.bind('all','x',f)
expected=('all',('all',('ex',Eq(('R',desc,2,1,()),0))))
good('exact_nested_abstraction',b==expected)
good('abstraction_roundtrip',k.instantiate(b[1],'x')==f)
q=('all',('ex',Eq(1,0)))
expected_ax=('>',q,('ex',Eq('y',0)))
good('quantifier_capture_avoidance',k.check([('all_e',q,'y')])==expected_ax)
good('reject_captured_conclusion',rejects(k,[('all_e',q,'y')],('>',q,('ex',Eq(0,0)))))
q=('all',('all',Eq(('R',desc,1,'p',()),0)))
inst=k.instantiate(q[1],('R',0,'y',Z,()))
good('frozen_slots_instantiation',inst==('all',Eq(('R',desc,('R',0,'y',Z,()),'p',()),0)))
for module in mods.values():
 good('bound_indices_not_free_names',module.check([('all_shift','x',('all',Eq(0,0)),Eq('x',Z))])[0]=='>')
 good('bound_indices_not_free_names',module.check([('ex_shift','x',Eq('x',Z),('all',Eq(0,0)))])[0]=='>')
# Nested local descriptors: validate only their own local slots.
for module in mods.values():
 good('nested_descriptor_locality',module.term(('R',('R',3,0,1,(0,1)),Z,Z,())))
 good('nested_descriptor_locality',not module.term(('R',('R',2,0,1,()),Z,Z,('a',))))
# Formula/term generators for independent finite-structure checks.
def genterm(depth=0,size=2,free=True):
 atoms=[Z]+list(range(depth))
 if free: atoms+=['x','y','z']
 if size==0 or rng.random()<.45:return rng.choice(atoms)
 if rng.random()<.5:return ('S',genterm(depth,size-1,free))
 m=rng.randrange(3)
 body=genterm(m+2,size-1,False)
 return ('R',body,genterm(depth,size-1,free),genterm(depth,size-1,free),tuple(genterm(depth,size-1,free) for _ in range(m)))
def genformula(depth=0,size=2):
 if size==0 or rng.random()<.4:return Eq(genterm(depth),genterm(depth))
 if rng.random()<.45:return (rng.choice(['all','ex']),genformula(depth+1,size-1))
 return (rng.choice(['&','|','>']),genformula(depth,size-1),genformula(depth,size-1))
def evalterm(t,env,bound,n):
 if isinstance(t,str):return env[t]
 if type(t)is int:return bound[t]
 if t==Z:return 0
 if t[0]=='S':return (evalterm(t[1],env,bound,n)+1)%n
 _,body,counter,initial,parameters=t
 args=tuple(evalterm(a,env,bound,n) for a in (counter,initial,*parameters))
 return int.from_bytes(hashlib.sha256(repr((body,len(parameters),args)).encode()).digest()[:4],'big')%n
def evalformula(f,env,bound,n):
 tag=f[0]
 if tag=='=':return evalterm(f[1],env,bound,n)==evalterm(f[2],env,bound,n)
 if tag=='&':return evalformula(f[1],env,bound,n) and evalformula(f[2],env,bound,n)
 if tag=='|':return evalformula(f[1],env,bound,n) or evalformula(f[2],env,bound,n)
 if tag=='>':return not evalformula(f[1],env,bound,n) or evalformula(f[2],env,bound,n)
 vals=(evalformula(f[1],env,[v]+bound,n) for v in range(n))
 return all(vals) if tag=='all' else any(vals)
for i in range(180):
 f=genformula(); a=genterm(); b=genterm()
 good('generated_syntax',k.formula(f) and k.term(a) and k.term(b))
 steps=[('eq',a,b,f,'x'),('all_e',('all',genformula(1)),a),('ex_i',('ex',genformula(1)),b),('sc','x',Eq(a,b)),('all_shift','fresh',f,genformula()),('ex_shift','fresh',genformula(),f)]
 for step in steps:
  conclusion=k.check([step])
  for n in (2,3):
   for _ in range(3):
    env={name:rng.randrange(n) for name in ['x','y','z','fresh']}
    good('finite_structure_schema_validity',evalformula(conclusion,env,[],n))
# Primitive recursion equations evaluated independently on standard small integers.
def evalpr(t,env=(),slots=()):
 if isinstance(t,str):return dict(env)[t]
 if type(t)is int:return slots[t]
 if t==Z:return 0
 if t[0]=='S':return 1+evalpr(t[1],env,slots)
 _,body,counter,initial,parameters=t
 n=evalpr(counter,env,slots);a=evalpr(initial,env,slots);p=[evalpr(x,env,slots) for x in parameters]
 if n>1000:raise OverflowError
 for j in range(n):a=evalpr(body,(),[a,j,*p])
 return a
def num(n):
 t=Z
 for _ in range(n):t=('S',t)
 return t
bodies=[(0,0),(0,1),(0,('S',0)),(1,2),(1,('R',0,1,0,())),(1,('R',1,0,2,())),(1,('R',2,0,1,(2,)))]
for m,body in bodies:
 for n in range(4):
  for initial in range(3):
   call=('R',body,num(n),num(initial),tuple(num(j+2) for j in range(m)))
   ax=k.check([('r0' if n==0 else 'rs',call)])
   good('independent_recursion_evaluation',evalpr(ax[1])==evalpr(ax[2]))
# Propositional schemas in finite branching Kripke frames.
frames=[{0:{0,1,2},1:{1},2:{2}},{0:{0,1,2},1:{1,2},2:{2}}]
atoms=[Eq('a','b'),Eq('a','c'),Eq('b','c')]
for frame in frames:
 upsets=[set(v for v in range(3) if mask>>v&1) for mask in range(8)]
 upsets=[u for u in upsets if all(frame[v]<=u for v in u)]
 def forces(f,w,valuation):
  if f[0]=='=':return w in valuation[f]
  if f[0]=='&':return forces(f[1],w,valuation) and forces(f[2],w,valuation)
  if f[0]=='|':return forces(f[1],w,valuation) or forces(f[2],w,valuation)
  return all(not forces(f[1],v,valuation) or forces(f[2],v,valuation) for v in frame[w])
 for index,(arity,_) in enumerate(k.PROPOSITIONAL):
  ax=k.check([('prop',index,tuple(atoms[:arity]))])
  for vals in itertools.product(upsets,repeat=arity):
   good('branching_kripke_propositional_validity',forces(ax,0,dict(zip(atoms,vals))))
# Regression: a malformed JSON null conclusion must be rejected.
path=ROOT/'null_conclusion_certificate.json'
path.write_text(json.dumps({'proof':[['r0',['R',1,['0'],['0'],[]]]],'conclusion':None}))
r=subprocess.run([sys.executable,str(ROOT/'check_json.py'),str(path)],capture_output=True,text=True)
if r.returncode==0:
 results['defects'].append({'severity':'transport input-validation issue, not a false-theorem acceptance','case':'JSON conclusion:null','detail':'check_json passes None as expected, invoking check() no-goal mode; malformed expected conclusion accepted','stdout':r.stdout.strip()})
else:count('null_expected_transport_rejected')
path.unlink()
results['total_checks']=sum(results['checks'].values())
results['kernel_hashes']={name:hashlib.sha256((ROOT/(name+'.py')).read_bytes()).hexdigest() for name in mods}
(ROOT/'independent_kernel_audit.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
