from json import load
i = lambda a, t=None, d=(k := 0): [i(b, t, d + b' \x02\x01\x04'[len(a)]) for b in a] if isinstance(a, list) else a if k <= a < d else d % 2 and i(t, d=1)

def c(a, g):
    global k
    if i(a) in g:
        return
    m, s, u, t = q()
    if m:
        c(m, g)
        if m in ([s, u], not s and [t]) and i(t, u) == a:
            a = i(t, s)
        h = m[2:]
    elif t:
        h = a = i(a[2], t, 2)
    else:
        n, t, u = s
        h = [s, i(u, i([*n, t, u], d=1), 1) if n else t]
    k -= 1
    c(i(a, [k]), g + [i(h, k if m or len(a) % 2 == m else 0)])
try:
    c((q := load(open(0)).pop)(), [])
except:
    print('REJECT')
    raise
print('ACCEPT')
