iPRA WITH TWO-EQUATION INDUCTION
3 November 2026
==============================

Start with ipra_two_equation_induction.pdf.
SPECIFICATION.txt gives the complete theory independently of the paper.

RECOMMENDATION

Use ordinary intuitionistic first-order equality logic with:
  1. 0 != S0;
  2. primitive-recursive defining equations;
  3. ordinary induction for a disjunction of two equations.

All quantifier-free induction is derived and can be used as the ordinary
working interface. Successor injectivity, successor nonzeroness, and
zero-or-successor coverage require no separate axioms.

The report proves full first-order bi-interpretability and syntactic
equiconsistency with iPRA. Both interpretation domains are the entire
carrier and both round-trip isomorphisms are internally identity.

It also gives a sharp comparison: with the fixed computation base,
induction for one equation is insufficient even up to ordinary
bi-interpretation using tuples, quotients, and finitely many parameters.
The product/automorphism obstruction is credited to the archived
finite-unfolding draft and reproved with a complete arithmetic-order proof.

WHAT IS IMPROVED

The proposal matches the strongest current elementary core's one fixed
sentence and two effective schemas, uses ordinary base-and-step induction,
and permits the direct invariant d(y,n)=0 OR y=n+d(y,n).
It omits optional special binders and signature optimizer algorithms.
It does not claim to dominate every source formula in raw tree size, or
to establish an absolute cognitive minimum across arbitrary languages.

CONTENTS

ipra_two_equation_induction.pdf   Compiled report
report.tex                       Main LaTeX source
sections/*.tex                   Complete proof and comparison sections
SPECIFICATION.txt                Standalone exact specification
provenance/source_manifest.json  Pinned source paths and verified hashes
provenance/comparison.csv        All eight source audit decisions
artifacts/check_examples.py     Standard-library numerical diagnostics
artifacts/results.json          Recorded finite diagnostic results
artifacts/validation.json       Build and review status
build.py                        Rebuild, check, hash, and ZIP script
SHA256SUMS.txt                   Checksums, excluding this list itself

REBUILD

  python3 build.py
  python3 build.py --checks-only
  python3 build.py --archive

PDF generation needs pdflatex and the standard packages named in report.tex.
Numerical checks need Python 3.10 or later and no third-party packages.
Temporary LaTeX files stay in .build and are excluded from the archive.

VERIFICATION SCOPE

The core and the proof of equivalence have complete written mathematical
proofs and independent mathematical reviews. The Python checks verify
finite examples only; they are not a proof-assistant formalization and do
not establish the infinite model or interpretation theorems.

SOURCE SNAPSHOT

https://github.com/VladimirReshetnikov/ProveIt
77e7fdf4a46344cc79cc9c88d78954bab1764ec5

The actual current and archived directories at this commit each contain
four proposals. All current drafts offer substantive improvements under
the broad historical filter, while equation closure sets the relevant
cognitive benchmark for the elementary axioms.
