#!/usr/bin/env python3
"""Rebuild the mathematical report and its finite diagnostics.

Uses Python's standard library and pdflatex. No downloaded source archive
is executed. Temporary LaTeX output is kept outside the deliverable file set.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile


BASE = Path(__file__).resolve().parent
PDF_NAME = "ipra_two_equation_induction.pdf"
BUILD = BASE / ".build"
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".synctex.gz"}


def deliverable_files():
    for path in sorted(BASE.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(BASE)
        if any(part.startswith(".") or part == "__pycache__" for part in relative.parts):
            continue
        if path.suffix in EXCLUDED_SUFFIXES or path.suffix == ".zip":
            continue
        if relative.as_posix() == "report.pdf":
            continue
        yield path


def checks():
    subprocess.run(
        [sys.executable, str(BASE / "artifacts/check_examples.py")],
        cwd=BASE, check=True
    )
    return json.loads((BASE / "artifacts/results.json").read_text())


def compile_pdf():
    compiler = shutil.which("pdflatex")
    if not compiler:
        raise SystemExit("pdflatex is required to compile report.tex")
    BUILD.mkdir(exist_ok=True)
    for index in range(1, 4):
        process = subprocess.run(
            [compiler, "-no-shell-escape", "-interaction=nonstopmode",
             "-halt-on-error", "-file-line-error",
             "-output-directory=" + str(BUILD), "report.tex"],
            cwd=BASE, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
        )
        (BUILD / f"latex_pass_{index}.txt").write_text(process.stdout)
        if process.returncode:
            print(process.stdout[-12000:])
            raise SystemExit(process.returncode)
    final_log = (BUILD / "report.log").read_text(errors="replace")
    bad = [
        line for line in final_log.splitlines()
        if any(marker in line for marker in (
            "undefined references", "multiply defined", "Overfull",
            "destination with the same identifier", "LaTeX Warning: Citation",
            "LaTeX Warning: Reference"
        ))
    ]
    if bad:
        print("\n".join(bad))
        raise SystemExit("Resolve the reported LaTeX problems before delivery.")
    shutil.copy2(BUILD / "report.pdf", BASE / PDF_NAME)
    match = re.search(r"Output written on .*?\((\d+) pages,", final_log, re.S)
    return {
        "pdf": PDF_NAME,
        "passes": 3,
        "page_count": int(match.group(1)) if match else None,
        "unresolved_references": False,
        "overfull_boxes": False,
        "duplicate_pdf_destinations": False,
        "visual_review": "Performed separately; see artifacts/validation.json."
    }


def refresh_hashes():
    entries = []
    for path in deliverable_files():
        if path.name == "SHA256SUMS.txt":
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        entries.append(f"{digest}  {path.relative_to(BASE).as_posix()}")
    (BASE / "SHA256SUMS.txt").write_text("\n".join(entries) + "\n")


def archive():
    target = BASE.parent / (BASE.name + ".zip")
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in deliverable_files():
            z.write(path, (Path(BASE.name) / path.relative_to(BASE)).as_posix())
    with zipfile.ZipFile(target) as z:
        failure = z.testzip()
        if failure is not None:
            raise SystemExit("ZIP integrity failure: " + failure)
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks-only", action="store_true")
    parser.add_argument("--archive", action="store_true")
    args = parser.parse_args()
    numerical = checks()
    if args.checks_only:
        return
    pdf = compile_pdf()
    (BASE / "artifacts/build_result.json").write_text(json.dumps({
        "diagnostics": {
            "status": numerical["status"],
            "assertions": numerical["total_assertions"],
            "scope": numerical["verification_scope"]
        },
        "latex": pdf
    }, indent=2) + "\n")
    refresh_hashes()
    result = {"status": "built", **pdf}
    if args.archive:
        result["archive"] = str(archive())
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
