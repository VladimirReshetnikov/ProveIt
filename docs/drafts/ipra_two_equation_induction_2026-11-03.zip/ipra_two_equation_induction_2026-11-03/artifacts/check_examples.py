#!/usr/bin/env python3
"""Deterministic finite diagnostics for the accompanying written proofs.

This is NOT a formal verification of the induction schemata, interpretation
theorem, all primitive recursive functions, or the infinite product model.
The natural-number tests use finite input samples with ordinary unbounded
integer arithmetic. The product tests inspect witnesses and sample operation
compatibility in N x N; a bounded box is never asserted to be a model.

Run: python3 artifacts/check_examples.py
The default output is artifacts/results.json next to this script.
Only the Python standard library is required.
"""

from __future__ import annotations

import argparse
from functools import lru_cache
from itertools import product
import json
from pathlib import Path


def iterate(update, n, a):
    """Initialized primitive recursion, with the old counter passed to update."""
    value = a
    for w in range(n):
        value = update(value, w)
    return value


@lru_cache(maxsize=None)
def Q(n, a):
    return iterate(lambda _v, w: w, n, a)


def predecessor(n):
    return Q(n, 0)


@lru_cache(maxsize=None)
def C(n, a, b):
    return iterate(lambda _v, _w: b, n, a)


@lru_cache(maxsize=None)
def A(n, a):
    return iterate(lambda v, _w: v + 1, n, a)


def add(a, b):
    return A(b, a)


@lru_cache(maxsize=None)
def d(a, n):
    return iterate(lambda v, _w: predecessor(v), n, a)


def beta(s, t):
    return C(Q(d(s + 1, t), 1), 0, 1)


def leq(a, b):
    return d(a, b) == 0


def swap(pair):
    return (pair[1], pair[0])


def coordinatewise(operation, *pairs):
    return tuple(operation(*(pair[i] for pair in pairs)) for i in (0, 1))


class Check:
    def __init__(self, name, statement):
        self.name = name
        self.statement = statement
        self.passed = 0

    def require(self, condition, inputs):
        if not condition:
            raise AssertionError({"check": self.name, "inputs": inputs})
        self.passed += 1

    def result(self):
        return {"name": self.name, "statement": self.statement,
                "status": "passed", "assertions": self.passed}


def run(bound):
    values = range(bound + 1)
    checks = []

    definitions = Check("recursive_operations", "Generated Q, C, A and d agree with their numerical specifications.")
    for n, a in product(values, repeat=2):
        definitions.require(Q(n, a) == (a if n == 0 else n - 1), [n, a])
        definitions.require(A(n, a) == a + n, [n, a])
        definitions.require(d(a, n) == max(a - n, 0), [n, a])
        definitions.require(C(n, a, a + 1) == (a if n == 0 else a + 1), [n, a])
    checks.append(definitions.result())

    residual = Check("two_equation_residual", "d(y,n)=0 or y=n+d(y,n), including the direct base and successor update.")
    for y, n in product(values, repeat=2):
        r = d(y, n)
        residual.require(r == 0 or y == add(n, r), [y, n])
        residual.require(d(y, n + 1) == predecessor(r), [y, n])
        if r == 0:
            residual.require(d(y, n + 1) == 0, [y, n])
        elif r == 1:
            residual.require(d(y, n + 1) == 0, [y, n])
        else:
            residual.require(y == add(n + 1, predecessor(r)), [y, n])
    for y in values:
        residual.require(y == add(0, d(y, 0)), [y, 0])
    checks.append(residual.result())

    equality = Check("equality_reflection", "beta(s,t)=C(Q(d(Ss,t),1),0,1); zero means equality and one means inequality.")
    for s, t in product(values, repeat=2):
        bit = beta(s, t)
        equality.require(bit in (0, 1), [s, t])
        equality.require((bit == 0) == (s == t), [s, t])
        equality.require((bit == 1) == (s != t), [s, t])
        equality.require((d(s + 1, t) == 1) == (s == t), [s, t])
    checks.append(equality.result())

    boolean = Check("decided_formula_truth_tables", "Zero=true. Tests concern already decided formulas; they do not assert excluded middle for arbitrary intuitionistic formulas.")
    truth_table = []
    for p, q in product((0, 1), repeat=2):
        conjunction = C(p, q, 1)
        disjunction = C(p, 0, q)
        implication = C(p, q, 0)
        negation = C(p, 1, 0)
        boolean.require((conjunction == 0) == (p == 0 and q == 0), [p, q])
        boolean.require((disjunction == 0) == (p == 0 or q == 0), [p, q])
        boolean.require((implication == 0) == (p == 1 or q == 0), [p, q])
        boolean.require((negation == 0) == (p == 1), [p, q])
        truth_table.append({"p": p, "q": q, "and": conjunction,
                            "or": disjunction, "implies": implication,
                            "not_p": negation})
    checks.append(boolean.result())

    arithmetic = Check("balance_and_difference_identities", "d(a,b+c)=d(d(a,b),c); d(a+b,b)=a; a+d(b,a)=b+d(a,b); d(Sa,Sb)=d(a,b); d(Sa,a)=1; a+Sk != a.")
    for a, b, c in product(values, repeat=3):
        arithmetic.require(d(a, add(b, c)) == d(d(a, b), c), [a, b, c])
    for a, b in product(values, repeat=2):
        arithmetic.require(d(add(a, b), b) == a, [a, b])
        arithmetic.require(add(a, d(b, a)) == add(b, d(a, b)), [a, b])
        arithmetic.require(d(a + 1, b + 1) == d(a, b), [a, b])
        arithmetic.require(add(a, b + 1) != a, [a, b])
    for a in values:
        arithmetic.require(d(a + 1, a) == 1, [a])
    checks.append(arithmetic.result())

    order = Check("order_defined_by_difference", "a <= b iff d(a,b)=0: numerical agreement, totality, antisymmetry, and transitivity.")
    for a, b in product(values, repeat=2):
        order.require(leq(a, b) == (a <= b), [a, b])
        order.require(leq(a, b) or leq(b, a), [a, b])
        order.require(not (leq(a, b) and leq(b, a)) or a == b, [a, b])
    for a, b, c in product(values, repeat=3):
        order.require(not (leq(a, b) and leq(b, c)) or leq(a, c), [a, b, c])
    checks.append(order.result())

    product_checks = Check("product_witness_and_swap_samples", "Sample evaluation in the infinite carrier N x N; no bounded box is claimed to satisfy a theory.")
    zero = (0, 0)
    witness = (0, 1)
    succ = lambda n: n + 1
    product_checks.require(witness != zero, list(witness))
    # Every coordinatewise successor has positive first coordinate. This
    # explicit witness has first coordinate zero, so cannot be a successor.
    product_checks.require(witness[0] == 0, list(witness))
    reconstructed = coordinatewise(succ, coordinatewise(predecessor, witness))
    product_checks.require(reconstructed != witness, list(witness))
    product_checks.require(swap(witness) != witness, list(witness))
    product_checks.require(swap(swap(witness)) == witness, list(witness))
    sample_bound = min(bound, 8)
    pairs = list(product(range(sample_bound + 1), repeat=2))
    for pair in pairs:
        product_checks.require(swap(swap(pair)) == pair, list(pair))
        for operation in (succ, predecessor):
            product_checks.require(swap(coordinatewise(operation, pair)) ==
                                   coordinatewise(operation, swap(pair)), list(pair))
        successor = coordinatewise(succ, pair)
        product_checks.require(coordinatewise(succ, coordinatewise(predecessor, successor)) == successor, list(pair))
    for left, right in product(pairs, repeat=2):
        for operation in (add, d, Q, beta):
            product_checks.require(swap(coordinatewise(operation, left, right)) ==
                                   coordinatewise(operation, swap(left), swap(right)), [list(left), list(right)])
    checks.append(product_checks.result())

    return {
        "status": "passed",
        "verification_scope": "Finite numerical diagnostics only; not formal proofs of the report's general theorems.",
        "limitations": [
            "Finite testing does not establish induction or the full bi-interpretability theorem.",
            "Truth tables apply to the already decided quantifier-free cases; they do not validate classical logic for arbitrary formulas.",
            "The infinite product model and preservation for arbitrary primitive recursive operations require the written structural proofs.",
            "Finite product samples are only input samples, not models: the bounded input box is not successor closed."
        ],
        "natural_number_input_range": {"minimum": 0, "maximum": bound},
        "product_coordinate_input_range": {"minimum": 0, "maximum": sample_bound},
        "total_assertions": sum(item["assertions"] for item in checks),
        "checks": checks,
        "decided_formula_truth_table_zero_means_true": truth_table,
        "product_counterexample": {
            "ambient_carrier": "N x N with coordinatewise operations",
            "zero": list(zero),
            "witness": list(witness),
            "successor_of_predecessor": list(reconstructed),
            "swap_of_witness": list(swap(witness)),
            "non_successor_reason": "The first coordinate is zero; each coordinatewise successor has positive first coordinate."
        }
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bound", type=int, default=50,
                        help="Largest input natural number (default: 50).")
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().with_name("results.json"))
    args = parser.parse_args()
    if args.bound < 1:
        parser.error("--bound must be at least 1")
    result = run(args.bound)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "total_assertions": result["total_assertions"],
                      "output": str(args.output), "scope": result["verification_scope"]}, sort_keys=True))


if __name__ == "__main__":
    main()
