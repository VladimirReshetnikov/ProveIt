#!/usr/bin/env python3
"""Rebuild the local-return package; Python standard library only."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent

def run(command, log):
    started=time.monotonic()
    proc=subprocess.run(command,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (ROOT/log).write_text(proc.stdout)
    result={'command':command,'exit_code':proc.returncode,'seconds':round(time.monotonic()-started,3),'log':log}
    if proc.returncode:
        print(proc.stdout[-6000:])
        raise RuntimeError('Command failed: '+repr(command))
    return result

def stats():
    r=json.loads((ROOT/'checks/return_emitter_results.json').read_text())
    values={
      'NumInputs':r['unique_inputs'],
      'NumExhaustive':r['exhaustive_terms_through_size_5'],
      'NumWeights':r['actual_formula_weight_equalities_checked'],
      'NumPadding':r['double_padding_recoveries_checked'],
      'NumProfiles':r['profile_comparisons'],
      'NumStrict':r['envelope_strict_active'],
      'NumTies':r['envelope_equal_both'],
      'NumOptionalWeights':r['optional_both_guards']['formula_weight_checks']}
    (ROOT/'verification/stats.tex').write_text(
       '% Generated from the actual current syntax audit.\n'+
       ''.join('\\newcommand{\\'+key+'}{'+format(value,',')+'}\n' for key,value in values.items()))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--lean',help='Path to a Lean 4.19.0 executable')
    parser.add_argument('--skip-pdf',action='store_true')
    args=parser.parse_args()
    (ROOT/'verification').mkdir(exist_ok=True)
    results={'python':sys.version,'checks':[]}
    for name in ('check_return_emitter','check_return_arithmetic'):
        results['checks'].append(run([sys.executable,'checks/'+name+'.py'],'verification/'+name+'.log'))
    stats()
    formal=ROOT/'formal/ShiftedReturn.lean'
    current_hash=hashlib.sha256(formal.read_bytes()).hexdigest()
    if args.lean:
        lean=str(Path(args.lean).resolve())
        results['lean']=run([lean,'formal/ShiftedReturn.lean'],'formal/lean_output.txt')
        version=subprocess.run([lean,'--version'],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True).stdout.strip()
        log=(ROOT/'formal/lean_output.txt').read_text()
        assert 'sorryAx' not in log
        formal_result={'source':formal.name,'sha256':current_hash,'lean_version':version,
          'exit_code':0,'contains_sorryAx':False,'primary_witness_quantifier_order':'forall target n, exists witness b',
          'primary_axiom_dependencies':['propext'],'classical_axioms_only_in_optional_global_witness':True,
          'formalization_scope':'SCOPE.txt','axiom_audit_output':'lean_output.txt'}
        (ROOT/'formal/verification.json').write_text(json.dumps(formal_result,indent=2)+'\n')
    else:
        recorded=json.loads((ROOT/'formal/verification.json').read_text())
        if recorded['sha256']!=current_hash:
            raise RuntimeError('Lean source changed after its recorded check; rerun with --lean.')
        results['lean']={'status':'not rerun; exact source hash matches the included successful compiler record',
                         'sha256':current_hash}
    if not args.skip_pdf:
        results['latex']=[]
        for passno in (1,2,3):
            results['latex'].append(run(['pdflatex','-interaction=nonstopmode','-halt-on-error','report.tex'],
                                       'verification/latex_pass_'+str(passno)+'.log'))
        log=(ROOT/'report.log').read_text()
        issues={'overfull_boxes':re.findall(r'Overfull \\[hv]box[^\n]*',log),
                'undefined_references':re.findall(r'(?:Reference|Citation)[^\n]*undefined',log),
                'other_reference_warnings':re.findall(r'LaTeX Warning: (?:There were undefined references|Label\(s\) may have changed)[^\n]*',log)}
        results['latex_quality']=issues
        if any(issues.values()):
            print(json.dumps(issues,indent=2))
            raise RuntimeError('PDF build needs layout/reference review.')
    (ROOT/'verification/build_results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({'status':'build passed','checks':len(results['checks']),
                      'pdf_built':not args.skip_pdf,'lean_rerun':bool(args.lean)},indent=2))

if __name__=='__main__':
    main()
