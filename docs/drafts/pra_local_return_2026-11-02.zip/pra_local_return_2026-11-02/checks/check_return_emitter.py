#!/usr/bin/env python3
"""Fresh literal AST audit of the four-case two-call return emitter.

No baseline programs are imported or executed. The current guarded-zero
emitter is reconstructed as actual formula syntax. Other current profiles
are compared by their printed cost formulas (explicitly labeled as such).
All function descriptors are finite immutable term trees, with root-only
Q(Sr,s) normalization. Active substitution never enters a descriptor.
The checks establish finite syntax/accounting facts, not semantic PRA
bi-interpretability; the latter requires the mathematical proof.
"""
from __future__ import annotations
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from collections import Counter
import hashlib
import json
import random

@dataclass(frozen=True, slots=True)
class Term:
    tag: str
    args: tuple['Term', ...] = ()
    name: str = ''
    body: 'Term | None' = None

@dataclass(frozen=True, slots=True)
class Formula:
    tag: str
    args: tuple = ()
    bound: str = ''


def var(name): return Term('var', name=name)
zero=Term('zero')
n,a,b,k,v,w=map(var, ('n','a','b','k','v','w'))
def suc(x): return Term('S',(x,))
def chi(x,y): return Term('chi',(x,y))

def is_rec(t, body):
    return t.tag == 'R' and t.body == body


def nf(t):
    while is_rec(t,w) and t.args[0].tag == 'S':
        t=t.args[0].args[0]
    return t


def rec(body,x,y):
    if not freevars(body) <= {'v','w'}:
        raise ValueError('A descriptor has a captured active variable')
    return Term('R',(x,y),body=nf(body))

def q(x,y): return rec(w,x,y)
def z(x,y): return rec(zero,x,y)

def subst(t, env):
    """Simultaneous active-slot substitution; frozen descriptors unchanged.

    Terms have no binding except the descriptor slots, which are never
    visited. Thus neither a replacement nor one of its variables can be
    captured by those slots. Replacements are inserted as whole trees,
    without recursively substituting within them.
    """
    if t.tag == 'var': return env.get(t.name,t)
    return Term(t.tag,tuple(subst(x,env) for x in t.args),t.name,t.body)

@lru_cache(None)
def freevars(t):
    if t.tag == 'var': return frozenset([t.name])
    return frozenset().union(*(freevars(x) for x in t.args))

@lru_cache(None)
def active(t):
    return 1+sum(active(x) for x in t.args)

@lru_cache(None)
def full(t):
    return 1+sum(full(x) for x in t.args)+(full(t.body) if isinstance(t,Term) and t.tag=='R' else 0)

@lru_cache(None)
def occ(t,name):
    return int(isinstance(t,Term) and t.tag=='var' and t.name==name)+sum(occ(x,name) for x in t.args)


def eq(x,y): return Formula('=',(x,y))
def conj(x,y): return Formula('and',(x,y))
def disj(x,y): return Formula('or',(x,y))
def implies(x,y): return Formula('implies',(x,y))
def forall(name,f): return Formula('forall',(f,),name)
def exists(name,f): return Formula('exists',(f,),name)
falsity=Formula('false')

def close_an(f): return forall('a',forall('n',f))
def r_of(u,x,y): return rec(subst(u,{'n':v,'a':w}),x,y)

def B(u):
    return conj(eq(r_of(u,zero,a),a),
                eq(r_of(u,suc(n),a),subst(u,{'n':r_of(u,n,a),'a':n})))

def D(u):
    return conj(eq(r_of(u,zero,a),a),
                eq(r_of(u,suc(n),a),r_of(u,n,subst(u,{'n':a,'a':zero}))))

sigma=implies(eq(zero,suc(zero)),falsity)
K=conj(eq(chi(a,a),suc(zero)), disj(eq(a,n),eq(chi(a,n),zero)))
seed=q(suc(n),a)


def old_guard(t):
    return is_rec(t,zero) and t.args[0]==chi(n,zero)


def selected_tail(t,allow_rooted=False):
    """Recognize literally Q(Z(chi(a,0),S tail),n).

    The optional variant also admits the old outer zero-state guard.
    """
    if allow_rooted and old_guard(t):
        t=t.args[1]
    if not is_rec(t,w) or t.args[1]!=n: return None
    zz=t.args[0]
    if not is_rec(zz,zero) or zz.args[0]!=chi(a,zero): return None
    ss=zz.args[1]
    if ss.tag!='S': return None
    return ss.args[0]


def guard(t):
    return q(z(chi(a,zero),suc(t)),n)


def rooted_guard(t):
    return z(chi(n,zero),guard(t))


def return_formula(u):
    probe=r_of(u,suc(suc(b)),a)
    pick=q(z(chi(probe,a),suc(b)),n)
    return forall('a',forall('n',exists('b',eq(r_of(u,suc(pick),a),a))))


def new_emit(u,allow_rooted=False):
    i,j=occ(u,'n'),occ(u,'a')
    if u==seed: return 'seed',close_an(conj(sigma,K))
    if i>0 and j==0: return 'autonomous',close_an(D(u))
    if selected_tail(u,allow_rooted) is not None: return 'return',return_formula(u)
    return 'left',close_an(B(u))


def old_emit(u):
    """Actual guarded-zero four-case specification, rebuilt independently."""
    i,j=occ(u,'n'),occ(u,'a')
    if u==seed: return 'seed',close_an(conj(B(u),conj(sigma,K)))
    if i>0 and j==0: return 'autonomous',close_an(D(u))
    if j>0 and old_guard(u):
        hypothesis=forall('k',implies(eq(subst(u,{'n':k}),zero),eq(subst(u,{'n':suc(k)}),zero)))
        propagation=implies(hypothesis,eq(u,zero))
        return 'guarded',close_an(conj(B(u),propagation))
    return 'left',close_an(B(u))


def counts(u):
    return active(u),occ(u,'n'),occ(u,'a'),full(u),full(nf(u))


def new_closed_counts(u,branch):
    m,i,j,W,V=counts(u)
    if branch=='seed': return 25,25
    if branch=='autonomous': return 15+m,15+W+3*V
    if branch=='return': return 20,22+2*W
    return 13+m+2*i,13+W+2*i+(2+i)*V


def old_closed_counts(u,branch):
    m,i,j,W,V=counts(u)
    if branch=='seed': return 43,47
    if branch=='autonomous': return 15+m,15+W+3*V
    if branch=='guarded': return 23+4*m+3*i,23+(6+i)*W+3*i
    return 13+m+2*i,13+W+2*i+(2+i)*V


def sparse_cost(u,full_selector):
    m,i,j,W,V=counts(u)
    if u==zero:return (18,18)
    if i==0:return (13+m,13+W+2*V)
    if j==0:return (15+m,15+W+3*V)
    if (W if full_selector else m)<=10:
        return 18+5*m+3*i,18+5*W+3*i+(2+i)*V
    return 28+4*m+3*i,28+4*W+3*i+(2+i)*V


def contains_identity_rec(t):
    if isinstance(t,Term) and t.tag=='R':
        if t.body==v or contains_identity_rec(t.body): return True
    return any(contains_identity_rec(x) for x in t.args)


def other_profiles(u):
    """Printed formulas ONLY, not reconstructed ASTs of these baselines.

    Factored fixed costs are deliberately omitted. Optional smaller
    variants are included; independent coordinate minima strengthen the
    benchmark even where no single emitter realizes both choices.
    The unit-descent profile has a broader immutable-parameter grammar.
    Orbit has logical equality conditionals. These are matched numeric
    profiles in the common-extension counting convention, not a claim
    that all signatures are literally identical.
    """
    m,i,j,W,V=counts(u)
    raw=(19+4*m+3*i,19+(6+i)*W+3*i)
    ret=(38+m+2*i,38+(6+i)*W+2*i)
    profiles={
        'sparse_mask_active_threshold':sparse_cost(u,False),
        'sparse_mask_full_threshold':sparse_cost(u,True),
        'orbit_factored':(29+2*m+2*i,29+(6+i)*W+2*i),
        'orbit_trajectory_rewrite':(33+m+2*i,33+(6+i)*W+2*i),
        'orbit_shifted_factored':(34+3*m+2*i+j,34+(7+i)*W+2*i+j),
        'orbit_fused':(46+2*m+2*i,46+(6+i)*W+2*i),
        'unit_descent_generated_k0':(19+3*m+3*i,19+(5+i)*W+3*i),
        'unit_descent_scalar_constancy':((38,40) if u==zero else (18+5*m+3*i,18+(7+i)*W+3*i)),
        'unit_scalar_optional_state_independent_pruning':((13+m,13+3*W) if u!=zero and i==0 else ((38,40) if u==zero else (18+5*m+3*i,18+(7+i)*W+3*i))),
        'witness_constancy_raw':raw,
        'witness_constancy_conditional':(26+4*m+3*i,26+(6+i)*W+3*i),
        'witness_return':ret,
        'witness_adaptive_actual':(raw if 3*m+i<=19 else ret),
        'witness_stronger_coordinate_min':tuple(min(raw[c],ret[c]) for c in (0,1)),
    }
    # Its optional projection-alias language contains no actual R_v;
    # compare only raw inputs in that literal shared sublanguage.
    if not contains_identity_rec(u):
        profiles['witness_projection_alias_eligible_only']=(25,25) if u==n else raw
    return profiles


def double_padding(u):
    return q(suc(q(suc(u),a)),a)


def term_text(t,descriptors=False):
    if t.tag=='var':return t.name
    if t.tag=='zero':return '0'
    if t.tag=='S':return 'S('+term_text(t.args[0],descriptors)+')'
    if t.tag=='chi':return 'chi('+','.join(term_text(x,descriptors) for x in t.args)+')'
    if is_rec(t,w):symbol='Q'
    elif is_rec(t,zero):symbol='Z'
    elif descriptors:symbol='R['+term_text(t.body,True)+']'
    else:symbol='R['+hashlib.sha256(repr(t.body).encode()).hexdigest()[:8]+']'
    return symbol+'('+','.join(term_text(x,descriptors) for x in t.args)+')'


def validate(t):
    if isinstance(t,Term):
        if t.tag=='R':
            assert t.body is not None and nf(t.body)==t.body
            assert freevars(t.body)<={'v','w'}
            validate(t.body)
        else:assert t.body is None
    for x in t.args:validate(x)


def quantify(f):
    if isinstance(f,Term):return (0,0)
    children=[quantify(x) for x in f.args]
    adds=int(f.tag in ('forall','exists'))
    return adds+sum(x[0] for x in children),adds+max([x[1] for x in children],default=0)


def descriptor_pool():
    candidates=[zero,v,w,suc(v),suc(w),chi(v,w),q(v,w),z(v,w),
                rec(suc(v),v,w),rec(chi(v,w),suc(v),w),
                rec(rec(suc(v),v,w),v,w),
                rec(chi(rec(suc(v),v,w),q(v,w)),v,w)]
    return tuple(dict.fromkeys(nf(x) for x in candidates))


def enumerate_small(descriptors,limit=5):
    by_size={1:[zero,n,a]}
    for size in range(2,limit+1):
        layer=[suc(x) for x in by_size[size-1]]
        for leftsize in range(1,size-1):
            rightsize=size-1-leftsize
            for x in by_size[leftsize]:
                for y in by_size[rightsize]:
                    layer.append(chi(x,y))
                    layer.extend(rec(d,x,y) for d in descriptors)
        by_size[size]=list(dict.fromkeys(layer))
    return [t for size in by_size for t in by_size[size]]


def random_term(rng,descriptors,depth):
    if depth==0 or rng.random()<0.24:return rng.choice([zero,n,a])
    c=rng.randrange(3)
    if c==0:return suc(random_term(rng,descriptors,depth-1))
    x=random_term(rng,descriptors,depth-1)
    y=random_term(rng,descriptors,depth-1)
    return chi(x,y) if c==1 else rec(rng.choice(descriptors),x,y)


def main():
    descriptors=descriptor_pool()
    small=enumerate_small(descriptors[:6],5)
    rng=random.Random(20261102)
    randoms=[random_term(rng,descriptors,6) for _ in range(800)]
    selected=[guard(t) for t in small[:350]+randoms[:100]]
    rooted_selected=[rooted_guard(t) for t in small[:350]+randoms[:100]]
    old_guards=[z(chi(n,zero),t) for t in small[:250]+randoms[100:200]]
    # Include literal seed, deep root aliases, nested frozen descriptors,
    # and every index alias used in the recovery proof.
    designated=[zero,a,n,seed,double_padding(seed),guard(zero),guard(n),guard(a),
                q(suc(n),zero),q(suc(zero),n),
                rec(descriptors[-1],n,a),guard(rec(descriptors[-1],n,a))]
    originals=list(dict.fromkeys(small+randoms+selected+rooted_selected+old_guards+designated))
    inputs=list(dict.fromkeys(originals+[double_padding(t) for t in originals[:600]]))
    branches=Counter(); oldbranches=Counter(); comparison=Counter()
    strict_active=0;strict_full=0;equal_both=0
    optional_branches=Counter();optional_strict_active=0;optional_strict_full=0
    optional_actual_checks=0
    minima={}
    for u in inputs:
        assert freevars(u)<={'n','a'}
        validate(u)
        assert nf(nf(u))==nf(u)
        branch,f=new_emit(u)
        oldbranch,old=old_emit(u)
        actual=(active(f),full(f))
        oldactual=(active(old),full(old))
        assert actual==new_closed_counts(u,branch),(term_text(u),actual,new_closed_counts(u,branch))
        assert oldactual==old_closed_counts(u,oldbranch)
        assert all(actual[c]<=oldactual[c] for c in (0,1))
        if oldbranch in ('seed','guarded') or branch=='return':
            assert all(actual[c]<oldactual[c] for c in (0,1))
        else:assert actual==oldactual
        assert quantify(f)==((3,3) if branch=='return' else (2,2))
        if branch=='return':
            assert oldbranch in ('left','guarded')
            m,i,j,W,V=counts(u)
            assert m>=8 and i>=1 and j>=1 and W==V and W>=10
            assert f.tag=='forall' and f.bound=='a'
            assert f.args[0].tag=='forall' and f.args[0].bound=='n'
            assert f.args[0].args[0].tag=='exists' and f.args[0].args[0].bound=='b'
        pad=double_padding(u)
        padbranch,padformula=new_emit(pad)
        assert padbranch=='left'
        assert nf(pad)==nf(u)
        assert r_of(pad,n,a).body==r_of(u,n,a).body
        # Frozen descriptors do not change under active renaming, even
        # when replacement names coincide with formal descriptor slots.
        ru=r_of(u,n,a)
        assert subst(ru,{'n':w,'a':v}).body==ru.body
        assert subst(n,{'n':a,'a':zero})==a
        # Each additional baseline is a published profile, as declared.
        profiles=other_profiles(u)
        profiles['guarded_zero_literal_ast']=oldactual
        envelope=tuple(min(cost[c] for cost in profiles.values()) for c in (0,1))
        assert all(actual[c]<=envelope[c] for c in (0,1)),(term_text(u),actual,envelope,profiles)
        if oldbranch in ('seed','guarded') or branch=='return':
            assert all(actual[c]<envelope[c] for c in (0,1)),(term_text(u),actual,envelope)
        optbranch,optformula=new_emit(u,allow_rooted=True)
        optactual=(active(optformula),full(optformula))
        assert optactual==new_closed_counts(u,optbranch)
        assert all(optactual[c]<=envelope[c] for c in (0,1))
        assert all(optactual[c]<=actual[c] for c in (0,1))
        if oldbranch in ('seed','guarded') or optbranch=='return':
            assert all(optactual[c]<envelope[c] for c in (0,1))
        if optactual[0]<envelope[0]:optional_strict_active+=1
        if optactual[1]<envelope[1]:optional_strict_full+=1
        assert new_emit(pad,allow_rooted=True)[0]=='left'
        optional_branches[optbranch]+=1
        optional_actual_checks+=2
        if actual[0]<envelope[0]:strict_active+=1
        if actual[1]<envelope[1]:strict_full+=1
        if actual==envelope:equal_both+=1
        for name,cost in profiles.items():
            for c,label in enumerate(('active','full')):
                key=name+':'+label
                comparison[key]+=1
                minima[key]=min(minima.get(key,cost[c]-actual[c]),cost[c]-actual[c])
        branches[branch]+=1;oldbranches[oldbranch]+=1
    example_terms=[zero,a,n,seed,guard(zero),guard(n),guard(a),rooted_guard(zero),
                   z(chi(n,zero),a),guard(rec(descriptors[-1],n,a)),
                   double_padding(guard(zero))]
    examples=[]
    for u in example_terms:
        br,f=new_emit(u);obr,of=old_emit(u)
        profiles=other_profiles(u);profiles['guarded_zero_literal_ast']=(active(of),full(of))
        examples.append({'term':term_text(u,True),'branch':br,'old_branch':obr,
            'input':dict(zip(('m','i','j','W','V'),counts(u))),
            'new':{'active':active(f),'full':full(f)},
            'optional_both_guards':dict(zip(('active','full'),(active(new_emit(u,True)[1]),full(new_emit(u,True)[1])))),
            'old_guarded_zero':{'active':active(of),'full':full(of)},
            'envelope':{'active':min(c[0] for c in profiles.values()),'full':min(c[1] for c in profiles.values())}})
    result={
        'status':'all assertions passed',
        'scope':'Finite syntax/accounting audit, not a semantic equivalence proof.',
        'baseline_commit':'fc604391af372504e9163797c0722069ae49466e',
        'baseline_ast':'Current guarded-zero emitter independently reconstructed from AXIOMS.txt.',
        'other_baselines':'Printed cost profiles only; fixed costs omitted. Conditional and immutable-parameter grammars explicitly differ. Optional profiles included; projection-alias variant is evaluated only where no R_v occurs, including inside frozen descriptors.',
        'exhaustive_terms_through_size_5':len(small),
        'random_requests':len(randoms),'unique_inputs':len(inputs),
        'new_branches':dict(branches),'guarded_zero_branches':dict(oldbranches),
        'actual_formula_weight_equalities_checked':4*len(inputs),
        'double_padding_recoveries_checked':len(inputs),
        'quantifier_profiles_checked':len(inputs),
        'envelope_strict_active':strict_active,'envelope_strict_full':strict_full,
        'envelope_equal_both':equal_both,
        'pointwise_claim':'Nonincrease relative to the coordinatewise envelope; strict at the old seed, every old j>0 guarded branch, and every newly selected unrooted guard. Other computation cases can tie.',
        'selected_pattern':'Q(Z(chi(a,0),S tail),n)',
        'selected_quantifier_order':'forall a forall n exists b',
        'optional_both_guards':{'branches':dict(optional_branches),'formula_weight_checks':optional_actual_checks,'envelope_strict_active':optional_strict_active,'envelope_strict_full':optional_strict_full,'pointwise_no_larger_than_primary':True},
        'minimum_savings_by_profile_and_metric':minima,
        'profile_comparisons':sum(comparison.values()),
        'examples':examples,
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    out=Path(__file__).with_name('return_emitter_results.json')
    out.write_text(json.dumps(result,indent=2)+'\n')
    ex=Path(__file__).with_name('return_emitter_examples.txt')
    ex.write_text('\n\n'.join(e['term']+'\n'+json.dumps({k:v for k,v in e.items() if k!='term'},sort_keys=True) for e in examples)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('examples','minimum_savings_by_profile_and_metric')},indent=2))

if __name__=='__main__':main()
