#!/usr/bin/env python3
"""Small arithmetic diagnostics for the pointwise-return construction.

Standard library only. These finite checks on natural numbers inspect
selector orientation, S/SS shifts, the constructive boundary witness,
latch reflection, and triangular pairing. They do not establish the
arbitrary-carrier equivalence theorem or replace its written proof.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json


def S(x): return x+1
def Q(n,a): return a if n==0 else n-1
def Z(n,a): return a if n==0 else 0
def chi(x,y): return int(x==y)
def pred(x): return Q(x,0)

def C(r,b,c):
    """The zero-selector: first branch on r=0, second on a successor."""
    return Q(Z(r,S(b)),c)

def choose_equal(x,y,b,c):
    """Return b on equality x=y, c otherwise, using true-on-equality chi."""
    return Q(Z(chi(x,y),S(c)),b)

def H(t,v,w):
    return Q(Z(chi(w,0),S(t(v,w))),v)

def rooted_H(t,v,w):
    return Z(chi(v,0),H(t,v,w))

def trajectory(t,initial,last_index,rooted=False):
    values=[initial]
    body=rooted_H if rooted else H
    for counter in range(last_index):
        values.append(body(t,values[-1],counter))
    return values

def boundary_witnesses(F,initial,last_target):
    """c(0)=0; c(Sn)=n when F(n)=initial, and c(n) otherwise."""
    values=[0]
    for target in range(last_target):
        values.append(choose_equal(F[target],initial,target,values[-1]))
    return values

def q_index(R,b,n,a):
    """Literal selector in the axiom: probe R(SSb,a), query R(Sq,a)."""
    return Q(Z(chi(R[S(S(b))],a),S(b)),n)


def main():
    checks=Counter()
    for r in range(9):
        for x in range(8):
            assert Q(0,x)==x and Q(S(r),x)==r
            assert Z(0,x)==x and Z(S(r),x)==0
            checks['Q_Z_equations']+=4
            for y in range(8):
                assert C(r,x,y)==(x if r==0 else y)
                checks['zero_selector']+=1
                assert choose_equal(r,x,x,y)==(x if r==x else y)
                checks['equality_selector']+=1
    for x in range(12):
        for y in range(12):
            assert chi(x,x)==1
            assert (x==y) or chi(x,y)==0
            assert (chi(x,y)==1)==(x==y)
            assert (chi(x,y)==0)==(x!=y)
            checks['native_equality_bit']+=4

    tails={
        'all_return':lambda v,w:v,
        'immediate_exit_to_zero':lambda v,w:0,
        'late_exit_at_17':lambda v,w:v if w<17 else 0,
        'growing_state':lambda v,w:S(v),
        'oscillating_state':lambda v,w:1 if v==0 else 0,
        'counter_parity':lambda v,w:w%2,
        'counter_three_cycle':lambda v,w:w%3,
        'very_late_exit_at_1000000':lambda v,w:v if w<1_000_000 else 0,
    }
    for tail in tails.values():
        for v in range(8):
            assert H(tail,v,0)==v
            assert rooted_H(tail,v,0)==v
            checks['guard_zero_counter_identity']+=2
            for w in range(9):
                assert H(tail,v,w)==(v if w==0 else tail(v,w))
                assert rooted_H(tail,v,w)==(0 if v==0 else H(tail,v,w))
                assert rooted_H(tail,0,w)==0
                checks['guard_branch_orientation']+=3

    # Exact reflection for the proof's specialized latch. The predicates
    # include nonmonotone cases: no induction hypothesis is used here.
    predicates={
        'true':lambda n,a:True,
        'false':lambda n,a:False,
        'equal_parameter':lambda n,a:n==a,
        'below_parameter':lambda n,a:n<a,
        'even_sum':lambda n,a:(n+a)%2==0,
        'successor_coverage':lambda n,a:n==0 or n==S(pred(n)),
    }
    for P in predicates.values():
        def latch(v,w,P=P):
            truth_bit=0 if P(w,pred(v)) else 1
            return Z(truth_bit,v)
        for parameter in range(7):
            initial=S(parameter)
            for v in range(10):
                for w in range(9):
                    expected=(v==initial and (w==0 or P(w,parameter)))
                    assert (H(latch,v,w)==initial)==expected
                    assert (rooted_H(latch,v,w)==initial)==expected
                    assert H(latch,v,w)==rooted_H(latch,v,w)
                    checks['latch_reflection']+=3

    last_target=64
    scenario_results=[]
    wrong_shift_counterexample=None
    wrong_boundary_update_counterexample=None
    for name,tail in tails.items():
        for rooted in (False,True):
            for initial in (0,1,2,5):
                # R needs index n+2 to inspect F(Sb)=R(SSb), including
                # the special target zero whose boundary witness is zero.
                R=trajectory(tail,initial,last_target+2,rooted)
                F=R[1:]
                assert F[0]==initial
                witnesses=boundary_witnesses(F,initial,last_target)
                exits=0
                nonzero_witnesses=0
                for target in range(last_target+1):
                    witness=witnesses[target]
                    assert witness <= max(target-1,0)
                    assert F[witness]==initial
                    assert F[target]==initial or F[S(witness)]!=initial
                    pick=q_index(R,witness,target,initial)
                    assert pick==(target if F[S(witness)]==initial else witness)
                    assert R[S(pick)]==initial
                    checks['boundary_invariant_conjuncts']+=2
                    checks['witness_bound']+=1
                    checks['literal_return_selector_and_equation']+=2
                    exits+=int(F[S(witness)]!=initial)
                    nonzero_witnesses+=int(witness!=0)
                    if wrong_shift_counterexample is None:
                        wrong_pick=Q(Z(chi(R[S(witness)],initial),S(witness)),target)
                        if R[S(wrong_pick)]!=initial:
                            wrong_shift_counterexample={
                                'scenario':name,'rooted':rooted,'initial':initial,
                                'target':target,'witness':witness,
                                'wrong_probe':'R(Sb,a) instead of R(SSb,a)',
                                'wrong_query_value':R[S(wrong_pick)],
                                'correct_query_value':R[S(pick)],
                            }
                # A concrete mutation diagnostic: updating c(Sn) to Sn
                # instead of n can store a nonreturning state as witness.
                wrong=[0]
                for target in range(last_target):
                    wrong.append(S(target) if F[target]==initial else wrong[-1])
                if wrong_boundary_update_counterexample is None:
                    for target,witness in enumerate(wrong):
                        if F[witness]!=initial:
                            wrong_boundary_update_counterexample={
                                'scenario':name,'rooted':rooted,'initial':initial,
                                'target':target,'wrong_witness':witness,
                                'wrong_update':'c(Sn)=Sn on return instead of c(Sn)=n',
                                'failed_value':F[witness],
                            }
                            break
                scenario_results.append({
                    'tail':name,'rooted':rooted,'initial':initial,
                    'targets_checked':last_target+1,
                    'targets_with_exit_witness':exits,
                    'targets_with_nonzero_witness':nonzero_witnesses,
                })
    assert wrong_shift_counterexample is not None
    assert wrong_boundary_update_counterexample is not None

    # No million-step run: the PR threshold latch has a simple explicit
    # numerical form, checked against its simulated short initial segment.
    threshold=1_000_000
    initial=1
    target=32
    late_tail=tails['very_late_exit_at_1000000']
    R=trajectory(late_tail,initial,last_target+2)
    F=R[1:]
    closed_F=lambda n:initial if n<threshold else 0
    assert all(F[n]==closed_F(n) for n in range(last_target+2))
    all_return_prefix=trajectory(tails['all_return'],initial,last_target+2)[1:]
    assert F==all_return_prefix
    local_witness=boundary_witnesses(F,initial,target)[target]
    assert local_witness==target-1
    def closed_query(b,n):
        pick=Q(Z(chi(closed_F(S(b)),initial),S(b)),n)
        return closed_F(pick)
    assert closed_query(local_witness,target)==initial
    assert closed_query(local_witness,threshold)!=initial
    global_boundary=threshold-1
    for query in (0,1,target,threshold-1,threshold,threshold+1,2*threshold):
        assert closed_query(global_boundary,query)==initial
        checks['explicit_late_boundary_sample']+=1
    local_global_example={
        'threshold':threshold,'local_target':target,'local_witness':local_witness,
        'short_simulation_last_F_index':last_target+1,
        'same_observed_prefix_as_all_return':True,
        'same_witness_fails_at_target':threshold,
        'explicit_global_exit_index':global_boundary,
        'scope':'This known PR threshold sequence illustrates why target-dependent witnesses need not locate a distant exit. It is not a general computability theorem.',
    }

    # Triangular pairing from the paper, using the actual interval-counter
    # recurrence rather than a floating-point square-root formula.
    grid=14
    T=[0]
    for j in range(2*grid+2):
        T.append(T[-1]+S(j))
    largest=T[2*grid]+grid
    interval=[0]
    for n in range(largest):
        old=interval[-1]
        interval.append(old+chi(S(n),T[S(old)]))
    for n,b in enumerate(interval):
        assert T[b]<=n<T[S(b)]
        checks['triangular_interval_boundaries']+=1
    def difference(x,y):return max(x-y,0)
    def pair(x,y):return T[x+y]+y
    def right(z):return difference(z,T[interval[z]])
    def left(z):return difference(interval[z],right(z))
    for x in range(grid+1):
        for y in range(grid+1):
            code=pair(x,y)
            assert left(code)==x
            assert right(code)==y
            checks['pair_retraction_identities']+=2
    for b in range(grid+1):
        for j in range(b+1):
            assert interval[T[b]+j]==b
            checks['triangular_block_identity']+=1

    result={
        'status':'all arithmetic diagnostics passed',
        'scope':'Finite natural-number diagnostics only. No claim of formal proof, arbitrary-carrier validity, or full PRA bi-interpretation verification.',
        'checks':dict(checks),'total_checks_in_counted_families':sum(checks.values()),
        'trajectories_checked':len(scenario_results),
        'targets_per_trajectory':last_target+1,
        'tail_names':list(tails),
        'predicate_names':list(predicates),
        'pair_grid':{'minimum_coordinate':0,'maximum_coordinate':grid,'pairs':(grid+1)**2},
        'wrong_shift_detected':wrong_shift_counterexample,
        'wrong_boundary_update_detected':wrong_boundary_update_counterexample,
        'local_versus_global_witness_example':local_global_example,
        'scenarios':scenario_results,
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    path=Path(__file__).with_name('return_arithmetic_results.json')
    path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='scenarios'},indent=2))

if __name__=='__main__':main()
