import Std

/-!
# Shifted return witnesses: an arbitrary-carrier proof kernel

This file proves the exact logical compression and the induction bootstrap.
The primary witness is target-dependent: forall n, exists b. Its soundness
is constructive via a primitive-recursive boundary witness. The earlier
global exists b, forall n variant is retained only as a classical supplement.
No induction principle, coverage axiom, or natural-number carrier is assumed
in the bootstrap. Reverse soundness has precisely stated induction premises.
The finite syntax compiler, pairing construction, and full bi-interpretation
are outside this kernel's scope.
-/

namespace ShiftedReturn

universe u

def ReturnClosed {A : Type u} (s : A → A) (F : A → A) (a : A) : Prop :=
  ∀ k, F k = a → F (s k) = a

def ReturnPrinciple {A : Type u} (s : A → A) (F : A → A) (a : A) : Prop :=
  ReturnClosed s F a → ∀ n, F n = a

/-- Optional global witness; the primary arithmetic witness is defined below. -/
def ConditionalWitness {A : Type u} [DecidableEq A]
    (s : A → A) (F : A → A) (a : A) : Prop :=
  ∃ b, ∀ n, F (if F (s b) = a then n else b) = a

theorem conditionalWitness_implies_returnPrinciple
    {A : Type u} [DecidableEq A] (s : A → A) (F : A → A) (a : A)
    (hw : ConditionalWitness s F a) : ReturnPrinciple s F a := by
  rcases hw with ⟨b, hb⟩
  intro hp n
  have hfb : F b = a := by simpa only [ite_self] using hb b
  have hfsb : F (s b) = a := hp b hfb
  simpa only [if_pos hfsb] using hb n

theorem returnPrinciple_implies_conditionalWitness
    {A : Type u} [DecidableEq A] (s : A → A) (F : A → A) (a : A)
    (hi : ReturnPrinciple s F a) : ConditionalWitness s F a := by
  classical
  by_cases hall : ∀ n, F n = a
  · exact ⟨a, fun n => hall _⟩
  · have hbad : ∃ b, F b = a ∧ F (s b) ≠ a := by
      apply Classical.byContradiction
      intro hn
      apply hall
      apply hi
      intro b hb
      apply Classical.byContradiction
      intro hs
      exact hn ⟨b, hb, hs⟩
    rcases hbad with ⟨b, hb, hs⟩
    refine ⟨b, ?_⟩
    intro n
    simpa only [if_neg hs] using hb

theorem conditionalWitness_iff_returnPrinciple
    {A : Type u} [DecidableEq A] (s : A → A) (F : A → A) (a : A) :
    ConditionalWitness s F a ↔ ReturnPrinciple s F a :=
  ⟨conditionalWitness_implies_returnPrinciple s F a,
    returnPrinciple_implies_conditionalWitness s F a⟩

/-- The actual finite arithmetic computations and bit calibration used below. -/
structure Kernel (A : Type u) where
  zero : A
  succ : A → A
  Q : A → A → A
  Z : A → A → A
  chi : A → A → A
  separated : zero ≠ succ zero
  q_zero : ∀ a, Q zero a = a
  q_succ : ∀ n a, Q (succ n) a = n
  z_zero : ∀ a, Z zero a = a
  z_succ : ∀ n a, Z (succ n) a = zero
  chi_diag : ∀ a, chi a a = succ zero
  chi_off : ∀ a b, a = b ∨ chi a b = zero

namespace Kernel

variable {A : Type u} (K : Kernel A)

def pred (x : A) : A := K.Q x K.zero

theorem pred_succ (x : A) : K.pred (K.succ x) = x := K.q_succ x K.zero

theorem succ_injective : ∀ x y, K.succ x = K.succ y → x = y := by
  intro x y h
  have hp := congrArg (fun z => K.Q z K.zero) h
  simpa only [K.q_succ] using hp

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro hs
  have hx : x = K.zero := by
    have hp := congrArg (fun z => K.Q z K.zero) hs
    simpa only [K.q_succ, K.q_zero] using hp
  apply K.separated
  exact hs.symm.trans (congrArg K.succ hx)

theorem chi_of_ne (x y : A) (h : x ≠ y) : K.chi x y = K.zero := by
  rcases K.chi_off x y with he | hc
  · exact False.elim (h he)
  · exact hc

include K in
theorem eq_or_ne (x y : A) : x = y ∨ x ≠ y := by
  rcases K.chi_off x y with he | hc
  · exact Or.inl he
  · apply Or.inr
    intro he
    subst x
    apply K.separated
    exact hc.symm.trans (K.chi_diag y)

/-- Returns n when x=a and b otherwise; this is an ordinary arithmetic term. -/
def choose (x a n b : A) : A :=
  K.Q (K.Z (K.chi x a) (K.succ b)) n

theorem choose_of_eq (x a n b : A) (he : x = a) :
    K.choose x a n b = n := by
  subst x
  simp only [choose, K.chi_diag, K.z_succ, K.q_zero]

theorem choose_of_ne (x a n b : A) (he : x ≠ a) :
    K.choose x a n b = b := by
  simp only [choose, K.chi_of_ne x a he, K.z_zero, K.q_succ]

theorem choose_same (x a b : A) : K.choose x a b b = b := by
  rcases K.chi_off x a with he | hc
  · exact K.choose_of_eq x a b b he
  · simp only [choose, hc, K.z_zero, K.q_succ]

def GlobalEncodedWitness (F : A → A) (a : A) : Prop :=
  ∃ b, ∀ n, F (K.choose (F (K.succ b)) a n b) = a

theorem globalEncodedWitness_implies_returnPrinciple (F : A → A) (a : A)
    (hw : K.GlobalEncodedWitness F a) : ReturnPrinciple K.succ F a := by
  rcases hw with ⟨b, hb⟩
  intro hp n
  have hfb : F b = a := by
    simpa only [K.choose_same] using hb b
  have hs : F (K.succ b) = a := hp b hfb
  simpa only [K.choose_of_eq _ _ _ _ hs] using hb n

theorem returnPrinciple_implies_globalEncodedWitness (F : A → A) (a : A)
    (hi : ReturnPrinciple K.succ F a) : K.GlobalEncodedWitness F a := by
  classical
  by_cases hall : ∀ n, F n = a
  · exact ⟨a, fun n => hall _⟩
  · have hbad : ∃ b, F b = a ∧ F (K.succ b) ≠ a := by
      apply Classical.byContradiction
      intro hn
      apply hall
      apply hi
      intro b hb
      apply Classical.byContradiction
      intro hs
      exact hn ⟨b, hb, hs⟩
    rcases hbad with ⟨b, hb, hs⟩
    refine ⟨b, ?_⟩
    intro n
    simpa only [K.choose_of_ne _ _ _ _ hs] using hb

theorem globalEncodedWitness_iff_returnPrinciple (F : A → A) (a : A) :
    K.GlobalEncodedWitness F a ↔ ReturnPrinciple K.succ F a :=
  ⟨K.globalEncodedWitness_implies_returnPrinciple F a,
    K.returnPrinciple_implies_globalEncodedWitness F a⟩

/-- The primary witness: the witness may depend on the requested target n. -/
def EncodedWitness (F : A → A) (a : A) : Prop :=
  ∀ n, ∃ b, F (K.choose (F (K.succ b)) a n b) = a

theorem encodedWitness_implies_returnPrinciple (F : A → A) (a : A)
    (hw : K.EncodedWitness F a) : ReturnPrinciple K.succ F a := by
  intro hp n
  rcases hw n with ⟨b, hb⟩
  rcases K.chi_off (F (K.succ b)) a with hs | hc
  · simpa only [K.choose_of_eq _ _ _ _ hs] using hb
  · have hfb : F b = a := by
      simpa only [choose, hc, K.z_zero, K.q_succ] using hb
    have hs : F (K.succ b) = a := hp b hfb
    simpa only [K.choose_of_eq _ _ _ _ hs] using hb

/-- The exact root form in the candidate specification. -/
def rooted (t : A → A → A) (v w : A) : A :=
  K.Q (K.Z (K.chi w K.zero) (K.succ (t v w))) v

theorem rooted_zero_right (t : A → A → A) (v : A) :
    K.rooted t v K.zero = v := by
  simp only [rooted, K.chi_diag, K.z_succ, K.q_zero]

/-- A truth term retaining its original numerical parameter in the state. -/
def latch (b : A → A → A) (v w : A) : A :=
  K.Z (b w (K.pred v)) v

theorem latch_zero_left
    (b : A → A → A)
    (brange : ∀ n a, b n a = K.zero ∨ b n a = K.succ K.zero)
    (w : A) : K.latch b K.zero w = K.zero := by
  rcases brange w (K.pred K.zero) with hb | hb
  · simp only [latch, hb, K.z_zero]
  · simp only [latch, hb, K.z_succ]

theorem rooted_latch_zero_left
    (b : A → A → A)
    (brange : ∀ n a, b n a = K.zero ∨ b n a = K.succ K.zero)
    (w : A) : K.rooted (K.latch b) K.zero w = K.zero := by
  rcases K.chi_off w K.zero with hw | cw
  · simp only [hw, K.rooted_zero_right]
  · simp only [rooted, cw, K.z_zero, K.q_succ, K.latch_zero_left b brange]

/-- The former outer zero guard is redundant for the actual latch body. -/
theorem outer_guard_redundant_for_latch
    (b : A → A → A)
    (brange : ∀ n a, b n a = K.zero ∨ b n a = K.succ K.zero)
    (v w : A) :
    K.Z (K.chi v K.zero) (K.rooted (K.latch b) v w) =
      K.rooted (K.latch b) v w := by
  rcases K.chi_off v K.zero with hv | cv
  · simp only [hv, K.chi_diag, K.z_succ, K.rooted_latch_zero_left b brange]
  · simp only [cv, K.z_zero]

theorem latch_reflection
    (P : A → A → Prop) (b : A → A → A)
    (brange : ∀ n a, b n a = K.zero ∨ b n a = K.succ K.zero)
    (btruth : ∀ n a, b n a = K.zero ↔ P n a)
    (v w a : A) :
    K.latch b v w = K.succ a ↔ v = K.succ a ∧ P w a := by
  constructor
  · intro hl
    rcases brange w (K.pred v) with hb | hb
    · have hv : v = K.succ a := by
        simpa only [latch, hb, K.z_zero] using hl
      have hba : b w a = K.zero := by
        simpa only [hv, K.pred_succ] using hb
      exact ⟨hv, (btruth w a).mp hba⟩
    · have hz : K.zero = K.succ a := by
        simpa only [latch, hb, K.z_succ] using hl
      exact False.elim (K.succ_ne_zero a hz.symm)
  · rintro ⟨hv, hp⟩
    have hb : b w a = K.zero := (btruth w a).mpr hp
    simp only [latch, hv, K.pred_succ, hb, K.z_zero]

theorem rooted_latch_reflection
    (P : A → A → Prop) (b : A → A → A)
    (brange : ∀ n a, b n a = K.zero ∨ b n a = K.succ K.zero)
    (btruth : ∀ n a, b n a = K.zero ↔ P n a)
    (v w a : A) :
    K.rooted (K.latch b) v w = K.succ a ↔
      v = K.succ a ∧ (w = K.zero ∨ P w a) := by
  constructor
  · intro hr
    rcases K.chi_off w K.zero with hw | cw
    · have hv : v = K.succ a := by
        simpa only [hw, K.rooted_zero_right] using hr
      exact ⟨hv, Or.inl hw⟩
    · have hl : K.latch b v w = K.succ a := by
        simpa only [rooted, cw, K.z_zero, K.q_succ] using hr
      have hpair := (K.latch_reflection P b brange btruth v w a).mp hl
      exact ⟨hpair.1, Or.inr hpair.2⟩
  · rintro ⟨hv, hw | hp⟩
    · simpa only [hw, K.rooted_zero_right] using hv
    · rcases K.chi_off w K.zero with hw | cw
      · simpa only [hw, K.rooted_zero_right] using hv
      · have hl := (K.latch_reflection P b brange btruth v w a).mpr ⟨hv, hp⟩
        simpa only [rooted, cw, K.z_zero, K.q_succ] using hl

/--
The central bootstrap. Its sole schematic assumption is the encoded witness
for the shifted trajectory of this particular later-stage recursor.
-/
theorem induction_from_shifted_witness
    (P : A → A → Prop) (b : A → A → A)
    (brange : ∀ n a, b n a = K.zero ∨ b n a = K.succ K.zero)
    (btruth : ∀ n a, b n a = K.zero ↔ P n a)
    (R : A → A → A)
    (rstep : ∀ n a, R (K.succ n) a =
      K.rooted (K.latch b) (R n a) n)
    (witness : ∀ a, K.EncodedWitness (fun n => R (K.succ n) a) a)
    (a : A) (hbase : P K.zero a)
    (hprogress : ∀ n, P n a → P (K.succ n) a) :
    ∀ n, P n a := by
  have reflect : ∀ n, R (K.succ n) (K.succ a) = K.succ a → P n a := by
    intro n hn
    have hr : K.rooted (K.latch b) (R n (K.succ a)) n = K.succ a := by
      rw [← rstep]
      exact hn
    have hp := ((K.rooted_latch_reflection P b brange btruth
      (R n (K.succ a)) n a).mp hr).2
    rcases hp with hz | hp
    · simpa only [hz] using hbase
    · exact hp
  have stable : ReturnClosed K.succ (fun n => R (K.succ n) (K.succ a))
      (K.succ a) := by
    intro n hn
    have hp : P (K.succ n) a := hprogress n (reflect n hn)
    change R (K.succ (K.succ n)) (K.succ a) = K.succ a
    rw [rstep]
    exact (K.rooted_latch_reflection P b brange btruth
      (R (K.succ n) (K.succ a)) (K.succ n) a).mpr ⟨hn, Or.inr hp⟩
  have allReturns :=
    K.encodedWitness_implies_returnPrinciple
      (fun n => R (K.succ n) (K.succ a)) (K.succ a)
      (witness (K.succ a)) stable
  exact fun n => reflect n (allReturns n)

/-- Generic shifted base computation, used in PRA's soundness direction. -/
theorem shifted_base (t : A → A → A) (R : A → A → A)
    (rzero : ∀ a, R K.zero a = a)
    (rstep : ∀ n a, R (K.succ n) a = K.rooted t (R n a) n)
    (a : A) : R (K.succ K.zero) a = a := by
  rw [rstep, rzero, K.rooted_zero_right]

/--
Optional classical global-witness soundness, separate from the constructive
target-dependent soundness below.
-/
theorem shifted_globalWitness_from_equation_induction
    (t : A → A → A) (R : A → A → A)
    (rzero : ∀ a, R K.zero a = a)
    (rstep : ∀ n a, R (K.succ n) a = K.rooted t (R n a) n)
    (a : A)
    (induction : R (K.succ K.zero) a = a →
      (∀ n, R (K.succ n) a = a → R (K.succ (K.succ n)) a = a) →
      ∀ n, R (K.succ n) a = a) :
    K.GlobalEncodedWitness (fun n => R (K.succ n) a) a := by
  apply K.returnPrinciple_implies_globalEncodedWitness
  intro hp
  exact induction (K.shifted_base t R rzero rstep a) hp

/-- The quantifier-free invariant of the explicit boundary-witness recursion. -/
def BoundaryInvariant (F : A → A) (a : A) (c : A → A) (n : A) : Prop :=
  F (c n) = a ∧ (F n = a ∨ F (K.succ (c n)) ≠ a)

theorem boundary_invariant_base
    (F : A → A) (a : A) (c : A → A)
    (fzero : F K.zero = a) (czero : c K.zero = K.zero) :
    K.BoundaryInvariant F a c K.zero := by
  constructor
  · simpa only [czero] using fzero
  · exact Or.inl fzero

theorem boundary_invariant_step
    (F : A → A) (a : A) (c : A → A)
    (cstep : ∀ n, c (K.succ n) = K.choose (F n) a n (c n))
    (n : A) (hi : K.BoundaryInvariant F a c n) :
    K.BoundaryInvariant F a c (K.succ n) := by
  rcases K.eq_or_ne (F n) a with hn | hn
  · have hc : c (K.succ n) = n := by
      rw [cstep, K.choose_of_eq _ _ _ _ hn]
    constructor
    · simpa only [hc] using hn
    · rcases K.eq_or_ne (F (K.succ n)) a with hs | hs
      · exact Or.inl hs
      · apply Or.inr
        simpa only [hc] using hs
  · have hc : c (K.succ n) = c n := by
      rw [cstep, K.choose_of_ne _ _ _ _ hn]
    constructor
    · simpa only [hc] using hi.1
    · apply Or.inr
      have hexit : F (K.succ (c n)) ≠ a := by
        rcases hi.2 with hp | he
        · exact False.elim (hn hp)
        · exact he
      simpa only [hc] using hexit

theorem encodedWitness_from_boundaryInvariant
    (F : A → A) (a : A) (c : A → A)
    (hinvariant : ∀ n, K.BoundaryInvariant F a c n) :
    K.EncodedWitness F a := by
  intro n
  refine ⟨c n, ?_⟩
  have hi := hinvariant n
  rcases K.chi_off (F (K.succ (c n))) a with hs | hc
  · have hn : F n = a := by
      rcases hi.2 with hn | he
      · exact hn
      · exact False.elim (he hs)
    simpa only [K.choose_of_eq _ _ _ _ hs] using hn
  · simpa only [choose, hc, K.z_zero, K.q_succ] using hi.1

/--
Constructive soundness of the primary target-dependent witness. The only
induction assumption is the explicitly displayed BoundaryInvariant instance.
The function c is supplied with its two primitive-recursion computations.
-/
theorem encodedWitness_from_boundaryInduction
    (F : A → A) (a : A) (c : A → A)
    (fzero : F K.zero = a) (czero : c K.zero = K.zero)
    (cstep : ∀ n, c (K.succ n) = K.choose (F n) a n (c n))
    (induction : K.BoundaryInvariant F a c K.zero →
      (∀ n, K.BoundaryInvariant F a c n →
        K.BoundaryInvariant F a c (K.succ n)) →
      ∀ n, K.BoundaryInvariant F a c n) :
    K.EncodedWitness F a := by
  apply K.encodedWitness_from_boundaryInvariant F a c
  exact induction
    (K.boundary_invariant_base F a c fzero czero)
    (K.boundary_invariant_step F a c cstep)

/-- The constructive soundness theorem specialized to the shifted recursor. -/
theorem shifted_witness_from_boundaryInduction
    (t : A → A → A) (R : A → A → A)
    (rzero : ∀ a, R K.zero a = a)
    (rstep : ∀ n a, R (K.succ n) a = K.rooted t (R n a) n)
    (a : A) (c : A → A)
    (czero : c K.zero = K.zero)
    (cstep : ∀ n, c (K.succ n) =
      K.choose (R (K.succ n) a) a n (c n))
    (induction : K.BoundaryInvariant (fun n => R (K.succ n) a) a c K.zero →
      (∀ n, K.BoundaryInvariant (fun n => R (K.succ n) a) a c n →
        K.BoundaryInvariant (fun n => R (K.succ n) a) a c (K.succ n)) →
      ∀ n, K.BoundaryInvariant (fun n => R (K.succ n) a) a c n) :
    K.EncodedWitness (fun n => R (K.succ n) a) a := by
  exact K.encodedWitness_from_boundaryInduction
    (fun n => R (K.succ n) a) a c
    (K.shifted_base t R rzero rstep a) czero cstep induction

end Kernel

end ShiftedReturn

#print axioms ShiftedReturn.conditionalWitness_implies_returnPrinciple
#print axioms ShiftedReturn.returnPrinciple_implies_conditionalWitness
#print axioms ShiftedReturn.Kernel.succ_ne_zero
#print axioms ShiftedReturn.Kernel.eq_or_ne
#print axioms ShiftedReturn.Kernel.encodedWitness_implies_returnPrinciple
#print axioms ShiftedReturn.Kernel.rooted_zero_right
#print axioms ShiftedReturn.Kernel.outer_guard_redundant_for_latch
#print axioms ShiftedReturn.Kernel.rooted_latch_reflection
#print axioms ShiftedReturn.Kernel.induction_from_shifted_witness
#print axioms ShiftedReturn.Kernel.boundary_invariant_base
#print axioms ShiftedReturn.Kernel.boundary_invariant_step
#print axioms ShiftedReturn.Kernel.encodedWitness_from_boundaryInvariant
#print axioms ShiftedReturn.Kernel.encodedWitness_from_boundaryInduction
#print axioms ShiftedReturn.Kernel.shifted_witness_from_boundaryInduction
#print axioms ShiftedReturn.Kernel.returnPrinciple_implies_globalEncodedWitness
#print axioms ShiftedReturn.Kernel.shifted_globalWitness_from_equation_induction
