PRA FROM LOCAL RETURN WITNESSES
Prepared for Vladimir Reshetnikov, November 2, 2026

START HERE
  report.pdf       Complete paper, proofs, exact current-draft comparison.
  AXIOMS.txt       Standalone complete four-case axiom specification.
  report.tex and sections/*.tex  All editable LaTeX sources.

MAIN RESULT
The inductive payload is a single ordinary first-order equation with prefix
forall a forall n exists b. Its active size is exactly 20 nodes; when every
stored recursor descriptor is recursively charged, its size is 22+2W.
The target-dependent witness has an explicit primitive-recursive boundary
finder in PRA. The construction works separately in classical and
intuitionistic logic.

The whole theory preserves the binary generated language and inherited
root normalization. All omitted computation is derived by double padding
for exactly the same canonical recursor. A complete written proof gives
full-carrier bi-interpretations and identity composites, indeed a common
conservative definitional extension with matching first-order PRA.

COMPARISON
All FIVE current archives were reviewed at commit
fc604391af372504e9163797c0722069ae49466e.
The new emitter never exceeds their matched-input coordinatewise minimum
under either active or full-descriptor size, including smaller optional
profiles and omitting old separately factored fixed costs.
It strictly improves the seed, old guarded induction inputs, and new
selected return inputs. Other computation-only inputs tie.
Cross-language profile comparisons are explicitly distinguished from
literal same-grammar comparisons. No absolute shortestness is claimed.

An optional broader selector accepts the earlier outer-guarded shapes too.
It is never larger in emitted size, but adds a literal recognition option.

VERIFICATION
  checks/check_return_emitter.py      Independent AST and cost audit.
  checks/return_emitter_results.json  Exact recorded results.
  checks/check_return_arithmetic.py   Finite selector/boundary/pair diagnostics.
  checks/return_arithmetic_results.json
  formal/ShiftedReturn.lean           Arbitrary-carrier Lean 4.19.0 kernel.
  formal/SCOPE.txt                    Exact formalization boundary.
  formal/lean_output.txt              Actual compiler and axiom audit.
  formal/verification.json            Source hash and compiler information.
  verification/                      Build, document, and review records.
  provenance/source_manifest.json    Immutable five-archive hashes and URLs.

The full syntax, pairing, PR compiler, and interpretation composites have
written proofs. They are not claimed to be fully formalized in Lean.
Finite Python tests are diagnostics, not semantic proofs.

REBUILD
Requires Python 3.10+ (standard library) and pdfLaTeX with the packages
listed in report.tex. No network is needed for a rebuild.

  python3 build.py

To rerun Lean as well:
  python3 build.py --lean /absolute/path/to/lean

Checks only:
  python3 build.py --skip-pdf

Individual checks:
  python3 checks/check_return_emitter.py
  python3 checks/check_return_arithmetic.py
  lean formal/ShiftedReturn.lean

A direct PDF build needs the generated verification/stats.tex, already
included. Run pdflatex three times from this directory.

CONTENTS AND SCOPE
The archive omits baseline ZIPs, toolchain binaries, temporary page images,
and ordinary LaTeX auxiliary files. Further research questions are included.
No GitHub files were changed or published.

INTEGRITY
SHA256SUMS lists every distributed file except the checksum list itself.
From this directory, run: sha256sum -c SHA256SUMS
