#!/usr/bin/env python3
"""Exhaust all nonempty union-closed families on four labeled points.

This directly calculates ordered union multiplicities and independently
checks entropy extrema, oddness, prefix inequalities and majorization,
the exact leakage identity, the collision corollary, the chain equality
case, and the claimed upper-diamond equality case. It also checks the
multi-sample extremality and equality statements for three and four
independent inputs. It is finite corroboration, not a proof.
Uses only the Python standard library. Run from any directory.
"""
from collections import Counter
from decimal import Decimal, localcontext
from itertools import combinations
import json
from pathlib import Path


def audit(ground_size=4):
    universe_size = 1 << ground_size
    nmax = universe_size
    with localcontext() as ctx:
        ctx.prec = 70
        logs = {1: Decimal(0)}

        def log(value):
            if value not in logs:
                logs[value] = Decimal(value).ln()
            return logs[value]

        def flog(value):
            return Decimal(value) * log(value)

        tol = Decimal("1e-60")
        count = nonchains = chain_equalities = diamond_equalities = 0
        integer_prefix_checks = sorted_majorization_checks = 0
        leakage_identity_checks = pair_leakage_checks = collision_checks = 0
        multi_sample_checks = 0
        family_size_counts = Counter()
        equality_size_counts = Counter()
        for mask in range(1, 1 << universe_size):
            family = [a for a in range(universe_size) if (mask >> a) & 1]
            if any(not ((mask >> (a | b)) & 1)
                   for a, b in combinations(family, 2)):
                continue
            count += 1
            n = len(family)
            family_size_counts[n] += 1
            counts = Counter(a | b for a in family for b in family)
            assert set(counts) == set(family)
            assert all(v > 0 and v % 2 for v in counts.values())
            assert sum(counts.values()) == n * n
            order = sorted(family, key=lambda a: (a.bit_count(), a))
            rank = {member: i + 1 for i, member in enumerate(order)}
            ordered_counts = [counts[a] for a in order]
            sorted_counts = sorted(ordered_counts)
            prefix = sorted_prefix = 0
            e = [0]
            sorted_deficits = [0]
            for j, (ordered, sorted_count) in enumerate(zip(ordered_counts, sorted_counts), 1):
                prefix += ordered
                sorted_prefix += sorted_count
                assert sorted_prefix <= prefix <= j * j
                assert (j * j - prefix) % 2 == 0
                assert (j * j - sorted_prefix) % 2 == 0
                e.append(j * j - prefix)
                sorted_deficits.append(j * j - sorted_prefix)
                integer_prefix_checks += 1
                sorted_majorization_checks += 1
            assert e[-1] == sorted_deficits[-1] == 0
            assert all(ordered_counts[j - 1] - (2 * j - 1) == e[j - 1] - e[j]
                       for j in range(1, n + 1))

            raw_entropy_loss = sum(flog(v) for v in counts.values())
            chain_raw_loss = sum(flog(2 * j - 1) for j in range(1, n + 1))
            gap = raw_entropy_loss - chain_raw_loss
            incomparable = [(a, b) for a, b in combinations(family, 2)
                            if (a | b) not in (a, b)]
            assert gap >= -tol, (family, counts, gap)
            chain_equalities += abs(gap) <= tol
            assert (abs(gap) <= tol) == (not incomparable)
            assert (sorted_counts == list(range(1, 2 * n, 2))) == (not incomparable)

            # Check the exact rank-leakage identity in two different forms.
            kl = sum(Decimal(r) * (log(r) - log(2 * j - 1))
                     for j, r in enumerate(ordered_counts, 1)) / Decimal(n * n)
            prefix_leakage = sum(Decimal(e[k]) * (log(2 * k + 1) - log(2 * k - 1))
                                 for k in range(1, n)) / Decimal(n * n)
            assert kl >= -tol
            assert abs(gap / Decimal(n * n) - kl - prefix_leakage) <= tol
            leakage_identity_checks += 1
            e_from_pairs = [0] * (n + 1)
            pair_leakage = Decimal(0)
            for a, b in incomparable:
                first = max(rank[a], rank[b])
                last = rank[a | b]
                assert first < last
                for k in range(first, last):
                    e_from_pairs[k] += 2
                pair_leakage += 2 * (log(2 * last - 1) - log(2 * first - 1))
            pair_leakage /= Decimal(n * n)
            assert e_from_pairs == e
            assert abs(pair_leakage - prefix_leakage) <= tol
            pair_leakage_checks += 1

            # Collision-probability statement without real arithmetic.
            square_sum = sum(r * r for r in ordered_counts)
            chain_square_sum = sum((2 * j - 1) ** 2 for j in range(1, n + 1))
            assert 3 * chain_square_sum == n * (4 * n * n - 1)
            assert square_sum >= chain_square_sum + (16 if incomparable else 0)
            collision_checks += 1

            if incomparable:
                nonchains += 1
                sharp_gap = (flog(2 * n - 5) + flog(2 * n + 1)
                             - flog(2 * n - 3) - flog(2 * n - 1))
                assert gap >= sharp_gap - tol, (family, counts, gap, sharp_gap)
                is_equal = abs(gap - sharp_gap) <= tol
                top = 0
                for member in family:
                    top |= member
                is_upper_diamond = (len(incomparable) == 1
                                    and (incomparable[0][0] | incomparable[0][1]) == top)
                assert is_equal == is_upper_diamond, (family, counts)
                if is_equal:
                    diamond_equalities += 1
                    equality_size_counts[n] += 1

            # Exact dynamic convolution of the independent-input union law.
            sample_counts = counts
            for sample_size in (3, 4):
                new_counts = Counter()
                for a, multiplicity in sample_counts.items():
                    for b in family:
                        new_counts[a | b] += multiplicity
                sample_counts = new_counts
                assert set(sample_counts) == set(family)
                assert sum(sample_counts.values()) == n ** sample_size
                multi_ordered = [sample_counts[a] for a in order]
                multi_sorted = sorted(multi_ordered)
                reference = [j ** sample_size - (j - 1) ** sample_size
                             for j in range(1, n + 1)]
                prefix = sorted_prefix = 0
                for j, (ordered, sorted_count) in enumerate(zip(multi_ordered, multi_sorted), 1):
                    prefix += ordered
                    sorted_prefix += sorted_count
                    assert sorted_prefix <= prefix <= j ** sample_size
                    integer_prefix_checks += 1
                    sorted_majorization_checks += 1
                assert (multi_sorted == reference) == (not incomparable)
                multi_gap = sum(flog(r) for r in multi_ordered) - sum(flog(r) for r in reference)
                assert multi_gap >= -tol
                assert (abs(multi_gap) <= tol) == (not incomparable)
                multi_sample_checks += 1

        return {
            "ground_size": ground_size,
            "candidate_families": (1 << universe_size) - 1,
            "nonempty_union_closed_families": count,
            "nonchains": nonchains,
            "chain_equalities": chain_equalities,
            "sharp_nonchain_equalities": diamond_equalities,
            "exact_integer_prefix_checks": integer_prefix_checks,
            "exact_sorted_majorization_checks": sorted_majorization_checks,
            "leakage_identity_checks": leakage_identity_checks,
            "incomparable_pair_leakage_checks": pair_leakage_checks,
            "exact_integer_collision_checks": collision_checks,
            "multi_sample_family_cases": multi_sample_checks,
            "multi_sample_counts_tested": [3, 4],
            "counterexamples": 0,
            "decimal_precision": 70,
            "tolerance": str(tol),
            "family_size_counts": dict(sorted(family_size_counts.items())),
            "sharp_equality_size_counts": dict(sorted(equality_size_counts.items())),
        }


if __name__ == "__main__":
    result = audit()
    output = Path(__file__).with_name("audit_entropy_extrema.json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
