#!/usr/bin/env python3
"""Outward-rounded evaluations for the finite-size entropy bounds.

Uses only the Python standard library. Decimal.ln and Decimal.sqrt are correctly
rounded to ROUND_HALF_EVEN; moving one representable decimal in either direction
therefore encloses the real value. All subsequent arithmetic uses directed
rounding. This numerical certificate is not a proof-assistant verification.
"""

from dataclasses import dataclass
from decimal import Decimal, localcontext, ROUND_FLOOR, ROUND_CEILING
import json
from pathlib import Path

PRECISION = 70


def directed(op, rounding):
    with localcontext() as ctx:
        ctx.prec = PRECISION
        ctx.rounding = rounding
        return op()


@dataclass(frozen=True)
class I:
    lo: Decimal
    hi: Decimal

    @staticmethod
    def of(value):
        if isinstance(value, I):
            return value
        d = Decimal(value)
        return I(d, d)

    def __add__(self, other):
        other = I.of(other)
        return I(directed(lambda: self.lo + other.lo, ROUND_FLOOR),
                 directed(lambda: self.hi + other.hi, ROUND_CEILING))

    __radd__ = __add__

    def __neg__(self):
        # Decimal.copy_negate is exact and independent of the ambient context.
        return I(self.hi.copy_negate(), self.lo.copy_negate())

    def __sub__(self, other):
        return self + -I.of(other)

    def __rsub__(self, other):
        return I.of(other) + -self

    def __mul__(self, other):
        other = I.of(other)
        pairs = [(x, y) for x in (self.lo, self.hi)
                        for y in (other.lo, other.hi)]
        return I(min(directed(lambda x=x, y=y: x*y, ROUND_FLOOR)
                     for x, y in pairs),
                 max(directed(lambda x=x, y=y: x*y, ROUND_CEILING)
                     for x, y in pairs))

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = I.of(other)
        assert not other.lo <= 0 <= other.hi
        pairs = [(x, y) for x in (self.lo, self.hi)
                        for y in (other.lo, other.hi)]
        return I(min(directed(lambda x=x, y=y: x/y, ROUND_FLOOR)
                     for x, y in pairs),
                 max(directed(lambda x=x, y=y: x/y, ROUND_CEILING)
                     for x, y in pairs))

    def __rtruediv__(self, other):
        return I.of(other) / self

    def ln(self):
        assert self.lo > 0
        with localcontext() as ctx:
            ctx.prec = PRECISION
            return I(self.lo.ln().next_minus(), self.hi.ln().next_plus())

    def sqrt(self):
        assert self.lo >= 0
        with localcontext() as ctx:
            ctx.prec = PRECISION
            return I(self.lo.sqrt().next_minus(), self.hi.sqrt().next_plus())

    def json(self):
        return {"lower": str(self.lo), "upper": str(self.hi)}


TAU = (I.of(5).sqrt()-1)/2
PSI = 1-TAU
CS_C = I.of("0.3828852549667978")
CS_M = 1-CS_C
CS_K = I.of("0.5")+CS_M/800000000
D_INF = I.of(2).ln()-I.of("0.5")
D_TWO = 3*I.of(3).ln()/4-I.of(2).ln()


def error_bound(n):
    return (I.of(n).ln()+4)/(12*n*n)


def d_n(n):
    if n <= 1000:
        value = I.of(0)
        for j in range(1, n+1):
            odd = 2*j-1
            value += I.of(odd)/(n*n)*(I.of(odd)/n).ln()
        return value, "direct finite sum"
    # Convex midpoint quadrature and the analytic error estimate proved in memo.
    low = D_INF-error_bound(n)
    return I(low.lo, D_INF.hi), "analytic midpoint bounds"


def main():
    assert 2**100 > 3**63  # Exact endpoint comparison in Proposition 8.2.
    rows = []
    for n in (2, 3, 4, 10, 100, 1000, 10**6, 10**12, 10**100):
        d, method = d_n(n)
        log_n = I.of(n).ln()
        golden = PSI + TAU*d/log_n
        cs = CS_C + CS_K*d/log_n
        rows.append({"N": str(n), "D_N": d.json(),
                     "golden": golden.json(), "costa_sadhu": cs.json(),
                     "D_method": method})

    # If 2 <= N <= 1000, D_N >= D_2 and ln N <= ln 1000.
    small_certificate = PSI + TAU*D_TWO/I.of(1000).ln()
    # Alternative small-N argument used by the final manuscript: evaluate
    # N=2,...,7 directly, then use the decreasing midpoint error for N>=8.
    small_direct_values = {}
    for n in range(2, 8):
        value, _ = d_n(n)
        assert value.lo > Decimal("0.12")
        small_direct_values[str(n)] = value.json()
    n8_midpoint_lower = D_INF-error_bound(8)
    assert n8_midpoint_lower.lo > Decimal("0.18")
    small_simple_certificate = PSI + TAU*I.of("0.12")/I.of(1000).ln()
    assert small_simple_certificate.lo > Decimal("0.3927")
    # If 1000 <= N <= 2,800,000, E(N) <= E(1000), ln N <= ln 2,800,000.
    large_certificate = PSI + TAU*(D_INF-error_bound(1000))/I.of(2800000).ln()
    assert small_certificate.lo > Decimal("0.39")
    assert large_certificate.lo > Decimal("0.39")

    # Endpoint comparison used to establish D_N >= D_2 for every N >= 2.
    d_one_third = 16*I.of(2).ln()/9-I.of(3).ln()
    assert d_one_third.lo > D_TWO.hi
    assert D_TWO.lo > 0

    output = {"precision_decimal_digits": PRECISION,
              "constants": {"tau": TAU.json(), "psi": PSI.json(),
                            "costa_sadhu_c": CS_C.json(),
                            "costa_sadhu_k": CS_K.json(),
                            "D_infinity": D_INF.json(), "D_2": D_TWO.json()},
              "table": rows,
              "exclusion_p_le_0_39": {
                  "N_at_most_1000": small_certificate.json(),
                  "simpler_manuscript_argument": {
                      "D_N_direct_for_N_2_through_7": small_direct_values,
                      "D_infinity_minus_error_at_N_8": n8_midpoint_lower.json(),
                      "psi_plus_tau_times_0_12_over_log_1000":
                          small_simple_certificate.json(),
                      "verified_claims": [
                          "D_N > 0.12 for N=2,3,4,5,6,7",
                          "D_infinity-E(8) > 0.18",
                          "psi+0.12*tau/ln(1000) > 0.3927"]},
                  "N_1000_to_2800000": large_certificate.json(),
                  "conclusion": "p <= 0.39 implies N > 2800000"},
              "D2_endpoint_difference": (d_one_third-D_TWO).json()}
    destination = Path(__file__).with_name("finite_bounds.json")
    destination.write_text(json.dumps(output, indent=2)+"\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
