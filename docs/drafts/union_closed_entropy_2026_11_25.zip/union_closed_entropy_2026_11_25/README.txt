FINITE-SIZE REFINEMENTS FOR THE UNION-CLOSED SETS CONJECTURE
25 November 2026

Prepared for Vladimir Reshetnikov by ChatGPT.

READ FIRST

This archive does not contain a proof of the full union-closed sets
conjecture. It contains complete proofs of proposed new finite-size
refinements, a sharp entropy theorem, an exact second-extremum theorem,
and reproducible numerical checks. A focused literature search found no
exact predecessor for these contributions; historical priority remains
unverified. Established ingredients and external dependencies are labeled.

MAIN RESULT

Let F be a nontrivial union-closed family of N >= 2 distinct sets, and let p
be the maximum proportion of its members containing any one element. Set

  tau = (sqrt(5)-1)/2,
  d_N = (1/N^2) sum_{j=1}^N (2j-1) ln((2j-1)/N),
  c = 0.3828852549667978,
  kappa = 0.50000000077139343129150275.

Then

  p >= max(1-tau + tau*d_N/ln N, c + kappa*d_N/ln N).

The first bound is analytic. The second uses Proposition 6.3 of the
computer-assisted Costa--Sadhu preprint arXiv:2610.02295v1. This archive
does not claim to rerun or independently certify that external paper.
Both use a new sharp upper bound on independent-union entropy proved in
the manuscript. The correction is of order 1/ln N and tends to zero.

A concrete analytic consequence: every such family with at most 2,800,000
members has an element in more than 39 percent of its members.

The sharp second-extremal theorem says that among nonchains the entropy
maximum is attained exactly by an inclusion poset consisting of a chain
of N-3 members below two incomparable members and their union.

CONTENTS

  union_closed_entropy.pdf    Complete research note, proofs and bibliography.
  union_closed_entropy.tex    Matching self-contained LaTeX source.
  literature_notes.txt        Prior-art comparison, exact sources and limits.
  Makefile                    Standard build and verification commands.
  artifacts/finite_bounds.py  Outward-rounded numerical interval calculator.
  artifacts/finite_bounds.json
                             Stored numerical interval certificates.
  artifacts/audit_entropy_extrema.py
                             Exhaustive check on four labeled ground elements.
  artifacts/audit_entropy_extrema.json
                             Complete census and verification counts.
  SHA256SUMS.txt              Checksums of the deliverable files.

REPRODUCTION

With Python 3 (standard library only):

  python3 artifacts/finite_bounds.py
  python3 artifacts/audit_entropy_extrema.py

Each script rewrites only its matching JSON output beside the script.
Do not use Python's -O option: assertions implement the checks.
The interval calculator relies on Python Decimal's correctly rounded
ln/sqrt operations, adds outward neighboring values, and uses directed
rounding for arithmetic. It is not proof-assistant verification.
The exhaustive audit performs exact integer combinatorial checks and
70-digit numerical entropy comparisons with tolerance 1e-60.

With a normal TeX Live/MiKTeX installation and latexmk:

  make pdf

Alternatively run pdflatex union_closed_entropy.tex twice. The source
uses common packages and has an embedded bibliography, so BibTeX is not
needed. The supplied PDF is already compiled.

  make verify

runs both Python checks. No downloaded datasets, solver licenses, or
network access are needed for those checks.

VALIDATION AND LIMITS

All 65,535 nonempty subfamilies on four labeled points were tested. There
are 4,959 union-closed families, 299 chains, and 4,660 nonchains; 218
families attain the sharp nonchain entropy bound. No counterexamples
were found. The included JSON records additional prefix, majorization,
defect-identity, collision, and multiple-union checks.

Finite computations corroborate the proofs; they do not establish the
infinite general statements by themselves. No Lean/Rocq formalization or
independent human referee review is claimed. The paper explicitly credits
Quas's prior chain example and the established scalar entropy inequalities.
