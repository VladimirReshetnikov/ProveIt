"""Package the validated deliverable with a deterministic file list and hashes."""

import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
SKIP = {".aux", ".log", ".out", ".toc", ".pyc", ".fls", ".fdb_latexmk"}


def included():
    return sorted(path for path in ROOT.rglob("*")
                  if path.is_file() and path.suffix not in SKIP
                  and "__pycache__" not in path.parts
                  and path.name != "file_manifest.json")


def main():
    paths = included()
    manifest = {str(path.relative_to(ROOT)): {
        "bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    } for path in paths}
    manifest_path = ROOT / "verification/file_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    archive = ROOT.with_suffix(".zip")
    with ZipFile(archive, "w", compression=ZIP_DEFLATED, compresslevel=9) as output:
        for path in sorted([*paths, manifest_path]):
            item = ZipInfo(str(Path(ROOT.name) / path.relative_to(ROOT)),
                           date_time=(2026, 11, 6, 12, 0, 0))
            item.compress_type = ZIP_DEFLATED
            item.external_attr = 0o100644 << 16
            output.writestr(item, path.read_bytes(), compress_type=ZIP_DEFLATED,
                            compresslevel=9)
    with ZipFile(archive) as check:
        if check.testzip() is not None:
            raise ValueError("ZIP integrity check failed")
    print(json.dumps({"archive": str(archive), "files": len(paths) + 1,
                      "bytes": archive.stat().st_size,
                      "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))


if __name__ == "__main__":
    main()
