"""Recount the bundled sources and replay all supplied verification offline."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    runs = []
    for args in (["measure.py"], ["code/translate.py", "verify"],
                 ["verification/audit_checker.py"]):
        result = subprocess.run([sys.executable, *args], cwd=ROOT,
                                text=True, capture_output=True, check=False)
        runs.append({"command": ["python3", *args], "returncode": result.returncode,
                     "stdout": result.stdout, "stderr": result.stderr})
        if result.returncode:
            print(result.stdout)
            print(result.stderr, file=sys.stderr)
            raise SystemExit(result.returncode)
    audit = json.loads((ROOT / "verification/audit_results.json").read_text())
    translation = json.loads((ROOT / "verification/translation_results.json").read_text())
    metrics = json.loads((ROOT / "verification/metrics.json").read_text())
    candidate = metrics["variants"][-1]
    expected_sha = hashlib.sha256((ROOT / "code/checker.py").read_bytes()).hexdigest()
    assert audit["checker_sha256"] == translation["candidate_checker_sha256"] == expected_sha
    assert audit["all_passed"] and translation["status"] == "passed"
    assert candidate["meaningful_python_tokens"] < metrics["minimum_previous_tokens"]
    assert candidate["ast_nodes"] < metrics["minimum_previous_ast"]
    summary = (
        f"The packaged replay accepted all {translation['corpus_count']} original baseline certificates, "
        "all their translations into the new checker, and all reverse translations. "
        "Their goals and assumption contexts were exactly preserved. "
        f"A further {translation['extra_case_count']} round-trip cases tested inserted guards beneath "
        "nested binders and direct numerical-axiom leaves. "
        f"An independent audit passed {audit['certificate_cases']} certificate cases "
        f"({audit['expected_accepts']} expected acceptances and {audit['expected_rejections']} expected rejections), "
        f"{audit['independent_oracle_properties']} binding/substitution oracle comparisons, and "
        f"{audit['schema_templates']} numerical-schema templates. "
        "The oracle used a separate named-variable syntax and did not use the kernel's "
        "substitution routines to compute expected answers. All checks passed.\n"
    )
    (ROOT / "verification/summary.tex").write_text(summary)
    result = {"all_passed": True, "checker_sha256": expected_sha,
              "corpus_count": translation["corpus_count"],
              "extra_roundtrips": translation["extra_case_count"],
              "certificate_cases": audit["certificate_cases"],
              "oracle_properties": audit["independent_oracle_properties"],
              "schema_templates": audit["schema_templates"],
              "tokens": candidate["meaningful_python_tokens"],
              "ast_nodes": candidate["ast_nodes"], "runs": runs}
    (ROOT / "verification/reproduction.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "runs"}, indent=2))


if __name__ == "__main__":
    main()
