"""Independent scope, substitution, schema, and adversarial audit.

This is test code, not trusted by checker.py. Expected substitutions and the
numerical axiom are built through a separate named-variable AST, without
calling the checker's shift/subst/inst to compute expected answers. It checks
certificates and syntactic invariants; it is not a formal soundness proof.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import random
import sys

ROOT = Path(__file__).resolve().parents[1]
KERNEL = ROOT / 'code' / 'checker.py'
spec = importlib.util.spec_from_file_location('audited_ipra_kernel', KERNEL)
K = importlib.util.module_from_spec(spec)
spec.loader.exec_module(K)
Z, F = -1, ('false',)
T = ('=', Z, Z)
CLASH = ('=', Z, ('s', Z))
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError)


def eq(left, right):
    return ('=', left, right)


def to_named(a, free=lambda i: 'f' + str(i)):
    """Use fresh names for all local binders; free names stay explicit."""
    serial = 0

    def fresh():
        nonlocal serial
        name = 'b' + str(serial)
        serial += 1
        return name

    def visit(a, bound=()):
        if type(a) is int:
            if a == -1:
                return ('zero',)
            assert a >= 0
            return ('var', bound[a] if a < len(bound) else free(a - len(bound)))
        tag = a[0]
        if tag == 'r':
            state, counter = fresh(), fresh()
            return ('r', visit(a[1], bound), visit(a[2], bound),
                    state, counter, visit(a[3], (state, counter) + bound))
        if tag in ('pi', 'sig'):
            variable = fresh()
            return (tag, variable, visit(a[1], (variable,) + bound),
                    visit(a[2], (variable,) + bound))
        return (tag, *(visit(child, bound) for child in a[1:]))

    return visit(a)


def from_named(a, free_index=lambda name: int(name[1:])):
    def visit(a, bound=()):
        tag = a[0]
        if tag == 'zero':
            return -1
        if tag == 'var':
            name = a[1]
            return bound.index(name) if name in bound else len(bound) + free_index(name)
        if tag == 'r':
            _, n, initial, state, counter, body = a
            return ('r', visit(n, bound), visit(initial, bound),
                    visit(body, (state, counter) + bound))
        if tag in ('pi', 'sig'):
            _, variable, left, right = a
            return (tag, visit(left, (variable,) + bound), visit(right, (variable,) + bound))
        return (tag, *(visit(child, bound) for child in a[1:]))

    return visit(a)


def named_substitute(a, environment, bound=()):
    """Substitute only free named variables; oracle terms use disjoint names."""
    tag = a[0]
    if tag == 'var':
        return a if a[1] in bound else environment(a[1])
    if tag == 'r':
        _, n, initial, state, counter, body = a
        return ('r', named_substitute(n, environment, bound),
                named_substitute(initial, environment, bound), state, counter,
                named_substitute(body, environment, (state, counter) + bound))
    if tag in ('pi', 'sig'):
        _, variable, left, right = a
        local = (variable,) + bound
        return (tag, variable, named_substitute(left, environment, local),
                named_substitute(right, environment, local))
    return (tag, *(named_substitute(child, environment, bound) for child in a[1:]))


def oracle_subst(a, environment):
    named = to_named(a)
    return from_named(named_substitute(named, lambda name: to_named(environment(int(name[1:])))))


def oracle_shift(a, amount=1):
    return oracle_subst(a, lambda index: index + amount)


def oracle_inst(a, term):
    return oracle_subst(a, lambda index: term if index == 0 else index - 1)


def oracle_successor(a):
    return oracle_subst(a, lambda index: ('s', 0) if index == 0 else index)


def oracle_nat(a, force_induction=False):
    """Build forall x(A0 -> forall d(Q_A -> Ax)) with named binders."""
    named = to_named(a, lambda index: 'x' if index == 0 else 'p' + str(index - 1))

    def replace_x(term):
        return named_substitute(named, lambda name: term if name == 'x' else ('var', name))

    base = replace_x(('zero',))
    antecedent = replace_x(('var', 'y')) if a[0] == '=' or force_induction else base
    step = ('pi', 'y', antecedent, replace_x(('s', ('var', 'y'))))
    whole = ('pi', 'x', base, ('pi', 'dummy', step, named))
    return from_named(whole, lambda name: int(name[1:]))


def reflexivity(term):
    call = ('r', Z, term, Z)
    seed = ('rec', call)
    return ('eq', seed, eq(0, oracle_shift(term)), seed)


def theorem_problem(goal, proof, assumptions=()):
    return {'assumptions': list(assumptions), 'goal': goal, 'proof': proof}


CASES = []
PROPERTIES = []


def add(name, assumptions, goal, proof, expected=False):
    CASES.append((name, theorem_problem(goal, proof, assumptions), expected))


def raw(name, problem, expected=False):
    CASES.append((name, problem, expected))


# Exact scalar types, term/formula separation, and external document shape.
for label, bad in [('boolean_true', True), ('boolean_false', False),
                   ('negative_two', -2), ('large_negative', -(10 ** 50)),
                   ('float_zero', -1.0), ('float_variable', 0.0),
                   ('none', None), ('string_variable', '0'),
                   ('empty_tuple', ()), ('unknown_term', ('q',)),
                   ('old_zero_tag', ('z',)), ('successor_missing_child', ('s',)),
                   ('successor_extra_child', ('s', Z, Z)),
                   ('recursor_missing_child', ('r', Z, Z)),
                   ('recursor_extra_child', ('r', Z, Z, Z, Z)),
                   ('formula_used_as_term', F)]:
    add('malformed_term_' + label, [eq(bad, Z)], eq(bad, Z), ('hyp', 0))
for label, bad in [('term_as_formula', Z), ('boolean_formula', True),
                   ('empty_formula', ()), ('unknown_formula', ('and', T, T)),
                   ('equation_extra_child', ('=', Z, Z, Z)),
                   ('bottom_extra_child', ('false', Z)),
                   ('pi_missing_child', ('pi', T)),
                   ('sigma_extra_child', ('sig', T, T, T))]:
    add('malformed_formula_' + label, [bad], bad, ('hyp', 0))
raw('document_not_mapping', [])
raw('document_missing_proof', {'assumptions': [], 'goal': T})
raw('document_extra_field', {'assumptions': [], 'goal': T, 'proof': reflexivity(Z), 'extra': 0})
raw('assumptions_not_list', {'assumptions': (), 'goal': T, 'proof': reflexivity(Z)})
add('unused_malformed_assumption', [eq(-2, Z)], T, reflexivity(Z))
for label, index in [('boolean', False), ('negative', -1), ('float', 0.0), ('too_large', 1)]:
    add('bad_hypothesis_index_' + label, [T], T, ('hyp', index))
add('unknown_proof_tag', [], T, ('trust', T))
add('proof_tag_extra_field', [T], T, ('hyp', 0, 0))
add('missing_hypothesis', [], T, ('hyp', 0))
add('nat_malformed_template', [], T, ('nat', eq(-2, Z)))
add('nat_extra_field', [], T, ('nat', T, T))

# Legal open support and the negative integer constant sentinel.
for label, term in [('zero', Z), ('successor_zero', ('s', Z)),
                    ('free_parameter', 0), ('large_free_parameter', 10 ** 50),
                    ('native_recursion', ('r', 0, Z, ('r', 1, 2, ('s', 4))))]:
    add('reflexivity_' + label, [], eq(term, term), reflexivity(term), True)
add('zero_is_a_constant_under_hypothesis', [T], T, ('hyp', 0), True)

# Pi introduction must lift all retained parameters, including inside R bodies.
add('pi_parameter_capture', [eq(0, Z)], ('pi', T, eq(0, Z)), ('pi', T, ('hyp', 0)))
add('pi_parameter_lift_valid', [eq(0, Z)], ('pi', T, eq(1, Z)), ('pi', T, ('hyp', 0)), True)
H = eq(('r', Z, Z, 2), Z)
add('pi_capture_under_rec_body', [H], ('pi', T, H), ('pi', T, ('hyp', 0)))
add('pi_rec_parameter_lift_valid', [H], ('pi', T, oracle_shift(H)), ('pi', T, ('hyp', 0)), True)
nested = ('pi', T, eq(1, 0))
add('pi_nested_binder_lift_valid', [nested], ('pi', T, oracle_shift(nested)),
    ('pi', T, ('hyp', 0)), True)
add('pi_nested_local_variable_corrupted', [nested], ('pi', T, ('pi', T, eq(2, 1))),
    ('pi', T, ('hyp', 0)))

# Existential witnesses cannot escape through goals or native recursion bodies.
S = ('sig', eq(0, Z), T)
add('sigma_witness_escape', [S], eq(0, Z), ('let', ('hyp', 0), eq(0, Z), ('hyp', 1)))
add('sigma_closed_goal_valid', [S], T, ('let', ('hyp', 0), T, ('hyp', 2)), True)
SH = ('sig', H, T)
add('sigma_witness_escape_under_rec', [SH], H, ('let', ('hyp', 0), H, ('hyp', 1)))
add('sigma_ambient_parameter_lift_valid', [eq(0, Z), S], eq(0, Z),
    ('let', ('hyp', 1), eq(0, Z), ('hyp', 0)), True)
add('sigma_false_from_true_components', [('sig', T, T)], F,
    ('let', ('hyp', 0), F, ('hyp', 1)))

# Quantifier application protects inner bound variables when inserting a term.
principal = ('pi', T, ('pi', eq(1, 0), eq(1, 0)))
expected = oracle_inst(principal[2], 0)
add('application_beneath_binder_valid', [principal, T], expected,
    ('app', ('hyp', 0), 0, ('hyp', 1)), True)
add('application_captured_inner_variable', [principal, T], ('pi', eq(0, 0), eq(0, 0)),
    ('app', ('hyp', 0), 0, ('hyp', 1)))
add('application_wrong_guard', [principal, CLASH], expected,
    ('app', ('hyp', 0), 0, ('hyp', 1)))
add('application_nonuniversal_major', [T], T, ('app', ('hyp', 0), Z, ('hyp', 0)))

# Equality replacement must protect both logical and native-recursion binders.
for label, template in [('pi', ('pi', T, eq(1, 0))),
                         ('sigma', ('sig', eq(0, 1), eq(1, 0))),
                         ('rec', H),
                         ('nested_rec', eq(('r', Z, 0, ('r', 2, 3, 4)), 0))]:
    source, target = oracle_inst(template, 0), oracle_inst(template, 1)
    add('transport_' + label + '_valid', [eq(0, 1), source], target,
        ('eq', ('hyp', 0), template, ('hyp', 1)), True)
    add('transport_' + label + '_wrong_premise', [eq(0, 1), target], target,
        ('eq', ('hyp', 0), template, ('hyp', 1)))
add('transport_capture_under_pi', [eq(0, 1), oracle_inst(('pi', T, eq(1, 0)), 0)],
    ('pi', T, eq(0, 0)), ('eq', ('hyp', 0), ('pi', T, eq(1, 0)), ('hyp', 1)))
for slot, label in [(0, 'state'), (1, 'counter')]:
    add('transport_capture_rec_' + label, [eq(0, 1), oracle_inst(H, 0)],
        eq(('r', Z, Z, slot), Z), ('eq', ('hyp', 0), H, ('hyp', 1)))

# The bridge recognizes exactly its two directions and needs a proof premise.
add('bridge_false_to_clash', [F], CLASH, ('bridge', ('hyp', 0)), True)
add('bridge_clash_to_false', [CLASH], F, ('bridge', ('hyp', 0)), True)
add('bridge_round_trip', [F], F, ('bridge', ('bridge', ('hyp', 0))), True)
add('bridge_reflexivity_is_not_contradiction', [T], F, ('bridge', ('hyp', 0)))
add('bridge_reversed_clash_is_not_primitive', [eq(('s', Z), Z)], F, ('bridge', ('hyp', 0)))
add('bridge_needs_premise', [], F, ('bridge',))
add('false_from_reflexivity', [], F, reflexivity(Z))
add('clash_from_reflexivity', [], CLASH, reflexivity(Z))
add('false_from_nat_leaf', [], F, ('nat', F))
add('fake_reflexivity_tag', [], CLASH, ('refl',))

# Explicit one-clause recursion; no symbolic-counter normalization is trusted.
rec_cases = [
    ('base_with_parameter', ('r', Z, 0, ('s', 0))),
    ('base_nested_initializer', ('r', Z, ('r', 0, Z, ('s', 0)), 2)),
    ('step_state', ('r', ('s', 0), Z, ('s', 0))),
    ('step_counter', ('r', ('s', 0), 1, 1)),
    ('step_parameter', ('r', ('s', 1), 0, 2)),
    ('step_nested_bodies', ('r', ('s', 0), 1, ('r', 0, 2, ('r', 3, 4, ('s', 6))))),
]
for label, r in rec_cases:
    if r[1] == Z:
        target = r[2]
    else:
        counter = r[1][1]
        previous = ('r', counter, r[2], r[3])
        target = oracle_subst(r[3], lambda index: (previous, counter)[index] if index < 2 else index - 2)
    add('rec_' + label, [], eq(r, target), ('rec', r), True)
    add('rec_' + label + '_wrong_result', [], eq(r, ('s', target)), ('rec', r))
unknown = ('r', 0, Z, 0)
add('rec_symbolic_counter_rejected', [], eq(unknown, Z), ('rec', unknown))

# Independent finite syntax census, with a fixed seed and bounded tree size.
rng = random.Random(20261106)


def random_term(depth):
    if depth == 0 or rng.randrange(4) == 0:
        return rng.choice([Z, 0, 1, 2, 3, 5])
    if rng.randrange(2):
        return ('s', random_term(depth - 1))
    return ('r', random_term(depth - 1), random_term(depth - 1), random_term(depth - 1))


def random_formula(depth):
    if depth == 0:
        return eq(random_term(2), random_term(2))
    choice = rng.randrange(5)
    if choice == 0:
        return F
    if choice == 1:
        return eq(random_term(2), random_term(2))
    return (rng.choice(['pi', 'sig']), random_formula(depth - 1), random_formula(depth - 1))


templates = [T, F, eq(0, Z), eq(0, 1), eq(('r', 0, 1, ('s', 2)), 2),
             ('pi', T, eq(1, Z)), ('sig', eq(0, 1), eq(1, 2)),
             ('pi', ('sig', eq(1, 2), T), ('sig', T, eq(2, 3)))]
templates += [random_formula(3) for _ in range(64)]

for index, template in enumerate(templates):
    name = 'nat_named_schema_%03d' % index
    add(name, [], oracle_nat(template), ('nat', template), True)
    base = oracle_inst(template, Z)
    antecedent = template if template[0] == '=' else oracle_shift(base)
    step = ('pi', antecedent, oracle_successor(template))
    target = ('r', 0, Z, ('s', 0)) if index % 3 == 0 else 0
    proof = ('app', ('app', ('nat', template), target, ('hyp', 0)), Z, ('hyp', 1))
    add('nat_instantiated_schema_%03d' % index, [base, step], oracle_inst(template, target), proof, True)
    if template[0] != '=' and oracle_nat(template, True) != oracle_nat(template):
        add('nat_reject_unrestricted_IH_%03d' % index, [], oracle_nat(template, True),
            ('nat', template))
        unrestricted_step = ('pi', template, oracle_successor(template))
        add('nat_reject_full_induction_application_%03d' % index,
            [base, unrestricted_step], oracle_inst(template, target), proof)

    # The checker-side operations are compared only after oracle answers exist.
    for amount in (0, 1, 2, 4):
        PROPERTIES.append(('shift_named_oracle_%03d_%d' % (index, amount),
                           K.shift(template, amount), oracle_shift(template, amount)))
    replacement = random_term(2)
    PROPERTIES.append(('instantiate_named_oracle_%03d' % index,
                       K.inst(template, replacement), oracle_inst(template, replacement)))
    PROPERTIES.append(('successor_named_oracle_%03d' % index,
                       K.subst(template, lambda i: ('s', 0) if i == 0 else i),
                       oracle_successor(template)))
    PROPERTIES.append(('native_named_round_trip_%03d' % index,
                       from_named(to_named(template)), template))

for amount in (0, 1, 2, 100):
    PROPERTIES.append(('zero_sentinel_is_fixed_%d' % amount, K.shift(Z, amount), Z))
PROPERTIES.append(('zero_sentinel_is_not_a_substitution_slot', K.inst(Z, ('s', Z)), Z))


def run():
    initial_hash = hashlib.sha256(KERNEL.read_bytes()).hexdigest()
    reports = []
    for name, document, expected in CASES:
        error = None
        try:
            actual = K.check(document) is True
        except ERRORS as exc:
            actual = False
            error = type(exc).__name__
        reports.append({'name': name, 'expected': expected, 'accepted': actual,
                        'passed': actual == expected, 'exception': error})
    properties = [{'name': name, 'passed': actual == expected}
                  for name, actual, expected in PROPERTIES]
    failures = [row['name'] for row in reports + properties if not row['passed']]
    final_hash = hashlib.sha256(KERNEL.read_bytes()).hexdigest()
    assert initial_hash == final_hash, 'checker changed during audit'
    result = {
        'checker_sha256': final_hash,
        'python_version': sys.version.split()[0],
        'scope': __doc__.strip(),
        'certificate_cases': len(reports),
        'expected_accepts': sum(row['expected'] for row in reports),
        'expected_rejections': sum(not row['expected'] for row in reports),
        'independent_oracle_properties': len(properties),
        'schema_templates': len(templates),
        'all_passed': not failures,
        'failures': failures,
        'cases': reports,
        'properties': properties,
        'limitation': 'Finite targeted regressions and independent syntax oracles; no formal proof of soundness or bi-interpretability is claimed.',
    }
    output = ROOT / 'verification' / 'audit_results.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ['checker_sha256', 'certificate_cases',
          'expected_accepts', 'expected_rejections', 'independent_oracle_properties',
          'schema_templates', 'all_passed', 'failures']}, indent=2))
    if failures:
        raise AssertionError('Audit failures: ' + ', '.join(failures))
    return result


if __name__ == '__main__':
    run()
