> This is the input-draft audit. Prospective reduction suggestions in it predate the final numerical axiom schema; report.tex and code/checker.py specify the delivered construction.

# Audit of the eleven current iPRA draft archives

## Snapshot and conclusion

The snapshot is `VladimirReshetnikov/ProveIt` commit
`b079e5787b1d708049ff0643ce1b534c1a225198`, as downloaded into
`sources/ProveIt/docs/drafts`. The eleven ZIP archives are mapped to extraction
IDs `d00` through `d10` in `sources/inventory.json`.

**The smallest supplied production verifier in the current set is d03,
`ipra_kernel_2026-11-06/code/checker.py`: 1,167 significant Python tokens and
1,252 Python AST nodes, with its JSON interface included.** Its own matched
comparison file `comparisons/previous_k_open_pattern.py` has 1,171 tokens and
1,248 AST nodes. Accordingly, a new implementation smaller in both measures
should target fewer than 1,167 tokens and fewer than 1,248 AST nodes. These are
attained sizes of supplied programs, not lower bounds on all implementations
of their theories.

The newest dates do not imply a smaller implementation. Most November 6
reports still compare against the earlier six arithmetic-core proposals,
not against all eleven archives now in the directory. Statements inside
those reports that the input drafts provide diagnostics rather than complete
checkers describe their earlier input set. **They are false as descriptions
of the present eleven archives**, which contain complete checking programs.

## One reproducible accounting convention

Run `python3 sources/draft_audit_measure.py` to regenerate
`sources/draft_audit.json`. Each row counts the original source of all local
modules needed by the selected verifier, exactly once. It includes syntax
validation, scope and substitution code, fixed schema data, inference
checking, input parsing, and the JSON driver. It excludes the common Python
runtime and standard libraries, proof producers, test programs, measurement
scripts, and document builders. The counts omit only comments, layout
markers, and genuine module/class/function docstrings. AST nodes are counted
after removing those docstring statements. Source bytes retain all text.

This is deliberately a census of the supplied complete programs, not a claim
that implementation style is controlled across every archive. They differ in
named versus indexed variables, native versus frozen recursion syntax,
inference versus goal-directed checking, and the amount of defensive input
handling. A controlled comparison with a new kernel should additionally use
a minimally changed copy of d03.

| ID | Archive | Smallest selected complete verifier | Tokens | AST nodes |
|---|---|---|---:|---:|
| d00 | `ipra_arithmetic_logic_kernel_2026-11-06.zip` | `kernel.py` + `check_json.py` | 1,772 | 1,825 |
| d01 | `ipra_block_kernel_2026-11-03.zip` | `code/matrix_checker.py` | 1,910 | 2,047 |
| d02 | `ipra_case_elimination_2026-11-06.zip` | `kernel_work/candidate_schema.py` | 1,798 | 1,927 |
| d03 | `ipra_kernel_2026-11-06.zip` | `code/checker.py` | **1,167** | 1,252 |
| d04 | `ipra_small_checker_2026-11-03 (1).zip` | `native/checker.py` (positive representation) | 1,238 | 1,266 |
| d05 | `ipra_small_checker_2026-11-03.zip` | `checker.py` | 1,289 | 1,393 |
| d06 | `ipra_small_kernel_2026-11-03(1).zip` | `rows_common.py` + `rows_kernel.py` | 1,849 | 2,081 |
| d07 | `ipra_small_kernel_2026-11-03.zip` | `artifacts/kernel.py` + `artifacts/check_json.py` (positive representation) | 2,066 | 2,190 |
| d08 | `ipra_small_kernel_2026-11-06 (2).zip` | `code/syntax.py`, `arithmetic.py`, `hilbert.py`, `check.py` | 1,677 | 1,816 |
| d09 | `ipra_small_kernel_2026-11-06.zip` | `kernel.py` + `check_certificate.py` | 1,937 | 2,150 |
| d10 | `ipra_two_binders_2026-11-06.zip` | `code/shared.py` + `code/check.py` | 1,833 | 1,929 |

The d07 version with genuine falsity is 2,123 tokens / 2,238 AST nodes with
the same JSON driver. The positive d04 and d07 rows are useful smaller proof
representations but require their explicitly stated ordinary-falsity
interface; see the warning below. This does not affect d03's winning size.

Published counts differ slightly from this census where an archive counted
docstrings, normalized its source by `ast.unparse`, or omitted its JSON
driver. For example d04 reports 1,233 tokens after its normalization, whereas
its literal original source has 1,238 under the present convention. d03's
reported 1,167/1,252 is reproduced exactly. These differences should not be
presented as errors without first matching the accounting policy.

The d00 reduced-language variant uses `encoded_kernel.py`. Its 1,896/1,974
row in the JSON includes the common driver's source with its import
understood to be retargeted from `kernel` to `encoded_kernel`; that change
does not alter token or AST counts. It is larger than d00's recommendation
because it charges an ordinary-formula disjunction expansion and a case
rule. The smaller d03 uses its native formula language directly.

## What each proposal actually contributes

### d00: arithmetic supplies reflexivity and explosion

The recommended kernel retains all ordinary first-order intuitionistic
connectives. It uses a native initialized recursor, guarded successor
induction on equations, equality replacement, and the fixed closed bridge
between genuine falsity and `0=S0`. Primitive equality reflexivity and
unrestricted explosion are deleted: a base computation yields reflexivity,
and a numerical selector transports the clash into every equation, after
which structural recursion over formulas yields explosion.

Its optional `encoded_kernel.py` deletes primitive disjunction. A numerical
tag encodes it using existential quantification, conjunction, and
implication. It supplies a separate zero-case principle, so the disjunction
elimination argument is not circular. Native parameter substitution is
accounted for in its interpretation discussion. The recommended full-logic
implementation is smaller than this encoded alternative under that
archive's representation.

### d01: finite logical blocks

Universal implication blocks and existential finite-choice blocks absorb
several conventional logical rules. The smallest matrix representation
admits a finite list of blocks, numerical binder counts, and lists of
premises/conjuncts. Empty forms express truth and falsity. Its two logical
certificate tags are a uniform introduction and elimination interface;
this does not mean only two primitive mathematical inference instances,
since the finite block data is substantive.

The arithmetic is still initialized recursion, separation, equality
reflexivity/replacement, and guarded successor progress on an equation.
The matrix representation saves branches but adds validation of block
lists, binder counts, lengths, and witness lists. Its supplied complete
matrix verifier is smaller than the supplied binary-block verifier
(1,910 versus 2,083 tokens), but larger than d03.

### d02: eliminate disjunction through an arithmetic eliminator

The native formula language has equality, genuine falsity, conjunction,
implication, and both quantifiers. It has frozen first-order recursion
descriptors rather than native term binders. Minimal natural deduction is
supplemented by separation, an arithmetic falsity bridge, and a numerical
schema with arbitrary conclusion A. That schema combines positive
successor equation induction with elimination between a zero case and the
inductive equation case. It establishes numerical case analysis before
proving the encoded disjunction's rules.

The schema implementation is smaller than the contextual-rule
implementation: 1,798 versus 1,844 tokens including the identical JSON
wrapper. The proof makes the necessary distinction between an arbitrary
conclusion in an eliminator and an unrestricted induction invariant. Equality
reflexivity remains primitive, so an already known deletion is still
available in this particular implementation, although this alone cannot
approach d03's size.

### d03: current smallest ordinary presentation

Numerical terms are zero, successor, variables, and a native initialized
recursor `R(n,a;v,w.h)`. Formulas are equality, genuine falsity, and the two
binders `Pi_x(A,B)=forall x(A -> B)` and
`Sigma_x(A,B)=exists x(A and B)`. The four binder rules, hypothesis, and
formula-context equality replacement supply the primitive logical kernel.

A closed two-way conversion exchanges falsity and `0=S0`. Both equality
reflexivity and generic explosion are derived. The `nat` rule has a base
premise and a successor premise; the latter receives an induction
hypothesis only when the template is literally an equation. For all other
formulas the same rule performs zero/successor case analysis. The open
variable namespace removes explicit external arity checks while preserving
eigenvariables by lifting the entire ambient context under a binder.

The report reconstructs ordinary connectives, including disjunction by
zero/successor guarded witnesses. It proves coverage and an arithmetic
equality test without using a quantified induction invariant. It explicitly
addresses substitution into free parameters of native recursion bodies:
translation to fixed first-order descriptors commutes with substitution up
to an internally provable equality, not necessarily literally. This is the
right obligation for genuine whole-carrier bi-interpretability.

No unsound inference was found in the source audit. In particular, every
formula returned by `infer` is well formed provided the context is, the
new variable is protected by `map(shift, g)`, Sigma elimination requires a
lifted outer conclusion, and equation-only induction is enforced by the
literal outer tag. The arbitrary ambient indices are legal free variables,
not escaping local slots.

As a targeted reproduction, `code/test_kernel.py` passed 53 accepted and
24 rejected certificates, with 53 previous-kernel cross-checks and 31
legacy fixtures. `code/adversarial.py` passed 18 independent cases (six
accepted, twelve rejected). These results support the implementation audit;
they are not a formal proof of soundness or of the metatheorem.

### d04: positive Hilbert checker and an ordinary completion

A theorem-list Hilbert presentation deletes equality reflexivity, generic
explosion, a primitive falsity constructor, and separation from the encoded
checker. Its positive language designates the equation `0=S0` as the
contradiction. A native-recursion/de Bruijn variant is smaller than its
frozen-descriptor and natural-deduction variants.

Crucially, the report does not claim ordinary model-theoretic
bi-interpretability of the bare positive theory. Its ordinary realization
adds genuine falsity and the identification `bottom <-> 0=S0`. A displayed
exact proof-translation theorem shows the positive kernel checks encoded
proofs of this realization. This construction already contains the idea of
removing both falsity syntax and the bridge from a certificate checker.
A new use of that idea must be attributed as a combination or adaptation,
not claimed as a new mathematical deletion.

### d05: prior compact Pi/Sigma kernel

This is the predecessor of d03. It supplies a standalone complete
Pi/Sigma verifier with numerical cases, equation induction, and a fixed
arithmetic sentence containing both successor separation and collapse from
falsity. Its final verifier has 1,289 tokens and 1,393 AST nodes. d03 removes
explicit outer-scope arity bookkeeping and simplifies the fixed bridge.

The useful controlled comparator is not only this older verbatim file.
d03 also supplies a 1,171-token / 1,248-AST version after giving it the same
open-scope and recursion-parser changes. Beating only 1,289 does not isolate
a new mathematical or algorithmic saving.

### d06: finite existential rows with frozen declarations

The two-binder presentation uses named-variable universal implications and
existential rows of conjunctions. Finite row choice supplies disjunction;
zero rows supplies genuine falsity. Terms refer to a validated finite table
of earlier recursion declarations, with separate local parameter slots.
The shared code charges declaration validation, free-variable extraction,
capture rejection, equality, computation, separation, and guarded induction.

The row variant is 1,849 tokens, modestly smaller than its fused
universal/existential variant at 1,862. The more substantial difference
from d03 is the representation cost of named binding and declaration
management, not a theory-strength difference.

### d07: falsity boundary is handled explicitly

The arithmetic is frozen initialized recursion and guarded successor
closure. The ordinary recommendation is a reflexivity-free Hilbert
presentation retaining genuine falsity. A bridge variant replaces generic
explosion and separation by a fixed two-way bridge. A still smaller positive
certificate kernel erases falsity, explosion, and separation.

The report explicitly demonstrates that the raw positive theory has
singleton models and distinguishes exact proof-translation equivalence from
ordinary model-theoretic bi-interpretability. Its genuine-falsity and bridge
presentations, rather than its bare positive theory, carry the ordinary
bi-interpretability theorem. This is a useful conceptual constraint on any
new claimed simplification.

### d08: a genuine-falsity Hilbert alternative

This archive is the last addition in the pinned commit. It presents all
fourteen logical axiom schemas and the only two inference rules, modus
ponens and generalization, plus initialized-recursion computation,
separation, and guarded equation closure. A theorem sequence eliminates
context tracking from the main Hilbert loop. Reflexivity is derived.

Its effective term representation uses frozen recursion descriptors,
with descriptor scope validation separated from active substitution.
A matched natural-deduction checker is provided. Its complete Hilbert
implementation has 1,677 tokens / 1,816 AST nodes, appreciably larger than
d03 despite the later upload time. The controlled deletion of primitive
reflexivity saves 24 tokens in its own implementation.

### d09: ordinary natural deduction with an arithmetic falsity bridge

This proposal retains every ordinary connective and replaces primitive
reflexivity, weakening, and explosion by derived transformations. Its
arithmetic is native initialized recursion, the two closed bridge
implications, and guarded successor progress on equations. It emphasizes
robust input handling and explicit external scope sizes. The JSON driver
is separate.

The full literal source plus its driver is 1,937 tokens / 2,150 AST nodes
under the census convention. Its advertised 1,793-token value concerns a
normalized mathematical kernel without the separate driver. Those are
legitimate but different boundaries. The paper's identity-update recursion
simplifications affect proof construction rather than producing a verifier
smaller than d03.

### d10: Pi/Sigma with equation induction and general numerical cases

This is the direct precursor of d03's logical and arithmetic organization.
It uses genuine falsity, Pi/Sigma, native recursion, and a single number rule
whose induction hypothesis is restricted to equations. It retains primitive
reflexivity, generic explosion, separation, and explicit scope size.

The proof develops numerical cases before encoded disjunction, avoiding
circular use of disjunction. Its complete implementation has 1,833 tokens /
1,929 AST nodes. The core design is mathematically compact, but its retained
branches and validation scaffolding cost more than d03.

## Material pitfalls for the new construction

1. **Do not equate an attained minimum with a complexity lower-bound
   theorem.** A fixed finite family yields a measured best upper bound.
   A global minimum is undefined until the implementation language,
   representation, runtime, and what is charged are fixed. A defensible
   statement is that the supplied new checker is no larger than every
   supplied comparator under a stated reproducible measurement.

2. **Falsity erasure changes the ordinary model-theoretic claim.** The raw
   positive calculus with `0=S0` as an external designated contradiction
   has a singleton model. No nonempty finite-power quotient of a singleton
   gives an iPRA model. Exact proof translations with bottom encoded as
   `0=S0`, and provable round-trip equivalences for translated formulas,
   do not by themselves remove this obstruction. Either retain genuine
   bottom and a bridge, or state an ordinary-falsity companion and count the
   full claim encoding as necessary. d04 and d07 already explain this.

3. **Equation induction alone is insufficient.** The coordinatewise model
   on `N x N` satisfies recursion equations, successor separation, and
   equation induction, but has mixed pairs which are neither zero nor
   successors. It invalidates the needed coverage and hence quantifier-free
   induction in the full language. d03's nonequational branch is a real
   case principle; deleting it loses strength.

4. **Native bodies require substitution coherence.** Replacing a free
   parameter inside a native body can alter the fixed descriptor generated
   on elaboration. Use internally proved recursion uniqueness at a fresh
   counter and initializer, with parameters fixed, to prove the relevant
   terms equal. Agreement only at standard numerals is inadequate for
   bi-interpretability, and treating native bodies as frozen labels is a
   different language.

5. **Disjunction must be bootstrapped without circularity.** A tag formula
   alone does not derive its own elimination rule. Prove numerical cases
   independently, then reconstruct disjunction rules, then establish
   quantifier-free reflection and induction. Checking the outer literal
   equation tag prevents induction on an expanded quantified encoding.

6. **The universal-conclusion number rule is a promising controlled
   improvement.** Replace d03's rule conclusion `P(t)` by
   `Pi_x(0=0,P(x))`, then instantiate by the already present Pi elimination.
   This removes the explicit target term and its validation from the number
   rule while preserving its equation-only induction hypothesis. The forward
   direction is generalization of the old fresh-variable instance; the
   reverse direction applies the new rule and supplies derived reflexivity
   at `0=0`. This improvement can be attempted while retaining genuine
   falsity, thereby avoiding any weakened interpretation convention.

No claim is made that every checker or all handwritten metatheory has been
formally verified. The focused soundness inspection and regressions concern
d03, the tight current baseline; the other programs were reviewed for their
architecture, exact TCB boundary, and relevant mathematical distinctions.
