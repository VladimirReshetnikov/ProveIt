"""Untrusted, bidirectional proof translation for the two complete checkers.

The candidate kernel is checker.py.  The fixed comparison kernel is
../comparison/baseline.py (the current d03 natural-deduction checker).
Neither kernel imports this module.  A translated document is accepted only
after the destination kernel independently checks its full certificate.

Forward translation expands an old numerical-rule application into an axiom
leaf and ordinary Pi applications.  Reverse translation proves each new
numerical axiom by two Pi introductions and the old numerical rule.  The
forward traversal explicitly embeds assumption indices when an extra base
guard is introduced for a non-equational numerical template.

Usage:
  python3 code/translate.py verify
  python3 code/translate.py verify --source /path/to/d03/certificates
  python3 code/translate.py forward INPUT.json OUTPUT.json
  python3 code/translate.py backward INPUT.json OUTPUT.json
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

import checker as new


ROOT = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location(
    "ipra_comparison_baseline", ROOT / "comparison" / "baseline.py")
if _spec is None or _spec.loader is None:
    raise ImportError("cannot load the fixed comparison checker")
old = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(old)


def to_new_term(a):
    """Translate terms/formulas only: the zero token changes, nothing else."""
    if type(a) is int:
        return a
    if a == ("z",):
        return -1
    return (a[0], *(to_new_term(b) for b in a[1:]))


def to_old_term(a):
    if type(a) is int:
        return ("z",) if a == -1 else a
    return (a[0], *(to_old_term(b) for b in a[1:]))


def _forward(p, source_context, target_context, indices):
    """Maintain target_context[indices[i]] == to_new(source_context[i]).

    Inserting an assumption does not bind a numerical variable.  Numerical
    lifting occurs only at the same original Pi, Sigma and numerical-rule
    binders.  The index embedding is extended whenever a child appends its
    own local assumptions, so those local assumptions cannot be captured by
    an inserted numerical base guard.
    """
    def child(q):
        return _forward(q, source_context, target_context, indices)

    match p:
        case ("hyp", i):
            return ("hyp", indices[i])
        case ("pi", a, q):
            b = to_new_term(a)
            return ("pi", b, _forward(
                q, (*map(old.shift, source_context), a),
                (*map(new.shift, target_context), b),
                (*indices, len(target_context))))
        case ("app", principal, t, argument):
            return ("app", child(principal), to_new_term(t), child(argument))
        case ("pair", a, t, left, right):
            return ("pair", to_new_term(a), to_new_term(t),
                    child(left), child(right))
        case ("let", principal, c, branch):
            a = old.infer(principal, source_context)
            b = to_new_term(a)
            return ("let", child(principal), to_new_term(c), _forward(
                branch, (*map(old.shift, source_context), a[1], a[2]),
                (*map(new.shift, target_context), b[1], b[2]),
                (*indices, len(target_context), len(target_context) + 1)))
        case ("bridge", premise):
            return ("bridge", child(premise))
        case ("eq", equality, template, premise):
            return ("eq", child(equality), to_new_term(template), child(premise))
        case ("rec", r):
            return ("rec", to_new_term(r))
        case ("nat", a, t, base, step):
            b = to_new_term(a)
            atomic = a[0] == "="
            guard = b if atomic else new.shift(new.inst(b, new.ZERO))
            source_hypotheses = (a,) if atomic else ()
            step_indices = (*indices, len(target_context)) if atomic else indices
            translated_step = _forward(
                step, (*map(old.shift, source_context), *source_hypotheses),
                (*map(new.shift, target_context), guard), step_indices)
            step_proof = ("pi", guard, translated_step)
            with_base = ("app", ("nat", b), to_new_term(t), child(base))
            return ("app", with_base, new.ZERO, step_proof)
        case _:
            raise ValueError("unknown baseline proof constructor")


def numerical_axiom_in_old(a, context_length):
    """An old-kernel proof of the candidate's zero-premise numerical axiom.

    After the two Pi introductions, numerical variables 0 and 1 are the
    dummy implication binder and the axiom's outer number x.  Old induction
    adds a further fresh variable.  Original parameters of the equation or
    case template must consequently move two slots while its distinguished
    slot 0 remains the induction variable.
    """
    base = old.shift(old.inst(a, old.ZERO))
    atomic = a[0] == "="
    guard = a if atomic else base
    successor = old.subst(a, lambda i: ("s", 0) if i == 0 else i)
    step = ("pi", guard, successor)
    template = old.subst(a, lambda i: 0 if i == 0 else i + 2)
    minor = context_length + 2 if atomic else context_length
    rule_step = ("app", ("hyp", context_length + 1), 0, ("hyp", minor))
    rule = ("nat", template, 1, ("hyp", context_length), rule_step)
    return ("pi", base, ("pi", old.shift(step, 2), rule))


def _backward(p, context):
    def child(q):
        return _backward(q, context)

    match p:
        case ("hyp", i):
            return ("hyp", i)
        case ("pi", a, q):
            return ("pi", to_old_term(a), _backward(
                q, (*map(new.shift, context), a)))
        case ("app", principal, t, argument):
            return ("app", child(principal), to_old_term(t), child(argument))
        case ("pair", a, t, left, right):
            return ("pair", to_old_term(a), to_old_term(t),
                    child(left), child(right))
        case ("let", principal, c, branch):
            a = new.infer(principal, context)
            return ("let", child(principal), to_old_term(c), _backward(
                branch, (*map(new.shift, context), a[1], a[2])))
        case ("bridge", premise):
            return ("bridge", child(premise))
        case ("eq", equality, template, premise):
            return ("eq", child(equality), to_old_term(template), child(premise))
        case ("rec", r):
            return ("rec", to_old_term(r))
        case ("nat", a):
            return numerical_axiom_in_old(to_old_term(a), len(context))
        case _:
            raise ValueError("unknown candidate proof constructor")


def forward(document):
    """Validate the baseline input, translate it, and check exact output."""
    old.check(document)
    g = tuple(map(old.freeze, document["assumptions"]))
    h = tuple(map(to_new_term, g))
    goal = to_new_term(old.freeze(document["goal"]))
    proof = _forward(old.freeze(document["proof"]), g, h, tuple(range(len(g))))
    result = {"assumptions": list(h), "goal": goal, "proof": proof}
    new.check(result)
    return result


def backward(document):
    """Validate the candidate input and check its baseline proof expansion."""
    new.check(document)
    g = tuple(map(new.freeze, document["assumptions"]))
    goal = to_old_term(new.freeze(document["goal"]))
    proof = _backward(new.freeze(document["proof"]), g)
    result = {"assumptions": list(map(to_old_term, g)), "goal": goal, "proof": proof}
    old.check(result)
    return result


def _bytes(document):
    return (json.dumps(document, separators=(",", ":")) + "\n").encode("utf-8")


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _size(document):
    return len(_bytes(document))


def _proof_counts(p, result=None):
    """Count proof constructors without mistaking formula tags for rules."""
    result = {} if result is None else result
    tag = p[0]
    result[tag] = result.get(tag, 0) + 1
    positions = {
        "hyp": (), "pi": (2,), "app": (1, 3), "pair": (3, 4),
        "let": (1, 3), "bridge": (1,), "eq": (1, 3), "rec": (),
        "nat": (3, 4) if len(p) == 5 else (),
    }
    for index in positions[tag]:
        _proof_counts(p[index], result)
    return result


def extra_baseline_cases():
    """Exercise context insertion below both Pi and Sigma proof binders."""
    eq = ("=", 0, 0)
    identity = ("pi", eq, eq)
    sigma = ("sig", eq, eq)
    g = [sigma]
    intro = ("pi", eq, ("hyp", 1))
    branch = ("let", ("hyp", 0), identity, ("pi", eq, ("hyp", 3)))
    cases = {}
    for name, step in (("insert_guard_under_pi", intro),
                       ("insert_guard_under_sigma_and_pi", branch)):
        p = ("nat", identity, old.ZERO, intro, step)
        cases[name] = {"assumptions": g, "goal": identity, "proof": p}
    return cases


def extra_candidate_cases():
    """Direct schema leaves, including all non-equational outer shapes."""
    eq = ("=", 0, ("r", 1, -1, ("s", 0)))
    templates = {
        "schema_equation_parameters": eq,
        "schema_falsity": new.FALSE,
        "schema_pi_with_parameters": ("pi", ("=", 1, 2), ("=", 0, 2)),
        "schema_sigma_with_parameters": ("sig", ("=", 0, 1), eq),
        "schema_nested_recursors": ("=", ("r", 0, 1,
            ("r", 1, 2, ("s", 0))), ("r", 2, -1, 0)),
    }
    cases = {}
    for name, a in templates.items():
        for length in (0, 2):
            g = [("=", 0, 1), ("pi", new.FALSE, ("=", 1, 1))][:length]
            p = ("nat", a)
            cases[f"{name}_context_{length}"] = {
                "assumptions": g, "goal": new.infer(p, tuple(g)), "proof": p}
    return cases


def verify_corpus(source=None):
    """Check the entire bundled corpus in both directions and save evidence."""
    directory = ROOT / "certificates" / "translations"
    baseline_dir = directory / "baseline"
    candidate_dir = directory / "candidate"
    generated_dir = directory / "generated"
    for path in (baseline_dir, candidate_dir, generated_dir):
        path.mkdir(parents=True, exist_ok=True)
    source = baseline_dir if source is None else Path(source)
    paths = sorted(source.glob("*.json"))
    if not paths:
        raise ValueError("the baseline certificate directory is empty")
    results = []
    totals = {"baseline_bytes": 0, "candidate_bytes": 0,
              "roundtrip_baseline_bytes": 0, "old_numerical_applications": 0}
    for path in paths:
        document = json.loads(path.read_text())
        translated = forward(document)
        returned = backward(translated)
        assert old.freeze(returned["goal"]) == old.freeze(document["goal"])
        assert old.freeze(returned["assumptions"]) == old.freeze(document["assumptions"])
        assert to_new_term(to_old_term(new.freeze(translated["goal"]))) == new.freeze(translated["goal"])
        (baseline_dir / path.name).write_bytes(_bytes(document))
        (candidate_dir / path.name).write_bytes(_bytes(translated))
        counts = _proof_counts(old.freeze(document["proof"]))
        sizes = {"baseline_bytes": _size(document),
                 "candidate_bytes": _size(translated),
                 "roundtrip_baseline_bytes": _size(returned)}
        for key, value in sizes.items():
            totals[key] += value
        totals["old_numerical_applications"] += counts.get("nat", 0)
        results.append({"name": path.name, "baseline_accepted": True,
                        "candidate_accepted": True, "reverse_accepted": True,
                        "roundtrip_goal_and_context_exact": True,
                        "candidate_sha256": _sha(candidate_dir / path.name),
                        "old_numerical_applications": counts.get("nat", 0), **sizes})
    extra = []
    for name, document in extra_baseline_cases().items():
        translated = forward(document)
        returned = backward(translated)
        assert old.freeze(returned["goal"]) == old.freeze(document["goal"])
        assert old.freeze(returned["assumptions"]) == old.freeze(document["assumptions"])
        (generated_dir / f"{name}.json").write_bytes(_bytes(translated))
        extra.append({"name": name, "direction": "old-new-old", "passed": True})
    for name, document in extra_candidate_cases().items():
        translated = backward(document)
        returned = forward(translated)
        assert new.freeze(returned["goal"]) == new.freeze(document["goal"])
        assert new.freeze(returned["assumptions"]) == new.freeze(document["assumptions"])
        (generated_dir / f"{name}.json").write_bytes(_bytes(document))
        extra.append({"name": name, "direction": "new-old-new", "passed": True})
    report = {
        "status": "passed", "corpus_count": len(results),
        "extra_case_count": len(extra), "totals": totals,
        "candidate_checker_sha256": _sha(ROOT / "code" / "checker.py"),
        "baseline_checker_sha256": _sha(ROOT / "comparison" / "baseline.py"),
        "compiler_sha256": _sha(Path(__file__)),
        "method": "Each source and translated certificate is checked by its own complete kernel. Exact goals and contexts are compared after both round trips.",
        "scope": "Finite certificate replay; this supports, but does not replace, the general proof-translation theorem.",
        "corpus": results, "extra_cases": extra,
    }
    report_path = ROOT / "verification" / "translation_results.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    verify = commands.add_parser("verify")
    verify.add_argument("--source", type=Path)
    for command in ("forward", "backward"):
        action = commands.add_parser(command)
        action.add_argument("input", type=Path)
        action.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.command == "verify":
        report = verify_corpus(args.source)
        print(json.dumps({key: report[key] for key in
                          ("status", "corpus_count", "extra_case_count", "totals")}))
    else:
        document = json.loads(args.input.read_text())
        result = forward(document) if args.command == "forward" else backward(document)
        args.output.write_bytes(_bytes(result))
        print(json.dumps({"accepted": True, "output": str(args.output)}))


if __name__ == "__main__":
    main()
