"""Reproduce complete-checker source counts; no proof-generation code is trusted."""

import ast
import hashlib
import io
import json
from pathlib import Path
import tokenize

ROOT = Path(__file__).resolve().parent


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in list(ast.walk(tree)):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body.pop(0)
                spans.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    ignored = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
               tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
    tokens = [token for token in tokenize.generate_tokens(io.StringIO(source).readline)
              if token.type not in ignored
              and not any(a <= token.start and token.end <= b for a, b in spans)]
    return {
        "bytes": len(data),
        "physical_lines": len(source.splitlines()),
        "meaningful_python_tokens": len(tokens),
        "token_characters": sum(len(token.string) for token in tokens),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_code_bytes": len((ast.unparse(tree) + "\n").encode()),
        "sha256": hashlib.sha256(data).hexdigest(),
    }


def main():
    census = json.loads((ROOT / "provenance/draft_census.json").read_text())
    previous = []
    for row in census["rows"]:
        parts = []
        for item in row["files"]:
            result = measure(ROOT / "comparison/drafts" / row["id"] / item["file"])
            if result["sha256"] != item["sha256"]:
                raise ValueError("Changed comparison source: " + item["file"])
            parts.append(result)
        totals = {key: sum(item[key] for item in parts)
                  for key in parts[0] if key != "sha256"}
        for key in ("meaningful_python_tokens", "ast_nodes", "token_characters"):
            if totals[key] != row[key]:
                raise ValueError("Census mismatch: " + row["id"])
        previous.append({"id": row["id"], "label": row["label"], **totals})
    variants = [{"file": file, **measure(ROOT / file)} for file in (
        "comparison/baseline.py", "comparison/baseline_sentinel.py",
        "comparison/schema_tagged_zero.py", "code/checker.py")]
    old, new = variants[0], variants[-1]
    result = {
        "source_commit": census["source_commit"],
        "boundary": "Every line of each complete checker, including syntax validation, binding operations, schema data and JSON CLI. Runtime/stdlib, proof compilers, tests and this counter are excluded equally.",
        "counting": "Exclude comments, layout tokens, and genuine module/function/class docstrings. Count all executable syntax and fixed data. AST nodes use the same docstring deletion. Normalized bytes use ast.unparse.",
        "previous": previous,
        "variants": variants,
        "savings": {key: {"absolute": old[key] - new[key],
                           "percent": round(100 * (old[key] - new[key]) / old[key], 6)}
                    for key in ("meaningful_python_tokens", "ast_nodes", "normalized_code_bytes")},
        "minimum_previous_tokens": min(row["meaningful_python_tokens"] for row in previous),
        "minimum_previous_ast": min(row["ast_nodes"] for row in previous),
        "limitation": "Finite, reproducible implementation comparison; no encoding-independent lower-bound or global minimality theorem.",
    }
    (ROOT / "verification/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"candidate": new, "savings": result["savings"],
                      "census_variants": len(previous)}, indent=2))


if __name__ == "__main__":
    main()
