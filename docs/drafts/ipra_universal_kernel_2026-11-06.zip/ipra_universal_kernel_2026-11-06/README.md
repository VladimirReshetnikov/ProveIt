# A smaller complete iPRA checker

This package specifies the theory **U**, proves its ordinary whole-domain
bi-interpretability and equiconsistency with intuitionistic primitive
recursive arithmetic, and supplies a complete executable proof checker.

The checker has **1,139 significant Python tokens and 1,220 AST nodes**.
The previous smallest supplied production checker has 1,167 tokens and
1,252 nodes; a nearby comparison variant has 1,248 nodes. The new checker
is below both measured thresholds. These are finite source comparisons,
not a global minimality theorem.

## Main change

The native numerical rule is replaced by a zero-premise axiom schema:

    forall x (A(0) -> (Q_A -> A(x)))
    Q_A = forall y (H_A(y) -> A(Sy))
    H_A(y) = A(y) for literal equations, and A(0) otherwise.

The same logical rules used for other formulas now check the premises,
fresh variables, and target instantiation of numerical arguments.
The non-equation case is constructor case analysis, not unrestricted
induction. An independent serialization change encodes number zero by
the integer token -1, while nonnegative integer tokens are variables.
Both changes are measured separately in the report and source variants.

Genuine logical falsity and its two-way bridge to `0 = S0` are retained.
This avoids the singleton-model obstruction of bare positive theories.

## Read and run

- `report.pdf`: the complete mathematical report.
- `report.tex`: its LaTeX source, with generated verification text in
  `verification/summary.tex`.
- `code/checker.py`: the entire trusted mathematical checker and JSON CLI.
- `code/translate.py`: untrusted bidirectional proof compiler; both source
  and output certificates are independently checked by their kernels.
- `comparison/baseline.py`: exact prior production checker.
- `comparison/baseline_sentinel.py` and `comparison/schema_tagged_zero.py`:
  matched variants isolating the two reductions.
- `comparison/drafts/`: all original sources used for the census.
- `provenance/`: exact archive identities, paths, and hashes.
- `verification/`: independent audit, test results, and reproducible counts.
- `certificates/`: ready-to-check examples and the translation corpus.

Python 3.10 or later is required. Checker and test code use only the
standard library. From this directory:

```bash
python3 reproduce.py
python3 code/checker.py certificates/derived_reflexivity.json
python3 code/checker.py certificates/induction_addition.json
```

The checker prints `ACCEPT` with exit status 0 for an accepted certificate.
Its input object has exactly `assumptions`, `goal`, and `proof`. Free number
variables are allowed in these judgments. A claim is a theorem when its
assumption list is empty; open number parameters can then be generalized.

Translate individual certificates:

```bash
python3 code/translate.py forward old.json new.json
python3 code/translate.py backward new.json expanded_old.json
```

Recount all included comparison files:

```bash
python3 measure.py
```

Rebuild the report (a standard LaTeX installation is required):

```bash
pdflatex -halt-on-error report.tex
pdflatex -halt-on-error report.tex
```

## Verification scope

The reproduction run checks 53 baseline certificates forward and backward,
with exact round-trip goals and assumptions, and 12 additional round-trip
cases. The independent named-variable oracle checks 307 acceptance/rejection
cases, 509 binding/substitution comparisons, and 72 numerical templates.
The mathematical proofs are in the report. The package does not claim a
Lean or Rocq formalization of the checker soundness or bi-interpretability
metatheorem.

## Provenance and attribution

Input repository: `VladimirReshetnikov/ProveIt`, `docs/drafts`, commit
`b079e5787b1d708049ff0643ce1b534c1a225198`.

The two-binder logic, native recursion, closed falsity bridge, and arithmetic
reconstruction are inherited from the supplied `ipra_kernel_2026-11-06.zip`
draft and credited in the report. The new contributions are the numerical
axiom reduction, the separate zero serialization reduction, their complete
implementation, the current eleven-archive census, the proof compilers,
and the verification included here. The original-source copies retain
their original contents and are used for reproducible comparison.

No repository changes are required to use this archive.
