PRA FROM ONE TWO-TERM SCHEMA
Research package prepared for Vladimir Reshetnikov
1 November 2026 (America/Los_Angeles)

MAIN RESULT
One direct two-term schema replaces the best current draft's two matrix
constructors. Computation laws are attached to propagation conclusions
using h_s(v)=s(v,v); reflexive inputs recover every computation descriptor.
The same specification is definitionally equivalent to matching classical
or intuitionistic first-order PRA. Both interpretations and both internal
identity round trips are proved in the report.

This is a simplification of the full axiom generator. It is not an absolute
minimum or an assertion that every emitted formula is shorter.

CONTENTS
report.pdf                  Compiled research paper, complete proofs.
report.tex                  Main LaTeX source.
sections/*.tex              All included source sections.
AXIOMS.txt                  Standalone complete nonlogical specification.
formal/Compression.lean      Verified Lean 4.19.0 constructive compression.
formal/check.txt             Actual compiler/version/axiom-audit output.
formal/SCOPE.txt             Exact formalization boundary.
formal/INDEPENDENT_REVIEW.txt Independent audit of the new reduction.
checks/schema_check.py       Python standard-library syntax generator/checker.
checks/schema_checks.json    Counts, syntax checks, and descriptor ledgers.
checks/schema_examples.txt   Explicit generated formulas and stored bodies.
audit/source_manifest.json  Pinned repository revision and source ZIP hashes.
audit/validation.json        Build and PDF inspection record.
SHA256SUMS.txt               Integrity hashes for the packaged files.
build.sh                    Rebuild the PDF and syntax checks.

REBUILD
Requirements: Python 3; pdfLaTeX plus latexmk with the standard packages
listed in report.tex. The PDF does not require Lean to rebuild.

  sh build.sh

To recheck the separate formal core using Lean 4.19.0:

  lean formal/Compression.lean

The formal file uses Lean's core library only and no external project.
All eight requested axiom reports were empty in the recorded check.

VERIFICATION LIMIT
The Lean file proves the exact diagonal identity, logical schema
compression, and selected bootstrap lemmas. It does not formalize the
complete arithmetic calibration, pairing, PR compiler, bi-interpretation,
or countermodel. Those results are proved mathematically in the report.
The Python checks concern finite syntax and counts, not arithmetic truth.

SOURCES
All five docs/drafts archives at ProveIt commit
104a876e91f8b4d091a3acb4bc79f5dc9942a418 were read.
The strongest previous matrix grammar is pra_zero_or_equation_2026-11-01.
The delayed basis and scalar arithmetic calibration are credited to those
drafts. The new positive contribution is the one-constructor compression;
the negative contribution is the tagged-fiber obstruction to a naive
one-term fixed-target reduction.
