#!/usr/bin/env python3
"""Structural checks and exact AST ledger for the one-constructor PRA schema.

Python 3 standard library only.  This checks syntax, dependency ranks,
substitution, and counts.  It is not a proof checker for the arithmetic
calibration or for bi-interpretability.

Lineage: the baseline formula specifications are transcribed from AXIOMS.txt
in the five ProveIt docs/drafts archives pinned at commit
104a876e91f8b4d091a3acb4bc79f5dc9942a418.  This implementation is new; it does
not import or copy the archives' checker implementations.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple[Term, ...] = ()
    name: str = ""
    body: Term | None = None


def V(name: str) -> Term:
    return Term("var", name=name)


Z = Term("zero")


def S(t: Term) -> Term:
    return Term("succ", (t,))


def D(body: Term, count: Term, seed: Term) -> Term:
    if fv_term(body) - {"v"}:
        raise ValueError("A stored body has an external free input")
    return Term("delay", (count, seed), body=body)


def Hole(name: str, *args: Term) -> Term:
    """Template-only binary term-builder; never an arithmetic primitive."""
    return Term("hole", tuple(args), name=name)


def fv_term(t: Term) -> set[str]:
    if t.tag == "var":
        return {t.name}
    return set().union(*(fv_term(a) for a in t.args))


def subst_term(t: Term, mapping: dict[str, Term]) -> Term:
    """Simultaneous substitution in active arguments; descriptor is frozen."""
    if t.tag == "var":
        return mapping.get(t.name, t)
    return Term(t.tag, tuple(subst_term(a, mapping) for a in t.args),
                t.name, t.body)


def rank(t: Term) -> int:
    """Maximum delayed-symbol dependency rank occurring in a term."""
    ranks = [rank(a) for a in t.args]
    if t.tag == "delay":
        assert t.body is not None
        ranks.append(1 + rank(t.body))
    return max(ranks, default=0)


def validate_term(t: Term, *, allow_holes: bool = False,
                  ancestors: frozenset[int] = frozenset()) -> None:
    if id(t) in ancestors:
        raise ValueError("Cyclic term or stored descriptor")
    next_ancestors = ancestors | {id(t)}
    arities = {"var": 0, "zero": 0, "succ": 1, "delay": 2}
    if t.tag == "hole":
        if not allow_holes or len(t.args) != 2:
            raise ValueError("Template hole in actual source syntax")
    elif t.tag not in arities or len(t.args) != arities[t.tag]:
        raise ValueError("Malformed term constructor")
    if t.tag == "delay":
        if t.body is None or fv_term(t.body) - {"v"}:
            raise ValueError("Illegal stored body")
        validate_term(t.body, allow_holes=allow_holes,
                      ancestors=next_ancestors)
    elif t.body is not None:
        raise ValueError("Only a delayed application may store a body")
    for a in t.args:
        validate_term(a, allow_holes=allow_holes,
                      ancestors=next_ancestors)


@dataclass(frozen=True)
class Formula:
    tag: str
    children: tuple[Formula, ...] = ()
    terms: tuple[Term, ...] = ()
    binder: str = ""


BOT = Formula("bottom")


def Eq(s: Term, t: Term) -> Formula:
    return Formula("eq", terms=(s, t))


def And(a: Formula, b: Formula) -> Formula:
    return Formula("and", (a, b))


def Or(a: Formula, b: Formula) -> Formula:
    return Formula("or", (a, b))


def Imp(a: Formula, b: Formula) -> Formula:
    return Formula("imp", (a, b))


def All(name: str, a: Formula) -> Formula:
    return Formula("all", (a,), binder=name)


def fv_formula(f: Formula) -> set[str]:
    result = set().union(*(fv_term(t) for t in f.terms),
                         *(fv_formula(c) for c in f.children))
    return result - {f.binder} if f.tag == "all" else result


def active_names(f: Formula) -> set[str]:
    result = set().union(*(fv_term(t) for t in f.terms),
                         *(active_names(c) for c in f.children))
    return result | {f.binder} if f.tag == "all" else result


def subst_formula(f: Formula, mapping: dict[str, Term]) -> Formula:
    """Capture-avoiding simultaneous substitution at free occurrences."""
    if f.tag == "all":
        b = f.binder
        body = f.children[0]
        relevant = {k: v for k, v in mapping.items()
                    if k != b and k in fv_formula(body)}
        replacement_names = set().union(*(fv_term(t) for t in relevant.values()))
        if b in replacement_names:
            forbidden = active_names(body) | replacement_names | set(relevant)
            i = 0
            while f"z{i}" in forbidden:
                i += 1
            fresh = f"z{i}"
            body = subst_formula(body, {b: V(fresh)})
            b = fresh
        return All(b, subst_formula(body, relevant))
    return Formula(f.tag,
                   tuple(subst_formula(c, mapping) for c in f.children),
                   tuple(subst_term(t, mapping) for t in f.terms), f.binder)


n, a, v = V("n"), V("a"), V("v")
ONE = S(Z)
SIGMA = Imp(Eq(Z, ONE), BOT)


def diagonal(s: Term) -> Term:
    if fv_term(s) - {"n", "a"}:
        raise ValueError("Input term has more than the two permitted names")
    return subst_term(s, {"n": v, "a": v})


def punctured(s: Term, t: Term) -> Formula:
    if (fv_term(s) | fv_term(t)) - {"n", "a"}:
        raise ValueError("Illegal free variable")
    return Or(Eq(n, Z), Eq(s, t))


def reset(h: Term) -> Formula:
    return Eq(D(h, D(ONE, n, Z), a), a)


def tail(h: Term) -> Formula:
    return Eq(D(h, S(S(n)), a),
              subst_term(h, {"v": D(h, S(n), a)}))


def propagate(f: Formula) -> Formula:
    return All("a", Imp(All("n", Imp(f, subst_formula(f, {"n": S(n)}))),
                        All("n", f)))


def old_dynamic(s: Term, t: Term) -> Formula:
    return propagate(punctured(s, t))


def stationary_matrix(h: Term) -> Formula:
    return And(SIGMA, All("n", And(reset(h), tail(h))))


def old_stationary(h: Term) -> Formula:
    return propagate(stationary_matrix(h))


def uniform(s: Term, t: Term) -> Formula:
    p = punctured(s, t)
    h = diagonal(s)
    progress = All("n", Imp(p, subst_formula(p, {"n": S(n)})))
    conclusion = All("n", And(p, And(SIGMA, And(reset(h), tail(h)))))
    return All("a", Imp(progress, conclusion))


def size_term(t: Term, *, descriptors: bool = False) -> int:
    count = 1 + sum(size_term(a, descriptors=descriptors) for a in t.args)
    if descriptors and t.body is not None:
        count += size_term(t.body, descriptors=True)
    return count


def size_formula(f: Formula, *, descriptors: bool = False) -> int:
    return (1 + sum(size_formula(c, descriptors=descriptors) for c in f.children)
            + sum(size_term(t, descriptors=descriptors) for t in f.terms))


def quantifier_count(f: Formula) -> int:
    return int(f.tag == "all") + sum(quantifier_count(c) for c in f.children)


def quantifier_depth(f: Formula) -> int:
    return int(f.tag == "all") + max((quantifier_depth(c) for c in f.children), default=0)


def has_shadowed_binder(f: Formula, bound: frozenset[str] = frozenset()) -> bool:
    if f.tag == "all":
        return f.binder in bound or has_shadowed_binder(f.children[0], bound | {f.binder})
    return any(has_shadowed_binder(c, bound) for c in f.children)


def encode_term(t: Term) -> list:
    if t.tag == "delay":
        assert t.body is not None
        return ["D", encode_term(t.body), *(encode_term(a) for a in t.args)]
    if t.tag in {"var", "hole"}:
        return [t.tag, t.name, *(encode_term(a) for a in t.args)]
    return [t.tag, *(encode_term(a) for a in t.args)]


def descriptor_id(t: Term) -> str:
    raw = json.dumps(encode_term(t), separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()[:12]


def descriptors_in(formulas: Iterable[Formula]) -> dict[str, Term]:
    found: dict[str, Term] = {}

    def scan_term(t: Term) -> None:
        if t.body is not None:
            key = json.dumps(encode_term(t.body), separators=(",", ":"))
            if key not in found:
                found[key] = t.body
                scan_term(t.body)
        for a in t.args:
            scan_term(a)

    def scan_formula(f: Formula) -> None:
        for t in f.terms:
            scan_term(t)
        for c in f.children:
            scan_formula(c)

    for f in formulas:
        scan_formula(f)
    return found


def ledger(formulas: Iterable[Formula]) -> dict[str, int | bool]:
    formulas = tuple(formulas)
    ds = descriptors_in(formulas)
    return {
        "active_ast": sum(size_formula(f) for f in formulas),
        "descriptor_tree_ast": sum(size_formula(f, descriptors=True)
                                   for f in formulas),
        "distinct_stored_descriptors": len(ds),
        "descriptor_body_nodes_once": sum(size_term(h) for h in ds.values()),
        "quantifier_occurrences": sum(quantifier_count(f) for f in formulas),
        "maximum_quantifier_depth": max((quantifier_depth(f) for f in formulas), default=0),
        "uses_binder_shadowing": any(has_shadowed_binder(f) for f in formulas),
    }


def term_text(t: Term) -> str:
    if t.tag == "zero":
        return "0"
    if t.tag == "var":
        return t.name
    if t.tag == "succ":
        return f"S({term_text(t.args[0])})"
    if t.tag == "delay":
        assert t.body is not None
        return f"D_{descriptor_id(t.body)}({term_text(t.args[0])},{term_text(t.args[1])})"
    return f"{t.name}({','.join(term_text(a) for a in t.args)})"


def formula_text(f: Formula) -> str:
    if f.tag == "bottom":
        return "false"
    if f.tag == "eq":
        return f"({term_text(f.terms[0])}={term_text(f.terms[1])})"
    if f.tag == "all":
        return f"forall {f.binder}. {formula_text(f.children[0])}"
    op = {"and": "AND", "or": "OR", "imp": "->"}[f.tag]
    return f"({formula_text(f.children[0])} {op} {formula_text(f.children[1])})"


def count_var(t: Term, name: str) -> int:
    return int(t.tag == "var" and t.name == name) + sum(count_var(a, name) for a in t.args)


def check_formula(f: Formula, *, allow_holes: bool = False) -> None:
    for t in f.terms:
        validate_term(t, allow_holes=allow_holes)
    for c in f.children:
        check_formula(c, allow_holes=allow_holes)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path,
                        help="Write schema_checks.json and schema_examples.txt here")
    args = parser.parse_args()

    predecessor = D(S(v), v, Z)
    samples = {
        "n_a": (n, a),
        "Sn_a": (S(n), a),
        "zero_zero": (Z, Z),
        "a_n": (a, n),
        "nested": (D(predecessor, S(n), S(a)), D(S(v), a, n)),
        "both_inputs": (D(S(v), n, a), D(ONE, a, n)),
    }
    rows = {}
    output_examples = []
    for name, (s, t) in samples.items():
        h = diagonal(s)
        validate_term(h)
        assert fv_term(h) <= {"v"}
        assert rank(h) == rank(s)
        assert rank(D(h, n, a)) == rank(s) + 1
        new = uniform(s, t)
        old_g, old_c = old_dynamic(s, t), old_stationary(h)
        bootstrap = uniform(s, s)
        for f in (new, old_g, old_c, bootstrap):
            check_formula(f)
            assert not fv_formula(f)
            assert active_names(f) <= {"n", "a"}
        assert subst_formula(stationary_matrix(h), {"n": S(n)}) == stationary_matrix(h)
        assert quantifier_count(new) == 3
        assert quantifier_depth(new) == 2
        assert not has_shadowed_binder(new)
        assert quantifier_count(old_c) == 6
        assert quantifier_depth(old_c) == 3
        assert has_shadowed_binder(old_c)

        L = size_term(s) + size_term(t)
        k = count_var(s, "n") + count_var(t, "n")
        r, tau = size_formula(reset(h)), size_formula(tail(h))
        assert r == 7
        assert tau == 6 + size_term(s) + 3 * (count_var(s, "n") + count_var(s, "a"))
        assert size_formula(old_g) == 21 + 3 * L + k
        assert size_formula(old_c) == 32 + 3 * r + 3 * tau
        assert size_formula(new) == 30 + 3 * L + k + r + tau
        assert size_formula(old_g) + size_formula(old_c) - size_formula(new) == 23 + 2 * r + 2 * tau

        rows[name] = {
            "s": term_text(s), "t": term_text(t),
            "diagonal": term_text(h), "input_rank": rank(s),
            "attached_symbol_rank": rank(s) + 1,
            "old_dynamic": ledger([old_g]), "old_stationary": ledger([old_c]),
            "old_pair": ledger([old_g, old_c]),
            "new_single": ledger([new]),
            "new_equivalent_pair": ledger([new, bootstrap]),
        }
        output_examples.append(f"[{name}]\n" + formula_text(new))
        for body in sorted(descriptors_in([new]).values(), key=lambda x: (rank(x), descriptor_id(x))):
            output_examples.append(f"  D_{descriptor_id(body)} body: {term_text(body)}; rank {1 + rank(body)}")

    unary_bodies = [Z, ONE, v, S(v), predecessor,
                    D(predecessor, S(v), S(v)),
                    D(D(S(v), v, Z), D(ONE, v, Z), S(v))]
    extraction_checks = []
    for h in unary_bodies:
        validate_term(h)
        s = subst_term(h, {"v": n})
        assert diagonal(s) == h
        f = uniform(s, s)
        conclusion = f.children[0].children[1]
        assert conclusion.tag == "all" and conclusion.binder == "n"
        body = conclusion.children[0]
        assert body.children[0] == punctured(s, s)
        assert body.children[1] == And(SIGMA, And(reset(h), tail(h)))
        # The schema's progress has a reflexive right disjunct at its target.
        progress = f.children[0].children[0].children[0]
        target_eq = progress.children[1].children[1]
        assert target_eq.terms[0] == target_eq.terms[1]
        extraction_checks.append({"body": term_text(h), "rank": rank(h),
                                  "exact_diagonal_recovery": True})

    # A concrete capture hazard, checked independently of the schema examples.
    hazard = All("a", Eq(n, a))
    repaired = subst_formula(hazard, {"n": a})
    assert repaired.binder != "a"
    assert fv_formula(repaired) == {"a"}
    assert repaired.children[0] == Eq(a, V(repaired.binder))
    # Stored descriptors are immutable under substitutions in active terms.
    stored = D(D(S(v), v, Z), n, a)
    changed = subst_term(stored, {"n": a, "a": n, "v": Z})
    assert changed.body == stored.body
    assert changed.args == (a, n)
    assert diagonal(D(S(v), n, a)) == D(S(v), v, v)
    rejected_controls = 0
    for bad_action in (lambda: D(S(V("external")), n, a),
                       lambda: uniform(V("external"), a),
                       lambda: validate_term(Hole("extra", n, a))):
        try:
            bad_action()
        except ValueError:
            rejected_controls += 1
        else:
            raise AssertionError("Malformed source syntax was accepted")
    assert rejected_controls == 3

    # Schematic binary term-builder holes: each application counts one node
    # plus its displayed arguments.  This is a declared template convention,
    # not a total encoding length for a metaprogram.
    sh, th = Hole("s", n, a), Hole("t", n, a)
    template_h = diagonal(sh)
    template_forms = [old_dynamic(sh, th), old_stationary(template_h),
                      uniform(sh, th), uniform(sh, sh)]
    for f in template_forms:
        check_formula(f, allow_holes=True)
    assert [size_formula(f) for f in template_forms] == [41, 98, 72, 72]

    result = {
        "scope": "Structural and arithmetic-of-syntax checks; not a formal proof of PRA equivalence.",
        "baseline_commit": "104a876e91f8b4d091a3acb4bc79f5dc9942a418",
        "actual_source_examples_checked": len(samples),
        "reflexive_descriptor_extractions_checked": len(unary_bodies),
        "capture_hazard_checked": True,
        "stored_descriptor_freezing_checked": True,
        "malformed_syntax_controls_rejected": rejected_controls,
        "sample_ledger": rows,
        "template_with_binary_term_builder_holes": {
            "old_dynamic": ledger([template_forms[0]]),
            "old_stationary": ledger([template_forms[1]]),
            "old_pair": ledger(template_forms[:2]),
            "new_single": ledger([template_forms[2]]),
            "new_equivalent_pair": ledger(template_forms[2:]),
        },
        "counting_caveat": "The old pair entails the new single, but they are not asserted equivalent as finite axiom sets. Equivalent comparison uses the extra reflexive new instance. No uniform instancewise size decrease is claimed.",
    }
    rendered = json.dumps(result, indent=2) + "\n"
    if args.out:
        args.out.mkdir(parents=True, exist_ok=True)
        (args.out / "schema_checks.json").write_text(rendered)
        (args.out / "schema_examples.txt").write_text("\n\n".join(output_examples) + "\n")
    print(rendered)


if __name__ == "__main__":
    main()
