#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build
python3 checks/schema_check.py --out checks > build/schema_stdout.json
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build report.tex
cp build/report.pdf report.pdf
