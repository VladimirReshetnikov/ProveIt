/-
PRA by one attached schema: constructive logical and syntactic core.

Lean 4.19.0, core library only.

Scope:
  * finite unary descriptors and two-variable active terms;
  * diagonal substitution leaves stored descriptor bodies frozen;
  * exact syntactic right inverse for diagonal substitution;
  * equivalence of the fused schema with computation + rooted propagation;
  * equation-induction, delayed-seed and successor/coverage extraction.

The complete numerical pairing and PRA bi-interpretation are NOT formalized
here. In particular, the arbitrary valuation used in the compression theorem
is metatheoretic; no object-language quantification over functions is added.
There is no use of classical reasoning, choice, propext, or admitted proofs.
-/

namespace AttachedPRA

/- Unary term syntax. In `delay h x y`, h is the stored unary descriptor.
   Finite trees enforce well-founded descriptor dependency. -/
inductive UnaryTerm where
  | var : UnaryTerm
  | zero : UnaryTerm
  | succ : UnaryTerm → UnaryTerm
  | delay : UnaryTerm → UnaryTerm → UnaryTerm → UnaryTerm
  deriving DecidableEq, Repr

/- Two active variable names, n and a; descriptor bodies are unary. -/
inductive Term where
  | n : Term
  | a : Term
  | zero : Term
  | succ : Term → Term
  | delay : UnaryTerm → Term → Term → Term
  deriving DecidableEq, Repr

/- s(v,v): substitute into active arguments, never into stored h. -/
def diagonal : Term → UnaryTerm
  | .n => .var
  | .a => .var
  | .zero => .zero
  | .succ s => .succ (diagonal s)
  | .delay h s t => .delay h (diagonal s) (diagonal t)

/- h(n): rename its sole active variable to n, leaving stored bodies frozen. -/
def liftUnary : UnaryTerm → Term
  | .var => .n
  | .zero => .zero
  | .succ h => .succ (liftUnary h)
  | .delay h s t => .delay h (liftUnary s) (liftUnary t)

theorem diagonal_lift (h : UnaryTerm) : diagonal (liftUnary h) = h := by
  induction h with
  | var => rfl
  | zero => rfl
  | succ h ih => exact congrArg UnaryTerm.succ ih
  | delay h s t _ ihs iht =>
      change UnaryTerm.delay h (diagonal (liftUnary s))
        (diagonal (liftUnary t)) = UnaryTerm.delay h s t
      rw [ihs, iht]

section Compression

variable {A : Type} (zero : A) (succ : A → A)
variable (value : Term → A → A → A)
variable (computation : UnaryTerm → A → A → Prop)

def Rooted (s t : Term) (n a : A) : Prop :=
  n = zero ∨ value s n a = value t n a

def Propagation : Prop :=
  ∀ s t a,
    (∀ n, Rooted zero value s t n a → Rooted zero value s t (succ n) a) →
    ∀ n, Rooted zero value s t n a

def AllComputation : Prop := ∀ h n a, computation h n a

def Fused : Prop :=
  ∀ s t a,
    (∀ n, Rooted zero value s t n a → Rooted zero value s t (succ n) a) →
    ∀ n, Rooted zero value s t n a ∧ computation (diagonal s) n a

theorem fused_to_propagation
    (hf : Fused zero succ value computation) : Propagation zero succ value := by
  intro s t a hp n
  exact (hf s t a hp n).1

theorem fused_to_computation
    (hf : Fused zero succ value computation) : AllComputation computation := by
  intro h n a
  have hp : ∀ k, Rooted zero value (liftUnary h) (liftUnary h) k a →
      Rooted zero value (liftUnary h) (liftUnary h) (succ k) a := by
    intro k _
    exact Or.inr rfl
  have hc := (hf (liftUnary h) (liftUnary h) a hp n).2
  rw [diagonal_lift] at hc
  exact hc

theorem basis_to_fused
    (hc : AllComputation computation)
    (hp : Propagation zero succ value) : Fused zero succ value computation := by
  intro s t a progress n
  exact ⟨hp s t a progress n, hc (diagonal s) n a⟩

theorem fused_iff_basis :
    Fused zero succ value computation ↔
    AllComputation computation ∧ Propagation zero succ value := by
  constructor
  · intro hf
    exact ⟨fused_to_computation zero succ value computation hf,
      fused_to_propagation zero succ value computation hf⟩
  · intro h
    exact basis_to_fused zero succ value computation h.1 h.2

end Compression

section InductionKernel

variable {A : Type} (zero : A) (succ : A → A)

/- This lemma is local in E. The arithmetic application chooses an equation.
   It does not assert a schema for arbitrary object-language predicates. -/
theorem equation_induction_of_rooted (E : A → Prop)
    (rooted : (∀ n, (n = zero ∨ E n) → (succ n = zero ∨ E (succ n))) →
      ∀ n, n = zero ∨ E n)
    (base : E zero) (step : ∀ n, E n → E (succ n)) : ∀ n, E n := by
  have resolve : ∀ n, (n = zero ∨ E n) → E n := by
    intro n hn
    cases hn with
    | inl hz => exact hz.symm ▸ base
    | inr he => exact he
  have progress : ∀ n, (n = zero ∨ E n) → (succ n = zero ∨ E (succ n)) := by
    intro n hn
    exact Or.inr (step n (resolve n hn))
  intro n
  exact resolve n (rooted progress n)

theorem coverage_of_rooted (pred : A → A)
    (pred_succ : ∀ n, pred (succ n) = n)
    (rooted : (∀ n, (n = zero ∨ n = succ (pred n)) →
      (succ n = zero ∨ succ n = succ (pred (succ n)))) →
      ∀ n, n = zero ∨ n = succ (pred n)) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  apply rooted
  intro n _
  exact Or.inr (congrArg succ (pred_succ n)).symm

theorem successor_injective (pred : A → A)
    (pred_succ : ∀ n, pred (succ n) = n) :
    ∀ x y, succ x = succ y → x = y := by
  intro x y he
  calc
    x = pred (succ x) := (pred_succ x).symm
    _ = pred (succ y) := congrArg pred he
    _ = y := pred_succ y

theorem successor_ne_zero (pred : A → A)
    (pred_zero : pred zero = zero)
    (pred_succ : ∀ n, pred (succ n) = n)
    (sep : zero ≠ succ zero) : ∀ n, succ n ≠ zero := by
  intro n hn
  have hn0 : n = zero := by
    calc
      n = pred (succ n) := (pred_succ n).symm
      _ = pred zero := congrArg pred hn
      _ = zero := pred_zero
  apply sep
  calc
    zero = succ n := hn.symm
    _ = succ zero := congrArg succ hn0

end InductionKernel

section DelayedSeeds

variable {A H : Type} (zero : A) (succ : A → A)
variable (D : H → A → A → A) (body : H → A → A) (oneBody : H)
variable (one_body : ∀ x, body oneBody x = succ zero)
variable (reset : ∀ h n a, D h (D oneBody n zero) a = a)
variable (tail : ∀ h n a, D h (succ (succ n)) a = body h (D h (succ n) a))

include one_body reset tail

theorem seed_one : ∀ h a, D h (succ zero) a = a := by
  intro h a
  have hq : D oneBody (succ (succ zero)) zero = succ zero := by
    calc
      D oneBody (succ (succ zero)) zero =
          body oneBody (D oneBody (succ zero) zero) := tail oneBody zero zero
      _ = succ zero := one_body _
  have hr := reset h (succ (succ zero)) a
  rw [hq] at hr
  exact hr

theorem seed_zero : ∀ h a, D h zero a = a := by
  intro h a
  have hq : D oneBody (succ zero) zero = zero :=
    seed_one zero succ D body oneBody one_body reset tail oneBody zero
  have hr := reset h (succ zero) a
  rw [hq] at hr
  exact hr

end DelayedSeeds

#print axioms diagonal_lift
#print axioms fused_iff_basis
#print axioms equation_induction_of_rooted
#print axioms coverage_of_rooted
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms seed_one
#print axioms seed_zero

end AttachedPRA
