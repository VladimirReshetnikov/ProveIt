# Antichain shadows and integer entropy envelopes

Research note for ProveIt, 25 November 2026.

**Start with `paper.pdf`** (10 pages). `paper.tex` is the complete LaTeX source.

## Results

* Strict half-frequency for a union-closed family of N >= 400 members if at most N^(4/5) are nonminimal. The more general local theorem uses any antichain and its upper shadow inside the family.
* A necessary upper-shadow expansion inequality for any hypothetical counterexample; in particular, nonminimal nonempty members must number at least N^((1+sqrt(5))/4-o(1)).
* Exact integer majorization under arbitrary selected downset-cut capacities, with two algorithms, an example where integrality matters, and a trace-fiber extension.
* Exact simultaneous relative-entropy projection for compatible cuts, strengthening the earlier ProveIt optimized rank-transport bound, including a degree-only correction.

The analytic abundance conclusions use the published Chase–Lovett independent-sampling entropy inequality. All additional inequalities are proved in the manuscript; the finite experiments are supplementary. The general conjecture and publication priority are not established. No new record for the unrestricted asymptotic constant or Lean formalization is claimed.

## Reproduce

Requires Python 3.10+ (standard library only) and a LaTeX installation with `amsmath`, `amsthm`, `lmodern`, `booktabs`, `microtype`, `mathtools`, `hyperref`, and `xcolor`.

```sh
make pdf
make verify
sha256sum -c SHA256SUMS # check the original supplied files before rebuilding
```

`verification.txt` records the actual run; `provenance.md` describes the checked antecedents and search limitations. No repository changes were made.
