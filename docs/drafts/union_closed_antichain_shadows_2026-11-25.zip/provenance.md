# Provenance and novelty limitations

## Repository inspection

The GitHub connector returned the listing of
https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts
on the `main` branch, 25 November 2026. Eight selected ZIP archives were inspected by extracting source entries from the base64 GitHub file responses. This is not a complete audit of all archives or all proofs in them. No repository content was modified.

| Archive | Git blob SHA | Subject inspected |
|---|---|---|
| `union_closed_rank_transport_2026-11-25.zip` | `f4c375d5ae9b7337ed4e542950da3d602be537be` | Exact KL/transport identity, layered and optimized row corrections, third entropy extremum |
| `union_closed_trace_entropy_2026-11-25.zip` | `17cb96f215a550ffe9954ca435da5960ac204434` | Trace prefix relaxation, real water-filling, finite-size frequency bounds |
| `union_closed_refinements_2026-11-25.zip` | `6477927e6fa8d36b4696f74d46a2591001d809a7` | Discrete parity in approximate closure, entropy extremum |
| `union_closed_dense_core_2026-11-25.zip` | `b1c269b2ae1cdb03f91797a2bf840e96730c5934` | Erasure-robust core with at most three omissions |
| `union_closed_joint_laws_2026-11-25.zip` | `c497e7f366a6c29bd2002919c0a5e497d6359133` | Regular linear incidence, local distributions and fluctuations |
| `union_closed_partial_theorems_2026-11-25.zip` | `6e072fb3cad5eb9fd6131db36ada8c2758804ea5` | Degree-four high girth and first-order regular incidence expansion |
| `union_closed_cycle_certificates.zip` | `78e17f9a3659b69b95c53e3c54e0a8f821a365b8` | Local oriented-graph certificates |
| `union_closed_uniform_threshold_2026-11-25.zip` | `14fa30e81e9018fbf4664e4c6a4927f74ef8940a` | Complete uniform-layer forcing criterion |

The rank-transport and trace-entropy manuscripts were the direct antecedents. This note retains their entropy input and rank transport identity rather than claiming them as original. The earlier refinements draft already uses parity, so parity itself is not claimed as new. The new proposed contributions are the local antichain-shadow criterion, the two downset capacities and exact integer prefix envelope using cuts across different linear extensions, the simultaneous KL projection and its degree-only correction, and their extension to trace fibers.

## Public literature

Targeted searches covered minimal members, antichain width and entropy, union-closed trace profiles, and relative-entropy refinements. References include:

* Gilmer, https://arxiv.org/abs/2211.09055
* Chase–Lovett, https://arxiv.org/abs/2211.11689 — established analytic input.
* Costa–Sadhu, https://arxiv.org/abs/2610.02295 — universal lower-bound context.
* Flippen, *Minimal Sets, Union-Closed Families, and Frankl's Conjecture*, https://scholarscompass.vcu.edu/etd/7527/ — a particularly relevant thesis; its full result catalogue was not exhaustively audited.
* https://quantavane.com/major-results/union-closed-sets-conjecture/ — reported further universal numerical result, not independently certified in this note.
* https://en.wikipedia.org/wiki/Union-closed_sets_conjecture — problem overview.

No exact predecessor for the proposed combination was identified in the material reviewed. The literature search was limited; this does not demonstrate that the results have never been published, nor that no existing theorem implies them. The novel claims should be treated as research candidates pending independent review. In particular, improvements in the paper are relative to the specified earlier formulas, not all known methods. The exact envelope and projection refer to their stated relaxations, not a characterization of realizable union-count profiles.
