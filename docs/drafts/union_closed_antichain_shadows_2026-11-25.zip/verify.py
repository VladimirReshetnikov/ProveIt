#!/usr/bin/env python3
"""Exact combinatorial audits; floating-point checks only for displayed entropies.
No external dependencies. The proofs, not this finite search, establish the theorems.
"""
from fractions import Fraction as Q
from itertools import combinations, combinations_with_replacement
from math import comb, log, sqrt
import random


def c2(n):
    return n*(n-1)//2


def hull(xs, ys):
    """Indices of the lower convex hull; x strictly increasing."""
    h = []
    for i in range(len(xs)):
        while len(h) > 1:
            a,b=h[-2:]
            if (ys[b]-ys[a])*(xs[i]-xs[b]) < (ys[i]-ys[b])*(xs[b]-xs[a]):
                break
            h.pop()
        h.append(i)
    return h


def integer_envelope(K):
    """Largest convex integer prefix <= K, given feasibility."""
    n=len(K)-1
    h=hull(list(range(n+1)),K)
    out=[None]*(n+1)
    intercept={}
    for a,b in zip(h,h[1:]):
        num=K[b]-K[a]; den=b-a
        slopes={num//den, -(-num//den)}
        for d in slopes:
            if d not in intercept:
                intercept[d]=min(v-d*i for i,v in enumerate(K))
        for j in range(a,b+1):
            v=max(d*j+intercept[d] for d in slopes)
            if out[j] is not None: assert out[j]==v
            out[j]=v
    assert out[0]==K[0] and out[-1]==K[-1]
    assert all(out[j]<=K[j] for j in range(n+1))
    z=[b-a for a,b in zip(out,out[1:])]
    assert z==sorted(z) and min(z)>=0
    return out


def slow_envelope(K):
    P=K[:]
    while True:
        old=P[:]
        for j in range(1,len(P)-1):
            P[j]=min(P[j],(P[j-1]+P[j+1])//2)
        if P==old: return P


def prefix(z):
    P=[0]
    for x in z: P.append(P[-1]+x)
    return P


def envelope_counts(K):
    P=integer_envelope(K)
    return [1+2*(b-a) for a,b in zip(P,P[1:])]


def is_uc(F):
    S=set(F)
    return all(a|b in S for a,b in combinations(F,2))


def subset(a,b): return a&b==a


def counts(F):
    r={x:1 for x in F}
    for a,b in combinations(F,2): r[a|b]+=2
    return r


def cut_bounds(order):
    K=[0]
    for j in range(1,len(order)+1):
        I=order[:j]
        mx=[v for v in I if not any(v!=w and subset(v,w) for w in I)]
        ds=[sum(subset(u,v) for u in I) for v in mx]
        E=sum(j-d for d in ds)-c2(len(mx))
        # Both upper bounds count unordered pairs with union in the ideal.
        K.append(min(c2(j)-E,sum(c2(d) for d in ds)))
    assert K[-1]==c2(len(order))
    return K


def relative_projection(K):
    """Optimal relaxed relative-entropy profile in ordered-pair counts."""
    n=len(K)-1
    C=[j*j for j in range(n+1)]
    B=[j+2*K[j] for j in range(n+1)]
    h=hull(C,B)
    v=[]
    for a,b in zip(h,h[1:]):
        slope=Q(B[b]-B[a],C[b]-C[a]); assert slope>0
        v.extend(slope*(2*i-1) for i in range(a+1,b+1))
    assert sum(v)==n*n
    assert all(x<=y for x,y in zip(prefix(v),B))
    return v


def H(r):
    t=sum(r)
    return log(t)-sum(float(x/t)*log(float(x)) for x in r if x)


def KL(r,c):
    t=sum(r); assert t==sum(c)
    return sum(float(x/t)*log(float(x/y)) for x,y in zip(r,c) if x)


def mincap(n,a):
    return [0]+[0 if j<=a else c2(j) for j in range(1,n+1)]


def audit_family(F):
    n=len(F); r=counts(F); c=list(range(1,2*n,2)); actual=sorted(r.values())
    P=prefix([(x-1)//2 for x in actual])
    o1=sorted(F,key=lambda x:(x.bit_count(),x))
    o2=sorted(F,key=lambda x:(x.bit_count(),-x))
    K1=cut_bounds(o1); K2=cut_bounds(o2)
    K=[min(a,b) for a,b in zip(K1,K2)]
    for order,cap in [(o1,K1),(o2,K2)]:
        raw=[r[x] for x in order]
        rawP=prefix([(v-1)//2 for v in raw])
        assert all(x<=y for x,y in zip(rawP,cap))
        v=relative_projection(cap)
        assert KL(raw,c)+1e-10>=KL(v,c)
        E=[c2(j)-cap[j] for j in range(n+1)]
        transport=2*sum(E[j]*log(c[j]/c[j-1]) for j in range(1,n))/n**2
        assert H(c)-H(raw)+1e-10>=KL(v,c)+transport
    E=integer_envelope(K)
    assert E==slow_envelope(K)
    assert all(x<=y for x,y in zip(P,E))
    assert H(actual)<=H(envelope_counts(K))+1e-10
    a=sum(not any(u!=v and subset(u,v) for u in F) for v in F)
    if n>1:
        K0=mincap(n,a); p0=integer_envelope(K0)
        assert p0==slow_envelope(K0)
        assert all(x<=y for x,y in zip(P,p0))
    return K1,K,actual


def exhaustive():
    total=0; strict=0; parity=None; multicut=None
    for d in range(1,5):
        cnt=0
        for mask in range(1,1<<(1<<d)):
            F=[i for i in range(1<<d) if mask>>i&1]
            if not is_uc(F): continue
            cnt+=1
            K1,K,r=audit_family(F)
            if any(K[j]<c2(j) for j in range(len(K))): strict+=1
            if parity is None and len(F)>1:
                h=hull(list(range(len(K))),K)
                if any((K[b]-K[a])%(b-a) for a,b in zip(h,h[1:])):
                    parity=(F,K,envelope_counts(K),r)
            if multicut is None and len(F)>2:
                c=list(range(1,2*len(F),2)); J=KL(relative_projection(K1),c)
                one=[]
                for j in range(1,len(F)):
                    k=[c2(i) for i in range(len(F)+1)];k[j]=K1[j]
                    one.append(KL(relative_projection(k),c))
                if J>max(one)+1e-8:
                    multicut=(F,K1,str(J),str(max(one)),[str(x) for x in relative_projection(K1)])
        print(f'ground size {d}: {cnt} nonempty union-closed families audited')
        total+=cnt
    print('total:',total,'with a strict cut below chain capacity:',strict)
    print('first parity example:',parity)
    print('first strict multi-cut example:',multicut)


def arbitrary_caps():
    """Brute-force exact comparison on random feasible small prefix instances."""
    rng=random.Random(20261125); num=0
    for n in range(2,7):
        T=c2(n)
        profiles=[prefix(x) for x in combinations_with_replacement(range(T+1),n) if sum(x)==T]
        for _ in range(60):
            p=rng.choice(profiles)
            K=[0]+[rng.randint(p[j],max(p[j],T)) for j in range(1,n)]+[T]
            q=integer_envelope(K)
            brute=[max(x[j] for x in profiles if all(v<=k for v,k in zip(x,K))) for j in range(n+1)]
            assert q==brute==slow_envelope(K);num+=1
    print('integer-envelope independent exhaustive comparisons:',num)


def trace_audit():
    """Exact integer cut strengthening inside trace fibers (sampled families)."""
    rng=random.Random(725)
    checked=0
    for _ in range(120):
        d=rng.randint(2,6); S={rng.randrange(1<<d) for _ in range(rng.randint(2,10))}
        while True:
            S2=S|{a|b for a,b in combinations(S,2)}
            if S2==S:break
            S=S2
        F=list(S);r=counts(F);W=rng.randrange(1<<d)
        traces={x&W for x in F}
        for t in traces:
            G=sorted((x for x in F if x&W==t),key=lambda x:(x.bit_count(),x));n=len(G)
            s=sum(x&W!=t and subset(x&W,t) for x in F)
            L=sum(r[x] for x in G);R=L-((s+n)**2-s*s)
            assert R>=0 and R%2==0
            local=cut_bounds(G) # formula valid for prefixes of any union-closed fiber
            K=[0]+[(R+(s+j)**2-s*s-j)//2-(c2(j)-local[j]) for j in range(1,n+1)]
            # cut_bounds uses the stronger of two valid bounds, each applies to pairs internal to G.
            p=prefix(sorted((r[x]-1)//2 for x in G));q=integer_envelope(K)
            assert all(a<=b for a,b in zip(p,q));checked+=1
    print('trace-fiber exact prefix checks:',checked)


def integer_certificates():
    c=Q(619,1000)
    assert c*c+c>1 # phi is the positive root of x^2+x=1
    examples=[(400,400,120,4,5),(501,500,144,4,5),(1150,1000,100,2,3),
              (1170000,1000000,10000,2,3),(1000000,1000000,60000,4,5)]
    for N,M,s,u,v in examples:
        assert M>=3 and 1<=s<M and s**v<=M**u
        margin=2*M*(1-c*Q(u,v))-6*c-N
        assert margin>=0
        print('half-frequency certificate (N,M,s,beta, margin):',N,M,s,Q(u,v),margin)
    # Family of m minimal members whose only strict common upper member is top.
    for m in range(2,20):
        F=[((1<<m)-1)^(1<<i) for i in range(m)]+[(1<<m)-1]
        r=sorted(counts(F).values());assert r==envelope_counts(mincap(m+1,m))
    print('sharpness: all 18 star examples match the minimal-layer envelope exactly')

if __name__=='__main__':
    integer_certificates()
    arbitrary_caps()
    exhaustive()
    trace_audit()
    print('ALL AUDITS PASSED')
