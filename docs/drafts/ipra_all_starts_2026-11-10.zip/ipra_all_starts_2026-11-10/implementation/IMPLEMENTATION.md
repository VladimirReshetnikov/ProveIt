# All-starts checker: protocol and correctness boundary

The complete program is `code/all_starts_checker.py`. It is a modification
of `ipra_kernel_and_initializer_2026-11-10/code/tokens.py` in ProveIt commit
`6c902762efcb1e78a5dd25db745310bab74f47a5`. Its whole-source measurements are
323 normalized Python tokens, 374 AST nodes, and 974 normalized bytes.
These counts include its standard JSON import, opening routine, every
inference branch, and the complete public acceptance/rejection driver.
They exclude genuine docstrings under the unchanged corpus normalizer.

This program is larger than the observed complete-source envelope
295 tokens / 334 AST nodes / 801 bytes. Those coordinates are attained by
three different frozen programs in `reference/`, not by one program.
The all-starts construction is a logical rule fusion, not a demonstrated
implementation-size breakthrough. The earlier arithmetic bootstrap,
raw representation, and most of the checking architecture are inherited.

## Ordinary meaning of the formulas

Numerical terms use zero, successor, and initialized scalar iteration

    I(0,a;u.h) = a
    I(Sn,a;u.h) = h[I(n,a;u.h)/u].

Only the update binds `u`; it may contain passive numerical parameters.
Each fixed finite update is a syntactic description, not an object-level
variable over programs. There is no universal numerical evaluator.

Let `tau(r,v) = I(r,v;u.Su)`. Formulas have equality, unary `Q`, and paired
`D` constructors. Their new ordinary meanings are:

* If the immediate matrix `E` is a literal equation,
  `Q_y E(y)` means `forall r,v (E(r) -> E(tau(r,v)))`.
* If the matrix `B` is compound, `Q_y B(y)` means
  `B(0) -> forall y B(y)`.
* `D_xy B(x,y)` means `exists x Q_y B(x,y)`.

The degenerate raw truth representations always mean `0=0`, so either
closure reading is harmless there. A literal equation beneath another
formula binder is compound at the outer binder.

Introduction is deterministic. From `E(t,z)` derive `E(t,Sz)` for an
equation matrix; from `B(t,0)` derive `B(t,Sz)` for a compound matrix.
In both cases introduce `D_xy B(x,y)`, with the displayed assumption
discharged and `z` fresh. Paired elimination still opens a fresh witness
and retains the resulting unary closure. Equality transport, hypothesis
use, and the two computation equations are unchanged.

Atomic-Q elimination is the new inference:

    Q_y E(y), E(r)  |-  E(tau(r,v)).

Compound-Q elimination remains:

    Q_y B(y), B(0)  |-  B(v).

All contexts are retained. These rules and the paper's formula translations,
not the finite tests alone, establish the mathematical equivalence with
iPRA. The meaning of raw atomic `Q` is different from the old conditional
reading: the old theorem `Q_y(y=1)` is not a theorem with this new meaning.
The paper gives the required nonidentity formula translation.

## Public input and output

Run:

    python3 code/all_starts_checker.py < certificate.json

The input is one JSON array. Its final cell is the closed goal. Earlier
cells are proof instructions `[m,t]`, consumed from the end. Hypothesis
membership consumes no instruction. An unused prefix is inert, as in the
inherited interface. Nothing in the input is executed as Python code.

Success prints `ACCEPT` followed by a newline and exits zero. Every caught
failure prints `REJECT` and exits one, with no traceback. Standard and
optimized Python have the same behavior on the supplied suite: the checker
does not rely on `assert` for any rule or validation check.

### Raw syntax and scope

The inherited representation uses the same finite array tree at numerical
and formula sorts:

| Array arity | Formula meaning | Numerical meaning | Child depth increment |
| --- | --- | --- | --- |
| 0 | Truth | Zero | No children |
| 1 | Unary closure Q | Successor | 2 |
| 2 | Equality | Annotated zero | 1 |
| 3 | Paired binder D | Scalar iterator | 4 |

Arrays of higher arity reject when traversed as syntax. Numerical binary
nodes have checked formula annotations but denote zero. The first two
children of a paired formula are checked inert padding. Canonical proofs
need neither feature to carry useful mathematical data.

At formula sort the traversal depth is `2q`; at numerical sort it is
`2q+1`, with `q` protected numerical slots. Positive integer coordinates
`2j-1` and `2j` both denote the j-th slot. Scalar zero denotes zero.
Negative coordinates name already allocated rigid eigenparameters.
The global floor `k` starts at zero and decreases for each new name.

Successor inserts one dummy zero slot. Iterator counter and initializer
insert two dummy zero slots; its update receives two aliases of its state.
Consequently the raw update `[3]` means successor of that state: the
successor's own dummy zero slot is skipped by coordinate 3.

The opening function retains a scalar only when `k <= a < d`. Otherwise
an exposed formula leaf becomes truth; an exposed numerical coordinate
requests the supplied numerical image. A requested image is itself checked
at numerical root. A missing used image rejects. Array traversal recursively
checks the complete input tree and its arity. The initial traversal forbids
meaningful free parameters in the public goal.

The full inherited decoding and common-motive proof are reproduced in the
accompanying paper/reference source. In applying that proof to the new
calculus, use congruence at a fixed immediate matrix kind: opening preserves
the Eq/Q/D constructors. Arbitrary conversion between an atomic matrix and
a compound matrix is not assumed to preserve the meaning of `Q`.

### Instruction cases

1. If `m` is truthy, the checker first proves `m` in the retained context.
   The strict `1/c(m,g)` check rejects a false-returning major. Failure
   never becomes an introduction or computation fallback.

   * For equality `m=[s,u]`, payload `t` is a formula motive. Its instance
     at `u` must be the requested goal, and its instance at `s` is checked
     as the minor premise.
   * For unary `m=[B]` with a literal equation body, payload `t` must be a
     pair `[r,v]`. The statement `s,u=i(u)` validates both numerical terms
     at numerical root and requires exactly two fields. The target image
     is then built as `[r,v,[3]]`, which denotes `tau(r,v)`. Its instance
     must equal the goal; the minor is the instance at `r`.
   * For unary `m=[B]` with a compound body, payload `t` is the ordinary
     target numerical term. The minor is the instance at zero, unchanged
     from the inherited checker.
   * For paired `m=[P,U,B]`, the payload is unused. A fresh witness is
     allocated, and one opened unary closure `[B]` is retained in the
     continuation.

2. If `m` is falsy and `t` is truthy, introduce the paired goal with
   numerical witness `t`. After opening the witness coordinate, allocate
   a fresh parameter `z`, check the successor matrix, and retain exactly
   its progress instance when the matrix is an equation or its zero
   instance when it is compound. Different falsy heads no longer choose
   different rules. A nonempty numerical zero box `[0,0,0]` can supply a
   truthy zero witness.

3. If both fields are falsy, the goal must be a direct one-step iterator
   computation equation. A zero counter selects I0. A truthy counter must
   unpack as a singleton successor and selects IS. There is no general
   evaluator or equality oracle.

## Why the new branch is sound

Suppose the successful unary-major branch sees a literal equation body.
Successful validation of the major establishes the new all-starts closure.
Opening the pair payload at formula depth zero visits both children at
numerical depth one. Thus both endpoints denote numerical terms already
valid at the current root, before being placed under an iterator.

This order matters. The iterator adds two dummy slots. If validation were
postponed until after construction of `[r,v,[3]]`, an exposed coordinate in
an endpoint could become a dummy zero slot. The supplied endpoint probes
reject this malformed interface, and a controlled mutant omitting the pair
validation accepts one of them.

After successful endpoint validation, the inherited image-insertion lemma
preserves their meanings under the iterator's dummy slots. The raw update
`[3]` is exactly `Su`, so the constructed image denotes `tau(r,v)`. The
shared goal comparison and recursive minor check therefore implement
precisely `Q_E,E(r) |- E(tau(r,v))`.

The local `try` does not hide an invalid pair by reinterpreting it as an
equality: the major is still an array of length one, so the fallback
assignment `s,u=m` necessarily fails. The entire public check then rejects.

For introduction, every ordinary compound matrix has odd array arity one
or three. It receives only its zero instance. Arity two receives the
equation induction hypothesis. The arity-zero truth alias receives only a
truth, which is harmless. In paired elimination the major is truthy, so
the common continuation always opens the witness at the fresh parameter.

Freshness follows from validation order. The goal, retained context,
major, and every used witness are scoped before the new name is allocated.
A major subproof may decrease the global floor, but the next name is lower
still; no assumption from that subproof is retained in the continuation.

Induction over a finite successful trace now extracts the corresponding
native derivation. The other branches use the inherited opening and
scope arguments unchanged. Conversely, encode a finite native derivation
in depth-first order, use `[r,v]` for an atomic-Q elimination and the old
numerical payload for compound Q, box a zero witness when necessary, and
allocate fresh negative labels in the actual checking order. This gives
canonical proof-theoretic completeness under sufficient finite resources.

The idealized checker terminates on finite JSON trees: each non-hypothesis
call consumes a packet cell; opening descends proper subtrees; a substituted
image is checked without another supplied image. A physical Python process
has finite stack, parser, memory, and time limits and may reject very deep
valid proofs. No verified-host-runtime claim is made.

## Verification and provenance

Run `python3 verify.py` from this directory. The script verifies unchanged
frozen source hashes, repeats the whole-program source measurements, and
runs 84 public CLI checks: 39 focused certificates plus three malformed
input cases under both ordinary and optimized Python. All passed.

The 39 certificates comprise 19 positive and 20 negative cases. Positive
cases include genuine nonzero-start all-starts specialization, zero-start
specialization, direct computation, actual induction-hypothesis use,
compound closure elimination, and a passive captured initializer.

Three controlled mutation probes additionally confirm that the suite
exercises endpoint root validation, the compound-induction restriction,
and strict rejection of a failed major. A probe's acceptance by a damaged
program is evidence that the guard was exercised; it is not, by itself,
a countermodel or a claim that the probe's goal is underivable otherwise.

The finite checks do not prove universal soundness, the arithmetic
compiler, or bi-interpretability. Those claims rest on the explicit
mathematical proofs. There is no Lean/Rocq formalization in this package.

Frozen source identities and precise original archive/member paths are in
`reference/provenance.json`. The corpus uses the MIT No Attribution license,
included here for completeness. The all-starts mathematical change is
reported separately from the inherited numerical and logical reconstruction.
