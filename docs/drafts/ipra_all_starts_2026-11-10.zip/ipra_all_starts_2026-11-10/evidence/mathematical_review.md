# Independent review of the all-starts presentation

Reviewed source: `theory/all_starts.tex` (before presentation-only integration edits) and the current repository
drafts at commit `6c902762efcb1e78a5dd25db745310bab74f47a5`.

This is an assistant-agent mathematical review, not an external peer review
or a Lean/Rocq formalization.

## Main judgment

The updated proposed mathematical equivalence is sound as a written proof.
I reread the revised note and verified that both requested corrections are
present: safe binder congruence covers every target-compound case, and the
unrestricted raw-target claim before normalization is confined to
existential elimination. The numerical dependency order is now explicit.
I also reviewed the added exact rule-fusion theorem below. No unresolved
mathematical gap was found in this review. The new all-starts elimination
is a real logical change, but the theory alone does not prove a complete
proof-checker size improvement.

## Verified dependencies

1. The orientation `tau(r,s) = I(r,s;u.Su)` is essential. Its first argument
   is the counter, so `tau(0,t)=t` is a computation equation. This makes
   equation induction derivable without using an addition theorem first.

2. Atomic paired introduction followed by paired elimination introduces
   a unary atomic closure from a progression premise. Applying all-starts
   elimination with start zero and arbitrary target gives contextual
   literal-equation induction. The retained context can be arbitrary raw
   syntax and is unchanged.

3. Separate literal-equation inductions prove `tau(r,0)=r`,
   `tau(r,1)=Sr`, and `tau(r,Ss)=S tau(r,s)`. The source thereby obtains
   one-step progression elimination. The target iPRA proof of the general
   jump uses only quantifier-free induction, with the progression formula
   retained as a quantified assumption.

4. Numerical cases hold for all raw formulas immediately: ignore the
   deterministic introduction hypothesis, open the resulting paired
   closure, and use the supplied base. The atomic case uses start zero;
   the compound case uses ordinary conditional specialization.

5. The safe Eq/D grammar is a metatheoretic sublanguage, not an extra
   admissibility test for the proposed complete checker. Its atomic
   immediate matrices have a computation-provable zero instance. This is
   exactly what permits the atomic/compound binder comparison needed by
   the gate and selector constructions. Arbitrary raw binder congruence
   must not be asserted.

6. Safe binder congruence has two exhaustive cases by the TARGET matrix.
   A compound target retains its zero instance; translate that instance
   into the source zero instance, specialize either kind of source closure
   from zero to the successor, and translate back. A gated atomic target
   supplies its zero theorem instead, so its retained progression
   hypothesis may be ignored. Reverse the roles for the converse.

7. The gate construction preserves the inner bound control of every
   immediate atomic matrix and gates only its payload. This validates the
   zero theorem, positive endpoint, and padding identities. The selector
   requires the special atomic merge under a common control. These details
   are necessary; naive leaf gating or unrestricted raw formula selection
   is not justified.

8. The predecessor-free safe logical macros are valid. Conjunction uses
   only the finite toggle values p(1)=1 and p(2)=0. The universal macro
   supplies a zero conjunct plus all positive instances, and numerical
   cases give arbitrary specialization. No predecessor is assumed there.

9. Derived safe existential elimination can conclude an arbitrary raw
   formula because the given continuation is passed directly to primitive
   paired elimination after opening the true-gated matrix. This suffices
   for the reverse raw-D normalization. The analogous statement for safe
   disjunction elimination should be deferred until normalization: its
   early proof constructs an implication whose consequent must be safe.

10. Every raw unary closure normalizes correctly: an atomic one becomes
    safe universal progression, while a compound one becomes safe
    conditional universal closure. Every raw paired closure becomes the
    safe existential quantification of that normalized unary closure.
    Reverse paired normalization uses the unrestricted-target existential
    elimination from item 9, followed by the correct deterministic
    introduction mode. It invokes no unsafe cross-kind congruence.

11. The numerical bridge can be ordered as scalar predecessor, actual
    equality characteristic, quantifier-free induction, then PR compiler.
    The short Choice predecessor appendix uses numerical cases, which
    are already available here. Alternatively, the current
    `ipra_axiomatization_review` archive includes a genuinely pure
    closed-iteration equational predecessor and pairing/PR compiler:
    `reference/scalar_iteration/sections/03_predecessor.tex` and
    `04_pairing_compiler.tex`. I read both. They use equational Boolean
    gluing rather than an assumed Boolean-range disjunction, so that
    alternative bridge is independent of the logical bootstrap.

12. Native absurdity is designated as 0=1. Its explosion is derived by
    selector computation and structural induction on raw formulas. A
    conventional first-order realization must include the falsity bridge
    to genuine bottom. Omitting that convention would leave the singleton
    positive model and would not establish ordinary bi-interpretability.

## Novelty and limits

The current corpus already contains deterministic atomic-progress versus
compound-base introduction, a separate local progression elimination,
safe gated syntax, padding, and the scalar arithmetic bridge. The new
contribution is precisely the all-starts QE rule, which yields the old
zero-start specialization and progression elimination as two instances of
one numerical jump operation, together with its raw-formula normalization.

Searches of all current extracted TeX and Markdown sources did not find
the all-starts or arbitrary-start iteration formulation. This establishes
only novelty relative to the inspected corpus, not literature-wide
priority. A complete implementation and matched whole-source measurement
are still required for the user's requested below-frontier claim.

## Added rule-fusion theorem: final review

The updated note defines a precise comparison calculus P with the same
native syntax and deterministic introduction, but with separate unary
closure specialization from zero (QE0) and one-step atomic progression
elimination (QE+). It proves identity-language equivalence of P with the
all-starts calculus A on every raw native end sequent.

Both proof transformations are valid. A derives QE0 by setting start zero
and derives QE+ by setting jump length one and rewriting with the already
proved tau identity. Conversely, P derives contextual equation induction
from atomic unary introduction plus QE0, and hence proves the tau
identities. Under the fixed raw closure hypothesis and fixed starting
equation E(r), induction on a fresh counter v proves E(tau(r,v)); QE+
supplies the successor step. Specializing v to the original target term
simulates atomic all-starts elimination. Freshening v before this
construction preserves all original passive parameters and contexts.
The compound case uses QE0 and the literal zero-counter computation.

This is a syntactic rule-fusion theorem, independent of semantic
completeness. It sharpens the positive contribution while making clear
that deterministic introduction and the progression interpretation were
already present in the earlier program.
