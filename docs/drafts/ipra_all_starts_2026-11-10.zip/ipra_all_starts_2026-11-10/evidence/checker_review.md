# Read-only review of the all-starts checker

Reviewed file: `work/checker_agent/all_starts/tokens_split_quiet.py`.

This is an assistant-agent mathematical branch and scope review. It is not
an external peer review, a formal verification, or an additional broad
regression run. The inherited raw decoder and whole-program contract were
read in the current Choice archive's `sections/implementation.tex`.

## Judgment

No new branch or scope error was found in the proposed all-starts changes.
The following checks support that judgment.

1. A truthy major is recursively proved before the program distinguishes
   its elimination form. A failed major cannot reach introduction.

2. For a unary major whose body has raw arity two, `i(payload)` is run at
   formula root and then unpacked into two entries. Formula-root arity
   two makes both entries numerical-root terms. They therefore provide
   the starting value and iteration length with the intended scope.

3. The constructed numerical term `[r, s, [3]]` denotes
   `I(r,s;u.Su)`. Its three-child iterator inserts two slots; the
   successor adds a dummy zero slot. Coordinate 3 refers through that
   dummy slot to the iterator state, not to an exposed variable.

4. The resulting two openings of the atomic matrix check
   `E(I(r,s;u.Su))` and recursively prove `E(r)`, exactly atomic
   all-starts specialization. No semantic evaluation of a general PR
   function is hidden in this operation.

5. If validation or unpacking of the atomic specialization pair fails,
   the inner exception fallback attempts to unpack the MAJOR as an
   equality. That major still has length one, so it rejects. A malformed
   atomic-Q packet cannot silently become equality transport.

6. A compound unary major keeps the inherited specialization payload:
   its two openings are `B(target)` and `B(0)`. This is equivalent to
   the manuscript's uniform `B(tau(0,target))` version by I0 and
   transport. The raw arity-zero truth alias may follow this path; its
   conditional and progression readings are both tautological.

7. At equality majors, the failed singleton unpack leaves the original
   payload template available; the two major entries supply its left
   and right numerical instances. This remains equality transport.

8. Introduction opens the witness while protecting the counter slot.
   The shared tail retains the fresh counter instance at even matrix
   arity (the substantive case is an equation of arity two), and the
   zero instance at compound arity one or three. Arity-zero truth is a
   harmless tautological special case. The successor goal is opened
   with `[k]`, which denotes successor of the new eigenparameter.

9. Paired elimination retains `[major[2]]` opened at the new witness
   label, hence precisely the unary closure at that witness. Its goal
   was root-scoped before this label was allocated and therefore cannot
   capture it. The major subproof may allocate earlier private labels;
   the continuation's new label lies below the resulting floor.

10. Every used introduction witness is root-checked during opening
    before the next freshness decrement. If a payload is wholly unused,
    its content is semantically inert. Context lists are extended rather
    than mutated, so private major-proof assumptions do not escape.

## Qualification when adapting the inherited proof

The Choice implementation's common-motive lemma invokes native binder
congruence. The new proof should not import arbitrary atomic/compound
cross-kind congruence from Choice. The opening routine preserves list
arity and every meaningful formula constructor. Thus its different
numerical instances have the same matrix kind, and fixed-root,
same-kind Q/D congruence is sufficient. Atomic progression and compound
conditional closure each respect such pointwise interderivability.

This review does not replace the producer/decoder regression evidence or
a universal formalization of the Python implementation. It specifically
checks the changed elimination branch, deterministic assumption choice,
and their binding/freshness interpretation.
