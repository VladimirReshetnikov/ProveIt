# Induction from arbitrary starting points

Research report prepared for Vladimir Reshetnikov, 10 November 2026 (UTC).

## Result and limitation

The report gives an exact new rule-fusion presentation of full first-order
intuitionistic primitive recursive arithmetic (iPRA), with written proofs
of both interpretation composites. It includes the complete primitive
syntax, computation equations, inference rules, side conditions, a full
standalone certificate checker, and an additional fixed-seed obstruction.

**The requested significant reduction below the existing checker frontier
was not obtained.** The new complete checker measures 323 normalized
Python tokens / 374 AST nodes / 974 normalized bytes. The inspected corpus
already contains complete programs attaining 295 / 334 / 801, respectively.
Those three minima belong to different programs. Neither this report nor
that comparison establishes an absolute minimum over all axiomatizations.

The mathematical novelty is relative to the inspected drafts: one
arbitrary-start elimination replaces the separate zero-start and one-step
progression eliminations in the specified progressive-closure language.
Deterministic introduction, gates, the scalar iterator, and the arithmetic
compiler are inherited and attributed. No literature-wide priority claim
or proof-assistant certification is made.

## Read and reproduce

- `ipra_all_starts.pdf`: complete compiled report.
- `ipra_all_starts.tex`: main LaTeX source, with `theory/`, `reference/`, and
  generated evidence tables as its inputs.
- `python3 verify.py`: reproduce all 84 public CLI tests, three guard
  mutation controls, frozen comparison hashes, and full-source sizes.
- `python3 build.py`: rebuild the PDF using an installed LaTeX distribution.
- `python3 audit_corpus.py /path/to/ProveIt/docs/drafts`: reproduce the
  archive hashes and complete Python source scan of the pinned corpus.

The checker and verification suite need only the Python standard library.
The reported size figures were obtained with CPython 3.12.14; Python's AST
and unparser can differ across versions. LaTeX requires pdfTeX, Latin
Modern, AMS packages, and the standard packages listed in the preamble.
`build.py` can generate missing format and font-map caches temporarily; it
does not install or download packages. Build intermediates may be deleted.

The comparison snapshot is ProveIt commit
`6c902762efcb1e78a5dd25db745310bab74f47a5`:

https://github.com/VladimirReshetnikov/ProveIt/tree/6c902762efcb1e78a5dd25db745310bab74f47a5/docs/drafts

## Archive map

| Path | Purpose |
| --- | --- |
| `theory/all_starts.tex` | Full calculus, exact fusion theorem, safe logical interface, raw normalization, and bi-interpretation |
| `theory/fixed_seed_counter_access.tex` | New finite-section obstruction with recursion-counter access |
| `code/checker.py` | Entire executable checker printed in the report |
| `implementation/` | Documented checker, input protocol, certificate producer, fixtures, verifier, measurements, and validation receipts |
| `reference/` | Verbatim arithmetic dependencies, raw decoder specification, frozen comparison sources, fixed-seed/amalgam references, and upstream license |
| `evidence/` | Repository snapshot, archive hashes, complete source scan, metrics, provenance, and review notes |
| `MANIFEST.sha256` | Integrity hashes for all delivered files except the manifest itself |

The documented checker at `implementation/code/all_starts_checker.py`
differs from the printed checker only by a descriptive module docstring.
The root verifier checks that their executable ASTs are identical. The
unchanged corpus measurement procedure strips docstrings consistently.

## Scope of verification

All 84 public checker runs passed: 39 focused certificates (19 positive,
20 negative), plus three malformed-input cases, each under ordinary and
optimized Python. Three mutation controls confirm that the suite reaches
endpoint root validation, the restriction against compound induction, and
strict rejection of failed majors. Finite tests are not a universal
soundness proof. The universal mathematical claims are written proofs,
reviewed by another assistant agent, not external peer review or Lean/Rocq
formalizations. Physical interpreter limits can reject very large valid
certificates.

The fixed-seed appendix proves its new finite-section theorem directly.
Its final model-theoretic transfer paragraph invokes the inherited unary
amalgam proof, whose source is included separately. It is restricted to
the stated ordinary first-order theories and interpretations; it is not a
barrier to every interpretation allowed in the original research problem.

## Attribution

The original drafts and inherited source files are from the pinned
VladimirReshetnikov/ProveIt repository under its MIT No Attribution license.
Exact archive/member identities and SHA-256 hashes are recorded in
`evidence/inherited_provenance.json` and the implementation provenance file.
The original license text is included in `reference/LICENSE.txt`.

The report's final section lists further research questions and states
the remaining unsolved size target explicitly.
