#!/usr/bin/env python3
"""Finite natural-number diagnostics for the boundary-witness manuscript.

This executes the actual scalar terms and recurrences on bounded inputs.
It is a reproducible diagnostic, NOT a proof over arbitrary carriers, a
proof of the infinite axiom schema, or a formal bi-interpretation check.
Run from any working directory. Results are written next to the report in
verification/arithmetic_results.json.
"""

from __future__ import annotations

from collections import Counter
from functools import cache
from itertools import product
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
COUNTS: Counter[str] = Counter()


def check(name: str, condition: bool, *context: object) -> None:
    COUNTS[name] += 1
    if not condition:
        raise AssertionError((name, context))


def Q(n: int, a: int) -> int:
    return a if n == 0 else n - 1


def Z(n: int, a: int) -> int:
    return a if n == 0 else 0


def chi(x: int, y: int) -> int:
    return int(x == y)


def pred(n: int) -> int:
    return Q(n, 0)


def C(r: int, b: int, c: int) -> int:
    # The literal derived selector Q(Z(r,Sb),c).
    return Q(Z(r, b + 1), c)


def rec(body, n: int, a: int) -> int:
    state = a
    for counter in range(n):
        state = body(state, counter)
    return state


@cache
def add(x: int, y: int) -> int:
    return rec(lambda v, _w: v + 1, y, x)


@cache
def diff(x: int, y: int) -> int:
    return rec(lambda v, _w: pred(v), y, x)


def chi_pra(x: int, y: int) -> int:
    d = diff(x + 1, y)
    return C(d, 0, C(pred(d), 1, 0))


def counter_guard(tail, v: int, w: int) -> int:
    # The actual final marked body I_t(v,w).
    return Q(Z(chi(w, 0), tail(v, w) + 1), v)


def periodic(mask: int, length: int, n: int) -> bool:
    return bool((mask >> (n % length)) & 1)


def selector_values(predicate, limit: int) -> list[int]:
    values = [0]
    for n in range(limit):
        old = values[-1]
        # A true-on-truth bit selects Sn; a false bit retains the witness.
        values.append(C(int(predicate(old + 1)), old, n + 1))
    return values


def basic_diagnostics() -> None:
    for n, a in product(range(33), repeat=2):
        check("Q_base", Q(0, a) == a, n, a)
        check("Q_step", Q(n + 1, a) == n, n, a)
        check("Z_base", Z(0, a) == a, n, a)
        check("Z_step", Z(n + 1, a) == 0, n, a)
        check("predecessor", pred(n + 1) == n, n)
        check("canonical_equality_bit", chi_pra(n, a) == chi(n, a), n, a)
    for r, b, c in product(range(17), repeat=3):
        check("selector_term", C(r, b, c) == (b if r == 0 else c), r, b, c)
    tail = lambda v, w: (3 * v + 5 * w + 2) % 23
    for v, w in product(range(33), repeat=2):
        expected = v if w == 0 else tail(v, w)
        check("counter_guard_term", counter_guard(tail, v, w) == expected, v, w)
        check("alias_projection", Q(counter_guard(tail, v, w) + 1, w)
              == counter_guard(tail, v, w), v, w)


def latch_diagnostics() -> dict[str, int]:
    masks = 0
    for length in range(1, 7):
        for mask in range(1 << length):
            masks += 1

            def P(w: int, b: int) -> bool:
                # Both slots matter; this family also includes constant tests.
                return periodic(mask, length, w + 2 * b)

            def tail(v: int, w: int) -> int:
                truth_bit = 0 if P(w, pred(v)) else 1
                return Z(truth_bit, v)

            def body(v: int, w: int) -> int:
                return counter_guard(tail, v, w)

            for v, w, b in product(range(17), range(11), range(7)):
                mark = b + 1
                reflected = v == mark and (w == 0 or P(w, b))
                check("arbitrary_state_latch_reflection",
                      (body(v, w) == mark) == reflected, length, mask, v, w, b)
            for b in range(7):
                mark = b + 1
                states = [mark]
                for n in range(13):
                    states.append(body(states[-1], n))
                    check("shifted_return_reflection",
                          (states[n + 1] == mark)
                          == (states[n] == mark and (n == 0 or P(n, b))),
                          length, mask, b, n)
                check("automatic_shifted_base", states[1] == mark, length, mask, b)
    return {"periodic_mask_families": masks, "mask_lengths": 6,
            "state_values": 17, "counter_values": 11, "parameter_values": 7}


def selector_diagnostics() -> dict[str, int]:
    ordinary_masks = 0
    pointed_masks = 0
    for length in range(1, 11):
        for mask in range(1 << length):
            predicate = lambda n: periodic(mask, length, n)
            limit = 2 * length + 2
            witnesses = selector_values(predicate, limit)
            pointed_masks += 1
            for n, witness in enumerate(witnesses):
                check("pointed_selector_invariant",
                      (witness == 0 or predicate(witness))
                      and (not predicate(witness + 1) or witness == n),
                      length, mask, n, witness)
                check("selector_witness_bound", 0 <= witness <= n,
                      length, mask, n, witness)
            if predicate(0):
                ordinary_masks += 1
                for n, witness in enumerate(witnesses):
                    check("boundary_selector_invariant",
                          predicate(witness)
                          and (not predicate(witness + 1) or witness == n),
                          length, mask, n, witness)
    return {"periodic_boolean_masks_pointed": pointed_masks,
            "periodic_boolean_masks_with_true_base": ordinary_masks,
            "maximum_mask_length": 10,
            "selector_horizon": "2 * mask length + 2"}


def arithmetic_and_pairing_diagnostics() -> dict[str, int]:
    for x, y in product(range(65), repeat=2):
        equations = [
            add(0, y) == y,
            add(x + 1, y) == add(x, y) + 1,
            diff(x + 1, y + 1) == diff(x, y),
            diff(pred(x), y) == pred(diff(x, y)),
            diff(x, x) == 0,
            diff(x + 1, x) == 1,
            diff(add(x, y), y) == x,
            diff(add(x, y), x) == y,
            diff(y, add(x, y)) == 0,
            not (diff(x + 1, y) == 0) or diff(x, y) == 0,
            C(diff(x, y), x, add(y, diff(x, y))) == x,
        ]
        for index, equation in enumerate(equations):
            check("arithmetic_ledger", equation, index, x, y)

    # Both tables are generated by the displayed scalar recurrences. No
    # inverse square-root formula is used to construct or decode K.
    triangular = [0]
    for n in range(256):
        triangular.append(add(triangular[-1], n + 1))
    maximum_z = 10000
    interval = [0]
    for z in range(maximum_z):
        old = interval[-1]
        interval.append(add(old, chi(z + 1, triangular[old + 1])))

    def T(n: int) -> int:
        return triangular[n]

    def K(z: int) -> int:
        if not 0 <= z <= maximum_z:
            raise ValueError(("pairing diagnostic out of declared bounds", z))
        return interval[z]

    def pair(x: int, y: int) -> int:
        return add(T(add(x, y)), y)

    def right(z: int) -> int:
        return diff(z, T(K(z)))

    def left(z: int) -> int:
        return diff(K(z), right(z))

    for b in range(129):
        check("triangular_boundary", K(T(b)) == b, b)
        for j in range(b + 1):
            check("triangular_block", K(add(T(b), j)) == b, b, j)
    for x, y in product(range(65), repeat=2):
        packed = pair(x, y)
        check("pair_right_retraction", right(packed) == y, x, y, packed)
        check("pair_left_retraction", left(packed) == x, x, y, packed)

    tuple_count = 0
    for arity in range(4):
        for values in product(range(5), repeat=arity):
            packed = 0
            for value in reversed(values):
                packed = pair(value, packed)
            decoded = []
            rest = packed
            for _ in values:
                decoded.append(left(rest))
                rest = right(rest)
            check("tuple_retraction", tuple(decoded) == values, values, packed)
            tuple_count += 1
    return {"arithmetic_argument_maximum": 64, "pair_argument_maximum": 64,
            "triangular_block_maximum": 128, "K_table_maximum_input": maximum_z,
            "tuple_arities": [0, 1, 2, 3], "tuple_values": [0, 1, 2, 3, 4],
            "tuple_count": tuple_count}


def main() -> None:
    basic_diagnostics()
    latch = latch_diagnostics()
    selectors = selector_diagnostics()
    pairing = arithmetic_and_pairing_diagnostics()
    result = {
        "status": "passed",
        "scope": "Finite standard-natural-number diagnostic; not a proof of the schema or bi-interpretability.",
        "independence": "Executes displayed term definitions and scalar recurrences; imports no manuscript-generated result files.",
        "assertions": dict(sorted(COUNTS.items())),
        "total_assertions": sum(COUNTS.values()),
        "latch_bounds": latch,
        "selector_bounds": selectors,
        "pairing_bounds": pairing,
    }
    destination = ROOT / "verification" / "arithmetic_results.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
