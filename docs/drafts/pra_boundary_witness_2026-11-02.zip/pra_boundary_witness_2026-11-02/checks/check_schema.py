#!/usr/bin/env python3
"""Independent literal-AST audit for the boundary-witness presentation.

No source or checker from the comparison archives is imported.  This program
checks syntax accounting, finite test cases, and the stated comparison ledger;
it does not prove semantic equivalence or bi-interpretability.

Usage: python3 checks/check_schema.py
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple["Term", ...] = ()
    descriptor: "Term | None" = None


@dataclass(frozen=True)
class Formula:
    op: str
    args: tuple["Term | Formula", ...] = ()
    bound: str | None = None


def var(name):
    return Term("var:" + name)


zero = Term("0")
n, a, k, b = map(var, ("n", "a", "k", "b"))
v, w = map(var, ("v", "w"))


def S(t):
    return Term("S", (t,))


one = S(zero)


def binary(name, left, right):
    return Term(name, (left, right))


def chi(left, right):
    return binary("chi", left, right)


def eps(left, right):
    return binary("eps", left, right)


def delta(left, right):
    return binary("Delta", left, right)


def R(descriptor, count, initial):
    return Term("R", (count, initial), descriptor)


def Q(count, initial):
    return R(w, count, initial)


def Z(count, initial):
    return R(zero, count, initial)


def sub(term, replacements):
    """Simultaneous active substitution.  Frozen descriptors are untouched."""
    if term.op.startswith("var:"):
        return replacements.get(term.op[4:], term)
    return Term(term.op, tuple(sub(x, replacements) for x in term.args),
                term.descriptor)


def use(term, first=n, second=a):
    return sub(term, {"n": first, "a": second})


def nf(term):
    """The inherited root-only projection normalization."""
    while (term.op == "R" and term.descriptor == w
           and term.args[0].op == "S"):
        term = term.args[0].args[0]
    return term


def selected(term, canonical):
    body = nf(term) if canonical else term
    return sub(body, {"n": v, "a": w})


def eq(left, right):
    return Formula("=", (left, right))


def And(left, right):
    return Formula("and", (left, right))


def Or(left, right):
    return Formula("or", (left, right))


def Imp(left, right):
    return Formula("implies", (left, right))


bottom = Formula("false")


def Forall(name, body):
    return Formula("forall", (body,), name)


def Exists(name, body):
    return Formula("exists", (body,), name)


def close(body):
    return Forall("a", Forall("n", body))


def weight(node, full=False):
    cost = 1 + sum(weight(x, full) for x in node.args)
    if isinstance(node, Term) and full and node.descriptor is not None:
        cost += weight(node.descriptor, True)
    return cost


def occurrences(term, name):
    if term.op == "var:" + name:
        return 1
    return sum(occurrences(x, name) for x in term.args)


def quantifiers(formula):
    if isinstance(formula, Term):
        return 0, 0
    children = [quantifiers(x) for x in formula.args]
    own = int(formula.op in ("forall", "exists"))
    return (own + sum(c[0] for c in children),
            own + max((c[1] for c in children), default=0))


def contains_test(term):
    return (term.op in ("chi", "eps", "Delta")
            or any(contains_test(x) for x in term.args)
            or (term.descriptor is not None and contains_test(term.descriptor)))


def show(term):
    if term.op.startswith("var:"):
        return term.op[4:]
    if term.op == "0":
        return "0"
    if term.op == "S":
        return "S(" + show(term.args[0]) + ")"
    if term.op == "R":
        label = ("Q" if term.descriptor == w else
                 "Z" if term.descriptor == zero else
                 "R[" + show(term.descriptor) + "]")
    else:
        label = term.op
    return label + "(" + ",".join(show(x) for x in term.args) + ")"


separation = Imp(eq(zero, one), bottom)


def true_bit_matrix():
    return And(eq(chi(a, a), one), Or(eq(a, n), eq(chi(a, n), zero)))


def false_bit_matrix():
    return And(eq(eps(a, a), zero), Or(eq(a, n), eq(eps(a, n), one)))


new_seed = close(And(separation, true_bit_matrix()))
old_witness_seed = close(And(separation, false_bit_matrix()))
seed_input = Q(S(n), a)


def rec_matrix(term, canonical=False):
    desc = selected(term, canonical)
    rec = lambda x, y: R(desc, x, y)
    return And(eq(rec(zero, a), a),
               eq(rec(S(n), a), use(term, rec(n, a), n)))


def right_matrix(term):
    desc = selected(term, True)
    rec = lambda x, y: R(desc, x, y)
    return And(eq(rec(zero, a), a),
               eq(rec(S(n), a), rec(n, use(term, a, zero))))


def identity_guard(tail):
    return Q(Z(chi(a, zero), S(tail)), n)


def is_identity_guard(term):
    if not (term.op == "R" and term.descriptor == w and term.args[1] == n):
        return False
    inner = term.args[0]
    return (inner.op == "R" and inner.descriptor == zero
            and inner.args[0] == chi(a, zero)
            and inner.args[1].op == "S")


def is_old_guard(term):
    return (term.op == "R" and term.descriptor == zero
            and term.args[0] == chi(n, zero))


def boundary_payload(term):
    desc = selected(term, True)
    rec = lambda x: R(desc, x, a)
    return Exists("k", And(eq(rec(S(k)), a),
                           Imp(eq(rec(S(S(k))), a), eq(k, n))))


def new_formula(term):
    i, j = occurrences(term, "n"), occurrences(term, "a")
    if term == seed_input:
        return "seed", new_seed
    if i > 0 and j == 0:
        return "autonomous_right", close(right_matrix(term))
    if is_identity_guard(term):
        return "boundary_only", close(boundary_payload(term))
    return "ordinary_left", close(rec_matrix(term, True))


def constancy(term):
    return Imp(Forall("k", eq(use(term, S(k)), use(term, k))),
               eq(term, use(term, zero)))


def mask_propagation(term):
    pred = lambda x: eq(delta(x, use(term, x)), x)
    return Imp(Forall("k", Imp(pred(k), eq(use(term, S(k)), S(k)))), pred(n))


def old_guarded(term):
    i, j = occurrences(term, "n"), occurrences(term, "a")
    rec = rec_matrix(term, True)
    if term == seed_input:
        return close(And(rec, And(separation, true_bit_matrix())))
    if i > 0 and j == 0:
        return close(right_matrix(term))
    if j > 0 and is_old_guard(term):
        progress = Forall("k", Imp(eq(use(term, k), zero),
                                    eq(use(term, S(k)), zero)))
        return close(And(rec, Imp(progress, eq(term, zero))))
    return close(rec)


def old_sparse(term, full_cutoff):
    i, j = occurrences(term, "n"), occurrences(term, "a")
    if term == zero:
        return close(And(separation, Or(eq(n, a), eq(delta(n, a), zero))))
    rec = rec_matrix(term, True)
    if i == 0:
        return close(rec)
    if j == 0:
        return close(right_matrix(term))
    small = weight(term, full_cutoff) <= 10
    return close(And(rec, constancy(term) if small else mask_propagation(term)))


def orbit(term, spelling="update", fused=False, predecessor_coverage=False):
    desc = selected(term, False)
    rec = lambda x: R(desc, x, a)
    if spelling == "shifted":
        premise = And(eq(use(term, a, zero), a),
                      Forall("k", Imp(eq(rec(S(k)), a),
                                       eq(use(term, a, S(k)), a))))
        payload = Imp(premise, eq(rec(S(n)), a))
    else:
        consequent = (eq(use(term, a, k), a) if spelling == "update"
                      else eq(rec(S(k)), a))
        payload = Imp(Forall("k", Imp(eq(rec(k), a), consequent)),
                      eq(rec(n), a))
    matrix = And(rec_matrix(term), payload)
    if fused:
        if spelling == "shifted":
            matrix = And(separation, matrix)
        else:
            coverage = (Or(eq(n, zero), eq(n, S(Q(n, zero))))
                        if predecessor_coverage else
                        Or(eq(n, zero), Exists("b", eq(n, S(b)))))
            matrix = And(And(separation, coverage), matrix)
    return close(matrix)


def witness(term, return_test=False, conditional=False):
    if return_test:
        desc = selected(term, False)
        probe = lambda x: eps(R(desc, S(x), a), a)
        test = Imp(eq(probe(S(b)), probe(b)), eq(probe(n), b))
    else:
        test = Imp(eq(use(term, S(b)), use(term, b)), eq(term, b))
    rec = rec_matrix(term)
    if conditional:
        rec = And(separation, rec)
    return Forall("a", Exists("b", Forall("n", And(rec, test))))


def unit_descent(term):
    descent = Imp(Forall("k", eq(use(term, k), S(use(term, S(k))))), bottom)
    return close(And(rec_matrix(term), descent))


def unit_scalar(term, prune=False):
    if term == zero:
        return close(And(rec_matrix(term), And(separation, false_bit_matrix())))
    if prune and occurrences(term, "n") == 0:
        return close(rec_matrix(term))
    return close(And(rec_matrix(term), constancy(term)))


def all_baselines(term):
    m, i = weight(term), occurrences(term, "n")
    raw_witness = witness(term)
    return {
        "guarded_zero_four_case": old_guarded(term),
        "sparse_mask_active_cutoff": old_sparse(term, False),
        "sparse_mask_descriptor_cutoff": old_sparse(term, True),
        "orbit_update_factored": orbit(term),
        "orbit_only_optional_factored": orbit(term, "orbit"),
        "orbit_update_fused": orbit(term, fused=True),
        "orbit_predecessor_coverage_fused": orbit(term, fused=True,
                                                predecessor_coverage=True),
        "orbit_shifted_fused": orbit(term, "shifted", fused=True),
        "orbit_shifted_with_separation_factored": orbit(term, "shifted"),
        "witness_raw": raw_witness,
        "witness_return_optional": witness(term, return_test=True),
        "witness_adaptive_optional": (raw_witness if 3*m+i <= 19 else
                                      witness(term, return_test=True)),
        "witness_identity_alias_optional": (old_witness_seed if term == n else
                                            raw_witness),
        "witness_conditional": witness(term, conditional=True),
        "unit_descent_generated_two_slot_profile": unit_descent(term),
        "unit_descent_scalar_constancy": unit_scalar(term),
        "unit_descent_scalar_optional_pruning": unit_scalar(term, True),
        "optional_factored_constancy_core": close(And(rec_matrix(term),
                                                     constancy(term))),
        "optional_factored_mask_core": close(And(rec_matrix(term),
                                                mask_propagation(term))),
    }


def check_closed_form_counts(term):
    m, W, V = weight(term), weight(term, True), weight(nf(term), True)
    i, j = occurrences(term, "n"), occurrences(term, "a")
    branch, f = new_formula(term)
    expected = {
        "seed": (25, 25),
        "autonomous_right": (15+m, 15+W+3*V),
        "boundary_only": (21, 21+2*W),
        "ordinary_left": (13+m+2*i, 13+W+2*i+(2+i)*V),
    }[branch]
    assert (weight(f), weight(f, True)) == expected, (show(term), branch)
    formulas = all_baselines(term)
    known = {
        "orbit_update_factored": (29+2*m+2*i, 29+(6+i)*W+2*i),
        "orbit_only_optional_factored": (33+m+2*i, 33+(6+i)*W+2*i),
        "orbit_update_fused": (46+2*m+2*i, 46+(6+i)*W+2*i),
        "orbit_predecessor_coverage_fused": (47+2*m+2*i, 48+(6+i)*W+2*i),
        "orbit_shifted_fused": (41+3*m+2*i+j, 41+(7+i)*W+2*i+j),
        "orbit_shifted_with_separation_factored":
            (34+3*m+2*i+j, 34+(7+i)*W+2*i+j),
        "witness_raw": (19+4*m+3*i, 19+(6+i)*W+3*i),
        "witness_return_optional": (38+m+2*i, 38+(6+i)*W+2*i),
        "witness_conditional": (26+4*m+3*i, 26+(6+i)*W+3*i),
        "unit_descent_generated_two_slot_profile":
            (19+3*m+3*i, 19+(5+i)*W+3*i),
        "optional_factored_constancy_core":
            (18+5*m+3*i, 18+(7+i)*W+3*i),
        "optional_factored_mask_core": (28+4*m+3*i, 28+(6+i)*W+3*i),
    }
    for label, pair in known.items():
        actual = (weight(formulas[label]), weight(formulas[label], True))
        assert actual == pair, (label, show(term), actual, pair)
    return branch, f, formulas


def test_inputs():
    # All descriptors below are finite and staged.  R_v is deliberately absent
    # as an application inside test inputs, so the witness projection-alias
    # variant admits the same compared raw terms without further translation.
    descs = [zero, w, S(v), Z(v, w), Q(v, S(w))]
    long_desc = v
    for _ in range(18):
        long_desc = S(long_desc)
    descs.append(long_desc)
    leaves = [zero, n, a]
    examples = [zero, n, a, one, S(n), S(a), Q(n, a), seed_input,
                Q(S(zero), a), Z(n, a), R(long_desc, n, a)]
    terms = set(examples)
    rng = random.Random(20261102)

    def random_term(depth):
        if depth <= 0 or rng.randrange(5) == 0:
            return rng.choice(leaves)
        case = rng.randrange(5)
        if case == 0:
            return S(random_term(depth-1))
        if case == 1:
            return chi(random_term(depth-1), random_term(depth-1))
        return R(rng.choice(descs), random_term(depth-1), random_term(depth-1))

    for _ in range(500):
        terms.add(random_term(4))
    tails = sorted(terms, key=lambda t: (weight(t), show(t)))[:120]
    for tail in tails:
        terms.add(identity_guard(tail))
        terms.add(Z(chi(n, zero), tail))
        terms.add(Q(S(tail), a))
        terms.add(Q(S(Q(S(tail), a)), n))
    return sorted(terms, key=lambda t: (weight(t), show(t))), examples


def run(output):
    terms, examples = test_inputs()
    branches, variant_names = Counter(), None
    by_variant = {}
    selected_stats = []
    examples_out = []
    q_stats = {}
    literal_count = 0
    for term in terms:
        branch, fresh, old = check_closed_form_counts(term)
        branches[branch] += 1
        variant_names = list(old)
        new_cost = (weight(fresh), weight(fresh, True))
        q_stats.setdefault(branch, set()).add(quantifiers(fresh))
        literal_count += int(not contains_test(term))
        for label, formula in old.items():
            old_cost = (weight(formula), weight(formula, True))
            assert all(x <= y for x, y in zip(new_cost, old_cost)), (
                "comparison failed", label, show(term), new_cost, old_cost)
            stats = by_variant.setdefault(label, {
                "active_strict": 0, "active_ties": 0,
                "full_strict": 0, "full_ties": 0})
            stats["active_strict" if new_cost[0] < old_cost[0] else
                  "active_ties"] += 1
            stats["full_strict" if new_cost[1] < old_cost[1] else
                  "full_ties"] += 1
        minimum = tuple(min(weight(f, full) for f in old.values())
                        for full in (False, True))
        if branch in ("seed", "boundary_only"):
            assert new_cost[0] < minimum[0] and new_cost[1] < minimum[1]
        if branch == "boundary_only":
            m, W = weight(term), weight(term, True)
            i, j = occurrences(term, "n"), occurrences(term, "a")
            tail = term.args[0].args[1].args[0]
            assert m == 7 + weight(tail)
            assert W == 9 + weight(tail, True)
            assert i == 1 + occurrences(tail, "n")
            assert j == 1 + occurrences(tail, "a")
            assert m >= 8 and W >= 10 and i >= 1 and j >= 1
            assert nf(term) == term
            assert minimum == (13+m+2*i, 13+(3+i)*W+2*i)
            wrapper = Q(S(term), a)
            wrapper_branch, _ = new_formula(wrapper)
            assert wrapper_branch == "ordinary_left"
            assert selected(wrapper, True) == selected(term, True)
            selected_stats.append((minimum[0]-21, minimum[1]-(21+2*W)))
        if term in examples or term in (identity_guard(zero), identity_guard(n),
                                       identity_guard(a)):
            examples_out.append({"term": show(term), "branch": branch,
                                 "active_input": weight(term),
                                 "full_input": weight(term, True),
                                 "n_occurrences": occurrences(term, "n"),
                                 "a_occurrences": occurrences(term, "a"),
                                 "new_active": new_cost[0], "new_full": new_cost[1],
                                 "old_min_active": minimum[0],
                                 "old_min_full": minimum[1]})

    # Structural checks supporting the pre-induction omission argument.
    assert selected(seed_input, True) == v
    assert right_matrix(n) == rec_matrix(n, True)
    assert (weight(new_seed), weight(new_seed, True)) == (25, 25)
    assert (weight(old_witness_seed), weight(old_witness_seed, True)) == (25, 25)
    assert weight(separation) == 6
    assert weight(Forall("n", Or(eq(n, zero), Exists("b", eq(n, S(b)))))) == 10

    result = {
        "status": "passed",
        "scope": "Independent literal-AST and finite syntax audit; not a proof of semantic equivalence.",
        "input_count": len(terms), "baseline_template_count": len(variant_names),
        "formula_tree_count": len(terms) * (1+len(variant_names)),
        "branch_counts": dict(branches),
        "arithmetic_only_inputs": literal_count,
        "inputs_with_test_symbols": len(terms)-literal_count,
        "comparison_convention": (
            "Literal common arithmetic grammar where available; matched syntax profiles in a common "
            "extension for chi/epsilon/Delta/conditional vocabularies. Fixed sentences outside a "
            "baseline recurring core are omitted, strengthening the claimed inequalities. "
            "The higher-arity unit-descent grammar is compared only on its two-slot profiles. "
            "The alias option is compared only where its reduced grammar admits the raw input."),
        "all_finite_inputs_weakly_dominate_each_baseline_in_both_metrics": True,
        "seed_and_marked_inputs_strictly_dominate_minimum_in_both_metrics": True,
        "selected_minimum_active_saving": min(x for x, y in selected_stats),
        "selected_minimum_full_saving": min(y for x, y in selected_stats),
        "quantifier_count_and_depth_by_branch": {
            name: [list(pair) for pair in sorted(pairs)]
            for name, pairs in q_stats.items()},
        "per_baseline": by_variant,
        "examples": examples_out,
        "analytic_comparison_obligations": {
            "marked_lower_bounds": "m>=8, W>=10, i>=1, j>=1; NF(u)=u",
            "marked_exact_current_envelope": "active=13+m+2i; full=13+(3+i)W+2i, attained by the guarded-zero ordinary-left branch",
            "marked_vs_guarded_zero_active": "(13+m+2i)-21 = m+2i-8 >= 2",
            "marked_vs_guarded_zero_full": "[13+(3+i)W+2i]-(21+2W) = (1+i)W+2i-8 >= 14",
            "marked_vs_orbit_only_active": "(33+m+2i)-21 = 12+m+2i > 0",
            "marked_vs_unit_descent_full": "[19+(5+i)W+3i]-(21+2W) = (3+i)W+3i-2 > 0",
            "ordinary_cases": "The guarded-zero or sparse-mask computation-only branches tie; other listed templates add nonnegative payloads or have larger displayed coefficients.",
            "seed_profile": "u=Q(Sn,a): (m,W,i,j)=(4,5,1,1); new=(25,25); minima=(34,47)",
            "proof_status": "These algebraic obligations are stated for the written universal proof; finite tests do not by themselves establish them."},
        "omission_checks": {
            "seed_normalizes_to_identity_descriptor": True,
            "identity_input_right_recursion_is_literal_left_recursion": True,
            "all_tested_marked_recursions_recovered_by_unmarked_projection_wrapper": True},
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"],
                      "input_count": result["input_count"],
                      "baseline_template_count": result["baseline_template_count"],
                      "formula_tree_count": result["formula_tree_count"],
                      "branch_counts": result["branch_counts"],
                      "selected_minimum_active_saving": result["selected_minimum_active_saving"],
                      "selected_minimum_full_saving": result["selected_minimum_full_saving"],
                      "output": str(output)}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[1] /
                        "verification" / "schema_results.json")
    args = parser.parse_args()
    run(args.output)
