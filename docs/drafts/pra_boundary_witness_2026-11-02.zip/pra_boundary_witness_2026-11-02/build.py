#!/usr/bin/env python3
"""Rebuild the reproducible checks and PDF; optionally rerun the Lean kernel."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(command, log):
    result = subprocess.run(command, cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (ROOT / log).write_text(result.stdout)
    if result.returncode:
        print(result.stdout[-12000:])
        raise RuntimeError(f"Command failed ({result.returncode}): {command[0]}")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Path to Lean 4.19.0, if installed")
    parser.add_argument("--skip-pdf", action="store_true")
    args = parser.parse_args()
    (ROOT / "verification").mkdir(exist_ok=True)
    run([sys.executable, "checks/check_schema.py"],
        "verification/schema_output.txt")
    run([sys.executable, "checks/check_arithmetic.py"],
        "verification/arithmetic_output.txt")
    formal = {"rerun_in_this_build": False,
              "note": "Earlier actual compiler run is recorded under formal/."}
    if args.lean:
        version = run([args.lean, "--version"], "formal/lean_version.txt").stdout.strip()
        result = run([args.lean, "formal/BoundaryWitness.lean"],
                     "formal/lean_output.txt")
        count = result.stdout.count("does not depend on any axioms")
        if count != 15 or "sorry" in result.stdout.lower():
            raise RuntimeError("Unexpected Lean axiom audit output")
        formal = {"rerun_in_this_build": True, "compiler": version,
                  "returncode": result.returncode, "theorem_reports": count,
                  "all_reported_without_axioms": True,
                  "sha256": hashlib.sha256((ROOT / "formal/BoundaryWitness.lean").read_bytes()).hexdigest(),
                  "scope": "Local kernels only; see formal/SCOPE.txt."}
        (ROOT / "formal/verification.json").write_text(json.dumps(formal, indent=2)+"\n")
    pdf = {"built": False}
    if not args.skip_pdf:
        for number in range(1, 4):
            run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                f"verification/latex_pass_{number}.txt")
        final_log = (ROOT / "report.log").read_text(errors="replace")
        unresolved = any(t in final_log for t in (
            "There were undefined references", "There were undefined citations",
            "Label(s) may have changed", "! LaTeX Error"))
        if unresolved:
            raise RuntimeError("Unresolved LaTeX references or build error")
        pdf = {"built": True, "size_bytes": (ROOT / "report.pdf").stat().st_size,
               "overfull_warnings": final_log.count("Overfull "),
               "underfull_warnings": final_log.count("Underfull "),
               "unresolved_references": False}
    result = {"status": "passed", "syntax": "passed", "arithmetic": "passed",
              "formal": formal, "pdf": pdf}
    (ROOT / "verification/build_results.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
