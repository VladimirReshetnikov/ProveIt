PRA BY BOUNDARY WITNESSES
Research package prepared for Vladimir Reshetnikov, November 2, 2026

START HERE
  report.pdf       Complete paper, proofs, comparisons, and research questions.
  report.tex       Main LaTeX source; sections/ contains required included files.
  AXIOMS.txt       Exact standalone specification of the scalar theory.

RESULT
The new scalar theory is bi-interpretable and equiconsistent with first-order
PRA. Both directions use the entire carrier and native equality; both round
trips are internally the identity. The paper proves a common conservative
definitional extension. Matching classical and intuitionistic versions work.

The induction-bearing boundary sentence has 21 active nodes, or 21+2W
when both copies of its finite stored description are fully charged. Its
computation equations are recovered through the existing root alias, so
they need not be repeated. The complete emitter has four cases and uses
the current guarded-zero draft's binary grammar and normalization.

COMPARISON
The five current drafts were inspected at ProveIt commit
fc604391af372504e9163797c0722069ae49466e. Their internal six-draft comparisons
refer to an older snapshot; this paper compares the five actual files,
including relevant optional templates.

The new emitter weakly dominates the measured lower envelope on matched
inputs and strictly improves the seed and all marked inputs. Computation-only
branches may tie. Alphabet, descriptor, quantifier, fixed-cost, and higher-arity
qualifications are stated in the paper. No absolute shortestness is claimed.

The simple formula-level alternative in the paper uses all standard PR
equations, 0 != S0, and a two-occurrence pointed boundary schema. It is
deductively equivalent to PRA in the same language, but is not claimed to
dominate unit descent by repeated formula size. It is distinct from the
optimized scalar emitter.

VERIFICATION
  formal/BoundaryWitness.lean       15 constructive local proof kernels.
  formal/lean_output.txt            Actual successful Lean 4.19.0 output.
  formal/SCOPE.txt                  Exact boundary of the formalization.
  checks/check_schema.py            Independent literal syntax-tree audit.
  checks/check_arithmetic.py        Finite standard-N diagnostics.
  verification/*.json               Recorded results and build/QA records.
  provenance/source_manifest.json   Pinned inputs, Git blobs, SHA-256 hashes.
  SHA256SUMS                       Final package integrity checksums.

All 15 Lean theorem reports have empty axiom dependencies. The entire
bi-interpretation is a written proof, not fully mechanized. Finite Python
tests do not prove the universal arithmetic or metatheoretic statements.

REBUILD
From the extracted directory:
  python3 build.py

To rerun the local Lean kernel with the pinned compiler:
  python3 build.py --lean /absolute/path/to/lean

Requirements: Python 3.10+, pdflatex with the common packages used in
report.tex, and optional Lean 4.19.0. No third-party Python or Lean package
is needed. The build does not download anything. Without --lean the stored
formal verification remains an earlier recorded check, not a new run.

No repository files were modified or published. Downloaded baseline archives,
toolchain binaries, temporary renderings, and LaTeX auxiliary files are not
redistributed in this package.
