import Init

/-!
Constructive local kernels for boundary-witness arithmetic.

The carrier D is arbitrary. The forward derivations assume no induction,
successor coverage, order, or asserted range for recursive states. The
converse selector theorem assumes induction explicitly, for its displayed
invariant only. All assumptions appear as theorem parameters. There are no
new axioms, admitted proofs, classical choice, or imported arithmetic results.

Not formalized here: the finite descriptor grammar, syntactic emitter and
case selection, the truth compiler, scalar pairing, or full bi-interpretability.
-/

universe u
namespace BoundaryWitness

variable {D : Type u}

/-- The witness either precedes a failure or is the requested index. -/
def Boundary (succ : D → D) (F : D → Prop) : Prop :=
  ∀ n, ∃ k, F k ∧ (F (succ k) → k = n)

/-- The extraction itself needs neither a base case nor decidability. -/
theorem boundary_progress
    (succ : D → D) (F : D → Prop)
    (boundary : Boundary succ F)
    (progress : ∀ n, F n → F (succ n)) : ∀ n, F n := by
  intro n
  obtain ⟨k, hk, htarget⟩ := boundary n
  have heq : k = n := htarget (progress k hk)
  exact heq ▸ hk

/-- The direct pointed version recovers the ordinary induction implication. -/
theorem pointed_boundary_induction
    (zero : D) (succ : D → D) (P : D → Prop)
    (boundary : ∀ n, ∃ k,
      (k = zero ∨ P k) ∧ (P (succ k) → k = n))
    (base : P zero) (progress : ∀ n, P n → P (succ n)) :
    ∀ n, P n := by
  intro n
  obtain ⟨k, hk, htarget⟩ := boundary n
  have pk : P k := by
    cases hk with
    | inl hz => exact hz ▸ base
    | inr hp => exact hp
  have heq : k = n := htarget (progress k pk)
  exact heq ▸ pk

/-- Quantifier-free selector invariant, stated as a predicate for this audit. -/
def SelectorInvariant (succ : D → D) (F : D → Prop) (c : D → D)
    (n : D) : Prop := F (c n) ∧ (F (succ (c n)) → c n = n)

/-- The constructive converse uses induction only for the displayed invariant.
    The two step assumptions are the equations of the primitive-recursive
    selector: c(Sn) = Sn when F(S(c(n))), and c(n) otherwise. -/
theorem selector_converse
    (zero : D) (succ : D → D) (F : D → Prop) (c : D → D)
    (base : F zero) (c_zero : c zero = zero)
    (decision : ∀ x, F x ∨ ¬ F x)
    (c_true : ∀ n, F (succ (c n)) → c (succ n) = succ n)
    (c_false : ∀ n, ¬ F (succ (c n)) → c (succ n) = c n)
    (induct : SelectorInvariant succ F c zero →
      (∀ n, SelectorInvariant succ F c n →
        SelectorInvariant succ F c (succ n)) →
      ∀ n, SelectorInvariant succ F c n) : Boundary succ F := by
  have start : SelectorInvariant succ F c zero := by
    constructor
    · rw [c_zero]
      exact base
    · intro _
      exact c_zero
  have step : ∀ n, SelectorInvariant succ F c n →
      SelectorInvariant succ F c (succ n) := by
    intro n ih
    cases decision (succ (c n)) with
    | inl hnext =>
      have hw : c n = n := ih.2 hnext
      have hnew : c (succ n) = succ n := c_true n hnext
      constructor
      · rw [hnew]
        exact hw ▸ hnext
      · intro _
        exact hnew
    | inr hnext =>
      have hnew : c (succ n) = c n := c_false n hnext
      constructor
      · exact hnew ▸ ih.1
      · intro h
        have old : F (succ (c n)) := hnew ▸ h
        exact False.elim (hnext old)
  intro n
  exact ⟨c n, induct start step n⟩

/-- Pointed selector invariant for arbitrary P, with no base assumption on P. -/
def PointedInvariant (zero : D) (succ : D → D) (P : D → Prop)
    (c : D → D) (n : D) : Prop :=
  (c n = zero ∨ P (c n)) ∧ (P (succ (c n)) → c n = n)

theorem pointed_selector_converse
    (zero : D) (succ : D → D) (P : D → Prop) (c : D → D)
    (c_zero : c zero = zero)
    (decision : ∀ x, P x ∨ ¬ P x)
    (c_true : ∀ n, P (succ (c n)) → c (succ n) = succ n)
    (c_false : ∀ n, ¬ P (succ (c n)) → c (succ n) = c n)
    (induct : PointedInvariant zero succ P c zero →
      (∀ n, PointedInvariant zero succ P c n →
        PointedInvariant zero succ P c (succ n)) →
      ∀ n, PointedInvariant zero succ P c n) :
    ∀ n, ∃ k, (k = zero ∨ P k) ∧ (P (succ k) → k = n) := by
  have start : PointedInvariant zero succ P c zero :=
    ⟨Or.inl c_zero, fun _ => c_zero⟩
  have step : ∀ n, PointedInvariant zero succ P c n →
      PointedInvariant zero succ P c (succ n) := by
    intro n ih
    cases decision (succ (c n)) with
    | inl hnext =>
      have hw : c n = n := ih.2 hnext
      have hnew : c (succ n) = succ n := c_true n hnext
      constructor
      · apply Or.inr
        rw [hnew]
        exact hw ▸ hnext
      · exact fun _ => hnew
    | inr hnext =>
      have hnew : c (succ n) = c n := c_false n hnext
      constructor
      · exact hnew ▸ ih.1
      · intro h
        have old : P (succ (c n)) := hnew ▸ h
        exact False.elim (hnext old)
  intro n
  exact ⟨c n, induct start step n⟩

/-- Native-equality decisions are proved from the actual bit clauses. -/
theorem equality_decisions
    (zero one : D) (chi : D → D → D)
    (separation : zero ≠ one)
    (diag : ∀ x, chi x x = one)
    (off : ∀ x y, x = y ∨ chi x y = zero) :
    ∀ x y : D, x = y ∨ x ≠ y := by
  intro x y
  cases off x y with
  | inl heq => exact Or.inl heq
  | inr hz =>
    apply Or.inr
    intro heq
    have hone : chi x y = one := heq ▸ diag x
    exact separation (hz.symm.trans hone)

theorem bit_off_diagonal
    (zero : D) (chi : D → D → D)
    (off : ∀ x y, x = y ∨ chi x y = zero)
    (x y : D) (hne : x ≠ y) : chi x y = zero := by
  cases off x y with
  | inl heq => exact False.elim (hne heq)
  | inr hz => exact hz

def LatchTail (Z bit : D → D → D) (pred : D → D) (v w : D) : D :=
  Z (bit w (pred v)) v

/-- The tail reflection concerns every possible state v. -/
theorem latch_tail_reflection
    (zero : D) (succ pred : D → D) (Z bit : D → D → D)
    (P : D → D → Prop)
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (zzero : ∀ x, Z zero x = x)
    (zstep : ∀ x y, Z (succ x) y = zero)
    (bit_range : ∀ w a, bit w a = zero ∨ bit w a = succ zero)
    (bit_true : ∀ w a, bit w a = zero ↔ P w a)
    (v w a : D) :
    LatchTail Z bit pred v w = succ a ↔ v = succ a ∧ P w a := by
  constructor
  · intro hout
    cases bit_range w (pred v) with
    | inl hb =>
      have hv : v = succ a := by
        simpa only [LatchTail, hb, zzero] using hout
      refine ⟨hv, ?_⟩
      have hp : P w (pred v) := (bit_true w (pred v)).mp hb
      simpa only [hv, pred_succ] using hp
    | inr hb =>
      have hz : zero = succ a := by
        simpa only [LatchTail, hb, zstep] using hout
      exact False.elim (succ_ne_zero a hz.symm)
  · intro h
    have hp : P w (pred v) := by
      simpa only [h.1, pred_succ] using h.2
    have hb : bit w (pred v) = zero := (bit_true w (pred v)).mpr hp
    simpa only [LatchTail, hb, zzero] using h.1

/-- The shifted base follows directly from the pointed first transition. -/
theorem shifted_base
    (zero : D) (succ : D → D) (h R : D → D → D)
    (rzero : ∀ a, R zero a = a)
    (rstep : ∀ n a, R (succ n) a = h (R n a) n)
    (pointed : ∀ a, h a zero = a) :
    ∀ a, R (succ zero) a = a := by
  intro a
  rw [rstep, rzero, pointed]

/-- Forward bootstrap on an arbitrary carrier, with local base and progress.
    The only reflection assumed is the exact double-guard result above. -/
theorem shifted_boundary_induction
    (zero : D) (succ : D → D) (h R : D → D → D)
    (P : D → D → Prop)
    (rstep : ∀ n a, R (succ n) a = h (R n a) n)
    (reflection : ∀ v n b, h v n = succ b ↔
      v = succ b ∧ (n = zero ∨ P n b))
    (boundary : ∀ a n, ∃ k,
      R (succ k) a = a ∧ (R (succ (succ k)) a = a → k = n))
    (b : D) (base : P zero b)
    (progress : ∀ n, P n b → P (succ n) b) : ∀ n, P n b := by
  have extract : ∀ n, R (succ n) (succ b) = succ b → P n b := by
    intro n hreturn
    have hout : h (R n (succ b)) n = succ b := by
      rw [← rstep]
      exact hreturn
    have hp := ((reflection (R n (succ b)) n b).mp hout).2
    cases hp with
    | inl hz => exact hz ▸ base
    | inr hp => exact hp
  have advance : ∀ n, R (succ n) (succ b) = succ b →
      R (succ (succ n)) (succ b) = succ b := by
    intro n hreturn
    have hp : P (succ n) b := progress n (extract n hreturn)
    rw [rstep]
    exact (reflection (R (succ n) (succ b)) (succ n) b).mpr
      ⟨hreturn, Or.inr hp⟩
  have all_returns : ∀ n, R (succ n) (succ b) = succ b :=
    boundary_progress succ (fun n => R (succ n) (succ b) = succ b)
      (boundary (succ b)) advance
  intro n
  exact extract n (all_returns n)

/-- Identity padding is transparent at the term level. Raw-descriptor alias
    recognition belongs to the separate executable syntax audit. -/
theorem tail_padding
    (succ : D → D) (Q tail : D → D → D)
    (qstep : ∀ x y, Q (succ x) y = x) (v w : D) :
    Q (succ (tail v w)) v = tail v w := qstep (tail v w) v

/-- The final presentation needs only this single counter guard. -/
def CounterGuard (zero : D) (succ : D → D)
    (Q Z chi tail : D → D → D) (v w : D) : D :=
  Q (Z (chi w zero) (succ (tail v w))) v

theorem counter_guard_zero
    (zero : D) (succ : D → D) (Q Z chi tail : D → D → D)
    (diag : ∀ x, chi x x = succ zero)
    (qzero : ∀ x, Q zero x = x)
    (zstep : ∀ x y, Z (succ x) y = zero) (v : D) :
    CounterGuard zero succ Q Z chi tail v zero = v := by
  unfold CounterGuard
  rw [diag, zstep, qzero]

theorem counter_guard_running
    (zero : D) (succ : D → D) (Q Z chi tail : D → D → D)
    (off : ∀ x y, x ≠ y → chi x y = zero)
    (qstep : ∀ x y, Q (succ x) y = x)
    (zzero : ∀ x, Z zero x = x)
    (v w : D) (hw : w ≠ zero) :
    CounterGuard zero succ Q Z chi tail v w = tail v w := by
  unfold CounterGuard
  rw [off w zero hw, zzero, qstep]

/-- Reflection for the actual final marked body, on all states v. -/
theorem counter_guard_latch_reflection
    (zero : D) (succ pred : D → D)
    (Q Z chi bit : D → D → D) (P : D → D → Prop)
    (eq_dec : ∀ x y : D, x = y ∨ x ≠ y)
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (diag : ∀ x, chi x x = succ zero)
    (off : ∀ x y, x ≠ y → chi x y = zero)
    (qzero : ∀ x, Q zero x = x)
    (qstep : ∀ x y, Q (succ x) y = x)
    (zzero : ∀ x, Z zero x = x)
    (zstep : ∀ x y, Z (succ x) y = zero)
    (bit_range : ∀ w a, bit w a = zero ∨ bit w a = succ zero)
    (bit_true : ∀ w a, bit w a = zero ↔ P w a)
    (v w a : D) :
    CounterGuard zero succ Q Z chi (LatchTail Z bit pred) v w = succ a ↔
      v = succ a ∧ (w = zero ∨ P w a) := by
  cases eq_dec w zero with
  | inl hw =>
    constructor
    · intro hout
      have hv : v = succ a := by
        rw [hw, counter_guard_zero zero succ Q Z chi
          (LatchTail Z bit pred) diag qzero zstep v] at hout
        exact hout
      exact ⟨hv, Or.inl hw⟩
    · intro h
      rw [hw, counter_guard_zero zero succ Q Z chi
        (LatchTail Z bit pred) diag qzero zstep v]
      exact h.1
  | inr hw =>
    have run := counter_guard_running zero succ Q Z chi
      (LatchTail Z bit pred) off qstep zzero v w hw
    have refl := latch_tail_reflection zero succ pred Z bit P
      succ_ne_zero pred_succ zzero zstep bit_range bit_true v w a
    constructor
    · intro hout
      have ht : LatchTail Z bit pred v w = succ a := run.symm.trans hout
      have h := refl.mp ht
      exact ⟨h.1, Or.inr h.2⟩
    · intro h
      have hp : P w a := by
        cases h.2 with
        | inl hz => exact False.elim (hw hz)
        | inr hp => exact hp
      exact run.trans (refl.mpr ⟨h.1, hp⟩)

/-- Once the syntactic alias selects the same R, its emitted step is the
    missing ordinary left step by one computation of Q. -/
theorem alias_step_recovery
    (succ : D → D) (Q R body : D → D → D)
    (qstep : ∀ x y, Q (succ x) y = x)
    (alias_step : ∀ n a,
      R (succ n) a = Q (succ (body (R n a) n)) n) :
    ∀ n a, R (succ n) a = body (R n a) n := by
  intro n a
  exact (alias_step n a).trans (qstep (body (R n a) n) n)

/-- Composition of the actual counter-guard latch with the new boundary
    axiom: the full local bootstrap, still on an arbitrary carrier. -/
theorem counter_guard_boundary_induction
    (zero : D) (succ pred : D → D)
    (Q Z chi bit R : D → D → D) (P : D → D → Prop)
    (eq_dec : ∀ x y : D, x = y ∨ x ≠ y)
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (diag : ∀ x, chi x x = succ zero)
    (off : ∀ x y, x ≠ y → chi x y = zero)
    (qzero : ∀ x, Q zero x = x)
    (qstep : ∀ x y, Q (succ x) y = x)
    (zzero : ∀ x, Z zero x = x)
    (zstep : ∀ x y, Z (succ x) y = zero)
    (bit_range : ∀ w a, bit w a = zero ∨ bit w a = succ zero)
    (bit_true : ∀ w a, bit w a = zero ↔ P w a)
    (rstep : ∀ n a, R (succ n) a =
      CounterGuard zero succ Q Z chi (LatchTail Z bit pred) (R n a) n)
    (boundary : ∀ a n, ∃ k,
      R (succ k) a = a ∧ (R (succ (succ k)) a = a → k = n))
    (b : D) (base : P zero b)
    (progress : ∀ n, P n b → P (succ n) b) : ∀ n, P n b := by
  apply shifted_boundary_induction zero succ
    (CounterGuard zero succ Q Z chi (LatchTail Z bit pred)) R P rstep
    (fun v w a => counter_guard_latch_reflection zero succ pred Q Z chi bit P
      eq_dec succ_ne_zero pred_succ diag off qzero qstep zzero zstep
      bit_range bit_true v w a)
    boundary b base progress

#print axioms boundary_progress
#print axioms pointed_boundary_induction
#print axioms selector_converse
#print axioms pointed_selector_converse
#print axioms equality_decisions
#print axioms bit_off_diagonal
#print axioms latch_tail_reflection
#print axioms shifted_base
#print axioms shifted_boundary_induction
#print axioms tail_padding
#print axioms counter_guard_zero
#print axioms counter_guard_running
#print axioms counter_guard_latch_reflection
#print axioms alias_step_recovery
#print axioms counter_guard_boundary_induction

end BoundaryWitness
