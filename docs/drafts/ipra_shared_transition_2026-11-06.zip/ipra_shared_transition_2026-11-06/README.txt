A SMALLER COMPLETE CHECKER FOR iPRA
6 November 2026

RESULT

The main result is a complete compact presentation of full first-order
intuitionistic primitive recursive arithmetic, with explicit full-sequent
translations, ordinary full-domain bi-interpretability, and equiconsistency.
The mathematical basis is inherited from the supplied ProveIt draft series.
The new contribution is a smaller complete checker and the proof that its
annotation convention preserves exactly the derivable sequents.

                         Current frontier   New primary   Strict control
Executable AST nodes                  712           683              695
Significant source tokens             664           641              651
Normalized tokens                     662           639              649
Normalized source bytes              2150          2053             2095
Raw source bytes                     2441          2384             2354

These are full-program measurements including JSON input and CLI handling,
under CPython 3.12.14. They establish a strict improvement over the six actual
current archives, including their optional complete historical components.
They do not prove an absolute minimality theorem.

The exact repository snapshot is:
  https://github.com/VladimirReshetnikov/ProveIt/tree/02b045f9f8d7887b27b853520f2cbfa374725a76/docs/drafts

CONTENTS

report.pdf           Complete mathematical and implementation report.
report.tex           Main TeX source, title, comparison, references and code listing.
theory.tex           Native rules, derived logic/arithmetic and bi-interpretation.
implementation.tex  Exact certificate contract and checker correctness proof.
checker.py           Entire primary acceptance program; no local imports.
comparison/          Six unchanged baselines, strict control, measurements,
                     immutable source identities, and wider source inventory.
examples/            Eighteen accepted arithmetic/logical certificates.
validation/          Fixed fixtures, proof normalizers, independent named-binder
                     oracle and reference proof interpreter, and audit notes.
results/             Reproduced measurements, test outcomes, hashes and TeX tables.
reproduce.py         Recompute comparisons and all included validation suites.
build.py             Rebuild the PDF using local pdfLaTeX.
MANIFEST.sha256      Hashes of all other delivered files.

RUNNING

Python 3.10 or later is needed for pattern matching and strict zip.
The checker itself has no third-party Python dependencies.

  python3 checker.py examples/reflexivity.json
  python3 checker.py examples/residual.json
  python3 reproduce.py
  python3 build.py

The first two commands print ACCEPT. Reproduction uses only the Python standard
library and bundled files. PDF rebuilding additionally requires a LaTeX
installation with the packages listed at the start of report.tex. The already
compiled report.pdf is included. Measuring source normalization on another
Python version can change counts; the exact version is recorded in the results.

INPUT BOUNDARY

The checker reads a JSON triple [context, goal, proof]. It strictly validates
every context formula and the goal. The representation of numerical zero is
-1; nonnegative integers are de Bruijn variables. Boolean/float values are
not terms. Signed integer and Boolean hypothesis selectors are harmless
aliases for selecting an already validated context entry.

In a universal elimination, an unused witness field may contain arbitrary
finite JSON. It denotes the default numerical witness zero. Whenever the bound
variable occurs in either formula component, substitution validates the entire
witness as a term. Equality motives, existential-introduction witnesses,
recursor terms, assumptions, and goals retain complete formation checks.
The matched strict control always validates that universal witness field.
The report proves that both interfaces have exactly the same derivable sequents.

VALIDATION AND LIMITS

All 256 frozen regression fixtures passed. Every one of the primary's 194
accepted fixtures was normalized and rechecked by both the strict control and
the frozen older smaller-checker, with literally unchanged context and goal.
The separate independent suite passes 4904 checks for each candidate, including
182 certificate cases, named-variable substitution/deletion tests, an explicit
rule interpreter, and JSON/CLI runs with normal Python and -O.

The report supplies the mathematical proofs. Finite tests are regression
evidence, not proofs of consistency or a Lean/Rocq verification of Python.
Resource exhaustion may reject a large proof; mathematical completeness refers
to finite derivations in ideal execution without resource bounds.

ATTRIBUTION

The recursor/Pi/E basis, arithmetic library, connective amalgamation, and
ordinary realization are developed in the supplied ProveIt drafts. Shared
local number-binder handling, inferred existential conclusions, and structural
computation clauses combine ideas present in separate current drafts. The
named-binder testing design is adapted with credit from their independent
audit. Exact source provenance is recorded in comparison/manifest.json and
validation/manifest.json. This bundle claims no new authorship for those
inherited mathematical constructions or baseline programs.

The report includes a Further research questions section.
