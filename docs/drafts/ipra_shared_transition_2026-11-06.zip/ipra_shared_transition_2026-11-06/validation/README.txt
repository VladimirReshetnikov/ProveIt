PORTABLE FIXTURE VALIDATION

This directory contains 256 frozen JSON certificates, their exact manifest, a
portable runner, and the recorded result of running it. It requires Python 3.10
or later and only the Python standard library. No generator, network access,
archive extraction, or other files from the development workspace are needed.

Place this directory at validation/ in the delivered bundle. From the bundle
root run:

    python3 validation/run_fixtures.py

The default checker paths are:
    checker.py
    comparison/strict_checker.py
    comparison/baselines/smaller.py

The baseline filename is smaller.py. The runner verifies all three exact
SHA-256 hashes before loading them. If the files are arranged differently, use
--primary PATH --strict PATH --source PATH. --output PATH selects the result
file; its default is validation/results.json.

All application-specific acceptance logic is inside the three respective
checker files. This runner, its occurrence test, the proof normalizers, the
fixture manifest, and the results are UNTRUSTED DEVELOPMENT SUPPORT. None is
imported by an acceptance checker. Passing this corpus is finite evidence, not
a proof-assistant verification of the metatheory or a universal soundness test.

CONTENTS AND EXPECTATIONS

- 150 inherited positive certificates: all 18 supplied arithmetic examples and
  132 accepted canonical logical fixtures, translated to the new certificate
  format. Both the primary and strict control accept all of them.
- 44 vacuous Pi eliminations with malformed witness payloads: the primary
  accepts them, the strict control rejects them, and normalization replaces
  the unused payload by numerical zero.
- 44 used malformed witnesses: both programs reject them. Occurrences in
  antecedents, consequents, nested existential formulas, and recursor update
  bodies are tested.
- 10 malformed equality motives and 8 other native negative cases: both
  programs reject them. The latter include an invalid recursor update hidden
  by a later vacuous transport and an invalid pack witness.

There are 194 primary acceptances and 62 primary rejections. Every primary
acceptance is additionally normalized into a proof checked by the strict
control and a proof checked by the frozen source smaller-checker. The claimed
context and conclusion remain literally unchanged.

The manifest records each fixture's bytes hash, its expected results, and the
exact bytes hashes of both normalized proof certificates when applicable.
JSON serialization for those normalization hashes is specified in the manifest.
It also records the exact repository snapshot and the source checker's archive
provenance. The runner verifies these hashes, expected acceptance decisions,
normalization hashes, restored-proof acceptance, and all group totals.

NORMALIZATION

The function uses_slot walks the inferred principal formula with binding depth,
so a locally bound variable is not mistaken for the variable being eliminated.
For a vacuous Pi elimination, restore replaces its witness field with -1, the
encoding of numerical zero. For equality elimination it preserves the motive:
actual substitutions already validate its entire formula tree. To target the
older source checker, restore also reinserts the inferred conclusion annotation
at each existential elimination. Fresh-variable scope deletion has already
ensured that this conclusion is independent of the eliminated witness.

The fixture files and their labels are frozen; this runner does not regenerate
them from the implementation under test. The normalized proofs are recomputed
and compared to their frozen expected hashes before either target checks them.
