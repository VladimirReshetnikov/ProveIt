EXACT CURRENT BASELINE COMPARISON

Snapshot: VladimirReshetnikov/ProveIt
          02b045f9f8d7887b27b853520f2cbfa374725a76
Directory: docs/drafts
Retrieved user-local date: 6 November 2026

The six files in baselines/ are unchanged copies of the complete top-level
checker.py files from the six archives at this snapshot. Their arithmetic,
logical basis and implementation ideas belong to the supplied ProveIt draft
series; this comparison claims no new authorship for them. manifest.json records
immutable repository links, exact archive SHA-256 hashes, Git blob SHA-1 hashes,
archive member paths, and exact checker SHA-256 hashes. Every copied checker was
byte-compared against its original ZIP member.

OFFLINE REPRODUCTION

Only Python 3.10+ and its standard library are required. No compared checker is
executed by the measurement script. Run from the deliverable's top directory:

  python3 comparison/measure.py --candidate checker.py --out results/comparison.json

Or, from this directory:

  python3 measure.py --candidate ../checker.py --out measured.json

Omit --candidate to reproduce the archived baseline table alone. The script
checks all six frozen baseline hashes before measuring them. Exact Python
versions are recorded because AST normalization can vary across Python releases.

The coordinatewise envelope of these six current files is:

  executable AST nodes       712
  significant source tokens  664
  normalized tokens          662
  normalized source bytes  2150
  raw source bytes         2441

The first four minima come from inferred.py. The raw-byte minimum comes from
compact.py. compact.py and compact_2.py are different supplied implementations,
not duplicate copies. The historical 750-node envelope cited in their reports
belongs to a previous snapshot and is not the current comparison target.

MEASUREMENT BOUNDARY AND DEFINITIONS

All application-specific acceptance code is counted: syntax validation,
substitution, logical rules, arithmetic, axiom data, imports and the JSON/CLI
wrapper. The only runtime shared with a candidate of this form is Python and its
standard library. Source-size metrics do not count untrusted proof generators,
the present measurement scripts, independent test oracles or mathematical prose.

AST nodes: all nodes visited by ast.walk after deleting actual module, function
and class docstrings. Significant source tokens: the original Python tokens,
excluding docstrings, comments and whitespace/control-layout tokens. Normalized
tokens and bytes: ast.unparse of the same stripped AST plus one newline. Raw
bytes: the original source including comments and documentation. Source tokens
and normalized tokens are separate columns because parentheses can normalize
away. No minification or compressed data are used to measure these baselines.

WIDER INVENTORY

source_scan.json is the frozen wider scan of all Python members in the six
archives: 890 occurrences, 241 distinct byte hashes. Selecting files with
top-level FunctionDef definitions named both infer and check gives 787
occurrences and 168 distinct hashes. Each record retains all archive/member
occurrences and its exact source hash. This mechanical filter is an inventory,
not a certificate that every selected historical file is complete or correct.

Every standalone optional competitor in that scan is at or above the current
envelope. The 34 distinct Python sources with fewer than 712 executable AST
nodes are included separately in the scan data. They are helpers, translators,
build/reproduction/measurement scripts, or incomplete checker modules importing
additional local acceptance code. They are not smaller complete checkers.

historical_groups_summary.json records separate dependency-accounted
measurements of the 74 historical groups listed by the unnumbered compact
archive's own comparison manifest, preserving labels, boundary qualifications
and dependency hashes. Each dependency is counted once per group. Some supplied
groups are expressly favorable core-only comparisons. Their coordinatewise
minima are 1154 AST nodes, 1089 source tokens, 3486 normalized bytes and 3817 raw
bytes, so they do not change the current frontier. Those group boundaries are
inherited from the supplied inventory; these arithmetic checks do not certify
the mathematical claims or completeness of all historical systems.

To repeat the wider scan, obtain the six original ZIPs named by manifest.json
and place them in one directory. They are unnecessary for the six-baseline
comparison and are omitted here to keep the deliverable compact. Then run:

  python3 measure.py --archives /path/to/archives --scan-out rescanned.json

The script verifies both archive SHA-256 and Git blob SHA-1 before scanning.
The underlying nested source files for historical group recomputation remain
in those original archives; this compact folder records their identities and
measurements without duplicating the full nested history.

INTERPRETATION

This is a reproducible comparison against the supplied finite implementation
frontier. It is not an absolute lower-bound theorem, a machine-checked proof of
soundness, or a proof that an axiomatization is globally shortest. Raw bytes are
a secondary metric because they depend on explanatory comments. The important
comparison is with the actual current files, not their retrospective tables.
