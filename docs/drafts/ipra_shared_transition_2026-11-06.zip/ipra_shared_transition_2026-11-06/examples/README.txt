EXAMPLE CERTIFICATES

This directory contains 18 arithmetic and logical proof certificates accepted
by both the primary checker and its strict control. From the delivered bundle
root, for example, run:

    python3 checker.py examples/reflexivity.json
    python3 checker.py examples/residual.json
    python3 checker.py examples/forall_exists_successor.json

Each file is a finite JSON triple [context, conclusion, proof]. A successful run
prints ACCEPT; a failed run prints REJECT and exits with status 1. Some files
are sequents with assumptions, rather than closed theorems. The complete
calculus and arithmetic abbreviations are specified in the accompanying report.

The collection covers:

- Equality reflexivity and successor injectivity.
- Existential witnesses and zero/successor coverage.
- Addition and iterated-predecessor identities.
- Successor cancellation and diagonal subtraction identities.
- The residual identity and the two directions of equality-test reflection.

The filenames are:
    coverage.json
    diff_cancel.json
    diff_diagonal.json
    diff_successor_diagonal.json
    direct_successor_plus_n.json
    direct_zero_plus_n.json
    epsilon_zero_implies_equal.json
    equal_implies_epsilon_zero.json
    forall_exists_successor.json
    one_residual_implies_equal.json
    q_zero_implies_one.json
    reflexivity.json
    residual.json
    successor_injective.json
    successor_plus.json
    zero_diff.json
    zero_plus.json
    zero_plus_n.json

These examples are adapted from the supplied ipra_smaller_checker_2026-11-06
archive at ProveIt commit 02b045f9f8d7887b27b853520f2cbfa374725a76. Their
contexts and conclusions are unchanged; existential-elimination conclusion
annotations were removed because the new checker infers them. They are not
new mathematical claims. The validation manifest includes exact hashes for
these 18 certificates and for their successful restorations to the source
certificate format.

Proof generation and the validation runner are not trusted by checker.py.
The examples are ordinary untrusted inputs to its complete acceptance code.
