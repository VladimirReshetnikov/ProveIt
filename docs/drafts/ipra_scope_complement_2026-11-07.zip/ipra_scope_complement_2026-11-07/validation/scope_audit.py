"""Independent, finite audit of the scope-complement opening theorem.

This is untrusted test support.  Neither proof checker imports this module.
The test canonicalizer follows the named term/formula grammar, not the
checkers' byte-table traversal.  Finite agreement is evidence for, not a
formal proof of, the theorem in scope_theorem.txt.
"""

from __future__ import annotations

import argparse
import ast
from collections import Counter
from copy import deepcopy
from functools import lru_cache
import hashlib
from itertools import product
import json
from pathlib import Path
import platform
import types


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DEFAULT_OLD = ROOT / "comparison/checker_integration_control.py"
DEFAULT_NEW = ROOT / "checker.py"


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def opening_module(path):
    """Extract only k and inst; importing a direct CLI would run its driver."""
    tree = ast.parse(Path(path).read_text())
    body = [
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "inst"
        or isinstance(node, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "k" for t in node.targets)
    ]
    require(len(body) == 2, ("Expected k and inst", str(path)))
    module = types.ModuleType("isolated_opening")
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), "exec"),
         module.__dict__)
    return module


def canonicalize(tree, floor, protected=0, numerical=False):
    """Total raw-JSON canonicalizer, with explicit sorted grammar.

    At a numerical leaf below `protected` local numerical binders, keep
    exactly the integers in [floor, 2*protected+1).  All others name the
    one exposed hole.  Malformed nodes are retained, so they still fail
    the old opener.  An image is never passed through this function.
    """
    if numerical and type(tree) is int:
        ceiling = 2 * protected + 1
        return tree if floor <= tree < ceiling else ceiling
    if type(tree) is not list:
        return deepcopy(tree)
    if numerical:
        if len(tree) == 1:  # successor
            return [canonicalize(tree[0], floor, protected, True)]
        if len(tree) == 3:  # scalar iteration, binding only in its update
            counter, initial, update = tree
            return [canonicalize(counter, floor, protected, True),
                    canonicalize(initial, floor, protected, True),
                    canonicalize(update, floor, protected + 1, True)]
    else:
        if len(tree) == 1:  # closure
            return [canonicalize(tree[0], floor, protected + 1, False)]
        if len(tree) == 2:  # equality
            return [canonicalize(child, floor, protected, True)
                    for child in tree]
        if len(tree) == 3:  # paired binder, including its checked padding
            return [canonicalize(child, floor, protected + 2, False)
                    for child in tree]
    return deepcopy(tree)  # wrong constructor arity


def raw_key(value):
    """JSON spelling distinguishes bool/int/float, unlike Python ==."""
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(",", ":"))


def outcome(module, tree, image, depth, floor):
    module.k = floor
    try:
        result = module.inst(tree, image, depth)
    except Exception as error:
        require(module.k == floor, "An opening changed the global floor")
        return False, type(error).__name__
    require(module.k == floor, "An opening changed the global floor")
    return True, result


def agrees(left, right):
    return left[0] == right[0] and (
        not left[0] or raw_key(left[1]) == raw_key(right[1])
    )


def compare(old, new, tree, image, depth, floor, counts, label):
    normalized = canonicalize(tree, floor, depth // 2, bool(depth % 2))
    expected = outcome(old, normalized, image, depth, floor)
    actual = outcome(new, tree, image, depth, floor)
    require(agrees(expected, actual), {
        "label": label, "tree": tree, "canonical": normalized,
        "image": image, "depth": depth, "floor": floor,
        "old": expected, "new": actual,
    })
    counts["canonicalization_cases"] += 1
    counts["defined" if actual[0] else "undefined"] += 1


def compositions(total, parts):
    if parts == 0:
        if total == 0:
            yield ()
        return
    for first in range(1, total - parts + 2):
        for rest in compositions(total - first, parts - 1):
            yield (first,) + rest


# This domain is exactly specified and exhaustively generated.  Each scalar
# or empty list has one node; a nonempty list has one plus its children's.
ATOMIC_DOMAIN = (-2, 0, 2, None, True)


@lru_cache(maxsize=None)
def trees_of_size(size):
    result = list(ATOMIC_DOMAIN) + [[]] if size == 1 else []
    for arity in range(1, min(4, size - 1) + 1):
        for sizes in compositions(size - 1, arity):
            for children in product(*(trees_of_size(n) for n in sizes)):
                result.append(list(children))
    return tuple(result)


def finite_exhaustion(old, new):
    trees = [tree for size in range(1, 6) for tree in trees_of_size(size)]
    images = [None, -3, -1, 0, 1, True, [0], [0, 0, 1]]
    floors, depths = (0, -1, -3), tuple(range(6))
    counts = Counter()
    for floor, depth, tree in product(floors, depths, trees):
        # With no image, validation is EXACTLY unchanged on the raw input;
        # successful output must be the very same raw syntax tree.
        previous = outcome(old, tree, None, depth, floor)
        current = outcome(new, tree, None, depth, floor)
        require(agrees(previous, current), {
            "label": "no-image-identity", "tree": tree,
            "depth": depth, "floor": floor,
            "old": previous, "new": current,
        })
        if current[0]:
            require(raw_key(current[1]) == raw_key(tree),
                    ("Successful validation changed its input", tree))
        counts["no_image_cases"] += 1
        for image in images:
            compare(old, new, tree, image, depth, floor, counts,
                    "all_raw_trees_through_five_nodes")
    return {
        "domain": {"atomic_values": list(ATOMIC_DOMAIN),
                   "array_arities": [0, 1, 2, 3, 4],
                   "maximum_tree_nodes": 5,
                   "tree_count": len(trees),
                   "counts_by_size": {str(n): len(trees_of_size(n))
                                      for n in range(1, 6)},
                   "floors": list(floors), "depths": list(depths),
                   "images": images},
        "counts": dict(counts),
    }


def threshold_and_nesting_grid(old, new):
    """Vary thresholds and test deeply nested, intentionally malformed trees."""
    counts = Counter()
    floors, depths = (0, -1, -4, -19), tuple(range(10))
    other_leaves = [True, False, None, 0.0, 1.0, -1.0, "x", "", {}, {"x": 0}]
    shapes = 0
    for floor, depth in product(floors, depths):
        leaves = [floor - 20, floor - 1, floor, floor + 1,
                  -1, 0, 1, 2, depth - 1, depth, depth + 1,
                  depth + 2, 10**30, -(10**30), *other_leaves]
        images = [None, floor - 1, floor, -1, 0, 1, depth + 1,
                  True, False, 0.0, "x", [], {}, [0], [1],
                  [0, 0, 1], [0, 0, floor - 1],
                  [0, 0, [0, 1, 3]], [0, 0, [0, 1, floor - 1]]]
        for leaf in leaves:
            templates = [
                leaf,
                [leaf],
                [leaf, 0],
                [0, leaf],
                [leaf, 0, 0],
                [0, leaf, 0],
                [0, 0, leaf],
                [[leaf, 0]],
                [[[leaf, 0]]],
                [[leaf, 0], [0, 0], [0, 0]],
                [[0, 0], [leaf, 0], [0, 0]],
                [[0, 0], [0, 0], [leaf, 0]],
                [[[leaf, 0]], [0, 0], [0, 0]],
                [[leaf, 0, 1], 0],
                [[0, 0, [leaf]], 0],
                [[0, 0, [0, 1, leaf]], 0],
                [[1, 0, [0, leaf, 3]], 0],
                [[[[0, 0, [0, 1, leaf]], 0]]],
                [0, 0, 0, leaf],
                [[0, 0, 0, leaf], 0],
            ]
            shapes += len(templates)
            for tree, image in product(templates, images):
                compare(old, new, tree, image, depth, floor, counts,
                        "threshold_and_nested_grammar_grid")
    return {"floors": list(floors), "depths": list(depths),
            "template_instances": shapes, "counts": dict(counts)}


def critical_cases(old, new):
    # Every success/failure here has an independent expected outcome.
    # Positive `1` is an exposed coordinate, not numerical one (which is [0]).
    examples = [
        ("negative template alias", [-1, 0], 0, 0, 0, [0, 0]),
        ("far negative alias", [-(10**30), 0], [0], 0, -4, [[0], 0]),
        ("negative closed goal", [-1, 0], None, 0, 0, None),
        ("future negative image", [1, 0], -1, 0, 0, None),
        ("future negative image below inner binder", [[-1, 0]], -1, 0, 0, None),
        ("positive image capture attack", [[-1, 0]], 1, 0, 0, None),
        ("local bound variable preserved", [[1, -1]], [0], 0, 0, [[1, [0]]]),
        ("two protected variables", [[1, -1], [3, 0], [0, 0]], [0], 0, 0,
         [[1, [0]], [3, 0], [0, 0]]),
        ("negative hole in checked padding", [[0, 0], [-1, 0], [0, 0]], [0], 0, 0,
         [[0, 0], [[0], 0], [0, 0]]),
        ("bad image used only in padding", [[0, 0], [-1, 0], [0, 0]], -1, 0, 0, None),
        ("nested iterator update hole", [0, 0, -1], [0, 0, 1], 1, 0,
         [0, 0, [0, 0, 1]]),
        ("invalid nested image remains invalid", [1, 0], [0, 0, -1], 0, 0, None),
        ("iterator local image coordinate", [1, 0], [0, 0, 1], 0, 0,
         [[0, 0, 1], 0]),
        ("unused malformed image", [0, 0], {"bad": -1}, 0, 0, [0, 0]),
        ("Boolean template rejected", [True, 0], 0, 0, 0, None),
        ("Boolean image rejected", [1, 0], True, 0, 0, None),
        ("float template rejected", [0.0, 0], 0, 0, 0, None),
        ("float image rejected", [1, 0], 0.0, 0, 0, None),
        ("equation encoded in term position", [[0, 0], 0], 0, 0, 0, None),
        ("numeral encoded in formula position", [0], 0, 0, 0, None),
        ("empty syntax array", [], 0, 0, 0, None),
        ("wrong term arity", [0, 0, 0, 0], 0, 1, 0, None),
        ("declared negative name", [-1, 0], [0], 0, -1, [-1, 0]),
        ("undeclared negative at next floor", [-2, 0], [0], 0, -1, [[0], 0]),
        ("large positive hole remains supported", [10**30, 0], [0], 0, 0,
         [[0], 0]),
    ]
    results = []
    counts = Counter()
    for label, tree, image, depth, floor, expected_value in examples:
        actual = outcome(new, tree, image, depth, floor)
        expected = expected_value is not None
        require(actual[0] == expected and (
            not expected or raw_key(actual[1]) == raw_key(expected_value)),
            (label, actual, expected_value))
        compare(old, new, tree, image, depth, floor, counts, label)
        results.append({"name": label, "defined": actual[0],
                        "result": actual[1] if actual[0] else None})
    # This explicitly records why canonicalization is invocation-relative.
    before = outcome(new, [-1, 0], [0], 0, 0)
    after = outcome(new, [-1, 0], [0], 0, -1)
    require(before == (True, [[0], 0]) and after == (True, [-1, 0]),
            "The floor-sensitive classification example changed")
    return {"cases": results, "counts": dict(counts),
            "floor_sensitive_example": {
                "template": [-1, 0], "image": [0],
                "at_floor_zero": before[1], "at_floor_minus_one": after[1]}}


def source_path(path):
    resolved = path.resolve()
    try:
        return resolved.relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return str(resolved)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--old", type=Path, default=DEFAULT_OLD)
    parser.add_argument("--new", type=Path, default=DEFAULT_NEW)
    parser.add_argument("--output", type=Path, default=HERE / "scope_audit.json")
    args = parser.parse_args()
    old, new = opening_module(args.old), opening_module(args.new)
    result = {"status": "PASS", "python": platform.python_version(),
              "old": {"path": source_path(args.old),
                      "sha256": hashlib.sha256(args.old.read_bytes()).hexdigest()},
              "new": {"path": source_path(args.new),
                      "sha256": hashlib.sha256(args.new.read_bytes()).hexdigest()},
              "finite_exhaustion": finite_exhaustion(old, new),
              "threshold_grid": threshold_and_nesting_grid(old, new),
              "critical_cases": critical_cases(old, new)}
    result["total_canonicalization_cases"] = sum(
        result[part]["counts"]["canonicalization_cases"]
        for part in ("finite_exhaustion", "threshold_grid", "critical_cases")
    )
    result["total_no_image_cases"] = result["finite_exhaustion"]["counts"]["no_image_cases"]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in (
        "status", "total_canonicalization_cases", "total_no_image_cases")}, indent=2))
    return result


if __name__ == "__main__":
    main()
