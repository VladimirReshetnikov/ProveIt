"""Independent finite certificate audit for scope-complement opening.

The production checker imports none of this support. Run from any directory:
    python3 validation/verify.py --checker checker.py

The named oracle uses named binders and explicit syntactic categories. Every
accepted audited packet is also translated to the frozen five-rule scalar
checker, which independently checks the emitted proof of the same closed goal.
"""
import argparse
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile

from compile_to_baseline import Compiler
from mutation_support import mutate
from named_oracle import Oracle

HERE = Path(__file__).resolve().parent


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def digest(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def file_hash(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def kernel(path, replacement=None):
    """Load the exact function bodies without running a standalone CLI.

    Only imports, definitions, and the initial declaration floor are retained;
    no function body is rewritten. Separate subprocess tests audit the driver.
    """
    source = Path(path).read_text()
    if replacement:
        old, new = replacement
        require(source.count(old) == 1, ('nonunique mutation anchor', old))
        source = source.replace(old, new)
    tree = ast.parse(source)
    tree.body = [node for node in tree.body
                 if isinstance(node, (ast.FunctionDef, ast.Import, ast.ImportFrom))
                 or (isinstance(node, ast.Assign)
                     and any(isinstance(t, ast.Name) and t.id == 'k' for t in node.targets))]
    namespace = {}
    exec(compile(tree, str(path), 'exec'), namespace)
    return namespace


def run(namespace, packet):
    namespace['k'] = 0
    stack = deepcopy(packet)
    try:
        namespace['take'] = stack.pop
        accepted = bool(namespace['check'](stack.pop(), []))
        error = None
    except Exception as exception:
        accepted, error = False, type(exception).__name__
    return {'accepted': accepted, 'final_k': namespace['k'],
            'remaining': len(stack) if type(stack) is list else None, 'error': error}


def rewrite_holes(value, lower, alias, formula=True, depth=0):
    """Independent explicit grammar; never uses the production packed table."""
    if not formula and type(value) is int:
        return alias() if value < lower or value > 2 * depth else value
    require(type(value) is list, 'aliased template is not a list')
    if formula:
        if len(value) == 2:
            return [rewrite_holes(v, lower, alias, False, depth) for v in value]
        require(len(value) in (1, 3), 'invalid formula constructor')
        bound = 1 if len(value) == 1 else 2
        return [rewrite_holes(v, lower, alias, True, depth + bound) for v in value]
    if len(value) == 1:
        return [rewrite_holes(value[0], lower, alias, False, depth)]
    require(len(value) == 3, 'invalid numerical constructor')
    return [rewrite_holes(value[0], lower, alias, False, depth),
            rewrite_holes(value[1], lower, alias, False, depth),
            rewrite_holes(value[2], lower, alias, False, depth + 1)]


def aliased(packet, trace, variant):
    result = deepcopy(packet)
    for item in trace['transports']:
        lower = item['lower_after_major']
        count = 0
        def image():
            nonlocal count
            count += 1
            if variant == 'next_unknown':
                return lower - 1
            if variant == 'huge_unknown':
                return lower - 10 ** 60
            return lower - count - 7 if count % 2 else 10 ** 40 + count
        i = item['instruction_index']
        result[i][1] = rewrite_holes(result[i][1], lower, image)
    return result


def new_cases():
    """Floor changes, negative-image attacks, and nested template examples."""
    rows = []
    def add(name, cells, goal, expected, reason):
        rows.append({'name': name, 'packet': list(reversed(cells)) + [goal],
                     'expected': expected, 'reason': reason})
    major = [[0, 0, 0], 0]
    for alias in (-1, -2, -999, -(10 ** 100)):
        add('negative_motive_' + str(abs(alias)),
            [[major, [alias, 0]], [], []], [0, 0], True,
            'An undeclared negative integer is a template hole, not a rigid parameter.')
    reflexivity_major = [[[0], 0, major[0]], major[0]]
    add('mixed_signed_holes', [[major, [-7, 10 ** 40]], [],
                              [reflexivity_major, [1, major[0]]], [], []], [0, 0], True,
        'Different signed spellings denote one common hole.')

    paired = [major, [0, 0], [0, 0]]
    # This major proof allocates -1 during introduction and -2 on elimination.
    allocated_major = [[paired, None], [0], [], []]
    for alias in (-1, -2, -3, -10 ** 30):
        add('major_allocation_boundary_' + str(abs(alias)),
            [[major, [alias, 0]], *allocated_major, []], [0, 0], alias < -2,
            'Classification uses the floor after the major proof: -1 and -2 are then rigid.')
    for alias in (-1, -2, -999):
        add('future_name_in_closed_goal_' + str(abs(alias)),
            [[major, [alias, 0]], *allocated_major, []], [alias, 0], False,
            'A future name in the closed goal cannot be justified by a later allocation.')

    # A paired introduction really uses its witness; unknown negative images
    # must not be mistaken for template holes during image validation.
    body = [[0, 3, 0], 3]
    for witness in (-1, -999, [0, 0, -999], 1, [1]):
        add('invalid_used_witness_' + digest(witness)[:12], [[witness], []],
            [body, [0, 0], [0, 0]], False,
            'Used images are checked without an image and must be closed at insertion.')
    add('valid_used_witness', [[0], []], [body, [0, 0], [0, 0]], True,
        'The corresponding well-scoped witness is accepted.')

    # The active hole occurs under a closure and an iterator-update binder.
    motive = [[[0, -99, [0, 1, -1000]], -101]]
    def closure_proof(image):
        b = [[0, image, [0, 1, image]], image]
        d = [b, [0, 0], [0, 0]]
        return [b], [[d, None], [0], []]
    goal, _ = closure_proof(0)
    _, minor = closure_proof(major[0])
    add('nested_negative_motive', [[major, motive], [], *minor], goal, True,
        'The same hole is opened beneath logical and numerical binders without capture.')
    return rows


def cli(checker, packet_path, expected, optimized=False):
    command = [sys.executable, *(['-O'] if optimized else []), str(checker), str(packet_path)]
    result = subprocess.run(command, capture_output=True, text=True, timeout=20)
    wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
    actual = result.returncode, result.stdout.strip(), result.stderr
    require(actual == wanted, ('CLI mismatch', packet_path.name, optimized, actual, wanted))
    return {'optimized': optimized, 'exit_code': result.returncode,
            'stdout': result.stdout.strip()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, default=HERE.parent / 'checker.py')
    parser.add_argument('--output', type=Path, default=HERE / 'results.json')
    args = parser.parse_args()
    candidate_path = args.checker.resolve()
    candidate = kernel(candidate_path)
    baseline = kernel(HERE / 'baseline_scalar.py')
    provenance = json.loads((HERE / 'provenance.json').read_text())
    for name, item in provenance['files'].items():
        require(file_hash(HERE / name) == item['delivered_sha256'], ('changed support', name))
    rows = json.loads((HERE / 'inherited_fixtures.json').read_text())
    rows += json.loads((HERE / 'new_fixtures.json').read_text())
    changed_name = 'new/used_future_motive_parameter'
    for row in rows:
        row['previous_expected'] = row['expected']
        if row['name'] == changed_name:
            row['expected'] = True
    new = new_cases()
    require(len(rows) == 207, 'inherited fixture count changed')
    examples = HERE.parent / 'examples'
    examples.mkdir(exist_ok=True)
    for row in new:
        (examples / (row['name'] + '.json')).write_text(json.dumps(row['packet'], indent=2) + '\n')

    totals = Counter()
    rule_counts = Counter()
    accepted_hashes = set()
    all_hashes = set()
    details = []
    translations = []
    compiler_counts = Counter()

    def audit(packet, label, expected=None, category='mutation'):
        actual = run(candidate, packet)
        oracle = Oracle().run(packet)
        require(actual['accepted'] == oracle['accepted'], ('oracle verdict', label, actual, oracle))
        if expected is not None:
            require(actual['accepted'] == expected, ('named expectation', label, actual))
        h = digest(packet)
        all_hashes.add(h)
        totals[category + '_cases'] += 1
        totals[category + ('_accepts' if actual['accepted'] else '_rejects')] += 1
        entry = {'name': label, 'category': category, 'packet_sha256': h,
                 'candidate': actual}
        if actual['accepted']:
            for key in ('final_k', 'remaining'):
                require(actual[key] == oracle[key], ('execution trace', label, key, actual, oracle))
            rule_counts.update(oracle['rules'])
            accepted_hashes.add(h)
            emitted = Compiler().run(packet)
            target = run(baseline, emitted['packet'])
            require(target['accepted'], ('translated proof rejected', label, target))
            require(emitted['packet'][-1] == packet[-1], ('translation changed closed goal', label))
            require(-target['final_k'] == emitted['target_allocations'],
                    ('translated allocation count', label, target, emitted['target_allocations']))
            compiler_counts['accepted_packets_translated'] += 1
            compiler_counts['direct_closure_introductions_expanded'] += emitted['expanded_direct_introductions']
            compiler_counts['motives_canonicalized'] += emitted['normalized_motives']
            compiler_counts['source_allocations'] += emitted['source_allocations']
            compiler_counts['target_allocations'] += emitted['target_allocations']
            entry['translation_sha256'] = digest(emitted['packet'])
            if category == 'new':
                translations.append({'name': label, 'packet': emitted['packet']})
        details.append(entry)
        return oracle

    traces = []
    for row in rows:
        trace = audit(row['packet'], row['name'], row['expected'], 'inherited')
        if trace['accepted'] and trace['transports']:
            traces.append((row, trace))
    for row in new:
        audit(row['packet'], row['name'], row['expected'], 'new')
    for row, trace in traces:
        for variant in ('next_unknown', 'huge_unknown', 'mixed'):
            changed = aliased(row['packet'], trace, variant)
            result = audit(changed, row['name'] + '/' + variant, True, 'alias')
            require(result['final_k'] == trace['final_k'] and result['remaining'] == trace['remaining'],
                    ('aliasing changed successful trace', row['name'], variant))

    rng = random.Random(20261107031)
    mutation_parents = rows + new
    for index in range(1600):
        parent = mutation_parents[index % len(mutation_parents)]
        audit(mutate(parent['packet'], rng), f'mutation_{index:04d}/{parent["name"]}')

    by_name = {row['name']: row for row in rows + new}
    changes = [
        ('captured_image', 'inst(t, d=1)', 'inst(t, d=d)', 'new/true_capture_attack', True),
        ('extra_scalar_binder', "b'\\0\\0\\2'", "b'\\0\\0\\4'", 'new/old_counter_is_not_a_hole_3', True),
        ('unvalidated_goal', 'if inst(a) in g:', 'if a in g:', 'new/future_eigenparameter_escape', True),
        ('compound_induction', 'h = [a, inst(a, 0)][len(a) % 2:]',
         'h = [a, inst(a, 0)]', 'original/compound_induction_hypothesis', True),
        ('missing_retained_base', 'h = [a, inst(a, 0)][len(a) % 2:]',
         'h = [a] if len(a) == 2 else [inst(a, 0)]', 'original/retained_base_separation', False),
        ('implicit_zero_image', 'def inst(a, t=None, d=0):', 'def inst(a, t=0, d=0):',
         'new/global_initializer_hole', True),
        ('unknown_name_kept_rigid', 'k <= a < d', 'a < d', 'new/invalid_unused_update_-999', True),
    ]
    controls = []
    for label, old, replacement, case, mutant_expected in changes:
        row = by_name[case]
        faulty = run(kernel(candidate_path, (old, replacement)), row['packet'])
        require(faulty['accepted'] == mutant_expected and mutant_expected != row['expected'],
                ('mutation control did not discriminate', label, faulty))
        controls.append({'name': label, 'fixture': case,
                         'correct_accepted': row['expected'], 'mutant_accepted': faulty['accepted']})

    cli_results = []
    with tempfile.TemporaryDirectory(prefix='ipra_scope_cli_') as tmp:
        chosen = new + [by_name[name] for name in (
            'new/true_capture_attack', 'new/future_eigenparameter_escape',
            'original/retained_base_separation', 'original/compound_induction_hypothesis',
            'new/global_initializer_hole', 'new/invalid_unused_update_True',
            'new/invalid_unused_update_False', 'new/arithmetic/add_two_three',
            'new/false_arithmetic/add_two_three')]
        for i, row in enumerate(chosen):
            path = Path(tmp) / f'{i:03d}.json'
            path.write_text(json.dumps(row['packet']) + '\n')
            for optimized in (False, True):
                cli_results.append({'name': row['name'], **cli(candidate_path, path, row['expected'], optimized)})
        for i, text in enumerate(('', '[', 'not-json')):
            path = Path(tmp) / f'malformed_{i}.json'
            path.write_text(text)
            for optimized in (False, True):
                cli_results.append({'name': f'malformed_{i}', **cli(candidate_path, path, False, optimized)})

    (HERE / 'new_scope_cases.json').write_text(json.dumps(new, indent=2) + '\n')
    (HERE / 'translated_examples.json').write_text(json.dumps(translations, indent=2) + '\n')
    summary = {'status': 'PASS', 'python': platform.python_version(),
               'checker': candidate_path.name, 'checker_sha256': file_hash(candidate_path),
               'support_provenance': provenance, 'counts': dict(totals),
               'distinct_packets': len(all_hashes), 'distinct_accepted_packets': len(accepted_hashes),
               'rule_executions_in_accepted_packets': dict(rule_counts),
               'proof_translation': dict(compiler_counts),
               'deliberate_controls': controls, 'cli_calls': len(cli_results),
               'intentionally_changed_inherited_expectation': changed_name,
               'evidence_limit': 'Finite certificate and implementation evidence; not a formalized universal soundness or bi-interpretation theorem.'}
    result = {'summary': summary, 'cases': details, 'cli': cli_results}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    args.output.with_name('summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
