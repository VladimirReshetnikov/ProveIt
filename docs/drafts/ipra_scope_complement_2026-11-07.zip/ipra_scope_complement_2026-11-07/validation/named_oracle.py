"""Independent named-binder oracle for the scalar one-hole checker.

This is untrusted validation support.  It is never imported by the candidate.
There is no packed sort/depth field, byte-string constructor table, structural
match statement, or call to the production substitution helper.  A template
has one optional hole: every integer outside the declared rigid-name range
and the explicitly protected binders denotes that hole. The extension to
undeclared negative names is the scope-complement convention audited here.

The explicit named-binder technique and raw-spelling convention are adapted
from the inspected scalar draft's validation/named_oracle.py.  The singleton
template convention, direct closure introduction, and independent rule
interpreter below implement the newly specified acceptance contract.
"""
from copy import deepcopy


class Syntax:
    def __init__(self, lower=0):
        self.lower = lower
        self.serial = 0

    def fresh(self):
        self.serial += 1
        return self.serial

    def term(self, value, bound=(), template=False):
        if type(value) is int:
            if value <= 0:
                if value < self.lower:
                    if template:
                        return ('hole',)
                    raise ValueError('undeclared numerical parameter')
                return ('constant', value)
            slot = (value + 1) // 2
            if slot <= len(bound):
                return ('variable', bound[slot - 1], 1 - value % 2)
            if template:
                return ('hole',)
            raise ValueError('unbound positive coordinate')
        if type(value) is not list:
            raise ValueError('term must be an integer or list')
        if len(value) == 1:
            return ('successor', self.term(value[0], bound, template))
        if len(value) == 3:
            previous = self.fresh()
            return ('iterator', self.term(value[0], bound, template),
                    self.term(value[1], bound, template), previous,
                    self.term(value[2], (previous,) + bound, template))
        raise ValueError('invalid term arity')

    def formula(self, value, bound=(), template=False):
        if type(value) is not list:
            raise ValueError('formula must be a list')
        if len(value) == 2:
            return ('equal', self.term(value[0], bound, template),
                    self.term(value[1], bound, template))
        if len(value) == 1:
            variable = self.fresh()
            return ('closure', variable,
                    self.formula(value[0], (variable,) + bound, template))
        if len(value) == 3:
            first, second = self.fresh(), self.fresh()
            return ('paired', first, second,
                    *(self.formula(v, (second, first) + bound, template) for v in value))
        raise ValueError('invalid formula arity')

    def term_data(self, tree, bound=()):
        tag = tree[0]
        if tag == 'constant':
            return tree[1]
        if tag == 'variable':
            return 2 * bound.index(tree[1]) + 1 + tree[2]
        if tag == 'successor':
            return [self.term_data(tree[1], bound)]
        if tag == 'iterator':
            _, count, initial, previous, body = tree
            return [self.term_data(count, bound), self.term_data(initial, bound),
                    self.term_data(body, (previous,) + bound)]
        raise ValueError('unsubstituted hole')

    def formula_data(self, tree, bound=()):
        tag = tree[0]
        if tag == 'equal':
            return [self.term_data(tree[1], bound), self.term_data(tree[2], bound)]
        if tag == 'closure':
            return [self.formula_data(tree[2], (tree[1],) + bound)]
        if tag == 'paired':
            return [self.formula_data(t, (tree[2], tree[1]) + bound) for t in tree[3:]]
        raise ValueError('invalid formula tree')


def children(tree):
    tag = tree[0]
    if tag in ('constant', 'variable', 'hole'):
        return ()
    if tag == 'successor':
        return (tree[1],)
    if tag == 'iterator':
        return (tree[1], tree[2], tree[4])
    if tag == 'equal':
        return tree[1:]
    if tag == 'paired':
        return tree[3:]
    return tree[2:]


def has_hole(tree):
    return tree[0] == 'hole' or any(has_hole(t) for t in children(tree))


def names_in(tree):
    if tree[0] == 'constant' and tree[1] < 0:
        return {tree[1]}
    return set().union(*(names_in(t) for t in children(tree)))


def replace_hole(tree, image):
    tag = tree[0]
    if tag == 'hole':
        return image
    if tag in ('constant', 'variable'):
        return tree
    if tag == 'successor':
        return (tag, replace_hole(tree[1], image))
    if tag == 'iterator':
        return (tag, replace_hole(tree[1], image), replace_hole(tree[2], image),
                tree[3], replace_hole(tree[4], image))
    if tag == 'equal':
        return (tag, *(replace_hole(t, image) for t in tree[1:]))
    if tag == 'paired':
        return (tag, tree[1], tree[2],
                *(replace_hole(t, image) for t in tree[3:]))
    return (tag, tree[1], replace_hole(tree[2], image))


def opening(value, image=None, *, formula=True, depth=0, lower=0):
    """Open one template, keeping depth nearest binders protected.

    A missing or invalid image is rejected exactly when the template uses its
    hole.  Images are parsed at depth zero, so a positive image coordinate can
    never be captured by a binder at its insertion site.
    """
    syntax = Syntax(lower)
    bound = tuple(syntax.fresh() for _ in range(depth))
    parse = syntax.formula if formula else syntax.term
    emit = syntax.formula_data if formula else syntax.term_data
    tree = parse(value, bound, template=True)
    replacement = syntax.term(image) if has_hole(tree) else None
    return emit(replace_hole(tree, replacement), bound)


class Oracle:
    def __init__(self, direct_closure=True):
        self.direct_closure = direct_closure
        self.lower = 0
        self.stack = []
        self.allocations = []
        self.rule_counts = {}
        self.transports = []

    def open(self, value, image=None, formula=True, depth=0):
        return opening(value, image, formula=formula, depth=depth, lower=self.lower)

    def rule(self, name):
        self.rule_counts[name] = self.rule_counts.get(name, 0) + 1

    def fresh(self, relevant):
        syntax = Syntax(self.lower)
        names = set().union(*(names_in(syntax.formula(a)) for a in relevant))
        self.lower -= 1
        if self.lower in names or any(self.lower >= n for n in names):
            raise AssertionError('oracle eigenparameter is not fresh')
        self.allocations.append({'eigenparameter': self.lower,
                                 'relevant_names': sorted(names)})
        return self.lower

    def check(self, goal, context):
        self.open(goal)
        if goal in context:
            self.rule('hypothesis')
            return True
        instruction_index = len(self.stack) - 1
        instruction = self.stack.pop()
        if type(instruction) is not list:
            return False
        if len(instruction) == 2:
            major, annotation = instruction
            if not self.check(major, context):
                return False
            if len(major) == 3:
                self.rule('paired_elimination')
                eigen = self.fresh([goal, *context, major])
                assumption = self.open([major[0]], eigen)
                return self.check(goal, [*context, assumption])
            if len(major) == 1:
                self.rule('closure_elimination')
                matrix, left, right = major[0], 0, annotation
            else:
                self.rule('equality_transport')
                matrix, (left, right) = annotation, major
                self.transports.append({'instruction_index': instruction_index,
                                        'lower_after_major': self.lower})
            if self.open(matrix, right) != goal:
                return False
            return self.check(self.open(matrix, left), context)
        if len(instruction) == 1:
            # The candidate's sort separation implements this explicit check:
            # a numerical equality child cannot parse as a formula.
            if len(goal) not in (1, 3):
                return False
            if len(goal) == 1 and not self.direct_closure:
                return False
            self.rule('closure_introduction' if len(goal) == 1 else 'paired_introduction')
            body = self.open(goal[0], instruction[0], depth=1)
            assumptions = [self.open(body, 0)]
            if len(body) == 2:
                assumptions.insert(0, body)
            eigen = self.fresh([goal, *context])
            conclusion = self.open(body, [eigen])
            instantiated = [self.open(a, eigen) for a in assumptions]
            return self.check(conclusion, [*context, *instantiated])
        if instruction == []:
            if len(goal) != 2 or type(goal[0]) is not list or len(goal[0]) != 3:
                return False
            counter, initial, update = goal[0]
            if type(counter) is int and counter == 0:
                self.rule('iteration_zero')
                expected = initial
            elif type(counter) is list and len(counter) == 1:
                self.rule('iteration_successor')
                previous = counter[0]
                expected = self.open(update, [previous, initial, update], False)
            else:
                return False
            return goal[1] == expected
        return False

    def run(self, packet, lower=0):
        self.lower = lower
        self.allocations = []
        self.rule_counts = {}
        self.transports = []
        self.stack = deepcopy(packet)
        try:
            accepted = bool(self.check(self.stack.pop(), []))
            error = None
        except Exception as exc:
            if isinstance(exc, AssertionError):
                raise
            accepted, error = False, type(exc).__name__
        return {'accepted': accepted,
                'remaining': len(self.stack) if type(self.stack) is list else None,
                'final_k': self.lower, 'error': error,
                'allocations': self.allocations, 'rules': self.rule_counts,
                'transports': self.transports}
