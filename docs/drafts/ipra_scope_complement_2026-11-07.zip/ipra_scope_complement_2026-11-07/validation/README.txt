INDEPENDENT CERTIFICATE AUDIT
============================

This directory is untrusted validation support. The production checker does
not import it. The finite results support implementation confidence; they do
not replace the mathematical soundness, completeness, or bi-interpretation
proofs in the article.

Run from any working directory:

    python3 /path/to/package/validation/verify.py

Or supply a different complete checker explicitly:

    python3 validation/verify.py --checker /path/to/checker.py

The default production path is ../checker.py. The script needs Python 3.10+
and the standard library. The recorded run used CPython 3.12.14. It writes
results.json, summary.json, new_scope_cases.json, translated_examples.json,
and the named JSON proof packets in ../examples/.

WHAT IS INDEPENDENT

named_oracle.py represents local binders with distinct names. Its parser has
separate numerical and formula functions; it does not use the production
byte table, packed depth, structural-pattern dispatcher, or inst function.
Its only semantic change from the inherited oracle is that a negative name
below the current declaration floor can denote a hole in an explicitly open
template. The parser still rejects that name in a closed term or image.
The oracle independently checks every eigenparameter against the names in
the retained data and records major-premise allocation floors.

compile_to_baseline.py is an untrusted proof producer. It translates every
accepted audited packet to the frozen original five-rule scalar checker in
baseline_scalar.py. It canonicalizes holes at the floor AFTER each major
proof, expands direct closure introductions using paired introduction and
elimination, and renames fresh parameters in target allocation order. The
frozen checker then independently checks the resulting certificate. The
closed goal must be exactly unchanged. Neither oracle nor compiler is an
authority for the production checker's acceptance decision.

The audit loads exact production function bodies using Python's AST parser
solely to avoid executing its standalone CLI during in-process comparisons.
No function body is changed. Separate subprocess runs exercise the actual
complete source file under ordinary Python and Python -O.

RECORDED FINITE COVERAGE

* 207 inherited named packets: 121 accepted and 86 rejected.
* 19 new named packets: 9 accepted and 10 rejected.
* 240 invocation-relative signed-hole variants, all accepted with unchanged
  parameter floors and remaining instruction counts.
* 1,600 deterministic generic JSON-tree mutations: 84 accepted, 1,516 rejected.
* In total, 2,066 packet executions, representing 1,690 distinct raw packets.
  There are 283 distinct accepted packets, repeated in 454 accepted executions.
* All 454 accepted executions are translated and accepted by the frozen
  scalar checker, proving exactly the original closed goals. The translation
  canonicalizes 1,910 motives and expands 11 direct closure introductions.
* 62 real CLI runs cover every new packet, important old controls, malformed
  JSON, normal Python, and Python -O.
* Seven deliberately defective checkers are distinguished by concrete controls:
  image capture, a nonexistent second scalar binder, missing goal validation,
  compound induction, deletion of the retained atomic base, an implicit zero
  image, and treating unknown negative names as rigid parameters.

Counts of repeated executions are not counts of distinct mathematical facts.
summary.json records both execution counts and distinct packet counts.

THE IMPORTANT FLOOR BOUNDARY

The new examples major_allocation_boundary_1.json and
major_allocation_boundary_2.json reject. Their major proof allocates names -1
and -2 before the equality motive is opened. Those integers are therefore
rigid parameters at the actual opening time; they cannot be treated as holes
to prove the older closed goal. The corresponding alias -3 remains unknown
and the packet major_allocation_boundary_3.json accepts. This specifically
tests the global-state subtlety, rather than only pure substitutions at a
fixed floor.

ONE INTENTIONALLY CHANGED OLD EXPECTATION

The inherited packet new/used_future_motive_parameter was rejected by the
previous syntax because its external equality motive used -999. It now
accepts: -999 explicitly denotes the sole template hole at that invocation.
Its proved goal remains 0=0, and the compiler emits a strict old proof of the
same goal. Future names in actual closed goals, updates, and used witnesses
remain rejected. Every other inherited named expectation is unchanged.

PROVENANCE AND LICENSING

The inherited fixtures, baseline, oracle, compiler and mutation helper were
read from docs/drafts/ipra_one_hole_2026-11-07.zip in ProveIt at commit
6ee66e8e01b8cf39d81f53fce44cbedfede2dfdb. That archive's Git blob identity is
185152c8d2379f085a1cd76cfaf32ec25186fcb7. provenance.json records both source
and delivered SHA-256 hashes and which files were adapted. Its older scalar
baseline and fixtures retain their own provenance in the source comments.
LICENSE_SOURCE.txt preserves the inherited MIT No Attribution license.
The newly written runner, scope-boundary examples, and audit notes use the
same license. No claim of novelty is made for the inherited arithmetic,
named-binder validation technique, or proof compiler architecture.
