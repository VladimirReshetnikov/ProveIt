"""Create or verify the reproducible payload manifest and ZIP archive."""
from pathlib import Path
import argparse
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / 'SHA256SUMS.txt'
EXCLUDED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc', '.synctex.gz'}


def payload():
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and p != MANIFEST
                  and '__pycache__' not in p.parts and p.suffix not in EXCLUDED_SUFFIXES)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify', action='store_true')
    args = parser.parse_args()
    if args.verify:
        recorded = {}
        for line in MANIFEST.read_text().splitlines():
            digest, name = line.split('  ', 1)
            path = ROOT / name
            if not path.is_file() or sha(path) != digest:
                raise SystemExit('Missing or changed payload: ' + name)
            recorded[name] = digest
        actual = {str(p.relative_to(ROOT)) for p in payload()}
        if actual != set(recorded):
            raise SystemExit('Unrecorded or missing payload files: ' + str(actual ^ set(recorded)))
        print(f'Verified {len(recorded)} payload hashes.')
        return
    files = payload()
    MANIFEST.write_text(''.join(f'{sha(p)}  {p.relative_to(ROOT)}\n' for p in files))
    destination = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in [*files, MANIFEST]:
            archive.write(path, str(Path(ROOT.name) / path.relative_to(ROOT)))
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise SystemExit('Archive CRC validation failed.')
    print(f'{destination.name}: {destination.stat().st_size} bytes; {len(files) + 1} entries')


if __name__ == '__main__':
    main()
