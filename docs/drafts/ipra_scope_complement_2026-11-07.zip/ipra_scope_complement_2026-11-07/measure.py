"""Remeasure the pinned current corpus and every delivered acceptance boundary."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parent
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    metric_path = ROOT / 'comparison/source_measure.py'
    assert hashlib.sha256(metric_path.read_bytes()).hexdigest() == manifest['metric_sha256']
    spec = importlib.util.spec_from_file_location('frozen_metric', metric_path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    measured = {}
    for entry in manifest['expanded']:
        row = metric.metrics(ROOT / entry['local_file'])
        assert row['sha256'] == entry['sha256'], entry['local_file']
        measured[entry['sha256']] = row
    current = [{**e, **measured[e['sha256']]} for e in manifest['programs']]
    envelope = {k: min(e[k] for e in current) for k in KEYS}
    expanded = {k: min(e[k] for e in measured.values()) for k in KEYS}
    candidates = []
    for path in ('checker_isolated.py', 'comparison/checker_integration_control.py', 'checker.py'):
        candidates.append({'file': path, **metric.metrics(ROOT / path)})
    final = candidates[-1]
    assert all(final[k] < envelope[k] for k in KEYS)
    assert envelope == expanded
    result = {
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'commit': manifest['commit'], 'archives': len(manifest['archives']),
        'current_program_count': len(current), 'expanded_distinct_count': len(measured),
        'expanded_path_count': sum(len(e['aliases']) for e in manifest['expanded']),
        'coordinate_minimum': envelope, 'expanded_coordinate_minimum': expanded,
        'candidates': candidates, 'current_programs': current,
        'strict_improvement': {k: final[k] < envelope[k] for k in KEYS},
        'novel_change_delta_from_integration_control': {
            k: candidates[1][k] - final[k] for k in KEYS},
        'normalization_note': 'Unmodified inherited full-source metric; core heuristic is not used.'
    }
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (ROOT / 'results/current_comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ['label', *KEYS, 'sha256'], extrasaction='ignore')
        writer.writeheader()
        writer.writerows(current)
    macros = []
    for name, row in [('Frontier', envelope), ('Primary', final), ('Isolated', candidates[0]),
                      ('Control', candidates[1])]:
        for key, suffix in zip(KEYS, ['Tokens', 'Nodes', 'Bytes']):
            macros.append('\\newcommand{\\' + name + suffix + '}{' + str(row[key]) + '}')
    (ROOT / 'results/numbers.tex').write_text('\n'.join(macros) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'current_programs'}, indent=2))


if __name__ == '__main__':
    main()
