SCOPE COMPLEMENTS AS SUBSTITUTION HOLES
A smaller complete presentation of intuitionistic primitive recursive arithmetic
Prepared for Vladimir Reshetnikov, 7 November 2026
========================================================================

READ FIRST

report.pdf is the complete mathematical article. report.tex and sections/
contain its editable LaTeX source. checker.py is the entire primary trusted
acceptance program. This is a strict measured improvement over the current
draft corpus, with a small new substitution-language lemma. It is not a
claim of an absolutely simplest axiomatization or a new arithmetic basis.

RESULT

                                      Tokens    AST nodes    Normalized bytes
Current coordinatewise minima             389          413                1159
Strongest one-hole baseline               389          413                1188
New opening convention alone              385          410                1180
Inherited integration control             379          406                1125
Delivered primary checker                 375          403                1117

All counts include the complete project-specific acceptance program: JSON
input, syntax and scope validation, substitution, all proof rules, verdicts,
exception handling, and exit status. Python and JSON are the shared ambient
runtime. The inherited normalization is unchanged and uses CPython 3.12.14.
The auxiliary metric's core heuristic is not used for the comparison.

The current repository snapshot is:
  6ee66e8e01b8cf39d81f53fce44cbedfede2dfdb
  https://github.com/VladimirReshetnikov/ProveIt/tree/6ee66e8e01b8cf39d81f53fce44cbedfede2dfdb/docs/drafts

All six archives were verified against their Git blob identities. Their
thirteen current root checkers are measured separately. A broader mechanical
screen includes 126 distinct sources at 525 paths, including historical
comparators and some support programs. It gives the same coordinate minima.
All frozen sources, hashes, original archive/member names, and the exact
selection criterion are included in comparison/manifest.json.

THE NEW IDEA

Every trusted substitution already supplies at most one numerical image.
At an integer term leaf, k is the declaration floor and d is the local
protected depth. The interval k <= a < d comprises exactly the values that
must remain unchanged: declared parameters, zero, and protected variables.
Every integer outside that interval may denote the single open-template hole.

Thus undeclared negative names need not have a separate error case in an
open template. Closed validation and used images still have no replacement
available, so an out-of-scope integer there still rejects. Used images are
checked at numerical root, preventing capture under destination binders.

The report proves that one conventional template gives exactly the same
endpoint instances. Equality motives are canonicalized at the scope AFTER
their major proof, because that proof can allocate names. Both endpoint
openings run at the same post-major floor. The primary does not execute a
canonicalizer: it remains one standalone file with no project imports.

The new convention alone saves four tokens, three AST nodes, and eight
normalized bytes. The remaining savings integrate already supplied driver
and calling-convention simplifications. The isolated ablation and integration
control make this attribution reproducible. The primary uses strict integer
syntax; it does not rely on Boolean aliases.

MATHEMATICAL CONTENT

The full native basis consists of zero, successor, scalar iteration, equality,
the closure binder Q, the paired binder D, five primitive inference patterns,
and two computation schemas. The paper explicitly states every rule and scope
condition. It derives full intuitionistic first-order logic and quantifier-free
induction, constructs predecessor and pairing internally, and compiles general
primitive recursion.

The ordinary realization includes a genuine falsity bridge. Both ordinary
interpretations use the entire numerical domain, and both composite
isomorphisms have graph x=y. Equiconsistency and bi-interpretability are with
full first-order iPRA, not merely a quantifier-free or classical fragment.

The foundational mathematics and substantial appendix exposition are inherited
from the supplied drafts and explicitly credited. The new result concerns the
complete proof presentation and its substitution convention. The metatheorems
have written proofs and independent reviews; they are not formalized in Lean
or Rocq. Finite testing is separate implementation evidence.

QUICK START

Requires Python 3.10 or later. From this directory:

  python3 checker.py examples/negative_motive_1.json
  python3 checker.py examples/major_allocation_boundary_3.json

These print ACCEPT and exit 0. Negative controls:

  python3 checker.py examples/future_name_in_closed_goal_1.json
  python3 checker.py examples/major_allocation_boundary_1.json

These print REJECT and exit 1. A rejected certificate does not prove its
sentence false. FORMAT.txt gives the exact input grammar and all instructions.

REPRODUCE OFFLINE

  python3 package.py --verify
  python3 reproduce.py
  python3 build.py

The first checks the delivered hashes. The second remeasures every frozen
source and runs the independent opening and complete-certificate audits.
The third rebuilds the PDF with pdfLaTeX and the packages listed in report.tex.
Only the Python standard library is needed for checking and reproduction.
The evidence and article can be reproduced without a network connection.

Reproduction intentionally rewrites result files, and a PDF rebuild can change
PDF metadata. Verify hashes before regeneration. After an intentional change,
python3 package.py refreshes the manifest and recreates the ZIP in the parent
directory. No checker imports any validation, metric, or proof-producing code.

EXECUTED EVIDENCE

  825,337 opening/canonicalization comparisons with an independent grammar.
   57,564 separate no-image validation equivalence checks.
    2,066 complete-packet executions, representing 1,690 distinct packets.
      454 accepted executions, representing 283 distinct accepted packets.
      454 successful translations to the frozen original scalar checker,
          preserving exactly the closed end-goal.
       62 actual CLI runs, including Python -O and malformed JSON.
        7 deliberately defective program variants detected.

All candidate packet verdicts agreed with the independent named-binder oracle.
The detailed receipts distinguish overlapping named cases from distinct inputs.
The inherited future-motive expectation changes intentionally only when the
name is a genuine unknown alias at the post-major floor. The important
floor-crossing cases are explicit and independently checked.

PACKAGE MAP

report.pdf, report.tex, sections/   Complete article and all LaTeX sources
checker.py                        Primary 375-token acceptance program
checker_isolated.py               Only the new substitution-language change
FORMAT.txt, examples/             Exact certificate contract and concrete packets
comparison/                       Integration control, frozen sources and metric
measure.py, results/               Measurements and reproduction/build receipts
validation/                       Independent oracle, compiler, audits and reviews
reproduce.py                      One-command finite evidence reproduction
build.py, package.py               Offline article build and archive integrity
ATTRIBUTION.txt, LICENSE_SOURCE.txt Contribution boundaries and inherited license
SHA256SUMS.txt                     Delivered payload hashes

No GitHub repository files were changed. No global minimality or historical
priority claim is made. The remaining challenge is a substantially smaller
mathematical basis, rather than the modest implementation reduction proved here.
