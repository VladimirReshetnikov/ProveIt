"""One offline command for all recorded source and finite-evidence checks."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(*args):
    result = subprocess.run([sys.executable, '-B', *args], cwd=ROOT,
                            capture_output=True, text=True)
    print(result.stdout)
    if result.returncode:
        print(result.stderr)
        raise SystemExit(result.returncode)


def main():
    run('measure.py')
    run('validation/scope_audit.py')
    run('validation/verify.py')
    metrics = json.loads((ROOT / 'results/metrics.json').read_text())
    scope = json.loads((ROOT / 'validation/scope_audit.json').read_text())
    certificates = json.loads((ROOT / 'validation/summary.json').read_text())
    receipt = {'status': 'PASS', 'primary': metrics['candidates'][-1],
               'scope_audit_result': scope, 'certificate_summary': certificates}
    (ROOT / 'results/reproduction.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('All source measurements and finite validation checks passed.')


if __name__ == '__main__':
    main()
