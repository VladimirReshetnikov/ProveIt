"""Build the included article offline with pdfLaTeX."""
from pathlib import Path
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    engine = shutil.which('pdflatex')
    if engine is None:
        raise SystemExit('Install pdfLaTeX and the packages listed in report.tex.')
    logs = ROOT / 'results'
    logs.mkdir(exist_ok=True)
    for run in range(1, 4):
        result = subprocess.run(
            [engine, '-interaction=nonstopmode', '-halt-on-error',
             '-file-line-error', '-no-shell-escape', 'report.tex'],
            cwd=ROOT, capture_output=True, text=True)
        (logs / f'latex_pass_{run}.txt').write_text(result.stdout + result.stderr)
        if result.returncode:
            raise SystemExit(result.stdout[-6000:] + result.stderr[-1000:])
    text = (ROOT / 'report.log').read_text()
    failures = [line for line in text.splitlines()
                if ('Overfull ' in line or 'undefined references' in line
                    or 'undefined citations' in line or 'multiply defined' in line)]
    receipt = {'engine': engine, 'passes': 3, 'pdf_bytes': (ROOT / 'report.pdf').stat().st_size,
               'layout_or_reference_warnings': failures}
    (logs / 'build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))
    if failures:
        raise SystemExit('Resolve the recorded layout/reference warnings before delivery.')


if __name__ == '__main__':
    main()
