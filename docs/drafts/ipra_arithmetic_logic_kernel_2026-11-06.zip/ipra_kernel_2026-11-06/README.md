# A smaller complete proof checker for intuitionistic PRA

Research package prepared for Vladimir Reshetnikov, 6 November 2026.

**Recommended presentation:** retain full first-order intuitionistic formulas,
initialized primitive recursion, and rooted equation induction. Replace
separation by the fixed bridge `(0 = S0) <-> false`, and derive both equality
reflexivity and unrestricted ex falso. The delivered checker is smaller than
the matched implementations of the common core of the six current drafts.
This is a measured relative improvement, not an assertion of absolute
minimality over all possible programming languages or proof encodings.

Read `report.pdf` for the complete theory, comparison, and mathematical proofs;
`report.tex` is its source. The report proves equivalence with the specified
full first-order iPRA, including both interpretations and their round trips.
These are written proofs, not a Lean or Rocq formalization. Finite tests below
do not prove the Python implementation sound or replace the general proofs.

## Reproduce the checks

Python **3.10 or newer**, with its standard library, is sufficient for the
checker, certificate generators, audits, and comparison. No third-party Python
packages, network access, or external proof engine are required.

From this directory:

```sh
python3 run_checks.py
```

This command reruns the primary certificate suite and independent audit, the
optional encoded-disjunction experiment and audit, and the complete-source
comparison. It verifies that `comparison/recommended.py` is byte-identical to
`kernel.py`, checks both baseline implementations on their primitive
reflexivity/ex-falso rules and original rooted induction, checks their scope
rejections, and exercises the JSON adapter. It writes `run_results.json`.

To skip the optional experiment's two test suites:

```sh
python3 run_checks.py --primary-only
```

To check the included single proof certificate through the file interface:

```sh
python3 check_json.py example_reflexivity.json
```

Successful output is `{"accepted": true}` with exit code 0. Rejection produces
`{"accepted": false}` with exit code 1. Without a filename, the adapter reads
one JSON certificate from standard input. The larger `certificates.json` file
is an array of examples; `test_kernel.py` constructs and replays that array.

The direct Python API is:

```python
from kernel import check

accepted = check(proof, conclusion, context=(), scope=0)
```

Use `check` for external certificates. `infer` is an internal recursive helper
whose callers supply already validated input contexts.

## Rebuild the paper separately

A LaTeX installation is needed only to rebuild the paper:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

The proof and comparison checks do not require LaTeX or the PDF.

## Mathematical core

The language contains numerical variables, `0`, successor, and a native
recursion binder

```text
R(n, a; v, w. h)
```

whose local variables `v,w` denote the previous value and current counter.
All numerical parameters of `h` remain explicit through ordinary variable
binding. Formulas use equality, genuine falsity, conjunction, disjunction,
implication, and both first-order quantifiers.

The numerical principles are precisely:

1. The fixed bridge `(0 = S0 -> false) and (false -> 0 = S0)`.
2. The two computation clauses
   `R(0,a;v,w.h) = a` and
   `R(Sn,a;v,w.h) = h[R(n,a;v,w.h)/v, n/w]`.
3. Rooted equation induction: from a derivation of `E(Sx)` under retained
   assumptions `Gamma` and the additional assumption `x=0 or E(x)`, infer
   `t=0 or E(t)` under `Gamma`. Here `E` is an equation and `x` is fresh for
   `Gamma` and `t`. The additional assumption is discharged.

The primitive logical rules are assumption, unrestricted equality
replacement, and the usual introduction/elimination rules for conjunction,
disjunction, implication, universal quantification, and existential
quantification, with the stated eigenvariable conditions. Reflexivity and
ex falso have **no primitive proof tags**. Context operations are represented
by hypothesis indices and are admissible as described in the report.

Reflexivity is derived in two steps: the base clause supplies `a=t` for
`a=R(0,t;v,w.v)`; equality replacement in the formula `z=t`, using the same
proof for both premises, supplies `t=t`. Under `0=S0`, a constant recursion
update collapses any two terms to equal values. The bridge then makes ex
falso derivable by structural induction on the requested formula. Genuine
falsity is retained throughout.

The report gives the full binding conventions, every rule, the recovery of
quantifier-free induction, and the interpretations between native recursion
terms and the usual finite primitive-recursive descriptions. There is no
primitive-recursive universal evaluator hidden in the binder.

## Concrete syntax and certificate scope

Python syntax is nested tuples; JSON represents them as arrays. Variables are
de Bruijn indices, and a context lists its newest assumption first.

| Object | Tuple form |
| --- | --- |
| Numerical variable | `("v", i)` |
| Zero and successor | `("0",)` and `("s", t)` |
| Recursion | `("r", counter, initializer, body)` |
| Equality and genuine falsity | `("=", s, t)` and `("!",)` |
| Binary formula | `("&", A, B)`, `("|", A, B)`, `(">", A, B)` |
| Quantified formula | `("A", body)` and `("E", body)` |

Each quantifier binds slot 0. A recursion body binds slot 0 for the previous
value and slot 1 for the counter; outer numerical parameters shift by two.
The `scope` argument counts available outer numerical variables. Proof
certificates use the finite rule constructors documented directly by the
pattern-matching clauses of `kernel.py`; the report explains their mathematical
meaning. The kernel checks syntax, scopes, substitution, rule side conditions,
and the claimed conclusion. `proofs.py` only constructs certificates; every
constructed certificate still has to pass the kernel.

## Measured comparison

The pinned repository snapshot is
`VladimirReshetnikov/ProveIt@86b708a209fd20431908347c5aa051d73c8d4682`.
`source_manifest.json` identifies the six inspected archives, their sizes,
Git blob hashes, SHA-256 hashes, and immutable source URLs.

The table measures **complete matched checker sources**, including their
syntax and scope checks, substitution, logical and arithmetic rules, and
error handling. The full ordinary-formula encoder is charged to the optional
disjunction-free experiment. These are matched implementations of the
mathematical presentations, not counts of the old drafts' diagnostic scripts.

| Presentation | Kernel bytes | Shared JSON adapter | Total bytes |
| --- | ---: | ---: | ---: |
| **Recommended: full disjunction, derived reflexivity and ex falso** | **6,334** | **788** | **7,122** |
| Common draft core, primitive ex-falso rule | 6,570 | 788 | 7,358 |
| Common draft core, ex-falso axiom schema | 6,515 | 788 | 7,303 |
| Optional disjunction-free experiment, with full input encoder | 6,703 | 788 | 7,491 |
| Disjunction-free comparison with primitive reflexivity/ex falso | 6,939 | 788 | 7,727 |

Thus the recommendation saves 236 bytes against the ordinary rule baseline
and 181 bytes against the shorter axiom-schema baseline. The optional
disjunction encoding loses 369 bytes against the recommendation once its
full input encoder is included. It is retained as a reproducible experiment.

`compare.py` regenerates the variants and records byte counts, lexical tokens,
AST nodes, source-line counts, dispatch-case counts, and hashes in
`comparison_results.json`. `run_checks.py` adds the identical 788-byte adapter
to every row in `run_results.json`. Python itself is the shared execution
runtime. Proof construction, tests, audits, comparison generation, certificate
data, and the mathematical report are outside the trusted checker and are
not charged to any row. No proof-generating helper is imported by a kernel.

## What the executable evidence covers

The primary theorem suite checks **23 accepted certificates**, **37 rejected
attempts**, and **23 JSON serialization replays**. Its certificates include
derived reflexivity, term collapse, structural ex falso using every logical
constructor, successor laws, coverage, contextual equation induction,
parameterized recursion identities, zero-test decidability, and quantified
logical examples. The negative cases exercise binding, eigenvariables, schema
restrictions, removed rule tags, and malformed inputs.

The independent primary audit checks **26 accepted** and **33 rejected** rule
examples. It also checks the semantic substitution identities on 300 generated
terms and 300 generated formulas, giving 600 checks each of shifting,
slot-dropping substitution, and slot-preserving substitution. Those finite
semantic tests audit the substitution implementation; they do not establish
the arithmetic equivalence theorem or intuitionistic completeness.

The optional experiment has its own certificate and audit records. The two
common-core baseline smoke suites additionally check **16 accepted** and
**10 rejected** cases in total. These collections overlap in their concerns;
they are kept separate rather than presented as independent proofs of one
metatheorem.

## File map

| Files | Role |
| --- | --- |
| `report.tex`, `report.pdf` | Complete theory, mathematical proofs, and comparison |
| `kernel.py`, `check_json.py` | Recommended checker and shared JSON adapter |
| `proofs.py`, `test_kernel.py` | Untrusted derived-rule builders and theorem-certificate tests |
| `certificates.json`, `example_reflexivity.json`, `test_results.json` | Concrete proof data and primary results |
| `audit_kernel.py`, `audit_results.json` | Independent rule, eigenvariable, and substitution audit |
| `compare.py`, `comparison/`, `comparison_results.json` | Reproducible matched checker implementations and metrics |
| `encoded_kernel.py`, `encoded_proofs.py`, `test_encoded_kernel.py` | Optional disjunction-free experiment |
| `encoded_certificates.json`, `encoded_test_results.json`, `encoded_audit_kernel.py`, `encoded_audit_results.json` | Optional experiment evidence |
| `source_manifest.json` | Pinned repository provenance |
| `run_checks.py`, `run_results.json` | One-command reproduction and summary |
