"""Check derived-rule certificates and reject specific unsound certificates.

Run with Python 3.10 or newer.  Results and concrete certificates are written
next to this file.  These tests do not formalize the general metatheorems or
prove the implementation sound; the mathematical proof is in the paper.
"""

import hashlib
import json
from pathlib import Path

import encoded_kernel as K
import encoded_proofs as P


HERE = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def proof_statistics(proof):
    children = {
        "h": (), "bridge": (), "rec": (),
        "rep": (2, 3), "&i": (1, 2), "&e": (2,),
        ">i": (2,), ">e": (1, 2), "Ai": (1,), "Ae": (2,),
        "Ei": (3,), "Ee": (2, 3), "zc": (2, 3), "ind": (3,),
    }
    counts = {}
    stack = [proof]
    while stack:
        p = stack.pop()
        counts[p[0]] = counts.get(p[0], 0) + 1
        stack.extend(p[i] for i in children[p[0]])
    return {"rule_nodes": sum(counts.values()), "rules": dict(sorted(counts.items()))}


def count_recursion(n):
    """Prove r(n,0;v,w.Sv)=n by the derived equation-induction compiler."""
    x = P.V(0)
    equation = P.Eq(P.R(x, P.Z, P.S(P.V(0))), x)
    base = P.rec(P.R(P.Z, P.Z, P.S(P.V(0))))
    unfolded = P.rec(P.R(P.S(x), P.Z, P.S(P.V(0))))
    step_body = P.trans(unfolded, P.congruence(P.S(P.V(0)), P.hyp(equation)))
    step = P.generalize(P.introduce(equation, step_body))
    return P.equation_induction(equation, n, base, step)


def successor_initial(n, a):
    """Prove r(n,Sa;v,w.Sv)=S(r(n,a;v,w.Sv)), including a parameter."""
    update = P.S(P.V(0))
    x, raised_a = P.V(0), K.shift(a)
    equation = P.Eq(P.R(x, P.S(raised_a), update), P.S(P.R(x, raised_a, update)))
    base_left = P.rec(P.R(P.Z, P.S(a), update))
    base_right = P.congruence(P.S(P.V(0)), P.sym(P.rec(P.R(P.Z, a, update))))
    base = P.trans(base_left, base_right)
    left_step = P.rec(P.R(P.S(x), P.S(raised_a), update))
    ih_step = P.congruence(P.S(P.V(0)), P.hyp(equation))
    right_step = P.congruence(P.S(P.V(0)), P.rec(P.R(P.S(x), raised_a, update)))
    step_body = P.trans(left_step, P.trans(ih_step, P.sym(right_step)))
    step = P.generalize(P.introduce(equation, step_body))
    return P.equation_induction(equation, n, base, step)


def run():
    positive = []
    negative = []
    certificates = []

    def accept(name, claim, context=(), scope=0):
        success = K.check(claim.proof, claim.formula, context, scope)
        if not success:
            raise AssertionError("positive certificate rejected: " + name)
        payload = {"name": name, "proof": claim.proof, "conclusion": claim.formula,
                   "context": context, "scope": scope}
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        positive.append({"name": name, "accepted": True,
                         "certificate_sha256": digest(encoded), **proof_statistics(claim.proof)})
        certificates.append(payload)

    def reject(name, proof, conclusion, context=(), scope=0):
        if K.check(proof, conclusion, context, scope):
            raise AssertionError("unsound or malformed certificate accepted: " + name)
        negative.append({"name": name, "rejected": True})

    # Real derivations with recursors and all logical constructors.
    accept("derived_reflexivity_closed", P.refl(P.ONE))
    complex_term = P.R(P.S(P.V(0)), P.V(1), P.R(P.V(1), P.V(0), P.V(3)))
    accept("derived_reflexivity_nested_recursion", P.refl(complex_term), scope=2)
    accept("collapse_arbitrary_terms", P.collapse(P.hyp(P.DELTA), complex_term, P.S(P.V(1))),
           (P.DELTA,), 2)

    quantified = P.All(P.Ex(P.And(P.Eq(P.V(0), P.V(1)),
                                 P.Imp(P.F, P.Eq(P.V(2), P.V(1))))))
    accept("structural_explosion_all_source_constructors", P.explode(P.hyp(P.F), quantified),
           (P.F,), 1)
    accept("structural_explosion_genuine_falsity", P.explode(P.hyp(P.F), P.F), (P.F,))

    ss = P.Eq(P.S(P.V(0)), P.S(P.V(1)))
    injectivity = P.introduce(ss, P.successor_injective(P.V(0), P.V(1), P.hyp(ss)))
    accept("successor_injectivity_universal", P.generalize(P.generalize(injectivity)))
    accept("successor_nonzero_universal", P.generalize(P.successor_nonzero(P.V(0))))
    accept("coverage_equation_universal", P.generalize(P.coverage(P.V(0))))
    accept("coverage_existential_universal", P.generalize(P.predecessor_coverage(P.V(0))))

    accept("identity_update_uniqueness_universal",
           P.generalize(P.generalize(P.identity_recursion(P.V(0), P.V(1)))))
    accept("counter_update_identity_universal", P.generalize(count_recursion(P.V(0))))
    accept("successor_initial_parameter_induction",
           P.generalize(P.generalize(successor_initial(P.V(0), P.V(1)))))
    arbitrary_context = (P.All(P.Ex(P.Imp(P.Eq(P.V(0), P.V(2)), P.F))),
                         P.Imp(P.Ex(P.Eq(P.V(0), P.V(1))), P.F))
    accept("equation_induction_with_quantified_retained_context",
           P.identity_recursion(P.V(0), P.V(1)), arbitrary_context, 2)

    # The derived ordinary equation-induction rule also works from hypotheses.
    equation = P.Eq(P.R(P.V(0), P.V(2), P.S(P.V(0))), P.V(1))
    base_formula = K.substitute(equation, (P.Z,))
    step_formula = P.All(P.Imp(equation, K.substitute(equation, (P.S(P.V(0)),), drop=False)))
    induction_instance = P.equation_induction(equation, P.V(0), P.hyp(base_formula, 1),
                                             P.hyp(step_formula))
    accept("generic_equation_induction_from_base_and_step", induction_instance,
           (step_formula, base_formula), 2)

    a = P.All(P.Ex(P.Eq(P.V(0), P.V(2))))
    b = P.Imp(P.Eq(P.V(0), P.Z), P.Ex(P.Eq(P.V(0), P.S(P.V(1)))))
    accept("encoded_disjunction_left", P.or_left(P.hyp(a), b), (a,), 1)
    accept("encoded_disjunction_right", P.or_right(a, P.hyp(b)), (b,), 1)
    accept("encoded_disjunction_elimination_and_commutativity", P.disjunction_commutes(a, b), scope=1)
    accept("encoded_disjunction_reflexive_cases",
           P.disjunction_commutes(P.F, P.All(P.Ex(P.Eq(P.V(0), P.V(1))))))

    # The public checker also accepts ordinary full-language goals and contexts.
    ordinary_commutativity = P.Imp(("|", a, b), ("|", b, a))
    commutativity_proof = P.disjunction_commutes(a, b)
    accept("ordinary_disjunction_goal_frontend",
           P.Claim(ordinary_commutativity, commutativity_proof.proof), scope=1)
    reversed_disjunction = P.apply(commutativity_proof, P.hyp(P.Or(a, b)))
    accept("ordinary_disjunction_context_frontend",
           P.Claim(("|", b, a), reversed_disjunction.proof), (("|", a, b),), 1)
    accept("ordinary_disjunction_under_quantifier_frontend",
           P.Claim(P.All(ordinary_commutativity), P.generalize(commutativity_proof).proof))
    ordinary_nested = P.All(P.Imp(("|", P.Eq(P.V(0), P.Z), P.F),
                                  P.Ex(("|", P.Eq(P.V(0), P.V(1)), P.F))))
    encoded_nested = K.encode(ordinary_nested, 0)
    accept("ordinary_nested_disjunction_goal_frontend",
           P.Claim(ordinary_nested, P.explode(P.hyp(P.F), encoded_nested).proof), (P.F,))

    # Explicitly test capture avoidance through a quantifier and nested recursors.
    context = (P.DELTA, P.All(P.Eq(P.V(0), P.Z)))
    replacement = ("rep", P.All(P.Eq(P.V(0), P.V(1))), ("h", 0), ("h", 1))
    accept("equality_substitution_preserves_quantifier_binding",
           P.Claim(P.All(P.Eq(P.V(0), P.ONE)), replacement), context)
    outer_body = P.R(P.V(1), P.V(0), P.V(3))
    nested = P.R(P.S(P.V(0)), P.V(1), outer_body)
    expected = P.R(P.V(0), P.R(P.V(0), P.V(1), outer_body), P.V(2))
    accept("recursion_substitution_preserves_inner_binding",
           P.Claim(P.Eq(nested, expected), ("rec", nested)), scope=2)
    captured = P.R(P.ONE, P.V(0), P.V(2))
    accept("recursion_update_captures_outer_parameter",
           P.Claim(P.Eq(captured, P.V(0)), ("rec", captured)), scope=1)

    # Forbidden primitive rules: these have genuinely derived replacements.
    reject("no_primitive_reflexivity", ("=", P.Z), P.Eq(P.Z, P.Z))
    reject("no_primitive_ex_falso", ("efq", ("h", 0), P.DELTA), P.DELTA, (P.F,))
    reject("no_primitive_disjunction", ("or_left", ("h", 0), P.DELTA),
           ("|", P.DELTA, P.DELTA), (P.DELTA,))
    ordinary_disjunction = ("|", P.DELTA, P.F)
    reject("auxiliary_certificate_formulas_must_be_native",
           (">i", ordinary_disjunction, ("h", 0)),
           P.Imp(ordinary_disjunction, ordinary_disjunction))

    # Invalid side conditions and capture attempts.
    rejected_matrix = P.Imp(P.Eq(P.V(0), P.Z), P.F)
    reject("induction_requires_equation_matrix", ("ind", rejected_matrix, P.Z, ("h", 0)),
           K.guard(K.substitute(rejected_matrix, (P.Z,)), P.Z))
    equation_zero = P.Eq(P.V(0), P.Z)
    retained = P.Eq(P.S(P.V(0)), P.Z)
    reject("root_eigenvariable_cannot_be_retained_parameter",
           ("ind", equation_zero, P.V(0), ("h", 1)),
           K.guard(P.Eq(P.V(0), P.Z), P.V(0)), (retained,), 1)
    reject("root_target_cannot_escape_scope",
           ("ind", P.Eq(P.V(0), P.V(0)), P.V(0), P.refl(P.S(P.V(0))).proof),
           P.Imp(P.F, P.F))
    reject("universal_eigenvariable_cannot_be_retained_parameter", ("Ai", ("h", 0)),
           P.All(P.Eq(P.V(0), P.Z)), (P.Eq(P.V(0), P.Z),), 1)
    exists_zero = P.Ex(P.Eq(P.V(0), P.Z))
    reject("existential_witness_cannot_escape",
           ("Ee", P.Eq(P.V(0), P.Z), ("h", 0), ("h", 0)),
           P.Eq(P.V(0), P.Z), (exists_zero,), 1)
    reject("equality_substitution_cannot_capture_bound_variable", replacement,
           P.All(P.Eq(P.ONE, P.V(0))), context)
    wrong_nested = P.R(P.V(0), P.R(P.V(0), P.V(1), outer_body), P.V(3))
    reject("recursion_substitution_cannot_capture_inner_variable", ("rec", nested),
           P.Eq(nested, wrong_nested), scope=2)
    reject("recursion_parameter_is_not_zero", ("rec", captured),
           P.Eq(captured, P.Z), scope=1)
    arbitrary_counter = P.R(P.V(0), P.Z, P.V(0))
    reject("recursion_equation_requires_zero_or_successor_counter", ("rec", arbitrary_counter),
           P.Eq(arbitrary_counter, P.Z), scope=1)
    reject("zero_case_conclusions_must_agree", ("zc", P.Z, P.refl(P.Z).proof, P.refl(P.ONE).proof),
           P.Eq(P.Z, P.Z))
    reject("zero_case_negation_is_not_zero_equality", ("zc", P.Z, ("h", 0), ("h", 0)),
           P.Eq(P.Z, P.Z))
    reject("implication_elimination_requires_exact_antecedent",
           (">e", ("h", 0), P.refl(P.Z).proof), P.F, (P.Imp(P.DELTA, P.F),))
    reject("existential_introduction_requires_instantiated_body",
           ("Ei", P.Eq(P.V(0), P.Z), P.ONE, P.refl(P.Z).proof),
           P.Ex(P.Eq(P.V(0), P.Z)))
    reject("equality_replacement_requires_matching_source",
           ("rep", P.Eq(P.V(0), P.Z), ("h", 0), P.refl(P.ONE).proof),
           P.Eq(P.ONE, P.Z), (P.DELTA,))
    reject("bridge_is_fixed_not_arbitrary_contradiction", ("bridge",),
           P.And(P.Imp(P.Eq(P.Z, P.Z), P.F), P.Imp(P.F, P.Eq(P.Z, P.Z))))

    # Fail closed on malformed public inputs.
    reject("negative_hypothesis_index", ("h", -1), P.DELTA, (P.DELTA,))
    reject("boolean_hypothesis_index", ("h", True), P.DELTA, (P.DELTA, P.DELTA))
    reject("out_of_range_hypothesis", ("h", 1), P.DELTA, (P.DELTA,))
    reject("undischarged_assumption_escape", (">i", P.DELTA, ("h", 1)),
           P.Imp(P.DELTA, P.DELTA))
    reject("negative_variable", ("h", 0), P.Eq(P.V(-1), P.Z), (P.Eq(P.V(-1), P.Z),))
    reject("unbound_variable", P.refl(P.V(0)).proof, P.Eq(P.V(0), P.V(0)))
    reject("malformed_term_arity", ("rec", ("r", ("0", P.Z), P.Z, P.V(0))), P.DELTA)
    reject("malformed_formula_arity", ("bridge",), ("&", P.F))
    reject("malformed_ordinary_disjunction_arity", ("h", 0), ("|", P.F), (P.F,))
    reject("ordinary_disjunction_does_not_bind_free_variables", ("h", 0),
           ("|", P.Eq(P.V(0), P.Z), P.F), (P.F,))
    reject("unknown_syntax", ("h", 0), ("oracle",), (("oracle",),))
    reject("boolean_scope", P.refl(P.Z).proof, P.Eq(P.Z, P.Z), scope=True)
    reject("negative_scope", P.refl(P.Z).proof, P.Eq(P.Z, P.Z), scope=-1)
    reject("non_tuple_context", ("h", 0), P.DELTA, [P.DELTA])
    reject("non_tuple_proof", ["bridge"], P.bridge().formula)
    reject("empty_proof", (), P.F)

    # Check the serialized interchange form as well as in-memory tuples.
    def tuples(obj):
        if isinstance(obj, list):
            return tuple(tuples(x) for x in obj)
        return obj
    encoded = json.dumps(certificates, sort_keys=True, indent=2) + "\n"
    decoded = json.loads(encoded)
    for record in decoded:
        if not K.check(tuples(record["proof"]), tuples(record["conclusion"]),
                       tuples(record["context"]), record["scope"]):
            raise AssertionError("serialized certificate rejected: " + record["name"])

    result = {
        "status": "PASS",
        "scope": ("Finite proof certificates for derived rules and arithmetic theorems; "
                  "negative syntax, substitution, eigenvariable, and rule checks. "
                  "This is not a Lean/Rocq formalization of the general equivalence "
                  "theorem or a proof of this Python checker's soundness."),
        "source_sha256": {p.name: digest(p.read_bytes())
                          for p in (HERE / "encoded_kernel.py", HERE / "encoded_proofs.py", Path(__file__))},
        "accepted_certificates": len(positive),
        "rejected_certificates": len(negative),
        "serialized_certificate_replay": len(decoded),
        "positive": positive,
        "negative": negative,
    }
    (HERE / "encoded_certificates.json").write_text(encoded)
    (HERE / "encoded_test_results.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "accepted": len(positive), "rejected": len(negative),
                      "serialized_replay": len(decoded)}, sort_keys=True))


if __name__ == "__main__":
    run()
