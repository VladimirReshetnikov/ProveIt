"""Reproduce the theorem certificates, independent audit, and size comparison.

Only Python 3.10+ and its standard library are required.  This runner, the
generators, and the tests are outside the trusted proof checker.  LaTeX
compilation is deliberately a separate command.
"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_script(filename):
    result = subprocess.run([sys.executable, "-B", filename], cwd=ROOT,
                            capture_output=True, text=True, timeout=60)
    if result.returncode:
        raise RuntimeError(filename + " failed:\n" + result.stdout + result.stderr)
    print("PASS " + filename)
    return {"script": filename, "exit_code": result.returncode}


def load_module(filename):
    path = ROOT / "comparison" / filename
    spec = importlib.util.spec_from_file_location("comparison_" + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def baseline_smoke(filename, explosion_as_axiom=False):
    """Check the baseline mechanisms whose implementation is being measured."""
    k = load_module(filename)
    zero, false, x = ("0",), ("!",), ("v", 0)
    one = ("s", zero)
    truth, delta = ("=", zero, zero), ("=", zero, one)
    accepted, rejected = [], []

    def yes(label, proof, conclusion, context=(), scope=0):
        if not k.check(proof, conclusion, context, scope):
            raise AssertionError((filename, "rejected expected proof", label))
        accepted.append(label)

    def no(label, proof, conclusion, context=(), scope=0):
        if k.check(proof, conclusion, context, scope):
            raise AssertionError((filename, "accepted forbidden proof", label))
        rejected.append(label)

    yes("primitive reflexivity", ("=", zero), truth)
    yes("open primitive reflexivity", ("=", x), ("=", x, x), scope=1)
    yes("separation", ("sep",), (">", delta, false))
    explosion = ((">e", ("!axiom", delta), ("h", 0)) if explosion_as_axiom
                 else ("!e", delta, ("h", 0)))
    yes("explosion", explosion, delta, (false,))
    base_term = ("r", zero, one, x)
    yes("recursion base", ("rec", base_term), ("=", base_term, one))
    step_term = ("r", ("s", x), zero, ("v", 1))
    yes("recursion counter step", ("rec", step_term), ("=", step_term, x), scope=1)
    equation = ("=", x, x)
    yes("original rooted equation rule",
        ("ind", equation, one, ("=", ("s", x))),
        k.guard(("=", one, one), one))
    parameter_equation = ("=", ("v", 1), ("v", 1))
    yes("rooted equation rule retains parameter indices",
        ("ind", parameter_equation, x, ("=", ("v", 1))),
        k.guard(("=", x, x), x), scope=1)
    no("universal eigenvariable escape", ("Ai", ("h", 0)),
       ("A", ("=", x, zero)), (("=", x, zero),), 1)
    existence = ("E", ("=", x, zero))
    no("existential eigenvariable escape",
       ("Ee", ("=", x, zero), ("h", 0), ("h", 0)),
       ("=", x, zero), (existence,), 1)
    invariant = ("=", x, zero)
    no("induction eigenvariable escape", ("ind", invariant, x, ("h", 1)),
       k.guard(("=", x, zero), x), (("=", ("s", x), zero),), 1)
    no("boolean hypothesis index", ("h", True), truth, (truth, truth))
    no("non-equational induction matrix",
       ("ind", (">", truth, truth), zero, (">i", truth, ("h", 0))),
       k.guard((">", truth, truth), zero))
    return {"file": filename, "accepted": len(accepted), "rejected": len(rejected),
            "accepted_cases": accepted, "rejected_cases": rejected}


def check_adapter():
    result = subprocess.run([sys.executable, "-B", "check_json.py", "example_reflexivity.json"],
                            cwd=ROOT, capture_output=True, text=True, timeout=60)
    if result.returncode != 0 or json.loads(result.stdout) != {"accepted": True}:
        raise AssertionError("JSON adapter rejected the supplied reflexivity example")
    invalid = subprocess.run([sys.executable, "-B", "check_json.py"], cwd=ROOT,
                             input='{"proof": ["=" , ["0"]], "conclusion": ["=", ["0"], ["0"]]}',
                             capture_output=True, text=True, timeout=60)
    if invalid.returncode != 1 or json.loads(invalid.stdout) != {"accepted": False}:
        raise AssertionError("JSON adapter accepted the removed primitive reflexivity rule")
    return {"valid_example_accepted": True, "forged_primitive_reflexivity_rejected": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--primary-only", action="store_true",
                        help="skip the optional disjunction-encoding test and audit suites")
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        raise SystemExit("Python 3.10 or newer is required")

    commands = [run_script("test_kernel.py"), run_script("audit_kernel.py")]
    if not args.primary_only:
        commands.extend([run_script("test_encoded_kernel.py"), run_script("encoded_audit_kernel.py")])
    commands.append(run_script("compare.py"))

    generated = ROOT / "comparison" / "recommended.py"
    kernel = ROOT / "kernel.py"
    if generated.read_bytes() != kernel.read_bytes():
        raise AssertionError("comparison/recommended.py is not byte-identical to kernel.py")

    baselines = [baseline_smoke("draft_common.py"),
                 baseline_smoke("draft_common_efq_axiom.py", explosion_as_axiom=True)]
    comparison = json.loads((ROOT / "comparison_results.json").read_text())
    adapter_bytes = (ROOT / "check_json.py").stat().st_size
    sizes = {name: {"kernel_bytes": row["bytes"], "adapter_bytes": adapter_bytes,
                    "total_bytes": row["bytes"] + adapter_bytes}
             for name, row in comparison.items() if isinstance(row, dict)}
    for name in ("draft_common", "draft_common_efq_axiom", "disjunction_free_full"):
        if sizes["recommended"]["total_bytes"] >= sizes[name]["total_bytes"]:
            raise AssertionError("recorded recommendation no longer wins the measured comparison")
    results = {
        "status": "PASS",
        "primary_only": args.primary_only,
        "commands": commands,
        "recommended_kernel_exact_match": True,
        "recommended_kernel_sha256": sha256(kernel),
        "adapter": check_adapter(),
        "baseline_smoke": baselines,
        "sizes_including_shared_json_adapter": sizes,
        "source_sha256": {name: sha256(ROOT / name)
                          for name in ("run_checks.py", "compare.py", "check_json.py")},
        "scope": ("Reproducible finite certificate, independent rule/substitution, baseline, "
                  "adapter, and matched-source size checks. The general metatheorems are "
                  "written proofs in report.tex, not Lean/Rocq formalizations. These tests "
                  "do not prove Python implementation soundness or absolute minimality."),
    }
    (ROOT / "run_results.json").write_text(json.dumps(results, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "primary_only": args.primary_only,
                      "recommended_total_bytes": sizes["recommended"]["total_bytes"],
                      "baseline_smoke_accepted": sum(row["accepted"] for row in baselines),
                      "baseline_smoke_rejected": sum(row["rejected"] for row in baselines)},
                     sort_keys=True))


if __name__ == "__main__":
    main()
