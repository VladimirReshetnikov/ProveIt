"""Independent audit of the complete kernel, outside the trusted base.

Run: python3 encoded_audit_kernel.py

Checks every rule family, adversarial eigenvariable uses, and the semantic
substitution lemma for generated syntax with nested one- and two-slot binders.
The finite semantic checks test substitution, not the truth or completeness
of arithmetic.  The written metatheory remains a separate proof obligation.
"""

import hashlib
import json
from pathlib import Path
import random

import encoded_kernel as K


Z = ("0",)
B = ("!",)
V = lambda i: ("v", i)
S = lambda a: ("s", a)
Eq = lambda a, b: ("=", a, b)
Imp = lambda a, b: (">", a, b)
Rec = lambda n, a, h: ("r", n, a, h)
N = lambda n: Z if n == 0 else S(N(n - 1))


def reflexivity(term):
    """A derived certificate, using only R0 and equality replacement."""
    redex = Rec(Z, term, V(0))
    computation = ("rec", redex)
    template = Eq(V(0), K.shift(term))
    return ("rep", template, computation, computation)


def main():
    accepted = []
    rejected = []

    def yes(label, proof, result, context=(), scope=0):
        if not K.check(proof, result, context, scope):
            raise AssertionError(("valid certificate rejected", label))
        accepted.append(label)

    def no(label, proof, result, context=(), scope=0):
        if K.check(proof, result, context, scope):
            raise AssertionError(("invalid certificate accepted", label))
        rejected.append(label)

    truth = Eq(Z, Z)
    p = reflexivity(Z)
    yes("derived reflexivity", p, truth)
    yes("open derived reflexivity", reflexivity(V(0)), Eq(V(0), V(0)), scope=1)
    yes("hypothesis index", ("h", 0), truth, (truth,))
    both = ("&i", p, p)
    yes("conjunction introduction", both, ("&", truth, truth))
    yes("left projection", ("&e", 0, both), truth)
    yes("right projection", ("&e", 1, both), truth)
    identity = (">i", truth, ("h", 0))
    yes("implication introduction", identity, Imp(truth, truth))
    yes("implication elimination", (">e", identity, p), truth)
    universal = ("Ai", reflexivity(V(0)))
    yes("universal introduction", universal, ("A", Eq(V(0), V(0))))
    yes("universal elimination", ("Ae", S(Z), universal), Eq(S(Z), S(Z)))
    existential = ("Ei", Eq(V(0), Z), Z, p)
    yes("existential introduction", existential, ("E", Eq(V(0), Z)))
    yes("existential elimination", ("Ee", truth, existential, p), truth)
    delta = Eq(Z, S(Z))
    bridge = ("&", Imp(delta, B), Imp(B, delta))
    yes("fixed bridge", ("bridge",), bridge)
    r0 = Rec(Z, S(Z), V(0))
    yes("recursion zero", ("rec", r0), Eq(r0, S(Z)))
    rs = Rec(S(V(0)), V(1), S(V(0)))
    yes("recursion state slot", ("rec", rs), Eq(rs, S(Rec(V(0), V(1), S(V(0))))), scope=2)
    counter = Rec(S(V(0)), Z, V(1))
    yes("recursion counter slot", ("rec", counter), Eq(counter, V(0)), scope=1)
    parameter = Rec(S(V(0)), Z, V(2))
    yes("recursion outer parameter", ("rec", parameter), Eq(parameter, V(0)), scope=1)
    yes("zero cases", ("zc", V(0), p, p), truth, scope=1)
    ambient = ("E", Eq(V(0), Z))
    yes("zero cases retains quantified context", ("zc", V(0), ("h", 1), ("h", 1)),
        ambient, (ambient,), scope=1)
    yes("root equation step", ("ind", truth, S(Z), p), K.guard(truth, S(Z)))
    outer_equation = Eq(V(1), V(1))
    yes("induction preserves parameter indices", ("ind", outer_equation, S(V(0)), reflexivity(V(1))),
        K.guard(Eq(V(0), V(0)), S(V(0))), scope=1)
    predecessor_equation = Eq(Rec(S(V(0)), Z, V(1)), V(0))
    predecessor_step = ("rec", Rec(S(S(V(0))), Z, V(1)))
    yes("induction substitutes counter but not recursor-local slots",
        ("ind", predecessor_equation, N(2), predecessor_step),
        K.guard(K.substitute(predecessor_equation, (N(2),)), N(2)))
    ax = ("rec", Rec(Z, Z, V(0)))
    yes("replacement beneath a quantifier", ("rep", ("A", Eq(V(1), Z)), ax, ("Ai", ax)),
        ("A", truth))
    yes("fresh universal variable shifts ambient assumption", ("Ai", ("h", 0)),
        ("A", Eq(V(1), Z)), (Eq(V(0), Z),), scope=1)

    no("primitive reflexivity has been removed", ("=", Z), truth)
    no("primitive explosion has been removed", ("!e", ("h", 0)), truth, (B,))
    no("unknown proof tag", ("axiom",), truth)
    no("non-tuple proof", ["bridge"], bridge)
    no("Boolean hypothesis index", ("h", True), truth, (truth, truth))
    no("negative hypothesis index", ("h", -1), truth, (truth,))
    no("nonexistent hypothesis", ("h", 0), truth)
    no("Boolean projection index", ("&e", True, both), truth)
    no("wrong projection index", ("&e", 2, both), truth)
    no("mismatched implication antecedent", (">e", identity, ("bridge",)), truth)
    no("escaping variable in term", ("rec", Rec(Z, V(0), V(0))), truth)
    no("negative de Bruijn index", reflexivity(V(-1)), Eq(V(-1), V(-1)))
    no("formula used as a term", ("rec", Rec(Z, B, V(0))), truth)
    no("malformed recursion arity", ("rec", ("r", Z, Z)), truth)
    no("recursor equation needs a constructor counter", ("rec", Rec(V(0), Z, V(0))), truth, scope=1)
    no("different conclusions in numerical cases", ("zc", V(0), ("h", 0), ("h", 0)),
        Eq(V(0), Z), scope=1)
    no("non-equational induction invariant", ("ind", Imp(truth, truth), Z, identity),
        K.guard(Imp(truth, truth), Z))
    no("induction target cannot use fresh counter", ("ind", truth, V(0), p), truth)
    no("induction hypothesis is not its successor equation", ("ind", truth, Z, ("h", 0)),
        K.guard(truth, Z))
    no("universal eigenvariable cannot occur in ambient hypothesis", ("Ai", ("h", 0)),
        ("A", Eq(V(0), Z)), (Eq(V(0), Z),), scope=1)
    ex = ("E", Eq(V(0), Z))
    no("existential witness cannot escape", ("Ee", Eq(V(0), Z), ("h", 0), ("h", 0)),
        Eq(V(0), Z), (ex,), scope=1)
    forged_existential = ("Ee", delta, ("h", 0),
                           ("rep", Eq(V(0), S(Z)), ("h", 0), ("h", 2)))
    no("existential eigenvariable must shift all ambient parameters", forged_existential,
        delta, (ex, Eq(V(0), S(Z))), scope=1)
    invariant = Eq(V(0), S(Z))
    forged_step = ("rep", Eq(S(V(1)), S(V(0))), ("h", 1), reflexivity(S(V(0))))
    no("induction eigenvariable must shift all ambient parameters",
        ("ind", invariant, N(2), forged_step),
        K.guard(Eq(N(2), S(Z)), N(2)), (Eq(V(0), Z),), scope=1)
    no("unknown predicate symbol", ("h", 0), ("P", Z), (("P", Z),))
    no("primitive disjunction proof constructor is absent", ("|i", 0, B, p), ("|", truth, B))
    yes("full disjunction claim is accepted", ("h", 0), ("|", truth, B), (("|", truth, B),))
    full = ("|", Eq(V(0), Z), ("A", ("|", Eq(V(0), V(1)), B)))
    yes("nested quantified disjunction claim", ("h", 0), full, (full,), scope=1)
    ztest = Eq(V(0), Z)
    negative = Imp(ztest, B)
    inner = ("E", ("&", Imp(ztest, Eq(V(1), V(3))), Imp(negative, B)))
    expected_encoding = ("E", ("&", Imp(ztest, Eq(V(1), Z)), Imp(negative, ("A", inner))))
    if K.encode(full, 1) != expected_encoding:
        raise AssertionError("disjunction encoder captures a variable under nested quantifiers")
    for label, malformed, scope in (
        ("surplus equality child", ("|", truth, ("=", Z, Z, Z)), 0),
        ("surplus successor child", ("|", truth, Eq(("s", Z, Z), Z)), 0),
        ("Boolean variable", ("|", truth, Eq(V(True), Z)), 2),
        ("surplus quantifier child", ("|", truth, ("A", truth, B)), 0),
        ("surplus disjunction child", ("|", truth, B, truth), 0),
        ("term as disjunct", ("|", truth, Z), 0),
        ("list as disjunct", ("|", truth, ["!"]), 0),
    ):
        no("encoder validates before shifting: " + label, ("h", 0), malformed, (malformed,), scope=scope)
    no("Boolean scope is not an integer scope", p, truth, scope=True)
    no("context must be a tuple", p, truth, context=[])

    rng = random.Random(20261106)
    counters = {"term": 0, "formula": 0, "shift": 0, "drop": 0, "preserve": 0}

    def term(scope, depth):
        if depth == 0:
            return V(rng.randrange(scope)) if scope and rng.randrange(2) else Z
        tag = rng.randrange(5)
        if tag < 2:
            return term(scope, 0)
        if tag == 2:
            return S(term(scope, depth - 1))
        return Rec(N(rng.randrange(3)), term(scope, depth - 1), term(scope + 2, depth - 1))

    def formula(scope, depth):
        if depth == 0:
            return Eq(term(scope, 2), term(scope, 2)) if rng.randrange(3) else B
        tag = rng.randrange(5)
        if tag == 0:
            return formula(scope, 0)
        if tag in (1, 2):
            return ("&" if tag == 1 else ">", formula(scope, depth - 1), formula(scope, depth - 1))
        return ("A" if tag == 3 else "E", formula(scope + 1, depth - 1))

    def evaluate(a, environment):
        """Independent semantics; quantifiers sample a fixed finite domain."""
        tag = a[0]
        if tag == "v":
            return environment[a[1]]
        if tag == "0":
            return 0
        if tag == "s":
            return evaluate(a[1], environment) + 1
        if tag == "r":
            n = evaluate(a[1], environment)
            value = evaluate(a[2], environment)
            for counter in range(n):
                value = evaluate(a[3], (value, counter) + environment)
            return value
        if tag == "=":
            return evaluate(a[1], environment) == evaluate(a[2], environment)
        if tag == "!":
            return False
        if tag == "&":
            return evaluate(a[1], environment) and evaluate(a[2], environment)
        if tag == ">":
            return not evaluate(a[1], environment) or evaluate(a[2], environment)
        values = (evaluate(a[1], (x,) + environment) for x in range(3))
        return all(values) if tag == "A" else any(values)

    for kind, generator, sort in (("term", term, "t"), ("formula", formula, "f")):
        for _ in range(300):
            a = generator(4, 3)
            if not K.wellformed(a, sort, 4):
                raise AssertionError("audit generator produced malformed syntax")
            environment = tuple(rng.randrange(4) for _ in range(4))
            extra = (rng.randrange(4), rng.randrange(4))
            if evaluate(K.shift(a, 2), extra + environment) != evaluate(a, environment):
                raise AssertionError(("shift semantic failure", a))
            counters["shift"] += 1
            replacements = (term(2, 2), term(2, 2))
            target_environment = environment[:2]
            inserted = tuple(evaluate(t, target_environment) for t in replacements)
            result = K.substitute(a, replacements)
            if (not K.wellformed(result, sort, 2)
                    or evaluate(result, target_environment) != evaluate(a, inserted + target_environment)):
                raise AssertionError(("dropping substitution semantic failure", a, replacements))
            counters["drop"] += 1
            replacements = (term(4, 2), term(4, 2))
            inserted = tuple(evaluate(t, environment) for t in replacements)
            result = K.substitute(a, replacements, drop=False)
            if (not K.wellformed(result, sort, 4)
                    or evaluate(result, environment) != evaluate(a, inserted + environment[2:])):
                raise AssertionError(("preserving substitution semantic failure", a, replacements))
            counters["preserve"] += 1
            counters[kind] += 1

    result = {
        "status": "PASS",
        "kernel_sha256": hashlib.sha256(Path(K.__file__).read_bytes()).hexdigest(),
        "valid_certificates": len(accepted),
        "invalid_certificates": len(rejected),
        "accepted_cases": accepted,
        "rejected_cases": rejected,
        "substitution_checks": counters,
        "scope": "Independent rule and eigenvariable audit; finite semantic substitution checks, not a proof-assistant metatheory.",
    }
    destination = Path(__file__).with_name("encoded_audit_results.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
