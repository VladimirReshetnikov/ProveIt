"""Untrusted certificate constructors for the small iPRA kernel.

Every returned Claim must be checked by kernel.check.  These helpers are not
part of the trusted checker or its size count.  They construct ordinary finite
proof trees, including the claimed derived rules; they add no kernel rules.
"""

from dataclasses import dataclass

import encoded_kernel as K


Z = K.ZERO
F = K.FALSE
V = lambda i: ("v", i)
S = lambda t: ("s", t)
R = lambda n, a, h: ("r", n, a, h)
Eq = lambda s, t: ("=", s, t)
And = lambda a, b: ("&", a, b)
Imp = lambda a, b: (">", a, b)
All = lambda a: ("A", a)
Ex = lambda a: ("E", a)
Neg = lambda a: Imp(a, F)
ONE = S(Z)
DELTA = Eq(Z, ONE)


def Or(a, b):
    """An ordinary formula, not a new syntax or proof constructor."""
    z = Eq(V(0), Z)
    return Ex(And(Imp(z, K.shift(a)), Imp(Neg(z), K.shift(b))))


def raise_free(expression, amount=1, cutoff=0):
    return K.variables(expression, lambda i, d: V(i + amount if i >= d + cutoff else i))


def _map_proof(proof, number_map, hypothesis_map, nd=0, hd=0):
    """Traverse proof binding structure, separately from expression binders."""
    tag = proof[0]
    e = lambda a, extra=0: number_map(a, nd + extra)
    p = lambda a, dn=0, dh=0: _map_proof(a, number_map, hypothesis_map, nd + dn, hd + dh)
    if tag == "h":
        return hypothesis_map(proof[1], nd, hd)
    if tag == "rep":
        return (tag, e(proof[1], 1), p(proof[2]), p(proof[3]))
    if tag == "&i" or tag == ">e":
        return (tag, p(proof[1]), p(proof[2]))
    if tag == "&e":
        return (tag, proof[1], p(proof[2]))
    if tag == ">i":
        return (tag, e(proof[1]), p(proof[2], dh=1))
    if tag == "Ai":
        return (tag, p(proof[1], dn=1))
    if tag == "Ae":
        return (tag, e(proof[1]), p(proof[2]))
    if tag == "Ei":
        return (tag, e(proof[1], 1), e(proof[2]), p(proof[3]))
    if tag == "Ee":
        return (tag, e(proof[1]), p(proof[2]), p(proof[3], dn=1, dh=1))
    if tag == "bridge":
        return proof
    if tag == "rec":
        return (tag, e(proof[1]))
    if tag == "zc":
        return (tag, e(proof[1]), p(proof[2], dh=1), p(proof[3], dh=1))
    if tag == "ind":
        return (tag, e(proof[1], 1), e(proof[2]), p(proof[3], dn=1, dh=1))
    raise ValueError("unknown proof constructor in untrusted transformation")


def lift_certificate(proof, amount=1):
    return _map_proof(proof, lambda a, d: raise_free(a, amount, d),
                      lambda i, nd, hd: ("h", i))


def weaken_certificate(proof, amount=1, cutoff=0):
    return _map_proof(proof, lambda a, d: a,
                      lambda i, nd, hd: ("h", i + amount if i >= hd + cutoff else i))


def cut_certificate(body, argument):
    """Replace the outermost assumption by a proof in the retained context."""
    def replace(i, nd, hd):
        if i == hd:
            return weaken_certificate(lift_certificate(argument, nd), hd)
        return ("h", i - 1 if i > hd else i)
    return _map_proof(body, lambda a, d: a, replace)


@dataclass(frozen=True)
class Claim:
    formula: tuple
    proof: tuple

    def valid(self, context=(), scope=0):
        return K.check(self.proof, self.formula, context, scope)


def hyp(formula, index=0):
    return Claim(formula, ("h", index))


def weaken(d, amount=1, cutoff=0):
    return Claim(d.formula, weaken_certificate(d.proof, amount, cutoff))


def lift(d, amount=1):
    return Claim(K.shift(d.formula, amount), lift_certificate(d.proof, amount))


def cut(body, argument):
    return Claim(body.formula, cut_certificate(body.proof, argument.proof))


def rec(term):
    _, n, a, h = term
    if n == Z:
        result = a
    else:
        assert n[0] == "s"
        result = K.substitute(h, (R(n[1], a, h), n[1]))
    return Claim(Eq(term, result), ("rec", term))


def rep(formula, equality, premise):
    assert equality.formula[0] == "="
    _, s, t = equality.formula
    assert premise.formula == K.substitute(formula, (s,))
    return Claim(K.substitute(formula, (t,)),
                 ("rep", formula, equality.proof, premise.proof))


def refl(t):
    """Derived reflexivity: rec supplies a=t and rep turns it into t=t."""
    p = rec(R(Z, t, V(0)))
    return rep(Eq(V(0), K.shift(t)), p, p)


def sym(d):
    _, s, t = d.formula
    return rep(Eq(V(0), K.shift(s)), d, refl(s))


def trans(first, second):
    _, s, t = first.formula
    assert second.formula[0] == "=" and second.formula[1] == t
    return rep(Eq(K.shift(s), V(0)), second, first)


def congruence(template, equality):
    """The term template binds its single argument in de Bruijn slot zero."""
    _, s, t = equality.formula
    fs = K.substitute(template, (s,))
    return rep(Eq(K.shift(fs), template), equality, refl(fs))


def bridge():
    return Claim(And(Imp(DELTA, F), Imp(F, DELTA)), ("bridge",))


def pair(left, right):
    return Claim(And(left.formula, right.formula), ("&i", left.proof, right.proof))


def project(index, conjunction):
    assert conjunction.formula[0] == "&" and index in (0, 1)
    return Claim(conjunction.formula[index + 1], ("&e", index, conjunction.proof))


def introduce(assumption, body):
    return Claim(Imp(assumption, body.formula), (">i", assumption, body.proof))


def apply(implication, argument):
    assert implication.formula[0] == ">" and implication.formula[1] == argument.formula
    return Claim(implication.formula[2], (">e", implication.proof, argument.proof))


def generalize(body):
    return Claim(All(body.formula), ("Ai", body.proof))


def instantiate(term, universal):
    assert universal.formula[0] == "A"
    return Claim(K.substitute(universal.formula[1], (term,)),
                 ("Ae", term, universal.proof))


def witness(formula, term, premise):
    assert premise.formula == K.substitute(formula, (term,))
    return Claim(Ex(formula), ("Ei", formula, term, premise.proof))


def exists_eliminate(conclusion, existence, premise):
    assert premise.formula == K.shift(conclusion)
    return Claim(conclusion, ("Ee", conclusion, existence.proof, premise.proof))


def zero_cases(term, zero_branch, other_branch):
    assert zero_branch.formula == other_branch.formula
    return Claim(zero_branch.formula, ("zc", term, zero_branch.proof, other_branch.proof))


def root(equation, term, premise):
    return Claim(K.guard(K.substitute(equation, (term,)), term),
                 ("ind", equation, term, premise.proof))


def separated(delta):
    return apply(project(0, bridge()), delta)


def collapse(delta, s, t):
    """From 0=S0 derive s=t using one constant recursion update."""
    assert delta.formula == DELTA
    body = K.shift(t, 2)
    at_zero, at_one = R(Z, s, body), R(ONE, s, body)
    counter_template = R(V(0), K.shift(s), K.shift(t, 3))
    middle = congruence(counter_template, delta)
    return trans(sym(rec(at_zero)), trans(middle, rec(at_one)))


def explode(false_proof, formula):
    """Compile a finite proof of any full source formula from genuine falsity."""
    assert false_proof.formula == F
    tag = formula[0]
    if tag == "!":
        return false_proof
    if tag == "=":
        delta = apply(project(1, bridge()), false_proof)
        return collapse(delta, formula[1], formula[2])
    if tag == "&":
        return pair(explode(false_proof, formula[1]), explode(false_proof, formula[2]))
    if tag == ">":
        return introduce(formula[1], explode(weaken(false_proof), formula[2]))
    if tag == "A":
        return generalize(explode(lift(false_proof), formula[1]))
    if tag == "E":
        return witness(formula[1], Z, explode(false_proof, K.substitute(formula[1], (Z,))))
    raise ValueError("unknown formula")


def or_left(left, b):
    a = left.formula
    d = Eq(Z, Z)
    first = introduce(d, weaken(left))
    false_proof = apply(hyp(Neg(d)), refl(Z))
    second = introduce(Neg(d), explode(false_proof, b))
    return witness(Or(a, b)[1], Z, pair(first, second))


def or_right(a, right):
    b = right.formula
    d = Eq(ONE, Z)
    false_proof = separated(sym(hyp(d)))
    first = introduce(d, explode(false_proof, a))
    second = introduce(Neg(d), weaken(right))
    return witness(Or(a, b)[1], ONE, pair(first, second))


def or_eliminate(disjunction, a, b, left_branch, right_branch):
    """Branches have contexts (a,)+Gamma and (b,)+Gamma respectively."""
    assert disjunction.formula == Or(a, b)
    assert left_branch.formula == right_branch.formula
    c = left_branch.formula
    body = disjunction.formula[1]
    d = Eq(V(0), Z)
    a_proof = apply(project(0, hyp(body, 1)), hyp(d))
    b_proof = apply(project(1, hyp(body, 1)), hyp(Neg(d)))
    left = cut(weaken(lift(left_branch), 2, 1), a_proof)
    right = cut(weaken(lift(right_branch), 2, 1), b_proof)
    cases = zero_cases(V(0), left, right)
    return exists_eliminate(c, disjunction, cases)


def predecessor(t):
    return R(t, Z, V(1))


def predecessor_successor(t):
    return rec(predecessor(S(t)))


def successor_injective(s, t, equality):
    assert equality.formula == Eq(S(s), S(t))
    middle = congruence(predecessor(V(0)), equality)
    return trans(sym(predecessor_successor(s)), trans(middle, predecessor_successor(t)))


def successor_nonzero(t):
    assumption = Eq(S(t), Z)
    mapped = congruence(predecessor(V(0)), hyp(assumption))
    t_zero = trans(sym(predecessor_successor(t)), trans(mapped, rec(predecessor(Z))))
    st_one = congruence(S(V(0)), t_zero)
    delta = trans(sym(hyp(assumption)), st_one)
    return introduce(assumption, separated(delta))


def equation_induction(equation, term, base, step):
    """Derived contextual equation induction; no extra primitive rule.

    equation has one additional numerical slot (its induction variable).
    base proves E(0); step proves forall x (E(x) -> E(Sx)).  Both use Gamma.
    The output proves E(term) in Gamma.  Parameters and Gamma are unrestricted.
    """
    assert equation[0] == "="
    assert base.formula == K.substitute(equation, (Z,))
    expected_step = All(Imp(equation, K.substitute(equation, (S(V(0)),), drop=False)))
    assert step.formula == expected_step
    x = V(0)
    template_in_x = raise_free(equation, 1, 1)
    lifted_base = weaken(lift(base), 2)
    e_x_zero = rep(template_in_x, sym(hyp(Eq(x, Z))), lifted_base)
    lifted_step = instantiate(x, weaken(lift(step), 2))
    zero_branch = apply(lifted_step, e_x_zero)
    h_x = K.guard(equation, x)
    e_x_nonzero = apply(hyp(h_x, 1), hyp(Neg(Eq(x, Z))))
    other_branch = apply(lifted_step, e_x_nonzero)
    guarded = root(equation, term, zero_cases(x, zero_branch, other_branch))
    final_zero = rep(equation, sym(hyp(Eq(term, Z))), weaken(base))
    final_other = apply(weaken(guarded), hyp(Neg(Eq(term, Z))))
    return zero_cases(term, final_zero, final_other)


def identity_recursion(term, initial):
    """A nontrivial induction certificate for r(n,a;v,w.v)=a."""
    equation = Eq(R(V(0), K.shift(initial), V(0)), K.shift(initial))
    base = rec(R(Z, initial, V(0)))
    at_successor = rec(R(S(V(0)), K.shift(initial), V(0)))
    step_body = trans(at_successor, hyp(equation))
    step = generalize(introduce(equation, step_body))
    return equation_induction(equation, term, base, step)


def coverage(term):
    """Derive the encoded disjunction t=0 or S(pred(t))=t."""
    equation = Eq(S(predecessor(V(0))), V(0))
    progress = congruence(S(V(0)), predecessor_successor(V(0)))
    guarded = root(equation, term, progress)
    a, b = Eq(term, Z), K.substitute(equation, (term,))
    left = or_left(hyp(a), b)
    right = or_right(a, apply(weaken(guarded), hyp(Neg(a))))
    return zero_cases(term, left, right)


def predecessor_coverage(term):
    """Derive t=0 or exists y (t=Sy), in the encoded disjunction."""
    equation = Eq(S(predecessor(V(0))), V(0))
    progress = congruence(S(V(0)), predecessor_successor(V(0)))
    guarded = root(equation, term, progress)
    a = Eq(term, Z)
    existential_body = Eq(K.shift(term), S(V(0)))
    b = Ex(existential_body)
    equality = sym(apply(weaken(guarded), hyp(Neg(a))))
    predecessor_exists = witness(existential_body, predecessor(term), equality)
    return zero_cases(term, or_left(hyp(a), b), or_right(a, predecessor_exists))


def disjunction_commutes(a, b):
    """A closed-in-hypotheses proof of (A V B) -> (B V A)."""
    premise = Or(a, b)
    left = or_right(b, hyp(a))
    right = or_left(hyp(b), a)
    return introduce(premise, or_eliminate(hyp(premise), a, b,
                                         weaken(left, 1, 1), weaken(right, 1, 1)))
