"""Generate matched, readable checker variants and measure their full sources.

All alternatives use the same recursion binding, scopes, equality replacement,
logical handlers, error handling, and certificate representation. No golfing,
compression, optimizer, imported proof engine, or omitted goal encoder is used.
"""

import ast
import hashlib
import io
import json
from pathlib import Path
import tokenize

ROOT = Path(__file__).resolve().parent
CORE = (ROOT / "encoded_kernel.py").read_text()


def change(source, old, new):
    if source.count(old) != 1:
        raise ValueError(("comparison patch drift", old))
    return source.replace(old, new)


def primitive_reflexivity(source):
    anchor = '        case ("rep", formula, equality, premise):\n'
    code = '''        case ("=", t):
            require(wellformed(t, "t", scope))
            return ("=", t, t)
'''
    return change(source, anchor, code + anchor)


def primitive_explosion(source, as_axiom=False):
    old = '''        case ("bridge",):
            delta = ("=", ZERO, ("s", ZERO))
            return ("&", (">", delta, FALSE), (">", FALSE, delta))
'''
    new = '''        case ("sep",):
            return (">", ("=", ZERO, ("s", ZERO)), FALSE)
'''
    if as_axiom:
        new += '''        case ("!axiom", conclusion):
            require(wellformed(conclusion, "f", scope))
            return (">", FALSE, conclusion)
'''
    else:
        new += '''        case ("!e", conclusion, premise):
            require(wellformed(conclusion, "f", scope)
                    and infer(premise, context, scope) == FALSE)
            return conclusion
'''
    return change(source, old, new)


def primitive_disjunction(source):
    source = change(source, '    "&": ("f", (("f", 0), ("f", 0))),\n',
                    '    "|": ("f", (("f", 0), ("f", 0))),\n'
                    '    "&": ("f", (("f", 0), ("f", 0))),\n')
    source = change(source,
                    '    return (">", (">", zero_test(term), FALSE), equation)\n',
                    '    return ("|", zero_test(term), equation)\n')
    start = source.index('def encode(')
    end = source.index('def infer(', start)
    source = source[:start] + source[end:]
    old = '''        case ("zc", term, zero_branch, other_branch):
            require(wellformed(term, "t", scope))
            a = zero_test(term)
            c = infer(zero_branch, (a,) + context, scope)
            require(infer(other_branch, ((">", a, FALSE),) + context, scope) == c)
            return c
'''
    new = '''        case ("|i", i, other, premise):
            require(type(i) is int and i in (0, 1) and wellformed(other, "f", scope))
            a = infer(premise, context, scope)
            return ("|", a, other) if i == 0 else ("|", other, a)
        case ("|e", disjunction, left_branch, right_branch):
            a = infer(disjunction, context, scope)
            require(a[0] == "|")
            c = infer(left_branch, (a[1],) + context, scope)
            require(infer(right_branch, (a[2],) + context, scope) == c)
            return c
'''
    source = change(source, old, new)
    source = change(source,
                    '        conclusion = encode(conclusion, scope)\n'
                    '        context = tuple(encode(a, scope) for a in context)\n',
                    '        require(wellformed(conclusion, "f", scope)\n'
                    '                and all(wellformed(a, "f", scope) for a in context))\n')
    return source


def metrics(source):
    tree = ast.parse(source)
    ignored = {tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
               tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
               tokenize.ENCODING}
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in ignored]
    active = set()
    for t in tokens:
        active.update(range(t.start[0], t.end[0] + 1))
    handlers = sum(len(n.cases) for n in ast.walk(tree) if isinstance(n, ast.Match))
    data = source.encode()
    return dict(bytes=len(data), lexical_tokens=len(tokens),
                ast_nodes=sum(1 for _ in ast.walk(tree)),
                nonblank_noncomment_lines=len(active),
                dispatch_cases=handlers, sha256=hashlib.sha256(data).hexdigest())


def main():
    common = primitive_reflexivity(primitive_explosion(CORE))
    variants = {
        "disjunction_free_full": CORE,
        "no_or_with_refl_efq": common,
        "recommended": primitive_disjunction(CORE),
        "draft_common": primitive_disjunction(common),
        "draft_common_efq_axiom": primitive_disjunction(
            primitive_reflexivity(primitive_explosion(CORE, as_axiom=True))),
    }
    out = ROOT / "comparison"
    out.mkdir(exist_ok=True)
    results = {}
    for name, text in variants.items():
        compile(text, str(out / (name + ".py")), "exec")
        (out / (name + ".py")).write_text(text)
        results[name] = metrics(text)
    results["scope"] = (
        "Complete Python kernel source including full-formula input encoding, "
        "syntax and scopes, substitution, schema/rule checking and errors. "
        "The same separate JSON I/O adapter is excluded from every row. "
        "These are matched implementations, not source measurements of old "
        "diagnostic scripts and not a global lower-bound theorem."
    )
    (ROOT / "comparison_results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
