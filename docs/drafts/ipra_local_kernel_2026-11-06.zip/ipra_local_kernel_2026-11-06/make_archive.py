"""Refresh file hashes and create a deterministic source-and-PDF ZIP archive."""

import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_DIRS = {"__pycache__", "build"}
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".fls", ".fdb_latexmk"}


def included(path):
    relative = path.relative_to(ROOT)
    return (path.is_file() and not any(part in EXCLUDED_DIRS for part in relative.parts)
            and path.suffix not in EXCLUDED_SUFFIXES and path.name != "FILES.sha256")


def main():
    for name in ("report.tex", "report.pdf", "checker.py", "verify.py",
                 "verification_summary.json", "validation/summary.json"):
        if not (ROOT / name).is_file():
            raise SystemExit(f"Missing deliverable: {name}")
    files = sorted(path for path in ROOT.rglob("*") if included(path))
    if any(path.is_symlink() for path in files):
        raise SystemExit("Archive inputs must be regular files, not links.")
    manifest = ROOT / "FILES.sha256"
    manifest.write_text("".join(
        hashlib.sha256(path.read_bytes()).hexdigest() + "  "
        + path.relative_to(ROOT).as_posix() + "\n" for path in files))
    files.append(manifest)
    output = ROOT.with_suffix(".zip")
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files):
            info = zipfile.ZipInfo((Path(ROOT.name) / path.relative_to(ROOT)).as_posix(),
                                   date_time=(2026, 11, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=9)
    with zipfile.ZipFile(output) as archive:
        bad = archive.testzip()
        if bad:
            raise SystemExit(f"ZIP integrity failure: {bad}")
    print(f"Created {output.name}: {len(files)} files, {output.stat().st_size} bytes.")


if __name__ == "__main__":
    main()
