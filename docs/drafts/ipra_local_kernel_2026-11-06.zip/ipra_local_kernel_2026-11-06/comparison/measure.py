"""Measure source syntax without importing or executing candidate checkers."""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parent
IGNORED = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
           tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}
AXES = ['raw_bytes','normalized_bytes','source_tokens','normalized_tokens','ast_nodes','source_lines']
class RemoveDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if node.body and isinstance(node.body[0],ast.Expr) and isinstance(node.body[0].value,ast.Constant) and isinstance(node.body[0].value.value,str):
            node.body.pop(0)
        return self.generic_visit(node)
    visit_Module=clean
    visit_FunctionDef=clean
    visit_AsyncFunctionDef=clean
    visit_ClassDef=clean

def measure(p):
    raw=p.read_bytes();source=raw.decode();tree=ast.parse(source);spans=[]
    for n in ast.walk(tree):
        if isinstance(n,(ast.Module,ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.body:
            d=n.body[0]
            if isinstance(d,ast.Expr) and isinstance(d.value,ast.Constant) and isinstance(d.value.value,str):
                spans.append(((d.lineno,d.col_offset),(d.end_lineno,d.end_col_offset)))
    def tokens(text,spans=()):
        return sum(t.type not in IGNORED and not any(lo<=t.start and t.end<=hi for lo,hi in spans) for t in tokenize.generate_tokens(io.StringIO(text).readline))
    names={n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    imports=sorted({alias.name for n in ast.walk(tree) if isinstance(n,ast.Import) for alias in n.names}|{n.module or '' for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)})
    has_cli=any(isinstance(n,ast.If) and '__name__' in ast.unparse(n.test) and '__main__' in ast.unparse(n.test) for n in tree.body)
    tree=RemoveDocstrings().visit(tree);normalized=ast.unparse(tree)+'\n'
    return {'sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw),'normalized_bytes':len(normalized.encode()),'source_tokens':tokens(source,spans),'normalized_tokens':tokens(normalized),'ast_nodes':sum(1 for n in ast.walk(tree)),'source_lines':len(source.splitlines()),'imports':imports,'function_names':sorted(names),'has_cli':has_cli}

def main():
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate',type=Path)
    parser.add_argument('--output',type=Path,default=ROOT/'metrics.json')
    args=parser.parse_args()
    manifest=json.loads((ROOT/'manifest.json').read_text())
    measured={}
    for record in manifest['sources']:
        m=measure(ROOT/record['path'])
        if m['sha256'] != record['sha256'] or m['raw_bytes'] != record['raw_bytes']:
            raise ValueError('Frozen source mismatch: '+record['path'])
        measured[record['sha256']]=m
    primary=[{'name':r['name'],'metrics':measured[r['metrics']['sha256']]} for r in manifest['primary']]
    standalone=[measured[r['metrics']['sha256']] for r in manifest['standalone']]
    groups=[]
    for g in manifest['historical_dependency_groups']:
        members=[measured[f['sha256']] for f in g['files']]
        groups.append({'id':g['id'],'label':g['label'],'metrics':{k:sum(m[k] for m in members) for k in AXES}})
    rows=standalone+[g['metrics'] for g in groups]
    envelope={k:min(m[k] for m in rows) for k in AXES}
    out={'python_version':platform.python_version(),'snapshot_commit':manifest['snapshot_commit'],'verified_source_count':len(measured),'standalone_count':len(standalone),'dependency_group_count':len(groups),'primary':primary,'complete_envelope':envelope,'groups':groups,'source_metrics':measured}
    if args.candidate:
        candidate=measure(args.candidate)
        if not set(candidate['imports']) <= {'json','sys'}:
            raise ValueError('Candidate has uncounted imports: '+str(candidate['imports']))
        if not candidate['has_cli']:
            raise ValueError('Candidate has no CLI in the compared program boundary')
        out['candidate']=candidate
        out['candidate_at_or_below']={k:candidate[k]<=envelope[k] for k in AXES}
        out['candidate_strictly_below']={k:candidate[k]<envelope[k] for k in AXES}
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in {'groups','source_metrics'}},indent=2))
if __name__=='__main__':main()
