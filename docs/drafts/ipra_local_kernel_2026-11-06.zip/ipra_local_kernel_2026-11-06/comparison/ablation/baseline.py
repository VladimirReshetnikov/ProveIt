"""Complete iPRA checker: sorted syntax and inferred existential conclusions.

Falsity has the explicit arithmetic conversion bottom = (0 = S0).
Hypotheses are formulas; recursor computations certify themselves.
Only finite JSON is input; no proof generator is trusted.
"""

import json
import sys

ZERO = -1


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


SCOPES = ({"s": (0,), "r": (0, 0, 2)},
          {"=": (0, 0), "pi": (1, 1), "ex": (1,)})


def subst(a, env=(1,), d=0, formula=True):
    if type(a) is int:
        require(not formula and a >= -1)
        i = a - d
        return a if i < 0 else subst(env[i], (d,), formula=False) if i < len(env) - 1 else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + width, width == 1)
                   for b, width in zip(args, SCOPES[formula][tag], strict=True))]


def infer(p, g):
    match p:
        case [("lam" | "pack") as tag, a, q]:
            h = a if tag == "lam" else ["=", 0, subst(a, formula=False)]
            subst(h)
            b = infer(q, [*map(subst, g), h])
            return ["pi", a, b] if tag == "lam" else ["ex", b]
        case ["use", p, *args]:
            tag, *parts = infer(p, g)
            if tag == "ex":
                return subst(infer(*args, [*map(subst, g), *parts]), [None, -1])
            a, q = args
            subst(a, formula=tag != "pi")
            b, c = (subst(a, [t, -1]) if tag == "=" else subst(t, [a, -1]) for t in parts)
            require(infer(q, g) == b)
            return c
        case ["r", n, a, h] as r:
            subst(r, formula=False)
            if n == ZERO:
                b = a
            else:
                _, n = n
                b = subst(h, [["r", n, a, h], n, -2], formula=False)
            return ["=", r, b]
        case ["nat", a, p]:
            base = subst(a, [ZERO, 0])
            require(infer(p, g) == ["pi", a if a[0] == "=" else base,
                                    subst(a, [["s", 0], 0])])
            return ["pi", base, a]
        case _:
            return g[g.index(p)]


def check(data):
    g, a, p = data
    require(type(g) is list)
    for b in [*g, a]:
        subst(b)
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        _, path = sys.argv
        with open(path, encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except Exception:
        print("REJECT")
        sys.exit(1)
