"""Construct and measure a full 2x2x2 controlled family of complete kernels.

All variants retain exactly the same JSON entry point, syntax traversal,
recursor branch, exception boundary, and imports. The transformations only
change the three named proof representations. This generator is untrusted.
"""
import ast
import argparse
import itertools
import json
from pathlib import Path
import platform

import measure as metrics

HERE = Path(__file__).resolve().parent
EXPECTED_BASELINE_SHA256 = 'c8ccc683ddd50d18ab5316257cdeaacf2b0a788112c36a844c60d6acc3e80a55'
COMMON_HEADER = '"""Controlled complete iPRA acceptance implementation."""'
FINAL_HEADER = '''"""Complete iPRA checker with shared local rules and checked scope lifting.

check(data) returns normally on acceptance and raises on rejection.
The command-line interface prints ACCEPT or REJECT.
"""'''

SHARED_INTRO = '''        case [("lam" | "pack" | "nat") as tag, a, q]:
            if tag == "pack":
                a = ["=", 0, subst(a, formula=False)]
            base = subst(a, [ZERO, 0] if tag == "nat" else (0,))
            b = infer(q, [*map(subst, g), a if a[0] == "=" else base])
            if tag == "nat":
                require(b == subst(a, [["s", 0], 0]))
                b = a
            return ["ex", b] if tag == "pack" else ["pi", base, b]
'''
SEPARATE_INTRO = '''        case [("lam" | "pack") as tag, a, q]:
            h = a if tag == "lam" else ["=", 0, subst(a, formula=False)]
            subst(h)
            b = infer(q, [*map(subst, g), h])
            return ["pi", a, b] if tag == "lam" else ["ex", b]
'''
SEPARATE_NAT = '''        case ["nat", a, p]:
            base = subst(a, [ZERO, 0])
            require(infer(p, g) == ["pi", a if a[0] == "=" else base,
                                    subst(a, [["s", 0], 0])])
            return ["pi", base, a]
'''
INFERRED_EX = '''        case ["use", p, *args]:
            tag, *parts = infer(p, g)
            if tag == "ex":
                return subst(infer(*args, [*map(subst, g), *parts]), [None, -1])
            a, q = args
            subst(a, formula=tag != "pi")
'''
EXPLICIT_EX = '''        case ["use", p, a, q]:
            tag, *parts = infer(p, g)
            lifted = subst(a, formula=tag != "pi")
            if tag == "ex":
                require(infer(q, [*map(subst, g), *parts]) == lifted)
                return a
'''


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('Expected exactly one source region for transformation')
    return text.replace(old, new)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, default=HERE / 'baseline.py',
                        help='Exact frozen inferred_elimination checker; defaults to bundled baseline.py.')
    parser.add_argument('--output-dir', type=Path, default=HERE,
                        help='Directory for all complete controlled variants and measurements.')
    parser.add_argument('--candidate', type=Path,
                        help='Optional final delivered checker; verify executable-AST identity and measure it.')
    args = parser.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    baseline_metrics = metrics.measure(args.baseline)
    if baseline_metrics['sha256'] != EXPECTED_BASELINE_SHA256:
        raise ValueError('The baseline does not match the frozen source hash.')
    baseline = args.baseline.read_text()
    header_end = baseline.index('"""', 3) + 3
    common = COMMON_HEADER + baseline[header_end:]
    records = []
    for local, indexed, inferred in itertools.product((False, True), repeat=3):
        source = common
        if local:
            source = replace_once(source, SEPARATE_INTRO, SHARED_INTRO)
            source = replace_once(source, SEPARATE_NAT, '')
        if indexed:
            source = replace_once(source, 'return g[g.index(p)]', 'return g[p]')
        if not inferred:
            source = replace_once(source, INFERRED_EX, EXPLICIT_EX)
        name = f'kernel_L{int(local)}_I{int(indexed)}_E{int(inferred)}.py'
        path = output / name
        compile(source, str(path), 'exec')
        path.write_text(source)
        records.append({'file': name, 'local_shared_N': local,
                        'indexed_hypotheses': indexed,
                        'inferred_ex_elimination': inferred,
                        'metrics': metrics.measure(path)})
    explicit = next(r for r in records if r['local_shared_N'] and
                    r['indexed_hypotheses'] and not r['inferred_ex_elimination'])
    final_source = replace_once((output / explicit['file']).read_text(),
                                '    return True\n', '')
    final_source = replace_once(final_source, COMMON_HEADER, FINAL_HEADER)
    final_path = output / 'kernel_final.py'
    compile(final_source, str(final_path), 'exec')
    final_path.write_text(final_source)
    final = {'file': final_path.name, 'local_shared_N': True,
             'indexed_hypotheses': True, 'inferred_ex_elimination': False,
             'normal_return_success': True, 'metrics': metrics.measure(final_path)}
    origin = next(r for r in records if not r['local_shared_N'] and
                  not r['indexed_hypotheses'] and r['inferred_ex_elimination'])
    def normalized(path):
        tree = metrics.RemoveDocstrings().visit(ast.parse(path.read_text()))
        return ast.dump(tree, include_attributes=False)
    if normalized(output / origin['file']) != normalized(args.baseline):
        raise ValueError('The controlled origin differs from the baseline executable AST.')
    delivered = None
    if args.candidate:
        if normalized(final_path) != normalized(args.candidate):
            raise ValueError('The delivered candidate differs from the final controlled executable AST.')
        if final_path.read_bytes() != args.candidate.read_bytes():
            raise ValueError('The delivered candidate differs from the final controlled source bytes.')
        delivered = metrics.measure(args.candidate)
    summary = {'baseline_sha256': baseline_metrics['sha256'],
               'python_version': platform.python_version(),
               'baseline_actual': baseline_metrics, 'candidate_actual': delivered,
               'final_variant': final,
               'variants': records,
               'invariants': ['Entire acceptance boundary counted',
                              'Only standard json and sys imported',
                              'Same syntax validator and substitution traversal',
                              'Same external judgment interface and explicit goal validation',
                              'Same recursor computation branch',
                              'Same fail-closed CLI and exception handler'],
               'note': 'L is local numerical premise plus shared local-rule implementation; I selects actual context entries; E infers witness-independent conclusions. Complete kernels differ in certificate representations, not in native derivability.'}
    (output / 'metrics.json').write_text(json.dumps(summary, indent=2) + '\n')
    lines = ['variant,L,I,E,normal_return_success,ast_nodes,source_tokens,normalized_tokens,normalized_bytes,raw_bytes,sha256']
    for r in [*records, final]:
        m = r['metrics']
        lines.append(','.join(map(str, [r['file'], int(r['local_shared_N']), int(r['indexed_hypotheses']),
                     int(r['inferred_ex_elimination']), int(r.get('normal_return_success', False)),
                     m['ast_nodes'], m['source_tokens'],
                     m['normalized_tokens'], m['normalized_bytes'], m['raw_bytes'], m['sha256']])))
    (output / 'table.csv').write_text('\n'.join(lines) + '\n')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
