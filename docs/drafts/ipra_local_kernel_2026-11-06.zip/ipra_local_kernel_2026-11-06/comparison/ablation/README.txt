Controlled ablation of the complete iPRA checker
================================================

This directory is self-contained. It includes the exact frozen baseline,
eight complete controlled variants, the final complete checker, the source
generator, the uniform measurement program, and focused constructor checks.
Only Python's standard library is needed. Use Python 3.11 or later.

Reproduction from any current directory
--------------------------------------

 python3 /path/to/this/directory/build_ablation.py
 python3 /path/to/this/directory/check_variants.py

To verify that the final generated source matches the delivered checker
byte-for-byte, add its path:

 python3 /path/to/this/directory/build_ablation.py --candidate /path/to/checker.py

Optional inputs/outputs:

 --baseline PATH     selects another local copy of the exact frozen baseline.
                     Its SHA-256 must match the documented source hash.
 --output-dir PATH   puts all nine generated sources and measurements there.

For a nondefault output directory, run check_variants.py --directory PATH.
No workspace-specific paths, network access, or parent-directory imports are
used. Neither these scripts nor their results are imported by any checker.

Provenance and invariant acceptance boundary
-------------------------------------------

baseline.py is the primary checker from the SHA-verified current draft
ipra_inferred_elimination_2026-11-06.zip, at ProveIt snapshot
820ef51b6ad3c13ce4a500673a9e81d951fbc06c. Its source SHA-256 is:

 c8ccc683ddd50d18ab5316257cdeaacf2b0a788112c36a844c60d6acc3e80a55

All eight controlled variants preserve the entire counted acceptance boundary:
standard JSON entry point, explicit context/goal validation, the same sorted
substitution traversal, the same validated recursor branch, and the same
fail-closed exception handler. They import only json and sys. No proof generator
or external axiom data participates in acceptance.

The eight controlled variants have identical header comments. The ninth uses
the delivered checker's exact header to permit a byte-for-byte identity check.
Normalized syntax measurements exclude all docstrings, comments, and layout.

Axes
----

 L = local numerical premise and the resulting shared lam/pack/nat branch.
     L=0 checks a closed Pi step premise. L=1 checks its successor body in the
     fresh local context directly. These are interderivable by Pi I/E.

 I = direct context indexing. I=0 uses a formula-key proof leaf and returns
     its actual validated context member. I=1 uses a position and returns the
     actual validated context member. Both implement the same hypothesis rule.

 E = inferred existential elimination. E=0 carries an explicit conclusion and
     compares its lift with the local conclusion, reusing the existing syntax
     validation traversal's result. E=1 infers the local conclusion and partially
     lowers it, failing if the witness occurs free. Both enforce the same
     eigenvariable condition, with different certificate representations.

All eight are complete representations of the same native derivability.
kernel_L0_I0_E1.py is executable-AST identical to baseline.py. All executable
differences among the eight variants belong to these three named axes.

Final ninth variant
-------------------

kernel_final.py is L1I1E0 with the redundant success Boolean removed from check.
The API convention is: normal return means acceptance; an exception means
rejection. The CLI already uses precisely this convention and is unchanged.
Thus the final change does not alter which JSON certificates the CLI accepts.

The final source SHA-256 is:

 672afaab345fa563807621166cf9f3b7604a8cf288fca145b8d8aed5b666648b

It has 688 executable AST nodes, 636 source tokens, 634 normalized tokens,
2122 normalized bytes, and 2364 raw source bytes. The complete source is 80
physical lines, including docstring and blank lines.

Findings
--------

 I saves 5 AST nodes, 5 source/normalized tokens, and 9 normalized bytes.
 L saves 10 AST nodes, 14 source/normalized tokens, and 1 normalized byte.
 E costs 7 AST nodes, 7 source/normalized tokens, and 2 normalized bytes.

These effects are additive in the controlled family. Inferred Ex is a smaller
certificate representation here, but it is NOT a smaller acceptance program.
The efficient explicit Ex branch stores the lifted result of a traversal that
is required anyway for validation. This is why retaining the conclusion wins.

From the strongest current baseline L0I0E1 to L1I1E0 the improvements are 22 AST
nodes and 26 normalized tokens. Removing the unused success Boolean saves a
further 2 AST nodes, 2 tokens, and 16 normalized bytes. The final total reduction
is 24 AST nodes, 28 normalized tokens, and 28 normalized bytes.

Validation scope
----------------

All nine sources compile. check_variants.py exercises 13 direct cases per
variant, covering all primitive constructors and selected rejection conditions.
It supplies literal expected formulas without a candidate substitution oracle.
It accepts an imported check call exactly when that call returns normally.
The current result is 117 checks, zero failures.

These are focused construction checks of the ablation family. They do not claim
formal verification or replace the separate project's independent scope,
substitution, adversarial-input, and full-certificate validation.

Outputs
-------

 metrics.json               Full metrics, source hashes, invariant boundary.
 table.csv                  Compact all-nine comparison with exact hashes.
 constructor_checks.json    All 117 focused check results.
 kernel_L*_I*_E*.py          Eight complete controlled acceptance programs.
 kernel_final.py            Exact final delivered acceptance program.
