"""Uniform source measurements; does not execute the measured program."""
import ast
import hashlib
import io
import tokenize

IGNORED = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
           tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}


class RemoveDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return self.generic_visit(node)

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            doc = node.body[0]
            if (isinstance(doc, ast.Expr) and isinstance(doc.value, ast.Constant)
                    and isinstance(doc.value.value, str)):
                spans.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))

    def tokens(text, excluded=()):
        return sum(token.type not in IGNORED and
                   not any(lo <= token.start and token.end <= hi for lo, hi in excluded)
                   for token in tokenize.generate_tokens(io.StringIO(text).readline))

    imports = sorted({alias.name for node in ast.walk(tree) if isinstance(node, ast.Import)
                      for alias in node.names} |
                     {node.module or '' for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)})
    tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(tree) + '\n'
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'raw_bytes': len(raw),
            'normalized_bytes': len(normalized.encode('utf-8')),
            'source_tokens': tokens(source, spans), 'normalized_tokens': tokens(normalized),
            'ast_nodes': sum(1 for node in ast.walk(tree)),
            'source_lines': len(source.splitlines()), 'imports': imports}
