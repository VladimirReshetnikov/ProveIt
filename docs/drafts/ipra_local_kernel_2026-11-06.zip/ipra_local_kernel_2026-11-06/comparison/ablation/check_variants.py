"""Small direct constructor checks of all complete controlled variants.

These checks prevent accidental construction of nonfunctional ablations.
They are not a soundness proof or a replacement for independent validation.
Expected formulas are literal data and never use a candidate traversal.
"""
import importlib.util
import argparse
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
Z = -1
T = ['=', Z, Z]


def load(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=HERE,
                        help='Directory containing generated variants and metrics.json.')
    args = parser.parse_args()
    directory = args.directory.resolve()
    records = []
    data = json.loads((directory / 'metrics.json').read_text())
    rows = [*data['variants'], data['final_variant']]
    for row in rows:
        mod = load(directory / row['file'])
        indexed, local, inferred = (row[k] for k in
            ('indexed_hypotheses', 'local_shared_N', 'inferred_ex_elimination'))
        ref = lambda a, i=0: i if indexed else a
        comp = ['r', Z, Z, Z]
        reflexivity = ['use', comp, ['=', 0, Z], comp]
        witness = ['=', 0, Z]
        existential = ['ex', T]
        quantified = ['ex', ['=', 0, Z]]
        successor_comp = ['r', ['s', Z], Z, 0]
        previous = ['r', Z, Z, 0]
        nat_t = ref(T) if local else ['lam', T, ref(T)]
        nat_ex = ref(existential) if local else ['lam', existential, ref(existential)]
        major = ref(existential)
        minor = ref(T, -1)
        eliminate = ['use', major, minor] if inferred else ['use', major, T, minor]
        bad_major = ref(quantified)
        leak = (['use', bad_major, ref(witness, -1)] if inferred else
                ['use', bad_major, witness, ref(witness, -1)])
        tests = [
            ('hypothesis', [[T], T, ref(T)], True),
            ('R0_and_transport', [[], T, reflexivity], True),
            ('PiI', [[], ['pi', T, T], ['lam', T, ref(T)]], True),
            ('EI', [[], ['ex', witness], ['pack', Z, ref(witness)]], True),
            ('PiE', [[['pi', T, T]], T,
                     ['use', ref(['pi', T, T]), Z, reflexivity]], True),
            ('EE', [[existential], T, eliminate], True),
            ('RS', [[], ['=', successor_comp, previous], successor_comp], True),
            ('atomic_N', [[], ['pi', T, T], ['nat', T, nat_t]], True),
            ('compound_cases', [[], ['pi', existential, existential],
                                ['nat', existential, nat_ex]], True),
            ('witness_escape', [[quantified], witness, leak], False),
            ('inactive_malformed_step', [[], T, ['r', Z, Z, True]], False),
            ('unused_bad_instantiation', [[['pi', T, T]], T,
                       ['use', ref(['pi', T, T]), False, reflexivity]], False),
            ('malformed_claim', [[T], ['=', False, False], ref(T)], False),
        ]
        for name, data, expected in tests:
            try:
                mod.check(data)
                actual = True
            except Exception:
                actual = False
            records.append({'variant': row['file'], 'case': name,
                            'expected': expected, 'accepted': actual})
    failures = [r for r in records if r['expected'] != r['accepted']]
    result = {'checks': len(records), 'failures': failures, 'passed': not failures,
              'records': records,
              'scope': 'Direct checks of complete controlled variants, not a formal proof.'}
    (directory / 'constructor_checks.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'checks': len(records), 'failures': failures, 'passed': not failures}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
