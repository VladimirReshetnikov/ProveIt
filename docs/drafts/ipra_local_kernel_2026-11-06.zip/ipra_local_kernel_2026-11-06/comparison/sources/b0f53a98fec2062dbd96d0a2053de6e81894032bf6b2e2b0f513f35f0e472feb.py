"""Cross-check positive certificates by explicit rules and named substitution.

This intentionally larger test interpreter does not import the trusted
checker. All variable operations go through the independent named oracle.
It is test infrastructure, not part of the acceptance program.
"""

from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

from audit import oracle, valid


def require(condition):
    if not condition:
        raise ValueError("independent certificate check failed")


def validate(expression, formula):
    require(valid(expression, formula))
    return expression


def infer(proof, context, counts):
    if type(proof) is list and proof and type(proof[0]) is str:
        tag = proof[0]
        if tag == "lam":
            require(len(proof) == 3)
            guard = validate(proof[1], True)
            local = [oracle(a) for a in context] + [guard]
            result = infer(proof[2], local, counts)
            counts["universal_introduction"] += 1
            return ["pi", guard, result]
        if tag == "pack":
            require(len(proof) == 3)
            witness = validate(proof[1], False)
            local = [oracle(a) for a in context] + [["=", 0, oracle(witness, formula=False)]]
            result = infer(proof[2], local, counts)
            counts["existential_introduction"] += 1
            return ["ex", result]
        if tag == "use":
            require(len(proof) >= 2)
            principal = infer(proof[1], context, counts)
            if principal[0] == "ex":
                require(len(proof) == 3)
                local = [oracle(a) for a in context] + [principal[1]]
                branch = infer(proof[2], local, counts)
                result = oracle(branch, [None, -1])
                counts["existential_elimination"] += 1
                return result
            require(len(proof) == 4)
            if principal[0] == "pi":
                witness = validate(proof[2], False)
                antecedent = oracle(principal[1], [witness, -1])
                result = oracle(principal[2], [witness, -1])
                counts["universal_elimination"] += 1
            else:
                require(principal[0] == "=")
                template = validate(proof[2], True)
                antecedent = oracle(template, [principal[1], -1])
                result = oracle(template, [principal[2], -1])
                counts["equality_transport"] += 1
            require(infer(proof[3], context, counts) == antecedent)
            return result
        if tag == "r":
            validate(proof, False)
            counter, initial, update = proof[1:]
            if counter == -1:
                result = initial
                counts["recursion_zero"] += 1
            else:
                require(type(counter) is list and len(counter) == 2 and counter[0] == "s")
                predecessor = counter[1]
                state = ["r", predecessor, initial, update]
                result = oracle(update, [state, predecessor, -2], formula=False)
                counts["recursion_successor"] += 1
            return ["=", proof, result]
        if tag == "nat":
            require(len(proof) == 3)
            matrix = validate(proof[1], True)
            base = oracle(matrix, [-1, 0])
            guard = matrix if matrix[0] == "=" else base
            consequent = oracle(matrix, [["s", 0], 0])
            require(infer(proof[2], context, counts) == ["pi", guard, consequent])
            counts["equation_induction" if matrix[0] == "=" else "numerical_cases"] += 1
            return ["pi", base, matrix]
    for stored in context:
        if proof == stored:
            counts["assumption"] += 1
            return stored
    raise ValueError("unavailable assumption")


def check(data):
    require(type(data) is list and len(data) == 3)
    context, conclusion, proof = data
    require(type(context) is list)
    for a in context + [conclusion]:
        validate(a, True)
    counts = Counter()
    require(infer(proof, context, counts) == conclusion)
    return counts


def main():
    if len(sys.argv) != 3:
        raise SystemExit("Usage: python3 certificate_oracle.py EXAMPLES_DIRECTORY REPORT_JSON")
    root = Path(sys.argv[1])
    reports = []
    totals = Counter()
    for path in sorted(root.rglob("*.json")):
        data = json.loads(path.read_text())
        counts = check(data)
        totals.update(counts)
        reports.append({"file": str(path.relative_to(root)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                        "proof_nodes": sum(counts.values()), "rules": dict(counts)})
    result = {"status": "passed", "certificates": len(reports), "proof_nodes": sum(totals.values()),
              "rules": dict(totals), "records": reports,
              "method": "Explicit independent rule interpreter, with globally named binding and substitution; candidate code is never imported."}
    Path(sys.argv[2]).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "records"}, indent=2))


if __name__ == "__main__":
    main()
