"""All nonlogical axiom generators. No evaluator or optimizer is trusted."""

from syntax import Z, BOT, S, Eq, Imp, Or, All, need, arguments, sub


def arithmetic(tag, args):
    if tag == "sep":
        need(not args)
        return Imp(Eq(Z, S(Z)), BOT)
    if tag in ("r0", "r1"):
        arguments(args, "t")
        r = args[0]
        need(type(r) is tuple and r[0] == "r")
        h, n, a, *parameters = r[1:]
        if tag == "r0":
            return Eq(("r", h, Z, a, *parameters), a)
        values = (r, n, *parameters)
        return Eq(("r", h, S(n), a, *parameters), sub(h, values.__getitem__))
    if tag == "ind":
        arguments(args, "f")
        e = args[0]
        need(e[0] == "=")
        rooted = Or(Eq(0, Z), e)
        step = sub(e, lambda i: S(0) if i == 0 else i)
        return Imp(All(Imp(rooted, step)), All(rooted))
    raise ValueError("unknown arithmetic schema")
