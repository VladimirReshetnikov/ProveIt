"""iPRA with fused universal implication and existential conjunction.

Formula constructors: eq, false, or, ["U", name, A, B], ["P", name, A, B].
U means forall name (A implies B); P means exists name (A and B).
"""

from common import Base, ZERO, ONE, FALSE, require, run


class Kernel(Base):
    binary = {"or"}
    binders = {"U": 2, "P": 2}
    separation = ["U", 0, ["eq", ZERO, ONE], FALSE]

    def logical(self, proof, context, goal):
        match proof:
            case ["U_intro", name, premise]:
                require(goal[0] == "U")
                self.fresh(name, context + [goal])
                left, right = [self.substitute(child, goal[1], ["v", name])
                               for child in goal[2:]]
                self.check(premise, context + [left], right)
            case ["U_elim", universal, term, premise, argument]:
                self.formula(universal)
                self.term(term)
                require(universal[0] == "U")
                left, right = [self.substitute(child, universal[1], term)
                               for child in universal[2:]]
                require(goal == right)
                self.check(premise, context, universal)
                self.check(argument, context, left)
            case ["P_intro", term, left, right]:
                require(goal[0] == "P")
                self.term(term)
                first, second = [self.substitute(child, goal[1], term)
                                 for child in goal[2:]]
                self.check(left, context, first)
                self.check(right, context, second)
            case ["P_elim", existential, name, premise, continuation]:
                self.formula(existential)
                require(existential[0] == "P")
                self.fresh(name, context + [goal, existential])
                parts = [self.substitute(child, existential[1], ["v", name])
                         for child in existential[2:]]
                self.check(premise, context, existential)
                self.check(continuation, context + parts, goal)
            case _:
                require(False)


if __name__ == "__main__":
    raise SystemExit(run(Kernel))
