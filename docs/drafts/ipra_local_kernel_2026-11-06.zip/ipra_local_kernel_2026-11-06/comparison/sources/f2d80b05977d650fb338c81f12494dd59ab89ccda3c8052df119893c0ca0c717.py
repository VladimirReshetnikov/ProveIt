"""Drafts' common raw core, already given the documented native-recursion syntax."""

from shared import (B, COMMON, Eq, S, V, Z, arity, common_rule, head, instantiate,
                    lifted, main, need, shift, successor_instance, verify, well)


SYNTAX = COMMON | {
    "and": ("formula", (("formula", 0), ("formula", 0))),
    "or": ("formula", (("formula", 0), ("formula", 0))),
    "imp": ("formula", (("formula", 0), ("formula", 0))),
    "all": ("formula", (("formula", 1),)),
    "ex": ("formula", (("formula", 1),)),
}
SEPARATION = ["imp", Eq(Z, S(Z)), B]


def check(proof, goal, context, scope):
    tag = head(proof)
    if common_rule(proof, goal, context, scope, SYNTAX, check, SEPARATION):
        return
    if tag == "andI":
        arity(proof, 2)
        need(goal[0] == "and", "not a conjunction")
        check(proof[1], goal[1], context, scope)
        check(proof[2], goal[2], context, scope)
    elif tag == "andE":
        arity(proof, 3)
        principal, side, conjunction = proof[1:]
        well(principal, "formula", scope, SYNTAX)
        need(principal[0] == "and" and type(side) is int and side in (0, 1), "bad projection")
        need(goal == principal[side + 1], "wrong conjunction target")
        check(conjunction, principal, context, scope)
    elif tag == "orI":
        arity(proof, 2)
        side, alternative = proof[1:]
        need(goal[0] == "or" and type(side) is int and side in (0, 1), "bad alternative")
        check(alternative, goal[side + 1], context, scope)
    elif tag == "orE":
        arity(proof, 4)
        principal, disjunction, left, right = proof[1:]
        well(principal, "formula", scope, SYNTAX)
        need(principal[0] == "or", "not a disjunction")
        check(disjunction, principal, context, scope)
        check(left, goal, context + [principal[1]], scope)
        check(right, goal, context + [principal[2]], scope)
    elif tag == "impI":
        arity(proof, 1)
        need(goal[0] == "imp", "not an implication")
        check(proof[1], goal[2], context + [goal[1]], scope)
    elif tag == "impE":
        arity(proof, 3)
        principal, implication, argument = proof[1:]
        well(principal, "formula", scope, SYNTAX)
        need(principal[0] == "imp" and goal == principal[2], "wrong implication target")
        check(implication, principal, context, scope)
        check(argument, principal[1], context, scope)
    elif tag == "allI":
        arity(proof, 1)
        need(goal[0] == "all", "not a universal formula")
        check(proof[1], goal[1], lifted(context, SYNTAX), scope + 1)
    elif tag == "allE":
        arity(proof, 3)
        principal, witness, universal = proof[1:]
        well(principal, "formula", scope, SYNTAX)
        well(witness, "term", scope, SYNTAX)
        need(principal[0] == "all", "not a universal principal")
        need(goal == instantiate(principal[1], [witness], SYNTAX), "wrong universal target")
        check(universal, principal, context, scope)
    elif tag == "exI":
        arity(proof, 2)
        witness, instance = proof[1:]
        need(goal[0] == "ex", "not an existential formula")
        well(witness, "term", scope, SYNTAX)
        check(instance, instantiate(goal[1], [witness], SYNTAX), context, scope)
    elif tag == "exE":
        arity(proof, 3)
        principal, existential, branch = proof[1:]
        well(principal, "formula", scope, SYNTAX)
        need(principal[0] == "ex", "not an existential principal")
        check(existential, principal, context, scope)
        check(branch, shift(goal, 1, SYNTAX),
              lifted(context, SYNTAX) + [principal[1]], scope + 1)
    elif tag == "sc":
        arity(proof, 3)
        equation, target, step = proof[1:]
        well(equation, "formula", scope + 1, SYNTAX)
        well(target, "term", scope, SYNTAX)
        need(equation[0] == "eq", "successor closure requires an equation")
        need(goal == ["or", Eq(target, Z), instantiate(equation, [target], SYNTAX)],
             "wrong successor-closure target")
        assumption = ["or", Eq(V(0), Z), equation]
        check(step, successor_instance(equation, SYNTAX),
              lifted(context, SYNTAX) + [assumption], scope + 1)
    else:
        need(False, "unknown proof rule")


if __name__ == "__main__":
    raise SystemExit(main(SYNTAX, check))
