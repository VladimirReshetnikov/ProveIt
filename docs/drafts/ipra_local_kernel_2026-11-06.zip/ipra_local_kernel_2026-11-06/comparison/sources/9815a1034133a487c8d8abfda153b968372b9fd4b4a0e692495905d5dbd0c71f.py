"""Shared finite syntax and arithmetic for the two iPRA proof checkers."""


def natural(value):
    return type(value) is int and value >= 0


def node(value, tag, length):
    return type(value) is list and len(value) == length and value[0] == tag


def term(value, scope):
    if natural(value):
        return value < scope
    if node(value, "0", 1):
        return True
    if node(value, "s", 2):
        return term(value[1], scope)
    if node(value, "r", 4):
        return (term(value[1], scope) and term(value[2], scope)
                and term(value[3], scope + 2))
    return False


def map_term(value, variable, depth=0):
    if type(value) is int:
        return value if value < depth else lift_term(variable(value - depth), depth)
    if value[0] == "0":
        return ["0"]
    if value[0] == "s":
        return ["s", map_term(value[1], variable, depth)]
    return ["r", map_term(value[1], variable, depth),
            map_term(value[2], variable, depth),
            map_term(value[3], variable, depth + 2)]


def lift_term(value, amount):
    return value if amount == 0 else map_term(value, lambda index: index + amount)


def replacement(values):
    return lambda index: values[index] if index < len(values) else index - len(values)


def instantiate_term(value, values):
    return map_term(value, replacement(values))


class Arithmetic:
    """The subclasses supply formula syntax and their logical rule cases."""

    def lift(self, formula, amount):
        return self.map_formula(formula, lambda index: index + amount)

    def instantiate(self, formula, values):
        return self.map_formula(formula, replacement(values))

    def lifted_context(self, context, amount):
        return [self.lift(formula, amount) for formula in context]

    def check(self, scope, context, conclusion, proof):
        try:
            return (natural(scope) and type(context) is list
                    and all(self.formula(formula, scope) for formula in context)
                    and self.formula(conclusion, scope)
                    and self._check(scope, context, conclusion, proof))
        except (IndexError, KeyError, TypeError, ValueError, RecursionError):
            return False

    def _check(self, scope, context, conclusion, proof):
        if not (type(proof) is list and proof and type(proof[0]) is str):
            return False
        tag = proof[0]
        if tag == "hyp" and len(proof) == 2:
            index = proof[1]
            return (natural(index) and index < len(context)
                    and context[index] == conclusion)
        if tag == "refl" and len(proof) == 1:
            return node(conclusion, "=", 3) and conclusion[1] == conclusion[2]
        if tag == "eq" and len(proof) == 5:
            equation, template, equal_proof, body_proof = proof[1:]
            return (node(equation, "=", 3) and self.formula(equation, scope)
                    and self.formula(template, scope + 1)
                    and conclusion == self.instantiate(template, [equation[2]])
                    and self._check(scope, context, equation, equal_proof)
                    and self._check(scope, context,
                                    self.instantiate(template, [equation[1]]), body_proof))
        if tag in ("r0", "rs") and len(proof) == 1:
            if not node(conclusion, "=", 3) or not node(conclusion[1], "r", 4):
                return False
            _, counter, initial, body = conclusion[1]
            if tag == "r0":
                return counter == ["0"] and conclusion[2] == initial
            if not node(counter, "s", 2):
                return False
            previous = ["r", counter[1], initial, body]
            return conclusion[2] == instantiate_term(body, [previous, counter[1]])
        if tag == "sep" and len(proof) == 1:
            return conclusion == self.separation()
        if tag == "ind" and len(proof) == 4:
            equation, target, premise = proof[1:]
            if not (node(equation, "=", 3) and self.formula(equation, scope + 1)
                    and term(target, scope)):
                return False
            expected = self.zero_or(target, self.instantiate(equation, [target]))
            successor = self.map_formula(equation,
                                        lambda index: ["s", 0] if index == 0 else index)
            extended = self.lifted_context(context, 1) + [self.zero_or(0, equation)]
            return (conclusion == expected
                    and self._check(scope + 1, extended, successor, premise))
        return self.logic(scope, context, conclusion, proof)
