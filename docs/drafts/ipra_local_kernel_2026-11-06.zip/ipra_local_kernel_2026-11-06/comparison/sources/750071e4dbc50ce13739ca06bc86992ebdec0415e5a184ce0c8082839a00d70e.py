"""iPRA with uniform universal/implication and existential/disjunction blocks."""
from common import Arithmetic, map_term, natural, node, term


class Checker(Arithmetic):
    def formula(self, value, scope):
        if node(value, "=", 3):
            return term(value[1], scope) and term(value[2], scope)
        return (type(value) is list and len(value) == 2 and value[0] in ("P", "D")
                and type(value[1]) is list
                and all(type(block) is list and len(block) == 2
                        and natural(block[0]) and type(block[1]) is list
                        and (value[0] == "D" or len(block[1]) > 0)
                        and all(self.formula(item, scope + block[0]) for item in block[1])
                        for block in value[1]))

    def map_formula(self, value, variable, depth=0):
        if value[0] == "=":
            return ["=", map_term(value[1], variable, depth),
                    map_term(value[2], variable, depth)]
        return [value[0], [[count, [self.map_formula(item, variable, depth + count)
                                   for item in items]] for count, items in value[1]]]

    def zero_or(self, value, equation):
        return ["D", [[0, [["=", value, ["0"]]]], [0, [equation]]]]

    def separation(self):
        return ["P", [[0, [["=", ["0"], ["s", ["0"]]], ["D", []]]]]]

    def logic(self, scope, context, conclusion, proof):
        if proof[0] == "I" and len(proof) == 2 and conclusion[0] in ("P", "D"):
            source, data = conclusion, proof[1]
        elif proof[0] == "E" and len(proof) == 4:
            source, major, data = proof[1:]
            if not (self.formula(source, scope) and source[0] in ("P", "D")
                    and self._check(scope, context, source, major)):
                return False
        else:
            return False
        # D introduction and P elimination select one block and supply witnesses.
        # P introduction and D elimination check every block under fresh variables.
        if (proof[0] == "I") == (source[0] == "D"):
            if not (type(data) is list and len(data) == 3):
                return False
            index, witnesses, arguments = data
            if not (natural(index) and index < len(source[1])):
                return False
            count, items = source[1][index]
            if not (type(witnesses) is list and len(witnesses) == count
                    and all(term(witness, scope) for witness in witnesses)):
                return False
            if source[0] == "P":
                if conclusion != self.instantiate(items[-1], witnesses):
                    return False
                items = items[:-1]
            return (type(arguments) is list and len(arguments) == len(items)
                    and all(self._check(scope, context, self.instantiate(item, witnesses), part)
                            for item, part in zip(items, arguments)))
        return (type(data) is list and len(data) == len(source[1])
                and all(self._check(scope + count,
                                    self.lifted_context(context, count)
                                    + (items if source[0] == "D" else items[:-1]),
                                    self.lift(conclusion, count) if source[0] == "D" else items[-1],
                                    part)
                        for (count, items), part in zip(source[1], data)))


check = Checker().check
