"""Complete iPRA checker with unary existential and one typed substitution.

Input is finite JSON; public falsity means the equation 0 = S0.
The paper specifies the calculus, encodings, and trusted boundary.
"""

import json
import sys

ZERO = -1
SCOPES = {"s": (0,), "r": (0, 0, 2), "=": (0, 0),
          "pi": (1, 1), "ex": (1,)}


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def subst(a, env=(1,), depth=0, formula=None):
    if a == ["false"]:
        a = ["=", ZERO, ["s", ZERO]]
    if type(a) is int:
        require(formula is not True and a >= -1)
        i = a - depth
        return a if i < 0 else subst(env[i], (depth,)) if i < len(env) - 1 else a + env[-1]
    require(type(a) is list)
    tag, *args = a
    require(formula is None or (tag not in ("s", "r")) == formula)
    return [tag, *(subst(b, env, depth + d, d == 1)
                   for b, d in zip(args, SCOPES[tag], strict=True))]


def infer(p, g):
    match p:
        case ["hyp", key]:
            return g[g.index(subst(key, (0,)))]
        case ["pi", a, q]:
            a = subst(a, (0,), formula=True)
            return ["pi", a, infer(q, [*map(subst, g), a])]
        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            a = subst(a, (0,), formula=tag != "pi")
            if tag == "ex":
                require(infer(q, [*map(subst, g), *e[1:]]) == subst(a))
                return a
            b, c = (subst(a, [t, -1]) if tag == "=" else subst(t, [a, -1]) for t in e[1:])
            require(infer(q, g) == b)
            return c
        case ["pack", t, p]:
            t = subst(t, (0,), formula=False)
            h = [*map(subst, g), ["=", 0, subst(t)]]
            return ["ex", infer(p, h)]
        case ["rec", ["r", n, a, h] as r]:
            subst(r, (0,), formula=False)
            if n == ZERO:
                b = a
            else:
                require(type(n) is list and n[0] == "s")
                b = subst(h, [["r", n[1], a, h], n[1], -2])
            return ["=", r, b]
        case ["nat", a]:
            a = subst(a, (0,), formula=True)
            base = subst(subst(a, [ZERO, -1]))
            h = a if a[0] == "=" else base
            step = ["pi", h, subst(a, [["s", 0], 0])]
            return ["pi", base, ["pi", subst(step, (2,)), subst(a)]]
        case _:
            raise ValueError("invalid certificate")


def check(data):
    g, a, p = data
    require(type(g) is list)
    g = [subst(b, (0,), formula=True) for b in g]
    require(infer(p, g) == subst(a, (0,), formula=True))
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
