"""A complete small proof checker for intuitionistic primitive recursive arithmetic.

Terms are ('v', i), ('0',), ('s', t), and ('r', counter, initial, body).
The recursor body binds state at index 0 and counter at index 1. Its outer
variables have their indices increased by two. Formula tags are '=', 'bot',
'and', 'or', 'imp', 'all', and 'ex'; quantifier bodies bind index 0.

The public entry point is check(scope, context, conclusion, certificate).
It accepts ordinary tuples or JSON lists and rejects malformed input. The
context is a finite sequence; order and duplicate assumptions are immaterial.
The syntax helpers below operate on already validated immutable syntax.

Certificate forms (p, q, r are child certificates; i is exactly 0 or 1):
  ('hyp',)                  claimed formula occurs in the context
  ('ax',)                   either (0 = S0) -> bottom or bottom -> (0 = S0)
  ('r0',), ('rs',)          defining equation recognized from the claim
  ('and_i', p, q)           conjunction introduction
  ('and_e', i, F, p)        project component i of conjunction F
  ('or_i', i, p)            introduce component i of the claimed disjunction
  ('or_e', F, p, q, r)      cases on disjunction F
  ('imp_i', p)             implication introduction
  ('imp_e', B, p, q)        p proves B -> conclusion; q proves B
  ('all_i', p)              generalize a fresh scoped variable
  ('all_e', B, t, p)        instantiate universally quantified body B at t
  ('ex_i', t, p)            existential introduction with witness t
  ('ex_e', B, p, q)         eliminate existential body B, with fresh witness
  ('eq_e', s, t, B, p, q)   substitute in formula template B, slot 0
  ('sp', E, t, p)           rooted successor progress for equation template E

Quantifier bodies and the templates B and E have one additional free slot.
Reflexivity, weakening, and general falsity elimination are derived.
Computation equations are explicit; there is no conversion or normalization.
No part of an input certificate is executed as Python code.
"""

ZERO = ('0',)
BOT = ('bot',)
DELTA = ('=', ZERO, ('s', ZERO))


def _freeze(value):
    """Accept only finite trees of exact built-in containers and scalar types."""
    if type(value) in (tuple, list):
        return tuple(_freeze(item) for item in value)
    if type(value) in (str, int):
        return value
    raise TypeError('certificates contain only lists, tuples, strings, and integers')


def _node(value):
    return type(value) is tuple and bool(value) and type(value[0]) is str


def term(scope, value):
    """Check term syntax and every variable scope, including recursor bodies."""
    if not _node(value):
        return False
    tag = value[0]
    if tag == 'v':
        return len(value) == 2 and type(value[1]) is int and 0 <= value[1] < scope
    if tag == '0':
        return len(value) == 1
    if tag == 's':
        return len(value) == 2 and term(scope, value[1])
    if tag == 'r':
        return (len(value) == 4 and term(scope, value[1])
                and term(scope, value[2]) and term(scope + 2, value[3]))
    return False


def formula(scope, value):
    """Check the complete, unrestricted first-order formula grammar."""
    if not _node(value):
        return False
    tag = value[0]
    if tag == '=':
        return len(value) == 3 and term(scope, value[1]) and term(scope, value[2])
    if tag == 'bot':
        return len(value) == 1
    if tag in ('and', 'or', 'imp'):
        return (len(value) == 3 and formula(scope, value[1])
                and formula(scope, value[2]))
    if tag in ('all', 'ex'):
        return len(value) == 2 and formula(scope + 1, value[1])
    return False


def _walk(value, variable, depth=0):
    """One binder-aware traversal shared by lifting and substitution."""
    tag = value[0]
    if tag == 'v':
        return variable(value[1], depth)
    if tag == 'r':
        return (tag, _walk(value[1], variable, depth),
                _walk(value[2], variable, depth),
                _walk(value[3], variable, depth + 2))
    if tag in ('all', 'ex'):
        return (tag, _walk(value[1], variable, depth + 1))
    return (tag,) + tuple(_walk(child, variable, depth) for child in value[1:])


def shift(value, amount, cutoff=0):
    """Lift outer variable indices at or above cutoff; respect every binder."""
    return _walk(value, lambda i, depth:
                 ('v', i + amount if i >= depth + cutoff else i))


def instantiate(body, replacements):
    """Simultaneously replace and remove the first k outer variable slots.

    A replacement is lifted beneath binders and is not revisited. Slots
    beyond the replaced prefix are decreased by k. In particular, a
    recursor computation supplies (previous_state, predecessor_counter).
    """
    count = len(replacements)

    def variable(index, depth):
        if index < depth:
            return ('v', index)
        slot = index - depth
        if slot < count:
            return shift(replacements[slot], depth)
        return ('v', index - count)

    return _walk(body, variable)


def _lift_context(context):
    return tuple(shift(assumption, 1) for assumption in context)


def _side(index):
    return type(index) is int and index in (0, 1)


def _check(scope, context, claim, proof):
    """Check a rule after the ambient formulas have been validated."""
    if not _node(proof):
        return False
    rule = proof[0]
    if rule == 'hyp' and len(proof) == 1:
        return claim in context
    if rule == 'ax' and len(proof) == 1:
        return claim in (('imp', DELTA, BOT), ('imp', BOT, DELTA))
    if rule in ('r0', 'rs') and len(proof) == 1:
        if claim[0] != '=' or claim[1][0] != 'r':
            return False
        _, counter, initial, body = claim[1]
        if rule == 'r0':
            return counter == ZERO and claim[2] == initial
        if counter[0] != 's':
            return False
        previous = ('r', counter[1], initial, body)
        return claim[2] == instantiate(body, (previous, counter[1]))
    if rule == 'and_i' and len(proof) == 3:
        return (claim[0] == 'and'
                and _check(scope, context, claim[1], proof[1])
                and _check(scope, context, claim[2], proof[2]))
    if rule == 'and_e' and len(proof) == 4:
        index, source, premise = proof[1:]
        return (_side(index) and formula(scope, source) and source[0] == 'and'
                and claim == source[index + 1]
                and _check(scope, context, source, premise))
    if rule == 'or_i' and len(proof) == 3:
        return (claim[0] == 'or' and _side(proof[1])
                and _check(scope, context, claim[proof[1] + 1], proof[2]))
    if rule == 'or_e' and len(proof) == 5:
        source, major, left, right = proof[1:]
        return (formula(scope, source) and source[0] == 'or'
                and _check(scope, context, source, major)
                and _check(scope, context + (source[1],), claim, left)
                and _check(scope, context + (source[2],), claim, right))
    if rule == 'imp_i' and len(proof) == 2:
        return (claim[0] == 'imp'
                and _check(scope, context + (claim[1],), claim[2], proof[1]))
    if rule == 'imp_e' and len(proof) == 4:
        antecedent, major, minor = proof[1:]
        return (formula(scope, antecedent)
                and _check(scope, context, ('imp', antecedent, claim), major)
                and _check(scope, context, antecedent, minor))
    if rule == 'all_i' and len(proof) == 2:
        return (claim[0] == 'all'
                and _check(scope + 1, _lift_context(context), claim[1], proof[1]))
    if rule == 'all_e' and len(proof) == 4:
        body, witness, premise = proof[1:]
        return (formula(scope + 1, body) and term(scope, witness)
                and claim == instantiate(body, (witness,))
                and _check(scope, context, ('all', body), premise))
    if rule == 'ex_i' and len(proof) == 3:
        witness, premise = proof[1:]
        return (claim[0] == 'ex' and term(scope, witness)
                and _check(scope, context, instantiate(claim[1], (witness,)), premise))
    if rule == 'ex_e' and len(proof) == 4:
        body, major, minor = proof[1:]
        return (formula(scope + 1, body)
                and _check(scope, context, ('ex', body), major)
                and _check(scope + 1, _lift_context(context) + (body,),
                           shift(claim, 1), minor))
    if rule == 'eq_e' and len(proof) == 6:
        left, right, body, equality, premise = proof[1:]
        return (term(scope, left) and term(scope, right) and formula(scope + 1, body)
                and claim == instantiate(body, (right,))
                and _check(scope, context, ('=', left, right), equality)
                and _check(scope, context, instantiate(body, (left,)), premise))
    if rule == 'sp' and len(proof) == 4:
        equation, target, premise = proof[1:]
        if not (formula(scope + 1, equation) and equation[0] == '='
                and term(scope, target)):
            return False
        conclusion = ('or', ('=', target, ZERO), instantiate(equation, (target,)))
        rooted = ('or', ('=', ('v', 0), ZERO), equation)
        # Lift parameters, then remove the template slot: parameters stay fixed.
        step = instantiate(shift(equation, 1, cutoff=1), (('s', ('v', 0)),))
        return (claim == conclusion
                and _check(scope + 1, _lift_context(context) + (rooted,), step, premise))
    return False


def check(scope, context, conclusion, certificate):
    """Validate an untrusted finite certificate, returning exactly True or False.

    Booleans are not accepted as integer indices. Unknown tags, wrong
    arities, ill-scoped syntax, cyclic containers, and resource exceptions
    fail closed. Python recursion and memory bounds still limit proof size.
    """
    try:
        if type(scope) is not int or scope < 0:
            return False
        context = _freeze(context)
        conclusion = _freeze(conclusion)
        certificate = _freeze(certificate)
        return (type(context) is tuple and all(formula(scope, a) for a in context)
                and formula(scope, conclusion)
                and _check(scope, context, conclusion, certificate))
    except (TypeError, ValueError, IndexError, RecursionError, OverflowError, MemoryError):
        return False
