"""Complete iPRA checker using one finite-prefix substitution operation.

Public falsity is represented by 0 = S0. The report proves faithful
full-sequent encoding and ordinary first-order bi-interpretability.
All validation, axiom construction and certificate checking is here.
"""

import json
import sys

ZERO = -1


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def wf(a, formula=False):
    match a:
        case int() if type(a) is int:
            return not formula and a >= -1
        case ["s", t]:
            return not formula and wf(t)
        case ["r", n, t, h]:
            return not formula and wf(n) and wf(t) and wf(h)
        case ["=", s, t]:
            return formula and wf(s) and wf(t)
        case [("pi" | "sig"), a, b]:
            return formula and wf(a, True) and wf(b, True)
        case _:
            return False


def sub(a, terms=(), drop=0, depth=0):
    if type(a) is int:
        if a < depth:
            return a
        i = a - depth
        return sub(terms[i], (), -depth) if i < len(terms) else a - drop
    return [a[0], *(sub(b, terms, drop,
                       depth + (2 if a[0] == "r" and i == 2 else
                                1 if a[0] in ("pi", "sig") else 0))
                    for i, b in enumerate(a[1:]))]


def shift(a, n=1):
    return sub(a, (), -n)


def inst(a, t):
    return sub(a, [t], 1)


def infer(p, g):
    match p:
        case ["hyp", key]:
            return g[g.index(key)]
        case ["pi", a, q]:
            require(wf(a, True))
            return ["pi", a, infer(q, [*map(shift, g), a])]
        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            require(wf(a, tag != "pi"))
            if tag == "sig":
                require(infer(q, [*map(shift, g), *e[1:]]) == shift(a))
                return a
            b, c = (inst(a, t) if tag == "=" else inst(t, a) for t in e[1:])
            require(infer(q, g) == b)
            return c
        case ["pair", t, p, q]:
            require(wf(t))
            h = [*map(shift, g), ["=", 0, shift(t)]]
            return ["sig", infer(p, h), infer(q, h)]
        case ["rec", ["r", n, a, h] as r]:
            require(wf(r))
            if n == ZERO:
                b = a
            else:
                require(type(n) is list and n[0] == "s")
                b = sub(h, [["r", n[1], a, h], n[1]], 2)
            return ["=", r, b]
        case ["nat", a]:
            require(wf(a, True))
            base = inst(a, ZERO)
            h = a if a[0] == "=" else shift(base)
            step = ["pi", h, sub(a, [["s", 0]])]
            return ["pi", ["sig", shift(base, 2), shift(step, 2)], a]
        case _:
            raise ValueError("invalid certificate")


def erase(a):
    if a == ["false"]:
        return ["=", ZERO, ["s", ZERO]]
    return list(map(erase, a)) if type(a) is list else a


def check(data):
    g, a, p = erase(data)
    require(type(g) is list and all(wf(b, True) for b in g) and wf(a, True))
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
