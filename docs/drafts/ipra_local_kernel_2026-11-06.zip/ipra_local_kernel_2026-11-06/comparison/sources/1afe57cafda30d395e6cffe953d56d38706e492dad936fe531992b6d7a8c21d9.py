"""The same arithmetic with ordinary intuitionistic first-order logical constructors."""

from common import Arithmetic, map_term, node, term


class Checker(Arithmetic):
    def formula(self, value, scope):
        if node(value, "=", 3):
            return term(value[1], scope) and term(value[2], scope)
        if node(value, "bot", 1):
            return True
        if type(value) is list and len(value) == 3 and value[0] in ("and", "or", "imp"):
            return self.formula(value[1], scope) and self.formula(value[2], scope)
        if type(value) is list and len(value) == 2 and value[0] in ("all", "ex"):
            return self.formula(value[1], scope + 1)
        return False

    def map_formula(self, value, variable, depth=0):
        if value[0] == "=":
            return ["=", map_term(value[1], variable, depth),
                    map_term(value[2], variable, depth)]
        if value[0] == "bot":
            return ["bot"]
        if value[0] in ("all", "ex"):
            return [value[0], self.map_formula(value[1], variable, depth + 1)]
        return [value[0], self.map_formula(value[1], variable, depth),
                self.map_formula(value[2], variable, depth)]

    def zero_or(self, value, equation):
        return ["or", ["=", value, ["0"]], equation]

    def separation(self):
        return ["imp", ["=", ["0"], ["s", ["0"]]], ["bot"]]

    def logic(self, scope, context, conclusion, proof):
        tag = proof[0]
        if tag == "and_i" and len(proof) == 3 and node(conclusion, "and", 3):
            return (self._check(scope, context, conclusion[1], proof[1])
                    and self._check(scope, context, conclusion[2], proof[2]))
        if tag in ("and_l", "and_r") and len(proof) == 3:
            source, source_proof = proof[1:]
            index = 1 if tag == "and_l" else 2
            return (node(source, "and", 3) and self.formula(source, scope)
                    and conclusion == source[index]
                    and self._check(scope, context, source, source_proof))
        if tag in ("or_l", "or_r") and len(proof) == 2 and node(conclusion, "or", 3):
            index = 1 if tag == "or_l" else 2
            return self._check(scope, context, conclusion[index], proof[1])
        if tag == "or_e" and len(proof) == 5:
            source, source_proof, left, right = proof[1:]
            return (node(source, "or", 3) and self.formula(source, scope)
                    and self._check(scope, context, source, source_proof)
                    and self._check(scope, context + [source[1]], conclusion, left)
                    and self._check(scope, context + [source[2]], conclusion, right))
        if tag == "imp_i" and len(proof) == 2 and node(conclusion, "imp", 3):
            return self._check(scope, context + [conclusion[1]], conclusion[2], proof[1])
        if tag == "imp_e" and len(proof) == 4:
            source, source_proof, argument = proof[1:]
            return (node(source, "imp", 3) and self.formula(source, scope)
                    and conclusion == source[2]
                    and self._check(scope, context, source, source_proof)
                    and self._check(scope, context, source[1], argument))
        if tag == "all_i" and len(proof) == 2 and node(conclusion, "all", 2):
            return self._check(scope + 1, self.lifted_context(context, 1),
                               conclusion[1], proof[1])
        if tag == "all_e" and len(proof) == 4:
            source, witness, source_proof = proof[1:]
            return (node(source, "all", 2) and self.formula(source, scope)
                    and term(witness, scope)
                    and conclusion == self.instantiate(source[1], [witness])
                    and self._check(scope, context, source, source_proof))
        if tag == "ex_i" and len(proof) == 3 and node(conclusion, "ex", 2):
            witness, argument = proof[1:]
            return (term(witness, scope)
                    and self._check(scope, context, self.instantiate(conclusion[1], [witness]),
                                    argument))
        if tag == "ex_e" and len(proof) == 4:
            source, source_proof, branch = proof[1:]
            return (node(source, "ex", 2) and self.formula(source, scope)
                    and self._check(scope, context, source, source_proof)
                    and self._check(scope + 1, self.lifted_context(context, 1) + [source[1]],
                                    self.lift(conclusion, 1), branch))
        if tag == "absurd" and len(proof) == 2:
            return self._check(scope, context, ["bot"], proof[1])
        return False


check = Checker().check
