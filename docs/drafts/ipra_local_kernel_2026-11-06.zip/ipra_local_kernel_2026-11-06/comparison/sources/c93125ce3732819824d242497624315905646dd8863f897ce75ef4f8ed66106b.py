"""Complete iPRA certificate checker. See report.pdf for the full theory.

Falsity has the explicit arithmetic conversion bottom = (0 = S0).
The six proof records share elimination and use witness equations.
Only finite JSON is input; no proof generator is trusted.
"""

import json
import sys

ZERO = -1


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def wf(a, formula=False):
    if type(a) is int:
        return not formula and a >= -1
    require(type(a) is list)
    tag, *args = a
    return (formula == (tag not in ("s", "r"))
            and len(args) == {"s": 1, "r": 3, "=": 2, "pi": 2, "sig": 2}[tag]
            and all(wf(b, tag in ("pi", "sig")) for b in args))


def subst(a, env=(1,), d=0):
    if type(a) is int:
        i = a - d
        return a if i < 0 else subst(env[i], (d,)) if i < len(env) - 1 else a + env[-1]
    return [a[0], *(subst(b, env, d + (2 if a[0] == "r" and i == 2 else
                                    1 if a[0] in ("pi", "sig") else 0))
                    for i, b in enumerate(a[1:]))]


def infer(p, g):
    match p:
        case ["hyp", key]:
            return g[g.index(key)]
        case ["pi", a, q]:
            require(wf(a, True))
            return ["pi", a, infer(q, [*map(subst, g), a])]
        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            require(wf(a, tag != "pi"))
            if tag == "sig":
                require(infer(q, [*map(subst, g), *e[1:]]) == subst(a))
                return a
            b, c = (subst(a, [t, -1]) if tag == "=" else subst(t, [a, -1]) for t in e[1:])
            require(infer(q, g) == b)
            return c
        case ["pair", t, p, q]:
            require(wf(t))
            h = [*map(subst, g), ["=", 0, subst(t)]]
            return ["sig", infer(p, h), infer(q, h)]
        case ["rec", ["r", n, a, h] as r]:
            require(wf(r))
            if n == ZERO:
                b = a
            else:
                require(type(n) is list and n[0] == "s")
                b = subst(h, [["r", n[1], a, h], n[1], -2])
            return ["=", r, b]
        case ["nat", a]:
            require(wf(a, True))
            base = subst(subst(a, [ZERO, -1]))
            h = a if a[0] == "=" else base
            step = ["pi", h, subst(a, [["s", 0], 0])]
            return ["pi", base, ["pi", subst(step, (2,)), subst(a)]]
        case _:
            raise ValueError("invalid certificate")


def erase(a):
    if a == ["false"]:
        return ["=", ZERO, ["s", ZERO]]
    return list(map(erase, a)) if type(a) is list else a


def check(data):
    g, a, p = erase(data)
    require(type(g) is list and all(wf(b, True) for b in g) and wf(a, True))
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
