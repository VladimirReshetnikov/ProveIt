"""Complete certificate checker for a finite-recursion presentation of iPRA.

Finite tuple syntax, de Bruijn number variables, and native recursion binders.
This file is the trusted mathematical kernel; it uses no imported libraries.
The JSON command-line adapter and proof-generating helpers are separate.
"""


class Invalid(ValueError):
    pass


GRAMMAR = {
    "0": ("t", ()),
    "s": ("t", (("t", 0),)),
    "r": ("t", (("t", 0), ("t", 0), ("t", 2))),
    "=": ("f", (("t", 0), ("t", 0))),
    "!": ("f", ()),
    "&": ("f", (("f", 0), ("f", 0))),
    ">": ("f", (("f", 0), ("f", 0))),
    "A": ("f", (("f", 1),)),
    "E": ("f", (("f", 1),)),
}
ZERO = ("0",)
FALSE = ("!",)


def require(condition):
    if not condition:
        raise Invalid("invalid certificate")


def wellformed(a, sort, scope):
    if type(a) is not tuple or not a or type(a[0]) is not str:
        return False
    if a[0] == "v":
        return (sort == "t" and len(a) == 2 and type(a[1]) is int
                and 0 <= a[1] < scope)
    spec = GRAMMAR.get(a[0])
    return bool(spec and spec[0] == sort and len(a) == 1 + len(spec[1])
                and all(wellformed(b, s, scope + k)
                        for b, (s, k) in zip(a[1:], spec[1])))


def variables(a, action, depth=0):
    if a[0] == "v":
        return action(a[1], depth)
    return (a[0],) + tuple(variables(b, action, depth + k)
                          for b, (_, k) in zip(a[1:], GRAMMAR[a[0]][1]))


def shift(a, amount=1):
    return variables(a, lambda i, d: ("v", i + amount if i >= d else i))


def substitute(a, terms, drop=True):
    def action(i, depth):
        j = i - depth
        if 0 <= j < len(terms):
            return shift(terms[j], depth)
        return ("v", i - len(terms) if drop and j >= len(terms) else i)
    return variables(a, action)


def zero_test(t):
    return ("=", t, ZERO)


def guard(equation, term):
    return (">", (">", zero_test(term), FALSE), equation)


def encode(a, scope):
    """Translate an ordinary claimed formula, charging disjunction expansion."""
    require(type(a) is tuple and a and type(a[0]) is str)
    if a[0] == "|":
        require(len(a) == 3)
        left, right = (shift(encode(b, scope)) for b in a[1:])
        p = zero_test(("v", 0))
        a = ("E", ("&", (">", p, left), (">", (">", p, FALSE), right)))
    elif a[0] in ("&", ">", "A", "E"):
        require(len(a) == 1 + len(GRAMMAR[a[0]][1]))
        a = (a[0],) + tuple(encode(b, scope + k)
                            for b, (_, k) in zip(a[1:], GRAMMAR[a[0]][1]))
    require(wellformed(a, "f", scope))
    return a


def infer(proof, context=(), scope=0):
    """Infer a conclusion; callers use check() to validate external inputs."""
    require(type(proof) is tuple and proof)
    match proof:
        case ("h", i):
            require(type(i) is int and 0 <= i < len(context))
            return context[i]
        case ("=", t):
            require(wellformed(t, "t", scope))
            return ("=", t, t)
        case ("rep", formula, equality, premise):
            require(wellformed(formula, "f", scope + 1))
            e = infer(equality, context, scope)
            require(e[0] == "=" and
                    infer(premise, context, scope) == substitute(formula, (e[1],)))
            return substitute(formula, (e[2],))
        case ("&i", left, right):
            return ("&", infer(left, context, scope), infer(right, context, scope))
        case ("&e", i, premise):
            require(type(i) is int and i in (0, 1))
            a = infer(premise, context, scope)
            require(a[0] == "&")
            return a[i + 1]
        case (">i", assumption, premise):
            require(wellformed(assumption, "f", scope))
            return (">", assumption, infer(premise, (assumption,) + context, scope))
        case (">e", implication, premise):
            a = infer(implication, context, scope)
            require(a[0] == ">" and infer(premise, context, scope) == a[1])
            return a[2]
        case ("Ai", premise):
            return ("A", infer(premise, tuple(shift(a) for a in context), scope + 1))
        case ("Ae", term, premise):
            require(wellformed(term, "t", scope))
            a = infer(premise, context, scope)
            require(a[0] == "A")
            return substitute(a[1], (term,))
        case ("Ei", formula, term, premise):
            require(wellformed(formula, "f", scope + 1)
                    and wellformed(term, "t", scope))
            require(infer(premise, context, scope) == substitute(formula, (term,)))
            return ("E", formula)
        case ("Ee", conclusion, existence, premise):
            require(wellformed(conclusion, "f", scope))
            a = infer(existence, context, scope)
            require(a[0] == "E")
            lifted = tuple(shift(b) for b in context)
            require(infer(premise, (a[1],) + lifted, scope + 1) == shift(conclusion))
            return conclusion
        case ("sep",):
            return (">", ("=", ZERO, ("s", ZERO)), FALSE)
        case ("!e", conclusion, premise):
            require(wellformed(conclusion, "f", scope)
                    and infer(premise, context, scope) == FALSE)
            return conclusion
        case ("rec", term):
            require(wellformed(term, "t", scope) and term[0] == "r")
            _, counter, initial, body = term
            if counter == ZERO:
                return ("=", term, initial)
            require(counter[0] == "s")
            n = counter[1]
            return ("=", term, substitute(body, (("r", n, initial, body), n)))
        case ("zc", term, zero_branch, other_branch):
            require(wellformed(term, "t", scope))
            a = zero_test(term)
            c = infer(zero_branch, (a,) + context, scope)
            require(infer(other_branch, ((">", a, FALSE),) + context, scope) == c)
            return c
        case ("ind", equation, term, premise):
            require(wellformed(equation, "f", scope + 1) and equation[0] == "="
                    and wellformed(term, "t", scope))
            x = ("v", 0)
            lifted = tuple(shift(a) for a in context)
            expected = substitute(equation, (("s", x),), drop=False)
            require(infer(premise, (guard(equation, x),) + lifted, scope + 1) == expected)
            return guard(substitute(equation, (term,)), term)
        case _:
            raise Invalid("unknown or malformed rule")


def check(proof, conclusion, context=(), scope=0):
    """Check a first-order claim against a finite proof certificate."""
    try:
        require(type(scope) is int and scope >= 0 and type(context) is tuple)
        conclusion = encode(conclusion, scope)
        context = tuple(encode(a, scope) for a in context)
        return infer(proof, context, scope) == conclusion
    except (Invalid, TypeError, ValueError, KeyError, IndexError, RecursionError):
        return False
