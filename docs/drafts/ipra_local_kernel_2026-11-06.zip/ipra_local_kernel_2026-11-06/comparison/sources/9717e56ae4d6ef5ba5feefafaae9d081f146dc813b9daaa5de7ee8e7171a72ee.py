"""Comparison checker: ordinary full intuitionistic natural deduction.

The numerical language, equality, disjunction, falsity, separation,
substitution, input validation, and rooted equation rule are shared.
Formula constructors: eq, false, or, and, imp, all, some.
"""

from common import Base, ZERO, ONE, FALSE, natural, require, run


class Kernel(Base):
    binary = {"or", "and", "imp"}
    binders = {"all": 1, "some": 1}
    separation = ["imp", ["eq", ZERO, ONE], FALSE]

    def logical(self, proof, context, goal):
        match proof:
            case ["and_intro", left, right]:
                require(goal[0] == "and")
                self.check(left, context, goal[1])
                self.check(right, context, goal[2])
            case ["and_elim", side, conjunction, premise]:
                self.formula(conjunction)
                require(conjunction[0] == "and" and natural(side) and side < 2)
                require(goal == conjunction[side + 1])
                self.check(premise, context, conjunction)
            case ["imp_intro", premise]:
                require(goal[0] == "imp")
                self.check(premise, context + [goal[1]], goal[2])
            case ["imp_elim", antecedent, premise, argument]:
                self.formula(antecedent)
                self.check(premise, context, ["imp", antecedent, goal])
                self.check(argument, context, antecedent)
            case ["all_intro", name, premise]:
                require(goal[0] == "all")
                self.fresh(name, context + [goal])
                instance = self.substitute(goal[2], goal[1], ["v", name])
                self.check(premise, context, instance)
            case ["all_elim", universal, term, premise]:
                self.formula(universal)
                self.term(term)
                require(universal[0] == "all")
                require(goal == self.substitute(universal[2], universal[1], term))
                self.check(premise, context, universal)
            case ["some_intro", term, premise]:
                require(goal[0] == "some")
                self.term(term)
                self.check(premise, context,
                           self.substitute(goal[2], goal[1], term))
            case ["some_elim", existential, name, premise, continuation]:
                self.formula(existential)
                require(existential[0] == "some")
                self.fresh(name, context + [goal, existential])
                instance = self.substitute(existential[2], existential[1],
                                           ["v", name])
                self.check(premise, context, existential)
                self.check(continuation, context + [instance], goal)
            case _:
                require(False)


if __name__ == "__main__":
    raise SystemExit(run(Kernel))
