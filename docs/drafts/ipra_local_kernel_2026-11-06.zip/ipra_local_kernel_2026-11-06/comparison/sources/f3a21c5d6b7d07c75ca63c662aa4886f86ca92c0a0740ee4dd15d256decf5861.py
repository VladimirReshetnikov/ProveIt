"""Complete reflexivity-free Hilbert checker for full first-order iPRA."""

from syntax import (BOT, Eq, Imp, Or, All, Ex, need, typed, arguments,
                    lift, inst, previous)
from arithmetic import arithmetic


def axiom(tag, args):
    if tag == "p":
        need(len(args) == 4)
        i, a, b, c = args
        need(type(i) is int and 0 <= i < 9)
        arguments((a, b, c), "fff")
        schemas = (
            Imp(a, Imp(b, a)),
            Imp(Imp(a, Imp(b, c)), Imp(Imp(a, b), Imp(a, c))),
            Imp(a, Imp(b, ("&", a, b))),
            Imp(("&", a, b), a),
            Imp(("&", a, b), b),
            Imp(a, Or(a, b)),
            Imp(b, Or(a, b)),
            Imp(Imp(a, c), Imp(Imp(b, c), Imp(Or(a, b), c))),
            Imp(BOT, a),
        )
        return schemas[i]
    if tag in ("ui", "ei"):
        arguments(args, "ft")
        a, t = args
        return Imp(All(a), inst(a, t)) if tag == "ui" else Imp(inst(a, t), Ex(a))
    if tag in ("ud", "ed"):
        arguments(args, "ff")
        a, b = args
        if tag == "ud":
            return Imp(All(Imp(lift(a), b)), Imp(a, All(b)))
        return Imp(All(Imp(a, lift(b))), Imp(Ex(a), b))
    if tag == "eq":
        arguments(args, "ttf")
        s, t, a = args
        return Imp(Eq(s, t), Imp(inst(a, s), inst(a, t)))
    if tag == "refl":
        arguments(args, "t")
        return Eq(args[0], args[0])
    return arithmetic(tag, args)


def check(proof, goal):
    typed(goal, "f")
    need(type(proof) is tuple and len(proof) > 0)
    proved = []
    for record in proof:
        need(type(record) is tuple and len(record) > 0)
        tag, args = record[0], record[1:]
        need(type(tag) is str)
        if tag == "mp":
            need(len(args) == 2)
            major, minor = (previous(proved, i) for i in args)
            need(major[0] == ">" and major[1] == minor)
            result = major[2]
        elif tag == "gen":
            need(len(args) == 1)
            result = All(previous(proved, args[0]))
        else:
            result = axiom(tag, args)
        proved.append(result)
    need(proved[-1] == goal)
    return goal
