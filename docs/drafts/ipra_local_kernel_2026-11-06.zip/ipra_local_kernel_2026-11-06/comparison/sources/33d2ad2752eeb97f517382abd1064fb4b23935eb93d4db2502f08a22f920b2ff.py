"""Complete iPRA certificate checker. See report.pdf for the full theory.

Falsity has the explicit arithmetic conversion bottom = (0 = S0).
The six proof records share elimination and use witness equations.
Only finite JSON is input; no proof generator is trusted.
"""

import json
import sys

ZERO = -1


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


SCOPES = {"s": (0,), "r": (0, 0, 2), "=": (0, 0),
          "pi": (1, 1), "ex": (1,)}


def subst(a, env=(1,), d=0, formula=None):
    if type(a) is int:
        require(formula is not True and a >= -1)
        i = a - d
        return a if i < 0 else subst(env[i], (d,)) if i < len(env) - 1 else a + env[-1]
    require(type(a) is list)
    tag, *args = a
    require(formula is None or (tag not in ("s", "r")) == formula)
    return [tag, *(subst(b, env, d + width, width == 1)
                   for b, width in zip(args, SCOPES[tag], strict=True))]


def infer(p, g):
    match p:
        case ["hyp", key]:
            subst(key, formula=True)
            return g[g.index(key)]
        case ["pi", a, q]:
            subst(a, formula=True)
            return ["pi", a, infer(q, [*map(subst, g), a])]
        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            subst(a, formula=tag != "pi")
            if tag == "ex":
                require(infer(q, [*map(subst, g), *e[1:]]) == subst(a))
                return a
            b, c = (subst(a, [t, -1]) if tag == "=" else subst(t, [a, -1]) for t in e[1:])
            require(infer(q, g) == b)
            return c
        case ["pack", t, p]:
            h = [*map(subst, g), ["=", 0, subst(t, formula=False)]]
            return ["ex", infer(p, h)]
        case ["rec", ["r", n, a, h] as r]:
            subst(r)
            if n == ZERO:
                b = a
            else:
                require(type(n) is list and n[0] == "s")
                b = subst(h, [["r", n[1], a, h], n[1], -2])
            return ["=", r, b]
        case ["nat", a]:
            base = subst(a, [ZERO, 0], formula=True)
            h = a if a[0] == "=" else base
            step = ["pi", h, subst(a, [["s", 0], 0])]
            return ["pi", base, ["pi", subst(step, (2,)), subst(a)]]
        case _:
            raise ValueError("invalid certificate")


def erase(a):
    if a == ["false"]:
        return ["=", ZERO, ["s", ZERO]]
    return list(map(erase, a)) if type(a) is list else a


def check(data):
    g, a, p = erase(data)
    require(type(g) is list)
    for b in [*g, a]:
        subst(b, formula=True)
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
