"""The complete shared syntax/scoping layer. Indices are de Bruijn indices."""

Z = ("z",)
BOT = ("F",)


def need(condition):
    if not condition:
        raise ValueError("invalid certificate")


def S(t):
    return ("s", t)


def Eq(s, t):
    return ("=", s, t)


def Imp(a, b):
    return (">", a, b)


def Or(a, b):
    return ("|", a, b)


def All(a):
    return ("@", a)


def Ex(a):
    return ("?", a)


def sort(e, bound=None):
    """Validate the entire tree; bound=None permits any free parameter."""
    if type(e) is int:
        need(e >= 0 and (bound is None or e < bound))
        return "t"
    need(type(e) is tuple and len(e) > 0 and type(e[0]) is str)
    tag, args = e[0], e[1:]
    if tag == "r":
        need(len(args) >= 3)
        need(sort(args[0], len(args) - 1) == "t")
        need(all(sort(t, bound) == "t" for t in args[1:]))
        return "t"
    signatures = {
        "z": ("t", ""), "s": ("t", "t"), "F": ("f", ""),
        "=": ("f", "tt"), "&": ("f", "ff"), "|": ("f", "ff"),
        ">": ("f", "ff"), "@": ("f", "f"), "?": ("f", "f"),
    }
    need(tag in signatures)
    result, inputs = signatures[tag]
    need(len(args) == len(inputs))
    scope = bound + 1 if bound is not None and tag in ("@", "?") else bound
    need(all(sort(a, scope) == k for a, k in zip(args, inputs)))
    return result


def typed(e, kind):
    need(sort(e) == kind)


def arguments(args, kinds):
    need(len(args) == len(kinds))
    for a, k in zip(args, kinds):
        typed(a, k)


def sub(e, env):
    """Simultaneously substitute active variables; recursor labels are frozen."""
    if type(e) is int:
        return env(e)
    tag = e[0]
    if tag in ("@", "?"):
        inside = lambda i: 0 if i == 0 else lift(env(i - 1))
        return (tag, sub(e[1], inside))
    if tag == "r":
        return (tag, e[1], *(sub(a, env) for a in e[2:]))
    return (tag, *(sub(a, env) for a in e[1:]))


def lift(e):
    return sub(e, lambda i: i + 1)


def inst(e, t):
    return sub(e, lambda i: t if i == 0 else i - 1)


def freeze(e):
    return tuple(freeze(x) for x in e) if type(e) is list else e


def previous(proved, i):
    need(type(i) is int and 0 <= i < len(proved))
    return proved[i]
