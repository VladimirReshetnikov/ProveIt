"""A small first-order iPRA Hilbert certificate checker.

Terms: ["v", i], ["0"], ["S", t], ["R", h, n, a, *parameters].
The frozen update h uses local slots 0=state, 1=counter, 2,...=parameters.
Formulas: ["=", s, t], ["and"|"or"|"imp", A, B], ["all"|"ex", i, A].
A document has exactly "goal" and "proof"; proof is a list of theorem records.
Only modus ponens and universal generalization use previously proved lines.
No normalization, proof search, arithmetic evaluation, or semantic test is used.
"""

import json
import sys


FALSITY = ["=", ["0"], ["S", ["0"]]]


class Invalid(Exception):
    pass


def require(condition):
    if not condition:
        raise Invalid


def natural(value):
    return type(value) is int and value >= 0


def term(node, bound=None):
    match node:
        case ["v", index]:
            return natural(index) and (bound is None or index < bound)
        case ["0"]:
            return True
        case ["S", value]:
            return term(value, bound)
        case ["R", update, counter, initial, *parameters]:
            return term(update, len(parameters) + 2) and all(
                term(value, bound) for value in [counter, initial, *parameters]
            )
    return False


def formula(node):
    match node:
        case ["=", left, right]:
            return term(left) and term(right)
        case [("and" | "or" | "imp"), left, right]:
            return formula(left) and formula(right)
        case [("all" | "ex"), variable, body]:
            return natural(variable) and formula(body)
    return False


def free(node):
    match node:
        case ["v", variable]:
            return {variable}
        case ["R", update, *arguments]:
            return set().union(*(free(value) for value in arguments))
        case [("all" | "ex"), variable, body]:
            return free(body) - {variable}
    return set().union(*(free(value) for value in node[1:]))


def substitute(node, replacements):
    """Simultaneous free substitution; reject capture; leave labels frozen."""
    tag = node[0]
    if tag == "v":
        return replacements.get(node[1], node)
    if tag == "R":
        return [tag, node[1], *(substitute(t, replacements) for t in node[2:])]
    if tag in ("all", "ex"):
        variable, body = node[1:]
        active = {
            key: value for key, value in replacements.items()
            if key != variable and key in free(body)
        }
        require(all(variable not in free(value) for value in active.values()))
        return [tag, variable, substitute(body, active)]
    return [tag, *(substitute(t, replacements) for t in node[1:])]


def implies(left, right):
    return ["imp", left, right]


def earlier(theorems, index):
    require(natural(index) and index < len(theorems))
    return theorems[index]


def infer(record, theorems):
    """Return the theorem licensed by a record, or raise Invalid."""
    match record:
        case ["logic", index, a, b, c]:
            require(natural(index) and index < 8 and all(map(formula, [a, b, c])))
            conjunction, disjunction = ["and", a, b], ["or", a, b]
            schemes = [
                implies(a, implies(b, a)),
                implies(implies(a, implies(b, c)),
                        implies(implies(a, b), implies(a, c))),
                implies(a, implies(b, conjunction)),
                implies(conjunction, a),
                implies(conjunction, b),
                implies(a, disjunction),
                implies(b, disjunction),
                implies(implies(a, c),
                        implies(implies(b, c), implies(disjunction, c))),
            ]
            return schemes[index]
        case ["forall_elim", variable, body, value]:
            require(natural(variable) and formula(body) and term(value))
            return implies(["all", variable, body], substitute(body, {variable: value}))
        case ["forall_shift", variable, a, b]:
            require(natural(variable) and formula(a) and formula(b))
            require(variable not in free(a))
            return implies(["all", variable, implies(a, b)],
                           implies(a, ["all", variable, b]))
        case ["exists_intro", variable, body, value]:
            require(natural(variable) and formula(body) and term(value))
            return implies(substitute(body, {variable: value}), ["ex", variable, body])
        case ["exists_shift", variable, a, b]:
            require(natural(variable) and formula(a) and formula(b))
            require(variable not in free(b))
            return implies(["all", variable, implies(a, b)],
                           implies(["ex", variable, a], b))
        case ["equality", variable, template, left, right]:
            require(natural(variable) and formula(template) and term(left) and term(right))
            source = substitute(template, {variable: left})
            target = substitute(template, {variable: right})
            return implies(["=", left, right], implies(source, target))
        case ["compute", call]:
            require(term(call) and call[0] == "R")
            update, counter, initial, *parameters = call[1:]
            if counter[0] == "0":
                value = initial
            else:
                require(counter[0] == "S")
                previous = ["R", update, counter[1], initial, *parameters]
                slots = [previous, counter[1], *parameters]
                value = substitute(update, dict(enumerate(slots)))
            return ["=", call, value]
        case ["closure", variable, equation]:
            require(natural(variable) and formula(equation) and equation[0] == "=")
            number = ["v", variable]
            boundary = ["or", ["=", number, ["0"]], equation]
            successor = substitute(equation, {variable: ["S", number]})
            return implies(["all", variable, implies(boundary, successor)],
                           ["all", variable, boundary])
        case ["mp", function, argument]:
            implication = earlier(theorems, function)
            require(implication[0] == "imp")
            require(implication[1] == earlier(theorems, argument))
            return implication[2]
        case ["gen", variable, premise]:
            require(natural(variable))
            return ["all", variable, earlier(theorems, premise)]
    raise Invalid


def check(document):
    try:
        require(type(document) is dict and set(document) == {"goal", "proof"})
        require(formula(document["goal"]) and type(document["proof"]) is list)
        theorems = []
        for record in document["proof"]:
            theorems.append(infer(record, theorems))
        return bool(theorems) and theorems[-1] == document["goal"]
    except (Invalid, RecursionError):
        return False


if __name__ == "__main__":
    try:
        accepted = check(json.load(sys.stdin))
    except (ValueError, RecursionError):
        accepted = False
    print("ACCEPT" if accepted else "REJECT")
    sys.exit(0 if accepted else 1)


