"""Complete iPRA kernel with open scopes and a closed falsity bridge.

All nonnegative integer variables are legal. Binding shifts the ambient
context; finite support replaces an explicit outer arity. Pi and Sigma
bind one number in both children; r binds state 0 and counter 1 in h.
The bridge exchanges genuine falsity with the equation 0=S0. The nat
rule supplies an induction hypothesis only when its template is an equation.
"""

import json
import sys

ZERO = -1
FALSE = ("false",)
CLASH = ("=", ZERO, ("s", ZERO))


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def wf(a, formula=False):
    match a:
        case int() if type(a) is int:
            return not formula and a >= -1
        case ("s", t):
            return not formula and wf(t)
        case ("r", n, t, h):
            return not formula and wf(n) and wf(t) and wf(h)
        case ("=", s, t):
            return formula and wf(s) and wf(t)
        case ("false",):
            return formula
        case (("pi" | "sig"), a, b):
            return formula and wf(a, True) and wf(b, True)
        case _:
            return False


def walk(a, f, d=0):
    if type(a) is int:
        return a if a < d else f(a - d, d)
    return (a[0], *(walk(b, f, d + (2 if a[0] == "r" and i == 2 else
                                  1 if a[0] in ("pi", "sig") else 0))
                    for i, b in enumerate(a[1:])))


def shift(a, n=1):
    return walk(a, lambda i, d: i + d + n)


def subst(a, env):
    return walk(a, lambda i, d: shift(env(i), d))


def inst(a, t):
    return subst(a, lambda i: t if i == 0 else i - 1)


def infer(p, g):
    match p:
        case ("hyp", i):
            require(type(i) is int and 0 <= i < len(g))
            return g[i]
        case ("pi", a, q):
            require(wf(a, True))
            return ("pi", a, infer(q, (*map(shift, g), a)))
        case ("app", p, t, q):
            a = infer(p, g)
            require(a[0] == "pi" and wf(t))
            require(infer(q, g) == inst(a[1], t))
            return inst(a[2], t)
        case ("pair", a, t, p, q):
            require(wf(a, True) and a[0] == "sig" and wf(t))
            require(infer(p, g) == inst(a[1], t))
            require(infer(q, g) == inst(a[2], t))
            return a
        case ("let", p, c, q):
            a = infer(p, g)
            require(a[0] == "sig" and wf(c, True))
            require(infer(q, (*map(shift, g), a[1], a[2])) == shift(c))
            return c
        case ("bridge", p):
            return {FALSE: CLASH, CLASH: FALSE}[infer(p, g)]
        case ("eq", p, a, q):
            e = infer(p, g)
            require(e[0] == "=" and wf(a, True))
            require(infer(q, g) == inst(a, e[1]))
            return inst(a, e[2])
        case ("rec", ("r", n, a, h) as r):
            require(wf(r))
            if n == ZERO:
                b = a
            else:
                require(type(n) is tuple and n[0] == "s")
                b = subst(h, lambda i: (("r", n[1], a, h), n[1])[i]
                          if i < 2 else i - 2)
            return ("=", r, b)
        case ("nat", a, t, p, q):
            require(wf(a, True) and wf(t))
            require(infer(p, g) == inst(a, ZERO))
            h = (a,) if a[0] == "=" else ()
            successor = subst(a, lambda i: ("s", 0) if i == 0 else i)
            require(infer(q, (*map(shift, g), *h)) == successor)
            return inst(a, t)
        case _:
            raise ValueError("invalid certificate")


def freeze(a):
    return tuple(map(freeze, a)) if type(a) is list else a


def check(data):
    require(type(data) is dict and set(data) == {"assumptions", "goal", "proof"})
    require(type(data["assumptions"]) is list)
    g = tuple(map(freeze, data["assumptions"]))
    a, p = freeze(data["goal"]), freeze(data["proof"])
    require(all(wf(b, True) for b in g) and wf(a, True))
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
