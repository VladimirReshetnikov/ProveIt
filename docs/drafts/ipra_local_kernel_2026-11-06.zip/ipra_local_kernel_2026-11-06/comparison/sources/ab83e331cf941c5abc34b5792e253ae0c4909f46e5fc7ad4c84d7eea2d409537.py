"""Usage: python3 run.py matrix|kernel|baseline certificate.json"""

import json
import importlib
import sys


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] not in ("matrix", "kernel", "baseline"):
        raise SystemExit("Usage: python3 run.py matrix|kernel|baseline certificate.json")
    try:
        with open(sys.argv[2], encoding="utf-8") as stream:
            record = json.load(stream)
        if type(record) is not dict or set(record) != {"scope", "context", "conclusion", "proof"}:
            raise ValueError("Expected exactly scope, context, conclusion, proof")
        accepted = importlib.import_module(sys.argv[1]).check(**record)
    except (OSError, ValueError, TypeError, RecursionError) as error:
        raise SystemExit("Invalid input: " + str(error))
    print("ACCEPT" if accepted else "REJECT")
    raise SystemExit(0 if accepted else 1)
