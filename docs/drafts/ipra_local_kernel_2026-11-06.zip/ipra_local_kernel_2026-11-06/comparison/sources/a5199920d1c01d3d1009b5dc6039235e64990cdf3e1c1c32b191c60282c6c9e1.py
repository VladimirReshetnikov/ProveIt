"""iPRA with one universal/implication and one existential/disjunction constructor."""

from common import Arithmetic, map_term, natural, node, term


class Checker(Arithmetic):
    def formula(self, value, scope):
        if node(value, "=", 3):
            return term(value[1], scope) and term(value[2], scope)
        if node(value, "P", 4):
            _, count, premises, conclusion = value
            return (natural(count) and type(premises) is list
                    and all(self.formula(item, scope + count) for item in premises)
                    and self.formula(conclusion, scope + count))
        if node(value, "D", 2) and type(value[1]) is list:
            return all(type(branch) is list and len(branch) == 2
                       and natural(branch[0]) and type(branch[1]) is list
                       and all(self.formula(item, scope + branch[0]) for item in branch[1])
                       for branch in value[1])
        return False

    def map_formula(self, value, variable, depth=0):
        if value[0] == "=":
            return ["=", map_term(value[1], variable, depth),
                    map_term(value[2], variable, depth)]
        if value[0] == "P":
            _, count, premises, conclusion = value
            return ["P", count, [self.map_formula(item, variable, depth + count)
                                 for item in premises],
                    self.map_formula(conclusion, variable, depth + count)]
        return ["D", [[count, [self.map_formula(item, variable, depth + count)
                               for item in premises]] for count, premises in value[1]]]

    def zero_or(self, value, equation):
        return ["D", [[0, [["=", value, ["0"]]]], [0, [equation]]]]

    def separation(self):
        return ["P", 0, [["=", ["0"], ["s", ["0"]]]], ["D", []]]

    def logic(self, scope, context, conclusion, proof):
        tag = proof[0]
        if tag == "PI" and len(proof) == 2 and node(conclusion, "P", 4):
            _, count, premises, result = conclusion
            return self._check(scope + count, self.lifted_context(context, count) + premises,
                               result, proof[1])
        if tag == "PE" and len(proof) == 5:
            source, witnesses, source_proof, arguments = proof[1:]
            if not (node(source, "P", 4) and self.formula(source, scope)
                    and type(witnesses) is list and len(witnesses) == source[1]
                    and all(term(witness, scope) for witness in witnesses)
                    and type(arguments) is list and len(arguments) == len(source[2])):
                return False
            return (conclusion == self.instantiate(source[3], witnesses)
                    and self._check(scope, context, source, source_proof)
                    and all(self._check(scope, context, self.instantiate(item, witnesses), part)
                            for item, part in zip(source[2], arguments)))
        if tag == "DI" and len(proof) == 4 and node(conclusion, "D", 2):
            index, witnesses, arguments = proof[1:]
            if not (natural(index) and index < len(conclusion[1])):
                return False
            count, premises = conclusion[1][index]
            return (type(witnesses) is list and len(witnesses) == count
                    and all(term(witness, scope) for witness in witnesses)
                    and type(arguments) is list and len(arguments) == len(premises)
                    and all(self._check(scope, context, self.instantiate(item, witnesses), part)
                            for item, part in zip(premises, arguments)))
        if tag == "DE" and len(proof) == 4:
            source, source_proof, branches = proof[1:]
            return (node(source, "D", 2) and self.formula(source, scope)
                    and type(branches) is list and len(branches) == len(source[1])
                    and self._check(scope, context, source, source_proof)
                    and all(self._check(scope + count,
                                        self.lifted_context(context, count) + premises,
                                        self.lift(conclusion, count), part)
                            for (count, premises), part in zip(source[1], branches)))
        return False


check = Checker().check
