"""A first-order arithmetic Hilbert proof checker; Python 3.10 or later.

Only this module is the mathematical checking kernel. Inputs are finite tuple
trees; JSON conversion, proof construction, and tests are separate utilities.
Free variables are strings, bound variables are de Bruijn indices. A recursor
descriptor is frozen syntax with local slots 0=value, 1=counter, 2+=parameters.
"""

ZERO = ("0",)


class InvalidProof(ValueError):
    pass


def require(condition, message="invalid proof"):
    if not condition:
        raise InvalidProof(message)


def name(value):
    return isinstance(value, str) and bool(value)


def term(value, depth=0, free=True):
    if isinstance(value, str):
        return free and bool(value)
    if type(value) is int:
        return 0 <= value < depth
    if not isinstance(value, tuple) or not value:
        return False
    if value == ZERO:
        return True
    if len(value) == 2 and value[0] == "S":
        return term(value[1], depth, free)
    if len(value) == 5 and value[0] == "R":
        _, body, counter, initial, parameters = value
        return (isinstance(parameters, tuple)
                and term(body, len(parameters) + 2, False)
                and all(term(t, depth, free)
                        for t in (counter, initial, *parameters)))
    return False


def formula(value, depth=0):
    if not isinstance(value, tuple) or not value:
        return False
    if value == ("bot",):
        return True
    if len(value) == 3 and value[0] == "=":
        return term(value[1], depth) and term(value[2], depth)
    if len(value) == 3 and value[0] in ("&", "|", ">"):
        return formula(value[1], depth) and formula(value[2], depth)
    if len(value) == 2 and value[0] in ("all", "ex"):
        return formula(value[1], depth + 1)
    return False


def map_term(value, visit):
    if isinstance(value, str) or type(value) is int:
        return visit(value)
    if value == ZERO:
        return value
    if value[0] == "S":
        return ("S", map_term(value[1], visit))
    _, body, counter, initial, parameters = value
    return ("R", body, map_term(counter, visit), map_term(initial, visit),
            tuple(map_term(t, visit) for t in parameters))


def map_formula(value, visit, depth=0):
    tag = value[0]
    if tag == "bot":
        return value
    if tag == "=":
        return (tag, *(map_term(t, lambda v: visit(v, depth)) for t in value[1:]))
    if tag in ("&", "|", ">"):
        return (tag, *(map_formula(a, visit, depth) for a in value[1:]))
    return (tag, map_formula(value[1], visit, depth + 1))


def free_names(value):
    found = set()

    def collect(variable, depth):
        if isinstance(variable, str):
            found.add(variable)
        return variable

    map_formula(value, collect)
    return found


def substitute(value, variable, replacement):
    return map_formula(value, lambda v, d: replacement if v == variable else v)


def bind(tag, variable, value):
    return (tag, map_formula(value, lambda v, d: d if v == variable else v))


def instantiate(body, replacement):
    # replacement is a well-formed term at depth zero, so it has no active
    # de Bruijn indices to shift. Frozen descriptors are never traversed.
    def replace(variable, depth):
        if type(variable) is not int or variable < depth:
            return variable
        return replacement if variable == depth else variable - 1

    return map_formula(body, replace)


def implication(left, right):
    return (">", left, right)


# Each pair is (number of formula metavariables, template).
PROPOSITIONAL = (
    (2, (">", 0, (">", 1, 0))),
    (3, (">", (">", 0, (">", 1, 2)), (">", (">", 0, 1), (">", 0, 2)))),
    (2, (">", 0, (">", 1, ("&", 0, 1)))),
    (2, (">", ("&", 0, 1), 0)),
    (2, (">", ("&", 0, 1), 1)),
    (2, (">", 0, ("|", 0, 1))),
    (2, (">", 1, ("|", 0, 1))),
    (3, (">", (">", 0, 2), (">", (">", 1, 2), (">", ("|", 0, 1), 2)))),
    (0, ("&", (">", ("=", ZERO, ("S", ZERO)), ("bot",)),
         (">", ("bot",), ("=", ZERO, ("S", ZERO))))),
)


def template_instance(pattern, arguments):
    if type(pattern) is int:
        return arguments[pattern]
    return (pattern[0], *(template_instance(p, arguments) for p in pattern[1:]))


def infer(step, previous):
    require(isinstance(step, tuple) and step and name(step[0]))
    tag = step[0]

    def arguments(length):
        require(len(step) == length + 1, "wrong proof-constructor arity")
        return step[1:]

    def reference(index):
        require(type(index) is int and 0 <= index < len(previous),
                "reference must be an earlier line")
        return previous[index]

    if tag == "prop":
        index, values = arguments(2)
        require(type(index) is int and 0 <= index < len(PROPOSITIONAL))
        arity, pattern = PROPOSITIONAL[index]
        require(isinstance(values, tuple) and len(values) == arity)
        require(all(formula(a) for a in values), "invalid formula instance")
        return template_instance(pattern, values)
    if tag == "mp":
        first, second = arguments(2)
        arrow, antecedent = reference(first), reference(second)
        require(arrow[0] == ">" and arrow[1] == antecedent, "modus ponens mismatch")
        return arrow[2]
    if tag == "gen":
        index, variable = arguments(2)
        require(name(variable))
        return bind("all", variable, reference(index))
    if tag in ("all_e", "ex_i"):
        quantified, witness = arguments(2)
        expected = "all" if tag == "all_e" else "ex"
        require(formula(quantified) and quantified[0] == expected and term(witness))
        instance = instantiate(quantified[1], witness)
        return (implication(quantified, instance) if tag == "all_e"
                else implication(instance, quantified))
    if tag in ("all_shift", "ex_shift"):
        variable, left, right = arguments(3)
        require(name(variable) and formula(left) and formula(right))
        fixed = left if tag == "all_shift" else right
        require(variable not in free_names(fixed), "quantifier side condition")
        premise = bind("all", variable, implication(left, right))
        conclusion = (implication(left, bind("all", variable, right))
                      if tag == "all_shift"
                      else implication(bind("ex", variable, left), right))
        return implication(premise, conclusion)
    if tag == "eq":
        left, right, pattern, variable = arguments(4)
        require(term(left) and term(right) and formula(pattern) and name(variable))
        return implication(("=", left, right), implication(
            substitute(pattern, variable, left), substitute(pattern, variable, right)))
    if tag in ("r0", "rs"):
        (call,) = arguments(1)
        require(term(call) and isinstance(call, tuple) and call[0] == "R")
        _, body, counter, initial, parameters = call
        if tag == "r0":
            require(counter == ZERO, "base equation needs counter zero")
            result = initial
        else:
            require(isinstance(counter, tuple) and counter[0] == "S",
                    "step equation needs a successor counter")
            old = counter[1]
            values = (("R", body, old, initial, parameters), old, *parameters)
            result = map_term(body, lambda slot: values[slot])
        return ("=", call, result)
    if tag == "sc":
        variable, equation = arguments(2)
        require(name(variable) and formula(equation) and equation[0] == "=")
        guard = ("|", ("=", variable, ZERO), equation)
        step_equation = substitute(equation, variable, ("S", variable))
        return implication(bind("all", variable, implication(guard, step_equation)),
                           bind("all", variable, guard))
    raise InvalidProof("unknown proof constructor")


def check(lines, expected=None):
    require(isinstance(lines, (tuple, list)) and bool(lines), "empty or invalid proof")
    if expected is not None:
        require(formula(expected), "invalid expected conclusion")
    previous = []
    for number, step in enumerate(lines):
        try:
            conclusion = infer(step, previous)
            require(formula(conclusion), "ill-formed inferred conclusion")
        except (InvalidProof, TypeError, IndexError, KeyError, RecursionError) as error:
            raise InvalidProof(f"line {number}: {error}") from error
        previous.append(conclusion)
    require(expected is None or previous[-1] == expected, "wrong final conclusion")
    return previous[-1]
