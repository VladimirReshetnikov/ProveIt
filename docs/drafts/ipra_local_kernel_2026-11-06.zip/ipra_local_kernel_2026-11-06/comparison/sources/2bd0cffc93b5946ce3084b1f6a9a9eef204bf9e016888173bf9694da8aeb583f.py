"""Complete goal-directed natural-deduction baseline for the raw draft core."""

from syntax import (BOT, Eq, Imp, Or, All, Ex, need, typed, arguments,
                    lift, inst, previous)
from arithmetic import arithmetic


def derive(proof, goal, context):
    typed(goal, "f")
    need(type(proof) is tuple and len(proof) > 0)
    tag, args = proof[0], proof[1:]
    need(type(tag) is str)
    if tag == "ax":
        need(len(args) > 0 and type(args[0]) is str)
        need(goal == arithmetic(args[0], args[1:]))
        return
    arities = {"hyp": 1, "refl": 0, "pair": 2, "left": 1, "right": 1,
               "lam": 1, "all": 1, "exists": 2, "false": 1, "app": 3,
               "fst": 2, "snd": 2, "cases": 5, "inst": 3,
               "choose": 3, "subst": 5}
    need(tag in arities and len(args) == arities[tag])
    if tag == "hyp":
        need(goal == previous(context, args[0]))
    elif tag == "refl":
        need(goal[0] == "=" and goal[1] == goal[2])
    elif tag == "pair":
        need(goal[0] == "&")
        for p, g in zip(args, goal[1:]):
            derive(p, g, context)
    elif tag in ("left", "right"):
        need(goal[0] == "|")
        derive(args[0], goal[1 if tag == "left" else 2], context)
    elif tag == "lam":
        need(goal[0] == ">")
        derive(args[0], goal[2], context + (goal[1],))
    elif tag == "all":
        need(goal[0] == "@")
        derive(args[0], goal[1], tuple(map(lift, context)))
    elif tag == "exists":
        need(goal[0] == "?")
        typed(args[0], "t")
        derive(args[1], inst(goal[1], args[0]), context)
    elif tag == "false":
        derive(args[0], BOT, context)
    elif tag == "app":
        a, p, q = args
        typed(a, "f")
        derive(p, Imp(a, goal), context)
        derive(q, a, context)
    elif tag in ("fst", "snd"):
        a, p = args
        typed(a, "f")
        pair = ("&", goal, a) if tag == "fst" else ("&", a, goal)
        derive(p, pair, context)
    elif tag == "cases":
        a, b, p, q, r = args
        arguments((a, b), "ff")
        derive(p, Or(a, b), context)
        derive(q, goal, context + (a,))
        derive(r, goal, context + (b,))
    elif tag == "inst":
        a, t, p = args
        arguments((a, t), "ft")
        need(goal == inst(a, t))
        derive(p, All(a), context)
    elif tag == "choose":
        a, p, q = args
        typed(a, "f")
        derive(p, Ex(a), context)
        derive(q, lift(goal), tuple(map(lift, context)) + (a,))
    elif tag == "subst":
        s, t, a, p, q = args
        arguments((s, t, a), "ttf")
        need(goal == inst(a, t))
        derive(p, Eq(s, t), context)
        derive(q, inst(a, s), context)


def check(proof, goal):
    derive(proof, goal, ())
    return goal
