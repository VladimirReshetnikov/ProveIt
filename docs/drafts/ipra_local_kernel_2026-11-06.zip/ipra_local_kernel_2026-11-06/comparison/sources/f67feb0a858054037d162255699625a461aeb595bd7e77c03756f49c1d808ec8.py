"""Complete iPRA checker with unary existentials and one typed traversal.

The traversal validates syntax, substitutes a finite prefix, and expands
public falsity to 0 = S0. No certificate producer is trusted.
"""

import json
import sys

ZERO = -1
SCOPES = {"s": (0,), "r": (0, 0, 2), "=": (0, 0),
          "pi": (1, 1), "ex": (1,)}


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def walk(a, env=(1,), d=0, formula=None):
    if a == ["false"]:
        a = ["=", ZERO, ["s", ZERO]]
    if type(a) is int:
        require(not formula and a >= -1)
        i = a - d
        return a if i < 0 else walk(env[i], (d,)) if i < len(env) - 1 else a + env[-1]
    require(type(a) is list)
    tag, *args = a
    require(formula is None or formula == (tag not in ("s", "r")))
    return [tag, *(walk(b, env, d + width, width == 1)
                   for b, width in zip(args, SCOPES[tag], strict=True))]


def infer(p, g):
    match p:
        case ["hyp", key]:
            return g[g.index(walk(key, (0,), formula=True))]
        case ["pi", a, q]:
            a = walk(a, (0,), formula=True)
            return ["pi", a, infer(q, [*map(walk, g), a])]
        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            a = walk(a, (0,), formula=tag != "pi")
            if tag == "ex":
                require(infer(q, [*map(walk, g), *e[1:]]) == walk(a))
                return a
            b, c = (walk(a, [t, -1]) if tag == "=" else walk(t, [a, -1]) for t in e[1:])
            require(infer(q, g) == b)
            return c
        case ["pack", t, p]:
            walk(t, (0,), formula=False)
            h = [*map(walk, g), ["=", 0, walk(t)]]
            return ["ex", infer(p, h)]
        case ["rec", ["r", n, a, h] as r]:
            walk(r, (0,), formula=False)
            if n == ZERO:
                b = a
            else:
                require(n[0] == "s")
                b = walk(h, [["r", n[1], a, h], n[1], -2])
            return ["=", r, b]
        case ["nat", a]:
            a = walk(a, (0,), formula=True)
            base = walk(a, [ZERO, 0])
            h = a if a[0] == "=" else base
            step = ["pi", h, walk(a, [["s", 0], 0])]
            return ["pi", base, ["pi", walk(step, (2,)), walk(a)]]
        case _:
            raise ValueError("invalid certificate")


def check(data):
    g, a, p = data
    require(type(g) is list)
    g = [walk(b, (0,), formula=True) for b in g]
    a = walk(a, (0,), formula=True)
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
