"""Complete iPRA verifier with genuine falsity and combined proof reductions.

Nonnegative integers are variables; -1 is the number zero. Pi and Sigma
bind one number in both formulas; r binds state and counter in its body.
The use record is principal-directed. Pair branches carry a fresh witness
equation. Nat supplies a numerical axiom; only equations receive induction.
"""

import json
import sys

ZERO = -1
FALSE = ["false"]
CLASH = ["=", ZERO, ["s", ZERO]]


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def wf(a, formula=False):
    match a:
        case int() if type(a) is int:
            return not formula and a >= -1
        case ("s", t):
            return not formula and wf(t)
        case ("r", n, t, h):
            return not formula and wf(n) and wf(t) and wf(h)
        case ("=", s, t):
            return formula and wf(s) and wf(t)
        case ("false",):
            return formula
        case (("pi" | "sig"), a, b):
            return formula and wf(a, True) and wf(b, True)
        case _:
            return False


def walk(a, f, d=0):
    if type(a) is int:
        return a if a < d else f(a - d, d)
    return [a[0], *(walk(b, f, d + (2 if a[0] == "r" and i == 2 else
                                  1 if a[0] in ("pi", "sig") else 0))
                    for i, b in enumerate(a[1:]))]


def shift(a, n=1):
    return walk(a, lambda i, d: i + d + n)


def subst(a, env):
    return walk(a, lambda i, d: shift(env(i), d))


def inst(a, t):
    return subst(a, lambda i: t if i == 0 else i - 1)


def infer(p, g):
    match p:
        case ("hyp", a):
            return g[g.index(a)]
        case ("pi", a, q):
            require(wf(a, True))
            return ["pi", a, infer(q, [*map(shift, g), a])]
        case ("app", p, t, q):
            a = infer(p, g)
            require(a[0] == "pi" and wf(t))
            require(infer(q, g) == inst(a[1], t))
            return inst(a[2], t)
        case ("let", p, c, q):
            a = infer(p, g)
            require(a[0] == "sig" and wf(c, True))
            require(infer(q, [*map(shift, g), a[1], a[2]]) == shift(c))
            return c
        case ("eq", p, a, q):
            e = infer(p, g)
            require(e[0] == "=" and wf(a, True))
            require(infer(q, g) == inst(a, e[1]))
            return inst(a, e[2])
        case ("pair", t, p, q):
            require(wf(t))
            h = [*map(shift, g), ["=", 0, shift(t)]]
            return ["sig", infer(p, h), infer(q, h)]
        case ("bridge", p):
            return [CLASH, FALSE][[FALSE, CLASH].index(infer(p, g))]
        case ("rec", ("r", n, a, h) as r):
            require(wf(r))
            if n == ZERO:
                b = a
            else:
                require(type(n) is list and n[0] == "s")
                b = subst(h, lambda i: (["r", n[1], a, h], n[1])[i]
                          if i < 2 else i - 2)
            return ["=", r, b]
        case ("nat", a):
            require(wf(a, True))
            base = shift(inst(a, ZERO))
            h = a if a[0] == "=" else base
            successor = subst(a, lambda i: ["s", 0] if i == 0 else i)
            step = ["pi", h, successor]
            return ["pi", base, ["pi", shift(step, 2), shift(a)]]
        case _:
            raise ValueError("invalid certificate")


def check(data):
    require(type(data) is dict and set(data) == {"assumptions", "goal", "proof"})
    g, a, p = (data[k] for k in ("assumptions", "goal", "proof"))
    require(type(g) is list and all(wf(b, True) for b in g) and wf(a, True))
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
