"""Complete four-constructor formula checker for intuitionistic PRA.

JSON input has arity, assumptions, goal, proof. Variables are de Bruijn
indices. Native r binds state 0 and counter 1 in its last child; pi and
sig bind index 0 in both children. Rejecting malformed input is mandatory.
Genuine falsity is retained. The bridge axiom gives 0=Sx implies bottom
and bottom implies x=0; generic explosion is derived, not primitive.
The nat rule permits an induction hypothesis exactly for equations and
otherwise performs zero/successor cases. rec checks both computation clauses;
reflexivity is also derived.
"""

import json
import sys

ZERO = ("z",)
FALSE = ("false",)


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def wf(a, d, formula=False):
    match a:
        case int() if type(a) is int:
            return not formula and 0 <= a < d
        case ("z",):
            return not formula
        case ("s", t):
            return not formula and wf(t, d)
        case ("r", n, t, h):
            return not formula and wf(n, d) and wf(t, d) and wf(h, d + 2)
        case ("=", s, t):
            return formula and wf(s, d) and wf(t, d)
        case ("false",):
            return formula
        case (("pi" | "sig"), a, b):
            return formula and wf(a, d + 1, True) and wf(b, d + 1, True)
        case _:
            return False


def walk(a, f, d=0):
    if type(a) is int:
        return a if a < d else f(a - d, d)
    return (a[0], *(walk(b, f, d + (2 if a[0] == "r" and i == 2 else
                                  1 if a[0] in ("pi", "sig") else 0))
                    for i, b in enumerate(a[1:])))


def shift(a, n=1):
    return walk(a, lambda i, d: i + d + n)


def subst(a, env):
    return walk(a, lambda i, d: shift(env(i), d))


def inst(a, t):
    return subst(a, lambda i: t if i == 0 else i - 1)


def infer(p, d, g):
    match p:
        case ("hyp", i):
            require(type(i) is int and 0 <= i < len(g))
            return g[i]
        case ("pi", a, q):
            require(wf(a, d + 1, True))
            return ("pi", a, infer(q, d + 1, (*map(shift, g), a)))
        case ("app", p, t, q):
            a = infer(p, d, g)
            require(a[0] == "pi" and wf(t, d))
            require(infer(q, d, g) == inst(a[1], t))
            return inst(a[2], t)
        case ("pair", a, t, p, q):
            require(wf(a, d, True) and a[0] == "sig" and wf(t, d))
            require(infer(p, d, g) == inst(a[1], t))
            require(infer(q, d, g) == inst(a[2], t))
            return a
        case ("let", p, c, q):
            a = infer(p, d, g)
            require(a[0] == "sig" and wf(c, d, True))
            require(infer(q, d + 1, (*map(shift, g), a[1], a[2])) == shift(c))
            return c
        case ("bridge",):
            return ("sig", ("pi", ("=", ZERO, ("s", 0)), FALSE), ("pi", FALSE, ("=", 0, ZERO)))
        case ("eq", p, a, q):
            e = infer(p, d, g)
            require(e[0] == "=" and wf(a, d + 1, True))
            require(infer(q, d, g) == inst(a, e[1]))
            return inst(a, e[2])
        case ("rec", r):
            require(wf(r, d) and type(r) is tuple and r[0] == "r")
            _, n, a, h = r
            if n == ZERO:
                b = a
            else:
                require(type(n) is tuple and n[0] == "s")
                b = subst(h, lambda i: (("r", n[1], a, h), n[1])[i]
                          if i < 2 else i - 2)
            return ("=", r, b)
        case ("nat", a, t, p, q):
            require(wf(a, d + 1, True) and wf(t, d))
            require(infer(p, d, g) == inst(a, ZERO))
            h = (a,) if a[0] == "=" else ()
            successor = subst(a, lambda i: ("s", 0) if i == 0 else i)
            require(infer(q, d + 1, (*map(shift, g), *h)) == successor)
            return inst(a, t)
        case _:
            raise ValueError("invalid certificate")


def freeze(a):
    return tuple(map(freeze, a)) if type(a) is list else a


def check(data):
    require(type(data) is dict and set(data) == {"arity", "assumptions", "goal", "proof"})
    d = data["arity"]
    require(type(d) is int and d >= 0 and type(data["assumptions"]) is list)
    g = tuple(map(freeze, data["assumptions"]))
    a, p = freeze(data["goal"]), freeze(data["proof"])
    require(all(wf(b, d, True) for b in g) and wf(a, d, True))
    require(infer(p, d, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
