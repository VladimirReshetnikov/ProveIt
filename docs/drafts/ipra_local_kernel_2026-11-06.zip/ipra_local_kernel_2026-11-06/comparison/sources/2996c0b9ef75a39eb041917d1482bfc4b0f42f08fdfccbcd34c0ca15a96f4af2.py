"""Full-connective natural deduction with two elementary kernel reductions.

JSON input has arity, assumptions, goal, proof. Native r binds state 0
and counter 1 in its last child; all/ex bind index 0 in their body.
The arithmetic rule is the drafts' rooted successor rule for equations.
"""

import json
import sys

ZERO = ("z",)
FALSE = ("false",)
CONTRADICTION = ("=", ZERO, ("s", ZERO))


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def wf(a, d, formula=False):
    match a:
        case int() if type(a) is int:
            return not formula and 0 <= a < d
        case ("z",):
            return not formula
        case ("s", t):
            return not formula and wf(t, d)
        case ("r", n, t, h):
            return not formula and wf(n, d) and wf(t, d) and wf(h, d + 2)
        case ("=", s, t):
            return formula and wf(s, d) and wf(t, d)
        case ("false",):
            return formula
        case (("&" | "|" | "->"), a, b):
            return formula and wf(a, d, True) and wf(b, d, True)
        case (("all" | "ex"), a):
            return formula and wf(a, d + 1, True)
        case _:
            return False


def walk(a, f, d=0):
    if type(a) is int:
        return a if a < d else f(a - d, d)
    return (a[0], *(walk(b, f, d + (2 if a[0] == "r" and i == 2 else
                                  1 if a[0] in ("all", "ex") else 0))
                    for i, b in enumerate(a[1:])))


def shift(a, n=1):
    return walk(a, lambda i, d: i + d + n)


def subst(a, env):
    return walk(a, lambda i, d: shift(env(i), d))


def inst(a, t):
    return subst(a, lambda i: t if i == 0 else i - 1)


def infer(p, d, g):
    match p:
        case ("hyp", i):
            require(type(i) is int and 0 <= i < len(g))
            return g[i]
        case ("and", p, q):
            return ("&", infer(p, d, g), infer(q, d, g))
        case ("proj", i, p):
            a = infer(p, d, g)
            require(a[0] == "&" and type(i) is int and 0 <= i <= 1)
            return a[i + 1]
        case ("in", a, i, p):
            require(wf(a, d, True) and a[0] == "|"
                    and type(i) is int and 0 <= i <= 1)
            require(infer(p, d, g) == a[i + 1])
            return a
        case ("case", p, q, r):
            a = infer(p, d, g)
            require(a[0] == "|")
            b = infer(q, d, (*g, a[1]))
            require(infer(r, d, (*g, a[2])) == b)
            return b
        case ("imp", a, p):
            require(wf(a, d, True))
            return ("->", a, infer(p, d, (*g, a)))
        case ("app", p, q):
            a = infer(p, d, g)
            require(a[0] == "->" and infer(q, d, g) == a[1])
            return a[2]
        case ("all", p):
            return ("all", infer(p, d + 1, tuple(map(shift, g))))
        case ("spec", p, t):
            a = infer(p, d, g)
            require(a[0] == "all" and wf(t, d))
            return inst(a[1], t)
        case ("exists", a, t, p):
            require(wf(a, d, True) and a[0] == "ex" and wf(t, d))
            require(infer(p, d, g) == inst(a[1], t))
            return a
        case ("let", p, c, q):
            a = infer(p, d, g)
            require(a[0] == "ex" and wf(c, d, True))
            require(infer(q, d + 1, (*map(shift, g), a[1])) == shift(c))
            return c
        case ("abort", p, a):
            require(wf(a, d, True) and infer(p, d, g) in (FALSE, CONTRADICTION))
            return a
        case ("eq", p, a, q):
            e = infer(p, d, g)
            require(e[0] == "=" and wf(a, d + 1, True))
            require(infer(q, d, g) == inst(a, e[1]))
            return inst(a, e[2])
        case ("rec", r):
            require(wf(r, d) and type(r) is tuple and r[0] == "r")
            _, n, a, h = r
            if n == ZERO:
                b = a
            else:
                require(type(n) is tuple and n[0] == "s")
                b = subst(h, lambda i: (("r", n[1], a, h), n[1])[i]
                          if i < 2 else i - 2)
            return ("=", r, b)
        case ("sc", e, t, p):
            require(wf(e, d + 1, True) and e[0] == "=" and wf(t, d))
            guard = ("|", ("=", 0, ZERO), e)
            successor = subst(e, lambda i: ("s", 0) if i == 0 else i)
            require(infer(p, d + 1, (*map(shift, g), guard)) == successor)
            return ("|", ("=", t, ZERO), inst(e, t))
        case _:
            raise ValueError("invalid certificate")


def freeze(a):
    return tuple(map(freeze, a)) if type(a) is list else a


def check(data):
    require(type(data) is dict and set(data) == {"arity", "assumptions", "goal", "proof"})
    d = data["arity"]
    require(type(d) is int and d >= 0 and type(data["assumptions"]) is list)
    g = tuple(map(freeze, data["assumptions"]))
    a, p = freeze(data["goal"]), freeze(data["proof"])
    require(all(wf(b, d, True) for b in g) and wf(a, d, True))
    require(infer(p, d, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
