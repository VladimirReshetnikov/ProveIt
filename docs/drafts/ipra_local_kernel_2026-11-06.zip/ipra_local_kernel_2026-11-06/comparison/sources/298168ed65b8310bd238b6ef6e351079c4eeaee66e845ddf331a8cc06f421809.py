"""Shared finite syntax and arithmetic for the two iPRA proof checkers."""


def natural(value):
    return type(value) is int and value >= 0


def node(value, tag, length):
    return type(value) is list and len(value) == length and value[0] == tag


def term(value, scope):
    if natural(value):
        return value < scope
    if node(value, "0", 1):
        return True
    if node(value, "s", 2):
        return term(value[1], scope)
    if node(value, "r", 4):
        return (term(value[1], scope) and term(value[2], scope)
                and term(value[3], scope + 2))
    return False


def map_term(value, variable, depth=0):
    if type(value) is int:
        return value if value < depth else lift_term(variable(value - depth), depth)
    if value[0] == "0":
        return ["0"]
    if value[0] == "s":
        return ["s", map_term(value[1], variable, depth)]
    return ["r", map_term(value[1], variable, depth),
            map_term(value[2], variable, depth),
            map_term(value[3], variable, depth + 2)]


def lift_term(value, amount):
    return value if amount == 0 else map_term(value, lambda index: index + amount)


def replacement(values):
    return lambda index: values[index] if index < len(values) else index - len(values)


def instantiate_term(value, values):
    return map_term(value, replacement(values))


class Arithmetic:
    """The subclasses supply formula syntax and their logical rule cases."""

    def lift(self, formula, amount):
        return self.map_formula(formula, lambda index: index + amount)

    def instantiate(self, formula, values):
        return self.map_formula(formula, replacement(values))

    def lifted_context(self, context, amount):
        return [self.lift(formula, amount) for formula in context]

    def check(self, scope, context, conclusion, proof):
        try:
            return (natural(scope) and type(context) is list
                    and all(self.formula(formula, scope) for formula in context)
                    and self.formula(conclusion, scope)
                    and self._check(scope, context, conclusion, proof))
        except (IndexError, KeyError, TypeError, ValueError, RecursionError):
            return False

    def _check(self, scope, context, conclusion, proof):
        if not (type(proof) is list and proof and type(proof[0]) is str):
            return False
        tag = proof[0]
        if tag == "hyp" and len(proof) == 2:
            index = proof[1]
            return (natural(index) and index < len(context)
                    and context[index] == conclusion)
        if tag == "refl" and len(proof) == 1:
            return node(conclusion, "=", 3) and conclusion[1] == conclusion[2]
        if tag == "eq" and len(proof) == 5:
            equation, template, equal_proof, body_proof = proof[1:]
            return (node(equation, "=", 3) and self.formula(equation, scope)
                    and self.formula(template, scope + 1)
                    and conclusion == self.instantiate(template, [equation[2]])
                    and self._check(scope, context, equation, equal_proof)
                    and self._check(scope, context,
                                    self.instantiate(template, [equation[1]]), body_proof))
        if tag in ("r0", "rs") and len(proof) == 1:
            if not node(conclusion, "=", 3) or not node(conclusion[1], "r", 4):
                return False
            _, counter, initial, body = conclusion[1]
            if tag == "r0":
                return counter == ["0"] and conclusion[2] == initial
            if not node(counter, "s", 2):
                return False
            previous = ["r", counter[1], initial, body]
            return conclusion[2] == instantiate_term(body, [previous, counter[1]])
        if tag == "sep" and len(proof) == 1:
            return conclusion == self.separation()
        if tag == "ind" and len(proof) == 4:
            equation, target, premise = proof[1:]
            if not (node(equation, "=", 3) and self.formula(equation, scope + 1)
                    and term(target, scope)):
                return False
            expected = self.zero_or(target, self.instantiate(equation, [target]))
            successor = self.map_formula(equation,
                                        lambda index: ["s", 0] if index == 0 else index)
            extended = self.lifted_context(context, 1) + [self.zero_or(0, equation)]
            return (conclusion == expected
                    and self._check(scope + 1, extended, successor, premise))
        return self.logic(scope, context, conclusion, proof)


"""iPRA with one universal/implication and one existential/disjunction constructor."""



class Checker(Arithmetic):
    def formula(self, value, scope):
        if node(value, "=", 3):
            return term(value[1], scope) and term(value[2], scope)
        if node(value, "P", 4):
            _, count, premises, conclusion = value
            return (natural(count) and type(premises) is list
                    and all(self.formula(item, scope + count) for item in premises)
                    and self.formula(conclusion, scope + count))
        if node(value, "D", 2) and type(value[1]) is list:
            return all(type(branch) is list and len(branch) == 2
                       and natural(branch[0]) and type(branch[1]) is list
                       and all(self.formula(item, scope + branch[0]) for item in branch[1])
                       for branch in value[1])
        return False

    def map_formula(self, value, variable, depth=0):
        if value[0] == "=":
            return ["=", map_term(value[1], variable, depth),
                    map_term(value[2], variable, depth)]
        if value[0] == "P":
            _, count, premises, conclusion = value
            return ["P", count, [self.map_formula(item, variable, depth + count)
                                 for item in premises],
                    self.map_formula(conclusion, variable, depth + count)]
        return ["D", [[count, [self.map_formula(item, variable, depth + count)
                               for item in premises]] for count, premises in value[1]]]

    def zero_or(self, value, equation):
        return ["D", [[0, [["=", value, ["0"]]]], [0, [equation]]]]

    def separation(self):
        return ["P", 0, [["=", ["0"], ["s", ["0"]]]], ["D", []]]

    def logic(self, scope, context, conclusion, proof):
        tag = proof[0]
        if tag == "PI" and len(proof) == 2 and node(conclusion, "P", 4):
            _, count, premises, result = conclusion
            return self._check(scope + count, self.lifted_context(context, count) + premises,
                               result, proof[1])
        if tag == "PE" and len(proof) == 5:
            source, witnesses, source_proof, arguments = proof[1:]
            if not (node(source, "P", 4) and self.formula(source, scope)
                    and type(witnesses) is list and len(witnesses) == source[1]
                    and all(term(witness, scope) for witness in witnesses)
                    and type(arguments) is list and len(arguments) == len(source[2])):
                return False
            return (conclusion == self.instantiate(source[3], witnesses)
                    and self._check(scope, context, source, source_proof)
                    and all(self._check(scope, context, self.instantiate(item, witnesses), part)
                            for item, part in zip(source[2], arguments)))
        if tag == "DI" and len(proof) == 4 and node(conclusion, "D", 2):
            index, witnesses, arguments = proof[1:]
            if not (natural(index) and index < len(conclusion[1])):
                return False
            count, premises = conclusion[1][index]
            return (type(witnesses) is list and len(witnesses) == count
                    and all(term(witness, scope) for witness in witnesses)
                    and type(arguments) is list and len(arguments) == len(premises)
                    and all(self._check(scope, context, self.instantiate(item, witnesses), part)
                            for item, part in zip(premises, arguments)))
        if tag == "DE" and len(proof) == 4:
            source, source_proof, branches = proof[1:]
            return (node(source, "D", 2) and self.formula(source, scope)
                    and type(branches) is list and len(branches) == len(source[1])
                    and self._check(scope, context, source, source_proof)
                    and all(self._check(scope + count,
                                        self.lifted_context(context, count) + premises,
                                        self.lift(conclusion, count), part)
                            for (count, premises), part in zip(source[1], branches)))
        return False


check = Checker().check


# Standalone JSON interface; Python and its standard json library are shared dependencies.
if __name__ == "__main__":
    import json
    import sys
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python3 " + sys.argv[0] + " certificate.json")
    try:
        with open(sys.argv[1], encoding="utf-8") as stream:
            record = json.load(stream)
        if type(record) is not dict or set(record) != {"scope", "context", "conclusion", "proof"}:
            raise ValueError("Expected exactly scope, context, conclusion, proof")
        accepted = check(**record)
    except (OSError, ValueError, TypeError, RecursionError) as error:
        raise SystemExit("Invalid input: " + str(error))
    print("ACCEPT" if accepted else "REJECT")
    raise SystemExit(0 if accepted else 1)
