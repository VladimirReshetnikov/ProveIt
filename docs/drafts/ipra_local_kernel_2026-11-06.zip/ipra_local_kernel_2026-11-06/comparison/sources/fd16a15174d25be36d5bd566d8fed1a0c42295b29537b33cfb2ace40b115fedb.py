"""Uniform iPRA checker: one validating substitution traversal.

Theory and certificate format follow the supplied composed-kernel draft.
SCOPES supplies arity, child sort, and binding width. See report.pdf.
"""

import json
import sys

ZERO = -1
SCOPES = {"s": (0,), "r": (0, 0, 2), "=": (0, 0),
          "pi": (1, 1), "sig": (1, 1)}


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def subst(a, env=lambda i: i, formula=None):
    if type(a) is int:
        require(formula is not True and a >= -1)
        return a if a < 0 else env(a)
    require(type(a) is list)
    tag, *args = a
    require(formula is None or (len(args) == 2) == formula)
    return [tag, *(subst(b, lambda i: i if i < d else shift(env(i - d), d), d == 1)
                   for b, d in zip(args, SCOPES[tag], strict=True))]


def shift(a, n=1):
    return subst(a, lambda i: i + n)


def inst(a, t):
    return subst(a, lambda i: t if i == 0 else i - 1)


def infer(p, g):
    match p:
        case ["hyp", key]:
            return g[g.index(key)]
        case ["pi", a, q]:
            subst(a, formula=True)
            return ["pi", a, infer(q, [*map(shift, g), a])]
        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            if tag == "sig":
                require(infer(q, [*map(shift, g), *e[1:]]) == shift(a))
                return a
            if tag == "pi":
                subst(a, formula=False)
            b, c = (inst(a, t) if tag == "=" else inst(t, a) for t in e[1:])
            require(infer(q, g) == b)
            return c
        case ["pair", t, p, q]:
            subst(t, formula=False)
            h = [*map(shift, g), ["=", 0, shift(t)]]
            return ["sig", infer(p, h), infer(q, h)]
        case ["rec", ["r", n, a, h] as r]:
            subst(r, formula=False)
            if n == ZERO:
                b = a
            else:
                require(type(n) is list and n[0] == "s")
                b = subst(h, lambda i: (["r", n[1], a, h], n[1])[i]
                          if i < 2 else i - 2)
            return ["=", r, b]
        case ["nat", a]:
            subst(a, formula=True)
            base = inst(a, ZERO)
            h = a if a[0] == "=" else shift(base)
            step = ["pi", h, subst(a, lambda i: ["s", 0] if i == 0 else i)]
            return ["pi", ["sig", shift(base, 2), shift(step, 2)], a]
        case _:
            raise ValueError("invalid certificate")


def erase(a):
    if a == ["false"]:
        return ["=", ZERO, ["s", ZERO]]
    return list(map(erase, a)) if type(a) is list else a


def check(data):
    g, a, p = erase(data)
    require(type(g) is list)
    for b in [*g, a]:
        subst(b, formula=True)
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
