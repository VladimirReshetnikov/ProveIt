"""Complete iPRA checker with one validating finite-prefix traversal.

Unary existential quantification and guarded universal implication form
its logical basis. The traversal also canonically encodes falsity.
Only finite JSON certificates are accepted; see the accompanying report.
"""

import json
import sys

ZERO = -1
SCOPES = {"s": (0,), "r": (0, 0, 2), "=": (0, 0),
          "pi": (1, 1), "ex": (1,)}


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def walk(a, env=(1,), depth=0, formula=None):
    if a == ["false"]:
        a = ["=", ZERO, ["s", ZERO]]
    if type(a) is int:
        require(not formula and a >= -1)
        i = a - depth
        if 0 <= i < len(env) - 1:
            return walk(env[i], (depth,))
        return a if i < 0 else a + env[-1]
    require(type(a) is list)
    tag, *args = a
    require(formula is None or formula == (tag not in ("s", "r")))
    return [tag, *(walk(b, env, depth + d, d == 1)
                   for b, d in zip(args, SCOPES[tag], strict=True))]


def normal(a, formula=True):
    return walk(a, (0,), formula=formula)


def infer(p, g):
    match p:
        case ["hyp", key]:
            return g[g.index(normal(key))]
        case ["pi", a, q]:
            a = normal(a)
            return ["pi", a, infer(q, [*map(walk, g), a])]
        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            a = normal(a, tag != "pi")
            if tag == "ex":
                require(infer(q, [*map(walk, g), *e[1:]]) == walk(a))
                return a
            b, c = (walk(a, [t, -1]) if tag == "=" else walk(t, [a, -1]) for t in e[1:])
            require(infer(q, g) == b)
            return c
        case ["pack", t, p]:
            normal(t, False)
            h = [*map(walk, g), ["=", 0, walk(t)]]
            return ["ex", infer(p, h)]
        case ["rec", ["r", n, a, h] as r]:
            normal(r, False)
            if n == ZERO:
                b = a
            else:
                require(type(n) is list and n[0] == "s")
                b = walk(h, [["r", n[1], a, h], n[1], -2])
            return ["=", r, b]
        case ["nat", a, t, p, q]:
            a = normal(a)
            normal(t, False)
            require(infer(p, g) == walk(a, [ZERO, -1]))
            h = [*map(walk, g), *([a] if a[0] == "=" else [])]
            require(infer(q, h) == walk(a, [["s", 0], 0]))
            return walk(a, [t, -1])
        case _:
            raise ValueError("invalid certificate")


def check(data):
    g, a, p = data
    require(type(g) is list)
    g = [normal(b) for b in g]
    a = normal(a)
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
