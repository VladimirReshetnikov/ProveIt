"""JSON I/O adapter shared by all matched proof-checker implementations."""

import json
from pathlib import Path
import sys

from kernel import check


def tuples(value):
    if type(value) is list:
        return tuple(tuples(x) for x in value)
    return value


def main():
    try:
        text = sys.stdin.read() if len(sys.argv) == 1 else Path(sys.argv[1]).read_text()
        data = json.loads(text)
        accepted = check(tuples(data["proof"]), tuples(data["conclusion"]),
                         tuples(data.get("context", [])), data.get("scope", 0))
    except (OSError, ValueError, TypeError, KeyError, RecursionError):
        accepted = False
    print(json.dumps({"accepted": accepted}))
    return 0 if accepted else 1


if __name__ == "__main__":
    sys.exit(main())
