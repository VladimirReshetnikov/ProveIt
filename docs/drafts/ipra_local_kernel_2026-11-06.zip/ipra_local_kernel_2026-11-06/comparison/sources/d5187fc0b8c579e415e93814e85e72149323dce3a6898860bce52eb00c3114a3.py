"""Standalone certificate checker for first-order intuitionistic arithmetic.

Public API: infer(proof, context=()) returns its conclusion; check(proof,
goal, context=()) returns True. Invalid raises Invalid. Every public input
uses immutable tuples. The JSON adapter converts arrays to tuples.

Terms: ("v", n), ("0",), ("S", term), ("R", descriptor, arguments).
R arguments are (counter, initializer, parameters...). Its descriptor is a
term in local slots 0=state, 1=counter, 2...=parameters. Descriptor labels
are frozen during active substitution. All unused slots are permitted.

Formula and proof tags, including this file's arithmetic schema or rule,
are specified completely in README.txt. No normalization or proof search
occurs. Inputs exceeding the Python runtime's resources are not accepted.
"""


class Invalid(ValueError):
    """The supplied finite object is not an accepted certificate."""


def require(condition, reason="invalid certificate"):
    if not condition:
        raise Invalid(reason)


def natural(value):
    require(type(value) is int and value >= 0, "expected a natural index")
    return value


def node(value):
    require(type(value) is tuple and len(value) > 0
            and type(value[0]) is str, "expected a tagged tuple")
    return value[0]


ZERO = ("0",)
ONE = ("S", ZERO)
BOTTOM = ("F",)
FIXED_AXIOMS = ((">", ("=", ZERO, ONE), BOTTOM),
                (">", BOTTOM, ("=", ZERO, ONE)))
BINARY = ("&", ">")


def term(t):
    """Validate a term and return its ACTIVE free variable identifiers."""
    tag = node(t)
    if tag == "v" and len(t) == 2:
        return {natural(t[1])}
    if tag == "0" and len(t) == 1:
        return set()
    if tag == "S" and len(t) == 2:
        return term(t[1])
    if tag == "R" and len(t) == 3 and type(t[2]) is tuple and len(t[2]) >= 2:
        require(all(i < len(t[2]) for i in term(t[1])),
                "descriptor slot exceeds its declared arity")
        return set().union(*(term(a) for a in t[2]))
    raise Invalid("malformed term")


def formula(a):
    """Validate a formula and return its free variable identifiers."""
    tag = node(a)
    if tag == "=" and len(a) == 3:
        return term(a[1]) | term(a[2])
    if tag == "F" and len(a) == 1:
        return set()
    if tag in BINARY and len(a) == 3:
        return formula(a[1]) | formula(a[2])
    if tag in ("all", "ex") and len(a) == 3:
        return formula(a[2]) - {natural(a[1])}
    raise Invalid("malformed formula")


def replace(t, environment):
    """Simultaneous active term substitution; nested labels stay frozen."""
    if t[0] == "v":
        return environment.get(t[1], t)
    if t[0] == "R":
        return ("R", t[1], tuple(replace(a, environment) for a in t[2]))
    return (t[0], *(replace(a, environment) for a in t[1:]))


def substitute(a, x, t):
    """Substitute t for free x; reject a substitution that would capture."""
    tag = a[0]
    if tag == "=":
        return ("=", replace(a[1], {x: t}), replace(a[2], {x: t}))
    if tag in ("all", "ex"):
        if a[1] == x:
            return a
        require(a[1] not in term(t) or x not in formula(a[2]),
                "variable capture; freshen the bound variable first")
        return (tag, a[1], substitute(a[2], x, t))
    return (tag, *(substitute(b, x, t) for b in a[1:]))


def context_variables(context):
    return set().union(*(formula(a) for a in context))


def _derive(p, context):
    tag = node(p)
    match p:
        case ("hyp", i):
            require(natural(i) < len(context), "assumption index out of range")
            return context[i]
        case ("refl", t):
            term(t)
            return ("=", t, t)
        case ("eq", equality, x, a, premise):
            natural(x)
            formula(a)
            e = _derive(equality, context)
            require(e[0] == "=", "equality elimination requires an equality")
            require(_derive(premise, context) == substitute(a, x, e[1]),
                    "wrong equality-substitution premise")
            return substitute(a, x, e[2])
        case ("&I", left, right):
            return ("&", _derive(left, context), _derive(right, context))
        case ("&L", premise) | ("&R", premise):
            a = _derive(premise, context)
            require(a[0] == "&", "conjunction elimination requires a conjunction")
            return a[1 if tag == "&L" else 2]

        case (">I", a, premise):
            formula(a)
            return (">", a, _derive(premise, context + (a,)))
        case (">E", implication, premise):
            a = _derive(implication, context)
            require(a[0] == ">", "implication elimination requires an implication")
            require(_derive(premise, context) == a[1], "wrong implication premise")
            return a[2]

        case ("allI", x, premise):
            natural(x)
            require(x not in context_variables(context), "universal eigenvariable escapes")
            return ("all", x, _derive(premise, context))
        case ("allE", premise, t):
            term(t)
            a = _derive(premise, context)
            require(a[0] == "all", "universal elimination requires a universal formula")
            return substitute(a[2], a[1], t)
        case ("exI", x, a, t, premise):
            natural(x)
            formula(a)
            term(t)
            require(_derive(premise, context) == substitute(a, x, t),
                    "wrong existential-introduction instance")
            return ("ex", x, a)
        case ("exE", existential, y, premise):
            natural(y)
            a = _derive(existential, context)
            require(a[0] == "ex", "existential elimination requires an existential formula")
            require(y not in context_variables(context) | formula(a),
                    "existential eigenvariable is not fresh")
            b = _derive(premise, context + (substitute(a[2], a[1], ("v", y)),))
            require(y not in formula(b), "existential eigenvariable escapes")
            return b
        case ("ax", i):
            require(natural(i) < len(FIXED_AXIOMS), "unknown fixed axiom")
            return FIXED_AXIOMS[i]
        case ("rec", r):
            term(r)
            require(r[0] == "R", "computation requires a recursor call")
            h, args = r[1], r[2]
            if args[0] == ZERO:
                value = args[1]
            else:
                require(args[0][0] == "S", "computation counter is neither zero nor successor")
                n = args[0][1]
                previous = ("R", h, (n, *args[1:]))
                value = replace(h, dict(enumerate((previous, n, *args[2:]))))
            return ("=", r, value)
        case ("sc", x, e, t, a, base, step, zero_case, equation_case):
            natural(x)
            formula(e)
            term(t)
            formula(a)
            require(e[0] == "=", "arithmetic induction is restricted to equations")
            require(x not in context_variables(context) | term(t) | formula(a),
                    "induction eigenvariable escapes")
            require(_derive(base, context) == substitute(e, x, ONE), "wrong arithmetic base")
            require(_derive(step, context + (e,)) == substitute(e, x, ("S", ("v", x))),
                    "wrong arithmetic step")
            require(_derive(zero_case, context + (("=", t, ZERO),)) == a,
                    "wrong zero-case conclusion")
            require(_derive(equation_case, context + (substitute(e, x, t),)) == a,
                    "wrong equation-case conclusion")
            return a
    raise Invalid("unknown proof tag or wrong number of fields")


def infer(proof, context=()):
    """Validate every witness and infer a conclusion in the given context."""
    require(type(context) is tuple, "context must be an immutable tuple")
    context_variables(context)
    return _derive(proof, context)


def check(proof, goal, context=()):
    """Accept exactly when infer(proof, context) is syntactically goal."""
    formula(goal)
    require(infer(proof, context) == goal, "the conclusion is not the requested goal")
    return True


# --- CLI adapter (not the mathematical kernel) ---
def _freeze(value):
    if type(value) is list:
        return tuple(_freeze(item) for item in value)
    require(type(value) in (str, int), "JSON certificate leaves must be strings or integers")
    return value


def main():
    import json
    import sys

    def unique_fields(pairs):
        result = dict(pairs)
        require(len(result) == len(pairs), "duplicate JSON object field")
        return result

    try:
        data = json.load(sys.stdin, object_pairs_hook=unique_fields)
        require(type(data) is dict and "proof" in data
                and set(data) <= {"proof", "goal", "context"}, "wrong top-level JSON fields")
        proof = _freeze(data["proof"])
        context = _freeze(data.get("context", []))
        conclusion = infer(proof, context)
        if "goal" in data:
            goal = _freeze(data["goal"])
            formula(goal)
            require(conclusion == goal, "the conclusion is not the requested goal")
        print(json.dumps({"ok": True, "conclusion": conclusion}))
        return 0
    except (Invalid, ValueError, TypeError, KeyError, IndexError, RecursionError) as error:
        print(json.dumps({"ok": False, "error": str(error)}))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
