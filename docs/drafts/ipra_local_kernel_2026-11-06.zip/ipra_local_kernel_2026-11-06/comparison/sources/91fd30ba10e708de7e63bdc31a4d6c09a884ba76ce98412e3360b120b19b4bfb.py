"""Trusted syntax, arithmetic, and infrastructure for the row-fused checker.

Terms: ["0"], ["v", name], ["s", term], ["r", function, *arguments].
Variable names and function indices are nonnegative integers. Function
declarations have local slots state=0, counter=1, parameters=2,3,... .
Named substitution rejects capture; certificates must choose fresh names.
"""

import json
import sys


ZERO = ["0"]
ONE = ["s", ZERO]
FALSE = ["E", None]


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def natural(value):
    return type(value) is int and value >= 0


class Base:
    """The subclass supplies U and E proof rules; rows are syntax metadata."""

    binders = {"U", "E"}

    def __init__(self, declarations):
        require(type(declarations) is list)
        self.functions = []
        self.arities = []
        for declaration in declarations:
            require(type(declaration) is dict)
            require(set(declaration) == {"parameters", "body"})
            count = declaration["parameters"]
            require(natural(count))
            self.term(declaration["body"], count + 2)
            self.functions.append(declaration["body"])
            self.arities.append(count + 2)

    def term(self, expression, slots=None):
        require(type(expression) is list and bool(expression))
        match expression:
            case ["0"]:
                return
            case ["v", name]:
                require(natural(name) and (slots is None or name < slots))
            case ["s", argument]:
                self.term(argument, slots)
            case ["r", function, *arguments]:
                require(natural(function) and function < len(self.functions))
                require(len(arguments) == self.arities[function])
                for argument in arguments:
                    self.term(argument, slots)
            case _:
                require(False)

    def formula(self, expression):
        require(type(expression) is list and bool(expression))
        tag = expression[0]
        require(type(tag) is str)
        if tag == "eq":
            require(len(expression) == 3)
            self.term(expression[1])
            self.term(expression[2])
        elif tag == "U":
            require(len(expression) == 4 and natural(expression[1]))
            for child in expression[2:]:
                self.formula(child)
        elif tag == "E":
            require(len(expression) >= 2 and
                    (expression[1] is None or natural(expression[1])))
            for row in expression[2:]:
                require(type(row) is list and bool(row) and row[0] == "row")
                for child in row[1:]:
                    self.formula(child)
        else:
            require(False)

    def disjoin(self, left, right):
        return ["E", None, ["row", left], ["row", right]]

    def free(self, expression):
        """Active free names only: recursion descriptors are never traversed."""
        tag = expression[0]
        if tag == "v":
            return {expression[1]}
        start = 2 if tag == "r" or tag in self.binders else 1
        result = set()
        for child in expression[start:]:
            result.update(self.free(child))
        if tag in self.binders:
            result.discard(expression[1])
        return result

    def substitute(self, expression, name, replacement):
        """One simultaneous free-name substitution, rejecting capture."""
        if name not in self.free(expression):
            return expression
        tag = expression[0]
        if tag == "v":
            return replacement
        if tag in self.binders:
            require(expression[1] not in self.free(replacement))
        start = 2 if tag == "r" or tag in self.binders else 1
        return expression[:start] + [
            self.substitute(child, name, replacement)
            for child in expression[start:]
        ]

    def fresh(self, name, expressions):
        require(natural(name))
        require(all(name not in self.free(item) for item in expressions))

    def plug(self, expression, values):
        """Instantiate all local update slots at once, without evaluating."""
        if expression[0] == "v":
            return values[expression[1]]
        start = 2 if expression[0] == "r" else 1
        return expression[:start] + [
            self.plug(child, values) for child in expression[start:]
        ]

    def computation(self, expression):
        require(expression[0] == "r")
        function, counter, initial, *parameters = expression[1:]
        if counter == ZERO:
            return initial
        require(counter[0] == "s")
        previous = counter[1]
        recursive = ["r", function, previous, initial, *parameters]
        return self.plug(self.functions[function],
                         [recursive, previous, *parameters])

    def check(self, proof, context, goal):
        self.formula(goal)
        require(type(proof) is list)
        match proof:
            case ["hyp"]:
                require(goal in context)
            case ["refl"]:
                require(goal[0] == "eq" and goal[1] == goal[2])
            case ["replace", equation, name, body, equality, premise]:
                self.formula(equation)
                self.formula(body)
                require(equation[0] == "eq" and natural(name))
                require(goal == self.substitute(body, name, equation[2]))
                self.check(equality, context, equation)
                self.check(premise, context,
                           self.substitute(body, name, equation[1]))
            case ["compute"]:
                require(goal[0] == "eq")
                require(goal[2] == self.computation(goal[1]))
            case ["separation"]:
                require(goal == self.separation)
            case ["induct", name, equation, target, premise]:
                self.formula(equation)
                self.term(target)
                require(equation[0] == "eq")
                self.fresh(name, context + [target])
                variable = ["v", name]
                expected = self.disjoin(["eq", target, ZERO],
                                        self.substitute(equation, name, target))
                require(goal == expected)
                assumption = self.disjoin(["eq", variable, ZERO], equation)
                successor = self.substitute(equation, name, ["s", variable])
                self.check(premise, context + [assumption], successor)
            case _:
                self.logical(proof, context, goal)


def run(kernel):
    """Read a closed JSON certificate problem from standard input."""
    try:
        problem = json.load(sys.stdin)
        require(type(problem) is dict)
        require(set(problem) == {"functions", "context", "conclusion", "proof"})
        checker = kernel(problem["functions"])
        context = problem["context"]
        require(type(context) is list)
        for formula in context:
            checker.formula(formula)
        checker.check(problem["proof"], context, problem["conclusion"])
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OverflowError):
        print(json.dumps({"accepted": False}))
        return 1
    print(json.dumps({"accepted": True}))
    return 0
