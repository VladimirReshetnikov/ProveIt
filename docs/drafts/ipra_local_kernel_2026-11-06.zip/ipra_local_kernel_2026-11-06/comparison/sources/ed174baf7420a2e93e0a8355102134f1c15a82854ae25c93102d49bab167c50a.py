"""Complete iPRA certificate checker. See report.pdf for the full theory.

Falsity is primitive, with an explicit bridge to the equation 0 = S0.
The seven proof records share elimination and use witness equations.
Only finite JSON is input; no proof generator is trusted.
"""

import json
import sys

ZERO = -1
FALSE = ["false"]
CLASH = ["=", ZERO, ["s", ZERO]]


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


SCOPE = {"s": (0,), "r": (0, 0, 2), "=": (0, 0),
         "pi": (1, 1), "sig": (1, 1), "false": ()}


def wf(a, formula=False):
    if type(a) is not list:
        return type(a) is int and not formula and a >= -1
    tag, *args = a
    scopes = SCOPE[tag]
    return ((tag not in ("s", "r")) == formula
            and len(args) == len(scopes)
            and all(wf(b, d == 1) for b, d in zip(args, scopes)))


def walk(a, f, d=0):
    if type(a) is int:
        return a if a < d else f(a - d, d)
    require(type(a) is list)
    tag, *args = a
    return [tag, *(walk(b, f, d + SCOPE[tag][i])
                   for i, b in enumerate(args))]


def shift(a, n=1):
    return walk(a, lambda i, d: i + d + n)


def subst(a, env):
    return walk(a, lambda i, d: shift(env(i), d))


def inst(a, t):
    return subst(a, lambda i: t if i == 0 else i - 1)


def infer(p, g):
    match p:
        case ["hyp", key]:
            return g[g.index(key)]
        case ["pi", a, q]:
            require(wf(a, True))
            return ["pi", a, infer(q, [*map(shift, g), a])]
        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            require(wf(a, tag != "pi"))
            if tag == "sig":
                require(infer(q, [*map(shift, g), *e[1:]]) == shift(a))
                return a
            b, c = (inst(a, t) if tag == "=" else inst(t, a) for t in e[1:])
            require(infer(q, g) == b)
            return c
        case ["pair", t, p, q]:
            require(wf(t))
            h = [*map(shift, g), ["=", 0, shift(t)]]
            return ["sig", infer(p, h), infer(q, h)]
        case ["bridge", p]:
            return [CLASH, FALSE][[FALSE, CLASH].index(infer(p, g))]
        case ["rec", ["r", n, a, h] as r]:
            require(wf(r))
            if n == ZERO:
                b = a
            else:
                require(n[0] == "s")
                b = subst(h, lambda i: (["r", n[1], a, h], n[1])[i]
                          if i < 2 else i - 2)
            return ["=", r, b]
        case ["nat", a]:
            require(wf(a, True))
            base = inst(a, ZERO)
            h = a if a[0] == "=" else shift(base)
            step = ["pi", h, subst(a, lambda i: ["s", 0] if i == 0 else i)]
            return ["pi", ["sig", shift(base, 2), shift(step, 2)], a]
        case _:
            raise ValueError("invalid certificate")


def check(data):
    g, a, p = data
    require(type(g) is list and all(wf(b, True) for b in g) and wf(a, True))
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
