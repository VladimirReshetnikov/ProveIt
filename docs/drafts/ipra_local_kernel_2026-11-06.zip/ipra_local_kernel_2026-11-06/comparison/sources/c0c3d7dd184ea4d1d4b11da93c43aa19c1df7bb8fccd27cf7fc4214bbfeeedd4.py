"""Shared JSON transport for all four kernels; no proof search or trusted lemmas."""

import argparse
import importlib
import json
from pathlib import Path


def tuples(value):
    if isinstance(value, list):
        return tuple(tuples(v) for v in value)
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate", type=Path)
    parser.add_argument("--kernel", default="kernel", choices=(
        "kernel", "kernel_genuine", "kernel_bridge", "kernel_reference"))
    args = parser.parse_args()
    module = importlib.import_module(args.kernel)
    payload = json.loads(args.certificate.read_text())
    if not isinstance(payload, dict) or set(payload) != {"proof", "conclusion"}:
        raise ValueError("certificate needs exactly proof and conclusion")
    expected = tuples(payload["conclusion"])
    if not module.formula(expected):
        raise module.InvalidProof("the JSON conclusion must be a formula")
    conclusion = module.check(tuples(payload["proof"]), expected)
    print(json.dumps({"accepted": True, "kernel": args.kernel,
                      "lines": len(payload["proof"]), "conclusion": conclusion}))


if __name__ == "__main__":
    main()
