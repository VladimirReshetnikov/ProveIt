"""Shared finite syntax and arithmetic for the two iPRA proof checkers."""


def natural(value):
    return type(value) is int and value >= 0


def node(value, tag, length):
    return type(value) is list and len(value) == length and value[0] == tag


def term(value, scope):
    if natural(value):
        return value < scope
    if node(value, "0", 1):
        return True
    if node(value, "s", 2):
        return term(value[1], scope)
    if node(value, "r", 4):
        return (term(value[1], scope) and term(value[2], scope)
                and term(value[3], scope + 2))
    return False


def map_term(value, variable, depth=0):
    if type(value) is int:
        return value if value < depth else lift_term(variable(value - depth), depth)
    if value[0] == "0":
        return ["0"]
    if value[0] == "s":
        return ["s", map_term(value[1], variable, depth)]
    return ["r", map_term(value[1], variable, depth),
            map_term(value[2], variable, depth),
            map_term(value[3], variable, depth + 2)]


def lift_term(value, amount):
    return value if amount == 0 else map_term(value, lambda index: index + amount)


def replacement(values):
    return lambda index: values[index] if index < len(values) else index - len(values)


def instantiate_term(value, values):
    return map_term(value, replacement(values))


class Arithmetic:
    """The subclasses supply formula syntax and their logical rule cases."""

    def lift(self, formula, amount):
        return self.map_formula(formula, lambda index: index + amount)

    def instantiate(self, formula, values):
        return self.map_formula(formula, replacement(values))

    def lifted_context(self, context, amount):
        return [self.lift(formula, amount) for formula in context]

    def check(self, scope, context, conclusion, proof):
        try:
            return (natural(scope) and type(context) is list
                    and all(self.formula(formula, scope) for formula in context)
                    and self.formula(conclusion, scope)
                    and self._check(scope, context, conclusion, proof))
        except (IndexError, KeyError, TypeError, ValueError, RecursionError):
            return False

    def _check(self, scope, context, conclusion, proof):
        if not (type(proof) is list and proof and type(proof[0]) is str):
            return False
        tag = proof[0]
        if tag == "hyp" and len(proof) == 2:
            index = proof[1]
            return (natural(index) and index < len(context)
                    and context[index] == conclusion)
        if tag == "refl" and len(proof) == 1:
            return node(conclusion, "=", 3) and conclusion[1] == conclusion[2]
        if tag == "eq" and len(proof) == 5:
            equation, template, equal_proof, body_proof = proof[1:]
            return (node(equation, "=", 3) and self.formula(equation, scope)
                    and self.formula(template, scope + 1)
                    and conclusion == self.instantiate(template, [equation[2]])
                    and self._check(scope, context, equation, equal_proof)
                    and self._check(scope, context,
                                    self.instantiate(template, [equation[1]]), body_proof))
        if tag in ("r0", "rs") and len(proof) == 1:
            if not node(conclusion, "=", 3) or not node(conclusion[1], "r", 4):
                return False
            _, counter, initial, body = conclusion[1]
            if tag == "r0":
                return counter == ["0"] and conclusion[2] == initial
            if not node(counter, "s", 2):
                return False
            previous = ["r", counter[1], initial, body]
            return conclusion[2] == instantiate_term(body, [previous, counter[1]])
        if tag == "sep" and len(proof) == 1:
            return conclusion == self.separation()
        if tag == "ind" and len(proof) == 4:
            equation, target, premise = proof[1:]
            if not (node(equation, "=", 3) and self.formula(equation, scope + 1)
                    and term(target, scope)):
                return False
            expected = self.zero_or(target, self.instantiate(equation, [target]))
            successor = self.map_formula(equation,
                                        lambda index: ["s", 0] if index == 0 else index)
            extended = self.lifted_context(context, 1) + [self.zero_or(0, equation)]
            return (conclusion == expected
                    and self._check(scope + 1, extended, successor, premise))
        return self.logic(scope, context, conclusion, proof)


"""iPRA with uniform universal/implication and existential/disjunction blocks."""


class Checker(Arithmetic):
    def formula(self, value, scope):
        if node(value, "=", 3):
            return term(value[1], scope) and term(value[2], scope)
        return (type(value) is list and len(value) == 2 and value[0] in ("P", "D")
                and type(value[1]) is list
                and all(type(block) is list and len(block) == 2
                        and natural(block[0]) and type(block[1]) is list
                        and (value[0] == "D" or len(block[1]) > 0)
                        and all(self.formula(item, scope + block[0]) for item in block[1])
                        for block in value[1]))

    def map_formula(self, value, variable, depth=0):
        if value[0] == "=":
            return ["=", map_term(value[1], variable, depth),
                    map_term(value[2], variable, depth)]
        return [value[0], [[count, [self.map_formula(item, variable, depth + count)
                                   for item in items]] for count, items in value[1]]]

    def zero_or(self, value, equation):
        return ["D", [[0, [["=", value, ["0"]]]], [0, [equation]]]]

    def separation(self):
        return ["P", [[0, [["=", ["0"], ["s", ["0"]]], ["D", []]]]]]

    def logic(self, scope, context, conclusion, proof):
        if proof[0] == "I" and len(proof) == 2 and conclusion[0] in ("P", "D"):
            source, data = conclusion, proof[1]
        elif proof[0] == "E" and len(proof) == 4:
            source, major, data = proof[1:]
            if not (self.formula(source, scope) and source[0] in ("P", "D")
                    and self._check(scope, context, source, major)):
                return False
        else:
            return False
        # D introduction and P elimination select one block and supply witnesses.
        # P introduction and D elimination check every block under fresh variables.
        if (proof[0] == "I") == (source[0] == "D"):
            if not (type(data) is list and len(data) == 3):
                return False
            index, witnesses, arguments = data
            if not (natural(index) and index < len(source[1])):
                return False
            count, items = source[1][index]
            if not (type(witnesses) is list and len(witnesses) == count
                    and all(term(witness, scope) for witness in witnesses)):
                return False
            if source[0] == "P":
                if conclusion != self.instantiate(items[-1], witnesses):
                    return False
                items = items[:-1]
            return (type(arguments) is list and len(arguments) == len(items)
                    and all(self._check(scope, context, self.instantiate(item, witnesses), part)
                            for item, part in zip(items, arguments)))
        return (type(data) is list and len(data) == len(source[1])
                and all(self._check(scope + count,
                                    self.lifted_context(context, count)
                                    + (items if source[0] == "D" else items[:-1]),
                                    self.lift(conclusion, count) if source[0] == "D" else items[-1],
                                    part)
                        for (count, items), part in zip(source[1], data)))


check = Checker().check


# Standalone JSON interface; Python and its standard json library are shared dependencies.
if __name__ == "__main__":
    import json
    import sys
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python3 " + sys.argv[0] + " certificate.json")
    try:
        with open(sys.argv[1], encoding="utf-8") as stream:
            record = json.load(stream)
        if type(record) is not dict or set(record) != {"scope", "context", "conclusion", "proof"}:
            raise ValueError("Expected exactly scope, context, conclusion, proof")
        accepted = check(**record)
    except (OSError, ValueError, TypeError, RecursionError) as error:
        raise SystemExit("Invalid input: " + str(error))
    print("ACCEPT" if accepted else "REJECT")
    raise SystemExit(0 if accepted else 1)
