"""Usage: python3 check.py certificate.json. Acceptance is exit status zero."""

import json
import sys
from syntax import freeze, need
from hilbert_reflexivity import check


def main():
    try:
        need(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            data = json.load(stream)
        need(type(data) is dict and set(data) == {"proof", "goal"})
        check(freeze(data["proof"]), freeze(data["goal"]))
    except (ValueError, TypeError, KeyError, IndexError, RecursionError, OSError):
        print("REJECT")
        return 1
    print("ACCEPT")
    return 0


if __name__ == "__main__":
    sys.exit(main())
