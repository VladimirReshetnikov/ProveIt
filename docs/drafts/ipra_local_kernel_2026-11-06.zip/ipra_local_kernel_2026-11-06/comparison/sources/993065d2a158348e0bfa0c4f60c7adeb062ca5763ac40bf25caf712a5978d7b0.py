"""Full candidate checker: genuine falsity, guarded Pi/Sigma, atomic induction."""

from shared import (B, COMMON, Eq, S, V, Z, arity, common_rule, head, instantiate,
                    lifted, main, need, shift, successor_instance, verify, well)


SYNTAX = COMMON | {
    "pi": ("formula", (("formula", 1), ("formula", 1))),
    "sigma": ("formula", (("formula", 1), ("formula", 1))),
}
SEPARATION = ["pi", Eq(Z, S(Z)), B]


def check(proof, goal, context, scope):
    tag = head(proof)
    if common_rule(proof, goal, context, scope, SYNTAX, check, SEPARATION):
        return
    if tag == "piI":
        arity(proof, 1)
        need(goal[0] == "pi", "not a Pi goal")
        check(proof[1], goal[2], lifted(context, SYNTAX) + [goal[1]], scope + 1)
    elif tag == "piE":
        arity(proof, 4)
        principal, witness, universal, guard = proof[1:]
        well(principal, "formula", scope, SYNTAX)
        well(witness, "term", scope, SYNTAX)
        need(principal[0] == "pi", "not a Pi principal")
        need(goal == instantiate(principal[2], [witness], SYNTAX), "wrong Pi target")
        check(universal, principal, context, scope)
        check(guard, instantiate(principal[1], [witness], SYNTAX), context, scope)
    elif tag == "sigmaI":
        arity(proof, 3)
        witness, left, right = proof[1:]
        need(goal[0] == "sigma", "not a Sigma goal")
        well(witness, "term", scope, SYNTAX)
        check(left, instantiate(goal[1], [witness], SYNTAX), context, scope)
        check(right, instantiate(goal[2], [witness], SYNTAX), context, scope)
    elif tag == "sigmaE":
        arity(proof, 3)
        principal, existential, branch = proof[1:]
        well(principal, "formula", scope, SYNTAX)
        need(principal[0] == "sigma", "not a Sigma principal")
        check(existential, principal, context, scope)
        check(branch, shift(goal, 1, SYNTAX),
              lifted(context, SYNTAX) + principal[1:], scope + 1)
    elif tag == "nat":
        arity(proof, 4)
        template, target, base, step = proof[1:]
        well(template, "formula", scope + 1, SYNTAX)
        well(target, "term", scope, SYNTAX)
        need(goal == instantiate(template, [target], SYNTAX), "wrong induction target")
        check(base, instantiate(template, [Z], SYNTAX), context, scope)
        hypotheses = [template] if template[0] == "eq" else []
        check(step, successor_instance(template, SYNTAX),
              lifted(context, SYNTAX) + hypotheses, scope + 1)
    else:
        need(False, "unknown proof rule")


if __name__ == "__main__":
    raise SystemExit(main(SYNTAX, check))
