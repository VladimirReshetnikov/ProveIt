"""iPRA certificate checker with unary existence and a validating substitution.

Finite JSON only. All numerical and logical axioms are constructed here.
Falsity is the explicit abbreviation 0 = S0.
"""

import json
import sys

ZERO = -1


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


SCOPES = {"s": (0,), "r": (0, 0, 2), "=": (0, 0),
          "pi": (1, 1), "ex": (1,)}


def subst(a, env=(1,), d=0, formula=None):
    if a == ["false"]:
        a = ["=", ZERO, ["s", ZERO]]
    if type(a) is int:
        require(not formula and a >= -1)
        i = a - d
        return a if i < 0 else subst(env[i], (d,)) if i < len(env) - 1 else a + env[-1]
    require(type(a) is list)
    tag, *args = a
    require(formula is None or (tag not in ("s", "r")) == formula)
    return [tag, *(subst(b, env, d + k, k == 1)
                   for b, k in zip(args, SCOPES[tag], strict=True))]


def infer(p, g):
    match p:
        case ["hyp", key]:
            return g[g.index(subst(key, (0,), formula=True))]
        case [("pi" | "pack") as tag, a, q]:
            a = subst(a, (0,), formula=tag == "pi")
            h = a if tag == "pi" else ["=", 0, subst(a)]
            b = infer(q, [*map(subst, g), h])
            return ["pi", a, b] if tag == "pi" else ["ex", b]
        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            a = subst(a, (0,), formula=tag != "pi")
            if tag == "ex":
                require(infer(q, [*map(subst, g), *e[1:]]) == subst(a))
                return a
            b, c = (subst(a, [t, -1]) if tag == "=" else subst(t, [a, -1]) for t in e[1:])
            require(infer(q, g) == b)
            return c
        case ["rec", ["r", n, a, h] as r]:
            subst(r, (0,), formula=False)
            if n == ZERO:
                b = a
            else:
                require(n[0] == "s")
                b = subst(h, [["r", n[1], a, h], n[1], -2])
            return ["=", r, b]
        case ["nat", a]:
            a = subst(a, (0,), formula=True)
            base = subst(a, [ZERO, 0])
            h = a if a[0] == "=" else base
            step = ["pi", h, subst(a, [["s", 0], 0])]
            return ["pi", base, ["pi", subst(step, (2,)), subst(a)]]
        case _:
            raise ValueError("invalid certificate")


def check(data):
    g, a, p = data
    require(type(g) is list)
    g = [subst(b, (0,), formula=True) for b in g]
    a = subst(a, (0,), formula=True)
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
