"""Small JSON-file driver. The proof checker itself is kernel.check."""

import json
from pathlib import Path
import sys

from kernel import check


def main():
    if len(sys.argv) < 2:
        raise SystemExit("Usage: python3 check_certificate.py certificates/*.json")
    rejected = 0
    for filename in sys.argv[1:]:
        try:
            item = json.loads(Path(filename).read_text())
            accepted = check(item["variables"], item["context"], item["conclusion"], item["proof"])
        except (OSError, ValueError, KeyError, TypeError):
            accepted = False
        print(("ACCEPT " if accepted else "REJECT ") + filename)
        rejected += not accepted
    raise SystemExit(1 if rejected else 0)


if __name__ == "__main__":
    main()
