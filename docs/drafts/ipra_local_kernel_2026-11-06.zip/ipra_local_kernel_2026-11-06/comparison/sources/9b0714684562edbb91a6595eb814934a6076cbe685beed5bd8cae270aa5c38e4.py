"""Complete iPRA checker with one shared fresh-number transition.

Proof leaves select context entries. Falsity is the equation 0 = S0.
Only this file and the standard Python/JSON runtime participate in acceptance.
"""

import json
import sys

ZERO = -1


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


SCOPES = ({"s": (0,), "r": (0, 0, 2)},
          {"=": (0, 0), "pi": (1, 1), "ex": (1,)})


def subst(a, env=(1,), d=0, formula=True):
    if type(a) is int:
        require(not formula and a >= -1)
        i = a - d
        return a if i < 0 else subst(env[i], (d,), formula=False) if i < len(env) - 1 else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + width, width == 1)
                   for b, width in zip(args, SCOPES[formula][tag], strict=True))]


def infer(p, g):
    match p:
        case [("lam" | "pack" | "nat") as tag, a, q]:
            if tag == "pack":
                a = ["=", 0, subst(a, formula=False)]
            base = subst(a, [ZERO, 0] if tag == "nat" else (0,))
            h = a if a[0] == "=" else base
            b = infer(q, [*map(subst, g), h])
            if tag == "nat":
                require(b == subst(a, [["s", 0], 0]))
                b = a
            return ["ex", b] if tag == "pack" else ["pi", base, b]
        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            subst(a, formula=tag != "pi")
            if tag == "ex":
                require(infer(q, [*map(subst, g), *e[1:]]) == subst(a))
                return a
            b, c = (subst(a, [t, -1]) if tag == "=" else subst(t, [a, -1]) for t in e[1:])
            require(infer(q, g) == b)
            return c
        case ["r", n, a, h] as r:
            subst(r, formula=False)
            if n == ZERO:
                b = a
            else:
                require(n[0] == "s")
                b = subst(h, [["r", n[1], a, h], n[1], -2], formula=False)
            return ["=", r, b]
        case _:
            return g[p]


def check(data):
    g, a, p = data
    require(type(g) is list)
    for b in [*g, a]:
        subst(b)
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
