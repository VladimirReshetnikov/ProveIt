"""Shared finite syntax and arithmetic for the two iPRA proof checkers."""


def natural(value):
    return type(value) is int and value >= 0


def node(value, tag, length):
    return type(value) is list and len(value) == length and value[0] == tag


def term(value, scope):
    if natural(value):
        return value < scope
    if node(value, "0", 1):
        return True
    if node(value, "s", 2):
        return term(value[1], scope)
    if node(value, "r", 4):
        return (term(value[1], scope) and term(value[2], scope)
                and term(value[3], scope + 2))
    return False


def map_term(value, variable, depth=0):
    if type(value) is int:
        return value if value < depth else lift_term(variable(value - depth), depth)
    if value[0] == "0":
        return ["0"]
    if value[0] == "s":
        return ["s", map_term(value[1], variable, depth)]
    return ["r", map_term(value[1], variable, depth),
            map_term(value[2], variable, depth),
            map_term(value[3], variable, depth + 2)]


def lift_term(value, amount):
    return value if amount == 0 else map_term(value, lambda index: index + amount)


def replacement(values):
    return lambda index: values[index] if index < len(values) else index - len(values)


def instantiate_term(value, values):
    return map_term(value, replacement(values))


class Arithmetic:
    """The subclasses supply formula syntax and their logical rule cases."""

    def lift(self, formula, amount):
        return self.map_formula(formula, lambda index: index + amount)

    def instantiate(self, formula, values):
        return self.map_formula(formula, replacement(values))

    def lifted_context(self, context, amount):
        return [self.lift(formula, amount) for formula in context]

    def check(self, scope, context, conclusion, proof):
        try:
            return (natural(scope) and type(context) is list
                    and all(self.formula(formula, scope) for formula in context)
                    and self.formula(conclusion, scope)
                    and self._check(scope, context, conclusion, proof))
        except (IndexError, KeyError, TypeError, ValueError, RecursionError):
            return False

    def _check(self, scope, context, conclusion, proof):
        if not (type(proof) is list and proof and type(proof[0]) is str):
            return False
        tag = proof[0]
        if tag == "hyp" and len(proof) == 2:
            index = proof[1]
            return (natural(index) and index < len(context)
                    and context[index] == conclusion)
        if tag == "refl" and len(proof) == 1:
            return node(conclusion, "=", 3) and conclusion[1] == conclusion[2]
        if tag == "eq" and len(proof) == 5:
            equation, template, equal_proof, body_proof = proof[1:]
            return (node(equation, "=", 3) and self.formula(equation, scope)
                    and self.formula(template, scope + 1)
                    and conclusion == self.instantiate(template, [equation[2]])
                    and self._check(scope, context, equation, equal_proof)
                    and self._check(scope, context,
                                    self.instantiate(template, [equation[1]]), body_proof))
        if tag in ("r0", "rs") and len(proof) == 1:
            if not node(conclusion, "=", 3) or not node(conclusion[1], "r", 4):
                return False
            _, counter, initial, body = conclusion[1]
            if tag == "r0":
                return counter == ["0"] and conclusion[2] == initial
            if not node(counter, "s", 2):
                return False
            previous = ["r", counter[1], initial, body]
            return conclusion[2] == instantiate_term(body, [previous, counter[1]])
        if tag == "sep" and len(proof) == 1:
            return conclusion == self.separation()
        if tag == "ind" and len(proof) == 4:
            equation, target, premise = proof[1:]
            if not (node(equation, "=", 3) and self.formula(equation, scope + 1)
                    and term(target, scope)):
                return False
            expected = self.zero_or(target, self.instantiate(equation, [target]))
            successor = self.map_formula(equation,
                                        lambda index: ["s", 0] if index == 0 else index)
            extended = self.lifted_context(context, 1) + [self.zero_or(0, equation)]
            return (conclusion == expected
                    and self._check(scope + 1, extended, successor, premise))
        return self.logic(scope, context, conclusion, proof)


"""The same arithmetic with ordinary intuitionistic first-order logical constructors."""



class Checker(Arithmetic):
    def formula(self, value, scope):
        if node(value, "=", 3):
            return term(value[1], scope) and term(value[2], scope)
        if node(value, "bot", 1):
            return True
        if type(value) is list and len(value) == 3 and value[0] in ("and", "or", "imp"):
            return self.formula(value[1], scope) and self.formula(value[2], scope)
        if type(value) is list and len(value) == 2 and value[0] in ("all", "ex"):
            return self.formula(value[1], scope + 1)
        return False

    def map_formula(self, value, variable, depth=0):
        if value[0] == "=":
            return ["=", map_term(value[1], variable, depth),
                    map_term(value[2], variable, depth)]
        if value[0] == "bot":
            return ["bot"]
        if value[0] in ("all", "ex"):
            return [value[0], self.map_formula(value[1], variable, depth + 1)]
        return [value[0], self.map_formula(value[1], variable, depth),
                self.map_formula(value[2], variable, depth)]

    def zero_or(self, value, equation):
        return ["or", ["=", value, ["0"]], equation]

    def separation(self):
        return ["imp", ["=", ["0"], ["s", ["0"]]], ["bot"]]

    def logic(self, scope, context, conclusion, proof):
        tag = proof[0]
        if tag == "and_i" and len(proof) == 3 and node(conclusion, "and", 3):
            return (self._check(scope, context, conclusion[1], proof[1])
                    and self._check(scope, context, conclusion[2], proof[2]))
        if tag in ("and_l", "and_r") and len(proof) == 3:
            source, source_proof = proof[1:]
            index = 1 if tag == "and_l" else 2
            return (node(source, "and", 3) and self.formula(source, scope)
                    and conclusion == source[index]
                    and self._check(scope, context, source, source_proof))
        if tag in ("or_l", "or_r") and len(proof) == 2 and node(conclusion, "or", 3):
            index = 1 if tag == "or_l" else 2
            return self._check(scope, context, conclusion[index], proof[1])
        if tag == "or_e" and len(proof) == 5:
            source, source_proof, left, right = proof[1:]
            return (node(source, "or", 3) and self.formula(source, scope)
                    and self._check(scope, context, source, source_proof)
                    and self._check(scope, context + [source[1]], conclusion, left)
                    and self._check(scope, context + [source[2]], conclusion, right))
        if tag == "imp_i" and len(proof) == 2 and node(conclusion, "imp", 3):
            return self._check(scope, context + [conclusion[1]], conclusion[2], proof[1])
        if tag == "imp_e" and len(proof) == 4:
            source, source_proof, argument = proof[1:]
            return (node(source, "imp", 3) and self.formula(source, scope)
                    and conclusion == source[2]
                    and self._check(scope, context, source, source_proof)
                    and self._check(scope, context, source[1], argument))
        if tag == "all_i" and len(proof) == 2 and node(conclusion, "all", 2):
            return self._check(scope + 1, self.lifted_context(context, 1),
                               conclusion[1], proof[1])
        if tag == "all_e" and len(proof) == 4:
            source, witness, source_proof = proof[1:]
            return (node(source, "all", 2) and self.formula(source, scope)
                    and term(witness, scope)
                    and conclusion == self.instantiate(source[1], [witness])
                    and self._check(scope, context, source, source_proof))
        if tag == "ex_i" and len(proof) == 3 and node(conclusion, "ex", 2):
            witness, argument = proof[1:]
            return (term(witness, scope)
                    and self._check(scope, context, self.instantiate(conclusion[1], [witness]),
                                    argument))
        if tag == "ex_e" and len(proof) == 4:
            source, source_proof, branch = proof[1:]
            return (node(source, "ex", 2) and self.formula(source, scope)
                    and self._check(scope, context, source, source_proof)
                    and self._check(scope + 1, self.lifted_context(context, 1) + [source[1]],
                                    self.lift(conclusion, 1), branch))
        if tag == "absurd" and len(proof) == 2:
            return self._check(scope, context, ["bot"], proof[1])
        return False


check = Checker().check


# Standalone JSON interface; Python and its standard json library are shared dependencies.
if __name__ == "__main__":
    import json
    import sys
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python3 " + sys.argv[0] + " certificate.json")
    try:
        with open(sys.argv[1], encoding="utf-8") as stream:
            record = json.load(stream)
        if type(record) is not dict or set(record) != {"scope", "context", "conclusion", "proof"}:
            raise ValueError("Expected exactly scope, context, conclusion, proof")
        accepted = check(**record)
    except (OSError, ValueError, TypeError, RecursionError) as error:
        raise SystemExit("Invalid input: " + str(error))
    print("ACCEPT" if accepted else "REJECT")
    raise SystemExit(0 if accepted else 1)
