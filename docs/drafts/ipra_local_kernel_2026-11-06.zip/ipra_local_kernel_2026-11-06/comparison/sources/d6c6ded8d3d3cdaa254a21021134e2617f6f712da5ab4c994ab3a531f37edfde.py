"""A finite-tree certificate checker for the positive iPRA calculus.

Terms: ["v", i], ["0"], ["S", t], ["R", h, n, a, *parameters].
The frozen update h has local slots 0=state, 1=counter, 2,...=parameters.
Formulas: ["=", s, t], ["and"|"or"|"imp", A, B], ["all"|"ex", i, A].
Input: {"context": [A, ...], "goal": B, "proof": finite JSON proof tree}.
No proof search, arithmetic evaluation, or normalization is performed.
"""

import json
import sys


FALSITY = ["=", ["0"], ["S", ["0"]]]


class Invalid(Exception):
    pass


def require(condition):
    if not condition:
        raise Invalid


def natural(value):
    return type(value) is int and value >= 0


def term(node, bound=None):
    match node:
        case ["v", index]:
            return natural(index) and (bound is None or index < bound)
        case ["0"]:
            return True
        case ["S", value]:
            return term(value, bound)
        case ["R", update, counter, initial, *parameters]:
            return term(update, len(parameters) + 2) and all(
                term(value, bound) for value in [counter, initial, *parameters]
            )
    return False


def formula(node):
    match node:
        case ["=", left, right]:
            return term(left) and term(right)
        case [("and" | "or" | "imp"), left, right]:
            return formula(left) and formula(right)
        case [("all" | "ex"), variable, body]:
            return natural(variable) and formula(body)
    return False


def free(node):
    match node:
        case ["v", variable]:
            return {variable}
        case ["R", update, *arguments]:
            return set().union(*(free(value) for value in arguments))
        case [("all" | "ex"), variable, body]:
            return free(body) - {variable}
    return set().union(*(free(value) for value in node[1:]))


def substitute(node, replacements):
    """Simultaneous free substitution; reject capture; leave labels frozen."""
    tag = node[0]
    if tag == "v":
        return replacements.get(node[1], node)
    if tag == "R":
        return [tag, node[1], *(substitute(t, replacements) for t in node[2:])]
    if tag in ("all", "ex"):
        variable, body = node[1:]
        active = {
            key: value for key, value in replacements.items()
            if key != variable and key in free(body)
        }
        require(all(variable not in free(value) for value in active.values()))
        return [tag, variable, substitute(body, active)]
    return [tag, *(substitute(t, replacements) for t in node[1:])]


def infer(proof, context):
    """Infer a conclusion, or raise Invalid. Context entries are validated."""
    match proof:
        case ["hyp", index]:
            require(natural(index) and index < len(context))
            return context[index]
        case ["pair", left, right]:
            return ["and", infer(left, context), infer(right, context)]
        case ["proj", index, premise]:
            require(type(index) is int and index in (0, 1))
            conjunction = infer(premise, context)
            require(conjunction[0] == "and")
            return conjunction[index + 1]
        case ["in", index, other, premise]:
            require(type(index) is int and index in (0, 1) and formula(other))
            sides = [infer(premise, context), other]
            return ["or", *sides[::1 if index == 0 else -1]]
        case ["case", premise, left, right]:
            disjunction = infer(premise, context)
            require(disjunction[0] == "or")
            result = infer(left, context + [disjunction[1]])
            require(result == infer(right, context + [disjunction[2]]))
            return result
        case ["lam", assumption, body]:
            require(formula(assumption))
            return ["imp", assumption, infer(body, context + [assumption])]
        case ["app", function, argument]:
            implication = infer(function, context)
            require(implication[0] == "imp")
            require(implication[1] == infer(argument, context))
            return implication[2]
        case ["all", universal, eigenvariable, premise]:
            require(formula(universal) and universal[0] == "all")
            require(natural(eigenvariable))
            require(eigenvariable not in set().union(free(universal), *map(free, context)))
            body = substitute(universal[2], {universal[1]: ["v", eigenvariable]})
            require(infer(premise, context) == body)
            return universal
        case ["at", premise, value]:
            require(term(value))
            universal = infer(premise, context)
            require(universal[0] == "all")
            return substitute(universal[2], {universal[1]: value})
        case ["pack", existential, value, premise]:
            require(formula(existential) and existential[0] == "ex" and term(value))
            require(infer(premise, context) == substitute(
                existential[2], {existential[1]: value}
            ))
            return existential
        case ["unpack", premise, eigenvariable, body]:
            require(natural(eigenvariable))
            existential = infer(premise, context)
            require(existential[0] == "ex")
            require(eigenvariable not in set().union(free(existential), *map(free, context)))
            witness = substitute(existential[2], {existential[1]: ["v", eigenvariable]})
            result = infer(body, context + [witness])
            require(eigenvariable not in free(result))
            return result
        case ["eq", equality, variable, template, premise]:
            require(natural(variable) and formula(template))
            equation = infer(equality, context)
            require(equation[0] == "=")
            require(infer(premise, context) == substitute(template, {variable: equation[1]}))
            return substitute(template, {variable: equation[2]})
        case ["compute", call]:
            require(term(call) and call[0] == "R")
            update, counter, initial, *parameters = call[1:]
            if counter[0] == "0":
                value = initial
            else:
                require(counter[0] == "S")
                previous = ["R", update, counter[1], initial, *parameters]
                slots = [previous, counter[1], *parameters]
                value = substitute(update, dict(enumerate(slots)))
            return ["=", call, value]
        case ["closure", variable, equation]:
            require(natural(variable) and formula(equation) and equation[0] == "=")
            number = ["v", variable]
            boundary = ["or", ["=", number, ["0"]], equation]
            successor = substitute(equation, {variable: ["S", number]})
            return ["imp", ["all", variable, ["imp", boundary, successor]],
                    ["all", variable, boundary]]
    raise Invalid


def check(document):
    try:
        require(type(document) is dict and set(document) == {"context", "goal", "proof"})
        context = document["context"]
        require(type(context) is list and all(map(formula, context)))
        require(formula(document["goal"]))
        return infer(document["proof"], context) == document["goal"]
    except (Invalid, RecursionError):
        return False


if __name__ == "__main__":
    try:
        accepted = check(json.load(sys.stdin))
    except (ValueError, RecursionError):
        accepted = False
    print("ACCEPT" if accepted else "REJECT")
    sys.exit(0 if accepted else 1)
