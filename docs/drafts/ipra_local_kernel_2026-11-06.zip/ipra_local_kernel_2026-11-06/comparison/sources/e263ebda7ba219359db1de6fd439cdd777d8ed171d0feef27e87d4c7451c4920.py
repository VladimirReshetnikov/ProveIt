#!/usr/bin/env python3
"""A complete Hilbert proof checker for native-recursion iPRA.

Usage: python3 kernel.py certificate.json.
Terms: nonnegative integer variables; ["z"], ["s", t], ["r", n, a, h].
R binds state 0 and counter 1 in h only. Quantifiers bind variable 0.
Variables beyond the local binding depth are free variables. Formulas use
=, false, &, |, ->, all, ex. No equality-reflexivity
axiom is assumed. Input: {"proof": [certificate lines], "conclusion": A}.
Each schema line gives its name and all witnesses; mp/gen cite earlier lines.
"""
import json
import sys


# Result sort, followed by child sorts. e denotes an equation template.
GRAMMAR = {
    "z": ("t", ""), "s": ("t", "t"), "r": ("t", "ttt"),
    "=": ("f", "tt"), "&": ("f", "ff"), "|": ("f", "ff"),
    "->": ("f", "ff"), "all": ("f", "f"), "ex": ("f", "f"),
    "false": ("f", ""),
}
BINDERS = {"r": (0, 0, 2), "all": (1,), "ex": (1,)}
Z = ("z",)
D = ("=", Z, ("s", Z))
FALSE = ("false",)


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def wellformed(a, sort):
    if type(a) is int:
        return sort == "t" and a >= 0
    if type(a) is not tuple or not a or type(a[0]) is not str:
        return False
    if sort == "e":
        return a[0] == "=" and wellformed(a, "f")
    result, children = GRAMMAR.get(a[0], (None, ""))
    return (result == sort and len(a) == len(children) + 1
            and all(wellformed(x, s) for x, s in zip(a[1:], children)))


def walk(a, variable, depth=0):
    """Map free variables, retaining each node's locally bound variables."""
    if type(a) is int:
        return a if a < depth else variable(a - depth, depth)
    scopes = BINDERS.get(a[0], (0,) * (len(a) - 1))
    return (a[0], *(walk(x, variable, depth + b)
                   for x, b in zip(a[1:], scopes)))


def shift(a, amount):
    return walk(a, lambda i, depth: i + depth + amount)


def substitute(a, substitution):
    return walk(a, lambda i, depth: shift(substitution(i), depth))


def instantiate(body, term):
    return substitute(body, lambda i: term if i == 0 else i - 1)


def I(a, b):
    return ("->", a, b)


def recursion_step(n, a, h):
    r = ("r", n, a, h)
    value = substitute(h, lambda i: (r, n)[i] if i < 2 else i - 2)
    return ("=", ("r", ("s", n), a, h), value)


def induction(e):
    p = ("|", ("=", 0, Z), e)
    step = substitute(e, lambda i: ("s", 0) if i == 0 else i)
    return I(("all", I(p, step)), ("all", p))


# Templates are typed before a generator runs; all witnesses are explicit.
SCHEMAS = {
    "k": ("ff", lambda a, b: I(a, I(b, a))),
    "s": ("fff", lambda a, b, c: I(I(a, I(b, c)), I(I(a, b), I(a, c)))),
    "and1": ("ff", lambda a, b: I(("&", a, b), a)),
    "and2": ("ff", lambda a, b: I(("&", a, b), b)),
    "and": ("ff", lambda a, b: I(a, I(b, ("&", a, b)))),
    "or1": ("ff", lambda a, b: I(a, ("|", a, b))),
    "or2": ("ff", lambda a, b: I(b, ("|", a, b))),
    "or": ("fff", lambda a, b, c: I(I(a, c), I(I(b, c), I(("|", a, b), c)))),
    "explode": ("f", lambda a: I(FALSE, a)),
    "sep": ("", lambda: I(D, FALSE)),
    "all": ("ft", lambda a, t: I(("all", a), instantiate(a, t))),
    "ex": ("ft", lambda a, t: I(instantiate(a, t), ("ex", a))),
    "all_move": ("ff", lambda a, b: I(("all", I(shift(a, 1), b)), I(a, ("all", b)))),
    "ex_move": ("ff", lambda a, b: I(("all", I(a, shift(b, 1))), I(("ex", a), b))),
    "eq": ("ttf", lambda s, t, a: I(("=", s, t), I(instantiate(a, s), instantiate(a, t)))),
    "r0": ("tt", lambda a, h: ("=", ("r", Z, a, h), a)),
    "rs": ("ttt", recursion_step),
    "ind": ("e", induction),
}


def premise(theorems, index):
    require(type(index) is int and 0 <= index < len(theorems))
    return theorems[index]


def infer(proof):
    """Infer and return every theorem in an immutable certificate sequence."""
    require(type(proof) is tuple and len(proof) > 0)
    theorems = []
    for line in proof:
        require(type(line) is tuple and len(line) > 0 and type(line[0]) is str)
        name, arguments = line[0], line[1:]
        if name == "mp":
            require(len(arguments) == 2)
            implication, antecedent = (premise(theorems, i) for i in arguments)
            require(implication[0] == "->" and implication[1] == antecedent)
            result = implication[2]
        elif name == "gen":
            require(len(arguments) == 2)
            old, variable = premise(theorems, arguments[0]), arguments[1]
            require(type(variable) is int and variable >= 0)
            body = substitute(old, lambda i: 0 if i == variable else i + 1)
            result = ("all", body)
        else:
            require(name in SCHEMAS)
            sorts, generate = SCHEMAS[name]
            require(len(arguments) == len(sorts)
                    and all(wellformed(a, s) for a, s in zip(arguments, sorts)))
            result = generate(*arguments)
        theorems.append(result)
    return theorems


def freeze(a):
    return tuple(freeze(x) for x in a) if type(a) is list else a


def check(document):
    require(type(document) is dict and set(document) == {"proof", "conclusion"})
    proof, conclusion = freeze(document["proof"]), freeze(document["conclusion"])
    require(wellformed(conclusion, "f"))
    require(infer(proof)[-1] == conclusion)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
