"""Shared trusted syntax, substitution, arithmetic leaves, and safe input."""

import json
import sys


class Rejected(Exception):
    pass


def need(condition, message="invalid certificate"):
    if not condition:
        raise Rejected(message)


def head(node):
    need(type(node) is list and node and type(node[0]) is str, "bad node")
    return node[0]


def arity(node, count):
    need(len(node) == count + 1, "wrong number of arguments")


def V(index):
    return ["v", index]


Z = ["z"]
B = ["bot"]


def S(term):
    return ["s", term]


def Eq(left, right):
    return ["eq", left, right]


def R(counter, initial, update):
    return ["r", counter, initial, update]


# Each child records its sort and the number of number variables it binds.
COMMON = {
    "z": ("term", ()),
    "s": ("term", (("term", 0),)),
    "r": ("term", (("term", 0), ("term", 0), ("term", 2))),
    "eq": ("formula", (("term", 0), ("term", 0))),
    "bot": ("formula", ()),
}


def well(node, sort, scope, syntax):
    tag = head(node)
    if tag == "v":
        arity(node, 1)
        need(sort == "term" and type(node[1]) is int and 0 <= node[1] < scope,
             "ill-scoped variable")
        return
    need(tag in syntax, "unknown constructor")
    result, children = syntax[tag]
    need(result == sort, "wrong syntactic sort")
    arity(node, len(children))
    for child, (child_sort, bound) in zip(node[1:], children):
        well(child, child_sort, scope + bound, syntax)


def variables(node, action, syntax, depth=0):
    if node[0] == "v":
        return action(node[1], depth)
    return [node[0]] + [
        variables(child, action, syntax, depth + bound)
        for child, (_, bound) in zip(node[1:], syntax[node[0]][1])
    ]


def shift(node, amount, syntax, cutoff=0):
    return variables(node, lambda index, depth:
                     V(index if index < depth + cutoff else index + amount), syntax)


def instantiate(body, values, syntax):
    def replace(index, depth):
        if index < depth:
            return V(index)
        slot = index - depth
        if slot < len(values):
            return shift(values[slot], depth, syntax)
        return V(index - len(values))
    return variables(body, replace, syntax)


def lifted(context, syntax):
    return [shift(formula, 1, syntax) for formula in context]


def successor_instance(template, syntax):
    return instantiate(shift(template, 1, syntax, cutoff=1), [S(V(0))], syntax)


def common_rule(proof, goal, context, scope, syntax, check, separation):
    tag = head(proof)
    if tag == "hyp":
        arity(proof, 0)
        need(goal in context, "missing assumption")
    elif tag == "refl":
        arity(proof, 0)
        need(goal[0] == "eq" and goal[1] == goal[2], "not reflexive")
    elif tag == "eqE":
        arity(proof, 5)
        left, right, template, equal, source = proof[1:]
        well(left, "term", scope, syntax)
        well(right, "term", scope, syntax)
        well(template, "formula", scope + 1, syntax)
        need(goal == instantiate(template, [right], syntax), "wrong equality target")
        check(equal, Eq(left, right), context, scope)
        check(source, instantiate(template, [left], syntax), context, scope)
    elif tag == "abort":
        arity(proof, 1)
        check(proof[1], B, context, scope)
    elif tag == "sep":
        arity(proof, 0)
        need(goal == separation, "wrong separation axiom")
    elif tag in ("r0", "rs"):
        arity(proof, 0)
        need(goal[0] == "eq" and goal[1][0] == "r", "not a recursion equation")
        counter, initial, update = goal[1][1:]
        if tag == "r0":
            need(counter == Z and goal[2] == initial, "wrong recursion base")
        else:
            need(counter[0] == "s", "not a successor counter")
            previous = counter[1]
            unfolded = instantiate(update, [R(previous, initial, update), previous], syntax)
            need(goal[2] == unfolded, "wrong recursion step")
    else:
        return False
    return True


def verify(document, syntax, check):
    need(type(document) is dict and set(document) == {"scope", "context", "goal", "proof"},
         "expected scope, context, goal, proof")
    scope, context, goal = document["scope"], document["context"], document["goal"]
    need(type(scope) is int and scope >= 0, "bad number-variable scope")
    need(type(context) is list, "bad context")
    well(goal, "formula", scope, syntax)
    for formula in context:
        well(formula, "formula", scope, syntax)
    check(document["proof"], goal, context, scope)


def main(syntax, check):
    try:
        need(len(sys.argv) == 2, "usage: checker.py CERTIFICATE.json (or - for stdin)")
        if sys.argv[1] == "-":
            document = json.load(sys.stdin)
        else:
            with open(sys.argv[1], encoding="utf-8") as stream:
                document = json.load(stream)
        verify(document, syntax, check)
    except (Rejected, ValueError, TypeError, KeyError, IndexError, RecursionError, OSError) as error:
        print(json.dumps({"accepted": False, "error": str(error)}))
        return 1
    print(json.dumps({"accepted": True}))
    return 0
