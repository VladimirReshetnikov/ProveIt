"""A Hilbert checker with de Bruijn quantifiers and a native recursion binder.

Terms: ["v",i], ["0"], ["S",t], ["R",n,a,h]. The last argument h binds
indices 0=state and 1=counter; its remaining indices refer to outer variables.
Formulas: equality; and/or/imp; ["all",A] and ["ex",A], each binding index 0.
The input has exactly "goal" and "proof"; the latter is a theorem sequence.
Only MP and Gen reference earlier lines. No normalization or search is used.
"""

import json
import sys


FALSITY = ["false"]


class Invalid(Exception):
    pass


def require(condition):
    if not condition:
        raise Invalid


def natural(value):
    return type(value) is int and value >= 0


def term(node):
    match node:
        case ["v", index]:
            return natural(index)
        case ["0"]:
            return True
        case ["S", value]:
            return term(value)
        case ["R", counter, initial, update]:
            return all(map(term, [counter, initial, update]))
    return False


def formula(node):
    match node:
        case ["false"]:
            return True
        case ["=", left, right]:
            return term(left) and term(right)
        case [("and" | "or" | "imp"), left, right]:
            return formula(left) and formula(right)
        case [("all" | "ex"), body]:
            return formula(body)
    return False


def substitute(node, values, extra=0, depth=0):
    """Replace free indices <len(values); shift the rest by extra-len(values)."""
    match node:
        case ["v", index]:
            if index < depth:
                return node
            if index - depth < len(values):
                return substitute(values[index - depth], [], depth)
            return ["v", index - len(values) + extra]
        case ["R", counter, initial, update]:
            return ["R", substitute(counter, values, extra, depth),
                    substitute(initial, values, extra, depth),
                    substitute(update, values, extra, depth + 2)]
        case [("all" | "ex"), body]:
            return [node[0], substitute(body, values, extra, depth + 1)]
    return [node[0], *(substitute(t, values, extra, depth) for t in node[1:])]


def implies(left, right):
    return ["imp", left, right]


def earlier(theorems, index):
    require(natural(index) and index < len(theorems))
    return theorems[index]


def infer(record, theorems):
    """Return the theorem licensed by one record, or raise Invalid."""
    match record:
        case ["logic", index, a, b, c]:
            require(natural(index) and index < 8 and all(map(formula, [a, b, c])))
            conjunction, disjunction = ["and", a, b], ["or", a, b]
            schemes = [
                implies(a, implies(b, a)),
                implies(implies(a, implies(b, c)),
                        implies(implies(a, b), implies(a, c))),
                implies(a, implies(b, conjunction)),
                implies(conjunction, a),
                implies(conjunction, b),
                implies(a, disjunction),
                implies(b, disjunction),
                implies(implies(a, c),
                        implies(implies(b, c), implies(disjunction, c))),
            ]
            return schemes[index]
        case ["forall_elim", body, value]:
            require(formula(body) and term(value))
            return implies(["all", body], substitute(body, [value]))
        case ["forall_shift", a, b]:
            require(formula(a) and formula(b))
            return implies(["all", implies(substitute(a, [], 1), b)],
                           implies(a, ["all", b]))
        case ["exists_intro", body, value]:
            require(formula(body) and term(value))
            return implies(substitute(body, [value]), ["ex", body])
        case ["exists_shift", a, b]:
            require(formula(a) and formula(b))
            return implies(["all", implies(a, substitute(b, [], 1))],
                           implies(["ex", a], b))
        case ["equality", template, left, right]:
            require(formula(template) and term(left) and term(right))
            return implies(["=", left, right],
                           implies(substitute(template, [left]),
                                   substitute(template, [right])))
        case ["compute", call]:
            require(term(call) and call[0] == "R")
            counter, initial, update = call[1:]
            if counter[0] == "0":
                value = initial
            else:
                require(counter[0] == "S")
                previous = ["R", counter[1], initial, update]
                value = substitute(update, [previous, counter[1]])
            return ["=", call, value]
        case ["closure", equation]:
            require(formula(equation) and equation[0] == "=")
            number = ["v", 0]
            boundary = ["or", ["=", number, ["0"]], equation]
            successor = substitute(equation, [["S", number]], 1)
            return implies(["all", implies(boundary, successor)], ["all", boundary])
        case ["reflexivity", value]:
            require(term(value))
            return ["=", value, value]
        case ["false_elim", body]:
            require(formula(body))
            return implies(FALSITY, body)
        case ["separation"]:
            return implies(["=", ["0"], ["S", ["0"]]], FALSITY)
        case ["mp", function, argument]:
            implication = earlier(theorems, function)
            require(implication[0] == "imp")
            require(implication[1] == earlier(theorems, argument))
            return implication[2]
        case ["gen", premise]:
            return ["all", earlier(theorems, premise)]
    raise Invalid


def check(document):
    try:
        require(type(document) is dict and set(document) == {"goal", "proof"})
        require(formula(document["goal"]) and type(document["proof"]) is list)
        theorems = []
        for record in document["proof"]:
            theorems.append(infer(record, theorems))
        return bool(theorems) and theorems[-1] == document["goal"]
    except (Invalid, RecursionError):
        return False


if __name__ == "__main__":
    try:
        accepted = check(json.load(sys.stdin))
    except (ValueError, RecursionError):
        accepted = False
    print("ACCEPT" if accepted else "REJECT")
    sys.exit(0 if accepted else 1)
