"""iPRA with universal implication and finite-choice existential rows.

Formulas: ["eq",s,t], ["U",name,A,B], ["E",name,*rows].
Each row is ["row",A,...]. E means exists name (a disjunction of the
rows' conjunctions); name=None omits the quantifier. No rows is genuine
falsity; an empty row is truth.
"""

from rows_common import Base, ZERO, ONE, FALSE, natural, require, run


class Kernel(Base):
    separation = ["U", 0, ["eq", ZERO, ONE], FALSE]

    def logical(self, proof, context, goal):
        match proof:
            case ["U_intro", name, premise]:
                require(goal[0] == "U")
                self.fresh(name, context + [goal])
                left, right = [self.substitute(child, goal[1], ["v", name])
                               for child in goal[2:]]
                self.check(premise, context + [left], right)
            case ["U_elim", universal, term, premise, argument]:
                self.formula(universal)
                self.term(term)
                require(universal[0] == "U")
                left, right = [self.substitute(child, universal[1], term)
                               for child in universal[2:]]
                require(goal == right)
                self.check(premise, context, universal)
                self.check(argument, context, left)
            case ["E_intro", term, side, premises]:
                require(goal[0] == "E" and natural(side) and side < len(goal) - 2)
                require(type(premises) is list and len(premises) == len(goal[side + 2]) - 1)
                self.term(term)
                for proof, part in zip(premises, goal[side + 2][1:]):
                    self.check(proof, context, self.substitute(part, goal[1], term))
            case ["E_elim", existential, name, premise, branches]:
                self.formula(existential)
                require(existential[0] == "E" and type(branches) is list)
                require(len(branches) == len(existential) - 2)
                self.fresh(name, context + [goal, existential])
                self.check(premise, context, existential)
                for proof, row in zip(branches, existential[2:]):
                    parts = [self.substitute(part, existential[1], ["v", name])
                             for part in row[1:]]
                    self.check(proof, context + parts, goal)
            case _:
                require(False)


if __name__ == "__main__":
    raise SystemExit(run(Kernel))
