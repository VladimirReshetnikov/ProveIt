"""Complete iPRA proof checker with genuine falsity; finite JSON input.

Zero is -1; nonnegative integers are number variables.  Pi and Sigma
bind one variable in both children; recursion binds two in its body.
See report.pdf for all rules, metatheory, provenance and trust boundary.
"""

import json
import sys

ZERO = -1
FALSE = ["false"]
CLASH = ["=", ZERO, ["s", ZERO]]
ARITIES = {"s": 1, "r": 3, "=": 2, "pi": 2, "sig": 2, "false": 0}
BINDERS = ("pi", "sig")


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def wf(a, formula=False):
    if type(a) is int:
        return not formula and a >= -1
    return (type(a) is list and bool(a) and a[0] in ARITIES
            and len(a) == ARITIES[a[0]] + 1
            and (a[0] in ("=", "pi", "sig", "false")) == formula
            and all(wf(b, a[0] in BINDERS) for b in a[1:]))


def walk(a, f, d=0):
    if type(a) is int:
        return a if a < d else f(a - d, d)
    return [a[0], *(walk(b, f, d + (2 if a[0] == "r" and i == 2 else
                                  1 if a[0] in BINDERS else 0))
                    for i, b in enumerate(a[1:]))]


def shift(a, n=1):
    return walk(a, lambda i, d: i + d + n)


def subst(a, env):
    return walk(a, lambda i, d: shift(env(i), d))


def inst(a, t):
    return subst(a, lambda i: t if i == 0 else i - 1)


def infer(p, g):
    match p:
        case ["hyp", a]:
            return g[g.index(a)]
        case ["pi", a, q]:
            require(wf(a, True))
            return ["pi", a, infer(q, [*map(shift, g), a])]
        case ["pair", t, p, q]:
            require(wf(t))
            h = [*map(shift, g), ["=", 0, shift(t)]]
            return ["sig", infer(p, h), infer(q, h)]
        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            require(wf(a, tag != "pi"))
            if tag == "sig":
                require(infer(q, [*map(shift, g), *e[1:]]) == shift(a))
                return a
            b, c = (inst(a, t) if tag == "=" else inst(t, a) for t in e[1:])
            require(infer(q, g) == b)
            return c
        case ["bridge", p]:
            return [CLASH, FALSE][[FALSE, CLASH].index(infer(p, g))]
        case ["rec", ["r", n, a, h] as r]:
            require(wf(r))
            if n == ZERO:
                b = a
            else:
                require(n[0] == "s")
                b = subst(h, lambda i: (["r", n[1], a, h], n[1])[i]
                          if i < 2 else i - 2)
            return ["=", r, b]
        case ["nat", a]:
            require(wf(a, True))
            base = shift(inst(a, ZERO))
            h = a if a[0] == "=" else base
            successor = subst(a, lambda i: ["s", 0] if i == 0 else i)
            step = ["pi", h, successor]
            return ["pi", base, ["pi", shift(step, 2), shift(a)]]
        case _:
            raise ValueError("invalid certificate")


def check(data):
    require(type(data) is dict and set(data) == {"assumptions", "goal", "proof"})
    g, a, p = (data[key] for key in ("assumptions", "goal", "proof"))
    require(type(g) is list and all(wf(b, True) for b in g) and wf(a, True))
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
