"""Complete iPRA certificate checker. See report.pdf for the full theory.

Falsity has the explicit arithmetic conversion bottom = (0 = S0).
The six proof records share elimination and use witness equations.
Only finite JSON is input; no proof generator is trusted.
"""

import json
import sys

ZERO = -1


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


def walk(a, f, d=0, formula=None):
    if type(a) is int:
        require(not formula and a >= -1)
        return a if a < d else f(a - d, d)
    k = ("s", "r", "=", "pi", "sig").index(a[0])
    require(type(a) is list and len(a) == (2, 4, 3, 3, 3)[k]
            and (formula is None or formula == (k > 1)))
    return [a[0], *(walk(b, f, d + (2 if k == 1 and i == 2 else
                                  1 if k > 2 else 0), k > 2)
                    for i, b in enumerate(a[1:]))]


def validate(a, formula=False):
    return walk(a, lambda i, d: i + d, formula=formula)

def shift(a, n=1):
    return walk(a, lambda i, d: i + d + n)


def subst(a, env):
    return walk(a, lambda i, d: shift(env(i), d))


def inst(a, t):
    return subst(a, lambda i: t if i == 0 else i - 1)


def infer(p, g):
    match p:
        case ["hyp", key]:
            return g[g.index(key)]
        case ["pi", a, q]:
            validate(a, True)
            return ["pi", a, infer(q, [*map(shift, g), a])]
        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            if tag == "sig":
                require(infer(q, [*map(shift, g), *e[1:]]) == shift(a))
                return a
            if tag == "pi":
                validate(a)
            b, c = (inst(a, t) if tag == "=" else inst(t, a) for t in e[1:])
            require(infer(q, g) == b)
            return c
        case ["pair", t, p, q]:
            validate(t)
            h = [*map(shift, g), ["=", 0, shift(t)]]
            return ["sig", infer(p, h), infer(q, h)]
        case ["rec", ["r", n, a, h] as r]:
            validate(r)
            if n == ZERO:
                b = a
            else:
                require(n[0] == "s")
                b = subst(h, lambda i: (["r", n[1], a, h], n[1])[i]
                          if i < 2 else i - 2)
            return ["=", r, b]
        case ["nat", a]:
            validate(a, True)
            base = inst(a, ZERO)
            h = a if a[0] == "=" else shift(base)
            step = ["pi", h, subst(a, lambda i: ["s", 0] if i == 0 else i)]
            return ["pi", ["sig", shift(base, 2), shift(step, 2)], a]
        case _:
            raise ValueError("invalid certificate")


def erase(a):
    if a == ["false"]:
        return ["=", ZERO, ["s", ZERO]]
    return list(map(erase, a)) if type(a) is list else a


def check(data):
    g, a, p = erase(data)
    require(type(g) is list)
    g = [validate(b, True) for b in g]
    validate(a, True)
    require(infer(p, g) == a)
    return True


if __name__ == "__main__":
    try:
        require(len(sys.argv) == 2)
        with open(sys.argv[1], encoding="utf-8") as stream:
            check(json.load(stream))
        print("ACCEPT")
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        print("REJECT")
        sys.exit(1)
