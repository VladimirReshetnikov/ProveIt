#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error report.tex > build/latex-pass-1.log
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error report.tex > build/latex-pass-2.log
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error report.tex > build/latex-pass-3.log
printf '%s\n' 'Built report.pdf.'
