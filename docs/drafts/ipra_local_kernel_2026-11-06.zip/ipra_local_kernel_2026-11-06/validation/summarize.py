"""Produce compact LaTeX and JSON summaries from the actual validation results."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    audit = json.loads((ROOT/"audit_results.json").read_text())
    examples = json.loads((ROOT/"example_results.json").read_text())
    if audit["checker_sha256"] != examples["checker_sha256"]:
        raise ValueError("Validation results refer to different checker versions")
    if audit["failures"] or examples["failures"]:
        raise ValueError("Validation has unresolved failures")
    macros = {
        "AuditSyntax": audit["counts"]["syntax"],
        "AuditSubstitutions": audit["counts"]["named_substitution"],
        "AuditCertificates": audit["counts"]["certificates"],
        "AuditPositive": audit["certificate_positive"],
        "AuditNegative": audit["certificate_negative"],
        "AuditCLI": audit["counts"]["cli"],
        "AuditMutations": audit["mutations_detected"],
        "ExampleOccurrences": examples["public_example_occurrences"],
        "ExampleOriginalDocuments": examples["unique_public_original_documents"],
        "ExamplePublicProofs": examples["unique_public_translated_certificates"],
        "ExamplePublicSequents": examples["unique_public_sequents"],
        "ExampleSelectedLogic": examples["selected_logic_occurrences"],
        "ExampleTotalProofs": examples["unique_total_translated_certificates"],
        "ExampleTotalSequents": examples["unique_total_sequents"],
        "ExampleSyntheticBridges": examples["synthetic_assumed_step_bridge_cases"],
    }
    text = "% Generated from audit_results.json and example_results.json.\n"
    text += "% Checker SHA-256: "+audit["checker_sha256"]+"\n"
    text += "".join("\\newcommand{\\"+name+"}{"+str(value)+"}\n" for name, value in macros.items())
    (ROOT/"summary.tex").write_text(text)
    result = {"checker_sha256": audit["checker_sha256"], "python_version": audit["python_version"],
              "counts": audit["counts"], "certificate_positive": audit["certificate_positive"],
              "certificate_negative": audit["certificate_negative"],
              "mutations_detected": audit["mutations_detected"],
              "public_example_occurrences": examples["public_example_occurrences"],
              "unique_public_source_documents": examples["unique_public_original_documents"],
              "unique_public_target_certificates": examples["unique_public_translated_certificates"],
              "unique_public_sequents": examples["unique_public_sequents"],
              "selected_logic_occurrences": examples["selected_logic_occurrences"],
              "unique_total_target_certificates": examples["unique_total_translated_certificates"],
              "unique_total_sequents": examples["unique_total_sequents"],
              "synthetic_assumed_step_bridge_cases": examples["synthetic_assumed_step_bridge_cases"],
              "failures": 0,
              "qualification": "Categories overlap and must not be summed as independent research evidence. These are finite regression tests, not formal metatheorems."}
    (ROOT/"summary.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
