"""Independent finite audit of syntax, binding and certificate boundaries.

Expected substitutions use named binders (oracle.py), never the candidate's
scope table or substitution routine.  Expected certificate verdicts are fixed
below.  Tests and deliberate mutation probes are regression evidence, not a
formal soundness, completeness, bi-interpretability or consistency proof.
"""

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import types

from oracle import BadSyntax, DeletedParameter, subst, well_formed

ROOT = Path(__file__).resolve().parent
Z = -1
T = ["=", Z, Z]
D = ["=", Z, ["s", Z]]


def eq(a, b):
    return ["=", a, b]


def attempt(function, *args, **kwargs):
    try:
        return True, function(*args, **kwargs), None
    except Exception as exc:
        return False, None, type(exc).__name__


def load(path):
    spec = importlib.util.spec_from_file_location("independently_audited_checker", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def syntax_samples():
    values = [None, False, True, -2, -1, 0, 4, -1.0, 0.0, 1.0, 0.25,
              "", "s", "ss", "r", "rrrr", "=", "===", "pi", "ex",
              {}, {"s": 0}, {"=": 0, "s": 1, "ss": 2}, [],
              ["false"], ["unknown", T], ["s"], ["s", Z], ["s", Z, Z],
              ["r", Z, Z], ["r", Z, Z, 0], ["r", Z, Z, 0, 1],
              ["="], ["=", Z], T, ["=", Z, Z, Z],
              ["pi"], ["pi", T], ["pi", T, T], ["pi", T, T, T],
              ["ex"], ["ex", T], ["ex", T, T]]
    for bad in (False, 0.0, None, -2, [], T, ["s"], {"s": Z}):
        values.extend([["s", bad], ["r", Z, Z, bad],
                       ["=", Z, bad], ["ex", ["=", 0, bad]]])
    values.extend([["pi", ["s", Z], T], ["ex", 0], ["=", T, Z]])
    return values


def random_expression(rng, formula, depth):
    if not formula:
        if not depth or rng.randrange(3) == 0:
            return rng.randrange(-1, 7)
        if rng.randrange(2):
            return ["s", random_expression(rng, False, depth-1)]
        return ["r", *(random_expression(rng, False, depth-1) for _ in range(3))]
    if not depth or rng.randrange(3) == 0:
        return eq(random_expression(rng, False, depth), random_expression(rng, False, depth))
    if rng.randrange(2):
        return ["pi", random_expression(rng, True, depth-1),
                random_expression(rng, True, depth-1)]
    return ["ex", random_expression(rng, True, depth-1)]


def substitution_cases():
    expressions = [(False, Z), (False, 0), (False, 4),
                   (False, ["r", 0, 1, ["r", 2, 3, ["s", 4]]]),
                   (False, ["r", ["s", 2], 0, ["s", 1]]),
                   (True, eq(0, 1)),
                   (True, ["pi", eq(0, 1), ["ex", eq(0, 3)]]),
                   (True, ["ex", ["pi", eq(0, 2), eq(1, 4)]]),
                   (True, ["pi", T, ["ex", eq(["r", Z, 1, 4], 3)]]),
                   (True, eq(["r", 0, 1, ["s", 2]], ["r", 2, 0, 3]))]
    rng = random.Random(20261107)
    expressions += [(bool(i % 2), random_expression(rng, bool(i % 2), 3))
                    for i in range(10)]
    environments = [(0,), (1,), (Z, -1), (["s", 0], 0),
                    (["r", 1, 0, ["s", 2]], ["s", 1], -2)]
    rows = []
    for i, (formula, expression) in enumerate(expressions):
        for depth in (0, 1, 3):
            for j, environment in enumerate(environments):
                try:
                    expected = subst(expression, environment, depth, formula)
                    valid = True
                except DeletedParameter:
                    expected, valid = None, False
                rows.append({"label": f"named:{i}:{depth}:{j}", "expression": expression,
                             "environment": list(environment), "depth": depth,
                             "formula": formula, "expected_valid": valid, "expected": expected})
    return rows


def certificate_cases():
    rows = []

    def add(label, data, expected, group):
        rows.append({"label": label, "data": data, "expected": expected, "group": group})

    def yes(label, data, group="rules"):
        add(label, data, True, group)

    def no(label, data, group="rules"):
        add(label, data, False, group)

    yes("hypothesis", [[T], T, 0], "lookup")
    yes("last-hypothesis-alias", [[D, T], T, -1], "lookup")
    yes("boolean-false-hypothesis-alias", [[T], T, False], "lookup")
    yes("boolean-true-hypothesis-alias", [[D, T], T, True], "lookup")
    no("float-is-not-a-hypothesis-index", [[T], T, 0.0], "lookup")
    no("out-of-range-hypothesis", [[T], T, 1], "lookup")
    no("formula-is-not-an-index", [[T], T, T], "lookup")
    no("empty-context-falsity", [[], D, 0], "consistency_regression")

    for i, a in enumerate([T, D, eq(0, 2), ["ex", eq(0, 1)],
                            ["pi", eq(0, 2), ["ex", eq(0, 3)]]]):
        yes(f"identity-guard:{i}", [[], ["pi", a, a], ["lam", a, 0]])
    free = eq(0, Z)
    yes("universal-keeps-old-parameter", [[free], ["pi", T, eq(1, Z)], ["lam", T, 0]], "eigenvariables")
    no("universal-rejects-parameter-capture", [[free], ["pi", T, free], ["lam", T, 0]], "eigenvariables")

    witnesses = [Z, 0, ["s", 2], ["r", 1, 0, ["s", 2]]]
    matrices = [T, eq(0, 1), ["ex", eq(0, 1)],
                ["pi", eq(0, 2), ["ex", eq(["r", 2, 3, 5], 2)]]]
    for i, (w, matrix) in enumerate(zip(witnesses, matrices)):
        guard = eq(0, 2)
        premise = ["pi", guard, matrix]
        left = subst(guard, (w, -1))
        right = subst(matrix, (w, -1))
        yes(f"guarded-use:{i}", [[premise, left], right, ["use", 0, w, 1]])
        no(f"guarded-use-wrong-premise:{i}", [[premise, D], right, ["use", 0, w, 1]], "premises")
        witness_eq = eq(0, subst(w, formula=False))
        yes(f"witness-pack:{i}", [[], ["ex", witness_eq], ["pack", w, 0]])
        equality = eq(Z, w)
        before = subst(matrix, (Z, -1))
        after = subst(matrix, (w, -1))
        yes(f"transport-under-binders:{i}", [[equality, before], after, ["use", 0, matrix, 1]])
    no("equality-use-wrong-minor", [[eq(Z, ["s", Z]), D], T,
                                    ["use", 0, T, 1]], "premises")

    closed_bodies = [T, ["pi", eq(0, 0), eq(0, 0)], ["ex", eq(0, 0)],
                     eq(["r", Z, Z, ["s", 0]], ["r", Z, Z, ["s", 1]]),
                     ["pi", T, ["ex", eq(["r", Z, 1, ["s", 3]], 1)]]]
    for i, body in enumerate(closed_bodies):
        yes(f"existential-keeps-local-binders:{i}", [[["ex", body]], body,
                                                  ["use", 0, body, 1]], "eigenvariables")
    yes("existential-decrements-outer-parameter", [[["ex", eq(1, 1)]], eq(0, 0),
                                                   ["use", 0, eq(0, 0), 1]], "eigenvariables")
    escape_bodies = [eq(0, Z), ["pi", T, eq(1, 1)], ["ex", eq(1, 1)],
                     eq(["r", Z, Z, 2], Z),
                     ["pi", T, ["ex", eq(["r", Z, Z, 4], Z)]]]
    for i, body in enumerate(escape_bodies):
        no(f"existential-rejects-escaped-witness:{i}", [[["ex", body]], body,
                                                      ["use", 0, body, 1]], "eigenvariables")
    no("existential-missing-minor", [[["ex", T]], T, ["use", 0, T]], "arity")
    no("existential-missing-conclusion", [[["ex", T]], T, ["use", 0, 1]], "arity")
    no("existential-extra-field", [[["ex", T]], T, ["use", 0, T, 1, 1]], "arity")
    no("existential-wrong-minor", [[["ex", T], D], T, ["use", 0, T, 1]], "premises")
    no("existential-wrong-conclusion", [[["ex", T]], D, ["use", 0, D, 1]], "premises")
    yes("existential-old-parameter-retained", [[["ex", T], free], free,
                                             ["use", 0, free, 1]], "eigenvariables")
    no("existential-old-parameter-misnumbered", [[["ex", T], free], eq(1, Z),
                                               ["use", 0, eq(1, Z), 1]], "eigenvariables")
    for i, bad in enumerate([eq(True, True), eq(-1.0, -1.0), ["s", Z], ["ex", False]]):
        # The explicit existential result is intermediate, so top-level goal
        # validation alone cannot replace its own validation.
        hidden = ["use", 0, bad, 1]
        no(f"hidden-malformed-existential-result:{i}", [[["ex", T], eq(0, 0), T], T,
               ["use", hidden, T, 2]], "unused_syntax")

    bad_terms = [None, False, True, -2, -1.0, 0.0, 1.0, [], ["s"], ["s", Z, Z], T, {"s": Z}]
    for i, bad in enumerate(bad_terms):
        no(f"unused-witness-use:{i}", [[["pi", T, T], T], T,
                                       ["use", 0, bad, 1]], "unused_syntax")
        no(f"unused-witness-pack:{i}", [[T], ["ex", T], ["pack", bad, 0]], "unused_syntax")
        # A constant transport predicate hides the bad equality unless the whole
        # recursor, including its unused update, is checked before inference.
        no(f"hidden-malformed-rec-update:{i}", [[T], T,
               ["use", ["r", Z, Z, bad], T, 0]], "unused_syntax")
    for i, n in enumerate([0, 1, False, 0.0, ["r", Z, Z, 0], ["s"], ["s", Z, Z]]):
        no(f"recursor-nonconstructor:{i}", [[T], T,
               ["use", ["r", n, Z, 0], T, 0]], "arithmetic")
    for i, body in enumerate([Z, 0, 1, 2, ["s", 0], ["r", 1, 0, ["s", 2]]]):
        zero = ["r", Z, ["s", 0], body]
        yes(f"recursor-base:{i}", [[], eq(zero, ["s", 0]), zero], "arithmetic")
        n, initial = ["r", 0, Z, 1], ["s", 2]
        step = ["r", ["s", n], initial, body]
        rhs = subst(body, (["r", n, initial, body], n, -2), formula=False)
        yes(f"recursor-step:{i}", [[], eq(step, rhs), step], "arithmetic")
        no(f"recursor-wrong-result:{i}", [[], eq(step, ["s", rhs]), step], "arithmetic")

    numerical = [eq(0, 0), eq(0, 3), ["ex", eq(0, 1)],
                 ["pi", eq(0, 1), eq(1, 0)],
                 ["ex", ["pi", eq(0, 2), eq(1, 4)]]]
    for i, a in enumerate(numerical):
        base, successor = subst(a, (Z, 0)), subst(a, (["s", 0], 0))
        h = a if a[0] == "=" else base
        premise, goal = ["pi", h, successor], ["pi", base, a]
        # This is an arbitrary assumed step theorem, not a syntactic lambda.
        yes(f"numerical-from-step-assumption:{i}", [[premise], goal,
              ["nat", a, ["use", 0, 0, 1]]], "numerical_rules")
        alternate_h = base if a[0] == "=" else a
        if alternate_h != h:
            no(f"reject-wrong-numerical-guard:{i}", [[["pi", alternate_h, successor]], goal,
                   ["nat", a, ["use", 0, 0, 1]]], "induction_restriction")
        if successor != base:
            no(f"reject-wrong-numerical-successor:{i}", [[["pi", h, base]], goal,
                   ["nat", a, ["use", 0, 0, 1]]], "induction_restriction")
        no(f"reject-missing-numerical-step:{i}", [[], goal, ["nat", a, 0]], "induction_restriction")

    for i, a in enumerate([None, False, True, -1.0, 0.0, [], ["ex", True], eq(True, True), eq(0.0, 0.0)]):
        no(f"invalid-goal:{i}", [[T], a, 0], "statement_boundary")
        no(f"invalid-unused-context:{i}", [[T, a], T, 0], "statement_boundary")
    for i, data in enumerate([None, [], [[], T], [[], T, 0, 0], ["", T, 0], [{}, T, 0]]):
        no(f"invalid-document:{i}", data, "statement_boundary")
    for i, p in enumerate([["lam", T], ["lam", T, 0, 0], ["pack", Z],
                            ["pack", Z, 0, 0], ["nat", eq(0, 0)],
                            ["nat", eq(0, 0), 0, 0], ["use", 0, Z], ["unknown", 0]]):
        no(f"invalid-certificate-arity:{i}", [[T], T, p], "arity")
    return rows


def certificate_results(kernel, cases):
    results = []
    for case in cases:
        ok, value, error = attempt(kernel.check, case["data"])
        actual = ok
        results.append({"label": case["label"], "group": case["group"],
                        "expected": case["expected"], "actual": actual,
                        "passed": actual == case["expected"], "exception": error})
    return results


def mutation_sensitivity(source, cases):
    mutations = [
        ("unrestricted_formula_induction", 'a if a[0] == "=" else base', 'a'),
        ("unlifted_existential_conclusion", 'lifted = subst(a, formula=tag != "pi")', 'lifted = subst(a, (0,), formula=tag != "pi")'),
        ("ignored_elimination_premise", 'require(infer(q, g) == b)', 'infer(q, g)'),
        ("unvalidated_recursor_update", 'subst(r, formula=False)', 'None'),
        ("unshifted_context_under_binder", '*map(subst, g)', '*g'),
        ("boolean_term_indices", 'type(a) is int', 'isinstance(a, int)'),
    ]
    records = []
    for label, before, after in mutations:
        if before not in source:
            raise ValueError("Mutation anchor absent: "+label)
        altered = source.replace(before, after)
        module = types.ModuleType("deliberately_unsound_"+label)
        exec(compile(altered, label, "exec"), module.__dict__)
        failures = [r["label"] for r in certificate_results(module, cases) if not r["passed"]]
        records.append({"mutation": label, "detected": bool(failures), "witnesses": failures})
    return records


def run(checker_path, output, mutations=True):
    kernel = load(checker_path)
    syntax_results, substitution_results, cli_results = [], [], []
    for i, value in enumerate(syntax_samples()):
        for formula in (False, True):
            wanted = well_formed(value, formula)
            ok, answer, error = attempt(kernel.subst, value, (0,), formula=formula)
            syntax_results.append({"label": f"syntax:{i}:{formula}", "expected": wanted,
                                   "actual": ok, "passed": ok == wanted and (not ok or answer == value),
                                   "exception": error})
    for row in substitution_cases():
        ok, actual, error = attempt(kernel.subst, row["expression"], row["environment"],
                                    d=row["depth"], formula=row["formula"])
        substitution_results.append({**row, "actual_valid": ok, "actual": actual,
              "passed": ok == row["expected_valid"] and (not ok or actual == row["expected"]),
              "exception": error})
    cases = certificate_cases()
    proof_results = certificate_results(kernel, cases)
    by_name = {case["label"]: case for case in cases}
    cli_labels = ["identity-guard:3", "empty-context-falsity", "existential-rejects-escaped-witness:0",
                  "hidden-malformed-rec-update:0", "reject-wrong-numerical-guard:2"]
    with tempfile.TemporaryDirectory(prefix="ipra-cli-audit-") as temp:
        for name in cli_labels:
            case = by_name[name]
            path = Path(temp)/(name.replace(":", "_")+".json")
            path.write_text(json.dumps(case["data"])+"\n")
            for optimized in (False, True):
                cmd = [sys.executable, *(["-O"] if optimized else []), str(checker_path), str(path)]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
                passed = ((result.returncode == 0) == case["expected"]
                          and result.stdout.strip() == ("ACCEPT" if case["expected"] else "REJECT"))
                cli_results.append({"label": name, "optimized": optimized, "passed": passed,
                                    "returncode": result.returncode, "stdout": result.stdout,
                                    "stderr": result.stderr})
        bad = Path(temp)/"invalid.json"
        bad.write_text("not JSON")
        for name, args in [("missing-argument", []), ("extra-argument", [str(bad), str(bad)]),
                           ("invalid-json", [str(bad)])]:
            result = subprocess.run([sys.executable, str(checker_path), *args],
                                    capture_output=True, text=True, timeout=20)
            cli_results.append({"label": name, "optimized": False,
                                "passed": result.returncode != 0 and result.stdout.strip() == "REJECT",
                                "returncode": result.returncode, "stdout": result.stdout,
                                "stderr": result.stderr})
    mutation_results = mutation_sensitivity(checker_path.read_text(), cases) if mutations else []
    groups = {"syntax": syntax_results, "named_substitution": substitution_results,
              "certificates": proof_results, "cli": cli_results}
    failures = [{"group": group, **row} for group, rows in groups.items() for row in rows if not row["passed"]]
    failures += [{"group": "mutation", **row} for row in mutation_results if not row["detected"]]
    result = {"checker_sha256": hashlib.sha256(checker_path.read_bytes()).hexdigest(),
              "python_version": sys.version.split()[0], "seed": 20261107,
              "counts": {group: len(rows) for group, rows in groups.items()},
              "certificate_groups": dict(Counter(c["group"] for c in cases)),
              "certificate_positive": sum(c["expected"] for c in cases),
              "certificate_negative": sum(not c["expected"] for c in cases),
              "mutations_detected": sum(r["detected"] for r in mutation_results),
              "mutation_count": len(mutation_results), "failures": failures,
              "certificate_cases": cases, "certificate_results": proof_results,
              "syntax_results": syntax_results, "substitution_results": substitution_results,
              "cli_results": cli_results, "mutation_results": mutation_results,
              "qualification": "Finite targeted regression tests with an independent named-variable oracle. Empty-context falsity checks reject selected invalid certificates; they are not a consistency proof. Deliberate mutation detection does not establish absence of other bugs. No machine-checked metatheory is claimed."}
    output.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k not in {
          "certificate_cases", "certificate_results", "syntax_results", "substitution_results", "cli_results", "mutation_results"}}, indent=2))
    if failures:
        raise SystemExit(1)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path, default=ROOT.parent/"checker.py")
    parser.add_argument("--output", type=Path, default=ROOT/"audit_results.json")
    parser.add_argument("--no-mutations", action="store_true")
    args = parser.parse_args()
    run(args.checker.resolve(), args.output, not args.no_mutations)
