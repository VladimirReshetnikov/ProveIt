"""Independent named-variable specification used only by validation tools.

The candidate's scope table, substitution, and inference are never called here.
Binder names are fresh Python objects, so simultaneous substitution cannot capture
them.  Only free names are replaced, and only encoding back to de Bruijn syntax
uses numerical binder positions.
"""


class BadSyntax(ValueError):
    pass


class DeletedParameter(ValueError):
    pass


def decode(a, formula=True, bound=()):
    if type(a) is int:
        if formula or a < -1:
            raise BadSyntax(a)
        if a == -1:
            return ("zero",)
        return ("bound", bound[a]) if a < len(bound) else ("free", a-len(bound))
    if type(a) is not list or not a or type(a[0]) is not str:
        raise BadSyntax(a)
    if not formula and a[0] == "s" and len(a) == 2:
        return ("succ", decode(a[1], False, bound))
    if not formula and a[0] == "r" and len(a) == 4:
        u, v = object(), object()
        return ("rec", decode(a[1], False, bound), decode(a[2], False, bound),
                u, v, decode(a[3], False, (u, v, *bound)))
    if formula and a[0] == "=" and len(a) == 3:
        return ("eq", decode(a[1], False, bound), decode(a[2], False, bound))
    if formula and a[0] == "pi" and len(a) == 3:
        x = object()
        return ("allimp", x, decode(a[1], True, (x, *bound)),
                decode(a[2], True, (x, *bound)))
    if formula and a[0] == "ex" and len(a) == 2:
        x = object()
        return ("exists", x, decode(a[1], True, (x, *bound)))
    raise BadSyntax(a)


def map_free(a, function):
    match a:
        case ("free", i):
            return function(i)
        case ("zero",) | ("bound", _):
            return a
        case ("succ", t):
            return ("succ", map_free(t, function))
        case ("eq", s, t):
            return ("eq", map_free(s, function), map_free(t, function))
        case ("rec", n, z, u, v, body):
            return ("rec", map_free(n, function), map_free(z, function), u, v,
                    map_free(body, function))
        case ("allimp", x, a, b):
            return ("allimp", x, map_free(a, function), map_free(b, function))
        case ("exists", x, a):
            return ("exists", x, map_free(a, function))
    raise BadSyntax(a)


def encode(a, bound=()):
    match a:
        case ("zero",):
            return -1
        case ("free", i):
            if type(i) is not int or i < 0:
                raise BadSyntax(i)
            return i + len(bound)
        case ("bound", x):
            return bound.index(x)
        case ("succ", t):
            return ["s", encode(t, bound)]
        case ("eq", s, t):
            return ["=", encode(s, bound), encode(t, bound)]
        case ("rec", n, z, u, v, body):
            return ["r", encode(n, bound), encode(z, bound),
                    encode(body, (u, v, *bound))]
        case ("allimp", x, a, b):
            return ["pi", encode(a, (x, *bound)), encode(b, (x, *bound))]
        case ("exists", x, a):
            return ["ex", encode(a, (x, *bound))]
    raise BadSyntax(a)


def rename(a, mapping, formula=True):
    return encode(map_free(decode(a, formula), lambda i: ("free", mapping(i))))


def subst(a, env=(1,), depth=0, formula=True):
    bound = tuple(object() for _ in range(depth))
    replacements = [None if t is None else decode(t, False) for t in env[:-1]]

    def replacement(i):
        if i >= len(replacements):
            return ("free", i+env[-1])
        if replacements[i] is None:
            raise DeletedParameter(i)
        return replacements[i]

    return encode(map_free(decode(a, formula, bound), replacement), bound)


def well_formed(a, formula=True):
    try:
        decode(a, formula)
        return True
    except BadSyntax:
        return False


def under_binder(mapping):
    return lambda i: 0 if i == 0 else 1+mapping(i-1)
