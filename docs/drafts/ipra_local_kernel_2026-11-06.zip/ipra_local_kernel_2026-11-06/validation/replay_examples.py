"""Revalidate and translate all current public examples without duplicate counts."""

import argparse
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import sys

from translate import translate_document
from oracle import subst

ROOT = Path(__file__).resolve().parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def canonical(data):
    return (json.dumps(data, separators=(",", ":"), sort_keys=True)+"\n").encode()


def run(checker_path, output):
    manifest = json.loads((ROOT/"source_manifest.json").read_text())
    old = {}
    for source in manifest["sources"]:
        path = ROOT/source["path"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != source["sha256"]:
            raise ValueError("Source checker changed: "+str(path))
        old[source["sha256"]] = (load(path, "source_"+source["sha256"]), source["local_nat"])
    candidate = load(checker_path, "audited_candidate")
    destination = ROOT/"translated"
    destination.mkdir(exist_ok=True)
    unique_inputs, unique_outputs, unique_sequents = set(), {}, set()
    public_inputs, public_outputs, public_sequents = set(), set(), set()
    source_verdicts, records, failures = {}, [], []
    for entry in manifest["records"]:
        path = ROOT/entry["input"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != entry["canonical_sha256"]:
            raise ValueError("Input document changed: "+str(path))
        data = json.loads(path.read_text())
        source, local_nat = old[entry["source_checker_sha256"]]
        source_key = (entry["source_checker_sha256"], entry["canonical_sha256"])
        if source_key not in source_verdicts:
            try:
                arity = len(inspect.signature(source.check).parameters)
                accepted = (source.check(*data) if arity == 3 else source.check(data)) is True
            except Exception:
                accepted = False
            source_verdicts[source_key] = accepted
        if not source_verdicts[source_key]:
            failures.append({"source": entry, "error": "Source does not accept its published positive example"})
            continue
        try:
            translated = translate_document(data, source, local_nat)
            if translated[:2] != data[:2]:
                raise ValueError("Translation changed context or goal")
            content = canonical(translated)
            digest = hashlib.sha256(content).hexdigest()
            sequent = hashlib.sha256(canonical(data[:2])).hexdigest()
            if digest not in unique_outputs:
                candidate.check(translated)
                target = destination/(digest+".json")
                target.write_bytes(content)
                unique_outputs[digest] = {"path": str(target.relative_to(ROOT)),
                                          "sha256": digest, "sequent_sha256": sequent,
                                          "accepted": True}
            unique_inputs.add(entry["canonical_sha256"])
            unique_sequents.add(sequent)
            if entry["role"] == "public_example":
                public_inputs.add(entry["canonical_sha256"])
                public_outputs.add(digest)
                public_sequents.add(sequent)
            records.append({"source": entry, "translated_sha256": digest})
        except Exception as exc:
            failures.append({"source": entry, "error": repr(exc)})
    # Deliberately exercise the compiler path where an old nat step is an
    # arbitrary assumed theorem rather than a syntactic lambda, also nested
    # beneath another fresh-number introduction.
    bridge_results = []
    bridge_root = ROOT/"translated_bridge"
    bridge_root.mkdir(exist_ok=True)
    bridge_entry = next(e for e in manifest["records"]
                        if e["archive"] == "ipra_compact_kernel_2026-11-06.zip")
    bridge_source, local_nat = old[bridge_entry["source_checker_sha256"]]
    for i, matrix in enumerate([["=", 0, 2], ["ex", ["=", 0, 2]]]):
        base, successor = subst(matrix, (-1, 0)), subst(matrix, (["s", 0], 0))
        guard = matrix if matrix[0] == "=" else base
        step, goal = ["pi", guard, successor], ["pi", base, matrix]
        direct = [[step], goal, ["nat", matrix, step]]
        nested = [[], ["pi", step, goal], ["lam", step, ["nat", matrix, step]]]
        for kind, data in [("direct", direct), ("nested", nested)]:
            name = f"assumed_step_{i}_{kind}"
            try:
                bridge_source.check(*data)
                translated = translate_document(data, bridge_source, local_nat)
                if translated[:2] != data[:2]:
                    raise ValueError("Bridge changed context or goal")
                candidate.check(translated)
                target = bridge_root/(name+".json")
                target.write_bytes(canonical(translated))
                bridge_results.append({"name": name, "passed": True,
                                       "source_document": data,
                                       "translated_path": str(target.relative_to(ROOT)),
                                       "translated_sha256": hashlib.sha256(target.read_bytes()).hexdigest()})
            except Exception as exc:
                failure = {"name": name, "passed": False, "error": repr(exc)}
                bridge_results.append(failure)
                failures.append({"synthetic_bridge": failure})
    result = {"checker_sha256": hashlib.sha256(checker_path.read_bytes()).hexdigest(),
              "python_version": sys.version.split()[0], "snapshot_commit": manifest["snapshot_commit"],
              "source_checker_count": len(old),
              "public_example_occurrences": sum(r["role"] == "public_example" for r in manifest["records"]),
              "unique_public_original_documents": len(public_inputs),
              "unique_public_translated_certificates": len(public_outputs),
              "unique_public_sequents": len(public_sequents),
              "selected_logic_occurrences": sum(r["role"] == "selected_logic_witness" for r in manifest["records"]),
              "unique_total_original_documents": len(unique_inputs),
              "unique_total_translated_certificates": len(unique_outputs),
              "unique_total_sequents": len(unique_sequents),
              "synthetic_assumed_step_bridge_cases": len(bridge_results),
              "synthetic_bridge_results": bridge_results,
              "context_and_goal_preserved": not failures,
              "failures": failures, "outputs": list(unique_outputs.values()), "translations": records,
              "qualification": "Finite source-example preservation and regression evidence. Repeated archive copies are not counted as independent cases. This is not a formal proof of the general translation theorem."}
    output.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k not in {"outputs", "translations", "synthetic_bridge_results"}}, indent=2))
    if failures:
        raise SystemExit(1)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path, default=ROOT.parent/"checker.py")
    parser.add_argument("--output", type=Path, default=ROOT/"example_results.json")
    args = parser.parse_args()
    run(args.checker.resolve(), args.output)
