"""Untrusted translation of the six current draft formats to the new format.

The old checker is used to read a validated source proof's inferred formula.
Context and goal are preserved exactly.  The new checker independently checks
the result; neither this translator nor the old checker is imported by it.

Closed-step nat proofs are translated even when the step proof is not a lambda:
we rename the entire proof under the new fresh number, weaken its context, and
apply its guarded universal to that number and the local numerical hypothesis.
"""

from oracle import rename, subst, under_binder


def translate(p, old_g, new_g, old_checker, local_nat=False, mapping=lambda i: i):
    def rec(q, g=old_g, h=new_g, f=mapping):
        return translate(q, g, h, old_checker, local_nat, f)

    def raised(g):
        return [subst(a) for a in g]

    bound = under_binder(mapping)
    if type(p) is list and p:
        tag = p[0]
        if tag == "lam":
            _, a, q = p
            a_new = rename(a, bound)
            return [tag, a_new, rec(q, [*raised(old_g), a],
                                   [*raised(new_g), a_new], bound)]
        if tag == "pack":
            _, t, q = p
            t_new = rename(t, mapping, False)
            a, a_new = ["=", 0, subst(t, formula=False)], ["=", 0, subst(t_new, formula=False)]
            return [tag, t_new, rec(q, [*raised(old_g), a],
                                   [*raised(new_g), a_new], bound)]
        if tag == "nat":
            _, a, q = p
            a_new = rename(a, bound)
            h = a if a[0] == "=" else subst(a, [-1, 0])
            h_new = a_new if a_new[0] == "=" else subst(a_new, [-1, 0])
            new_local = [*raised(new_g), h_new]
            if local_nat:
                body = rec(q, [*raised(old_g), h], new_local, bound)
            elif type(q) is list and q[0] == "lam" and q[1] == h:
                body = rec(q[2], [*raised(old_g), h], new_local, bound)
            else:
                step = rec(q, old_g, new_local, lambda i: 1+mapping(i))
                body = ["use", step, 0, len(new_g)]
            return [tag, a_new, body]
        if tag == "use":
            major = old_checker.infer(p[1], old_g)
            major_new = rec(p[1])
            if major[0] == "ex":
                minor = p[-1]
                conclusion = rename(old_checker.infer(p, old_g), mapping)
                return [tag, major_new, conclusion,
                        rec(minor, [*raised(old_g), major[1]],
                            [*raised(new_g), rename(major[1], bound)], bound)]
            _, _, a, q = p
            annotation = rename(a, bound) if major[0] == "=" else rename(a, mapping, False)
            return [tag, major_new, annotation, rec(q)]
        if tag == "r":
            return rename(p, mapping, False)

    # Lookup always selects a validated stored formula, also for harmless aliases.
    formula = old_checker.infer(p, old_g)
    return new_g.index(rename(formula, mapping))


def translate_document(data, old_checker, local_nat=False):
    g, a, p = data
    return [g, a, translate(p, g, g, old_checker, local_nat)]
