INDEPENDENT IMPLEMENTATION VALIDATION

Run from any directory with Python 3.11 or newer:

  python3 validation/replay_examples.py
  python3 validation/audit.py
  python3 validation/summarize.py

Both audit drivers also accept --checker /absolute/path/checker.py and --output
/absolute/path/results.json. The summarizer reads the default result files.
No network or third-party Python package is required.

EXPECTED FINAL CHECKER

SHA-256: 672afaab345fa563807621166cf9f3b7604a8cf288fca145b8d8aed5b666648b
The API check(data) accepts by normal return and rejects by raising. The normal
successful return value is None. The CLI prints ACCEPT or REJECT. Explicit
existential elimination is ["use", major_proof, conclusion, minor_proof].

EXAMPLE PRESERVATION

source_manifest.json records every top-level public example in all six exact
Git-blob-verified archives at ProveIt snapshot
820ef51b6ad3c13ce4a500673a9e81d951fbc06c. Source checkers in sources/ are verbatim
copies with verified SHA-256. Documents in inputs/ are normalized JSON; their
original member byte hashes and canonical-document hashes are both retained.

There are 93 public-example occurrences across the archives, representing 45
different source documents. Translation gives 35 distinct target certificates
for 26 distinct sequents. Repeated archive copies do not count as independent
cases. Eight selected published conjunction/disjunction and binder witnesses
bring the total to 42 target certificates for 31 distinct sequents.

translate.py is an untrusted compiler. It preserves the source context and goal
exactly. It translates both local and closed-step numerical rules, and supplies
the explicit conclusion required by existential elimination. Four additional
synthetic bridge tests exercise arbitrary assumed step theorems, including a
step beneath another binder; the translator does not require the old step proof
to be syntactically a lambda. Each original example is rechecked by its source
checker, and each distinct translated certificate is checked by the final one.

INDEPENDENT ORACLE AND ADVERSARIAL CASES

oracle.py translates de Bruijn syntax to named binders. Fresh Python objects name
bound variables; substitution acts only on free names, then indices are rebuilt.
The oracle never imports the candidate or copies its scope table. It supplies
expected answers for 300 substitution/raising comparisons over fixed nested
examples and a reproducible random sample. Only substitution environments used
by the final calculus are tested; there is no partial scope-deletion test mode.

audit.py contains 156 grammar checks and 167 fixed certificate cases: 46 expected
acceptances and 121 expected rejections. These cover term/formula sorting,
booleans/floats, arity, unused invalid annotations, full recursor validation,
equational transport, numerical-rule premise restrictions, and eigenvariable
freshness under nested Pi, Ex and recursor binders. In particular, substituting
the induction hypothesis for the fixed base in the quantified-formula case is
rejected. Explicit existential conclusions are checked even when intermediate
and subsequently hidden by constant equality transport.

The runtime permits harmless proof-index aliases: negative list indices and
booleans can select an existing validated assumption. Tests record this behavior
explicitly. Booleans/floats inside terms or formulas are rejected. Floats are not
valid list indices. These proof aliases do not add formulas to the context.

Thirteen actual subprocess CLI tests include one accepted theorem and four
different invalid certificates in normal and Python -O modes, plus missing
arguments, extra arguments and malformed JSON. The absence of assert-based
acceptance checks is thus exercised in the optimized interpreter.

Six deliberate source mutations are detected: unrestricted formula induction,
an unlifted existential conclusion, an ignored elimination premise, skipped
recursor validation, an unshifted context and boolean term indices. Mutant
modules are confined to the test process; the candidate file is not changed.

TRUST AND LIMITS

Only checker.py participates in acceptance. Validation scripts, source checkers,
the compiler, oracle, fixtures and result files are untrusted tools. Tests are
finite implementation evidence. Rejection of a particular empty-context proof
of 0=S0 is a regression check, not a proof of consistency. Mutation detection
does not rule out other bugs. The general metatheorems are mathematical proofs
in the report; no Lean/Rocq verification is claimed. Categories overlap and their
counts must not be summed as independent research evidence.
