A SMALLER LOCAL PROOF KERNEL FOR iPRA
Prepared for Vladimir Reshetnikov -- November 6, 2026

RESULT

The complete checker is below the measured envelope of the six current draft
archives at ProveIt commit 820ef51b6ad3c13ce4a500673a9e81d951fbc06c:

                         Current envelope      This checker
  AST nodes                        712                 688
  Normalized Python tokens         662                 634
  Significant source tokens        664                 636
  Normalized source bytes         2150                2122
  Raw source bytes                2441                2364

The complete source is 80 physical lines including its docstring and blank
lines. The arithmetic basis and logical reconstruction are inherited from the
supplied drafts. The new contribution combines a local numerical premise,
direct context references, and reuse of the validated raised conclusion for
existential elimination. An unused success Boolean is removed separately.
Controlled variants show that inferring the existential conclusion is larger
in this particular architecture, even though it shortens certificates.

The report gives the entire native language, logical rules, arithmetic schemas,
and numerical rule. It derives full intuitionistic logic and quantifier-free
induction. Its ordinary realization explicitly includes numerical coverage and
the falsity bridge, and is whole-domain bi-interpretable with iPRA. Equality
witnesses both internal round-trip isomorphisms. The native calculus is a
faithful proof presentation of that ordinary realization.

This is a finite-corpus size improvement, not a global minimality theorem.
Metatheory is proved in the paper; it has not been formalized in Lean or Rocq.
The executable tests are finite validation and do not replace the proofs.

MAIN FILES

  report.pdf                    Compiled paper.
  report.tex, sections/          Complete LaTeX source.
  checker.py                    Entire trusted acceptance program.
  verify.py                     Offline reproduction driver.
  verification_summary.json     Actual reproduction results.
  build.sh                      PDF build command.
  make_archive.py               Refresh hashes and rebuild the ZIP.
  comparison/                   Frozen sources, hashes and common measurements.
  comparison/ablation/          Nine complete controlled variants and builder.
  validation/                   Independent oracle, translator, examples, tests.
  FILES.sha256                   Hashes for the delivered files.

REPRODUCE

From the extracted directory, using Python 3.11 or later:

  python3 verify.py

This needs only the Python standard library and no network. It verifies frozen
source hashes, reconstructs the controlled variants, translates the original
examples, checks binding and malformed inputs, and reruns actual CLI checks
including Python -O. Categories overlap; their counts are not one aggregate
number of independent results.

To rebuild the PDF with a conventional TeX Live installation:

  bash build.sh

Required LaTeX packages are listed in report.tex (including amsmath, amsthm,
lmodern, microtype, geometry, booktabs, enumitem, listings, fancyhdr, xurl,
hyperref and bookmark). A precompiled PDF is included.

CHECK A CERTIFICATE

  python3 checker.py path/to/certificate.json

The input is [context, goal, proof]. ACCEPT with exit status zero means accepted;
REJECT with nonzero status means rejected. As an imported API, check(data)
returns normally on acceptance (its value is None) and raises on rejection.
No Boolean result should be tested. Examples and their provenance are in
validation/inputs and validation/example_results.json.

Numerical terms use -1 for zero and nonnegative de Bruijn indices for variables.
Formula constructors are ["=",s,t], ["pi",A,B], and ["ex",A]. Term constructors
are ["s",t] and ["r",n,a,h], with two local slots in h. Proof records are fully
documented in the report. Existential elimination carries an explicit external
conclusion: ["use",major_proof,conclusion,minor_proof].

Only checker.py and the ordinary Python/JSON runtime participate in acceptance.
The translator, proof generators, benchmark, oracle and tests are untrusted
clients. There is no external axiom database, universal numerical evaluator,
eval/exec, or assert-dependent acceptance check in checker.py. Physical resource
limits may reject large valid certificates; completeness concerns the idealized
unbounded algorithm.

PROVENANCE

Current draft snapshot:
https://github.com/VladimirReshetnikov/ProveIt/tree/820ef51b6ad3c13ce4a500673a9e81d951fbc06c/docs/drafts

Exact archive Git blob hashes, SHA-256 values, sizes, member paths, and original
source bytes are recorded in comparison/manifest.json. The selected current
archives are compact_kernel (both uploads), inferred_elimination,
scope_inference, smaller_checker and structural_checker, all dated 2026-11-06.

Final checker SHA-256:
672afaab345fa563807621166cf9f3b7604a8cf288fca145b8d8aed5b666648b
