"""Reproduce the frozen comparison, controlled variants and implementation checks."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
EXPECTED = "672afaab345fa563807621166cf9f3b7604a8cf288fca145b8d8aed5b666648b"


def main():
    if sys.version_info < (3, 11):
        raise SystemExit("Use Python 3.11 or later.")
    digest = hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest()
    if digest != EXPECTED:
        raise SystemExit("The checker differs from the frozen deliverable.")
    jobs = [
        ("Frozen source comparison", ["comparison/measure.py", "--candidate", "checker.py",
                                       "--output", "comparison/metrics.json"]),
        ("Controlled reconstruction", ["comparison/ablation/build_ablation.py", "--candidate", "checker.py"]),
        ("Controlled constructor checks", ["comparison/ablation/check_variants.py"]),
        ("Exact example translation", ["validation/replay_examples.py"]),
        ("Independent implementation audit", ["validation/audit.py"]),
        ("Validation summary", ["validation/summarize.py"]),
    ]
    records = []
    for name, arguments in jobs:
        result = subprocess.run([sys.executable, *arguments], cwd=ROOT,
                                text=True, capture_output=True)
        records.append({"name": name, "exit_code": result.returncode})
        if result.returncode:
            print(result.stdout, end="")
            print(result.stderr, end="", file=sys.stderr)
            raise SystemExit(f"FAILED: {name}")
        print(f"PASS: {name}")
    metrics = json.loads((ROOT / "comparison/metrics.json").read_text())
    validation = json.loads((ROOT / "validation/summary.json").read_text())
    if not all(metrics["candidate_at_or_below"].values()) or validation["failures"]:
        raise SystemExit("A comparison or validation requirement failed.")
    if metrics["candidate"]["sha256"] != EXPECTED or validation["checker_sha256"] != EXPECTED:
        raise SystemExit("Result files refer to another checker.")
    summary = {"checker_sha256": digest, "python": sys.version.split()[0],
               "jobs": records, "metrics": metrics["candidate"],
               "comparison_envelope": metrics["complete_envelope"],
               "validation": validation, "failures": 0}
    (ROOT / "verification_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print("All reproduction steps passed; see verification_summary.json.")


if __name__ == "__main__":
    main()
