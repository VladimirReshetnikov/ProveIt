These are the individual certificates from code/certificates.json.
Expected results and meanings:

zero_seed_successor.json: ACCEPT — R(0,0;0)=1: the numerical base is successor seeded.
zero_arbitrary_seed.json: ACCEPT — R(0,4;u)=5, independently of the update body.
counter_slot.json: ACCEPT — The predecessor counter is 2, distinct from the seed and previous state.
state_slot.json: ACCEPT — The state slot is the earlier R value, not the predecessor counter.
counter_below_successor.json: ACCEPT — Opening a counter occurrence under an additional numerical binder.
state_below_successor.json: ACCEPT — Opening a previous-state occurrence under an additional binder.
both_slots_nested.json: ACCEPT — Nested R uses outer state as counter and outer counter as seed.
counter_even_alias.json: ACCEPT — Coordinates 3 and 4 alias the counter.
state_even_alias.json: ACCEPT — Coordinates 1 and 2 alias the previous state.
swapped_counter_state.json: REJECT — Swapping the two substitutions would assert a false ground equation.
original_update_retained.json: ACCEPT — The recursive state keeps the original update, including its counter binder.
frozen_counter_in_recursive_state.json: REJECT — Freezing the update counter inside the recursive state would falsely identify 9 and 12.
bouncing_predecessor_zero.json: ACCEPT — W(0)=1.
bouncing_predecessor_successor.json: ACCEPT — W(5)=4 directly.
derived_reflexivity.json: ACCEPT — Reflexivity follows from W(Sa)=a and transport.
transported_successor_congruence.json: ACCEPT — Equality transport under a successor context.
ordinary_recursion_base.json: ACCEPT — Expanded proof of J_h(0,3)=3.
ordinary_recursion_step.json: ACCEPT — Expanded proof of J_h(3,3)=h(2,J_h(2,3)); h uses both inputs.
genuine_equation_induction.json: ACCEPT — DI/DE/QE plus a genuinely used equation induction hypothesis.
induction_with_wrong_case_mode.json: REJECT — The same proof requires the IH and fails with only the zero base.
conditional_false_base.json: ACCEPT — Q_y(y=1) retains its conditional-universal meaning by Case introduction.
false_base_wrong_induction_mode.json: REJECT — A progression assumption does not supply the required false zero base.
case_annotation_null.json: ACCEPT — This falsy marker is an instruction annotation, not numerical syntax.
case_annotation_empty_object.json: ACCEPT — This falsy marker is an instruction annotation, not numerical syntax.
case_annotation_empty_string.json: ACCEPT — This falsy marker is an instruction annotation, not numerical syntax.
nested_parameter_and_counter.json: ACCEPT — Outer Case and inner Ind preserve a captured initializer and counter.
captured_inner_counter.json: REJECT — The inner counter has been replaced by the distinct outer parameter.
nonvacuous_paired_witness.json: ACCEPT — The selected existential witness becomes the recursion initializer.
free_positive_witness.json: REJECT — A used witness must be valid at numerical root before insertion.
future_negative_witness.json: REJECT — A used witness must be valid at numerical root before insertion.
nested_update_passive_parameter.json: ACCEPT — A passive parameter survives two local R binders, DI, DE and QE.
ordinary_recursion_bound_counter.json: ACCEPT — The general J successor derivation is closed by DI/DE and specialized by QE.
failed_major_cannot_fall_through.json: REJECT — The failed major cannot become a successful computation fallback.
canonical_false.json: REJECT — Zero is not successor zero.
wrong_old_base.json: REJECT — The old zero-seeded computation equation is not an axiom of R.
four_child_goal.json: REJECT — Malformed formula arity.
free_negative_goal.json: REJECT — The public goal must be closed.
two_child_counter.json: REJECT — The starred fixed-arity call independently rejects a non-singleton counter.
three_child_counter.json: REJECT — A nested R counter is not a literal successor redex.
free_update_coordinate.json: REJECT — A body has exactly two local numerical slots, plus actual outer parameters.
object_in_syntax.json: REJECT — Unlike the separate implementation experiment, this kernel has strict list syntax.
