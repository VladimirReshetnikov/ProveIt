# Review of the counter-aware kernel

The complete new program is `kernel.py`. The old byte comparator is the
762-byte `code/choice_checker.py` from `ipra_scalar_feedback_2026-11-09.zip`.
The Choice-DI logical rules, target checking, freshness discipline, and
strict list traversal are unchanged. The arithmetic branch is changed to
successor-seeded, counter-aware recursion as specified in `FORMAT.txt`.

## Arithmetic opening lemma

At a recursion update root, the numerical environment is `(v,u,rho)`:
state first, counter second. At numerical depth 3, the coordinates 1 and 2
remain protected and 3/4 are exposed. Therefore `i(h,n,3)` substitutes the
predecessor counter n and protects the state. A subsequent depth-1 opening
substitutes the previous recursion value for the state. Each used image is
first checked at numerical root; it cannot acquire a meaning from a local
binder at its insertion site. All passive parameters at a computation
leaf are retained rigid parameters, so these two local openings preserve
them. An induction on the raw tree gives the same statement under nested
successor, recursion, and annotation constructors.

Consequently the successor expression is exactly

    h[n/u, R(n,a;u,v.h)/v].

The recursive state must use the original h. Substituting the current
counter into the recursive state's stored update would change earlier
stages. A supplied negative fixture distinguishes the correct value 9
from the incorrectly frozen value 12.

The base expression `[a]` is the raw successor abbreviation. Its ordinary
meaning is `R(0,a;u,v.0)`, so the base rule requires no independent
successor symbol or a third computation schema.

Canonical completeness uses the named-to-raw encoder in `producer.py`.
Passive variables are fresh rigid labels at computation leaves; temporary
zero padding is represented canonically. Some noncanonical padding aliases
may reject when an image is used at numerical root. Completeness does not
require every semantic alias to have the same literal computation packet.

## Validation by function arity

For a truthy list n, evaluation of `i(h,*n,3)` calls the fixed-arity opening
function with `2+len(n)` positional arguments. It succeeds exactly when
`len(n)=1`, after which its arguments are exactly `(h,n[0],3)`. Lists of
length 2 or 3 fail before entering the function body. Lists of length 4
already fail the initial traversal. Non-list numerical syntax is either a
scalar, rejected as a truthy iterable counter, or invalid syntax rejected
by traversal. Empty lists are handled by the base branch. This proves
equivalence to explicit singleton unpacking for every raw JSON packet
under the same unlimited-resource execution model. No use is made of
assertions that could disappear under optimized Python.

## Reflected numerical basis and native reflexivity

Set `S(a)=R(0,a;u,v.0)` and `W(n)=R(n,0;u,v.u)`. The two computation
schemas directly give `W(0)=1` and `W(S(a))=a`. Reflexivity for an arbitrary
term a follows by using the latter equation as both premises of equality
transport with motive `x=a`. Thus replacing the old zero-seeded iterator
does not leave a gap in the native equality bootstrap.

For any fixed update h, define

    J_h(n,a) = W(R(n,a;u,v.S(h(u,W(v))))).

The derived equations `J_h(0,a)=a` and
`J_h(S(n),a)=h(n,J_h(n,a))` each follow by one R computation under W and
then one computation `W(S(t))=t`. The executable producer expands all
equality transports, reflexivity uses, and computations in these proofs.
No numerical evaluator is called by the kernel.

## Logical tests and scope

The test suite supplies actual closed proof packets for genuine equation
induction, Q elimination, D introduction and elimination, equality
transport and congruence, arbitrary captured initializers, nested update
binders, and the J equations at a DI-bound counter.

The conditional closure `Q_y(y=1)` is specifically proved by the Case
choice. Its false base `0=1` transports a recursion counter from 0 to 1,
yielding `S(z)=0`, hence `S(z)=1`. Changing this proof to the Ind choice
fails: the local hypothesis then has the wrong meaning. This protects the
full conditional-universal interpretation of Q.

Negative cases include a swapped counter/state, a frozen recursive update,
an inner counter confused with its captured outer initializer, a genuinely
used but free witness image, a future negative witness, a failed major
before a true computation goal, non-singleton counters, malformed arities,
and objects occurring as syntax.

See `validation.json` for exact executed counts and source hashes. These
tests supplement the structural proofs. They do not constitute a
proof-assistant formalization of full iPRA bi-interpretability.
