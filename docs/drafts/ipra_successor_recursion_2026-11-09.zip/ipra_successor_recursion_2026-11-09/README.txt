SUCCESSOR FROM RECURSION
A two-schema presentation of intuitionistic primitive recursive arithmetic
Prepared for Vladimir Reshetnikov — November 9, 2026 (Pacific date)

READ FIRST
----------
ipra_successor_recursion.pdf is the main paper. Its complete standalone
editable source is ipra_successor_recursion.tex. report.tex and theory/
are the modular sources from which the standalone version is generated.

MAIN RESULT
-----------
The only primitive numerical constructors are zero and

    R(n,a;u,v.h),

where u is the old counter and v the previous state. Successor is the
fixed abbreviation S(a)=R(0,a;u,v.0). The computation schemas are

    R(0,a;u,v.h)   = S(a)
    R(Sn,a;u,v.h)  = h[n/u,R(n,a;u,v.h)/v].

There is no uniform total evaluator or quantification over function codes.
Updates are fixed finite descriptions with passive numerical parameters.

The derived term W(n)=R(n,0;u,v.u) satisfies W(0)=1 and W(Sn)=n
by computation. Therefore

    C(n,a,b) = W(R(n,a;u,v.S(b)))

is an unrestricted zero/successor selector. Every ordinary primitive
recursion with base g and update h compiles directly to

    J_g,h(n,x) = W(R(n,g(x);u,v.S(h(u,W(v),x)))).

Its defining base and step equations follow by computation alone. This
removes the scalar predecessor and pairing bootstrap used in the old
initialized-scalar presentation.

The main paper specifies all ordinary and native logical rules, both
computation schemas, coverage and separation in the ordinary theory,
and contextual literal-equation induction. The native checker derives
ordinary intuitionistic logic from the inherited Choice-DI envelope.
Both numerical domains are the entire source domain, equality is actual
equality, and both interpretation composites are internally isomorphic
to the identity via x=y. Thus the theory is bi-interpretable and
equiconsistent with full first-order iPRA.

EXACT COMPLEXITY RESULT
----------------------
Under the unchanged corpus source normalizer, counting the entire
standalone program, CPython 3.12.14 gives:

                                      tokens     AST nodes     bytes
  Published token profile                292           336       865
  Published AST profile                  296           330       882
  Published byte profile                 298           349       762
  New code/kernel.py                     305           351       738

The new complete checker is 24 normalized bytes smaller than the actual
published byte leader, approximately 3.15%. It is NOT a token or AST record,
and no one program is claimed to dominate all three published coordinates.
Absolute minimality and literature-wide priority are not established.

The correct byte comparator is the 762-byte choice_checker.py inside
ipra_scalar_feedback_2026-11-09.zip. Some other current reports compare
against older frontiers. All eleven ZIPs in the pinned current directory
were acquired and Git-blob-verified; all 519 extracted Python occurrences
(398 distinct contents) were measured.

The checker retains a unary serialized abbreviation for successor. Its
cost is charged. The mathematical primitive grammar can expand it into R.
The source-size improvement uses the new counter-opening call's argument
arity to validate a singleton successor counter, while performing its
required substitution. The logical elimination decomposition already
appears in the published byte leader and is attributed to that source.

FULL CHECKER TRUST BOUNDARY
--------------------------
code/kernel.py imports only the standard json module. It does not import
the proof producer, numerical evaluator, validators, source normalizer,
or report. Input is one JSON array on standard input. The last element is
the closed goal; earlier cells are consumed backwards as instructions.
Unused prefix cells are inert. Success prints ACCEPT and exits zero.
Failure prints REJECT and exits nonzero; traceback output on stderr is
permitted, matching the published comparator.

For example:

    python3 code/kernel.py < examples/ordinary_recursion_step.json
    python3 code/kernel.py < examples/canonical_false.json

See code/FORMAT.txt for the complete syntax, scope rules, and instruction
decoding, and code/correctness.md for the implementation proof.

VALIDATION
----------
Run, from this directory:

    python3 verify.py

When MANIFEST.json is present, this first verifies its source_files hashes:
the immutable source, reference, and other fixed package files. Rebuilding
the PDFs or regenerating certificates and receipts does not invalidate
this default source-integrity check. The manifest records those outputs
separately under generated_files.

Verification also generates the executable code/kernel_normalized.py by
the inherited docstring removal and AST normalization (738 bytes on
CPython 3.12.14); its manifest entry belongs to generated_files.

To verify all recorded distribution hashes before rebuilding or regenerating outputs,
run:

    python3 verify.py --distribution-integrity

This checks both manifest mappings before replaying the tests. It requires
MANIFEST.json and intentionally rejects generated files whose bytes have
changed since distribution, including PDFs with new build metadata.

This replays 41 proof fixtures (25 positive and 16 negative) through both
the compact and explicit-unpacking kernels, runs 82 fresh normal/optimized
CLI checks, compares 1,435 malformed-subtree mutations, checks 168 finite
compiler instances, and compares 2,000 structural openings against an
independent named substitution implementation. It also remeasures the
complete programs and runs 14,223 finite countdown diagnostics.

Examples include expanded proofs of the compiler's base and step,
a step under a bound counter, a genuine use of the induction hypothesis,
nested captures, the conditional false-base Q closure, and rejections for
swapped/frozen counter meanings and malformed/future parameters.
A separate reviewer ran 24 additional normal/optimized raw-input cases.

Finite checks support the code and expose transcription errors. The
universal soundness, arithmetic completion, and bi-interpretability
claims have written mathematical proofs and separate assistant reviews.
No Lean, Rocq, or Isabelle kernel verified the entire metatheory.

SUPPLEMENT: A FINITE COUNTDOWN COMPLETION
---------------------------------------
supplement/seed_shift_bridge.pdf and .tex contain a separate complete paper.

Over the existing countdown uniqueness theory T_W, add the single equation

    A(n,S(a)) = S(A(n,a)),

where A is the initialized successor iterator. The completed theory is
deductively equivalent to full iPRA in the same fixed-description language.
The proof uses a new clipped counter p(n,a)=d(n,r(n,a)), then proves the
faithful clock, positive residual reconstruction, actual equality
reflection, and all quantifier-free induction.

Over T_W, the seed-shift equation, full initialized-successor uniqueness,
the single residual equation C(d(a,n),a,A(d(a,n),n))=a, and full iPRA are
equivalent completions. The paper does NOT prove that bare T_W supplies
these equations. It has no complete-checker size claim and is not used by
the main checker.

BUILDING
--------
Run:

    python3 build.py

This creates the standalone main .tex and compiles both PDFs with pdfLaTeX,
with shell escape disabled, using only the included sources. A normal
LaTeX installation with the declared packages is required. No Python
third-party packages or network access are needed for build or verification.
The build rejects overfull or unresolved-reference warnings.

FILE GUIDE
----------
ipra_successor_recursion.tex/pdf  Standalone main paper.
report.tex, theory/               Modular main-paper sources.
code/                            Entire kernel, producer, format, tests.
examples/                        Individual positive and negative packets.
reference/                       Exact published sources and prerequisite.
evidence/                        Pinned audit, metrics, receipts, reviews.
supplement/                      Standalone countdown completion paper.
scripts/                         Untrusted measurement and diagnostics.
verify.py, build.py               Offline reproduction commands.
ATTRIBUTION.txt                   Exact inherited/new contribution account.
MANIFEST.json                    Separate hashes for fixed sources and regenerable outputs.
LICENSE.txt                      Inherited MIT No Attribution license.

SOURCE SNAPSHOT
---------------
Repository: VladimirReshetnikov/ProveIt
Commit: 70feebabe24445912ae5eb336a6d7e9ba40a882b
Directory: docs/drafts
Direct archives: 11

The optional source audit is documented in scripts/AUDIT.txt. To verify a
local collection of the eleven pinned ZIPs without network access:

    python3 scripts/audit_sources.py --archives /path/to/archives --offline

Omitting --offline permits retrieval of missing archives from the immutable
commit URLs. Every archive's size, Git blob SHA-1 and SHA-256 is checked;
all 519 Python member measurements are compared with the supplied audit.
This source-download audit is separate from the offline checker replay.

https://github.com/VladimirReshetnikov/ProveIt/tree/70feebabe24445912ae5eb336a6d7e9ba40a882b/docs/drafts
