ONE SIGNED RECURRENCE AND ONE RETRACTION FOR INTUITIONISTIC PRA
============================================================
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific time).

START WITH report.pdf. The complete editable source is report.tex together
with sections/*.tex. The PDF is compiled from that source.

RESULT AND LIMIT
----------------
The report supplies a complete ordinary intuitionistic first-order theory
deductively equivalent, identity-domain bi-interpretable, and equiconsistent
with full iPRA. In the current signed-counter presentation, the entire
successor-uniqueness schema is replaced by one fixed equation:

    H(D(n)) = n.

D is the fixed doubling description; H is the fixed half description.
The theory retains the full fixed-description PR language and equations,
numerical coverage, separation, and a uniqueness rule for only the one
fixed signed update B.

The key new phase argument proves zero stationarity from uniqueness for
any fixed-point-free update, using numerical coverage. It needs no equality
test, no inverse iteration, no Boolean-range assumption, and no successor
uniqueness. Over the resulting signed-rule base, the retraction, injectivity
of D, and admissibility of all successor-uniqueness instances are equivalent.

The requested STRICT COMPLETE-CHECKER REDUCTION IS NOT ESTABLISHED.
The observed current coordinate envelope remains 312 normalized tokens /
347 AST nodes / 878 normalized bytes, attained by different programs.
No new complete checker below it is claimed. No absolute simplestness,
redundancy or independence of the retraction, or literature-wide priority
is claimed. Fixed-update uniqueness has older precedent; the particular
phase and retraction reduction is new relative to the 16 inspected archives.

CONTENTS
--------
report.pdf / report.tex / sections/
    Full paper, complete theory, arithmetic reconstruction, interpretations,
    product-domain alternative, cost discussion, and exact unresolved goal.
verification/
    Independent producer and symbolic replay checker, 80 proof nodes in two
    relative certificates, 14 rejected corrupted-certificate controls, and
    explicit trust-boundary README. Not a complete iPRA checker.
code/definitions.json and code/check_definitions.py
    Acyclic descriptions and finite literal-computation diagnostics, not
    proofs of universal internal equations.
comparison/
    Four unchanged nondominated complete reference checkers, unchanged
    source normalizer and licenses, hashes, offline measurements, and a
    targeted acceptance/scope audit. These implement the inherited native
    calculus, not the new theory directly.
evidence/
    Pinned 16-archive snapshot, all 18 complete-source profiles, executed
    receipts, build record, and visual QA.
reviews/
    Independent mathematical review of the final primary proof.
ATTRIBUTION.txt / LICENSE.txt
    Contribution boundary and reuse terms; original notices remain attached
    to inherited files.
build.py / reproduce.py / package.py / MANIFEST.json
    Offline build, evidence reproduction, deterministic packaging, and
    SHA-256 integrity for all other package members.

REPRODUCE
---------
Python 3.10+ with its standard library:

    python3 reproduce.py

The recorded measurements use CPython 3.12.14; other Python unparsers can
change normalized AST/source metrics. The symbolic proofs are replayed in
normal and optimized Python. The complete native checker audit separately
runs 28 targeted CLI cases in both modes plus 8 scope/image checks.

Build with pdfLaTeX, a standard TeX distribution, and Poppler pdfinfo:

    python3 build.py

Required LaTeX packages are listed in report.tex. Compilation disables
shell escape. No network or external theorem prover is used by these scripts.

After intentional edits, rebuilding, and validation:

    python3 package.py

This refreshes the manifest and ZIP. It does not prove the mathematics or
replace visual review. Transient build files and Python caches are excluded.

SOURCE SNAPSHOT
---------------
https://github.com/VladimirReshetnikov/ProveIt/tree/4890fd00a5cacfc9881ae282120978f95c3ba392/docs/drafts

All 16 current archives were downloaded and checked against their Git blob
identities and sizes. Immutable archive URLs and SHA-256 digests are included.
No repository changes were pushed.

VERIFICATION SCOPE
------------------
The full mathematics has written proofs and independent review, not a Lean
or Rocq formalization. The two symbolic certificates establish exactly the
relative phase and lifting lemmas stated in their own README. The report
proves the specific B fixed-point property, intertwining, equality reflection,
latch induction, and both complete interpretation composites in writing.
Finite numerical diagnostics and source-size measurements are separate
evidence and are never used as substitutes for those universal proofs.
