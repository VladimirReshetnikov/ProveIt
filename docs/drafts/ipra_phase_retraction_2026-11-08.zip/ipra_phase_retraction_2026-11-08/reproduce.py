"""Reproduce the scoped evidence; does not claim to formalize all mathematics."""
from pathlib import Path
import json
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
commands = [
    [sys.executable, "verification/verify_all.py"],
    [sys.executable, "-O", "verification/verify_all.py"],
    [sys.executable, "code/check_definitions.py"],
    [sys.executable, "comparison/measure_frontier.py"],
    [sys.executable, "comparison/audit_checker.py"],
]
records = []
for command in commands:
    run = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    record = {"command": [Path(command[0]).name, *command[1:]],
              "exit_code": run.returncode,
              "stdout": run.stdout, "stderr": run.stderr}
    records.append(record)
    if run.returncode:
        print(run.stdout + run.stderr)
        raise SystemExit(run.returncode)
receipt = {"all_passed": True, "python": platform.python_version(),
           "checks": records,
           "scope": "Symbolic relative lemmas, finite diagnostics, measurements, and targeted CLI audit"}
(ROOT / "evidence" / "reproduction.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"all_passed": True, "commands_completed": len(records),
                  "python": platform.python_version()}, indent=2))
