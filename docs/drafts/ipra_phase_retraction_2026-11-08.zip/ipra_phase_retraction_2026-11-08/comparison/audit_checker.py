#!/usr/bin/env python3
"""Replay finite focused format/freshness diagnostics on the unchanged checker.

These tests are not a full soundness proof. See checker_audit.txt for the
written reasoning and audit_cases.json for all exact public-interface inputs.
"""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CHECKER = ROOT / 'array_only.py'
EXPECTED = '9cc227c1481d321449b8f9b5ca5d447555bec42f28e07419ad1bab1c7d097e28'
actual_hash = hashlib.sha256(CHECKER.read_bytes()).hexdigest()
if actual_hash != EXPECTED:
    raise ValueError('The inherited checker was modified')
cases = json.loads((ROOT / 'audit_cases.json').read_text())
cli_rows = []
for c in cases:
    for optimize in [False, True]:
        args = [sys.executable] + (['-O'] if optimize else []) + [str(CHECKER)]
        p = subprocess.run(args, input=c['input'], text=True, capture_output=True, timeout=5)
        actual = p.returncode == 0 and p.stdout == 'ACCEPT\n' and not p.stderr
        expected_exit = 0 if c['expected_accept'] else 1
        passed = (actual == c['expected_accept'] and p.returncode == expected_exit
                  and p.stdout == ('ACCEPT\n' if c['expected_accept'] else 'REJECT\n')
                  and not p.stderr)
        cli_rows.append({'name': c['name'], 'optimized': optimize,
                         'expected_accept': c['expected_accept'], 'actual_accept': actual,
                         'returncode': p.returncode, 'passed': passed})

# Load the inspected definitions, excluding the input-consuming CLI driver.
tree = ast.parse(CHECKER.read_text())
tree.body = [n for n in tree.body if not isinstance(n, ast.Try)]
ns = {}
exec(compile(tree, str(CHECKER), 'exec'), ns)
box_zero = [0, 0, 0]
inst_cases = [
    ('fresh_numeric_coordinate_rejects', 0, -1, None, 1, False, None),
    ('available_numeric_coordinate_retained', -1, -1, None, 1, True, -1),
    ('next_numeric_coordinate_rejects', -1, -2, None, 1, False, None),
    ('formula_scalar_erases_to_truth', 0, -1, None, 0, True, 0),
    ('bad_child_does_not_rescue_array', 0, [0, {}, 0], None, 1, False, None),
    ('unsupported_arity_does_not_rescue_array', 0, [0, 0, 0, 0], None, 0, False, None),
    ('future_coordinate_inside_image_rejects', -1, [1, 0], [0, -2, 0], 0, False, None),
    ('legal_image_control', 0, [1, 0], box_zero, 0, True, [box_zero, 0]),
]
inst_rows = []
for name, floor, a, t, d, normal, result in inst_cases:
    ns['k'] = floor
    try:
        value = ns['inst'](a, t, d)
        row = {'name': name, 'normal_return': True, 'result': value,
               'passed': normal and value == result}
    except Exception as error:
        row = {'name': name, 'normal_return': False, 'exception': type(error).__name__,
               'passed': not normal}
    inst_rows.append(row)

receipt = {
    'checker_sha256': actual_hash, 'python': sys.version.split()[0],
    'cli_case_count': len(cases), 'cli_runs': len(cli_rows),
    'inst_case_count': len(inst_rows),
    'all_passed': all(r['passed'] for r in cli_rows + inst_rows),
    'cli_results': cli_rows, 'inst_results': inst_rows,
    'scope': 'Finite targeted diagnostics; no claim of complete soundness proof.',
}
destination = ROOT.parent / 'evidence/checker_audit.json'
destination.parent.mkdir(exist_ok=True)
destination.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k not in ['cli_results', 'inst_results']}, indent=2))
if not receipt['all_passed']:
    print(json.dumps([r for r in cli_rows + inst_rows if not r['passed']], indent=2))
    raise SystemExit(1)
