#!/usr/bin/env python3
"""Reproduce the four inherited frontier profiles without running the checkers."""
import hashlib
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / 'provenance.json').read_text())
for entry in manifest['files']:
    path = ROOT / entry['file']
    if hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
        raise ValueError('Changed inherited payload: ' + entry['file'])
spec = importlib.util.spec_from_file_location('inherited_measure', ROOT / 'source_measure.py')
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
names = ['array_only.py', 'compact_unpack_open.py', 'structural_open.py', 'compact_open.py']
rows = [{'file': name, **measure.metrics(ROOT / name)} for name in names]
fields = ['normalized_tokens', 'ast_nodes', 'normalized_bytes']
envelope = {k: min(row[k] for row in rows) for k in fields}
record = json.loads((ROOT.parent / 'evidence/all_18_profiles.json').read_text())
record_by_hash = {row['sha256']: row for row in record['programs']}
same_interpreter = platform.python_version() == record['python']
if same_interpreter:
    for row in rows:
        original = record_by_hash[row['sha256']]
        if any(row[k] != original[k] for k in fields):
            raise ValueError('Measurement differs from the recorded source: ' + row['file'])
    if envelope != record['envelope']:
        raise ValueError('Retained sources fail to reproduce the recorded envelope')
result = {
    'python': platform.python_version(), 'commit': manifest['commit'],
    'whole_program_boundary': True, 'checker_code_executed_for_measurement': False,
    'unchanged_payload_hashes_verified': len(manifest['files']),
    'retained_complete_frontier_sources': len(rows),
    'recorded_full_corpus_programs': len(record['programs']),
    'same_interpreter_as_original_measurement': same_interpreter,
    'coordinate_envelope': envelope, 'programs': rows,
    'scope': 'Finite inherited complete-source measurements; no new competing checker or universal lower-bound theorem.',
}
(ROOT / 'evidence.json').write_text(json.dumps(result, indent=2) + '\n')
lines = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
         r'Complete inherited checker & Tokens & AST nodes & Bytes\\', r'\midrule']
for row in rows:
    filename = row['file'].replace('_', r'\_')
    values = [r'\textbf{' + str(row[k]) + '}' if row[k] == envelope[k] else str(row[k]) for k in fields]
    lines.append(r'\texttt{' + filename + '} & ' + ' & '.join(values) + r'\\')
lines.extend([r'\bottomrule', r'\end{tabular}'])
(ROOT / 'table.tex').write_text('\n'.join(lines) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'programs'}, indent=2))
