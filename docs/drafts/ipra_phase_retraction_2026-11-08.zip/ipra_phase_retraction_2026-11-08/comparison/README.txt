UNCHANGED COMPLETE CHECKER FRONTIER AND FOCUSED AUDIT

Sources: ProveIt docs/drafts at commit
4890fd00a5cacfc9881ae282120978f95c3ba392.

Four nondominated complete checker sources are retained byte-for-byte,
together with the unchanged inherited normalizer and license. provenance.json
gives archive/member/hash identities. array_only_review.txt and
array_only_provenance.json preserve their source report's own refinement
proof and its earlier snapshot references; those historical claims describe
that report, not a new result of this package.

OFFLINE REPRODUCTION
  python3 comparison/measure_frontier.py
  python3 comparison/audit_checker.py

The first command verifies every unchanged copied payload's hash, imports
only the inspected measurement module, and measures the complete checker
sources without executing them. It writes comparison/evidence.json and
comparison/table.tex. The main source measurement includes imports and the
full CLI acceptance/rejection wrapper. Comments and genuine docstrings are
excluded. The Python standard runtime is the shared fixed assumption.

CPython 3.12.14 results:
  array_only.py             312 tokens / 348 AST nodes / 920 bytes
  compact_unpack_open.py    313 tokens / 347 AST nodes / 922 bytes
  structural_open.py        316 tokens / 347 AST nodes / 901 bytes
  compact_open.py           317 tokens / 351 AST nodes / 878 bytes

Coordinate envelope: 312 / 347 / 878, attained by different programs.
The full eighteen-profile measurement record is in evidence/all_18_profiles.json
at the package root. The fourteen other sources are identified by immutable
archive/member/hash provenance but are not repackaged. The retained four
reproduce all three minima. The sixteen input archives are identified in
evidence/source_snapshot.json. No old report PDF is included.

All four programs implement the inherited scalar/native calculus. They are
not direct checkers for the new phase-retraction theory. The profiles are
finite observed measurements, not universal lower bounds or an assertion
of a new complete-checker record. *_open.py programs assume ordinary UTF-8
process input with matching decoding/error handling.

The second command replays 28 exact targeted CLI cases in both normal and
optimized Python, plus eight scope/image cases, and writes
evidence/checker_audit.json. All exact CLI inputs are in audit_cases.json;
checker_audit.txt supplies the written argument and limitations. In
particular, D of constant Delta is a valid theorem, but using it to derive
Delta without its base rejects. This audit found no fatal benchmark defect;
it is not a formal verification of the complete inherited decoding theorem.

source_measure.py is the unchanged inherited file. Its own standalone main
expects the original corpus manifest. Use measure_frontier.py here; it calls
the inherited metrics(path) API without needing external files or network.
