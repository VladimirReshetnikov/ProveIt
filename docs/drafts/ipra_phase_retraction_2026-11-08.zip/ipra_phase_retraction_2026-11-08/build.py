"""Compile the complete manuscript with shell escape disabled."""
from pathlib import Path
import json
import platform
import re
import shutil
import subprocess


ROOT = Path(__file__).resolve().parent
BUILD = ROOT / "build"
BUILD.mkdir(exist_ok=True)
command = ["pdflatex", "-no-shell-escape", "-halt-on-error",
           "-interaction=nonstopmode", "-output-directory", str(BUILD),
           "report.tex"]
passes = []
for number in range(1, 4):
    run = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    (BUILD / f"pass_{number}.txt").write_text(run.stdout + run.stderr)
    if run.returncode:
        print((run.stdout + run.stderr)[-6000:])
        raise SystemExit(run.returncode)
    passes.append({"pass": number, "exit_code": run.returncode})
log = (BUILD / "report.log").read_text(errors="replace")
shutil.copyfile(BUILD / "report.pdf", ROOT / "report.pdf")
(ROOT / "evidence" / "latex_build.txt").write_text(log)
info = subprocess.run(["pdfinfo", str(ROOT / "report.pdf")],
                      text=True, capture_output=True, check=True).stdout
pages = int(re.search(r"^Pages:\s+(\d+)", info, re.M).group(1))
receipt = {
    "success": True,
    "python": platform.python_version(),
    "passes": passes,
    "pages": pages,
    "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
    "overfull_boxes": len(re.findall(r"Overfull \\[hv]box", log)),
    "undefined_references": "There were undefined references" in log,
    "shell_escape": False,
    "scope": "Compilation and log checks; visual QA recorded separately",
}
(ROOT / "evidence" / "build.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
