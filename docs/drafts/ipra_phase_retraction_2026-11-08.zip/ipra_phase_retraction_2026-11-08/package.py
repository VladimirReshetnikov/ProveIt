"""Refresh a portable integrity manifest and create a deterministic ZIP."""
from pathlib import Path
import hashlib
import json
import zipfile


ROOT = Path(__file__).resolve().parent
excluded = {"build", "__pycache__", ".DS_Store"}


def payloads():
    return sorted(p for p in ROOT.rglob("*") if p.is_file()
                  and not any(part in excluded for part in p.relative_to(ROOT).parts)
                  and p.name != "MANIFEST.json"
                  and p.suffix not in {".pyc", ".aux", ".out", ".toc"})


entries = []
for path in payloads():
    content = path.read_bytes()
    entries.append({"path": path.relative_to(ROOT).as_posix(), "bytes": len(content),
                    "sha256": hashlib.sha256(content).hexdigest()})
manifest = {"format": 1, "scope": "All packaged members other than this manifest",
            "files": entries}
(ROOT / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
destination = ROOT.parent / (ROOT.name + ".zip")
with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in payloads() + [ROOT / "MANIFEST.json"]:
        info = zipfile.ZipInfo(ROOT.name + "/" + path.relative_to(ROOT).as_posix(),
                               date_time=(2026, 11, 8, 12, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                         compresslevel=9)
with zipfile.ZipFile(destination) as archive:
    bad = archive.testzip()
    if bad:
        raise ValueError("Corrupt archive member: " + bad)
    for entry in entries:
        content = archive.read(ROOT.name + "/" + entry["path"])
        if hashlib.sha256(content).hexdigest() != entry["sha256"]:
            raise ValueError("Archive hash mismatch: " + entry["path"])
print(json.dumps({"archive": destination.name, "members": len(entries) + 1,
                  "bytes": destination.stat().st_size,
                  "sha256": hashlib.sha256(destination.read_bytes()).hexdigest()}, indent=2))
