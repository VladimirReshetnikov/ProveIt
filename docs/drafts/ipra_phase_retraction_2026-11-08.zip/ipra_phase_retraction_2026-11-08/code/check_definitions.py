"""Generic staged-description interpreter and explicitly finite diagnostics.

Only zero and successor are primitive numerical implementations. Every named
helper, including selectors, parity, halving, and signed iteration, is evaluated
from definitions.json. Closed-form expressions occur only in expected diagnostic
values. This external interpreter is not a function symbol of the theory and
does not assert a primitive-recursive universal evaluator.
On raw descriptions it is an ordinary external partial computable execution
procedure; the finite validated descriptions have their usual terminating
primitive-recursive semantics. No uniform primitive-recursive bound is claimed.
"""
import copy
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path


class InvalidDescription(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise InvalidDescription(message)


def validate(data):
    require(data.get("format") == "finite-pr-declarations-v1", "unknown declaration format")
    known, declarations = {"0": 0, "S": 1}, {}

    def check_term(term, variables):
        if isinstance(term, str):
            require(term in variables, "unbound variable: " + term)
            return
        require(isinstance(term, list) and term, "term must be a variable or application")
        symbol = term[0]
        require(isinstance(symbol, str) and symbol in known,
                "reference is not an earlier-stage symbol: " + str(symbol))
        require(len(term) - 1 == known[symbol], "wrong call arity for " + symbol)
        for argument in term[1:]:
            check_term(argument, variables)

    for declaration in data["declarations"]:
        name, kind = declaration["name"], declaration["kind"]
        parameters, arity = declaration["parameters"], declaration["arity"]
        require(isinstance(name, str) and name.isidentifier() and name not in known,
                "duplicate or invalid declaration name")
        require(isinstance(parameters, list) and all(isinstance(p, str) and p.isidentifier() for p in parameters),
                "invalid parameter list")
        require(len(parameters) == len(set(parameters)) and not {"z", "state"}.intersection(parameters),
                "duplicate or reserved parameter")
        require(type(arity) is int and arity >= 0, "invalid declared arity")
        if kind == "composition":
            require(arity == len(parameters), "composition arity does not match parameters")
            check_term(declaration["body"], set(parameters))
        else:
            require(kind == "primitive_recursion", "unknown description constructor")
            require(arity == len(parameters) + 1, "recursion arity does not match parameters")
            check_term(declaration["base"], set(parameters))
            check_term(declaration["step"], set(parameters) | {"z", "state"})
        known[name], declarations[name] = arity, declaration
    return known, declarations


class Interpreter:
    def __init__(self, table):
        self.arities, self.declarations = validate(table)
        self.term_evaluations = 0
        self.recursion_steps = 0

    def evaluate_term(self, term, environment):
        self.term_evaluations += 1
        if isinstance(term, str):
            return environment[term]
        arguments = tuple(self.evaluate_term(t, environment) for t in term[1:])
        return self.call(term[0], arguments)

    @lru_cache(maxsize=None)
    def call(self, name, arguments):
        require(name in self.arities and len(arguments) == self.arities[name], "invalid invocation arity")
        require(all(type(a) is int and a >= 0 for a in arguments), "inputs must be natural numbers")
        if name == "0":
            return 0
        if name == "S":
            return arguments[0] + 1
        declaration = self.declarations[name]
        if declaration["kind"] == "composition":
            environment = dict(zip(declaration["parameters"], arguments))
            return self.evaluate_term(declaration["body"], environment)
        environment = dict(zip(declaration["parameters"], arguments[1:]))
        value = self.evaluate_term(declaration["base"], environment)
        for counter in range(arguments[0]):
            self.recursion_steps += 1
            step_environment = dict(environment, z=counter, state=value)
            value = self.evaluate_term(declaration["step"], step_environment)
        return value


def standard_decode(code):
    return code // 2 if code % 2 == 0 else -(code // 2) - 1


def standard_encode(integer):
    return 2 * integer if integer >= 0 else -2 * integer - 1


def main():
    code_directory = Path(__file__).resolve().parent
    table_path = code_directory / "definitions.json"
    table = json.loads(table_path.read_text(encoding="utf-8"))
    interpreter = Interpreter(table)
    call = lambda name, *args: interpreter.call(name, tuple(args))
    rows, total = [], 0

    def check(name, inputs, actual, expected, domain):
        nonlocal total
        count = 0
        for arguments in inputs:
            arguments = arguments if isinstance(arguments, tuple) else (arguments,)
            got, wanted = actual(*arguments), expected(*arguments)
            if got != wanted:
                raise AssertionError((name, arguments, got, wanted))
            count += 1
        rows.append({"name": name, "cases": count, "domain": domain, "passed": True})
        total += count

    expected_unary = {
        "P": lambda n: max(n - 1, 0),
        "delta": lambda n: int(n == 0),
        "sg": lambda n: int(n != 0),
        "D": lambda n: 2 * n,
        "E": lambda n: n % 2,
        "H": lambda n: n // 2,
        "B": lambda n: standard_encode(standard_decode(n) + 1),
        "N": lambda n: 0 if n == 0 else 2 * n - 1,
    }
    for name, expected in expected_unary.items():
        check(name + " values", range(33), lambda n, name=name: call(name, n), expected, "0 <= n <= 32")
    check("selector values", itertools.product(range(33), range(5), range(5)),
          lambda n, a, b: call("C", n, a, b), lambda n, a, b: a if n == 0 else b,
          "0 <= n <= 32; 0 <= a,b <= 4")
    for name, expected in (("I_S", lambda n, a: n + a),
                           ("I_B", lambda n, a: standard_encode(standard_decode(a) + n))):
        check(name + " values", itertools.product(range(13), range(25)),
              lambda n, a, name=name: call(name, n, a), expected, "0 <= n <= 12; 0 <= a <= 24")
    check("equality characteristic values", itertools.product(range(13), repeat=2),
          lambda a, b: call("epsilon", a, b), lambda a, b: int(a != b), "0 <= a,b <= 12")
    identities = {
        "retraction H(Dn)=n": (lambda n: call("H", call("D", n)), lambda n: n),
        "half two-step": (lambda n: call("H", n + 2), lambda n: call("H", n) + 1),
        "positive intertwining": (lambda n: call("B", call("D", n)), lambda n: call("D", n + 1)),
        "backward negative clock": (lambda n: call("B", call("N", n + 1)), lambda n: call("N", n)),
        "positive clock": (lambda n: call("I_B", n, 0), lambda n: call("D", n)),
        "negative diagonal": (lambda n: call("I_B", n, call("N", n)), lambda n: 0),
        "signed update fixed-point-freeness": (lambda n: call("B", n) != n, lambda n: True),
    }
    for name, (actual, expected) in identities.items():
        check(name, range(33), actual, expected, "0 <= n <= 32")
    check("one-step commutation", itertools.product(range(13), repeat=2),
          lambda n, a: call("B", call("I_B", n, a)),
          lambda n, a: call("I_B", n, call("B", a)), "0 <= n,a <= 12")
    check("commuting iterates", itertools.product(range(7), range(7), range(9)),
          lambda k, n, a: call("I_B", k, call("I_B", n, a)),
          lambda k, n, a: call("I_B", n, call("I_B", k, a)), "0 <= k,n <= 6; 0 <= a <= 8")

    mutations = [
        ("forward_reference", lambda d: d[0].update(step=["D", "z"])),
        ("wrong_call_arity", lambda d: d[2].update(body=["C", "u", ["0"]])),
        ("direct_definition_cycle", lambda d: d[5].update(step=["E", "state"])),
        ("two_definition_cycle", lambda d: (d[0].update(step=["C", "z", ["0"], ["0"]]),
                                            d[1].update(step=["P", "state"]))),
        ("undeclared_state_in_base", lambda d: d[0].update(base="state")),
        ("wrong_declared_arity", lambda d: d[1].update(arity=2)),
        ("duplicate_name", lambda d: d[10].update(name="B")),
    ]
    negative = []
    for name, mutate in mutations:
        malformed = copy.deepcopy(table)
        mutate(malformed["declarations"])
        try:
            validate(malformed)
        except InvalidDescription as error:
            negative.append({"test": name, "rejected": True, "reason": str(error)})
        else:
            raise AssertionError("invalid description accepted: " + name)

    report = {
        "scope": "Finite standard-model diagnostics of exact staged descriptions; not universal proofs or a complete iPRA checker.",
        "evaluator": {"primitive_numerical_operations": ["zero", "successor"],
                      "computability_scope": "Ordinary external partial computable procedure on descriptions; not a primitive-recursive universal evaluator inside the theory.",
                      "named_helpers_use_closed_form_shortcuts": False,
                      "cache": str(interpreter.call.cache_info()),
                      "term_evaluations": interpreter.term_evaluations,
                      "declared_recursion_steps_executed": interpreter.recursion_steps,
                      "object_language_evaluator_symbol": False},
        "declaration_order": [d["name"] for d in table["declarations"]],
        "arities": interpreter.arities,
        "finite_checks": rows,
        "total_finite_cases": total,
        "invalid_descriptions": negative,
        "all_checks_passed": True,
        "sha256": {"definitions.json": hashlib.sha256(table_path.read_bytes()).hexdigest(),
                   "check_definitions.py": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
    }
    output = code_directory.parent / "evidence" / "description_diagnostics.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"declarations": len(table["declarations"]), "finite_cases": total,
                      "invalid_descriptions_rejected": len(negative),
                      "all_checks_passed": True}, indent=2))


if __name__ == "__main__":
    main()
