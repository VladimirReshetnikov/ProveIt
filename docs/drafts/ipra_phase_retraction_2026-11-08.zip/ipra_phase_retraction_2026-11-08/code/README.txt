FINITE PR DESCRIPTION TABLE AND DIAGNOSTICS
==========================================

Run from the package root:

    python3 code/check_definitions.py

definitions.json exactly records the twelve fixed helpers used in Sections 2
and 5 of the report, in an acyclic declaration order. A variable is a string;
an application is [name, argument, ...]. Only 0 and S are initial symbols.
A composition declaration has a body term in its named parameters. A recursion
declaration has its counter first, a base term in the passive parameters,
and a step term with additional variables z and state. The step at counter
z+1 is evaluated using z and the preceding output state.

These are finite abbreviations for the report's standard PR description trees:
compile a variable to its projection, 0 to the appropriate zero description,
an application to composition, and a base/step pair to primitive recursion.
Earlier-stage helper references expand finitely. There are no forward or
self references, implicit recursive definitions, or numerically supplied
program codes in the arithmetic language.

The interpreter validates arities and stages before execution. It evaluates
each helper by traversing its actual body/base/step term, using a loop for the
declared primitive recursion and caching completed calls. In particular it
does not replace doubling, parity, halving, the selector, or the signed
iterator with their familiar closed forms. The only primitive numerical
implementations are zero and successor. Closed forms are used solely as
independent expected values in the finite diagnostics.

The external interpreter is an ordinary partial computable procedure on raw
descriptions. Its successful finite runs do not provide an object-language
universal primitive-recursive evaluator, a uniform primitive-recursive time
bound, or a proof of a universally quantified equation. No such evaluator
symbol occurs in the theory. The report's internal mathematical proofs bear
the universal proof obligations.

evidence/description_diagnostics.json records the exact finite domains,
case counts, rejection reasons for malformed descriptions, executed recursion
step count, cache statistics, and SHA-256 hashes. The diagnostics include
the equality characteristic on 0..12 and basic numerical behavior on 0..32.
