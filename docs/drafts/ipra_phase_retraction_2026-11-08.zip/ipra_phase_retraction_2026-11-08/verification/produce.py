"""Independent symbolic proof construction; does not import the replay checker."""
import json
from pathlib import Path


Z = ("0",)
O = ("S", Z)


def T(name, *arguments):
    return (name, *arguments)


def E(left, right):
    return ("eq", left, right)


def replace(expression, variable, value):
    if isinstance(expression, str):
        return value if expression == variable else expression
    return (expression[0], *(replace(x, variable, value) for x in expression[1:]))


class Builder:
    def __init__(self, task):
        self.task, self.steps, self.outputs, self.markers = task, [], [], {}

    def add(self, data, output):
        self.steps.append(data)
        self.outputs.append(output)
        return len(self.steps) - 1

    def refl(self, value):
        return self.add({"op": "refl", "term": value}, E(value, value))

    def schema(self, name, arg):
        r, f = T("r", arg, "a"), T("f", arg, "a")
        outputs = {
            "base": E(T("r", Z, "a"), Z),
            "stationary": E(T("r", T("S", arg), "a"), r),
            "coverage": ("or", E(arg, Z), E(arg, T("S", T("P", arg)))),
            "recurrence": E(T("f", T("S", arg), "a"), T("S", f)),
            "intertwine": E(T("D", T("S", arg)), T("h", T("D", arg))),
            "rho": E(T("H", T("D", arg)), arg),
        }
        return self.add({"op": "schema", "name": name, "arg": arg}, outputs[name])

    def ax(self, name, *args):
        if name in ("I0", "A0"):
            output = E(T(name[0], Z, args[0]), args[0])
        elif name in ("IS", "AS"):
            n, a = args
            output = E(T(name[0], T("S", n), a), T("h" if name == "IS" else "S", T(name[0], n, a)))
        elif name == "C0":
            output = E(T("C", Z, *args), args[0])
        else:
            n, a, b = args
            output = E(T("C", T("S", n), a, b), b)
        return self.add({"op": "axiom", "name": name, "args": args}, output)

    def assume(self, formula):
        return self.add({"op": "assume", "formula": formula}, formula)

    def sym(self, proof):
        _, a, b = self.outputs[proof]
        return self.add({"op": "sym", "proof": proof}, E(b, a))

    def tr(self, left, right):
        _, a, b = self.outputs[left]
        _, c, d = self.outputs[right]
        assert b == c
        return self.add({"op": "trans", "left": left, "right": right}, E(a, d))

    def cong(self, symbol, *proofs):
        a = T(symbol, *(self.outputs[p][1] for p in proofs))
        b = T(symbol, *(self.outputs[p][2] for p in proofs))
        return self.add({"op": "cong", "symbol": symbol, "proofs": proofs}, E(a, b))

    def unique(self, proof, body):
        output = E(replace(body, "x", "t"), T("I", "t", replace(body, "x", Z)))
        return self.add({"op": "unique", "rule": "h", "body": body,
                         "counter": "z", "target": "t", "proof": proof}, output)

    def cases(self, disj, la, left, ra, right):
        assert self.outputs[left] == self.outputs[right]
        return self.add({"op": "cases", "disjunction": disj,
                         "left_assumption": la, "left": left,
                         "right_assumption": ra, "right": right}, self.outputs[left])

    def save(self, directory):
        output = {"task": self.task, "steps": self.steps, "markers": self.markers}
        path = directory / (self.task + ".json")
        path.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
        return path


def phase():
    b = Builder("phase")
    az, haz = T("I", "z", Z), T("h", T("I", "z", Z))
    cz, ct = T("r", "z", "a"), T("r", "t", "a")
    range_z = b.schema("coverage", cz)
    left_a, right_a = b.assume(E(cz, Z)), b.assume(E(cz, T("S", T("P", cz))))

    def recurrence_branch(assumption, one):
        next_c = b.tr(b.schema("stationary", "z"), assumption)
        next_a = b.ax("IS", "z", Z)
        next_F = b.cong("C", next_c, next_a, b.cong("h", next_a))
        select_next = b.ax("CS", T("P", cz), haz, T("h", haz)) if one else b.ax("C0", haz, T("h", haz))
        lhs = b.tr(next_F, select_next)
        now_F = b.cong("C", assumption, b.refl(az), b.refl(haz))
        select_now = b.ax("CS", T("P", cz), az, haz) if one else b.ax("C0", az, haz)
        rhs = b.cong("h", b.tr(now_F, select_now))
        return b.tr(lhs, b.sym(rhs))

    left = recurrence_branch(left_a, False)
    right = recurrence_branch(right_a, True)
    recurrence = b.cases(range_z, left_a, left, right_a, right)
    body = T("C", T("r", "x", "a"), T("I", "x", Z), T("h", T("I", "x", Z)))
    uniqueness = b.unique(recurrence, body)
    i00 = b.ax("I0", Z)
    base = b.cong("C", b.schema("base", Z), i00, b.cong("h", i00))
    base = b.tr(base, b.ax("C0", Z, T("h", Z)))
    clock = b.tr(uniqueness, b.cong("I", b.refl("t"), base))

    at, hat = T("I", "t", Z), T("h", T("I", "t", Z))
    range_t = b.schema("coverage", ct)
    left_t, right_t = b.assume(E(ct, Z)), b.assume(E(ct, T("S", T("P", ct))))
    phase_one = b.cong("C", right_t, b.refl(at), b.refl(hat))
    phase_one = b.tr(phase_one, b.ax("CS", T("P", ct), at, hat))
    fixed_point = b.tr(b.sym(phase_one), clock)
    contradiction = b.add({"op": "no_fix", "proof": fixed_point}, ("bot",))
    impossible = b.add({"op": "explode", "proof": contradiction, "formula": E(ct, Z)}, E(ct, Z))
    b.cases(range_t, left_t, left_t, right_t, impossible)
    b.markers = {"uniqueness": uniqueness, "recurrence_case": recurrence,
                 "undischarged_branch": left, "fixed_point": fixed_point,
                 "contradiction": contradiction}
    return b


def rho_to_successor():
    b = Builder("rho_to_successor")
    fz, f0, ft = T("f", "z", "a"), T("f", Z, "a"), T("f", "t", "a")
    lifted = b.cong("D", b.schema("recurrence", "z"))
    lifted = b.tr(lifted, b.schema("intertwine", fz))
    first = b.unique(lifted, T("D", T("f", "x", "a")))

    az = T("A", "z", f0)
    canonical = b.cong("D", b.ax("AS", "z", f0))
    canonical = b.tr(canonical, b.schema("intertwine", az))
    second = b.unique(canonical, T("D", T("A", "x", f0)))
    initial = b.cong("D", b.ax("A0", f0))
    second = b.tr(second, b.cong("I", b.refl("t"), initial))
    doubled = b.tr(first, b.sym(second))
    recovered = b.cong("H", doubled)
    decoded = b.tr(b.sym(b.schema("rho", ft)), recovered)
    b.tr(decoded, b.schema("rho", T("A", "t", f0)))
    b.markers = {"first_uniqueness": first, "second_uniqueness": second,
                 "doubled_equality": doubled, "decoded_equality": recovered}
    return b


if __name__ == "__main__":
    destination = Path(__file__).resolve().parent / "certificates"
    destination.mkdir(exist_ok=True)
    for construction in (phase, rho_to_successor):
        print(construction().save(destination).name)
