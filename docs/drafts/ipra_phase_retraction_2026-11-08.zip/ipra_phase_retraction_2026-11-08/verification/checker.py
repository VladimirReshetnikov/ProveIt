"""Scoped symbolic replay for two relative lemmas; NOT an iPRA checker."""
import json
import sys


class Invalid(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


def frozen(value):
    return tuple(map(frozen, value)) if isinstance(value, list) else value


ZERO = ("0",)
ONE = ("S", ZERO)
VARIABLES = frozenset(("x", "z", "t", "a", "v"))
ARITY = {"0": 0, "S": 1, "P": 1, "h": 1, "D": 1, "H": 1,
         "r": 2, "f": 2, "I": 2, "A": 2, "C": 3}


def term(value):
    if isinstance(value, str):
        require(value in VARIABLES, "unknown numerical variable")
    else:
        require(isinstance(value, tuple) and value, "not a numerical term")
        require(value[0] in ARITY, "unknown numerical function")
        require(len(value) == ARITY[value[0]] + 1, "wrong function arity")
        for argument in value[1:]:
            term(argument)
    return value


def free(value):
    if isinstance(value, str):
        return {value}
    return set().union(*(free(x) for x in value[1:])) if len(value) > 1 else set()


def sub(value, variable, replacement):
    if isinstance(value, str):
        return replacement if value == variable else value
    return (value[0], *(sub(x, variable, replacement) for x in value[1:]))


def eq(left, right):
    return ("eq", term(left), term(right))


def formula(value):
    if value[0] == "eq":
        require(len(value) == 3, "wrong equality arity")
        eq(*value[1:])
    elif value[0] == "or":
        require(len(value) == 3, "wrong disjunction arity")
        formula(value[1])
        formula(value[2])
    else:
        require(value == ("bot",), "unknown formula")
    return value


def problem(task):
    f = ("f", "t", "a")
    f0 = ("f", ZERO, "a")
    if task == "phase":
        return {"base", "stationary", "coverage"}, eq(("r", "t", "a"), ZERO)
    require(task == "rho_to_successor", "unknown proof obligation")
    return {"recurrence", "intertwine", "rho"}, eq(f, ("A", "t", f0))


def schema(name, argument):
    u = term(argument)
    r = ("r", u, "a")
    f = ("f", u, "a")
    if name == "base":
        require(u == ZERO, "base schema has no arbitrary index")
        return eq(("r", ZERO, "a"), ZERO)
    if name == "stationary":
        return eq(("r", ("S", u), "a"), r)
    if name == "coverage":
        return ("or", eq(u, ZERO), eq(u, ("S", ("P", u))))
    if name == "recurrence":
        return eq(("f", ("S", u), "a"), ("S", f))
    if name == "intertwine":
        return eq(("D", ("S", u)), ("h", ("D", u)))
    require(name == "rho", "unknown hypothesis schema")
    return eq(("H", ("D", u)), u)


def axiom(name, arguments):
    if name in ("I0", "A0"):
        a, = arguments
        return eq((name[0], ZERO, a), a)
    if name in ("IS", "AS"):
        n, a = arguments
        op = "h" if name == "IS" else "S"
        return eq((name[0], ("S", n), a), (op, (name[0], n, a)))
    if name == "C0":
        a, b = arguments
        return eq(("C", ZERO, a, b), a)
    require(name == "CS", "unknown computation equation")
    n, a, b = arguments
    return eq(("C", ("S", n), a, b), b)


def verify(certificate, disabled=()):
    allowed, goal = problem(certificate["task"])
    lines, assumption_ids, counts = [], set(), {}

    def get(index):
        require(type(index) is int and 0 <= index < len(lines), "invalid premise reference")
        return lines[index]

    def equality(index):
        value, dependencies = get(index)
        require(value[0] == "eq", "equality premise required")
        return value[1], value[2], dependencies

    for index, raw in enumerate(certificate["steps"]):
        step = {k: frozen(v) for k, v in raw.items()}
        op, deps = step["op"], frozenset()
        counts[op] = counts.get(op, 0) + 1
        try:
            if op == "refl":
                out = eq(step["term"], step["term"])
            elif op == "schema":
                require(step["name"] in allowed - set(disabled), "unavailable hypothesis schema")
                out = schema(step["name"], step["arg"])
            elif op == "axiom":
                out = axiom(step["name"], step["args"])
            elif op == "assume":
                out, deps = formula(step["formula"]), frozenset({index})
                assumption_ids.add(index)
            elif op == "sym":
                a, b, deps = equality(step["proof"])
                out = eq(b, a)
            elif op == "trans":
                a, b, d = equality(step["left"])
                c, e, f = equality(step["right"])
                require(b == c, "transitivity middle terms differ")
                out, deps = eq(a, e), d | f
            elif op == "cong":
                premises = [equality(i) for i in step["proofs"]]
                out = eq((step["symbol"], *(p[0] for p in premises)),
                         (step["symbol"], *(p[1] for p in premises)))
                deps = frozenset().union(*(p[2] for p in premises))
            elif op == "unique":
                require(step["rule"] == "h", "only the specified h-uniqueness rule is available")
                body, z, target = term(step["body"]), step["counter"], term(step["target"])
                require(z in VARIABLES and z != "x", "invalid recurrence eigenvariable")
                premise, deps = get(step["proof"])
                retained_free = {"a"}.union(*(free(lines[i][0]) for i in deps))
                require(z not in retained_free | (free(body) - {"x"}) | free(target), "freshness failure")
                require(premise == eq(sub(body, "x", ("S", z)),
                                      ("h", sub(body, "x", z))), "wrong uniqueness recurrence")
                out = eq(sub(body, "x", target), ("I", target, sub(body, "x", ZERO)))
            elif op == "cases":
                disjunction, d = get(step["disjunction"])
                l, r = step["left_assumption"], step["right_assumption"]
                require(disjunction[0] == "or", "disjunction required")
                require(l in assumption_ids and r in assumption_ids, "case assumptions required")
                require(lines[l][0] == disjunction[1] and lines[r][0] == disjunction[2], "wrong case assumptions")
                a, da = get(step["left"])
                b, db = get(step["right"])
                require(a == b and r not in da and l not in db, "invalid case branches")
                out, deps = a, d | (da - {l}) | (db - {r})
            elif op == "no_fix":
                require(certificate["task"] == "phase" and "no_fix" not in disabled, "fixed-point-free hypothesis unavailable")
                a, b, deps = equality(step["proof"])
                require(a == ("h", b), "not an h fixed point")
                out = ("bot",)
            else:
                require(op == "explode", "unknown inference")
                previous, deps = get(step["proof"])
                require(previous == ("bot",), "falsity premise required")
                out = formula(step["formula"])
            lines.append((formula(out), deps))
        except (Invalid, KeyError, TypeError, ValueError, IndexError) as error:
            raise Invalid(f"step {index} ({op}): {error}") from error
    require(lines and lines[-1] == (goal, frozenset()), "wrong endpoint or undischarged assumptions")
    return {"task": certificate["task"], "accepted": True, "nodes": len(lines), "inferences": counts}


if __name__ == "__main__":
    with open(sys.argv[1], encoding="utf-8") as stream:
        print(json.dumps(verify(json.load(stream)), indent=2, sort_keys=True))
