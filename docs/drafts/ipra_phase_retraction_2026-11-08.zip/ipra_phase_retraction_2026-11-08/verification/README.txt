SCOPED SYMBOLIC VERIFICATION
===========================

This directory contains independently constructed proof certificates and a
small replay checker for two relative lemmas in the report. It is not a
complete iPRA checker, not a proof-assistant formalization of the whole
report, and not a competitor in the repository's checker-size benchmark.

Run with Python 3 (standard library only):

    python3 verify_all.py

The command reconstructs both certificates using produce.py, replays them
using checker.py, checks targeted invalid mutations, and writes results.json.
The producer does not import the checker. The checker's final proof
obligations and permitted hypothesis schemas are fixed independently of
the certificate's input. There is no eval, external prover, search, numeric
normalization oracle, or hidden induction inference.

TERMS, FORMULAS, AND PARAMETERS

The checker has one numerical sort. Function arities are checked, and a
formula cannot be used as a numerical term. Symbols r and f are schematic
fixed numerical terms of the recurrence argument and a passive numerical
parameter a. The symbols h, D, and H are fixed schematic unary numerical
operations. I is initialized iteration of h; A is initialized iteration
of successor S. C is the zero/successor selector, and P appears only in
the explicit coverage formula. These are schematic roles in a relative
metatheorem, not object-level variables ranging over primitive-recursive
functions.

The recurrence variable z, target t, and passive parameter a are distinct.
The template placeholder x is replaced syntactically. The uniqueness
checker verifies the recurrence's exact shape and checks that z is absent
from the target, passive template parameters, global retained data, and
all undischarged local assumptions. Every proof node carries its local
assumption dependencies; disjunction elimination removes only the two
specified case assumptions, and the exact final endpoint must have no
remaining local dependencies.

1. phase.json: direct phase-switch lemma (57 proof nodes)

Given:

    r(0,a) = 0,
    r(Sn,a) = r(n,a),
    x = 0 or x = S(Px),
    h(x) != x,
    I(0,b) = b, I(Sn,b) = h(I(n,b)),
    C(0,b,c) = b, C(Sn,b,c) = c,
    the contextual uniqueness rule for the one fixed update h,

the certificate proves r(t,a)=0. It uses the numerical term

    F(n) = C(r(n,a), I(n,0), h(I(n,0))).

Both recurrence cases are proved and discharged before the single
uniqueness inference. F(0)=0 is proved explicitly. The successor case
of coverage at the target would then give a fixed point of h, so
intuitionistic case elimination gives r(t,a)=0.

The certificate assumes no Boolean range, no sign function, no numerical
equality-reflection test, and no inverse or cancellation property of I.
The hypotheses that the report establishes about the specific signed
update B (especially fixed-point-freeness) are NOT proved by this capsule.

2. rho_to_successor.json: the retraction lifting lemma (23 proof nodes)

Given:

    f(Sn,a) = S(f(n,a)),
    D(Sx) = h(Dx),
    H(Dx) = x,
    I(0,b) = b, I(Sn,b) = h(I(n,b)),
    A(0,b) = b, A(Sn,b) = S(A(n,b)),
    the contextual uniqueness rule for h,

the certificate proves

    f(t,a) = A(t,f(0,a)).

It compares D(f(n,a)) and D(A(n,f(0,a))) using two h-uniqueness
inferences, explicitly normalizes their common initializer, and applies
H and the two required retraction instances. Successor uniqueness is
not available to the checker. The intertwining equation D(Sx)=h(Dx)
and the retraction are explicit retained hypotheses of this relative
lemma. The report proves the former for h=B using the phase-switch
lemma and supplies the latter as its one fixed additional equation.

TRUST BOUNDARY

The primitive replay inferences are equality reflexivity, symmetry,
transitivity and congruence; the displayed computation equations;
instances of the problem's explicitly listed hypotheses; ordinary
disjunction elimination, application of the fixed-point-free hypothesis,
and falsity elimination; and the single specified uniqueness schema.
The logical rules are conventional intuitionistic rules, not an appeal
to a Boolean truth-table oracle. The certificates do not establish
soundness or completeness of the repository's native logical calculus.

The numerical bridge from zero stationarity to signed-counter equality
reflection, arbitrary quantifier-free induction, and both complete
interpretation composites remains the mathematical proof in the report.
No assertion about those parts is inferred merely from these checks.

NEGATIVE CHECKS

verify_all.py checks rejection when an unavailable successor-uniqueness
rule is requested; a recurrence eigenvariable captures a passive
parameter; a case assumption containing the eigenvariable remains
undischarged; the fixed-point equation is wrong; coverage, fixed-point-
freeness, intertwining, or the retraction is unavailable; a case is
discharged incorrectly; the lifted uniqueness template is wrong; a
formula is used as a numerical term; a numerical arity is malformed;
a premise reference points forward; or the final endpoint is wrong.
The precise error for each rejected mutation is recorded in results.json.

Deleting a hypothesis in these tests means replay of this particular
certificate must fail. It is not a mathematical independence claim
about the corresponding weakened theory.
