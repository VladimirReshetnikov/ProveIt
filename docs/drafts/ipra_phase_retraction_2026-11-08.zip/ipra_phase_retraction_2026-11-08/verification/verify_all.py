"""Replay the certificates and reject targeted invalid mutations."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from checker import Invalid, verify


ROOT = Path(__file__).resolve().parent


def mutated(original, action):
    result = copy.deepcopy(original)
    action(result)
    return result


def update_step(certificate, marker, **changes):
    certificate["steps"][certificate["markers"][marker]].update(changes)


def overwrite_step(certificate, marker, replacement):
    certificate["steps"][certificate["markers"][marker]] = replacement


def first_operation(certificate, operation):
    return next(s for s in certificate["steps"] if s["op"] == operation)


def main():
    subprocess.run([sys.executable, str(ROOT / "produce.py")], check=True,
                   capture_output=True, text=True)
    phase = json.loads((ROOT / "certificates/phase.json").read_text())
    rho = json.loads((ROOT / "certificates/rho_to_successor.json").read_text())
    positives = [verify(phase), verify(rho)]
    tests = [
        ("unavailable_successor_uniqueness", mutated(phase, lambda c:
         update_step(c, "uniqueness", rule="S")), ()),
        ("eigenvariable_captures_passive_parameter", mutated(phase, lambda c:
         update_step(c, "uniqueness", counter="a")), ()),
        ("undischarged_case_at_uniqueness", mutated(phase, lambda c:
         update_step(c, "uniqueness", proof=c["markers"]["undischarged_branch"])), ()),
        ("wrong_fixed_point_equation", mutated(phase, lambda c:
         overwrite_step(c, "fixed_point", {"op": "refl", "term": ["I", "t", ["0"]]})), ()),
        ("coverage_not_available", phase, ("coverage",)),
        ("fixed_point_freeness_not_available", phase, ("no_fix",)),
        ("wrong_case_discharge", mutated(phase, lambda c:
         c["steps"][-1].update(right_assumption=c["steps"][-1]["left_assumption"])), ()),
        ("missing_retraction", rho, ("rho",)),
        ("missing_intertwining", rho, ("intertwine",)),
        ("wrong_lifted_template", mutated(rho, lambda c:
         update_step(c, "first_uniqueness", body=["f", "x", "a"])), ()),
        ("formula_used_as_numerical_term", mutated(phase, lambda c:
         first_operation(c, "refl").update(term=["eq", ["0"], ["0"]])), ()),
        ("malformed_numerical_arity", mutated(phase, lambda c:
         first_operation(c, "refl").update(term=["S", ["0"], ["0"]])), ()),
        ("forward_premise_reference", mutated(rho, lambda c:
         first_operation(c, "trans").update(left=len(c["steps"]) + 1)), ()),
        ("wrong_final_endpoint", mutated(rho, lambda c:
         c["steps"].append({"op": "refl", "term": "t"})), ()),
    ]
    rejected = []
    for name, certificate, disabled in tests:
        try:
            verify(certificate, disabled=disabled)
        except Invalid as error:
            rejected.append({"test": name, "rejected": True, "reason": str(error)})
        else:
            raise RuntimeError("Invalid mutation was accepted: " + name)
    files = sorted(ROOT.glob("*.py")) + sorted((ROOT / "certificates").glob("*.json"))
    report = {
        "scope": "Two relative symbolic lemmas, not a complete iPRA proof checker or formalization",
        "positive_certificates": positives,
        "negative_mutations": rejected,
        "all_checks_passed": True,
        "sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
    }
    (ROOT / "results.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"positive_certificates": len(positives),
                      "positive_nodes": sum(x["nodes"] for x in positives),
                      "negative_mutations_rejected": len(rejected),
                      "all_checks_passed": True}, indent=2))


if __name__ == "__main__":
    main()
