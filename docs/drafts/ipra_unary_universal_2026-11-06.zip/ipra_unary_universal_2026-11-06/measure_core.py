"""Supplementary uniform comparison after removing imports and CLI blocks.

The primary report compares complete acceptance programs. This deliberately
different boundary checks how that result changes when all top-level imports
and __name__-guarded CLI blocks are removed identically from every source.
"""
import ast
import io
import json
import sys
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIELDS = ('ast_nodes', 'normalized_tokens', 'normalized_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


def measure(path):
    tree = ast.parse(path.read_text())
    for node in ast.walk(tree):
        if (isinstance(node, (ast.Module, ast.FunctionDef,
                              ast.AsyncFunctionDef, ast.ClassDef))
                and ast.get_docstring(node, clean=False) is not None):
            node.body.pop(0)
    tree.body = [n for n in tree.body if not isinstance(n, (ast.Import, ast.ImportFrom))
                 and not (isinstance(n, ast.If) and '__name__' in ast.unparse(n.test))]
    normalized = ast.unparse(tree) + '\n'
    return {'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_tokens': sum(t.type not in IGNORED for t in
                                     tokenize.generate_tokens(io.StringIO(normalized).readline)),
            'normalized_bytes': len(normalized.encode())}


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    baselines = [{'source': e['source'], **measure(ROOT / 'comparison' / e['source'])}
                 for e in manifest['baselines']]
    envelope = {f: min(r[f] for r in baselines) for f in FIELDS}
    candidates = [{'source': p, **measure(ROOT / p)}
                  for p in ('checker.py', 'checker_demand.py')]
    result = {'python': sys.version, 'boundary': __doc__, 'baselines': baselines,
              'envelope': envelope, 'candidates': candidates,
              'conclusion': 'The new programs improve the complete-program boundary, '
                            'but do not improve every coordinate of this stripped-core boundary.'}
    (ROOT / 'results/core_metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'envelope': envelope, 'candidates': candidates}, indent=2))


if __name__ == '__main__':
    main()
