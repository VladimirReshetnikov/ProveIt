"""Build substantial unary-U arithmetic certificates from frozen proof steps.

The proof producer is outside the trusted kernel.  It reuses exact arithmetic
step certificates identified by translator.py, discharges their equation
induction hypotheses, and supplies computation-based initial cases.  Every
generated source and target sequent is checked independently.
"""

import json
from pathlib import Path

from translator import ROOT, SOURCE, STRICT, DEMAND, compile_sequent, save_json, sha


def eq(s, t):
    return ["=", s, t]


def successor(t):
    return ["s", t]


def recursor(n, a, h):
    return ["r", n, a, h]


def lift(t):
    return SOURCE.subst(t, formula=False)


def reflexivity(t):
    computation = eq(recursor(0, t, 0), t)
    return [computation, [], eq(1, lift(t)), []]


def symmetry(s, t, p):
    return [eq(s, t), p, eq(1, lift(s)), reflexivity(s)]


def transitivity(s, t, u, p, q):
    return [eq(t, u), q, eq(lift(s), 1), p]


def replace_at(t, path, value):
    if not path:
        return value
    result = list(t)
    result[path[0]] = replace_at(result[path[0]], path[1:], value)
    return result


def redex(t):
    """Find one computation outside all recursor update binders."""
    if type(t) is int:
        return None
    tag, *parts = t
    if tag == "r":
        n, a, h = parts
        if n == 0:
            return (), t, a
        if isinstance(n, list) and n[0] == "s":
            previous = n[1]
            value = SOURCE.subst(h, [recursor(previous, a, h), previous, -2],
                                 formula=False)
            return (), t, value
        positions = (1, 2)
    else:
        positions = (1,)
    for index in positions:
        child = redex(t[index])
        if child is not None:
            path, old, new = child
            return (index, *path), old, new
    return None


def normalization(t):
    """Return a finite equational normalization proof, using no rewrite oracle."""
    original, current, certificate = t, t, reflexivity(t)
    for _ in range(10000):
        step = redex(current)
        if step is None:
            return current, certificate
        path, old, new = step
        rewritten = replace_at(current, path, new)
        if path:
            motive = eq(lift(current), replace_at(lift(current), path, 1))
            step_proof = [eq(old, new), [], motive, reflexivity(current)]
        else:
            step_proof = []
        certificate = transitivity(original, current, rewritten,
                                   certificate, step_proof)
        current = rewritten
    raise RuntimeError("Proof producer reached its conservative rewrite limit")


def computation_equality(s, t):
    left, left_proof = normalization(s)
    right, right_proof = normalization(t)
    if left != right:
        raise ValueError("The two terms did not normalize to the same syntax")
    reverse = symmetry(t, right, right_proof)
    proof = transitivity(s, left, t, left_proof, reverse)
    if not SOURCE.check(eq(s, t), proof):
        raise AssertionError("Produced computation proof failed source checking")
    return proof


def main():
    examples = [
        {
            "name": "zero_plus",
            "step_source": "direct_zero_plus_n_subderivation.json",
            "body": eq(recursor(1, 0, successor(1)), 1),
            "description": "R(n,0;u,v.Su)=n, by equation induction.",
        },
        {
            "name": "zero_truncated_difference",
            "step_source": "zero_diff_subderivation.json",
            "body": eq(recursor(1, 0, recursor(1, 0, 2)), 0),
            "description": "Iterated predecessor started at zero remains zero.",
        },
        {
            "name": "successor_plus",
            "step_source": "successor_plus_subderivation.json",
            "body": eq(recursor(1, successor(3), successor(1)),
                       successor(recursor(1, 3, successor(1)))),
            "description": "R(n,Sa;u,v.Su)=S(R(n,a;u,v.Su)), with parameter a.",
        },
        {
            "name": "truncated_difference_cancel",
            "step_source": "diff_cancel_subderivation.json",
            "body": eq(recursor(successor(1), successor(3), recursor(1, 0, 2)),
                       recursor(1, 3, recursor(1, 0, 2))),
            "description": "Truncated difference cancels simultaneous successors.",
        },
    ]
    report = {
        "description": "Native U induction theorems using exact inherited equality step proofs.",
        "trusted_proof_producer": False,
        "source_strict_checker_sha256": sha(ROOT / "reference/goal_only_checker.py"),
        "target_strict_checker_sha256": sha(ROOT / "checker.py"),
        "target_demand_checker_sha256": sha(ROOT / "checker_demand.py"),
        "examples": [],
    }
    for entry in examples:
        source_path = ROOT / "extracted_sources" / entry["step_source"]
        inherited = json.loads(source_path.read_text())
        body, step = entry["body"], inherited[1]
        successor_goal = SOURCE.subst(body, [["s", 1], 0])
        if inherited[0] != successor_goal:
            raise AssertionError("Chosen inherited step has the wrong successor goal")
        # This explicit check removes all inherited extra contexts.  The sole
        # remaining assumption is the equation induction hypothesis B(y).
        if not SOURCE.check(successor_goal, step, body):
            raise AssertionError("Inherited step needs more than the induction hypothesis")

        retained_zero = SOURCE.subst(body, [0, 0])
        conditional = ["pi", retained_zero, body]
        source_conditional = [conditional, [step]]
        target_conditional = compile_sequent(source_conditional)
        base = SOURCE.subst(body, [0, -1])
        base_proof = computation_equality(base[1], base[2])
        result = SOURCE.subst(body, [1, -1])
        source_result = [result, [conditional, [step], 1, base_proof]]
        target_result = compile_sequent(source_result)
        source_names = []
        target_names = []
        for suffix, source, target in (
            ("conditional", source_conditional, target_conditional),
            ("theorem", source_result, target_result),
        ):
            source_name = "generated_sources/" + entry["name"] + "_" + suffix + ".json"
            target_name = "arithmetic_examples/" + entry["name"] + "_" + suffix + ".json"
            save_json(ROOT / source_name, source)
            save_json(ROOT / target_name, target)
            source_names.append(source_name)
            target_names.append(target_name)
        report["examples"].append({
            "name": entry["name"],
            "mathematical_description": entry["description"],
            "inherited_step_source": "extracted_sources/" + entry["step_source"],
            "inherited_step_source_sha256": sha(source_path),
            "step_uses_only_induction_hypothesis": True,
            "inherited_step_preserved_exactly": True,
            "source_sequents": source_names,
            "target_sequents": target_names,
            "source_accepted": True,
            "strict_target_accepted": True,
            "demand_target_accepted": True,
        })
    report["summary"] = {
        "induction_families": len(report["examples"]),
        "source_and_target_sequents_checked": 2 * len(report["examples"]),
        "source_and_both_target_policies_passed": True,
    }
    save_json(ROOT / "arithmetic_results.json", report)
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
