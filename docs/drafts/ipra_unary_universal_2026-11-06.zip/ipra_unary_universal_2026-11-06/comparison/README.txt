Frozen current-corpus comparator sources
=======================================

All 13 advertised top-level acceptance programs from all six ZIPs in the
current docs/drafts directory at commit fa581763b2bb75e8ba055da8e56280c9fd5dd890.
No source is modified. manifest.json records both archive and member identity,
source SHA-256, witness policy, public interface and independently recomputed
measurements. The minimum 582 AST / 569 tokens quoted in these papers belongs
to their earlier comparison corpus, not this current corpus.

python3 measure.py
python3 measure.py ../checker.py ../checker_strict.py

The optional paths are candidate complete programs; the script compares each
against every coordinate of the current all-program minimum. Source bytes are
not a representation-independent theorem of minimality.
