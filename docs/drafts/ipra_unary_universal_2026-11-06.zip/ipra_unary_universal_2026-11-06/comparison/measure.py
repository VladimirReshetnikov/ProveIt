"""Hash-verified, full-program comparison against the current six-draft corpus."""
from pathlib import Path
import ast
import io
import json
import tokenize
import hashlib
import sys

ROOT = Path(__file__).resolve().parent
FIELDS = ['ast_nodes', 'source_tokens', 'normalized_tokens', 'normalized_bytes', 'raw_bytes']
IGNORED = {tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE, tokenize.INDENT,
           tokenize.DEDENT, tokenize.ENDMARKER, tokenize.ENCODING}


def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf8')
    tree = ast.parse(source)
    omitted = []
    for node in ast.walk(tree):
        if (isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))
                and ast.get_docstring(node, clean=False) is not None):
            doc = node.body.pop(0)
            omitted.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    normalized = ast.unparse(tree) + '\n'

    def token_count(text, spans=()):
        return sum(t.type not in IGNORED and not any(a <= t.start and t.end <= b for a, b in spans)
                   for t in tokenize.generate_tokens(io.StringIO(text).readline))

    return {'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'source_tokens': token_count(source, omitted),
            'normalized_tokens': token_count(normalized),
            'normalized_bytes': len(normalized.encode()), 'raw_bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def envelope(rows):
    return {field: min(r[field] for r in rows) for field in FIELDS}


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    rows = []
    for entry in manifest['baselines']:
        current = measure(ROOT / entry['source'])
        if current['sha256'] != entry['sha256']:
            raise ValueError('Frozen source changed: ' + entry['source'])
        rows.append({**entry, **current})
    lower = envelope(rows)
    categories = {}
    for interface in ('theorem', 'open_sequent'):
        for policy in ('strict', 'demand'):
            selected = [r for r in rows if r['interface'] == interface and r['witness_policy'] == policy]
            if selected:
                categories[interface + '/' + policy] = envelope(selected)
    candidates = []
    for name in sys.argv[1:]:
        path = Path(name)
        row = {'source': name, **measure(path)}
        row['strictly_below_each_current_coordinate'] = {f: row[f] < lower[f] for f in FIELDS}
        candidates.append(row)
    result = {'python': sys.version, 'repository': manifest['repository'], 'commit': manifest['commit'],
              'measurement_boundary': manifest['boundary'], 'baselines': rows, 'envelope': lower,
              'profile_envelopes': categories, 'candidates': candidates}
    (ROOT / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'verified_baselines': len(rows), 'envelope': lower, 'candidates': candidates}, indent=2))
    return result


if __name__ == '__main__':
    main()
