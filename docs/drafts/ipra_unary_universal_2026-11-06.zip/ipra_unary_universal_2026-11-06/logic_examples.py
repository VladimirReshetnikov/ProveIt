"""Checked examples for the actual unary-U encodings of intuitionistic logic.

This untrusted producer imports the formula encodings from connectives.py.
It uses only independently checked recursor equations and equality transport
to bridge the encoded atomic endpoints.  The checker never imports this file.
"""

import json

import connectives as C
from arithmetic_examples import computation_equality, reflexivity
from translator import ROOT, STRICT, DEMAND, compile_sequent, save_json, sha


def equation(s, t):
    return ["=", s, t]


def lift(a):
    return C.lift(a)


def computed_equality(s, t):
    """Produce a native proof of a concrete definitional equality."""
    old_proof = computation_equality(s, t)
    return compile_sequent([equation(s, t), old_proof])[1]


def native_reflexivity(t):
    return compile_sequent([equation(t, t), reflexivity(t)])[1]


def symmetry(s, t, p):
    return [equation(s, t), p, equation(1, lift(s)), native_reflexivity(s)]


def atom_transport(source, target, certificate):
    """Transport an equation across checked equalities of its two terms."""
    if source[0] != "=" or target[0] != "=":
        raise ValueError("The endpoint transport helper is only for equations")
    _, s, t = source
    _, new_s, new_t = target
    right = [equation(t, new_t), computed_equality(t, new_t),
             equation(lift(s), 1), certificate]
    return [equation(s, new_s), computed_equality(s, new_s),
            equation(1, lift(new_t)), right]


def main():
    a = equation(1, 0)
    b = equation(2, ["s", 0])
    cases = []

    # The equation A is an arbitrary assumption-shaped formula, not a theorem.
    # UI's retained base is M_0(A,A); its successor goal computes to the same A.
    reflexive = C.implication(a, a)
    body = reflexive[1]
    base = STRICT.subst(body, [0, 0])
    step = STRICT.subst(body, [["s", 1], 0])
    reflexive_proof = [atom_transport(base, step, None)]
    cases.append(("encoded_implication_reflexivity", [reflexive, reflexive_proof],
                  "Theorem: the actual encoding of A implies A, for A=(x=0)."))

    # U elimination at the numeral one is the modus ponens step after
    # converting the retained zero endpoint from A and the successor endpoint
    # into B.  The ambient context is exactly (encoded A implies B, A).
    arrow = C.implication(a, b)
    zero = STRICT.subst(arrow[1], [0, -1])
    one = STRICT.subst(arrow[1], [["s", 0], -1])
    zero_proof = atom_transport(a, zero, None)
    one_proof = [arrow, None, ["s", 0], zero_proof]
    modus_ponens = atom_transport(one, b, one_proof)
    cases.append(("encoded_modus_ponens", [b, modus_ponens, arrow, a],
                  "Open sequent: encoded (A implies B), A prove B."))

    # Under the fresh UI number n, choose its successor as the existential
    # witness. EI provides y=Sn. The truthifying recursors at S n and p(S n)
    # compute, transporting that local equation to the encoded matrix.
    ordinary = ["forall", ["exists", ["=", 1, ["s", 2]]]]
    forall_exists = C.encode(ordinary)
    successor_existential = STRICT.subst(forall_exists[1], [["s", 1], 0])
    matrix = successor_existential[1]
    witness_equation = equation(1, ["s", 2])
    existential_proof = [["s", 1], atom_transport(witness_equation, matrix, None)]
    cases.append(("encoded_forall_exists_successor", [forall_exists, [existential_proof]],
                  "Theorem: the actual encoding of forall x exists y, y=Sx."))

    # Choose selector zero. EI's local equation z=0 is reversed and used to
    # transport M_0(A,B) to M_z(A,B); the former computes to the lifted A.
    disjunction = C.disjunction(a, b)
    matrix = disjunction[1]
    at_zero = STRICT.subst(matrix, [0, 0])
    at_zero_proof = atom_transport(lift(a), at_zero, None)
    motive = STRICT.subst(matrix, [1, 1])
    at_selector = [equation(0, 1), symmetry(1, 0, None), motive, at_zero_proof]
    cases.append(("encoded_disjunction_left", [disjunction, [0, at_selector], a],
                  "Open sequent: A proves the actual encoding of A or B."))

    report = {
        "description": "Native certificates for executable intuitionistic-logic encodings.",
        "formula_encoder_sha256": sha(ROOT / "connectives.py"),
        "strict_checker_sha256": sha(ROOT / "checker.py"),
        "demand_checker_sha256": sha(ROOT / "checker_demand.py"),
        "trusted_proof_producer": False,
        "cases": [],
    }
    for name, sequent, description in cases:
        if not STRICT.check(*sequent):
            raise AssertionError("Strict checker rejected " + name)
        if not DEMAND.check(*sequent):
            raise AssertionError("Demand checker rejected " + name)
        file = "logic_examples/" + name + ".json"
        save_json(ROOT / file, sequent)
        report["cases"].append({
            "name": name,
            "description": description,
            "file": file,
            "sha256": sha(ROOT / file),
            "assumptions": len(sequent) - 2,
            "strict_accepted": True,
            "demand_accepted": True,
        })
    report["summary"] = {"checked_cases": len(cases), "both_policies_passed": True}
    save_json(ROOT / "logic_results.json", report)
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
