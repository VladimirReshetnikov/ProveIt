"""Untrusted executable definitions of the report's logical encodings.

This module is never imported by either acceptance program. It constructs
formula syntax, not proofs. Terms use the native syntax from FORMAT.txt.
The ordinary formula input additionally accepts and/or/imp/forall/exists
and the nullary list ['false']. Bound number variables use positive de
Bruijn indices; integer zero is the number constant.
"""
import json
import sys


def map_variables(a, function, depth=0):
    if type(a) is int:
        if a < 0:
            raise ValueError('negative numerical leaf')
        return a if a <= depth else function(a - depth, depth)
    tag, *parts = a
    widths = {'s': (0,), 'r': (0, 0, 2), '=': (0, 0),
              'u': (1,), 'ex': (1,)}[tag]
    return [tag, *(map_variables(p, function, depth + width)
                   for p, width in zip(parts, widths, strict=True))]


def lift(a, count=1):
    return map_variables(a, lambda i, depth: i + depth + count)


def instance(body, term, drop=True):
    return map_variables(body, lambda i, depth:
                         lift(term, depth) if i == 1
                         else i + depth - int(drop))


def successor(t):
    return ['s', t]


def predecessor(t):
    return ['r', t, 0, 2]


def choose(n, a, b):
    return ['r', n, a, lift(b, 2)]


def truthify(formula, selector):
    """Q_selector(formula); selector is outside formula's existing binders."""
    tag, *parts = formula
    if tag == '=':
        s, t = parts
        return ['=', choose(selector, 0, s), choose(selector, 0, t)]
    if tag not in ('u', 'ex') or len(parts) != 1:
        raise ValueError('not a native formula')
    return [tag, truthify(parts[0], lift(selector))]


def select(a, b, selector):
    """M_selector(a,b), with U taking priority over E as in the report."""
    if a[0] == 'u' or b[0] == 'u':
        left = a[1] if a[0] == 'u' else truthify(lift(a), 1)
        right = b[1] if b[0] == 'u' else truthify(lift(b), 1)
        return ['u', select(left, right, lift(selector))]
    if a[0] == 'ex' or b[0] == 'ex':
        left = a[1] if a[0] == 'ex' else lift(a)
        right = b[1] if b[0] == 'ex' else lift(b)
        return ['ex', select(left, right, lift(selector))]
    if a[0] != '=' or b[0] != '=':
        raise ValueError('not a native formula')
    return ['=', choose(selector, a[1], b[1]),
            choose(selector, a[2], b[2])]


def universal(body):
    """The free slot 1 of body is the variable to quantify."""
    return ['u', truthify(instance(body, predecessor(1), drop=False), 1)]


def implication(a, b):
    return ['u', select(lift(a), lift(b), 1)]


def conjunction(a, b):
    return universal(select(lift(a), lift(b), 1))


def disjunction(a, b):
    return ['ex', select(lift(a), lift(b), 1)]


def encode(a):
    tag, *parts = a
    if tag == '=':
        if len(parts) != 2:
            raise ValueError('equality arity')
        return a
    if tag == 'false' and not parts:
        return ['=', 0, successor(0)]
    if tag in ('and', 'or', 'imp'):
        left, right = map(encode, parts)
        return {'and': conjunction, 'or': disjunction,
                'imp': implication}[tag](left, right)
    body, = parts
    if tag == 'forall':
        return universal(encode(body))
    if tag in ('exists', 'ex'):
        return ['ex', encode(body)]
    if tag == 'u':
        return ['u', encode(body)]
    raise ValueError('unknown formula constructor')


if __name__ == '__main__':
    _, path = sys.argv
    with open(path, 'rb') as stream:
        result = encode(json.load(stream))
    print(json.dumps(result, separators=(',', ':')))
