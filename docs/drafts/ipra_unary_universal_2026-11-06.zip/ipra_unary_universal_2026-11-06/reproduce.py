"""Reproduce every reported source comparison and implementation audit offline."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def main():
    commands = [
        ['comparison/measure.py', 'checker.py', 'checker_demand.py'],
        ['measure_core.py'],
        ['translator.py'],
        ['arithmetic_examples.py'],
        ['logic_examples.py'],
        ['validation/run_audit.py', 'checker.py', 'checker_demand.py'],
        ['validation/connective_audit.py', 'connectives.py'],
        ['validation/check_examples.py', '--strict', 'checker.py', '--demand',
         'checker_demand.py', 'arithmetic_examples', 'translated_examples', 'logic_examples'],
    ]
    outcomes = []
    for args in commands:
        start = time.monotonic()
        result = subprocess.run([sys.executable, *args], cwd=ROOT, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        row = {'command': ['python3', *args], 'returncode': result.returncode,
               'elapsed_seconds': round(time.monotonic() - start, 3),
               'output': result.stdout}
        outcomes.append(row)
        print(args[0] + ': ' + ('PASS' if result.returncode == 0 else 'FAIL'), flush=True)
        if result.returncode:
            print(result.stdout)
            break
    record = {'python': platform.python_version(),
              'kernel_sha256': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                                for name in ['checker.py', 'checker_demand.py']},
              'commands': outcomes,
              'all_passed': len(outcomes) == len(commands)
                            and all(row['returncode'] == 0 for row in outcomes)}
    (ROOT / 'results/reproduction.json').write_text(json.dumps(record, indent=2) + '\n')
    if not record['all_passed']:
        raise SystemExit(1)
    print('All comparison, generation, oracle and CLI checks passed.')


if __name__ == '__main__':
    main()
