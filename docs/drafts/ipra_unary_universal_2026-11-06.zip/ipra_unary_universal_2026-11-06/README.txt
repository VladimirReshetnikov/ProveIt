A UNARY AXIOMATIZATION OF INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov -- 6 November 2026 (Pacific time)

RESULT

The supplied theory replaces the guarded binary binder Pi_x[H;B] in the
current drafts by a unary binder U_x B, read B(0) -> forall x B(x).
Its introduction always retains the base B(0), and supplies B(y) as an
induction hypothesis only for literal equation matrices. This removes
the guard argument and its syntactic collision test. Substitution is
admissible directly, and a truthification/padding construction recovers
all ordinary intuitionistic logical operations.

Every native formula is a word of two kinds of unary binders (U and E)
ending in one equation. The arithmetic uses zero, successor and a binder
for each fixed initialized recursion. The report states every primitive
axiom/schema/rule and proves full first-order bi-interpretability with
iPRA. Both ordinary interpretations use the whole number domain and
equality defines their internal composite isomorphisms.

CURRENT, RECOMPUTED COMPARISON

Source: https://github.com/VladimirReshetnikov/ProveIt
Commit: fa581763b2bb75e8ba055da8e56280c9fd5dd890
Scope:  all 13 top-level complete checkers in the six current draft ZIPs

                                  AST   Source   Normalized   Normalized
                                nodes   tokens       tokens        bytes
Current all-program minimum        562      541          543         1688
New checker_demand.py               556      532          540         1663

Current strict open minimum        570      547          551         1743
New checker.py (strict)             568      542          550         1708

Every coordinate in the first new row is below the all-program envelope.
The complete source is counted, including input/output and rejection.
The minimum quoted inside the old reports (582 AST) is now obsolete.
This is a reproducible finite-corpus reduction, not absolute minimality.

Boundary caveat: removing imports and command-line code from every
program gives a different envelope. The new inference core alone does
not beat that envelope. The report and measure_core.py disclose those
numbers; the quantitative improvement is for complete acceptance programs.
The logical guard elimination is a separate mathematical simplification.

WITNESS POLICY

The smallest program is checker_demand.py. It validates all public
formulas, hypotheses, existential witnesses and equality motives. A unary
witness unused in its matrix is ignored and may always be replaced by zero.
checker.py also validates that unused numerical annotation. Both prove
exactly the same well-formed sequents. FORMAT.txt gives the exact contract.

START HERE

  report.pdf                  Full research article
  report.tex, sections/       Complete LaTeX source
  checker_demand.py           Smallest complete standalone checker
  checker.py                  Strict standalone companion
  FORMAT.txt                  Syntax, certificates, priority and CLI contract
  logic_examples/             Four actual logical-encoding proof certificates
  arithmetic_examples/        Eight conditional/unconditional induction proofs
  translated_examples/        Nineteen checked inherited subderivations
  connectives.py              Untrusted executable logical syntax definitions
  comparison/                 All 13 frozen current checker sources and hashes
  validation/                 Independent syntax, binding, rule and CLI audits
  source_examples/, reference/ Frozen source proofs/checker for reproduction
  translator.py               Explicitly partial numerical-Pi proof compiler
  arithmetic_examples.py      Producer of the eight arithmetic certificates
  logic_examples.py           Producer of the four logical certificates
  results/                    Recorded verification and build evidence
  reproduce.py                Rerun the offline checks
  build.py                    Rebuild report.pdf with pdfLaTeX
  package.py                  Refresh checksums and ZIP
  MANIFEST.sha256             Hashes of every other delivered file

RUN

Python 3.10+ and only its standard library are needed. Exact source
normalization counts use CPython 3.12.14.

  python3 checker_demand.py logic_examples/encoded_forall_exists_successor.json
  python3 checker.py arithmetic_examples/zero_plus_theorem.json
  python3 reproduce.py
  python3 build.py

Input is [goal, proof, *hypotheses]. ACCEPT and exit zero mean acceptance.
Free numerical variables are arbitrary parameters. Open contexts certify
sequents; they are not assertions of unconditional theoremhood.

EVIDENCE AND LIMITS

The package contains independent named-variable substitution and rule
oracles, 261 labeled adversarial fixtures, 1200 substitution samples with
five anchors, full normal/-O command-line tests, actual arithmetic and
logical proof certificates, and separate formula-encoder endpoint checks.
Run reproduce.py for the exact counts and zero-failure reports.

The partial compiler translates only guarded formulas whose guard is
literally their matrix's zero instance. All 19 entire old examples contain
some other guarded binder and are recorded outside its scope. The 19
translated examples are checked extracted subderivations, with precise
provenance and source contexts. The general logical translation is proved
mathematically in the article; no completed general proof compiler is claimed.

The universal mathematical proofs are not formalized in Lean or Rocq.
Finite tests are evidence about the concrete implementation, not an
internal consistency proof or a substitute for the bi-interpretation proof.
Real Python resource limits can reject exceptionally large valid proofs.

The prior draft series supplies the initialized-recursion arithmetic and
the fixed-recursion interpretation method; it is explicitly credited.
The unary connective, retained-base rule, truthification/padding argument,
and its implementation form this iteration's principal contribution.
