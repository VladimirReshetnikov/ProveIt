"""Rebuild the supplied report with an installed pdfLaTeX distribution."""
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    executable = shutil.which('pdflatex')
    if executable is None:
        raise SystemExit('Install pdfLaTeX to rebuild the PDF; the compiled PDF is supplied.')
    destination = ROOT / '.build'
    destination.mkdir(exist_ok=True)
    for iteration in range(3):
        command = [executable, '-interaction=nonstopmode', '-halt-on-error',
                   '-file-line-error', '-output-directory=.build', 'report.tex']
        result = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
        (destination / f'pass_{iteration + 1}.txt').write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-9000:])
            raise SystemExit(result.returncode)
    log = (destination / 'report.log').read_text(errors='replace')
    forbidden = ['There were undefined references', 'There were undefined citations',
                 'Rerun to get cross-references right']
    if any(fragment in log for fragment in forbidden):
        raise SystemExit('Unresolved references after three compilation passes')
    warnings = re.findall(r'(?:Overfull|Underfull)[^\n]*', log)
    shutil.copy2(destination / 'report.pdf', ROOT / 'report.pdf')
    record = {'engine': executable, 'passes': 3, 'unresolved_references': False,
              'layout_warnings': warnings, 'pdf_bytes': (ROOT / 'report.pdf').stat().st_size}
    (ROOT / 'results/build.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
