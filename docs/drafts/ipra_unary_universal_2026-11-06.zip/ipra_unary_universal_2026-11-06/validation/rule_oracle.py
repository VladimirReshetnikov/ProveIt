"""Independent rule interpreter for unary-U certificate syntax.

This file imports only an explicit grammar and named-binder substitution.
The two oracle programs never import either target checker. Certificate
priority and fallback are part of the published proof format.
"""
from collections import Counter
from named_oracle import valid, substitute


def require(ok):
    if not ok:
        raise ValueError('independent rule condition failed')


def infer(goal, proof, context=(), strict=True, counts=None):
    require(valid(goal))
    require(all(valid(a) for a in context))
    counts = Counter() if counts is None else counts
    array = type(proof) is list
    if goal[0] == 'u' and array and len(proof) == 1:
        body = goal[1]
        local = [substitute(body, [0, 0])]
        if body[0] == '=':
            local.append(body)
            counts['equation_induction_with_retained_base'] += 1
        else:
            counts['compound_cases_without_induction_hypothesis'] += 1
        next_goal = substitute(body, [['s', 1], 0])
        return infer(next_goal, proof[0], [*[substitute(a) for a in context], *local], strict, counts)
    if goal[0] == 'ex' and array and len(proof) == 2:
        witness, child = proof
        require(valid(witness, False))
        local = ['=', 1, substitute(witness, formula=False)]
        counts['existential_introduction'] += 1
        return infer(goal[1], child, [*[substitute(a) for a in context], local], strict, counts)
    if array and len(proof) >= 2 and type(proof[0]) is list and proof[0]:
        major, child, *args = proof
        if infer(major, child, context, strict, counts):
            if major[0] == 'ex':
                require(len(args) == 1)
                counts['existential_elimination'] += 1
                return infer(substitute(goal), args[0],
                             [*[substitute(a) for a in context], major[1]], strict, counts)
            require(len(args) == 2)
            annotation, child = args
            if major[0] == 'u':
                if strict:
                    require(valid(annotation, False))
                premise = substitute(major[1], [0, -1])
                conclusion = substitute(major[1], [annotation, -1])
                counts['conditional_universal_elimination'] += 1
            else:
                require(major[0] == '=')
                require(valid(annotation))
                premise = substitute(annotation, [major[1], -1])
                conclusion = substitute(annotation, [major[2], -1])
                counts['equality_transport'] += 1
            return conclusion == goal and infer(premise, child, context, strict, counts)
        counts['failed_major_hypothesis_fallback'] += 1
    if proof == 'r' and goal[0] == '=' and type(goal[1]) is list and goal[1][0] == 'r':
        counter, initializer, update = goal[1][1:]
        if counter == 0:
            rhs = initializer
            counts['recursion_zero'] += 1
        else:
            require(type(counter) is list and len(counter) == 2 and counter[0] == 's')
            predecessor = counter[1]
            rhs = substitute(update, [['r', predecessor, initializer, update], predecessor, -2], formula=False)
            counts['recursion_successor'] += 1
        return rhs == goal[2]
    counts['hypothesis_membership'] += 1
    return goal in context


def accepted(record, strict=True, counts=None):
    try:
        require(type(record) is list and len(record) >= 2)
        return bool(infer(record[0], record[1], record[2:], strict, counts))
    except Exception:
        return False
