"""Independently recheck external unary certificates using named binders.

Usage: python3 check_examples.py --strict CHECKER --demand CHECKER DIR [DIR ...]
The rule oracle does not import the producer, checker, or target substitution.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import sys
import subprocess
import argparse
from rule_oracle import accepted


def main(directories, strict_path=None, demand_path=None):
    results = []
    counts = Counter()
    cli_runs = 0
    cli_failures = []
    if bool(strict_path) != bool(demand_path):
        raise ValueError("Supply both checker paths or neither.")
    for directory in directories:
        for path in sorted(Path(directory).glob('*.json')):
            record = json.loads(path.read_text())
            strict = accepted(record, strict=True, counts=counts)
            demand = accepted(record, strict=False)
            if strict_path:
                for policy, target in [('strict', strict_path), ('demand', demand_path)]:
                    for optimization in ([], ['-O']):
                        proc = subprocess.run([sys.executable, *optimization, str(Path(target).resolve()), str(path.resolve())],
                                              capture_output=True, text=True, timeout=30)
                        cli_runs += 1
                        if proc.returncode != 0 or proc.stdout.strip() != 'ACCEPT':
                            cli_failures.append({'file': path.name, 'policy': policy, 'optimization': optimization,
                                                 'returncode': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr})
            results.append({'directory': Path(directory).name, 'file': path.name,
                            'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                            'strict_oracle': strict, 'demand_oracle': demand})
    failures = [r for r in results if not (r['strict_oracle'] and r['demand_oracle'])] + cli_failures
    result = {'files': len(results), 'oracle_checks': 2 * len(results), 'CLI_runs': cli_runs,
              'rule_counts_strict': dict(counts), 'results': results, 'failures': failures,
              'note': 'Inherited subderivations remain distinct from whole-source proof translation.'}
    (Path(__file__).resolve().parent / 'examples_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'files': len(results), 'oracle_checks': 2 * len(results), 'CLI_runs': cli_runs, 'failures': failures}, indent=2))
    if failures:
        raise SystemExit(1)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--strict')
    parser.add_argument('--demand')
    parser.add_argument('directories', nargs='+')
    args = parser.parse_args()
    main(args.directories, args.strict, args.demand)
