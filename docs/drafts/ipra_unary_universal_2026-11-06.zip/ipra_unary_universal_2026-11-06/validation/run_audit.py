"""Run independent syntax, rules, substitution, CLI, and optimization audits.

Usage: python3 run_audit.py STRICT_CHECKER DEMAND_CHECKER
Everything here is untrusted validation support, never loaded by a checker.
"""
from pathlib import Path
from collections import Counter
import hashlib
import importlib.util
import json
import random
import subprocess
import sys
import tempfile

from named_oracle import substitute, term, formula
from rule_oracle import accepted, infer
from fixtures import build

ROOT = Path(__file__).resolve().parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def api_accepted(module, record):
    try:
        return bool(module.check(*record))
    except Exception:
        return False


def outcome(operation):
    try:
        return ('value', operation())
    except Exception:
        return ('error',)


def run(strict_path, demand_path):
    variants = {'strict': load(strict_path, 'audited_strict'),
                'demand': load(demand_path, 'audited_demand')}
    paths = {'strict': strict_path.resolve(), 'demand': demand_path.resolve()}
    rows = build()
    counts = {policy: Counter() for policy in variants}
    failures = []
    api_runs = 0
    for fixture in rows:
        for policy, module in variants.items():
            expected = fixture[policy]
            oracle = accepted(fixture['record'], policy == 'strict', counts[policy])
            actual = api_accepted(module, fixture['record'])
            api_runs += 1
            if not (expected == oracle == actual):
                failures.append({'group': 'fixture', 'case': fixture['name'], 'policy': policy,
                                 'expected': expected, 'oracle': oracle, 'actual': actual})

    # These demonstrate that the crucial fixtures isolate the intended rule.
    eq_case = next(r for r in rows if r['name'] == 'U_equation_reads_base_and_induction_hypothesis')
    body = eq_case['record'][0][1]
    child = eq_case['record'][1][0]
    base = substitute(body, [0, 0])
    step = substitute(body, [['s', 1], 0])
    sensitivity = {
        'equation_with_both_assumptions': infer(step, child, [base, body]),
        'equation_with_base_omitted': infer(step, child, [body]),
        'equation_with_IH_omitted': infer(step, child, [base]),
    }
    co_case = next(r for r in rows if r['name'] == 'U_compound_cannot_use_induction_hypothesis')
    body = co_case['record'][0][1]
    child = co_case['record'][1][0]
    base = substitute(body, [0, 0])
    step = substitute(body, [['s', 1], 0])
    sensitivity.update({'compound_without_IH': infer(step, child, [base]),
                        'compound_if_illegal_IH_added': infer(step, child, [base, body])})
    wanted = {'equation_with_both_assumptions': True, 'equation_with_base_omitted': False,
              'equation_with_IH_omitted': False, 'compound_without_IH': False,
              'compound_if_illegal_IH_added': True}
    if sensitivity != wanted:
        failures.append({'group': 'rule_sensitivity', 'actual': sensitivity, 'expected': wanted})

    rng = random.Random(2026110607)
    samples = []
    for i in range(1200):
        sort = bool(i % 2)
        expression = formula(rng, 4) if sort else term(rng, 4)
        depth = rng.randrange(0, 5)
        a, b = term(rng, 2), term(rng, 2)
        env = rng.choice([[0], [1], [3], [a, 0], [a, -1], [a, b, -2]])
        samples.append((expression, env, depth, sort))
    anchors = [
        (['u', ['=', 1, 2]], [1], 0, True, ['u', ['=', 1, 3]]),
        (['ex', ['=', 2, 1]], [3, -1], 0, True, ['ex', ['=', 4, 1]]),
        (['r', 1, 2, ['s', 3]], [4, -1], 0, False, ['r', 4, 1, ['s', 6]]),
        (['r', 3, 1, ['r', 2, 1, 5]], [4, -1], 2, False,
         ['r', 6, 1, ['r', 2, 1, 5]]),
        (['u', ['ex', ['=', 1, 2]]], [{'unused': True}, -1], 0, True,
         ['u', ['ex', ['=', 1, 2]]]),
    ]
    substitution_runs = 0
    for i, (expression, env, depth, sort) in enumerate(samples):
        expected = outcome(lambda: substitute(expression, env, depth, sort))
        for policy, module in variants.items():
            actual = outcome(lambda: module.subst(expression, env, depth, sort))
            substitution_runs += 1
            if actual != expected:
                failures.append({'group': 'substitution', 'sample': i, 'policy': policy,
                                 'input': [expression, env, depth, sort], 'expected': expected, 'actual': actual})
    for i, (expression, env, depth, sort, expected) in enumerate(anchors):
        oracle = substitute(expression, env, depth, sort)
        for policy, module in variants.items():
            actual = module.subst(expression, env, depth, sort)
            substitution_runs += 1
            if actual != expected or oracle != expected:
                failures.append({'group': 'anchor', 'sample': i, 'policy': policy,
                                 'expected': expected, 'oracle': oracle, 'actual': actual})

    # Whole-program evidence catches parser, entry-point and -O differences.
    cli_runs = 0
    with tempfile.TemporaryDirectory(prefix='unary_ipra_audit_') as temporary:
        temporary = Path(temporary)
        for index, fixture in enumerate(rows):
            fixture_path = temporary / (str(index) + '.json')
            fixture_path.write_text(json.dumps(fixture['record']), encoding='utf8')
            for policy in variants:
                for optimization in ([], ['-O']):
                    proc = subprocess.run([sys.executable, *optimization, str(paths[policy]), str(fixture_path)],
                                          capture_output=True, text=True, timeout=15)
                    cli_runs += 1
                    expected = fixture[policy]
                    ok = (proc.returncode == 0 and proc.stdout.strip() == 'ACCEPT') if expected else (
                        proc.returncode != 0 and proc.stdout.strip() == 'REJECT')
                    if not ok:
                        failures.append({'group': 'CLI', 'case': fixture['name'], 'policy': policy,
                                         'optimization': optimization, 'expected': expected,
                                         'returncode': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr})
        malformed = [b'', b'[', b'null trailing', b'[["=",0,0],NaN]', b'\xff\xff']
        # NaN is permissible unused proof metadata under Python's JSON parser;
        # its goal has no assumption and no derivation, so this record rejects.
        for index, content in enumerate(malformed):
            path = temporary / ('malformed_' + str(index) + '.json')
            path.write_bytes(content)
            for policy in variants:
                for optimization in ([], ['-O']):
                    proc = subprocess.run([sys.executable, *optimization, str(paths[policy]), str(path)],
                                          capture_output=True, text=True, timeout=15)
                    cli_runs += 1
                    if proc.returncode == 0 or proc.stdout.strip() != 'REJECT':
                        failures.append({'group': 'malformed_CLI', 'case': index, 'policy': policy})
        valid_path = temporary / 'valid.json'
        valid_path.write_text(json.dumps(rows[0]['record']))
        for policy in variants:
            for arguments in ([], [str(valid_path), 'extra']):
                proc = subprocess.run([sys.executable, str(paths[policy]), *arguments], capture_output=True,
                                      text=True, timeout=15)
                cli_runs += 1
                if proc.returncode == 0 or proc.stdout.strip() != 'REJECT':
                    failures.append({'group': 'argument_count', 'policy': policy, 'arguments': arguments})

    result = {'python': sys.version, 'candidate_hashes': {k: hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()},
              'fixtures': len(rows), 'expected_accepts': {p: sum(r[p] for r in rows) for p in variants},
              'expected_rejections': {p: sum(not r[p] for r in rows) for p in variants},
              'API_runs': api_runs, 'named_substitution_samples': len(samples), 'named_substitution_anchors': len(anchors),
              'substitution_comparisons': substitution_runs, 'CLI_runs': cli_runs, 'rule_sensitivity': sensitivity,
              'oracle_rule_counts': {p: dict(c) for p,c in counts.items()}, 'failures': failures,
              'interpretation': 'Finite tests of implementation obligations; not a formal proof of universal soundness or bi-interpretability.'}
    (ROOT / 'audit_results.json').write_text(json.dumps(result, indent=2) + '\n')
    (ROOT / 'fixtures.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if failures:
        raise SystemExit(1)
    return result


if __name__ == '__main__':
    _, strict, demand = sys.argv
    run(Path(strict), Path(demand))
