Independent unary-U validation support
======================================

The checker never imports any file in this directory. named_oracle.py uses
fresh binder identities and named free variables, independently of the
checker's de Bruijn environment algorithm. rule_oracle.py states the unary
rules using that separate grammar and substitution. Provenance and the
inherited validation-method license are retained.

Commands (from the final package root; adapt the directory name if needed):

  python3 validation/run_audit.py checker.py checker_demand.py
  python3 validation/connective_audit.py connectives.py
  python3 validation/check_examples.py --strict checker.py --demand checker_demand.py EXAMPLE_DIR [EXAMPLE_DIR ...]

The first command writes audit_results.json and fixtures.json next to itself.
It checks 261 labeled fixtures against the independent oracle and both
programs, 1,200 substitution samples plus five fixed anchors, and all
fixtures through both real command lines normally and with Python -O.
Its rule-sensitivity checks require rejection when either retained base or
equation IH is removed, and verify that the compound-IH negative test would
accept if the forbidden hypothesis were supplied.

The second command compares the encoder's lift/instance operations against
named-binder substitution and evaluates Q/M selector endpoints in small
nonempty domains containing zero and one. These are finite algebraic tests,
not models of iPRA. It does not identify the S/p-shifted full universal
encoding with a bounded universal over the same truncated domain.

The third command checks supplied proof certificates independently, optionally
running them through both actual CLI programs normally and with -O when both
checker paths are supplied. Syntax-only logical_encodings.json is not a proof
certificate and must not be passed as a proof-example directory.

Recorded result files enumerate exactly which counts belong to which group.
Groups overlap; they are not counts of distinct theorems. All validation is
finite regression evidence, not a Lean/Rocq proof of the universal metatheory.
mathematical_audit.txt records the independent reasoning audit.
