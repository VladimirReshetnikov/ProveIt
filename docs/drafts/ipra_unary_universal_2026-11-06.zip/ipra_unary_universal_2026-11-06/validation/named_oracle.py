"""Independent named-variable substitution for the unary iPRA language.

The method is adapted from the structural-kernel draft's named_oracle.py:
resolve de Bruijn indices into globally distinct binder names; replace named
free variables; recover indices. The grammar, positive indexing, unary U,
and lazy validation of unused annotations are explicit here. No target
checker or target substitution function is imported. Provenance is recorded
in provenance.json. This is untrusted validation support.
"""
import itertools

fresh = itertools.count()


def valid(a, formula=True):
    if not formula and type(a) is int:
        return a >= 0
    if type(a) is not list or not a or type(a[0]) is not str:
        return False
    tag = a[0]
    if formula:
        if tag == '=':
            return len(a) == 3 and valid(a[1], False) and valid(a[2], False)
        if tag in ('u', 'ex'):
            return len(a) == 2 and valid(a[1], True)
    else:
        if tag == 's':
            return len(a) == 2 and valid(a[1], False)
        if tag == 'r':
            return len(a) == 4 and all(valid(x, False) for x in a[1:])
    return False


def named(a, stack=()):
    if type(a) is int:
        if a == 0:
            return ('zero',)
        i = a - 1
        return ('bound', stack[i]) if i < len(stack) else ('free', i - len(stack))
    tag = a[0]
    if tag == 's':
        return ('succ', named(a[1], stack))
    if tag == 'r':
        state, counter = next(fresh), next(fresh)
        return ('rec', named(a[1], stack), named(a[2], stack), state, counter,
                named(a[3], (state, counter, *stack)))
    if tag == '=':
        return ('equal', named(a[1], stack), named(a[2], stack))
    variable = next(fresh)
    return ('conditional' if tag == 'u' else 'exists', variable,
            named(a[1], (variable, *stack)))


def indices(a, stack=()):
    tag = a[0]
    if tag == 'zero':
        return 0
    if tag == 'bound':
        return 1 + stack.index(a[1])
    if tag == 'free':
        if a[1] < 0:
            raise ValueError('invalid deletion environment')
        return 1 + a[1] + len(stack)
    if tag == 'succ':
        return ['s', indices(a[1], stack)]
    if tag == 'rec':
        return ['r', indices(a[1], stack), indices(a[2], stack),
                indices(a[5], (a[3], a[4], *stack))]
    if tag == 'equal':
        return ['=', indices(a[1], stack), indices(a[2], stack)]
    return ['u' if tag == 'conditional' else 'ex', indices(a[2], (a[1], *stack))]


def replace_named(a, replacements, delta):
    tag = a[0]
    if tag == 'free':
        i = a[1]
        if i < len(replacements):
            term = replacements[i]
            if not valid(term, False):
                raise ValueError('invalid demanded replacement')
            return named(term)
        return ('free', i + delta)
    if tag in ('zero', 'bound'):
        return a
    if tag == 'succ':
        return (tag, replace_named(a[1], replacements, delta))
    if tag == 'rec':
        return (tag, replace_named(a[1], replacements, delta),
                replace_named(a[2], replacements, delta), a[3], a[4],
                replace_named(a[5], replacements, delta))
    if tag == 'equal':
        return (tag, replace_named(a[1], replacements, delta),
                replace_named(a[2], replacements, delta))
    return (tag, a[1], replace_named(a[2], replacements, delta))


def substitute(a, env=(1,), depth=0, formula=True):
    if not valid(a, formula) or type(depth) is not int or depth < 0:
        raise ValueError('invalid syntax')
    if not env or type(env[-1]) is not int:
        raise ValueError('invalid environment')
    stack = tuple(next(fresh) for _ in range(depth))
    return indices(replace_named(named(a, stack), list(env[:-1]), env[-1]), stack)


def term(rng, height=3):
    if height == 0 or rng.randrange(3) == 0:
        return rng.randrange(0, 9)
    if rng.randrange(2) == 0:
        return ['s', term(rng, height - 1)]
    return ['r', term(rng, height - 1), term(rng, height - 1), term(rng, height - 1)]


def formula(rng, height=3):
    if height == 0 or rng.randrange(3) == 0:
        return ['=', term(rng, 2), term(rng, 2)]
    return [rng.choice(['u', 'ex']), formula(rng, height - 1)]
