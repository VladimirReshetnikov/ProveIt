"""Independent binding and selector-endpoint checks for the untrusted encoder.

Usage: python3 connective_audit.py CONNECTIVES_PY

Finite-domain evaluation here is only an algebraic test of Q and M endpoints
and of implication/disjunction definitions. It is NOT a finite model of iPRA.
In particular, the predecessor-shift universal encoding is not compared with
a bounded universal over the same truncated domain; doing so would create a
spurious boundary failure.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import random
import sys
from named_oracle import substitute, formula, term, valid

ROOT = Path(__file__).resolve().parent


def number(t, env):
    if type(t) is int:
        return 0 if t == 0 else env[t - 1]
    if t[0] == 's':
        return number(t[1], env) + 1
    if t[0] != 'r':
        raise ValueError('non-term in finite evaluation')
    n = number(t[1], env)
    if n > 5000:
        raise ValueError('unexpectedly large test recursion')
    result = number(t[2], env)
    for old_counter in range(n):
        result = number(t[3], (result, old_counter, *env))
    return result


def truth(a, env, domain):
    if a[0] == '=':
        return number(a[1], env) == number(a[2], env)
    if a[0] == 'u':
        base = truth(a[1], (0, *env), domain)
        return (not base) or all(truth(a[1], (x, *env), domain) for x in domain)
    if a[0] == 'ex':
        return any(truth(a[1], (x, *env), domain) for x in domain)
    raise ValueError('non-formula in finite evaluation')


def logical_nodes(a):
    return 0 if a[0] == '=' else 1 + logical_nodes(a[1])


def small_term(rng, depth=2):
    if depth == 0 or rng.randrange(3) == 0:
        return rng.randrange(0, 5)
    if rng.randrange(2) == 0:
        return ['s', small_term(rng, depth - 1)]
    # Bounded counters and simple updates keep test execution predictable.
    return ['r', rng.choice([0, ['s', 0], 1, 2]), small_term(rng, depth - 1),
            rng.choice([0, 1, 2, 3, ['s', 1]])]


def small_formula(rng, depth=3):
    if depth == 0 or rng.randrange(3) == 0:
        return ['=', small_term(rng), small_term(rng)]
    return [rng.choice(['u', 'ex']), small_formula(rng, depth - 1)]


def main(path):
    path = Path(path)
    spec = importlib.util.spec_from_file_location('audited_connectives', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    rng = random.Random(2026110693)
    failures = []
    binding = 0
    for i in range(800):
        sort = bool(i % 2)
        a = formula(rng, 4) if sort else term(rng, 4)
        n = rng.randrange(0, 5)
        witness = term(rng, 2)
        tests = [('lift', mod.lift(a, n), substitute(a, [n], formula=sort)),
                 ('instance_drop', mod.instance(a, witness), substitute(a, [witness, -1], formula=sort)),
                 ('instance_keep', mod.instance(a, witness, drop=False), substitute(a, [witness, 0], formula=sort))]
        for kind, actual, expected in tests:
            binding += 1
            if actual != expected:
                failures.append({'group': 'binding', 'case': i, 'kind': kind, 'actual': actual, 'expected': expected})

    selected = [
        ['=', 1, 0], ['u', ['=', 1, 2]], ['ex', ['=', 1, 2]],
        ['u', ['ex', ['=', 1, ['s', 2]]]],
        ['ex', ['u', ['=', ['r', 2, 3, ['s', 1]], 1]]],
        ['u', ['ex', ['u', ['=', 2, 4]]]],
        ['ex', ['u', ['ex', ['=', 3, 1]]]],
    ]
    selected += [small_formula(rng) for _ in range(33)]
    domains = [(0, 1), (0, 1, 2), (0, 1, 2, 3)]
    environments = [tuple(0 for _ in range(12)), tuple(i % 3 for i in range(12)),
                    tuple((i + 1) % 4 for i in range(12)), tuple(2 for _ in range(12))]
    q_checks = 0
    selector_checks = 0
    padding_checks = 0
    connective_checks = 0
    formation_checks = 0
    measures = 0
    for i, a in enumerate(selected):
        q0 = mod.truthify(a, 0)
        qs = mod.truthify(a, ['s', 1])
        padding = ['u', mod.truthify(mod.lift(a), 1)]
        for expr in (q0, qs, padding):
            formation_checks += 1
            if not valid(expr):
                failures.append({'group': 'formation_Q', 'case': i})
        measures += 2
        if logical_nodes(q0) != logical_nodes(a) or logical_nodes(qs) != logical_nodes(a):
            failures.append({'group': 'Q_constructor_count', 'case': i})
        for domain in domains:
            for env in environments:
                actual = truth(a, env, domain)
                q_checks += 2
                if not truth(q0, env, domain) or truth(qs, env, domain) != actual:
                    failures.append({'group': 'Q_endpoint', 'case': i, 'domain': domain, 'env': env})
                padding_checks += 1
                if truth(padding, env, domain) != actual:
                    failures.append({'group': 'U_truth_padding', 'case': i, 'domain': domain, 'env': env})
    pairs = [(selected[i], selected[j]) for i in range(7) for j in range(7)]
    pairs += [(rng.choice(selected), rng.choice(selected)) for _ in range(51)]
    for i, (a, b) in enumerate(pairs):
        m0 = mod.select(a, b, 0)
        ms = mod.select(a, b, ['s', 1])
        imp = mod.implication(a, b)
        disj = mod.disjunction(a, b)
        # Conjunction uses the unbounded-universal encoding; test its formation
        # and binder implementation separately, not truncated-domain equality.
        conj = mod.conjunction(a, b)
        for expr in (m0, ms, imp, disj, conj):
            formation_checks += 1
            if not valid(expr):
                failures.append({'group': 'formation_M', 'case': i})
        for domain in domains:
            for env in environments:
                av, bv = truth(a, env, domain), truth(b, env, domain)
                selector_checks += 2
                if truth(m0, env, domain) != av or truth(ms, env, domain) != bv:
                    failures.append({'group': 'M_endpoint', 'case': i, 'domain': domain, 'env': env})
                connective_checks += 2
                if truth(imp, env, domain) != ((not av) or bv):
                    failures.append({'group': 'implication', 'case': i, 'domain': domain, 'env': env})
                if truth(disj, env, domain) != (av or bv):
                    failures.append({'group': 'disjunction', 'case': i, 'domain': domain, 'env': env})

    result = {'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'binding_comparisons': binding,
              'formula_samples': len(selected), 'selector_pairs': len(pairs), 'Q_endpoint_checks': q_checks,
              'virtual_U_padding_checks': padding_checks, 'M_endpoint_checks': selector_checks,
              'implication_and_disjunction_checks': connective_checks, 'formation_checks': formation_checks,
              'Q_logical_constructor_count_checks': measures, 'failures': failures,
              'scope': 'Independent finite algebraic endpoint tests, not models of iPRA or a formal proof of the translations.'}
    (ROOT / 'connective_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if failures:
        raise SystemExit(1)
    return result


if __name__ == '__main__':
    _, path = sys.argv
    main(path)
