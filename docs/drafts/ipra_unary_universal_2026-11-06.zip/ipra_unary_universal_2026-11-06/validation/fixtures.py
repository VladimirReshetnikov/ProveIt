"""Rule fixtures derived from the stated unary-U calculus, not the target code."""
from copy import deepcopy
from named_oracle import substitute


def eq(a, b): return ['=', a, b]
def succ(a): return ['s', a]
def rec(n, a, h): return ['r', n, a, h]
def u(a): return ['u', a]
def ex(a): return ['ex', a]
def lift(a, formula=True): return substitute(a, formula=formula)


def refl(t):
    r = rec(0, t, 0)
    return [eq(r, t), 'r', eq(1, lift(t, False)), 'r']


def successor_step(n, initializer=0, update=1):
    """Use R(n)=0 and one computation to derive R(Sn)=0."""
    major = eq(rec(n, initializer, update), 0)
    lhs = rec(succ(n), initializer, update)
    return [major, None, eq(lift(lhs, False), 1), 'r']


def build():
    result = []
    def add(name, record, strict, demand=None, purpose=''):
        result.append({'name': name, 'record': record, 'strict': strict,
                       'demand': strict if demand is None else demand, 'purpose': purpose})

    truth = eq(0, 0)
    false = eq(0, succ(0))
    add('closed_reflexivity', [truth, refl(0)], True)
    add('parameter_reflexivity', [eq(3, 3), refl(3)], True)
    add('hypothesis', [truth, None, truth], True)
    add('absent_hypothesis', [truth, None], False)
    add('false_without_hypothesis', [false, None], False)
    add('false_from_hypothesis', [false, None, false], True)
    add('ignored_hypothesis_metadata', [truth, {'ignored': [True, None]}, truth], True)
    add('duplicate_context', [truth, None, truth, truth], True)

    for i, term in enumerate([0, 1, 7, succ(0), succ(2), rec(2, 1, succ(1))]):
        add('R0_' + str(i), [eq(rec(0, term, succ(1)), term), 'r'], True)
        add('R0_wrong_rhs_' + str(i), [eq(rec(0, term, succ(1)), succ(term)), 'r'], False)
    for i, update in enumerate([0, 1, 2, 3, succ(1), succ(2), succ(3), rec(2, 1, succ(3))]):
        n, initializer = 2, succ(1)
        lhs = rec(succ(n), initializer, update)
        rhs = substitute(update, [rec(n, initializer, update), n, -2], formula=False)
        add('RS_' + str(i), [eq(lhs, rhs), 'r'], True)
        add('RS_wrong_rhs_' + str(i), [eq(lhs, succ(rhs)), 'r'], False)
    add('recursion_on_free_counter', [eq(rec(1, 0, 0), 0), 'r'], False)
    add('recursion_on_nested_recursor_counter', [eq(rec(rec(0, 0, 0), 0, 0), 0), 'r'], False)
    add('recursion_reversed_equation', [eq(0, rec(0, 0, 0)), 'r'], False)
    add('recursion_needs_leaf_marker', [eq(rec(0, 0, 0), 0), None], False)

    # The base and IH are syntactically different. This certificate reads both.
    body = eq(rec(1, 0, 1), 0)
    base = substitute(body, [0, 0])
    lhs = rec(succ(1), 0, 1)
    r0 = rec(0, 0, 1)
    # Computation gives r0=0; transport reflexivity gives 0=r0.
    zero_to_r0 = [eq(r0, 0), 'r', eq(1, lift(r0, False)), refl(r0)]
    # IH + RS gives lhs=0; transport along 0=r0 gives lhs=r0.
    lhs_to_r0 = [eq(0, r0), zero_to_r0, eq(lift(lhs, False), 1), successor_step(1)]
    # The retained base r0=0 is a genuinely selected final major.
    step = [base, None, eq(lift(lhs, False), 1), lhs_to_r0]
    induction_both = [u(body), [step]]
    add('U_equation_reads_base_and_induction_hypothesis', induction_both, True,
        purpose='Rejects if either the retained base or the equation IH is omitted.')
    add('U_equation_induction_uses_IH', [u(body), [successor_step(1)]], True)
    add('U_equation_base_without_step', [u(body), [None]], False)
    add('U_vacuous_equation_base', [u(truth), [None]], True)
    add('U_unsound_false_induction_candidate', [u(eq(1, 0)), [None]], False)

    # B(x) is compound, so the U premise contains B(0) and no B(x).
    compound = ex(eq(rec(2, 0, 1), 0))
    illegal_step = [compound, None, [0, successor_step(3)]]
    add('U_compound_cannot_use_induction_hypothesis', [u(compound), [illegal_step]], False,
        purpose='Would accept if equation induction were erroneously generalized to compound formulas.')
    # A valid numerical-cases step reads the base through E elimination.
    compound = ex(eq(rec(2, 0, 0), 0))
    compound_base = substitute(compound, [0, 0])
    add('U_compound_cases_reads_retained_base', [u(compound), [[compound_base, None, [0, 'r']]]], True)
    add('U_nested_compound_cases', [u(ex(truth)), [None]], True)
    add('U_retained_scope_capture', [u(eq(1, 2)), [None], eq(succ(1), 2)], False)

    # Elimination consumes B(0), not B(t); a free parameter is not captured.
    body = eq(1, 2)
    major = u(body)
    base = eq(0, 1)
    goal = eq(succ(2), 1)
    add('U_elimination_parameter_scope', [goal, [major, None, succ(2), None], major, base], True)
    add('U_elimination_missing_base', [goal, [major, None, succ(2), None], major], False)
    add('U_elimination_wrong_base', [goal, [major, None, succ(2), None], major, goal], False)
    add('U_elimination_wrong_conclusion', [eq(1, succ(2)), [major, None, succ(2), None], major, base], False)
    add('U_elimination_extra_argument', [goal, [major, None, succ(2), None, 0], major, base], False)
    add('U_elimination_missing_argument', [goal, [major, None, succ(2)], major, base], False)
    add('U_elimination_failed_major_falls_back', [truth, [u(eq(1, 0)), None, 0, None], truth], True)
    add('U_elimination_failed_major_no_fallback', [truth, [u(eq(1, 0)), None, 0, None]], False)

    # Existential freshness is exposed by both positive and capture tests.
    add('E_introduction_zero', [ex(eq(1, 0)), [0, None]], True)
    add('E_introduction_parameter', [ex(eq(1, 2)), [1, None]], True)
    add('E_introduction_successor', [ex(eq(1, succ(0))), [succ(0), None]], True)
    add('E_introduction_wrong_witness', [ex(eq(1, succ(0))), [0, None]], False)
    add('E_elimination', [truth, [ex(eq(1, 0)), None, refl(0)], ex(eq(1, 0))], True)
    add('E_elimination_capture', [eq(1, 0), [ex(eq(1, 0)), None, None], ex(eq(1, 0))], False)
    add('E_elimination_extra_argument', [truth, [ex(truth), None, None, None], ex(truth), truth], False)
    add('E_elimination_missing_argument', [truth, [ex(truth), None], ex(truth), truth], False)

    # Equality transport through each binder and the two-slot recursion body.
    equality = eq(2, succ(3))
    motives = [eq(1, 0), u(eq(2, 1)), ex(eq(2, 1)),
               u(ex(eq(rec(3, 1, succ(5)), 2))),
               eq(rec(1, 0, 3), rec(1, 2, succ(3)))]
    for i, motive in enumerate(motives):
        before = substitute(motive, [equality[1], -1])
        after = substitute(motive, [equality[2], -1])
        proof = [equality, None, motive, None]
        add('equality_transport_motive_' + str(i), [after, proof, equality, before], True)
        add('equality_transport_missing_minor_' + str(i), [after, proof, equality], False)
    add('equality_wrong_direction', [eq(2, 0), [equality, None, eq(1, 0), None], equality, eq(succ(3), 0)], False)
    add('equality_invalid_motive', [truth, [eq(0, 0), None, 0, None], truth], False)

    bad_terms = [True, False, None, -1, -2, 0.0, 1.5, '', '0', {}, {'s': 0}, [], ['s'],
                 ['s', 0, 0], ['r', 0, 0], ['r', 0, 0, 0, 0], ['=', 0, 0], ['u', truth], ['ex', truth],
                 ['s', -1], ['r', 0, 0, ['u', truth]]]
    for i, bad in enumerate(bad_terms):
        add('invalid_term_as_goal_' + str(i), [eq(bad, bad), None, eq(bad, bad)], False)
        add('invalid_term_unused_recursion_update_' + str(i), [eq(rec(0, 0, bad), 0), 'r'], False)
        add('invalid_existential_witness_' + str(i), [ex(truth), [bad, refl(0)]], False)
        add('unused_universal_annotation_' + str(i), [truth, [u(truth), None, bad, None], u(truth), truth], False, True)
        # Make every malformed term demanded by the matrix.
        add('demanded_universal_annotation_' + str(i), [truth, [u(eq(1, 0)), None, bad, None], u(eq(1, 0)), truth], False)
    bad_formulas = [True, False, None, 0, 1, -1, 0.0, '', 'u', {}, [], ['='], ['=', 0], ['=', 0, 0, 0],
                    ['u'], ['u', truth, truth], ['ex'], ['ex', truth, truth], ['s', 0], ['r', 0, 0, 0],
                    ['pi', truth, truth], ['u', 0], ['ex', 0], ['u', ['=', 0, False]]]
    for i, bad in enumerate(bad_formulas):
        add('invalid_formula_goal_' + str(i), [bad, None, bad], False)
        add('invalid_unused_public_hypothesis_' + str(i), [truth, refl(0), bad], False)
        add('invalid_equality_motive_' + str(i), [truth, [truth, None, bad, None], truth], False)

    # Deliberately truncated and malformed top-level records.
    for i, record in enumerate([None, {}, '', 0, True, [], [truth]]):
        add('malformed_public_record_' + str(i), record, False)
    return result
