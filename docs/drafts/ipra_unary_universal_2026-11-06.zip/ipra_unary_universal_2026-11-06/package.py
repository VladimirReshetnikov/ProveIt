"""Create a manifest and a reproducible ZIP of the final deliverable files."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'.build', '__pycache__'}


def files():
    return sorted(p for p in ROOT.rglob('*')
                  if p.is_file() and not any(part in EXCLUDED for part in p.relative_to(ROOT).parts)
                  and p.suffix not in ('.pyc', '.pyo')
                  and p.name != 'MANIFEST.sha256')


def main():
    paths = files()
    manifest = ''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  '
                       + p.relative_to(ROOT).as_posix() + '\n' for p in paths)
    (ROOT / 'MANIFEST.sha256').write_text(manifest)
    destination = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in [*paths, ROOT / 'MANIFEST.sha256']:
            entry = zipfile.ZipInfo(ROOT.name + '/' + path.relative_to(ROOT).as_posix(),
                                    date_time=(2026, 11, 6, 12, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, path.read_bytes(), compresslevel=9)
    print(destination.name)
    print('files:', len(paths) + 1)
    print('bytes:', destination.stat().st_size)
    print('sha256:', hashlib.sha256(destination.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
