"""Translate the literal numerical-Pi fragment into the unary-U calculus.

This is an untrusted, deliberately partial proof compiler.  Its accepted
source fragment requires EVERY guarded universal in formulas and equality
motives to have its guard literally equal to the body's zero instance.
It makes no claim to compile arbitrary old guarded universals.  Every
emitted certificate is independently checked by both target kernels.

Run ``python3 translator.py`` beside checker.py and checker_demand.py.
The bundled frozen source and source examples make the run self-contained.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


SOURCE = load_module("frozen_goal_only", ROOT / "reference/goal_only_checker.py")
STRICT = load_module("unary_strict", ROOT / "checker.py")
DEMAND = load_module("unary_demand", ROOT / "checker_demand.py")


class OutsideFragment(ValueError):
    """The source derivation uses a guarded universal outside this compiler."""


def formula(a):
    """Compile a well-formed source formula, leaving its number terms intact."""
    tag, *parts = a
    if tag == "=":
        return [tag, *parts]
    if tag == "ex":
        return [tag, formula(parts[0])]
    if tag == "pi":
        h, b = parts
        if h != SOURCE.subst(b, [0, 0]):
            raise OutsideFragment("A Pi guard is not its body's literal zero instance")
        return ["u", formula(b)]
    raise ValueError("Unknown formula constructor")


def proof(a, p, g):
    """Compile exactly the source inference selected at this proof node."""
    formula(a)
    match (a, p):
        case [["pi", h, b], [q]]:
            # formula(a) has already established h == b(0).
            local = b if b[0] == "=" else h
            goal = SOURCE.subst(b, [["s", 1], 0])
            context = [*map(SOURCE.subst, g), local]
            return [proof(goal, q, context)]
        case [["ex", b], [t, q]]:
            local = ["=", 1, SOURCE.subst(t, formula=False)]
            context = [*map(SOURCE.subst, g), local]
            return [t, proof(b, q, context)]
        case [_, [[tag, *parts] as m, r, *args]] if SOURCE.check(m, r, *g):
            major = formula(m)
            major_proof = proof(m, r, g)
            if tag == "ex":
                q, = args
                local, = parts
                goal = SOURCE.subst(a)
                context = [*map(SOURCE.subst, g), local]
                return [major, major_proof, proof(goal, q, context)]
            t, q = args
            if tag == "=":
                annotation = formula(t)
                goal = SOURCE.subst(t, [parts[0], -1])
            else:
                annotation = t
                goal = SOURCE.subst(parts[0], [t, -1])
            return [major, major_proof, annotation, proof(goal, q, g)]
        case [["=", ["r", _, _, _], _], []]:
            return "r"
        case _:
            # A membership leaf has no semantically relevant certificate.
            return None


def compile_sequent(sequent):
    """Check a source sequent, compile it, and check both target policies."""
    a, p, *g = sequent
    if not SOURCE.check(a, p, *g):
        raise ValueError("Source rejected the submitted sequent")
    result = [formula(a), proof(a, p, g), *map(formula, g)]
    if not STRICT.check(*result) or not DEMAND.check(*result):
        raise AssertionError("A compiled certificate failed target checking")
    return result


def derivation_nodes(a, p, g=(), path=(1,)):
    """Replay source derivations, including the exact local sequent at each node."""
    yield {"proof_path": list(path), "sequent": [a, p, *g]}
    match (a, p):
        case [["pi", h, b], [q]]:
            if h == SOURCE.subst(b, [0, 0]):
                h = b if b[0] == "=" else h
                b = SOURCE.subst(b, [["s", 1], 0])
            yield from derivation_nodes(b, q, [*map(SOURCE.subst, g), h], (*path, 0))
        case [["ex", b], [t, q]]:
            h = ["=", 1, SOURCE.subst(t, formula=False)]
            yield from derivation_nodes(b, q, [*map(SOURCE.subst, g), h], (*path, 1))
        case [_, [[tag, *parts] as m, r, *args]] if SOURCE.check(m, r, *g):
            yield from derivation_nodes(m, r, g, (*path, 1))
            if tag == "ex":
                q, = args
                h, = parts
                yield from derivation_nodes(SOURCE.subst(a), q,
                                            [*map(SOURCE.subst, g), h], (*path, 2))
            else:
                t, q = args
                b = (SOURCE.subst(t, [parts[0], -1]) if tag == "="
                     else SOURCE.subst(parts[0], [t, -1]))
                yield from derivation_nodes(b, q, g, (*path, 3))


def supported_formula(a):
    try:
        formula(a)
        return True
    except OutsideFragment:
        return False


def encoded(value):
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


def main():
    report = {
        "repository": "VladimirReshetnikov/ProveIt",
        "commit": "fa581763b2bb75e8ba055da8e56280c9fd5dd890",
        "source_archive": "docs/drafts/ipra_goal_only_2026-11-06.zip",
        "source_archive_sha256": "4c12259ef1c13ddb82eaa29fa3e5873b479e5c0157246bc224acdaa379f80f5d",
        "source_checker_sha256": sha(ROOT / "reference/goal_only_checker.py"),
        "target_strict_sha256": sha(ROOT / "checker.py"),
        "target_demand_sha256": sha(ROOT / "checker_demand.py"),
        "scope": "Every Pi occurring in a formula or motive has guard literally B(0).",
        "outside_scope_is_not_target_rejection": True,
        "context_pruning": (
            "For extracted nodes, only assumptions outside the compiler fragment "
            "are removed. The complete pruned source sequent is rechecked before "
            "translation. Target context is exactly the translation of that "
            "pruned source context. Original local contexts are also retained."
        ),
        "whole_examples": [],
        "extracted_examples": [],
    }
    seen = set()
    for path in sorted((ROOT / "source_examples").glob("*.json")):
        source_sequent = json.loads(path.read_text())
        if not SOURCE.check(*source_sequent):
            raise AssertionError("Frozen source example rejected: " + path.name)
        whole = {"file": path.name, "sha256": sha(path), "source_accepted": True}
        try:
            target = compile_sequent(source_sequent)
            save_json(ROOT / "translated_examples" / path.name, target)
            whole["status"] = "compiled_and_accepted_by_both_targets"
        except OutsideFragment as error:
            whole.update(status="outside_compiler_scope", reason=str(error))
        report["whole_examples"].append(whole)

        supported = []
        a, p, *g = source_sequent
        for node in derivation_nodes(a, p, g):
            goal, certificate, *original_context = node["sequent"]
            if not supported_formula(goal):
                continue
            context = [h for h in original_context if supported_formula(h)]
            pruned_source = [goal, certificate, *context]
            if not SOURCE.check(*pruned_source):
                continue
            try:
                target = compile_sequent(pruned_source)
            except OutsideFragment:
                continue
            code = encoded(pruned_source)
            if code in seen:
                continue
            supported.append((len(encoded(certificate)), node, pruned_source, target, code))
        # Preserve one substantial, distinct subderivation per original example.
        if supported:
            size, node, source, target, code = max(supported, key=lambda row: row[0])
            seen.add(code)
            name = path.stem + "_subderivation.json"
            source_name = "extracted_sources/" + name
            target_name = "translated_examples/" + name
            save_json(ROOT / source_name, source)
            save_json(ROOT / target_name, target)
            report["extracted_examples"].append({
                "source_example": path.name,
                "source_example_sha256": sha(path),
                "source_proof_node_path": node["proof_path"],
                "source_proof_node_pointer": "/" + "/".join(map(str, node["proof_path"])),
                "original_local_sequent": node["sequent"],
                "checked_source_sequent_file": source_name,
                "target_sequent_file": target_name,
                "source_context_size": len(source) - 2,
                "original_context_size": len(node["sequent"]) - 2,
                "certificate_json_bytes": size,
                "source_accepted": True,
                "strict_target_accepted": True,
                "demand_target_accepted": True,
                "source_sequent_sha256": sha(ROOT / source_name),
                "target_sequent_sha256": sha(ROOT / target_name),
            })
    report["summary"] = {
        "source_examples": len(report["whole_examples"]),
        "whole_examples_compiled": sum(e["status"].startswith("compiled")
                                       for e in report["whole_examples"]),
        "whole_examples_outside_scope": sum(e["status"] == "outside_compiler_scope"
                                            for e in report["whole_examples"]),
        "extracted_examples_compiled_and_checked": len(report["extracted_examples"]),
        "extracted_certificate_json_bytes": sum(e["certificate_json_bytes"]
                                               for e in report["extracted_examples"]),
    }
    save_json(ROOT / "translation_results.json", report)
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
