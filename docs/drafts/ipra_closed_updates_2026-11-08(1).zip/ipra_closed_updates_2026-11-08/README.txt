REMOVING ALL UPDATE PARAMETERS FROM iPRA
=======================================
Research report for Vladimir Reshetnikov
8 November 2026 (Pacific date)

RESULT AND LIMITATION
---------------------
The report gives a theory bi-interpretable with full intuitionistic
primitive recursive arithmetic in which every scalar iterator update is
a closed unary term. Its counter and initializer remain arbitrary terms.
The nonlogical basis is two iterator computation schemas, literal-equation
induction, a two-valued zero-test axiom, and the explicit falsity bridge.

The main contribution relative to the inspected drafts is an internal
predecessor construction using a delayed-reset clock, proved before
numerical coverage. A second, halving clock gives pairing projections.
Every primitive-recursive definition is then compiled by carrying its
fixed environment in the state. Both interpretations use the whole
domain; both composites are internally the identity.

This resolves the explicit closed-update predecessor gap in the current
foundation audit. Pure iteration's classical standard-model completeness
is older work, credited to Gladstone and Severin. The report does not
claim historical priority for that functional-completeness theorem.

The user's additional request for a strict complete-checker size record
is NOT achieved. The current coordinate envelope is 317 normalized
tokens / 348 AST nodes / 885 normalized bytes. The direct closed-update
scope prototype measures 396 / 430 / 1168. The prototype is exploratory,
with focused scope diagnostics rather than a general correctness proof.
The report also does not establish an absolute simplestness theorem.

START HERE
----------
report.pdf                   Complete mathematical paper.
report.tex, sections/*.tex    Editable LaTeX source for the complete paper.
code/closed_programs.py       Exact staged term definitions and validator.
code/verify_clocks.py         Literal and accelerated finite diagnostics.
code/checker_closed_update_prototype.py
                             Disclosed exploratory checker, not a record.
code/test_scope_prototype.py  Six public-interface scope diagnostics.
comparison/measure.py         Reproduces the frozen size comparison.
comparison/checkers/          Twelve unchanged current checker sources.
results/                     Definition, diagnostic, measurement, and QA
                             receipts. Their limitations are explicit.
ATTRIBUTION.txt               Contribution boundaries and provenance.
LICENSE.txt, attribution/    License and inherited attribution notices.
MANIFEST.json                SHA-256 digest of every packaged payload file
                             except the manifest itself.

REPRODUCE THE EXECUTABLE RESULTS
------------------------------
Use Python 3.10 or later. All numerical and comparison programs require
only the standard library. The delivered receipts used CPython 3.12.14.
Source-size measurements can depend on the Python ast.unparse version;
use that version to reproduce the exact reported triple.

    python3 reproduce.py

This runs, in order:

    python3 code/verify_clocks.py
    python3 code/test_scope_prototype.py
    python3 comparison/measure.py

The clock diagnostics report 104,268 finite checks, including 23 literal
AST evaluations. Larger tests disclose standard-model shortcuts. The
definition validator checks 32 staged numerical definitions and rejects
four malformed examples. None of these finite checks is a proof of the
nonstandard-model identities, bi-interpretability, or universal checker
soundness. Those claims are supported by the written mathematical proofs.
No Lean, Rocq, or other proof-assistant formalization is included.

BUILD THE PAPER
---------------
With a working TeX Live or MiKTeX installation and latexmk:

    python3 build.py

Equivalently:

    latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

The paper uses standard packages: geometry, fontenc, lmodern, microtype,
amsmath, amssymb, amsthm, mathtools, booktabs, longtable, array, enumitem,
xcolor, fancyhdr, hyperref, and bookmark. It needs no network download,
shell escape, external bibliography processor, or generated figures.
The already compiled PDF is included for reading without TeX installed.

To regenerate a payload manifest and ZIP after deliberate changes:

    python3 make_archive.py

This excludes TeX intermediate files, caches, temporary files, and the
archive itself. It creates the ZIP next to the package directory.

SOURCE SNAPSHOT
---------------
Repository: VladimirReshetnikov/ProveIt
Commit:     06e097f723c659030816e0194e5eb7e8c607ba9b
Directory:  docs/drafts
URL: https://github.com/VladimirReshetnikov/ProveIt/tree/06e097f723c659030816e0194e5eb7e8c607ba9b/docs/drafts

All twelve current draft archives were inspected. The comparison includes
their twelve complete root checker programs; it does not silently reuse
an older envelope. The coordinate minima have different attainers.
Archive hashes, source hashes, and the unchanged measurement normalizer
are retained. No change was pushed to the repository.

The complementary Kripke-fan argument in the paper explains a limitation
of ordinary disjunction-free axiomatizations, even with definable quotient
interpretations. It is not a checker-size lower bound and carries no
global historical novelty claim.
