"""Reproduce the finite diagnostics and frozen source measurements."""

from pathlib import Path
import json
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def main():
    commands = (
        "code/verify_clocks.py",
        "code/test_scope_prototype.py",
        "comparison/measure.py",
    )
    records = []
    for relative in commands:
        completed = subprocess.run(
            [sys.executable, str(ROOT / relative)],
            cwd=ROOT, text=True, capture_output=True, check=False,
        )
        if completed.returncode:
            sys.stderr.write(completed.stdout + completed.stderr)
            raise SystemExit(completed.returncode)
        records.append({"script": relative, "exit_code": completed.returncode})
        print("PASS", relative)
    result = {
        "status": "PASS",
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "commands": records,
        "scope": "Reproduced finite diagnostics and measurements, not formal proofs.",
    }
    (ROOT / "results" / "reproduction.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
