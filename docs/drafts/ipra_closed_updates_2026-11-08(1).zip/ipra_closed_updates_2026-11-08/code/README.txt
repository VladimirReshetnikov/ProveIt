Closed unary iteration: numerical definition and diagnostic artifacts
===================================================================

Run with Python 3.10 or later, from any directory:

    python3 code/verify_clocks.py

The command writes:

    results/closed_definitions.json
    results/clock_checks.json

closed_programs.py gives the exact finite staged term DAG for all 32 named
numerical definitions used in the predecessor and pairing constructions.
The only recursion constructor is J_h(n,a).  Its update h names an earlier
unary definition, validated in an environment containing exactly its one
state parameter.  Counters and initializers may contain arbitrary ambient
parameters.  The update never captures them.  Calls to named functions are
finite acyclic abbreviations, not an additional recursion operation.

The syntax validator checks stage order, arity, and variable scope.  It
does not check logical derivations.  The exported JSON is an auditable
definition artifact, not a formal proof certificate.

verify_clocks.py has two evaluation modes:

1. A literal, fuel-bounded external interpreter executes the exact AST
   with no accelerated numerical helper.  It checks 23 small examples,
   including the selector, comparator, two finite cycles, the two ramps,
   the reset update, and initial predecessor cases.

2. Larger finite diagnostics use explicitly recorded standard-model
   shortcuts for the inherited functions.  They test the new clock
   invariants, reset, ramp, readout, predecessor, halving completion time,
   bitlength, and pairing projections.  The clock V uses its linear even
   tail to avoid impractically many steps on large pair codes; small
   cases compare this acceleration with literal T-step execution.

The paper supplies the symbolic proofs.  No finite diagnostic proves
identity in nonstandard models, full bi-interpretability, or proof-checker
soundness.  No universal primitive-recursive evaluator is asserted in the
object theory.  The external literal interpreter is explicitly fuel bounded
and can decline to evaluate even a small term by exhausting that fuel.

All artifacts here use only the Python standard library.
