"""Reproduce finite diagnostics for the closed-update construction.

These checks are NOT a formal proof and are NOT a proof checker.
The symbolic, fixed-parameter induction arguments are in the paper.

Two deliberately different evaluation modes are used:
  1. A fuel-bounded literal interpreter evaluates the exact staged AST on
     tiny inputs, using only 0, successor, abbreviation expansion and J.
  2. Larger finite checks use explicit fast standard-model realizations
     of inherited functions and the proved linear tail of the halving
     clock.  Every shortcut is recorded in the JSON output.

The larger checks therefore cannot establish the inherited identities,
their provability in the theory, or behavior in nonstandard models.
"""

from __future__ import annotations

from collections import Counter
import json
from pathlib import Path

from closed_programs import (
    LiteralInterpreter, StagedProgram, call, construction, iterate, num, var,
)


def repeat(update, count: int, initial: int) -> int:
    state = initial
    for _ in range(count):
        state = update(state)
    return state


def select(n: int, a: int, b: int) -> int:
    return a if n == 0 else b


# Explicit shortcuts for inherited helpers, only in standard N.
def N(n: int) -> int:
    return n % 2


def M(n: int) -> int:
    return n % 3


def G(n: int) -> int:
    return n + n // 2


def H(n: int) -> int:
    return G(n) if N(n) == 0 else n


def E(n: int) -> int:
    return 1 << n


def L(a: int, b: int) -> int:
    return int(a <= b)


def q5(u: int) -> int:
    return select(L(u, 0),
                  select(L(u, 1),
                         select(L(u, 2),
                                select(L(u, 3), 0, 4), 3), 2), 1)


def F(u: int) -> int:
    return select(M(u), select(N(u), H(u), 1), u + 3)


def A(n: int) -> int:
    # The new ramp is actually iterated, rather than replaced by ceil(5n/3).
    return repeat(lambda u: u + 1 + L(u % 5, 3), n, 0)


def Q(n: int) -> int:
    return repeat(F, 2 * n + 1, 3 * E(A(n) + 1))


def P(n: int) -> int:
    # Both mathematical arguments are evaluated; no expected predecessor
    # value is used to execute the new construction.
    return select(L(n, 2), Q(n) + M(n) + 1, L(2, n))


def d(a: int, b: int) -> int:
    return max(a - b, 0)


def D(n: int) -> int:
    return d(G(n), n)


def T(v: int) -> int:
    return select(N(v), v + 2,
                  select(L(2, D(v)), 0, 2 * D(D(v)) + 1))


def V_literal_steps(t: int, a: int) -> int:
    """Execute each T-step, using the fast inherited helpers above."""
    return repeat(T, t, 2 * a + 1)


def V(t: int, a: int) -> int:
    """Execute odd steps, then use the explicit even-tail formula."""
    state = 2 * a + 1
    remaining = t
    while remaining and N(state):
        state = T(state)
        remaining -= 1
    return state + 2 * remaining


def K(a: int) -> int:
    return d(a + 1, D(V(a + 1, a)))


def ell(a: int) -> int:
    return P(K(a))


def pair(a: int, b: int) -> int:
    return E(a) + E(a + b + 1)


def first(z: int) -> int:
    return ell(d(z, E(ell(z))))


def second(z: int) -> int:
    return d(P(ell(z)), first(z))


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    output = root / "results"
    output.mkdir(parents=True, exist_ok=True)
    program = construction()
    program.export(output / "closed_definitions.json")
    counts: Counter[str] = Counter()

    def check(group: str, condition: bool, context=None) -> None:
        if not condition:
            raise AssertionError(f"{group} failed: {context!r}")
        counts[group] += 1

    rejected = []
    bad_builders = [
        ("unary update capturing a second variable",
         lambda p: p.add("bad", ("u",), var(1), "must reject")),
        ("a forward reference",
         lambda p: p.add("bad", ("u",), call("not_declared", var(0)), "must reject")),
        ("using a binary function as a unary iterator update",
         lambda p: p.add("bad", ("u",), iterate("add", var(0), num(0)), "must reject")),
        ("wrong abbreviation arity",
         lambda p: p.add("bad", ("u",), call("add", var(0)), "must reject")),
    ]
    for description, build in bad_builders:
        try:
            build(construction())
        except ValueError:
            rejected.append(description)
            check("syntax_rejections", True)
        else:
            check("syntax_rejections", False, description)

    literal = LiteralInterpreter(program, fuel=2_000_000)
    literal_cases = [
        ("add", (4, 5), 9),
        ("zero_test", (0,), 1), ("zero_test", (4,), 0),
        ("selector", (0, 4, 7), 4), ("selector", (3, 4, 7), 7),
        ("parity", (7,), 1), ("mod3", (8,), 2),
        ("ramp3", (6,), 9), ("factor_map", (6,), 9),
        ("factor_map", (7,), 7),
        ("leq", (2, 3), 1), ("leq", (3, 2), 0),
        ("cycle5_update", (3,), 4), ("cycle5_update", (8,), 0),
        ("mod5", (7,), 2), ("ramp5", (6,), 10),
        ("reset_update", (6,), 9), ("reset_update", (9,), 1),
        ("reset_update", (4,), 7),
        ("readout", (0,), 9),
        ("predecessor", (0,), 0), ("predecessor", (1,), 0),
        ("pair", (1, 1), 10),
    ]
    literal_results = []
    for name, arguments, expected in literal_cases:
        before = literal.used
        actual = literal.evaluate(name, *arguments)
        check("exact_ast_literal_cases", actual == expected, (name, arguments, actual, expected))
        literal_results.append({"name": name, "arguments": arguments,
                                "value": actual, "work_units": literal.used - before})

    for u in range(301):
        check("q5_range", q5(u) in range(5), u)
    for n in range(121):
        check("mod5_cycle", repeat(q5, n, 0) == n % 5, n)
    for a in range(81):
        for t in range(41):
            check("reset_clock_identity", repeat(F, a + 1 + t, 3 * E(a)) == 3 * t + 1, (a, t))

    for u in range(0, 601, 3):
        r, v, w = u, u, 3 * u
        for t in range(71):
            check("H_preserves_mod3_zero", M(r) == 0, (u, t))
            check("clock_coincidence_gate", select(N(r), v, r) == r, (u, t))
            check("clock_residue_gate", select(N(r), 1, M(F(v))) == 1, (u, t))
            check("clock_scale_gate", select(N(r), F(v), F(w)) == F(v), (u, t))
            r, v, w = H(r), F(v), F(w)

    for n in range(201):
        an = A(n)
        check("ramp_standard_value", an == (5 * n + 2) // 3, n)
        check("ramp_residue_invariant", an % 5 == 2 * M(n), n)
        check("ramp_bound", L(A(n + 3) + 1, 2 * (n + 3)) == 1, n)
        check("readout_identity", Q(n + 3) + M(n) == n + 1, n)
        check("predecessor_equations", P(n + 1) == n and P(0) == 0, n)

    for n in range(501):
        check("half_standard_value", D(n) == n // 2, n)
    for a in range(81):
        for t in range(81):
            check("halving_tail_acceleration", V(t, a) == V_literal_steps(t, a), (t, a))
    for a in range(161):
        state = 2 * a + 1
        for t in range(a + 4):
            q = D(state)
            check("halving_odd_phase_bound", N(state) != 1 or q + t <= a, (a, t, state))
            check("halving_even_phase_bound", N(state) != 0 or q + 1 <= t, (a, t, state))
            state = T(state)
        check("halving_finishes_by_a_plus_one", N(V(a + 1, a)) == 0, a)
        check("completion_time_standard_value", K(a) == max(1, a.bit_length()), a)
        if a >= 2:
            check("completion_time_recurrence", K(a) == 1 + K(D(a)), a)
        for extra in range(21):
            t = a + 1 + extra
            check("completion_time_stability", d(t, D(V(t, a))) == K(a), (a, extra))

    for a in range(81):
        check("power_bitlength_identity", K(E(a)) == a + 1 and ell(E(a)) == a, a)
    codes = set()
    for a in range(33):
        for b in range(33):
            code = pair(a, b)
            check("pair_bitlength", K(code) == a + b + 2 and ell(code) == a + b + 1, (a, b))
            check("pair_first_projection", first(code) == a, (a, b))
            check("pair_second_projection", second(code) == b, (a, b))
            check("finite_pair_injectivity", code not in codes, (a, b))
            codes.add(code)

    results = {
        "status": "all finite diagnostics passed",
        "limitations": [
            "No Lean, Rocq, or other formal proof was checked by this script.",
            "Finite diagnostics do not establish nonstandard-model identities or bi-interpretability.",
            "The syntax validator checks the finite staged definition DAG, not logical inference.",
            "The literal interpreter has external fuel and is not an object-language universal PR evaluator.",
        ],
        "syntax_validation": program.validate(),
        "rejected_invalid_definitions": rejected,
        "exact_ast_evaluation": {
            "fuel_limit": literal.fuel, "work_used": literal.used,
            "memoized_calls": len(literal.cache), "cases": literal_results,
        },
        "fast_standard_model_shortcuts": {
            "N": "n % 2", "M": "n % 3", "M5": "n % 5",
            "G": "n + n//2", "H": "G(n) when even; n when odd",
            "E": "1 << n", "L": "int(a <= t)",
            "d": "max(a-b,0)",
            "V_even_tail": "after first even state, remaining T steps add 2 each",
            "new_terms_actually_executed": ["q5", "F", "A", "Q", "P", "T odd phase", "K", "ell", "pair", "first", "second"],
        },
        "check_counts": dict(sorted(counts.items())),
        "total_checks": sum(counts.values()),
        "sample_predecessor_table": [
            {"n": n, "A": A(n), "Q": Q(n), "P": P(n)} for n in range(15)
        ],
    }
    (output / "clock_checks.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": results["status"], "total_checks": results["total_checks"],
                      "literal_work_units": literal.used,
                      "definitions": len(program.definitions)}, indent=2))


if __name__ == "__main__":
    main()
