"""Exact, staged term DAG for the closed-update iPRA construction.

The object language has 0, S and J_h(n,a), where h is a PREVIOUSLY
DEFINED unary term.  A J node records only a fixed unary definition name:
it has no captured numerical parameters.  Ordinary definitions of other
arities are finite acyclic abbreviations, expanded by simultaneous
substitution; they add no recursion scheme.

The optional literal interpreter is an external, fuel-bounded diagnostic.
It is not an object-language universal primitive-recursive evaluator and
is not used as a proof checker.  Its recursive evaluation strategy can
exhaust fuel even on very small inputs to the predecessor term.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any


Expr = tuple[Any, ...]


def var(index: int) -> Expr:
    return ("var", index)


def num(value: int) -> Expr:
    """Numerals are abbreviations for a finite string of S's over 0."""
    if type(value) is not int or value < 0:
        raise ValueError("a numeral must be a nonnegative integer")
    result: Expr = ("zero",)
    for _ in range(value):
        result = ("succ", result)
    return result


def succ(term: Expr) -> Expr:
    return ("succ", term)


def call(name: str, *arguments: Expr) -> Expr:
    return ("call", name, *arguments)


def iterate(update: str, count: Expr, initial: Expr) -> Expr:
    return ("iterate", update, count, initial)


@dataclass(frozen=True)
class Definition:
    name: str
    parameters: tuple[str, ...]
    expression: Expr
    explanation: str

    @property
    def arity(self) -> int:
        return len(self.parameters)


class StagedProgram:
    def __init__(self) -> None:
        self.definitions: list[Definition] = []
        self.by_name: dict[str, Definition] = {}

    def add(self, name: str, parameters: tuple[str, ...],
            expression: Expr, explanation: str) -> None:
        if name in self.by_name:
            raise ValueError(f"duplicate definition: {name}")
        self._validate_expression(expression, len(parameters), self.by_name)
        definition = Definition(name, parameters, expression, explanation)
        self.definitions.append(definition)
        self.by_name[name] = definition

    @staticmethod
    def _validate_expression(term: Expr, arity: int,
                             earlier: dict[str, Definition]) -> None:
        if type(term) is not tuple or not term:
            raise ValueError("expression must be a nonempty tuple")
        tag = term[0]
        if tag == "zero" and len(term) == 1:
            return
        if tag == "var" and len(term) == 2:
            if type(term[1]) is not int or not 0 <= term[1] < arity:
                raise ValueError(f"out-of-scope variable: {term}")
            return
        if tag == "succ" and len(term) == 2:
            StagedProgram._validate_expression(term[1], arity, earlier)
            return
        if tag == "call" and len(term) >= 2:
            name = term[1]
            if type(name) is not str or name not in earlier:
                raise ValueError(f"call must refer to an earlier definition: {name}")
            if len(term) - 2 != earlier[name].arity:
                raise ValueError(f"wrong arity for {name}")
            for argument in term[2:]:
                StagedProgram._validate_expression(argument, arity, earlier)
            return
        if tag == "iterate" and len(term) == 4:
            update = term[1]
            if type(update) is not str or update not in earlier:
                raise ValueError("an iterator must name an earlier update")
            if earlier[update].arity != 1:
                raise ValueError(f"iterator update is not unary: {update}")
            StagedProgram._validate_expression(term[2], arity, earlier)
            StagedProgram._validate_expression(term[3], arity, earlier)
            # There is no environment argument or closure capture in this node.
            # The earlier unary definition has already been validated in arity 1.
            return
        raise ValueError(f"malformed expression: {term}")

    def validate(self) -> dict[str, Any]:
        earlier: dict[str, Definition] = {}
        iteration_nodes: list[dict[str, Any]] = []

        def collect(term: Expr, owner: str) -> None:
            if term[0] == "iterate":
                iteration_nodes.append({"owner": owner, "update": term[1],
                                        "update_arity": earlier[term[1]].arity})
                collect(term[2], owner)
                collect(term[3], owner)
            elif term[0] == "succ":
                collect(term[1], owner)
            elif term[0] == "call":
                for child in term[2:]:
                    collect(child, owner)

        for definition in self.definitions:
            self._validate_expression(definition.expression, definition.arity, earlier)
            collect(definition.expression, definition.name)
            earlier[definition.name] = definition
        return {
            "definition_count": len(self.definitions),
            "iterator_node_count": len(iteration_nodes),
            "all_dependencies_strictly_earlier": True,
            "all_iterator_updates_unary_without_captured_parameters": True,
            "all_variable_occurrences_within_declared_arity": True,
            "primitive_term_constructors": ["var", "zero", "succ", "iterate"],
            "call_nodes_are_finite_acyclic_abbreviations": True,
            "iteration_nodes": iteration_nodes,
        }

    def export(self, destination: Path) -> None:
        data = {
            "format": "closed-unary-iteration-dag-v1",
            "notice": (
                "This is a finite staged term definition DAG, not a theory of "
                "program codes. The validation below checks syntax and closure, "
                "not the mathematical proof of iPRA bi-interpretability."
            ),
            "grammar": {
                "zero": ["zero"], "successor": ["succ", "term"],
                "variable": ["var", "index below definition arity"],
                "abbreviation": ["call", "earlier definition", "arguments..."],
                "iteration": ["iterate", "earlier UNARY definition", "count", "initial"],
            },
            "definitions": [
                {"stage": i, "name": definition.name,
                 "parameters": definition.parameters,
                 "arity": definition.arity,
                 "expression": definition.expression,
                 "explanation": definition.explanation}
                for i, definition in enumerate(self.definitions)
            ],
            "validation": self.validate(),
        }
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def construction() -> StagedProgram:
    p = StagedProgram()
    x, y, z = var(0), var(1), var(2)
    c = call
    p.add("successor", ("u",), succ(x), "The primitive successor update.")
    p.add("zero_update", ("u",), num(0), "The constant-zero unary update.")
    p.add("identity", ("u",), x, "A diagnostic identity update.")
    p.add("add", ("a", "b"), iterate("successor", y, x), "a+b.")
    p.add("double", ("u",), c("add", x, x), "2u, by repeated addition.")
    p.add("triple", ("u",), c("add", c("add", x, x), x), "3u, by repeated addition.")
    p.add("zero_test", ("n",), iterate("zero_update", x, num(1)), "Z(0)=1, Z(Sn)=0.")
    p.add("selector", ("n", "a", "b"),
          c("add", iterate("zero_update", x, y),
            iterate("zero_update", c("zero_test", x), z)),
          "C(0,a,b)=a; C(Sn,a,b)=b. A Boolean 1 selects b.")
    p.add("parity", ("n",), iterate("zero_test", x, num(0)), "N, the parity cycle.")
    p.add("cycle3_update", ("u",),
          c("add", c("zero_test", x), c("double", c("parity", x))),
          "j(u)=Z(u)+2N(u), with cycle 0,1,2,0.")
    p.add("mod3", ("n",), iterate("cycle3_update", x, num(0)), "M, the modulus-three cycle.")
    p.add("ramp3_update", ("u",), succ(c("add", x, c("mod3", x))),
          "Closed update u -> S(u+M(u)).")
    p.add("ramp3", ("n",), iterate("ramp3_update", x, num(0)),
          "Inherited G, standardly n+floor(n/2).")
    p.add("factor_map", ("u",), c("selector", c("parity", x), c("ramp3", x), x),
          "H(2u)=3u; H fixes odd inputs and commutes with scaling by 3.")
    p.add("power2", ("n",), iterate("double", x, num(1)), "E(n)=2^n.")
    p.add("leq", ("a", "t"),
          c("parity", iterate("factor_map", y, c("power2", x))),
          "L(a,t), Boolean true=1; standardly a<=t.")
    p.add("cycle5_update", ("u",),
          c("selector", c("leq", x, num(0)),
            c("selector", c("leq", x, num(1)),
              c("selector", c("leq", x, num(2)),
                c("selector", c("leq", x, num(3)), num(0), num(4)), num(3)), num(2)), num(1)),
          "A globally finite-valued 0,1,2,3,4 cycle, using only Boolean selectors.")
    p.add("mod5", ("n",), iterate("cycle5_update", x, num(0)), "M5.")
    p.add("reset_update", ("u",),
          c("selector", c("mod3", x),
            c("selector", c("parity", x), c("factor_map", x), num(1)),
            c("add", x, num(3))),
          "F: convert factors 2 to 3; reset an odd multiple of 3 to 1; count by 3.")
    p.add("ramp5_update", ("u",),
          c("add", succ(x), c("leq", c("mod5", x), num(3))),
          "g(u)=u+1+L(M5(u),3).")
    p.add("ramp5", ("n",), iterate("ramp5_update", x, num(0)),
          "A: increments 2,2,1, standardly ceil(5n/3).")
    p.add("readout", ("n",),
          iterate("reset_update", succ(c("double", x)),
                  c("triple", c("power2", succ(c("ramp5", x))))),
          "Q(n)=F^(2n+1)(3E(A(n)+1)).")
    p.add("predecessor", ("n",),
          c("selector", c("leq", x, num(2)),
            succ(c("add", c("readout", x), c("mod3", x))), c("leq", num(2), x)),
          "P, with internally proved P(0)=0 and P(Sn)=n.")
    p.add("subtract", ("a", "b"), iterate("predecessor", y, x),
          "Truncated subtraction d(a,b)=P^b(a).")
    p.add("half", ("n",), c("subtract", c("ramp3", x), x),
          "D(n)=d(G(n),n), standardly floor(n/2).")
    p.add("halving_update", ("v",),
          c("selector", c("parity", x), c("add", x, num(2)),
            c("selector", c("leq", num(2), c("half", x)), num(0),
              succ(c("double", c("half", c("half", x)))))),
          "T: even states count by 2; odd states encode q, halve q>=2, otherwise finish at 0.")
    p.add("halving_orbit", ("t", "a"),
          iterate("halving_update", x, succ(c("double", y))), "V(t,a)=T^t(2a+1).")
    p.add("completion_time", ("a",),
          c("subtract", succ(x), c("half", c("halving_orbit", succ(x), x))),
          "K(a)=d(a+1,D(V(a+1,a))).")
    p.add("bit_length_minus_one", ("a",), c("predecessor", c("completion_time", x)),
          "ell=P(K); ell(E(a))=a and ell(0)=0.")
    p.add("pair", ("a", "b"),
          c("add", c("power2", x), c("power2", succ(c("add", x, y)))),
          "c(a,b)=E(a)+E(a+b+1).")
    p.add("first", ("z",),
          c("bit_length_minus_one", c("subtract", x,
            c("power2", c("bit_length_minus_one", x)))),
          "pi0(z)=ell(d(z,E(ell(z)))).")
    p.add("second", ("z",),
          c("subtract", c("predecessor", c("bit_length_minus_one", x)), c("first", x)),
          "pi1(z)=d(P(ell(z)),pi0(z)).")
    return p


class FuelExhausted(RuntimeError):
    pass


class LiteralInterpreter:
    """Externally evaluate the exact DAG, with a hard work limit and memoization.

    Primitive iteration uses exactly h^0(a)=a and h^(n+1)(a)=h(h^n(a)).
    No numerical helper is replaced by a closed form in this interpreter.
    """
    def __init__(self, program: StagedProgram, fuel: int = 200_000) -> None:
        program.validate()
        self.program = program
        self.fuel = fuel
        self.used = 0
        self.cache: dict[tuple[str, tuple[int, ...]], int] = {}

    def tick(self, amount: int = 1) -> None:
        self.used += amount
        if self.used > self.fuel:
            raise FuelExhausted(f"literal interpreter exceeded {self.fuel} units of fuel")

    def evaluate(self, name: str, *arguments: int) -> int:
        definition = self.program.by_name[name]
        if len(arguments) != definition.arity:
            raise ValueError("wrong call arity")
        if any(type(a) is not int or a < 0 for a in arguments):
            raise ValueError("arguments must be nonnegative integers")
        self.tick()
        key = (name, arguments)
        if key not in self.cache:
            self.cache[key] = self.expression(definition.expression, arguments)
        return self.cache[key]

    def expression(self, term: Expr, environment: tuple[int, ...]) -> int:
        self.tick()
        tag = term[0]
        if tag == "zero":
            return 0
        if tag == "var":
            return environment[term[1]]
        if tag == "succ":
            return self.expression(term[1], environment) + 1
        if tag == "call":
            values = tuple(self.expression(a, environment) for a in term[2:])
            return self.evaluate(term[1], *values)
        if tag == "iterate":
            count = self.expression(term[2], environment)
            state = self.expression(term[3], environment)
            if count > self.fuel - self.used:
                raise FuelExhausted("literal iteration count exceeds remaining fuel")
            for _ in range(count):
                self.tick()
                state = self.evaluate(term[1], state)
            return state
        raise ValueError("unvalidated expression")


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    p = construction()
    p.export(root / "results" / "closed_definitions.json")
    print(json.dumps(p.validate(), indent=2))


if __name__ == "__main__":
    main()
