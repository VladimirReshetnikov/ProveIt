"""Replay six focused diagnostics of the exploratory closed-program checker.

These tests exercise computation and the new closed update scope boundary.
They do not prove universal soundness, completeness, or bi-interpretability.
The checker is launched through its public JSON/stdin interface each time.
"""

from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parent.parent
CHECKER = ROOT / "code" / "checker_closed_update_prototype.py"
RESULT = ROOT / "results" / "scope_prototype.json"
EXPECTED_SHA256 = "e47dfb352e22bda7e86365ff51bc834f0c4796d5d817d1743fe042442d7b80e8"

# At one-input program scope, [3] represents the successor of that input.
SUCCESSOR_PROGRAM = [3]
CASES = (
    {
        "name": "zero_computation",
        "description": "J_S(0,0)=0 is an I0 instance.",
        "packet": [[0, 0], [[0, 0, SUCCESSOR_PROGRAM], 0]],
        "expected_accept": True,
    },
    {
        "name": "successor_computation",
        "description": "J_S(S0,0)=S(J_S(0,0)) is an IS instance.",
        "packet": [[0, 0], [[[0], 0, SUCCESSOR_PROGRAM],
                            [[0, 0, SUCCESSOR_PROGRAM]]]],
        "expected_accept": True,
    },
    {
        "name": "false_zero_computation",
        "description": "An alleged I0 instance with result S0 rejects.",
        "packet": [[0, 0], [[0, 0, SUCCESSOR_PROGRAM], [0]]],
        "expected_accept": False,
    },
    {
        "name": "program_captures_outer_slot",
        "description": "Program coordinate 5 cannot capture an outer paired-binder slot.",
        "packet": [[0, [0, 0, 0]], [0, 0, [[0, 0, 5], 0]]],
        "expected_accept": False,
    },
    {
        "name": "program_negative_parameter",
        "description": "A negative rigid parameter is forbidden in a closed update program.",
        "packet": [[0, 0], [[0, 0, -1], 0]],
        "expected_accept": False,
    },
    {
        "name": "oversized_program",
        "description": "A program node with four children rejects.",
        "packet": [[0, 0], [[0, 0, [0, 0, 0, 0]], 0]],
        "expected_accept": False,
    },
)


def main():
    checker_hash = hashlib.sha256(CHECKER.read_bytes()).hexdigest()
    if checker_hash != EXPECTED_SHA256:
        raise ValueError("The exploratory checker differs from the measured prototype.")
    records = []
    for case in CASES:
        completed = subprocess.run(
            [sys.executable, str(CHECKER)],
            input=json.dumps(case["packet"]),
            text=True,
            capture_output=True,
            timeout=10,
            check=False,
        )
        expected_output = "ACCEPT" if case["expected_accept"] else "REJECT"
        expected_exit = 0 if case["expected_accept"] else 1
        passed = (completed.stdout.strip() == expected_output
                  and completed.returncode == expected_exit
                  and completed.stderr == "")
        records.append({
            **case,
            "stdout": completed.stdout.strip(),
            "stderr": completed.stderr,
            "exit_code": completed.returncode,
            "passed": passed,
        })
    failures = sum(not item["passed"] for item in records)
    result = {
        "status": "PASS" if failures == 0 else "FAIL",
        "scope": "Six finite public-interface diagnostics; no universal checker correctness claim.",
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "checker": str(CHECKER.relative_to(ROOT)),
        "checker_sha256": checker_hash,
        "test_count": len(records),
        "passed_count": len(records) - failures,
        "failed_count": failures,
        "tests": records,
    }
    RESULT.parent.mkdir(parents=True, exist_ok=True)
    RESULT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in
                      ("status", "test_count", "passed_count", "failed_count")},
                     indent=2))
    return int(failures != 0)


if __name__ == "__main__":
    raise SystemExit(main())
