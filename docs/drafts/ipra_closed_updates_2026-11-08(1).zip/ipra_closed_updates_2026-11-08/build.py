"""Build the complete paper with a working latexmk/TeX installation."""

from pathlib import Path
import shutil
import subprocess


ROOT = Path(__file__).resolve().parent


def main():
    executable = shutil.which("latexmk")
    if executable is None:
        raise SystemExit("Install latexmk and a working TeX distribution first.")
    subprocess.run(
        [executable, "-pdf", "-interaction=nonstopmode", "-halt-on-error",
         "-latexoption=-no-shell-escape", "report.tex"],
        cwd=ROOT, check=True,
    )
    print(ROOT / "report.pdf")


if __name__ == "__main__":
    main()
