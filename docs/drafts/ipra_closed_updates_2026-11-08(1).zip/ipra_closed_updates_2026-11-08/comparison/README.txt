Pinned full-program comparison
==============================

Run from the extracted package root:

    python3 comparison/measure.py

Outputs:
    results/measurements.json
    results/comparison_table.tex

snapshot.json identifies the twelve current archives at ProveIt commit
06e097f723c659030816e0194e5eb7e8c607ba9b. original_audit.json records the
initial independent measurement and SHA-256 hashes of all twelve complete
root checker programs found in those archives. The exact programs are
copied under checkers/. Historical nested comparison copies and partial
test APIs are not additional root contenders.

source_measure.py is the unchanged inherited normalizer from the supplied
Boolean-boundary archive. measure.py verifies its SHA-256 and every copied
program's original SHA-256 before recomputing the comparison. It does not
execute the frozen comparison programs. No network access is needed.

The measured boundary is the complete source with genuine docstrings
removed and ast.unparse normalization applied. It includes imports,
input/output, scope handling, inference checking and rejection behavior.
The three headline coordinates are normalized significant tokens, AST
nodes, and normalized UTF-8 source bytes. Exact counts can depend on
Python's AST and unparser version; the recorded runtime is CPython 3.12.14.

The present coordinate envelope is 317 / 348 / 885. Its two nondominated
programs are the byte and structural profiles in the initializer-obstruction
archive. Different profiles attain the byte minimum and token/AST minima.
The 322 / 350 / 903 figures in several source reports refer to their earlier
six-archive comparison, not the present twelve-archive snapshot.

The exploratory closed-update checker is measured separately at
396 / 430 / 1168 and is not a new size record. Six focused diagnostics are
reproduced by code/test_scope_prototype.py; they are not a universal proof
of the prototype's correctness. No source-size measurement is a universal
lower-bound theorem about all equivalent axiomatizations.
