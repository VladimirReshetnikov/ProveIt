"""Remeasure every current root checker and the exploratory closed-update prototype.

The inherited source_measure.py is imported unchanged. Frozen source identities
are checked against the original audit before measurement. No network access
or execution of the comparison checkers is required.
"""

from pathlib import Path, PurePosixPath
import hashlib
import importlib.util
import json
import platform


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
METRIC_KEYS = ("normalized_tokens", "ast_nodes", "normalized_bytes")
NORMALIZER_SHA256 = "f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc"
PROTOTYPE_SHA256 = "e47dfb352e22bda7e86365ff51bc834f0c4796d5d817d1743fe042442d7b80e8"
LABELS = {
    "ipra_boolean_core_2026-11-08__checker.py": "Boolean core synthesis",
    "ipra_boxed_witnesses_2026-11-08__checker.py": "Boxed witnesses",
    "ipra_boxed_witnesses_2026-11-08__checker_compatible.py": "Boxed: compatible",
    "ipra_clausal_kernel_2026-11-08__checker.py": "Clausal kernel",
    "ipra_context_blocks_2026-11-08__checker.py": "Context blocks",
    "ipra_context_pairs_2026-11-08__checker.py": "Context pairs",
    "ipra_context_pairs_2026-11-08__checker_exact_list.py": "Context pairs: exact list",
    "ipra_fixed_contexts_2026-11-08__checker.py": "Fixed contexts",
    "ipra_kernel_2026-11-08__checker.py": "Initializer kernel: byte profile",
    "ipra_kernel_2026-11-08__checker_structural.py": "Initializer kernel: structural",
    "ipra_normalized_elimination_2026-11-08__checker.py": "Normalized elimination",
    "ipra_normalized_elimination_2026-11-08__checker_readable.py": "Normalized: readable",
}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dominates(left, right):
    return (all(left[key] <= right[key] for key in METRIC_KEYS)
            and any(left[key] < right[key] for key in METRIC_KEYS))


def main():
    normalizer_path = HERE / "source_measure.py"
    if sha256(normalizer_path) != NORMALIZER_SHA256:
        raise ValueError("The inherited measurement normalizer has changed.")
    spec = importlib.util.spec_from_file_location("inherited_source_measure", normalizer_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load inherited measurement normalizer.")
    normalizer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(normalizer)

    snapshot = json.loads((HERE / "snapshot.json").read_text(encoding="utf-8"))
    audit = json.loads((HERE / "original_audit.json").read_text(encoding="utf-8"))
    archives = {item["name"]: item for item in snapshot["files"]}
    rows = []
    copied_names = set()
    for entry in audit["rows"]:
        original = PurePosixPath(entry["path"])
        directory = original.parent.name
        copied_name = directory + "__" + original.name
        copied_names.add(copied_name)
        path = HERE / "checkers" / copied_name
        measured = normalizer.metrics(path)
        if measured["sha256"] != entry["sha256"]:
            raise ValueError("Frozen checker source has changed: " + copied_name)
        archive_name = ("ipra_kernels_and_initializer_obstruction_2026-11-08.zip"
                        if directory == "ipra_kernel_2026-11-08"
                        else directory + ".zip")
        if archive_name not in archives:
            raise ValueError("Missing source archive identity: " + archive_name)
        rows.append({
            "label": LABELS[copied_name],
            "local_file": str(path.relative_to(ROOT)),
            "source_archive": archive_name,
            "source_member": directory + "/" + original.name,
            "archive_blob_sha1": archives[archive_name]["blob_sha"],
            **{key: value for key, value in measured.items() if key != "core"},
        })
    if {path.name for path in (HERE / "checkers").glob("*.py")} != copied_names:
        raise ValueError("The copied checker inventory differs from the twelve-program audit.")

    minima = {key: min(row[key] for row in rows) for key in METRIC_KEYS}
    frontier = [row for row in rows
                if not any(dominates(other, row) for other in rows)]
    for row in rows:
        row["pareto_frontier"] = row in frontier
    prototype_path = ROOT / "code" / "checker_closed_update_prototype.py"
    prototype = normalizer.metrics(prototype_path)
    if prototype["sha256"] != PROTOTYPE_SHA256:
        raise ValueError("The exploratory prototype differs from its recorded source.")
    prototype = {
        "label": "Closed-update scope prototype",
        "local_file": str(prototype_path.relative_to(ROOT)),
        "status": "EXPLORATORY_NOT_A_CERTIFIED_SIZE_CONTENDER",
        **{key: value for key, value in prototype.items() if key != "core"},
    }
    result = {
        "repository": "VladimirReshetnikov/ProveIt",
        "commit": snapshot["commit"],
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "measurement_scope": "Complete standalone source, including imports, input/output and rejection; docstrings stripped and ast.unparse normalized.",
        "normalizer_file": "comparison/source_measure.py",
        "normalizer_sha256": NORMALIZER_SHA256,
        "archive_count": len(snapshot["files"]),
        "current_program_count": len(rows),
        "coordinatewise_minimum": minima,
        "minimum_attainers": {
            key: [row["local_file"] for row in rows if row[key] == minima[key]]
            for key in METRIC_KEYS
        },
        "pareto_frontier": [row["local_file"] for row in frontier],
        "current_programs": rows,
        "prototype": prototype,
        "prototype_delta_from_minima": {
            key: prototype[key] - minima[key] for key in METRIC_KEYS
        },
        "prototype_strictly_below_minima": {
            key: prototype[key] < minima[key] for key in METRIC_KEYS
        },
        "comparison_status": "NO_NEW_CHECKER_SIZE_RECORD",
        "limits": "These are finite source measurements, not a universal lower bound or an independent correctness proof of the submitted checkers. The prototype has only six focused scope diagnostics.",
    }
    results = ROOT / "results"
    results.mkdir(parents=True, exist_ok=True)
    (results / "measurements.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8")

    table = [r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
             r"Complete program & Tokens & AST & Bytes\\", r"\midrule"]
    for row in rows:
        table.append(f"{row['label']} & {row['normalized_tokens']} & "
                     f"{row['ast_nodes']} & {row['normalized_bytes']}" + r"\\")
    table.extend([
        r"\midrule",
        f"Current coordinate minima & {minima['normalized_tokens']} & "
        f"{minima['ast_nodes']} & {minima['normalized_bytes']}" + r"\\",
        f"Exploratory closed-update prototype & {prototype['normalized_tokens']} & "
        f"{prototype['ast_nodes']} & {prototype['normalized_bytes']}" + r"\\",
        r"\bottomrule", r"\end{tabular}",
    ])
    (results / "comparison_table.tex").write_text("\n".join(table) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in (
        "current_program_count", "coordinatewise_minimum", "pareto_frontier",
        "prototype_delta_from_minima", "comparison_status")}, indent=2))


if __name__ == "__main__":
    main()
