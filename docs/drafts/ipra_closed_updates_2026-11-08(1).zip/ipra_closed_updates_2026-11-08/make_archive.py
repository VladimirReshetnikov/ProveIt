"""Write a payload manifest and a deterministic ZIP beside this directory."""

from pathlib import Path
import hashlib
import json
import zipfile


ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {
    ".aux", ".log", ".out", ".toc", ".fls", ".fdb_latexmk", ".synctex.gz",
    ".pyc", ".zip", ".fmt",
}


def payload_files():
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if not path.is_file() or path.is_symlink():
            continue
        if any(part.startswith(".") or part == "__pycache__" for part in relative.parts):
            continue
        if any(path.name.endswith(suffix) for suffix in EXCLUDED_SUFFIXES):
            continue
        if relative.as_posix() != "MANIFEST.json":
            yield path


def main():
    files = list(payload_files())
    manifest = {
        "title": "Removing all update parameters from iPRA",
        "date": "2026-11-08",
        "source_commit": "06e097f723c659030816e0194e5eb7e8c607ba9b",
        "manifest_excludes_itself": True,
        "files": [
            {"path": path.relative_to(ROOT).as_posix(),
             "bytes": path.stat().st_size,
             "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
            for path in files
        ],
    }
    manifest_path = ROOT / "MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    archive_path = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted([*files, manifest_path]):
            name = ROOT.name + "/" + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 8, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(archive_path) as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError("Archive CRC failed: " + bad)
    print(json.dumps({
        "archive": str(archive_path), "file_count": len(files) + 1,
        "bytes": archive_path.stat().st_size,
        "sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    }, indent=2))


if __name__ == "__main__":
    main()
