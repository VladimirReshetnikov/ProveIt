"""Independent, explicit-sort reference for the saturated iPRA representation.

This is audit code, not a trusted dependency of the submitted proof checker.
It does not import the checker. The reference uses ordinary scope lists and
an explicit distinction between numerical and formula positions. In particular
it does not implement the checker's parity-based, saturated-increment walk.
"""

import math


ZERO = ("zero",)
TRUTH = ("truth",)
HOLE = ("hole",)
ABSENT = object()


class InvalidSyntax(ValueError):
    pass


def retained_number(value, floor, limit):
    """The JSON numerical leaf test, separated from formula truth aliases."""
    if not isinstance(value, (int, float)):
        raise InvalidSyntax("a numerical leaf must be a JSON number")
    return floor <= value < limit


def reference_open(expression, image=ABSENT, *, sort="formula", slots=0, floor=0):
    """Normalize or open using an explicit sorted syntax recursion.

    slots counts raw protected coordinates, including dummy slots. A numerical
    root has three zero aliases, 0 <= a < 3, and two aliases per protected slot.
    Image validation is deliberately lazy, matching the stated calculus: an
    unused numerical image is not part of the opening's active syntax.
    """
    if slots < 0 or sort not in ("formula", "number"):
        raise ValueError("invalid reference scope")

    def walk(node, kind, count, replacement):
        if not isinstance(node, list):
            if kind == "formula":
                return 0
            if retained_number(node, floor, 3 + 2 * count):
                return node
            if replacement is ABSENT:
                raise InvalidSyntax("an open numerical coordinate has no image")
            return walk(replacement, "number", 0, ABSENT)

        arity = len(node)
        if arity == 0:
            return []
        if kind == "formula":
            if arity == 1:
                return [walk(node[0], "formula", count + 1, replacement)]
            if arity == 2:
                return [walk(x, "number", count, replacement) for x in node]
            # Every arity >= 3 has two formula binders; extra fields are padding.
            return [walk(x, "formula", count + 2, replacement) for x in node]

        if arity == 1:
            return [walk(node[0], "number", count + 1, replacement)]
        if arity == 2:
            # A numerical binary node is zero with two checked annotations.
            return [walk(x, "formula", count + 3, replacement) for x in node]
        # Every numerical arity >= 3 adds two numerical coordinates uniformly.
        return [walk(x, "number", count + 2, replacement) for x in node]

    return walk(expression, sort, slots, image)


def decode(expression, *, sort="formula", slots=0, floor=0,
           profile="scalar", allow_holes=False):
    """Decode to a separate locally nameless syntax and validate all padding.

    The returned syntax has actual logical/arithmetic binders only. Dummy raw
    slots become zero. Formula aliases become truth. Numerical binary nodes
    become zero, but their annotation children are recursively checked first.
    Ignored padding is validated, never accepted by an unchecked shortcut.
    """
    if profile not in ("scalar", "direct"):
        raise ValueError("unknown arithmetic profile")
    if slots < 0:
        raise ValueError("negative scope")
    initial_scope = [("level", slots - 1 - j) for j in range(slots)]

    def resolve_scalar(node, scope, level):
        if not retained_number(node, floor, 3 + 2 * len(scope)):
            if allow_holes:
                return HOLE
            raise InvalidSyntax("unbound numerical coordinate")
        if node < 0:
            return ("parameter", math.floor(node))
        if node < 3:
            return ZERO
        item = scope[(math.floor(node) - 3) // 2]
        if item == ZERO:
            return ZERO
        return ("bound", level - 1 - item[1])

    def number(node, scope, level):
        if not isinstance(node, list):
            return resolve_scalar(node, scope, level)
        n = len(node)
        if not n:
            return ZERO
        if n == 1:
            return ("successor", number(node[0], [ZERO] + scope, level))
        if n == 2:
            annotations = [ZERO, ZERO, ZERO] + scope
            for child in node:
                formula(child, annotations, level)
            return ZERO

        dummy_scope = [ZERO, ZERO] + scope
        counter = number(node[0], dummy_scope, level)
        initializer = number(node[1], dummy_scope, level)
        if profile == "scalar":
            previous = ("level", level)
            update = number(node[2], [previous, previous] + scope, level + 1)
            tag = "iterate"
        else:
            previous_counter = ("level", level)
            previous_value = ("level", level + 1)
            update = number(node[2], [previous_value, previous_counter] + scope,
                            level + 2)
            tag = "recurse"
        for padding in node[3:]:
            number(padding, dummy_scope, level)
        return (tag, counter, initializer, update)

    def formula(node, scope, level):
        if not isinstance(node, list):
            return TRUTH
        n = len(node)
        if not n:
            return TRUTH
        if n == 1:
            variable = ("level", level)
            return ("closure", formula(node[0], [variable] + scope, level + 1))
        if n == 2:
            return ("equal", number(node[0], scope, level),
                    number(node[1], scope, level))

        outer = ("level", level)
        inner = ("level", level + 1)
        binder_scope = [inner, outer] + scope
        decoded = [formula(child, binder_scope, level + 2) for child in node]
        return ("paired", decoded[2])

    if sort == "number":
        return number(expression, initial_scope, slots)
    if sort == "formula":
        return formula(expression, initial_scope, slots)
    raise ValueError("unknown sort")


def map_children(node, visit, depth=0):
    """One independent binder-aware traversal for the semantic syntax."""
    tag = node[0]
    if tag in ("zero", "truth", "hole", "parameter", "bound"):
        return node
    if tag == "successor":
        return (tag, visit(node[1], depth))
    if tag == "equal":
        return (tag, visit(node[1], depth), visit(node[2], depth))
    if tag == "closure":
        return (tag, visit(node[1], depth + 1))
    if tag == "paired":
        return (tag, visit(node[1], depth + 2))
    if tag in ("iterate", "recurse"):
        bound_count = 1 if tag == "iterate" else 2
        return (tag, visit(node[1], depth), visit(node[2], depth),
                visit(node[3], depth + bound_count))
    raise ValueError("unknown semantic constructor")


def replace_hole(motive, value):
    """Fill a sorted motive with a closed numerical value (rigid names allowed)."""
    def walk(node, depth=0):
        if node == HOLE:
            return value
        return map_children(node, walk, depth)
    return walk(motive)


def shift_bound_indices(term, amount):
    def walk(node, depth=0):
        if node[0] == "bound":
            return ("bound", node[1] + amount if node[1] >= depth else node[1])
        return map_children(node, walk, depth)
    return walk(term)


def eliminate_binding(body, index, value):
    """Standard de Bruijn substitution, eliminating one surrounding binding."""
    def walk(node, depth=0):
        if node[0] == "bound":
            variable = node[1]
            target = index + depth
            if variable == target:
                return shift_bound_indices(value, depth)
            return ("bound", variable - 1 if variable > target else variable)
        return map_children(node, walk, depth)
    return walk(body)


def is_closed(term):
    result = True
    def walk(node, depth=0):
        nonlocal result
        if node[0] == "bound" and node[1] >= depth:
            result = False
        return map_children(node, walk, depth)
    walk(term)
    return result


def contains_hole(term):
    if term == HOLE:
        return True
    return any(isinstance(part, tuple) and contains_hole(part) for part in term[1:])
