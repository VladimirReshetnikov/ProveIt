"""Deterministic independent finite checks of saturated-scope opening.

Run: python3 validate_opening.py /absolute/path/to/checker.py
The mathematical opening theorem is not established by these finite tests.
Only the candidate's exact sub/inst function is executed; the independent reference
and semantic decoder are in opening_reference.py and are not kernel dependencies.
"""

import argparse
import ast
import hashlib
import itertools
import json
from pathlib import Path
import random

from opening_reference import (
    ABSENT, HOLE, InvalidSyntax, contains_hole, decode, eliminate_binding,
    is_closed, reference_open, replace_hole,
)


SEED = 812037


def load_opening(path):
    text = path.read_text()
    tree = ast.parse(text, filename=str(path))
    definitions = [node for node in tree.body
                   if isinstance(node, ast.FunctionDef) and node.name in {"sub", "inst"}]
    if len(definitions) != 1:
        raise ValueError("expected exactly one top-level sub or inst function")
    module = ast.Module(body=definitions, type_ignores=[])
    namespace = {"k": 0}
    exec(compile(module, str(path), "exec"), namespace)
    return namespace[definitions[0].name], namespace


def outcome(call):
    try:
        return True, call()
    except (Exception, RecursionError):
        return False, None


def assert_equal_opening(inst, namespace, raw, image=ABSENT, *, sort="formula",
                         slots=0, floor=-3):
    namespace["k"] = floor
    depth = 2 * slots + (3 if sort == "number" else 0)
    image_arg = None if image is ABSENT else image
    actual = outcome(lambda: inst(raw, image_arg, depth))
    expected = outcome(lambda: reference_open(raw, image, sort=sort,
                                             slots=slots, floor=floor))
    if actual != expected:
        raise AssertionError({"kind": "opening_mismatch", "raw": raw,
                              "image": repr(image), "sort": sort,
                              "slots": slots, "floor": floor,
                              "actual": actual, "expected": expected})
    return actual


def generate(rng, kind, slots, depth, *, holes=False, extended=True):
    """Generate bounded well-scoped raw syntax by independent sorted rules."""
    if depth == 0 or rng.randrange(4) == 0:
        if kind == "formula":
            return rng.choice([0, 19, -200, None, "truth", {"ignored": 7}, []])
        if holes and rng.randrange(3) == 0:
            return 3 + 2 * slots + rng.choice([0, 0.25, 1, 9])
        values = [-3, -2.5, -1, -0.5, 0, False, 1, True, 2, 2.75]
        if slots:
            values += [3 + 2 * rng.randrange(slots) + rng.choice([0, 0.5, 1, 1.75])]
        return rng.choice(values)
    n = rng.choice([0, 1, 2, 3, 3, 4, 5, 7] if extended else [0, 1, 2, 3])
    if not n:
        return []
    if kind == "formula":
        child_kind = "number" if n == 2 else "formula"
        child_slots = slots if n == 2 else slots + (1 if n == 1 else 2)
    else:
        child_kind = "formula" if n == 2 else "number"
        child_slots = slots + (1 if n == 1 else 3 if n == 2 else 2)
    return [generate(rng, child_kind, child_slots, depth - 1,
                     holes=holes, extended=extended) for _ in range(n)]


def force_meaningful_hole(rng, raw, kind, slots):
    """Insert a hole in a semantic field, never merely in ignored padding."""
    hole = 3 + 2 * slots + rng.choice([0, 0.5, 1, 8])
    if kind == "number":
        if not isinstance(raw, list) or len(raw) in (0, 2):
            return hole
        result = list(raw)
        if len(raw) == 1:
            result[0] = force_meaningful_hole(rng, raw[0], "number", slots + 1)
        else:
            field = rng.randrange(3)
            result[field] = force_meaningful_hole(rng, raw[field], "number", slots + 2)
        return result
    if not isinstance(raw, list) or not raw:
        return [hole, 0]
    result = list(raw)
    if len(raw) == 1:
        result[0] = force_meaningful_hole(rng, raw[0], "formula", slots + 1)
    elif len(raw) == 2:
        field = rng.randrange(2)
        result[field] = force_meaningful_hole(rng, raw[field], "number", slots)
    else:
        result[2] = force_meaningful_hole(rng, raw[2], "formula", slots + 2)
    return result


def primitive_tests(inst, namespace, counts):
    # Every array of up to five scalar entries from this six-element alphabet.
    atoms = [-1, 0, 2, 3, None, "alias"]
    expressions = atoms + [False, 1, 2.75, 3.5, -0.5, {}, float("inf"), float("nan")]
    expressions += [list(parts) for arity in range(6)
                    for parts in itertools.product(atoms, repeat=arity)]
    for expression in expressions:
        for sort, slots in [("formula", 0), ("number", 0), ("formula", 1),
                            ("number", 1), ("formula", 3), ("number", 3)]:
            for image in (ABSENT, [0], [0, 0], "invalid numerical image"):
                assert_equal_opening(inst, namespace, expression, image,
                                     sort=sort, slots=slots)
                counts["bounded_scalar_array_openings"] += 1

    # Dedicated scope and alias expectations, independent of the kernel walk.
    assert decode(2.75, sort="number", floor=-3) == ("zero",)
    assert decode(-0.5, sort="number", floor=-3) == ("parameter", -1)
    assert decode(3.5, sort="number", slots=1, floor=-3) == ("bound", 0)
    assert decode(4.75, sort="number", slots=1, floor=-3) == ("bound", 0)
    assert decode([None, {"a": 1}], sort="number", floor=-3) == ("zero",)
    assert decode([3], sort="number", floor=-3) == ("successor", ("zero",))
    assert decode([0, 0, 3], sort="number", floor=-3) == (
        "iterate", ("zero",), ("zero",), ("bound", 0))
    assert decode([0, 0, 5], sort="number", floor=-3) == (
        "iterate", ("zero",), ("zero",), ("bound", 0))
    assert decode([0, 0, 5], sort="number", floor=-3, profile="direct") == (
        "recurse", ("zero",), ("zero",), ("bound", 1))
    counts["explicit_alias_and_scope_cases"] = 9


def motive_tests(inst, namespace, rng, counts, sample_count):
    for profile in ("scalar", "direct"):
        for _ in range(sample_count):
            kind = rng.choice(["formula", "formula", "number"])
            slots = rng.randrange(4)
            raw = generate(rng, kind, slots, rng.randrange(1, 5), holes=True)
            if _ % 2:
                raw = force_meaningful_hole(rng, raw, kind, slots)
            left = generate(rng, "number", 0, rng.randrange(1, 4))
            right = [left] if _ % 2 else generate(rng, "number", 0, rng.randrange(1, 4))
            motive = decode(raw, sort=kind, slots=slots, floor=-3,
                            profile=profile, allow_holes=True)
            for image in (left, right):
                value = decode(image, sort="number", floor=-3, profile=profile)
                assert is_closed(value)
                ok, opened = assert_equal_opening(inst, namespace, raw, image,
                                                  sort=kind, slots=slots)
                assert ok
                obtained = decode(opened, sort=kind, slots=slots, floor=-3,
                                  profile=profile)
                expected = replace_hole(motive, value)
                if obtained != expected:
                    raise AssertionError({"kind": "common_motive", "profile": profile,
                                          "raw": raw, "image": image, "slots": slots,
                                          "motive": motive, "obtained": obtained,
                                          "expected": expected})
                counts["semantic_motive_openings_" + profile] += 1
            counts["common_motive_pairs_" + profile] += 1
            if contains_hole(motive):
                counts["pairs_with_meaningful_holes_" + profile] += 1
            else:
                counts["pairs_without_meaningful_holes_" + profile] += 1
            if _ % 2:
                assert contains_hole(motive)
                assert decode(left, sort="number", floor=-3, profile=profile) != decode(
                    right, sort="number", floor=-3, profile=profile)
                counts["pairs_with_forced_hole_and_distinct_images_" + profile] += 1


def padding_tests(inst, namespace, rng, counts, sample_count):
    for profile in ("scalar", "direct"):
        for _ in range(sample_count):
            kind = rng.choice(["formula", "number"])
            slots = rng.randrange(3)
            child_kind = kind
            raw = [generate(rng, child_kind, slots + 2, 2, holes=True)
                   for _ in range(3)]
            extra = [generate(rng, child_kind, slots + 2, 2, holes=True)
                     for _ in range(rng.randrange(1, 8))]
            image = generate(rng, "number", 0, 2)
            _, ordinary = assert_equal_opening(inst, namespace, raw, image,
                                               sort=kind, slots=slots)
            _, padded = assert_equal_opening(inst, namespace, raw + extra, image,
                                             sort=kind, slots=slots)
            a = decode(ordinary, sort=kind, slots=slots, floor=-3, profile=profile)
            b = decode(padded, sort=kind, slots=slots, floor=-3, profile=profile)
            assert a == b
            counts["saturated_padding_pairs_" + profile] += 1


def computation_tests(inst, namespace, rng, counts, sample_count):
    namespace["k"] = -3
    for profile in ("scalar", "direct"):
        for _ in range(sample_count):
            # n and a are root-scoped terms: dummy raw coordinates in these
            # fields would be legal but need not produce literal computation
            # certificates. Here we test the canonical computation embedding.
            counter = generate(rng, "number", 0, 2)
            initial = generate(rng, "number", 0, 2)
            body = generate(rng, "number", 2, rng.randrange(1, 5))
            recursor = [counter, initial, body]
            rec_sem = decode(recursor, sort="number", floor=-3, profile=profile)
            counter_sem = decode(counter, sort="number", floor=-3, profile=profile)
            body_sem = rec_sem[3]
            if profile == "scalar":
                opened = inst(body, recursor, 3)
                expected = eliminate_binding(body_sem, 0, rec_sem)
            else:
                first = inst(body, counter, 5)
                # First opening removes only the prior-counter coordinate;
                # the nearer raw slot still denotes the prior value.
                ref_first = reference_open(body, counter, sort="number", slots=1,
                                           floor=-3)
                assert first == ref_first
                opened = inst(first, recursor, 3)
                expected = eliminate_binding(
                    eliminate_binding(body_sem, 1, counter_sem), 0, rec_sem)
            obtained = decode(opened, sort="number", floor=-3, profile=profile)
            if obtained != expected:
                raise AssertionError({"kind": "computation_substitution", "profile": profile,
                                      "body": body, "counter": counter,
                                      "initial": initial, "obtained": obtained,
                                      "expected": expected})
            counts["symbolic_successor_computations_" + profile] += 1


def logical_binding_tests(inst, namespace, rng, counts, sample_count):
    namespace["k"] = -3
    parameter = ("parameter", -3)
    for profile in ("scalar", "direct"):
        for _ in range(sample_count):
            matrix = generate(rng, "formula", 2, rng.randrange(1, 5))
            witness = generate(rng, "number", 0, 3)
            body = decode(matrix, slots=2, floor=-3, profile=profile)
            value = decode(witness, sort="number", floor=-3, profile=profile)
            opened_witness = inst(matrix, witness, 2)
            expected_witness = eliminate_binding(body, 1, value)
            assert decode(opened_witness, slots=1, floor=-3, profile=profile) == expected_witness
            for image, semantic_image in [
                (0, ("zero",)),
                (-3, parameter),
                ([-3], ("successor", parameter)),
            ]:
                opened_inner = inst(opened_witness, image, 0)
                expected_inner = eliminate_binding(expected_witness, 0, semantic_image)
                assert decode(opened_inner, floor=-3, profile=profile) == expected_inner
                counts["paired_introduction_inner_substitutions_" + profile] += 1
            opened_closure = inst([matrix], -3, 0)
            expected_closure = ("closure", eliminate_binding(body, 1, parameter))
            assert decode(opened_closure, floor=-3, profile=profile) == expected_closure
            counts["paired_elimination_closure_substitutions_" + profile] += 1


def raw_fuzz(inst, namespace, rng, counts, sample_count):
    atoms = [None, "x", {}, {"a": [1, 2]}, -99, -3.5, -3, -1, 0,
             False, True, 2.9, 3, 4.5, 7, 11, float("inf"), float("nan")]
    def tree(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return rng.choice(atoms)
        return [tree(depth - 1) for _ in range(rng.randrange(7))]
    for _ in range(sample_count):
        expression = tree(rng.randrange(1, 5))
        image = rng.choice([ABSENT, tree(2)])
        assert_equal_opening(inst, namespace, expression, image,
                             sort=rng.choice(["formula", "number"]),
                             slots=rng.randrange(4), floor=rng.choice([0, -1, -3]))
        counts["arbitrary_json_opening_cases"] += 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("checker", type=Path)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("results.json"))
    args = parser.parse_args()
    checker = args.checker.resolve()
    inst, namespace = load_opening(checker)
    from collections import defaultdict
    counts = defaultdict(int)
    rng = random.Random(SEED)
    primitive_tests(inst, namespace, counts)
    raw_fuzz(inst, namespace, rng, counts, 10000)
    motive_tests(inst, namespace, rng, counts, 3000)
    padding_tests(inst, namespace, rng, counts, 1500)
    computation_tests(inst, namespace, rng, counts, 2000)
    logical_binding_tests(inst, namespace, rng, counts, 1500)
    report = {
        "status": "passed",
        "checker_name": checker.name,
        "opening_function": inst.__name__,
        "checker_sha256": hashlib.sha256(checker.read_bytes()).hexdigest(),
        "seed": SEED,
        "counts": dict(sorted(counts.items())),
        "scope": "Finite independent tests of opening, semantic substitution, padding, and computation.",
        "limits": [
            "Not a proof-assistant formalization or an exhaustive audit of whole-checker soundness.",
            "The common-motive theorem still requires the structural mathematical proof.",
            "The fixed random seed and bounded scalar-array enumeration make the evidence reproducible.",
            "Only the exact submitted sub/inst function is extracted from the checker; no oracle code is trusted by it.",
        ],
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
