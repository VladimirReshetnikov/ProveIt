Independent saturated-scope opening audit
========================================

These files were written independently of the candidate kernel by a separate
mathematical reviewer. They are validation artifacts, not dependencies of the
trusted checker and not part of its source-size measurement.

Run with Python 3.10 or later:

    python3 validate_opening.py /absolute/path/to/checker.py

From this directory in the delivered archive, reproduce both exact-source
receipts with:

    python3 validate_opening.py ../../checker_scalar.py --output results_scalar.json
    python3 validate_opening.py ../../checker_direct.py --output results_direct.json

The test runner extracts only the submitted checker's exact sub or inst function by
parsing its source. It compares that function against a separate explicit-sort
reference and an independent semantic syntax. The reference does not use the
candidate's parity-based traversal or saturated-increment expression.

The representation audited has formula depth 2q and numerical depth 2q+3.
Numerical leaves in [0,3) denote zero. Protected slot j, starting with j=1,
has coordinates [2j+1,2j+3). Negative retained coordinates denote rigid
parameters by their floors. Formula scalar leaves denote truth; binary
numerical arrays denote zero with checked formula annotations. Arrays of
arity at least three use their first three fields, with all extra fields
checked as semantically irrelevant padding. Every array of arity at least
three adds two protected slots, corresponding to four depth units.

The test families cover:

* Bounded exhaustive scalar arrays through arity five, under six scopes and
  four image conditions, including invalid or unused numerical images.
* Arbitrary bounded JSON trees, including malformed numerical leaves and
  formula aliases, with a fixed random seed.
* Exact agreement of the two opening procedures.
* A common sorted motive for two independently chosen numerical images,
  tested after decoding to a separate binder syntax.
* Semantic invariance under additional checked padding.
* Symbolic scalar and direct-recursion successor substitution, including
  the direct profile's separate previous-counter and previous-value slots.
* The distinct witness, base, induction, and successor openings in paired
  introduction, and the retained closure in paired elimination.

The tests provide finite, reproducible evidence. They do not prove whole-
checker soundness, completeness, bi-interpretability, or the general opening
lemma. Those remain mathematical claims of the accompanying manuscript.
