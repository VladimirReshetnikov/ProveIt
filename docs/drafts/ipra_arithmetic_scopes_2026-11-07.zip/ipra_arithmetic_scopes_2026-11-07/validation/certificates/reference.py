"""Independent named-rule verifier for the saturated iPRA presentation.

Validation code, not part of the acceptance kernel. Numerical and formula
syntax are traversed separately, with explicit protected-variable counts.
No packed depth, arity table, source import, or structural match is shared
with the submitted checker.
"""
from copy import deepcopy


class Reference:
    def __init__(self, width=1):
        if width not in (1, 2):
            raise ValueError("recursion width")
        self.width = width
        self.lower = 0
        self.rules = {}

    def record(self, name):
        self.rules[name] = self.rules.get(name, 0) + 1

    def term(self, value, image=None, protected=0):
        if isinstance(value, (int, float)):
            if self.lower <= value < 2 * protected + 3:
                return value
            return self.term(image)
        if type(value) is not list:
            raise ValueError("numerical leaf")
        if not value:
            return []
        if len(value) == 1:
            return [self.term(value[0], image, protected + 1)]
        if len(value) == 2:
            # These two formula annotations have no numerical denotation.
            return [self.formula(child, image, protected + 3)
                    for child in value]
        # Additional children are validated numerical padding.
        return [self.term(child, image, protected + 2) for child in value]

    def formula(self, value, image=None, protected=0):
        if type(value) is not list:
            return 0
        if not value:
            return []
        if len(value) == 1:
            return [self.formula(value[0], image, protected + 1)]
        if len(value) == 2:
            return [self.term(child, image, protected) for child in value]
        # The third child is meaningful; all others are formula padding.
        return [self.formula(child, image, protected + 2) for child in value]

    def fresh(self):
        self.lower -= 1
        return self.lower

    def check(self, goal, context):
        normalized = self.formula(goal)
        if normalized in context:
            self.record("hypothesis")
            return True
        instruction = self.stack.pop()

        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, context):
                if not isinstance(major, (list, str)):
                    raise ValueError("major shape")
                if len(major) >= 3:
                    self.record("paired_elimination")
                    eigen = self.fresh()
                    hypothesis = self.formula([major[2]], eigen)
                    return self.check(self.formula(goal, [eigen]),
                                      context + [hypothesis])
                if type(major) is list and len(major) == 1:
                    self.record("closure_elimination")
                    matrix, left, right = major[0], 0, annotation
                elif len(major) == 2:
                    self.record("equality_transport")
                    matrix, (left, right) = annotation, major
                else:
                    raise ValueError("empty major")
                if self.formula(matrix, right) != goal:
                    return False
                return self.check(self.formula(matrix, left), context)
            self.record("failed_major_fallthrough")

        if type(instruction) is list and not instruction:
            if type(goal) is not list or len(goal) != 2:
                raise ValueError("computation requires equality")
            left, right = goal
            if type(left) is not list or len(left) != 3:
                raise ValueError("computation requires ternary recursor")
            counter, initial, update = left
            if counter == [] or (isinstance(counter, (int, float))
                                 and counter == 0):
                self.record("computation_zero")
                expected = initial
            elif type(counter) is list and len(counter) == 1:
                self.record("computation_successor")
                smaller = [counter[0], initial, update]
                body = (update if self.width == 1
                        else self.term(update, counter[0], 1))
                expected = self.term(body, smaller)
            else:
                raise ValueError("counter shape")
            return expected == right

        if type(goal) is not list or len(goal) < 3:
            raise ValueError("paired introduction shape")
        self.record("paired_introduction")
        matrix = self.formula(goal[2], instruction, 1)
        base = self.formula(matrix, 0)
        if type(matrix) is not list:
            raise ValueError("scalar introduction matrix")
        if len(matrix) == 2:
            self.record("equation_induction")
            assumptions = [matrix, base]
        else:
            assumptions = [base]
        eigen = self.fresh()
        step = self.formula(matrix, [eigen])
        hypotheses = [self.formula(h, eigen) for h in assumptions]
        return self.check(step, context + hypotheses)

    def run(self, packet):
        self.lower = 0
        self.rules = {}
        self.stack = deepcopy(packet)
        error = None
        try:
            accepted = bool(self.check(self.stack.pop(), []))
        except Exception as exc:
            accepted = False
            error = type(exc).__name__
        return {"accepted": accepted, "final_k": self.lower,
                "remaining": len(self.stack) if type(self.stack) is list else None,
                "rules": dict(self.rules), "error": error}


def value(term, *, width=1, env=(), parameters=None, budget=None):
    """Independent standard-natural denotation; ignored padding is not read.

    This evaluator does not perform opening, does not import Reference,
    and uses actual numerical environments instead of coordinate scopes.
    Bounds limit validation samples only, never the delivered checker.
    """
    import math
    if parameters is None:
        parameters = {}
    if budget is None:
        budget = [10000]
    budget[0] -= 1
    if budget[0] < 0:
        raise OverflowError("validation evaluator budget")
    if isinstance(term, (int, float)):
        c = math.floor(term)
        if c < 0:
            return parameters[c]
        if c < 3:
            return 0
        return env[(c - 3) // 2]
    if type(term) is not list:
        raise ValueError("term type")
    if len(term) in (0, 2):
        return 0
    if len(term) == 1:
        result = 1 + value(term[0], width=width, env=(0,) + env,
                           parameters=parameters, budget=budget)
    else:
        count, initial, update = term[:3]
        count = value(count, width=width, env=(0, 0) + env,
                      parameters=parameters, budget=budget)
        result = value(initial, width=width, env=(0, 0) + env,
                       parameters=parameters, budget=budget)
        if count > 30:
            raise OverflowError("validation counter bound")
        for predecessor in range(count):
            local = ((result, result) if width == 1
                     else (result, predecessor))
            result = value(update, width=width, env=local + env,
                           parameters=parameters, budget=budget)
    if result > 100000:
        raise OverflowError("validation value bound")
    return result
