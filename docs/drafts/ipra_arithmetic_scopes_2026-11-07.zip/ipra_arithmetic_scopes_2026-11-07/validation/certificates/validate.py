"""Reproduce the independent certificate and boundary validation.

Run python3 validate.py. It writes results.json and translated fixtures.
The source fixtures are exact copies of the current common_scope archive.
Only validate.py and reference.py are new validation tools. None of these
files is imported by either submitted checker.
"""
from copy import deepcopy
from collections import Counter
from pathlib import Path
import ast
import hashlib
import json
import platform
import random
import subprocess
import sys

from reference import Reference, value

ROOT = Path(__file__).resolve().parent
SEED = 2026110703


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_kernel(path):
    tree = ast.parse(Path(path).read_text())
    # Retain the executable core before the first top-level I/O driver.
    # The public CLI is tested separately with the unmodified whole file.
    drivers = [i for i, node in enumerate(tree.body)
               if isinstance(node, ast.Try)]
    if len(drivers) != 1:
        raise ValueError("unexpected source driver")
    tree.body = tree.body[:drivers[0]]
    namespace = {}
    exec(compile(tree, str(path), "exec"), namespace)
    return namespace


def run_kernel(namespace, packet):
    stack = deepcopy(packet)
    namespace["k"] = 0
    error = None
    try:
        namespace["take"] = stack.pop
        check = namespace.get("test", namespace.get("check"))
        accepted = bool(check(namespace["take"](), []))
    except Exception as exc:
        accepted = False
        error = type(exc).__name__
    return {"accepted": accepted, "error": error,
            "final_k": namespace["k"],
            "remaining": len(stack) if type(stack) is list else None}


def translate(tree):
    """For this canonical fixture, raise every positive coordinate by two.

    Zero stays zero, so the computation counter's zero spelling remains
    falsy. Negative eigenlabels and all array shapes remain unchanged.
    There are no numerical instruction opcodes in this packet format.
    Success is verified certificate by certificate, not assumed for an
    arbitrary noncanonical packet or every possible normalization.
    """
    if isinstance(tree, list):
        return [translate(child) for child in tree]
    if isinstance(tree, (int, float)) and tree > 0:
        return tree + 2
    return tree


def numeral(n):
    result = 0
    for _ in range(n):
        result = [result]
    return result


def named_cases(width):
    false = [[], [0]]
    major = [[], [], [], [0]]
    binary = [[7, 0], [8, 0]]
    padded = [0, 0, 3, 0, [0]]
    r = Reference(width)
    counter, initial, update = [0], 0, 5
    body = update if width == 1 else r.term(update, counter[0], 1)
    expected = r.term(body, [counter[0], initial, update])
    return [
        ("arity_four_false_equality_attack", [0, [major, 0], false], False),
        ("padded_paired_introduction", [0, major], True),
        ("padded_paired_elimination", [0, [major, 0], [[]]], True),
        ("very_long_paired_padding", [0, [[], [], []] + [[]] * 30], True),
        ("checked_formula_scalar_padding", [0, [[], [], [], None, "abc", {"x": 1}]], True),
        ("padded_numeric_initializer", [[], [[0, padded, 3], padded]], True),
        ("binary_numeric_annotation_third_slot", [[], [[0, binary, 3], binary]], True),
        ("binary_annotation_one_slot_too_far", [[], [[0, [[9, 0], []], 3], [[9, 0], []]]], False),
        ("boolean_true_is_zero_alias", [[], [[0, True, 3], True]], True),
        ("fractional_zero_alias", [[], [[0, 2.9, 3], 2.9]], True),
        ("true_counter_alias_not_computation_opcode", [[], [[True, 0, 3], 0]], False),
        ("mode_specific_outer_update_slot", [[], [[[0], 0, 5], expected]], True),
        ("future_parameter_rejected", [[], [[0, -1, 3], -1]], False),
        ("exposed_numerical_slot_rejected", [[], [[0, 3, 3], 3]], False),
        ("wrong_zero_computation", [[], [[0, 0, 3], [0]]], False),
        ("wrong_successor_computation", [[], [[[0], 0, [5]], 0]], False),
        ("checked_numeric_padding_rejected", [[], [[0, [0, 0, 3, None], 3], [0, 0, 3, None]]], False),
        ("formula_padding_scope_checked", [0, [[], [], [], [9, 0]]], False),
        ("active_nan_rejected", [[], [[0, float("nan"), 3], 0]], False),
        ("active_infinity_rejected", [[], [[0, float("inf"), 3], 0]], False),
        ("erased_nan_padding", [0, [[], [], [], float("nan")]], True),
        ("empty_packet", [], False),
        ("nonarray_packet", {"goal": 0}, False),
        ("null_packet", None, False),
        ("scalar_packet", 0, False),
    ]


def random_tree(rng, depth=3):
    atoms = [None, False, True, -4, -2, -1, 0, 1, 2, 3, 4, 5, 7, 9,
             0.25, 2.75, 3.5, "", "a", "ab", "abc", {"x": 0}]
    if depth <= 0 or rng.random() < 0.48:
        return deepcopy(rng.choice(atoms))
    return [random_tree(rng, depth - 1) for _ in range(rng.randrange(7))]


def paths(tree, prefix=()):
    yield prefix
    if isinstance(tree, list):
        for index, child in enumerate(tree):
            yield from paths(child, prefix + (index,))


def mutate(packet, rng):
    result = deepcopy(packet)
    path = rng.choice(list(paths(result)))
    replacement = random_tree(rng, 2)
    if not path:
        return replacement
    location = result
    for part in path[:-1]:
        location = location[part]
    location[path[-1]] = replacement
    return result


def main():
    rng = random.Random(SEED)
    results = {"python": platform.python_version(), "random_seed": SEED,
               "scope": "Finite independent implementation evidence, not a formal soundness proof.",
               "widths": {}, "failures": []}
    failures = results["failures"]
    cli_count = 0
    for width, label in [(1, "scalar"), (2, "direct")]:
        checker = ROOT / f"checker_{label}.py"
        original = ROOT / "fixtures" / f"checker_{label}.py"
        fixture = ROOT / "fixtures" / f"original_{label}.json"
        old = load_kernel(original)
        candidate = load_kernel(checker)
        records = json.loads(fixture.read_text())["records"]
        ref = Reference(width)
        stats = {"checker_sha256": digest(checker),
                 "original_checker_sha256": digest(original),
                 "fixture_sha256": digest(fixture),
                 "inherited_positive_count": len(records),
                 "populations": {}, "accepted_rule_counts": {},
                 "comparisons": 0, "accepted": 0,
                 "named_cases": [], "semantic_computation_equalities": 0}
        rules = Counter()

        def compare(packet, population, name, expected=None):
            got = run_kernel(candidate, packet)
            wanted = ref.run(packet)
            stats["comparisons"] += 1
            stats["populations"][population] = stats["populations"].get(population, 0) + 1
            if got["accepted"]:
                stats["accepted"] += 1
                rules.update(wanted["rules"])
            if got["accepted"] != wanted["accepted"]:
                failures.append({"width": width, "name": name, "kind": "oracle_disagreement",
                                 "actual": got, "reference": wanted, "packet": packet})
            if expected is not None and got["accepted"] != expected:
                failures.append({"width": width, "name": name, "kind": "unexpected_verdict",
                                 "expected": expected, "actual": got, "packet": packet})
            return got["accepted"]

        translated = []
        for record in records:
            if not run_kernel(old, record["packet"])["accepted"]:
                failures.append({"width": width, "name": record["name"],
                                 "kind": "source_positive_did_not_accept"})
            packet = translate(record["packet"])
            compare(packet, "translated_positive", record["name"], True)
            translated.append({"source_id": record["id"], "name": record["name"],
                               "source_packet_sha256": record["packet_sha256"],
                               "packet": packet})
            for _ in range(12):
                compare(mutate(packet, rng), "positive_mutation", record["name"])

        (ROOT / f"positive_{label}.json").write_text(json.dumps({
            "translation": "Every positive numeric leaf x maps to x+2; zero and negative leaves are unchanged.",
            "source_fixture_sha256": digest(fixture), "records": translated}, indent=2) + "\n")

        cases = named_cases(width)
        for name, packet, expected in cases:
            verdict = compare(packet, "named_case", name, expected)
            stats["named_cases"].append({"name": name, "expected": expected, "actual": verdict})

        for i in range(2000):
            packet = [random_tree(rng) for _ in range(rng.randrange(1, 8))]
            compare(packet, "random_packet", str(i))
        for i in range(500):
            prefix = deepcopy(rng.choice(translated)["packet"][:-1])
            # A false closed equation; retaining or mutating prefix commands
            # must not convert an earlier successful certificate into a proof.
            left = rng.randrange(4)
            right = (left + rng.randrange(1, 4)) % 5
            if right == left:
                right = left + 1
            prefix.append([numeral(left), numeral(right)])
            compare(prefix, "false_closed_equation", str(i), False)

        updates = [0, 1, 2.5, 3, 4, 5, 6, [5], [7],
                   [0, 7, 3], [0, 9, 3, 0], [[], []],
                   [0, 0, 3, 7, [9]]]
        for i in range(400):
            n = numeral(rng.randrange(4))
            seed = rng.choice([0, True, 2.75, [0], [[0]], [[], []]])
            update = deepcopy(rng.choice(updates))
            body = update if width == 1 else ref.term(update, n, 1)
            expected = ref.term(body, [n, seed, update])
            goal = [[[n], seed, update], expected]
            compare([[], goal], "computed_successor", str(i), True)
            lv = value(goal[0], width=width)
            rv = value(goal[1], width=width)
            if lv != rv:
                failures.append({"width": width, "name": str(i), "kind": "false_denotation",
                                 "left": lv, "right": rv, "goal": goal})
            else:
                stats["semantic_computation_equalities"] += 1
            wrong = [goal[0], numeral(lv + 1)]
            compare([[], wrong], "wrong_computation_result", str(i), False)

        cli_records = [(r["name"], r["packet"], True) for r in translated] + cases
        for optimized in (False, True):
            command = [sys.executable] + (["-O"] if optimized else []) + [str(checker)]
            for name, packet, expected in cli_records:
                process = subprocess.run(command, input=json.dumps(packet),
                                         text=True, capture_output=True, timeout=10)
                cli_count += 1
                actual = (process.returncode, process.stdout, process.stderr)
                wanted = (0, "ACCEPT\n", "") if expected else (1, "REJECT\n", "")
                if actual != wanted:
                    failures.append({"width": width, "name": name, "kind": "public_cli",
                                     "optimized": optimized, "actual": actual, "expected": wanted})
            for malformed in ["", "[", "null null", "{} trailing", "[[]]\n[]"]:
                process = subprocess.run(command, input=malformed, text=True,
                                         capture_output=True, timeout=10)
                cli_count += 1
                if (process.returncode, process.stdout, process.stderr) != (1, "REJECT\n", ""):
                    failures.append({"width": width, "name": malformed,
                                     "kind": "malformed_json_cli", "optimized": optimized})
        stats["accepted_rule_counts"] = dict(rules)
        results["widths"][label] = stats

    results["public_cli_runs"] = cli_count
    results["validator_sha256"] = digest(__file__)
    results["reference_sha256"] = digest(ROOT / "reference.py")
    results["status"] = "PASS" if not failures else "FAIL"
    (ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({"status": results["status"], "failures": len(failures),
                      "public_cli_runs": cli_count,
                      "widths": {k: {"positives": v["inherited_positive_count"],
                                     "comparisons": v["comparisons"],
                                     "accepted": v["accepted"],
                                     "semantic_computation_equalities": v["semantic_computation_equalities"]}
                                 for k, v in results["widths"].items()}}, indent=2))
    if failures:
        print(json.dumps(failures[:5], indent=2))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
