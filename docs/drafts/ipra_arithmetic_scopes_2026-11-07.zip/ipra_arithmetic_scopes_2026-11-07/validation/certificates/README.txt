INDEPENDENT CERTIFICATE VALIDATION
==================================

Run: python3 validate.py

Verified: all 147 inherited scalar and 55 inherited direct positive certificates
accept after mapping every strictly positive coordinate x to x+2. Zero and
negative coordinates and array shapes are preserved. The original packets are
first checked against their exact source checkers. These are fixture-specific
executable checks, not a claim that arbitrary proof-packet normalization preserves
instruction consumption.

A separate named-rule reference checker agrees with the candidate on 9,276
packet comparisons; all named expectations and 524 normal / python -O public
process checks pass. There are 800 independently evaluated true successor
equalities and 800 deliberately wrong computation results, plus 1,000 false
closed-equation targets. See results.json for exact counts and hashes.

The original source checkers in fixtures/ are unchanged. Both candidate files
are exact copies of the final submitted checker_scalar.py and checker_direct.py,
including the sub/test names, decision bit 1, and public I/O driver. The direct
version differs only by its stated two-stage 5-then-3 successor opening.
The reference treats unary major premises as lists only, matching the final
sequence matcher. A one-character string major is rejected, whereas the earlier
experimental length-based dispatcher could treat it as unary. This restriction
does not affect any translated canonical positive certificate. The random
population remains unchanged and includes one-, two-, and three-character
strings; no failing sample is discarded. No test helper is part of the
submitted proof acceptance boundary.

Finite tests do not establish the universal soundness, completeness, consistency,
or bi-interpretability theorem; those require the mathematical argument.
