"""Package the complete source, report, comparisons, and reproducible evidence."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OMIT_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc"}


def entries():
    return sorted(p for p in ROOT.rglob("*") if p.is_file()
                  and "__pycache__" not in p.parts
                  and p.suffix not in OMIT_SUFFIXES
                  and p.name != "MANIFEST.json")


def main():
    required = ["report.tex", "report.pdf", "checker_scalar.py", "checker_direct.py",
                "results/measurements.json", "results/pdf_qa.json",
                "validation/certificates/FINAL_SOURCE_RECEIPT.json",
                "validation/opening/results_scalar.json", "validation/opening/results_direct.json"]
    for name in required:
        if not (ROOT / name).is_file():
            raise SystemExit(f"Required deliverable missing: {name}")
    files = entries()
    manifest = {"package": ROOT.name, "source_commit": "fa69b78013baadf9a4e9d63ef1a57f56ca1eb017",
        "files": [{"path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size,
                   "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
    (ROOT / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    files.append(ROOT / "MANIFEST.json")
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in sorted(files):
            output.write(path, arcname=str(Path(ROOT.name) / path.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as source:
        if source.testzip() is not None:
            raise SystemExit("ZIP integrity check failed")
        for item in manifest["files"]:
            content = source.read(ROOT.name + "/" + item["path"])
            if hashlib.sha256(content).hexdigest() != item["sha256"]:
                raise SystemExit("ZIP manifest mismatch: " + item["path"])
    readable_pdf = ROOT.parent / (ROOT.name + ".pdf")
    shutil.copy2(ROOT / "report.pdf", readable_pdf)
    print(json.dumps({"zip": str(archive), "pdf": str(readable_pdf),
                      "files": len(files), "zip_bytes": archive.stat().st_size,
                      "zip_sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))


if __name__ == "__main__":
    main()
