"""Recompute the complete-source comparison against the pinned current corpus."""
import ast
import importlib.util
import json
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("inherited_measure", ROOT / "comparison/source_measure.py")
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")
DRIVER = """
try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
except:
    print('REJECT')
    sys.exit(1)
print('ACCEPT')
"""


def source_metrics(source):
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "source.py"
        path.write_text(source)
        return {k: v for k, v in measure.metrics(path).items() if k != "core"}


def measure_file(path):
    source = path.read_text()
    tree = ast.parse(source)
    core = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.Assign))]
    core_text = ast.unparse(ast.Module(body=core, type_ignores=[])) + "\n"
    entry = "test" if any(isinstance(n, ast.FunctionDef) and n.name == "test" for n in core) else "check"
    common = "import json, sys\n" + core_text + DRIVER.replace("check(", entry + "(")
    class CommonNames(ast.NodeTransformer):
        names = {"test": "check", "sub": "inst"}
        def visit_Name(self, node):
            node.id = self.names.get(node.id, node.id)
            return node
        def visit_FunctionDef(self, node):
            node.name = self.names.get(node.name, node.name)
            return self.generic_visit(node)
    common_names = ast.unparse(CommonNames().visit(ast.parse(common))) + "\n"
    return {
        "delivered": source_metrics(source),
        "common_stdin": source_metrics(common),
        "common_stdin_and_names": source_metrics(common_names),
        "definitions_only": source_metrics(core_text),
    }


def main():
    manifest = json.loads((ROOT / "comparison/manifest.json").read_text())
    baselines = []
    for item in manifest["programs"]:
        metrics = measure_file(ROOT / item["local_file"])
        assert metrics["delivered"]["sha256"] == item["sha256"]
        baselines.append({**item, **metrics})
    minima = {
        boundary: {field: min(row[boundary][field] for row in baselines) for field in FIELDS}
        for boundary in ("delivered", "common_stdin", "common_stdin_and_names", "definitions_only")
    }
    candidates = {name: measure_file(ROOT / name) for name in ("checker_scalar.py", "checker_direct.py")}
    result = {"commit": manifest["commit"], "archive_count": len(manifest["archives"]),
              "program_count": len(baselines), "coordinatewise_minima": minima,
              "candidates": candidates, "baselines": baselines}
    (ROOT / "results/measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = [r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
             r"Program or boundary & Tokens & AST nodes & Bytes\\", r"\midrule"]
    def row(label, values):
        return label + " & " + " & ".join(str(values[k]) for k in FIELDS) + r"\\"
    for boundary, label in (("delivered", "Current delivered minima"), ("common_stdin", "Current identical-driver minima")):
        lines.append(row(label, minima[boundary]))
    lines.append(r"\midrule")
    for filename, label in (("checker_scalar.py", "New scalar iterator"), ("checker_direct.py", "New direct recursor")):
        lines.append(row(label, candidates[filename]["delivered"]))
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (ROOT / "results/main_table.tex").write_text("\n".join(lines) + "\n")
    detail = [r"\begin{longtable}{@{}llrrr@{}}", r"\toprule",
              r"Draft & Root file & Tokens & AST & Bytes\\", r"\midrule\endhead"]
    for item in baselines:
        draft = item["archive"].removeprefix("ipra_").removesuffix("_2026-11-07.zip").replace("_", r"\_")
        name = Path(item["local_file"]).name.split("__", 1)[1].replace("_", r"\_")
        detail.append(draft + " & " + name + " & " + " & ".join(str(item["delivered"][k]) for k in FIELDS) + r"\\")
    detail.extend([r"\bottomrule", r"\end{longtable}"])
    (ROOT / "results/baseline_table.tex").write_text("\n".join(detail) + "\n")
    print(json.dumps({"minima": minima, "candidates": {name: {b: {k: m[b][k] for k in FIELDS} for b in m} for name, m in candidates.items()}}, indent=2))


if __name__ == "__main__":
    main()
