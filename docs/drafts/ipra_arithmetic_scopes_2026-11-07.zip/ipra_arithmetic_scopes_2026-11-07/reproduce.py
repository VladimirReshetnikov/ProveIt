"""Reproduce the checks, complete-source comparison, and report PDF."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(*arguments):
    subprocess.run([sys.executable, *map(str, arguments)], cwd=ROOT, check=True)


def main():
    receipt = json.loads((ROOT / "validation/certificates/FINAL_SOURCE_RECEIPT.json").read_text())
    for profile, expected in receipt["exact_final_checkers"].items():
        actual = hashlib.sha256((ROOT / f"checker_{profile}.py").read_bytes()).hexdigest()
        if actual != expected:
            raise SystemExit(f"Changed checker: {profile}")
    run(ROOT / "validation/certificates/validate.py")
    for profile in ("scalar", "direct"):
        run(ROOT / "validation/opening/validate_opening.py", ROOT / f"checker_{profile}.py",
            "--output", ROOT / f"validation/opening/results_{profile}.json")
    run(ROOT / "measure.py")
    run(ROOT / "build.py")
    print("All reproducible checks completed.")


if __name__ == "__main__":
    main()
