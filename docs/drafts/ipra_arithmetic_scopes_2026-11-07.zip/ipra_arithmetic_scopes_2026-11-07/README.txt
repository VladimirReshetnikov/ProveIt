ARITHMETIC SCOPE INCREMENTS FOR iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific time).

Start with report.pdf; report.tex and all included TeX fragments are its
complete source. Both standalone checkers are included. The scalar checker
is smaller; the direct checker gives a much shorter arithmetic equivalence
proof because predecessor is immediate.

RESULT
Current snapshot: fa69b78013baadf9a4e9d63ef1a57f56ca1eb017.
Six current draft archives, eleven complete root programs.
Actual delivered coordinate minima: 342 tokens / 364 AST nodes / 978 bytes.
New scalar: 334 / 356 / 964. New direct: 341 / 362 / 975.
With the same stdin driver: old minima 341 / 362 / 966; scalar 334 / 356 / 964;
direct 341 / 362 / 975. Bytes depend on helper names and return-value spelling;
see results/measurements.json for the additional common-name control.

The new representation reserves [0,3) for zero coordinates, making the
child-scope increments arity+1. Saturating arity at three admits checked
padding. The native two arithmetic computation schemas and five inference
patterns are inherited. The report gives them explicitly and includes
written soundness, completeness, and whole-domain bi-interpretability proofs.
This is a further representation reduction, not a global minimality theorem
or a claimed new arithmetic axiom basis.

RUN A CERTIFICATE
  python3 checker_scalar.py < examples/scalar_zero.json
  python3 checker_direct.py < examples/direct_counter.json

The input is one JSON list. The last cell is a closed goal. Earlier cells
are proof instructions, consumed from the end. ACCEPT has exit code 0;
REJECT has exit code 1. Unused prefix cells are inert. Use the matching
arithmetic profile. Python 3.10+ and its standard library suffice.

REPRODUCE
  python3 reproduce.py

This rechecks source receipts, reruns the independent certificate and opening
tests, recomputes the comparison, and rebuilds the PDF. LaTeX is needed only
for the final PDF build. See the validation READMEs for individual commands.
Resource limits can reject very large valid proofs, as in the supplied
baseline programs. The mathematical completeness claim is unbounded-resource.

CONTENTS
  report.tex, report.pdf        Full report and compiled PDF
  sections/, appendices/       Complete mathematical source
  checker_scalar.py            Smallest delivered decision program
  checker_direct.py            Direct-recursion companion
  examples/                    Accepted and deliberately rejected packets
  comparison/baselines/         Eleven unchanged current comparators
  comparison/manifest.json     Pinned archive/source provenance and hashes
  validation/certificates/     Independent rule-level verifier and tests
  validation/opening/          Independent sorted decoder and substitution tests
  results/                    Measurements, validation receipts, and audits
  measure.py, build.py,
    reproduce.py               Reproduction tools (not trusted by the checker)
  ATTRIBUTION.txt               New/inherited contribution boundary
  LICENSE-inherited.txt        License for inherited material

VALIDATION STATUS
All 147 scalar and 55 direct inherited positive certificates translate and
accept. Independent checking covers 9,276 packets and 524 public CLI runs,
plus 224,280 bounded openings and further semantic substitution populations.
There were zero failures. These are finite executable checks, not a Lean
or Rocq proof of the universal metatheorems.
