CURRENT SNAPSHOT COMPARISON

Run the root command:
  python3 measure.py

baselines/ contains exactly eleven unchanged root checker files from the
six current archives at commit fa69b78013baadf9a4e9d63ef1a57f56ca1eb017.
manifest.json records their archive members and byte hashes.

source_measure.py is retained unchanged as an inherited measurement source.
Only its metrics() function is imported by the root measurement command.
Its historical standalone main() expects the old archive's manifest layout
and is not an entry point for this package. The root measure.py provides
the current traversal and the explicit common-driver/common-name controls.

The existing normalizer strips genuine docstrings and normalizes Python
source with ast.unparse. It does not normalize identifier spelling. The
root command therefore separately records common helper names.
