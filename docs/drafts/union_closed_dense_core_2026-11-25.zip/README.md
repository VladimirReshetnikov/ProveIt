# Three omitted generators suffice

Start with `paper.pdf` (complete elementary proofs); `paper.tex` is its self-contained source.

Main result: if a core has any point belonging to all but at most three of its generators, one or two fixed core points have mean frequency at least one half in every translate of the core. This implies Frankl's conclusion for arbitrarily many exceptional generators together with any number of private generators. The tagged-family generalization, sharp one- and two-point frequency bounds, exact bad-quartet criterion, and four-omission obstruction are also proved.

The general conjecture is not proved. These are proposed original extensions, not a certified priority claim. The proof does not use numerical entropy bounds or a finite search as a premise.

## Reproduce

- `python3 verify.py > verification.json` — Python 3.10+, standard library, assertions enabled. Checks all 32,902 nonempty type collections on one through four labels, including 5,981,137 retained-witness erasures, plus larger seeded models and exact extremizers.
- `pdflatex -interaction=nonstopmode -halt-on-error paper.tex` twice — standard TeX Live, no external files or network.
- `sha256sum -c SHA256SUMS` — check the delivered artifacts before modifying them.

`provenance.md` records repository and literature comparisons. The code is supplemental finite verification, not Lean/Rocq formalization or independent human review. No repository changes were made.
