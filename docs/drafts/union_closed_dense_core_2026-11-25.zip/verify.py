#!/usr/bin/env python3
"""Exact finite audits for the dense-core theorems. Python 3.10+, stdlib.
The general results are proved in paper.tex; this is not a formal proof.
"""
from itertools import combinations
from random import Random
from collections import Counter
import json


def subsets(mask):
    sub = mask
    while True:
        yield sub
        if sub == 0:
            return
        sub = (sub - 1) & mask


def closure(H, top):
    C = {top}
    for T in H:
        C |= {D & T for D in C}
    return C


def direct_rows(H, top):
    # A row records omitted point types, not generator representations.
    H = tuple(sorted(H))
    return {sum(1 << j for j,T in enumerate(H) if I & ~T == 0)
            for I in subsets(top)}


def minimal(H):
    return [T for T in sorted(H) if not any(S != T and S & ~T == 0 for S in H)]


def misses(C,T):
    return sum(D & ~T == 0 for D in C)


def witness(H):
    M = minimal(H)
    if len(M) == 1:
        return tuple(M)
    for T,S in combinations(M,2):
        if (T&S).bit_count() <= 1:
            return T,S
    T = min(M,key=lambda x:(x.bit_count(),x))
    if T.bit_count() <= 3:
        return T,next(S for S in M if S!=T)
    return None


def quartet(H,T,S):
    R=T&S
    assert R.bit_count()==2
    return any((A&R).bit_count()==1 and (B&R).bit_count()==1 and
               (A&R)!=(B&R) and ((A&B)&~T==0 or (A&B)&~S==0)
               for A,B in combinations(set(H)-{T,S},2))


def verify_model(H,top,C,stats,check_rows=True):
    N=len(C)
    M=minimal(H)
    if check_rows:
        rows=direct_rows(H,top)
        assert len(rows)==N
        for j,T in enumerate(sorted(H)):
            assert sum(bool(row & (1<<j)) for row in rows)==misses(C,T)
        stats['direct_row_models']+=1
    for T in M:
        r=T.bit_count(); a=misses(C,T)
        assert (N-a)*((1<<r)+r+1)>=N*(r+1)
        stats['marked_bounds']+=1
    for T,S in combinations(M,2):
        t=(T&S).bit_count(); a=misses(C,T)+misses(C,S)
        assert (2*N-a)*((1<<t)+t+3)>=2*N*(t+2)
        stats['pair_bounds']+=1
        if t==2:
            assert (a>N)==(len(H)==4 and quartet(H,T,S))
            stats['overlap_two_failure_checks']+=1
    w=witness(H)
    if w:
        assert 2*sum(N-misses(C,T) for T in w)>=len(w)*N
        stats['certificate_models']+=1
    return w


def exhaustive(k):
    top=(1<<k)-1
    # Family of types H encoded by one bit per proper subset T of [k].
    limit=1<<top
    down=[sum(1<<D for D in subsets(T)) for T in range(top+1)]
    Cs=[1<<top]*limit
    stats=Counter()
    for mask in range(1,limit):
        bit=mask&-mask; T=bit.bit_length()-1
        prev=Cs[mask^bit]
        C=prev
        # Exact intersection closure from the previous model.
        for D in range(top+1):
            if prev>>D&1: C|=1<<(D&T)
        Cs[mask]=C
        H={T for T in range(top) if mask>>T&1}
        assert C==sum(1<<D for D in closure(H,top))
        w=verify_model(H,top,{D for D in range(top+1) if C>>D&1},stats)
        assert w is not None # k<=4, every proper subset has size <=3
        W=sum(1<<T for T in w)
        # It suffices to test all erasures retaining the selected witness(es).
        # If any selected point is erased it is forced present, and a pair's
        # mean is automatically >=1/2; for a singleton it is then 1.
        for sub in subsets(mask^W):
            c=Cs[sub|W] # sub|W <= mask, so already computed
            N=c.bit_count()
            a=sum((c&down[T]).bit_count() for T in w)
            assert 2*a<=len(w)*N
            stats['retaining_erasures']+=1
        stats['models']+=1
        # All omitted-witness cases follow from nonnegativity without lookup.
        stats['automatic_erasures']+=(1<<len(H))-(1<<(len(H)-len(w)))
    return dict(stats)


def random_models():
    rng=Random(20261125); stats=Counter()
    for k in range(5,13):
        top=(1<<k)-1
        for i in range(200):
            # Force a complement of size <=3, also explore unrestricted pairs.
            H=set(rng.sample(range(top),rng.randint(1,min(24,top))))
            if i%2==0:
                H.add(sum(1<<j for j in rng.sample(range(k),rng.randrange(4))))
            C=closure(H,top)
            w=verify_model(H,top,C,stats,check_rows=(i<10))
            if w:
                for _ in range(12):
                    sub={T for T in H if rng.randrange(2)}
                    D=closure(sub,top); N=len(D)
                    a=sum(misses(D,T) for T in w if T in sub)
                    assert 2*a<=len(w)*N
                    stats['random_erasures']+=1
            for T,S in combinations(minimal(H),2):
                if (T&S).bit_count()!=2: continue
                # Explicitly test every candidate bad quartet.
                bad=quartet(H,T,S)
                found=False
                for A,B in combinations(H-{T,S},2):
                    Q={T,S,A,B}; D=closure(Q,top)
                    if misses(D,T)+misses(D,S)>len(D): found=True
                assert bad==found
                stats['quartet_criterion_checks']+=1
            stats['models']+=1
    return dict(stats)


def sharpness():
    ans=[]
    for r in range(2,11):
        R=(1<<r)-1; top=(1<<(2*r))-1
        H={R}|{(R^(1<<i))|(1<<(r+i)) for i in range(r)}
        C=closure(H,top); N=len(C)
        assert N==(1<<r)+r+1 and misses(C,R)==1<<r
        assert R in minimal(H)
        # Pair example has two exclusive marked labels and r fresh labels.
        T=R|(1<<r); S=R|(1<<(r+1)); top=(1<<(2*r+2))-1
        H2={T,S}|{(R^(1<<i))|(1<<(r+2+i)) for i in range(r)}
        C2=closure(H2,top); N2=len(C2)
        assert T in minimal(H2) and S in minimal(H2)
        assert N2==(1<<r)+r+3
        assert misses(C2,T)==misses(C2,S)==(1<<r)+1
        ans.append({'r_or_t':r,'marked_count':N,'marked_present':N-(1<<r),
                    'pair_count':N2,'each_pair_present':N2-(1<<r)-1})
    return ans


def four_omission_obstruction():
    top=63
    H={sum(1<<i for i in I) for I in combinations(range(6),4)}
    bad_singletons=set(); total=0; pairs_by_overlap=Counter()
    for T,S in combinations(sorted(H),2):
        candidates=[]
        for A,B in combinations(H-{T,S},2):
            C=closure({T,S,A,B},top); N=len(C)
            a,b=misses(C,T),misses(C,S)
            if a+b>N:
                candidates.append((2*a-N,2*b-N))
                if 2*a>N: bad_singletons.add(T)
                if 2*b>N: bad_singletons.add(S)
        assert candidates
        # Exchanging T and S by a permutation of labels leaves H invariant.
        # Test the reversed deficits explicitly as well.
        assert all((v,u) in candidates for u,v in candidates)
        pairs_by_overlap[(T&S).bit_count()]+=1
        total+=len(candidates)
    assert bad_singletons==H
    return {'types':len(H),'pairs_obstructed':sum(pairs_by_overlap.values()),
            'by_overlap':dict(pairs_by_overlap),'bad_quartets_counted_per_marked_pair':total,
            'singletons_obstructed':len(bad_singletons)}


def actual_tagged_example():
    k=7; m=5
    cols=list(combinations(range(k),3))
    B=[sum(1<<j for j,T in enumerate(cols) if i not in T) for i in range(k)]
    G=[7|(1<<(len(cols)+i)) for i in range(m)]
    F={0}
    for A in B+G: F|={U|A for U in F}
    assert len(F)>50 and min(U.bit_count() for U in F if U)>3
    for A in B:
        assert not any(U and U!=A and U&~A==0 for U in F)
        assert all(sum(bool(C&(1<<j)) for C in B)>=2 for j in range(len(cols)) if A>>j&1)
    sig=[sum(1<<i for i,A in enumerate(B+G) if A>>j&1) for j in range(len(cols)+m)]
    assert len(sig)==len(set(sig))
    freqs=[sum(bool(A>>j&1) for A in F) for j in range(len(cols)+m)]
    return {'core_generators':k,'private_generators':m,'points':len(cols)+m,
            'members':len(F),'minimum_nonempty_size':min(U.bit_count() for U in F if U),
            'max_frequency_count':max(freqs),'tag_counts':freqs[len(cols):]}


def main():
    result={'exhaustive':{str(k):exhaustive(k) for k in range(1,5)},
            'random':random_models(),'sharp_examples':sharpness(),
            'tagged_example':actual_tagged_example(),
            'four_omission_obstruction':four_omission_obstruction(),
            'status':'PASS; exact integer checks, not an exhaustive check for unbounded sizes'}
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
