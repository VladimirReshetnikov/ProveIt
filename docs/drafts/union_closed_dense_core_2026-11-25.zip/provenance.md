# Repository and literature provenance

Date: 2026-11-25 (America/Los_Angeles).

## Repository inspection

The GitHub connector listed the main-branch directory:
https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts

Directly relevant full source inspected: `private-generators.tex` in
`union_closed_three_results.zip`, Git blob `f04bbb142b4ba9b169463a845906a560829c0423`.
It proves the at-most-five-exceptional-generator result by a common average of
maximum-support types, partitioning by private generators. Its six-generator
example refutes that particular choice of maximum-support certificate, and
its last paragraph proposes different weights for six or more generators.
The new paper uses the partition but proves a different, unbounded criterion
with a fixed certificate of support at most two, and gives a sharp limit to
that support-size approach.

README summaries and/or TeX file inventories were retrieved from the following
archives (some displayed summaries were truncated; the full mathematical
contents were not all audited):

- union-closed-abundance.zip
- union-closed-results.zip
- union_closed_abundance.zip
- union_closed_abundance_theorems.zip
- union_closed_advances_2026-11-25.zip
- union_closed_entropy_2026_11_25.zip
- union_closed_entropy_research_2026-11-25.zip
- union_closed_extensions_2026-11-25(1).zip
- union_closed_extensions_2026-11-25.zip
- union_closed_frequency_bounds.zip
- union_closed_joint_laws_2026-11-25.zip
- union_closed_local_abundance.zip
- union_closed_marked_abundance.zip
- union_closed_partial_results.zip
- union_closed_partial_theorems_2026-11-25.zip
- union_closed_refinements_2026-11-25.zip
- union_closed_three_results.zip

The remaining listed archive, `union_closed_structural_theorems.zip` (blob
`bba38e6abe6445578e551dfc16f678f4fdb4fa56`), returned zero bytes from the
connector, so its contents could not be inspected. Direct raw GitHub access
from the execution environment was unavailable. No repository files were changed.

## Literature search

Queries included combinations of `union closed sets conjecture`, `all but three`,
`all but two`, `private generators`, `transversal`, `maximal supports`,
`meet irreducible`, `minimal principal ideals`, and `Frankl`. Relevant sources:

- Bruhn and Schaudt, survey: https://arxiv.org/abs/1309.3297
- Poonen, Union-closed families: https://doi.org/10.1016/0097-3165(92)90068-6
- Bruhn, Charbit, Schaudt and Telle, graph formulation: https://arxiv.org/abs/1212.4175
- Wikipedia, general context and known cases: https://en.wikipedia.org/wiki/Union-closed_sets_conjecture

The familiar singleton/doubleton, small-family, lattice and graph results and
Poonen's weight criterion are not claimed as original. The searches did not
locate the exact erasure-robust three-omission criterion, the two sharp envelopes,
or the bad-quartet and four-omission support-size results in the form proved here.
This is a bounded comparison, not a systematic review of every paper or every
repository draft. Novelty is provisional. No claim is made to improve the
unrestricted entropy constant or to solve the full conjecture.
