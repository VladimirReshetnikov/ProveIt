"""Finite diagnostics for the open closed-unary shifted-iteration candidate.

This is an evaluator of its standard interpretation, not a proof checker.
The whole-domain identities are proved in sections/07_unary_shift.tex.
"""

from functools import lru_cache
import json


ZERO = ("zero",)
VAR = ("var",)


def K(update, count, initializer):
    return ("K", update, count, initializer)


def compose(term, argument):
    """Substitute for the ambient input; closed update indices stay fixed."""
    if term == ZERO:
        return ZERO
    if term == VAR:
        return argument
    _, update, count, initializer = term
    return K(update, compose(count, argument), compose(initializer, argument))


@lru_cache(maxsize=None)
def value(term, x):
    if term == ZERO:
        return 0
    if term == VAR:
        return x
    _, update, count, initializer = term
    n = value(count, x)
    a = value(initializer, x) + 1
    for _ in range(n):
        a = value(update, a)
    return a


SIGMA = K(VAR, ZERO, VAR)
Z = K(ZERO, VAR, ZERO)
W = K(Z, VAR, ZERO)
O = compose(Z, W)
H = K(ZERO, O, SIGMA)
Q = K(H, VAR, ZERO)
D = compose(Q, SIGMA)
J = compose(Z, Q)


def conjunction(a, b):
    state = b + 1
    for _ in range(a):
        state = value(J, state)
    return value(Z, state)


def run():
    checked = 129
    for n in range(checked):
        assert value(D, n) == 2 * n
        assert value(J, n) == int(n == 1)
        assert value(J, n + 1) == value(Z, n)
        assert value(O, n + 2) == value(O, n)
        assert value(O, value(D, n)) == 0
    truth_table = []
    for a in (0, 1):
        for b in (0, 1):
            result = conjunction(a, b)
            assert result == a * b
            truth_table.append({"a": a, "b": b, "value": result})
    return {
        "status": "finite_diagnostics_passed",
        "scope": "Standard natural-number evaluation only; no completeness or minimality claim.",
        "checked_inputs": {"first": 0, "last": checked - 1},
        "q_prefix": [value(Q, n) for n in range(12)],
        "D_prefix": [value(D, n) for n in range(12)],
        "J_prefix": [value(J, n) for n in range(12)],
        "conjunction_truth_table": truth_table,
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
