"""Shared finite syntax operations; no theorem prover or semantic oracle."""
from __future__ import annotations

import re

BUILTINS = {"C": 3, "pair": 2, "left": 1, "right": 1, "pred": 1}
NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def name_ok(name):
    return isinstance(name, str) and NAME.fullmatch(name) is not None


def check_signature(signature):
    require(isinstance(signature, dict), "signature must be an object")
    for name, arity in signature.items():
        require(name_ok(name) and name not in BUILTINS, "bad or reserved symbol")
        require(type(arity) is int and arity >= 0, "arity must be natural")


def var(name):
    return {"v": name}


def num(value):
    return {"n": value}


def app(name, *args):
    return {"f": name, "a": list(args)}


def once(initial, binder, body):
    """The actual scalar term I(1, initial; binder.body), not a new let node."""
    return {"I": [num(1), initial, binder, body]}


def check_term(term, signature):
    require(isinstance(term, dict), "term must be an object")
    if set(term) == {"v"}:
        require(name_ok(term["v"]), "invalid variable")
    elif set(term) == {"n"}:
        require(type(term["n"]) is int and term["n"] >= 0, "bad numeral")
    else:
        require(set(term) == {"f", "a"}, "bad numerical term")
        arities = BUILTINS | signature
        require(isinstance(term["f"], str) and term["f"] in arities,
                "unknown numerical symbol")
        require(isinstance(term["a"], list)
                and len(term["a"]) == arities[term["f"]], "wrong arity")
        for child in term["a"]:
            check_term(child, signature)


def term_vars(term):
    if "v" in term:
        return {term["v"]}
    if "n" in term:
        return set()
    if "I" in term:
        count, initial, binder, body = term["I"]
        return term_vars(count) | term_vars(initial) | (term_vars(body) - {binder})
    return set().union(*(term_vars(x) for x in term["a"]))


def substitute(term, replacements):
    """Simultaneous substitution in numerical terms (terms have no binders)."""
    if "v" in term:
        return replacements.get(term["v"], term)
    if "n" in term:
        return term
    return app(term["f"], *(substitute(x, replacements) for x in term["a"]))


def check_source(formula, signature):
    require(isinstance(formula, dict) and len(formula) == 1, "bad formula")
    tag, data = next(iter(formula.items()))
    if tag == "zero":
        check_term(data, signature)
    elif tag in {"and", "or"}:
        require(isinstance(data, list) and len(data) == 2, "binary connective")
        for child in data:
            check_source(child, signature)
    elif tag in {"exists", "forall"}:
        require(isinstance(data, list) and len(data) == 2 and name_ok(data[0]),
                "bad numerical quantifier")
        check_source(data[1], signature)
    else:
        raise ValueError("unsupported source connective: " + tag)


def formula_vars(formula, free=True):
    tag, data = next(iter(formula.items()))
    if tag == "zero":
        return term_vars(data)
    if tag in {"and", "or"}:
        return formula_vars(data[0], free) | formula_vars(data[1], free)
    found = formula_vars(data[1], free)
    return found - {data[0]} if free else found | {data[0]}


def check_normal(normal, signature):
    require(isinstance(normal, dict) and set(normal) == {"e", "a", "r"},
            "bad prenex normal form")
    require(isinstance(normal["e"], list) and isinstance(normal["a"], list),
            "quantifier prefixes must be lists")
    names = normal["e"] + normal["a"]
    require(all(name_ok(x) for x in names) and len(names) == len(set(names)),
            "repeated or invalid bound variable")
    check_term(normal["r"], signature)


def normal_free(normal):
    return term_vars(normal["r"]) - set(normal["e"] + normal["a"])


def normal_all(normal):
    return term_vars(normal["r"]) | set(normal["e"] + normal["a"])


def balanced_projection(code, length, index):
    """Projection from a balanced binary pairing of a nonempty finite tuple."""
    require(0 <= index < length, "projection index out of bounds")
    if length == 1:
        return code
    split = length // 2
    if index < split:
        return balanced_projection(app("left", code), split, index)
    return balanced_projection(app("right", code), length - split, index - split)


def term_nodes(term):
    if "I" in term:
        count, initial, _, body = term["I"]
        return 1 + term_nodes(count) + term_nodes(initial) + term_nodes(body)
    return 1 if "f" not in term else 1 + sum(term_nodes(x) for x in term["a"])


def source_nodes(formula):
    tag, data = next(iter(formula.items()))
    if tag == "zero":
        return 1 + term_nodes(data)
    if tag in {"and", "or"}:
        return 1 + sum(source_nodes(x) for x in data)
    return 1 + source_nodes(data[1])


def native_nodes(formula):
    if "eq" in formula:
        return 1 + sum(term_nodes(x) for x in formula["eq"])
    return 1 + native_nodes(formula["D"][2])


class Fresh:
    def __init__(self, used):
        self.used = set(used)
        self.next = 0

    def take(self, prefix="_v"):
        while True:
            candidate = prefix + str(self.next)
            self.next += 1
            if candidate not in self.used:
                self.used.add(candidate)
                return candidate
