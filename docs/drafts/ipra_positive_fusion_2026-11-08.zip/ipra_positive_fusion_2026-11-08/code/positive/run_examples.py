"""Reproduce structural certificates, targeted rejection tests and diagnostics."""
from __future__ import annotations

from copy import deepcopy
from itertools import product
from math import isqrt, log2
from pathlib import Path
import json

from compile_positive import compile_certificate
from verify_positive import verify
from syntax import (app, balanced_projection, formula_vars, native_nodes, num,
                    source_nodes, term_nodes, var)

HERE = Path(__file__).resolve().parent
SIGNATURE = {"eq_characteristic": 2, "lt_characteristic": 2,
             "even_characteristic": 1, "add": 2}

# These supplied numerical functions are fixed primitive-recursive functions.
# Their zero-sets define the source leaves; they are not propositional oracles.
FUNCTIONS = {
    "eq_characteristic": lambda x, y: int(x != y),
    "lt_characteristic": lambda x, y: int(not x < y),
    "even_characteristic": lambda x: x % 2,
    "add": lambda x, y: x + y,
}


def atom(name, *arguments):
    return {"zero": app(name, *arguments)}


def exists(name, body):
    return {"exists": [name, body]}


def forall(name, body):
    return {"forall": [name, body]}


def conj(left, right):
    return {"and": [left, right]}


def disj(left, right):
    return {"or": [left, right]}


def eq(left, right):
    return atom("eq_characteristic", left, right)


def sigma2(x="x", y="y", parameter="a"):
    return exists(x, forall(y, atom("lt_characteristic", var(y),
                                    app("add", var(x), var(parameter)))))


def eval_term(term, environment):
    if "n" in term:
        return term["n"]
    if "v" in term:
        return environment[term["v"]]
    name = term["f"]
    values = [eval_term(t, environment) for t in term["a"]]
    if name == "C":
        return values[1] if values[0] == 0 else values[2]
    if name == "pred":
        return max(0, values[0] - 1)
    if name == "pair":
        x, y = values
        return (x + y) * (x + y + 1) // 2 + y
    if name in {"left", "right"}:
        n = values[0]
        diagonal = (isqrt(8 * n + 1) - 1) // 2
        right = n - diagonal * (diagonal + 1) // 2
        return diagonal - right if name == "left" else right
    return FUNCTIONS[name](*values)


def eval_source(formula, environment, domain):
    tag, data = next(iter(formula.items()))
    if tag == "zero":
        return eval_term(data, environment) == 0
    if tag == "and":
        return (eval_source(data[0], environment, domain)
                and eval_source(data[1], environment, domain))
    if tag == "or":
        return (eval_source(data[0], environment, domain)
                or eval_source(data[1], environment, domain))
    name, body = data
    values = (eval_source(body, environment | {name: value}, domain) for value in domain)
    return any(values) if tag == "exists" else all(values)


def eval_normal(normal, environment, domain):
    def all_values(existential_values):
        base = environment | dict(zip(normal["e"], existential_values))
        return all(eval_term(normal["r"], base | dict(zip(normal["a"], values))) == 0
                   for values in product(domain, repeat=len(normal["a"])))
    return any(all_values(values) for values in product(domain, repeat=len(normal["e"])))


def rejected(call):
    try:
        call()
    except (ValueError, TypeError, KeyError, IndexError):
        return True
    return False


def examples():
    a, b, x = var("a"), var("b"), var("x")
    return {
        "zero_true": {"zero": num(0)},
        "zero_false": {"zero": num(1)},
        "ground_conjunction": conj(eq(a, b), atom("even_characteristic", a)),
        "ground_disjunction": disj(eq(a, b), atom("even_characteristic", b)),
        "existential_equation": exists("x", eq(x, a)),
        "universal_equation": forall("y", atom("lt_characteristic", var("y"), a)),
        "sigma2_block": sigma2(),
        "two_universals": forall("u", forall("v", eq(var("u"), var("v")))),
        "nested_existentials": exists("x", exists("y", eq(x, var("y")))),
        "unused_existential": exists("unused", {"zero": num(0)}),
        "universal_disjunction_needs_tag": disj(
            forall("u", eq(var("u"), a)), forall("v", eq(var("v"), b))),
        "same_spelling_in_siblings": disj(sigma2(), sigma2()),
        "free_bound_capture_trap": conj(exists("x", eq(x, a)), eq(x, b)),
        "shadowing": exists("x", conj(eq(x, a), exists("x", eq(x, b)))),
        "generated_name_collision": exists("x", eq(x, var("_b0"))),
        "positive_cluster": exists("z", conj(
            sigma2("x", "y", "z"),
            disj(sigma2("u", "v", "z"), sigma2("p", "q", "a")))),
    }


def main():
    output = HERE / "examples"
    output.mkdir(exist_ok=True)
    accepted = []
    certificates = {}
    diagnostic_comparisons = 0
    for name, source in examples().items():
        certificate = compile_certificate(source, SIGNATURE)
        receipt = verify(certificate)
        certificates[name] = certificate
        (output / (name + ".json")).write_text(
            json.dumps(certificate, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        for size in (2, 3):
            domain = tuple(range(size))
            free = sorted(formula_vars(source))
            for values in product(domain, repeat=len(free)):
                environment = dict(zip(free, values))
                assert eval_source(source, environment, domain) == eval_normal(
                    certificate["normal"], environment, domain), name
                diagnostic_comparisons += 1
        accepted.append({"name": name, **receipt,
                         "source_nodes": source_nodes(source),
                         "native_nodes": native_nodes(certificate["native"]),
                         "native_linear_nodes": native_nodes(certificate["native_linear"])})

    invalid_sources = {
        "forall_exists": forall("x", exists("y", eq(var("x"), var("y")))),
        "implication": {"implies": [eq(num(0), num(0)), eq(num(0), num(1))]},
        "forall_positive_body": forall("x", conj(eq(var("x"), num(0)),
                                                   eq(var("x"), num(1)))),
        "wrong_arity": {"zero": app("eq_characteristic", num(0))},
        "boolean_is_not_numeral": {"zero": {"n": True}},
        "invalid_variable": exists("not a name", {"zero": num(0)}),
    }
    invalid_receipts = []
    for name, source in invalid_sources.items():
        assert rejected(lambda: compile_certificate(source, SIGNATURE)), name
        invalid_receipts.append(name)

    mutations = []
    for name, original in certificates.items():
        altered = deepcopy(original)
        altered["derivation"]["result"]["r"] = num(7)
        assert rejected(lambda: verify(altered)), "altered schema: " + name
        mutations.append("altered_schema_" + name)
    altered = deepcopy(certificates["sigma2_block"])
    altered["native"]["D"][2]["eq"][0]["a"][0] = num(0)
    assert rejected(lambda: verify(altered))
    mutations.append("erased_native_gate")
    altered = deepcopy(certificates["sigma2_block"])
    altered["native"]["D"][0] = "a"
    assert rejected(lambda: verify(altered))
    mutations.append("captured_native_parameter")
    altered = deepcopy(certificates["free_bound_capture_trap"])
    altered["alpha"]["and"][0]["exists"][0] = "x"
    assert rejected(lambda: verify(altered))
    mutations.append("capturing_alpha_conversion")
    altered = deepcopy(certificates["universal_disjunction_needs_tag"])
    altered["derivation"]["selector"] = "a"
    assert rejected(lambda: verify(altered))
    mutations.append("nonfresh_disjunction_selector")
    altered = deepcopy(certificates["sigma2_block"])
    altered["normal"]["a"] = []
    assert rejected(lambda: verify(altered))
    mutations.append("deleted_universal_prefix")
    altered = deepcopy(certificates["sigma2_block"])
    altered["native_linear"]["D"][2]["eq"][0]["a"][2]["I"][0] = num(0)
    assert rejected(lambda: verify(altered))
    mutations.append("zero_step_instead_of_beta")
    altered = deepcopy(certificates["sigma2_block"])
    altered["native_linear"]["D"][2]["eq"][0]["a"][2]["I"][2] = "a"
    assert rejected(lambda: verify(altered))
    mutations.append("capturing_scalar_binder")
    altered = deepcopy(certificates["sigma2_block"])
    altered["native_linear"]["D"][2]["eq"][0]["a"][2]["I"][1] = num(7)
    assert rejected(lambda: verify(altered))
    mutations.append("wrong_tuple_decoder_seed")
    altered = deepcopy(certificates["unused_existential"])
    altered["native_linear"]["D"][2]["eq"][0]["a"][2]["I"][1] = var("extra_free")
    assert rejected(lambda: verify(altered))
    mutations.append("free_parameter_hidden_by_unused_beta")

    # Python equality aliases bool/int and float/int: validate every supplied
    # syntax field before comparing it to an expected term or formula.
    for label, value in (("boolean", True), ("float", 1.0)):
        altered = deepcopy(certificates["sigma2_block"])
        altered["native_linear"]["D"][2]["eq"][0]["a"][2]["I"][0] = {"n": value}
        assert rejected(lambda: verify(altered))
        mutations.append(label + "_iterator_count_alias")
    for output_name in ("native", "native_linear"):
        for label, value in (("boolean", False), ("float", 0.0)):
            altered = deepcopy(certificates["sigma2_block"])
            altered[output_name]["D"][2]["eq"][1] = {"n": value}
            assert rejected(lambda: verify(altered))
            mutations.append(label + "_" + output_name + "_rhs_alias")
    for label, value in (("boolean", False), ("float", 0.0)):
        altered = deepcopy(certificates["zero_true"])
        altered["normal"]["r"] = {"n": value}
        assert rejected(lambda: verify(altered))
        mutations.append(label + "_top_level_normal_alias")
    altered = deepcopy(certificates["zero_true"])
    altered["derivation"]["source"]["zero"] = {"n": False}
    assert rejected(lambda: verify(altered))
    mutations.append("boolean_certificate_node_source_alias")
    altered = deepcopy(certificates["sigma2_block"])
    altered["native"]["D"][2]["extra"] = num(0)
    assert rejected(lambda: verify(altered))
    mutations.append("foreign_native_equation_field")
    altered = deepcopy(certificates["sigma2_block"])
    altered["native_linear"]["D"][2]["eq"][0]["a"][2]["I"][0]["extra"] = 0
    assert rejected(lambda: verify(altered))
    mutations.append("foreign_iterator_count_field")
    altered = deepcopy(certificates["sigma2_block"])
    altered["normal"]["extra"] = 0
    assert rejected(lambda: verify(altered))
    mutations.append("foreign_normal_form_field")
    altered = deepcopy(certificates["sigma2_block"])
    altered["native_linear"]["D"][2]["eq"][0]["a"][2]["extra"] = 0
    assert rejected(lambda: verify(altered))
    mutations.append("foreign_linear_term_field")

    # Balanced-codec syntax bound, checked over many finite tuple lengths.
    for length in range(1, 129):
        bound = (length - 1).bit_length()
        for index in range(length):
            projection = balanced_projection(var("w"), length, index)
            assert term_nodes(projection) - 1 <= bound

    families = []
    for connective in ("and", "or"):
        for count in (1, 2, 4, 8, 16, 32, 64):
            source = sigma2()
            for _ in range(1, count):
                source = {connective: [source, sigma2()]}
            certificate = compile_certificate(source, SIGNATURE)
            result = verify(certificate)
            total = source_nodes(source)
            size = native_nodes(certificate["native"])
            linear_size = native_nodes(certificate["native_linear"])
            families.append({"connective": connective, "blocks": count,
                             "source_nodes": total, "native_nodes": size,
                             "native_linear_nodes": linear_size,
                             "linear_nodes_over_N": round(linear_size / total, 6),
                             "one_step_scalar_bindings": result["one_step_scalar_bindings"],
                             "native_depth": result["native_depth"],
                             "nodes_over_N_log2_N": round(size / (total * log2(max(2, total))), 6)})

    receipt = {
        "accepted_certificates": len(accepted),
        "examples": accepted,
        "rejected_source_cases": invalid_receipts,
        "rejected_mutations": mutations,
        "finite_prenex_semantic_comparisons": diagnostic_comparisons,
        "projection_length_tests": 128 * 129 // 2,
        "size_families": families,
        "verification_boundary": [
            "The independent verifier checks finite applications of the stated proof schemas, alpha conversion and freshness.",
            "The written mathematical proof supplies universal soundness of these schemas; no Lean or Rocq formalization is claimed.",
            "Source leaves are explicit equations r(args)=0 for supplied fixed primitive-recursive numerical functions.",
            "Signature declarations name fixed PR functions; this verifier does not prove their primitive recursivity.",
            "Finite-domain diagnostics concern only source-versus-prenex formulas, never native pairing semantics.",
            "The one-D constructor relies on inherited pairing projection equations, predecessor equations, selector endpoints and numerical coverage.",
            "The linear native output decodes each tuple once with actual parameterized I(1,a;u.h) terms; every beta erasure is independently checked.",
            "Size counts use tree nodes and fixed numerical operation symbols; literal scalar expansion needs the report's fixed-definition or linear-wrapper accounting.",
            "The numerical-let lowering uses parameterized scalar updates and is not asserted to preserve the closed-update grammar.",
            "This is a formula compiler, not a complete iPRA proof checker and not a reduction of kernel size."
        ]
    }
    (HERE / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in receipt.items()
                      if key not in {"examples", "size_families", "verification_boundary"}}, indent=2))


if __name__ == "__main__":
    main()
