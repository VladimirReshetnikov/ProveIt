"""Verify the finite proof schemas emitted by compile_positive.py.

No producer code is imported. Shared syntax.py performs finite syntax
validation and simultaneous numerical substitution, not logical inference.
"""
from __future__ import annotations

import argparse
import json

from syntax import (BUILTINS, app, balanced_projection, check_normal, check_signature,
                    check_source, check_term, formula_vars, name_ok, normal_all,
                    normal_free, num, require, substitute, term_vars, var)


def verify_alpha(source, target):
    """Check alpha equivalence with globally fresh, pairwise distinct binders."""
    free = formula_vars(source)
    used = set()

    def walk(a, b, environment):
        require(set(a) == set(b), "alpha conversion changed a connective")
        tag, data = next(iter(a.items()))
        other = b[tag]
        if tag == "zero":
            expected = substitute(data, {x: var(y) for x, y in environment.items()})
            require(expected == other, "alpha conversion changed a numerical term")
        elif tag in {"and", "or"}:
            walk(data[0], other[0], environment)
            walk(data[1], other[1], environment)
        else:
            old, body = data
            new, body2 = other
            require(new not in free and new not in used, "capturing or repeated binder")
            used.add(new)
            walk(body, body2, environment | {old: new})

    walk(source, target, {})
    return used


def verify_node(node, source, signature, all_source_names, selectors):
    require(isinstance(node, dict), "certificate node must be an object")
    rule = node.get("rule")
    allowed = {"rule", "source", "result", "children"}
    if rule == "or_tagged":
        allowed.add("selector")
    require(set(node) == allowed, "wrong certificate fields")
    check_source(node["source"], signature)
    require(node["source"] == source, "certificate source mismatch")
    require(isinstance(node["children"], list), "children must be a list")
    result = node["result"]
    check_normal(result, signature)
    tag, data = next(iter(source.items()))
    children = node["children"]

    if rule == "zero":
        require(tag == "zero" and children == [], "bad zero-test rule")
        expected = {"e": [], "a": [], "r": data}
    elif rule == "forall_block":
        require(tag == "forall" and children == [], "bad universal-block rule")
        names, body = [], source
        while "forall" in body:
            name, body = body["forall"]
            names.append(name)
        require("zero" in body, "unlicensed universal quantifier shift")
        expected = {"e": [], "a": names, "r": body["zero"]}
    elif rule == "exists":
        require(tag == "exists" and len(children) == 1, "bad existential rule")
        name, body = data
        q = verify_node(children[0], body, signature, all_source_names, selectors)
        require(name not in q["e"] + q["a"], "repeated existential binder")
        expected = {"e": [name] + q["e"], "a": q["a"], "r": q["r"]}
    elif rule in {"and", "or_ground", "or_tagged"}:
        require(tag == ("and" if rule == "and" else "or") and len(children) == 2,
                "wrong binary normalization rule")
        p = verify_node(children[0], data[0], signature, all_source_names, selectors)
        q = verify_node(children[1], data[1], signature, all_source_names, selectors)
        bp, bq = set(p["e"] + p["a"]), set(q["e"] + q["a"])
        require(not (bp & bq), "shared bound variable across operands")
        require(not (bp & formula_vars(data[1]))
                and not (bq & formula_vars(data[0])), "capture across operands")
        if rule == "and":
            expected = {"e": p["e"] + q["e"], "a": p["a"] + q["a"],
                        "r": app("C", p["r"], q["r"], num(1))}
        elif rule == "or_ground":
            require(not (bp or bq), "ground disjunction has quantified operands")
            expected = {"e": [], "a": [],
                        "r": app("C", p["r"], num(0), q["r"])}
        else:
            require(bool(bp or bq), "tagged rule used for a ground disjunction")
            selector = node["selector"]
            require(name_ok(selector) and selector not in all_source_names
                    and selector not in selectors
                    and selector not in normal_all(p) | normal_all(q),
                    "disjunction selector is not fresh")
            selectors.add(selector)
            expected = {"e": [selector] + p["e"] + q["e"],
                        "a": p["a"] + q["a"],
                        "r": app("C", var(selector), p["r"], q["r"])}
    else:
        raise ValueError("unknown normalization rule")

    require(result == expected, "normal form does not match its proof schema")
    require(normal_free(result) == formula_vars(source), "free parameters changed")
    return result


def check_plain_equation(equation, signature):
    require(isinstance(equation, dict) and set(equation) == {"eq"}
            and isinstance(equation["eq"], list) and len(equation["eq"]) == 2,
            "bad native equation syntax")
    for term in equation["eq"]:
        check_term(term, signature)


def verify_native(native, normal, signature):
    if not (normal["e"] or normal["a"]):
        check_plain_equation(native, signature)
        require(native == {"eq": [normal["r"], num(0)]}, "wrong depth-zero output")
        return 0
    require(isinstance(native, dict) and set(native) == {"D"}, "expected one D binder")
    data = native["D"]
    require(isinstance(data, list) and len(data) == 3, "bad D syntax")
    x, z, body = data
    require(name_ok(x) and name_ok(z) and x != z
            and x not in normal_all(normal) and z not in normal_all(normal),
            "native binder captures a numerical parameter")
    check_plain_equation(body, signature)
    replacements = {}
    for index, name in enumerate(normal["e"]):
        replacements[name] = balanced_projection(var(x), len(normal["e"]), index)
    for index, name in enumerate(normal["a"]):
        replacements[name] = balanced_projection(app("pred", var(z)),
                                                len(normal["a"]), index)
    matrix = substitute(normal["r"], replacements)
    expected = {"eq": [app("C", var(z), num(0), matrix), num(0)]}
    require(body == expected, "wrong balanced projections or native gate")
    require((term_vars(matrix) | {z}) - {x, z} == normal_free(normal),
            "native output changed free parameters")
    return 1


def verify_linear_native(linear, plain, normal, signature):
    """Check genuine I(1,a;u.h) conversions; erasure is only a certificate check."""
    if "eq" in plain:
        check_plain_equation(linear, signature)
        require(linear == plain, "ground linear output differs")
        return 0
    require(isinstance(linear, dict) and set(linear) == {"D"}
            and isinstance(linear["D"], list) and len(linear["D"]) == 3,
            "bad linear native formula")
    x, z, body = linear["D"]
    require([x, z] == plain["D"][:2], "linear output changed its D binders")
    require(isinstance(body, dict) and set(body) == {"eq"}
            and isinstance(body["eq"], list) and len(body["eq"]) == 2,
            "bad linear equality")
    forbidden = normal_free(normal) | {x, z}
    seen = set()

    def erase(term, environment):
        require(isinstance(term, dict), "linear term must be an object")
        if set(term) == {"v"}:
            require(name_ok(term["v"]), "bad linear variable")
            return environment.get(term["v"], term)
        if set(term) == {"n"}:
            require(type(term["n"]) is int and term["n"] >= 0, "bad linear numeral")
            return term
        if set(term) == {"I"}:
            data = term["I"]
            require(isinstance(data, list) and len(data) == 4, "bad scalar iterator")
            count, initial, binder, update = data
            require(isinstance(count, dict) and set(count) == {"n"}
                    and type(count["n"]) is int and count["n"] == 1,
                    "only an exact integer-one iterator count is licensed")
            require(name_ok(binder) and binder not in forbidden and binder not in seen,
                    "capturing or repeated scalar binder")
            seen.add(binder)
            value = erase(initial, environment)
            return erase(update, environment | {binder: value})
        require(set(term) == {"f", "a"} and isinstance(term["a"], list),
                "bad linear function application")
        arities = BUILTINS | signature
        require(isinstance(term["f"], str) and term["f"] in arities
                and len(term["a"]) == arities[term["f"]], "bad linear function arity")
        return app(term["f"], *(erase(child, environment) for child in term["a"]))

    erased = {"eq": [erase(term, {}) for term in body["eq"]]}
    require(erased == plain["D"][2], "one-step scalar beta conversion failed")
    require((term_vars(body["eq"][0]) | term_vars(body["eq"][1])) - {x, z}
            == normal_free(normal), "linear output changed free parameters")
    return len(seen)


def verify(certificate):
    require(isinstance(certificate, dict) and set(certificate) == {
        "format", "signature", "source", "alpha", "derivation", "normal", "native",
        "native_linear"
    }, "bad certificate envelope")
    require(certificate["format"] == "positive-sigma2-v1", "unknown format")
    signature = certificate["signature"]
    check_signature(signature)
    check_source(certificate["source"], signature)
    check_source(certificate["alpha"], signature)
    verify_alpha(certificate["source"], certificate["alpha"])
    normal = verify_node(certificate["derivation"], certificate["alpha"], signature,
                         formula_vars(certificate["alpha"], free=False), set())
    check_normal(certificate["normal"], signature)
    require(certificate["normal"] == normal, "final normal form mismatch")
    depth = verify_native(certificate["native"], normal, signature)
    bindings = verify_linear_native(certificate["native_linear"], certificate["native"],
                                    normal, signature)
    return {"accepted": True, "native_depth": depth,
            "one_step_scalar_bindings": bindings,
            "existential_variables": len(normal["e"]),
            "universal_variables": len(normal["a"]),
            "free_variables": sorted(normal_free(normal))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate")
    args = parser.parse_args()
    try:
        with open(args.certificate, encoding="utf-8") as stream:
            certificate = json.load(stream)
        print(json.dumps(verify(certificate), sort_keys=True))
    except (ValueError, TypeError, KeyError, IndexError, RecursionError) as error:
        print(json.dumps({"accepted": False, "reason": str(error)}))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
