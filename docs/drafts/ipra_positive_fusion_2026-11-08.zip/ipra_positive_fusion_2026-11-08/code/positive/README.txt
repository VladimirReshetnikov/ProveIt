Positive Sigma2 normalization and one-D compilation
=================================================

Purpose and exact claim
-----------------------
This directory contains an untrusted formula producer, a separately implemented
proof-schema certificate verifier, readable shared finite syntax operations,
and reproducible examples. The mathematical report proves the schemas.
This is NOT a complete iPRA proof checker, a proof-assistant formalization,
or evidence that the trusted iPRA kernel has become smaller.

Run with Python 3.10 or later; only its standard library is used:

    python3 run_examples.py
    python3 verify_positive.py examples/positive_cluster.json

To compile a supplied source document:

    python3 compile_positive.py input.json certificate.json
    python3 verify_positive.py certificate.json

The input is an object containing `signature` and `source`. A signature maps
names of supplied fixed primitive-recursive numerical functions to arities.
For instance {"eq_characteristic":2} names the fixed function which is 0 for
equal arguments and 1 otherwise. A signature declaration is an explicit
mathematical dependency: the verifier checks arity, not primitive recursivity.
The reproduction script supplies the actual fixed numerical functions for
every example. No arbitrary propositional atom is passed off as an equation.

Numerical syntax
----------------
  {"v":"x"}                    variable
  {"n":0}                      natural numeral (JSON booleans are rejected)
  {"f":"name","a":[t1,...]}     application at the declared arity

The fixed numerical abbreviations, reserved against source redefinition, are:

  C(n,a,b) = a if n=0; b if n is a successor;
  pred(0)=0, pred(Sn)=n;
  pair(a,b), left, right with left(pair(a,b))=a, right(pair(a,b))=b.

The mathematical argument uses only these equations, numerical coverage and
the fixed primitive-recursive character of the operations. Pair bijectivity
is unnecessary. The finite diagnostics use Cantor pairing, but never infer
native soundness from a finite-domain model (finite nontrivial domains do not
support the needed pairing section).

Source formula syntax
---------------------
  {"zero":t}                    the literal equation t=0
  {"and":[F,G]}, {"or":[F,G]}
  {"exists":["x",F]}
  {"forall":["x",F]}

Universal nodes are accepted only in a contiguous forall* prefix ending in
one zero-test leaf. Existential nodes and the positive connectives may occur
arbitrarily outside such blocks. In particular, every positive combination
of prenex Sigma2 blocks exists* forall* (r=0) is accepted. Implications and
forall-exists switches are rejected. This is a deliberately precise input
fragment; rejection of a formula need not imply that it lacks some Sigma2
equivalent. Alpha conversion supports free/bound name collisions, repeated
bound spellings in siblings, and nested shadowing without capture.

Normal form and certificate rules
---------------------------------
A normal form {"e":[...],"a":[...],"r":t} means

    exists e1 ... ek forall a1 ... am (t=0).

The verifier checks all node schemas, quantifier freshness, alpha equivalence,
and exact output syntax. For conjunction, matrices r,s are combined as
C(r,s,1)=0. For disjunction of ground matrices they combine as C(r,0,s)=0.
For quantified disjunction a new existential tag b is introduced and the
matrix is C(b,r,s)=0. The unused witnesses in the other branch can be 0.
Witness lists and universal lists are concatenated only after freshening.

The verifier does not import the producer. It shares only finite syntax,
term-substitution and balanced projection helpers in syntax.py. The emitted
certificate contains an explicit tree of proof-schema applications. It is
not a list of finite truth tests and not a primitive native proof derivation.

Native outputs
--------------
The equation grammar is {"eq":[s,t]}. A paired formula is

    {"D":["w","z",B]},

with ordinary meaning exists w (B(w,0) -> forall z B(w,z)). A quantifier-free
normal form emits its equation at depth zero. Otherwise finite witness and
universal tuples are encoded by balanced binary pairing; their components
are projected from w and pred(z). The sole equation leaf is

    C(z,0,r(projected witnesses, projected universals)) = 0.

Its zero instance is true and its successor instances are the prenex matrix.
The inherited paired-fusion theorem proves the one-D equivalence. No
classical prenex transformation, choice principle, or quantified induction
is used in the positive normalization rules.

There are two equivalent native outputs. `native` uses direct balanced
projection terms. `native_linear` decodes each tuple once, binding the two
children of each pairing node as numerical variables. These bindings are
actual scalar terms, written in JSON as

    {"I":[{"n":1}, initial, "u", body]},

and denoting I(1,initial;u.body). The two scalar iterator equations prove
I(1,a;u.h)=h[a/u]. Thus this is not a free DAG extension or a new let
primitive. The independent verifier checks freshness of every scalar binder
and beta-erases the generated one-step iterators to the already verified
direct projection matrix. The update bodies can capture outer numerical
variables, so this construction belongs to the parameterized scalar basis;
no closed-update claim is made.

Size accounting
---------------
Each source matrix term is retained once. Every operation contributes a
bounded number of syntax nodes, and each occurrence of a quantified variable
receives a balanced projection of length at most ceil(log2 m), where m is
its tuple length. Consequently the direct native syntax has O(N log N) tree
nodes for source size N in the fixed numerical-operation signature.
Generated variable-name character lengths and certificate size are not this
tree-node metric. Certificates repeat source subformulas and need not be
linear or quasilinear in N.

For a literal expansion into the scalar iterator grammar, arbitrary naive
macro expansion could duplicate arguments and spoil the bound. The report's
linear wrapper for each fixed function avoids this:

    f(t) is represented as I(1,t;u.f(u)),

and multivariate functions use nested one-step iterators with fresh bound
variables. Each actual argument then occurs once. Fixed definitions contribute
constant overhead, so the tree-node O(N log N) bound survives that specified
expansion.

The numerical-iterator lowering improves the output bound to O(N) tree
nodes. Its original matrix occurs once. A tuple with m>=2 components has
m-1 internal pairing nodes and needs two child bindings per node; the
universal tuple additionally binds pred(z) once. A singleton needs one
binding. Thus both tuple decoders together have O(N) bindings and each
decoder application receives a numerical variable. Each generated binding
has bounded syntax size. These are actual iterator terms, not storage
sharing outside the language. With each fixed numerical abbreviation either
already expanded in the input-size accounting or expanded via the linear
one-step wrappers above, the literal scalar output remains O(N).

The Python outputs retain fixed numerical-operation abbreviations and do
not themselves run the inherited scalar arithmetic-definition compiler.

Evidence and limits
-------------------
run_examples.py writes certificates and receipt.json. It checks free-variable
preservation, shadowing, capture avoidance, quantified disjunction tags,
positive nested clusters, wrong syntax, prohibited quantifier shifts, altered
certificate rejection, balanced-projection path lengths, and source/native
tree-node counts for growing families. The finite semantic diagnostics compare
only the source positive formula with its prenex form on inhabited test
domains containing 0 and 1. They do not replace the written universal proof.

The new mathematical results are reductions in formula depth and explicit
output-size bounds. No claim of historical priority beyond the inspected
draft corpus is made.
