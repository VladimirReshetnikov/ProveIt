"""Produce positive-Sigma2 proof-schema certificates and one-D formulas.

The mathematical soundness of the checked schemas is stated in the report.
This is an untrusted producer, not an implementation of the iPRA kernel.
"""
from __future__ import annotations

import argparse
import json

from syntax import (Fresh, app, balanced_projection, check_signature,
                    check_source, formula_vars, normal_all, num, require,
                    once, substitute, var)


def alpha_rename(formula, fresh, environment=None):
    environment = {} if environment is None else environment
    tag, data = next(iter(formula.items()))
    if tag == "zero":
        return {"zero": substitute(data, {x: var(y) for x, y in environment.items()})}
    if tag in {"and", "or"}:
        return {tag: [alpha_rename(x, fresh, environment) for x in data]}
    old, body = data
    new = fresh.take("_b")
    return {tag: [new, alpha_rename(body, fresh, environment | {old: new})]}


def normalization(formula, fresh):
    tag, data = next(iter(formula.items()))
    children = []
    extra = {}
    if tag == "zero":
        rule = "zero"
        result = {"e": [], "a": [], "r": data}
    elif tag == "forall":
        variables = []
        body = formula
        while "forall" in body:
            x, body = body["forall"]
            variables.append(x)
        require("zero" in body,
                "universal quantification is accepted only in a forall* zero-test block; "
                "no forall-exists interchange is licensed")
        rule = "forall_block"
        result = {"e": [], "a": variables, "r": body["zero"]}
    elif tag == "exists":
        x, body = data
        child = normalization(body, fresh)
        children = [child]
        q = child["result"]
        rule = "exists"
        result = {"e": [x] + q["e"], "a": q["a"], "r": q["r"]}
    else:
        left = normalization(data[0], fresh)
        right = normalization(data[1], fresh)
        children = [left, right]
        p, q = left["result"], right["result"]
        if tag == "and":
            rule = "and"
            result = {"e": p["e"] + q["e"], "a": p["a"] + q["a"],
                      "r": app("C", p["r"], q["r"], num(1))}
        elif not (p["e"] or p["a"] or q["e"] or q["a"]):
            rule = "or_ground"
            result = {"e": [], "a": [],
                      "r": app("C", p["r"], num(0), q["r"])}
        else:
            rule = "or_tagged"
            selector = fresh.take("_tag")
            extra = {"selector": selector}
            result = {"e": [selector] + p["e"] + q["e"],
                      "a": p["a"] + q["a"],
                      "r": app("C", var(selector), p["r"], q["r"])}
    return {"rule": rule, "source": formula, "result": result,
            "children": children, **extra}


def native_formula(normal, fresh):
    if not (normal["e"] or normal["a"]):
        return {"eq": [normal["r"], num(0)]}
    x, z = fresh.take("_w"), fresh.take("_z")
    replacements = {}
    for i, name in enumerate(normal["e"]):
        replacements[name] = balanced_projection(var(x), len(normal["e"]), i)
    for i, name in enumerate(normal["a"]):
        replacements[name] = balanced_projection(app("pred", var(z)),
                                                len(normal["a"]), i)
    matrix = substitute(normal["r"], replacements)
    return {"D": [x, z, {"eq": [app("C", var(z), num(0), matrix), num(0)]}]}


def linear_native_formula(normal, plain, fresh):
    """Decode each finite tuple once using genuine one-step scalar iterators."""
    if "eq" in plain:
        return plain
    x, z, _ = plain["D"]
    bindings = []

    def descend(parent, names):
        if len(names) == 1:
            bindings.append((names[0], parent))
            return
        split = len(names) // 2
        left_names, right_names = names[:split], names[split:]
        left = left_names[0] if len(left_names) == 1 else fresh.take("_decode")
        right = right_names[0] if len(right_names) == 1 else fresh.take("_decode")
        bindings.append((left, app("left", parent)))
        bindings.append((right, app("right", parent)))
        if len(left_names) > 1:
            descend(var(left), left_names)
        if len(right_names) > 1:
            descend(var(right), right_names)

    if normal["e"]:
        descend(var(x), normal["e"])
    if len(normal["a"]) == 1:
        descend(app("pred", var(z)), normal["a"])
    elif normal["a"]:
        root = fresh.take("_universal_root")
        bindings.append((root, app("pred", var(z))))
        descend(var(root), normal["a"])
    matrix = normal["r"]
    for name, initial in reversed(bindings):
        matrix = once(initial, name, matrix)
    return {"D": [x, z, {"eq": [app("C", var(z), num(0), matrix), num(0)]}]}


def compile_certificate(source, signature):
    check_signature(signature)
    check_source(source, signature)
    fresh = Fresh(formula_vars(source, free=False))
    alpha = alpha_rename(source, fresh)
    derivation = normalization(alpha, fresh)
    normal = derivation["result"]
    fresh.used.update(normal_all(normal))
    plain = native_formula(normal, fresh)
    linear = linear_native_formula(normal, plain, fresh)
    return {"format": "positive-sigma2-v1", "signature": signature,
            "source": source, "alpha": alpha, "derivation": derivation,
            "normal": normal, "native": plain, "native_linear": linear}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", help="JSON object with source and signature")
    parser.add_argument("output", help="certificate JSON output")
    args = parser.parse_args()
    with open(args.input, encoding="utf-8") as stream:
        document = json.load(stream)
    result = compile_certificate(document["source"], document["signature"])
    with open(args.output, "w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")


if __name__ == "__main__":
    main()
