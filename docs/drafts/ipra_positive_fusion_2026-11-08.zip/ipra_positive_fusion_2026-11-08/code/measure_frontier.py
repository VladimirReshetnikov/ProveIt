"""Measure all retained complete checkers, including the four existing variants.

This is a source-size comparison, not a proof of checker soundness. The
unchanged programs are parsed as data and never executed by this script.
"""

import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def verified(entry):
    path = ROOT / entry["file"]
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != entry["sha256"]:
        raise ValueError("Frozen source changed: " + entry["file"])
    return path


def main():
    manifest = json.loads((ROOT / "provenance/source_manifest.json").read_text())
    metric_path = verified(manifest["metric"])
    spec = importlib.util.spec_from_file_location("inherited_metrics", metric_path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    rows = [dict(entry, **metric.metrics(verified(entry)))
            for entry in manifest["programs"]]
    complete = [r for r in rows if r["role"] != "exploratory_prototype"]
    retained = [r for r in complete if r["role"] == "complete_inherited_standalone"]
    if len(complete) != 16 or len(retained) != 12:
        raise ValueError("Unexpected comparison inventory")
    def envelope(items):
        return {k: min(r[k] for r in items) for k in FIELDS}
    def dominates(a, b):
        return all(a[k] <= b[k] for k in FIELDS) and any(a[k] < b[k] for k in FIELDS)
    pareto = [r for r in complete
              if not any(dominates(other, r) for other in complete)]
    result = {"status": "PASS", "commit": manifest["commit"],
              "python": platform.python_version(),
              "retained_twelve_envelope": envelope(retained),
              "all_sixteen_envelope": envelope(complete),
              "pareto_programs": [r["label"] for r in pareto],
              "programs": rows,
              "scope": "Whole-source size only; no new checker or soundness claim."}
    dest = ROOT / "results"
    dest.mkdir(exist_ok=True)
    (dest / "frontier.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = [r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
             r"Existing complete program & Tokens & AST nodes & Bytes\\",
             r"\midrule"]
    selected = [r for r in complete if r["file"].endswith(
        ("kernels_structural.py", "kernels_byte.py"))]
    selected += [r for r in complete if r["role"] == "complete_existing_variant"]
    for r in selected:
        lines.append(r["label"].replace("_", r"\_") + " & " +
                     " & ".join(str(r[k]) for k in FIELDS) + r"\\")
    lines += [r"\midrule", "All sixteen: coordinate minima & " +
              " & ".join(str(envelope(complete)[k]) for k in FIELDS) + r"\\",
              r"\bottomrule", r"\end{tabular}"]
    (dest / "frontier_table.tex").write_text("\n".join(lines) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "programs"}, indent=2))


if __name__ == "__main__":
    main()
