"""Compile the report with ordinary pdflatex; no shell escape or network."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent

for _ in range(3):
    result = subprocess.run(
        ["pdflatex", "-no-shell-escape", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
        cwd=ROOT, capture_output=True, text=True,
    )
    (ROOT / "results/latex_build.txt").write_text(result.stdout + result.stderr)
    if result.returncode:
        raise SystemExit(result.stdout[-6000:] + result.stderr)
print("Built report.pdf")
