SUPPLEMENTAL COMPLETE-CHECKER IMPLEMENTATION EXPERIMENTS
======================================================

These four programs are small source transformations of the retained
initializer checkers.  They implement the inherited scalar-iterator
calculus.  They do NOT implement the new shifted K theory.  Their source
measurements are supplemental evidence, not a new mathematical
axiomatization or a claim to meet every complexity target.

Measured results using the unchanged inherited normalizer
--------------------------------------------------------
  Program                    Tokens   AST nodes   Normalized bytes
  structural_open.py            316         347                901
  compact_open.py               317         351                878
  compact_unpack.py             314         348                929
  compact_unpack_open.py        313         347                922

The pinned coordinate envelope is 317 tokens, 348 AST nodes, and 885
normalized bytes.  Some variants improve tokens or AST nodes; another
improves bytes.  No variant is strictly below all three coordinates.
The function names inst and check and all other helper names are retained.
No identifier shortening is used to manufacture a byte improvement.

Reproduce
---------
From the complete archive:

  python3 exploration/run_experiments.py

The default reference directory is ../benchmark relative to this folder.
For another arrangement:

  python3 run_experiments.py --benchmark-dir /absolute/path/to/benchmark

The script verifies the normalizer and baseline hashes against the sibling
benchmark manifest, verifies that each variant is exactly its stated
source transformation, measures each complete program, and replays the
13 bundled CLI cases.  It writes only results.json in this folder.
It creates no local bytecode cache and imports no external oracle.
The inherited normalizer only parses source; the separate regression
step actually executes the two compared checker programs.

The measurements above were obtained with CPython 3.12.14.  The generated
receipt records the current interpreter and whether its measurements
match these recorded figures.

Transformation 1: standard-input wrapper
---------------------------------------
The *_open programs replace

  import json, sys                 import json
  json.load(sys.stdin)      by     json.load(open(0))

The wrapper still reads one complete JSON value from standard input.  The
core checker receives the same parsed JSON value when the two text streams
use the same encoding and error handling.  This permits removal of the
otherwise unused sys import; it does not change inst, proof rules, context
handling, or freshness validation.

This equivalence is qualified.  sys.stdin can honor PYTHONIOENCODING or a
replacement stream differently from open(0), which opens file descriptor
zero as a fresh text stream.  We do not claim identical behavior for every
raw byte stream and arbitrary Python environment.  The intended interface
is an ordinary UTF-8 command-line process with no earlier reader consuming
the input.  The regression explicitly sets -X utf8, PYTHONUTF8=1, and
PYTHONIOENCODING=utf-8:strict, and records both streams' observed encodings
and error policies.  It sends UTF-8 bytes to both subprocesses.

Transformation 2: major-premise unpacking
----------------------------------------
In the compact checker's equation/closure elimination branch, replace

  t, s, u = (t, *m) if m[1:] else (*m, 0, t)

by

  try:
      s, u = m
  except:
      s, u, t = 0, t, *m

The enclosing major validation and slice test are unchanged.  At this
branch, a usable validated major is either a two-element equation [s,u]
or a one-element closure [B].  A three-element major takes paired
elimination.  Oversized arrays fail the unchanged syntax traversal; other
JSON containers or scalar majors cannot survive the validation/slicing
needed to reach this branch as usable majors.

For [s,u], unpacking succeeds and the previous template t is unchanged.
Both versions subsequently use the triple (template, source, target)
(old t,s,u).  For [B], the first unpacking fails before assignments take
place; simultaneous assignment in the handler gives s=0, u=old t, t=B.
This is exactly the old closure triple (B,0,old t).  Thus the subsequent
recursive checks, instruction consumption, and scope handling agree.
The same argument applies with arbitrary contents of these lists; it
does not assume the payload is well formed before its eventual use.
There is no change to arithmetic computation, substitution, induction,
eigenparameter allocation, or acceptance via assertions.

This is a local source-equivalence argument, not a new axiom reduction.
The try/except form reduces the token and AST counts but increases the
normalized byte count through additional control syntax and indentation.
Finite implementation resource limits and external process interruptions
are not a mathematical equivalence claim.

Regression evidence and provenance
----------------------------------
cli_cases.json contains ten unchanged public packets from the inherited
initializer package, including two declared rejection examples, plus
three malformed-input controls.  Each copied packet retains its source
member, original expected verdict, and SHA-256.  The source archive URL
is recorded in that file.  The negative controls are '{', '[]', and
'null'.

For each of these 13 inputs, the reproducer compares the exact exit code,
standard output, and standard error of the pinned initializer_compact.py
against compact_unpack_open.py.  It also checks the expected verdict.
All 13 comparisons passed under the recorded UTF-8 configuration, for
26 subprocess runs.  The receipt in results.json is reproducible.
These finite tests supplement the local equivalence reasoning; they do
not prove the inherited calculus sound or establish bi-interpretability.

Original checker source, the inherited normalizer, and provenance are in
the sibling benchmark directory.  The inherited source license is retained
there at provenance/LICENSE-inherited.txt.  Original attribution is retained
in that directory as well.  The only checker changes are the two explicit
source transformations above; the arithmetic and logical mathematics of
those programs are inherited.
