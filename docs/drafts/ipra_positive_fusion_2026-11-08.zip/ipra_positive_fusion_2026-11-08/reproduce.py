"""Reproduce the finite measurements and schema checks; standard library only."""
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")


def run(path, cwd=ROOT):
    result = subprocess.run(
        [sys.executable, str(ROOT / path)],
        cwd=cwd, env=ENV, capture_output=True, text=True,
    )
    if result.returncode:
        raise SystemExit(result.stdout + result.stderr)
    return result.stdout


def main():
    run(Path("code/measure_frontier.py"))
    positive = ROOT / "code/positive"
    run(Path("code/positive/run_examples.py"), cwd=positive)
    receipt = json.loads((positive / "receipt.json").read_text())
    (RESULTS / "positive_receipt.json").write_text(
        json.dumps(receipt, indent=2) + "\n"
    )
    unary = json.loads(run(Path("code/unary_shift_diagnostic.py")))
    (RESULTS / "unary_shift_diagnostic.json").write_text(
        json.dumps(unary, indent=2) + "\n"
    )
    frontier = json.loads((RESULTS / "frontier.json").read_text())
    summary = {
        "status": "PASS",
        "python": frontier["python"],
        "all_sixteen_envelope": frontier["all_sixteen_envelope"],
        "accepted_certificates": receipt["accepted_certificates"],
        "rejected_mutations": len(receipt["rejected_mutations"]),
        "rejected_sources": len(receipt["rejected_source_cases"]),
        "finite_prenex_comparisons": receipt["finite_prenex_semantic_comparisons"],
        "projection_checks": receipt["projection_length_tests"],
        "unary_standard_inputs": unary["checked_inputs"],
        "scope": (
            "Finite source measurements, checked proof schemas, and standard "
            "evaluation diagnostics. No new complete checker or formal proof "
            "of iPRA bi-interpretability is claimed."
        ),
    }
    (RESULTS / "reproduction.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

