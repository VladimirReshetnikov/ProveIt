POSITIVE FUSION IN A ONE-BINDER PRESENTATION OF iPRA
=================================================

Status
------
The requested strict reduction in the size of a complete iPRA proof checker
has NOT been obtained. This archive must not be cited as a new smallest
axiomatization or a proof of an absolute lower bound.

It supplies a constructive improvement in formula translation:
  * Existential quantification and disjunction are absorbed into an
    already-present positive-depth paired binder.
  * Every fixed finite positive combination of prenex existential-universal
    arithmetic blocks has a native representative at depth at most one.
  * Actual one-step scalar iterations provide numerical bindings, yielding
    O(N) scalar syntax-tree nodes for a fixed finite PR vocabulary.

The complete reference scalar/native theory and its bi-interpretability with
full first-order iPRA are inherited. The report states all logical and
nonlogical rules, explains both composites, and gives proofs of the new
transformations. An open closed-unary shifted-iteration candidate is clearly
separated in the appendix; no completeness or reverse interpretation is claimed.

Read
----
report.pdf                 Compiled research report.
report.tex, sections/      Complete TeX source.
code/positive/README.txt   Compiler format, proof-schema verifier, exact scope.
results/frontier.json      All source measurements and the Pareto frontier.
results/positive_receipt.json
                           Certificate and diagnostic results.
results/unary_shift_diagnostic.json
                           Finite standard-number evaluation of the open candidate.
provenance/source_manifest.json
                           Pinned archive identities and copied-source hashes.
reference/ATTRIBUTION.txt  Inherited material versus this report.
reference/arithmetic/     Selected original proof source fragments, not standalone TeX.
research/                 An explicit standard predecessor candidate whose internal
                          defining equations remain an open proof obligation.

Reproduce
---------
Python 3.10 or newer, standard library only:

    python3 reproduce.py

This runs the original source normalizer on verified copied sources, generates
and verifies sixteen compiler certificates, exercises rejection controls and
finite diagnostics, and evaluates the appendix's displayed terms.
It does not execute the inherited checker programs.
The recorded source metrics were produced with CPython 3.12.14.
Different Python versions may unparse source differently.

Compile the report with a normally configured TeX Live or MiKTeX installation:

    python3 build.py

The build invokes pdflatex three times, with shell escape disabled and no
network access. Packages are ordinary LaTeX packages: geometry, fontenc,
lmodern, microtype, amsmath, amssymb, amsthm, mathtools, booktabs, longtable,
array, enumitem, xcolor, xurl, hyperref, fancyhdr.
The mathematical report is self-contained as a source set; the files under
reference/arithmetic/ are additional inherited proof details and are not
inputs to report.tex.

Comparison convention
---------------------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit:     12a94890af11b5e75f753260f3be00bb11ae7f08
Six current ZIP files in docs/drafts were inspected.

The current sixteen complete source programs have coordinate minima
313 normalized tokens / 347 AST nodes / 878 normalized UTF-8 bytes.
Different inherited programs attain these coordinates. Four complete variants
already supplied in the successor-from-recursion archive improve on the
twelve-program envelope 317 / 348 / 885 quoted in several current reports.
This is a correction to the comparison inventory, not a new checker.

Verification boundary
---------------------
The producer and schema verifier are separate implementations, sharing only
finite syntax, substitution, and projection helpers. The verifier validates
proof-schema applications, syntax, binding, alpha conversion and output
structure. The mathematical report proves the schemas.

This is NOT a full native proof derivation generator, a complete iPRA kernel,
or a Lean/Rocq formalization. Numerical signature declarations are explicit
dependencies; their arity is checked, their primitive recursivity is not
automatically proved. Finite semantic comparisons concern only source versus
prenex form, never a finite-domain model of native pairing arithmetic.
Literal scalar expansion is covered by the written size proof; the JSON
outputs retain fixed numerical-operation abbreviations.

Recorded results: 16 accepted certificates; 38 altered certificates rejected;
6 unsupported/malformed sources rejected; 127 finite prenex comparisons;
8,256 projection checks. These counts are diagnostics, not theorem proofs.

Attribution
-----------
Inherited files are copied unchanged, with their supplied MIT No Attribution
license. Original attribution files contain statements about their OWN reports
and snapshots; see reference/ATTRIBUTION.txt for the current provenance.
No historical priority beyond the inspected draft corpus is claimed.

