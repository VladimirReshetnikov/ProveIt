iPRA WITH A NORMAL RECURSION SIGNATURE
Prepared for Vladimir Reshetnikov
2 November 2026

MAIN RESULT
-----------
The report constructs a full first-order intuitionistic theory that is
bi-interpretable and equiconsistent with iPRA. Its new simplification is
to normalize a finite recursion body before creating its function symbol.
Identity updates and descriptions already reduced to an existing operation
therefore need no new declaration and no identity or alias axiom.

The native pairing equations supply additional valid reductions, for
example L(B(v,S^m(w))) -> v. Every recursor for that family is eliminated.
The report gives an explicit virtual-recursion term for every omitted
description and proves both of its recursion equations.

The comparison is pinned to ProveIt commit
44d32ed7bce61b58f6a28c03979cc95dd935acf7.
All four current drafts and all five immediately archived drafts were
reviewed and their ZIP bytes verified against Git blob identities.
All four current drafts contribute a real improvement; none is discarded
wholesale. Provenance is recorded in provenance/source_manifest.json.

COMPARISON
----------
After granting the previous compatible presentation the same universal
prefix sharing and logical-definition records, the fixed arithmetic and
computation support decreases from 81 to 70 nodes. Including Sep, Cov,
and the chosen logical definitions gives:

  Logical mode       Matched old support       New support
  K3 only                    109                    98
  K4 only                    112                   101
  K3 and K4                  121                   110

The report also proves a literal proper axiom-deletion theorem for the
actual optimized pairing-and-sharing draft, with its own optimizer and
size convention unchanged.

For each retained canonical description compared with its own raw
embedding, the new computation minimum is no larger than the compatible
source-module minimum. An arbitrary many-to-one normalization need not
preserve the active occurrence profile, so a stronger claim about every
old module or finite proof packet is not asserted.

For h_m(v,w)=L(B(v,S^m(w))), the generous old compatible computation
envelope costs 2m+38 for m>=9 under the published descriptor convention.
The new signature emits no declaration and no computation module.
An application with variable arguments shrinks from m+7 nodes to one.

WHAT IS IN THE ARCHIVE
---------------------
report.pdf                 Compiled report, including complete theory,
                           mathematical proofs, comparisons, limitations,
                           and Further research questions.
report.tex                 Main TeX source.
sections/*.tex             All ten included source sections.
AXIOMS.txt                 Concise exact axiom and generator specification.
build.py                   Rebuilds the PDF; optionally reruns the checks.
artifacts/normal_signature.py
                           Executable active/frozen syntax, normalizer,
                           raw translation, exact AST size checks, and
                           bounded numerical diagnostics.
artifacts/normal_signature_checks.json
                           Reproducible output of that script.
artifacts/strict_family_check.py
                           Independent module and sharing checker for the
                           explicit strict-improvement family.
artifacts/strict_family_results.json
                           Reproducible independent comparison output.
provenance/source_manifest.json
                           All nine source archive identities and digests.
verification/              Build log and verification status.
SHA256SUMS.txt              Digests of the package files, excluding itself.

REBUILDING
----------
Requires Python 3.10+ and a standard LaTeX installation containing
pdflatex, amsmath, amsthm, mathtools, lmodern, microtype, geometry,
booktabs, longtable, array, xcolor, enumitem, and hyperref.

From this directory:

  python3 build.py --verify

The checks use only the Python standard library. To run them separately:

  python3 artifacts/normal_signature.py
  python3 artifacts/strict_family_check.py

PROOF STATUS AND SCOPE
----------------------
The interpretation and bi-interpretation theorems have constructive
mathematical proofs in the report. They preserve the whole carrier,
native equality, genuine falsity, arbitrary implication, and both
quantifiers. Quantifier-free numerical decidability is not used to
classicalize quantified formulas.

The Python checks verify finite syntax and arithmetic diagnostics; they
are not a proof-assistant verification of the infinite metatheory.
The full boundary generator is specified and proved in the report but
is not implemented exhaustively by the supplied checker.

The finite node counts do not count the infinite axiom set, the entire
logical calculus, the finite generator program, or proof lengths.
No encoding-independent absolute shortestness theorem is claimed.
