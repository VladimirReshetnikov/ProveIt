#!/usr/bin/env python3
"""Rebuild this self-contained TeX report and optionally rerun its checks."""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true",
                        help="also rerun the two independent Python checkers")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    verification = root / "verification"
    verification.mkdir(exist_ok=True)
    if args.verify:
        for script in ("normal_signature.py", "strict_family_check.py"):
            result = subprocess.run(
                [sys.executable, str(root / "artifacts" / script)],
                cwd=root, check=True, capture_output=True, text=True,
            )
            (verification / (script.removesuffix(".py") + "_stdout.txt")).write_text(
                result.stdout + result.stderr, encoding="utf-8")
            print(script + ": passed")
    latex = shutil.which("pdflatex")
    if latex is None:
        raise SystemExit("pdflatex is required; see README.txt.")
    with tempfile.TemporaryDirectory(prefix="ipra-report-") as tmp:
        build = Path(tmp)
        log = ""
        for iteration in range(4):
            result = subprocess.run(
                [latex, "-interaction=nonstopmode", "-halt-on-error",
                 "-output-directory=" + str(build), "report.tex"],
                cwd=root, capture_output=True, text=True,
            )
            log = (build / "report.log").read_text(encoding="utf-8", errors="replace")
            if result.returncode:
                (verification / "latex_build.txt").write_text(log, encoding="utf-8")
                raise SystemExit(result.stdout[-8000:] + result.stderr)
            if iteration >= 2 and "Rerun to get" not in log:
                break
        (verification / "latex_build.txt").write_text(log, encoding="utf-8")
        issues = ("Overfull \\hbox", "Overfull \\vbox", "undefined references",
                  "Undefined control sequence", "There were undefined citations")
        found = [issue for issue in issues if issue in log]
        if found:
            raise SystemExit("Layout/reference issues in latex_build.txt: " + ", ".join(found))
        shutil.copy2(build / "report.pdf", root / "report.pdf")
    print("report.pdf: built; no overfull boxes or undefined references")

if __name__ == "__main__":
    main()
