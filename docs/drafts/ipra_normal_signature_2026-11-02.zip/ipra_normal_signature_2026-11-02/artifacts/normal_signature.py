#!/usr/bin/env python3
"""Finite diagnostics for the normal-signature presentation of iPRA.

This is an executable specification of term syntax, active normalization,
and the bottom-up translation of frozen descriptions. It is NOT a proof
assistant and does NOT mechanically prove the bi-interpretability theorem.
Its Python evaluator is external test code, not an internal universal
primitive-recursive evaluator postulated by the mathematical theory.

Run with Python 3.10 or later (standard library only):
    python3 artifacts/normal_signature.py
The JSON report is written beside this script. An alternative output path
can be supplied with --output. All random sampling uses a fixed seed.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
import json
from math import isqrt
from pathlib import Path
import random
from typing import Mapping


ARITIES = {"0": 0, "S": 1, "B": 2, "L": 1, "R": 1, "Q": 2, "Z": 2}


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple["Term", ...] = ()
    descriptor: "Term | None" = None
    name: str | None = None

    def __post_init__(self) -> None:
        if self.op == "var":
            if not self.name or self.args or self.descriptor is not None:
                raise ValueError("Malformed variable")
        elif self.op == "Rec":
            if len(self.args) != 2 or self.descriptor is None or self.name is not None:
                raise ValueError("Malformed initialized recursor")
        elif self.op in ARITIES:
            if len(self.args) != ARITIES[self.op] or self.descriptor is not None or self.name is not None:
                raise ValueError(f"Malformed native application {self.op}")
        else:
            raise ValueError(f"Unknown term operation {self.op}")


def V(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("0")


def A(op: str, *args: Term) -> Term:
    return Term(op, tuple(args))


def Rec(h: Term, counter: Term, initial: Term) -> Term:
    if not active_vars(h) <= {"v", "w"}:
        raise ValueError("A stored description may have active variables v,w only")
    return Term("Rec", (counter, initial), descriptor=h)


@lru_cache(maxsize=None)
def size(t: Term) -> int:
    """Full-tree size; every Rec occurrence pays its entire description."""
    return 1 + sum(size(a) for a in t.args) + (size(t.descriptor) if t.descriptor is not None else 0)


@lru_cache(maxsize=None)
def active_vars(t: Term) -> frozenset[str]:
    if t.op == "var":
        return frozenset({t.name})
    return frozenset().union(*(active_vars(a) for a in t.args))


@lru_cache(maxsize=None)
def rank(t: Term) -> int:
    """Maximum generated-function rank occurring in a finite term."""
    own = 1 + rank(t.descriptor) if t.descriptor is not None else 0
    return max((own, *(rank(a) for a in t.args)))


def subst(t: Term, bindings: Mapping[str, Term]) -> Term:
    """Simultaneous active substitution: never traverse stored descriptions."""
    if t.op == "var":
        return bindings.get(t.name, t)
    return Term(t.op, tuple(subst(a, bindings) for a in t.args), t.descriptor)


def local_reduction(t: Term) -> tuple[Term, str] | None:
    """First applicable root rule; every accepted rule strictly lowers size."""
    candidate: Term | None = None
    rule = ""
    if t.op in ("L", "R") and t.args[0].op == "B":
        candidate = t.args[0].args[0 if t.op == "L" else 1]
        rule = "pair_beta_" + t.op
    elif t.op == "B" and t.args[0].op == "L" and t.args[1].op == "R" and t.args[0].args[0] == t.args[1].args[0]:
        candidate = t.args[0].args[0]
        rule = "pair_eta"
    elif t.op == "Q":
        counter, initial = t.args
        if counter == ZERO:
            candidate, rule = initial, "Q_zero"
        elif counter.op == "S":
            candidate, rule = counter.args[0], "Q_successor"
    elif t.op == "Z":
        counter, initial = t.args
        if counter == ZERO:
            candidate, rule = initial, "Z_zero"
        elif counter.op == "S":
            candidate, rule = ZERO, "Z_successor"
    elif t.op == "Rec":
        counter, initial = t.args
        if counter == ZERO:
            candidate, rule = initial, "recursor_zero"
        elif counter.op == "S":
            predecessor = counter.args[0]
            previous = Rec(t.descriptor, predecessor, initial)
            candidate = subst(t.descriptor, {"v": previous, "w": predecessor})
            rule = "recursor_successor"
    if candidate is not None and size(candidate) < size(t):
        return candidate, rule
    return None


def active_step(t: Term) -> tuple[Term, str] | None:
    """One deterministic innermost-leftmost step; frozen bodies stay frozen."""
    for i, arg in enumerate(t.args):
        reduced = active_step(arg)
        if reduced is not None:
            replacement, rule = reduced
            args = t.args[:i] + (replacement,) + t.args[i + 1 :]
            return Term(t.op, args, t.descriptor), rule
    return local_reduction(t)


def normalize_trace(t: Term) -> tuple[Term, Counter[str]]:
    rules: Counter[str] = Counter()
    start_size = size(t)
    while True:
        step = active_step(t)
        if step is None:
            return t, rules
        new, rule = step
        assert size(new) < size(t)
        rules[rule] += 1
        assert sum(rules.values()) < start_size
        t = new


@lru_cache(maxsize=None)
def normalize(t: Term) -> Term:
    return normalize_trace(t)[0]


@lru_cache(maxsize=None)
def translate(t: Term) -> Term:
    """Homomorphic on active applications; normalize translated bodies only.

    There is deliberately no normalize() call around a general native or
    recursor application. Only a stored update is normalized, after its
    dependencies have been recursively translated.
    """
    if t.op == "var":
        return t
    args = tuple(translate(a) for a in t.args)
    if t.op != "Rec":
        return Term(t.op, args)
    h = normalize(translate(t.descriptor))
    counter, initial = args
    if h == V("v"):
        return initial
    if h == ZERO:
        return A("Z", counter, initial)
    if h == V("w"):
        return A("Q", counter, initial)
    return Rec(h, counter, initial)


def is_canonical(t: Term) -> bool:
    if t.descriptor is not None:
        h = t.descriptor
        if not active_vars(h) <= {"v", "w"} or h in (V("v"), V("w"), ZERO) or normalize(h) != h or not is_canonical(h):
            return False
    return all(is_canonical(a) for a in t.args)


def projected(t: Term, variable: str = "x") -> bool:
    """Every active occurrence of variable is inside an intact R(variable)."""
    if t == A("R", V(variable)):
        return True
    if t == V(variable):
        return False
    return all(projected(a, variable) for a in t.args)


def render(t: Term) -> str:
    if t.op == "var":
        return t.name
    if t.op == "0":
        return "0"
    if t.op == "Rec":
        return "Rec[" + render(t.descriptor) + "](" + ",".join(render(a) for a in t.args) + ")"
    return t.op + "(" + ",".join(render(a) for a in t.args) + ")"


def numeral(n: int) -> Term:
    t = ZERO
    for _ in range(n):
        t = A("S", t)
    return t


def evaluate(t: Term, env: Mapping[str, int]) -> int:
    """External standard-N evaluator, used only on the finite tests below."""
    if t.op == "var":
        return env[t.name]
    if t.op == "0":
        return 0
    values = tuple(evaluate(a, env) for a in t.args)
    if t.op == "S":
        return values[0] + 1
    if t.op == "B":
        a, n = values
        k = a + n
        return k * (k + 1) // 2 + n
    if t.op in ("L", "R"):
        z = values[0]
        k = (isqrt(8 * z + 1) - 1) // 2
        right = z - k * (k + 1) // 2
        return k - right if t.op == "L" else right
    if t.op == "Q":
        n, a = values
        return a if n == 0 else n - 1
    if t.op == "Z":
        n, a = values
        return a if n == 0 else 0
    if t.op == "Rec":
        n, state = values
        for counter in range(n):
            # Rebind both slots: surrounding numerical variables are never
            # captured by the frozen description.
            state = evaluate(t.descriptor, {"v": state, "w": counter})
        return state
    raise AssertionError(t.op)


@dataclass(frozen=True)
class Formula:
    op: str
    parts: tuple["Term | Formula", ...]
    binder: str | None = None


def F(op: str, *parts: Term | Formula) -> Formula:
    return Formula(op, tuple(parts))


def Eq(left: Term, right: Term) -> Formula:
    return F("=", left, right)


def close(names: tuple[str, ...], body: Formula, quantifier: str = "forall") -> Formula:
    for name in reversed(names):
        body = Formula(quantifier, (body,), name)
    return body


def conjunction(formulas: list[Formula]) -> Formula:
    assert formulas
    out = formulas[0]
    for f in formulas[1:]:
        out = F("and", out, f)
    return out


def formula_size(f: Term | Formula) -> int:
    if isinstance(f, Term):
        return size(f)
    return 1 + sum(formula_size(x) for x in f.parts)


def descriptor_counts(t: Term) -> tuple[int, int, int, int]:
    """Return H,k,j,r; active literal S(w) subtrees are removed first."""
    def walk(q: Term) -> tuple[int, int, int]:
        if q == A("S", V("w")):
            return 0, 1, 0
        if q == V("v"):
            return 1, 0, 0
        if q == V("w"):
            return 0, 0, 1
        counts = [walk(a) for a in q.args]
        return tuple(sum(c[i] for c in counts) for i in range(3))
    return (size(t), *walk(t))


def dagger(t: Term, state: Term, counter: Term, successor: Term) -> Term:
    if t == A("S", V("w")):
        return successor
    if t == V("v"):
        return state
    if t == V("w"):
        return counter
    if t.op == "var":
        return t
    return Term(t.op, tuple(dagger(a, state, counter, successor) for a in t.args), t.descriptor)


def predecessor(n: Term) -> Term:
    return A("Q", n, ZERO)


def selector(n: Term, a: Term, b: Term) -> Term:
    return A("Q", A("Z", n, A("S", a)), b)


def computation_formulas(h: Term) -> dict[str, list[Formula]]:
    """Raw candidate sizes plus PB, the nonselected predecessor-bound comparison."""
    a, n, u, x, y = (V(s) for s in ("a", "n", "u", "x", "y"))
    rn = Rec(h, n, a)
    next_value = subst(h, {"v": rn, "w": n})
    graph_next = subst(h, {"v": u, "w": n})
    table = F("K4", F("and", Eq(x, n), Eq(y, u)), Eq(Rec(h, x, a), y), Eq(x, A("S", n)), Eq(y, dagger(h, u, n, x)))
    table3 = F("K3", table.parts[0], table.parts[1], F("implies", table.parts[2], table.parts[3]))
    init = F("implies", Eq(n, ZERO), Eq(u, a))
    def table_close(body: Formula) -> Formula:
        return close(("a", "n"), close(("u",), F("and", init, close(("x", "y"), body)), "exists"))
    result = {
        "D": [close(("a",), Eq(Rec(h, ZERO, a), a)), close(("a", "n"), Eq(Rec(h, A("S", n), a), next_value))],
        "G3": [close(("a", "n", "u"), F("K3", F("and", Eq(n, ZERO), Eq(u, a)), Eq(rn, u), Eq(Rec(h, A("S", n), a), graph_next)))],
        "G0": [close(("a", "n", "u"), F("implies", Eq(rn, u), F("and", init, Eq(Rec(h, A("S", n), a), graph_next))))],
        "T4": [table_close(table)],
        "T3": [table_close(table3)],
        "F": [close(("a", "n"), Eq(rn, selector(n, a, dagger(h, Rec(h, predecessor(n), a), predecessor(n), n))))],
        "PB": [close(("a", "n", "u"), F("implies", Eq(predecessor(n), u), Eq(rn, selector(n, a, dagger(h, Rec(h, u, a), u, n)))))],
    }
    if descriptor_counts(h)[3] == 0:
        shifted = F("K4", F("and", Eq(A("S", x), n), Eq(y, u)), Eq(Rec(h, x, a), y), Eq(x, n), Eq(y, selector(n, a, dagger(h, u, ZERO, n))))
        shifted3 = F("K3", shifted.parts[0], shifted.parts[1], F("implies", shifted.parts[2], shifted.parts[3]))
        result["N4"] = [close(("a", "n"), close(("u",), close(("x", "y"), shifted), "exists"))]
        result["N3"] = [close(("a", "n"), close(("u",), close(("x", "y"), shifted3), "exists"))]
    return result


def replace_subterm(t: Term, selected: Term, variable: Term) -> tuple[Term, int]:
    """Replace every active copy of selected; do not enter a stored body."""
    if t == selected:
        return variable, 1
    count = 0
    children = []
    for arg in t.args:
        child, copies = replace_subterm(arg, selected, variable)
        children.append(child)
        count += copies
    return Term(t.op, tuple(children), t.descriptor, t.name), count


def pricing_diagnostics(descriptors: list[Term]) -> dict:
    a, n = V("a"), V("n")
    pair = [
        Eq(A("B", A("L", a), A("R", a)), a),
        Eq(A("S", A("B", A("S", a), n)), A("B", a, A("S", n))),
        Eq(A("S", A("B", ZERO, n)), A("B", A("S", n), ZERO)),
        Eq(A("L", A("B", a, n)), a),
        Eq(A("R", A("B", a, n)), n),
    ]
    helpers = [Eq(A("Q", ZERO, a), a), Eq(A("Q", A("S", n), a), n), Eq(A("Z", ZERO, a), a), Eq(A("Z", A("S", n), a), ZERO)]
    old_helpers = [Eq(Rec(V("w"), ZERO, a), a), Eq(Rec(V("w"), A("S", n), a), n), Eq(Rec(ZERO, ZERO, a), a), Eq(Rec(ZERO, A("S", n), a), ZERO)]
    identity = Eq(Rec(V("v"), n, a), a)
    pair_separate = sum(formula_size(f) for f in [close(("a",), pair[0]), close(("a", "n"), pair[1]), close(("n",), pair[2]), close(("a", "n"), conjunction(pair[3:]))])
    helpers_separate = sum(formula_size(close(("a",) if i % 2 == 0 else ("a", "n"), f)) for i, f in enumerate(helpers))
    old_helpers_separate = sum(formula_size(close(("a",) if i % 2 == 0 else ("a", "n"), f)) for i, f in enumerate(old_helpers))
    counts = {
        "pairing_atomic_matrices": [formula_size(f) for f in pair],
        "pairing_published_separate": pair_separate,
        "pairing_shared_prefix": formula_size(close(("a", "n"), conjunction(pair))),
        "native_QZ_atomic_matrices": [formula_size(f) for f in helpers],
        "native_QZ_separate": helpers_separate,
        "native_QZ_shared_prefix": formula_size(close(("a", "n"), conjunction(helpers))),
        "new_nine_equation_core_shared_prefix": formula_size(close(("a", "n"), conjunction(pair + helpers))),
        "old_descriptor_charged_QZ_separate": old_helpers_separate,
        "old_identity_module": formula_size(close(("a", "n"), identity)),
        "old_support_published_separate": pair_separate + old_helpers_separate + formula_size(close(("a", "n"), identity)),
        "old_support_equally_shared_prefix": formula_size(close(("a", "n"), conjunction(pair + old_helpers + [identity]))),
    }
    assert counts["pairing_atomic_matrices"] == [7, 10, 9, 6, 6]
    assert pair_separate == 45 and counts["pairing_shared_prefix"] == 44
    assert helpers_separate == 28 and counts["native_QZ_shared_prefix"] == 27
    assert counts["new_nine_equation_core_shared_prefix"] == 70
    assert counts["old_support_published_separate"] == 85
    assert counts["old_support_equally_shared_prefix"] == 81
    checks = 0
    binding_checks = 0
    for h in descriptors:
        H, k, j, r = descriptor_counts(h)
        expected = {"D": 3 * H + 13 + k * (H + 2), "G3": 3 * H + 21, "G0": 3 * H + 22, "T4": 2 * H - j + 32, "T3": 2 * H - j + 33, "F": 2 * H - j + 11 + k * (H + 4) + 2 * r, "PB": 2 * H - j + 18 + k * (H + 2)}
        if r == 0:
            expected["N4"] = 2 * H - j + 29
            expected["N3"] = 2 * H - j + 30
        formulas = computation_formulas(h)
        actual = {name: sum(formula_size(f) for f in module) for name, module in formulas.items()}
        assert actual == expected, (render(h), actual, expected)
        checks += len(actual)
        folded_atom = formulas["F"][0].parts[0].parts[0]
        chosen = predecessor(V("n"))
        replacement = V("u")
        left, left_count = replace_subterm(folded_atom.parts[0], chosen, replacement)
        right, right_count = replace_subterm(folded_atom.parts[1], chosen, replacement)
        copies = left_count + right_count
        assert copies >= k + r
        if k + r > 0:
            factored = close(("a", "n"), close(("u",), F("and", Eq(replacement, chosen), Eq(left, right)), "exists"))
            assert formula_size(factored) == actual["F"] + 7 - 2 * copies
            assert formula_size(factored) <= actual["PB"]
        else:
            assert actual["F"] < actual["PB"]
        binding_checks += 1
    counts["computation_formula_size_equalities_checked"] = checks
    counts["predecessor_bound_subsumption_checks"] = binding_checks
    counts["formula_prices"] = {
        "D": "3H+13+k(H+2)", "G3": "3H+21", "G0": "3H+22",
        "T4": "2H-j+32", "T3": "2H-j+33",
        "F_native_QZ": "2H-j+11+k(H+4)+2r", "N4_r_zero": "2H-j+29", "N3_r_zero": "2H-j+30",
        "PB_comparison_only": "2H-j+18+k(H+2)", "L_state_free_special_case": "2H-j+18",
        "F_saving_against_old_branch": "2+k+r",
        "single_predecessor_binding_change": "7-2m for m active copies of p(n), where m >= k+r",
    }
    return counts


def run_checks() -> dict:
    seed = 20261102
    rng = random.Random(seed)
    v, w, x, a, z = (V(s) for s in ("v", "w", "x", "a", "z"))
    descriptors = [
        v, w, ZERO, A("S", v), A("S", w), A("B", v, w),
        A("B", A("S", w), A("S", A("S", w))),
        A("L", A("B", v, numeral(3))),
        A("R", A("B", numeral(2), w)),
        A("Q", A("S", v), w), A("Z", ZERO, v),
        Rec(v, w, v), Rec(A("S", v), ZERO, w),
        Rec(A("S", v), A("S", w), ZERO),
        A("Q", w, A("Z", w, v)),
    ]
    def generated(depth: int, variables: tuple[Term, ...], recursors: bool) -> Term:
        if depth == 0 or rng.randrange(5) == 0:
            return rng.choice((ZERO, *variables))
        op = rng.choice(("S", "B", "L", "R", "Q", "Z", "Rec") if recursors else ("S", "B", "L", "R", "Q", "Z"))
        if op == "Rec":
            return Rec(rng.choice(descriptors), generated(depth - 1, variables, recursors), generated(depth - 1, variables, recursors))
        return A(op, *(generated(depth - 1, variables, recursors) for _ in range(ARITIES[op])))

    raw_terms = [generated(4, (x, a, z), True) for _ in range(600)]
    all_rules: Counter[str] = Counter()
    for term in raw_terms:
        target = translate(term)
        assert size(target) <= size(term)
        assert rank(target) <= rank(term)
        assert is_canonical(target)
        assert translate(target) == target
        normal, rules = normalize_trace(target)
        assert size(normal) <= size(target)
        assert normalize(normal) == normal
        all_rules.update(rules)
        lifted = subst(target, {"x": A("R", x), "a": A("L", z)})
        assert projected(lifted)
        assert projected(normalize(lifted))
        assert projected(translate(lifted))
        bindings = {"x": A("Q", A("S", a), z), "a": Rec(v, z, x)}
        assert translate(subst(term, bindings)) == subst(target, {name: translate(value) for name, value in bindings.items()})

    # Explicit checks target overlapping normalization/capture edge cases.
    frozen = Rec(A("B", v, w), v, w)
    replaced = subst(frozen, {"v": numeral(7), "w": numeral(9)})
    assert replaced.descriptor is frozen.descriptor
    assert replaced.args == (numeral(7), numeral(9))
    assert dagger(frozen, x, a, z).descriptor is frozen.descriptor
    assert descriptor_counts(Rec(A("S", w), v, w)) == (size(Rec(A("S", w), v, w)), 1, 0, 1)
    eta_protected = A("B", A("L", A("R", x)), A("R", A("R", x)))
    assert projected(eta_protected) and normalize(eta_protected) == A("R", x)
    eta_unprotected = A("B", A("L", x), A("R", x))
    assert not projected(eta_unprotected)
    # Translation must not normalize a general active application.
    assert translate(A("Q", ZERO, a)) == A("Q", ZERO, a)
    assert translate(Rec(A("S", v), ZERO, a)) == Rec(A("S", v), ZERO, a)
    # Normalization itself need not commute syntactically with substitution.
    # The homomorphic translation, in contrast, must commute with it.
    open_call = Rec(A("S", v), x, a)
    assert normalize(subst(open_call, {"x": ZERO})) != subst(normalize(open_call), {"x": ZERO})

    numerical_native = 0
    for term in [generated(4, (x, a, z), False) for _ in range(100)]:
        normal = normalize(term)
        for i in range(4):
            env = {"x": i, "a": (i + 1) % 4, "z": (i + 2) % 4}
            assert evaluate(term, env) == evaluate(normal, env)
            numerical_native += 1

    virtual_base = virtual_step = raw_translation_values = 0
    for h in descriptors:
        for initial in range(4):
            assert evaluate(translate(Rec(h, ZERO, numeral(initial))), {}) == initial
            virtual_base += 1
            for counter in range(5):
                raw = Rec(h, numeral(counter), numeral(initial))
                returned = translate(raw)
                assert evaluate(raw, {}) == evaluate(returned, {})
                raw_translation_values += 1
                previous = evaluate(returned, {})
                following = evaluate(translate(Rec(h, numeral(counter + 1), numeral(initial))), {})
                expected = evaluate(translate(h), {"v": previous, "w": counter})
                assert following == expected
                virtual_step += 1

    family = []
    for m in range(25):
        counter_word = w
        for _ in range(m):
            counter_word = A("S", counter_word)
        h = A("L", A("B", v, counter_word))
        raw = Rec(h, x, a)
        assert normalize(h) == v and translate(raw) == a
        family.append({"m": m, "descriptor_size": size(h), "raw_call_size": size(raw), "translated_call_size": size(a)})

    count_descriptors = descriptors + [generated(4, (v, w), True) for _ in range(100)]
    pricing = pricing_diagnostics(count_descriptors)
    return {
        "status": "passed",
        "scope": "Exact finite syntax/count checks and bounded standard-N diagnostics; not a formal verification of the metatheorems.",
        "seed": seed,
        "normalizer_strategy": "Deterministic innermost-leftmost active rewriting; every accepted step strictly decreases full charged size; descriptions stay frozen.",
        "translation_strategy": "Bottom-up description translation plus description normalization, then identity/zero/counter dispatch; active applications are translated homomorphically.",
        "syntax_samples": len(raw_terms),
        "properties_checked_per_syntax_sample": ["translation_size_nonincrease", "dependency_rank_nonincrease", "canonical_description_formation", "translation_idempotence", "normalizer_size_nonincrease", "normalizer_idempotence", "projected_occurrence_preservation", "homomorphic_translation_substitution_commutation"],
        "normalization_rule_counts_on_samples": dict(sorted(all_rules.items())),
        "explicit_capture_and_protection_checks": "passed",
        "native_normalization_value_checks": numerical_native,
        "raw_translation_value_checks": raw_translation_values,
        "virtual_base_checks": virtual_base,
        "virtual_successor_checks": virtual_step,
        "virtual_equation_bounds": {"descriptors": len(descriptors), "initial_values": [0, 3], "counter_values": [0, 4]},
        "strict_omission_family": {"description": "h_m(v,w)=L(B(v,S^m(w))); the translated recursor is its initial argument", "tested_m": [0, 24], "instances": family},
        "pricing": pricing,
        "not_established_by_this_script": ["all-case mathematical correctness of normalization", "contextual induction for every formula index", "full intuitionistic bi-interpretability", "equiconsistency", "an encoding-independent minimality theorem"],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("normal_signature_checks.json"))
    args = parser.parse_args()
    report = run_checks()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "output": str(args.output.resolve()), "syntax_samples": report["syntax_samples"], "new_shared_core_nodes": report["pricing"]["new_nine_equation_core_shared_prefix"], "old_equally_shared_support_nodes": report["pricing"]["old_support_equally_shared_prefix"]}, sort_keys=True))


if __name__ == "__main__":
    main()
