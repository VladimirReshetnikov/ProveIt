#!/usr/bin/env python3
"""Independent exact-AST check for a canonical-signature strict family.
This checks syntax/size/equality factoring, not the full iPRA metatheorem.
No source archive's implementation is imported or run.
"""
from collections import Counter
from itertools import combinations
import json
from pathlib import Path

# Terms: ('var',name), ('0',), ('S',t), ('B',s,t), ('L',t),
# ('right',t), ('rec',frozen_descriptor,counter,initial).
def V(s): return ('var',s)
zero=('0',)
v,w=V('v'),V('w')
a,n,u,x,y=map(V,['a','n','u','x','y'])
def S(t): return ('S',t)
def B(s,t): return ('B',s,t)
def L(t): return ('L',t)
def Rt(t): return ('right',t)
def rec(h,s,t): return ('rec',h,s,t)
def Q(s,t): return rec(w,s,t)
def Z(s,t): return rec(zero,s,t)
def p(t): return Q(t,zero)
def I(s,t,b): return Q(Z(s,S(t)),b)
def eq(s,t): return ('eq',s,t)
def And(s,t): return ('and',s,t)
def Imp(s,t): return ('imp',s,t)
def K3(s,t,b): return ('K3',s,t,b)
def K4(s,t,b,c): return ('K4',s,t,b,c)
def quant(tag,vs,f):
 for name in reversed(vs): f=(tag,name,f)
 return f

def size(t):
 if t[0] in ('var','0'): return 1
 if t[0] in ('all','exists'): return 1+size(t[2])
 return 1+sum(size(z) for z in t[1:])

def achildren(t):
 if t[0] in ('var','0'): return ()
 if t[0]=='rec': return t[2:]
 return t[1:]

def rebuild(t,children):
 if t[0]=='rec': return ('rec',t[1],*children)
 return (t[0],*children)

def sub(t,env):
 if t[0]=='var': return env.get(t[1],t)
 if t[0]=='0': return t
 return rebuild(t,tuple(sub(c,env) for c in achildren(t)))

def dagger(t,st,counter,next_counter):
 if t==S(w): return next_counter
 if t==v: return st
 if t==w: return counter
 if t[0] in ('var','0'): return t
 return rebuild(t,tuple(dagger(c,st,counter,next_counter) for c in achildren(t)))

def old_body_norm(t):
 if t[0] in ('var','0'): return t
 z=rebuild(t,tuple(old_body_norm(c) for c in achildren(t)))
 if z[0]=='rec' and z[2]==zero: return old_body_norm(z[3])
 if z[0]=='rec' and z[1]==w and z[2][0]=='S': return old_body_norm(z[2][1])
 return z

def pair_norm(t):
 if t[0] in ('var','0'): return t
 z=rebuild(t,tuple(pair_norm(c) for c in achildren(t)))
 if z[0]=='L' and z[1][0]=='B': return pair_norm(z[1][1])
 if z[0]=='right' and z[1][0]=='B': return pair_norm(z[1][2])
 if z[0]=='B' and z[1][0]=='L' and z[2][0]=='right' and z[1][1]==z[2][1]:
  return pair_norm(z[1][1])
 return z

def active_list(t):
 out=[]; seen=set()
 def visit(z):
  for c in achildren(z): visit(c)
  if z[0]!='var' and z not in seen:
   seen.add(z);out.append(z)
 visit(t)
 return out

def counts(t):
 out=Counter()
 def visit(z):
  out[z]+=1
  for c in achildren(z):visit(c)
 visit(t)
 return out

def factor_size(E):
 assert E[0]=='eq'
 # An originally singly occurring term is never needed in a minimum:
 # eliminating its binding decreases size by exactly 5; dependencies
 # merely move its single occurrence to an earlier definition.
 terms=[]; seen=set(); occurrence=Counter()
 for side in E[1:]:
  occurrence.update(counts(side))
  for z in active_list(side):
   if z not in seen: seen.add(z);terms.append(z)
 terms=[z for z in terms if occurrence[z]>=2]
 best=size(E);best_bind=[]
 for mask in range(1,1<<len(terms)):
  chosen=[z for i,z in enumerate(terms) if mask>>i&1]
  bindings={z:V('fresh'+str(i)) for i,z in enumerate(chosen)}
  def replace(z,skip_root=False):
   if not skip_root and z in bindings:return bindings[z]
   if z[0] in ('var','0'):return z
   return rebuild(z,tuple(replace(c) for c in achildren(z)))
  cost=1+sum(size(replace(z)) for z in E[1:])
  cost+=sum(size(replace(z,True))+4 for z in chosen)
  if cost<best:best=cost;best_bind=chosen
 return best,best_bind

def factored_formula_size(F):
 if F[0]=='eq': return factor_size(F)[0]
 if F[0] in ('all','exists'):return 1+factored_formula_size(F[2])
 return 1+sum(factored_formula_size(c) for c in F[1:])

def native_helpers(F):
 """Translate helper calls only; the displayed h_m descriptors contain none."""
 if F[0] in ('var','0'): return F
 if F[0] in ('all','exists'): return (F[0],F[1],native_helpers(F[2]))
 if F[0]=='rec':
  args=tuple(native_helpers(c) for c in F[2:])
  if F[1]==w:return ('Q',*args)
  if F[1]==zero:return ('Z',*args)
  return ('rec',F[1],*args)
 return (F[0],*(native_helpers(c) for c in F[1:]))

def modules(h):
 H=size(h)
 D=(quant('all',['a'],eq(rec(h,zero,a),a)),
    quant('all',['a','n'],eq(rec(h,S(n),a),sub(h,{'v':rec(h,n,a),'w':n}))))
 G=(quant('all',['a','n','u'],K3(And(eq(n,zero),eq(u,a)),eq(rec(h,n,a),u),eq(rec(h,S(n),a),sub(h,{'v':u,'w':n})))),)
 T=(quant('all',['a','n'],quant('exists',['u'],And(Imp(eq(n,zero),eq(u,a)),quant('all',['x','y'],K4(And(eq(x,n),eq(y,u)),eq(rec(h,x,a),y),eq(x,S(n)),eq(y,dagger(h,u,n,x))))))),)
 F=(quant('all',['a','n'],eq(rec(h,n,a),I(n,a,dagger(h,rec(h,p(n),a),p(n),n)))),)
 Lmod=(quant('all',['a','n','u'],Imp(eq(p(n),u),eq(rec(h,n,a),I(n,a,dagger(h,rec(h,u,a),u,n))))),)
 N=(quant('all',['a','n'],quant('exists',['u'],quant('all',['x','y'],K4(And(eq(S(x),n),eq(y,u)),eq(rec(h,x,a),y),eq(x,n),eq(y,I(n,a,dagger(h,u,zero,n))))))),)
 return {'D':D,'G3':G,'T4':T,'F':F,'L':Lmod,'N4':N}

def main():
 rows=[]
 for m in [1,2,3,8,9,10,20,40]:
  tail=w
  for _ in range(m):tail=S(tail)
  h=L(B(v,tail)); H=size(h)
  assert H==m+4 and old_body_norm(h)==h and pair_norm(h)==v
  current=modules(h)
  raw={name:sum(size(f) for f in M) for name,M in current.items()}
  factored={name:sum(factored_formula_size(f) for f in M) for name,M in current.items()}
  expected={'D':4*m+31,'G3':3*m+33,'T4':2*m+39,'F':3*m+29,'L':3*m+34,'N4':2*m+38}
  assert raw==expected,(m,raw,expected)
  assert raw==factored,(m,raw,factored)
  native={name:sum(factored_formula_size(native_helpers(f)) for f in M)
          for name,M in current.items()}
  native_expected=dict(expected,F=3*m+26,L=3*m+31,N4=2*m+36)
  assert native==native_expected,(m,native,native_expected)
  if m>=10:assert min(native.values())==2*m+36
  old_min=min(factored.values())
  if m>=9:assert old_min==2*m+38
  old_call=rec(h,n,a)
  assert size(old_call)==m+7
  rows.append({'m':m,'H':H,'old_modules_after_exact_atomic_factoring':factored,
               'native_helper_benchmark_modules':native,
               'old_union_min':old_min,'new_module_cost':0,
               'old_call_size':size(old_call),'new_call_size':1,
               'new_normal_form':'v','old_normal_form_unchanged':True})
 out={'status':'passed','claim':'native projection beta removes entire recursor declaration and module',
      'families':rows,'limits':'Exact AST and finite arithmetic of costs; no full metatheorem formalization.'}
 path=Path(__file__).with_name('strict_family_results.json')
 path.write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
