REPRODUCIBLE CURRENT-DRAFT COMPARISON

Repository: VladimirReshetnikov/ProveIt
Pinned commit: 5516d2b87784c331887af7309579654c99838ba9
Requested directory: docs/drafts
Source retrieval date: 6 November 2026

WHAT IS INCLUDED

sources/ contains exact UTF-8 Python source bytes for 89 distinct candidate
acceptance programs, including all six main checkers. Copies are named by
SHA-256, eliminating duplicate files. Their combined source size is 390,351
bytes. provenance.json maps all 251 selected original archive members to
these hashes, records their metrics, and marks main, control/ablation, and
other inherited comparison candidates. Every main is also explicitly named.
The original ZIPs are not included. Their Git blob hashes, SHA-256 hashes,
sizes, names and repository paths are retained in the provenance.

The selection rule is deliberately transparent: take every .py ZIP member
containing the three literal strings "def infer(", "def check(" and
"json.load(". This is a conservative comparison census, not a soundness or
completeness certification. Some candidates are intentionally altered
controls or inherited copies; the census labels do not assert equivalence
of their interfaces, theory, or external dependencies. The six main programs
were additionally read as full standalone acceptance programs. In particular,
the reduced-kernel main admits native formulas directly, while other mains
include a public falsity alias or an explicit falsity bridge. Including this
smaller native-only interface makes the size target more demanding.

COUNTING METHOD

All complete source files are measured. Imports, formation checks, binding,
substitution, arithmetic axioms, proof rules, JSON input and CLI handling
are included. Python and its standard library are the common host runtime.
No generated proof or elaboration routine is counted as part of a checker
unless it is actually needed by that acceptance program.

raw_bytes: original file bytes, including comments and layout.
source_tokens: Python lexical tokens excluding comments, layout/end markers,
  and actual leading module/class/function docstrings.
ast_nodes: ast.walk count after removing those docstrings; includes operator,
  context and pattern nodes. This is a syntactic measure, not machine code.
normalized_bytes: bytes of ast.unparse of that docstring-free AST, plus one
  final newline. This removes layout/comment differences without shortening
  names or rewriting implementations.
normalized_tokens: significant lexical tokens of that normalized source.

Recorded runtime: Python 3.12.14. AST shape and ast.unparse may vary between
Python versions; raw bytes and source tokens are generally more stable.
No comparator is imported or executed by either script.

RUN OFFLINE

  python3 measure.py --output reproduced_metrics.json
  python3 measure.py /absolute/path/to/new_checker.py --output comparison.json

The optional candidate is measured by exactly the same function. Every
included snapshot is verified against its SHA-256 before measurement.
metrics.json records the supplied baseline results. On Python 3.12.14 the
main-checker coordinate minima are:

  raw_bytes            3088
  source_tokens         863
  ast_nodes             915
  normalized_bytes     2730
  normalized_tokens     864

The same minima hold over all 89 discovered source candidates. The minimum
in each coordinate may belong to a different checker; this is the finite
coordinatewise lower envelope, not an absolute shortest-program theorem.

REBUILD FROM ORIGINAL ZIP ARCHIVES

Put the six pinned ZIPs in a directory and run:

  python3 collect.py /path/to/archives --source-manifest source_manifest.json \
      --output /path/to/new/comparison

collect.py verifies every original Git blob SHA and size before collecting
members. It reads each exact member and preserves its bytes. It does not
extract arbitrary paths or execute any archive content. To measure that new
directory with this copy of measure.py, use --directory /path/to/new/comparison.

LIMITS

Finite source metrics do not prove universal minimality, theory equivalence,
soundness or completeness. The accompanying mathematical report and checker
audits must establish those separately. The candidate census deliberately
includes ambiguous controls instead of silently excluding small files.
