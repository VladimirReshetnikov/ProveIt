#!/usr/bin/env python3
"""Rebuild exact source snapshots from the six pinned original ZIP archives.

This script only reads ZIP members, hashes bytes and parses Python source.
It does not import or execute a predecessor checker or its build scripts.
Run it in a separate output directory if preserving the supplied census.
"""

import argparse
import hashlib
import json
from pathlib import Path
import zipfile

from measure import measure_bytes


def selected(source):
    # Freeze the transparent, conservative rule used in the initial census.
    # This is candidate discovery, never a proof of completeness or soundness.
    return all(text in source for text in ("def infer(", "def check(", "json.load("))


def member_role(name, main_member):
    if name == main_member:
        return "main"
    if "/controls/" in name or "/ablation/" in name:
        return "control_or_ablation"
    return "inherited_comparison_candidate"


def collect(archive_directory, source_manifest, output):
    pinned = json.loads(source_manifest.read_text())
    output.mkdir(parents=True, exist_ok=True)
    (output / "sources").mkdir(exist_ok=True)
    sources, members, mains, archives = {}, [], [], []
    for archive_index, item in enumerate(pinned["files"]):
        data = (archive_directory / item["name"]).read_bytes()
        git_sha = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if git_sha != item["sha"] or len(data) != item["size"]:
            raise ValueError("original archive mismatch: " + item["name"])
        draft = item["name"][:-4]
        main_member = draft + ("/code/checker.py" if "single_traversal" in draft
                               else "/checker.py")
        archives.append({**item, "sha256": hashlib.sha256(data).hexdigest()})
        with zipfile.ZipFile(archive_directory / item["name"]) as archive:
            for member in sorted(archive.namelist()):
                if not member.endswith(".py"):
                    continue
                body = archive.read(member)
                if not selected(body.decode("utf-8")):
                    continue
                metrics = measure_bytes(body)
                sha = metrics["sha256"]
                copy = "sources/" + sha + ".py"
                role = member_role(member, main_member)
                sources.setdefault(sha, {"sha256": sha, "copy": copy,
                                         "metrics": metrics, "roles": []})
                if role not in sources[sha]["roles"]:
                    sources[sha]["roles"].append(role)
                (output / copy).write_bytes(body)
                members.append({"archive": archive_index, "member": member,
                                "sha256": sha, "role": role})
                if member == main_member:
                    mains.append({"draft": draft, "archive": archive_index,
                                  "member": member, "sha256": sha})
    if len(mains) != len(archives):
        raise ValueError("one main checker per archive was not found")
    result = {
        "repository": pinned["repo"], "commit": pinned["commit"],
        "selection_rule": "Python members containing all literal strings: def infer( ; def check( ; json.load(",
        "status": "Conservative source-size census. Candidate selection and role labels do not certify soundness, completeness, interface equivalence, or absence of external dependencies. All detected source is counted even for ambiguous controls.",
        "archive_indexes": "Member archive fields index the following zero-based archive list.",
        "archives": archives, "main_checkers": mains,
        "sources": sorted(sources.values(), key=lambda item: item["sha256"]),
        "members": members,
    }
    (output / "provenance.json").write_text(json.dumps(result, indent=2) + "\n")
    (output / "source_manifest.json").write_bytes(source_manifest.read_bytes())
    return {"unique_sources": len(sources), "archive_members": len(members),
            "main_checkers": len(mains),
            "source_bytes": sum(item["metrics"]["raw_bytes"] for item in sources.values())}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive_directory", type=Path)
    parser.add_argument("--source-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    print(json.dumps(collect(arguments.archive_directory, arguments.source_manifest,
                             arguments.output), indent=2))
