#!/usr/bin/env python3
"""Reproduce a conservative source-size census without executing its checkers.

The common runtime is Python and its standard json/sys libraries. Every byte
of each supplied standalone source is charged; no imported local module is
silently excluded. Source tokens omit layout, comments and actual leading
module/class/function docstrings. AST nodes and normalized source are counted
after removing those same docstrings. ast.unparse is Python-version-sensitive.
"""

import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize


LAYOUT = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
          tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
OWNERS = (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)
METRICS = ("raw_bytes", "source_tokens", "ast_nodes", "normalized_bytes",
           "normalized_tokens")


def is_docstring(node):
    return (isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant)
            and isinstance(node.value.value, str))


class RemoveDocstrings(ast.NodeTransformer):
    def generic_visit(self, node):
        super().generic_visit(node)
        if isinstance(node, OWNERS) and node.body and is_docstring(node.body[0]):
            node.body = node.body[1:]
        return node


def significant_tokens(source, ignored_spans=()):
    count = 0
    for token in tokenize.generate_tokens(io.StringIO(source).readline):
        if token.type in LAYOUT:
            continue
        if any(start <= token.start and token.end <= end
               for start, end in ignored_spans):
            continue
        count += 1
    return count


def measure_bytes(data):
    source = data.decode("utf-8")
    tree = ast.parse(source)
    docstrings = [node.body[0] for node in ast.walk(tree)
                  if isinstance(node, OWNERS) and node.body
                  and is_docstring(node.body[0])]
    spans = [((node.lineno, node.col_offset),
              (node.end_lineno, node.end_col_offset)) for node in docstrings]
    tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(tree) + "\n"
    return {
        "sha256": hashlib.sha256(data).hexdigest(),
        "raw_bytes": len(data),
        "source_tokens": significant_tokens(source, spans),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "normalized_tokens": significant_tokens(normalized),
    }


def coordinate_minima(rows):
    return {key: min(row[key] for row in rows) for key in METRICS}


def census(directory):
    manifest = json.loads((directory / "provenance.json").read_text())
    results = []
    for item in manifest["sources"]:
        actual = measure_bytes((directory / item["copy"]).read_bytes())
        if actual["sha256"] != item["sha256"]:
            raise ValueError("source hash mismatch: " + item["copy"])
        results.append({"copy": item["copy"], **actual})
    by_hash = {row["sha256"]: row for row in results}
    primary = [{"draft": item["draft"], "member": item["member"],
                **by_hash[item["sha256"]]} for item in manifest["main_checkers"]]
    return {
        "python_version": sys.version.split()[0],
        "repository": manifest["repository"],
        "commit": manifest["commit"],
        "unique_candidate_sources": len(results),
        "archive_member_occurrences": len(manifest["members"]),
        "main_checkers": primary,
        "main_coordinate_minima": coordinate_minima(primary),
        "census_coordinate_minima": coordinate_minima(results),
        "sources": sorted(results, key=lambda row: (row["source_tokens"],
                                                    row["ast_nodes"], row["copy"])),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate", nargs="?", type=Path,
                        help="optional new standalone checker to compare")
    parser.add_argument("--directory", type=Path, default=Path(__file__).parent)
    parser.add_argument("--output", type=Path,
                        help="also save the JSON result to this explicit path")
    args = parser.parse_args()
    result = census(args.directory.resolve())
    if args.candidate:
        candidate = measure_bytes(args.candidate.read_bytes())
        result["candidate"] = {"path": str(args.candidate), **candidate}
        minima = result["census_coordinate_minima"]
        result["candidate_at_or_below_each_minimum"] = {
            key: candidate[key] <= minima[key] for key in METRICS}
        result["candidate_savings_against_coordinate_minima"] = {
            key: {"absolute": minima[key] - candidate[key],
                  "percent": 100 * (minima[key] - candidate[key]) / minima[key]}
            for key in METRICS}
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered)
    print(rendered, end="")


if __name__ == "__main__":
    main()
