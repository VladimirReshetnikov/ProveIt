#!/usr/bin/env python3
"""Recompute comparison figures and replay this package's verification."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    spec = importlib.util.spec_from_file_location('measure', ROOT / 'comparison/measure.py')
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    result = measure.census(ROOT / 'comparison')
    candidate = measure.measure_bytes((ROOT / 'checker.py').read_bytes())
    result['candidate'] = {'path': 'checker.py', **candidate}
    frontier = result['census_coordinate_minima']
    result['candidate_at_or_below_each_minimum'] = {
        key: candidate[key] <= frontier[key] for key in measure.METRICS}
    result['candidate_savings_against_coordinate_minima'] = {
        key: {'absolute': frontier[key] - candidate[key],
              'percent': 100 * (frontier[key] - candidate[key]) / frontier[key]}
        for key in measure.METRICS}
    if not all(result['candidate_at_or_below_each_minimum'].values()):
        raise ValueError('candidate no longer meets the stated comparison')
    (ROOT / 'comparison/results.json').write_text(json.dumps(result, indent=2) + '\n')
    macros = {
        'CandidateTokens': candidate['source_tokens'],
        'CandidateAST': candidate['ast_nodes'],
        'CandidateNormalizedBytes': candidate['normalized_bytes'],
        'CandidateRawBytes': candidate['raw_bytes'],
        'FrontierTokens': frontier['source_tokens'],
        'FrontierAST': frontier['ast_nodes'],
        'FrontierNormalizedBytes': frontier['normalized_bytes'],
        'FrontierRawBytes': frontier['raw_bytes'],
        'CensusCount': result['unique_candidate_sources'],
    }
    (ROOT / 'comparison/metrics_macros.tex').write_text(''.join(
        '\\newcommand{\\' + key + '}{' + f'{value:,}' + '}\n'
        for key, value in macros.items()))
    labels = ['Prefix', 'Reduced checker', 'Reduced kernel', 'Single traversal',
              'Unary existential', 'Uniform']
    rows = sorted(result['main_checkers'], key=lambda row: row['draft'])
    table = ['\\begin{tabular}{lrrrr}', '\\toprule',
             'Complete checker & Tokens & AST nodes & Norm. bytes & Raw bytes \\\\',
             '\\midrule']
    for label, row in zip(labels, rows, strict=True):
        nums = [row[key] for key in ('source_tokens', 'ast_nodes', 'normalized_bytes', 'raw_bytes')]
        table.append(label + ' & ' + ' & '.join(f'{v:,}' for v in nums) + ' \\\\')
    table += ['\\midrule', 'Current coordinate minima & ' + ' & '.join(
        f'{frontier[key]:,}' for key in ('source_tokens', 'ast_nodes', 'normalized_bytes', 'raw_bytes')) + ' \\\\',
        '\\textbf{This checker} & ' + ' & '.join('\\textbf{' + f'{candidate[key]:,}' + '}'
          for key in ('source_tokens', 'ast_nodes', 'normalized_bytes', 'raw_bytes')) + ' \\\\',
        '\\bottomrule', '\\end{tabular}']
    (ROOT / 'comparison/summary_table.tex').write_text('\n'.join(table) + '\n')
    fixtures = json.loads((ROOT / 'validation/fixture_manifest.json').read_text())
    for item in fixtures:
        path = ROOT / 'validation' / item['file']
        if hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
            raise ValueError('fixture hash mismatch: ' + item['name'])
    for program in ['validation/audit.py', 'validation/independent_binding.py']:
        path = ROOT / program
        if not path.is_file():
            raise FileNotFoundError(path)
        subprocess.run([sys.executable, str(path)], cwd=ROOT, check=True)
    baseline = ROOT / ('comparison/sources/'
        '76f05776e72c22ff4e7dd09d002c0c55a51eaca204b66e5a9e5e01764ecd9aea.py')
    independent = ROOT / 'validation/independent'
    subprocess.run([sys.executable, str(independent / 'audit.py'),
                    str(ROOT / 'checker.py'), str(baseline),
                    '--output', str(independent)], cwd=ROOT, check=True)
    print(json.dumps({'candidate': candidate,
                      'frontier': frontier,
                      'all_comparison_coordinates_passed': True}, indent=2))


if __name__ == '__main__':
    main()
