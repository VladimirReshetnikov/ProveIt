A SMALLER COMPLETE CHECKER FOR INTUITIONISTIC PRA
Prepared for Vladimir Reshetnikov, 6 November 2026
================================================

Start with report.pdf. Its complete source is report.tex, with generated
comparison/metrics_macros.tex, comparison/summary_table.tex, and
validation/summary.tex. The entire trusted acceptance program is checker.py.

RESULT

The complete checker contains 817 significant Python source tokens,
871 executable AST nodes, 2,650 normalized bytes, and 2,975 raw bytes.
The coordinatewise minima of the six current draft checkers are
863 tokens, 915 AST nodes, 2,730 normalized bytes, and 3,088 raw bytes.
The same minima hold in the extended 89-source conservative census.
The figures include syntax validation, binding operations, inference and
arithmetic schemas, public falsity conversion, statement checks, imports,
JSON input, and command-line result/error handling.

This is a modest, measured reduction in a complete implementation of the
existing unary-existential calculus. The mathematical basis is credited
to the draft series. This iteration combines its unary logical basis,
finite-prefix substitutions, and shared syntax traversal, then factors
repeated identity-normalization calls into a thin helper. There is one
recursive syntax traversal and no hidden trusted preprocessor or theorem
oracle. An absolute globally shortest checker is not claimed.

THEORY

One number sort. Terms: variables, 0, successor, initialized recursion
R(n,a;u,k.h). Canonical formulas: s=t; Pi_x(A;B)=forall x(A->B);
E_x A=exists x A. Public falsity has an explicit bridge to 0=S0.

Six primitive logical inference patterns: hypotheses; Pi introduction
and elimination; witnessed existential introduction and existential
elimination; equality replacement. Nonlogical schemas: the two recursion
equations and one numerical schema giving induction for literal equations
and zero/successor cases for all other formulas. The report lists every
rule and side condition, derives full intuitionistic logic and
quantifier-free induction, and proves ordinary whole-domain
bi-interpretability with full first-order iPRA. Internal recursion
uniqueness establishes the round trips at arbitrary, including
nonstandard, arguments. The archive includes Further research questions.

RUN

Python 3.10 or newer; standard library only. Measurements were made with
Python 3.12.14; AST counts and ast.unparse can vary across Python versions.

  python3 reproduce.py
  python3 checker.py examples/reflexivity.json
  python3 checker.py examples/addition_induction.json
  python3 checker.py examples/quantified_explosion.json
  python3 checker.py examples/reject_quantified_induction.json

The positive examples print ACCEPT and exit 0. The deliberate negative
example prints REJECT and exits 1. A certificate's assumptions must be
empty to certify an unconditional theorem. A certificate with nonempty
assumptions certifies a sequent. Free numerical parameters are allowed.

REBUILD

  python3 build.py

Requires pdfLaTeX and the standard packages listed in report.tex.
If an installed TeX tree lacks its prebuilt pdflatex format, the builder
initializes that format in a temporary directory using the installed files.
This runs verification, compiles three passes, checks for overfull boxes
and unresolved references, refreshes SHA256SUMS.txt, and creates the ZIP
beside this directory. It also copies the PDF beside the directory.
Use --skip-tests only after the exact current sources have been verified.
Use --package-only to refresh the archive after an already completed
compilation and visual review. The original ZIPs are not needed to
reproduce comparison counts; exact counted source snapshots are included.

SOURCE SNAPSHOT

Repository: VladimirReshetnikov/ProveIt
Commit: 5516d2b87784c331887af7309579654c99838ba9
Directory: docs/drafts

All six downloaded archive bytes were verified against their Git blob
identities. comparison/source_manifest.json records that evidence.
comparison/provenance.json maps original archive members to the included
89 deduplicated exact source snapshots. The conservative census does not
claim that every inherited control is independently sound and complete.
The six main complete checkers are separately identified.

VALIDATION

The package replays 176 inherited fixtures (115 accepted, 61 rejected),
98 further malformed-input and rule-boundary trials, and 352 command-line
invocations including optimized Python. It compares 10,000 finite
substitutions with an independently implemented fresh-symbol oracle.
An additional independent review targets concrete soundness boundaries.
The respective scripts and result records are in validation/.

One certificate-interface difference is deliberate: the unary baseline
accepted a Boolean alias in a hypothesis key and returned the canonical
stored assumption. This was sound. The new checker validates the key and
rejects that malformed alias. The theory and all well-formed derivations
are preserved. See validation/fixture_manifest.json.

The metatheory has written proofs, not a Lean/Rocq formalization. Finite
tests do not replace those proofs. Large finite certificates may exhaust
host resources. No acceptance gate in checker.py depends on assert.

CONTENTS

  report.pdf, report.tex       Complete report and rebuildable source
  checker.py                  Complete trusted acceptance program
  FORMAT.txt                  Syntax, scopes, schemas, certificate format
  examples/                   Convenient positive and negative examples
  validation/                 Regression corpus, two audits, results
  controls/                   Matched implementation controls and metrics
  comparison/                 Exact baseline sources, provenance, counter
  reproduce.py, build.py       Reproduction and packaging
  SHA256SUMS.txt               Digests for all other packaged files

ATTRIBUTION

The proof basis and its metatheory develop the supplied ProveIt drafts,
especially the unary-existential, prefix, uniform, and single-traversal
proposals. They are not presented as newly discovered mathematics.
See report.pdf's sources and attribution section for precise scope.
