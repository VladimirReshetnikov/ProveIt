#!/usr/bin/env python3
"""Focused independent review of the frozen unified iPRA checker.

Expected sequents below are constructed directly; no candidate traversal,
inference routine or proof-builder is used to calculate an expected goal.
The targeted risks are grammar/type confusion, unused malformed terms,
capture beneath both binder kinds, escaping existential witnesses,
quantified induction, and the public falsity boundary. This is finite
adversarial evidence, not a machine-checked soundness proof.
"""

import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys


FROZEN_SHA256 = "2e91dd0c7ca78da9d15c6857c71c7eee082ef636d25d32cfceb8454d6f112e5e"
BASELINE_SHA256 = "76f05776e72c22ff4e7dd09d002c0c55a51eaca204b66e5a9e5e01764ecd9aea"
EXPECTED_ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError)


def eq(a, b):
    return ["=", a, b]


def rec(n, a, h):
    return ["r", n, a, h]


def pi(a, b):
    return ["pi", a, b]


def ex(a):
    return ["ex", a]


def hyp(a):
    return ["hyp", a]


T = eq(-1, -1)
D = eq(-1, ["s", -1])
B = ["false"]


def cases():
    result = []

    def add(name, accepted, data, reason, cli=False):
        result.append({"name": name, "accepted": accepted, "certificate": data,
                       "reason": reason, "cli": cli})

    add("closed_recursion_zero", True,
        [[], eq(rec(-1, -1, 0), -1), ["rec", rec(-1, -1, 0)]],
        "A basic closed arithmetic axiom is accepted.", True)
    add("unproved_falsity", False, [[], B, hyp(B)],
        "Normalization is not a proof of the normalized formula.", True)
    add("canonical_bottom_assumption", True, [[B], D, hyp(B)],
        "The public alias and its arithmetic representative agree.")
    add("bottom_guard_and_key", True, [[], pi(B, B), ["pi", B, hyp(B)]],
        "A source alias is normalized in the goal, guard and hypothesis key.")
    add("bottom_under_existential", True, [[B], ex(B), ["pack", -1, hyp(B)]],
        "The alias is normalized beneath an existential proof binder.")
    add("falsity_not_a_term", False, [[T], ex(T), ["pack", B, hyp(T)]],
        "Formula normalization cannot smuggle falsity into a numerical witness.", True)

    for name, bad in (("boolean", False), ("floating", 0.0),
                      ("negative_index", -2), ("unknown_tag", ["unknown", -1]),
                      ("unhashable_tag", [["s"], -1]),
                      ("term_with_formula_child", ["s", T])):
        add("unused_witness_" + name, False,
            [[T], ex(T), ["pack", bad, hyp(T)]],
            "Even an unused existential witness must be a well-formed term.",
            name in ("boolean", "unhashable_tag"))
    for name, bad in (("formula", T), ("bottom", B), ("boolean", True),
                      ("bad_arity", ["r", -1, -1])):
        r = rec(-1, -1, bad)
        add("unused_recursion_body_" + name, False,
            [[], eq(r, -1), ["rec", r]],
            "The zero equation must validate its unused recursion body.")
    add("recursion_counter_variable", False,
        [[], eq(rec(0, -1, 0), -1), ["rec", rec(0, -1, 0)]],
        "Only zero or an explicit successor is a computation-axiom counter.")
    add("extra_equation_child", False,
        [[["=", -1, -1, -1]], ["=", -1, -1, -1], hyp(["=", -1, -1, -1])],
        "Strict constructor arity is checked at the external context.")
    add("wrong_formula_sort", False, [[0], 0, hyp(0)],
        "A numerical variable is not a formula.")
    add("malformed_hypothesis_alias", False,
        [[eq(0, -1)], eq(0, -1), hyp(eq(False, -1))],
        "Python Boolean equality must not bypass formula validation at keys.")
    add("extra_proof_field", False, [[T], T, ["hyp", T, T]],
        "A proof record with an extra argument is not another inference rule.")
    add("extra_envelope_field", False, [[], T, hyp(T), 0],
        "The JSON sequent envelope has exactly three fields.")

    identity = pi(eq(0, 0), eq(0, 0))
    add("guarded_identity", True,
        [[], identity, ["pi", eq(0, 0), hyp(eq(0, 0))]],
        "A fresh number and its local guard may be abstracted.")
    add("pi_retained_parameter_capture", False,
        [[eq(0, -1)], pi(T, eq(0, -1)), ["pi", T, hyp(eq(0, -1))]],
        "The retained free parameter is index 1 beneath a fresh Pi binder.")

    hidden = eq(rec(-1, -1, 2), -1)
    hidden_lifted = eq(rec(-1, -1, 3), -1)
    add("pi_lifts_parameter_beneath_recursion", True,
        [[hidden], pi(T, hidden_lifted), ["pi", T, hyp(hidden_lifted)]],
        "A retained free parameter inside a two-place recursion body is lifted.")
    add("pi_capture_beneath_recursion", False,
        [[hidden], pi(T, hidden), ["pi", T, hyp(hidden)]],
        "The same hidden parameter cannot become the fresh Pi eigenvariable.")

    existential = ex(eq(0, 0))
    add("existential_witness_escape", False,
        [[existential], eq(0, 0),
         ["use", hyp(existential), eq(0, 0), hyp(eq(0, 0))]],
        "An opened witness must not become a free variable of the conclusion.", True)
    add("existential_escape_beneath_recursion", False,
        [[ex(hidden)], hidden, ["use", hyp(ex(hidden)), hidden, hyp(hidden)]],
        "Witness escape is also rejected when hidden beneath a recursion binder.")
    nested = pi(T, eq(1, 1))
    add("existential_escape_beneath_pi", False,
        [[ex(nested)], nested, ["use", hyp(ex(nested)), nested, hyp(nested)]],
        "A witness occurring under another logical binder still cannot escape.")
    add("existential_elimination_closed_goal", True,
        [[ex(T)], T, ["use", hyp(ex(T)), T, hyp(T)]],
        "An opened existential may discharge to a witness-independent conclusion.")
    add("witness_equation_parameter_lift", True,
        [[], ex(eq(0, 1)), ["pack", 0, hyp(eq(0, 1))]],
        "The witness value is a retained parameter and is lifted in y=t.")
    add("witness_equation_capture", False,
        [[], ex(eq(0, 0)), ["pack", 0, hyp(eq(0, 0))]],
        "Packing a retained parameter does not assume that the new witness equals itself.")

    equality = eq(0, 1)
    template = pi(T, eq(1, 0))
    transported = pi(T, eq(2, 0))
    add("transport_beneath_pi", True,
        [[equality, template], transported,
         ["use", hyp(equality), template, hyp(template)]],
        "Replacement terms are lifted below Pi; its bound variable stays bound.")
    add("transport_pi_capture", False,
        [[equality, template], template,
         ["use", hyp(equality), template, hyp(template)]],
        "Transport must replace the distinguished outer slot beneath Pi.")
    add("transport_beneath_recursion", True,
        [[equality, hidden], hidden_lifted,
         ["use", hyp(equality), hidden, hyp(hidden)]],
        "The distinguished replacement slot is lifted through two recursion binders.")
    add("transport_recursion_capture", False,
        [[equality, hidden], hidden,
         ["use", hyp(equality), hidden, hyp(hidden)]],
        "A replacement cannot capture either recursion-local variable.")

    # h(v,u) is an inner initialized recursion whose update uses the outer
    # state, hence index 2 inside the inner body. The outer step substitutes
    # simultaneously u := R(x,b,h), v := x. Beneath the inner binder pair,
    # R(x,b,h) must become R(index 2,index 3,h).
    body = rec(1, 0, ["s", 2])
    outer = rec(["s", 0], 1, body)
    previous = rec(0, 1, body)
    next_value = rec(0, previous, ["s", rec(2, 3, body)])
    add("simultaneous_recursion_under_nested_body", True,
        [[], eq(outer, next_value), ["rec", outer]],
        "The recursive value and predecessor are simultaneous substitutions, lifted under nested recursion.")
    captured = rec(0, previous, ["s", previous])
    add("nested_recursion_replacement_capture", False,
        [[], eq(outer, captured), ["rec", outer]],
        "An unlifted recursive value under an inner recursion body must be rejected.")

    # Each expected schema is handwritten from the named formula
    # forall x (P(0) -> forall z (forall y(H(y) -> P(Sy)) -> P(x))).
    atomic = eq(0, 1)
    atomic_schema = pi(eq(-1, 1),
                       pi(pi(eq(0, 3), eq(["s", 0], 3)), eq(1, 2)))
    add("equation_induction_with_parameter", True,
        [[], atomic_schema, ["nat", atomic]],
        "Equation induction retains a numerical parameter through all three binders.", True)
    for name, matrix, base, successor, conclusion in (
        ("existential", ex(eq(0, 1)), ex(eq(0, -1)),
         ex(eq(0, ["s", 1])), ex(eq(0, 2))),
        ("pi", pi(T, eq(1, 0)), pi(T, eq(-1, 0)),
         pi(T, eq(["s", 1], 0)), pi(T, eq(2, 0))),
    ):
        schema = pi(base, pi(pi(base, successor), conclusion))
        forged = pi(base, pi(pi(matrix, successor), conclusion))
        add(name + "_numerical_cases", True, [[], schema, ["nat", matrix]],
            "A quantified formula receives the fixed base guard, never its own induction hypothesis.")
        add(name + "_forbidden_quantified_induction", False,
            [[], forged, ["nat", matrix]],
            "An equational matrix does not make the enclosing quantified formula an equation.", True)
    return result


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def accepts(module, data):
    try:
        return module.check(copy.deepcopy(data)) is True
    except EXPECTED_ERRORS:
        return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checker", type=Path)
    parser.add_argument("baseline", type=Path)
    parser.add_argument("--output", type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    digest = hashlib.sha256(args.checker.read_bytes()).hexdigest()
    if digest != FROZEN_SHA256:
        raise ValueError("candidate differs from the frozen audited source")
    if hashlib.sha256(args.baseline.read_bytes()).hexdigest() != BASELINE_SHA256:
        raise ValueError("baseline differs from the pinned unary-existential source")
    candidate = load_module("review_candidate", args.checker)
    baseline = load_module("review_baseline", args.baseline)
    args.output.mkdir(parents=True, exist_ok=True)
    folder = args.output / "certificates"
    folder.mkdir(exist_ok=True)
    report = []
    for item in cases():
        path = folder / (item["name"] + ".json")
        path.write_text(json.dumps(item["certificate"]) + "\n")
        actual = accepts(candidate, item["certificate"])
        if actual != item["accepted"]:
            raise AssertionError((item["name"], "unexpected candidate outcome", actual))
        replayed = None
        if item["accepted"]:
            replayed = accepts(baseline, item["certificate"])
            if not replayed:
                raise AssertionError((item["name"], "baseline replay rejected"))
        executions = []
        if item["cli"]:
            for flags in ([], ["-O"]):
                completed = subprocess.run(
                    [sys.executable, *flags, str(args.checker), str(path)],
                    text=True, capture_output=True, timeout=10)
                wanted = (0, "ACCEPT\n") if item["accepted"] else (1, "REJECT\n")
                if (completed.returncode, completed.stdout) != wanted or completed.stderr:
                    raise AssertionError((item["name"], flags, completed))
                executions.append({"optimized": bool(flags), "passed": True})
        report.append({"name": item["name"], "expected_accept": item["accepted"],
                       "actual_accept": actual, "reason": item["reason"],
                       "baseline_replay": replayed, "cli": executions})
    if hashlib.sha256(args.checker.read_bytes()).hexdigest() != digest:
        raise ValueError("candidate changed during the audit")
    result = {
        "checker_sha256": digest, "baseline_sha256": BASELINE_SHA256,
        "python_version": sys.version.split()[0],
        "cases": len(report),
        "accepted": sum(row["actual_accept"] for row in report),
        "rejected": sum(not row["actual_accept"] for row in report),
        "baseline_positive_replays": sum(row["baseline_replay"] is True for row in report),
        "cli_executions": sum(len(row["cli"]) for row in report),
        "all_passed": True,
        "limitation": "Focused finite adversarial tests, plus manual invariant review; no mechanized universal soundness proof.",
        "results": report,
    }
    (args.output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "results"}, indent=2))


if __name__ == "__main__":
    main()
