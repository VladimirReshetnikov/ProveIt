"""Recheck frozen proof fixtures, typed syntax, and the command-line boundary."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('kernel', ROOT.parent / 'checker.py')
kernel = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kernel)
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError)


def accepted(data):
    try:
        return kernel.check(data) is True
    except ERRORS:
        return False


def main():
    records = json.loads((ROOT / 'fixture_manifest.json').read_text())
    counts = {True: 0, False: 0}
    for record in records:
        data = json.loads((ROOT / record['file']).read_text())
        result = accepted(data)
        assert result == record['accepted'], record['name']
        counts[result] += 1
    # Complete malformed JSON-domain values, substituted into otherwise
    # valid sequent/annotation locations. No source-level eval is used.
    values = [None, True, False, 0.0, -1.0, '', 'false', {}, {'a': 0}, [],
              ['s'], ['r', -1, -1], ['=', -1], ['ex'], ['pi', ['=', 0, 0]],
              ['ex', ['=', 0, 0], ['=', 0, 0]], ['unknown', -1],
              [['s'], -1], ['s', ['=', 0, 0]], ['=', ['ex', ['=', 0, 0]], -1],
              ['r', -1, -1, ['false']], -2, -100]
    rejected = 0
    valid = [[], ['pi', ['=', 0, 0], ['=', 0, 0]],
             ['pi', ['=', 0, 0], ['hyp', ['=', 0, 0]]]]
    assert accepted(valid)
    for bad in values:
        trials = [
            [[], bad, ['hyp', bad]],
            [[bad], bad, ['hyp', bad]],
            [[], ['ex', ['=', 0, 0]], ['pack', bad, ['hyp', ['=', 0, 0]]]],
            [[], ['=', -1, -1], ['rec', ['r', -1, -1, bad]]],
        ]
        for trial in trials:
            assert not accepted(trial), trial
            rejected += 1
    # Root proof annotation uses genuine zero rather than Python's Boolean alias.
    for bad in (False, True, 0.0, 1.0):
        n = int(bad)
        trial = [[['=', n, -1]], ['=', n, -1], ['hyp', ['=', bad, -1]]]
        assert not accepted(trial), trial
        rejected += 1
    # A successor step with a quantified induction hypothesis must be rejected.
    for constructor in ('pi', 'ex'):
        matrix = [constructor, ['=', 0, 1], ['=', 0, 1]] if constructor == 'pi' else [constructor, ['=', 0, 1]]
        malformed = copy.deepcopy(kernel.infer(['nat', matrix], []))
        # This deliberate change attempts to replace the fixed-base step guard.
        malformed[2][1][1] = kernel.walk(matrix, (2,))
        assert not accepted([[], malformed, ['nat', matrix]])
        rejected += 1
    cli = []
    for flag in ([], ['-O']):
        for record in records:
            p = subprocess.run([sys.executable, *flag, str(ROOT.parent / 'checker.py'),
                                str(ROOT / record['file'])], capture_output=True, text=True)
            expect = record['accepted']
            assert (p.returncode == 0) == expect, (flag, record['name'], p.stderr)
            assert p.stdout == ('ACCEPT\n' if expect else 'REJECT\n')
            cli.append({'optimized': bool(flag), 'name': record['name'], 'accepted': expect})
    report = {'checker_sha256': hashlib.sha256((ROOT.parent / 'checker.py').read_bytes()).hexdigest(),
              'fixtures': len(records), 'accepted': counts[True], 'rejected': counts[False],
              'extra_negative_trials': rejected, 'cli_trials': len(cli),
              'all_passed': True,
              'qualification': 'Finite regression evidence; not a formal proof of the implementation.'}
    (ROOT / 'audit_results.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
