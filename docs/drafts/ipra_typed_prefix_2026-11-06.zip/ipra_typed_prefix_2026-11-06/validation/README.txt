VALIDATION PROVENANCE AND SCOPE
===============================

audit.py checks 176 stored certificate fixtures and 98 additional negative
trials. It also runs every fixture through the actual CLI ordinarily and
with -O (352 invocations). The corpus is copied byte-for-byte from the
validation/certificates directory in the pinned unary-existential archive:

  docs/drafts/ipra_unary_existential_2026-11-06.zip
  commit 5516d2b87784c331887af7309579654c99838ba9

The per-file original content hashes are retained in fixture_manifest.json.
One expectation is intentionally changed: stored_hypothesis_boolean_alias
is rejected by the new strictly validated key interface. The original
baseline's lookup was sound because it returned the canonical stored
assumption; this change is not advertised as repairing an unsound theory.

independent_binding.py uses a fresh-symbol oracle. It decodes number indices
to distinct bound-symbol objects, replaces free symbols, and re-encodes.
The candidate supplies no shifting or substitution routine to that oracle.
The fixed seed makes its 2,000 trees and 10,000 substitutions reproducible.

independent/audit.py and independent/REVIEW.txt are a separately authored
manual invariant review and focused 43-certificate audit. Expected formulas
are handwritten, without using the candidate to compute them. Every positive
case replays in the exact preserved unary baseline; selected cases exercise
the actual CLI in ordinary and optimized mode. Hashes pin both implementations.

From the package root, run python3 reproduce.py to run all of this and
recompute the comparison. No original ZIP archive or network is needed.

These overlapping finite audits are implementation evidence, not a
formalization of universal soundness, completeness, or bi-interpretability.
The latter arguments are written in report.pdf/report.tex. No Lean/Rocq
formalization of Python semantics or the metatheory is claimed.

pdf_build.json records clean compilation. pdf_review.json records visual
inspection of the final PDF; temporary page images are not part of the package.
