#!/usr/bin/env python3
"""Rebuild the PDF and ZIP with standard Python and pdfLaTeX."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent


def members():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts and p.suffix != '.pyc'
                  and p.name != 'SHA256SUMS.txt')


def package():
    paths = members()
    (ROOT / 'SHA256SUMS.txt').write_text(''.join(
        hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(ROOT).as_posix() + '\n'
        for p in paths))
    archive = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in [*paths, ROOT / 'SHA256SUMS.txt']:
            z.write(p, (Path(ROOT.name) / p.relative_to(ROOT)).as_posix())
    shutil.copy2(ROOT / 'report.pdf', ROOT.with_suffix('.pdf'))
    print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
                      'members': len(paths) + 1}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skip-tests', action='store_true')
    parser.add_argument('--package-only', action='store_true')
    args = parser.parse_args()
    if not args.package_only:
        if not args.skip_tests:
            subprocess.run([sys.executable, str(ROOT / 'reproduce.py')], cwd=ROOT, check=True)
        environment = dict(os.environ, SOURCE_DATE_EPOCH='1793966400')
        with tempfile.TemporaryDirectory(prefix='ipra_tex_') as work:
            lookup = subprocess.run(['kpsewhich', 'pdflatex.fmt'], env=environment,
                                    capture_output=True, text=True)
            if not lookup.stdout.strip():
                initialized = subprocess.run(
                    ['pdftex', '-ini', '-etex', '-interaction=nonstopmode', '-halt-on-error',
                     '-jobname=pdflatex', '-progname=pdflatex', '-output-directory=' + work,
                     'pdflatex.ini'], cwd=work, env=environment,
                    capture_output=True, text=True)
                if initialized.returncode:
                    print(initialized.stdout[-10000:])
                    raise RuntimeError('could not initialize the installed LaTeX format')
                environment['TEXFORMATS'] = work + os.pathsep + environment.get('TEXFORMATS', '')
            for _ in range(3):
                p = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                                    '-file-line-error', '-output-directory=' + work, 'report.tex'],
                                   cwd=ROOT, env=environment, capture_output=True, text=True)
                if p.returncode:
                    print(p.stdout[-10000:])
                    raise RuntimeError('pdfLaTeX failed')
            log = (Path(work) / 'report.log').read_text(errors='replace')
            diagnostics = [line for line in log.splitlines()
                           if 'Overfull' in line or 'undefined' in line
                           or 'Rerun to get cross-references right' in line]
            if diagnostics:
                raise RuntimeError('PDF diagnostics:\n' + '\n'.join(diagnostics))
            shutil.copy2(Path(work) / 'report.pdf', ROOT / 'report.pdf')
            (ROOT / 'validation/pdf_build.json').write_text(json.dumps(
                {'passes': 3, 'engine': 'pdfLaTeX', 'overfull_or_unresolved_diagnostics': diagnostics,
                 'note': 'Visual review is separately recorded in pdf_review.json.'}, indent=2) + '\n')
    package()


if __name__ == '__main__':
    main()
