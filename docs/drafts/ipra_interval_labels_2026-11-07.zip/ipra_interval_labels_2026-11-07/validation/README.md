# Candidate validation

Run from any working directory with Python 3.10 or later:

    python3 validation/verify.py

By default the candidate is `../checker.py` relative to this folder. An alternate location is accepted via `--candidate /absolute/path/checker.py`. Use `--results /absolute/path/results.json` to choose the output receipt.

The production checker imports none of this validation code. The packet oracle uses separate term and formula traversals, explicit named inference rules, and explicit arity checks; it does not use the production table, sort/depth packing, or matcher. `semantic_oracle.py` is inherited unchanged from the truth-completion draft. `interval_oracle.py` widens its scalar branch and zero-counter check to the admitted numerical labels, and the script verifies this exact change.

The 147 bundled positive packets come from truth-completion's translated scalar fixtures. Their source names and hashes are recorded separately. Nine complete root checker programs at repository commit `ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a` are frozen in `references/` and hash-checked before measurement. The source metrics helper is inherited unchanged. The shared conventional driver and prefix-core boundaries are explicit in `verify.py`.

Finite tests support the implementation analysis; they do not constitute a formal proof of soundness, completeness, or bi-interpretability. Those rely on the paper's metatheory. In particular, successful raw packets need not have identical execution traces after flooring labels: alias coalescing may close hypotheses earlier. The retraction claim is about openings and decoded derivations.
