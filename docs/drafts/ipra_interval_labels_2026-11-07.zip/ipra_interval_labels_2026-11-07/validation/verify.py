"""Independent audit of interval-leaf scalar iPRA candidate integrations.

Temporary research validation only: production candidates import no part of
this script. Bounded tests supplement, but do not replace, soundness proofs.
"""
import ast
import argparse
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import importlib.util
import json
from math import isfinite, floor, nextafter, inf
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import types

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--candidate', type=Path, default=HERE.parent / 'checker.py')
parser.add_argument('--results', type=Path, default=HERE / 'audit_candidate_results.json')
audit_options = parser.parse_args()
OUT = audit_options.results.resolve().parent
OUT.mkdir(parents=True, exist_ok=True)


def module_from(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


meter = module_from(HERE / 'source_measure.py', 'candidate_measure')
PRIMARY = ['normalized_tokens', 'ast_nodes', 'normalized_bytes']
DRIVER = """
try:
    take = json.load(open(sys.argv[1])).pop
    accepted = check(take(), [])
except:
    accepted = False
print('ACCEPT' if accepted else 'REJECT')
sys.exit(not accepted)
"""

def common_driver(path):
    tree = ast.parse(path.read_text())
    cut = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Try))
    tree.body = tree.body[:cut] + ast.parse(DRIVER).body
    with tempfile.TemporaryDirectory() as temporary:
        target = Path(temporary) / 'control.py'
        target.write_text(ast.unparse(tree) + '\n')
        return meter.metrics(target)

shared = types.SimpleNamespace(PRIMARY=PRIMARY, common_driver=common_driver)
oracle_source = (HERE / 'semantic_oracle.py').read_text()
oracle_module = types.ModuleType('independent_oracle')
exec(compile(oracle_source, 'independent_oracle', 'exec'), oracle_module.__dict__)
wide_oracle = types.ModuleType('independent_wide_oracle')
wide_source = oracle_source.replace('type(value) is int', 'type(value) is not list')
wide_source = wide_source.replace('type(count) is int and count==0', 'type(count) is not list and count==0')
exec(compile(wide_source, 'independent_wide_oracle', 'exec'), wide_oracle.__dict__)
assert wide_source == (HERE / 'interval_oracle.py').read_text()


def prefix_tree(path):
    tree = ast.parse(path.read_text())
    cut = next(i for i, n in enumerate(tree.body) if isinstance(n, ast.Try))
    return ast.Module(body=tree.body[:cut], type_ignores=[])


def load(path):
    mod = types.ModuleType(path.stem)
    exec(compile(prefix_tree(path), str(path), 'exec'), mod.__dict__)
    return mod


def run(module, packet):
    module.k = 0
    stack = deepcopy(packet)
    try:
        module.take = stack.pop
        verdict = bool(module.check(stack.pop(), []))
        error = None
    except Exception as exc:
        verdict = False
        error = type(exc).__name__
    return {'accepted': verdict, 'final_k': module.k,
            'remaining': len(stack) if type(stack) is list else None, 'error': error}


def norm_bool(value):
    if type(value) is bool:
        return int(value)
    if type(value) is list:
        return [norm_bool(v) for v in value]
    return value


def paths(value):
    yield ()
    if type(value) is list:
        for i, child in enumerate(value):
            for p in paths(child):
                yield (i,) + p


rng = random.Random(261107365)
leaves = [None, True, False, -99, -5, -2, -1, 0, 1, 2, 3, 7,
          -2.5, -1.5, -0.5, 0.0, 0.5, 1.5, 2.5, 3.5,
          [], [0], [1], [0, 0], [[0], 0], [[0], [0], [0]], {}, '', 'x', 'xxx']


def mutate(value):
    answer = deepcopy(value)
    path = rng.choice(list(paths(answer)))
    new = deepcopy(rng.choice(leaves))
    if not path:
        return new
    parent = answer
    for index in path[:-1]:
        parent = parent[index]
    parent[path[-1]] = new
    return answer


def replace_bool(value, rate=0.6):
    if type(value) is int and value in (0, 1) and rng.random() < rate:
        return bool(value)
    if type(value) is list:
        return [replace_bool(v, rate) for v in value]
    return value


def replace_fraction(value, rate=0.35):
    if type(value) is int and rng.random() < rate:
        # Keep exact zeros half the time so arithmetic base traces survive.
        return float(value) if rng.random() < .5 else value + .25
    if type(value) is list:
        return [replace_fraction(v, rate) for v in value]
    return value


def measured(path):
    result = meter.metrics(path)
    with tempfile.TemporaryDirectory() as tmp:
        core = Path(tmp) / 'core.py'
        core.write_text(ast.unparse(prefix_tree(path)) + '\n')
        prefix = meter.metrics(core)
    result.pop('core', None)
    result['core_with_imports_globals'] = {k: prefix[k] for k in shared.PRIMARY}
    result['common_conventional_driver'] = {k: shared.common_driver(path)[k] for k in shared.PRIMARY}
    return result


programs = {
    'fallback': HERE / 'references/fallback.py',
    'partition': audit_options.candidate.resolve(),
}
loaded = {name: load(path) for name, path in programs.items()}
source = load(HERE / 'references/truth_scalar.py')
positive = json.loads((HERE / 'positive_scalar_packets.json').read_text())
fixed = {
    'unsafe_introduction': ([0, [[0], 0]], False),
    'zero_computation': ([[], [[0, 0, 0], 0]], True),
    'truth_paired': ([0, [[0], [0], [0]]], True),
    'false_zero_computation': ([[], [[0, 0, 0], [0]]], False),
    'future_update': ([[], [[0, 0, -1], 0]], False),
    'false_induction': ([0, [[1, 0], [1, 0], [1, 0]]], False),
    'bare_truth': ([0], False),
    'malformed_string': ([[], 'x'], False),
    'malformed_object': ({}, False),
}
counts = {name: Counter() for name in programs}
rule_counts = {name: Counter() for name in programs}


def verify(packet, name, expected=None):
    for variant, module in loaded.items():
        actual = run(module, packet)
        if variant == 'fallback':
            integer_packet = norm_bool(packet)
            oracle = oracle_module.Oracle(1).run(integer_packet)
            direct_source = run(source, integer_packet)
            assert actual['accepted'] == direct_source['accepted'], (variant, name, 'source', actual, direct_source, packet)
            counts[variant]['direct_source_comparisons'] += 1
        else:
            oracle = wide_oracle.Oracle(1).run(packet)
        assert actual['accepted'] == oracle['accepted'], (variant, name, 'oracle', actual, oracle, packet)
        if expected is not None:
            assert actual['accepted'] == expected, (variant, name, 'expected', actual, packet)
        if actual['accepted']:
            assert (actual['final_k'], actual['remaining']) == (oracle['final_k'], oracle['remaining']), (variant, name, 'trace', actual, oracle)
        counts[variant]['packets'] += 1
        counts[variant]['accepted' if actual['accepted'] else 'rejected'] += 1
        rule_counts[variant].update(oracle['rules'])


for i, packet in enumerate(positive):
    verify(packet, f'translated_positive/{i}', True)
    for j in range(3):
        verify(replace_bool(packet), f'boolean_alias/{i}/{j}', True)
    for j in range(3):
        verify(replace_fraction(packet), f'fractional_labels/{i}/{j}')
    for j in range(24):
        verify(mutate(packet), f'mutation/{i}/{j}')
for name, (packet, expected) in fixed.items():
    verify(packet, name, expected)

# CPython's JSON reader also accepts nonfinite floats, including overflow
# from valid JSON numeric tokens. They are legitimate opening holes but
# can never survive no-image validation.
nonfinite_holes = []
for hole in (float('nan'), float('inf'), -float('inf')):
    equation = [[0, 0, 0], 0]
    packet = [[], [], [equation, [hole, 0]], [0, 0]]
    verify(packet, 'nonfinite_transport_hole/' + repr(hole))
    assert run(loaded['partition'], packet)['accepted']
    assert not run(loaded['fallback'], packet)['accepted']
    integer_packet = [[], [], [equation, [1, 0]], [0, 0]]
    assert run(loaded['fallback'], integer_packet)['accepted']
    nonfinite_holes.append({'hole': repr(hole), 'partition_accepts': True,
                           'fallback_accepts_original': False,
                           'fallback_accepts_integer_retraction': True})


def tree(depth):
    if depth == 0 or rng.random() < .5:
        return deepcopy(rng.choice(leaves))
    return [tree(depth - 1) for _ in range(rng.randrange(5))]


for i in range(3000):
    verify(tree(4), f'malformed/{i}')
false_goals = [[[0], 0], [0, [0]], [[[0]], 0], [[[0]], [0]],
               [[1, 0], [1, 0], [1, 0]], [[0, 1], [0, 1], [0, 1]]]
for i in range(6000):
    packet = deepcopy(rng.choice(positive))
    for _ in range(1 + rng.randrange(3)):
        if len(packet) > 1:
            index = rng.randrange(len(packet) - 1)
            packet[index] = mutate(packet[index])
    packet[-1] = deepcopy(false_goals[i % len(false_goals)])
    verify(packet, f'false_target/{i}', False)

# Independent named-sort traversal for the interval retraction theorem.
def retract(value, depth):
    if type(value) in (int, bool):
        return int(value)
    if type(value) is float:
        return floor(value) if isfinite(value) else depth
    if type(value) is not list:
        return value
    if depth % 2:
        widths = {1: (0,), 3: (0, 0, 2)}.get(len(value))
    else:
        widths = {1: (2,), 2: (1, 1), 3: (4, 4, 4)}.get(len(value))
    if widths is None:
        return deepcopy(value)
    return [retract(child, depth + width) for child, width in zip(value, widths)]


def opened(module, value, image, depth, lower):
    module.k = lower
    try:
        return True, module.inst(value, image, depth)
    except Exception:
        return False, None


opening_counts = Counter()
for i in range(5000):
    lower = rng.choice((0, -1, -3, -8))
    depth = rng.randrange(10)
    boundary = rng.choice((lower, 0, 1, depth))
    floating = rng.choice((float(boundary), nextafter(float(boundary), inf),
                           nextafter(float(boundary), -inf), float('nan'),
                           float('inf'), -float('inf')))
    value = floating if i % 3 == 0 else mutate(tree(3))
    image = rng.choice((0, [0], lower, [lower], [0, 0, 1], None, .25))
    actual = opened(loaded['partition'], value, image, depth, lower)
    ref = opened(loaded['fallback'], retract(value, depth), retract(image, 1), depth, lower)
    assert actual[0] == ref[0], ('opening domain retraction', i, lower, depth, value, image, actual, ref)
    if actual[0]:
        assert retract(actual[1], depth) == ref[1], ('opening value retraction', i, lower, depth, value, image, actual, ref)
    opening_counts['cases'] += 1
    opening_counts['successful' if actual[0] else 'rejected'] += 1

# Used malformed scalar nodes must fail before any unbounded recursion.
termination_rows = []
for variant, module in loaded.items():
    original = module.inst
    for malformed in ('x', 'xx', 'xxx', '', {}, {'x': 0}, None, float('nan'), float('inf'), -float('inf')):
        calls = [0]
        def counted(*args, **kwargs):
            calls[0] += 1
            if calls[0] > 20:
                raise RuntimeError('opening exceeded finite scalar bound')
            return original(*args, **kwargs)
        module.inst = counted
        module.k = 0
        try:
            module.inst(malformed)
            raise AssertionError(('malformed node accepted', variant, malformed))
        except (TypeError, ValueError, IndexError):
            pass
        finally:
            module.inst = original
        assert calls[0] <= 2, ('scalar malformed recursion', variant, malformed, calls)
        termination_rows.append({'variant': variant, 'input': repr(malformed), 'inst_calls': calls[0]})

# Meaningful public-driver checks include both Python modes and parse errors.
cli_rows = []
cli_packets = [(name, packet, expected) for name, (packet, expected) in fixed.items()]
cli_packets += [('translated_first', positive[0], True), ('translated_last', positive[-1], True),
                ('boolean_zero', [[], [[0, False, 0], False]], True)]
with tempfile.TemporaryDirectory() as tmp:
    for name, packet, expected in cli_packets:
        path = Path(tmp) / 'packet.json'
        path.write_text(json.dumps(packet))
        for variant, program in programs.items():
            for optimized in (False, True):
                args = [sys.executable] + (['-O'] if optimized else []) + [str(program), str(path)]
                r = subprocess.run(args, capture_output=True, text=True, timeout=5)
                assert (r.returncode, r.stdout.strip()) == ((0, 'ACCEPT') if expected else (1, 'REJECT')), (variant, name, optimized, r)
                cli_rows.append({'variant': variant, 'name': name, 'optimized': optimized, 'accepted': expected})
    for variant, program in programs.items():
        for contents in ('{bad', '', 'NaN', 'Infinity', '-Infinity', '[[], "x"]'):
            path = Path(tmp) / 'packet.json'
            path.write_text(contents)
            r = subprocess.run([sys.executable, str(program), str(path)], capture_output=True, text=True, timeout=5)
            assert (r.returncode, r.stdout.strip()) == (1, 'REJECT'), ('invalid json/packet', variant, contents, r)
            cli_rows.append({'variant': variant, 'name': 'invalid_text/' + contents, 'optimized': False, 'accepted': False})

comparators = []
manifest = json.loads((HERE / 'comparison_manifest.json').read_text())
for row in manifest['programs']:
    path = HERE / row['local_file']
    assert sha256(path.read_bytes()).hexdigest() == row['sha256']
    comparators.append({'path': row['source_path'], **measured(path)})
result = {
    'status': 'PASS', 'python': platform.python_version(), 'seed': 261107365,
    'candidate_metrics': {name: measured(path) for name, path in programs.items()},
    'current_root_checkers': comparators,
    'current_root_envelope': {k: min(row[k] for row in comparators) for k in shared.PRIMARY},
    'common_driver_envelope': {k: min(row['common_conventional_driver'][k] for row in comparators) for k in shared.PRIMARY},
    'core_envelope': {k: min(row['core_with_imports_globals'][k] for row in comparators) for k in shared.PRIMARY},
    'counts': {name: dict(c) for name, c in counts.items()},
    'rule_counts': {name: dict(c) for name, c in rule_counts.items()},
    'source_positive_packets': len(positive), 'fixed_packets': len(fixed),
    'false_target_probes': 6000, 'malformed_random_packets': 3000,
    'cli_runs': len(cli_rows), 'cli_results': cli_rows,
    'interval_retraction_openings': dict(opening_counts),
    'nonfinite_template_holes': nonfinite_holes,
    'malformed_scalar_termination': termination_rows,
    'oracle_original_sha256': sha256(oracle_source.encode()).hexdigest(),
    'oracle_wide_sha256': sha256(wide_source.encode()).hexdigest(),
    'claim_boundary': 'Finite tests are not formal proofs. Soundness relies on conservative truth completion and interval/floor decoding; canonical completeness is inherited from third-matrix scalar calculus.'
}
audit_options.results.resolve().write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('current_root_checkers', 'cli_results', 'malformed_scalar_termination')}, indent=2))
