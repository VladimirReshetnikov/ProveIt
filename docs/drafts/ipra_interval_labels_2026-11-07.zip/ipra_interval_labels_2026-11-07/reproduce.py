"""Reproduce the complete-source comparison and finite iPRA kernel audits."""
from pathlib import Path
import ast
import csv
import hashlib
import json
import subprocess
import sys
import types

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'
EXPECTED_CHECKER = '30c03b11f64a35a6df27e4a43ddf9057549790a095e8e10355fd53d413e6a63e'


def refresh_tables():
    receipt = json.loads((RESULTS / 'validation.json').read_text())
    primary = receipt['candidate_metrics']['partition']
    fields = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
    boundaries = [
        ('whole_program', receipt['current_root_envelope'], primary),
        ('common_driver', receipt['common_driver_envelope'], primary['common_conventional_driver']),
        ('checking_prefix', receipt['core_envelope'], primary['core_with_imports_globals']),
    ]
    for name, old, new in boundaries:
        if not all(new[key] < old[key] for key in fields):
            raise RuntimeError(f'Strict reduction failed at {name}: {old}, {new}')
    metrics = {
        'python': receipt['python'],
        'repository_commit': 'ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a',
        'source_sha256': primary['sha256'],
        'boundaries': {
            name: {'current_minimum': {key: old[key] for key in fields},
                   'candidate': {key: new[key] for key in fields}}
            for name, old, new in boundaries
        },
        'current_root_checkers': receipt['current_root_checkers'],
    }
    (RESULTS / 'metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
    with (RESULTS / 'comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=('path', *fields, 'sha256'))
        writer.writeheader()
        for row in receipt['current_root_checkers']:
            writer.writerow({key: row[key] for key in writer.fieldnames})
        writer.writerow({'path': 'checker.py', **{key: primary[key] for key in fields},
                         'sha256': primary['sha256']})
    counts = receipt['counts']['partition']
    openings = receipt['interval_retraction_openings']
    summary = r'''\begin{center}
\begin{tabular}{@{}lr@{}}
\toprule
Recorded audit category & Count\\
\midrule
Primary packet/oracle comparisons & %d\\
Accepted / rejected primary packets & %d / %d\\
Inherited translated positive proofs & %d\\
Boolean / fractional fixture variants & 441 / 441\\
Mutated source fixtures & 3528\\
Random malformed packets & %d\\
False-target attempts, all rejected & %d\\
Independent interval-retraction openings & %d\\
Successful / rejected openings & %d / %d\\
Public CLI runs across both variants & %d\\
\bottomrule
\end{tabular}
\end{center}
The subcategories are already included in the packet total; they are not
additional independent proofs. The primary packet count includes three
nonfinite-hole transport examples. The 60 public CLI invocations span the
primary and integration-reference checkers; they are not 60 distinct theorems.
''' % (counts['packets'], counts['accepted'], counts['rejected'],
       receipt['source_positive_packets'], receipt['malformed_random_packets'],
       receipt['false_target_probes'], openings['cases'], openings['successful'],
       openings['rejected'], receipt['cli_runs'])
    (RESULTS / 'evidence_summary.tex').write_text(summary)
    return receipt


def public_examples():
    index = json.loads((ROOT / 'examples/index.json').read_text())
    rows = []
    for item in index:
        expected = item['expected']
        for optimized in (False, True):
            args = [sys.executable] + (['-O'] if optimized else [])
            args += [str(ROOT / 'checker.py'), str(ROOT / 'examples' / item['file'])]
            result = subprocess.run(args, capture_output=True, text=True, timeout=10)
            desired = (0, 'ACCEPT') if expected == 'ACCEPT' else (1, 'REJECT')
            if (result.returncode, result.stdout.strip()) != desired:
                raise RuntimeError((item['file'], optimized, result.returncode,
                                    result.stdout, result.stderr))
            rows.append({'file': item['file'], 'optimized': optimized, 'verdict': expected})
    (RESULTS / 'public_examples.json').write_text(json.dumps(rows, indent=2) + '\n')


def guard_mutation_control():
    """An intentionally unsound first-child introduction must admit the attack."""
    source = (ROOT / 'checker.py').read_text()
    attack = [0, [[0], 0]]
    rows = []
    for name, text in [('production', source),
                       ('unsafe_first_child', source.replace('a[2]', 'a[0]'))]:
        tree = ast.parse(text)
        boundary = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Try))
        tree.body = tree.body[:boundary]
        module = types.ModuleType(name)
        exec(compile(tree, name, 'exec'), module.__dict__)
        stack = json.loads(json.dumps(attack))
        module.take = stack.pop
        try:
            verdict = bool(module.check(stack.pop(), []))
        except Exception:
            verdict = False
        rows.append({'variant': name, 'attack_accepted': verdict})
    if rows[0]['attack_accepted'] or not rows[1]['attack_accepted']:
        raise RuntimeError('Introduction-guard mutation control failed')
    (RESULTS / 'guard_mutation_control.json').write_text(json.dumps(rows, indent=2) + '\n')


def main():
    RESULTS.mkdir(exist_ok=True)
    actual = hashlib.sha256((ROOT / 'checker.py').read_bytes()).hexdigest()
    if actual != EXPECTED_CHECKER:
        raise RuntimeError('Production checker differs from the reviewed candidate')
    command = [sys.executable, str(ROOT / 'validation/verify.py'),
               '--candidate', str(ROOT / 'checker.py'),
               '--results', str(RESULTS / 'validation.json')]
    with (RESULTS / 'audit_stdout.txt').open('w') as stream:
        subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=True)
    receipt = refresh_tables()
    public_examples()
    guard_mutation_control()
    print(json.dumps({'status': 'PASS',
                      'primary_packets': receipt['counts']['partition'],
                      'interval_openings': receipt['interval_retraction_openings'],
                      'metrics': receipt['candidate_metrics']['partition'],
                      'public_examples': 'passed in normal and optimized Python',
                      'guard_mutation_control': 'detected intentionally unsound variant'}, indent=2))


if __name__ == '__main__':
    main()
