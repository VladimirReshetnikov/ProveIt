INTERVAL LABELS SIMPLIFY AN iPRA PROOF CHECKER
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific time)
================================================================

RESULT

The complete standalone checker.py measures 362 normalized Python tokens,
386 AST nodes, and 1064 normalized bytes. The nine root checkers in the
six current ProveIt drafts have coordinatewise minimum 367 / 392 / 1076.
The source snapshot is commit ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a.

With exactly the same conventional public driver, the current minimum is
369 / 395 / 1105 and the new candidate is 366 / 391 / 1101. The corresponding
complete checking-prefix minima are 318 / 339 / 929 and 315 / 335 / 925.
The reduction therefore survives both controls. Exact metrics use CPython
3.12.14; the checker requires Python 3.10 or later.

THE NEW IDEA

One scalar/list partition replaces both an integer-recognition predicate
and a separate list-validation copy. The existing scope bounds validate
scalar labels. A retained finite numeric label r denotes the same syntax
as floor(r), since all scope interval endpoints are integers. No floor
operation is added to the trusted program. This is a conservative change
of certificate notation, not fractional arithmetic in the object theory.

The full truth-completion boundary is retained, including its essential
third-matrix introduction guard. The accepted theorem set is unchanged.
The paper proves sound extraction from successful traces, canonical integer
completeness, and idealized total rejection of malformed used syntax.

The positive result is a small checker reduction relative to the inspected
corpus. It is not a new arithmetic foundation or a proof of absolute
shortestness. No mathematical breakthrough is claimed. The inherited native
calculus has two scalar-iteration computation schemas and five inference
patterns. The complete logical reconstruction and scalar arithmetic
bootstrap are included, with both ordinary whole-domain interpretation
composites and equiconsistency with full first-order intuitionistic PRA.

START

Read report.pdf. All editable sources are in report.tex, sections/, and
foundation/. The ZIP is self-contained for the following commands:

  python3 checker.py examples/zero_computation.json
  python3 checker.py examples/fractional_initializer.json
  python3 -O checker.py examples/fractional_bound_coordinate.json

These print ACCEPT and exit 0. The deliberate attack

  python3 checker.py examples/unsafe_first_child_introduction.json

prints REJECT and exits 1. Rejection concerns that packet, not mathematical
unprovability of a formula. FORMAT.txt describes the public input language.

REPRODUCE

  python3 reproduce.py
  python3 build.py

Reproduction uses Python's standard library and the bundled frozen sources;
no network is required. The PDF build also requires pdfLaTeX and the packages
listed in report.tex. Actual execution has finite stack, parsing, time, and
memory limits. Completeness has the ordinary adequate-finite-resource meaning.

CONTENTS

  checker.py                 Entire trusted acceptance program
  report.tex / report.pdf    Paper source and compiled paper
  sections/                  New representation and extraction argument
  foundation/                Attributed complete inherited iPRA foundation
  examples/                  Small positive and negative public packets
  validation/                Independent oracle, frozen fixtures, source metric,
                             comparators, and mathematical audit notes
  comparison/                Pinned archive identity and provenance
  results/                   Reproducible measurement and validation receipts
  reproduce.py / build.py    Offline reproduction and compilation
  ATTRIBUTION.txt             Exact new/inherited contribution boundary
  LICENSE.txt                Preserved source license
  SHA256SUMS.txt              Integrity manifest for the delivered archive

CORRECTNESS BOUNDARY

Theorems are established by written mathematical arguments, not a Lean or
Rocq formalization of the calculus or Python runtime. The finite executable
audits do not establish consistency or bi-interpretability on their own.

The proof normalizes successful rule applications. Flooring an entire
arbitrary JSON packet need not preserve its execution: new raw equalities
can change hypothesis matching and destructive stack consumption. Every
canonical integer proof remains available, which is the required completeness
statement. Some semantically equivalent fractional spellings are rejected.

Only checker.py is project-specific trusted runtime code. It imports no
oracle, proof compiler, arithmetic evaluator, metric helper, or theorem data.
Its verdict does not depend on assertions that disappear under Python -O.

PROVENANCE

https://github.com/VladimirReshetnikov/ProveIt/tree/ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a/docs/drafts

The nine current root sources are frozen byte-for-byte. Foundation sources
and inherited representation ideas are explicitly attributed. No repository
mutation was made to produce this archive.
