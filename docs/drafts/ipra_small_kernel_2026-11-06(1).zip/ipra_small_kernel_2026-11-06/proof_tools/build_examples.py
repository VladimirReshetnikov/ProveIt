"""Build a few illustrative closed theorems; this is not trusted code.

The named proof builder is inherited from the supplied unary-existential
draft. Each expected conclusion below is specified before encoding and
every result must pass the standalone checker.
"""

import hashlib
import importlib.util
import json
from pathlib import Path

from builder import *

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "examples"


def pred(t):
    u, v = fresh("previous"), fresh("counter")
    return R(t, Z, u, v, v)


def add(a, n):
    u, v = fresh("previous"), fresh("counter")
    return R(n, a, u, v, S(u))


def cover(t):
    return disjunction(Eq(t, Z), Eq(S(pred(t)), t))


def main():
    OUT.mkdir(exist_ok=True)
    records = []

    def save(name, proof, goal, reading):
        if not same(proof.goal, goal):
            raise ValueError("Unexpected mathematical conclusion: " + name)
        data = certificate([], proof, [])
        if data[:2] != [[], encode(goal, [])]:
            raise ValueError("Unexpected encoded endpoints: " + name)
        kernel.check(data)
        encoded = json.dumps(data, separators=(",", ":")) + "\n"
        (OUT / (name + ".json")).write_text(encoded)
        records.append({"name": name, "ordinary_reading": reading,
                        "assumptions": [], "bytes": len(encoded.encode()),
                        "sha256": hashlib.sha256(encoded.encode()).hexdigest(),
                        "new_checker": "accepted"})

    x, y, z = fresh("x"), fresh("y"), fresh("transport")
    save("reflexivity", pi_intro(x, T, refl(x)), All(x, Eq(x, x)),
         "forall x, x = x")

    existential = Ex(y, Eq(y, S(x)))
    p = pi_intro(x, T, exists_intro(existential, S(x), refl(S(x))))
    save("forall_exists_successor", p, All(x, existential),
         "forall x, exists y, y = S(x)")

    premise = Eq(S(x), S(y))
    transported = congr(hyp(premise), z, pred(z))
    identity = trans(trans(sym(compute(pred(S(x)))), transported),
                     compute(pred(S(y))))
    p = pi_intro(x, T, pi_intro(y, premise, identity))
    save("successor_injective", p, All(x, Pi(y, premise, Eq(x, y))),
         "forall x forall y, S(x) = S(y) -> x = y")

    n = fresh("induction_number")
    matrix = Eq(add(Z, n), n)
    def step(y, hypothesis):
        return trans(compute(add(Z, S(y))), congr(hypothesis, z, S(z)))
    p = numerical(n, matrix, x, compute(add(Z, Z)), step)
    save("zero_plus_n", pi_intro(x, T, p), All(x, Eq(add(Z, x), x)),
         "forall n, 0 + n = n; addition recurses on its second argument")

    matrix, _ = cover(n)
    base_formula, base_plan = cover(Z)
    base = disjunction_intro(base_plan, refl(Z), 0)
    def cover_step(y, unused_base):
        _, plan = cover(S(y))
        right = congr(compute(pred(S(y))), z, S(z))
        return disjunction_intro(plan, right, 1)
    p = numerical(n, matrix, x, base, cover_step)
    goal, _ = cover(x)
    save("coverage", pi_intro(x, T, p), All(x, goal),
         "forall x, x = 0 or S(pred(x)) = x")

    result = {"status": "passed", "examples": records,
              "qualification": "Five finite closed examples, checked by the complete standalone candidate."}
    (ROOT / "validation/example_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
