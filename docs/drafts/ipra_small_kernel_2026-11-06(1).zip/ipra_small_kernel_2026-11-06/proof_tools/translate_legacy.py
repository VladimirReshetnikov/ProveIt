"""Untrusted old-to-new certificate translator.

The old checker is used only to identify major-premise formula constructors.
All translated endpoints are retained. Acceptance is determined independently
by checker.py. This script is not imported by the trusted implementation.
"""

import copy
import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "legacy_reference", ROOT / "controls/legacy_format.py")
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError)


def generic(p):
    """Retain malformed structure, renaming only an old intro proof tag."""
    if type(p) is not list:
        return p
    result = [generic(x) for x in p]
    if result and result[0] == "pack":
        result[0] = "ex"
    return result


def proof(p, g):
    try:
        match p:
            case ["hyp", _] | ["rec", _] | ["nat", _]:
                return copy.deepcopy(p)
            case ["pi", a, q]:
                return ["pi", a, proof(q, [*map(legacy.subst, g), a])]
            case ["pack", t, q]:
                local = [*map(legacy.subst, g),
                         ["=", 0, legacy.subst(t, formula=False)]]
                return ["ex", t, proof(q, local)]
            case ["use", principal, a, q]:
                major = legacy.infer(principal, g)
                converted = proof(principal, g)
                if major[0] == "ex":
                    local = [*map(legacy.subst, g), *major[1:]]
                    return ["use", converted, proof(q, local)]
                return ["use", converted, a, proof(q, g)]
    except ERRORS:
        pass
    return generic(p)


def certificate(data):
    try:
        g, goal, p = legacy.erase(copy.deepcopy(data))
        return [g, goal, proof(p, g)]
    except ERRORS:
        return generic(copy.deepcopy(data))
