OFFLINE COMPARISON OF COMPLETE CHECKER SOURCES

Snapshot
--------
Repository: VladimirReshetnikov/ProveIt
Commit: 536394385961ff82c0a1290b219f63dbfd963685
Directory: docs/drafts

The six archives were downloaded at this exact commit and their original
Git blob SHA-1 values were checked before extraction. manifest.json records
the archive filenames, repository paths, byte counts, Git blob SHA-1 values,
SHA-256 values, and immutable repository URLs.

Inventory
---------
The initial inventory selected every ZIP member ending in .py whose Python
AST contains function definitions named infer and check: 373 occurrences,
115 distinct sources. A subsequent audit inspected ALL 448 Python members of
the six archives (188 distinct sources), including differently named kernels.
It found three additional exported standalone checkers and 27 dependency
components used by historical checker groups. The remaining 45 occurrences
(43 distinct sources) are build, measurement, certificate-generation or test
utilities. Each exclusion is classified individually in manifest.json.

All 145 checker or dependency source files are stored byte-for-byte as
sources/<SHA-256>.py. No source was reformatted or altered. The expanded
comparison contains 118 standalone checker sources and 74 historical groups,
with overlap between the two sets. Partial modules are NOT individually
treated as complete checkers or included in a coordinatewise envelope.

For each occurrence, manifest.json records the original archive filename and
exact ZIP-member path, the source hash, its stored path, and its classification:
six current public main programs, one current canonical core, or bundled
support. The support group includes historical implementations and matched
controls. Additional occurrence records identify the 30 sources found in the
coverage audit. Historical dependency groups are recovered from the verbatim
historical_index.json, itself a member of the pinned typed-substitution archive;
its source provenance and SHA-256 are recorded. Its historical repository commit
describes older ancestors, not the current six-archive comparison snapshot.

Source classification and dependency recovery do not independently certify
the logical soundness or completeness of every historical implementation.
Each group is measured by summing its listed files. Historical groups without
a CLI are favorably counted without adding one. Group boundaries and original
module names are retained, so the treatment is reproducible and explicit.

Reproduce
---------
From the package root:

    python3 comparison/measure.py

Only Python's standard library is required. No network access is used. The
script verifies every frozen source hash and measures those sources and the
sibling checker.py. It does not import or execute any program under comparison.
It writes comparison/metrics.json, comparison/metrics_macros.tex, and
comparison/comparison_table.tex.

Optional arguments:

    --candidate PATH     Measure a different candidate.
    --output-dir PATH    Write the generated outputs in a different directory.

An absent candidate is permitted: metrics.json then has candidate=null and
the candidate LaTeX macros expand to an em dash. This supports reproducing
the baseline inventory independently of the proposed checker. The script also
verifies the exact inherited index and measures all 74 dependency groups.

Measured scope
--------------
The complete file is counted, including syntax validation, arithmetic axiom
construction, variable binding, substitution, inference, JSON input, and CLI.

tokens: Significant tokens in the original source, excluding docstrings,
comments, whitespace, indentation tokens, and the end marker.
normalized_tokens: Significant tokens after ast.unparse of the AST with
docstrings removed. This exposes reductions caused only by optional syntax
such as redundant parentheses in the original source.
ast_nodes: All ast.walk nodes, including context nodes, after docstring removal.
normalized_bytes: UTF-8 size of ast.unparse of that AST plus a final newline.
source_bytes: Original complete file size, including comments and docstrings.
code_lines: Original lines on which a significant non-docstring token starts.
physical_lines: All original lines, including blanks, comments and docstrings.

The recorded measurements use Python 3.12.14. Other Python versions can change
AST representation, tokenization or ast.unparse formatting. The script records
the actual Python version used on every run.

Two comparison boundaries
-------------------------
The six main checkers expose the public ['false'] abbreviation. The optional
typed-substitution checker_core.py instead accepts the canonical language,
where falsity is written as the equation 0=S0. Its source is a complete
acceptance program. Its smaller size must be disclosed in any comparison
against all bundled alternatives.

For this snapshot, the coordinatewise envelope of the six public main
programs is 808 original tokens, 808 normalized tokens, 855 AST nodes,
2618 normalized bytes and 2865 original bytes. Different programs can attain
different coordinates of an envelope.

Across the expanded standalone and grouped comparison, the canonical core
attains 796 original tokens,
796 normalized tokens, 839 AST nodes, 2547 normalized bytes and 2848 original
bytes. Historical interfaces can differ, so the all-source inventory is a
conservative size comparison, not a proof of identical accepted certificates.

The 74 historical groups have coordinatewise minima of 1089 original tokens,
1089 normalized tokens, 1154 AST nodes, 3486 normalized bytes and 3817 original
bytes. Thus the corrected inventory coverage does not change the frontier.
The three additional standalone exported checkers have at least 1910 original
tokens. The 27 dependency components are counted only within their groups.

LaTeX interface
---------------
The generated metrics_macros.tex defines CandidateTokens,
CandidateNormalizedTokens, CandidateAST, CandidateNormBytes, CandidateBytes,
CandidateRawBytes, CandidateCodeLines and CandidatePhysicalLines.
CandidateBytes and CandidateRawBytes both denote ORIGINAL complete bytes;
CandidateNormBytes denotes normalized bytes. The same suffixes are available
with prefixes PublicMinimum, InventoryMinimum and CanonicalCore.
ComparatorOccurrences and ComparatorUnique give the inventory counts.
These two macros retain the INITIAL inventory counts (373 and 115).
ExpandedStandaloneCount gives 118, HistoricalGroupCount gives 74,
FrozenSourceCount gives 145, AllPythonOccurrences gives 448, and
ExcludedUtilityOccurrences gives 45.

The generated comparison_table.tex is a tabular environment using booktabs.
It lists the candidate if present, the six main programs and the canonical
core. metrics.json additionally contains all 115 initial measurements, the
30 additional module measurements with their classifications, all 74 grouped
measurements, the corrected coordinatewise envelopes, and exact candidate
differences. Partial module measurements never enter a whole-checker minimum.

Limits of the claim
-------------------
This is a reproducible implementation-size comparison at a fixed source
snapshot. It is not a mathematical lower bound on every possible proof
checker. Changing language, runtime, certificate contract, or normalization
convention can change the result. Passing a size comparison does not prove
logical soundness; the theory and verification evidence are provided elsewhere
in the package.
