"""Reproduce finite validation of the standalone candidate.

Expected mathematical endpoints come from frozen certificates or the
independent named-variable oracle, never from candidate inference.
The old format is translated outside the trusted boundary.
"""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "proof_tools"))
from translate_legacy import certificate, generic, ERRORS


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    checker = load("candidate", ROOT / "checker.py")
    annotated = load("annotated_control", ROOT / "controls/annotated_existential.py")
    oracle = load("legacy_oracle", ROOT / "validation/legacy_audit.py")
    failures, records = [], []
    counts = dict(inherited_accept=0, inherited_reject=0,
                  translated_additional_accept=0, translated_additional_reject=0,
                  obsolete_annotations_replaced=0, native_accept=0,
                  native_reject=0, named_substitutions=0,
                  formation_rejections=0, cli_invocations=0,
                  canonical_lookup_results=0)
    native_dir = ROOT / "validation/native_certificates"
    native_dir.mkdir(exist_ok=True)

    def check(name, data, expected, group, cli=False):
        raw = json.dumps(data, separators=(",", ":")) + "\n"
        path = native_dir / (name.replace("/", "_") + ".json")
        path.write_text(raw)
        try:
            accepted = checker.check(copy.deepcopy(data)) is True
        except ERRORS:
            accepted = False
        except Exception as error:
            accepted = False
            failures.append({"name": name, "unexpected_exception": repr(error)})
        if accepted != expected:
            failures.append({"name": name, "expected": expected,
                             "accepted": accepted})
        counts[group + ("_accept" if expected else "_reject")] += 1
        records.append({"name": name, "expected_accept": expected,
                        "accepted": accepted,
                        "file": str(path.relative_to(ROOT)),
                        "sha256": hashlib.sha256(raw.encode()).hexdigest()})
        if cli:
            for optimization in ([], ["-O"]):
                run = subprocess.run([sys.executable, *optimization,
                                      str(ROOT / "checker.py"), str(path)],
                                     text=True, capture_output=True, timeout=20)
                counts["cli_invocations"] += 1
                if (run.returncode != (0 if expected else 1) or
                        run.stdout.strip() != ("ACCEPT" if expected else "REJECT")):
                    failures.append({"name": name, "cli_mode": optimization,
                                     "returncode": run.returncode,
                                     "stdout": run.stdout, "stderr": run.stderr})

    inherited = ROOT / "validation/inherited"
    source_records = json.loads(
        (inherited / "certificate_results.json").read_text())["certificates"]
    control_counts = dict(accepted=0, rejected=0)
    control_failures = []
    for record in source_records:
        raw = (inherited / record["file"]).read_bytes()
        if hashlib.sha256(raw).hexdigest() != record["sha256"]:
            raise ValueError("Changed inherited fixture: " + record["name"])
        check("inherited/" + record["name"], certificate(json.loads(raw)),
              record["accepted"], "inherited")
        try:
            control_accepts = annotated.check(generic(json.loads(raw))) is True
        except ERRORS:
            control_accepts = False
        control_counts["accepted" if control_accepts else "rejected"] += 1
        if control_accepts != record["accepted"]:
            control_failures.append(record["name"])
    if control_failures:
        failures.append({"name": "annotated_control", "cases": control_failures})
    (ROOT / "validation/control_results.json").write_text(json.dumps(dict(
        control="controls/annotated_existential.py",
        sha256=hashlib.sha256((ROOT / "controls/annotated_existential.py").read_bytes()).hexdigest(),
        **control_counts, failures=control_failures,
        translation="Only the old introduction tag pack is renamed ex; conclusion annotations are retained."
    ), indent=2) + "\n")

    # The existing audit independently constructs additional certificates and
    # a named-variable substitution corpus in the old public proof format.
    # Its executable is retained unchanged, with its source hash recorded.
    with tempfile.TemporaryDirectory(prefix="ipra_legacy_audit_") as temporary:
        old_out = Path(temporary)
        subprocess.run([sys.executable, str(ROOT / "validation/legacy_audit.py"),
                        str(ROOT / "controls/legacy_format.py"), "--inherited",
                        str(inherited), "--out", str(old_out)],
                       check=True, capture_output=True, text=True)
        generated = json.loads((old_out / "results.json").read_text())
        for record in generated["certificates"]:
            if "file" not in record:
                continue
            data = json.loads((old_out / record["file"]).read_text())
            if record["name"].startswith("bad_existential_conclusion_"):
                # There is no conclusion field in the new ex-use record.
                # Keeping that old field is now an arity error. Do not claim
                # that erasing a malformed old annotation tests its syntax.
                counts["obsolete_annotations_replaced"] += 1
                check("extra_ex_field/" + record["name"], data, False, "native")
            else:
                check("translated/" + record["name"], certificate(data),
                      record["expected_accept"], "translated_additional")
        substitutions = json.loads((old_out / "substitution_cases.json").read_text())
        for number, record in enumerate(substitutions):
            actual = checker.subst(record["tree"], record["env"],
                                   record["d"], record["formula"])
            if actual != record["expected"]:
                failures.append({"name": f"named_substitution_{number}"})
            counts["named_substitutions"] += 1
        (ROOT / "validation/substitution_cases.json").write_text(
            json.dumps(substitutions, indent=2) + "\n")

    zero = -1
    truth = ["=", zero, zero]
    bottom = ["=", zero, ["s", zero]]
    public_false = ["false"]
    ex_truth = ["ex", truth]
    hyp = lambda a: ["hyp", a]
    native = [
        ("inferred_ex", [[ex_truth], truth,
                         ["use", hyp(ex_truth), hyp(truth)]], True),
        ("ex_extra_field", [[ex_truth], truth,
                            ["use", hyp(ex_truth), truth, hyp(truth)]], False),
        ("ex_missing_minor", [[ex_truth], truth, ["use", hyp(ex_truth)]], False),
        ("equality_missing_template", [[truth], truth,
                                      ["use", hyp(truth), hyp(truth)]], False),
        ("ex_intro_wrong_sort", [[truth], ex_truth,
                                 ["ex", truth, hyp(truth)]], False),
        ("old_pack_tag", [[truth], ex_truth,
                          ["pack", zero, hyp(truth)]], False),
        ("false_assumption", [[public_false], bottom, hyp(bottom)], True),
        ("false_goal", [[bottom], public_false, hyp(bottom)], True),
        ("false_lookup", [[bottom], bottom, hyp(public_false)], True),
        ("false_guard", [[], ["pi", bottom, bottom],
                         ["pi", public_false, hyp(bottom)]], True),
        ("false_ex_body", [[bottom], ["ex", bottom],
                           ["ex", zero, hyp(public_false)]], True),
        ("false_transport", [[truth, bottom], bottom,
                             ["use", hyp(truth), public_false, hyp(bottom)]], True),
        ("false_ex_minor", [[["ex", bottom]], public_false,
                            ["use", hyp(["ex", bottom]), hyp(public_false)]], True),
        ("false_nat", [[], oracle.numerical_formula(bottom),
                       ["nat", public_false]], True),
    ]
    # Expected scope deletion results are written independently of inference.
    for name, body, conclusion, accepted in (
        ("free_eigenvariable", ["=", 0, zero], truth, False),
        ("outer_parameter", ["=", 1, zero], ["=", 0, zero], True),
        ("under_existential_escape", ["ex", ["=", 1, zero]], ex_truth, False),
        ("under_existential_parameter", ["ex", ["=", 2, 0]],
         ["ex", ["=", 1, 0]], True),
        ("under_recursion_escape", ["=", ["r", zero, zero, 2], zero],
         truth, False),
        ("under_recursion_parameter", ["=", ["r", zero, zero, 3], zero],
         ["=", ["r", zero, zero, 2], zero], True),
    ):
        principal = ["ex", body]
        native.append((name, [[principal], conclusion,
                              ["use", hyp(principal), hyp(body)]], accepted))
    for number, counter in enumerate((0, 2, ["r", zero, zero, 0],
                                      False, 0.0, -2, "s0", {},
                                      ["s"], ["s", zero, zero])):
        native.append((f"non_redex_counter_{number}", [[], truth,
                      ["rec", ["r", counter, zero, 0]]], False))
    for name, data, accepted in native:
        check(name, data, accepted, "native", cli=True)

    # A lookup key is only a selector. Stored assumptions remain canonical.
    for alias in (False, 0.0):
        context = [["=", 0, zero]]
        result = checker.infer(["hyp", ["=", alias, zero]], context)
        if result is not context[0]:
            failures.append({"name": "noncanonical_lookup_result"})
        counts["canonical_lookup_results"] += 1

    bad_terms = (False, 0.0, None, -2, "x", {}, [], ["s"],
                 ["r", zero, zero], truth, public_false)
    bad_formulas = (False, 0.0, None, zero, "x", {}, [], ["=", zero],
                    ["ex"], ["pi", truth], ["s", zero])
    for formula, objects in ((False, bad_terms), (True, bad_formulas)):
        for value in objects:
            try:
                checker.subst(value, (0,), formula=formula)
            except ERRORS:
                pass
            else:
                failures.append({"name": "formation", "value": value,
                                 "formula": formula})
            counts["formation_rejections"] += 1

    for number, raw in enumerate(("[", "NaN", "null", '{"context":[]}')):
        path = native_dir / f"invalid_json_{number}.txt"
        path.write_text(raw)
        for optimization in ([], ["-O"]):
            run = subprocess.run([sys.executable, *optimization,
                                  str(ROOT / "checker.py"), str(path)],
                                 text=True, capture_output=True, timeout=20)
            counts["cli_invocations"] += 1
            if run.returncode != 1 or run.stdout.strip() != "REJECT":
                failures.append({"name": f"invalid_json_{number}"})

    subprocess.run([sys.executable, str(ROOT / "validation/audit_scope_deletion.py"),
                    str(ROOT / "checker.py"),
                    str(ROOT / "validation/scope_deletion_results.json")],
                   check=True, capture_output=True, text=True)
    scope = json.loads((ROOT / "validation/scope_deletion_results.json").read_text())
    result = dict(status="passed" if not failures else "failed", counts=counts,
                  checker_sha256=hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
                  scope_deletion=scope, records=records, failures=failures,
                  qualification="Finite regression evidence, not a formal soundness proof.")
    (ROOT / "validation/results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in
                      ("status", "checker_sha256", "counts", "failures")}, indent=2))
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())
