"""Independent named-variable oracle for existential scope deletion.

Usage: python3 audit_scope_deletion.py PATH_TO_CHECKER [RESULT_JSON]
No certificate generator participates in acceptance.
"""
import importlib.util
import json
import random
import sys
from pathlib import Path


def load(path):
    spec = importlib.util.spec_from_file_location("scope_candidate", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class NamedSyntax:
    def __init__(self, seed=20261106):
        self.rng = random.Random(seed)
        self.next_name = 0

    def fresh(self):
        self.next_name += 1
        return "local_" + str(self.next_name)

    def term(self, depth, variables):
        op = self.rng.randrange(5 if depth else 2)
        if op == 0:
            return ("zero",)
        if op == 1:
            return ("var", self.rng.choice(variables))
        if op == 2:
            return ("successor", self.term(depth - 1, variables))
        old, counter = self.fresh(), self.fresh()
        return ("recursion", self.term(depth - 1, variables),
                self.term(depth - 1, variables), old, counter,
                self.term(depth - 1, (old, counter, *variables)))

    def formula(self, depth, variables):
        op = self.rng.randrange(4 if depth else 1)
        if op == 0:
            return ("equal", self.term(min(depth + 1, 3), variables),
                    self.term(min(depth + 1, 3), variables))
        name = self.fresh()
        extended = (name, *variables)
        if op == 1:
            return ("exists", name, self.formula(depth - 1, extended))
        return ("guarded", name, self.formula(depth - 1, extended),
                self.formula(depth - 1, extended))


def encode(a, names):
    """Translate named syntax; absence of a free name raises ValueError."""
    match a:
        case ("zero",):
            return -1
        case ("var", name):
            return names.index(name)
        case ("successor", b):
            return ["s", encode(b, names)]
        case ("recursion", n, base, old, counter, body):
            return ["r", encode(n, names), encode(base, names),
                    encode(body, (old, counter, *names))]
        case ("equal", s, t):
            return ["=", encode(s, names), encode(t, names)]
        case ("exists", name, body):
            return ["ex", encode(body, (name, *names))]
        case ("guarded", name, guard, body):
            return ["pi", encode(guard, (name, *names)),
                    encode(body, (name, *names))]
        case _:
            raise AssertionError("bad test oracle syntax")


def main():
    candidate = load(sys.argv[1])
    maker = NamedSyntax()
    cases = []
    for number in range(3000):
        variables = ("eigen", "outer_a", "outer_b") if number % 2 else ("outer_a", "outer_b")
        cases.append(maker.formula(number % 7, variables))
    accepted = rejected = 0
    for named in cases:
        original = encode(named, ("eigen", "outer_a", "outer_b"))
        try:
            expected = encode(named, ("outer_a", "outer_b"))
        except ValueError:
            try:
                candidate.subst(original, [None, -1])
            except (ValueError, TypeError):
                rejected += 1
            else:
                raise AssertionError("accepted an escaping eigenvariable")
        else:
            actual = candidate.subst(original, [None, -1])
            assert actual == expected, (named, actual, expected)
            assert candidate.subst(actual) == original
            accepted += 1
    result = {"checker": str(Path(sys.argv[1]).resolve()), "seed": 20261106,
              "named_formulas_tested": len(cases), "successful_scope_deletions": accepted,
              "witness_escape_rejections": rejected,
              "oracle": "independent named syntax, compiled with and without the eigenvariable",
              "all_checks_passed": True}
    if len(sys.argv) > 2:
        Path(sys.argv[2]).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
