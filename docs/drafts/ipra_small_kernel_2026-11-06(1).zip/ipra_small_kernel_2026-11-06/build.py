"""Compile the included LaTeX report, with generated measurement macros."""

from pathlib import Path
import os
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    subprocess.run([sys.executable, str(ROOT / "comparison/measure.py")],
                   cwd=ROOT, check=True)
    engine = shutil.which("pdflatex")
    if engine is None:
        raise SystemExit("pdfLaTeX is required to compile report.tex")
    environment = os.environ.copy()
    lookup = shutil.which("kpsewhich")
    if lookup and not subprocess.run([lookup, "pdflatex.fmt"],
                                     capture_output=True).stdout.strip():
        formats = ROOT / ".build/formats"
        formats.mkdir(parents=True, exist_ok=True)
        if not (formats / "pdflatex.fmt").exists():
            result = subprocess.run(
                [str(Path(engine).with_name("pdftex")), "-ini",
                 "-interaction=nonstopmode", "-halt-on-error",
                 "-jobname=pdflatex", "-progname=pdflatex", "-etex", "pdflatex.ini"],
                cwd=formats, text=True, capture_output=True)
            (formats / "format_build.txt").write_text(result.stdout + result.stderr)
            if result.returncode:
                print((result.stdout + result.stderr)[-6000:])
                raise SystemExit(result.returncode)
        environment["TEXFORMATS"] = str(formats) + os.pathsep + environment.get("TEXFORMATS", "")
    for _ in range(3):
        result = subprocess.run(
            [engine, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=ROOT, env=environment, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (ROOT / "build_output.txt").write_text(result.stdout, encoding="utf-8")
        if result.returncode:
            print(result.stdout[-6000:])
            raise SystemExit(result.returncode)
    print("Compiled report.pdf")


if __name__ == "__main__":
    main()
