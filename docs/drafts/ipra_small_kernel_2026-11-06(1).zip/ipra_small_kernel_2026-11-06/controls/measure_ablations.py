"""Measure the transparent source ablations and the matched ex-use control.

No checker is executed by this script. The common metric implementation
is comparison/measure.py; the frozen ablation hashes are verified first.
"""

import hashlib
import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("common_metrics", ROOT / "comparison/measure.py")
metrics = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metrics)


def main():
    manifest = json.loads((ROOT / "controls/ablation_manifest.json").read_text())
    rows = []
    for record in manifest["steps"]:
        path = ROOT / record["path"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != record["sha256"]:
            raise ValueError("Changed ablation: " + record["path"])
        rows.append(dict(record, metrics=metrics.measure(path)))
    main = metrics.measure(ROOT / "checker.py")
    control = metrics.measure(ROOT / "controls/annotated_existential.py")
    result = dict(steps=rows, candidate=main, annotated_existential=control,
                  qualification=manifest["qualification"])
    (ROOT / "controls/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    text = [r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
            r"Stage & Source tokens & Norm.\ tokens & AST & Norm.\ bytes\\",
            r"\midrule"]
    labels = ["Supplied shared traversal", "Validated counter", "Internal sort flag",
              "Direct step premise", "Shared failure", "Typed successor",
              "Shared introduction", "Conclusion synthesis", "Shared major premise",
              "Reuse function arity"]
    for label, row in zip(labels, rows, strict=True):
        m = row["metrics"]
        text.append(label + " & " + " & ".join(str(m[k]) for k in
                    ("tokens", "normalized_tokens", "ast_nodes", "normalized_bytes")) + r"\\")
    text.extend([r"\midrule", "Matched annotated control & " + " & ".join(
        str(control[k]) for k in ("tokens", "normalized_tokens", "ast_nodes", "normalized_bytes")) + r"\\",
        r"\bottomrule", r"\end{tabular}"])
    (ROOT / "controls/ablation_table.tex").write_text("\n".join(text) + "\n")
    print(json.dumps({"candidate": main, "annotated_existential": control}, indent=2))


if __name__ == "__main__":
    main()
