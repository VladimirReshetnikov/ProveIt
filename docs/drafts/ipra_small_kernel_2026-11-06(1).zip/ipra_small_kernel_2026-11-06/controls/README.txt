MATCHED CONTROLS AND SOURCE ABLATIONS

legacy_format.py is the initial implementation control. It preserves the
supplied public proof-record format, including pack-introduction and an
explicit existential-elimination conclusion annotation. Its changes from
the supplied shared-traversal checker are the first five ablation stages.
It is used outside the trusted boundary by the legacy certificate translator.

annotated_existential.py is the matched control for conclusion synthesis.
It has the candidate's shared intro syntax and shared major-premise handling,
but existential elimination has the record ["use", principal, conclusion,
minor]. The candidate instead uses ["use", principal, minor], synthesizes
the conclusion, and rejects any escaping eigenvariable using the existing
substitution routine. No ignored placeholder field is accepted.

The matched annotated control has 775 significant source tokens, 773
normalized tokens, 835 AST nodes, and 2538 normalized bytes. The candidate
has 772, 770, 824, and 2494 respectively. Conclusion synthesis with function
arity reuse saves three significant tokens, eleven AST nodes, and 44 normalized
bytes against this close control. Both controls are additional results of
this iteration, not previously supplied drafts.

The hash-verified ablation sequence is recorded in ablation_manifest.json.
Stages 06 and 07 change proof-record syntax while preserving the native
logical consequence relation. The table is deliberately not represented
as a sequence of identical certificate formats. Stage 07 alone increases
some checker-size measures; shared major-premise handling and function arity
reuse in the final stages offset it. The last stage calls infer(*args, context);
since infer has exactly two positional parameters, Python rejects zero or
multiple remaining proof fields by TypeError. This is the same arity condition
previously enforced by q, = args. The candidate dominates every included
ablation in the principal source, normalized token, AST, and normalized byte
measurements.

Run from the package root:

    python3 controls/measure_ablations.py

This uses comparison/measure.py for the same complete-file measurements.
It neither imports nor executes any checker. The matched annotated control
is separately exercised on all 176 inherited certificates by
validation/run_validation.py (with only pack renamed to ex).

Checkers accept finite JSON. Python exceptions reject malformed certificates;
the standalone CLI catches the listed exception classes and prints REJECT.
The direct check() API returns True on success and raises on rejection.
These finite tests and measurements do not constitute formal verification.
