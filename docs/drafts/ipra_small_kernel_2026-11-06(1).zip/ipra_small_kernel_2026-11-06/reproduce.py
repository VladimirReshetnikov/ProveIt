"""Reproduce measurements, finite validation, examples, and the PDF offline."""

from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


if __name__ == "__main__":
    for script in ("comparison/measure.py", "controls/measure_ablations.py",
                   "validation/run_validation.py",
                   "proof_tools/build_examples.py", "build.py"):
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
    print("Measurements, validation, examples, and PDF reproduced.")
