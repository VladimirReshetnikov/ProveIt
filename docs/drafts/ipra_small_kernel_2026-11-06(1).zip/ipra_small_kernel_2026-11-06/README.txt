A SMALLER COMPLETE PROOF CHECKER FOR iPRA
6 November 2026

START HERE

report.pdf is the complete mathematical report. report.tex and sections/
are its source. The report specifies every primitive formation condition,
logical rule, arithmetic schema, and side condition, reconstructs full
intuitionistic first-order logic and quantifier-free induction, and proves
whole-domain bi-interpretability and equiconsistency with first-order iPRA.

checker.py is the entire standalone acceptance program. Nothing in
proof_tools/, comparison/, controls/, or validation/ is imported by it.
FORMAT.txt specifies its exact JSON input format, including all proof tags.

The native calculus retains the supplied drafts' unary-existential basis:
initialized primitive recursion, equality, guarded universal quantification,
unary existence, and one numerical schema with equation induction and
compound-formula cases. Public falsity explicitly abbreviates 0 = S0.
The implementation improvement synthesizes existential-elimination
conclusions by partial scope deletion using the existing substitution
traversal, with exact proof arity enforced by the inference helper's interface.
The report attributes the mathematical basis and inherited tools to the
supplied drafts; it does not claim those ingredients are new.

SIZE RESULT

The complete delivered checker has:
  772 significant original source tokens;
  770 significant normalized tokens;
  824 AST nodes;
  2494 normalized UTF-8 bytes;
  2778 complete original bytes;
  71 significant code lines and 92 physical lines.

The corresponding token/AST/byte envelope in the inspected draft corpus is
796 / 796 / 839 / 2547 / 2848. The candidate is strictly below all five.
It ties the minimum code-line count and does not minimize physical lines.
These are reproducible implementation-size comparisons, not a proof that
no smaller axiomatization or program exists.

The pinned source commit is:
536394385961ff82c0a1290b219f63dbfd963685
https://github.com/VladimirReshetnikov/ProveIt/tree/536394385961ff82c0a1290b219f63dbfd963685/docs/drafts

All six archives were retrieved and checked against their Git blob hashes.
The expanded inventory classifies all 448 Python members and measures 118
standalone sources plus 74 overlapping historical dependency groups.
The latter are measured with their complete recorded dependencies. The
archive retains 145 unchanged source files and the inherited dependency
index. These counts describe overlapping comparison sets and must not be
added as a count of distinct implementations. comparison/README.txt explains
the normalization, census, individual exclusions, and provenance.

QUICK START

Python 3.10+ is required. The checker and validation tools use only Python's
standard library. From this directory:

    python3 checker.py examples/coverage.json

prints ACCEPT. An invalid certificate prints REJECT and exits with status 1.
The direct check() function returns True for acceptance and raises on
rejection. Python's finite resources bound practical input depth and size.

To reproduce every reported measurement and finite validation:

    python3 comparison/measure.py
    python3 controls/measure_ablations.py
    python3 validation/run_validation.py
    python3 proof_tools/build_examples.py

To compile the report (pdfLaTeX and its ordinary packages are required):

    python3 build.py

To run all of the above in sequence:

    python3 reproduce.py

No network is used by these commands. build.py runs pdfLaTeX three times for
stable cross-references and can initialize a local format when necessary.
Exact normalization byte counts are tied to the Python version recorded
in comparison/metrics.json; ast.unparse formatting can change with Python.

EVIDENCE AND ITS LIMITS

Recorded finite validation includes 352 candidate-format certificate cases
(146 accepted, 206 rejected), 176 matched annotated-control cases, 428
independent named-variable substitution comparisons, 22 direct malformed
formation rejections, 68 ordinary/optimized CLI runs, 2 canonical hypothesis
object checks, and 3000 independent scope-deletion cases. The latter split
into 2001 valid deletions and 999 eigenvariable-escape rejections. Five
closed theorem certificates are also delivered. No failures were found.

The report supplies general written mathematical proofs. The executable
checks are finite implementation validation, not a Lean/Rocq formalization
or a machine-checked proof of the Python program's correctness.

The five examples prove universal reflexivity, existence of successors,
successor injectivity, 0+n=n, and zero/successor coverage. Derived logical
and arithmetic abbreviations are expanded before checking. The proof
builder and format translator are untrusted convenience tools.

CONTENTS

  report.pdf, report.tex, sections/  Full report and editable LaTeX source.
  checker.py                       Complete acceptance program.
  FORMAT.txt                       Exact certificate format and scope rules.
  examples/                        Five closed theorem certificates.
  proof_tools/                     Untrusted proof builder and translator.
  validation/                      Fixtures, independent audits, and results.
  controls/                        Matched control and measured reductions.
  comparison/                      Frozen sources, provenance, measurements.
  build.py, reproduce.py            Offline reproduction entry points.
  SHA256SUMS                       Integrity list for delivered files.

The comparison script parses historical programs but does not execute them.
Historical source-size comparisons do not certify those programs' correctness.
Temporary TeX products, local format caches, and Python bytecode caches are
excluded from the release archive.

CHECKER IDENTITY

SHA-256(checker.py):
18ff6b6834d531483be13c693952429f8dfdab9cabc36f7a0a7b7a2699563fe4

The report's final section gives further research questions: formal scope
deletion verification, additional annotation synthesis, a smaller arithmetic
basis, alternative constructive formula selectors, proof-expansion bounds,
and a fixed lower-level cost model for meaningful minimality claims.
