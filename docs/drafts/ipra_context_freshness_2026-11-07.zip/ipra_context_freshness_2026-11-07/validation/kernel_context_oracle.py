"""Independent named-binder oracle for the context-derived kernel.

Validation only. No packed depth table, structural match, or production
opening function is imported. Boolean aliases are normalized at the input.
"""
from copy import deepcopy
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from named_oracle import opening, Syntax, names_in


def normalize(value):
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, list):
        return [normalize(v) for v in value]
    if isinstance(value, dict):
        return {key: normalize(v) for key, v in value.items()}
    return value


class ContextOracle:
    def __init__(self):
        self.stack = []
        self.allocations = []
        self.rules = {}

    def count(self, name):
        self.rules[name] = self.rules.get(name, 0) + 1

    def check(self, goal, context):
        lower = -len(context)
        def op(value, image=None, *, formula=True, depth=0):
            return opening(value, image, formula=formula, depth=depth, lower=lower)
        op(goal)
        if goal in context:
            self.count('hypothesis')
            return True
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, context):
                if len(major) == 3:
                    self.count('paired_elimination')
                    eigen = lower - 1
                    syntax = Syntax(lower)
                    old_names = set().union(*(names_in(syntax.formula(a)) for a in [goal, *context, major]))
                    assert eigen not in old_names
                    self.allocations.append({'scope_size':len(context), 'eigen':eigen, 'old_names':sorted(old_names)})
                    assumption = opening([major[0]], eigen, lower=eigen)
                    return self.check(goal, context + [assumption])
                if len(major) == 1:
                    self.count('closure_elimination')
                    matrix, left, right = major[0], 0, annotation
                else:
                    self.count('equality_transport')
                    matrix, (left, right) = annotation, major
                if op(matrix, right) != goal:
                    return False
                return self.check(op(matrix, left), context)
        if instruction == []:
            self.count('iteration_computation')
            if len(goal) != 2 or type(goal[0]) is not list or len(goal[0]) != 3:
                raise ValueError('computation requires a literal iterator equation')
            counter, initial, update = goal[0]
            if counter == 0:
                expected = initial
            elif type(counter) is list and len(counter) == 1:
                expected = op(update, [counter[0], initial, update], formula=False)
            else:
                raise ValueError('computation counter is neither zero nor successor')
            return goal[1] == expected
        # Failed elimination guards may fall through; no premise from the
        # discarded attempt is retained. Each recursive call has its own floor.
        if len(goal) not in (1, 3):
            raise ValueError('introduction requires a logical goal')
        self.count('closure_introduction' if len(goal) == 1 else 'paired_introduction')
        body = op(goal[0], instruction, depth=1)
        assumptions = [op(body, 0)]
        if len(body) == 2:
            assumptions.insert(0, body)
        eigen = lower - 1
        syntax = Syntax(lower)
        old_names = set().union(*(names_in(syntax.formula(a)) for a in [goal, *context]))
        bound_y = syntax.fresh()
        old_names |= names_in(syntax.formula(body, (bound_y,)))
        assert eigen not in old_names
        self.allocations.append({'scope_size':len(context), 'eigen':eigen, 'old_names':sorted(old_names)})
        conclusion = opening(body, [eigen], lower=eigen)
        added = [opening(a, eigen, lower=eigen) for a in assumptions]
        assert len(added) >= 1
        return self.check(conclusion, context + added)

    def run(self, packet):
        self.stack = normalize(deepcopy(packet))
        try:
            accepted = bool(self.check(self.stack.pop(), []))
            error = None
        except AssertionError:
            raise
        except Exception as exc:
            accepted, error = False, type(exc).__name__
        return {'accepted':accepted, 'remaining':len(self.stack) if isinstance(self.stack,list) else None,
                'error':error, 'allocations':self.allocations, 'rules':self.rules}
