"""Canonical and boundary verification of the raw global companion.

All test support is untrusted and excluded from the acceptance program.
Finite checks do not establish consistency or the interpretation theorem.
"""
import ast
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import types

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = ROOT / 'results/global_validation'
OUT.mkdir(parents=True, exist_ok=True)
KERNEL = ROOT / 'checker_global.py'
from global_translate import GlobalCompiler
from global_oracle import GlobalOracle
from kernel_context_oracle import normalize
from named_oracle import Oracle
from new_cases import cases


def load(path):
    tree = ast.parse(path.read_text())
    tree.body = [node for node in tree.body
                 if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef))]
    module = types.ModuleType('tested_global_kernel')
    exec(compile(tree, str(path), 'exec'), module.__dict__)
    return module


kernel = load(KERNEL)


def run(packet):
    stack = deepcopy(packet)
    kernel.k = 0
    try:
        kernel.take = stack.pop
        accepted = bool(kernel.check(stack.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {'accepted':accepted, 'final_k':kernel.k,
            'remaining':len(stack) if isinstance(stack,list) else None, 'error':error}


def verify(packet, label, expected):
    actual = run(packet)
    oracle = GlobalOracle().run(packet)
    assert actual['accepted'] == oracle['accepted'], (label,actual,oracle)
    assert actual['accepted'] == expected, (label,actual)
    if actual['accepted']:
        assert actual['remaining'] == oracle['remaining'], (label,actual,oracle)
        assert actual['final_k'] == oracle['final_k'], (label,actual,oracle)
    return {'name':label, **actual, 'oracle_rules':oracle['rules'],
            'oracle_allocations':oracle['allocations']}


def bool_aliases(v):
    if type(v) is int and v in (0,1):
        return bool(v)
    if isinstance(v,list):
        return [bool_aliases(x) for x in v]
    return v


def packet(goal, cells):
    return list(reversed(cells)) + [goal]


inherited = json.loads((HERE / 'inherited_fixtures.json').read_text())
rows = inherited + cases(inherited)
compiled = []
checks = []
for row in rows:
    if not row['expected']:
        continue
    translated = GlobalCompiler().run(row['packet'])
    result = verify(translated['packet'], 'translated/' + row['name'], True)
    # No eigenparameter is renumbered; direct introduction also preserves
    # the source allocation count in every accepted canonical trace.
    source = Oracle().run(row['packet'])
    assert result['final_k'] == source['final_k'], row['name']
    assert all(x['source'] == x['target'] for x in translated['renamings'])
    checks.append(result)
    checks.append(verify(bool_aliases(translated['packet']), 'boolean/' + row['name'], True))
    compiled.append({'name':row['name'], **translated})

# Scoped tests that are independent of the changed introduction wrapper.
m = [[0,0,0],0]
d = [[3,3],[0,0],[0,0]]
bad = []
for name in (-1,-2,-999):
    bad.append((f'future_root_parameter_{name}', [[],[name,name]]))
    bad.append((f'future_unused_update_{name}', [[],[[0,0,name],0]]))
    bad.append((f'future_paired_witness_{name}', packet(d,[name])))
    bad.append((f'future_motive_parameter_{name}', packet([0,0],[[m,[1,name]],[],[]])))
for value in (True,False,0.0,1.0,None,{},'bad',[]):
    bad.append(('malformed_goal_' + repr(value), [[],value]))
for value in (1,3,999):
    bad.append((f'unbound_witness_{value}', packet(d,[value])))
    bad.append((f'unbound_goal_{value}', [[],[value,value]]))
bad.extend([
    ('false_computation', [[],[[0,0,0],[0]]]),
    ('nonzero_nonsuccessor_counter',[[],[[[0,0,1],0,1],0]]),
    ('unbound_scalar_counter',[[],[[0,0,3],0]]),
])
for label,p in bad:
    checks.append(verify(p,'malformed/' + label,False))

# The global companion intentionally accepts later auxiliary uses of a
# sibling's allocated numerical name. Its canonical wrapper compiler leaves
# that name unchanged, whereas the context compiler replaces it by zero.
q = [[0,0]]
sibling_source = packet([0,0],[[q,0],[0],[d,0],[-1],[m,[1,0]],[],[]])
sibling = GlobalCompiler().run(sibling_source)
checks.append(verify(sibling['packet'],'scope/global_sibling_parameter',True))
assert not sibling['erased_auxiliaries']
(OUT/'sibling_global.json').write_text(json.dumps(sibling,indent=2)+'\n')

cli_checks=[]
for label,p,want in [('accept_arithmetic',compiled[-1]['packet'],True),
                     ('accept_sibling',sibling['packet'],True),
                     ('reject_escape',bad[0][1],False)]:
    target=OUT/(label+'.json');target.write_text(json.dumps(p)+'\n')
    for optimized in (False,True):
        args=[sys.executable,*(['-O'] if optimized else []),str(KERNEL),str(target)]
        result=subprocess.run(args,capture_output=True,text=True,timeout=10)
        expected=(0,'ACCEPT','') if want else (1,'REJECT','')
        assert (result.returncode,result.stdout.strip(),result.stderr)==expected,(label,result)
        cli_checks.append({'name':label,'optimized':optimized,'returncode':result.returncode,'stdout':result.stdout.strip()})

spec=importlib.util.spec_from_file_location('source_measure',ROOT/'comparison/source_measure.py')
metric=importlib.util.module_from_spec(spec);spec.loader.exec_module(metric)
result={'statement':'Finite verification, not a formal equivalence proof.',
        'canonical_source_proofs_translated':len(compiled),
        'boolean_alias_copies':len(compiled),
        'focused_negative_tests':len(bad),
        'focused_checks':len(checks),
        'cli_checks':cli_checks,
        'metrics':metric.metrics(KERNEL),
        'focused_results':checks}
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'translated_cases.json').write_text(json.dumps(compiled,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k != 'focused_results'},indent=2))
