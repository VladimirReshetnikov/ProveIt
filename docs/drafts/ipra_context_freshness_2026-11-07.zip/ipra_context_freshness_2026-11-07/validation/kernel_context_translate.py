"""Untrusted canonical compiler from global-clock wrapped packets.

Each source eigenparameter is renamed to minus one minus the active context
length. Inactive auxiliary source parameters are replaced by zero. The
compiler is independent of the production opening implementation.
"""
from copy import deepcopy
from kernel_context_oracle import BASE
from named_oracle import opening, Oracle


class ContextCompiler:
    def __init__(self):
        self.lower = 0
        self.stack = []
        self.renamings = []
        self.auxiliary_erasures = set()

    def rename(self, value, names):
        if type(value) is int:
            if value < 0:
                if value not in names:
                    self.auxiliary_erasures.add(value)
                return names.get(value, 0)
            return value
        if type(value) is list:
            return [self.rename(v, names) for v in value]
        return deepcopy(value)

    def op(self, value, image=None, *, depth=0):
        return opening(value, image, depth=depth, lower=self.lower)

    def child_names(self, context, names):
        self.lower -= 1
        source_eigen = self.lower
        target_eigen = -len(context) - 1
        target_names = {**names, source_eigen: target_eigen}
        self.renamings.append({'source':source_eigen,'target':target_eigen,'scope_size':len(context)})
        return source_eigen, target_names

    def node(self, goal, context, names):
        self.op(goal)
        target_goal = self.rename(goal, names)
        if goal in context:
            return target_goal, []
        instruction = self.stack.pop()
        if len(instruction) == 2:
            major, annotation = instruction
            target_major, major_cells = self.node(major, context, names)
            if len(major) == 3:
                eigen, child_names = self.child_names(context, names)
                assumption = self.op([major[0]], eigen)
                _, minor_cells = self.node(goal, context + [assumption], child_names)
                return target_goal, [[target_major, 0], *major_cells, *minor_cells]
            if len(major) == 1:
                matrix, left, right = major[0], 0, annotation
            else:
                matrix, (left, right) = annotation, major
            if self.op(matrix, right) != goal:
                raise ValueError('source transport endpoint')
            _, minor_cells = self.node(self.op(matrix, left), context, names)
            return target_goal, [[target_major, self.rename(annotation, names)], *major_cells, *minor_cells]
        if len(instruction) == 1:
            annotation = instruction[0]
            body = self.op(goal[0], annotation, depth=1)
            try:
                self.op(goal[0], None, depth=1)
                target_annotation = 0
            except (ValueError, TypeError):
                target_annotation = self.rename(annotation, names)
            assumptions = [self.op(body, 0)]
            if len(body) == 2:
                assumptions.insert(0, body)
            eigen, child_names = self.child_names(context, names)
            conclusion = self.op(body, [eigen])
            child_context = context + [self.op(a, eigen) for a in assumptions]
            _, minor_cells = self.node(conclusion, child_context, child_names)
            return target_goal, [target_annotation, *minor_cells]
        if instruction == []:
            return target_goal, [[]]
        raise ValueError('invalid source instruction')

    def run(self, packet):
        source = Oracle().run(packet)
        if not source['accepted']:
            raise ValueError('source packet rejected by named oracle')
        self.stack = deepcopy(packet)
        goal, cells = self.node(self.stack.pop(), [], {})
        return {'packet':list(reversed(cells)) + [goal], 'renamings':self.renamings,
                'erased_auxiliaries':sorted(self.auxiliary_erasures)}
