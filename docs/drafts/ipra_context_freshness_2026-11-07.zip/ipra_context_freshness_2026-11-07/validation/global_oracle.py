"""Independent named-binder oracle for the raw-witness global companion.

Unlike the context kernel, a completed premise advances this oracle's shared
freshness floor. This intentionally matches the inherited global-clock
certificate contract. The parser and rule interpreter do not import either
production checker or its packed depth traversal.
"""
from named_oracle import Oracle, Syntax, names_in
from kernel_context_oracle import normalize


class GlobalOracle(Oracle):
    def check(self, goal, context):
        self.open(goal)
        if goal in context:
            self.rule('hypothesis')
            return True
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, context):
                if len(major) == 3:
                    self.rule('paired_elimination')
                    eigen = self.fresh([goal, *context, major])
                    assumption = self.open([major[0]], eigen)
                    return self.check(goal, context + [assumption])
                if len(major) == 1:
                    self.rule('closure_elimination')
                    matrix, left, right = major[0], 0, annotation
                else:
                    self.rule('equality_transport')
                    matrix, (left, right) = annotation, major
                if self.open(matrix, right) != goal:
                    return False
                return self.check(self.open(matrix, left), context)
        if instruction == []:
            self.rule('iteration_computation')
            if len(goal) != 2 or type(goal[0]) is not list or len(goal[0]) != 3:
                raise ValueError('computation requires a literal iterator equation')
            counter, initial, update = goal[0]
            if counter == 0:
                expected = initial
            elif type(counter) is list and len(counter) == 1:
                expected = self.open(update, [counter[0], initial, update], formula=False)
            else:
                raise ValueError('computation counter is neither zero nor successor')
            return goal[1] == expected
        # False elimination guards fall through; malformed shapes raise and
        # abort. Returning False in place of such an exception would change
        # the meaning of this raw instruction format.
        if len(goal) not in (1, 3):
            raise ValueError('introduction requires a logical goal')
        self.rule('closure_introduction' if len(goal) == 1 else 'paired_introduction')
        body = self.open(goal[0], instruction, depth=1)
        assumptions = [self.open(body, 0)]
        if len(body) == 2:
            assumptions.insert(0, body)
        syntax = Syntax(self.lower)
        bound_y = syntax.fresh()
        body_names = names_in(syntax.formula(body, (bound_y,)))
        eigen = self.fresh([goal, *context])
        assert eigen not in body_names
        conclusion = self.open(body, [eigen])
        added = [self.open(a, eigen) for a in assumptions]
        return self.check(conclusion, context + added)

    def run(self, packet, lower=0):
        return super().run(normalize(packet), lower=lower)
