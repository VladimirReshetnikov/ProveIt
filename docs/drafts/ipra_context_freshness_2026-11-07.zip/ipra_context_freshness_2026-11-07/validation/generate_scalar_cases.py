"""Independent finite scalar-iterator certificates and adversarial controls.

The evaluation proof builder uses only the two iterator computation axioms and
equality transport. Its certificates are untrusted outputs checked separately
by the candidate programs and an explicit named-binder oracle.
"""
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
import json


@dataclass
class Proof:
    goal: list
    cells: list


def numeral(number):
    result = 0
    for _ in range(number):
        result = [result]
    return result


def value_of_numeral(term):
    count = 0
    while type(term) is list and len(term) == 1:
        count += 1
        term = term[0]
    if type(term) is not int or term != 0:
        return None
    return count


def refl(term):
    axiom = [[0, term, 0], term]
    return Proof([term, term], [[axiom, [1, term]], [], []])


def trans(first, second):
    if first.goal[1] != second.goal[0]:
        raise ValueError('incompatible equality proofs')
    return Proof([first.goal[0], second.goal[1]],
                 [[second.goal, [first.goal[0], 1]], *second.cells, *first.cells])


def successor_congruence(proof):
    left = [proof.goal[0]]
    return Proof([left, [proof.goal[1]]],
                 [[proof.goal, [left, [1]]], *proof.cells, *refl(left).cells])


def replace_previous(body, image, protected=0):
    if type(body) is int:
        if body <= 0:
            return body
        slot = (body - 1) // 2
        if slot < protected:
            return body
        if slot == protected:
            return deepcopy(image)
        raise ValueError('unbound update coordinate in generated term')
    if len(body) == 1:
        return [replace_previous(body[0], image, protected)]
    if len(body) == 3:
        return [replace_previous(body[0], image, protected),
                replace_previous(body[1], image, protected),
                replace_previous(body[2], image, protected + 1)]
    raise ValueError('invalid update term')


def evaluate_proof(term):
    if value_of_numeral(term) is not None:
        return refl(term)
    if len(term) == 1:
        return successor_congruence(evaluate_proof(term[0]))
    counter, initial, update = term
    n = value_of_numeral(counter)
    if n is None:
        evaluated_counter = evaluate_proof(counter)
        normalized = [evaluated_counter.goal[1], initial, update]
        motive = [term, [1, initial, update]]
        bridge = Proof([term, normalized],
                       [[evaluated_counter.goal, motive], *evaluated_counter.cells,
                        *refl(term).cells])
        return trans(bridge, evaluate_proof(normalized))
    if n == 0:
        direct = Proof([term, initial], [[]])
        return trans(direct, evaluate_proof(initial))
    previous = [counter[0], initial, update]
    reduced = replace_previous(update, previous)
    return trans(Proof([term, reduced], [[]]), evaluate_proof(reduced))


def packet(proof):
    return list(reversed(proof.cells)) + [proof.goal]


def cases():
    truth, one, two = [0, 0], [0], [[0]]
    result = []
    def add(name, certificate, expected, explanation):
        result.append({'name': name, 'packet': certificate, 'expected': expected,
                       'explanation': explanation})
    # Finite computation proofs, generated from scalar-iterator syntax alone.
    terms = [
        [0, one, 1],
        [one, 0, [1]],
        [two, 0, [1]],
        [numeral(3), one, [[1]]],
        [two, one, [two, 1, [1]]],
        [two, one, [two, 1, 3]],
        [numeral(3), 0, [[1, 0, [1]]]],
        [[two, 0, [1]], one, [1]],
    ]
    for index, term in enumerate(terms):
        proof = evaluate_proof(term)
        expected_value = value_of_numeral(proof.goal[1])
        if expected_value is None or len(proof.cells) > 5000:
            raise ValueError('bad finite evaluation proof')
        name = f'scalar_evaluation_{index:02d}'
        add(name, packet(proof), True,
            {'standard_value': expected_value, 'instruction_cells': len(proof.cells)})
        bad = packet(proof)
        bad[-1] = [term, [proof.goal[1]]]
        add(name + '_false_successor', bad, False,
            'Same proof instructions with the final numerical result changed by one.')
    add('previous_alias_2', [[], [[one, 0, 2], [0, 0, 2]]], True,
        'Both paired spellings1 and2 denote the single previous-value binder.')
    add('nonexistent_counter_slot', [[], [[0, 0, 3], 0]], False,
        'Coordinate3 is unbound at a closed scalar-iterator update, even under I0.')
    add('nonexistent_counter_alias', [[], [[0, 0, 4], 0]], False,
        'Coordinate4 is likewise not a second update binder.')
    add('future_parameter_in_unused_update', [[], [[0, 0, -1], 0]], False,
        'Full formation validates unused update bodies before any fresh allocation.')
    add('boolean_in_unused_update', [[], [[0, 0, True], 0]], False,
        'JSON booleans are not numerical leaves.')
    add('false_zero_equation', [[], [[0, one, 1], 0]], False,
        'I0 returns its actual initial value.')
    outer_previous = [0, one, [one, 1, 3]]
    nested = [one, one, [one, 1, 3]]
    add('nested_outer_previous',
        [[], [nested, [one, outer_previous, outer_previous]]], True,
        'Coordinate3 under the inner update refers to the outer previous value.')
    add('nested_unbound_coordinate', [[], [[0, 0, [0, 1, 5]], 0]], False,
        'Only two previous-value binders exist in this nested update.')
    add('formula_variable_beneath_iterator',
        [[], [0], [[[0, 0, 3], 0], truth, truth]], True,
        'Coordinate3 under an iterator can denote the surrounding formula variable.')
    add('first_formula_variable_beneath_iterator',
        [[], [one], [[[0, 3, 5], 3], truth, truth]], True,
        'Both formula binders retain their scope when an iterator binder is entered.')
    # A4-cell false formula becomes accepted by depth-contextual image validation.
    eigen = -1
    term = [[eigen], 0, [eigen]]
    reflexivity_major = [[0, term, 0], term]
    consumption = [[3], [reflexivity_major, [1, term]], [], []]
    capture_goal = [[[1, 0, 5], [1, 0, 3]], truth, truth]
    add('scalar_contextual_capture', consumption[::-1] + [capture_goal], False,
        'D_xy G_y(x=y) is false: its base is true, but no x equals all successors. '
        'Witness coordinate3 must be rejected at its own depth zero.')
    return result


if __name__ == '__main__':
    target = Path(__file__).resolve().parent/'new_cases/scalar_cases.json'
    target.write_text(json.dumps(cases(), indent=2) + '\n')
    print('Generated', len(cases()), 'scalar cases.')
