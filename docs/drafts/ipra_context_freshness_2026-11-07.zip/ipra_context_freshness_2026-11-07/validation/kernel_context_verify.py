"""Focused validation of scope-local eigenparameters.

Finite tests support implementation confidence; the allocator elimination
and iPRA equivalence are mathematical metatheorems, not consequences of tests.
"""
import ast
from collections import Counter
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import types

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from kernel_context_oracle import ContextOracle, BASE, normalize
from kernel_context_translate import ContextCompiler
from named_oracle import Oracle
from new_cases import cases

OUT = HERE.parent / 'results/context_validation'
OUT.mkdir(parents=True, exist_ok=True)
KERNEL = HERE.parent / 'checker.py'


def load_definitions(path):
    """The complete public CLI is tested separately below."""
    tree = ast.parse(path.read_text())
    tree.body = [node for node in tree.body
                 if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef))]
    module = types.ModuleType('tested_context_kernel')
    exec(compile(tree, str(path), 'exec'), module.__dict__)
    return module


kernel = load_definitions(KERNEL)


def run(packet):
    stack = deepcopy(packet)
    try:
        kernel.take = stack.pop
        accepted = bool(kernel.check(stack.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {'accepted':accepted,
            'remaining':len(stack) if isinstance(stack,list) else None,
            'error':error}


def verify(packet, label, expected=None):
    actual = run(packet)
    oracle = ContextOracle().run(packet)
    assert actual['accepted'] == oracle['accepted'], (label, actual, oracle)
    if actual['accepted']:
        assert actual['remaining'] == oracle['remaining'], (label, actual, oracle)
    if expected is not None:
        assert actual['accepted'] == expected, (label, actual)
    return {'name':label, **actual, 'oracle_allocations':oracle['allocations'],
            'oracle_rules':oracle['rules']}


def packet(goal, cells):
    return list(reversed(cells)) + [goal]


def refl(term, initial=0):
    major = [[ [0], initial, term], term]
    return [[major, [1,term]], [], []]


inherited = json.loads((BASE / 'inherited_fixtures.json').read_text())
rows = inherited + cases(inherited)
translated = []
checks = []
for row in rows:
    if not row['expected']:
        continue
    compiled = ContextCompiler().run(row['packet'])
    checks.append(verify(compiled['packet'], 'translated/' + row['name'], True))
    translated.append({'name':row['name'], **compiled})

# After an atomic introduction, g has two assumptions. Its admitted floor is
# -2 although the induction eigenparameter is -1. The spare parameter -2 is
# auxiliary and absent from the sequent; arbitrary initial values are sound.
gap_goal = [[1,1]]
gap_packet = packet(gap_goal, [0, *refl([-1], initial=-2)])
checks.append(verify(gap_packet, 'scope/two_assumption_gap', True))
(OUT / 'two_assumption_gap.json').write_text(json.dumps(gap_packet) + '\n')

# Source-global allocations from a completed sibling proof are later reused
# as auxiliary witnesses. The compiler replaces such inactive names by zero.
q = [[0,0]]
d = [[3,3], [0,0], [0,0]]
m = [[0,0,0],0]
source_sibling = packet([0,0], [[q,0], [0], [d,0], [-1], [m,[1,0]], [], []])
assert Oracle().run(source_sibling)['accepted']
sibling = ContextCompiler().run(source_sibling)
assert sibling['erased_auxiliaries'] == [-1]
checks.append(verify(sibling['packet'], 'scope/sibling_auxiliary_erasure', True))
assert len({entry['target'] for entry in sibling['renamings']}) < len(sibling['renamings'])
(OUT / 'sibling_auxiliary_erasure.json').write_text(json.dumps(sibling,indent=2) + '\n')

# Direct negative-parameter leak. Root validation must fail before any
# subproof can allocate the name; a later allocation cannot legalize it.
bad = []
for name in (-1,-2,-999):
    bad.append((f'root_future_parameter_{name}', packet([name,name], refl(name))))
    bad.append((f'root_future_update_{name}', [[], [[0,0,name],0]]))
    bad.append((f'future_paired_witness_{name}', packet(d, [name])))
    bad.append((f'future_transport_template_{name}', packet([0,0], [[m,[1,name]],[],[]])))
for value in (True,False,0.0,1.0,None,{},'x',[]):
    # Booleans are intentionally valid numeric aliases, so put them at the
    # formula root; neither Boolean is a complete formula.
    bad.append(('malformed_goal_' + repr(value), [[],value]))
for label,value in [('outer_hole',3),('large_hole',999),('future',-3),('float',0.0),('dict',{}),('empty',[])]:
    corrupted = deepcopy(gap_packet)
    # The child major in refl uses the spare -2 initializer. It must remain a
    # legal closed term at the child's floor, and a positive root hole fails.
    for cell in corrupted[:-1]:
        if isinstance(cell,list) and len(cell)==2 and isinstance(cell[0],list) and len(cell[0])==2:
            cell[0][0][1] = value
            break
    bad.append(('gap_initializer_' + label,corrupted))
for label,p in bad:
    checks.append(verify(p,'malformed/' + label,False))

# Boolean normalization must commute with all used operations, including
# rigid-name range checks, constructor dispatch, and structural equality.
def bool_aliases(v):
    if type(v) is int and v in (0,1):
        return bool(v)
    if isinstance(v,list):
        return [bool_aliases(x) for x in v]
    return v
for row in translated:
    p = bool_aliases(row['packet'])
    checks.append(verify(p, 'boolean/' + row['name'], True))
    assert run(p)['accepted'] == run(normalize(p))['accepted']

# Differential malformed-input probes against the independent named parser.
# These are local single-node changes, not random claims about arithmetic.
rng = random.Random(20261107)
mutation_checks = []
substitutes = [-999, -3, -2, -1, 0, 1, 3, 999, True, False, 0.0, None, {}, [], [0], [0,0], 'bad']
def paths(v, prefix=()):
    yield prefix
    if isinstance(v,list):
        for i,x in enumerate(v):
            yield from paths(x,prefix+(i,))
for i in range(800):
    original = translated[i % len(translated)]['packet']
    p = deepcopy(original)
    address = rng.choice(list(paths(p)))
    value = deepcopy(rng.choice(substitutes))
    if not address:
        p = value
    else:
        node=p
        for index in address[:-1]:node=node[index]
        node[address[-1]]=value
    mutation_checks.append(verify(p,f'mutation/{i}'))

# Both ordinary and optimized Python run the entire unchanged public file.
cli_checks=[]
for label,p,want in [('accept_gap',gap_packet,True),('accept_sibling',sibling['packet'],True),('reject_escape',bad[0][1],False)]:
    target=OUT/(label+'.json');target.write_text(json.dumps(p)+'\n')
    for optimized in (False,True):
        args=[sys.executable,*(['-O'] if optimized else []),str(KERNEL),str(target)]
        r=subprocess.run(args,capture_output=True,text=True,timeout=10)
        expected=(0,'ACCEPT','') if want else (1,'REJECT','')
        assert (r.returncode,r.stdout.strip(),r.stderr)==expected,(label,r)
        cli_checks.append({'name':label,'optimized':optimized,'returncode':r.returncode,'stdout':r.stdout.strip()})

spec=importlib.util.spec_from_file_location('source_measure',HERE.parent/'comparison/source_measure.py')
metric=importlib.util.module_from_spec(spec);spec.loader.exec_module(metric)
result={
    'statement':'Finite validation; not a formal proof of iPRA equivalence.',
    'canonical_source_proofs_translated':len(translated),
    'focused_checks':len(checks),
    'mutation_checks':len(mutation_checks),
    'mutation_verdicts':dict(Counter(x['accepted'] for x in mutation_checks)),
    'cli_checks':cli_checks,
    'metrics':metric.metrics(KERNEL),
    'focused_results':checks,
    'mutation_results':mutation_checks,
}
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'translated_cases.json').write_text(json.dumps(translated,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('focused_results','mutation_results')},indent=2))
