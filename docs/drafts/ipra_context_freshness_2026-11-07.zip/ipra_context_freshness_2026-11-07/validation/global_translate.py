"""Untrusted wrapper-removal compiler preserving global numerical names.

The source derivation is parsed along its actual proof trace. Numerical
introduction annotations lose exactly their outer instruction wrapper;
unused introduction annotations are replaced by canonical zero. Numerical
successor constructors inside a used witness are left untouched.
"""
from copy import deepcopy
from kernel_context_translate import ContextCompiler


class GlobalCompiler(ContextCompiler):
    def rename(self, value, names):
        return deepcopy(value)

    def child_names(self, context, names):
        self.lower -= 1
        eigen = self.lower
        self.renamings.append({'source':eigen, 'target':eigen,
                              'scope_size':len(context)})
        return eigen, {**names, eigen:eigen}
