"""Concrete one-hole motive examples, arithmetic certificates, and controls.

The proof builder is untrusted.  Every output is passed independently through
the candidate CLI, the named oracle, or both by verify.py.
"""
from copy import deepcopy
from generate_scalar_cases import Proof, evaluate_proof, numeral, packet, refl


def cases(inherited):
    rows = []
    def add(name, proof_packet, expected=True, reason='', five=None):
        rows.append({'name': 'new/' + name, 'cohort': 'one_hole',
                     'packet': proof_packet, 'expected': expected,
                     'five_expected': expected if five is None else five,
                     'reason': reason})

    # I(0,0;u.0)=0, followed by the motive x=0.  Only the name of the
    # template hole varies; the theorem and all actual terms are unchanged.
    major = [[0, 0, 0], 0]
    for alias in (1, 2, 3, 4, 5, 255, 256, 65535, 10**40):
        cells = [[major, [alias, 0]], [], []]
        add(f'motive_alias_{alias}', packet(Proof([0, 0], cells)),
            reason='Every out-of-scope positive template coordinate denotes the same hole.')

    initial = major[0]
    mixed = Proof([0, 0], [[major, [7, 999]], [], *refl(initial).cells])
    add('mixed_aliases_same_hole', packet(mixed),
        reason='Distinct excess coordinates 7 and 999 are aliases, not two variables.')

    # Q_y(I(0,x;u.I(0,u;v.x))=x) is a theorem for each closed x.
    # Hole names exceed every local binder count and occur at different depths.
    # The Q proofs use the derived rule via D, so both kernels accept them.
    motive = [[[0, 77, [0, 1, 99]], 77]]
    def closed_q_proof(image):
        body = [[0, image, [0, 1, image]], image]
        paired = [body, [0, 0], [0, 0]]
        return Proof([body], [[paired, None], [0], []])
    target = closed_q_proof(0).goal
    left = closed_q_proof(initial)
    add('nested_motive_aliases', packet(Proof(target, [[major, motive], [], *left.cells])),
        reason='One template hole is opened beneath both logical and scalar-update binders.')

    # Direct Q introduction is new syntax in the smaller main checker; the
    # five-rule companion accepts the same theorem through the older derived rule.
    direct_goal = [[1, 1]]
    direct = Proof(direct_goal, [[None], *refl([-1]).cells])
    add('direct_closure_reflexivity', packet(direct), five=False,
        reason='A direct Q-introduction certificate; the witness annotation is unused.')
    source = next(r for r in inherited if r['name'] == 'original/retained_base_separation')
    paired_packet = deepcopy(source['packet'])
    paired_goal = paired_packet[-1]
    direct_separation = deepcopy(paired_packet)
    direct_separation[-1] = [paired_goal[0]]
    add('direct_closure_retained_base', direct_separation, five=False,
        reason='Direct Q_x(x=S0) retains its contradictory base; the induction hypothesis is unused.')
    derived = paired_packet[:-1] + [[paired_goal, None], [paired_goal[0]]]
    add('derived_closure_retained_base', derived,
        reason='Both kernels prove the same Q sentence by paired introduction and elimination.')

    for alias in (1, 3, 65535):
        bad = packet(Proof([alias, alias], refl(0).cells))
        add(f'global_goal_hole_{alias}', bad, False,
            'A closed goal has no template image, so an unbound coordinate is forbidden.')
    add('global_initializer_hole', [[], [[0, 3, 1], 3]], False,
        'An unbound root parameter must not acquire an implicit default zero image.')
    for bad_leaf in (-1, -999, True, False, 0.0, None, {}):
        add('invalid_unused_update_' + repr(bad_leaf).replace(' ', '_'),
            [[], [[0, 0, bad_leaf], 0]], False,
            'All unused update syntax is validated at the root; future names and nonterms fail.')
    for alias in (3, 4, 999):
        add(f'old_counter_is_not_a_hole_{alias}', [[], [[0, 0, alias], 0]], False,
            'In a closed scalar update only one binder exists; there is no supplied image.')

    add('used_future_motive_parameter', packet(Proof([0, 0], [[major, [-999, 0]], [], []])),
        False, 'A template may alias positive holes but cannot introduce an undeclared rigid name.')
    add('malformed_motive_formula', packet(Proof([0, 0], [[major, [1, 2, 3]], [], []])),
        False, 'Template opening preserves the strict term/formula grammar.')
    capture = next(r for r in inherited if r['name'] == 'original/scalar_contextual_capture')
    add('true_capture_attack', deepcopy(capture['packet']), False,
        'A used witness must be closed at its own insertion depth; this would prove a false sentence if captured.')
    escape = next(r for r in inherited if r['name'] == 'original/false_eigenparameter_escape')
    add('future_eigenparameter_escape', deepcopy(escape['packet']), False,
        'The root sentence cannot refer to the eigenparameter allocated only later in its proof.')
    add('unevaluated_counter_not_a_computation', [[], [[[0, 0, 1], 0, 1], 0]], False,
        'The local computation rule requires a literal zero or successor counter, not a reducible counter.')
    add('empty_array_term_not_zero', [[], [[[], 0, 1], 0]], False,
        'Zero is integer 0; an empty JSON list is not a numerical constructor.')
    add('nonarray_packet', {'goal': [0, 0]}, False,
        'The command-line certificate must be an array.')

    # Additional closed arithmetic proofs.  Their values are checked using a
    # separate literal iterator evaluator in verify.py.
    two, three = numeral(2), numeral(3)
    arithmetic = [
        ('add_two_three', [three, two, [1]], 5),
        ('multiply_two_three', [three, 0, [two, 1, [1]]], 6),
        ('power_two_three', [three, [0], [1, 1, [1]]], 8),
        ('parity_three', [three, 0, [1, [0], 0]], 1),
        ('nested_previous_copy', [two, three, [two, 1, 3]], 3),
        ('nested_counter_evaluation', [[two, 0, [1]], three, [1]], 5),
    ]
    for name, term, expected_value in arithmetic:
        proof = evaluate_proof(term)
        row = {'name': 'new/arithmetic/' + name, 'cohort': 'one_hole_arithmetic',
               'packet': packet(proof), 'expected': True, 'five_expected': True,
               'standard_value': expected_value, 'instruction_cells': len(proof.cells)}
        rows.append(row)
        false_packet = packet(proof)
        false_packet[-1] = [term, numeral(expected_value + 1)]
        add('false_arithmetic/' + name, false_packet, False,
            'The same certificate cannot prove the successor of its correct numerical result.')
    return rows
