VALIDATION SUPPORT: NOT PART OF THE TRUSTED ACCEPTANCE PROGRAMS

Run from any working directory with Python 3.10 or newer:

  python3 /absolute/path/to/validation/kernel_context_verify.py
  python3 /absolute/path/to/validation/verify_global.py

Both scripts are self-contained within this archive. They use only Python's
standard library. They write reproducible results and concrete certificates
under ../results/context_validation and ../results/global_validation.
The unchanged source metric is ../comparison/source_measure.py.

Context-derived checker (../checker.py)
--------------------------------------
- Complete source: 381 normalized tokens, 409 AST nodes, 1142 normalized bytes.
- SHA-256: e8ea27e7cf9c78a33ea1f7dc6ed6e7dee6fd95b29c906188dd90832ceae0788a
- 120 accepted old canonical derivations translated to local scope names.
- 268 focused checks, including those 120 translations, 120 Boolean copies,
  two positive scope examples, and 26 targeted malformed/escape controls.
- 800 reproducible single-node mutations compared with an independent named
  parser and rule interpreter: 719 rejected and 81 accepted, zero disagreement.
- Six complete CLI checks: two positive examples and one rejected escape,
  each with ordinary Python and Python -O.

kernel_context_oracle.py parses binders using names and explicit constructor
cases. It uses neither the production opening helper nor its packed depth
array. Every local call computes its own floor from the context length.
Freshness is independently audited against sets of occurring parameter names.

kernel_context_translate.py traverses actual accepted source derivations.
It renames eigenparameters lexically and substitutes zero for inactive
auxiliary source parameters. The two-assumption-gap example deliberately
uses a spare active label. The sibling example demonstrates both reuse of a
local eigenparameter code and erasure of an inactive global-clock parameter.
Raw-packet equivalence with the older global allocator is not asserted.

Global-clock companion (../checker_global.py)
---------------------------------------------
- Complete source: 379 normalized tokens, 404 AST nodes, 1129 normalized bytes.
- SHA-256: 9edccd10f904dbd23ea287c3c3824e315dc8a3c0b786a328ab5ff3859334aa53
- 120 accepted old canonical derivations converted to raw witness instructions.
- 120 Boolean-alias copies, 29 focused negative controls, and one positive
  sibling-parameter example: 270 focused checks total.
- Six complete CLI checks, again including ordinary Python and Python -O.

The global compiler removes instruction wrappers along the parsed proof
trace. It does not remove successor constructors from numerical witnesses.
All source eigenparameter numbers and accepted-trace allocation counts are
preserved. global_oracle.py uses the independent named parser but retains a
shared global floor, as the companion's certificate contract requires.

The production files are never imported by each other and import none of
this validation support. Testing their functions uses AST extraction of
imports and function definitions; separate CLI tests run the complete,
unchanged files including their public input/exception/verdict boundaries.

Inherited material and scope of evidence
---------------------------------------
The following files are copied unchanged from the current one-hole archive:
  named_oracle.py
  inherited_fixtures.json
  new_cases.py
  generate_scalar_cases.py

Their exact provenance and hashes are in inherited_provenance.json. The
source repository was inspected at commit
6ee66e8e01b8cf39d81f53fce44cbedfede2dfdb.

named_oracle.py is also the independent acceptance oracle for the original
wrapped, integer-only source packets. Its syntax parser is reused by the
new oracles; the changed scope policy and raw instruction interpreter are
implemented explicitly in their own files.

A malformed subproof that raises an exception must abort the entire packet.
An ordinary False result from an elimination guard can fall through to
introduction. The new named oracles preserve this distinction. Unused
annotations and unused certificate prefixes may be inert; their presence
is not itself a reason to reject a sound proof.

These are finite implementation checks. They do not prove consistency,
canonical completeness, or the bi-interpretation theorem. Those claims
require the mathematical arguments in the report. No Lean or Rocq
formalization is claimed.
