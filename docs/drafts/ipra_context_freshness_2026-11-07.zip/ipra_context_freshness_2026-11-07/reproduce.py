"""Recompute the frozen comparison and both independent validation suites."""
from pathlib import Path
import json
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    steps = ['comparison/measure.py',
             'validation/kernel_context_verify.py',
             'validation/verify_global.py']
    (ROOT / 'results').mkdir(exist_ok=True)
    records = []
    for step in steps:
        process = subprocess.run([sys.executable, str(ROOT / step)], cwd=ROOT,
                                 capture_output=True, text=True)
        log_name = Path(step).stem + '_run.txt'
        (ROOT / 'results' / log_name).write_text(process.stdout + process.stderr)
        record = {'script': step, 'returncode': process.returncode,
                  'log': 'results/' + log_name}
        records.append(record)
        print(('PASS ' if process.returncode == 0 else 'FAIL ') + step)
        if process.returncode:
            print(process.stdout[-4000:])
            print(process.stderr[-4000:])
            raise SystemExit(process.returncode)
    result = {'status': 'PASS', 'python': platform.python_version(),
              'steps': records,
              'scope': 'Finite implementation verification and source measurement; '
                       'not a proof-assistant certification of the metatheory.'}
    (ROOT / 'results/reproduction.json').write_text(
        json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
