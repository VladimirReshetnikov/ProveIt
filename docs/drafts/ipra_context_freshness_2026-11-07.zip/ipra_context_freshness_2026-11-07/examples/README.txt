Each file is a complete proof packet.

python3 checker.py examples/context_valid.json
  Expected: ACCEPT, exit 0.
python3 checker.py examples/reject_escape.json
  Expected: REJECT, exit 1.
python3 checker_global.py examples/global_valid.json
  Expected: ACCEPT, exit 0.

More certificates and translated derivations are in results/context_validation
and results/global_validation. The parameter conventions of the two checkers
are different; raw-packet equivalence is not claimed.
