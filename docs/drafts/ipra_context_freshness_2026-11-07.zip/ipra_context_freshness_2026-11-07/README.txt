FRESH VARIABLES FROM ASSUMPTIONS
Prepared for Vladimir Reshetnikov, 7 November 2026

Read ipra_context_freshness.pdf for the full report.
The matching .tex file and sections/ contain all mathematical source.

RESULT
Current six-archive corpus: 389 tokens / 413 AST nodes / 1159 normalized bytes.
Context-based checker.py:   381 tokens / 409 AST nodes / 1142 normalized bytes.
Global checker_global.py:  379 tokens / 404 AST nodes / 1129 normalized bytes.

The new positive idea is context-derived freshness: the next eigenparameter
is -len(context)-1, and every allocating rule adds at least one assumption.
It removes shared global name-allocation state.

The global companion is slightly smaller. Its reduction combines existing
ingredients; it is not claimed as a new arithmetic basis. Both programs
faithfully present the inherited scalar calculus, whose ordinary realization
is bi-interpretable with full first-order intuitionistic PRA.

The report also extends the fixed-seed term-function obstruction to
counter-dependent seeds h^n(phi(n)). It does not establish general
uninterpretability of a changed-domain theory.

SCOPE
The comparison is relative to the six current archives at ProveIt commit
6ee66e8e01b8cf39d81f53fce44cbedfede2dfdb.
No absolute shortestness or historical priority claim is made.
Written proofs and finite executable checks are distinguished. No Lean or
Rocq formalization of the entire metatheory is claimed.

USAGE
  python3 checker.py examples/context_valid.json
  python3 checker.py examples/reject_escape.json

A packet is a JSON list with the closed goal last and a reverse-consumption
instruction stream before it. Success prints ACCEPT and exits zero.
The two checkers have different rigid-parameter conventions; use certificates
prepared for the corresponding checker. Neither imports validation support.

REPRODUCE
  python3 reproduce.py
  python3 build.py

The first command recomputes whole-program source measurements and finite
checker validation offline. The second needs a pdfLaTeX installation and
the standard packages listed in the TeX preamble.
Checkers need Python 3.10 or later. Recorded normalization used CPython 3.12.14.
The mathematical completeness statement idealizes finite resource limits.

CONTENTS
  checker.py, checker_global.py       Complete acceptance programs.
  ipra_context_freshness.tex/.pdf     Report and compiled document.
  sections/                         Full mathematical development.
  comparison/                       Frozen metric and comparator sources.
  validation/                       Independent named oracles and tests.
  examples/                         Small public-CLI examples.
  results/                          Reproducible measurements and checks.
  ATTRIBUTION.txt                    Detailed provenance.
  LICENSE-inherited.txt              Preserved source license.

The report includes all logical and nonlogical schemas and inference rules,
both ordinary interpretations and their identity isomorphisms, and Further
research questions.
