"""Reproduce the complete-source comparison using only this archive.

Run from any working directory with: python3 comparison/measure.py
Frozen sources are hash-verified but never executed.  The inherited
source_measure.py is preserved byte-for-byte; only its whole-program
metrics are used.  Its unequal-wrapper 'core' heuristic is deliberately
excluded from every comparison and output produced here.
"""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import platform
import sys


HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parent
COMMIT = '6ee66e8e01b8cf39d81f53fce44cbedfede2dfdb'
MEASURES = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
FIELDS = ('source_tokens', *MEASURES, 'raw_bytes', 'sha256')
NORMALIZER_SHA256 = 'f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(name):
    return json.loads((HERE / name).read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def local_source(relative):
    path = (HERE / relative).resolve()
    require(path.is_relative_to(HERE), 'Comparator path escapes comparison/: ' + relative)
    require(path.is_file(), 'Missing frozen comparator: ' + relative)
    return path


def load_metric():
    path = HERE / 'source_measure.py'
    require(digest(path) == NORMALIZER_SHA256, 'Inherited source_measure.py has changed')
    spec = importlib.util.spec_from_file_location('frozen_source_measure', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.metrics


def envelope(rows):
    return {key: min(row[key] for row in rows) for key in MEASURES}


def attainers(rows, minima):
    return {key: [row['local_file'] for row in rows if row[key] == minima[key]]
            for key in MEASURES}


def main():
    snapshot = read_json('github_snapshot.json')
    expanded_manifest = read_json('expanded_manifest.json')
    current_manifest = read_json('current_programs.json')
    archive_hashes = read_json('archive_hashes.json')
    require(snapshot['commit'] == COMMIT, 'Unexpected GitHub snapshot commit')
    require(expanded_manifest['commit'] == COMMIT, 'Unexpected expanded inventory commit')
    require(len(current_manifest) == 13, 'Expected thirteen current root programs')
    require(len(snapshot['archives']) == len(archive_hashes) == 6, 'Expected six source archives')
    require(expanded_manifest['normalizer']['sha256'] == NORMALIZER_SHA256,
            'Expanded manifest names a different source normalizer')
    archive_by_name = {entry['file']: entry for entry in archive_hashes}
    for entry in snapshot['archives']:
        require(entry['name'] in archive_by_name, 'Archive provenance sets disagree')
        require(entry['size'] == archive_by_name[entry['name']]['bytes'],
                'Archive byte counts disagree: ' + entry['name'])

    measure = load_metric()

    def measured(path):
        values = measure(path)
        return {key: values[key] for key in FIELDS}

    def frozen(entry):
        path = local_source(entry['local_file'])
        require(digest(path) == entry['sha256'], 'Frozen-source hash mismatch: ' + entry['local_file'])
        return measured(path)

    current = []
    for index, entry in enumerate(current_manifest):
        current.append({'label': 'current_' + str(index),
                        'local_file': entry['local_file'],
                        'original_path': entry['original_path'],
                        **frozen(entry)})

    expanded = []
    path_hashes = {}
    for entry in expanded_manifest['programs']:
        require(entry['original_paths'], 'Expanded source has no original path')
        for path in entry['original_paths']:
            require(path not in path_hashes, 'Original path appears twice: ' + path)
            path_hashes[path] = entry['sha256']
        expanded.append({'label': entry['sha256'],
                         'local_file': entry['local_file'],
                         'original_path_count': len(entry['original_paths']),
                         **frozen(entry)})
    require(len(expanded) == expanded_manifest['unique_source_count'] == 129,
            'Expected 129 distinct frozen expanded sources')
    require(len({row['sha256'] for row in expanded}) == 129, 'Expanded hashes are not unique')
    require(len(path_hashes) == expanded_manifest['path_count'] == 530,
            'Expected 530 original source paths')
    for entry in current_manifest:
        require(path_hashes.get(entry['original_path']) == entry['sha256'],
                'A current root program is missing from the expanded mapping')

    current_minimum = envelope(current)
    expanded_minimum = envelope(expanded)
    require(current_minimum == expanded_minimum,
            'Expanded inventory changed the current comparison envelope')
    candidates = []
    for filename in ('checker.py', 'checker_global.py'):
        row = {'label': filename, 'local_file': '../' + filename,
               **measured(PACKAGE / filename)}
        row['below_current'] = {key: row[key] < current_minimum[key] for key in MEASURES}
        row['below_expanded'] = {key: row[key] < expanded_minimum[key] for key in MEASURES}
        row['strict_below_both'] = all(row['below_current'].values()) and all(row['below_expanded'].values())
        row['decrease_from_current'] = {key: current_minimum[key] - row[key] for key in MEASURES}
        candidates.append(row)

    result = {
        'status': 'PASS' if all(row['strict_below_both'] for row in candidates) else 'FAIL',
        'repository': 'VladimirReshetnikov/ProveIt',
        'commit': COMMIT,
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'recorded_python': expanded_manifest['recorded_python'],
        'whole_program_only': True,
        'normalizer_sha256': NORMALIZER_SHA256,
        'metric_note': 'Strip genuine docstrings; ast.unparse plus newline; count significant tokens, all AST nodes, and normalized UTF-8 bytes. Imports, syntax checking, proof rules, JSON input, exception handling, and verdicts remain included. Runtime normalization can vary with Python versions.',
        'excluded_metric_note': 'The inherited core heuristic is not used: it treats wrapped and unwrapped command-line drivers unequally.',
        'archive_count': len(archive_hashes),
        'archive_provenance': archive_hashes,
        'archive_verification_note': 'ZIP SHA-256 values and Git blob IDs record acquisition provenance. Offline replay verifies the frozen Python source bytes; it does not require or rehash the original ZIP archives.',
        'current_program_count': len(current),
        'expanded_unique_source_count': len(expanded),
        'expanded_original_path_count': len(path_hashes),
        'expanded_inventory_rule': expanded_manifest['inventory_rule'],
        'expanded_mapping': 'comparison/expanded_manifest.json',
        'current_minimum': current_minimum,
        'expanded_minimum': expanded_minimum,
        'current_minimum_attainers': attainers(current, current_minimum),
        'expanded_minimum_attainers': attainers(expanded, expanded_minimum),
        'current_programs': current,
        'expanded_programs': expanded,
        'candidates': candidates,
        'claim_limit': 'A finite-corpus lower envelope, not an encoding-independent lower bound or an absolute shortestness theorem.',
    }
    destination = PACKAGE / 'results'
    destination.mkdir(exist_ok=True)
    (destination / 'comparison.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    fields = ('cohort', 'label', 'local_file', *FIELDS, 'original_path', 'original_path_count')
    with (destination / 'comparison.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fields, extrasaction='ignore')
        writer.writeheader()
        for cohort, rows in (('current', current), ('expanded', expanded), ('candidate', candidates)):
            writer.writerows({'cohort': cohort, **row} for row in rows)
    print(json.dumps({key: result[key] for key in (
        'status', 'commit', 'python', 'current_program_count',
        'expanded_unique_source_count', 'expanded_original_path_count',
        'current_minimum', 'expanded_minimum', 'candidates')}, indent=2))
    require(result['status'] == 'PASS', 'At least one candidate is not strictly below both envelopes')


if __name__ == '__main__':
    main()
