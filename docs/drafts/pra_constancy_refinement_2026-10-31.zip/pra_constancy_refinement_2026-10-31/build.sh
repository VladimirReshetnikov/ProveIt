#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
mkdir -p build
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=build pra_constancy_refinement.tex
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=build pra_constancy_refinement.tex
cp build/pra_constancy_refinement.pdf pra_constancy_refinement.pdf
