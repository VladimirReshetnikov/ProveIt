#!/usr/bin/env python3
"""Auditable executable companion to the PRA constancy refinement.

This is a syntactic compiler and a collection of finite and symbolic checks.
It is NOT a proof checker for first-order arithmetic.  In particular, finite
evaluation does not establish the manuscript's equivalence theorem, the
soundness of induction, or the validity of a schema in nonstandard models.

Only Python's standard library is used.  Run:

    python3 pra_compiler.py --write-report verification.json

The expression language has one numerical sort, 0, S, variables, and fresh
primitive-recursion declarations.  The definitions of p, monus, and c below
are descriptions, not unverified calls to Python's arithmetic operations.
Python arithmetic is used separately as a finite reference interpretation.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import hashlib
from itertools import product
import json
from pathlib import Path
import random
import re
from typing import Iterable, Mapping


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Call:
    name: str
    args: tuple[Term, ...]


Term = Zero | Var | Call
ZERO = Zero()


def call(name: str, *args: Term) -> Call:
    return Call(name, tuple(args))


def succ(term: Term) -> Call:
    return call("S", term)


ONE = succ(ZERO)


def numeral(value: int) -> Term:
    if type(value) is not int or value < 0:
        raise ValueError("A numeral is a nonnegative integer.")
    result: Term = ZERO
    for _ in range(value):
        result = succ(result)
    return result


def free_variables(term: Term) -> set[str]:
    if isinstance(term, Zero):
        return set()
    if isinstance(term, Var):
        return {term.name}
    if isinstance(term, Call):
        return set().union(*(free_variables(arg) for arg in term.args))
    raise TypeError(f"Not a numerical term: {term!r}")


def substitute(term: Term, values: Mapping[str, Term]) -> Term:
    """Simultaneous substitution; inserted terms are not substituted again."""
    if isinstance(term, Zero):
        return term
    if isinstance(term, Var):
        return values.get(term.name, term)
    return Call(term.name, tuple(substitute(arg, values) for arg in term.args))


def show(term: Term) -> str:
    if isinstance(term, Zero):
        return "0"
    if isinstance(term, Var):
        return term.name
    return f"{term.name}({','.join(show(arg) for arg in term.args)})"


@dataclass(frozen=True)
class Recursion:
    name: str
    parameters: tuple[str, ...]
    recursion_slot: int
    index_variable: str
    result_variable: str
    base: Term
    step: Term

    @property
    def arity(self) -> int:
        return len(self.parameters) + 1


class Signature:
    """A well-founded, description-indexed numerical signature."""

    def __init__(self) -> None:
        self.arities: dict[str, int] = {"S": 1}
        self.definitions: dict[str, Recursion] = {}

    def validate(self, term: Term, context: Iterable[str]) -> None:
        allowed = set(context)
        if isinstance(term, Zero):
            return
        if isinstance(term, Var):
            if not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", term.name):
                raise ValueError(f"Invalid variable name: {term.name!r}")
            if term.name not in allowed:
                raise ValueError(f"Undeclared free variable: {term.name}")
            return
        if not isinstance(term, Call):
            raise TypeError("The syntax contains a non-term.")
        if term.name not in self.arities:
            raise ValueError(f"Unknown or forward-referenced function: {term.name}")
        if len(term.args) != self.arities[term.name]:
            raise ValueError(f"Wrong arity for {term.name}")
        for arg in term.args:
            self.validate(arg, allowed)

    def declare(self, definition: Recursion) -> None:
        if not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", definition.name):
            raise ValueError("Invalid function name.")
        if definition.name in self.arities:
            raise ValueError("A recursion declaration must introduce a fresh symbol.")
        names = definition.parameters + (
            definition.index_variable, definition.result_variable
        )
        if any(not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", name) for name in names):
            raise ValueError("All displayed context names must be identifiers.")
        if len(names) != len(set(names)):
            raise ValueError("The parameter, index, and recursive-result names differ.")
        if not 0 <= definition.recursion_slot < definition.arity:
            raise ValueError("Recursion slot is outside the declared arity.")
        # The new symbol is deliberately absent while its bodies are checked.
        self.validate(definition.base, definition.parameters)
        self.validate(definition.step, names)
        self.arities[definition.name] = definition.arity
        self.definitions[definition.name] = definition

    def evaluate(self, term: Term, environment: Mapping[str, int]) -> int:
        if isinstance(term, Zero):
            return 0
        if isinstance(term, Var):
            result = environment[term.name]
            if type(result) is not int or result < 0:
                raise ValueError("Numerical variables take nonnegative integer values.")
            return result
        return self.evaluate_call(
            term.name, tuple(self.evaluate(arg, environment) for arg in term.args)
        )

    @lru_cache(maxsize=None)
    def evaluate_call(self, name: str, arguments: tuple[int, ...]) -> int:
        if name not in self.arities or len(arguments) != self.arities[name]:
            raise ValueError("Unknown function or wrong evaluation arity.")
        if any(type(value) is not int or value < 0 for value in arguments):
            raise ValueError("Function arguments must be natural numbers.")
        if name == "S":
            return arguments[0] + 1
        definition = self.definitions[name]
        count = arguments[definition.recursion_slot]
        parameter_values = (
            arguments[:definition.recursion_slot]
            + arguments[definition.recursion_slot + 1:]
        )
        environment = dict(zip(definition.parameters, parameter_values))
        result = self.evaluate(definition.base, environment)
        for index in range(count):
            environment[definition.index_variable] = index
            environment[definition.result_variable] = result
            result = self.evaluate(definition.step, environment)
        return result

    def normalize(self, term: Term) -> Term:
        """Use only the displayed recursion equations on constructor inputs.

        A variable remains symbolic.  This is not a complete equational
        decision procedure and applies no arithmetic induction principle.
        """
        if isinstance(term, (Zero, Var)):
            return term
        arguments = tuple(self.normalize(arg) for arg in term.args)
        rebuilt = Call(term.name, arguments)
        if term.name == "S":
            return rebuilt
        definition = self.definitions[term.name]
        head = arguments[definition.recursion_slot]
        parameters = (
            arguments[:definition.recursion_slot]
            + arguments[definition.recursion_slot + 1:]
        )
        replacements = dict(zip(definition.parameters, parameters))
        if isinstance(head, Zero):
            return self.normalize(substitute(definition.base, replacements))
        if isinstance(head, Call) and head.name == "S":
            predecessor = head.args[0]
            recursive_arguments = list(arguments)
            recursive_arguments[definition.recursion_slot] = predecessor
            replacements[definition.index_variable] = predecessor
            replacements[definition.result_variable] = Call(
                term.name, tuple(recursive_arguments)
            )
            return self.normalize(substitute(definition.step, replacements))
        return rebuilt


def standard_signature() -> Signature:
    signature = Signature()
    signature.declare(Recursion(
        "p", (), 0, "n", "r", ZERO, Var("n")
    ))
    signature.declare(Recursion(
        "monus", ("x",), 1, "n", "r", Var("x"), call("p", Var("r"))
    ))
    signature.declare(Recursion(
        "c", ("u", "v"), 0, "n", "r", Var("u"), Var("v")
    ))
    return signature


def epsilon(left: Term, right: Term) -> Term:
    """The two-recursion equality indicator, expanded as an ordinary term."""
    return call(
        "monus",
        call("monus", ONE, call("monus", left, right)),
        call("monus", right, left),
    )


def zero_test(term: Term) -> Term:
    return epsilon(term, ZERO)


@dataclass(frozen=True)
class Formula:
    kind: str
    args: tuple[Formula | Term, ...] = ()


def eq(left: Term, right: Term) -> Formula:
    return Formula("eq", (left, right))


def connective(kind: str, *args: Formula) -> Formula:
    return Formula(kind, tuple(args))


def validate_formula(signature: Signature, formula: Formula,
                     context: Iterable[str]) -> None:
    if not isinstance(formula, Formula):
        raise TypeError("A formula node was expected.")
    arities = {"top": 0, "bottom": 0, "eq": 2,
               "not": 1, "and": 2, "or": 2, "imp": 2}
    if formula.kind not in arities or len(formula.args) != arities[formula.kind]:
        raise ValueError("Unknown connective or wrong connective arity.")
    if formula.kind == "eq":
        for arg in formula.args:
            signature.validate(arg, context)  # type: ignore[arg-type]
    else:
        for arg in formula.args:
            validate_formula(signature, arg, context)  # type: ignore[arg-type]


def formula_variables(formula: Formula) -> set[str]:
    if formula.kind == "eq":
        return set().union(*(free_variables(arg) for arg in formula.args))  # type: ignore[arg-type]
    return set().union(*(formula_variables(arg) for arg in formula.args))  # type: ignore[arg-type]


def show_formula(formula: Formula) -> str:
    if formula.kind == "eq":
        return f"({show(formula.args[0])}={show(formula.args[1])})"  # type: ignore[arg-type]
    if formula.kind in {"top", "bottom"}:
        return formula.kind
    return f"{formula.kind}({','.join(show_formula(arg) for arg in formula.args)})"  # type: ignore[arg-type]


def compile_formula(formula: Formula) -> Term:
    """Compile a quantifier-free formula to a term: 0=true, 1=false.

    Correctness in the theory requires the manuscript's arithmetic bridge;
    it is not being asserted merely from the recurrence equations.
    """
    if formula.kind == "top":
        return ZERO
    if formula.kind == "bottom":
        return ONE
    if formula.kind == "eq":
        return zero_test(epsilon(formula.args[0], formula.args[1]))  # type: ignore[arg-type]
    left = compile_formula(formula.args[0])  # type: ignore[arg-type]
    if formula.kind == "not":
        return zero_test(left)
    right = compile_formula(formula.args[1])  # type: ignore[arg-type]
    if formula.kind == "and":
        return call("c", left, right, ONE)
    if formula.kind == "or":
        return call("c", left, ZERO, right)
    if formula.kind == "imp":
        return call("c", left, right, ZERO)
    raise ValueError(f"Unknown formula constructor: {formula.kind}")


def evaluate_formula(signature: Signature, formula: Formula,
                     environment: Mapping[str, int]) -> bool:
    """Standard-model Boolean semantics, separate from the term compiler."""
    if formula.kind == "top":
        return True
    if formula.kind == "bottom":
        return False
    if formula.kind == "eq":
        return signature.evaluate(formula.args[0], environment) == signature.evaluate(formula.args[1], environment)  # type: ignore[arg-type]
    left = evaluate_formula(signature, formula.args[0], environment)  # type: ignore[arg-type]
    if formula.kind == "not":
        return not left
    right = evaluate_formula(signature, formula.args[1], environment)  # type: ignore[arg-type]
    if formula.kind == "and":
        return left and right
    if formula.kind == "or":
        return left or right
    if formula.kind == "imp":
        return (not left) or right
    raise ValueError("Unknown formula constructor.")


def must_reject(action, label: str) -> dict[str, str]:
    try:
        action()
    except (ValueError, TypeError) as error:
        return {"case": label, "result": "rejected", "reason": str(error)}
    raise AssertionError(f"Invalid syntax accepted: {label}")


def syntax_checks(signature: Signature) -> list[dict[str, str]]:
    x, n, r = Var("x"), Var("n"), Var("r")
    checks = [
        must_reject(lambda: signature.validate(call("p", x, ZERO), {"x"}),
                    "wrong numerical arity"),
        must_reject(lambda: signature.validate(Var("outside"), {"x"}),
                    "undeclared free variable"),
        must_reject(lambda: signature.validate(call("future", x), {"x"}),
                    "forward function reference"),
        must_reject(lambda: signature.declare(Recursion(
            "bad_base", (), 0, "n", "r", r, n)),
            "recursive-result variable occurs in the base"),
        must_reject(lambda: signature.declare(Recursion(
            "bad_self", (), 0, "n", "r", ZERO, call("bad_self", n))),
            "self-reference outside the recursive-result placeholder"),
        must_reject(lambda: signature.declare(Recursion(
            "bad_context", ("x",), 0, "n", "r", x, Var("y"))),
            "unlisted step parameter"),
        must_reject(lambda: signature.declare(Recursion(
            "bad_names", ("n",), 0, "n", "r", n, r)),
            "index variable reused as a parameter"),
        must_reject(lambda: signature.declare(Recursion(
            "bad_identifier", ("unused-name",), 0, "n", "r", ZERO, r)),
            "invalid unused parameter identifier"),
        must_reject(lambda: signature.declare(Recursion(
            "bad_slot", (), 1, "n", "r", ZERO, r)),
            "recursion slot out of bounds"),
        must_reject(lambda: signature.declare(Recursion(
            "p", (), 0, "n", "r", ZERO, n)),
            "nonfresh declared symbol"),
        must_reject(lambda: validate_formula(
            signature, Formula("imp", (Formula("top"),)), {"x"}),
            "wrong logical arity"),
        must_reject(lambda: validate_formula(
            signature, Formula("forall", (Formula("top"),)), {"x"}),
            "quantifier outside the quantifier-free grammar"),
    ]
    original = call("monus", Var("x"), Var("y"))
    swapped = substitute(original, {"x": Var("y"), "y": Var("x")})
    assert show(swapped) == "monus(y,x)", "Substitution must be simultaneous."
    checks.append({"case": "simultaneous variable substitution", "result": "passed",
                   "reason": "monus(x,y) becomes monus(y,x)"})
    return checks


def arithmetic_checks(signature: Signature) -> dict:
    counters = {"predecessor": 0, "monus": 0, "conditional": 0,
                "epsilon": 0, "zero_test": 0, "atomic_code": 0}
    for value in range(49):
        assert signature.evaluate_call("p", (value,)) == max(value - 1, 0)
        counters["predecessor"] += 1
        assert signature.evaluate(zero_test(Var("x")), {"x": value}) == int(value == 0)
        counters["zero_test"] += 1
    for x, y in product(range(25), repeat=2):
        environment = {"x": x, "y": y}
        assert signature.evaluate_call("monus", (x, y)) == max(x - y, 0)
        counters["monus"] += 1
        bit = signature.evaluate(epsilon(Var("x"), Var("y")), environment)
        assert bit == int(x == y)
        counters["epsilon"] += 1
        code = signature.evaluate(compile_formula(eq(Var("x"), Var("y"))), environment)
        assert code == int(x != y)
        counters["atomic_code"] += 1
    for n, u, v in product(range(9), repeat=3):
        assert signature.evaluate_call("c", (n, u, v)) == (u if n == 0 else v)
        counters["conditional"] += 1
    ground = signature.normalize(epsilon(ZERO, ZERO))
    assert ground == ONE
    return {"kind": "finite standard-model evaluation",
            "ranges": {"p_and_Z": "0..48", "monus_and_epsilon": "0..24 squared",
                       "conditional": "0..8 cubed"},
            "checked_instances": counters,
            "ground_symbolic_check": {"epsilon(0,0)": show(ground)}}


def gate_checks(signature: Signature) -> list[dict]:
    result = []
    for kind in ("not", "and", "or", "imp"):
        input_count = 1 if kind == "not" else 2
        for bits in product((0, 1), repeat=input_count):
            atoms = tuple(Formula("top" if bit == 0 else "bottom") for bit in bits)
            formula = connective(kind, *atoms)
            compiled = compile_formula(formula)
            normalized = signature.normalize(compiled)
            expected = int(not evaluate_formula(signature, formula, {}))
            assert normalized == numeral(expected)
            result.append({"gate": kind, "truth_zero_inputs": list(bits),
                           "symbolic_normal_form": show(normalized),
                           "expected_truth_zero_output": expected})
    return result


def formula_checks(signature: Signature) -> dict:
    x, y, z = (Var(name) for name in ("x", "y", "z"))
    formulas = [
        Formula("top"), Formula("bottom"), eq(x, y),
        eq(call("p", succ(x)), x),
        connective("imp", eq(x, ZERO), eq(call("monus", x, y), ZERO)),
        connective("or", eq(x, y), connective("not", eq(x, y))),
        connective("imp", connective("and", eq(x, y), eq(y, z)), eq(x, z)),
        eq(call("monus", succ(x), succ(y)), call("monus", x, y)),
        connective("and", connective("not", eq(x, ZERO)),
                   eq(call("c", x, y, z), z)),
    ]
    generator = random.Random(20261031)
    simple_terms: tuple[Term, ...] = (
        ZERO, ONE, x, y, z, succ(x), call("p", y),
        call("monus", x, y), call("c", z, x, y),
    )

    def generated_formula(depth: int) -> Formula:
        if depth == 0 or generator.randrange(4) == 0:
            return eq(generator.choice(simple_terms), generator.choice(simple_terms))
        kind = generator.choice(("not", "and", "or", "imp"))
        args = [generated_formula(depth - 1)]
        if kind != "not":
            args.append(generated_formula(depth - 1))
        return connective(kind, *args)

    formulas.extend(generated_formula(3) for _ in range(120))
    checks = 0
    examples = []
    for index, formula in enumerate(formulas):
        validate_formula(signature, formula, {"x", "y", "z"})
        compiled = compile_formula(formula)
        signature.validate(compiled, {"x", "y", "z"})
        assert free_variables(compiled) == formula_variables(formula)
        for assignment in product(range(5), repeat=3):
            environment = dict(zip(("x", "y", "z"), assignment))
            expected = int(not evaluate_formula(signature, formula, environment))
            actual = signature.evaluate(compiled, environment)
            assert actual in (0, 1)
            assert actual == expected, (show_formula(formula), environment, actual)
            checks += 1
        if index < 9:
            examples.append({"formula": show_formula(formula),
                             "compiled_term": show(compiled),
                             "free_variables": sorted(free_variables(compiled))})
    return {"kind": "finite standard-model compiler evaluation",
            "deterministic_seed": 20261031, "formula_count": len(formulas),
            "assignments_per_formula": 125, "checked_formula_assignments": checks,
            "all_compiled_outputs_boolean": True,
            "free_variables_preserved": True, "examples": examples}


def latch_checks(signature: Signature) -> dict:
    q = Var("q")
    cases = []
    for current, following in product((0, 1), repeat=2):
        previous = call("c", numeral(current), q, ZERO)
        next_value = call("c", numeral(following), previous, ZERO)
        left = signature.normalize(previous)
        right = signature.normalize(next_value)
        allowed = not (current == 0 and following == 1)
        if allowed:
            assert left == right
        else:
            assert left != right
        cases.append({"b_n": current, "b_Sn": following,
                      "allowed_by_zero_inductiveness": allowed,
                      "P_Sn_normal_form": show(left),
                      "P_SSn_normal_form": show(right),
                      "same_syntactic_term": left == right})
    base = signature.normalize(call("c", ZERO, ONE, ZERO))
    false_branch = signature.normalize(call("c", ONE, q, ZERO))
    assert base == ONE and false_branch == ZERO
    return {"kind": "symbolic rewriting by defining equations only",
            "arbitrary_state_variable": "q",
            "q_has_no_numeric_assignment": True,
            "recursion": "P(0)=1; P(S(n))=c(b(n),P(n),0)",
            "shifted_term": "L(n)=P(S(n))",
            "admissible_transition_cases": cases,
            "base_normal_form": show(base),
            "false_branch_normal_form": show(false_branch),
            "claim_checked": "P(S(S(n)))=P(S(n)) for the three admissible Boolean transitions",
            "claim_not_checked": "The first-order constancy schema and its proof transformation"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write-report", type=Path)
    arguments = parser.parse_args()
    signature = standard_signature()
    declarations = []
    for definition in signature.definitions.values():
        declarations.append({
            "name": definition.name,
            "arity": definition.arity,
            "recursion_slot_zero_based": definition.recursion_slot,
            "parameters": list(definition.parameters),
            "index_variable": definition.index_variable,
            "result_variable": definition.result_variable,
            "base_term": show(definition.base),
            "step_term": show(definition.step),
        })
    report = {
        "artifact": "PRA constancy refinement: compiler and symbolic latch companion",
        "status": "passed",
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "source_trace": {
            "primitive_recursion_descriptions": declarations,
            "defining_equations": [
                "p(0)=0", "p(S(n))=n", "monus(x,0)=x",
                "monus(x,S(n))=p(monus(x,n))",
                "c(0,u,v)=u", "c(S(n),u,v)=v",
            ],
            "epsilon_term": show(epsilon(Var("x"), Var("y"))),
            "epsilon_intended_value": "1 if x=y; 0 otherwise",
            "Z_term": show(zero_test(Var("x"))),
            "truth_zero_atom_term": show(compile_formula(eq(Var("x"), Var("y")))),
            "manuscript_dependency": "Equality bridge plus constancy; complete mathematical proofs are in the accompanying manuscript.",
        },
        "syntax_validation": syntax_checks(signature),
        "arithmetic": arithmetic_checks(signature),
        "boolean_gate_table": gate_checks(signature),
        "formula_compiler": formula_checks(signature),
        "latch": latch_checks(signature),
        "limits": [
            "Finite evaluations concern the standard natural numbers only.",
            "The Boolean gate and latch identities are symbolic definitional reductions, with q left arbitrary.",
            "No first-order proof calculus, induction schema, or model-theoretic equivalence is machine-checked here.",
            "The equivalence of the proposed kernels with PRA/iPRA rests on the manuscript's proofs.",
            "No dependency on an unspecified equality oracle occurs in the evaluated term grammar.",
        ],
    }
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if arguments.write_report:
        arguments.write_report.write_text(encoded, encoding="utf-8")
    summary = {
        "status": report["status"],
        "syntax_checks": len(report["syntax_validation"]),
        "formula_assignments": report["formula_compiler"]["checked_formula_assignments"],
        "symbolic_gate_cases": len(report["boolean_gate_table"]),
        "symbolic_latch_cases": len(report["latch"]["admissible_transition_cases"]),
        "report": str(arguments.write_report) if arguments.write_report else None,
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
