EXECUTABLE COMPANION: PRA CONSTANCY REFINEMENT
===========================================

Files
-----
pra_compiler.py     Self-contained Python 3.10+ program using only the standard library.
verification.json  Report produced by running that program, including its SHA-256.

Run from this directory:

  python3 pra_compiler.py --write-report verification.json

What is checked
---------------
1. A numerical term syntax with 0, S, variables, and fresh primitive-recursion
   declarations. Arity, displayed free variables, recursion position, freshness,
   and the prohibition on forward/self references are explicitly validated.

2. The declared programs for predecessor p, truncated subtraction monus, and
   the numerical conditional c. Their finite evaluations are compared with an
   independent standard-number specification.

3. The explicit comparator

     epsilon(x,y) = (1 monus (x monus y)) monus (y monus x)

   and the truth-zero atomic code Z(epsilon(x,y)), where Z(t)=epsilon(t,0).
   No unspecified equality-test function is invoked by the term evaluator.

4. A quantifier-free formula compiler. The target code is 0 for truth and 1
   for falsehood. All Boolean gate rows are checked by symbolic normalization.
   Structured examples and deterministically generated formulas are evaluated
   over a finite grid, with free-variable preservation checked separately.

5. The latch lemma using

     P(0)=1,  P(S(n))=c(b(n),P(n),0),  L(n)=P(S(n)).

   The state q=P(n) remains a syntactic variable. For the admissible bit pairs
   (b(n),b(S(n)))=(0,0),(1,0),(1,1), the two sides P(S(S(n))) and P(S(n))
   normalize to exactly the same term. The excluded pair (0,1) does not.
   This makes the role of the induction premise visible without restricting
   the possible numerical values of the latch state.

Limits
------
Finite evaluation is not a proof about all natural numbers or nonstandard
models. The program does not implement a first-order proof checker, verify
the constancy schema, or formally certify the equivalence with PRA/iPRA.
The mathematical proofs in the manuscript supply those claims. The symbolic
latch and gate checks certify only the displayed definitional reductions.

The verification report includes the literal recursion descriptions and
expanded terms used by the program so that the correspondence with the
manuscript can be inspected directly.
