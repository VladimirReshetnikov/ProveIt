A SMALLER CONSTANCY PRESENTATION OF PRIMITIVE RECURSIVE ARITHMETIC
==============================================================
Prepared for Vladimir Reshetnikov, 31 October 2026.

Start with pra_constancy_refinement.pdf. The exact axiom specification is
also available independently in axioms.txt.

MAIN RESULT
-----------
The fixed equality indicator can be written using only predecessor and
truncated subtraction:

  epsilon(x,y) = (1 monus (x monus y)) monus (y monus x).

Together with all primitive-recursion defining equations, use the schema
that a term unchanged by successor is constant. The remaining fixed axiom is:

  Classical:      epsilon(x,y)=0 iff x!=y.
  Intuitionistic: x=y XOR epsilon(x,y)=0.

The positive intuitionistic version also works classically. Both systems are
proved exactly equivalent, in the SAME first-order language and chosen logic,
to ordinary PRA with quantifier-free induction.

WHAT IS IMPROVED
----------------
This reduces the explicit comparison program in current constancy proposals
from six or five recursion dependencies to two. The signed-number proposal
has five comparator dependencies plus two additional proof helpers; those
proof-only helpers are not counted as part of its fixed comparison program.
The constancy schema and shifted-accumulator proof method are already in the
reviewed drafts. No historical novelty is claimed for the subtraction formula.

The strongest guarded-equation presentation remains competitive: it needs
no comparator in its fixed axioms. This note does NOT claim a smaller number
of axiom templates, global minimality, or dominance over every existing draft.

ADDITIONAL RESULTS
------------------
Two explicit countermodel constructions rule out a natural further reduction:
* Guarded induction only for t=0 fails to give predecessor coverage.
* Even predecessor coverage together with induction for every zero-test
  formula (including quantified ones) can fail induction for j(n)=n.
  The latter model satisfies every true first-order zero-test sentence.

The paper includes complete equivalence proofs, a constructive proof of
comparison by truncated subtraction, the classical/intuitionistic distinction,
an archive-by-archive audit, and a Further research questions section.

SOURCE SNAPSHOT
---------------
Repository: VladimirReshetnikov/ProveIt
Commit: a0dd253b72f0ebfd368f674fcf722e0671d4a6ef
Directory: docs/drafts
All six archives were retrieved; Git blob hashes were checked.
See source_audit.json for exact filenames, immutable URLs, and SHA-256 hashes.
Original source archives are not duplicated here.

FILES
-----
pra_constancy_refinement.pdf       Complete research note.
pra_constancy_refinement.tex       Main LaTeX source.
sections/monus_comparison.tex      Complete constructive comparator proof.
sections/zero_obstructions.tex     The two countermodels and reflection lemma.
axioms.txt                        Standalone exact specification.
artifacts/pra_compiler.py          Executable syntax/compiler/latch companion.
artifacts/verification.json        Recorded diagnostic results and source hash.
artifacts/README.txt               Companion scope and instructions.
source_audit.json                  Immutable source provenance and comparison.
VALIDATION.txt                    Build, review, and verification record.
Makefile                          PDF and companion commands.
build.sh                          Direct PDF build without make.
SHA256SUMS                        Hashes of all other deliverable files.

REBUILD
-------
Requirements: a conventional LaTeX installation with pdflatex, amsmath,
amssymb, amsthm, mathtools, lmodern, microtype, geometry, booktabs, array,
longtable, enumitem, xcolor, titlesec, fancyhdr, tcolorbox, and hyperref.
The Python companion requires Python 3.10+ and no third-party packages.

From this directory:
  sh build.sh
or:
  make pdf

To rerun diagnostics:
  make check
or:
  python3 artifacts/pra_compiler.py --write-report artifacts/verification.json

Rebuilding or regenerating a report may change byte hashes. SHA256SUMS records
the exact delivered versions. The PDFs need not be byte-identical across TeX
versions even when their mathematical content is identical.

VERIFICATION LIMITS
-------------------
The text contains complete mathematical proofs. The companion validates
syntax, performs symbolic gate/latch reductions, and checks finite numerical
examples. It is NOT a first-order proof checker or a Lean/Rocq formalization,
and finite computations do not establish the universal equivalence theorem.
