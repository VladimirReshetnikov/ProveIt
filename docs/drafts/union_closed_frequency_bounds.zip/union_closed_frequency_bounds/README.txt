Frequency bounds for union-closed families
25 November 2026

Read union_closed.pdf for the proofs. The LaTeX entry point is
union_closed.tex. All included sections must be kept beside it.

The general entropy theorem guarantees an element in strictly more than
39% of the members of every nontrivial union-closed family of size at
most one billion. The two-triple theorem answers an open question in the
ProveIt drafts. Its minimum family sizes, for two triples sharing one
point with all five marked points below half, are 117 and 164 (empty set
present, odd and even sizes) and 163 and 210 (empty set absent).
The full half-frequency conjecture remains open.

Other sections cover a marked four-element member, locally abundant
vertices of tournaments, and the exact least possible larger endpoint
frequency at a prescribed edge of a bounded-degree tree. The bibliography
identifies the relevant repository snapshot and the external results used.
The final section discusses scope and open questions.

Reproduce the computations with Python 3.10 or later, a C++17 compiler,
a POSIX shell, and make, using

    make check

The Python programs use only the standard library. Leave Python assertions
enabled. The C++ checker enumerates all 808154 nonempty eligible five-point
fibers. The independent Python checker certifies the main local weight
inequalities from negative-weight hulls. The C++ census additionally
certifies the small score types used in the corollary at the thresholds.
All threshold tests in the main entropy theorem use rational enclosures.
The four-ground-point entropy audit uses floating-point comparisons.
verification.txt records a full run.

examples/example_117.txt lists the 117 members using labels 0 through 10.
checks/verify_overlap_examples.py constructs all four minimizers. In the
generated integer encoding, union is bitwise OR and bit i represents point i.

Build the PDF with a standard TeX Live installation and latexmk using

    make pdf

Alternatively run pdflatex union_closed.tex three times. The tree drawing
is produced in TeX. No network access or bibliography processor is needed.
