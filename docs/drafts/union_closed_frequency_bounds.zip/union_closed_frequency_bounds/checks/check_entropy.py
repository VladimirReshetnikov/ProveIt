"""Rational certificates and an independent small-ground-set entropy audit."""
from fractions import Fraction as F
from math import log
from itertools import combinations_with_replacement

# Decimal endpoints for (3-sqrt(5))/2. Squaring verifies the strict bracket.
G_LO = F("0.381966011250")
G_HI = F("0.381966011251")
TAU_LO = 1 - G_HI
assert (3 - 2 * G_HI) ** 2 < 5 < (3 - 2 * G_LO) ** 2


def near_log(x):
    """Enclose log(x) for 1 <= x <= 2 via twice the atanh series."""
    assert 1 <= x <= 2
    z = (x - 1) / (x + 1)
    n = 24
    lo = 2 * sum(z ** (2 * j + 1) / (2 * j + 1) for j in range(n))
    hi = lo + 2 * z ** (2 * n + 1) / ((2 * n + 1) * (1 - z * z))
    return lo, hi


def log_bounds(x):
    x = F(x)
    assert x >= 1
    power = 0
    while x > 2:
        x /= 2
        power += 1
    ll, lu = near_log(x)
    tl, tu = near_log(F(2))
    return ll + power * tl, lu + power * tu


def quartic(g, z):
    denominator = 1 - (1 + 2 * g - g * g) * z * z
    assert denominator > 0
    return 2 * g ** 4 * z ** 4 / denominator


def c_lower(q):
    lo, _ = log_bounds((1 + q) / (1 + q / 2))
    return 2 * q * q * lo + 2 * q ** 3 / (2 + q)


def certificates():
    points = [G_LO] + [F(k, 1000) for k in (384, 387, 391, 397, 405, 414, 420, 1000)]
    millis = (171, 172, 173, 174, 177, 181, 188, 177)
    for u, v, target in zip(points, points[1:], millis):
        lower = c_lower(u) / (u * (2-u)) + quartic(G_LO, 1-v) / (v * (2-v))
        assert lower > F(target, 1000)
    assert F(".17") + 4 * quartic(G_HI, F(1, 2)) < 1
    print("All eight scalar induction intervals and the base case certified.")

    def test(s, d_lower, error, max_n, target):
        gain = F(".17") * s ** 2 + quartic(G_LO, s) - error
        numerator = d_lower + gain
        assert numerator > 0
        lower = G_LO + TAU_LO * numerator / log_bounds(max_n)[1]
        assert lower > F(target)
        print(f"Certified lower bound > {target} for the stated test at N <= {max_n}.")

    ln2 = log_bounds(2)[0]
    assert G_LO + TAU_LO * F(8, 81) / log_bounds(9)[1] > F(".40")
    test(F(".61"), F(8, 81), F(1, 100), 10**4, ".3931")
    test(F(".61"), ln2 - F(1, 2) - F(3, 10000), F(1, 10**8), 10**9, ".39004")
    test(F(".595"), ln2 - F(1, 2) - F(3, 1000), F(1, 10**6), 1000, ".4054")


def audit():
    """Combinatorics exact. Entropy comparisons here use double precision."""
    tested = eligible = recursive_steps = 0
    gamma = (3 - 5 ** 0.5) / 2
    c = lambda q: 2*q*q*log((1+q)/(1+q/2)) + 2*q**3/(2+q)
    gridsize = 4
    cache = {}

    def ent_gap(family):
        n = len(family)
        counts = {v: 0 for v in family}
        for a, b in combinations_with_replacement(family, 2):
            if (a | b) not in counts:
                return None
            counts[a | b] += 1 if a == b else 2
        ref = range(1, 2*n, 2)
        return (sum(k*log(k) for k in counts.values()) - sum(k*log(k) for k in ref))/n**2

    for bits in range(1, 1 << (1 << gridsize)):
        members = tuple(i for i in range(1 << gridsize) if bits & (1 << i))
        if len(members) < 2:
            continue
        gap = ent_gap(members)
        if gap is None:
            continue
        cache[members] = gap
        tested += 1
        n = len(members)
        degrees = [sum((i >> v) & 1 for i in members) for v in range(gridsize)]
        s = (n - max(degrees)) / n
        assert gap + 1e-12 >= .17*s*s + quartic(gamma, s) - 1/n**2
        if n - max(degrees) < 2:
            continue
        eligible += 1
        assert gap + 1e-12 >= c(gamma)*s*s + quartic(gamma, s)
        for x, count in enumerate(degrees):
            if count != max(degrees):
                continue
            sub = tuple(i for i in members if not (i >> x) & 1)
            q = max(sum((i >> v) & 1 for i in sub) for v in range(gridsize))/len(sub)
            # Every proper subfamily is an earlier bit mask in this enumeration.
            assert gap + 1e-12 >= s*s*(c(q) + cache[sub]) + quartic(gamma, s)
            recursive_steps += 1
    print(f"Four-point audit: {tested} union-closed families with at least 2 members; "
          f"{eligible} meet the omission hypothesis; {recursive_steps} maximal-coordinate recursions.")


if __name__ == "__main__":
    certificates()
    audit()
