#!/usr/bin/env python3
"""Integer checks for the local endpoint surplus of edge-generated families."""
from fractions import Fraction
from itertools import combinations


def vertex_sets(n, edges):
    """Generate directly by testing the no-isolated-vertex condition."""
    masks = [sum(1 << v for v in edge) for edge in edges]
    members = set()
    for choice in range(1 << n):
        covered = 0
        for mask in masks:
            if choice & mask == mask:
                covered |= mask
        if covered == choice:
            members.add(choice)
    return members


def neighborhoods(n, edges):
    adj = [set() for _ in range(n)]
    for x, y in edges:
        adj[x].add(y)
        adj[y].add(x)
    return adj


def check_small_graphs():
    total_graphs = total_edges = 0
    for n in range(2, 6):
        possible = list(combinations(range(n), 2))
        for flags in range(1 << len(possible)):
            edges = [e for i, e in enumerate(possible) if flags & (1 << i)]
            adj = neighborhoods(n, edges)
            family = vertex_sets(n, edges)
            total_graphs += 1
            for x, y in edges:
                if len(adj[x]) == len(adj[y]) == 1:
                    continue
                total_edges += 1
                edge = (1 << x) | (1 << y)
                witnesses = {s for s in family if s & edge == edge and s ^ edge not in family}
                incidences = sum((s & edge).bit_count() for s in family)
                assert incidences - len(family) == len(witnesses)
                for z in (adj[x] | adj[y]) - {x, y}:
                    w_set = adj[z] - {x, y}
                    w_mask = sum(1 << w for w in w_set)
                    fiber_sizes = {}
                    for source in family:
                        image = edge | (1 << z)
                        for i, j in edges:
                            mask = (1 << i) | (1 << j)
                            if not w_mask & mask and source & mask == mask:
                                image |= mask
                        assert image in witnesses
                        fiber_sizes[image] = fiber_sizes.get(image, 0) + 1
                    bound = 8
                    for w in w_set:
                        bound *= 1 + 2 ** (len(adj[w]) - 1)
                    assert max(fiber_sizes.values()) <= bound
                    assert bound * len(witnesses) >= len(family)
    return total_graphs, total_edges


def symmetric_tree(delta):
    edges = [(0, 1)]
    last = 1
    for root in (0, 1):
        last += 1
        z = last
        edges.append((root, z))
        for _ in range(delta - 1):
            last += 1
            w = last
            edges.append((z, w))
            for _ in range(delta - 1):
                last += 1
                edges.append((w, last))
    return last + 1, edges


def check_examples():
    for delta in (2, 3):
        d = delta - 1
        n, edges = symmetric_tree(delta)
        family = vertex_sets(n, edges)
        counts = [sum(s & 3 == i for s in family) for i in range(4)]
        b = (1 + 2**d) ** d
        q = 2 ** (d * d) + b
        assert counts == [(q - 1)**2, b * (q - 1), b * (q - 1), q*q]
        print(f'Symmetric tree, maximum degree {delta}: {n} vertices, '
              f'trace counts 00,01,10,11 = {counts}, endpoint frequency '
              f'{Fraction(counts[1] + counts[3], len(family))}')


def product(a, b):
    return [[sum(x*y for x, y in zip(row, col)) for col in zip(*b)] for row in a]


def lincomb(terms):
    return [[sum(c * a[i][j] for c, a in terms) for j in range(len(terms[0][1][0]))]
            for i in range(len(terms[0][1]))]


def check_certificate():
    t = [[1, 1, 0], [0, 0, 1], [1, 0, 1]]
    e = [[0, 0, 0], [0, 1, 0], [0, 0, 1]]
    a, b = [[1, 0, 0]], [[1], [0], [1]]
    t2 = product(t, t)
    t2e, tet = product(t2, e), product(product(t, e), t)
    h = lincomb([(65, t2e), (65, tet), (-74, t2)])
    h_end = lincomb([(65, t2e), (-37, t2)])
    left, right = [a], [b]
    for _ in range(4):
        left.append(product(left[-1], t))
        right.append(product(t, right[-1]))
    lb = left[1:] + [lincomb([(1, left[4]), (-1, left[3])])]
    rb = right[1:] + [lincomb([(1, right[4]), (-1, right[3])])]
    internal = [[product(product(u, h), v)[0][0] for v in rb] for u in lb]
    terminal = [product(product(a, h_end), v)[0][0] for v in rb]
    assert internal == [[132, 152, 201, 382, 181], [152, 136, 122, 260, 138],
                        [201, 122, 0, 79, 79], [382, 260, 79, 280, 201],
                        [181, 138, 79, 201, 122]]
    assert terminal == [47, 66, 76, 133, 57]
    tn = t2
    cycle_values = []
    for _ in (3, 4, 5):
        tn = product(tn, t)
        cycle_values.append(65*(tn[1][1]+tn[2][2])-37*sum(tn[j][j] for j in range(3)))
    assert cycle_values == [10, 20, 21]
    print('Confirmed the internal and terminal matrix certificates and cycle seeds.')


if __name__ == '__main__':
    graph_count, edge_count = check_small_graphs()
    print(f'Checked {graph_count} labelled simple graphs on 2 to 5 vertices, '
          f'with {edge_count} eligible marked edges.')
    check_examples()
    check_certificate()
