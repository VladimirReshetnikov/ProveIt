#!/usr/bin/env python3
"""Construct and check all four extremizers. Python 3.10+, standard library."""
from itertools import combinations

FIRST, SECOND, TOP = 7, 25, 31
A = 0x820000C3
B = 0x83000083
C = 0x83838383
D = 0xFFD5D5D5
E = 0xAAD500D5
F = 0xAA00D5D5
SEED = (A, C, C, D, E, F)
BATCH = (A, A, B, B, D)


def traces(code):
    return {i for i in range(32) if (code >> i) & 1}


def build(batch_count, has_empty):
    labels = SEED + BATCH*batch_count
    universe = (1 << len(labels)) - 1
    family = {FIRST, SECOND, TOP}
    if has_empty:
        family.add(0)
    family.update((universe << 5) | trace for trace in range(32))
    for index, code in enumerate(labels):
        outside = universe ^ (1 << index)
        family.update((outside << 5) | trace for trace in traces(code))
    return family


if __name__ == "__main__":
    cases = ((0, True, 117, 58), (1, True, 164, 81),
             (1, False, 163, 81), (2, False, 210, 104))
    for q, has_empty, n, degree in cases:
        family = build(q, has_empty)
        assert len(family) == n
        assert all((x | y) in family for x, y in combinations(family, 2))
        assert {s for s in family if s.bit_count() == 3} == {FIRST, SECOND}
        assert (0 in family) == has_empty
        degrees = [sum(bool(s & (1 << i)) for s in family) for i in range(5)]
        assert degrees == [degree]*5 and 2*degree < n
        print(f"N={n}, empty={has_empty}, marked degrees={degrees}, every union present")
