#!/usr/bin/env python3
"""Check the sharp tree theorem by nonisomorphic tree enumeration and rooted DP."""
from fractions import Fraction
from math import prod
from check_edges import neighborhoods, symmetric_tree, vertex_sets


def canonical_tree(adj):
    """Canonical form from the lexicographically smallest rooted encoding."""
    def encoding(root, parent):
        codes = sorted(encoding(v, root) for v in adj[root] if v != parent)
        return '(' + ''.join(codes) + ')'
    return min(encoding(v, None) for v in range(len(adj)))


def trees_through(limit):
    # Every tree of the next order can be obtained by adding a pendant vertex.
    level = {(): [set()]}
    for order in range(1, limit + 1):
        yield order, list(level.values())
        if order == limit:
            break
        new_level = {}
        for adj in level.values():
            for parent in range(order):
                edited = [neighbors.copy() for neighbors in adj] + [{parent}]
                edited[parent].add(order)
                new_level.setdefault(canonical_tree(edited), edited)
        level = new_level


def local_counts(adj, x, y):
    def branch(v, parent):
        children = [branch(i, v) for i in adj[v] if i != parent]
        absent = prod(a + c - h for a, c, h in children)
        present = prod(a + c for a, c, h in children)
        needs_parent = prod(a for a, _, _ in children)
        return absent, present, needs_parent

    ax, cx, hx = branch(x, y)
    ay, cy, hy = branch(y, x)
    return (ax*ay, (cx-hx)*ay, ax*(cy-hy), cx*cy)


def extremal_excess(delta):
    d = delta - 1
    b = (1 + 2 ** d) ** d
    q = 2 ** (d * d) + b
    total = q * q + (q - 1) ** 2 + 2*b*(q - 1)
    return Fraction(2*q - 1, 2*total)


def check_small_trees():
    known_counts = (1, 1, 1, 2, 3, 6, 11, 23, 47, 106, 235, 551)
    trees, marks = 0, 0
    ties = []
    for n, level in trees_through(12):
        assert len(level) == known_counts[n - 1]
        if n < 3:
            continue
        for adj in level:
            trees += 1
            delta = max(map(len, adj))
            edges = [(x, y) for x in range(n) for y in adj[x] if x < y]
            family = vertex_sets(n, edges) if n <= 9 else None
            threshold = extremal_excess(delta)
            for x, y in edges:
                marks += 1
                counts = local_counts(adj, x, y)
                if family is not None:
                    expected = [0]*4
                    for s in family:
                        expected[((s >> x) & 1) + 2*((s >> y) & 1)] += 1
                    assert counts == tuple(expected)
                maximum = counts[3] + max(counts[1], counts[2])
                excess = Fraction(maximum, sum(counts)) - Fraction(1, 2)
                assert excess >= threshold
                if excess == threshold:
                    ties.append((n, delta))
    assert ties == [(8, 2)]
    print(f'Checked all {trees} unlabelled trees on 3 to 12 vertices and '
          f'all {marks} choices of marked edge. Sole equality: the central edge of P8.')


if __name__ == '__main__':
    check_small_trees()
    for delta in range(2, 16):
        n, edges = symmetric_tree(delta)
        counts = local_counts(neighborhoods(n, edges), 0, 1)
        excess = Fraction(counts[1] + counts[3], sum(counts)) - Fraction(1, 2)
        assert excess == extremal_excess(delta)
    print('Rooted DP recovered the exact extremal value on every constructed tree '
          'for maximum degrees 2 through 15.')
