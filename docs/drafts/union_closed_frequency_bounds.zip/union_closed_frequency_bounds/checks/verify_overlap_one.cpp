// Exhaustive integer certificates for two triples meeting at one point.
// Build with c++ -O2 -std=c++17 verify_overlap_one.cpp -o verify_overlap_one
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <set>

using Bits = std::uint32_t;
using Weights = std::array<int, 5>;

constexpr int first = 7, second = 25, top = 31;
constexpr Weights core_weights{39,32,32,32,32};
constexpr Weights petal_weights{311,115,211,163,163};

Bits bit(int mask) { return Bits{1} << mask; }
int size_of_mask(int x) {
    int count = 0;
    while (x) { x &= x - 1; ++count; }
    return count;
}
void require(bool condition) {
    if (!condition) { std::cerr << "Certificate failed\n"; std::exit(1); }
}

struct Fiber {
    Bits masks = 0;
    int size = 0;
    int score = 0;
    Weights imbalance{};
};
struct Statistics {
    int total = 0, missing_core = 0, missing_petal = 0;
    int core_min = std::numeric_limits<int>::max();
    int petal_min = std::numeric_limits<int>::max();
    std::set<int> small_scores;
    int high=0, low=0, score_five=0;
} stats;

int dot(const Weights& a, const Weights& b) {
    int sum = 0;
    for (int i = 0; i < 5; ++i) sum += a[i] * b[i];
    return sum;
}

void examine(const Fiber& h) {
    if (h.size == 0) return;
    ++stats.total;
    require((h.masks & bit(top)) != 0 && h.score >= 0);
    if (h.score <= 13) stats.small_scores.insert(h.score);
    if (h.score == 0 || h.score == 5) {
        require((h.masks & bit(0)) != 0);
        if (h.score == 5) {
            require(h.size == 14 && h.imbalance[0] == -2);
            ++stats.score_five;
        } else if (h.masks & bit(1)) {
            require(3*h.imbalance[0] == h.size);
            ++stats.high;
        } else {
            require(h.size == 23 && h.imbalance[0] == -9);
            for (int i=1; i<5; ++i) require((h.masks & bit(1<<i)) != 0);
            ++stats.low;
        }
    }
    if (!(h.masks & bit(0)) || !(h.masks & bit(1))) {
        ++stats.missing_core;
        stats.core_min = std::min(stats.core_min, dot(core_weights,h.imbalance)+h.size);
    }
    if (!(h.masks & bit(0)) || !(h.masks & bit(2))) {
        ++stats.missing_petal;
        stats.petal_min = std::min(stats.petal_min, dot(petal_weights,h.imbalance)+5*h.size);
    }
}

// Decide inclusion of trace j after all numerically larger traces.
// All strict unions of j with prior traces or with a prescribed triple
// have larger masks, so an invalid inclusion can be pruned immediately.
void enumerate(int j, const Fiber& h) {
    if (j < 0) { examine(h); return; }
    enumerate(j-1, h);
    const Bits next_masks = h.masks | bit(j);
    if (!(next_masks & bit(j | first)) || !(next_masks & bit(j | second))) return;
    for (int k = j + 1; k <= top; ++k)
        if ((h.masks & bit(k)) && !(next_masks & bit(j | k))) return;
    Fiber next = h;
    next.masks = next_masks;
    ++next.size;
    next.score += 41 * (j & 1) + 25 * size_of_mask(j & 30) - 69;
    for (int i=0; i<5; ++i) next.imbalance[i] += 2*((j >> i) & 1)-1;
    enumerate(j-1, next);
}

int main() {
    enumerate(31, Fiber{});
    require(stats.total == 808154 && stats.small_scores == std::set<int>{0,5,6,9,12});
    require(stats.core_min == 0 && stats.petal_min == 0);
    require(stats.high == 8 && stats.low == 1 && stats.score_five == 4);
    std::cout << "Nonempty admissible fibers: " << stats.total << "\n"
              << "Scores through 13: {0,5,6,9,12}; all scores nonnegative\n"
              << "Zero score: 8 high-core and 1 low-core fiber; score 5: 4 fibers\n"
              << "Unswitchable core: " << stats.missing_core
              << " fibers; minimum certificate slack " << stats.core_min << "\n"
              << "Unswitchable first petal: " << stats.missing_petal
              << " fibers; minimum certificate slack " << stats.petal_min << "\n";
}
