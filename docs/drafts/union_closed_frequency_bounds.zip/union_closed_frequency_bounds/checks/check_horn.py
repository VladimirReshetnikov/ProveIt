#!/usr/bin/env python3
"""Independent exact checks of the rule identity, matching bound, and tournament theorem."""
from itertools import combinations


def bits(mask):
    while mask:
        bit = mask & -mask
        yield bit
        mask ^= bit


def table(weights):
    return [sum(weights[i] for i in range(len(weights)) if mask & (1 << i))
            for mask in range(1 << len(weights))]


def check_rules(rules, weight):
    universe = len(weight) - 1
    cell_size = [0] * len(rules)
    expected = actual = 0
    for subset in range(universe + 1):
        bad = [i for i, (head, body) in enumerate(rules)
               if subset & head and not subset & body]
        if not bad:
            actual += 2 * weight[subset] - weight[universe]
            continue
        cell_size[bad[0]] += 1
        common_head = common_body = universe
        for i in bad:
            head, body = rules[i]
            common_head &= head
            common_body &= body
        expected += weight[common_body] - weight[common_head]
    assert actual == expected

    lower = 0
    for i, (head, body) in enumerate(rules):
        free = universe ^ (head | body)
        # Enumerate matchable right-vertex subsets by processing the left vertices.
        masks = {0}
        for other_head, other_body in rules[:i]:
            if body & other_head or other_body & head:
                continue
            masks |= {used | bit for used in masks
                      for bit in bits(other_body & free & ~used)}
        maximum = max(weight[mask] for mask in masks)
        lower += cell_size[i] * (weight[body] - weight[head] - maximum)
    assert actual >= lower


def test_rule_systems():
    universe = 7
    possible = [(head, body) for head in bits(universe) for body in range(1, 8)
                if not head & body]
    count = 0
    for selected in range(1 << len(possible)):
        rules = [rule for i, rule in enumerate(possible) if selected & (1 << i)]
        for order in (rules, rules[::-1]):
            for weights in ((1, 1, 1), (0, 2, 3), (7, 0, 1)):
                check_rules(order, table(weights))
                count += 1
    print(f"Ordered rule systems and weights checked: {count}")


def feasible_sets(outgoing):
    n = len(outgoing)
    universe = (1 << n) - 1
    incoming = [universe ^ (1 << v) ^ outgoing[v] for v in range(n)]
    return [subset for subset in range(1 << n)
            if all(outgoing[bit.bit_length() - 1] & subset
                   and incoming[bit.bit_length() - 1] & subset for bit in bits(subset))]


def enumerator_counts(outgoing):
    """Compute value and gradient at all ones from the cube expansion."""
    n = len(outgoing)
    all_bits = (1 << n) - 1
    incoming = [all_bits ^ (1 << v) ^ outgoing[v] for v in range(n)]
    total = 0
    degrees = [0] * n

    def record(sign, fixed, free):
        nonlocal total
        cube_size = 1 << free.bit_count()
        total += sign * cube_size
        for bit in bits(fixed):
            degrees[bit.bit_length() - 1] += sign * cube_size
        for bit in bits(free):
            degrees[bit.bit_length() - 1] += sign * (cube_size // 2)

    record(1, 0, all_bits)
    for v in range(n):
        root = 1 << v
        record(-1, root, outgoing[v])
        record(-1, root, incoming[v])
        record(1, root, 0)
        for other in bits(outgoing[v]):
            between = outgoing[v] & incoming[other.bit_length() - 1]
            record(1, root | other, between)
    return total, degrees


def check_tournament(outgoing):
    family = feasible_sets(outgoing)
    size, degrees = enumerator_counts(outgoing)
    assert size == len(family)
    assert degrees == [sum(bool(subset & (1 << v)) for subset in family)
                       for v in range(len(outgoing))]
    if len(family) == 1:
        return 0
    support = family[-1]
    triangles = [subset for subset in family if subset.bit_count() == 3]
    # A tournament vertex is in a non-singleton strong component iff it
    # lies on a directed triangle. Count these directly for each prescribed member.
    triangle_count = {bit: sum(bool(bit & tri) for tri in triangles) for bit in bits(support)}
    for chosen in family[1:]:
        covered = 0
        for tri in triangles:
            if tri & chosen == tri:
                covered |= tri
        size = chosen.bit_count()
        singletons = (chosen ^ covered).bit_count()
        lower = sum(triangle_count[bit] - 1 for bit in bits(chosen)) + singletons * (size - 3)
        actual = sum(2 * (member & chosen).bit_count() - size for member in family)
        assert actual >= lower >= 0
        if chosen == support:
            # Test equality via the stated graph shape, using direct cross-arc checks.
            is_equality = chosen.bit_count() == 3
            if chosen.bit_count() == 6:
                for first in triangles:
                    second = support ^ first
                    if second in triangles and all(
                            outgoing[bit.bit_length() - 1] & second == second for bit in bits(first)):
                        is_equality = True
            assert (actual == 0) == is_equality
    return len(family) - 1


def test_tournaments():
    for n in range(1, 7):
        edges = list(combinations(range(n), 2))
        total = 1 << len(edges)
        prescribed = 0
        for orientation in range(total):
            outgoing = [0] * n
            for i, (a, b) in enumerate(edges):
                if orientation & (1 << i):
                    a, b = b, a
                outgoing[a] |= 1 << b
            prescribed += check_tournament(outgoing)
        print(f"{n} vertices: {total} labeled tournaments, {prescribed} prescribed nonempty sets")


def test_witness():
    # Blocks 0,1,2 form A; 3 is v; 4,5,6 form B; 7 is w.
    outgoing = [0] * 8
    for triple in ((0, 1, 2), (4, 5, 6)):
        for i in range(3):
            outgoing[triple[i]] |= 1 << triple[(i + 1) % 3]
    for sources, targets in ((range(3), (3, 4, 5, 6)), ((3,), (4, 5, 6, 7)),
                             ((4, 5, 6), (7,)), ((7,), range(3))):
        for v in sources:
            for u in targets:
                outgoing[v] |= 1 << u
    family = feasible_sets(outgoing)
    assert 127 in family
    inside_through_v = [s for s in family if s & 8 and not s & 128]
    assert inside_through_v == [127]
    check_tournament(outgoing)
    print("Eight-vertex tournament and seven-vertex irreducible member verified.")
    size, counts = enumerator_counts(outgoing)
    print(f"Witness family size {size}, vertex counts {counts}.")


if __name__ == "__main__":
    test_rule_systems()
    test_tournaments()
    test_witness()
    paley = [sum(1 << ((i + step) % 7) for step in (1, 2, 4)) for i in range(7)]
    family = feasible_sets(paley)
    for side in (paley[0], 126 ^ paley[0]):
        assert side in family and (side | 1) not in family
    print("Paley 7 dependency obstruction verified.")
    print("Paley 7 family size and occurrence counts:", *enumerator_counts(paley))
