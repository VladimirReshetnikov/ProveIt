#!/usr/bin/env python3
"""Independent certificates using only hulls of negative traces; Python 3.10+."""
SEEDS = frozenset((0, 7, 25, 31))


def negative_hulls(weights):
    hulls = {frozenset()}
    for coordinate, value in enumerate(weights):
        if value >= 0:
            continue
        added = {h | frozenset(coordinate | s for s in h | SEEDS)
                 for h in hulls}
        hulls.update(added)
    hulls.remove(frozenset())
    return hulls


def unswitchable(h, singleton):
    return not (0 in h and singleton in h)


def run():
    patterns = range(32)
    local = [41*(mask & 1) + 25*(mask & 30).bit_count() - 69 for mask in patterns]
    hulls = negative_hulls(local)
    values = {sum(local[x] for x in h) for h in hulls}
    assert min(values) == 0
    assert {v for v in values if v < 9} <= {0,5,6}
    assert {v for v in local if 0 <= v < 9} == {6}
    print(f"Score: {len(hulls)} nonempty negative hulls, values below 9:"
          f" {sorted(v for v in values if v < 9)}; other positive traces cost at least 6.")
    for singleton, coeffs, offset in ((1,(39,32,32,32,32),1),
                                      (2,(311,115,211,163,163),5)):
        local = [offset + sum(w*(2*((mask >> i)&1)-1) for i,w in enumerate(coeffs))
                 for mask in patterns]
        hulls = negative_hulls(local)
        candidates = [h for h in hulls if unswitchable(h, singleton)]
        minimum = min(sum(local[x] for x in h) for h in candidates)
        assert minimum == 0
        print(f"Unswitchable singleton mask {singleton}: {len(candidates)} negative hulls,"
              f" minimum slack {minimum}.")


if __name__ == "__main__":
    run()
