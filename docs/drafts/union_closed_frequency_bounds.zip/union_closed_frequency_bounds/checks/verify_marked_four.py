#!/usr/bin/env python3
"""Exact independent checks for the four-element member theorem (Python 3.10+)."""
from fractions import Fraction
from itertools import combinations, combinations_with_replacement


def subcube(mask):
    return frozenset(s for s in range(mask + 1) if (s | mask) == mask)


def is_union_closed(family):
    return all((a | b) in family for a, b in combinations(family, 2))


def marked_score(fiber):
    return sum(5 * s.bit_count() - 8 for s in fiber)


def audit_fibers():
    full = frozenset(range(16))
    ordinary = {subcube(e) | {15} for e in full if e.bit_count() == 2}
    zeros = set()
    valid = mixed_targets = 0
    minimum_mixed = 33
    mixed_requirements = {
        frozenset(a | b for a in first for b in second)
        for first, second in combinations(ordinary, 2)
    }
    for code in range(1 << 15, 1 << 16):
        fiber = frozenset(s for s in full if (code >> s) & 1)
        if not is_union_closed(fiber):
            continue
        valid += 1
        score = marked_score(fiber)
        assert score >= 0
        if score == 0:
            zeros.add(fiber)
        if any(req <= fiber for req in mixed_requirements):
            mixed_targets += 1
            assert score >= 8
            minimum_mixed = min(minimum_mixed, score)
    assert zeros == ordinary and minimum_mixed == 8
    return valid, mixed_targets


def audit_examples():
    front = 15
    first, second = subcube(3) | {front}, subcube(12) | {front}
    for k in range(2, 7):
        block1 = (1 << k) - 1
        block2 = block1 << k
        both = block1 | block2
        fibers = {0: frozenset((0, front)), both: subcube(front)}
        for p in subcube(block1) - {block1}:
            fibers[block2 | p] = first
        for p in subcube(block2) - {block2}:
            fibers[block1 | p] = second
        for (x, left), (y, right) in combinations_with_replacement(fibers.items(), 2):
            target = fibers[x | y]
            assert all((a | b) in target for a in left for b in right)
        n = sum(map(len, fibers.values()))
        degree = [sum(bool(c & (1 << i)) for f in fibers.values() for c in f)
                  for i in range(4)]
        outside = [sum(len(f) for s, f in fibers.items() if s & (1 << i))
                   for i in range(2 * k)]
        t = 2**k - 1
        assert n == 10*t + 18 and degree == [4*t + 9] * 4
        assert 5*max(degree) - 2*n == 9
        assert outside == [5*t + 5*(2**(k-1) - 1) + 16] * (2*k)
        sum_scores = sum(marked_score(f) for f in fibers.values())
        assert sum_scores == 36
        v = Fraction(5*t, n)
        assert 2*v*v >= Fraction(1, 2) - Fraction(321*9, 2*n)


def small_log_interval(r, terms=28):
    """Rational enclosure for log(r), with 1 <= r <= 2."""
    assert 1 <= r <= 2
    z = (r - 1) / (r + 1)
    low = 2*sum(z**(2*k+1) / (2*k+1) for k in range(terms))
    tail_bound = 2*z**(2*terms+1) / ((2*terms+1)*(1-z*z))
    return low, low + tail_bound


def log_interval(r):
    """Dyadic range reduction followed by the atanh-series enclosure."""
    r = Fraction(r)
    assert r >= 1
    k = 0
    while r >= 2:
        k += 1
        r /= 2
    lower, upper = small_log_interval(r)
    l2, u2 = small_log_interval(Fraction(2))
    return k*l2 + lower, k*u2 + upper


def finite_frequency_check():
    n, e = 40968, 9
    r = Fraction(1, 2) - Fraction(321*e, 2*n)
    k0 = Fraction(n, 5) + 4*e
    ell_low = log_interval(Fraction(n, 5))[0] - Fraction(64*e, n)*log_interval(Fraction(16, 5))[1]
    numerator_high = (log_interval(2)[1] + (1-r)*log_interval(k0)[1]
                      + r*log_interval(Fraction(e, 2))[1])
    tau_high = Fraction(618034, 1000000)
    assert tau_high**2 + tau_high > 1 and ell_low > 0
    bound = 1 - tau_high*numerator_high/ell_low
    assert bound > Fraction(57, 100)


if __name__ == "__main__":
    valid, mixed = audit_fibers()
    audit_examples()
    finite_frequency_check()
    print("Four-point families containing the full trace tested: 32768")
    print(f"Union-closed fibers among them: {valid}; zero-score fibers: 6")
    print(f"Possible mixed output fibers: {mixed}; minimum score: 8")
    print("Complete union-closure and all degrees checked for block sizes 2 through 6.")
    print("Certified via rational intervals: N=40968 and E=9 imply p_out > 57/100.")
