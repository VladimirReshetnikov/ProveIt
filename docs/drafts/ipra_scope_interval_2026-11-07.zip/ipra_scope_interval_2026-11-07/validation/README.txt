PORTABLE VALIDATION OF LIVE-INTERVAL OPENING
==========================================

Everything in this directory is untrusted test support. The complete
acceptance program checker.py imports none of it. Passing finite tests does
not prove consistency, soundness for every possible certificate, or the
bi-interpretation theorem; those claims have written proofs in the report.

From the package root, run:

    python3 reproduce_checks.py

This measures the complete sources, runs the main audit, and runs a second,
independently prepared review. It writes results/metrics.json,
results/validation.json, results/independent_review.json, and a concise
results/receipt.json. No repository download or network access is needed.
Each script also accepts --checker /absolute/path/checker.py. The checker
itself requires Python 3.10 or later; exact source normalization counts were
recorded with CPython 3.12.14.

MAIN AUDIT
----------
named_oracle.py has separate term and formula grammars and uses explicit
named binders. It does not use the production packed-depth table, the
production opening function, or its match-statement rule dispatcher. Its
one changed scope rule is explicit source code: an integer below the current
floor denotes the unique hole when parsing a template. The original oracle
is retained as named_oracle_previous.py; there is no runtime source rewrite.

verify.py checks:

* The already-used deterministic cohort of 14,000 randomized openings,
  against the independent named parser. All 1,046 successful openings also
  agree with the previous checker after independent sorted canonicalization.
* 24 explicit opening cases covering both interval boundaries, negative
  holes, live rigid parameters, nested binders, protected aliases, invalid
  images, unused images, sort errors, and capture prevention.
* All 207 inherited fixed packets. Their original files are preserved
  byte-for-byte, with hashes. The annotated union keeps every original field
  and adds interval_expected, with an explanation where a verdict changes.
* All 207 packets through each of four complete CLI scripts: the old
  one-hole program, the interval-only ablation, the driver-only ablation,
  and the final program. Each runs normally and with Python -O. These are
  1,656 executions of 207 fixed packets, not 1,656 different theorems.
* Twelve readable examples, including 2+3=5 and the genuine new negative-hole
  transport certificate. Both old and new complete CLIs are run in both
  interpreter modes on these examples, for 48 additional executions.

The only changed verdict among the 207 inherited packets is
new/used_future_motive_parameter. Its old template [-999,0] was rejected for
an undeclared rigid parameter. Under the new convention it means the one-hole
formula x=0. The packet proves I(0,0;u.0)=0 twice by computation, then uses
one real equality-transport step to derive 0=0. The trace is required to
contain exactly those two computations and that transport. Closed goals,
closed update bodies, and effective replacement images still reject
undeclared parameters.

Function-level opening tests read the original ASTs of inst and check, without
changing their bodies. This is only a way to call those functions in a test.
Every complete CLI is tested separately; no claim about the driver is based
on stripping it or assuming that an extracted function program is equivalent.

SECOND INDEPENDENT REVIEW
-------------------------
independent_review.py is the portable version of a separate review completed
before package integration. The original reviewer source and recorded result
are preserved as independent_review_original.py and
independent_review_original_results.json. provenance.json records their
hashes and the exact adaptation: candidate/reference/output paths and source
hash recording. The normalization algorithm and test cohorts are unchanged.

The second review checks 13,440 systematic opening/canonicalization pairs
and 13 directed proof packets through the old and new CLIs, normally and
under Python -O (52 CLI executions). In particular it distinguishes:

* a negative alias that becomes a live rigid name while its major proof is
  checked, so it must no longer be treated as a hole;
* a more negative alias that is still a hole after that major proof;
* an alias whose numerical value is allocated only in the minor proof, after
  both transport endpoints have already been opened.

The canonicalization theorem must therefore use the floor at the time the
motive is opened: after the major proof, before the minor proof. A global
textual replacement performed before proof checking is not the claimed
translation.

All sources, fixtures, and metric code retain explicit provenance. The total
1,756 CLI executions include repeated implementations, interpreter modes,
and selected examples. They are implementation evidence, not an independent
formal verification of the arithmetic metatheory.
