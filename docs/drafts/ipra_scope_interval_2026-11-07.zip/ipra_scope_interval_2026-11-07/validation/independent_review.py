"""Independent directed audit; untrusted and not imported by acceptance kernel."""
from pathlib import Path
import argparse
from hashlib import sha256
import ast
import copy
import json
import subprocess
import sys
import tempfile
import types

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--checker', type=Path, default=ROOT / 'checker.py')
parser.add_argument('--output', type=Path, default=ROOT / 'results/independent_review.json')
args = parser.parse_args()
CAND = args.checker.resolve()
manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
ref_info = manifest['baseline_for_ablation']
REF = ROOT / ref_info['local_file']
assert sha256(REF.read_bytes()).hexdigest() == ref_info['sha256']

def functions(path):
    tree = ast.parse(path.read_text())
    body = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
    env = {'k': 0}
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), 'exec'), env)
    return env

candidate = functions(CAND)
reference = functions(REF)

def canonical(value, floor, level=0, term=False):
    """Use independent sorted grammar, with one external variable at each level."""
    if term:
        if type(value) is int:
            return value if floor <= value < 2 * level + 1 else 2 * level + 1
        if type(value) is not list:
            raise ValueError('non-term')
        if len(value) == 1:
            return [canonical(value[0], floor, level, True)]
        if len(value) == 3:
            return [canonical(value[0], floor, level, True),
                    canonical(value[1], floor, level, True),
                    canonical(value[2], floor, level + 1, True)]
        raise ValueError('non-term')
    if type(value) is not list:
        raise ValueError('non-formula')
    if len(value) == 1:
        return [canonical(value[0], floor, level + 1)]
    if len(value) == 2:
        return [canonical(child, floor, level, True) for child in value]
    if len(value) == 3:
        return [canonical(child, floor, level + 2) for child in value]
    raise ValueError('non-formula')

def opening(module, value, image, floor, depth):
    module['k'] = floor
    try:
        return (True, module['inst'](copy.deepcopy(value), copy.deepcopy(image), depth))
    except Exception:
        return (False, None)

# Genuine substitution motives in which bound coordinates, rigid variables,
# both sorts, all binder kinds, and both ends of the interval are present.
integers = [-10**60, -7, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 99, 10**60]
count = 0
for floor in [0, -1, -3, -7]:
    images = [0, [0], [0, 0, 1], None, -1, -8, 1, True]
    for v in integers:
        terms = [v, [v], [0, v, 1], [v, 0, 3], [0, 0, [0, v, 3]]]
        formulae = [[v, 0], [[v, 1]], [[v, 3], [v, 1], [0, 0]],
                    [[[0, v, 5], 3]], [[[v, 5]], [0, 0], [0, 0]]]
        for term, values in [(True, terms), (False, formulae)]:
            for value in values:
                for level in [0, 1, 2]:
                    normal = canonical(value, floor, level, term)
                    for image in images:
                        actual = opening(candidate, value, image, floor, 2 * level + int(term))
                        expected = opening(reference, normal, image, floor, 2 * level + int(term))
                        assert actual == expected, (floor, value, level, term, image, actual, expected)
                        count += 1

zero_computation = [[0, 0, 0], 0]
q_computation = [zero_computation]

def outer_transport(hole, allocate_major=False, allocate_minor=False):
    # Instructions in the chronological order that check() consumes them.
    steps = [[zero_computation, [hole, 0]]]
    if allocate_major:
        steps += [[q_computation, 0], [None], []]
    else:
        steps += [[]]
    if allocate_minor:
        steps += [[q_computation, 0], [None], []]
    else:
        steps += [[]]
    return list(reversed(steps)) + [[0, 0]]

cases = [
    ('new_negative_hole_at_floor_zero', outer_transport(-1), True, False),
    ('very_negative_hole', outer_transport(-10**60), True, False),
    ('positive_hole_unchanged', outer_transport(1), True, True),
    ('major_allocation_makes_alias_rigid', outer_transport(-1, allocate_major=True), False, False),
    ('major_allocation_leaves_more_negative_alias_hole', outer_transport(-2, allocate_major=True), True, False),
    ('minor_allocation_does_not_reinterpret_endpoints', outer_transport(-1, allocate_minor=True), True, False),
    ('both_major_and_minor_allocations', outer_transport(-2, allocate_major=True, allocate_minor=True), True, False),
    ('future_negative_closed_goal_rejected', [[], [-1, -1]], False, False),
    ('future_negative_unused_update_rejected', [[], [[0, 0, -1], 0]], False, False),
    ('future_negative_used_witness_rejected', [[-1], [[3, 3], [0, 0], [0, 0]]], False, False),
    ('unused_future_negative_witness_harmless', [[-999], [[0, 0], [0, 0], [0, 0]]], True, True),
    ('used_image_cannot_contain_future_negative', [[], [], [zero_computation, [-99, 0]], [-1, 0]], False, False),
    ('zero_successor_false_goal', [[], [0, [0]]], False, False),
]

runs = []
with tempfile.TemporaryDirectory() as tmp:
    packet_file = Path(tmp) / 'packet.json'
    for label, packet, want_candidate, want_reference in cases:
        packet_file.write_text(json.dumps(packet))
        for path, want in [(CAND, want_candidate), (REF, want_reference)]:
            for optimized in [False, True]:
                command = [sys.executable] + (['-O'] if optimized else []) + [str(path), str(packet_file)]
                result = subprocess.run(command, capture_output=True, text=True, timeout=10)
                accepted = result.returncode == 0
                assert accepted == want, (label, path, optimized, want, result.stdout, result.stderr)
                assert result.stdout.strip() == ('ACCEPT' if accepted else 'REJECT')
                runs.append({'case': label, 'checker': path.name if path == REF else 'candidate',
                             'optimized': optimized, 'accepted': accepted})

out = {'canonicalization_cases': count, 'directed_packet_cases': len(cases),
       'cli_runs': len(runs), 'all_pass': True, 'cases': runs}
out['checker_sha256'] = sha256(CAND.read_bytes()).hexdigest()
out['reference_sha256'] = sha256(REF.read_bytes()).hexdigest()
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({k: v for k, v in out.items() if k != 'cases'}, indent=2))
