"""Independent finite checks of interval opening and complete CLI verdicts.

This code is untrusted support, never imported by checker.py. Function-level
opening tests load the candidate's unchanged function ASTs. Every one of the
207 fixed packets is also run through the actual, complete candidate CLI,
both normally and under Python -O. The same full-driver runs cover the two
ablations and the earlier checker; no claim about their drivers relies on
the function extraction used for opening tests.
"""
import argparse
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import types

from named_oracle import Oracle, opening

ROOT = Path(__file__).resolve().parent.parent
HERE = Path(__file__).resolve().parent
CHANGED = 'new/used_future_motive_parameter'


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def file_hash(path):
    return sha256(path.read_bytes()).hexdigest()


def load_functions(path):
    """Load the actual top-level function ASTs without executing a CLI driver.

    No function body is transformed. The actual complete script is tested
    separately by subprocess, so driver tests do not trust this operation.
    """
    tree = ast.parse(path.read_text(), filename=str(path))
    selected = []
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef)):
            selected.append(node)
        elif (isinstance(node, ast.Assign) and len(node.targets) == 1
              and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'k'):
            selected.append(node)
    module = types.ModuleType('tested_kernel')
    module.__file__ = str(path)
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), 'exec'), module.__dict__)
    require(callable(module.inst) and callable(module.check), 'Kernel functions missing')
    return module


def run(module, packet):
    module.k = 0
    stack = deepcopy(packet)
    try:
        module.take = stack.pop
        accepted = bool(module.check(stack.pop(), []))
        error = None
    except Exception as exception:
        accepted, error = False, type(exception).__name__
    return {'accepted': accepted, 'final_k': module.k,
            'remaining': len(stack) if type(stack) is list else None, 'error': error}


def call_open(module, value, image, lower, depth):
    module.k = lower
    try:
        return True, module.inst(deepcopy(value), deepcopy(image), d=depth)
    except Exception:
        return False, None


def oracle_open(value, image, lower, depth):
    try:
        return True, opening(deepcopy(value), deepcopy(image),
                             formula=depth % 2 == 0, depth=depth // 2, lower=lower)
    except Exception:
        return False, None


def canonicalize(value, lower, depth):
    """Independent separate-sort normalizer into the previous one-hole grammar.

    The parameter floor is an explicit argument, just as in the mathematical
    statement. It is not read from or inferred using the production opener.
    """
    def term(x, binders):
        if type(x) is int:
            first_free = 2 * binders + 1
            return x if lower <= x < first_free else first_free
        if type(x) is not list:
            raise ValueError('not a numerical tree')
        if len(x) == 1:
            return [term(x[0], binders)]
        if len(x) == 3:
            return [term(x[0], binders), term(x[1], binders), term(x[2], binders + 1)]
        raise ValueError('invalid numerical arity')

    def formula(x, binders):
        if type(x) is not list:
            raise ValueError('not a formula tree')
        if len(x) == 2:
            return [term(part, binders) for part in x]
        if len(x) == 1:
            return [formula(x[0], binders + 1)]
        if len(x) == 3:
            return [formula(part, binders + 2) for part in x]
        raise ValueError('invalid formula arity')
    return (term if depth % 2 else formula)(value, depth // 2)


def randomized_openings(candidate, previous):
    # Reproduce the already-used deterministic cohort; this is not a larger
    # search that keeps growing until a favorable result appears.
    rng = random.Random(7112026)
    leaves = [-10**30, -7, -3, -2, -1, 0, 1, 2, 3, 4, 5, 99, 10**30,
              None, True, False, 0.0, {}, 'x']

    def tree(height):
        if height == 0 or rng.random() < .38:
            return deepcopy(rng.choice(leaves))
        return [tree(height - 1) for _ in range(rng.randrange(5))]

    successes = 0
    for index in range(14000):
        value, image = tree(4), tree(2)
        lower, depth = rng.choice([0, -1, -3, -6]), rng.randrange(8)
        actual = call_open(candidate, value, image, lower, depth)
        expected = oracle_open(value, image, lower, depth)
        require(actual == expected, ('named opening oracle', index, value, image, lower, depth, actual, expected))
        if actual[0]:
            normalized = canonicalize(value, lower, depth)
            old = call_open(previous, normalized, image, lower, depth)
            require(actual == old, ('canonicalization', index, actual, old))
            successes += 1
    return {'seed': 7112026, 'cases': 14000, 'successful_openings': successes,
            'failed_openings': 14000 - successes,
            'successful_canonicalizations_checked': successes}


def targeted_openings(candidate, previous):
    # Every tuple is: name, template, image, floor, packed depth, expected.
    # Expected=None means rejection; successful outputs here are never None.
    cases = [
        ('negative_hole', [-99, 0], [0], 0, 0, [[0], 0]),
        ('live_negative_is_rigid', [-1, 7], [0], -1, 0, [-1, [0]]),
        ('lower_boundary', [-3, -4], 0, -3, 0, [-3, 0]),
        ('closed_negative_rejected', [-1, 0], None, 0, 0, None),
        ('closed_positive_rejected', [1, 0], None, 0, 0, None),
        ('undeclared_image_rejected', [99, 0], -1, 0, 0, None),
        ('declared_image_allowed', [99, 0], -1, -1, 0, [-1, 0]),
        ('nested_negative_hole', [[-99, 1]], [0], 0, 0, [[[0], 1]]),
        ('protected_aliases', [[1, 2]], {}, 0, 0, [[1, 2]]),
        ('first_unprotected_slot', [[3, 1]], [0], 0, 0, [[[0], 1]]),
        ('image_with_own_binder', [[-99, 1]], [0, 0, 1], 0, 0, [[[0, 0, 1], 1]]),
        ('image_capture_rejected', [[-99, 1]], 1, 0, 0, None),
        ('nested_image_capture_rejected', [[-99, 1]], [0, 0, 3], 0, 0, None),
        ('inert_unused_image', [[1, 1]], {}, 0, 0, [[1, 1]]),
        ('numerical_hole_is_not_formula', -99, 0, 0, 0, None),
        ('float_is_not_integer', [-99.0, 0], 0, 0, 0, None),
        ('boolean_is_not_integer', [False, 0], 0, 0, 0, None),
        ('closed_padding_still_checked', [[0, 0], [-1, 0], [0, 0]], None, 0, 0, None),
        ('floor_changes_hole_role', [-2, 0], [0], -1, 0, [[0], 0]),
        ('floor_changes_rigid_role', [-2, 0], [0], -2, 0, [-2, 0]),
        ('mixed_outside_labels', [[-100, 99]], [0], 0, 0, [[[0], [0]]]),
        ('nested_iterator_scope', [0, 0, [3, 1, [-9]]], [0], 0, 1,
         [0, 0, [[0], 1, [[0]]]]),
        ('even_bound_alias', 2, None, 0, 3, 2),
        ('term_negative_hole', -6, 0, -3, 3, 0),
    ]
    results = []
    for name, value, image, lower, depth, wanted in cases:
        actual = call_open(candidate, value, image, lower, depth)
        expected = (wanted is not None, wanted)
        require(actual == expected, ('targeted opening', name, actual, expected))
        require(actual == oracle_open(value, image, lower, depth), ('targeted named oracle', name))
        if actual[0]:
            require(actual == call_open(previous, canonicalize(value, lower, depth), image, lower, depth),
                    ('targeted canonicalization', name))
        results.append({'name': name, 'accepted': actual[0]})
    return results


def number(term, environment=()):
    """Literal standard-number evaluation; independent of proof acceptance."""
    if type(term) is int:
        if term == 0:
            return 0
        require(term > 0, 'Free rigid parameter in numerical evaluation')
        return environment[(term - 1) // 2]
    if len(term) == 1:
        return number(term[0], environment) + 1
    count, initial, update = term
    value = number(initial, environment)
    for _ in range(number(count, environment)):
        value = number(update, (value, *environment))
    return value


def cli(checker, packet_file, expected, optimized):
    command = [sys.executable, *(['-O'] if optimized else []), str(checker), str(packet_file)]
    actual = subprocess.run(command, capture_output=True, text=True, timeout=30)
    wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
    verdict = (actual.returncode, actual.stdout.strip(), actual.stderr)
    require(verdict == wanted, ('complete CLI', checker.name, packet_file.name, optimized, verdict, wanted))
    return {'optimized': optimized, 'exit_code': actual.returncode,
            'stdout': actual.stdout.strip()}


def verify_provenance():
    provenance = json.loads((HERE / 'provenance.json').read_text())
    for row in [*provenance['fixture_sources'], provenance['fixed_union'],
                provenance['oracle'], provenance['oracle']['modified_from']]:
        require(file_hash(ROOT / row['local_file']) == row['sha256'],
                ('Changed validation source', row['local_file']))
    original = []
    for row in provenance['fixture_sources']:
        original.extend(json.loads((ROOT / row['local_file']).read_text()))
    fixed = json.loads((ROOT / provenance['fixed_union']['local_file']).read_text())
    require(len(fixed) == len(original) == 207, 'Fixed cohort size changed')
    for new, old in zip(fixed, original):
        require({k: v for k, v in new.items() if k not in ('interval_expected', 'interval_explanation')} == old,
                ('Changed inherited fixture', old['name']))
    return fixed, provenance


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, default=ROOT / 'checker.py')
    parser.add_argument('--output', type=Path, default=ROOT / 'results' / 'validation.json')
    args = parser.parse_args()
    checker = args.checker.resolve()
    rows, provenance = verify_provenance()
    manifest = json.loads((ROOT / 'comparison' / 'manifest.json').read_text())
    baseline = manifest['baseline_for_ablation']
    reference_path = ROOT / baseline['local_file']
    require(file_hash(reference_path) == baseline['sha256'], 'Changed previous checker')
    candidate, previous = load_functions(checker), load_functions(reference_path)
    randomized = randomized_openings(candidate, previous)
    targeted = targeted_openings(candidate, previous)

    fixed_results = []
    changed = []
    for row in rows:
        got, old = run(candidate, row['packet']), run(previous, row['packet'])
        named = Oracle().run(row['packet'])
        require(old['accepted'] == row['expected'], ('Inherited verdict', row['name'], old))
        require(got['accepted'] == named['accepted'] == row['interval_expected'],
                ('New verdict', row['name'], got, named, row['interval_expected']))
        if got['accepted']:
            require((got['final_k'], got['remaining']) == (named['final_k'], named['remaining']),
                    ('Successful execution state', row['name'], got, named))
        if got['accepted'] != old['accepted']:
            changed.append(row['name'])
        fixed_results.append({'name': row['name'], 'accepted': got['accepted'],
                              'previous_accepted': old['accepted'], 'rules': named['rules']})
    require(changed == [CHANGED], ('Unexpected changed verdicts', changed))
    changed_result = next(row for row in fixed_results if row['name'] == CHANGED)
    require(changed_result['rules'].get('equality_transport') == 1
            and changed_result['rules'].get('iteration_zero') == 2,
            ('Negative-hole example did not use its genuine premises', changed_result))

    examples = json.loads((ROOT / 'examples' / 'index.json').read_text())
    example_results = []
    for row in examples:
        path = ROOT / row['file']
        require(file_hash(path) == row['sha256'], ('Changed example', row['file']))
        packet = json.loads(path.read_text())
        actual, old = run(candidate, packet), run(previous, packet)
        named = Oracle().run(packet)
        require(actual['accepted'] == row['expected'] == named['accepted'], ('Example', row['file']))
        require(old['accepted'] == row['previous_expected'], ('Previous example', row['file']))
        record = {'file': row['file'], 'accepted': actual['accepted'],
                  'previous_accepted': old['accepted'], 'rules': named['rules']}
        if path.name == 'addition_2_3.json':
            lhs, rhs = packet[-1]
            require(number(lhs) == number(rhs) == 5, 'Addition evaluation failed')
            require(number(lhs[0]) == 3 and number(lhs[1]) == 2, 'Addition encoding changed')
            record['arithmetic'] = {'initial': 2, 'counter': 3, 'value': 5,
                                    'instruction_cells': len(packet) - 1}
        example_results.append(record)

    # Test the full scripts, not the extracted in-process function modules.
    programs = [{'name': 'delivered', 'path': checker, 'language': 'interval'},
                {'name': 'previous_one_hole', 'path': reference_path, 'language': 'previous'}]
    for row in manifest['ablations']:
        path = ROOT / row['local_file']
        require(file_hash(path) == row['sha256'], ('Changed ablation', row['local_file']))
        programs.append({'name': path.stem, 'path': path, 'language': row['expected_language']})
    cli_results = []
    example_cli_runs = 0
    with tempfile.TemporaryDirectory(prefix='ipra_interval_cli_') as directory:
        packet_files = []
        for index, row in enumerate(rows):
            path = Path(directory) / ('fixture_%03d.json' % index)
            path.write_text(json.dumps(row['packet']) + '\n')
            packet_files.append(path)
        for program in programs:
            counts = Counter()
            for row, path in zip(rows, packet_files):
                expected = row['interval_expected'] if program['language'] == 'interval' else row['expected']
                for optimized in (False, True):
                    cli(program['path'], path, expected, optimized)
                    counts['optimized' if optimized else 'normal'] += 1
                    counts['accept' if expected else 'reject'] += 1
            cli_results.append({'program': program['name'], 'sha256': file_hash(program['path']),
                                'language': program['language'], 'runs': sum(counts[k] for k in ('normal', 'optimized')),
                                'counts': dict(counts)})
        for row in examples:
            for program in programs[:2]:
                expected = row['expected'] if program['language'] == 'interval' else row['previous_expected']
                for optimized in (False, True):
                    cli(program['path'], ROOT / row['file'], expected, optimized)
                    example_cli_runs += 1

    report = {
        'python': platform.python_version(), 'checker_sha256': file_hash(checker),
        'commit': provenance['commit'], 'all_pass': True,
        'randomized_openings': randomized,
        'targeted_openings': targeted,
        'fixed_packets': len(rows),
        'accepted_fixed_packets': sum(row['accepted'] for row in fixed_results),
        'previous_accepted_fixed_packets': sum(row['previous_accepted'] for row in fixed_results),
        'changed_fixed_outcomes': changed,
        'changed_case_trace': changed_result,
        'fixed_results': fixed_results,
        'examples': example_results,
        'full_script_fixed_cli': cli_results,
        'example_cli_runs': example_cli_runs,
        'total_full_script_cli_runs': sum(row['runs'] for row in cli_results) + example_cli_runs,
        'distinct_fixed_packets': 207,
        'evidence_scope': 'Finite implementation checks and source measurements; no formal proof of the metatheorems.'
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in report.items()
                      if key not in ('fixed_results', 'examples', 'targeted_openings')}, indent=2))


if __name__ == '__main__':
    main()
