"""Reproduce the complete-source comparison against the pinned six ZIPs.

This is untrusted measurement support. The acceptance program imports none
of it. The inherited metric implementation is copied without modification.
"""
import argparse
import csv
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parent
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def require(condition, explanation):
    if not condition:
        raise AssertionError(explanation)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def load(path):
    spec = importlib.util.spec_from_file_location('frozen_source_measure', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, default=ROOT / 'checker.py')
    parser.add_argument('--output', type=Path, default=ROOT / 'results' / 'metrics.json')
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'comparison' / 'manifest.json').read_text())
    metric = manifest['metric_source']
    require(digest(ROOT / metric['local_file']) == metric['sha256'],
            'Changed inherited metric implementation')
    measure = load(ROOT / metric['local_file'])

    expanded = []
    lookup = {}
    for row in manifest['distinct_expanded_sources']:
        path = ROOT / row['local_file']
        require(digest(path) == row['sha256'], ('Changed frozen source', row['local_file']))
        measured = measure.metrics(path)
        lookup[row['sha256']] = measured
        expanded.append({**row, 'metrics': measured})
    current = [{**row, 'metrics': lookup[row['sha256']]}
               for row in manifest['root_programs']]
    require(len(current) == 13 and len(expanded) == 80, 'Pinned inventory count changed')

    current_minimum = {key: min(row['metrics'][key] for row in current) for key in KEYS}
    expanded_minimum = {key: min(row['metrics'][key] for row in expanded) for key in KEYS}
    expected_minimum = dict(zip(KEYS, (389, 413, 1159)))
    require(current_minimum == expected_minimum, ('Pinned current envelope changed', current_minimum))
    require(expanded_minimum == expected_minimum, ('Pinned expanded envelope changed', expanded_minimum))

    baseline = manifest['baseline_for_ablation']
    ablations = [{**baseline, 'label': 'Previous one-hole checker; inherited importable driver',
                  'expected_language': 'previous', 'metrics': lookup[baseline['sha256']]}]
    for row in manifest['ablations']:
        path = ROOT / row['local_file']
        require(digest(path) == row['sha256'], ('Changed ablation', row['local_file']))
        ablations.append({**row, 'metrics': measure.metrics(path)})
    candidate = measure.metrics(args.checker.resolve())
    ablations.append({'label': 'Delivered interval checker; standalone driver',
                      'local_file': 'checker.py', 'expected_language': 'interval',
                      'metrics': candidate})

    expected_ablations = [(389, 413, 1188), (385, 410, 1180),
                          (385, 410, 1137), (381, 407, 1129)]
    for row, expected in zip(ablations, expected_ablations):
        require(tuple(row['metrics'][key] for key in KEYS) == expected,
                ('Unexpected ablation count', row['label'], row['metrics'], expected))
    strict = {key: candidate[key] < current_minimum[key] for key in KEYS}
    require(all(strict.values()), ('Candidate does not beat every coordinate', strict))

    result = {
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'commit': manifest['commit'],
        'archive_count': len(manifest['archives']),
        'current_program_count': len(current),
        'expanded_distinct_source_count': len(expanded),
        'expanded_path_count': sum(len(row['original_paths']) for row in expanded),
        'current_coordinatewise_minimum': current_minimum,
        'expanded_coordinatewise_minimum': expanded_minimum,
        'minimum_attainers': {key: [row['label'] for row in current
                                    if row['metrics'][key] == current_minimum[key]] for key in KEYS},
        'candidate': candidate,
        'strictly_below_every_coordinate': strict,
        'ablations': ablations,
        'isolated_interval_delta': dict(zip(KEYS, (-4, -3, -8))),
        'isolated_driver_delta': dict(zip(KEYS, (-4, -3, -51))),
        'current_programs': current,
        'expanded_sources': expanded,
        'scope': 'Finite corpus-relative full-source comparison; not an absolute complexity lower bound.'
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    with args.output.with_suffix('.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ['label', *KEYS, 'sha256'])
        writer.writeheader()
        for row in current + ablations[1:]:
            writer.writerow({'label': row['label'], **{key: row['metrics'][key] for key in KEYS},
                             'sha256': row['metrics']['sha256']})
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('current_programs', 'expanded_sources')}, indent=2))


if __name__ == '__main__':
    main()
