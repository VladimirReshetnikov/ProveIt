INTERVAL SUBSTITUTION FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 7 November 2026

START HERE

report.pdf is the complete mathematical article. report.tex and sections/
contain its editable LaTeX sources. checker.py is the entire standalone
acceptance program; FORMAT.txt specifies its exact certificate language.

ESTABLISHED RESULT

The complete checker is strictly below the coordinatewise minima of all
thirteen current root acceptance programs in the six supplied archives:

                                      Tokens    AST nodes    Normalized bytes
Current corpus envelope                  389          413                1159
Interval checker.py                      381          407                1129

The source snapshot is ProveIt commit:
6ee66e8e01b8cf39d81f53fce44cbedfede2dfdb
https://github.com/VladimirReshetnikov/ProveIt/tree/6ee66e8e01b8cf39d81f53fce44cbedfede2dfdb/docs/drafts

An expanded inventory of eighty distinct checker-shaped programs has the
same minima. The preserved metric strips true docstrings, normalizes with
ast.unparse, and counts the whole program, including input, validation,
proof rules and the verdict driver. Exact counts use CPython 3.12.14.

WHAT CHANGED

Live numerical coordinates form the interval k <= a < d: allocated
parameters, zero, and locally protected bound coordinates. Every integer
outside that interval now denotes the single hole in an OPEN template.
Closed expressions and inserted numerical images have no available hole
and still reject undeclared parameters and unbound coordinates.

A uniform canonicalization maps every such template to the preceding
positive-hole convention. It uses the parameter floor when the template is
opened, after the major proof. Both endpoint instances of equality transport
use this same floor, before the minor proof can allocate further parameters.
The report proves extraction of a native derivation from every successful
run and preservation of the closed theorem set.

The isolated new scope rule saves 4 tokens, 3 AST nodes and 8 normalized
bytes. The rest of the total reduction uses an explicitly credited
standalone driver from the current absorbed-scalar draft. Controlled
ablations expose the separate contributions.

MATHEMATICAL CONTENT

The native basis retains zero, successor, initialized scalar iteration,
equality, and the Q/D logical binders. Five primitive inference patterns
and two computation schemas are stated in full. The checker directly
accepts the already-derived Q-introduction rule as well.

The article restates the inherited full intuitionistic logical
reconstruction, internal predecessor, quantifier-free reflection, pairing,
general primitive-recursion compiler, ordinary first-order realization,
and both interpretation composites. The ordinary realization is
bi-interpretable with full first-order iPRA on the entire numerical domain.
Both internally proved isomorphisms have graph x=y. This includes
nonstandard counters. Equiconsistency uses the explicit falsity bridge.

There is also a new obstruction theorem for the proposed update-generated
initializer B(n;h)=h^n(S(h(0))). Every term in that grammar is bounded by a
primitive recursive function of one chosen input coordinate. Consequently
addition, maximum and injective pairing cannot be term-defined there.
This is NOT a theorem excluding all relational or different-domain
interpretations. The precise scope is stated in the paper.

REPRODUCE OFFLINE

  python3 package.py --verify
  python3 reproduce.py
  python3 build.py

The first command verifies the delivered file hashes. The second recomputes
measurements and implementation evidence. The third rebuilds report.pdf
with pdfLaTeX; it supports an offline temporary-format fallback for an
unconfigured TeX tree. The included PDF can be read without TeX.

The checker requires Python 3.10+ and imports only json and sys. The audit
uses only the Python standard library. No network or repository checkout
is required after this package has been unpacked. The example index gives
expected verdicts and describes the deliberately changed negative-hole
cases. A command of the form

  python3 checker.py examples/NAME.json

prints ACCEPT and exits 0 on a checked proof, or prints REJECT and exits 1.
A rejection does not mean that the displayed theorem is false.

Reproduction refreshes result files. Rebuilding may change PDF metadata.
Verify original hashes before regeneration; run package.py again after
intentional changes to refresh the manifest and ZIP.

EVIDENCE AND LIMITS

The archive includes an independent named-variable oracle, inherited fixed
packets, randomized opening comparisons, separate directed tests of
use-time scope and eigenparameter allocation, actual normal/-O CLI runs,
source hashes and controlled ablations. Exact counts and changed outcomes
are recorded in results/. No oracle, compiler or fixture is imported by
checker.py.

The universal mathematical claims have written proofs and independent
review. They are not Lean/Rocq formalizations. Finite tests do not establish
consistency, universal correctness or minimality by enumeration. Resource
limits may reject sufficiently large otherwise-valid certificates.

This is a modest structural improvement over a pinned finite corpus, not
an absolute shortestness theorem or a fundamentally new arithmetic basis.
Inherited and new contributions are separated in ATTRIBUTION.txt and in
the article. Further research questions are included.

PACKAGE MAP

report.pdf, report.tex, sections/  Complete article and editable sources
checker.py                       Entire trusted acceptance program
FORMAT.txt                       Exact public syntax and rule contract
examples/                        Accepted/rejected public proof packets
comparison/                      Frozen comparators, metric and provenance
validation/                      Independent oracles and directed checks
results/                         Measurement and validation receipts
measure.py, reproduce.py          Offline evidence reproduction
build.py, package.py              PDF build and integrity/ZIP utilities
repository_snapshot.json         Pinned archive identities
ATTRIBUTION.txt                   New and inherited contribution boundary
UPSTREAM_ATTRIBUTION.txt          Preserved upstream intellectual provenance
LICENSE_SOURCE.txt               Preserved MIT No Attribution license
SHA256SUMS.txt                    Payload integrity manifest
