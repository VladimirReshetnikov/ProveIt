PINNED COMPLETE-SOURCE COMPARISON
================================

Repository: VladimirReshetnikov/ProveIt
Commit: 6ee66e8e01b8cf39d81f53fce44cbedfede2dfdb
Directory: docs/drafts

manifest.json identifies all six ZIP archives by their SHA-256 and Git blob
SHA-1 hashes. It records all 13 current top-level acceptance programs. The
expanded inventory contains 80 distinct sources at 348 archive-member paths:
every Python file found in those ZIPs with top-level functions named inst and
check. This intentionally over-inclusive inventory is not an assertion that
every inherited or experimental source is a sound competing axiomatization.
All 80 exact source byte sequences are frozen under their SHA-256 filenames.

source_measure.py is copied byte-for-byte from the absorbed-scalar archive.
Its complete-program metrics remove genuine docstrings, use ast.unparse to
normalize presentation, and count significant tokens, AST nodes, and UTF-8
bytes. Imports, syntax validation, every inference branch, input parsing,
exception handling, verdict printing, and process status are all counted.
The Python runtime and standard JSON parser are shared ambient dependencies.

Run from the package root:

    python3 measure.py

Or supply another copy of the delivered acceptance file:

    python3 measure.py --checker /absolute/path/checker.py

The current and expanded coordinatewise envelopes are both:

    normalized tokens 389; AST nodes 413; normalized bytes 1159.

The exact-integer delivered program is 381 / 407 / 1129. This is a finite
corpus-relative comparison, not an encoding-independent lower bound or a
proof of absolute shortestness.

ATTRIBUTION OF THE TWO CONTRIBUTIONS
----------------------------------
The ablation table deliberately separates the new opening rule from the
already-existing standalone CLI driver:

                                        Tokens  AST   Bytes
Previous one-hole, importable driver       389   413   1188
Interval opening only                     385   410   1180
Standalone driver only                    385   410   1137
Interval opening and standalone driver    381   407   1129

The isolated new interval convention removes four normalized tokens, three
AST nodes, and eight bytes. The inherited driver independently removes four
tokens, three AST nodes, and 51 bytes. No part of the driver reduction is
presented as a new arithmetic theorem or new opening mechanism. The main
validation script executes all four complete scripts on all 207 fixed
packets under ordinary Python and Python -O, rather than inferring driver
behavior from an extracted function body.

The SHA-256 provenance of the metric implementation and each frozen or
ablation source is verified on every measurement run. Source licenses are
preserved in LICENSE_SOURCE.txt. The mathematical calculus and earlier
one-hole presentation are inherited from the cited ProveIt drafts.
