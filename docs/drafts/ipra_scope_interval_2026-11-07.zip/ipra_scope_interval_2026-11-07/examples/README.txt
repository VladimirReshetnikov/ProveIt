EXAMPLE CERTIFICATES
====================

Run an example from the package root:

    python3 checker.py examples/addition_2_3.json
    python3 checker.py examples/negative_hole_transport.json

Both print ACCEPT and exit with status zero. Instructions are consumed from
right to left; the last array item is the closed goal. An unused prefix has
no effect, and hypothesis recognition consumes no instruction.

addition_2_3.json proves I(3,2;u.Su)=5: starting from two, iterate successor
three times. It has 23 instruction cells. No addition axiom, arithmetic
evaluation oracle, or external proof compiler is used by the checker.

negative_hole_transport.json is the four-cell packet

    [[], [], [[[0,0,0],0],[-999,0]], [0,0]]

Here the major equation is I(0,0;u.0)=0. The motive [-999,0] means x=0,
because -999 lies outside the live interval at both endpoint openings.
The major and minor are genuine zero-computation proofs, so equality
transport derives 0=0. The old checker rejects the same spelling.
negative_hole_transport_canonical.json replaces -999 by 1 and is accepted
by both checkers. The two packets have the same closed goal.

The rejected examples target false arithmetic results, an altered transport
conclusion, undeclared names in a closed goal or update, an invalid used
witness, and variable capture. index.json gives every expected verdict and
file hash, including which spellings the previous checker accepted.
