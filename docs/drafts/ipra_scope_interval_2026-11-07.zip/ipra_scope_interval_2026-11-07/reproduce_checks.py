"""Run the complete portable measurement and validation package."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, default=ROOT / 'checker.py')
    parser.add_argument('--output-directory', type=Path, default=ROOT / 'results')
    parser.add_argument('--summarize-existing', action='store_true',
                        help='Summarize already completed reports whose checker hash still matches.')
    args = parser.parse_args()
    candidate = args.checker.resolve()
    output = args.output_directory.resolve()
    output.mkdir(parents=True, exist_ok=True)
    stages = [('measure.py', 'metrics.json'),
              ('validation/verify.py', 'validation.json'),
              ('validation/independent_review.py', 'independent_review.json')]
    if not args.summarize_existing:
        for program, result in stages:
            process = subprocess.run([sys.executable, '-B', str(ROOT / program),
                                      '--checker', str(candidate), '--output', str(output / result)],
                                     capture_output=True, text=True)
            if process.returncode:
                print(process.stdout, end='')
                print(process.stderr, end='', file=sys.stderr)
                raise SystemExit(process.returncode)
    measurements = json.loads((output / 'metrics.json').read_text())
    validation = json.loads((output / 'validation.json').read_text())
    review = json.loads((output / 'independent_review.json').read_text())
    hashes = {measurements['candidate']['sha256'], validation['checker_sha256'],
              review['checker_sha256'], sha256(candidate.read_bytes()).hexdigest()}
    if len(hashes) != 1:
        raise ValueError('Candidate changed during reproduction')
    if not (validation['all_pass'] and review['all_pass']
            and all(measurements['strictly_below_every_coordinate'].values())):
        raise ValueError('A recorded validation or comparison did not pass')
    receipt = {
        'all_pass': True,
        'checker_sha256': next(iter(hashes)),
        'pinned_commit': measurements['commit'],
        'current_programs': measurements['current_program_count'],
        'distinct_embedded_sources_including_roots': measurements['expanded_distinct_source_count'],
        'source_occurrences': measurements['expanded_path_count'],
        'current_coordinatewise_envelope': measurements['current_coordinatewise_minimum'],
        'candidate': {key: measurements['candidate'][key]
                      for key in ('normalized_tokens', 'ast_nodes', 'normalized_bytes')},
        'randomized_opening_checks': validation['randomized_openings']['cases'],
        'targeted_opening_checks': len(validation['targeted_openings']),
        'independent_canonicalization_checks': review['canonicalization_cases'],
        'fixed_packets': validation['fixed_packets'],
        'changed_fixed_outcomes': validation['changed_fixed_outcomes'],
        'example_packets': len(validation['examples']),
        'independent_directed_packets': review['directed_packet_cases'],
        'fixed_cli_runs_per_implementation': {row['program']: row['runs']
                                             for row in validation['full_script_fixed_cli']},
        'main_validation_cli_runs': validation['total_full_script_cli_runs'],
        'independent_review_cli_runs': review['cli_runs'],
        'total_cli_runs': validation['total_full_script_cli_runs'] + review['cli_runs'],
        'interpretation_of_counts': 'Repeated normal/-O and implementation runs are executions, not distinct mathematical facts.',
        'proof_status': 'Written metatheorems plus finite executable tests; not a Lean or Rocq formalization.'
    }
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
