"""Create or verify the self-contained deliverable archive."""
from pathlib import Path
import hashlib
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "SHA256SUMS.txt"


def payload():
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if not path.is_file() or path == MANIFEST:
            continue
        if "__pycache__" in relative.parts or path.suffix in {".pyc", ".aux", ".log", ".out", ".toc", ".fmt"}:
            continue
        if path.name.startswith("latex_pass_"):
            continue
        yield path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


if "--verify" in sys.argv:
    records = [line.split("  ", 1) for line in MANIFEST.read_text().splitlines()]
    for expected, name in records:
        if digest(ROOT / name) != expected:
            raise SystemExit("Hash mismatch: " + name)
    actual = {str(path.relative_to(ROOT)) for path in payload()}
    if actual != {name for _, name in records}:
        raise SystemExit("Payload membership differs from manifest")
    print(f"Verified {len(records)} delivered files.")
else:
    files = list(payload())
    MANIFEST.write_text("".join(f"{digest(path)}  {path.relative_to(ROOT)}\n" for path in files))
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in [*files, MANIFEST]:
            bundle.write(path, str(Path(ROOT.name) / path.relative_to(ROOT)))
    print(archive)
