"""Recompute all delivered comparison and validation evidence."""
from reproduce_checks import main

if __name__ == "__main__":
    main()
