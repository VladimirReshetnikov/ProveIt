#!/usr/bin/env python3
"""Regenerate exact outer-cone certificates for the two local abundance bounds.

Standard library only. Acceptance uses integer arithmetic and Fraction; decimals
are printed for convenience and never decide acceptance. Usage:
    python3 generate_cones.py --case both --output-dir data

The triples case rounds after a complete child update. The quadruples case
rounds after each child multiplication, using the nonnegative partial-message
coordinates (U, V-W, W). Every rounding replaces a normalized point by an
explicit triangle containing it. See the accompanying paper for the proof.
"""
from argparse import ArgumentParser
from fractions import Fraction
from math import gcd
from pathlib import Path
import json
import time

VERSION = 1
CASES = {
    "triples": dict(r=4, d=3, depth=11, K=10**6, rounding="complete",
                    abundance=Fraction(3239, 6250)),
    "quadruples": dict(r=4, d=4, depth=37, K=10**4, rounding="partial",
                       abundance=Fraction(5019, 10000)),
}


def determinant(p, q, r):
    return (p[0]*(q[1]*r[2]-q[2]*r[1])
            + p[1]*(q[2]*r[0]-q[0]*r[2])
            + p[2]*(q[0]*r[1]-q[1]*r[0]))


def normalized_key(v):
    s = sum(v)
    return Fraction(v[0], s), Fraction(v[1], s)


def in_polygon(poly, q):
    """Exact cone membership after normalizing by coordinate sum."""
    n = len(poly)
    if n == 1:
        return all(x*sum(q) == y*sum(poly[0])
                   for x, y in zip(poly[0], q))
    if n == 2:
        if determinant(poly[0], poly[1], q):
            return False
        return all(min(Fraction(p[i], sum(p)) for p in poly)
                   <= Fraction(q[i], sum(q))
                   <= max(Fraction(p[i], sum(p)) for p in poly)
                   for i in range(3))
    if (determinant(poly[0], poly[1], q) < 0
            or determinant(poly[0], poly[-1], q) > 0):
        return False
    lo, hi = 1, n-1
    while hi-lo > 1:
        mid = (lo+hi)//2
        if determinant(poly[0], poly[mid], q) >= 0:
            lo = mid
        else:
            hi = mid
    return determinant(poly[lo], poly[hi], q) >= 0


def hull(vectors):
    """Extreme rays of a positive cone, with exact containment validation."""
    unique = set()
    for ray in vectors:
        assert len(ray) == 3 and min(ray) >= 0
        z = gcd(*ray)
        if z:
            unique.add(tuple(a//z for a in ray))
    seq = sorted(unique, key=normalized_key)
    if len(seq) < 3:
        return tuple(seq)
    output = []
    for order in (seq, reversed(seq)):
        chain = []
        for v in order:
            while (len(chain) >= 2
                   and determinant(chain[-2], chain[-1], v) <= 0):
                chain.pop()
            chain.append(v)
        output.extend(chain[:-1])
    output = tuple(output)
    assert all(in_polygon(output, q) for q in seq)
    return output


def enclosing_triangle(v, K):
    """Grid rays of a triangle containing v/sum(v), with exact integer tests."""
    assert min(v) >= 0
    s = sum(v)
    if not s:
        return ()
    A, alpha = divmod(K*v[0], s)
    B, beta = divmod(K*v[1], s)
    if alpha+beta <= s:
        points = ((A, B), (A+1, B), (A, B+1))
        weights = (s-alpha-beta, alpha, beta)
    else:
        points = ((A+1, B+1), (A+1, B), (A, B+1))
        weights = (alpha+beta-s, s-beta, s-alpha)
    rays = tuple((a, b, K-a-b) for a, b in points)
    assert min(weights) >= 0 and sum(weights) == s
    assert all(sum(w*p[j] for w, p in zip(weights, rays)) == K*v[j]
               for j in range(3))
    assert all(min(p) >= 0 or w == 0 for w, p in zip(weights, rays))
    return tuple(p for p in rays if min(p) >= 0)


def complete_update(C, k, K):
    factors = tuple((b+c, a+b, b) for a, b, c in C)
    product_cone = ((1, 1, 1),)
    for _ in range(k):
        product_cone = hull(tuple(x*y for x, y in zip(p, q))
                            for p in product_cone for q in factors)
    messages = ((u, v-w, w) for u, v, w in product_cone)
    return hull(p for m in messages for p in enclosing_triangle(m, K))


def partial_update(C, k, K):
    # (A,B,C)=(U,V-W,W) for partial products; empty product gives (1,0,1).
    accumulator = ((1, 0, 1),)
    for _ in range(k):
        accumulator = hull(
            p
            for A, B, D in accumulator for a, b, c in C
            for p in enclosing_triangle(
                (A*(b+c), B*(a+b)+D*a, D*b), K))
    return accumulator


def diagonal_root_bound(C, r):
    return max(Fraction((b+c)**r,
                        (b+c)**r + (a+b)**r - b**r)
               for a, b, c in C)


def generate(name, output_dir):
    cfg = CASES[name]
    r, d, depth, K = (cfg[k] for k in ("r", "d", "depth", "K"))
    update = complete_update if cfg["rounding"] == "complete" else partial_update
    P = Q = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    history = []
    started = time.monotonic()
    for level in range(1, depth+1):
        if r == d:
            assert P == Q
            P = Q = update(P, r-1, K)
        else:
            P, Q = update(Q, r-1, K), update(P, d-1, K)
        bound = diagonal_root_bound(Q, r)
        history.append(dict(depth=level, P=P, G=Q,
                            root_max=[bound.numerator, bound.denominator]))
        print(f"{name}: level {level}/{depth}; rays {len(P)},{len(Q)}; "
              f"abundance >= {float(1-bound):.12f}", flush=True)
    abundance = cfg["abundance"]
    omission = 1-abundance
    assert bound <= omission
    # Independent form of the final test, with integer coefficients.
    numerator, denominator = omission.numerator, omission.denominator
    margins = [numerator*((a+b)**r-b**r)
               -(denominator-numerator)*(b+c)**r for a, b, c in Q]
    assert min(margins) > 0
    certificate = dict(version=VERSION, case=name, r=r, d=d, K=K,
                       rounding=cfg["rounding"], depth=depth,
                       target_abundance=[abundance.numerator, abundance.denominator],
                       history=history)
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"{name}_certificate.json"
    path.write_text(json.dumps(certificate, separators=(",", ":"))+"\n")
    print(f"PASS {name}: exact omission bound {bound}; "
          f"target abundance {abundance}; girth >= {2*depth+4}; "
          f"seconds {time.monotonic()-started:.2f}; {path}", flush=True)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=("triples", "quadruples", "both"),
                        default="both")
    parser.add_argument("--output-dir", type=Path, default=Path("data"))
    args = parser.parse_args()
    for name in (CASES if args.case == "both" else (args.case,)):
        generate(name, args.output_dir)


if __name__ == "__main__":
    main()
