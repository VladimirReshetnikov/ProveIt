#!/usr/bin/env python3
"""Independently verify an outer-cone certificate, using exact arithmetic only.

Usage:
    python3 verify_certificate.py CERTIFICATE.json [--report report.json]

This verifier does not import the certificate generator, reproduce its mesh
rounding, or use a floating-point convex hull.  It checks exact unrounded image
containments at every level.  Python -O does not disable any check.
"""
import argparse
import json
from fractions import Fraction
from math import gcd
from pathlib import Path


class CertificateError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise CertificateError(message)


def det(u, v, w):
    return (u[0] * (v[1] * w[2] - v[2] * w[1])
            - u[1] * (v[0] * w[2] - v[2] * w[0])
            + u[2] * (v[0] * w[1] - v[1] * w[0]))


def primitive(v):
    d = gcd(*v)
    return tuple(t // d for t in v) if d else None


def check_ray(v):
    require(isinstance(v, (list, tuple)) and len(v) == 3,
            "A ray must have three coordinates")
    require(all(type(t) is int and t >= 0 for t in v),
            "Ray coordinates must be nonnegative integers")
    require(sum(v) > 0, "A ray cannot be zero")


def inside_convex(poly, point):
    # Exact fan search; poly has counterclockwise, noncollinear consecutive
    # vertices in the plane a+b+c=1 (represented homogeneously).
    if det(poly[0], poly[1], point) < 0:
        return False
    if det(poly[0], poly[-1], point) > 0:
        return False
    left, right = 1, len(poly) - 1
    while right - left > 1:
        mid = (left + right) // 2
        if det(poly[0], poly[mid], point) >= 0:
            left = mid
        else:
            right = mid
    return det(poly[left], poly[right], point) >= 0


def hull(points):
    # Normalize to the plane a+b+c=1, sort by its first two coordinates,
    # and use exact determinants for the planar orientation tests.
    points = {primitive(p) for p in points}
    points.discard(None)
    require(bool(points), "Empty product cone")
    for p in points:
        check_ray(p)
    ordered = sorted(points, key=lambda p: (Fraction(p[0], sum(p)),
                                            Fraction(p[1], sum(p))))
    if len(ordered) <= 2:
        return ordered
    lower = []
    for p in ordered:
        while len(lower) >= 2 and det(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(ordered):
        while len(upper) >= 2 and det(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    polygon = lower[:-1] + upper[:-1]
    require(len(polygon) >= 2, "Invalid hull")
    if len(polygon) >= 3:
        require(det(polygon[0], polygon[1], polygon[2]) > 0,
                "Hull lacks a counterclockwise noncollinear triple")
        require(all(det(polygon[i - 1], polygon[i], polygon[(i + 1) % len(polygon)]) > 0
                    for i in range(len(polygon))), "Nonconvex computed hull")
        for p in points:
            require(inside_convex(polygon, p), "Hull omitted an input point")
    else:
        require(all(det(polygon[0], polygon[1], p) == 0 for p in points),
                "Two-ray hull omitted a noncollinear point")
    return polygon


def update_images(previous, arity):
    linear = [(b + c, a + b, b) for a, b, c in previous]
    partial = [(1, 1, 1)]
    for _ in range(arity):
        products = (tuple(x * y for x, y in zip(v, w))
                    for v in partial for w in linear)
        partial = hull(products)
    image = [(u, v - w, w) for u, v, w in partial]
    require(all(min(p) >= 0 for p in image), "Negative update coordinate")
    return image


def check_inclusion(images, outer, label):
    require(isinstance(outer, list) and len(outer) >= 3,
            label + ": outer cone must have at least three rays")
    for ray in outer:
        check_ray(ray)
    canonical = hull(outer)
    require(len(canonical) >= 3,
            label + ": outer cone is not full dimensional")
    require(det(canonical[0], canonical[1], canonical[2]) > 0,
            label + ": outer cone is not full dimensional")
    require([primitive(p) for p in outer] == canonical,
            label + ": certificate rays are not the canonical convex hull")
    for p in images:
        require(all(det(canonical[i - 1], canonical[i], p) >= 0
                    for i in range(len(canonical))),
                label + ": exact image ray is outside the certified cone: " + str(p))


def check_root_claim(rays, degree, recorded, label="root"):
    bound = max(Fraction((b + c) ** degree,
                         (b + c) ** degree + (a + b) ** degree - b ** degree)
                for a, b, c in rays)
    require(isinstance(recorded, list) and len(recorded) == 2
            and all(type(v) is int for v in recorded) and recorded[1] > 0,
            "Invalid recorded root bound at " + label)
    require(bound == Fraction(*recorded),
            "Recorded root bound disagrees with exact ray maximum at " + label)
    return bound


def check_root_cap(rays, degree, omission_cap):
    n, q = omission_cap.numerator, omission_cap.denominator
    for a, b, c in rays:
        numerator = (b + c) ** degree
        denominator = numerator + (a + b) ** degree - b ** degree
        require(q * numerator < n * denominator,
                "Certificate does not prove the requested strict omission cap")
        require((q - n) * (b + c) ** degree + n * b ** degree
                <= n * (a + b) ** degree,
                "Final weighted norm inequality failed")


def verify(data, omission_cap=Fraction(3011, 6250), verbose=False):
    require(isinstance(data, dict), "Certificate must be a JSON object")
    r, d = data.get("r"), data.get("d")
    require(type(r) is int and type(d) is int and r >= 2 and d >= 2,
            "Both incidence degrees must be integers at least two")
    history = data.get("history")
    require(isinstance(history, list) and bool(history), "Missing cone history")
    require(0 < omission_cap < 1, "Omission cap must lie strictly between zero and one")
    P = G = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
    output = []
    for number, row in enumerate(history, 1):
        require(isinstance(row, dict) and row.get("depth") == number,
                "Incorrect or missing depth number")
        Pimage = update_images(G, r - 1)
        Gimage = Pimage if r == d and P == G else update_images(P, d - 1)
        check_inclusion(Pimage, row.get("P"), "Depth %d point" % number)
        check_inclusion(Gimage, row.get("G"), "Depth %d generator" % number)
        P, G = row["P"], row["G"]
        bound = check_root_claim(G, r, row.get("root_max"),
                                 "depth %d" % number)
        output.append({"depth": number, "point_rays": len(P),
                       "generator_rays": len(G), "exact_point_images": len(Pimage),
                       "exact_generator_images": len(Gimage),
                       "frequency_lower_numerator": bound.denominator - bound.numerator,
                       "frequency_lower_denominator": bound.denominator})
        if verbose:
            print("Verified depth %d: %d point rays, %d generator rays" %
                  (number, len(P), len(G)), flush=True)
    check_root_cap(G, r, omission_cap)
    n, q = omission_cap.numerator, omission_cap.denominator
    lower = 1 - bound
    return {"status": "PASS", "point_degree": r, "generator_degree": d,
            "message_depth": len(history), "tree_ball_radius": len(history) + 1,
            "strict_frequency_lower_bound": [q - n, q],
            "exact_frequency_lower_bound": [lower.numerator, lower.denominator],
            "steps": output}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate", type=Path)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--omission-cap", default="3011/6250",
                        help="Exact rational requested omission cap (default 0.48176)")
    args = parser.parse_args()
    try:
        data = json.loads(args.certificate.read_text())
        result = verify(data, Fraction(args.omission_cap), verbose=True)
    except (CertificateError, KeyError, TypeError, ZeroDivisionError,
            json.JSONDecodeError, OSError) as exc:
        parser.exit(1, "FAIL: " + str(exc) + "\n")
    if args.report:
        args.report.write_text(json.dumps(result, indent=2) + "\n")
    num, den = result["exact_frequency_lower_bound"]
    print("PASS: exact frequency lower bound %d/%d" % (num, den))
    # Display only; all decisions above use integers and Fractions.
    print("Decimal approximation: %.16f" % float(Fraction(num, den)))


if __name__ == "__main__":
    main()
