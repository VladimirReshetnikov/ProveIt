#!/usr/bin/env python3
"""Focused mutation checks of the independent verification kernel."""
import argparse
from copy import deepcopy
from fractions import Fraction
import json
from pathlib import Path
from verify_certificate import (CertificateError, check_inclusion,
                                check_root_claim, check_root_cap, require)


def rejected(fn, label):
    try:
        fn()
    except CertificateError:
        print("PASS: rejected " + label)
        return
    raise RuntimeError("Failed to reject " + label)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate",type=Path)
    parser.add_argument("--omission-cap",default="3011/6250")
    args=parser.parse_args()
    data=json.loads(args.certificate.read_text())
    last=data["history"][-1]
    rays=last["G"]
    claim=last["root_max"]
    degree=data["r"]
    cap=Fraction(args.omission_cap)
    check_inclusion(rays,rays,"valid final polygon")
    check_root_claim(rays,degree,claim)
    check_root_cap(rays,degree,cap)
    malformed=deepcopy(rays)
    malformed[0]=[0,0,0]
    rejected(lambda:check_inclusion(rays,malformed,"mutated final polygon"),
             "a zero final certificate ray")
    rejected(lambda:check_inclusion([(1,1,1)],[[1,0,0],[1,1,0],[0,1,0]],
                                    "degenerate polygon"),
             "a full-dimensionality violation")
    understated=[claim[0]-1,claim[1]]
    rejected(lambda:check_root_claim(rays,degree,understated),
             "an understated recorded final root bound")
    impossible=Fraction(claim[0],claim[1])-Fraction(1,10**12)
    rejected(lambda:check_root_cap(rays,degree,impossible),
             "an understated requested omission cap")


if __name__=="__main__":main()
