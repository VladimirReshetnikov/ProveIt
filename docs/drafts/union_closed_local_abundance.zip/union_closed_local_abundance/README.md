# Every point above one half

**Two exact computer-assisted partial results for the union-closed sets conjecture.**

Prepared for Vladimir Reshetnikov, November 25, 2026.

## The results

Take all **distinct unions**, including the empty union, of a finite collection of generators. The incidence graph has a vertex for every point, a vertex for every generator, and an edge for membership. Assume each point lies in exactly four generators.

| Generator size | Minimum incidence girth | Guaranteed frequency of every point |
|---|---:|---:|
| Four | 78 | Strictly greater than 0.5019 |
| Three | 26 | Strictly greater than 0.51824 |

The exact certified lower bounds are, respectively:

* `231030546175451 / 460246542869612 = 0.5019712798601119...`
* `58188008459104285410301 / 112278432054527250720426 = 0.5182474264589452...`

The paper proves a stronger local statement. Only the radius-38 or radius-12 incidence ball around the specified point needs the prescribed tree structure. The bound persists after any feasible conditioning on union membership outside that neighborhood, including the boundary. The membership indicators at sufficiently separated points therefore stochastically dominate independent biased coins. Further consequences are lower-tail bounds for union size and an all-vertex maximal-independent-set theorem for arbitrary 4-regular graphs of girth at least 78.

The four-element result is the principal proposed new restricted case. The existence of some abundant point for triple-generated families was already known; the triple result strengthens the conclusion to every point with a uniform strict surplus. The certificate method is credited to a preceding degree-three high-girth research note. Exact predecessor statements were not found in the reviewed literature or the twelve ProveIt draft archives. Historical priority remains provisional.

**Scope:** this does not settle the full conjecture or improve an unrestricted universal constant. The girth assumptions are strong and have not been optimized. Globally regular examples have at least 2,026,277,576,509,488,133 ground points in the four-element case, and 74,649 in the triple case. The paper gives a classical constructive existence proof for arbitrarily large connected examples. These are mathematical structural theorems, not enumeration of families of manageable size.

## Read the paper

`paper.pdf` contains the full mathematical argument and proof-status discussion.

`paper.tex` is the main source and includes `local_bounds.tex`, `probability.tex`, and `nonvacuity.tex`. Keep these source files together when compiling.

## Verify the finite proof

Requirements: Python 3.9 or later; standard library only. No package installation, network connection, numerical solver, or floating-point geometry library is required.

From this directory:

```bash
python3 code/verify_certificate.py certificates/quadruples_certificate.json \
  --omission-cap 4981/10000 --report verification/quadruples_check.json

python3 code/verify_certificate.py certificates/triples_certificate.json \
  --omission-cap 3011/6250 --report verification/triples_check.json
```

The independently written verifier checks exact unrounded recurrence-image containment at all 37 or 11 levels, then verifies the final rational probability bound. It imports no generator code and does not assume that the mesh-rounding algorithm is correct. Geometry uses integer determinants and exact rational sorting. Decimals are displayed only after acceptance.

The verifier prints `PASS` and exits with status zero on success. An unsupported claim exits with nonzero status. Its validation uses explicit checks and remains active under `python3 -O`.

Focused negative checks:

```bash
python3 -O code/test_certificate_rejection.py certificates/triples_certificate.json
python3 -O code/test_certificate_rejection.py certificates/quadruples_certificate.json \
  --omission-cap 4981/10000
```

These deliberately introduce a zero ray, a degenerate cone, an understated recorded bound, and an unsupported requested cap. All must be rejected.

## Regenerate the certificates

```bash
python3 code/generate_cones.py --case both --output-dir regenerated
```

Run the verifier on the two resulting JSON files using the same omission caps. The archive also includes per-level CSV summaries. In the preparation environment, generation took about 2 seconds for triples and 201 seconds for quadruples; timing depends on the machine. The clean certificates were checked against the independently audited versions in every normalized ray and every recorded fraction.

The program uses a simplex grid with denominator 1,000,000 for triples and 10,000 for quadruples. Rounding is outward and is justified by exact nonnegative barycentric coefficients. The quadruple construction also rounds after individual child products using a nonnegative bilinear version of the recurrence.

## Compile the PDF

Use a normal TeX Live or MiKTeX installation providing the packages named in `paper.tex`:

```bash
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
```

The delivered PDF was compiled from these sources and visually reviewed. The proof is computer-assisted with exact arithmetic; it has not been formalized in Lean or Rocq.

## Contents and provenance

* `certificates/`: complete rational ray certificates, not samples of states.
* `code/`: standalone certificate generator, independent verifier, and negative checks.
* `verification/`: successful reports, per-level CSV tables, mathematical audit, literature audit, source archive inventory, and compilation/validation details.
* `MANIFEST.sha256`: SHA-256 digests of the delivered files, excluding the manifest itself.

The supplied ProveIt drafts were read at commit `986dce91ff909ef94b12bb9553e22a719887168d`. The exact twelve input archive names and hashes are in `verification/prior_drafts.json`. No prior draft archive is redistributed here.
