#!/usr/bin/env python3
"""Rebuild the new checks, optional Lean kernels, and research PDF."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(command: list[str], log_name: str) -> dict:
    result = subprocess.run(command, cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (ROOT / "verification" / log_name).write_text(result.stdout)
    if result.returncode:
        print(result.stdout, file=sys.stderr)
        raise RuntimeError(f"Command failed with status {result.returncode}: {command}")
    return {"command": command, "exit_code": result.returncode, "log": log_name}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--checks-only", action="store_true")
    modes.add_argument("--pdf-only", action="store_true")
    parser.add_argument("--lean", help="Optional path to a Lean 4.19.0 executable")
    args = parser.parse_args()
    (ROOT / "verification").mkdir(exist_ok=True)
    records: list[dict] = []
    if not args.pdf_only:
        for script in ("check_syntax.py", "check_computation_models.py"):
            records.append(run([sys.executable, "code/" + script],
                               script.removesuffix(".py") + ".log"))
        records.append(run([sys.executable, "code/emit.py",
                            "code/examples/boundary.json"],
                           "emitted_boundary.json"))
        records.append(run([sys.executable, "code/emit.py",
                            "code/examples/computation.json"],
                           "emitted_computation.json"))
        if args.lean:
            lean = str(Path(args.lean).resolve())
            records.append(run([lean, "--version"], "lean_rebuild_version.log"))
            for name in ("BoundaryK", "ComputationK"):
                records.append(run([lean, f"proofs/{name}.lean"],
                                   f"{name}_rebuild.log"))
    if not args.checks_only:
        compiler = shutil.which("pdflatex")
        if compiler is None:
            raise RuntimeError("pdflatex is required for the PDF build")
        output = ROOT / "_build"
        output.mkdir(exist_ok=True)
        command = [compiler, "-no-shell-escape", "-interaction=nonstopmode",
                   "-halt-on-error", "-output-directory=_build", "report.tex"]
        for pass_number in range(1, 4):
            records.append(run(command, f"latex_pass_{pass_number}.log"))
        shutil.copyfile(output / "report.pdf", ROOT / "report.pdf")
        final_log = (output / "report.log").read_text(errors="replace")
        problems = [line for line in final_log.splitlines()
                    if "Overfull" in line or "undefined references" in line
                    or ("Citation" in line and "undefined" in line)]
        if problems:
            raise RuntimeError("PDF requires review: " + "\n".join(problems))
        records.append({"pdf_sha256": hashlib.sha256(
            (ROOT / "report.pdf").read_bytes()).hexdigest(),
            "layout_warning_check": "passed"})
    summary = {"status": "passed", "records": records,
               "full_biinterpretation_formalized": False,
               "note": "Visual PDF review is separate from successful compilation."}
    (ROOT / "verification" / "latest_build.json").write_text(
        json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"status": "passed", "operations": len(records),
                      "pdf_built": not args.checks_only,
                      "lean_rechecked": bool(args.lean) and not args.pdf_only}))


if __name__ == "__main__":
    main()
