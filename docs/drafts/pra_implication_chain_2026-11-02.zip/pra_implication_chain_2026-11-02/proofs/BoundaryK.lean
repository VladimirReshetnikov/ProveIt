/-
  Constructive local kernels for implication-chain boundary arithmetic.
  Lean 4.19.0, Std only.

  Scope: boundary-to-induction, the omitted smallest equations, the omitted
  coverage equation, and a natural-number witness scan. This is not a
  formalization of the staged syntax, arithmetic bootstrap, PR compiler,
  or full first-order bi-interpretation theorem.
-/
import Std

namespace BoundaryK

/-- The logical connective is an explicit conservative definition. -/
def K (A B C : Prop) : Prop := (B → A) ∧ (A → C)

theorem k_and (A B : Prop) : K A True B ↔ (A ∧ B) := by
  constructor
  · intro h
    have ha : A := h.1 True.intro
    exact ⟨ha, h.2 ha⟩
  · intro h
    exact ⟨fun _ => h.1, fun _ => h.2⟩

theorem k_imp (A B : Prop) : K A False B ↔ (A → B) := by
  exact ⟨fun h => h.2, fun h => ⟨False.elim, h⟩⟩

variable {α : Type} (zero : α) (succ : α → α)

/-- Constructor coverage is a separate hypothesis. -/
def Coverage : Prop := ∀ z, z = zero ∨ ∃ y, z = succ y

/-- The predecessor boundary at target `n` with witness `b`. -/
def PredBoundary (P : α → Prop) (n b : α) : Prop :=
  ∀ x, K (P x) (succ x = b) (x = b → b = n)

/-- Full induction, with the base and progress retained as hypotheses. -/
theorem boundary_induction (P : α → Prop)
    (cover : Coverage zero succ)
    (witness : ∀ n, ∃ b, PredBoundary succ P n b)
    (base : P zero) (progress : ∀ x, P x → P (succ x)) :
    ∀ n, P n := by
  intro n
  obtain ⟨b, hb⟩ := witness n
  have hpb : P b := by
    cases cover b with
    | inl hz => exact hz.symm ▸ base
    | inr hs =>
      obtain ⟨y, hy⟩ := hs
      have hpy : P y := (hb y).1 hy.symm
      exact hy.symm ▸ progress y hpy
  have hbn : b = n := (hb b).2 hpb rfl
  exact hbn ▸ hpb

/-- Induction for `x = a` follows from separation alone. -/
theorem leaf_right_induction (separate : zero ≠ succ zero) (a : α)
    (base : zero = a) (progress : ∀ x, x = a → succ x = a) :
    ∀ n, n = a := by
  have hs : succ zero = a := progress zero base
  exact False.elim (separate (base.trans hs.symm))

/-- Induction for `a = x` is the symmetric omission. -/
theorem leaf_left_induction (separate : zero ≠ succ zero) (a : α)
    (base : a = zero) (progress : ∀ x, a = x → a = succ x) :
    ∀ n, a = n := by
  have hs : a = succ zero := progress zero base
  exact False.elim (separate (base.symm.trans hs))

theorem zero_right_induction (separate : zero ≠ succ zero)
    (base : zero = zero)
    (progress : ∀ x, x = zero → succ x = zero) :
    ∀ n, n = zero :=
  leaf_right_induction zero succ separate zero base progress

theorem zero_left_induction (separate : zero ≠ succ zero)
    (base : zero = zero)
    (progress : ∀ x, zero = x → zero = succ x) :
    ∀ n, zero = n :=
  leaf_left_induction zero succ separate zero base progress

theorem reflexive_induction : ∀ n : α, n = n := fun _ => rfl

/-- The atomic coverage equation from the earlier bare architecture. -/
def CoverageEquation (Q : α → α → α) (x : α) : Prop :=
  x = succ (Q x zero)

section CounterProjection

variable (Q : α → α → α)
variable (qzero : ∀ a, Q zero a = a)
variable (qsucc : ∀ n a, Q (succ n) a = n)
variable (separate : zero ≠ succ zero)

include Q qzero qsucc separate in
theorem successor_ne_zero (x : α) : succ x ≠ zero := by
  intro hx
  have he : x = zero := by
    calc
      x = Q (succ x) zero := (qsucc x zero).symm
      _ = Q zero zero := congrArg (fun z => Q z zero) hx
      _ = zero := qzero zero
  have hs : succ zero = zero := by
    calc
      succ zero = succ x := congrArg succ he.symm
      _ = zero := hx
  exact separate hs.symm

include qzero separate in
theorem coverage_equation_false_at_zero :
    ¬ CoverageEquation zero succ Q zero := by
  intro h
  have he : zero = succ zero := by
    calc
      zero = succ (Q zero zero) := h
      _ = succ zero := congrArg succ (qzero zero)
  exact separate he

include qzero separate in
/-- Its induction implication is already immediate from its false base. -/
theorem coverage_equation_induction
    (base : CoverageEquation zero succ Q zero)
    (_progress : ∀ x, CoverageEquation zero succ Q x →
      CoverageEquation zero succ Q (succ x)) :
    ∀ n, CoverageEquation zero succ Q n := by
  exact False.elim
    (coverage_equation_false_at_zero zero succ Q qzero separate base)

include qzero qsucc separate in
/-- Its whole predecessor clause has witness zero, without coverage. -/
theorem coverage_equation_boundary (n : α) :
    PredBoundary succ (CoverageEquation zero succ Q) n zero := by
  intro x
  constructor
  · intro hs
    exact False.elim
      (successor_ne_zero zero succ Q qzero qsucc separate x hs)
  · intro he hx
    have hz : CoverageEquation zero succ Q zero := hx ▸ he
    exact False.elim
      (coverage_equation_false_at_zero zero succ Q qzero separate hz)

include qzero qsucc separate in
theorem coverage_equation_witness :
    ∀ n, ∃ b, PredBoundary succ (CoverageEquation zero succ Q) n b := by
  intro n
  exact ⟨zero, coverage_equation_boundary zero succ Q qzero qsucc separate n⟩

end CounterProjection

section NaturalNumberScan

variable (P : Nat → Prop) [DecidablePred P]

/-- For a fixed PR predicate this recursion is a PR scanner. -/
def scan : Nat → Nat
  | 0 => 0
  | Nat.succ n => if P (scan n) then Nat.succ n else scan n

/-- The proof needs no leastness or order claim about the witness. -/
theorem scan_invariant (n : Nat) :
    (scan P n = 0 ∨ P (Nat.pred (scan P n))) ∧
    (P (scan P n) → scan P n = n) := by
  induction n with
  | zero =>
    change (0 = 0 ∨ P (Nat.pred 0)) ∧ (P 0 → 0 = 0)
    exact ⟨Or.inl rfl, fun _ => rfl⟩
  | succ n ih =>
    by_cases hp : P (scan P n)
    · have he : scan P n = n := ih.2 hp
      have hn : P n := he ▸ hp
      change
        ((if P (scan P n) then Nat.succ n else scan P n) = 0 ∨
          P (Nat.pred (if P (scan P n) then Nat.succ n else scan P n))) ∧
        (P (if P (scan P n) then Nat.succ n else scan P n) →
          (if P (scan P n) then Nat.succ n else scan P n) = Nat.succ n)
      rw [if_pos hp]
      exact ⟨Or.inr hn, fun _ => rfl⟩
    · change
        ((if P (scan P n) then Nat.succ n else scan P n) = 0 ∨
          P (Nat.pred (if P (scan P n) then Nat.succ n else scan P n))) ∧
        (P (if P (scan P n) then Nat.succ n else scan P n) →
          (if P (scan P n) then Nat.succ n else scan P n) = Nat.succ n)
      rw [if_neg hp]
      exact ⟨ih.1, fun h => False.elim (hp h)⟩

theorem scan_boundary (n : Nat) :
    PredBoundary Nat.succ P n (scan P n) := by
  have inv := scan_invariant P n
  intro x
  constructor
  · intro hs
    cases inv.1 with
    | inl hz => exact False.elim (Nat.noConfusion (hs.trans hz))
    | inr hp =>
      have he : Nat.pred (scan P n) = x := by
        calc
          Nat.pred (scan P n) = Nat.pred (Nat.succ x) :=
            congrArg Nat.pred hs.symm
          _ = x := rfl
      exact he ▸ hp
  · intro hp hx
    exact inv.2 (hx ▸ hp)

theorem scan_witness : ∀ n, ∃ b, PredBoundary Nat.succ P n b := by
  intro n
  exact ⟨scan P n, scan_boundary P n⟩

end NaturalNumberScan

-- These commands report the actual axioms used by the local checked proofs.
#print axioms k_and
#print axioms k_imp
#print axioms boundary_induction
#print axioms leaf_right_induction
#print axioms leaf_left_induction
#print axioms zero_right_induction
#print axioms zero_left_induction
#print axioms reflexive_induction
#print axioms successor_ne_zero
#print axioms coverage_equation_false_at_zero
#print axioms coverage_equation_induction
#print axioms coverage_equation_boundary
#print axioms coverage_equation_witness
#print axioms scan_invariant
#print axioms scan_boundary
#print axioms scan_witness

end BoundaryK
