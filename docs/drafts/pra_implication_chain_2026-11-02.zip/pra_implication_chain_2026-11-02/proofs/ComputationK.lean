/- Constructive local computation kernels for arbitrary types and operations.
   This file checks local module equivalences, not the full PRA interpretation. -/

universe u

def chainK (A B C : Prop) : Prop := (B → A) ∧ (A → C)

theorem computation_graphK_iff {α : Type u}
    (zero : α) (succ : α → α) (rec : α → α → α) (step : α → α → α) :
    ((∀ a, rec zero a = a) ∧
      (∀ a n, rec (succ n) a = step (rec n a) n)) ↔
    (∀ a n v, chainK (rec n a = v) (n = zero ∧ v = a)
      (rec (succ n) a = step v n)) := by
  constructor
  · rintro ⟨base, next⟩ a n v
    constructor
    · rintro ⟨atZero, value⟩
      simpa only [atZero, value] using base a
    · intro value
      simpa only [value] using next a n
  · intro graph
    constructor
    · intro a
      exact (graph a zero a).1 ⟨rfl, rfl⟩
    · intro a n
      exact (graph a n (rec n a)).2 rfl

theorem computation_endpointK_iff {α : Type u}
    (zero : α) (succ : α → α) (rec : α → α → α) (step : α → α → α) :
    ((∀ a, rec zero a = a) ∧
      (∀ a n, rec (succ n) a = step (rec n a) n)) ↔
    (∀ a n, ∃ v, (n = zero → v = a) ∧
      ∀ x y, chainK (rec x a = y) (x = n ∧ y = v)
        (x = succ n → y = step v n)) := by
  constructor
  · rintro ⟨base, next⟩ a n
    refine ⟨rec n a, ?_, ?_⟩
    · intro atZero
      simpa only [atZero] using base a
    · intro x y
      constructor
      · rintro ⟨rfl, rfl⟩
        rfl
      · intro value atNext
        subst x
        exact value.symm.trans (next a n)
  · intro endpoint
    constructor
    · intro a
      rcases endpoint a zero with ⟨v, initial, graph⟩
      exact ((graph zero v).1 ⟨rfl, rfl⟩).trans (initial rfl)
    · intro a n
      rcases endpoint a n with ⟨v, _, graph⟩
      have current : rec n a = v := (graph n v).1 ⟨rfl, rfl⟩
      have next : rec (succ n) a = step v n :=
        (graph (succ n) (rec (succ n) a)).2 rfl rfl
      exact next.trans (congrArg (fun z => step z n) current.symm)

#print axioms computation_graphK_iff
#print axioms computation_endpointK_iff
