#!/usr/bin/env python3
"""Emit a literal optimized K boundary or complete computation module.

JSON terms are strings "0", "x", "a", "v", "w"; ["S", term]; or
["R", frozen_descriptor, counter, initial]. No expression is evaluated.
Boundary input: {"mode": "boundary", "equation": [left, right]}.
Computation input: {"mode": "computation", "descriptor": term}.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from check_syntax import (
    Node, ZERO, active_occurrences, active_size, active_variables,
    boundary_modules, computation_modules, equation, full_size,
    omission_reason, recursor, serialize, successor, var,
)


def term(data: object, allowed: set[str]) -> Node:
    if isinstance(data, str):
        if data == "0":
            return ZERO
        if data in allowed:
            return var(data)
        raise ValueError(f"Unknown or out-of-scope variable: {data}")
    if not isinstance(data, list) or not data:
        raise ValueError("A term must be an allowed string or a constructor list")
    if data[0] == "S" and len(data) == 2:
        return successor(term(data[1], allowed))
    if data[0] == "R" and len(data) == 4:
        body = term(data[1], {"v", "w"})
        return recursor(body, term(data[2], allowed), term(data[3], allowed))
    raise ValueError("Invalid term constructor or arity")


def emit(data: dict) -> dict:
    mode = data.get("mode")
    if mode == "boundary":
        operands = data.get("equation")
        if not isinstance(operands, list) or len(operands) != 2:
            raise ValueError("An equation needs exactly two term operands")
        atom = equation(*(term(item, {"x", "a"}) for item in operands))
        reason = omission_reason(atom)
        result = {"mode": mode, "equation": serialize(atom),
                  "F": full_size(atom), "active_size": active_size(atom),
                  "active_x_occurrences": active_occurrences(atom, "x"),
                  "omission_reason": reason}
        if reason is not None:
            result.update({"chosen": "omitted", "full_cost": 0, "axioms": []})
        else:
            formula = boundary_modules(atom)["K_positive"]
            result.update({"chosen": "KB", "full_cost": full_size(formula),
                           "axioms": [serialize(formula)]})
        result["required_fixed_support"] = {
            "Sep": 6, "Cov": 10, "K_definition": 12,
            "recursion_modules": "Add all used frozen descriptors and dependencies"}
        return result
    if mode == "computation":
        body = term(data.get("descriptor"), {"v", "w"})
        if not active_variables(body).issubset({"v", "w"}):
            raise ValueError("The descriptor captures an extra parameter")
        modules = computation_modules(body)
        choices = ("D", "G_K", "T_K")
        sizes = {key: sum(full_size(f) for f in modules[key]) for key in choices}
        chosen = min(choices, key=lambda key: sizes[key])
        return {"mode": mode, "descriptor": serialize(body),
                "H": full_size(body), "active_size": active_size(body),
                "active_state_occurrences": active_occurrences(body, "v"),
                "candidate_full_costs": sizes, "chosen": chosen,
                "full_cost": sizes[chosen],
                "axioms": [serialize(f) for f in modules[chosen]],
                "tie_order": list(choices),
                "support_note": "K's generic definition is charged once when used; "
                                "earlier descriptor modules are additional."}
    raise ValueError("mode must be boundary or computation")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text())
    if not isinstance(data, dict):
        raise ValueError("Top-level input must be an object")
    print(json.dumps(emit(data), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
