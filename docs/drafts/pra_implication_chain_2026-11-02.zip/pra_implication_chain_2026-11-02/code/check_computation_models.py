#!/usr/bin/env python3
"""Finite model diagnostic for the two computation-module equivalences.

Enumerates every structure of cardinalities one and two with an arbitrary
distinguished element, unary successor, and two arbitrary binary operations.
This is a supplementary classical semantic check; the constructive theorems
are proved separately in proofs/ComputationK.lean and in the paper.
"""

from __future__ import annotations

import argparse
from itertools import product
import json
from pathlib import Path


def implies(antecedent: bool, consequent: bool) -> bool:
    return not antecedent or consequent


def chain(first: bool, second: bool, third: bool) -> bool:
    return implies(second, first) and implies(first, third)


def audit() -> dict:
    totals = []
    for cardinality in (1, 2):
        values = tuple(range(cardinality))
        examined = satisfying = fixed_point_structures = noninjective_structures = 0
        for zero in values:
            for successor in product(values, repeat=cardinality):
                has_fixed_point = any(successor[n] == n for n in values)
                noninjective = len(set(successor)) < cardinality
                for rec_table in product(values, repeat=cardinality * cardinality):
                    def rec(n: int, a: int) -> int:
                        return rec_table[n * cardinality + a]

                    for update_table in product(values, repeat=cardinality * cardinality):
                        def update(state: int, counter: int) -> int:
                            return update_table[state * cardinality + counter]

                        defining_equations = (
                            all(rec(zero, a) == a for a in values) and
                            all(rec(successor[n], a) == update(rec(n, a), n)
                                for a in values for n in values))
                        current_graph = all(
                            chain(rec(n, a) == u, n == zero and u == a,
                                  rec(successor[n], a) == update(u, n))
                            for a in values for n in values for u in values)
                        endpoint_graph = all(
                            any(implies(n == zero, u == a) and
                                all(chain(rec(x, a) == y, x == n and y == u,
                                          implies(x == successor[n], y == update(u, n)))
                                    for x in values for y in values)
                                for u in values)
                            for a in values for n in values)
                        if not (defining_equations == current_graph == endpoint_graph):
                            raise RuntimeError(json.dumps({
                                "cardinality": cardinality, "zero": zero,
                                "successor": successor, "rec_table": rec_table,
                                "update_table": update_table,
                                "D": defining_equations, "G_K": current_graph,
                                "T_K": endpoint_graph}))
                        examined += 1
                        satisfying += int(defining_equations)
                        fixed_point_structures += int(has_fixed_point)
                        noninjective_structures += int(noninjective)
        expected = (cardinality * cardinality ** cardinality *
                    cardinality ** (2 * cardinality * cardinality))
        if examined != expected:
            raise RuntimeError("The enumeration did not cover every advertised structure")
        totals.append({"cardinality": cardinality, "structures": examined,
                       "satisfying_all_three_modules": satisfying,
                       "falsifying_all_three_modules": examined - satisfying,
                       "structures_with_successor_fixed_points": fixed_point_structures,
                       "structures_with_noninjective_successor": noninjective_structures})
    return {
        "status": "passed", "structures_checked": sum(r["structures"] for r in totals),
        "per_cardinality": totals,
        "modules": ["ordinary defining equations D", "current graph G_K",
                    "single-occurrence endpoint graph T_K"],
        "assumptions_imposed": [],
        "scope": "Exhaustive finite classical semantics at cardinalities one and two. "
                 "No extrapolation to all structures or intuitionistic semantics is made "
                 "from this finite check; the separate constructive proofs establish "
                 "the unrestricted equivalences.",
        "not_a_verification_of": ["The full PRA theory", "The arithmetic compiler",
                                   "Bi-interpretability", "Global minimality"]}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] /
                        "verification" / "computation_model_results.json")
    args = parser.parse_args()
    result = audit()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": result["status"],
                      "structures_checked": result["structures_checked"],
                      "scope": "Supplementary finite semantic diagnostic",
                      "output": str(args.output)}, sort_keys=True))


if __name__ == "__main__":
    main()
