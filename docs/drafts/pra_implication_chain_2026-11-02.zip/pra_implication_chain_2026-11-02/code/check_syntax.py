#!/usr/bin/env python3
"""Literal syntax accounting for the implication-chain PRA presentation.

This is an executable syntax/size audit, not a proof checker for PRA or
bi-interpretability. Stored recursion descriptors are frozen under active
substitution and are charged at every occurrence in the full-tree metric.
All checks use explicit exceptions, so Python -O does not disable them.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Iterable, Mapping


@dataclass(frozen=True)
class Node:
    kind: str
    children: tuple["Node", ...] = ()
    name: str = ""
    descriptor: "Node | None" = None


def var(name: str) -> Node:
    return Node("var", name=name)


ZERO = Node("const", name="0")
BOTTOM = Node("bottom")


def successor(term: Node) -> Node:
    return Node("S", (term,))


def active_variables(node: Node) -> set[str]:
    if node.kind == "var":
        return {node.name}
    result: set[str] = set()
    for child in node.children:
        result.update(active_variables(child))
    if node.kind in {"forall", "exists"}:
        result.discard(node.name)
    return result


def recursor(descriptor: Node, counter: Node, initial: Node) -> Node:
    if not active_variables(descriptor).issubset({"v", "w"}):
        raise ValueError("A recursion descriptor captures a numerical parameter")
    return Node("R", (counter, initial), descriptor=descriptor)


def binary(kind: str, left: Node, right: Node) -> Node:
    return Node(kind, (left, right))


def equation(left: Node, right: Node) -> Node:
    return binary("=", left, right)


def conjunction(left: Node, right: Node) -> Node:
    return binary("and", left, right)


def disjunction(left: Node, right: Node) -> Node:
    return binary("or", left, right)


def implication(left: Node, right: Node) -> Node:
    return binary("implies", left, right)


def negate(formula: Node) -> Node:
    return implication(formula, BOTTOM)


def ternary(kind: str, first: Node, second: Node, third: Node) -> Node:
    return Node(kind, (first, second, third))


def quantify(kind: str, names: Iterable[str], formula: Node) -> Node:
    result = formula
    for name in reversed(tuple(names)):
        result = Node(kind, (result,), name=name)
    return result


def full_size(node: Node) -> int:
    frozen = full_size(node.descriptor) if node.descriptor is not None else 0
    return 1 + frozen + sum(full_size(child) for child in node.children)


def active_size(node: Node) -> int:
    return 1 + sum(active_size(child) for child in node.children)


def active_occurrences(node: Node, variable: str) -> int:
    if node.kind == "var":
        return int(node.name == variable)
    if node.kind in {"forall", "exists"} and node.name == variable:
        return 0
    return sum(active_occurrences(child, variable) for child in node.children)


def substitute_active(node: Node, replacements: Mapping[str, Node]) -> Node:
    """Substitute in a term or unbound formula, never its stored descriptors.

    This audit constructs binders only after substitution. Rejecting a binder
    here makes accidental capture an explicit error instead of silently
    performing a potentially unsound formula substitution.
    """
    if node.kind == "var":
        return replacements.get(node.name, node)
    if node.kind in {"forall", "exists"}:
        raise ValueError("Perform active substitution before adding binders")
    return Node(node.kind,
                tuple(substitute_active(c, replacements) for c in node.children),
                node.name, node.descriptor)


def serialize(node: Node) -> str:
    if node.kind in {"var", "const"}:
        return node.name
    if node.kind == "bottom":
        return "false"
    if node.kind == "R":
        if node.descriptor is None:
            raise ValueError("Missing recursion descriptor")
        return "R[" + serialize(node.descriptor) + "](" + ",".join(
            serialize(c) for c in node.children) + ")"
    if node.kind in {"forall", "exists"}:
        return "(" + node.kind + " " + node.name + " " + serialize(
            node.children[0]) + ")"
    return "(" + node.kind + " " + " ".join(serialize(c) for c in node.children) + ")"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def computation_modules(body: Node) -> dict[str, tuple[Node, ...]]:
    a, n, u, x, y = map(var, ("a", "n", "u", "x", "y"))
    current = recursor(body, n, a)
    update = substitute_active(body, {"v": u, "w": n})
    next_value = recursor(body, successor(n), a)
    initial = implication(equation(n, ZERO), equation(u, a))
    graph = equation(recursor(body, x, a), y)
    first = implication(equation(x, n), equation(y, u))
    second = implication(equation(x, successor(n)), equation(y, update))
    base = quantify("forall", ["a"], equation(recursor(body, ZERO, a), a))
    step = quantify("forall", ["a", "n"], equation(
        next_value, substitute_active(body, {"v": current, "w": n})))
    old_g = quantify("forall", ["a", "n", "u"], implication(
        equation(current, u), conjunction(initial, equation(next_value, update))))
    new_g = quantify("forall", ["a", "n", "u"], ternary(
        "K", equation(current, u),
        conjunction(equation(n, ZERO), equation(u, a)),
        equation(next_value, update)))
    old_t = quantify("forall", ["a", "n"], quantify("exists", ["u"],
        conjunction(initial, quantify("forall", ["x", "y"],
            implication(graph, conjunction(first, second))))))
    new_t = quantify("forall", ["a", "n"], quantify("exists", ["u"],
        conjunction(initial, quantify("forall", ["x", "y"], ternary(
            "K", graph, conjunction(equation(x, n), equation(y, u)), second)))))
    return {"D": (base, step), "G_old": (old_g,), "T_old": (old_t,),
            "G_K": (new_g,), "T_K": (new_t,)}


def boundary_modules(atom: Node) -> dict[str, Node]:
    require(atom.kind == "=", "A boundary index must be an equation")
    require(active_variables(atom).issubset({"x", "a"}),
            "A boundary index has an unexpected active parameter")
    x, b, n = map(var, ("x", "b", "n"))
    at_b = substitute_active(atom, {"x": b})
    at_next = substitute_active(atom, {"x": successor(b)})
    b_zero = equation(b, ZERO)
    b_n = equation(b, n)
    old_direct = conjunction(disjunction(b_zero, at_b), implication(at_next, b_n))
    j_direct = ternary("J", at_b, b_zero, implication(at_next, b_n))
    j_universal = ternary("J", atom,
        implication(equation(x, b), b_zero),
        implication(equation(x, successor(b)), b_n))
    predecessor = equation(successor(x), b)
    endpoint = implication(equation(x, b), b_n)
    k_positive = ternary("K", atom, predecessor, endpoint)
    k_negative = ternary("K", negate(atom), predecessor, endpoint)
    strong_predecessor = ternary("If", atom, endpoint, negate(predecessor))
    result = {}
    for name, matrix in [("D_native", old_direct), ("D_J", j_direct),
                         ("U_J", j_universal), ("K_positive", k_positive),
                         ("K_negative", k_negative),
                         ("If_predecessor", strong_predecessor)]:
        if name not in {"D_native", "D_J"}:
            matrix = quantify("forall", ["x"], matrix)
        result[name] = quantify("forall", ["a", "n"],
                               quantify("exists", ["b"], matrix))
    return result


def coverage_atom() -> Node:
    x = var("x")
    return equation(x, successor(recursor(var("w"), x, ZERO)))


def omission_reason(atom: Node) -> str | None:
    require(atom.kind == "=", "The omission classifier expects an equation")
    if active_occurrences(atom, "x") == 0:
        return "no_active_induction_variable"
    left, right = atom.children
    if left == right:
        return "literal_reflexivity"
    x, a = var("x"), var("a")
    if (left, right) in {(x, ZERO), (ZERO, x), (x, a), (a, x)}:
        return "four_leaf_equations"
    cov = coverage_atom()
    if atom == cov or atom == equation(cov.children[1], cov.children[0]):
        return "explicit_coverage_replacement"
    return None


def descriptors_in(node: Node) -> set[Node]:
    found: set[Node] = set()
    if node.descriptor is not None:
        found.add(node.descriptor)
        found.update(descriptors_in(node.descriptor))
    for child in node.children:
        found.update(descriptors_in(child))
    return found


def old_boundary_cost(atom: Node, presentation: str) -> int:
    F = full_size(atom)
    i = active_occurrences(atom, "x")
    X, Y = map(full_size, atom.children)
    if presentation == "J":
        return min(2 * F + i + 11, F + 20)
    if presentation == "ordinary_native":
        return min(2 * F + i + 12, 2 * F + 18, F + 29 + min(X, Y, 6))
    if presentation == "covered_If":
        return min(2 * F + i + 12, F + 18)
    raise ValueError("Unknown old presentation")


def packet_comparison(atoms: Iterable[Node]) -> dict:
    atoms = tuple(dict.fromkeys(atoms))
    require(coverage_atom() in atoms,
            "Canonical packet comparison requires the literal coverage atom")
    support = set().union(*(descriptors_in(atom) for atom in atoms))
    require(var("w") in support, "The canonical packet must contain Q support")
    old_computation = new_computation = 0
    for body in support:
        modules = computation_modules(body)
        sizes = {name: sum(map(full_size, forms)) for name, forms in modules.items()}
        old_computation += min(sizes[k] for k in ("D", "G_old", "T_old"))
        new_computation += min(sizes[k] for k in ("D", "G_K", "T_K"))
    retained = [atom for atom in atoms if omission_reason(atom) is None]
    new_boundary = sum(full_size(atom) + 16 for atom in retained)
    comparisons = {}
    for presentation, fixed in [("J", 18), ("ordinary_native", 6),
                                ("covered_If", 30)]:
        old_atoms = [atom for atom in atoms if omission_reason(atom) in
                     {None, "explicit_coverage_replacement"}]
        if presentation == "covered_If":
            old_atoms = retained
        old_boundary = sum(old_boundary_cost(atom, presentation) for atom in old_atoms)
        old_total = fixed + old_computation + old_boundary
        new_total = 28 + new_computation + new_boundary
        require(new_total <= old_total, "Failed canonical packet domination")
        comparisons[presentation] = {
            "old_fixed": fixed, "new_fixed": 28,
            "old_computation": old_computation, "new_computation": new_computation,
            "old_boundary": old_boundary, "new_boundary": new_boundary,
            "old_total": old_total, "new_total": new_total,
            "saving": old_total - new_total}
    return {
        "scope": "Canonical coverage-containing packets in the matched mixed language; "
                 "not arbitrary proof costs or other primitive signatures.",
        "common_trivial_omissions_granted_to_both_sides": True,
        "equations": [serialize(atom) for atom in atoms],
        "retained_equations": [serialize(atom) for atom in retained],
        "closed_descriptor_support": [serialize(body) for body in sorted(
            support, key=lambda d: (full_size(d), serialize(d)))],
        "comparisons": comparisons}


def repeated_successor(node: Node, count: int) -> Node:
    for _ in range(count):
        node = successor(node)
    return node


def audit() -> dict:
    v, w, x, a = map(var, ("v", "w", "x", "a"))
    descriptor_cases = [ZERO, v, w]
    for H in (2, 4, 6, 7, 8, 12, 13, 20, 21, 33, 100):
        descriptor_cases.extend([repeated_successor(v, H - 1),
                                 repeated_successor(w, H - 1)])
    descriptor_cases.extend([
        recursor(v, w, w),
        recursor(w, v, w),
        recursor(v, recursor(w, v, ZERO), w),
        recursor(successor(v), successor(v), recursor(w, w, v)),
        recursor(v, recursor(v, v, w), recursor(v, w, v)),
    ])
    descriptor_cases = list(dict.fromkeys(descriptor_cases))
    rows = []
    for body in descriptor_cases:
        H, m, k = full_size(body), active_size(body), active_occurrences(body, "v")
        modules = computation_modules(body)
        measured = {name: sum(map(full_size, forms)) for name, forms in modules.items()}
        active = {name: sum(map(active_size, forms)) for name, forms in modules.items()}
        expected = {"D": 3 * H + 13 + k * (H + 2), "G_old": 3 * H + 22,
                    "T_old": 2 * H + 34, "G_K": 3 * H + 21, "T_K": 2 * H + 33}
        expected_active = {"D": m + 13 + 2 * k, "G_old": m + 22,
                           "T_old": m + 34, "G_K": m + 21, "T_K": m + 33}
        require(measured == expected, "Full computation profile: " + serialize(body))
        require(active == expected_active, "Active computation profile: " + serialize(body))
        require(min(measured[k] for k in ("D", "G_K", "T_K")) <=
                min(measured[k] for k in ("D", "G_old", "T_old")),
                "Computation domination failed")
        rows.append({"descriptor": serialize(body), "H": H, "m": m, "k": k,
                     "full": measured, "active": active})

    frozen_case = recursor(v, w, w)
    require(active_occurrences(frozen_case, "v") == 0, "Frozen v was counted as active")
    require(substitute_active(frozen_case, {"v": successor(v)}) == frozen_case,
            "Active substitution entered a frozen descriptor")
    nesting_case = recursor(v, v, w)
    nesting_result = substitute_active(nesting_case, {"v": successor(v)})
    require(nesting_result.descriptor == v and nesting_result.children[0] == successor(v),
            "Active and frozen occurrences were not distinguished")

    terms = [ZERO, x, a, successor(ZERO), successor(x), successor(a),
             recursor(w, x, ZERO), recursor(w, a, x), recursor(ZERO, x, a),
             recursor(successor(v), x, a),
             recursor(descriptor_cases[-1], successor(x), a),
             recursor(repeated_successor(v, 12), x, a)]
    atoms = [equation(left, right) for left in terms for right in terms]
    atoms.extend([coverage_atom(), equation(coverage_atom().children[1], x)])
    atoms = list(dict.fromkeys(atoms))
    omission_counts: dict[str, int] = {}
    for atom in atoms:
        F, i = full_size(atom), active_occurrences(atom, "x")
        modules = boundary_modules(atom)
        expected = {"D_native": 2 * F + i + 12, "D_J": 2 * F + i + 11,
                    "U_J": F + 20, "K_positive": F + 16,
                    "K_negative": F + 18, "If_predecessor": F + 18}
        require({name: full_size(form) for name, form in modules.items()} == expected,
                "Boundary profile: " + serialize(atom))
        f = active_size(atom)
        expected_active = {"D_native": 2 * f + i + 12, "D_J": 2 * f + i + 11,
                           "U_J": f + 20, "K_positive": f + 16,
                           "K_negative": f + 18, "If_predecessor": f + 18}
        require({name: active_size(form) for name, form in modules.items()} == expected_active,
                "Active boundary profile: " + serialize(atom))
        reason = omission_reason(atom)
        omission_counts[reason or "retained"] = omission_counts.get(reason or "retained", 0) + 1
        if reason is None:
            for old in ("J", "ordinary_native", "covered_If"):
                require(F + 16 <= old_boundary_cost(atom, old),
                        "Retained boundary domination: " + serialize(atom))
    leaf_equations = [equation(left, right) for left in (ZERO, x, a)
                      for right in (ZERO, x, a)
                      if full_size(equation(left, right)) == 3 and
                      active_occurrences(equation(left, right), "x") == 1]
    require(len(leaf_equations) == 4, "The F=3,i=1 classification is not exact")
    require(all(omission_reason(atom) == "four_leaf_equations" for atom in leaf_equations),
            "A leaf exception was not omitted")
    cov = coverage_atom()
    require((full_size(cov), active_occurrences(cov, "x")) == (7, 2),
            "Coverage must be measured using full, not active, size")

    A, B, C = map(var, ("A", "B", "C"))
    definitions = {
        "K": (ternary("K", A, B, C), conjunction(implication(B, A), implication(A, C))),
        "J": (ternary("J", A, B, C), conjunction(disjunction(A, B), implication(A, C))),
        "If": (ternary("If", A, B, C),
               disjunction(conjunction(A, B), conjunction(negate(A), C)))}
    definition_sizes = {name: full_size(lhs) + 1 + full_size(rhs)
                        for name, (lhs, rhs) in definitions.items()}
    require(definition_sizes == {"K": 12, "J": 12, "If": 14},
            "Logical definition record count")
    sep = negate(equation(ZERO, successor(ZERO)))
    coverage = quantify("forall", ["x"], quantify("exists", ["y"],
        disjunction(equation(x, ZERO), equation(x, successor(var("y"))))))
    require((full_size(sep), full_size(coverage)) == (6, 10), "Fixed arithmetic count")
    packets = [packet_comparison([cov]),
               packet_comparison([cov, *leaf_equations, equation(successor(x), a),
                                  equation(recursor(w, x, ZERO), a)]),
               packet_comparison([cov, equation(terms[-1], a),
                                  equation(terms[-2], successor(x))])]
    first = packets[0]["comparisons"]
    require(first["J"]["saving"] == 17, "Canonical J saving should be 17")
    require(first["ordinary_native"]["saving"] == 6, "Native saving should be 6")
    require(first["covered_If"]["saving"] == 2, "Covered If saving should be 2")
    return {
        "status": "passed",
        "scope": "Executable finite syntax audit and exact formula counts; not a "
                 "formal proof of arithmetic adequacy or bi-interpretability.",
        "metric": "One node per variable, constant, application, equality, connective, "
                  "falsity and individual quantifier; full size additionally charges "
                  "each frozen recursion descriptor hereditarily at every occurrence.",
        "binder_annotation_cost": 0,
        "frozen_substitution_checks": "passed",
        "computation_cases": rows,
        "boundary_equations_checked": len(atoms),
        "boundary_profiles": {"positive": "F+16", "negative": "F+18",
                              "negative_raw_zero_test": "T+20"},
        "omission_counts": omission_counts,
        "exact_leaf_exceptions": [serialize(atom) for atom in leaf_equations],
        "coverage_atom": {"formula": serialize(cov), "full_size": 7,
                          "active_size": active_size(cov), "active_x_occurrences": 2},
        "logical_definition_records": definition_sizes,
        "fixed_arithmetic": {"separation": 6, "coverage": 10},
        "canonical_packet_comparisons": packets,
        "not_claimed": ["Global shortestness across signatures or logical bases",
                        "Domination of arbitrary finite proof-support packets",
                        "Domination of the primitive-chi, unary, or relational architectures",
                        "A proof assistant verification of the full interpretation theorem"]}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] /
                        "verification" / "syntax_results.json")
    args = parser.parse_args()
    results = audit()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": results["status"],
                      "descriptor_cases": len(results["computation_cases"]),
                      "boundary_equations": results["boundary_equations_checked"],
                      "output": str(args.output),
                      "scope": "Finite syntax/size audit, not the full mathematical proof"},
                     sort_keys=True))


if __name__ == "__main__":
    main()
