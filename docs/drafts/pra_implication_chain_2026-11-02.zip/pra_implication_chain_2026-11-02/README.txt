AN IMPLICATION-CHAIN AXIOMATIZATION OF PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 2 November 2026
================================================================

START HERE
  report.pdf          Complete mathematical paper and comparison.
  report.tex          Main LaTeX source.
  sections/*.tex      All included proof and comparison sections.
  AXIOMS.txt          Standalone exact specification.

MAIN NEW RESULT
  K(A,B,C) := (B -> A) AND (A -> C).

  forall a n exists b forall x,
    K(E(x,a), S(x)=b, x=b -> b=n)

uses an equation E once and has full size F+16. This improves the current
covered predecessor F+18 clause and, with explicit support accounting,
the current native recurring envelope. A small finite omission policy
handles vacuous, reflexive, four leaf, and canonical coverage equations.

The same K reduces complete recursion modules to
  min(3H+13+k(H+2), 3H+21, 2H+33),
improving both current graph branches by one node.

The theory has full first-order bi-interpretability and equiconsistency
with PRA, separately classically and intuitionistically. Both domains
are whole carriers, equality is native, and both round trips are the
identity. The entire proof is in the report.

HONEST COMPARISON
The source audit pins ProveIt at
  df8fb0bbd19b6b8442b78569d38b9d888e4e7a0d.
Six current ZIPs and five actually archived ZIPs were read. All six
current proposals contain some improvement over those archived inputs.
The papers' own older five-current/eight-archived labels were not reused.

Fixed separation plus coverage costs16; the K logical record costs12.
The resulting28-node record replaces canonical fixed-plus-coverage
totals34,45,47,30 in the compatible native presentations. Common used
computation modules are added on both sides. Other primitive vocabularies,
isolated packets, and complete proof lengths are separately qualified.
No global or language-independent minimum has been proved.

REPRODUCE
Python 3.10+ and a conventional pdfLaTeX installation:
  python3 build.py --checks-only
  python3 build.py --pdf-only

To rerun the Lean kernels as well:
  python3 build.py --lean /absolute/path/to/lean

Use Lean 4.19.0, core library only; lean-toolchain pins it. No downloads
are performed by the builder. Python checkers use the standard library.
The build creates temporary _build/ files and writes verification logs.
Rebuilt PDF metadata can change its checksum.

EMIT LITERAL AXIOMS
  python3 code/emit.py code/examples/boundary.json
  python3 code/emit.py code/examples/computation.json
  python3 code/emit.py code/examples/coverage_omission.json

JSON terms:
  "0", "x", "a"       numerical boundary terms
  "v", "w"            descriptor slots
  ["S", term]         successor
  ["R", h, n, a]      initialized recursor with frozen descriptor h

Each descriptor uses only its own v,w slots. Nested descriptors are
finite syntax, not evaluated programs. Boundary variables are x,a.
The emitter reports support separately and never silently supplies it.

VERIFICATION
  proofs/BoundaryK.lean:
    local constructive induction and omission kernels; Nat scan.
  proofs/ComputationK.lean:
    unconditional equivalence of both computation graph modules.
  verification/BoundaryK.log and computation_lean.log:
    actual successful Lean 4.19.0 output; all 18 dependency audits empty.
  code/check_syntax.py:
    full/active tree counts, frozen substitution, omission classifier,
    complete computation selector, and matched packet comparisons.
  code/check_computation_models.py:
    all 2049 structures of sizes 1 and 2, arbitrary operations.

The full arithmetic bootstrap, parameter compiler, and first-order
interpretation theorem have written proofs; the Lean files do not
formalize that entire metatheory. Finite diagnostics are supplementary.

The execution environment required a narrow startup-path compatibility
shim for Lean's executable-location lookup. Its source is retained in
verification/runtime_path_shim.c; it supplies a known pathname and does
not change proof checking. Normal Lean installations need no shim.

PROVENANCE AND INTEGRITY
  provenance/source_manifest.json:
    pinned URLs, Git blob checks, archive and member hashes.
  provenance/draft_comparison.csv:
    six-current versus five-archived audit and relevant source sections.
  provenance/review_notes.txt:
    independent mathematical review scope and qualifications.
  MANIFEST.sha256:
    deliverable hashes, excluding the manifest itself.

Source ZIP/PDF packages are referenced, not duplicated. No changes were
posted to the repository. The complete deliverable is this archive.
