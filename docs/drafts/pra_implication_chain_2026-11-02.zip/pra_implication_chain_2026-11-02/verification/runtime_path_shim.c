#define _GNU_SOURCE
#include <unistd.h>
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
ssize_t readlink(const char *path, char *buf, size_t size) {
    char expected[80];
    snprintf(expected, sizeof(expected), "/proc/%ld/exe", (long)getpid());
    const char *known = getenv("PRA_LEAN_EXECUTABLE");
    if (known && strcmp(path, expected) == 0) {
        size_t length = strlen(known);
        if (length > size) length = size;
        memcpy(buf, known, length);
        return (ssize_t)length;
    }
    ssize_t (*original)(const char *, char *, size_t) = dlsym(RTLD_NEXT, "readlink");
    return original(path, buf, size);
}
