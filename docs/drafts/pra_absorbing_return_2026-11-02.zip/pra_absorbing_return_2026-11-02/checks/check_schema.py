#!/usr/bin/env python3
"""Construct and check the actual formula trees of absorbing-return PRA.

No third-party packages are required.  Run from any directory:

    python3 checks/check_schema.py

The output is written beside this package in verification/.  These checks
verify finite syntax, exact node counts, branch eligibility, and the tested
instances of the comparison inequalities.  They do not prove induction,
bi-interpretability, or inequalities on all inputs; the report supplies the
mathematical proofs of those assertions.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass, field
from functools import lru_cache
import json
from pathlib import Path
import random
from typing import Union


@dataclass(frozen=True)
class Term:
    """A finite active term with an optional frozen recursor descriptor."""

    tag: str
    args: tuple[Term, ...] = ()
    name: str = ""
    descriptor: Term | None = None
    _hash: int = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        arities = {"var": 0, "zero": 0, "S": 1, "chi": 2, "R": 2}
        assert self.tag in arities and len(self.args) == arities[self.tag]
        assert (self.tag == "R") == (self.descriptor is not None)
        assert (self.tag == "var") == bool(self.name)
        object.__setattr__(
            self, "_hash", hash((self.tag, self.args, self.name, self.descriptor))
        )

    def __hash__(self) -> int:
        return self._hash


@dataclass(frozen=True)
class Formula:
    tag: str
    children: tuple[Union[Term, Formula], ...] = ()
    binder: str = ""

    def __post_init__(self) -> None:
        arities = {"=": 2, "and": 2, "or": 2, "implies": 2,
                   "forall": 1, "exists": 1, "false": 0}
        assert self.tag in arities and len(self.children) == arities[self.tag]
        assert (self.tag in {"forall", "exists"}) == bool(self.binder)
        if self.tag == "=":
            assert all(isinstance(x, Term) for x in self.children)
        else:
            assert all(isinstance(x, Formula) for x in self.children)


def var(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")
N, A, B, C, J, V, W = [var(x) for x in ("n", "a", "b", "c", "j", "v", "w")]


def succ(x: Term) -> Term:
    return Term("S", (x,))


def chi(x: Term, y: Term) -> Term:
    return Term("chi", (x, y))


def rec(descriptor: Term, x: Term, y: Term) -> Term:
    # Normalization is explicit at descriptor selection, never implicit here.
    return Term("R", (x, y), descriptor=descriptor)


def q(x: Term, y: Term) -> Term:
    return rec(W, x, y)


def z(x: Term, y: Term) -> Term:
    return rec(ZERO, x, y)


def is_q(t: Term) -> bool:
    return t.tag == "R" and t.descriptor == W


def is_z(t: Term) -> bool:
    return t.tag == "R" and t.descriptor == ZERO


def normalize(t: Term) -> Term:
    """Only strip literal outer Q(S(r),s) roots, repeatedly."""
    while is_q(t) and t.args[0].tag == "S":
        t = t.args[0].args[0]
    return t


def substitute(t: Term, replacements: dict[str, Term]) -> Term:
    """Simultaneous substitution in active slots; descriptors stay frozen."""
    if t.tag == "var":
        return replacements.get(t.name, t)
    if not t.args:
        return t
    args = tuple(substitute(x, replacements) for x in t.args)
    if args == t.args:
        return t
    return Term(t.tag, args, t.name, t.descriptor)


@lru_cache(maxsize=100000)
def occurrence(t: Term, name: str) -> int:
    if t.tag == "var":
        return int(t.name == name)
    return sum(occurrence(x, name) for x in t.args)


@lru_cache(maxsize=100000)
def free_variables(t: Term) -> frozenset[str]:
    if t.tag == "var":
        return frozenset((t.name,))
    return frozenset().union(*(free_variables(x) for x in t.args))


@lru_cache(maxsize=100000)
def term_size(t: Term, full: bool) -> int:
    # Every occurrence is charged. Caching a subtree's integer size does not
    # turn repeated uses of it into shared/DAG cost.
    total = 1 + sum(term_size(x, full) for x in t.args)
    if full and t.descriptor is not None:
        total += term_size(t.descriptor, True)
    return total


def formula_size(f: Formula, full: bool) -> int:
    return 1 + sum(
        term_size(x, full) if isinstance(x, Term) else formula_size(x, full)
        for x in f.children
    )


def sizes(f: Formula) -> tuple[int, int]:
    return formula_size(f, False), formula_size(f, True)


def eq(x: Term, y: Term) -> Formula:
    return Formula("=", (x, y))


def conjunction(x: Formula, y: Formula) -> Formula:
    return Formula("and", (x, y))


def disjunction(x: Formula, y: Formula) -> Formula:
    return Formula("or", (x, y))


def implies(x: Formula, y: Formula) -> Formula:
    return Formula("implies", (x, y))


def forall(name: str, f: Formula) -> Formula:
    return Formula("forall", (f,), name)


def exists(name: str, f: Formula) -> Formula:
    return Formula("exists", (f,), name)


def close(names: tuple[str, ...], f: Formula) -> Formula:
    for name in reversed(names):
        f = forall(name, f)
    return f


def negate(f: Formula) -> Formula:
    return implies(f, Formula("false"))


def pad(u: Term, count: int = 1) -> Term:
    for _ in range(count):
        u = q(succ(u), A)
    return u


def descriptor(u: Term, normalized: bool = True) -> Term:
    body = substitute(u, {"n": V, "a": W})
    return normalize(body) if normalized else body


def r_for(u: Term, normalized: bool = True):
    d = descriptor(u, normalized)
    return lambda x, y: rec(d, x, y)


def profile(u: Term) -> dict[str, int]:
    return {"m": term_size(u, False), "W": term_size(u, True),
            "mc": term_size(normalize(u), False),
            "V": term_size(normalize(u), True),
            "i": occurrence(u, "n"), "j": occurrence(u, "a")}


def identity_guard(t: Term) -> Term:
    return q(z(chi(A, ZERO), succ(t)), N)


def identity_tail(u: Term) -> Term | None:
    if not is_q(u) or u.args[1] != N:
        return None
    inner = u.args[0]
    if not is_z(inner) or inner.args[0] != chi(A, ZERO):
        return None
    value = inner.args[1]
    return value.args[0] if value.tag == "S" else None


def absorbing_body(t: Term) -> Term:
    regularized = z(chi(N, ZERO), z(t, succ(q(N, ZERO))))
    return identity_guard(regularized)


def absorbing_tail(u: Term) -> Term | None:
    inner = identity_tail(u)
    if inner is None or not is_z(inner) or inner.args[0] != chi(N, ZERO):
        return None
    masked = inner.args[1]
    if not is_z(masked) or masked.args[1] != succ(q(N, ZERO)):
        return None
    return masked.args[0]


def scheduled_absorbing_body(u: Term) -> Term | None:
    if not is_q(u) or u.args[1] != A or u.args[0].tag != "S":
        return None
    body = u.args[0].args[0]
    return body if absorbing_tail(body) is not None else None


def rooted_guard(t: Term) -> Term:
    return z(z(chi(A, ZERO), chi(t, ZERO)), N)


def rooted_tail(u: Term) -> Term | None:
    if not is_z(u) or u.args[1] != N:
        return None
    first = u.args[0]
    if not is_z(first) or first.args[0] != chi(A, ZERO):
        return None
    bit = first.args[1]
    return bit.args[0] if bit.tag == "chi" and bit.args[1] == ZERO else None


def outer_guard(t: Term) -> Term:
    return z(chi(N, ZERO), identity_guard(t))


def is_broad_local_selected(u: Term) -> bool:
    return identity_tail(u) is not None or (
        is_z(u) and u.args[0] == chi(N, ZERO)
        and identity_tail(u.args[1]) is not None
    )


def seed() -> Formula:
    sigma = negate(eq(ZERO, succ(ZERO)))
    bit = conjunction(eq(chi(A, A), succ(ZERO)),
                      disjunction(eq(A, N), eq(chi(A, N), ZERO)))
    matrix = conjunction(sigma, bit)
    return close(("a", "n"), matrix)


def base(u: Term) -> Formula:
    r = r_for(u)
    return forall("a", eq(r(ZERO, A), A))


def left_matrix(u: Term, normalized: bool = True) -> Formula:
    r = r_for(u, normalized)
    step = substitute(u, {"n": r(N, A), "a": N})
    return conjunction(eq(r(ZERO, A), A), eq(r(succ(N), A), step))


def ordinary_left(u: Term) -> Formula:
    return close(("a", "n"), left_matrix(u))


def autonomous_right(u: Term) -> Formula:
    r = r_for(u)
    first = substitute(u, {"n": A, "a": ZERO})
    return close(("a", "n"), conjunction(
        eq(r(ZERO, A), A), eq(r(succ(N), A), r(N, first))))


def bound_step_matrix(u: Term) -> Formula:
    r = r_for(u)
    return implies(eq(r(N, A), C),
                   eq(r(succ(N), A), substitute(u, {"n": C, "a": N})))


def bound_step(u: Term) -> Formula:
    return close(("a", "n", "c"), bound_step_matrix(u))


def canonical_bound_step(u: Term) -> Formula:
    # This emitter deliberately exposes the canonical body.  The incumbent
    # formula constructors below continue to expose the raw input body.
    return bound_step(normalize(u))


def bound_computation(u: Term) -> Formula:
    r = r_for(u)
    return close(("a", "n"), conjunction(
        eq(r(ZERO, A), A), forall("c", bound_step_matrix(u))))


def boundary_witness(u: Term) -> Formula:
    r = r_for(u)
    matrix = conjunction(eq(r(succ(B), A), A),
                         implies(eq(r(succ(succ(B)), A), A), eq(B, N)))
    return close(("a", "n"), exists("b", matrix))


def local_witness(u: Term) -> Formula:
    r = r_for(u)
    chosen = q(z(chi(r(succ(succ(B)), A), A), succ(B)), N)
    return close(("a", "n"), exists("b", eq(r(succ(chosen), A), A)))


def absorbing_witness(u: Term) -> Formula:
    r = r_for(u)
    chosen = q(z(r(succ(succ(B)), A), succ(B)), N)
    return close(("a", "n"), exists("b", eq(r(succ(chosen), A), A)))


def rooted_return(u: Term) -> Formula:
    r = r_for(u)
    progress = forall("b", implies(eq(r(succ(B), A), A),
                                   eq(r(succ(succ(B)), A), A)))
    return close(("a", "n"), implies(progress, eq(r(succ(N), A), A)))


def autonomous_term_profile(u: Term) -> Formula:
    clause = negate(forall("j", eq(
        substitute(u, {"n": J, "a": A}),
        succ(substitute(u, {"n": succ(J), "a": A})))))
    return close(("a", "n"), conjunction(left_matrix(u, False), clause))


def autonomous_orbit_profile(u: Term) -> Formula:
    r = r_for(u, False)
    clause = negate(forall("j", eq(r(J, A), succ(r(succ(J), A)))))
    return close(("a", "n"), conjunction(left_matrix(u, False), clause))


NEW_SEED = pad(N, 4)
OLD_SEED = pad(N)
ROOTED_SEED = z(chi(N, ZERO), A)


def emit_new(u: Term) -> tuple[str, Formula]:
    if u == NEW_SEED:
        return "seed", seed()
    if normalize(u) == u:
        return "canonical_base", base(u)
    if scheduled_absorbing_body(u) is not None:
        return "absorbing_witness", absorbing_witness(u)
    return "canonical_bound_step", canonical_bound_step(u)


def emit_boundary(u: Term) -> tuple[str, Formula]:
    p = profile(u)
    if u == OLD_SEED:
        return "seed", seed()
    if p["i"] > 0 and p["j"] == 0:
        return "right", autonomous_right(u)
    if identity_tail(u) is not None:
        return "boundary", boundary_witness(u)
    return "left", ordinary_left(u)


def emit_local(u: Term, broad: bool = False) -> tuple[str, Formula]:
    p = profile(u)
    if u == OLD_SEED:
        return "seed", seed()
    if p["i"] > 0 and p["j"] == 0:
        return "right", autonomous_right(u)
    selected = is_broad_local_selected(u) if broad else identity_tail(u) is not None
    if selected:
        return "local", local_witness(u)
    return "left", ordinary_left(u)


def emit_rooted(u: Term) -> tuple[str, Formula]:
    p = profile(u)
    if u == ROOTED_SEED:
        return "seed", seed()
    if p["i"] > 0 and p["j"] == 0:
        return "right", autonomous_right(u)
    if rooted_tail(u) is not None:
        return "rooted", rooted_return(u)
    if p["i"] >= 4:
        return "bound", bound_computation(u)
    return "left", ordinary_left(u)


def expected_size(branch: str, p: dict[str, int]):
    m, full, normalized, i = p["m"], p["W"], p["V"], p["i"]
    return {
        "seed": (25, 25),
        "canonical_base": (6, 6 + full),
        "absorbing_witness": (18, 20 + 2 * normalized),
        "canonical_bound_step": (14 + p["mc"], 14 + 3 * normalized),
        "left": (13 + m + 2 * i, 13 + full + 2 * i + (2 + i) * normalized),
        "right": (15 + m, 15 + full + 3 * normalized),
        "boundary": (21, 21 + 2 * full),
        "local": (20, 22 + 2 * full),
        "rooted": (24, 24 + 3 * full),
        "bound": (20 + m, 20 + full + 3 * normalized),
        "term_profile": (19 + 3 * m + 3 * i, 19 + (5 + i) * full + 3 * i),
        "orbit_profile": (26 + m + 2 * i, 26 + (5 + i) * full + 2 * i),
    }[branch]


def compare_one(u: Term) -> dict:
    p = profile(u)
    assert free_variables(u) <= {"n", "a"}
    assert 1 <= p["V"] <= p["W"] and p["m"] <= p["W"]
    assert normalize(normalize(u)) == normalize(u)
    branch, formula = emit_new(u)
    measured = sizes(formula)
    assert measured == expected_size(branch, p), (branch, p, measured)
    old = {}
    candidates = {
        "boundary_witness": emit_boundary(u),
        "local_return": emit_local(u),
        "local_return_broad": emit_local(u, True),
        "rooted_return": emit_rooted(u),
        "autonomous_term_matched": ("term_profile", autonomous_term_profile(u)),
        "autonomous_orbit_matched": ("orbit_profile", autonomous_orbit_profile(u)),
    }
    for name, (old_branch, old_formula) in candidates.items():
        actual = sizes(old_formula)
        assert actual == expected_size(old_branch, p), (name, old_branch, p, actual)
        assert measured[0] < actual[0] and measured[1] < actual[1], (
            "strict envelope failure", name, branch, p, measured, actual)
        old[name] = {"branch": old_branch, "active": actual[0], "full": actual[1]}
    envelope = (min(x["active"] for x in old.values()),
                min(x["full"] for x in old.values()))
    return {"profile": p, "new_branch": branch,
            "new": {"active": measured[0], "full": measured[1]},
            "old_envelope": {"active": envelope[0], "full": envelope[1]},
            "saving": {"active": envelope[0] - measured[0],
                       "full": envelope[1] - measured[1]}, "incumbents": old}


def term_text(t: Term, descriptors: bool = False) -> str:
    if t.tag == "var":
        return t.name
    if t.tag == "zero":
        return "0"
    if t.tag == "S":
        return "S(" + term_text(t.args[0], descriptors) + ")"
    if t.tag == "chi":
        name = "chi"
    elif is_q(t):
        name = "Q"
    elif is_z(t):
        name = "Z"
    else:
        name = "R[" + term_text(t.descriptor, descriptors) + "]" if descriptors else "R_h"
    return name + "(" + ",".join(term_text(x, descriptors) for x in t.args) + ")"


def formula_text(f: Formula) -> str:
    if f.tag == "false":
        return "FALSE"
    if f.tag == "=":
        return term_text(f.children[0]) + "=" + term_text(f.children[1])
    if f.tag in {"forall", "exists"}:
        return f.tag + " " + f.binder + " (" + formula_text(f.children[0]) + ")"
    return "(" + formula_text(f.children[0]) + " " + f.tag + " " + formula_text(f.children[1]) + ")"


def random_term(rng: random.Random, depth: int, variables: tuple[Term, Term],
                descriptors: list[Term]) -> Term:
    if depth <= 0 or rng.random() < 0.18:
        return rng.choice((ZERO,) + variables)
    kind = rng.randrange(5)
    x = random_term(rng, depth - 1, variables, descriptors)
    if kind == 0:
        return succ(x)
    y = random_term(rng, depth - 1, variables, descriptors)
    if kind == 1:
        return chi(x, y)
    if kind == 2:
        return q(x, y)
    if kind == 3:
        return z(x, y)
    return rec(rng.choice(descriptors), x, y)


def descriptor_pool(rng: random.Random) -> list[Term]:
    pool = [ZERO, V, W, succ(V), succ(W), chi(V, W)]
    for _ in range(4):
        prior = list(pool)
        additions = [normalize(random_term(rng, 3, (V, W), prior)) for _ in range(12)]
        pool.extend(x for x in additions if x not in pool)
    assert all(free_variables(t) <= {"v", "w"} and normalize(t) == t for t in pool)
    return pool


def check_substitution_and_normalization(pool: list[Term]) -> int:
    checks = 0
    # Simultaneity: the inserted replacement is not itself substituted.
    assert substitute(N, {"n": A, "a": ZERO}) == A
    assert substitute(chi(N, A), {"n": A, "a": N}) == chi(A, N)
    checks += 2
    # A frozen descriptor may contain v,w; substitutions never enter it.
    sample = rec(chi(V, W), N, A)
    changed = substitute(sample, {"v": ZERO, "w": ZERO, "n": A, "a": N})
    assert changed.descriptor == sample.descriptor and changed.args == (A, N)
    checks += 1
    # Root normalization does not visit an S argument, other arguments, or descriptors.
    nested = q(succ(N), A)
    assert normalize(succ(nested)) == succ(nested)
    assert normalize(q(N, nested)) == q(N, nested)
    raw_descriptor = q(succ(V), W)
    named = rec(raw_descriptor, N, A)
    assert normalize(named) == named and named.descriptor == raw_descriptor
    checks += 3
    for d in pool:
        u = substitute(d, {"v": N, "w": A})
        assert normalize(u) == u
        twice = pad(u, 2)
        assert normalize(twice) == u
        branch, _ = emit_new(twice)
        assert branch == "canonical_bound_step"
        assert descriptor(twice) == descriptor(u)
        # The new exposed body is already canonical, before Q equations exist.
        state = rec(descriptor(u), N, A)
        actual_update = substitute(normalize(twice), {"n": state, "a": N})
        expected_update = substitute(u, {"n": state, "a": N})
        assert actual_update == expected_update
        checks += 5
    # Q's step is obtained at P(a), before normalization has been justified
    # arithmetically: the canonical exposed body is literally the counter slot.
    branch, emitted = emit_new(pad(A))
    assert branch == "canonical_bound_step"
    assert normalize(pad(A)) == A
    assert emitted == close(("a", "n", "c"),
                            implies(eq(q(N, A), C), eq(q(succ(N), A), N)))
    checks += 3
    return checks


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--random-count", type=int, default=6500)
    parser.add_argument("--seed", type=int, default=20261102)
    parser.add_argument("--output-dir", type=Path,
                        default=Path(__file__).resolve().parents[1] / "verification")
    args = parser.parse_args()
    assert args.random_count >= 0
    rng = random.Random(args.seed)
    pool = descriptor_pool(rng)
    syntax_checks = check_substitution_and_normalization(pool)

    tails = [ZERO, N, A, succ(N), succ(A), chi(N, A), q(N, A), z(N, A)]
    tails += [rec(d, N, A) for d in pool[-12:]]
    # Repeated state slots exercise both sides of the old bound-state threshold.
    repeated = N
    for _ in range(10):
        tails.append(repeated)
        repeated = chi(N, repeated)
    structured = set((ZERO, N, A, OLD_SEED, ROOTED_SEED, NEW_SEED))
    for t in tails:
        bodies = [t, identity_guard(t), absorbing_body(t), rooted_guard(t), outer_guard(t)]
        for body in bodies:
            for depth in range(8):
                structured.add(pad(body, depth))
            structured.add(q(succ(body), ZERO))
            structured.add(q(succ(body), succ(A)))
        # Each absorbing wrapper has the exact literal costs claimed in the paper.
        h = absorbing_body(t)
        pt, ph = profile(t), profile(h)
        assert (ph["m"], ph["W"], ph["i"], ph["j"]) == (
            pt["m"] + 16, pt["W"] + 21, pt["i"] + 3, pt["j"] + 1)
        assert normalize(h) == h and absorbing_tail(h) == t
        assert sizes(absorbing_witness(h)) == (18, 20 + 2 * ph["W"])
        canonical_old = [sizes(emit_boundary(h)[1]), sizes(emit_local(h)[1]),
                         sizes(emit_local(h, True)[1]), sizes(emit_rooted(h)[1])]
        assert (min(x[0] for x in canonical_old), min(x[1] for x in canonical_old)) == (
            20, 21 + 2 * ph["W"])
        syntax_checks += 4

    random_inputs: set[Term] = set()
    while len(random_inputs) < args.random_count:
        random_inputs.add(random_term(rng, rng.randint(3, 7), (N, A), pool))

    branches: Counter[str] = Counter()
    tested: set[Term] = set()
    min_saving = {"active": None, "full": None}
    maxima = {"m": 0, "mc": 0, "W": 0, "V": 0, "i": 0, "j": 0}
    for u in list(structured) + list(random_inputs):
        if u in tested:
            continue
        result = compare_one(u)
        tested.add(u)
        branches[result["new_branch"]] += 1
        for metric in min_saving:
            saving = result["saving"][metric]
            if min_saving[metric] is None or saving < min_saving[metric]:
                min_saving[metric] = saving
        for name in maxima:
            maxima[name] = max(maxima[name], result["profile"][name])

    examples = [
        ("zero", ZERO), ("second_slot", A), ("first_slot", N),
        ("old_boundary_local_seed", OLD_SEED), ("old_rooted_seed", ROOTED_SEED),
        ("new_seed", NEW_SEED), ("old_identity_guard_zero", identity_guard(ZERO)),
        ("old_rooted_guard_zero", rooted_guard(ZERO)),
        ("old_broad_local_guard_zero", outer_guard(ZERO)),
        ("absorbing_body_zero", absorbing_body(ZERO)),
        ("scheduled_absorbing_zero", pad(absorbing_body(ZERO))),
        ("scheduled_absorbing_state", pad(absorbing_body(N))),
        ("double_alias_zero", pad(ZERO, 2)),
        ("nested_descriptor", rec(pool[-1], N, A)),
    ]
    example_records = []
    lines = ["ABSORBING-RETURN PRA: ACTUAL FORMULA-TREE CHECKS", "",
             "Counts are active/full. Stored descriptions stay frozen under substitution.",
             "The comparison to autonomous templates is a matched-profile comparison.", ""]
    for name, u in examples:
        record = {"name": name, "input": term_text(u, True), **compare_one(u)}
        branch, formula = emit_new(u)
        record["emitted_formula"] = formula_text(formula)
        example_records.append(record)
        new, old = record["new"], record["old_envelope"]
        lines += [name, "  input: " + term_text(u, True), "  branch: " + branch,
                  f"  new: {new['active']}/{new['full']}; old envelope: {old['active']}/{old['full']}",
                  "  formula: " + formula_text(formula), ""]

    h0 = absorbing_body(ZERO)
    kernel = {
        "tail": "0", "body_active": term_size(h0, False),
        "body_full": term_size(h0, True),
        "new_unrelocated": {"active": 18, "full": sizes(absorbing_witness(h0))[1]},
        "old_coordinate_minimum": {"active": 20, "full": 21 + 2 * term_size(h0, True)},
        "new_formula": formula_text(absorbing_witness(h0)),
        "meaning": "Independent kernel improvement, before moving axioms to aliases.",
    }
    assert kernel["new_unrelocated"] == {"active": 18, "full": 64}
    assert kernel["old_coordinate_minimum"] == {"active": 20, "full": 65}
    results = {
        "status": "PASS", "schema_version": "four_case_canonical_exposure_seed_P4",
        "repository_snapshot": "53f59452ff3340cfdff9b1ac34c80d14ee2ce1b4",
        "random_seed": args.seed, "unique_random_inputs": len(random_inputs),
        "unique_structured_inputs": len(structured), "unique_total_inputs": len(tested),
        "frozen_descriptor_pool_size": len(pool), "dedicated_syntax_checks": syntax_checks,
        "new_branch_counts": dict(sorted(branches.items())),
        "minimum_observed_strict_saving": min_saving, "largest_tested_profiles": maxima,
        "strict_both_metrics_for_every_tested_input": True,
        "comparison_scope": {
            "literal": ["boundary_witness", "local_return", "local_return_broad", "rooted_return"],
            "matched_complete_k0_templates": ["autonomous_term", "autonomous_orbit"],
            "fixed_autonomous_basis_cost": "omitted, favoring the incumbent",
            "exposure_convention": "New bound steps expose NF(u); all incumbent computation formulas expose raw u. The report proves the normalization identity internally after deriving Q's equations.",
            "not_compared": "Standalone induction payloads with computation costs discarded.",
        },
        "mathematical_scope": "Finite syntax and count checks only. Universal inequalities, induction, and bi-interpretability are proved in the report, not by finite testing.",
        "kernel_improvement": kernel, "examples": example_records,
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    json_path = args.output_dir / "schema_results.json"
    examples_path = args.output_dir / "schema_examples.txt"
    json_path.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    examples_path.write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({k: results[k] for k in (
        "status", "schema_version", "unique_random_inputs", "unique_structured_inputs",
        "unique_total_inputs", "new_branch_counts", "minimum_observed_strict_saving")}, indent=2))
    print("Results:", json_path)
    print("Examples:", examples_path)


if __name__ == "__main__":
    main()
