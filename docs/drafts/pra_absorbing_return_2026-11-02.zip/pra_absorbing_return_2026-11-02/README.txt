PRA FROM ABSORBING RETURN WITNESSES
Prepared for Vladimir Reshetnikov, November 2, 2026

START HERE
  report.pdf       Complete mathematical report.
  report.tex       Main TeX source; includes the numbered .tex sections.
  AXIOMS.txt       Complete final four-case specification.

MAIN RESULTS
1. A new absorbing return witness removes the equality test from the
   current local-return formula. On the same canonical absorbing inputs,
   it costs 18 active nodes and 20+2W fully charged nodes, strictly
   improving the current joint minima 20 and 21+2W.
2. A four-case emitter shares base/step obligations across the existing
   normalized aliases and prints the canonical update body. It is strictly
   shorter in BOTH measures at EVERY shared raw input compared with the
   current four-draft benchmark, with the grammar qualification below.
3. The theory and first-order PRA have a common conservative definitional
   extension. Both interpretations use the full domain and native equality;
   both composites are internally the identity.
4. The proofs work separately in classical and intuitionistic logic.

SOURCE SNAPSHOT
  ProveIt commit 53f59452ff3340cfdff9b1ac34c80d14ee2ce1b4.
  Four current archives: autonomous_orbits, boundary_witness, local_return,
  rooted_return, all dated 2026-11-02.
  Immutable URLs and hashes are in provenance/source_manifest.json.

EXACT SCOPE
  Literal same-grammar comparisons cover the boundary/local/rooted drafts.
  The autonomous draft uses a different descriptor grammar; its disclosed
  complete two-slot recurring templates are compared as matched profiles.
  This is not an encoding-independent shortestness theorem.
  Formula counts do not measure the entire grammar/emitter or proof support.
  The longer absorbing wrapper can increase the size of a particular
  formula-to-induction compilation, even though matched witness counts fall.

REPRODUCE
  python3 build.py
  Requirements: Python 3.10+, pdflatex with the standard packages named
  in report.tex. The Python syntax checker needs no third-party package.
  The build reruns the syntax checks and compiles the PDF three times.

FORMAL CHECK
  lean formal/AbsorbingReturn.lean
  Verified with Lean 4.19.0; uses only the bundled Std library.
  See formal/SCOPE.txt for exact hypotheses and exclusions.
  The checked development is a partial formalization of mathematical
  kernels, not a full mechanization of the complete theory equivalence.
  The printed dependencies contain no sorryAx or Classical.choice.

ARTIFACTS
  checks/check_schema.py       Actual AST emitter, counts, finite checks.
  formal/AbsorbingReturn.lean  Checked arbitrary-carrier and search kernels.
  formal/SCOPE.txt             Exact formal verification scope.
  verification/               Build, syntax, mathematical review and PDF QA.
  provenance/                 Source archive inventory and hashes.
  SHA256SUMS                  Integrity hashes for packaged files.

The final section of the report contains Further research questions.
