#!/usr/bin/env python3
"""Rerun the finite syntax checks and compile the mathematical report."""
from pathlib import Path
import json
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
verification = root / "verification"
verification.mkdir(exist_ok=True)
commands = []

def run(command, log_name):
    result = subprocess.run(
        command, cwd=root, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, check=False
    )
    (verification / log_name).write_text(result.stdout)
    commands.append({"command": command, "exit_code": result.returncode,
                     "log": log_name})
    if result.returncode:
        print(result.stdout[-6000:])
        raise SystemExit(result.returncode)

run([sys.executable, "checks/check_schema.py"], "schema_run.txt")
if not shutil.which("pdflatex"):
    raise SystemExit("pdflatex is required to compile report.tex.")
for number in range(1, 4):
    run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
         "report.tex"], f"latex_pass_{number}.txt")
log = (root / "report.log").read_text(errors="replace")
bad = {
    "overfull_boxes": len(re.findall(r"Overfull \\[hv]box", log)),
    "undefined_references": "There were undefined references" in log,
    "undefined_citations": bool(re.search(r"Citation .* undefined", log)),
    "latex_errors": bool(re.search(r"^!", log, re.M)),
}
result = {"status": "PASS" if not any(bad.values()) else "REVIEW",
          "commands": commands, "diagnostics": bad,
          "pdf_bytes": (root / "report.pdf").stat().st_size}
(verification / "build_results.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))
if any(bad.values()):
    raise SystemExit(1)
