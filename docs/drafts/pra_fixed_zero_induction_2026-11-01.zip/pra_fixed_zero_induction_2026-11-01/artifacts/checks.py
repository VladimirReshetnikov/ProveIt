#!/usr/bin/env python3
"""Finite diagnostics for the guarded-equation PRA presentation.

Run with Python 3.10 or newer; only the standard library is used.
The output is a reproducible JSON report. These diagnostics are not proofs
about arbitrary models, nor a formal verification of either interpretation.
The evaluator is an external Python interpreter for finite acyclic test
descriptions, not a claimed primitive-recursive universal evaluator.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
import json
import math
from pathlib import Path
from typing import Callable, Union


class DiagnosticFailure(RuntimeError):
    pass


COUNTS: Counter[str] = Counter()


def check(category: str, condition: bool, message: str) -> None:
    """Checks remain active under python -O."""
    COUNTS[category] += 1
    if not condition:
        raise DiagnosticFailure(message)


# Formula-tree ledger. A quantifier charges one node, not an extra node for
# its binder annotation. All actual variable occurrences are separate leaves.
@dataclass(frozen=True)
class Node:
    label: str
    children: tuple[Node, ...] = ()

    def size(self) -> int:
        return 1 + sum(child.size() for child in self.children)


def leaf(name: str) -> Node:
    return Node(name)


def app(name: str, *args: Node) -> Node:
    return Node(name, args)


def eq(left: Node, right: Node) -> Node:
    return app("=", left, right)


def implies(left: Node, right: Node) -> Node:
    return app("implies", left, right)


def forall(variable: str, body: Node) -> Node:
    return Node("forall:" + variable, (body,))


def close(names: list[str], body: Node) -> Node:
    for name in reversed(names):
        body = forall(name, body)
    return body


def recurrence_templates(k: int, mode: str) -> tuple[Node, Node]:
    n, a, zero = leaf("n"), leaf("a"), leaf("0")
    sn = app("S", n)
    names = ["b" + str(i) for i in range(k)]
    bs = tuple(leaf(name) for name in names)
    base = close(["a"] + names, eq(app("R", zero, a, *bs), a))
    if mode == "ordinary":
        nested = app("R", n, a, *bs)
        update = app("h", n, *bs, nested)
    elif mode == "swap_full":
        nested = app("R", a, n, *bs)
        update = app("h", n, a, *bs, nested)
    elif mode == "swap_counter":
        nested = app("R", a, n, *bs)
        update = app("h", n, *bs, nested)
    else:
        raise ValueError(mode)
    step = close(["n", "a"] + names, eq(app("R", sn, a, *bs), update))
    return base, step


def induction_template(q: int, form: str) -> Node:
    names = ["c" + str(i) for i in range(q)]
    cs = tuple(leaf(name) for name in names)
    n, zero = leaf("n"), leaf("0")
    sn = app("S", n)

    def matrix(arg: Node) -> Node:
        if form == "qfi":
            return app("A", arg, *cs)
        first = eq(app("s", arg, *cs), app("t", arg, *cs))
        if form == "two_equations":
            second = eq(app("u", arg, *cs), app("v", arg, *cs))
            return app("or", first, second)
        if form == "guarded":
            return first
        raise ValueError(form)

    if form == "guarded":
        guarded_n = app("or", eq(n, zero), matrix(n))
        premise = forall("n", implies(guarded_n, matrix(sn)))
        conclusion = forall("n", guarded_n)
    else:
        progression = forall("n", implies(matrix(n), matrix(sn)))
        premise = app("and", matrix(zero), progression)
        conclusion = forall("n", matrix(n))
    return close(names, implies(premise, conclusion))


def probe_template(q: int, inline: bool) -> Node:
    names = ["c" + str(i) for i in range(q)]
    cs = tuple(leaf(name) for name in names)
    n, a, zero = leaf("n"), leaf("a"), leaf("0")
    fn = app("f", n, *cs)
    f0 = app("f", zero, *cs)
    fsn = app("f", app("S", n), *cs)
    premise = forall("n", eq(fsn, fn))
    if inline:
        comparator = app("C", app("D", a, f0), f0, a)
        conclusion_matrix = app("or", eq(comparator, a), eq(app("S", fn), a))
    else:
        comparator = app("T", f0, a)
        conclusion_matrix = app("or", eq(comparator, a), eq(fn, a))
    conclusion = forall("a", forall("n", conclusion_matrix))
    return close(names, implies(premise, conclusion))


def metric_diagnostics() -> list[dict]:
    sep = implies(eq(leaf("0"), app("S", leaf("0"))), leaf("bottom"))
    check("metric_components", sep.size() == 6, "separator count")
    c_body, d_body = leaf("b"), leaf("v")
    t_body = app("C", app("D", leaf("a"), leaf("n")), leaf("n"), leaf("a"))
    check("metric_components", c_body.size() == 1, "selector body count")
    check("metric_components", d_body.size() == 1, "swap body count")
    check("metric_components", t_body.size() == 6, "probe body count")
    rows = []
    for k in range(4):
        ordinary = recurrence_templates(k, "ordinary")
        full_swap = recurrence_templates(k, "swap_full")
        counter_swap = recurrence_templates(k, "swap_counter")
        for q in range(4):
            cases = [
                ("initialized_qfi", ordinary, induction_template(q, "qfi"), 0,
                 6 * k + 5 * q + 38),
                ("initialized_two_equations", ordinary,
                 induction_template(q, "two_equations"), 0,
                 6 * k + 17 * q + 77),
                ("initialized_guarded_equation", ordinary,
                 induction_template(q, "guarded"), 0,
                 6 * k + 7 * q + 53),
                ("fresh_probe_full_swap", full_swap, probe_template(q, False),
                 c_body.size() + d_body.size() + t_body.size(),
                 6 * k + 5 * q + 54),
                ("fresh_inline_counter_swap", counter_swap, probe_template(q, True),
                 c_body.size() + d_body.size(),
                 6 * k + 6 * q + 52),
            ]
            for name, recurrence, schema, bodies, expected in cases:
                components = {
                    "base": recurrence[0].size(),
                    "step": recurrence[1].size(),
                    "separator": sep.size(),
                    "schema": schema.size(),
                }
                display = sum(components.values())
                total = display + bodies
                check("metric_totals", total == expected, f"{name}, k={k}, q={q}")
                rows.append({"basis": name, "k": k, "q": q, **components,
                             "display": display, "selected_bodies": bodies,
                             "partial_total": total})
    return rows


# Numerical recurrence diagnostics. Neither the implementation of monus nor
# the accumulator loop uses min/max; those appear only in expected results.
def predecessor(x: int) -> int:
    return 0 if x == 0 else x - 1


def addition(x: int, y: int) -> int:
    value = x
    for _ in range(y):
        value += 1
    return value


def monus(x: int, y: int) -> int:
    value = x
    for _ in range(y):
        value = predecessor(value)
    return value


def selector(z: int, u: int, w: int) -> int:
    return u if z == 0 else w


def accumulators(x: int, n: int) -> tuple[int, int, int]:
    r, u, v = x, 0, 0
    for _ in range(n):
        old_r, old_u, old_v = r, u, v
        r = predecessor(old_r)
        u = selector(old_r, old_u, old_u + 1)
        v = selector(old_r, old_v + 1, old_v)
    return r, u, v


def error_bit(x: int, y: int) -> int:
    return selector(addition(monus(x, y), monus(y, x)), 0, 1)


Formula = tuple


def boolean_value(formula: Formula, atoms: tuple[bool, ...]) -> bool:
    tag = formula[0]
    if tag == "atom":
        return atoms[formula[1]]
    if tag == "true":
        return True
    if tag == "false":
        return False
    left = boolean_value(formula[1], atoms)
    right = boolean_value(formula[2], atoms)
    if tag == "and":
        return left and right
    if tag == "or":
        return left or right
    if tag == "implies":
        return (not left) or right
    raise ValueError(tag)


def compiled_error(formula: Formula, atom_bits: tuple[int, ...]) -> int:
    tag = formula[0]
    if tag == "atom":
        return atom_bits[formula[1]]
    if tag == "true":
        return 0
    if tag == "false":
        return 1
    left = compiled_error(formula[1], atom_bits)
    right = compiled_error(formula[2], atom_bits)
    if tag == "and":
        return selector(left, right, 1)
    if tag == "or":
        return selector(left, 0, right)
    if tag == "implies":
        return selector(left, right, 0)
    raise ValueError(tag)


def arithmetic_diagnostics(bound: int = 20) -> dict:
    a, b, c = ("atom", 0), ("atom", 1), ("atom", 2)
    false, true = ("false",), ("true",)
    formulas = [a, b, c, false, true]
    for connective in ("and", "or", "implies"):
        formulas.extend([(connective, a, b), (connective, b, c)])
    formulas.extend([
        ("implies", a, false),
        ("or", a, ("implies", a, false)),
        ("implies", ("and", a, b), c),
        ("and", ("or", a, b), ("implies", b, c)),
        ("implies", ("implies", a, b), ("implies", b, a)),
    ])
    for x in range(bound + 1):
        for y in range(bound + 1):
            r, u, v = accumulators(x, y)
            check("accumulator_invariants", x == addition(r, u), f"x invariant {x,y}")
            check("accumulator_invariants", y == addition(v, u), f"n invariant {x,y}")
            check("numerical_crosschecks", r == max(x - y, 0), f"r meaning {x,y}")
            check("numerical_crosschecks", u == min(x, y), f"u meaning {x,y}")
            check("numerical_crosschecks", v == max(y - x, 0), f"v meaning {x,y}")
            check("arithmetic_identities", addition(x, y) == addition(y, x),
                  f"addition commutativity {x,y}")
            check("arithmetic_identities", monus(x + 1, y + 1) == monus(x, y),
                  f"simultaneous predecessor {x,y}")
            check("arithmetic_identities", monus(addition(x, y), x) == y,
                  f"prefix subtraction {x,y}")
            reflected = monus(x, y) == 0 and monus(y, x) == 0
            check("native_equality_numerics", reflected == (x == y),
                  f"equality reflection {x,y}")
            eb = error_bit(x, y)
            check("native_equality_numerics", eb in (0, 1), f"bit range {x,y}")
            check("native_equality_numerics", (eb == 0) == (x == y), f"bit truth {x,y}")
            atom_pairs = ((x, y), (monus(x, y), 0), (x + 1, y))
            atoms = tuple(left == right for left, right in atom_pairs)
            bits = tuple(error_bit(left, right) for left, right in atom_pairs)
            for index, formula in enumerate(formulas):
                bit = compiled_error(formula, bits)
                truth = boolean_value(formula, atoms)
                check("boolean_compilation", bit in (0, 1), f"formula range {x,y,index}")
                check("boolean_compilation", (bit == 0) == truth,
                      f"formula correctness {x,y,index}")
    # Standard-numerical witnesses to two invalid mutations of G. The paper
    # supplies the universal logical arguments, not these bounded examples.
    check("negative_controls", all((not False) or False for _ in range(5)),
          "unguarded false progression must hold")
    check("negative_controls", not ((1 == 0) or False),
          "removing premise guard must fail at one")
    e_successor = lambda n: n + 1 == predecessor(n + 1) + 1
    check("negative_controls", all(e_successor(n) for n in range(5)),
          "coverage equation must hold at successors")
    check("negative_controls", not (0 == predecessor(0) + 1),
          "removing conclusion guard must fail at zero")
    return {"bound_inclusive": bound, "input_pairs": (bound + 1) ** 2,
            "formula_examples": len(formulas)}


# Finite effective description syntax. An ordinary symbol with p parameters
# has inputs (n,b_0,...,b_{p-1}), base variables (b_0,...,b_{p-1}), and update
# variables (n,b_0,...,b_{p-1},v). An initialized symbol with p frozen
# parameters has inputs (n,a,b_0,...,b_{p-1}) and update variables
# (n,b_0,...,b_{p-1},v). Its seed does not enter the update interface.
@dataclass(frozen=True)
class Var:
    index: int


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    child: Term


@dataclass(frozen=True, eq=False)
class Program:
    name: str
    style: str
    parameters: int
    base: Term | None
    step: Term

    @property
    def arity(self) -> int:
        return self.parameters + (1 if self.style == "ordinary" else 2)


@dataclass(frozen=True)
class Call:
    program: Program
    arguments: tuple[Term, ...]


Term = Union[Var, Zero, Succ, Call]
ZERO = Zero()


def substitute(term: Term, variables: tuple[Term, ...]) -> Term:
    if isinstance(term, Var):
        return variables[term.index]
    if isinstance(term, Zero):
        return term
    if isinstance(term, Succ):
        return Succ(substitute(term.child, variables))
    return Call(term.program, tuple(substitute(arg, variables) for arg in term.arguments))


def evaluate_term(term: Term, variables: tuple[int, ...]) -> int:
    if isinstance(term, Var):
        return variables[term.index]
    if isinstance(term, Zero):
        return 0
    if isinstance(term, Succ):
        return evaluate_term(term.child, variables) + 1
    args = tuple(evaluate_term(arg, variables) for arg in term.arguments)
    return evaluate_program(term.program, args)


@lru_cache(maxsize=None)
def evaluate_program(program: Program, arguments: tuple[int, ...]) -> int:
    if len(arguments) != program.arity or any(arg < 0 for arg in arguments):
        raise DiagnosticFailure("invalid program inputs")
    n = arguments[0]
    if program.style == "ordinary":
        frozen = arguments[1:]
        if program.base is None:
            raise DiagnosticFailure("ordinary program has no base")
        value = evaluate_term(program.base, frozen)
    elif program.style == "initialized":
        value = arguments[1]
        frozen = arguments[2:]
    else:
        raise DiagnosticFailure("unknown program style")
    for index in range(n):
        value = evaluate_term(program.step, (index,) + frozen + (value,))
    return value


class Compilers:
    def __init__(self) -> None:
        self.forward_symbols: dict[Program, Program] = {}
        self.reverse_symbols: dict[Program, Program] = {}

    def forward_symbol(self, ordinary: Program) -> Program:
        if ordinary.style != "ordinary":
            raise DiagnosticFailure("forward compiler expected ordinary description")
        if ordinary not in self.forward_symbols:
            step = self.forward(ordinary.step)
            self.forward_symbols[ordinary] = Program(
                "alpha[" + ordinary.name + "]", "initialized",
                ordinary.parameters, None, step)
        return self.forward_symbols[ordinary]

    def forward(self, term: Term) -> Term:
        if isinstance(term, (Var, Zero)):
            return term
        if isinstance(term, Succ):
            return Succ(self.forward(term.child))
        source = term.program
        target = self.forward_symbol(source)
        args = tuple(self.forward(arg) for arg in term.arguments)
        if source.base is None:
            raise DiagnosticFailure("missing ordinary base")
        base = substitute(self.forward(source.base), args[1:])
        return Call(target, (args[0], base) + args[1:])

    def reverse_symbol(self, initialized: Program) -> Program:
        if initialized.style != "initialized":
            raise DiagnosticFailure("reverse compiler expected initialized description")
        if initialized not in self.reverse_symbols:
            k = initialized.parameters
            translated_step = self.reverse(initialized.step)
            # Add the seed as the first frozen parameter. The old update
            # ignored that seed; its old frozen parameters move right by one.
            reindex = ((Var(0),) + tuple(Var(i + 2) for i in range(k))
                       + (Var(k + 2),))
            step = substitute(translated_step, reindex)
            self.reverse_symbols[initialized] = Program(
                "beta[" + initialized.name + "]", "ordinary", k + 1, Var(0), step)
        return self.reverse_symbols[initialized]

    def reverse(self, term: Term) -> Term:
        if isinstance(term, (Var, Zero)):
            return term
        if isinstance(term, Succ):
            return Succ(self.reverse(term.child))
        target = self.reverse_symbol(term.program)
        return Call(target, tuple(self.reverse(arg) for arg in term.arguments))


def validate_description(root: Program) -> int:
    visited: set[Program] = set()
    active: set[Program] = set()

    def visit_term(term: Term, scope: int, style: str) -> None:
        if isinstance(term, Var):
            check("description_well_formedness", 0 <= term.index < scope,
                  "variable outside descriptor scope")
        elif isinstance(term, Succ):
            visit_term(term.child, scope, style)
        elif isinstance(term, Call):
            check("description_well_formedness", len(term.arguments) == term.program.arity,
                  "call has wrong arity")
            check("description_well_formedness", term.program.style == style,
                  "mixed source and target syntax")
            for arg in term.arguments:
                visit_term(arg, scope, style)
            visit_program(term.program)

    def visit_program(program: Program) -> None:
        if program in visited:
            return
        check("description_well_formedness", program not in active,
              "cyclic descriptor dependency")
        active.add(program)
        if program.style == "ordinary":
            check("description_well_formedness", program.base is not None,
                  "missing ordinary base")
            visit_term(program.base, program.parameters, program.style)
        else:
            check("description_well_formedness", program.base is None,
                  "initialized descriptor has a hidden base")
        visit_term(program.step, program.parameters + 2, program.style)
        active.remove(program)
        visited.add(program)

    visit_program(root)
    return len(visited)


def identity_call(program: Program) -> Call:
    return Call(program, tuple(Var(i) for i in range(program.arity)))


def compiler_diagnostics() -> dict:
    compilers = Compilers()
    pred = Program("predecessor", "ordinary", 0, ZERO, Var(0))
    add = Program("addition", "ordinary", 1, Var(0), Succ(Var(2)))
    multiply = Program("multiplication", "ordinary", 1, ZERO,
                       Call(add, (Var(1), Var(2))))
    factorial = Program("factorial", "ordinary", 0, Succ(ZERO),
                        Call(multiply, (Succ(Var(0)), Var(1))))
    choose = Program("zero_selector", "ordinary", 2, Var(0), Var(2))
    ordinary_examples: list[tuple[Program, list[tuple[int, ...]], Callable]] = [
        (pred, [(n,) for n in range(12)], lambda n: predecessor(n)),
        (add, [(n, a) for n in range(9) for a in range(8)], lambda n, a: n + a),
        (multiply, [(n, a) for n in range(8) for a in range(7)], lambda n, a: n * a),
        (factorial, [(n,) for n in range(7)], lambda n: math.factorial(n)),
        (choose, [(n, a, b) for n in range(5) for a in range(4) for b in range(4)],
         lambda n, a, b: a if n == 0 else b),
    ]
    ordinary_rows = []
    for program, samples, expected in ordinary_examples:
        original = identity_call(program)
        forward = compilers.forward(original)
        roundtrip = compilers.reverse(forward)
        for term in (original, forward, roundtrip):
            validate_description(term.program)
        for args in samples:
            source = evaluate_term(original, args)
            check("ordinary_standard_values", source == expected(*args),
                  f"ordinary standard value: {program.name} {args}")
            check("ordinary_forward_translation", evaluate_term(forward, args) == source,
                  f"ordinary forward translation: {program.name} {args}")
            check("ordinary_roundtrip", evaluate_term(roundtrip, args) == source,
                  f"ordinary round trip: {program.name} {args}")
        ordinary_rows.append({"name": program.name, "samples": len(samples)})

    add_step = compilers.forward(Call(add, (Var(1), Var(2))))
    factorial_step = compilers.forward(Call(multiply, (Succ(Var(0)), Var(1))))
    seeded_count = Program("seeded_count", "initialized", 0, None, Succ(Var(1)))
    seeded_pred = Program("seeded_predecessor", "initialized", 0, None, Var(0))
    seeded_sum = Program("seeded_sum", "initialized", 1, None, add_step)
    seeded_fact = Program("seeded_factorial", "initialized", 0, None, factorial_step)
    seeded_select = Program("seeded_selector", "initialized", 1, None, Var(1))
    initialized_examples: list[tuple[Program, list[tuple[int, ...]], Callable]] = [
        (seeded_count, [(n, a) for n in range(9) for a in range(7)],
         lambda n, a: n + a),
        (seeded_pred, [(n, a) for n in range(9) for a in range(7)],
         lambda n, a: a if n == 0 else n - 1),
        (seeded_sum, [(n, a, b) for n in range(7) for a in range(5) for b in range(5)],
         lambda n, a, b: a + n * b),
        (seeded_fact, [(n, a) for n in range(6) for a in range(5)],
         lambda n, a: a * math.factorial(n)),
        (seeded_select,
         [(n, a, b) for n in range(5) for a in range(4) for b in range(4)],
         lambda n, a, b: a if n == 0 else b),
    ]
    initialized_rows = []
    for program, samples, expected in initialized_examples:
        original = identity_call(program)
        reverse = compilers.reverse(original)
        roundtrip = compilers.forward(reverse)
        for term in (original, reverse, roundtrip):
            validate_description(term.program)
        check("redundant_seed_syntax", roundtrip.program.parameters == program.parameters + 1,
              "round trip must introduce the seed as an extra frozen parameter")
        check("redundant_seed_syntax", roundtrip.arguments[1] == Var(1),
              "round-trip seed has changed")
        check("redundant_seed_syntax", roundtrip.arguments[2] == Var(1),
              "extra frozen seed argument is missing")
        for args in samples:
            source = evaluate_term(original, args)
            check("initialized_standard_values", source == expected(*args),
                  f"initialized standard value: {program.name} {args}")
            check("initialized_reverse_translation", evaluate_term(reverse, args) == source,
                  f"initialized reverse translation: {program.name} {args}")
            check("initialized_roundtrip", evaluate_term(roundtrip, args) == source,
                  f"initialized round trip: {program.name} {args}")
        initialized_rows.append({"name": program.name, "samples": len(samples)})
    return {
        "ordinary_examples": ordinary_rows,
        "initialized_examples": initialized_rows,
        "ordinary_sample_tuples": sum(row["samples"] for row in ordinary_rows),
        "initialized_sample_tuples": sum(row["samples"] for row in initialized_rows),
        "forward_symbols_constructed": len(compilers.forward_symbols),
        "reverse_symbols_constructed": len(compilers.reverse_symbols),
        "evaluator_cache_entries": evaluate_program.cache_info().currsize,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="also write the JSON report to this path")
    args = parser.parse_args()
    metrics = metric_diagnostics()
    arithmetic = arithmetic_diagnostics()
    compilers = compiler_diagnostics()
    report = {
        "status": "all finite diagnostics passed",
        "scope": [
            "Independent formula AST counts include universal closures and selected bodies.",
            "Recurrence, equality-bit, and Boolean tests use standard natural-number inputs.",
            "Two syntax-directed compilers operate on finite acyclic description DAGs.",
            "The initialized round trip explicitly retains its redundant frozen seed.",
        ],
        "limitations": [
            "These finite diagnostics are not proofs about arbitrary or nonstandard models.",
            "The written proof establishes native equality reflection and bi-interpretability.",
            "No end-to-end first-order proof checker or interpretation certificate is claimed.",
            "The external Python evaluator is not a primitive-recursive universal evaluator.",
            "The partial node ledger omits full syntax encodings and is not a global minimum.",
        ],
        "checks_by_category": dict(sorted(COUNTS.items())),
        "total_checks": sum(COUNTS.values()),
        "arithmetic_and_boolean_scope": arithmetic,
        "compiler_scope": compilers,
        "metric_rows": metrics,
    }
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")


if __name__ == "__main__":
    main()
