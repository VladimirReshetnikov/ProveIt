PRA WITH ONE EQUATION AND A FIXED ZERO CASE
Prepared for Vladimir Reshetnikov, 1 November 2026

MAIN RESULT
The complete basis is in AXIOMS.txt and on the first numbered page of
report.pdf. Initialized ordinary recursion, 0 != S0, and the schema

  [forall n ((n=0 or E(n)) -> E(Sn))]
      -> forall n (n=0 or E(n))

suffice when E is a single equation between arbitrary finite terms with
all finite fixed parameter tuples. In each ambient logic, classical or
intuitionistic, the result has a common conservative definitional
extension with ordinary first-order PRA. Both interpretations keep the
whole carrier and native equality; both composites are internally the
identity.

NEW MATHEMATICAL STEP
Equation induction plus constructor coverage already yields full
quantifier-free induction. Two separate equation invariants for two
ordinary accumulator recursions establish native equality reflection.
The previous arbitrary comparison-disjunction induction is unnecessary.

EXACT COMPARISON
For k frozen recursion parameters and q induction parameters:
  new basis:                        53 + 6k + 7q
  previous two-equation basis:      77 + 6k + 17q
Thus the previously used k=0,q=1 profile decreases from 94 to 60.
These are partial syntax-tree counts, not invariant description lengths.

The earlier unrestricted quantifier-free FORMULA schema still has a
shorter displayed basis: 38 + 6k + 5q. It has a different placeholder
grammar. The report does not claim a global simplest axiomatization.

A secondary combination of the current fresh-probe and inline-swap
schemata has partial display-plus-selected-body sum 52 + 6k + 6q,
compared with 54 + 6k + 5q for the current three-program fresh-probe
basis. This improvement is mixed in parameter arity and inherits the
underlying swap equivalence theorem from the cited drafts.

FILES
  report.tex, sections/*.tex     Complete article source
  report.pdf                    Compiled article
  AXIOMS.txt                    Exact standalone specification
  formal/GuardedEquation.lean    Constructive checked reconstruction kernel
  formal/GuardedEquation.log     Actual Lean 4.19.0 verification output
  formal/lean-toolchain          Required version
  formal/SCOPE.txt               Precise boundary of formal verification
  artifacts/checks.py            Stdlib diagnostics, syntax compilers, AST counts
  artifacts/results.json         Executed diagnostics and exact count ledger
  audit/source_manifest.json     Immutable source URLs and source hashes
  audit/mathematical_review.txt  Independent mathematical audit
  audit/*.log, audit/*.json      Build and validation records
  SHA256SUMS.txt                 Hashes of delivered package members
  build.py                      Rebuild script

REBUILD
  python3 build.py
Requires Python 3.10+ and a standard TeX Live installation.
Optional formal recheck with Lean 4.19.0:
  python3 build.py --lean /path/to/lean
or:
  lean formal/GuardedEquation.lean

VERIFICATION SCOPE
The Lean file proves the arithmetic and Boolean reconstruction over an
arbitrary carrier and admitted-term interface. The actual finite
description grammar, both interpretation compilers, their internal
round trips, and automorphism arguments are mathematical proofs in the
article, not a complete first-order proof-assistant formalization.
All 17 printed Lean endpoints have no additional global axiom
dependencies; they remain conditional on the explicitly stated basis.

The 21,210 finite checks diagnose transcription, arithmetic functions,
Boolean encodings, syntax counts, and sample compiler round trips.
They are not proofs about arbitrary or nonstandard models.

PROVENANCE
Six current archives were read at:
  https://github.com/VladimirReshetnikov/ProveIt/tree/bd7c1189f8d75f1cf738c156d8c376158de16460/docs/drafts
Their bytes match the recorded Git blob hashes. No changes to the
GitHub repository are part of this delivery. The Lean kernel explicitly
attributes its reusable arithmetic and Boolean code to the supplied
TwoEquation.lean; the guarded principle and accumulator proof replace
its two-equation induction and comparison argument.

