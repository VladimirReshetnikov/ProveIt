#!/usr/bin/env python3
"""Rebuild the numerical diagnostics and paper; optionally recheck Lean."""
from __future__ import annotations
import argparse
import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def run(command, log, env=None):
    result = subprocess.run(command, cwd=ROOT, env=env, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log.write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}); see {log}")
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lean", help="Optional Lean 4.19.0 executable")
    args = parser.parse_args()
    audit = ROOT / "audit"
    build = ROOT / "build"
    audit.mkdir(exist_ok=True)
    build.mkdir(exist_ok=True)
    run([sys.executable, "artifacts/checks.py", "--output", "artifacts/results.json"],
        audit / "diagnostics.log")
    tex_env = dict(os.environ)
    epoch = int(datetime.datetime(2026, 11, 1, tzinfo=datetime.timezone.utc).timestamp())
    tex_env.setdefault("SOURCE_DATE_EPOCH", str(epoch))
    tex_env.setdefault("FORCE_SOURCE_DATE", "1")
    for number in range(1, 4):
        run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
             "-file-line-error", "-output-directory=build", "report.tex"],
            audit / f"latex-pass-{number}.log", tex_env)
    shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
    latex_log = (build / "report.log").read_text(encoding="utf-8", errors="replace")
    problems = [line for line in latex_log.splitlines()
                if ("Overfull " in line or "undefined" in line.lower()
                    or "Rerun to get" in line)]
    if problems:
        raise RuntimeError("Inspect final TeX log:\n" + "\n".join(problems))
    metadata = {
        "paper": "report.pdf",
        "latex_passes": 3,
        "undefined_references": False,
        "overfull_boxes": False,
        "diagnostic_result": "artifacts/results.json",
        "lean_requested": bool(args.lean),
        "visual_review": "Required separately; compilation does not check layout."
    }
    if args.lean:
        version = subprocess.run([args.lean, "--version"], text=True,
                                 capture_output=True, check=True)
        run([args.lean, "formal/GuardedEquation.lean"],
            ROOT / "formal/GuardedEquation.log")
        metadata["lean_version"] = version.stdout.strip()
        metadata["lean_exit_code"] = 0
    (audit / "build.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps(metadata, indent=2))

if __name__ == "__main__":
    main()

