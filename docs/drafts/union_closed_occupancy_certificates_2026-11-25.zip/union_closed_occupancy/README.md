# Occupancy-corrected deletion certificates

Research manuscript for ProveIt, 25 November 2026. Start with `paper.pdf`.

The principal contribution is Theorem 2.1, a two-stage deletion inequality for arbitrary support hypergraphs. It improves the first-stage deletion-repair theorem in the named repository draft by using a conditional occupancy cap. Consequences include strict pointwise half-frequency in linear regular systems at improved explicit degree thresholds, a girth-ten specialization, and an asymptotic degree saving of `(ln 2 + o(1))*2^(r-1)/r` relative to the predecessor's uniform sufficient formula.

## Contents

- `paper.tex`: full mathematical argument and references.
- `paper.pdf`: compiled manuscript.
- `verify.py`: standard-library Python integer-interval threshold checker and independent finite audits of conditional occupancy, deletion, and duality.
- `thresholds.csv`: exact-arithmetic certified numerical bounds (outward-rounded displayed decimals).
- `verification.txt`: actual output of the verifier.
- `provenance.md`: repository and literature review, limitations.
- `Makefile`: reproduction commands.
- `SHA256SUMS`: hashes of the supplied files.

## Reproduce

From this directory, run `sha256sum -c SHA256SUMS` before rebuilding; then run `make verify` and `make pdf`. Python 3.10+ and a standard LaTeX distribution are sufficient. No Internet access or nonstandard Python packages are required. The PDF may acquire different metadata on recompilation.

The numerical inequalities are certified by integer arithmetic, with no floating-point sign decisions. The exhaustive small-instance and seeded random audits complement, but do not replace, the general mathematical proofs. No proof assistant verification or independent referee review is claimed. The general conjecture and historical novelty remain open; no new universal constant is claimed. No changes were made to the GitHub repository.
