#!/usr/bin/env python3
"""Outward-rounded integer interval certificates and independent finite audits."""
from dataclasses import dataclass
from fractions import Fraction
from itertools import combinations
from math import comb
import random, csv
from pathlib import Path

SCALE = 10**36

def check(condition, message):
    if not condition:
        raise AssertionError(message)

def ceildiv(a,b): return -(-a//b)

@dataclass(frozen=True)
class I:
    lo: int
    hi: int
    @staticmethod
    def make(n, d=1):
        return I(n*SCALE//d, ceildiv(n*SCALE,d))
    def __add__(self,other): return I(self.lo+other.lo,self.hi+other.hi)
    def __sub__(self,other): return I(self.lo-other.hi,self.hi-other.lo)
    def __mul__(self,other):
        check(self.lo>=0 and other.lo>=0,'nonnegative product')
        return I(self.lo*other.lo//SCALE,ceildiv(self.hi*other.hi,SCALE))
    def inv(self):
        check(self.lo>0,'positive denominator')
        return I(SCALE*SCALE//self.hi,ceildiv(SCALE*SCALE,self.lo))
    def __pow__(self,n):
        check(isinstance(n,int) and n>=0,'integer exponent')
        y=I.make(1); x=self
        while n:
            if n&1: y=y*x
            n//=2
            if n: x=x*x
        return y
    def lower_decimal(self, places=6):
        a=self.lo*10**places//SCALE
        return f'{a//10**places}.{a%10**places:0{places}d}'
    def upper_decimal(self, places=6):
        a=ceildiv(self.hi*10**places,SCALE)
        return f'{a//10**places}.{a%10**places:0{places}d}'

ONE=I.make(1); ZERO=I.make(0)

def bound(r,d,mode):
    q=I.make(2**(r-1)-1,2**(r-1)); n=d-1
    u=q**n; z=ONE-u; m=(r-1)*n
    total=ZERO; groups=[]
    for s in range(1,r+1):
        if mode=='old': h=ONE
        elif mode=='new':
            R=(ONE-q**(n-s))**m*(ONE-q**(n+1-s))**(r-2)
            h=(ONE+R).inv()
        elif mode=='girth': h=(ONE+z**((r-1)*d-1)).inv()
        else: raise ValueError(mode)
        b=ONE-h*u
        if s>=2 and mode!='girth': groups.append(q**(s-1)*(I.make(2)-h*u))
        total=total+I.make(comb(r,s))*z**(r-s)*b**(s*m)
    return total, groups

ROWS=[(3,11,11,10),(4,32,31,30),(5,81,79,79),(6,195,192,191),
      (7,451,446,445),(8,1021,1011,1011)]

def certificates():
    rows=[]
    for r,*ds in ROWS:
        row={'r':r}
        for mode,d in zip(('old','new','girth'),ds):
            check(d-1>r and d-2>=2**(r-1)-1, 'monotone branch')
            val, groups=bound(r,d,mode)
            prev, _=bound(r,d-1,mode)
            check(val.lo>SCALE, f'{mode}, r={r}: crossing')
            check(prev.hi<SCALE, f'{mode}, r={r}: previous crossing')
            check(all(x.lo>=SCALE for x in groups), f'{mode}, r={r}: grouping')
            freq=ONE-(ONE+val).inv()
            row.update({f'{mode}_d':d,f'{mode}_previous_S_upper':prev.upper_decimal(9),
                        f'{mode}_S_lower':val.lower_decimal(9),
                        f'{mode}_freq_lower':freq.lower_decimal(9)})
        # Compare new/girth against old at the same old threshold.
        for mode in ('new','girth'):
            a,_=bound(r,ds[0],mode); b,_=bound(r,ds[0],'old')
            check(a.lo>b.hi,'strict improvement at old threshold')
        rows.append(row)
    p=Path(__file__).with_name('thresholds.csv')
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader();w.writerows(rows)
    print('Exact interval threshold certificates (scale 10^36):')
    for row in rows:
        print('r=%d: old=%d, new=%d, girth=%d; new f >= %s, girth f >= %s'%
              (row['r'],row['old_d'],row['new_d'],row['girth_d'],row['new_freq_lower'],row['girth_freq_lower']))


def bits(x):
    while x:
        b=x&-x; yield b; x-=b

def hull(y,edges):
    a=0
    for e in edges:
        if e&y==e: a|=e
    return a

def petal_failure(edges, fixed):
    # Greedy disjoint-petal collection. Zero residual petals are allowed.
    used=0; result=Fraction(1)
    for e in sorted(edges,key=lambda e:(e&~fixed).bit_count()):
        p=e&~fixed
        if p&used: continue
        used|=p
        result*=1-Fraction(1,2**p.bit_count())
    return result

def audit_system(n,edges, rng, all_anchors=False):
    universe=(1<<n)-1
    supported=[y for y in range(1<<n) if hull(y,edges)==y]
    # Independently form all primal distinct unions and compare marked frequencies.
    generators=[sum(1<<j for j,e in enumerate(edges) if e&v) for v in bits(universe)]
    primal={0}
    for g in generators: primal|={a|g for a in primal}
    check(len(primal)==len(supported),'duality size')
    for j,e in enumerate(edges):
        check(sum(not(a&(1<<j)) for a in primal)==sum(y&e==e for y in supported),'duality marked absence')
    anchors=list(edges)
    if not all_anchors:
        anchors=rng.sample(anchors,min(3,len(anchors)))
        if len(edges)>1:
            e,f=rng.sample(list(edges),2); anchors.append(e|f)
    occupancy_checks=trace_checks=0
    for A in anchors:
        C0=[y for y in supported if y&A==A]
        Ds=[d for d in range(1,A+1) if d&A==d]
        if len(Ds)>14: Ds=rng.sample(Ds,14)
        for D in Ds:
            safe=[e for e in edges if not(e&D)]
            W=hull(universe,[e for e in edges if e&D])&~D
            safe_hulls={y:hull(y,safe) for y in C0}
            R={}; rho={}
            for w in bits(W):
                rho[w]=petal_failure([e for e in safe if e&w],A|w)
                if w&A: continue
                neighbors=hull(universe,[e for e in edges if e&w])&~w&~D
                result=Fraction(1)
                for u in bits(neighbors):
                    rr=petal_failure([e for e in safe if e&u and not(e&w)],A|w|u)
                    result*=1-rr
                R[w]=result
            # Check exact stage-by-stage occupancy and loss, and the combined trace inequality.
            order=list(bits(W)); rng.shuffle(order)
            C=C0[:]; prod=Fraction(1); old=Fraction(1)
            for w in order:
                H=Fraction(1) if w&A else 1/(1+R[w])
                present=sum(bool(y&w) for y in C)
                check(present<=H*len(C),'conditional occupancy cap')
                occupancy_checks+=1
                nextC=[y for y in C if not(y&w) or safe_hulls[y]&w]
                check(len(nextC)>=(1-H*rho[w])*len(C),'stage bound')
                C=nextC;prod*=1-H*rho[w];old*=1-rho[w]
            N_D=sum(y&A==A^D for y in supported)
            check(len(C)==N_D,'trace bijection')
            check(N_D>=prod*len(C0),'refined trace inequality')
            check(prod>=old,'dominates predecessor')
            trace_checks+=1
    return occupancy_checks,trace_checks

def audits():
    rng=random.Random(20261125); systems=[]
    # All nonempty simple 3-uniform hypergraphs on four vertices, including nonlinear ones.
    triples=[sum(1<<i for i in c) for c in combinations(range(4),3)]
    for m in range(1,1<<len(triples)):
        systems.append((4,[e for i,e in enumerate(triples) if m>>i&1],True))
    # Diverse random nonuniform systems; no assumption of linearity for the general theorem.
    for _ in range(32):
        n=rng.randint(4,8)
        es=sorted(set(rng.randrange(1,1<<n) for _ in range(rng.randint(2,12))))
        systems.append((n,es,False))
    # Cyclic Steiner triple system STS(13), all pair incidences exactly one.
    sts=sorted({sum(1<<((v+i)%13) for v in b) for b in [(0,1,4),(0,2,7)] for i in range(13)})
    check(len(sts)==26 and all(sum((e>>i&1) and (e>>j&1) for e in sts)==1 for i,j in combinations(range(13),2)),'STS(13)')
    systems.append((13,sts,False))
    # Loose path and loose cycle of triples (sparse examples).
    systems.append((9,[7,28,112,448],True))
    systems.append((8,[7,28,112,193],True))
    checks=[0,0]
    for n,edges,aa in systems:
        x,y=audit_system(n,edges,rng,aa);checks[0]+=x;checks[1]+=y
    print(f'Exact finite audits: {len(systems)} systems; {checks[0]} conditional occupancy/stage checks; {checks[1]} trace identities and inequalities.')
    print('All checks passed. Finite tests are supplementary; the general proof is in paper.tex.')

if __name__=='__main__':
    certificates();audits()
