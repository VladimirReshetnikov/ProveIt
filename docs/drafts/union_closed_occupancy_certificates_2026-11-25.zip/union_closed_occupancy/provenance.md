# Provenance and scope

## Repository audit

Read-only GitHub connector retrieval of `VladimirReshetnikov/ProveIt`, `main`, `docs/drafts`, on 25 November 2026. The directory listed 35 ZIP archives and `.gitkeep`. Six archives were decoded from their GitHub base64 blob representations to inspect their README and LaTeX abstract and section headings. For the deletion-repair archive, the full sections on support duality, the conditional deletion theorem, and the uniform degree calculation were also extracted and read, including their proofs. The present result builds on that specific theorem and compares its explicit uniform degree bound, not an optimal implementation of all of its local certificates.

| Archive | Blob SHA |
|---|---|
| union_closed_deletion_repair_2026-11-25.zip | 91723c866b8a7e50af44cb3ac3682a243fab2108 |
| union_closed_rank_transport_2026-11-25.zip | f4c375d5ae9b7337ed4e542950da3d602be537be |
| union_closed_sharp_trace_obstructions_2026-11-25.zip | bef1e8104a5bc31e1246f27867e88a73441a4423 |
| union_closed_signature_interfaces_2026-11-25.zip | 7d715274e013371d5d4156b461f970c50c1f9c00 |
| union_closed_redundant_core_2026-11-25.zip | 18cd1e26f63dee50486533964e3fbf085660af09 |
| union_closed_antichain_shadows_2026-11-25.zip | ce0aa9b6412a1196261afacbb8deb9954fb7ead7 |

Directory: https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts

The other 29 archives were listed but their contents were not inspected. In particular this is not an exhaustive internal priority search. The existing deletion-repair draft's proof was used as a mathematical antecedent; the additional occupancy bound, its use in the first-stage repair, the explicit new formulas and asymptotic comparison were derived here. No changes were made to the repository.

## Public literature consulted

- https://en.wikipedia.org/wiki/Union-closed_sets_conjecture — statement and background.
- https://arxiv.org/abs/2211.09055 — Gilmer's positive universal bound.
- https://arxiv.org/abs/2610.02295 — Costa and Sadhu's October 2026 preprint, reporting 0.3828852549667978.
- https://quantavane.com/major-results/union-closed-sets-conjecture/ — November 2026 online report claiming 0.38317525996679..., not independently audited.
- https://arxiv.org/abs/math/9409215 — Knill's graph-generated union-closed families and local counting; abstract inspected.
- https://www.sciencedirect.com/science/article/pii/S0195669814001425 — Bruhn et al., graph formulation of the conjecture and restricted cases (abstract inspected).
- https://www.tandfonline.com/doi/full/10.1080/10586458.2024.2410964 — Pulaj and Wood, local configurations (abstract inspected).

Searches included current universal bounds, graph/lattice formulations, and targeted combinations of union-closed families, support hypergraphs, local counting, deletion, occupancy, girth, and regularity. No exact match for the two-stage occupancy certificate or its thresholds was found in the sources inspected. This is limited evidence; it does not establish priority over the full literature or other drafts. The numerical comparisons and proofs are self-contained and do not depend on any of the recent universal-bound claims.
