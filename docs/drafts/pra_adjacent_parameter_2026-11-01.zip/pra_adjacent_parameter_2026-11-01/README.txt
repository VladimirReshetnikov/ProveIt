PRA FROM ONE TERM AT ADJACENT PARAMETERS
Prepared for Vladimir Reshetnikov, 1 November 2026 (America/Los_Angeles).

MAIN RESULT
The proposed classical theory is definitionally equivalent to classical
first-order PRA. The same nonlogical theory in intuitionistic logic is
definitionally equivalent to intuitionistic first-order PRA. Both directions
preserve the full carrier and native equality, with identity round trips.

The sole input is a binary term u(n,a), and the equation used by the schema
is u(n,a)=u(n,S(a)). Computation axioms are attached through h_u(v)=u(v,0).
There is one axiom constructor and no additional diagonal identity.

START HERE
  report.pdf             Complete mathematical paper.
  AXIOMS.txt             Exact standalone nonlogical specification.
  report.tex             Main LaTeX source.
  sections/              All mathematical source sections and appendices.
  formal/AdjacentKernel.lean
                         Constructive Lean proof kernel.
  formal/SCOPE.txt        Exact machine-verification boundary.
  checks/check_schema.py  Reproducible syntax and bounded arithmetic checks.
  checks/results.json    Recorded diagnostic results.
  checks/examples.txt    Fully emitted example axioms.
  audit/source_manifest.json
                         Pinned comparison archives and hashes.
  audit/mathematical_review.txt
                         Independent mathematical review.
  build.py               Rebuild the PDF and run checks.
  SHA256SUMS.txt          Checksums of packaged files, excluding this list.

REBUILD
Requires Python 3.10+ and a LaTeX installation providing pdflatex plus the
packages listed in report.tex. No Python third-party modules are required
for the checker or build script.

  python3 build.py

To also recheck the Lean kernel with Lean 4.19.0:

  python3 build.py --lean /absolute/path/to/lean

Alternatively:
  python3 checks/check_schema.py
  lean formal/AdjacentKernel.lean
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

SCOPE
The complete bi-interpretation is a written proof. The Lean file checks
the new local reduction, not the entire first-order theory. Finite tests
are diagnostics, not consistency proofs. "Simpler" means the explicit
structural comparison in the report; no global minimality is claimed.
No historical novelty claim beyond the inspected drafts is made.

COMPARISON REVISION
VladimirReshetnikov/ProveIt, d605be20835fc80907e01a105bcb059f07ed8b8c.
Three archives were present and inspected: pra_one_schema,
pra_one_term_diagonal, and pra_short_propagation, all dated 2026-11-01.
This package does not modify the remote repository.
