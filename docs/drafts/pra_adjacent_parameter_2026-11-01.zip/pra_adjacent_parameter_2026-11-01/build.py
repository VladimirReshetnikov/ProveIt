#!/usr/bin/env python3
"""Rebuild the report and reproducible checks; no third-party Python modules."""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
AUDIT = ROOT / "audit"


def run(command, log_name):
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    output = result.stdout + result.stderr
    (AUDIT / log_name).write_text(output, encoding="utf-8")
    if result.returncode:
        print(output[-12000:], file=sys.stderr)
        raise RuntimeError(f"Command failed ({result.returncode}): {command[0]}")
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Path to Lean 4.19.0 (optional)")
    args = parser.parse_args()
    AUDIT.mkdir(exist_ok=True)
    results = {}
    run([sys.executable, "checks/check_schema.py"], "python_check.log")
    results["diagnostics"] = json.loads(
        (ROOT / "checks/results.json").read_text(encoding="utf-8")
    )

    if args.lean:
        version = run([args.lean, "--version"], "lean_version.log").strip()
        output = run([args.lean, "formal/AdjacentKernel.lean"], "lean_check.log")
        audited = output.count("does not depend on any axioms")
        if audited != 15 or "sorryAx" in output or "error:" in output:
            raise RuntimeError("Unexpected Lean audit output")
        results["lean"] = {"version": version, "audited_theorems": audited,
                           "axiom_dependencies": [], "scope": "formal/SCOPE.txt"}
    else:
        results["lean"] = {"status": "not rerun; supply --lean to verify locally",
                           "scope": "formal/SCOPE.txt"}

    latex = shutil.which("pdflatex")
    if not latex:
        raise RuntimeError("pdflatex is required to compile the report")
    for number in range(1, 4):
        run([latex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            f"latex_pass_{number}.log")
    log = (ROOT / "report.log").read_text(encoding="utf-8", errors="replace")
    unresolved = [line for line in log.splitlines()
                  if "undefined" in line.lower() or "Overfull" in line]
    if unresolved:
        raise RuntimeError("LaTeX layout/reference diagnostics: " + " | ".join(unresolved))
    results["latex"] = {"passes": 3, "undefined_references": 0,
                        "overfull_boxes": 0, "pdf_bytes": (ROOT / "report.pdf").stat().st_size}
    (AUDIT / "build_results.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8")
    for suffix in ("aux", "log", "out", "toc"):
        (ROOT / f"report.{suffix}").unlink(missing_ok=True)
    lines = []
    for path in sorted(ROOT.rglob("*")):
        if path.is_file() and path.name != "SHA256SUMS.txt" and "__pycache__" not in path.parts:
            lines.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(ROOT)}")
    (ROOT / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"pdf": str(ROOT / "report.pdf"), "checks": "passed",
                      "lean": results["lean"], "latex": results["latex"]}, indent=2))


if __name__ == "__main__":
    main()
