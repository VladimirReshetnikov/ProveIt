#!/usr/bin/env python3
"""Reproducible syntax checks and bounded diagnostics for adjacent-slice PRA.

Python 3.10+, standard library only. Run this file to regenerate results.json
and examples.txt beside it. A failed check raises an exception and exits nonzero.

The term AST distinguishes active arguments from a frozen iterator descriptor.
These checks do not prove the infinite schema, consistency, bi-interpretability,
or the correctness of the paper's full arithmetic construction.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple[Term, ...] = ()
    name: str = ""
    body: Term | None = None


def var(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")
n, a, v = (var(name) for name in ("n", "a", "v"))


def succ(x: Term) -> Term:
    return Term("succ", (x,))


ONE = succ(ZERO)


def delayed(body: Term, counter: Term, seed: Term) -> Term:
    return Term("delay", (counter, seed), body=body)


def iterate(body: Term, counter: Term, seed: Term) -> Term:
    return delayed(body, succ(counter), seed)


def substitute(t: Term, replacements: dict[str, Term]) -> Term:
    """Simultaneous active substitution: NEVER enter t.body."""
    if t.tag == "var":
        return replacements.get(t.name, t)
    return Term(t.tag, tuple(substitute(x, replacements) for x in t.args),
                t.name, t.body)


def free_variables(t: Term) -> set[str]:
    if t.tag == "var":
        return {t.name}
    return set().union(*(free_variables(x) for x in t.args))


def validate(t: Term, allowed: set[str], *, template: bool = False) -> None:
    arity = {"var": 0, "zero": 0, "succ": 1, "delay": 2}
    if template:
        arity["hole"] = 2
    if t.tag not in arity or len(t.args) != arity[t.tag]:
        raise ValueError(f"Malformed or inadmissible term: {t.tag}")
    if t.tag == "var" and t.name not in allowed:
        raise ValueError(f"Variable {t.name!r} outside {sorted(allowed)}")
    if t.tag == "delay":
        if t.body is None:
            raise ValueError("An iterator has no descriptor")
        validate(t.body, {"v"}, template=template)
    elif t.body is not None:
        raise ValueError("Only an iterator may carry a descriptor")
    for child in t.args:
        validate(child, allowed, template=template)


def term_nodes(t: Term, *, stored: bool = False) -> int:
    result = 1 + sum(term_nodes(x, stored=stored) for x in t.args)
    if stored and t.body is not None:
        result += term_nodes(t.body, stored=True)
    return result


def occurrences(t: Term, name: str) -> int:
    return int(t.tag == "var" and t.name == name) + sum(
        occurrences(x, name) for x in t.args)


def rank(t: Term) -> int:
    values = [0] + [rank(x) for x in t.args]
    if t.body is not None:
        values.append(1 + rank(t.body))
    return max(values)


def descriptors(t: Term) -> set[Term]:
    result = set().union(*(descriptors(x) for x in t.args))
    if t.body is not None:
        result.add(t.body)
        result.update(descriptors(t.body))
    return result


def print_term(t: Term) -> str:
    if t.tag == "var":
        return t.name
    if t.tag == "zero":
        return "0"
    if t.tag == "succ":
        return f"S({print_term(t.args[0])})"
    if t.tag == "delay":
        return (f"D[{print_term(t.body)}]("  # type: ignore[arg-type]
                f"{print_term(t.args[0])},{print_term(t.args[1])})")
    if t.tag == "hole":
        return f"{t.name}({','.join(print_term(x) for x in t.args)})"
    raise ValueError(t.tag)


@dataclass(frozen=True)
class Formula:
    tag: str
    args: tuple[Formula | Term, ...] = ()
    bound: str = ""


def eq(x: Term, y: Term) -> Formula:
    return Formula("eq", (x, y))


def binary(tag: str, x: Formula, y: Formula) -> Formula:
    return Formula(tag, (x, y))


def all_(name: str, f: Formula) -> Formula:
    return Formula("all", (f,), name)


def formula_nodes(f: Formula, *, stored: bool = False) -> int:
    return 1 + sum(term_nodes(x, stored=stored) if isinstance(x, Term)
                   else formula_nodes(x, stored=stored) for x in f.args)


def formula_free(f: Formula) -> set[str]:
    result = set().union(*(free_variables(x) if isinstance(x, Term)
                          else formula_free(x) for x in f.args))
    return result - {f.bound} if f.tag == "all" else result


def formula_names(f: Formula) -> set[str]:
    result = set().union(*(free_variables(x) if isinstance(x, Term)
                          else formula_names(x) for x in f.args))
    return result | ({f.bound} if f.tag == "all" else set())


def formula_descriptors(f: Formula) -> set[Term]:
    return set().union(*(descriptors(x) if isinstance(x, Term)
                         else formula_descriptors(x) for x in f.args))


def substitute_formula(f: Formula, replacements: dict[str, Term]) -> Formula:
    """Capture-avoiding formula substitution, still freezing descriptors."""
    if f.tag == "all":
        body = f.args[0]
        bound = f.bound
        remaining = {key: value for key, value in replacements.items()
                     if key != bound}
        relevant = {key: value for key, value in remaining.items()
                    if key in formula_free(body)}  # type: ignore[arg-type]
        if any(bound in free_variables(value) for value in relevant.values()):
            used = formula_names(body) | set(remaining)  # type: ignore[arg-type]
            for value in remaining.values():
                used.update(free_variables(value))
            index = 0
            while f"{bound}_{index}" in used:
                index += 1
            fresh = f"{bound}_{index}"
            body = substitute_formula(body, {bound: var(fresh)})
            bound = fresh
        return all_(bound, substitute_formula(body, remaining))
    return Formula(f.tag, tuple(substitute(x, replacements)
                                if isinstance(x, Term)
                                else substitute_formula(x, replacements)
                                for x in f.args), f.bound)


def quantifier_data(f: Formula, depth: int = 0) -> tuple[int, int]:
    next_depth = depth + int(f.tag == "all")
    count, maximum = int(f.tag == "all"), next_depth
    for child in f.args:
        if isinstance(child, Formula):
            child_count, child_maximum = quantifier_data(child, next_depth)
            count += child_count
            maximum = max(maximum, child_maximum)
    return count, maximum


def print_formula(f: Formula) -> str:
    if f.tag == "bot":
        return "false"
    if f.tag == "eq":
        return f"({print_term(f.args[0])}={print_term(f.args[1])})"
    if f.tag == "all":
        return f"forall {f.bound} ({print_formula(f.args[0])})"
    operator = {"and": "AND", "or": "OR", "imp": "->"}[f.tag]
    return f"({print_formula(f.args[0])} {operator} {print_formula(f.args[1])})"


def zero_section(u: Term) -> Term:
    return substitute(u, {"n": v, "a": ZERO})


def computation_package(h: Term) -> Formula:
    sigma = binary("imp", eq(ZERO, ONE), Formula("bot"))
    reset = eq(delayed(h, delayed(ONE, n, ZERO), a), a)
    tail = eq(delayed(h, succ(succ(n)), a),
              substitute(h, {"v": delayed(h, succ(n), a)}))
    return binary("and", sigma, binary("and", reset, tail))


def axiom(u: Term, *, template: bool = False) -> Formula:
    validate(u, {"n", "a"}, template=template)
    h = zero_section(u)
    equality = eq(u, substitute(u, {"a": succ(a)}))
    rooted = binary("or", eq(n, ZERO), equality)
    successor = substitute_formula(equality, {"n": succ(n)})
    premise = all_("n", binary("imp", rooted, successor))
    conclusion = all_("n", binary("and", rooted, computation_package(h)))
    return all_("a", binary("imp", premise, conclusion))


def old_two_term_axiom(s: Term, t: Term) -> Formula:
    """Only the exact one_schema comparison template, not a new theory."""
    h = substitute(s, {"n": v, "a": v})
    rooted = binary("or", eq(n, ZERO), eq(s, t))
    successor = substitute_formula(rooted, {"n": succ(n)})
    premise = all_("n", binary("imp", rooted, successor))
    conclusion = all_("n", binary("and", rooted, computation_package(h)))
    return all_("a", binary("imp", premise, conclusion))


@lru_cache(maxsize=None)
def unary_value(body: Term, value: int) -> int:
    return evaluate(body, {"v": value})


def evaluate(t: Term, environment: dict[str, int]) -> int:
    if t.tag == "zero":
        return 0
    if t.tag == "var":
        return environment[t.name]
    if t.tag == "succ":
        return 1 + evaluate(t.args[0], environment)
    if t.tag == "delay":
        counter = evaluate(t.args[0], environment)
        result = evaluate(t.args[1], environment)
        for _ in range(max(counter - 1, 0)):
            result = unary_value(t.body, result)  # type: ignore[arg-type]
        return result
    raise ValueError("Schematic holes have no numerical interpretation")


def pred(x: Term) -> Term:
    return delayed(succ(v), x, ZERO)


def z(counter: Term, seed: Term) -> Term:
    return iterate(ZERO, counter, seed)


def add(x: Term, y: Term) -> Term:
    return iterate(succ(v), y, x)


def selector(bit: Term, x: Term, y: Term) -> Term:
    return add(z(bit, x), z(z(bit, ONE), y))


def toggle(x: Term) -> Term:
    return iterate(z(v, ONE), x, ZERO)


CHECKS: dict[str, int] = {}


def check(group: str, condition: bool, detail: str = "") -> None:
    if not condition:
        raise AssertionError(f"{group}: {detail}")
    CHECKS[group] = CHECKS.get(group, 0) + 1


def expect_invalid(t: Term, *, dynamic: bool) -> None:
    try:
        if dynamic:
            axiom(t)
        else:
            validate(t, {"v"})
    except ValueError:
        check("invalid_syntax_rejected", True)
    else:
        raise AssertionError("Invalid syntax was admitted")


def main() -> None:
    legal_bodies = [v, ZERO, ONE, succ(v), pred(v), z(v, ONE)]
    samples = [n, a, ZERO, ONE, succ(n), succ(a)]
    samples += [delayed(h, counter, seed) for h in legal_bodies
                for counter in [n, a, ZERO, succ(n), succ(a)]
                for seed in [n, a, ZERO, ONE]]
    samples += [selector(a, n, n), selector(a, n, succ(pred(n))), toggle(a)]
    samples = list(dict.fromkeys(samples))

    for u in samples:
        f = axiom(u)
        size = 38 + 7 * term_nodes(u) + 5 * occurrences(u, "n")
        size += 3 * occurrences(u, "a")
        check("node_formula", formula_nodes(f) == size, print_term(u))
        check("closed_axioms", formula_free(f) == set())
        check("two_active_names", formula_names(f) <= {"n", "a"})
        check("quantifier_profile", quantifier_data(f) == (3, 2))
        h = zero_section(u)
        validate(h, {"v"})
        check("zero_section_rank", rank(h) == rank(u))
        check("zero_section_free_variables", free_variables(h) <= {"v"})

    for h in legal_bodies:
        u = substitute(h, {"v": n})
        check("descriptor_surjectivity", zero_section(u) == h)
        check("reflexive_extraction", substitute(u, {"a": succ(a)}) == u)

    nested_body = delayed(succ(v), v, ZERO)
    frozen = delayed(nested_body, n, a)
    changed = substitute(frozen, {"n": succ(a), "a": ZERO, "v": ONE})
    check("frozen_descriptors", changed.body is frozen.body)
    check("frozen_descriptors", changed.body == nested_body)
    check("simultaneous_substitution", changed.args == (succ(a), ZERO))
    captured = substitute_formula(all_("a", eq(n, a)), {"n": a})
    check("capture_avoidance", formula_free(captured) == {"a"})
    check("capture_avoidance", captured.bound != "a")
    shadowed = substitute_formula(all_("n", eq(n, a)), {"n": ZERO})
    check("bound_variable_protection", shadowed == all_("n", eq(n, a)))
    expect_invalid(var("b"), dynamic=True)
    expect_invalid(delayed(n, n, a), dynamic=True)
    expect_invalid(Term("hole", (n, a), "U"), dynamic=True)

    u_hole = Term("hole", (n, a), "U")
    s_hole = Term("hole", (n, a), "S_hole")
    t_hole = Term("hole", (n, a), "T_hole")
    template_counts = {
        "current_one_schema_two_binary_holes":
            formula_nodes(old_two_term_axiom(s_hole, t_hole)),
        "new_adjacent_slices_one_binary_hole":
            formula_nodes(axiom(u_hole, template=True)),
    }
    check("template_counts", template_counts == {
        "current_one_schema_two_binary_holes": 72,
        "new_adjacent_slices_one_binary_hole": 67,
    })

    bound = 6
    for h in legal_bodies:
        for counter in range(bound + 1):
            for seed in range(bound + 1):
                env = {"n": counter, "a": seed}
                check("reset_values", evaluate(
                    delayed(h, delayed(ONE, n, ZERO), a), env) == seed)
                check("tail_values", evaluate(delayed(h, succ(succ(n)), a), env)
                      == unary_value(h, evaluate(delayed(h, succ(n), a), env)))
        for seed in range(bound + 1):
            check("seed_values", evaluate(delayed(h, ZERO, a), {"a": seed})
                  == seed)
            check("seed_values", evaluate(delayed(h, ONE, a), {"a": seed})
                  == seed)

    for x in range(bound + 1):
        for y in range(bound + 1):
            env = {"n": x, "a": y}
            check("weak_selector_values", evaluate(selector(ZERO, n, a), env)
                  == x)
            check("weak_selector_values", evaluate(selector(ONE, n, a), env)
                  == evaluate(pred(succ(a)), env))
            for bit in range(bound + 1):
                check("successor_selector_values", evaluate(
                    selector(succ(var("b")), n, a), {**env, "b": bit}) == y)

    for value in range(2 * bound + 1):
        env = {"a": value}
        bit = evaluate(toggle(a), env)
        check("predecessor_values", evaluate(pred(succ(a)), env) == value)
        check("toggle_values", bit in (0, 1))
        check("toggle_values", evaluate(toggle(succ(a)), env) == 1 - bit)

    splice_terms = [n, a, ZERO, succ(n), succ(a), pred(n),
                    add(n, a), z(n, a)]
    splice_bound = 8
    for s in splice_terms:
        for t in splice_terms:
            shifted_t = substitute(t, {"a": pred(a)})
            u0 = selector(toggle(a), s, shifted_t)
            u1 = selector(toggle(a), shifted_t, s)
            for counter in range(splice_bound + 1):
                for parameter in range(splice_bound + 1):
                    env = {"n": counter, "a": parameter}
                    u = u0 if evaluate(toggle(a), env) == 0 else u1
                    check("splice_left_values", evaluate(u, env) == evaluate(s, env))
                    check("splice_right_values", evaluate(
                        substitute(u, {"a": succ(a)}), env) == evaluate(t, env))

    examples = []
    example_rows = []
    for u in [n, a, succ(n), succ(a)]:
        f = axiom(u)
        example_rows.append({
            "input": print_term(u),
            "zero_section": print_term(zero_section(u)),
            "active_nodes": formula_nodes(f),
            "nodes_with_stored_bodies_repeated": formula_nodes(f, stored=True),
            "distinct_descriptors": len(formula_descriptors(f)),
        })
        examples.extend([
            f"INPUT u(n,a) = {print_term(u)}",
            f"ZERO SECTION h(v) = {print_term(zero_section(u))}",
            f"ACTIVE NODES = {formula_nodes(f)}",
            "EXACT EMITTED FORMULA (stored descriptor bodies in brackets):",
            print_formula(f), "",
        ])

    output = Path(__file__).resolve().parent
    result = {
        "status": "passed",
        "scope": ("Finite syntax checks and bounded standard-natural-number "
                  "diagnostics; not a proof of consistency, the infinite "
                  "schema, or bi-interpretability."),
        "sample_input_terms": len(samples),
        "active_count_formula": "38 + 7*|u| + 5*#n(u) + 3*#a(u)",
        "count_convention": ("One node per active variable, constant, function "
                             "application, equality, connective or quantifier; "
                             "descriptor labels are stored separately; 1=S(0)."),
        "template_count_warning": ("The holes are schematic binary builders, "
                                   "not arithmetic function symbols. These "
                                   "counts imply no uniform instance-size bound."),
        "template_counts": template_counts,
        "numerical_bounds_inclusive": {"computation_and_selector": bound,
                                       "toggle": 2 * bound,
                                       "splice_counter_and_parameter": splice_bound},
        "splice_term_pairs": len(splice_terms) ** 2,
        "checks_by_group": CHECKS,
        "total_checks": sum(CHECKS.values()),
        "examples": example_rows,
    }
    (output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    header = ("ADJACENT-SLICE AXIOM GENERATOR: EXACT FINITE EXAMPLES\n\n"
              "All active abbreviations are expanded. D[body](x,y) retains\n"
              "its frozen unary descriptor body; variable substitution never\n"
              "enters those brackets. These examples are not a finite\n"
              "axiomatization and the numerical diagnostics are not proofs.\n\n")
    (output / "examples.txt").write_text(header + "\n".join(examples))
    print(json.dumps({"status": result["status"],
                      "sample_input_terms": len(samples),
                      "total_checks": result["total_checks"],
                      "template_counts": template_counts}, indent=2))


if __name__ == "__main__":
    main()
