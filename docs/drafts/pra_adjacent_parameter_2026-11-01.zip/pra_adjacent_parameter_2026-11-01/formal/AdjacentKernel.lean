import Std

/-!
Constructive proof kernel for adjacent-parameter propagation.

Scope: this file checks the arithmetic bootstrap and the two-compiler transfer
from the selected adjacent-equality schema instances to equation propagation.
Terms are represented by functions over an arbitrary type. No assertion is
made here that quantification over these functions is object-language syntax.
The paper supplies the finite-term grammar, the computation extraction, and
the full PRA interpretation. No classical reasoning is used in this file.
-/

namespace AdjacentKernel

universe u v

variable {A : Type u} {B : Type v}

def Rooted (zero : A) (left right : A → A) (n : A) : Prop :=
  n = zero ∨ left n = right n

def Adjacent (zero : A) (succ : A → A) (term : A → A → A) : Prop :=
  ∀ a, (∀ n, Rooted zero (fun k => term k a) (fun k => term k (succ a)) n →
    term (succ n) a = term (succ n) (succ a)) →
    ∀ n, Rooted zero (fun k => term k a) (fun k => term k (succ a)) n

def Propagation (zero : A) (succ : A → A) (left right : A → A → A) : Prop :=
  ∀ a, (∀ n, Rooted zero (fun k => left k a) (fun k => right k a) n →
    left (succ n) a = right (succ n) a) →
    ∀ n, Rooted zero (fun k => left k a) (fun k => right k a) n

theorem computationExtraction
    (zero : A) (succ : A → A) (body : A → A) (bundle : A → A → Prop)
    (schemaInstance : ∀ a, (∀ n, (n = zero ∨ body n = body n) →
      body (succ n) = body (succ n)) →
      ∀ n, (n = zero ∨ body n = body n) ∧ bundle n a) :
    ∀ n a, bundle n a := by
  intro n a
  exact (schemaInstance a (fun _ _ => rfl) n).2

theorem delayedSeeds
    (zero : A) (succ : A → A) (iter : B → A → A → A) (oneIndex : B)
    (reset : ∀ index n a, iter index (iter oneIndex n zero) a = a)
    (oneTail : ∀ n a, iter oneIndex (succ (succ n)) a = succ zero) :
    (∀ index a, iter index (succ zero) a = a) ∧
    (∀ index a, iter index zero a = a) := by
  have seedOne : ∀ index a, iter index (succ zero) a = a := by
    intro index a
    have equation := reset index (succ (succ zero)) a
    rw [oneTail] at equation
    exact equation
  constructor
  · exact seedOne
  · intro index a
    have equation := reset index (succ zero) a
    rw [seedOne oneIndex zero] at equation
    exact equation

def Select (add : A → A → A) (zeroTest : A → A → A) (one : A)
    (test left right : A) : A :=
  add (zeroTest test left) (zeroTest (zeroTest test one) right)

theorem weakSelectorZero
    (zero : A) (succ : A → A) (add zeroTest : A → A → A)
    (rightZero : ∀ x, add x zero = x)
    (testZero : ∀ x, zeroTest zero x = x)
    (testSucc : ∀ n x, zeroTest (succ n) x = zero) :
    ∀ x y, Select add zeroTest (succ zero) zero x y = x := by
  intro x y
  unfold Select
  rw [testZero, testZero, testSucc, rightZero]

theorem weakSelectorSucc
    (zero : A) (succ pred : A → A) (add zeroTest : A → A → A)
    (leftZero : ∀ x, add zero x = pred (succ x))
    (testZero : ∀ x, zeroTest zero x = x)
    (testSucc : ∀ n x, zeroTest (succ n) x = zero) :
    ∀ n x y, Select add zeroTest (succ zero) (succ n) x y = pred (succ y) := by
  intro n x y
  unfold Select
  rw [testSucc, testSucc, testZero, leftZero]

theorem predecessorFromAdjacent
    (zero : A) (succ pred : A → A) (selector : A → A → A → A)
    (predOne : pred (succ zero) = zero)
    (predTail : ∀ n, pred (succ (succ n)) = succ (pred (succ n)))
    (selectZero : ∀ x y, selector zero x y = x)
    (selectOne : ∀ x y, selector (succ zero) x y = pred (succ y))
    (schemaInstance : Adjacent zero succ (fun n a => selector a n n)) :
    ∀ n, pred (succ n) = n := by
  have rooted : ∀ n, n = zero ∨ n = pred (succ n) := by
    have raw := schemaInstance zero (by
      intro n hypothesis
      change n = zero ∨ selector zero n n = selector (succ zero) n n at hypothesis
      rw [selectZero, selectOne] at hypothesis
      change selector zero (succ n) (succ n) =
        selector (succ zero) (succ n) (succ n)
      rw [selectZero, selectOne, predTail]
      cases hypothesis with
      | inl atZero => subst n; rw [predOne]
      | inr current => rw [← current])
    intro n
    have result := raw n
    change n = zero ∨ selector zero n n = selector (succ zero) n n at result
    rw [selectZero, selectOne] at result
    exact result
  intro n
  cases rooted n with
  | inl atZero => subst n; exact predOne
  | inr current => exact current.symm

theorem successorInjective
    (succ pred : A → A)
    (predSucc : ∀ n, pred (succ n) = n) :
    (∀ x y, succ x = succ y → x = y) := by
  intro x y equalSucc
  have equation := congrArg pred equalSucc
  simpa only [predSucc] using equation

theorem successorNonzero
    (zero : A) (succ pred : A → A)
    (separation : zero ≠ succ zero) (predZero : pred zero = zero)
    (predSucc : ∀ n, pred (succ n) = n) :
    ∀ n, succ n ≠ zero := by
  intro n equalZero
  have collapsed := congrArg pred equalZero
  rw [predSucc, predZero] at collapsed
  apply separation
  rw [collapsed] at equalZero
  exact equalZero.symm

theorem coverageFromAdjacent
    (zero : A) (succ pred : A → A) (selector : A → A → A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (selectZero : ∀ x y, selector zero x y = x)
    (selectOne : ∀ x y, selector (succ zero) x y = y)
    (schemaInstance : Adjacent zero succ (fun n a => selector a n (succ (pred n)))) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  have raw := schemaInstance zero (by
    intro n _
    change selector zero (succ n) (succ (pred (succ n))) =
      selector (succ zero) (succ n) (succ (pred (succ n)))
    rw [selectZero, selectOne, predSucc])
  intro n
  have result := raw n
  change n = zero ∨ selector zero n (succ (pred n)) =
    selector (succ zero) n (succ (pred n)) at result
  simpa only [selectZero, selectOne] using result

theorem parityRangeWithoutInduction
    (zero : A) (succ pred parity : A → A) (zeroTest : A → A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (testZero : ∀ x, zeroTest zero x = x)
    (testSucc : ∀ n x, zeroTest (succ n) x = zero)
    (parityZero : parity zero = zero)
    (parityStep : ∀ n, parity (succ n) = zeroTest (parity n) (succ zero)) :
    ∀ n, parity n = zero ∨ parity n = succ zero := by
  intro n
  cases coverage n with
  | inl atZero => subst n; exact Or.inl parityZero
  | inr atSucc =>
    rw [atSucc, parityStep]
    cases coverage (parity (pred n)) with
    | inl innerZero => rw [innerZero, testZero]; exact Or.inr rfl
    | inr innerSucc => rw [innerSucc, testSucc]; exact Or.inl rfl

theorem parityFlips
    (zero : A) (succ parity : A → A) (zeroTest : A → A → A)
    (testZero : ∀ x, zeroTest zero x = x)
    (testSucc : ∀ n x, zeroTest (succ n) x = zero)
    (parityStep : ∀ n, parity (succ n) = zeroTest (parity n) (succ zero)) :
    (∀ a, parity a = zero → parity (succ a) = succ zero) ∧
    (∀ a, parity a = succ zero → parity (succ a) = zero) := by
  constructor
  · intro a value
    rw [parityStep, value, testZero]
  · intro a value
    rw [parityStep, value, testSucc]

def CompileZero (selector : A → A → A → A) (parity pred : A → A)
    (left right : A → A → A) (n a : A) : A :=
  selector (parity a) (left n a) (right n (pred a))

def CompileOne (selector : A → A → A → A) (parity pred : A → A)
    (left right : A → A → A) (n a : A) : A :=
  selector (parity a) (right n (pred a)) (left n a)

theorem compilerZero
    (zero : A) (succ pred parity : A → A) (selector : A → A → A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (selectZero : ∀ x y, selector zero x y = x)
    (selectOne : ∀ x y, selector (succ zero) x y = y)
    (flipZero : ∀ a, parity a = zero → parity (succ a) = succ zero)
    (left right : A → A → A) (a : A) (value : parity a = zero) :
    ∀ n, (CompileZero selector parity pred left right n a =
      CompileZero selector parity pred left right n (succ a)) ↔
      left n a = right n a := by
  intro n
  unfold CompileZero
  rw [value, flipZero a value, predSucc, selectZero, selectOne]

theorem compilerOne
    (zero : A) (succ pred parity : A → A) (selector : A → A → A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (selectZero : ∀ x y, selector zero x y = x)
    (selectOne : ∀ x y, selector (succ zero) x y = y)
    (flipOne : ∀ a, parity a = succ zero → parity (succ a) = zero)
    (left right : A → A → A) (a : A) (value : parity a = succ zero) :
    ∀ n, (CompileOne selector parity pred left right n a =
      CompileOne selector parity pred left right n (succ a)) ↔
      left n a = right n a := by
  intro n
  unfold CompileOne
  rw [value, flipOne a value, predSucc, selectZero, selectOne]

theorem transferAtParameter
    (zero : A) (succ : A → A) (left right term : A → A → A)
    (schemaInstance : Adjacent zero succ term) (a : A)
    (bridge : ∀ n, (term n a = term n (succ a)) ↔ left n a = right n a)
    (step : ∀ n, Rooted zero (fun k => left k a) (fun k => right k a) n →
      left (succ n) a = right (succ n) a) :
    ∀ n, Rooted zero (fun k => left k a) (fun k => right k a) n := by
  have rootedBridge : ∀ n,
      Rooted zero (fun k => term k a) (fun k => term k (succ a)) n ↔
      Rooted zero (fun k => left k a) (fun k => right k a) n := by
    intro n
    exact or_congr Iff.rfl (bridge n)
  have result := schemaInstance a (fun n hypothesis =>
    (bridge (succ n)).mpr (step n ((rootedBridge n).mp hypothesis)))
  intro n
  exact (rootedBridge n).mp (result n)

theorem equationPropagation
    (zero : A) (succ pred parity : A → A) (selector : A → A → A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (selectZero : ∀ x y, selector zero x y = x)
    (selectOne : ∀ x y, selector (succ zero) x y = y)
    (parityRange : ∀ a, parity a = zero ∨ parity a = succ zero)
    (flipZero : ∀ a, parity a = zero → parity (succ a) = succ zero)
    (flipOne : ∀ a, parity a = succ zero → parity (succ a) = zero)
    (left right : A → A → A)
    (zeroInstance : Adjacent zero succ (CompileZero selector parity pred left right))
    (oneInstance : Adjacent zero succ (CompileOne selector parity pred left right)) :
    Propagation zero succ left right := by
  intro a step
  cases parityRange a with
  | inl value =>
    exact transferAtParameter zero succ left right _ zeroInstance a
      (compilerZero zero succ pred parity selector predSucc selectZero selectOne
        flipZero left right a value) step
  | inr value =>
    exact transferAtParameter zero succ left right _ oneInstance a
      (compilerOne zero succ pred parity selector predSucc selectZero selectOne
        flipOne left right a value) step

theorem equationInduction
    (zero : A) (succ : A → A) (left right : A → A → A)
    (propagation : Propagation zero succ left right) (a : A)
    (base : left zero a = right zero a)
    (step : ∀ n, left n a = right n a → left (succ n) a = right (succ n) a) :
    ∀ n, left n a = right n a := by
  have extract : ∀ n, Rooted zero (fun k => left k a) (fun k => right k a) n →
      left n a = right n a := by
    intro n hypothesis
    cases hypothesis with
    | inl atZero => subst n; exact base
    | inr equation => exact equation
  have result := propagation a (fun n hypothesis => step n (extract n hypothesis))
  intro n
  exact extract n (result n)

#print axioms computationExtraction
#print axioms delayedSeeds
#print axioms weakSelectorZero
#print axioms weakSelectorSucc
#print axioms predecessorFromAdjacent
#print axioms successorInjective
#print axioms successorNonzero
#print axioms coverageFromAdjacent
#print axioms parityRangeWithoutInduction
#print axioms parityFlips
#print axioms compilerZero
#print axioms compilerOne
#print axioms transferAtParameter
#print axioms equationPropagation
#print axioms equationInduction

end AdjacentKernel
