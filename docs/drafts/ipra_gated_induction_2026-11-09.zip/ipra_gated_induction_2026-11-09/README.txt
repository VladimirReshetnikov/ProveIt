DETERMINISTIC GATED INDUCTION FOR iPRA
====================================
Research report prepared for Vladimir Reshetnikov
9 November 2026

START HERE
----------
ipra_gated_induction.pdf is the complete 25-page report.
ipra_gated_induction.tex is its standalone, editable LaTeX source.

The report gives a new gated presentation of full first-order
intuitionistic primitive recursive arithmetic, with written proofs of
equiconsistency and whole-domain bi-interpretability. It also proves a
finite existential Harrop-cover obstruction to interpreting a theory
with decidable equality and arbitrarily large finite sets.

The requested complete checker below the current corpus frontier has
NOT been obtained. The deterministic introduction rule removes a proof
annotation but adds a grammar restriction. Its net implementation cost
has not been established. No claim of absolute minimality, literature-wide
priority, external peer review, or proof-assistant verification is made.

MAIN MATHEMATICAL CONTENT
-------------------------
* Gated atomic matrices have a provable zero instance. Atomic binder
  introduction retains only the progress hypothesis; compound introduction
  retains only the base hypothesis. The old closure elimination is kept.
* A grammar-preserving gate, padding, and selectors derive all ordinary
  intuitionistic logic before equation induction is reconstructed.
* A delayed predecessor gate recovers arbitrary literal-equation induction.
  The attributed arithmetic appendix recovers all quantifier-free induction
  and an actual equality detector on the entire numerical domain.
* Both formula interpretation composites are proved. The numerical
  functions, domain, and actual equality are unchanged.
* Native absurdity is the designated equation 0=1. The ordinary first-order
  realization explicitly includes (0=1) -> bottom. The positive decoded
  equations alone have a singleton model and are not that realization.
* In a consistent ordinary intuitionistic theory with Harrop axioms, a
  decidable quotient on a domain covered by m existential Harrop components
  has at most m classes. This is not a checker-size lower bound and does
  not cover arbitrary non-Harrop interpretation domains.

CONTENTS
--------
manuscript.tex                      Editable modular report source
sections/gated_candidate.tex         New presentation and equivalence proof
sections/harrop_finite_cover.tex      Finite-cover obstruction and proof
sections/arithmetic_completion.tex   Attributed arithmetic completion
build.py                            Flatten sources and compile the PDF
reproduce.py                        Reproduce the scoped executable evidence
package.py                          Build a checksum-verified ZIP
code/gated_syntax/                   New finite syntax/endpoint experiments
reference/checkers/                  Unchanged complete Choice-DI comparators
reference/choice_baseline.zip        Complete original Choice-DI reference
reference/LICENSE-inherited.txt      Inherited MIT No Attribution license
reference/choice_attribution.txt     Original Choice-DI attribution
ATTRIBUTION.txt                      Separation of new and inherited work
evidence/                           Measurements, receipts, manifests, reviews
MANIFEST.sha256.json                 SHA-256 of all other packaged payloads

REPRODUCING EXECUTABLE EVIDENCE
-----------------------------
From the extracted package directory, with Python 3 and its standard library:

    python3 reproduce.py

The recorded runtime is CPython 3.12.14. The script measures whole inherited
checker modules after stripping comments and genuine docstrings and applying
ast.unparse; it does not rename identifiers or omit the public interface.
The recorded normalized counts are:

                    tokens     AST nodes     bytes
    tokens.py          299           345       880
    structure.py       304           340       902
    bytes.py           307           353       815

The envelope 299 / 340 / 815 is attained by different programs. These are
achievable implementation sizes, not proven universal lower bounds.
Different Python releases can normalize source differently.

The replay runs 21 focused positive/negative certificates through each of
the three inherited programs in normal and optimized Python: 126 public
CLI executions, all passing. This checks the copied baseline interface.

The new syntax artifact records 649 finite checks, including independent
capture-avoiding substitution comparisons, admissibility checks, symbolic
selector/gate endpoints, and malformed-input controls. Its normalizer uses
only the displayed C/P computation rules plus explicitly declared derived
padding/reflexivity schemas. It is not a complete proof checker and does
not establish the universal mathematical metatheorems by execution.
See code/gated_syntax/README.txt and FORMAT.txt for exact scope.

BUILDING THE REPORT
-------------------
With Python 3 and an ordinary LaTeX installation containing pdflatex and the
packages imported in manuscript.tex:

    python3 build.py

This flattens the modular source into ipra_gated_induction.tex and compiles
it twice, with shell escape disabled. The delivered standalone TeX can also
be compiled directly with pdflatex, twice for references. No bibliography
processor or network access is needed.

The supplied PDF was compiled and every page rendered for visual review.
The final compilation has no unresolved citations/references and no
overfull or underfull boxes. An epstopdf warning that shell escape is
disabled is harmless; the document does not require external conversion.

PACKAGING AND CHECKSUMS
----------------------
    python3 package.py

This writes a ZIP beside the package directory, checks ZIP integrity, and
verifies the bytes of every packaged file against MANIFEST.sha256.json.
Build auxiliaries and Python caches are omitted. Rebuilding or rerunning
the checks changes generated evidence; rerun package.py afterward to
refresh the manifest. PDF binaries may vary with LaTeX versions and dates.

SOURCE SNAPSHOT AND AUDIT SCOPE
------------------------------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Pinned commit: 1d0d5f030546d707992b4cc4194ea6971fe84938
Source directory: docs/drafts

All 26 top-level archives in that snapshot were downloaded and their Git
blob identities checked. Their contribution/status statements were read,
with targeted review of central rules, proofs, and selected code. This was
not a formal verification of every inherited compiler or every archive line.
The manifests record each original path, identity, URL, and checksum.
A final repository check at a96433acd71ba2b23d2745848efe82b85ac9a734 found
the same 26 draft archives unchanged.

The original Choice-DI archive is included for its complete semantic and
arithmetic background. Other source archives are identified by the manifest
rather than redundantly included. Mathematical review notes in evidence/
are internal checks from this research session, not external peer reviews.
They document intermediate scrutiny; the report is the final statement.

WHAT REMAINS OPEN
----------------
A complete, publicly callable gated checker with an explicit decoder must
still be implemented and measured under the same whole-source convention.
The full primitive-recursive signature used in the new proof cannot simply
inherit the old scalar checker's cost. The present work establishes a
mathematical simplification and an obstruction, not the requested strict
below-frontier complexity result.
