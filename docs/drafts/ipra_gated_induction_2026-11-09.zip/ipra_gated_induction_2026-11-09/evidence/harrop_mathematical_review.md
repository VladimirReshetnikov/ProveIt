# Independent review of the Harrop-domain obstruction

Reviewed file: `harrop_obstruction.md`.

## Verdict

The main binary-decomposition theorem and the parameter-free finite-dimensional quotient-interpretation corollary are correct under the stated ordinary intuitionistic first-order interpretation convention. I found no counterexample. The contextual recurrence/reset rule applications are correct provided they have the displayed unrestricted retained-context form and freshness conditions, so that their ordinary axiom internalizations are available.

This is a scoped obstruction to a particular arithmetic architecture. It is not a proof-checker size lower bound, not a proof that no simpler presentation exists, and not an exclusion of all domain-changing or logical-representation-changing interpretations.

## 1. Relative disjunction property

The displayed Harrop grammar is the standard one: arbitrary formulas are allowed in implication antecedents; implication consequents are Harrop. Harrop formulas are closed under substitution of individual terms.

The proposed cut-free proof works for first-order intuitionistic sequent calculus. In an implication-left step with principal formula C -> H, the continuation premise has H in its antecedent and thus again has only Harrop antecedents. Apply the induction hypothesis to that premise, retain the other premise proving C, and reconstruct the same chosen disjunct. First-order universal-left substitution preserves Harropness. No existential-left or disjunction-left principal formula can occur while the whole antecedent is Harrop. Right rules other than disjunction-right cannot conclude the literal disjunction succedent. Structural rules and falsity-left cause no difficulty.

Cut elimination is applied to ordinary pure intuitionistic logic with the finitely many used theory axioms retained as hypotheses. It need not be assumed for a bespoke arithmetic calculus with its axioms built into special rules.

Fresh individual constants are legitimate: extend the language conservatively, perform the finite proof and disjunct extraction, then use the fresh-constant generalization lemma. No domain elements are selected by a choice principle.

## 2. Equality

Replacing logical equality temporarily by a binary predicate with equality axioms is sound for this argument. Reflexivity, symmetry, transitivity, each function congruence instance, and each atomic predicate congruence instance are closed universal Horn formulas and hence Harrop. Only finitely many are used in a given proof.

Replacement in arbitrary formulas is derivable by structural induction using both directions of atomic congruence. Implication uses its consequent direction and the inverse direction on its antecedent; quantifiers use fresh bound-variable renaming. Thus the relative DP transfers back to the ordinary first-order logic with equality used in the report. No negative-equality decidability axiom is silently added.

## 3. Binary decomposition

Given T |- forall x(delta(x) -> (A(x) or B(x))), a fresh constant tuple c yields T,delta(c) |- A(c) or B(c). The proof uses a finite Harrop subtheory of T, and delta(c) is Harrop. Relative DP yields one fixed branch in that very context. Discharging and fresh-constant generalization produce one of the two uniform theorems over delta. This genuinely is a uniform branch, not a pointwise metatheoretic choice.

Either uniform theorem contradicts the corresponding existential counterexample. It is unnecessary that A or B be Harrop. In particular, arbitrary existential quantifiers introduced by graph-based term translation and arbitrary quotient equality formulas are harmless to this reasoning.

## 4. Quotient and relational interpretations

The iPRA fragment actually used is very small:

- forall n(n=0 or exists m n=S(m));
- exists n not(n=0), witnessed by S(0);
- exists n not(exists m n=S(m)), witnessed by 0.

A connective-preserving interpretation with genuine-falsity preservation translates these into exactly the decomposition theorem's three clauses after relativization. Let A be the translation of n=0 and B the translation of exists m(n=S(m)). The second and third target theorems translate as exists tuple x(delta(x) and not A(x)) and exists tuple x(delta(x) and not B(x)). This remains true if constants and functions are given by provably total graphs instead of source terms, and if equality is a provable congruence used to form a quotient.

The proof consequently applies to any target theory proving those three statements, not specifically to all the strength of iPRA. Stating this generalization could help make the result's mechanism transparent. It does not make a stronger claim about arbitrary nonhomomorphic translations.

Ordinary finite-dimensional interpretations use a finite tuple, so the fresh-constant and universal-generalization steps are routine. An interpreted domain that is merely provably equivalent in T to a Harrop formula is covered too: replace its domain formula by that Harrop equivalent before applying the theorem.

## 5. Contextual-rule internalization

For the displayed recurrence rule, assume the universally quantified step condition, instantiate it at a fresh z, invoke the rule at a fresh target x, universally generalize x, and discharge the assumed step. Finally universally close the passive parameters. This proves its displayed Harrop axiom.

Conversely, from a step derivation in an arbitrary retained context, the eigenvariable condition permits universal generalization of z, and the axiom yields the desired target instance. Thus the equivalence is exact for the stated contextual rule. Reset and ordinary equation induction are handled identically. Their axioms have universally quantified atomic consequents, so arbitrary complexity in their antecedents does not spoil Harropness.

An advisable wording qualification is to say “these equation-concluding schemas, with the displayed finitary contextual internalization” rather than imply that every conceivable special inference mechanism with an equational conclusion is automatically covered. For instance, rules that alter the consequence relation nonhomomorphically or use infinitary/global semantic side conditions need a separate analysis.

## 6. Scope qualifications to retain

1. The target here is full first-order iPRA with coverage derivable from quantifier-free induction, as explicitly fixed by the reports. A bare atomic-induction theory with no positive boundary information is not silently identified with that target.
2. The interpreted domain must be Harrop, or provably equivalent to Harrop. No conclusion is obtained for arbitrary disjunctively or existentially defined domains.
3. Parameter admissibility must be Harrop for the given parameterized extension of the argument. If T proves existence of admissible parameters, adjoining fresh parameters satisfying their Harrop condition preserves consistency and gives the same proof.
4. Genuine falsity and the interpretation's preservation of it matter. Native logics that change the logical representation are explicitly outside scope until translated into an ordinary realization.
5. The theory axioms are closed, deductions are ordinary intuitionistic deductions, and the theory is consistent. Classical logic is outside scope; an inconsistent Harrop theory trivially proves every branch.
6. The absence of the observation from current draft text is a corpus-relative novelty statement. The relative DP is established proof theory; historical novelty of this elementary interpretation corollary has not been researched or established.

## 7. Useful clean formulation

**Harrop-domain partition theorem.** If T is a consistent intuitionistic first-order theory axiomatized by closed Harrop sentences and delta is a Harrop domain formula, no T-provably exhaustive binary partition of delta can have T-provably inhabited complements of both parts. The partition predicates themselves may be arbitrary formulas.

The iPRA interpretation corollary and the impossibility of deriving a nonconstant two-valued numerical range theorem from the displayed purely Harrop arithmetic architectures follow immediately.
