# Independent mathematical review of gated_candidate.tex

## Outcome

The gated-calculus equivalence argument is coherent after the delayed-gate equation-induction proof and literal-projection equality bootstrap were adopted. I found no missing induction, coverage, equality-reflection, or formula-round-trip assumption in the displayed construction. This is a handwritten mathematical review, not a formal verification or a proof-checker size result.

## Dependency audit

1. A primitive projection equation r=t with r=pi_0^1(t), used as both premises of transport with motive v=t, gives reflexivity before any computation chains are joined. The ordinary-assumption guard is the single primitive projection axiom pi_0^1(0)=0. After this bootstrap, symmetry/transitivity join the recursion and projection computations that give the designated C/P endpoint equations. This corrects the earlier premature treatment of a derived C equation as a single primitive axiom.
2. Binder congruence is valid whenever both endpoint binders obey the gate grammar. A compound target retains its base. An atomic target has a computationally true gated base, allowing the opened old closure to be used while ignoring the target progress hypothesis. This includes a change between atomic and compound matrices when both binders remain admissible.
3. Gates preserve an existing immediate atomic D gate by modifying only its payloads. The tempting outer wrapping C(v,0,C(y,0,s)) would be invalid, but the text uses the correct C(y,0,C(v,0,s)).
4. G_0 A is proved by external structural induction. The gated atomic D case has reflexive payloads, and the compound case ignores its introduction assumption. G_(Su) A is removed by computation and the already derived binder congruence. Padding is therefore obtained before induction or coverage.
5. Numerical cases apply to Pad(A(n)), whose root is always compound, and then remove padding. This does not covertly apply induction to A.
6. The formula selector terminates: paired and mixed-root steps remove at least one actual binder level; when both immediate matrices are atomic, the special merge preserves their common outer gate. In the mixed matrix case the recursive selector has a binder root, which is admissible under the enclosing D.
7. Implication pads both operands so its matrix is compound; this is essential for retaining the antecedent at zero. All other logical macros have a zero-gated matrix. The conjunction and universal macros use the available predecessor P, with P(Sz)=z, so their introduction and elimination proofs do not need induction. Disjunction elimination uses numerical cases only after implication is available.
8. Coverage is derived only after the complete ordinary logical interface and unconditional numerical cases. It then allows case analysis inside contexts containing the chosen number.
9. For equation induction, B(y)=C(y,0,s(Py))=C(y,0,t(Py)) has B(0) provable and B(Sv) equivalent to E(v). Under B(z), coverage gives E(z): base at z=0, and original step from E(Pz) at z=S(Pz). Atomic DI and the unchanged closure elimination at St yield E(t). This uses the given step proof with a capture-free numerical substitution, not an illegal change of the retained context.
10. The inherited arithmetic-completion appendix proves actual equality reflection using only literal equation induction, full PR computation, coverage, and separation. Its residual equation invariant has an equation as matrix throughout. Its later Boolean compilation is an external recursion on fixed quantifier-free syntax.
11. Forward atomic DI is sound by equation induction and its computationally true base; forward compound DI is sound by numerical cases. Native paired-binder characterization handles its atomic reverse direction using the gated base theorem and its compound reverse direction using the retained base. Hence the formula round trips do not form any illegal ungated atomic binder.

## Boundaries

- The proof uses the full finite-description PR language. It does not establish the same result for the much smaller scalar-iterator signature of the smallest native executable checkers.
- A complete checker must enforce the designated C gate, arity and scope discipline. Removing an introduction certificate choice is not by itself a net source-size improvement.
- The endpoint notation for gates is read substitutionally: if the control variable also occurs in a payload, substituting a successor changes all its free occurrences. The current explanatory sentence states this convention; it is necessary for universal and delayed-gate macros.
- The novelty claim should remain relative to the inspected corpus. The construction is a syntax restriction plus a proof transformation, not an absolute minimality theorem.
