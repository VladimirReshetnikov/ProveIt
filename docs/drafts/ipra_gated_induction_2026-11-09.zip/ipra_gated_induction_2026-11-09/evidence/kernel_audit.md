# Audit of the iPRA logical and proof-kernel frontier

Snapshot: `VladimirReshetnikov/ProveIt`, commit `1d0d5f030546d707992b4cc4194ea6971fe84938`.
Sources: the 26 downloaded, Git-blob-verified archives in `drafts/`.
This is an internal research audit, not an external peer review or proof-assistant verification.

## Principal finding

The newest relevant proposal is **Choice DI**, in `ipra_choice_2026-11-09`. It already establishes the one-local-assumption transformation that many older reports list as an open direction. The currently attained whole-source coordinate envelope is **299 normalized Python tokens, 340 AST nodes, 815 normalized bytes**. Different complete programs attain these three coordinates. The older recurring figure 309/344/864 is stale.

Independent remeasurement used CPython 3.12.14, stripping comments and genuine docstrings only, then `ast.unparse` plus newline. All operational source remains charged: imports, raw-syntax validation, substitution, proof checking, parsing, verdicts, and rejection. The result agrees exactly with the Choice report:

| Complete source | Tokens | AST nodes | Normalized bytes |
|---|---:|---:|---:|
| Choice `code/native/tokens.py` | 299 | 345 | 880 |
| Choice `code/native/structure.py` | 304 | 340 | 902 |
| Choice `code/native/bytes.py` | 307 | 353 | 815 |
| Earlier indexed-major comparator | 305 | 345 | 860 |
| Earlier strict structural comparator | 308 | 341 | 894 |
| Earlier padded-major comparator | 311 | 352 | 820 |
| Earlier iterable-alias comparator | 306 | 340 | 859 |
| Earlier reconstructed complete kernel | 309 | 344 | 864 |

The detailed independent inventory is `kernel_inventory.json`. It contains 17 distinct small sources with a complete-looking CLI, not 17 certified alternatives: `compact_left_prototype.py` and the nominal experiment are not certified complete comparators. Reports' classification, not file shape, determines admissibility.

The iterable-alias comparator relies on Python's recursion guard to reject a nonempty-string malformed branch. The three Choice programs use explicitly guarded finite list traversals and avoid this qualification. Fixed real machine resources still reject some sufficiently large valid finite certificates, as with any practical recursive checker.

## The exact Choice calculus

Numerical terms are `x`, `0`, `S(t)`, and initialized scalar iteration `I(n,a;u.h)`, where the update has one state variable and may have passive parameters. The two computation schemas are

\[
I(0,a;u.h)=a,\qquad I(Sn,a;u.h)=h[I(n,a;u.h)/u].
\]

No term variable denotes a function description; all descriptions are finite external syntax. In the ordinary signature they are elaborated in stages to individual function symbols.

Native formulas are equations and paired binders `D_(x,y) B`. A retained clause `<A;y.B(y)>` means `A -> forall y B(y)`. Alongside computation, the inference patterns are:

1. **Use:** from `A` and a retained clause `<A;y.B(y)>`, infer `B(t)`.
2. **DE:** from `D_(x,y) B`, open at fresh `a` the clause `<B(a,0);y.B(a,y)>` in a continuation.
3. **Transport:** from `s=t` and `F(s)`, infer `F(t)` for an arbitrary fixed formula motive.
4. **Choice DI:** from `Gamma,B(t,eta_e(z)) |- B(t,Sz)`, infer `Gamma |- D_(x,y) B`, where `eta_0(z)=0`, `eta_1(z)=z`; progress choice 1 is permitted only for a literal equation matrix, and case choice 0 is permitted for every matrix. The eigenparameter is fresh for all retained data and the witness.

Ordinary hypotheses are constant-consequent clauses with a fixed computation theorem antecedent. Context reuse is allowed. The raw compact checker instead retains formulas, adds the unary closure `Q_y B = B(0) -> forall y B(y)` on DE, and uses its elimination. Q and an unused-witness D are mutually definable.

There are no primitive reflexivity, coverage, separation, ordinary logical connectives, or separate induction rules. Reflexivity derives from a computation equality by transport. Contextual equation induction derives from progress DI, DE, and Use. Numerical cases and the entire ordinary logical interface derive from case DI, DE, Use, and gates/selectors built using the constant iterator update.

## Why the Choice transformation is a substantive mathematical result

The original atomic introduction retains both `E(t,0)` and `E(t,z)`. Choice never retains both in one inference. To recover the old rule:

1. Use outer case DI, retaining `E(t,0)`.
2. Inside it, use progress DI with an **unused** existential variable `u`, introducing `D_(u,y) E(t,y)` from the original step proof.
3. DE opens `<E(t,0);y.E(t,y)>` without changing the fixed original witness `t`.
4. Supply the retained base and use that clause at `Sz`; close the outer case DI.

The unused inner witness is essential; binding the original witness coordinate would replace `t` by an arbitrary fresh witness. The argument preserves arbitrary retained contexts, exact numerical and formula syntax, and the whole consequence relation. It expands an N-node proof with r atomic mixed introductions to exactly N+5r inference nodes under the stated counting convention. The proof is in `sections/choice_basis.tex`; I checked its freshness and assumption uses and found no gap.

## Full bi-interpretability evidence and its boundary

The ordinary realization `T_I` uses intuitionistic first-order equality logic with genuine falsity, the iteration schemas, literal-equation induction, numerical coverage `forall x (x=0 or exists y x=Sy)`, and the explicit falsity bridge `(0=S0)->bottom`.

The native D translates as `exists x (B(x,0)->forall y B(x,y))`; the domain is the entire numerical domain and equality is actual equality. The paper gives:

- Gate/padding and formula-selector constructions for implication, conjunction, disjunction, existential and universal quantification, and falsity.
- Derivations of every ordinary logical rule, including constructive disjunction elimination through numerical cases.
- A native proof of the paired-binder formula roundtrip, not merely a sound one-way decoding.
- An internal scalar predecessor proof, followed by equality reflection and quantifier-free induction, then pairing and compilation of each fixed primitive recursion.
- Both numerical composites by induction on each fixed finite description and internal uniqueness of its recursion; the identity graph is `x=y`.

This is a serious written whole-domain argument. It does not merely match standard numeral values, use an unspecified universal evaluator, or confuse equiconsistency with bi-interpretability. The explicit genuine-falsity bridge is necessary in the ordinary realization: positive equations alone allow a singleton numerical structure.

The full arithmetic compiler, all universal proof-translation theorems, and both bi-interpretation composites are **not** mechanized in Lean/Rocq. Finite executable certificates and normal/optimized CLI controls support the implementation; they do not replace those universal mathematical proofs. I audited the logical bridge and the stated dependency order, not every line of every inherited arithmetic appendix.

The whole-source size comparison is reproducible but is not a mathematical lower-bound theorem. Raw byte counts depend on identifier spelling; the claimed native syntax is deliberately compact and its semantic decoder is elaborate. No fixed formal notion of “straightforward implementation” has been proved minimal.

## Other assigned archives

| Archive | Actual contribution relevant here | Full-frontier status |
|---|---|---|
| adjacent_symmetry | A fixed adjacent-observation symmetry rule replaces nested reset and recovers equality/induction after Boolean-range and separation axioms. Complete readable checker 3242/3447/12919, matched improvement. | Far above native minimum. |
| boolean_bootstrap | Boolean induction calibrates the clock before full reflection, removing a redundant second-diagonal mask. Its certificate replayer is a fragment. | Explicitly no new smaller full checker. |
| choice | Complementary base/progress introductions with one retained assumption. | Current smallest guarded coordinate envelope. |
| clock_and_kernel | Simpler scalar predecessor; separately smaller strict/native implementations. | Structural comparator 308/341/894; iterable alias comparator 306/340/859. |
| exact_depth | Exact logical-depth and oracle-threshold families for a fixed grammar. | Does not bound complete checker source or arbitrary alternative languages. |
| forward_left | Arbitrary equality source is made a direct retained-clause source by vacuous closure; forward-left occurrence rewriting suffices; linear N+5T transport translation. | Readable full checker 3218/3562/15789; rejected compact prototype is not a comparator. |
| frontier_audit | Atomic transport derivation, uniform Open interface, fixed-point obstruction, classical finite-axiomatization boundary. | No smaller complete checker. Open sketches explicitly unvalidated and larger. |
| left_rewriting | Only root or one immediate argument on the left side need be forward rewritten; arbitrary proved equality source suffices. | Readable full checker 3160/3501/15674. |
| local_rewriting | Equality transport normal form: literal equations, one occurrence, computation or atomic local-clause sources. | Readable full checker 3287/3650/16192. |
| neutral_transport | Local computation/atomic-clause-sourced bidirectional rewrites preserve all native formulas; arbitrary formula IH would give HA. | No new full checker; retained old baseline. |
| rotation | Successor uniqueness plus one fixed rotation law recovers full iPRA over its retained base. | Mathematical trade, not smaller native grammar/checker. |
| unbounded_depth | Fixed classical truth level with unbounded intuitionistic native formula depth. | Representation obstruction only; not a general simplicity bound. |

## Rejected tempting further reduction

Deleting the Choice mode and always selecting progress at equations and case at compounds is **already rejected in the corpus**. It is not a new solution. See `ipra_feedback.../ipra_feedback.tex`, appendix “Why the tempting one-assumption binder reduction was rejected”, and `ipra_orbit_pulse.../report.tex`, “A tempting checker deletion that was rejected”.

Under standard natural numbers, reinterpret each raw atomic closure as progression `forall y(E(y)->E(Sy))`, while compound closures retain the conditional-closure meaning. The reduced introduction and unchanged closure elimination remain sound, since external induction makes progression plus the base imply all instances. For `E(y)` equal to `y=1`, the original closure is true (false base), but progression is false. Thus the reduced calculus cannot prove every theorem of the original decoding.

Changing the decoder to progression does not cure both composites: the ordinary conditional-closure model also validates the reduced rules, so the raw formula cannot be refuted there, whereas iPRA refutes its progression translation. Padding protects a sublanguage but leaves the extra raw atomic formulas undetermined. The `progress_closure` draft repairs this by an additional local successor elimination, which has its own cost.

One potentially distinct research direction would normalize the **admissible atomic binder syntax** so its zero instance is a provable truth, making progression and closure coincide, while placing implications into a compound padded sublanguage. This requires a precise new raw decoder, a proof of roundtrips for every allowed formula, and a complete accounting of normalization/validation. I do not currently have a smaller implementation of it. It must not be represented as an achieved breakthrough.

## Other compression directions already present

Atomic-only transport, one-occurrence transport, left-only rewriting, arbitrary-source weakening via a vacuous binder, clause-opening fusion, stationarity/uniqueness trades, and gate/padding reductions are all already explored. Combining names of inference rules does not reduce necessary checks. The frontier-audit Open calculus is mathematically sound but its experimental layouts measured 351/392/1014 and 370/404/1014 and were not certified full acceptors.

The strongest opportunity appears to be a new semantic organization that removes an actual primitive check without leaving unconstrained raw formulas. A further recoding of the Choice mode into truthiness, witness annotation, arity aliases, or a byte string would be implementation compression of the existing result, not the requested significant mathematical advance.
