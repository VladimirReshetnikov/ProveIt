# Finite unions of Harrop domains and discrete quotients

## Verified theorem

Let T be a theory in ordinary intuitionistic first-order logic axiomatized by closed Harrop formulas. Let

    delta(x) <-> H_1(x) or ... or H_r(x)

be provable in T, where each H_i is Harrop and x may be a fixed finite tuple. Let E(x,y) be any formula. Assume T proves, on delta, reflexivity of E and decidability E(x,y) or not E(x,y). Then, for each i,

    T |- forall x,y ((H_i(x) and H_i(y)) -> E(x,y)).

Consequently, if E is an interpreted equality equivalence relation, the quotient delta/E has at most r classes, provably in T. Neither E nor its negation must be Harrop.

## Proof of the single-piece assertion

Take fresh constant tuples c,d. From H_i(c),H_i(d), infer delta(c),delta(d), then E(c,d) or not E(c,d). All assumptions besides the disjunctive conclusion are Harrop. Relative DP gives one of the two judgments in this same context.

If E(c,d) is derivable, discharge both assumptions and generalize to obtain the asserted uniform theorem.

Otherwise discharge and generalize to obtain

    T |- forall x,y ((H_i(x) and H_i(y)) -> not E(x,y)).

Instantiate y=x. Under H_i(x), infer not E(x,x). The domain implication and assumed reflexivity give E(x,x), so T proves forall x not H_i(x). By falsity elimination the desired E(x,y) follows under H_i(x),H_i(y). Thus the assertion holds in either metatheoretic DP branch. No inhabitation or existence property for H_i is needed.

This part does not even require consistency of T. Consistency enters only when excluding interpretations with arbitrarily many distinct target elements.

## Internal cardinality conclusion

For fixed r >= 1, T proves

    forall x_0,...,x_r
      ((delta(x_0) and ... and delta(x_r))
       -> OR_{0 <= a < b <= r} E(x_a,x_b)).

Proof: eliminate the r-way domain disjunction for each of the r+1 variables. In each resulting finite branch, assign to each variable one of r Harrop pieces. The ordinary finite pigeonhole principle in the metatheory supplies two assigned to the same piece. Apply that piece's uniform theorem and introduce the corresponding disjunct. Close all disjunction eliminations. This is a finite ordinary intuitionistic derivation for each fixed r; no excluded middle and no arithmetic pigeonhole axiom in T is used.

For r=0, delta is provably false, so an interpretation's nonempty-domain requirement is already impossible in a consistent T.

## Interpretation obstruction

Suppose consistent T interpreted full iPRA by an ordinary connective- and falsity-preserving finite-dimensional interpretation whose domain is T-provably equivalent to a finite union of Harrop formulas.

The target proves equality reflexivity and decidability, giving the hypotheses above for its interpreted quotient equality E. For the particular fixed r, the target also proves existence of r+1 pairwise unequal elements: the numerals 0,1,...,r. Their translation contradicts the internal cardinality bound. Hence such an interpretation does not exist.

This handles arbitrary definable quotient equality, relational constants/functions, and all fixed finite dimensions. It also handles parameters with a Harrop admissibility condition, after adjoining admissible fresh parameters as in the prior review. It does not exclude domains with unrestricted existential or other non-Harrop structure that are not provably finite Harrop unions.

## Review status

I checked the relative-DP use, diagonal substitution in the negative branch, handling of empty pieces, and the finite intuitionistic pigeonhole derivation. No gap or counterexample found. The result is a new deduction for the current investigation from the established relative DP; historical novelty has not been researched or established.

## Verified strengthening: existentially quantified Harrop pieces

The same theorem holds when

    delta(x) <-> OR_{i=1}^r exists w_i H_i(x,w_i),

with each H_i Harrop and each witness tuple w_i finite (possibly empty).

For the i-th piece, apply relative DP under the Harrop assumptions
H_i(c,u), H_i(d,v), using fresh constant tuples for both domain elements and
both witness tuples. The positive branch yields the uniform implication
H_i(x,u) and H_i(y,v) -> E(x,y). In the negative branch, generalize all four
tuples and diagonalize y=x and v=u. Reflexivity yields forall x,u not
H_i(x,u), so the same positive implication holds vacuously.

Ordinary existential elimination now gives

    (exists u H_i(x,u)) and (exists v H_i(y,v)) -> E(x,y).

No witness uniqueness, selection function, or choice principle is needed.
The finite disjunction/pigeonhole proof is unchanged. Therefore a consistent
Harrop theory cannot ordinarily interpret full iPRA with a domain provably
equivalent to any fixed finite union of existential closures of Harrop
formulas. The interpreted quotient equality may still be an arbitrary
formula. The original Harrop-domain and finite-Harrop-union results are the
empty-witness special cases.
