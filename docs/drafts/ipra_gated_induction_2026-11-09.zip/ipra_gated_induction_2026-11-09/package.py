#!/usr/bin/env python3
"""Package final sources, PDF, attributed references and evidence."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
SKIP_SUFFIXES = {'.aux', '.out', '.toc', '.pyc', '.synctex.gz'}


def payloads():
    return [p for p in sorted(ROOT.rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts
            and p.name != 'MANIFEST.sha256.json'
            and p.suffix not in SKIP_SUFFIXES
            and not (p.parent == ROOT and p.suffix == '.log')]


def main():
    files = payloads()
    required = {'ipra_gated_induction.tex', 'ipra_gated_induction.pdf',
                'README.txt', 'sections/gated_candidate.tex',
                'sections/harrop_finite_cover.tex'}
    names = {str(p.relative_to(ROOT)) for p in files}
    if not required <= names:
        raise RuntimeError('Missing deliverables: ' + repr(required - names))
    manifest = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in files}
    mf = ROOT / 'MANIFEST.sha256.json'
    mf.write_text(json.dumps(manifest, indent=2) + '\n')
    destination = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in files + [mf]:
            archive.write(path, str(Path(ROOT.name) / path.relative_to(ROOT)))
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('ZIP integrity failure')
        for name, digest in manifest.items():
            content = archive.read(str(Path(ROOT.name) / name))
            if hashlib.sha256(content).hexdigest() != digest:
                raise RuntimeError('Packaged checksum mismatch: ' + name)
    print(json.dumps({'zip': str(destination), 'bytes': destination.stat().st_size,
                      'payload_files': len(files),
                      'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}, indent=2))


if __name__ == '__main__':
    main()
