#!/usr/bin/env python3
"""Flatten the modular manuscript and compile its delivered editable TeX."""
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
STEM = 'ipra_gated_induction'


def expand(path, stack=()):
    path = path.resolve()
    if path in stack or not path.is_relative_to(ROOT):
        raise ValueError('Invalid or cyclic input: ' + str(path))
    text = path.read_text()

    def include(match):
        child = (path.parent / match.group(1)).resolve()
        return '\n% Begin included source: ' + str(child.relative_to(ROOT)) + '\n' + \
               expand(child, stack + (path,)) + '\n% End included source\n'

    return re.sub(r'\\input\{([^}]+)\}', include, text)


def main():
    source = ROOT / (STEM + '.tex')
    source.write_text(expand(ROOT / 'manuscript.tex'))
    logs = []
    for run in range(2):
        process = subprocess.run(
            ['pdflatex', '-no-shell-escape', '-interaction=nonstopmode',
             '-halt-on-error', source.name],
            cwd=ROOT, text=True, capture_output=True)
        logs.append(process.stdout + process.stderr)
        if process.returncode:
            (ROOT / 'evidence/build.log').write_text('\n'.join(logs))
            raise RuntimeError('TeX compilation failed; see evidence/build.log.')
    (ROOT / 'evidence/build.log').write_text('\n'.join(logs))
    result = {'source': source.name, 'pdf': STEM + '.pdf',
              'runs': len(logs), 'shell_escape': False,
              'overfull_warnings': [line for line in logs[-1].splitlines()
                                    if 'Overfull' in line]}
    (ROOT / 'evidence/build.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
