#!/usr/bin/env python3
"""Reproduce the explicitly scoped executable evidence in this package.

This measures inherited complete checkers and replays their focused public
certificates. It does not prove the new gated calculus or its metatheorems.
"""
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import subprocess
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    raw = path.read_bytes()
    tree = ast.fix_missing_locations(StripDocstrings().visit(
        ast.parse(raw.decode('utf-8'))))
    normalized = ast.unparse(tree) + '\n'
    return {
        'file': str(path.relative_to(ROOT)),
        'sha256': hashlib.sha256(raw).hexdigest(),
        'normalized_tokens': sum(
            tok.type not in IGNORED for tok in
            tokenize.generate_tokens(io.StringIO(normalized).readline)),
        'ast_nodes': sum(1 for _ in ast.walk(tree)),
        'normalized_bytes': len(normalized.encode('utf-8')),
        'raw_bytes': len(raw),
    }


def main():
    evidence = ROOT / 'evidence'
    evidence.mkdir(exist_ok=True)
    programs = [ROOT / 'reference/checkers' / name
                for name in ('tokens.py', 'structure.py', 'bytes.py')]
    rows = [measure(path) for path in programs]
    fields = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
    metrics = {
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'scope': 'unchanged inherited complete Choice-DI programs only',
        'programs': rows,
        'coordinate_envelope': {
            key: min(row[key] for row in rows) for key in fields},
        'attainers': {
            key: [row['file'] for row in rows
                  if row[key] == min(r[key] for r in rows)]
            for key in fields},
    }
    (evidence / 'baseline_metrics.json').write_text(
        json.dumps(metrics, indent=2) + '\n')

    focused = json.loads((ROOT / 'reference/checkers/focused_certificates.json')
                         .read_text())['cases']
    receipts = []
    for program in programs:
        for optimized in (False, True):
            for case in focused:
                command = [sys.executable]
                if optimized:
                    command.append('-O')
                command.append(str(program))
                result = subprocess.run(
                    command, input=json.dumps(case['packet']), text=True,
                    capture_output=True, timeout=10, cwd=ROOT)
                accepted = result.returncode == 0 and result.stdout.strip() == 'ACCEPT'
                rejected = result.returncode == 1 and result.stdout.strip() == 'REJECT'
                passed = accepted if case['accept'] else rejected
                receipts.append({
                    'program': program.name, 'optimized': optimized,
                    'case': case['name'], 'expected_accept': case['accept'],
                    'exit_code': result.returncode,
                    'stdout': result.stdout.strip(), 'passed': passed,
                })
    replay = {
        'scope': 'focused inherited public-CLI certificates, not a universal proof',
        'case_count_per_program_and_mode': len(focused),
        'execution_count': len(receipts),
        'failures': sum(not row['passed'] for row in receipts),
        'receipts': receipts,
    }
    (evidence / 'baseline_replay.json').write_text(
        json.dumps(replay, indent=2) + '\n')
    if replay['failures']:
        raise RuntimeError('Inherited baseline replay failed; inspect evidence.')

    syntax_runner = ROOT / 'code/gated_syntax/verify.py'
    syntax_summary = None
    if syntax_runner.exists():
        run = subprocess.run([sys.executable, str(syntax_runner)],
                             cwd=ROOT, capture_output=True, text=True,
                             timeout=60)
        (evidence / 'gated_syntax_log.txt').write_text(run.stdout + run.stderr)
        if run.returncode:
            raise RuntimeError('Gated syntax evidence failed; inspect log.')
        syntax_summary = run.stdout.strip()
    print(json.dumps({
        'coordinate_envelope': metrics['coordinate_envelope'],
        'baseline_executions': replay['execution_count'],
        'baseline_failures': replay['failures'],
        'gated_syntax': syntax_summary,
    }, indent=2))


if __name__ == '__main__':
    main()
