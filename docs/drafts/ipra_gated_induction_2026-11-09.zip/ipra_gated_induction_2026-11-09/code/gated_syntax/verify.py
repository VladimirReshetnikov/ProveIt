"""Reproduce finite syntax and endpoint evidence for gated-D formulas.

This is not a full iPRA proof checker or a mechanization of bi-interpretability.
Run `python3 verify.py` from this directory. No third-party package is needed.
"""

from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

import constructors as c
import symbolic as s
import validator as v


ROOT = Path(__file__).resolve().parent

# Literal fixtures are independent of the constructors being tested.
CORPUS = {
    "equation": ["=", ["v", "a"], ["v", "b"]],
    "opaque_functions": ["=", ["f", "f", [["v", "a"], ["0"]]],
                         ["f", "add", [["v", "b"], ["S", ["0"]]]]],
    "guarded": ["D", "x", "y", ["=",
        ["C", ["v", "y"], ["0"], ["f", "f", [["v", "x"], ["v", "y"]]]],
        ["C", ["v", "y"], ["0"], ["f", "add", [["v", "a"], ["v", "y"]]]]]],
    "nested": ["D", "u", "v", ["D", "x", "y", ["=",
        ["C", ["v", "y"], ["0"], ["f", "f", [["v", "x"], ["v", "v"]]]],
        ["C", ["v", "y"], ["0"],
         ["f", "h", [["v", "u"], ["v", "y"], ["v", "a"]]]]]]],
    "shadowed": ["D", "x", "y", ["D", "x", "y", ["=",
        ["C", ["v", "y"], ["0"], ["f", "f", [["v", "x"], ["v", "a"]]]],
        ["C", ["v", "y"], ["0"], ["f", "add", [["v", "y"], ["v", "b"]]]]]]],
    "depth_three": ["D", "r", "s", ["D", "u", "v", ["D", "x", "y", ["=",
        ["C", ["v", "y"], ["0"], ["f", "h", [["v", "r"], ["v", "u"], ["v", "x"]]]],
        ["C", ["v", "y"], ["0"], ["f", "h", [["v", "s"], ["v", "v"], ["v", "y"]]]]]]]],
    "literal_padding": ["D", "p", "q", ["=",
        ["C", ["v", "q"], ["0"], ["v", "a"]],
        ["C", ["v", "q"], ["0"], ["v", "b"]]]],
}

MAPPINGS = [
    {"a": ["v", "x"], "b": ["S", ["v", "y"]]},
    {"a": ["f", "h", [["v", "y"], ["v", "x"], ["S", ["0"]]]], "b": ["v", "a"]},
    {"a": ["C", ["v", "v"], ["0"], ["v", "z"]]},
    {"x": ["v", "a"], "y": ["v", "b"], "z": ["S", ["0"]]},
]


def digest(value):
    return hashlib.sha256(json.dumps(value, separators=(",", ":"), sort_keys=True).encode()).hexdigest()


def size(value):
    return 1 + sum(size(child) for child in value) if isinstance(value, (list, tuple)) else 1


def main():
    records = []
    examples = {"signature": v.DEFAULT_SIGNATURE, "formulas": {}}

    def check(label, category, condition, details=None):
        if not condition:
            raise RuntimeError("Failed finite check: " + label)
        records.append({"label": label, "category": category, "status": "PASS",
                        **({"details": details} if details is not None else {})})

    parsed = {}
    for label, raw in CORPUS.items():
        parsed[label] = v.formula(raw)
        check(label, "literal_fixture", True, {"free": sorted(v.free(parsed[label]))})

    # Substitution correctness is compared against a separate bound-indexed
    # reference implementation, not against constructors.substitute itself.
    for label, raw in CORPUS.items():
        source = parsed[label]
        for index, mapping in enumerate(MAPPINGS):
            output = c.substitute(raw, mapping)
            actual = v.canonical(v.formula(output))
            images = {key: v.canonical_term(v.term(term)) for key, term in mapping.items()}
            expected = v.canonical_free_substitution(v.canonical(source), images)
            check(f"substitution/{label}/{index}", "capture_avoiding_substitution",
                  actual == expected)

    control = "endpoint_control"
    one_image = ("S", ("v", "endpoint_parameter"))
    for label, raw in CORPUS.items():
        source = parsed[label]
        gated_raw = c.gate(c.V(control), raw)
        gated = v.formula(gated_raw)
        zero = s.instantiate_fresh(gated, control, ("0",))
        counts = Counter()
        zero_nf = s.normal_form(zero, counts, use_padding=False)
        check("gate-zero/" + label, "gate_zero_reflexive_leaves",
              s.reflexive_leaves(zero_nf), dict(counts))
        successor = s.instantiate_fresh(gated, control, one_image)
        equal, receipt = s.equivalent(successor, source)
        check("gate-successor/" + label, "gate_successor_endpoint", equal, receipt)
        padded_raw = c.padding(raw)
        padded = v.formula(padded_raw)
        equal, receipt = s.equivalent(padded, source)
        check("padding/" + label, "padding_schema_instance", equal, receipt)
        examples["formulas"]["gate_" + label] = gated_raw
        examples["formulas"]["pad_" + label] = padded_raw

        # The external control deliberately collides with existing binders.
        collision = c.gate(c.V("y"), raw)
        collision_parsed = v.formula(collision)
        check("gate-collision/" + label, "gate_control_scope",
              "y" in v.free(collision_parsed))

    # Every ordered pair includes equal depth, unequal depth, nested binders,
    # repeated binder names, and genuine parameter/counter dependence.
    for left_label, left_raw in CORPUS.items():
        for right_label, right_raw in CORPUS.items():
            pair = left_label + "/" + right_label
            raw = c.selector(c.V(control), left_raw, right_raw)
            formula = v.formula(raw)
            for endpoint, image, target in [
                    ("zero", ("0",), parsed[left_label]),
                    ("successor", one_image, parsed[right_label])]:
                opened = s.instantiate_fresh(formula, control, image)
                equal, receipt = s.equivalent(opened, target)
                check("selector-" + endpoint + "/" + pair, "selector_endpoint", equal, receipt)
            for macro_name, build in [("implication", c.implies),
                                      ("conjunction", c.conjunction),
                                      ("disjunction", c.disjunction)]:
                constructed = build(left_raw, right_raw)
                checked = v.formula(constructed)
                check(macro_name + "/" + pair, "logical_macro_syntax",
                      v.free(checked) == v.free(parsed[left_label]) | v.free(parsed[right_label]))
                for side, target in [(0, parsed[left_label]), (1, parsed[right_label])]:
                    if macro_name == "implication":
                        image = ("0",) if side == 0 else ("S", ("0",))
                        opened = s.instantiate_fresh(checked[3], checked[2], image)
                    elif macro_name == "conjunction":
                        image = ("S", ("0",)) if side == 0 else ("S", ("S", ("0",)))
                        opened = s.instantiate_fresh(checked[3], checked[2], image)
                    else:
                        # First expose the existential's successor gate; then
                        # choose its zero/successor witness for the disjunction.
                        opened = s.instantiate_fresh(checked[3], checked[2], ("S", ("0",)))
                        image = ("0",) if side == 0 else ("S", ("0",))
                        opened = s.instantiate_fresh(opened, checked[1], image)
                    equal, receipt = s.equivalent(opened, target)
                    check(f"{macro_name}-endpoint/{pair}/{side}",
                          "logical_macro_endpoint", equal, receipt)
            if left_label == "equation" and right_label == "nested":
                examples["formulas"]["mixed_selector"] = raw
                examples["formulas"]["mixed_implication"] = c.implies(left_raw, right_raw)
                examples["formulas"]["mixed_conjunction"] = c.conjunction(left_raw, right_raw)
                examples["formulas"]["mixed_disjunction"] = c.disjunction(left_raw, right_raw)

    for label, raw in CORPUS.items():
        for macro_name, build in [("existential", c.exists), ("universal", c.universal)]:
            result = v.formula(build("a", raw))
            check(macro_name + "/" + label, "logical_macro_syntax",
                  v.free(result) == v.free(parsed[label]) - {"a"})
            parameter = ("v", "quantified_parameter")
            if macro_name == "universal":
                opened = s.instantiate_fresh(result[3], result[2], ("S", parameter))
                target = s.instantiate_fresh(parsed[label], "a", parameter)
            else:
                opened = s.instantiate_fresh(result[3], result[2], ("S", ("0",)))
                target = parsed[label]
            equal, receipt = s.equivalent(opened, target)
            check(macro_name + "-endpoint/" + label, "logical_macro_endpoint", equal, receipt)

    # Explicit parser rejection controls, including the old false-base atom.
    bad = {
        "unrestricted_false_base": ["D", "x", "y", ["=", ["v", "y"], ["S", ["0"]]]],
        "wrong_guard_control": ["D", "x", "y", ["=",
            ["C", ["v", "x"], ["0"], ["v", "a"]],
            ["C", ["v", "x"], ["0"], ["v", "b"]]]],
        "nongated_right": ["D", "x", "y", ["=",
            ["C", ["v", "y"], ["0"], ["v", "a"]], ["v", "b"]]],
        "nonzero_initial_guard": ["D", "x", "y", ["=",
            ["C", ["v", "y"], ["S", ["0"]], ["v", "a"]],
            ["C", ["v", "y"], ["0"], ["v", "b"]]]],
        "duplicate_binder": ["D", "x", "x", ["=", ["0"], ["0"]]],
        "wrong_function_arity": ["=", ["f", "f", [["0"]]], ["0"]],
        "unknown_function": ["=", ["f", "unknown", []], ["0"]],
        "boolean_variable": ["=", ["v", True], ["0"]],
        "unknown_formula_tag": ["forall", "x", ["=", ["0"], ["0"]]],
        "wrong_C_arity": ["=", ["C", ["0"], ["0"]], ["0"]],
    }
    for label, raw in bad.items():
        rejected = False
        try:
            v.formula(raw)
        except (v.SyntaxError, TypeError):
            rejected = True
        check("syntax-negative/" + label, "malformed_syntax_rejection", rejected)

    # These binders are legal, but they are not vacuous padding: an inverse
    # gate match alone is insufficient unless both freshness checks hold.
    for dependent in ("x", "y"):
        raw = ["D", "x", "y", ["=",
            ["C", ["v", "y"], ["0"], ["v", dependent]],
            ["C", ["v", "y"], ["0"], ["0"]]]]
        check("padding-nonvacuous/" + dependent, "invalid_padding_rejection",
              s.padding_instance(v.formula(raw)) is None)

    # An intentionally captured substitution must differ from the independent
    # bound-indexed reference. This checks that the comparison can detect it.
    source = parsed["guarded"]
    corrupted = deepcopy(CORPUS["guarded"])
    corrupted[3][2][3][2][0] = ["v", "y"]
    reference = v.canonical_free_substitution(v.canonical(source),
                                             {"a": ("free", "y")})
    check("captured-substitution-control", "semantic_negative_control",
          v.canonical(v.formula(corrupted)) != reference)

    incorrect = v.formula(c.selector(c.V(control), CORPUS["equation"], CORPUS["opaque_functions"]))
    opened = s.instantiate_fresh(incorrect, control, ("0",))
    equal, _ = s.equivalent(opened, parsed["opaque_functions"])
    check("wrong-selector-endpoint-control", "semantic_negative_control", not equal)

    stale = deepcopy(CORPUS["guarded"])
    stale[2] = "new_counter"
    try:
        v.formula(stale)
        rejected = False
    except v.SyntaxError:
        rejected = True
    check("stale-counter-guard-control", "semantic_negative_control", rejected)

    # Exercise the actual public parser in normal and optimized Python.
    for optimized in (False, True):
        command = [sys.executable, *( ["-O"] if optimized else []), str(ROOT / "validator.py")]
        for label, raw, expected_status in [
                ("legal", examples["formulas"]["mixed_implication"], 0),
                ("illegal", bad["unrestricted_false_base"], 1)]:
            packet = {"signature": v.DEFAULT_SIGNATURE, "formula": raw}
            completed = subprocess.run(command, input=json.dumps(packet), text=True,
                                       capture_output=True, timeout=15)
            expected_verdict = "ACCEPT" if expected_status == 0 else "REJECT"
            answer = json.loads(completed.stdout)
            check(f"public-cli/{optimized}/{label}", "public_parser_cli",
                  completed.returncode == expected_status and answer["syntax"] == expected_verdict)

    totals = Counter(item["category"] for item in records)
    result = {
        "status": "PASS",
        "python": platform.python_version(),
        "checks": len(records),
        "categories": dict(sorted(totals.items())),
        "scope": "Finite syntax, capture avoidance, and symbolic endpoints only; not a full proof checker or a universal metatheory formalization.",
        "computational_equations": ["C0", "CS", "P0", "PS"],
        "logical_schemas_used": ["Vacuous padding D_(x,y) G_y A <-> A (fresh x,y)",
                                 "Equality reflexivity and D wrapping of uniformly reflexive matrices"],
        "files": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in sorted(ROOT.glob("*.py"))},
        "example_hash": digest(examples),
        "largest_example_tree_units": max(size(a) for a in examples["formulas"].values()),
        "records": records,
    }
    (ROOT / "examples.json").write_text(json.dumps(examples, indent=2) + "\n")
    (ROOT / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "records"}, indent=2))


if __name__ == "__main__":
    main()
