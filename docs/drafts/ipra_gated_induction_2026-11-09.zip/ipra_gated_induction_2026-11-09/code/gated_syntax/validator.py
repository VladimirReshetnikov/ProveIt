"""Independent parser for the finite gated-D syntax; not a proof checker.

This module does not import the formula constructors. Public input consists
of JSON arrays. Its output consists of immutable tuples. Only syntactic
arity and the direct-atomic-body gate restriction are checked.
"""

import json
import re
import sys


DEFAULT_SIGNATURE = {"add": 2, "mul": 2, "pred": 1, "f": 2, "h": 3}
_NAME = re.compile(r"[A-Za-z_][A-Za-z_0-9]*\Z")


class SyntaxError(ValueError):
    pass


def name(value):
    if not isinstance(value, str) or not _NAME.fullmatch(value):
        raise SyntaxError("Expected an ordinary variable/function name")
    return value


def signature(raw):
    if type(raw) is not dict:
        raise SyntaxError("The function signature must be an object")
    result = {}
    for symbol, arity in raw.items():
        name(symbol)
        if symbol in {"v", "S", "C", "D", "f_builtin"}:
            raise SyntaxError("Reserved symbol in function signature")
        if type(arity) is not int or arity < 0:
            raise SyntaxError("A function arity must be a nonnegative integer")
        result[symbol] = arity
    return result


def term(raw, functions=None):
    functions = DEFAULT_SIGNATURE if functions is None else functions
    if type(raw) is not list or not raw or type(raw[0]) is not str:
        raise SyntaxError("A term must be a tagged array")
    tag = raw[0]
    if tag == "0" and len(raw) == 1:
        return ("0",)
    if tag == "v" and len(raw) == 2:
        return ("v", name(raw[1]))
    if tag == "S" and len(raw) == 2:
        return ("S", term(raw[1], functions))
    if tag == "C" and len(raw) == 4:
        return ("C", *(term(child, functions) for child in raw[1:]))
    if tag == "f" and len(raw) == 3:
        symbol = name(raw[1])
        if symbol not in functions or type(raw[2]) is not list:
            raise SyntaxError("Unknown function or malformed argument list")
        if len(raw[2]) != functions[symbol]:
            raise SyntaxError("Wrong function arity")
        return ("f", symbol, tuple(term(child, functions) for child in raw[2]))
    raise SyntaxError("Unknown term constructor or wrong constructor arity")


def is_gate_atom(body, counter):
    if body[0] != "=":
        return False
    return all(side[0] == "C" and side[1] == ("v", counter)
               and side[2] == ("0",) for side in body[1:])


def formula(raw, functions=None):
    functions = DEFAULT_SIGNATURE if functions is None else functions
    if type(raw) is not list or not raw or type(raw[0]) is not str:
        raise SyntaxError("A formula must be a tagged array")
    if raw[0] == "=" and len(raw) == 3:
        return ("=", term(raw[1], functions), term(raw[2], functions))
    if raw[0] == "D" and len(raw) == 4:
        witness, counter = name(raw[1]), name(raw[2])
        if witness == counter:
            raise SyntaxError("The two paired binders must be distinct")
        body = formula(raw[3], functions)
        if body[0] == "=" and not is_gate_atom(body, counter):
            raise SyntaxError("A direct atomic D body must literally be zero-gated")
        return ("D", witness, counter, body)
    raise SyntaxError("Unknown formula constructor or wrong constructor arity")


def term_free(t):
    if t[0] == "v":
        return {t[1]}
    if t[0] == "0":
        return set()
    children = t[2] if t[0] == "f" else t[1:]
    return set().union(*(term_free(child) for child in children))


def free(a):
    if a[0] == "=":
        return term_free(a[1]) | term_free(a[2])
    return free(a[3]) - {a[1], a[2]}


def bound_names(a):
    if a[0] == "=":
        return set()
    return {a[1], a[2]} | bound_names(a[3])


def canonical_term(t, bound=()):
    if t[0] == "v":
        return ("bound", bound.index(t[1])) if t[1] in bound else ("free", t[1])
    if t[0] == "0":
        return t
    if t[0] == "f":
        return ("f", t[1], tuple(canonical_term(child, bound) for child in t[2]))
    return (t[0], *(canonical_term(child, bound) for child in t[1:]))


def canonical(a, bound=()):
    """Alpha-normal form using de Bruijn indices, independent of producers."""
    if a[0] == "=":
        return ("=", canonical_term(a[1], bound), canonical_term(a[2], bound))
    return ("D", canonical(a[3], (a[2], a[1], *bound)))


def canonical_free_substitution(tree, replacements):
    """Reference substitution on already bound-indexed syntax.

    Replacement terms are canonical at the empty binder environment, hence
    have no bound indices. They cannot be captured by insertion.
    """
    if not isinstance(tree, tuple):
        return tree
    if len(tree) == 2 and tree[0] == "free" and tree[1] in replacements:
        return replacements[tree[1]]
    return tuple(canonical_free_substitution(x, replacements) for x in tree)


def to_json(tree):
    if isinstance(tree, tuple):
        return [to_json(child) for child in tree]
    return tree


def main():
    try:
        packet = json.load(sys.stdin)
        if type(packet) is not dict or set(packet) != {"signature", "formula"}:
            raise SyntaxError("Expected exactly signature and formula fields")
        parsed = formula(packet["formula"], signature(packet["signature"]))
        print(json.dumps({"syntax": "ACCEPT", "free_variables": sorted(free(parsed))}))
    except (ValueError, TypeError, KeyError, RecursionError) as exc:
        print(json.dumps({"syntax": "REJECT", "reason": str(exc)}))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
