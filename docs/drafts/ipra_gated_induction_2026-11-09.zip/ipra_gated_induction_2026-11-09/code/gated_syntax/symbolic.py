"""Independent finite symbolic endpoint replay.

Only four designated PR equations are computational reductions:
  C(0,a,b)=a, C(Sn,a,b)=b, pred(0)=0, pred(Sn)=n.
Other function symbols remain uninterpreted. In addition, the optional
padding contraction checks a literal instance of the manuscript's proved
schema D_(x,y) G_y A <-> A, with x,y absent from FV(A). This is explicitly
a cited mathematical schema, not a primitive derivation verified here.
"""

from collections import Counter

import validator as v


def reduce_term(t, counts):
    tag = t[0]
    if tag in {"0", "v"}:
        return t
    if tag == "f":
        args = tuple(reduce_term(child, counts) for child in t[2])
        if t[1] == "pred":
            if args[0] == ("0",):
                counts["P0"] += 1
                return ("0",)
            if args[0][0] == "S":
                counts["PS"] += 1
                return args[0][1]
        return ("f", t[1], args)
    children = tuple(reduce_term(child, counts) for child in t[1:])
    if tag == "C":
        control, zero_case, successor_case = children
        if control == ("0",):
            counts["C0"] += 1
            return zero_case
        if control[0] == "S":
            counts["CS"] += 1
            return successor_case
    return (tag, *children)


def unguard_term(t, control):
    if t[0] == "C" and t[1] == ("v", control) and t[2] == ("0",):
        return t[3]
    return None


def ungate(a, control):
    """Recognize a literal payload-aware G_control instance independently."""
    if a[0] == "=":
        left = unguard_term(a[1], control)
        right = unguard_term(a[2], control)
        return None if left is None or right is None else ("=", left, right)
    _, witness, counter, body = a
    if control in {witness, counter}:
        return None
    if body[0] == "=":
        if not v.is_gate_atom(body, counter):
            return None
        left = unguard_term(body[1][3], control)
        right = unguard_term(body[2][3], control)
        if left is None or right is None:
            return None
        base = ("0",)
        guarded = ("=", ("C", ("v", counter), base, left),
                   ("C", ("v", counter), base, right))
        return ("D", witness, counter, guarded)
    inner = ungate(body, control)
    return None if inner is None else ("D", witness, counter, inner)


def padding_instance(a):
    if a[0] != "D":
        return None
    _, witness, counter, body = a
    candidate = ungate(body, counter)
    if candidate is None or {witness, counter} & v.free(candidate):
        return None
    # Check that removal leaves an admissible formula in the same grammar.
    v.formula(v.to_json(candidate))
    return candidate


def normal_form(a, counts=None, use_padding=True):
    counts = Counter() if counts is None else counts
    if a[0] == "=":
        return ("=", reduce_term(a[1], counts), reduce_term(a[2], counts))
    body = normal_form(a[3], counts, use_padding)
    candidate = ("D", a[1], a[2], body)
    if use_padding:
        contracted = padding_instance(candidate)
        if contracted is not None:
            counts["padding_schema"] += 1
            return normal_form(contracted, counts, use_padding)
    return candidate


def instantiate_fresh(a, variable, image):
    """Independent endpoint instantiation; freshness is checked explicitly."""
    if variable in v.bound_names(a) or v.term_free(image) & v.bound_names(a):
        raise ValueError("Endpoint control or image is not fresh for the binders")

    def term(t):
        if t[0] == "v":
            return image if t[1] == variable else t
        if t[0] == "0":
            return t
        if t[0] == "f":
            return ("f", t[1], tuple(term(child) for child in t[2]))
        return (t[0], *(term(child) for child in t[1:]))

    def formula(b):
        if b[0] == "=":
            return ("=", term(b[1]), term(b[2]))
        return ("D", b[1], b[2], formula(b[3]))

    return formula(a)


def equivalent(a, b):
    """Exact alpha comparison after the stated computation/padding schemas."""
    left_counts, right_counts = Counter(), Counter()
    left = normal_form(a, left_counts)
    right = normal_form(b, right_counts)
    return (v.canonical(left) == v.canonical(right),
            {"left": dict(left_counts), "right": dict(right_counts)})


def reflexive_leaves(a):
    """A schematic theorem certificate, using derived equality reflexivity.

    D wrapping of a uniformly reflexive matrix is derivable by DI ignoring
    its local assumption. This routine does not expand those derivations.
    """
    if a[0] == "=":
        return a[1] == a[2]
    return reflexive_leaves(a[3])
