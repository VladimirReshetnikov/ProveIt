GATED-D FINITE SYNTAX AND ENDPOINT EVIDENCE
=========================================

Scope
-----
These files support the gated-induction manuscript with finite, executable
syntax and symbolic-computation evidence. They are NOT a complete iPRA
proof checker, a proof of the universal metatheorems, a Lean/Rocq
formalization, or a new entry below the existing complete-checker frontier.

Run
---
From this directory, with Python 3 and its standard library:

    python3 verify.py

The recorded run used CPython 3.12.14. It completed 649 checks with no
failures. It writes results.json (all named receipts and source hashes)
and examples.json (representative generated formulas). Running it again
regenerates those two files. No network or third-party package is needed.

Contents and trust boundaries
-----------------------------
validator.py is an independent JSON parser and finite grammar validator.
It does not import the constructors. It checks numerical/formula arities,
function-symbol arities, names, distinct paired binders, and the exact
gate restriction on a D whose immediate body is an equation.

constructors.py is an untrusted producer of capture-avoiding numerical
substitution, payload-aware gates, padding, selectors, and the manuscript's
derived logical macros. Its output is independently parsed and validated.

symbolic.py normalizes only these designated primitive-recursive equations:

    C(0,a,b) = a                  C(Sn,a,b) = b
    pred(0) = 0                  pred(Sn) = n.

All other function symbols stay uninterpreted. The replayer also recognizes
literal instances of the manuscript's proved vacuous-padding schema

    D_(x,y) G_y A <-> A,          x,y absent from the free variables of A.

That schema is an explicitly imported mathematical dependency. The program
checks its exact syntactic instance and freshness; it does not expand its
primitive derivation. The G_0 checks use equality reflexivity and D-wrapping
of uniformly reflexive leaves as explicitly declared derived schemata.
They are not assertions of a full proof-assistant verification.

verify.py starts from seven independent literal JSON fixtures, including
equations, direct guarded binders, depth-three formulas, repeated/shadowed
bound names, and literal padding. It checks all ordered fixture pairs.
Capture-avoiding substitutions are compared with a separately implemented
de Bruijn reference substitution, not with the producer itself. Endpoint
comparisons use exact C/P reductions, the stated padding schema, and alpha
equivalence. No numerical semantic evaluator or truth oracle is used.

Recorded finite checks
----------------------
  28  Capture-avoiding substitutions, checked by an independent reference
   7  External gate controls colliding with existing binder names
   7  G_(Su) endpoint comparisons
   7  G_0 reflexive-leaf checks
   2  Rejection of nonvacuous alleged padding
   7  Independently written literal fixtures
 308  Logical macro endpoint comparisons
 161  Logical macro syntax/free-variable checks
  10  Malformed or forbidden formula rejections
   7  Exact vacuous-padding schema instances
   4  Public parser CLI checks in ordinary and optimized Python
  98  Selector endpoint comparisons at equal and unequal formula depths
   3  Captured substitution, wrong endpoint, and stale guard controls
 ---
 649  Total

The logical endpoint tests exercise implication, conjunction, disjunction,
existential gates, and universal predecessor gates. They check the necessary
finite endpoint identities, not all introduction/elimination derivations.

Public syntax validator
-----------------------
validator.py reads an object with exactly two fields:

    {"signature": {"add": 2, ...}, "formula": <formula-array>}

An accepted formula prints a JSON verdict with "syntax": "ACCEPT" and its
free variables, and exits zero. A malformed/forbidden formula prints
"syntax": "REJECT" and exits one. This verdict concerns syntax only.
See FORMAT.txt for the exact grammar.

The signature gives fixed function names and arities. This parser does not
check primitive-recursive description declarations or prove defining
equations for those arbitrary symbols. C and pred are the designated
abbreviations with the four displayed computation equations.

Limits
------
Finite fixtures do not establish closure for every formula or substitution.
The manuscript provides those structural proofs. The evidence does not
implement native inference checking, ordinary proof translation, the full
primitive-recursive compiler, or either bi-interpretation composite.
Python recursion/memory limits can reject sufficiently large syntactic
inputs. None of these file sizes is presented as a complete-checker record.
