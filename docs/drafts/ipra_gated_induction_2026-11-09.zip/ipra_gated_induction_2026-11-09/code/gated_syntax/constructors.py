"""Untrusted finite formula constructors for the gated-D presentation.

Public output is JSON syntax consumed by the independent validator. The
functions here are syntactic builders, not an acceptance kernel.
"""


def V(x):
    return ["v", x]


def Z():
    return ["0"]


def S(t):
    return ["S", t]


def C(control, first, second):
    return ["C", control, first, second]


def F(symbol, *arguments):
    return ["f", symbol, list(arguments)]


def Eq(s, t):
    return ["=", s, t]


def D(x, y, body):
    return ["D", x, y, body]


def term_variables(t):
    if t[0] == "v":
        return {t[1]}
    if t[0] == "0":
        return set()
    children = t[2] if t[0] == "f" else t[1:]
    result = set()
    for child in children:
        result.update(term_variables(child))
    return result


def free_variables(a):
    if a[0] == "=":
        return term_variables(a[1]) | term_variables(a[2])
    return free_variables(a[3]) - {a[1], a[2]}


def all_names(a):
    if a[0] == "=":
        return term_variables(a[1]) | term_variables(a[2])
    return {a[1], a[2]} | all_names(a[3])


def fresh(avoid, prefix="g"):
    index = 0
    while prefix + str(index) in avoid:
        index += 1
    result = prefix + str(index)
    avoid.add(result)
    return result


def subst_term(t, mapping):
    if t[0] == "v":
        return mapping.get(t[1], t)
    if t[0] == "0":
        return t
    if t[0] == "f":
        return F(t[1], *(subst_term(child, mapping) for child in t[2]))
    return [t[0], *(subst_term(child, mapping) for child in t[1:])]


def substitute(a, mapping):
    """Simultaneous free numerical substitution with alpha-renaming."""
    if a[0] == "=":
        return Eq(subst_term(a[1], mapping), subst_term(a[2], mapping))
    _, x, y, body = a
    usable = {key: val for key, val in mapping.items() if key not in {x, y}}
    image_names = set().union(*(term_variables(t) for t in usable.values()))
    avoid = all_names(a) | image_names | set(mapping)
    if x in image_names:
        new_x = fresh(avoid, "sx")
        body = substitute(body, {x: V(new_x)})
        x = new_x
    if y in image_names:
        new_y = fresh(avoid, "sy")
        body = substitute(body, {y: V(new_y)})
        y = new_y
    return D(x, y, substitute(body, usable))


def rename_outer(a, x, y):
    if a[0] != "D":
        raise ValueError("Expected a paired formula")
    old_x, old_y = a[1:3]
    if x == y or {x, y} & (all_names(a) - {old_x, old_y}):
        raise ValueError("New outer binder names must be fresh")
    return D(x, y, substitute(a[3], {old_x: V(x), old_y: V(y)}))


def gate_term(control, t):
    return C(control, Z(), t)


def gate_atom(counter, s, t):
    return Eq(gate_term(V(counter), s), gate_term(V(counter), t))


def payload(body, counter):
    if body[0] != "=" or any(side[0] != "C" or side[1] != V(counter)
                              or side[2] != Z() for side in body[1:]):
        raise ValueError("Expected a literal zero-gated equation")
    return body[1][3], body[2][3]


def gate(control, a):
    if a[0] == "=":
        return Eq(gate_term(control, a[1]), gate_term(control, a[2]))
    _, x, y, body = a
    if {x, y} & term_variables(control):
        avoid = all_names(a) | term_variables(control)
        x, y = fresh(avoid, "gx"), fresh(avoid, "gy")
        a = rename_outer(a, x, y)
        body = a[3]
    if body[0] == "=":
        s, t = payload(body, y)
        return D(x, y, gate_atom(y, gate_term(control, s), gate_term(control, t)))
    return D(x, y, gate(control, body))


def padding(a, names=None):
    if names is None:
        avoid = all_names(a)
        x, y = fresh(avoid, "px"), fresh(avoid, "py")
    else:
        x, y = names
        if x == y or {x, y} & all_names(a):
            raise ValueError("Padding variables must be fresh")
    return D(x, y, gate(V(y), a))


def selector(control, a, b):
    if a[0] == b[0] == "=":
        return Eq(C(control, a[1], b[1]), C(control, a[2], b[2]))
    avoid = all_names(a) | all_names(b) | term_variables(control)
    x, y = fresh(avoid, "mx"), fresh(avoid, "my")
    aa = padding(a, (x, y)) if a[0] == "=" else rename_outer(a, x, y)
    bb = padding(b, (x, y)) if b[0] == "=" else rename_outer(b, x, y)
    left, right = aa[3], bb[3]
    if left[0] == right[0] == "=":
        s, t = payload(left, y)
        u, w = payload(right, y)
        body = gate_atom(y, C(control, s, u), C(control, t, w))
    else:
        body = selector(control, left, right)
    return D(x, y, body)


def exists(variable, a):
    """Derived existential: D_(variable,y) G_y A."""
    avoid = all_names(a) | {variable}
    y = fresh(avoid, "ey")
    return D(variable, y, gate(V(y), a))


def implies(a, b):
    """Use a compound matrix so arbitrary antecedents use case DI."""
    avoid = all_names(a) | all_names(b)
    x, y = fresh(avoid, "ix"), fresh(avoid, "iy")
    return D(x, y, selector(V(y), padding(a), padding(b)))


def disjunction(a, b):
    avoid = all_names(a) | all_names(b)
    x = fresh(avoid, "dx")
    return exists(x, selector(V(x), a, b))


def conjunction(a, b):
    avoid = all_names(a) | all_names(b)
    x, y = fresh(avoid, "cx"), fresh(avoid, "cy")
    chosen = selector(F("pred", V(y)), a, b)
    return D(x, y, gate(V(y), chosen))


def universal(variable, a):
    avoid = all_names(a) | {variable}
    x, y = fresh(avoid, "ax"), fresh(avoid, "ay")
    instance = substitute(a, {variable: F("pred", V(y))})
    return D(x, y, gate(V(y), instance))
