#!/usr/bin/env python3
"""Rebuild the PDF; no network or third-party Python packages are used."""

from pathlib import Path
import argparse
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--engine", default="pdflatex")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    engine = shutil.which(args.engine)
    if engine is None:
        raise SystemExit(f"Required LaTeX engine is unavailable: {args.engine}")
    build = root / "build"
    build.mkdir(exist_ok=True)
    command = [engine, "-interaction=nonstopmode", "-halt-on-error",
               "-file-line-error", "-output-directory", str(build), "report.tex"]
    for pass_number in range(1, 4):
        process = subprocess.run(command, cwd=root, text=True,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, check=False)
        (build / f"pass_{pass_number}.txt").write_text(process.stdout)
        if process.returncode:
            print(process.stdout[-8000:], file=sys.stderr)
            raise SystemExit(f"LaTeX pass {pass_number} failed.")
    log = (build / "report.log").read_text(errors="replace")
    problems = [line for line in log.splitlines()
                if any(token in line for token in
                       ("Overfull", "undefined", "multiply defined",
                        "same identifier", "Rerun to get"))]
    if problems:
        raise SystemExit("Review LaTeX diagnostics:\n" + "\n".join(problems))
    destination = root / "report.pdf"
    shutil.copy2(build / "report.pdf", destination)
    print(f"Built {destination.name}: {destination.stat().st_size:,} bytes")
    print("Three LaTeX passes completed; cross-references resolved.")


if __name__ == "__main__":
    main()
