iPRA WITH COMPUTATION AND QUANTIFIER-FREE INDUCTION
Research package prepared for Vladimir Reshetnikov
3 November 2026
=================================================

MAIN RESULT
The recommended theory uses ordinary intuitionistic first-order equality
logic, 0 != S0, primitive recursive defining equations, and quantifier-free
induction. The familiar core is standard mathematics. The recommendation
is a cognitive simplification of the supplied specialized presentations.

Successor injectivity and successor nonzeroness follow from the predecessor
computation and separation. One quantifier-free induction proves numerical
coverage. With a shared conventional description language, both full
first-order interpretations and their composites are literal identity.
The report additionally proves both compiler round trips for the current
drafts' initialized-recursion interface.

The optional minimal-logic variant retains genuine falsity, replaces
separation by FALSE iff 0=S0, and derives falsity elimination. The report
also gives three deletion countermodels and the stronger N x N obstruction
to equation-only induction.

CONTENTS
  report.tex                 Complete paper, including all proofs.
  report.pdf                 Compiled paper.
  AXIOMS.txt                 Standalone specification and theorem summary.
  build.py                   Standard-library Python PDF rebuild script.
  provenance/sources.json    Eight pinned source archives and verified hashes.
  provenance/AUDIT.txt       Historical filter and precise comparison scope.
  VALIDATION.txt             Proof-review and PDF-validation scope.
  SHA256SUMS.txt             Checksums of the delivered files except itself.

BUILD
Run from any directory:
  python3 /path/to/extracted/package/build.py

Requires pdflatex and the usual LaTeX packages listed in the preamble.
The script runs three passes, checks reference/layout diagnostics, and
replaces report.pdf. Intermediates go into a build subdirectory. Rebuilding
may change PDF metadata and hence its hash without changing the content.
No network access or third-party Python package is needed by build.py.

SOURCE SNAPSHOT
Repository: VladimirReshetnikov/ProveIt
Commit: 77e7fdf4a46344cc79cc9c88d78954bab1764ec5
Directory: docs/drafts (four current archives, four in archived)
All four current proposals survive the historical improvement filter;
three principally optimize expressions, while equation closure changes
the reference arithmetic core. Original archives are not duplicated here.

CLAIM SCOPE
The construction is fully bi-interpretable and syntactically equiconsistent
with the explicitly specified full first-order iPRA, preserving genuine
falsity and every logical operation. No claim is made of an absolute
shortest axiomatization, universal proof-length improvement, or a numerical
minimum for human cognitive simplicity. The broader ordinary induction
index class is an explicit tradeoff.

Written proofs were independently reviewed. They are not Lean/Rocq
certified, and no finite numerical experiments are used as evidence for
the full metatheorems. See the Further research questions section.
