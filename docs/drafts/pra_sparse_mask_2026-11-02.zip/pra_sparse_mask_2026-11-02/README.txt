SPARSE MASK ARITHMETIC
Prepared for Vladimir Reshetnikov, November 2, 2026

MAIN RESULT
Two equivalent effective first-order presentations of PRA with smaller
emitted axiom instances. The complete written proof establishes a common
conservative definitional extension, full-carrier bi-interpretations, and
identity round trips. The result is not a claim of an absolute minimum.

Read report.pdf; its editable source is report.tex plus sections/*.tex.
AXIOMS.txt gives the exact specification without the surrounding report.

The two versions differ only in a syntactic threshold:
  T_A chooses the smaller active formula tree.
  T_D chooses the smaller formula after recursively expanding descriptors.
T_D is recommended when hidden descriptor repetition is the concern.
All tests inspect the RAW input, before the root-normalization rule.

The literal-zero input emits only the fixed 18-node sentence. Zero-recursion
equations are recovered from Q(S0,a). This omission is intentional.

VERIFICATION
  checks/check_emitter.py             Independent syntax-tree audit
  verification/emitter_results.json  Exact counts, examples, comparison scope
  formal/CompactEmitterKernel.lean    Lean-checked local logical kernel
  formal/SCOPE.txt                    What is and is not formalized
  formal/lean-check.log               Successful Lean 4.19.0 check
  source_manifest.json               Pinned six-archive inventory and hashes

The full bi-interpretability theorem is proved in the report, not entirely
formalized in Lean. The kernel has explicit arithmetic/schematic premises.
The executable finite tests are not a substitute for the mathematical proof.

REBUILD
  python3 build.py
Requires Python 3 and pdflatex with common AMS, Latin Modern, geometry,
hyperref, booktabs, tabularx, enumitem, fancyhdr, xurl and microtype packages.
Optional formal check:
  python3 formal/check_lean.py --lean /path/to/lean
Use Lean 4.19.0. No Mathlib or network dependency is required.

COMPARISON CAVEATS
The active-aware version strictly improves the principal printed baseline
instances on common raw inputs. The descriptor-aware version gives the
corresponding strict expanded-tree improvement, but can tie the constancy
draft in active size on small terms with large frozen descriptors.
An optional separately factored mask core already has the same recurring
large-term active size; it is discussed separately in the report.
The new generator has five leaf cases and uses both a binary mask and the
earlier root-normalized recursor grammar. These are real specification costs.

Repository snapshot:
d46d2b97cb3c4d4f3a0154fc5884ea42ffcd5966
https://github.com/VladimirReshetnikov/ProveIt/tree/d46d2b97cb3c4d4f3a0154fc5884ea42ffcd5966/docs/drafts

The report credits each inherited ingredient. No repository changes or
external publications were made for this task.
