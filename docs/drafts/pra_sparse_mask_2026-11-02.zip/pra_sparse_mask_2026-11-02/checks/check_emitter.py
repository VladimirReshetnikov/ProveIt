#!/usr/bin/env python3
"""Independent syntactic audit of the hybrid PRA emitter.

This checks formula syntax and counts, not arithmetic equivalence or proofs.
Stored recursor descriptors are actual immutable trees, and substitutions
change active arguments only.  All indices are root-normalized on creation.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple['Term', ...] = ()
    name: str = ''
    descriptor: 'Term | None' = None


@dataclass(frozen=True)
class Formula:
    op: str
    args: tuple[object, ...] = ()
    binder: str = ''


def V(name): return Term('var', name=name)
Z = Term('zero')
def S(t): return Term('successor', (t,))
def Delta(t, s): return Term('mask', (t, s))


def nf(t):
    while (t.op == 'rec' and t.descriptor == V('w')
           and t.args[0].op == 'successor'):
        t = t.args[0].args[0]
    return t


def R(body, n, a):
    return Term('rec', (n, a), descriptor=nf(body))


def Q(n, a): return R(V('w'), n, a)


@lru_cache(None)
def size(t, full=False):
    if isinstance(t, Term):
        return (1 + sum(size(x, full) for x in t.args)
                + (size(t.descriptor, True)
                   if full and t.op == 'rec' else 0))
    assert isinstance(t, Formula)
    return 1 + sum(size(x, full) for x in t.args)


@lru_cache(None)
def occurrences(t, name):
    if t.op == 'var': return int(t.name == name)
    return sum(occurrences(x, name) for x in t.args)


def subst(t, mapping):
    if t.op == 'var': return mapping.get(t.name, t)
    # The descriptor is deliberately NOT traversed or substituted.
    return Term(t.op, tuple(subst(x, mapping) for x in t.args),
                t.name, t.descriptor)


def E(x, y): return Formula('eq', (x, y))
def And(x, y): return Formula('and', (x, y))
def Or(x, y): return Formula('or', (x, y))
def Imp(x, y): return Formula('implies', (x, y))
def All(v, x): return Formula('forall', (x,), v)
Bot = Formula('false')
n, a, k = V('n'), V('a'), V('k')
sigma = Imp(E(Z, S(Z)), Bot)
off = Or(E(n, a), E(Delta(n, a), Z))
exception = Z


def at(u, x, y): return subst(u, {'n': x, 'a': y})
def descriptor(u): return nf(at(u, V('v'), V('w')))


def computational(u, right=False):
    h = descriptor(u)
    base = E(R(h, Z, a), a)
    update = (R(h, n, at(u, a, Z)) if right
              else at(u, R(h, n, a), n))
    return And(base, E(R(h, S(n), a), update))


def constancy(u):
    premise = All('k', E(at(u, S(k), a), at(u, k, a)))
    return Imp(premise, E(u, at(u, Z, a)))


def mask_fp(u):
    def pred(x): return E(Delta(x, at(u, x, a)), x)
    premise = All('k', Imp(pred(k), E(at(u, S(k), a), S(k))))
    return Imp(premise, pred(n))


def emit(u, full_aware=False):
    i, j = occurrences(u, 'n'), occurrences(u, 'a')
    if u == exception:
        matrix = And(sigma, off)
        branch = 'exception'
    elif i == 0:
        matrix = computational(u)
        branch = 'left'
    elif j == 0:
        matrix = computational(u, right=True)
        branch = 'right'
    elif size(u, full_aware) <= 10:
        matrix = And(computational(u), constancy(u))
        branch = 'constancy'
    else:
        matrix = And(computational(u), mask_fp(u))
        branch = 'mask_fp'
    return All('a', All('n', matrix)), branch


def expected(u, branch, full=False):
    m = size(u, full)
    i = occurrences(u, 'n')
    h = size(descriptor(u), True) if full else 0
    if branch == 'exception': return 18
    if branch == 'left': return 13 + m + 2*i + (2+i)*h
    if branch == 'right': return 15 + m + 3*h
    if branch == 'constancy': return 18 + 5*m + 3*i + (2+i)*h
    if branch == 'mask_fp': return 28 + 4*m + 3*i + (2+i)*h
    raise AssertionError(branch)


def quantifiers(f):
    if isinstance(f, Term): return (0, 0)
    children = [quantifiers(x) for x in f.args]
    extra = int(f.op == 'forall')
    return (extra + sum(x[0] for x in children),
            extra + max((x[1] for x in children), default=0))


def show(t):
    if t.op == 'var': return t.name
    if t.op == 'zero': return '0'
    if t.op == 'successor': return 'S(' + show(t.args[0]) + ')'
    if t.op == 'mask': return 'Delta(' + ','.join(map(show,t.args)) + ')'
    return 'R[' + show(t.descriptor) + '](' + ','.join(map(show,t.args)) + ')'


def pad(t):
    for v in (a,n,a,n): t = Q(S(t), v)
    return t


def make_descriptors():
    v,w=V('v'),V('w')
    pred=Q(v,Z)
    subtraction=R(pred,w,v)
    deep=Delta(R(Delta(v,w),v,w), S(subtraction))
    return tuple(dict.fromkeys(map(nf, (
        Z,v,w,S(v),S(w),Delta(v,w),pred,subtraction,deep))))


def enumerate_terms(max_size, descriptors):
    by_size={1:(Z,n,a)}
    for length in range(2,max_size+1):
        found={S(t) for t in by_size[length-1]}
        for left in range(1,length-1):
            right=length-1-left
            for x in by_size[left]:
                for y in by_size[right]:
                    found.add(Delta(x,y))
                    for h in descriptors: found.add(R(h,x,y))
        by_size[length]=tuple(sorted(found,key=show))
    return tuple(t for k in sorted(by_size) for t in by_size[k])


def random_terms(count, descriptors):
    rng=random.Random(20261102)
    def term(depth):
        if depth==0 or rng.randrange(7)==0: return rng.choice((Z,n,a))
        kind=rng.randrange(3)
        if kind==0:return S(term(depth-1))
        x,y=term(depth-1),term(depth-1)
        return Delta(x,y) if kind==1 else R(rng.choice(descriptors),x,y)
    return tuple(term(rng.randrange(2,6)) for _ in range(count))


def baselines(u):
    m,i,j=size(u),occurrences(u,'n'),occurrences(u,'a')
    return {
        'constancy_K':25+5*m+3*i,
        'equality_bit_parenthesized_EB':38 if u==Z else 26+5*m+3*i,
        'equality_bit_unparenthesized_Z_core':33+5*m+3*i,
        'equality_bit_unparenthesized_rooted_core':38+4*m+3*i,
        'equality_test_mask_core':35+4*m+3*i,
        'equality_test_mask_fused':45+4*m+3*i,
        'four_occurrence_F_core':32+4*m+3*i,
        'four_occurrence_F_packaged':47+4*m+3*i,
        'four_occurrence_AO':35+7*m+4*i+3*j-max(j-i,0),
        'zero_anchor_HP2':22+m if j==0 else 35+7*m+4*i,
        'zero_anchor_HP3':20+m if i==0 else (22+m if j==0 else 35+7*m+4*i),
    }


def full_baselines(u):
    W,i,j=size(u,True),occurrences(u,'n'),occurrences(u,'a')
    H=size(descriptor(u),True)
    return {
        # Unpruned-body baselines have their new descriptor size W.
        'constancy_K':25+5*W+3*i+(2+i)*W,
        'equality_bit_parenthesized_EB':40 if u==Z else 26+5*W+3*i+(2+i)*W,
        'equality_bit_unparenthesized_Z_core':33+5*W+3*i+(2+i)*W,
        'equality_bit_unparenthesized_rooted_core':38+4*W+3*i+(2+i)*W,
        'equality_test_mask_core':35+4*W+3*i+(2+i)*W,
        'equality_test_mask_fused':45+4*W+3*i+(2+i)*W,
        'four_occurrence_F_core':32+4*W+3*i+(2+i)*W,
        'four_occurrence_F_packaged':47+4*W+3*i+(2+i)*W,
        'four_occurrence_AO':35+7*W+4*i+3*j-max(j-i,0)+(2+i)*W,
        'zero_anchor_HP2':22+W+3*H if j==0 else 35+7*W+4*i+(2+i)*H,
        'zero_anchor_HP3':(20+W+2*H if i==0 else
             (22+W+3*H if j==0 else 35+7*W+4*i+(2+i)*H)),
    }


def main():
    descriptors=make_descriptors()
    finite=enumerate_terms(5,descriptors)
    randoms=random_terms(600,descriptors)
    named=(Z,n,a,S(Z),S(n),S(a),Q(n,a),Q(S(n),a),Q(S(Z),a),
           Q(n,Q(a,a)), pad(n), pad(Z), R(descriptors[-1],n,a))
    terms=tuple(dict.fromkeys((*finite,*randoms,*named)))
    result={
        'scope':'Syntactic audit only; not a formal proof of arithmetic or interpretation equivalence.',
        'seed':'The literal zero input emits only separation and the off-diagonal mask law; no R_0 equation is emitted there.',
        'baseline_scope':'Principal printed emitters and selected explicitly printed alternatives. Fixed sentences attached to baseline cores are not added to their per-instance cost. This is not a search over arbitrary re-factoring or axiom generators.',
        'enumeration':{'maximum_active_size':5,'descriptor_count':len(descriptors),
                       'enumerated_terms':len(finite),'random_seed':20261102,
                       'random_terms_requested':600,'unique_total_terms':len(terms)},
        'descriptor_trees':[show(h) for h in descriptors],
        'variants':{},
    }
    for full_aware in (False,True):
        variant='full_aware' if full_aware else 'active_aware'
        branches=Counter()
        active_min={key:None for key in baselines(Z)}
        active_nonpositive=Counter()
        full_min={key:None for key in full_baselines(Z)}
        full_losses=Counter()
        examples=[]
        for u in terms:
            f,branch=emit(u,full_aware)
            branches[branch]+=1
            actual,full_actual=size(f),size(f,True)
            assert actual==expected(u,branch), (variant,show(u),'active')
            assert full_actual==expected(u,branch,True),(variant,show(u),'full')
            count,depth=quantifiers(f)
            expected_q=(3,3) if branch in ('constancy','mask_fp') else (2,2)
            assert (count,depth)==expected_q
            for key,cost in baselines(u).items():
                saving=cost-actual
                if active_min[key] is None or saving<active_min[key]['saving']:
                    active_min[key]={'saving':saving,'input':show(u),
                                     'old':cost,'new':actual}
                if saving<=0: active_nonpositive[key]+=1
                if full_aware and key=='constancy_K':
                    assert saving>=0,(variant,show(u),key,'active nondominance')
                else:
                    assert saving>0,(variant,show(u),key,'active dominance')
            for key,cost in full_baselines(u).items():
                saving=cost-full_actual
                if saving<=0: full_losses[key]+=1
                if full_min[key] is None or saving<full_min[key]['saving']:
                    full_min[key]={'saving':saving,'input':show(u),
                                   'old':cost,'new':full_actual}
                if full_aware or key in ('constancy_K','zero_anchor_HP3'):
                    assert saving>0,(variant,show(u),key,'full dominance')
            h=at(u,V('v'),V('w'))
            assert nf(nf(h))==nf(h)
            assert size(nf(h))<=size(h)
            assert size(nf(h),True)<=size(h,True)
            padded=pad(u)
            assert size(padded)==size(u)+12
            assert occurrences(padded,'n')==occurrences(u,'n')+2
            assert occurrences(padded,'a')==occurrences(u,'a')+2
            assert descriptor(padded)==descriptor(u)
            assert emit(padded,full_aware)[1]=='mask_fp'
            if u in named:
                examples.append({'input':show(u),'m':size(u),'W':size(u,True),
                    'i':occurrences(u,'n'),'j':occurrences(u,'a'),
                    'H':size(descriptor(u),True),'branch':branch,
                    'active':actual,'full':full_actual})
        result['variants'][variant]={
            'branch_counts':dict(sorted(branches.items())),
            'active_minimum_savings':active_min,
            'nonpositive_active_comparisons':dict(sorted(active_nonpositive.items())),
            'full_minimum_savings':full_min,
            'nonpositive_full_comparisons':dict(sorted(full_losses.items())),
            'named_examples':examples,
        }
    # A stored descriptor's variables are not active variables.
    frozen=R(Delta(V('v'),V('w')),n,a)
    changed=subst(frozen,{'n':S(n),'a':Z,'v':Z,'w':Z})
    assert changed.descriptor==frozen.descriptor
    # Root-only NF must not traverse arbitrary arguments.
    interior=S(Q(S(n),a))
    assert nf(interior)==interior
    # The root alias used to recover the omitted zero computation.
    recover_zero=Q(S(Z),a)
    assert descriptor(recover_zero)==Z
    assert emit(recover_zero)[1]=='left'
    assert emit(a)[1]=='left'
    result['checks_passed']={
        'exact_formula_counts':2*len(terms)*2,
        'quantifier_profiles':2*len(terms),
        'padding_instances':2*len(terms),
        'descriptor_normalization':2*len(terms),
        'frozen_substitution':True,
        'root_only_normalization':True,
        'zero_recursion_recovery_syntax':True,
    }
    out=Path(__file__).resolve().with_name('results.json')
    out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'passed':True,'unique_terms':len(terms),
                      'enumerated_terms':len(finite),
                      'results_file':str(out),
                      'checks':result['checks_passed']},indent=2))


if __name__=='__main__': main()
