Independent syntax audit for the hybrid PRA emitter
===================================================

Run with Python 3.10 or newer:

    python3 check_emitter.py

No third-party dependencies are needed. The script writes deterministic
results.json alongside itself. It constructs each new emitted formula tree
and counts its actual nodes; it does not evaluate only the new emitter's
displayed closed count formulas. The old baseline costs are the published
closed formulas, not independently reconstructed old formula trees.

Scope
-----

This is a syntax and cost audit. It is not a formal verification of the
arithmetic bootstrap, model theory, bi-interpretations, or padding's semantic
identity. Those mathematical arguments must be supplied separately.

Every variable, zero, function application, equality, connective, quantifier,
and falsity symbol counts as one active node. Negation is expanded as an
implication to falsity, and 1 is expanded as S(0). Recursor applications have
two active arguments. Their descriptors are actual finite immutable trees
in variables v,w and are frozen during active substitution. In the recursive
full measure, every descriptor is charged in full at every occurrence.

The only normalization is repeated root removal

    NF(Q(S(r),s)) = NF(r),       Q = R_w.

It never traverses an ordinary argument or any frozen descriptor. Recursor
indices are normalized on creation. Existing finite descriptor trees can
contain earlier recursors. The enumerator therefore exercises actual frozen
indices, not an uninterpreted placeholder for their size.

Emitter checked
---------------

The literal input 0 emits only the 18-node sentence

    forall a forall n [ (0=S(0) -> false)
                        and (n=a or Delta(n,a)=0) ].

There is no R_0 computation in this special output. The checker verifies
the syntax used to recover it: Q(S(0),a) is not literally zero, has i=0,
has normalized descriptor 0, and receives ordinary left computation.
The Q computation itself is emitted at input a.

Other inputs use these cases, in order:

  i=0                  left computation only
  i>0, j=0             right computation only
  i>0, j>0, size<=10    left computation plus constancy
  i>0, j>0, size>10     left computation plus mask fixed-point induction

Here i and j count active occurrences of n and a. The primary variant uses
active input size m for its size decision. The full-aware variant uses
recursively expanded input size W. If H is the expanded size of NF(u),
the independently verified count formulas are:

  branch       active size                  recursively expanded size
  ----------   ---------------------------  ----------------------------------
  zero seed    18                           18
  left         13+m+2i (i=0 here)           13+W+2i+(2+i)H
  right        15+m                         15+W+3H
  constancy    18+5m+3i                     18+5W+3i+(2+i)H
  mask         28+4m+3i                     28+4W+3i+(2+i)H

The seed, left, and right branches have two quantifiers and depth two.
The two induction branches have three quantifiers and depth three.

Padding checked
---------------

Define D_z(t)=Q(S(t),z). Four alternating shells give

    hat(t) = D_n(D_a(D_n(D_a(t)))).

For every tested t, the script verifies:

  active size increases by 12;
  each active variable count increases by 2;
  the normalized descriptor is unchanged;
  both emitter variants select the mask branch.

The arithmetic equality D_z(t)=t follows from Q's computation law. This
script checks the syntax supporting that proof; it does not replace it.

Baseline coverage and qualifications
-----------------------------------

The current six archives are represented as follows:

  pra_constancy_2026-11-02.zip
    constancy_K

  pra_equality_bit_2026-11-02.zip
    equality_bit_unparenthesized_Z_core
    equality_bit_unparenthesized_rooted_core (printed alternative)

  pra_equality_bit_2026-11-02 (1).zip
    equality_bit_parenthesized_EB

  pra_equality_test_2026-11-02.zip
    equality_test_mask_core
    equality_test_mask_fused (printed alternative)

  pra_four_occurrence_2026-11-02.zip
    four_occurrence_F_core
    four_occurrence_F_packaged
    four_occurrence_AO (separate printed adaptive alternative)

  pra_zero_anchor_projection_2026-11-02.zip
    zero_anchor_HP2
    zero_anchor_HP3 (the printed stronger pruning alternative)

Fixed sentences attached to a baseline's recurring core are NOT added to
that core's per-instance count. Thus the comparisons do not inflate those
baselines by charging their fixed axioms repeatedly. This is a comparison
with specified printed emitters; it is not a search over all possible new
factorings, logical grammars, or programs generating equivalent theories.

The primary active-aware variant is strictly smaller in active size than
each of those baseline profiles on every tested input. It is also strictly
smaller in full size than constancy_K and zero_anchor_HP3. It is NOT claimed
to be strictly smaller in full size than every other baseline. The results
record concrete counterexamples where a small active input carries large
frozen descriptors and the constancy choice has a larger expanded cost.

The full-aware variant is strictly smaller in full size than every listed
printed baseline on every tested input. It is strictly smaller in active
size against the others, but can TIE constancy_K on a three-node input with
both variables and a large descriptor. These ties are recorded rather than
discarded. The report must not turn this nonincrease into strict dominance.

The available term grammars differ among reports. Costs for inputs outside
a baseline's literal language are profile comparisons only. In particular,
the constancy draft admits a logical equality conditional, whereas the new
grammar has a primitive equality mask with its axiom explicitly charged.
The audit does not prove arbitrary cross-language proof-length bounds.

Finite coverage
---------------

The script exhaustively enumerates active terms through size five from
0,n,a, successor, Delta, and nine explicit canonical recursor descriptors,
including nested descriptors. It then adds 600 fixed-seed random requests
and designated examples. The current run has 6,315 exhaustively generated
terms and 6,695 unique terms in total. Both variants are audited, giving
26,780 exact formula-count checks and 13,390 checks each of quantifier
profiles, root normalization, and padding. The finite enumeration is
evidence for the implementation; universal inequalities require the
symbolic arguments in the accompanying report.
