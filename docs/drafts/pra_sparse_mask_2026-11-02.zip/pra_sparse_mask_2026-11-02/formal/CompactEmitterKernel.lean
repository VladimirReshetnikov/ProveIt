import Std

/-!
# A checked local kernel for the compact PRA emitter

The carrier is arbitrary. All arithmetic and schematic premises are explicit
theorem parameters; no `axiom` declarations are introduced.

Theorems here check the semantic padding transfer, recovery of left recursion
from a padded computation equation, derivation of the mask diagonal and native
equality test, and the one-predicate mask-induction argument. Functions and
predicates used in these metatheorems are higher-order parameters. The paper
separately establishes that each required instance is represented by a legal
finite term in its generated first-order signature.

This file does not formalize the syntax generator, its cost formula, triangular
pairing, the primitive-recursive compiler, or the full bi-interpretation.
-/

namespace CompactPRA

universe u
variable {A : Type u}

def pad4 (Q : A → A → A) (S : A → A) (f : A → A → A)
    (n a : A) : A :=
  let t₁ := Q (S (f n a)) a
  let t₂ := Q (S t₁) n
  let t₃ := Q (S t₂) a
  Q (S t₃) n

theorem padding_identity
    (Q : A → A → A) (S : A → A)
    (qSucc : ∀ x y, Q (S x) y = x)
    (f : A → A → A) (n a : A) :
    pad4 Q S f n a = f n a := by
  calc
    pad4 Q S f n a = Q (S (Q (S (Q (S (f n a)) a)) n)) a := qSucc _ _
    _ = Q (S (Q (S (f n a)) a)) n := qSucc _ _
    _ = Q (S (f n a)) a := qSucc _ _
    _ = f n a := qSucc _ _

theorem left_recursion_from_padding
    (Q F : A → A → A) (S h : A → A)
    (qSucc : ∀ x y, Q (S x) y = x)
    (paddedStep : ∀ n a, F (S n) a = Q (S (h (F n a))) n) :
    ∀ n a, F (S n) a = h (F n a) := by
  intro n a
  exact (paddedStep n a).trans (qSucc (h (F n a)) n)

theorem zero_recursion_from_padding
    (zero : A) (Q Rzero : A → A → A) (S : A → A)
    (qSucc : ∀ x y, Q (S x) y = x)
    (paddedBase : ∀ a, Rzero zero a = a)
    (paddedStep : ∀ n a, Rzero (S n) a = Q (S zero) n) :
    (∀ a, Rzero zero a = a) ∧ (∀ n a, Rzero (S n) a = zero) := by
  constructor
  · exact paddedBase
  · intro n a
    exact (paddedStep n a).trans (qSucc zero n)

def MaskAt (M : A → A → A) (f : A → A → A) (n a : A) : Prop :=
  M n (f n a) = n

def MaskProgress (M : A → A → A) (S : A → A)
    (f : A → A → A) (a : A) : Prop :=
  ∀ n, MaskAt M f n a → f (S n) a = S n

def MaskAxiom (M : A → A → A) (S : A → A)
    (f : A → A → A) : Prop :=
  ∀ a, MaskProgress M S f a → ∀ n, MaskAt M f n a

theorem mask_transfer
    (M : A → A → A) (S : A → A) (f g : A → A → A)
    (same : ∀ n a, g n a = f n a)
    (gAxiom : MaskAxiom M S g) : MaskAxiom M S f := by
  intro a fProgress n
  have gProgress : MaskProgress M S g a := by
    intro k gMask
    have fMask : MaskAt M f k a := by
      change M k (f k a) = k
      change M k (g k a) = k at gMask
      rw [same k a] at gMask
      exact gMask
    exact (same (S k) a).trans (fProgress k fMask)
  have h := gAxiom a gProgress n
  change M n (g n a) = n at h
  change M n (f n a) = n
  rw [same n a] at h
  exact h

theorem mask_from_padded_instance
    (Q M : A → A → A) (S : A → A)
    (qSucc : ∀ x y, Q (S x) y = x)
    (f : A → A → A)
    (paddedAxiom : MaskAxiom M S (pad4 Q S f)) :
    MaskAxiom M S f := by
  exact mask_transfer M S f (pad4 Q S f)
    (padding_identity Q S qSucc f) paddedAxiom

theorem mask_diagonal
    (zero : A) (M : A → A → A) (S : A → A)
    (identityAxiom : MaskAxiom M S (fun n _ => n)) :
    ∀ x, M x x = x := by
  intro x
  have progress : MaskProgress M S (fun n _ => n) zero := by
    intro n _
    rfl
  exact identityAxiom zero progress x

theorem diagonal_from_padded_identity
    (zero : A) (Q M : A → A → A) (S : A → A)
    (qSucc : ∀ x y, Q (S x) y = x)
    (paddedAxiom : MaskAxiom M S (pad4 Q S (fun n _ => n))) :
    ∀ x, M x x = x := by
  exact mask_diagonal zero M S
    (mask_from_padded_instance Q M S qSucc (fun n _ => n) paddedAxiom)

theorem mask_zero
    (zero : A) (M : A → A → A)
    (diag : ∀ x, M x x = x)
    (off : ∀ x y, x = y ∨ M x y = zero) :
    ∀ x, M zero x = zero := by
  intro x
  rcases off zero x with eq | masked
  · rw [← eq]
    exact diag zero
  · exact masked

theorem mask_root_iff
    (zero : A) (M : A → A → A)
    (diag : ∀ x, M x x = x)
    (off : ∀ x y, x = y ∨ M x y = zero)
    (n b : A) : M n b = n ↔ n = zero ∨ n = b := by
  constructor
  · intro h
    rcases off n b with eq | masked
    · exact Or.inr eq
    · exact Or.inl (h.symm.trans masked)
  · intro h
    rcases h with atZero | eq
    · subst n
      exact mask_zero zero M diag off b
    · rw [eq]
      exact diag b

theorem successor_injective
    (zero : A) (Q : A → A → A) (S : A → A)
    (qSucc : ∀ x y, Q (S x) y = x) :
    ∀ x y, S x = S y → x = y := by
  intro x y h
  calc
    x = Q (S x) zero := (qSucc x zero).symm
    _ = Q (S y) zero := congrArg (fun t => Q t zero) h
    _ = y := qSucc y zero

theorem successor_ne_zero
    (zero : A) (Q : A → A → A) (S : A → A)
    (qZero : ∀ a, Q zero a = a)
    (qSucc : ∀ x y, Q (S x) y = x)
    (sep : zero ≠ S zero) :
    ∀ x, S x ≠ zero := by
  intro x h
  have hx : x = zero := by
    calc
      x = Q (S x) zero := (qSucc x zero).symm
      _ = Q zero zero := congrArg (fun t => Q t zero) h
      _ = zero := qZero zero
  subst x
  exact sep h.symm

def equalityBit (M Z : A → A → A) (S : A → A)
    (zero : A) (x y : A) : A :=
  Z (M (S x) (S y)) (S zero)

theorem equality_bit_spec
    (zero : A) (M Z : A → A → A) (S : A → A)
    (diag : ∀ x, M x x = x)
    (off : ∀ x y, x = y ∨ M x y = zero)
    (sInjective : ∀ x y, S x = S y → x = y)
    (sNonzero : ∀ x, S x ≠ zero)
    (zZero : ∀ a, Z zero a = a)
    (zSucc : ∀ n a, Z (S n) a = zero)
    (x y : A) :
    (x = y ∧ equalityBit M Z S zero x y = zero) ∨
    (x ≠ y ∧ equalityBit M Z S zero x y = S zero) := by
  rcases off (S x) (S y) with equal | masked
  · have xy := sInjective x y equal
    left
    constructor
    · exact xy
    · subst y
      change Z (M (S x) (S x)) (S zero) = zero
      rw [diag, zSucc]
  · right
    constructor
    · intro xy
      subst y
      rw [diag] at masked
      exact sNonzero x masked
    · change Z (M (S x) (S y)) (S zero) = S zero
      rw [masked, zZero]

def encode (C : A → A → A → A) (zero : A) (b : A → A)
    (n : A) : A := C (b n) n zero

theorem encoded_mask_iff
    (zero one : A) (M : A → A → A) (C : A → A → A → A)
    (diag : ∀ x, M x x = x)
    (off : ∀ x y, x = y ∨ M x y = zero)
    (cZero : ∀ x y, C zero x y = x)
    (cOne : ∀ x y, C one x y = y)
    (P : A → Prop) (b : A → A)
    (bit : ∀ n, b n = zero ∨ b n = one)
    (truth : ∀ n, b n = zero ↔ P n)
    (n : A) :
    M n (encode C zero b n) = n ↔ n = zero ∨ P n := by
  constructor
  · intro h
    rcases (mask_root_iff zero M diag off n (encode C zero b n)).mp h
      with atZero | same
    · exact Or.inl atZero
    · rcases bit n with trueBit | falseBit
      · exact Or.inr ((truth n).mp trueBit)
      · have outputZero : encode C zero b n = zero := by
          change C (b n) n zero = zero
          rw [falseBit, cOne]
        exact Or.inl (same.trans outputZero)
  · intro h
    apply (mask_root_iff zero M diag off n (encode C zero b n)).mpr
    rcases h with atZero | holds
    · exact Or.inl atZero
    · right
      change n = C (b n) n zero
      rw [(truth n).mpr holds, cZero]

theorem encoded_value_of_truth
    (zero : A) (C : A → A → A → A)
    (cZero : ∀ x y, C zero x y = x)
    (P : A → Prop) (b : A → A)
    (truth : ∀ n, b n = zero ↔ P n) :
    ∀ n, P n → encode C zero b n = n := by
  intro n h
  change C (b n) n zero = n
  rw [(truth n).mpr h, cZero]

theorem mask_to_induction
    (zero : A) (M : A → A → A) (S : A → A)
    (P : A → Prop) (f : A → A)
    (maskInstance :
      (∀ n, M n (f n) = n → f (S n) = S n) →
        ∀ n, M n (f n) = n)
    (encoding : ∀ n, M n (f n) = n ↔ n = zero ∨ P n)
    (trueValue : ∀ n, P n → f n = n)
    (base : P zero)
    (step : ∀ n, P n → P (S n)) :
    ∀ n, P n := by
  have progress : ∀ n, M n (f n) = n → f (S n) = S n := by
    intro n h
    have pn : P n := by
      rcases (encoding n).mp h with atZero | holds
      · rw [atZero]
        exact base
      · exact holds
    exact trueValue (S n) (step n pn)
  have allMasks := maskInstance progress
  intro n
  rcases (encoding n).mp (allMasks n) with atZero | holds
  · rw [atZero]
    exact base
  · exact holds

theorem boolean_mask_to_induction
    (zero one : A) (M : A → A → A) (S : A → A)
    (C : A → A → A → A)
    (diag : ∀ x, M x x = x)
    (off : ∀ x y, x = y ∨ M x y = zero)
    (cZero : ∀ x y, C zero x y = x)
    (cOne : ∀ x y, C one x y = y)
    (P : A → Prop) (b : A → A)
    (bit : ∀ n, b n = zero ∨ b n = one)
    (truth : ∀ n, b n = zero ↔ P n)
    (maskInstance :
      (∀ n, M n (encode C zero b n) = n →
        encode C zero b (S n) = S n) →
        ∀ n, M n (encode C zero b n) = n)
    (base : P zero)
    (step : ∀ n, P n → P (S n)) :
    ∀ n, P n := by
  exact mask_to_induction zero M S P (encode C zero b) maskInstance
    (encoded_mask_iff zero one M C diag off cZero cOne P b bit truth)
    (encoded_value_of_truth zero C cZero P b truth) base step

-- These commands record the actual trusted axiom dependencies of the local
-- algebraic/logic kernel, separately from its explicit theorem hypotheses.
#print axioms padding_identity
#print axioms left_recursion_from_padding
#print axioms zero_recursion_from_padding
#print axioms mask_from_padded_instance
#print axioms diagonal_from_padded_identity
#print axioms mask_root_iff
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms equality_bit_spec
#print axioms encoded_mask_iff
#print axioms mask_to_induction
#print axioms boolean_mask_to_induction

end CompactPRA
