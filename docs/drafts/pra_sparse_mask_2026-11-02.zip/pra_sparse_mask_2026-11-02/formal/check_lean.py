#!/usr/bin/env python3
"""Recheck the local Lean kernel and record exact version and source hash."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lean", default=shutil.which("lean"))
    args = parser.parse_args()
    if not args.lean:
        parser.error("Lean is not on PATH; supply --lean /absolute/path/to/lean")
    root = Path(__file__).resolve().parent
    source = root / "CompactEmitterKernel.lean"
    version = subprocess.run([args.lean, "--version"], text=True,
                             capture_output=True, check=True)
    check = subprocess.run([args.lean, str(source)], text=True,
                           capture_output=True)
    output = check.stdout + check.stderr
    (root / "lean-check.log").write_text(version.stdout + output)
    verified = check.returncode == 0 and "sorryAx" not in output
    report = {
        "verified": verified,
        "lean_version": version.stdout.strip(),
        "exit_code": check.returncode,
        "source": source.name,
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "dependency_checks": [line for line in output.splitlines()
                              if "does not depend on any axioms" in line
                              or "depends on axioms" in line],
        "scope": "Local metatheorems only; see SCOPE.txt.",
    }
    (root / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if not verified:
        print(output, file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
