#!/usr/bin/env python3
"""Reproduce the syntax audit and build the included LaTeX report."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile


def run(command, root, log):
    result = subprocess.run(command, cwd=root, text=True, capture_output=True)
    log.write_text(result.stdout + result.stderr)
    if result.returncode:
        print((result.stdout + result.stderr)[-12000:], file=sys.stderr)
        raise SystemExit(result.returncode)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skip-checks", action="store_true")
    parser.add_argument("--lean", help="Optional path to a Lean 4.19.0 executable")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    verification = root / "verification"
    verification.mkdir(exist_ok=True)
    if not args.skip_checks:
        run([sys.executable, "checks/check_emitter.py"], root,
            verification / "emitter_check.log")
        shutil.copyfile(root / "checks/results.json",
                        verification / "emitter_results.json")
        (root / "checks/results.json").unlink()
    if args.lean:
        run([sys.executable, "formal/check_lean.py", "--lean", args.lean],
            root, verification / "lean_recheck.log")
    latex = shutil.which("pdflatex")
    if not latex:
        raise SystemExit("pdflatex is required; install a TeX Live distribution.")
    # A clean isolated build avoids stale auxiliary files from interrupted runs.
    with tempfile.TemporaryDirectory(prefix="pra_sparse_tex_") as directory:
        build_dir = Path(directory)
        shutil.copyfile(root / "report.tex", build_dir / "report.tex")
        shutil.copytree(root / "sections", build_dir / "sections")
        for number in range(1, 4):
            run([latex, "-interaction=nonstopmode", "-halt-on-error",
                 "-file-line-error", "report.tex"], build_dir,
                verification / f"latex_pass_{number}.log")
        final_log = (build_dir / "report.log").read_text(errors="replace")
        pdf_bytes = (build_dir / "report.pdf").read_bytes()
    if not pdf_bytes.startswith(b"%PDF-") or not pdf_bytes.rstrip().endswith(b"%%EOF"):
        raise SystemExit("The compiled PDF is incomplete; it was not published.")
    temporary_pdf = root / "report.pdf.complete"
    with temporary_pdf.open("wb") as stream:
        stream.write(pdf_bytes)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary_pdf, root / "report.pdf")
    report = {
        "latex_engine": subprocess.run([latex, "--version"],
                      capture_output=True, text=True).stdout.splitlines()[0],
        "pdf_bytes": (root / "report.pdf").stat().st_size,
        "pdf_sha256": hashlib.sha256((root / "report.pdf").read_bytes()).hexdigest(),
        "overfull_boxes": re.findall(r"Overfull[^\n]*", final_log),
        "undefined_references": bool(re.search(r"(?:Reference|Citation).*undefined|There were undefined", final_log)),
        "formal_check_scope": "Only the explicit kernel described in formal/SCOPE.txt.",
    }
    (verification / "build_results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if report["overfull_boxes"] or report["undefined_references"]:
        raise SystemExit("Build completed, but layout/reference warnings require review.")


if __name__ == "__main__":
    main()
