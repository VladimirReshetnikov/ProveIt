PRA WITH UNARY UPDATES AND ONE FIXED COUNTER PROJECTION
Research date: 1 November 2026 (America/Los_Angeles)
Comparison snapshot: ab29d2ad2189948d995d6cffa7cea5298cd126a0

MAIN RESULT
For both matching ambient logics, classical and intuitionistic, PRA is
bi-interpretable with a theory whose recursion language has only:
  K(0,a)=a, K(Sn,a)=n (one fixed counter-reading description), and
  I_h(0,a)=a, I_h(Sn,a)=h(I_h(n,a)) for earlier unary terms h(v).
One-parameter quantifier-free induction suffices. The original normalized
single-schema display and its two admission rewrites can be retained.
An optional named-predecessor variant has a 25-node outer display with
four admission rules. This count is not a complete specification length.

The full mathematical proof uses a new diagonal tail-splitting lemma
and a simpler pairing decoder to stay within the single induction
parameter until tuple coding is available. Both interpretations preserve
the whole carrier and native equality, and both round trips are the identity.

FILES
  report.pdf                   Complete report and proofs.
  report.tex                   Main LaTeX source.
  pairing_proof.tex             Included pairing and arithmetic proof.
  source_manifest.json          Immutable sources, Git blobs, SHA-256 hashes.
  verification/PairingKernel.lean
                               Abstract-carrier partial Lean certificate.
  verification/PairingKernel-verification.txt
                               Version, source hash, output and proof boundary.
  verification/check_pure_basis.py
                               Actual finite-term grammar and iterator checks.
  verification/pure_basis_audit.json
                               Recorded numerical and eight-source byte checks.
  verification/pure_basis_syntax.json
                               Exported finite term DAG and description bodies.
  verification/check_schemata.py
                               Literal admission probes and template counts.
  verification/schema_checks.json
                               Recorded schema-check output.
  verification/RESULTS.txt       Consolidated verification and limitations.
  verification/induction_ledger.csv
                               All induction matrices before tuple coding.
  SHA256SUMS                    Hashes of the deliverable files.

BUILD AND CHECK
From this directory, with a normal TeX Live installation:
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

With Python 3.10 or later (standard library only):
  python3 verification/check_pure_basis.py --output /tmp/pure_basis_audit.json
  python3 verification/check_schemata.py

With Lean 4.19.0:
  lean verification/PairingKernel.lean

To repeat source-byte checks, download the eight archives named in
source_manifest.json from their immutable download_url values into one
directory, then run:
  python3 verification/check_pure_basis.py --output /tmp/source_recheck.json \
    --source-manifest source_manifest.json --archives-dir /path/to/archives

VERIFICATION BOUNDARY
The mathematical report proves the full theorem. Finite numerical tests
are diagnostics only. The Lean file checks first-step interchange,
diagonal tail splitting, exact stripping, and decoder identities with
explicit arithmetic and exact induction-instance hypotheses. It does
not formalize the whole first-order calculus, the entire arithmetic
bootstrap, the normalization kernel, or the final compiler/round trips.
It uses no unrestricted semantic induction principle over arbitrary
Lean predicates, no sorry, and no classical choice.

NOVELTY AND LIMITS
The comparison uses all eight current archives at the stated commit.
The closest prior pure-iteration bridge has unrestricted parameter
induction. The new result is the combination of the smaller recursion
grammar with only one frozen induction parameter and the resulting
two-variable axiom interface. No encoding-independent minimum is claimed.
Eliminating the fixed predecessor source remains an open question here.

The report includes a Further research questions section.
