import Init

/-!
# A constructive kernel for the one-mixed-description pairing

This file checks the first-step interchange, diagonal tail splitting,
exact stripping, and the final two decoder identities over an arbitrary
carrier. It deliberately does NOT assume an induction principle for all
Lean predicates. Each induction hypothesis below names one specific
two-variable matrix: the induction variable and one frozen carrier
parameter are its only carrier inputs.

The operations and the unary update `f` are fixed interpretations of
language symbols / fixed finite term descriptions. They are not extra
number parameters in the object-theory induction instances.

The arithmetic, parity, power-bound, and odd-tail lemmas in `retraction`
are explicit assumptions. Their quantifier-free, one-parameter written
proofs are in the accompanying report. No natural-number interpretation,
standard-model evaluation, classical choice, or unrestricted induction is
used in this kernel. The description grammar, normalization equivalence,
full primitive-recursion compiler, and interpretation round trips are
outside this certificate.
-/

set_option autoImplicit false

universe u

namespace PRAOneMixed

variable {A : Type u}

/-- The precise first-step matrix: `n` varies and `a` is frozen. -/
def FirstMatrix (I : A → A → A) (f S : A → A) (n a : A) : Prop :=
  I (S n) a = I n (f a)

/-- The precise diagonal-tail matrix: `x` varies and `n` is frozen. -/
def TailMatrix (I sub : A → A → A) (zero x n : A) : Prop :=
  sub x n = zero → I n n = I (sub n x) (I x n)

/-- The precise stripping matrix: `x` varies and `a` is frozen. -/
def StripMatrix (I E : A → A → A) (x a : A) : Prop :=
  I x (E x a) = a

theorem firstStep
    (zero : A) (S f : A → A) (I : A → A → A)
    (iZero : ∀ a, I zero a = a)
    (iSucc : ∀ n a, I (S n) a = f (I n a))
    (indFirst : ∀ a,
      FirstMatrix I f S zero a →
      (∀ n, FirstMatrix I f S n a → FirstMatrix I f S (S n) a) →
      ∀ n, FirstMatrix I f S n a) :
    ∀ n a, I (S n) a = I n (f a) := by
  intro n a
  apply indFirst a ?_ ?_ n
  · change I (S zero) a = I zero (f a)
    calc
      I (S zero) a = f (I zero a) := iSucc zero a
      _ = f a := congrArg f (iZero a)
      _ = I zero (f a) := (iZero (f a)).symm
  · intro k ih
    change I (S k) a = I k (f a) at ih
    change I (S (S k)) a = I (S k) (f a)
    calc
      I (S (S k)) a = f (I (S k) a) := iSucc (S k) a
      _ = f (I k (f a)) := congrArg f ih
      _ = I (S k) (f a) := (iSucc k (f a)).symm

theorem diagonalTail
    (zero : A) (S f : A → A) (I sub : A → A → A)
    (iZero : ∀ a, I zero a = a)
    (iSucc : ∀ n a, I (S n) a = f (I n a))
    (subZeroRight : ∀ a, sub a zero = a)
    (orderDown : ∀ x n, sub (S x) n = zero → sub x n = zero)
    (tailDecrement : ∀ x n,
      sub (S x) n = zero → sub n x = S (sub n (S x)))
    (first : ∀ n a, I (S n) a = I n (f a))
    (indTail : ∀ n,
      TailMatrix I sub zero zero n →
      (∀ x, TailMatrix I sub zero x n → TailMatrix I sub zero (S x) n) →
      ∀ x, TailMatrix I sub zero x n) :
    ∀ x n, sub x n = zero → I n n = I (sub n x) (I x n) := by
  intro x n
  apply indTail n ?_ ?_ x
  · intro _
    rw [subZeroRight n, iZero n]
  · intro k ih hNext
    have hPrev : sub k n = zero := orderDown k n hNext
    have hCut : sub n k = S (sub n (S k)) := tailDecrement k n hNext
    calc
      I n n = I (sub n k) (I k n) := ih hPrev
      _ = I (S (sub n (S k))) (I k n) :=
        congrArg (fun t => I t (I k n)) hCut
      _ = I (sub n (S k)) (f (I k n)) :=
        first (sub n (S k)) (I k n)
      _ = I (sub n (S k)) (I (S k) n) :=
        congrArg (I (sub n (S k))) (iSucc k n).symm

theorem exactStripping
    (zero : A) (S f D : A → A) (I E : A → A → A)
    (iZero : ∀ a, I zero a = a)
    (eZero : ∀ a, E zero a = a)
    (eSucc : ∀ x a, E (S x) a = D (E x a))
    (halveDouble : ∀ a, f (D a) = a)
    (first : ∀ n a, I (S n) a = I n (f a))
    (indStrip : ∀ a,
      StripMatrix I E zero a →
      (∀ x, StripMatrix I E x a → StripMatrix I E (S x) a) →
      ∀ x, StripMatrix I E x a) :
    ∀ x a, I x (E x a) = a := by
  intro x a
  apply indStrip a ?_ ?_ x
  · change I zero (E zero a) = a
    rw [eZero a, iZero a]
  · intro k ih
    change I k (E k a) = a at ih
    change I (S k) (E (S k) a) = a
    calc
      I (S k) (E (S k) a) = I (S k) (D (E k a)) :=
        congrArg (I (S k)) (eSucc k a)
      _ = I k (f (D (E k a))) := first k (D (E k a))
      _ = I k (E k a) := congrArg (I k) (halveDouble (E k a))
      _ = a := ih

def pair (S D : A → A) (E : A → A → A) (x y : A) : A :=
  E x (S (D y))

def leftDecoder (H : A → A) (sub Iu Iw : A → A → A) (z : A) : A :=
  sub z (H (sub (Iw z z) (Iu z z)))

def rightDecoder (H : A → A) (Iu : A → A → A) (z : A) : A :=
  H (Iu z z)

/-
The hypotheses below are exactly the already-proved binary / unary
lemmas used by the written decoder calculation. In particular, there
is NO associativity hypothesis and NO general semigroup law.
-/
theorem retraction
    (zero : A) (S D H r : A → A)
    (add sub E Iu Iw : A → A → A)
    (succNeZero : ∀ a, S a ≠ zero)
    (powerBound : ∀ x a, a ≠ zero → sub x (E x a) = zero)
    (gap : ∀ x n, sub x n = zero → n = add x (sub n x))
    (addComm : ∀ a b, add a b = add b a)
    (subCancel : ∀ a b, sub (add a b) a = b)
    (halfDouble : ∀ a, H (D a) = a)
    (halfOdd : ∀ a, H (S (D a)) = a)
    (parityOdd : ∀ a, r (S (D a)) = S zero)
    (tailU : ∀ x n, sub x n = zero → Iu n n = Iu (sub n x) (Iu x n))
    (tailW : ∀ x n, sub x n = zero → Iw n n = Iw (sub n x) (Iw x n))
    (stripU : ∀ x a, Iu x (E x a) = a)
    (stripW : ∀ x a, Iw x (E x a) = a)
    (oddU : ∀ k a, r a = S zero → Iu k a = a)
    (oddW : ∀ k a, r a = S zero → Iw k a = add a (D k)) :
    ∀ x y,
      leftDecoder H sub Iu Iw (pair S D E x y) = x ∧
      rightDecoder H Iu (pair S D E x y) = y := by
  intro x y
  let a := S (D y)
  let n := E x a
  let k := sub n x
  have hBound : sub x n = zero := powerBound x a (succNeZero (D y))
  have hOdd : r a = S zero := parityOdd y
  have hU : Iu n n = a := by
    calc
      Iu n n = Iu k (Iu x n) := tailU x n hBound
      _ = Iu k a := congrArg (Iu k) (stripU x a)
      _ = a := oddU k a hOdd
  have hW : Iw n n = add a (D k) := by
    calc
      Iw n n = Iw k (Iw x n) := tailW x n hBound
      _ = Iw k a := congrArg (Iw k) (stripW x a)
      _ = add a (D k) := oddW k a hOdd
  have hDifference : sub (Iw n n) (Iu n n) = D k := by
    rw [hW, hU, subCancel a (D k)]
  have hGap : n = add k x := by
    calc
      n = add x k := gap x n hBound
      _ = add k x := addComm x k
  constructor
  · change sub n (H (sub (Iw n n) (Iu n n))) = x
    rw [hDifference, halfDouble k]
    calc
      sub n k = sub (add k x) k := congrArg (fun t => sub t k) hGap
      _ = x := subCancel k x
  · change H (Iu n n) = y
    rw [hU]
    exact halfOdd y

#print axioms firstStep
#print axioms diagonalTail
#print axioms exactStripping
#print axioms retraction

end PRAOneMixed
