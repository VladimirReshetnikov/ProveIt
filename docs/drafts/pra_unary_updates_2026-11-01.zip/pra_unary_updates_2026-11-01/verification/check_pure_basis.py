#!/usr/bin/env python3
"""Finite diagnostics for PRA with one counter-reading description.

The model evaluator executes the displayed finite term DAG and implements EVERY
recursor by literal iteration of its stored update.  It contains no arithmetic
shortcut for predecessor, addition, subtraction, halving, parity, valuation, or
power.  Expected values in the diagnostic assertions may use Python arithmetic.

These finite tests do not prove the axiomatization or its bi-interpretability.
Those are arbitrary-model theorems proved in the accompanying mathematical text.

Usage:
  python3 check_pure_basis.py --output pure_basis_audit.json
  python3 check_pure_basis.py --output pure_basis_audit.json \
      --source-manifest source_manifest.json --archives-dir sources/archives

Python standard library only.  Input archives are read, never executed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time
from dataclasses import dataclass
from functools import lru_cache


@dataclass(frozen=True)
class Description:
    name: str
    body: int


class Syntax:
    """Hash-consed finite terms; description references are external indices."""

    def __init__(self) -> None:
        self.nodes: list[tuple[str, str | int | None, tuple[int, ...]]] = []
        self.interned: dict[tuple, int] = {}
        self.descriptions: list[Description] = []

    def node(self, tag: str, payload=None, children: tuple[int, ...] = ()) -> int:
        key = (tag, payload, children)
        if key not in self.interned:
            self.interned[key] = len(self.nodes)
            self.nodes.append(key)
        return self.interned[key]

    def var(self, name: str) -> int:
        return self.node("var", name)

    def zero(self) -> int:
        return self.node("zero")

    def succ(self, t: int) -> int:
        return self.node("succ", children=(t,))

    def call(self, description: int, n: int, a: int) -> int:
        if not 0 <= description < len(self.descriptions):
            raise ValueError("unknown or forward description reference")
        return self.node("call", description, (n, a))

    @lru_cache(maxsize=None)
    def free(self, t: int) -> frozenset[str]:
        tag, payload, children = self.nodes[t]
        if tag == "var":
            return frozenset((str(payload),))
        return frozenset().union(*(self.free(c) for c in children))

    @lru_cache(maxsize=None)
    def references(self, t: int) -> frozenset[int]:
        tag, payload, children = self.nodes[t]
        own = frozenset((int(payload),)) if tag == "call" else frozenset()
        return own.union(*(self.references(c) for c in children))

    def validate_body(self, name: str, body: int, position: int) -> None:
        if name == "K":
            if position != 0 or self.nodes[body] != ("var", "u", ()):
                raise ValueError("K must be first and have the literal update u")
        elif not self.free(body).issubset({"v"}):
            raise ValueError("every description other than K must have unary update")
        if any(i >= position or i < 0 for i in self.references(body)):
            raise ValueError("description dependency is not earlier")

    def define(self, name: str, body: int) -> int:
        if any(d.name == name for d in self.descriptions):
            raise ValueError("duplicate description name")
        i = len(self.descriptions)
        self.validate_body(name, body, i)
        self.descriptions.append(Description(name, body))
        return i

    def validate(self) -> dict:
        arities = {"var": 0, "zero": 0, "succ": 1, "call": 2}
        for i, (tag, payload, children) in enumerate(self.nodes):
            if tag not in arities or len(children) != arities[tag]:
                raise AssertionError("malformed term arity")
            if any(c < 0 or c >= i for c in children):
                raise AssertionError("term children must be earlier DAG nodes")
            if tag == "call" and not 0 <= int(payload) < len(self.descriptions):
                raise AssertionError("invalid description reference")
        rows = []
        for i, desc in enumerate(self.descriptions):
            self.validate_body(desc.name, desc.body, i)
            rows.append({
                "index": i,
                "name": desc.name,
                "body_node": desc.body,
                "free_variables": sorted(self.free(desc.body)),
                "dependencies": [self.descriptions[j].name
                                 for j in sorted(self.references(desc.body))],
                "kind": "sole counter-reading update u" if i == 0 else "unary update",
            })
        mixed = [r["name"] for r in rows if "u" in r["free_variables"]]
        assert mixed == ["K"]
        return {"term_dag_nodes": len(self.nodes),
                "description_count": len(rows), "counter_reading_descriptions": mixed,
                "all_function_arities_at_most_two": True,
                "all_dependencies_strictly_earlier": True, "descriptions": rows}

    def export(self) -> dict:
        return {"nodes": [{"tag": t, "payload": p, "children": list(c)}
                          for t, p, c in self.nodes],
                "descriptions": [{"name": d.name, "body": d.body}
                                 for d in self.descriptions]}


class Model:
    """Literal natural-number evaluation, with memoized iterator prefixes."""

    def __init__(self, syntax: Syntax) -> None:
        self.syntax = syntax
        self.prefixes: dict[tuple[int, int], list[int]] = {}
        self.unary_updates: dict[tuple[int, int], int] = {}
        self.term_evaluations = 0
        self.iterator_steps = 0
        self.update_cache_hits = 0

    def value(self, t: int, env: dict[str, int]) -> int:
        self.term_evaluations += 1
        tag, payload, children = self.syntax.nodes[t]
        if tag == "var":
            return env[str(payload)]
        if tag == "zero":
            return 0
        if tag == "succ":
            return self.value(children[0], env) + 1
        if tag == "call":
            n = self.value(children[0], env)
            a = self.value(children[1], env)
            return self.iterate(int(payload), n, a)
        raise ValueError(tag)

    def iterate(self, desc: int, n: int, a: int) -> int:
        if n < 0 or a < 0:
            raise ValueError("the diagnostic model is the natural numbers")
        values = self.prefixes.setdefault((desc, a), [a])
        body = self.syntax.descriptions[desc].body
        while len(values) <= n:
            counter = len(values) - 1
            old = values[-1]
            if desc == 0:
                new = self.value(body, {"u": counter, "v": old})
            else:
                key = (desc, old)
                if key in self.unary_updates:
                    self.update_cache_hits += 1
                    new = self.unary_updates[key]
                else:
                    new = self.value(body, {"v": old})
                    self.unary_updates[key] = new
            values.append(new)
            self.iterator_steps += 1
        return values[n]


def build_basis() -> tuple[Syntax, dict[str, int], dict[str, int]]:
    s = Syntax()
    zero = s.zero()
    one = s.succ(zero)
    u, v = s.var("u"), s.var("v")
    n, a, x, y, z = (s.var(k) for k in ("n", "a", "x", "y", "z"))
    K = s.define("K", u)
    p = lambda t: s.call(K, t, zero)
    Z_id = s.define("Z", zero)
    Z = lambda t, b: s.call(Z_id, t, b)
    add_id = s.define("Add", s.succ(v))
    add = lambda t, b: s.call(add_id, b, t)
    sub_id = s.define("Sub", p(v))
    sub = lambda t, b: s.call(sub_id, b, t)
    C = lambda t, b, c: add(Z(t, b), Z(Z(t, one), c))

    cycle_id = s.define("Cycle3", C(p(v), s.succ(v), zero))
    m = lambda t: s.call(cycle_id, t, zero)
    bit = lambda t: Z(p(t), t)
    grow_id = s.define("Grow", add(s.succ(v), bit(m(v))))
    G = lambda t: s.call(grow_id, t, zero)
    parity = lambda t: m(G(t))
    half = lambda t: sub(G(t), t)
    double = lambda t: add(t, t)
    double_id = s.define("Double", double(v))
    E = lambda t, b: s.call(double_id, t, b)

    strip_id = s.define("Strip", C(parity(v), half(v), v))
    advance_id = s.define("StripAdvance", C(parity(v), half(v), s.succ(s.succ(v))))
    U = lambda t: s.call(strip_id, t, t)
    W = lambda t: s.call(advance_id, t, t)
    J = lambda t, b: E(t, s.succ(double(b)))
    L = lambda t: sub(t, half(sub(W(t), U(t))))
    R = lambda t: half(U(t))

    terms = {
        "p": p(n), "Z": Z(n, a), "add": add(x, y), "d": sub(x, y),
        "C": C(z, x, y), "c": C(p(n), s.succ(n), zero),
        "m": m(n), "b": bit(n), "g": add(s.succ(n), bit(m(n))),
        "G": G(n), "r": parity(n), "H": half(n), "D": double(n),
        "E": E(n, a), "u": C(parity(n), half(n), n),
        "w": C(parity(n), half(n), s.succ(s.succ(n))),
        "U": U(n), "W": W(n), "J": J(x, y), "L": L(n), "R": R(n),
    }
    descriptions = {d.name: i for i, d in enumerate(s.descriptions)}
    return s, terms, descriptions


def verify_sources(manifest_path: Path, archives_dir: Path) -> dict:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    rows = []
    for item in manifest["drafts"]:
        path = archives_dir / item["name"]
        data = path.read_bytes()
        actual_git = hashlib.sha1(b"blob " + str(len(data)).encode("ascii")
                                  + b"\0" + data).hexdigest()
        assert actual_git == item["sha"], (item["name"], "Git blob hash mismatch")
        assert len(data) == item["size"], (item["name"], "byte size mismatch")
        rows.append({"name": item["name"], "bytes": len(data),
                     "git_blob_sha1": actual_git,
                     "sha256": hashlib.sha256(data).hexdigest(),
                     "verified": True})
    return {"status": "passed", "snapshot": manifest["head"],
            "archive_count": len(rows), "archives": rows}


def run_diagnostics(s: Syntax, terms: dict[str, int], ids: dict[str, int]) -> dict:
    model = Model(s)
    counts: dict[str, int] = {}

    def check(group: str, condition: bool) -> None:
        assert condition, group
        counts[group] = counts.get(group, 0) + 1

    def V(name: str, **env: int) -> int:
        return model.value(terms[name], env)

    for n in range(24):
        check("predecessor", V("p", n=n + 1) == n)
        check("modulo_three", V("m", n=n) == n % 3)
        check("halving", V("H", n=n) == n // 2)
        check("parity", V("r", n=n) == n % 2)
        check("double", V("D", n=n) == 2 * n)
        check("two_step_half", V("H", n=n + 2) == V("H", n=n) + 1)
        check("two_step_parity", V("r", n=n + 2) == V("r", n=n))
    check("predecessor", V("p", n=0) == 0)

    for x in range(8):
        for y in range(8):
            check("addition", V("add", x=x, y=y) == x + y)
            check("subtraction", V("d", x=x, y=y) == max(x - y, 0))
            check("selector", V("C", z=0, x=x, y=y) == x)
            check("selector", V("C", z=3, x=x, y=y) == y)
            if x <= y:
                gap = V("d", x=y, y=x)
                check("gap_identity", y == V("add", x=x, y=gap))
            if y > 0 and x <= y:
                check("double_bound", V("d", x=x + 1, y=V("D", n=y)) == 0)

    pairs = []
    for x in range(4):
        for y in range(4):
            code = V("J", x=x, y=y)
            left, right = V("L", n=code), V("R", n=code)
            check("pairing_left", left == x)
            check("pairing_right", right == y)
            check("pairing_code", code == (2 ** x) * (2 * y + 1))
            k = V("d", x=code, y=x)
            check("strip_tail", V("U", n=code) == 2 * y + 1)
            check("advance_tail", V("W", n=code) == 2 * y + 1 + 2 * k)
            pairs.append({"x": x, "y": y, "code": code,
                          "left": left, "right": right})

    for name in ("Cycle3", "Grow", "Strip", "StripAdvance"):
        f = ids[name]
        for n in range(9):
            for x in range(n + 1):
                k = V("d", x=n, y=x)
                lhs = model.iterate(f, n, n)
                rhs = model.iterate(f, k, model.iterate(f, x, n))
                check("diagonal_tail_split", lhs == rhs)
        for n in range(9):
            for a in range(5):
                lhs = model.iterate(f, n + 1, a)
                first = model.iterate(f, 1, a)
                rhs = model.iterate(f, n, first)
                check("first_step_commutation", lhs == rhs)

    rejected = 0
    for forbidden in (s.var("u"), s.succ(s.var("u")),
                      s.call(ids["Add"], s.var("u"), s.var("v"))):
        try:
            s.validate_body("ForbiddenMixed", forbidden, len(s.descriptions))
        except ValueError:
            rejected += 1
        else:
            raise AssertionError("an unlicensed counter-dependent update was accepted")
    check("grammar_negative_cases", rejected == 3)

    return {
        "status": "passed", "assertions_by_group": counts,
        "total_assertions": sum(counts.values()),
        "ranges": {"halving_and_parity": "0 <= n < 24",
                   "arithmetic": "0 <= x,y < 8",
                   "pairing": "0 <= x,y < 4",
                   "tail_split": "0 <= x <= n < 9, four updates",
                   "first_step": "0 <= n < 9, 0 <= a < 5, four updates"},
        "sample_pairs": pairs,
        "evaluator": {
            "implementation": "literal term-DAG evaluation and iteration of stored bodies",
            "arithmetic_shortcuts_used": False,
            "term_evaluations": model.term_evaluations,
            "actual_iterator_steps": model.iterator_steps,
            "memoized_prefixes": len(model.prefixes),
            "memoized_prefix_values": sum(map(len, model.prefixes.values())),
            "unary_update_cache_entries": len(model.unary_updates),
            "unary_update_cache_hits": model.update_cache_hits,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("pure_basis_audit.json"))
    parser.add_argument("--source-manifest", type=Path)
    parser.add_argument("--archives-dir", type=Path)
    parser.add_argument("--export-syntax", type=Path)
    args = parser.parse_args()
    if bool(args.source_manifest) != bool(args.archives_dir):
        parser.error("--source-manifest and --archives-dir must be used together")
    started = time.perf_counter()
    s, terms, ids = build_basis()
    result = {
        "scope": "Finite syntax, numerical and source-integrity diagnostics; not a proof of the model-theoretic theorem.",
        "syntax": s.validate(),
        "numeric": run_diagnostics(s, terms, ids),
    }
    # Check again because the negative grammar diagnostics construct extra terms.
    result["syntax"] = s.validate()
    result["helpers"] = {name: {"node": node, "free_variables": sorted(s.free(node))}
                         for name, node in terms.items()}
    if args.source_manifest:
        result["sources"] = verify_sources(args.source_manifest, args.archives_dir)
    else:
        result["sources"] = {"status": "not requested",
                             "instruction": "Supply --source-manifest and --archives-dir to repeat byte verification."}
    result["elapsed_seconds"] = round(time.perf_counter() - started, 6)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    if args.export_syntax:
        args.export_syntax.write_text(json.dumps({**s.export(), "helpers": terms}, indent=2)
                                      + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed",
                      "numeric_assertions": result["numeric"]["total_assertions"],
                      "descriptions": result["syntax"]["description_count"],
                      "counter_reading_descriptions": result["syntax"]["counter_reading_descriptions"],
                      "verified_archives": result["sources"].get("archive_count", 0),
                      "iterator_steps": result["numeric"]["evaluator"]["actual_iterator_steps"],
                      "elapsed_seconds": result["elapsed_seconds"],
                      "audit": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
