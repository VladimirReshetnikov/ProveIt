#!/usr/bin/env python3
"""Finite syntax diagnostics for the two normalized axiom presentations.

Checks literal simultaneous substitution, the stated normalizers, the
stationary extraction probes, and the 26/25 partial template counts.
These tests supplement the structural-induction proofs in report.tex.
Python standard library only.
"""
import json


def V(x): return ("var", x)
O = ("zero",)
def S(t): return ("S", t)
def P(t): return ("p", t)
def I(t, a): return ("I", t, a)
def H(t): return ("h", t)
def Delta(t, a): return ("delta", t, a)
def Eq(t, a): return ("eq", t, a)
B = ("bot",)
def Imp(t, a): return ("imp", t, a)
def And(t, a): return ("and", t, a)
def All(x, f): return ("all", x, f)
def A(t, a): return ("formula_slot", t, a)
n, a = V("n"), V("a")


def subst(tree, variable, term):
    """Replace original variable leaves once; do not revisit inserted terms."""
    if tree == V(variable):
        return term
    return tuple(subst(x, variable, term) if isinstance(x, tuple) else x
                 for x in tree)


def normalize(tree, named_predecessor=False):
    children = tuple(normalize(x, named_predecessor)
                     if isinstance(x, tuple) else x for x in tree[1:])
    tree = (tree[0], *children)
    if tree[0] == "I" and tree[1] == O:
        return tree[2]
    if named_predecessor and tree == P(O):
        return O
    if named_predecessor and tree[0] == "p" and tree[1][0] == "S":
        return tree[1][1]
    if tree == Eq(O, S(O)):
        return B
    return tree


def admitted(f, named_predecessor=False):
    base = normalize(subst(f, "n", O), named_predecessor)
    return base[0] == "imp" and base[1] == base[2]


def nodes(t):
    # Names and binder labels are metadata; a variable leaf is one node.
    return 1 + sum(nodes(c) for c in t[1:] if isinstance(c, tuple))


def schema(pure):
    step = Eq(I(S(n), a), H(I(n, a)) if pure else Delta(n, I(n, a)))
    return All("a", Imp(All("n", Imp(A(n, a), A(S(n), a))),
                        All("n", And(A(n, a), step))))


def main():
    assertions = 0
    def check(condition):
        nonlocal assertions
        assert condition
        assertions += 1

    ordinary_probes = {
        "computation": Imp(B, B),
        "separation": Imp(Eq(O, S(O)), B),
        "initialization": Imp(Eq(a, a), Eq(I(O, a), a)),
    }
    for probe in ordinary_probes.values():
        check(admitted(probe))
        check(admitted(probe, True))
    predecessor_probes = {
        "p_zero": Imp(Eq(O, O), Eq(P(O), O)),
        "p_successor": Imp(Eq(a, a), Eq(P(S(a)), a)),
    }
    for probe in predecessor_probes.values():
        check(admitted(probe, True))
        check(not admitted(probe))
    matrices = [B, Eq(n, a), Eq(I(n, a), a), Eq(P(n), O),
                Imp(Eq(n, O), Eq(a, a)),
                And(Eq(P(S(n)), n), Eq(I(n, P(a)), a))]
    for f in matrices:
        normalized_induction = Imp(subst(f, "n", O), f)
        check(admitted(normalized_induction))
        check(admitted(normalized_induction, True))
    check(not admitted(B))
    check(not admitted(Eq(a, a)))
    check(normalize(P(S(I(O, a))), True) == a)
    check(normalize(Eq(P(S(O)), S(O)), True) == B)
    check(subst(V("n"), "n", I(O, V("n"))) == I(O, V("n")))
    check(nodes(schema(False)) == 26)
    check(nodes(schema(True)) == 25)
    print(json.dumps({"status": "passed", "assertions": assertions,
                      "uniform_fixed_exception_template_nodes": nodes(schema(False)),
                      "named_predecessor_template_nodes": nodes(schema(True)),
                      "scope": "Finite syntax diagnostics, not a formal proof of all instances."},
                     indent=2))


if __name__ == "__main__":
    main()
