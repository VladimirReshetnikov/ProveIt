#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error pra_base_free.tex
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error pra_base_free.tex
