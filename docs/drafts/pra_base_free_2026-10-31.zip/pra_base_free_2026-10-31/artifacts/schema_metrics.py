#!/usr/bin/env python3
"""Count the displayed PRA schemas in a declared, reproducible AST grammar.

This is a syntax audit, not a theorem prover.  It independently constructs
the formulas described in the article and the six reviewed draft packages.
The metric matches the earlier guarded-successor draft's schema_sizes.py:
one node per variable, constant, function application, equality, connective,
or quantifier occurrence.  Binder names are metadata.  Negation and XOR are
expanded; function-symbol names for schematic terms are not program text.

Run from the package root:
    python3 artifacts/schema_metrics.py --report artifacts/schema_metrics.json

Only the specified report file is written.  There are no external packages,
network calls, downloaded executables, or theorem-prover assumptions.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Node:
    kind: str
    children: tuple["Node", ...] = ()
    label: str | None = None

    def as_json(self) -> dict:
        result = {"kind": self.kind}
        if self.label is not None:
            result["label"] = self.label
        if self.children:
            result["children"] = [child.as_json() for child in self.children]
        return result


def variable(name):
    return Node("variable", label=name)


def zero():
    return Node("constant", label="0")


def function(name, *arguments):
    return Node("function", tuple(arguments), name)


def successor(term):
    return function("S", term)


def equality(left, right):
    return Node("equality", (left, right))


def conjunction(left, right):
    return Node("and", (left, right))


def disjunction(left, right):
    return Node("or", (left, right))


def implies(left, right):
    return Node("implies", (left, right))


def negation(body):
    return implies(body, Node("bottom"))


def exclusive(left, right):
    # Each reused subtree is counted as a fresh *occurrence* when traversed.
    return conjunction(disjunction(left, right),
                       negation(conjunction(left, right)))


def forall(name, body):
    return Node("forall", (body,), name)


def count(tree):
    totals = Counter({tree.kind: 1})
    for child in tree.children:
        totals.update(count(child))
    return totals


def build_schemas(parameter_count=1):
    n = variable("n")
    parameters = tuple(variable(f"a{i}") for i in range(parameter_count))

    def close(body):
        for parameter in reversed(parameters):
            body = forall(parameter.label, body)
        return body

    def f(term):
        return function("f", term, *parameters)

    def g(term):
        return function("g", term, *parameters)

    def t(term):
        return function("t", term, *parameters)

    def n_zero(term):
        return equality(term, zero())

    def successor_equation(term):
        return equality(f(term), successor(g(term)))

    def unrestricted_equation(term):
        return equality(f(term), g(term))

    def guard(equation, term):
        return disjunction(n_zero(term), equation(term))

    def step(equation):
        return forall("n", implies(guard(equation, n),
                                   equation(successor(n))))

    def guarded_conclusion(equation):
        return forall("n", guard(equation, n))

    separation = negation(equality(zero(), successor(zero())))
    term_separation = negation(equality(zero(), successor(g(zero()))))

    # Original exclusive schema X has r(n)=0 as its left alternative.
    def old_left(term):
        return equality(f(term), zero())

    def old_positive(term):
        return disjunction(old_left(term), successor_equation(term))

    old_x = close(implies(
        conjunction(old_positive(zero()),
                    forall("n", implies(old_positive(n),
                                        old_positive(successor(n))))),
        forall("n", exclusive(old_left(n), successor_equation(n)))))

    # Guarded successor Y1: f(0)=0 plus the n=0-guarded step.
    old_y1 = close(implies(
        conjunction(equality(f(zero()), zero()), step(successor_equation)),
        forall("n", exclusive(n_zero(n), successor_equation(n)))))

    seeded_a = close(implies(
        conjunction(equality(f(zero()), zero()), step(successor_equation)),
        conjunction(term_separation, guarded_conclusion(successor_equation))))

    base_free_a = close(implies(
        step(successor_equation),
        conjunction(term_separation, guarded_conclusion(successor_equation))))

    ground_successor_a = close(implies(
        step(successor_equation),
        conjunction(separation, guarded_conclusion(successor_equation))))

    recommended_k = close(implies(
        step(unrestricted_equation),
        conjunction(separation, guarded_conclusion(unrestricted_equation))))

    guarded_g = close(implies(
        step(unrestricted_equation), guarded_conclusion(unrestricted_equation)))

    # The independently reviewed one-term alternative, with its fixed bridge.
    one_equation = equality(n, successor(t(n)))
    one_term_y = close(implies(
        forall("n", implies(disjunction(n_zero(n), one_equation),
                            equality(n, t(successor(n))))),
        forall("n", exclusive(n_zero(n), one_equation))))
    x, y = variable("x"), variable("y")
    shift = forall("x", forall("y", equality(
        function("M", successor(x), successor(y)), function("M", x, y))))

    return {
        "exclusive_X": (old_x,),
        "guarded_successor_Y1": (old_y1,),
        "seeded_A": (seeded_a,),
        "base_free_A_prime": (base_free_a,),
        "ground_successor_A": (ground_successor_a,),
        "recommended_K": (recommended_k,),
        "guarded_G_plus_Sep": (guarded_g, separation),
        "one_term_Y_plus_SHIFT": (one_term_y, shift),
    }


def inspect_schemas(parameter_count, include_trees):
    results = {}
    for name, formulas in build_schemas(parameter_count).items():
        totals = Counter()
        details = []
        for formula in formulas:
            counts = count(formula)
            totals.update(counts)
            detail = {
                "nodes": sum(counts.values()),
                "equality_occurrences": counts["equality"],
                "by_kind": dict(sorted(counts.items())),
            }
            if include_trees:
                detail["ast"] = formula.as_json()
            details.append(detail)
        results[name] = {
            "nodes": sum(totals.values()),
            "equality_occurrences": totals["equality"],
            "arithmetic_templates": len(formulas),
            "total_templates_including_two_computation_templates": len(formulas) + 2,
            "schematic_terms": 1 if name == "one_term_Y_plus_SHIFT" else 2,
            "by_kind": dict(sorted(totals.items())),
            "formulas": details,
        }
    return results


def make_report():
    # Hand-derived checks, including the previously published 82, 60, and 42.
    # Entries are (nodes, equality occurrences, separate arithmetic templates).
    expected = {
        "exclusive_X": (82, 10, 1),
        "guarded_successor_Y1": (60, 8, 1),
        "seeded_A": (54, 7, 1),
        "base_free_A_prime": (48, 6, 1),
        "ground_successor_A": (46, 6, 1),
        "recommended_K": (43, 6, 1),
        "guarded_G_plus_Sep": (42, 6, 2),
        "one_term_Y_plus_SHIFT": (55, 8, 2),
    }
    one = inspect_schemas(1, include_trees=True)
    for name, prediction in expected.items():
        actual = tuple(one[name][key] for key in
                       ("nodes", "equality_occurrences", "arithmetic_templates"))
        if actual != prediction:
            raise AssertionError((name, actual, prediction))

    zero_parameter = inspect_schemas(0, include_trees=False)
    linear_counts = {
        name: {
            "constant": zero_parameter[name]["nodes"],
            "coefficient_of_parameter_count":
                one[name]["nodes"] - zero_parameter[name]["nodes"],
        }
        for name in one
    }
    for parameter_count in range(2, 5):
        current = inspect_schemas(parameter_count, include_trees=False)
        for name, law in linear_counts.items():
            predicted = (law["constant"] + parameter_count *
                         law["coefficient_of_parameter_count"])
            if current[name]["nodes"] != predicted:
                raise AssertionError((name, parameter_count, predicted))

    return {
        "status": "All declared syntax checks passed; no mathematical theorem is certified.",
        "metric": {
            "unit": "One per variable, constant, function application, equality, "
                    "logical connective, bottom, or universal quantifier occurrence.",
            "negation": "A -> bottom",
            "exclusive_or": "(A OR B) AND ((A AND B) -> bottom)",
            "quantifiers": "A binder counts once; its bound-variable name is metadata.",
            "parameter": "One fixed numerical parameter occurs in each schematic-term "
                         "application; its outer universal binder is counted.",
            "shared_trees": "Repeated subtrees count again at each occurrence.",
            "separate_formulas": "Their sizes are added without an invented conjunction.",
            "omitted": [
                "The two common computation templates, except in template totals.",
                "Comma, parentheses, whitespace, and variable-name character lengths.",
                "The program descriptions replacing schematic term placeholders.",
                "The length of the common logic, language grammar, and proof translations.",
            ],
            "limitation": "This is not an absolute shortest-axiomatization metric. "
                          "A one-template conjunction can be longer than two formulas.",
        },
        "provenance": {
            "metric_source": "ProveIt/docs/drafts/pra_guarded_successor_2026-10-31.zip: "
                             "artifacts/schema_sizes.py (read, not executed).",
            "implementation": "Independent explicit AST construction in this script.",
            "baseline_matches": {"exclusive_X": 82,
                                 "guarded_successor_Y1": 60,
                                 "guarded_G_plus_Sep": 42},
        },
        "accounting_observations": [
            "Deleting seeded A's base f(0,a)=0 removes that five-node equation "
            "and its conjunction: 54 to 48 nodes, seven to six equalities.",
            "Replacing 0!=S(g(0,a)) with ground 0!=1 removes two nodes: 48 to 46.",
            "Using unrestricted equality removes three successor occurrences: 46 to 43.",
            "Recommended K has the same six equality occurrences as G plus Sep "
            "and is one node LONGER (43 versus 42), because it uses a conjunction.",
            "K's one arithmetic template versus G plus Sep's two is packaging, "
            "not a reduction in total logical content or proof strength.",
            "The one-term Y comparison includes the fixed SHIFT bridge; "
            "sufficiency of Y alone is not claimed.",
        ],
        "one_parameter_presentations": one,
        "zero_parameter_presentations": zero_parameter,
        "nodes_as_linear_functions_of_parameter_count": linear_counts,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path,
                        help="write the report as JSON to this exact path")
    args = parser.parse_args()
    serialized = json.dumps(make_report(), indent=2, ensure_ascii=True) + "\n"
    if args.report is None:
        print(serialized, end="")
    else:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(serialized, encoding="utf-8")
        print(f"Syntax audit passed; wrote {args.report}")


if __name__ == "__main__":
    main()
