#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 artifacts/schema_metrics.py --report artifacts/schema_metrics.json
lean_compiler="lean"
if [ "$#" -gt 0 ]; then
  lean_compiler="$1"
fi
"$lean_compiler" formal/BaseFreePRA.lean
