A SHORTER COMMON AXIOMATIZATION OF PRIMITIVE RECURSIVE ARITHMETIC
31 October 2026
==============================================================

READ FIRST

pra_base_free.pdf is the complete research paper.
pra_base_free.tex is its standalone LaTeX source.
axioms.txt is the exact plain-text specification.

RESULT

The base condition f(0,a)=0 in the current seeded guarded schema can be
deleted. This gives a common classical/intuitionistic basis with six
equality occurrences in its sole arithmetic schema, instead of seven,
and removes the delay-and-mask construction from equation induction.

An equivalent normalized schema K combines guarded equation induction
with ground separation in its conclusion. With the two initialized-
iteration computation templates, this gives three templates in total,
only binary generated symbols, and one numerical induction parameter.

The paper explicitly distinguishes the new deletion from inherited
ingredients. The shorter separated G+Sep specification already exists
in the initial-value draft. K packages it, and is one AST node longer
than writing those two components separately. No absolute minimality
or proof of the one-term candidate without its bridge is claimed.

CONTENTS

  pra_base_free.tex / pra_base_free.pdf
    Complete paper, including constructive equivalence proof,
    comparator, formula compiler, pairing and recursion translation.

  axioms.txt
    All syntax restrictions, computation and arithmetic schemas.

  formal/BaseFreePRA.lean
    New scoped certificate for the constructive reductions.
    Lean 4.19.0, Init only. No Mathlib, Classical, choice, or sorry.

  formal/README.txt / formal/verification.txt
    Exact formal scope and recorded compiler result.

  artifacts/schema_metrics.py / artifacts/schema_metrics.json
    Reproducible formula-tree counts, with explicit ASTs and limitations.

  source_audit.json
    Exact pinned repository snapshot, source paths and checksums.

  comparison.tsv
    Concise machine-readable comparison of arithmetic formula sizes.

  build.sh / check.sh / lean-toolchain
    Reproduction commands and pinned compiler.

  VALIDATION.txt / SHA256SUMS
    Verification status and package integrity.

BUILD THE PDF

  bash build.sh

Requires a standard LaTeX installation with pdflatex and the packages
declared in the source. Two passes resolve all references.

RECHECK ARTIFACTS

  bash check.sh

Requires Python 3 and Lean 4.19.0 on PATH. To choose the compiler:

  bash check.sh /absolute/path/to/lean

No external Lean packages are required.

The paper's complete PRA equivalence is a mathematical proof.
The Lean file checks the revised logical core only; it does not formalize
the full first-order calculus, comparator, pairing, or language compiler.

SOURCE SNAPSHOT

https://github.com/VladimirReshetnikov/ProveIt
Commit: 1933ee3d1630a43f96bfe16aeb88a8371b52082e

All six PRA archives in docs/drafts at this commit were reviewed.
The docs/incoming listing and index were inspected for additional PRA
material; unrelated Busy Beaver packages were not reviewed.
