/-!
# The base-free arithmetic schema: a scoped constructive certificate

Lean 4.19.0, with Init only. No Classical, choice, or object-domain induction.

The schemas below range over actual finite terms with exactly two available
variables: the induction index and one fixed parameter. Function symbols in
`Fn` are arbitrary binary symbols. Predecessor is a displayed helper whose
two computation equations are explicit assumptions. In the accompanying
paper it is a term obtained from an admitted seeded iterator.

This NEW certificate verifies the base-free schema A', its direct reduction
to equation induction, and its equivalence to Sep + G and to
Sep + constructor coverage + equation induction. It also verifies the
shorter general-equation schema K, and that A' implies the old seeded A.

The use of finite syntax and a generic algebra follows the verification
architecture of the supplied SeededGuard.lean. No previous proof file is
imported. In particular, the direct equation-induction proof here uses
f = S u and g = v; it does not use the old mask or delayed recursors.

Scope: these are constructive Lean proofs of reductions between term-indexed
schema properties of an abstract algebra. They are not a formalization of
the full first-order derivation calculus, the seeded-description grammar,
equality reflection, pairing, or the final PRA definitional equivalence.
Those parts are proved in the accompanying paper. Structural induction on
finite terms is used only to verify syntactic substitution. No induction
principle is assumed or invoked for the abstract numerical carrier except
the explicitly displayed arithmetic schema hypotheses.
-/

namespace BaseFreePRA

universe u v

inductive Var where
  | index
  | parameter

inductive Term (Fn : Type u) where
  | var : Var → Term Fn
  | zero : Term Fn
  | succ : Term Fn → Term Fn
  | pred : Term Fn → Term Fn
  | app : Fn → Term Fn → Term Fn → Term Fn

/-- Syntactic substitution of S n for n; the parameter remains fixed. -/
def Term.shift {Fn : Type u} : Term Fn → Term Fn
  | .var .index => .succ (.var .index)
  | .var .parameter => .var .parameter
  | .zero => .zero
  | .succ t => .succ t.shift
  | .pred t => .pred t.shift
  | .app f s t => .app f s.shift t.shift

structure Algebra (Fn : Type u) where
  Carrier : Type v
  zero : Carrier
  succ : Carrier → Carrier
  pred : Carrier → Carrier
  app : Fn → Carrier → Carrier → Carrier

def Algebra.eval {Fn : Type u} (M : Algebra.{u,v} Fn)
    (n a : M.Carrier) : Term Fn → M.Carrier
  | .var .index => n
  | .var .parameter => a
  | .zero => M.zero
  | .succ t => M.succ (M.eval n a t)
  | .pred t => M.pred (M.eval n a t)
  | .app f s t => M.app f (M.eval n a s) (M.eval n a t)

theorem eval_shift {Fn : Type u} (M : Algebra.{u,v} Fn)
    (n a : M.Carrier) (t : Term Fn) :
    M.eval n a t.shift = M.eval (M.succ n) a t := by
  induction t with
  | var x => cases x <;> rfl
  | zero => rfl
  | succ t ih => exact congrArg M.succ ih
  | pred t ih => exact congrArg M.pred ih
  | app f s t ihs iht =>
      change M.app f (M.eval n a s.shift) (M.eval n a t.shift) = _
      rw [ihs, iht]
      rfl

structure PredecessorLaws {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop where
  at_zero : M.pred M.zero = M.zero
  at_succ : ∀ n, M.pred (M.succ n) = n

def Separation {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  M.zero ≠ M.succ M.zero

def Coverage {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ n, n = M.zero ∨ n = M.succ (M.pred n)

def Step {Fn : Type u} (M : Algebra.{u,v} Fn)
    (s t : Term Fn) (a : M.Carrier) : Prop :=
  ∀ n, (n = M.zero ∨ M.eval n a s = M.eval n a t) →
    M.eval (M.succ n) a s = M.eval (M.succ n) a t

def Positive {Fn : Type u} (M : Algebra.{u,v} Fn)
    (s t : Term Fn) (a : M.Carrier) : Prop :=
  ∀ n, n = M.zero ∨ M.eval n a s = M.eval n a t

/-- A': no hypothesis specifies the value of f at zero. -/
def BaseFreeSchema {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ (f g : Term Fn) (a : M.Carrier), Step M f (.succ g) a →
    (M.zero ≠ M.succ (M.eval M.zero a g)) ∧ Positive M f (.succ g) a

/-- The earlier G schema, with an arbitrary equation in its guard. -/
def GuardedSchema {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ (s t : Term Fn) (a : M.Carrier),
    Step M s t a → Positive M s t a

def EquationInduction {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ (s t : Term Fn) (a : M.Carrier),
    M.eval M.zero a s = M.eval M.zero a t →
    (∀ n, M.eval n a s = M.eval n a t →
      M.eval (M.succ n) a s = M.eval (M.succ n) a t) →
    ∀ n, M.eval n a s = M.eval n a t

/-- The old seeded A retains the now-unnecessary initial equation. -/
def OldSeededSchema {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ (f g : Term Fn) (a : M.Carrier), M.eval M.zero a f = M.zero →
    Step M f (.succ g) a →
    (M.zero ≠ M.succ (M.eval M.zero a g)) ∧ Positive M f (.succ g) a

/-- K packages the arbitrary-equation G conclusion with ground separation. -/
def CompactSchema {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ (s t : Term Fn) (a : M.Carrier), Step M s t a →
    Separation M ∧ Positive M s t a

theorem successor_injective {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) {x y : M.Carrier}
    (h : M.succ x = M.succ y) : x = y := by
  have he := congrArg M.pred h
  rw [hp.at_succ, hp.at_succ] at he
  exact he

theorem successor_nonzero {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) (hsep : Separation M) (n : M.Carrier) :
    M.zero ≠ M.succ n := by
  intro he
  have hn : M.zero = n := by
    have h := congrArg M.pred he
    rw [hp.at_zero, hp.at_succ] at h
    exact h
  exact hsep (he.trans (congrArg M.succ hn).symm)

theorem baseFree_separation_coverage {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) (hb : BaseFreeSchema M) :
    Separation M ∧ Coverage M := by
  have hstep : Step M (.var .index) (.succ (.pred (.var .index)))
      M.zero := by
    intro n _
    change M.succ n = M.succ (M.pred (M.succ n))
    rw [hp.at_succ]
  obtain ⟨hsep, hcov⟩ := hb (.var .index) (.pred (.var .index)) M.zero hstep
  change M.zero ≠ M.succ (M.pred M.zero) at hsep
  rw [hp.at_zero] at hsep
  exact ⟨hsep, hcov⟩

/-- The direct lifting f = S u, g = v; no zero boundary or delay is needed. -/
theorem baseFree_equationInduction {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) (hb : BaseFreeSchema M) : EquationInduction M := by
  intro s t a hbase hnext
  have hstep : Step M (.succ s) (.succ t) a := by
    intro n hn
    change M.succ (M.eval (M.succ n) a s) = M.succ (M.eval (M.succ n) a t)
    apply congrArg M.succ
    apply hnext n
    rcases hn with hz | he
    · rw [hz]
      exact hbase
    · exact successor_injective M hp he
  have hpositive := (hb (.succ s) t a hstep).2
  intro n
  rcases hpositive n with hz | he
  · rw [hz]
    exact hbase
  · exact successor_injective M hp he

theorem guarded_coverage {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) (hg : GuardedSchema M) : Coverage M := by
  apply hg (.var .index) (.succ (.pred (.var .index))) M.zero
  intro n _
  change M.succ n = M.succ (M.pred (M.succ n))
  rw [hp.at_succ]

theorem guarded_equationInduction {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hg : GuardedSchema M) : EquationInduction M := by
  intro s t a hbase hnext
  have hstep : Step M s t a := by
    intro n hn
    apply hnext n
    rcases hn with hz | he
    · rw [hz]
      exact hbase
    · exact he
  intro n
  rcases hg s t a hstep n with hz | he
  · rw [hz]
    exact hbase
  · exact he

theorem guarded_of_coverage_equationInduction {Fn : Type u}
    (M : Algebra.{u,v} Fn) (hc : Coverage M) (hi : EquationInduction M) :
    GuardedSchema M := by
  intro s t a hs
  have hbase : M.eval M.zero a s.shift = M.eval M.zero a t.shift := by
    rw [eval_shift, eval_shift]
    exact hs M.zero (Or.inl rfl)
  have hnext : ∀ n, M.eval n a s.shift = M.eval n a t.shift →
      M.eval (M.succ n) a s.shift = M.eval (M.succ n) a t.shift := by
    intro n he
    rw [eval_shift, eval_shift] at he
    rw [eval_shift, eval_shift]
    exact hs (M.succ n) (Or.inr he)
  have hall := hi s.shift t.shift a hbase hnext
  intro n
  rcases hc n with hz | hsucc
  · exact Or.inl hz
  · apply Or.inr
    have he := hall (M.pred n)
    rw [eval_shift, eval_shift, ← hsucc] at he
    exact he

theorem baseFree_guarded {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) (hb : BaseFreeSchema M) : GuardedSchema M :=
  guarded_of_coverage_equationInduction M
    (baseFree_separation_coverage M hp hb).2 (baseFree_equationInduction M hp hb)

theorem baseFree_of_separation_guarded {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) (hsep : Separation M) (hg : GuardedSchema M) :
    BaseFreeSchema M := by
  intro f g a hs
  exact ⟨successor_nonzero M hp hsep (M.eval M.zero a g), hg f (.succ g) a hs⟩

theorem baseFree_iff_separation_guarded {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) :
    BaseFreeSchema M ↔ Separation M ∧ GuardedSchema M := by
  constructor
  · intro hb
    exact ⟨(baseFree_separation_coverage M hp hb).1, baseFree_guarded M hp hb⟩
  · intro h
    exact baseFree_of_separation_guarded M hp h.1 h.2

theorem baseFree_iff_separation_coverage_equationInduction {Fn : Type u}
    (M : Algebra.{u,v} Fn) (hp : PredecessorLaws M) :
    BaseFreeSchema M ↔ Separation M ∧ Coverage M ∧ EquationInduction M := by
  constructor
  · intro hb
    obtain ⟨hsep, hc⟩ := baseFree_separation_coverage M hp hb
    exact ⟨hsep, hc, baseFree_equationInduction M hp hb⟩
  · intro h
    exact baseFree_of_separation_guarded M hp h.1
      (guarded_of_coverage_equationInduction M h.2.1 h.2.2)

theorem baseFree_oldSeeded {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hb : BaseFreeSchema M) : OldSeededSchema M := by
  intro f g a _ hs
  exact hb f g a hs

theorem compact_iff_separation_guarded {Fn : Type u} (M : Algebra.{u,v} Fn) :
    CompactSchema M ↔ Separation M ∧ GuardedSchema M := by
  constructor
  · intro hk
    have hstep : Step M .zero .zero M.zero := by
      intro _ _
      rfl
    refine ⟨(hk .zero .zero M.zero hstep).1, ?_⟩
    intro s t a hs
    exact (hk s t a hs).2
  · intro h s t a hs
    exact ⟨h.1, h.2 s t a hs⟩

theorem compact_iff_baseFree {Fn : Type u} (M : Algebra.{u,v} Fn)
    (hp : PredecessorLaws M) : CompactSchema M ↔ BaseFreeSchema M := by
  constructor
  · intro hk
    exact (baseFree_iff_separation_guarded M hp).2
      ((compact_iff_separation_guarded M).1 hk)
  · intro hb
    exact (compact_iff_separation_guarded M).2
      ((baseFree_iff_separation_guarded M hp).1 hb)

/-- An actual quantifier-free formula syntax, for the converse from PRA. -/
inductive Formula (Fn : Type u) where
  | equal : Term Fn → Term Fn → Formula Fn
  | bottom : Formula Fn
  | and : Formula Fn → Formula Fn → Formula Fn
  | or : Formula Fn → Formula Fn → Formula Fn
  | imp : Formula Fn → Formula Fn → Formula Fn

def Formula.holds {Fn : Type u} (M : Algebra.{u,v} Fn)
    (n a : M.Carrier) : Formula Fn → Prop
  | .equal s t => M.eval n a s = M.eval n a t
  | .bottom => False
  | .and A B => A.holds M n a ∧ B.holds M n a
  | .or A B => A.holds M n a ∨ B.holds M n a
  | .imp A B => A.holds M n a → B.holds M n a

def QuantifierFreeInduction {Fn : Type u} (M : Algebra.{u,v} Fn) : Prop :=
  ∀ (A : Formula Fn) (a : M.Carrier), A.holds M M.zero a →
    (∀ n, A.holds M n a → A.holds M (M.succ n) a) →
    ∀ n, A.holds M n a

theorem baseFree_of_quantifierFreeInduction {Fn : Type u}
    (M : Algebra.{u,v} Fn) (hn : ∀ n, M.zero ≠ M.succ n)
    (hi : QuantifierFreeInduction M) : BaseFreeSchema M := by
  intro f g a hs
  let B : Formula Fn := .or (.equal (.var .index) .zero) (.equal f (.succ g))
  have hbase : B.holds M M.zero a := Or.inl rfl
  have hnext : ∀ n, B.holds M n a → B.holds M (M.succ n) a := by
    intro n he
    exact Or.inr (hs n he)
  exact ⟨hn (M.eval M.zero a g), hi B a hbase hnext⟩

#print axioms eval_shift
#print axioms successor_injective
#print axioms successor_nonzero
#print axioms baseFree_separation_coverage
#print axioms baseFree_equationInduction
#print axioms baseFree_guarded
#print axioms baseFree_iff_separation_guarded
#print axioms baseFree_iff_separation_coverage_equationInduction
#print axioms baseFree_oldSeeded
#print axioms compact_iff_separation_guarded
#print axioms compact_iff_baseFree
#print axioms baseFree_of_quantifierFreeInduction

end BaseFreePRA
