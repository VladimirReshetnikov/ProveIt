SCOPED LEAN CERTIFICATE
======================

File: BaseFreePRA.lean
Compiler: Lean 4.19.0
Dependencies: Init only; no Mathlib or external package.
Reproduce: lean BaseFreePRA.lean

The actual compiled output is recorded in verification.txt. All twelve
printed headline results depend on no Lean axioms. There is no sorry,
Classical invocation, choice, or induction over the abstract numerical
carrier. Structural induction is used to verify substitution on finite
Term syntax.

SCHEMAS REPRESENTED

The finite term grammar has two variable slots, zero, successor,
predecessor, and arbitrary binary applications. Every schema ranges over
terms in that grammar, with one fixed numerical parameter. Predecessor is
a helper constructor with two explicitly assumed computation equations;
the paper obtains it from a permitted initialized iterator.

BaseFreeSchema is A': the successor-equation guarded step implies
0 != S(g(0,a)) and the positive guarded conclusion, with no base premise.

GuardedSchema is the earlier G, with an arbitrary equation in the guard.
CompactSchema is K, combining G with ground separation in its conclusion.
OldSeededSchema is the earlier A, which additionally assumes f(0,a)=0.

PROVED RESULTS

1. Predecessor's successor equation gives successor injectivity.
2. A' gives separation and positive constructor coverage in one instance.
3. A' gives equation induction by the direct terms f=S(u), g=v.
4. A' is equivalent to separation plus G.
5. A' is equivalent to separation, coverage, and equation induction.
6. A' implies the old seeded A.
7. K is equivalent to separation plus G, and hence to A'.
8. Quantifier-free induction and successor nonzeroness imply A'.

PROOF SCOPE

These are constructive reductions between term-indexed schema properties
of an abstract algebra, expressed and checked in Lean. This is not a
formalization of the full first-order proof calculus or a machine-checked
proof of the complete PRA equivalence theorem. The complete grammar of
initialized-iterator descriptions, the native-equality comparator, the
quantifier-free formula compiler, pairing, and conservative definitional
extension are proved in the paper, outside this certificate.

The finite-syntax/generic-algebra verification architecture is informed
by the supplied SeededGuard.lean. This is a new standalone certificate;
it imports no earlier proof and uses none of the old masking or delay
construction in the direct equation-induction reduction.
