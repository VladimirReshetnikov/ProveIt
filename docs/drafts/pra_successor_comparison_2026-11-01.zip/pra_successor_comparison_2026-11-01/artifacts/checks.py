#!/usr/bin/env python3
"""Finite diagnostics and exact template-size calculations.

These checks are executable diagnostics, not proofs of first-order
interpretability, intuitionistic derivability, or nonstandard-model claims.
Only Python's standard library is needed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from functools import cache
from pathlib import Path


def node(label, *children):
    return (label, children)


def size(tree):
    return 1 + sum(map(size, tree[1]))


def atom(name):
    return node(name)


def app(name, *args):
    return node(name, *args)


def eq(left, right):
    return node("=", left, right)


def universal(names, body):
    for name in reversed(names):
        body = node("forall " + name, body)
    return body


def formula_metrics(m):
    assert m >= 1
    n, a, zero, v = map(atom, ("n", "a", "0", "v"))
    bnames = ["b" + str(i) for i in range(m - 1)]
    bs = list(map(atom, bnames))
    params = [a, *bs]
    pnames = ["a", *bnames]
    sn = app("S", n)
    fn = app("f", n, *params)
    f0 = app("f", zero, *params)
    base = universal(pnames, eq(app("R", zero, *params), a))
    inner = app("R", a, n, *bs)
    oldstep = universal(["n", *pnames],
                        eq(app("R", sn, *params),
                           app("h", n, a, *bs, inner)))
    newstep = universal(["n", *pnames],
                        eq(app("R", sn, *params),
                           app("h", n, *bs, inner)))
    sep = node("implies", eq(zero, app("S", zero)), atom("false"))
    stationarity = universal(["n"],
                             eq(app("f", sn, *params), fn))
    oldconclusion = universal(["n"], node("or",
        eq(app("T", f0, a), a), eq(fn, a)))
    newconclusion = universal(["n"], node("or",
        eq(app("C", app("D", a, f0), f0, a), a),
        eq(app("S", fn), a)))
    oldschema = universal(pnames, node("implies", stationarity, oldconclusion))
    newschema = universal(pnames, node("implies", stationarity, newconclusion))
    oldbodies = [atom("b"), v, app("C", app("D", a, n), n, a)]
    newbodies = [atom("b"), v]
    old = {"base": size(base), "step": size(oldstep),
           "separation": size(sep), "comparison": size(oldschema),
           "helper_bodies": sum(map(size, oldbodies))}
    new = {"base": size(base), "step": size(newstep),
           "separation": size(sep), "comparison": size(newschema),
           "helper_bodies": sum(map(size, newbodies))}
    for row in (old, new):
        row["display"] = sum(row[k] for k in ("base", "step", "separation", "comparison"))
        row["partial_total"] = row["display"] + row["helper_bodies"]
    assert old["partial_total"] == 11 * m + 47
    assert new["partial_total"] == 12 * m + 45
    return {"m": m, "current_best": old, "new": new,
            "new_minus_current": new["partial_total"] - old["partial_total"]}


def swap(update, *parameters):
    """R(0,a,b)=a; R(Sn,a,b)=h(n,b,R(a,n,b)).

    The Python calling convention is h(n, v, *b).  Every recursive
    call decreases x+a by exactly one; h never receives the seed a.
    """
    @cache
    def run(x, a):
        if x < 0 or a < 0:
            raise ValueError("Natural-number arguments required")
        if x == 0:
            return a
        n = x - 1
        assert a + n == x + a - 1
        return update(n, run(a, n), *parameters)
    return run


def reverse_compile(update, *parameters):
    """Ordinary-PR diagonal fold specialized to seed-blind updates."""
    @cache
    def fold(j, d, e):
        if j == 0:
            return e if d == 0 else update(d - 1, d - 1, *parameters)
        k = j - 1
        return update(d + k,
                      update(e + k, fold(k, d, e), *parameters),
                      *parameters)

    def run(x, a):
        return fold(min(x, a), max(x - a, 0), max(a - x, 0))
    return run


def numerical_checks():
    count = {}
    bound = 24
    D = swap(lambda n, v: v)

    def C(z, left, right):
        return swap(lambda n, v, b: b, right)(z, left)

    tested = 0
    for x in range(bound + 1):
        for a in range(bound + 1):
            assert D(x, a) == max(a - x, 0) + max(x - a - 1, 0)
            assert D(0, a) == a
            assert D(x + 1, a) == D(a, x)
            assert C(x, a, 7) == (a if x == 0 else 7)
            assert C(D(a, x), x, a) == a or x + 1 == a
            E = C(D(a + 1, x), x, a + 1)
            err = D(a, E)
            assert err in (0, 1)
            assert (err == 0) == (x == a)
            assert (err == 1) == (x != a)
            tested += 1
    count["C_D_comparison_and_equality_pairs"] = tested

    for x in range(bound + 1):
        assert D(x, x) == 0
        assert D(x, x + 1) == 1
        assert D(x + 1, 0) == x
    count["diagonal_and_predecessor_arguments"] = bound + 1

    updates = [
        ("identity", lambda n, v: v),
        ("successor", lambda n, v: v + 1),
        ("counter", lambda n, v: n),
        ("affine", lambda n, v: 2 * v + n + 1),
        ("alternating_reset", lambda n, v: v + n if n % 2 else n),
    ]
    tests = 0
    for name, update in updates:
        R = swap(update)
        compiled = reverse_compile(update)
        for x in range(14):
            for a in range(14):
                assert R(x, a) == compiled(x, a), (name, x, a)
                assert compiled(0, a) == a
                assert compiled(x + 1, a) == update(x, compiled(a, x))
                assert R(x + 1, a + 1) == update(x, update(a, R(x, a)))
                tests += 1
    count["forward_reverse_and_diagonal_recurrence_pairs"] = tests

    # Each update is independently idempotent in its accumulator.
    idempotents = [
        ("identity", lambda n, v: v),
        ("bounded_overwrite", lambda n, v: n + 1 if n % 3 == 0 else v),
        ("latch", lambda n, v: 1 if n in (4, 9) else v),
    ]
    scans = 0
    for name, update in idempotents:
        R = swap(update)
        expected = 0
        for n in range(25):
            assert R(n, n) == expected, (name, n)
            for v in range(15):
                assert update(n, update(n, v)) == update(n, v)
            assert R(n + 1, n + 1) == update(n, R(n, n))
            expected = update(n, expected)
            scans += 1
    count["idempotent_diagonal_scan_steps"] = scans

    # Arbitrary finite Boolean sequences, not only induction hypotheses.
    # The diagonal is exactly the error latch, and its shifted term is
    # stationary whenever the Boolean sequence has base=true and is
    # successor closed throughout the checked interval.
    latch_cases = 0
    width = 7
    for mask in range(1 << width):
        bits = [(mask >> n) & 1 for n in range(width)]
        def truth(n):
            return bits[n] if n < width else bits[-1]
        R = swap(lambda n, v: v if truth(n) else 1)
        expected = 0
        for n in range(width + 1):
            assert R(n, n) == expected
            expected = expected if truth(n) else 1
        if bits[0] == 1 and all(not bits[n] or bits[n + 1]
                                for n in range(width - 1)):
            shifted = [R(n + 1, n + 1) for n in range(width)]
            assert shifted == [0] * width
        latch_cases += 1
    count["finite_boolean_latch_sequences"] = latch_cases

    # Bounded ordinary-recursion compiler.  The seed is absent from h.
    # W(j,N)=R(Sj,S(N+j),N); the inner high-counter update is identity.
    examples = [
        ("successive_increments", 0, lambda j, v: v + 1),
        ("factorial", 1, lambda j, v: (j + 1) * v),
        ("affine_accumulation", 3, lambda j, v: 2 * v + j),
        ("nonmonotone_reset", 7, lambda j, v: j if j % 2 else v // 2),
    ]
    compiler_pairs = 0
    coherence_triples = 0
    for name, base, step in examples:
        runs = {}
        for N in range(11):
            def update(n, v, N):
                return base if n == 0 else step(n - 1, v) if n <= N else v
            R = swap(update, N)
            W = lambda j, R=R, N=N: R(j + 1, N + j + 1)
            runs[N] = W
            assert W(0) == base
            expected = base
            for j in range(N + 1):
                assert W(j) == expected, (name, j, N)
                if j + 1 <= N:
                    assert W(j + 1) == step(j, W(j)), (name, j, N)
                expected = step(j, expected)
                compiler_pairs += 1
        for N in runs:
            for M in runs:
                for j in range(min(N, M) + 1):
                    assert runs[N](j) == runs[M](j)
                    coherence_triples += 1
        for n in range(10):
            assert runs[n + 1](n + 1) == step(n, runs[n](n))
    count["bounded_PR_compiler_pairs"] = compiler_pairs
    count["bounded_coherence_triples"] = coherence_triples
    return count


def archive_hash_checks(manifest_path):
    if manifest_path is None or not manifest_path.exists():
        return {"status": "not_run", "reason": "source manifest not supplied"}
    manifest = json.loads(manifest_path.read_text())
    rows = []
    for entry in manifest["files"]:
        path = manifest_path.parent / entry["name"]
        data = path.read_bytes()
        digest = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert digest == entry["sha"], entry["name"]
        assert len(data) == entry["size"], entry["name"]
        rows.append({"name": entry["name"], "bytes": len(data),
                     "git_blob_sha1": digest, "verified": True})
    return {"status": "passed", "snapshot": manifest["head"], "archives": rows}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--source-manifest", type=Path)
    args = parser.parse_args()
    report = {
        "status": "passed",
        "scope": "Finite diagnostics and exact schematic AST metrics; not a machine-checked proof of the mathematical metatheorems.",
        "metrics": [formula_metrics(m) for m in range(1, 7)],
        "numerical_checks": numerical_checks(),
        "source_archives": archive_hash_checks(args.source_manifest),
    }
    text = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text)
    print(text, end="")


if __name__ == "__main__":
    main()
