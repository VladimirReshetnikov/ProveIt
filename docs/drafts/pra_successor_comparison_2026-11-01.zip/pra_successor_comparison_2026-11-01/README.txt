PRA WITHOUT A SEPARATE COMPARISON PROGRAM
1 November 2026

MAIN RESULT
The same nonlogical basis, in classical or intuitionistic first-order
equality logic respectively, is definitionally equivalent to the matching
version of first-order PRA. Both interpretations have full domains and
native equality; both compositions are provably the identity on every
function description.

WHAT IS NEW
The update in initialized swap recursion receives the counter and the
recursive value, but not the changing initial value. A positive successor
comparison schema uses only C and D; no dedicated comparator program T
is selected. Idempotent diagonal scans give a direct induction proof.

Under the reviewed drafts' representative expanded tree count, the
display-plus-designated-body subtotal is 57 versus 58. Displayed formulas
alone increase from 50 to 55; selected bodies decrease from 8 to 2.
For parameter count m the totals are 12m+45 and 11m+47, respectively:
the new basis wins at m=1, ties at m=2, and is larger for m>=3.
This is a structural simplification with a modest metric-dependent saving,
not an absolute or uniform shortestness theorem.

CONTENTS
  pra_successor_comparison.pdf  Complete mathematical report.
  report.tex                   Main LaTeX source.
  sections/*.tex               All proof and comparison sections.
  AXIOMS.txt                   Standalone exact specification.
  build.py                     Rebuilds the PDF with pdflatex.
  artifacts/checks.py           Standard-library finite diagnostics.
  artifacts/check_results.json Recorded numerical and AST results.
  audit/source_manifest.json   Eight immutable reviewed source identities.
  audit/validation.json        Build, review, and verification scope.
  SHA256SUMS                   Checksums for the package contents.

REBUILD
  python3 build.py
Requires Python 3 and a standard LaTeX installation with pdflatex,
lmodern, microtype, amsmath, mathtools, geometry, booktabs, tabularx,
enumitem, xcolor, fancyhdr, xurl, and hyperref.

RUN FINITE DIAGNOSTICS
  python3 artifacts/checks.py --output artifacts/check_results_rebuilt.json
To also verify retrieved source ZIPs, place them next to a copy of the
source manifest and pass --source-manifest /path/to/manifest.json.
The package's recorded check results include verification of all eight
source archives at commit 3abedb526f9557c7817899dbd5fcd9872a95c51d.

VERIFICATION SCOPE
The report contains complete constructive mathematical proofs.
The Python checks are finite diagnostics and exact template counts;
they are not a Lean or Rocq formalization of the metatheorems.
Countermodels in the report show why plain constancy, negative comparison,
and zero-only constancy cannot substitute for the positive comparison.
The report includes a Further research questions section.
