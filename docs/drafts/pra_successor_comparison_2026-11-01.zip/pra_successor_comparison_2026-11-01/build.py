#!/usr/bin/env python3
"""Build the complete report using standard LaTeX. Requires pdflatex."""
from pathlib import Path
import shutil
import subprocess
import tempfile

root = Path(__file__).resolve().parent
engine = shutil.which("pdflatex")
if not engine:
    raise SystemExit("pdflatex is required; install a standard TeX distribution.")
audit = root / "audit"
audit.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(prefix="pra_tex_") as temporary:
    output = Path(temporary)
    command = [engine, "-interaction=nonstopmode", "-halt-on-error",
               "-jobname=pra_successor_comparison",
               "-output-directory=" + str(output), "report.tex"]
    transcript = []
    for pass_number in range(1, 4):
        completed = subprocess.run(command, cwd=root, text=True,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT)
        transcript.append("PASS " + str(pass_number) + "\n" + completed.stdout)
        (audit / "latex_build.log").write_text("\n".join(transcript))
        if completed.returncode:
            print(completed.stdout)
            raise SystemExit(completed.returncode)
    shutil.copy2(output / "pra_successor_comparison.pdf",
                 root / "pra_successor_comparison.pdf")
    shutil.copy2(output / "pra_successor_comparison.log",
                 audit / "latex_final.log")
print(root / "pra_successor_comparison.pdf")
