# Provenance and limits of the novelty assessment

## Repository access

GitHub connector was used to list `https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts` on the main branch, and to obtain ZIP bytes using the base64 file endpoint. The ZIP central directories and the selected DEFLATE-compressed text files were decoded in the tool environment. Direct git network access from the local runtime was unavailable (DNS failure). No GitHub mutation was requested or performed.

Direct antecedent (full `uc_lopsided/paper.tex`, README read):

- `union_closed_lopsided_certificates_2026-11-25.zip`, blob SHA `6a4907063eaf84961dcfacea3718ebf7741ff100`. Its Theorem 3.2 and regular corollary give the neighborhood-product frequency bound; Table 1 gives thresholds 14, 40, 100, 237, 541, 1206. Its last section asks whether a sharper conditional-avoidance argument can lower the triple threshold. The current proof inherits the dual representation and lopsided dependency graph, but fixes the mark and bounds obstructions to deleting part of it. The unbounded-construction proposition in the new manuscript exhibits a strict separation from the old symmetric certificate.
- `union_closed_joint_laws_2026-11-25.zip`, blob SHA `c497e7f366a6c29bd2002919c0a5e497d6359133`: its relationship to the support-hypergraph local lemma is documented by the directly read lopsided draft. The full text of the joint-laws ZIP was not separately read here; extraction of README by exact filename produced no content.

Other ZIP README summaries inspected for topic comparison (not a systematic audit of their proofs):

- `union_closed_signature_interfaces_2026-11-25.zip` (`7d715274e013371d5d4156b461f970c50c1f9c00`): separating signatures, rank and projection counts.
- `union_closed_rank_transport_2026-11-25.zip` (`f4c375d5ae9b7337ed4e542950da3d602be537be`): principal-filter entropy and rank transport.
- `union_closed_five_type_obstructions_2026-11-25.zip` (`031a30363602a04b7a35a4e3194f484a2f076a9c`): marked-pair obstruction tests and omissions.
- `union_closed_antichain_shadows_2026-11-25.zip` (`ce0aa9b6412a1196261afacbb8deb9954fb7ead7`): antichain expansion and entropy envelopes.
- `union_closed_redundant_core_2026-11-25.zip` (`18cd1e26f63dee50486533964e3fbf085660af09`): redundant incidence cores and sharp binomial thresholds.
- `union_closed_dense_core_2026-11-25.zip` (`b1c269b2ae1cdb03f91797a2bf840e96730c5934`): three omitted generators, robust marked pairs.
- `union_closed_defective_substitution.zip` (`14d8202bb57108a1908e62bec65918ac030e7571`): defective substitution patterns, marked bounds.

Other archives were listed but not systematically inspected. The advance is established relative to the stated prior symmetric sufficient criterion, not a proof that every previous approach fails on the new class.

## Public literature review

Targeted web searches on 25 November 2026 covered the current universal lower bound, dual generator incidence, graph-generated union-closed families, hypergraph local lemmas and deletion, and local configurations. Relevant sources:

- E. Knill, *Graph generated union-closed families of sets* (1994), https://arxiv.org/abs/math/9409215 — classical dual viewpoint and rank-two case. Not a claim of novelty for duality.
- H. Bruhn, P. Charbit, O. Schaudt, J. A. Telle, *The graph formulation of the union-closed sets conjecture* (2015), https://doi.org/10.1016/j.ejc.2014.08.030 — graph formulation and restricted cases.
- J. Pulaj, K. Wood, *Local Configurations in Union-Closed Families* (2025), https://doi.org/10.1080/10586458.2024.2410964 — other local configuration criteria.
- S. Costa, A. Sadhu, *Beyond Liu's 0.382709 threshold for the union-closed sets conjecture*, https://arxiv.org/abs/2610.02295 and https://zenodo.org/records/22727713 — abstract reports 0.3828852549667978 as universal lower bound.
- Quantavane, https://quantavane.com/major-results/union-closed-sets-conjecture/ — November 2026 project announcement reports 0.38317525996679...; not independently audited here.
- https://en.wikipedia.org/wiki/Union-closed_sets_conjecture — general statement and background.

No identical deletion-based criterion and threshold table was found in this limited review. This is not a comprehensive priority search: in particular, no claim is made that every prior result or manuscript has been read, that these generator classes were never previously covered, or that the unrestricted constant was improved. The mathematical result stands or falls by its proof, while historical originality remains provisional.
