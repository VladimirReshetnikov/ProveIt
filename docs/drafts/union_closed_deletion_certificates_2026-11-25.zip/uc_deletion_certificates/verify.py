#!/usr/bin/env python3
"""Exact certificate arithmetic and finite checks (standard library only)."""
from fractions import Fraction as F
from itertools import combinations
from math import comb
import csv, json, random

ROWS=[(3,14,13,49,52),(4,40,39,207,66),(5,100,99,642,70),
      (6,237,234,1674,61),(7,541,536,4618,66),(8,1206,1197,11610,52)]

def require(x,msg):
    if not x: raise AssertionError(msg)

def subsets(s):
    t=s
    while True:
        yield t
        if not t: break
        t=(t-1)&s

def certificate(r,d,h,k=1):
    R=r-1; q=F(2**R-1,2**R); a=F(1,h); s=R*(d-1); t=R*(s+1)
    delta=(r-k)*q**(d-1)/(1-a)**s+k*s*q**max(0,d-k)/2**R/(1-a)**t
    return delta

def verify_rows():
    rows=[]
    for r,old,d,h,L in ROWS:
        R=r-1; u=2**R; q=F(u-1,u); b=R*d; s=R*(d-1); t=R*(s+1)
        require(2*u**d*(h-1)**b >= (u-1)**d*h**(b+1),'LLL certificate')
        require(d>=u and d>=r,'propagation condition')
        delta=certificate(r,d,h)
        require(delta < 1-F(L,r*(100-L)),'strict abundance bound')
        f=r*(1-delta)/(1+r*(1-delta))
        rows.append(dict(rank=r,prior_threshold=old,new_threshold=d,denominator=h,
                         strict_percent=L,delta_approx=f'{float(delta):.9f}',bound_approx=f'{float(f):.9f}'))
    # Prior symmetric full-edge certificate cannot prove half at r=3,d=13.
    require(4*53**75<54**75,'old half test fails at a=1/54')
    require(2*53**51<54**51,'old two-index test fails at a=1/54')
    require(2*4**13*53**26<3**13*54**27,'old LLL fails at a=1/54')
    # d=12 cannot meet even the old symmetric LLL maximum.
    require(F(3,4)**12/2>F(1,25)*F(24,25)**24,'d12 symmetric ceiling')
    with open('bounds.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    return rows

def good_sets(n,edges):
    return {t for t in range(1<<n) if t==union_of_edges(t,edges)}
def union_of_edges(t,edges):
    u=0
    for e in edges:
        if e&t==e: u|=e
    return u

def neigh(n,edges):
    out=[0]*n
    for e in edges:
        for v in range(n):
            if e>>v&1:out[v]|=e&~(1<<v)
    return out

def bits(s):
    while s:
        t=s&-s;yield t.bit_length()-1;s-=t

def model(n,edges,E,a,all_cuts=True):
    """Enumerate conditional product exactly, and check each obstruction bound."""
    V=(1<<n)-1; outside=V^E; N=neigh(n,edges); Y=[E|t for t in subsets(outside)]
    good=good_sets(n,edges); full=[y for y in Y if y in good]; assert full
    # Conditional bad probabilities. The selected E centers are automatically good.
    C={v:{y for y in Y if (y>>v&1) and not any((e>>v&1) and e&y==e for e in edges)} for v in bits(outside)}
    def W(s):
        z=F(1)
        for v in bits(s):z*=1-a[v]
        return z
    eligible=all(F(len(C[v]),len(Y)) <= a[v]*W(N[v]&outside) for v in C)
    pchecks=0; cuts=0; obstruction_checks=0
    # Exact fiber identity works even if no certificate exists.
    for K in subsets(E):
        if not K: continue
        if not all_cuts and K.bit_count()>1:continue
        cuts+=1
        success=sum((y&~K) in good for y in full)
        require(success==sum(t&E==E^K for t in good),'exact deletion identity')
        events=[]
        for w in bits(V^K):
            wbit=1<<w
            surviving=[h for h in edges if h&wbit and not h&K]
            hs=[E] if E&wbit else [h for h in edges if h&wbit and h&K]
            for h in hs:
                P=h&outside; D=0
                for g in surviving:D|=g
                D &= outside&~P
                charge=P|D
                for p in bits(P):charge|=N[p]&outside
                event={y for y in Y if y&h==h and not any(g&y==g for g in surviving)}
                events.append(event)
                if eligible:
                    require(F(len(event.intersection(full)),len(full))<=F(len(event),len(Y))/W(charge),'local obstruction bound')
                    obstruction_checks+=1
        actual_bad={y for y in full if (y&~K) not in good}
        predicted=set().union(*events).intersection(full) if events else set()
        require(actual_bad==predicted,'exact obstruction union')
        if eligible:
            # Also check lopsided conditional estimate for all simultaneous avoidance sets, when small.
            if len(C)<=6 and cuts==1:
                for v in C:
                    for S in subsets(outside&~(1<<v)):
                        av=[y for y in Y if all(y not in C[w] for w in bits(S))]
                        require(bool(av),'positive avoidance')
                        require(F(sum(y in C[v] for y in av),len(av))<=a[v],'conditional LLL estimate')
                        pchecks+=1
    # Dual map via direct set of point masks for all selections.
    orig={sum(1<<i for i,e in enumerate(edges) if e&s) for s in range(1<<n)}
    require(len(orig)==len(good),'dual cardinality')
    i=edges.index(E);require(sum(not(t>>i&1) for t in orig)==len(full),'dual frequency')
    return cuts,int(eligible),pchecks,obstruction_checks

def finite_checks():
    rng=random.Random(20261125); counts=[0]*4; models=0
    # Exhaustive nonempty hypergraphs on <=3 vertices (including isolated vertices).
    for n in range(1,4):
        for hm in range(1,1<<((1<<n)-1)):
            es=[i for i in range(1,1<<n) if hm>>(i-1)&1]
            for E in es:
                z=model(n,es,E,[F(1,5)]*n);models+=1
                counts=[x+y for x,y in zip(counts,z)]
    # Random and complete uniform systems; complete systems include overlapping petals.
    for n in range(4,10):
        for trial in range(15):
            es=sorted(rng.sample(range(1,1<<n),rng.randint(1,min(30,(1<<n)-1))))
            E=rng.choice(es);z=model(n,es,E,[F(1,10)]*n);models+=1
            counts=[x+y for x,y in zip(counts,z)]
        for r in range(2,min(n,4)+1):
            es=[sum(1<<i for i in c) for c in combinations(range(n),r)]
            z=model(n,es,es[0],[F(1,20)]*n);models+=1
            counts=[x+y for x,y in zip(counts,z)]
    return dict(marked_models=models,deletion_cut_checks=counts[0],eligible_models=counts[1],conditional_avoidance_checks=counts[2],local_obstruction_checks=counts[3])

def construction_checks():
    for m in (169,170,251):
        es=[(i,m+(i+13*j)%m,2*m+(i+j)%m) for i in range(m) for j in range(13)]
        require(len(set(es))==13*m,'distinct')
        degrees=[0]*(3*m);pairs=set();adj=[set() for _ in degrees]
        for e in es:
            for x in e:degrees[x]+=1
            for x,y in combinations(e,2):
                require((x,y) not in pairs,'linear');pairs.add((x,y));adj[x].add(y);adj[y].add(x)
        require(set(degrees)=={13},'regular')
        seen={0};todo=[0]
        while todo:
            x=todo.pop()
            for y in adj[x]-seen:seen.add(y);todo.append(y)
        require(len(seen)==3*m,'connected')
        for e in es:
            E=set(e)
            for i,j in combinations(e,2):
                require(len((adj[i]|adj[j]|{i,j}))==51,'two-index neighborhood')
                require(not (adj[i]&adj[j])-E,'no Berge triangles')
            require(len(set.union(E,*(adj[i] for i in e)))==75,'full-edge neighborhood')
    return [169,170,251]

if __name__=='__main__':
    result=dict(certificates=verify_rows(),finite_checks=finite_checks(),cyclic_construction_sizes=construction_checks())
    print(json.dumps(result,indent=2))
