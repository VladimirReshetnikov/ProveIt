# Deletion certificates for abundant elements in union-closed families

Research note for ProveIt, 25 November 2026. Start with `paper.pdf`.

## Results

* In linear r-uniform d-regular support hypergraphs, every original ground point has frequency > 1/2 at d >= 13, 39, 99, 234, 536, 1197 for r = 3, 4, 5, 6, 7, 8 respectively. These improve the explicit sufficient thresholds 14, 40, 100, 237, 541, 1206 in the directly inspected lopsided-certificate draft. At r=3, d>=13 the guarantee is strictly >52%.
* An exact deletion-count identity and an asymmetric obstruction certificate for arbitrary support hypergraphs; a multiple-deletion quantitative bound.
* Explicit connected linear triple systems on 3m indices for every m>=169, with minimum original nonempty set size 13, where the preceding symmetric marked-subedge certificate fails even using exact neighborhoods.
* Exact enumeration of 2^27 vertex subsets of AG(3,3), giving 110,889,485 distinct unions and marked-point frequency 95,107,309 / 110,889,485.

The full conjecture is not proved. These are proposed original restricted-case advances relative to a specific repository antecedent; public-literature priority is not guaranteed. No proof-assistant formalization or independent peer review is claimed. The general proof is not based on exhaustive enumeration. No repository changes were made.

## Files

- `paper.tex`, `paper.pdf` — complete self-contained mathematical manuscript.
- `verify.py`, `verification.json`, `bounds.csv` — exact rational threshold certificates and finite checks; actual executed output.
- `affine27.cpp`, `affine27.txt` — independent enumeration of the 27-vertex example and its actual output.
- `provenance.md` — repository/literature audit and novelty limitations.
- `Makefile`, `SHA256SUMS` — reproducibility and integrity.

## Reproduction

Python 3.10+ (standard library), C++17 compiler (for the larger enumeration), and TeX Live with AMS, Latin Modern, microtype, booktabs, geometry and hyperref packages.

```sh
sha256sum -c SHA256SUMS
make verify
make affine
make pdf
```

`make verify` regenerates `verification.json` and `bounds.csv`. `make affine` compiles and runs the enumeration. `make pdf` compiles twice. Rebuilt PDF metadata may differ. The large enumeration uses approximately 16 MiB for its invalid-subset bitset. Table decimals are displays only; certificate decisions use exact integer or Fraction arithmetic.
