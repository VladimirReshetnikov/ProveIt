// Exact independent enumeration for the affine Steiner triple system AG(3,3).
// A subset is invalid iff some selected vertex has no complete incident line.
#include <array>
#include <cstdint>
#include <iostream>
#include <vector>
#include <stdexcept>
using U=uint32_t; using C=uint64_t;
constexpr U V=27, N=1u<<V;
std::vector<uint64_t> bad(N/64,0);
void mark(U s){bad[s>>6]|=1ull<<(s&63);}
bool good(U s){return !(bad[s>>6]>>(s&63)&1ull);}
void require(bool c){if(!c) throw std::runtime_error("check failed");}
int third(int a,int b){int x=0,p=1; for(int k=0;k<3;k++){x+=p*((6-a%3-b%3)%3);a/=3;b/=3;p*=3;}return x;}
void rec(const std::vector<std::array<U,2>>& ps, size_t i,U s){if(i==ps.size()){mark(s);return;}rec(ps,i+1,s);rec(ps,i+1,s|ps[i][0]);rec(ps,i+1,s|ps[i][1]);}
int main(){
    std::vector<U> edges;for(U a=0;a<V;a++)for(U b=a+1;b<V;b++){U c=third(a,b);if(c>b)edges.push_back((1u<<a)|(1u<<b)|(1u<<c));}
    require(edges.size()==117);
    for(U v=0;v<V;v++){
        std::vector<std::array<U,2>> ps;U seen=1u<<v;
        for(U e:edges)if(e&(1u<<v)){U p=e^(1u<<v);require(!(p&seen));seen|=p;U low=p&(-p);ps.push_back({low,p^low});}
        require(ps.size()==13 && seen==N-1);rec(ps,0,1u<<v);
    }
    U E=7;require(third(0,1)==2);std::array<C,8> count{},success{}; C total=0;
    for(U y=0;y<N;y++)if(good(y)){++total;++count[y&E];if((y&E)==E)for(U k=0;k<=E;k++)if(good(y&~k))++success[k];}
    for(U k=0;k<=E;k++)require(success[k]==count[E^k]);
    require(100*(total-count[E])>52*total);
    std::cout<<"vertices="<<V<<"\nlines="<<edges.size()<<"\nsets="<<total<<"\nmark_absent="<<count[E]<<"\nmark_present="<<total-count[E]<<"\n";
    for(U k=0;k<=E;k++)std::cout<<"deleted_mask="<<k<<" success="<<success[k]<<"\n";
}
