PRA FROM SMALL IMPLICATION TEMPLATES
Research prepared for Vladimir Reshetnikov, 1 November 2026

START HERE

  report.pdf                 Complete mathematical report.
  report.tex                 Main editable LaTeX source.
  sections/bootstrap.tex     Included arithmetic and logic-specific proof.
  AXIOMS.txt                 Complete standalone specification.

MAIN RESULT

Both theories use 0,S and binary recursion descriptions R_h. The only
axioms are 0 != S0 and a joint induction/computation schema, admitting
only templates whose modified zero substitution is literally B -> B.
The equality probe uses the seed as its own rigid reference, so every
actual axiom has at most two individual variable names.

Classical version: templates are implications between single equations.
Intuitionistic version: each side may be a disjunction of up to two equations.

Equivalent intuitionistic option: retain only the classical atomic templates
and add one explicit constructor-coverage sentence. This has a simpler
admission grammar, with partial display count 46 rather than 35. The report
proves the same-language equivalence of these two intuitionistic versions.

Each is definitionally equivalent, via a common conservative definitional
extension, to matching-logic first-order PRA. Both interpretations retain
the whole carrier and native equality; both round trips are internally
the identity, also at nonstandard elements. Equiconsistency follows.

The classical atomic-only fragment recovers positive constructor coverage
by excluded middle. The same atomic-only theory in intuitionistic logic
cannot prove native coverage; a Harrop-context disjunction-property proof
explains the local distinction. This is not a general non-bi-interpretability
claim about arbitrary alternative interpretations.

COMPARISON

All five current docs/drafts archives were reviewed at ProveIt commit:
  0bf6525f9b09421e5ffacdd5fba7648d28b7fcff

The new partial formula-schema count is 35 versus 39 for the comparable
reflexive display and 42 for the fixed two-variable fused display.
The admission test and actual substituted bodies are not charged.
Under an exposed term-placeholder convention the new counts are 83 and
147, while the older fixed-zero term basis is 60. Normalized concrete
instances can be longer. No absolute shortestness or global dominance
over all draft presentations is claimed.

The new contributions are the diagonalized initialization probe combined
with syntactic-base normalization, the restricted template grammars,
their precise classical/intuitionistic distinction, and the supporting
logical certificates. Binary recursors, arithmetic identities, and the
one-parameter pairing strategy are credited to the source drafts.

ARTIFACTS AND VERIFICATION

  formal/SubstitutedTautology.lean
      Original finite-syntax Lean 4.19.0 certificate, core Init only.
      Checks admission, both restricted grammars, initialization, computation,
      equation/clause induction, the classical negative-coverage argument,
      coverage under explicit excluded middle, and the converse reduction.
  formal/SCOPE.txt
      Exact assumptions, endpoints, and proof boundaries.
  formal/lean-toolchain
      Compiler version pin.
  checks/schema_check.py / schema_results.json
      Independent syntax, admission, variable, and size diagnostics.
  audit/
      Source provenance, mathematical reviews, compiler output, build and QA.
  build.py
      Rebuild and replay instructions implemented as a Python script.
  SHA256SUMS.txt
      Integrity hashes of all other packaged files.

The Lean certificate is not an end-to-end formalization of arithmetic,
pairing, PR compilation, or the identity bi-interpretations. These are
written internal proofs in the report. Its classical coverage theorem
has excluded middle as an explicit argument; an empty kernel-axiom list
for that theorem does not remove its explicit hypothesis.
Numerical/syntax diagnostics are not proofs about nonstandard models.

REBUILD

Python 3.10 or later and TeX Live with the packages in report.tex:

  python3 build.py
  python3 build.py --checks-only
  python3 build.py --pdf-only
  python3 build.py --lean /path/to/lean

For a direct Lean replay:
  lean formal/SubstitutedTautology.lean

Use Lean 4.19.0; no Mathlib project is required. The document build uses
no shell escape. Verify SHA256SUMS.txt before rebuilding; generated PDF
metadata and build outputs may change, so byte-identical rebuilds are
not asserted. Original comparison archives are not duplicated here.
