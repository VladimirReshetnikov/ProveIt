#!/usr/bin/env python3
"""Rebuild the report and replay its explicitly scoped checks."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(command: list[str], log: Path) -> subprocess.CompletedProcess:
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    log.write_text(result.stdout + result.stderr, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}): {command}; see {log}")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--checks-only", action="store_true")
    mode.add_argument("--pdf-only", action="store_true")
    parser.add_argument("--lean", help="Path to Lean 4.19.0 for optional certificate replay")
    args = parser.parse_args()
    audit = ROOT / "audit"
    audit.mkdir(exist_ok=True)
    previous = audit / "build_results.json"
    results = json.loads(previous.read_text()) if previous.exists() else {}

    if not args.pdf_only:
        run([sys.executable, str(ROOT / "checks/schema_check.py")],
            audit / "schema_check.log")
        results["syntax_checks"] = "passed"

    if args.lean:
        version = run([args.lean, "--version"], audit / "lean_version.txt")
        if "version 4.19.0" not in version.stdout:
            raise RuntimeError("The supplied compiler is not Lean 4.19.0")
        compiled = run([args.lean, str(ROOT / "formal/SubstitutedTautology.lean")],
                       audit / "lean_verification.log")
        if "sorryAx" in compiled.stdout or "Classical.choice" in compiled.stdout:
            raise RuntimeError("Unexpected global axiom in the printed endpoint audit")
        results["lean"] = {
            "version": version.stdout.strip(), "exit_code": compiled.returncode,
            "source_sha256": hashlib.sha256(
                (ROOT / "formal/SubstitutedTautology.lean").read_bytes()).hexdigest(),
            "scope": "finite-syntax logical kernels; classical EM is an explicit hypothesis",
        }

    if not args.checks_only:
        build = ROOT / "_build"
        build.mkdir(exist_ok=True)
        command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                   "-no-shell-escape", "-output-directory", str(build), "report.tex"]
        for number in range(1, 4):
            run(command, audit / f"latex_pass_{number}.log")
        log = (build / "report.log").read_text(errors="replace")
        bad = [line for line in log.splitlines() if
               "Overfull" in line or "undefined references" in line or
               re.search(r"(?:Reference|Citation) .* undefined", line)]
        if bad:
            raise RuntimeError("PDF diagnostics require review: " + repr(bad))
        shutil.copy2(build / "report.pdf", ROOT / "report.pdf")
        info = run(["pdfinfo", str(ROOT / "report.pdf")], audit / "pdfinfo.txt")
        match = re.search(r"^Pages:\s+(\d+)", info.stdout, re.M)
        results["pdf"] = {
            "pages": int(match.group(1)) if match else None,
            "tex_passes": 3, "overfull_boxes": 0, "unresolved_references": 0,
            "sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest(),
            "visual_review": "separate rendering and inspection; see audit/pdf_review.json",
        }
    (audit / "build_results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
