/-
Finite-syntax certificate for the substituted-tautology reduction.
Lean 4.19.0, core library only. No classical reasoning or arithmetic induction
on the model's carrier is assumed by the forward logical reduction.
-/
import Init

namespace SubstitutedTautology

universe u

inductive Term (V : Type) where
  | var : V → Term V
  | zero : Term V
  | succ : Term V → Term V
  | call : Nat → Term V → Term V → Term V
  deriving DecidableEq

inductive Formula (V : Type) where
  | equal : Term V → Term V → Formula V
  | falsity : Formula V
  | conj : Formula V → Formula V → Formula V
  | disj : Formula V → Formula V → Formula V
  | impl : Formula V → Formula V → Formula V
  deriving DecidableEq

structure Model (D : Type u) where
  zero : D
  succ : D → D
  call : Nat → D → D → D

def Term.bind {V W : Type} (σ : V → Term W) : Term V → Term W
  | .var v => σ v
  | .zero => .zero
  | .succ t => .succ (t.bind σ)
  | .call k t s => .call k (t.bind σ) (s.bind σ)

def Term.eval {V : Type} {D : Type u} (M : Model D) (ρ : V → D) : Term V → D
  | .var v => ρ v
  | .zero => M.zero
  | .succ t => M.succ (t.eval M ρ)
  | .call k t s => M.call k (t.eval M ρ) (s.eval M ρ)

theorem Term.bind_bind {V W Z : Type} (t : Term V)
    (σ : V → Term W) (τ : W → Term Z) :
    (t.bind σ).bind τ = t.bind (fun v => (σ v).bind τ) := by
  induction t <;> simp_all [Term.bind]

theorem Term.eval_bind {V W : Type} {D : Type u} (t : Term V)
    (σ : V → Term W) (M : Model D) (ρ : W → D) :
    (t.bind σ).eval M ρ = t.eval M (fun v => (σ v).eval M ρ) := by
  induction t <;> simp_all [Term.bind, Term.eval]

def Formula.bind {V W : Type} (σ : V → Term W) : Formula V → Formula W
  | .equal t s => .equal (t.bind σ) (s.bind σ)
  | .falsity => .falsity
  | .conj P Q => .conj (P.bind σ) (Q.bind σ)
  | .disj P Q => .disj (P.bind σ) (Q.bind σ)
  | .impl P Q => .impl (P.bind σ) (Q.bind σ)

def Formula.Holds {V : Type} {D : Type u} (M : Model D) (ρ : V → D) :
    Formula V → Prop
  | .equal t s => t.eval M ρ = s.eval M ρ
  | .falsity => False
  | .conj P Q => P.Holds M ρ ∧ Q.Holds M ρ
  | .disj P Q => P.Holds M ρ ∨ Q.Holds M ρ
  | .impl P Q => P.Holds M ρ → Q.Holds M ρ

theorem Formula.bind_bind {V W Z : Type} (A : Formula V)
    (σ : V → Term W) (τ : W → Term Z) :
    (A.bind σ).bind τ = A.bind (fun v => (σ v).bind τ) := by
  induction A <;> simp_all [Formula.bind, Term.bind_bind]

theorem Formula.holds_bind {V W : Type} {D : Type u} (A : Formula V)
    (σ : V → Term W) (M : Model D) (ρ : W → D) :
    (A.bind σ).Holds M ρ ↔ A.Holds M (fun v => (σ v).eval M ρ) := by
  induction A <;> simp_all [Formula.bind, Formula.Holds, Term.eval_bind]

inductive PairVar where
  | time | seed
  deriving DecidableEq

inductive TripleVar where
  | time | slot | seed
  deriving DecidableEq

inductive BodyVar where
  | counter | value
  deriving DecidableEq

def env2 {D : Type u} (n a : D) : PairVar → D
  | .time => n
  | .seed => a

def env3 {D : Type u} (n z a : D) : TripleVar → D
  | .time => n
  | .slot => z
  | .seed => a

def bodyEnv {D : Type u} (n v : D) : BodyVar → D
  | .counter => n
  | .value => v

def seedBase (k : Nat) : TripleVar → Term Unit
  | .time => .zero
  | .slot => .call k .zero (.var ())
  | .seed => .var ()

/-- Exact syntactic admission: simultaneous substitution, then identical branches. -/
def Admitted (k : Nat) (A : Formula TripleVar) : Prop :=
  ∃ B : Formula Unit, A.bind (seedBase k) = .impl B B

/-- A executable finite-syntax admission test; no proof search or normalization. -/
def admissionTest (k : Nat) (A : Formula TripleVar) : Bool :=
  match A.bind (seedBase k) with
  | .impl P Q => decide (P = Q)
  | _ => false

theorem admissionTest_correct (k : Nat) (A : Formula TripleVar) :
    admissionTest k A = true ↔ Admitted k A := by
  unfold admissionTest Admitted
  generalize A.bind (seedBase k) = C
  cases C <;> simp [eq_comm]

def BaseComp {D : Type u} (M : Model D) : Prop :=
  ∀ k a, M.call k M.zero a = a

def StepEq {D : Type u} (M : Model D) (bodies : Nat → Term BodyVar)
    (k : Nat) (n a : D) : Prop :=
  M.call k (M.succ n) a = (bodies k).eval M (bodyEnv n (M.call k n a))

def StepComp {D : Type u} (M : Model D) (bodies : Nat → Term BodyVar) : Prop :=
  ∀ k n a, StepEq M bodies k n a

def QFI1 {D : Type u} (M : Model D) : Prop :=
  ∀ (F : Formula PairVar) a,
    F.Holds M (env2 M.zero a) →
    (∀ n, F.Holds M (env2 n a) → F.Holds M (env2 (M.succ n) a)) →
    ∀ n, F.Holds M (env2 n a)

def JointKernel {D : Type u} (M : Model D) (bodies : Nat → Term BodyVar) : Prop :=
  ∀ k (A : Formula TripleVar), Admitted k A → ∀ a,
    (∀ n, A.Holds M (env3 n a a) → A.Holds M (env3 (M.succ n) a a)) →
    ∀ n, A.Holds M (env3 n a a) ∧ StepEq M bodies k n a

def Separation {D : Type u} (M : Model D) : Prop := M.zero = M.succ M.zero → False

def FullN35 {D : Type u} (M : Model D) (bodies : Nat → Term BodyVar) : Prop :=
  Separation M ∧ JointKernel M bodies

def Baseline {D : Type u} (M : Model D) (bodies : Nat → Term BodyVar) : Prop :=
  Separation M ∧ BaseComp M ∧ StepComp M bodies ∧ QFI1 M

def truthTemplate : Formula TripleVar := .impl .falsity .falsity

theorem truth_admitted (k : Nat) : Admitted k truthTemplate :=
  ⟨.falsity, rfl⟩

def initializationProbe (k : Nat) : Formula TripleVar :=
  .impl (.equal (.var .slot) (.var .seed))
    (.equal (.call k .zero (.var .seed)) (.var .seed))

theorem initialization_admitted (k : Nat) : Admitted k (initializationProbe k) :=
  ⟨.equal (.call k .zero (.var ())) (.var ()), rfl⟩

theorem joint_initialization {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : JointKernel M bodies) : BaseComp M := by
  intro k a
  have step : ∀ n, (initializationProbe k).Holds M (env3 n a a) →
      (initializationProbe k).Holds M (env3 (M.succ n) a a) := by
    intro n h
    exact h
  have result := (H k (initializationProbe k) (initialization_admitted k)
    a step M.zero).1
  exact result rfl

theorem joint_successor {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : JointKernel M bodies) :
    StepComp M bodies := by
  intro k n a
  exact (H k truthTemplate (truth_admitted k) a (by intro _ h; exact h) n).2

def normBase : PairVar → Term TripleVar
  | .time => .zero
  | .seed => .var .seed

def normRun : PairVar → Term TripleVar
  | .time => .var .time
  | .seed => .var .seed

def unitBase : PairVar → Term Unit
  | .time => .zero
  | .seed => .var ()

def normalized (F : Formula PairVar) : Formula TripleVar :=
  .impl (F.bind normBase) (F.bind normRun)

theorem normBase_seedBase (F : Formula PairVar) (k : Nat) :
    (F.bind normBase).bind (seedBase k) = F.bind unitBase := by
  rw [Formula.bind_bind]
  congr 1
  funext v
  cases v <;> rfl

theorem normRun_seedBase (F : Formula PairVar) (k : Nat) :
    (F.bind normRun).bind (seedBase k) = F.bind unitBase := by
  rw [Formula.bind_bind]
  congr 1
  funext v
  cases v <;> rfl

theorem normalized_admitted (F : Formula PairVar) (k : Nat) :
    Admitted k (normalized F) := by
  refine ⟨F.bind unitBase, ?_⟩
  change Formula.impl ((F.bind normBase).bind (seedBase k))
    ((F.bind normRun).bind (seedBase k)) = _
  rw [normBase_seedBase, normRun_seedBase]

theorem holds_normalized {D : Type u} (M : Model D) (F : Formula PairVar)
    (n z a : D) :
    (normalized F).Holds M (env3 n z a) ↔
      (F.Holds M (env2 M.zero a) → F.Holds M (env2 n a)) := by
  change ((F.bind normBase).Holds M (env3 n z a) →
    (F.bind normRun).Holds M (env3 n z a)) ↔ _
  rw [Formula.holds_bind, Formula.holds_bind]
  have hb : (fun v => (normBase v).eval M (env3 n z a)) = env2 M.zero a := by
    funext v
    cases v <;> rfl
  have hr : (fun v => (normRun v).eval M (env3 n z a)) = env2 n a := by
    funext v
    cases v <;> rfl
  rw [hb, hr]

theorem joint_induction {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : JointKernel M bodies) : QFI1 M := by
  intro F a base progress n
  have normalizedProgress : ∀ m, (normalized F).Holds M (env3 m a a) →
      (normalized F).Holds M (env3 (M.succ m) a a) := by
    intro m hm
    apply (holds_normalized M F (M.succ m) a a).2
    intro h0
    exact progress m ((holds_normalized M F m a a).1 hm h0)
  have hn := (H 0 (normalized F) (normalized_admitted F 0)
    a normalizedProgress n).1
  exact (holds_normalized M F n a a).1 hn base

def diagonal : TripleVar → Term PairVar
  | .time => .var .time
  | .slot => .var .seed
  | .seed => .var .seed

theorem holds_diagonal {D : Type u} (M : Model D) (A : Formula TripleVar)
    (n a : D) :
    (A.bind diagonal).Holds M (env2 n a) ↔ A.Holds M (env3 n a a) := by
  rw [Formula.holds_bind]
  have he : (fun v => (diagonal v).eval M (env2 n a)) = env3 n a a := by
    funext v
    cases v <;> rfl
  rw [he]

theorem admitted_base {D : Type u} {M : Model D} (initial : BaseComp M)
    {k : Nat} {A : Formula TripleVar} (admission : Admitted k A) (a : D) :
    A.Holds M (env3 M.zero a a) := by
  rcases admission with ⟨B, hb⟩
  have syntactic : (A.bind (seedBase k)).Holds M (fun _ => a) := by
    rw [hb]
    exact fun h => h
  have transformed := (Formula.holds_bind A (seedBase k) M (fun _ => a)).1 syntactic
  have he : (fun v => (seedBase k v).eval M (fun _ => a)) =
      env3 M.zero a a := by
    funext v
    cases v with
    | time => rfl
    | slot => exact initial k a
    | seed => rfl
  rw [he] at transformed
  exact transformed

theorem baseline_joint {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (initial : BaseComp M)
    (successor : StepComp M bodies) (induction : QFI1 M) :
    JointKernel M bodies := by
  intro k A admission a progress n
  have diagBase : (A.bind diagonal).Holds M (env2 M.zero a) :=
    (holds_diagonal M A M.zero a).2 (admitted_base initial admission a)
  have diagStep : ∀ m, (A.bind diagonal).Holds M (env2 m a) →
      (A.bind diagonal).Holds M (env2 (M.succ m) a) := by
    intro m hm
    exact (holds_diagonal M A (M.succ m) a).2
      (progress m ((holds_diagonal M A m a).1 hm))
  exact ⟨(holds_diagonal M A n a).1
    (induction (A.bind diagonal) a diagBase diagStep n), successor k n a⟩

theorem fullN35_iff_baseline {D : Type u} (M : Model D)
    (bodies : Nat → Term BodyVar) : FullN35 M bodies ↔ Baseline M bodies := by
  constructor
  · intro H
    exact ⟨H.1, joint_initialization H.2, joint_successor H.2, joint_induction H.2⟩
  · intro H
    exact ⟨H.1, baseline_joint H.2.1 H.2.2.1 H.2.2.2⟩

/-
The main presentation restricts each side of A = P → Q to one equation
or the disjunction of two equations. The empty clause is NOT admitted.
The unrestricted equivalence above is a separate intermediate certificate.
-/

inductive Clause {V : Type} : Formula V → Prop where
  | atom (t s : Term V) : Clause (.equal t s)
  | pair (t s u v : Term V) : Clause (.disj (.equal t s) (.equal u v))

inductive SmallTemplate : Formula TripleVar → Prop where
  | mk {P Q : Formula TripleVar} : Clause P → Clause Q →
      SmallTemplate (.impl P Q)

theorem clause_bind {V W : Type} {F : Formula V} (H : Clause F)
    (σ : V → Term W) : Clause (F.bind σ) := by
  cases H with
  | atom t s => exact .atom (t.bind σ) (s.bind σ)
  | pair t s u v => exact .pair (t.bind σ) (s.bind σ) (u.bind σ) (v.bind σ)

def equationTest {V : Type} : Formula V → Bool
  | .equal _ _ => true
  | _ => false

def clauseTest {V : Type} : Formula V → Bool
  | .equal _ _ => true
  | .disj P Q => equationTest P && equationTest Q
  | _ => false

theorem clauseTest_correct {V : Type} (F : Formula V) :
    clauseTest F = true ↔ Clause F := by
  constructor
  · intro h
    cases F with
    | equal t s => exact .atom t s
    | falsity => contradiction
    | conj P Q => contradiction
    | impl P Q => contradiction
    | disj P Q =>
      cases P <;> cases Q <;> simp_all [clauseTest, equationTest]
      exact .pair _ _ _ _
  · intro h
    cases h <;> rfl

def smallTemplateTest : Formula TripleVar → Bool
  | .impl P Q => clauseTest P && clauseTest Q
  | _ => false

def RestrictedAdmitted (k : Nat) (A : Formula TripleVar) : Prop :=
  SmallTemplate A ∧ Admitted k A

def restrictedAdmissionTest (k : Nat) (A : Formula TripleVar) : Bool :=
  smallTemplateTest A && admissionTest k A

theorem smallTemplateTest_correct (A : Formula TripleVar) :
    smallTemplateTest A = true ↔ SmallTemplate A := by
  constructor
  · intro h
    cases A with
    | equal t s => contradiction
    | falsity => contradiction
    | conj P Q => contradiction
    | disj P Q => contradiction
    | impl P Q =>
      have hc : clauseTest P = true ∧ clauseTest Q = true := by
        simpa only [smallTemplateTest, Bool.and_eq_true] using h
      exact .mk ((clauseTest_correct P).1 hc.1) ((clauseTest_correct Q).1 hc.2)
  · intro h
    cases h with
    | mk hp hq =>
      cases hp <;> cases hq <;> rfl

theorem restrictedAdmissionTest_correct (k : Nat) (A : Formula TripleVar) :
    restrictedAdmissionTest k A = true ↔ RestrictedAdmitted k A := by
  simp only [restrictedAdmissionTest, Bool.and_eq_true,
    smallTemplateTest_correct, admissionTest_correct, RestrictedAdmitted]

def SmallJointKernel {D : Type u} (M : Model D)
    (bodies : Nat → Term BodyVar) : Prop :=
  ∀ k (A : Formula TripleVar), RestrictedAdmitted k A → ∀ a,
    (∀ n, A.Holds M (env3 n a a) → A.Holds M (env3 (M.succ n) a a)) →
    ∀ n, A.Holds M (env3 n a a) ∧ StepEq M bodies k n a

def N35 {D : Type u} (M : Model D) (bodies : Nat → Term BodyVar) : Prop :=
  Separation M ∧ SmallJointKernel M bodies

def ClauseInduction {D : Type u} (M : Model D) : Prop :=
  ∀ (F : Formula PairVar), Clause F → ∀ a,
    F.Holds M (env2 M.zero a) →
    (∀ n, F.Holds M (env2 n a) → F.Holds M (env2 (M.succ n) a)) →
    ∀ n, F.Holds M (env2 n a)

def EquationInduction {D : Type u} (M : Model D) : Prop :=
  ∀ (t s : Term PairVar) a,
    t.eval M (env2 M.zero a) = s.eval M (env2 M.zero a) →
    (∀ n, t.eval M (env2 n a) = s.eval M (env2 n a) →
      t.eval M (env2 (M.succ n) a) = s.eval M (env2 (M.succ n) a)) →
    ∀ n, t.eval M (env2 n a) = s.eval M (env2 n a)

theorem initialization_small (k : Nat) : SmallTemplate (initializationProbe k) :=
  .mk (.atom _ _) (.atom _ _)

def smallTruth : Formula TripleVar := .impl (.equal .zero .zero) (.equal .zero .zero)

theorem smallTruth_admitted (k : Nat) : RestrictedAdmitted k smallTruth :=
  ⟨.mk (.atom _ _) (.atom _ _), ⟨.equal .zero .zero, rfl⟩⟩

theorem small_initialization {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : SmallJointKernel M bodies) : BaseComp M := by
  intro k a
  have result := (H k (initializationProbe k)
    ⟨initialization_small k, initialization_admitted k⟩
    a (by intro _ h; exact h) M.zero).1
  exact result rfl

theorem small_successor {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : SmallJointKernel M bodies) :
    StepComp M bodies := by
  intro k n a
  exact (H k smallTruth (smallTruth_admitted k) a (by intro _ h; exact h) n).2

theorem normalized_small {F : Formula PairVar} (clause : Clause F) :
    SmallTemplate (normalized F) :=
  .mk (clause_bind clause normBase) (clause_bind clause normRun)

theorem small_clauseInduction {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : SmallJointKernel M bodies) :
    ClauseInduction M := by
  intro F clause a base progress n
  have normalizedProgress : ∀ m, (normalized F).Holds M (env3 m a a) →
      (normalized F).Holds M (env3 (M.succ m) a a) := by
    intro m hm
    apply (holds_normalized M F (M.succ m) a a).2
    intro h0
    exact progress m ((holds_normalized M F m a a).1 hm h0)
  have hn := (H 0 (normalized F) ⟨normalized_small clause, normalized_admitted F 0⟩
    a normalizedProgress n).1
  exact (holds_normalized M F n a a).1 hn base

theorem small_equationInduction {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : SmallJointKernel M bodies) :
    EquationInduction M := by
  intro t s a base progress n
  exact small_clauseInduction H (.equal t s) (.atom t s) a base progress n

def coverageMatrix (p : Nat) : Formula PairVar :=
  .disj (.equal (.var .time) .zero)
    (.equal (.var .time) (.succ (.call p (.var .time) .zero)))

theorem small_coverage {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : SmallJointKernel M bodies)
    (p : Nat) (bodyIsCounter : bodies p = .var .counter) (n : D) :
    n = M.zero ∨ n = M.succ (M.call p n M.zero) := by
  have base : (coverageMatrix p).Holds M (env2 M.zero M.zero) := Or.inl rfl
  have progress : ∀ m, (coverageMatrix p).Holds M (env2 m M.zero) →
      (coverageMatrix p).Holds M (env2 (M.succ m) M.zero) := by
    intro m _
    have predSucc := small_successor H p m M.zero
    unfold StepEq at predSucc
    rw [bodyIsCounter] at predSucc
    exact Or.inr (congrArg M.succ predSucc.symm)
  exact small_clauseInduction H (coverageMatrix p) (.pair _ _ _ _)
    M.zero base progress n

theorem n35_extracts_kernel {D : Type u} (M : Model D)
    (bodies : Nat → Term BodyVar) (H : N35 M bodies) :
    Separation M ∧ BaseComp M ∧ StepComp M bodies ∧
      ClauseInduction M ∧ EquationInduction M :=
  ⟨H.1, small_initialization H.2, small_successor H.2,
    small_clauseInduction H.2, small_equationInduction H.2⟩

theorem baseline_implies_n35 {D : Type u} (M : Model D)
    (bodies : Nat → Term BodyVar) (H : Baseline M bodies) : N35 M bodies := by
  refine ⟨H.1, ?_⟩
  intro k A admission a progress n
  exact baseline_joint H.2.1 H.2.2.1 H.2.2.2 k A admission.2 a progress n

/-
Classical refinement: each side of the template is now ONE equation.
All proofs remain constructive except that the final coverage theorem takes
excluded middle as an EXPLICIT HYPOTHESIS. No global Classical declaration
or Classical.choice is used.
-/

inductive AtomicTemplate : Formula TripleVar → Prop where
  | mk (t s u v : Term TripleVar) :
      AtomicTemplate (.impl (.equal t s) (.equal u v))

def atomicTemplateTest : Formula TripleVar → Bool
  | .impl P Q => equationTest P && equationTest Q
  | _ => false

theorem atomicTemplateTest_correct (A : Formula TripleVar) :
    atomicTemplateTest A = true ↔ AtomicTemplate A := by
  constructor
  · intro h
    cases A with
    | equal t s => contradiction
    | falsity => contradiction
    | conj P Q => contradiction
    | disj P Q => contradiction
    | impl P Q =>
      cases P <;> cases Q <;> simp_all [atomicTemplateTest, equationTest]
      exact .mk _ _ _ _
  · intro h
    cases h <;> rfl

def AtomicAdmitted (k : Nat) (A : Formula TripleVar) : Prop :=
  AtomicTemplate A ∧ Admitted k A

def atomicAdmissionTest (k : Nat) (A : Formula TripleVar) : Bool :=
  atomicTemplateTest A && admissionTest k A

theorem atomicAdmissionTest_correct (k : Nat) (A : Formula TripleVar) :
    atomicAdmissionTest k A = true ↔ AtomicAdmitted k A := by
  simp only [atomicAdmissionTest, Bool.and_eq_true,
    atomicTemplateTest_correct, admissionTest_correct, AtomicAdmitted]

def AtomicJointKernel {D : Type u} (M : Model D)
    (bodies : Nat → Term BodyVar) : Prop :=
  ∀ k (A : Formula TripleVar), AtomicAdmitted k A → ∀ a,
    (∀ n, A.Holds M (env3 n a a) → A.Holds M (env3 (M.succ n) a a)) →
    ∀ n, A.Holds M (env3 n a a) ∧ StepEq M bodies k n a

def AtomicN35 {D : Type u} (M : Model D) (bodies : Nat → Term BodyVar) : Prop :=
  Separation M ∧ AtomicJointKernel M bodies

theorem atomic_initialization {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : AtomicJointKernel M bodies) :
    BaseComp M := by
  intro k a
  have result := (H k (initializationProbe k)
    ⟨.mk _ _ _ _, initialization_admitted k⟩
    a (by intro _ h; exact h) M.zero).1
  exact result rfl

theorem atomic_successor {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : AtomicJointKernel M bodies) :
    StepComp M bodies := by
  intro k n a
  exact (H k smallTruth ⟨.mk _ _ _ _, (smallTruth_admitted k).2⟩
    a (by intro _ h; exact h) n).2

theorem atomic_equationInduction {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : AtomicJointKernel M bodies) :
    EquationInduction M := by
  intro t s a base progress n
  let F : Formula PairVar := .equal t s
  have normalizedProgress : ∀ m, (normalized F).Holds M (env3 m a a) →
      (normalized F).Holds M (env3 (M.succ m) a a) := by
    intro m hm
    apply (holds_normalized M F (M.succ m) a a).2
    intro h0
    exact progress m ((holds_normalized M F m a a).1 hm h0)
  have hn := (H 0 (normalized F)
    ⟨.mk _ _ _ _, normalized_admitted F 0⟩
    a normalizedProgress n).1
  exact (holds_normalized M F n a a).1 hn base

def weakCoverageTemplate : Formula TripleVar :=
  .impl (.equal (.var .time) (.var .seed)) (.equal .zero (.var .seed))

theorem weakCoverage_admitted (k : Nat) : AtomicAdmitted k weakCoverageTemplate :=
  ⟨.mk _ _ _ _, ⟨.equal .zero (.var ()), rfl⟩⟩

theorem atomic_weakCoverage {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : AtomicJointKernel M bodies)
    (p : Nat) (bodyIsCounter : bodies p = .var .counter) (a : D)
    (notSelf : ¬ a = M.succ (M.call p a M.zero)) : a = M.zero := by
  have progress : ∀ m, weakCoverageTemplate.Holds M (env3 m a a) →
      weakCoverageTemplate.Holds M (env3 (M.succ m) a a) := by
    intro m _
    change M.succ m = a → M.zero = a
    intro hm
    have predSucc := atomic_successor H p m M.zero
    unfold StepEq at predSucc
    rw [bodyIsCounter] at predSucc
    have predecessor : M.call p a M.zero = m := by
      rw [← hm]
      exact predSucc
    have self : a = M.succ (M.call p a M.zero) := by
      rw [predecessor]
      exact hm.symm
    exact False.elim (notSelf self)
  have atSeed := (H p weakCoverageTemplate (weakCoverage_admitted p)
    a progress a).1
  exact (atSeed rfl).symm

theorem atomic_coverage_of_decision {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : AtomicJointKernel M bodies)
    (p : Nat) (bodyIsCounter : bodies p = .var .counter) (a : D)
    (decision : (a = M.succ (M.call p a M.zero)) ∨
      ¬ (a = M.succ (M.call p a M.zero))) :
    a = M.zero ∨ a = M.succ (M.call p a M.zero) := by
  cases decision with
  | inl yes => exact Or.inr yes
  | inr no => exact Or.inl (atomic_weakCoverage H p bodyIsCounter a no)

/-- Classical logic is supplied explicitly; the surrounding file stays constructive. -/
theorem atomic_classicalCoverage {D : Type u} {M : Model D}
    {bodies : Nat → Term BodyVar} (H : AtomicJointKernel M bodies)
    (p : Nat) (bodyIsCounter : bodies p = .var .counter)
    (excludedMiddle : ∀ P : Prop, P ∨ ¬ P) (a : D) :
    a = M.zero ∨ a = M.succ (M.call p a M.zero) :=
  atomic_coverage_of_decision H p bodyIsCounter a (excludedMiddle _)

theorem atomicN35_extracts_kernel {D : Type u} (M : Model D)
    (bodies : Nat → Term BodyVar) (H : AtomicN35 M bodies) :
    Separation M ∧ BaseComp M ∧ StepComp M bodies ∧ EquationInduction M :=
  ⟨H.1, atomic_initialization H.2, atomic_successor H.2, atomic_equationInduction H.2⟩

theorem baseline_implies_atomicN35 {D : Type u} (M : Model D)
    (bodies : Nat → Term BodyVar) (H : Baseline M bodies) : AtomicN35 M bodies := by
  refine ⟨H.1, ?_⟩
  intro k A admission a progress n
  exact baseline_joint H.2.1 H.2.2.1 H.2.2.2 k A admission.2 a progress n

#print axioms admissionTest_correct
#print axioms restrictedAdmissionTest_correct
#print axioms joint_initialization
#print axioms joint_successor
#print axioms joint_induction
#print axioms baseline_joint
#print axioms fullN35_iff_baseline
#print axioms small_initialization
#print axioms small_successor
#print axioms small_clauseInduction
#print axioms small_equationInduction
#print axioms small_coverage
#print axioms n35_extracts_kernel
#print axioms baseline_implies_n35
#print axioms atomicAdmissionTest_correct
#print axioms atomic_initialization
#print axioms atomic_successor
#print axioms atomic_equationInduction
#print axioms atomic_weakCoverage
#print axioms atomic_coverage_of_decision
#print axioms atomic_classicalCoverage
#print axioms atomicN35_extracts_kernel
#print axioms baseline_implies_atomicN35

end SubstitutedTautology
