#!/usr/bin/env python3
"""Finite-syntax diagnostics for the substituted-tautology PRA presentation.

This checks syntax, simultaneous capture-avoiding substitution, the exact
restricted admission test, and reproducible size ledgers.  It is not a proof
checker for first-order logic, arithmetic, or the bi-interpretation theorem.
The mathematical proof and the independent written audit supply those layers.

Run from any working directory: python3 /path/to/schema_check.py
The result is written beside this file as schema_results.json.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json


@dataclass(frozen=True)
class Term:
    tag: str
    name: str = ""
    args: tuple[Term, ...] = ()

    def __post_init__(self):
        if self.tag == "var":
            assert self.name and not self.args
        else:
            assert self.tag == "fun" and self.name

    @property
    def size(self) -> int:
        return 1 + sum(t.size for t in self.args)

    @property
    def free(self) -> frozenset[str]:
        if self.tag == "var":
            return frozenset((self.name,))
        return frozenset().union(*(t.free for t in self.args))

    def occurrences(self, name: str) -> int:
        if self.tag == "var":
            return int(self.name == name)
        return sum(t.occurrences(name) for t in self.args)

    def substitute(self, env: dict[str, Term]) -> Term:
        # Deliberately do not substitute recursively into a replacement.
        if self.tag == "var":
            return env.get(self.name, self)
        return Term("fun", self.name, tuple(t.substitute(env) for t in self.args))

    def render(self) -> str:
        if self.tag == "var" or not self.args:
            return self.name
        return self.name + "(" + ",".join(t.render() for t in self.args) + ")"


def V(name: str) -> Term:
    return Term("var", name)


def F(name: str, *args: Term) -> Term:
    return Term("fun", name, args)


ZERO = F("0")


def S(t: Term) -> Term:
    return F("S", t)


def R(t: Term, a: Term) -> Term:
    return F("R_h", t, a)


@dataclass(frozen=True)
class Formula:
    tag: str
    terms: tuple[Term, ...] = ()
    children: tuple[Formula, ...] = ()
    name: str = ""

    def __post_init__(self):
        if self.tag == "eq":
            assert len(self.terms) == 2 and not self.children and not self.name
        elif self.tag == "bottom":
            assert not self.terms and not self.children and not self.name
        elif self.tag in ("and", "or", "implies"):
            assert not self.terms and len(self.children) == 2 and not self.name
        elif self.tag == "forall":
            assert not self.terms and len(self.children) == 1 and self.name
        elif self.tag == "placeholder":
            # Used only for the separately labelled partial display ledger.
            assert not self.children and self.name
        else:
            raise ValueError(self.tag)

    @property
    def size(self) -> int:
        # A binder name is a label, not an additional variable occurrence.
        return 1 + sum(t.size for t in self.terms) + sum(c.size for c in self.children)

    @property
    def free(self) -> frozenset[str]:
        result = frozenset().union(*(t.free for t in self.terms))
        result |= frozenset().union(*(c.free for c in self.children))
        return result - {self.name} if self.tag == "forall" else result

    def occurrences(self, name: str) -> int:
        if self.tag == "forall" and self.name == name:
            return 0
        return sum(t.occurrences(name) for t in self.terms) + sum(
            c.occurrences(name) for c in self.children
        )

    def substitute(self, env: dict[str, Term]) -> Formula:
        if self.tag == "forall":
            active = {k: v for k, v in env.items() if k != self.name}
            body = self.children[0]
            replacement_free = frozenset().union(*(t.free for t in active.values()))
            bound = self.name
            if bound in replacement_free and body.free.intersection(active):
                forbidden = body.free | replacement_free | frozenset(active) | {bound}
                index = 0
                fresh = "fresh_0"
                while fresh in forbidden:
                    index += 1
                    fresh = "fresh_" + str(index)
                body = body.substitute({bound: V(fresh)})
                bound = fresh
            return All(bound, body.substitute(active))
        return Formula(
            self.tag,
            tuple(t.substitute(env) for t in self.terms),
            tuple(c.substitute(env) for c in self.children),
            self.name,
        )

    def render(self) -> str:
        if self.tag == "eq":
            return self.terms[0].render() + "=" + self.terms[1].render()
        if self.tag == "bottom":
            return "false"
        if self.tag == "forall":
            return "forall " + self.name + ".(" + self.children[0].render() + ")"
        if self.tag == "placeholder":
            return self.name + "(" + ",".join(t.render() for t in self.terms) + ")"
        token = {"and": " & ", "or": " | ", "implies": " -> "}[self.tag]
        return "(" + self.children[0].render() + token + self.children[1].render() + ")"


def Eq(s: Term, t: Term) -> Formula:
    return Formula("eq", (s, t))


def Bottom() -> Formula:
    return Formula("bottom")


def And(p: Formula, q: Formula) -> Formula:
    return Formula("and", children=(p, q))


def Or(p: Formula, q: Formula) -> Formula:
    return Formula("or", children=(p, q))


def Imp(p: Formula, q: Formula) -> Formula:
    return Formula("implies", children=(p, q))


def All(name: str, p: Formula) -> Formula:
    return Formula("forall", children=(p,), name=name)


def Placeholder(name: str, *terms: Term) -> Formula:
    return Formula("placeholder", terms=terms, name=name)


def is_clause(p: Formula) -> bool:
    """Exactly one equation, or the binary disjunction of two equations."""
    return p.tag == "eq" or (
        p.tag == "or" and all(c.tag == "eq" for c in p.children)
    )


def in_binary_signature(t: Term) -> bool:
    """Validate arity in a supplied 0,S,binary-symbol signature.

    Function-symbol identities stand for already resolved descriptions; their
    well-founded dependency certificates are outside this syntax diagnostic.
    """
    if t.tag == "var":
        return True
    expected = 0 if t.name == "0" else 1 if t.name == "S" else 2
    return len(t.args) == expected and all(in_binary_signature(a) for a in t.args)


def formula_terms_valid(p: Formula) -> bool:
    return all(in_binary_signature(t) for t in p.terms) and all(
        formula_terms_valid(c) for c in p.children
    )


def transported(p: Formula) -> Formula:
    return p.substitute({"x": ZERO, "z": R(ZERO, V("w"))})


def admitted(p: Formula) -> bool:
    if p.tag != "implies" or not p.free <= {"x", "z", "w"}:
        return False
    if not all(is_clause(c) for c in p.children):
        return False
    if not formula_terms_valid(p):
        return False
    base = transported(p)
    return base.children[0] == base.children[1]


def admitted_atomic(p: Formula) -> bool:
    """The stricter classical presentation: both clauses are single equations."""
    return admitted(p) and all(c.tag == "eq" for c in p.children)


def is_harrop(p: Formula) -> bool:
    """Syntactic Harrop classification, not a proof of the relative DP theorem."""
    if p.tag in ("eq", "bottom"):
        return True
    if p.tag in ("and", "forall"):
        return all(is_harrop(c) for c in p.children)
    if p.tag == "implies":
        return is_harrop(p.children[1])
    return False


def eq_computation(body: Term | None = None) -> Formula:
    """With body=None, h is an opaque application for the partial ledger only."""
    n, a = V("n"), V("a")
    update = F("h", n, R(n, a)) if body is None else body.substitute(
        {"u": n, "v": R(n, a)}
    )
    return Eq(R(S(n), a), update)


def joint(p: Formula, body: Term | None = None) -> Formula:
    n, a = V("n"), V("a")
    pn = p.substitute({"x": n, "z": a, "w": a})
    ps = p.substitute({"x": S(n), "z": a, "w": a})
    return All("a", Imp(All("n", Imp(pn, ps)), All("n", And(pn, eq_computation(body)))))


SEP = Imp(Eq(ZERO, S(ZERO)), Bottom())
R0 = All("a", Eq(R(ZERO, V("a")), V("a")))


def normalized(f: Formula) -> Formula:
    return Imp(f.substitute({"x": ZERO}), f)


def fused(f: Formula) -> Formula:
    n, a = V("n"), V("a")
    f0 = f.substitute({"x": ZERO, "w": a})
    fn = f.substitute({"x": n, "w": a})
    fs = f.substitute({"x": S(n), "w": a})
    return All("a", Imp(And(Or(f0, Eq(ZERO, S(ZERO))), All("n", Imp(fn, fs))), All("n", fn)))


def partial_ledger() -> dict[str, int]:
    n, a, c = V("n"), V("a"), V("c")
    rs = All("n", All("a", eq_computation()))
    f = Placeholder("F", V("x"), V("w"))
    ni = All("c", Imp(
        All("n", Imp(Placeholder("F", n, c), Placeholder("F", S(n), c))),
        All("n", Placeholder("F", n, c)),
    ))
    template = Placeholder("A", V("x"), V("z"), V("w"))
    an = Placeholder("A", n, a, a)
    asn = Placeholder("A", S(n), a, a)
    a0 = Placeholder("A", ZERO, R(ZERO, a), a)
    diagonal = All("a", Imp(
        And(Or(a0, Eq(ZERO, S(ZERO))), All("n", Imp(an, asn))),
        All("n", And(an, eq_computation())),
    ))
    result = {
        "initialization_template": R0.size,
        "successor_template": rs.size,
        "separation_with_negation_expanded": SEP.size,
        "new_joint_template": joint(template).size,
        "new_joint_plus_separation": joint(template).size + SEP.size,
        "unrestricted_diagonal_joint": diagonal.size,
        "existing_reflexive_one_parameter_total": R0.size + rs.size + SEP.size + ni.size,
        "existing_fused_one_parameter_total": R0.size + rs.size + fused(f).size,
    }
    assert result == {
        "initialization_template": 6,
        "successor_template": 12,
        "separation_with_negation_expanded": 6,
        "new_joint_template": 29,
        "new_joint_plus_separation": 35,
        "unrestricted_diagonal_joint": 41,
        "existing_reflexive_one_parameter_total": 39,
        "existing_fused_one_parameter_total": 42,
    }
    return result


def term_placeholder_ledger() -> dict:
    """Expose the matrix connectives instead of hiding them inside opaque A.

    The s,t,... heads in this ledger are schematic TERM CONTEXTS, not new
    ternary function symbols of the arithmetic language.  Their displayed
    argument counts are three for the new template interface and two for Z2.
    The update h remains a two-argument schematic term context in both.
    """
    x, z, w, n, c = map(V, ("x", "z", "w", "n", "c"))
    holes = [F("term_" + name, x, z, w) for name in "stuvabcd"]
    equations = [Eq(holes[i], holes[i + 1]) for i in range(0, 8, 2)]
    atomic = Imp(equations[0], equations[1])
    two_clause = Imp(Or(equations[0], equations[1]), Or(equations[2], equations[3]))

    def old_equation(t: Term) -> Formula:
        return Eq(F("term_s", t, c), F("term_t", t, c))

    zero_exception = Or(Eq(n, ZERO), old_equation(n))
    z2 = All("c", Imp(
        All("n", Imp(zero_exception, old_equation(S(n)))),
        All("n", zero_exception),
    ))
    rs = All("n", All("a", eq_computation()))
    counts = {
        "new_classical_matrix_nodes": atomic.size,
        "new_classical_counter_occurrences": atomic.occurrences("x"),
        "new_classical_joint_plus_separation": joint(atomic).size + SEP.size,
        "new_intuitionistic_maximum_matrix_nodes": two_clause.size,
        "new_intuitionistic_maximum_counter_occurrences": two_clause.occurrences("x"),
        "new_intuitionistic_maximum_joint_plus_separation": joint(two_clause).size + SEP.size,
        "existing_Z2_fixed_zero_schema": z2.size,
        "existing_Z2_with_computation_and_separation": R0.size + rs.size + SEP.size + z2.size,
    }
    assert counts == {
        "new_classical_matrix_nodes": 19,
        "new_classical_counter_occurrences": 4,
        "new_classical_joint_plus_separation": 83,
        "new_intuitionistic_maximum_matrix_nodes": 39,
        "new_intuitionistic_maximum_counter_occurrences": 8,
        "new_intuitionistic_maximum_joint_plus_separation": 147,
        "existing_Z2_fixed_zero_schema": 36,
        "existing_Z2_with_computation_and_separation": 60,
    }
    return {
        "counts": counts,
        "new_term_context_interface": ["x", "z", "w"],
        "old_Z2_term_context_interface": ["n", "c"],
        "basis_assumptions": [
            "One node per occurrence, all universal closures counted, no shared-subexpression credit",
            "Negation expanded as implication to falsity; separation costs 6",
            "Term-context applications include all displayed individual arguments",
            "Term contexts are metasyntactic placeholders, not additional primitive function symbols",
            "The update h is a two-argument term placeholder in every compared successor equation",
            "Z2 includes separate R0, RS, and separation, totaling 24 before its 36-node induction schema",
            "New joint theories have no separate computation axioms, but include their 6-node separation",
            "Intuitionistic figure 147 is the largest allowed two-equation-clause shape, not the size of every instance",
        ],
        "warning": "The opaque-A count 35 does not dominate the older term-only Z2 count 60 under this term-placeholder metric: the corresponding new counts are 83 and at most 147. Neither ledger measures a complete axiom-enumerator encoding or all expanded concrete instances.",
    }


def finite_terms(max_size: int) -> list[Term]:
    """All terms up to max_size in the small signature 0,z,S,R_h."""
    by_size: dict[int, list[Term]] = {1: [ZERO, V("z")]}
    for size in range(2, max_size + 1):
        terms = [S(t) for t in by_size[size - 1]]
        for left in range(1, size - 1):
            right = size - 1 - left
            terms.extend(R(s, t) for s in by_size[left] for t in by_size[right])
        by_size[size] = terms
    return [t for size in range(1, max_size + 1) for t in by_size[size]]


def restore_anchor_term(t: Term) -> Term:
    """Left inverse on images of z -> R_h(0,w), with w fresh in the source."""
    if t == R(ZERO, V("w")):
        return V("z")
    if t.tag == "var":
        return t
    return F(t.name, *(restore_anchor_term(a) for a in t.args))


def run() -> dict:
    x, z, w, u, v = map(V, ("x", "z", "w", "u", "v"))
    predecessor = lambda t: F("R_counter", t, ZERO)
    cover = Or(Eq(x, ZERO), Eq(x, S(predecessor(x))))
    equation = Eq(F("R_prior", x, w), F("R_prior", S(x), w))
    probes = {
        "successor_computation": Imp(Eq(ZERO, ZERO), Eq(ZERO, ZERO)),
        "initialization": Imp(Eq(z, w), Eq(R(ZERO, w), w)),
        "equation_induction": normalized(equation),
        "constructor_coverage": normalized(cover),
    }
    probe_results = {}
    for name, p in probes.items():
        assert admitted(p)
        actual = joint(p, u)
        assert not actual.free
        assert set(collect_variable_names(actual)) <= {"n", "a"}
        probe_results[name] = {
            "admitted": True,
            "template": p.render(),
            "transported_base": transported(p).render(),
            "diagonal": p.substitute({"x": V("n"), "z": V("a"), "w": V("a")}).render(),
            "template_size": p.size,
            "individual_variables_in_closed_instance": sorted(set(collect_variable_names(actual))),
        }

    atomic_cover = Imp(Eq(x, w), Eq(ZERO, w))
    assert admitted_atomic(atomic_cover)
    atomic_probes = {
        name: admitted_atomic(p) for name, p in probes.items()
    }
    assert atomic_probes == {
        "successor_computation": True,
        "initialization": True,
        "equation_induction": True,
        "constructor_coverage": False,
    }
    atomic_probes["classical_coverage_probe"] = admitted_atomic(atomic_cover)
    assert is_harrop(SEP)
    assert all(
        is_harrop(joint(p, u))
        for p in [*list(probes.values())[:3], atomic_cover]
    )
    assert not is_harrop(joint(probes["constructor_coverage"], u))

    negatives = {
        "falsity_not_a_clause": Imp(Bottom(), Bottom()),
        "atomic_formula_not_an_implication": Eq(z, R(ZERO, w)),
        "unequal_transported_branches": Imp(Eq(z, w), Eq(ZERO, ZERO)),
        "third_disjunct_forbidden": Imp(Or(cover, Eq(w, w)), Or(cover, Eq(w, w))),
        "conjunction_forbidden": Imp(And(Eq(x, x), Eq(w, w)), And(Eq(x, x), Eq(w, w))),
        "extra_free_variable": Imp(Eq(V("b"), V("b")), Eq(V("b"), V("b"))),
        "ternary_primitive_forbidden": Imp(Eq(F("bad", x, z, w), ZERO), Eq(F("bad", x, z, w), ZERO)),
    }
    assert all(not admitted(p) for p in negatives.values())

    # A direct simultaneous-substitution check: inserted w must stay w.
    t = F("R_prior", z, w)
    simultaneous = t.substitute({"z": R(ZERO, w), "w": ZERO})
    assert simultaneous == F("R_prior", R(ZERO, w), ZERO)
    captured = All("w", Eq(z, w)).substitute({"z": w})
    assert captured.free == {"w"}
    assert captured.name != "w"
    assert captured.children[0] == Eq(w, V(captured.name))
    shadowed = All("w", Eq(z, w)).substitute({"w": ZERO})
    assert shadowed == All("w", Eq(z, w))

    bodies = {
        "counter": u,
        "successor_state": S(v),
        "earlier_counter_recursion": F("R_counter", u, S(v)),
        "duplicated_state": F("R_successor_state", v, v),
    }
    matrices = [
        Eq(x, w),
        Eq(S(x), F("R_prior", x, w)),
        Eq(F("R_prior", x, x), F("R_prior", S(x), w)),
        cover,
    ]
    expanded_checks = []
    for body_name, body in bodies.items():
        assert body.free <= {"u", "v"}
        k = body.substitute({"u": V("n"), "v": R(V("n"), V("a"))}).size
        assert k == body.size + 2 * body.occurrences("v")
        for name, p in probes.items():
            m, d = p.size, p.occurrences("x")
            observed = joint(p, body).size + SEP.size
            assert observed == 17 + 3 * m + d + k
            expanded_checks.append({
                "kind": "joint", "body": body_name, "probe": name,
                "m": m, "d": d, "k": k, "observed": observed,
                "predicted": 17 + 3 * m + d + k,
            })
        for matrix in matrices:
            p = normalized(matrix)
            assert admitted(p)
            f, d = matrix.size, matrix.occurrences("x")
            new = joint(p, body).size + SEP.size
            old = R0.size + All("n", All("a", eq_computation(body))).size + fused(matrix).size
            assert new == 20 + k + 6 * f + d
            assert old == 24 + k + 4 * f + d
            assert new - old == 2 * f - 4
            expanded_checks.append({
                "kind": "normalized_matrix_comparison", "body": body_name,
                "matrix": matrix.render(), "f": f, "d": d, "k": k,
                "new": new, "old_fused": old, "new_minus_old": new - old,
            })

    source_terms = finite_terms(6)
    images = [t.substitute({"z": R(ZERO, w)}) for t in source_terms]
    assert len(set(source_terms)) == len(source_terms)
    assert len(set(images)) == len(images)
    assert all(restore_anchor_term(image) == source for source, image in zip(source_terms, images))
    clause_terms = source_terms[:10]
    atoms = [Eq(s, t) for s in clause_terms for t in clause_terms]
    clauses = atoms + [Or(p, q) for p in atoms[:10] for q in atoms[:10]]
    clause_images = [p.substitute({"z": R(ZERO, w)}) for p in clauses]
    assert len(set(clause_images)) == len(set(clauses))
    # x -> 0 legitimately identifies x with 0 BEFORE the injective substitution.
    collapsing = Imp(Eq(x, z), Eq(ZERO, z))
    assert admitted(collapsing)
    assert collapsing.children[0] != collapsing.children[1]
    assert collapsing.substitute({"x": ZERO}).children[0] == collapsing.substitute({"x": ZERO}).children[1]

    return {
        "status": "PASS",
        "scope": {
            "checked": [
                "finite AST construction and structural equality",
                "simultaneous substitution and selected capture-avoidance cases",
                "exact one-or-two-equation clause admission",
                "four proof templates and seven rejected templates",
                "atomic-only classical admission and its coverage probe",
                "Harrop classification of the atomic family examples and separation",
                "fixed two-variable instantiated formulas",
                "partial display counts under the old drafts' convention",
                "term-placeholder counts exposing the new matrix and old Z2 basis",
                "expanded counts with actual update bodies",
                "bounded examples of fresh-anchor substitution injectivity",
            ],
            "not_checked": [
                "a first-order proof calculus or syntactic proof transport",
                "the complete recursion-description grammar",
                "arithmetic bootstrap, pairing, or interpretation round trips",
                "all syntax cases by a proof assistant",
                "the relative Harrop-context disjunction-property metatheorem",
                "a global shortestness or historical-priority claim",
            ],
        },
        "admission_grammar": "A=P->Q; P,Q each one equation or a binary disjunction of two equations; FV(A) subset {x,z,w}; transported branches literally equal",
        "probes": probe_results,
        "classical_atomic_variant": {
            "admission_grammar": "Same admission test, but P and Q are each a single equation",
            "probe_classification": atomic_probes,
            "coverage_probe": atomic_cover.render(),
            "transported_base": transported(atomic_cover).render(),
            "diagonal": atomic_cover.substitute({"x": V("n"), "z": V("a"), "w": V("a")}).render(),
            "tested_atomic_joint_instances_and_separation_are_harrop": True,
            "positive_disjunctive_coverage_instance_is_not_harrop": True,
            "partial_display_count_including_separation": 35,
            "qualification": "The script checks syntax and classification only. Classical sufficiency and intuitionistic nonderivability of positive native coverage are mathematical arguments in the report/audit.",
        },
        "negative_cases_rejected": sorted(negatives),
        "substitution_checks": {
            "simultaneous_example": simultaneous.render(),
            "capture_avoiding_example": captured.render(),
            "bound_variable_shadowing": True,
        },
        "partial_display_ledger": partial_ledger(),
        "term_placeholder_ledger": term_placeholder_ledger(),
        "expanded_formula_identities": {
            "joint_plus_sep": "17 + 3*m + d + k",
            "normalized_matrix_joint_plus_sep": "20 + k + 6*f + d",
            "old_fused_with_computations": "24 + k + 4*f + d",
            "normalized_difference_new_minus_old": "2*f - 4",
            "definitions": "m=|A|; d=occ_x(A), or occ_x(F) in normalized comparison; f=|F|; k=|h(n,R_h(n,a))| after actual update-body substitution",
            "qualification": "Only the selected equation/disjunctive matrices in these comparisons directly satisfy the main admission grammar. General QFI is recovered through the proved equality-bit compiler, whose expansion is not counted here.",
        },
        "expanded_checks": expanded_checks,
        "anchor_substitution_examples": {
            "maximum_source_term_size": 6,
            "term_count": len(source_terms),
            "distinct_clause_count": len(set(clauses)),
            "injective_on_enumerated_terms_and_clauses": True,
            "explicit_left_inverse_checked": True,
            "qualification": "Finite diagnostics accompany, but do not prove, the general structural-induction argument in the audit/report.",
        },
    }


def collect_variable_names(p: Formula) -> list[str]:
    def term_names(t: Term) -> list[str]:
        return [t.name] if t.tag == "var" else [n for a in t.args for n in term_names(a)]
    names = [n for t in p.terms for n in term_names(t)]
    names += [n for c in p.children for n in collect_variable_names(c)]
    if p.tag == "forall":
        names.append(p.name)
    return names


if __name__ == "__main__":
    result = run()
    destination = Path(__file__).resolve().with_name("schema_results.json")
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("PASS: syntax, admission, display ledger, and expanded-size diagnostics")
    print(json.dumps(result["partial_display_ledger"], sort_keys=True))
    print("Expanded cases:", len(result["expanded_checks"]))
    print("Anchor terms:", result["anchor_substitution_examples"]["term_count"])
    print("Wrote", destination)
