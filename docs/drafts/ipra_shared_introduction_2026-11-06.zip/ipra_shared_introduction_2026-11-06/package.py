"""Create the deliverable ZIP with a SHA-256 manifest, excluding temporary files."""
from pathlib import Path
import hashlib
import zipfile


def main():
    root = Path(__file__).resolve().parent
    paths = sorted(p for p in root.rglob("*") if p.is_file()
                   and not any(part.startswith(".") or part == "__pycache__"
                               for part in p.relative_to(root).parts)
                   and p.name != "MANIFEST.sha256"
                   and p.suffix not in {".pyc", ".png"})
    (root / "MANIFEST.sha256").write_text("".join(
        hashlib.sha256(p.read_bytes()).hexdigest() + "  "
        + p.relative_to(root).as_posix() + "\n" for p in paths))
    paths.append(root / "MANIFEST.sha256")
    destination = root.parent / (root.name + ".zip")
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in paths:
            archive.write(path, path.relative_to(root.parent))
    print(destination)
    print(str(len(paths)) + " files; " + str(destination.stat().st_size) + " bytes")


if __name__ == "__main__":
    main()
