"""Reproduce source measurements, translations, and independent checking offline."""
from pathlib import Path
import json
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parent
    runs = ("measure.py", "validation/verify_translations.py", "validation/independent_audit.py")
    for script in runs:
        completed = subprocess.run([sys.executable, str(root / script)],
                                   cwd=root, capture_output=True, text=True)
        if completed.returncode:
            print(completed.stdout + completed.stderr)
            raise SystemExit(completed.returncode)
        print("PASS " + script)
    metrics = json.loads((root / "results/metrics.json").read_text())
    translations = json.loads((root / "results/checked_translations.json").read_text())
    audit = json.loads((root / "results/independent_audit.json").read_text())
    records = json.loads((root / "validation/translated_corpus.json").read_text())
    if not audit["pass"]:
        raise ValueError("Independent audit failed.")
    summary = {
        "status": "passed", "python": sys.version,
        "snapshot": metrics["snapshot"],
        "current_envelope": metrics["current_envelope"],
        "candidates": metrics["candidates"],
        "translation_records": translations["source_theorems"],
        "distinct_translated_certificates": len({
            json.dumps(record["data"], sort_keys=True) for record in records}),
        "distinct_translated_goals": len({
            json.dumps(record["data"][0], sort_keys=True) for record in records}),
        "independent_audit": {key: value["summary"]
                              for key, value in audit["variants"].items()},
        "cli_runs": sum(value["summary"]["cli_runs"]
                        for value in audit["variants"].values()),
        "failures": audit["failures"],
        "scope": "Finite executable evidence plus written metatheory; no proof-assistant verification."
    }
    (root / "results/reproduction.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
