"""Compile the complete LaTeX report with pdfLaTeX, without network access."""
from pathlib import Path
import os
import shutil
import subprocess


def main():
    root = Path(__file__).resolve().parent
    target = root / ".build"
    target.mkdir(exist_ok=True)
    env = dict(os.environ)
    env["SOURCE_DATE_EPOCH"] = "1794024745"
    env["FORCE_SOURCE_DATE"] = "1"
    formats = target / "formats"
    formats.mkdir(exist_ok=True)
    env["TEXFORMATS"] = str(formats) + os.pathsep + env.get("TEXFORMATS", "")
    available = subprocess.run(["kpsewhich", "pdflatex.fmt"], env=env,
                               capture_output=True, text=True)
    if not available.stdout.strip():
        initialize = ["pdftex", "-ini", "-etex", "-interaction=nonstopmode",
                      "-halt-on-error", "-jobname=pdflatex", "-progname=pdflatex",
                      "pdflatex.ini"]
        completed = subprocess.run(initialize, cwd=formats, env=env,
                                   capture_output=True, text=True)
        (target / "format_build.txt").write_text(completed.stdout + completed.stderr)
        if completed.returncode:
            print((completed.stdout + completed.stderr)[-10000:])
            raise SystemExit(completed.returncode)
    command = ["pdflatex", "-halt-on-error", "-interaction=nonstopmode",
               "-file-line-error", "-output-directory=" + str(target), "report.tex"]
    for number in range(3):
        completed = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True)
        (target / ("pass_" + str(number + 1) + ".txt")).write_text(
            completed.stdout + completed.stderr)
        if completed.returncode:
            print((completed.stdout + completed.stderr)[-12000:])
            raise SystemExit(completed.returncode)
    log = (target / "report.log").read_text(errors="replace")
    if "There were undefined references" in log or "LaTeX Warning: Citation" in log:
        raise SystemExit("Unresolved references remain.")
    shutil.copyfile(target / "report.pdf", root / "report.pdf")
    for line in log.splitlines():
        if "Overfull" in line or "Output written" in line:
            print(line)
    print("Built report.pdf")


if __name__ == "__main__":
    main()
