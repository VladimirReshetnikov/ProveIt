"""Remeasure the complete programs and frozen comparison sources offline."""
import ast
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
FIELDS = ("ast_nodes", "normalized_tokens", "normalized_bytes")


class StripDocstrings(ast.NodeTransformer):
    def visit(self, node):
        node = super().visit(node)
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                node.body.pop(0)
        return node


def measure(path):
    raw = path.read_bytes()
    tree = StripDocstrings().visit(ast.parse(raw.decode("utf-8")))
    normalized = ast.unparse(tree) + "\n"
    ignored = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.INDENT,
               tokenize.DEDENT, tokenize.NEWLINE, tokenize.NL, tokenize.COMMENT}
    tokens = sum(token.type not in ignored
                 for token in tokenize.generate_tokens(io.StringIO(normalized).readline))
    return {
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_tokens": tokens,
        "normalized_bytes": len(normalized.encode("utf-8")),
        "raw_bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


def run():
    manifest = json.loads((ROOT / "comparison/source_manifest.json").read_text())
    measured = {}
    for category in ("current", "historical"):
        for item in manifest[category]:
            result = measure(ROOT / item["frozen_source"])
            if result["sha256"] != item["sha256"]:
                raise ValueError("Frozen source hash changed: " + item["frozen_source"])
            if any(result[key] != item["metrics"][key] for key in FIELDS):
                raise ValueError("Snapshot metric differs on this Python version: "
                                 + item["frozen_source"])
            measured[item["sha256"]] = result
    envelope = {key: min(measured[item["sha256"]][key]
                         for item in manifest["current"]) for key in FIELDS}
    historical = {key: min(measured[item["sha256"]][key]
                           for item in manifest["historical"]) for key in FIELDS}
    candidates = {name: measure(ROOT / name)
                  for name in ("checker.py", "checker_demand.py")}
    below = {name: {key: value[key] < envelope[key] for key in FIELDS}
             for name, value in candidates.items()}
    if not all(all(row.values()) for row in below.values()):
        raise ValueError("A candidate does not beat every current coordinate minimum.")
    result = {
        "status": "passed", "python": sys.version,
        "snapshot": manifest["snapshot"],
        "boundary": "Entire standalone source including JSON CLI and failure handling; "
                    "only comments and docstrings excluded from normalized measures. "
                    "The same Python runtime and json/sys modules are excluded for all.",
        "frozen_current_sources": len(manifest["current"]),
        "frozen_historical_candidates": len(manifest["historical"]),
        "current_envelope": envelope,
        "historical_candidate_envelope": historical,
        "candidates": candidates,
        "strictly_below_current": below,
        "demand_reductions": {
            key: {"absolute": envelope[key] - candidates["checker_demand.py"][key],
                  "percent": 100 * (envelope[key] - candidates["checker_demand.py"][key])
                  / envelope[key]} for key in FIELDS},
    }
    (ROOT / "results/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    run()
