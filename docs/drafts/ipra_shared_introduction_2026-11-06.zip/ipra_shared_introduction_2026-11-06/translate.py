"""Untrusted translation from the pinned goal-reconstruction calculus.

All input certificates must be accepted by the explicitly supplied source
checker. All output certificates are checked again by the target. The helpers
and comparison checker are not part of the trusted acceptance program.
"""
from copy import deepcopy
import checker

s = checker.subst
RED = ['r', -1, -1, -1]
EQ = ['=', RED, -1]


def find_zero(a, depth=0):
    if a == -1:
        return (), depth
    if type(a) is list:
        widths = next(table[a[0]] for table in checker.SCOPES if a[0] in table)
        for i, (b, width) in enumerate(zip(a[1:], widths), 1):
            found = find_zero(b, depth + width)
            if found is not None:
                path, level = found
                return (i, *path), level
    return None


def replace(a, path, value):
    if not path:
        return deepcopy(value)
    i, *tail = path
    result = a.copy()
    result[i] = replace(result[i], tail, value)
    return result


def tagged(a, p, g):
    """Reconstruct the explicit tagged proof from a verified source proof."""
    match (a, p):
        case [['pi', h, b], [False | True as induct, q]]:
            if induct:
                if h != s(b, [-1, 0]):
                    raise ValueError('Invalid induction guard')
                h = b if b[0] == '=' else h
                b = s(b, [['s', 0], 0])
            return ['nat' if induct else 'lam', tagged(b, q, [*map(s, g), h])]
        case [['ex', b], [t, q]]:
            h = ['=', 0, s(t, formula=False)]
            return ['pack', deepcopy(t), tagged(b, q, [*map(s, g), h])]
        case [_, [[tag, *parts] as m, r, *args]]:
            # Canonical accepted certificates use an accepted major premise.
            # A source fallback hypothesis can justify a failed-major record;
            # select that hypothesis only when reconstruction fails.
            try:
                mr = tagged(m, r, g)
                if tag == 'ex':
                    q, = args
                    return ['use', deepcopy(m), mr, tagged(s(a), q, [*map(s, g), *parts])]
                t, q = args
                if tag == 'pi':
                    try:
                        s(t, formula=False)
                    except Exception:
                        if any(s(v, [t, -1]) != s(v, [-1, -1]) for v in parts):
                            raise ValueError('The malformed witness is used')
                        t = -1
                b, c = (s(t, [v, -1]) if tag == '=' else s(v, [t, -1]) for v in parts)
                if c != a:
                    raise ValueError('Wrong elimination conclusion')
                return ['use', deepcopy(m), mr, deepcopy(t), tagged(b, q, g)]
            except Exception:
                if a not in g:
                    raise
                return g.index(a)
        case [['=', ['r', n, t, h], b], 'r']:
            if n != -1:
                _, n = n
                t = s(h, [['r', n, t, h], n, -2], formula=False)
            if b != t:
                raise ValueError('Invalid computation')
            return 'r'
        case _:
            return g.index(a)


def premises(a, p, g, automatic=False):
    if type(p) is not list:
        return []
    if p[0] in ('lam', 'nat'):
        _, h, b = a
        if p[0] == 'nat' or automatic and h == s(b, [-1, 0]):
            h = b if b[0] == '=' else h
            b = s(b, [['s', 0], 0])
        return [(b, p[1], [*map(s, g), h])]
    if p[0] == 'pack':
        _, t, q = p
        return [(a[1], q, [*map(s, g), ['=', 0, s(t, formula=False)]])]
    _, m, r, *args = p
    tag, *parts = m
    result = [(m, r, g)]
    if tag == 'ex':
        q, = args
        result.append((s(a), q, [*map(s, g), *parts]))
    else:
        t, q = args
        b, _ = (s(t, [v, -1]) if tag == '=' else s(v, [t, -1]) for v in parts)
        result.append((b, q, g))
    return result


def rebuild(p, children):
    if not children:
        return p
    if p[0] in ('lam', 'nat'):
        return [p[0], children[0]]
    if p[0] == 'pack':
        return ['pack', deepcopy(p[1]), children[0]]
    if p[1][0] == 'ex':
        return ['use', deepcopy(p[1]), children[0], children[1]]
    return ['use', deepcopy(p[1]), children[0], deepcopy(p[3]), children[1]]


def transport_hypothesis(a, p, g, index, path):
    if type(p) is int and p == index:
        target = g[index]
        depth = 0
        node = target
        for i in path:
            widths = next(table[node[0]] for table in checker.SCOPES if node[0] in table)
            depth += widths[i - 1]
            node = node[i]
        motive = replace(s(target), path, depth)
        return ['use', deepcopy(EQ), 'r', motive, p]
    children = [transport_hypothesis(b, q, h, index, path)
                for b, q, h in premises(a, p, g, automatic=True)]
    return rebuild(p, children)


def automatic(a, p, g):
    children = [automatic(b, q, h) for b, q, h in premises(a, p, g)]
    if type(p) is list and p[0] in ('lam', 'nat'):
        _, h, b = a
        if p[0] == 'nat' or h != s(b, [-1, 0]):
            return ['lam', children[0]]
        found = find_zero(h)
        if found is None:
            if h != b or s(b, [['s', 0], 0]) != b:
                raise ValueError('No-zero collision invariant failed')
            return ['lam', len(g)]
        path, depth = found
        changed_guard = replace(h, path, RED)
        if changed_guard == s(b, [-1, 0]):
            raise ValueError('Guard perturbation did not separate syntax')
        minor = transport_hypothesis(b, children[0], [*map(s, g), h], len(g), path)
        motive = replace(s(a), (1, *path), depth + 1)
        return ['use', deepcopy(EQ), 'r', motive, ['lam', minor]]
    return rebuild(p, children)


def encode(p):
    if type(p) is int:
        return None
    if type(p) is not list:
        return p
    if p[0] in ('lam', 'nat'):
        return [encode(p[1])]
    if p[0] == 'pack':
        return [deepcopy(p[1]), encode(p[2])]
    _, major, proof, *args = p
    if major[0] == 'ex':
        return [deepcopy(major), encode(proof), encode(args[0])]
    return [deepcopy(major), encode(proof), deepcopy(args[0]), encode(args[1])]


def translate(data, source):
    """Validate a source sequent, preserve it exactly, and verify the result."""
    a, p, *g = data
    for h in g:
        source.subst(h)
    if source.check(a, p, g) is not True:
        raise ValueError('The source checker rejected the input')
    result = [deepcopy(a), encode(automatic(a, tagged(a, p, g), g)), *deepcopy(g)]
    if checker.check(result[0], result[1], result[2:]) is not True:
        raise ValueError('The target checker rejected the translation')
    return result


def main():
    import argparse
    import importlib.util
    import json
    from pathlib import Path
    parser = argparse.ArgumentParser(description='Translate a pinned theorem certificate and strictly recheck it')
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location('pinned_goal_reconstruction', root / 'comparison/goal_reconstruction.py')
    source = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source)
    data = json.loads(args.input.read_text(encoding='utf-8'))
    if type(data) is not list or len(data) != 2:
        raise ValueError('The command-line translator requires a theorem certificate [goal, proof]')
    result = translate(data, source)
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print('Translated and verified')


if __name__ == '__main__':
    main()
