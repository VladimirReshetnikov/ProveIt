A SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 6 November 2026

RESULT

The two complete theorem checkers beat the minimum of each declared
source-size measure across the nine current main/companion programs in
the five ProveIt/docs/drafts archives at commit
1d1b154fb3f071169b6a003b3f9d727166880006.

                              AST nodes   Normalized tokens   Normalized bytes
Current minimum                   582             569               1762
checker.py (strict)                581             564               1734
checker_demand.py (smallest)        569             554               1688

The counted boundary is the entire acceptance source, including formation,
substitution, logical and arithmetic rules, JSON loading, and failure
handling. Comments and docstrings are excluded from normalized measures.
The same Python runtime and json/sys modules are excluded in every case.
CPython 3.12.14 produced the exact normalized measurements.

This is a strict finite-corpus improvement. It is not an absolute
minimality theorem over all languages or proof representations.

WHAT CHANGED

The construction combines automatic guarded introduction with reconstruction
from the expected goal. A guarded introduction now has certificate [q].
Existential introduction has [t,q]. Both introductions and existential
elimination use the same final recursive check under a fresh variable.

Automatic introduction, its collision repair, the arithmetic basis, and
the whole-domain bi-interpretation are inherited from the supplied drafts.
Their full proofs are restated and attributed in report.pdf. The new
contribution is the compatible combination and shared implementation,
with a measured reduction against the current source snapshot.

QUICK START

From this directory:

  python3 checker.py examples/reflexivity.json
  python3 checker_demand.py examples/residual.json
  python3 reproduce.py

Acceptance prints ACCEPT and exits zero. Rejection prints REJECT and exits
nonzero. Both programs accept theorem input [goal, proof], with no external
hypotheses. Free number parameters are allowed; their universal closure
is understood. See FORMAT.txt and the report for the full grammar.

checker.py checks every witness used by an elimination rule.
checker_demand.py omits a redundant check when a universal witness is
unused in both components of its major. Replacing such an annotation
with zero recovers a strict proof. Both recognize the same theorems.

TRANSLATING SOURCE PROOFS

  python3 translate.py INPUT.json OUTPUT.json

INPUT.json must use the theorem-certificate format of the frozen
comparison/goal_reconstruction.py. The compiler checks the input,
handles automatic-introduction collisions using equality transport,
and checks its output with the new strict checker.

The translator and all verification code are untrusted support:
neither acceptance program imports them.

REPRODUCING THE EVIDENCE

  python3 measure.py
  python3 validation/verify_translations.py
  python3 validation/independent_audit.py

reproduce.py runs all three and writes results/reproduction.json.
The source comparison freezes all nine current programs and 216 historical
checker candidates. Every frozen source is hash-verified before measuring.
The proof corpus contains 212 labeled records, representing 151 distinct
translated certificates and 145 distinct conclusions.

Both candidate programs pass the independent oracle's 136 targeted cases,
500 substitution samples, and all 18 named examples. Actual command-line
verification includes normal and -O execution: 608 runs in total.
The 13 additional demand accepts are exactly intended unused-witness cases.

These finite checks supplement written structural and bi-interpretation
proofs. The metatheorems are not formalized in Lean or Rocq.

BUILDING THE DOCUMENT AND ARCHIVE

  python3 build.py
  python3 package.py

build.py invokes pdfLaTeX three times, checks for unresolved references,
and writes report.pdf. Temporary build files stay in .build/.
package.py creates the ZIP alongside this directory and writes a SHA-256
manifest. No network access is needed.

Python programs require Python 3.10 or newer and only its standard library.
Exact normalized measurements use CPython 3.12.14. PDF rebuilding requires
pdfLaTeX and the TeX packages listed in report.tex.

CONTENTS

report.tex, sections/, report.pdf    Complete axiomatization and proofs
checker.py, checker_demand.py       Complete acceptance programs
translate.py                       Checked source-to-target proof compiler
examples/                          Eighteen named theorem certificates
validation/                        Independent oracle, cases, proof corpora
results/                           Measured and executed verification results
comparison/                        Frozen, hash-identified baseline sources
source_snapshot.json               Repository snapshot and archive hashes
measure.py, reproduce.py            Offline measurement and verification
build.py, package.py                Document build and packaging
MANIFEST.sha256                    Checksums of all other deliverable files
LICENSE_SOURCE.txt                 Repository license for inherited material

The report includes Further research questions.
