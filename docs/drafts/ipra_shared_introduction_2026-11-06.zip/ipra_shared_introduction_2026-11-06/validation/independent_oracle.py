"""Independent readable oracle for the automatic iPRA calculus.

This module is validation code, not part of the trusted checker.
It uses separate term/formula grammars and explicit capture-avoiding
substitution operations, with no import from the candidate checker.
"""


class Invalid(ValueError):
    pass


def require(condition):
    if not condition:
        raise Invalid


def term(t):
    if type(t) is int:
        require(t >= -1)
    else:
        require(type(t) is list)
        if len(t) == 2 and t[0] == 's':
            term(t[1])
        elif len(t) == 4 and t[0] == 'r':
            term(t[1])
            term(t[2])
            term(t[3])
        else:
            raise Invalid


def formula(a):
    require(type(a) is list and len(a) > 0)
    if a[0] == '=' and len(a) == 3:
        term(a[1])
        term(a[2])
    elif a[0] == 'pi' and len(a) == 3:
        formula(a[1])
        formula(a[2])
    elif a[0] == 'ex' and len(a) == 2:
        formula(a[1])
    else:
        raise Invalid


def map_term(t, variable, depth=0):
    if type(t) is int:
        return t if t < depth else variable(t, depth)
    if t[0] == 's':
        return ['s', map_term(t[1], variable, depth)]
    return ['r', map_term(t[1], variable, depth),
            map_term(t[2], variable, depth),
            map_term(t[3], variable, depth + 2)]


def map_formula(a, variable, depth=0):
    if a[0] == '=':
        return ['=', map_term(a[1], variable, depth),
                map_term(a[2], variable, depth)]
    if a[0] == 'pi':
        return ['pi', map_formula(a[1], variable, depth + 1),
                map_formula(a[2], variable, depth + 1)]
    return ['ex', map_formula(a[1], variable, depth + 1)]


def shift_term(t, amount=1, cutoff=0):
    term(t)
    return map_term(t, lambda n, d: n + amount, cutoff)


def shift_formula(a, amount=1, cutoff=0):
    formula(a)
    return map_formula(a, lambda n, d: n + amount, cutoff)


def replace_formula(a, replacement, delete=False):
    """Replace outer variable zero; validate a witness only if used.

    Keeping the slot is used by base/successor matrices; deleting it is
    used for actual quantifier and equality-motive instantiation.
    """
    formula(a)

    def variable(n, depth):
        if n == depth:
            return shift_term(replacement, depth)
        return n - int(delete)

    return map_formula(a, variable)


def update(h, previous, counter):
    term(h)
    term(previous)
    term(counter)

    def variable(n, depth):
        if n == depth:
            return shift_term(previous, depth)
        if n == depth + 1:
            return shift_term(counter, depth)
        return n - 2

    return map_term(h, variable)


def member(a, context):
    return any(a == h for h in context)


def derive(a, proof, context, strict=True):
    """Rule-by-rule derivability of a payload, in the supplied context."""
    formula(a)
    if a[0] == 'pi' and type(proof) is list and len(proof) == 1:
        antecedent, body = a[1:]
        if antecedent == replace_formula(body, -1):
            local = body if body[0] == '=' else antecedent
            conclusion = replace_formula(body, ['s', 0])
        else:
            local, conclusion = antecedent, body
        opened_context = [shift_formula(h) for h in context] + [local]
        return derive(conclusion, proof[0], opened_context, strict)

    if a[0] == 'ex' and type(proof) is list and len(proof) == 2:
        witness, minor = proof
        term(witness)
        local = ['=', 0, shift_term(witness)]
        opened_context = [shift_formula(h) for h in context] + [local]
        return derive(a[1], minor, opened_context, strict)

    elimination_shape = (type(proof) is list and len(proof) >= 2
                         and type(proof[0]) is list and len(proof[0]) >= 1)
    if elimination_shape:
        major, major_proof = proof[:2]
        # Malformed majors raise. A well-formed but unproved major permits
        # the production checker's harmless Hyp fallback.
        if not derive(major, major_proof, context, strict):
            return member(a, context)
        if major[0] == 'ex':
            require(len(proof) == 3)
            opened_context = [shift_formula(h) for h in context] + [major[1]]
            return derive(shift_formula(a), proof[2], opened_context, strict)
        require(len(proof) == 4)
        argument, minor = proof[2:]
        if major[0] == '=':
            formula(argument)
            source = replace_formula(argument, major[1], delete=True)
            target = replace_formula(argument, major[2], delete=True)
        else:
            if strict:
                term(argument)
            source = replace_formula(major[1], argument, delete=True)
            target = replace_formula(major[2], argument, delete=True)
        return target == a and derive(source, minor, context, strict)

    computation_shape = (a[0] == '=' and type(a[1]) is list
                         and a[1][0] == 'r' and proof == 'r')
    if computation_shape:
        recursor, proposed = a[1:]
        counter, initial, step = recursor[1:]
        if counter == -1:
            result = initial
        else:
            require(type(counter) is list and counter[0] == 's')
            predecessor = counter[1]
            previous = ['r', predecessor, initial, step]
            result = update(step, previous, predecessor)
        return proposed == result

    return member(a, context)


def accepts(a, proof, context=(), strict=True):
    try:
        for h in context:
            formula(h)
        return derive(a, proof, list(context), strict)
    except (Invalid, TypeError, ValueError, IndexError, RecursionError):
        return False


def accepts_payload(payload, strict=True):
    if type(payload) is not list or len(payload) != 2:
        return False
    return accepts(payload[0], payload[1], strict=strict)
