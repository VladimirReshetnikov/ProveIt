"""Reproduce checked translation and proof-format round trips offline."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import checker
import checker_demand
import translate


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def source_proof(a, p, g):
    """Convert a verified canonical automatic certificate to two-mode form."""
    s = checker.subst
    match (a, p):
        case [['pi', h, b], [q]]:
            numeric = h == s(b, [-1, 0])
            if numeric:
                h = b if b[0] == '=' else h
                b = s(b, [['s', 0], 0])
            return [numeric, source_proof(b, q, [*map(s, g), h])]
        case [['ex', b], [t, q]]:
            h = ['=', 0, s(t, formula=False)]
            return [t, source_proof(b, q, [*map(s, g), h])]
        case [_, [[tag, *parts] as m, r, *args]]:
            major = source_proof(m, r, g)
            if tag == 'ex':
                q, = args
                return [m, major, source_proof(s(a), q, [*map(s, g), *parts])]
            t, q = args
            b, _ = (s(t, [v, -1]) if tag == '=' else s(v, [t, -1]) for v in parts)
            return [m, major, t, source_proof(b, q, g)]
        case [['=', ['r', _, _, _], _], 'r']:
            return 'r'
        case _:
            if a not in g:
                raise ValueError('Missing hypothesis')
            return None


def run():
    source_path = ROOT / 'comparison/goal_reconstruction.py'
    corpus_path = ROOT / 'validation/source_closed_corpus.json'
    for path, expected in [
        (source_path, '50c89a7fc8d8f8474c22eeabb8e6160a866fc35a1b556294667935a08c898b84'),
        (corpus_path, '6d3901e3acd75b8e5931a36b3f86902ab02943e4a46c38503f3e9d2e058bf6b0'),
    ]:
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Pinned source hash changed: ' + str(path))
    source = load('pinned_source_checker', source_path)
    records = json.loads(corpus_path.read_text())
    transformed = []
    for record in records:
        data = record['data']
        if len(data) != 2:
            raise ValueError('Not a theorem certificate')
        result = translate.translate(data, source)
        a, p = result
        if checker_demand.check(a, p, []) is not True:
            raise ValueError('Demand checker rejected ' + record['id'])
        back = source_proof(a, p, [])
        if source.check(a, back, []) is not True:
            raise ValueError('Source checker rejected round trip ' + record['id'])
        if a != data[0]:
            raise ValueError('A goal changed')
        transformed.append({'id': record['id'], 'data': result})
    expected = json.loads((ROOT / 'validation/translated_corpus.json').read_text())
    if transformed != expected:
        raise ValueError('Reconstructed corpus differs from saved corpus')
    result = {
        'status': 'passed',
        'source_theorems': len(records),
        'strict_forward_acceptances': len(records),
        'demand_forward_acceptances': len(records),
        'source_backward_acceptances': len(records),
        'exact_goals_preserved': len(records),
        'source_checker_sha256': hashlib.sha256(source_path.read_bytes()).hexdigest(),
        'source_corpus_sha256': hashlib.sha256(corpus_path.read_bytes()).hexdigest(),
        'scope': 'Finite translation and round-trip evidence, not a proof-assistant formalization.'
    }
    (ROOT / 'results/checked_translations.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    run()
