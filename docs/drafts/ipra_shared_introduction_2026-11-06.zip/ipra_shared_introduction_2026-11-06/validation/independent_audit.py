"""Targeted independent validation of the new standalone checkers.

Run: python3 validation/independent_audit.py
Optional arguments select STRICT_CHECKER and DEMAND_CHECKER.
Results are written to results/independent_audit.json. Source programs are never modified.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

import independent_oracle as oracle

ZERO = -1
ONE = ['s', ZERO]
TRUE = ['=', ZERO, ZERO]
FALSE = ['=', ZERO, ONE]


def eq(s, t):
    return ['=', s, t]


def succ(t):
    return ['s', t]


def rec(n, a, h):
    return ['r', n, a, h]


def reflexivity(t):
    r = rec(ZERO, t, ZERO)
    major = eq(r, t)
    motive = eq(0, oracle.shift_term(t))
    return eq(t, t), [major, 'r', motive, 'r']


def existence(t):
    return ['ex', eq(0, oracle.shift_term(t))], [t, None]


def examples():
    cases = []

    def add(name, a, p, want=True, context=(), demand=None, group='logical'):
        cases.append({'name': name, 'group': group, 'payload': [a, p],
                      'context': list(context), 'strict': want,
                      'demand': want if demand is None else demand})

    def raw(name, payload, want=False):
        cases.append({'name': name, 'group': 'interface', 'payload': payload,
                      'context': [], 'strict': want, 'demand': want})

    ts = [ZERO, 0, 3, ONE, succ(0), rec(0, 2, succ(0)),
          rec(succ(2), 0, rec(1, 0, succ(2)))]
    updates = [ZERO, 0, 1, 2, succ(0), rec(1, 2, succ(3))]
    for i, t in enumerate(ts):
        goal, proof = reflexivity(t)
        add(f'reflexivity_{i}', goal, proof, group='equality')
        goal, proof = existence(t)
        add(f'existence_{i}', goal, proof, group='existential')
        local = eq(0, oracle.shift_term(t))
        minor_motive = eq(0, oracle.shift_term(t, 2))
        minor = [local, None, minor_motive, None]
        add(f'existential_elimination_{i}', eq(t, t), [goal, proof, minor],
            group='existential')
    for i, h in enumerate(updates):
        r = rec(ZERO, 2, h)
        add(f'compute_zero_{i}', eq(r, 2), 'r', group='computation')
        n = rec(succ(0), 1, 0)
        r = rec(succ(n), 2, h)
        reduct = oracle.update(h, rec(n, 2, h), n)
        add(f'compute_successor_{i}', eq(r, reduct), 'r', group='computation')
    add('compute_wrong_reduct', eq(rec(ZERO, ZERO, 0), ONE), 'r', False,
        group='computation')
    add('compute_variable_counter', eq(rec(0, ZERO, 0), ZERO), 'r', False,
        group='computation')
    add('compute_nonsuccessor_counter', eq(rec(rec(ZERO, ZERO, 0), ZERO, 0), ZERO),
        'r', False, group='computation')

    # Ordinary Pi introduction, with both matrices depending on the bound number.
    add('ordinary_pi_identity', ['pi', eq(0, 0), eq(0, 0)], [None])
    # Automatic equation-induction dispatch for the expected P(0) -> P(x).
    p = eq(0, 0)
    pi_reflexivity = ['pi', TRUE, p]
    pi_proof = [reflexivity(succ(0))[1]]
    add('equation_induction', pi_reflexivity, pi_proof, group='numerical')
    # Compound formulas receive only the zero case, never an induction hypothesis.
    b = ['ex', eq(0, 1)]
    h = oracle.replace_formula(b, ZERO)
    add('compound_numerical_cases', ['pi', h, b], [[succ(0), None]],
        group='numerical')
    add('compound_step_cannot_use_matrix', ['pi', h, b], [None], False,
        group='numerical')
    add('bad_induction_step', ['pi', TRUE, eq(0, ZERO)], [None], False,
        group='numerical')
    add('singleton_pi_required', pi_reflexivity, [True, pi_proof[0]], False,
        group='shape')
    add('one_boolean_is_not_a_proof', pi_reflexivity, [True], False,
        group='shape')

    true_proof = reflexivity(ZERO)[1]
    for i, t in enumerate(ts):
        add(f'pi_instantiation_{i}', eq(t, t),
            [pi_reflexivity, pi_proof, t, true_proof], group='universal')
    vacuous = ['pi', TRUE, TRUE]
    vacuous_proof = [None]
    bads = [None, False, True, 0.0, -1.0, -2, [], {}, 'unused',
            ['s'], ['s', ZERO, ZERO], ['=', ZERO, ZERO],
            ['r', ZERO, ZERO, {'dead': 'body'}]]
    for i, bad in enumerate(bads):
        add(f'vacuous_witness_{i}', TRUE,
            [vacuous, vacuous_proof, bad, true_proof], False, demand=True,
            group='demand_validation')
        add(f'used_bad_witness_{i}', TRUE,
            [pi_reflexivity, pi_proof, bad, true_proof], False,
            group='demand_validation')
        # Motives are formulas and cannot be erased.
        add(f'equality_motive_sort_{i}', TRUE,
            [TRUE, true_proof, bad, true_proof], bad == TRUE,
            group='equality')

    major, mp = existence(ZERO)
    add('existential_freshness_leak', eq(0, ZERO), [major, mp, None], False,
        group='freshness')
    add('pi_freshness_leak', ['pi', eq(0, 0), eq(0, ZERO)], [None], False,
        context=[eq(0, ZERO)], group='freshness')
    nested = ['ex', ['ex', eq(0, 1)]]
    nested_proof = [ZERO, [0, None]]
    add('nested_exists', nested, nested_proof, group='freshness')
    # Open the outer witness, then the inner witness, then use a separate zero witness.
    inner = ['ex', eq(0, 1)]
    conclusion, cp = existence(ZERO)
    add('nested_exists_elimination', conclusion,
        [nested, nested_proof, [inner, None, cp]], group='freshness')
    add('nested_matrix_slot_retention', ['pi', TRUE, ['ex', eq(0, 1)]],
        [[0, None]], group='freshness')

    # Equality transport through an existential binder.
    major = eq(0, 1)
    motive = ['ex', eq(0, 1)]
    source, source_proof = existence(0)
    target, _ = existence(1)
    add('quantified_equality_transport', target,
        [major, None, motive, source_proof], context=[major], group='equality')
    add('quantified_equality_wrong_slot', target,
        [major, None, ['ex', eq(0, 2)], source_proof], False,
        context=[major], group='equality')
    add('hypothesis_false_major_fallback', TRUE, [FALSE, None, ZERO, None],
        context=[TRUE], group='hypothesis')
    add('hypothesis_noncanonical_payload', TRUE, {'ignored': 'annotation'},
        context=[TRUE], group='hypothesis')
    add('malformed_major_does_not_fallback', TRUE, [['unknown'], None, ZERO, None],
        False, context=[TRUE], group='hypothesis')
    add('false_theorem', FALSE, None, False, group='rejection')
    add('foreign_hypothesis', TRUE, None, False, group='rejection')

    malformed = [None, False, True, 0, ZERO, 0.0, {}, [], 'pi',
                 ['=', False, ZERO], ['=', ZERO, -1.0], ['=', ZERO, -2],
                 ['=', ZERO], ['=', ZERO, ZERO, ZERO], ['pi', TRUE],
                 ['pi', TRUE, TRUE, TRUE], ['ex', ZERO], ['ex', TRUE, TRUE],
                 ['=', ['s'], ZERO], ['=', ['s', ZERO, ZERO], ZERO],
                 ['=', ['r', ZERO, ZERO], ZERO],
                 ['=', ['r', ZERO, ZERO, ['=', ZERO, ZERO]], ZERO],
                 ['=', ['r', ZERO, ZERO, False], ZERO],
                 ['=', ['r', ZERO, ZERO, 0.0], ZERO],
                 ['=', ['r', ZERO, ZERO, {'unused': 0}], ZERO],
                 ['=', {'s': ZERO}, ZERO], ['=', ['unknown', ZERO], ZERO]]
    for i, bad in enumerate(malformed):
        add(f'malformed_goal_{i}', bad, 'r', False, group='syntax')
    for i, payload in enumerate([None, False, 0, [], [TRUE], [TRUE, None, TRUE],
                                 {'goal': TRUE, 'proof': None}, 'ab']):
        raw(f'bad_interface_{i}', payload)
    return cases


def load(path, label):
    spec = importlib.util.spec_from_file_location('audit_' + label, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def candidate_accepts(module, payload, context):
    try:
        if context:
            return bool(module.check(payload[0], payload[1], context))
        return bool(module.check(*payload, []))
    except Exception:
        return False


def random_term(rng, depth):
    if depth == 0 or rng.randrange(4) == 0:
        return rng.randrange(-1, 5)
    if rng.randrange(2) == 0:
        return succ(random_term(rng, depth - 1))
    return rec(*(random_term(rng, depth - 1) for _ in range(3)))


def random_formula(rng, depth):
    if depth == 0 or rng.randrange(3) == 0:
        return eq(random_term(rng, 2), random_term(rng, 2))
    if rng.randrange(2) == 0:
        return ['ex', random_formula(rng, depth - 1)]
    return ['pi', random_formula(rng, depth - 1), random_formula(rng, depth - 1)]


def substitution_checks(module):
    rng = random.Random(20261106)
    results = []
    for i in range(100):
        a = random_formula(rng, 3)
        t = random_term(rng, 3)
        operations = [
            ('lift', oracle.shift_formula(a), lambda: module.subst(a)),
            ('base', oracle.replace_formula(a, ZERO), lambda: module.subst(a, [ZERO, 0])),
            ('successor', oracle.replace_formula(a, succ(0)), lambda: module.subst(a, [succ(0), 0])),
            ('instantiate', oracle.replace_formula(a, t, True), lambda: module.subst(a, [t, -1])),
        ]
        for name, expected, operation in operations:
            actual = operation()
            results.append({'case': f'formula_{i}_{name}', 'pass': actual == expected})
        h = random_term(rng, 4)
        p = random_term(rng, 2)
        n = random_term(rng, 2)
        expected = oracle.update(h, p, n)
        actual = module.subst(h, [p, n, -2], formula=False)
        results.append({'case': f'update_{i}', 'pass': actual == expected})
    return results


def main():
    here = Path(__file__).resolve().parent
    root = here.parent
    args = sys.argv[1:] or [str(root/'checker.py'), str(root/'checker_demand.py')]
    strict_path = Path(args[0]).resolve()
    targets = [('strict', strict_path, True)]
    if len(args) > 1:
        targets.append(('demand', Path(args[1]).resolve(), False))
    cases = examples()
    (here / 'independent_cases.json').write_text(json.dumps(cases, indent=2) + '\n')
    result = {'python': sys.version, 'oracle_sha256': hashlib.sha256((here/'independent_oracle.py').read_bytes()).hexdigest(),
              'case_count': len(cases), 'variants': {}}
    failures = []
    for label, path, strict in targets:
        module = load(path, label)
        records = []
        substitutions = substitution_checks(module)
        with tempfile.TemporaryDirectory(prefix='ipra_independent_audit_') as tmp:
            for item in cases:
                payload = item['payload']
                context = item['context']
                expected = item[label]
                if context:
                    independent = oracle.accepts(*payload, context=context, strict=strict)
                else:
                    independent = oracle.accepts_payload(payload, strict=strict)
                actual = candidate_accepts(module, copy.deepcopy(payload), copy.deepcopy(context))
                row = {'name': item['name'], 'group': item['group'], 'expected': expected,
                       'oracle': independent, 'candidate': actual, 'cli': {}}
                if not context:
                    fixture = Path(tmp) / (item['name'] + '.json')
                    fixture.write_text(json.dumps(payload))
                    for optimization in ('normal', 'optimized'):
                        command = [sys.executable] + (['-O'] if optimization == 'optimized' else [])
                        proc = subprocess.run(command + [str(path), str(fixture)], text=True,
                                              capture_output=True, timeout=10)
                        accepted = proc.returncode == 0 and proc.stdout == 'ACCEPT\n'
                        rejected = proc.returncode != 0 and proc.stdout == 'REJECT\n'
                        row['cli'][optimization] = {'accept': accepted, 'valid_response': accepted or rejected}
                row['pass'] = (independent == expected and actual == expected
                               and all(v['accept'] == expected and v['valid_response'] for v in row['cli'].values()))
                records.append(row)
                if not row['pass']:
                    failures.append({'variant': label, **row})
            syntax_cli = []
            for i, text in enumerate(['', '{', '[] trailing', '[NaN, null]']):
                fixture = Path(tmp) / ('bad_json_' + str(i))
                fixture.write_text(text)
                for flag in ([], ['-O']):
                    proc = subprocess.run([sys.executable, *flag, str(path), str(fixture)],
                                          capture_output=True, text=True, timeout=10)
                    ok = proc.returncode != 0 and proc.stdout == 'REJECT\n'
                    syntax_cli.append({'case': i, 'optimized': bool(flag), 'pass': ok})
                    if not ok:
                        failures.append({'variant': label, 'bad_json': i, 'optimized': bool(flag)})
        named_records = []
        for fixture in sorted((root/'examples').glob('*.json')):
            payload = json.loads(fixture.read_text())
            independent = oracle.accepts_payload(payload, strict=strict)
            actual = candidate_accepts(module, payload, [])
            row = {'name': fixture.name, 'oracle': independent, 'candidate': actual, 'cli': {}}
            for optimization in ('normal', 'optimized'):
                command = [sys.executable] + (['-O'] if optimization == 'optimized' else [])
                proc = subprocess.run(command + [str(path), str(fixture)], text=True,
                                      capture_output=True, timeout=30)
                row['cli'][optimization] = proc.returncode == 0 and proc.stdout == 'ACCEPT\n'
            row['pass'] = independent and actual and all(row['cli'].values())
            named_records.append(row)
            if not row['pass']:
                failures.append({'variant': label, 'named_example': fixture.name, **row})
        bad_subst = [r for r in substitutions if not r['pass']]
        failures.extend({'variant': label, **r} for r in bad_subst)
        result['variants'][label] = {
            'source': str(path.relative_to(root)) if path.is_relative_to(root) else str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'rules_and_malformed_inputs': records,
            'substitution_count': len(substitutions), 'substitution_failures': bad_subst,
            'malformed_json_cli': syntax_cli,
            'named_examples': named_records,
            'summary': {'cases': len(records), 'expected_accepts': sum(r['expected'] for r in records),
                        'expected_rejects': sum(not r['expected'] for r in records),
                        'disagreements': sum(not r['pass'] for r in records),
                        'generated_cli_runs': sum(len(r['cli']) for r in records) + len(syntax_cli),
                        'named_examples': len(named_records),
                        'named_cli_runs': 2 * len(named_records),
                        'substitution_samples': len(substitutions),
                        'cli_runs': sum(len(r['cli']) for r in records) + len(syntax_cli) + 2 * len(named_records)}
        }
    result['failures'] = failures
    result['pass'] = not failures
    (root / 'results' / 'independent_audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'pass': result['pass'], 'summaries': {k:v['summary'] for k,v in result['variants'].items()},
                      'failures': failures}, indent=2))
    return bool(failures)


if __name__ == '__main__':
    sys.exit(main())
