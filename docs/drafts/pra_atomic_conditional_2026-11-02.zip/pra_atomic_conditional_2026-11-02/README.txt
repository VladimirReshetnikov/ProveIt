ATOMIC CONDITIONAL PRA
2 November 2026

Read report.pdf. Rebuild it from report.tex and 01_core.tex through
06_verification.tex. All source files are included.

MAIN RESULT
The equation-indexed atomic conditional boundary theory and its two-branch
minimum serializer have common conservative definitional extensions with
first-order PRA, with whole-carrier identity interpretation round trips.
The statement holds separately classically and intuitionistically.

NEW IMPROVEMENTS
* Atomic single-occurrence core reaches the actual surviving native bound
  min(2F+i+12,F+20), with the inherited six-node arithmetic seed.
* The raw zero-truth equality code Q(d(Ss,t),1) contains each operand once
  and has full size X+Y+10, versus 2X+2Y+29 for the published normalized
  derived equality bit.
* The smaller truth compiler uses Z(r,s) directly for implication.
* The swapped conditional reduces the large raw nonzero module from
  T+24 to T+22 in the same logical basis.
* A countermodel excludes every fixed finite alphabet of closed equality
  targets, even up to arbitrary bi-interpretation with finite parameters.
* A complete finite certificate rules out two ternary gates for the
  unchanged conditional-boundary Boolean skeleton.

COMPARISON SCOPE
Repository: VladimirReshetnikov/ProveIt
Snapshot: 2ba9e7a5767fee450c6611868fdf0c4d3a27754e
Five current and eight archived ZIPs were downloaded and Git-blob-verified.
All five current packages improve on the archived iteration.
Full syntax counts charge frozen descriptors at every occurrence.
The paper distinguishes local serialized module sizes, fixed seeds,
logical-definition costs, and finite proof-support obligations.
No language-independent absolute shortest theory is claimed.

CONTENTS
report.pdf; report.tex; 01_core.tex through 06_verification.tex
code/boundary.py                  finite syntax, emitters, truth compilers
code/verify.py                    exact counts and finite semantic checks
code/independent_equality_check.py independent equality/count check
code/check_boolean_skeleton.py    complete local lower-bound certificates
code/example_*.json               runnable emitter inputs
proofs/AtomicConditional.lean     Lean 4.19.0, Init only
verification/                    actual check outputs and build review
provenance/                      source URLs and verified hashes

REPRODUCTION (from this directory)
python3 code/verify.py
python3 code/independent_equality_check.py
python3 code/check_boolean_skeleton.py --output verification/boolean_skeleton.json
python3 code/boundary.py code/example_atomic.json
python3 code/boundary.py code/example_nonzero.json
lean proofs/AtomicConditional.lean
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

VERIFICATION SCOPE
The full interpretation and arithmetic reconstruction have written proofs.
Lean checks local logical/algebraic kernels and a Nat scan, not the complete
PRA syntax, arithmetic bootstrap, pairing, or bi-interpretation metatheorem.
All eighteen printed kernel results have no axioms. There are no sorry
proofs or classical commands. Finite Python checks supplement the proofs.
The optional Boolean-edge emitter requires a separate certified range;
the CLI deliberately does not accept an unchecked Boolean flag.
