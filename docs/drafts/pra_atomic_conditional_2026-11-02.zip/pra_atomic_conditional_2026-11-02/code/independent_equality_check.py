"""Independent finite checks for the compact equality and zero-truth compiler.

These checks support the written proof; they are not a formal proof of PRA.
"""
from __future__ import annotations

import json


def v(name):
    return ("var", name)


zero = ("zero",)


def succ(t):
    return ("S", t)


one = succ(zero)


def rec(h, n, a):
    return ("R", h, n, a)


def q(n, a):
    return rec(v("w"), n, a)


def z(n, a):
    return rec(zero, n, a)


def pred(t):
    return q(t, zero)


def diff(s, t):
    return rec(pred(v("v")), t, s)


def ite(r, a, b):
    return q(z(r, succ(a)), b)


def size(t, full=True):
    if t[0] in ("var", "zero"):
        return 1
    if t[0] == "S":
        return 1 + size(t[1], full)
    assert t[0] == "R"
    return 1 + (size(t[1], full) if full else 0) + size(t[2], full) + size(t[3], full)


def qnum(n, a):
    return a if n == 0 else n - 1


def znum(n, a):
    return a if n == 0 else 0


def run():
    counts = []
    for sx in range(1, 15):
        for sy in range(1, 15):
            x, y = v("x"), v("y")
            for _ in range(sx - 1):
                x = succ(x)
            for _ in range(sy - 1):
                y = succ(y)
            r = diff(succ(x), y)
            old = ite(r, zero, ite(pred(r), one, zero))
            new_bit = z(q(r, one), one)
            new_unit = rec(z(v("w"), one), r, zero)
            new_zero = q(r, one)
            assert size(old) == 2*sx + 2*sy + 29
            assert size(new_bit) == sx + sy + 14
            assert size(new_unit) == sx + sy + 13
            assert size(new_zero) == sx + sy + 10
            assert size(old, False) == 2*sx + 2*sy + 16
            assert size(new_bit, False) == sx + sy + 8
            if sx == sy == 1:
                counts = {
                    "published_normalized": size(old),
                    "compact_normalized": size(new_bit),
                    "optional_unit_recursion": size(new_unit),
                    "zero_truth": size(new_zero),
                }
    for x in range(101):
        for y in range(101):
            r = max(x + 1 - y, 0)
            error = qnum(r, 1)
            bit = znum(error, 1)
            assert (r == 1) == (x == y)
            assert (error == 0) == (x == y)
            assert bit == int(x == y)
    for a in range(21):
        for b in range(21):
            assert (znum(a, b) == 0) == ((a != 0) or (b == 0))
            assert (a+b == 0) == ((a == 0) and (b == 0))
            assert (znum(znum(a, 1), b) == 0) == ((a == 0) or (b == 0))
    h = z(v("w"), one)
    u0 = rec(h, zero, v("a"))
    us = rec(h, succ(v("n")), v("a"))
    support_r0 = 1 + 1 + size(u0) + 1
    support_rs = 2 + 1 + size(us) + size(z(v("n"), one))
    assert (support_r0, support_rs) == (11, 17)
    return {
        "status": "all checks passed",
        "operand_size_pairs": 14**2,
        "numeric_equality_pairs": 101**2,
        "truth_gate_pairs": 21**2,
        "full_counts_at_variable_operands": counts,
        "optional_new_descriptor_generic_axiom_sizes": [support_r0, support_rs],
        "qualification": "Finite checks and exact syntax counts; no claim of complete formalization.",
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
