#!/usr/bin/env python3
"""Exact syntax checks and finite semantic checks supporting the paper.

The mathematical proofs in report.tex, and the scoped Lean kernels, carry the
unbounded claims.  This program does not test nonstandard models or establish
the full bi-interpretation.
"""
from __future__ import annotations

import itertools
import json
import random
from pathlib import Path

from boundary import (
    BOT, ONE, ZERO, add, atomic_emitter, boolean_edge, compact_bit, con,
    conditional_boundary, diff, direct_boundary, eq, equality_error, evaluate,
    evaluate_formula, expand_conditional, formula_occurrences, formula_size,
    nonzero_emitter, occurrences, pred, published_bit, published_code, q,
    raw_direct, rec, signed_zero_codes, simple_zero_code, subst_term, succ,
    term_size, var, z,
)


def formula_profile(f):
    if f.kind == "eq":
        return {"E": 1, "B": 0, "C": 0, "D": 0, "I": 0,
                "W": sum(term_size(t) for t in f.terms)}
    if f.kind == "bottom":
        return {"E": 0, "B": 1, "C": 0, "D": 0, "I": 0, "W": 0}
    a, b = map(formula_profile, f.children)
    result = {key: a[key] + b[key] for key in a}
    result[{"and": "C", "or": "D", "implies": "I"}[f.kind]] += 1
    return result


def main():
    rng = random.Random(20261102)
    x, a = var("x"), var("a")
    terms = [x, a, ZERO, ONE, succ(x), pred(x), q(x, a), z(x, a),
             add(x, a), diff(succ(x), a), compact_bit(x, a)]
    for depth in range(1, 10):
        t = x
        for _ in range(depth):
            t = add(t, x)
        terms.append(t)
        terms.append(succ(t))
    # Descriptor syntax is charged, while substitutions remain outside it.
    frozen = rec(add(var("v"), var("w")), x, a)
    transformed = subst_term(frozen, {"v": succ(x), "x": succ(x)})
    assert transformed.descriptor == frozen.descriptor
    assert occurrences(frozen, "v") == 0
    assert term_size(transformed) == term_size(frozen) + 1
    terms.append(frozen)

    atomic_rows = []
    for left, right in itertools.product(terms, repeat=2):
        p = eq(left, right)
        fsize, count = formula_size(p), formula_occurrences(p, "x")
        native, table = direct_boundary(p), conditional_boundary(p)
        assert formula_size(native) == 2*fsize + count + 12
        assert formula_size(table) == fsize + 20
        assert formula_size(expand_conditional(table)) == 2*fsize + 24
        label, emitted = atomic_emitter(left, right)
        expected = min(2*fsize + count + 12, fsize + 20) if count else 0
        assert (formula_size(emitted) if emitted else 0) == expected
        if len(atomic_rows) < 8 and count:
            atomic_rows.append({"F": fsize, "i": count,
                                "selected": label, "nodes": expected})

    raw_cases = 0
    for term in terms:
        size, count = term_size(term), occurrences(term, "x")
        negative = conditional_boundary(eq(term, ZERO), True)
        assert formula_size(negative) == size + 22
        assert formula_size(raw_direct(term)) == 2*size + count + 15
        assert formula_size(boolean_edge(term)) == 4*size + count + 8
        if count:
            expected = min(2*size + count + 15, size + 22)
            assert formula_size(nonzero_emitter(term)[1]) == expected
            raw_cases += 1

    # Check the envelope on all feasible profiles in a substantial finite box.
    envelope_cases = 0
    for size in range(1, 301):
        for count in range(1, (size+1)//2 + 1):
            new = min(2*size + count + 15, size + 22)
            old = min(2*size + count + 15, 2*size + 18,
                      size + 28, size + 24)
            assert new <= old
            assert min(new, 4*size + count + 8) <= min(
                old, 4*size + count + 8, size + 25)
            envelope_cases += 1

    small_terms = [ZERO, ONE, x, a, succ(x), pred(x), q(x, a), z(x, a)]
    atoms = [eq(t, u) for t, u in itertools.product(small_terms, repeat=2)]
    formulas = [BOT] + atoms
    for _ in range(80):
        left = rng.choice(atoms + [BOT])
        right = rng.choice(atoms + [BOT])
        formulas.append(con(rng.choice(("and", "or", "implies")), left, right))
    for _ in range(30):
        formulas.append(con(rng.choice(("and", "or", "implies")),
                            rng.choice(formulas[:145]), rng.choice(atoms)))
    semantic_cases = 0
    for formula in formulas:
        profile = formula_profile(formula)
        new = simple_zero_code(formula)
        old = published_code(formula)
        positive, negative = signed_zero_codes(formula)
        saving = (profile["W"] + 20*profile["E"] + 2*profile["C"]
                  + 4*profile["I"] - 1)
        assert term_size(old) - term_size(new) == saving
        assert term_size(positive) <= term_size(new)
        if profile["E"]:
            assert saving >= 21
        for xv, av in itertools.product(range(5), repeat=2):
            environment = {"x": xv, "a": av}
            truth = evaluate_formula(formula, environment)
            assert (evaluate(new, environment) == 0) == truth
            assert evaluate(old, environment) == int(truth)
            assert (evaluate(positive, environment) == 0) == truth
            assert (evaluate(negative, environment) == 0) == (not truth)
            semantic_cases += 1

    assert term_size(published_bit(x, a)) == 33
    assert term_size(compact_bit(x, a)) == 16
    assert term_size(equality_error(x, a)) == 12
    numeric_pairs = 0
    for xv, av in itertools.product(range(41), repeat=2):
        environment = {"x": xv, "a": av}
        assert (evaluate(equality_error(x, a), environment) == 0) == (xv == av)
        numeric_pairs += 1

    # Every 12-place truth pattern, every target 0..10, both polarities.
    # Values beyond the displayed window are irrelevant to the scan.
    scan_cases = 0
    for bits in itertools.product((False, True), repeat=12):
        for negative in (False, True):
            truth = [(not bit) if negative else bit for bit in bits]
            witness = 0
            for target in range(11):
                assert witness == 0 or truth[witness]
                assert not truth[witness+1] or witness == target
                for probe in range(12):
                    forward = probe != witness+1 or witness == target
                    backward = probe != witness or witness == 0
                    branch = (backward if bits[probe] else forward) if negative \
                        else (forward if bits[probe] else backward)
                    assert branch
                scan_cases += 1
                if truth[witness+1]:
                    witness += 1

    result = {
        "status": "all checks passed",
        "atomic_term_pairs": len(terms)**2,
        "raw_term_cases": raw_cases,
        "feasible_envelope_profiles": envelope_cases,
        "formula_compiler_cases": len(formulas),
        "formula_semantic_assignments": semantic_cases,
        "numeric_equality_pairs": numeric_pairs,
        "scanner_target_and_polarity_cases": scan_cases,
        "equality_full_sizes": {"published_bit": 33, "compact_bit": 16,
                                "zero_truth_error": 12},
        "atomic_examples": atomic_rows,
        "scope": "Exact finite syntax and finite semantic checks, not full PRA formalization",
    }
    out = Path(__file__).resolve().parents[1] / "verification" / "checks.json"
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
