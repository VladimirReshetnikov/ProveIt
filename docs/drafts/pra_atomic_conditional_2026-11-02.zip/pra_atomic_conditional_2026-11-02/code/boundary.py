#!/usr/bin/env python3
"""Finite syntax and reproducible emitters for atomic conditional PRA.

No numerical universal evaluator is part of the proposed theory.  The Python
evaluator below is an external, deliberately resource-limited test utility.
Frozen recursor descriptors are counted but never substituted into.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Term:
    kind: str
    args: tuple["Term", ...] = ()
    name: str = ""
    descriptor: "Term | None" = None


@dataclass(frozen=True)
class Formula:
    kind: str
    children: tuple["Formula", ...] = ()
    terms: tuple[Term, ...] = ()
    binder: str = ""


def var(name):
    return Term("var", name=name)


ZERO = Term("zero")


def succ(t):
    return Term("succ", (t,))


ONE = succ(ZERO)


def rec(h, n, a):
    if not free_term(h) <= {"v", "w"}:
        raise ValueError("A descriptor may have only the active slots v,w.")
    return Term("rec", (n, a), descriptor=h)


def q(n, a):
    return rec(var("w"), n, a)


def z(n, a):
    return rec(ZERO, n, a)


def pred(t):
    return q(t, ZERO)


def add(a, b):
    return rec(succ(var("v")), b, a)


def diff(a, b):
    return rec(pred(var("v")), b, a)


def ite_zero(condition, positive, negative):
    return q(z(condition, succ(positive)), negative)


def equality_error(a, b):
    """Zero exactly when a=b; each input occurs once."""
    return q(diff(succ(a), b), ONE)


def compact_bit(a, b):
    return z(equality_error(a, b), ONE)


def published_bit(a, b):
    residual = diff(succ(a), b)
    return ite_zero(residual, ZERO, ite_zero(pred(residual), ONE, ZERO))


def eq(a, b):
    return Formula("eq", terms=(a, b))


BOT = Formula("bottom")


def con(kind, *children):
    return Formula(kind, tuple(children))


def neg(p):
    return con("implies", p, BOT)


def quantify(kind, name, body):
    return Formula(kind, (body,), binder=name)


def prefix(body, binders):
    for kind, name in reversed(binders):
        body = quantify(kind, name, body)
    return body


def free_term(t):
    if t.kind == "var":
        return {t.name}
    return set().union(*(free_term(a) for a in t.args))


def occurrences(t, variable):
    if t.kind == "var":
        return int(t.name == variable)
    return sum(occurrences(a, variable) for a in t.args)


def subst_term(t, substitutions):
    if t.kind == "var":
        return substitutions.get(t.name, t)
    return Term(t.kind, tuple(subst_term(a, substitutions) for a in t.args),
                t.name, t.descriptor)


def subst_formula(f, substitutions):
    if f.kind in ("all", "exists"):
        restricted = {k: v for k, v in substitutions.items() if k != f.binder}
        if any(f.binder in free_term(v) for v in restricted.values()):
            raise ValueError("Capture would occur; rename the bound variable first.")
        return quantify(f.kind, f.binder, subst_formula(f.children[0], restricted))
    return Formula(f.kind,
                   tuple(subst_formula(c, substitutions) for c in f.children),
                   tuple(subst_term(t, substitutions) for t in f.terms), f.binder)


def term_size(t, full=True):
    return (1 + sum(term_size(a, full) for a in t.args)
            + (term_size(t.descriptor, full)
               if full and t.descriptor is not None else 0))


def formula_size(f, full=True):
    return (1 + sum(formula_size(c, full) for c in f.children)
            + sum(term_size(t, full) for t in f.terms))


def formula_occurrences(f, variable):
    if f.kind in ("all", "exists") and f.binder == variable:
        return 0
    return (sum(occurrences(t, variable) for t in f.terms)
            + sum(formula_occurrences(c, variable) for c in f.children))


def direct_boundary(p, negative=False):
    b, n = var("b"), var("n")
    at_b = subst_formula(p, {"x": b})
    at_next = subst_formula(p, {"x": succ(b)})
    if negative:
        first = con("implies", at_b, eq(b, ZERO))
        second = con("or", eq(b, n), at_next)
    else:
        first = con("or", eq(b, ZERO), at_b)
        second = con("implies", at_next, eq(b, n))
    return prefix(con("and", first, second),
                  (("all", "a"), ("all", "n"), ("exists", "b")))


def conditional_boundary(p, negative=False):
    x, b, n = var("x"), var("b"), var("n")
    forward = con("implies", eq(x, succ(b)), eq(b, n))
    backward = con("implies", eq(x, b), eq(b, ZERO))
    branches = (backward, forward) if negative else (forward, backward)
    return prefix(con("conditional", p, *branches),
                  (("all", "a"), ("all", "n"), ("exists", "b"), ("all", "x")))


def raw_direct(t):
    b, n = var("b"), var("n")
    tb = subst_term(t, {"x": b})
    tsb = subst_term(t, {"x": succ(b)})
    matrix = con("and", eq(z(tb, b), ZERO),
                 con("or", eq(tsb, ZERO), eq(b, n)))
    return prefix(matrix, (("all", "a"), ("all", "n"), ("exists", "b")))


def boolean_edge(t):
    """Valid only with an independently supplied {0,1}-range certificate."""
    b, n = var("b"), var("n")
    call = lambda u: subst_term(t, {"x": u})
    matrix = eq(q(call(succ(b)), call(b)), q(call(n), call(ZERO)))
    return prefix(matrix, (("all", "a"), ("all", "n"), ("exists", "b")))


def atomic_emitter(left, right):
    if not (free_term(left) | free_term(right)) <= {"x", "a"}:
        raise ValueError("Atomic inputs must have active variables only x,a.")
    p = eq(left, right)
    if formula_occurrences(p, "x") == 0:
        return "vacuous", None
    candidates = [("B", direct_boundary(p)),
                  ("C", conditional_boundary(p))]
    return min(candidates, key=lambda item: formula_size(item[1]))


def nonzero_emitter(t, *, certified_boolean=False):
    if not free_term(t) <= {"x", "a"}:
        raise ValueError("Raw inputs must have active variables only x,a.")
    if occurrences(t, "x") == 0:
        return "vacuous", None
    candidates = [("DB", raw_direct(t)),
                  ("C-negative", conditional_boundary(eq(t, ZERO), True))]
    if certified_boolean:
        candidates.append(("Boolean-edge", boolean_edge(t)))
    return min(candidates, key=lambda item: formula_size(item[1]))


def simple_zero_code(f):
    if f.kind == "eq":
        return equality_error(*f.terms)
    if f.kind == "bottom":
        return ONE
    a, b = map(simple_zero_code, f.children)
    if f.kind == "and":
        return add(a, b)
    if f.kind == "or":
        return z(z(a, ONE), b)
    if f.kind == "implies":
        return z(a, b)
    raise ValueError("Expected a quantifier-free formula in the binary basis.")


def published_code(f):
    if f.kind == "eq":
        return published_bit(*f.terms)
    if f.kind == "bottom":
        return ZERO
    a, b = map(published_code, f.children)
    if f.kind == "and":
        return ite_zero(a, ZERO, b)
    if f.kind == "or":
        return ite_zero(a, b, ONE)
    if f.kind == "implies":
        return ite_zero(a, ONE, b)
    raise ValueError("Expected the binary quantifier-free basis.")


def signed_zero_codes(f):
    """Return codes (zero iff f, zero iff not f), using finite dynamic programming."""
    if f.kind == "eq":
        positive = equality_error(*f.terms)
        return positive, z(positive, ONE)
    if f.kind == "bottom":
        return ONE, ZERO
    if f.kind == "implies" and f.children[1].kind == "bottom":
        positive, negative = signed_zero_codes(f.children[0])
        return negative, positive
    ap, am = signed_zero_codes(f.children[0])
    bp, bm = signed_zero_codes(f.children[1])
    if f.kind == "and":
        positives = [add(ap, bp)]
        negatives = [z(ap, bm), z(bp, am)]
    elif f.kind == "or":
        positives = [z(am, bp), z(bm, ap)]
        negatives = [add(am, bm)]
    elif f.kind == "implies":
        positives = [z(ap, bp)]
        negatives = [add(ap, bm)]
    else:
        raise ValueError("Expected the binary quantifier-free basis.")
    p0, m0 = min(positives, key=term_size), min(negatives, key=term_size)
    # More than one sign reversal cannot lower the strictly positive cost.
    return (min((p0, z(m0, ONE)), key=term_size),
            min((m0, z(p0, ONE)), key=term_size))


def expand_conditional(f):
    children = tuple(expand_conditional(c) for c in f.children)
    if f.kind == "conditional":
        p, u, v = children
        return con("or", con("and", p, u), con("and", neg(p), v))
    return Formula(f.kind, children, f.terms, f.binder)


def term_data(t):
    if t.kind == "var":
        return ["var", t.name]
    if t.kind == "zero":
        return ["zero"]
    if t.kind == "succ":
        return ["S", term_data(t.args[0])]
    return ["R", term_data(t.descriptor), *(term_data(a) for a in t.args)]


def formula_data(f):
    if f.kind == "eq":
        return ["eq", *(term_data(t) for t in f.terms)]
    if f.kind in ("all", "exists"):
        return [f.kind, f.binder, formula_data(f.children[0])]
    return [f.kind, *(formula_data(c) for c in f.children)]


def parse_term(data):
    if not isinstance(data, list) or not data:
        raise ValueError("Expected a term encoded as a nonempty JSON array.")
    if data[0] == "var" and len(data) == 2 and isinstance(data[1], str):
        return var(data[1])
    if data == ["zero"]:
        return ZERO
    if data[0] == "S" and len(data) == 2:
        return succ(parse_term(data[1]))
    if data[0] == "R" and len(data) == 4:
        return rec(*(parse_term(d) for d in data[1:]))
    raise ValueError(f"Unrecognized term node: {data[0]!r}")


def evaluate(t, environment, budget=None):
    """External testing only. Every evaluation step consumes finite fuel."""
    if budget is None:
        budget = [200_000]
    budget[0] -= 1
    if budget[0] < 0:
        raise RuntimeError("External test-evaluator fuel exhausted.")
    if t.kind == "var":
        return environment[t.name]
    if t.kind == "zero":
        return 0
    if t.kind == "succ":
        return 1 + evaluate(t.args[0], environment, budget)
    count = evaluate(t.args[0], environment, budget)
    state = evaluate(t.args[1], environment, budget)
    if count > budget[0]:
        raise RuntimeError("External test-evaluator recursion bound exceeded.")
    for counter in range(count):
        state = evaluate(t.descriptor, {"v": state, "w": counter}, budget)
    return state


def evaluate_formula(f, environment):
    if f.kind == "eq":
        return evaluate(f.terms[0], environment) == evaluate(f.terms[1], environment)
    if f.kind == "bottom":
        return False
    a, b = (evaluate_formula(c, environment) for c in f.children)
    if f.kind == "and":
        return a and b
    if f.kind == "or":
        return a or b
    if f.kind == "implies":
        return not a or b
    raise ValueError("External evaluation is limited to the binary QF basis.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    request = json.loads(args.input.read_text())
    mode = request.get("mode", "atomic")
    if mode == "atomic":
        label, result = atomic_emitter(parse_term(request["left"]),
                                       parse_term(request["right"]))
    elif mode == "nonzero":
        # The CLI deliberately never accepts an unchecked Boolean certificate.
        label, result = nonzero_emitter(parse_term(request["term"]))
    else:
        raise ValueError("Mode must be 'atomic' or 'nonzero'.")
    answer = {"selected": label, "full_size": formula_size(result) if result else 0,
              "active_size": formula_size(result, False) if result else 0,
              "formula": formula_data(result) if result else None,
              "status": "literal syntax emission, not a full proof certificate"}
    payload = json.dumps(answer, indent=2) + "\n"
    if args.output:
        args.output.write_text(payload)
    else:
        print(payload, end="")


if __name__ == "__main__":
    main()
