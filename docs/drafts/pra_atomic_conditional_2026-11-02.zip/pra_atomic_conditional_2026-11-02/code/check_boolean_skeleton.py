#!/usr/bin/env python3
"""Certify a local two-gate obstruction for the conditional boundary matrix.

The five independent propositional leaves are P,A,B,C,D.  The target is

    if P then (A -> B) else (C -> D),

restricted to assignments satisfying not (A and C).  In the arithmetic
application A is x=S(b), B is b=n, C is x=b, and D is b=0.  The restriction
expresses S(b) != b.  Every assignment satisfying it is realized in N.

The claim concerns formula trees with at most two truth-functional gates,
each of fan-in at most three, and these five leaves.  All five leaves are
essential even on the restricted domain.  Consequently a two-gate tree
would use each leaf exactly once: a three-variable inner gate feeds one
input of a three-input outer gate.  This verifier checks all ten choices
of the inner three variables.  A triangle in the conflict graph prevents
the inner truth function from summarizing those variables into one bit.

Gate truth functions are entirely unrestricted; this is not merely a
search through selected standard connectives.  This certificate is not a
lower bound for different arithmetic atoms, different axiom schemes,
shared circuits, larger-fan-in connectives, or global theory descriptions.
"""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
from typing import Iterable


NAMES = ("P", "A", "B", "C", "D")
BITS = (False, True)
ASSIGNMENTS = tuple(itertools.product(BITS, repeat=5))


def admissible(values: tuple[bool, ...]) -> bool:
    return not (values[1] and values[3])


def target(values: tuple[bool, ...]) -> bool:
    p, a, b, c, d = values
    return ((not a) or b) if p else ((not c) or d)


def bit_map(names: Iterable[str], values: Iterable[bool]) -> dict[str, int]:
    return {name: int(value) for name, value in zip(names, values, strict=True)}


def full_values(
    inner_indices: tuple[int, ...],
    inner: tuple[bool, ...],
    outer_indices: tuple[int, ...],
    outer: tuple[bool, ...],
) -> tuple[bool, ...]:
    values = [False] * 5
    for i, value in zip(inner_indices, inner, strict=True):
        values[i] = value
    for i, value in zip(outer_indices, outer, strict=True):
        values[i] = value
    return tuple(values)


def essentiality_certificates() -> list[dict]:
    certificates = []
    for index, name in enumerate(NAMES):
        witness = None
        for left in ASSIGNMENTS:
            right_list = list(left)
            right_list[index] = not right_list[index]
            right = tuple(right_list)
            if admissible(left) and admissible(right) and target(left) != target(right):
                witness = {
                    "variable": name,
                    "left": bit_map(NAMES, left),
                    "right": bit_map(NAMES, right),
                    "left_target": int(target(left)),
                    "right_target": int(target(right)),
                }
                break
        if witness is None:
            raise AssertionError(f"No essentiality witness for {name}")
        certificates.append(witness)
    return certificates


def natural_number_realizations() -> list[dict]:
    """Realize every admissible tuple (A,B,C,D) by actual n,b,x."""
    results = []
    for a, target_equal, c, zero_equal in itertools.product(BITS, repeat=4):
        if a and c:
            continue
        boundary = 0 if zero_equal else 1
        target_number = boundary if target_equal else boundary + 1
        probe = boundary + 1 if a else boundary if c else boundary + 2
        actual = (
            probe == boundary + 1,
            boundary == target_number,
            probe == boundary,
            boundary == 0,
        )
        expected = (a, target_equal, c, zero_equal)
        if actual != expected:
            raise AssertionError((actual, expected))
        results.append({
            "atoms": bit_map(("A", "B", "C", "D"), expected),
            "b": boundary,
            "n": target_number,
            "x": probe,
        })
    if len(results) != 12:
        raise AssertionError("Expected twelve endpoint assignments")
    return results


def conflict_certificate(inner_indices: tuple[int, ...]) -> dict:
    outer_indices = tuple(i for i in range(5) if i not in inner_indices)
    inner_names = tuple(NAMES[i] for i in inner_indices)
    outer_names = tuple(NAMES[i] for i in outer_indices)
    inner_values = tuple(itertools.product(BITS, repeat=3))
    outer_values = tuple(itertools.product(BITS, repeat=2))
    edges: dict[tuple[int, int], tuple[bool, ...]] = {}

    # An edge means that these inner assignments must receive different
    # bits from any proposed inner gate: one common outer assignment
    # produces different required target values on admissible inputs.
    for left_index, right_index in itertools.combinations(range(8), 2):
        for outer in outer_values:
            left = full_values(
                inner_indices, inner_values[left_index], outer_indices, outer
            )
            right = full_values(
                inner_indices, inner_values[right_index], outer_indices, outer
            )
            if admissible(left) and admissible(right) and target(left) != target(right):
                edges[left_index, right_index] = outer
                break

    triangle = next(
        (vertices for vertices in itertools.combinations(range(8), 3)
         if all(edge in edges for edge in itertools.combinations(vertices, 2))),
        None,
    )
    if triangle is None:
        raise AssertionError(f"No triangle for inner block {inner_names}")

    edge_certificates = []
    for left_index, right_index in itertools.combinations(triangle, 2):
        outer = edges[left_index, right_index]
        left = full_values(inner_indices, inner_values[left_index], outer_indices, outer)
        right = full_values(inner_indices, inner_values[right_index], outer_indices, outer)
        # Revalidate the displayed certificate rather than trusting only
        # the earlier graph construction.
        assert admissible(left) and admissible(right)
        assert target(left) != target(right)
        assert all(left[i] == right[i] for i in outer_indices)
        edge_certificates.append({
            "inner_vertex_indices": [left_index, right_index],
            "common_outer_assignment": bit_map(outer_names, outer),
            "left_full_assignment": bit_map(NAMES, left),
            "right_full_assignment": bit_map(NAMES, right),
            "left_target": int(target(left)),
            "right_target": int(target(right)),
        })

    return {
        "inner_variables": list(inner_names),
        "outer_variables": list(outer_names),
        "graph_vertex_count": 8,
        "graph_edge_count": len(edges),
        "triangle_vertex_indices": list(triangle),
        "triangle_inner_assignments": [
            bit_map(inner_names, inner_values[index]) for index in triangle
        ],
        "triangle_edges": edge_certificates,
        "one_bit_summary_impossible": True,
    }


def build_result() -> dict:
    valid = tuple(values for values in ASSIGNMENTS if admissible(values))
    assert len(valid) == 24
    blocks = [conflict_certificate(indices)
              for indices in itertools.combinations(range(5), 3)]
    assert len(blocks) == 10
    return {
        "claim": "No exact two-gate formula tree with fan-in at most three",
        "target": "C(P, A -> B, C -> D)",
        "conditional_semantics": "if first argument then second else third",
        "domain_constraint": "not (A and C)",
        "admissible_assignment_count": len(valid),
        "true_target_count": sum(map(target, valid)),
        "false_target_count": sum(not target(values) for values in valid),
        "essentiality_certificates": essentiality_certificates(),
        "endpoint_meanings": {
            "A": "x = S(b)", "B": "b = n", "C": "x = b", "D": "b = 0"
        },
        "natural_number_endpoint_realizations": natural_number_realizations(),
        "inner_block_count": len(blocks),
        "inner_blocks": blocks,
        "all_blocks_have_triangle": True,
        "scope": [
            "Only these five propositional leaves and the stated domain constraint",
            "Formula trees, not circuits with additional sharing",
            "At most two Boolean truth-functional gates, each of arity at most three",
            "No restriction on the gates' Boolean truth tables",
            "Exact equality with the target on every admissible assignment",
            "No global lower bound for other axioms, atoms, encodings, or theories",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Write the JSON certificate here")
    args = parser.parse_args()
    payload = json.dumps(build_result(), indent=2, sort_keys=True) + "\n"
    if args.output is None:
        print(payload, end="")
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
        print(f"Verified ten inner blocks; certificate written to {args.output}")


if __name__ == "__main__":
    main()
