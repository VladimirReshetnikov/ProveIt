import Init

/-!
Constructive local certificates for atomic conditional boundary arithmetic.

This file checks only the kernels explicitly stated below. It does not formalize
the descriptor grammar, the complete arithmetic bootstrap, pairing, proof
translation, or the model-theoretic bi-interpretation of the paper.

No classical choice, excluded-middle axiom, or additional axiom is introduced.
The scanner is checked on Lean's inductive Nat; its corresponding first-order
PRA proof is the quantifier-free invariant supplied in the written paper.
-/

namespace AtomicConditional

universe u

def Conditional (condition positive negative : Prop) : Prop :=
  (condition ∧ positive) ∨ (¬condition ∧ negative)

def Boundary {α : Type u} (zero : α) (succ : α → α)
    (predicate : α → Prop) (target witness : α) : Prop :=
  (witness = zero ∨ predicate witness) ∧
    (predicate (succ witness) → witness = target)

def PositiveTable {α : Type u} (zero : α) (succ : α → α)
    (predicate : α → Prop) (target witness : α) : Prop :=
  ∀ probe, Conditional (predicate probe)
    (probe = succ witness → witness = target)
    (probe = witness → witness = zero)

def NegativeTable {α : Type u} (zero : α) (succ : α → α)
    (predicate : α → Prop) (target witness : α) : Prop :=
  ∀ probe, Conditional (predicate probe)
    (probe = witness → witness = zero)
    (probe = succ witness → witness = target)

theorem conditional_decides {condition positive negative : Prop}
    (hypothesis : Conditional condition positive negative) :
    condition ∨ ¬condition := by
  cases hypothesis with
  | inl branch => exact Or.inl branch.1
  | inr branch => exact Or.inr branch.1

theorem positive_table_boundary {α : Type u} {zero : α} {succ : α → α}
    {predicate : α → Prop} {target witness : α}
    (table : PositiveTable zero succ predicate target witness) :
    Boundary zero succ predicate target witness := by
  constructor
  · cases table witness with
    | inl branch => exact Or.inr branch.1
    | inr branch => exact Or.inl (branch.2 rfl)
  · intro next_holds
    cases table (succ witness) with
    | inl branch => exact branch.2 rfl
    | inr branch => exact False.elim (branch.1 next_holds)

theorem negative_table_boundary {α : Type u} {zero : α} {succ : α → α}
    {predicate : α → Prop} {target witness : α}
    (table : NegativeTable zero succ predicate target witness) :
    Boundary zero succ (fun value => ¬predicate value) target witness := by
  constructor
  · cases table witness with
    | inl branch => exact Or.inl (branch.2 rfl)
    | inr branch => exact Or.inr branch.1
  · intro next_fails
    cases table (succ witness) with
    | inl branch => exact False.elim (next_fails branch.1)
    | inr branch => exact branch.2 rfl

theorem positive_table_of_boundary {α : Type u} {zero : α} {succ : α → α}
    {predicate : α → Prop} {target witness : α}
    (boundary : Boundary zero succ predicate target witness)
    (decisions : ∀ value, predicate value ∨ ¬predicate value) :
    PositiveTable zero succ predicate target witness := by
  intro probe
  cases decisions probe with
  | inl holds =>
      apply Or.inl
      constructor
      · exact holds
      · intro at_next
        exact boundary.2 (at_next ▸ holds)
  | inr fails =>
      apply Or.inr
      constructor
      · exact fails
      · intro at_witness
        cases boundary.1 with
        | inl at_zero => exact at_zero
        | inr holds => exact False.elim (fails (at_witness.symm ▸ holds))

theorem positive_table_iff {α : Type u} {zero : α} {succ : α → α}
    {predicate : α → Prop} {target witness : α} :
    PositiveTable zero succ predicate target witness ↔
      Boundary zero succ predicate target witness ∧
        (∀ value, predicate value ∨ ¬predicate value) := by
  constructor
  · intro table
    exact ⟨positive_table_boundary table,
      fun value => conditional_decides (table value)⟩
  · intro facts
    exact positive_table_of_boundary facts.1 facts.2

theorem boundary_induction {α : Type u} {zero : α} {succ : α → α}
    {predicate : α → Prop}
    (boundaries : ∀ target, ∃ witness, Boundary zero succ predicate target witness)
    (base : predicate zero)
    (progress : ∀ value, predicate value → predicate (succ value)) :
    ∀ target, predicate target := by
  intro target
  obtain ⟨witness, first, second⟩ := boundaries target
  have at_witness : predicate witness := by
    cases first with
    | inl at_zero => exact at_zero.symm ▸ base
    | inr holds => exact holds
  have at_target : witness = target := second (progress witness at_witness)
  exact at_target ▸ at_witness

theorem positive_table_induction {α : Type u} {zero : α} {succ : α → α}
    {predicate : α → Prop}
    (tables : ∀ target, ∃ witness, PositiveTable zero succ predicate target witness)
    (base : predicate zero)
    (progress : ∀ value, predicate value → predicate (succ value)) :
    ∀ target, predicate target := by
  apply boundary_induction (base := base) (progress := progress)
  intro target
  obtain ⟨witness, table⟩ := tables target
  exact ⟨witness, positive_table_boundary table⟩

theorem negative_table_induction {α : Type u} {zero : α} {succ : α → α}
    {predicate : α → Prop}
    (tables : ∀ target, ∃ witness, NegativeTable zero succ predicate target witness)
    (base : ¬predicate zero)
    (progress : ∀ value, ¬predicate value → ¬predicate (succ value)) :
    ∀ target, ¬predicate target := by
  apply boundary_induction (predicate := fun value => ¬predicate value)
    (base := base) (progress := progress)
  intro target
  obtain ⟨witness, table⟩ := tables target
  exact ⟨witness, negative_table_boundary table⟩

theorem coverage_from_atomic_boundary {α : Type u} {zero : α}
    {succ predecessor : α → α}
    (predecessor_succ : ∀ value, predecessor (succ value) = value)
    (boundaries : ∀ target, ∃ witness,
      Boundary zero succ (fun value => value = succ (predecessor value))
        target witness) :
    ∀ value, value = zero ∨ value = succ (predecessor value) := by
  intro target
  obtain ⟨witness, first, second⟩ := boundaries target
  have next_holds : succ witness = succ (predecessor (succ witness)) :=
    congrArg succ (predecessor_succ witness).symm
  have at_target : witness = target := second next_holds
  exact at_target ▸ first

theorem coverage_from_atomic_table {α : Type u} {zero : α}
    {succ predecessor : α → α}
    (predecessor_succ : ∀ value, predecessor (succ value) = value)
    (tables : ∀ target, ∃ witness,
      PositiveTable zero succ (fun value => value = succ (predecessor value))
        target witness) :
    ∀ value, value = zero ∨ value = succ (predecessor value) := by
  apply coverage_from_atomic_boundary predecessor_succ
  intro target
  obtain ⟨witness, table⟩ := tables target
  exact ⟨witness, positive_table_boundary table⟩

theorem equality_decidable_from_atomic_tables {α : Type u}
    {zero : α} {succ : α → α}
    (tables : ∀ parameter target, ∃ witness,
      PositiveTable zero succ (fun value => value = parameter) target witness) :
    ∀ left right : α, left = right ∨ left ≠ right := by
  intro left right
  obtain ⟨witness, table⟩ := tables right zero
  exact conditional_decides (table left)

/- The size-selecting variant retains the conditional table for S^3 x = S^3 a. -/
theorem equality_decidable_from_padded_tables {α : Type u}
    {zero : α} {succ : α → α}
    (successor_injective : ∀ left right,
      succ left = succ right → left = right)
    (tables : ∀ parameter target, ∃ witness,
      PositiveTable zero succ
        (fun value => succ (succ (succ value)) = succ (succ (succ parameter)))
        target witness) :
    ∀ left right : α, left = right ∨ left ≠ right := by
  intro left right
  obtain ⟨witness, table⟩ := tables right zero
  cases conditional_decides (table left) with
  | inl equal =>
      exact Or.inl
        (successor_injective _ _
          (successor_injective _ _ (successor_injective _ _ equal)))
  | inr unequal =>
      apply Or.inr
      intro equal
      exact unequal (congrArg (fun value => succ (succ (succ value))) equal)

/- The smaller unit extractor needs only the stated local arithmetic facts. -/

def unitBit {α : Type u} (zero : α) (succ : α → α)
    (q z : α → α → α) (value : α) : α :=
  z (q value (succ zero)) (succ zero)

theorem unit_bit_spec {α : Type u} {zero : α} {succ : α → α}
    {q z : α → α → α}
    (separation : zero ≠ succ zero)
    (q_zero : ∀ initial, q zero initial = initial)
    (q_succ : ∀ value initial, q (succ value) initial = value)
    (z_zero : ∀ initial, z zero initial = initial)
    (z_succ : ∀ value initial, z (succ value) initial = zero)
    (coverage : ∀ value, value = zero ∨ ∃ prior, value = succ prior) :
    ∀ value, (unitBit zero succ q z value = zero ∨
        unitBit zero succ q z value = succ zero) ∧
      (unitBit zero succ q z value = succ zero ↔ value = succ zero) := by
  intro value
  have successor_injective : ∀ left right,
      succ left = succ right → left = right := by
    intro left right equality
    have transported := congrArg (fun input => q input zero) equality
    change q (succ left) zero = q (succ right) zero at transported
    rw [q_succ, q_succ] at transported
    exact transported
  have successor_nonzero : ∀ input, succ input ≠ zero := by
    intro input equality
    have transported := congrArg (fun argument => q argument zero) equality
    change q (succ input) zero = q zero zero at transported
    rw [q_succ, q_zero] at transported
    have impossible : succ zero = zero := transported ▸ equality
    exact separation impossible.symm
  cases coverage value with
  | inl at_zero =>
      subst value
      have bit_zero : unitBit zero succ q z zero = zero := by
        unfold unitBit
        rw [q_zero, z_succ]
      constructor
      · exact Or.inl bit_zero
      · constructor
        · intro equality
          exact False.elim (separation (bit_zero.symm.trans equality))
        · intro equality
          exact False.elim (separation equality)
  | inr as_successor =>
      obtain ⟨prior, at_successor⟩ := as_successor
      subst value
      cases coverage prior with
      | inl at_zero =>
          subst prior
          have bit_one : unitBit zero succ q z (succ zero) = succ zero := by
            unfold unitBit
            rw [q_succ, z_zero]
          exact ⟨Or.inr bit_one, ⟨fun _ => rfl, fun _ => bit_one⟩⟩
      | inr as_successor =>
          obtain ⟨earlier, at_successor⟩ := as_successor
          subst prior
          have bit_zero : unitBit zero succ q z (succ (succ earlier)) = zero := by
            unfold unitBit
            rw [q_succ, z_succ]
          constructor
          · exact Or.inl bit_zero
          · constructor
            · intro equality
              exact False.elim (separation (bit_zero.symm.trans equality))
            · intro equality
              exact False.elim
                (successor_nonzero earlier (successor_injective _ _ equality))

theorem equality_bit_from_unit_recognizer {α : Type u}
    {zero : α} {succ : α → α} {q z difference : α → α → α}
    (unit_spec : ∀ value,
      unitBit zero succ q z value = succ zero ↔ value = succ zero)
    (unit_recognizer : ∀ left right,
      difference (succ left) right = succ zero ↔ left = right) :
    ∀ left right,
      unitBit zero succ q z (difference (succ left) right) = succ zero ↔
        left = right := by
  intro left right
  exact (unit_spec _).trans (unit_recognizer left right)

/- Zero represents truth in the smaller, unnormalized arithmetic compiler. -/

theorem raw_unit_recognizer {α : Type u} {zero : α} {succ : α → α}
    {q : α → α → α}
    (separation : zero ≠ succ zero)
    (q_zero : ∀ initial, q zero initial = initial)
    (q_succ : ∀ value initial, q (succ value) initial = value)
    (coverage : ∀ value, value = zero ∨ ∃ prior, value = succ prior) :
    ∀ value, q value (succ zero) = zero ↔ value = succ zero := by
  intro value
  constructor
  · intro recognized
    cases coverage value with
    | inl at_zero =>
        subst value
        rw [q_zero] at recognized
        exact False.elim (separation recognized.symm)
    | inr as_successor =>
        obtain ⟨prior, at_successor⟩ := as_successor
        subst value
        rw [q_succ] at recognized
        exact congrArg succ recognized
  · intro at_one
    subst value
    exact q_succ zero (succ zero)

theorem raw_equality_from_unit_recognizer {α : Type u}
    {zero : α} {succ : α → α} {q difference : α → α → α}
    (raw_unit : ∀ value, q value (succ zero) = zero ↔ value = succ zero)
    (residual_unit : ∀ left right,
      difference (succ left) right = succ zero ↔ left = right) :
    ∀ left right,
      q (difference (succ left) right) (succ zero) = zero ↔ left = right := by
  intro left right
  exact (raw_unit _).trans (residual_unit left right)

theorem successor_nonzero_from_z {α : Type u} {zero : α} {succ : α → α}
    {z : α → α → α}
    (separation : zero ≠ succ zero)
    (z_zero : ∀ initial, z zero initial = initial)
    (z_succ : ∀ value initial, z (succ value) initial = zero) :
    ∀ value, succ value ≠ zero := by
  intro value at_zero
  have recognized := z_succ value (succ zero)
  rw [at_zero, z_zero] at recognized
  exact separation recognized.symm

theorem zero_implication_gate {α : Type u} {zero : α} {succ : α → α}
    {z : α → α → α}
    (z_zero : ∀ initial, z zero initial = initial)
    (z_succ : ∀ value initial, z (succ value) initial = zero)
    (coverage : ∀ value, value = zero ∨ ∃ prior, value = succ prior) :
    ∀ left right, z left right = zero ↔ (left = zero → right = zero) := by
  intro left right
  constructor
  · intro recognized at_zero
    subst left
    rw [z_zero] at recognized
    exact recognized
  · intro implication
    cases coverage left with
    | inl at_zero =>
        subst left
        rw [z_zero]
        exact implication rfl
    | inr as_successor =>
        obtain ⟨prior, at_successor⟩ := as_successor
        subst left
        exact z_succ prior right

theorem zero_conjunction_gate {α : Type u} {zero : α} {succ : α → α}
    {z add : α → α → α}
    (separation : zero ≠ succ zero)
    (z_zero : ∀ initial, z zero initial = initial)
    (z_succ : ∀ value initial, z (succ value) initial = zero)
    (add_zero : ∀ left, add left zero = left)
    (add_succ : ∀ left right, add left (succ right) = succ (add left right))
    (coverage : ∀ value, value = zero ∨ ∃ prior, value = succ prior) :
    ∀ left right, add left right = zero ↔ (left = zero ∧ right = zero) := by
  intro left right
  constructor
  · intro recognized
    cases coverage right with
    | inl at_zero =>
        subst right
        rw [add_zero] at recognized
        exact ⟨recognized, rfl⟩
    | inr as_successor =>
        obtain ⟨prior, at_successor⟩ := as_successor
        subst right
        rw [add_succ] at recognized
        exact False.elim
          (successor_nonzero_from_z separation z_zero z_succ _ recognized)
  · intro both_zero
    obtain ⟨left_zero, right_zero⟩ := both_zero
    subst left
    subst right
    exact add_zero zero

theorem zero_disjunction_gate {α : Type u} {zero : α} {succ : α → α}
    {z : α → α → α}
    (z_zero : ∀ initial, z zero initial = initial)
    (z_succ : ∀ value initial, z (succ value) initial = zero)
    (coverage : ∀ value, value = zero ∨ ∃ prior, value = succ prior) :
    ∀ left right,
      z (z left (succ zero)) right = zero ↔ (left = zero ∨ right = zero) := by
  intro left right
  constructor
  · intro recognized
    cases coverage left with
    | inl at_zero => exact Or.inl at_zero
    | inr as_successor =>
        obtain ⟨prior, at_successor⟩ := as_successor
        subst left
        rw [z_succ, z_zero] at recognized
        exact Or.inr recognized
  · intro one_zero
    cases one_zero with
    | inl at_zero =>
        subst left
        rw [z_zero, z_succ]
    | inr at_zero =>
        subst right
        cases coverage left with
        | inl at_zero =>
            subst left
            rw [z_zero, z_succ]
        | inr as_successor =>
            obtain ⟨prior, at_successor⟩ := as_successor
            subst left
            rw [z_succ, z_zero]

theorem normalize_zero_code {α : Type u} {zero : α} {succ : α → α}
    {z : α → α → α}
    (separation : zero ≠ succ zero)
    (z_zero : ∀ initial, z zero initial = initial)
    (z_succ : ∀ value initial, z (succ value) initial = zero)
    (coverage : ∀ value, value = zero ∨ ∃ prior, value = succ prior) :
    ∀ value, (z value (succ zero) = zero ∨ z value (succ zero) = succ zero) ∧
      (z value (succ zero) = succ zero ↔ value = zero) := by
  intro value
  cases coverage value with
  | inl at_zero =>
      subst value
      constructor
      · exact Or.inr (z_zero (succ zero))
      · exact ⟨fun _ => rfl, fun _ => z_zero (succ zero)⟩
  | inr as_successor =>
      obtain ⟨prior, at_successor⟩ := as_successor
      subst value
      constructor
      · exact Or.inl (z_succ prior (succ zero))
      · constructor
        · intro recognized
          rw [z_succ] at recognized
          exact False.elim (separation recognized)
        · intro at_zero
          exact False.elim
            (successor_nonzero_from_z separation z_zero z_succ prior at_zero)

/- A concrete check of the quantifier-free boundary-witness invariant. -/

def scan (predicate : Nat → Prop) [DecidablePred predicate] : Nat → Nat
  | 0 => 0
  | Nat.succ counter =>
      if predicate (Nat.succ (scan predicate counter))
      then Nat.succ (scan predicate counter)
      else scan predicate counter

theorem scan_invariant (predicate : Nat → Prop) [DecidablePred predicate] :
    ∀ counter, Boundary 0 Nat.succ predicate counter (scan predicate counter) := by
  intro counter
  induction counter with
  | zero => exact ⟨Or.inl rfl, fun _ => rfl⟩
  | succ counter induction_hypothesis =>
      by_cases next_holds : predicate (Nat.succ (scan predicate counter))
      · simp only [scan, if_pos next_holds]
        constructor
        · exact Or.inr next_holds
        · intro _
          exact congrArg Nat.succ (induction_hypothesis.2 next_holds)
      · simp only [scan, if_neg next_holds]
        constructor
        · exact induction_hypothesis.1
        · intro contradiction
          exact False.elim (next_holds contradiction)

theorem scan_positive_table (predicate : Nat → Prop) [DecidablePred predicate]
    (target : Nat) :
    PositiveTable 0 Nat.succ predicate target (scan predicate target) := by
  apply positive_table_of_boundary (scan_invariant predicate target)
  intro value
  by_cases holds : predicate value
  · exact Or.inl holds
  · exact Or.inr holds

theorem nat_positive_tables (predicate : Nat → Prop) [DecidablePred predicate] :
    ∀ target, ∃ witness, PositiveTable 0 Nat.succ predicate target witness := by
  intro target
  exact ⟨scan predicate target, scan_positive_table predicate target⟩

#print axioms positive_table_boundary
#print axioms negative_table_boundary
#print axioms positive_table_iff
#print axioms positive_table_induction
#print axioms negative_table_induction
#print axioms coverage_from_atomic_table
#print axioms equality_decidable_from_atomic_tables
#print axioms equality_decidable_from_padded_tables
#print axioms unit_bit_spec
#print axioms equality_bit_from_unit_recognizer
#print axioms raw_unit_recognizer
#print axioms raw_equality_from_unit_recognizer
#print axioms zero_implication_gate
#print axioms zero_conjunction_gate
#print axioms zero_disjunction_gate
#print axioms normalize_zero_code
#print axioms scan_invariant
#print axioms nat_positive_tables

end AtomicConditional
