"""Verify frozen source identities and reproduce the whole-file comparison."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import platform
import tempfile
import tokenize

ROOT = Path(__file__).resolve().parent


def main():
    specification = importlib.util.spec_from_file_location(
        "inherited_measure", ROOT / "kernel" / "measure_source.py")
    measure = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(measure)
    manifest = json.loads((ROOT / "reference" / "manifest.json").read_text())
    rows = []
    for entry in manifest["programs"]:
        path = ROOT / entry["local_file"]
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != entry["sha256"]:
            raise ValueError("Changed inherited source: " + entry["local_file"])
        rows.append({**entry, **measure.metrics(path)})
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    result = {
        "python": platform.python_version(),
        "snapshot": manifest["snapshot"],
        "programs": rows,
        "coordinatewise_minimum": {
            key: min(row[key] for row in rows) for key in fields},
        "scope": "Frozen leading complete native programs, whole-module metric."
    }
    names = {"inst": "i", "check": "c", "take": "q"}
    source = (ROOT / "reference" / "compact_open.py").read_text()
    tokens = [token._replace(string=names.get(token.string, token.string))
              if token.type == tokenize.NAME else token
              for token in tokenize.generate_tokens(io.StringIO(source).readline)]
    with tempfile.TemporaryDirectory(prefix="ipra-name-control-") as scratch:
        candidate = Path(scratch) / "compact_open_short.py"
        candidate.write_text(tokenize.untokenize(tokens))
        result["inherited_uniform_name_control"] = measure.metrics(candidate)
    output = ROOT / "evidence" / "frontier_reproduced.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({
        "coordinatewise_minimum": result["coordinatewise_minimum"],
        "uniform_name_control": {
            key: result["inherited_uniform_name_control"][key] for key in fields}
    }, indent=2))


if __name__ == "__main__":
    main()
