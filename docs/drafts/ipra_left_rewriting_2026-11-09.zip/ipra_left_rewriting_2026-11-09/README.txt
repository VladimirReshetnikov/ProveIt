LEFT REWRITING FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Research report prepared for Vladimir Reshetnikov, 9 November 2026

STATUS
------
The package gives a complete native axiomatization, full proof translations,
and whole-domain bi-interpretability of its faithful ordinary first-order
realization with iPRA. That realization explicitly includes (0=1)->bottom.
The native calculus itself designates 0=1 as falsity and derives explosion.

The new equality rule replaces only the root or one immediate argument of
the LEFT side of an equation, in the forward direction, using any checked
equation proof as source. General equality reasoning is derived. A small
vacuous-binder argument proves that the old source-provenance restriction
adds no consequence. Both interpretation composites and the full logical
and nonlogical inventory are supplied.

The complete checker is smaller than the matched local-rewriting baseline:
                  tokens    AST nodes    normalized bytes
  baseline          3287        3650               16192
  new               3160        3501               15674
  saving             127         149                 518

This does NOT beat the current compact native coordinate envelope
306 / 340 / 839. The requested global minimum-breaking breakthrough remains
unestablished. The paper distinguishes those compact programs' different
malformed-input contracts and the name sensitivity of byte measurements.

START HERE
----------
report.pdf                   Complete mathematical report.
report.tex                   Standalone editable LaTeX source.
frontmatter.tex, 01_*.tex     Modular sources used by build.py.
kernel/README.txt            Exact certificate format and executable details.
kernel/shallow_checker.py    Recommended standalone acceptance algorithm.
kernel/shallow_migrate.py    Untrusted old-to-new proof compiler.
kernel/SOURCE_CHANGE.patch   Complete final source difference.
kernel/source_examples/     Nine unchanged inherited proof certificates.
kernel/shallow_examples/    Translated and focused checked certificates.
kernel/*verification.json   Detailed verification receipts.
kernel/*measurements.json   Whole-program metrics and matched savings.
reference/                  Frozen leading compact comparators.
evidence/                   Pinned source identities, audits, and build log.
ATTRIBUTION.txt              Sources and contribution boundaries.
LICENSE-inherited.txt       License supplied with inherited material.
SHA256SUMS                  Payload integrity list, excluding itself.

PROOF SIZE
----------
For the stated old-to-shallow compiler, the exact tree-node formula is

  N_new = N_old + 4 V + 8 W + 8 sum(max(d-1,0)),

where V counts reverse source uses, W counts right-side rewrites, and d is
each old rewrite path's length. The compiler introduces no new binders,
eigenvariables, local assumptions, contexts, or clause indices. The formula
is about proof nodes, not serialized bytes or optimal proof length.

REPRODUCE
---------
Use Python 3.12 and its standard library (tested CPython 3.12.14).
From this package's root directory:

  python3 kernel/verify_shallow.py
  python3 kernel/verify.py
  python3 audit_frontier.py

To check one final certificate:

  python3 kernel/shallow_checker.py < kernel/shallow_examples/compound_depth_3.json

Expected verdict: ACCEPT, exit 0. Invalid public packets print REJECT and
exit 1. The checker does not import the compiler or another checker.
The producer uses the baseline and new checker only to validate its work.

To rebuild the standalone source and PDF:

  python3 build.py

This requires a normally configured pdfLaTeX installation and the standard
packages listed in frontmatter.tex. Shell escape is disabled. The already
compiled PDF is included. No network is required for any reproduction.

EVIDENCE LIMITS
---------------
The main metatheorems are mathematical proofs, independently reviewed by
assistant agents. They are not Lean/Rocq formalizations or external peer
review. Finite certificate checks cover all nine inherited examples, all
four direction/side combinations, deep occurrences, retained open contexts,
scope rejection, and malformed/obsolete instruction fields. They supplement
the written proof; they do not by themselves prove the metatheorems.

SOURCE SNAPSHOT
---------------
Repository: VladimirReshetnikov/ProveIt
Commit: 572c3ef372fb22e30951af30bf1041efcffc8b7d
Directory: docs/drafts
All twelve current ZIP archives were checked by length and Git blob SHA-1;
their SHA-256 identities are included. The repository was read only.
