"""Build the self-contained LaTeX source and its PDF; no network is used."""
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
PARTS = ["frontmatter.tex", "01_scope.tex", "02_rewriting.tex",
         "03_logic.tex", "04_arithmetic.tex", "05_evidence.tex"]


def main():
    source = "\n\n".join((ROOT / name).read_text(encoding="utf-8")
                           for name in PARTS)
    (ROOT / "report.tex").write_text(source, encoding="utf-8")
    evidence = ROOT / "evidence"
    evidence.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="ipra-latex-") as scratch:
        outputs = []
        for _ in range(3):
            result = subprocess.run(
                ["pdflatex", "-halt-on-error", "-interaction=nonstopmode",
                 "-no-shell-escape", "-output-directory", scratch, "report.tex"],
                cwd=ROOT, text=True, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, check=False)
            outputs.append(result.stdout)
            if result.returncode:
                (evidence / "build_stdout.txt").write_text(
                    "\n".join(outputs), encoding="utf-8")
                raise SystemExit(result.returncode)
        shutil.copy2(Path(scratch) / "report.pdf", ROOT / "report.pdf")
        shutil.copy2(Path(scratch) / "report.log", evidence / "build.log")
    print("Built report.tex and report.pdf")


if __name__ == "__main__":
    main()
