"""Verify the shallow arbitrary-source refinement and its proof compiler."""

import copy
import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path

import baseline_checker as B
import shallow_checker as S
import shallow_migrate as M
import measure_source
import verify as V


ROOT = Path(__file__).resolve().parent


def demand(value, message):
    if not value:
        raise ValueError(message)


def check_source():
    V.check_exact_changes()
    source = (ROOT / "checker.py").read_text()
    start = source.index('def replace_at(')
    end = source.index('\n\nclass Checker:', start)
    source = source[:start] + source[end + 2:]
    source = source.replace('"source", "path"', '"source", "slot"')
    source = source.replace(
        '            require(type(source) is dict and source.get("rule") == "use",\n'
        '                    "rewrite source must be a direct clause use")\n', '')
    source = source.replace('''            path = proof["path"]
            require(type(path) is list and all(type(item) is int and item >= 0 for item in path),
                    "rewrite path must be an array of nonnegative integers")
            left = equation[1]
            right = equation[2]
            target = list(old)
            target[1] = replace_at(old[1], path, left, right)
''', '''            slot = proof["slot"]
            require(type(slot) is int and slot >= -1, "rewrite slot must be an integer at least minus one")
            left = equation[1]
            right = equation[2]
            term = old[1]
            if slot == -1:
                require(term == left, "rewrite source is not the whole left term")
                replacement = right
            else:
                require(term[0] != "$" and slot < len(term) - 1,
                        "rewrite slot leaves the numerical term")
                require(term[slot + 1] == left, "rewrite source is not the selected argument")
                replacement = list(term)
                replacement[slot + 1] = right
            target = ["=", replacement, old[2]]
''')
    demand(source == (ROOT / "shallow_checker.py").read_text(),
           "unlisted shallow checker change")


def public_result(packet, optimized=False):
    command = [sys.executable] + (["-O"] if optimized else []) + [str(ROOT / "shallow_checker.py")]
    process = subprocess.run(command, input=json.dumps(packet), text=True,
                             capture_output=True, timeout=60)
    return {"exit_code": process.returncode, "stdout": process.stdout,
            "stderr": process.stderr}


def rejects(packet):
    try:
        S.check_packet(packet)
    except Exception:
        return True
    return False


def main():
    check_source()
    destination = ROOT / "shallow_examples"
    destination.mkdir(exist_ok=True)
    receipts = []
    for path in sorted((ROOT / "source_examples").glob("*.json")):
        packet = json.loads(path.read_text())
        output, stats = M.migrate_packet(packet)
        counts = stats["counts"]
        expected = (stats["source"]["proof_nodes"] + 4*counts["reverse"]
                    + 8*counts["right"] + 8*counts["lifts"])
        demand(stats["target"]["proof_nodes"] == expected, "exact proof-node formula failed")
        target = destination / path.name
        target.write_text(json.dumps(output, indent=2) + "\n")
        receipts.append({"name": path.name, "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                         "output_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
                         "exact_node_formula": True, **stats})
    demand(len(receipts) == 9, "expected all nine inherited examples")

    focused = []
    for reverse in (0, 1):
        for right in (0, 1):
            output, stats = M.migrate_packet(V.focused_packet(reverse, right))
            target = destination / f"focused_reverse_{reverse}_right_{right}.json"
            target.write_text(json.dumps(output, indent=2) + "\n")
            public = [public_result(output, mode) for mode in (False, True)]
            demand(all(item == {"exit_code": 0, "stdout": "ACCEPT\n", "stderr": ""}
                       for item in public), "focused public proof rejected")
            focused.append({"reverse": reverse, "right": right, "stats": stats, "public": public})

    # A retained equation and a deep variable occurrence exercise unchanged
    # contexts/scopes; no compiler-generated binder or clause is needed.
    p, q = ["$", "_fl0"], ["$", "q"]
    equation = ["=", p, q]
    context = [S.hypothesis(equation)]
    source = {"rule": "use", "conclusion": equation, "clause": 0,
              "term": ["0"], "premise": M.comp(["id", ["0"]], ["0"])}
    before = M.comp(["id", ["S", p]], ["S", p])
    open_proof = {"rule": "rw", "conclusion": ["=", ["id", ["S", q]], ["S", p]],
                  "source": source, "before": before, "orientation": 0,
                  "side": 0, "path": [0, 0]}
    open_output, open_stats = M.migrate_derivation(open_proof, [], context, {"_fl0", "q"})
    malformed_scope = copy.deepcopy(open_output)
    try:
        S.Checker([]).check(malformed_scope, context, {"_fl0"})
    except Exception:
        scope_rejected = True
    else:
        scope_rejected = False
    demand(scope_rejected, "free variable escaped its scope")

    seed = json.loads((destination / "reflexivity.json").read_text())
    negatives = []
    for slot in (True, -2, 999, 0.0, [], "0"):
        modified = copy.deepcopy(seed)
        V.first_rewrite(modified["proof"])["slot"] = slot
        demand(rejects(modified), "malformed or out-of-range slot accepted")
        negatives.append({"slot": slot, "rejected": True})
    for field, value in (("orientation", 0), ("side", 0), ("path", [])):
        modified = copy.deepcopy(seed)
        V.first_rewrite(modified["proof"])[field] = value
        demand(rejects(modified), "obsolete rewrite field accepted")
        negatives.append({"extra_field": field, "rejected": True})
    false_packet = {"declarations": [], "goal": ["=", ["0"], ["S", ["0"]]],
                    "proof": {"rule": "comp", "conclusion": ["=", ["0"], ["S", ["0"]]]}}
    public_negative = [public_result(false_packet, mode) for mode in (False, True)]
    demand(all(item == {"exit_code": 1, "stdout": "REJECT\n", "stderr": ""}
               for item in public_negative), "false public equation accepted")

    rows = [{"file": name, **measure_source.metrics(ROOT / name)} for name in
            ("baseline_checker.py", "forward_checker.py", "clause_forward_checker.py",
             "checker.py", "shallow_checker.py")]
    metrics = {"python": platform.python_version(), "rows": rows,
               "matched_saving": {key: rows[0][key] - rows[-1][key]
                                  for key in ("normalized_tokens", "ast_nodes", "normalized_bytes")},
               "global_frontier_beaten": False}
    receipt = {"exact_source_changes_verified": True, "inherited_examples": receipts,
               "focused_examples": focused, "open_context": open_stats,
               "malformed_scope_rejected": scope_rejected, "negative_cases": negatives,
               "negative_public": public_negative,
               "scope": "Finite checks supplement the written proof; no Lean/Rocq metatheory claim."}
    (ROOT / "shallow_measurements.json").write_text(json.dumps(metrics, indent=2) + "\n")
    (ROOT / "shallow_verification.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"inherited_examples": len(receipts), "focused_examples": len(focused),
                      "scope_rejection": scope_rejected, "negative_cases": len(negatives),
                      "metrics": metrics}, indent=2))


if __name__ == "__main__":
    main()
