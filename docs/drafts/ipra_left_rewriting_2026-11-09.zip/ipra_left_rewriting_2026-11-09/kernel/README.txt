FORWARD LEFT REWRITING WITH SHALLOW OCCURRENCES
=============================================

Main executable
---------------

  python3 shallow_checker.py < shallow_examples/compound_depth_3.json

The main verifier reads one JSON proof packet, prints ACCEPT or REJECT, and
exits with status 0 or 1. It imports only the standard-library json module.
It does not import a proof producer, another checker, a theorem oracle, or an
encoded program. The public interface always uses the local calculus.

The files checker.py, clause_forward_checker.py, and forward_checker.py are
intermediate variants retained to isolate the measured changes. The final
variant is shallow_checker.py.

What changed mathematically
---------------------------

The old one-occurrence rewrite operation supported two directions, either
equation side, arbitrary-depth term paths, and only computation/clause-use
sources. The new operation has one fixed direction, rewrites only the LEFT
term, selects only the root or one immediate numerical argument, and allows
ANY independently checked equation proof as its source.

The new rule's exact JSON fields are:

  {"rule":"rw", "conclusion": C, "source": E, "before": P, "slot": j}

E and P are proof trees in the SAME retained context and variable scope.
They must conclude literal equations s=t and u=v. The source E may have any
valid proof head; it must itself check. A bare unproved equation is rejected.

If j=-1, require u=s and conclude t=v.
If j>=0, require u=f(a0,...,ak), j<k+1, and aj=s, and conclude
f(a0,...,a(j-1),t,a(j+1),...,ak)=v.

j must be an actual Python/JSON integer: booleans, floats, strings, arrays,
values below -1, and out-of-bounds argument positions are rejected. Argument
indices exclude the function-name head. Variables and nullary functions have
no numerical argument slots. There is no recursive path visitor in the final
checker. The former orientation, side, and path fields are rejected.

All other declaration, formula, binding, context, logical-rule, parsing,
alpha-equivalence, and public failure checks are inherited without change.
The complete original format is preserved in baseline_format.txt; replace
its rule 5 with the specification above. All other sections still apply.

Numerical presentation and comparison scope
------------------------------------------

This implementation uses the original checker's fixed finite PR-description
declarations: projection, composition, and primitive recursion, with built-in
0, S, and id. It is NOT a direct parser for the older drafts' alternative
closed-update K_h syntax. The equality-rule theorem applies with the numerical
basis held fixed. Moving between equivalent arithmetic bases requires the
arithmetic compilations stated in the mathematical report.

Paired formulas D(x,y,B) retain the original interpretation
exists x (B(x,0) -> forall y B(x,y)). Only literal equation matrices receive
the additional induction hypothesis. Neither arbitrary formula induction nor
classical logic has been added. The inherited Python reference modes for
general/atomic transport remain in the measured source, but the public CLI
cannot enable them.

Why the old operations are derivable
-----------------------------------

1. Reflexivity t=t follows by rewriting the left root of id(t)=t with another
   proof of the same computation equation. This uses three proof nodes.
2. For E:s=t, rewrite the left root of s=s using E to obtain t=s. Symmetry
   adds four nodes to the supplied proof of E.
3. Right-side rewriting is symmetry, left-side rewriting, then symmetry.
4. A source equality can be lifted through one function argument by symmetry,
   reflexivity of the target parent, and a shallow rewrite. Iterate this
   through the inner ancestors, then rewrite the outer argument directly.
5. Allowing arbitrary equation sources does not increase consequence strength:
   in the original calculus, the theorem D(u,y,E) with both binders vacuous
   opens a local clause <E;b.E>. Clause use with the supplied proof of E then
   re-presents E as an admissible neutral source. The older stricter compiler
   migrate.py implements this wrapper explicitly.

These are mathematical derivations, not claims inferred from finite tests.
They establish the matched consequence-equivalence once the inherited base
calculus is fixed. They do not establish a global complexity minimum.

Proof migration
---------------

  python3 shallow_migrate.py source_examples/compound_depth_3.json result.json
  python3 shallow_checker.py < result.json

The producer checks its input with the unchanged baseline, transforms it,
and checks its output independently with shallow_checker.py. The final
compiler introduces NO new binders, eigenvariables, local assumptions,
contexts, or clause indices. It only inserts equation proofs. Thus original
scope and context references are retained exactly.

For tree proof-node counts, let N be the old count, V the number of reversed
rewrite nodes, W the number of right-side rewrite nodes, and
L = sum(max(path_length-1, 0)) over all old rewrite nodes. The output count is
exactly

  N_new = N + 4 V + 8 W + 8 L.

This counts proof-node occurrences, not compressed DAG nodes or bytes of
formula annotations. The exact formula is verified for every included
inherited example. The untrusted implementation uses deep copying for
clarity; the formula is not a bound on its running time.

Reproduce verification and measurements
---------------------------------------

  python3 verify_shallow.py

The script checks the exact allowed source transformations, including the
unchanged baseline and normalizer hashes. It compiles all nine inherited
certificates, checks the exact node formula, exercises all four combinations
of old direction/side choices, checks a retained open context with a deep
variable occurrence, and rejects malformed scope, slots, and obsolete fields.
Public CLI acceptance/rejection is checked in ordinary and optimized Python.
The receipt is shallow_verification.json. All nine original certificates are
preserved byte-for-byte in source_examples/; translated ones are in
shallow_examples/.

The earlier clause-only forward-left variant can separately be reproduced:

  python3 verify.py

It uses explicit vacuous-D wrappers and has the exact larger node formula
N_new=N+5R+14V+28W, where R is the old rewrite-node count. Its files and
receipts are retained as intermediate evidence, not as the recommended kernel.

Measured complete source (CPython 3.12.14)
-----------------------------------------

                                 Tokens   AST nodes   Normalized bytes
  unchanged baseline               3287        3650              16192
  forward only                     3256        3609              15987
  clause-only forward              3252        3606              15962
  clause-only forward left         3221        3565              15813
  arbitrary-source shallow left    3160        3501              15674

Final matched saving: 127 tokens, 149 AST nodes, 518 normalized bytes.
Only actual docstrings/comments are excluded; parsing, syntax, numerical
declarations, references, validation, exception handling, and CLI are counted.
The unchanged inherited normalizer and exact rows are included.

This does NOT beat the entire directory's native-code frontier of
306 tokens / 340 AST nodes / 839 normalized bytes. Those coordinates concern
different compact representations and are not mathematical lower bounds.
No claim of the globally simplest axiomatization or a new global source-size
record is made. These counts support a narrower structural improvement over
the matched readable local-rewriting checker.

Provenance and verification limits
---------------------------------

Original repository: https://github.com/VladimirReshetnikov/ProveIt
Pinned commit: 572c3ef372fb22e30951af30bf1041efcffc8b7d
Original archive: docs/drafts/ipra_local_rewriting_2026-11-09.zip
Original member: ipra_local_rewriting_2026-11-09/code/local_checker.py
Baseline SHA-256:
95831c0899bf861ea272c4c5edc681c31dbda1dd3147ccd907997855b6f10694

baseline_checker.py is an unchanged copy. SOURCE_CHANGE.patch gives the final
complete-source difference. provenance.json records the baseline and source
measurement helper identities. This package preserves attribution to the
user-supplied draft and separates inherited infrastructure from new changes.

The written metatheoretic proof is not formalized in Lean or Rocq. Finite
certificate and rejection checks supplement it. As with the baseline, a
fixed real Python process can reject sufficiently deep valid proofs because
of finite resources; the abstract recursive checker is considered with
sufficient finite resources. No acceptance rule depends on removing a
validation guard or on interpreting certificate data as executable code.
