"""Untrusted compiler from bidirectional local rewriting to forward-left rewriting.

Both input and output are checked independently. The output checker never
imports this compiler, the baseline, or any proof producer. The construction
uses only computation, clause use, paired introduction/elimination, and
one-occurrence forward rewriting on the left term with a clause-use source.
"""

import copy
import json
from pathlib import Path

import baseline_checker as B
import checker as F


ZERO = ["0"]


def strings(value):
    if type(value) is str:
        yield value
    elif type(value) in (list, tuple):
        for child in value:
            yield from strings(child)
    elif type(value) is dict:
        for child in value.values():
            yield from strings(child)


def shift_indices(proof, boundary, count):
    """Weaken by inserting count clauses after the retained root context."""
    result = copy.deepcopy(proof)
    if result["rule"] == "use" and result["clause"] >= boundary:
        result["clause"] += count
    for key in ("premise", "major", "before", "source"):
        if key in result:
            result[key] = shift_indices(result[key], boundary, count)
    return result


def comp(left, right):
    return {"rule": "comp", "conclusion": ["=", left, right]}


def truth_proof():
    return comp(["id", ZERO], ZERO)


class Compiler:
    def __init__(self, *inputs):
        self.used = set(strings(inputs))
        self.counter = 0
        self.macros = {"neutralize": 0, "reflexivity": 0, "symmetry": 0,
                       "old_forward": 0, "old_reverse": 0,
                       "old_left": 0, "old_right": 0}

    def fresh(self):
        while True:
            result = "_fl" + str(self.counter)
            self.counter += 1
            if result not in self.used:
                self.used.add(result)
                return result

    def forward_left(self, equality, before, path, context_length):
        """Neutralize an arbitrary proved equation, then rewrite once."""
        self.macros["neutralize"] += 1
        equation = equality["conclusion"]
        if equation[0] != "=" or before["conclusion"][0] != "=":
            raise ValueError("The rewriting macro requires two equations")
        u, y, z, a = (self.fresh() for _ in range(4))
        paired = ["D", u, y, copy.deepcopy(equation)]
        base_use = {
            "rule": "use", "conclusion": copy.deepcopy(equation),
            "clause": context_length, "term": copy.deepcopy(ZERO),
            "premise": truth_proof(),
        }
        major = {
            "rule": "di", "conclusion": paired,
            "witness": copy.deepcopy(ZERO), "eigen": z,
            "premise": base_use,
        }
        # DE inserts <E; b.E> after the retained root context. All local
        # clauses introduced inside lifted subproofs move one position.
        source = {
            "rule": "use", "conclusion": copy.deepcopy(equation),
            "clause": context_length, "term": copy.deepcopy(ZERO),
            "premise": shift_indices(equality, context_length, 1),
        }
        lifted_before = shift_indices(before, context_length, 1)
        result = copy.deepcopy(before["conclusion"])
        result[1] = F.replace_at(result[1], path, equation[1], equation[2])
        rewrite = {
            "rule": "rw", "conclusion": result,
            "before": lifted_before, "source": source,
            "path": copy.deepcopy(path),
        }
        return {
            "rule": "de", "conclusion": copy.deepcopy(result),
            "major": major, "eigen": a, "premise": rewrite,
        }

    def reflexivity(self, term, context_length):
        self.macros["reflexivity"] += 1
        seed = comp(["id", copy.deepcopy(term)], copy.deepcopy(term))
        return self.forward_left(seed, copy.deepcopy(seed), [], context_length)

    def symmetry(self, equality, context_length):
        self.macros["symmetry"] += 1
        left = equality["conclusion"][1]
        return self.forward_left(
            equality, self.reflexivity(left, context_length), [], context_length)

    def translate(self, proof, context_length=0):
        result = copy.deepcopy(proof)
        rule = proof["rule"]
        if rule == "comp":
            return result
        if rule == "use":
            result["premise"] = self.translate(proof["premise"], context_length)
        elif rule == "di":
            extra = 2 if proof["conclusion"][3][0] == "=" else 1
            result["premise"] = self.translate(proof["premise"], context_length + extra)
        elif rule == "de":
            result["major"] = self.translate(proof["major"], context_length)
            result["premise"] = self.translate(proof["premise"], context_length + 1)
        elif rule == "rw":
            equality = self.translate(proof["source"], context_length)
            before = self.translate(proof["before"], context_length)
            reverse, right = proof["orientation"], proof["side"]
            self.macros["old_reverse" if reverse else "old_forward"] += 1
            self.macros["old_right" if right else "old_left"] += 1
            if reverse:
                equality = self.symmetry(equality, context_length)
            if right:
                before = self.symmetry(before, context_length)
            result = self.forward_left(equality, before, proof["path"], context_length)
            if right:
                result = self.symmetry(result, context_length)
        else:
            raise ValueError("Source is not a local-calculus proof: " + str(rule))
        if not F.alpha_equal(result["conclusion"], proof["conclusion"]):
            raise ValueError("Compilation changed the concluding formula")
        result["conclusion"] = copy.deepcopy(proof["conclusion"])
        return result


def migrate_packet(packet):
    source_stats = B.check_packet(packet)
    compiler = Compiler(packet)
    output = copy.deepcopy(packet)
    output["proof"] = compiler.translate(packet["proof"])
    target_stats = F.check_packet(output)
    return output, {"source": source_stats, "target": target_stats,
                    "macros": compiler.macros}


def migrate_derivation(proof, declarations, context, scope):
    source_stats = B.Checker(declarations).check(proof, context, scope)
    compiler = Compiler(proof, declarations, context, list(scope))
    output = compiler.translate(proof, len(context))
    target_stats = F.Checker(declarations).check(
        output, context, scope, expected=proof["conclusion"])
    return output, {"source": source_stats, "target": target_stats,
                    "macros": compiler.macros}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    arguments = parser.parse_args()
    with arguments.input.open(encoding="utf-8") as stream:
        packet = B.load_packet(stream)
    output, stats = migrate_packet(packet)
    arguments.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(stats, indent=2))
