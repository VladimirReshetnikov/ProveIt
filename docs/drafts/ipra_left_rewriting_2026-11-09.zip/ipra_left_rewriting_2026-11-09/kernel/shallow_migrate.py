"""Untrusted compiler to forward-left rewriting at the root or one argument.

No new bound variables, assumptions, scopes, or clause indices are introduced.
The output kernel independently checks every equation source, including derived
equations. Vacuous-D neutralization in the mathematical proof justifies this
source generality relative to the inherited local calculus.
"""

import copy
import json
from pathlib import Path

import baseline_checker as B
import shallow_checker as S


def comp(left, right):
    return {"rule": "comp", "conclusion": ["=", left, right]}


class Compiler:
    def __init__(self):
        self.counts = {"rewrites": 0, "reverse": 0, "right": 0, "lifts": 0}

    def rewrite(self, equality, before, slot):
        source = equality["conclusion"]
        result = copy.deepcopy(before["conclusion"])
        if slot == -1:
            if result[1] != source[1]:
                raise ValueError("Root source mismatch")
            result[1] = copy.deepcopy(source[2])
        else:
            if result[1][slot + 1] != source[1]:
                raise ValueError("Argument source mismatch")
            result[1][slot + 1] = copy.deepcopy(source[2])
        return {"rule": "rw", "conclusion": result,
                "source": equality, "before": before, "slot": slot}

    def reflexivity(self, term):
        seed = comp(["id", copy.deepcopy(term)], copy.deepcopy(term))
        return self.rewrite(seed, copy.deepcopy(seed), -1)

    def symmetry(self, equality):
        return self.rewrite(equality, self.reflexivity(equality["conclusion"][1]), -1)

    def deep_left(self, equality, before, path):
        ancestors = []
        term = before["conclusion"][1]
        for index in path:
            ancestors.append((term, index))
            term = term[index + 1]
        if term != equality["conclusion"][1]:
            raise ValueError("Deep source mismatch")
        for parent, index in reversed(ancestors[1:]):
            self.counts["lifts"] += 1
            replacement_parent = copy.deepcopy(parent)
            replacement_parent[index + 1] = copy.deepcopy(equality["conclusion"][2])
            equality = self.rewrite(self.symmetry(equality),
                                    self.reflexivity(replacement_parent), index)
        return self.rewrite(equality, before, path[0] if path else -1)

    def translate(self, proof):
        result = copy.deepcopy(proof)
        rule = proof["rule"]
        if rule == "comp":
            return result
        if rule in ("use", "di"):
            result["premise"] = self.translate(proof["premise"])
        elif rule == "de":
            result["major"] = self.translate(proof["major"])
            result["premise"] = self.translate(proof["premise"])
        elif rule == "rw":
            self.counts["rewrites"] += 1
            self.counts["reverse"] += proof["orientation"]
            self.counts["right"] += proof["side"]
            equality = self.translate(proof["source"])
            before = self.translate(proof["before"])
            if proof["orientation"]:
                equality = self.symmetry(equality)
            if proof["side"]:
                before = self.symmetry(before)
            result = self.deep_left(equality, before, proof["path"])
            if proof["side"]:
                result = self.symmetry(result)
        else:
            raise ValueError("Source is not a local-calculus proof: " + str(rule))
        if not S.alpha_equal(result["conclusion"], proof["conclusion"]):
            raise ValueError("Compilation changed the concluding formula")
        result["conclusion"] = copy.deepcopy(proof["conclusion"])
        return result


def migrate_packet(packet):
    source = B.check_packet(packet)
    compiler = Compiler()
    output = copy.deepcopy(packet)
    output["proof"] = compiler.translate(packet["proof"])
    target = S.check_packet(output)
    return output, {"source": source, "target": target, "counts": compiler.counts}


def migrate_derivation(proof, declarations, context, scope):
    source = B.Checker(declarations).check(proof, context, scope)
    compiler = Compiler()
    output = compiler.translate(proof)
    target = S.Checker(declarations).check(output, context, scope,
                                         expected=proof["conclusion"])
    return output, {"source": source, "target": target, "counts": compiler.counts}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    arguments = parser.parse_args()
    with arguments.input.open(encoding="utf-8") as stream:
        packet = B.load_packet(stream)
    output, stats = migrate_packet(packet)
    arguments.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(stats, indent=2))
