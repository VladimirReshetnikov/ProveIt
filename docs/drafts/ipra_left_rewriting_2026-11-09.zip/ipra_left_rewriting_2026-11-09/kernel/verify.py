"""Reproduce the matched source comparison and forward-left proof compilation.

This validation harness is outside the acceptance kernel. It verifies exact
source changes, reproduces every included source-to-target certificate, checks
the exact linear proof-node bound, and exercises the new rejection boundary.
"""

import copy
import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path

import baseline_checker as B
import checker as F
import measure_source
import migrate as M


ROOT = Path(__file__).resolve().parent


def demand(value, message):
    if not value:
        raise ValueError(message)


def check_exact_changes():
    provenance = json.loads((ROOT / "provenance.json").read_text())
    base = (ROOT / "baseline_checker.py").read_text()
    demand(hashlib.sha256(base.encode()).hexdigest() == provenance["baseline_sha256"],
           "baseline source changed")
    demand(hashlib.sha256((ROOT / "measure_source.py").read_bytes()).hexdigest()
           == provenance["normalizer_sha256"], "source normalizer changed")
    forward = base.replace('"source", "orientation", "side", "path"',
                           '"source", "side", "path"')
    forward = forward.replace('            orientation = proof["orientation"]\n', '')
    forward = forward.replace(
        '            require(type(orientation) is int and orientation in (0, 1),\n'
        '                    "rewrite orientation must be zero or one")\n', '')
    forward = forward.replace(
        '            left = equation[1 + orientation]\n'
        '            right = equation[2 - orientation]\n',
        '            left = equation[1]\n            right = equation[2]\n')
    demand(forward == (ROOT / "forward_checker.py").read_text(),
           "unlisted forward-checker change")
    clause = forward.replace('source.get("rule") in ("comp", "use")',
                             'source.get("rule") == "use"')
    clause = clause.replace('rewrite source must be a computation or direct clause use',
                            'rewrite source must be a direct clause use')
    demand(clause == (ROOT / "clause_forward_checker.py").read_text(),
           "unlisted clause-only checker change")
    left = clause.replace('"source", "side", "path"', '"source", "path"')
    left = left.replace('            side = proof["side"]\n', '')
    left = left.replace(
        '            require(type(side) is int and side in (0, 1),'
        ' "rewrite side must be zero or one")\n', '')
    left = left.replace(
        '            target[side + 1] = replace_at(old[side + 1], path, left, right)\n',
        '            target[1] = replace_at(old[1], path, left, right)\n')
    demand(left == (ROOT / "checker.py").read_text(), "unlisted final checker change")


def old_flags(proof):
    result = copy.deepcopy(proof)
    if result["rule"] == "rw":
        result["orientation"] = 0
        result["side"] = 0
    for key in ("premise", "major", "before", "source"):
        if key in result:
            result[key] = old_flags(result[key])
    return result


def first_rewrite(proof):
    if proof["rule"] == "rw":
        return proof
    for key in ("premise", "major", "before", "source"):
        if key in proof:
            found = first_rewrite(proof[key])
            if found is not None:
                return found
    return None


def reject(packet):
    try:
        F.check_packet(packet)
    except Exception:
        return True
    return False


def public_result(packet, optimized=False):
    command = [sys.executable] + (["-O"] if optimized else []) + [str(ROOT / "checker.py")]
    process = subprocess.run(command, input=json.dumps(packet), text=True,
                             capture_output=True, timeout=60)
    return {"exit_code": process.returncode, "stdout": process.stdout,
            "stderr": process.stderr}


def focused_packet(reverse, right):
    zero = ["0"]
    inside = zero if reverse else ["id", zero]
    seed = ["S", inside]
    before = M.comp(["id", seed], seed)
    source = M.comp(["id", zero], zero)
    path = [0] if right else [0, 0]
    old = copy.deepcopy(before["conclusion"])
    old[right + 1] = F.replace_at(old[right + 1], path,
                                source["conclusion"][1 + reverse],
                                source["conclusion"][2 - reverse])
    proof = {"rule": "rw", "conclusion": old, "source": source,
             "before": before, "orientation": reverse, "side": right, "path": path}
    return {"declarations": [], "goal": old, "proof": proof}


def main():
    check_exact_changes()
    (ROOT / "examples").mkdir(exist_ok=True)
    source_paths = sorted((ROOT / "source_examples").glob("*.json"))
    demand(len(source_paths) == 9, "expected the nine unchanged inherited examples")
    receipts = []
    outputs = {}
    for source in source_paths:
        packet = json.loads(source.read_text())
        output, stats = M.migrate_packet(packet)
        counts = stats["macros"]
        r = counts["old_forward"] + counts["old_reverse"]
        expected = (stats["source"]["proof_nodes"] + 5*r
                    + 14*counts["old_reverse"] + 28*counts["old_right"])
        demand(stats["target"]["proof_nodes"] == expected, "proof-node bound failed")
        destination = ROOT / "examples" / source.name
        destination.write_text(json.dumps(output, indent=2) + "\n")
        outputs[source.name] = output
        receipts.append({"name": source.name, "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                         "output_sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
                         "exact_node_formula": True, **stats})

    focused = []
    for reverse in (0, 1):
        for right in (0, 1):
            packet = focused_packet(reverse, right)
            output, stats = M.migrate_packet(packet)
            embedded = {**output, "proof": old_flags(output["proof"])}
            B.check_packet(embedded)
            filename = f"focused_reverse_{reverse}_right_{right}.json"
            (ROOT / "examples" / filename).write_text(json.dumps(output, indent=2) + "\n")
            cli = [public_result(output, optimized) for optimized in (False, True)]
            demand(all(item == {"exit_code": 0, "stdout": "ACCEPT\n", "stderr": ""}
                       for item in cli), "focused public certificate rejected")
            focused.append({"reverse": reverse, "right": right, "stats": stats, "public": cli})

    # Open retained contexts and a name chosen to collide with the compiler's
    # default fresh-name prefix exercise both clause rebasing and freshness.
    p, q = ["$", "_fl0"], ["$", "q"]
    equation = ["=", p, q]
    context = [F.hypothesis(equation)]
    source = {"rule": "use", "conclusion": equation, "clause": 0,
              "term": ["0"], "premise": M.truth_proof()}
    before = M.comp(["id", p], p)
    open_proof = {"rule": "rw", "conclusion": ["=", ["id", p], q],
                  "source": source, "before": before, "orientation": 0,
                  "side": 1, "path": []}
    open_output, open_stats = M.migrate_derivation(
        open_proof, [], context, {"_fl0", "q"})
    B.Checker([]).check(old_flags(open_output), context, {"_fl0", "q"})

    seed = outputs["reflexivity.json"]
    negatives = []
    for field, value in (("orientation", 0), ("side", 0)):
        changed = copy.deepcopy(seed)
        first_rewrite(changed["proof"])[field] = value
        demand(reject(changed), "obsolete field accepted")
        negatives.append({"case": "extra_" + field, "rejected": True})
    changed = copy.deepcopy(seed)
    first_rewrite(changed["proof"])["source"] = M.comp(["id", ["0"]], ["0"])
    demand(reject(changed), "direct computation source accepted")
    negatives.append({"case": "direct_computation_source", "rejected": True})
    for path in ([True], [-1], [999]):
        changed = copy.deepcopy(seed)
        first_rewrite(changed["proof"])["path"] = path
        demand(reject(changed), "invalid path accepted")
        negatives.append({"case": "invalid_path", "path": path, "rejected": True})
    false_packet = {"declarations": [], "goal": ["=", ["0"], ["S", ["0"]]],
                    "proof": {"rule": "comp", "conclusion": ["=", ["0"], ["S", ["0"]]]}}
    demand(reject(false_packet), "false computation accepted")
    negatives.append({"case": "false_equation", "rejected": True})
    false_cli = [public_result(false_packet, optimized) for optimized in (False, True)]
    demand(all(item == {"exit_code": 1, "stdout": "REJECT\n", "stderr": ""}
               for item in false_cli), "false public certificate not rejected")

    rows = [{"file": name, **measure_source.metrics(ROOT / name)} for name in
            ("baseline_checker.py", "forward_checker.py", "clause_forward_checker.py", "checker.py")]
    metrics = {"python": platform.python_version(), "rows": rows,
               "matched_saving": {key: rows[0][key] - rows[-1][key]
                                  for key in ("normalized_tokens", "ast_nodes", "normalized_bytes")},
               "global_frontier_beaten": False}
    result = {"exact_source_change_verified": True, "inherited_examples": receipts,
              "focused_examples": focused, "open_context": open_stats,
              "negative_cases": negatives, "negative_public": false_cli,
              "scope": "Finite verification supplements the written proof; no Lean/Rocq metatheory claim."}
    (ROOT / "measurements.json").write_text(json.dumps(metrics, indent=2) + "\n")
    (ROOT / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"source_change_verified": True, "inherited_examples": len(receipts),
                      "focused_examples": len(focused), "negative_cases": len(negatives),
                      "metrics": metrics}, indent=2))


if __name__ == "__main__":
    main()
