# Direct four-pattern arrow-context checker: negative size result

`checker_arrows.py` is a concrete, standalone direct implementation of the one-binder, four-pattern theory. It uses singleton formulas for D (binding two numerical variables), binary formulas for equality, and explicit context entries [P,Q] for the reusable arrow from P to any numerical instance of Q. Ordinary assumptions are stored as [T,A], with the fixed computation theorem T = Iter(0,0;u.0)=0. The driver, parser, both context constructors, indices, premises, scope checks, exceptions, and verdict are all in this one file.

Whole-file inherited metrics: **416 normalized tokens, 449 AST nodes, 1176 normalized bytes**. This is worse than the current root envelope 375/403/1117 by +41 tokens, +46 AST nodes, and +59 bytes. It does not meet the benchmark. The explicit capability pairs and their separate creation/use account for the extra implementation cost, despite fewer formula constructors and inference-pattern names.

Six meaningful smoke cases exercise computation, equality transport, paired introduction, an ordinary assumption encoded as a truth-premise arrow, paired elimination followed by capability use, and the earlier falsity attack. They have the expected outcomes; see arrow_checker_results.json. This small experiment is not a completed adversarial certification or metatheory formalization.

Two unselected variations were measured: direct shared branch fusion worsens source to 422/461/1295; replacing indexed Use by a search over context entries gives 414/445/1165 but requires a more complicated proof-stream completeness argument. Neither is competitive, so further source-golf is not warranted.

The already smaller truth-completed kernel can of course check the same ordinary theorem set through the proved translation, with Q as an abbreviation and Hyp/QE as derived operations. That establishes implementation support for the four-pattern axiomatization but does NOT demonstrate an additional code-size saving attributable to removing Q/Hyp primitives. Keep those claims separate.
