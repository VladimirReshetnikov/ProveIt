"""Untrusted independent opening, decoding, and mutation checks.

The production checkers import none of this module. Finite evidence is not a
formal proof of the mathematical soundness or completeness theorem.
"""
from copy import deepcopy
import itertools
import random
from semantic_oracle import Oracle

def paths(value,prefix=()):
    yield prefix
    if type(value) is list:
        for i,x in enumerate(value): yield from paths(x,(*prefix,i))


def mutate(value,rng):
    path=rng.choice(list(paths(value)))
    replacement=rng.choice([None,True,False,0,1,2,3,5,17,255,-1,-2,-99,
                            0.0,0.5,'x',{},[],[0],[0,0],[0,0,0],[[0],0]])
    if not path:return deepcopy(replacement)
    result=deepcopy(value);parent=result
    for index in path[:-1]:parent=parent[index]
    parent[path[-1]]=deepcopy(replacement)
    return result


def intro_index_attacks():
    true=[0,0]
    bad=[[1,0,[0]],0]  # C(y,0,1)=0, true at zero and false at a successor.
    qbad=[bad]
    false_goal=[[[0],0,[0]],0]
    # A B-elimination wrongly selecting the first padding matrix accepts A.
    A=[[],0,[[bad,true,true],0],[qbad,[0]],false_goal]
    # A B-introduction wrongly selecting the first matrix accepts B.
    B=[[],0,[[true,true,bad],0],[qbad,[0]],false_goal]
    return {'unguarded_equation_introduction':[0,[[0],0]],
            'wrong_elimination_matrix':A,'wrong_introduction_matrix':B}


def term_normal(value,q,k,width):
    if type(value) is int:
        if not k<=value<2*q+1:return ('H',)
        if value==0:return ('Z',)
        if value<0:return ('P',value)
        return ('V',(value+1)//2-1)
    if len(value)==1:return ('S',term_normal(value[0],q,k,width))
    if len(value)==3:
        return ('R',term_normal(value[0],q,k,width),term_normal(value[1],q,k,width),
                term_normal(value[2],q+width,k,width))
    raise ValueError('not numerical')


def formula_normal(value,q,k,width):
    if type(value) is int:return ('T',)
    if len(value)==2:
        return ('E',term_normal(value[0],q,k,width),term_normal(value[1],q,k,width))
    if len(value)==1:
        sub=formula_normal(value[0],q+1,k,width)
        return sub if sub==('T',) else ('Q',sub)
    if len(value)==3:
        sub=formula_normal(value[2],q+2,k,width)
        return sub if sub==('T',) else ('B',sub)
    raise ValueError('not a formula')


def plug(tree,image):
    if tree==('H',):return image
    if type(tree) is tuple:return tuple(plug(x,image) for x in tree)
    return tree


def generated_term(rng,size,q,width,holes=False):
    if size==0 or rng.random()<.4:
        atoms=[-2,-1,0,*range(1,2*q+1)]
        if holes: atoms += [-99,2*q+1,2*q+2,999]
        return rng.choice(atoms)
    if rng.random()<.4:
        return [generated_term(rng,size-1,q,width,holes)]
    return [generated_term(rng,size-1,q,width,holes),
            generated_term(rng,size-1,q,width,holes),
            generated_term(rng,size-1,q+width,width,holes)]


def generated_formula(rng,size,q,width):
    if size==0 or rng.random()<.3:
        if rng.random()<.5:return rng.choice([-99,-2,-1,0,1,2*q,2*q+1,999])
        return [generated_term(rng,2,q,width,True),generated_term(rng,2,q,width,True)]
    if rng.random()<.5:return [generated_formula(rng,size-1,q+1,width)]
    return [generated_formula(rng,size-1,q+2,width) for _ in range(3)]


def opening_audit(module,width):
    atoms=[-99,-2,-1,0,1,2,3,4,5,999,None,True,False,0.0,0.5,'x',{}]
    values=atoms+[[],[0],[1],[999],[0,0],[0,0,1],[0,0,3],[[0],0],
                 [[0,0]],[0,[1],[2]],[[[0]],[[1]],[[2]]],
                 [[1,0],[3,4],[5,6]],[[0,0,999],0]]
    images=[None,0,-1,-99,1,[0],[0,0,1],[0,0,3],[],[0,0],True,{}]
    count=0;valid_count=0
    for formula,value,depth,lower,image in itertools.product((True,False),values,range(4),(0,-2),images):
        module.k=lower
        try:
            actual=module.inst(deepcopy(value),deepcopy(image),2*depth+(not formula));valid=True
        except Exception:actual=None;valid=False
        oracle=Oracle(width);oracle.lower=lower
        try:
            fn=oracle.formula if formula else oracle.term
            expected=fn(deepcopy(value),deepcopy(image),depth);expected_valid=True
        except Exception:expected=None;expected_valid=False
        assert valid==expected_valid and (not valid or actual==expected),('opening',width,value,image,depth,lower,actual,expected)
        count+=1;valid_count+=valid
    return {'cases':count,'successful':valid_count}


def semantic_opening_audit(module,width,count=2500):
    rng=random.Random(137000+width);module.k=-2
    successful=0;repeated_purity=0
    for _ in range(count):
        q=rng.randrange(4)
        value=generated_formula(rng,3,q,width)
        image=generated_term(rng,3,0,width)
        opened=module.inst(value,image,2*q)
        source=formula_normal(value,q,-2,width)
        decoded_image=term_normal(image,0,-2,width)
        actual=formula_normal(opened,q,-2,width)
        expected=plug(source,decoded_image)
        assert actual==expected,('semantic substitution',width,q,value,image,opened,actual,expected)
        successful+=1
        # A term can be repeatedly read in formula sort. Even if some raw
        # interval choices reject, every successful result must stay pure.
        pure=deepcopy(image)
        for _ in range(3):
            try:pure=module.inst(pure,image,2*q)
            except Exception:break
            assert formula_normal(pure,q,-2,width)==('T',)
            assert all(type(v) is not list or len(v)!=2 for p in paths(pure)
                       for v in [at(pure,p)])
            repeated_purity+=1
    return {'substitution_cases':successful,'successful_repeated_purity_steps':repeated_purity}


def at(value,path):
    for i in path:value=value[i]
    return value


