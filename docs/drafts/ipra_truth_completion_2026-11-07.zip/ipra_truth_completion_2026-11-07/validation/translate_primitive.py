"""Untrusted witness compiler: old scalar/recursor proofs -> primitive truth kernels.

Eliminates direct Q-introduction using B-I/B-E/Hyp and moves the meaningful
B matrix from the first to the third slot.  No code here is trusted by the
acceptance program.  Failed-major allocations are replayed using truth-only B-elimination
wrappers, whose harmless assumptions cannot match any ordinary source goal.
"""
from pathlib import Path
import ast
from copy import deepcopy
import json
import types



def load(path):
    tree=ast.parse(Path(path).read_text()); body=[]
    for node in tree.body:
        if isinstance(node,ast.Try): break
        body.append(node)
    module=types.ModuleType('loaded_prefix')
    exec(compile(ast.Module(body=body,type_ignores=[]),str(path),'exec'),module.__dict__)
    return module


def run(module,packet):
    module.k=0; stack=deepcopy(packet); module.take=stack.pop
    try: return bool(module.check(stack.pop(),[]))
    except Exception: return False


class ProofFalse(Exception):
    pass


class Compiler:
    def __init__(self,old,width=1):
        self.old=old; self.new_floor=0; self.mapping={}; self.expansions=0
        self.steps=0; self.width=width; self.fallbacks=0; self.reserved_wrappers=0

    def term(self,value,depth=0,template=False):
        if type(value) is int:
            if value<0:
                if value>=self.old.k:
                    return self.mapping[value]
                if template: return 2*depth+1
                raise ValueError('unused invalid image')
            return value
        if type(value) is not list: raise ValueError('not a term')
        if len(value)==1:
            return [self.term(value[0],depth,template)]
        if len(value)==3:
            return [self.term(value[0],depth,template),self.term(value[1],depth,template),
                    self.term(value[2],depth+self.width,template)]
        raise ValueError('not a term')

    def formula(self,value,depth=0,template=False):
        if type(value) is not list: raise ValueError('not a source formula')
        if len(value)==1:
            return [self.formula(value[0],depth+1,template)]
        if len(value)==2:
            return [self.term(x,depth,template) for x in value]
        if len(value)==3:
            # Destination B's semantic body is its last child.
            return [self.formula(value[i],depth+2,template) for i in (1,2,0)]
        raise ValueError('not a source formula')

    def image(self,value):
        try: return self.term(value)
        except Exception: return 0

    def eigen(self):
        self.old.k-=1; self.new_floor-=1
        self.mapping[self.old.k]=self.new_floor
        return self.old.k

    def check(self,goal,context):
        self.steps+=1
        self.old.inst(goal)
        if goal in context:
            return []
        instruction=self.stack.pop()
        prefix=[]
        if type(instruction) is list and len(instruction)==2:
            major,annotation=instruction
            translated_major=self.formula(major)
            old_floor=self.old.k
            saved=(self.new_floor,self.mapping.copy(),self.expansions,
                   self.fallbacks,self.reserved_wrappers)
            try:
                major_proof=self.check(major,context)
            except ProofFalse:
                # The source guard consumed its failed attempt. Preserve
                # that old floor, but discard the unexecuted target code.
                (self.new_floor,self.mapping,self.expansions,
                 self.fallbacks,self.reserved_wrappers)=saved
                self.fallbacks+=1
                for old_name in range(old_floor-1,self.old.k-1,-1):
                    self.new_floor-=2
                    self.mapping[old_name]=self.new_floor
                    self.reserved_wrappers+=1
                    # Both the major B theorem and its Q continuation
                    # contain an inert formula scalar. No ordinary source
                    # goal has that shape, so no unintended Hyp shortcut
                    # can leave part of the translated proof unread.
                    prefix += [[[[0],[0],[0]],0],0]
            else:
                if len(major)==3:
                    instruction_new=[translated_major,0]
                    eigen=self.eigen()
                    assumption=self.old.inst([major[0]],eigen)
                    rest=self.check(goal,context+[assumption])
                    return [instruction_new]+major_proof+rest
                if len(major)==1:
                    matrix,left,right=major[0],0,annotation
                    translated_annotation=self.image(annotation)
                else:
                    matrix=annotation;left,right=major
                    translated_annotation=self.formula(annotation,template=True)
                if self.old.inst(matrix,right)!=goal: raise ProofFalse()
                rest=self.check(self.old.inst(matrix,left),context)
                return [[translated_major,translated_annotation]]+major_proof+rest
        if instruction==[]:
            (count,initial,body),right=goal
            if count:
                count,=count
                opened=self.old.inst(body,count,3) if self.width==2 else body
                initial=self.old.inst(opened,[count,initial,body],1)
            if right!=initial: raise ProofFalse()
            return [[]]
        if len(goal) not in (1,3): raise ValueError('not an introduction')
        source_body=goal[0]
        translated_body=self.formula(source_body,depth=1)
        if len(goal)==3:
            witness=self.image(instruction)
        else:
            witness=0
        body=self.old.inst(source_body,instruction,2)
        assumptions=[body,self.old.inst(body,0)][len(body)%2:]
        eigen=self.eigen()
        child=self.old.inst(body,[eigen])
        child_context=context+[self.old.inst(a,eigen) for a in assumptions]
        proof=self.check(child,child_context)
        if len(goal)==3:
            return prefix+[witness]+proof
        # Q-I is B-I on an unused outer witness, followed by B-E and Hyp.
        self.expansions+=1
        paired=[translated_body,translated_body,translated_body]
        self.new_floor-=1  # B-E's extra unused eigenparameter, after its major proof.
        return prefix+[[paired,0],0]+proof

    def compile(self,packet):
        self.old.k=0;self.stack=deepcopy(packet)
        goal=self.stack.pop();translated_goal=self.formula(goal)
        proof=self.check(goal,[])
        return list(reversed(proof))+[translated_goal]

