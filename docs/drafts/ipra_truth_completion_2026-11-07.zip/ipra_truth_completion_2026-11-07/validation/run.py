#!/usr/bin/env python3
"""Reproduce the finite validation of both complete acceptance programs.

Run with Python 3.10+ from any directory.  All inputs are bundled and every
saved path is relative to this package.  The production checkers do not
import this module, its translators, its oracle, or any fixture generator.
Finite tests support implementation confidence; they do not formally verify
the mathematical soundness, completeness, or bi-interpretability proofs.
"""
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import types

from opening_checks import opening_audit,semantic_opening_audit,intro_index_attacks,mutate,paths
from semantic_oracle import Oracle
from translate_primitive import Compiler,load,run as accepted

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
RESULTS=ROOT/'results'
EXAMPLES=ROOT/'examples'
PROGRAMS={1:ROOT/'checker_scalar.py',2:ROOT/'checker.py'}
NAMES={1:'scalar',2:'full'}


def require(condition,detail):
    if not condition:raise AssertionError(detail)


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,sort_keys=False)+'\n')


def digest(path):return sha256(path.read_bytes()).hexdigest()


def trace(module,packet):
    module.k=0;stack=deepcopy(packet);used=[]
    def take():
        value=stack.pop();used.append(deepcopy(value));return value
    try:
        module.take=take
        verdict=bool(module.check(stack.pop(),[]));error=None
    except Exception as exc:
        verdict=False;error=type(exc).__name__
    return {'accepted':verdict,'final_k':module.k,
            'remaining':len(stack) if type(stack) is list else None,
            'error':error,'used':used}


def unwrap_instruction(cell):
    if type(cell) is list and len(cell)==1:
        witness=cell[0]
        if type(witness) is int or type(witness) is list and len(witness) in (1,3):
            return witness
        return 0
    return cell


def source_and_translation_checks():
    legacy=json.loads((HERE/'source_scalar_fixtures.json').read_text())
    staged=json.loads((HERE/'source_direct_fixtures.json').read_text())
    source={1:load(HERE/'source_scalar.py'),2:load(HERE/'source_direct.py')}
    wrapped=load(HERE/'source_scalar_wrapped.py')
    target={w:load(p) for w,p in PROGRAMS.items()}
    prepared=[];source_rows=[];records=[];packets={1:[],2:[]}
    for row in legacy:
        old=trace(wrapped,row['packet'])
        require(old['accepted']==row['expected'],('wrapped source expectation',row['name'],old['accepted']))
        source_rows.append({'cohort':'legacy_wrapped_scalar','name':row['name'],'accepted':old['accepted']})
        if old['accepted']:
            packet=[unwrap_instruction(c) for c in reversed(old['used'])]+[deepcopy(row['packet'][-1])]
            require(accepted(source[1],packet),('witness unwrapping',row['name']))
            prepared.append((1,'legacy_wrapped_scalar',row['name'],packet))
    for key,width in [('scalar',1),('full',2),('embedded',2)]:
        for row in staged[key]:
            verdict=accepted(source[width],row['packet'])
            require(verdict==row['expected'],('staged source expectation',key,row['name'],verdict))
            source_rows.append({'cohort':'staged_'+key,'name':row['name'],'accepted':verdict})
            if verdict:prepared.append((width,'staged_'+key,row['name'],row['packet']))
    for index,(width,cohort,name,packet) in enumerate(prepared):
        compiler=Compiler(source[width],width)
        result=compiler.compile(packet)
        actual=trace(target[width],result);oracle=Oracle(width).run(result)
        require(actual['accepted'] and oracle['accepted'],('translated proof',cohort,name,actual,oracle))
        require((actual['final_k'],actual['remaining'])==(oracle['final_k'],oracle['remaining']),('translated trace',name))
        file=HERE/'translated'/NAMES[width]/f'{index:03d}.json'
        save(file,result)
        record={'variant':NAMES[width],'cohort':cohort,'name':name,'status':'PASS',
                'packet_file':str(file.relative_to(ROOT)),'packet_sha256':digest(file),
                'Q_introduction_expansions':compiler.expansions,
                'successful_guard_fallthroughs':compiler.fallbacks,
                'reserved_name_wrappers':compiler.reserved_wrappers}
        records.append(record)
        packets[width].append({'name':cohort+'/'+name,'packet':result,'expected':True,'record':record})
    receipt={'status':'PASS','source_expectations_checked':len(source_rows),
             'source_positive_expectations':sum(r['accepted'] for r in source_rows),
             'translated_proofs':len(records),
             'by_variant':{NAMES[w]:len(packets[w]) for w in (1,2)},
             'Q_introduction_expansions':sum(r['Q_introduction_expansions'] for r in records),
             'successful_guard_fallthroughs':sum(r['successful_guard_fallthroughs'] for r in records),
             'reserved_name_wrappers':sum(r['reserved_name_wrappers'] for r in records),
             'source_expectations':source_rows,'translations':records}
    save(RESULTS/'translations.json',receipt)
    return packets,receipt


def fixed_examples():
    rows=[{'name':name,'packet':packet,'expected':False} for name,packet in intro_index_attacks().items()]
    rows += [
        {'name':'truth_only_paired','packet':[0,[[0],[0],[0]]],'expected':True},
        {'name':'zero_computation','packet':[[],[[0,0,0],0]],'expected':True},
        {'name':'false_zero_computation','packet':[[],[[0,0,0],[0]]],'expected':False},
        {'name':'future_parameter_in_unused_update','packet':[[],[[0,0,-1],0]],'expected':False},
        {'name':'false_induction','packet':[0,[[1,0],[1,0],[1,0]]],'expected':False},
        {'name':'bare_truth_root_is_not_an_accepted_encoding','packet':[0],'expected':False},
        {'name':'boolean_term_is_rejected','packet':[[],[[0,False,0],0]],'expected':False},
        {'name':'float_term_is_rejected','packet':[[],[[0,0.0,0],0]],'expected':False},
        {'name':'malformed_packet_object','packet':{},'expected':False}]
    return rows


def packet_and_opening_checks(width,positive_rows):
    module=load(PROGRAMS[width]);oracle=Oracle(width)
    rng=random.Random(178000+width);counts=Counter();rules=Counter()
    def agreement(packet,name,expected=None):
        actual=trace(module,packet);independent=oracle.run(packet)
        require(actual['accepted']==independent['accepted'],('oracle verdict',width,name,packet,actual,independent))
        if expected is not None:require(actual['accepted']==expected,('expected verdict',width,name,actual))
        if actual['accepted']:
            require((actual['final_k'],actual['remaining'])==(independent['final_k'],independent['remaining']),('oracle trace',width,name))
        counts['packets']+=1;counts['accepted' if actual['accepted'] else 'rejected']+=1
        rules.update(independent['rules'])
    rows=positive_rows+fixed_examples()
    for row in rows:
        agreement(row['packet'],row['name'],row['expected'])
        for _ in range(40):agreement(mutate(row['packet'],rng),row['name']+'/mutation')
    for _ in range(2000):
        def tree(depth):
            if depth==0 or rng.random()<.4:
                return deepcopy(rng.choice([None,True,False,-99,-1,0,1,2,3,0.5,{},'x']))
            return [tree(depth-1) for _ in range(rng.randrange(5))]
        agreement(tree(4),'random malformed')
    opening=opening_audit(module,width)
    semantic=semantic_opening_audit(module,width)
    return {'variant':NAMES[width],'checker_sha256':digest(PROGRAMS[width]),
            **dict(counts),'rule_counts':dict(rules),
            'opening_agreement':opening,'normalized_semantic_opening':semantic,
            'random_seed':178000+width,'mutations_per_fixture':40,'random_malformed_packets':2000}


def mutation_controls():
    source=PROGRAMS[1].read_text();attacks=intro_index_attacks();records=[]
    variants=[('unguarded_equation_introduction','a = inst(a[2], t, 2)','a = inst(a[0], t, 2)',
               attacks['unguarded_equation_introduction']),
              ('wrong_paired_elimination_matrix','h = [m[2:]]','h = [m[:1]]',attacks['wrong_elimination_matrix']),
              ('wrong_paired_introduction_matrix','a = inst(a[2], t, 2)','a = inst(a[0], t, 2)',
               attacks['wrong_introduction_matrix'])]
    for name,before,after,packet in variants:
        require(source.count(before)==1,('mutation site',name))
        tree=ast.parse(source.replace(before,after));body=[]
        for node in tree.body:
            if isinstance(node,ast.Try):break
            body.append(node)
        mutant=types.ModuleType(name)
        exec(compile(ast.Module(body=body,type_ignores=[]),name,'exec'),mutant.__dict__)
        bad=accepted(mutant,packet);good=accepted(load(PROGRAMS[1]),packet)
        require(bad and not good,('mutation control',name,bad,good))
        records.append({'name':name,'correct_accepts':good,'mutant_accepts':bad,
                        'false_packet':packet})
    save(RESULTS/'mutation_controls.json',{'status':'PASS','controls':records})
    return records


def falsity_probes(width,positive_rows,count=12000):
    """Search only for false conclusions in a fixed finite standard-model family."""
    module=load(PROGRAMS[width]);rng=random.Random(626073+width)
    paired=lambda b:[deepcopy(b),deepcopy(b),deepcopy(b)]
    false_goals=[[[0],0],[0,[0]],[[[0]],0],[[[0]],[0]],paired([1,0]),paired([0,1])]
    leaves=[-4,-3,-2,-1,0,1,2,3,4,5,100,None,False,True,[],[0],[1],
            [0,0],[1,0],[[0],0],paired([0]),paired([1,0])]
    pool=[r['packet'] for r in positive_rows]
    def edit(value):
        result=deepcopy(value);path=rng.choice(list(paths(result)))
        if not path:return deepcopy(rng.choice(leaves))
        parent=result
        for i in path[:-1]:parent=parent[i]
        old=parent[path[-1]];choice=rng.randrange(5)
        if choice==0:parent[path[-1]]=deepcopy(rng.choice(leaves))
        elif choice==1:parent[path[-1]]=[old]
        elif choice==2:parent[path[-1]]=[old,old]
        elif choice==3:parent[path[-1]]=[old,old,old]
        elif type(old) is list and old:parent[path[-1]]=rng.choice(old)
        return result
    for index in range(count):
        packet=deepcopy(rng.choice(pool))
        for _ in range(1+rng.randrange(3)):
            if len(packet)>1:
                position=rng.randrange(len(packet)-1);packet[position]=edit(packet[position])
        packet[-1]=deepcopy(false_goals[index%len(false_goals)])
        require(not accepted(module,packet),('falsity probe',width,index,packet))
    small=leaves[:]
    for atom in (-1,0,1,2,[0],[1],[0,0],[1,0]):small.extend([[atom],[atom,atom],[atom,atom,atom]])
    systematic=0
    for goal in false_goals:
        for instruction in small:
            for prefix in ([],[[]],[0],[[],[]],[0,0]):
                packet=deepcopy(prefix+[instruction,goal]);systematic+=1
                require(not accepted(module,packet),('systematic falsity probe',width,systematic,packet))
    return {'variant':NAMES[width],'targeted_mutations':count,'small_systematic_packets':systematic,
            'found_false_conclusions':0,'seed':626073+width,
            'scope':'Finite standard-natural-number falsity probes, not a proof of soundness.'}


def publish_examples_and_cli(packets):
    records=[];index=[];public=[]
    selected={
        'successor_uses_counter':'full_counter_step',
        'successor_uses_both_arguments':'full_counter_and_state_step',
        'successor_under_two_nested_recursors':'nested_recursion_step',
        'atomic_induction_recursion_identity':'induction_identity',
        'addition_two_three':'addition_2_3',
        'multiplication_two_three':'multiplication_2_3',
        'power_two_three':'power_2_3',
        'nested_Q_introductions':'nested_closure_introduction',
        'D_unused_malformed_witness':'unused_malformed_witness',
        'failed_major_retains_consumed_allocation':'failed_major_reserved_name'}
    # Choose one genuine full-recursion example of each requested behavior.
    for original,filename in selected.items():
        row=next(r for r in packets[2] if r['record']['cohort']=='staged_full' and r['record']['name']==original)
        path=EXAMPLES/(filename+'.json');save(path,row['packet'])
        index.append({'file':path.name,'checker':'checker.py','expected':True,'source':row['record']['packet_file']})
        public.append((2,path,True))
    for row in fixed_examples():
        path=EXAMPLES/(row['name']+'.json');save(path,row['packet'])
        index.append({'file':path.name,'checkers':['checker.py','checker_scalar.py'],'expected':row['expected']})
        public.extend((width,path,row['expected']) for width in (1,2))
    # Exercise the scalar CLI on representative translated proofs, including
    # real induction and extra reserved-name scopes.
    for name in ('nested_Q_introductions','atomic_induction_recursion_identity',
                 'addition_two_three','failed_major_retains_consumed_allocation'):
        row=next(r for r in packets[1] if r['record']['cohort']=='staged_scalar' and r['record']['name']==name)
        path=ROOT/row['record']['packet_file'];public.append((1,path,True))
    for width,path,expected in public:
        for flags in ([],['-O']):
            proc=subprocess.run([sys.executable,*flags,str(PROGRAMS[width]),str(path)],
                                text=True,capture_output=True,timeout=15)
            wanted=(0,'ACCEPT','') if expected else (1,'REJECT','')
            actual=(proc.returncode,proc.stdout.strip(),proc.stderr)
            require(actual==wanted,('public CLI',NAMES[width],str(path.relative_to(ROOT)),flags,actual,wanted))
            records.append({'variant':NAMES[width],'file':str(path.relative_to(ROOT)),
                            'optimized':bool(flags),'expected':expected,'status':'PASS'})
    save(EXAMPLES/'index.json',index)
    save(RESULTS/'public_cli.json',{'status':'PASS','runs':len(records),'records':records})
    return len(records)


def main():
    RESULTS.mkdir(exist_ok=True);EXAMPLES.mkdir(exist_ok=True)
    packets,translation=source_and_translation_checks()
    programs=[packet_and_opening_checks(width,packets[width]) for width in (1,2)]
    controls=mutation_controls()
    falsity=[falsity_probes(width,packets[width]) for width in (1,2)]
    save(RESULTS/'falsity_probes.json',{'status':'PASS','variants':falsity})
    cli=publish_examples_and_cli(packets)
    summary={'status':'PASS','python_version':platform.python_version(),
             'checker_files':{NAMES[w]:{'path':str(PROGRAMS[w].relative_to(ROOT)),
                                      'sha256':digest(PROGRAMS[w])} for w in (1,2)},
             'source_files':{p.name:digest(p) for p in (HERE/'source_scalar.py',HERE/'source_direct.py',
                                                       HERE/'source_scalar_wrapped.py',
                                                       HERE/'source_scalar_fixtures.json',HERE/'source_direct_fixtures.json')},
             'source_expectations_checked':translation['source_expectations_checked'],
             'translated_proofs':translation['translated_proofs'],
             'translated_by_variant':translation['by_variant'],
             'Q_introduction_expansions':translation['Q_introduction_expansions'],
             'guard_fallthrough_translations':translation['successful_guard_fallthroughs'],
             'reserved_name_wrappers':translation['reserved_name_wrappers'],
             'programs':programs,'mutation_controls':len(controls),
             'falsity_probes':falsity,'public_cli_runs':cli,
             'scope':'Finite reproducible implementation evidence. No Lean/Rocq certification or formal verification of metatheory is claimed.'}
    save(RESULTS/'validation.json',summary)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
