"""Reproduce whole-source, uniform-driver, and structural-ablation measurements."""
from pathlib import Path
import ast
import csv
import hashlib
import importlib.util
import json
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
KEYS = ("normalized_tokens", "ast_nodes", "normalized_bytes")
DRIVER = """try:
    take = json.load(open(sys.argv[1])).pop
    accepted = check(take(), [])
except:
    accepted = False
print('ACCEPT' if accepted else 'REJECT')
sys.exit(not accepted)
"""


def prefix(source):
    tree = ast.parse(source)
    nodes = []
    for node in tree.body:
        if isinstance(node, ast.Try):
            break
        if isinstance(node, ast.If) and "__name__" in ast.unparse(node.test):
            break
        nodes.append(node)
    return ast.unparse(ast.Module(body=nodes, type_ignores=[])) + "\n"


def main():
    corpus = json.loads((ROOT / "comparison/corpus.json").read_text())
    metric_file = ROOT / "comparison/source_measure.py"
    assert hashlib.sha256(metric_file.read_bytes()).hexdigest() == corpus["normalizer_sha256"]
    spec = importlib.util.spec_from_file_location("unchanged_metric", metric_file)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    unique = {}
    for entry in corpus["expanded_programs"]:
        if entry["sha256"] not in unique:
            measured = metric.metrics(ROOT / entry["local_file"])
            assert measured["sha256"] == entry["sha256"]
            unique[entry["sha256"]] = measured
    current = [{**entry, **unique[entry["sha256"]]} for entry in corpus["root_programs"]]
    envelope = {key: min(row[key] for row in current) for key in KEYS}
    expanded = {key: min(row[key] for row in unique.values()) for key in KEYS}
    candidates = [{"file": name, **metric.metrics(ROOT / name)}
                  for name in ("checker.py", "checker_scalar.py")]
    assert envelope == expanded == dict(zip(KEYS, (375, 403, 1117)))
    assert all(candidate[key] < envelope[key] for candidate in candidates for key in KEYS)
    with tempfile.TemporaryDirectory() as temporary:
        scratch = Path(temporary) / "program.py"

        def measure_text(text):
            scratch.write_text(text)
            return {key: metric.metrics(scratch)[key] for key in KEYS}

        controls = []
        for entry in current:
            source = (ROOT / entry["local_file"]).read_text()
            controls.append({"archive": entry["archive"], "member": entry["member"],
                             **measure_text(prefix(source) + DRIVER)})
        controlled_envelope = {key: min(row[key] for row in controls) for key in KEYS}
        controlled_candidates = [{"file": candidate["file"], **measure_text(
            prefix((ROOT / candidate["file"]).read_text()) + DRIVER)}
            for candidate in candidates]
        scalar = (ROOT / "checker_scalar.py").read_text()
        strict_leaf = scalar.replace("if type(a) is int:", "if type(a) is int and d % 2:")
        ablations = [
            {"name": "Integrated inherited scalar control",
             **{key: metric.metrics(ROOT / "comparison/checker_integration_control.py")[key]
                for key in KEYS}},
            {"name": "Third matrix and primitive introduction, strict leaf sort",
             **measure_text(strict_leaf)},
            {"name": "Conservative truth completion, scalar", **measure_text(scalar)},
            {"name": "Conservative truth completion, full recursion, common driver",
             **measure_text(prefix((ROOT / "checker.py").read_text()) + DRIVER)},
            {"name": "Delivered full recursion, standalone driver",
             **{key: candidates[0][key] for key in KEYS}},
        ]
    result = {
        "python": platform.python_version(), "implementation": platform.python_implementation(),
        "commit": corpus["commit"], "archive_count": len(corpus["archives"]),
        "current_count": len(current), "expanded_paths": len(corpus["expanded_programs"]),
        "expanded_distinct": len(unique), "envelope": envelope,
        "expanded_envelope": expanded, "current": current, "candidates": candidates,
        "common_driver_envelope": controlled_envelope, "common_driver_current": controls,
        "common_driver_candidates": controlled_candidates, "ablations": ablations,
        "scope": "Finite source comparison, not a lower bound over all theories or encodings.",
    }
    (ROOT / "results/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    with (ROOT / "results/current_comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, ["archive", "member", *KEYS, "sha256"], extrasaction="ignore")
        writer.writeheader()
        writer.writerows(current)
    lines = []
    for name, row in [("Old", envelope), ("Direct", candidates[0]), ("Scalar", candidates[1])]:
        for key, suffix in zip(KEYS, ["Tokens", "Nodes", "Bytes"]):
            lines.append("\\newcommand{\\" + name + suffix + "}{" + str(row[key]) + "}")
    (ROOT / "results/numbers.tex").write_text("\n".join(lines) + "\n")
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ("current", "common_driver_current")}, indent=2))


if __name__ == "__main__":
    main()
