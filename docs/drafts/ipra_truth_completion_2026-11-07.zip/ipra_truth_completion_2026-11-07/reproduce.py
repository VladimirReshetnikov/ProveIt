"""Reproduce source measurements and finite implementation checks."""
from pathlib import Path
import argparse
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pdf", action="store_true")
    parser.add_argument("--latex", default="pdflatex")
    args = parser.parse_args()
    subprocess.run([sys.executable, "measure.py"], cwd=ROOT, check=True)
    subprocess.run([sys.executable, "validation/run.py"], cwd=ROOT, check=True)
    if args.pdf:
        subprocess.run([sys.executable, "build.py", "--latex", args.latex], cwd=ROOT, check=True)
    print("Reproduction completed.")


if __name__ == "__main__":
    main()
