"""Compile the self-contained report with a normal LaTeX installation."""
from pathlib import Path
import argparse
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--latex", default=os.environ.get("IPRA_LATEX", "pdflatex"))
    args = parser.parse_args()
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    for _ in range(3):
        result = subprocess.run([args.latex, "-interaction=nonstopmode", "-halt-on-error",
                                 "-output-directory=" + str(build), "report.tex"],
                                cwd=ROOT, text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
        (build / "compiler_stdout.txt").write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-12000:])
            raise SystemExit(result.returncode)
    shutil.copy2(build / "report.pdf", ROOT / "report.pdf")
    print("Compiled report.pdf")


if __name__ == "__main__":
    main()
