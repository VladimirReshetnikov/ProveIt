CONSERVATIVE TRUTH COMPLETION FOR iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026

START HERE

Read report.pdf for the complete construction and proofs. The source is
report.tex with its sections/ and results/ inputs. This package is intended
to be usable without access to the original repository or this conversation.

The principal implementation result is a smaller complete acceptance
program for a presentation of full first-order intuitionistic primitive
recursive arithmetic. All logical rules and nonlogical computation schemas
are stated. The ordinary first-order realizations are bi-interpretable
with iPRA on the entire domain; both composite isomorphisms are equality.

Measured complete sources (tokens / AST nodes / normalized UTF-8 bytes):

  Current inspected corpus minimum:       375 / 403 / 1117
  checker_scalar.py, scalar iteration:    369 / 395 / 1105
  checker.py, full primitive recursion:   374 / 396 / 1098

The unchanged inherited metric counts the complete acceptance source,
including imports, JSON parsing, exception handling, output and exit status.
It removes genuine docstrings and normalizes with Python's ast.unparse.
The recorded runtime is CPython 3.12.14. Counts can depend on the version
of Python's AST and unparser, so use that version for exact reproduction.

With an identical public input/output driver for every program, the scalar
result remains 369 / 395 / 1105 and the old minimum remains 375 / 403 / 1117.
The full-recursion result becomes 376 / 401 / 1117. Its whole-source strict
improvement therefore includes a separately disclosed driver contribution.

This is a strict finite-corpus comparison, not a lower-bound theorem over
all formal languages or a claim of absolute shortestness. The new semantic
idea is conservative truth completion of otherwise rejected formula syntax.
The numerical basis and much of the equivalence development are inherited;
ATTRIBUTION.txt gives the lineage. Global historical novelty is unproved.

The report also proves an equivalent one-binder, four-pattern presentation.
Its reusable arrow contexts have a real implementation cost. The direct
prototype in research/ is larger (416 / 449 / 1176), has only limited smoke
testing, and is not one of the two primary acceptance programs.

RUN A COMPLETE CHECKER

Python 3.10 or later is required. Only the standard library is used.
From this directory:

  python3 checker.py examples/full_counter_step.json
  python3 checker.py examples/addition_2_3.json
  python3 checker_scalar.py examples/zero_computation.json

These print ACCEPT and exit with status zero. For a rejected certificate:

  python3 checker.py examples/unguarded_equation_introduction.json

This prints REJECT and exits with status one. It is the explicit S0 = 0
attack on an earlier, unsafe version of the proposed change. The correct
checkers reject it. The file examples/index.json specifies all public
examples, their variants and verdicts.

A packet is a JSON array consumed from its end. The last element is the
closed goal. The report describes the exact packed syntax and its meaning.
Canonical paired formulas put the same matrix in all three positions;
only the third position is logically meaningful, but all are validated.
Raw annotations, numerical aliases and successful failed-guard fallthrough
are accounted for in the extraction proof. Unused prefix cells may remain.
The complete checker files import none of the support files in this package.

A rejected packet is not a claim that its intended formula is unprovable.
For example, a bare truth leaf is not an accepted root encoding; canonical
proofs supply complete theorem coverage. Soundness concerns all accepted
packets, while completeness is through canonical encodings. Resource failure
also rejects. The metatheory idealizes sufficient finite resources.

REPRODUCE THE RESULTS

  python3 reproduce.py

This repeats the exact source measurements and finite validation and writes
machine-readable receipts in results/. No network access is needed. It
checks source-fixture expectations, translates positive certificates, runs
an independent readable oracle, exercises openings, and tests falsity probes
and three deliberate unsound mutations. Public examples are run both with
ordinary Python and with the -O switch. Assertions are not part of either
primary acceptance decision.

Individual commands:

  python3 measure.py
  python3 validation/run.py

The shipped validation receipt records 342 source expectations, 202 positive
translations (147 scalar and 55 full recursion), 13,266 packet/oracle
comparisons, 11,520 opening comparisons, 5,000 decoded substitution checks,
15,000 successful repeated purity steps, 26,760 targeted/systematic falsity
probes, three mutation controls and 76 public command-line runs. Categories
overlap and are not counts of independent mathematical theorems.

REBUILD THE PDF

Install a normal LaTeX distribution with pdflatex, Latin Modern and the
standard packages named in report.tex. Then run:

  python3 build.py

or:

  python3 reproduce.py --pdf

An alternative compiler executable can be selected with --latex PATH.
build.py also honors the IPRA_LATEX environment variable. It runs three
passes and copies the compiled result to report.pdf. No bibliography tool,
shell escape, external image, or network access is required.

CONTENTS

  report.tex, report.pdf       Complete paper, proofs and full checker listings
  sections/                   Mathematical and implementation sections
  checker.py                  Primary full primitive-recursion checker
  checker_scalar.py           Primary scalar-iteration checker
  examples/                   Public certificates and expected verdicts
  validation/                 Translator, independent oracle and source fixtures
  comparison/                 Unchanged metric, controls and frozen corpus
  results/                    Exact measurements and validation receipts
  research/                   Larger four-pattern implementation experiment
  measure.py                  Offline comparison and ablation reproduction
  reproduce.py                Measurement and validation entry point
  build.py                    PDF build entry point
  ATTRIBUTION.txt              Mathematical and source provenance
  LICENSE_SOURCE.txt          Terms accompanying the inherited sources
  SHA256SUMS.txt               Integrity manifest for the packaged files

PINNED COMPARISON

Repository: VladimirReshetnikov/ProveIt
Commit: 25e16049bbc73c92703296181e0696370c987577
Directory: docs/drafts

https://github.com/VladimirReshetnikov/ProveIt/tree/25e16049bbc73c92703296181e0696370c987577/docs/drafts

The six current ZIPs contain ten root checker sources. Their actual current
minimum is 375 / 403 / 1117; older figures printed inside their reports are
not the current comparison target. An expanded scan of 742 source paths,
representing 153 distinct complete-checker-like source files, has the same
minimum. All 153 unique files and their provenance are bundled. The scan
deliberately over-includes inherited experimental controls; it does not
independently certify the soundness of every old program.

LIMITS OF THE EVIDENCE

The report supplies mathematical proofs, not a Lean or Rocq formalization.
The test suite is finite implementation evidence and cannot establish the
universal metatheorems. The reduction is modest and representation-dependent.
The report's Further research questions identify stronger reductions and
formal certification work that remain open.
