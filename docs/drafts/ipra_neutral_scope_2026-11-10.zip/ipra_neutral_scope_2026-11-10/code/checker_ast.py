from json import load

def c(a, g=([],), k=0):

    def i(a, t=0j, d=0):
        try:
            return [i(b, t, d + 5 - len(a)) for b in a]
        except:
            return a if k <= a < d else d % 2 and i(t, d=3)
    while i(a) not in g:
        m, s, u, t = q()
        c(m, g, k)
        if m in ([s, u], not s and [t] * 3) and i(t, u) == a:
            a = i(t, s)
        h = m * 3 or (u and [[s and [s], u, t], i(t, [s, u, t], 3) if s else u]) or (a := i(*a, t, 2))
        k -= 1
        g += (i(h, (m or len(a) % 2 == u) and k),)
        a = i(a, [k])
c((q := load(open(0)).pop)())
print('ACCEPT')
