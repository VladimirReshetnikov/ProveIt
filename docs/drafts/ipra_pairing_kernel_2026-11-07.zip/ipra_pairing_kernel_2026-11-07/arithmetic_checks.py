"""Finite sanity checks and exact polynomial identities for the new proofs.

These are not native-calculus certificates. The written universal proofs
remain essential. L is evaluated by its intended natural-number meaning.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def C(n, a, b):
    return b if n else a


def L(a, b):
    return int(a <= b)


def iterate(n, a, update):
    for _ in range(n):
        a = update(a)
    return a


def F(m, u):
    return C(L(u + 2, m), u, u + 1)


def V(t, m):
    return iterate(t, 0, lambda u: F(m, u))


# Exact sparse polynomial operations in three formal variables.
def add(p, q):
    result = p.copy()
    for monomial, coefficient in q.items():
        result[monomial] = result.get(monomial, 0) + coefficient
    return {m: c for m, c in result.items() if c}


def mul(p, q):
    result = {}
    for x, a in p.items():
        for y, b in q.items():
            m = tuple(x[i] + y[i] for i in range(3))
            result[m] = result.get(m, 0) + a * b
    return {m: c for m, c in result.items() if c}


def main():
    update_cases = iteration_cases = predecessor_cases = invariant_cases = projection_cases = 0
    for m in range(24):
        require(F(m + 2, 0) == 1, ('update base', m))
        for u in range(24):
            require(F(m + 2, u + 1) == F(m + 1, u) + 1, ('update conjugacy', m, u))
            update_cases += 1
        for t in range(24):
            require(V(t + 1, m + 2) == V(t, m + 1) + 1, ('iteration conjugacy', t, m))
            iteration_cases += 1
    for m in range(60):
        require(V(m + 1, m + 1) == m, ('predecessor', m))
        predecessor_cases += 1
    require(V(0, 0) == 0, 'predecessor zero')
    for a in range(12):
        for b in range(12):
            w = a + b
            n = w * w + a
            value = 0
            root = None
            for i in range(n + 4):
                require(value + max(w - i, 0) == w, ('remainder invariant', a, b, i))
                invariant_cases += 1
                if i == n:
                    root = value
                value = C(L((value + 1) ** 2, n), value, value + 1)
            require(root == w, ('root', a, b))
            left = max(n - root * root, 0)
            right = max(root - left, 0)
            require((left, right) == (a, b), ('projections', a, b))
            projection_cases += 1

    one = {(0, 0, 0): 1}
    x = {(1, 0, 0): 1}
    y = {(0, 1, 0): 1}
    z = {(0, 0, 1): 1}
    w = add(x, y)
    n = add(mul(w, w), x)
    # (a+b+1)^2 = ((a+b)^2+a) + (a+2b+1).
    require(mul(add(w, one), add(w, one)) == add(n, add(add(x, add(y, y)), one)),
            'exact upper-gap coefficients')
    # (v+1+t)^2+a = (v+1)^2 + (2(v+1)t+t^2+a).
    v1 = add(x, one)
    require(add(mul(add(v1, y), add(v1, y)), z) ==
            add(mul(v1, v1), add(add(mul(add(v1, v1), y), mul(y, y)), z)),
            'exact lower-gap coefficients')
    # At w=v+1: w^2+a = w + (wv+a).
    require(add(mul(v1, v1), z) == add(v1, add(mul(v1, x), z)),
            'exact count-witness coefficients')
    result = {
        'status': 'PASS', 'update_conjugacy_cases': update_cases,
        'iteration_conjugacy_cases': iteration_cases, 'predecessor_successor_cases': predecessor_cases,
        'predecessor_zero_case': True, 'search_invariant_cases': invariant_cases,
        'projection_pairs': projection_cases, 'exact_polynomial_identities': 3,
        'limitations': 'Finite standard-natural arithmetic checks and exact polynomial expansions; not formal native proofs. L uses its intended natural-number meaning.',
    }
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/arithmetic.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
