"""Compile the complete paper using ordinary pdfLaTeX, without shell escape."""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
compiler = shutil.which('pdflatex')
if not compiler:
    raise SystemExit('pdflatex is required to rebuild the PDF.')
(ROOT / 'results').mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(prefix='ipra-paper-') as directory:
    environment = os.environ.copy()
    def locate(name):
        return subprocess.run(['kpsewhich', name], env=environment,
                              capture_output=True, text=True).returncode == 0
    # Some minimal installations contain TeX sources but no generated ls-R,
    # format, or font-map files. Build those locally, without downloading.
    distribution = Path('/usr/share/texlive/texmf-dist')
    if not locate('article.cls') and (distribution / 'tex/latex/base/article.cls').exists():
        environment['TEXMF'] = '{/usr/share/texlive/texmf-dist,/usr/share/texmf,/etc/texmf}'
    if not locate('pdflatex.fmt'):
        setup = subprocess.run(['pdftex', '-ini', '-etex', '-interaction=nonstopmode',
                                '-jobname=pdflatex', '-progname=pdflatex', 'pdflatex.ini'],
                               cwd=directory, env=environment, capture_output=True, text=True)
        if setup.returncode:
            raise SystemExit(setup.stdout[-4000:] + setup.stderr)
        environment['TEXFORMATS'] = directory + os.pathsep + environment.get('TEXFORMATS', '')
    if not locate('pdftex.map') and distribution.exists():
        maps = sorted((distribution / 'fonts/map/dvips/amsfonts').glob('*.map'))
        latin_modern = Path('/usr/share/texmf/fonts/map/dvips/lm/lm.map')
        if latin_modern.exists():
            maps.append(latin_modern)
        if maps:
            (Path(directory) / 'pdftex.map').write_bytes(b'\n'.join(p.read_bytes() for p in maps))
            environment['TEXFONTMAPS'] = directory + os.pathsep + environment.get('TEXFONTMAPS', '')
    for number in range(1, 4):
        run = subprocess.run([compiler, '-no-shell-escape', '-interaction=nonstopmode',
                              '-halt-on-error', '-output-directory', directory, 'report.tex'],
                             cwd=ROOT, env=environment, capture_output=True, text=True)
        (ROOT / f'results/latex_pass_{number}.txt').write_text(run.stdout + run.stderr)
        if run.returncode:
            print(run.stdout[-8000:])
            raise SystemExit(run.returncode)
    log = (Path(directory) / 'report.log').read_text(errors='replace')
    failures = [line for line in log.splitlines() if
                'Overfull' in line or 'undefined' in line or 'multiply defined' in line]
    if failures:
        print('\n'.join(failures))
        raise SystemExit('Resolve layout/reference warnings before final delivery.')
    shutil.copy2(Path(directory) / 'report.pdf', ROOT / 'report.pdf')
print('Compiled report.pdf with no overfull boxes or unresolved references.')
