"""Reproduce complete-source and common-driver comparisons offline."""
import ast
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('inherited_measure', ROOT / 'comparison/source_measure.py')
metric = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metric)
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    current = []
    for item in manifest['programs']:
        path = ROOT / 'comparison' / item['local_file']
        row = metric.metrics(path)
        if row['sha256'] != item['sha256']:
            raise ValueError('Changed frozen comparator: ' + item['label'])
        current.append({'label': item['label'], **row})
    candidate = metric.metrics(ROOT / 'checker.py')
    tree = ast.parse((ROOT / 'checker.py').read_text())
    driver_start = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Try))
    driver = tree.body[driver_start:]
    common = []
    with tempfile.TemporaryDirectory() as directory:
        for item in manifest['programs']:
            tree = ast.parse((ROOT / 'comparison' / item['local_file']).read_text())
            start = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Try))
            tree.body[start:] = driver
            path = Path(directory) / item['label']
            path.write_text(ast.unparse(ast.fix_missing_locations(tree)) + '\n')
            common.append({'label': item['label'], **metric.metrics(path)})
    minima = {key: min(row[key] for row in current) for key in KEYS}
    common_minima = {key: min(row[key] for row in common) for key in KEYS}
    if not all(candidate[key] < minima[key] and candidate[key] < common_minima[key] for key in KEYS):
        raise ValueError('Strict complete-source/common-driver comparison failed')
    ablations = [{'file': p.name, **metric.metrics(p)}
                 for p in sorted((ROOT / 'comparison/ablations').glob('*.py'))]
    result = {
        'python': platform.python_version(), 'commit': manifest['commit'],
        'archive_count': len(manifest['archives']), 'root_program_count': len(current),
        'current_minima': minima, 'candidate': candidate,
        'common_driver_minima': common_minima,
        'common_driver_delta': {key: candidate[key] - common_minima[key] for key in KEYS},
        'candidate_reduction': {key: minima[key] - candidate[key] for key in KEYS},
        'complete_programs': current, 'common_driver_programs': common,
        'ablations': ablations,
        'metric_scope': 'Whole acceptance source. Legacy metric core fields are not used.',
    }
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    rows = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
            r'Current archive / program & Tokens & Nodes & Bytes\\', r'\midrule']
    for row in current:
        label = row['label'].replace('ipra_', '').replace('__', ' / ').replace('.py', '')
        rows.append(label.replace('_', r'\_') + ' & ' + ' & '.join(str(row[k]) for k in KEYS) + r'\\')
    rows += [r'\midrule', 'Current minima & ' + ' & '.join(str(minima[k]) for k in KEYS) + r'\\',
             'Delivered checker & ' + ' & '.join(str(candidate[k]) for k in KEYS) + r'\\',
             r'\bottomrule', r'\end{tabular}']
    (ROOT / 'results/current_table.tex').write_text('\n'.join(rows) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in {'complete_programs', 'common_driver_programs'}}, indent=2))


if __name__ == '__main__':
    main()
