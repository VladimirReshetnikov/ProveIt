A SMALLER iPRA CHECKER AND PAIRING BY ONE EQUATION INVARIANT
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific date)

START HERE

Read report.pdf. Its full editable source is report.tex and sections/*.tex.
This package is self-contained after extraction and reproduces its source
measurements and finite validation without network access.

RESULTS

The actual six current ProveIt archives at commit
ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a contain nine root checker programs.
Their complete-source normalized minima are 367 Python tokens / 392 AST
nodes / 1,076 UTF-8 bytes. The delivered checker.py is 360 / 388 / 1,048,
strictly below all three supplied minima under the unchanged inherited metric.

The new syntax idea admits [] as zero at numerical sort and as truth at
formula sort. This removes two rejection entries from the shared traversal
table, while preserving soundness and all old canonical proofs. The final
program also uses a normal early-return simplification and credits the
existing scalar-kernel/truth-completion/Boolean-alias conventions.
Applying the same compact driver to EVERY current source gives a stricter
control envelope of 365 / 390 / 1,068. The final candidate is smaller by
five tokens, two AST nodes, and twenty normalized bytes. Both comparisons
are reproducible. No absolute or encoding-independent shortestness theorem
is claimed.

Two mathematical proof simplifications are new relative to the inspected
current corpus:

1. The inherited scalar predecessor term is justified by shifted conjugacy
   using two post-comparator equation inductions, instead of four.
2. Pairing is proved by the single equation invariant
       A(i,J(a,b)) + d(a+b,i) = a+b.
   It now precedes quantifier-free reflection and avoids the former order,
   balance, monotone-square, and bounded-root development.

The full primitive-recursion compiler therefore also precedes reflection.
The report gives every native axiom/schema/rule, reconstructs full ordinary
intuitionistic logic, supplies the scalar comparator and predecessor proofs,
proves pairing and quantifier-free reflection, and establishes faithful
ordinary bi-interpretability with iPRA. Both ordinary domains are the whole
domain, and both composite isomorphisms have graph x=y.

The arithmetic basis and five-pattern logical calculus are inherited.
No additional primitive rule is removed by this report. The two new proof arguments simplify the metatheory; empty-syntax completion is the separate reduction in the trusted checker.
Worldwide priority is not claimed. These are written proofs, not Lean/Rocq
formalizations; finite tests are supporting implementation evidence.

RUN

  python3 checker.py examples/addition_two_three.json
  python3 checker.py examples/unguarded_equation_introduction.json

The first prints ACCEPT and exits 0. The second prints REJECT and exits 1.
Both behaviors persist under python3 -O. Rejection concerns a certificate,
not the provability of its intended formula. examples/index.json lists all
29 public packets and their expected verdicts.

  python3 reproduce.py
  python3 build.py

Reproduction needs Python 3.10+ and its standard library. Exact reported
counts use CPython 3.12.14 because AST/unparse details can change by version.
The PDF build also needs pdfLaTeX and the standard packages in report.tex.
It disables shell escape and checks layout/reference warnings.

CONTENTS

  report.tex / report.pdf / sections/  Complete paper and source
  checker.py                           Whole trusted project-specific checker
  FORMAT.txt                           Packet grammar and operational details
  examples/                            Runnable positive and negative packets
  comparison/                          Frozen sources, unchanged metric, manifest
  validation/                          Independent oracle, fixtures, attack checks
  results/                             Measurements, arithmetic checks, build logs
  measure.py / arithmetic_checks.py    Offline checks supporting the report
  reproduce.py / build.py / package.py  Reproduction, PDF build, and packaging
  ATTRIBUTION.txt / LICENSE_SOURCE.txt  Source lineage and inherited permission
  SHA256SUMS.txt                        Final package integrity manifest

TRUST AND VALIDATION

checker.py imports only json and sys. It imports no project-specific helper,
proof producer, oracle, theorem database, or universal evaluator. All its
syntax, freshness, inference, input/output, and rejection code is counted.
The entry point uses no assertion. Only literal equations receive induction
hypotheses. The ordinary realization includes the necessary 0=S0 -> falsity
bridge; the native designated contradiction is 0=S0.

Recorded validation: 2,373 packet/oracle comparisons, 3,300 opening checks,
six detected unsound mutations, and 90 actual CLI runs. All five inference
patterns and both computation schemas are exercised. Arithmetic receipts
cover the new invariant and three exact polynomial identities, with their
finite-model limitations explicitly stated. These numbers are not counts
of independently proved universal mathematical theorems.

Resource exhaustion can reject a sufficiently large valid certificate.
Completeness is the usual idealized sufficient-finite-resources statement.
No remote repository modification was made for this deliverable.
