"""Offline finite validation of the zero/truth empty-array completion.

All imported modules here are untrusted validation support.  The complete
acceptance program imports only json and sys.  These finite checks do not
replace the mathematical soundness, completeness or interpretation proofs.
"""
import argparse
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import types

from semantic_oracle import Oracle

HERE = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def load_prefix(source, label):
    """Load function definitions for auditing, without the public CLI driver."""
    tree = ast.parse(source)
    body = []
    for node in tree.body:
        if isinstance(node, ast.Try):
            break
        body.append(node)
    module = types.ModuleType(label)
    exec(compile(ast.Module(body=body, type_ignores=[]), label, 'exec'),
         module.__dict__)
    return module


def normalize(value):
    """The semantic normalization proved in the report: false/true -> 0/1."""
    if type(value) is bool:
        return int(value)
    if type(value) is list:
        return [normalize(child) for child in value]
    if type(value) is dict:
        return {key: normalize(child) for key, child in value.items()}
    return value


def trace(module, packet):
    module.k = 0
    stack = deepcopy(packet)
    try:
        module.take = stack.pop
        result = bool(module.check(stack.pop(), []))
    except Exception:
        result = False
    return result, module.k, len(stack) if type(stack) is list else None


def boolify(value, rng):
    if type(value) is int and value in (0, 1) and rng.randrange(3):
        return bool(value)
    if type(value) is list:
        return [boolify(child, rng) for child in value]
    return value


def paths(value, prefix=()):
    yield prefix
    if type(value) is list:
        for index, child in enumerate(value):
            yield from paths(child, prefix + (index,))


def mutate(value, rng):
    result = deepcopy(value)
    path = rng.choice(list(paths(result)))
    replacements = [False, True, 0, 1, 2, 3, -1, -99, [0], [], None,
                    0.0, 'x', {}, [0, 0], [0, 0, 0], [], [[], [], []], [[], 0, []]]
    replacement = deepcopy(rng.choice(replacements))
    if not path:
        return replacement
    parent = result
    for index in path[:-1]:
        parent = parent[index]
    parent[path[-1]] = replacement
    return result


def opening_checks(candidate):
    """Compare binding boundaries with the independent, explicitly sorted oracle."""
    values = [-99, -2, -1, 0, 1, 2, 3, 5, True, False, 0.0, 'x', {}, [],
              [0], [1], [0, 0], [1, 0], [0, 0, 1], [0, 0, 3],
              [[1, 0]], [[3, 3], [3, 3], [3, 3]],
              [[], [], []], [1, [], []], [[], 0, 1]]
    images = [None, 0, [0], True, False, 1, -1, [0, 0, 1], [0, 0], [0, 0, 3], []]
    total = successful = 0
    for formula in (True, False):
        for value in values:
            for protected in range(3):
                for lower in (0, -2):
                    for image in images:
                        candidate.k = lower
                        try:
                            actual = candidate.inst(deepcopy(value), deepcopy(image),
                                                    2 * protected + (not formula))
                            success = True
                        except Exception:
                            actual, success = None, False
                        oracle = Oracle(1)
                        oracle.lower = lower
                        try:
                            operation = oracle.formula if formula else oracle.term
                            expected = operation(normalize(value), normalize(image), protected)
                            expected_success = True
                        except Exception:
                            expected, expected_success = None, False
                        require(success == expected_success and
                                (not success or normalize(actual) == expected),
                                ('opening', formula, value, protected, lower, image))
                        total += 1
                        successful += success
    return {'comparisons': total, 'successful_openings': successful}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checker', type=Path, default=HERE.parent / 'checker.py')
    options = parser.parse_args()
    path = options.checker.resolve()
    source = path.read_text()
    candidate = load_prefix(source, 'candidate')
    reference_source = (HERE / 'reference_truth_scalar.py').read_text()
    reference = load_prefix(reference_source, 'reference')
    fixtures = json.loads((HERE / 'positive_fixtures.json').read_text())
    attacks = json.loads((HERE / 'attacks.json').read_text())
    empty_cases = json.loads((HERE / 'empty_cases.json').read_text())
    counts = Counter()
    rules = Counter()
    observations = []
    rng = random.Random(72661107)

    def audit(packet, label, expected=None, count_rules=False, compare_reference=False):
        actual = trace(candidate, packet)
        normalized = normalize(packet)
        old = trace(reference, normalized)
        independent = Oracle(1).run(normalized)
        if compare_reference:
            require(actual == old, ('canonical reference preservation', label, actual, old))
            counts['canonical_reference_comparisons'] += 1
        elif actual[0] and not old[0]:
            counts['accepted_extra_encodings'] += 1
        require(actual[0] == independent['accepted'],
                ('independent verdict', label, actual, independent))
        if actual[0]:
            require(actual[1:] == (independent['final_k'], independent['remaining']),
                    ('independent accepted trace', label, actual, independent))
        if expected is not None:
            require(actual[0] == expected, ('expected verdict', label, actual[0]))
        counts['packet_comparisons'] += 1
        counts['accepted' if actual[0] else 'rejected'] += 1
        if count_rules:
            rules.update(independent['rules'])
        observations.append({'label': label, 'accepted': actual[0]})

    for index, fixture in enumerate(fixtures):
        packet = fixture['packet']
        audit(packet, 'canonical/' + str(index), True, True, True)
        for variant in range(4):
            audit(boolify(packet, rng), f'Boolean-alias/{index}/{variant}', True, compare_reference=True)
    for index in range(1200):
        packet = boolify(rng.choice(fixtures)['packet'], rng)
        audit(mutate(packet, rng), 'mutation/' + str(index))
    for row in attacks:
        audit(row['packet'], 'targeted/' + row['name'], row['expected'])
    alias_examples = {
        'Boolean_zero': [[], [[0, False, 0], 0]],
        'Boolean_state_coordinate': [[], [[[0], 0, True], [0, 0, True]]],
        'truth_formula_boolean': [0, [[False], [False], [False]]],
    }
    for name, packet in alias_examples.items():
        audit(packet, 'targeted/' + name, True)
    for row in empty_cases:
        audit(row['packet'], 'empty-completion/' + row['name'], row['expected'])

    # Closed false equations have an unambiguous standard-model meaning.
    # These probes deliberately combine new empty-array syntax with arbitrary
    # old/new proof prefixes, without treating failure as unprovability.
    def numeral(n, zero):
        term = deepcopy(zero)
        for _ in range(n): term = [term]
        return term
    false_goals = [[numeral(n, left), numeral(m, right)]
                   for n, m in ((0, 1), (1, 0), (1, 2), (2, 1))
                   for left in (0, []) for right in (0, [])]
    prefix_pool = [row['packet'] for row in fixtures]
    prefix_pool += [row['packet'] for row in empty_cases if row['expected']]
    for index in range(400):
        packet = deepcopy(rng.choice(prefix_pool))
        packet[-1] = deepcopy(false_goals[index % len(false_goals)])
        audit(packet, 'false-equation/' + str(index), False)
    required_rules = {'hypothesis', 'paired_introduction', 'paired_elimination',
                      'closure_elimination', 'equality_transport',
                      'computation_zero', 'computation_successor'}
    require(required_rules <= rules.keys(), ('missing rule coverage', required_rules - rules.keys()))

    controls = []
    for site in json.loads((HERE / 'mutation_sites.json').read_text()):
        require(source.count(site['before']) == 1, ('mutation source site', site['name']))
        mutant = load_prefix(source.replace(site['before'], site['after']), site['name'])
        packet = next(row['packet'] for row in attacks if row['name'] == site['name'])
        good, bad = trace(candidate, packet)[0], trace(mutant, packet)[0]
        require(not good and bad, ('mutation control', site['name'], good, bad))
        controls.append({'name': site['name'], 'correct_accepts': good, 'mutant_accepts': bad})

    # Exercise the *complete* command-line program, including parsing,
    # output, exit codes and Python -O, on all rules and the principal attacks.
    selected_names = {'D_elimination_then_Q_elimination', 'transport_under_Q',
                      'atomic_induction_recursion_identity', 'addition_two_three',
                      'retained_false_base_is_used', 'successor_uses_state',
                      'zero_initialization'}
    cli_cases = [(row['source_name'], row['packet'], True) for row in fixtures
                 if row['source_name'] in selected_names]
    cli_cases += [(row['name'], row['packet'], row['expected']) for row in attacks]
    cli_cases += [(name, packet, True) for name, packet in alias_examples.items()]
    cli_cases += [(row['name'], row['packet'], row['expected']) for row in empty_cases]
    cli_rows = []
    with tempfile.TemporaryDirectory() as directory:
        packet_path = Path(directory) / 'packet.json'
        for name, packet, expected in cli_cases:
            packet_path.write_text(json.dumps(packet) + '\n')
            for optimized in (False, True):
                command = [sys.executable] + (['-O'] if optimized else [])
                result = subprocess.run(command + [str(path), str(packet_path)],
                                        capture_output=True, text=True, timeout=30)
                require(result.returncode == (0 if expected else 1) and
                        result.stdout.strip() == ('ACCEPT' if expected else 'REJECT'),
                        ('public CLI', name, optimized, result.returncode,
                         result.stdout, result.stderr))
                cli_rows.append({'name': name, 'optimized': optimized, 'accepted': expected})

    result = {
        'status': 'PASS',
        'python': platform.python_version(),
        'checker_sha256': sha256(path.read_bytes()).hexdigest(),
        'reference_sha256': sha256((HERE / 'reference_truth_scalar.py').read_bytes()).hexdigest(),
        'oracle_sha256': sha256((HERE / 'semantic_oracle.py').read_bytes()).hexdigest(),
        'seed': 72661107,
        'positive_source_fixtures': len(fixtures),
        'Boolean_alias_variants': 4 * len(fixtures),
        'mutated_packets': 1200,
        'false_equation_probes': 400,
        'dedicated_empty_completion_packets': len(empty_cases),
        'targeted_negative_packets': len(attacks),
        'targeted_positive_alias_packets': len(alias_examples),
        **dict(counts),
        'canonical_rule_coverage': dict(rules),
        'empty_completion_cases': [{'name': row['name'], 'expected': row['expected']}
                                   for row in empty_cases],
        'opening_checks': opening_checks(candidate),
        'mutation_controls': controls,
        'CLI_runs': len(cli_rows),
        'CLI_details': cli_rows,
        'packet_observations': observations,
        'limitations': 'Finite executable evidence; not a proof-assistant formalization.',
    }
    (HERE / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key not in {'CLI_details', 'packet_observations'}}, indent=2))


if __name__ == '__main__':
    main()
