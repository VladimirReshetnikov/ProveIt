SELF-CONTAINED EMPTY-COMPLETION VALIDATION

From the final package root run:
  python3 validation/run.py
The default production source is checker.py. Select another complete source
with --checker PATH. Python 3.10+ and the standard library are sufficient.
Recorded results used CPython 3.12.14. No network is used.

The new explicit oracle accepts empty arrays at numerical and formula sort,
while preserving the exact raw arrays used by the checker. Only Booleans are
normalized to integers for comparison. A global empty-array-to-zero rewrite
would be invalid because [] is also an instruction and a formula encoding;
no such simulation claim is made. The old exact-integer reference additionally
confirms preservation of all 147 canonical positives and 588 Boolean variants.

The receipt results.json records 2373 packet comparisons (952 accept and
1421 reject), including 1200 mutations, 400 false-equation probes, 17 dedicated
empty-completion cases, 18 other targeted negatives and 3 positive aliases.
There are 3300 independent sorted-opening comparisons, six deliberately
incorrect-program controls, and 90 complete CLI runs, half under Python -O.
All five logical rule patterns and both computation schemas occur in accepted
canonical certificates. Test populations can overlap and are not counts of
independent mathematical theorems. Fifty-four accepted test packets use extra
encodings unavailable in the previous raw grammar; these are expected.

The source checker imports none of this validation support. The AST loader
is confined to an untrusted test harness; the full public command line is
also run normally and with -O. Finite evidence does not establish the universal
metatheorems. Source lineage and terms are supplied alongside this file.
