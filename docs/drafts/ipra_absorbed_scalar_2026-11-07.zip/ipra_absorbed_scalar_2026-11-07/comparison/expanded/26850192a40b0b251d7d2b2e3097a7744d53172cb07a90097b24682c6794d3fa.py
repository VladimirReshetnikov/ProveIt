"""Locally nameless iPRA checker with monotone eigenparameter allocation."""
import json
import sys
k = 0

def inst(a, env=(), d=0, formula=True):
    global k
    if type(a) is int and (not formula):
        k = min(k, a)
        return a if a <= d else inst(env[a - d - 1], formula=False)
    tag, *args = a
    return [tag, *(inst(b, env, d + width, width == 1) for b, width in zip(args, ({'=': b'\x00\x00', 'u': b'\x01', 'ex': b'\x01'} if formula else {'s': b'\x00', 'r': b'\x00\x00\x02'})[tag], strict=True))]

def check(a, p, g):
    global k
    inst(a)
    match (a, p.pop()):
        case [['u', b], []]:
            h = [inst(b, [0]), b][:len(b) - 1]
        case [['ex', b], [t]]:
            return check(inst(b, [t]), p, g)
        case [_, [[tag, *parts] as m, t]] if check(m, p, g):
            if tag == 'ex':
                b, h = (a, parts)
            else:
                if tag == 'u':
                    t, parts = (*parts, [0, t])
                b, c = (inst(t, [v]) for v in parts)
                return c == a and check(b, p, g)
        case [[_, [_, n, t, h], b], []]:
            if n:
                _, n = n
                t = inst(h, (['r', n, t, h], n), formula=False)
            return b == t
        case _:
            return a in g
    k -= 1
    return check(inst(b, [['s', k]]), p, g + [inst(c, [k]) for c in h])
if __name__ == '__main__':
    try:
        _, path = sys.argv
        if not check(*json.load(open(path, 'rb')), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
