"""Complete iPRA theorem checker; used substitution images are validated."""
import json
import sys


def inst(a, env=0, d=0):
    if type(a) is int and d % 2 and a >= k:
        return a if a < d else inst(env[a - d >> 1], d=1)
    return [inst(b, env, d + w) for b, w in zip(a + [], (None, None, b'\2', b'\0', b'\1\1', None, b'\2\2\2', b'\0\0\4')[2 * len(a) + d % 2])]


def check(a, g):
    global k
    inst(a)
    if a in g:
        return True
    match (a, take()):
        case [b, [m, t]] if check(m, g):
            if m[2:]:
                h = m[:1]
            else:
                if len(m) == 1:
                    t, m = m[0], [0, t]
                return inst(t, m[1:]) == a and check(inst(t, m[:1]), g)
        case [[b], _]:
            h = [b, inst(b, [0])][len(b) % 2:]
        case [[b, _, _], [t]]:
            return check(inst(b, [t]), g)
        case [[[n, t, r], b], _]:
            if n:
                n, = n
                t = inst(r, ([n, t, r], n), d=1)
            return b == t
    k -= 1
    return check(inst(b, [[k]]), g + [inst(c, [k]) for c in h])


if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        k = -len(take())
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except:
        print('REJECT')
        sys.exit(1)
