"""Complete closed-goal iPRA checker using bit-coded unary formula spines."""
import json
import sys
k = 0


def inst(a, env=(), d=0):
    if not d:
        c, s, t = a
        if type(c) is not int or c < 1:
            raise ValueError
        return [c] + [inst(b, env, c.bit_length()) for b in (s, t)]
    if type(a) is int and a >= k:
        return a if a < d else inst(env[a - d], d=1)
    return [inst(b, env, d + w) for b, w in zip(a + [], (None, b'\0', None, b'\0\0\2')[len(a)])]


def check(a, g):
    global k
    b = inst(a)
    c = b[0]
    b[0] //= 2
    match take():
        case [m, u] if check(m, g):
            if not m[0] % 2:
                m[0] //= 2
                u, m = m, [1, 0, u]
            if m[0] == 1:
                return inst(u, m[2:]) == a and check(inst(u, m[1:2]), g)
            m[0] //= 2
            h = [m]
            b = a
        case [] if not c % 2:
            h = [b, inst(b, [0])][c > 2:]
        case [u] if c > 1 and c % 2:
            return check(inst(b, [u]), g)
        case [] if c == 1:
            n, t, h = a[1]
            if n:
                n, = n
                t = inst(h, ([n, t, h], n), d=1)
            return a[2] == t
        case _:
            return a in g
    k -= 1
    return check(inst(b, [[k]]), g + [inst(c, [k]) for c in h])


if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
