"""Complete arity iPRA checker with fresh eigenparameters and one proof stream."""
import json
import sys
k = 0


def inst(a, env=(), d=0, sort=True):
    global k
    if type(a) is int and not sort:
        k = min(k, a)
        return a if a <= d else env[a - d - 1]
    return [inst(b, env, d + width, width == 1) for b, width in zip(a + [], ((None, b'\0', b'', b'\0\0\2'), (None, b'\1', b'\0\0', b'\1\1\1'))[sort][len(a)], strict=True)]


def check(a, g):
    global k
    b = inst(a)
    match (a, take()):
        case [_, [m, t]] if check(m, g):
            if len(m) == 3:
                h = m[:1]
            else:
                if len(m) == 1:
                    t, m = m[0], [0, inst(t, sort=False)]
                b, c = (inst(t, [v]) for v in m)
                return c == a and check(b, g)
        case [[b], []]:
            h = [inst(b, [0]), b][:2 - len(b) % 2]
        case [[b, _, _], [t]]:
            return check(inst(b, [inst(t, sort=False)]), g)
        case [[[n, t, h], b], []]:
            if n:
                n, = n
                t = inst(h, [[n, t, h], n], sort=False)
            return b == t
        case _:
            return a in g
    k -= 1
    return check(inst(b, [[k]]), g + [inst(c, [k]) for c in h])
if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
