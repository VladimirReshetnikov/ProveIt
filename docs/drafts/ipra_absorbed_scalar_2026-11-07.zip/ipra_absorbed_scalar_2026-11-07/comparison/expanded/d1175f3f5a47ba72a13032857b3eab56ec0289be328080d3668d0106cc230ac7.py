import json
import sys
k=0

def inst(a, env=(), d=0):
    if type(a) is int:
        global k
        k=min(k,a)
        return a if a<=d else inst(env[a-d-1])
    return [inst(b,env,d+w) for b,w in zip(a+[],(None,b'\0',None,b'\0\0\2')[len(a)])]

def form(a,env=()):
    s,t,*p=a+[]
    return [inst(s,env,len(p)),inst(t,env,len(p)),*p]

def check(a,g):
    global k
    form(a)
    if a in g:
        return True
    match (a,take()):
        case [_,[m,t]] if check(m,g):
            if len(m)>2 and not len(m)%2:
                h=[m[:-1]]
                b=a
            else:
                if len(m)%2:
                    t,m=m[:-1],[0,t]
                b,c=(form(t,[v]) for v in m)
                return c==a and check(b,g)
        case [_,[]] if len(a)%2:
            b=a[:-1]
            h=[form(b,[0]),b][:1+(len(a)==3)]
        case [_,[t]] if len(a)>2 and not len(a)%2:
            return check(form(a[:-1],[t]),g)
        case [[[n,t,h],b],[]]:
            if n:
                n,=n
                t=inst(h,([n,t,h],n))
            return b==t
    k-=1
    return check(form(b,[[k]]),g+[form(c,[k]) for c in h])

if __name__=='__main__':
    try:
        take=json.load(open(sys.argv[1])).pop
        if not check(take(),[]): raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
