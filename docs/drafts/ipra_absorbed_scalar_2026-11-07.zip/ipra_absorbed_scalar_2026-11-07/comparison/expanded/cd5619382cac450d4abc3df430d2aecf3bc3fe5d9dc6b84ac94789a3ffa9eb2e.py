"""Complete iPRA theorem checker; used substitution images are validated."""
import json
import sys
k = 0


def inst(a, env=(), d=0):
    global k
    if type(a) is int and d % 2:
        k = min(k, a)
        return a if a <= d // 2 else inst(env[a - d // 2 - 1], d=1)
    return [inst(b, env, d + w) for b, w in zip(a + [], (None, None, b'\2', b'\0', b'\1\1', None, b'\2\2\2', b'\0\0\4')[2 * len(a) + d % 2])]


def check(a, g):
    global k
    b = inst(a)
    if a in g:
        return True
    match (a, take()):
        case [_, [m, t]] if check(m, g):
            if len(m) == 3:
                h = m[:1]
            else:
                if len(m) == 1:
                    t, m = m[0], [0, t]
                b, c = (inst(t, [v]) for v in m)
                return c == a and check(b, g)
        case [[b], []]:
            h = [b, inst(b, [0])][len(b) % 2:]
        case [[b, _, _], [t]]:
            return check(inst(b, [t]), g)
        case [[[n, t, r], b], []]:
            if n:
                n, = n
                t = inst(r, ([n, t, r], n), d=1)
            return b == t
    k -= 1
    return check(inst(b, [[k]]), g + [inst(c, [k]) for c in h])


if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
