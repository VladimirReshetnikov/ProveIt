"""Open-goal iPRA checker with an explicit finite parameter context."""
import json
import sys


def inst(a, env=0, d=0):
    if type(a) is int and d % 2 and a >= k:
        return a if a <= d // 2 else inst(env[a - d // 2 - 1], d=1)
    return [inst(b, env, d + w) for b, w in zip(a + [], (0, 0, b'\2', b'\0', b'\1\1', 0, b'\2\2\2', b'\0\0\4')[len(a) * 2 + d % 2])]


def check(a, g):
    global k
    b = inst(a)
    match (a, take()):
        case [_, [m, t]] if check(m, g):
            if m[2:]:
                h = m[:1]
            else:
                if not m[1:]:
                    t, m = m[0], [0, t]
                b, c = (inst(t, [v]) for v in m)
                return c == a and check(b, g)
        case [[b], []]:
            h = [inst(b, [0]), b][:2 - len(b) % 2]
        case [[b, _, _], [t]]:
            return check(inst(b, [t]), g)
        case [[[n, t, h], b], []]:
            if n:
                n, = n
                t = inst(h, ([n, t, h], n), d=1)
            return b == t
        case _:
            return a in g
    k -= 1
    return check(inst(b, [[k]]), g + [inst(c, [k]) for c in h])


if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        k = -len(take())
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
