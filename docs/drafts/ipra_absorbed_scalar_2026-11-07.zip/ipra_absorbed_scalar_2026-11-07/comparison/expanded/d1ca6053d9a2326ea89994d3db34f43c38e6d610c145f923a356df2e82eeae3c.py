"""Complete iPRA checker with scalar iteration and a paired logical binder."""
import json
import sys
k = 0


def inst(a, *env, d=0):
    if type(a) is int and d % 2 and a >= k:
        return a if a < d else inst(env[a - d >> 1], d=1)
    return [inst(b, *env, d=d + w) for b, w in zip(a + [], (0, 0, b'\2', b'\0', b'\1\1', 0, b'\4\4\4', b'\0\0\2')[len(a) * 2 + d % 2])]


def check(a, g):
    global k
    if inst(a) in g:
        return True
    match (a, take()):
        case [b, [m, t]] if check(m, g):
            if m[2:]:
                h = [m[:1]]
            else:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
        case [[b, _, _], [t]]:
            b = inst(b, t, d=2)
            h = [inst(b, 0), b][:2 - len(b) % 2]
        case [[[n, t, r], b], []]:
            if n:
                n, = n
                t = inst(r, [n, t, r], d=1)
            return b == t
    k -= 1
    return check(inst(b, [k]), g + [inst(c, k) for c in h])


if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
