"""Closed-sentence iPRA checker with parameters declared before use."""
import json
import sys
k = 0


def inst(a, env=(), d=0):
    if type(a) is int and d % 2 and a >= k:
        return a if a < d else inst(env[a - d >> 1], d=1)
    return [inst(b, env, d + w) for b, w in zip(a + [], (None, None, b'\2', b'\0', b'\1\1', None, b'\2\2\2', b'\0\0\4')[2 * len(a) + d % 2])]


def check(a, g):
    global k
    match (inst(a), take()):
        case [b, [m, t]] if check(m, g):
            if len(m) == 3:
                h = m[:1]
            else:
                if len(m) == 1:
                    t, m = m[0], [0, t]
                return inst(t, m[1:]) == a and check(inst(t, m[:1]), g)
        case [[b], []]:
            h = [inst(b, [0]), b][:2 - len(b) % 2]
        case [[b, _, _], [t]]:
            return check(inst(b, [t]), g)
        case [[[n, t, h], b], []]:
            if n:
                n, = n
                t = inst(h, ([n, t, h], n), d=1)
            return b == t
        case _:
            return a in g
    k -= 1
    return check(inst(b, [[k]]), g + [inst(c, [k]) for c in h])


if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except:
        print('REJECT')
        sys.exit(1)
