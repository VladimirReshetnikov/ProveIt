"""Complete iPRA checker whose unread proof stream supplies fresh names."""
import json
import sys


def inst(a, env=0, d=0):
    if type(a) is int and d % 2 and not -len(p) <= a < 0:
        return a if a < d else inst(env[a - d >> 1], d=1)
    return [inst(b, env, d + w) for b, w in zip(a + [], (0, 0, b'\2', b'\0', b'\1\1', 0, b'\2\2\2', b'\0\0\4')[2 * len(a) + d % 2])]


def check(a, g):
    match (inst(a), p.pop()):
        case [b, [m, t]] if check(m, g):
            if m[2:]:
                h = m[:1]
            else:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1:]) == a and check(inst(t, m[:1]), g)
        case [[b], []]:
            h = [b, inst(b, [0])][len(b) % 2:]
        case [[b, _, _], [t]]:
            return check(inst(b, [t]), g)
        case [[[n, t, h], b], []]:
            if n:
                n, = n
                t = inst(h, ([n, t, h], n), d=1)
            return b == t
        case _:
            return a in g
    k = ~len(p)
    return check(inst(b, [[k]]), g + [inst(c, [k]) for c in h])


if __name__ == '__main__':
    try:
        p = json.load(open(sys.argv[1]))
        if not check(p.pop(), []):
            raise ValueError
        print('ACCEPT')
    except:
        print('REJECT')
        sys.exit(1)
