"""Finite checks accompanying the Boolean-erasure simulation proof.

This is untrusted validation code, not imported by either checked kernel.
It does not assert that finite testing proves soundness.
"""

import ast
import importlib.util
import io
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import tokenize
from copy import deepcopy

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "frozen/strict_scalar_sort.py"
CANDIDATE = HERE / "checker.py"
CORPUS = HERE / "fixtures/scalar_cases.json"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def erase(value):
    if type(value) is bool:
        return int(value)
    if type(value) is list:
        return [erase(v) for v in value]
    if type(value) is dict:
        return {k: erase(v) for k, v in value.items()}
    return value


def booleanize(value, selector):
    if type(value) is int and value in (0, 1) and selector(value):
        return bool(value)
    if type(value) is list:
        return [booleanize(v, selector) for v in value]
    if type(value) is dict:
        return {k: booleanize(v, selector) for k, v in value.items()}
    return value


def verdict(module, packet):
    module.k = 0
    stream = deepcopy(packet)
    try:
        module.take = stream.pop
        accepted = bool(module.check(stream.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return accepted, error, module.k, len(stream) if type(stream) is list else None


def opening(module, value, env, d, k):
    module.k = k
    try:
        return True, module.inst(deepcopy(value), *deepcopy(env), d=d)
    except Exception as exc:
        return False, type(exc).__name__


def metrics(path):
    return load(HERE / "frozen/source_measure.py", "frozen_source_measure").metrics(path)


def main():
    reference = load(SOURCE, "strict_sort_scalar")
    candidate = load(CANDIDATE, "boolean_sort_scalar")
    rng = random.Random(20261107)
    cases = json.loads(CORPUS.read_text()) + json.loads((HERE / "fixtures/direct_introduction.json").read_text())
    checked = 0
    accepted = 0
    intentional_changes = []
    cli_cases = []

    def compare(packet, name):
        nonlocal checked, accepted
        actual = verdict(candidate, packet)
        expected = verdict(reference, erase(packet))
        if actual != expected:
            raise AssertionError((name, actual, expected, packet))
        checked += 1
        accepted += actual[0]
        return actual[0]

    for case in cases:
        packet = case["packet"]
        actual = compare(packet, case["name"])
        if actual != case["expected"]:
            intentional_changes.append({"name": case["name"], "old": case["expected"],
                                        "new": actual})
        selectors = [lambda n: n == 0, lambda n: n == 1, lambda n: True]
        selectors += [lambda n: rng.randrange(2) == 0 for _ in range(5)]
        for index, selector in enumerate(selectors):
            transformed = booleanize(packet, selector)
            compare(transformed, (case["name"], index))
        if len(cli_cases) < 8 or case["name"] in {
                "boolean_in_unused_update", "nonexistent_counter_slot",
                "scalar_contextual_capture", "compound_induction_hypothesis",
                "false_eigenparameter_escape"} or case["name"].startswith("direct_"):
            transformed = booleanize(packet, lambda n: True)
            cli_cases.append((case["name"], transformed, compare(transformed, case["name"])))

    # Deliberately malformed packets exercise the exact normalization claim,
    # including arbitrary JSON types in unused positions.
    leaves = [False, True, 0, 1, 2, -1, -2, 0.0, 0.5, -0.5,
              float("nan"), float("inf"), "", "x", None, {}]

    def arbitrary(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return deepcopy(rng.choice(leaves))
        if rng.randrange(8) == 0:
            return {"ignored": arbitrary(depth - 1)}
        return [arbitrary(depth - 1) for _ in range(rng.randrange(5))]

    malformed = 2048
    for index in range(malformed):
        compare(arbitrary(4), ("malformed", index))

    # Scoped openings cover Boolean aliases both before and under binders.
    values = leaves + [[v] for v in leaves]
    values += [[0, 0], [False, False], [True, 0], [[True, True]],
               [[True, 0], [0, 0], [0, 0]],
               [0, False, True], [0, 0, [0, 0, True]],
               [[0, 0, True], False], [0, 0, 3], [0, 0, 4]]
    environments = [(), (0,), (False,), (True,), ([0],), (-1,),
                    (0, [False]), (True, False)]
    opening_checks = 0
    for value in values:
        for env in environments:
            for d in range(7):
                for k in (0, -1, -3):
                    actual = opening(candidate, value, env, d, k)
                    expected = opening(reference, erase(value), erase(list(env)), d, k)
                    if actual[0] != expected[0] or (
                            actual[0] and erase(actual[1]) != expected[1]) or (
                            not actual[0] and actual[1] != expected[1]):
                        raise AssertionError(("opening", value, env, d, k, actual, expected))
                    opening_checks += 1

    cli_checks = 0
    with tempfile.TemporaryDirectory() as temporary:
        for index, (name, packet, accepted_packet) in enumerate(cli_cases):
            path = Path(temporary) / (str(index) + ".json")
            path.write_text(json.dumps(packet))
            for optimized in (False, True):
                result = subprocess.run([sys.executable,
                    *(["-O"] if optimized else []), str(CANDIDATE), str(path)],
                    text=True, capture_output=True, timeout=10)
                expected = (0, "ACCEPT\n", "") if accepted_packet else (1, "REJECT\n", "")
                actual = result.returncode, result.stdout, result.stderr
                if actual != expected:
                    raise AssertionError(("CLI", name, optimized, actual, expected))
                cli_checks += 1

    result = {"status": "PASS", "python": sys.version.split()[0],
              "candidate": metrics(CANDIDATE), "strict_reference": metrics(SOURCE),
              "original_scalar": metrics(HERE / "frozen/scalar_original.py"),
              "original_sort": metrics(HERE / "frozen/sort_original.py"),
              "packet_simulations": checked, "accepted_packet_simulations": accepted,
              "malformed_packets_included": malformed,
              "opening_simulations": opening_checks, "command_line_checks": cli_checks,
              "intentional_old_format_changes": intentional_changes,
              "limits": "Finite implementation evidence; soundness rests on the separate all-JSON Boolean-erasure simulation and scalar/sort calculus proofs."}
    (HERE / "boolean_validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
