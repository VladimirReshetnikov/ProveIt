ONE SCALAR ITERATOR FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 7 November 2026

START HERE

report.pdf is the complete paper. report.tex and sections/*.tex are its
editable LaTeX sources. The principal result combines two reductions that
the pinned drafts treated separately: successor is an abbreviation and the
iterator update binds only the previous value, without a counter coordinate.

Terms:
    t ::= variable | 0 | A(n,a;u.h)
    S(a) := A(0,a;u.0)

Computation schemas:
    A(0,a;u.h) = S(a)
    A(S(n),a;u.h) = h[A(n,a;u.h)/u]

The crucial derived finite term delta satisfies delta(0)=1 and delta(S(n))=n.
It recovers an arbitrary-initialized scalar iterator. The paper supplies
the full native logical rules, the entire decoder construction, logical
reconstruction, internal arithmetic and pairing, ordinary first-order
realization, and both definable interpretation isomorphisms with iPRA.

WHAT THE CLAIM DOES AND DOES NOT MEAN

The ordinary realization is bi-interpretable with full first-order iPRA,
not merely its quantifier-free fragment. Both interpretations use the whole
numeric domain; both composite isomorphisms have graph x=y. Native falsity
is the chosen equation 0=S(0); the ordinary realization explicitly includes
its bridge to ordinary falsity.

The strict size comparison is against the supplied finite corpus at commit
b10a56a8f655c607494a3069b31d6679d968797a. It is not a global shortestness
theorem or a historical-priority claim. One binding constructor represents
a recursively specified family of ordinary first-order function symbols,
not a universal evaluator. The two computation schemas have infinitely many
instances. Small primitive syntax trades against long derived terms and
expensive naive evaluation.

The proofs are written mathematical proofs with an independent second
review. No Lean or Rocq proof-assistant formalization is claimed. Finite
executable checks support implementation confidence but are not proofs of
the metatheorems. No GitHub repository changes were made.

COMPLETE-CHECKER COMPARISON

                            Normalized tokens   AST nodes   Normalized bytes
Current coordinate minima                 411         425               1207
Direct A checker.py                       406         423               1159
Derived-I checker_derived.py               409         423               1202

All imports, syntax validation, scope checks, proof rules, input decoding,
and verdict code are included. The unchanged source metric removes true
docstrings, normalizes with ast.unparse, and measures the complete source.
Its auxiliary 'core' heuristic is not used for the standalone checker.

The direct checker is a standalone CLI without an importability wrapper.
It checks the displayed A equations directly. The companion retains the
old importable entry-point wrapper and checks the provably equivalent
ordinary scalar-iterator presentation. Its separate improvement is also
strict in all three coordinates. Driver and serialization savings are not
attributed entirely to the arithmetic reduction.

The comparison inventory contains fourteen current root/research programs
from six distinct ZIP archives. An expanded scan of 58 distinct complete
sources at 180 paths has the same minima. Original filenames, Git blob
identities, SHA-256 hashes, source paths, and measured values are recorded
in comparison/manifest.json and results/metrics.json. The comparator source
files needed to reproduce the measurement are included; downloading the
archives again is unnecessary.

HOW TO REPRODUCE

Use CPython 3.12.14 for the exact published metric. The checkers require
Python 3.10 or later because they use structural pattern matching; exact
normalization counts can depend on the Python release. Validation scripts
use only the standard library and require no network access.

From this directory:

    python3 reproduce.py

This checks that each delivered checker is byte-identical to its audited
copy, verifies comparator hashes, remeasures the full corpus, runs the
direct checker audit, runs the companion audit, and evaluates the literal
arithmetic definitions. It writes refreshed JSON results. On failure it
exits nonzero. Finite evidence is deterministic except elapsed-time fields.

Individual commands:

    python3 measure.py
    python3 kernel_audit/validate.py
    python3 companion_audit/validate.py
    python3 validation/absorbed_scalar_audit.py

To rebuild the PDF, install a normal TeX Live environment with pdfLaTeX,
lmodern, microtype, AMS packages, geometry, booktabs, longtable, xcolor,
listings, fancyhdr, enumitem, hyperref, and xurl, then run:

    python3 build.py

The compiled PDF is included. Rebuilding is not necessary to read it.

To exercise the primary directly:

    python3 checker.py kernel_audit/examples/computation_00.json
    python3 checker.py kernel_audit/examples/false_equality.json

The first prints ACCEPT and exits 0. The second prints REJECT and exits 1.
FORMAT.txt gives the complete certificate grammar and examples. Use the
companion's own examples with checker_derived.py; its introduction records
and computation equations differ.

PACKAGE MAP

report.pdf, report.tex, sections/    Complete paper and editable sources
checker.py                          Entire trusted direct acceptance program
checker_derived.py                  Entire trusted companion acceptance program
FORMAT.txt                          Direct certificate format and rule records
build.py                            Offline PDF rebuild
reproduce.py                        One-command finite evidence reproduction
measure.py                          Pinned corpus and candidate measurement
comparison/                         Unchanged metric, comparators, provenance
kernel_audit/                       Named-variable oracle, native packets,
                                    mutation controls, strict reference
companion_audit/                    Separate Boolean-normalization audit
validation/absorbed_scalar_audit.py Literal A-definition numerical evaluation
validation/formal_review.txt        Independent mathematical review notes
results/                            Recorded metrics and finite-check results
ATTRIBUTION.txt                      Inherited and new contributions
LICENSE_SOURCE.txt                   License notice for inherited source
SHA256SUMS                          Integrity hashes of the delivered files

Neither checker imports the oracle, a compiler, a fixture, the numerical
audit, or the measurement code. Audit-directory checker copies are included
for reproducibility and are required to match the top-level deliverables.
Audit helpers, source comparisons, and proof-generation examples are outside
the acceptance boundary; they cannot add an accepted theorem.

The direct audit records 47 native packets (28 positive, 19 negative), four
counter-free source imports, 767 packet/oracle/normalization comparisons,
1,320 independent scoped openings, 114 real CLI runs, and seven mutation
controls. Fifty-two accepted source packets outside the explicit restricted
translation are identified as excluded; no universal proof transport is
claimed for that finite fixture converter.

The arithmetic audit checks 914 equations by evaluating the literal
successor-initialized definitions. It executes 14,405,000 scalar updates in
15,407 iterator calls. It does not substitute the claimed closed forms for
the terms under test.

SHA256SUMS describes the files as delivered, excluding itself and temporary
TeX/cache files. Reproduction intentionally refreshes result files and may
change timing fields; a PDF rebuild also changes PDF metadata. Thus verify
integrity before regeneration if checking the original package bytes.
