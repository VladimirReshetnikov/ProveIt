"""Reproduce every finite check; mathematical proof remains in report.pdf."""
from pathlib import Path
import json
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(relative):
    completed = subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT,
                               text=True, capture_output=True)
    if completed.returncode:
        print(completed.stdout)
        print(completed.stderr, file=sys.stderr)
        raise SystemExit(completed.returncode)
    print('PASS:', relative, flush=True)


def main():
    print('Python', platform.python_version(), flush=True)
    for delivered, audited in (
        ('checker.py', 'kernel_audit/checker.py'),
        ('checker_derived.py', 'companion_audit/checker.py'),
    ):
        if (ROOT / delivered).read_bytes() != (ROOT / audited).read_bytes():
            raise ValueError('Audited copy differs from delivered program: ' + delivered)
    print('PASS: delivered programs match audited copies', flush=True)
    run('measure.py')
    run('kernel_audit/validate.py')
    run('companion_audit/validate.py')
    run('validation/absorbed_scalar_audit.py')
    shutil.copy2(ROOT / 'kernel_audit/validation_results.json',
                 ROOT / 'results/kernel_validation.json')
    shutil.copy2(ROOT / 'companion_audit/boolean_validation.json',
                 ROOT / 'results/companion_validation.json')
    metrics = json.loads((ROOT / 'results/metrics.json').read_text())
    print('Current coordinate minima:', metrics['current_minimum'], flush=True)
    for candidate in metrics['candidates']:
        values = [candidate[k] for k in ('normalized_tokens', 'ast_nodes', 'normalized_bytes')]
        print(candidate['file'] + ':', '/'.join(map(str, values)), flush=True)
    print('All finite checks passed. See report.pdf for the mathematical proofs.', flush=True)


if __name__ == '__main__':
    main()
