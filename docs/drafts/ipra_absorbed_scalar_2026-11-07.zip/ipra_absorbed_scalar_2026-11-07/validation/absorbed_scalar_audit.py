"""Finite audit of literal successor-initialized scalar-iterator definitions.

All named functions below are built from A and composition.  Memoization
only reuses identical evaluations; it does not replace a definition by its
claimed closed form.  This is evidence about small standard inputs, not a
formal verification of the internal proofs or arbitrary-counter identities.
"""
from functools import cache
import json
from pathlib import Path
import time

COUNTS = {"iterator_calls": 0, "iterator_steps": 0}


def A(n, a, h):
    assert type(n) is int and type(a) is int and n >= 0 and a >= 0
    COUNTS["iterator_calls"] += 1
    COUNTS["iterator_steps"] += n
    value = a + 1
    for _ in range(n):
        value = h(value)
    return value


@cache
def S(n):
    return A(0, n, lambda _: 0)


@cache
def Z(n):
    return A(n, 0, lambda _: 0)


@cache
def P(b, a):
    return A(b, 0, lambda _: a)


@cache
def V(u, b):
    return A(Z(b), u, lambda _: u)


@cache
def B(b, c):
    return Z(A(b, 0, lambda _: Z(c)))


@cache
def N(n):
    return Z(A(n, 0, Z))


@cache
def j(u):
    return A(Z(N(u)), 1, lambda _: Z(u))


@cache
def M(n):
    return j(j(A(n, 0, j)))


@cache
def q2(u):
    return A(N(u), S(u), lambda _: 0)


@cache
def D(n):
    return A(S(n), 0, q2)


@cache
def q3(u):
    return A(Z(Z(M(u))), S(S(u)), lambda _: 0)


@cache
def T(n):
    return A(S(n), 0, q3)


@cache
def qG(u):
    return A(N(M(u)), V(u, Z(M(u))), lambda _: 0)


@cache
def G(n):
    return A(S(n), 0, qG)


@cache
def E(u):
    return Z(N(u))


@cache
def L(u):
    return P(E(u), u)


@cache
def H(u):
    return P(E(u), L(G(u)))


@cache
def K(u):
    return P(E(u), T(u))


@cache
def plus(a, b):
    return A(b, a, S)


@cache
def power_initializer(x):
    return A(x, 0, lambda u: plus(u, u))


@cache
def e(x):
    return S(power_initializer(x))


@cache
def F(x, y):
    return A(y, power_initializer(x), H)


@cache
def w(x, y):
    return Z(N(F(x, y)))


@cache
def c(x, y):
    return w(x, S(y))


@cache
def q(y, u):
    return A(Z(c(y, u)), u, lambda _: 0)


@cache
def g(n, y):
    return A(S(n), y, lambda u: q(y, u))


@cache
def delta(x):
    return A(x, x, lambda u: q(x, u))


def derived_iterator(n, a, h):
    return delta(A(n, a, lambda u: S(h(delta(u)))))


def main():
    started = time.monotonic()
    checks = {}

    def eq(label, left, right, args):
        if left != right:
            raise AssertionError((label, args, left, right))
        checks[label] = checks.get(label, 0) + 1

    for n in range(31):
        eq("Z", Z(n), int(n == 0), n)
        eq("parity", N(n), n % 2, n)
        eq("three_cycle", M(n), n % 3, n)
        eq("double", D(n), 2 * n, n)
        eq("triple", T(n), 3 * n, n)
        eq("ramp", G(n), (3 * n + 1) // 2, n)
        eq("ramp_invariant", M(G(n)), D(N(n)), n)
        eq("ramp_recurrence", G(S(n)), S(V(G(n), Z(N(n)))), n)
        eq("ramp_double", G(D(n)), T(n), n)
        eq("ramp_triple", V(G(T(n)), N(n)), T(G(n)), n)
        eq("factor_trade", H(D(n)), K(n), n)
        eq("commuting_updates", H(K(n)), K(H(n)), n)
        eq("parity_K", N(K(n)), N(n), n)
        eq("H_evenness", E(H(n)), B(E(n), E(G(n))), n)
        for b in range(2):
            eq("residue_increment", M(V(n, b)), M(V(M(n), b)), (n, b))
            eq("mask_increment", P(Z(b), V(n, b)), P(Z(b), n), (n, b))
            for d in range(2):
                eq("nested_gate", P(b, P(d, n)), P(B(b, d), n), (n, b, d))

    for x in range(6):
        eq("exponential_initializer", e(x), 2 ** (x + 1), x)
        for y in range(8):
            eq("diagonal_state", F(S(x), S(y)), K(F(x, y)), (x, y))
            eq("strict_control", c(x, y), int(y < x), (x, y))
            eq("control_persistence", B(c(x, y), c(x, S(y))), c(x, S(y)), (x, y))
            eq("guarded_prefix", P(c(y, x), g(x, y)), P(c(y, x), x), (x, y))

    for n in range(7):
        eq("decoder", delta(n), max(0, n - 1) if n else 1, n)

    # Keep decoded intermediate values small: delta is intentionally expensive.
    updates = [("constant_zero", lambda u: 0), ("identity", lambda u: u),
               ("successor", lambda u: S(u))]
    for name, update in updates:
        for a in range(3):
            for n in range(3):
                expected = a
                for _ in range(n):
                    expected = update(expected)
                eq("derived_iterator_" + name, derived_iterator(n, a, update), expected, (n, a))

    result = {
        "status": "PASS",
        "scope": "Finite standard-model evaluation of literal A definitions; not formal proof",
        "checks": checks,
        "total_checks": sum(checks.values()),
        "cost": COUNTS,
        "elapsed_seconds": round(time.monotonic() - started, 3),
    }
    path = Path(__file__).resolve().parents[1] / "results/absorbed_scalar_audit_results.json"
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
