"""Reproduce the pinned full-program comparison with the unchanged source metric."""
from pathlib import Path
import hashlib
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('source_measure', ROOT / 'comparison/source_measure.py')
metric = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metric)
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def measure():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    groups = {}
    for group in ('programs', 'expanded'):
        rows = []
        for source in manifest[group]:
            path = ROOT / source['local_file']
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            if actual != source['sha256']:
                raise ValueError('Changed comparator: ' + source['local_file'])
            rows.append({**source, 'metrics': metric.metrics(path)})
        groups[group] = rows
    current_minimum = {k: min(row['metrics'][k] for row in groups['programs']) for k in KEYS}
    expanded_minimum = {k: min(row['metrics'][k] for row in groups['expanded']) for k in KEYS}
    candidates = []
    for name in ('checker.py', 'checker_derived.py'):
        path = ROOT / name
        if path.exists():
            data = metric.metrics(path)
            candidates.append({'file': name, **data,
                               'strict_improvement': {k: data[k] < current_minimum[k] for k in KEYS}})
    result = {'python': platform.python_version(), 'commit': manifest['commit'],
              'archive_count': len(manifest['archives']), 'current_programs': len(groups['programs']),
              'expanded_distinct_sources': len(groups['expanded']),
              'expanded_source_paths': sum(len(row['source_paths']) for row in groups['expanded']),
              'current_minimum': current_minimum, 'expanded_minimum': expanded_minimum,
              'candidates': candidates, 'programs': groups['programs']}
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    if current_minimum != expanded_minimum:
        raise ValueError('Expanded inventory changed the frontier')
    for candidate in candidates:
        if not all(candidate['strict_improvement'].values()):
            raise ValueError('Candidate does not beat every current coordinate')
    print(json.dumps({k: v for k, v in result.items() if k != 'programs'}, indent=2))
    return result


if __name__ == '__main__':
    measure()
