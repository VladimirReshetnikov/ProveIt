"""Compile the complete article with three pdfLaTeX passes, offline."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    executable = shutil.which('pdflatex')
    if executable is None:
        raise SystemExit('pdfLaTeX is required to rebuild the PDF; the compiled PDF is included.')
    for _ in range(3):
        result = subprocess.run([executable, '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
                                cwd=ROOT, text=True, capture_output=True)
        if result.returncode:
            print(result.stdout[-12000:])
            print(result.stderr)
            raise SystemExit(result.returncode)
    print('Compiled report.pdf')


if __name__ == '__main__':
    main()
