"""Reproduce finite direct-A implementation evidence with standard Python.

The acceptance program is checker.py alone. Every helper used here is outside
that boundary. Tests do not constitute a formal verification of the metatheory.
"""

import ast
from collections import Counter
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import types

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'validation'))
from named_oracle import Oracle, opening, erase_booleans
import counter_free


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def load_library(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_prefix(source, name):
    """Load the exact global/function prefix for in-process testing only.

    The complete file is independently exercised as a real CLI below. No
    imported helper or altered function is substituted for production code.
    """
    parsed = ast.parse(source)
    prefix = []
    for node in parsed.body:
        if isinstance(node, ast.Try):
            break
        prefix.append(node)
    require(len(prefix) < len(parsed.body), 'standalone driver was not found')
    module = types.ModuleType(name)
    exec(compile(ast.Module(body=prefix, type_ignores=[]), name, 'exec'), module.__dict__)
    return module


def run(module, packet):
    module.k = 0
    stream = deepcopy(packet)
    try:
        module.take = stream.pop
        accepted = bool(module.check(stream.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {'accepted': accepted, 'error': error, 'final_k': module.k,
            'remaining': len(stream) if type(stream) is list else None}


def booleanize(value, selector):
    if type(value) is int and value in (0, 1) and selector(value):
        return bool(value)
    if type(value) is list:
        return [booleanize(v, selector) for v in value]
    if type(value) is dict:
        return {k: booleanize(v, selector) for k, v in value.items()}
    return value


def main():
    source = (ROOT / 'checker.py').read_text()
    kernel = load_prefix(source, 'direct_A_kernel')
    normalized_kernel = load_prefix(source.replace('isinstance(a, int)', 'type(a) is int'),
                                    'integer_only_direct_A')
    strict = load_library(ROOT / 'frozen/strict_wrapped_A.py', 'strict_wrapped_A')
    binary = load_library(ROOT / 'frozen/binary_absorbed.py', 'binary_absorbed')
    metric = load_library(ROOT / 'frozen/source_measure.py', 'frozen_metric')
    actual_metric = metric.metrics(ROOT / 'checker.py')
    require(tuple(actual_metric[k] for k in ('normalized_tokens', 'ast_nodes', 'normalized_bytes'))
            == (406, 423, 1159), actual_metric)
    cases = json.loads((ROOT / 'fixtures/native_A_cases.json').read_text())
    imports = json.loads((ROOT / 'fixtures/counter_free_imports.json').read_text())
    imported = imports['translated']
    for item in imported:
        require(run(binary, item['source_packet'])['accepted'], ('source', item['name']))
        require(counter_free.packet(item['source_packet']) == item['strict_packet'],
                ('transport reproducibility', item['name']))
    all_cases = cases + imported
    rows = []
    rules = Counter()
    allocations = 0
    comparisons = 0

    def compare(packet, name, expected=None):
        nonlocal comparisons, allocations
        actual = run(kernel, packet)
        independent = Oracle().run(packet)
        normalized = run(normalized_kernel, erase_booleans(packet))
        require(actual == normalized, ('Boolean erasure', name, actual, normalized))
        require(actual['accepted'] == independent['accepted'],
                ('named oracle', name, actual, independent))
        if expected is not None:
            require(actual['accepted'] == expected, ('expected verdict', name, actual))
        if actual['accepted']:
            require(actual['final_k'] == independent['final_k'] and
                    actual['remaining'] == independent['remaining'],
                    ('scope/consumption history', name, actual, independent))
        comparisons += 1
        return actual, independent

    for case in all_cases:
        actual, independent = compare(case['packet'], case['name'], case['expected'])
        if 'strict_packet' in case:
            require(run(strict, erase_booleans(case['strict_packet']))['accepted']
                    == case['expected'], ('strict reference', case['name']))
        rules.update(independent['rules'])
        allocations += len(independent['allocations'])
        rows.append({'name': case['name'], 'expected': case['expected'],
                     'result': actual, 'oracle_rules': independent['rules']})

    # Deliberate numerical aliases exercise both constant zero and bound code 1.
    rng = random.Random(20261107)
    for case in all_cases:
        selectors = [lambda n: n == 0, lambda n: n == 1, lambda n: True,
                     lambda n: rng.randrange(2) == 0]
        for index, selector in enumerate(selectors):
            packet = booleanize(case['packet'], selector)
            compare(packet, (case['name'], 'Boolean variant', index), case['expected'])

    # Small hostile packets focus on malformed JSON and exception/fallback behavior.
    leaves = [None, False, True, 0, 1, -1, 2, -2, 0.0, 0.5,
              float('nan'), float('inf'), '', 'x', {}]

    def arbitrary(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return deepcopy(rng.choice(leaves))
        if rng.randrange(8) == 0:
            return {'ignored': arbitrary(depth - 1)}
        return [arbitrary(depth - 1) for _ in range(rng.randrange(5))]

    malformed_count = 512
    for index in range(malformed_count):
        compare(arbitrary(4), ('malformed', index))

    # Independent named-binder openings cover the only new arithmetic scope:
    # one previous-value slot, with no available previous-counter slot.
    values = [False, True, 0, 1, 2, 3, 4, -1, -2, None, 0.0, [True],
              [0, 0], [[1, 1]], [[3, 1], [0, 0], [0, 0]],
              [0, 0, 1], [0, 0, 2], [0, 0, 3], [0, 0, 4],
              [0, 0, [0, 0, 3]], [0, 0, [0, 0, 5]],
              [[0, 0, True], False]]
    environments = [(), (0,), (True,), ([False],), (-1,), (3,)]
    opening_count = 0
    for value in values:
        for env in environments:
            for depth in range(5):
                for lower in (0, -1):
                    kernel.k = lower
                    try:
                        actual = kernel.inst(deepcopy(value), *deepcopy(env), d=depth)
                        failed = False
                    except Exception:
                        actual, failed = None, True
                    try:
                        expected = opening(erase_booleans(value), erase_booleans(list(env)),
                            formula=depth % 2 == 0, depth=depth // 2, lower=lower)
                        reference_failed = False
                    except Exception:
                        expected, reference_failed = None, True
                    require(failed == reference_failed and
                            (failed or erase_booleans(actual) == expected),
                            ('opening', value, env, depth, lower, actual, expected))
                    opening_count += 1

    mutation_specs = [
        ('omit_successor_at_zero', 'return b == [t]', 'return b == t',
         'old_I_zero_axiom', True),
        ('double_wrap_initializer', 'inst(r, [n, t, r], d=1)',
         'inst(r, [n, [t], r], d=1)', 'wrong_A_successor_initializer', True),
        ('lose_protected_logical_binder', 'b, = inst(b[:1], t)',
         'b = inst(b[0], t)', 'false_Q_coverage', True),
        ('permit_contextual_capture', 'inst(env[a - d >> 1], d=1)',
         'env[a - d >> 1]', 'contextual_capture_attack', True),
        ('allow_compound_induction', 'h = [b, inst(b, 0)][len(b) % 2:]',
         'h = [b, inst(b, 0)]', 'compound_induction_hypothesis_attack', True),
        ('remove_retained_base', 'h = [b, inst(b, 0)][len(b) % 2:]',
         'h = [b][:1 - len(b) % 2]', 'retained_false_base_is_used', False),
        ('remove_equation_induction', 'h = [b, inst(b, 0)][len(b) % 2:]',
         'h = [inst(b, 0)]', 'atomic_induction_A_successor', False),
    ]
    lookup = {c['name']: c for c in cases}
    mutations = []
    for name, before, after, case_name, expected in mutation_specs:
        require(source.count(before) == 1, ('mutation anchor', name))
        mutant = load_prefix(source.replace(before, after), name)
        result = run(mutant, lookup[case_name]['packet'])['accepted']
        require(result == expected, ('mutation detection', name, result))
        mutations.append({'defect': name, 'certificate': case_name,
                          'mutant_accepts': result,
                          'delivered_accepts': lookup[case_name]['expected']})

    cli_count = 0
    with tempfile.TemporaryDirectory() as temporary:
        cli_cases = all_cases + [
            {'name': 'Boolean ' + c['name'], 'packet': booleanize(c['packet'], lambda n: True),
             'expected': c['expected']} for c in cases[:6]]
        for index, case in enumerate(cli_cases):
            packet_path = Path(temporary) / (str(index) + '.json')
            packet_path.write_text(json.dumps(case['packet']))
            for optimized in (False, True):
                result = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                    str(ROOT / 'checker.py'), str(packet_path)],
                    capture_output=True, text=True, timeout=10)
                actual = result.returncode, result.stdout, result.stderr
                expected = (0, 'ACCEPT\n', '') if case['expected'] else (1, 'REJECT\n', '')
                require(actual == expected, ('CLI', case['name'], optimized, actual))
                cli_count += 1

    result = {'status': 'PASS', 'python': platform.python_version(),
              'complete_program': actual_metric,
              'metric_note': 'The complete-program fields count every executable line. The inherited core heuristic does not remove a standalone unguarded driver and is not used for core comparisons.',
              'native_packets': len(cases), 'native_positive': sum(c['expected'] for c in cases),
              'native_negative': sum(not c['expected'] for c in cases),
              'counter_free_imported': len(imported),
              'accepted_source_packets_not_transported': len(imports['excluded_accepted_sources']),
              'packet_oracle_and_normalization_comparisons': comparisons,
              'malformed_packets_included': malformed_count,
              'independent_scoped_openings': opening_count,
              'native_and_imported_rule_counts': dict(rules),
              'native_and_imported_eigenallocations': allocations,
              'actual_cli_runs': cli_count, 'mutation_controls': mutations,
              'cases': rows,
              'limitations': ['Finite executable checks do not prove the mathematical metatheory.',
                  'The syntactically counter-free source transporter is deliberately partial.',
                  'All proof producers, oracles, source normalizers, and test code are outside checker.py.']}
    (ROOT / 'validation_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('cases', 'mutation_controls')}, indent=2))


if __name__ == '__main__':
    main()
