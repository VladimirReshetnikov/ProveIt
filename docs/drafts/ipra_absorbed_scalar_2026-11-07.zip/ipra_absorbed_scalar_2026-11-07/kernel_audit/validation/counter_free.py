"""Translate the counter-free fragment of R2 certificates into scalar iteration.

This untrusted partial translator never pretends to implement general primitive
recursion. A source recursion update with an occurrence of its counter binder
is rejected. Other positive coordinates are adjusted when that unused binder
is removed. Certificates whose translation succeeds must still be checked by
the target kernel and the independent named oracle.
"""
from copy import deepcopy
from pathlib import Path
import json


class CounterUsed(ValueError):
    pass


def term(value, old=(), new=()):
    if type(value) is int:
        if value <= 0:
            return value
        slot = (value - 1) // 2
        if slot >= len(old):
            raise ValueError('unbound source coordinate')
        name = old[slot]
        if name not in new:
            raise CounterUsed('the source recursion counter is used')
        return 2 * new.index(name) + 1 + (1 - value % 2)
    if type(value) is not list:
        raise ValueError('invalid source numerical term')
    if len(value) == 1:
        return [term(value[0], old, new)]
    if len(value) == 3:
        previous, counter = object(), object()
        return [term(value[0], old, new), term(value[1], old, new),
                term(value[2], (previous, counter) + old, (previous,) + new)]
    raise ValueError('invalid source term arity')


def formula(value, old=(), new=()):
    if type(value) is not list:
        raise ValueError('invalid source formula')
    if len(value) == 2:
        return [term(x, old, new) for x in value]
    if len(value) in (1, 3):
        count = 1 if len(value) == 1 else 2
        bound = tuple(object() for _ in range(count))
        return [formula(x, bound + old, bound + new) for x in value]
    raise ValueError('invalid source formula arity')


def packet(source):
    if type(source) is not list or not source:
        raise ValueError('invalid source packet')
    converted = []
    for cell in source[:-1]:
        if type(cell) is not list:
            raise ValueError('noncanonical source instruction')
        if len(cell) == 0:
            converted.append([])
        elif len(cell) == 1:
            converted.append([term(cell[0])])
        elif len(cell) == 2:
            major, annotation = cell
            translated_major = formula(major)
            if len(major) == 2:
                hole = object()
                translated_annotation = formula(annotation, (hole,), (hole,))
            elif len(major) == 1:
                translated_annotation = term(annotation)
            else:
                translated_annotation = deepcopy(annotation)
            converted.append([translated_major, translated_annotation])
        else:
            raise ValueError('invalid source instruction arity')
    return converted + [formula(source[-1])]


def transport_all(source_rows):
    translated, excluded = [], []
    for row in source_rows:
        if not row['name'].startswith(('declared/', 'declared_aliases/')):
            continue
        try:
            target = packet(row['packet'])
        except CounterUsed as exception:
            excluded.append({'name': row['name'], 'reason': str(exception)})
        else:
            translated.append({'name': row['name'], 'packet': target,
                               'expected': True,
                               'source_packet_sha256': row['packet_sha256'],
                               'source_path': row['source_path']})
    return translated, excluded


if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    source = json.loads((root/'source_fixtures.json').read_text())['cases']
    translated, excluded = transport_all(source)
    result = {'source_positive_packets': 45, 'translated': translated,
              'excluded_counter_using_packets': excluded,
              'scope': 'Only the syntactically counter-free fragment is translated.'}
    (root/'new_cases/counter_free_transports.json').write_text(
        json.dumps(result, indent=2) + '\n')
    print('Transported', len(translated), 'of45; excluded', len(excluded), 'counter-using proofs.')
