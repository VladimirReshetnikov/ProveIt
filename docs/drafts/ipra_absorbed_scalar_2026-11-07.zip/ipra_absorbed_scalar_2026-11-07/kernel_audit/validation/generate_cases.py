"""Untrusted native A proof producer and deliberately invalid certificates.

The producer uses the independent named-binder opening operation. The checked
program never imports it, the oracle, this file, or any generated certificate.
"""

from copy import deepcopy
import json
from pathlib import Path

from named_oracle import opening

TRUTH = [0, 0]


class Builder:
    def __init__(self, goal):
        self.goal = goal
        self.lower = 0
        self.context = []
        self.cells = []

    def open(self, value, images=(), formula=True):
        return opening(value, images, formula=formula, lower=self.lower)

    def leaf(self):
        return self.goal in self.context

    def prove(self, goal, action):
        previous = self.goal
        self.goal = goal
        action()
        self.goal = previous

    def hyp(self):
        if not self.leaf():
            raise AssertionError(('missing producer hypothesis', self.goal, self.context))

    def computation(self):
        if self.leaf():
            return
        left, right = self.goal
        n, a, body = left
        expected = [a] if n == 0 else self.open(body, [[n[0], a, body]], False)
        if right != expected:
            raise AssertionError(('incorrect produced computation', self.goal, expected))
        self.cells.append(('computation', []))

    def transport(self, major, motive, major_proof, minor_proof):
        if self.leaf():
            return
        target = self.goal
        self.cells.append(('elimination', [major, motive]))
        self.prove(major, major_proof)
        if self.open(motive, [major[1]]) != target:
            raise AssertionError(('producer transport endpoint', target, major, motive))
        self.prove(self.open(motive, [major[0]]), minor_proof)

    def reflexivity(self):
        if self.leaf():
            return
        t, right = self.goal
        if t != right:
            raise AssertionError(('not reflexivity', self.goal))
        # A(S0,0;u.t)=t supplies reflexivity without a predecessor lemma.
        r = [[0], 0, t]
        self.transport([r, t], [1, t], self.computation, self.computation)

    def intro(self, witness, step):
        if self.leaf():
            return
        goal = self.goal
        if len(goal) not in (1, 3):
            raise AssertionError('intro requires Q or D')
        self.cells.append(('introduction', deepcopy(witness)))
        body, = self.open([goal[0]], [witness])
        base = self.open(body, [0])
        self.lower -= 1
        eigen = self.lower
        hypothesis = self.open(body, [eigen])
        conclusion = self.open(body, [[eigen]])
        old_context = self.context
        self.context = [*old_context, base]
        if len(body) == 2:
            self.context.append(hypothesis)
        self.prove(conclusion, lambda: step(eigen, hypothesis, base))
        self.context = old_context

    def q_elim(self, major, instance, major_proof, base_proof):
        if self.leaf():
            return
        goal = self.goal
        self.cells.append(('elimination', [major, instance]))
        self.prove(major, major_proof)
        if self.open(major[0], [instance]) != goal:
            raise AssertionError('Q endpoint mismatch')
        self.prove(self.open(major[0], [0]), base_proof)

    def d_elim(self, major, major_proof, continuation):
        if self.leaf():
            return
        goal = self.goal
        self.cells.append(('elimination', [major, None]))
        self.prove(major, major_proof)
        self.lower -= 1
        eigen = self.lower
        assumption = self.open([major[0]], [eigen])
        old_context = self.context
        self.context = [*old_context, assumption]
        self.prove(goal, lambda: continuation(eigen, assumption))
        self.context = old_context

    def equals_one_from_false(self):
        """Prove t=1 using a retained 0=1 assumption."""
        t, one = self.goal
        if one != [0]:
            raise AssertionError('expected target t=1')
        r = [[0], 0, t]

        def inner():
            self.transport([0, [0]], [[1, 0, t], [0]],
                           self.hyp, self.computation)

        self.transport([r, t], [1, [0]], self.computation, inner)

    def packets(self):
        bare, wrapped = [], []
        for kind, cell in reversed(self.cells):
            bare.append(deepcopy(cell))
            wrapped.append([deepcopy(cell)] if kind == 'introduction' else deepcopy(cell))
        return bare + [deepcopy(self.goal)], wrapped + [deepcopy(self.goal)]


def generated():
    result = []

    def make(name, goal, action):
        builder = Builder(goal)
        action(builder)
        packet, reference = builder.packets()
        result.append({'name': name, 'packet': packet, 'strict_packet': reference,
                       'expected': True, 'producer_allocations': -builder.lower})

    for index, (n, a, update) in enumerate([
            (0, 0, 0), (0, [0], 1), (0, [0, 0, [1]], [1]),
            ([0], 0, 0), ([0], 0, 1), ([0], [0], 2),
            ([[0]], 0, [1]), ([0], 0, [1, 0, [3]]),
            ([0], 0, [1, 0, [1]]), ([[0]], [0], [0, 1, [3]])]):
        lhs = [n, a, update]
        rhs = [a] if n == 0 else opening(update, [[n[0], a, update]], formula=False)
        make('computation_%02d' % index, [lhs, rhs], lambda b: b.computation())

    for index, term in enumerate([0, [0], [[0]], [0, 0, 1], [[0], 0, [1]]]):
        make('reflexivity_%02d' % index, [term, term], lambda b: b.reflexivity())

    q_refl = [[1, 1]]
    make('Q_bound_reflexivity', q_refl,
         lambda b: b.intro(0, lambda *_: b.reflexivity()))
    make('Q_unused_witness_object', [TRUTH],
         lambda b: b.intro({'unused': True}, lambda *_: b.hyp()))
    make('Q_unused_witness_empty_array', [TRUTH],
         lambda b: b.intro([], lambda *_: b.hyp()))
    make('D_used_successor_witness', [[3, 3], TRUTH, TRUTH],
         lambda b: b.intro([0], lambda *_: b.hyp()))
    make('D_unused_malformed_witness', [[1, 1], TRUTH, TRUTH],
         lambda b: b.intro({'unused': None}, lambda *_: b.reflexivity()))
    make('nested_Q_introductions', [[[3, 3]]],
         lambda b: b.intro(0, lambda *_: b.intro(0, lambda *_: b.hyp())))

    term = [[0], [0], [1]]
    make('Q_elimination_at_A_term', [term, term],
         lambda b: b.q_elim(q_refl, term,
             lambda: b.intro(0, lambda *_: b.reflexivity()), b.reflexivity))

    paired = [[1, 1], TRUTH, TRUTH]
    make('D_elimination_then_Q_elimination', [term, term],
         lambda b: b.d_elim(paired,
             lambda: b.intro(0, lambda *_: b.reflexivity()),
             lambda eigen, assumption: b.q_elim(assumption, term, b.hyp, b.reflexivity)))

    p, q = [0, 0, 1], [0]
    make('transport_under_Q', [[q, q]],
         lambda b: b.transport([p, q], [[3, 3]], b.computation,
             lambda: b.intro(0, lambda *_: b.hyp())))
    make('transport_under_D_and_Q', [[[q, q]], TRUTH, TRUTH],
         lambda b: b.transport([p, q], [[[7, 7]], TRUTH, TRUTH], b.computation,
             lambda: b.intro(0, lambda *_: b.hyp())))

    # Literal-equation induction is essential in this certificate.
    induction_matrix = [[1, 0, [1]], [1]]

    def induction_step(b, eigen, hypothesis, base):
        lhs = [[eigen], 0, [1]]
        b.transport(hypothesis, [lhs, [1]], b.hyp, b.computation)

    make('atomic_induction_A_successor', [induction_matrix],
         lambda b: b.intro(0, lambda e, h, z: induction_step(b, e, h, z)))
    make('retained_false_base_is_used', [[1, [0]]],
         lambda b: b.intro(0, lambda *_: b.equals_one_from_false()))

    # The malformed two-entry witness is ignored. Its failed elimination
    # guard consumes a rejected A0 computation, then direct Q introduction
    # proves the constant closure. This is deliberate documented fallback.
    fallback = [[], [[[0, 0, 0], 0], None], [TRUTH]]
    result.append({'name': 'failed_major_falls_back_to_unused_witness',
                   'packet': fallback, 'strict_packet': [[0], [TRUTH]],
                   'expected': True, 'producer_allocations': 1,
                   'note': 'The strict packet gives the extracted proof with discarded failed-major cells.'})

    # A used, locally unbound witness would capture a protected variable if
    # opening images were inserted without checking them at numerical depth 0.
    capture_goal = [[[1, 0, 5], [1, 0, 3]], TRUTH, TRUTH]
    captured_term = [[-1], 0, [-1]]
    capture = Builder([captured_term, captured_term])
    capture.lower = -1
    capture.reflexivity()
    capture_packet, _ = capture.packets()
    result.append({'name': 'contextual_capture_attack',
                   'packet': capture_packet[:-1] + [3, capture_goal],
                   'expected': False,
                   'note': 'An intentionally unbound witness code must not be captured by the inner logical binder.'})

    # This certificate is accepted if compound matrices are incorrectly given
    # an induction hypothesis. It is a control for this exact rule restriction,
    # not a claim that its concluding theorem is underivable by other proofs.
    compound_goal = [[[[3, 0, 1], 0]]]
    previous, current = [-1, 0, 1], [[-1], 0, 1]
    base = [[[0, 0, 1], 0]]
    illegal_hypothesis = [[previous, 0]]
    compound = Builder([[current, 0]])
    compound.lower = -1
    compound.context = [base, illegal_hypothesis]

    def symmetry():
        compound.transport([current, previous], [1, current],
                           compound.computation, compound.reflexivity)

    compound.transport([previous, current], [[3, 0]], symmetry, compound.hyp)
    compound_packet, _ = compound.packets()
    result.append({'name': 'compound_induction_hypothesis_attack',
                   'packet': compound_packet[:-1] + [0, compound_goal],
                   'expected': False})

    bad = [
        ('old_I_zero_axiom', [[], [[0, 0, 0], 0]]),
        ('wrong_A_successor_initializer', [[], [[[0], 0, 1], [0, [0], 1]]]),
        ('nonexistent_counter_slot', [[], [[[0], 0, 3], 0]]),
        ('nonexistent_counter_alias', [[], [[[0], 0, 4], 0]]),
        ('future_parameter_in_update', [[], [[0, 0, -1], [0]]]),
        ('nested_unbound_coordinate', [[], [[0, 0, [0, 0, 5]], [0]]]),
        ('future_witness', [-1, [[3, 3], TRUTH, TRUTH]]),
        ('bound_coordinate_as_witness', [1, [[3, 3], TRUTH, TRUTH]]),
        ('future_parameter_in_padding', [0, [TRUTH, [-1, -1], TRUTH]]),
        ('invalid_padding', [0, [TRUTH, None, TRUTH]]),
        ('formula_sort_not_numerical', [0, [0, [0]]]),
        ('iterator_cannot_be_formula_matrix', [0, [[0, 0, 0], [0]]]),
        ('false_equality', [[], [0, [0]]]),
        ('false_Q_coverage', [0, [[1, 0]]]),
        ('empty_packet', []),
        ('object_packet', {}),
        ('float_zero_is_not_numerical', [[], [[0.0, 0, 0], [0]]]),
    ]
    result.extend({'name': name, 'packet': packet, 'expected': False} for name, packet in bad)
    return result


def main():
    root = Path(__file__).resolve().parents[1]
    cases = generated()
    (root / 'fixtures/native_A_cases.json').write_text(json.dumps(cases, indent=2) + '\n')
    for case in cases:
        (root / 'examples' / (case['name'] + '.json')).write_text(json.dumps(case['packet']) + '\n')
    print('Generated', len(cases), 'native A cases.')


if __name__ == '__main__':
    main()
