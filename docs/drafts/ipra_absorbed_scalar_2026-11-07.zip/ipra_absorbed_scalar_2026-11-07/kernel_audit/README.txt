DIRECT SUCCESSOR-INITIALIZED SCALAR A KERNEL
==========================================

This is the self-contained implementation audit package for the new direct
A presentation. The complete trusted program is checker.py alone.

Quick checks:

  python3 checker.py examples/atomic_induction_A_successor.json
  python3 checker.py examples/retained_false_base_is_used.json

Both print ACCEPT. An intentional negative control:

  python3 checker.py examples/contextual_capture_attack.json

This prints REJECT and exits with status 1.

Reproduce the finite audit from any working directory:

  python3 validate.py

The exact source counts were obtained with CPython 3.12.14 using the
unchanged upstream normalization routine frozen/source_measure.py:

  406 normalized significant tokens
  423 AST nodes
  1159 normalized UTF-8 bytes

Every executable line is counted, including imports, JSON input, validation,
logical and arithmetic checks, verdict output, and exit status. The primary
is a standalone CLI, so it has no importability guard. The old metric's
diagnostic core heuristic strips __name__ guards; it does not strip this
standalone driver and is not used for a core-size comparison.

Validation includes 47 native certificates (28 positive, 19 negative), four
explicitly counter-free certificates transported from a current absorbed
two-variable recursor draft, a separate strict-integer/wrapped-instruction
reference, an explicit named-binder oracle, scoped substitution checks,
Boolean-normalization checks, actual normal/-O CLI runs, and seven targeted
mutations. validation_results.json gives exact counts and per-case records.

The deliberately partial transporter excludes 52 accepted source packets;
it does not implement the general arithmetic bi-interpretation. The full
metatheory is proved in the accompanying paper, not established by finite
tests or by this partial source transport.

FORMAT.txt is the complete packet and dispatch contract.
ATTRIBUTION.txt and manifest.json record source provenance.
validation/ contains untrusted proof producers and an independent oracle.
frozen/ contains the unchanged source metric and reference programs.
fixtures/ preserves inputs; examples/ contains the native positive/negative
packets. No helper is imported by checker.py.

The validation runner loads the exact production function/global prefix
for in-process comparisons and tests the entire CLI file separately. It
does not substitute a test implementation for the acceptance program.
