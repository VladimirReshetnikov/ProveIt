"""Complete scalar-iterator iPRA checker with Boolean numerical aliases.

JSON false aliases code 0; JSON true aliases bound-variable code 1.
The numerical update binds only the previous value. Closure introduction
is an admissible extra branch justified by separation of the two sorts.
"""
import json, sys
k = 0


def inst(a, *env, d=0):
    if isinstance(a, int) and d % 2 and a >= k:
        return a if a < d else inst(env[a - d >> 1], d=1)
    return [inst(b, *env, d=d + w) for b, w in zip(a + [], (0, 0, b'\2', b'\0', b'\1\1', 0, b'\4\4\4', b'\0\0\2')[len(a) * 2 + d % 2])]


def check(a, g):
    global k
    if inst(a) in g:
        return True
    match (a, take()):
        case [b, [m, t]] if check(m, g):
            if m[2:]:
                h = [m[:1]]
            else:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
        case [[[n, t, r], b], []]:
            if n:
                n, = n
                return b == inst(r, [n, t, r], d=1)
            return b == [t]
        case [b, t]:
            b, = inst(b[:1], t)
            h = [b, inst(b, 0)][len(b) % 2:]
    k -= 1
    return check(inst(b, [k]), g + [inst(c, k) for c in h])


try:
    take = json.load(open(sys.argv[1])).pop
    accepted = check(take(), [])
except:
    accepted = False
print('ACCEPT' if accepted else 'REJECT')
sys.exit(not accepted)
