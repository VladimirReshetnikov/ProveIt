#!/usr/bin/env python3
"""Rebuild diagnostics, the optional Lean certificate, and the report."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys


def run(command: list[str], root: Path, logfile: Path) -> str:
    result = subprocess.run(command, cwd=root, capture_output=True, text=True)
    output = result.stdout + result.stderr
    logfile.write_text(output, encoding="utf-8")
    if result.returncode:
        print("\n".join(output.splitlines()[-30:]), file=sys.stderr)
        raise SystemExit(result.returncode)
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--lean", help="Path to a Lean 4.19.0 executable")
    group.add_argument("--skip-lean", action="store_true",
                       help="Do not rerun the certificate")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    audit = root / "audit"
    audit.mkdir(exist_ok=True)
    summary: dict[str, object] = {}

    run([sys.executable, "checks/check_uniform_delay.py"], root,
        audit / "diagnostics_console.txt")
    checks = json.loads((audit / "checks.json").read_text(encoding="utf-8"))
    summary["diagnostics"] = {"status": checks["status"],
                              "count": checks["total_checks"]}
    print(f"Diagnostics: {checks['total_checks']} checks passed.")

    lean = None if args.skip_lean else (args.lean or shutil.which("lean"))
    if lean:
        version = run([lean, "--version"], root, audit / "lean_version.txt").strip()
        run([lean, "formal/UniformDelay.lean"], root, audit / "lean_check.txt")
        summary["lean"] = {"status": "checked", "version": version}
        print("Lean certificate: checked.")
    else:
        summary["lean"] = {"status": "not_rerun",
                           "reason": "Explicit skip or lean not on PATH"}
        print("Lean certificate: not rerun; included original output is preserved.")

    pdflatex = shutil.which("pdflatex")
    if pdflatex is None:
        raise SystemExit("pdflatex is required to build the PDF.")
    for pass_number in range(1, 4):
        run([pdflatex, "-interaction=nonstopmode", "-halt-on-error",
             "-jobname=pra_uniform_delay", "report.tex"], root,
            audit / f"latex_pass_{pass_number}.txt")
    log = (root / "pra_uniform_delay.log").read_text(errors="replace")
    problems = [line for line in log.splitlines()
                if "Overfull" in line or "undefined" in line.lower()]
    summary["pdf"] = {"status": "built", "path": "pra_uniform_delay.pdf",
                      "layout_or_reference_warnings": problems}
    (audit / "rebuild_status.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    if problems:
        raise SystemExit("PDF built with warnings; inspect audit/rebuild_status.json.")
    print("PDF: built in three passes; no overfull boxes or undefined references.")


if __name__ == "__main__":
    main()
