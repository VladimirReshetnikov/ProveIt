UNIFORM DELAYED ITERATION FOR PRIMITIVE RECURSIVE ARITHMETIC
Research prepared for Vladimir Reshetnikov
1 November 2026

START HERE
  pra_uniform_delay.pdf     Complete 18-page research report.
  report.tex               Main LaTeX source; includes sections/*.tex.

RESULT
  For every earlier unary term h(v), introduce a binary D_h with:

    D_h(0,a)   = a
    D_h(S0,a)  = a
    D_h(SSn,a) = h(D_h(Sn,a)).

  Add 0 != S0 and quantifier-free induction with at most one frozen
  numerical parameter. This theory has a common conservative definitional
  extension with first-order PRA in each matching logic (classical or
  intuitionistic). Both interpretation domains are the whole carrier;
  both round trips are internally the identity.

  The report also specifies an equivalent sole-schema presentation with
  three literal matrix constructors and the inherited 15-node outer
  propagation template. The same nonlogical specification works in the
  two logics.

  The key terms are I_h(n,a)=D_h(Sn,a) and p(n)=D_S(n,0).
  Parameter-free equation induction proves p(Sn)=n.

COMPARISON AND LIMITS
  Compared all five ZIP archives in ProveIt/docs/drafts at:
    9e793b1080d95e3fdd1537ba475e67e639d84f20

  The reduction removes the distinguished counter-reading K operation,
  retaining one scalar sort and binary function symbols. The computation
  templates decrease from 31 to 26 nodes when each generic closed schema
  is counted once. This is a partial template measure.

  For m concrete update slots, the same placeholder ledger is
    old: 14+17m; new: 26m.
  Thus a finite expanded delayed library can cost more. Stored bodies,
  induction matrices, and generator code have additional costs.
  No global minimality or new outer-node record is claimed.

  This changes ordinary iteration into delayed iteration. It does NOT
  resolve the unchanged pure-scalar ordinary-iteration predecessor problem.

VERIFICATION
  formal/UniformDelay.lean: 15 constructive kernel lemmas, checked with
  Lean 4.19.0. All report no axiom dependencies. The arithmetic induction
  hypotheses are explicit, individual equation-induction instances.
  The certificate is not a formalization of the entire description
  syntax, pairing construction, or first-order bi-interpretation.

  checks/check_uniform_delay.py: 2,977 finite syntax and arithmetic
  diagnostics, including 1,400 translation/round-trip value comparisons.
  Uses Python's standard library only. This is testing, not an all-model
  proof. See the written report for the full proof.

REBUILD
  Requirements: Python 3.10+, pdflatex with the standard AMS, Latin Modern,
  microtype, geometry, booktabs, tabularx, enumitem, xcolor, fancyhdr, xurl,
  needspace, and hyperref packages. Lean 4.19.0 is needed only to recheck
  the proof certificate; Mathlib is not needed.

  All diagnostics and the PDF:
    python3 build.py --skip-lean

  Also recheck the Lean kernel:
    python3 build.py --lean /absolute/path/to/lean

  With lean already on PATH:
    python3 build.py

  Diagnostics alone:
    python3 checks/check_uniform_delay.py

  Lean alone:
    lean formal/UniformDelay.lean

  The build script runs diagnostics, optionally Lean, and three pdflatex
  passes, then writes its exact output and status under audit/.
  If Lean is unavailable, it explicitly reports that it was not rerun.

FILES
  report.tex
  sections/comparison.tex
  sections/calibration.tex
  sections/interpretations.tex
  sections/audit.tex
  sections/references.tex
  pra_uniform_delay.pdf
  formal/UniformDelay.lean
  checks/check_uniform_delay.py
  audit/lean_check.txt
  audit/checks.json
  audit/source_manifest.json
  audit/pdf_validation.json
  build.py
  README.txt
  Additional build output may be included under audit/.

SOURCES
  The source manifest records immutable GitHub URLs, checked Git blob
  SHA-1 identities, SHA-256 hashes, sizes, and LaTeX member hashes for all
  five inspected archives. The report gives citations and a comparison
  table. No source archives are duplicated in this deliverable.

  The arithmetic parameter-coding construction is adapted with attribution
  from the current scalar drafts. The new uniform delayed constructor is
  not claimed as a literature-wide priority result.
