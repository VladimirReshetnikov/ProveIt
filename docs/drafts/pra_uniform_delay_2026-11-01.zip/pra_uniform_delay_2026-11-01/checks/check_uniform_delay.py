#!/usr/bin/env python3
"""Executable syntax and bounded diagnostics for uniform delayed iteration.

This is not a proof assistant and does not prove the arbitrary-model theorem.
It implements the actual staged languages, literal matrix constructors,
capture-avoiding substitution, term translations, and independent old/new
evaluators. All finite evaluations below are explicitly diagnostic.

Run from any directory with Python 3.10 or later. The only output file is
the adjacent package's audit/checks.json. No third-party packages are used.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
from typing import Callable
import json
import platform


class CheckFailure(Exception):
    pass


class SyntaxFailure(ValueError):
    pass


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple[Term, ...] = ()
    name: str = ""


def V(name: str) -> Term:
    return Term("var", name=name)


Z = Term("zero")


def S(t: Term) -> Term:
    return Term("S", (t,))


def D(name: str, n: Term, a: Term) -> Term:
    return Term("D", (n, a), name)


def I(name: str, n: Term, a: Term) -> Term:
    return Term("I", (n, a), name)


def K(n: Term, a: Term) -> Term:
    return Term("K", (n, a))


def term_variables(t: Term) -> set[str]:
    if t.op == "var":
        return {t.name}
    return set().union(*(term_variables(a) for a in t.args))


def substitute_term(t: Term, variable: str, replacement: Term) -> Term:
    """Substitute only in active arguments; descriptor names are immutable."""
    if t.op == "var" and t.name == variable:
        return replacement
    return Term(t.op, tuple(substitute_term(a, variable, replacement)
                           for a in t.args), t.name)


def term_nodes(t: Term) -> int:
    return 1 + sum(term_nodes(a) for a in t.args)


def term_text(t: Term) -> str:
    if t.op == "var":
        return t.name
    if t.op == "zero":
        return "0"
    if t.op == "S":
        return f"S({term_text(t.args[0])})"
    label = t.op + ("[" + t.name + "]" if t.name else "")
    return label + "(" + ",".join(term_text(a) for a in t.args) + ")"


class Registry:
    """D updates or old I updates, each with one private variable v."""

    def __init__(self, kind: str):
        if kind not in {"D", "I"}:
            raise SyntaxFailure("Unknown registry kind")
        self.kind = kind
        self.entries: dict[str, Term] = {}
        self.order: list[str] = []

    def validate(self, term: Term, variables: set[str]) -> None:
        expected = {"var": 0, "zero": 0, "S": 1, self.kind: 2}
        if self.kind == "I":
            expected["K"] = 2
        if term.op not in expected or len(term.args) != expected[term.op]:
            raise SyntaxFailure(f"Malformed/foreign operation: {term.op}")
        if term.op == "var":
            if not term.name or term.name not in variables:
                raise SyntaxFailure(f"Forbidden free variable: {term.name}")
        elif term.op == self.kind:
            if term.name not in self.entries:
                raise SyntaxFailure(f"Self/future/unknown descriptor: {term.name}")
        elif term.name:
            raise SyntaxFailure("Unexpected name on a primitive operation")
        for argument in term.args:
            self.validate(argument, variables)

    def add(self, name: str, body: Term) -> str:
        if not name or name in self.entries:
            raise SyntaxFailure("Empty or duplicate descriptor name")
        # Validation happens before insertion: no self or forward reference.
        self.validate(body, {"v"})
        self.entries[name] = body
        self.order.append(name)
        return name

    def dependencies(self, name: str) -> list[str]:
        def walk(t: Term) -> set[str]:
            found = {t.name} if t.op == self.kind else set()
            for a in t.args:
                found.update(walk(a))
            return found
        return sorted(walk(self.entries[name]))


class Evaluator:
    """Standard-N semantics with cached descriptor applications."""

    def __init__(self, registry: Registry):
        self.registry = registry

    def term(self, t: Term, values: dict[str, int]) -> int:
        if t.op == "var":
            result = values[t.name]
            if result < 0:
                raise ValueError("Natural-number evaluator received a negative input")
            return result
        if t.op == "zero":
            return 0
        if t.op == "S":
            return self.term(t.args[0], values) + 1
        n, a = (self.term(x, values) for x in t.args)
        if t.op == "K" and self.registry.kind == "I":
            return a if n == 0 else n - 1
        if t.op != self.registry.kind:
            raise SyntaxFailure("Evaluator received a foreign function")
        return self.call(t.name, n, a)

    @lru_cache(maxsize=65536)
    def call(self, name: str, n: int, a: int) -> int:
        if n < 0 or a < 0:
            raise ValueError("Natural-number arguments required")
        if n > 100000:
            raise CheckFailure("Diagnostic iteration budget exceeded")
        body = self.registry.entries[name]
        value = a
        # These are different standard definitions of the old and new symbols.
        repetitions = max(n - 1, 0) if self.registry.kind == "D" else n
        for _ in range(repetitions):
            value = self.term(body, {"v": value})
        return value


class OldToDelayed:
    """Translate the exceptional K and every old unary I update to D terms."""

    def __init__(self, source: Registry):
        self.target = Registry("D")
        self.d_s = self.target.add("base_successor", S(V("v")))
        self.d_z = self.target.add("base_zero", Z)
        self.names: dict[str, str] = {}
        for name in source.order:
            body = self.term(source.entries[name])
            same = next((n for n in self.target.order
                         if self.target.entries[n] == body), None)
            self.names[name] = same or self.target.add("from_" + name, body)

    def predecessor(self, t: Term) -> Term:
        return D(self.d_s, t, Z)

    def term(self, t: Term) -> Term:
        if t.op in {"var", "zero"}:
            return t
        if t.op == "S":
            return S(self.term(t.args[0]))
        n, a = (self.term(x) for x in t.args)
        if t.op == "I":
            return D(self.names[t.name], S(n), a)
        if t.op == "K":
            # K(n,a)=I_S(p(n),I_0(n,a)).
            return D(self.d_s, S(self.predecessor(n)), D(self.d_z, S(n), a))
        raise SyntaxFailure("Old-to-delayed compiler received an invalid term")


class DelayedToOld:
    """Translate D_h(n,a) as I_{h*}(K(n,0),a)."""

    def __init__(self, source: Registry):
        self.target = Registry("I")
        self.names: dict[str, str] = {}
        for name in source.order:
            body = self.term(source.entries[name])
            self.names[name] = self.target.add("from_" + name, body)

    def term(self, t: Term) -> Term:
        if t.op in {"var", "zero"}:
            return t
        if t.op == "S":
            return S(self.term(t.args[0]))
        if t.op == "D":
            n, a = (self.term(x) for x in t.args)
            return I(self.names[t.name], K(n, Z), a)
        raise SyntaxFailure("Delayed-to-old compiler received an invalid term")


@dataclass(frozen=True)
class Formula:
    op: str
    args: tuple[Formula | Term, ...] = ()
    name: str = ""


BOT = Formula("false")


def Eq(left: Term, right: Term) -> Formula:
    return Formula("eq", (left, right))


def And(left: Formula, right: Formula) -> Formula:
    return Formula("and", (left, right))


def Or(left: Formula, right: Formula) -> Formula:
    return Formula("or", (left, right))


def Imp(left: Formula, right: Formula) -> Formula:
    return Formula("imp", (left, right))


def Forall(variable: str, body: Formula) -> Formula:
    return Formula("all", (body,), variable)


DELTA = Eq(Z, S(Z))


def formula_variables(f: Formula) -> set[str]:
    found: set[str] = set()
    for a in f.args:
        found.update(term_variables(a) if isinstance(a, Term)
                     else formula_variables(a))
    return found - {f.name} if f.op == "all" else found


def formula_names(f: Formula) -> set[str]:
    found = {f.name} if f.op == "all" else set()
    for a in f.args:
        found.update(term_variables(a) if isinstance(a, Term)
                     else formula_names(a))
    return found


def substitute_formula(f: Formula, variable: str, replacement: Term) -> Formula:
    if f.op == "all":
        if f.name == variable:
            return f
        binder, body = f.name, f.args[0]
        if binder in term_variables(replacement) and variable in formula_variables(body):
            unavailable = formula_names(body) | term_variables(replacement) | {variable}
            suffix = 0
            fresh = binder + "_" + str(suffix)
            while fresh in unavailable:
                suffix += 1
                fresh = binder + "_" + str(suffix)
            body = substitute_formula(body, binder, V(fresh))
            binder = fresh
        return Forall(binder, substitute_formula(body, variable, replacement))
    return Formula(f.op, tuple(
        substitute_term(a, variable, replacement) if isinstance(a, Term)
        else substitute_formula(a, variable, replacement)
        for a in f.args), f.name)


def formula_nodes(f: Formula) -> int:
    return 1 + sum(term_nodes(a) if isinstance(a, Term) else formula_nodes(a)
                   for a in f.args)


def validate_formula(f: Formula, registry: Registry, allowed: set[str],
                     quantified: bool = False) -> None:
    if f.op == "false":
        if f.args or f.name:
            raise SyntaxFailure("Malformed falsity")
        return
    if f.op == "eq":
        if len(f.args) != 2 or not all(isinstance(a, Term) for a in f.args):
            raise SyntaxFailure("Malformed equality")
        for a in f.args:
            registry.validate(a, allowed)
        return
    if f.op == "all":
        if not quantified or len(f.args) != 1 or not f.name:
            raise SyntaxFailure("Unexpected/malformed quantifier")
        validate_formula(f.args[0], registry, allowed | {f.name}, True)
        return
    if f.op not in {"and", "or", "imp"} or len(f.args) != 2:
        raise SyntaxFailure("Malformed formula connective")
    if f.name or not all(isinstance(a, Formula) for a in f.args):
        raise SyntaxFailure("Malformed formula children")
    for a in f.args:
        validate_formula(a, registry, allowed, quantified)


def guarded_matrix(a_formula: Formula) -> Formula:
    return Imp(Or(substitute_formula(a_formula, "n", Z), DELTA), a_formula)


def base_matrix(name: str, second_seed: bool = False) -> Formula:
    return Eq(D(name, S(Z) if second_seed else Z, V("a")), V("a"))


def tail_matrix(registry: Registry, name: str) -> Formula:
    state = D(name, S(V("a")), V("n"))
    update = substitute_term(registry.entries[name], "v", state)
    return Forall("n", Eq(D(name, S(S(V("a"))), V("n")), update))


def matrix_class(f: Formula, registry: Registry) -> str:
    """Exactly the G, B, T constructors: no normalization or rewrite search."""
    validate_formula(f, registry, {"n", "a"}, quantified=True)
    if f.op == "imp" and f.args[0].op == "or":
        a_formula = f.args[1]
        validate_formula(a_formula, registry, {"n", "a"}, quantified=False)
        if f == guarded_matrix(a_formula):
            return "G"
    if f.op == "eq" and f.args[0].op == "D":
        name = f.args[0].name
        if f == base_matrix(name, False):
            return "B0"
        if f == base_matrix(name, True):
            return "B1"
    if f.op == "all" and f.name == "n":
        eq = f.args[0]
        if eq.op == "eq" and eq.args[0].op == "D":
            name = eq.args[0].name
            if f == tail_matrix(registry, name):
                return "T"
    raise SyntaxFailure("Matrix is not one of the three literal classes")


def propagation_axiom(f: Formula, registry: Registry) -> Formula:
    matrix_class(f, registry)
    step = Imp(f, substitute_formula(f, "n", S(V("n"))))
    return Forall("a", Imp(Forall("n", step), Forall("n", f)))


class Audit:
    def __init__(self):
        self.counts: dict[str, int] = {}

    def check(self, category: str, condition: bool, description: str) -> None:
        if not condition:
            raise CheckFailure(category + ": " + description)
        self.counts[category] = self.counts.get(category, 0) + 1

    def rejects(self, category: str, action: Callable[[], object], description: str) -> None:
        try:
            action()
        except SyntaxFailure:
            self.check(category, True, description)
        else:
            raise CheckFailure(category + ": failed to reject " + description)


def sample_delayed() -> Registry:
    r = Registry("D")
    v = V("v")
    r.add("successor", S(v))
    r.add("zero", Z)
    r.add("identity", v)
    r.add("double", D("successor", S(v), v))
    r.add("predecessor", D("successor", v, Z))
    r.add("odd", S(D("successor", S(v), v)))
    r.add("spike", D("zero", v, S(v)))
    return r


def sample_old() -> Registry:
    r = Registry("I")
    v = V("v")
    r.add("successor", S(v))
    r.add("zero", Z)
    r.add("identity", v)
    r.add("double", I("successor", v, v))
    r.add("predecessor", K(v, Z))
    r.add("odd", S(I("successor", v, v)))
    r.add("spike", I("zero", K(v, Z), S(v)))
    return r


def audit_syntax(audit: Audit, delayed: Registry) -> None:
    malformed = Registry("D")
    audit.rejects("descriptor_rejections", lambda: malformed.add("self", D("self", V("v"), Z)),
                  "self reference")
    audit.rejects("descriptor_rejections", lambda: malformed.add("first", D("future", V("v"), Z)),
                  "future reference")
    audit.rejects("descriptor_rejections", lambda: malformed.add("extra", S(V("a"))),
                  "frozen parameter in update")
    audit.rejects("descriptor_rejections", lambda: malformed.add("counter", V("n")),
                  "counter input in update")
    audit.rejects("descriptor_rejections", lambda: malformed.add("foreign", K(V("v"), Z)),
                  "old exceptional K in new language")
    audit.rejects("descriptor_rejections", lambda: malformed.add("badarity", Term("S", ())),
                  "malformed arity")
    malformed.add("ok", Z)
    audit.rejects("descriptor_rejections", lambda: malformed.add("ok", V("v")),
                  "duplicate descriptor")
    for position, name in enumerate(delayed.order):
        earlier = set(delayed.order[:position])
        audit.check("dependency_DAG", set(delayed.dependencies(name)) <= earlier,
                    "every dependency is strictly earlier")
        audit.check("dependency_DAG", term_variables(delayed.entries[name]) <= {"v"},
                    "only current state variable occurs in update")

    body_before = delayed.entries["successor"]
    active = D("successor", V("n"), V("v"))
    changed = substitute_term(active, "v", Z)
    audit.check("substitution", changed == D("successor", V("n"), Z), "active argument changes")
    audit.check("substitution", delayed.entries["successor"] == body_before == S(V("v")),
                "stored descriptor body is not traversed")

    captured = substitute_formula(Forall("a", Eq(V("n"), V("a"))), "n", V("a"))
    audit.check("substitution", formula_variables(captured) == {"a"}, "capture is avoided")
    audit.check("substitution", captured.name != "a", "conflicting binder is renamed")
    inner = Forall("n", Eq(V("n"), V("a")))
    audit.check("substitution", substitute_formula(inner, "n", S(V("n"))) == inner,
                "bound occurrences are never replaced")

    a_examples = [BOT, Eq(V("n"), V("a")), Eq(D("predecessor", V("n"), V("a")), Z)]
    a_examples += [And(a_examples[1], a_examples[2]), Or(a_examples[1], BOT),
                   Imp(a_examples[1], a_examples[2]), Imp(a_examples[2], BOT)]
    matrices = [guarded_matrix(a) for a in a_examples]
    for name in delayed.order:
        matrices.extend([base_matrix(name), base_matrix(name, True), tail_matrix(delayed, name)])
    for matrix in matrices:
        label = matrix_class(matrix, delayed)
        axiom = propagation_axiom(matrix, delayed)
        audit.check("matrix_admission", label in {"G", "B0", "B1", "T"}, "literal accepted matrix")
        audit.check("emitted_axioms", formula_variables(axiom) == set(), "universal closure is closed")
        audit.check("emitted_axioms", formula_names(axiom) <= {"n", "a"}, "only two active names")
        if label == "T":
            audit.check("substitution", substitute_formula(matrix, "n", S(V("n"))) == matrix,
                        "stationary bound-n tail is unchanged")
            audit.check("substitution", formula_variables(matrix) == {"a"}, "tail only has free a")

    wrong_delta = Imp(Or(Eq(Z, V("a")), Eq(S(Z), Z)), Eq(V("n"), V("a")))
    negatives = [wrong_delta, Eq(D("successor", S(S(Z)), V("a")), V("a")),
                 Eq(D("successor", Z, V("n")), V("n")),
                 Eq(V("a"), D("successor", Z, V("a"))),
                 Forall("a", Eq(D("successor", S(S(V("a"))), V("n")), S(V("n")))),
                 tail_matrix(delayed, "successor").args[0],
                 guarded_matrix(Forall("n", Eq(V("n"), V("a")))),
                 Imp(Or(Eq(V("a"), Z), DELTA), Eq(V("n"), V("a")))]
    for index, matrix in enumerate(negatives):
        audit.rejects("matrix_rejections", lambda matrix=matrix: matrix_class(matrix, delayed),
                      f"nonliteral or nonpermitted matrix {index}")


def audit_semantics(audit: Audit, delayed: Registry, old: Registry) -> dict:
    deval = Evaluator(delayed)
    for name in delayed.order:
        for n in range(7):
            for a in range(5):
                audit.check("delayed_computation", deval.call(name, 0, a) == a, "zero seed")
                audit.check("delayed_computation", deval.call(name, 1, a) == a, "one seed")
                audit.check("delayed_computation",
                            deval.call(name, n + 2, a) ==
                            deval.term(delayed.entries[name], {"v": deval.call(name, n + 1, a)}),
                            "delayed tail")
                ordinary = a
                for _ in range(n):
                    ordinary = deval.term(delayed.entries[name], {"v": ordinary})
                audit.check("shifted_iteration", deval.call(name, n + 1, a) == ordinary,
                            "shifted D equals independently unrolled ordinary iteration")

    n, a = V("n"), V("a")
    p = D("successor", n, Z)
    recovered_k = D("successor", S(p), D("zero", S(n), a))
    for nv in range(21):
        audit.check("predecessor_recovery", deval.term(p, {"n": nv}) == max(nv - 1, 0),
                    "predecessor value")
        audit.check("predecessor_recovery", deval.call("successor", nv + 1, 0) == nv,
                    "p(Sn)=n")
        for av in range(11):
            audit.check("K_recovery", deval.term(recovered_k, {"n": nv, "a": av}) ==
                        (av if nv == 0 else nv - 1), "exceptional old recursor recovered")

    old_to_d = OldToDelayed(old)
    back_to_old = DelayedToOld(old_to_d.target)
    old_evaluator = Evaluator(old)
    forward_evaluator = Evaluator(old_to_d.target)
    round_evaluator = Evaluator(back_to_old.target)
    old_terms = [K(n, a)] + [I(name, n, a) for name in old.order]
    old_terms += [K(S(n), I("predecessor", a, n)),
                  I("successor", K(n, Z), I("zero", n, a))]
    for term in old_terms:
        forward = old_to_d.term(term)
        round_trip = back_to_old.term(forward)
        old_to_d.target.validate(forward, {"n", "a"})
        back_to_old.target.validate(round_trip, {"n", "a"})
        audit.check("compiler_syntax", True, "old-to-D and reverse are legal staged terms")
        for nv in range(7):
            for av in range(5):
                env = {"n": nv, "a": av}
                expected = old_evaluator.term(term, env)
                audit.check("old_to_D_values", forward_evaluator.term(forward, env) == expected,
                            "forward old term compilation")
                audit.check("old_roundtrip_values", round_evaluator.term(round_trip, env) == expected,
                            "old-D-old bounded round trip")

    d_to_old = DelayedToOld(delayed)
    back_to_d = OldToDelayed(d_to_old.target)
    forward_evaluator = Evaluator(d_to_old.target)
    round_evaluator = Evaluator(back_to_d.target)
    d_terms = [D(name, n, a) for name in delayed.order]
    d_terms += [p, recovered_k, D("successor", D("successor", n, Z), a)]
    for term in d_terms:
        forward = d_to_old.term(term)
        round_trip = back_to_d.term(forward)
        d_to_old.target.validate(forward, {"n", "a"})
        back_to_d.target.validate(round_trip, {"n", "a"})
        audit.check("compiler_syntax", True, "D-to-old and reverse are legal staged terms")
        for nv in range(7):
            for av in range(5):
                env = {"n": nv, "a": av}
                expected = deval.term(term, env)
                audit.check("D_to_old_values", forward_evaluator.term(forward, env) == expected,
                            "forward delayed term compilation")
                audit.check("D_roundtrip_values", round_evaluator.term(round_trip, env) == expected,
                            "D-old-D bounded round trip")
    return {
        "old_source_descriptors": len(old.order),
        "delayed_source_descriptors": len(delayed.order),
        "old_sample_terms": len(old_terms),
        "delayed_sample_terms": len(d_terms),
        "values_per_sample_term": 35,
        "old_to_D_example_K": term_text(old_to_d.term(K(n, a))),
        "D_to_old_example": term_text(d_to_old.term(D("successor", n, a))),
    }


def audit_deletions(audit: Audit) -> list[dict]:
    """Bounded audits of explicit standard-N counterinterpretations, h(v)=Sv."""
    def no_zero(n: int, a: int) -> int:
        return a + 7 if n == 0 else a + n - 1

    def no_one(n: int, a: int) -> int:
        return a if n == 0 else a + 7 + n - 1

    def no_tail(n: int, a: int) -> int:
        return a

    for nv in range(11):
        for av in range(5):
            audit.check("deletion_zero", no_zero(1, av) == av and
                        no_zero(nv + 2, av) == no_zero(nv + 1, av) + 1,
                        "remaining one-seed and tail equations")
            audit.check("deletion_one", no_one(0, av) == av and
                        no_one(nv + 2, av) == no_one(nv + 1, av) + 1,
                        "remaining zero-seed and tail equations")
            audit.check("deletion_tail", no_tail(0, av) == av and no_tail(1, av) == av,
                        "both seed equations")
    audit.check("deletion_witnesses", no_zero(0, 0) != 0, "deleted zero law fails")
    audit.check("deletion_witnesses", no_one(1, 0) != 0, "deleted one law fails")
    audit.check("deletion_witnesses", no_tail(2, 0) != no_tail(1, 0) + 1, "deleted tail law fails")
    return [
        {"deleted": "zero seed", "definition": "D(0,a)=a+7; D(n,a)=a+n-1 for n>=1",
         "witness": {"n": 0, "a": 0, "actual": 7, "required": 0}},
        {"deleted": "one seed", "definition": "D(0,a)=a; D(n,a)=a+7+n-1 for n>=1",
         "witness": {"n": 1, "a": 0, "actual": 7, "required": 0}},
        {"deleted": "tail", "definition": "D(n,a)=a",
         "witness": {"n": 2, "a": 0, "actual": 0, "required": 1}},
    ]


def audit_counts(audit: Audit, delayed: Registry) -> dict:
    n, a = V("n"), V("a")
    d_zero = Forall("a", Eq(D("successor", Z, a), a))
    d_one = Forall("a", Eq(D("successor", S(Z), a), a))
    d_tail = Forall("a", Forall("n", Eq(D("successor", S(S(n)), a),
                                        S(D("successor", S(n), a)))))
    k_zero = Forall("a", Eq(K(Z, a), a))
    k_tail = Forall("a", Forall("n", Eq(K(S(n), a), n)))
    i_zero = Forall("a", Eq(I("successor", Z, a), a))
    i_tail = Forall("a", Forall("n", Eq(I("successor", S(n), a),
                                        S(I("successor", n, a)))))
    computed = {
        "D_zero": formula_nodes(d_zero), "D_one": formula_nodes(d_one),
        "D_tail": formula_nodes(d_tail), "K_zero": formula_nodes(k_zero),
        "K_tail": formula_nodes(k_tail), "I_zero": formula_nodes(i_zero),
        "I_tail": formula_nodes(i_tail),
    }
    expected = {"D_zero": 6, "D_one": 7, "D_tail": 13,
                "K_zero": 6, "K_tail": 8, "I_zero": 6, "I_tail": 11}
    audit.check("node_ledger", computed == expected, "universal AST counts")
    opaque = Formula("opaque", (n, a), "F")
    opaque_step = Formula("opaque", (S(n), a), "F")
    outer = Forall("a", Imp(Forall("n", Imp(opaque, opaque_step)), Forall("n", opaque)))
    audit.check("node_ledger", formula_nodes(outer) == 15, "opaque P15 outer count")
    new_emitted = [formula_nodes(propagation_axiom(f, delayed)) for f in
                   [base_matrix("successor"), base_matrix("successor", True),
                    tail_matrix(delayed, "successor")]]
    audit.check("node_ledger", new_emitted == [20, 23, 41], "actual stationary P15 instances")
    # Old stationary packaging through the identical outer P15 schema:
    # initialization matrix size 5; quantified K tail 7; I tail 10.
    old_k_emitted = 3 * 5 + 5 + 3 * 7 + 5
    old_i_emitted = 3 * 5 + 5 + 3 * 10 + 5
    audit.check("node_ledger", (old_k_emitted, old_i_emitted) == (46, 55), "matched old packaging")
    rows = [{"m": m, "old_transparent": 14 + 17 * m, "new_transparent": 26 * m,
             "old_P15_stationary": 46 + 55 * m, "new_P15_stationary": 84 * m}
            for m in range(1, 7)]
    return {
        "convention": "One node per active variable/constant occurrence, application, connective, quantifier; binder labels and stored description bodies excluded. For these computation-template counts h is a one-node unary application, realized concretely by S.",
        "universal_transparent_axioms": computed,
        "one_update_architecture": {"old_K_plus_I": 31, "new_D": 26},
        "finite_library": {"old": "14+17m", "new": "26m", "rows": rows},
        "opaque_outer_schema": 15,
        "fully_emitted_D_stationary_instances": new_emitted,
        "fully_emitted_one_update": {"old_K_plus_I": 101, "new_D": 84},
        "fully_emitted_finite_library": {"old": "46+55m", "new": "84m"},
        "caveat": "31 versus 26 compares the transparent K-plus-one-I architecture with one D update, not complete theory descriptions or all expanded axiom instances. For m>=2 the new finite-library subtotal is larger. The result removes an exceptional update constructor; it is not a total-description-length minimum.",
    }


def main() -> None:
    audit = Audit()
    delayed, old = sample_delayed(), sample_old()
    audit_syntax(audit, delayed)
    compiler = audit_semantics(audit, delayed, old)
    deletions = audit_deletions(audit)
    counts = audit_counts(audit, delayed)
    result = {
        "status": "passed",
        "scope": "Executable syntax and finite diagnostics only; not an end-to-end formal proof of induction recovery, bi-interpretability, or correctness in nonstandard/Kripke models.",
        "runtime": {"python": platform.python_version(), "dependencies": "standard library only"},
        "script_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "checks_by_category": audit.counts,
        "total_checks": sum(audit.counts.values()),
        "description_DAG": [{"name": name, "body": term_text(delayed.entries[name]),
                              "earlier_dependencies": delayed.dependencies(name)}
                             for name in delayed.order],
        "compilers": compiler,
        "counterinterpretations": {
            "ambient_structure": "Standard natural numbers with standard successor and h(v)=S(v). Standard N validates every quantifier-free induction instance even after expansion by arbitrary total functions.",
            "diagnostic_boundary": "The code checks bounded samples of the displayed explicit interpretations. Their general countermodel justification is the written argument; no finite search is claimed to prove it.",
            "cases": deletions,
        },
        "node_counts": counts,
    }
    destination = Path(__file__).resolve().parents[1] / "audit" / "checks.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": result["status"], "total_checks": result["total_checks"],
                      "checks_by_category": audit.counts,
                      "audit_file": str(destination)}, indent=2))


if __name__ == "__main__":
    main()
