#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/check.py
python3 artifacts/check_counterfree.py
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
