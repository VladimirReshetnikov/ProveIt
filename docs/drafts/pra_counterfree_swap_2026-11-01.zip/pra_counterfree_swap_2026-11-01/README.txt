Two compact axiomatizations of PRA
Research report prepared for Vladimir Reshetnikov, 1 November 2026.

Review target: ProveIt commit 5a840e8c09e7257d9e17e292f4c7902f8bd43977.

Main results: a 49-node representative display with 14 selected update-body
nodes, and an alternative 50-node display with 13 selected update-body nodes.
Both combined subtotals are 63; the comparable prior best subtotal is 65.
The 49-node basis removes the counter input from its recursion update.
The 50-node basis has a shorter completeness proof. Neither wins every metric.
The same constructive proof works in classical and intuitionistic logic
separately, with whole-domain identity-round-trip bi-interpretations.
This is not a proof of absolute minimality.

Files
  report.tex, roundtrips.tex, counterfree.tex, report.pdf: complete theorem and proofs.
  axioms.txt: plain-text effective specification.
  source_manifest.json: exact pinned input archive and member hashes.
  artifacts/check.py, artifacts/results.json: 50-node diagnostics.
  artifacts/check_counterfree.py and its JSON: 49-node diagnostics.
  build.sh: build the PDF and run diagnostics using standard TeX Live/Python.
  VALIDATION.txt: checks performed and their limitations.
  SHA256SUMS: release content checksums.

No input archive script was executed. No new Lean or Rocq certificate is
claimed. Numerical tests are finite diagnostics, not universal proofs.
The full bi-interpretability result is the written proof, including internal
uniqueness on nonstandard arguments and both interpretation composites.

Run from this directory:
  sh build.sh
or:
  python3 artifacts/check.py
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
