#!/usr/bin/env python3
"""Standalone diagnostics for the counter-free 49-node PRA basis.

Run: python3 artifacts/check_counterfree.py
This fresh, standard-library-only script does not import any other script.
The written first-order proof has been independently audited, not formally
verified. Finite tests and term reductions are NOT themselves a proof of
induction, expressiveness, or interpretation.
The separate, completed 50-node diagnostics are deliberately left unchanged.
"""
from __future__ import annotations
import argparse
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path

def require(condition, detail="diagnostic failed"):
    """Checks remain active under python -O."""
    if not condition:
        raise AssertionError(detail)

# AST tuple: (kind, label, children). Quantifier names are binder metadata,
# not extra variable occurrences. Every actual child remains explicit.
def node(kind,label,*children): return (kind,label,children)
def variable(s): return node('variable',s)
def app(s,*xs): return node('application',s,*xs)
def equal(x,y): return node('equality','=',x,y)
def imply(x,y): return node('connective','implies',x,y)
def disj(x,y): return node('connective','or',x,y)
def all_(v,f): return node('quantifier',v[1],f)
def close(vs,f):
    for v in reversed(vs): f=all_(v,f)
    return f
ZERO=node('constant','0')
BOTTOM=node('falsity','bottom')
def S(x): return app('S',x)
ONE=S(ZERO)
def count(t): return 1+sum(map(count,t[2]))
def ast_json(t):
    r={'kind':t[0],'label':t[1]}
    if t[2]: r['children']=list(map(ast_json,t[2]))
    return r

def formula_trees(m):
    require(m>=1, 'diagnostic failed')
    n,a=variable('n'),variable('a')
    bs=tuple(variable('b'+str(i)) for i in range(1,m))
    ps=(a,)+bs
    return {
        'D_base':close(ps,equal(app('R',ZERO,a,*bs),a)),
        'D_step':close((n,)+ps,equal(app('R',S(n),a,*bs),
                     app('h',a,*bs,app('R',a,n,*bs)))),
        'PC':close(ps,imply(all_(n,equal(app('f',S(n),a,*bs),app('f',n,a,*bs))),
             all_(n,disj(equal(app('U',app('f',ZERO,a,*bs),a),a),
                         equal(app('f',n,a,*bs),a))))),
        'Sep':imply(equal(ZERO,ONE),BOTTOM)}

def metrics():
    rows=[]
    for m in range(1,13):
        cs={k:count(t) for k,t in formula_trees(m).items()}
        d=cs['D_base']+cs['D_step']
        total=d+cs['PC']+cs['Sep']
        require(cs['D_base']==4+2*m and cs['D_step']==8+4*m, 'diagnostic failed')
        require(d==12+6*m and cs['PC']==20+5*m and cs['Sep']==6, 'diagnostic failed')
        require(total==38+11*m, 'diagnostic failed')
        rows.append({'m':m,**cs,'D':d,'total':total})
    a,b,v=map(variable,('a','b','v'))
    ds={'C':b,'D':v,'U':app('C',app('D',a,v),app('C',app('D',v,a),a,S(a)),a)}
    sizes={k:count(t) for k,t in ds.items()}
    require(sizes=={'C':1,'D':1,'U':12}, 'diagnostic failed')
    require(sum(sizes.values())==14, 'diagnostic failed')
    return {'counting_convention':'Every variable occurrence, constant, application, equality, '
        'connective, bottom, and individual quantifier costs one. Expand negation as '
        'implication to bottom, and 1 as S(0). The two D equations are not conjoined. '
        'Binder names are metadata; all displayed schematic arguments are charged.',
        'closed_forms':{'D':'12 + 6*m','PC':'20 + 5*m','Sep':'6','total':'38 + 11*m'},
        'arity_checks':rows,'one_parameter_nodes':rows[0]['total'],
        'explicit_trees':{str(m):{k:ast_json(t) for k,t in formula_trees(m).items()} for m in (1,3)},
        'selected_bodies':{k:{'count':count(t),'tree':ast_json(t)} for k,t in ds.items()},
        'selected_body_total':14,'display_plus_selected_bodies':49+14,
        'metric_limit':'Not an absolute description-length optimum. Description tags, '
            'binding metadata, schema enumerator, and arbitrary substituted bodies are not included.'}


def direct(h):
    """Standard-N diagnostic evaluator: the recursive argument sum decreases."""
    @lru_cache(None)
    def r(x,a,bs=()):
        require(x>=0 and a>=0, 'diagnostic failed')
        return a if x==0 else h(a,bs,r(a,x-1,bs))
    return r


def compiler(h,omit_inner=False):
    """Ordinary V recursion; d,e,bs are fixed during the iteration.
    V0=C(d,e,h(0,bs,p(d))).
    V(Sj)=h(S(e+j),bs,h(d+j,bs,Vj)).
    Rhat(x,y)=V(min(x,y),x monus y,y monus x).
    """
    def r(x,y,bs=()):
        d,e=max(x-y,0),max(y-x,0)
        value=e if d==0 else h(0,bs,max(d-1,0))
        for j in range(min(x,y)):
            inner=value if omit_inner else h(d+j,bs,value)
            value=h(e+j+1,bs,inner)
        return value
    return r

C=direct(lambda a,b,v:b[0])
D=direct(lambda a,b,v:v)
U=direct(lambda a,b,v:C(D(a,v),C(D(v,a),a,(a+1,)),(a,)))
def p(x): return D(x,0)
def ztest(x): return p(U(x+1,1))  # truth bit: 1 iff x=0
def eqbit(x,y): return D(y+1,U(x+1,y+1))  # 1 iff x=y
def J(z,u,v): return C(ztest(z),v,(u,))  # u iff z=0
ADD=direct(lambda a,b,v:v+1)
ORDER=direct(lambda a,b,v:C(eqbit(a,b[0]),v,(a,)))
def lebit(x,y): return eqbit(ORDER(y,y,(x,)),x)
def monus(x,y): return C(lebit(x,y),D(y,x),(0,))


def compiler_tests(bound=18):
    examples=[('previous',lambda a,b,v:v,[()]),
        ('mutable',lambda a,b,v:a,[()]),
        ('increment',lambda a,b,v:v+1,[()]),
        ('nonlinear',lambda a,b,v:a*a+v,[()]),
        ('frozen',lambda a,b,v:(b[0]+1)*v+a+b[1],[(0,0),(1,2),(3,1)])]
    rows=[]
    for name,h,params in examples:
        r,rc=direct(h),compiler(h)
        comparisons=equations=0
        for bs in params:
            for x,y in itertools.product(range(bound+1),repeat=2):
                require(r(x,y,bs)==rc(x,y,bs), 'diagnostic failed')
                require(rc(0,y,bs)==y, 'diagnostic failed')
                require(rc(x+1,y,bs)==h(y,bs,rc(y,x,bs)), 'diagnostic failed')
                require(rc(x+1,0,bs)==h(0,bs,x), 'diagnostic failed')
                require(rc(x+1,y+1,bs)==h(y+1,bs,h(x,bs,rc(x,y,bs))), 'diagnostic failed')
                comparisons+=1; equations+=4
        rows.append({'update':name,'frozen_tuples':params,'comparisons':comparisons,'equations':equations})
    h=lambda a,b,v:v+1
    r,bad=direct(h),compiler(h,omit_inner=True)
    witness=next(({'x':x,'y':y,'correct':r(x,y),'mutated':bad(x,y)}
                  for x,y in itertools.product(range(bound+1),repeat=2) if r(x,y)!=bad(x,y)),None)
    require(witness, 'diagnostic failed')
    return {'bound':bound,'examples':rows,'total_comparisons':sum(x['comparisons'] for x in rows),
            'total_equations':sum(x['equations'] for x in rows),
            'negative_control':{'mutation':'omit inner update in V','detected':True,'witness':witness}}


def arithmetic_tests(bound=30):
    for x,y in itertools.product(range(bound+1),repeat=2):
        require(D(x,y)==(y-x if y>=x else x-y-1), 'diagnostic failed')
        require(U(x,y)==(y+1 if x==y and x>0 else y), 'diagnostic failed')
        require(U(x,y)==y or x==y, 'diagnostic failed')
        require(eqbit(x,y)==int(x==y), 'diagnostic failed')
        require(ADD(x,y)==x+y, 'diagnostic failed')
        require(ADD(x+1,y)==ADD(x,y)+1, 'diagnostic failed')
        require(ORDER(y,y,(x,))==(x if x<=y else 0), 'diagnostic failed')
        require(lebit(x,y)==int(x<=y), 'diagnostic failed')
        require(ORDER(0,0,(x,))==0, 'diagnostic failed')
        require(ORDER(y+1,y+1,(x,))==C(eqbit(y+1,x),ORDER(y,y,(x,)),(y+1,)), 'diagnostic failed')
        require(lebit(x,0)==eqbit(x,0), 'diagnostic failed')
        require(lebit(x,y+1)==int(bool(lebit(x,y)) or bool(eqbit(x,y+1))), 'diagnostic failed')
        # Bounded witnesses are searched only for this finite diagnostic,
        # never hidden inside the counter-free program definition.
        witness_exists=any(ADD(x,z)==y for z in range(y+1))
        require(bool(lebit(x,y))==witness_exists, 'diagnostic failed')
        require(monus(x,y)==max(x-y,0), 'diagnostic failed')
        require(monus(x,0)==x and monus(x,y+1)==p(monus(x,y)), 'diagnostic failed')
    for x in range(bound+1):
        require(p(x+1)==x, 'diagnostic failed')
        require(ztest(x)==int(x==0), 'diagnostic failed')
        require(D(x,x)==0 and D(x,x+1)==1, 'diagnostic failed')
        require(U(x+1,x)==x and U(x+1,x+1)==x+2, 'diagnostic failed')
        for u,v in itertools.product(range(4),repeat=2):
            require(J(x,u,v)==(u if x==0 else v), 'diagnostic failed')
    require(U(1,1)==2, 'diagnostic failed')
    bad=direct(lambda a,b,v:C(D(a,v),C(D(v,a),a,(0,)),(a,)))
    require(bad(1,1)!=2, 'diagnostic failed')
    return {'bound':bound,'pairs':(bound+1)**2,
        'U_closed_form':'y+1 if x=y>0, otherwise y','U_1_1':U(1,1),
        'D_closed_form':'y-x if y>=x, otherwise x-y-1',
        'helper_formulas':{'p':'D(x,0)','ztest':'p(U(Sx,1)); truth bit for x=0',
            'eqbit':'D(Sy,U(Sx,Sy)); truth bit for x=y','J':'C(ztest(z),v,u)',
            'addition':'R for h(a,v)=S(v)',
            'order_record':'R_x(y,y) for h_x(a,v)=C(eqbit(a,x),v,a)',
            'lebit':'eqbit(R_x(y,y),x)',
            'monus':'C(lebit(x,y),D(y,x),0)'},
        'order_recurrence_checks':(bound+1)**2,
        'order_recurrence':'q(0,x)=0; q(Sn,x)=C(eqbit(Sn,x),q(n,x),Sn)',
        'bounded_additive_witness_checks':(bound+1)**2,
        'bounded_witness_equivalence':'lebit(x,y)=1 iff some z<=y satisfies ADD(x,z)=y',
        'witness_search_scope':'Finite test oracle only; the program definition uses no search.',
        'negative_control':{'mutation':'replace S(a) in U update with 0',
            'detected':True,'claim':'U(1,1)=2','mutated_value':bad(1,1)}}


def idempotent_tests(bound=20):
    examples=[('identity',lambda a,b,v:v),('overwrite',lambda a,b,v:a),
              ('maximum',lambda a,b,v:max(a,v)),('minimum',lambda a,b,v:min(a,v)),
              ('nonzero_latch',lambda a,b,v:1 if a%3==0 else v)]
    rows=[]
    for name,h in examples:
        for a,v in itertools.product(range(bound+1),repeat=2):
            require(h(a,(),h(a,(),v))==h(a,(),v), 'diagnostic failed')
        r=direct(h)
        # General base includes BOTH h0 and h1. Cancelling this base without
        # the additional h0(0)=0 hypothesis would be an invalid simplification.
        d=h(1,(),h(0,(),0))
        require(r(1,1)==d, 'diagnostic failed')
        for n in range(1,bound+1):
            require(r(n,n)==d, 'diagnostic failed')
            require(r(n+1,n+1)==h(n+1,(),r(n,n)), 'diagnostic failed')
            d=h(n+1,(),d)
        normalized=h(0,(),0)==0
        if normalized:
            require(r(1,1)==h(1,(),r(0,0)), 'diagnostic failed')
        rows.append({'update':name,'pointwise_idempotence_checks':(bound+1)**2,
                     'diagonal_steps':bound,'has_normalized_base_h0_0_eq_0':normalized})
    return {'bound':bound,'examples':rows,
            'general_base':'R(1,1)=h(1,h(0,0))',
            'step':'R(n+1,n+1)=h(n+1,R(n,n)) for n>=1',
            'zero_step_caveat':'The same recurrence at n=0 requires h(0,0)=0 (or an equivalent base condition).'}


def qfi_latch_tests(length=9):
    truth_tables=[]
    for b,c in itertools.product((0,1),repeat=2):
        conjunction=C(b,0,(c,)); disjunction=C(b,c,(1,)); implication=C(b,1,(c,))
        require(conjunction==int(bool(b) and bool(c)), 'diagnostic failed')
        require(disjunction==int(bool(b) or bool(c)), 'diagnostic failed')
        require(implication==int(not bool(b) or bool(c)), 'diagnostic failed')
        truth_tables.append({'B':b,'C':c,'and':conjunction,'or':disjunction,'implies':implication})
    values=local_stationarity=0
    for bits in itertools.product((0,1),repeat=length):
        h=lambda a,bs,v:C(bits[a],1,(v,))
        r=direct(h)
        ts=[r(n+1,n+1) for n in range(length-1)]
        for n,t in enumerate(ts):
            require(t==int(0 in bits[:n+2]), 'diagnostic failed')
            require(h(n,(),1)==1, 'diagnostic failed')
            if bits[n]==0: require(t==1, 'diagnostic failed')
            values+=1
        if bits[0]==bits[1]==1: require(ts[0]==0, 'diagnostic failed')
        for n in range(length-2):
            require(ts[n+1]==h(n+2,(),h(n+1,(),ts[n])), 'diagnostic failed')
            if not bits[n+1] or bits[n+2]:
                require(ts[n+1]==ts[n], 'diagnostic failed')
                local_stationarity+=1
    return {'bit_convention':'b(n)=1 iff A(n); 0 denotes false',
            'truth_tables':truth_tables,'latch_update':'h(a,v)=C(b(a),1,v)',
            'diagonal':'t(n)=L(Sn,Sn)','all_bit_sequences_tested':2**length,
            'sequence_length':length,'diagonal_values':values,
            'local_progress_stationarity_checks':local_stationarity,
            'finite_characterization':'t(n)=1 iff some b(k)=0 for 0<=k<=n+1',
            'scope':'Exhaustive finite bit tables verify the local latch computation. '
                'The quantified induction derivation still requires the written contextual PC proof.'}


def ordinary_recursion_tests(bound=11):
    specs=[('identity',lambda b:0,lambda n,b,v:v+1,[()]),
           ('factorial',lambda b:1,lambda n,b,v:(n+1)*v,[()]),
           ('triangular',lambda b:0,lambda n,b,v:v+n+1,[()]),
           ('affine',lambda b:b[0],lambda n,b,v:v+b[1],[(0,0),(2,3)]),
           ('time_dependent',lambda b:b[0]+b[1],lambda n,b,v:(b[0]+1)*v+n+b[1],[(0,2),(1,3)])]
    rows=[]
    for name,g,h,params in specs:
        def update(a,bs,v):
            cap,ps=bs[0],bs[1:]
            active=J(a,g(ps),h(p(a),ps,v))
            return C(lebit(a,cap),v,(active,))
        r=direct(update)
        def W(cap,j,ps): return r(j+1,ADD(cap,j)+1,(cap,)+ps)
        values=steps=consistent=0
        for ps in params:
            expected=[g(ps)]
            for n in range(bound): expected.append(h(n,ps,expected[-1]))
            for cap in range(bound+1):
                for j in range(cap+1):
                    require(W(cap,j,ps)==expected[j], (name,cap,j,ps))
                    require(W(cap,j,ps)==W(j,j,ps), 'diagnostic failed')
                    values+=1;consistent+=1
                    if j<cap:
                        require(W(cap,j+1,ps)==h(j,ps,W(cap,j,ps)), 'diagnostic failed')
                        steps+=1
            for n in range(bound+1):
                require(r(n+1,ADD(n,n)+1,(n,)+ps)==expected[n], 'diagnostic failed')
        rows.append({'ordinary_recursion':name,'parameter_tuples':params,
                     'bounded_W_values':values,'within_cap_recursion_steps':steps,
                     'cross_cap_consistency_checks':consistent})
    # Capacity is essential: the identity example freezes at 0 at cap=0.
    h=lambda a,bs,v:C(lebit(a,bs[0]),v,(J(a,0,v+1),))
    r=direct(h)
    wrong=r(2,ADD(0,1)+1,(0,))
    require(wrong!=1, 'diagnostic failed')
    return {'bound':bound,'examples':rows,
            'update':'h_N(a,v)=if a<=N then J(a,G,H(p(a),v)) else v',
            'W':'W_N(j)=R_N(Sj,S(N+j))','F':'F(n)=W_n(n)',
            'implementation':'All branching, equality, order, predecessor, and addition helpers '
                'are evaluated through the designated counter-free C,D,U,order,and addition programs.',
            'total_W_values':sum(r['bounded_W_values'] for r in rows),
            'total_cross_cap_consistency':sum(r['cross_cap_consistency_checks'] for r in rows),
            'negative_control':{'mutation':'use capacity 0 at j=1 for identity recursion',
                'detected':True,'expected_identity_value':1,'mutated_value':wrong},
            'scope':'Tests the standard numerical equations and cross-N stability only. '
                'An internal quantifier-free proof with changing N is not supplied by these tests.'}


def pretty(t):
    return t[1] if not t[2] else t[1]+'('+','.join(map(pretty,t[2]))+')'
def rewrite_once(t):
    k,s,cs=t
    if k!='application': return t
    if s=='C':
        z,a,b=cs
        if z==ZERO:return a
        if z[0]=='application' and z[1]=='S':return b
    if s=='D':
        z,a=cs
        if z==ZERO:return a
        if z[0]=='application' and z[1]=='S':return app('D',a,z[2][0])
    if s=='U':
        z,a=cs
        if z==ZERO:return a
        if z[0]=='application' and z[1]=='S':
            v=app('U',a,z[2][0])
            return app('C',app('D',a,v),app('C',app('D',v,a),a,S(a)),a)
    return t

def normalize(t,assumptions=()):
    for _ in range(1000):
        replacement=next((rhs for lhs,rhs in assumptions if t==lhs),None)
        if replacement is not None:t=replacement;continue
        new=(t[0],t[1],tuple(normalize(c,assumptions) for c in t[2]))
        new=rewrite_once(new)
        if new==t:return t
        t=new
    raise AssertionError('rewrite limit exceeded')

def symbolic_tests():
    x=variable('x');d=app('D',x,x);r=app('D',x,S(x))
    checks=[('p0',app('D',ZERO,ZERO),ZERO,()),
            ('pS',app('D',S(x),ZERO),x,()),
            ('U11',app('U',ONE,ONE),S(ONE),()),
            ('D diagonal stationarity',app('D',S(x),S(x)),d,()),
            ('D next-diagonal stationarity',app('D',S(x),S(S(x))),r,()),
            ('U successor diagonal conditional on bootstrap lemmas',app('U',S(x),S(x)),S(S(x)),
             ((app('U',S(x),x),x),(d,ZERO),(r,ONE)))]
    rows=[]
    for name,lhs,rhs,assumptions in checks:
        lnorm,rnorm=normalize(lhs,assumptions),normalize(rhs,assumptions)
        require(lnorm==rnorm, (name,pretty(lnorm),pretty(rnorm)))
        rows.append({'identity':name,'lhs':pretty(lhs),'rhs':pretty(rhs),
            'assumptions':[pretty(equal(l,r)) for l,r in assumptions],
            'common_normal_form':pretty(lnorm)})
    return {'checks':rows,'scope':'Syntactic computation rewrites only; every non-computation '
        'lemma used by a reduction is explicitly listed as an assumption.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('results_counterfree.json'))
    args=parser.parse_args()
    result={'status':'DIAGNOSTICS_PASS','theory_status':'WRITTEN_PROOF_AUDITED_NOT_FORMALLY_VERIFIED',
            'scope':'Finite standard-natural-number diagnostics and exact AST accounting, '
                'not formal verification of axiom schemas, QFI, full ordinary-PR expressiveness, '
                'or either interpretation round trip.',
            'metrics':metrics(),'symbolic_computation':symbolic_tests(),
            'reverse_compiler':compiler_tests(),'arithmetic':arithmetic_tests(),
            'idempotent_diagonal_fold':idempotent_tests(),'direct_QFI_latch':qfi_latch_tests(),
            'ordinary_recursion':ordinary_recursion_tests(),
            'reproducibility':{'python':'Python 3.9 or later; standard library only',
                'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'inherited_scripts_executed':False,'imports_other_local_scripts':False,'randomness':False}}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':result['status'],'theory_status':result['theory_status'],
        'nodes':result['metrics']['one_parameter_nodes'],'selected_bodies':14,'combined_subtotal':63,
        'compiler_comparisons':result['reverse_compiler']['total_comparisons'],
        'arithmetic_pairs':result['arithmetic']['pairs'],
        'latch_values':result['direct_QFI_latch']['diagonal_values'],
        'ordinary_W_values':result['ordinary_recursion']['total_W_values'],
        'cross_cap_consistency':result['ordinary_recursion']['total_cross_cap_consistency'],
        'negative_controls_detected':3,'output':str(args.output)},sort_keys=True))

if __name__=='__main__':main()
