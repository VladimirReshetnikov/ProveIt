#!/usr/bin/env python3
"""Reproducible diagnostics for the initialized-swap/pointed-constancy basis.

Only Python's standard library is needed. This program was written afresh;
no inherited archive script is imported or executed. Run from any directory:
    python3 artifacts/check.py
The adjacent results.json is deterministic. Finite numerical tests do not
prove an axiom schema, induction, or bi-interpretability. The symbolic part
checks specified term rewrites, not complete first-order derivations.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path
from typing import Callable


@dataclass(frozen=True)
class Tree:
    """One actual node per variable/constant/application/logical operation.

    A quantifier is a single node with binder metadata and a formula child:
    its binding variable is NOT an additional variable occurrence. Arguments
    and free variable occurrences remain explicit. There is no negation,
    numeral 1, predecessor, q, J, or e node in the counted formula trees.
    """
    tag: str
    label: str
    children: tuple['Tree', ...] = ()

    def count(self) -> int:
        return 1 + sum(c.count() for c in self.children)

    def as_json(self):
        result = {'kind': self.tag, 'label': self.label}
        if self.children:
            result['children'] = [c.as_json() for c in self.children]
        return result

    def show(self) -> str:
        if not self.children:
            return self.label
        if self.tag == 'quantifier':
            return f'forall {self.label}. ({self.children[0].show()})'
        return self.label + '(' + ', '.join(c.show() for c in self.children) + ')'


def var(name): return Tree('variable', name)
def app(name, *args): return Tree('application', name, tuple(args))
def eq(x, y): return Tree('equality', '=', (x, y))
def disj(x, y): return Tree('connective', 'or', (x, y))
def implies(x, y): return Tree('connective', 'implies', (x, y))
def all_(v, body): return Tree('quantifier', v.label, (body,))
def close(vs, body):
    for v in reversed(vs):
        body = all_(v, body)
    return body

ZERO = Tree('constant', '0')
BOTTOM = Tree('falsity', 'bottom')
def succ(x): return app('S', x)
ONE = succ(ZERO)


def formula_trees(m):
    """m >= 1: mutable a plus m-1 frozen parameters in D;
    PC uses the designated comparison parameter a and m-1 other parameters.
    The two computation equations are charged separately, NOT conjoined.
    """
    if m < 1:
        raise ValueError('m must include the comparison/mutable parameter a')
    n, a = var('n'), var('a')
    bs = tuple(var(f'b{i}') for i in range(1, m))
    params = (a,) + bs
    base = close(params, eq(app('R', ZERO, a, *bs), a))
    step = close((n,) + params,
                 eq(app('R', succ(n), a, *bs),
                    app('h', n, a, *bs, app('R', a, n, *bs))))
    fn = app('f', n, a, *bs)
    f0 = app('f', ZERO, a, *bs)
    fs = app('f', succ(n), a, *bs)
    pc = close(params, implies(all_(n, eq(fs, fn)),
               all_(n, disj(eq(app('T', f0, a), a), eq(fn, a)))))
    sep = implies(eq(ZERO, ONE), BOTTOM)
    return {'D_base': base, 'D_step': step, 'PC': pc, 'Sep': sep}


def metric_checks():
    rows = []
    for m in range(1, 13):
        ts = formula_trees(m)
        counts = {k: v.count() for k, v in ts.items()}
        d = counts['D_base'] + counts['D_step']
        total = d + counts['PC'] + counts['Sep']
        assert d == 13 + 6*m
        assert counts['D_base'] == 4 + 2*m
        assert counts['D_step'] == 9 + 4*m
        assert counts['PC'] == 20 + 5*m
        assert counts['Sep'] == 6
        assert total == 39 + 11*m
        rows.append({'m': m, **counts, 'D': d, 'total': total})
    n, a, b, v = map(var, ('n', 'a', 'b', 'v'))
    descriptors = {
        'C': b,
        'D': v,
        'T': app('C', app('D', a, n),
                 app('C', app('D', n, a), a, ZERO), a),
    }
    sizes = {k: t.count() for k, t in descriptors.items()}
    assert sizes == {'C': 1, 'D': 1, 'T': 11}
    assert sum(sizes.values()) == 13
    return {
        'convention': 'Every occurrence counts: variable, constant, application, '
            'equality, connective, bottom, individual quantifier. A binder name '
            'is metadata. Expand 1 as S(0) and not A as implies(A,bottom). '
            'D equations are separate universally closed schemas, not a conjunction.',
        'closed_form': {'D': '13 + 6*m', 'PC': '20 + 5*m',
                        'Sep': '6', 'total': '39 + 11*m'},
        'closed_form_basis': {
            'D_base': '4 + 2*m', 'D_step': '9 + 4*m',
            'PC_antecedent_before_outer_closure': '7 + 2*m',
            'PC_consequent_before_outer_closure': '12 + 2*m',
            'PC_outer_closure': 'm', 'PC_implication': '1'},
        'tested_arities': rows,
        'one_parameter_total': rows[0]['total'],
        'one_parameter_explicit_trees': {
            k: {'count': t.count(), 'text': t.show(), 'tree': t.as_json()}
            for k, t in formula_trees(1).items()},
        'three_parameter_explicit_trees': {
            k: {'count': t.count(), 'text': t.show(), 'tree': t.as_json()}
            for k, t in formula_trees(3).items()},
        'selected_update_bodies': {
            k: {'count': t.count(), 'text': t.show(), 'tree': t.as_json()}
            for k, t in descriptors.items()},
        'selected_update_body_total': sum(sizes.values()),
        'not_charged_as_formula_nodes': [
            'arbitrary substituted update/instance bodies',
            'description tags and variable-binding metadata',
            'schema enumerator',
            'the full effective language; this is not an absolute encoding minimum'],
    }


Update = Callable[[int, int, tuple[int, ...], int], int]


def direct_swap(h: Update):
    """Reference evaluation on N; call sum decreases by one.
    This evaluator is diagnostic, NOT the proposed ordinary-PR compiler.
    """
    @lru_cache(None)
    def r(x, y, bs=()):
        assert x >= 0 and y >= 0
        if x == 0:
            return y
        return h(x-1, y, bs, r(y, x-1, bs))
    return r


def ordinary_compiler(h: Update, omit_inner=False):
    """An explicit ordinary recursion V with d,e,bs held fixed.
    V(0,d,e,bs) = C(d,e,h(p(d),0,bs,p(d))).
    V(j+1,d,e,bs) = h(d+j,e+j+1,bs,h(e+j,d+j,bs,V(j,d,e,bs))).
    Rhat(x,y,bs) = V(min(x,y),x monus y,y monus x,bs).
    omit_inner is used ONLY for a deliberately incorrect negative control.
    """
    def compiled(x, y, bs=()):
        d, e = max(x-y, 0), max(y-x, 0)
        pd = max(d-1, 0)
        value = e if d == 0 else h(pd, 0, bs, pd)
        for j in range(min(x, y)):
            inner = value if omit_inner else h(e+j, d+j, bs, value)
            value = h(d+j, e+j+1, bs, inner)
        return value
    return compiled


C = direct_swap(lambda n, a, bs, v: bs[0])
D = direct_swap(lambda n, a, bs, v: v)
T = direct_swap(lambda n, a, bs, v: C(D(a, n), C(D(n, a), a, (0,)), (a,)))


def pred(n): return D(n, 0)
def q(n): return T(n+1, 1)
def error(x, y): return T(x+1, y+1)
def selector(z, u, v): return C(q(z), u, (v,))


def compiler_checks(bound):
    cases = [
        ('return_previous', lambda n,a,b,v: v, [()]),
        ('return_time', lambda n,a,b,v: n, [()]),
        ('return_mutable', lambda n,a,b,v: a, [()]),
        ('increment', lambda n,a,b,v: v+1, [()]),
        ('nonlinear', lambda n,a,b,v: n*a+v+1, [()]),
        ('one_frozen', lambda n,a,b,v: (n+1)*b[0]+a+v, [(0,), (1,), (4,)]),
        ('two_frozen', lambda n,a,b,v: (b[0]+1)*v+n*b[1]+a,
            [(0,0), (1,2), (3,1)]),
    ]
    results = []
    for name, h, tuples in cases:
        r, rc = direct_swap(h), ordinary_compiler(h)
        tests = equations = 0
        for bs in tuples:
            for x,y in itertools.product(range(bound+1), repeat=2):
                assert r(x,y,bs) == rc(x,y,bs), (name,x,y,bs)
                tests += 1
                assert rc(0,y,bs) == y
                assert rc(x+1,y,bs) == h(x,y,bs,rc(y,x,bs))
                assert rc(x+1,0,bs) == h(x,0,bs,x)
                assert rc(x+1,y+1,bs) == h(x,y+1,bs,h(y,x,bs,rc(x,y,bs)))
                equations += 4
        results.append({'update': name, 'frozen_parameter_tuples': tuples,
                        'direct_vs_compiled': tests, 'equation_checks': equations})
    # Intentionally wrong V that omits the inner h.
    h = lambda n,a,b,v: v+1
    r, bad = direct_swap(h), ordinary_compiler(h, omit_inner=True)
    witnesses = [(x,y,r(x,y),bad(x,y)) for x,y in
                 itertools.product(range(bound+1), repeat=2) if r(x,y) != bad(x,y)]
    assert witnesses, 'negative control did not detect the wrong compiler'
    x,y,good,wrong = witnesses[0]
    return {'bound': bound, 'updates': results,
            'total_comparisons': sum(r['direct_vs_compiled'] for r in results),
            'total_equation_checks': sum(r['equation_checks'] for r in results),
            'negative_control': {'mutation': 'omit inner h in the V successor step',
                'detected': True, 'witness': {'x':x,'y':y,'correct':good,'mutated':wrong}}}


def arithmetic_checks(bound):
    pairs = 0
    for x,y in itertools.product(range(bound+1), repeat=2):
        dclosed = y-x if y >= x else x-y-1
        tclosed = 0 if x == y and x > 0 else y
        assert D(x,y) == dclosed
        assert T(x,y) == tclosed
        assert (D(x,y) == 0) == (x == y or x == y+1)
        assert T(x,y) == y or x == y
        assert (error(x,y) == 0) == (x == y)
        assert (x-y if x >= y else 0) + min(x,y) == x
        assert (y-x if y >= x else 0) + min(x,y) == y
        assert max(x-y,0) == 0 or max(y-x,0) == 0
        assert min(x+1,y+1) == min(x,y)+1
        pairs += 1
    for x in range(bound+1):
        assert pred(x+1) == x
        assert q(x) == int(x != 0)
        assert D(x,x) == 0
        assert D(x,x+1) == 1
        assert T(x+1,x+1) == 0
        for u,v in itertools.product(range(5), repeat=2):
            assert selector(x,u,v) == (u if x == 0 else v)
    # Wrong constructor update: reverse the D inputs in BOTH selector tests.
    bad_t = direct_swap(lambda n,a,bs,v:
        C(D(n,a), C(D(a,n),a,(0,)), (a,)))
    witnesses = [(x,y,T(x,y),bad_t(x,y)) for x,y in
        itertools.product(range(bound+1), repeat=2) if T(x,y) != bad_t(x,y)]
    assert witnesses
    assert bad_t(1,1) != 0  # Specifically catches the failed bootstrap q(0)=0.
    x,y,good,wrong = witnesses[0]
    return {'bound': bound, 'pairs': pairs,
            'D_closed_form': 'y-x if y>=x, otherwise x-y-1',
            'T_closed_form': '0 if x=y>0, otherwise y',
            'checked_helpers': ['p(Sx)=x', 'q(x)=0 iff x=0', 'D(x,x)=0',
                'D(x,Sx)=1', 'T(Sx,Sx)=0', 'e(x,y)=0 iff x=y',
                'J(z,u,v) selects by z=0', 'normalization d+m=x,e+m=y',
                'axis normalization d=0 or e=0', 'min successor shift'],
            'negative_control': {'mutation': 'reverse both D arguments in the T update',
                'detected': True, 'witness': {'x':x,'y':y,'correct':good,'mutated':wrong},
                'bootstrap_failure': {'claim': 'T(1,1)=0', 'mutated_value':bad_t(1,1)}}}


def simulation_checks(bound):
    specifications = [
        ('identity', lambda b: 0, lambda n,b,v: v+1, [()]),
        ('factorial', lambda b: 1, lambda n,b,v: (n+1)*v, [()]),
        ('triangular', lambda b: 0, lambda n,b,v: v+n+1, [()]),
        ('affine_frozen', lambda b:b[0], lambda n,b,v:v+b[1], [(0,0),(2,3),(4,1)]),
        ('time_dependent_frozen', lambda b:b[0]+b[1],
            lambda n,b,v:(b[0]+1)*v+n+b[1], [(0,2),(1,3)]),
    ]
    result = []
    for name,g,h,tuples in specifications:
        def update(n,a,b,v):
            return selector(error(a,n),v,selector(n,g(b),h(pred(n),b,v)))
        r = direct_swap(update)
        count = 0
        for bs in tuples:
            v = g(bs)
            for n in range(bound+1):
                assert r(n+1,n+1,bs) == v, (name,n,bs)
                assert r(n+1,n,bs) == r(n,n,bs)
                assert r(n+2,n+2,bs) == h(n,bs,r(n+1,n+1,bs))
                v = h(n,bs,v)
                count += 1
        result.append({'ordinary_recursion': name, 'parameter_tuples': tuples,
                       'value_and_two_equation_checks': count})
    return {'bound':bound,'examples':result,
            'update': 'J(e(a,n),v,J(n,G(b),H(p(n),b,v)))',
            'decoded_function': 'F(n,b)=R(Sn,Sn,b)',
            'total_values':sum(r['value_and_two_equation_checks'] for r in result),
            'helper_implementation': 'J,q,e,p evaluated via the selected C,D,T swap programs'}


def rewrite_once(term):
    """The ONLY built-in equalities are the six selected computation laws."""
    cs = term.children
    if term.tag != 'application':
        return term
    if term.label == 'C' and len(cs) == 3:
        z,a,b = cs
        if z == ZERO: return a
        if z.tag == 'application' and z.label == 'S': return b
    if term.label == 'D' and len(cs) == 2:
        z,a = cs
        if z == ZERO: return a
        if z.tag == 'application' and z.label == 'S': return app('D',a,z.children[0])
    if term.label == 'T' and len(cs) == 2:
        z,a = cs
        if z == ZERO: return a
        if z.tag == 'application' and z.label == 'S':
            n = z.children[0]
            return app('C',app('D',a,n),app('C',app('D',n,a),a,ZERO),a)
    return term


def normalize(term, assumptions=()):
    """Finite syntactic rewriting; assumption equations are explicit per check."""
    for _ in range(1000):
        replacement = next((rhs for lhs,rhs in assumptions if term == lhs), None)
        if replacement is not None:
            term = replacement
            continue
        if term.children:
            newer = Tree(term.tag,term.label,tuple(normalize(c,assumptions) for c in term.children))
        else:
            newer = term
        newer = rewrite_once(newer)
        if newer == term:
            return term
        term = newer
    raise AssertionError('rewrite step limit exceeded')


def symbolic_checks():
    x = var('x')
    dxx = app('D',x,x)
    dxsx = app('D',x,succ(x))
    checks = [
        ('p(0)=0', app('D',ZERO,ZERO), ZERO, ()),
        ('p(Sx)=x', app('D',succ(x),ZERO), x, ()),
        ('T(1,1)=0', app('T',ONE,ONE), ZERO, ()),
        ('diagonal d base', app('D',ZERO,ZERO), ZERO, ()),
        ('diagonal d stationarity', app('D',succ(x),succ(x)), dxx, ()),
        ('diagonal r base', app('D',ZERO,ONE), ONE, ()),
        ('diagonal r stationarity', app('D',succ(x),succ(succ(x))), dxsx, ()),
        ('successor diagonal eraser, conditional on proved diagonal lemmas',
            app('T',succ(x),succ(x)), ZERO, ((dxx,ZERO),(dxsx,ONE))),
    ]
    rows = []
    for name,lhs,rhs,assumptions in checks:
        left, right = normalize(lhs,assumptions),normalize(rhs,assumptions)
        assert left == right, (name,left.show(),right.show())
        rows.append({'identity':name,'lhs':lhs.show(),'rhs':rhs.show(),
                     'assumptions':[eq(l,r).show() for l,r in assumptions],
                     'common_normal_form':left.show()})
    return {'method':'Term equality by the six selected computation rewrite rules; '
                     'all additional lemma assumptions are listed per identity.',
            'checks':rows,
            'scope':'These finite symbolic reductions use arbitrary variables. '
                    'They do not themselves prove the stationary preservation lemmas, '
                    'induction, or any complete first-order interpretation theorem.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('results.json'))
    args = parser.parse_args()
    result = {
        'status':'PASS',
        'scope':'Exact formula-tree and selected-body counts, explicit symbolic '
                'computation reductions, and finite natural-number diagnostics. '
                'Not a formal verification of the complete first-order theory, '
                'quantified axiom schemas, or bi-interpretation theorem.',
        'metric_checks':metric_checks(),
        'symbolic_computation_checks':symbolic_checks(),
        'swap_compiler_checks':compiler_checks(18),
        'arithmetic_checks':arithmetic_checks(30),
        'ordinary_recursion_simulation_checks':simulation_checks(14),
        'reproducibility':{'python':'Python 3.9 or later; standard library only',
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'inherited_scripts_executed':False,'randomness':False},
    }
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':result['status'],
        'one_parameter_nodes':result['metric_checks']['one_parameter_total'],
        'selected_update_body_nodes':result['metric_checks']['selected_update_body_total'],
        'compiler_comparisons':result['swap_compiler_checks']['total_comparisons'],
        'compiler_equation_checks':result['swap_compiler_checks']['total_equation_checks'],
        'arithmetic_pairs':result['arithmetic_checks']['pairs'],
        'simulation_values':result['ordinary_recursion_simulation_checks']['total_values'],
        'symbolic_reductions':len(result['symbolic_computation_checks']['checks']),
        'negative_controls_detected':2,'output':str(args.output)},sort_keys=True))


if __name__ == '__main__':
    main()
