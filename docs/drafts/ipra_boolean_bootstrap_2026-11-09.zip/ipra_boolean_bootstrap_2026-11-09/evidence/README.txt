EVIDENCE MAP
============

source_manifest.json              Exact identities of all 11 current ZIPs.
measurements.json                 New matched term sizes; old kernel size.
reproduction.json                 Executed new certificate/control/size checks.
document_quality.json             Final PDF build, extraction, and visual review.
build.log                        Actual three-pass compilation output.
compilation_environment.json      Local TeX runtime and successful build details.

Independent reviews retain their original research wording and may name
intermediate work paths. The delivered equivalents are:

  work/plain_ar_corpus_scan.json -> corpus_search_audit.json
  work/plain_ar_size_audit.json  -> matched_tree_size_audit.json
  work/plain_ar_replayer_source_identity.json -> replayer_source_identity.json
  work/plain_ar_novelty_audit.md -> independent_mathematical_audit.txt
  work/plain_ar_replayer_review.md -> independent_replayer_review.txt

global_frontier_final_review.txt explains why the proven local deletion did
not yield a smaller complete native checker. It is not a minimality proof.

These reviews and finite controls support the stated manuscript and replay
scope. They are not a full machine formalization of the interpretation
theorems or a verification of all inherited historical checker suites.
