"""Matched numerical-tree comparison and inherited complete-kernel measurement.

The two measures concern different objects. No complete-checker improvement
is inferred from a smaller numerical term. The frozen kernel is not executed.
"""
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

import closed_terms as ct


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def run():
    root = Path(__file__).resolve().parents[1]
    a, b, z = map(ct.V, ['a', 'b', 'z'])
    definitions = ct.DECLARATIONS + [
        {'name': 'old_transition', 'parameters': ['a', 'b', 'z'],
         'body': ct.A('mask', ct.A('d', a, b), ct.S(z))},
        {'name': 'raw_transition', 'parameters': ['a', 'b', 'z'],
         'body': ct.A('mask', ct.A('epsilon', a, b), ct.S(z))},
    ]
    names = {'epsilon', 'd', 'old_transition', 'raw_transition'}
    rows = [r for r in ct.tree_node_counts(definitions) if r['name'] in names]
    expected = {'epsilon': 182, 'd': 374,
                'old_transition': 378, 'raw_transition': 186}
    for row in rows:
        if row['expanded_nodes_on_variable_arguments'] != expected[row['name']]:
            raise RuntimeError('Matched numerical-tree count changed')

    source = root / 'reference/frontier_kernel/complete_kernel.py'
    raw = source.read_bytes()
    tree = StripDocstrings().visit(ast.parse(raw.decode('utf-8')))
    normalized = (ast.unparse(tree) + '\n').encode('utf-8')
    ignored = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
               tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
               tokenize.ENDMARKER}
    tokens = tokenize.generate_tokens(io.StringIO(normalized.decode()).readline)
    metrics = {'normalized_tokens': sum(t.type not in ignored for t in tokens),
               'ast_nodes': sum(1 for _ in ast.walk(tree)),
               'normalized_bytes': len(normalized)}
    if platform.python_version() == '3.12.14':
        if metrics != {'normalized_tokens': 309, 'ast_nodes': 344,
                       'normalized_bytes': 864}:
            raise RuntimeError('Frozen complete-kernel count changed')
    result = {
        'passed': True, 'python': platform.python_version(),
        'numerical_tree_measure':
            'Fully expanded variable/zero/successor/iterator nodes; each '
            'fixed unary update body counted at every occurrence.',
        'term_declaration_sha256': ct.source_digest(), 'terms': rows,
        'complete_kernel': {
            'path': str(source.relative_to(root)),
            'source_sha256': hashlib.sha256(raw).hexdigest(),
            'normalized_sha256': hashlib.sha256(normalized).hexdigest(),
            **metrics},
        'scope': 'Local guard deletion only; no new complete-checker record.',
    }
    (root / 'evidence/measurements.json').write_text(
        json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    print(json.dumps(run(), indent=2))
