"""Explicit closed-iterator terms for the clock calibration report.

Only 0, S and I_h are primitive numerical syntax. Named helpers are acyclic
macros. An iterator update is always an earlier unary declaration, evaluated
in a fresh one-variable environment; it never captures an ambient parameter.
This is a term validator/evaluator, not a proof checker for iPRA.
"""
from functools import lru_cache
import hashlib
import json


def V(name):
    return ["v", name]


def S(term):
    return ["S", term]


def A(name, *arguments):
    return ["call", name, *arguments]


def I(update, counter, seed):
    return ["I", update, counter, seed]


ZERO = ["0"]
ONE = S(ZERO)
x, y, n, a, b, u = map(V, ("x", "y", "n", "a", "b", "u"))

DECLARATIONS = [
    {"name": "zero", "parameters": ["u"], "body": ZERO},
    {"name": "succ", "parameters": ["u"], "body": S(u)},
    {"name": "mask", "parameters": ["n", "a"], "body": I("zero", n, a)},
    {"name": "Z", "parameters": ["n"], "body": A("mask", n, ONE)},
    {"name": "bit", "parameters": ["n"], "body": A("Z", A("Z", n))},
    {"name": "add", "parameters": ["a", "b"], "body": I("succ", b, a)},
    {"name": "clock", "parameters": ["a"], "body": I("succ", a, ZERO)},
    {"name": "C0", "parameters": ["n", "a", "b"],
     "body": A("add", A("mask", n, a), A("mask", A("Z", n), b))},
    {"name": "parity", "parameters": ["n"], "body": I("Z", n, ZERO)},
    {"name": "j", "parameters": ["u"],
     "body": A("add", A("Z", u), A("add", A("parity", u), A("parity", u)))},
    {"name": "mod3", "parameters": ["n"], "body": I("j", n, ZERO)},
    {"name": "g", "parameters": ["u"], "body": S(A("add", u, A("mod3", u)))},
    {"name": "G", "parameters": ["n"], "body": I("g", n, ZERO)},
    {"name": "H", "parameters": ["u"],
     "body": A("C0", A("parity", u), A("G", u), u)},
    {"name": "double", "parameters": ["u"], "body": A("add", u, u)},
    {"name": "pow2", "parameters": ["n"], "body": I("double", n, ONE)},
    {"name": "L", "parameters": ["a", "b"],
     "body": A("parity", I("H", b, A("pow2", a)))},
    {"name": "ell", "parameters": ["a", "b"], "body": A("Z", A("L", a, b))},
    {"name": "epsilon", "parameters": ["a", "b"],
     "body": I("Z", A("ell", a, b), A("ell", b, a))},
    {"name": "d", "parameters": ["a", "b"],
     "body": A("mask", A("epsilon", A("clock", b), b), A("epsilon", a, b))},
    {"name": "ramp", "parameters": ["y", "a", "b"],
     "body": I("succ", A("mask", A("bit", y), a),
               A("mask", A("Z", A("bit", y)), b))},
]


class InvalidTerm(ValueError):
    pass


def validate(declarations):
    """Reject forward references, wrong arities, and captured variables."""
    earlier = {}

    def walk(term, allowed):
        if not isinstance(term, list) or not term:
            raise InvalidTerm("Terms must be nonempty arrays")
        kind = term[0]
        if kind == "0" and len(term) == 1:
            return
        if kind == "v" and len(term) == 2 and term[1] in allowed:
            return
        if kind == "S" and len(term) == 2:
            walk(term[1], allowed)
            return
        if kind == "call" and len(term) >= 2 and term[1] in earlier:
            if len(term) - 2 != len(earlier[term[1]]["parameters"]):
                raise InvalidTerm("Macro application arity mismatch")
            for child in term[2:]:
                walk(child, allowed)
            return
        if kind == "I" and len(term) == 4 and term[1] in earlier:
            if len(earlier[term[1]]["parameters"]) != 1:
                raise InvalidTerm("An iterator update must be a closed unary description")
            walk(term[2], allowed)
            walk(term[3], allowed)
            return
        raise InvalidTerm("Malformed term, undeclared variable, or non-earlier symbol")

    if type(declarations) is not list:
        raise InvalidTerm("Declaration table must be an array")
    for row in declarations:
        if type(row) is not dict or set(row) != {"name", "parameters", "body"}:
            raise InvalidTerm("Malformed declaration")
        name, params = row["name"], row["parameters"]
        if not isinstance(name, str) or not name.isidentifier() or name in earlier:
            raise InvalidTerm("Invalid or repeated declaration name")
        if type(params) is not list or len(params) != len(set(params)):
            raise InvalidTerm("Malformed parameter list")
        if not all(isinstance(p, str) and p.isidentifier() for p in params):
            raise InvalidTerm("Invalid parameter name")
        walk(row["body"], set(params))
        earlier[name] = row
    return earlier


def tree_node_counts(declarations):
    """Count fully expanded trees, including every fixed update body.

    No exponential tree is allocated. A macro's expanded size is an affine
    function of the sizes of its argument trees. One node is charged for
    each variable, 0, S, and I (whose update body is charged recursively).
    This is a disclosed syntax measure, not complete-checker size.
    """
    validate(declarations)
    affine = {}
    rows = []
    for row in declarations:
        params = row["parameters"]

        def plus(left, right):
            return [a + b for a, b in zip(left, right)]

        def scale(k, vector):
            return [k * value for value in vector]

        def node(term):
            tag = term[0]
            if tag == "v":
                result = [0] * (len(params) + 1)
                result[params.index(term[1]) + 1] = 1
                return result
            if tag == "0":
                return [1] + [0] * len(params)
            if tag == "S":
                result = node(term[1])
                result[0] += 1
                return result
            if tag == "call":
                coefficients = affine[term[1]]
                result = [coefficients[0]] + [0] * len(params)
                for coefficient, argument in zip(coefficients[1:], term[2:]):
                    result = plus(result, scale(coefficient, node(argument)))
                return result
            if tag == "I":
                result = plus(node(term[2]), node(term[3]))
                result[0] += 1 + sum(affine[term[1]])
                return result
            raise InvalidTerm("Unknown node")

        affine[row["name"]] = node(row["body"])
        rows.append({"name": row["name"], "expanded_nodes_on_variable_arguments":
                     sum(affine[row["name"]]), "affine_coefficients": affine[row["name"]]})
    return rows


def evaluator(declarations=DECLARATIONS, successor_acceleration=True):
    table = validate(declarations)
    if successor_acceleration and table.get("succ") != DECLARATIONS[1]:
        raise InvalidTerm("Successor acceleration requires the exact successor declaration")

    @lru_cache(maxsize=None)
    def call(name, arguments):
        row = table[name]
        if len(arguments) != len(row["parameters"]):
            raise InvalidTerm("Evaluation arity mismatch")
        if not all(type(x) is int and x >= 0 for x in arguments):
            raise InvalidTerm("Evaluator inputs must be natural numbers")
        return evaluate(row["body"], dict(zip(row["parameters"], arguments)))

    @lru_cache(maxsize=None)
    def iterate(update, counter, seed):
        if successor_acceleration and update == "succ":
            return counter + seed
        state, step, seen = seed, 0, {}
        while step < counter:
            if state in seen:
                period = step - seen[state]
                skips = (counter - step) // period
                if skips:
                    step += skips * period
                    continue
            else:
                seen[state] = step
            state = call(update, (state,))
            step += 1
        return state

    def evaluate(term, environment):
        tag = term[0]
        if tag == "0":
            return 0
        if tag == "v":
            return environment[term[1]]
        if tag == "S":
            return evaluate(term[1], environment) + 1
        if tag == "call":
            return call(term[1], tuple(evaluate(x, environment) for x in term[2:]))
        if tag == "I":
            # The update's environment is made by call(), never inherited here.
            return iterate(term[1], evaluate(term[2], environment), evaluate(term[3], environment))
        raise InvalidTerm("Unknown evaluator term")

    return call, iterate


def source_digest(declarations=DECLARATIONS):
    raw = json.dumps(declarations, separators=(",", ":"), sort_keys=True).encode()
    return hashlib.sha256(raw).hexdigest()


if __name__ == "__main__":
    print(json.dumps({"declarations": DECLARATIONS, "sha256": source_digest(),
                      "expanded_tree_sizes": tree_node_counts(DECLARATIONS)}, indent=2))
