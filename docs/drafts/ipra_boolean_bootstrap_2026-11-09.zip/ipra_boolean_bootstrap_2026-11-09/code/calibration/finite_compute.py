"""Literal closed-iteration evaluation for the two concrete endpoint proofs.

This interpreter makes every iteration step. It does not use the accelerated
or cycle-skipping evaluator in the inherited closed_terms.py. The declaration
table is unchanged, and its staged closed-update validator is reused.
Evaluation of closed terms is a finite defining-equation reduction, not an
induction oracle for variable inputs. It is deliberately capped in this
certificate profile, which only needs L(1,0) and L(0,1).
"""
from functools import lru_cache
import closed_terms


def numeral(n):
    value = ['zero']
    for _ in range(n):
        value = ['S', value]
    return value


def compute_endpoint(arguments):
    if type(arguments) is not list or len(arguments) != 2:
        raise ValueError('Malformed endpoint arguments')
    if any(type(n) is not int or n not in (0, 1) for n in arguments):
        raise ValueError('Endpoint inputs must be literal zero/one numerals')
    table = closed_terms.validate(closed_terms.DECLARATIONS)
    counts = {'iterator_zero_rules': 0, 'iterator_successor_rules': 0,
              'macro_expansions': 0, 'successor_constructors': 0}

    @lru_cache(maxsize=None)
    def call(name, arguments):
        row = table[name]
        if len(arguments) != len(row['parameters']):
            raise ValueError('Wrong declaration arity')
        counts['macro_expansions'] += 1
        return evaluate(row['body'], dict(zip(row['parameters'], arguments)))

    def evaluate(term, environment):
        tag = term[0]
        if tag == '0': return 0
        if tag == 'v': return environment[term[1]]
        if tag == 'S':
            counts['successor_constructors'] += 1
            return evaluate(term[1], environment) + 1
        if tag == 'call':
            return call(term[1], tuple(evaluate(x, environment) for x in term[2:]))
        if tag == 'I':
            update, counter, seed = term[1:]
            counter = evaluate(counter, environment)
            state = evaluate(seed, environment)
            counts['iterator_zero_rules'] += 1
            for _ in range(counter):
                counts['iterator_successor_rules'] += 1
                if counts['iterator_successor_rules'] > 100000:
                    raise ValueError('Finite endpoint reduction budget exceeded')
                state = call(update, (state,))
            return state
        raise ValueError('Unknown closed-term constructor')

    result = call('L', tuple(arguments))
    return {'value': result, 'reductions': counts,
            'declaration_sha256': closed_terms.source_digest()}
