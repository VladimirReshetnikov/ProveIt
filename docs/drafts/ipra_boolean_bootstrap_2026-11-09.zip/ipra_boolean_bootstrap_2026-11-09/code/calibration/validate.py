"""Finite positive/negative checks of the symbolic calibration replayer."""
import copy
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import replay

ROOT=Path(__file__).resolve().parent
certificate=json.loads((ROOT/'certificate.json').read_text())
def nodes(value):
    if type(value) is dict:
        if 'rule' in value:yield value
        for x in value.values():yield from nodes(x)
    elif type(value) is list:
        for x in value:yield from nodes(x)
def first(value,rule):return next(n for n in nodes(value) if n.get('rule')==rule)
def mutant(change):
    value=copy.deepcopy(certificate);change(value);return value
def change_ar(value,key,item):first(value,'AR')[key]=item

tests=[]
def add(name,change,contains=None):tests.append((name,mutant(change),contains))
add('invented_arithmetic_axiom',lambda c:first(c,'axiom').update(name='equality_reflection'),'Unlicensed arithmetic')
add('unchecked_later_theorem',lambda c:first(c,'theorem').update(name='clock_identity'),'Unchecked')
add('AR_eigenvariable_in_passive_parameters',lambda c:change_ar(c,'eigenvariable','a'),'fresh')
add('AR_eigenvariable_escapes_in_target',lambda c:change_ar(c,'target',['var','z']),'fresh')
add('AR_template_variable_reused_as_eigenvariable',lambda c:change_ar(c,'eigenvariable','x'),'Invalid AR variables')
add('AR_unlicensed_independent_anchor',lambda c:first(c,'AR').update(anchor=['zero']),'Malformed AR')
add('AR_wrong_template',lambda c:change_ar(c,'template',['var','x']),'AR premise')
add('AR_missing_premise',lambda c:first(c,'AR').pop('proof'),'Malformed AR')
add('AR_changed_target_without_transports',lambda c:change_ar(c,'target',['S',['zero']]),'Transitivity middle')
add('unlicensed_induction_rule',lambda c:first(c,'AR').update(rule='induction'),'Unlicensed inference')
add('wrong_computation_argument',lambda c:first(c,'axiom').update(terms=[]),'arity mismatch')
add('unsupported_term_constructor',lambda c:first(c,'axiom').update(terms=[['oracle']]),'arity mismatch')
add('noncorrelated_raw_diagonal_bit',lambda c:first(c['claims'][1],'axiom').update(terms=[['w',['var','a'],['var','b']]]))
add('clock_proof_replaced_by_reflexivity',lambda c:c['claims'][5].update(proof={'rule':'eq_refl','term':['zero']}),'wrong exported')
add('changed_trusted_mask_axiom',lambda c:c['trusted_axioms'].update(MS='M(Sn,a)=a'),'declaration mismatch')
add('invented_Boolean_induction_oracle',lambda c:first(c['claims'][4],'AR').update(rule='Boolean_induction'),'Unlicensed inference')
add('forged_computed_endpoint_value',lambda c:first(c,'closed_compute').update(value=1),'Malformed finite computation')
add('changed_closed_endpoint_input',lambda c:first(c,'closed_compute').update(arguments=[0,1]))
add('nonliteral_computation_input',lambda c:first(c,'closed_compute').update(arguments=[['var','a'],0]),'literal zero/one')
add('clock_defect_AR_eigenvariable_in_target',lambda c:first(c['claims'][4],'AR').update(target=['var','z']),'fresh')
add('second_diagonal_reinserted_in_declared_rule',lambda c:c.update(trusted_AR='Corrected d guard'),'AR declaration mismatch')
add('duplicate_exported_theorem',lambda c:c['claims'][1].update(name='raw_range'),'specified order')

positive=replay.verify(certificate)
rows=[]
for name,value,contains in tests:
    try:
        replay.verify(value)
        raise RuntimeError('Invalid certificate was accepted: '+name)
    except (replay.nd.InvalidCertificate,KeyError,TypeError,IndexError,RecursionError,ValueError) as error:
        message=str(error)
        if contains and contains not in message:raise RuntimeError(name+': unexpected failure: '+message)
        rows.append({'name':name,'rejected':True,'reason':message})

cli=[]
with tempfile.TemporaryDirectory(prefix='calibration-check-') as directory:
    for optimize in (False,True):
        args=[sys.executable]+(['-O'] if optimize else [])+[str(ROOT/'replay.py')]
        process=subprocess.run(args,capture_output=True,text=True,timeout=20)
        if process.returncode!=0 or not json.loads(process.stdout)['accepted'] or process.stderr:
            raise RuntimeError('Valid CLI proof failed')
        cli.append({'case':'valid','optimized':optimize,'accepted':True})
        for name,text in [('malformed_json','{'),('wrong_root','null')]:
            p=Path(directory)/(name+'.json');p.write_text(text)
            process=subprocess.run([*args,str(p)],capture_output=True,text=True,timeout=20)
            if process.returncode!=1 or json.loads(process.stdout)['accepted'] or process.stderr:
                raise RuntimeError('Malformed CLI input not rejected correctly')
            cli.append({'case':name,'optimized':optimize,'accepted':False})

counts={}
for node in nodes(certificate):
    if node.get('rule')=='axiom':counts[node['name']]=counts.get(node['name'],0)+1
receipt={'python':platform.python_version(),'positive':positive,
         'arithmetic_axiom_occurrences':dict(sorted(counts.items())),
         'negative_control_count':len(rows),'negative_controls':rows,'cli_checks':cli,
         'sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
                   for name in ['shared_nd.py','closed_terms.py','finite_compute.py','replay.py','produce.py','certificate.json','validate.py']},
         'scope':'Symbolic ND proof of source calibration with two concrete closed-term endpoint reductions. Finite malformed controls test enforcement; no variable-input semantic oracle, induction oracle, or complete metatheory verification is claimed.'}
(ROOT/'validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'accepted':True,'exported_theorems':len(positive['claims']),
                  'proof_nodes':positive['proof_nodes'],'negative_controls':len(rows),
                  'CLI_checks':len(cli),'arithmetic_axiom_occurrences':counts},indent=2))
