PLAIN RAW-RESET CLOCK CALIBRATION CERTIFICATE
============================================

Result
------
Seven closed claims replay successfully in 952 proof nodes. There are exactly
TWO applications of the proposed raw anchored-reset rule: one proves restricted
reflection; the other is the fully expanded Boolean-valued induction argument
for the clock defect. No Boolean-induction acceptance rule is implemented.

Run with Python 3.10 or newer:
  python3 produce.py
  python3 replay.py
  python3 validate.py

The producer does not import the replayer. The replayer independently checks
each logical/equality step, reconstructs every raw-reset occurrence from its
literal template, and permits only previously checked closed theorems. The
seven exported targets and their dependency order are fixed in the replayer.

The 22 deliberate corruptions are rejected. Six command-line checks cover the
valid certificate and malformed inputs, in normal and optimized Python. Exact
results, arithmetic-rule occurrences, and source hashes are in validation.json.

Exact arithmetic profile
------------------------
Terms have 0, S, M, A, T, w, and variables. Here
  M(n,a) = I_0(n,a),
  A(n,a) = I_S(n,a),
  T(n,a) = I_Z(n,a),
  1 = S0,
  Z(n) = M(n,1),
  w(a,b) = the fixed finite closed-iteration term L(a,b).

The declared computation schemas are
  M(0,a)=a; M(Sn,a)=0;
  A(0,a)=a; A(Sn,a)=S(A(n,a));
  T(0,a)=a; T(Sn,a)=Z(T(n,a));
and BR: Z(n)=0 or Z(n)=1.

The exact comparison abbreviation is
  ell(a,b) = Z(w(a,b)),
  epsilon(a,b) = T(ell(a,b),ell(b,a)).
The clock is c(a)=A(a,0).
All these abbreviations are expanded in the symbolic certificate. In
particular the former d(a,b)=M(epsilon(c(b),b),epsilon(a,b)) never occurs
in the replayer's reset rule. The copied declaration table retains d only
because it is an UNCHANGED attributed source artifact; no proof or endpoint
computation uses that declaration.

Finite endpoint verification
----------------------------
The certificate's two closed_compute nodes have no user-supplied output.
The replayer evaluates the fixed declaration L at arguments (1,0) and (0,1),
then reconstructs the resulting literal equality. Those arguments give 0 and 1,
respectively; congruence and the explicit M/T computation rules prove
  epsilon(1,0)=1.

finite_compute.py uses the unchanged staged declaration table and validator
in closed_terms.py. It interprets only zero, successor, variable, acyclic
macro calls, and I_h iteration. It performs EVERY iterator-successor step.
It does NOT use the inherited evaluator's successor acceleration or exact
cycle skipping. Memoization only reuses already evaluated identical closed
macro applications. Each of the two endpoints needs five iterator-successor
steps. The endpoint profile permits only literal zero/one inputs, validates
all arities and closed updates, and limits evaluation steps.

This is finite normalization using the declared equations, not an axiom that
the detector decides arbitrary equality. In particular no variable-input
computation, numerical truth oracle, clock identity, separation, predecessor,
coverage, or induction theorem is accepted by this operation. The full
comparator theorem for arbitrary inputs remains a mathematical argument in
the report and inherited reference, outside this certificate's scope.

Exact anchored-reset rule
-------------------------
For the same fixed template f(x,p) at all occurrences, define
  anchor = f(1,p),
  reset(z) = M(epsilon(f(z,p),anchor),Sz).
From a proof under Gamma of f(reset(z),p)=anchor, infer f(t,p)=anchor.
The eigenvariable z must be distinct from x and absent from every retained
assumption, the target t, and every fixed template parameter. No independently
supplied anchor is permitted. The checker reconstructs the reset and premise;
changing the guard, target, template, anchor interface, or freshness fails.

Seven checked claims
--------------------
1. raw_range: epsilon(a,b)=0 or epsilon(a,b)=1.
2. raw_diagonal: epsilon(a,a)=0.
3. raw_endpoint: epsilon(1,0)=1.
4. restricted_reflection: epsilon(c(a),b)=0 implies c(a)=b.
5. clock_defect: epsilon(c(a),a)=0.
6. clock_identity: c(a)=a.
7. full_reflection: epsilon(a,b)=0 iff a=b.

The restricted reflection proof uses the defective ramp
  F_ab(y)=A(M(Z(Z(y)),a),M(Z(Z(Z(y))),b)),
whose finite endpoints are c(a), b, b at 0, Sy, 1 respectively. The proof
uses raw reflexivity but no clock identity.

The clock-defect proof uses f(x)=epsilon(c(x),x). Its values are Boolean by
claim 1; its values at 0 and 1 are zero by computation and claim 2. In the
zero case f(z)=0, claim 4 gives c(z)=z, the A successor equation gives
c(Sz)=Sz, and claim 2 proves f(Sz)=0. The epsilon(0,0) reset advances.
In the one case, claim 3 makes the reset zero, whose f-value is zero.
These cases prove the EXACT raw-reset premise. The second AR application
gives claim 5; it is not replaced by a trusted induction macro.

Scope
-----
This is a verification of the source-calibration fragment relative to the
explicit arithmetic and raw-reset profile. It is not a complete iPRA proof
checker and is not a candidate in the 309/344/864 complete-source comparison.
It does not mechanically certify the target-side arbitrary-input comparator
proof, the PR-function compiler, the full logical reconstruction, or the
bi-interpretability metatheorem. Those obligations are stated and proved in
the report with attributed inherited dependencies.

Attribution
-----------
Sources were copied from VladimirReshetnikov/ProveIt, repository snapshot
  e707d8bd1bcbc036631663e7538efd8b42b1e130,
archive
  docs/drafts/ipra_two_diagonal_2026-11-09.zip,
Git blob SHA-1
  bb76dd235a79e69c9b44521d56072be1c5be8565.
The source archive's own report refers to snapshot
  89fd4b4c5cd158259b1f2846f63e3d98f053553c.

shared_nd.py and closed_terms.py are unchanged copies of the corresponding
source files. Their SHA-256 hashes and complete source paths are recorded in
provenance.json. The inherited engine itself came from the reconstructed
anchored-reset report, as documented in its original header. Its license is
retained as LICENSE-inherited.txt.

replay.py, produce.py and validate.py are adapted from the source archive's
calibration wrapper, untrusted producer, and corruption controls. The new
plain-reset theorem sequence, explicit defect-induction proof, literal finite
endpoint interpreter, and new negative controls are the present additions.
