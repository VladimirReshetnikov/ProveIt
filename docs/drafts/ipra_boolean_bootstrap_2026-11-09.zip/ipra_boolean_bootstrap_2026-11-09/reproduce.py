"""Regenerate and check the delivered evidence, without network access."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parent
    calibration = root / 'code/calibration'
    commands = [
        ('produce_certificate', [sys.executable, 'produce.py'], calibration),
        ('replay_certificate', [sys.executable, 'replay.py'], calibration),
        ('negative_and_cli_controls', [sys.executable, 'validate.py'], calibration),
        ('matched_measurements', [sys.executable, 'code/measure.py'], root),
    ]
    results = []
    for name, command, directory in commands:
        completed = subprocess.run(command, cwd=directory, text=True,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, check=False)
        row = {'name': name, 'exit_code': completed.returncode}
        if completed.returncode:
            row['stdout'] = completed.stdout
            row['stderr'] = completed.stderr
            results.append(row)
            print(json.dumps({'passed': False, 'steps': results}, indent=2))
            return 1
        try:
            row['result'] = json.loads(completed.stdout)
        except json.JSONDecodeError:
            row['stdout'] = completed.stdout
        results.append(row)
    evidence = root / 'evidence'
    evidence.mkdir(exist_ok=True)
    certificate = calibration / 'certificate.json'
    receipt = {'passed': True, 'python': platform.python_version(),
               'certificate_sha256': hashlib.sha256(certificate.read_bytes()).hexdigest(),
               'steps': results,
               'scope': 'Source-calibration replay, corruptions, CLI, and sizes. '
                        'No claim of complete formalization of bi-interpretability.'}
    (evidence / 'reproduction.json').write_text(json.dumps(receipt, indent=2) + '\n')
    validation = json.loads((calibration / 'validation.json').read_text())
    print(json.dumps({'passed': True, 'python': platform.python_version(),
                      'proof_nodes': validation['positive']['proof_nodes'],
                      'claims': len(validation['positive']['claims']),
                      'receipt': 'evidence/reproduction.json'}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
