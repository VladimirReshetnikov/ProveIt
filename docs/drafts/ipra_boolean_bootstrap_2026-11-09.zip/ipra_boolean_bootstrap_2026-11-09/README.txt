BOOLEAN INDUCTION CALIBRATES THE CLOCK
9 November 2026
=====================================

Result
------
The clock-related second-diagonal mask in the current closed-unary-iteration
reset proposal can be removed. Boolean-valued zero induction is derivable
before general reflection; applied to epsilon(I_S(n,0),n), it proves the
clock identity. Restricted reflection then becomes actual equality
reflection. The full theory is equiconsistent and whole-domain
bi-interpretable with intuitionistic primitive recursive arithmetic.

This is a proved local mathematical simplification. The requested complete
checker below the existing 309-token /344-AST-node /864-byte corpus frontier
has NOT been obtained. The manuscript states this qualification explicitly.

Start here
----------
ipra_boolean_bootstrap.pdf       New report, including all axioms and rules,
                                proofs, comparison, and further questions.
ipra_boolean_bootstrap.tex       Its standalone editable LaTeX source.

code/calibration/               New explicit symbolic certificate and replayer.
code/measure.py                 Matched term and frozen whole-source measures.
evidence/                       Pinned sources, replay receipts, audits, metrics.
reference/closed_equational/    Inherited complete internal arithmetic compiler
                                proof and original compiled report.
reference/frontier_kernel/      Unchanged existing complete-checker comparator.

The new report also proves a boundary theorem: shifted initialization with
the analogous plain reset admits a model where every compound operation
erases an extra coordinate. Noninjective successor and a nontrivial
finite-order automorphism rule out ordinary full bi-interpretability with
iPRA. This is not a counterexample to the stronger existing shifted theory
with genuine equation induction.

Reproduce
---------
  python3 reproduce.py
  python3 build.py

The evidence needs only Python's standard library and no network. The PDF
build needs a complete pdfLaTeX installation with the standard packages
named at the beginning of the source. It uses shell escape disabled.

The certificate verifies 7 closed source-calibration claims in 952 proof
nodes, with exactly 2 applications of the new raw rule. It accepts no
Boolean-induction, reflection, or clock-identity oracle. The two concrete
comparator endpoints are computed from the fixed declarations by literal
primitive iteration. There are 22 rejected corruptions and 6 CLI checks.

The full target comparator theorem, PR compiler, general proof-translation
metatheorems, and bi-interpretation composites are manuscript proofs with
explicit inherited dependencies. The replayer is not a complete iPRA
checker or a Lean/Rocq verification of the entire result.

The expanded fixed guard shrinks from 374 to 182 numerical tree nodes;
the corresponding reset from 378 to 186 on unit-size arguments. These
counts are not complete-checker source sizes. Full expansion of an anchor
b saves exactly 188+4|b| nodes; shared-DAG costs differ.

Source snapshot and attribution
-------------------------------
VladimirReshetnikov/ProveIt
commit e707d8bd1bcbc036631663e7538efd8b42b1e130
https://github.com/VladimirReshetnikov/ProveIt/tree/e707d8bd1bcbc036631663e7538efd8b42b1e130/docs/drafts

All 11 current archive identities are in evidence/source_manifest.json.
The raw comparator, defective ramp, internal closed-iterator compiler,
logical engine, and old complete kernel are inherited, with exact
attribution and original licenses retained. The new contribution is the
Boolean-induction clock bootstrap, its plain-rule certificate, and the
shifted-reset countermodel. No repository changes were made.

See ATTRIBUTION.txt for copied source identities and SHA256SUMS for package
integrity. The checksums exclude SHA256SUMS itself and transient TeX files.
