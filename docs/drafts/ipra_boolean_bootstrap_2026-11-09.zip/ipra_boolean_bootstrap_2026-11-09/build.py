"""Build the main standalone report with an installed pdfLaTeX distribution."""
from pathlib import Path
import subprocess


root = Path(__file__).resolve().parent
logs = []
for pass_number in (1, 2, 3):
    result = subprocess.run(
        ['pdflatex', '-no-shell-escape', '-interaction=nonstopmode',
         '-halt-on-error', 'ipra_boolean_bootstrap.tex'],
        cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        check=False)
    logs.append(f'PASS {pass_number}\n{result.stdout}')
    if result.returncode:
        (root / 'evidence/build.log').write_text('\n'.join(logs))
        raise SystemExit(result.stdout)
(root / 'evidence/build.log').write_text('\n'.join(logs))
print(root / 'ipra_boolean_bootstrap.pdf')
