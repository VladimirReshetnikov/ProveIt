"""Rebuild the supplied LaTeX report; requires pdflatex on PATH."""

from pathlib import Path
import shutil
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parent


def main():
    executable = shutil.which("pdflatex")
    if executable is None:
        raise SystemExit("Install a TeX distribution providing pdflatex first.")
    artifacts = ROOT / "artifacts"
    artifacts.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="ipra_latex_") as directory:
        build = Path(directory)
        shutil.copyfile(ROOT / "report.tex", build / "report.tex")
        shutil.copytree(ROOT / "sections", build / "sections")
        for number in range(1, 4):
            result = subprocess.run(
                [executable, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                cwd=build, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            )
            (artifacts / f"latex_pass_{number}.txt").write_bytes(result.stdout)
            if result.returncode:
                raise SystemExit(result.stdout.decode("utf-8", errors="replace"))
        pdf = (build / "report.pdf").read_bytes()
        (ROOT / "report.pdf").write_bytes(pdf)
        (artifacts / "latex_final.log").write_bytes((build / "report.log").read_bytes())
    print(f"{ROOT / 'report.pdf'} ({len(pdf)} bytes)")


if __name__ == "__main__":
    main()
