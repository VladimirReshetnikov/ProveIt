"""Independent CLI audit of finite rows: real proofs, false-inference attacks,
and syntax attacks. Runs normally and with -O; no assert-based test gates.
"""

import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from make_attacks import attacks
from make_rows_examples import translate


ROOT = Path(__file__).resolve().parent
ZERO = ["0"]
ONE = ["s", ZERO]
FALSE = ["E", None]
TRUE = ["E", None, ["row"]]


def v(name):
    return ["v", name]


def eq(left, right):
    return ["eq", left, right]


def row_formula(name, rows):
    return ["E", name, *[["row", *row] for row in rows]]


def data(goal, proof, context=None, functions=None):
    return {"functions": [] if functions is None else functions,
            "context": [] if context is None else context,
            "conclusion": goal, "proof": proof}


def cases():
    out = []

    def add(name, problem, wanted):
        out.append((name, problem, wanted))

    reflexive = eq(ZERO, ZERO)
    true_proof = ["E_intro", ZERO, 0, []]
    add("unquantified_empty_row", data(TRUE, true_proof), True)
    add("quantified_empty_row", data(row_formula(0, [[]]),
        ["E_intro", ONE, 0, []]), True)
    add("several_empty_alternatives", data(row_formula(None, [[], [], []]),
        ["E_intro", ZERO, 2, []]), True)
    alternatives = row_formula(None, [[], [], []])
    add("all_empty_branches_checked", data(reflexive,
        ["E_elim", alternatives, 10, ["E_intro", ZERO, 0, []],
         [["refl"], ["refl"], ["refl"]]]), True)

    # An empty conjunction is true, so eliminating it cannot produce false.
    add("empty_row_does_not_explode", data(FALSE,
        ["E_elim", TRUE, 10, true_proof, [["hyp"]]]), False)
    mixed = row_formula(None, [[], [FALSE]])
    add("empty_branch_cannot_be_omitted", data(FALSE,
        ["E_elim", mixed, 10, ["E_intro", ZERO, 0, []], [["hyp"]]]), False)
    add("empty_branch_cannot_use_other_row", data(FALSE,
        ["E_elim", mixed, 10, ["E_intro", ZERO, 0, []],
         [["hyp"], ["hyp"]]]), False)
    add("empty_alternatives_need_major_premise", data(eq(ZERO, ONE),
        ["E_elim", FALSE, 10, ["hyp"], []]), False)
    add("empty_alternatives_retain_major_premise", data(eq(ZERO, ONE),
        ["E_elim", FALSE, 10, ["hyp"], []], [FALSE]), True)

    # Capture would turn the valid forall x exists y x=y into the false
    # exists y S(y)=y. This certificate has no assumptions.
    existence = row_formula(1, [[eq(v(0), v(1))]])
    universal = ["U", 0, reflexive, existence]
    universal_proof = ["U_intro", 10, ["E_intro", v(10), 0, [["refl"]]]]
    captured = row_formula(1, [[eq(["s", v(1)], v(1))]])
    add("capture_would_create_successor_fixed_point", data(captured,
        ["U_elim", universal, ["s", v(1)], universal_proof, ["refl"]]), False)

    existence_zero = row_formula(0, [[eq(v(0), ZERO)]])
    add("existential_witness_cannot_escape", data(eq(v(1), ZERO),
        ["E_elim", existence_zero, 1,
         ["E_intro", ZERO, 0, [["refl"]]], [["hyp"]]]), False)

    nested = row_formula(0, [[row_formula(1, [[eq(v(1), ["s", v(0)])]])]])
    nested_proof = ["E_intro", ZERO, 0,
                    [["E_intro", ONE, 0, [["refl"]]]]]
    bad_fixed_point = row_formula(1, [[eq(v(1), ["s", v(1)])]])
    add("elimination_capture_would_create_fixed_point", data(bad_fixed_point,
        ["E_elim", nested, 1, nested_proof, [["hyp"]]]), False)

    add("generalization_cannot_capture_free_goal_parameter", data(
        ["U", 0, reflexive, eq(v(1), v(0))],
        ["U_intro", 1, ["refl"]]), False)
    add("generalization_cannot_use_retained_number_fact", data(
        ["U", 0, reflexive, eq(v(0), ZERO)],
        ["U_intro", 1, ["hyp"]], [eq(v(1), ZERO)]), False)

    # A free parameter in a later alternative must participate in freshness.
    later_parameter = row_formula(0, [[eq(v(0), ZERO)], [eq(v(1), ZERO)]])
    add("later_row_free_parameter_is_not_fresh", data(reflexive,
        ["E_elim", later_parameter, 1, ["hyp"], [["refl"], ["refl"]]],
        [later_parameter]), False)
    deep_context = row_formula(None, [[row_formula(None, [[eq(v(9), ZERO)]])]])
    add("nested_context_free_parameter_is_not_fresh", data(reflexive,
        ["E_elim", TRUE, 9, true_proof, [["refl"]]], [deep_context]), False)

    # None is genuinely no binder: free numerical names are still replaced.
    body = row_formula(None, [[eq(v(2), ZERO)]])
    before = row_formula(None, [[eq(v(0), ZERO)]])
    after = row_formula(None, [[eq(v(1), ZERO)]])
    add("none_binder_preserves_free_variable_substitution", data(after,
        ["replace", eq(v(0), v(1)), 2, body, ["hyp"], ["hyp"]],
        [eq(v(0), v(1)), before]), True)

    shadowed = row_formula(0, [[["U", 0, reflexive, eq(v(0), v(0))],
                               eq(v(0), ZERO)]])
    add("nested_same_name_shadows_outer_witness", data(shadowed,
        ["E_intro", ZERO, 0, [["U_intro", 10, ["refl"]], ["refl"]]]), True)
    unselected = row_formula(0, [[eq(v(0), v(0))],
                                [["U", 1, reflexive, eq(v(0), v(1))]]])
    add("unselected_row_needs_no_capture_substitution", data(unselected,
        ["E_intro", v(1), 0, [["refl"]]]), True)
    add("selected_row_capture_is_rejected", data(unselected,
        ["E_intro", v(1), 1, [["U_intro", 10, ["refl"]]]]), False)

    two_premises = row_formula(None, [[reflexive, eq(ZERO, ONE)]])
    add("missing_false_row_member", data(two_premises,
        ["E_intro", ZERO, 0, [["refl"]]]), False)
    add("extra_empty_row_premise", data(TRUE,
        ["E_intro", ZERO, 0, [["refl"]]]), False)
    add("wrong_row_member_proof", data(two_premises,
        ["E_intro", ZERO, 0, [["refl"], ["refl"]]]), False)
    add("extra_false_elimination_branch", data(reflexive,
        ["E_elim", FALSE, 10, ["hyp"], [["refl"]]], [FALSE]), False)

    for name, side in (("negative", -1), ("boolean", True),
                       ("null", None), ("out_of_range", 1)):
        add("bad_row_index_" + name, data(TRUE,
            ["E_intro", ZERO, side, []]), False)
    add("false_has_no_selectable_row", data(FALSE,
        ["E_intro", ZERO, 0, []]), False)
    add("vacuous_witness_is_still_validated", data(TRUE,
        ["E_intro", ["r", -1, ZERO, ZERO], 0, []]), False)
    add("branch_list_is_required", data(reflexive,
        ["E_elim", TRUE, 10, true_proof, {}]), False)
    add("premise_list_is_required", data(TRUE,
        ["E_intro", ZERO, 0, {}]), False)
    add("boolean_eigenvariable", data(reflexive,
        ["E_elim", TRUE, True, true_proof, [["refl"]]]), False)

    for index, malformed in enumerate((
        ["E"], ["E", True], ["E", -1], ["E", "none"],
        ["E", None, []], ["E", None, ["row", ["false"]]],
        ["E", None, ["not_row", reflexive]], ["row", reflexive],
        ["false"], ["or", reflexive, reflexive],
    )):
        add("malformed_row_formula_" + str(index),
            data(malformed, ["hyp"], [malformed]), False)

    # C may not mistake a fused singleton row for the required equation.
    wrapped_equation = row_formula(None, [[reflexive]])
    conclusion = row_formula(None, [[reflexive], [wrapped_equation]])
    add("C_requires_literal_equation", data(conclusion,
        ["induct", 0, wrapped_equation, ZERO,
         ["E_intro", ZERO, 0, [["refl"]]]]), False)

    two = ["s", ONE]
    bad_C = row_formula(None, [[eq(two, ZERO)], [eq(two, ONE)]])
    add("C_cannot_generalize_retained_successor_fact", data(bad_C,
        ["induct", 0, eq(v(0), ONE), two, ["hyp"]],
        [eq(["s", v(0)], ONE)]), False)

    # A topological declaration may not capture a numerical environment.
    add("undeclared_descriptor_environment", data(reflexive, ["refl"],
        functions=[{"parameters": 0, "body": v(2)}]), False)
    add("cyclic_definition", data(reflexive, ["refl"],
        functions=[{"parameters": 0, "body": ["r", 0, v(1), v(0)]}]), False)
    add("boolean_function_index", data(eq(["r", False, ZERO, ZERO], ZERO),
        ["compute"], functions=[{"parameters": 0, "body": v(1)}]), False)
    return out


def execute(problem, optimized):
    command = [sys.executable] + (["-O"] if optimized else []) + [str(ROOT / "rows_kernel.py")]
    completed = subprocess.run(command, input=json.dumps(problem), text=True,
                               capture_output=True, timeout=15, cwd=ROOT)
    return completed.returncode, json.loads(completed.stdout), completed.stderr


def main():
    records = []
    supplied = [(p.name, json.loads(p.read_text()), True)
                for p in sorted((ROOT / "examples").glob("rows_*.json"))]
    if len(supplied) != 18:
        raise RuntimeError("Expected the 18 translated proof fixtures")
    independent = cases()
    transferred, excluded = [], []
    for name, (problem, reason) in attacks(True).items():
        try:
            converted = translate(problem)
            # Preserve extra record fields, which are themselves parser attacks.
            converted.update({key: value for key, value in problem.items()
                              if key not in converted})
        except ValueError:
            excluded.append({"name": name, "reason": "Malformed source syntax is outside the translator domain."})
            continue
        transferred.append(("transferred_" + name, converted, False))
    for optimized in (False, True):
        for name, problem, wanted in supplied + independent + transferred:
            code, result, stderr = execute(problem, optimized)
            if code != (0 if wanted else 1) or result != {"accepted": wanted} or stderr:
                raise RuntimeError((name, optimized, wanted, code, result, stderr))
            records.append({"name": name, "optimized": optimized,
                            "expected_accept": wanted, "passed": True})

    def functions(path):
        tree = ast.parse(path.read_text())
        return {node.name: ast.dump(node, include_attributes=False)
                for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}

    old, new = functions(ROOT / "common.py"), functions(ROOT / "rows_common.py")
    unchanged = {}
    for name in ("require", "natural", "__init__", "term", "free",
                 "substitute", "fresh", "plug", "computation", "run"):
        unchanged[name] = old[name] == new[name]
        if not unchanged[name]:
            raise RuntimeError("Unexpected numerical/infrastructure change: " + name)

    result = {
        "status": "all passed", "python": sys.version.split()[0],
        "translated_positive_fixtures": len(supplied),
        "independent_cases": len(independent),
        "independent_positive_cases": sum(wanted for _, _, wanted in independent),
        "independent_negative_cases": sum(not wanted for _, _, wanted in independent),
        "transferred_candidate_attack_cases": len(transferred),
        "untranslatable_source_attacks": excluded,
        "cli_invocations": len(records), "normal_and_optimized_python": True,
        "identical_inherited_method_asts": unchanged,
        "source_sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                          for name in ("rows_common.py", "rows_kernel.py")},
        "scope": "Independent finite audit and source review, not a formal soundness proof.",
        "results": records,
    }
    (ROOT / "row_independent_audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "results"}, indent=2))


if __name__ == "__main__":
    main()
