"""Executable certificate and adversarial checks for the row calculus.

This tests implementation behavior; the report proves the unbounded
mathematical equivalence. No finite test collection certifies soundness.
"""

from copy import deepcopy
import json
from pathlib import Path

from rows_common import ZERO, ONE, FALSE
from make_examples import candidate_examples, problem, equation, variable
from make_examples import symmetric, transitive
from make_rows_examples import translate
from rows_kernel import Kernel


def accepted(data):
    try:
        checker = Kernel(data["functions"])
        for item in data["context"]:
            checker.formula(item)
        checker.check(data["proof"], data["context"], data["conclusion"])
        return True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OverflowError):
        return False


def main():
    records = []

    def test(name, data, expected):
        result = accepted(data)
        assert result == expected, (name, result, expected)
        records.append({"name": name, "expected": expected, "accepted": result})

    for name, data in candidate_examples().items():
        test("translated_" + name, translate(data), True)

    reflexive = equation(ZERO, ZERO)
    empty_row = ["E", None, ["row"]]
    triple = ["E", None, ["row", reflexive, reflexive, reflexive]]
    test("empty_row_truth", problem(empty_row, ["E_intro", ZERO, 0, []]), True)
    test("three_member_row", problem(triple,
         ["E_intro", ZERO, 0, [["refl"], ["refl"], ["refl"]]]), True)
    test("quantified_empty_row", problem(["E", 5, ["row"]],
         ["E_intro", ONE, 0, []]), True)

    a, b, witness = variable(0), variable(1), variable(30)
    existential = ["E", 10,
                   ["row", equation(variable(10), a), equation(variable(10), b)],
                   ["row", equation(a, b)], ["row", equation(b, a)]]
    first = transitive(a, witness, b,
                       symmetric(witness, a, ["hyp"]), ["hyp"])
    branches = [first, ["hyp"], symmetric(b, a, ["hyp"])]
    data = problem(equation(a, b),
                   ["E_elim", existential, 30, ["hyp"], branches], [existential])
    test("three_unequal_dependent_rows", data, True)

    malformed = deepcopy(data)
    malformed["proof"][-1].pop()
    test("missing_elimination_branch", malformed, False)
    malformed = deepcopy(data)
    malformed["proof"][-1].append(["refl"])
    test("extra_elimination_branch", malformed, False)
    malformed = deepcopy(data)
    malformed["proof"][2] = 0
    test("escaping_eigenvariable", malformed, False)

    for side in (-1, 1, True, None, "0"):
        test("invalid_row_index_" + repr(side),
             problem(empty_row, ["E_intro", ZERO, side, []]), False)
    test("falsity_has_no_row", problem(FALSE, ["E_intro", ZERO, 0, []]), False)
    test("missing_row_premise", problem(triple,
         ["E_intro", ZERO, 0, [["refl"], ["refl"]]]), False)
    test("extra_row_premise", problem(empty_row,
         ["E_intro", ZERO, 0, [["refl"]]]), False)
    test("nonlist_premises", problem(empty_row,
         ["E_intro", ZERO, 0, {}]), False)
    test("unvalidated_vacuous_witness", problem(empty_row,
         ["E_intro", ["v", True], 0, []]), False)

    for malformed in (["E"], ["E", True], ["E", -1],
                      ["E", None, []], ["E", None, ["not_row"]],
                      ["E", None, ["row", ["false"]]], ["row", reflexive]):
        test("malformed_formula_" + repr(malformed), problem(malformed, ["hyp"],
             [malformed]), False)

    arbitrary = ["U", 5, reflexive, ["E", 6, ["row", equation(variable(6), ZERO)]]]
    test("genuine_false_elimination", problem(arbitrary,
         ["E_elim", FALSE, 40, ["hyp"], []], [FALSE]), True)
    test("false_elimination_extra_branch", problem(arbitrary,
         ["E_elim", FALSE, 40, ["hyp"], [["refl"]]], [FALSE]), False)
    test("false_elimination_without_false", problem(arbitrary,
         ["E_elim", FALSE, 40, ["hyp"], []]), False)

    capture = ["E", 10, ["row", ["U", 30, reflexive,
                equation(variable(10), variable(30))]]]
    test("witness_capture_rejected", problem(capture,
         ["E_intro", variable(30), 0, [["U_intro", 31, ["refl"]]]]), False)

    result = {"status": "passed", "count": len(records), "records": records,
              "scope": "Finite proof-certificate and malformed-input checks; not a formal soundness proof."}
    destination = Path(__file__).resolve().parent / "artifacts"
    destination.mkdir(exist_ok=True)
    (destination / "row_checks.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "passed", "count": len(records)}))


if __name__ == "__main__":
    main()
