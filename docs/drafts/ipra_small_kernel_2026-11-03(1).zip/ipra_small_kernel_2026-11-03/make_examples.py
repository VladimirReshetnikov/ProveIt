"""Untrusted certificate construction; only the two checkers are authoritative."""

import json
from pathlib import Path

from common import ZERO, ONE, FALSE


def variable(name):
    return ["v", name]


def successor(term):
    return ["s", term]


def equation(left, right):
    return ["eq", left, right]


def call(function, *arguments):
    return ["r", function, *arguments]


def truth():
    return equation(ZERO, ZERO)


def conjunction(left, right):
    return ["and", left, right]


def implication(left, right):
    return ["imp", left, right]


def disjunction(left, right):
    return ["or", left, right]


FUNCTIONS = [
    {"parameters": 0, "body": variable(1)},
    {"parameters": 1, "body": variable(2)},
    {"parameters": 0, "body": successor(variable(0))},
    {"parameters": 0, "body": call(0, variable(0), ZERO)},
]


def symmetric(left, right, proof):
    """Turn left=right into right=left by the primitive replacement rule."""
    slot = 900
    return ["replace", equation(left, right), slot,
            equation(variable(slot), left), proof, ["refl"]]


def transitive(first, middle, last, left, right):
    slot = 901
    return ["replace", equation(middle, last), slot,
            equation(first, variable(slot)), right, left]


def congruent(function, left, right, proof):
    slot = 902
    return ["replace", equation(left, right), slot,
            equation(function(left), function(variable(slot))), proof, ["refl"]]


def predecessor(term):
    return call(0, term, ZERO)


def zero_add(term):
    return call(2, term, ZERO)


def coverage(term):
    name = 50
    v = variable(name)
    invariant = equation(successor(predecessor(v)), v)
    step = congruent(successor, predecessor(successor(v)), v, ["compute"])
    formula = disjunction(equation(term, ZERO),
                          equation(successor(predecessor(term)), term))
    return formula, ["induct", name, invariant, term, step]


def zero_add_identity(term):
    """A genuine C proof of R_S(n,0)=n, including both zero branches."""
    name = 51
    v = variable(name)
    invariant = equation(zero_add(v), v)

    def at_zero(value):
        # From value=0, replace 0 by value in the base computation theorem.
        zero_to_value = symmetric(value, ZERO, ["hyp"])
        return ["replace", equation(ZERO, value), 903,
                equation(zero_add(variable(903)), variable(903)),
                zero_to_value, ["compute"]]

    def advance(value, induction_hypothesis):
        left = zero_add(successor(value))
        middle = successor(zero_add(value))
        right = successor(value)
        lifted = congruent(successor, zero_add(value), value,
                           induction_hypothesis)
        return transitive(left, middle, right, ["compute"], lifted)

    assumption = disjunction(equation(v, ZERO), invariant)
    step = ["or_elim", assumption, ["hyp"],
            advance(v, at_zero(v)), advance(v, ["hyp"])]
    rooted = ["induct", name, invariant, term, step]
    rooted_formula = disjunction(equation(term, ZERO),
                                 equation(zero_add(term), term))
    proof = ["or_elim", rooted_formula, rooted, at_zero(term), ["hyp"]]
    return equation(zero_add(term), term), proof


def successor_injective(left, right, equality):
    sl, sr = successor(left), successor(right)
    pl, pr = predecessor(sl), predecessor(sr)
    lifted = congruent(predecessor, sl, sr, equality)
    first = transitive(left, pl, pr,
                       symmetric(pl, left, ["compute"]), lifted)
    return transitive(left, pr, right, first, ["compute"])


def successor_contradiction(term):
    """From S(term)=0 derive the fixed equality 0=1 using Q only."""
    st = successor(term)
    ps, pz = predecessor(st), predecessor(ZERO)
    lifted = congruent(predecessor, st, ZERO, ["hyp"])
    first = transitive(term, ps, pz,
                       symmetric(ps, term, ["compute"]), lifted)
    term_zero = transitive(term, pz, ZERO, first, ["compute"])
    shifted = congruent(successor, term, ZERO, term_zero)
    return transitive(ZERO, st, ONE,
                      symmetric(st, ZERO, ["hyp"]), shifted)


def problem(formula, proof, context=None, functions=None):
    return {"functions": FUNCTIONS if functions is None else functions,
            "context": [] if context is None else context,
            "conclusion": formula, "proof": proof}


def candidate_examples():
    out = {}
    t = variable(20)
    a, b = equation(variable(0), ZERO), equation(variable(1), ZERO)
    out["reflexivity"] = problem(equation(t, t), ["refl"])
    out["symmetry"] = problem(equation(variable(1), variable(0)),
        symmetric(variable(0), variable(1), ["hyp"]),
        [equation(variable(0), variable(1))])
    out["transitivity"] = problem(equation(variable(0), variable(2)),
        transitive(variable(0), variable(1), variable(2), ["hyp"], ["hyp"]),
        [equation(variable(0), variable(1)), equation(variable(1), variable(2))])

    body, proof = coverage(t)
    out["coverage"] = problem(["U", 20, truth(), body],
                               ["U_intro", 20, proof])
    body, proof = zero_add_identity(t)
    out["zero_addition"] = problem(["U", 20, truth(), body],
                                    ["U_intro", 20, proof])

    x, y = variable(21), variable(22)
    premise = equation(successor(x), successor(y))
    conclusion = equation(x, y)
    out["successor_injective"] = problem(
        ["U", 21, truth(), ["U", 22, premise, conclusion]],
        ["U_intro", 21, ["U_intro", 22,
                         successor_injective(x, y, ["hyp"])]] )

    sep = ["U", 0, equation(ZERO, ONE), FALSE]
    contradiction = ["U_elim", sep, ZERO, ["separation"],
                     successor_contradiction(t)]
    out["successor_nonzero"] = problem(
        ["U", 20, equation(successor(t), ZERO), FALSE],
        ["U_intro", 20, contradiction])
    out["separation"] = problem(sep, ["separation"])

    pair = ["P", 100, a, b]
    swap = ["P", 101, b, a]
    out["pair_swap"] = problem(["U", 102, pair, swap],
        ["U_intro", 103, ["P_elim", pair, 104, ["hyp"],
                          ["P_intro", ZERO, ["hyp"], ["hyp"]]]])

    sums = disjunction(a, b)
    out["disjunction_swap"] = problem(
        ["U", 100, sums, disjunction(b, a)],
        ["U_intro", 101, ["or_elim", sums, ["hyp"],
            ["or_intro", 1, ["hyp"]], ["or_intro", 0, ["hyp"]]]])

    universal = ["U", 10, truth(), equation(variable(10), ZERO)]
    out["universal_instantiation"] = problem(equation(t, ZERO),
        ["U_elim", universal, t, ["hyp"], ["refl"]], [universal])

    existential = ["P", 10, equation(variable(10), variable(0)),
                    equation(variable(10), variable(1))]
    witness = variable(30)
    continuation = transitive(variable(0), witness, variable(1),
                              symmetric(witness, variable(0), ["hyp"]),
                              ["hyp"])
    out["dependent_pair_elimination"] = problem(
        equation(variable(0), variable(1)),
        ["P_elim", existential, 30, ["hyp"], continuation], [existential])
    out["existential_witness"] = problem(
        ["P", 10, truth(), equation(variable(10), t)],
        ["P_intro", t, ["refl"], ["refl"]])

    arbitrary = ["U", 10, equation(variable(10), variable(10)),
                  ["P", 11, a, b]]
    out["falsity_elimination"] = problem(
        ["U", 100, FALSE, arbitrary],
        ["U_intro", 101, ["false_elim", ["hyp"]]])

    out["parameter_computation"] = problem(
        equation(call(1, successor(t), variable(0), variable(1)), variable(1)),
        ["compute"])
    out["nested_update_computation"] = problem(
        equation(call(3, successor(t), variable(0)),
                 call(0, call(3, t, variable(0)), ZERO)), ["compute"])

    frozen_body = equation(call(3, variable(904), ZERO), call(3, t, ZERO))
    out["frozen_descriptor_replacement"] = problem(
        equation(call(3, variable(21), ZERO), call(3, t, ZERO)),
        ["replace", equation(t, variable(21)), 904, frozen_body,
         ["hyp"], ["refl"]], [equation(t, variable(21))])
    out["unused_and_duplicate_declarations"] = problem(
        equation(call(1, ZERO, t, variable(0), variable(1)), t), ["compute"],
        functions=[{"parameters": 2, "body": variable(0)},
                   {"parameters": 2, "body": variable(0)}])
    return out


def baseline_examples():
    out = {}
    common = candidate_examples()
    for name in ("reflexivity", "symmetry", "transitivity",
                 "parameter_computation", "nested_update_computation",
                 "frozen_descriptor_replacement", "unused_and_duplicate_declarations"):
        out[name] = common[name]
    t = variable(20)
    a, b = equation(variable(0), ZERO), equation(variable(1), ZERO)

    for name, constructor in (("coverage", coverage),
                              ("zero_addition", zero_add_identity)):
        body, proof = constructor(t)
        out[name] = problem(["all", 20, body], ["all_intro", 20, proof])

    x, y = variable(21), variable(22)
    premise = equation(successor(x), successor(y))
    out["successor_injective"] = problem(
        ["all", 21, ["all", 22, implication(premise, equation(x, y))]],
        ["all_intro", 21, ["all_intro", 22, ["imp_intro",
                            successor_injective(x, y, ["hyp"])]]])
    sep = implication(equation(ZERO, ONE), FALSE)
    out["successor_nonzero"] = problem(
        ["all", 20, implication(equation(successor(t), ZERO), FALSE)],
        ["all_intro", 20, ["imp_intro", ["imp_elim", equation(ZERO, ONE),
            ["separation"], successor_contradiction(t)]]])
    out["separation"] = problem(sep, ["separation"])

    pair = conjunction(a, b)
    out["pair_swap"] = problem(implication(pair, conjunction(b, a)),
        ["imp_intro", ["and_intro", ["and_elim", 1, pair, ["hyp"]],
                        ["and_elim", 0, pair, ["hyp"]]]])

    sums = disjunction(a, b)
    out["disjunction_swap"] = problem(implication(sums, disjunction(b, a)),
        ["imp_intro", ["or_elim", sums, ["hyp"],
            ["or_intro", 1, ["hyp"]], ["or_intro", 0, ["hyp"]]]])

    universal = ["all", 10, equation(variable(10), ZERO)]
    out["universal_instantiation"] = problem(equation(t, ZERO),
        ["all_elim", universal, t, ["hyp"]], [universal])

    body = conjunction(equation(variable(10), variable(0)),
                       equation(variable(10), variable(1)))
    existential = ["some", 10, body]
    witness = variable(30)
    instance = conjunction(equation(witness, variable(0)),
                           equation(witness, variable(1)))
    left = ["and_elim", 0, instance, ["hyp"]]
    right = ["and_elim", 1, instance, ["hyp"]]
    continuation = transitive(variable(0), witness, variable(1),
                              symmetric(witness, variable(0), left), right)
    out["dependent_pair_elimination"] = problem(
        equation(variable(0), variable(1)),
        ["some_elim", existential, 30, ["hyp"], continuation], [existential])
    out["existential_witness"] = problem(
        ["some", 10, equation(variable(10), t)], ["some_intro", t, ["refl"]])

    arbitrary = ["all", 10, implication(equation(variable(10), variable(10)),
                    ["some", 11, conjunction(a, b)])]
    out["falsity_elimination"] = problem(implication(FALSE, arbitrary),
                                        ["imp_intro", ["false_elim", ["hyp"]]])
    return out


def main():
    destination = Path(__file__).resolve().parent / "examples"
    destination.mkdir(exist_ok=True)
    for family, samples in (("candidate", candidate_examples()),
                            ("baseline", baseline_examples())):
        for name, data in samples.items():
            path = destination / (family + "_" + name + ".json")
            path.write_text(json.dumps(data, indent=2) + "\n")
    written = sum(path.name.startswith(("candidate_", "baseline_"))
                  for path in destination.glob("*.json"))
    print("Wrote", written, "candidate/baseline certificate fixtures")


if __name__ == "__main__":
    main()
