"""Untrusted translation of fused U/P certificates into the row calculus.

The arithmetic declarations are unchanged. None is a genuinely vacuous
positive binder, so translation commutes literally with named substitution.
"""

import json
from itertools import count
from pathlib import Path

from rows_common import ZERO, FALSE
from make_examples import candidate_examples


def formula(expression):
    match expression:
        case ["eq", _, _]:
            return expression
        case ["false"]:
            return FALSE
        case ["or", left, right]:
            return ["E", None, ["row", formula(left)], ["row", formula(right)]]
        case ["U", name, left, right]:
            return ["U", name, formula(left), formula(right)]
        case ["P", name, left, right]:
            return ["E", name, ["row", formula(left), formula(right)]]
        case _:
            raise ValueError("unknown formula constructor")


def proof(expression, fresh):
    match expression:
        case ["hyp"] | ["refl"] | ["compute"] | ["separation"]:
            return expression
        case ["replace", equation, name, body, equality, premise]:
            return ["replace", equation, name, formula(body),
                    proof(equality, fresh), proof(premise, fresh)]
        case ["induct", name, equation, target, premise]:
            return ["induct", name, equation, target, proof(premise, fresh)]
        case ["U_intro", name, premise]:
            return ["U_intro", name, proof(premise, fresh)]
        case ["U_elim", universal, term, premise, argument]:
            return ["U_elim", formula(universal), term,
                    proof(premise, fresh), proof(argument, fresh)]
        case ["P_intro", term, left, right]:
            return ["E_intro", term, 0, [proof(left, fresh), proof(right, fresh)]]
        case ["P_elim", existential, name, premise, continuation]:
            return ["E_elim", formula(existential), name,
                    proof(premise, fresh), [proof(continuation, fresh)]]
        case ["or_intro", side, premise]:
            return ["E_intro", ZERO, side, [proof(premise, fresh)]]
        case ["or_elim", disjunction, premise, left, right]:
            return ["E_elim", formula(disjunction), next(fresh),
                    proof(premise, fresh), [proof(left, fresh), proof(right, fresh)]]
        case ["false_elim", premise]:
            return ["E_elim", FALSE, next(fresh), proof(premise, fresh), []]
        case _:
            raise ValueError("unknown proof constructor")


def integer_names(value):
    if type(value) is int:
        yield value
    elif type(value) is list:
        for item in value:
            yield from integer_names(item)
    elif type(value) is dict:
        for item in value.values():
            yield from integer_names(item)


def translate(problem):
    fresh = count(max(integer_names(problem), default=-1) + 1)
    return {
        "functions": problem["functions"],
        "context": [formula(item) for item in problem["context"]],
        "conclusion": formula(problem["conclusion"]),
        "proof": proof(problem["proof"], fresh),
    }


def main():
    destination = Path(__file__).resolve().parent / "examples"
    destination.mkdir(exist_ok=True)
    for name, problem in candidate_examples().items():
        path = destination / ("rows_" + name + ".json")
        path.write_text(json.dumps(translate(problem), indent=2) + "\n")
    print("Wrote", len(list(destination.glob("rows_*.json"))), "row certificates")


if __name__ == "__main__":
    main()
