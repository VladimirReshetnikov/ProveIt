"""Replay real certificates and reject mathematical attacks under Python and -O.

This is executable evidence about these implementations, not a machine-checked
metatheorem proving kernel soundness or completeness.
"""

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

import make_examples
import make_attacks


ROOT = Path(__file__).resolve().parent


def invoke(module, payload, optimized):
    command = [sys.executable]
    if optimized:
        command.append("-O")
    command.append(str(ROOT / module))
    completed = subprocess.run(command, input=payload, text=True,
                               capture_output=True, timeout=15, cwd=ROOT)
    try:
        result = json.loads(completed.stdout)
    except ValueError as error:
        raise RuntimeError((command, completed.returncode,
                            completed.stdout, completed.stderr)) from error
    return completed.returncode, result, completed.stderr


def main():
    make_examples.main()
    make_attacks.main()
    records = []
    started = time.monotonic()
    for optimized in (False, True):
        for directory, expected in (("examples", True), ("negative_examples", False)):
            for path in sorted((ROOT / directory).glob("*.json")):
                if not path.name.startswith(("candidate_", "baseline_")):
                    continue
                module = "kernel.py" if path.name.startswith("candidate_") else "baseline.py"
                code, result, stderr = invoke(module, path.read_text(), optimized)
                wanted = 0 if expected else 1
                if code != wanted or result != {"accepted": expected} or stderr:
                    raise RuntimeError((path.name, optimized, code, result, stderr))
                records.append({"file": str(path.relative_to(ROOT)),
                                "optimized": optimized, "expected_accept": expected,
                                "passed": True})
        for module in ("kernel.py", "baseline.py"):
            for payload in ("not json", "null", "[]", "{", "42", "true"):
                code, result, stderr = invoke(module, payload, optimized)
                if code != 1 or result != {"accepted": False} or stderr:
                    raise RuntimeError((module, payload, optimized, code, result, stderr))
                records.append({"input": payload, "module": module,
                                "optimized": optimized, "expected_accept": False,
                                "passed": True})
    hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
              for name in ("common.py", "kernel.py", "baseline.py")}
    summary = {
        "status": "all passed", "python": sys.version.split()[0],
        "positive_fixtures": sum(p.name.startswith(("candidate_", "baseline_"))
                                 for p in (ROOT / "examples").glob("*.json")),
        "negative_fixtures": sum(p.name.startswith(("candidate_", "baseline_"))
                                 for p in (ROOT / "negative_examples").glob("*.json")),
        "cli_invocations": len(records),
        "normal_and_optimized_python": True,
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "trusted_source_sha256": hashes,
        "scope": "Finite regression evidence, not a formal soundness proof.",
        "results": records,
    }
    (ROOT / "test_results.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({key: value for key, value in summary.items() if key != "results"},
                     indent=2))


if __name__ == "__main__":
    main()
