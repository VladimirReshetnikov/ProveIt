"""Mathematical attack certificates and malformed inputs; all must reject."""

from copy import deepcopy
import json
from pathlib import Path

from make_examples import (
    FUNCTIONS, FALSE, ONE, ZERO, call, coverage, disjunction, equation,
    problem, successor, truth, variable,
)


def attacks(fused):
    out = {}

    def add(name, data, reason):
        out[name] = (data, reason)

    def all_formula(name, body):
        return ["U", name, truth(), body] if fused else ["all", name, body]

    def all_intro(name, proof):
        return ["U_intro" if fused else "all_intro", name, proof]

    def all_elim(formula, term, proof):
        return (["U_elim", formula, term, proof, ["refl"]] if fused else
                ["all_elim", formula, term, proof])

    def exists_formula(name, body):
        return ["P", name, truth(), body] if fused else ["some", name, body]

    def exists_intro(term, proof):
        return (["P_intro", term, ["refl"], proof] if fused else
                ["some_intro", term, proof])

    def exists_elim(formula, name, proof, continuation):
        return ["P_elim" if fused else "some_elim", formula, name,
                proof, continuation]

    # If capture were allowed, instantiate forall x exists y x=y with S(y)
    # to obtain the false sentence exists y S(y)=y.
    universal = all_formula(0, exists_formula(1, equation(variable(0), variable(1))))
    universal_proof = all_intro(10, exists_intro(variable(10), ["refl"]))
    captured = exists_formula(1, equation(successor(variable(1)), variable(1)))
    add("capture_false_fixed_point", problem(captured,
        all_elim(universal, successor(variable(1)), universal_proof)),
        "Capturing a witness binder would assert a successor fixed point.")

    # From the true existential exists x x=0, an escaping witness would
    # incorrectly yield the open theorem y=0.
    existential = exists_formula(0, equation(variable(0), ZERO))
    add("escaping_existential_witness", problem(equation(variable(1), ZERO),
        exists_elim(existential, 1, exists_intro(ZERO, ["refl"]), ["hyp"])),
        "The existential eigenvariable occurs freely in the conclusion.")

    add("universal_eigenvariable_in_context", problem(
        all_formula(0, equation(variable(0), ZERO)), all_intro(1, ["hyp"]),
        [equation(variable(1), ZERO)]),
        "A fact about one number does not prove that every number is zero.")
    add("universal_eigenvariable_in_goal", problem(
        all_formula(0, equation(variable(0), variable(1))),
        all_intro(1, ["refl"])),
        "The chosen eigenvariable is a free parameter of the conclusion.")
    free_existential = exists_formula(0, equation(variable(0), variable(1)))
    add("existential_eigenvariable_in_formula", problem(truth(),
        exists_elim(free_existential, 1, ["hyp"], ["refl"]),
        [free_existential]),
        "The chosen witness name already denotes a free existential parameter.")

    eq = equation(variable(0), variable(1))
    template = all_formula(1, equation(variable(2), variable(1)))
    before = all_formula(1, equation(variable(0), variable(1)))
    after = all_formula(1, equation(variable(1), variable(1)))
    add("equality_replacement_capture", problem(after,
        ["replace", eq, 2, template, ["hyp"], ["hyp"]], [eq, before]),
        "Equality substitution must not capture a free replacement variable.")

    # Without freshness of the retained context, C would turn S(x)=1,
    # which is satisfiable at x=0, into the false 2=0 or 2=1.
    two = successor(ONE)
    invariant = equation(variable(0), ONE)
    bad_conclusion = disjunction(equation(two, ZERO), equation(two, ONE))
    add("induction_eigenvariable_in_context", problem(bad_conclusion,
        ["induct", 0, invariant, two, ["hyp"]],
        [equation(successor(variable(0)), ONE)]),
        "A single retained successor fact cannot be generalized by C.")

    body, proof = coverage(variable(50))
    add("induction_variable_in_target", problem(body, proof),
        "The specified C rule requires its induction name to be fresh for target.")
    quantified = all_formula(0, equation(variable(0), variable(0)))
    add("induction_on_quantified_formula", problem(
        disjunction(equation(ZERO, ZERO), quantified),
        ["induct", 52, quantified, ZERO, all_intro(1, ["refl"])]),
        "The C invariant must be a single equation, never a quantified formula.")

    invariant = equation(call(0, successor(variable(52)), ZERO), variable(52))
    wrong = disjunction(equation(variable(20), ZERO),
                        equation(call(0, ONE, ZERO), ZERO))
    add("induction_wrong_target_instance", problem(wrong,
        ["induct", 52, invariant, variable(20), ["compute"]]),
        "The conclusion must contain the exact target instance of the invariant.")

    add("false_by_reflexivity", problem(FALSE, ["refl"]),
        "Reflexivity proves only literal identical-term equations.")
    add("zero_equals_one", problem(equation(ZERO, ONE), ["refl"]),
        "Distinct numeral terms cannot be reflexivity conclusions.")
    add("false_elimination_without_false", problem(equation(ZERO, ONE),
        ["false_elim", ["hyp"]]),
        "Explosion still requires an actual falsity derivation.")
    add("unknown_proof_tag", problem(truth(), ["oracle"]),
        "No unlisted theorem or semantic oracle is available.")
    add("proof_extra_field", problem(truth(), ["refl", "ignored"]),
        "Certificate shapes have exact lengths.")
    add("missing_hypothesis", problem(truth(), ["hyp"]),
        "Assumption leaves must belong to the retained context.")

    add("wrong_base_computation", problem(equation(call(0, ZERO, ONE), ZERO),
        ["compute"]), "Initialization returns the supplied initializer.")
    add("wrong_successor_computation", problem(equation(call(0, ONE, ZERO), ONE),
        ["compute"]), "The update slots must be instantiated exactly.")
    add("symbolic_counter_computation", problem(
        equation(call(0, variable(20), ZERO), ZERO), ["compute"]),
        "Computation accepts only a literal zero or successor counter.")
    add("negative_function_index", problem(
        equation(call(-1, ZERO, ZERO), ZERO), ["compute"]),
        "Negative indices must not access Python's last list element.")
    add("boolean_function_index", problem(
        equation(call(False, ZERO, ZERO), ZERO), ["compute"]),
        "JSON false is not the integer function index zero.")
    add("undeclared_function", problem(
        equation(call(len(FUNCTIONS), ZERO, ZERO), ZERO), ["compute"]),
        "Every function reference must name a validated declaration.")
    add("wrong_function_arity", problem(
        equation(call(1, ZERO, ZERO), ZERO), ["compute"]),
        "A selector needs its explicit parameter argument.")
    add("negative_variable", problem(equation(variable(-1), variable(-1)), ["refl"]),
        "Variable names are nonnegative integers.")
    add("boolean_variable", problem(equation(variable(True), variable(True)), ["refl"]),
        "JSON true is not a variable name.")
    add("boolean_or_side", problem(disjunction(truth(), FALSE),
        ["or_intro", False, ["refl"]]),
        "A Boolean value must not masquerade as an alternative index.")
    add("negative_or_side", problem(disjunction(FALSE, truth()),
        ["or_intro", -1, ["refl"]]),
        "Negative side indices are forbidden.")
    add("extra_formula_child", problem(["false", truth()], ["false_elim", ["hyp"]]),
        "Falsity is nullary.")
    add("boolean_binder", problem(all_formula(True, truth()), all_intro(1, ["refl"])),
        "Binder names must be integers, excluding Boolean values.")

    cyclic = [{"parameters": 0, "body": call(0, variable(1), variable(0))}]
    add("cyclic_declaration", problem(truth(), ["refl"], functions=cyclic),
        "A declaration may use only earlier functions.")
    forward = [{"parameters": 0, "body": call(1, variable(1), variable(0))},
               {"parameters": 0, "body": variable(0)}]
    add("forward_declaration", problem(truth(), ["refl"], functions=forward),
        "A later definition cannot certify an earlier declaration.")
    add("escaping_local_slot", problem(truth(), ["refl"],
        functions=[{"parameters": 0, "body": variable(2)}]),
        "An update cannot capture an undeclared environment variable.")
    add("negative_parameter_count", problem(truth(), ["refl"],
        functions=[{"parameters": -1, "body": ZERO}]),
        "Negative arities are invalid.")
    add("boolean_parameter_count", problem(truth(), ["refl"],
        functions=[{"parameters": False, "body": ZERO}]),
        "Boolean arities are invalid.")
    add("declaration_extra_metadata", problem(truth(), ["refl"],
        functions=[{"parameters": 0, "body": ZERO, "trusted": True}]),
        "Unknown metadata cannot install an unchecked declaration.")
    extra = problem(truth(), ["refl"])
    extra["approved"] = True
    add("problem_extra_field", extra, "The complete input record has exactly four fields.")
    malformed_context = problem(truth(), ["refl"], context=[["not_a_formula"]])
    add("unused_malformed_context", malformed_context,
        "Even unused assumptions must be validated.")
    return out


def main():
    root = Path(__file__).resolve().parent
    directory = root / "negative_examples"
    directory.mkdir(exist_ok=True)
    manifest = []
    for family, fused in (("candidate", True), ("baseline", False)):
        for name, (data, reason) in attacks(fused).items():
            path = directory / (family + "_" + name + ".json")
            path.write_text(json.dumps(data, indent=2) + "\n")
            manifest.append({"file": str(path.relative_to(root)), "reason": reason})
    (root / "negative_examples.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print("Wrote", len(manifest), "required-rejection fixtures")


if __name__ == "__main__":
    main()
