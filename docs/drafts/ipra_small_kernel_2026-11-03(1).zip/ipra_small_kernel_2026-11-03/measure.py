"""Reproducible implementation-relative source accounting; standard library only."""

import ast
import hashlib
import io
import json
from pathlib import Path
import tokenize


ROOT = Path(__file__).resolve().parent


def source_metrics(name):
    raw = (ROOT / name).read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    docstrings = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                first = node.body[0]
                docstrings.append(((first.lineno, first.col_offset),
                                   (first.end_lineno, first.end_col_offset)))
                node.body = node.body[1:]
    ignored = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
               tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}
    tokens = []
    for token in tokenize.generate_tokens(io.StringIO(source).readline):
        if token.type in ignored:
            continue
        if any(start <= token.start and token.end <= end for start, end in docstrings):
            continue
        tokens.append(token)
    nodes = list(ast.walk(tree))
    return {
        "file": name,
        "raw_utf8_bytes": len(raw),
        "lexical_tokens_without_comments_docstrings_layout": len(tokens),
        "token_spelling_utf8_bytes": sum(len(t.string.encode("utf-8")) for t in tokens),
        "ast_nodes_without_docstrings": len(nodes),
        "python_statements_without_docstrings": sum(isinstance(n, ast.stmt) for n in nodes),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


def main():
    files = {name: source_metrics(name) for name in
             ("common.py", "kernel.py", "baseline.py")}
    variants = {"fused_UP": ["common.py", "kernel.py"],
                "full_logic_baseline": ["common.py", "baseline.py"]}
    if (ROOT / "rows_common.py").is_file() and (ROOT / "rows_kernel.py").is_file():
        for name in ("rows_common.py", "rows_kernel.py"):
            files[name] = source_metrics(name)
        variants["finite_rows"] = ["rows_common.py", "rows_kernel.py"]
    numeric = [key for key, value in files["common.py"].items() if type(value) is int]
    totals = {}
    for variant, names in variants.items():
        totals[variant] = {"trusted_files": names}
        totals[variant].update({key: sum(files[name][key] for name in names) for key in numeric})
    savings = {key: totals["full_logic_baseline"][key] - totals["fused_UP"][key]
               for key in numeric}
    output = {
        "method": "Literal complete trusted Python source, shared module counted once per variant.",
        "fixed_external_runtime": "Python 3 interpreter and its standard json/sys modules.",
        "excluded": "Certificate builders, tests, examples, metrics, prose and build scripts.",
        "qualification": "These are implementation-relative sizes, not global lower bounds.",
        "files": files, "totals": totals, "fused_UP_saving_vs_full_logic": savings,
        "logical_rule_schemes": {"full_logic": 16, "fused_UP": 11},
        "logical_case_tags_in_variant_module": {"full_logic": 8, "fused_UP": 4},
        "shared_certificate_tags": 9,
    }
    if "finite_rows" in totals:
        output["finite_rows_saving"] = {
            key: totals["full_logic_baseline"][key] - totals["finite_rows"][key]
            for key in numeric}
        output["finite_rows_saving_vs_fused_UP"] = {
            key: totals["fused_UP"][key] - totals["finite_rows"][key]
            for key in numeric}
        output["finite_rows_saving_percent_vs_full_logic"] = {
            key: round(100 * output["finite_rows_saving"][key]
                       / totals["full_logic_baseline"][key], 6)
            for key in numeric}
        output["logical_rule_schemes"]["finite_rows"] = 7
        output["logical_case_tags_in_variant_module"]["finite_rows"] = 4
        output["shared_certificate_tags_by_variant"] = {
            "full_logic": 9, "fused_UP": 9, "finite_rows": 6}
        output["complete_certificate_tags_by_variant"] = {
            "full_logic": 17, "fused_UP": 13, "finite_rows": 10}
    (ROOT / "measurements.json").write_text(json.dumps(output, indent=2) + "\n")
    lines = ["TRUSTED SOURCE ACCOUNTING", "", output["qualification"], "",
             "file / variant | raw bytes | lexical tokens | token bytes | AST nodes | statements"]
    for name, data in {**files, **totals}.items():
        lines.append("{} | {} | {} | {} | {} | {}".format(name,
            data["raw_utf8_bytes"], data["lexical_tokens_without_comments_docstrings_layout"],
            data["token_spelling_utf8_bytes"], data["ast_nodes_without_docstrings"],
            data["python_statements_without_docstrings"]))
    lines.extend(["", "Fused U/P saving against the full-logic comparison:",
                  json.dumps(savings, indent=2)])
    if "finite_rows" in totals:
        lines.extend(["", "Finite-rows saving against the full-logic comparison:",
                      json.dumps(output["finite_rows_saving"], indent=2),
                      "", "Finite-rows saving against the fused U/P comparison:",
                      json.dumps(output["finite_rows_saving_vs_fused_UP"], indent=2)])
    lines.extend(["", output["method"],
                  "Fixed runtime: " + output["fixed_external_runtime"],
                  "Excluded: " + output["excluded"]])
    text = "\n".join(lines) + "\n"
    (ROOT / "measurements.txt").write_text(text)
    print(text)


if __name__ == "__main__":
    main()
