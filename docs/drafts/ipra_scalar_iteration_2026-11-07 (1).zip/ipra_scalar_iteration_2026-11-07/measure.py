"""Reproduce the complete-program frontier with the unchanged inherited metric."""
from pathlib import Path
import hashlib
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('source_measure', ROOT/'comparison/source_measure.py')
metric = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metric)
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def checked(item):
    row = metric.metrics(ROOT/item['local_path'])
    if row['sha256'] != item['sha256']:
        raise ValueError('Changed frozen comparator: '+item['local_path'])
    return item | row


def main():
    manifest = json.loads((ROOT/'comparison/manifest.json').read_text())
    root_rows = [checked(x) for x in manifest['programs']]
    inventory = json.loads((ROOT/'comparison/nested_inventory.json').read_text())
    expanded_rows = [checked(x) for x in inventory['unique']]
    envelope = {k:min(x[k] for x in root_rows) for k in KEYS}
    expanded = {k:min(x[k] for x in expanded_rows) for k in KEYS}
    core = {k:min(x['core'][k] for x in expanded_rows) for k in KEYS}
    candidate = metric.metrics(ROOT/'checker.py')
    baseline = metric.metrics(ROOT/'validation/baseline_419.py')
    assert expanded == envelope
    assert all(candidate[k] < envelope[k] for k in KEYS)
    assert all(candidate['core'][k] < core[k] for k in KEYS)
    result = dict(commit=manifest['commit'], python=platform.python_version(),
                  root_count=len(root_rows), expanded_count=len(expanded_rows),
                  expanded_occurrences=inventory['all_count'],
                  coordinatewise_minimum=envelope, core_coordinatewise_minimum=core,
                  candidate=candidate, combined_recursion_baseline=baseline,
                  improvement={k:envelope[k]-candidate[k] for k in KEYS},
                  metric_sha256=hashlib.sha256((ROOT/'comparison/source_measure.py').read_bytes()).hexdigest(),
                  programs=root_rows)
    (ROOT/'results/metrics.json').write_text(json.dumps(result,indent=2)+'\n')
    names = {'ipra_argument_opening_2026-11-07.zip':'Argument opening',
             'ipra_fused_binder_2026-11-07.zip':'Fused binder',
             'ipra_proof_clock_2026-11-07.zip':'Proof clock A',
             'ipra_proof_clock_2026-11-07_variant.zip':'Proof clock B',
             'ipra_successor_absorption_2026-11-07.zip':'Successor absorption',
             'ipra_verified_frontier_2026-11-07.zip':'Verified frontier'}
    lines=[r'\begin{tabular}{@{}lrrr@{}}',r'\toprule',r'Complete program & Tokens & AST nodes & Bytes\\',r'\midrule']
    for row in root_rows:
        label=names[row['archive']]+' / '+row['file'].replace('_',r'\_')
        lines.append(label+' & '+' & '.join(str(row[k]) for k in KEYS)+r'\\')
    lines += [r'\midrule','Current separate minima & '+' & '.join(str(envelope[k]) for k in KEYS)+r'\\',
              'Combined recursor reference & '+' & '.join(str(baseline[k]) for k in KEYS)+r'\\',
              r'\textbf{Scalar iterator (this work)} & '+' & '.join(r'\textbf{'+str(candidate[k])+'}' for k in KEYS)+r'\\',
              r'\bottomrule',r'\end{tabular}']
    (ROOT/'results/comparison_table.tex').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='programs'},indent=2))


if __name__ == '__main__':
    main()
