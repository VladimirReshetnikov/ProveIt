"""Compile the delivered paper using an installed pdfLaTeX."""
from pathlib import Path
import subprocess
import shutil

ROOT = Path(__file__).resolve().parent


def main():
    engine = shutil.which('pdflatex')
    if engine is None:
        raise SystemExit('Install a TeX distribution with pdflatex and the packages listed in report.tex.')
    for iteration in range(3):
        result = subprocess.run([engine, '-interaction=nonstopmode', '-halt-on-error',
                                 '-file-line-error', 'report.tex'],
                                cwd=ROOT, text=True, capture_output=True)
        (ROOT/'results'/f'latex_pass_{iteration+1}.txt').write_text(result.stdout+result.stderr)
        if result.returncode:
            print(result.stdout[-12000:])
            raise SystemExit(result.returncode)
    print(ROOT/'report.pdf')


if __name__ == '__main__':
    main()
