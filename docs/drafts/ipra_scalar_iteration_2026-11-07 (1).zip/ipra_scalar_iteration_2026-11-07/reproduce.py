"""Reproduce all reported finite evidence; no network access is required."""
from pathlib import Path
import json
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def main():
    commands = [
        ['measure.py'],
        ['validation/verify.py'],
        ['research/arithmetic_checks.py'],
    ]
    runs = []
    for args in commands:
        started = time.monotonic()
        result = subprocess.run([sys.executable, *args], cwd=ROOT,
                                text=True, capture_output=True)
        row = dict(command=[sys.executable, *args], returncode=result.returncode,
                   seconds=round(time.monotonic()-started, 3),
                   stdout=result.stdout, stderr=result.stderr)
        runs.append(row)
        print(('PASS' if result.returncode == 0 else 'FAIL') + ': ' + ' '.join(args), flush=True)
        if result.returncode:
            print(result.stdout)
            print(result.stderr, file=sys.stderr)
            raise SystemExit(result.returncode)
    result = dict(status='PASS', python=platform.python_version(), runs=runs,
                  scope='Reproduces finite evidence; not a machine proof of metatheorems.')
    (ROOT/'results/reproduction.json').write_text(json.dumps(result, indent=2)+'\n')
    metrics = json.loads((ROOT/'results/metrics.json').read_text())
    validation = json.loads((ROOT/'results/verification.json').read_text())
    print('Complete checker:', {k:metrics['candidate'][k] for k in
          ('normalized_tokens','ast_nodes','normalized_bytes')})
    print('Scalar comparison:', validation['summary'])


if __name__ == '__main__':
    main()
