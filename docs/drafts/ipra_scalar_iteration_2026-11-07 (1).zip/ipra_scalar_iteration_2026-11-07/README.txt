SCALAR ITERATION: A SMALLER COMPLETE AXIOMATIZATION OF iPRA
7 November 2026
========================================================

MAIN RESULT

The complete acceptance program checker.py has 417 normalized Python
tokens, 430 AST nodes, and 1,226 normalized UTF-8 bytes. These are below
the inspected drafts' separate minima 427 / 436 / 1,246. The comparison
uses the unchanged inherited AST-normalization metric and includes all
imports, syntax/scope checking, JSON loading and final verdict handling.

The inspected ProveIt commit is:
  5c4724e5550a1b19347ac62c9b02857a7e3fbd19

This is a strict improvement over that finite corpus, not a proof that
no still smaller presentation is possible.

The mathematical change is replacement of a two-variable primitive
recursor update by scalar iteration:
  I(0,a;u.h) = a
  I(Sn,a;u.h) = h[I(n,a;u.h)/u].
Only the previous value is bound in h. Fixed parameters are allowed.
The paper proves comparison, predecessor, quantifier-free induction,
pairing and full primitive recursion internally. Its ordinary first-order
realization is bi-interpretable with iPRA on the entire numerical domain;
the double-interpretation isomorphisms are given by ordinary equality.

START HERE

  report.pdf                 Complete paper, including all primitive rules.
  report.tex                 Main LaTeX source; includes sections/ and research/.
  checker.py                 The entire trusted acceptance program.
  ATTRIBUTION.txt             Inherited mathematics/code and source relationships.

The appendix prints the complete checker. The paper distinguishes
written mathematical proofs from implementation tests, and makes no
worldwide priority claim for pure iteration's expressive completeness.

RUNNING THE CHECKER

Use Python 3.10 or later. The reported metric uses CPython 3.12.14.
The checker imports only the standard-library json and sys modules.
From the extracted archive directory:

  python3 checker.py examples/scalar/targeted/iteration_zero.json
  python3 checker.py examples/scalar/targeted/iteration_successor.json

Each should print ACCEPT and exit with status zero.

  python3 checker.py validation/rejected/scalar/targeted/old_counter_coordinate_at_zero.json

This should print REJECT and exit with status one.

The public packet is one JSON array containing reverse-order proof data
followed by its closed goal. The native term/formula grammar, coordinate
aliases, eigenvariable handling, and instruction formats are specified
in the paper. Hypotheses close automatically and use no instruction.
Unread initial array elements are permitted inert data. This is not a
proof-search program or a general arithmetic evaluator.

Use examples/scalar/ for the primary program. Other examples directories
are the retained TWO-BINDER baseline corpus and are not all scalar inputs.
validation/README.txt explains the precise boundary.

REPRODUCING ALL FINITE EVIDENCE

  python3 reproduce.py

This performs, without network access:

  * Hash checks and size measurements of all 97 distinct frozen complete
    comparator sources (307 archive occurrences, including 11 root programs).
  * Retained baseline implementation checks.
  * Primary scalar checks: 98 named fixed cases, 1,000 distinct mutations,
    20 opening boundaries, nine translation boundaries, 90 actual CLI
    executions, and six deliberately defective variants detected.
  * 5,726 numerical arithmetic assertions, with literal scalar evaluation
    separated explicitly from accelerated sanity checks.

Detailed results are in results/metrics.json, results/verification.json,
results/verification_baseline.json, results/reproduction.json, and
research/arithmetic_checks_results.json. Reproduction overwrites these
generated result files. All fixed comparison inputs remain unchanged.

Individual commands are also available:

  python3 measure.py
  python3 validation/verify_scalar.py
  python3 validation/verify_baseline.py
  python3 research/arithmetic_checks.py

validation/scalar_oracle.py uses explicitly named binders. The syntax
translator embeds a scalar iterator into a larger recursor by inserting
an unused counter slot. Neither is imported by checker.py.

BUILDING THE PAPER

Install a TeX distribution containing pdfLaTeX, Latin Modern, AMS math,
microtype, geometry, booktabs, listings, fancyhdr, hyperref and xcolor.
Then run:

  python3 build.py

This compiles report.pdf with three passes. LaTeX diagnostics go into
results/latex_pass_*.txt. No shell escape is used.

SCOPE AND LIMITATIONS

The metatheorems are written proofs with explicit induction invariants
and independent mathematical review. They are not complete generated
proof certificates and are not formalized in Lean or Rocq. Finite tests
do not prove consistency, soundness, bi-interpretability, or minimality.

The main presentation accepts closed sentences. Open parameter theorems
are encoded by their derived universal closures. All interpretation
domains are the full numerical domain. Pair encoding is an internal
derived operation; it is not a restriction to standard numbers or a cut.

Proof size, term size and evaluation time may grow substantially after
counter elimination. This work optimizes the complete trusted acceptance
program under the specified corpus metric, not those separate costs.

The 419-token baseline and comparison/combined_direct.py are intermediate
implementations created for this work. They are not counted as old
proposals in the frontier. See the paper and manifests for exact provenance.

SHA256SUMS.txt records the files as delivered. Regenerated reports/logs
will naturally have different hashes on other systems or Python versions.
