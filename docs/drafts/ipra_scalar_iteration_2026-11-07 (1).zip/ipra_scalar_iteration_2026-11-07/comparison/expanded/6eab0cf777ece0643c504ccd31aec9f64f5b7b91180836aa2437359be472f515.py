"""Frozen-fixture transport, exact provenance, and normal/optimized CLI checks."""

from collections import Counter
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from transport import SOURCE, SOURCE_SHA256, translate
from validation.common import canonical_bytes, declared_verdict, digest, module, verdict, write_result


class TransportTests(unittest.TestCase):
    def test_frozen_transport_and_cli(self):
        index = json.loads((ROOT / "validation/reference/index.json").read_text())
        self.assertEqual(digest(SOURCE.read_bytes()), SOURCE_SHA256)
        reference_source = SOURCE.read_text()
        kernel = module((ROOT / "checker.py").read_text())
        records = []
        rejected = []

        for row in index["records"]:
            with self.subTest(instance=row["id"], source=row["source_path"]):
                source_path = ROOT / row["fixture"]
                frozen = source_path.read_bytes()
                self.assertEqual(digest(frozen), row["sha256"])
                packet = json.loads(frozen)
                self.assertEqual(digest(canonical_bytes(packet)), row["packet_sha256"])
                self.assertEqual(declared_verdict(reference_source, packet), row["expected_accept"])

                if not row["expected_accept"]:
                    with self.assertRaises(Exception):
                        translate(packet)
                    rejected.append({"id": row["id"], "source_path": row["source_path"],
                                     "reference_rejected": True})
                    continue

                translated, events = translate(packet)
                target = ROOT / row["transported"]
                target_bytes = target.read_bytes()
                self.assertEqual(digest(target_bytes), row["transported_sha256"])
                self.assertEqual(json.loads(target_bytes), translated)
                self.assertEqual(digest(canonical_bytes(translated)),
                                 row["transported_packet_sha256"])
                self.assertTrue(verdict(kernel, translated))

                cli = []
                for mode, flags in (("normal", []), ("optimized", ["-O"])):
                    result = subprocess.run(
                        [sys.executable, *flags, str(ROOT / "checker.py"), str(target)],
                        text=True, capture_output=True, timeout=30,
                    )
                    self.assertEqual(result.returncode, 0, (mode, result.stderr))
                    self.assertEqual(result.stdout, "ACCEPT\n", mode)
                    self.assertEqual(result.stderr, "", mode)
                    cli.append({"mode": mode, "accepted": True})

                records.append({
                    "id": row["id"], "group": row["group"],
                    "source_path": row["source_path"], "source_sha256": row["sha256"],
                    "source_packet_sha256": row["packet_sha256"],
                    "output": row["transported"], "output_sha256": row["transported_sha256"],
                    "packet_sha256": row["transported_packet_sha256"],
                    "instructions": len(translated) - 1,
                    "allocations": events, "reference_accepted": True,
                    "in_process_accepted": True, "cli": cli,
                })

        summary = {
            "source_instances": len(index["records"]),
            "positive_instances": len(records),
            "positive_distinct_source_paths": len({r["source_path"] for r in records}),
            "positive_distinct_source_packets": len({r["source_packet_sha256"] for r in records}),
            "distinct_transported_packets": len({r["packet_sha256"] for r in records}),
            "negative_reference_instances": len(rejected),
            "normal_cli_acceptances": len(records),
            "optimized_cli_acceptances": len(records),
            "positive_group_instances": dict(Counter(r["group"] for r in records)),
        }
        self.assertEqual(summary["source_instances"], 57)
        self.assertEqual(summary["positive_instances"], 52)
        self.assertEqual(summary["positive_distinct_source_paths"], 50)
        self.assertEqual(summary["positive_distinct_source_packets"], 49)
        self.assertEqual(summary["distinct_transported_packets"], 49)
        self.assertEqual(summary["negative_reference_instances"], 5)
        write_result("transport.json", {"summary": summary, "records": records,
                                       "reference_rejections": rejected})

    def test_direct_rejections(self):
        kernel = module((ROOT / "checker.py").read_text())
        cases = [
            ("empty_document", []),
            ("empty_goal", [[]]),
            ("unsupported_zero_successor_equality", [[], [0, [0]]]),
            ("incorrect_recursion_base", [[], [[0, 0, 0], [0]]]),
            ("incorrect_recursion_step", [[], [[[0], 0, 1], [0]]]),
            ("boolean_update", [[], [[[0], 0, True], 0]]),
            ("escaped_update_coordinate_5", [[], [[0, 0, 5], 0]]),
            ("escaped_update_coordinate_6", [[], [[0, 0, 6], 0]]),
            ("boolean_term", [[], [False, 0]]),
            ("floating_term", [[], [0.0, 0]]),
            ("empty_term", [[], [[], 0]]),
        ]
        for name, packet in cases:
            with self.subTest(case=name):
                self.assertFalse(verdict(kernel, packet))
        write_result("direct_rejections.json", {
            "rejected": len(cases),
            "cases": [{"name": name, "packet": packet, "accepted": False}
                      for name, packet in cases],
        })

    def test_combined_companion(self):
        index = json.loads((ROOT / "validation/reference/index.json").read_text())
        source = (ROOT / "checker_combined.py").read_text()
        records = []
        for row in index["records"]:
            with self.subTest(instance=row["id"]):
                packet = json.loads((ROOT / row["fixture"]).read_text())
                # This companion uses declared-supply names. A fresh module
                # for each packet prevents allocations leaking across cases.
                accepted = declared_verdict(source, packet)
                self.assertEqual(accepted, row["expected_accept"])
                records.append({"id": row["id"], "expected_accept": row["expected_accept"],
                                "accepted": accepted})

        cli = []
        for basename in ("closed_reflexivity.json", "root_free_parameter.json"):
            row = next(r for r in index["records"]
                       if Path(r["source_path"]).name == basename)
            result = subprocess.run(
                [sys.executable, str(ROOT / "checker_combined.py"), str(ROOT / row["fixture"])],
                text=True, capture_output=True, timeout=30,
            )
            self.assertEqual(result.returncode, 0 if row["expected_accept"] else 1)
            self.assertEqual(result.stdout, "ACCEPT\n" if row["expected_accept"] else "REJECT\n")
            self.assertEqual(result.stderr, "")
            cli.append({"id": row["id"], "expected_accept": row["expected_accept"],
                        "accepted": result.returncode == 0})
        write_result("combined.json", {
            "summary": {"instances": len(records),
                        "accepted_instances": sum(r["accepted"] for r in records),
                        "rejected_instances": sum(not r["accepted"] for r in records),
                        "cli_cases": len(cli)},
            "records": records, "cli": cli,
        })

    def test_zero_reflexivity_sample(self):
        packet = json.loads((ROOT / "examples/reflexivity_zero.json").read_text())
        self.assertEqual(packet[-1], [0, 0])
        self.assertTrue(verdict(module((ROOT / "checker.py").read_text()), packet))


if __name__ == "__main__":
    unittest.main()
