"""Regression helpers and independent explicit-rule oracle for the iPRA checkers.

This validator is untrusted and is not imported by the acceptance checker.
It compares whole CLI acceptance, not merely an internal successful call.
The independent implementation uses explicit grammar and separate binder depth.
"""
from copy import deepcopy
from pathlib import Path
import hashlib
import importlib.util
import json
import random
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT/'reference_checker.py'


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ExplicitOracle:
    """Separate sort/depth implementation preserving raw paired-coordinate aliases."""
    def term(self, a, env=(), depth=0):
        if type(a) is int:
            if a < self.floor:
                raise ValueError('undeclared parameter')
            if a <= 0 or (a + 1)//2 <= depth:
                return a
            return self.term(env[(a + 1)//2 - depth - 1])
        if type(a) is not list:
            raise ValueError('not a term')
        if len(a) == 1:
            return [self.term(a[0], env, depth)]
        if len(a) == 3:
            return [self.term(a[0], env, depth), self.term(a[1], env, depth),
                    self.term(a[2], env, depth + 2)]
        raise ValueError('bad numerical constructor')

    def formula(self, a, env=(), depth=0):
        if type(a) is not list:
            raise ValueError('not a formula')
        if len(a) == 1:
            return [self.formula(a[0], env, depth + 1)]
        if len(a) == 2:
            return [self.term(a[0], env, depth), self.term(a[1], env, depth)]
        if len(a) == 3:
            return [self.formula(x, env, depth + 1) for x in a]
        raise ValueError('bad logical constructor')

    def proof(self, a, context):
        self.formula(a)
        instruction = self.stream.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, motive = instruction
            if not self.proof(major, context):
                return a in context
            if len(major) == 3:
                self.floor -= 1
                self.allocations += 1
                local = self.formula(major[0], [self.floor])
                return self.proof(a, context + [local])
            if len(major) == 1:
                body, left, right = major[0], 0, motive
            else:
                body, left, right = motive, major[0], major[1]
            before = self.formula(body, [left])
            after = self.formula(body, [right])
            return after == a and self.proof(before, context)
        if len(a) == 1 and instruction == []:
            body = a[0]
            locals_ = [self.formula(body, [0])]
            if len(body) == 2:
                locals_.append(body)
            self.floor -= 1
            self.allocations += 1
            goal = self.formula(body, [[self.floor]])
            locals_ = [self.formula(x, [self.floor]) for x in locals_]
            return self.proof(goal, context + locals_)
        if len(a) == 3 and type(instruction) is list and len(instruction) == 1:
            return self.proof(self.formula(a[0], [instruction[0]]), context)
        if (len(a) == 2 and type(a[0]) is list and len(a[0]) == 3
                and instruction == []):
            counter, initializer, update = a[0]
            if counter == 0:
                return a[1] == initializer
            if type(counter) is not list or len(counter) != 1:
                raise ValueError('counter is neither zero nor successor')
            predecessor = counter[0]
            rhs = self.term(update, [[predecessor, initializer, update], predecessor])
            return a[1] == rhs
        return a in context

    def verdict(self, packet):
        self.floor = 0
        self.allocations = 0
        try:
            self.stream = deepcopy(packet)
            goal = self.stream.pop()
            return bool(self.proof(goal, []))
        except Exception:
            return False


def verdict(module, packet):
    try:
        stream = deepcopy(packet)
        module.k = 0
        module.take = stream.pop
        return bool(module.check(stream.pop(), []))
    except Exception:
        return False


def pack(goal, events):
    return deepcopy(events[::-1]) + [deepcopy(goal)]


def reflexivity_events(t):
    equation = [[0, t, 0], t]
    return [[equation, [1, t]], [], []]


def new_cases():
    records = []
    def add(name, goal, events, expected, reason):
        records.append(dict(name=name, packet=pack(goal, events), expected=expected, reason=reason))
    add('fresh_universal_reflexivity', [[1, 2]], [[]] + reflexivity_events([-1]), True,
        'Both protected aliases open to the same fresh successor term.')
    add('future_fixed_parameter_in_closure', [[1, -1]], [[]] + reflexivity_events([-1]), False,
        'The closure cannot contain its future eigenparameter as a fixed parameter.')
    add('future_parameter_in_unused_recursion_update', [[0, 0, -1], 0], [[]], False,
        'Dead numerical update syntax is still validated.')
    add('closed_recursion_previous_value_alias_1', [[[0], 0, 1], [0, 0, 1]], [[]], True,
        'First raw alias denotes the previous recursive value.')
    add('closed_recursion_previous_value_alias_2', [[[0], 0, 2], [0, 0, 2]], [[]], True,
        'Second raw alias denotes the previous recursive value.')
    add('closed_recursion_counter_alias_3', [[[0], 0, 3], 0], [[]], True,
        'First counter alias denotes predecessor zero.')
    add('closed_recursion_counter_alias_4', [[[0], 0, 4], 0], [[]], True,
        'Second counter alias denotes predecessor zero.')
    add('closed_recursion_out_of_scope_5', [[[0], 0, 5], 0], [[]], False,
        'The first coordinate beyond both update binders is unbound.')
    add('alias_conversion_is_not_literal_RS', [[[0], 0, 1], [0, 0, 2]], [[]], False,
        'Aliases in protected update syntax need a derivation; raw RS does not convert them.')
    add('equality_substitution_capture', [0, 0], [[[[0, 0, 0], 0], [3, 0]], []], False,
        'The motive contains a second unbound opening slot.')
    add('existential_future_used_witness', [[1, 1], [0, 0], [0, 0]], [[-1]] + reflexivity_events(-1), False,
        'A used witness cannot name a future eigenparameter.')
    for junk in [None, True, 0.0, 'unused', {'x': -99}, [5]]:
        add('existential_unused_witness_' + str(len(records)), [[0, 0], [0, 0], [0, 0]],
            [[junk]] + reflexivity_events(0), True,
            'The witness annotation is inert when the matrix contains no opening slot.')
    for i, junk in enumerate([None, True, False, 0.0, 1.0, '0', {}, [], [0, 0], [0, 0, 0, 0]]):
        add('malformed_used_term_' + str(i), [[0, junk, 0], junk], [[]], False,
            'Every used numerical position must pass exact-type and exact-arity validation.')
        add('malformed_root_formula_' + str(i), junk, [[]], False,
            'A root goal must satisfy the formula grammar; no assumptions are supplied.')
    return records


def mutate(packet, rng):
    result = deepcopy(packet)
    paths = []
    def visit(x, p):
        paths.append(p)
        if type(x) is list:
            for i, y in enumerate(x): visit(y, p + [i])
    visit(result, [])
    path = rng.choice(paths)
    changes = [None, True, False, 0.0, -999, 5, [], [0], [0, 0], [0, 0, 0, 0]]
    replacement = deepcopy(rng.choice(changes))
    if not path:
        return replacement
    target = result
    for i in path[:-1]: target = target[i]
    target[path[-1]] = replacement
    return result


def main():
    candidate_path = ROOT.parent/'checker.py'
    baseline_path = REFERENCE
    candidate = load(candidate_path, 'candidate_combined_closed')
    baseline = load(baseline_path, 'source_paired_declared')
    oracle = ExplicitOracle()
    frozen = json.loads((ROOT/'fixtures_manifest.json').read_text())
    if hashlib.sha256(baseline_path.read_bytes()).hexdigest() != frozen['baseline_sha256']:
        raise AssertionError('Changed frozen reference checker')
    fixtures = ROOT/'fixtures'
    fixtures.mkdir(exist_ok=True)
    records = []
    for item in frozen['cases']:
        path = ROOT/item['file']
        if hashlib.sha256(path.read_bytes()).hexdigest() != item['source_sha256']:
            raise AssertionError('Changed frozen certificate: ' + item['file'])
        records.append({k: v for k, v in item.items() if k != 'file'} |
                       dict(packet=json.loads(path.read_text())))
    inherited_count = len(records)
    records += new_cases()
    summary = []
    for record in records:
        packet = record['packet']
        want = record['expected']
        c, b, o = verdict(candidate, packet), verdict(baseline, packet), oracle.verdict(packet)
        if (c, b, o) != (want, want, want):
            raise AssertionError((record['name'], c, b, o, want))
        path = fixtures/(record['name'] + '.json')
        path.write_text(json.dumps(packet, separators=(',', ':')) + '\n')
        process = subprocess.run([sys.executable, str(candidate_path), str(path)], capture_output=True, text=True)
        if process.returncode != (0 if want else 1) or process.stdout.strip() != ('ACCEPT' if want else 'REJECT'):
            raise AssertionError(('CLI', record['name'], process.returncode, process.stdout, process.stderr))
        summary.append({k: v for k, v in record.items() if k != 'packet'} | dict(
            candidate=c, baseline=b, explicit_oracle=o, oracle_eigenparameter_allocations=oracle.allocations,
            file=str(path.relative_to(ROOT)), cli_exit=process.returncode, cli_stdout=process.stdout.strip()))
    rng = random.Random(20261107)
    mutations = []
    for i in range(1200):
        parent = records[i % len(records)]
        packet = mutate(parent['packet'], rng)
        c, b, o = verdict(candidate, packet), verdict(baseline, packet), oracle.verdict(packet)
        if len({c, b, o}) != 1:
            raise AssertionError(('mutation differential', i, c, b, o, packet))
        mutations.append(dict(index=i, parent=parent['name'], candidate=c, baseline=b, explicit_oracle=o,
                              packet_sha256=hashlib.sha256(json.dumps(packet, sort_keys=True).encode()).hexdigest()))
    out = dict(status='PASS', candidate_sha256=hashlib.sha256(candidate_path.read_bytes()).hexdigest(),
               baseline_sha256=hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
               pinned_commit='18e3b9b4071c76fb9e817a2eb50d7b12f7246d18',
               inherited_cases=inherited_count, new_cases=len(records)-inherited_count,
               explicit_case_acceptances=sum(x['expected'] for x in records),
               explicit_case_rejections=sum(not x['expected'] for x in records),
               actual_cli_checks=len(records), differential_mutations=len(mutations),
               mutation_acceptances=sum(x['candidate'] for x in mutations),
               oracle_eigenparameter_allocations=sum(x['oracle_eigenparameter_allocations'] for x in summary),
               cases=summary, mutations=mutations,
               limits='Finite regression and differential checks; metatheoretic proofs are not machine formalized.')
    (ROOT.parent/'results/verification.json').write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps({k: v for k, v in out.items() if k not in ('cases', 'mutations')}, indent=2))


if __name__ == '__main__':
    main()
