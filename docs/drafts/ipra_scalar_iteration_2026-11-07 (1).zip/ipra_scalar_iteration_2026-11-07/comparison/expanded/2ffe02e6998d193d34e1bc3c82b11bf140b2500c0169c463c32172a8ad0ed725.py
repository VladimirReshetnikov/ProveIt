"""Reproduce proof transport, independent oracle checks, and adversarial tests.

This entire directory is test support outside the trusted acceptance kernel.
Only the package checker_closed.py and checker.py decide the certificates.  The source
packets and source checker are pinned copies from the inspected public draft.
"""
from __future__ import annotations
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import types

import translate as tr
from named_oracle import Oracle, opening

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT.parents[1]
EXAMPLES = PACKAGE / 'examples/translated'
RESULTS = PACKAGE / 'results'
CLOSED = PACKAGE / 'checker_closed.py'
OPEN = PACKAGE / 'checker.py'


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def packet(proof):
    return tr.Emitter().packet(proof)


def predecessor(t):
    u, v = tr.fresh(), tr.fresh()
    return tr.R(t, 0, u, v, v)


def make_capture_attack():
    """False D_xy G_y(x=p(y)), accepted only with contextual image capture."""
    x, y, e = tr.fresh(), tr.fresh(), tr.fresh()
    value = predecessor(tr.S(e))
    step = tr.gate_convert(tr.refl(value), tr.Eq(value, value), tr.S(e), True)
    harmless = tr.d_intro(tr.D(x, y, tr.gate(tr.Eq(predecessor(y), predecessor(y)), y)),
                          0, e, step)
    result = packet(harmless)
    result[-1] = tr.raw_formula(tr.D(x, y, tr.gate(tr.Eq(x, predecessor(y)), y)), {})
    # The image is used beneath a selector's two numerical binders.  A buggy
    # validator using insertion depth accepts coordinate5 as the inner y.
    result[-2] = [[5, 0, 3]]
    return result


def make_escape_attack():
    """A DE eigenparameter escapes to the public goal if its validation is lost."""
    x, y, e, a = (tr.fresh() for _ in range(4))
    body = tr.gate(tr.Eq(x, 0), y)
    step = tr.gate_convert(tr.refl(0), tr.Eq(0, 0), tr.S(e), True)
    major = tr.d_intro(tr.D(x, y, body), 0, e, step)
    closure = tr.Q(y, tr.sf(body, x, a))
    ungated = tr.Eq(a, 0)
    extracted = tr.q_elim(tr.hyp(closure), tr.S(0), tr.gate_zero(ungated))
    minor = tr.gate_convert(extracted, ungated, tr.S(0), False)
    proof = tr.d_elim(major, a, minor)
    emitter = tr.Emitter()
    scope = {a: -2}  # DI allocates -1; DE then allocates -2.
    emitter.emit(proof, scope=scope)
    assert emitter.k == -2
    return emitter.cells[::-1] + [tr.raw_formula(proof.goal, scope)]


def make_compound_induction_attack():
    """Uses a compound Q formula as an illegal induction hypothesis.

    The conclusion happens to be provable by a different derivation; this
    certificate specifically requires the forbidden compound hypothesis.
    """
    x, y, e, z, u, v, hole = (tr.fresh() for _ in range(7))
    def value(t):
        return tr.R(t, 0, u, v, u)
    body = tr.Q(z, tr.Eq(value(y), 0))
    computation = tr.comp(value(tr.S(e)), value(e))
    step = tr.eq_elim(tr.sym(computation), hole, tr.Q(z, tr.Eq(hole, 0)),
                      tr.hyp(tr.sf(body, y, e)))
    emitter = tr.Emitter()
    emitter.k = -1
    emitter.cells.append([0])
    scope = {e: -1}
    extra = [tr.raw_formula(tr.sf(body, y, 0), scope),
             tr.raw_formula(tr.sf(body, y, e), scope)]
    emitter.emit(step, extra, scope)
    return emitter.cells[::-1] + [tr.raw_formula(tr.D(x, y, body), {})]


def examples():
    truth = [0, 0]
    d_constant = [truth, truth, truth]
    d_first = [[3, 3], truth, truth]
    good = [[0], d_constant]
    x, y, e = tr.fresh(), tr.fresh(), tr.fresh()
    both = packet(tr.d_intro(tr.D(x, y, tr.Eq(y, y)), 0, e, tr.refl(tr.S(e))))
    alias = deepcopy(both)
    alias[-1][0] = [1, 2]
    result = [
        ('constant_matrix_retains_base', good, True),
        ('first_binder_witness_used', [[0], d_first], True),
        ('second_binder_successor_step', both, True),
        ('second_binder_coordinate_alias', alias, True),
        ('first_binder_coordinate_alias', [[0], [[3, 4], truth, truth]], True),
        ('unused_future_witness', [[-999], d_constant], True),
        ('unused_object_witness', [[{'ignored': True}], d_constant], True),
        ('unused_prefix', [None, *good], True),
        ('empty_formula', [[], []], False),
        ('boolean_is_not_zero', [[], [[0, False, 0], False]], False),
        ('unbound_root_coordinate', [[], [1, 1]], False),
        ('undeclared_root_parameter', [[], [-1, -1]], False),
        ('undeclared_parameter_in_padding', [[0], [truth, [-1, -1], truth]], False),
        ('unbound_coordinate_in_padding', [[0], [truth, [5, 5], truth]], False),
        ('malformed_padding', [[0], [truth, None, truth]], False),
        ('used_future_witness', [[-1], d_first], False),
        ('used_boolean_witness', [[True], d_first], False),
        ('used_object_witness', [[{}], d_first], False),
        ('used_unbound_witness', [[1], d_first], False),
        ('used_unbound_witness_alias', [[2], d_first], False),
        ('witness_update_leaks_outer_coordinate', [[[0, 0, 5]], d_first], False),
        ('missing_witness_annotation', [[], d_constant], False),
        ('multiple_witness_annotations', [[0, 0], d_constant], False),
        ('scalar_witness_annotation', [0, d_constant], False),
        ('direct_Q_introduction_removed', [[], [[0, 0]]], False),
        ('false_successor_zero_computation', [[], [[0, [0], 0], 0]], False),
        ('false_inner_capture', make_capture_attack(), False),
        ('false_eigenparameter_escape', make_escape_attack(), False),
        ('compound_induction_hypothesis', make_compound_induction_attack(), False),
    ]
    return result


def mutant(code, old, new, name):
    assert code.count(old) == 1, (name, old)
    module = types.ModuleType(name)
    # These are explicit, local mutations of the already inspected checker.
    # No downloaded code or proof annotation is executed here.
    exec(compile(code.replace(old, new), name, 'exec'), module.__dict__)
    return module


def audit_opening(closed):
    """Compare explicit named parsing with the production packed opening."""
    atoms = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, True, None, {}]
    terms = [*atoms, [], [0], [1], [5], [0, 0], [0, 0, 1], [0, 0, 3],
             [0, 0, 5], [1, 0, [0, 3, 7]], [0, 0, [0, 1, 9]]]
    formulas = [[t, 0] for t in terms]
    formulas += [[[t, 0]] for t in (-2, 0, 1, 2, 3, 4, 5)]
    formulas += [[[t, 0], [1, 2], [3, 4]] for t in (-2, 0, 1, 2, 3, 4, 5, 6)]
    formulas += [[], None, {}, [True], [[0, 0], [5, 5], [0, 0]],
                 [[[5, 1]], [[3, 4]], [[1, 2]]],
                 [[[[0, 0, 9], 5]], [0, 0], [0, 0]]]
    environments = [(), (0,), (-1,), (-3,), (1,), ([0],), ([0, 0, 3],),
                    ([0, 0, 5],), (0, [0])]
    counts = Counter()
    for formula, values in ((True, formulas), (False, terms)):
        for value in values:
            for depth in (0, 1, 2):
                for lower in (0, -2):
                    for images in environments:
                        closed.k = lower
                        try:
                            actual = closed.inst(deepcopy(value), deepcopy(images),
                                                 2 * depth + (not formula))
                            valid = True
                        except Exception:
                            actual, valid = None, False
                        try:
                            expected = opening(deepcopy(value), deepcopy(images),
                                               formula=formula, depth=depth, lower=lower)
                            valid_expected = True
                        except Exception:
                            expected, valid_expected = None, False
                        assert valid == valid_expected and (not valid or actual == expected), \
                            (value, images, formula, depth, lower, actual, expected)
                        counts['valid' if valid else 'invalid'] += 1
    return dict(counts)


def cli(path, packet_path, expected, optimized):
    args = [sys.executable, *(['-O'] if optimized else []), str(path), str(packet_path)]
    completed = subprocess.run(args, capture_output=True, text=True, timeout=10)
    accepted = completed.returncode == 0 and completed.stdout.strip() == 'ACCEPT'
    rejected = completed.returncode == 1 and completed.stdout.strip() == 'REJECT'
    assert accepted if expected else rejected, (args, completed.returncode,
                                               completed.stdout, completed.stderr)
    return 1


def main():
    closed = tr.load_kernel(CLOSED, 'strict_closed')
    opened = tr.load_kernel(OPEN, 'strict_open')
    provenance = json.loads((ROOT / 'provenance.json').read_text())
    for row in provenance['files']:
        assert sha256((ROOT / row['file']).read_bytes()).hexdigest() == row['sha256'], row['file']
    results = {'target_sha256': {path.name: sha256(path.read_bytes()).hexdigest()
                                for path in (CLOSED, OPEN)}}
    assert results['target_sha256'] == provenance['target_sha256']
    results['substitution_oracle'] = audit_opening(closed)
    theorem_rows, cli_count = [], 0
    for group in ('declared', 'declared_aliases', 'open'):
        header = group == 'open'
        checker = OPEN if header else CLOSED
        source_dir = ROOT / 'frozen' / ('scanned' if header else group)
        for source in sorted(source_dir.glob('*.json')):
            translated, record = tr.transport(json.loads(source.read_text()), checker,
                source_path=ROOT / ('source_scanned.py' if header else 'source_checker.py'),
                preserve_parameters=header, header=header)
            destination = EXAMPLES / group / source.name
            write_json(destination, translated)
            oracle_packet = deepcopy(translated)
            lower = -len(oracle_packet.pop()) if header else 0
            oracle = Oracle().run(oracle_packet, lower)
            for field in ('accepted', 'remaining', 'final_k'):
                assert oracle[field] == record['target_run'][field], (source.name, field)
            for optimized in (False, True):
                cli_count += cli(checker, destination, True, optimized)
            record.update(name=source.name, group=group, named_oracle=oracle)
            theorem_rows.append(record)
    results['theorem_groups'] = dict(Counter(r['group'] for r in theorem_rows))
    results['theorem_cells'] = {group: {
        side: sum(r[side + '_cells'] for r in theorem_rows if r['group'] == group)
        for side in ('source', 'target')} for group in results['theorem_groups']}
    results['freshness_allocations_checked'] = sum(
        len(r['named_oracle']['allocations']) for r in theorem_rows)
    write_json(RESULTS / 'semantic_theorems.json', theorem_rows)
    adversarial_rows = []
    packets = {}
    for name, certificate, expected in examples():
        packets[name] = certificate
        oracle = Oracle().run(certificate)
        actual = tr.run_target(closed, certificate)
        assert oracle['accepted'] == actual['accepted'] == expected, (name, oracle, actual)
        destination = EXAMPLES / 'boundary_closed' / (name + '.json')
        write_json(destination, certificate)
        for optimized in (False, True):
            cli_count += cli(CLOSED, destination, expected, optimized)
        # The explicit open interface with an empty namespace has the same logic.
        open_certificate = [*certificate, []]
        open_actual = tr.run_target(opened, open_certificate, True)
        assert open_actual['accepted'] == expected, (name, open_actual)
        open_destination = EXAMPLES / 'boundary_open' / (name + '.json')
        write_json(open_destination, open_certificate)
        for optimized in (False, True):
            cli_count += cli(OPEN, open_destination, expected, optimized)
        adversarial_rows.append({'name': name, 'expected': expected,
                                 'closed': actual, 'open': open_actual,
                                 'named_oracle': oracle})
    # A declared open parameter is admissible in an actually used witness.
    declared = [[-1], [[3, 4], [0, 0], [0, 0]], [None]]
    assert tr.run_target(opened, declared, True)['accepted']
    assert Oracle().run(declared[:-1], -1)['accepted']
    declared_path = EXAMPLES / 'boundary_open/declared_parameter_witness.json'
    write_json(declared_path, declared)
    for optimized in (False, True):
        cli_count += cli(OPEN, declared_path, True, optimized)
    write_json(RESULTS / 'semantic_boundaries.json', adversarial_rows)
    code = (CLOSED).read_text()
    mutations = [
        ('contextual_image_capture', 'inst(env[a - d >> 1], d=1)',
         'inst(env[a - d >> 1], d=d)', 'false_inner_capture'),
        ('missing_goal_validation', 'if inst(a) in g:', 'if a in g:',
         'false_eigenparameter_escape'),
        ('unrestricted_induction', 'h = [inst(b, [0]), b][:2 - len(b) % 2]',
         'h = [inst(b, [0]), b]', 'compound_induction_hypothesis'),
    ]
    mutation_rows = []
    for name, old, new, fixture in mutations:
        changed = mutant(code, old, new, name)
        verdict = tr.run_target(changed, packets[fixture])
        assert verdict['accepted'], (name, verdict)
        mutation_rows.append({'mutation': name, 'fixture': fixture,
                              'mutant_accepts': True, 'strict_accepts': False})
    results.update(adversarial_cases=len(adversarial_rows),
                   positive_boundary_cases=sum(r['expected'] for r in adversarial_rows),
                   negative_boundary_cases=sum(not r['expected'] for r in adversarial_rows),
                   extra_declared_open_positive=1, mutation_controls=mutation_rows,
                   public_cli_runs=cli_count, status='PASS')
    write_json(RESULTS / 'semantic_summary.json', results)
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
