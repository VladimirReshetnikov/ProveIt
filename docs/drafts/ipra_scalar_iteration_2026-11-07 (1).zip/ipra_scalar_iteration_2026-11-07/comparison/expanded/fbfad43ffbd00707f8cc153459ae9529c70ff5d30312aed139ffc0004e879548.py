"""Portable audit of both opening-by-arguments checkers.

This file is outside the trusted checker.  In the final archive, place it
beside verify.py, reference_checker.py, fixtures_manifest.json and fixtures/.
By default it audits ../checker.py and ../checker_fused.py.  The imported
verify.py provides the independent explicit-rule oracle and corpus builder.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import random
import subprocess
import sys
import tempfile


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def packet_digest(packet):
    return hashlib.sha256(json.dumps(packet, sort_keys=True).encode()).hexdigest()


def count_openings(audit, module, packet):
    calls = 0
    code = module.inst.__code__

    def profile(frame, event, arg):
        nonlocal calls
        if event == 'call' and frame.f_code is code:
            calls += 1

    sys.setprofile(profile)
    try:
        assert audit.verdict(module, packet)
    finally:
        sys.setprofile(None)
    return calls


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--validation-dir', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--checker-dir', type=Path)
    parser.add_argument('--main', default='checker.py')
    parser.add_argument('--fused', default='checker_fused.py')
    parser.add_argument('--oracle', default='verify.py')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    validation = args.validation_dir.resolve()
    checker_dir = (args.checker_dir or validation.parent).resolve()
    report = args.report or validation.parent/'results/verification.json'
    audit = load(validation/args.oracle, 'independent_audit')
    reference_path = validation/'reference_checker.py'
    reference = load(reference_path, 'reference_checker')
    manifest = json.loads((validation/'fixtures_manifest.json').read_text())
    assert digest(reference_path) == manifest['baseline_sha256']
    records = []
    for item in manifest['cases']:
        path = validation/item['file']
        assert digest(path) == item['source_sha256'], item['file']
        records.append(dict(item, packet=json.loads(path.read_text())))
    records.extend(audit.new_cases())
    paths = {'main': checker_dir/args.main, 'fused': checker_dir/args.fused}
    modules = {name: load(path, 'opening_' + name) for name, path in paths.items()}
    oracle = audit.ExplicitOracle()
    case_rows = []
    cli_runs = 0
    with tempfile.TemporaryDirectory(prefix='ipra_opening_audit_') as temporary:
        for index, item in enumerate(records):
            packet = item['packet']
            expected = item['expected']
            assert audit.verdict(reference, packet) == expected
            assert oracle.verdict(packet) == expected
            case_path = Path(temporary)/f'case_{index:03d}.json'
            case_path.write_text(json.dumps(packet, separators=(',', ':')) + '\n')
            row = {'index': index, 'name': item['name'], 'expected': expected,
                   'packet_sha256': packet_digest(packet)}
            for name, module in modules.items():
                assert audit.verdict(module, packet) == expected, (name, item['name'])
                process = subprocess.run([sys.executable, str(paths[name]), str(case_path)],
                                         capture_output=True, text=True)
                want_code, want_output = (0, 'ACCEPT') if expected else (1, 'REJECT')
                assert (process.returncode, process.stdout.strip()) == (want_code, want_output), (
                    name, item['name'], process.returncode, process.stdout, process.stderr)
                cli_runs += 1
                row[name] = {'accept': expected, 'cli_exit': process.returncode}
                if expected:
                    row[name]['inst_calls'] = count_openings(audit, module, packet)
            case_rows.append(row)
    rng = random.Random(20261107)
    mutation_rows = []
    for index in range(1200):
        parent = records[index % len(records)]
        packet = audit.mutate(parent['packet'], rng)
        expected = audit.verdict(reference, packet)
        assert oracle.verdict(packet) == expected, ('oracle mutation', index)
        row = {'index': index, 'parent': parent['name'], 'accept': expected,
               'packet_sha256': packet_digest(packet)}
        for name, module in modules.items():
            assert audit.verdict(module, packet) == expected, (name, 'mutation', index)
            row[name] = expected
        mutation_rows.append(row)
    totals = {name: sum(row[name].get('inst_calls', 0) for row in case_rows) for name in modules}
    result = {
        'status': 'PASS',
        'candidate_sha256': {name: digest(path) for name, path in paths.items()},
        'reference_sha256': digest(reference_path),
        'fixed_case_entries_per_checker': len(records),
        'distinct_case_names': len({item['name'] for item in records}),
        'distinct_fixed_packets': len({packet_digest(item['packet']) for item in records}),
        'actual_cli_runs': cli_runs,
        'mutation_packets': len(mutation_rows),
        'distinct_mutation_packets': len({row['packet_sha256'] for row in mutation_rows}),
        'distinct_mutations_not_in_fixed_corpus': len(
            {row['packet_sha256'] for row in mutation_rows} -
            {row['packet_sha256'] for row in case_rows}),
        'candidate_mutation_comparisons': len(mutation_rows) * len(modules),
        'accepting_case_entries': sum(item['expected'] for item in records),
        'inst_call_totals': totals,
        'inst_calls_saved_by_fusion': totals['main'] - totals['fused'],
        'inst_call_fraction_saved': (totals['main'] - totals['fused']) / totals['main'],
        'cases': case_rows,
        'mutations': mutation_rows,
        'limits': 'Finite regression and differential checks; mathematical proofs are not machine formalized.',
    }
    report.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('cases', 'mutations')}, indent=2))


if __name__ == '__main__':
    main()
