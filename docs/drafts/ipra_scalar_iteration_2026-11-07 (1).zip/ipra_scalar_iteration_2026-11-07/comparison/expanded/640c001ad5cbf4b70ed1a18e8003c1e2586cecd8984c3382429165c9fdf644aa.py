"""Offline paired-coordinate transport validation, including subtree pruning.

Adapted from ipra_alternation_2026-11-07/validation/transport_test.py in the
pinned ProveIt corpus.  See ATTRIBUTION.txt for exact origin and changes.

The 45 inherited theorem fixtures use empty contexts.  The 21 open-sequent
fixtures validate their supplied assumptions first and are not public theorem
certificates.  New focused examples exercise changed eigenname allocation,
later auxiliary names, failed-major fallback, and an unused input prefix.
"""
from __future__ import annotations

from collections import deque
from copy import deepcopy
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from translator import encode_coordinates, load_kernel, require, run_kernel, transport

SOURCE = ROOT / 'source_checker.py'
TARGET = ROOT.parents[1] / 'checker.py'
FIXTURES = ROOT / 'source_fixtures'
OUTPUT = ROOT / 'examples'
PUBLIC = OUTPUT / 'theorems'
RESULTS = ROOT / 'results/transport.json'


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def source_from_plan(goal, plan, context=()):
    """Generate a source certificate by observing actual source recursion.

    A planner chooses one instruction and its child planners after the real
    kernel has validated the current goal.  This is a certificate generator,
    not an acceptance oracle; the completed input is independently rerun.
    """
    module = load_kernel(SOURCE, 'planned_source')
    original = module.check
    pending = deque([plan])
    cells = []
    module.k = 0

    def wrapped(a, g):
        require(bool(pending), 'source planner queue is exhausted')
        planner = pending.popleft()

        def take():
            cell, children = planner(deepcopy(a), deepcopy(g), module.k)
            cells.append(deepcopy(cell))
            pending.extendleft(reversed(children))
            return cell

        module.take = take
        return original(a, g)

    module.check = wrapped
    for assumption in context:
        module.inst(assumption)
    require(wrapped(deepcopy(goal), deepcopy(list(context))),
            'source planner did not produce an accepted derivation')
    require(not pending, 'source planner has unused child plans')
    certificate = list(reversed(cells)) + [deepcopy(goal)]
    clean = load_kernel(SOURCE, 'clean_planned_source')
    direct = run_kernel(clean, certificate, context)
    require(direct['accepted'] and direct['remaining'] == 0,
            'actual source rejects the generated certificate')
    return certificate


def hypothesis(goal, context, k):
    require(goal in context, 'planned hypothesis is absent')
    return None, []


def computation(goal, context, k):
    return [], []


def reflexivity(update=0):
    def planner(goal, context, k):
        require(len(goal) == 2 and goal[0] == goal[1],
                'reflexivity planner received another goal')
        term = goal[0]
        recursor = [0, term, deepcopy(update)]
        return [[recursor, term], [1, term]], [computation, computation]
    return planner


def q_intro(child):
    def planner(goal, context, k):
        require(len(goal) == 1, 'Q-introduction goal has wrong shape')
        return [], [child]
    return planner


def focused_sources():
    truth = [0, 0]
    h = [[1, 1]]
    conclusion = [[[1], [1]]]
    existential_h = [h, truth, truth]

    def major_exists(goal, context, k):
        return [0], [q_intro(reflexivity())]

    def redundant_h_elimination(goal, context, k):
        return [h, 0], [q_intro(reflexivity()), reflexivity()]

    def continuation(goal, context, k):
        # -3 was an eigenname of the preceding redundant H proof.  Here it
        # is a free auxiliary name in a later sibling.  Pruning makes the
        # retained final eigen -4 become -3, so a scope-only rename would
        # identify two different roles.  Grounding non-interface free names
        # avoids that collision.
        return [truth, conclusion], [redundant_h_elimination,
                                    q_intro(reflexivity(update=-3))]

    def root(goal, context, k):
        return [existential_h, 0], [major_exists, continuation]

    prune = source_from_plan(conclusion, root)

    def unused_future(goal, context, k):
        return [[truth], -1000000], [q_intro(hypothesis), reflexivity()]

    future = source_from_plan(truth, unused_future)
    fallback = json.loads((FIXTURES / 'failed_major_fallback.json').read_text())
    prefix = [None, {'unused_prefix_parameter': -9999999}] + source_from_plan(
        truth, reflexivity())
    return [
        ('pruned_allocation_and_later_free_name', prune),
        ('unused_future_witness', future),
        ('source_failed_major_fallback', fallback),
        ('discarded_unused_prefix', prefix),
    ]


def cli(kernel, file, expected, optimized=False):
    command = [sys.executable]
    if optimized:
        command.append('-O')
    command += [str(kernel), str(file)]
    result = subprocess.run(command, capture_output=True, text=True, timeout=30)
    require(result.returncode == (0 if expected else 1),
            f'wrong CLI status: {file.name}, optimized={optimized}')
    require(result.stdout.strip() == ('ACCEPT' if expected else 'REJECT'),
            f'wrong CLI verdict: {file.name}, optimized={optimized}')
    return {'file': str(file.relative_to(ROOT)), 'optimized': optimized,
            'exit_code': result.returncode, 'verdict': result.stdout.strip(),
            'kernel': str(kernel)}


def main():
    global TARGET
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target-checker', type=Path, default=TARGET)
    args = parser.parse_args()
    TARGET = args.target_checker.resolve()
    manifest = json.loads((FIXTURES / 'manifest.json').read_text())
    for entry in manifest['files']:
        data = (FIXTURES / entry['file']).read_bytes()
        require(hashlib.sha256(data).hexdigest() == entry['sha256'],
                'changed frozen source fixture: ' + entry['file'])

    records, cli_records = [], []
    for kind in ('theorems', 'open_sequents'):
        for path in sorted((FIXTURES / kind).glob('*.json')):
            value = json.loads(path.read_text())
            context = []
            certificate = value
            if kind == 'open_sequents':
                context = value['validated_external_context']
                certificate = value['stack'] + [value['goal']]
            target, summary = transport(certificate, context,
                                        source_path=SOURCE, target_path=TARGET)
            require(target[-2] == encode_coordinates(certificate[-1]),
                    'the root was not preserved under coordinate encoding')
            if kind == 'theorems':
                out = PUBLIC / path.name
                write_json(out, target)
                cli_records.append(cli(SOURCE, path, True))
                cli_records.append(cli(TARGET, out, True))
                cli_records.append(cli(TARGET, out, True, optimized=True))
            else:
                out = OUTPUT / 'open_sequents' / path.name
                write_json(out, {'goal': target[-2], 'stack': target[:-2],
                                 'declaration_header': target[-1],
                                 'validated_external_context': encode_coordinates(context),
                                 'scope': 'Internal test, not a theorem certificate.'})
            records.append({'name': path.name, 'kind': kind, **summary})

    focused = []
    for name, source in focused_sources():
        source_path = OUTPUT / 'focused_source' / (name + '.json')
        write_json(source_path, source)
        target, summary = transport(source, source_path=SOURCE, target_path=TARGET)
        out = PUBLIC / (name + '.json')
        write_json(out, target)
        cli_records.append(cli(SOURCE, source_path, True))
        cli_records.append(cli(TARGET, out, True))
        cli_records.append(cli(TARGET, out, True, optimized=True))
        focused.append({'name': name, **summary})

    pruning, future, fallback, prefix = focused
    require(pruning['source_allocations'] == [-1, -2, -3, -4],
            'the pruning example no longer has its intended source allocations')
    require(pruning['retained_allocation_map'] == [
        {'source': -1, 'target': -1}, {'source': -2, 'target': -2},
        {'source': -4, 'target': -3}], 'later eigenname was not renamed')
    require(-3 in pruning['grounded_auxiliary_names'],
            'later free auxiliary name was not specialized separately')
    require(pruning['pruned_source_cells'] > pruning['pruned_subtrees'],
            'no genuine non-leaf subtree was pruned')
    require(future['source_run']['final_k'] == -1,
            'an unused future witness unexpectedly reserved a parameter')
    require(-1000000 in future['grounded_auxiliary_names'],
            'unused future-witness fixture is missing')
    require(fallback['failed_major_fallbacks'] == 1,
            'failed-major fallback was not exercised')
    require(fallback['target_run']['final_k'] > fallback['source_run']['final_k'],
            'the failed-major allocation was not removed')
    require(prefix['source_unused_prefix_cells'] == 2,
            'unused source prefix fixture was not exercised')

    # These are direct target inputs.  Unlike the older target, this kernel
    # intentionally accepts arbitrary ignored markers at default Q/computation
    # steps, so a nonempty marker there is not a negative test.
    rejected = {
        'false_equation': [None, [0, [0]], []],
        'missing_reflexivity_proof': [[0, 0], []],
        'malformed_formula': [None, [[]], []],
        'illegal_positive_witness': [[1], [[1, 0], [0, 0], [0, 0]], []],
        'false_computation': [None, [[0, 0, 0], [0]], []],
        'undeclared_parameter': [[], [[0, -1, 0], -1], []],
    }
    for name, value in rejected.items():
        path = OUTPUT / 'rejected' / (name + '.json')
        write_json(path, value)
        cli_records.append(cli(TARGET, path, False))
        cli_records.append(cli(TARGET, path, False, optimized=True))

    # The default cases are genuine rule defaults: a failed major guard can
    # consume a rejected proof and allocate a parameter before the valid
    # default rule is chosen.  Its assumptions remain local.  These fixtures
    # exercise that behavior rather than test an unrelated source convention.
    false_major = [[[0, 1, 0], [1]]]
    direct_target_inputs = {
        'wildcard_computation_marker': [None, [[0, 0, 0], 0], []],
        'wildcard_closure_marker': [None, [[0, 0]], []],
        'default_closure_after_failed_major': [
            None, None, [false_major, 0], [[0, 0]], []],
        'default_computation_after_failed_major': [
            None, None, [false_major, 0], [[0, 0, 0], 0], []],
    }
    default_records = []
    for name, value in direct_target_inputs.items():
        path = PUBLIC / (name + '.json')
        write_json(path, value)
        direct = run_kernel(load_kernel(TARGET, 'default_target_' + name),
                            value, target=True)
        require(direct['accepted'] and direct['remaining'] == 0,
                'the intended target default rule was not exercised: ' + name)
        cli_records.append(cli(TARGET, path, True))
        cli_records.append(cli(TARGET, path, True, optimized=True))
        default_records.append({'name': name, 'target_run': direct})
    require(default_records[2]['target_run']['final_k'] == -2,
            'failed-major allocation did not precede fallback Q allocation')
    require(default_records[3]['target_run']['final_k'] == -1,
            'failed-major allocation was not retained before computation')

    result = {
        'status': 'passed',
        'python': sys.version.split()[0],
        'inherited_public_theorems': sum(r['kind'] == 'theorems' for r in records),
        'inherited_open_sequents': sum(r['kind'] == 'open_sequents' for r in records),
        'focused_public_theorems': len(focused),
        'new_default_rule_public_theorems': len(default_records),
        'rejected_public_inputs': len(rejected),
        'cli_runs': len(cli_records),
        'inherited_source_cells_consumed': sum(r['source_cells_consumed'] for r in records),
        'inherited_target_cells': sum(r['target_cells'] for r in records),
        'inherited_pruned_subtrees': sum(r['pruned_subtrees'] for r in records),
        'records': records, 'focused': focused, 'default_rules': default_records,
        'cli': cli_records,
        'target_sha256': hashlib.sha256(TARGET.read_bytes()).hexdigest(),
        'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'limits': 'Finite implementation evidence, not a formal proof of the metatheorems.',
    }
    write_json(RESULTS, result)
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('records', 'focused', 'default_rules', 'cli')}, indent=2))


if __name__ == '__main__':
    main()
