"""Independent grammar, named substitution, and public-certificate checks.

The reference parser/checker does not import checker.py. This harness loads
checker.py solely to compare its observable verdicts and opening results to
the independently written reference, and runs both soundness defect controls.
"""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import platform
import random
import subprocess
import sys

from named_oracle import NamedSyntax, inspect as reference_inspect


ROOT = Path(__file__).resolve().parent.parent


def load_program(text, label):
    namespace = {"__name__": label}
    exec(compile(text, label, "exec"), namespace)
    return namespace


def kernel_verdict(namespace, packet):
    namespace["p"] = deepcopy(packet)
    try:
        return bool(namespace["check"](namespace["p"].pop(), []))
    except BaseException:
        return False


def reflexivity(term):
    recursor = [0, term, 0]
    major = [recursor, term]
    motive = [1, term]
    return [[], [], [major, motive]], [term, term]


def existential(body, first_ghost=None, second_ghost=None):
    return [body, [0, 0] if first_ghost is None else first_ghost,
            [0, 0] if second_ghost is None else second_ghost]


def numeral(n):
    result = 0
    for _ in range(n):
        result = [result]
    return result


def evaluate_term(raw, bound=(), parameters=None):
    """Direct standard-number evaluator; independent of either substitution."""
    parameters = {} if parameters is None else parameters
    if type(raw) is int:
        if raw == 0:
            return 0
        if raw < 0:
            return parameters[raw]
        return bound[(raw - 1) // 2]
    if type(raw) is not list:
        raise ValueError("not a numerical term")
    if len(raw) == 1:
        return evaluate_term(raw[0], bound, parameters) + 1
    if len(raw) == 3:
        count = evaluate_term(raw[0], bound, parameters)
        value = evaluate_term(raw[1], bound, parameters)
        for step in range(count):
            value = evaluate_term(raw[2], (value, step) + bound, parameters)
        return value
    raise ValueError("not a numerical constructor")


def focused_packets():
    rows = []

    def add(name, packet, expected):
        rows.append({"name": name, "packet": packet, "expected": expected})

    add("recursor_zero", [[], [[0, 0, 0], 0]], True)
    add("recursor_open_name_below_boundary", [[], [[0, -2, 0], -2]], True)
    add("recursor_open_name_at_boundary", [[], [[0, -1, 0], -1]], False)
    add("padding_count_changes_namespace", [None, [], [[0, -2, 0], -2]], False)
    add("padding_with_shifted_name", [None, [], [[0, -3, 0], -3]], True)
    for alias in (1, 2):
        add(f"recursor_previous_value_alias_{alias}",
            [[], [[[[0]], [0], alias], [[0], [0], alias]]], True)
    for alias in (3, 4):
        add(f"recursor_previous_counter_alias_{alias}",
            [[], [[[[0]], [0], alias], [0]]], True)

    # A bound variable in an embedded update must retain its lexical binder.
    for alias in (7, 8):
        update = [0, 1, alias]
        previous_value = [0, 0, update]
        add(f"nested_recursion_outer_counter_alias_{alias}",
            [[], [[ [0], 0, update], [0, previous_value, 0]]], True)

    for term, name, expected in ((0, "zero", True), (-4, "open_allowed", True),
                                  (-3, "open_reserved", False)):
        stream, goal = reflexivity(term)
        add("reflexivity_" + name, stream + [goal], expected)

    for alias in (1, 2):
        stream, _ = reflexivity([-4])
        add(f"closure_reflexivity_alias_{alias}", stream + [[], [[alias, alias]]], True)
    add("vacuous_closure_hypothesis", [None, [], [[0, 0]]], True)

    rstream, _ = reflexivity(0)
    for alias in (1, 2):
        add(f"existential_witness_alias_{alias}",
            rstream + [[0], existential([alias, 0])], True)
    for index, witness in enumerate((None, True, [], {}, "unused", 7)):
        add(f"unused_existential_witness_{index}",
            rstream + [[witness], existential([0, 0])], True)
        add(f"used_bad_existential_witness_{index}",
            rstream + [[witness], existential([1, 0])], False)

    add("existential_ghost_bound_aliases",
        rstream + [[0], existential([1, 0], [1, 2], [[1, 1]])], True)
    bad_ghosts = (0, [], True, [0, 0, 0, 0], [3, 0], [-1, 0])
    for i, ghost in enumerate(bad_ghosts):
        add(f"malformed_existential_ghost_{i}",
            rstream + [[0], existential([1, 0], ghost)], False)

    major = existential([0, 0])
    add("existential_elimination_ignored_annotation",
        [None] + rstream + [[0], [major, {"ignored": True}], [0, 0]], True)

    # Equality transport under a binder uses an independently numbered hole.
    eq_major_stream, eq_major = reflexivity(0)
    minor = existential([1, 0])
    for outside_alias in (3, 4):
        motive = existential([1, outside_alias])
        add(f"transport_beneath_existential_alias_{outside_alias}",
            rstream + [[0]] + eq_major_stream + [[eq_major, motive], minor], True)

    a, b = [0, 0, 1], [0, 0, 2]
    add("literal_alias_difference_needs_a_derivation", [[], [[0, a, 0], b]], False)
    add("unread_prefix_contents_supply_no_assumptions", [{"unread": [True, 1.5, None]}] +
        [[], [[0, 0, 0], 0]], True)
    for name, packet in (
        ("empty_document", []), ("object_document", {}),
        ("number_document", 0), ("boolean_document", True),
        ("missing_instruction", [[0, 0]]),
        ("false_equation", [[], [0, [0]]]),
        ("boolean_numerical_leaf", [[], [[0, True, 0], True]]),
        ("floating_numerical_leaf", [[], [[0, 0.0, 0], 0.0]]),
        ("empty_numerical_term", [[], [[0, [], 0], []]]),
        ("overlong_update_coordinate", [[], [[0, 0, 5], 0]]),
    ):
        add(name, packet, False)
    return rows


def opening_audit(kernel):
    cases = []

    def compare(raw, images=(), numerical=False, remaining=0):
        syntax = NamedSyntax()
        try:
            expected = syntax.open(raw, images, numerical=numerical, remaining=remaining)
            expected_ok = True
        except Exception:
            expected, expected_ok = None, False
        kernel["p"] = [None] * remaining
        try:
            actual = kernel["inst"](deepcopy(raw), deepcopy(images), d=1 if numerical else 0)
            actual_ok = True
        except BaseException:
            actual, actual_ok = None, False
        if (actual_ok, actual) != (expected_ok, expected):
            raise AssertionError(("opening mismatch", raw, images, numerical, remaining,
                                  expected_ok, expected, actual_ok, actual))
        cases.append((expected_ok, numerical))

    leaves = [None, False, True, 0.0, 1.5, "x", {}, [], *range(-8, 11)]
    # Explicit sort/arity boundaries, all ghost positions, both protected aliases.
    for remaining in (0, 1, 3, 7):
        for leaf in leaves:
            for raw, numerical in (
                (leaf, True), ([leaf], True), ([0, 0, leaf], True),
                ([leaf, 0], False), ([[leaf, 0]], False),
                (existential([0, 0], [leaf, 0]), False),
                (existential([0, 0], [0, 0], [leaf, 0]), False),
                ([[0, 0, [0, 0, leaf]], 0], False),
            ):
                compare(raw, numerical=numerical, remaining=remaining)

    matrices = (
        [1, 2], [[1, 3]], [[2, 4]],
        existential([1, 3], [2, 4], [0, 0]),
        [[0, 1, [0, 3, 5]], 2],
        [[[1, 0, 5], [1, 0, 7]]],
    )
    images = ([], [0], [[0]], [[0, 0, 1]], [1], [3], [True],
              [-1], [-8], [0, [0]], [None, 0], [{"bad": 0}])
    for remaining in (0, 2, 7):
        for raw in matrices:
            for substitution in images:
                compare(raw, substitution, remaining=remaining)

    # Deterministic tree mutations exercise malformed list grammar beyond leaves.
    randomizer = random.Random(20261107)
    atoms = [0, 1, 2, 3, 4, 5, 6, -1, -9, True, None, "x", {}]

    def tree(depth):
        if depth == 0 or randomizer.randrange(3) == 0:
            return deepcopy(randomizer.choice(atoms))
        return [tree(depth - 1) for _ in range(randomizer.randrange(5))]

    for _ in range(600):
        compare(tree(4), randomizer.choice(images), bool(randomizer.randrange(2)),
                randomizer.randrange(8))
    return {"comparisons": len(cases), "successful_openings": sum(a for a, _ in cases)}


def capture_controls(source, kernel):
    # Q_x exists z (pred(x)=a): at a=0 the base is true but x=2 is false.
    scope_packet = [[], [0], [], [[[[3, 0, 3], -3], [0, 0], [0, 0]]]]
    before = "    match (inst(a), p.pop()):"
    after = "    instruction = p.pop()\n    match (inst(a), instruction):"
    if source.count(before) != 1:
        raise AssertionError("scope defect-control mutation point changed")
    scope_mutant = load_program(source.replace(before, after), "wrong_scope_clock")

    # E_x Q_y(C(y,0,y)=C(y,0,x)); base is always true. Its y=1 and y=2
    # consequences demand the same x equal two different natural numbers.
    # Invalid image5 becomes the y bound coordinate inside a recursor update.
    eigenparameter = -4
    term = [[eigenparameter], 0, [eigenparameter]]
    stream, _ = reflexivity(term)
    image_goal = existential([[[1, 0, 5], [1, 0, 7]]])
    image_packet = stream + [[], [5], image_goal]
    before_image = "else inst(env[a - d >> 1], d=1)"
    after_image = "else env[a - d >> 1]"
    if source.count(before_image) != 1:
        raise AssertionError("image defect-control mutation point changed")
    image_mutant = load_program(source.replace(before_image, after_image), "wrong_image_scope")

    rows = []
    for name, packet, mutant in (
        ("scope_capture_attack", scope_packet, scope_mutant),
        ("image_capture_attack", image_packet, image_mutant),
    ):
        honest = kernel_verdict(kernel, packet)
        reference = reference_inspect(packet)["accepted"]
        defective = kernel_verdict(mutant, packet)
        if honest or reference or not defective:
            raise AssertionError((name, honest, reference, defective))
        path = ROOT / "examples" / "independent" / (name + ".json")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(packet, separators=(",", ":")) + "\n")
        rows.append({"name": name, "file": str(path.relative_to(ROOT)),
                     "kernel_rejected": True, "named_oracle_rejected": True,
                     "deliberately_unsound_mutant_accepted": True})

    predecessor_zero = evaluate_term([0, 0, 3])
    predecessor_two = evaluate_term([numeral(2), 0, 3])
    if (predecessor_zero, predecessor_two) != (0, 1):
        raise AssertionError("direct predecessor evaluation failed")
    return {"controls": rows,
            "standard_counterexample": {"free_parameter_a": 0,
                "predecessor_at_zero": predecessor_zero,
                "predecessor_at_two": predecessor_two,
                "selector_attack_positive_inputs": [1, 2],
                "interpretation": "Finite numerical checks illustrate the written countermodel arguments."}}


def main():
    sys.setrecursionlimit(max(20000, sys.getrecursionlimit()))
    source = (ROOT / "checker.py").read_text()
    kernel = load_program(source, "independent_black_box_target")
    opening = opening_audit(kernel)
    focused = []
    out = ROOT / "examples" / "independent"
    out.mkdir(parents=True, exist_ok=True)
    for case in focused_packets():
        actual = kernel_verdict(kernel, case["packet"])
        reference = reference_inspect(case["packet"])
        if actual != case["expected"] or reference["accepted"] != case["expected"]:
            raise AssertionError((case["name"], case["expected"], actual, reference))
        file = out / (case["name"] + ".json")
        file.write_text(json.dumps(case["packet"], separators=(",", ":")) + "\n")
        focused.append({"name": case["name"], "file": str(file.relative_to(ROOT)),
                        "expected": case["expected"], "kernel": actual,
                        "named_oracle": reference["accepted"]})

    transported = []
    packet_hashes = set()
    for file in sorted((ROOT / "examples" / "transported").glob("*.json")):
        packet = json.loads(file.read_text())
        reference = reference_inspect(packet)
        if not reference["accepted"]:
            raise AssertionError((file.name, reference))
        digest = hashlib.sha256(json.dumps(packet, separators=(",", ":")).encode()).hexdigest()
        packet_hashes.add(digest)
        transported.append({"file": str(file.relative_to(ROOT)), "accepted": True,
                            "packet_sha256": digest})

    controls = capture_controls(source, kernel)

    # Mutate genuine equality proofs to numerically false targets. Evaluation is
    # direct iteration and does not call either opening implementation.
    terms = [numeral(i) for i in range(5)]
    terms += [[0, numeral(i), 1] for i in range(4)]
    terms += [[numeral(i), 0, 3] for i in range(5)]
    false_equations = 0
    for left in terms:
        stream, _ = reflexivity(left)
        for right in terms:
            if evaluate_term(left) == evaluate_term(right):
                continue
            packet = stream + [[left, right]]
            if kernel_verdict(kernel, packet) or reference_inspect(packet)["accepted"]:
                raise AssertionError(("false numerical equation accepted", left, right))
            false_equations += 1

    cli_rows = []
    for name in ("recursor_zero", "reflexivity_open_allowed",
                 "reflexivity_open_reserved", "used_bad_existential_witness_2",
                 "malformed_existential_ghost_2", "scope_capture_attack",
                 "image_capture_attack"):
        file = out / (name + ".json")
        expected = reference_inspect(json.loads(file.read_text()))["accepted"]
        for optimized in (False, True):
            process = subprocess.run(
                [sys.executable, *(["-O"] if optimized else []),
                 str(ROOT / "checker.py"), str(file)], capture_output=True, text=True
            )
            if (process.returncode, process.stdout.strip()) != (
                0 if expected else 1, "ACCEPT" if expected else "REJECT"
            ):
                raise AssertionError(("CLI discrepancy", name, optimized, process.returncode,
                                      process.stdout, process.stderr))
            cli_rows.append({"case": name, "optimized": optimized, "accepted": expected})

    parser_rows = []
    parser_cases = (
        ("empty", "", False),
        ("unterminated_list", "[", False),
        ("trailing_document", "[] []", False),
        ("object_root", "{}", False),
        ("null_root", "null", False),
        ("string_root", '"x"', False),
        ("floating_root", "2.0", False),
        ("used_nonfinite_number", "[[],[[0,NaN,0],NaN]]", False),
        ("valid_axiom", "[[],[[0,0,0],0]]", True),
    )
    parser_dir = out / "parser"
    parser_dir.mkdir(exist_ok=True)
    for name, text, expected in parser_cases:
        file = parser_dir / (name + ".txt")
        file.write_text(text)
        try:
            reference = reference_inspect(json.loads(text))["accepted"]
        except Exception:
            reference = False
        if reference != expected:
            raise AssertionError(("textual reference discrepancy", name, reference))
        for optimized in (False, True):
            process = subprocess.run(
                [sys.executable, *(["-O"] if optimized else []),
                 str(ROOT / "checker.py"), str(file)], capture_output=True, text=True
            )
            if (process.returncode, process.stdout.strip()) != (
                0 if expected else 1, "ACCEPT" if expected else "REJECT"
            ):
                raise AssertionError(("textual CLI discrepancy", name, optimized,
                                      process.returncode, process.stdout, process.stderr))
            parser_rows.append({"name": name, "file": str(file.relative_to(ROOT)),
                                "optimized": optimized, "accepted": expected})

    result = {
        "status": "PASS", "python": platform.python_version(),
        "kernel_sha256": hashlib.sha256(source.encode()).hexdigest(),
        "named_oracle_sha256": hashlib.sha256((ROOT / "validation" / "named_oracle.py").read_bytes()).hexdigest(),
        "opening": opening, "focused_packet_count": len(focused),
        "transported_instances": len(transported),
        "distinct_transported_packets": len(packet_hashes),
        "false_numerical_equations_rejected": false_equations,
        "actual_cli_runs": len(cli_rows) + len(parser_rows),
        "textual_parser_cases": len(parser_cases), "defect_controls": controls,
        "focused_packets": focused, "transported": transported,
        "cli": cli_rows, "textual_cli": parser_rows,
        "limits": "Finite independent implementation evidence. No formal proof of metatheorems, universal soundness, or consistency. Cohorts overlap and are not counts of distinct theorems.",
    }
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results" / "independent.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items()
                      if k not in {"focused_packets", "transported", "cli", "textual_cli", "defect_controls"}}, indent=2))
    return result


if __name__ == "__main__":
    main()
