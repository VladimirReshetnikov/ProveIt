#!/usr/bin/env python3
"""Finite semantic checks for the explicit scalar-iterator arithmetic.

This file is not a proof checker and is not in the trusted kernel.  It
checks concrete values and the algebraic identities used in the paper.

All object-language definitions are built from zero, successor, and the
scalar iterator.  The update dispatcher receives only the previous scalar
state and fixed numerical parameters; it never receives the iteration
counter.  The literal evaluator memoizes complete scalar orbits without
skipping an update.  Its test grid is deliberately modest.

The accelerated evaluator uses exact cycle detection.  For successor and
u -> u+c it also uses translation period 1.  For the G update
    g(u) = u + m(u) + 1
it uses the PROVED update identity g(u+3)=g(u)+3, allowing an orbit cycle
modulo 3 to be advanced by its exact accumulated displacement.  This is
not the false identity G(n+3)=G(n)+3: the iterated function satisfies
G(n+2)=G(n)+3.  The accelerated G values are compared with literal values
for every input 0..200.  Acceleration is a benchmark aid, never a kernel
rule, theorem certificate, or replacement for the equational proofs.
"""

from __future__ import annotations

import argparse
import functools
import json
from collections import Counter
from pathlib import Path


class ScalarArithmetic:
    def __init__(self, accelerated=False):
        self.accelerated = accelerated
        self.orbits = {}
        self.actual_updates = 0
        self.skipped_updates = 0
        self.maximum_requested_count = 0
        self.maximum_observed_state = 0

    @functools.cache
    def I(self, count, initial, operation, parameters=()):
        """Scalar iteration; the counter is not passed to _update."""
        assert type(count) is int and count >= 0
        assert type(initial) is int and initial >= 0
        self.maximum_requested_count = max(self.maximum_requested_count, count)
        self.maximum_observed_state = max(self.maximum_observed_state, initial)
        if not self.accelerated:
            orbit = self.orbits.setdefault((initial, operation, parameters), [initial])
            while len(orbit) <= count:
                orbit.append(self._update(operation, parameters, orbit[-1]))
            return orbit[count]

        # These periods are justified by the stated equational identities.
        translation_period = {
            "successor": 1,
            "plus_parameter": 1,
            "state_G": 3,
        }.get(operation)
        seen = {}
        state = initial
        completed = 0
        while completed < count:
            key = state if translation_period is None else state % translation_period
            if key in seen:
                old_completed, old_state = seen[key]
                cycle_length = completed - old_completed
                repetitions = (count - completed) // cycle_length
                if repetitions:
                    displacement = state - old_state
                    state += repetitions * displacement
                    skipped = repetitions * cycle_length
                    completed += skipped
                    self.skipped_updates += skipped
                    self.maximum_observed_state = max(self.maximum_observed_state, state)
                    # Avoid reusing a cycle anchor after this jump.
                    seen.clear()
                    continue
            else:
                seen[key] = (completed, state)
            state = self._update(operation, parameters, state)
            completed += 1
        return state

    def _update(self, operation, parameters, previous):
        """Only previous state and fixed parameters reach object updates."""
        self.actual_updates += 1
        if operation == "successor":
            result = previous + 1
        elif operation == "constant":
            result = parameters[0]
        elif operation == "plus_parameter":
            result = self.add(previous, parameters[0])
        elif operation == "zero_indicator":
            result = self.Z(previous)
        elif operation == "state_m":
            result = self.add(self.Z(previous), self.mul(2, self.P(previous)))
        elif operation == "state_G":
            result = self.add(self.add(previous, self.m(previous)), 1)
        elif operation == "state_T":
            result = self.T(previous)
        elif operation == "twice":
            result = self.mul(2, previous)
        elif operation == "saturation_H":
            result = self.C(self.L(previous + 1, parameters[0]), previous, previous + 1)
        elif operation == "saturation_p":
            result = self.C(self.L(previous + 2, parameters[0]), previous, previous + 1)
        else:
            raise ValueError(operation)
        self.maximum_observed_state = max(self.maximum_observed_state, result)
        return result

    @functools.cache
    def add(self, a, b):
        return self.I(b, a, "successor")

    @functools.cache
    def mul(self, a, b):
        return self.I(b, 0, "plus_parameter", (a,))

    @functools.cache
    def C(self, e, a, b):
        return self.I(e, a, "constant", (b,))

    @functools.cache
    def Z(self, n):
        return self.I(n, 1, "constant", (0,))

    @functools.cache
    def P(self, n):
        return self.I(n, 0, "zero_indicator")

    @functools.cache
    def m(self, n):
        return self.I(n, 0, "state_m")

    @functools.cache
    def G(self, n):
        return self.I(n, 0, "state_G")

    @functools.cache
    def T(self, n):
        return self.C(self.P(n), self.G(n), 1)

    @functools.cache
    def F(self, n):
        return self.C(self.m(n), self.mul(3, n), 1)

    @functools.cache
    def U(self, y, a):
        return self.I(y, a, "state_T")

    @functools.cache
    def E(self, x):
        return self.I(x, 1, "twice")

    @functools.cache
    def L(self, x, y):
        return self.P(self.U(y, self.E(x)))

    @functools.cache
    def H(self, t, m):
        return self.I(t, 0, "saturation_H", (m,))

    @functools.cache
    def p(self, m):
        return self.I(m, 0, "saturation_p", (m,))

    def statistics(self):
        return {
            "actual_scalar_updates": self.actual_updates,
            "updates_skipped_by_acceleration": self.skipped_updates,
            "largest_requested_iteration_count": self.maximum_requested_count,
            "largest_observed_state": self.maximum_observed_state,
        }


def check_grid(arithmetic, bound):
    counts = Counter()

    def equal(label, left, right, *arguments):
        if left != right:
            raise AssertionError((label, arguments, left, right))
        counts[label] += 1

    a = arithmetic
    for n in range(bound + 1):
        equal("Z_standard_value", a.Z(n), int(n == 0), n)
        equal("P_standard_value", a.P(n), n % 2, n)
        equal("m_standard_value", a.m(n), n % 3, n)
        equal("G_standard_value", a.G(n), 3 * n // 2, n)
        equal("P_period_two", a.P(n + 2), a.P(n), n)
        equal("P_double", a.P(2 * n), 0, n)
        equal("P_double_plus_one", a.P(2 * n + 1), 1, n)
        equal("P_triple", a.P(3 * n), a.P(n), n)
        equal("m_period_three", a.m(n + 3), a.m(n), n)
        equal("m_triple", a.m(3 * n), 0, n)
        equal("m_triple_plus_one", a.m(3 * n + 1), 1, n)
        equal("m_triple_plus_two", a.m(3 * n + 2), 2, n)
        equal("m_G", a.m(a.G(n)), a.P(n), n)
        equal("G_two_step", a.G(n + 2), a.G(n) + 3, n)
        equal("G_double", a.G(2 * n), 3 * n, n)
        equal("G_double_plus_one", a.G(2 * n + 1), 3 * n + 1, n)
        equal("G_triple", a.G(3 * n), 3 * a.G(n) + a.P(n), n)
        equal("T_double", a.T(2 * n), 3 * n, n)
        equal("T_double_plus_one", a.T(2 * n + 1), 1, n)
        equal("T_triple_F", a.T(3 * n), a.F(a.T(n)), n)
        equal("T_F_commute_on_image", a.T(a.F(a.T(n))), a.F(a.T(a.T(n))), n)
        equal("F_preserves_parity_on_image", a.P(a.F(a.T(n))), a.P(a.T(n)), n)
        equal("L_zero_left", a.L(0, n), 1, n)
        equal("L_successor_zero", a.L(n + 1, 0), 0, n)
        equal("L_diagonal_strict", a.L(n + 1, n), 0, n)
        equal("H_diagonal", a.H(n, n), n, n)
        equal("H_diagonal_extra_step", a.H(n + 1, n), n, n)
        equal("p_successor", a.p(n + 1), n, n)
        equal("p_standard_value", a.p(n), max(n - 1, 0), n)
        for k in range(bound + 1):
            equal("addition", a.add(n, k), n + k, n, k)
            equal("multiplication", a.mul(n, k), n * k, n, k)
            equal("U_fixed_initializer", a.U(n + 1, 3 * k), a.F(a.U(n + 1, k)), n, k)
            equal("U_odd_factor_observable", a.P(a.U(n, 3 * k)), a.P(a.U(n, k)), n, k)
            equal("U_rotation", a.U(n + 1, k), a.U(n, a.T(k)), n, k)
            equal("L_successor_diagonal", a.L(n + 1, k + 1), a.L(n, k), n, k)
            equal("L_standard_value", a.L(n, k), int(n <= k), n, k)
            equal("H_successor_conjugacy", a.H(n + 1, k + 1), a.H(n, k) + 1, n, k)
            equal("H_standard_value", a.H(n, k), min(n, k), n, k)
    equal("p_zero", a.p(0), 0)
    return {
        "parameter_grid": {"minimum": 0, "maximum": bound, "endpoints_included": True},
        "note": "Displayed successor and multiplier identities also evaluate their explicit larger arguments.",
        "assertions": sum(counts.values()),
        "counts_by_identity": dict(sorted(counts.items())),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("arithmetic_checks_results.json"))
    args = parser.parse_args()
    literal = ScalarArithmetic(accelerated=False)
    accelerated = ScalarArithmetic(accelerated=True)
    exact = check_grid(literal, 6)
    fast = check_grid(accelerated, 20)

    # Independent execution of the same G definition, with and without skips.
    for n in range(201):
        assert literal.G(n) == accelerated.G(n), ("G_acceleration", n)

    # Compare all named unary definitions at modest inputs, and all bivariate
    # definitions on the same modest grid. These are additional comparisons.
    cross_checks = 0
    unary = ("Z", "P", "m", "G", "T", "F", "E", "p")
    binary = ("add", "mul", "U", "L", "H")
    for name in unary:
        for n in range(7):
            assert getattr(literal, name)(n) == getattr(accelerated, name)(n), (name, n)
            cross_checks += 1
    for name in binary:
        for n in range(7):
            for k in range(7):
                assert getattr(literal, name)(n, k) == getattr(accelerated, name)(n, k), (name, n, k)
                cross_checks += 1

    result = {
        "status": "PASS",
        "evidence_type": "finite semantic checks, not formal proof certificates",
        "literal_iterator_grid": exact,
        "accelerated_iterator_grid": fast,
        "G_acceleration_vs_literal": {"minimum": 0, "maximum": 200, "assertions": 201},
        "other_literal_vs_accelerated_comparisons": cross_checks,
        "total_assertions": exact["assertions"] + fast["assertions"] + 201 + cross_checks,
        "literal_evaluator_statistics": literal.statistics(),
        "accelerated_evaluator_statistics": accelerated.statistics(),
        "update_interface": "operation, fixed parameters, previous scalar; no recursion counter",
        "acceleration_justification": {
            "ordinary_cycles": "exact repeated scalar state",
            "successor": "S(u+1)=S(u)+1",
            "addition_update": "(u+1)+c=(u+c)+1",
            "G_update": "g(u+3)=g(u)+3 for g(u)=u+m(u)+1, by m(u+3)=m(u)",
            "iterated_G_distinction": "G(n+2)=G(n)+3; no assertion G(n+3)=G(n)+3",
        },
    }
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": result["status"], "total_assertions": result["total_assertions"], "output": str(args.output)}, sort_keys=True))


if __name__ == "__main__":
    main()
