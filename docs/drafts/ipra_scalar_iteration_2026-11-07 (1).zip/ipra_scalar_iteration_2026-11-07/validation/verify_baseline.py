"""Reproducible finite checks of the complete protected-opening kernel.

The acceptance program imports none of this code. The named-variable oracle
and frozen checker are preserved, with hashes, from the inspected fused-binder
archive. This script adds targeted protected-opening fixtures, deterministic
certificate mutations, and actual public CLI executions. Finite agreement is
not a formal soundness or completeness proof.
"""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import types

from oracle import Oracle, opening

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
SEED = 20261107
MUTATION_COUNT = 1000


def dump(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'))


def digest(value):
    return sha256(dump(value).encode()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def kernel_verdict(module, packet):
    if type(packet) is not list:
        return False
    stream = deepcopy(packet)
    module.k = 0
    module.take = stream.pop
    try:
        return bool(module.check(stream.pop(), []))
    except Exception:
        return False


def oracle_verdict(packet):
    if type(packet) is not list:
        return {'accepted': False, 'rules': {}, 'allocations': []}
    return Oracle().run(packet)


def targeted_cases():
    truth = [0, 0]
    def paired(body, first=None, second=None):
        return [body, truth if first is None else first,
                truth if second is None else second]
    one = [0]
    recursor_witness = [0, [0], 3]
    result = []
    def add(name, packet, expected, reason):
        result.append({'name': 'targeted/' + name, 'packet': packet,
                       'expected': expected, 'reason': reason,
                       'origin': 'new targeted fixture'})

    # Both D coordinates occur. The outer witness must be substituted while
    # the inner coordinate remains bound until the subsequent local step.
    add('protected_inner_coordinate', [[], [one],
        paired([[0, 1, 7], 1])], True,
        'Retain inner y in the initializer; open outer x in the update.')
    add('protected_even_aliases', [[], [one],
        paired([[0, 2, 8], 2])], True,
        'Repeat the same scope boundary with even coordinate aliases.')
    add('outer_witness_in_initializer', [[], [recursor_witness],
        paired([[0, 3, 5], 3])], True,
        'Insert a locally closed recursor witness while protecting inner y.')
    add('doubly_nested_recursion_scope', [[], [one],
        paired([[0, 1, [0, 5, 11]], 1])], True,
        'Open the outer D coordinate beneath two numerical update binders.')
    add('used_closed_recursive_witness', [[recursor_witness],
        paired([3, 3])], True,
        'Bound variables belonging to the witness itself remain legal.')
    add('unused_null_witness', [[None], paired(truth)], True,
        'The declared demand policy permits an unused annotation.')
    add('unused_malformed_witness', [[[0, 0, 99]], paired(truth)], True,
        'A witness that is never inserted can be replaced semantically by zero.')
    add('valid_both_coordinate_padding', [[0],
        paired(truth, [1, 3], [2, 4])], True,
        'Both D binders are in scope in each inert but validated padding field.')
    previous = [0, [0], [0, 1, 7]]
    add('simultaneous_recursion_images', [[],
        [[[0], [0], [0, 1, 7]], [0, previous, 0]]], True,
        'The successor schema substitutes previous value and counter simultaneously.')
    add('recursion_zero', [[], [[0, [0], [1]], [0]]], True,
        'The zero schema returns its initializer without executing the update.')

    add('protected_coordinate_not_a_closed_witness', [[1],
        paired([3, 3])], False,
        'The witness must be locally closed even though an inner binder is protected.')
    add('protected_even_coordinate_not_a_closed_witness', [[2],
        paired([4, 4])], False,
        'An even alias must not capture the protected inner coordinate either.')
    add('future_name_in_used_witness', [[-1], paired([3, 3])], False,
        'A name allocated by this introduction is unavailable in its witness.')
    add('future_name_deep_in_used_witness', [[[0, 0, -1]],
        paired([3, 3])], False,
        'Unused recursor updates still contribute to syntactic scope validation.')
    add('witness_capture_under_own_recursion', [[[0, 0, 5]],
        paired([3, 3])], False,
        'The witness update has only its own two binders, not the enclosing D binder.')
    add('used_float_witness', [[0.0], paired([3, 3])], False,
        'Numerical leaves are exact integers, so Python numeric equality cannot hide a float.')
    add('used_false_witness', [[False], paired([3, 3])], False,
        'Python booleans are not numerical syntax despite being int subclasses.')
    add('float_equation_leaf', [[], [[0, 0.0, 0], 0]], False,
        'Validate the complete goal before comparing a computation result.')
    add('future_name_in_inert_padding', [[0],
        paired(truth, [-1, 0])], False,
        'Padding is semantically inert but belongs to the declared raw grammar.')
    add('out_of_scope_coordinate_in_padding', [[0],
        paired(truth, [5, 5])], False,
        'A D node binds exactly two coordinates in every field.')
    add('wrong_nested_successor_result', [[],
        [[[0], [0], [0, 1, 7]], [0, previous, [0]]]], False,
        'The counter image is zero in this computation, not successor zero.')
    add('unbound_root_alias', [[], [2, 2]], False,
        'The public interface accepts closed goals without free-coordinate headers.')
    add('undeclared_root_future_name', [[], [-50, -50]], False,
        'A closed root cannot use a prospective rigid parameter.')
    add('unmatched_instruction', [None, paired(truth)], False,
        'A paired introduction requires one witness annotation.')
    add('empty_packet', [], False, 'No conclusion is supplied.')
    add('nonarray_packet', {'goal': truth}, False,
        'The complete public input is a JSON array, not an object.')
    return result


def opening_cases():
    one = [0]
    truth = [0, 0]
    return [
        ('protect_inner_open_outer', [1, 3], [one], True, 1, 0, [1, one]),
        ('protect_even_inner_open_even_outer', [2, 4], [one], True, 1, 0, [2, one]),
        ('recursor_update_outer_parameter', [[0, 1, 7], 3], [one], True, 1, 0,
         [[0, 1, one], one]),
        ('nested_logical_closure', [[3, 5]], [one], True, 1, 0, [[3, one]]),
        ('nested_paired_binder', [[5, 7], truth, truth], [one], True, 1, 0,
         [[5, one], truth, truth]),
        ('nested_numerical_updates', [[0, 1, [0, 5, 11]], 3], [one], True, 1, 0,
         [[0, 1, [0, 5, one]], one]),
        ('unused_future_image', [1, 1], [-999], True, 1, 0, [1, 1]),
        ('used_declared_parameter', [1, 3], [-1], True, 1, -2, [1, -1]),
        ('used_closed_update', [1, 3], [[0, 0, 3]], True, 1, 0,
         [1, [0, 0, 3]]),
        ('two_simultaneous_images', [1, 3, 7], [one, 0], False, 0, 0,
         [one, 0, 0]),
        ('missing_second_image', [1, 5], [one], True, 1, 0, None),
        ('positive_image_cannot_capture', [1, 3], [1], True, 1, 0, None),
        ('even_positive_image_cannot_capture', [1, 3], [2], True, 1, 0, None),
        ('future_image_rejected', [1, 3], [-1], True, 1, 0, None),
        ('future_image_below_declared_floor', [1, 3], [-3], True, 1, -2, None),
        ('image_update_cannot_capture', [1, 3], [[0, 0, 5]], True, 1, 0, None),
        ('image_boolean_rejected', [1, 3], [False], True, 1, 0, None),
        ('image_float_rejected', [1, 3], [0.0], True, 1, 0, None),
        ('inert_padding_still_opens_image', [truth, [7, 7], truth], [-1], True, 1, 0, None),
        ('formula_boolean_rejected', [False, 0], [], True, 0, 0, None),
    ]


def check_openings(candidate, reference):
    rows = []
    for name, value, images, formula, depth, lower, expected in opening_cases():
        actual = []
        for which in ('candidate', 'reference', 'oracle'):
            try:
                if which == 'oracle':
                    result = opening(deepcopy(value), deepcopy(images),
                                     formula=formula, depth=depth, lower=lower)
                else:
                    module = candidate if which == 'candidate' else reference
                    module.k = lower
                    d = 2 * depth + int(not formula)
                    if which == 'candidate':
                        result = module.inst(deepcopy(value), *deepcopy(images), d=d)
                    else:
                        result = module.inst(deepcopy(value), deepcopy(images), d)
                entry = {'valid': True, 'result': result}
            except Exception:
                entry = {'valid': False}
            actual.append(entry)
        wanted = {'valid': False} if expected is None else {'valid': True, 'result': expected}
        if any(entry != wanted for entry in actual):
            raise AssertionError((name, wanted, actual))
        rows.append({'name': name, 'expected_valid': expected is not None,
                     'protected_depth': depth, 'lower_bound': lower,
                     'all_three_agree': True})
    return rows


def paths(value, path=()):
    yield path
    if type(value) is list:
        for i, child in enumerate(value):
            yield from paths(child, path + (i,))


def at(value, path):
    for i in path:
        value = value[i]
    return value


def replace(value, path, replacement):
    if not path:
        return replacement
    at(value, path[:-1])[path[-1]] = replacement
    return value


def mutations(fixtures):
    rng = random.Random(SEED)
    seeds = [row for row in fixtures if row['expected']]
    seen = {digest(row['packet']) for row in fixtures}
    replacements = [None, True, False, 0.0, -100, -2, -1, 0, 1, 2, 3, 4, 5, 6,
                    [], {}, [0], [1], [0, 0], [0, [0]], [0, 0, 5]]
    count = 0
    attempts = 0
    while count < MUTATION_COUNT:
        attempts += 1
        if attempts > 100 * MUTATION_COUNT:
            raise RuntimeError('Could not generate enough distinct mutations')
        source = rng.choice(seeds)
        value = deepcopy(source['packet'])
        choices = list(paths(value))
        path = rng.choice(choices)
        operation = rng.randrange(7)
        if operation == 0:
            value = replace(value, path, deepcopy(rng.choice(replacements)))
            label = 'replace_subtree'
        elif operation == 1:
            node = at(value, path)
            if type(node) is list and node:
                del node[rng.randrange(len(node))]
            else:
                value = replace(value, path, [])
            label = 'delete_child'
        elif operation == 2:
            node = at(value, path)
            if type(node) is list:
                node.insert(rng.randrange(len(node) + 1), deepcopy(rng.choice(replacements)))
            else:
                value = replace(value, path, [node, 0])
            label = 'insert_child'
        elif operation == 3:
            integers = [p for p in choices if type(at(value, p)) is int]
            if not integers:
                continue
            path = rng.choice(integers)
            value = replace(value, path, at(value, path) + rng.choice((-3, -2, -1, 1, 2, 3)))
            label = 'change_integer_coordinate'
        elif operation == 4:
            value = replace(value, path, [at(value, path)])
            label = 'wrap_subtree'
        elif operation == 5:
            if type(value) is list and len(value) > 1:
                a, b = rng.sample(range(len(value)), 2)
                value[a], value[b] = value[b], value[a]
            else:
                continue
            label = 'exchange_stream_cells'
        else:
            if type(value) is not list:
                continue
            value = [deepcopy(rng.choice(replacements)), *value]
            label = 'prepend_unread_annotation'
        h = digest(value)
        if h in seen:
            continue
        seen.add(h)
        yield {'index': count, 'source': source['name'], 'operation': label,
               'subtree_path': list(path), 'sha256': h, 'packet': value}
        count += 1


def cli_checks(fixtures):
    # All new targeted cases, selected substantive inherited theorems, and the
    # three semantic attack fixtures are run through the real JSON/CLI boundary.
    selected = [row for row in fixtures if row['origin'] == 'new targeted fixture']
    wanted = ('022_universal_reflexivity', '001_encoded_forall_exists_successor',
              '008_equation_induction', '018_recursion_outer_parameter_correct',
              '024_recursion_nested_update_4', '063_existential_elimination',
              'false_inner_capture', 'false_eigenparameter_escape',
              'compound_induction_hypothesis')
    selected += [row for row in fixtures if any(row['name'].endswith(s) for s in wanted)]
    rows = []
    with tempfile.TemporaryDirectory(prefix='ipra-protected-validation-') as directory:
        path = Path(directory) / 'case.json'
        for row in selected:
            path.write_text(json.dumps(row['packet']))
            for optimized in (False, True):
                command = [sys.executable, *(['-O'] if optimized else []),
                           str(HERE / 'baseline_419.py'), str(path)]
                completed = subprocess.run(command, capture_output=True, text=True, timeout=10)
                expected = (0, 'ACCEPT') if row['expected'] else (1, 'REJECT')
                actual = (completed.returncode, completed.stdout.strip())
                if actual != expected or completed.stderr:
                    raise AssertionError((row['name'], optimized, expected, actual, completed.stderr))
                rows.append({'name': row['name'], 'optimized': optimized,
                             'expected': row['expected'], 'returncode': completed.returncode,
                             'stdout': completed.stdout.strip()})
        for name, text in (('malformed_json', '[true,'), ('trailing_json', '[] []')):
            path.write_text(text)
            completed = subprocess.run([sys.executable, str(HERE / 'baseline_419.py'), str(path)],
                                       capture_output=True, text=True, timeout=10)
            if (completed.returncode, completed.stdout.strip(), completed.stderr) != (1, 'REJECT', ''):
                raise AssertionError((name, completed.returncode, completed.stdout, completed.stderr))
            rows.append({'name': name, 'optimized': False, 'expected': False,
                         'returncode': completed.returncode, 'stdout': completed.stdout.strip()})
    return rows


def sensitivity(fixtures):
    source = (HERE / 'baseline_419.py').read_text()
    variants = [
        ('lost_inner_protection', 'b = inst(b, t, d=2)', 'b = inst(b, t, d=0)',
         'targeted/protected_inner_coordinate'),
        ('contextual_image_capture', 'inst(env[a - d >> 1], d=1)',
         'inst(env[a - d >> 1], d=d)', 'boundary/false_inner_capture'),
        ('compound_induction', 'h = [inst(b, 0), b][:2 - len(b) % 2]',
         'h = [inst(b, 0), b]', 'boundary/compound_induction_hypothesis'),
        ('skipped_goal_validation', 'if inst(a) in g:', 'if a in g:',
         'boundary/false_eigenparameter_escape'),
        ('boolean_as_integer', 'type(a) is int', 'isinstance(a, int)',
         'targeted/used_false_witness'),
    ]
    rows = []
    lookup = {row['name']: row for row in fixtures}
    for name, old, new, case in variants:
        if source.count(old) != 1:
            raise AssertionError((name, 'unexpected candidate source'))
        module = types.ModuleType(name)
        exec(compile(source.replace(old, new), name, 'exec'), module.__dict__)
        expected = lookup[case]['expected']
        actual = kernel_verdict(module, lookup[case]['packet'])
        if actual == expected:
            raise AssertionError((name, case, 'fixture did not detect deliberate defect'))
        rows.append({'defect': name, 'fixture': case, 'correct_expected': expected,
                     'defective_result': actual, 'detected': True})
    return rows


def main():
    provenance = json.loads((HERE / 'provenance.json').read_text())
    for row in provenance['files']:
        if sha256((ROOT / row['local_path']).read_bytes()).hexdigest() != row['sha256']:
            raise AssertionError(('modified frozen support', row['local_path']))
    candidate = load(HERE / 'baseline_419.py', 'protected_candidate')
    reference = load(HERE / 'frozen_fused_closed.py', 'frozen_reference')
    fixtures = json.loads((HERE / 'inherited_manifest.json').read_text())
    for row in fixtures:
        file = ROOT / row['path']
        if sha256(file.read_bytes()).hexdigest() != row['sha256']:
            raise AssertionError(('modified inherited fixture', row['path']))
        row['packet'] = json.loads(file.read_text())
    for row in targeted_cases():
        location = 'examples/targeted' if row['expected'] else 'validation/rejected/targeted'
        path = ROOT / location / (row['name'].split('/')[-1] + '.json')
        write_json(path, row['packet'])
        row['path'] = str(path.relative_to(ROOT))
        row['sha256'] = sha256(path.read_bytes()).hexdigest()
        fixtures.append(row)
    fixed_rows = []
    rules = Counter()
    allocations = 0
    for row in fixtures:
        a = kernel_verdict(candidate, row['packet'])
        b = kernel_verdict(reference, row['packet'])
        oracle = oracle_verdict(row['packet'])
        c = oracle['accepted']
        if (a, b, c) != (row['expected'],) * 3:
            raise AssertionError((row['name'], row['expected'], a, b, c))
        if row['expected']:
            rules.update(oracle['rules'])
            allocations += len(oracle['allocations'])
        fixed_rows.append({k: v for k, v in row.items() if k != 'packet'} |
                          {'packet_sha256': digest(row['packet']),
                           'candidate': a, 'frozen_reference': b, 'named_oracle': c})
    opening_rows = check_openings(candidate, reference)
    mutant_rows = []
    for row in mutations(fixtures):
        a = kernel_verdict(candidate, row['packet'])
        b = kernel_verdict(reference, row['packet'])
        c = oracle_verdict(row['packet'])['accepted']
        if not a == b == c:
            raise AssertionError(('mutation disagreement', row, a, b, c))
        mutant_rows.append({k: v for k, v in row.items() if k != 'packet'} |
                           {'candidate': a, 'frozen_reference': b, 'named_oracle': c})
        if len(mutant_rows) % 200 == 0:
            print('Verified', len(mutant_rows), 'distinct certificate mutations', flush=True)
    cli_rows = cli_checks(fixtures)
    sensitivity_rows = sensitivity(fixtures)
    manifest = [{k: v for k, v in row.items() if k != 'packet'} for row in fixtures]
    write_json(HERE / 'fixture_manifest.json', manifest)
    summary = {
        'fixed_case_count': len(fixed_rows),
        'fixed_expected_accept': sum(row['expected'] for row in fixed_rows),
        'fixed_expected_reject': sum(not row['expected'] for row in fixed_rows),
        'fixed_distinct_packets': len({row['packet_sha256'] for row in fixed_rows}),
        'opening_case_count': len(opening_rows),
        'opening_valid': sum(row['expected_valid'] for row in opening_rows),
        'opening_invalid': sum(not row['expected_valid'] for row in opening_rows),
        'mutation_count': len(mutant_rows),
        'mutation_distinct_packets': len({row['sha256'] for row in mutant_rows}),
        'mutations_absent_from_fixed_corpus': len(mutant_rows),
        'mutation_accept': sum(row['candidate'] for row in mutant_rows),
        'mutation_reject': sum(not row['candidate'] for row in mutant_rows),
        'actual_cli_runs': len(cli_rows),
        'cli_expected_accept': sum(row['expected'] for row in cli_rows),
        'cli_expected_reject': sum(not row['expected'] for row in cli_rows),
        'deliberate_kernel_defects_detected': len(sensitivity_rows),
        'all_comparisons_agree': True,
        'successful_fixed_oracle_rules': dict(rules),
        'successful_fixed_oracle_fresh_allocations': allocations,
    }
    result = {
        'scope': 'Finite validation, not a formal proof of the metatheorems.',
        'python': platform.python_version(),
        'seed': SEED,
        'candidate_sha256': sha256((HERE / 'baseline_419.py').read_bytes()).hexdigest(),
        'reference_sha256': sha256((HERE / 'frozen_fused_closed.py').read_bytes()).hexdigest(),
        'oracle_sha256': sha256((HERE / 'oracle.py').read_bytes()).hexdigest(),
        'summary': summary,
        'fixed_cases': fixed_rows,
        'protected_opening_cases': opening_rows,
        'certificate_mutations': mutant_rows,
        'cli_runs': cli_rows,
        'sensitivity': sensitivity_rows,
    }
    write_json(ROOT / 'results/verification_baseline.json', result)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
