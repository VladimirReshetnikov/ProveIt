"""Reproduce both the retained recursion baseline and primary scalar checks.

Neither verification driver is imported by the acceptance program.
"""
import verify_baseline
import verify_scalar


if __name__ == '__main__':
    print('Checking the retained two-binder recursion baseline:', flush=True)
    verify_baseline.main()
    print('Checking the primary scalar-iteration program:', flush=True)
    verify_scalar.main()
