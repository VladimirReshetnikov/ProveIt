"""Finite verification of the scalar-iteration acceptance program.

This is test support, not part of checker.py. It compares a named-binder
oracle and the independently frozen two-binder checker via a syntax
embedding that inserts an unused counter binder in each iterator update.
It also exercises the actual public CLI and deliberate defective variants.
"""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import types

from scalar_oracle import Oracle, opening
from translation import SyntaxTranslation, CounterUsed, embed_scalar, remove_unused_counter
from verify_baseline import digest, dump, write_json, load, kernel_verdict, mutations, SEED

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent


def oracle_verdict(packet):
    if type(packet) is not list:
        return {'accepted': False, 'rules': {}, 'allocations': []}
    return Oracle().run(packet)


def targeted_cases():
    truth = [0, 0]
    def paired(body):
        return [body, truth, truth]
    one = [0]
    witness = [0, one, 1]
    update = [0, 1, 3]
    previous = [0, one, update]
    rows = []
    def add(name, packet, expected, reason):
        rows.append({'name': 'scalar/targeted/' + name, 'packet': packet,
                     'expected': expected, 'reason': reason,
                     'origin': 'new scalar targeted fixture'})
    add('iteration_zero', [[], [[0, one, [1]], one]], True,
        'I(0,a;h) is literally a; the update binds exactly one value.')
    add('iteration_successor', [[], [[[0], 0, [1]], [[0, 0, [1]]]]], True,
        'I(S0,0;u.Su) is literally S(I(0,0;u.Su)).')
    add('iteration_successor_even_alias', [[], [[[0], 0, [2]], [[0, 0, [2]]]]], True,
        'Even spelling of the sole previous-value coordinate is accepted.')
    add('nested_iteration_image', [[], [[[0], one, update], [0, previous, previous]]], True,
        'Substitute the previous value beneath another update without capture.')
    add('protected_inner_outer_under_iterator', [[], [one],
        paired([[0, 1, 5], 1])], True,
        'Protect the inner D coordinate and open the outer coordinate under I.')
    add('protected_outer_even_under_iterator', [[], [one],
        paired([[0, 2, 6], 2])], True,
        'The same protected opening works for even coordinate aliases.')
    add('closed_iterator_witness', [[witness], paired([3, 3])], True,
        'A used witness may bind its own previous value.')
    add('iterator_witness_in_initializer', [[], [witness],
        paired([[0, 3, 1], 3])], True,
        'A locally closed nested iterator is inserted as an outer witness.')
    add('old_counter_coordinate_at_zero', [[], [[0, 0, 3], 0]], False,
        'The former recursor counter coordinate is unbound even at zero.')
    add('old_even_counter_coordinate_at_zero', [[], [[0, 0, 4], 0]], False,
        'The even alias of the removed counter is also unbound.')
    add('old_counter_coordinate_at_successor', [[], [[[0], 0, 3], 0]], False,
        'An iterator update cannot refer to a previous counter.')
    add('incorrect_iteration_successor_result', [[], [[[0], 0, [1]], [0]]], False,
        'The computation rule does not silently normalize the previous iterate.')
    add('capture_protected_inner_witness', [[], [1],
        paired([[0, 3, 1], 3])], False,
        'A used witness is validated as locally closed, not in the protected scope.')
    add('capture_protected_even_inner_witness', [[], [2],
        paired([[0, 4, 1], 4])], False,
        'Even aliases cannot capture a protected D coordinate.')
    add('witness_old_counter_coordinate', [[[0, 0, 3]], paired([3, 3])], False,
        'A used witness has one local update binder, not two.')
    add('nested_update_future_name', [[], [[0, 0, [0, 1, -1]], 0]], False,
        'All goal syntax is checked, including a future name in an unused update.')
    return rows


def fixed_fixtures():
    rows, skipped = [], []
    for row in json.loads((HERE / 'fixture_manifest.json').read_text()):
        source = ROOT / row['path']
        if sha256(source.read_bytes()).hexdigest() != row['sha256']:
            raise AssertionError(('changed baseline fixture', row['path']))
        packet = json.loads(source.read_text())
        try:
            scalar = remove_unused_counter(packet)
        except CounterUsed:
            skipped.append({'name': row['name'], 'reason': 'A numerical update uses its counter.'})
            continue
        if embed_scalar(scalar) != packet:
            raise AssertionError(('nonidentity inverse translation', row['name']))
        new = {**row, 'name': 'scalar/inherited/' + row['name'], 'packet': scalar,
               'origin': 'counter-free baseline fixture',
               'baseline_path': row['path'], 'baseline_sha256': row['sha256']}
        rows.append(new)
    rows += targeted_cases()
    for row in rows:
        prefix = 'examples/scalar' if row['expected'] else 'validation/rejected/scalar'
        suffix = row['name'].removeprefix('scalar/') + '.json'
        path = ROOT / prefix / suffix
        write_json(path, row['packet'])
        row['path'] = str(path.relative_to(ROOT))
        row['sha256'] = sha256(path.read_bytes()).hexdigest()
    return rows, skipped


def opening_cases():
    one, truth = [0], [0, 0]
    return [
        ('protect_inner_open_outer', [1, 3], [one], True, 1, 0, [1, one]),
        ('protect_even_aliases', [2, 4], [one], True, 1, 0, [2, one]),
        ('iterator_outer_parameter', [[0, 1, 5], 3], [one], True, 1, 0,
         [[0, 1, one], one]),
        ('nested_logical_closure', [[3, 5]], [one], True, 1, 0, [[3, one]]),
        ('nested_paired_binder', [[5, 7], truth, truth], [one], True, 1, 0,
         [[5, one], truth, truth]),
        ('nested_numerical_updates', [[0, 1, [0, 3, 7]], 3], [one], True, 1, 0,
         [[0, 1, [0, 3, one]], one]),
        ('unused_future_image', [1, 1], [-999], True, 1, 0, [1, 1]),
        ('used_declared_parameter', [1, 3], [-1], True, 1, -2, [1, -1]),
        ('used_closed_iterator', [1, 3], [[0, 0, 1]], True, 1, 0,
         [1, [0, 0, 1]]),
        ('two_simultaneous_images', [1, 3, 5], [one, 0], False, 0, 0,
         [one, 0, 0]),
        ('missing_second_image', [1, 5], [one], True, 1, 0, None),
        ('positive_image_cannot_capture', [1, 3], [1], True, 1, 0, None),
        ('even_image_cannot_capture', [1, 3], [2], True, 1, 0, None),
        ('future_image_rejected', [1, 3], [-1], True, 1, 0, None),
        ('future_image_below_floor', [1, 3], [-3], True, 1, -2, None),
        ('image_iterator_cannot_capture', [1, 3], [[0, 0, 3]], True, 1, 0, None),
        ('image_boolean_rejected', [1, 3], [False], True, 1, 0, None),
        ('image_float_rejected', [1, 3], [0.0], True, 1, 0, None),
        ('inert_padding_opens_image', [truth, [7, 7], truth], [-1], True, 1, 0, None),
        ('formula_boolean_rejected', [False, 0], [], True, 0, 0, None),
    ]


def check_openings(candidate, reference):
    embed = SyntaxTranslation(1, 2)
    rows = []
    for name, value, images, formula, depth, lower, expected in opening_cases():
        mapping = tuple(range(depth))
        translate = embed.formula if formula else embed.term
        actual = []
        for which in ('candidate', 'oracle', 'embedded_reference'):
            try:
                if which == 'oracle':
                    result = opening(deepcopy(value), deepcopy(images),
                                     formula=formula, depth=depth, lower=lower)
                elif which == 'candidate':
                    candidate.k = lower
                    result = candidate.inst(deepcopy(value), *deepcopy(images),
                                            d=2*depth + int(not formula))
                else:
                    reference.k = lower
                    result = reference.inst(translate(value, mapping, depth),
                                            *(embed.term(image) for image in images),
                                            d=2*depth + int(not formula))
                wanted = translate(expected, mapping, depth) if which == 'embedded_reference' else expected
                verdict = expected is not None and result == wanted
            except Exception:
                verdict = expected is None
            actual.append(verdict)
        if not all(actual):
            raise AssertionError(('opening disagreement', name, actual))
        rows.append({'name': name, 'expected_valid': expected is not None,
                     'protected_depth': depth, 'lower_bound': lower,
                     'candidate_oracle_embedded_reference_agree': True})
    return rows


def check_translation():
    embed = SyntaxTranslation(1, 2)
    inverse = SyntaxTranslation(2, 1)
    examples = [
        ('previous_value', [0, 0, 1], [0, 0, 1]),
        ('previous_even_alias', [0, 0, 2], [0, 0, 2]),
        ('unbound_outer', [0, 0, 3], [0, 0, 5]),
        ('unbound_outer_even', [0, 0, 4], [0, 0, 6]),
        ('nested_outer_previous', [0, 0, [0, 1, 3]], [0, 0, [0, 1, 5]]),
        ('nested_unbound_outer', [0, 0, [0, 3, 5]], [0, 0, [0, 5, 9]]),
    ]
    rows = []
    for name, source, expected in examples:
        if embed.term(source) != expected or inverse.term(expected) != source:
            raise AssertionError(('translation boundary', name))
        rows.append({'name': name, 'expected': 'roundtrip', 'passed': True})
    for name, source in [('removed_counter', [0, 0, 3]),
                         ('removed_counter_even', [0, 0, 4]),
                         ('nested_removed_counter', [0, 0, [0, 0, 7]])]:
        try:
            inverse.term(source)
        except CounterUsed:
            rows.append({'name': name, 'expected': 'counter-used rejection', 'passed': True})
        else:
            raise AssertionError(('missed counter', name))
    return rows


def cli_checks(fixtures):
    selected = [row for row in fixtures if row['origin'] == 'new scalar targeted fixture']
    wanted = ('008_equation_induction', '018_recursion_outer_parameter_correct',
              '063_existential_elimination', 'false_eigenparameter_escape',
              'compound_induction_hypothesis', 'unused_null_witness')
    selected += [row for row in fixtures if any(row['name'].endswith(name) for name in wanted)]
    rows = []
    with tempfile.TemporaryDirectory(prefix='ipra-scalar-validation-') as directory:
        path = Path(directory) / 'case.json'
        for row in selected:
            for backend, executable, packet in [
                    ('scalar', ROOT / 'checker.py', row['packet']),
                    ('embedded_recursion', HERE / 'baseline_419.py', embed_scalar(row['packet']))]:
                path.write_text(json.dumps(packet))
                for optimized in (False, True):
                    command = [sys.executable, *(['-O'] if optimized else []), str(executable), str(path)]
                    completed = subprocess.run(command, capture_output=True, text=True, timeout=10)
                    expected = (0, 'ACCEPT') if row['expected'] else (1, 'REJECT')
                    actual = completed.returncode, completed.stdout.strip()
                    if actual != expected or completed.stderr:
                        raise AssertionError(('CLI disagreement', row['name'], backend, optimized,
                                              expected, actual, completed.stderr))
                    rows.append({'name': row['name'], 'backend': backend,
                                 'optimized': optimized, 'expected': row['expected'],
                                 'returncode': completed.returncode, 'stdout': completed.stdout.strip()})
        for name, content in [('malformed_json', '[true,'), ('trailing_json', '[] []')]:
            path.write_text(content)
            completed = subprocess.run([sys.executable, str(ROOT / 'checker.py'), str(path)],
                                       capture_output=True, text=True, timeout=10)
            if (completed.returncode, completed.stdout.strip(), completed.stderr) != (1, 'REJECT', ''):
                raise AssertionError(('malformed JSON', name))
            rows.append({'name': name, 'backend': 'scalar', 'optimized': False,
                         'expected': False, 'returncode': 1, 'stdout': 'REJECT'})
    return rows


def sensitivity(fixtures):
    source = (ROOT / 'checker.py').read_text()
    variants = [
        ('retained_previous_counter_binder', "b'\\0\\0\\2'", "b'\\0\\0\\4'",
         'scalar/targeted/old_counter_coordinate_at_zero'),
        ('lost_inner_protection', 'b = inst(b, t, d=2)', 'b = inst(b, t, d=0)',
         'scalar/targeted/protected_inner_outer_under_iterator'),
        ('contextual_image_capture', 'inst(env[a - d >> 1], d=1)',
         'inst(env[a - d >> 1], d=d)', 'scalar/targeted/capture_protected_inner_witness'),
        ('compound_induction', 'h = [inst(b, 0), b][:2 - len(b) % 2]',
         'h = [inst(b, 0), b]', 'scalar/inherited/boundary/compound_induction_hypothesis'),
        ('skipped_goal_validation', 'if inst(a) in g:', 'if a in g:',
         'scalar/inherited/boundary/false_eigenparameter_escape'),
        ('boolean_as_integer', 'type(a) is int', 'isinstance(a, int)',
         'scalar/inherited/targeted/used_false_witness'),
    ]
    lookup = {row['name']: row for row in fixtures}
    rows = []
    for name, old, new, case in variants:
        if source.count(old) != 1:
            raise AssertionError(('unexpected source in sensitivity', name))
        module = types.ModuleType(name)
        exec(compile(source.replace(old, new), name, 'exec'), module.__dict__)
        expected = lookup[case]['expected']
        actual = kernel_verdict(module, lookup[case]['packet'])
        if actual == expected:
            raise AssertionError(('fixture failed to detect deliberate defect', name, case))
        rows.append({'defect': name, 'fixture': case, 'correct_expected': expected,
                     'defective_result': actual, 'detected': True})
    return rows


def main():
    candidate = load(ROOT / 'checker.py', 'scalar_candidate')
    reference = load(HERE / 'baseline_419.py', 'two_binder_reference')
    fixtures, skipped = fixed_fixtures()
    fixed_rows = []
    rules, allocations = Counter(), 0
    for row in fixtures:
        packet = row['packet']
        embedded = embed_scalar(packet)
        if remove_unused_counter(embedded) != packet:
            raise AssertionError(('scalar embedding roundtrip', row['name']))
        a = kernel_verdict(candidate, packet)
        b = kernel_verdict(reference, embedded)
        oracle = oracle_verdict(packet)
        c = oracle['accepted']
        if (a, b, c) != (row['expected'],)*3:
            raise AssertionError(('fixed disagreement', row['name'], row['expected'], a, b, c))
        if a:
            rules.update(oracle['rules'])
            allocations += len(oracle['allocations'])
        fixed_rows.append({key: value for key, value in row.items() if key != 'packet'} |
                          {'packet_sha256': digest(packet), 'candidate': a,
                           'embedded_two_binder_reference': b, 'named_scalar_oracle': c})
    opening_rows = check_openings(candidate, reference)
    translation_rows = check_translation()
    mutant_rows = []
    for row in mutations(fixtures):
        packet = row['packet']
        embedded = embed_scalar(packet)
        if remove_unused_counter(embedded) != packet:
            raise AssertionError(('mutation embedding roundtrip', row['index']))
        a = kernel_verdict(candidate, packet)
        b = kernel_verdict(reference, embedded)
        c = oracle_verdict(packet)['accepted']
        if not a == b == c:
            write_json(HERE / 'scalar_debug_mutation.json', row)
            raise AssertionError(('mutation disagreement', row['index'], row['source'], a, b, c))
        mutant_rows.append({key: value for key, value in row.items() if key != 'packet'} |
                           {'candidate': a, 'embedded_two_binder_reference': b,
                            'named_scalar_oracle': c, 'translation_roundtrip': True})
    cli_rows = cli_checks(fixtures)
    sensitivity_rows = sensitivity(fixtures)
    manifest = [{key: value for key, value in row.items() if key != 'packet'} for row in fixtures]
    write_json(HERE / 'scalar_fixture_manifest.json', manifest)
    summary = {
        'fixed_case_count': len(fixed_rows),
        'fixed_expected_accept': sum(row['expected'] for row in fixed_rows),
        'fixed_expected_reject': sum(not row['expected'] for row in fixed_rows),
        'fixed_distinct_packets': len({row['packet_sha256'] for row in fixed_rows}),
        'inherited_counter_free_cases': len(fixtures)-len(targeted_cases()),
        'excluded_counter_using_baseline_cases': len(skipped),
        'new_scalar_targeted_cases': len(targeted_cases()),
        'opening_case_count': len(opening_rows),
        'opening_valid': sum(row['expected_valid'] for row in opening_rows),
        'opening_invalid': sum(not row['expected_valid'] for row in opening_rows),
        'translation_boundary_cases': len(translation_rows),
        'mutation_count': len(mutant_rows),
        'mutation_distinct_packets': len({row['sha256'] for row in mutant_rows}),
        'mutations_absent_from_fixed_corpus': len(mutant_rows),
        'mutation_accept': sum(row['candidate'] for row in mutant_rows),
        'mutation_reject': sum(not row['candidate'] for row in mutant_rows),
        'actual_cli_runs': len(cli_rows),
        'scalar_cli_runs': sum(row['backend']=='scalar' for row in cli_rows),
        'embedded_reference_cli_runs': sum(row['backend']=='embedded_recursion' for row in cli_rows),
        'cli_expected_accept': sum(row['expected'] for row in cli_rows),
        'cli_expected_reject': sum(not row['expected'] for row in cli_rows),
        'deliberate_kernel_defects_detected': len(sensitivity_rows),
        'all_comparisons_agree': True,
        'successful_fixed_oracle_rules': dict(rules),
        'successful_fixed_oracle_fresh_allocations': allocations,
    }
    result = {
        'scope': 'Finite implementation validation, not a formal proof of soundness or bi-interpretability.',
        'comparison': '417-token scalar checker; named-binder scalar oracle; I-to-R embedding into 419-token recursion checker.',
        'python': platform.python_version(), 'seed': SEED,
        'candidate_sha256': sha256((ROOT / 'checker.py').read_bytes()).hexdigest(),
        'reference_sha256': sha256((HERE / 'baseline_419.py').read_bytes()).hexdigest(),
        'oracle_sha256': sha256((HERE / 'scalar_oracle.py').read_bytes()).hexdigest(),
        'translation_sha256': sha256((HERE / 'translation.py').read_bytes()).hexdigest(),
        'summary': summary, 'fixed_cases': fixed_rows,
        'excluded_baseline_cases': skipped, 'protected_opening_cases': opening_rows,
        'translation_boundary_cases': translation_rows,
        'certificate_mutations': mutant_rows, 'cli_runs': cli_rows,
        'sensitivity': sensitivity_rows,
    }
    write_json(ROOT / 'results/verification.json', result)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
