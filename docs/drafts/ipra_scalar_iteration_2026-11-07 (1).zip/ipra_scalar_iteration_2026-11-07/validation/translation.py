"""Syntax translations between scalar iteration and mixed recursion.

Each numerical update in the source has either one binder (previous value)
or two (previous value, previous counter). Formula binders do not change.
The embedding inserts a genuinely unused counter slot. Its partial inverse
rejects an occurrence of that counter, including beneath nested binders.

Malformed annotations are retained as data, so ignored certificate prefixes
and unused witness annotations do not become additional trust requirements.
No proof-search, computation, or theorem decision is performed here.
"""
from copy import deepcopy


class CounterUsed(ValueError):
    pass


def shifted(mapping, amount):
    return tuple(None if index is None else index + amount for index in mapping)


class SyntaxTranslation:
    def __init__(self, source_update_binders, target_update_binders):
        if (source_update_binders, target_update_binders) not in ((1, 2), (2, 1)):
            raise ValueError('Expected scalar-to-mixed or counter-free mixed-to-scalar')
        self.source = source_update_binders
        self.target = target_update_binders

    def term(self, value, mapping=(), target_depth=0):
        if type(value) is int:
            if value <= 0:
                return value
            source_index, alias = divmod(value - 1, 2)
            if source_index < len(mapping):
                target_index = mapping[source_index]
                if target_index is None:
                    raise CounterUsed('An update refers to its previous counter')
            else:
                target_index = target_depth + source_index - len(mapping)
            return 2 * target_index + 1 + alias
        if type(value) is not list:
            return deepcopy(value)
        if len(value) == 1:
            return [self.term(value[0], mapping, target_depth)]
        if len(value) == 3:
            local = (0,) if self.source == 1 else (0, None)
            body_mapping = local + shifted(mapping, self.target)
            return [self.term(value[0], mapping, target_depth),
                    self.term(value[1], mapping, target_depth),
                    self.term(value[2], body_mapping, target_depth + self.target)]
        return deepcopy(value)

    def formula(self, value, mapping=(), target_depth=0):
        if type(value) is not list:
            return deepcopy(value)
        if len(value) == 2:
            return [self.term(term, mapping, target_depth) for term in value]
        if len(value) in (1, 3):
            binders = 1 if len(value) == 1 else 2
            local = tuple(range(binders))
            body_mapping = local + shifted(mapping, binders)
            return [self.formula(body, body_mapping, target_depth + binders)
                    for body in value]
        return deepcopy(value)

    def instruction(self, value):
        if type(value) is not list:
            return deepcopy(value)
        if len(value) == 1:
            return [self.term(value[0])]
        if len(value) == 2:
            major, annotation = value
            translated = self.formula(major)
            if type(major) is list and len(major) == 1:
                annotation = self.term(annotation)
            elif type(major) is list and len(major) == 2:
                annotation = self.formula(annotation)
            else:
                annotation = deepcopy(annotation)
            return [translated, annotation]
        return deepcopy(value)

    def packet(self, value):
        if type(value) is not list or not value:
            return deepcopy(value)
        return [*(self.instruction(cell) for cell in value[:-1]),
                self.formula(value[-1])]


def embed_scalar(packet):
    return SyntaxTranslation(1, 2).packet(packet)


def remove_unused_counter(packet):
    return SyntaxTranslation(2, 1).packet(packet)


if __name__ == '__main__':
    import argparse
    import json
    from pathlib import Path
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('packet', type=Path)
    parser.add_argument('--drop-unused-counter', action='store_true',
                        help='Convert a counter-free recursion certificate to scalar iteration.')
    arguments = parser.parse_args()
    packet = json.loads(arguments.packet.read_text())
    translate = remove_unused_counter if arguments.drop_unused_counter else embed_scalar
    print(json.dumps(translate(packet), indent=2))
