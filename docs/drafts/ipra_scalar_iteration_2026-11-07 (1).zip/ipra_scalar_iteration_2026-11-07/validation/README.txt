VALIDATION SUPPORT AND ITS LIMITS
================================

The public acceptance program is ../checker.py. It imports none of the files
in this directory. These files are untrusted explanatory and test artifacts;
they do not enlarge the measured acceptance program.

Reproduce from the archive root with:

    python3 validation/verify.py

This first checks the retained two-binder recursion baseline and then checks
the primary one-binder scalar-iteration program. It writes the detailed
machine-readable evidence to results/verification_baseline.json and
results/verification.json. Each can also be rerun on its own:

    python3 validation/verify_baseline.py
    python3 validation/verify_scalar.py

The primary scalar result compares three implementations on every fixed
fixture and generated certificate mutation:

  * checker.py, the compact primary acceptance program;
  * scalar_oracle.py, a readable interpreter using explicitly named binders;
  * baseline_419.py, after translation.py embeds each numerical iterator into
    a two-binder recursor with its previous-counter binder left unused.

The named oracle has explicit term/formula parsers, binder environments,
hole substitution and eigenparameter checks. It uses neither the compact
sort/depth encoding nor its constructor table nor its match statement.
It derives from the frozen upstream named oracle, not from an independently
devised proof calculus. scalar_oracle.py changes the numerical update binder
arity and successor computation to scalar iteration. The baseline and oracle
therefore provide useful structural diversity, without being a machine proof
of any metatheorem.

PROVENANCE

provenance.json identifies the exact inspected upstream commit, archive
members and SHA-256 hashes of oracle.py and frozen_fused_closed.py. Those two
files are unmodified snapshots from the fused-binder draft. baseline_419.py
is the retained protected-opening implementation. The scalar result records
hashes of the current checker, its scalar oracle, the translator and baseline.
All fixed fixture manifests record file hashes and expected verdicts.

SCALAR FIXTURES

The primary accepted examples are under examples/scalar/. Corresponding
rejection fixtures are under validation/rejected/scalar/. The primary corpus
has 98 named cases: 55 expected acceptances and 43 expected rejections. Some
case labels cover identical JSON packets, so there are 89 distinct packets.
Eighty-two cases are obtained by deleting provably unused update-counter
slots from baseline syntax; 18 baseline cases that actually use those slots
are excluded rather than reinterpreted. Sixteen scalar-specific cases cover
I(0), I(Sn), coordinate aliases, nested updates, protected D opening, local
witness closure, forbidden old counter coordinates, and future names.

The old examples/upstream/, examples/upstream_boundaries/, examples/targeted/
and matching rejection directories are the retained TWO-BINDER BASELINE
corpus. They are not all inputs for the primary scalar checker. Use the
scalar_fixture_manifest.json paths for the primary program.

Additional checks cover 20 direct opening boundaries (10 valid, 10 invalid)
and nine translation boundaries. A seeded mutation generator produces 1000
distinct packets absent from the fixed corpus. It changes syntax and stream
positions, wraps/deletes/inserts data, and adds unread annotations. Mutations
are not assumed false: the final scalar run accepts 251 and rejects 749.
All three implementations agree on every verdict, and every scalar packet
roundtrips through the embedding and its counter-free inverse.

The driver performs 90 actual CLI invocations: 46 primary and 44 embedded
baseline executions, including both normal Python and python -O on selected
fixtures and malformed JSON through the primary public boundary. These runs
contain 48 expected acceptances and 42 expected rejections. Six deliberately
defective checker variants are detected by dedicated fixtures: the removed
counter binder accidentally retained, loss of protected inner scope,
contextual capture in substitution images, compound-formula induction,
skipped goal validation, and treating booleans as numerical syntax.

SCOPE OF THE TRANSLATION

The syntax embedding retains formula binders. In an iterator update it maps
its previous-value coordinate to the recursor previous-value coordinate,
inserts the unused previous-counter slot, and shifts every outer coordinate
accordingly, including beneath nested updates and formula binders. Alias
spelling is retained. A malformed unbound scalar coordinate remains unbound
in its recursor translation. The inverse raises CounterUsed if an update
really mentions the inserted counter. No evaluator or proof search is used.

Example:

    python3 validation/translation.py examples/scalar/targeted/nested_iteration_image.json > /tmp/embedded-ipra.json
    python3 validation/baseline_419.py /tmp/embedded-ipra.json

The optional --drop-unused-counter switch performs the partial inverse.
Unused witnesses and unread certificate prefixes remain ordinary data:
validation follows the same demand boundary as the acceptance interface.

WHAT THESE RESULTS DO NOT ESTABLISH

Finite tests do not establish soundness, primitive-recursive completeness,
ordinary bi-interpretability, consistency, or global minimality. The paper's
mathematical arguments carry those claims and their stated qualifications.
The tests exercise the implementation, binding translation, parser boundary,
and several concrete attacks. No SAT/SMT solver, native extension, network
resource, generated lemma file, or test oracle is trusted by checker.py.
