"""Reproduce the whole-program comparison under CPython's AST convention."""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
IGNORED = {tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
           tokenize.ENCODING}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node
    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def significant(text):
    return sum(token.type not in IGNORED
               for token in tokenize.generate_tokens(io.StringIO(text).readline))


def metrics(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    parsed = ast.parse(source)
    doclines = set()
    for node in ast.walk(parsed):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            body = node.body
            if (body and isinstance(body[0], ast.Expr)
                    and isinstance(body[0].value, ast.Constant)
                    and isinstance(body[0].value.value, str)):
                doclines.update(range(body[0].lineno, body[0].end_lineno + 1))
    # Source token accounting excludes only the actual docstring token.
    source_tokens = sum(t.type not in IGNORED and not
                        (t.type == tokenize.STRING and t.start[0] in doclines)
                        for t in tokenize.generate_tokens(io.StringIO(source).readline))
    tree = ast.fix_missing_locations(StripDocstrings().visit(parsed))
    normalized = ast.unparse(tree) + '\n'
    return {'source_tokens': source_tokens,
            'normalized_tokens': significant(normalized),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode('utf-8')),
            'raw_bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    manifest = json.loads((ROOT / 'comparison/source_manifest.json').read_text())
    rows = []
    for row in manifest['programs']:
        measured = metrics(ROOT / row['local_file'])
        assert measured['sha256'] == row['sha256'], row['local_file']
        rows.append({'label': Path(row['local_file']).stem,
                     'policy': row['witness_policy'], 'interface': row['interface'],
                     **measured})
    keys = ['source_tokens', 'normalized_tokens', 'ast_nodes', 'normalized_bytes', 'raw_bytes']
    envelope = {key: min(row[key] for row in rows) for key in keys}
    selected = metrics(ROOT / 'checker.py')
    demand = metrics(ROOT / 'checker_demand.py')
    for key in ['normalized_tokens', 'ast_nodes', 'normalized_bytes']:
        assert selected[key] < envelope[key], (key, selected[key], envelope[key])
    historical = [metrics(path) for path in sorted((ROOT / 'comparison/history').glob('*.py'))]
    historical_envelope = {key: min(row[key] for row in historical) for key in keys}
    result = {'python': sys.version, 'head': manifest['repository_head'],
              'current_program_count': len(rows), 'current_envelope': envelope,
              'selected_strict': selected, 'optional_demand': demand,
              'historical_unique_programs': len(historical),
              'historical_envelope': historical_envelope, 'current_programs': rows}
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    (results / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (results / 'metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows + [{'label': 'NEW_strict', 'policy': 'strict', 'interface': 'theorem', **selected},
                                {'label': 'NEW_demand', 'policy': 'demand', 'interface': 'theorem', **demand}])
    macros = {'NewTokens': selected['normalized_tokens'], 'NewAST': selected['ast_nodes'],
              'NewBytes': selected['normalized_bytes'], 'OldTokens': envelope['normalized_tokens'],
              'OldAST': envelope['ast_nodes'], 'OldBytes': envelope['normalized_bytes'],
              'TokenDrop': envelope['normalized_tokens'] - selected['normalized_tokens'],
              'ASTDrop': envelope['ast_nodes'] - selected['ast_nodes'],
              'ByteDrop': envelope['normalized_bytes'] - selected['normalized_bytes']}
    (results / 'metrics.tex').write_text(''.join('\\newcommand{\\' + name + '}{' + str(value) + '}\n'
                                              for name, value in macros.items()))
    lines = ['\\begin{center}\\small', '\\begin{tabular}{llrrr}', '\\toprule',
             'Draft / variant & Policy & Tokens & AST & Bytes\\\\', '\\midrule']
    for row in rows:
        label = row['label'].replace('__checker', '').replace('_', ' ')
        label = label.replace('automatic goal kernel', 'automatic goal')
        lines.append(f"{label} & {row['policy']} & {row['normalized_tokens']} & {row['ast_nodes']} & {row['normalized_bytes']}\\\\")
    lines += ['\\midrule', f"\\textbf{{New unary closure}} & strict & \\textbf{{{selected['normalized_tokens']}}} & \\textbf{{{selected['ast_nodes']}}} & \\textbf{{{selected['normalized_bytes']}}}\\\\", '\\bottomrule', '\\end{tabular}', '\\end{center}']
    (results / 'comparison_table.tex').write_text('\n'.join(lines) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'current_programs'}, indent=2))


if __name__ == '__main__':
    main()
