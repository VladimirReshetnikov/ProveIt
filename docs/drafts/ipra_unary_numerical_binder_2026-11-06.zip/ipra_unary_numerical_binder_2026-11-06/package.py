"""Create the deliverable ZIP and an integrity manifest."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
BUILD_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.fls', '.fdb_latexmk', '.pyc'}


def deliverable(path):
    return (path.is_file() and '__pycache__' not in path.parts
            and path.suffix not in BUILD_SUFFIXES
            and path.name != 'MANIFEST.sha256')


def main():
    files = sorted(path for path in ROOT.rglob('*') if deliverable(path))
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(''.join(hashlib.sha256(path.read_bytes()).hexdigest()
                                + '  ' + path.relative_to(ROOT).as_posix() + '\n'
                                for path in files))
    archive = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for path in sorted(files + [manifest]):
            out.write(path, ROOT.name + '/' + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None
    standalone = ROOT.parent / (ROOT.name + '.pdf')
    shutil.copyfile(ROOT / 'report.pdf', standalone)
    print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
                      'files': len(files) + 1,
                      'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                      'pdf': str(standalone)}, indent=2))


if __name__ == '__main__':
    main()
