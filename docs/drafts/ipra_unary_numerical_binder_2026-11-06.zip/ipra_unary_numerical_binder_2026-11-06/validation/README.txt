INDEPENDENT AUDIT OF THE UNARY-Q CHECKER
======================================

Run from any working directory:

  python3 validation/audit.py --checker /absolute/path/to/checker.py

The audit writes validation/results.json and validation/fixtures.json.
Only the Python standard library is required.  The acceptance checker
does not import any file in this validation directory.

reference.py is an independently written rule interpreter.  It parses
numerical terms and formulas into different named-variable dataclasses.
Its binders receive distinct names, substitution is ordinary capture-free
replacement by names, and equality is checked by alpha normalization.
This differs from the measured checker's de Bruijn prefix substitution,
width tables, and structural pattern dispatch.

The named interpreter implements the precise certificate protocol:

  * Q introduction has one child and gives its branch B(0), together with
    B(y) only when B is literally an equation; the goal is B(S(y)).
  * Q elimination requires both its Q-major and the base minor B(0).
  * Existential introduction remembers a strictly validated numerical
    witness through a fresh equality; elimination cannot leak its eigenvariable.
  * Equality elimination checks the displayed formula motive and both
    instantiated endpoints.
  * R0 and RS are unfolded by named accumulator/predecessor substitution.
  * Existing assumptions justify the fallback rule.  A selected malformed
    inference raises an invalid-certificate condition and cannot become
    a failed major that silently falls back to a surrounding hypothesis.

The seed corpus generated_sequents.json contains 23 independently
constructed derivations from the proof-builder agent.  These include
17 theorems and six open sequents.  The audit checks all 23 by the named
interpreter and adds hand-labeled adversarial and positive fixtures.

Executed on the selected strict checker:

  102 targeted cases: 30 accept and 72 reject;
  630 generated instances of the logical/computation rules;
  1,200 deterministic bounded certificate mutations, with 133 accepted
    and 1,067 rejected by both implementations;
  900 transformations compared with independent named substitution;
  24 real command-line runs, split equally between ordinary Python and -O;
  four deliberate logical/validation faults, each detected by a specifically
    relevant negative fixture.

The detected faults are unrestricted quantified induction hypotheses,
omitted Q-elimination base premises, existential-goal capture, and skipped
validation of an unused universal witness.  These sensitivity checks show
that the corresponding test cases reach the intended protection.

Public acceptance remains theorem-only: [goal, proof].  A supplied third
field cannot add assumptions, even if it is an empty list.  Internal
open-sequent tests pass independently validated assumptions to exercise
individual logical rules.  They are not unconditional theorem claims.

All positive numerical variable indices are legal free parameters when
they occur outside binders.  There is no fixed maximum context arity, so
a large index is not itself an out-of-scope error.  Scope attacks instead
test illegal negative coordinates, malformed binders, substitution capture,
and existential eigenvariable escape.

The results are finite regression evidence.  They do not constitute an
exhaustive or machine-checked proof of the checker-correctness, arithmetic
bi-interpretability, or consistency theorems.  The mathematical proofs
must be assessed separately.
