iPRA WITH UNARY NUMERICAL CLOSURE
Research report for Vladimir Reshetnikov, 6 November 2026

Start with report.pdf. Its complete LaTeX source is report.tex plus sections/.

MAIN RESULT
The native binder Q_x B has the ordinary meaning B(0) -> forall x B(x).
Q introduction retains B(0) in every case and supplies B(y) as an additional
induction hypothesis only when B is literally an equation. With equality,
existence, and the two initialized-recursion equations, this gives a faithful
presentation of an ordinary theory bi-interpretable and equiconsistent with
full first-order intuitionistic primitive recursive arithmetic.

The complete strict checker is checker.py:
  539 normalized significant Python tokens
  554 executable AST nodes
  1684 normalized UTF-8 bytes
The respective minima over all 13 current draft programs are 543,562,1688.
The six archives are pinned at ProveIt commit
fa581763b2bb75e8ba055da8e56280c9fd5dd890.

This is a finite-corpus improvement, not a proof of absolute minimality.
The mathematical correctness arguments are written proofs. No complete
Lean or Rocq formalization is claimed. Executable tests are independent
supporting evidence and are distinguished from those general proofs.

FILES
  checker.py                 Complete strict theorem-acceptance program.
  checker_demand.py          Optional demand-validation comparison program.
  FORMAT.txt                 Exact syntax and certificate conventions.
  examples/                  Concrete theorem inputs and retained-context cases.
  validation/                Untrusted proof builders and independent validator.
  comparison/sources/        All 13 current comparator programs, unchanged.
  comparison/history/        223 distinct historical acceptance candidates.
  comparison/*.json          Provenance, source hashes, and broad census.
  results/                   Reproduced sizes and verification results.
  measure.py                 Common complete-program measurement.
  reproduce.py               Regenerate examples, metrics, and validation results.
  MANIFEST.sha256            Delivered-file integrity checks.
  LICENSE_SOURCE.txt         Preserved license for inherited source material.

REPRODUCE
Use CPython 3.12 to match the reported AST/unparse conventions.
No third-party Python packages are required.

  python3 reproduce.py
  python3 checker.py examples/equation_induction_at_parameter.json

The second command prints ACCEPT. In particular, neither a proof builder
nor the independent validator is imported by checker.py.

BUILD THE PAPER
With a standard TeX Live installation:

  python3 build.py

The script uses pdfLaTeX and generates a temporary format if necessary.
With an already configured TeX installation, latexmk -pdf report.tex also
works. The compiled PDF is supplied in the archive.

REPORTING LIMITS
The public strict interface accepts [goal,proof] only. Internal open-sequent
tests validate their assumptions separately. Arbitrary free number variables
are parameters. The mathematical calculus has no fixed size/depth bound;
an actual Python execution may reject otherwise valid inputs exceeding its
available memory, stack, or JSON decoding resources.

The optional demand checker has the same theorem set under annotation
repair, but may ignore a malformed numerical witness if the witness is
unused. The strict checker is the main deliverable and rejects that case.
