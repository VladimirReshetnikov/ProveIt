"""Regenerate the comparison and meaningful verification artifacts."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(*arguments):
    subprocess.run([sys.executable, *map(str, arguments)], cwd=ROOT, check=True)


def main():
    run('measure.py')
    run('validation/build_examples.py', 'checker.py', 'examples')
    shutil.copyfile(ROOT / 'examples/generated_sequents.json',
                    ROOT / 'validation/generated_sequents.json')
    run('validation/audit.py', '--checker', 'checker.py')
    shutil.copyfile(ROOT / 'validation/results.json', ROOT / 'results/audit.json')
    run('validation/run_transform_checks.py', '--checker', 'checker.py',
        '--corpus', 'examples/generated_sequents.json',
        '--output', 'results/transforms.json')
    run('validation/logic_certificates.py', '--checker', 'checker.py',
        '--reference', 'validation/reference.py', '--output', 'examples/logic')
    shutil.copyfile(ROOT / 'examples/logic/logic_summary.json', ROOT / 'results/logic.json')
    logic = json.loads((ROOT / 'results/logic.json').read_text())
    assert logic['kernel_accepted'] and logic['independent_reference_accepted']
    for result in ['audit.json', 'transforms.json']:
        data = json.loads((ROOT / 'results' / result).read_text())
        assert data.get('status') == 'passed' or data.get('passed') is True, result
    print('All reproduction gates passed.')


if __name__ == '__main__':
    main()
