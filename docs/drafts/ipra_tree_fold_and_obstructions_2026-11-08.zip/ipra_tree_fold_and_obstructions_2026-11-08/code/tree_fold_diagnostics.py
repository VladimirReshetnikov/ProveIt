#!/usr/bin/env python3
"""Finite diagnostics for the tree-fold constructions in the paper.

This is an evaluator, NOT a proof checker and NOT a formalization of the
bi-interpretation. Natural arithmetic in this diagnostic uses Python integers.
Trees are hash-consed immutable values. Only the fold evaluator reads a node's
children in the implementations of the derived projections. The oracle in
main() separately reads the children when checking the answers.
"""

from functools import lru_cache
from math import isqrt
from pathlib import Path
import json
import platform


class Trees:
    def __init__(self):
        self.nodes = [None]
        self.intern = {}

    def pair(self, left, right):
        key = (left, right)
        if key not in self.intern:
            self.intern[key] = len(self.nodes)
            self.nodes.append(key)
        return self.intern[key]

    def fold(self, tree, initial, update):
        values = {0: initial}
        stack = [(tree, False)]
        while stack:
            current, ready = stack.pop()
            if current in values:
                continue
            left, right = self.nodes[current]
            if ready:
                values[current] = update(values[left], values[right])
            else:
                stack.extend(((current, True), (right, False), (left, False)))
        return values[tree]

    @lru_cache(maxsize=None)
    def rank(self, tree):
        return self.fold(tree, 0, lambda left, right: 1 + left + right)

    def guarded_fold(self, tree, bound, side=0, faulty=False):
        def update(left, right):
            candidate = self.pair(left, right)
            below = self.rank(candidate) <= bound if faulty else self.rank(candidate) < bound
            return candidate if below else (left if side == 0 else right)
        return self.fold(tree, 0, update)

    @lru_cache(maxsize=None)
    def left(self, tree):
        return self.guarded_fold(tree, self.rank(tree), 0)

    @lru_cache(maxsize=None)
    def right(self, tree):
        return self.guarded_fold(tree, self.rank(tree), 1)

    def paramorphism(self, tree, initial, update):
        def lifted(left_state, right_state):
            left_tree, left_value = self.left(left_state), self.right(left_state)
            right_tree, right_value = self.left(right_state), self.right(right_state)
            return self.pair(self.pair(left_tree, right_tree),
                             update(left_tree, right_tree, left_value, right_value))
        state = self.fold(tree, self.pair(0, initial), lifted)
        return self.right(state)

    @lru_cache(maxsize=None)
    def encode(self, tree):
        def step(left, right):
            total = left + right
            return 1 + total * (total + 1) // 2 + right
        return self.fold(tree, 0, step)

    @staticmethod
    def split_code(number):
        if number <= 0:
            raise ValueError('A node code must be positive')
        z = number - 1
        diagonal = (isqrt(8 * z + 1) - 1) // 2
        right = z - diagonal * (diagonal + 1) // 2
        left = diagonal - right
        if not (0 <= left < number and 0 <= right < number):
            raise ValueError('The subcode bound failed')
        return left, right

    @lru_cache(maxsize=None)
    def decode_reference(self, number):
        if number == 0:
            return 0
        left, right = self.split_code(number)
        return self.pair(self.decode_reference(left), self.decode_reference(right))

    def retrieve(self, history, offset):
        for _ in range(offset):
            history = self.right(history)
        return self.left(history)

    def history_decoder(self, limit):
        # History at n is [decode(n), ..., decode(0)], represented by tree pairs.
        history = self.pair(0, 0)
        answers = [0]
        for n in range(limit):
            a, b = self.split_code(n + 1)
            value = self.pair(self.retrieve(history, n - a),
                              self.retrieve(history, n - b))
            history = self.pair(value, history)
            answers.append(self.left(history))
        return answers


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    trees = Trees()
    by_size = [[0]]
    max_size = 9
    for size in range(1, max_size + 1):
        layer = []
        for left_size in range(size):
            right_size = size - 1 - left_size
            layer.extend(trees.pair(a, b)
                         for a in by_size[left_size] for b in by_size[right_size])
        by_size.append(layer)
    samples = [tree for layer in by_size for tree in layer]
    guard_cases = 0
    faulty_examples = []
    for tree in samples:
        expected = (0, 0) if tree == 0 else trees.nodes[tree]
        require((trees.left(tree), trees.right(tree)) == expected, 'Projection failed')
        rank = trees.rank(tree)
        for bound in (0, rank, rank + 1, rank + 2):
            for side in (0, 1):
                folded = trees.guarded_fold(tree, bound, side)
                if rank < bound:
                    require(folded == tree, 'Guarded identity failed')
                guard_cases += 1
        number = trees.encode(tree)
        require(trees.decode_reference(number) == tree, 'Tree round trip failed')
        # A paramorphism that returns the original left child checks that the
        # lifted state really carries the original subtree, not merely its size.
        require(trees.paramorphism(tree, 0, lambda a, b, x, y: a) == expected[0],
                'Paramorphism simulation failed')
        if tree and len(faulty_examples) < 5:
            bad = trees.guarded_fold(tree, rank, 0, faulty=True)
            if bad != expected[0]:
                faulty_examples.append({'tree_code': number,
                                        'correct_left_code': trees.encode(expected[0]),
                                        'faulty_left_code': trees.encode(bad)})
    require(len(faulty_examples) == 5, 'The <= mutation was not detected')
    for number in range(10000):
        require(trees.encode(trees.decode_reference(number)) == number,
                'Numerical round trip failed')
    history_limit = 128
    history_values = trees.history_decoder(history_limit)
    for number, value in enumerate(history_values):
        require(value == trees.decode_reference(number), 'History decoder failed')
    result = {
        'python': platform.python_version(),
        'scope': 'Finite evaluation only; not a universal proof or full iPRA checker.',
        'arithmetic_dependency': 'Host natural arithmetic realizes the proved numerical subsystem.',
        'max_internal_nodes': max_size,
        'catalan_layer_counts': list(map(len, by_size)),
        'trees_checked': len(samples),
        'guarded_fold_instances_checked': guard_cases,
        'projection_and_paramorphism_cases': len(samples),
        'tree_code_round_trips': len(samples),
        'numerical_code_round_trips': 10000,
        'history_decoder_values': len(history_values),
        'faulty_nonstrict_threshold_examples': faulty_examples,
        'status': 'PASS'
    }
    output = Path(__file__).resolve().parents[1] / 'evidence' / 'tree_diagnostics.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
