#!/usr/bin/env python3
"""Reproduce whole-program source measurements; never execute a checker."""
from pathlib import Path
import hashlib
import importlib.util
import json
import platform
import sys

ROOT = Path(__file__).resolve().parents[1]
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
sys.dont_write_bytecode = True


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    metric_path = ROOT / 'comparison/inherited_measure.py'
    if hashlib.sha256(metric_path.read_bytes()).hexdigest() != manifest['normalizer_sha256']:
        raise ValueError('Source normalizer checksum mismatch')
    spec = importlib.util.spec_from_file_location('inherited_measure', metric_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = []
    for entry in manifest['programs']:
        raw = (ROOT / entry['local_file']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != entry['sha256']:
            raise ValueError('Source checksum mismatch: ' + entry['local_file'])
        rows.append({**entry, **module.metrics(raw)})
    retained = [row for row in rows if row['status'] == 'retained complete checker']
    result = {
        'python': platform.python_version(), 'commit': manifest['commit'],
        'checker_programs_executed': False,
        'retained_envelope': {key: min(row[key] for row in retained) for key in FIELDS},
        'including_current_exploratory_envelope':
            {key: min(row[key] for row in rows) for key in FIELDS},
        'scope': 'Finite source inventory, not a universal complexity lower bound; '
                 'source measurement is not independent soundness verification.',
        'programs': rows
    }
    (ROOT / 'evidence/comparison.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'programs'}, indent=2))


if __name__ == '__main__':
    main()
