#!/usr/bin/env python3
"""Repeat finite diagnostics and exact inherited source measurements."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
for script in ('code/tree_fold_diagnostics.py', 'code/measure_comparison.py'):
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
print('All finite diagnostics and source measurements completed.')
