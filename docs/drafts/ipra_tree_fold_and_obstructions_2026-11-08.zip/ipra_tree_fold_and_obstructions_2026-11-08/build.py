#!/usr/bin/env python3
"""Build the main paper without network access or shell escape."""
from pathlib import Path
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    engine = shutil.which('pdflatex')
    if not engine:
        raise SystemExit('pdflatex is required; the compiled report.pdf is included.')
    build = ROOT / '.build'
    build.mkdir(exist_ok=True)
    env = dict(os.environ)
    fmt = subprocess.run(['kpsewhich', 'pdflatex.fmt'], env=env,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if not fmt.stdout.strip():
        # Installed-files-only fallback adapted from the inherited scalar report.
        trees = [str(p) for p in (Path('/usr/share/texlive/texmf-dist'),
                                 Path('/usr/share/texmf')) if p.is_dir()]
        if trees:
            env['TEXMF'] = '{' + ','.join(trees) + '}'
        cache = build / 'texformat'
        cache.mkdir(exist_ok=True)
        if not (cache / 'pdflatex.fmt').is_file():
            make = subprocess.run(['pdftex', '-ini', '-etex', '-jobname=pdflatex',
                                   '-interaction=nonstopmode', '-halt-on-error',
                                   '-no-shell-escape', 'pdflatex.ini'],
                                  cwd=cache, env=env, text=True,
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            if make.returncode:
                print(make.stdout[-12000:])
                raise SystemExit(make.returncode)
        maps = [Path('/usr/share/texmf/fonts/map/dvips/lm/lm.map')]
        maps.extend(Path('/usr/share/texlive/texmf-dist/fonts/map/dvips/amsfonts') / n
                    for n in ('cm.map', 'cmextra.map', 'symbols.map'))
        if all(p.is_file() for p in maps):
            (cache / 'pdftex.map').write_text('\n'.join(p.read_text() for p in maps))
            env['TEXFONTMAPS'] = str(cache) + os.pathsep
        env['TEXFORMATS'] = str(cache) + os.pathsep
    command = [engine, '-interaction=nonstopmode', '-halt-on-error',
               '-file-line-error', '-no-shell-escape',
               '-output-directory=' + str(build), 'report.tex']
    outputs = []
    for run in range(3):
        result = subprocess.run(command, cwd=ROOT, env=env, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        outputs.append('PASS ' + str(run + 1) + '\n' + result.stdout)
        if result.returncode:
            (ROOT / 'evidence/latex_build.txt').write_text('\n'.join(outputs))
            print(result.stdout[-12000:])
            raise SystemExit(result.returncode)
    shutil.copyfile(build / 'report.pdf', ROOT / 'report.pdf')
    (ROOT / 'evidence/latex_build.txt').write_text('\n'.join(outputs))
    log = (build / 'report.log').read_text(errors='replace')
    warnings = [line for line in log.splitlines()
                if 'Warning' in line or 'Overfull' in line or 'Underfull' in line]
    (ROOT / 'evidence/latex_warnings.txt').write_text('\n'.join(warnings) + '\n')
    print('Built report.pdf (' + str((ROOT / 'report.pdf').stat().st_size) + ' bytes).')
    print('\n'.join(warnings) if warnings else 'No TeX warnings or box diagnostics.')


if __name__ == '__main__':
    main()
