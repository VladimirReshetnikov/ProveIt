BINARY FOLDS AND THE COMPLEXITY BOUNDARY FOR INTUITIONISTIC PRA
============================================================
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date).

OUTCOME
-------
The requested strict proof-checker complexity improvement has NOT been
established. This package is research progress, not a claimed new minimum.

The main positive result is a fully specified ordinary first-order tree-fold
theory bi-interpretable with full iPRA, with an explicit dependency on the
current scalar arithmetic reconstruction theorem. Its fold sees only the
two recursive results. A fixed size threshold recovers both original-child
projections without assuming destructors or full tree recursion.

The paper gives the complete logical and nonlogical inventory, internal
guarded-equation proofs, actual encoding/decoding terms, and both nonidentity
composite isomorphisms. Independent mathematical reviews checked the main
bootstrap and coding dependencies. The proof is not Lean/Rocq-formalized.

A general product theorem rules out a large family of ordinary Horn/equational
reductions even with parameterized definable quotient domains. A separate
initializer-absorbed Mal'cev identity is proved with its recursor-extensionality
cost explicitly stated. That fragment is not claimed to be a complete iPRA
replacement.

COMPARISON
----------
The six current ZIPs were pinned at commit
12a94890af11b5e75f753260f3be00bb11ae7f08.
The retained twelve programs have minima 317 tokens / 348 AST nodes / 885 bytes.
Including the current archive's four complete exploratory variants gives
313 tokens / 347 AST nodes / 878 bytes, attained by different programs.
The wrapper variants have an explicit UTF-8 CLI convention. No new complete
tree proof checker is supplied; the evaluator is not entered in this comparison.

START HERE
----------
report.pdf                    Main compiled research paper.
report.tex, sections/          Complete editable source of the main paper.
dependencies/closed_equational/ Exact inherited mathematical dependency.
code/tree_fold_diagnostics.py  Finite tree evaluator and diagnostic checks.
code/measure_comparison.py     Whole-program source comparison, no checker execution.
comparison/                   Frozen comparator sources and inherited normalizer.
evidence/                     Reproducible results and build/verification scope.
provenance/source_snapshot.json All six current archive identities.
ATTRIBUTION.txt                Explicit contribution and dependency boundaries.
SHA256SUMS                    Integrity manifest for other packaged files.

REPRODUCTION
------------
With Python 3.10+ (recorded run: CPython 3.12.14):

    python3 reproduce.py

This uses only the standard library and needs no network access. It checks
6,918 trees up to nine internal nodes; 55,344 guarded-fold instances;
projection and paramorphism identities; tree round trips; 10,000 numerical
round trips; 129 history-decoder values; and a deliberately faulty nonstrict
threshold. These are finite diagnostics, not proofs of universal statements.

To rebuild the main PDF with a normal TeX Live/MiKTeX installation:

    python3 build.py

The build disables shell escape. Standard packages include lmodern, microtype,
geometry, amsmath, amssymb, amsthm, mathtools, booktabs, longtable, array,
enumitem, xcolor, fancyhdr, needspace, and hyperref. A compiled PDF is included.

To verify the original archive before deliberately regenerating artifacts:

    sha256sum -c SHA256SUMS

After intentional changes, python3 package.py refreshes the manifest and ZIP.

DEPENDENCY SCOPE
----------------
dependencies/closed_equational contains the unchanged main mathematical
source, PDF, and necessary TeX table from the current closed-equational
archive. Its upstream README describes that larger original package; it is
not a claim that all of its original testing infrastructure is copied here.
The new report identifies the exact theorem used and checks its hypotheses
on the definable numerical spine domain before invoking it.

No remote repository changes were made. No absolute simplestness or global
historical priority claim is made. See the paper's Further research questions.
