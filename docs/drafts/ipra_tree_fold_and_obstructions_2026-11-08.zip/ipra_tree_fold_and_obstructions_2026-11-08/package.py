#!/usr/bin/env python3
"""Create a deterministic ZIP with source, paper, evidence and dependencies."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent


def payloads():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and not any(part in {'.build', '__pycache__'}
                              for part in p.relative_to(ROOT).parts)
                  and p.suffix not in {'.pyc', '.aux', '.toc', '.out', '.log'})


def main():
    manifest = ROOT / 'SHA256SUMS'
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  '
                               + p.relative_to(ROOT).as_posix() + '\n'
                               for p in payloads() if p != manifest))
    target = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for p in payloads():
            info = zipfile.ZipInfo((Path(ROOT.name) / p.relative_to(ROOT)).as_posix(),
                                   date_time=(2026, 11, 8, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, p.read_bytes())
    print(str(target))
    print('bytes:', target.stat().st_size)


if __name__ == '__main__':
    main()
