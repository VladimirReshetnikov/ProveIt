#!/usr/bin/env python3
"""Exact finite checks for the signature-interface theorems (Python 3.10+).
No third-party packages. General theorems are proved in paper.tex.
"""
from itertools import combinations
from math import comb
from fractions import Fraction
from collections import defaultdict
import random, json, argparse


def check(ok, message):
    if not ok:
        raise AssertionError(message)


def submasks(a):
    b = a
    while True:
        yield b
        if not b:
            return
        b = (b - 1) & a


def join_closure(gens):
    F = {0}
    for g in gens:
        F |= {f | g for f in F}
    return F


def pair_signatures(n, edges=None):
    if edges is None:
        edges = list(combinations(range(n), 2))
    s = [0] * n
    for k, (i, j) in enumerate(edges):
        s[i] |= 1 << k
        s[j] |= 1 << k
    return [0 if not I else _join(s[i] for i in range(n) if I >> i & 1)
            for I in range(1 << n)], len(edges)


def _join(xs):
    z = 0
    for x in xs:
        z |= x
    return z


def projection_formula(A, n):
    full = (1 << n) - 1
    absent = _join(full ^ a for a in A).bit_count()
    return 1 + absent + sum(len({a & J for a in A})
                           for J in range(1 << n) if J.bit_count() >= 2)


def direct_fibre(A, sig, n):
    return {(a | I, sig[I], bool(I)) for a in A for I in range(1 << n)}


def ratio_near_top(n):
    return Fraction(21, 5) if n == 3 else Fraction((n + 2) * (1 << (n-1)) - n, n+1)


def audit_arbitrary(nmax):
    out = []
    for n in range(3, nmax + 1):
        sig, _ = pair_signatures(n)
        full = (1 << n) - 1
        eq = 0
        tested = 0
        for fm in range(1, 1 << (1 << n)):
            A = [a for a in range(1 << n) if fm >> a & 1]
            actual = len(direct_fibre(A, sig, n))
            formula = projection_formula(A, n)
            check(actual == formula, ('projection identity', n, A))
            check(actual * (1 << n) >= (3**n - n) * len(A), ('sharp bound', n, A))
            if actual * (1 << n) == (3**n - n) * len(A):
                eq += 1
                check(len(A) == 1 << n, ('equality classification', n, A))
            tested += 1
        check(eq == 1, ('missing equality', n))
        out.append(dict(n=n, families=tested, equality_cases=eq))
    return out


def audit_near_top(nmax):
    out = []
    for n in range(3, nmax + 1):
        full = (1 << n) - 1
        rank = [0] + [full ^ (1 << i) for i in range(n)] + [full]
        # All possible nonempty union-closed local families in these ranks.
        best = None
        winners = []
        count = 0
        for mask in range(1, 1 << len(rank)):
            A = {a for i,a in enumerate(rank) if mask >> i & 1}
            if any(a | b not in A for a in A for b in A):
                continue
            value = Fraction(projection_formula(A, n), len(A))
            check(value >= ratio_near_top(n), ('near-top lower bound', n, A, value))
            if best is None or value < best:
                best, winners = value, [sorted(A)]
            elif value == best:
                winners.append(sorted(A))
            count += 1
        check(best == ratio_near_top(n), ('near-top sharpness', n, best))
        out.append(dict(n=n, families=count, min_ratio=str(best),
                        min_frequency=str(1-1/best), attaining_fibres=winners))
    return out


def check_model(n, r, boundary, outside, m, edges=None):
    # Bits: q_0..q_{n-1}, then pair signatures, then p, then exterior.
    sig, ns = pair_signatures(n, edges)
    qmask = (1 << n) - 1
    pbit = 1 << (n+ns)
    shift = n+ns+1
    gen = [(1 << i) | (sig[1 << i] << n) | pbit for i in range(n)]
    gen += [q | (e << shift) for q,e in boundary]
    gen += [e << shift for e in outside]
    F = join_closure(gen)
    fibers = defaultdict(list)
    for U in F:
        fibers[U >> shift].append(U)
    missing = sum(not (U & pbit) for U in F)
    check(missing * (1 << r) <= len(F), ('rank theorem', n,r,boundary,outside))
    complete = edges is None
    if complete:
        check(missing * (3**n-n) <= len(F) * (1 << n), 'projection global')
    class_count = 0
    for V, Us in fibers.items():
        eligible = [q for q,e in boundary if e & V == e]
        def canonical(B):
            return _join(q for q in eligible if q & B == q)
        A = {U & qmask for U in Us if not U & pbit}
        check(A and all(a == canonical(a) for a in A), 'p-free boundary reconstruction')
        actual_local = {(U & qmask, (U >> n) & ((1 << ns)-1), bool(U&pbit)) for U in Us}
        check(actual_local == direct_fibre(A,sig,n), 'independent direct fibre construction')
        cl = defaultdict(list)
        for U in Us:
            cl[canonical(U & qmask)].append(U)
        check(set(cl) == A, 'every class has a p-free member')
        for a, members in cl.items():
            class_count += 1
            check(sum(not U&pbit for U in members) == 1, 'unique p-free member')
            check(len(members) >= 1 << r, 'conditional rank bound')
            if complete:
                top = _join(eligible)
                B = qmask ^ a
                allowed = sum(canonical(a|K)==a for K in submasks(B))
                pred = (1 << a.bit_count()) * allowed - (a.bit_count() if a == top else 0)
                check(len(members) == pred, 'exact canonical class formula')
        if complete:
            check(len(Us)==projection_formula(A,n), 'global projection formula')
            L = 1+sum(comb(n,k) for k in range(r,n+1))
            delta = 2**n-n-2**r
            check(len(Us)*L >= len(A)*(2**r*L+delta), 'strict uniform rank bound')
            if n==r+1:
                b=ratio_near_top(n)
                check(len(Us)*b.denominator >= len(A)*b.numerator, 'sharp near-top bound')
    return len(F),missing,len(fibers),class_count


def audit_models(trials,seed):
    rng=random.Random(seed)
    records = []
    for mode in ('complete', 'sparse'):
        count=0; classes=0; fibers=0; sets=0
        for _ in range(trials):
            n=rng.randint(3,7) if mode=='complete' else rng.randint(4,8)
            if mode=='sparse':
                # A cycle has degree two, with no globally private signature.
                r=2
                edges=sorted({tuple(sorted((i,(i+1)%n))) for i in range(n)})
            else:
                r=rng.randint(2,n-1); edges=None
            m=rng.randint(0,3)
            eligible_q=[q for q in range(1<<n) if q.bit_count()>=r]
            boundary=[(rng.choice(eligible_q), rng.randrange(1<<m))
                      for _ in range(rng.randint(0,10))]
            outside=[rng.randrange(1<<m) for _ in range(rng.randint(0,5))]
            N,M,V,C=check_model(n,r,boundary,outside,m,edges)
            count+=1;classes+=C;fibers+=V;sets+=N
        records.append(dict(mode=mode,models=count,distinct_sets_summed=sets,exterior_fibres=fibers,canonical_classes=classes))
    return records


def audit_witnesses():
    rows=[]
    # No rank restriction: full q cube, direct local enumeration.
    for n in range(3,9):
        sig,_=pair_signatures(n)
        A=list(range(1<<n))
        N=len(direct_fibre(A,sig,n));M=len(A)
        check(N==3**n-n,'full cube sharpness')
        rows.append(dict(kind='unrestricted_sharp',n=n,N=N,missing=M,frequency=str(Fraction(N-M,N))))
    # Exact canonical-class sharpness on complete uniform boundary.
    for n in range(3,7):
        r=n-1
        full=(1<<n)-1
        boundary=[(full^(1<<i),0) for i in range(n)]
        N,M,_,_=check_model(n,r,boundary,[],0)
        # Pure boundary includes empty; for n=3 it attains the global bound.
        if n==3:
            check(Fraction(N,M)==ratio_near_top(n),'n=3 equality')
        rows.append(dict(kind='complete_near_top',n=n,N=N,missing=M,frequency=str(Fraction(N-M,N))))
    # Boundary copies tagged by independent outside elements; no exterior gen.
    for n in (4,5,6):
        full=(1<<n)-1; r=n-1
        Nstar=(n+2)*(1<<(n-1))-n
        for m in (1,2,3,4):
            boundary=[(full^(1<<i),1<<j) for i in range(n) for j in range(m)]
            N,M,_,_=check_model(n,r,boundary,[],m)
            check(N==2**n+(2**m-1)*Nstar,'tag count N')
            check(M==1+(2**m-1)*(n+1),'tag count M')
            rows.append(dict(kind='tag_sharp_limit',n=n,tags=m,N=N,missing=M,frequency=str(Fraction(N-M,N)),limit=str(1-1/ratio_near_top(n))))
    # Explicit large-set, no-private connected example, r=3, n=5.
    n,r,m=5,3,7
    boundary=[(_join(1<<i for i in C),3) for C in combinations(range(n),r)]
    outside=[_join(1<<((j+t)%m) for t in range(r+2)) for j in range(m)]
    N,M,_,_=check_model(n,r,boundary,outside,m)
    rows.append(dict(kind='connected_example',n=n,r=r,exterior_points=m,N=N,missing=M,frequency=str(Fraction(N-M,N))))
    return rows


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--quick',action='store_true')
    args=ap.parse_args()
    report={'arbitrary_fibres':audit_arbitrary(3 if args.quick else 4),
            'near_top_fibres':audit_near_top(6 if args.quick else 9),
            'models':audit_models(40 if args.quick else 350,20261125),
            'witnesses':audit_witnesses(),
            'status':'PASS (exact integer/rational finite checks; not a formal proof)'}
    print(json.dumps(report,indent=2))

if __name__=='__main__': main()
