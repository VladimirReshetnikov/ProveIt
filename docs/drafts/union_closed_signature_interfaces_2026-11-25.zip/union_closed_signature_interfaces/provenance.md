# Research provenance and limitations

Date: 25 November 2026 (Pacific time).

## Repository inspection

The GitHub connector listed `VladimirReshetnikov/ProveIt`, branch `main`, directory
`docs/drafts`: https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts.
The directory includes draft ZIPs on entropy, local configurations, high-girth
and regular generators, substitution, rank transport, and complete layers.
Base64 file retrieval and in-memory ZIP/DEFLATE extraction through the connector
were used to examine the following documents. This was a thematic screen, not
an exhaustive reading or independent validation of the archived theorems.

| Archive (in docs/drafts) | What was inspected |
|---|---|
| `union_closed_uniform_threshold_2026-11-25.zip` | README and extensive LaTeX source, including main result and proofs of threshold and sharpness (blob 14fa30e81e9018fbf4664e4c6a4927f74ef8940a); different rooted-shadow approach. |
| `union_closed_dense_core_2026-11-25.zip` | README and provenance (blob b1c269b2ae1cdb03f91797a2bf840e96730c5934); private generators and small omitted-generator core. |
| `union_closed_substitution.zip` | README, theorem/section headings and portion of source audit (blob ed07cbc73f2d66acf503b5d34206b7bfd65afad1); complete substitution and exterior-conditioned formulas. |
| `union_closed_local_abundance.zip` | README and LaTeX theorem/section headings; exterior-conditioned high-girth tree certificates. |
| `union_closed_marked_abundance.zip` | README and LaTeX theorem/section headings; marked graph, deletion, and tagged-core results. |
| `union_closed_joint_laws_2026-11-25.zip` | README and source provenance; joint laws and concentration for regular linear generators. |
| `union_closed_cycle_certificates.zip` | README and prior-work note (blob 78e17f9a3659b69b95c53e3c54e0a8f821a365b8); oriented graph cycles, and a broader prior-work inventory. |
| `union_closed_rank_transport_2026-11-25.zip` | README (blob f4c375d5ae9b7337ed4e542950da3d602be537be); entropy transport. |
| `union_closed_extensions_2026-11-25.zip` | README (blob 2b814e8557ebd25e065d10b35d10033b31c60ee1); regular generators, multi-union entropy, filters. |
| `union_closed_trace_entropy_2026-11-25.zip` | README and provenance; trace-refinement entropy. |
| `union_closed_refinements_2026-11-25.zip` | README excerpt and file inventory (blob 6477927e6fa8d36b4696f74d46a2591001d809a7). |
| `union_closed_advances_2026-11-25.zip` | File inventory (blob 76d24159fb2ef3cff97a5488d023c382efc916a9); additional entropy and structural results. |

`union_closed_structural_theorems.zip` (blob bba38e6abe6445578e551dfc16f678f4fdb4fa56)
returned zero decoded bytes. It was not reviewed. Other listed ZIPs were not
read in full; in some cases only the directory listing or a reference in a
reviewed draft was available. Some batch output was truncated, so no claim of
review of every source entry is made. Direct raw.githubusercontent.com access
from the execution container failed (DNS). No repository changes were made.

The proof in the present manuscript is self-contained. It builds on the
common generator/dual viewpoint and the goal of exterior-conditioned marked
abundance found in these drafts, rather than depending on any of their
unverified theorem statements. The uniform-layer argument was explored but
not used. In particular we chose a signature-interface restriction instead of
attempting a new universal entropy bound.

## Public comparison

Targeted searches used combinations of `Frankl`, `union closed sets`,
`private elements`, `local marked abundance`, `boundary generators`,
`projection cardinality`, `pair signatures`, `hypergraph substitution`,
`distinct unions`, `induced subgraphs without isolated vertices`, and
`local configurations`. The relevant retrieved public results include:

- Overview: https://en.wikipedia.org/wiki/Union-closed_sets_conjecture
- Poonen (1992), Union-closed families: https://doi.org/10.1016/0097-3165(92)90068-6
- Pulaj and Wood (2025), Local configurations in union-closed families: https://doi.org/10.1080/10586458.2024.2410964
- Bruhn, Charbit, Schaudt and Telle (2015), Graph formulation: https://arxiv.org/abs/1212.4175
- El-Zahar (1997), A graph-theoretic version: https://onlinelibrary.wiley.com/doi/abs/10.1002/%28SICI%291097-0118%28199711%2926%3A3%3C155%3A%3AAID-JGT6%3E3.0.CO%3B2-Q
- Gilmer (2022), constant lower bound: https://arxiv.org/abs/2211.09055
- Costa and Sadhu (2026), beyond Liu's threshold: https://arxiv.org/abs/2610.02295
- Quantavane (Nov. 2026), self-published report of a computer-assisted 0.383175... lower bound: https://quantavane.com/major-results/union-closed-sets-conjecture/ (not independently audited here).

The searches did not locate the precise signature-interface theorem, exact
projection count with its collision correction, or near-top-rank optima
proved in this manuscript. That is a limited novelty assessment, not proof
that these statements are unprecedented. The closest themes (conditioning,
separating generator representations, small local configurations, and
substitution) are credited; the elementary counting and signature conditions
as general techniques are not claimed novel. The restriction on allowed
exterior generators is essential and the result is not an unrestricted
Poonen FC certificate. The work is not independently refereed or formally
verified in a proof assistant. The full conjecture and its best unrestricted
bound are not improved.
