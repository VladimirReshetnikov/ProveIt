# Signature interfaces in union-closed families

Research note, 25 November 2026. Start with `paper.pdf`.

## Contents

- `paper.tex` — complete LaTeX source and proofs.
- `paper.pdf` — compiled nine-page manuscript.
- `verify.py` — standard-library Python 3.10+ exact independent-of-typesetting finite checks.
- `verification.json` — actual full verifier output, with equality cases and sharpness examples.
- `bounds.csv` — selected exact rational frequency bounds.
- `provenance.md` — inspected GitHub archives, related public work, and novelty limitations.
- `Makefile` — reproducible build and verification targets.
- `SHA256SUMS` — integrity manifest.

## Main mathematical conclusions

1. In the specified generator-interface model, separating signatures on any r
   indices and interface rank at least r give frequency >= 1-2^(-r) for a
   prescribed point p, even conditioned on canonical interface classes.
2. Complete pair signatures give an exact count in terms of all coordinate
   projections of each p-free exterior fiber. Without a rank restriction the
   sharp bound is 1-2^n/(3^n-n), n>=3.
3. At rank n-1 the sharp infimum improves to 16/21 for n=3, and
   1-(n+1)/((n+2)*2^(n-1)-n) for n>=4. The limiting constructions are explicit.
4. Sparse signature graphs with minimum degree r suffice for the first theorem.
   Connected examples have no private points, arbitrarily large minimum
   nonempty member size, and four-cycles in the incidence graph.

## Reproduce

    sha256sum -c SHA256SUMS
    python3 verify.py
    pdflatex -interaction=nonstopmode -halt-on-error paper.tex
    pdflatex -interaction=nonstopmode -halt-on-error paper.tex

`python3 verify.py --quick` performs a smaller audit. The program uses only
integers and exact Fraction comparisons; checks remain active under `python -O`.
The finite tests complement the general proofs, rather than replacing them.
A recompilation may change PDF metadata and the file checksum.

This is a structural research contribution with complete mathematical proofs,
not a solution of the unrestricted conjecture or an improved universal
frequency constant. Historical novelty is provisional. The repository audit
was selective; one listed ZIP could not be decoded. No Lean/Rocq verification
or external referee review is claimed. No changes were made to GitHub.
