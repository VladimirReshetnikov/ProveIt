EXECUTABLE CERTIFICATES

Each JSON file is [goal, proof, *hypotheses] for the complete checker.py
public interface. Integer 0 is zero; positive integers are de Bruijn
variables, starting at 1. The numeral one is ["s", 0].

Run, for example:

    python3 checker.py examples/reflexivity.json
    python3 checker.py examples/automatic_collision.json
    python3 checker.py examples/forall_exists_successor.json

The examples are translations of the 19 named certificates in the pinned
automatic-introduction archive. validate.py independently checks their
source proofs, forward acceptance, exact sequent preservation, and reverse
reconstruction. The arithmetic examples include zero/successor recursion,
successor injectivity, numerical coverage, and the equality discriminator.
They are support evidence; no example is imported by the trusted checker.
