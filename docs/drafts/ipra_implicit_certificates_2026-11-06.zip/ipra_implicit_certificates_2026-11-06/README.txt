iPRA WITH IMPLICIT PROOF INSTRUCTIONS
====================================
Prepared for Vladimir Reshetnikov -- 6 November 2026 (Pacific time)

RESULT

This package supplies a complete finite proof presentation of full first-order
intuitionistic primitive recursive arithmetic and a standalone strict
open-sequent checker. The checker is strictly below the coordinatewise minimum
of all nine complete current checker variants in the five ProveIt draft ZIPs
at commit b41e161535c2696e4ee465142e131c6c3dab3316.

                                Current minimum    This checker
  Executable Python AST nodes               582             574
  Significant source tokens                 569             547
  Normalized significant tokens             569             551
  Normalized UTF-8 source bytes            1,762           1,743
  Raw source bytes                        1,852           1,800

The complete acceptance program is counted: binding signature, formation,
substitution, all rules, JSON input, exact filename argument count, output,
and rejection. Only comments and genuine docstrings are removed from the
primary measures. The recorded normalization runtime is CPython 3.12.14.
The current minimum includes a theorem-only checker with unused-witness
erasure. The new checker supports public hypotheses and validates even
unused numerical witnesses in each selected successful inference.

This is a strict finite-source improvement, not a proof of an absolute
representation-independent minimum. The mathematical arithmetic basis is
inherited and explicitly credited. This iteration reduces certificate and
validation machinery by combining implicit introduction tags, context
membership, shared fresh-variable transitions, byte-array binding widths,
and a smaller complete syntax-validation path.

MATHEMATICAL CONTENT

report.pdf and its complete LaTeX sources specify every primitive logical
and arithmetic rule. Terms have zero, successor, and initialized recursion.
Formulas have equality, guarded universal quantification, and existence.
Automatic introduction gives equation induction or numerical cases according
to the literal matrix, and ordinary introduction is recovered by the
closed-zero detour when its shape collides with the numerical branch.

The report proves full intuitionistic logical reconstruction, quantifier-free
reflection into literal equations, all required induction instances, and
whole-domain bi-interpretability with the stated first-order iPRA. Internal
fixed-recursion uniqueness identifies each double-translated function with
the original; equality defines both composite isomorphisms. Equiconsistency
follows. These are written mathematical proofs, not Lean/Rocq metatheorems.

START HERE

  report.pdf                     Complete mathematical report.
  report.tex, sections/*.tex      All LaTeX sources.
  checker.py                     Entire trusted acceptance program.
  FORMAT.txt                     Exact syntax and certificate contract.
  examples/                      Nineteen executable theorem/sequent examples.
  comparison/                    Nine exact baseline sources, provenance, metrics.
  validation/                    Untrusted translations and independent audits.
  results/                       Recorded machine-readable evidence.
  reproduce.py                   Reproduce comparison and verification offline.
  build.py                       Rebuild report.pdf with pdfLaTeX.
  package.py                     Rebuild the manifest and ZIP.
  LICENSE_SOURCE.txt             Preserved source license.
  MANIFEST.sha256                Checksums of all other distributed files.

QUICK START

Python 3.10 or newer and its standard library suffice. For exact recorded
AST/unparse counts, use CPython 3.12.14. From the extracted package directory:

  python3 checker.py examples/reflexivity.json
  python3 checker.py examples/automatic_collision.json
  python3 checker.py examples/residual.json
  python3 reproduce.py

Acceptance prints ACCEPT and exits zero. Rejection prints REJECT and exits
one. All checks remain active with python -O. The public input is
[goal, proof, *hypotheses]. An empty context certifies an unconditional
theorem uniformly in the goal's free numerical parameters. Open assumptions
certify the displayed sequent, not an unconditional theorem.

To rebuild the PDF and archive:

  python3 build.py
  python3 package.py

The PDF build needs an installed TeX distribution and the packages declared
in report.tex. A compiled PDF is supplied, so TeX is not needed for the
checker or verification. The build helper initializes a temporary format
if the TeX sources exist but pdflatex.fmt has not been generated.

EXECUTED VERIFICATION

  * Five archive Git blob identities verified against the repository.
  * Nine complete current baseline sources retained byte for byte.
  * 239 source certificates translated forward and reconstructed backward;
    both source directions checked by the original strict checker and an
    independent rule interpreter.
  * 717 exact comparisons of conclusions and ordered hypotheses.
  * 1,200 substitutions compared with an independent named-binder algorithm.
  * All 19 examples run normally and with -O: 38 positive CLI runs.
  * 189 independently labeled adversarial fixtures: 22 accept, 167 reject;
    every fixture run normally and with -O, plus five malformed JSON inputs
    and an extra-argument rejection: 384 CLI runs.
  * The package copied to an unrelated temporary directory and reproduced
    from its parent working directory, without repository paths or network.
  * Zero failures.

These categories overlap. Finite tests supplement the written invariants;
they are not a general machine-checked soundness or internal consistency
proof. Fixed stack, memory, or time limits can reject large valid proofs.

PROVENANCE AND CONTRIBUTION

Repository: https://github.com/VladimirReshetnikov/ProveIt
Snapshot:   b41e161535c2696e4ee465142e131c6c3dab3316
Directory:  docs/drafts

All five current archives and four explicit alternative checker variants
are covered. Earlier larger benchmark numbers quoted inside their papers
are not used as the present comparison. Archive hashes, exact source paths,
and witness policies are in comparison/manifest.json. Mathematical sources
and implementation contributions are identified in the report references.

The sole checker imports no artifact from comparison/, validation/, or
examples/. Proof generation, translation, normalization metrics, independent
oracles, and the mathematical development are outside its acceptance path.

Final checker SHA-256:
8a7ebcc70a8a684e54f8fcc48e8b40df080636326716fce717c93b6a3ea60230
