VALIDATION AND TRUST BOUNDARY

Only ../checker.py decides the public acceptance verdict. It imports Python's
json and sys modules, and none of these validation, translation, corpus, or
comparison artifacts. All support here is untrusted.

Run from any current working directory:

    python3 /path/to/package/reproduce.py

or run this component alone:

    python3 /path/to/package/validation/validate.py

validate.py verifies the frozen file hashes, then checks 239 complete source
certificates and their translations. Every source and reconstructed certificate
must pass both the frozen strict source checker and an independent rule oracle.
The three exact-sequent comparisons per case check the forward number notation
change, exact reverse recovery of the goal and ordered hypotheses, and a second
forward sequent roundtrip. Proof objects need not be textually identical because
hypothesis indices are reconstructed and can be different aliases.

The source corpus contains 19 source examples and 194 earlier positive fixtures
translated into the automatic calculus. An additional 26 collision certificates
exercise its nontrivial ordinary-introduction translation. Each of these is
independently accepted before it is used; source provenance and byte hashes are
in frozen/provenance.json, and per-certificate origins are in source_corpus.json.

The binding audit compares 1200 deterministic generated cases with a separate
named-binder substitution algorithm. The CLI audit runs all 19 packaged examples
normally and with Python -O. Results are written to
../results/translation_validation.json. The separate adversarial.py component
covers explicit accepted/rejected boundary cases and writes adversarial.json.

TRANSLATION SUPPORT

translate.py converts a source automatic certificate (zero=-1, variable 0 is
nearest) to the current certificate format (zero=0, variable 1 is nearest), or
reconstructs an explicit source proof from an accepted current proof:

    python3 validation/translate.py forward SOURCE.json DESTINATION.json
    python3 validation/translate.py backward SOURCE.json DESTINATION.json

The forward operation expects a well-formed accepted automatic certificate.
Backward reconstruction is only promised on accepted current certificates.
Translated output must still be checked; running a generator is not acceptance.
Neither operation calls the current acceptance kernel.

PROVENANCE

Frozen code and original collision data are byte-identical members of the
ipra_automatic_introduction_2026-11-06.zip archive in ProveIt at commit
b41e161535c2696e4ee465142e131c6c3dab3316. The fixed positive corpus was generated
from that archive's fixtures and constructive compiler; the archive member and
checksum for every input are recorded. Unneeded historical compilers, PDFs,
negative corpora, and duplicate checkers have not been repackaged here.

The original MIT No Attribution license is preserved in ../LICENSE_SOURCE.txt.
The source oracle has its own attribution comments, also preserved unchanged.
These finite tests support the implementation argument. They do not constitute
a machine-checked general soundness theorem or an internal consistency proof.
