"""Offline source-to-kernel translation and independent binding validation.

All input files are inside this package. No GitHub access or other checkout is
needed. This is untrusted support; checker.py imports none of it.
"""
import hashlib
import importlib.util
import json
import random
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FROZEN = HERE / 'frozen'
sys.path[:0] = [str(HERE), str(FROZEN)]
import translate


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def accepted(module, data):
    try:
        goal, proof, *context = data
        for hypothesis in context:
            module.subst(hypothesis)
        return module.check(goal, proof, context) is True
    except Exception:
        return False


def sequent(data):
    return [data[0], *data[2:]]


def main():
    provenance = json.loads((FROZEN / 'provenance.json').read_text())
    for entry in provenance['files']:
        content = (FROZEN / entry['file']).read_bytes()
        if hashlib.sha256(content).hexdigest() != entry['sha256']:
            raise ValueError('Modified frozen source: ' + entry['file'])
    candidate = load(ROOT / 'checker.py', 'validated_candidate')
    source = load(FROZEN / 'automatic_checker.py', 'validated_source')
    independent = load(FROZEN / 'automatic_rule_oracle.py', 'independent_rule_oracle')
    records = []
    failures = []

    def run(name, data):
        source_kernel = accepted(source, data)
        source_oracle = independent.accepted(data, strict=True)
        if not (source_kernel and source_oracle):
            raise ValueError(('invalid source certificate', name))
        output = translate.forward(data)
        forward_ok = accepted(candidate, output)
        expected = [translate.renumber(formula, 1) for formula in sequent(data)]
        forward_exact = sequent(output) == expected
        restored = translate.backward(output)
        backward_kernel = accepted(source, restored)
        backward_oracle = independent.accepted(restored, strict=True)
        backward_exact = sequent(restored) == sequent(data)
        roundtrip_exact = sequent(translate.forward(restored)) == sequent(output)
        checks = {
            'source_kernel': source_kernel,
            'source_oracle': source_oracle,
            'forward_accepted': forward_ok,
            'forward_sequent_exact': forward_exact,
            'backward_kernel': backward_kernel,
            'backward_oracle': backward_oracle,
            'backward_sequent_exact': backward_exact,
            'sequent_roundtrip_exact': roundtrip_exact,
        }
        records.append({'name': name, **checks})
        if not all(checks.values()):
            failures.append({'name': name, 'checks': checks})
        return output

    corpus = json.loads((FROZEN / 'source_corpus.json').read_text())
    example_paths = []
    for entry in corpus:
        output = run(entry['name'], entry['certificate'])
        if entry['name'].startswith('example/'):
            path = ROOT / 'examples' / entry['name'].split('/', 1)[1]
            if json.loads(path.read_text()) != output:
                failures.append({'name': entry['name'], 'reason': 'packaged example differs from translation'})
            example_paths.append(path)
    collisions = json.loads((FROZEN / 'collision_cases.json').read_text())
    for entry in collisions:
        run('collision/' + entry['name'], entry['translated'])

    # This oracle replaces named free variables after assigning fresh names
    # to every binder; it does not reuse the kernel's index arithmetic.
    rng = random.Random(20261106)

    def term(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return rng.randrange(0, 7)
        if rng.randrange(2):
            return ['s', term(depth - 1)]
        return ['r', term(depth - 1), term(depth - 1), term(depth - 1)]

    def formula(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return ['=', term(3), term(3)]
        if rng.randrange(2):
            return ['ex', formula(depth - 1)]
        return ['pi', formula(depth - 1), formula(depth - 1)]

    substitution_checks = 0
    for index in range(1200):
        is_formula = bool(index % 2)
        expression = formula(3) if is_formula else term(4)
        count = rng.randrange(4)
        shift = rng.randrange(-count, 4)
        environment = [term(2) for _ in range(count)] + [shift]
        try:
            actual = candidate.subst(expression, environment, formula=is_formula)
            old_environment = [*[translate.renumber(t, -1) for t in environment[:-1]], environment[-1]]
            original = translate.oracle(translate.renumber(expression, -1), old_environment, formula=is_formula)
            expected = translate.renumber(original, 1)
            if actual != expected:
                failures.append({'name': 'substitution/' + str(index), 'reason': 'named oracle disagrees'})
            substitution_checks += 1
        except Exception as error:
            failures.append({'name': 'substitution/' + str(index), 'reason': repr(error)})

    cli_checks = 0
    for path in example_paths:
        for flags in ([], ['-O']):
            process = subprocess.run(
                [sys.executable, *flags, str(ROOT / 'checker.py'), str(path)],
                capture_output=True, text=True, timeout=30,
            )
            cli_checks += 1
            if process.returncode != 0 or process.stdout != 'ACCEPT\n' or process.stderr:
                failures.append({'name': 'cli/' + path.name, 'flags': flags, 'reason': 'public CLI outcome differs'})

    result = {
        'python': sys.version,
        'candidate_sha256': hashlib.sha256((ROOT / 'checker.py').read_bytes()).hexdigest(),
        'frozen_files_verified': len(provenance['files']),
        'translated': len(records),
        'source_examples': len(example_paths),
        'source_frozen_positives': len(corpus) - len(example_paths),
        'collision_cases': len(collisions),
        'exact_sequent_checks': 3 * len(records),
        'substitution_checks': substitution_checks,
        'cli_checks': cli_checks,
        'failures': failures,
        'translations': records,
    }
    destination = ROOT / 'results'
    destination.mkdir(exist_ok=True)
    (destination / 'translation_validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'translations'}, indent=2))
    if failures:
        raise SystemExit(1)
    return result


if __name__ == '__main__':
    main()
