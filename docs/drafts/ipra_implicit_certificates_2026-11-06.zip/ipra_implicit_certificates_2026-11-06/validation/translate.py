"""Untrusted translations to/from the pinned automatic-introduction calculus.

This module is not imported by the candidate checker. Reverse translation
uses an independent named-variable substitution oracle, not candidate code.
"""
import copy
import sys
from pathlib import Path

FROZEN = Path(__file__).resolve().parent / 'frozen'
sys.path.insert(0, str(FROZEN))
from named_oracle import oracle, valid


def renumber(a, delta):
    if type(a) is int:
        return a + delta
    if type(a) is list:
        return [renumber(b, delta) for b in a]
    return copy.deepcopy(a)


def forward_proof(p):
    if type(p) is list and p:
        if p[0] == 'lam':
            return [forward_proof(p[1])]
        if p[0] == 'pack':
            return [renumber(p[1], 1), forward_proof(p[2])]
        m, r, *args = p
        out = [renumber(m, 1), forward_proof(r)]
        if m[0] == 'ex':
            return out + [forward_proof(args[0])]
        return out + [renumber(args[0], 1), forward_proof(args[1])]
    return 'r' if p == 'r' else None


def forward(data):
    a, p, *g = data
    return [renumber(a, 1), forward_proof(p), *[renumber(h, 1) for h in g]]


def checked(a, formula=True):
    if not valid(a, formula):
        raise ValueError('invalid syntax')
    return a


def restore(a, p, g):
    """Return an automatic certificate, in old number notation.

    a and g already use zero=-1 notation; p uses the new format.
    Only accepted candidate certificates are promised to translate. The final
    source oracle independently rechecks the reconstructed inference.
    """
    checked(a)
    if type(p) is list and a[0] == 'pi' and len(p) == 1:
        _, h, b = a
        if h == oracle(b, [-1, 0]):
            h = b if b[0] == '=' else h
            b = oracle(b, [['s', 0], 0])
        return ['lam', restore(b, p[0], [*[oracle(x) for x in g], h])]
    if type(p) is list and a[0] == 'ex' and len(p) == 2:
        t = checked(renumber(p[0], -1), False)
        h = ['=', 0, oracle(t, formula=False)]
        return ['pack', t, restore(a[1], p[1], [*[oracle(x) for x in g], h])]
    if type(p) is list and len(p) >= 2 and type(p[0]) is list and p[0]:
        m = checked(renumber(p[0], -1))
        try:
            r = restore(m, p[1], g)
        except Exception:
            return g.index(a)
        args = p[2:]
        if m[0] == 'ex':
            q, = args
            return [m, r, restore(oracle(a), q, [*[oracle(x) for x in g], m[1]])]
        t, q = args
        t = checked(renumber(t, -1), m[0] == '=')
        b, c = (oracle(t, [v, -1]) if m[0] == '=' else oracle(v, [t, -1]) for v in m[1:])
        if c != a:
            raise ValueError('conclusion mismatch')
        return [m, r, t, restore(b, q, g)]
    if p == 'r' and a[0] == '=' and type(a[1]) is list and a[1][0] == 'r':
        _, n, t, h = a[1]
        if n != -1:
            if type(n) is not list or len(n) != 2 or n[0] != 's':
                raise ValueError('noncomputational counter')
            n = n[1]
            t = oracle(h, [['r', n, t, h], n, -2], formula=False)
        if a[2] != t:
            raise ValueError('computation mismatch')
        return 'r'
    return g.index(a)


def backward(data):
    a, p, *g = data
    a = renumber(a, -1)
    g = [checked(renumber(h, -1)) for h in g]
    return [a, restore(a, p, g), *g]


def main():
    """Translate a JSON certificate; generators remain outside the kernel."""
    import argparse
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('direction', choices=('forward', 'backward'))
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    data = json.loads(args.source.read_text(encoding='utf-8'))
    result = forward(data) if args.direction == 'forward' else backward(data)
    args.destination.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print('Wrote translated certificate; validate it with the destination checker.')


if __name__ == '__main__':
    main()
