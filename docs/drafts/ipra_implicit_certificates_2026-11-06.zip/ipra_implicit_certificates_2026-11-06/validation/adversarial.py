"""Independent, labeled boundary tests of the complete public checker.

Fixtures are constructed from explicit logical examples and invalid inputs,
without importing any kernel or translation helper.  Every fixture is run
through the actual CLI both normally and with Python optimization enabled.
This is finite implementation evidence, not a proof of the metatheorems.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def eq(s, t):
    return ['=', s, t]


def succ(t):
    return ['s', t]


T = eq(0, 0)
D = eq(0, succ(0))
ZERO_EQUATION = eq(['r', 0, 0, 0], 0)
REFL = [ZERO_EQUATION, 'r', eq(1, 0), 'r']


def cases():
    """Return fixed expected labels, not labels learned from the checker."""
    records = []

    def add(name, data, expected, reason):
        records.append({'name': name, 'data': data, 'expected': expected,
                        'reason': reason})

    add('reflexivity', [T, REFL], True,
        'Zero recursion followed by equality transport proves 0=0.')
    add('wrong_closed_conclusion', [D, REFL], False,
        'The same certificate cannot prove 0=S0.')
    add('hypothesis', [D, None, D], True,
        'An open sequent may use its declared assumption.')
    add('missing_hypothesis', [D, None], False,
        'There is no undeclared hypothesis.')
    for payload in [False, True, 7, -7, 'ignored', {}, [], ['unused', 1]]:
        add('hypothesis_alias_' + str(len(records)), [T, payload, T], True,
            'A payload selecting no earlier rule denotes Hyp membership.')

    invalid = [None, False, True, 0.0, 1.0, -1, -7, '', '0', 's', 'ss',
               [], {}, {'s': 0}, ['s'], ['s', 0, 0], ['r', 0, 0],
               ['r', 0, 0, 0, 0], ['bad', 0], ['=', 0, 0]]
    pi_tt = ['pi', T, T]
    for i, bad in enumerate(invalid):
        add(f'invalid_goal_term_{i}', [eq(0, bad), None, T], False,
            'The public goal must contain canonical numerical terms.')
        add(f'invalid_unused_assumption_{i}', [T, REFL, eq(0, bad)], False,
            'Every public assumption is validated even when unused.')
        add(f'invalid_recursion_counter_{i}',
            [eq(['r', bad, 0, 0], 0), 'r'], False,
            'Only a valid zero or successor counter admits computation.')
        add(f'strict_vacuous_universal_witness_{i}',
            [T, [pi_tt, [None], bad, REFL]], False,
            'Strict checking rejects an invalid witness even if both matrices are vacuous.')
        add(f'strict_existential_witness_{i}',
            [['ex', T], [bad, REFL]], False,
            'Existential witnesses are strictly validated.')

    for i, bad in enumerate([None, False, True, 0, 1, -1, 0.0, [], {},
                             ['=', 0], ['=', 0, 0, 0], ['ex'],
                             ['ex', T, T], ['pi', T], ['pi', T, T, T],
                             ['s', 0]]):
        add(f'invalid_formula_{i}', [bad, None], False,
            'An invalid formula cannot enter the canonical proof state.')
        add(f'invalid_equality_motive_{i}', [T, [T, REFL, bad, REFL]], False,
            'An equality motive is a formula and is traversed completely.')

    add('zero_computation', [ZERO_EQUATION, 'r'], True,
        'The zero computation axiom has its exact initializer on the right.')
    add('zero_wrong_initializer', [eq(['r', 0, succ(0), 0], 0), 'r'], False,
        'The zero equation cannot discard the initializer.')
    add('successor_update_previous_counter',
        [eq(['r', succ(7), 0, 2], 7), 'r'], True,
        'Update slot 2 is the previous counter.')
    add('successor_update_previous_value',
        [eq(['r', succ(7), 0, 1], ['r', 7, 0, 1]), 'r'], True,
        'Update slot 1 is the previous recursive value.')
    add('successor_swapped_update_slots',
        [eq(['r', succ(7), 0, 1], 7), 'r'], False,
        'Previous counter and previous value must not be interchanged.')
    add('free_counter_is_not_zero', [eq(['r', 1, 0, 0], 0), 'r'], False,
        'A free positive index is a variable, not numerical zero.')
    add('nested_recursion_counter_is_not_a_successor',
        [eq(['r', ['r', 0, 0, 0], 0, 0], 0), 'r'], False,
        'The computation certificate only handles a syntactic zero or successor.')
    for bad in [None, False, [], {}, ['s'], ['=', 0, 0]]:
        add('dead_invalid_update_' + str(len(records)),
            [eq(['r', 0, 0, bad], 0), 'r'], False,
            'The whole public equation is validated, including a dead update.')

    H = eq(1, 0)
    add('ordinary_introduction', [['pi', H, H], [None]], True,
        'A nonmatching guard selects ordinary introduction.')
    add('matching_introduction', [pi_tt, [None]], True,
        'A vacuous matching equation has a direct numerical-rule proof.')
    add('old_lambda_tag_is_not_a_certificate',
        [pi_tt, ['lam', None]], False,
        'The one-child introduction form is the stated new format.')
    add('existential_witness', [['ex', eq(1, 0)], [0, None]], True,
        'A fresh equality to zero supplies an existential witness.')
    add('existential_parameter_preserved',
        [['ex', eq(1, succ(2))], [succ(1), None]], True,
        'An ambient parameter is lifted past the fresh witness.')
    add('existential_parameter_capture',
        [['ex', eq(1, succ(1))], [succ(1), None]], False,
        'The ambient witness parameter may not become the new local variable.')
    add('lambda_parameter_preserved',
        [['pi', T, eq(2, 0)], [None], eq(1, 0)], True,
        'An outer assumption keeps its numerical parameter under introduction.')
    add('lambda_parameter_capture',
        [['pi', T, eq(1, 0)], [None], eq(1, 0)], False,
        'An outer assumption cannot bind the new eigenvariable.')

    ex_t = ['ex', T]
    add('existential_elimination', [T, [ex_t, None, None], ex_t], True,
        'A local existential matrix can prove the unchanged outer goal.')
    leak = eq(1, 0)
    major = ['ex', leak]
    add('existential_eigenvariable_escape',
        [leak, [major, None, None], major], False,
        'The local existential witness cannot escape to a free conclusion.')
    nested_leak = ['pi', T, eq(2, 0)]
    nested_major = ['ex', nested_leak]
    add('existential_escape_under_binder',
        [nested_leak, [nested_major, None, None], nested_major], False,
        'The eigenvariable condition persists below a nested binder.')

    step_atomic = ['pi', eq(1, 0), eq(succ(1), 0)]
    inductive_goal = ['pi', T, eq(1, 0)]
    add('literal_equation_induction',
        [inductive_goal, [[step_atomic, None, 1, None]], step_atomic], True,
        'The equation branch supplies B(y) while proving B(Sy).')
    B = ['ex', eq(1, 2)]
    B0 = ['ex', eq(1, 0)]
    BS = ['ex', eq(1, succ(2))]
    step_compound = ['pi', B, BS]
    add('forbidden_compound_induction',
        [['pi', B0, B], [[step_compound, None, 1, None]], step_compound], False,
        'For compounds the local assumption is only B(0), not B(y).')

    add('failed_major_hypothesis_fallback',
        [T, [ex_t, None, None], T], True,
        'A False-returning major may select the valid Hyp fallback.')
    add('failed_major_does_not_prove_new_goal',
        [D, [ex_t, None, None], T], False,
        'Fallback cannot supply a goal absent from the context.')
    add('raising_major_does_not_fall_back',
        [T, [ex_t, [False, REFL], None], T], False,
        'An exception in the major rejects even if a hypothesis could prove the goal.')
    add('failed_minor_propagates',
        [T, [pi_tt, [None], 0, None]], False,
        'A proved major does not compensate for a missing minor proof.')
    add('valid_universal_elimination',
        [T, [pi_tt, [None], 0, REFL]], True,
        'Both major and minor proofs are required and may succeed.')

    for i, proof in enumerate([[pi_tt, [None]], [pi_tt, [None], 0],
                               [pi_tt, [None], 0, REFL, REFL],
                               [ex_t, None], [ex_t, None, None, None]]):
        add(f'elimination_arity_{i}', [T, proof, ex_t], False,
            'Elimination arity is exact after the major has been proved.')
    add('short_major_on_ex_goal', [ex_t, [pi_tt, [None]]], False,
        'A two-field list on an existential goal is a witness introduction; a formula is not a term.')
    for i, data in enumerate([None, False, 3, [], [T], {},
                              {'a': T, 'p': REFL}, '[]']):
        add(f'invalid_outer_record_{i}', data, False,
            'Malformed outer JSON cannot provide a canonical sequent.')
    return records


def main():
    checker = ROOT / 'checker.py'
    records = cases()
    (ROOT / 'validation' / 'adversarial_cases.json').write_text(
        json.dumps(records, indent=2) + '\n')
    runs = []
    with tempfile.TemporaryDirectory(prefix='ipra-adversarial-') as folder:
        directory = Path(folder)
        for record in records:
            path = directory / (record['name'] + '.json')
            path.write_text(json.dumps(record['data']) + '\n')
            for optimized in (False, True):
                command = [sys.executable, *(['-O'] if optimized else []),
                           str(checker), str(path)]
                result = subprocess.run(command, capture_output=True, text=True,
                                        timeout=15)
                accepted = result.returncode == 0 and result.stdout.strip() == 'ACCEPT'
                well_formed_verdict = ((accepted and not result.stderr) or
                                      (result.returncode == 1 and
                                       result.stdout.strip() == 'REJECT' and
                                       not result.stderr))
                runs.append({'name': record['name'], 'optimized': optimized,
                             'accepted': accepted,
                             'expected': record['expected'],
                             'passed': accepted == record['expected'] and
                                       well_formed_verdict})
        for i, raw in enumerate(['', 'not json', '[', '[0,null] trailing',
                                  '{"goal":']):
            path = directory / f'malformed_json_{i}.json'
            path.write_text(raw)
            result = subprocess.run([sys.executable, str(checker), str(path)],
                                    capture_output=True, text=True, timeout=15)
            runs.append({'name': f'malformed_json_{i}', 'optimized': False,
                         'accepted': result.returncode == 0, 'expected': False,
                         'passed': result.returncode == 1 and
                                   result.stdout.strip() == 'REJECT' and
                                   not result.stderr})
        path = directory / 'trailing_arguments.json'
        path.write_text(json.dumps([T, REFL]) + '\n')
        result = subprocess.run([sys.executable, str(checker), str(path), 'extra'],
                                capture_output=True, text=True, timeout=15)
        runs.append({'name': 'trailing_cli_arguments_are_rejected',
                     'optimized': False, 'accepted': result.returncode == 0,
                     'expected': False, 'passed': result.returncode == 1 and
                     result.stdout.strip() == 'REJECT' and not result.stderr})
    failures = [run for run in runs if not run['passed']]
    summary = {'checker_sha256': hashlib.sha256(checker.read_bytes()).hexdigest(),
               'method': 'Explicit independently labeled public JSON fixtures, '
                         'run through the complete CLI normally and with -O; '
                         'no candidate helpers used to generate expected labels.',
               'labeled_fixtures': len(records),
               'expected_acceptances': sum(record['expected'] for record in records),
               'expected_rejections': sum(not record['expected'] for record in records),
               'cli_runs': len(runs), 'failures': failures,
               'passed': not failures, 'runs': runs}
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results' / 'adversarial.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({key: value for key, value in summary.items()
                      if key != 'runs'}, indent=2))
    if failures:
        raise SystemExit(1)
    return summary


if __name__ == '__main__':
    main()
