"""Run every packaged acceptance-program measurement and validation offline."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    stages = [
        ROOT / 'comparison/measure.py',
        ROOT / 'validation/validate.py',
    ]
    auditor = ROOT / 'validation/adversarial.py'
    if auditor.exists():
        stages.append(auditor)
    completed = []
    for script in stages:
        print('Running ' + str(script.relative_to(ROOT)), flush=True)
        subprocess.run([sys.executable, str(script)], cwd=ROOT, check=True)
        completed.append(str(script.relative_to(ROOT)))
    result = {'status': 'passed', 'stages': completed, 'python': sys.version}
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    print('All packaged checks passed.')


if __name__ == '__main__':
    main()
