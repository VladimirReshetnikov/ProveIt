"""Measure entire current acceptance programs; no application code is omitted.

The four primary measures match the supplied drafts.  Only comments and
actual module/function/class docstrings are excluded.  UTF-8 normalized
bytes and normalized tokens are computed from ast.unparse.  Raw source
bytes are supplementary.  Standard Python and its json/sys runtime are
shared assumptions, and are treated identically for every program.
"""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes',
          'normalized_bytes', 'raw_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


def measure(path):
    """Count one entire source file without any implementation rewriting."""
    raw = Path(path).read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                             ast.AsyncFunctionDef)) and node.body:
            doc = node.body[0]
            if (isinstance(doc, ast.Expr) and
                    isinstance(doc.value, ast.Constant) and
                    isinstance(doc.value.value, str)):
                node.body.pop(0)
                spans.append(((doc.lineno, doc.col_offset),
                              (doc.end_lineno, doc.end_col_offset)))
    normalized = ast.unparse(tree) + '\n'

    def count(text, omitted=()):
        return sum(token.type not in IGNORED and
                   not any(start <= token.start and token.end <= end
                           for start, end in omitted)
                   for token in tokenize.generate_tokens(io.StringIO(text).readline))

    return {'sha256': hashlib.sha256(raw).hexdigest(),
            'source_tokens': count(source, spans),
            'normalized_tokens': count(normalized),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode('utf-8')),
            'raw_bytes': len(raw)}


def envelope(rows):
    return {key: min(row[key] for row in rows) for key in FIELDS}


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    rows = []
    for entry in manifest['baselines']:
        row = {**entry, **measure(ROOT / entry['source'])}
        if row['sha256'] != entry['source_sha256']:
            raise ValueError('Modified frozen source: ' + entry['source'])
        rows.append(row)
    result = {
        'python': sys.version,
        'python_version': platform.python_version(),
        'repository': manifest['repository'],
        'commit': manifest['commit'],
        'boundary': 'Entire standalone acceptance program, excluding comments '
                    'and genuine docstrings only; all grammar, substitution, '
                    'logic, arithmetic, JSON/CLI, and rejection code counted.',
        'baselines': rows,
        'primary_envelope': envelope([r for r in rows if r['primary']]),
        'all_current_envelope': envelope(rows),
        'open_sequent_envelope': envelope([r for r in rows
                                         if r['interface'] == 'open_sequent']),
        'strict_open_envelope': envelope([r for r in rows
                                         if r['interface'] == 'open_sequent'
                                         and r['witness_policy'] == 'strict'])}
    candidate = {'source': '../checker.py', 'primary': True,
                 'interface': 'open_sequent', 'witness_policy': 'strict',
                 **measure(ROOT.parent / 'checker.py')}
    result['candidate'] = candidate
    result['strictly_below_all_current'] = {
        key: candidate[key] < result['all_current_envelope'][key]
        for key in FIELDS}
    result['relative_reduction_percent'] = {
        key: 100 * (1 - candidate[key] / result['all_current_envelope'][key])
        for key in FIELDS}
    (ROOT / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    (ROOT.parent / 'results').mkdir(exist_ok=True)
    (ROOT.parent / 'results/metrics.json').write_text(
        json.dumps(result, indent=2) + '\n')
    with (ROOT / 'metrics.csv').open('w', newline='') as stream:
        columns = ['source', 'sha256', 'primary', 'interface', 'witness_policy', *FIELDS]
        writer = csv.DictWriter(stream, columns, extrasaction='ignore')
        writer.writeheader()
        writer.writerows([*rows, candidate])
    if not all(result['strictly_below_all_current'].values()):
        raise ValueError('The candidate must beat every declared coordinate')
    print(json.dumps({key: value for key, value in result.items()
                      if key != 'baselines'}, indent=2))
    return result


if __name__ == '__main__':
    main()
