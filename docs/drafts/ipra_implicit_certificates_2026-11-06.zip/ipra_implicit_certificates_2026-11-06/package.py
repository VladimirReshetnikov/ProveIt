"""Create a checksum manifest and a reproducible ZIP of the complete deliverable."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc', '.synctex.gz'}


def payloads():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and p.name != 'MANIFEST.sha256'
                  and p.suffix not in EXCLUDED_SUFFIXES
                  and not any(part.startswith('.') or part == '__pycache__'
                              for part in p.relative_to(ROOT).parts))


if __name__ == '__main__':
    if not (ROOT / 'report.pdf').is_file():
        raise SystemExit('Run build.py before packaging.')
    files = payloads()
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() +
                               '  ' + p.relative_to(ROOT).as_posix() + '\n'
                               for p in files), encoding='utf-8')
    archive = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as output:
        for path in sorted([*files, manifest]):
            name = ROOT.name + '/' + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 6, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            output.writestr(info, path.read_bytes(), compresslevel=9)
    print(str(archive))
