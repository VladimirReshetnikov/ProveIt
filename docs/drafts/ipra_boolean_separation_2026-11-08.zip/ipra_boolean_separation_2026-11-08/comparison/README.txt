REPRODUCIBLE CURRENT-DRAFT COMPARISON
===================================

Repository: https://github.com/VladimirReshetnikov/ProveIt
Pinned commit: 6fac3001a902d6666186fc4692a96de0ef296cf7
User-facing preparation date: 8 November 2026

This folder contains every top-level checker*.py program from the six ZIP
archives present in docs/drafts at the pinned commit: nine programs in total.
The frozen sources are copied byte-for-byte. Nested historical comparator
programs and validation-only oracles are excluded from this current corpus.

Run from any working directory:

    python3 /absolute/path/to/comparison/source_measure.py

Or run from this directory:

    python3 source_measure.py

The measurement script is copied unchanged from the current context-pairs
draft. It verifies each source SHA-256 against manifest.json, then writes
metrics.json and metrics.csv. It measures the complete accepting program,
including imports, literal tables, error handling, and public input/output.
Comments and genuine docstrings are excluded by the inherited normalizer.
The metric definitions and its additional core diagnostic are unchanged.
AST normalization may vary with the Python version; metrics.json records
the actual Python version and implementation used for this run.

The manifest records exact archive SHA-256 hashes, Git blob hashes, sizes,
pinned repository URLs, program-member paths, and source SHA-256 hashes.
The archive Git blob hashes were independently recomputed from the local
archive bytes and matched the hashes returned for the pinned GitHub snapshot.
Each frozen program was also compared with its original ZIP member.
The source-measure script's provenance and SHA-256 are recorded separately.
The six full archives are not duplicated here: all source bytes needed to
reproduce these measurements offline are already included.

CONTRIBUTION AND INTERPRETATION

All nine checkers and the source-measure program are inherited work, credited
to ProveIt Contributors and the named source drafts. No edits to those
programs or new checker-size improvement are claimed by this package.
The accompanying Boolean-separation theory is a mathematical alternative;
it has not been shown to possess a complete direct checker below this corpus.
These measurements establish the comparison target, not that unmet claim.

Interface, witness-policy, and proof-layout metadata intentionally say
"as delivered; see original draft". They are not guessed from source syntax.
The original six drafts remain the authoritative descriptions of those
certificate languages and of their correctness and completeness claims.

LICENSING AND ATTRIBUTION

The root LICENSE reproduces the source archives' MIT No Attribution License
(copyright 2026 ProveIt Contributors). All six archives supplied identical
license bytes. The attribution/ directory also preserves every root license
and attribution notice available in the six extracted source archives,
including their earlier attribution chains. Those notices describe their
original packages; their references to "new" work or older pinned snapshots
must be read in that original context, not as claims about this package.
