"""Replay certificates and reject three deliberate mathematical/scope defects.

Run: python3 verification/verify_equations.py
The output concerns only the supplementary equational certificates. It is
not evidence of a formalized full iPRA proof checker or bi-interpretation.
"""
import copy
import json
from pathlib import Path
from eq_kernel import InvalidCertificate, verify

ROOT = Path(__file__).resolve().parent


def replace_variable(a, variable, image):
    if isinstance(a, str):
        return copy.deepcopy(image) if a == variable else a
    return [a[0], *(replace_variable(b, variable, image) for b in a[1:])]


def refresh_instances(cert):
    cert["base"] = [replace_variable(t, cert["induct"], "0") for t in cert["equation"]]
    cert["successor"] = [replace_variable(t, cert["induct"], ["S", cert["eigenvariable"]])
                         for t in cert["equation"]]


def main():
    document = json.loads((ROOT / "certificates.json").read_text())
    proofs = verify(document)
    mutants = []

    false_goal = copy.deepcopy(document)
    false_goal["certificates"][0]["equation"][1] = ["S", "a"]
    refresh_instances(false_goal["certificates"][0])
    mutants.append(("false_c_diagonal_goal_with_consistent_instances", false_goal))

    bad_successor = copy.deepcopy(document)
    bad_successor["certificates"][0]["successor"][0][1] = "0"
    mutants.append(("incorrect_successor_substitution", bad_successor))

    missing_predecessor = copy.deepcopy(document)
    missing_predecessor["certificates"][-1]["imports"].remove("PS")
    mutants.append(("predecessor_successor_law_removed_from_scope", missing_predecessor))

    outcomes = []
    for name, mutant in mutants:
        try:
            verify(mutant)
        except InvalidCertificate as error:
            outcomes.append({"name": name, "status": "rejected", "reason": str(error)})
        else:
            raise AssertionError("Incorrect certificate accepted: " + name)
    result = {
        "scope": "Six equational inductions only; imported laws explicitly recorded; no full bi-interpretation formalization",
        "certificates_verified": len(proofs),
        "mutation_tests_rejected": len(outcomes),
        "proofs": proofs,
        "mutation_tests": outcomes,
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
