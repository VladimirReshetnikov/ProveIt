"""Small supplementary kernel for six equational induction certificates.

This is NOT a checker for iPRA, Boolean separation, or bi-interpretability.
Its trusted boundary is first-order equality, literal-equation induction,
and the explicitly selected imported equations below. C0/CS and N0/NS
follow by expanding the report's definitions into I0/IS. P0/PS are the
predecessor theorem proved in the report, NOT extra native axioms.

Terms are JSON strings (variables, or "0") and tagged arrays. Z(t) is
elaborated definitionally to C(t,S(0),0). Rewriting uses exact first-order
pattern matching; no numerical evaluation or heuristic equality is used.
All six successor proofs ignore the induction hypothesis. They therefore
check by a restricted, sound instance of literal-equation induction.
"""
from collections import Counter

ARITY = {"S": 1, "C": 3, "Z": 1, "N": 1, "P": 1}


class InvalidCertificate(ValueError):
    pass


def term(a):
    if type(a) is str:
        if a == "0" or a.isidentifier():
            return a
    if type(a) is list and a and type(a[0]) is str:
        op = a[0]
        if op in ARITY and len(a) == ARITY[op] + 1:
            children = tuple(term(b) for b in a[1:])
            return ("C", children[0], ("S", "0"), "0") if op == "Z" else (op, *children)
    raise InvalidCertificate("Malformed numerical term")


def variables(a):
    if isinstance(a, str):
        return set() if a == "0" else {a}
    return set().union(*(variables(b) for b in a[1:]))


def substitute(a, images):
    if isinstance(a, str):
        return images.get(a, a)
    return (a[0], *(substitute(b, images) for b in a[1:]))


def match(pattern, target, images):
    if isinstance(pattern, str):
        if pattern == "0":
            return target == "0"
        if pattern in images:
            return images[pattern] == target
        images[pattern] = target
        return True
    return (isinstance(target, tuple) and len(pattern) == len(target)
            and pattern[0] == target[0]
            and all(match(p, t, images) for p, t in zip(pattern[1:], target[1:])))


IMPORTS = {
    "C0": (term(["C", "0", "a", "b"]), term("a")),
    "CS": (term(["C", ["S", "n"], "a", "b"]), term("b")),
    "N0": (term(["N", "0"]), term("0")),
    "NS": (term(["N", ["S", "n"]]), term(["Z", ["N", "n"]])),
    "P0": (term(["P", "0"]), term("0")),
    "PS": (term(["P", ["S", "n"]]), term("n")),
}


def normalize(a, rules, used, fuel=10000):
    budget = [fuel]

    def go(node):
        budget[0] -= 1
        if budget[0] < 0:
            raise InvalidCertificate("Normalization resource bound exceeded")
        if isinstance(node, tuple):
            node = (node[0], *(go(b) for b in node[1:]))
        for name, (lhs, rhs) in rules:
            images = {}
            if match(lhs, node, images):
                result = substitute(rhs, images)
                if result != node:
                    used[name] += 1
                    return go(result)
        return node

    return go(a)


def equation(raw):
    if type(raw) is not list or len(raw) != 2:
        raise InvalidCertificate("An equation must have exactly two terms")
    return tuple(term(a) for a in raw)


def verify(document):
    if (type(document) is not dict or type(document.get("schema_version")) is not int
            or document["schema_version"] != 1):
        raise InvalidCertificate("Unknown certificate format")
    certificates = document.get("certificates")
    if type(certificates) is not list:
        raise InvalidCertificate("Missing certificate list")
    proved, dependencies, reports = {}, {}, []
    required = {"name", "equation", "induct", "eigenvariable", "base",
                "successor", "imports", "use", "rewrite"}
    for cert in certificates:
        if type(cert) is not dict or set(cert) != required:
            raise InvalidCertificate("Wrong certificate fields")
        name = cert["name"]
        if type(name) is not str or not name.isidentifier() or name in proved:
            raise InvalidCertificate("Invalid or duplicate theorem name")
        lhs, rhs = equation(cert["equation"])
        variable, eigen = cert["induct"], cert["eigenvariable"]
        free = variables(lhs) | variables(rhs)
        if (type(variable) is not str or variable not in free
                or type(eigen) is not str or not eigen.isidentifier() or eigen in free):
            raise InvalidCertificate("Invalid induction variable or eigenvariable")
        names, earlier = cert["imports"], cert["use"]
        if (type(names) is not list or type(earlier) is not list
                or any(type(n) is not str or n not in IMPORTS for n in names)
                or any(type(n) is not str or n not in proved for n in earlier)):
            raise InvalidCertificate("Unproved or out-of-scope rewrite")
        rules = [(n, proved[n]) for n in earlier] + [(n, IMPORTS[n]) for n in names]
        used = Counter()
        for label, image in (("base", "0"), ("successor", ("S", eigen))):
            expected = tuple(substitute(t, {variable: image}) for t in (lhs, rhs))
            if equation(cert[label]) != expected:
                raise InvalidCertificate(f"{name}: wrong {label} substitution")
            if normalize(expected[0], rules, used) != normalize(expected[1], rules, used):
                raise InvalidCertificate(f"{name}: {label} equation did not check")
        if cert["rewrite"] == "left_to_right":
            rule = (lhs, rhs)
        elif cert["rewrite"] == "right_to_left":
            rule = (rhs, lhs)
        else:
            raise InvalidCertificate("Unknown rewrite direction")
        if isinstance(rule[0], str) or not variables(rule[1]) <= variables(rule[0]):
            raise InvalidCertificate("Unsafe schematic rewrite shape")
        proved[name] = rule
        dependencies[name] = set(names).union(*(dependencies[n] for n in earlier))
        reports.append({"name": name, "status": "verified",
                        "induction_hypothesis_used": False,
                        "rewrite_applications": dict(sorted(used.items())),
                        "import_dependencies": sorted(dependencies[name])})
    return reports
