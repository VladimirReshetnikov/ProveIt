iPRA FROM BOOLEAN SEPARATION
Research report prepared for Vladimir Reshetnikov, November 8, 2026

STATUS
This is a mathematical research result, not a successful claim of a
checker smaller than every current draft. The strict complexity goal
remains unproved. The current measured envelope is 322 normalized tokens,
350 AST nodes, and 903 normalized bytes; these have different attainers.

RESULTS
1. Over scalar iteration and literal-equation induction, replace numerical
   coverage x=0 or exists y x=Sy by x=0 or Z(x)=0, where
   Z(x)=I(x,S0;u.0). The report derives predecessor before using coverage,
   then recovers coverage with witness P(x). The two bases are equivalent.
2. A product-preserved arithmetic cannot be rescued by merely changing
   interpreted domains: finite-order automorphisms obstruct bi-interpretation
   with iPRA. Arbitrary powers also defeat finite parameter choices.

The native calculus uses positive intuitionistic logic and designated
contradiction D=(0=S0). Its ORDINARY FIRST-ORDER REALIZATION explicitly adds
genuine bottom and the bridge D -> bottom. Standard bi-interpretability
with iPRA is proved for that realization; the native calculus faithfully
presents it. The raw positive axioms alone have a one-element model and
are NOT silently claimed model-theoretically bi-interpretable with iPRA.

FILES
report.tex / report.pdf        Complete article and compiled version.
sections/                     LaTeX source sections.
verification/                 Six symbolic equation-induction certificates,
                              readable kernel, replay script, recorded results.
comparison/                   Nine unchanged current baseline checkers,
                              inherited source measurement script, manifest,
                              JSON/CSV output and attribution notices.
build.sh                      Compile the article using pdflatex.
RESULTS.json                  Machine-readable status and verification scope.
SHA256SUMS                    Hashes of all other included files.

REPRODUCE
  python3 verification/verify_equations.py
  python3 comparison/source_measure.py
  bash build.sh

The symbolic checker verifies only six equation-induction fragments and
explicitly imports P(0)=0 and P(Sx)=x as report-proved lemmas. It is not a
full iPRA checker and is not a formalization of the full bi-interpretation.
The report contains the proofs of the imported mathematical results.
No Lean/Rocq proof is claimed.

PROVENANCE
ProveIt snapshot 6fac3001a902d6666186fc4692a96de0ef296cf7,
https://github.com/VladimirReshetnikov/ProveIt/tree/6fac3001a902d6666186fc4692a96de0ef296cf7/docs/drafts
All six current archives were inspected. The scalar comparator,
predecessor, reflection, and pair-coding constructions are attributed
adaptations of that corpus, not newly discovered function constructions.
The exact archive and program hashes are in comparison/manifest.json.
Novelty is assessed only relative to the inspected corpus; global
historical priority and absolute optimality are not asserted.
