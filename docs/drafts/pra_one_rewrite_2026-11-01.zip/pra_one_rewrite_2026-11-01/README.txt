PRIMITIVE RECURSIVE ARITHMETIC FROM ONE LOCAL REWRITE
Research prepared for Vladimir Reshetnikov, 1 November 2026

MAIN RESULTS

1. An 18-node partial schema display, compared with two independently
   presented 26-node baselines in the eight drafts at ProveIt commit
   ab29d2ad2189948d995d6cffa7cea5298cd126a0.
2. A 15-node alternative using a precisely restricted stationary quantified
   matrix grammar. No induction for moving quantified formulas is assumed.
3. A strictly smaller update language: retain one fixed counter-dependent
   predecessor description; every other generated update is unary in the
   state. A constructive internal pairing proof justifies this reduction.
4. The constructions work separately in classical and intuitionistic
   first-order equality logic and have common conservative definitional
   extensions with matching PRA. Both interpretation round trips are
   internally the identity on the whole carrier.

The main gate allows ZERO OR ONE marked local replacement, after substituting
zero for the induction variable, to obtain a literal B->B. Stationary probes
force the very arithmetic equations used by that gate. The equation
information is explicit in the finite gate; it has not disappeared.

The counts are PARTIAL OUTER-DISPLAY COUNTS. They exclude matrix bodies,
update bodies, grammar and admission code. The new axioms use three variable
names instead of the old best presentations' two. No absolute minimum or
universally shorter concrete proof translation is asserted.

CONTENTS

report.pdf                 Complete compiled mathematical paper.
report.tex                 Main LaTeX source.
sections/*.tex             Full proofs, variants, source comparison, supplement.
AXIOMS.txt                 Standalone exact specification and core probes.
formal/OneRewrite.lean      Constructive finite-syntax logical kernel.
formal/SCOPE.txt            Exact formalization boundary.
formal/lean-toolchain       Version used: Lean4.19.0.
formal/lean-check.log       Checked theorem dependency reports.
formal/verification.json   Compiler, exit status, hashes, scope.
artifacts/check_syntax.py   Independent one-step admission/metric diagnostics.
artifacts/results.json     Deterministic check results and certificates.
artifacts/check_pure_pairing.py
                           Finite diagnostics for the restricted-update proof.
artifacts/pure_pairing_results.json
                           Recorded restricted-update diagnostic results.
audit/source_manifest.json Pinned eight-archive comparison metadata.
audit/download_checks.json Checked lengths, Git identifiers and SHA-256 hashes.
audit/review_mathematics.txt
                           Independent mathematical review and scope.
audit/final_review.txt      Source-pinned review of the final proof text.
audit/validation.json       Final build, file and PDF QA record.
build.py                   Portable checks and PDF build.
SHA256SUMS                 Integrity hashes for packaged deliverables.

REBUILD

Requires Python3.10+ and TeX Live with latexmk and the packages in report.tex.
From this directory:

  python3 build.py

This runs the syntax checks and finite restricted-update diagnostics,
builds report.pdf, and checks the final LaTeX log for errors and unresolved
references. If lean is on PATH it also runs the kernel; alternatively:

  python3 build.py --lean /absolute/path/to/lean

Lean4.19.0 needs no Mathlib or third-party Lean package:

  lean formal/OneRewrite.lean

The scripts use only the Python standard library. Final visual QA used
PyMuPDF rendering, with all 25 page images checked. This renderer is not
needed to rebuild the report.

VERIFICATION BOUNDARY

The Lean file checks actual finite term/formula syntax and substitution,
the exact zero-or-one rewrite relation, its constructive semantic soundness,
the stationary probes, U19's equivalence to the two-parameter binary basis,
U18's equivalence to endpoint induction plus the arithmetic laws, and
extraction of one-parameter QF induction from U18.

The complete first-order derivation calculus, staged language compiler,
arithmetic/pairing bridge, full bi-interpretability theorem, stationary15
variant, and restricted-update supplement are written proofs. They are not
claimed as an end-to-end proof-assistant formalization.

The 20 recorded dependency reports contain neither sorryAx nor
Classical.choice; each is empty or lists only propext and Quot.sound.
Finite numerical or syntax diagnostics are not substitutes for the internal
proofs about arbitrary and nonstandard models.

PROVENANCE

All eight source archives were read from the exact requested directory at
the pinned commit. No repository files were changed. The report credits the
inherited one-parameter arithmetic/pairing bootstrap. The finite syntax and
substitution proof pattern in the Lean kernel is adapted with attribution
from the supplied syntactic-base draft.
