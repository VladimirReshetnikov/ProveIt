#!/usr/bin/env python3
"""Reproduce the delivered diagnostics and paper without network access."""

from __future__ import annotations

import argparse
import json
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent


def run(args: list[str], *, log: pathlib.Path | None = None) -> None:
    result = subprocess.run(
        args, cwd=ROOT, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, check=False
    )
    if log is not None:
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        sys.stdout.write(result.stdout)
        raise SystemExit(result.returncode)
    print("PASS:", " ".join(args[:2]))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Lean4.19.0 executable")
    args = parser.parse_args()
    run([sys.executable, "artifacts/check_syntax.py"])
    pairing = ROOT / "artifacts/check_pure_pairing.py"
    if pairing.exists():
        run([sys.executable, str(pairing)])
    lean = args.lean or shutil.which("lean")
    if lean:
        run([lean, "formal/OneRewrite.lean"], log=ROOT / "_build/lean-recheck.log")
    else:
        print("Lean not on PATH; the recorded kernel run remains in formal/.")
    run(
        ["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error",
         "-outdir=_build", "report.tex"],
        log=ROOT / "_build/latexmk.log"
    )
    tex_log = (ROOT / "_build/report.log").read_text(errors="replace")
    blockers = [
        r"Overfull \hbox", r"Overfull \vbox",
        "There were undefined references", "There were undefined citations",
        "Fatal error", "LaTeX Error"
    ]
    failures = [text for text in blockers if text in tex_log]
    if failures:
        raise SystemExit("LaTeX QA failed: " + ", ".join(failures))
    shutil.copy2(ROOT / "_build/report.pdf", ROOT / "report.pdf")
    print("Created report.pdf")


if __name__ == "__main__":
    main()
