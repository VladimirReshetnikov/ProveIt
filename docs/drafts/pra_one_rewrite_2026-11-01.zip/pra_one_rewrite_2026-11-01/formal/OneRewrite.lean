/-
PRA from propagation with zero or one local rewrite.

Core Lean 4.19 only. The elementary finite Term/Formula infrastructure and
substitution-lemma proof pattern are adapted from DiagonalSchema.lean in
the supplied pra_syntactic_base_2026-11-01 archive, pinned in ProveIt at
ab29d2ad2189948d995d6cffa7cea5298cd126a0. The one-step relations, admission
condition, stationary probes, and equivalence below are new for this report.

Scope: a constructive semantic logical kernel over indexed binary symbols
and given two-input bodies. No object first-order proof calculus, staging
compiler, arithmetic bootstrap, or final bi-interpretation is formalized.
The report separately restricts bodies to finite earlier descriptions.
In particular, this file does not assume a primitive-recursive evaluator.
-/

namespace OneRewrite

inductive Two where
  | left | right
  deriving DecidableEq

inductive Three where
  | counter | first | second
  deriving DecidableEq

inductive Term (V : Type) where
  | var : V → Term V
  | zero : Term V
  | succ : Term V → Term V
  | app : Nat → Term V → Term V → Term V
  deriving DecidableEq

inductive Formula (V : Type) where
  | eq : Term V → Term V → Formula V
  | bot : Formula V
  | conj : Formula V → Formula V → Formula V
  | disj : Formula V → Formula V → Formula V
  | imp : Formula V → Formula V → Formula V
  deriving DecidableEq

structure Model (D : Type) where
  zero : D
  succ : D → D
  app : Nat → D → D → D

def Term.subst {V W : Type} (s : V → Term W) : Term V → Term W
  | .var v => s v
  | .zero => .zero
  | .succ t => .succ (t.subst s)
  | .app k t u => .app k (t.subst s) (u.subst s)

def Formula.subst {V W : Type} (s : V → Term W) : Formula V → Formula W
  | .eq t u => .eq (t.subst s) (u.subst s)
  | .bot => .bot
  | .conj A B => .conj (A.subst s) (B.subst s)
  | .disj A B => .disj (A.subst s) (B.subst s)
  | .imp A B => .imp (A.subst s) (B.subst s)

def Term.eval {V D : Type} (M : Model D) (e : V → D) : Term V → D
  | .var v => e v
  | .zero => M.zero
  | .succ t => M.succ (t.eval M e)
  | .app k t u => M.app k (t.eval M e) (u.eval M e)

def Formula.eval {V D : Type} (M : Model D) (e : V → D) : Formula V → Prop
  | .eq t u => t.eval M e = u.eval M e
  | .bot => False
  | .conj A B => A.eval M e ∧ B.eval M e
  | .disj A B => A.eval M e ∨ B.eval M e
  | .imp A B => A.eval M e → B.eval M e

theorem Term.subst_id {V : Type} (t : Term V) :
    t.subst Term.var = t := by
  induction t with
  | var v => rfl
  | zero => rfl
  | succ t ih => simp only [Term.subst, ih]
  | app k t u iht ihu => simp only [Term.subst, iht, ihu]

theorem Formula.subst_id {V : Type} (A : Formula V) :
    A.subst Term.var = A := by
  induction A with
  | eq t u => simp only [Formula.subst, Term.subst_id]
  | bot => rfl
  | conj A B ihA ihB => simp only [Formula.subst, ihA, ihB]
  | disj A B ihA ihB => simp only [Formula.subst, ihA, ihB]
  | imp A B ihA ihB => simp only [Formula.subst, ihA, ihB]

theorem Term.subst_subst {U V W : Type} (t : Term U)
    (s : U → Term V) (r : V → Term W) :
    (t.subst s).subst r = t.subst (fun v => (s v).subst r) := by
  induction t with
  | var v => rfl
  | zero => rfl
  | succ t ih => simp only [Term.subst, ih]
  | app k t u iht ihu => simp only [Term.subst, iht, ihu]

theorem Formula.subst_subst {U V W : Type} (A : Formula U)
    (s : U → Term V) (r : V → Term W) :
    (A.subst s).subst r = A.subst (fun v => (s v).subst r) := by
  induction A with
  | eq t u => simp only [Formula.subst, Term.subst_subst]
  | bot => rfl
  | conj A B ihA ihB => simp only [Formula.subst, ihA, ihB]
  | disj A B ihA ihB => simp only [Formula.subst, ihA, ihB]
  | imp A B ihA ihB => simp only [Formula.subst, ihA, ihB]

theorem Term.eval_subst {V W D : Type} (M : Model D)
    (t : Term V) (s : V → Term W) (e : W → D) :
    (t.subst s).eval M e = t.eval M (fun v => (s v).eval M e) := by
  induction t with
  | var v => rfl
  | zero => rfl
  | succ t ih => simp only [Term.subst, Term.eval, ih]
  | app k t u iht ihu => simp only [Term.subst, Term.eval, iht, ihu]

theorem Formula.eval_subst {V W D : Type} (M : Model D)
    (A : Formula V) (s : V → Term W) (e : W → D) :
    (A.subst s).eval M e ↔ A.eval M (fun v => (s v).eval M e) := by
  induction A with
  | eq t u => simp only [Formula.subst, Formula.eval, Term.eval_subst]
  | bot => rfl
  | conj A B ihA ihB => simp only [Formula.subst, Formula.eval, ihA, ihB]
  | disj A B ihA ihB => simp only [Formula.subst, Formula.eval, ihA, ihB]
  | imp A B ihA ihB => simp only [Formula.subst, Formula.eval, ihA, ihB]

def envTwo {D : Type} (a b : D) : Two → D
  | .left => a
  | .right => b

def envThree {D : Type} (n a b : D) : Three → D
  | .counter => n
  | .first => a
  | .second => b

def pairSub {V : Type} (t u : Term V) : Two → Term V
  | .left => t
  | .right => u

abbrev Bodies := Nat → Term Two

def bodyApp {V : Type} (bodies : Bodies) (k : Nat)
    (t u : Term V) : Term V :=
  (bodies k).subst (pairSub t u)

theorem eval_bodyApp {V D : Type} (M : Model D) (bodies : Bodies)
    (k : Nat) (t u : Term V) (e : V → D) :
    (bodyApp bodies k t u).eval M e =
      (bodies k).eval M (envTwo (t.eval M e) (u.eval M e)) := by
  unfold bodyApp
  rw [Term.eval_subst]
  have henv : (fun v => (pairSub t u v).eval M e) =
      envTwo (t.eval M e) (u.eval M e) := by
    funext v
    cases v <;> rfl
  rw [henv]

def guard {V : Type} : Formula V := .eq .zero (.succ .zero)

/- Exactly one selected root contraction, possibly inside a term context.
   There is deliberately no reflexivity or transitivity constructor. -/
inductive TermRewrite (bodies : Bodies) {V : Type} : Term V → Term V → Prop
  | base (k : Nat) (t : Term V) :
      TermRewrite bodies (.app k .zero t) t
  | step (k : Nat) (n a : Term V) :
      TermRewrite bodies (.app k (.succ n) a)
        (bodyApp bodies k n (.app k n a))
  | succ {t t' : Term V} :
      TermRewrite bodies t t' → TermRewrite bodies (.succ t) (.succ t')
  | appLeft {k : Nat} {t t' u : Term V} :
      TermRewrite bodies t t' →
      TermRewrite bodies (.app k t u) (.app k t' u)
  | appRight {k : Nat} {t u u' : Term V} :
      TermRewrite bodies u u' →
      TermRewrite bodies (.app k t u) (.app k t u')

/- Exactly one contraction in one formula occurrence. Term rewrites occur
   in one side of one equality; the final constructor paths retain all
   other subtrees, including repeated occurrences of the same syntax. -/
inductive FormulaRewrite (bodies : Bodies) {V : Type} :
    Formula V → Formula V → Prop
  | eqLeft {t t' u : Term V} :
      TermRewrite bodies t t' →
      FormulaRewrite bodies (.eq t u) (.eq t' u)
  | eqRight {t u u' : Term V} :
      TermRewrite bodies u u' →
      FormulaRewrite bodies (.eq t u) (.eq t u')
  | guard : FormulaRewrite bodies guard .bot
  | conjLeft {A A' B : Formula V} :
      FormulaRewrite bodies A A' →
      FormulaRewrite bodies (.conj A B) (.conj A' B)
  | conjRight {A B B' : Formula V} :
      FormulaRewrite bodies B B' →
      FormulaRewrite bodies (.conj A B) (.conj A B')
  | disjLeft {A A' B : Formula V} :
      FormulaRewrite bodies A A' →
      FormulaRewrite bodies (.disj A B) (.disj A' B)
  | disjRight {A B B' : Formula V} :
      FormulaRewrite bodies B B' →
      FormulaRewrite bodies (.disj A B) (.disj A B')
  | impLeft {A A' B : Formula V} :
      FormulaRewrite bodies A A' →
      FormulaRewrite bodies (.imp A B) (.imp A' B)
  | impRight {A B B' : Formula V} :
      FormulaRewrite bodies B B' →
      FormulaRewrite bodies (.imp A B) (.imp A B')

def Bases {D : Type} (M : Model D) : Prop :=
  ∀ k a, M.app k M.zero a = a

def Steps {D : Type} (M : Model D) (bodies : Bodies) : Prop :=
  ∀ k n a, M.app k (M.succ n) a =
    (bodies k).eval M (envTwo n (M.app k n a))

def Separation {D : Type} (M : Model D) : Prop :=
  M.zero = M.succ M.zero → False

theorem TermRewrite.sound {V D : Type} (M : Model D) (bodies : Bodies)
    (hb : Bases M) (hs : Steps M bodies) {t u : Term V}
    (r : TermRewrite bodies t u) (e : V → D) :
    t.eval M e = u.eval M e := by
  induction r with
  | base k t => exact hb k (t.eval M e)
  | step k n a =>
    change M.app k (M.succ (n.eval M e)) (a.eval M e) =
      (bodyApp bodies k n (.app k n a)).eval M e
    rw [eval_bodyApp]
    exact hs k (n.eval M e) (a.eval M e)
  | succ r ih => exact congrArg M.succ ih
  | appLeft r ih =>
    simp only [Term.eval, ih]
  | appRight r ih =>
    simp only [Term.eval, ih]

theorem FormulaRewrite.sound {V D : Type} (M : Model D) (bodies : Bodies)
    (hb : Bases M) (hs : Steps M bodies) (he : Separation M)
    {A B : Formula V} (r : FormulaRewrite bodies A B) (e : V → D) :
    A.eval M e ↔ B.eval M e := by
  induction r with
  | eqLeft r =>
    simp only [Formula.eval, TermRewrite.sound M bodies hb hs r e]
  | eqRight r =>
    simp only [Formula.eval, TermRewrite.sound M bodies hb hs r e]
  | guard =>
    change (M.zero = M.succ M.zero) ↔ False
    exact ⟨he, False.elim⟩
  | conjLeft r ih => simp only [Formula.eval, ih]
  | conjRight r ih => simp only [Formula.eval, ih]
  | disjLeft r ih => simp only [Formula.eval, ih]
  | disjRight r ih => simp only [Formula.eval, ih]
  | impLeft r ih => simp only [Formula.eval, ih]
  | impRight r ih => simp only [Formula.eval, ih]

def baseSub : Three → Term Two
  | .counter => .zero
  | .first => .var .left
  | .second => .var .right

def Admitted (bodies : Bodies) (F : Formula Three) : Prop :=
  ∃ B : Formula Two,
    F.subst baseSub = .imp B B ∨
      FormulaRewrite bodies (F.subst baseSub) (.imp B B)

def QFInduction {D : Type} (M : Model D) : Prop :=
  ∀ F : Formula Three, ∀ a b : D,
    F.eval M (envThree M.zero a b) →
    (∀ n, F.eval M (envThree n a b) →
      F.eval M (envThree (M.succ n) a b)) →
    ∀ n, F.eval M (envThree n a b)

def Schema {D : Type} (M : Model D) (bodies : Bodies) : Prop :=
  ∀ F : Formula Three, Admitted bodies F → ∀ a b : D,
    (∀ n, F.eval M (envThree n a b) →
      F.eval M (envThree (M.succ n) a b)) →
    ∀ n, F.eval M (envThree n a b)

def paramLift : Two → Term Three
  | .left => .var .first
  | .right => .var .second

def stationary (A : Formula Two) : Formula Three := A.subst paramLift

theorem stationary_base (A : Formula Two) :
    (stationary A).subst baseSub = A := by
  unfold stationary
  rw [Formula.subst_subst]
  have h : (fun v => (paramLift v).subst baseSub) = Term.var := by
    funext v
    cases v <;> rfl
  rw [h, Formula.subst_id]

theorem eval_stationary {D : Type} (M : Model D) (A : Formula Two)
    (n a b : D) :
    (stationary A).eval M (envThree n a b) ↔
      A.eval M (envTwo a b) := by
  unfold stationary
  rw [Formula.eval_subst]
  have h : (fun v => (paramLift v).eval M (envThree n a b)) =
      envTwo a b := by
    funext v
    cases v <;> rfl
  rw [h]

theorem schema_stationary {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema M bodies) (A : Formula Two)
    (had : Admitted bodies (stationary A)) (a b : D) :
    A.eval M (envTwo a b) := by
  have hp : ∀ n, (stationary A).eval M (envThree n a b) →
      (stationary A).eval M (envThree (M.succ n) a b) := by
    intro n hn
    exact (eval_stationary M A (M.succ n) a b).2
      ((eval_stationary M A n a b).1 hn)
  exact (eval_stationary M A M.zero a b).1
    (H (stationary A) had a b hp M.zero)

def initProbe (k : Nat) : Formula Two :=
  .imp (.eq (.var .left) (.var .left))
    (.eq (.app k .zero (.var .left)) (.var .left))

theorem initProbe_admitted (bodies : Bodies) (k : Nat) :
    Admitted bodies (stationary (initProbe k)) := by
  refine ⟨.eq (.var .left) (.var .left), Or.inr ?_⟩
  rw [stationary_base]
  exact FormulaRewrite.impRight (FormulaRewrite.eqLeft
    (TermRewrite.base (bodies := bodies) k (Term.var Two.left)))

theorem schema_bases {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema M bodies) : Bases M := by
  intro k a
  have p := schema_stationary M bodies H (initProbe k)
    (initProbe_admitted bodies k) a M.zero
  exact p rfl

def stepRhs (bodies : Bodies) (k : Nat) : Term Two :=
  bodyApp bodies k (.var .left) (.app k (.var .left) (.var .right))

def stepProbe (bodies : Bodies) (k : Nat) : Formula Two :=
  .imp (.eq (stepRhs bodies k) (stepRhs bodies k))
    (.eq (.app k (.succ (.var .left)) (.var .right)) (stepRhs bodies k))

theorem stepProbe_admitted (bodies : Bodies) (k : Nat) :
    Admitted bodies (stationary (stepProbe bodies k)) := by
  refine ⟨.eq (stepRhs bodies k) (stepRhs bodies k), Or.inr ?_⟩
  rw [stationary_base]
  exact FormulaRewrite.impRight (FormulaRewrite.eqLeft
    (TermRewrite.step (bodies := bodies) k (Term.var Two.left) (Term.var Two.right)))

theorem schema_steps {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema M bodies) : Steps M bodies := by
  intro k n a
  have p := schema_stationary M bodies H (stepProbe bodies k)
    (stepProbe_admitted bodies k) n a
  have q : M.app k (M.succ n) a =
      (stepRhs bodies k).eval M (envTwo n a) := p rfl
  unfold stepRhs at q
  rw [eval_bodyApp] at q
  exact q

def sepProbe : Formula Two := .imp guard .bot

theorem sepProbe_admitted (bodies : Bodies) :
    Admitted bodies (stationary sepProbe) := by
  refine ⟨.bot, Or.inr ?_⟩
  rw [stationary_base]
  exact .impLeft .guard

theorem schema_separation {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema M bodies) : Separation M := by
  exact schema_stationary M bodies H sepProbe (sepProbe_admitted bodies)
    M.zero M.zero

def freezeCounter : Three → Term Three
  | .counter => .zero
  | .first => .var .first
  | .second => .var .second

def inductionProbe (F : Formula Three) : Formula Three :=
  .imp (F.subst freezeCounter) F

theorem inductionProbe_admitted (bodies : Bodies) (F : Formula Three) :
    Admitted bodies (inductionProbe F) := by
  refine ⟨F.subst baseSub, Or.inl ?_⟩
  have h : (fun v => (freezeCounter v).subst baseSub) = baseSub := by
    funext v
    cases v <;> rfl
  simp only [inductionProbe, Formula.subst, Formula.subst_subst, h]

theorem eval_inductionProbe {D : Type} (M : Model D) (F : Formula Three)
    (n a b : D) :
    (inductionProbe F).eval M (envThree n a b) ↔
      (F.eval M (envThree M.zero a b) → F.eval M (envThree n a b)) := by
  have h : (fun v => (freezeCounter v).eval M (envThree n a b)) =
      envThree M.zero a b := by
    funext v
    cases v <;> rfl
  simp only [inductionProbe, Formula.eval, Formula.eval_subst, h]

theorem schema_induction {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema M bodies) : QFInduction M := by
  intro F a b hz hs n
  have hp : ∀ m, (inductionProbe F).eval M (envThree m a b) →
      (inductionProbe F).eval M (envThree (M.succ m) a b) := by
    intro m hm
    apply (eval_inductionProbe M F (M.succ m) a b).2
    intro hbase
    exact hs m ((eval_inductionProbe M F m a b).1 hm hbase)
  have p := H (inductionProbe F) (inductionProbe_admitted bodies F) a b hp n
  exact (eval_inductionProbe M F n a b).1 p hz

theorem eval_base {D : Type} (M : Model D) (F : Formula Three) (a b : D) :
    (F.subst baseSub).eval M (envTwo a b) ↔
      F.eval M (envThree M.zero a b) := by
  rw [Formula.eval_subst]
  have h : (fun v => (baseSub v).eval M (envTwo a b)) =
      envThree M.zero a b := by
    funext v
    cases v <;> rfl
  rw [h]

theorem admitted_base {D : Type} (M : Model D) (bodies : Bodies)
    (hb : Bases M) (hs : Steps M bodies) (he : Separation M)
    (F : Formula Three) (had : Admitted bodies F) (a b : D) :
    F.eval M (envThree M.zero a b) := by
  apply (eval_base M F a b).1
  obtain ⟨B, hz | hr⟩ := had
  · rw [hz]
    exact fun hB => hB
  · apply (FormulaRewrite.sound M bodies hb hs he hr (envTwo a b)).2
    exact fun hB => hB

theorem base_induction_schema {D : Type} (M : Model D) (bodies : Bodies)
    (hb : Bases M) (hs : Steps M bodies) (he : Separation M)
    (hi : QFInduction M) : Schema M bodies := by
  intro F had a b hp n
  exact hi F a b (admitted_base M bodies hb hs he F had a b) hp n

theorem schema_iff {D : Type} (M : Model D) (bodies : Bodies) :
    Schema M bodies ↔
      Bases M ∧ Steps M bodies ∧ Separation M ∧ QFInduction M := by
  constructor
  · intro H
    exact ⟨schema_bases M bodies H, schema_steps M bodies H,
      schema_separation M bodies H, schema_induction M bodies H⟩
  · rintro ⟨hb, hs, he, hi⟩
    exact base_induction_schema M bodies hb hs he hi

/- The 18-node endpoint variant uses its second frozen parameter as the
   requested conclusion index. Its exact local equivalence is to endpoint
   induction, not directly to full two-parameter induction. Recovering the
   latter uses the arithmetic pairing proof supplied separately in the paper. -/

def EndpointSchema {D : Type} (M : Model D) (bodies : Bodies) : Prop :=
  ∀ F : Formula Three, Admitted bodies F → ∀ a b : D,
    (∀ n, F.eval M (envThree n a b) →
      F.eval M (envThree (M.succ n) a b)) →
    F.eval M (envThree b a b)

def EndpointInduction {D : Type} (M : Model D) : Prop :=
  ∀ F : Formula Three, ∀ a b : D,
    F.eval M (envThree M.zero a b) →
    (∀ n, F.eval M (envThree n a b) →
      F.eval M (envThree (M.succ n) a b)) →
    F.eval M (envThree b a b)

theorem schema_endpoint {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema M bodies) : EndpointSchema M bodies := by
  intro F had a b hp
  exact H F had a b hp b

theorem endpoint_stationary {D : Type} (M : Model D) (bodies : Bodies)
    (H : EndpointSchema M bodies) (A : Formula Two)
    (had : Admitted bodies (stationary A)) (a b : D) :
    A.eval M (envTwo a b) := by
  have hp : ∀ n, (stationary A).eval M (envThree n a b) →
      (stationary A).eval M (envThree (M.succ n) a b) := by
    intro n hn
    exact (eval_stationary M A (M.succ n) a b).2
      ((eval_stationary M A n a b).1 hn)
  exact (eval_stationary M A b a b).1
    (H (stationary A) had a b hp)

theorem endpoint_bases {D : Type} (M : Model D) (bodies : Bodies)
    (H : EndpointSchema M bodies) : Bases M := by
  intro k a
  have p := endpoint_stationary M bodies H (initProbe k)
    (initProbe_admitted bodies k) a M.zero
  exact p rfl

theorem endpoint_steps {D : Type} (M : Model D) (bodies : Bodies)
    (H : EndpointSchema M bodies) : Steps M bodies := by
  intro k n a
  have p := endpoint_stationary M bodies H (stepProbe bodies k)
    (stepProbe_admitted bodies k) n a
  have q : M.app k (M.succ n) a =
      (stepRhs bodies k).eval M (envTwo n a) := p rfl
  unfold stepRhs at q
  rw [eval_bodyApp] at q
  exact q

theorem endpoint_separation {D : Type} (M : Model D) (bodies : Bodies)
    (H : EndpointSchema M bodies) : Separation M := by
  exact endpoint_stationary M bodies H sepProbe (sepProbe_admitted bodies)
    M.zero M.zero

theorem endpoint_induction {D : Type} (M : Model D) (bodies : Bodies)
    (H : EndpointSchema M bodies) : EndpointInduction M := by
  intro F a b hz hs
  have hp : ∀ m, (inductionProbe F).eval M (envThree m a b) →
      (inductionProbe F).eval M (envThree (M.succ m) a b) := by
    intro m hm
    apply (eval_inductionProbe M F (M.succ m) a b).2
    intro hbase
    exact hs m ((eval_inductionProbe M F m a b).1 hm hbase)
  have p := H (inductionProbe F) (inductionProbe_admitted bodies F) a b hp
  exact (eval_inductionProbe M F b a b).1 p hz

theorem base_endpointInduction_schema {D : Type} (M : Model D)
    (bodies : Bodies) (hb : Bases M) (hs : Steps M bodies)
    (he : Separation M) (hi : EndpointInduction M) :
    EndpointSchema M bodies := by
  intro F had a b hp
  exact hi F a b (admitted_base M bodies hb hs he F had a b) hp

theorem base_induction_endpoint {D : Type} (M : Model D) (bodies : Bodies)
    (hb : Bases M) (hs : Steps M bodies) (he : Separation M)
    (hi : QFInduction M) : EndpointSchema M bodies := by
  exact schema_endpoint M bodies (base_induction_schema M bodies hb hs he hi)

theorem endpoint_iff {D : Type} (M : Model D) (bodies : Bodies) :
    EndpointSchema M bodies ↔
      Bases M ∧ Steps M bodies ∧ Separation M ∧ EndpointInduction M := by
  constructor
  · intro H
    exact ⟨endpoint_bases M bodies H, endpoint_steps M bodies H,
      endpoint_separation M bodies H, endpoint_induction M bodies H⟩
  · rintro ⟨hb, hs, he, hi⟩
    exact base_endpointInduction_schema M bodies hb hs he hi

def oneParameterLift : Two → Term Three
  | .left => .var .counter
  | .right => .var .first

def liftOneParameter (F : Formula Two) : Formula Three :=
  F.subst oneParameterLift

def OneParameterInduction {D : Type} (M : Model D) : Prop :=
  ∀ F : Formula Two, ∀ a : D,
    F.eval M (envTwo M.zero a) →
    (∀ n, F.eval M (envTwo n a) → F.eval M (envTwo (M.succ n) a)) →
    ∀ n, F.eval M (envTwo n a)

theorem eval_liftOneParameter {D : Type} (M : Model D) (F : Formula Two)
    (n a b : D) :
    (liftOneParameter F).eval M (envThree n a b) ↔
      F.eval M (envTwo n a) := by
  unfold liftOneParameter
  rw [Formula.eval_subst]
  have h : (fun v => (oneParameterLift v).eval M (envThree n a b)) =
      envTwo n a := by
    funext v
    cases v <;> rfl
  rw [h]

theorem endpointInduction_oneParameter {D : Type} (M : Model D)
    (hi : EndpointInduction M) : OneParameterInduction M := by
  intro F a hz hs n
  have hbase : (liftOneParameter F).eval M (envThree M.zero a n) :=
    (eval_liftOneParameter M F M.zero a n).2 hz
  have hp : ∀ m, (liftOneParameter F).eval M (envThree m a n) →
      (liftOneParameter F).eval M (envThree (M.succ m) a n) := by
    intro m hm
    exact (eval_liftOneParameter M F (M.succ m) a n).2
      (hs m ((eval_liftOneParameter M F m a n).1 hm))
  exact (eval_liftOneParameter M F n a n).1
    (hi (liftOneParameter F) a n hbase hp)

theorem endpoint_oneParameter {D : Type} (M : Model D) (bodies : Bodies)
    (H : EndpointSchema M bodies) : OneParameterInduction M := by
  exact endpointInduction_oneParameter M (endpoint_induction M bodies H)

#print axioms TermRewrite.sound
#print axioms FormulaRewrite.sound
#print axioms initProbe_admitted
#print axioms stepProbe_admitted
#print axioms sepProbe_admitted
#print axioms inductionProbe_admitted
#print axioms schema_bases
#print axioms schema_steps
#print axioms schema_separation
#print axioms schema_induction
#print axioms admitted_base
#print axioms schema_iff
#print axioms schema_endpoint
#print axioms endpoint_bases
#print axioms endpoint_steps
#print axioms endpoint_separation
#print axioms endpoint_induction
#print axioms base_induction_endpoint
#print axioms endpoint_iff
#print axioms endpoint_oneParameter

end OneRewrite
