#!/usr/bin/env python3
"""Independent finite-syntax diagnostics for the C18/C19/C15 PRA schemes.

Standard library only. These checks verify syntax, certificates and bounded
standard-N examples. They do not prove the arithmetic compiler, induction on
nonstandard models, or the complete bi-interpretability theorem.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass, FrozenInstanceError
import hashlib
import json
from pathlib import Path
import random
import sys


@dataclass(frozen=True, slots=True)
class Node:
    tag: str
    value: str | int | None = None
    children: tuple["Node", ...] = ()


def V(name):
    return Node("var", name)


ZERO = Node("zero")
BOT = Node("bot")


def S(t):
    return Node("succ", children=(t,))


def R(index, counter, seed):
    return Node("rec", index, (counter, seed))


def Eq(s, t):
    return Node("eq", children=(s, t))


def Imp(p, q):
    return Node("imp", children=(p, q))


def And(p, q):
    return Node("and", children=(p, q))


def Or(p, q):
    return Node("or", children=(p, q))


def All(variable, formula):
    return Node("all", variable, (formula,))


def Meta(name, *arguments):
    """Display-metric placeholder only; not admitted by formula validation."""
    return Node("meta", name, tuple(arguments))


def encode(node):
    return [node.tag, node.value, [encode(c) for c in node.children]]


def size(node):
    return 1 + sum(size(c) for c in node.children)


def free_variables(node):
    if node.tag == "var":
        return frozenset((node.value,))
    found = frozenset().union(*(free_variables(c) for c in node.children))
    return found - {node.value} if node.tag in {"all", "exists"} else found


def names(node):
    own = {node.value} if node.tag in {"var", "all", "exists"} else set()
    return own.union(*(names(c) for c in node.children))


def substitute(node, mapping):
    """Capture-avoiding active-tree substitution; descriptor metadata is opaque."""
    if node.tag == "var":
        return mapping.get(node.value, node)
    if node.tag in {"all", "exists"}:
        binder, body = node.value, node.children[0]
        active = {k: v for k, v in mapping.items() if k != binder}
        replacement_free = frozenset().union(*(
            free_variables(v) for k, v in active.items()
            if k in free_variables(body)
        ))
        if binder in replacement_free:
            occupied = names(body) | set(active)
            occupied |= set().union(*(names(v) for v in active.values()))
            suffix = 1
            while f"{binder}_{suffix}" in occupied:
                suffix += 1
            fresh = f"{binder}_{suffix}"
            body = substitute(body, {binder: V(fresh)})
            binder = fresh
        return Node(node.tag, binder, (substitute(body, active),))
    return Node(node.tag, node.value,
                tuple(substitute(c, mapping) for c in node.children))


@dataclass(frozen=True, slots=True)
class Descriptor:
    name: str
    body: Node


Registry = tuple[Descriptor, ...]


def valid_term(node, registry, upper=None):
    bound = len(registry) if upper is None else upper
    if node.tag == "var":
        return isinstance(node.value, str) and not node.children
    if node.tag == "zero":
        return node.value is None and not node.children
    if node.tag == "succ":
        return len(node.children) == 1 and valid_term(node.children[0], registry, bound)
    if node.tag == "rec":
        return (isinstance(node.value, int) and 0 <= node.value < bound
                and len(node.children) == 2
                and all(valid_term(c, registry, bound) for c in node.children))
    return False


def valid_formula(node, registry):
    if node.tag == "bot":
        return not node.children
    if node.tag == "eq":
        return len(node.children) == 2 and all(valid_term(c, registry) for c in node.children)
    if node.tag in {"imp", "and", "or"}:
        return len(node.children) == 2 and all(valid_formula(c, registry) for c in node.children)
    if node.tag in {"all", "exists"}:
        return (isinstance(node.value, str) and len(node.children) == 1
                and valid_formula(node.children[0], registry))
    return False


def validate_registry(registry):
    for index, description in enumerate(registry):
        if free_variables(description.body) - {"u", "v"}:
            raise ValueError("A stored update has undeclared interface variables")
        if not valid_term(description.body, registry, upper=index):
            raise ValueError("An update is not an earlier-only finite term")


def is_qf(node):
    return node.tag not in {"all", "exists"} and all(is_qf(c) for c in node.children)


def reflexive_implication(node):
    return node.tag == "imp" and node.children[0] == node.children[1]


def stationary_universal_equations(node):
    """The paper's precise V15 extra branch, with literal binder name b."""
    if node.tag != "imp":
        return False
    for branch in node.children:
        if branch.tag != "all" or branch.value != "b":
            return False
        equation = branch.children[0]
        if equation.tag != "eq":
            return False
        if any(free_variables(term) - {"a", "b"} for term in equation.children):
            return False
    return True


def active_positions(node, path=()):
    yield path, node
    for index, child in enumerate(node.children):
        yield from active_positions(child, path + (index,))


def replace_at(node, path, replacement):
    if not path:
        return replacement
    children = list(node.children)
    children[path[0]] = replace_at(children[path[0]], path[1:], replacement)
    return Node(node.tag, node.value, tuple(children))


def replacement(node, registry):
    if node.tag == "rec":
        counter, seed = node.children
        if counter == ZERO:
            return "Z", seed, node.value
        if counter.tag == "succ":
            predecessor = counter.children[0]
            body = registry[node.value].body
            expanded = substitute(body, {"u": predecessor,
                                        "v": R(node.value, predecessor, seed)})
            return "S", expanded, node.value
    if node == Eq(ZERO, S(ZERO)):
        return "D", BOT, None
    return None


def one_step_results(formula, registry):
    """Choose a position in the ORIGINAL tree; never visit inserted material."""
    for path, node in active_positions(formula):
        match = replacement(node, registry)
        if match is not None:
            rule, new_node, descriptor = match
            certificate = {"steps": 1, "rule": rule, "path": list(path),
                           "descriptor": descriptor}
            yield certificate, replace_at(formula, path, new_node)


def admitted(formula, registry, scheme="C18_star"):
    if not valid_formula(formula, registry):
        return None
    fv = free_variables(formula)
    if scheme in {"C18", "C19", "C18_star"}:
        if not is_qf(formula) or fv - {"n", "a", "b"}:
            return None
        if scheme == "C18_star" and "n" in fv and "b" in fv:
            return None
    elif scheme == "C15":
        if fv - {"n", "a"}:
            return None
        if not is_qf(formula) and not stationary_universal_equations(formula):
            return None
    else:
        raise ValueError(f"Unknown scheme: {scheme}")
    base = substitute(formula, {"n": ZERO})
    if reflexive_implication(base):
        return {"steps": 0, "rule": "identity", "path": [], "descriptor": None}
    for certificate, rewritten in one_step_results(base, registry):
        if reflexive_implication(rewritten):
            return certificate
    return None


def expanded_c18(formula):
    step = All("n", Imp(formula, substitute(formula, {"n": S(V("n"))})))
    return All("a", All("b", Imp(step, substitute(formula, {"n": V("b")}))))


def free_occurrences(node, variable):
    if node.tag == "var":
        return int(node.value == variable)
    if node.tag in {"all", "exists"} and node.value == variable:
        return 0
    return sum(free_occurrences(c, variable) for c in node.children)


def standard_value(node, environment, registry, budget=None):
    """Bounded diagnostic interpreter for the finitely selected descriptions."""
    budget = [250000] if budget is None else budget
    budget[0] -= 1
    if budget[0] < 0:
        raise RuntimeError("Diagnostic evaluation budget exceeded")
    if node.tag == "var":
        return environment[node.value]
    if node.tag == "zero":
        return 0
    if node.tag == "succ":
        return 1 + standard_value(node.children[0], environment, registry, budget)
    if node.tag == "rec":
        counter = standard_value(node.children[0], environment, registry, budget)
        current = standard_value(node.children[1], environment, registry, budget)
        for index in range(counter):
            current = standard_value(registry[node.value].body,
                                     {"u": index, "v": current}, registry, budget)
        return current
    raise ValueError("Not a term")


def standard_truth(node, environment, registry):
    if node.tag == "bot":
        return False
    if node.tag == "eq":
        return standard_value(node.children[0], environment, registry) == standard_value(
            node.children[1], environment, registry)
    p = standard_truth(node.children[0], environment, registry)
    q = standard_truth(node.children[1], environment, registry)
    if node.tag == "imp":
        return not p or q
    if node.tag == "and":
        return p and q
    if node.tag == "or":
        return p or q
    raise ValueError("Only QF diagnostic truth evaluation is supported")


class Ledger:
    def __init__(self):
        self.groups = Counter()

    def require(self, condition, group, label):
        if not condition:
            raise AssertionError(f"{group}: {label}")
        self.groups[group] += 1


def sample_registry():
    u, v = V("u"), V("v")
    rows = (
        ("counter", u), ("identity", v), ("reset", ZERO),
        ("successor_value", S(v)), ("successor_counter", S(u)),
        ("earlier_increment", R(3, u, v)),
        ("earlier_counter", R(0, v, u)),
        ("nested_identity", S(R(1, u, v))),
        ("reversed_increment", R(3, v, u)),
        ("nested_reset", R(2, S(u), v)),
        ("mixed_earlier", R(7, u, R(0, v, ZERO))),
        ("metadata_redex", R(1, ZERO, v)),
    )
    registry = tuple(Descriptor(name, body) for name, body in rows)
    validate_registry(registry)
    return registry


def run_checks(seed):
    ledger = Ledger()
    check = ledger.require
    registry = sample_registry()
    original_registry = tuple((d.name, encode(d.body)) for d in registry)
    a, b, n = V("a"), V("b"), V("n")
    probes = []
    saved_formulas = []

    for index, description in enumerate(registry):
        t = substitute(description.body, {"u": a, "v": R(index, a, b)})
        rows = (
            ("R0", Imp(Eq(a, a), Eq(R(index, ZERO, a), a)), "Z"),
            ("RS", Imp(Eq(t, t), Eq(R(index, S(a), b), t)), "S"),
        )
        for label, formula, rule in rows:
            for scheme in ("C18", "C19", "C18_star"):
                witness = admitted(formula, registry, scheme)
                check(witness is not None and witness["steps"] == 1
                      and witness["rule"] == rule,
                      "stationary_probes", f"{label}/{index}/{scheme}")
            probes.append({"kind": label, "descriptor": index,
                           "descriptor_name": description.name,
                           "certificate": admitted(formula, registry)})
            saved_formulas.append(formula)
            check(size(expanded_c18(formula)) == 5 + 3 * size(formula)
                  + free_occurrences(formula, "n"), "expanded_size", f"{label}/{index}")

    separation = Imp(Eq(ZERO, S(ZERO)), BOT)
    certificate = admitted(separation, registry)
    check(certificate is not None and certificate["rule"] == "D",
          "separation", "one atom rewrite")
    probes.append({"kind": "Sep", "certificate": certificate})
    saved_formulas.append(separation)

    rng = random.Random(seed)

    def random_term(depth):
        if depth == 0:
            return rng.choice((ZERO, a, n))
        option = rng.randrange(4)
        if option == 0:
            return rng.choice((ZERO, a, n))
        if option == 1:
            return S(random_term(depth - 1))
        return R(rng.randrange(len(registry)), random_term(depth - 1),
                 random_term(depth - 1))

    def random_formula(depth):
        if depth == 0 or rng.randrange(4) == 0:
            return BOT if rng.randrange(7) == 0 else Eq(random_term(2), random_term(2))
        return rng.choice((Imp, And, Or))(random_formula(depth - 1),
                                          random_formula(depth - 1))

    random_sizes = []
    for number in range(420):
        goal = random_formula(3)
        formula = Imp(substitute(goal, {"n": ZERO}), goal)
        witness = admitted(formula, registry)
        check(witness is not None and witness["steps"] == 0,
              "random_zero_step_qfi", str(number))
        check("b" not in free_variables(formula), "dynamic_fv", str(number))
        expanded = size(expanded_c18(formula))
        check(expanded == 5 + 3 * size(formula) + free_occurrences(formula, "n"),
              "expanded_size", f"random/{number}")
        random_sizes.append(expanded)

    three_variable = Imp(Eq(R(3, n, a), b), Eq(R(3, n, a), b))
    check(admitted(three_variable, registry, "C18") is not None,
          "fv_policies", "unrestricted C18 allows three slots")
    check(admitted(three_variable, registry, "C19") is not None,
          "fv_policies", "C19 allows three slots")
    check(admitted(three_variable, registry, "C18_star") is None,
          "fv_policies", "C18_star rejects jointly dynamic/probe-dependent matrix")
    outsider = Imp(Eq(V("c"), V("c")), Eq(V("c"), V("c")))
    for scheme in ("C18", "C19", "C18_star", "C15"):
        check(admitted(outsider, registry, scheme) is None,
              "fv_policies", f"reject external free variable/{scheme}")

    index = 7
    t = substitute(registry[index].body, {"u": a, "v": R(index, a, b)})
    stationary_15 = Imp(All("b", Eq(t, t)), All("b", Eq(R(index, S(a), b), t)))
    witness_15 = admitted(stationary_15, registry, "C15")
    check(witness_15 is not None and witness_15["steps"] == 1
          and witness_15["rule"] == "S", "stationary_C15", "quantified RS probe")
    check(admitted(stationary_15, registry, "C18_star") is None,
          "stationary_C15", "main scheme stays QF")
    dynamic_quantified = Imp(All("b", Eq(n, b)), All("b", Eq(n, b)))
    check(admitted(dynamic_quantified, registry, "C15") is None,
          "stationary_C15", "no quantified dynamic induction")
    other_stationary = Imp(All("b", BOT), All("b", BOT))
    check(admitted(other_stationary, registry, "C15") is None,
          "stationary_C15", "stationary quantifiers must have the exact equation shape")
    probes.append({"kind": "C15 quantified RS", "descriptor": index,
                   "formula": encode(stationary_15), "certificate": witness_15})

    multiple = Imp(Eq(a, a), Eq(R(1, ZERO, R(1, ZERO, a)), a))
    check(admitted(multiple, registry) is None, "negative_controls", "two zero steps needed")
    two_step_success = any(reflexive_implication(second)
                           for _, first in one_step_results(multiple, registry)
                           for _, second in one_step_results(first, registry))
    check(two_step_success, "negative_controls", "control really succeeds after two steps")
    inserted = Imp(Eq(S(b), S(b)), Eq(R(7, S(ZERO), b), S(b)))
    check(admitted(inserted, registry) is None,
          "negative_controls", "inserted earlier body is not rescanned")
    inserted_results = list(one_step_results(inserted, registry))
    check(len(inserted_results) == 1 and inserted_results[0][0]["rule"] == "S",
          "negative_controls", "only original S redex is visited")
    mismatch = Imp(Eq(a, a), Eq(R(1, ZERO, b), a))
    check(admitted(mismatch, registry) is None,
          "negative_controls", "literal branch mismatch is rejected")
    reversed_atom = Imp(Eq(S(ZERO), ZERO), BOT)
    check(admitted(reversed_atom, registry) is None,
          "negative_controls", "D is directional and literal")
    lone_false = BOT
    check(admitted(lone_false, registry) is None,
          "negative_controls", "unrestricted false matrix is rejected")

    opaque_term = R(11, a, b)
    opaque_formula = Eq(opaque_term, opaque_term)
    check(not list(one_step_results(opaque_formula, registry)),
          "metadata_opacity", "stored redex is not active")
    check(free_variables(opaque_term) == {"a", "b"},
          "metadata_opacity", "interface u,v are not active free variables")
    check(substitute(opaque_term, {"u": ZERO, "v": ZERO}) == opaque_term,
          "metadata_opacity", "substitution does not enter stored update")
    check(tuple((d.name, encode(d.body)) for d in registry) == original_registry,
          "metadata_opacity", "registry unchanged after all probes")
    try:
        registry[0].body = ZERO
    except FrozenInstanceError:
        immutable = True
    else:
        immutable = False
    check(immutable, "registry_validation", "descriptor object is immutable")
    for bad_body in (R(0, V("u"), V("v")), V("extra")):
        try:
            validate_registry((Descriptor("invalid", bad_body),))
        except ValueError:
            rejected = True
        else:
            rejected = False
        check(rejected, "registry_validation", "forward/self reference or extra variable")

    captured = substitute(All("b", Eq(n, b)), {"n": b})
    check(captured.value != "b" and free_variables(captured) == {"b"},
          "substitution", "quantifier capture is avoided")
    check(substitute(All("n", Eq(n, a)), {"n": ZERO}) == All("n", Eq(n, a)),
          "substitution", "bound occurrences are untouched")

    f3 = lambda counter: Meta("F", counter, a, b)
    f2 = lambda counter: Meta("F", counter, a)
    metrics = {
        "C18": size(All("a", All("b", Imp(All("n", Imp(f3(n), f3(S(n)))), f3(b))))),
        "C19": size(All("a", All("b", Imp(All("n", Imp(f3(n), f3(S(n)))), All("n", f3(n)))))),
        "C15": size(All("a", Imp(All("n", Imp(f2(n), f2(S(n)))), All("n", f2(n))))),
        "baseline_N26": size(All("a", Imp(All("n", Imp(f2(n), f2(S(n)))),
            All("n", And(f2(n), Eq(R(0, S(n), a), Meta("h", n, R(0, n, a)))))))),
    }
    for label, expected in (("C18", 18), ("C19", 19), ("C15", 15), ("baseline_N26", 26)):
        check(metrics[label] == expected, "partial_AST_metrics", label)

    for number, formula in enumerate(saved_formulas):
        for certificate, result in one_step_results(formula, registry):
            for aa in range(3):
                for bb in range(3):
                    environment = {"a": aa, "b": bb, "n": 1}
                    check(standard_truth(formula, environment, registry)
                          == standard_truth(result, environment, registry),
                          "finite_N_rewrite_diagnostics",
                          f"probe {number}/{certificate['path']}/{aa}/{bb}")

    return {
        "status": "passed", "checks_passed": sum(ledger.groups.values()),
        "check_groups": dict(sorted(ledger.groups.items())),
        "random_seed": seed, "random_QF_induction_probes": 420,
        "random_expanded_size_range": [min(random_sizes), max(random_sizes)],
        "metrics": metrics,
        "expanded_C18_formula": "5 + 3*m + free_counter_occurrences",
        "descriptor_registry": [{"index": i, "name": d.name, "body": encode(d.body)}
                                for i, d in enumerate(registry)],
        "certificates": probes,
        "negative_controls": ["two-step-only base", "inserted-body rescan",
            "literal mismatch", "reversed separation atom", "false matrix",
            "extra free variable", "quantified dynamic matrix", "metadata rewrite"],
        "scope": ("Finite syntactic and bounded standard-natural-number diagnostics only. "
                  "Not an end-to-end proof of the first-order arithmetic compiler, "
                  "nonstandard-model properties, or bi-interpretability."),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("results.json"))
    parser.add_argument("--seed", type=int, default=20261101)
    arguments = parser.parse_args()
    result = run_checks(arguments.seed)
    result["source_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": result["status"], "checks_passed": result["checks_passed"],
                      "metrics": result["metrics"], "output": str(arguments.output)}))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"FAILED: {error}", file=sys.stderr)
        raise SystemExit(1)
