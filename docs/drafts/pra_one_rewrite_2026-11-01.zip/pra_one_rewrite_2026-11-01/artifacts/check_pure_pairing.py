"""Finite numerical checks for the pure-iteration pairing candidate.

This is a standard-natural test, not an internal proof or a proof of the full
axiomatization.  p, Z, addition, subtraction, and C use their established
closed forms.  Every newly proposed iterator uses only a unary state update.
"""
from functools import cache
import json
from pathlib import Path


def iterate(step, count, seed):
    value = seed
    for _ in range(count):
        value = step(value)
    return value


def p(value):
    return max(value - 1, 0)


def C(test, yes, no):
    return yes if test == 0 else no


def d(left, right):
    return max(left - right, 0)


def c(value):
    return C(d(value, 1), value + 1, 0)


@cache
def m(value):
    return iterate(c, value, 0)


def g(value):
    return value + 1 + int(m(value) == 1)


@cache
def G(value):
    return iterate(g, value, 0)


@cache
def r(value):
    return m(G(value))


@cache
def H(value):
    return d(G(value), value)


def u(value):
    return C(r(value), H(value), value)


def w(value):
    return C(r(value), H(value), value + 2)


@cache
def U(value):
    return iterate(u, value, value)


@cache
def W(value):
    return iterate(w, value, value)


def A(value):
    return value + value + U(value)


def L(value):
    return H(d(A(value), W(value)))


def R(value):
    return H(U(value))


def J(left, right):
    return iterate(lambda value: value + value, left, 1 + right + right)


def scanner(predicate, count):
    def step(value):
        if value == 0:
            return 0
        if value == 1:
            return 1
        tested = p(p(value))
        if not predicate(tested):
            return 1
        return C(tested, 0, p(value))

    return iterate(step, count + 1, count + 2)


def check():
    checked = 0
    for value in range(151):
        assert H(value) == value // 2
        assert r(value) == value % 2
        assert value == 2 * H(value) + r(value)
        assert W(value) <= A(value)
        assert U(2 * value) == U(value)
        assert U(2 * value + 1) == 2 * value + 1
        assert W(2 * value + 1) == 3 * (2 * value + 1)
        assert L(2 * value + 1) == 0
        assert R(2 * value + 1) == value
        if value:
            assert r(U(value)) == r(W(value)) == 1
            assert u(U(value)) == U(value)
            assert W(2 * value) == W(value) + 2 * p(value)
            assert L(2 * value) == L(value) + 1
            assert R(2 * value) == R(value)
        checked += 1
    pairs = 0
    for left in range(7):
        for right in range(9):
            code = J(left, right)
            assert L(code) == left
            assert R(code) == right
            pairs += 1
    scans = 0
    for mask in range(256):
        pred = lambda n, mask=mask: bool(mask & (1 << n))
        for count in range(8):
            assert (scanner(pred, count) == 0) == all(pred(k) for k in range(count + 1))
            scans += 1
    return {
        "status": "passed",
        "scope": "finite standard-natural checks, not a proof",
        "unary_input_values": checked,
        "pairing_cases": pairs,
        "scanner_cases": scans,
        "largest_pairing_code": J(6, 8),
    }


if __name__ == "__main__":
    result = check()
    encoded = json.dumps(result, indent=2) + "\n"
    Path(__file__).with_name("pure_pairing_results.json").write_text(encoded)
    print(encoded, end="")
