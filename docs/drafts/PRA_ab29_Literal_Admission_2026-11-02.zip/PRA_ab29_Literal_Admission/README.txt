PRA further reductions at ab29d2ad21 — 2 November 2026

Read report.pdf (9 pages); edit/rebuild report.tex.

Main result: a literal three-case admission test replaces normalization in
an equivalent 26-node presentation. A separate 19-node pure-propagation
presentation is proved with two parameters. Neither beats the strongest
supplied presentation in total description length. Pure15 remains open.

REPLAY
  python3 checks/check.py
  python3 checks/arity_audit.py
Requires Python 3 standard library only. The tests count ASTs, verify 8
source ZIP identities, check finite normalization examples and reject a
hidden second parameter. They are not formal proof certificates.

BUILD
  sh build.sh
Requires a functioning pdfLaTeX installation with article, geometry,
amsmath/amssymb/amsthm, booktabs, hyperref, fancyhdr, lmodern. Run twice.
The font-map declarations in report.tex accommodate the build host's
TeX layout; ordinary complete TeX installations can remove those three
pdfmapfile lines and use their configured font maps.

SOURCES AND PROOFS
sources/: all 8 exact source ZIPs; verified_manifest.json gives immutable
URLs, bytes, Git blob SHA-1, SHA-256 and relevant TeX members. Source
archives are evidence, not scripts automatically executed by our checks.
The guarded-seed source provides inherited arithmetic/pairing/compiler
calibration. The new constructive equivalence proofs are in report.tex.
Additional independent audit notes are included. Their preliminary metric
conventions may differ; report.tex and checks/results.json specify the
final consistent changed-slot-image ledger.

No new proof-assistant kernel formalization is claimed.
