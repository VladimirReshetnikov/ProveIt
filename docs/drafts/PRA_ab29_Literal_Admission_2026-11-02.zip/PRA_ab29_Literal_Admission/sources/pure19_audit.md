# Independent audit: pure19 normalization alternative

Fix one update descriptor h with current binary symbol R=R_h; h contains only earlier symbols. Allow all quantifier-free F(n,a,b), but admit an instance only when N(F(0,a,b)) is literally B -> B. Emit

  forall a forall b ((forall n (F(n,a,b) -> F(Sn,a,b))) -> forall n F(n,a,b)).

N acts recursively on terms and formulas. Its current-symbol rules are R(0,t)->t and R(Su,t)->h(u,R(u,t)); after term normalization, equality 0=S0 is replaced by bottom. Other syntax is preserved. Normalize a rewritten RHS fully. Only the currently indexed R is rewritten, not earlier recursors.

Termination: after normalizing arguments of a current-R application, peel its finite leading successor spine. Each successor rewrite recurses on the strictly shorter spine; h has no current R, so substituting the normalized accumulator into h creates no new current-R applications outside already normalized inserted terms. Other term constructors are treated structurally. Formula traversal is structural. This also proves idempotence. No general evaluator for arbitrary codes is postulated.

Constructive extraction:
1. R0: F independent of n,b, namely (a=a)->R(0,a)=a. Its normalized tested base is (a=a)->(a=a). Its progress is logical identity. The conclusion gives the R0 equation by reflexivity.
2. RS: let t=h(a,R(a,b)); take F independent of n equal to (t=t)->R(Sa,b)=t. Both equation atoms normalize to the identical N(t)=N(t); progress is logical identity. Thus all a,b satisfy RS.
3. Separation: F independent of n,a,b equal to (0=S0)->bottom. Its normal form is bottom->bottom; the conclusion gives separation.
4. QFI2: for arbitrary G(n,a,b), take F=G(0,a,b)->G(n,a,b). At zero both sides are syntactically identical even after N. Under ordinary base and progress hypotheses, establish F-progress, apply the schema, and use the base to conclude G. No excluded middle is used.

Conversely, R0, RS, separation, and QFI2 prove every schema instance. Structural normalization soundness gives F(0,a,b) iff N(F(0,a,b)), using equality congruence and (0=S0) iff bottom. The admission condition proves the normalized base intuitionistically. Apply QFI2 to F. This establishes exact same-language equivalence to that explicit basis.

The old one-parameter basis is contained in QFI2. Its written pairing compiler recovers full QFI and ordinary PR; conversely PRA proves QFI2. Therefore the existing identity-round-trip argument transfers. This is a display improvement, not an overall improvement.

Metric (one AST node for each variable, constant, bottom, application, connective, and quantifier): F(n,a,b) costs4; F(Sn,a,b) costs5. Progress costs11; conclusion costs5; outer implication plus two parameter quantifiers costs3; display total19. With B(a,b) as a three-node metavariable application the admission reflexive pattern costs7, not5; the latter is valid only if B is encoded as a one-argument metasyntactic context. Under fully explicit two-parameter B(a,b) accounting:
- R0 rewrite sides4; RS sides9; separation sides5; pattern7.
- schema + pattern + rewrite sides =44.
- add zero substitution-image term1 =45.
- add one token per rewrite instruction3 =48.
These are partial ledgers, excluding descriptor/admission-program machinery. They do not beat guarded29 or normalized26 under comparable charged ledgers. If a zero-argument metavariable B denotes an arbitrary formula, all patterns must instead be consistently recounted that way.

No route established to remove the third matrix slot of direct guarded29 without losing independent seed access in the R0 probe. No valid pure15 recovery of arbitrary-seed RS was obtained. Closed-seed induction does not by itself supply the two independent arguments needed in the constant RS probe; pairing may not be assumed before its required recurrence equations are available.
