# Exact source review

Commit: ab29d2ad2189948d995d6cffa7cea5298cd126a0. Eight current ZIPs downloaded and their Git blob SHA-1 identities checked; verified_manifest.json records bytes, SHA-256, raw URL and TeX members. No imported code executed.

## Main frontier

- pra_guarded_seed and pra_syntactic_base: same direct-substitution core G, 29 partial display nodes, no separate separation axiom. Quantifier-free A(x,z,w); admissible when A(0,R_h(0,a),a) is literally (B or 0=S0) implies B. Emit forall a [(forall n (A(n,a,a) implies A(Sn,a,a))) implies forall n (A(n,a,a) and RS)]. Constant probes extract separation, recursion initialization and successor computation; normalizing arbitrary F by (F(0,a) or bad) implies F(n,a) recovers I1 constructively. Converse uses R0, separation, I1 and RS. Exact same-language equivalence is elementary and valid. Both reports supply full written arithmetic/compiler/identity-roundtrip argument.
- pra_syntactic_base additionally gives N26: two-slot F, admission after bottom-up R_h(0,t)->t and (0=S0)->false must be B->B. Same emitted induction/RS schema, no separate axioms. Its complete admission program is not counted or proved smaller than G. Its logical equivalence is valid by extracting each rewrite equation through a constant probe, then structural normalization in the converse.
- pra_diagonal_reflexive and pra_diagonal_seed: D35, literal B->B admission plus separate Sep. diagonal_reflexive has W32 with current R_h(0,a)->a normalization plus separate Sep. These are dominated in display by G29/N26 but have simpler admission rules.
- pra_diagonal_initialization: transparent diagonal41 with Sep included inside schema, one-occurrence restriction produces smaller expanded matrices; syntactic version outer26 with longer expanded axioms. It does not beat N26 uniformly or establish globally smaller full specification.
- pra_substituted_tautology: D35 with restricted matrix shape: classically implications between equations suffice; intuitionistically each side may be one equation or a disjunction of two equations. Equation-only intuitionistic variant needs concrete coverage; written Harrop obstruction separates it. This is a grammar improvement, not display dominance over G/N.
- PRA_0bf6525_Diagonal_Seed: prior delivered41vsfixed42, T0 partial result; superseded as display baseline.
- pra_two_variable_and_graph: arithmetic38; separate graph-source seed337, per arithmetic axiom overhead72. Not comparable to arithmetic schema subtotal; graph improvement credits prior construction.

## Proof scope

Some drafts report compiled Lean semantic kernels for central logical equivalence, not full first-order syntactic compiler or arithmetic biinterpretation. I inspected TeX source, not reran their Lean or Python. All metric comparisons remain partial schema-display counts excluding formula/update bodies, admission program and language descriptor formation. The strongest fair frontier is G29 with direct literal admission versus N26 with explicit two-rule normalization; do not compare a new result merely to old41/42 or count admission as free.
