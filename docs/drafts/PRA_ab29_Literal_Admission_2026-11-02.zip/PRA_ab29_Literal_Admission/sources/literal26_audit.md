# Independent audit: three literal admission cases, display26

For each earlier two-input update term h and quantifier-free F(n,a), admit the displayed instance precisely when capture-free F(0,a) is literally one of:
1. B -> B, for arbitrary quantifier-free B with at most a free;
2. R_h(0,a)=a;
3. (0=S0)->bottom.
Emit
 forall a ((forall n (F(n,a)->F(Sn,a))) -> forall n (F(n,a) and R_h(Sn,a)=h(n,R_h(n,a)))).
No arithmetic rewriting or theoremhood test enters admission.

Constructive forward direction to R0, RS, Sep, I1:
- Constant F=R_h(0,a)=a is admitted. Its progress is P->P, so the schema supplies R0 by conjunction elimination.
- Constant F=(0=S0)->bottom similarly supplies Sep.
- Constant F=bottom->bottom supplies RS for every n,a.
- For arbitrary G(n,a), use F=G(0,a)->G(n,a). Its tested base is literally reflexive. Given ordinary base and step for G, derive progress for F, apply the schema, then use the base and conjunction elimination to obtain forall n G(n,a).
All arguments use intuitionistic logic only.

Conversely the explicit basis R0, RS, Sep, I1 proves each admitted axiom: each of the three literal forms is an available base theorem; apply I1 to F using the assumed progress; conjoin the available RS equation and close n,a. The recovery of ordinary PRA and the identity-round-trip compiler from that basis are inherited without modification.

Admission comparison with the old two-rule normalized26 family is INCOMPARABLE, not inclusion:
- F=R_h(0,a)=a belongs to the literal family, but its old normal form is a=a, not B->B.
- F=(R_h(0,a)=a)->(a=a) belongs to the normalized family, but its tested zero is none of the three literal forms.
These witness differences of admitted syntax, not differences in the generated theories.

Partial AST comparison:
- Display26: matrix F(n,a)3, successor matrix4, progress9, conclusion15, outer2.
- B(a)->B(a) admission pattern5; R0 equation5; Sep formula6; total literal-pattern payload16.
- Display plus payload42; adding the zero substitution image1 gives43; optionally charging the two choice separators gives45.
Compare earlier ledgers consistently: direct guarded29 has pattern10 and simultaneous-substitution images5, yielding44; normalized26 has pattern5, rewrite sides9, zero image1, and two instruction tokens, yielding43. Hence no convention-independent overall length improvement. The defensible gain is removal of the arithmetic normalizer while retaining the lowest established one-parameter display count26.
