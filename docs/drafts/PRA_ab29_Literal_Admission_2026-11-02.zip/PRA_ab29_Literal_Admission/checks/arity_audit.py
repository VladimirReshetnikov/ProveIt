#!/usr/bin/env python3
"""Independent partial AST count. Not a proof checker."""
import json

def node(op,*args): return (op,args)
def size(t): return 1+sum(map(size,t[1]))
def v(name): return node(name)
n,a,b=map(v,['n','a','b'])
def app(f,*x): return node(f,*x)
def prop(params):
    F=lambda t:app('F',t,*params)
    out=app('implies',app('forall_n',app('implies',F(n),F(app('S',n)))),app('forall_n',F(n)))
    for p in reversed(params):out=app('forall_'+p[0],out)
    return out
L=app('R_h',app('S',n),a)
R=app('h',n,app('R_h',n,a))
r={'one_parameter_pure_propagation':size(prop([a])), 'two_parameter_pure_propagation':size(prop([a,b])), 'RS_rewrite_sides':size(L)+size(R)}
assert r=={'one_parameter_pure_propagation':15,'two_parameter_pure_propagation':19,'RS_rewrite_sides':9}
print(json.dumps(r,indent=2))
