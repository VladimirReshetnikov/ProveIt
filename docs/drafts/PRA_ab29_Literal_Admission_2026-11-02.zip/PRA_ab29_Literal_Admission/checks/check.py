#!/usr/bin/env python3
"""Finite syntax controls and source identity checks; NOT a proof kernel."""
import hashlib,json, pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
def T(f,*a):return (f,tuple(a))
def sz(t):return 1+sum(map(sz,t[1]))
x,a,b,u,v=map(lambda z:T('$'+z),('x','a','b','u','v'))
z=T('0'); bot=T('bot'); S=lambda t:T('S',t); R=lambda s,t:T('R',s,t)
E=lambda s,t:T('=',s,t); I=lambda s,t:T('imp',s,t); O=lambda s,t:T('or',s,t)
bad=E(z,S(z)); sep=I(bad,bot)
def subst(t,d):return d.get(t[0],T(t[0],*(subst(q,d) for q in t[1])))
def fv(t):return ({t[0]} if t[0].startswith('$') else set()).union(*(fv(c) for c in t[1]))
def sameimp(t):return t[0]=='imp' and t[1][0]==t[1][1]
def literal(f):
 if not fv(f)<={'$x','$a'}:return False
 q=subst(f,{'$x':z})
 return sameimp(q) or q==E(R(z,a),a) or q==sep
# Only R is the current symbol; H is an uninterpreted earlier binary symbol.
# The tested update is h(u,v)=H(u,v), so nested R appears solely in arguments.
def norm(t,compute=False):
 q=T(t[0],*(norm(c,compute) for c in t[1]))
 if q[0]=='R':
  s,w=q[1]
  if s==z:return w
  if compute and s[0]=='S':return norm(T('H',s[1][0],R(s[1][0],w)),True)
 if q==bad:return bot
 return q
def normalized(f,params,compute=False):
 if not fv(f)<={'$x',*params}:return False
 return sameimp(norm(subst(f,{'$x':z}),compute))
init=E(R(z,a),a)
oldonly=I(init,E(a,a))
assert literal(init) and not normalized(init,{'$a'})
assert not literal(oldonly) and normalized(oldonly,{'$a'})
assert literal(sep) and literal(I(bot,bot))
L=R(S(a),b); V=T('H',a,R(a,b)); probe=I(E(L,L),E(L,V))
assert normalized(probe,{'$a','$b'},True)
assert not normalized(probe,{'$a'},True) # hidden second parameter rejected
assert norm(L,True)==norm(V,True)
# Finite controls over symbolic and numeral terms. No termination theorem inferred.
terms=[z,a,b,S(z),S(a),R(z,a),R(S(z),a),R(S(S(a)),b),T('later',R(S(z),a))]
for s in terms:
 for t in terms:
  assert norm(R(S(s),t),True)==norm(T('H',s,R(s,t)),True)
  assert norm(R(z,t),True)==norm(t,True)
  assert norm(norm(R(s,t),True),True)==norm(R(s,t),True)
# Counts, with placeholders represented as applications of their declared arity.
B1=T('B',a);B2=T('B',a,b)
patterns={'G':sz(I(O(B1,bad),B1)),'N':sz(I(B1,B1)), 'H':sz(I(O(B1,bad),B1)), 'L':sz(I(B1,B1))+sz(init)+sz(sep), 'P':sz(I(B2,B2))}
rewrites={'G':0,'N':sz(R(z,a))+sz(a)+sz(bad)+sz(bot),'H':sz(R(z,a))+sz(a),'L':0,'P':sz(R(z,a))+sz(a)+sz(L)+sz(V)+sz(bad)+sz(bot)}
def schema(params, matrix_args, joint):
 fn=lambda t:T('F',t,*matrix_args)
 out=T('forall_n',T('and',fn(x),E(R(S(x),a),T('h',x,R(x,a))))) if joint else T('forall_n',fn(x))
 out=I(T('forall_n',I(fn(x),fn(S(x)))),out)
 for p in reversed(params):out=T('forall_'+p[0],out)
 return out
display={'G':sz(schema([a],[a,a],True)), 'N':sz(schema([a],[a],True)), 'H':sz(schema([a],[a],True)), 'L':sz(schema([a],[a],True)), 'P':sz(schema([a,b],[a,b],False))}
assert display=={'G':29,'N':26,'H':26,'L':26,'P':19}
changed_images={'G':sz(z)+sz(R(z,a)),'N':sz(z),'H':sz(z),'L':sz(z),'P':sz(z)}
instructions={'G':0,'N':2,'H':1,'L':0,'P':3}
ledger={k:dict(display=display[k],patterns=patterns[k],rewrite_sides=rewrites[k],subtotal=display[k]+patterns[k]+rewrites[k],changed_images=changed_images[k],rewrite_instructions=instructions[k]) for k in display}
assert [ledger[k]['subtotal'] for k in display]==[39,40,40,42,44]
for row in ledger.values():
 row['with_images']=row['subtotal']+row['changed_images']
 row['with_images_and_instructions']=row['with_images']+row['rewrite_instructions']
manifest=json.loads((ROOT/'sources/verified_manifest.json').read_text())
for entry in manifest:
 data=(ROOT/'sources'/entry['name']).read_bytes()
 assert len(data)==entry['bytes']
 assert hashlib.sha256(data).hexdigest()==entry['sha256']
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==entry['git_blob']
print(json.dumps({'status':'PASS','scope':'finite syntax controls, AST ledger, 8 source identities; not formal proof','ledger':ledger,'normalizer_pairs_checked':len(terms)**2},indent=2))
