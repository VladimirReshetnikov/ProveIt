# Why the apparent 15-node replacement is not established

Consider the one-parameter schema

    forall a ((forall n (F(n,a) -> F(Sn,a))) -> forall n F(n,a)),

admitted when normalizing F(0,a) by R0, Sep, and RS gives literally B -> B. Its partial display has 15 AST nodes. The RS normalizer costs 9 displayed term nodes, against 11 nodes removed from the original conclusion (the conjunction plus its 10-node equation).

The proposed extraction argument sets F to a constant-in-n implication `(L=L) -> L=R`, where L=R_h(Sm,a), R=h(m,R_h(m,a)). Its normalized base is reflexive and its progress premise is tautological. But this F has two frozen parameters m,a, not the single allowed parameter a. Calling the induction variable m does not repair the argument: F then depends on it and progress is no longer a logical theorem. A pairing code cannot be assumed at this stage because the available pairing construction itself uses the RS equations being extracted.

Allowing two frozen parameters repairs this particular inference, but changes the display from 15 to 19 nodes. Under schema+admission-pattern+rewrite-sides accounting, the apparent 38 becomes 44 (four extra schema nodes and two extra admission-pattern argument nodes), versus 39 for direct G and 40 for the established two-rule normalized N. This is an audit of the proposed proof, not a countermodel or an impossibility theorem for the one-parameter candidate. No bi-interpretability claim is made for that candidate.
