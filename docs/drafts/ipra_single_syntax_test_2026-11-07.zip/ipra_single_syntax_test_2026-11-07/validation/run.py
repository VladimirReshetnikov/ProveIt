#!/usr/bin/env python3
"""Offline finite validation of both complete iPRA acceptance programs.

Run with Python 3.10+ from any directory. The production checkers import none
of this file, the independent oracle, the historical source programs, or the
untrusted certificate compiler. Mathematical trace extraction is proved in
the report; this runner supplies reproducible finite implementation evidence.
"""
import ast
from copy import deepcopy
from hashlib import sha256
import itertools
import json
import math
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import types

from oracle import Oracle
from translate_primitive import Compiler, load, run as accepted

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SOURCE = HERE / 'source'
RESULTS = ROOT / 'results'
EXAMPLES = ROOT / 'examples'
PROGRAMS = {1: ROOT / 'checker.py', 2: ROOT / 'checker_full.py'}
EXACT_LIST = ROOT / 'checker_exact_list.py'
NAMES = {1: 'scalar', 2: 'full'}


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def save(path, value, compact=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, separators=(',', ':')) if compact else json.dumps(value, indent=2)
    path.write_text(text + '\n')


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def packet_digest(packet):
    return sha256(json.dumps(packet, separators=(',', ':')).encode()).hexdigest()


def trace(module, packet):
    module.k = 0
    stack = deepcopy(packet)
    consumed = []
    def take():
        value = stack.pop()
        consumed.append(deepcopy(value))
        return value
    try:
        module.take = take
        verdict = bool(module.check(stack.pop(), []))
    except Exception:
        verdict = False
    return {'accepted': verdict, 'final_k': module.k,
            'remaining': len(stack) if type(stack) is list else None,
            'consumed': consumed}


def agreement(module, packet, width, label):
    actual = trace(module, packet)
    expected = Oracle(width).run(packet)
    fields = ('accepted', 'final_k', 'remaining')
    require(all(actual[key] == expected[key] for key in fields),
            ('oracle disagreement', width, label,
             {key: actual[key] for key in fields}, expected))
    return actual


def unwrap_instruction(cell):
    if type(cell) is list and len(cell) == 1:
        witness = cell[0]
        if type(witness) is int or type(witness) is list and len(witness) in (1, 3):
            return witness
        return 0
    return cell


def canonical_translations(modules):
    legacy = json.loads((SOURCE / 'fixtures_wrapped_scalar.json').read_text())
    staged = json.loads((SOURCE / 'fixtures_staged.json').read_text())
    wrapped = load(SOURCE / 'source_scalar_wrapped.py')
    sources = {1: load(SOURCE / 'source_scalar.py'),
               2: load(SOURCE / 'source_direct.py')}
    prepared = []
    source_records = []
    for row in legacy:
        actual = trace(wrapped, row['packet'])
        require(actual['accepted'] == row['expected'], ('historical source', row['name']))
        source_records.append({'cohort': 'legacy_wrapped_scalar', 'name': row['name'],
                               'expected': row['expected']})
        if actual['accepted']:
            packet = [unwrap_instruction(c) for c in reversed(actual['consumed'])]
            packet.append(deepcopy(row['packet'][-1]))
            require(accepted(sources[1], packet), ('unwrap', row['name']))
            prepared.append((1, 'legacy_wrapped_scalar', row['name'], packet))
    for key, width in (('scalar', 1), ('full', 2), ('embedded', 2)):
        for row in staged[key]:
            actual = accepted(sources[width], row['packet'])
            require(actual == row['expected'], ('historical source', key, row['name']))
            source_records.append({'cohort': 'staged_' + key, 'name': row['name'],
                                   'expected': row['expected']})
            if actual:
                prepared.append((width, 'staged_' + key, row['name'], row['packet']))
    packets = {1: [], 2: []}
    records = []
    for index, (width, cohort, name, packet) in enumerate(prepared):
        compiler = Compiler(sources[width], width)
        translated = compiler.compile(packet)
        actual = agreement(modules[width], translated, width, (cohort, name))
        require(actual['accepted'], ('compiled positive rejected', cohort, name))
        if width == 1:
            alternative = agreement(modules['exact_list'], translated, width,
                                    ('exact-list alternative', cohort, name))
            require(alternative['accepted'], ('exact-list positive rejected', cohort, name))
        row = {'variant': NAMES[width], 'cohort': cohort, 'name': name,
               'compiled_packet_sha256': packet_digest(translated),
               'Q_introduction_expansions': compiler.expansions,
               'failed_major_fallthroughs': compiler.fallbacks,
               'reserved_name_wrappers': compiler.reserved_wrappers}
        packets[width].append({**row, 'packet': translated})
        records.append(row)
        if '--dump-translations' in sys.argv:
            save(RESULTS / 'translated' / NAMES[width] / f'{index:03d}.json', translated, True)
    receipt = {'status': 'PASS', 'source_expectations_checked': len(source_records),
               'source_positives': sum(r['expected'] for r in source_records),
               'translated_proofs': len(records),
               'by_variant': {NAMES[w]: len(packets[w]) for w in (1, 2)},
               'exact_list_alternative_positive_checks': len(packets[1]),
               'Q_introduction_expansions': sum(r['Q_introduction_expansions'] for r in records),
               'failed_major_fallthroughs': sum(r['failed_major_fallthroughs'] for r in records),
               'reserved_name_wrappers': sum(r['reserved_name_wrappers'] for r in records),
               'source_expectations': source_records, 'translations': records}
    save(RESULTS / 'translations.json', receipt)
    return packets, staged, receipt


def intro_attacks():
    true = [0, 0]
    bad = [[1, 0, [0]], 0]
    qbad = [bad]
    false_goal = [[[0], 0, [0]], 0]
    return {
        'unguarded_equation_introduction': [0, [[0], 0]],
        'wrong_elimination_matrix': [[], 0, [[bad, true, true], 0], [qbad, [0]], false_goal],
        'wrong_introduction_matrix': [[], 0, [[true, true, bad], 0], [qbad, [0]], false_goal],
    }


def non_atomic_induction_packet():
    body = [[[3, 0, 1], 0]]
    previous, current = [-1, 0, 1], [[-1], 0, 1]
    major, inverse = [current, previous], [previous, current]
    zero = [[0, current, 0], current]
    return [[], [], [zero, [3, current]], [], [major, [3, current]],
            [inverse, [[3, 0]]], 0, [body, body, body]]


def positive_fractional_coordinates(value):
    if type(value) is int and value > 0:
        return value + 0.5
    if type(value) is list:
        return [positive_fractional_coordinates(v) for v in value]
    return value


def publish_examples(packets, staged, modules):
    rows = []
    def add(name, packet, expected, widths=(1, 2), note='', extension=False):
        filename = name + '.json'
        save(EXAMPLES / filename, packet, len(json.dumps(packet)) > 2000)
        row = {'file': filename, 'checkers': [PROGRAMS[w].name for w in widths],
               'expected': expected, 'note': note}
        if 1 in widths:
            row['checkers'].append(EXACT_LIST.name)
        if extension:
            row['parser_extension'] = 'Python json NaN/Infinity tokens; these are not strict JSON numbers.'
        for width in widths:
            actual = agreement(modules[width], packet, width, name)
            require(actual['accepted'] == expected, ('example verdict', name, width))
        if 1 in widths:
            actual = agreement(modules['exact_list'], packet, 1, ('exact-list', name))
            require(actual['accepted'] == expected, ('exact-list example verdict', name))
        rows.append(row)
    add('zero_computation', [[], [[0, 0, 0], 0]], True)
    add('fractional_zero_alias', [[], [[0, 0.5, 0], 0.5]], True,
        note='The initializer and result floor to numerical zero.')
    add('boolean_zero_alias', [[], [[False, False, False], False]], True)
    add('fractional_truth_tree', [0, [[0.5], [0.5], [0.5]]], True,
        note='The meaningful formula matrix is truth-only.')
    add('false_root_zero_successor', [[], [0, [0]]], False,
        note='The canonical contradiction 0=S0 is rejected.')
    add('fractional_counter_rejected', [[], [[0.5, 0, 0], 0]], False,
        note='A nonzero fractional scalar is not a syntactic zero or successor counter.')
    add('future_fractional_parameter_rejected', [[], [[0, 0, -0.5], 0]], False,
        note='The future rigid name floor(-0.5)=-1 is not yet available.')
    add('future_parameter_in_padding', [0, [[0, 0], [-0.5, -0.5], [0, 0]]], False)
    add('string_term_rejected', [[], [[0, 'x', 0], 'x']], False)
    add('object_term_rejected', [[], [[0, {'coordinate': 0}, 0], {'coordinate': 0}]], False)
    add('null_term_rejected', [[], [[0, None, 0], None]], False)
    add('bare_truth_root_rejected', [0], False,
        note='Semantic truth does not require acceptance of every redundant spelling.')
    zero_equation = [[0, 0, 0], 0]
    for label, value in (('nan', float('nan')), ('infinity', float('inf')),
                         ('negative_infinity', -float('inf'))):
        add(label + '_template_hole', [[], [], [zero_equation, [value, 0]], [0, 0]],
            True, note='A nonfinite scalar acts only as an exposed template hole.', extension=True)
        add(label + '_used_term_rejected', [[], [[0, value, 0], value]],
            False, note='A nonfinite scalar cannot survive closed numerical validation.', extension=True)
    for name, packet in intro_attacks().items():
        add(name, packet, False)
    add('non_atomic_induction_rejected', non_atomic_induction_packet(), False,
        note='This certificate illegally uses a non-atomic induction hypothesis. The goal itself is provable by other certificates.')
    for width in (1, 2):
        source_attack = next(r['packet'] for r in staged[NAMES[width]]
                             if r['name'] == 'contextual_capture_attack')
        attack = deepcopy(source_attack)
        a, b, c = attack[-1]
        attack[-1] = [b, c, a]
        add('capture_' + NAMES[width] + '_rejected', attack, False, (width,))
    selected = ('atomic_induction_recursion_identity', 'nested_Q_introductions',
                'addition_two_three', 'transport_under_D_and_Q',
                'failed_major_retains_consumed_allocation')
    for width in (1, 2):
        names = selected + (('successor_uses_both_arguments',
                              'successor_under_two_nested_recursors') if width == 2 else ())
        for name in names:
            row = next(r for r in packets[width] if r['cohort'] == 'staged_' + NAMES[width]
                       and r['name'] == name)
            add(NAMES[width] + '_' + name, row['packet'], True, (width,),
                note='Inherited positive derivation, compiled through primitive paired rules; Q-introduction expansions: '
                     + str(row['Q_introduction_expansions']) + '.')
    row = next(r for r in packets[1] if r['cohort'] == 'staged_scalar'
               and r['name'] == 'atomic_induction_recursion_identity')
    add('rational_coordinates', positive_fractional_coordinates(row['packet']), True, (1,),
        note='Positive protected/hole coordinates n are represented by n+1/2 in an actual induction certificate.')
    for filename, expected in (('normalization_raw.json', True),
                               ('normalization_quotient.json', False)):
        packet = json.loads((EXAMPLES / filename).read_text())
        # The two static files are a deliberately fixed counterexample pair.
        add(filename[:-5], packet, expected, (1,),
            note='Whole-packet flooring can change instruction consumption; the soundness argument extracts a successful trace.')
    save(EXAMPLES / 'index.json', rows)
    save(RESULTS / 'examples.json', {'status': 'PASS', 'files': len(rows),
                                  'profile_cases': sum(len(r['checkers']) for r in rows),
                                  'records': rows})
    return rows


def mutate(value, replacement, rng):
    if type(value) is list and value and rng.random() < 0.8:
        value = deepcopy(value)
        index = rng.randrange(len(value))
        value[index] = mutate(value[index], replacement, rng)
        return value
    return deepcopy(replacement)


def mutation_audit(modules, packets, examples, count=6000):
    atoms = [False, True, -4, -1, 0, 1, 2, 3, -3.5, -1.5, -0.5,
             0.0, 0.5, 1.5, 2.5, 3.5, float('nan'), float('inf'),
             -float('inf'), None, '', 'x', 'xyz', {}, {'a': 0}, [], [0], [0, 0]]
    records = []
    for width in (1, 2):
        pool = [r['packet'] for r in packets[width] if len(json.dumps(r['packet'])) < 5000]
        pool += [json.loads((EXAMPLES / r['file']).read_text()) for r in examples
                 if PROGRAMS[width].name in r['checkers'] and (EXAMPLES / r['file']).stat().st_size < 5000]
        rng = random.Random(218490 + width)
        accepted_count = 0
        for index in range(count):
            packet = deepcopy(rng.choice(pool))
            for _ in range(1 + rng.randrange(3)):
                packet = mutate(packet, rng.choice(atoms), rng)
            actual = agreement(modules[width], packet, width, ('mutation', index))
            accepted_count += actual['accepted']
        records.append({'variant': NAMES[width], 'seed': 218490 + width,
                        'packets': count, 'accepted': accepted_count, 'mismatches': 0})
    result = {'status': 'PASS', 'variants': records,
              'scope': 'Exact finite trace agreement, including failed-major consumption and freshness allocation.'}
    save(RESULTS / 'mutations.json', result)
    return records


def quotient(value):
    if isinstance(value, float):
        return math.floor(value)
    if type(value) is bool:
        return int(value)
    if type(value) is list:
        return [quotient(x) for x in value]
    return value


def production_open(module, value, image, depth, lower):
    module.k = lower
    try:
        return True, module.inst(deepcopy(value), deepcopy(image), depth)
    except Exception:
        return False, None


def oracle_open(width, value, image, depth, lower):
    oracle = Oracle(width)
    oracle.lower = lower
    method = oracle.term if depth % 2 else oracle.formula
    try:
        return True, method(deepcopy(value), deepcopy(image), depth // 2)
    except Exception:
        return False, None


def opening_audit(modules, count=5000):
    atoms = [-99, -2, -1, 0, 1, 2, 3, 4, 5, 999, -1.5, -0.5, 0.5, 1.5,
             None, True, False, float('nan'), float('inf'), -float('inf'), 'x', {}]
    values = atoms + [[], [0], [1], [999], [0, 0], [0, 0, 1], [0, 0, 3],
                     [[0], 0], [[0, 0]], [0, [1], [2]], [[1, 0], [3, 4], [5, 6]],
                     [[0, 0, 999], 0]]
    images = [None, 0, -1, -99, 1, 0.5, -0.5, [0], [0, 0, 1], [], True, {}]
    finite = [-4, -1, 0, 1, 2, 3, False, True, -3.5, -1.5, -0.5,
              0.0, 0.5, 1.5, 2.5, 3.5]
    records = []
    for width in (1, 2):
        total = successful = 0
        for value, image, depth, lower in itertools.product(values, images, range(8), (0, -2)):
            actual = production_open(modules[width], value, image, depth, lower)
            expected = oracle_open(width, value, image, depth, lower)
            require(actual[0] == expected[0] and (not actual[0] or actual[1] == expected[1]),
                    ('opening agreement', width, value, image, depth, lower))
            total += 1
            successful += actual[0]
        rng = random.Random(218500 + width)
        def tree(depth):
            if not depth or rng.random() < 0.4:
                return rng.choice(finite)
            return [tree(depth - 1) for _ in range(rng.choice((1, 2, 3)))]
        quotient_successes = 0
        for index in range(count):
            value, image, depth, lower = tree(3), tree(2), rng.randrange(8), -rng.randrange(5)
            actual = production_open(modules[width], value, image, depth, lower)
            expected = oracle_open(width, quotient(value), quotient(image), depth, lower)
            require(actual[0] == expected[0], ('quotient validity', width, index))
            if actual[0]:
                require(quotient(actual[1]) == expected[1], ('quotient opening', width, index))
                quotient_successes += 1
        records.append({'variant': NAMES[width], 'explicit_opening_cases': total,
                        'explicit_successes': successful, 'quotient_cases': count,
                        'quotient_successes': quotient_successes,
                        'quotient_seed': 218500 + width})
    save(RESULTS / 'openings.json', {'status': 'PASS', 'variants': records,
         'scope': 'Single-opening commutation only. No whole-packet normalization equivalence is asserted.'})
    return records


def module_from_text(source, label):
    tree = ast.parse(source)
    body = []
    for node in tree.body:
        if isinstance(node, ast.Try):
            break
        body.append(node)
    module = types.ModuleType(label)
    exec(compile(ast.Module(body=body, type_ignores=[]), label, 'exec'), module.__dict__)
    return module


def mutation_controls(packets, staged):
    attacks = intro_attacks()
    records = []
    for width in (1, 2):
        source = PROGRAMS[width].read_text()
        def control(name, before, after, packet, correct=False, mutant=True, kind='invalid certificate accepted'):
            require(source.count(before) == 1, ('mutation site', name, width))
            modified = module_from_text(source.replace(before, after), name)
            good = accepted(load(PROGRAMS[width]), packet)
            bad = accepted(modified, packet)
            require((good, bad) == (correct, mutant), ('mutation control', name, width, good, bad))
            records.append({'variant': NAMES[width], 'name': name, 'correct_accepts': good,
                            'mutant_accepts': bad, 'purpose': kind,
                            'source_replacement': {'before': before, 'after': after},
                            'packet': packet})
        control('first_child_introduction', 'a = inst(a[2], t, 2)', 'a = inst(a[0], t, 2)',
                attacks['unguarded_equation_introduction'], kind='false equation S0=0 accepted')
        control('wrong_paired_elimination_matrix', 'h = [m[2:]]', 'h = [m[:1]]',
                attacks['wrong_elimination_matrix'], kind='false computation equation accepted')
        control('non_atomic_induction_hypothesis', 'h = [a, inst(a, 0)][len(a) % 2:]',
                'h = [a, inst(a, 0)]', non_atomic_induction_packet(),
                kind='a non-atomic induction hypothesis is illegally usable; no unprovability claim about this goal')
        control('freshness_floor_removed', 'k <= a < d', 'a < d',
                [[], [[0, 0, -0.5], 0]], kind='undeclared fractional rigid parameter accepted')
        control('initial_validation_removed', 'if inst(a) in g:', 'if a in g:',
                [[], [[0, 0, -0.5], 0]], kind='undeclared fractional rigid parameter accepted')
        control('default_zero_image', 'def inst(a, t=None, d=0):', 'def inst(a, t=0, d=0):',
                [[], [[0, 0, 999], 0]], kind='out-of-scope coordinate silently supplied with zero')
        control('unchecked_computation_result', 'return b == t', 'return True',
                [[], [[0, 0, 0], [0]]], kind='false computation equation accepted')
        major = [[0, 0, 0], 0]
        control('unchecked_transport_endpoint', 'inst(t, m[1]) == a and ', '',
                [[], [], [major, [1, 0]], [0, [0]]], kind='the contradiction 0=S0 accepted')
        control('non_successor_counter', 'n, = n', 'n = n[0]',
                [[], [[[0, 0, 0], 0, 0], 0]], kind='a non-successor counter is accepted by the computation rule')
        capture = deepcopy(next(r['packet'] for r in staged[NAMES[width]]
                                if r['name'] == 'contextual_capture_attack'))
        a, b, c = capture[-1]
        capture[-1] = [b, c, a]
        control('image_capture', 'inst(t, d=1)', 'inst(t, d=d)', capture,
                kind='an exposed witness is captured under local binders')
        retained = next(r['packet'] for r in packets[width]
                        if r['cohort'] == 'staged_' + NAMES[width]
                        and r['name'] == 'retained_false_base_is_used')
        control('atomic_base_deleted', 'h = [a, inst(a, 0)][len(a) % 2:]',
                'h = [a] if len(a) == 2 else [inst(a, 0)]', retained, True, False,
                kind='a valid proof using the retained false base is lost')
        if width == 2:
            packet = next(r['packet'] for r in staged['full'] if r['name'] == 'counter_and_state_swapped')
            control('counter_state_exchanged', 't = inst(inst(r, n, 3), [n, t, r], 1)',
                    't = inst(inst(r, [n, t, r], 3), n, 1)', packet,
                    kind='the full-recursion computation substitutes the counter and state incorrectly')
    save(RESULTS / 'mutation_controls.json', {'status': 'PASS', 'controls': len(records),
                                            'records': records})
    return records


def falsity_audit(modules, packets, count=1500):
    goals = [[0, [0]], [[0], 0], [[0, 0, 0], [0]], [0.5, [0]]]
    replacements = [0, 0.5, -0.5, 1.5, None, [], [0], [0, 0], [0, 0, 0]]
    records = []
    for width in (1, 2):
        rng = random.Random(218600 + width)
        pool = [r['packet'] for r in packets[width] if len(json.dumps(r['packet'])) < 5000]
        for index in range(count):
            packet = deepcopy(rng.choice(pool))
            if len(packet) > 1:
                position = rng.randrange(len(packet) - 1)
                packet[position] = mutate(packet[position], rng.choice(replacements), rng)
            packet[-1] = deepcopy(goals[index % len(goals)])
            actual = agreement(modules[width], packet, width, ('false goal', index))
            require(not actual['accepted'], ('false conclusion', width, index))
        systematic = 0
        for goal, instruction, prefix in itertools.product(goals, replacements,
                                                           ([], [[]], [0], [[], []])):
            packet = deepcopy(prefix + [instruction, goal])
            require(not accepted(modules[width], packet), ('systematic false goal', width, packet))
            systematic += 1
        records.append({'variant': NAMES[width], 'seed': 218600 + width,
                        'targeted_packets': count, 'systematic_packets': systematic,
                        'false_conclusions_found': 0})
    save(RESULTS / 'falsity.json', {'status': 'PASS', 'variants': records,
         'scope': 'Finite probes of false standard-natural-number conclusions, not a proof of soundness.'})
    return records


def public_cli(examples):
    records = []
    for row in examples:
        for program in row['checkers']:
            for flags in ([], ['-O']):
                proc = subprocess.run([sys.executable, *flags, str(ROOT / program),
                                       str(EXAMPLES / row['file'])],
                                      text=True, capture_output=True, timeout=20)
                wanted = (0, 'ACCEPT', '') if row['expected'] else (1, 'REJECT', '')
                actual = (proc.returncode, proc.stdout.strip(), proc.stderr)
                require(actual == wanted, ('public CLI', program, row['file'], flags, actual, wanted))
                records.append({'checker': program, 'file': row['file'], 'optimized': bool(flags),
                                'expected': row['expected'], 'status': 'PASS'})
    failures = []
    with tempfile.TemporaryDirectory() as directory:
        directory = Path(directory)
        malformed = {'malformed_json': '[0', 'trailing_json': '[] []',
                     'root_object': '{"goal":[0,0]}', 'root_null': 'null'}
        for name, contents in malformed.items():
            (directory / (name + '.json')).write_text(contents)
        for variant, program in (('scalar', PROGRAMS[1]), ('full', PROGRAMS[2]),
                                 ('scalar_exact_list', EXACT_LIST)):
            for flags in ([], ['-O']):
                cases = [('missing_argument', []), ('missing_file', [str(directory / 'absent.json')])]
                cases += [(name, [str(directory / (name + '.json'))]) for name in malformed]
                for name, arguments in cases:
                    proc = subprocess.run([sys.executable, *flags, str(program), *arguments],
                                          text=True, capture_output=True, timeout=20)
                    require((proc.returncode, proc.stdout.strip(), proc.stderr) == (1, 'REJECT', ''),
                            ('malformed public input', variant, flags, name, proc.stdout, proc.stderr))
                    failures.append({'variant': variant, 'optimized': bool(flags),
                                     'case': name, 'status': 'PASS'})
    save(RESULTS / 'public_cli.json', {'status': 'PASS', 'example_runs': len(records),
                                     'malformed_input_runs': len(failures),
                                     'records': records, 'malformed_inputs': failures})
    return len(records), len(failures)


def verify_frozen_sources():
    manifest = json.loads((HERE / 'source_manifest.json').read_text())
    for row in manifest['files'] + [manifest['adapted_oracle']]:
        require(digest(ROOT / row['local_file']) == row['local_sha256'],
                ('frozen validation source changed', row['local_file']))


def main():
    verify_frozen_sources()
    modules = {width: load(path) for width, path in PROGRAMS.items()}
    modules['exact_list'] = load(EXACT_LIST)
    packets, staged, translations = canonical_translations(modules)
    examples = publish_examples(packets, staged, modules)
    mutation_records = mutation_audit(modules, packets, examples)
    opening_records = opening_audit(modules)
    controls = mutation_controls(packets, staged)
    falsity = falsity_audit(modules, packets)
    example_cli, malformed_cli = public_cli(examples)
    result = {'status': 'PASS', 'python': platform.python_version(),
              'checker_files': {NAMES[w]: {'file': PROGRAMS[w].name, 'sha256': digest(PROGRAMS[w])}
                                for w in (1, 2)},
              'exact_list_alternative': {'file': EXACT_LIST.name, 'sha256': digest(EXACT_LIST),
                                        'canonical_positive_checks': translations['exact_list_alternative_positive_checks'],
                                        'random_audit': 'Not duplicated: the type predicates agree on every reachable JSON/default/internal list value.'},
              'source_expectations_checked': translations['source_expectations_checked'],
              'translated_positive_proofs': translations['translated_proofs'],
              'translated_by_variant': translations['by_variant'],
              'Q_introduction_expansions': translations['Q_introduction_expansions'],
              'failed_major_fallthroughs': translations['failed_major_fallthroughs'],
              'reserved_name_wrappers': translations['reserved_name_wrappers'],
              'example_files': len(examples),
              'example_profile_cases': sum(len(r['checkers']) for r in examples),
              'packet_mutations': mutation_records, 'opening_checks': opening_records,
              'mutation_controls': len(controls), 'falsity_checks': falsity,
              'public_example_cli_runs': example_cli,
              'public_malformed_cli_runs': malformed_cli,
              'scope': 'Offline finite implementation evidence. No mechanized metatheory, global minimum, or whole-packet flooring equivalence is claimed.'}
    save(RESULTS / 'validation.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
