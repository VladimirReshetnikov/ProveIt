OFFLINE VALIDATION OF THE COMPLETE ACCEPTANCE PROGRAMS
====================================================

Reproduce from any working directory with Python 3.10 or later:

    python3 validation/verify.py

When invoking from another directory, supply the path to this package's
validation/verify.py. The equivalent entry point is validation/run.py.
Only Python's standard library is used. No network access is needed.

For individually inspectable copies of every compiled historical proof:

    python3 validation/verify.py --dump-translations

That optional switch writes the 202 generated packets under
results/translated/{scalar,full}/. The normal run keeps the same packets
in memory and records their compact-serialization SHA-256 hashes in
results/translations.json. The package includes 39 selected example files
and an explicit expected-verdict index at examples/index.json.

PROGRAMS AND THE TRUSTED BOUNDARY
-------------------------------

checker.py is the primary scalar-iteration checker.
checker_full.py is the full-primitive-recursion companion.
checker_exact_list.py is the supported scalar alternative whose only
executable difference from checker.py is type(a) is list in place of
isinstance(a, list). All values reachable from the public JSON parser,
default arguments, and internal list construction have ordinary built-in
types, so these two predicates agree throughout their executions.

Each program is standalone. It imports no project-specific validation,
compiler, fixture producer, or semantic oracle. The public interface is:

    python3 checker.py examples/rational_coordinates.json

An accepted packet prints ACCEPT and exits with status 0. Rejection prints
REJECT and exits with status 1. The driver works with Python -O; acceptance
does not rely on Python assertions. Malformed JSON and missing arguments
or input files are caught by the same public rejection boundary.

INHERITED SOURCES AND CANONICAL COMPILATION
-----------------------------------------

source_manifest.json pins the source ZIP and original member hashes to
ProveIt commit ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a. The frozen inputs
come from docs/drafts/ipra_truth_completion_2026-11-07.zip, whose Git blob
is fc394b68c40902b60e04b18512c607a7f18e5698. See ../LICENSE_INHERITED.txt.
Two fixture files were compactly reserialized without changing their JSON
values; both original and delivered hashes are recorded. All other frozen
source programs and the compiler are unchanged. The adapted oracle's
original hash, delivered hash, and modifications are recorded separately.

The runner first checks all 342 historical source expectations against
their matching frozen source programs. It does not reuse a source-negative
verdict as an expectation for the new, more permissive representation.
Wrapped witnesses in the historical scalar source are unwrapped from its
successful trace and checked again before compilation.

The untrusted translate_primitive.py compiler expands direct closure
introduction through paired introduction, paired elimination, and hypothesis
use. It moves the meaningful paired matrix from the old first position to
the third position and freshens rigid parameters. Allocations consumed by
failed source major premises are replayed using harmless paired wrappers.
No part of this compiler lies in the acceptance boundary.

The 202 compiled positive proofs comprise 147 scalar and 55 full-recursion
proofs. They contain 33 direct-closure-introduction expansions, 4 successful
failed-major fallthrough translations, and 2 reserved-name wrappers. The
scalar alternative also checks all 147 scalar positive proofs.

INDEPENDENT ORACLE AND NUMERIC COMPLETION
----------------------------------------

oracle.py uses explicit numerical and formula grammars, separate protected
binder counts, and direct logical rule dispatch. It does not use the
production packed depth table, production opening function, or Python
match statement. Its raw scalar labels are retained when comparing execution
traces, while the mathematical interpretation sends finite scalar numerical
leaves to their floors and scalar formula leaves to truth.

Booleans are permitted numerical aliases: False is zero and True is bound
coordinate one, not the numeral one (whose representation is [0]). Finite
fractional scalars are admitted when they lie in the appropriate scope
interval. examples/rational_coordinates.json uses n+1/2 in place of positive
coordinates in an actual equation-induction proof.

Python's json parser also accepts NaN and Infinity tokens. The corresponding
six examples are explicitly marked as parser extensions in examples/index.json;
they are not strict JSON numbers. Such scalars can be exposed template-hole
spellings but cannot survive closed numerical validation. Strings, objects,
and null are rejected promptly when reached as syntax. Unused annotations
remain inert, as in the inherited certificate convention.

Single opening commutes with the floor interpretation on finite scalars.
This does NOT imply that flooring an entire proof packet preserves its
execution or acceptance: collapsing distinct raw expressions can change
hypothesis shortcuts, failed-major fallthrough, and instruction consumption.
examples/normalization_raw.json is accepted and its whole-packet floor image
examples/normalization_quotient.json is rejected. The soundness theorem in
the report extracts a native proof from the successful trace instead.

EXECUTED FINITE EVIDENCE
-----------------------

The saved run used Python 3.12.14 and passed:

- 342 matching historical source expectations.
- 202 compiled positive proofs: 147 scalar and 55 full recursion.
- 147 additional scalar positive checks using the exact-list alternative.
- 39 example files, giving 92 checker/example profile cases.
- 12,000 seeded mutated-packet comparisons with the independent oracle,
  checking verdict, final fresh-name floor, and remaining packet cells.
- 13,056 explicit opening/validation comparisons with the independent oracle.
- 10,000 finite-scalar quotient/opening comparisons.
- 23 deliberate source-mutation controls.
- 3,288 targeted and systematic probes with false numerical conclusions.
- 184 actual example command-line runs, both normally and with Python -O.
- 36 additional command-line runs rejecting missing arguments/files,
  malformed JSON, trailing JSON, a root object, and root null.

The random audits are not duplicated for the exact-list alternative: its
predicate is extensionally identical on every reachable value. It receives
all canonical scalar proof checks and every applicable fixed/public test.

Mutation controls expose wrong paired-matrix selection, introduction on an
equation, a non-atomic induction hypothesis, missing freshness or initial
validation, a default zero image, unchecked computation and transport,
capture under local binders, non-successor counter forms, deletion of a
retained base, and exchanged counter/state arguments in full recursion.
Some controls detect invalid certificates for provable goals rather than
false theorems; each control's purpose is explicitly labeled in its receipt.
No claim that an arbitrary non-atomic-induction goal is unprovable in iPRA
is inferred from rejection of one certificate.

A separate mutation that merely deletes the old list guard was not promoted:
although finite accepted traces can be analyzed, malformed strings can then
recurse until a host resource limit. The delivered list-first implementation
rejects those scalar objects immediately and retains ordinary idealized
termination on finite parsed inputs.

RECEIPTS AND LIMITATIONS
-----------------------

results/validation.json is the compact aggregate receipt with exact checker
hashes. Detailed records are in translations.json, examples.json,
mutations.json, openings.json, mutation_controls.json, falsity.json, and
public_cli.json in the same results directory. Each generated random cohort
records its fixed seed. All frozen validation sources are hash-checked before
the run begins.

These are finite, reproducible implementation checks. They do not mechanize
soundness, completeness, bi-interpretability, or equiconsistency, and they do
not prove an absolute minimum over theories or encodings. Those mathematical
claims and their precise scope are given in the accompanying report.
