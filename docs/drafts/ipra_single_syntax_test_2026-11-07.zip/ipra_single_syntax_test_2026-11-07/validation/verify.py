#!/usr/bin/env python3
"""Run the self-contained offline validation suite from any directory."""
from run import main

if __name__ == '__main__':
    main()
