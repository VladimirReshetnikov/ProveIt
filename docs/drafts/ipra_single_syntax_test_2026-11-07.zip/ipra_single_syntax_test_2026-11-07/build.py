"""Build the complete paper with local pdfLaTeX; no network or shell escape."""
from pathlib import Path
import json
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def validation_table():
    data = json.loads((ROOT / 'results' / 'validation.json').read_text())
    rows = [
        ('Frozen source expectations checked', data['source_expectations_checked']),
        ('Translated positive proofs (scalar / full)',
         str(data['translated_by_variant']['scalar']) + ' / '
         + str(data['translated_by_variant']['full'])),
        ('Seeded mutated-packet comparisons', sum(x['packets'] for x in data['packet_mutations'])),
        ('Explicit sorted-opening comparisons', sum(x['explicit_opening_cases'] for x in data['opening_checks'])),
        ('Finite-scalar quotient comparisons', sum(x['quotient_cases'] for x in data['opening_checks'])),
        ('Deliberately altered checker controls', data['mutation_controls']),
        ('Targeted and systematic falsity probes',
         sum(x['targeted_packets'] + x['systematic_packets'] for x in data['falsity_checks'])),
        ('Public example CLI runs, including optimized Python', data['public_example_cli_runs']),
        ('Malformed-input CLI runs', data['public_malformed_cli_runs']),
    ]
    text = '\\begin{center}\n\\begin{tabular}{@{}lr@{}}\n\\toprule\n'
    text += 'Recorded finite check & Count\\\\\n\\midrule\n'
    for label, value in rows:
        text += label + ' & ' + str(value) + '\\\\\n'
    text += '\\bottomrule\n\\end{tabular}\n\\end{center}\n'
    (ROOT / 'results' / 'validation_table.tex').write_text(text)


def main():
    subprocess.run([sys.executable, str(ROOT / 'comparison' / 'measure.py')],
                   cwd=ROOT, check=True)
    validation_table()
    latex = shutil.which('pdflatex')
    if not latex:
        raise SystemExit('Install pdfLaTeX and the packages listed in report.tex.')
    build = ROOT / 'build'
    build.mkdir(exist_ok=True)
    for number in range(1, 4):
        completed = subprocess.run(
            [latex, '-no-shell-escape', '-interaction=nonstopmode',
             '-halt-on-error', '-output-directory=build', 'report.tex'],
            cwd=ROOT, capture_output=True, text=True)
        (build / f'pass_{number}.txt').write_text(completed.stdout + completed.stderr)
        if completed.returncode:
            print(completed.stdout[-12000:])
            raise SystemExit(completed.returncode)
    log = (build / 'report.log').read_text(errors='replace')
    errors = [line for line in log.splitlines()
              if line.startswith('!') or 'Overfull \\' in line
              or 'There were undefined references' in line
              or ('Warning:' in line and 'undefined' in line)
              or 'multiply defined' in line]
    if errors:
        raise SystemExit('PDF layout/reference checks failed:\n' + '\n'.join(errors))
    shutil.copyfile(build / 'report.pdf', ROOT / 'report.pdf')
    pages = re.search(r'Output written on .*?\((\d+) pages', log, re.S)
    receipt = {'compiler': subprocess.run([latex, '--version'], capture_output=True,
                                         text=True).stdout.splitlines()[0],
               'passes': 3, 'shell_escape': False,
               'pages': int(pages.group(1)) if pages else None,
               'overfull_boxes': 0, 'undefined_references': 0,
               'pdf': 'report.pdf'}
    (ROOT / 'results' / 'build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
