"""Reproduce the comparison and finite validation, optionally rebuilding the PDF."""
from pathlib import Path
import argparse
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pdf', action='store_true', help='also rebuild report.pdf')
    args = parser.parse_args()
    for relative in ('comparison/measure.py', 'validation/verify.py'):
        subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT, check=True)
    if args.pdf:
        subprocess.run([sys.executable, str(ROOT / 'build.py')], cwd=ROOT, check=True)
    print('Reproduction completed successfully.')


if __name__ == '__main__':
    main()
