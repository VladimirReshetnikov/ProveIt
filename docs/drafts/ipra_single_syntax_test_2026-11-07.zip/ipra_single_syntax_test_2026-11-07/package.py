"""Create a self-contained ZIP and a SHA-256 manifest for this exact release."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_DIRECTORIES = {'build', '__pycache__', 'rendered'}


def files():
    return [p for p in sorted(ROOT.rglob('*'))
            if p.is_file()
            and not (set(p.relative_to(ROOT).parts) & EXCLUDED_DIRECTORIES)
            and p.suffix not in {'.pyc', '.zip'}
            and p.name != 'SHA256SUMS']


def main():
    required = ['report.tex', 'report.pdf', 'checker.py', 'checker_full.py',
                'checker_exact_list.py',
                'README.txt', 'FORMAT.txt', 'results/measurements.json',
                'results/validation.json']
    for name in required:
        if not (ROOT / name).is_file():
            raise SystemExit('Missing required deliverable: ' + name)
    entries = files()
    manifest = '\n'.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  '
                         + p.relative_to(ROOT).as_posix() for p in entries) + '\n'
    (ROOT / 'SHA256SUMS').write_text(manifest)
    archive = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as z:
        for p in entries + [ROOT / 'SHA256SUMS']:
            z.write(p, (Path(ROOT.name) / p.relative_to(ROOT)).as_posix())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise SystemExit('Archive integrity failure.')
    print(archive)
    print('bytes:', archive.stat().st_size)
    print('sha256:', hashlib.sha256(archive.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
