REPRODUCIBLE COMPARISON
=======================

Run from the extracted package root:

  python3 comparison/measure.py

The program uses only the Python standard library. It parses source as data;
it does not execute any measured checker. It verifies every frozen source
SHA-256 before reporting measurements. Exact recorded results use CPython
3.12.14; AST and normalization details can change with the Python version.

CURRENT BOUNDARY

The snapshot is ProveIt commit
  ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a
and its six current docs/drafts ZIP files. repository_manifest.json retains
their original names, paths, sizes and Git blob SHA-1 identities. The ZIP
bytes were checked against those identities before extracting sources.
manifest.json lists the exact source identities used in this comparison.

current/ contains all nine root checker*.py sources. They represent seven
distinct byte strings: the primary checkers from integrated, locality, and
opening_and_witnesses are identical. The whole-source normalized minima are
367 tokens, 392 AST nodes and 1076 UTF-8 bytes, all attained by the direct
scalar checker. Earlier reports inside these archives quote the older
375/403/1117 frontier, which is not the current comparison target.

The primary scalar checker.py measures 362/384/1068. The supported scalar
alternative checker_exact_list.py measures 362/386/1064. Each complete
program is strictly below every current coordinate minimum. These are two
actual Pareto options: the primary has two fewer AST nodes; the exact-list
alternative has four fewer bytes. No synthetic program combining their best
coordinates is claimed. The full-recursion companion measures 369/390/1080;
it improves on the current full-recursion subgroup (374/396/1088), but is
not below the overall scalar frontier in all three coordinates.

NORMALIZATION AND TRUST BOUNDARY

Genuine docstrings are removed, the entire remaining module is normalized
by ast.unparse, and significant tokens, all ast.walk nodes, and normalized
UTF-8 bytes are counted. Imports, JSON input, every validation and inference
operation, exception handling, verdict output and exit status are included.
No project-specific helper is imported by a primary checker. AST context
nodes such as Load and Store ARE counted. An additional non-context count
is provided as a separate statistic and never substituted for this metric.

Raw bytes and source tokens are also recorded. Comments and documentation
make raw bytes a poor standalone complexity measure; the headline comparison
uses the three normalized measures. No encoding-independent or global lower
bound is claimed by a finite-corpus measurement.

COMMON DRIVER

Every root source is additionally measured after replacing only its public
input/output driver with the same explicit Boolean-result driver. All
imports, global initialization and checking definitions remain present.
The exact common driver is stored in results/measurements.json.

                        Tokens  AST nodes  Normalized bytes
Current common minimum     369        395              1105
Primary scalar checker     366        389              1105
Exact-list alternative     366        391              1101

The primary survives as a strict token/node improvement and a byte tie.
The supported exact-list alternative is strictly below the current minima
in all three common-driver coordinates. The two rows remain separate actual
programs. The common-driver full-recursion companion is 373/395/1117.

OPTIONAL COMPARATORS AND CONTROLS

optional/ contains four directly supplied nonroot alternatives. The locality
native checker is an optional supported reference with another packet
format. The reduction and truth-completion prototypes are explicitly marked
experimental in their source packages. They are measured, not promoted as
newly certified production programs; none lowers the observed frontier.

controls/checker_truth_synthesis.py is the preceding synthesis with explicit
integer/Boolean validation and the compact verdict driver. Its 365/388/1072
count isolates the further list-first partition change to 362/384/1068.
It does not permit the new finite-float label aliases.

checker_exact_list.py at the package root is a supported complete alternative.
It replaces isinstance(a, list) with type(a) is list. The comparison copy
controls/checker_exact_list.py has the same executable body and a different
docstring. Default json.load creates exact built-in list objects. Every
internal array construction uses list literals, comprehensions, slices or
concatenation and therefore also produces exact built-in lists. No list
subclass can reach the type predicate. The two predicates agree on every
reachable value, so all validation and inference behavior is preserved.
The scalar soundness, completeness and bi-interpretation arguments apply
unchanged. This supported option is self-contained and imports no helper.

Its 362/386/1064 count trades two extra AST nodes for four fewer bytes. Its
common-driver count is 366/391/1101, strictly below all three previous
common-driver coordinate minima. The primary checker.py remains the option
with fewer AST nodes. The choice is a representation-sensitive Pareto
tradeoff within one arithmetic and logical foundation.

HISTORICAL SCAN

original_audit.json records a broader static scan of the extracted current
archives: 816 checker-like paths, representing 177 distinct source hashes.
Its normalized minima agree with the nine-root comparison. The selection
rule deliberately overincludes archival predecessors and experimental
controls, and does not certify their soundness.

Those 177 historical byte strings are not all duplicated in this package.
Thus the main nine-source comparison, four optional comparators and the
explicit controls are reproducible offline here; the broader historical
scan is recorded evidence requiring the pinned original archives to repeat.
Do not describe that historical scan as independently rerun by measure.py.

OUTPUTS

results/measurements.json       Exact measurements, identities and controls
results/measurements.csv        Current root comparison table
results/measurement_table.tex   Paper table
results/common_driver_table.tex Common-driver paper table
results/numbers.tex             Automatically generated paper macros
