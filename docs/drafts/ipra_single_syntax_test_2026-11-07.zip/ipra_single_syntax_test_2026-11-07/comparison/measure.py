"""Reproduce whole-source iPRA measurements offline, without executing checkers.

The current nine root programs and four optional comparators are frozen by
SHA-256 in manifest.json. The normalization convention is inherited from the
drafts: remove actual docstrings, ast.unparse, and count significant tokens,
all AST nodes (including expression contexts), and normalized UTF-8 bytes.
The additional non-context count is reported separately and is not substituted
for the inherited all-node metric.
"""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RESULTS = ROOT / 'results'
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes',
          'ast_non_context_nodes', 'normalized_bytes', 'raw_bytes')
NORMALIZED = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
COMMON_DRIVER = """try:
    take = json.load(open(sys.argv[1])).pop
    accepted = check(take(), [])
except:
    accepted = False
print('ACCEPT' if accepted else 'REJECT')
sys.exit(not accepted)
"""


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def tokens(source):
    return sum(t.type not in IGNORED
               for t in tokenize.generate_tokens(io.StringIO(source).readline))


def measure_bytes(raw):
    source = raw.decode('utf-8')
    parsed = ast.parse(source)
    docstrings = set()
    for node in ast.walk(parsed):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                value = node.body[0].value
                docstrings.add(((value.lineno, value.col_offset),
                                (value.end_lineno, value.end_col_offset)))
    original_tokens = sum(
        t.type not in IGNORED and (t.start, t.end) not in docstrings
        for t in tokenize.generate_tokens(io.StringIO(source).readline))
    tree = ast.fix_missing_locations(StripDocstrings().visit(parsed))
    normalized = ast.unparse(tree) + '\n'
    nodes = list(ast.walk(tree))
    return {
        'source_tokens': original_tokens,
        'normalized_tokens': tokens(normalized),
        'ast_nodes': len(nodes),
        'ast_non_context_nodes': sum(not isinstance(n, ast.expr_context)
                                     for n in nodes),
        'normalized_bytes': len(normalized.encode('utf-8')),
        'raw_bytes': len(raw),
        'sha256': hashlib.sha256(raw).hexdigest(),
        'normalized_sha256': hashlib.sha256(normalized.encode('utf-8')).hexdigest(),
    }


def metrics(path):
    """Public convenience function; reads and parses but does not execute."""
    return measure_bytes(Path(path).read_bytes())


def common_driver_metrics(raw):
    tree = ast.fix_missing_locations(
        StripDocstrings().visit(ast.parse(raw.decode('utf-8'))))
    # These sources have module imports, global initialization, function
    # definitions, and then one public try/except input/output driver.
    cut = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Try))
    prefix = tree.body[:cut]
    permitted = (ast.Import, ast.ImportFrom, ast.Assign, ast.AnnAssign,
                 ast.FunctionDef, ast.AsyncFunctionDef)
    if not all(isinstance(node, permitted) for node in prefix):
        raise ValueError('Unexpected statement before the public driver')
    tree.body = prefix + ast.parse(COMMON_DRIVER).body
    return measure_bytes((ast.unparse(tree) + '\n').encode('utf-8'))


def checked_entry(entry, key='local_file'):
    path = HERE / entry[key]
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != entry['sha256']:
        raise ValueError('Changed frozen comparator: ' + entry[key])
    return {**entry, **measure_bytes(raw),
            'common_driver': common_driver_metrics(raw)}


def minima(rows, fields=FIELDS):
    return {key: min(row[key] for row in rows) for key in fields}


def tex_escape(text):
    return text.replace('_', r'\_').replace('&', r'\&')


def short_label(row):
    archive = row['archive'].removeprefix('ipra_').split('_2026')[0]
    names = {'direct_kernel': 'Direct kernel', 'integrated': 'Integrated',
             'locality': 'Locality', 'opening_and_witnesses': 'Opening and witnesses',
             'reduction': 'Reduction', 'truth_completion': 'Truth completion'}
    label = names.get(archive, archive)
    if row['original_file'] == 'checker_scalar.py':
        label += ' (scalar)'
    elif row['original_file'] == 'checker_full.py' or (
            archive in ('direct_kernel', 'truth_completion')
            and row['original_file'] == 'checker.py'):
        label += ' (full recursion)'
    return label


def candidate_label(row):
    return {
        'checker.py': 'New scalar (fewer AST nodes)',
        'checker_exact_list.py': 'New scalar (fewer bytes)',
        'checker_full.py': 'New full-recursion checker',
    }[row['file']]


def write_table(rows, candidates, old):
    lines = [r'\begin{table}[tbp]', r'\centering\small',
             r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             r'Complete source & Tokens & AST nodes & Bytes\\', r'\midrule']
    for row in rows:
        lines.append(tex_escape(short_label(row)) + ' & '
                     + ' & '.join(str(row[key]) for key in NORMALIZED) + r'\\')
    lines += [r'\midrule', 'Current coordinatewise minimum & '
              + ' & '.join(str(old[key]) for key in NORMALIZED) + r'\\']
    for row in candidates:
        label = candidate_label(row)
        lines.append(label + ' & '
                     + ' & '.join(r'\textbf{' + str(row[key]) + '}'
                                  for key in NORMALIZED) + r'\\')
    lines += [r'\bottomrule', r'\end{tabular}',
              r'\caption{Complete normalized Python sources in the six current archives. '
              r'All imports, parsing, checking, error handling, verdicts and exit status '
              r'are included. AST nodes include expression contexts. '
              r'The comparison is corpus-relative, not an absolute lower-bound theorem.}',
              r'\label{tab:measurements}', r'\end{table}', '']
    (RESULTS / 'measurement_table.tex').write_text('\n'.join(lines))


def write_common_table(candidates, old):
    lines = [r'\begin{table}[tbp]', r'\centering\small',
             r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             r'Identical public driver & Tokens & AST nodes & Bytes\\', r'\midrule',
             'Current coordinatewise minimum & '
             + ' & '.join(str(old[key]) for key in NORMALIZED) + r'\\']
    for row in candidates:
        label = candidate_label(row)
        lines.append(label + ' & '
                     + ' & '.join(str(row['common_driver'][key]) for key in NORMALIZED)
                     + r'\\')
    lines += [r'\bottomrule', r'\end{tabular}',
              r'\caption{Control using the same explicit Boolean-result driver for every '
              r'complete source. This retains all checking code and global initialization. '
              r'The primary scalar checker has fewer tokens and AST nodes and ties in bytes. '
              r'The supported exact-list scalar alternative is strictly below all three '
              r'current coordinatewise minima. These are two actual programs, '
              r'not a synthetic combination of their best coordinates.}',
              r'\label{tab:common-driver}', r'\end{table}', '']
    (RESULTS / 'common_driver_table.tex').write_text('\n'.join(lines))


def write_macros(candidate, full, exact, old, common_old, result):
    values = {}
    for prefix, source in (
            ('Candidate', candidate), ('Full', full), ('Exact', exact), ('Old', old),
            ('CommonCandidate', candidate['common_driver']),
            ('CommonFull', full['common_driver']),
            ('CommonExact', exact['common_driver']), ('CommonOld', common_old)):
        for suffix, key in (('Tokens', 'normalized_tokens'),
                            ('Nodes', 'ast_nodes'), ('Bytes', 'normalized_bytes')):
            values[prefix + suffix] = source[key]
    values.update(CurrentArchives=result['archive_count'],
                  CurrentPrograms=result['root_program_count'],
                  CurrentUniquePrograms=result['root_unique_source_hashes'],
                  CandidateSourceTokens=candidate['source_tokens'],
                  OldSourceTokens=old['source_tokens'])
    lines = ['% Generated by comparison/measure.py; do not edit by hand.']
    lines += ['\\newcommand{\\' + name + '}{' + str(value) + '}'
              for name, value in values.items()]
    (RESULTS / 'numbers.tex').write_text('\n'.join(lines) + '\n')


def main():
    manifest = json.loads((HERE / 'manifest.json').read_text())
    rows = [checked_entry(entry) for entry in manifest['programs']]
    optional = [checked_entry(entry) for entry in manifest['secondary_programs']]
    controls = [checked_entry(entry, 'file') for entry in manifest['controls']]
    candidates = []
    for filename in ('checker.py', 'checker_full.py', 'checker_exact_list.py'):
        path = ROOT / filename
        raw = path.read_bytes()
        candidates.append({'file': filename, **measure_bytes(raw),
                           'common_driver': common_driver_metrics(raw)})
    old = minima(rows)
    common_old = minima([row['common_driver'] for row in rows], NORMALIZED)
    full_rows = [row for row in rows
                 if row['arithmetic'] == 'full_primitive_recursion']
    result = {
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'commit': manifest['commit'],
        'archive_count': len(manifest['archives']),
        'root_program_count': len(rows),
        'root_unique_source_hashes': len({row['sha256'] for row in rows}),
        'boundary': 'Complete source, including all imports, input, validation, inference, exception handling, verdicts and exit status. No measured source is executed.',
        'normalization': 'Remove genuine docstrings; ast.unparse plus newline; count significant tokens, all ast.walk nodes, and UTF-8 bytes. AST contexts are included.',
        'supported_scalar_options': {
            'checker.py': 'Primary: fewer AST nodes.',
            'checker_exact_list.py': 'Supported alternative: four fewer normalized bytes at the cost of two AST nodes. JSON decoding and all internal constructors produce exact built-in lists, so the two type predicates agree on every reachable value.',
            'qualification': 'Each option is a complete actual program. No synthetic coordinate-minimum candidate is claimed.'},
        'coordinatewise_minimum': old,
        'full_recursion_subgroup_minimum': minima(full_rows, NORMALIZED),
        'full_recursion_subgroup_common_driver_minimum': minima(
            [row['common_driver'] for row in full_rows], NORMALIZED),
        'common_driver': COMMON_DRIVER,
        'common_driver_minimum': common_old,
        'candidates': candidates,
        'candidate_strict_improvements': [
            {key: row[key] < old[key] for key in NORMALIZED} for row in candidates],
        'candidate_common_driver_comparison': [
            {key: ('smaller' if row['common_driver'][key] < common_old[key]
                   else 'equal' if row['common_driver'][key] == common_old[key]
                   else 'larger') for key in NORMALIZED} for row in candidates],
        'root_programs': rows,
        'optional_programs': optional,
        'controls': controls,
        'expanded_archival_scan': {
            'status': 'Recorded independent audit; all historical sources are not bundled.',
            'metadata': 'comparison/original_audit.json',
            'qualification': 'Offline reproduction here covers the nine current root programs, the four optional direct alternatives, and the explicit controls. No new measurement of the full historical source corpus is claimed.'},
    }
    RESULTS.mkdir(exist_ok=True)
    (RESULTS / 'measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    with (RESULTS / 'measurements.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ('archive', 'original_file', *FIELDS, 'sha256'),
                                extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    write_table(rows, candidates, old)
    write_common_table(candidates, common_old)
    write_macros(candidates[0], candidates[1], candidates[2], old, common_old, result)
    print(json.dumps({key: result[key] for key in (
        'python', 'commit', 'archive_count', 'root_program_count',
        'root_unique_source_hashes', 'coordinatewise_minimum',
        'common_driver_minimum', 'candidates', 'candidate_strict_improvements',
        'candidate_common_driver_comparison')}, indent=2))


if __name__ == '__main__':
    main()
