A SINGLE SYNTAX TEST: A SMALLER CHECKED PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific time)
================================================================

START HERE

Read report.pdf. The complete editable source is report.tex together with
sections/, foundation/, and the generated tables in results/. The archive
contains all sources and fixtures required for offline reproduction.

RESULT

The new scalar presentation is below the current supplied draft frontier
in all three inherited complete-program source measures:

                              Normalized tokens  All AST nodes  Norm. bytes
Current six-archive minimum                  367            392         1076
checker.py                                   362            384         1068
checker_exact_list.py                        362            386         1064
checker_full.py                              369            390         1080

The first two delivered programs implement exactly the same scalar calculus.
The primary uses isinstance for its one list test; the supported alternative
uses an exact type comparison. Because the parser and checker create only
ordinary built-in lists, the predicates agree on all reachable values.
The primary has fewer AST nodes, while the alternative has fewer bytes.
No synthetic combination of their separate minima is claimed as a program.

With the identical conventional input/output driver on every program:

                              Normalized tokens  All AST nodes  Norm. bytes
Current minimum                              369            395         1105
Primary scalar                               366            389         1105
Exact-list scalar alternative                366            391         1101

The exact-list alternative improves all three common-driver coordinates.
The primary improves tokens and AST nodes and ties normalized bytes.
The full-recursion companion improves the current full-recursion subgroup
(374/396/1088), but does not dominate the overall scalar frontier.

Measurements include every import, validation and inference operation,
lookup table, JSON input, exception handler, verdict, and exit status.
Genuine docstrings are removed and the rest is normalized with ast.unparse.
AST counts include Load/Store context nodes. Exact recorded figures use
CPython 3.12.14; interpreter versions can affect normalization.

THE NEW IDEA

Classify a syntax node once: a list is traversed, while a scalar is tested
against the integer scope interval. This reuses the list classification as
the container guard and removes a redundant check. Finite numerical labels
denote the same syntactic coordinates as their integer floors. The checker
does not compute floor and the arithmetic theory gains no new operation.

The interval identity k <= a < d iff k <= floor(a) < d, together with the
inherited truth-completion invariant, proves the enlarged certificate
alphabet conservative. The new soundness argument extracts a derivation
from the actual successful trace. Whole-packet flooring is not a valid
execution-preserving translation: an included raw packet accepts while its
floored form rejects because a new hypothesis match changes consumption.

MATHEMATICAL STRENGTH

The report states every logical and nonlogical rule. The native basis has
zero, successor, initialized scalar iteration, equality, closure Q, and
paired binder D; two computation schemas and five inference patterns.
Ordinary intuitionistic logic is reconstructed internally. The complete
scalar predecessor, equality reflection, pairing, and primitive-recursion
compiler are included with attribution.

The faithful ordinary realization and iPRA are bi-interpretable on the whole
domain, with equality x=y defining both composite isomorphisms. The native
contradiction 0=S0 corresponds to genuine ordinary falsity through an explicit
bridge. The ordinary theory retains numerical coverage. These details are
essential for the full first-order strength claim.

The arithmetic basis and much of its proof are inherited. The improvement
is in certificate representation and trusted checker size. It is modest
and corpus-relative. No absolute simplest axiomatization, globally novel
arithmetic foundation, or representation-independent optimum is established.
The broader foundational breakthrough requested by the research program
remains open. The proofs are written mathematical proofs, not a Lean or Rocq
formalization of the complete metatheory or Python runtime.

CURRENT SOURCE SNAPSHOT

Repository: VladimirReshetnikov/ProveIt
Commit:     ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a
Directory:  docs/drafts

https://github.com/VladimirReshetnikov/ProveIt/tree/ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a/docs/drafts

All six retrieved ZIPs were verified against their Git blob hashes.
They contain nine root checkers, with seven distinct source byte strings.
The older 375/403/1117 numbers printed in their reports are not the current
comparison target. Frozen source copies and provenance are included.

RUN

  python3 checker.py examples/scalar_addition_two_three.json
  python3 checker_exact_list.py examples/rational_coordinates.json
  python3 checker_full.py examples/full_successor_uses_both_arguments.json
  python3 checker.py examples/normalization_raw.json
  python3 checker.py examples/normalization_quotient.json

The first four print ACCEPT and exit 0. The last deliberately prints REJECT
and exits 1. Every example's expected verdict and applicable checkers appear
in examples/index.json. FORMAT.txt specifies the entire packet language.

REPRODUCE

  python3 reproduce.py

This verifies frozen source identities, remeasures the complete programs,
and reruns finite validation. Only Python's standard library is needed;
no network is used. To also rebuild the paper:

  python3 reproduce.py --pdf

PDF rebuilding additionally requires pdfLaTeX, Latin Modern, and the standard
packages listed in report.tex. The build runs three passes with shell escape
disabled and rejects undefined references and overfull boxes.

  python3 build.py       Rebuild just the measurements, tables, and PDF
  python3 package.py     Regenerate SHA256SUMS and the ZIP after changes

The original release manifest covers all delivered files except itself.
Reproduction or rebuilding can update receipts/PDF metadata; regenerate the
manifest after intentional changes if those modified files will be packaged.

RECORDED FINITE VALIDATION

All recorded checks passed:

  342 frozen source expectations;
  202 compiled positive proofs: 147 scalar and 55 full recursion;
  147 additional positive replays for the exact-list alternative;
  92 example/checker cases across 39 example files;
  12,000 seeded mutated-packet trace comparisons with a separate oracle;
  13,056 explicit sorted-opening comparisons;
  10,000 finite-scalar quotient/opening comparisons;
  23 deliberate source-mutation controls;
  3,288 targeted and systematic false-conclusion probes;
  220 actual CLI runs, including ordinary and optimized Python.

These categories overlap. They are not summed into a count of independent
mathematical theorems. Some mutation controls detect invalid certificates or
the loss of valid ones, rather than inconsistency of a mutant. Finite tests
do not replace the universal correctness and interpretation proofs.

CONTENTS

  report.tex, report.pdf       Complete mathematical paper and compiled PDF
  sections/, foundation/      All editable LaTeX sections and proofs
  checker.py                  Primary complete scalar checker
  checker_exact_list.py       Supported alternative scalar implementation
  checker_full.py             Full-recursion companion
  FORMAT.txt                  Public certificate language and dispatch
  examples/                   Accepted and rejected runnable packets
  comparison/                 Frozen sources, controls, metrics, provenance
  validation/                 Independent oracle, compiler, tests, fixtures
  results/                    Machine-readable comparison and test receipts
  reproduce.py, build.py       Offline reproduction and PDF build
  package.py, SHA256SUMS       Archive construction and release file identities
  ATTRIBUTION.txt             Inherited and new contribution boundaries
  LICENSE_INHERITED.txt       Preserved source permission

TRUST AND RESOURCES

Each checker imports only json and sys. Producers, translators, oracles and
measurement scripts are untrusted support and are not imported by a checker.
The single positive list test prevents accidental recursive treatment of
strings as trees. Used numerical images and all padding are validated.
Only literal equalities receive an induction hypothesis.

The parser admits NaN/infinity extensions; these are labeled explicitly in
the examples. They can name template holes, but cannot survive closed used
syntax. Fractional aliases name existing coordinates, never new arithmetic
elements. See the soundness proof for the exact noncanonical behavior.

The idealized checker terminates on finite parsed inputs. Real parsing,
recursion, time and memory limits may reject sufficiently large valid proofs.
Completeness is the usual adequate-finite-resources statement.
