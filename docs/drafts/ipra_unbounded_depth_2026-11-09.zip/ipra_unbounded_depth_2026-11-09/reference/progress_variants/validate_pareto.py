"""Narrow regression support for the two assessed source refactorings.

This is evidence, not a proof of the inherited arithmetic metatheory.
Run from any directory; the frozen sources and fixtures are in the package.
"""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
REFERENCE = ROOT / 'reference'
spec = importlib.util.spec_from_file_location('source_measure', REFERENCE / 'source_measure.py')
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)


def definitions(path):
    parsed = ast.parse(path.read_text())
    parsed.body = [node for node in parsed.body if not isinstance(node, ast.Try)]
    scope = {}
    exec(compile(parsed, str(path), 'exec'), scope)
    return scope


def run(scope, packet):
    stack = copy.deepcopy(packet)
    scope['k'] = 0
    scope['q'] = stack.pop
    try:
        result = bool(scope['c'](stack.pop(), []))
    except BaseException:
        result = False
    return result, scope['k'], json.dumps(stack, sort_keys=True)


def main():
    baseline_path = REFERENCE / 'checkers/complete_kernel.py'
    baseline = definitions(baseline_path)
    positives = json.loads((REFERENCE / 'complete_kernel_fixtures.json').read_text())['records']
    public = json.loads((REFERENCE / 'complete_kernel_cli_cases.json').read_text())['cases']
    result = {'python': platform.python_version(), 'baseline': measure.metrics(baseline_path),
              'candidates': [], 'limitations': 'Finite regression; all-input reasoning in ASSESSMENT.txt.'}
    for name in ('local_s.py', 'lambda_instance.py'):
        path = HERE / name
        candidate = definitions(path)
        for fixture in positives:
            old = run(baseline, fixture['packet'])
            new = run(candidate, fixture['packet'])
            if old != new or not new[0]:
                raise ValueError((name, fixture['name'], old, new))
        public_runs = 0
        for optimized in (False, True):
            for case in public:
                command = [sys.executable] + (['-O'] if optimized else []) + [str(path)]
                completed = subprocess.run(command, input=case['input_text'], text=True,
                                           capture_output=True, timeout=20)
                expected = ((0, 'ACCEPT\n', '') if case['expected_accept']
                            else (1, 'REJECT\n', ''))
                if (completed.returncode, completed.stdout, completed.stderr) != expected:
                    raise ValueError((name, optimized, case['name'], completed, expected))
                public_runs += 1
        result['candidates'].append({'file': name, **measure.metrics(path),
                                     'positive_packets': len(positives),
                                     'matching_state_and_remaining_stack': True,
                                     'public_protocol_runs': public_runs,
                                     'protocol_modes': ['normal', '-O']})
    (HERE / 'pareto_validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
