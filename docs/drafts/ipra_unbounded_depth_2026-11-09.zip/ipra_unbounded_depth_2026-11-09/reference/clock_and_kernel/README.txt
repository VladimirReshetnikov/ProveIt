A SIMPLER CLOCK FOR iPRA
Research package prepared for Vladimir Reshetnikov, 9 November 2026.

START HERE
Open report.pdf. report.tex plus sections/ are its editable sources.
report_standalone.tex contains the entire main manuscript and the displayed
checker source in one LaTeX file.

MAIN MATHEMATICAL RESULT
In bare initialized closed iteration with literal-equation induction,
the new clock defines predecessor internally:

  T(u) = C(N(u), C(N(G(u)), G(u), 1), u+2)
  A(n) = I_T(G(n), 2E(n))
  P(n) = C(N(A(n)), 0, A(n)+N(n)).

It proves P(0)=0 and P(S(n))=n over the entire domain. The previous
helpers H,d4,M4,e,r,R are unnecessary. The old general three-way
gluing argument is unnecessary too. The shared predecessor description
drops from 22 declarations / 130 body nodes to 16 / 93 (28.46%).
This is a reduction of derived arithmetic, not a smaller trusted rule set.

COMPLETE AXIOMATIZATION
The report explicitly specifies the two computation schemas and four
native inference patterns, derives ordinary intuitionistic logic and
all quantifier-free induction, and explains both whole-domain identity
composites with iPRA. The native basis and most of its compiler are
inherited and credited. The new predecessor replaces the old term
inside that compiler. No universal PR evaluator is introduced.

SEPARATE CHECKER RESULTS
code/native/checker.py measures 306 normalized tokens, 340 AST nodes,
859 normalized bytes in CPython 3.12.14, against the supplied
309 / 344 / 864 complete source. Its decoder adds exactly these
traversed syntax aliases:
  empty string -> []
  empty object -> []
  one-empty-key object -> [[]] (associated value ignored).
The successful-trace soundness proof is included. Canonical numeric/array
certificates retain their exact behavior, but ALL-INPUT equivalence is
NOT claimed. Nonempty strings reject through CPython's recursion guard;
an unlimited-stack idealization would diverge on that malformed branch.
This runtime qualification is part of the result. The byte record is
literal-source only; it does not survive every identifier-renaming control.

code/native/strict_checker.py preserves the original all-input behavior
and validation. It measures 308 / 341 / 894: fewer tokens/AST nodes,
more bytes. It does not beat the entire three-coordinate frontier.

Neither program implements the new predecessor proof directly; they
implement the inherited native certificate calculus. No global smallestness
or major reduction of the trusted axiomatization is claimed. A structurally
total all-JSON checker strictly below every current coordinate remains open.

REPRODUCE
  python3 reproduce.py
  python3 build.py
  python3 package.py

The diagnostics and comparisons need Python's standard library only.
Exact ast.unparse measurements use CPython 3.12.14. The PDF build uses
pdflatex with shell escape disabled and the standard packages listed
in report.tex. A local-format bootstrap is supplied for minimal Debian
TeX installations whose installed format cache has not been generated.
It downloads nothing and changes no system TeX files.

Run a checker on a JSON packet:
  python3 code/native/checker.py < packet.json
  python3 code/native/strict_checker.py < packet.json

VERIFICATION SCOPE
The universal arithmetic theorem is a written proof with separate
assistant review, not a Lean or Rocq formalization. Numerical diagnostics
validate definitions and finite instances only. The full checker receipt
contains 1,032 CLI runs, both normal and optimized, 147 positive fixtures,
13 public cases, two sets of 1,500 trace comparisons, and 1,155 local
alias-substitution checks. The source extension's universal soundness
rests on its written trace extraction and the inherited calculus proof.

FILES
report.pdf / report.tex / report_standalone.tex / sections/
  Main report and complete editable sources.
code/check_clock.py / code/closed_definitions.json
  New and old arithmetic descriptions, validator, diagnostics and counts.
code/native/
  Complete candidate, strict alternative, old baseline, verification,
  fixtures, measurement utility, and precise proof notes.
code/measure_checkers.py
  Remeasures nineteen unchanged complete supplied reference sources.
reference/closed_equational/
  Unchanged attributed source/PDF for the old arithmetic and compiler.
reference/checkers/ / reference/provenance/
  Attributed comparison sources, original specifications and provenance.
evidence/
  Source hashes, actual validation receipts, reviews, build and PDF checks.
MANIFEST.json
  Byte sizes and SHA-256 hashes of the packaged payload.

SOURCE
Repository: VladimirReshetnikov/ProveIt
Snapshot: e707d8bd1bcbc036631663e7538efd8b42b1e130
All eleven current docs/drafts archives were retrieved and verified.
The repository was read only; no changes were submitted.
