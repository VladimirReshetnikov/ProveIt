DIRECT CHECKER FOR SHIFTED CLOSED-UNARY ARITHMETIC
================================================

Status and trust boundary
-------------------------
kernel.py is a complete, standalone, readable proof checker for the ordinary
first-order theory specified here. It is not a compact record checker. It
imports only Python's standard library. It imports neither tests.py nor a
producer, evaluator, oracle, theorem database, or external theorem prover.
Every arithmetic axiom and every logical inference it trusts appears below
and in the rule dispatcher. The supplied certificates do not formalize the
long predecessor/clock proof or the bi-interpretability theorem.

The program has written soundness/completeness justification below and finite
executable regression evidence. It is not verified in Lean, Rocq, or another
proof assistant. A successful run certifies one derivation in this explicit
theory, not the surrounding mathematical metatheorems.

Run a certificate:
  python3 kernel.py < examples/contextual_equation_induction.json

Reproduce all finite checks and source-size measurements:
  python3 tests.py

Python 3.10+ is sufficient. Exact recorded source metrics use CPython 3.12.14.
Both ordinary Python and Python -O are checked. No acceptance condition uses
an assert statement. No network access or nonstandard package is needed.

Public packet and output
------------------------
The input is one JSON object with exactly two fields:
  {"goal": FORMULA, "proof": PROOF_NODE}

The goal must be closed. The proof starts with the empty context and no free
numerical variables. Success prints ACCEPT on stdout and exits with code 0.
Failure exits with code 1 and a REJECT diagnostic on stderr. Syntax errors,
duplicate JSON object keys, nonfinite JSON numbers, unknown rules, extra rule
fields, wrong premise counts, unbound variables, and failed side conditions
are rejected. Boolean values are not accepted as integer hypothesis indices
or projection selectors. Input is never executed as code.

The callable public API is verify(packet), which returns True or raises an
exception on failure. Ambient contexts/names are internal checker state;
the user cannot supply them in the public packet.

Numerical terms: fixed descriptions, no universal evaluator
-----------------------------------------------------------
  ["0"]                  zero
  ["v", "x"]             numerical variable x
  ["K", n, a, h]          shifted iteration with count n, seed a, update h

The free variables of n and a must be available in the ambient environment.
The update h is checked in the RESET environment containing only the reserved
variable "$". Its free variables must be a subset of {"$"}. In a nested K,
the nested update gets its own reset "$" environment. Thus an update may
read its state but may not capture an ambient parameter or a running counter.
The actual arguments n and a may contain arbitrary available parameters.

Every update is an actual finite syntax tree. A K-symbol indexed by h only
uses earlier operations appearing in the smaller update-index syntax; no
numeric program-code variable or total universal evaluation axiom is present.
There are no symbol references that can construct circular declarations.

Successor is an abbreviation, expanded in every certificate:
  sigma(t) = ["K", ["0"], t, ["v", "$"]].

The zero test and one are also abbreviations:
  delta(t) = ["K", t, ["0"], ["0"]],
  one = sigma(["0"]).

There is no primitive S term constructor. There is no definitionally trusted
computation: computation equalities require a K0 or KS proof node.

Formula syntax and variable discipline
--------------------------------------
  ["eq", s, t]            numerical equality
  ["bot"]                 genuine falsity
  ["and", A, B]           conjunction
  ["or", A, B]            disjunction
  ["imp", A, B]           implication
  ["all", "x", A]         universal quantification
  ["ex", "x", A]          existential quantification

All user variables and formula binders are nonempty strings other than "$".
The same name may be shadowed by an ordinary formula binder. Comparisons of
formulas use alpha-equivalence, with nearest binders taking precedence.
Numerical substitution is capture avoiding. If an image's free variable would
be captured, the binder is renamed first to an unused name. Closed K update
indices are never modified by ambient numerical substitution.

A proof node has the form
  {"rule": NAME, ...RULE_FIELDS..., "premises": [PROOF_NODE, ...]}.
The dispatcher enforces exactly the displayed fields and premise count.
Premises are ordered. In descriptions below, C is the retained context and
N is the current set of available numerical variable names.

All logical and equality rules
-------------------------------
hyp: fields index; 0 premises.
  Return C[index]. Context indices start at zero; hypotheses are reusable.

refl: fields term; 0 premises.
  Return term=term.

transport: fields var, body; 2 premises.
  var must be fresh for N. body is a formula in N plus var. Premise 0 proves
  s=t and premise 1 proves body[s/var]. Return body[t/var]. The motive may
  contain all ordinary logical operations and any number of occurrences.

bot_e: fields as; 1 premise.
  Premise must prove bot. Return the well-formed formula in field as.

and_i: no fields; 2 premises.
  From A and B return A and B.

and_e: fields side (0 or 1); 1 premise.
  From A0 and A1 return A_side.

or_i: fields side (0 or 1), other; 1 premise.
  From A and supplied B return A or B when side=0, B or A when side=1.

or_e: no fields; 3 premises.
  Premise 0 proves A or B. Check premise 1 under C followed by A and
  premise 2 under C followed by B. Their conclusions must be alpha-equivalent.
  Return that common conclusion; both branch assumptions are discharged.

imp_i: fields assume; 1 premise.
  Check the premise under C followed by assume. From its conclusion B return
  assume -> B, discharging that final assumption.

imp_e: no fields; 2 premises.
  Premise 0 proves A -> B and premise 1 proves A. Return B.

all_i: fields var; 1 premise.
  var must not be in N. Check the premise in N plus var, retaining C.
  From its conclusion A return forall var A. This ensures var is absent
  from every free variable in the retained context.

all_e: fields term; 1 premise.
  From forall x A return A[term/x], using capture-avoiding substitution.

ex_i: fields var, body, term; 1 premise.
  Validate exists var body in N and validate the witness term in N.
  The premise must prove body[term/var]. Return exists var body.

ex_e: fields var; 2 premises.
  Premise 0 proves exists x A. var must not be in N. Check premise 1 in
  N plus var, under C followed by A[var/x]. Its conclusion must have no
  free occurrence of var. Return it, discharging the witness assumption.

Structural weakening, exchange, contraction, bound renaming, numerical
substitution, and cut are admissible metarules, not unchecked instructions.
There is no classical inference rule or excluded-middle schema.

All nonlogical axioms and the induction rule
--------------------------------------------
K0: fields seed, update; 0 premises.
  update is closed unary. Return
    K_update(0,seed) = sigma(seed).

KS: fields count, seed, update; 0 premises.
  update is closed unary. Return
    K_update(sigma(count),seed) = update[K_update(count,seed)/$].
  Substitution into actual argument positions is explicit; nested fixed
  update indices remain unchanged.

BR: fields term; 0 premises.
  Return delta(term)=0 or delta(term)=one.

F: no fields; 0 premises.
  Return 0=one -> bot.

EI: fields var, left, right, at; 2 premises.
  var is fresh for N. left and right are NUMERICAL TERMS in N plus var;
  at is a numerical term in N. Put E(var):=(left=right).
  Premise 0, under the original C,N, must prove E(0).
  Premise 1, under C followed by E(var), in N plus var, must prove
  E(sigma(var)). Return E(at), discharging that one induction hypothesis.
  Thus only a literal equation is an induction matrix. An equation beneath
  a connective or a quantifier is not admitted as a matrix. Retained C may
  contain arbitrary first-order formulas and is unchanged by the rule.

These are the complete nonlogical axioms/rules. In particular, the checker
has NO successor-injectivity axiom, coverage axiom, predecessor axiom,
retraction axiom, clock axiom,
pairing axiom, equality-test reflection axiom, induction for arbitrary
quantified formulas, or hidden library of derived theorems.

Written correctness argument
-----------------------------
1. Validation and substitution. Induction on term trees proves that term()
   admits exactly the displayed fixed-description syntax with its prescribed
   free-variable environment. The K update case resets that environment.
   Induction on formula trees gives the analogous fact for formula(). Standard
   structural induction proves the capture-avoiding substitution lemma; the
   fresh renaming branch avoids every free name of the image and every name
   in the renamed body. Closed update indices have no ambient free variables
   and are therefore left unchanged. canonical() computes ordinary alpha-
   equivalence using the nearest binder, with closed update scopes reset.

2. Soundness. Induct on a successful finite infer() trace. Each case implements
   exactly the inference above, and each returned formula is validated in its
   stated ambient environment. A recursive hypothesis is a previously validated
   member of the retained context. Introduction/elimination cases retain or
   discharge exactly their specified assumptions. The explicit fresh-name and
   free-variable checks give the quantifier and EI side conditions. BR and F
   return only their actual instances; K0/KS build their conclusions from
   validated terms. EI takes two terms, so a compound induction matrix cannot
   enter through a syntactic abbreviation. Transport uses the substitution
   lemma and actual equality. At verify(), the context/environment are empty
   and the inferred conclusion must match the closed requested goal.

3. Completeness for this presentation. Translate a finite ordinary natural-
   deduction derivation in the displayed theory recursively to proof nodes.
   Rename eigenvariables to unused strings, expand sigma/delta abbreviations,
   express each fixed operation by its finite K syntax, and reference retained
   hypotheses by their list positions. Every inference then matches one listed
   rule. Alpha-equivalent binder choices are accepted. Structural rules are
   handled by index changes, duplication of premise proofs, or substitution
   of proofs at hypothesis leaves, after eigenvariable renaming. In particular,
   ordinary contextual equation induction is represented directly by EI.

4. Termination and resources. Validation and proof checking descend finite
   parsed trees. Substitution may grow a finite formula but does not inspect
   a formula as executable code. Its alpha-renaming recursion strictly enters
   a smaller body and chooses a name that does not trigger the same capture.
   All operations therefore terminate in the mathematical finite-tree model.
   Actual memory or Python recursion limits may reject sufficiently large
   valid derivations. Completeness has the usual sufficient-finite-resources
   meaning; no resource-bound completeness claim is made.

Finite evidence and what it establishes
---------------------------------------
tests.py manually constructs expected formulas and proof packets; kernel.py
never imports it. The examples exercise every one of the 19 rule names.
The substantive arithmetic examples include contextual equation induction:
  forall a forall b (a=b -> forall n K_id(n,a)=sigma(b)),
whose retained assumption is used in the base, and successor separation:
  forall x (sigma(x)=0 -> bot),
derived using K0, KS, equality transport, implication elimination and F.
The latter proof uses no BR or induction.

The quantified transport and universal-specialization examples force actual
capture avoidance and compare independently chosen alpha-equivalent binders.
Rejection controls include attempted quantified induction, escaped/freshness-
violating eigenvariables, ambient capture by a K update, wrong induction base
or step, false equations, context leaks, malformed syntax and invented axioms.

validation.json records 20 accepted packets, 32 rejected packets, 5 malformed
JSON controls and 109 full CLI runs. All 52 structured cases also run through
verify(), and all run as subprocesses under both normal and optimized Python.
These tests are finite implementation evidence, not proofs of the universal
arithmetic construction or either interpretation composite.


Additional focused scope audit
------------------------------
A second review checked nested same-name binders, arithmetic index binding,
substitution under nested K, and all quantifier/EI freshness conditions. No
actual soundness or capture-avoidance gap was found. Three focused adversarial
controls and two matching positive controls were added:
  * KS substitutes the outer state in a nested K's two actual arguments while
    preserving that nested K's separately bound update. An alteration that
    substitutes into the nested index is rejected. In the concrete example,
    the altered equation is false already on standard natural numbers.
  * Alpha-equivalence identifies the nearest repeated binder, accepting an
    actual alpha-renaming but rejecting confusion of inner and outer binders.
  * An EI target mentioning its newly introduced induction variable rejects;
    the target must have been a term in the original ambient environment.
The trusted program did not change during this review. Its SHA-256 is
fe89bc49352e5c73b0130045f746fe1fbe65a49b9456f17493c5cc3dca5116c0.

Whole-program complexity
-------------------------
The exact normalized source profile of kernel.py, under the same convention as
current comparator programs, is:
  2730 significant tokens / 2856 AST nodes / 10512 normalized UTF-8 bytes.
Comments and genuine leading docstrings are removed, then ast.unparse is used;
all remaining source, imports, tables, validation, and the CLI wrapper count.
The measured current compact envelope is 313 / 347 / 878 with different
attainers. This readable direct checker is therefore not a size competitor,
and its existence does not prove a strict proof-checker complexity reduction.

Contents
---------
kernel.py         Complete standalone trusted accepting program.
tests.py          Untrusted certificate producer, regression runner and measurer.
examples/*.json   Twenty concrete valid closed derivations.
validation.json   Actual executed result record and full-program source metrics.
README.txt        Exact syntax, full rule inventory and correctness/scope notes.
