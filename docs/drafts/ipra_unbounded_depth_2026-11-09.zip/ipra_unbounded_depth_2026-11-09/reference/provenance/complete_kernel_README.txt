COMPLETE NATIVE KERNEL: EXACT SOURCE REFINEMENT
=============================================

Result and scope
----------------

complete_kernel.py is a whole executable implementation of the inherited
scalar/native certificate checker. With the exact inherited normalizer and
CPython 3.12.14 it has:

  309 normalized Python tokens
  344 Python AST nodes
  864 normalized UTF-8 bytes

The frozen corpus coordinate minima are 312 tokens, 347 AST nodes, and 878
bytes. Thus this literal complete source is strictly smaller in each of the
three declared coordinates. The parser import, input handling, substitution,
proof checking, exception handling, and output driver are all measured. Only
actual Python docstrings are removed by the inherited normalizer.

This is a separate implementation result. It does NOT implement the new
anchored-reset axiomatization in the report. It preserves the public proof
language and behavior of reference/checkers/array_only.py. The arithmetic
calculus, logical rules, proof interpretation, and theorem repertoire are
inherited. No new claim about global minimality follows from these counts.

The new mathematical axiom deletion and this source improvement should be
reported as two independent findings. Neither the source refactoring nor
the shorter identifier names are a mathematical breakthrough.

Stable candidate SHA-256:
  6726df4aa9cb5560ac82889c5ff1fcab8838e8752b29eeee2c509ad78e85982e
Frozen array_only.py SHA-256:
  9cc227c1481d321449b8f9b5ca5d447555bec42f28e07419ad1bab1c7d097e28
Inherited source_measure.py SHA-256:
  f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc

Reproduction
------------

From the artifact directory:

  python code/verify_complete_kernel.py

The verifier rejects changes to the candidate, baseline, measurement script,
fixture files, or frozen manifest before executing the verification. It also
checks every frozen comparator against its manifest hash. It writes:

  evidence/complete_kernel_results.json
  evidence/complete_kernel_metrics.json

The metrics intentionally use the whole module, not the optional "core"
metric exported by the old normalizer. Python versions can change AST/unparse
details; the recorded environment is CPython 3.12.14.

For a direct invocation, supply a JSON proof packet on standard input:

  python code/complete_kernel.py < certificate.json

Success prints exactly ACCEPT followed by a newline, with exit status 0 and
empty stderr. Rejection prints exactly REJECT followed by a newline, with
exit status 1 and empty stderr, under ordinary execution. The same behavior
is checked under python -O. There are no assert-based acceptance gates.

Honest naming control
---------------------

The inherited metric does not normalize identifiers. The collision-free
renaming inst -> i, check -> c, take -> q removes 62 normalized bytes from
the corresponding complete source, without changing token or AST counts.
It is therefore necessary to distinguish the literal-source record from
a comparison in which all implementations receive the same short names.

                                Literal source        Uniform short names
                                tokens / AST / bytes   tokens / AST / bytes
  array_only.py                 312 / 348 / 920        312 / 348 / 858
  compact_unpack_open.py        313 / 347 / 922        313 / 347 / 860
  structural_open.py            316 / 347 / 901        316 / 347 / 839
  compact_open.py               317 / 351 / 878        317 / 351 / 816
  complete_kernel.py            309 / 344 / 864        309 / 344 / 864

These four old programs include every attainer of an old coordinate minimum.
The verifier proves that the three replacement identifiers do not occur in
their original binding/name sets before applying the same AST renaming.
The full literal measurements for all 17 frozen complete programs are in
the metric receipt. Frozen reference files are never rewritten.

The token and AST records persist under this naming control. The byte
dominance does NOT persist: compact_open.py reaches 816 bytes under the same
renaming. In particular the claim is not name-independent Pareto dominance.
The final source is six normalized bytes longer than uniformly renamed
array_only.py, while using three fewer tokens and four fewer AST nodes.

Exact transformation
--------------------

There are four changes to the frozen array_only.py executable AST:

1. The three collision-free identifier renamings above.
2. Elimination tries one-element unpacking before two-element unpacking.
3. The singleton case's local zero is supplied by immutable default s=0.
4. The never-read first byte of the arity-offset table becomes a space.

Baseline elimination block, after renaming:

  try:
      s, u = m
  except:
      s, u, t = 0, t, *m
  return i(t, u) == a and c(i(t, s), g)

Final block, inside c(a, g, s=0):

  u = t
  try:
      t, = m
  except:
      s, u = m
  return i(t, u) == a and c(i(t, s), g)

The verifier reconstructs exactly this AST transformation, including the
changed default and byte literal, and compares it with the entire final
AST after docstring removal. It rejects any unlisted executable change.
There are exactly four calls to c; every one supplies exactly two positional
arguments and no keyword arguments. The sole runtime import is json.

The next sections prove this transformation correct for the full public
JSON interface, including malformed and noncanonical inputs. It is not
merely an argument about canonical arithmetic proof terms.

All-input equivalence: transport dispatch
----------------------------------------

Use the same parsed JSON objects in the two executions, and identify old
and new variable names by the alpha-renaming. Before the modified block,
the programs have identical goal a, context g, proof-stack remainder,
global freshness floor k, and instruction fields m,t. The changed block
is guarded by exactly the same two conditions:

  if m and c(m, g):
      if [] in (h := [0, m[2:]]):

For an ordinary list m, the first truth test makes m nonempty. The inner
test is true precisely when m[2:] is empty, because 0 is not equal to [].
Thus a list can enter the changed block only with length one or two.

There is no additional non-list case. Numbers, booleans, null, and JSON
objects cannot successfully perform this slice; both programs fail before
the changed assignments. A string slice is a string and cannot equal an
empty list; directly checking a string also fails the unchanged array-only
substitution traversal. These observations cover every kind of built-in
value returned by json.load, including its supported NaN and Infinity
extensions. Internal syntax construction creates only ordinary lists and
scalars, and cannot introduce an overloaded iterator or custom object.

For len(m)=1, write m=[M] and let T be the incoming value of t.

  Old: two-target unpack fails; fallback sets (s,u,t)=(0,T,M).
  New: default s=0, then u=T and singleton unpack t=M.

For len(m)=2, write m=[L,R].

  Old: unpack succeeds and sets (s,u,t)=(L,R,T).
  New: u=T; singleton unpack fails before assigning t; fallback sets
       s=L and u=R, leaving t=T.

Both cases produce exactly the same three object references, not merely
equal values. Failed ordinary list unpacking checks cardinality before
storing its targets. No user iterator or property access occurs. This also
handles object-identity-sensitive details such as a floating-point NaN
inside a list: neither refactoring changes any member reference.

The zero default is an immutable integer. All four driver/recursive calls
pass only a and g, so every activation receives precisely s=0. Local writes
to s cannot change the function default or another activation. The two-item
case overwrites s before reading it, and other branches never read it.

Consequently the common return expression evaluates the same substitutions,
the same equality test, and the same recursive subcheck. Its short-circuit
behavior, instruction consumption, context, and global k are preserved.
No proof cell is consumed by either dispatch block itself.

All-input equivalence: the unread arity-table cell
------------------------------------------------

The substitution traversal consults its four-byte table only in the body of

  [i(b,t,d+TABLE[len(a)]) for b in a+[]]

For the built-ins under consideration, a+[] succeeds only for a list. If
the list is empty, the body is never evaluated: TABLE[0] is never read. If
it is nonempty, every evaluated lookup has index at least one. Traversal
does not mutate a, and the proof-stack pop operation is not called by i.
The two tables agree at indices one, two, and three; both have length four,
so all higher indices fail in exactly the same way. A non-list fails at
a+[] before any table access. This also applies to checker-generated data.

Replacing byte zero by printable space therefore changes no evaluated
value. Python's normalized literal spelling shrinks by three bytes. This
is removal of unreachable literal overhead, not a changed arity convention.

Whole program and failure behavior
----------------------------------

All other executable operations are unchanged by the verified AST rewrite:
JSON parsing, the array-only syntax guard, scalar comparisons, substitution,
context membership, introduction, computation, paired-major elimination,
fresh-coordinate allocation, recursive proof checking, and the outer CLI.
The language has not been silently restricted to a canonical subgrammar.
Existing Boolean/float numerical aliases, unused malformed witnesses,
unused prefix cells, and failed-major fallback behavior are retained.

Induction on the finite recursive evaluation trace now gives identical
returns or rejection at corresponding program points, with the same proof
stack and global k. Every non-hypothesis checker invocation consumes an
instruction; syntax traversal acts on finite JSON-derived acyclic values.
The modified block neither adds a recursive call nor changes any of its
arguments. Malformed JSON fails in the unchanged parser. Parsed top-level
values with no usable pop method, empty packets, ill-shaped instructions,
malformed goals, and later syntax failures reach the unchanged rejection
handler in both programs.

The driver still performs 1/c(q(),[]) and then prints ACCEPT; it still
catches failures, prints REJECT, and raises SystemExit(1). No stderr output
or diagnostic traceback was introduced. This is equality of the public
CLI language and verdict behavior, not equality of private helper APIs:
the function has a renamed identifier and one extra internal default.

As usual for source-equivalence claims, execution must be ordinary and
deterministic with sufficient resources. The programs do not use exactly
the same transient allocations, caught exception objects, bytecode, or
time. No claim covers injected MemoryError, tracing/signal interference,
external process termination, or fault-for-fault equivalence at resource
boundaries. This qualification does not narrow the JSON certificate grammar.

Regression and integrity evidence
---------------------------------

The verifier replays all 147 inherited positive certificates and all 13
public CLI cases against both complete executables, in normal and -O modes.
It adds two explicit canonical proofs for failed-major fallback, fifteen
alias/corruption cases, and five malformed-parser cases. Every CLI check
compares all three observations: exact stdout, stderr, and exit status.

Positive tracing records a canonical integer/array witness for every
operational branch: context membership, singleton elimination, equation
transport, paired-major elimination, introduction, zero computation,
successor computation, context allocation, and failed-major fallback.
The measured source is not modified by this observation. The two additional
fallback packets are embedded in the verifier and included in the receipt
for direct inspection; the historical names of inherited fixtures are not
treated as proof that a branch was actually exercised.

A separate systematic corpus uses ordinary JSON atoms, singleton and
overlong arrays, numerical aliases, objects, strings, null, NaN, and
infinities in several packet/instruction/goal positions. Fixed-seed changes
to inherited proofs exercise malformed nested syntax and witness aliases.
These comparisons require equality of acceptance, freshness floor, and
remaining proof stack, not just one-way acceptance containment.

Integrity controls deliberately alter the candidate, comparator, and
fixture bytes and require hash rejection. AST controls change the zero
default, a reachable offset, or the transport equality gate and require
source-transform rejection. Thus the supporting verifier does not merely
trust a precomputed success receipt.

The fixture files are copied unchanged from the successor-clock archive.
Their original positive corpus was recorded at repository commit
06e097f723c659030816e0194e5eb7e8c607ba9b in
docs/drafts/ipra_kernels_and_initializer_obstruction_2026-11-08.zip,
member ipra_kernel_2026-11-08/validation/boxed_positive_certificates.json.
Exact fixture and comparator hashes, the pinned current repository commit,
and individual metric rows are retained in the receipts/reference manifest.

Trust boundary
--------------

The checker itself uses Python built-ins and the standard json parser.
It does not import this verifier, proof producers, the source normalizer,
an arithmetic decision procedure, or an encoded implementation of iPRA.
The four-byte offset table is ordinary syntax data, fully charged in size.
All finite tests and corpus files are outside the measured checker.

The written equivalence proof transfers the inherited checker's logical
soundness and completeness, conditional on the correctness of that prior
calculus and its interpretation. The tests do not replace those mathematical
proofs. They do not verify the report's new anchored-reset theory either;
its scoped symbolic certificate and manuscript proof are separate artifacts.
