#!/usr/bin/env python3
"""Recompute the complete current iPRA checker frontier, offline.

The measurement convention is the inherited ProveIt source_measure.py
convention: remove comments and genuine docstrings, parse the complete source,
normalize with ast.unparse, and count tokens, AST nodes, and UTF-8 bytes.
No checker code, source literal, import, validation, or public driver is omitted.

Default input: the frozen root programs in ../comparison/checkers.
Usage: python3 measure_current.py [--baseline-dir DIR] [--output FILE]

The common-driver control is accepted only when the original driver has exactly
the inspected JSON/ACCEPT/REJECT form, differing solely in rejection exit syntax.
This script imports no project-specific measurement or proof-checker module.
"""

import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize


SNAPSHOT = "06e097f723c659030816e0194e5eb7e8c607ba9b"
ARCHIVES = {
    "ipra_boolean_boundary_2026-11-08": (),
    "ipra_boolean_core_2026-11-08": ("checker.py",),
    "ipra_boolean_separation_2026-11-08": (),
    "ipra_boxed_witnesses_2026-11-08": ("checker.py", "checker_compatible.py"),
    "ipra_clausal_kernel_2026-11-08": ("checker.py",),
    "ipra_context_blocks_2026-11-08": ("checker.py",),
    "ipra_context_pairs_2026-11-08": ("checker.py", "checker_exact_list.py"),
    "ipra_fixed_contexts_2026-11-08": ("checker.py",),
    "ipra_foundation_audit_2026-11-08": (),
    "ipra_kernels_and_initializer_obstruction_2026-11-08": (
        "checker.py", "checker_structural.py"
    ),
    "ipra_normalized_elimination_2026-11-08": (
        "checker.py", "checker_readable.py"
    ),
    "ipra_structural_audit_2026-11-08": (),
}
CHECKER_SHA256 = {
    "ipra_boolean_core_2026-11-08/checker.py":
        "95173ee161d104c1a7fc177f1597ff219f3e1612b459995059c41da588d66122",
    "ipra_boxed_witnesses_2026-11-08/checker.py":
        "5ecdcbf3ce5714616b9544aa21fda42bbde97818372119700ee5c78e88ffa6f4",
    "ipra_boxed_witnesses_2026-11-08/checker_compatible.py":
        "de606cbc80d04a8a9c8a214d6d8cc06ddae0f4adc17da5872f73fce5197881d0",
    "ipra_clausal_kernel_2026-11-08/checker.py":
        "84ac895d7d3457da80810f662d0a2bc7477f62d12e74897877e2fb438d841e5e",
    "ipra_context_blocks_2026-11-08/checker.py":
        "697cd8a3765496ae7304bb8fc599619f0ffc9cf02683ad5471a5ee0f16512e36",
    "ipra_context_pairs_2026-11-08/checker.py":
        "c81aa29492105e9a60cbdd643dfcd099412f46bc27fadff9dfff9fbb3615d258",
    "ipra_context_pairs_2026-11-08/checker_exact_list.py":
        "2eb8684c9e11e1d9442d85ed7fdd4c0f2568ef0f6dc98bbf715a458751bfa8ae",
    "ipra_fixed_contexts_2026-11-08/checker.py":
        "b149fec7ea0fcd0482b59dce040ea0445fedeeeadc0756ec0d0f189a9dd22f3a",
    "ipra_kernels_and_initializer_obstruction_2026-11-08/checker.py":
        "59445dee32b772be9d8ba2d7174a7456b7312f4419cc0733df285e0bc01aa3aa",
    "ipra_kernels_and_initializer_obstruction_2026-11-08/checker_structural.py":
        "9cf9f85b4b41a1988790aaf02fc92ccc325b9267a26391a3fa15644984059f97",
    "ipra_normalized_elimination_2026-11-08/checker.py":
        "7047cb279f6e16977fcd26c8278973cce755e4e45f9b01f93cba32b1fcf61b17",
    "ipra_normalized_elimination_2026-11-08/checker_readable.py":
        "2f7e951c13a15a7bb641fc4012d73781346bcf50cfc0a567a35d2ed93ed63eb6",
}
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")
IGNORED = {
    tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
    tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
}
DRIVER = """try:
    take = json.load(sys.stdin).pop
    1 / test(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
"""


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


class CommonNames(ast.NodeTransformer):
    names = {"inst": "sub", "check": "test"}

    def visit_Name(self, node):
        node.id = self.names.get(node.id, node.id)
        return node

    def visit_FunctionDef(self, node):
        node.name = self.names.get(node.name, node.name)
        return self.generic_visit(node)


def significant(source):
    return sum(t.type not in IGNORED for t in
               tokenize.generate_tokens(io.StringIO(source).readline))


def metrics(raw):
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    spans = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                value = node.body[0].value
                spans.add(((value.lineno, value.col_offset),
                           (value.end_lineno, value.end_col_offset)))
    source_tokens = sum(
        t.type not in IGNORED and (t.start, t.end) not in spans
        for t in tokenize.generate_tokens(io.StringIO(source).readline)
    )
    tree = ast.fix_missing_locations(StripDocstrings().visit(tree))
    normalized = ast.unparse(tree) + "\n"
    return {
        "source_tokens": source_tokens,
        "normalized_tokens": significant(normalized),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "raw_bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


def profiles(source):
    answer = {}
    for name, common_driver in (("common_names", False),
                                ("common_names_and_driver", True)):
        tree = CommonNames().visit(ast.parse(source))
        if common_driver:
            indexes = [i for i, n in enumerate(tree.body) if isinstance(n, ast.Try)]
            if len(indexes) != 1 or indexes[0] != len(tree.body) - 1:
                raise ValueError("Unrecognized public-driver boundary")
            boundary = indexes[0]
            old = tree.body[boundary]
            canonical = ast.parse(DRIVER).body[0]
            alternate = ast.parse(DRIVER.replace(
                "sys.exit(1)", "raise SystemExit(1)")).body[0]
            if ast.dump(old) not in {ast.dump(canonical), ast.dump(alternate)}:
                raise ValueError("Public driver has an uninspected semantic change")
            tree.body = tree.body[:boundary] + [canonical]
        controlled = (ast.unparse(ast.fix_missing_locations(tree)) + "\n").encode()
        measured = metrics(controlled)
        answer[name] = {key: measured[key] for key in FIELDS}
    return answer


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-dir", type=Path,
                        default=Path(__file__).resolve().parents[1] / "comparison" / "checkers")
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[1] / "results" / "current_benchmark.json")
    args = parser.parse_args()
    base = args.baseline_dir.resolve()
    manifest = json.loads((base / "manifest.json").read_text())
    if manifest["sha"] != SNAPSHOT:
        raise ValueError("The source snapshot does not match this audit")
    if {entry["name"] for entry in manifest["files"]} != {
            name + ".zip" for name in ARCHIVES}:
        raise ValueError("The twelve-archive source boundary changed")

    rows = []
    for archive, names in ARCHIVES.items():
        inner = ("ipra_kernel_2026-11-08" if "kernels_and_initializer" in archive
                 else archive)
        root = base / archive / inner
        observed = {path.name for path in root.glob("checker*.py")}
        if observed != set(names):
            raise ValueError("Unexpected complete root-checker inventory: " + archive)
        for name in names:
            path = root / name
            raw = path.read_bytes()
            if hashlib.sha256(raw).hexdigest() != CHECKER_SHA256[archive + "/" + name]:
                raise ValueError("The frozen source checksum changed: " + str(path))
            source = raw.decode("utf-8")
            imports = [ast.unparse(n) for n in ast.parse(source).body
                       if isinstance(n, (ast.Import, ast.ImportFrom))]
            # Inspection of all twelve files established this common boundary.
            if imports != ["import json, sys"]:
                raise ValueError("Changed acceptance dependency boundary: " + str(path))
            rows.append({
                "archive": archive,
                "member": str(path.relative_to(base / archive)),
                "path": str(path),
                "scope": "current-root",
                "imports": imports,
                **metrics(raw),
                "profiles": profiles(source),
            })

    extra = []
    prototype_root = base / "ipra_structural_audit_2026-11-08"
    for path in sorted(prototype_root.rglob("prototypes/checker*.py")):
        extra.append({"path": str(path), **metrics(path.read_bytes())})
    all_fields = (*FIELDS, "source_tokens", "raw_bytes")
    minima = {key: min(row[key] for row in rows) for key in all_fields}
    hashes = sorted({row["sha256"] for row in rows})
    result = {
        "snapshot": SNAPSHOT,
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "archives": len(ARCHIVES),
        "root_programs": len(rows),
        "metrics": minima,
        "attainers": {
            key: [row["path"] for row in rows if row[key] == minima[key]]
            for key in all_fields
        },
        "programs": rows,
        "structural_prototypes": extra,
        "controlled_envelopes": {
            name: {key: min(row["profiles"][name][key] for row in rows)
                   for key in FIELDS}
            for name in ("common_names", "common_names_and_driver")
        },
        "duplicate_hash_groups": [
            [row["path"] for row in rows if row["sha256"] == digest]
            for digest in hashes
            if sum(row["sha256"] == digest for row in rows) > 1
        ],
        "scope_note": (
            "Whole standalone root programs, including all parser, validator, "
            "scope data, logical operations, imports, and acceptance/rejection code. "
            "Historical nested comparators are not additional active proposals. "
            "Prototype APIs and fragment verifiers are not substituted for "
            "complete serialized theorem checkers. Standard Python and its "
            "standard library are common external runtime dependencies."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in (
        "snapshot", "python", "archives", "root_programs", "metrics",
        "controlled_envelopes", "duplicate_hash_groups")}, indent=2))


if __name__ == "__main__":
    main()
