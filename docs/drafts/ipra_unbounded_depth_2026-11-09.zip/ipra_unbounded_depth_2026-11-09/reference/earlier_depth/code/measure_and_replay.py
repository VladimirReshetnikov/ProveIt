#!/usr/bin/env python3
"""Reproduce the pinned source measurements and documented CLI examples.

The inherited checker files are measured as entire programs. They are not
imported by this script. Two compatible frontier programs are executed in
isolated subprocesses on the thirteen inherited public packets.
"""

import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    manifest = json.loads((ROOT / "comparison/manifest.json").read_text())
    normalizer = ROOT / "comparison/inherited_measure_current.py"
    spec = importlib.util.spec_from_file_location("inherited_metrics", normalizer)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = []
    for entry in manifest["programs"]:
        path = ROOT / "comparison" / entry["file"]
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == entry["sha256"],
                "A comparator source changed: " + entry["file"])
        actual = module.metrics(raw)
        for field in FIELDS:
            require(actual[field] == entry["metrics"][field],
                    "Metric differs for " + entry["file"] + ": " + field
                    + ". Exact profiles were recorded on CPython 3.12.14.")
        rows.append({"file": entry["file"], **actual})
    minima = {field: min(row[field] for row in rows) for field in FIELDS}
    require(minima == manifest["minima"], "The recorded envelope differs")

    packets = json.loads((ROOT / "comparison/cli_cases.json").read_text())
    cases = packets["cases"]
    checkers = ["01_compact_unpack_open.py", "04_compact_open.py"]
    replays = []
    for case in cases:
        raw = case["input_text"].encode("utf-8")
        if "source_sha256" in case:
            require(hashlib.sha256(raw).hexdigest() == case["source_sha256"],
                    "An inherited public packet changed: " + case["name"])
        expected = ((0, b"ACCEPT\n", b"") if case["expected_accept"]
                    else (1, b"REJECT\n", b""))
        observed = []
        for name in checkers:
            path = ROOT / "comparison/checkers" / name
            result = subprocess.run([sys.executable, "-I", "-X", "utf8", str(path)],
                                    input=raw, capture_output=True, timeout=10)
            triple = (result.returncode, result.stdout, result.stderr)
            require(triple == expected,
                    "Unexpected checker result: " + name + " / " + case["name"])
            observed.append({"checker": name, "exit_code": result.returncode,
                             "stdout": result.stdout.decode("utf-8"),
                             "stderr": result.stderr.decode("utf-8")})
        replays.append({"case": case["name"],
                        "expected_accept": case["expected_accept"],
                        "results": observed})

    receipt = {"status": "PASS", "python": platform.python_version(),
               "source_commit": manifest["commit"],
               "complete_programs_measured": len(rows),
               "original_source_occurrences": manifest["source_occurrences"],
               "minima": minima, "measurements": rows,
               "cli_cases": len(cases), "subprocess_runs": len(cases) * len(checkers),
               "replays": replays,
               "scope": "Exact copied-source audit and inherited finite regressions; "
                        "not an independent metatheoretic proof of the checkers"}
    destination = ROOT / "evidence/frontier_receipt.json"
    destination.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "programs": len(rows),
                      "envelope": minima, "cli_cases": len(cases),
                      "runs": len(cases) * len(checkers)}, sort_keys=True))


if __name__ == "__main__":
    main()
