NEGATIVE-FORMULA DEPTH EVIDENCE

Run with Python 3:
  python3 depth_evidence.py

The script creates depth_evidence.json and checks:
  * the three symbolic endpoint equations of the explicitly displayed
    two-binder formula for double-negated halting;
  * capture-avoiding substitution on an intentionally colliding variable;
  * the k and k+1 upper-bound depths for formal prefixes, k=1,...,12;
  * selector depth and preservation of free parameters for 49 depth pairs.

The formula named Rk is opaque. The script does not construct a universal
arithmetical predicate, prove its completeness, evaluate a halting set, or
establish the nonexistence of shallower formulas. It is not an iPRA proof
checker. Those mathematical arguments are stated and proved in the paper.

The arithmetic primitives C, p and S in this evidence are the fixed derived
terms of the paper. The normalizer uses only their displayed endpoint
equations. It does not use unbounded numerical search or an evaluator for
all primitive-recursive descriptions.
