#!/usr/bin/env python3
"""Symbolic evidence for the negative-formula depth theorem.

This is NOT an iPRA proof checker, a verification of modified realizability,
or a test of undecidability. It checks the finite syntax constructions used
in the paper: capture avoidance, gate endpoint computations, and the stated
binder depths. All numerical functions except C, p, S, 0 and 1 are opaque.
Run: python3 depth_evidence.py
"""

import json
from pathlib import Path


def var(name):
    return ("var", name)


ZERO = ("zero",)
ONE = ("S", ZERO)


def succ(term):
    return ("S", term)


def pred(term):
    return ("p", term)


def choose(control, left, right):
    return ("C", control, left, right)


def equal(left, right):
    return ("eq", left, right)


def binder(witness, counter, matrix):
    assert witness != counter
    return ("D", witness, counter, matrix)


def term_names(term):
    if term[0] == "var":
        return {term[1]}
    return set().union(*(term_names(x) for x in term[1:]))


def all_names(formula):
    if formula[0] == "eq":
        return term_names(formula[1]) | term_names(formula[2])
    assert formula[0] == "D"
    return {formula[1], formula[2]} | all_names(formula[3])


def free_names(formula):
    if formula[0] == "eq":
        return term_names(formula[1]) | term_names(formula[2])
    assert formula[0] == "D"
    return free_names(formula[3]) - {formula[1], formula[2]}


class Names:
    def __init__(self, forbidden=()):
        self.used = set(forbidden)
        self.next = 0

    def fresh(self):
        while True:
            name = "v" + str(self.next)
            self.next += 1
            if name not in self.used:
                self.used.add(name)
                return name


def term_substitute(term, variable, replacement):
    if term[0] == "var":
        return replacement if term[1] == variable else term
    return (term[0], *(term_substitute(t, variable, replacement)
                       for t in term[1:]))


def substitute(formula, variable, replacement):
    """Capture-avoiding numerical substitution in a named formula."""
    if formula[0] == "eq":
        return equal(term_substitute(formula[1], variable, replacement),
                     term_substitute(formula[2], variable, replacement))
    _, x, y, body = formula
    if variable in (x, y):
        return formula
    supply = Names(all_names(formula) | term_names(replacement) | {variable})
    if x in term_names(replacement):
        fresh = supply.fresh()
        body = substitute(body, x, var(fresh))
        x = fresh
    if y in term_names(replacement):
        fresh = supply.fresh()
        body = substitute(body, y, var(fresh))
        y = fresh
    return binder(x, y, substitute(body, variable, replacement))


def depth(formula):
    if formula[0] == "eq":
        return 0
    assert formula[0] == "D"
    return 1 + depth(formula[3])


def gate(control, formula):
    """Produce G_control(formula), renaming a conflicting binder first."""
    if formula[0] == "eq":
        return equal(choose(control, ZERO, formula[1]),
                     choose(control, ZERO, formula[2]))
    _, x, y, body = formula
    supply = Names(all_names(formula) | term_names(control))
    if x in term_names(control):
        fresh = supply.fresh()
        body = substitute(body, x, var(fresh))
        x = fresh
    if y in term_names(control):
        fresh = supply.fresh()
        body = substitute(body, y, var(fresh))
        y = fresh
    return binder(x, y, gate(control, body))


def pad(formula):
    supply = Names(all_names(formula))
    x, y = supply.fresh(), supply.fresh()
    return binder(x, y, gate(var(y), formula))


def selector(control, left, right):
    """Aligned selector M_control. Padding cost is counted in syntax."""
    while depth(left) < depth(right):
        left = pad(left)
    while depth(right) < depth(left):
        right = pad(right)
    if left[0] == "eq":
        assert right[0] == "eq"
        return equal(choose(control, left[1], right[1]),
                     choose(control, left[2], right[2]))
    supply = Names(all_names(left) | all_names(right) | term_names(control))
    x, y = supply.fresh(), supply.fresh()
    _, lx, ly, lb = left
    _, rx, ry, rb = right
    lb = substitute(substitute(lb, lx, var(x)), ly, var(y))
    rb = substitute(substitute(rb, rx, var(x)), ry, var(y))
    return binder(x, y, selector(control, lb, rb))


def all_quantified(variable, body):
    supply = Names(all_names(body) | {variable})
    u, z = supply.fresh(), supply.fresh()
    matrix = substitute(body, variable, pred(var(z)))
    return binder(u, z, gate(var(z), matrix))


def pair_quantified(witness, counter, body):
    supply = Names(all_names(body) | {witness, counter})
    z = supply.fresh()
    matrix = substitute(body, counter, pred(var(z)))
    return binder(witness, z, gate(var(z), matrix))


def implication(left, right):
    supply = Names(all_names(left) | all_names(right))
    u, z = supply.fresh(), supply.fresh()
    return binder(u, z, selector(var(z), left, right))


def normalize(term):
    """Only the displayed numerical endpoint equations are used."""
    if term[0] in ("var", "zero"):
        return term
    args = tuple(normalize(t) for t in term[1:])
    if term[0] == "C":
        control, left, right = args
        if control == ZERO:
            return left
        if control[0] == "S":
            return right
    if term[0] == "p":
        if args[0][0] == "S":
            return args[0][1]
        if args[0] == ZERO:
            return ZERO
    return (term[0], *args)


def normalize_equation(formula):
    assert formula[0] == "eq"
    return equal(normalize(formula[1]), normalize(formula[2]))


def generic_negative(k):
    """Compile the formal prefix H_k = not(forall exists forall ... R_k)."""
    assert k >= 1
    variables = ["n", "y1"]
    for j in range(2, k + 1):
        variables.extend(("x" + str(j), "y" + str(j)))
    atom = equal(("R" + str(k), *(var(x) for x in variables)), ZERO)
    body = atom
    for j in range(k, 1, -1):
        body = pair_quantified("x" + str(j), "y" + str(j), body)
    universal = all_quantified("y1", body)
    negative = implication(universal, equal(ZERO, ONE))
    return atom, universal, negative


def main():
    n, z, y, m, w = map(var, ("n", "z", "y", "m", "w"))
    equation = equal(choose(y, ZERO, choose(z, ("r", n, pred(y)), ZERO)),
                     choose(y, ZERO, ONE))
    concrete = binder("a", "z", binder("b", "y", equation))
    endpoints = {
        "y_zero": normalize_equation(substitute(equation, "y", ZERO)),
        "z_zero_y_successor": normalize_equation(
            substitute(substitute(equation, "z", ZERO), "y", succ(m))),
        "z_successor_y_successor": normalize_equation(
            substitute(substitute(equation, "z", succ(w)), "y", succ(m))),
    }
    assert endpoints["y_zero"] == equal(ZERO, ZERO)
    assert endpoints["z_zero_y_successor"] == equal(("r", n, m), ONE)
    assert endpoints["z_successor_y_successor"] == equal(ZERO, ONE)
    assert depth(concrete) == 2
    assert free_names(concrete) == {"n"}

    capture = binder("y", "z", equal(var("x"), var("y")))
    renamed = substitute(capture, "x", var("y"))
    assert free_names(renamed) == {"y"}
    assert renamed[1] != "y"
    assert renamed[3] == equal(var("y"), var(renamed[1]))

    generated = []
    for k in range(1, 13):
        atom, universal, negative = generic_negative(k)
        assert depth(universal) == k
        assert depth(negative) == k + 1
        assert free_names(universal) == {"n"}
        assert free_names(negative) == {"n"}
        generated.append({"k": k, "positive_prefix_depth": depth(universal),
                          "negative_formula_depth": depth(negative),
                          "free_variables": sorted(free_names(negative))})

    selection_checks = 0
    for left_depth in range(7):
        for right_depth in range(7):
            left = equal(var("left"), ZERO)
            right = equal(var("right"), ONE)
            for _ in range(left_depth):
                left = pad(left)
            for _ in range(right_depth):
                right = pad(right)
            selected = selector(var("control"), left, right)
            assert depth(selected) == max(left_depth, right_depth)
            assert free_names(selected) == {"left", "right", "control"}
            selection_checks += 1

    receipt = {
        "status": "PASS",
        "scope": "Finite symbolic syntax checks only; not an iPRA proof checker",
        "not_verified_by_this_program": [
            "modified-realizability soundness or totality of System T",
            "arithmetical-hierarchy strictness or noncomputability of halting",
            "the metatheoretic nonexistence of a shallower equivalent formula",
        ],
        "concrete_formula": concrete,
        "concrete_depth": depth(concrete),
        "symbolic_endpoints": endpoints,
        "capture_avoidance_example": renamed,
        "general_upper_bounds": generated,
        "selector_depth_and_free_variable_checks": selection_checks,
    }
    path = Path(__file__).resolve().parents[1] / "evidence" / "depth_evidence.json"
    path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "endpoint_cases": len(endpoints),
                      "upper_bounds": len(generated),
                      "selector_cases": selection_checks,
                      "receipt": path.name}, sort_keys=True))


if __name__ == "__main__":
    main()
