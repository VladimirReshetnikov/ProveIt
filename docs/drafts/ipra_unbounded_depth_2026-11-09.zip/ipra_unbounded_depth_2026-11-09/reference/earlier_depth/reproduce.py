#!/usr/bin/env python3
"""Run the finite executable evidence. No network or third-party packages."""
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    (ROOT / "evidence").mkdir(exist_ok=True)
    if sys.flags.optimize:
        raise RuntimeError("Run without -O; the symbolic diagnostic uses assertions.")
    steps = []
    for name in ("measure_and_replay.py", "depth_evidence.py"):
        result = subprocess.run([sys.executable, "-B", str(ROOT / "code" / name)],
                                cwd=ROOT, capture_output=True, text=True, timeout=60)
        if result.returncode:
            print(result.stdout, end="")
            print(result.stderr, file=sys.stderr, end="")
            raise SystemExit(result.returncode)
        print(result.stdout, end="")
        steps.append({"script": name, "exit_code": result.returncode,
                      "stdout": result.stdout, "stderr": result.stderr})
    receipt = {"status": "PASS", "python": platform.python_version(),
               "steps": steps,
               "scope": "Finite source, CLI, and symbolic syntax checks only"}
    (ROOT / "evidence/reproduction.json").write_text(json.dumps(receipt, indent=2) + "\n")


if __name__ == "__main__":
    main()
