THE INTUITIONISTIC COST OF A SINGLE LOGICAL BINDER
================================================
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date).

STATUS
------
The requested strictly smaller complete iPRA axiomatization/checker has
NOT been established. This archive must not be described as a new smallest
complete proof checker or as a proof of an absolute complexity lower bound.

The new mathematical result relative to the ten inspected current drafts
is an EXACT INTUITIONISTIC DEPTH SEPARATION in their native D language:

  For each k >= 1 there is a negative arithmetic formula H_k(n) with
  minimum standard-truth-set depth k and minimum iPRA-provable-equivalence
  depth k+1. The lower bound holds even for equivalence provable in HA.

At k=1, double-negated halting has exact intuitionistic native depth two,
although its standard truth set has depth one. An explicit two-binder
formula and all endpoint derivations are supplied.

The proof uses total modified realizability, a fixed dummy realizer for
negative premises in the full standard finite-type structure, and the
arithmetical hierarchy. These details are essential. No independence-of-
premise axiom, classical rule, or new induction principle is added to iPRA.

COMPLETE REFERENCE THEORY
-------------------------
The paper also gives all logical and nonlogical rules of an inherited
shifted-recursion theory with captured numerical parameters, a direct
primitive-recursive compiler, a noncircular equality-characteristic proof,
and both whole-domain interpretation composites. It is bi-interpretable
and equiconsistent with full first-order iPRA. Its mathematical basis is
attributed to the supplied successor-from-recursion draft; no new source-
size record is assigned to it.

CURRENT COMPARISON
------------------
Repository: VladimirReshetnikov/ProveIt
Commit: deefab74912eef91a2cd1ba6686589cb8964466e
Directory: docs/drafts
Archives inspected: 10
Distinct complete normalized checker sources: 16, in 140 occurrences
Current coordinate envelope: 313 tokens / 347 AST nodes / 878 bytes
Different programs attain these coordinates. The old 317/348/885 envelope
omits four current complete variants. The full source files and hashes
are included. No remote repository changes were made.

READ AND REPRODUCE
-----------------
report.pdf                  Main compiled mathematical report
report.tex, sections/       Complete editable LaTeX source
comparison/checkers/       Sixteen unchanged complete comparator sources
comparison/manifest.json    Source identities, hashes, profiles, exclusions
comparison/provenance/     Current archive identities and inherited license
code/                      New finite diagnostic and measurement scripts
evidence/                  Executed source/CLI/symbolic receipts
reviews/                   Independent proof and implementation audits
ATTRIBUTION.txt             Inherited versus new contribution boundary
SHA256SUMS                 Integrity hashes of the delivered payload

With Python 3.12, standard library only:
  python3 reproduce.py

The checks measure all 16 copied source files, replay 13 inherited cases
against 2 compatible frontier checkers (26 subprocess executions), and
verify the symbolic endpoint/depth/freshness constructions. These are
finite executable checks, not a formal verification of the metatheorems.
No Lean/Rocq formalization is claimed. Exact AST/unparser size figures
were recorded on CPython 3.12.14 and can vary with interpreter versions.

With a normal TeX installation:
  python3 build.py

The PDF build disables shell escape and needs no network. Its ordinary
LaTeX dependencies are listed at the top of report.tex.

Verify the unmodified delivered package:
  sha256sum -c SHA256SUMS

LIMITS
------
The theorem concerns uniform predicates in this one native logical
language. It does not rule out a smaller checker for that language, a
different connective, another domain, or a different bi-interpretation.
Historical priority beyond the inspected corpus has not been established.
The requested checker-size breakthrough remains open.
