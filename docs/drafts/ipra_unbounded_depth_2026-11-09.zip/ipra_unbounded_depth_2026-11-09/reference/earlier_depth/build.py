#!/usr/bin/env python3
"""Compile the complete report three times with pdfLaTeX and no shell escape."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    executable = shutil.which("pdflatex")
    if not executable:
        raise SystemExit("pdflatex is required to rebuild the included PDF")
    for _ in range(3):
        result = subprocess.run([executable, "-no-shell-escape", "-halt-on-error",
                                 "-interaction=nonstopmode", "report.tex"],
                                cwd=ROOT, capture_output=True, text=True, timeout=60)
        if result.returncode:
            print(result.stdout)
            print(result.stderr)
            raise SystemExit(result.returncode)
    print("Built report.pdf from the complete delivered TeX source.")


if __name__ == "__main__":
    main()
