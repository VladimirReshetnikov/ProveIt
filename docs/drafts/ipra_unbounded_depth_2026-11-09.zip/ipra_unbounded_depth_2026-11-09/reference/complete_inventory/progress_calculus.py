#!/usr/bin/env python3
"""Readable proof verifier for the progression/closure presentation of iPRA.

The only runtime dependencies are Python's standard library.  This is a
reference implementation, not a contender for the corpus's size record.
See README.txt for the syntax, inference rules, and trust boundary.
"""

import json
import re
import sys


class CheckError(ValueError):
    """A document fails a formation, scope, or inference check."""


def need(condition, message):
    if not condition:
        raise CheckError(message)


def name(value):
    need(type(value) is str and re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", value),
         "invalid variable name")
    return value


def parse_term(raw):
    need(type(raw) is list and bool(raw), "term must be a tagged array")
    tag = raw[0]
    if tag == "v" and len(raw) == 2:
        return ("v", name(raw[1]))
    if tag == "0" and len(raw) == 1:
        return ("0",)
    if tag == "s" and len(raw) == 2:
        return ("s", parse_term(raw[1]))
    if tag == "i" and len(raw) == 5:
        return ("i", parse_term(raw[1]), parse_term(raw[2]),
                name(raw[3]), parse_term(raw[4]))
    raise CheckError("malformed numerical term")


def parse_formula(raw):
    need(type(raw) is list and bool(raw), "formula must be a tagged array")
    tag = raw[0]
    if tag == "=" and len(raw) == 3:
        return ("=", parse_term(raw[1]), parse_term(raw[2]))
    if tag == "q" and len(raw) == 3:
        return ("q", name(raw[1]), parse_formula(raw[2]))
    if tag == "d" and len(raw) == 4:
        x, y = name(raw[1]), name(raw[2])
        need(x != y, "paired binders must have distinct names")
        return ("d", x, y, parse_formula(raw[3]))
    raise CheckError("malformed native formula")


def fv_term(t):
    tag = t[0]
    if tag == "v":
        return {t[1]}
    if tag == "0":
        return set()
    if tag == "s":
        return fv_term(t[1])
    return fv_term(t[1]) | fv_term(t[2]) | (fv_term(t[4]) - {t[3]})


def fv_formula(f):
    if f[0] == "=":
        return fv_term(f[1]) | fv_term(f[2])
    if f[0] == "q":
        return fv_formula(f[2]) - {f[1]}
    return fv_formula(f[3]) - {f[1], f[2]}


def names_term(t):
    if t[0] == "v":
        return {t[1]}
    if t[0] == "0":
        return set()
    if t[0] == "s":
        return names_term(t[1])
    return names_term(t[1]) | names_term(t[2]) | {t[3]} | names_term(t[4])


def names_formula(f):
    if f[0] == "=":
        return names_term(f[1]) | names_term(f[2])
    if f[0] == "q":
        return {f[1]} | names_formula(f[2])
    return {f[1], f[2]} | names_formula(f[3])


def fresh_name(avoid):
    index = 0
    while "_fresh" + str(index) in avoid:
        index += 1
    return "_fresh" + str(index)


def subst_term(t, variable, replacement):
    """Capture-avoiding substitution in a parsed term."""
    tag = t[0]
    if tag == "v":
        return replacement if t[1] == variable else t
    if tag == "0":
        return t
    if tag == "s":
        return ("s", subst_term(t[1], variable, replacement))
    _, counter, seed, bound, body = t
    counter = subst_term(counter, variable, replacement)
    seed = subst_term(seed, variable, replacement)
    if bound == variable or variable not in fv_term(body):
        return ("i", counter, seed, bound, body)
    if bound in fv_term(replacement):
        renamed = fresh_name(names_term(body) | names_term(replacement) | {variable, bound})
        body = subst_term(body, bound, ("v", renamed))
        bound = renamed
    return ("i", counter, seed, bound, subst_term(body, variable, replacement))


def subst_formula(f, variable, replacement):
    """Capture-avoiding substitution in a parsed formula."""
    if f[0] == "=":
        return ("=", subst_term(f[1], variable, replacement),
                subst_term(f[2], variable, replacement))
    bounds = list(f[1:-1])
    body = f[-1]
    if variable in bounds or variable not in fv_formula(body):
        return f
    avoid = names_formula(body) | names_term(replacement) | set(bounds) | {variable}
    for index, bound in enumerate(bounds):
        if bound in fv_term(replacement):
            renamed = fresh_name(avoid)
            avoid.add(renamed)
            body = subst_formula(body, bound, ("v", renamed))
            bounds[index] = renamed
    return (f[0], *bounds, subst_formula(body, variable, replacement))


def subst_many_formula(f, replacements):
    """Simultaneous substitution; replacements are never substituted into."""
    avoid = names_formula(f) | set(replacements)
    for term in replacements.values():
        avoid |= names_term(term)
    holes = {}
    for variable in replacements:
        temporary = fresh_name(avoid)
        avoid.add(temporary)
        holes[variable] = temporary
        f = subst_formula(f, variable, ("v", temporary))
    for variable, temporary in holes.items():
        f = subst_formula(f, temporary, replacements[variable])
    return f


def _variable_key(variable, bound):
    for distance, candidate in enumerate(reversed(bound)):
        if variable == candidate:
            return ("bound", distance)
    return ("free", variable)


def _term_key(t, bound):
    if t[0] == "v":
        return _variable_key(t[1], bound)
    if t[0] == "0":
        return ("0",)
    if t[0] == "s":
        return ("s", _term_key(t[1], bound))
    return ("i", _term_key(t[1], bound), _term_key(t[2], bound),
            _term_key(t[4], bound + (t[3],)))


def _formula_key(f, bound=()):
    if f[0] == "=":
        return ("=", _term_key(f[1], bound), _term_key(f[2], bound))
    if f[0] == "q":
        return ("q", _formula_key(f[2], bound + (f[1],)))
    return ("d", _formula_key(f[3], bound + (f[1], f[2])))


def alpha_equal(left, right):
    return _formula_key(left) == _formula_key(right)


def _same(actual, expected, where):
    need(alpha_equal(actual, expected), where + ": conclusion mismatch")


def _fields(node, expected):
    need(type(node) is dict and set(node) == set(expected), "incorrect proof fields")


def _context_fv(context):
    answer = set()
    for formula in context:
        answer |= fv_formula(formula)
    return answer


def verify(node, context):
    """Reconstruct a proof under an immutable parsed context; return its goal."""
    need(type(node) is dict and "rule" in node and "goal" in node,
         "proof node needs rule and goal")
    rule = node["rule"]
    need(type(rule) is str, "rule name must be a string")
    goal = parse_formula(node["goal"])
    common = {"rule", "goal"}

    if rule == "hyp":
        _fields(node, common | {"index"})
        index = node["index"]
        need(type(index) is int and 0 <= index < len(context), "invalid hypothesis index")
        _same(goal, context[index], "hypothesis")

    elif rule in {"i0", "is"}:
        _fields(node, common)
        need(goal[0] == "=" and goal[1][0] == "i", "computation needs an iterator equation")
        _, counter, seed, bound, body = goal[1]
        if rule == "i0":
            need(counter[0] == "0", "I0 counter is not zero")
            expected = ("=", goal[1], seed)
        else:
            need(counter[0] == "s", "IS counter is not a successor")
            previous = ("i", counter[1], seed, bound, body)
            expected = ("=", goal[1], subst_term(body, bound, previous))
        _same(goal, expected, "computation")

    elif rule == "di":
        _fields(node, common | {"witness", "fresh", "step"})
        need(goal[0] == "d", "DI conclusion must have a paired root")
        _, x, y, matrix = goal
        witness = parse_term(node["witness"])
        eigen = name(node["fresh"])
        forbidden = _context_fv(context) | fv_term(witness) | (fv_formula(matrix) - {x, y})
        need(eigen not in forbidden, "DI eigenvariable is not fresh")
        at = ("v", eigen) if matrix[0] == "=" else ("0",)
        assumption = subst_many_formula(matrix, {x: witness, y: at})
        successor = subst_many_formula(matrix, {x: witness, y: ("s", ("v", eigen))})
        _same(verify(node["step"], context + (assumption,)), successor, "DI step")

    elif rule in {"qe0", "qep"}:
        _fields(node, common | {"major", "minor", "target"})
        major = verify(node["major"], context)
        need(major[0] == "q", "QE major must have a unary closure root")
        _, bound, matrix = major
        target = parse_term(node["target"])
        if rule == "qep":
            need(matrix[0] == "=", "QE+ requires a literal equation matrix")
            source_term, result_term = target, ("s", target)
        else:
            source_term, result_term = ("0",), target
        _same(verify(node["minor"], context), subst_formula(matrix, bound, source_term), "QE minor")
        _same(goal, subst_formula(matrix, bound, result_term), "QE goal")

    elif rule == "de":
        _fields(node, common | {"major", "fresh", "step"})
        major = verify(node["major"], context)
        need(major[0] == "d", "DE major must have a paired root")
        _, x, y, matrix = major
        eigen = name(node["fresh"])
        forbidden = _context_fv(context) | fv_formula(goal) | (fv_formula(matrix) - {x, y})
        need(eigen not in forbidden, "DE eigenvariable is not fresh")
        assumption = subst_formula(("q", y, matrix), x, ("v", eigen))
        _same(verify(node["step"], context + (assumption,)), goal, "DE continuation")

    elif rule == "tr":
        _fields(node, common | {"equality", "minor", "var", "motive"})
        equality = verify(node["equality"], context)
        need(equality[0] == "=", "transport major must be an equation")
        variable = name(node["var"])
        motive = parse_formula(node["motive"])
        _same(verify(node["minor"], context), subst_formula(motive, variable, equality[1]),
              "transport source")
        _same(goal, subst_formula(motive, variable, equality[2]), "transport target")

    else:
        raise CheckError("unknown inference rule")
    return goal


def verify_document(document):
    _fields(document, {"context", "proof"})
    need(type(document["context"]) is list, "context must be an array")
    context = tuple(parse_formula(raw) for raw in document["context"])
    return verify(document["proof"], context)


def main():
    try:
        verify_document(json.load(sys.stdin))
    except Exception:
        print("REJECT")
        return 1
    print("ACCEPT")
    return 0


if __name__ == "__main__":
    sys.exit(main())
