#!/usr/bin/env python3
"""Standalone proof checker for shifted closed-unary arithmetic U.

The complete trusted implementation is this file and Python's standard library.
It checks full intuitionistic first-order natural deduction, equality, K0/KS,
Boolean range BR, the falsity bridge F, and literal-equation induction.
No evaluator, theorem table, imported producer, or external prover is trusted.
"""
import json
import sys


class Invalid(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


def variable(name):
    return ["v", name]


def zero():
    return ["0"]


def successor(term):
    return ["K", zero(), term, variable("$")]


def delta(term):
    return ["K", term, zero(), zero()]


def eq(left, right):
    return ["eq", left, right]


def user_name(name):
    require(type(name) is str and bool(name) and name != "$",
            "Expected a nonempty variable name other than reserved '$'.")


def term(t, names):
    require(type(t) is list and bool(t), "Malformed term.")
    if t[0] == "0":
        require(len(t) == 1, "Malformed zero.")
    elif t[0] == "v":
        require(len(t) == 2 and type(t[1]) is str and t[1] in names,
                "Unbound numerical variable.")
    elif t[0] == "K":
        require(len(t) == 4, "K needs count, seed, and closed unary update.")
        term(t[1], names)
        term(t[2], names)
        term(t[3], {"$"})
    else:
        raise Invalid("Unknown term constructor.")
    return t


def formula(a, names):
    require(type(a) is list and bool(a), "Malformed formula.")
    if a[0] == "bot":
        require(len(a) == 1, "Malformed falsity.")
    elif a[0] == "eq":
        require(len(a) == 3, "Equality needs two terms.")
        term(a[1], names)
        term(a[2], names)
    elif a[0] in ("and", "or", "imp"):
        require(len(a) == 3, "Binary connective needs two formulas.")
        formula(a[1], names)
        formula(a[2], names)
    elif a[0] in ("all", "ex"):
        require(len(a) == 3, "Quantifier needs a name and formula.")
        user_name(a[1])
        formula(a[2], names | {a[1]})
    else:
        raise Invalid("Unknown formula constructor.")
    return a


def term_free(t):
    if t[0] == "0":
        return set()
    if t[0] == "v":
        return {t[1]}
    return term_free(t[1]) | term_free(t[2])


def free(a):
    if a[0] == "bot":
        return set()
    if a[0] == "eq":
        return term_free(a[1]) | term_free(a[2])
    if a[0] in ("all", "ex"):
        return free(a[2]) - {a[1]}
    return free(a[1]) | free(a[2])


def all_names(a):
    if a[0] in ("all", "ex"):
        return {a[1]} | all_names(a[2])
    if a[0] in ("and", "or", "imp"):
        return all_names(a[1]) | all_names(a[2])
    return free(a)


def fresh(avoid):
    i = 0
    while "_v" + str(i) in avoid:
        i += 1
    return "_v" + str(i)


def substitute_term(t, name, image):
    if t[0] == "v":
        return image if t[1] == name else t
    if t[0] == "0":
        return t
    return ["K", substitute_term(t[1], name, image),
            substitute_term(t[2], name, image), t[3]]


def substitute(a, name, image):
    """Capture-avoiding numerical substitution; fixed update indices stay closed."""
    if a[0] == "bot":
        return a
    if a[0] == "eq":
        return eq(substitute_term(a[1], name, image),
                  substitute_term(a[2], name, image))
    if a[0] in ("and", "or", "imp"):
        return [a[0], substitute(a[1], name, image),
                substitute(a[2], name, image)]
    tag, bound, body = a
    if bound == name:
        return a
    if bound in term_free(image) and name in free(body):
        renamed = fresh(all_names(body) | term_free(image) | {name, bound})
        body = substitute(body, bound, variable(renamed))
        bound = renamed
    return [tag, bound, substitute(body, name, image)]


def canonical_term(t, binders):
    if t[0] == "v":
        name = t[1]
        return ("bound", binders.index(name)) if name in binders else ("free", name)
    if t[0] == "0":
        return ("0",)
    return ("K", canonical_term(t[1], binders), canonical_term(t[2], binders),
            canonical_term(t[3], ("$",)))


def canonical(a, binders=()):
    if a[0] == "bot":
        return ("bot",)
    if a[0] == "eq":
        return ("eq", canonical_term(a[1], binders), canonical_term(a[2], binders))
    if a[0] in ("all", "ex"):
        return (a[0], canonical(a[2], (a[1],) + binders))
    return (a[0], canonical(a[1], binders), canonical(a[2], binders))


def same(left, right):
    return canonical(left) == canonical(right)


# Each rule lists its complete non-premise fields and exact premise count.
RULES = {
    "hyp": ({"index"}, 0), "refl": ({"term"}, 0),
    "transport": ({"var", "body"}, 2), "bot_e": ({"as"}, 1),
    "and_i": (set(), 2), "and_e": ({"side"}, 1),
    "or_i": ({"side", "other"}, 1), "or_e": (set(), 3),
    "imp_i": ({"assume"}, 1), "imp_e": (set(), 2),
    "all_i": ({"var"}, 1), "all_e": ({"term"}, 1),
    "ex_i": ({"var", "body", "term"}, 1), "ex_e": ({"var"}, 2),
    "K0": ({"seed", "update"}, 0), "KS": ({"count", "seed", "update"}, 0),
    "BR": ({"term"}, 0), "F": (set(), 0),
    "EI": ({"var", "left", "right", "at"}, 2),
}


def infer(node, context=(), names=frozenset()):
    require(type(node) is dict and type(node.get("rule")) is str,
            "Proof node needs a rule name.")
    rule = node["rule"]
    require(rule in RULES, "Unknown rule.")
    fields, count = RULES[rule]
    require(set(node) == fields | {"rule", "premises"}, "Wrong rule fields.")
    ps = node["premises"]
    require(type(ps) is list and len(ps) == count, "Wrong premise count.")

    def premise(i, retained=context, ambient=names):
        return infer(ps[i], retained, ambient)

    def new_variable():
        x = node["var"]
        user_name(x)
        require(x not in names, "Eigenvariable/template name is not fresh.")
        return x

    if rule == "hyp":
        i = node["index"]
        require(type(i) is int and 0 <= i < len(context), "Invalid hypothesis index.")
        result = context[i]
    elif rule == "refl":
        t = term(node["term"], names)
        result = eq(t, t)
    elif rule == "transport":
        x = new_variable()
        body = formula(node["body"], names | {x})
        equality = premise(0)
        require(equality[0] == "eq", "Transport major must be an equation.")
        require(same(premise(1), substitute(body, x, equality[1])),
                "Transport source does not match its motive.")
        result = substitute(body, x, equality[2])
    elif rule == "bot_e":
        require(premise(0) == ["bot"], "Falsity elimination needs falsity.")
        result = formula(node["as"], names)
    elif rule == "and_i":
        result = ["and", premise(0), premise(1)]
    elif rule == "and_e":
        major = premise(0)
        side = node["side"]
        require(major[0] == "and" and type(side) is int and side in (0, 1),
                "Conjunction projection needs side 0 or 1.")
        result = major[side + 1]
    elif rule == "or_i":
        side = node["side"]
        require(type(side) is int and side in (0, 1), "Disjunction needs side 0 or 1.")
        pair = [premise(0), formula(node["other"], names)]
        result = ["or"] + (pair if side == 0 else pair[::-1])
    elif rule == "or_e":
        major = premise(0)
        require(major[0] == "or", "Disjunction elimination needs a disjunction.")
        result = premise(1, context + (major[1],))
        require(same(result, premise(2, context + (major[2],))),
                "Disjunction branches have different conclusions.")
    elif rule == "imp_i":
        antecedent = formula(node["assume"], names)
        result = ["imp", antecedent, premise(0, context + (antecedent,))]
    elif rule == "imp_e":
        major = premise(0)
        require(major[0] == "imp" and same(major[1], premise(1)),
                "Implication antecedent mismatch.")
        result = major[2]
    elif rule == "all_i":
        x = new_variable()
        result = ["all", x, premise(0, context, names | {x})]
    elif rule == "all_e":
        major = premise(0)
        require(major[0] == "all", "Universal elimination needs a universal formula.")
        result = substitute(major[2], major[1], term(node["term"], names))
    elif rule == "ex_i":
        x = node["var"]
        user_name(x)
        result = formula(["ex", x, node["body"]], names)
        witness = term(node["term"], names)
        require(same(premise(0), substitute(result[2], x, witness)),
                "Existential witness instance mismatch.")
    elif rule == "ex_e":
        major = premise(0)
        require(major[0] == "ex", "Existential elimination needs an existential formula.")
        x = new_variable()
        local = substitute(major[2], major[1], variable(x))
        result = premise(1, context + (local,), names | {x})
        require(x not in free(result), "Existential eigenvariable escapes.")
    elif rule in ("K0", "KS"):
        seed = term(node["seed"], names)
        update = term(node["update"], {"$"})
        if rule == "K0":
            result = eq(["K", zero(), seed, update], successor(seed))
        else:
            n = term(node["count"], names)
            previous = ["K", n, seed, update]
            result = eq(["K", successor(n), seed, update],
                        substitute_term(update, "$", previous))
    elif rule == "BR":
        n = term(node["term"], names)
        result = ["or", eq(delta(n), zero()), eq(delta(n), successor(zero()))]
    elif rule == "F":
        result = ["imp", eq(zero(), successor(zero())), ["bot"]]
    elif rule == "EI":
        x = new_variable()
        left = term(node["left"], names | {x})
        right = term(node["right"], names | {x})
        target = term(node["at"], names)
        matrix = eq(left, right)
        require(same(premise(0), substitute(matrix, x, zero())),
                "Equation-induction base mismatch.")
        step = premise(1, context + (matrix,), names | {x})
        require(same(step, substitute(matrix, x, successor(variable(x)))),
                "Equation-induction successor mismatch.")
        result = substitute(matrix, x, target)
    else:
        raise Invalid("Unimplemented rule.")
    return formula(result, names)


def verify(packet):
    require(type(packet) is dict and set(packet) == {"goal", "proof"},
            "Packet must have exactly goal and proof.")
    goal = formula(packet["goal"], set())
    conclusion = infer(packet["proof"])
    require(same(goal, conclusion), "Proof conclusion differs from the closed goal.")
    return True


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON object field.")
        result[key] = value
    return result


def reject_constant(value):
    raise Invalid("Nonfinite JSON numeric constant: " + value)


def main():
    try:
        packet = json.load(sys.stdin, object_pairs_hook=unique_object,
                           parse_constant=reject_constant)
        verify(packet)
    except (Invalid, ValueError, TypeError, KeyError, IndexError, RecursionError,
            MemoryError, OverflowError) as error:
        print("REJECT: " + str(error), file=sys.stderr)
        return 1
    print("ACCEPT")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
