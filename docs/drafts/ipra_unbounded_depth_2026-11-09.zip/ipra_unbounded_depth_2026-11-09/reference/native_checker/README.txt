NATIVE CHECKER REFINEMENTS -- 9 NOVEMBER 2026

checker.py is the smaller iterable-tree implementation: 306 normalized
tokens / 340 AST nodes / 859 normalized bytes, using the inherited whole
source metric on CPython 3.12.14. It differs from baseline.py only by
deleting `+ []` from the substitution comprehension (docstrings aside).

This changes the accepted JSON syntax. At traversed syntax positions,
the empty string and empty object denote []; an object whose sole key is
the empty string denotes [[]], with its associated value ignored. Read
checker_refinement.tex for the successful-trace soundness argument and
the explicit counterexample to naive packetwise normalization.

RESOURCE QUALIFICATION: Nonempty strings reject through CPython's finite
recursion guard. An idealization with an unrestricted stack would diverge
on such malformed inputs. Canonical array/numeric inputs retain structural
descent and the exact old behavior. The new syntax extension therefore
cannot be described as an all-input-equivalent removal of a redundant
validation guard. All actual CLI verdicts tested are ordinary CPython ones.

strict_checker.py retains the array-only guard and has exactly the old
all-input behavior under ordinary adequate-resource execution. It measures
308 tokens / 341 AST nodes / 894 bytes. It improves two coordinates but
does NOT beat the old byte minimum. Read strict_refinement.tex.

These are implementation refinements of the inherited native iPRA calculus.
They do not implement the new arithmetic construction in the main report.
Their soundness uses the existing native-calculus metatheory; the code and
tests are not a new Lean/Rocq verification of full bi-interpretability.

Reproduce the main result and all packaged CLI tests:
  python3 verify_checker.py

The script writes checker_validation.json. It runs both ordinary and
optimized Python on 147 inherited positive certificates, 13 public CLI
cases, explicit failed-major probes, alias and malformed cases, and the
known counterexample to deleting the initial substitution validation.
It also compares 1500 canonical mutation traces and checks the local alias
substitution law. Finite tests supplement the written proof.

Origin: ProveIt docs/drafts/ipra_package_reconstructed.zip, member
ipra_reset_2026-11-08/code/complete_kernel.py, at repository snapshot
e707d8bd1bcbc036631663e7538efd8b42b1e130. The untouched baseline, fixture
files, inherited source normalizer, and license are packaged here.

The supporting source_measure.py is imported only by the verification
script, never by either measured standalone proof checker.
