"""Self-contained supporting checks for the iterable-tree native verifier.

The only inputs are packaged files. This script is not the measured kernel.
Its regression tests do not replace the successful-trace soundness argument.
"""
import ast
import copy
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'baseline.py'
NEW = ROOT / 'checker.py'
STRICT = ROOT / 'strict_checker.py'
spec = importlib.util.spec_from_file_location('measure', ROOT / 'source_measure.py')
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def tree(source):
    return measure.StripDocstrings().visit(ast.parse(source))


def load(path):
    parsed = ast.parse(path.read_text())
    require(isinstance(parsed.body[-1], ast.Try), 'CLI driver is not the final block')
    parsed.body.pop()
    ns = {}
    exec(compile(parsed, str(path), 'exec'), ns)
    return ns


def evaluate(ns, packet):
    packet = copy.deepcopy(packet)
    ns['k'] = 0
    try:
        ns['q'] = packet.pop
        accepted = bool(ns['c'](ns['q'](), []))
    except BaseException:
        accepted = False
    return accepted, ns['k'], packet


def cli(job):
    path, data, optimized, accepted, name = job
    command = [sys.executable] + (['-O'] if optimized else []) + [str(path)]
    p = subprocess.run(command, input=data, text=True, capture_output=True, timeout=10)
    expected = ('ACCEPT\n', '', 0) if accepted else ('REJECT\n', '', 1)
    got = (p.stdout, p.stderr, p.returncode)
    require(got == expected, repr((path.name, name, optimized, got, expected)))
    return True


def all_paths(value, path=()):
    yield path
    if isinstance(value, list):
        for i, child in enumerate(value):
            yield from all_paths(child, path + (i,))


def replace(value, path, new):
    if not path:
        return copy.deepcopy(new)
    result = copy.deepcopy(value)
    target = result
    for index in path[:-1]:
        target = target[index]
    target[path[-1]] = copy.deepcopy(new)
    return result


def main():
    original = BASE.read_text()
    old_tree = tree(original)
    expected_source = original.replace('for b in a + []', 'for b in a')
    require(expected_source != original, 'Expected original comprehension not found')
    require(ast.dump(tree(expected_source)) == ast.dump(tree(NEW.read_text())), 'Unlisted executable change')
    old_block = '''        if [] in (h := [0, m[2:]]):
            u = t
            try:
                t, = m
            except:
                s, u = m
            return i(t, u) == a and c(i(t, s), g)'''
    new_block = '''        u = t
        try:
            try:
                t, = m
            except:
                s, u = m
        except:
            h = [0, m[2:]]
        else:
            return i(t, u) == a and c(i(t, s), g)'''
    require(old_block in original, 'Expected old dispatch block not found')
    require(ast.dump(tree(original.replace(old_block, new_block))) == ast.dump(tree(STRICT.read_text())), 'Unlisted strict-guard change')
    metrics = {p.name: measure.metrics(p) for p in [BASE, NEW, STRICT]}
    fields = ['normalized_tokens', 'ast_nodes', 'normalized_bytes']
    require(tuple(metrics[BASE.name][x] for x in fields) == (309, 344, 864), 'Baseline metric mismatch')
    require(tuple(metrics[NEW.name][x] for x in fields) == (306, 340, 859), 'Candidate metric mismatch')
    require(tuple(metrics[STRICT.name][x] for x in fields) == (308, 341, 894), 'Strict-guard metric mismatch')

    fixtures = json.loads((ROOT / 'positive_fixtures.json').read_text())['records']
    public = json.loads((ROOT / 'cli_cases.json').read_text())['cases']
    supplemental = [
        ('failed_major_then_zero_computation', [[0, 0], [[[0, 0, 0], [0]], 0], [[0, 0, 0], 0]], True),
        ('failed_major_then_introduction', [[0, 0], [[[0, 0, 0], [0]], [0]], [0, 0, [0, 0]]], True),
        ('canonical_false', [[0, 0], [0, [0]]], False),
        ('false_computation', [[0, 0], [[0, 0, 0], [0]]], False),
        ('known_initial_validation_attack', [[0, [0]], [[0, 0, [], [0]], 0], [[], [0]]], False),
        ('overlong_goal', [[0, 0], [0, 0, 0, 0]], False),
    ]
    arbitrary_values = [0, None, 'ignored', {'arbitrary': [None, True, 'x']}, [1, 2, 3]]
    aliases = [('', ''), ('empty_map', {})] + [('one_key_' + str(j), {'': v}) for j, v in enumerate(arbitrary_values)]
    extension_cases = []
    for name, value in aliases:
        extension_cases.append(('alias_computation_' + name, [[0, 0], [[0, value, 0], value]], True))
    for name, bad in [('nonempty_string', 'x'), ('long_string', 'abc'), ('nonempty_key', {'x': 0}), ('two_keys', {'': 0, 'x': 0})]:
        extension_cases.append(('rejected_' + name, [[0, 0], [[0, bad, 0], bad]], False))
    # A raw inequality can disappear after alias normalization. A failed-major
    # branch must therefore be translated as a trace, not by replacing the packet.
    packetwise_counterexample = [[0, 0], [[[0, '', 0], []], 0], [[0, 0, 0], 0]]
    normalized_counterexample = [[0, 0], [[[0, [], 0], []], 0], [[0, 0, 0], 0]]
    extension_cases.append(('packetwise_counterexample', packetwise_counterexample, True))

    jobs = []
    for record in fixtures:
        for path in [BASE, NEW, STRICT]:
            for optimized in [False, True]:
                jobs.append((path, json.dumps(record['packet']), optimized, True, record['name']))
    for record in public:
        for path in [BASE, NEW, STRICT]:
            for optimized in [False, True]:
                jobs.append((path, record['input_text'], optimized, record['expected_accept'], record['name']))
    for name, packet, accepted in supplemental:
        for path in [BASE, NEW, STRICT]:
            for optimized in [False, True]:
                jobs.append((path, json.dumps(packet), optimized, accepted, name))
    for name, packet, accepted in extension_cases:
        for optimized in [False, True]:
            jobs.append((NEW, json.dumps(packet), optimized, accepted, name))
    jobs += [(BASE, json.dumps(normalized_counterexample), mode, False, 'normalized_fallback_counterexample') for mode in [False, True]]
    for data in ['', '[] []', '"x"', '{}', 'null']:
        for optimized in [False, True]:
            jobs.append((NEW, data, optimized, False, 'parser_' + repr(data)))
    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(cli, jobs))

    old, new, strict = load(BASE), load(NEW), load(STRICT)
    rng = random.Random(11092026)
    replacements = [0, 1, -1, -2, 2, 3, [], [0], [0, 0], [0, 0, 0], [0, 0, 0, 0]]
    for _ in range(1500):
        packet = rng.choice(fixtures)['packet']
        packet = replace(packet, rng.choice(list(all_paths(packet))), rng.choice(replacements))
        require(evaluate(old, packet) == evaluate(new, packet) == evaluate(strict, packet), 'Canonical trace mismatch')

    malformed_replacements = [None, False, True, -1, 0, 1, 0.5, '', 'x', {}, {'': 0}, {'x': 0}, [], [0], [0, 0, 0, 0]]
    for _ in range(1500):
        packet = rng.choice(fixtures)['packet']
        packet = replace(packet, rng.choice(list(all_paths(packet))), rng.choice(malformed_replacements))
        require(evaluate(old, packet) == evaluate(strict, packet), 'Strict-guard noncanonical trace mismatch')

    # The exact local alias law is tested at every scope offset reached by the
    # numerical/formula grammar, with several replacement values and floors.
    local_checks = 0
    for floor in [0, -1, -3]:
        for depth in range(-1, 10):
            for replacement in [None, 0, [0], [0, 0], [0, 0, 0]]:
                for name, value in aliases:
                    normal = [[]] if isinstance(value, dict) and value else []
                    old['k'] = new['k'] = floor
                    actual = new['i'](value, replacement, depth)
                    expected = old['i'](normal, replacement, depth)
                    require(actual == expected, 'Local alias substitution mismatch')
                    local_checks += 1

    receipt = {
        'python': platform.python_version(),
        'complete_source_metrics': metrics,
        'exact_executable_edit': 'Delete only + [] from the substitution comprehension.',
        'canonical_trace_equivalence': 'Structural induction on arrays and ordinary numeric leaves; regression below.',
        'whole_json_language_equivalence_claimed': False,
        'positive_fixtures': len(fixtures),
        'public_cli_cases': len(public),
        'supplemental_cases': len(supplemental),
        'explicit_extension_cases': len(extension_cases),
        'cli_runs_normal_and_optimized': len(jobs),
        'canonical_mutation_trace_checks': 1500,
        'strict_guard_noncanonical_trace_checks': 1500,
        'local_alias_substitution_checks': local_checks,
        'packetwise_normalization_counterexample': {'candidate_packet': packetwise_counterexample, 'normalized_packet': normalized_counterexample, 'candidate_accepts': True, 'baseline_normalized_rejects': True},
        'relevant_source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [BASE, NEW, STRICT, ROOT/'positive_fixtures.json', ROOT/'cli_cases.json', ROOT/'source_measure.py']},
        'all_checks_passed': True,
        'scope': 'Whole-source measurement, CLI tests, and local alias checks. Full logical soundness relies on the written successful-trace extension of the inherited native-calculus theorem.',
    }
    (ROOT / 'checker_validation.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k: v for k, v in receipt.items() if k not in ['complete_source_metrics', 'packetwise_normalization_counterexample', 'relevant_source_sha256']}, indent=2))


if __name__ == '__main__':
    main()
