CLOSED ITERATION AND THE EQUATIONAL CONTENT OF iPRA
=================================================
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date).

START WITH report.pdf. The complete editable source is report.tex together
with sections/*.tex and results/current_table.tex.

STATUS
------
The requested strict reduction below the complete-checker frontier is NOT
established. The current inherited coordinate minima are 317 normalized
tokens / 348 AST nodes / 885 normalized bytes, attained by different
programs. No new full checker is presented as a record.

MATHEMATICAL RESULTS
--------------------
1. Fixed closed unary initialized iteration, with its two computation
   equations and literal-equation induction, internally constructs
   predecessor, pairing with both projections, and every fixed primitive-
   recursive operation. Boolean range, numerical coverage, falsity,
   order, and quantifier-free induction are unnecessary for that bootstrap.

2. The key new pairing invariant is the literal equation
       c(x,y) = Sx + d(c(x,y),Sx).
   Its explicit slack replaces the previous order argument.

3. Completing the theory with Boolean range and the falsity bridge is
   conservative for positive Horn conclusions from positive assumptions.
   The report gives exact formula grammars, a partial-cut proof, quotient
   gluing, and counterexamples to removing the restrictions. For equation
   contexts and equation conclusions, the proof can be entirely equational.

4. The completed theory is whole-domain bi-interpretable and equiconsistent
   with full intuitionistic PRA. Both composites have the internally
   definable identity graph x=y. All ordinary logical rules and nonlogical
   axioms are listed, as is the inherited four-pattern native presentation.

The numerical predecessor and projection terms, Boolean-gluing construction,
and full native basis are credited to the current drafts. The stronger
dependency reduction, shorter equational pairing argument, and uniform
conservativity theorem are new relative to the inspected collection.
Historical priority is not claimed. Pure iteration's standard-model
functional completeness is older work of Gladstone and Severin.

SOURCE BOUNDARY
---------------
Repository: VladimirReshetnikov/ProveIt
Current commit: 9773e5e0376fdaf953567d0e1e6f19570d566bc6
Directory: docs/drafts
All SIX current ZIPs were extracted and inspected. The current collection
retains TWELVE exact complete comparison programs from parent snapshot
06e097f723c659030816e0194e5eb7e8c607ba9b. Three additional experimental
programs are separately retained and measured; none lowers the frontier.
Source hashes and exact current/archive provenance accompany the report.

CONTENTS
--------
report.pdf / report.tex / sections/  Complete mathematical report and source.
verification/slack_certificate/     Separate producer and replay checker.
verification/closed_terms/          Inherited staged definitions and diagnostics.
verification/measure_current.py    Exact current program audit.
verification/measure_inherited.py  Unchanged inherited metric and source audit.
comparison/checkers/               Twelve unchanged full comparison programs.
comparison/experiments/            Three unchanged disclosed experiments.
provenance/                        Source inventory, hashes, and attribution.
results/                           Executed measurements and validation records.
reproduce.py / Makefile            Offline reproduction and PDF build.
SHA256SUMS.txt                     Integrity manifest for delivered payloads.

REPRODUCE
---------
Use Python 3.12 for the exact recorded AST/unparser metrics. The verification
scripts use the standard library and need no network.

    python3 reproduce.py

Build the paper with a normal TeX installation:

    make pdf

The article needs common packages listed in report.tex. There is no shell
escape, external bibliography processor, or network dependency.

VERIFY THE SCOPE
----------------
The symbolic replay verifies 11 universal equation theorems, 48 proof nodes,
73 explicit occurrence rewrites, and 5 literal-equation inductions relative
to exactly 24 disclosed equation schemas. All five corrupted certificates
reject. It is not a full iPRA checker and does not certify its dependencies.

The separate term diagnostics validate 13 closed staged updates, reject two
malformed updates, run nine literal predecessor evaluations (0 through 8),
and report 602 separately labelled accelerated finite cases. These finite
tests are not proofs of the universal statements or bi-interpretability.

Gluing, partial cut elimination, the full predecessor, logical reconstruction,
and bi-interpretability are written mathematical proofs. No complete Lean
or Rocq formalization is claimed. A Further research questions section
identifies the remaining checker-size and mechanization problems.
