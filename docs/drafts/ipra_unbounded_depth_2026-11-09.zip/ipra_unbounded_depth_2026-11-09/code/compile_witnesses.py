#!/usr/bin/env python3
"""Compile symbolic excluded-middle families into actual native D syntax.

This is an untrusted syntax compiler with independent output-shape checks.
It is NOT an iPRA proof checker, a realizability verifier, a jump oracle, or
a proof of the infinite depth-separation theorem. R_k is a formal name for
one fixed PR characteristic matrix, to be instantiated separately. C and
P are the inherited PR selector and predecessor abbreviations; expanding
their numerical definitions does not change formula depth.

The logical macros are inherited from the pinned clock_and_kernel report,
sections/04_equivalence.tex. The present contribution is the executable
assembly and structural verification of the new H_k / L_k witnesses.
Only Python's standard library is needed. Run from any working directory:

    python3 code/compile_witnesses.py
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


def var(name):
    return ("var", name)


ZERO = ("zero",)
ONE = ("S", ZERO)
BOTTOM = ("eq", ZERO, ONE)


def term_fv(term):
    if term[0] == "var":
        return {term[1]}
    if term[0] == "zero":
        return set()
    args = term[2:] if term[0] == "matrix" else term[1:]
    return set().union(*(term_fv(t) for t in args))


def formula_fv(formula):
    if formula[0] == "eq":
        return term_fv(formula[1]) | term_fv(formula[2])
    if formula[0] == "D":
        return formula_fv(formula[3]) - {formula[1], formula[2]}
    raise ValueError("not a native formula")


def subst_term(term, replacement):
    tag = term[0]
    if tag == "var":
        return replacement.get(term[1], term)
    if tag == "zero":
        return term
    if tag == "matrix":
        return (tag, term[1], *(subst_term(t, replacement) for t in term[2:]))
    return (tag, *(subst_term(t, replacement) for t in term[1:]))


def native_depth(formula):
    if formula[0] == "eq":
        return 0
    if formula[0] == "D":
        return 1 + native_depth(formula[3])
    raise ValueError("not a native formula")


class Compiler:
    def __init__(self):
        self.serial = 0
        self.selector_cases = {"eq_eq": 0, "D_D": 0, "eq_D": 0, "D_eq": 0}

    def fresh(self):
        name = "_v" + str(self.serial)
        self.serial += 1
        return name

    def substitute(self, formula, replacement):
        """Capture-avoiding substitution of numerical terms for free names."""
        if formula[0] == "eq":
            return ("eq", subst_term(formula[1], replacement),
                    subst_term(formula[2], replacement))
        _, x, y, body = formula
        active = {n: t for n, t in replacement.items() if n not in {x, y}}
        images = set().union(*(term_fv(t) for t in active.values()))
        if x in images or y in images:
            nx, ny = self.fresh(), self.fresh()
            body = self.substitute(body, {x: var(nx), y: var(ny)})
            x, y = nx, ny
        return ("D", x, y, self.substitute(body, active))

    def opened_body(self, formula, x, y):
        if formula[0] != "D":
            raise ValueError("expected a paired binder")
        return self.substitute(formula[3],
                               {formula[1]: var(x), formula[2]: var(y)})

    def gate(self, control, formula):
        if formula[0] == "eq":
            return ("eq", ("C", control, ZERO, formula[1]),
                    ("C", control, ZERO, formula[2]))
        _, x, y, body = formula
        if {x, y} & term_fv(control):
            nx, ny = self.fresh(), self.fresh()
            body = self.opened_body(formula, nx, ny)
            x, y = nx, ny
        return ("D", x, y, self.gate(control, body))

    def select(self, control, left, right):
        """Direct depth-preserving formula selector M_control(left,right)."""
        leq, req = left[0] == "eq", right[0] == "eq"
        if leq and req:
            self.selector_cases["eq_eq"] += 1
            return ("eq", ("C", control, left[1], right[1]),
                    ("C", control, left[2], right[2]))
        x, y = self.fresh(), self.fresh()
        if not leq and not req:
            self.selector_cases["D_D"] += 1
            a = self.opened_body(left, x, y)
            b = self.opened_body(right, x, y)
        elif leq:
            self.selector_cases["eq_D"] += 1
            a = self.gate(var(y), left)
            b = self.opened_body(right, x, y)
        else:
            self.selector_cases["D_eq"] += 1
            a = self.opened_body(left, x, y)
            b = self.gate(var(y), right)
        return ("D", x, y, self.select(control, a, b))

    def implication(self, left, right):
        unused, z = self.fresh(), self.fresh()
        return ("D", unused, z, self.select(var(z), left, right))

    def negation(self, formula):
        return self.implication(formula, BOTTOM)

    def universal(self, variable, formula):
        unused, z = self.fresh(), self.fresh()
        body = self.substitute(formula, {variable: ("P", var(z))})
        return ("D", unused, z, self.gate(var(z), body))

    def disjunction(self, left, right):
        z, y = self.fresh(), self.fresh()
        body = self.select(var(z), left, right)
        return ("D", z, y, self.gate(var(y), body))

    def family(self, k):
        if not isinstance(k, int) or isinstance(k, bool) or k < 1:
            raise ValueError("k must be a positive integer")
        xs = ["x" + str(i) for i in range(1, 2 * k + 1)]
        matrix = ("matrix", "R_" + str(k), var("n"), *(var(x) for x in xs))
        h = ("eq", matrix, ZERO)
        # Compile the pure negative translation of the Sigma_(2k) prefix:
        # every existential becomes not forall x not (...).
        for i in range(2 * k, 0, -1):
            if i % 2 == 0:
                h = self.universal(xs[i - 1], h)
            else:
                h = self.negation(self.universal(xs[i - 1], self.negation(h)))
        result = self.disjunction(h, self.negation(h))
        return h, result


def check_serialized_native(root, k, expected_depth=None, expected_free=None):
    """Independent strict reader for the emitted JSON tree, not builder ASTs."""
    seen_binders = set()
    counts = {"binders": 0, "equations": 0, "term_nodes": 0,
              "matrix_occurrences": 0}

    def term(node, bound):
        if not isinstance(node, list) or not node or not isinstance(node[0], str):
            raise ValueError("invalid numerical node")
        counts["term_nodes"] += 1
        tag = node[0]
        if tag == "var":
            if len(node) != 2 or not isinstance(node[1], str) or not node[1]:
                raise ValueError("invalid variable")
            return set() if node[1] in bound else {node[1]}
        if tag == "zero":
            if len(node) != 1:
                raise ValueError("invalid zero arity")
            return set()
        if tag in {"S", "P"}:
            if len(node) != 2:
                raise ValueError("invalid unary arity")
            return term(node[1], bound)
        if tag == "C":
            if len(node) != 4:
                raise ValueError("invalid selector arity")
            return set().union(*(term(t, bound) for t in node[1:]))
        if tag == "matrix":
            if len(node) != 2 * k + 3 or node[1] != "R_" + str(k):
                raise ValueError("invalid fixed matrix declaration or arity")
            counts["matrix_occurrences"] += 1
            return set().union(*(term(t, bound) for t in node[2:]))
        raise ValueError("unrecognized numerical constructor")

    def formula(node, bound):
        if not isinstance(node, list) or not node:
            raise ValueError("invalid formula node")
        if node[0] == "eq":
            if len(node) != 3:
                raise ValueError("invalid equality arity")
            counts["equations"] += 1
            return 0, term(node[1], bound) | term(node[2], bound)
        if node[0] != "D" or len(node) != 4:
            raise ValueError("formula must be an equation or paired binder")
        x, y = node[1:3]
        if (not isinstance(x, str) or not isinstance(y, str) or not x or not y
                or x == y or {x, y} & seen_binders):
            raise ValueError("binders must be distinct and globally fresh")
        seen_binders.update((x, y))
        counts["binders"] += 1
        depth, free = formula(node[3], bound | {x, y})
        return depth + 1, free

    depth, free = formula(root, set())
    if expected_depth is not None and depth != expected_depth:
        raise ValueError("unexpected formula depth")
    if expected_free is not None and free != set(expected_free):
        raise ValueError("unexpected free variables")
    return {"depth": depth, "free_variables": sorted(free), **counts}


def run_structural_controls():
    c = Compiler()
    n = var("n")
    atom = ("eq", n, ZERO)
    deep = c.universal("w", ("eq", var("w"), n))
    # Exercise all four selector clauses, including unequal input depths.
    for a, b in [(atom, atom), (deep, deep), (atom, deep), (deep, atom)]:
        result = c.select(var("control"), a, b)
        if native_depth(result) != max(native_depth(a), native_depth(b)):
            raise RuntimeError("selector changed maximum input depth")
        if formula_fv(result) != {"n", "control"}:
            raise RuntimeError("selector captured or leaked a name")
    if any(v == 0 for v in c.selector_cases.values()):
        raise RuntimeError("a selector clause was not exercised")
    # A deliberate capture risk forces alpha-renaming during substitution.
    x, y = c.fresh(), c.fresh()
    risk = ("D", x, y, ("eq", var("n"), var(x)))
    safe = c.substitute(risk, {"n": var(x)})
    if formula_fv(safe) != {x} or safe[1] == x:
        raise RuntimeError("capture-avoiding substitution failed")
    invalid = [
        ["D", "q", "q", ["eq", ["zero"], ["zero"]]],
        ["eq", ["C", ["zero"], ["zero"]], ["zero"]],
        ["eq", ["matrix", "R_1", ["var", "n"]], ["zero"]],
        ["eq", ["unknown"], ["zero"]],
        ["eq", ["var", "leaked"], ["zero"]],
    ]
    rejected = 0
    for bad in invalid:
        try:
            check_serialized_native(bad, 1, expected_free={"n"})
        except ValueError:
            rejected += 1
        else:
            raise RuntimeError("corrupted native syntax was accepted")
    return {"selector_cases": c.selector_cases, "capture_control": "passed",
            "corrupted_trees_rejected": rejected}


def main():
    root = Path(__file__).resolve().parents[1]
    evidence = root / "evidence"
    examples = root / "examples"
    evidence.mkdir(exist_ok=True)
    examples.mkdir(exist_ok=True)
    summaries = []
    for k in range(1, 5):
        compiler = Compiler()
        h, formula = compiler.family(k)
        h_serialized = json.loads(json.dumps(h))
        serialized = json.loads(json.dumps(formula))
        h_shape = check_serialized_native(h_serialized, k, 4 * k, {"n"})
        shape = check_serialized_native(serialized, k, 4 * k + 2, {"n"})
        if formula_fv(formula) != {"n"} or native_depth(formula) != 4 * k + 2:
            raise RuntimeError("independent reader and builder disagree")
        compact = json.dumps(serialized, separators=(",", ":")).encode()
        summary = {"k": k, "H_depth": h_shape["depth"], "L_shape": shape,
                   "claimed_upper_bound": 4 * k + 2,
                   "depth_equals_upper_bound": True,
                   "compact_formula_bytes": len(compact),
                   "compact_formula_sha256": hashlib.sha256(compact).hexdigest(),
                   "selector_cases_during_build": compiler.selector_cases}
        if k <= 2:
            packet = {
                "format": "native-D-symbolic-tree-v1",
                "k": k,
                "meaning": "L_k(n) = H_k(n) or not H_k(n)",
                "H_definition": "Negative translation of exists x1 forall x2 ... "
                                "exists x(2k-1) forall x(2k) [R_k(n,x1,...,x2k)=0]",
                "numerical_abbreviations": {
                    "C": "C(0,a,b)=a; C(Su,a,b)=b",
                    "P": "P(0)=0; P(Su)=u",
                    "matrix": "R_k is an uninterpreted placeholder for a fixed "
                              "primitive-recursive characteristic matrix, not an oracle",
                },
                "scope": "An actual native formula in abbreviated PR numerical "
                         "syntax. Structural checks do not prove logical equivalence, "
                         "jump completeness, realizability, or the separation theorem.",
                "formula": serialized,
                "structural_check": shape,
            }
            path = examples / ("witness_k" + str(k) + ".json")
            path.write_text(json.dumps(packet, indent=2) + "\n", encoding="utf-8")
            reread = json.loads(path.read_text(encoding="utf-8"))
            check_serialized_native(reread["formula"], k, 4 * k + 2, {"n"})
            summary["example_file"] = str(path.relative_to(root))
            summary["example_file_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        summaries.append(summary)
    receipt = {
        "scope": "Finite structural verification of explicit symbolic formula "
                 "witnesses. This does not mechanize the infinite mathematical "
                 "theorem and is not a complete arithmetic proof checker.",
        "matrix_status": "R_k remains a formal name for a separately fixed PR "
                         "matrix. No matrix, truth predicate, or jump oracle is evaluated.",
        "logical_macro_source": "Inherited direct G/M compiler from the supplied "
                                "ipra_clock_and_kernel_2026-11-09 archive, "
                                "sections/04_equivalence.tex",
        "families": summaries,
        "controls": run_structural_controls(),
    }
    path = evidence / "formula_witnesses.json"
    path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"families_checked": len(summaries),
                      "depths": [s["L_shape"]["depth"] for s in summaries],
                      "controls": receipt["controls"],
                      "receipt": str(path.relative_to(root))}, indent=2))


if __name__ == "__main__":
    main()
