#!/usr/bin/env python3
"""Reproduce finite artifacts and whole-source comparison measurements.

This driver does not mechanize the oracle-realizability metatheorem.
The complete native checkers and their validation suite are inherited.
"""
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'evidence'


def main():
    EVIDENCE.mkdir(exist_ok=True)
    index_path = ROOT / 'reference/complete_inventory/index.json'
    index = json.loads(index_path.read_text())
    inventory = json.loads((ROOT / index['full_inventory_receipt']).read_text())
    entries = index['entries']
    if index['source_count'] != 27 or len(entries) != 27:
        raise ValueError('The frozen inventory must contain exactly 27 complete sources')
    hashes = {entry['sha256'] for entry in entries}
    expected = {row['sha256']: row for row in inventory['programs']}
    if len(hashes) != 27 or hashes != set(expected):
        raise ValueError('The frozen source hashes differ from the current12 inventory')
    paths = [ROOT / entry['file'] for entry in entries]
    observed = set((ROOT / 'reference/complete_inventory').glob('*.py'))
    if len(set(paths)) != 27 or set(paths) != observed:
        raise ValueError('The frozen source files differ from the complete source index')
    normalizer = ROOT / index['normalizer']['file']
    if hashlib.sha256(normalizer.read_bytes()).hexdigest() != index['normalizer']['sha256']:
        raise ValueError('The inherited whole-source normalizer changed')
    spec = importlib.util.spec_from_file_location(
        'source_measure', normalizer)
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    rows = []
    for entry, path in zip(entries, paths):
        metric = measure.metrics(path)
        if metric['sha256'] != entry['sha256']:
            raise ValueError('Frozen source identity changed: ' + entry['file'])
        source_record = expected[entry['sha256']]
        for key, value in entry['expected_metrics'].items():
            if value != source_record[key] or metric[key] != value:
                raise ValueError('Whole-source metric mismatch: ' + entry['file'] + ': ' + key)
        if entry['source_occurrence'] not in source_record['occurrences']:
            raise ValueError('Source provenance differs from the full inventory: ' + entry['file'])
        rows.append({'label': entry['label'],
                     'file': str(path.relative_to(ROOT)),
                     'normalized_tokens': metric['normalized_tokens'],
                     'ast_nodes': metric['ast_nodes'],
                     'normalized_bytes': metric['normalized_bytes'],
                     'sha256': metric['sha256']})
    metric_fields = ['normalized_tokens', 'ast_nodes', 'normalized_bytes']
    minima = {field: min(row[field] for row in rows) for field in metric_fields}
    if minima != inventory['coordinate_minima']:
        raise ValueError('The measured coordinate minima differ from the current12 inventory')
    fields = ['label', 'file', *metric_fields, 'sha256']
    with (EVIDENCE / 'comparator_metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fields)
        writer.writeheader()
        writer.writerows(rows)
    metrics = {
        'python': platform.python_version(),
        'scope': ('Exactly 27 distinct sources classified as complete in the frozen current12 '
                  'inventory, including retained historical comparators. Whole files; '
                  'no core-only submetrics. Classification is inherited, not a new proof '
                  'of semantic correctness or a universal minimum.'),
        'source_index': str(index_path.relative_to(ROOT)),
        'identity_and_metrics_verified': True,
        'sources': rows,
        'coordinatewise_minima': minima,
    }
    (EVIDENCE / 'comparator_metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
    logs = []
    commands = [
        [sys.executable, str(ROOT / 'code/compile_witnesses.py')],
        [sys.executable, '-O', str(ROOT / 'code/compile_witnesses.py')],
        [sys.executable, str(ROOT / 'reference/native_checker/verify_checker.py')],
    ]
    for number, command in enumerate(commands, 1):
        process = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, timeout=180)
        name = f'reproduction_{number}.txt'
        (EVIDENCE / name).write_text(process.stdout + process.stderr)
        record = {'command': [str(Path(p).relative_to(ROOT)) if str(p).startswith(str(ROOT)) else p
                              for p in command],
                  'exit_code': process.returncode, 'log': name}
        logs.append(record)
        if process.returncode:
            (EVIDENCE / 'reproduction.json').write_text(json.dumps({'passed': False, 'runs': logs}, indent=2) + '\n')
            raise RuntimeError('Reproduction failed; inspect ' + name)
    receipt_path = ROOT / 'reference/native_checker/checker_validation.json'
    inherited = json.loads(receipt_path.read_text())
    (EVIDENCE / 'native_checker_validation.json').write_text(json.dumps(inherited, indent=2) + '\n')
    result = {'passed': True, 'python': platform.python_version(),
              'scope': 'Finite implementation/structure checks; no mechanized proof of the depth theorem.',
              'measured_files': len(rows), 'runs': logs,
              'complete_source_index': str(index_path.relative_to(ROOT)),
              'source_identity_and_metrics_verified': True,
              'formula_witnesses': 'formula_witnesses.json',
              'native_checker_receipt': 'native_checker_validation.json',
              'metrics': 'comparator_metrics.json'}
    (EVIDENCE / 'reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
