#!/usr/bin/env python3
"""Create a reproducible ZIP and verify its CRCs and payload hashes."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SKIP_SUFFIXES = {'.aux', '.log', '.toc', '.out', '.fls', '.fdb_latexmk', '.pyc'}


def main():
    payload = sorted(p for p in ROOT.rglob('*') if p.is_file()
                     and p.suffix not in SKIP_SUFFIXES
                     and '__pycache__' not in p.parts and '.texcache' not in p.parts
                     and p.name != 'MANIFEST.json')
    manifest = {'format': 1, 'files': [
        {'path': str(p.relative_to(ROOT)), 'size_bytes': p.stat().st_size,
         'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in payload]}
    mpath = ROOT / 'MANIFEST.json'
    mpath.write_text(json.dumps(manifest, indent=2) + '\n')
    archive = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in payload + [mpath]:
            info = zipfile.ZipInfo(ROOT.name + '/' + str(path.relative_to(ROOT)),
                                   date_time=(2026, 11, 9, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError('Archive CRC check failed')
        for row in manifest['files']:
            data = z.read(ROOT.name + '/' + row['path'])
            if len(data) != row['size_bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
                raise RuntimeError('Archive payload differs: ' + row['path'])
    print(json.dumps({'archive': str(archive), 'files': len(payload) + 1,
                      'size_bytes': archive.stat().st_size,
                      'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                      'crc_and_payload_verification': 'passed'}, indent=2))


if __name__ == '__main__':
    main()
