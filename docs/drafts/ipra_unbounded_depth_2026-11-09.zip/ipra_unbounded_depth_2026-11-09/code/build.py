#!/usr/bin/env python3
"""Build the complete single-file TeX and PDF, with shell escape disabled."""
import os
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def tex_environment(logs):
    """Use installed TeX; bootstrap a private format if only its cache is absent.

    The fallback is adapted from the attributed clock-and-kernel build script.
    It downloads nothing and changes no system files.
    """
    environment = os.environ.copy()
    probe = subprocess.run(['kpsewhich', 'pdflatex.fmt'], text=True,
                           capture_output=True, env=environment)
    if probe.stdout.strip():
        return environment
    cache = ROOT / '.texcache'
    trees = [Path('/usr/share/texmf'), Path('/usr/share/texlive/texmf-dist')]
    if not all(p.is_dir() for p in trees):
        raise RuntimeError('Configure the installed pdfLaTeX format before building.')
    cache.mkdir(exist_ok=True)
    environment['TEXMF'] = '{' + ','.join(map(str, [cache, *trees])) + '}'
    target = cache / 'web2c/pdftex/pdflatex.fmt'
    if not target.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        process = subprocess.run(
            ['pdftex', '-ini', '-etex', '-no-shell-escape', '-interaction=nonstopmode',
             '-halt-on-error', '-jobname=pdflatex', '-progname=pdflatex', 'pdflatex.ini'],
            cwd=cache, env=environment, text=True, capture_output=True, timeout=180)
        logs.append(process.stdout + process.stderr)
        if process.returncode:
            (ROOT / 'evidence/latex_build.txt').write_text('\n'.join(logs))
            raise RuntimeError('Local TeX format generation failed; see evidence/latex_build.txt')
        shutil.move(cache / 'pdflatex.fmt', target)
    maps = [trees[0] / 'fonts/map/dvips/lm/lm.map']
    maps += sorted((trees[1] / 'fonts/map/dvips/amsfonts').glob('*.map'))
    fontmap = cache / 'fonts/map/pdftex/local/pdftex.map'
    fontmap.parent.mkdir(parents=True, exist_ok=True)
    fontmap.write_text('\n'.join(p.read_text() for p in maps))
    return environment


def expanded(path):
    content = path.read_text(encoding='utf-8')
    content = re.sub(r'\\input\{([^}]+)\}',
                     lambda m: expanded(path.parent / m.group(1)), content)
    def listing(match):
        options, filename = match.groups()
        start = re.search(r'firstline=(\d+)', options)
        lines = (path.parent / filename).read_text().splitlines()
        if start:
            lines = lines[int(start.group(1)) - 1:]
            options = re.sub(r',?firstline=\d+,?', '', options).strip(',')
        return '\\begin{lstlisting}[' + options + ']\n' + '\n'.join(lines) + '\n\\end{lstlisting}'
    return re.sub(r'\\lstinputlisting\[([^\]]*)\]\{([^}]+)\}', listing, content)


def main():
    source = ROOT / 'ipra_unbounded_depth.tex'
    source.write_text(expanded(ROOT / 'report.tex'), encoding='utf-8')
    executable = shutil.which('pdflatex')
    if not executable:
        raise RuntimeError('pdflatex is required; the compiled PDF is already included.')
    logs = []
    environment = tex_environment(logs)
    command = [executable, '-no-shell-escape', '-interaction=nonstopmode',
               '-halt-on-error', source.name]
    for _ in range(3):
        process = subprocess.run(command, cwd=ROOT, env=environment,
                                 text=True, capture_output=True, timeout=180)
        logs.append(process.stdout + process.stderr)
        if process.returncode:
            (ROOT / 'evidence/latex_build.txt').write_text('\n'.join(logs))
            raise RuntimeError('LaTeX failed; see evidence/latex_build.txt')
    (ROOT / 'evidence/latex_build.txt').write_text('\n'.join(logs))
    last_log = source.with_suffix('.log').read_text()
    if 'There were undefined references' in last_log or 'undefined citations' in last_log:
        raise RuntimeError('The final LaTeX pass has unresolved references.')
    print(source.with_suffix('.pdf'))


if __name__ == '__main__':
    main()
