UNBOUNDED INTUITIONISTIC DEPTH AT CLASSICAL DEPTH ZERO
Research prepared for Vladimir Reshetnikov, 9 November 2026

MAIN RESULT
===========
For each k >= 1 there is an arithmetic formula L_k(n) with

  classical standard-truth-set native depth: 0
  HA-provable-equivalence native depth: at least k+1
  iPRA-provable-equivalence native depth: between k+1 and 4k+2.

The native binder is D_(x,y) B = exists x (B(x,0) -> forall y B(x,y)).
Take a purely negative H_k whose standard truth set is Sigma^0_(2k)-complete,
and put L_k = H_k or not H_k. Every L_k instance is classically true.
An equivalent shallow native formula would supply oracle realizers with
too little computational power to decide H_k, a contradiction.

This answers the explicit fixed-classical-level depth-gap question in the
archived ipra_intuitionistic_depth_2026-11-08 report. The novelty claim is
relative to the supplied corpus. Literature-wide priority is not established.

STATUS OF THE USER'S LARGER OBJECTIVE
===================================
No new axiomatization below the complete-checker frontier is established.
Formula depth is not checker source length. The complete native basis and
compact checkers here are inherited, attributed comparison material.
The new positive result is a mathematical representation obstruction.

READ FIRST
==========
ipra_unbounded_depth.pdf    Complete report.
ipra_unbounded_depth.tex    Complete standalone editable LaTeX source.
report.tex                 Modular source for reproducible assembly.
depth_theorem.tex           Main new proof.
stability_obstruction.tex   Simpler restriction on negative-only grammars.
CLAIMS.json                Explicit claim/status map.
ATTRIBUTION.txt             Provenance and contribution boundaries.

REPRODUCE
=========
From the extracted package directory:

  python3 code/reproduce.py
  python3 code/build.py
  python3 code/package.py

The first command requires Python's standard library only. Its exact source
normalization baseline is CPython 3.12.14. The second requires a functioning
pdfLaTeX installation with the ordinary packages listed in the source; shell
escape is disabled. The compiled PDF is included. The third recreates the
manifest and ZIP, verifies every payload SHA-256 and all ZIP CRCs, and omits
transient TeX files and Python bytecode.
If the installed Linux TeX distribution lacks a generated pdfLaTeX format,
the builder can generate a private local format using installed files;
it changes no system files and downloads nothing.

VERIFICATION SCOPE
==================
The main lower-bound theorem is a written proof with two independent
assistant audits. It is not a Lean/Rocq formalization or external peer review.

code/compile_witnesses.py implements the inherited finite native formula
macros for the new family. It checks actual symbolic formulas at k=1,2,3,4,
including their depths, scopes, and capture avoidance. R_k is a formal name
for a separately chosen primitive-recursive jump matrix. The script neither
evaluates that matrix nor implements any noncomputable oracle. The finite
checks do not prove the infinite separation theorem.

reference/native_checker contains unchanged complete reference checkers and
their original validation suite. Their accepted language, aliases, resource
qualifications and soundness arguments are described in that directory.
They are distinct from the formula compiler and the new metatheorem.

reference/closed_equational and reference/clock_and_kernel preserve the
attributed full native arithmetic construction and its refinements.
reference/earlier_depth preserves the previous depth theorem and the exact
open question addressed by the new result.

reference/complete_inventory contains the 27 distinct sources classified as
complete in the current archives, with exact original paths and identities.
The reproduction driver checks all 27 hashes and their whole-source metrics.
The literal coordinate minima 306 tokens, 340 AST nodes and 839 bytes are
attained by different programs. Excluding the iterable-alias implementation
gives coordinate minima 307/341/839, again from different files. Uniform
identifier shortening is a separate control, not a foundational result.

evidence/source_snapshot.json records all twelve current archives pinned at
ProveIt commit 572c3ef372fb22e30951af30bf1041efcffc8b7d.
evidence/earlier_depth_source.json records the separate archived source.
The repository was only read; no changes were submitted.

LIMITS TO KEEP IN VIEW
=====================
The lower bound fixes the native formula grammar, its ordinary decoding,
and numerical terms denoting primitive-recursive functions. It does not
exclude other connectives, domain changes or arbitrary bi-interpretations.
It does not prove an exact minimum depth for the family, a universal source-
size lower bound, or a smaller complete axiomatization. Both interpretation
round trips remain required for any future positive simplification.
