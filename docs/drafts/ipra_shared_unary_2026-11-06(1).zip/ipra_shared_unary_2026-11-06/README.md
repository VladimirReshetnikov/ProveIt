# A smaller complete checker for intuitionistic primitive recursive arithmetic

This package gives a complete axiomatization and executable certificate checker
for **full first-order iPRA**, with quantifier-free induction. It is a synthesis
of the six proposals in Vladimir Reshetnikov's ProveIt repository at commit
`9e338a5c51a26ac6ae90f2d8f563a44c3879ba68`.

The complete checker has **865 Python AST nodes, 829 significant tokens,
2,621 normalized bytes, and 2,865 original bytes**. Each count is below the
corresponding minimum among the six supplied main implementations:
915 nodes, 863 tokens, 2,730 normalized bytes, and 3,088 original bytes.
This is an empirical improvement over the pinned comparison set, not an
absolute minimality theorem.

## Read the mathematics

`report.pdf` is the compiled article. `report.tex` and `sections/` are its complete
LaTeX sources. The report specifies all syntax, logical rules, nonlogical schemas,
and the falsity convention; derives full intuitionistic logic; proves recovery
of quantifier-free induction; and gives whole-domain bi-interpretations with
internally definable identity isomorphisms.

The mathematical basis, especially unary existence and formula amalgamation,
comes from the supplied unary-existential draft. The implementation combines
that basis with a typed finite-prefix substitution traversal, a scope table,
shared introduction code, and a direct zero-substitution for the numerical base.
The inherited ideas are attributed explicitly in the article.

## Check a certificate

Use Python 3.10 or later. There are no third-party Python dependencies.

```bash
python3 checker.py examples/equation_induction_addition.json
```

The checker prints `ACCEPT` and exits 0 on acceptance; otherwise it prints
`REJECT` and exits 1 for the handled invalid-input and resource-limit cases.
The input is `[context, goal, proof]`. The full acceptance implementation is
`checker.py`; no other file is imported apart from standard `json` and `sys`.

## Reproduce the evidence

```bash
python3 reproduce.py
```

This reruns the four size measurements, independent binding and inference audit,
matched controls, and 362 actual CLI regression invocations. It requires neither
network access nor the original draft archives.

Individual commands are:

```bash
python3 measure.py
python3 validation/audit_candidate.py --output results/independent_audit.json
python3 validation/verify_controls.py
python3 validation/run_regression.py
```

`results/metrics.json` records whole-program measurements. Its AST and normalized
source results were produced with Python 3.12.14; different Python versions may
format `ast.unparse` differently. The report's mathematical strength and the
checker interface do not depend on those formatting choices.

The independent audit includes 1,372 named-syntax substitution comparisons,
23 independent numerical-axiom constructions, 25 positive certificates,
198 adversarial certificates, and six additional CLI boundary cases.
It does not reuse the checker's substitution routine as its oracle.

The regression fixtures preserve the predecessor's expected sequents and labels.
One intentionally noncanonical Boolean hypothesis key is replaced by its actual
context formula; its original bytes are retained as an additional negative case.
The change is documented and hashed in `validation/fixtures/provenance.json`.
All 60 original negative fixtures remain unmodified. The source metadata file
is historical provenance, not a claim that the predecessor's separate tests
were rerun by this package.

`comparison/baselines/` contains six verbatim complete checker sources and their
provenance. `comparison/controls/` contains complete same-interface alternatives
that separate validation from substitution or split the introduction branches.
`comparison/support_inventory.json` records 269 Python files with both `infer`
and `check` definitions, representing 98 distinct source hashes. This inventory
does not certify all included programs as sound or complete. To repeat that
optional inventory, obtain the six original archives at the pinned commit,
extract each beneath a directory named by its ZIP stem, and run:

```bash
python3 measure.py --inventory /path/to/extracted_archives
```

## Rebuild the article

Install a standard pdfLaTeX distribution with the packages named in `report.tex`.
Then run:

```bash
python3 build.py
# Or all verification plus the PDF:
python3 reproduce.py --pdf
```

The build runs three LaTeX passes and rejects unresolved references or overfull
boxes. Final page layout was also visually inspected. Temporary TeX output goes
into `build/`; the deliverable is copied to `report.pdf`.

## Scope of verification

The general equivalence and bi-interpretation results are mathematical proofs
in the article. The program has structural soundness arguments and finite
executable validation; this package does not claim a Lean or Rocq formalization.
Python and its JSON parser are the shared runtime trust base. Very deep valid
proof trees can encounter Python's recursion or memory limits; resource
rejection is not evidence that the mathematical sequent is unprovable.
