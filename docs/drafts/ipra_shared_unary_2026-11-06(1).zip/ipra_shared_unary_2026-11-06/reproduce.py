"""Reproduce all delivered checker measurements and audits, without network access."""

import argparse
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true", help="also compile report.tex with pdfLaTeX")
    args = parser.parse_args()
    (ROOT / "results").mkdir(exist_ok=True)
    commands = [
        ["measure.py"],
        ["validation/audit_candidate.py", "--output", "results/independent_audit.json"],
        ["validation/verify_controls.py"],
        ["validation/run_regression.py"],
    ]
    if args.pdf:
        commands.append(["build.py"])
    for command in commands:
        print("Running " + " ".join(command), flush=True)
        subprocess.run([sys.executable, *command], cwd=ROOT, check=True)
    print("All requested reproduction steps passed.")


if __name__ == "__main__":
    main()
