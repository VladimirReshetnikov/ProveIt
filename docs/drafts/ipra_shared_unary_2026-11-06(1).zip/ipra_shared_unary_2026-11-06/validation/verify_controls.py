"""Compare the matched controls against the candidate on supplied JSON fixtures.

This is a finite regression check, not a proof of checker soundness.
"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def accepts(module, certificate):
    try:
        return module.check(certificate) is True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixtures", type=Path, default=ROOT / "validation" / "fixtures" / "inherited")
    parser.add_argument("--checker", type=Path,
                        default=ROOT / ("checker_candidate.py" if
                                        (ROOT / "checker_candidate.py").exists() else "checker.py"))
    parser.add_argument("--controls", type=Path, default=ROOT / "comparison" / "controls")
    parser.add_argument("--output", type=Path, default=ROOT / "results" / "controls.json")
    args = parser.parse_args()
    candidate = load(args.checker)
    paths = sorted(args.controls.glob("*.py"))
    controls = {path.name: load(path) for path in paths}
    records = []
    for path in sorted(args.fixtures.glob("*.json")):
        data = path.read_bytes()
        certificate = json.loads(data)
        expected = accepts(candidate, certificate)
        actual = {name: accepts(module, certificate) for name, module in controls.items()}
        records.append({"fixture": path.name, "sha256": hashlib.sha256(data).hexdigest(),
                        "candidate_accepts": expected, "control_acceptance": actual})
        if any(value != expected for value in actual.values()):
            raise AssertionError(records[-1])
    result = {
        "candidate_sha256": hashlib.sha256(args.checker.read_bytes()).hexdigest(),
        "control_sha256": {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                           for path in paths},
        "fixture_count": len(records),
        "candidate_accepts": sum(record["candidate_accepts"] for record in records),
        "candidate_rejects": sum(not record["candidate_accepts"] for record in records),
        "disagreements": 0,
        "records": records,
        "qualification": "Finite comparisons only; the mathematical argument is stated separately.",
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "records"}, indent=2))


if __name__ == "__main__":
    main()
