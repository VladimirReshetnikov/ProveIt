"""Run frozen proof certificates through the actual checker command line.

Usage, from any directory:
    python3 /path/to/package/validation/run_regression.py

No proof generator or candidate inference function supplies expected results.
The labels and stated sequents come from frozen predecessor fixtures. One
documented hypothesis-key normalization is stored alongside its original.
Only the Python standard library is needed; use Python 3.10 or later.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "validation" / "fixtures"
CHECKER = ROOT / "checker.py"
OUTPUT = ROOT / "results" / "regression.json"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    # Assertions are intentionally avoided: this harness also works with -O.
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def inspect_inventory():
    manifest = read_json(FIXTURES / "manifest.json")
    provenance = read_json(FIXTURES / "provenance.json")
    metadata_bytes = (FIXTURES / provenance["source_metadata_copy"]).read_bytes()
    require(digest(metadata_bytes) == provenance["source_metadata_sha256"],
            "source metadata hash mismatch")
    original = json.loads(metadata_bytes)
    original_by_name = {row["name"]: row for row in original["certificates"]}
    records = manifest["certificates"]
    require(len(original_by_name) == 176, "unexpected predecessor inventory")
    require(len(records) == 177, "unexpected current inventory")
    require(len({row["name"] for row in records}) == len(records),
            "duplicate fixture name")
    require(sum(row["accepted"] is True for row in records) == 116,
            "unexpected positive count")
    require(sum(row["accepted"] is False for row in records) == 61,
            "unexpected negative count")
    require(len(manifest["malformed_json"]) == 4,
            "unexpected malformed JSON inventory")

    inherited = [row for row in records if row["file"].startswith("inherited/")]
    require(len(inherited) == 176, "missing inherited fixture")
    require({row["source_name"] for row in inherited} == set(original_by_name),
            "predecessor labels are not preserved one-to-one")
    unchanged = 0
    normalized = []
    for row in records + manifest["malformed_json"]:
        require(type(row["accepted"]) is bool, "non-Boolean expected label")
        path = FIXTURES / row["file"]
        require(path.resolve().is_relative_to(FIXTURES.resolve()),
                "fixture path outside fixture directory")
        data = path.read_bytes()
        require(len(data) == row["bytes"] and digest(data) == row["sha256"],
                "fixture hash or size mismatch: " + row["name"])
        if row in inherited:
            source = original_by_name[row["source_name"]]
            require(row["accepted"] is source["accepted"],
                    "changed inherited acceptance label: " + row["name"])
            require(row["source_sha256"] == source["sha256"],
                    "changed source provenance: " + row["name"])
            if row["transformation"] == "none":
                require(row["sha256"] == source["sha256"],
                        "changed supposedly unmodified fixture: " + row["name"])
                unchanged += 1
            else:
                require(row["transformation"] == "hypothesis_key_normalization",
                        "unrecognized fixture modification")
                normalized.append(row)

    require(unchanged == 175 and len(normalized) == 1,
            "unexpected number of modified predecessor fixtures")
    changed = normalized[0]
    require(changed["source_name"] == "stored_hypothesis_boolean_alias",
            "the modified fixture is not the documented alias case")
    source_record = next(row for row in records
                         if row["name"] == "reject_original_boolean_alias_key")
    require(source_record["accepted"] is False, "alias must be rejected")
    require(source_record["sha256"] == changed["source_sha256"],
            "original alias bytes were not preserved")
    source_data = read_json(FIXTURES / source_record["file"])
    require(type(source_data[2][1][1]) is bool,
            "original key is not the recorded Boolean alias")
    source_data[2][1] = source_data[0][0]
    expected_normalized_bytes = (
        json.dumps(source_data, separators=(",", ":"), ensure_ascii=True) + "\n"
    ).encode()
    require(expected_normalized_bytes == (FIXTURES / changed["file"]).read_bytes(),
            "normalization altered more than the hypothesis lookup key")

    examples = read_json(FIXTURES / "examples_manifest.json")["examples"]
    for row in examples:
        data = (ROOT / "examples" / row["file"]).read_bytes()
        require(digest(data) == row["sha256"], "example hash mismatch")
        require(data == (FIXTURES / row["source_fixture"]).read_bytes(),
                "example differs from its tested fixture")
    return manifest, provenance, len(examples)


def run_one(record, optimized):
    flags = ["-O"] if optimized else []
    command = [sys.executable, *flags, str(CHECKER),
               str(FIXTURES / record["file"])]
    expected_code, expected_text = ((0, "ACCEPT\n") if record["accepted"]
                                    else (1, "REJECT\n"))
    try:
        result = subprocess.run(command, capture_output=True, text=True,
                                timeout=30, check=False)
        passed = (result.returncode == expected_code
                  and result.stdout == expected_text and result.stderr == "")
        outcome = {"returncode": result.returncode, "stdout": result.stdout,
                   "stderr": result.stderr, "passed": passed}
    except (OSError, subprocess.TimeoutExpired) as error:
        outcome = {"passed": False, "error": str(error)}
    return outcome


def main():
    manifest, provenance, example_count = inspect_inventory()
    outcomes = []
    for record in manifest["certificates"] + manifest["malformed_json"]:
        outcomes.append({
            "name": record["name"], "file": record["file"],
            "category": record["category"], "sha256": record["sha256"],
            "expected_accept": record["accepted"],
            "normal": run_one(record, False),
            "optimized": run_one(record, True),
        })
    failures = [row["name"] for row in outcomes
                if not row["normal"]["passed"] or not row["optimized"]["passed"]]
    categories = sorted({row["category"] for row in manifest["certificates"]})
    result = {
        "status": "passed" if not failures else "failed",
        "python_version": platform.python_version(),
        "checker_sha256": digest(CHECKER.read_bytes()),
        "harness_sha256": digest(Path(__file__).read_bytes()),
        "manifest_sha256": digest((FIXTURES / "manifest.json").read_bytes()),
        "source_repository": provenance["source_repository"],
        "source_commit": provenance["source_commit"],
        "source_archive_sha256": provenance["source_archive_sha256"],
        "source_metadata_sha256": provenance["source_metadata_sha256"],
        "unchanged_predecessor_positive_certificates": 115,
        "normalized_predecessor_positive_certificates": 1,
        "unchanged_predecessor_negative_certificates": 60,
        "additional_original_alias_negative_certificates": 1,
        "positive_certificates": 116,
        "negative_certificates": 61,
        "certificate_cli_invocations": 354,
        "malformed_json_files": 4,
        "malformed_json_cli_invocations": 8,
        "total_cli_invocations": len(outcomes) * 2,
        "normal_and_optimized_python": True,
        "byte_identical_example_copies": example_count,
        "categories": {c: sum(row["category"] == c for row in manifest["certificates"])
                       for c in categories},
        "expected_goal_policy": "Every goal and context is frozen in its input certificate. The harness neither imports candidate inference nor regenerates goals.",
        "qualification": "Finite CLI regression evidence. The inherited source reports independent proof expansion; this harness does not rerun that expansion or claim formal verification.",
        "failures": failures,
        "outcomes": outcomes,
    }
    OUTPUT.parent.mkdir(exist_ok=True)
    OUTPUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items()
                      if key != "outcomes"}, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
