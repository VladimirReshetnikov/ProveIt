"""Measure whole proof-checker programs without executing them.

Run with no arguments beside checker.py, comparison/baselines/,
and comparison/controls/. Optional --inventory scans the extracted baseline archives and
records every Python source containing both an infer and a check definition.
"""

import argparse
import ast
import copy
import hashlib
import io
import json
import platform
from pathlib import Path
import tokenize


ROOT = Path(__file__).resolve().parent
IGNORED_TOKENS = {
    tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
    tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
}


def docstring_statements(tree):
    containers = (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
    for node in ast.walk(tree):
        if isinstance(node, containers) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                yield first


def without_docstrings(tree):
    tree = copy.deepcopy(tree)
    statements = {id(node) for node in docstring_statements(tree)}
    for node in ast.walk(tree):
        if hasattr(node, "body") and isinstance(node.body, list):
            node.body = [item for item in node.body if id(item) not in statements]
    return tree


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    parsed = ast.parse(source, filename=str(path))
    stripped = without_docstrings(parsed)
    ranges = [((node.lineno, node.col_offset), (node.end_lineno, node.end_col_offset))
              for node in docstring_statements(parsed)]
    significant = [token for token in tokenize.generate_tokens(io.StringIO(source).readline)
                   if token.type not in IGNORED_TOKENS]
    non_doc_tokens = [token for token in significant
                      if not any(start <= token.start and token.end <= end
                                 for start, end in ranges)]
    normalized = (ast.unparse(stripped) + "\n").encode("utf-8")
    return {
        "sha256": hashlib.sha256(data).hexdigest(),
        "source_bytes": len(data),
        "ast_nodes": sum(1 for _ in ast.walk(stripped)),
        "tokens": len(non_doc_tokens),
        "normalized_bytes": len(normalized),
        "ast_nodes_with_docstrings": sum(1 for _ in ast.walk(parsed)),
        "tokens_with_docstrings": len(significant),
        "normalized_sha256": hashlib.sha256(normalized).hexdigest(),
    }


def row(path, base, kind):
    return {"kind": kind, "path": str(path.relative_to(base)), **measure(path)}


def inventory(directory):
    records = []
    for path in sorted(directory.rglob("*.py")):
        parsed = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        definitions = {node.name for node in ast.walk(parsed)
                       if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
        if {"infer", "check"} <= definitions:
            relative = path.relative_to(directory)
            records.append({
                "archive": relative.parts[0] + ".zip",
                "member": str(Path(*relative.parts[1:])),
                "path": str(relative),
                **measure(path),
            })
    return records


def lower_envelope(records):
    fields = ("source_bytes", "ast_nodes", "tokens", "normalized_bytes")
    return {field: min(record[field] for record in records) for field in fields}


def main():
    default_checker = ROOT / "checker_candidate.py"
    if not default_checker.exists():
        default_checker = ROOT / "checker.py"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path, default=default_checker)
    parser.add_argument("--baselines", type=Path, default=ROOT / "comparison" / "baselines")
    parser.add_argument("--controls", type=Path, default=ROOT / "comparison" / "controls")
    parser.add_argument("--inventory", type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "results" / "metrics.json")
    parser.add_argument("--inventory-output", type=Path,
                        default=ROOT / "comparison" / "support_inventory.json")
    args = parser.parse_args()

    candidate = {"kind": "candidate", "path": args.checker.name, **measure(args.checker)}
    baselines = [row(path, args.baselines, "baseline")
                 for path in sorted(args.baselines.glob("*.py"))]
    controls = [row(path, args.controls, "control")
                for path in sorted(args.controls.glob("*.py"))]
    if len(baselines) != 6:
        raise ValueError("Expected exactly the six primary baseline programs")
    envelope = lower_envelope(baselines)
    result = {
        "python_version": platform.python_version(),
        "definitions": {
            "source_bytes": "Original complete UTF-8 file, including comments and docstrings.",
            "ast_nodes": "All ast.walk nodes, including contexts, after removing docstrings.",
            "tokens": "Python tokens excluding docstrings, comments, whitespace, and end marker.",
            "normalized_bytes": "UTF-8 bytes of ast.unparse(docstring-stripped AST) plus newline.",
            "scope": "The entire program, including validation, axiom construction and CLI.",
        },
        "candidate": candidate,
        "baselines": baselines,
        "controls": controls,
        "baseline_lower_envelope": envelope,
        "candidate_strictly_below_every_primary_metric": {
            field: candidate[field] < value for field, value in envelope.items()
        },
        "control_deltas_over_candidate": {
            control["path"]: {field: control[field] - candidate[field] for field in envelope}
            for control in controls
        },
    }
    if args.inventory is not None:
        records = inventory(args.inventory)
        hashes = {record["sha256"] for record in records}
        support = {
            "criterion": "Python sources defining both infer and check anywhere in their AST.",
            "source_files": len(records),
            "distinct_sha256": len(hashes),
            "lower_envelope": lower_envelope(records),
            "records": records,
        }
        args.inventory_output.write_text(json.dumps(support, indent=2) + "\n", encoding="utf-8")
        result["support_inventory_summary"] = {
            key: value for key, value in support.items() if key != "records"
        }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
