"""Compile report.tex with pdfLaTeX and record the build outcome."""

import json
import os
from pathlib import Path
import re
import shutil
import subprocess


ROOT = Path(__file__).resolve().parent


def main():
    engine = shutil.which("pdflatex")
    if engine is None:
        raise SystemExit("Install pdfLaTeX (for example, TeX Live) to build the report.")
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    (ROOT / "results").mkdir(exist_ok=True)
    environment = dict(os.environ)
    environment["SOURCE_DATE_EPOCH"] = "1794003993"
    environment["FORCE_SOURCE_DATE"] = "1"
    command = [engine, "-interaction=nonstopmode", "-halt-on-error",
               "-file-line-error", "-output-directory=build", "report.tex"]
    for number in range(3):
        result = subprocess.run(command, cwd=ROOT, env=environment,
                                capture_output=True, text=True, check=False)
        (build / f"pass_{number + 1}.txt").write_text(result.stdout + result.stderr)
        if result.returncode:
            raise SystemExit(result.stdout[-8000:] + result.stderr)
    log = (build / "report.log").read_text(errors="replace")
    diagnostics = [line for line in log.splitlines()
                   if "Overfull" in line or "undefined" in line.lower()
                   or "LaTeX Warning" in line or "Package hyperref Warning" in line]
    if diagnostics:
        raise SystemExit("Resolve TeX diagnostics before delivery:\n" + "\n".join(diagnostics))
    shutil.copy2(build / "report.pdf", ROOT / "report.pdf")
    match = re.search(r"Output written on .*?\((\d+) pages", log)
    status = {"engine": "pdfLaTeX", "passes": 3, "success": True,
              "pages": int(match.group(1)) if match else None,
              "diagnostics": diagnostics}
    (ROOT / "results" / "latex.json").write_text(json.dumps(status, indent=2) + "\n")
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()
