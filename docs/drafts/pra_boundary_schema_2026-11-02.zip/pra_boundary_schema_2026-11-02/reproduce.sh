#!/usr/bin/env bash
set -eu
PRA_PACKAGE_ROOT=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
cd "$PRA_PACKAGE_ROOT"
python3 verification/mask_counts.py > verification/mask_counts.run.txt
python3 verification/boundary_counts.py > verification/boundary_counts.run.txt
python3 verification/finite_checks.py > verification/finite_checks.run.txt
PRA_LEAN_BIN=${PRA_LEAN_BIN:-lean}
"$PRA_LEAN_BIN" --version
"$PRA_LEAN_BIN" verification/Boundary.lean > verification/Boundary.compiler.txt
pdflatex -interaction=nonstopmode -halt-on-error report.tex > verification/latex-pass-1.txt
pdflatex -interaction=nonstopmode -halt-on-error report.tex > verification/latex-pass-2.txt
echo 'All executable checks and both LaTeX passes completed.'
