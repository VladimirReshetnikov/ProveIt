"""Exact formula-tree accounting for the three-occurrence PRA boundary schema.

Imports the tiny AST from mask_counts.py. The finite corpus exercises the
implementation; the identities in the paper follow by structural counting.
"""
from __future__ import annotations

import json
from pathlib import Path

from mask_counts import (
    Node, app, atom, eq, quantify, q, z, succ, substitute, size,
)


x, a, n, b, c = map(atom, ("x", "a", "n", "b", "c"))
zero = atom("0")
one = succ(zero)
bottom = atom("bottom")


def boundary(formula: Node) -> Node:
    at_n = substitute(formula, {"x": n})
    at_b = substitute(formula, {"x": b})
    at_c = substitute(formula, {"x": c})
    body = app(
        "and", app("implies", at_b, at_n),
        app("or", eq(b, zero), app("and", eq(b, succ(c)), at_c)),
    )
    return quantify("forall_a forall_n exists_b exists_c", body)


def selector(condition: Node, at_zero: Node, at_positive: Node) -> Node:
    # The exact Q/Z abbreviation used by the raw-mask drafts.
    return q(z(condition, succ(at_zero)), at_positive)


def truth_term(formula: Node, mode: str) -> Node:
    if formula.tag == "bottom":
        return zero
    if formula.tag == "=":
        return app("chi", *formula.children)
    left = truth_term(formula.children[0], mode)
    right = truth_term(formula.children[1], mode)
    if mode == "raw_selector":
        if formula.tag == "and":
            return selector(left, zero, right)
        if formula.tag == "or":
            return selector(left, right, one)
        if formula.tag == "implies":
            return selector(left, one, right)
    elif mode == "marked_boolean":
        if formula.tag == "and":
            return q(q(left, one), right)
        if formula.tag == "or":
            return q(q(left, q(right, one)), one)
        if formula.tag == "implies":
            return q(q(right, left), one)
    raise ValueError((formula.tag, mode))


def count_active_x(node: Node) -> int:
    return (int(node.tag == "x" and not node.children)
            + sum(count_active_x(child) for child in node.children))


def ordinary_induction(formula: Node) -> Node:
    at_zero = substitute(formula, {"x": zero})
    at_x = formula
    at_sx = substitute(formula, {"x": succ(x)})
    at_n = substitute(formula, {"x": n})
    step = quantify("forall_x", app("implies", at_x, at_sx))
    conclusion = quantify("forall_n", at_n)
    return quantify("forall_a", app("implies", app("and", at_zero, step), conclusion))


def main() -> None:
    basic = eq(x, a)
    frozen = q(z(atom("v"), succ(atom("w"))), atom("w"))
    call = app("R", x, a, descriptor=frozen)
    atoms = [bottom, basic, eq(succ(x), zero), eq(call, a)]
    formulas = list(atoms)
    for connective in ["and", "or", "implies"]:
        for left in atoms:
            for right in atoms:
                formulas.append(app(connective, left, right))
    formulas += [
        app("implies", app("and", eq(call, a), app("implies", basic, bottom)),
            app("or", eq(x, zero), eq(succ(x), a))),
        eq(app("R", call, call, descriptor=frozen), call),
    ]
    records = []
    for index, formula in enumerate(formulas):
        m, t = formula.active, formula.full
        result = boundary(formula)
        assert size(result) == [3 * m + 15, 3 * t + 15]
        ordinary = ordinary_induction(formula)
        occurrences = count_active_x(formula)
        assert size(ordinary) == [4 * m + occurrences + 6, 4 * t + occurrences + 6]
        modes = {}
        for mode in ["raw_selector", "marked_boolean"]:
            truth = truth_term(formula, mode)
            assert truth.active >= m
            assert truth.full >= t
            old_active = truth.active + 20
            old_full = 4 * truth.full + 22
            saving = old_full - result.full
            assert saving >= t + 7
            modes[mode] = {
                "truth_term": size(truth),
                "favorable_old_unfused_W12_module": [old_active, old_full],
                "full_saving": saving,
            }
        records.append({
            "case": index, "formula": [m, t], "boundary": size(result),
            "ordinary_induction": size(ordinary), "compilers": modes,
        })
    report = {
        "scope": "Syntax counting only; not a mathematical proof checker",
        "number_of_cases": len(records),
        "formula_identity": ["3m+15", "3T+15"],
        "full_mask_envelope_lower_bound": "4T+22",
        "uniform_full_saving_lower_bound": "T+7",
        "comparison_domain": (
            "A fixed formula in a shared earlier arithmetic language and the "
            "explicit unoptimized truth compilers in the inspected drafts. "
            "No claim about shortest semantically equivalent formulas, every "
            "raw serializer address, or coordinatewise active-size domination."
        ),
        "cases": records,
    }
    output = Path(__file__).with_name("boundary_counts.json")
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "cases"}, indent=2))
    print("Atomic equality case: " + json.dumps(records[1], sort_keys=True))


if __name__ == "__main__":
    main()
