import Lean

/-!
Semantic kernels for the boundary presentation of PRA.

This file checks the logical implication from the boundary schema to
induction and an explicit primitive-recursive witness scan over Nat.
It does not formalize the generated first-order syntax, all primitive-
recursive program translations, or the full bi-interpretability theorem.
-/

namespace PRABoundary

universe u

def Boundary {α : Type u} (zero : α) (succ : α → α)
    (predicate : α → Prop) (target : α) : Prop :=
  ∃ boundary predecessor,
    (predicate boundary → predicate target) ∧
    (boundary = zero ∨
      (boundary = succ predecessor ∧ predicate predecessor))

theorem boundary_implies_induction {α : Type u}
    (zero : α) (succ : α → α) (predicate : α → Prop)
    (witness : ∀ target, Boundary zero succ predicate target)
    (base : predicate zero)
    (step : ∀ x, predicate x → predicate (succ x)) :
    ∀ target, predicate target := by
  intro target
  obtain ⟨boundary, predecessor, transfer, support⟩ := witness target
  apply transfer
  cases support with
  | inl atZero =>
      rw [atZero]
      exact base
  | inr fromPredecessor =>
      rw [fromPredecessor.1]
      exact step predecessor fromPredecessor.2

def scan (predicate : Nat → Prop) [DecidablePred predicate] : Nat → Nat × Nat
  | 0 => (0, 0)
  | Nat.succ n =>
      if predicate n then (Nat.succ n, n) else scan predicate n

theorem scan_invariant (predicate : Nat → Prop) [DecidablePred predicate]
    (n : Nat) :
    (predicate (scan predicate n).1 → predicate n) ∧
    ((scan predicate n).1 = 0 ∨
      ((scan predicate n).1 = Nat.succ (scan predicate n).2 ∧
        predicate (scan predicate n).2)) := by
  induction n with
  | zero =>
      exact ⟨fun proof => proof, Or.inl rfl⟩
  | succ n previous =>
      by_cases good : predicate n
      · rw [scan, if_pos good]
        exact ⟨fun proof => proof, Or.inr ⟨rfl, good⟩⟩
      · rw [scan, if_neg good]
        exact ⟨fun proof => (good (previous.1 proof)).elim, previous.2⟩

theorem scan_supplies_boundary (predicate : Nat → Prop)
    [DecidablePred predicate] (target : Nat) :
    Boundary 0 Nat.succ predicate target := by
  exact ⟨(scan predicate target).1, (scan predicate target).2,
    scan_invariant predicate target⟩

/- This scalar scan is exactly e from the paper.  It freezes as soon as
the current selected value fails the predicate, and uses its ordinary
predecessor as the second boundary witness. -/

def firstBadScan (predicate : Nat → Prop) [DecidablePred predicate] : Nat → Nat
  | 0 => 0
  | Nat.succ n =>
      if predicate (firstBadScan predicate n) then
        Nat.succ n
      else firstBadScan predicate n

theorem firstBadScan_invariant (predicate : Nat → Prop)
    [DecidablePred predicate] (n : Nat) :
    (predicate (firstBadScan predicate n) → predicate n) ∧
    (firstBadScan predicate n = 0 ∨
      (firstBadScan predicate n = Nat.succ (Nat.pred (firstBadScan predicate n)) ∧
        predicate (Nat.pred (firstBadScan predicate n)))) := by
  induction n with
  | zero =>
      exact ⟨fun proof => proof, Or.inl rfl⟩
  | succ n previous =>
      by_cases good : predicate (firstBadScan predicate n)
      · rw [firstBadScan, if_pos good]
        exact ⟨fun proof => proof, Or.inr ⟨rfl, previous.1 good⟩⟩
      · rw [firstBadScan, if_neg good]
        exact ⟨fun proof => (good proof).elim, previous.2⟩

theorem firstBadScan_supplies_boundary (predicate : Nat → Prop)
    [DecidablePred predicate] (target : Nat) :
    Boundary 0 Nat.succ predicate target := by
  exact ⟨firstBadScan predicate target, Nat.pred (firstBadScan predicate target),
    firstBadScan_invariant predicate target⟩

/- A generic check of the key successor step used to recover exact native
equality from addition and truncated subtraction.  The ledger laws are
inputs here; the paper derives each with at most one induction parameter. -/

structure ArithmeticLedger (α : Type u) where
  zero : α
  succ : α → α
  pred : α → α
  add : α → α → α
  sub : α → α → α
  separation : succ zero ≠ zero
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  coverage : ∀ x, x = zero ∨ ∃ y, x = succ y
  add_zero : ∀ x, add x zero = x
  add_succ : ∀ x y, add x (succ y) = succ (add x y)
  succ_add : ∀ x y, add (succ x) y = succ (add x y)
  sub_succ : ∀ x y, sub x (succ y) = pred (sub x y)
  sub_pred : ∀ x y, sub (pred x) y = pred (sub x y)
  sub_diag_succ : ∀ x, sub (succ x) x = succ zero

theorem reconstruction_step {α : Type u} (arith : ArithmeticLedger α)
    (x y : α)
    (previous : arith.sub x y = arith.zero →
      arith.add x (arith.sub y x) = y)
    (nextZero : arith.sub (arith.succ x) y = arith.zero) :
    arith.add (arith.succ x) (arith.sub y (arith.succ x)) = y := by
  have currentZero : arith.sub x y = arith.zero := by
    calc
      arith.sub x y = arith.sub (arith.pred (arith.succ x)) y := by
        rw [arith.pred_succ]
      _ = arith.pred (arith.sub (arith.succ x) y) :=
        arith.sub_pred (arith.succ x) y
      _ = arith.zero := by rw [nextZero, arith.pred_zero]
  have reconstruction := previous currentZero
  cases arith.coverage (arith.sub y x) with
  | inl remainingZero =>
      have same : x = y := by
        simpa only [remainingZero, arith.add_zero] using reconstruction
      have impossible : arith.succ arith.zero = arith.zero := by
        calc
          arith.succ arith.zero = arith.sub (arith.succ x) x :=
            (arith.sub_diag_succ x).symm
          _ = arith.zero := by simpa only [same] using nextZero
      exact (arith.separation impossible).elim
  | inr remainingSuccessor =>
      obtain ⟨rest, remaining⟩ := remainingSuccessor
      have nextSub : arith.sub y (arith.succ x) = rest := by
        rw [arith.sub_succ, remaining, arith.pred_succ]
      calc
        arith.add (arith.succ x) (arith.sub y (arith.succ x)) =
            arith.add (arith.succ x) rest := by rw [nextSub]
        _ = arith.succ (arith.add x rest) := arith.succ_add x rest
        _ = arith.add x (arith.succ rest) := (arith.add_succ x rest).symm
        _ = arith.add x (arith.sub y x) := by rw [remaining]
        _ = y := reconstruction

#print axioms boundary_implies_induction
#print axioms scan_invariant
#print axioms scan_supplies_boundary
#print axioms firstBadScan_invariant
#print axioms firstBadScan_supplies_boundary
#print axioms reconstruction_step

end PRABoundary
