Verification scope and reproduction
==================================

Lean semantic kernels
---------------------
Boundary.lean was checked with the Lean 4.19.0 release compiler:

  lean Boundary.lean

When invoking from the package root, use the actual relative path to this
file, for example `lean verification/Boundary.lean`. No Mathlib installation
is required; the file imports Lean itself. The exact successful output is
recorded in Boundary.compiler.txt. Every named theorem checked with
`#print axioms` has no axiom dependencies; the source has no sorry proof
placeholders and declares no unproved axioms.

The checked results are:

* boundary_implies_induction: On an arbitrary carrier, a boundary witness
  for every target, a base proof, and a successor-preservation proof imply
  the predicate at every target. This uses constructive logic and does not
  assume decidability or a natural-number induction principle on the carrier.

* scan_invariant and scan_supplies_boundary: An alternative primitive-
  recursive pair-valued scan produces witnesses for any decidable predicate
  on Nat. This scan looks at the predicate of the current counter.

* firstBadScan_invariant and firstBadScan_supplies_boundary: These check
  exactly the scalar selector e and invariant displayed in the paper.
  The scan tests the predicate at its currently selected value, advances to
  the next counter when true, and otherwise freezes. Its two witnesses are
  e(n) and Nat.pred(e(n)). A fixed numerical parameter in the paper is held
  fixed in the predicate supplied to these Lean theorems.

* reconstruction_step: Given the arithmetic ledger laws explicitly listed
  in the ArithmeticLedger structure, the critical successor step for
  d(x,y)=0 -> x+d(y,x)=y is valid on an arbitrary carrier. The lemma does
  not assume standard natural numbers and uses only its displayed inputs.

These are semantic kernel proofs. Lean's metavariable `predicate` is used
to state a general lemma that can be applied to each fixed formula; it is
not a predicate variable added to the proposed first-order theory.

What is not encoded in Lean:

* the entire generated first-order language and its proof calculus;
* the finite syntactic test defining all legal recursor descriptions;
* the derivations of all arithmetic ledger laws from the proposed axioms;
* the pairing construction and arbitrary finite parameter coding;
* the complete primitive-recursive compiler and effective proof translations;
* the full conservative definitional-extension or bi-interpretability theorem.

Those are proved in the paper. The Nat scan lemmas use Lean's natural-number
induction; they do not by themselves formalize derivability inside PRA.
The paper supplies the corresponding quantifier-free invariant and verifies
that each fixed predicate test and each scan is primitive recursive.

Syntax calculators
------------------
Run these from their containing directory or by their relative paths:

  python3 mask_counts.py
  python3 boundary_counts.py

The latter imports the former's AST representation. Each run writes a JSON
report alongside the script. Active size charges one node for every syntax
occurrence. Full size also recursively charges every frozen function
descriptor at every function occurrence. There is no DAG sharing.
The substitution routine changes active variable leaves only, never frozen
descriptors. The formulas used here have fresh binders and no substituted
variable can be captured; the routine is not a general-purpose bound-variable
renaming library.

mask_counts.py checks ordinary and diagonal mask witnesses, tail versus
whole-body descriptor conventions, the merged-discriminator seed, and the
one-node quantifier-factoring refinement.

boundary_counts.py checks 54 formula examples, including all connectives and
nested frozen recursion descriptions. It checks the identities 3m+15 and
3T+15, the ordinary-induction count 4T+j+6, and the lower bound for the
specific syntax-directed Boolean compilers used in the inspected drafts.

The finite cases validate the implementation of the calculators. The general
cost identities and compiler bounds follow from the structural arguments in
the paper; finite testing alone would not prove them. The comparison does not
cover semantic optimization, arbitrary sharing of earlier auxiliary masks,
or shortest proofs of individual induction instances.
