"""Exact syntax-tree counts for the inherited PRA mask workload.

This is a syntax calculation, not a proof checker.  It charges every frozen
descriptor at every generated function occurrence, with no DAG sharing.
All negations are implication to falsity.  Quantifier binders cost one node.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    tag: str
    children: tuple["Node", ...] = ()
    descriptor: "Node | None" = None

    @property
    def active(self) -> int:
        return 1 + sum(child.active for child in self.children)

    @property
    def full(self) -> int:
        return (
            1 + sum(child.full for child in self.children)
            + (self.descriptor.full if self.descriptor is not None else 0)
        )


def atom(name: str) -> Node:
    return Node(name)


def app(name: str, *args: Node, descriptor: Node | None = None) -> Node:
    return Node(name, args, descriptor)


def eq(left: Node, right: Node) -> Node:
    return app("=", left, right)


def conjunction(left: Node, right: Node) -> Node:
    return app("and", left, right)


def quantify(spec: str, body: Node) -> Node:
    for binder in reversed(spec.split()):
        body = app(binder, body)
    return body


zero = atom("0")
x, a, n, b, w, y = map(atom, ("x", "a", "n", "b", "w", "y"))


def succ(value: Node) -> Node:
    return app("S", value)


def q(left: Node, right: Node) -> Node:
    return app("Q", left, right, descriptor=w)


def z(left: Node, right: Node) -> Node:
    return app("Z", left, right, descriptor=zero)


def substitute(term: Node, replacements: dict[str, Node]) -> Node:
    # Frozen descriptors do not undergo active variable substitution.
    if not term.children and term.tag in replacements:
        return replacements[term.tag]
    return Node(
        term.tag,
        tuple(substitute(child, replacements) for child in term.children),
        term.descriptor,
    )


def mask_call(tail: Node, first: Node, second: Node, *, whole: bool) -> Node:
    descriptor = z(tail, x) if whole else tail
    return app("M", first, second, descriptor=descriptor)


def definition(tail: Node, *, whole: bool = False, closed: bool = True) -> Node:
    body = eq(mask_call(tail, n, a, whole=whole),
              z(substitute(tail, {"x": n}), n))
    return quantify("forall_a forall_n", body) if closed else body


def witness(tail: Node, *, shift: bool, diagonal: bool = False,
            whole: bool = False, closed: bool = True) -> Node:
    target = a if diagonal else n
    inner = mask_call(tail, succ(b) if shift else b, a, whole=whole)
    body = eq(mask_call(tail, q(inner, target), a, whole=whole), zero)
    prefix = "forall_a exists_b" if diagonal else "forall_a forall_n exists_b"
    return quantify(prefix, body) if closed else body


def fused(tail: Node, *, shift: bool, whole: bool = False) -> Node:
    body = conjunction(
        definition(tail, whole=whole, closed=False),
        witness(tail, shift=shift, whole=whole, closed=False),
    )
    return quantify("forall_a forall_n exists_b", body)


def size(node: Node) -> list[int]:
    return [node.active, node.full]


def check_tail(tail: Node) -> dict[str, object]:
    m, t = tail.active, tail.full
    d = definition(tail)
    assert size(d) == [8 + m, 9 + 2 * t]
    assert size(witness(tail, shift=True)) == [13, 14 + 2 * t]
    assert size(witness(tail, shift=False)) == [12, 13 + 2 * t]
    assert size(witness(tail, shift=True, diagonal=True)) == [12, 13 + 2 * t]
    assert size(witness(tail, shift=False, diagonal=True)) == [11, 12 + 2 * t]
    assert size(fused(tail, shift=True)) == [20 + m, 22 + 4 * t]
    assert size(fused(tail, shift=False)) == [19 + m, 21 + 4 * t]
    assert size(definition(tail, whole=True)) == [8 + m, 12 + 2 * t]
    assert size(witness(tail, shift=True, whole=True)) == [13, 20 + 2 * t]
    assert size(witness(tail, shift=False, whole=True)) == [12, 19 + 2 * t]
    return {
        "tail": [m, t],
        "definition_tail_stored": size(d),
        "shifted": size(witness(tail, shift=True)),
        "unshifted": size(witness(tail, shift=False)),
        "diagonal_shifted": size(witness(tail, shift=True, diagonal=True)),
        "diagonal_unshifted": size(witness(tail, shift=False, diagonal=True)),
        "fused_shifted": size(fused(tail, shift=True)),
        "fused_unshifted": size(fused(tail, shift=False)),
    }


def main() -> None:
    # Nested descriptor examples exercise the distinction between active and
    # full counts.  These are not bounds on the infinite mathematical schema.
    tails = [zero, x, a, app("chi", x, a), z(x, a), q(z(x, a), x)]
    nested = app("R_nested", x, a, descriptor=q(z(w, zero), w))
    tails += [nested, z(app("chi", nested, a), x), q(nested, succ(a))]
    records = [check_tail(tail) for tail in tails]

    off = quantify("forall_x forall_y", app("or", eq(x, y),
                   eq(app("D", x, y), zero)))
    dpart = quantify("forall_x exists_y", app("implies",
                     eq(app("D", x, zero), app("D", x, app("D", y, y))),
                     atom("bottom")))
    assert size(off) == [11, 11]
    assert size(dpart) == [13, 13]
    result = {
        "scope": "Exact AST counts; not a mathematical proof checker",
        "tail_cases": records,
        "merged_seed": {"Off": size(off), "DPart": size(dpart), "total": [24, 24]},
        "identities": {
            "fused_W13": ["20+m", "22+4T"],
            "fused_W12": ["19+m", "21+4T"],
            "current_best_unfused_W12": ["20+m", "22+4T"],
            "strict_saving_vs_unfused_W12": [1, 1],
        },
    }
    path = Path(__file__).with_name("mask_counts.json")
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
