"""Finite regression checks for the boundary witnesses and arithmetic terms.

These checks concern standard finite inputs. They are not proofs of induction,
primitive-recursive completeness, or interpretation claims in arbitrary models.
The corresponding general proofs are in report.tex, and the logical kernels
are checked separately in Boundary.lean.
"""
from __future__ import annotations

from itertools import product
import json
from pathlib import Path


def scan_checks(max_length: int = 16) -> dict[str, int]:
    patterns = states = 0
    for length in range(1, max_length + 1):
        for bits in product((False, True), repeat=length):
            patterns += 1
            candidate = 0
            for target in range(length):
                predecessor = max(candidate - 1, 0)
                transfer = not bits[candidate] or bits[target]
                boundary = candidate == 0 or (
                    candidate == predecessor + 1 and bits[predecessor]
                )
                assert transfer and boundary, (bits, target, candidate)
                states += 1
                if target + 1 < length and bits[candidate]:
                    candidate = target + 1
    return {"maximum_length": max_length, "Boolean_patterns": patterns,
            "invariant_states_checked": states}


def initialized_recursion(body, count: int, initial: int) -> int:
    value = initial
    for counter in range(count):
        value = body(value, counter)
    return value


def add(x: int, y: int) -> int:
    return initialized_recursion(lambda value, _: value + 1, y, x)


def difference(x: int, y: int) -> int:
    return initialized_recursion(lambda value, _: max(value - 1, 0), y, x)


def zero_mask(x: int, value: int) -> int:
    # Closed form of R_0, justified directly by its recursion equations.
    return value if x == 0 else 0


def equality_bit(x: int, y: int) -> int:
    return zero_mask(add(difference(x, y), difference(y, x)), 1)


def arithmetic_checks(bound: int = 24) -> dict[str, int]:
    pairs = 0
    for x in range(bound + 1):
        for y in range(bound + 1):
            assert equality_bit(x, y) == int(x == y)
            assert (difference(x, y) != 0 or
                    add(x, difference(y, x)) == y)
            assert difference(add(x, y), y) == x
            assert difference(add(x, y), x) == y
            assert difference(y, add(x, y)) == 0
            pairs += 1

    triangular = [0]
    for n in range(2 * bound + 2):
        triangular.append(add(triangular[-1], n + 1))
    max_code = triangular[2 * bound] + bound
    counter = [0]
    for z in range(max_code):
        value = counter[-1]
        next_value = add(value, equality_bit(z + 1, triangular[value + 1]))
        counter.append(next_value)

    def right(code: int) -> int:
        return difference(code, triangular[counter[code]])

    def left(code: int) -> int:
        return difference(counter[code], right(code))

    for x in range(bound + 1):
        for y in range(bound + 1):
            code = add(triangular[add(x, y)], y)
            assert left(code) == x and right(code) == y
    return {"coordinate_bound": bound, "ordered_pairs_checked": pairs,
            "largest_pair_code": max_code}


def main() -> None:
    result = {
        "scope": "Finite standard-model regression checks; not a formal proof",
        "boundary_selector": scan_checks(),
        "arithmetic_and_pairing": arithmetic_checks(),
        "status": "all assertions passed",
    }
    destination = Path(__file__).with_suffix(".json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
