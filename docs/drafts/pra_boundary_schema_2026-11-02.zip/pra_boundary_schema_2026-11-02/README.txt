PRA WITH ONE BOUNDARY SCHEMA
One fixed axiom, binary recursion, and three formula occurrences
Prepared for Vladimir Reshetnikov -- 2 November 2026

START HERE
  report.pdf  Complete mathematical paper and exact comparison.
  report.tex  Complete editable LaTeX source, with bibliography inline.
  AXIOMS.txt  The entire formal specification in plain text.

MAIN RESULT
Initial symbols are only 0,S. One uniform constructor supplies binary
initialized recursors R_h. The only fixed arithmetic axiom is 0 != S0.
For every quantifier-free A(x,a), the boundary schema is

  forall a forall n exists b exists c,
    (A(b,a) -> A(n,a)) AND (b=0 OR (b=S(c) AND A(c,a))).

This theory has a common conservative definitional extension with
first-order PRA, separately for classical and intuitionistic logic.
The interpretations use full domains and native equality; both composite
isomorphisms are identity. The complete proof includes the recovery of
an equality bit, pairing, all finite parameter tuples, and all primitive
recursive functions, without using those resources circularly.

WHAT IMPROVES
The actual six GitHub archives at commit
4d5474f10e00412135d659dc7a1f74fc6457656a were downloaded and hash-checked.
For the declared common-formula workload, a boundary instance has exact
full syntax size 3T+15. The current complete mask-module envelope is at
least 4T+22, granting the best 12-node covered witness and tail-only
descriptors. Thus the full-size saving is at least T+7. The fixed basis
falls from 24 to 6 nodes. No auxiliary mask constructor is needed.

This is NOT a claim of language-independent minimality or active-size
dominance. At A(x,a) = (x=a), the boundary costs 24 active/full nodes,
while the best mask module costs 23 active and 34 full nodes. Ordinary
induction costs only 19 for that easy example. The comparison covers
the archived uniform construction recipes, not shortest proofs of each
instance or arbitrary semantic simplification. See the paper's scope.

VERIFICATION
  verification/Boundary.lean
    Lean 4.19.0 semantic kernel checks. No Mathlib dependency.
    These check the central logical implication, explicit witness scans,
    and the equality-bootstrap step, not the entire first-order compiler
    and bi-interpretability theorem.
  verification/Boundary.compiler.txt
    Successful compiler output and theorem-axiom reports.
  verification/boundary_counts.py, boundary_counts.json
    Exact AST calculations with nested frozen descriptions; 54 predicate
    cases and the current syntactic Boolean compilers.
  verification/mask_counts.py, mask_counts.json
    Supporting AST and exact incumbent/factored-mask counts.
  verification/finite_checks.py, finite_checks.json
    Exhaustive Boolean-prefix witness checks and finite arithmetic checks.
    These are regression checks, not general mathematical proofs.
  verification/verification_log.txt
    Recorded successful build and verification summary.

REPRODUCE
Needs Python 3.10+, Lean 4.19.0, and pdflatex with the standard packages
listed in report.tex. From this directory:

  bash reproduce.sh

If Lean is not on PATH:

  PRA_LEAN_BIN=/absolute/path/to/lean bash reproduce.sh

The Python checks use only the standard library. For just the report:

  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

PROVENANCE
  provenance/source_manifest.json   Immutable source URLs and Git hashes.
  provenance/download_manifest.json SHA-256 hashes and inspected TeX paths.

The source archives themselves are not duplicated in this package.
This package creates a research deliverable; it does not change the
source GitHub repository. No global historical novelty claim is made.
