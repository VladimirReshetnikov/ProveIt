# A standalone checker for countdown uniqueness and reflection

`checker.py` is a complete standalone checker for the specified native
calculus. It imports only Python's standard `json` module. All numerical
macros used by its added rules are expanded inside the measured source.
The producer, evaluator, fixtures, and test runner are untrusted supporting
artifacts; none is imported by the checker.

The checker replaces the inherited atomic-induction choice in paired
introduction with two rules: countdown uniqueness `uw` and fixed
reflection `r2`. Paired introduction retains its base assumption only.
The full equivalence of this calculus with the ordinary presentation in
the report is a mathematical metatheorem, not a result certified by these
finite tests. In particular, the tests do not constitute a formal proof
of the native logical interpretation or arithmetic reconstruction.

## Public protocol

The input is one JSON object with exactly two fields:

```json
{"goal": ["=", 0, 0], "proof": ["tr", ["ax", ["=", ["g", ["g", 0, 0], 0], 0]], ["=", ["v", 0], 0], ["ax", ["=", ["g", ["g", 0, 0], 0], 0]]]}
```

Run `python3 checker.py < packet.json`. Acceptance prints `ACCEPT` and
exits zero. Rejection prints `REJECT` and exits nonzero. Proof instructions
are data; input is never evaluated as Python. Python's finite recursion,
memory, and JSON resource limits can reject sufficiently large valid
proofs. The code uses explicit checks, so `python3 -O` preserves them.

## Numerical syntax

| JSON form | Meaning |
|---|---|
| `0` | Numerical zero, with exact integer type |
| `["v",i]` | de Bruijn coordinate `i`, beginning at zero |
| `["p",name]` | An active, explicitly introduced eigenparameter |
| `["g",a,b]` | `G(a,b)` |
| `["j",n,h]` | `J(n;u.h)`, binding coordinate zero only in `h` |

The current number of protected coordinates and active parameter names
are validated explicitly. Booleans and floats are not numerical zero.
Nested binders use capture-avoiding shifting and opening.

Successor is the macro `S(a)=G(0,a)`. The three primitive computation
schemas are `G(Sa,b)=a`, `J(0;u.h)=0`, and
`J(Sn;u.h)=h[J(n;u.h)/u]`. An `ax` instruction checks exactly one such
step. It performs no evaluation, induction, search, or extensional test.

## Formula syntax

| JSON form | Meaning in ordinary intuitionistic logic |
|---|---|
| `["=",s,t]` | Actual numerical equality `s=t` |
| `["q",B]` | `B(0) -> forall y B(y)` |
| `["d",B]` | `exists x (B(x,0) -> forall y B(x,y))` |

For `q`, coordinate zero of its body is `y`. For `d`, coordinate zero is
`y` and coordinate one is `x`. Any outer coordinates follow these slots.

## Logical and computational instructions

The retained context is an ordered list of formulas; its entries may be
compound formulas. All numerical and formula inputs are checked in the
current parameter scope.

- `["hyp",i]` returns context entry `i`. The index must be an exact
  nonnegative integer in range.
- `["ax",E]` returns a validated instance of one primitive computation
  schema.
- `["di",D,w,name,p]` is **Case only**. `D` must be `["d",B]` and
  `name` must be fresh. Under the additional assumption `B(w,0)`, the
  premise `p` must prove `B(w,S(name))`. It returns `D`. No induction
  hypothesis is added, including when `B` is an equation. The old
  six-field `di` instructions with `step` or `case` mode are rejected.
- `["qe",p,t,q]` checks that `p` proves `["q",B]` and that `q` proves
  `B(0)`, and returns `B(t)`.
- `["de",p,name,A,q]` checks that `p` proves `["d",B]`, then checks
  `q` under the fresh parameter `name` and extra assumption
  `["q",B(name,y)]`. Its conclusion must be the previously validated
  `A`; the fresh parameter therefore cannot escape.
- `["tr",p,M,q]` checks that `p` proves `s=t`, that `M` is a formula
  with one open numerical coordinate, and that `q` proves `M(s)`.
  It returns `M(t)`. The motive can contain arbitrary nested logical
  and numerical binders.

## Primitive-only initialization and countdown

The checker's numerical builders implement these finite macros:

```
W(x)       = G(x,0)
M(n,a)     = J(n;u.a)
Z(n)       = W(M(n,S0))
H_a(u)     = G(M(Z(u),S(Sa)), W(W(u)))
L(n,a)     = W(J(Sn;u.H_a(u)))
```

The compiler lifts the initializer under the new state binder. Its update
is fixed, so it needs no general initialized-iterator compiler in the
trusted checker. The result contains only `0`, `v`, `p`, `g`, and `j`,
with no symbol for a program or universal evaluator. The untrusted
producer separately implements the report's general macro
`I(n,a;v.h)=W(J(Sn;u.G(M(Z(u),S(Sa)),h(W(u)))))`, taking care to lift
passive coordinates before opening the old state slot. Diagnostics check
that specializing this general expansion to `h(v)=W(v)` gives exactly the
checker's `L` tree, including when its initializer has an ambient bound
coordinate.

## Countdown uniqueness

`["uw",f,t,name,p]` checks a numerical template `f` with one open
coordinate and a numerical target `t`. The parameter `name` is fresh
for the active scope and hence for the validated retained context,
template, and target. With `z` denoting that parameter, the premise must
be precisely

```
f(Sz) = W(f(z)).
```

The returned formula is precisely

```
f(t) = L(t,f(0)).
```

The template is finite syntax. Arbitrary fixed passive parameters are
permitted. The premise retains the entire old context and receives no
new assumption. A proof that merely has the right shape without
proving the recurrence is rejected.

## Fixed reflection

`["r2",a,b,p]` checks numerical arguments `a,b`. The premise must prove
exactly

```
L(b,S(Sa)) = S(S0).
```

It returns `a=b`. This is the contextual inference form of one fixed
universally quantified implication. The displayed `L` is expanded by
the finite compiler above; it is not an additional primitive function.

The two successors in the initializer matter. Replacing `S(Sa)` by
`S(a)` would be unsound in the standard model: `a=1,b=0` would give the
premise `L(0,2)=2` and the false conclusion `1=0`. A fixture supplies a
valid proof of that incorrect-offset premise and verifies that the
actual rule rejects it.

## Reproduction and measurement

Run `python3 verify.py`. It regenerates the finite fixtures, replays each
in-process and through the public CLI with and without `-O`, and checks
finite standard-model values of the initializer compiler, including
captured passive coordinates. It writes `validation.json`.

`baseline_checker.py` is the attributed, unchanged readable three-schema
checker from the pinned repository archive. Measurement strips
docstrings and counts the complete source, including JSON input,
validation, substitution, every numerical macro, and the result protocol.
Supporting scripts are excluded because the checker does not use them.

This candidate is larger than the matched readable baseline and larger
than the current compact frontier. The archive makes no smaller-checker
claim. Finite validation also does not establish universal soundness of
Python or the mathematical bi-interpretability theorem.
