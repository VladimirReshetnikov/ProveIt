# Structural checker routes: findings

## Current boundary
The current complete checkers interleave syntax validation, capture-avoiding opening, eigenparameter freshness, and context membership in one function `i`. A successful native derivation is not enough to justify removing any of these duties.

## Total extra arities
Replacing the finite arity table by an unrestricted arithmetic increment admits additional array shapes. Current paired elimination treats every proof major with a third child as a paired binder, while introduction selects equation induction by arity parity. An even-arity extension interpreted as a paired compound therefore obtains compound-formula induction. Giving those extra nodes a trivial meaning instead fails the elimination rule, which extracts their third child as a nontrivial closure. A sound definitional extension must either canonicalize every node before rule dispatch or replace parity atomhood with exact equation recognition. Both cost additional implementation.

## Synthesis instead of checking a given goal
A synthesis checker returning the derived formula can omit some requested-goal matching, but existential/paired elimination must then reject an inferred conclusion containing its freshly allocated witness. The existing goal-directed checker gets this condition by fixing and checking the conclusion before entering the fresh context. Synthesis also needs comparison of each introduction minor with the successor instance and explicit tags/payloads for hypotheses and computation. No smaller complete implementation was established.

## Pair-coded unary binder
The mathematical binder D_z A(z) := exists w (A(pair(w,0)) -> forall n A(pair(w,n))) is definable on iPRA once pairing is available. A binary-tree domain makes pairing primitive, but structural tree recursion requires the children and recursive outputs in its step interface. No full checker saving or independent bi-interpretability improvement was established.

## Output protocol
Replacing ACCEPT/REJECT output with exit-status-only acceptance saves source in all competing checkers. The same optimization applies unchanged to the current frontier, so it does not demonstrate a better axiomatization or a matched-interface improvement.

## Conclusion
No sound new below-frontier complete checker was obtained from these routes. This is a negative result of this search, not a mathematical lower-bound theorem.
