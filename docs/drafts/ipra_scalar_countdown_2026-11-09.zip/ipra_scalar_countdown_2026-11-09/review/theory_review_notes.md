# Independent mathematical review

## Scope

The current three-schema reset-gate construction already removes the arbitrary initializer from numerical syntax. A fixed-base tree-recursion alternative is therefore not a new initializer-removal result, and no smaller complete checker has been obtained from it. Pair coding can turn the native two-variable binder into a one-variable binder, but this transfers work into pairing/projection syntax and does not establish a net saving.

## A precise sufficient condition for the remaining countdown problem

Work in the countdown draft's theory T_W. Write A(n,a) for successor iteration and d(a,n) for absorbing-predecessor iteration. The draft proves full contextual stationarity and

    d(Sa,Sn) = d(a,n).

Consider the additional conditional reverse-retraction principle

    R:  d(a,n) = Sk  ==>  A(n,Sk) = a.

This principle is valid in ordinary arithmetic. It is deliberately restricted to a positive remaining countdown; the unrestricted right-inverse equation is false.

**Proposition.** T_W + R admits uniqueness for arbitrary successor trajectories:

    Gamma |- f(Sz,p) = S f(z,p)
    --------------------------------
    Gamma |- f(t,p) = A(t,f(0,p)).

**Proof.** All parameters remain fixed. The term q(n)=d(f(n),n) is stationary, since its successor value is d(Sf(n),Sn)=d(f(n),n). Thus q(n)=f(0). Applying the same argument to the successor trajectory Sf(n) gives d(Sf(n),n)=Sf(0). R therefore gives

    S f(n) = A(n,Sf(0)).                    (1)

For an arbitrary a, the term g(n)=S A(n,a) is also a successor trajectory. Repeating the preceding argument gives

    d(S A(n,a),n)=Sa,
    S A(n,a)=A(n,Sa).                       (2)

Substitute a=f(0) in (2), compare with (1), and use successor injectivity. This proves the claimed uniqueness rule with arbitrary retained hypotheses. Applying it to f(n)=n yields A(n,0)=n.

No proof of R in T_W, and no implication from this proposition to the full requested minimization, is asserted here.

## Why a tempting duplicate-tag model fails

An elementary attempted model duplicates nonstandard values with invisible labels; successor preserves labels, A(n,a) keeps the initializer's label, and d(a,n) keeps a's label until its ordinary value becomes standard, when the label disappears. Then c(n)=A(n,0) has the canonical label, suggesting c(n) could differ from n.

This particular construction does not satisfy the already derived U_P rule. In a sufficiently nonstandard base model let

    f(n)=d(A(d(a,n),n),n).

On ordinary numerical values f(n)=d(a,n). In the proposed lift, whenever n and a-n are nonstandard, f(n) retains n's label. The lift makes f(Sn)=P(f(n)) hold throughout: its chosen A has the usual seed-shift identity, and labels disappear harmlessly as the countdown reaches standard values. But f(0)=c(a) has the canonical label, so U_P demands f(n)=d(c(a),n), whose label is canonical. Choosing a noncanonical label for n contradicts that demand.

This rejects only that proposed lift, not all tagged models and not the possibility that the countdown theory is strictly weaker than iPRA.
