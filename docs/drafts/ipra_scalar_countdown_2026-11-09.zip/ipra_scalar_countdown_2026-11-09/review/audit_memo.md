# Independent iPRA corpus audit

Snapshot: ProveIt `70feebabe24445912ae5eb336a6d7e9ba40a882b`, eleven top-level ZIP files in `docs/drafts`.

## Mathematical baseline

I checked the inherited Choice-DI calculus, its ordinary realization, the scalar predecessor bootstrap, equality reflection, and the full raw-formula normalization in the all-starts draft. I found no gap in these inspected arguments. This is a written-proof audit, not a proof-assistant verification or an audit of every historical nested source.

The baseline has terms `x | 0 | S t | I(n,a;u.h)` and native equality plus paired binder `D_xy B`. Its ordinary meaning is `exists x (B(x,0) -> forall y B(x,y))`. The primitive Choice-DI rule retains exactly one local assumption: either the zero instance, or the progression instance when the matrix is literally an equation. The restriction is on the root constructor, not on provable equivalence to an equation.

The missing two-assumption induction rule is reconstructed by an outer case introduction and an inner progress introduction with an unused existential coordinate. The unused coordinate is essential: elimination then returns the intended fixed witness parameter unchanged. This construction preserves arbitrary retained contexts, not only closed arithmetic conclusions.

The logical macros use the scalar selector and structural formula selection. Their proofs establish both formula composites. Numerical coverage is derived before the scalar arithmetic bootstrap. The predecessor construction uses only literal-equation induction with passive parameters fixed. Equality reflection is obtained by a residual reconstruction equation, not assumed from standard-model correctness. Quantifier-free induction is then derived through Boolean characteristics, and only afterward is pairing used to compile full primitive recursion.

The ordinary realization must include the genuine falsity bridge `(0=S0) -> false`. Positive equations alone admit a singleton structure. Domain interpretations are the entire numerical domain, with actual equality; internal uniqueness of every fixed recursion identifies the double-translated symbols. Thus there is a credible full bi-interpretability proof, beyond equiconsistency or standard-model agreement.

## Current mathematical proposals and their scope

| Archive | Main positive construction | Strict complete-checker outcome |
| --- | --- | --- |
| `ipra_all_starts_2026-11-10` | Atomic closures mean progression; one all-starts elimination fuses progression and zero-start specialization. Raw formulas are normalized into a safe sublanguage, proving both composites. | New checker does not beat frontier. |
| `ipra_calibration_and_fusion_2026-11-09` | Finite native axioms cannot repair deterministic introduction; an exceptional fused numerical constructor is functionally complete. | No new complete smaller axiomatization; fused source axioms/composites remain separate obligations. |
| `ipra_countdown_retraction_2026-11-09` | Bouncing-predecessor uniqueness proves whole-domain countdown retraction, full stationarity, and absorbing-predecessor uniqueness; an independent native rule factorization is complete. | Countdown theory itself is not proved bi-interpretable; factorized checker is not a matched overall gain. |
| `ipra_fixed_position_2026-11-09` | Fixed initializer-position equality transport, with direct one-step iterator computation, recovers arbitrary numerical and formula congruence. | Complete equivalent presentation, no global size record. |
| `ipra_forward_gates_2026-11-09` | Forward gates recover arbitrary contextual equation induction in the gated presentation. | Complete equivalent presentation, no global size record. |
| `ipra_k_iteration_2026-11-09` | Zero and successor are represented by `K` and application; `(K a)b=a` plus zero-seed iteration gives three computation schemas and arbitrary initialization. | Matched readable-checker saving, but 1,242 tokens is above compact frontier. |
| `ipra_kernel_and_initializer_2026-11-10` | A separate four-schema finite gate restores arbitrary initialization; existing Choice implementation removes stored selection state. | Implementation family improves its older controls to coordinate envelope 296/339/809; that size is not the new finite-gate theory's size. |
| `ipra_scalar_feedback_2026-11-09` | Scalar iteration plus an initially unspecified comparator and feedback rule calibrates actual inequality and recovers iPRA. | Separate existing-Choice implementation is 298/349/762; the new feedback theory's checker is larger. |
| Both `ipra_three_schema_2026-11-09` archives | Same successor-as-zero-branch/positive-predecessor binary operation, equivalent to K/application; three numerical computation schemas. | Complete theory, matched local savings; no global frontier claim. |
| `ipra_witnesses_and_seeds_2026-11-09` | DI witnesses can be restricted to zero or variables; fixed numeral seeds face a precisely scoped unary-section obstruction. | Complete equivalent witness restriction, but its direct checker is larger. |

## Complexity cautions

The repeatedly quoted 299/340/815 envelope is stale for the present folder. The parenthesized three-schema draft includes countdown controls 295/341/866, 300/334/893, and 303/349/801, while scalar_feedback provides a 762-byte Choice checker. These are different programs and different rejection-reporting profiles. Measure current sources rather than copying a historical abstract's minima.

Observed minima are achieved upper bounds on optimal implementation size, not mathematical lower bounds. A claim to improve all coordinates must beat the coordinate envelope while retaining the complete trusted input/output and checking interface. A new theory's checker cannot inherit the size of a separate unchanged-Choice implementation.

## Compact implementation boundary

I inspected `scalar_feedback/code/choice_checker.py` against its inherited decoder. The parser, syntax validation, scope traversal, freshness counter, computation rules, inference dispatch, and verdict handling are all in the measured source apart from standard Python/JSON facilities. It imports no arithmetic oracle, producer, theorem library, or external encoded program.

The unusual raw aliases are intentional: formula scalar leaves mean truth, binary numerical nodes mean zero with checked annotations, and protected dummy slots are explicit. Soundness is through decoding, not through a canonical-syntax claim. Malformed finite JSON values are rejected unless wholly unused payloads; negative names allocated during a completed major subproof cannot leak assumptions because contexts are private. The equation-only progress branch remains guarded by the root arity.

The universal extraction proof and formula-composite argument are the relevant evidence. Finite tests alone would not establish them. No concrete unsound accepted packet was found in this inspection.
