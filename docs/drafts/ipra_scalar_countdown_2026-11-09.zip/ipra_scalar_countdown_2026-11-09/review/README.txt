Independent research notes retain the scopes at which they were written.
The final theorem and metrics are in report.pdf and evidence/complete_checker_metrics.json.
The older R1 residual condition in reviews is equivalent to the final R2 observation sentence by the report.
The full native Case-only bridge was subsequently checked independently; see theory/native.tex.
