# Independent audit: scalar bouncing uniqueness plus one reflection axiom

## Verdict

The proposed scalar completion is valid at the level of the written internal derivations checked here. It avoids the circular use of full primitive recursion or equation induction in the reset construction. Its extra reflection axiom is essential to the proof as presently given; this does not complete the older `U_W`-only theory.

## Exact source

Use ordinary intuitionistic first-order equality logic. Numerical terms have `0`, binary `G`, and the fixed-description zero-seeded iterator `J(n;u.h)`. Write `Sx := G(0,x)`. The computation schemas are

1. `G(Sa,b)=a`;
2. `J(0;u.h)=0`;
3. `J(Sn;u.h)=h[J(n;u.h)/u]`.

Add numerical coverage, `(0=S0) -> false`, contextual bouncing uniqueness `U_W`, and one universal reflection axiom `R1`, defined below. Every update and term template is fixed finite syntax. All passive parameters remain fixed in a rule instance.

## Coverage-only initialized-iterator compiler

Define `W(x)=G(x,0)`, so `W0=1` and `W(Sx)=x`. Define

`P(x)=J(x;u.W(x))`,

`C(x,a,b)=W(G(J(x;u.S(Sb)),a))`.

Computation alone proves `P0=0`, `P(Sx)=x`, `C(0,a,b)=a`, and `C(Sx,a,b)=b`.

For a fixed update `h`, define

`T(u)=C(u,Sa,S(h(Pu)))`,

`V(n,a)=J(Sn;u.T(u))`,

`I(n,a;h)=P(V(n,a))`.

Then `T0=Sa` and `T(Su)=S(h(u))`. Coverage of an arbitrary `u` proves that `T(u)` is a successor. Since `V(n,a)=T(J(n;T))` by one direct computation, coverage proves `V(n,a)=S(P(V(n,a)))` for every `n`. This is a finite case argument; it does not use induction.

Now `V0=Sa`, `V(Sn)=T(Vn)=S(h(P(Vn)))`, so `I0=a` and `I(Sn)=h(In)`. This supplies all initialized scalar iterators before any induction principle has been derived.

## Elementary prerequisites for stationarity

Put `delta(u)=C(u,1,0)`, and define `p(n)=I(n,0;u.delta(u))`. Coverage proves the Boolean ranges of `delta` and `p`; for `p` use counter coverage and its successor computation. Thus `S` has no fixed point: `Sa=a` would imply `delta(p(a))=p(a)`, impossible at either Boolean value. Coverage then shows that `W` has no fixed point.

Let `L(n,a)=I(n,a;u.W(u))`. The rule `U_W` is

`Gamma |- f(Sz)=W(f(z))` implies `Gamma |- f(t)=L(t,f(0))`,

with the usual freshness condition on `z`.

For a stationary `r` with `r0=0`, set `q(n)=L(n,0)` and `g(n)=C(r(n),q(n),W(q(n)))`. Selector cases prove `g(Sn)=W(g(n))`, and `g0=0`. Hence `U_W` proves `g(n)=q(n)`. The successor branch for `r(n)` would give the forbidden fixed point `W(q(n))=q(n)`. Coverage leaves `r(n)=0`.

For each externally fixed numeral `m`, numeral-valued stationarity follows by an external induction on `m`. In the successor case apply the preceding numeral case to `P(r(n))` and zero-stationarity to `delta(r(n))`. Coverage reconstructs `r(n)=S(P(r(n)))=m+1`. Only the cases `m=1,2` are needed below.

## Rotation, diagonals, and the defined countdown

Apply `U_W` to `f(n)=W(L(n,a))` to prove

`L(n,W(a))=W(L(n,a))`.

For a fixed standard `m`, the term `q_m(n)=L(n,S^m n)` is stationary by this rotation and the computation `W(Sx)=x`. Its zero value is `m`, so numeral stationarity yields `L(n,S^m n)=m`.

Define, rather than postulate as a separate recursive symbol,

`d(a,n)=P(L(n,Sa))`.

The following details should be present explicitly in the report:

- Coverage proves `P(W(v))=P(P(v))` by the cases `v=0` and `v=Sx`.
- Therefore `d(a,0)=a` and `d(a,Sn)=P(d(a,n))`.
- Rotation proves `d(Sa,Sn)=d(a,n)` directly.
- The fixed-numeral diagonals prove `d(a,a)=0` and `d(Sa,a)=1`.

The added universal reflection axiom is precisely

`R1: forall a b, d(Sa,b)=1 -> a=b`.

## Actual equality characteristic

A shorter characteristic than the proposed selector expression is

`e(a,b)=delta(W(d(Sa,b)))`.

Coverage and separation prove `delta(v)=1 iff v=0` and `W(v)=0 iff v=1`. Consequently `e(a,b)=1 iff d(Sa,b)=1`. Its Boolean range is automatic from `delta`. Axiom `R1` proves the forward equality reflection, and the established diagonal proves its converse:

`e(a,b)=1 iff a=b`.

The originally proposed `C(d(Sa,b),0,delta(P(d(Sa,b))))` is also correct and is **one-true**, not zero-true.

## Zero-start successor rigidity

Assume in a retained context that `f0=0` and `f(Sn)=S(f(n))`. Define

`q(n)=d(S(f(n)),n)`.

Then `q0=1`, and cancellation gives

`q(Sn)=d(S(S(f(n))),Sn)=d(S(f(n)),n)=q(n)`.

Numeral stationarity yields `d(S(f(t)),t)=1`. Apply `R1` with `a=f(t)`, `b=t` to conclude `f(t)=t`. There is no use of successor uniqueness in this derivation.

## Quantifier-free induction by a scalar reset

Compile each fixed quantifier-free formula `A` to a Boolean term `b_A` with `b_A=1 iff A`, using actual equality characteristic `e`, `b_false=0`, and

`b_(A and B)=C(b_A,0,b_B)`,

`b_(A or B)=C(b_A,b_B,1)`,

`b_(A -> B)=C(b_A,1,b_B)`.

This is external recursion on finite formula syntax. The implication clause uses intuitionistic reasoning in the two proved Boolean branches, not excluded middle for arbitrary quantified formulas.

Suppose `Gamma |- A(0)` and `Gamma,A(z) |- A(Sz)` with `z` fresh. By the derived equivalence, finite Boolean cases establish for every `u`

`b_A(C(b_A(u),0,Su))=1`.

Indeed, a false input resets to the known base, and a true input advances by the given step. Define the scalar trajectory

`f(n)=I(n,0;u.C(b_A(u),0,Su))`.

Coverage of its counter, together with the preceding global range property of its update, proves `b_A(f(n))=1` for every `n`: zero is the base; a successor is one update of an arbitrary previous value. This does not require an induction hypothesis. Hence the iterator computation gives `f(Sn)=S(f(n))`, and `f0=0`. Zero-start successor rigidity gives `f(n)=n`, and equality transport yields `b_A(n)=1`, hence `A(n)`.

Thus full contextual quantifier-free induction is derived in the scalar source. All quantified assumptions in `Gamma` remain allowed; only the induction matrix is quantifier free.

## Remaining presentation obligations

The existing scalar-to-PR compiler may now be used, because quantifier-free induction is available. Its pairing and function uniqueness arguments are not needed earlier in the proof.

In iPRA, `G` has its ordinary case definition and `J` is zero-seeded iteration. The source computation and boundary axioms hold. Equation induction proves `U_W`; the countdown recurrences identify the defined `d` with truncated subtraction, proving `R1`. In the other direction the argument above supplies iPRA. Coverage identifies the composite `G`; equation induction, now derived, identifies each composite fixed `J` by uniqueness. Both domains are unchanged and the composite isomorphism is actual identity.

These obligations establish a complete scalar completion once the inherited PR compiler is supplied. They do **not** establish a smaller complete checker than the current draft envelope. The expanded `R1` term and `U_W` matching rule must be included in any implementation accounting.
