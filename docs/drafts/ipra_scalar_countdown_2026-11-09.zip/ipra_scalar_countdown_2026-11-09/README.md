# Completing iPRA from a fixed countdown rule

**Outcome:** a finite scalar axiomatization is proved equiconsistent and
bi-interpretable with full first-order iPRA. The requested strictly smaller
complete checker has **not** been obtained. The new readable checker is
larger than its matched predecessor and the current compact frontier.

Read `report.pdf`. Its complete source is `report.tex` plus `theory/*.tex`.

## The result

The numerical grammar is `0`, a binary gate `G`, and zero-seeded scalar
iteration `J`. There are three computation schemas. In addition to
intuitionistic first-order equality logic, coverage, and separation, the
ordinary source has one fixed countdown uniqueness rule and one fixed
universal sentence:

    L(b, S(S(a))) = 2  ->  a = b.

Here `W(0)=1`, `W(Sa)=a`, and `L(n,a)` iterates `W` from `a`. All of
these are explicitly expanded in the finite numerical grammar. Over the
stated base with uniqueness, this sentence is equivalent to full
quantifier-free induction. The proof uses only a scalar reset before
induction is recovered. Both interpretation domains are the entire domain,
with internal identity isomorphisms for both numerical composites.

The exact family theorem says that every fixed observation level at least
2 is equivalent, while the analogous levels 0 and 1 are inconsistent.
This family theorem is not a lower bound for all axiomatizations.

## Evidence and scope

- `code/native/checker.py`: complete standalone native checker; imports only `json`.
- `code/native/FORMAT.md`: exact syntax, rules, scope checks, and invocation.
- `code/native/produce.py`: untrusted certificate construction and general scalar compiler.
- `code/native/fixtures.json`: 14 positive and 17 negative examples.
- `code/native/validation.json`: 31 fixture results, 62 command-line replays, and 780 diagnostics.
- `code/check_observations.py`: 5,010 additional finite standard-model checks.
- `code/measure_sources.py`: complete-source measurement, including the trusted countdown compiler.
- `reference/`: unchanged compact comparison sources.
- `evidence/`: pinned source provenance, corpus inventories, metrics and numerical results.
- `review/`: independent reviews and rejected routes, with their limited scopes.

The written equivalence proof is not formalized in Lean or Rocq. Finite
tests do not replace its internal arguments about arbitrary and nonstandard
elements. No absolute minimality or literature-wide novelty is claimed.

## Reproduce

    python3 reproduce.py
    python3 build.py

Python checks use the standard library. PDF building requires a LaTeX
installation with the packages listed in `report.tex`.

## Audited comparison

Repository: `VladimirReshetnikov/ProveIt`

Commit: `70feebabe24445912ae5eb336a6d7e9ba40a882b`

Eleven top-level `docs/drafts` ZIP files were retrieved and their Git blob
identities verified. Different existing checkers attain 292 normalized
tokens, 330 AST nodes, and 762 normalized bytes. The matched readable
predecessor measures 1,442 / 1,674 / 5,323; the new checker measures
1,754 / 1,996 / 6,536. Thus the computational size target remains unmet.

See the report's contribution ledger and `code/native/ATTRIBUTION.txt`
for inherited ingredients. In particular the gate, initialized-iterator
compiler, case-binder logical interface, and scalar PR compiler are
attributed to the inspected drafts. The new result is their specific
finite countdown completion, scalar reset dependency argument, and exact
observation-level boundary.
