CERTIFICATE VALIDATION
======================

Run from any working directory:

    python3 /absolute/path/to/ipra_prefix_kernel_2026-11-06/tests/run_certificates.py

Or, from the unpacked archive root:

    python3 tests/run_certificates.py

The driver imports only this archive's checker.py. It needs Python 3.10 or
later and the standard library. It verifies the fixture hashes, checks all
70 named certificates through the API, and rechecks eight selected fixtures
through the command-line interface in normal and optimized (-O) Python.
It writes validation/certificate_results.json and exits nonzero on a
mismatch. The 16 CLI calls reuse existing fixtures; they are not 16 new
mathematical examples.

There are 37 positive and 33 negative fixtures. Every fixture has a stated
purpose, expected result, content hash and origin in fixture_manifest.json.
The two certificate subdirectories contain the complete finite JSON data;
no external repository, generator or network access is needed to rerun them.

POSITIVE COVERAGE

* Computation at zero and successor, with ambient parameters.
* A new, explicitly written successor-computation equation that substitutes
  both recursive state and counter under a nested recursor while preserving
  a free parameter. Its paired negative fixture changes that parameter into
  a bound counter.
* Derived reflexivity, successor injectivity and successor separation.
* Pi and Sigma introduction and elimination, dependent nested binders,
  retained assumptions, and a large free-variable index.
* Ordinary implication and conjunction introduction; implication elimination
  and both conjunction projections; ordinary universal and existential
  introduction and elimination.
* Both introductions and elimination of the current numerical-tag
  disjunction macro, including compound formulas and parameters.
* Equality replacement under logical and recursion binders.
* Equation induction applied to iteration of successor; general numerical
  cases; the constant-falsity numerical case; local-assumption lifting.
* Public falsity conversion, collapse to an arbitrary equation, and explosion
  into a nested quantified formula.

NEGATIVE COVERAGE

* False claims of a closed contradiction, and use of an unlisted proof rule.
* An attempted strengthening of general numerical cases to induction for a
  quantified matrix.
* Escaping existential witnesses, captured universal eigenvariables, and
  substitution capture under both logical and recursion binders.
* Wrong replacement premises; malformed formula templates, fresh guards,
  existential targets, recursion terms and bodies; non-constructor counters.
* Malformed outer envelopes and forbidden Boolean, floating-point, string or
  negative-index values in relevant theorem-syntax positions.
* A malformed but unused recursion body in a zero computation.

An intentionally accepted equality-alias hypothesis lookup tests retrieval
of the stored canonical formula. The lookup key is not returned as inferred
theorem syntax; malformed assumptions and goals are independently rejected.

PROVENANCE

Sixty-three fixture byte streams are reserialized selections of the composed
kernel's certificate suite in the ProveIt archive identified in the manifest.
Their original source-byte hashes and full archive-relative paths are retained.
Seven fixtures were written independently for this package. The comparisons
are finite regression checks, not a formal proof of the checker metatheory.
The report provides the mathematical soundness/completeness arguments.
