"""Independent finite audit of the prefix-substitution checker.

Run from any directory, for example:
    python3 tests/substitution_audit.py
    python3 tests/substitution_audit.py --checker validation/prefix_explicit_weakening_default.py
    python3 tests/substitution_audit.py --output validation/substitution_results.json

The checker path is resolved relative to the current directory when supplied.
The oracle below uses callbacks and an explicit case for each constructor;
it does not call or import the checker's substitution or formation helpers.
It follows the previous, general simultaneous-substitution specification.
Handwritten expected results separately check the binding conventions.

This file is an untrusted audit, not an acceptance dependency or a formal
verification. Tests compare finite instances and cannot prove metatheorems.
"""

import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import sys


SEED = 20261106


def map_free_reference(a, transform, depth=0):
    """Reference callback traversal, with constructor-specific binding scopes."""
    if type(a) is int:
        return a if a < depth else transform(a - depth, depth)
    tag = a[0]
    if tag == "s":
        return ["s", map_free_reference(a[1], transform, depth)]
    if tag == "r":
        return ["r", map_free_reference(a[1], transform, depth),
                map_free_reference(a[2], transform, depth),
                map_free_reference(a[3], transform, depth + 2)]
    if tag == "=":
        return ["=", map_free_reference(a[1], transform, depth),
                map_free_reference(a[2], transform, depth)]
    if tag in ("pi", "sig"):
        return [tag, map_free_reference(a[1], transform, depth + 1),
                map_free_reference(a[2], transform, depth + 1)]
    raise ValueError("not a reference expression")


def shift_reference(a, amount):
    return map_free_reference(a, lambda index, depth: index + depth + amount)


def substitute_reference(a, prefix=(), delta=1, depth=0):
    """Simultaneous environment: prefix[i] for i<k, variable i+delta otherwise."""
    def environment(index):
        return prefix[index] if index < len(prefix) else index + delta
    return map_free_reference(a, lambda index, level:
                              shift_reference(environment(index), level), depth)


def term(rng, height):
    if height == 0 or rng.randrange(3) == 0:
        return rng.randrange(-1, 8)
    if rng.randrange(2) == 0:
        return ["s", term(rng, height - 1)]
    return ["r", term(rng, height - 1), term(rng, height - 1),
            term(rng, height - 1)]


def formula(rng, height):
    if height == 0 or rng.randrange(3) == 0:
        return ["=", term(rng, 2), term(rng, 2)]
    return [rng.choice(("pi", "sig")), formula(rng, height - 1),
            formula(rng, height - 1)]


def e(a, b):
    return ["=", a, b]


def s(a):
    return ["s", a]


def hyp(a):
    return ["hyp", a]


def document(assumptions, goal, proof):
    return [assumptions, goal, proof]


def load_checker(path):
    specification = importlib.util.spec_from_file_location("audited_checker", path)
    checker = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(checker)
    return checker


class Audit:
    def __init__(self):
        self.counts = {}
        self.failures = []

    def record(self, group, name, condition, details=None):
        self.counts[group] = self.counts.get(group, 0) + 1
        if not condition:
            self.failures.append({"group": group, "name": name, "details": details})

    def equal(self, group, name, actual, expected):
        self.record(group, name, actual == expected,
                    {"actual": actual, "expected": expected})


def manual_substitution_checks(checker, audit):
    cases = [
        ("zero_is_not_shifted", -1, (), 1, 0, -1),
        ("default_weakening_free_variable", 0, (), 1, 0, 1),
        ("weaken_two", e(0, 3), (), 2, 0, e(2, 5)),
        ("protected_ambient_index", 0, [s(4)], -1, 1, 0),
        ("ambient_replacement_is_raised", 1, [s(4)], -1, 1, s(5)),
        ("ambient_tail_is_lowered", 3, [s(4)], -1, 1, 2),
        ("instantiate_zero", e(0, 2), [-1], -1, 0, e(-1, 1)),
        ("simultaneous_not_iterated", e(0, 1), [1, 0], 0, 0, e(1, 0)),
        ("successor_replacement_keeps_parameters", e(0, 3), [s(0)], 0, 0,
         e(s(0), 3)),
        ("pi_binds_both_children", ["pi", e(0, 1), e(2, 3)], [s(0)], 0, 0,
         ["pi", e(0, s(1)), e(2, 3)]),
        ("sigma_binds_both_children", ["sig", e(0, 1), e(1, 2)], [3], -1, 0,
         ["sig", e(0, 4), e(4, 1)]),
        ("recursor_only_binds_body", ["r", 0, 1, s(2)], [s(0), s(1)], -2, 0,
         ["r", s(0), s(1), s(s(2))]),
        ("recursor_tail_parameter", ["r", 2, 1, s(2)], [s(0), s(1)], -2, 0,
         ["r", 0, s(1), s(s(2))]),
        ("nested_recursors_weakening", ["r", 0, 1, ["r", 2, 0, s(4)]], (), 1, 0,
         ["r", 1, 2, ["r", 3, 0, s(5)]]),
        ("inserted_term_own_binders_protected", e(0, 1), [["r", 0, -1, s(0)]],
         -1, 0, e(["r", 0, -1, s(0)], 0)),
        ("nested_pi_sigma_instantiation",
         ["pi", e(0, 1), ["sig", e(0, 2), e(1, 3)]],
         [["r", 0, -1, s(2)]], -1, 0,
         ["pi", e(0, ["r", 1, -1, s(3)]),
          ["sig", e(0, ["r", 2, -1, s(4)]), e(1, 2)]]),
    ]
    for name, a, prefix, delta, depth, expected in cases:
        before = copy.deepcopy((a, prefix))
        actual = checker.sub(a, prefix, delta, depth)
        audit.equal("manual_binding", name, actual, expected)
        audit.equal("reference_manual_binding", name,
                    substitute_reference(a, prefix, delta, depth), expected)
        audit.equal("input_immutability", name, (a, prefix), before)
    audit.equal("manual_binding", "omitted_arguments_mean_weakening",
                checker.sub(e(0, -1)), e(1, -1))
    audit.equal("manual_binding", "inst_helper_removes_one_slot",
                checker.inst(e(0, 2), s(3)), e(s(3), 1))


def differential_checks(checker, audit, count):
    rng = random.Random(SEED)
    for number in range(count):
        a = (term if number % 2 == 0 else formula)(rng, 3)
        prefix = [term(rng, 2) for _ in range(rng.randrange(4))]
        delta = rng.randrange(-len(prefix), 4)
        depth = rng.randrange(4)
        expected = substitute_reference(a, prefix, delta, depth)
        actual = checker.sub(a, prefix, delta, depth)
        audit.equal("differential_substitution", str(number), actual, expected)
    # Test real caller forms separately, including the two distinct tail shifts.
    for number in range(100):
        a = formula(rng, 3)
        witness, previous, counter = (term(rng, 2) for _ in range(3))
        calls = [("weakening", (), 1), ("instantiation", [witness], -1),
                 ("recursion", [previous, counter], -2),
                 ("successor_template", [s(0)], 0)]
        for name, prefix, delta in calls:
            audit.equal("caller_forms", f"{name}_{number}",
                        checker.sub(a, prefix, delta),
                        substitute_reference(a, prefix, delta))


def boundary_checks(checker, audit):
    z = -1
    truth = e(z, z)
    clash = e(z, s(z))
    public_false = ["false"]
    refl_term = ["r", z, z, z]
    refl_proof = ["rec", refl_term]
    reflexivity = ["use", refl_proof, e(0, z), refl_proof]
    old_formula = e(0, z)
    shifted_formula = e(1, z)
    fresh = e(0, 1)
    sigma = ["sig", e(0, z), truth]
    successor_rec = ["r", s(0), 2, 0]
    expected_rec = e(successor_rec, ["r", 0, 2, 0])
    cases = [
        ("reflexivity", True, document([], truth, reflexivity)),
        ("recursion_successor_state", True,
         document([], expected_rec, ["rec", successor_rec])),
        ("public_false_assumption_is_preserved", True,
         document([public_false], public_false, hyp(public_false))),
        ("clash_encodes_public_false", True,
         document([clash], public_false, hyp(clash))),
        ("unproved_false", False, document([], public_false, hyp(public_false))),
        ("unproved_clash", False, document([], clash, hyp(clash))),
        ("unknown_rule", False, document([], truth, ["refl", z])),
        ("nonlist_context", False, document({}, truth, reflexivity)),
        ("too_few_fields", False, [[], truth]),
        ("too_many_fields", False, [[], truth, reflexivity, 0]),
        ("null_document", False, None),
        ("malformed_goal_arity", False, document([], ["=", z], reflexivity)),
        ("malformed_assumption_arity", False,
         document([["=", z]], truth, reflexivity)),
        ("boolean_goal_variable", False,
         document([e(1, 1)], e(True, True), hyp(e(1, 1)))),
        ("float_goal_variable", False,
         document([e(1, 1)], e(1.0, 1.0), hyp(e(1, 1)))),
        ("boolean_assumption_variable", False,
         document([e(True, True)], e(1, 1), hyp(e(1, 1)))),
        ("float_assumption_variable", False,
         document([e(1.0, 1.0)], e(1, 1), hyp(e(1, 1)))),
        ("negative_variable_below_zero_sentinel", False,
         document([e(-2, -2)], e(-2, -2), hyp(e(-2, -2)))),
        ("pi_context_weakening", True,
         document([old_formula], ["pi", truth, shifted_formula],
                  ["pi", truth, hyp(shifted_formula)])),
        ("pi_old_parameter_cannot_be_captured", False,
         document([old_formula], ["pi", truth, old_formula],
                  ["pi", truth, hyp(old_formula)])),
        ("boolean_pi_guard", False,
         document([], ["pi", e(1, 1), e(1, 1)],
                  ["pi", e(True, True), hyp(e(1, 1))])),
        ("pi_boolean_witness", False,
         document([["pi", truth, truth], truth], truth,
                  ["use", hyp(["pi", truth, truth]), True, hyp(truth)])),
        ("equality_boolean_template", False,
         document([e(1, 1)], e(1, 1),
                  ["use", hyp(e(1, 1)), e(True, 0), hyp(e(1, 1))])),
        ("pair_fresh_witness_equation", True,
         document([], ["sig", fresh, fresh], ["pair", 0, hyp(fresh), hyp(fresh)])),
        ("pair_boolean_witness", False,
         document([], ["sig", fresh, fresh], ["pair", True, hyp(fresh), hyp(fresh)])),
        ("pair_float_witness", False,
         document([], ["sig", fresh, fresh], ["pair", 0.0, hyp(fresh), hyp(fresh)])),
        ("sigma_witness_may_not_escape", False,
         document([sigma], old_formula, ["use", hyp(sigma), old_formula, hyp(old_formula)])),
        ("recursion_boolean_initializer", False,
         document([], e(["r", z, 1, z], 1), ["rec", ["r", z, True, z]])),
        ("recursion_float_counter", False,
         document([], e(["r", z, z, z], z), ["rec", ["r", -1.0, z, z]])),
        ("recursion_boolean_body", False,
         document([], e(["r", z, z, 1], z), ["rec", ["r", z, z, True]])),
        ("recursion_nonconstructor_counter", False,
         document([], e(["r", 0, z, z], z), ["rec", ["r", 0, z, z]])),
        ("recursion_unknown_body", False,
         document([], truth, ["rec", ["r", z, z, ["unknown"]]])),
        ("numerical_axiom_boolean_template", False,
         document([], truth, ["nat", e(True, True)])),
        ("numerical_axiom_malformed_template", False,
         document([], truth, ["nat", ["=", 0]])),
        # Lookup keys are selectors, not claimed formulas: aliases may select
        # only an existing, previously validated assumption.
        ("boolean_alias_lookup_selects_existing_formula", True,
         document([e(1, 1)], e(1, 1), hyp(e(True, True)))),
        ("float_alias_lookup_selects_existing_formula", True,
         document([e(1, 1)], e(1, 1), hyp(e(1.0, 1.0)))),
        ("alias_lookup_cannot_manufacture_assumption", False,
         document([truth], e(1, 1), hyp(e(True, True)))),
    ]
    for name, expected, data in cases:
        # JSON round-trip enforces the actual public input data classes.
        data = json.loads(json.dumps(data))
        exception = None
        try:
            actual = checker.check(data) is True
        except (ValueError, TypeError, IndexError, KeyError, RecursionError) as error:
            actual = False
            exception = type(error).__name__
        except Exception as error:
            actual = None
            exception = "unexpected " + type(error).__name__
        audit.record("public_boundary", name, actual == expected,
                     {"expected_acceptance": expected, "actual_acceptance": actual,
                      "exception": exception})

    stored = e(1, 1)
    context = [stored]
    for name, key in (("boolean_key", e(True, True)), ("float_key", e(1.0, 1.0))):
        inferred = checker.infer(hyp(key), context)
        audit.record("stored_assumption_identity", name, inferred is stored)
        audit.record("stored_assumption_exact_integers", name,
                     type(inferred[1]) is int and type(inferred[2]) is int)


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path, default=root / "checker.py")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--cases", type=int, default=4000)
    arguments = parser.parse_args()
    if arguments.cases < 1:
        parser.error("--cases must be positive")
    checker_path = arguments.checker.resolve()
    checker = load_checker(checker_path)
    audit = Audit()
    manual_substitution_checks(checker, audit)
    differential_checks(checker, audit, arguments.cases)
    boundary_checks(checker, audit)
    result = {
        "audit": "finite-prefix substitution and public-boundary audit",
        "checker": str(checker_path),
        "checker_sha256": hashlib.sha256(checker_path.read_bytes()).hexdigest(),
        "python_version": sys.version.split()[0],
        "seed": SEED,
        "all_passed": not audit.failures,
        "counts": audit.counts,
        "total_checks": sum(audit.counts.values()),
        "failures": audit.failures,
        "scope": "Finite executable evidence; not a proof of soundness or bi-interpretability.",
        "hypothesis_lookup": (
            "Boolean or float lookup keys may alias an existing formula under Python equality. "
            "The checker returns the validated stored formula itself; aliases do not enter "
            "the inferred formula. Goals, assumptions, and new annotations reject such values."
        ),
        "substitution_precondition": (
            "Wellformed input and prefix terms; len(prefix)+delta >= 0. "
            "All actual caller forms satisfy this bound."
        ),
    }
    encoded = json.dumps(result, indent=2) + "\n"
    if arguments.output:
        arguments.output.parent.mkdir(parents=True, exist_ok=True)
        arguments.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")
    return 0 if result["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
