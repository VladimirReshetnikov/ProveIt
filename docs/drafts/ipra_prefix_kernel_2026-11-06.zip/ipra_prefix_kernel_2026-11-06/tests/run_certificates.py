"""Run the named, finite certificate regression suite from any directory.

Only checker.py is the implementation under test. Fixture construction and
this driver are untrusted testing utilities, not part of the proof kernel.
No source outside this unpacked archive is imported or read.
"""

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
REJECTIONS = (ValueError, TypeError, IndexError, KeyError, RecursionError)
CLI_NAMES = (
    'derived_reflexivity',
    'recursion_simultaneous_substitution',
    'disjunction_elimination',
    'compound_numerical_cases',
    'unproved_bottom',
    'boolean_goal',
    'sigma_witness_escape',
    'forbidden_quantified_induction',
)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    checker_path = ROOT / 'checker.py'
    manifest_path = ROOT / 'tests' / 'fixture_manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    spec = importlib.util.spec_from_file_location('checked_kernel', checker_path)
    kernel = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(kernel)

    records = []
    failures = []
    by_name = {}
    for fixture in manifest['fixtures']:
        name = fixture['name']
        if name in by_name:
            raise ValueError('duplicate fixture name: ' + name)
        by_name[name] = fixture
        path = ROOT / fixture['file']
        if sha256(path) != fixture['sha256']:
            raise ValueError('fixture hash differs from the manifest: ' + name)
        data = json.loads(path.read_text(encoding='utf-8'))
        rejection = None
        try:
            accepted = kernel.check(data) is True
        except REJECTIONS as exc:
            accepted = False
            rejection = type(exc).__name__
        except Exception as exc:
            accepted = False
            rejection = 'unexpected ' + type(exc).__name__
            failures.append(name + ': ' + rejection)
        passed = accepted == fixture['expected_accept']
        if not passed:
            failures.append(name + ': wrong acceptance result')
        records.append({
            'name': name,
            'file': fixture['file'],
            'expected_accept': fixture['expected_accept'],
            'actual_accept': accepted,
            'passed': passed,
            'rejection_exception': rejection,
        })

    cli_records = []
    for optimized in (False, True):
        for name in CLI_NAMES:
            fixture = by_name[name]
            command = [sys.executable, *(['-O'] if optimized else []),
                       str(checker_path), str(ROOT / fixture['file'])]
            # A temporary caller directory is unnecessary: all operands are
            # absolute, and cwd deliberately differs from the archive root.
            result = subprocess.run(command, cwd=ROOT / 'tests',
                                    capture_output=True, text=True, timeout=30)
            expected = fixture['expected_accept']
            passed = (result.returncode == (0 if expected else 1)
                      and result.stdout.strip() == ('ACCEPT' if expected else 'REJECT')
                      and result.stderr == '')
            if not passed:
                failures.append(name + ': CLI failure, optimized=' + str(optimized))
            cli_records.append({
                'name': name,
                'optimized_python': optimized,
                'expected_accept': expected,
                'exit_code': result.returncode,
                'stdout': result.stdout.strip(),
                'stderr': result.stderr,
                'passed': passed,
            })

    report = {
        'checker_file': 'checker.py',
        'checker_sha256': sha256(checker_path),
        'fixture_manifest_sha256': sha256(manifest_path),
        'fixture_count': len(records),
        'positive_fixtures': sum(row['expected_accept'] for row in records),
        'negative_fixtures': sum(not row['expected_accept'] for row in records),
        'cli_distinct_fixtures': len(CLI_NAMES),
        'cli_rechecks': len(cli_records),
        'all_passed': not failures,
        'scope': ('Named finite regression cases. CLI rechecks reuse eight of '
                  'the same fixtures, each in ordinary and optimized Python. '
                  'These tests do not establish soundness or completeness.'),
        'fixture_results': records,
        'cli_results': cli_records,
        'failures': failures,
    }
    destination = ROOT / 'validation' / 'certificate_results.json'
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    summary = {key: report[key] for key in (
        'checker_sha256', 'fixture_count', 'positive_fixtures',
        'negative_fixtures', 'cli_distinct_fixtures', 'cli_rechecks', 'all_passed')}
    print(json.dumps(summary, indent=2))
    if failures:
        for failure in failures:
            print(failure, file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
