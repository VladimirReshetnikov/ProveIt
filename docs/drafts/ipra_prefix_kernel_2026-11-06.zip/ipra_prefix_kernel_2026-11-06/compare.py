"""Recount complete checkers without importing or executing any checker.

Run this file from any working directory.  All input paths are relative to
this archive.  The six current main checkers and their explicit alternatives
are remeasured from verbatim packaged sources.  The larger inherited-source
census is an authenticated measurement record, not a new execution or a
remeasurement of omitted source files.  See provenance/README.txt.
"""

import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tokenize


ROOT = Path(__file__).resolve().parent
METRICS = ("significant_tokens", "normalized_tokens", "ast_nodes",
           "normalized_bytes", "raw_bytes")
LAYOUT = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
          tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def measure_source(raw):
    """Count the entire source, removing only comments/layout/docstrings."""
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                             ast.AsyncFunctionDef)) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr)
                    and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                spans.append(((first.lineno, first.col_offset),
                              (first.end_lineno, first.end_col_offset)))
                del node.body[0]

    def tokens(text, omit_spans=()):
        return sum(1 for token in tokenize.generate_tokens(io.StringIO(text).readline)
                   if token.type not in LAYOUT
                   and not any(start <= token.start and token.end <= end
                               for start, end in omit_spans))

    normalized = ast.unparse(tree) + "\n"
    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(alias.name.split(".")[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.add("." * node.level + (node.module or ""))
    return {
        "sha256": hashlib.sha256(raw).hexdigest(),
        "significant_tokens": tokens(source, spans),
        "normalized_tokens": tokens(normalized),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "raw_bytes": len(raw),
        "imports": sorted(imports),
    }


def aggregate(parts):
    """A dependency closure is charged once per distinct source file."""
    return {key: sum(part[key] for part in parts) for key in METRICS}


def frontier(rows):
    return {key: {"value": min(row[key] for row in rows),
                  "ids": [row["id"] for row in rows
                          if row[key] == min(item[key] for item in rows)]}
            for key in METRICS}


def latex_escape(text):
    return text.replace("_", r"\_").replace("&", r"\&")


def main():
    manifest = json.loads((ROOT / "provenance/source_manifest.json").read_text())
    source_metrics = {}
    for relative, metadata in manifest["files"].items():
        raw = (ROOT / relative).read_bytes()
        measured = measure_source(raw)
        if measured["sha256"] != metadata["sha256"]:
            raise ValueError("Source hash mismatch: " + relative)
        # Every packaged current checker is a complete standalone program.
        # A local dependency cannot be silently left outside its source count.
        nonstandard = set(measured["imports"]) - sys.stdlib_module_names
        if nonstandard:
            raise ValueError("Unaccounted imports in " + relative + ": "
                             + repr(sorted(nonstandard)))
        source_metrics[relative] = measured

    rows = []
    for program in manifest["programs"]:
        row = dict(program)
        row.update(aggregate([source_metrics[path]
                              for path in dict.fromkeys(program["files"])]))
        rows.append(row)
    mains = [row for row in rows if row["kind"] == "current_main"]
    if len(mains) != 6:
        raise ValueError("The comparison requires exactly six current main checkers")

    candidate = {"id": "candidate", "label": "Finite-prefix checker",
                 "file": "checker.py", **measure_source((ROOT / "checker.py").read_bytes())}
    if set(candidate["imports"]) - sys.stdlib_module_names:
        raise ValueError("Candidate has an unaccounted nonstandard import")

    controls = []
    for identifier, label, relative in (
            ("callback", "Matched callback checker", "controls/callback_checker.py"),
            ("prefix_helpers", "Prefix substitution with helpers", "controls/prefix_with_helpers.py")):
        measured = measure_source((ROOT / relative).read_bytes())
        if set(measured["imports"]) - sys.stdlib_module_names:
            raise ValueError("Matched control has an unaccounted import: " + relative)
        controls.append({"id": identifier, "label": label, "file": relative, **measured})
    matched_chain = [next(row for row in mains if row["id"] == "composed.main"),
                     *controls, candidate]
    matched_differences = [
        {"from": before["id"], "to": after["id"],
         "reductions": {key: before[key] - after[key] for key in METRICS}}
        for before, after in zip(matched_chain, matched_chain[1:])]

    recorded = manifest["inherited_census"]
    census_raw = (ROOT / recorded["path"]).read_bytes()
    if hashlib.sha256(census_raw).hexdigest() != recorded["sha256"]:
        raise ValueError("Inherited-census record hash mismatch")
    census = json.loads(census_raw)
    inherited = census["distinct_programs"]
    complete_inherited = [row for row in inherited if row["complete_cli"]]
    current_frontier = frontier(rows)
    main_frontier = frontier(mains)
    inherited_frontier = frontier(complete_inherited)
    favorable_frontier = frontier(inherited)
    candidate_below = {
        key: candidate[key] < current_frontier[key]["value"] for key in METRICS}
    inherited_not_smaller = {
        key: favorable_frontier[key]["value"] >= main_frontier[key]["value"]
        for key in METRICS}
    report = {
        "repository": manifest["repository"],
        "repository_commit": manifest["repository_commit"],
        "python_version": platform.python_version(),
        "method": {
            "significant_tokens": "Original-spelling Python tokens, excluding comments, layout and actual docstrings.",
            "normalized_tokens": "Same token count after docstring removal and ast.unparse, followed by one newline.",
            "ast_nodes": "All ast.walk nodes after actual docstring removal; operator and context nodes included.",
            "normalized_bytes": "UTF-8 bytes after docstring removal and ast.unparse, followed by one newline.",
            "raw_bytes": "Entire original file, including comments, docstrings and formatting.",
            "boundary": "All checker source, including validation, representations, substitutions, axioms, imports, CLI and error handling. Python and its standard library are the common runtime.",
            "execution": "Checkers are read and statically parsed; none is imported or executed.",
        },
        "packaged_source_count": len(source_metrics),
        "current_program_count": len(rows),
        "current_main_count": len(mains),
        "current_alternative_count": len(rows) - len(mains),
        "all_packaged_source_hashes_verified": True,
        "all_current_imports_standard_library": True,
        "current_main_coordinate_minima": main_frontier,
        "current_all_coordinate_minima": current_frontier,
        "current_sources": source_metrics,
        "current_programs": rows,
        "candidate": candidate,
        "matched_controls": controls,
        "matched_control_differences": matched_differences,
        "candidate_strictly_below_current_all": candidate_below,
        "savings_against_current_all": {
            key: {"absolute": current_frontier[key]["value"] - candidate[key],
                  "percent": 100 * (current_frontier[key]["value"] - candidate[key])
                             / current_frontier[key]["value"]}
            for key in METRICS},
        "inherited_census": {
            "record": recorded["path"],
            "record_sha256": recorded["sha256"],
            "record_kind": "Static measurements made from inherited sources in the six pinned current archives; those older bytes are not duplicated here.",
            "distinct_program_count": len(inherited),
            "complete_program_count": len(complete_inherited),
            "complete_coordinate_minima": inherited_frontier,
            "favorable_including_core_only_minima": favorable_frontier,
            "no_inherited_coordinate_beats_current_main_minimum": inherited_not_smaller,
            "reproduction": "This script reaggregates recorded inherited measurements; only the 34 packaged current programs are remeasured from source. The record identifies exact current archive members for external source retrieval.",
        },
        "limitation": "A comparison of a pinned finite implementation corpus, not an absolute shortest-checker theorem. Historical API-only fragments are reported separately and do not set the complete-program frontier.",
    }
    (ROOT / "validation").mkdir(exist_ok=True)
    (ROOT / "validation/comparison.json").write_text(json.dumps(report, indent=2) + "\n")

    table = [r"\begin{tabular}{lrrrrr}", r"\toprule",
             r"Complete checker & Tokens & Norm. tokens & AST & Norm. bytes & Raw bytes \\",
             r"\midrule"]
    for row in mains:
        table.append(latex_escape(row["label"]) + " & " + " & ".join(
            f"{row[key]:,}" for key in METRICS) + r" \\")
    table.extend([r"\midrule", "Current coordinate minima & " + " & ".join(
        f'{current_frontier[key]["value"]:,}' for key in METRICS) + r" \\",
        r"\textbf{Finite-prefix checker} & " + " & ".join(
            r"\textbf{" + f"{candidate[key]:,}" + "}" for key in METRICS) + r" \\",
        r"\bottomrule", r"\end{tabular}"])
    (ROOT / "sections").mkdir(exist_ok=True)
    (ROOT / "sections/comparison_table.tex").write_text("\n".join(table) + "\n")
    control_table = [r"\begin{tabular}{lrrr}", r"\toprule",
                     r"Matched implementation & Norm. tokens & AST & Norm. bytes \\",
                     r"\midrule"]
    for row in matched_chain:
        control_table.append(latex_escape(row["label"]) + " & " + " & ".join(
            f"{row[key]:,}" for key in ("normalized_tokens", "ast_nodes", "normalized_bytes"))
            + r" \\")
    control_table.extend([r"\bottomrule", r"\end{tabular}"])
    (ROOT / "sections/matched_control_table.tex").write_text("\n".join(control_table) + "\n")
    print(json.dumps({"commit": report["repository_commit"],
                      "current_programs": len(rows),
                      "candidate": {key: candidate[key] for key in METRICS},
                      "current_minima": {key: current_frontier[key]["value"]
                                         for key in METRICS},
                      "candidate_strictly_below": candidate_below,
                      "inherited_no_smaller": inherited_not_smaller}, indent=2))


if __name__ == "__main__":
    main()
