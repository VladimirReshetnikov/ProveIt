"""Reproduce validation, comparison tables, and the compiled report."""
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def run(command):
    subprocess.run(command, cwd=ROOT, check=True)

def main():
    for script in ("compare.py", "tests/substitution_audit.py",
                   "tests/run_certificates.py"):
        run([sys.executable, script])
    if shutil.which("latexmk"):
        run(["latexmk", "-pdf", "-interaction=nonstopmode",
             "-halt-on-error", "report.tex"])
    elif shutil.which("pdflatex"):
        for _ in range(3):
            run(["pdflatex", "-interaction=nonstopmode",
                 "-halt-on-error", "report.tex"])
    else:
        raise SystemExit("Install a LaTeX distribution with pdflatex to build the PDF.")
    print("Built:", ROOT / "report.pdf")

if __name__ == "__main__":
    main()
