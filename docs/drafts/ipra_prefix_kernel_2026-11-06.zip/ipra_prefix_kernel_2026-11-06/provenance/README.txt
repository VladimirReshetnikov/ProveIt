SOURCE COMPARISON AND ATTRIBUTION
================================

Repository: VladimirReshetnikov/ProveIt
Current comparison commit: 36fb791c722edc2549719744c38feef74fa422fb
Current directory: docs/drafts

The six main checker files and 28 explicit standalone alternatives/controls
are copied verbatim in current_checkers/. The copied programs originate in
the user's repository and retain their original source comments. The new
report credits their mathematical calculus and implementation reductions;
these copies are comparison evidence, not newly authored kernels.

source_manifest.json gives the exact current archive path, Git blob SHA-1,
archive SHA-256, archive member, source SHA-256, and packaged path. Archive
sizes and Git blob hashes were checked against the GitHub listing. The main
rows refer to the six archives at the current commit, not to the earlier
six-archive snapshots described inside those reports.

Run from any working directory:

    python3 /path/to/ipra_prefix_kernel_2026-11-06/compare.py

The command reads and statically parses all 34 packaged current programs and
the new candidate and matched controls. It imports or executes none of those
programs. Every current program is standalone; its imported modules are
checked against Python's standard library. It regenerates:

    validation/comparison.json
    sections/comparison_table.tex
    sections/matched_control_table.tex

The entire acceptance source is charged, including grammar validation,
binding/substitution machinery, arithmetic schemas, input decoding, CLI,
imports and rejection handling. Python and its standard library are the
same external runtime for every program. Proof builders, tests and this
measurement tool are not part of any acceptance kernel.

Five metrics are deliberately kept separate:

* significant_tokens: original-spelling lexical tokens, excluding comments,
  layout and actual module/class/function docstrings;
* normalized_tokens: the same token count after removing those docstrings
  and applying ast.unparse;
* ast_nodes: all nodes from ast.walk after docstring removal, including
  operators and load/store contexts;
* normalized_bytes: UTF-8 bytes of ast.unparse output plus one newline;
* raw_bytes: the complete original source, including comments/formatting.

Normalized spelling is Python-version dependent; the generated result records
the actual Python version. In particular the Compact main checker has 981
original tokens and 989 normalized tokens, while the Composed checker has
957 under both conventions. These quantities must not be interchanged.

inherited_census.json records the additional static survey of earlier
implementations embedded within the six current archives. Its explicit
source closures were taken from comparison/census.json in Combined,
comparison/groups.json in Compact kernel, and comparisons/source_index.json
in Composed. A further scan of all 383 Python files found standalone
infer/check programs not already in those closures. There were 580 group
observations, 74 distinct source sets, and 81 distinct source-file contents.
Of the 74 groups, 66 carry a complete-CLI boundary and eight are favorably
counted core/API-only groups. Every available recorded source hash was checked.

The inherited complete-program minima are 1089 original tokens, 1089
normalized tokens, 1154 AST nodes, 3486 normalized bytes and 3817 raw bytes.
Including the eight core/API-only groups does not lower any coordinate.
Consequently no inherited comparison is smaller than the current six-main
coordinate envelope. Their source bytes are not duplicated in this archive.

The reproduction command checks the census record's hash and recomputes its
aggregate minima from the stored source measurements. It does not claim to
remeasure omitted historical source bytes. The census identifies exact
members of the six current archives, allowing a separate fresh retrieval
and full recount. The six-main and 28-alternative comparisons, which set the
relevant current frontier, are fully reproducible from packaged source.

Static measurement is not a proof of mathematical correctness or absolute
minimality. The report separately explains the native calculus, the public
falsity encoding and the new finite-prefix substitution operation.
