A SMALLER COMPLETE CHECKER FOR iPRA
==================================

Prepared for Vladimir Reshetnikov, 6 November 2026.

Start with report.pdf. Its LaTeX source is report.tex plus sections/*.tex.
The complete trusted program is checker.py. Everything required to check
certificates is in that one file, using only Python's json and sys modules.

RESULT
------
The checker has:
  907 significant original-source tokens
  907 normalized source tokens
  956 executable AST nodes
  2,998 normalized executable bytes
  3,367 original UTF-8 source bytes

The current comparison commit is:
  36fb791c722edc2549719744c38feef74fa422fb
in VladimirReshetnikov/ProveIt, docs/drafts.

The coordinate minima over all 34 packaged current standalone programs
(six main checkers plus 28 explicit alternatives/controls) are:
  957 original tokens
  957 normalized tokens
  1,013 AST nodes
  3,127 normalized bytes
  3,430 raw bytes

The candidate is strictly below every listed current coordinate minimum.
The complete source comparison is reproducible from the packaged bytes.
This is not an assertion of absolute shortest-program optimality.

WHAT IS NEW
-----------
The existing two-binder mathematical basis is retained and fully specified.
A single finite-prefix substitution operation replaces callback environments
and shares weakening, binder opening, recursive-state/counter substitution,
and the successor template used by the numerical schema.

The report includes every primitive logical rule, the explicit conversion
between genuine falsity and 0=S0, both recursion equations, and the numerical
induction/cases schema. It derives all intuitionistic first-order operations
and all quantifier-free induction instances, and gives ordinary first-order
bi-interpretations whose composites are internally the identity on the entire
number domain. The full public consequence relation is preserved, including
arbitrary retained contexts and arbitrary formulas.

The general proofs are mathematical, not Lean or Rocq formalizations.
Finite executable evidence is reported separately.

CONTENTS
--------
report.pdf / report.tex / sections/    Complete report and source
checker.py                            Entire acceptance program
FORMAT.txt                            Exact certificate format
compare.py                            Static, reproducible size comparison
controls/                             Two matched implementation controls
provenance/                           Pinned sources, hashes and survey
certificates/accept/                   37 expected acceptances
certificates/reject/                   33 expected rejections
tests/run_certificates.py              Named certificate and CLI checks
tests/substitution_audit.py            Independent substitution oracle/checks
validation/                           Actual validation and comparison results
build.py                              Run checks and compile the PDF
SHA256SUMS.txt                         SHA-256 hashes of delivered files

RUN
---
Use Python 3.10 or later:
  python3 checker.py certificates/accept/conjunction_introduction.json
  python3 tests/run_certificates.py
  python3 tests/substitution_audit.py
  python3 compare.py

The named certificate suite has 70 fixtures: 37 accepted and 33 rejected.
It rechecks eight fixtures through both normal and -O Python (16 CLI rechecks).
The substitution/boundary audit reports 4,491 successful finite checks,
including 4,000 deterministic comparisons against an independent callback
oracle and 400 tests of the exact checker caller patterns.

To regenerate the PDF and validation tables:
  python3 build.py

This also requires pdflatex and, preferably, latexmk, with the ordinary LaTeX
packages named at the beginning of report.tex. No network access is needed.

Run commands from the unpacked archive root, or pass absolute script paths.
The scripts resolve files relative to their own location.

TRUST AND PROVENANCE
-------------------
Only checker.py participates in certificate acceptance. Comparators, test
drivers, stored measurements, proof fixtures and this report are not imports
of the checker. All trusted validation and input/output are included in its
reported size. Python and the standard library form the common runtime.

The six current archive blob identities were verified. Main sources and
alternatives in provenance/current_checkers are copied verbatim for
comparison; they retain their original comments. The report explicitly
credits their inherited ideas. Historical comparison sources that cannot
lower the frontier are indexed and hashed without being duplicated; offline
reproduction reaggregates that historical record, and remeasures all current
sources from their complete packaged bytes.

The mathematical algorithm operates on finite trees. Extremely large valid
certificates can exceed a host's memory or recursion limit. No semantic
normalizer, universal primitive-recursive evaluator, imported axiom database,
or proof generator is consulted by acceptance.
