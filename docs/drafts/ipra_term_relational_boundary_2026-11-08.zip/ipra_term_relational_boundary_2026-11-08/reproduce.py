#!/usr/bin/env python3
"""Reproduce the pinned source comparison offline, without running checkers.

Usage:
    python3 reproduce.py
    python3 reproduce.py --pdf

The comparison reads, hashes, tokenizes, and parses the frozen checker
sources. It never imports or executes them. Only the SHA-256-verified,
unchanged metric module is imported. No network access is performed.
The optional PDF build requires local pdflatex and disables shell escape.
This is reproduction evidence for existing programs, not a new checker.
"""

import argparse
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'
REFERENCE_PYTHON = '3.12.14'
EXPECTED_METRIC_SHA256 = (
    'f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc'
)
COORDINATES = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
EXPECTED_FLOOR = dict(zip(COORDINATES, (317, 348, 885)))
EXPECTED_FIELDS = (
    'source_tokens', 'normalized_tokens', 'ast_nodes',
    'normalized_bytes', 'raw_bytes', 'sha256', 'core',
)
ARCHIVE_LABELS = {
    'boolean_boundary': 'Boolean boundary',
    'boolean_core': 'Boolean core',
    'boolean_separation': 'Boolean separation',
    'boxed_witnesses': 'Boxed witnesses',
    'clausal_kernel': 'Clausal kernel',
    'context_blocks': 'Context blocks',
    'context_pairs': 'Context pairs',
    'fixed_contexts': 'Fixed contexts',
    'foundation_audit': 'Foundation audit',
    'kernels_and_initializer_obstruction': 'Initializer kernels',
    'normalized_elimination': 'Normalized elimination',
    'structural_audit': 'Structural audit',
}
VARIANT_LABELS = {
    'checker.py': 'primary',
    'checker_compatible.py': 'compatible',
    'checker_exact_list.py': 'exact list',
    'checker_structural.py': 'structural',
    'checker_readable.py': 'readable',
}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def archive_label(name):
    stem = name.removesuffix('.zip')
    key = stem.removeprefix('ipra_').removesuffix('_2026-11-08')
    return ARCHIVE_LABELS.get(key, key.replace('_', ' ').capitalize())


def local_path(relative):
    """Resolve only files contained in this extracted package."""
    path = (ROOT / relative).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError(f'Manifest path leaves the package: {relative}')
    if not path.is_file():
        raise FileNotFoundError(f'Missing package file: {relative}')
    return path


def load_metric():
    path = local_path('comparison/source_measure.py')
    actual = sha256(path)
    if actual != EXPECTED_METRIC_SHA256:
        raise ValueError('The inherited metric source has changed: ' + actual)
    spec = importlib.util.spec_from_file_location('pinned_source_measure', path)
    if spec is None or spec.loader is None:
        raise RuntimeError('Cannot load the verified source-measurement module')
    module = importlib.util.module_from_spec(spec)
    sys.dont_write_bytecode = True
    spec.loader.exec_module(module)
    return module


def measure_baselines():
    manifest_path = local_path('comparison/manifest.json')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    archives = manifest['archives']
    programs = manifest['programs']
    if len(archives) != 12 or len(programs) != 12:
        raise ValueError('This pinned comparison requires 12 archives and 12 programs')
    archive_names = {entry['name'] for entry in archives}
    if len(archive_names) != len(archives):
        raise ValueError('Duplicate archive identities in the manifest')
    paths = [entry['local_file'] for entry in programs]
    if len(set(paths)) != len(paths):
        raise ValueError('Duplicate baseline paths in the manifest')

    # Check every baseline before importing the metric module. Baselines are data.
    for entry in programs:
        if entry['archive'] + '.zip' not in archive_names:
            raise ValueError('Program refers to an unlisted archive: ' + entry['archive'])
        actual = sha256(local_path(entry['local_file']))
        if actual != entry['sha256']:
            raise ValueError('Changed baseline source: ' + entry['local_file'])

    metric = load_metric()
    counts = {
        name: sum(entry['archive'] + '.zip' == name for entry in programs)
        for name in archive_names
    }
    rows = []
    for entry in programs:
        measured = metric.metrics(local_path(entry['local_file']))
        for field in EXPECTED_FIELDS:
            if measured[field] != entry[field]:
                raise ValueError(
                    f"Metric mismatch for {entry['local_file']}: {field}; "
                    f"expected {entry[field]!r}, obtained {measured[field]!r}. "
                    f'The reference runtime is CPython {REFERENCE_PYTHON}; '
                    f'this runtime is {platform.python_implementation()} '
                    f'{platform.python_version()}.'
                )
        label = archive_label(entry['archive'])
        if counts[entry['archive'] + '.zip'] > 1:
            label += ' (' + VARIANT_LABELS.get(entry['file'], entry['file']) + ')'
        rows.append({
            'label': label,
            'archive': entry['archive'],
            'file': entry['file'],
            'local_file': entry['local_file'],
            **measured,
        })

    floor = {key: min(row[key] for row in rows) for key in COORDINATES}
    if floor != EXPECTED_FLOOR:
        raise ValueError(f'Unexpected coordinatewise envelope: {floor!r}')
    frontier = [
        row['label'] for row in rows
        if not any(
            all(other[key] <= row[key] for key in COORDINATES)
            and any(other[key] < row[key] for key in COORDINATES)
            for other in rows
        )
    ]
    inventory = [
        {
            **entry,
            'label': archive_label(entry['name']),
            'root_checker_count': counts[entry['name']],
            'zip_included': False,
        }
        for entry in archives
    ]
    return {
        'status': 'PASS',
        'repository': manifest['repository'],
        'commit': manifest['commit'],
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'reference_python': REFERENCE_PYTHON,
        'archive_count': len(archives),
        'program_count': len(rows),
        'archives_with_root_checkers': sum(count > 0 for count in counts.values()),
        'verified_baseline_hashes': len(rows),
        'verified_expected_program_measurements': len(rows),
        'metric_source_sha256': EXPECTED_METRIC_SHA256,
        'manifest_sha256': sha256(manifest_path),
        'measurement_boundary': (
            'Complete standalone programs, including imports, input/output, '
            'scope validation, inference, and rejection. Genuine docstrings '
            'are removed and ast.unparse normalizes the source. Significant '
            'tokens exclude comments and layout; all AST nodes and normalized '
            'UTF-8 bytes are counted. Identifiers are not renamed.'
        ),
        'archive_verification_scope': (
            'The manifest retains the 12 original archive identities as '
            'retrieval provenance. The original ZIP files are not included '
            'and are not rehashed by this offline script. All 12 included '
            'baseline source files and the inherited metric source are '
            'verified locally.'
        ),
        'execution_scope': (
            'No network access; no baseline checker is imported or executed. '
            'The comparison measures source size and does not revalidate '
            'checker soundness or the mathematical metatheorems.'
        ),
        'comparison_status': (
            'Existing finite-corpus envelope only. No candidate checker, '
            'strict improvement, or universal lower-bound claim is made.'
        ),
        'coordinates': list(COORDINATES),
        'coordinatewise_minimum': floor,
        'minimum_attainers': {
            key: [row['label'] for row in rows if row[key] == floor[key]]
            for key in COORDINATES
        },
        'pareto_frontier': frontier,
        'archives': inventory,
        'programs': rows,
    }


def write_results(result):
    RESULTS.mkdir(exist_ok=True)
    (RESULTS / 'measurements.json').write_text(
        json.dumps(result, indent=2) + '\n', encoding='utf-8'
    )
    fields = (
        'label', 'archive', 'file', 'local_file', 'source_tokens',
        'normalized_tokens', 'ast_nodes', 'normalized_bytes', 'raw_bytes', 'sha256',
    )
    with (RESULTS / 'measurements.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(result['programs'])

    lines = [
        '% Generated offline by reproduce.py; all rows are inherited programs.',
        r'\begin{center}',
        r'\small',
        r'\begin{tabular}{@{}lrrr@{}}',
        r'\toprule',
        r'Complete inherited program & Tokens & AST nodes & Bytes \\',
        r'\midrule',
    ]
    floor = result['coordinatewise_minimum']
    for row in result['programs']:
        cells = [row['label']]
        for key in COORDINATES:
            value = str(row[key])
            if row[key] == floor[key]:
                value = r'\textbf{' + value + '}'
            cells.append(value)
        lines.append(' & '.join(cells) + r' \\')
    lines.extend([
        r'\midrule',
        r'Observed coordinate minima & \textbf{317} & \textbf{348} & \textbf{885} \\',
        r'\bottomrule',
        r'\end{tabular}',
        r'\end{center}',
    ])
    (RESULTS / 'baseline_table.tex').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def build_pdf():
    engine = shutil.which('pdflatex')
    if engine is None:
        raise RuntimeError('--pdf requires a locally installed pdflatex executable')
    local_path('report.tex')
    logs = []
    with tempfile.TemporaryDirectory(prefix='ipra-rebuild-') as temporary:
        directory = Path(temporary)
        command = [
            engine, '-interaction=nonstopmode', '-halt-on-error',
            '-file-line-error', '-no-shell-escape',
            '-output-directory=' + str(directory), 'report.tex',
        ]
        for pass_number in range(1, 5):
            completed = subprocess.run(
                command, cwd=ROOT, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, timeout=60, check=False,
            )
            logs.append(f'PDFLATEX PASS {pass_number}\n' + completed.stdout)
            (RESULTS / 'build.log').write_text('\n'.join(logs), encoding='utf-8')
            if completed.returncode:
                raise RuntimeError(
                    f'pdflatex pass {pass_number} failed; see results/build.log\n'
                    + '\n'.join(completed.stdout.splitlines()[-25:])
                )
            needs_rerun = any(message in completed.stdout for message in (
                'Rerun to get', 'Rerun to get cross-references right',
                'There were undefined references', 'Label(s) may have changed',
            ))
            if pass_number >= 2 and not needs_rerun:
                break
        else:
            raise RuntimeError('PDF references did not stabilize in four passes')
        pdf = directory / 'report.pdf'
        if not pdf.is_file():
            raise RuntimeError('pdflatex succeeded without producing report.pdf')
        shutil.copy2(pdf, ROOT / 'report.pdf')
    (RESULTS / 'build.json').write_text(json.dumps({
        'status': 'PASS',
        'engine': 'pdflatex',
        'passes': pass_number,
        'shell_escape': False,
        'temporary_build_directory': True,
        'output': 'report.pdf',
        'sha256': sha256(ROOT / 'report.pdf'),
    }, indent=2) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pdf', action='store_true', help='also rebuild the PDF locally')
    arguments = parser.parse_args()
    result = measure_baselines()
    write_results(result)
    if arguments.pdf:
        build_pdf()
    print(json.dumps({
        'status': result['status'],
        'python': result['python'],
        'archives': result['archive_count'],
        'programs': result['program_count'],
        'verified_baseline_hashes': result['verified_baseline_hashes'],
        'coordinatewise_minimum': result['coordinatewise_minimum'],
        'pareto_frontier': result['pareto_frontier'],
        'pdf_rebuilt': arguments.pdf,
    }, indent=2))


if __name__ == '__main__':
    main()
