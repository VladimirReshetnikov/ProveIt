iPRA AT THE TERM-RELATION BOUNDARY
================================
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date).

START WITH report.pdf. Complete editable sources are report.tex, sections/,
and the generated results/baseline_table.tex.

STATUS
------
The requested strict reduction below the existing complete-checker benchmark
has NOT been established. No new candidate proof checker is advertised.
This archive supplies two proved mathematical results and an exact current
comparison, with that limitation stated throughout.

NEW RESULT: FINITE-DIMENSIONAL QUOTIENT OBSTRUCTION
------------------------------------------------
If every scalar term is bounded by a unary function of one globally fixed
input coordinate, no tuple of such terms can represent an infinite binary
operation with a two-sided identity on ANY D/E with D contained in N^d.
D and E need not be definable. The identity need hold only modulo E.
Associativity is unnecessary. The proof expands a product with d+1 leaves,
finds an unused input block, and obtains a finite box representing every class.

The quantitative version shows that an n-leaf product representing an infinite
unital magma in d coordinates has total majorant-support width at least n.

The all-fixed-seeds almost-unary lemma is INHERITED from the current drafts.
The new step extends its obstruction to all finite-dimensional quotient term
representations. General relational interpretations remain outside this result.

POSITIVE BOUNDARY EXAMPLE: BOOLEAN GRAPH THEORY
--------------------------------------------
An explicitly specified theory BG has constants 0,1 and Boolean-valued graph
characteristic functions b_f for fixed primitive-recursive descriptions.
Its axioms are Boolean range, total unique graph values, and exact graph
translations of the explicitly stated iPRA axioms. All logical rules are listed.
Both whole-domain interpretations and BOTH internal identity composites are
proved. A common-signature construction strengthens this to definitional
equivalence using definitions by unique graph formulas. Every nonvariable
native term is Boolean-valued, but all arithmetic
functions are relationally represented. Boolean range is essential to the
stated recovery of the complete native characteristic functions.

This is an explicit relationalization result, not a claim that relationalization
is new or that the construction has a smaller checker. No literature-wide
priority claim is made. The universal proofs are written proofs, not a Lean or
Rocq formalization.

PINNED COMPARISON
-----------------
Repository: VladimirReshetnikov/ProveIt
Commit: 06e097f723c659030816e0194e5eb7e8c607ba9b
Directory: docs/drafts/
12 current archives; 12 root-level standalone checker programs.

Complete normalized coordinate minima: 317 tokens / 348 AST nodes / 885 bytes.
Initializer primary checker:             318 tokens / 352 AST nodes / 885 bytes.
Initializer structural checker:          317 tokens / 348 AST nodes / 908 bytes.

No single program attains every minimum. These are finite observed minima,
not universal lower-bound theorems. The unchanged whole-program normalizer,
12 unchanged comparison sources, archive identities and checksums are included.

REPRODUCE OFFLINE
-----------------
  python3 reproduce.py
  python3 examples/semantic_examples.py
  python3 reproduce.py --pdf

The first command verifies hashes and reproduces all size measurements.
The second runs finite explanatory semantic examples. It is NOT a theory
proof checker and does not prove the universal theorems by testing.
The last additionally requires pdfLaTeX and the packages in report.tex.
The recorded measurement runtime is CPython 3.12.14.

CONTENTS
--------
report.pdf / report.tex     Report and principal source
sections/                  Complete mathematical text and axiomatizations
comparison/                Frozen sources, metric, provenance
examples/                  Small semantic illustrations
results/                   Reproducible measurements and validation receipts
reproduce.py               Offline measurement and optional PDF build
ATTRIBUTION.txt             Precise inherited/new contribution boundaries
LICENSE-inherited.txt      License for retained ProveIt comparison material
SHA256SUMS.txt              Package integrity manifest

No changes have been pushed to GitHub.
