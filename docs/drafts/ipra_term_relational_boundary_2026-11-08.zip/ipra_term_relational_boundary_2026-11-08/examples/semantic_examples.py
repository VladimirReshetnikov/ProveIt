"""Finite illustrations of the written theorems; not a proof checker.

Only the standard library is used. This file does not claim to verify the
universal mathematical results or their intuitionistic derivations.
"""
from itertools import product
import json
from pathlib import Path


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def finite_quotient_examples():
    """D=N^2, E congruence modulo m in coordinate 0; M has finite range."""
    cases = 0
    rows = []
    for modulus in range(2, 8):
        identity = (0, 0)

        def equivalent(a, b):
            return a[0] % modulus == b[0] % modulus

        def multiply(a, b):
            return ((a[0] + b[0]) % modulus, 0)

        for a in product(range(2 * modulus + 1), range(3)):
            require(equivalent(multiply(identity, a), a), 'left identity')
            require(equivalent(multiply(a, identity), a), 'right identity')
            for inputs in [(a, identity, identity),
                           (identity, a, identity),
                           (identity, identity, a)]:
                result = multiply(multiply(inputs[0], inputs[1]), inputs[2])
                require(0 <= result[0] < modulus and result[1] == 0,
                        'finite representative box')
                require(equivalent(result, a), 'tree preserves quotient class')
                cases += 1
        rows.append({'modulus': modulus, 'representative_box_size': modulus,
                     'quotient_size': modulus, 'dimension': 2})
    # Infinite projection magmas show that just one identity law is insufficient.
    require(all((lambda x, y: x)(x, 0) == x for x in range(20)),
            'projection has a right identity')
    require((lambda x, y: x)(0, 1) != 1, 'projection has no left identity')
    return {'sample_tree_cases': cases, 'finite_quotients': rows,
            'one_sided_identity_counterexample': 'projection M(x,y)=x'}


def graph_examples():
    """Check the explicit characteristic formula and native value recovery."""
    functions = [
        ('successor', 1, lambda x: x + 1),
        ('predecessor', 1, lambda x: max(x - 1, 0)),
        ('addition', 2, lambda x, y: x + y),
        ('multiplication', 2, lambda x, y: x * y),
        ('constant_seven', 0, lambda: 7),
    ]
    checked = 0
    native_recoveries = 0
    rows = []
    for name, arity, function in functions:
        local = 0
        for arguments in product(range(5), repeat=arity):
            value = function(*arguments)
            for proposed in range(max(9, value + 2)):
                difference = max(value - proposed, 0) + max(proposed - value, 0)
                chi = int(difference != 0)
                native_b = 0 if proposed == value else 1
                require(chi in (0, 1), 'Boolean range')
                require((chi == 0) == (proposed == value), 'zero characterization')
                require((chi == 1) == (proposed != value), 'one characterization')
                for z in range(4):
                    graph_chi = (z == chi)
                    require(graph_chi == (z == native_b), 'native composite')
                    native_recoveries += 1
                checked += 1
                local += 1
        rows.append({'function': name, 'arity': arity, 'sample_graph_tuples': local})
    # Without Boolean range, zero sets agree but the native function is not recovered.
    source_value, proposed = 3, 9
    old_characteristic = 0 if proposed == source_value else 2
    composite_value = 0 if proposed == source_value else 1
    require((old_characteristic == 0) == (composite_value == 0), 'equal zero sets')
    require(old_characteristic != composite_value, 'failed native recovery')
    return {'sample_graph_tuples': checked, 'sample_native_recoveries': native_recoveries,
            'functions': rows,
            'range_omission_example': {'original_false_value': old_characteristic,
                                       'composite_false_value': composite_value,
                                       'same_zero_set': True}}


def main():
    result = {
        'status': 'PASS',
        'scope': 'Finite semantic illustrations; not proof-assistant verification.',
        'quotient_examples': finite_quotient_examples(),
        'graph_examples': graph_examples(),
    }
    destination = Path(__file__).resolve().parents[1] / 'results' / 'semantic_examples.json'
    destination.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
