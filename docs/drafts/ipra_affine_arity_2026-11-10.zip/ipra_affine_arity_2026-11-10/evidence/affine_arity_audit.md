# Independent audit of affine arity depth and bottom decoding

## Conclusion

The proposed change has a coherent soundness argument, and this focused
review found no counterexample. It is a genuine new direction relative
to the inspected current and recursively embedded corpus. It is not a
new arithmetic basis: it simplifies the representation and checker for
the existing native Eq/Q/D theory.

The essential combination is:

1. Replace the depth-increment table by `len(a) + 1`.
2. Decode a binary formula with one extra zero-valued numerical slot.
3. Decode formula arrays of arity at least four as the existing false
   equation `0 = S(0)`; decode numerical arrays of those arities as zero.
4. Require exactly three fields before applying D introduction.

Dropping item 4 is unsound: an arbitrary larger-arity root could otherwise
enter the introduction branch even though its meaning is falsity. The
exact unpacking or starred-call guard is a logical requirement, not
optional malformed-input hygiene.

## Precise meaningful decoder

Let `rho` be a list of protected numerical values, nearest first.
Numerical zero is the scalar 0. Positive coordinates `2j+1,2j+2` name
the same slot `rho[j]`, for `j >= 0`; retained negative coordinates are
rigid numerical parameters. For canonical integer/array syntax:

| Shape | Numerical reading `N_rho` | Formula reading `F_rho` |
|---|---|---|
| Empty array | 0 | `0=0` |
| One child `[a]` | `S N_(0,rho)(a)` | `Q_y F_(y,rho)(a)` |
| Two children `[s,t]` | 0 (annotations ignored semantically) | `N_(0,rho)(s) = N_(0,rho)(t)` |
| Three children `[n,a,h]` | `I(N_(0,0,rho)(n), N_(0,0,rho)(a); v.N_(v,v,rho)(h))` | `D_(x,y) F_(y,x,rho)(h)`; the other two fields are annotations |
| Four or more children | 0 | `0=S(0)` |

Scalar formula aliases retain their inherited truth reading. Annotations
and junk children are still traversed by the implementation, so they can
cause rejection; their traversal never adds mathematical content.

For meaningful constructors the new increment has exactly the needed
parity and environment size:

- Q/S: `1+1=2`, one protected slot.
- Eq: `2+1=3`, a change from formula parity to numerical parity plus
  one dummy zero slot.
- D/I: `3+1=4`, two protected slots.

For arities at least four, the child-depth arithmetic has no semantic
effect because the parent already denotes a constant. This is why an
unbounded arity table is unnecessary.

The opening/substitution lemma is proved by structural recursion over
meaningful constructors. The Eq case uses the added zero slot. The junk
cases are constant on both sides of the lemma. A validated numerical
replacement image has no meaningful positive external coordinate, so
inserting it under an extra outer zero slot does not change its reading.

## Why elimination from junk is safe

For a verified major of arity at least four, the decoded premise is
`0=S(0)`. Its tail `m[2:]` can have any arity and decode to any native
formula. Using it as a local assumption is sound by intuitionistic
explosion from the already proved false major. The continuation need
not encode a special junk rule.

This argument does not assume consistency of iPRA. It is a proof
translation: first translate the checked major into a proof of falsity,
then use the ordinary intuitionistic falsity-elimination rule. The
inherited native-to-iPRA interpretation already establishes that
`0=S(0)` implies genuine falsity.

For a proper Eq/Q/D major, the old elimination cases remain, with the
new Eq padding included in the common opening lemma. The root shape
is unchanged by opening, so a junk major cannot masquerade as Eq/Q by
normalization.

## Why introduction requires exact shape

The DI branch must extract its matrix only from a three-child array.
Both `_, _, a = a` and a correctly parameterized starred call of the
form `i(*a[2:], t=t, d=2)` enforce that shape on successful execution.
For a list of length two the matrix is absent; for length at least four
the extra positional argument causes unpacking failure or a duplicate
argument error. The source variant must actually retain this condition.

After opening the witness, a matrix of even junk arity may take the
progress branch. This is sound because its decoded matrix is the literal
equation `0=S(0)`. An odd junk arity takes only the case branch; allowing
fewer induction certificates for a junk alias is harmless. Proper unary
Q and ternary D matrices still cannot receive progress induction.

No claim that every raw alias of every theorem has an accepted
certificate is needed. Completeness should be stated for the canonical
Eq/Q/D encodings. The object theory and its existing bi-interpretation
remain the same.

## Generated computation: the nontrivial obligation

The current constructed-computation branch receives predecessor `p`,
seed `a`, update `h`, and a base/step flag. It builds an equation of the
form

```
[[flag and [p], a, h], open(h, [p,a,h], 1) if flag else a]
```

and then opens the equation at the newly admitted negative label `w`.
Because Eq now adds one zero slot, its two numerical sides must be
decoded with environment `(0,)`, not the empty environment. Forgetting
this change would invalidate the numerical audit.

The inherited known-instance argument adapts as follows.

**Base case.** After substituting `w=0`, the seed under the source
iterator's two extra zero slots and the seed on the right have identical
zero-completed meanings. The added Eq zero slot occurs on both sides.
The generated equation is I0 after zero completion.

**Step, recursive image used.** A meaningful state occurrence in the
update causes the opener to evaluate the recursive image at numerical
root depth 1 before copying it. This still excludes every meaningful
positive external coordinate from the image. In particular the newly
added Eq padding cannot turn a formerly external coordinate into a
new meaningful dependency. Extra zero slots outside a root-validated
term do not affect its interpretation. The source and right-hand
recursive values therefore agree, and the zero instance is IS.

**Step, recursive image unused.** The update has no meaningful outer
state occurrence: any such occurrence would have requested the image.
The same observation excludes a meaningful new negative label before
it is admitted. The update is independent of the outer state and of
the extra surrounding padding. Counter and seed may retain dependence
on `w`, but after setting `w=0` the computation is a legitimate IS
instance with constant-in-state update. Junk numerical subtrees do not
invalidate this reasoning; their entire value is zero regardless of
the descendants the validator happened to traverse.

Thus the generated equation `H(w)` has an iPRA proof of `H(0)`. Since
`w` is absent from the retained context and conclusion, substitution
and cut discharge its use. This review supports the known-zero-instance
statement; it does not claim every generated `H(w)` is uniform in `w`.

## Focused independent finite audit

`affine_supply_audit.py` implements the opener with the new affine depth
and a separate numerical decoder with the extra Eq zero slot. It tests
the actual generated equation's zero instance, with two old parameters
varying independently over 0,1,2. Inputs include positive/negative and
fractional scalar aliases, binding-boundary coordinates, and numerical
arrays of arities 4 through 6, together with randomly generated trees.

Recorded outcome in `affine_supply_result.json`:

- 120,800 attempted packets.
- 84,369 successfully generated equations.
- 759,321 evaluated valuations.
- Zero computation-budget cutoffs.
- No false zero instance and no decoder exception.

This finite audit targets a real remaining risk in the new construction.
It supplements the structural argument; it is not a formal proof or
evidence of arbitrary-element bi-interpretability by itself.

## Novelty scan

All 16 current ZIPs and their recursively embedded sources were searched:
22 unique archives in total. A Python AST search for `len(anything)+1`
or `1+len(anything)` found ten occurrences, all ordinary packaging or
manifest counters. No inspected proof checker uses that depth formula.
Text searches found no proposal to decode larger-arity formula trees as
bottom, no affine arity/depth replacement, and no equivalent deletion
of the bounded depth table through junk-bottom decoding.

By contrast, the existing reports explicitly say traversed arrays of
arity above three reject. The closest existing ideas are permissive
scalar/iterable aliases, semantically ignored numerical annotations,
and known-instance computation discharge. Those are inherited and
should be credited. The new combination changes the arity semantics
and proves the safe behavior needed to remove the table.

This establishes novelty relative to the inspected supplied corpus,
not literature-wide priority or a globally minimal axiomatization.
