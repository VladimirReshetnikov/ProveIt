# Independent audit of the pinned iPRA comparison set

## Scope and result

The source snapshot is `VladimirReshetnikov/ProveIt` commit
`3fb35a5f2c0cb506180bede7ee3b9b5f93d4bc9d`, directory `docs/drafts`.
All 16 current ZIP files were obtained and their Git blob identities were
checked against the pinned GitHub listing. Recursively inspecting embedded
ZIP files adds six unique historical archives. Duplicate copies of the
same ZIP bytes are counted once. This yields 22 unique archives, 516
Python source occurrences, and 297 files that pass the static public-checker
candidate screen.

The inclusive observed coordinate envelope is:

| Coordinate | Minimum | Complete program attaining it | Other coordinates | Raw gzip -9 bytes |
|---|---:|---|---|---:|
| Normalized significant tokens | 277 | `ipra_constructed_computation_2026-11-10/code/checker_explicit.py` | 317 AST nodes, 684 normalized bytes | 403 |
| AST nodes | 311 | `ipra_transient_seed_2026-11-10/code/checker_structure.py` | 280 tokens, 705 normalized bytes | 393 |
| Normalized UTF-8 bytes | 672 | `ipra_counter_congruence_2026-11-10/ancillary/zero_product.py` | 281 tokens, 322 AST nodes | 397 |

Two matched source programs in the scalar-successor archive also attain
277 tokens. Their complete profiles are 277/317/684 and 277/319/679.
They are included even though they are reference controls, rather than
the archive's headline candidate. Excluding them would still leave the
constructed-computation explicit candidate at 277 tokens.

These are minima among inspected implementations, hence upper bounds on
an unknown implementation optimum. They are not mathematical lower
bounds on every axiomatization or programming language. A new complete
program with fewer than 277 tokens, 311 AST nodes, and 672 normalized
bytes would beat this conservative observed envelope in all three
coordinates simultaneously. Merely beating a report's older baseline
(often 281/315/685) does not beat the current snapshot.

The envelope is attained by different programs. Reporting the tuple as
the size of one existing implementation would be incorrect.

## Measurement boundary

The normalizer removes genuine Python module/function/class docstrings,
then uses `ast.unparse(tree) + '\n'`. Significant tokens exclude comments,
line-ending, indentation, and end-marker tokens. AST nodes are all nodes
visited by `ast.walk` after docstring removal. Bytes are normalized UTF-8
bytes. The whole module is counted: syntax handling, substitution,
freshness, rule checking, JSON import statement, stdin driver, exception
handling, and ACCEPT/REJECT output.

The minimum attainers were read directly. Each is a standalone module
whose only import is Python's standard JSON module or `load` from it.
There is no project-specific imported theorem library, rule table,
arithmetic evaluator, producer, trusted certificate translator, or
external generated data in its trusted project closure. The constant
depth tables inside the source are charged. Certificate producers and
test suites are untrusted support and are not needed by the checker.

As in the supplied comparison protocol, the interpreter and standard
library implementation are fixed runtime assumptions. Their source
code is not added to the checker byte count. Counting an import statement
does not mean that the JSON parser itself has no trusted complexity.
This common runtime boundary must remain explicit in any new comparison.

The AST-minimum program uses an exception-based iterable traversal rather
than a direct list-type test. Its report explicitly admits the harmless
aliases `"" -> []`, `{}` to `[]`, and a dictionary with the single empty
key to `[[]]` in traversed tree positions. Nonempty strings recurse into
their characters and are rejected through CPython's finite recursion
limit. Thus its raw-input behavior is tied to that runtime boundary;
it is not a separately established terminating algorithm on arbitrary
JSON under an idealized unlimited recursion stack. This program remains
in the conservative comparison envelope, rather than being silently
excluded to make a new claim easier.

The raw byte-minimum program detects lists with `a * 0 == []`. This is an
implementation trick applicable to exact JSON built-in values, not a new
arithmetic axiom. Unsupported objects fail through exception handling.
No new unsoundness finding is claimed here.

## Gzip information requested by the user

The script records both raw-source and normalized-source compressed sizes
using `gzip.compress(data, compresslevel=9, mtime=0)`. The timestamp is
fixed and no filename is embedded. This measures the ordinary gzip
maximum compression level, not an optimization objective. For all three
minimum sources above, the result was independently compared with
`gzip -9 -n -c`: the bytes agree exactly.

The smallest raw gzip result among the screened complete checker files
is 381 bytes for `ipra_local_rewriting_2026-11-10/code/kernel_balanced.py`.
Its normalized source profile is 286 tokens, 320 AST nodes, and 736
bytes. This illustrates why gzip should remain informational: the
compressed-source ordering differs from the structural ordering.

Raw and normalized compression can differ substantially when a source
has explanatory comments. For example the successor-recursion archive
contains the same 305/351/738 normalized checker in a commented source
whose raw gzip is 709 bytes and in a normalized source whose gzip is
428 bytes. A fair report should name the exact bytes being compressed.

## Existing ideas: novelty map

The table records the principal contribution asserted in each inspected
report, rather than independently certifying all its mathematical proofs.
Written proof claims in these archives are not Lean/Rocq formalization.

| Current archive | Existing contribution and implications for a new proposal |
|---|---|
| Atomic transport | General hypothesis use and compound-formula equality transport are derived from elimination-only assumption use and transport whose motive is a literal equation. The report itself acknowledges an earlier fixed-position transport predecessor. Repeating atomic-transport reduction is not new. |
| Constructed computation | A certificate gives a predecessor and a base/step flag; the checker constructs the source counter. State-independent updates allow validation of unused substitution images to be delayed. A separate counterinterpretation proves that simultaneously restricting DI witnesses to zero/variables and QE targets to one/variables loses native theorems, even after adding finitely many numeral QE targets. |
| Counter congruence | With the existing counter-aware successor recursor, congruence only in its counter plus left-root equation replacement derives all numerical and then formula transport. The proof uses numerical cases. Independent-initializer deletion is obstructed by monotonicity or a one-coordinate majorant. Incidental Python source tricks, not the new congruence calculus, attain its byte minimum. |
| Elimination assumptions | Assumptions may be used directly only as elimination majors. General identity is derived with an expansion of 4+3d(A) nodes for object formula depth d. A new claim to eliminate hypothesis lookup needs to go beyond this result. |
| Endpoint certificates | The certificate supplies source, target, and template; the checker validates them against its major premise instead of recovering two different elimination shapes. The source savings are certificate engineering. |
| Flat computation | Successor computations are restricted to boxed predecessors and other instances recovered by equality. Generated equations are supplied through three independent certificate fields and an explicit tag. A uniform fresh-parameter computation argument removes the need for an exceptional zero-instance discharge. Zero is directly available as a logical witness. Main checker: 278/314/679. |
| Generated assumptions | Computation becomes a locally generated assumption. A known zero instance suffices for discharge by substitution and cut. Arithmetic and logic share a continuation. Inapplicable equality/Q requests preserve the goal and add truth. Main checker: 281/318/685; separate AST profile: 283/315/710. |
| Guarded elimination | A failed elimination match retains the original obligation and appends a provable truth assumption. This permits equality, conditional-universal, and paired elimination to share control flow. |
| Local rewriting | One-occurrence equality replacement and elimination-only hypotheses recover unrestricted transport and assumption use. Scalar successor-seeded recursion is completed by finite transposition and predecessor construction. The permissive iterable checker gives the best observed gzip FYI figure. |
| Named specialization | Arbitrary QE targets can be reduced to numerical variables and the single numeral 1 by equality naming, using a selector before the full arithmetic bootstrap. Either target class alone fails. Separate source savings come from shared continuations and a failed-match state invariant. |
| Scalar countdown | A fixed countdown reflection sentence plus an explicit uniqueness rule replaces quantifier-free induction over its stated base. This is a finite completion theorem, with a much larger full checker, not a size record. |
| Scalar successor | The previously open scalar successor-seeded recursor with only its old state as update input has a whole-domain predecessor. Finite permutation/conjugation, affine comparison, and saturation supply the bootstrap. The unresolved-left-inverse question in older drafts is now resolved. |
| Shared continuation | Endpoint certificates, shared continuation, and elimination-only assumptions are combined. The proposed scalar successor-seeded basis was left open here, but is completed in later current drafts. |
| Successor recursion | A counter-aware successor-seeded recursor gives predecessor, a selector, and fixed primitive-recursion compilation directly, with two numerical constructors and two computation schemas. A new claim to eliminate primitive successor should acknowledge this. |
| Successor seed completion | Another complete predecessor construction for scalar successor-seeded recursion, using affine alignment, saturation, and finite correction. No new open predecessor gap remains at this snapshot. |
| Transient seed | Transient states and a reset cycle give a predecessor for scalar successor-seeded recursion. A native-logic Boolean cancellation bootstrap avoids circularly assuming full logical macros. A seed tied to the update has a one-coordinate majorant and cannot define addition, general selection, or injective pairing by terms. |

## Comparison implications

The compact checker family implements a native formula language built
from equations and paired/closure binders. In its familiar presentation,
`Q_y B` reads `B(0) -> forall y B(y)` and `D_{x,y} B` reads
`exists x (B(x,0) -> forall y B(x,y))`. The full intuitionistic logical
bridge, actual-equality reflection, and fixed-description arithmetic
compiler are inherited across most proposals. A new source-size result
does not by itself establish a new arithmetic foundation.

Several old headline candidates are dominated by newer complete programs.
For instance constructed-computation's explicit 277/317/684 dominates
generated-assumptions' 281/318/685; flat computation's 278/314/679 also
dominates that old baseline and the scalar-successor main profiles.
Keeping all of them in the inclusive envelope is harmless and avoids
subjective decisions about which mathematical ideas should be discarded.
The three current coordinate attainers remain the conservative target.

The equality/logic reductions already explored include identity
expansion, atomic transport, one-occurrence transport, fixed-counter
congruence, shared continuations, and guarded neutral commands. Numerical
reductions already explored include removal of primitive successor,
removal of the old-counter update slot, scalar predecessor bootstraps,
countdown/reflection completions, and several obstructions to deleting
the independent initializer. A new architecture should distinguish its
contribution explicitly from these results.

## Reproduction files

`measure_baselines.py` is a static measurement script; it executes no
supplied draft code. It verifies pinned ZIP Git blob hashes, recursively
reads unique embedded ZIPs, and generates `baseline_summary.json`,
`baseline_metrics.csv`, and `recursive_python_metrics.json`. Its simple
ACCEPT/REJECT/JSON-load screen intentionally includes support scripts;
all minimum attainers were manually inspected to exclude such false
positives at the frontier. No source passing that broad screen falls
below the displayed minima.

The root run was:

```
python3 audit/measure_baselines.py --manifest pinned_sources.json --baselines baselines --output audit
```

The measurements use CPython 3.12.14. AST-unparse output is version
sensitive, so the runtime version is part of the reproducible comparison.
