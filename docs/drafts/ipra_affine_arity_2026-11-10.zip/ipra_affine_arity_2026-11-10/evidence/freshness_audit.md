# Focused audit: global versus lexical freshness

## Finding

No soundness counterexample was found from the fact that the global
negative-name floor remains lowered after a major-premise subproof
returns. The surviving names do not carry their former assumptions.
Private contexts are constructed with `g + [...]`, and the caller
retains its original `g`. A name allocated in a finished subproof can
therefore be reused later only as an arbitrary numerical parameter.
This is a bookkeeping complication, not evidence that an existential
witness assumption escapes its scope.

This is a focused mathematical/source audit of that mechanism, not a
formal certification of every checker alias or of the whole iPRA bridge.

## Why discharged names do not leak assumptions

Write a checking call schematically as `c(A, Gamma)`. The root-opening
check is evaluated before the call allocates any new negative name,
even when the hypothesis-membership test subsequently fails. Thus every
meaningful numerical name in the requested conclusion and retained
context is already available.

Suppose checking a major `M` allocates new labels `D`, then returns.
Those labels do not occur meaningfully in the `M`, `Gamma`, or outer
`A` that were fixed before the subproof. The caller does not inherit
any hypotheses introduced in that subproof. Its later certificate
payload may nevertheless mention labels in `D`; these are now allowed
by the globally lowered floor. They are simply additional arbitrary
parameters in the continuation.

The relevant elimination lemma is elementary:

> If a derivation of `Gamma |- A` contains auxiliary free numerical
> parameters `D` absent from `Gamma,A`, uniformly substitute zero for
> `D` throughout the derivation, first renaming all remaining local
> eigenparameters to avoid capture. The result is still a derivation
> of `Gamma |- A`.

The native rules are stable under this substitution. Literal equations
remain literal equations, so the induction restriction is preserved.
The finite primitive-recursive descriptions remain fixed expressions.
The fresh-parameter side conditions are restored by the prior
alpha-renaming. Substitution may change later local goals and local
assumptions containing the auxiliary parameters, but it leaves the
retained outer sequent unchanged.

The existing named-specialization translator explicitly implements
this idea. Its `Compiler.forget` method assigns zero to private labels
of a pruned subproof, with the comment that later certificates may
still mention globally allocated names as arbitrary parameters. This
is present at:

`ipra_named_specialization_2026-11-10/code/translate_uniform.py`

The code is copied again in the guarded-elimination archive as
`successor_variant/reference/translate_uniform_original.py`.

## What context-local freshness can simplify

If every continuation adds exactly one assumption, context length can
also count local parameter levels. In a lexical implementation,
`k = -len(g)` is local to the call, and the opening function closes over
that local `k`. A recursively checked major gets its own local floor;
its allocations do not affect the caller. The caller then uses
`k-1` for its next local parameter. Labels can be reused in disjoint
subproofs because the contexts and opening closures are disjoint.

This removes global trace-dependent numbering and the need to explain
continued availability of private sibling-subproof names. A canonical
certificate translation should alpha-rename live parameters to lexical
levels and replace dead arbitrary names by zero. It must not claim
that the same raw JSON certificate is accepted with exactly the same
meaning in both naming schemes. The existing reports correctly warn
that certificate reserialization is required.

Context length is a valid level count only because the compact calculus
introduces one parameter alongside each appended assumption, including
administrative truth assumptions. A general proof calculus that
introduces several parameters per hypothesis or changes contexts in
other ways cannot infer this invariant merely from `len(g)`.

## What context-local freshness does not simplify by itself

There are two distinct issues:

1. Labels allocated in a completed major subproof remain globally usable.
2. An arithmetic packet may contain the label that is about to become the
   new continuation parameter, and the generated equation may acquire
   dependence on that label after opening.

Lexical freshness addresses the first. It does not automatically
address the second. The generated/constructed-computation presentations
justify an assumption `H(w)` using a proof of its zero instance `H(0)`
and freshness of `w` in the retained conclusion/context. Their known-
instance discharge lemma remains necessary unless a stronger arithmetic
generator theorem is supplied.

The flat-computation draft supplies such a stronger theorem: each
successfully generated equation is a computation theorem uniformly in
the newly admitted parameter. Its analysis separates a recursive image
that is actually used (therefore root-validated before the new label
exists) from an unused image (the update is state-independent). That
uniformity is a property of the generator and sorted decoder, not a
consequence of changing the freshness counter alone.

## Exact prior art in the supplied corpus

The local-context-depth idea is already present in current embedded
sources and must not be claimed as newly discovered.

### Fixed-position archive

The counter-congruence ZIP embeds
`reference/ipra_fixed_position_2026-11-09.zip`. Within it:

`ipra_fixed_position_2026-11-09/reference/lexical_scope_experiment.py`

starts its checker with:

```python
def c(a, g, s=1):
    k = -len(g)
    i = lambda a, t=None, d=0: ...
```

The report's subsection **Scope simplification and the current minimum**
describes the same context-length eigenvariable scheme. It measures
301 tokens / 350 AST nodes / 881 normalized bytes, against an older
299/345/880 comparator. It explicitly calls the prototype exploratory,
not the fully certified positive implementation of that report.

The unchanged extracted prototype is saved as
`audit/reference/prior_lexical_scope_experiment.py` for inspection.

### Elimination-assumptions archive

`evidence/independent_mathematical_review.txt` reports another prior
context-depth-local-freshness prototype at **300/354/763**, against
**298/349/762**. It states that the prototype was not a size win.

### Successor-seed-completion archive

`evidence/checker_profiles.txt`, under **Explorations not included in
the delivered frontier**, says branch-local freshness can replace the
global floor but its best direct-J profile was **286/321/683** and
needed certificate reserialization.

### Additional historical mention

The embedded three-schema archive's
`evidence/reviews/final_kernel_audit.txt` also discusses replacing the
global floor by local context depth. A recursive text search of all
22 unique current/embedded archives found the prior records above.

## Consequence for a new claim

A new lexical implementation could still be a useful, simpler,
measurably smaller combination with the later constructed-computation
or shared-continuation architecture. Its honest novelty claim would be
that successful integration, a strengthened soundness proof, or a
specific new reduction enabled by lexical levels. Neither the lexical
level idea itself nor the replacement of global state alone is new
relative to the supplied corpus. No false equivalence was established
by this focused audit.
