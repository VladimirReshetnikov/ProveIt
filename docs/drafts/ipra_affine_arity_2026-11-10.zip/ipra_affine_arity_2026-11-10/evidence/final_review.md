# Independent final mathematical and evidence review

## Reviewed inputs

- Main manuscript: `output/ipra_affine_arity_2026-11-10/report.tex`.
- New representation argument: `output/ipra_affine_arity_2026-11-10/theory/linear_arity.tex`.
- Selected checker: `checker_work/affine_bytes.py`.
- Copied bridge sources and `reference/provenance.json`.
- Existing focused receipts `affine_replay.json`, `affine_validation.json`,
  `affine_supply_audit.json`, and `affine_guard_controls.json`.

This review did not rerun broad testing or inspect the rendered PDF. The
root agent is responsible for final artifact assembly and visual QA.

Initial reviewed SHA-256 bindings:

| Input | SHA-256 |
|---|---|
| `report.tex` | `9fa7a191f3752f14e2708bfe351a147a60ef7daa7f2e1d2643598b141cf6e803` |
| `theory/linear_arity.tex` | `88d1c408ce4797050084c6c4f7cc27486163ed90244adbc970a0c4cf5a230d24` |
| `checker_work/affine_bytes.py` | `6bf8d9723cd42b83f0691c6770fadbc03069cad1b226e6fabe39b1bbb9b4aca8` |

## Verdict

No new soundness counterexample, induction strengthening, hidden trusted
verifier, or unjustified raw-alias completeness claim was found. The report
correctly limits the numerical result to a byte-size improvement, treats
gzip as informational, distinguishes the object theory from serialized
representations, and acknowledges that the significant foundational
breakthrough requested has not been obtained.

Two short mathematical clarifications should be incorporated before final
delivery; they do not require a checker change or more testing:

1. In the new fragment's soundness proof, replace the unqualified sentence
   that computation packets "construct instances" of the iterator
   equations by the explicit statement that **the zero instances of the
   generated assumptions are derivable from I0/IS**, followed by the
   known-instance discharge lemma. The current main manuscript already
   gives the correct H(0) argument. This edit makes the local proof agree
   with it and avoids implying uniform H(w).
2. Before applying the inherited gates/selectors to arbitrary formulas,
   explicitly replace Q subformulas by their interderivable unused-witness
   D forms. The reproduced selector construction is defined on Eq/D
   syntax. The copied ordinary bridge proves
   `Q_y B <-> D_(u,y) B` with unused u, so this is an available
   preprocessing step, not a missing theorem. The main summary should
   mention it rather than silently applying an Eq/D definition to Eq/Q/D.

A third useful terminology clarification is that total decoding concerns
array shapes under the numerical scope discipline. It does not mean that
every arbitrary JSON packet field denotes an object expression. The text
already rejects non-orderable values and exempts unused payload fields;
one explicit sentence would prevent reading the heading too broadly.

## Fractional numerical aliases

The proposed convention is consistent with the opener's interval tests:

- `[0,1)` denotes numerical zero.
- `[2j-1,2j+1)` denotes protected slot rho_j, for j >= 1.
- An allocated negative interval `[r,r+1)` denotes eta(r), where r is
  an integer. Equivalently this uses the integer floor of the negative
  retained value, not truncation toward zero.

The lower floor and every depth are integers, so retention inequalities
commute with this decoding. Python-equal numeric aliases receive equal
meanings. Booleans coincide with their integer aliases. Non-finite
numbers cannot survive the finite retention test at a meaningful scalar
position; a successful opening either supplies a checked image or maps
the irrelevant formula scalar to truth. An unused command field needs
no decoding. No additional parameter or arithmetic operation is created.

The selected product list test `a * 0 == []` admits precisely actual
lists among the relevant JSON built-in values. Numeric multiplication
yields a number, string multiplication yields the empty string, and
unsupported values raise. The `0j` default is not JSON-supplied and
cannot pass the ordered numerical check, so it remains a rejection
sentinel rather than a semantic scalar alias.

## Neutral Boolean minor fallback

The selected source uses

```
a = guard and i(t, s) or a
```

after a proved major. If the target checks match but the would-be minor
is Python-false, the original target remains the proof obligation. For
an Eq or Q major the appended tail is still the empty-array truth
assumption. The ensuing successful continuation therefore proves the
original target under a provable truth assumption and an unused fresh
parameter. Substitution and cut remove that administrative step. The
checker does not accept the target merely because the guard matched.

A canonical native formula has a nonempty Eq/Q/D root, so this fallback
cannot suppress a required inference in the canonical completeness
translation. This source variant can have a different accepted raw
certificate language from the explicit-if reference; the report does
not need or claim exact raw-protocol equivalence.

## Arity soundness and canonical scope

The selected bitwise expression `d - ~len(a)` is exactly
`d + len(a) + 1` for Python integers. The representation proof uses
the necessary extra zero coordinate under Eq and preserves the Q/S
and D/I increments.

The starred call `i(*a[2:], t=t, d=2)` imposes exactly three target
children on successful DI execution. It closes the one route that
would otherwise introduce a junk root decoded as falsity. Larger
verified majors are harmless through existing explosion, not through
an unproved new bottom predicate. Larger matrices may decode to the
literal false equation and have the corresponding admissible case or
progress reading. Proper Q/D matrices cannot acquire progress induction.

The report explicitly promises completeness only on canonical object
encodings. It does not require every alias to be provable, nor a
serialization-level identity composite. The whole-domain actual-equality
bi-interpretation is a claim about the fixed object theory.

## Inherited bridge verification

All five copied mathematical sources match their original pinned
generated-assumptions files byte for byte, and every recorded hash in
`reference/provenance.json` matches:

- `inherited_choice_basis.tex`
- `scalar_predecessor.tex`
- `equality_reflection.tex`
- `primitive_recursion.tex`
- `inherited_ordinary_bridge.tex`

The copied license also matches. The main report attributes the appendix
sections as unchanged inherited work and explains that their historical
"old/new" wording refers to those earlier sources. No new formal
verification of that inherited bridge is claimed.

The visible arithmetic dependency order is appropriate: predecessor
before reflected equality; reflected equality before arbitrary
quantifier-free induction; then pairing/general recursion. The ordinary
realization explicitly includes both numerical coverage and the falsity
bridge `(0=S0) -> bottom`, avoiding the singleton-model gap.

## Evidence and package binding

The replay receipt binds the selected checker to SHA-256
`6bf8d9723cd42b83f0691c6770fadbc03069cad1b226e6fabe39b1bbb9b4aca8`,
which is the source reviewed here. It records 39 cases across three
profiles and two interpreter modes, for 234 successful expected-outcome
checks. Its guard-deletion control rejects in the genuine program and
accepts in the deliberately weakened mutant.

The two focused numerical Supply audits record 502,803 and 759,321
valuations respectively, with no resource-bounded cases. Both explicitly
limit their conclusions to finite standard-model tests. The manuscript
correctly says these are not whole-domain bi-interpretability proofs.

At the time of this review, generated metric macros, controlled-comparison
tables, the final code copy, and validation-summary TeX were still being
assembled. Therefore this review does not certify their later numerical
transcription or final ZIP contents. Final assembly should use the exact
reviewed source hash and preserve the existing distinction between
unique cases, repeated executions, and replayed receipts.
