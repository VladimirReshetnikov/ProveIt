AFFINE DEPTHS FOR A SMALL iPRA CHECKER
Research prepared for Vladimir Reshetnikov, 10 November 2026

MAIN RESULT

The complete selected checker is 648 normalized Python bytes, 283
significant tokens, and 326 AST nodes. Its maximum-level ordinary gzip
size is 385 bytes (level 9, no filename or timestamp).

The previous observed minimum source size in the 16 pinned current
archives is 672 bytes. The selected checker does not beat the separate
277-token and 311-AST minima. Gzip is FYI, not an optimization objective.

The new idea replaces the arity lookup by depth + length + 1, adds one
zero coordinate below equations, and decodes larger formula arrays as
the existing contradiction 0=S0. Exact paired-introduction shape checking
is essential. Object formulas remain the inherited Eq/Q/D language.
Accepted raw inputs are sound under that decoder; completeness is for
canonical encodings. No new opaque bottom predicate is introduced.

This is a modest new checker-level reduction. It is not an absolute
minimum or the significant foundational breakthrough requested. The
arithmetic and logical axiomatization is inherited, explicitly stated,
and proved equiconsistent and bi-interpretable with full first-order iPRA
through the included mathematical bridge. No Lean/Rocq verification is
claimed.

CONTENTS

report.pdf                 Compiled complete report.
report.tex                 Main LaTeX source; all inputs are included.
theory/                    New representation argument.
reference/                 Attributed inherited proofs and frozen comparators.
code/checker.py            Entire 648-byte standalone checker.
code/checker.py.gz         Actual gzip level 9 output, informational only.
code/readable_checker.py   Explanatory equivalent on the stated interface.
tests/                    Certificate producer, fixtures, verification and audits.
evidence/                 Results, comparisons, review and pinned provenance.
measure.py                Reproduce raw/normalized/gzip program measurements.
reproduce.py              Run the relevant portable checks.
build.py                  Compile report.tex with pdflatex.
fetch_baselines.py         Optional retrieval of pinned comparison archives.
measure_baselines.py       Optional full static corpus audit.
CLAIMS.json                Machine-readable scope and limitations.
MANIFEST.json              SHA-256 hashes of package files.

REPRODUCTION

Use Python 3.12 for exact AST-unparse source metrics; the recorded run
used CPython 3.12.14. The proof checker itself uses only the standard
library. All necessary local proof data are included.

    python3 reproduce.py
    python3 build.py

The second command requires a LaTeX installation containing the packages
listed in report.tex. It produces report.pdf. Numerical audits are finite
falsification checks and are explicitly not proof-assistant verification.

To run the selected checker on one fixture:

    python3 code/checker.py < tests/examples/I0_arbitrary_seed.json

Consult tests/affine_cases.json for the names of all available fixtures.

The optional full baseline audit needs network access and about 70 MB of
ZIP input. It retrieves only the pinned snapshot and executes no archive
code:

    python3 fetch_baselines.py
    python3 measure_baselines.py --manifest evidence/pinned_sources.json --baselines baselines --output baseline_reaudit

The ordinary reproduction command measures the included frozen leaders,
so fetching all 16 archives is not needed to inspect the result.

PROVENANCE

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 3fb35a5f2c0cb506180bede7ee3b9b5f93d4bc9d
Path: docs/drafts

The earlier generated-assumptions and constructed-computation reports
provide the native calculus, primitive-recursion bridge, and the source
checker family. The new contribution is the affine decoder and its
soundness argument. Reference source hashes and exact origins are
recorded in reference/provenance.json and evidence/implementation_provenance.json.

No repository changes, commits, pull requests, or publications were made.
