#!/usr/bin/env python3
"""Rebuild the report; optionally recheck the bundled Lean proof template."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def run(command: list[str], root: Path, log: Path) -> str:
    result = subprocess.run(command, cwd=root, text=True, capture_output=True)
    output = result.stdout + result.stderr
    log.write_text(output, encoding="utf-8")
    if result.returncode:
        print(output[-9000:], file=sys.stderr)
        raise SystemExit(f"Command failed ({result.returncode}): {command[0]}")
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Path to Lean (tested with 4.19.0)")
    parser.add_argument("--skip-lean", action="store_true", help="Rebuild only the PDF")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    artifacts = root / "artifacts"
    artifacts.mkdir(exist_ok=True)
    lean = args.lean or os.environ.get("IPRA_LEAN") or shutil.which("lean")
    if not args.skip_lean and lean:
        version = run([lean, "--version"], root, artifacts / "lean-version.txt").strip()
        output = run([lean, "artifacts/UniqueRecursion.lean"], root,
                     artifacts / "lean-verification.txt")
        (artifacts / "lean-verification.txt").write_text(version + "\n\n" + output)
        checks = [line for line in output.splitlines() if "does not depend on any axioms" in line]
        if len(checks) != 6:
            raise SystemExit("Expected six empty kernel-axiom dependency reports; inspect Lean output.")
        old = artifacts / "lean-verification.json"
        metadata = json.loads(old.read_text()) if old.exists() else {}
        metadata.update({
            "lean_version": version,
            "source": "UniqueRecursion.lean",
            "source_sha256": hashlib.sha256((artifacts / "UniqueRecursion.lean").read_bytes()).hexdigest(),
            "exit_code": 0,
            "kernel_axioms_for_printed_theorems": [],
            "scope": "Checked algebraic proof template; first-order syntax, admissibility, and full bi-interpretability are not formalized.",
        })
        metadata.pop("environment_note", None)
        old.write_text(json.dumps(metadata, indent=2) + "\n")
        print("Lean proof template verified; six inspected results have no additional kernel axioms.")
    elif args.skip_lean:
        print("Lean verification skipped as requested; retained records describe the delivered source.")
    else:
        print("Lean not installed: rebuilding PDF only. Use --lean PATH to recheck the proof template.")

    latex = shutil.which("pdflatex")
    if not latex:
        raise SystemExit("pdflatex is required to compile report.tex.")
    for number in range(1, 5):
        run([latex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"], root,
            artifacts / f"latex-pass-{number}.txt")
        current_log = (root / "report.log").read_text(errors="replace")
        if number >= 2 and "Label(s) may have changed" not in current_log and "Rerun to get" not in current_log:
            break
    log = (root / "report.log").read_text(errors="replace")
    warnings = [line for line in log.splitlines()
                if "Overfull" in line or "undefined" in line or "multiply defined" in line or "Rerun to get" in line]
    if warnings:
        print("Layout/reference warnings requiring review:", *warnings, sep="\n")
    print("Built", root / "report.pdf")


if __name__ == "__main__":
    main()
