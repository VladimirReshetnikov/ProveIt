/-
Unique recursion: a checked proof template for the arithmetic bootstrap.
Lean 4.19.0; uses only Lean's bundled Init library.

SCOPE. This file verifies the algebraic and intuitionistic proof steps.
It does NOT formalize the generated first-order language or the complete
first-order bi-interpretability theorem. The field `compare` is a
metalevel interface for the term-indexed uniqueness schema. Its Lean type
quantifies over functions; treating that type as an unrestricted
object-language second-order axiom would be a different, stronger theory.
Every use below has a displayed finite term-shaped update and solution;
their first-order admissibility is justified separately in the report.
Similarly, the functions f and g in `equation_induction` stand for the two
finite terms of an arbitrary equation-schema instance.

No classical logic, choice, Mathlib, `sorry`, or extra global axiom is used.
The abstract arithmetic hypotheses are explicit fields of `Core`.
-/

import Init

universe u

namespace UniqueRecursion

structure Core (N : Type u) where
  zero : N
  succ : N → N
  q : N → N → N
  choose : N → N → N → N
  add : N → N → N
  sub : N → N → N
  sep : zero ≠ succ zero
  coverage : ∀ x, x = zero ∨ ∃ y, x = succ y
  q_zero : ∀ a, q zero a = a
  q_succ : ∀ n a, q (succ n) a = n
  choose_zero : ∀ a b, choose zero a b = a
  choose_succ : ∀ n a b, choose (succ n) a b = b
  add_zero : ∀ a, add a zero = a
  add_succ : ∀ a n, add a (succ n) = succ (add a n)
  sub_zero : ∀ a, sub a zero = a
  sub_succ : ∀ a n, sub a (succ n) = q (sub a n) zero
  compare : ∀ (h : N → N → N) (f g : N → N),
    f zero = g zero →
    (∀ n, f (succ n) = h (f n) n) →
    (∀ n, g (succ n) = h (g n) n) →
    ∀ n, f n = g n

namespace Core

variable {N : Type u} (c : Core N)

def one : N := c.succ c.zero
def pred (x : N) : N := c.q x c.zero

theorem q_one (a : N) : c.q c.one a = c.zero := c.q_succ c.zero a

theorem choose_one (a b : N) : c.choose c.one a b = b :=
  c.choose_succ c.zero a b

theorem pred_zero : c.pred c.zero = c.zero := c.q_zero c.zero

theorem pred_succ (x : N) : c.pred (c.succ x) = x :=
  c.q_succ x c.zero

theorem succ_injective {x y : N} (h : c.succ x = c.succ y) : x = y := by
  calc
    x = c.pred (c.succ x) := (c.pred_succ x).symm
    _ = c.pred (c.succ y) := congrArg c.pred h
    _ = y := c.pred_succ y

theorem succ_ne_zero (x : N) : c.succ x ≠ c.zero := by
  intro h
  have hx : x = c.zero := by
    calc
      x = c.pred (c.succ x) := (c.pred_succ x).symm
      _ = c.pred c.zero := congrArg c.pred h
      _ = c.zero := c.pred_zero
  exact c.sep (h.symm.trans (congrArg c.succ hx))

theorem one_ne_zero : c.one ≠ c.zero := c.succ_ne_zero c.zero

theorem choose_same (x a : N) : c.choose x a a = a := by
  cases c.coverage x with
  | inl hz =>
    rw [hz]
    exact c.choose_zero a a
  | inr hs =>
    cases hs with
    | intro y hy =>
      rw [hy]
      exact c.choose_succ y a a

/- Each identity here is obtained by comparing two explicitly displayed
   solutions of the same recurrence. No induction principle is assumed. -/

theorem add_zero_left (n : N) : c.add c.zero n = n := by
  exact c.compare
    (fun v _ => c.succ v)
    (fun k => c.add c.zero k)
    (fun k => k)
    (c.add_zero c.zero)
    (fun k => c.add_succ c.zero k)
    (fun _ => rfl)
    n

theorem add_succ_left (a n : N) :
    c.add (c.succ a) n = c.succ (c.add a n) := by
  apply c.compare
    (fun v _ => c.succ v)
    (fun k => c.add (c.succ a) k)
    (fun k => c.succ (c.add a k))
  · calc
      c.add (c.succ a) c.zero = c.succ a := c.add_zero (c.succ a)
      _ = c.succ (c.add a c.zero) := congrArg c.succ (c.add_zero a).symm
  · intro k
    exact c.add_succ (c.succ a) k
  · intro k
    exact congrArg c.succ (c.add_succ a k)

theorem sub_next (a n : N) : c.sub a (c.succ n) = c.pred (c.sub a n) :=
  c.sub_succ a n

theorem sub_zero_left (n : N) : c.sub c.zero n = c.zero := by
  exact c.compare
    (fun v _ => c.pred v)
    (fun k => c.sub c.zero k)
    (fun _ => c.zero)
    (c.sub_zero c.zero)
    (fun k => c.sub_next c.zero k)
    (fun _ => c.pred_zero.symm)
    n

theorem sub_shift (a n : N) : c.sub (c.succ a) (c.succ n) = c.sub a n := by
  apply c.compare
    (fun v _ => c.pred v)
    (fun k => c.sub (c.succ a) (c.succ k))
    (fun k => c.sub a k)
  · calc
      c.sub (c.succ a) (c.succ c.zero)
          = c.pred (c.sub (c.succ a) c.zero) := c.sub_next (c.succ a) c.zero
      _ = c.pred (c.succ a) := congrArg c.pred (c.sub_zero (c.succ a))
      _ = a := c.pred_succ a
      _ = c.sub a c.zero := (c.sub_zero a).symm
  · intro k
    exact c.sub_next (c.succ a) (c.succ k)
  · intro k
    exact c.sub_next a k

theorem sub_self (a : N) : c.sub a a = c.zero := by
  exact c.compare
    (fun v _ => v)
    (fun k => c.sub k k)
    (fun _ => c.zero)
    (c.sub_zero c.zero)
    (fun k => c.sub_shift k k)
    (fun _ => rfl)
    a

theorem sub_succ_self (a : N) : c.sub (c.succ a) a = c.one := by
  exact c.compare
    (fun v _ => v)
    (fun k => c.sub (c.succ k) k)
    (fun _ => c.one)
    (c.sub_zero (c.succ c.zero))
    (fun k => c.sub_shift (c.succ k) k)
    (fun _ => rfl)
    a

def residual (y n : N) : N :=
  c.choose (c.sub y n) y (c.add n (c.sub y n))

def residualUpdate (y v n : N) : N :=
  c.choose (c.pred (c.sub y n)) y v

theorem residual_zero (y : N) : c.residual y c.zero = y := by
  unfold residual
  rw [c.sub_zero, c.add_zero_left]
  exact c.choose_same y y

theorem residual_next (y n : N) :
    c.residual y (c.succ n) = c.residualUpdate y (c.residual y n) n := by
  cases c.coverage (c.sub y n) with
  | inl hz =>
    unfold residual residualUpdate
    rw [c.sub_next, hz, c.pred_zero, c.choose_zero, c.choose_zero]
  | inr hs =>
    cases hs with
    | intro a ha =>
      unfold residual residualUpdate
      rw [c.sub_next, ha, c.pred_succ, c.choose_succ, c.add_succ_left, c.add_succ]

/- The central noncircular step: the residual and the constant y solve
   the SAME term-defined recurrence. -/
theorem residual_reconstruction (y n : N) : c.residual y n = y := by
  exact c.compare
    (c.residualUpdate y)
    (c.residual y)
    (fun _ => y)
    (c.residual_zero y)
    (c.residual_next y)
    (fun k => (c.choose_same (c.pred (c.sub y k)) y).symm)
    n

def raw (s t : N) : N := c.sub (c.succ s) t
def bit (s t : N) : N := c.choose (c.q (c.raw s t) c.one) c.zero c.one

theorem raw_one_of_eq {s t : N} (h : s = t) : c.raw s t = c.one := by
  cases h
  exact c.sub_succ_self s

theorem eq_of_raw_one {s t : N} (h : c.raw s t = c.one) : s = t := by
  have hr := c.residual_reconstruction (c.succ s) t
  change c.choose (c.raw s t) (c.succ s) (c.add t (c.raw s t)) = c.succ s at hr
  rw [h] at hr
  change c.choose (c.succ c.zero) (c.succ s)
    (c.add t (c.succ c.zero)) = c.succ s at hr
  rw [c.choose_succ, c.add_succ, c.add_zero] at hr
  exact (c.succ_injective hr).symm

theorem bit_zero_of_eq {s t : N} (h : s = t) : c.bit s t = c.zero := by
  have hr := c.raw_one_of_eq h
  unfold bit
  rw [hr, c.q_one, c.choose_zero]

theorem bit_of_raw_zero {s t : N} (h : c.raw s t = c.zero) :
    c.bit s t = c.one := by
  unfold bit
  rw [h, c.q_zero, c.choose_one]

theorem bit_of_raw_two_succ {s t a : N} (h : c.raw s t = c.succ (c.succ a)) :
    c.bit s t = c.one := by
  unfold bit
  rw [h, c.q_succ, c.choose_succ]

theorem eq_of_bit_zero {s t : N} (h : c.bit s t = c.zero) : s = t := by
  cases c.coverage (c.raw s t) with
  | inl hz =>
    exact False.elim (c.one_ne_zero ((c.bit_of_raw_zero hz).symm.trans h))
  | inr hs =>
    cases hs with
    | intro a ha =>
      cases c.coverage a with
      | inl az =>
        have hr : c.raw s t = c.one := ha.trans (congrArg c.succ az)
        exact c.eq_of_raw_one hr
      | inr ap =>
        cases ap with
        | intro b hb =>
          have hr : c.raw s t = c.succ (c.succ b) :=
            ha.trans (congrArg c.succ hb)
          exact False.elim (c.one_ne_zero ((c.bit_of_raw_two_succ hr).symm.trans h))

theorem bit_cases (s t : N) : c.bit s t = c.zero ∨ c.bit s t = c.one := by
  cases c.coverage (c.q (c.raw s t) c.one) with
  | inl hz =>
    apply Or.inl
    exact (congrArg (fun x => c.choose x c.zero c.one) hz).trans
      (c.choose_zero c.zero c.one)
  | inr hs =>
    cases hs with
    | intro a ha =>
      apply Or.inr
      exact (congrArg (fun x => c.choose x c.zero c.one) ha).trans
        (c.choose_succ a c.zero c.one)

theorem ne_of_bit_one {s t : N} (h : c.bit s t = c.one) : s ≠ t := by
  intro e
  exact c.sep ((c.bit_zero_of_eq e).symm.trans h)

theorem bit_one_of_ne {s t : N} (h : s ≠ t) : c.bit s t = c.one := by
  cases c.bit_cases s t with
  | inl hz => exact False.elim (h (c.eq_of_bit_zero hz))
  | inr ho => exact ho

theorem equality_decidable (c : Core N) (s t : N) : s = t ∨ s ≠ t := by
  cases c.bit_cases s t with
  | inl hz => exact Or.inl (c.eq_of_bit_zero hz)
  | inr ho => exact Or.inr (c.ne_of_bit_one ho)

/- Arbitrary f,g are metalevel placeholders for the two finite terms of
   one equation-induction instance. The displayed h is itself term-shaped.
   The first-order derivation uses the parameterized recursor for that h. -/
theorem equation_induction (f g : N → N)
    (base : f c.zero = g c.zero)
    (step : ∀ n, f n = g n → f (c.succ n) = g (c.succ n)) :
    ∀ n, f n = g n := by
  let h : N → N → N := fun v n =>
    c.choose (c.bit v (f n)) (f (c.succ n)) (g (c.succ n))
  have hf : ∀ n, f (c.succ n) = h (f n) n := by
    intro n
    dsimp [h]
    rw [c.bit_zero_of_eq (rfl : f n = f n), c.choose_zero]
  have hg : ∀ n, g (c.succ n) = h (g n) n := by
    intro n
    cases c.bit_cases (g n) (f n) with
    | inl hz =>
      have e : f n = g n := (c.eq_of_bit_zero hz).symm
      dsimp [h]
      rw [hz, c.choose_zero]
      exact (step n e).symm
    | inr ho =>
      dsimp [h]
      rw [ho]
      exact (c.choose_succ c.zero (f (c.succ n)) (g (c.succ n))).symm
  exact c.compare h f g base hf hg

end Core

/- A finite quantifier-free formula tree with its numerical term values
   already supplied. This is the metalevel propositional part of the
   usual characteristic-function compiler. -/
inductive QF (N : Type u) where
  | eq : N → N → QF N
  | falsum : QF N
  | conj : QF N → QF N → QF N
  | disj : QF N → QF N → QF N
  | impl : QF N → QF N → QF N

namespace QF

variable {N : Type u}

def meaning : QF N → Prop
  | .eq s t => s = t
  | .falsum => False
  | .conj p q => meaning p ∧ meaning q
  | .disj p q => meaning p ∨ meaning q
  | .impl p q => meaning p → meaning q

def code (c : Core N) : QF N → N
  | .eq s t => c.bit s t
  | .falsum => c.one
  | .conj p q => c.choose (code c p) (code c q) c.one
  | .disj p q => c.choose (code c p) c.zero (code c q)
  | .impl p q => c.choose (code c p) (code c q) c.zero

theorem specification (c : Core N) (f : QF N) :
    (code c f = c.zero ∧ meaning f) ∨
    (code c f = c.one ∧ ¬ meaning f) := by
  induction f with
  | eq s t =>
    cases c.bit_cases s t with
    | inl hz => exact Or.inl ⟨hz, c.eq_of_bit_zero hz⟩
    | inr ho => exact Or.inr ⟨ho, c.ne_of_bit_one ho⟩
  | falsum =>
    exact Or.inr ⟨rfl, fun h => h⟩
  | conj p q hp hq =>
    cases hp with
    | inl hp =>
      cases hq with
      | inl hq =>
        apply Or.inl
        constructor
        · change c.choose (code c p) (code c q) c.one = c.zero
          rw [hp.1, c.choose_zero, hq.1]
        · exact ⟨hp.2, hq.2⟩
      | inr hq =>
        apply Or.inr
        constructor
        · change c.choose (code c p) (code c q) c.one = c.one
          rw [hp.1, c.choose_zero, hq.1]
        · exact fun h => hq.2 h.2
    | inr hp =>
      apply Or.inr
      constructor
      · change c.choose (code c p) (code c q) c.one = c.one
        rw [hp.1, c.choose_one]
      · exact fun h => hp.2 h.1
  | disj p q hp hq =>
    cases hp with
    | inl hp =>
      apply Or.inl
      constructor
      · change c.choose (code c p) c.zero (code c q) = c.zero
        rw [hp.1, c.choose_zero]
      · exact Or.inl hp.2
    | inr hp =>
      cases hq with
      | inl hq =>
        apply Or.inl
        constructor
        · change c.choose (code c p) c.zero (code c q) = c.zero
          rw [hp.1, c.choose_one, hq.1]
        · exact Or.inr hq.2
      | inr hq =>
        apply Or.inr
        constructor
        · change c.choose (code c p) c.zero (code c q) = c.one
          rw [hp.1, c.choose_one, hq.1]
        · intro h
          cases h with
          | inl h => exact hp.2 h
          | inr h => exact hq.2 h
  | impl p q hp hq =>
    cases hp with
    | inl hp =>
      cases hq with
      | inl hq =>
        apply Or.inl
        constructor
        · change c.choose (code c p) (code c q) c.zero = c.zero
          rw [hp.1, c.choose_zero, hq.1]
        · exact fun _ => hq.2
      | inr hq =>
        apply Or.inr
        constructor
        · change c.choose (code c p) (code c q) c.zero = c.one
          rw [hp.1, c.choose_zero, hq.1]
        · exact fun h => hq.2 (h hp.2)
    | inr hp =>
      apply Or.inl
      constructor
      · change c.choose (code c p) (code c q) c.zero = c.zero
        rw [hp.1, c.choose_one]
      · exact fun h => False.elim (hp.2 h)

theorem reflection (c : Core N) (f : QF N) : code c f = c.zero ↔ meaning f := by
  constructor
  · intro h
    cases specification c f with
    | inl hz => exact hz.2
    | inr ho => exact False.elim (c.sep (h.symm.trans ho.1))
  · intro h
    cases specification c f with
    | inl hz => exact hz.1
    | inr ho => exact False.elim (ho.2 h)

/- F stands for the values of one fixed finite formula after substituting
   the induction variable. The generated-language admissibility of its
   characteristic term is a separate syntactic metatheorem in the report. -/
theorem quantifier_free_induction (c : Core N) (F : N → QF N)
    (base : meaning (F c.zero))
    (step : ∀ n, meaning (F n) → meaning (F (c.succ n))) :
    ∀ n, meaning (F n) := by
  have eqs : ∀ n, code c (F n) = c.zero := by
    apply c.equation_induction (fun n => code c (F n)) (fun _ => c.zero)
    · exact (reflection c (F c.zero)).mpr base
    · intro n hn
      exact (reflection c (F (c.succ n))).mpr
        (step n ((reflection c (F n)).mp hn))
  exact fun n => (reflection c (F n)).mp (eqs n)

end QF

#print axioms Core.residual_reconstruction
#print axioms Core.eq_of_bit_zero
#print axioms Core.equality_decidable
#print axioms Core.equation_induction
#print axioms QF.reflection
#print axioms QF.quantifier_free_induction

end UniqueRecursion
