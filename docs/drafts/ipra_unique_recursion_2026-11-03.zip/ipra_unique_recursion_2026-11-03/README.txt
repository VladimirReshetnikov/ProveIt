iPRA FROM CONSTRUCTORS AND UNIQUE RECURSION
3 November 2026
==========================================

RECOMMENDATION
Use two constructor sentences and one characterization schema:
  1. 0 differs from S0.
  2. Every number is either zero or a successor.
  3. A sequence given by a finite term equals the specified primitive
     recursion iff it has that recursion's initial value and update.

The schema supplies the computation equations by its self-comparison
instance. Induction is derived, not separately postulated. All comparison
sequences are finite terms, and all parameters are numbers. There is no
function sort, universal program evaluator, or second-order initiality
axiom. The main logic is ordinary intuitionistic first-order equality.

RESULT
The theory is deductively equivalent to full first-order iPRA in a common
recursor language, and equiconsistent and bi-interpretable with a usual
language of finite primitive-recursive definitions. Both interpretation
domains are the whole carrier; their composites are internally identity.

The proof derives an equality bit from uniqueness before deriving equation
induction, so it does not assume induction or equality decidability
circularly. An optional minimal-logic variant derives falsity elimination
from the arithmetic equivalence (0=S0) iff bottom.

COMPARISON
All four current and all four archived proposals were reviewed at commit
77e7fdf4a46344cc79cc9c88d78954bab1764ec5 of VladimirReshetnikov/ProveIt.
All four current drafts contain some genuine improvement and were retained.
The proposal changes the governing concept from a special boundary/closure
schema to unique recursion. This is a cognitive recommendation, not a
global shortestness theorem or packet-by-packet symbol-count claim.
Uniqueness as a replacement for induction has historical antecedents;
the report claims no historical discovery of that principle.

CONTENTS
  report.tex                  Main LaTeX source and bibliography
  sections/*.tex              Complete section sources
  report.pdf                  Compiled report
  AXIOMS.txt                  Exact standalone theory specification
  artifacts/UniqueRecursion.lean
                              Machine-checked algebraic proof template
  artifacts/lean-verification.txt and .json
                              Successful Lean output, scope, source hash
  provenance/source_manifest.json
                              Pinned URLs, Git blob hashes, SHA-256 hashes
  provenance/comparison.csv    Eight-source audit and historical filter
  provenance/source_validation.json
                              Downloaded hashes matched to GitHub metadata
  artifacts/validation.json    Build and layout validation summary
  build.py                    Rebuild script
  SHA256SUMS.txt               Hashes of the delivered package files

LEAN SCOPE
Checked with Lean 4.19.0, bundled Init only. No Mathlib, Classical, sorry,
or extra global axiom is used. Six inspected results have empty kernel
axiom dependency lists. Arithmetic hypotheses remain explicit fields of
an abstract Core structure.

The compare field is a metalevel proof-template interface whose Lean type
quantifies over functions. It must not be mistaken for the first-order
axiom: the report separately proves that its eight uses instantiate the
stated term-indexed schema. First-order syntax, the schema generator,
proof translations, and the full bi-interpretability metatheorem have
complete written proofs here, but are not formally encoded in this Lean
file. The optional minimal-logic variant and product countermodel are
also written proofs, not additional Lean results.

REBUILD
  python3 build.py
or, with an explicit Lean executable:
  python3 build.py --lean /absolute/path/to/lean
or, for the PDF only:
  python3 build.py --skip-lean

Requirements: Python 3; pdflatex and the standard LaTeX packages named in
report.tex. Rechecking Lean requires Lean 4.19.0 (the tested version).
No downloaded package is needed by the Lean source.

To verify only the formal artifact from this directory:
  lean artifacts/UniqueRecursion.lean

Rebuilding can change PDF metadata and hashes. SHA256SUMS.txt identifies
the originally delivered files; it is not silently refreshed by build.py.
