PRA FROM ONE TERM
Research prepared for Vladimir Reshetnikov -- 1 November 2026

MAIN RESULT
The current two-term induction generator n=0 OR s(n,a)=t(n,a) can be
replaced by n=0 OR t(n,a)=n, using one arbitrary term, if one adds the
fixed unary diagonal identity D_p(n,n)=q(n,n).
The existing delayed language and its two computation schemes remain.
The same proof gives a common conservative definitional extension with
first-order PRA in each matching classical/intuitionistic logic.

This is a proved grammar reduction with finite fixed overhead. It is not
an absolute shortestness theorem or an assertion that every expanded
axiom gets shorter. The diagonal-free one-term candidate remains open.

FILES
  report.pdf / report.tex / sections/ : complete written mathematical report
  AXIOMS.txt                         : extractable exact specification
  formal/OneTermKernel.lean           : arbitrary-carrier constructive kernel
  formal/SCOPE.txt                    : precise formal-verification boundary
  checks/check_spec.py                : syntax and bounded model diagnostics
  checks/results.json                : recorded diagnostic results
  audit/                             : source manifest and verification records
  build.py                           : reproducible build entry point
  SHA256SUMS.txt                      : final deliverable checksums

BUILD
  python3 build.py
requires Python 3 and pdflatex with standard packages used by report.tex.
It runs the diagnostics and compiles the PDF three times for references.
It does not download or install software.

To check the formal kernel with Lean 4.19.0:
  lean formal/OneTermKernel.lean
The file imports only Init; Mathlib is unnecessary. The archived log and
receipt record a successful run. The entire bi-interpretation, descriptor
syntax, numerical pairing, and compiler are NOT formalized in this kernel.

SOURCE BASELINE
All five archives in ProveIt/docs/drafts at commit
bc2c2c2d0fe0ec5e29df9d01190ecb959aa9d88c were reviewed.
See audit/source_manifest.json for exact names and hashes. The report
identifies inherited constructions and gives their proofs for completeness.

NEW NEGATIVE RESULT
A moving comparison target matters. Replacing n by zero or any finite
menu of closed terms admits ghost-fiber models even when K is retained.
Their involutive automorphisms rule out any ordinary bi-interpretation
with PRA, including finite-dimensional/quotient interpretations. This is
stronger than merely showing that the intended identity interpretation fails.

No repository files were changed or published by this research package.
