#!/usr/bin/env python3
"""Exact finite syntax checks and bounded model diagnostics.

These checks do not establish any infinite induction schema or bi-interpretation.
The mathematical proofs are in the report; the new conditional kernel is in Lean.
"""
from dataclasses import dataclass
from itertools import product
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

@dataclass(frozen=True)
class Term:
    op: str
    args: tuple = ()
    body: object = None
    name: str = ''

def V(name): return Term('var', name=name)
def S(x): return Term('S', (x,))
def D(h, n, a): return Term('D', (n, a), body=h)
zero = Term('0')
one = S(zero)
v, n, a = V('v'), V('n'), V('a')
succ_body = S(v)
pred_body = D(succ_body, v, zero)

def p(x): return D(succ_body, x, zero)
def q(x, y): return D(one, x, y)
def dp(x, y): return D(pred_body, x, y)

def fv(t):
    if t.op == 'var': return {t.name}
    return set().union(*(fv(x) for x in t.args)) if t.args else set()

def legal(t):
    assert t.op in {'var', '0', 'S', 'D'}
    assert len(t.args) == {'var': 0, '0': 0, 'S': 1, 'D': 2}[t.op]
    for x in t.args: legal(x)
    if t.op == 'D':
        legal(t.body)
        assert fv(t.body) <= {'v'}

def subst(t, name, value):
    if t.op == 'var': return value if t.name == name else t
    # The descriptor is stored syntax and is deliberately NOT substituted.
    return Term(t.op, tuple(subst(x, name, value) for x in t.args), t.body, t.name)

def size(t): return 1 + sum(size(x) for x in t.args)

def show(t):
    if t.op == 'var': return t.name
    if t.op == '0': return '0'
    if t.op == 'S': return f'S({show(t.args[0])})'
    return f'D_{{{show(t.body)}}}({show(t.args[0])},{show(t.args[1])})'

@dataclass(frozen=True)
class Formula:
    op: str
    args: tuple = ()
    binder: str = ''

def Eq(x, y): return Formula('=', (x, y))
def And(x, y): return Formula('and', (x, y))
def Or(x, y): return Formula('or', (x, y))
def Imp(x, y): return Formula('implies', (x, y))
def All(x, f): return Formula('forall', (f,), x)
bot = Formula('false')

def ffv(f):
    if f.op == '=': return fv(f.args[0]) | fv(f.args[1])
    if f.op == 'false': return set()
    if f.op == 'forall': return ffv(f.args[0]) - {f.binder}
    return ffv(f.args[0]) | ffv(f.args[1])

def fsubst(f, name, value):
    if f.op == '=': return Eq(*(subst(x, name, value) for x in f.args))
    if f.op == 'false': return f
    if f.op == 'forall':
        if f.binder == name: return f
        body, binder = f.args[0], f.binder
        if binder in fv(value) and name in ffv(body):
            unavailable = ffv(body) | fv(value) | {name, binder}
            fresh = binder + '_fresh'
            while fresh in unavailable: fresh += '_fresh'
            body = fsubst(body, binder, V(fresh))
            binder = fresh
        return All(binder, fsubst(body, name, value))
    return Formula(f.op, tuple(fsubst(x, name, value) for x in f.args))

def fsize(f):
    if f.op == '=': return 1 + size(f.args[0]) + size(f.args[1])
    return 1 + sum(fsize(x) for x in f.args)

def names(f):
    if f.op == '=': return fv(f.args[0]) | fv(f.args[1])
    if f.op == 'false': return set()
    if f.op == 'forall': return {f.binder} | names(f.args[0])
    return names(f.args[0]) | names(f.args[1])

def fshow(f):
    if f.op == '=': return f'({show(f.args[0])}={show(f.args[1])})'
    if f.op == 'false': return 'false'
    if f.op == 'forall': return f'(forall {f.binder} {fshow(f.args[0])})'
    return f'({fshow(f.args[0])} {f.op} {fshow(f.args[1])})'

def dynamic(t):
    legal(t)
    assert fv(t) <= {'n', 'a'}
    return Or(Eq(n, zero), Eq(t, n))

def stationary(h):
    legal(h)
    assert fv(h) <= {'v'}
    reset = Eq(D(h, q(n, zero), a), a)
    tail = Eq(D(h, S(S(n)), a), subst(h, 'v', D(h, S(n), a)))
    diagonal = Eq(dp(n, n), q(n, n))
    return And(Imp(Eq(zero, one), bot), All('n', And(reset, And(tail, diagonal))))

def wrapper(f):
    return All('a', Imp(All('n', Imp(f, fsubst(f, 'n', S(n)))), All('n', f)))

@dataclass(frozen=True)
class Element:
    level: int
    tag: int = 0

class Model:
    def __init__(self, ghost=False, singleton=(0, 1, 3)):
        self.ghost = ghost
        self.singleton = frozenset(singleton)
    def canon(self, k): return Element(k) if self.ghost else k
    def pi(self, x): return x.level if self.ghost else x
    def successor(self, x): return self.canon(self.pi(x) + 1)
    def eval(self, t, env):
        if t.op == 'var': return env[t.name]
        if t.op == '0': return self.canon(0)
        if t.op == 'S': return self.successor(self.eval(t.args[0], env))
        count = self.pi(self.eval(t.args[0], env))
        state = self.eval(t.args[1], env)
        if count > 2000:
            raise ValueError('Diagnostic size limit reached; this is not a proof evaluator.')
        for _ in range(max(count - 1, 0)):
            state = self.eval(t.body, {'v': state})
        return state
    def sample(self, maximum):
        if not self.ghost: return list(range(maximum + 1))
        return [Element(k, tag) for k in range(maximum + 1)
                for tag in ([0] if k in self.singleton else [0, 1, 2])]

def sigma(x):
    if x.level == 2 and x.tag in (1, 2): return Element(2, 3-x.tag)
    return x

def main():
    bodies = [v, zero, one, S(v), S(S(v)), pred_body, D(zero, v, one)]
    terms = [zero, one, n, a, S(n), S(a), p(n), p(a), p(S(n)),
             dp(n, n), q(n, n), dp(S(n), S(a))]
    terms += [D(h, x, y) for h in bodies for x in (n, a) for y in (n, a, zero)]
    terms = list(dict.fromkeys(terms))
    syntax_checks = 0
    for t in terms:
        legal(t)
        f = dynamic(t)
        closed = wrapper(f)
        assert ffv(closed) == set()
        assert names(closed) <= {'n', 'a'}
        assert subst(t, 'v', a) == t  # no active v, including in descriptor bodies
        syntax_checks += 4
    for h in bodies:
        f = stationary(h)
        assert ffv(f) <= {'a'}
        assert fsubst(f, 'n', S(n)) == f
        assert ffv(wrapper(f)) == set()
        assert names(wrapper(f)) <= {'n', 'a'}
        syntax_checks += 4
    # An explicit capture test, separate from the two-name emitted axioms.
    capture = fsubst(All('a', Eq(n, a)), 'n', a)
    assert capture.binder != 'a' and ffv(capture) == {'a'}
    syntax_checks += 1
    compact_count = fsize(All('n', Eq(dp(n, n), q(n, n))))
    unit_count = fsize(All('n', Eq(dp(S(n), S(n)), one)))
    assert (compact_count, unit_count) == (8, 9)

    nat = Model()
    ghost = Model(True)
    samples = ghost.sample(6)
    projection_cases = target_cases = equivariance_cases = 0
    for t, x, y in product(terms, samples, samples):
        result = ghost.eval(t, {'n': x, 'a': y})
        numeric = nat.eval(t, {'n': x.level, 'a': y.level})
        assert result.level == numeric
        projection_cases += 1
        for b in sorted(ghost.singleton):
            assert (result == Element(b)) == (numeric == b)
            target_cases += 1
        translated = ghost.eval(t, {'n': sigma(x), 'a': sigma(y)})
        assert sigma(result) == translated
        equivariance_cases += 1
    computation_cases = 0
    for h, x, y in product(bodies, samples, samples):
        env = {'n': x, 'a': y}
        assert ghost.eval(D(h, q(n, zero), a), env) == y
        assert ghost.eval(D(h, S(S(n)), a), env) == ghost.eval(
            subst(h, 'v', D(h, S(n), a)), env)
        computation_cases += 2
    for x in samples:
        env = {'n': x}
        assert ghost.eval(dp(n, n), env) == ghost.eval(q(n, n), env)
        assert ghost.eval(dp(S(n), S(n)), env) == Element(1)
        computation_cases += 2
    g1, g2 = Element(2, 1), Element(2, 2)
    assert g1 != g2 and ghost.successor(g1) == ghost.successor(g2)
    assert sigma(sigma(g1)) == g1 and sigma(g1) != g1
    assert ghost.eval(p(S(n)), {'n': g1}) != g1
    for x in samples:
        sx = ghost.successor(x)
        assert ghost.eval(p(S(n)), {'n': sx}) == sx

    # Bounded arithmetic illustration only; no claim to verify induction.
    residual_cases = 0
    for x, y in product(range(21), repeat=2):
        d = lambda u, w: max(u-w, 0)
        selector = lambda r, b, c: b if r == 0 else c
        assert selector(d(y,x), x, d(y,d(y,x))) == x
        assert (d(x+1,y) == 1) == (x == y)
        residual_cases += 1
    result = {
        'status': 'passed',
        'scope': 'Finite syntax checks and bounded diagnostics, not an infinite-schema proof.',
        'term_samples': len(terms), 'descriptor_samples': len(bodies),
        'syntax_assertions': syntax_checks,
        'compact_K_ast_nodes': compact_count, 'unit_diagonal_ast_nodes': unit_count,
        'ast_convention': 'One per operator, application, constant, variable occurrence, quantifier; descriptor labels opaque.',
        'ghost_elements_sampled': len(samples),
        'projection_cases': projection_cases, 'fixed_target_factorization_cases': target_cases,
        'automorphism_equivariance_cases': equivariance_cases,
        'computation_and_diagonal_cases': computation_cases,
        'standard_residual_and_equality_cases': residual_cases,
        'explicit_counterexample': {
            'x': [2,1], 'y': [2,2], 'Sx_equals_Sy': True,
            'x_equals_y': False, 'involution_nonidentity': True,
            'moving_target_pred_successor_at_x': [2,0],
            'new_K_retained': True,
        },
        'unproved_by_this_script': [
            'All propagation instances', 'Nonstandard-model adequacy of the positive theory',
            'Bi-interpretability or consistency', 'The automorphism obstruction for all interpretations'],
    }
    (ROOT / 'checks' / 'results.json').write_text(json.dumps(result, indent=2)+'\n')
    examples = {
        'dynamic_predecessor': fshow(wrapper(dynamic(p(S(n))))),
        'dynamic_coverage': fshow(wrapper(dynamic(S(p(n))))),
        'stationary_successor': fshow(wrapper(stationary(S(v)))),
        'compact_diagonal': fshow(All('n', Eq(dp(n,n),q(n,n)))),
    }
    (ROOT / 'checks' / 'generated_examples.json').write_text(json.dumps(examples, indent=2)+'\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
