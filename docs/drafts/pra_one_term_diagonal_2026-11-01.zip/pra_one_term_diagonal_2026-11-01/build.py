#!/usr/bin/env python3
"""Run the bounded diagnostics and compile the complete TeX report."""
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def main():
    subprocess.run([sys.executable, str(ROOT / 'checks' / 'check_spec.py')],
                   cwd=ROOT, check=True)
    engine = shutil.which('pdflatex')
    if engine is None:
        raise SystemExit('pdflatex is required; no software is installed automatically.')
    audit = ROOT / 'audit'
    audit.mkdir(exist_ok=True)
    for index in range(1, 4):
        run = subprocess.run([engine, '-interaction=nonstopmode', '-halt-on-error',
                              'report.tex'], cwd=ROOT, text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (audit / f'latex-pass-{index}.txt').write_text(run.stdout, encoding='utf-8')
        if run.returncode:
            print(run.stdout[-8000:])
            raise SystemExit(run.returncode)
    print('Built report.pdf; inspect its rendered pages before delivery.')

if __name__ == '__main__':
    main()
