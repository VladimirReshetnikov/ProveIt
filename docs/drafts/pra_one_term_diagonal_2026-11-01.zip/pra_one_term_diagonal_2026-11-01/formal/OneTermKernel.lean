/-
Constructive kernel for the one-term PRA presentation.

The carrier is arbitrary. Each propagation or induction hypothesis below is
for the one displayed instance; no induction over all semantic predicates or
functions is postulated. This file verifies the new logical/arithmetic kernel,
not the finite descriptor grammar, numerical pairing, primitive-recursion
compiler, or complete first-order bi-interpretation.

Only Init is imported. No classical logic, choice, sorry, or induction on a
standard-natural-number carrier is used.
-/
import Init

namespace OneTermKernel

universe u
variable {A : Type u}

def InductionAt (zero : A) (succ : A → A) (P : A → Prop) : Prop :=
  P zero → (∀ n, P n → P (succ n)) → ∀ n, P n

def Propagation (succ : A → A) (F : A → A → Prop) : Prop :=
  ∀ a, (∀ n, F n a → F (succ n) a) → ∀ n, F n a

def RootedFixed (zero : A) (t : A → A → A) (n a : A) : Prop :=
  n = zero ∨ t n a = n

theorem stationary
    (zero : A) (succ : A → A) (P : A → Prop)
    (propagate : Propagation succ (fun _ a => P a)) :
    ∀ a, P a := by
  intro a
  exact propagate a (fun _ hp => hp) zero

/-- A selected one-term propagation instance gives its fixed-point induction
    instance, including under local base and step hypotheses. -/
theorem fixedpoint_induction
    (zero : A) (succ : A → A) (t : A → A → A)
    (propagate : Propagation succ (RootedFixed zero t)) :
    ∀ a, InductionAt zero succ (fun n => t n a = n) := by
  intro a hbase hstep n
  have allRooted : ∀ m, RootedFixed zero t m a := by
    apply propagate a
    intro m hm
    have eqHere : t m a = m := by
      cases hm with
      | inl hz => simpa only [hz] using hbase
      | inr he => exact he
    exact Or.inr (hstep m eqHere)
  cases allRooted n with
  | inl hz => simpa only [hz] using hbase
  | inr he => exact he

/-- Both delayed initial values follow from the inherited reset/tail laws.
    The q-tail is used here only at its closed input (SS0,0). -/
theorem delayed_seeds
    (zero : A) (succ : A → A) (q D : A → A → A)
    (qAtTwo : q (succ (succ zero)) zero = succ zero)
    (qReset : ∀ n a, q (q n zero) a = a)
    (reset : ∀ n a, D (q n zero) a = a) :
    (∀ a, D zero a = a) ∧ (∀ a, D (succ zero) a = a) := by
  have atOne : ∀ a, D (succ zero) a = a := by
    intro a
    have h := reset (succ (succ zero)) a
    rw [qAtTwo] at h
    exact h
  have qOneZero : q (succ zero) zero = zero := by
    have h := qReset (succ (succ zero)) zero
    rw [qAtTwo] at h
    exact h
  refine ⟨?_, atOne⟩
  intro a
  have h := reset (succ zero) a
  rw [qOneZero] at h
  exact h

theorem predecessor_from_fixedpoint
    (zero : A) (succ : A → A) (D : A → A → A)
    (seed : D (succ zero) zero = zero)
    (tail : ∀ n, D (succ (succ n)) zero = succ (D (succ n) zero))
    (ind : InductionAt zero succ (fun n => D (succ n) zero = n)) :
    ∀ n, D (succ n) zero = n := by
  apply ind seed
  intro n ih
  exact (tail n).trans (congrArg succ ih)

theorem rooted_coverage
    (zero : A) (succ pred : A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (propagate : Propagation succ
      (RootedFixed zero (fun n _ => succ (pred n)))) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  intro n
  have allRooted : ∀ m,
      RootedFixed zero (fun k _ => succ (pred k)) m zero := by
    apply propagate zero
    intro m _
    exact Or.inr (congrArg succ (predSucc m))
  cases allRooted n with
  | inl hz => exact Or.inl hz
  | inr he => exact Or.inr he.symm

theorem successor_injective
    (succ pred : A → A) (predSucc : ∀ n, pred (succ n) = n) :
    ∀ x y, succ x = succ y → x = y := by
  intro x y h
  have hp := congrArg pred h
  simpa only [predSucc] using hp

theorem successor_nonzero
    (zero : A) (succ pred : A → A)
    (separate : zero ≠ succ zero)
    (predZero : pred zero = zero)
    (predSucc : ∀ n, pred (succ n) = n) :
    ∀ n, succ n ≠ zero := by
  intro n hn
  have nz : n = zero := by
    have hp := congrArg pred hn
    simpa only [predSucc, predZero] using hp
  exact separate ((congrArg succ nz).symm.trans hn).symm

/-- This equivalence is the one-term encoding of zero-target propagation. -/
theorem zero_root_equivalence
    (zero : A) (succ pred : A → A) (Z : A → A → A)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (zZero : ∀ a, Z zero a = a)
    (zSucc : ∀ x a, Z (succ x) a = zero)
    (r n : A) :
    (n = zero ∨ r = zero) ↔ (n = zero ∨ Z r n = n) := by
  constructor
  · intro h
    cases h with
    | inl hz => exact Or.inl hz
    | inr hr =>
      apply Or.inr
      rw [hr, zZero]
  · intro h
    cases h with
    | inl hz => exact Or.inl hz
    | inr he =>
      cases coverage r with
      | inl hr => exact Or.inr hr
      | inr hs =>
        have hzero : Z r n = zero := by rw [hs, zSucc]
        exact Or.inl (he.symm.trans hzero)

theorem zero_induction_from_one_term
    (zero : A) (succ pred : A → A) (Z : A → A → A)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (zZero : ∀ a, Z zero a = a)
    (zSucc : ∀ x a, Z (succ x) a = zero)
    (r : A → A → A)
    (propagate : Propagation succ
      (RootedFixed zero (fun n a => Z (r n a) n))) :
    ∀ a, InductionAt zero succ (fun n => r n a = zero) := by
  intro a hbase hstep n
  have reflect := zero_root_equivalence zero succ pred Z coverage zZero zSucc
  have allRooted : ∀ m,
      RootedFixed zero (fun k b => Z (r k b) k) m a := by
    apply propagate a
    intro m hm
    have hm' : m = zero ∨ r m a = zero := (reflect (r m a) m).mpr hm
    have eqHere : r m a = zero := by
      cases hm' with
      | inl hz => simpa only [hz] using hbase
      | inr he => exact he
    exact (reflect (r (succ m) a) (succ m)).mp (Or.inr (hstep m eqHere))
  have hn : n = zero ∨ r n a = zero :=
    (reflect (r n a) n).mpr (allRooted n)
  cases hn with
  | inl hz => simpa only [hz] using hbase
  | inr he => exact he

/-- The compact extra identity D_p(n,n)=q(n,n) implies the unit diagonal.
    Here q is only assumed to have the already recovered seed and tail laws. -/
theorem compact_diagonal_to_unit
    (zero : A) (succ pred : A → A) (q D : A → A → A)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (qOne : ∀ a, q (succ zero) a = a)
    (qTail : ∀ n a, q (succ (succ n)) a = succ zero)
    (compact : ∀ n, D n n = q n n) :
    ∀ n, D (succ n) (succ n) = succ zero := by
  intro n
  rw [compact]
  cases coverage n with
  | inl hz => rw [hz, qOne]
  | inr hs => rw [hs, qTail]

theorem unit_diagonal_to_compact
    (zero : A) (succ pred : A → A) (q D : A → A → A)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (qZero : ∀ a, q zero a = a)
    (qOne : ∀ a, q (succ zero) a = a)
    (qTail : ∀ n a, q (succ (succ n)) a = succ zero)
    (dZero : ∀ a, D zero a = a)
    (diagonal : ∀ n, D (succ n) (succ n) = succ zero) :
    ∀ n, D n n = q n n := by
  intro n
  cases coverage n with
  | inl hz => rw [hz, dZero, qZero]
  | inr hs =>
    rw [hs, diagonal]
    cases coverage (pred n) with
    | inl hp => rw [hp, qOne]
    | inr hp => rw [hp, qTail]

theorem selector_idempotent
    (zero : A) (succ pred : A → A) (C : A → A → A → A)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (cZero : ∀ a b, C zero a b = a)
    (cSucc : ∀ x a b, C (succ x) a b = b) :
    ∀ x a, C x a a = a := by
  intro x a
  cases coverage x with
  | inl hz => rw [hz, cZero]
  | inr hs => rw [hs, cSucc]

theorem difference_zero_diagonal
    (zero : A) (succ pred : A → A) (d : A → A → A)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (predSucc : ∀ x, pred (succ x) = x)
    (dZero : ∀ a, d a zero = a)
    (dSucc : ∀ a n, d a (succ n) = pred (d a n))
    (unitDiagonal : ∀ n, d (succ n) n = succ zero) :
    ∀ n, d n n = zero := by
  intro n
  cases coverage n with
  | inl hz => rw [hz, dZero]
  | inr hs =>
    calc
      d n n = d (succ (pred n)) (succ (pred n)) :=
        congrArg (fun x => d x x) hs
      _ = pred (d (succ (pred n)) (pred n)) := dSucc _ _
      _ = pred (succ zero) := congrArg pred (unitDiagonal (pred n))
      _ = zero := predSucc zero

def Residual (d : A → A → A) (C : A → A → A → A) (n a : A) : A :=
  C (d a n) n (d a (d a n))

/-- The new double-subtraction residual. This theorem uses exactly its own
    target-n induction instance and the one fixed diagonal fact. -/
theorem diagonal_residual
    (zero : A) (succ pred : A → A)
    (d : A → A → A) (C : A → A → A → A)
    (separate : zero ≠ succ zero)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (predZero : pred zero = zero)
    (predSucc : ∀ x, pred (succ x) = x)
    (dZero : ∀ a, d a zero = a)
    (dSucc : ∀ a n, d a (succ n) = pred (d a n))
    (unitDiagonal : ∀ n, d (succ n) n = succ zero)
    (cZero : ∀ a b, C zero a b = a)
    (cSucc : ∀ x a b, C (succ x) a b = b)
    (ind : ∀ a, InductionAt zero succ (fun n => Residual d C n a = n)) :
    ∀ n a, Residual d C n a = n := by
  have zeroDiagonal := difference_zero_diagonal zero succ pred d
    coverage predSucc dZero dSucc unitDiagonal
  have idem := selector_idempotent zero succ pred C coverage cZero cSucc
  intro n a
  apply ind a
  · unfold Residual
    rw [dZero, zeroDiagonal]
    exact idem a zero
  · intro k ih
    cases coverage (d a k) with
    | inl hr =>
      unfold Residual
      rw [dSucc, hr, predZero, cZero]
    | inr hr =>
      let r := pred (d a k)
      have hr' : d a k = succ r := hr
      have ih' : d a (succ r) = k := by
        unfold Residual at ih
        rw [hr', cSucc] at ih
        exact ih
      have px : pred (d a r) = k := (dSucc a r).symm.trans ih'
      have xn : d a r ≠ zero := by
        intro xz
        have kz : k = zero := by
          calc
            k = pred (d a r) := px.symm
            _ = pred zero := congrArg pred xz
            _ = zero := predZero
        have ar : a = succ r := by
          have h := hr'
          rw [kz, dZero] at h
          exact h
        have xo : d a r = succ zero := by rw [ar, unitDiagonal]
        exact separate (xz.symm.trans xo)
      have xs : d a r = succ k := by
        cases coverage (d a r) with
        | inl xz => exact False.elim (xn xz)
        | inr hx => exact hx.trans (congrArg succ px)
      unfold Residual
      rw [dSucc, hr', predSucc, xs]
      exact idem r (succ k)

/-- Native equality is recovered on the entire arbitrary carrier. -/
theorem native_equality_reflection
    (zero : A) (succ pred : A → A)
    (d : A → A → A) (C : A → A → A → A)
    (predSucc : ∀ x, pred (succ x) = x)
    (dZero : ∀ a, d a zero = a)
    (dSucc : ∀ a n, d a (succ n) = pred (d a n))
    (unitDiagonal : ∀ n, d (succ n) n = succ zero)
    (cSucc : ∀ x a b, C (succ x) a b = b)
    (residual : ∀ n a, Residual d C n a = n) :
    ∀ x y, d (succ x) y = succ zero ↔ x = y := by
  intro x y
  constructor
  · intro h
    have hr := residual y (succ x)
    unfold Residual at hr
    rw [h, cSucc, dSucc, dZero, predSucc] at hr
    exact hr
  · intro h
    rw [h, unitDiagonal]

theorem three_constructor_cases
    (zero : A) (succ pred : A → A)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x)) :
    ∀ r, r = zero ∨ r = succ zero ∨ ∃ u, r = succ (succ u) := by
  intro r
  cases coverage r with
  | inl hz => exact Or.inl hz
  | inr hs =>
    cases coverage (pred r) with
    | inl hz => exact Or.inr (Or.inl (hs.trans (congrArg succ hz)))
    | inr hss =>
      exact Or.inr (Or.inr ⟨pred (pred r), hs.trans (congrArg succ hss)⟩)

def OneTest (zero one : A) (pred : A → A) (C : A → A → A → A) (r : A) : A :=
  C r one (C (pred r) zero one)

theorem one_test_specification
    (zero : A) (succ pred : A → A) (C : A → A → A → A)
    (separate : zero ≠ succ zero)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (predSucc : ∀ x, pred (succ x) = x)
    (succNonzero : ∀ x, succ x ≠ zero)
    (cZero : ∀ a b, C zero a b = a)
    (cSucc : ∀ x a b, C (succ x) a b = b) :
    ∀ r,
      (OneTest zero (succ zero) pred C r = zero ∨
       OneTest zero (succ zero) pred C r = succ zero) ∧
      (OneTest zero (succ zero) pred C r = zero ↔ r = succ zero) := by
  intro r
  cases three_constructor_cases zero succ pred coverage r with
  | inl hz =>
    have value : OneTest zero (succ zero) pred C r = succ zero := by
      unfold OneTest
      rw [hz, cZero]
    refine ⟨Or.inr value, ?_⟩
    constructor
    · intro h
      exact False.elim (separate (h.symm.trans value))
    · intro h
      exact False.elim (separate (hz.symm.trans h))
  | inr hs =>
    cases hs with
    | inl ho =>
      have value : OneTest zero (succ zero) pred C r = zero := by
        unfold OneTest
        rw [ho, predSucc, cZero, cSucc]
      exact ⟨Or.inl value, ⟨fun _ => ho, fun _ => value⟩⟩
    | inr hss =>
      cases hss with
      | intro t ht =>
        have value : OneTest zero (succ zero) pred C r = succ zero := by
          unfold OneTest
          rw [ht, predSucc, cSucc, cSucc]
        refine ⟨Or.inr value, ?_⟩
        constructor
        · intro h
          exact False.elim (separate (h.symm.trans value))
        · intro h
          have ss : succ (succ t) = succ zero := ht.symm.trans h
          have sz : succ t = zero :=
            successor_injective succ pred predSucc (succ t) zero ss
          exact False.elim (succNonzero t sz)

def BitSpec (zero one : A) (P : Prop) (bit : A) : Prop :=
  (bit = zero ∨ bit = one) ∧ (P ↔ bit = zero)

theorem native_equality_bit
    (zero : A) (succ pred : A → A)
    (d : A → A → A) (C : A → A → A → A)
    (testSpec : ∀ r,
      (OneTest zero (succ zero) pred C r = zero ∨
       OneTest zero (succ zero) pred C r = succ zero) ∧
      (OneTest zero (succ zero) pred C r = zero ↔ r = succ zero))
    (reflection : ∀ x y, d (succ x) y = succ zero ↔ x = y) :
    ∀ x y, BitSpec zero (succ zero) (x = y)
      (OneTest zero (succ zero) pred C (d (succ x) y)) := by
  intro x y
  have spec := testSpec (d (succ x) y)
  exact ⟨spec.1, (spec.2.trans (reflection x y)).symm⟩

/-- Transfer one represented formula's induction instance from the one
    zero-equation instance for its truth term. The finite truth-term syntax
    compiler itself is outside this file's explicitly stated scope. -/
theorem represented_formula_induction
    (zero : A) (succ : A → A) (P : A → A → Prop) (bit : A → A → A)
    (correct : ∀ n a, P n a ↔ bit n a = zero)
    (ind : ∀ a, InductionAt zero succ (fun n => bit n a = zero)) :
    ∀ a, InductionAt zero succ (fun n => P n a) := by
  intro a hbase hstep n
  have eqBase : bit zero a = zero := (correct zero a).mp hbase
  have eqStep : ∀ m, bit m a = zero → bit (succ m) a = zero := by
    intro m hm
    exact (correct (succ m) a).mp (hstep m ((correct m a).mpr hm))
  exact (correct n a).mpr (ind a eqBase eqStep n)

#print axioms stationary
#print axioms fixedpoint_induction
#print axioms delayed_seeds
#print axioms predecessor_from_fixedpoint
#print axioms rooted_coverage
#print axioms successor_injective
#print axioms successor_nonzero
#print axioms zero_root_equivalence
#print axioms zero_induction_from_one_term
#print axioms compact_diagonal_to_unit
#print axioms unit_diagonal_to_compact
#print axioms difference_zero_diagonal
#print axioms diagonal_residual
#print axioms native_equality_reflection
#print axioms one_test_specification
#print axioms native_equality_bit
#print axioms represented_formula_induction

end OneTermKernel
