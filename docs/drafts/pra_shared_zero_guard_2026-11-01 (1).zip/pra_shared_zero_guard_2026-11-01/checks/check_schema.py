#!/usr/bin/env python3
"""Reproducible syntax checks for the shared-zero-guard PRA schema.

The symbolic counting identities are proved in the report. These finite
checks catch implementation and expansion mistakes; they are not proofs of
PRA equivalence or of the infinite schema. Python standard library only.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import Path
import hashlib
import json
import random


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple["Term", ...] = ()
    name: str = ""
    body: "Term | None" = None


def V(name):
    return Term("var", name=name)


ZERO = Term("zero")
N, A, X = V("n"), V("a"), V("v")


def S(t):
    return Term("succ", (t,))


ONE = S(ZERO)


def D(body, n, a):
    if not active_vars(body) <= {"v"}:
        raise ValueError("Stored descriptor must be unary or constant.")
    return Term("iter", (n, a), body=body)


def active_vars(t):
    if t.tag == "var":
        return {t.name}
    return set().union(*(active_vars(a) for a in t.args))


def subst(t, mapping):
    """Simultaneous active substitution; never enter a stored descriptor."""
    if t.tag == "var":
        return mapping.get(t.name, t)
    return Term(t.tag, tuple(subst(a, mapping) for a in t.args), t.name, t.body)


def tsize(t, inclusive=False):
    return (1 + sum(tsize(a, inclusive) for a in t.args)
            + (tsize(t.body, True) if inclusive and t.body is not None else 0))


def occurrences(t, name):
    return int(t.tag == "var" and t.name == name) + sum(
        occurrences(a, name) for a in t.args)


def rank(t):
    return max([0] + [rank(a) for a in t.args]
               + ([1 + rank(t.body)] if t.body is not None else []))


def pretty(t):
    if t.tag == "var":
        return t.name
    if t.tag == "zero":
        return "0"
    if t.tag == "succ":
        return "S(" + pretty(t.args[0]) + ")"
    return "D_{" + pretty(t.body) + "}(" + ",".join(map(pretty, t.args)) + ")"


@dataclass(frozen=True)
class Formula:
    tag: str
    children: tuple = ()
    binder: str = ""


def eq(x, y):
    return Formula("eq", (x, y))


BOT = Formula("bottom")


def conjunction(p, q):
    return Formula("and", (p, q))


def disjunction(p, q):
    return Formula("or", (p, q))


def implies(p, q):
    return Formula("imp", (p, q))


def forall(v, p):
    return Formula("all", (p,), v)


def fsize(f, inclusive=False):
    if f.tag == "eq":
        return 1 + sum(tsize(t, inclusive) for t in f.children)
    return 1 + sum(fsize(c, inclusive) for c in f.children)


def qcount(f):
    if f.tag == "eq":
        return 0
    return int(f.tag == "all") + sum(qcount(c) for c in f.children)


def qdepth(f):
    if f.tag == "eq":
        return 0
    return int(f.tag == "all") + max([0] + [qdepth(c) for c in f.children])


def fnames(f):
    if f.tag == "eq":
        return set().union(*(active_vars(t) for t in f.children))
    return ({f.binder} if f.tag == "all" else set()).union(
        *(fnames(c) for c in f.children))


def free_vars(f):
    if f.tag == "eq":
        return set().union(*(active_vars(t) for t in f.children))
    found = set().union(*(free_vars(c) for c in f.children))
    return found - {f.binder} if f.tag == "all" else found


def descriptors_term(t):
    c = Counter()
    if t.body is not None:
        c[t.body] += 1
        c += descriptors_term(t.body)
    for a in t.args:
        c += descriptors_term(a)
    return c


def descriptors_formula(f):
    c = Counter()
    if f.tag == "eq":
        for t in f.children:
            c += descriptors_term(t)
    else:
        for child in f.children:
            c += descriptors_formula(child)
    return c


def section(u):
    if not active_vars(u) <= {"n", "a"}:
        raise ValueError("A schema input has at most the slots n and a.")
    return subst(u, {"n": X, "a": ZERO})


def build(u, new):
    h = section(u)
    endpoint = eq(u, subst(u, {"a": S(A)}))
    successor_endpoint = eq(
        subst(u, {"n": S(N)}),
        subst(u, {"n": S(N), "a": S(A)}))
    root = eq(N, ZERO)
    p = disjunction(root, endpoint)
    progress = forall("n", implies(p, successor_endpoint))
    separator = implies(eq(ZERO, ONE), BOT)
    reset = eq(D(h, D(ONE, N, ZERO), A), A)
    if new:
        tail = eq(D(h, S(N), A), subst(h, {"v": D(h, N, A)}))
        result = conjunction(separator, conjunction(reset, disjunction(
            root, conjunction(endpoint, tail))))
    else:
        tail = eq(D(h, S(S(N)), A), subst(h, {"v": D(h, S(N), A)}))
        result = conjunction(p, conjunction(separator, conjunction(reset, tail)))
    return forall("a", implies(progress, forall("n", result)))


def corpus():
    bodies = [ZERO, ONE, X, S(X), D(S(X), X, ZERO),
              D(ZERO, S(X), ONE), D(D(S(X), X, ZERO), S(X), ZERO)]
    named = [
        ("0", ZERO), ("a", A), ("n", N), ("S(n)", S(N)),
        ("D_S(n,a)", D(S(X), N, A)),
        ("D_S(n,n)", D(S(X), N, N)),
        ("D_S(D_S(n,n),a)", D(S(X), D(S(X), N, N), A)),
        ("D_p(n,a)", D(D(S(X), X, ZERO), N, A)),
    ]
    rng = random.Random(20261101)

    def random_term(depth):
        if depth == 0 or rng.random() < 0.38:
            return rng.choice([ZERO, N, A])
        if rng.random() < 0.4:
            return S(random_term(depth - 1))
        return D(rng.choice(bodies), random_term(depth - 1),
                 random_term(depth - 1))

    terms = list(dict.fromkeys(t for _, t in named))
    seen = set(terms)
    while len(terms) < 600:
        t = random_term(5)
        if t not in seen:
            terms.append(t)
            seen.add(t)
    return named, terms


def run():
    named, terms = corpus()
    rows = []
    for u in terms:
        old, new = build(u, False), build(u, True)
        U, W = tsize(u), tsize(u, True)
        k, j = occurrences(u, "n"), occurrences(u, "a")
        old_active, new_active = fsize(old), fsize(new)
        old_full, new_full = fsize(old, True), fsize(new, True)
        assert old_active == 38 + 7 * U + 5 * k + 3 * j
        assert new_active == 37 + 7 * U + 4 * k + 3 * j
        assert old_full == 40 + (9 + k) * W + 5 * k + 3 * j
        assert new_full == 39 + (9 + k) * W + 4 * k + 3 * j
        assert old_active - new_active == old_full - new_full == 1 + k
        assert descriptors_formula(old) == descriptors_formula(new)
        for f in [old, new]:
            assert qcount(f) == 3 and qdepth(f) == 2
            assert fnames(f) == {"n", "a"}
            assert free_vars(f) == set()
        h = section(u)
        assert active_vars(h) <= {"v"}
        assert rank(D(h, N, A)) == rank(h) + 1
        rows.append((u, old_active, new_active, old_full, new_full, k))

    # Descriptor extraction is literal for parameter-independent inputs.
    for h in [ZERO, ONE, X, S(X), D(S(X), X, ZERO),
              D(D(S(X), X, ZERO), X, ZERO)]:
        u = subst(h, {"v": N})
        assert section(u) == h
        assert subst(u, {"a": S(A)}) == u

    # Substitution changes active arguments and preserves stored bodies.
    stored = D(S(X), X, ZERO)
    source = D(stored, N, A)
    changed = subst(source, {"n": S(N), "a": ZERO, "v": ONE})
    assert changed.body is stored
    assert changed.args == (S(N), ZERO)
    # Simultaneous substitution does not recursively resubstitute its image.
    assert subst(N, {"n": A, "a": ZERO}) == A

    rejection_checks = 0
    for action in [lambda: section(V("b")), lambda: D(A, N, A)]:
        try:
            action()
        except ValueError:
            rejection_checks += 1
        else:
            raise AssertionError("Malformed syntax was accepted.")
    assert rejection_checks == 2

    # Bounded diagnostic for the explicit standard-N reversed-Tail
    # counterinterpretation in the report. The proof there is unbounded.
    def bad_d(n, a):
        return a if n == 0 else 0

    examples = [lambda x: 0, lambda x: 1, lambda x: x, lambda x: x + 1]
    diagnostic_count = 0
    for h in examples:
        for n in range(8):
            for a in range(6):
                assert bad_d(bad_d(n, 0), a) == a
                assert bad_d(n + 2, a) == bad_d(n + 1, h(a))
                diagnostic_count += 1
    assert bad_d(2, 0) != bad_d(1, 0) + 1

    index = {row[0]: row for row in rows}
    example_rows = []
    for label, u in named:
        _, old, new, old_full, new_full, k = index[u]
        example_rows.append({
            "input": label, "expanded_input": pretty(u),
            "old_active": old, "new_active": new, "saving": 1 + k,
            "old_descriptor_inclusive": old_full,
            "new_descriptor_inclusive": new_full})
    result = {
        "status": "PASS", "seed": 20261101,
        "distinct_terms_checked": len(terms),
        "formula_count": 2 * len(terms),
        "symbolic_active_sizes": {
            "old": "38 + 7*U + 5*k + 3*j",
            "new": "37 + 7*U + 4*k + 3*j"},
        "symbolic_descriptor_inclusive_sizes": {
            "old": "40 + (9+k)*W + 5*k + 3*j",
            "new": "39 + (9+k)*W + 4*k + 3*j"},
        "saving_in_both_conventions": "1+k",
        "maximum_active_input_size": max(tsize(t) for t in terms),
        "maximum_descriptor_rank": max(rank(t) for t in terms),
        "all_quantifier_counts": 3, "all_quantifier_depths": 2,
        "all_active_names": ["a", "n"],
        "descriptor_multisets_identical": True,
        "malformed_input_rejections": rejection_checks,
        "bounded_countermodel_checks": diagnostic_count,
        "examples": example_rows,
        "scope": "Finite diagnostics, not a mechanization of the infinite schema."
    }
    return result


if __name__ == "__main__":
    result = run()
    root = Path(__file__).resolve().parents[1]
    (root / "audit").mkdir(exist_ok=True)
    (root / "audit" / "syntax_check.json").write_text(
        json.dumps(result, indent=2) + "\n")
    summary = [
        "PASS: 600 distinct terms; 1200 expanded formulas.",
        "Both exact size formulas and saving 1+occ_n(u) checked.",
        "Three quantifiers, depth two, active names n/a, no free variables.",
        "Frozen descriptors and identical descriptor multisets checked.",
        "Malformed-input controls and bounded reversed-Tail diagnostic passed.",
        "",
        "Input                         Old  New  Saving  Full-old  Full-new",
    ]
    for row in result["examples"]:
        summary.append(
            f'{row["input"]:<30}{row["old_active"]:>4} '
            f'{row["new_active"]:>4} {row["saving"]:>6} '
            f'{row["old_descriptor_inclusive"]:>9} '
            f'{row["new_descriptor_inclusive"]:>9}')
    text = "\n".join(summary) + "\n"
    (root / "checks" / "examples.txt").write_text(text)
    print(text, end="")
