import Init

/-!
Constructive local kernel for the shared root guard presentation of PRA.

Scope: an arbitrary carrier and finitely selected interpretation functions
represent the constant-one descriptor, constant-zero descriptor, and one
arbitrary descriptor.  Every arithmetic/schema premise is an explicit
argument.  This is not an encoding of first-order syntax, nor a claim that
the object language quantifies over functions.  The written report supplies
the descriptor grammar, the term-schemaInstance selections, and PRA calibration.

No classical reasoning, additional axioms, or admitted declarations occur.
-/

namespace GuardedTailKernel

universe u
variable {A : Type u}

def Progress (zero : A) (succ : A → A) (E : A → A → Prop) (a : A) : Prop :=
  ∀ n, (n = zero ∨ E n a) → E (succ n) a

def OldInstance (zero : A) (succ : A → A) (q D : A → A → A)
    (body : A → A) (E : A → A → Prop) : Prop :=
  ∀ a, Progress zero succ E a → ∀ n,
    (n = zero ∨ E n a) ∧
    ((zero ≠ succ zero) ∧
      (D (q n zero) a = a ∧
        D (succ (succ n)) a = body (D (succ n) a)))

def NewInstance (zero : A) (succ : A → A) (q D : A → A → A)
    (body : A → A) (E : A → A → Prop) : Prop :=
  ∀ a, Progress zero succ E a → ∀ n,
    (zero ≠ succ zero) ∧
    (D (q n zero) a = a ∧
      (n = zero ∨ (E n a ∧ D (succ n) a = body (D n a))))

theorem extractReflexive
    (zero : A) (succ : A → A) (q D : A → A → A) (body : A → A)
    (schemaInstance : NewInstance zero succ q D body (fun n _ => body n = body n)) :
    (zero ≠ succ zero) ∧
    ((∀ n a, D (q n zero) a = a) ∧
      (∀ n a, n = zero ∨ D (succ n) a = body (D n a))) := by
  have extracted : ∀ n a,
      (zero ≠ succ zero) ∧
      (D (q n zero) a = a ∧
        (n = zero ∨ (body n = body n ∧
          D (succ n) a = body (D n a)))) := by
    intro n a
    exact schemaInstance a (fun _ _ => rfl) n
  constructor
  · exact (extracted zero zero).1
  constructor
  · intro n a
    exact (extracted n a).2.1
  · intro n a
    cases (extracted n a).2.2 with
    | inl root => exact Or.inl root
    | inr tail => exact Or.inr tail.2

theorem guardedSeeds
    (zero : A) (succ : A → A) (q D : A → A → A)
    (separation : zero ≠ succ zero)
    (qReset : ∀ n a, q (q n zero) a = a)
    (reset : ∀ n a, D (q n zero) a = a)
    (qGuard : ∀ n a, n = zero ∨ q (succ n) a = succ zero) :
    (∀ a, D zero a = a) ∧ (∀ a, D (succ zero) a = a) := by
  have qTwo : q (succ (succ zero)) zero = succ zero := by
    cases qGuard (succ zero) zero with
    | inl collapsed => exact False.elim (separation collapsed.symm)
    | inr value => exact value
  have seedOne : ∀ a, D (succ zero) a = a := by
    intro a
    have equation := reset (succ (succ zero)) a
    rw [qTwo] at equation
    exact equation
  have qOne : q (succ zero) zero = zero := by
    have equation := qReset (succ (succ zero)) zero
    rw [qTwo] at equation
    exact equation
  constructor
  · intro a
    have equation := reset (succ zero) a
    rw [qOne] at equation
    exact equation
  · exact seedOne

theorem successorNonzeroFromGuard
    (zero : A) (succ : A → A) (q Z : A → A → A)
    (separation : zero ≠ succ zero)
    (qReset : ∀ n a, q (q n zero) a = a)
    (zeroReset : ∀ n a, Z (q n zero) a = a)
    (qGuard : ∀ n a, n = zero ∨ q (succ n) a = succ zero)
    (zeroGuard : ∀ n a, n = zero ∨ Z (succ n) a = zero) :
    ∀ n, succ n ≠ zero := by
  have seedZero := (guardedSeeds zero succ q Z separation qReset zeroReset qGuard).1
  intro n collapsed
  cases zeroGuard n (succ zero) with
  | inl atRoot =>
      rw [atRoot] at collapsed
      exact separation collapsed.symm
  | inr atTail =>
      rw [collapsed, seedZero] at atTail
      exact separation atTail.symm

theorem recoverDelayedTail
    (zero : A) (succ : A → A) (D : A → A → A) (body : A → A)
    (successorNonzero : ∀ n, succ n ≠ zero)
    (guardedTail : ∀ n a, n = zero ∨ D (succ n) a = body (D n a)) :
    ∀ n a, D (succ (succ n)) a = body (D (succ n) a) := by
  intro n a
  cases guardedTail (succ n) a with
  | inl impossible => exact False.elim (successorNonzero n impossible)
  | inr tail => exact tail

theorem delayedTailToGuard
    (zero : A) (succ pred : A → A) (D : A → A → A) (body : A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (delayedTail : ∀ n a, D (succ (succ n)) a = body (D (succ n) a)) :
    ∀ n a, n = zero ∨ D (succ n) a = body (D n a) := by
  intro n a
  cases coverage n with
  | inl root => exact Or.inl root
  | inr predecessor =>
      apply Or.inr
      have equation := delayedTail (pred n) a
      rw [← predecessor] at equation
      exact equation

theorem newProjectsPropagation
    (zero : A) (succ : A → A) (q D : A → A → A)
    (body : A → A) (E : A → A → Prop)
    (schemaInstance : NewInstance zero succ q D body E) :
    ∀ a, Progress zero succ E a → ∀ n, n = zero ∨ E n a := by
  intro a progress n
  cases (schemaInstance a progress n).2.2 with
  | inl root => exact Or.inl root
  | inr equalityAndTail => exact Or.inr equalityAndTail.1

theorem newToOld
    (zero : A) (succ : A → A) (q D : A → A → A)
    (body : A → A) (E : A → A → Prop)
    (successorNonzero : ∀ n, succ n ≠ zero)
    (schemaInstance : NewInstance zero succ q D body E) :
    OldInstance zero succ q D body E := by
  intro a progress n
  have here := schemaInstance a progress n
  constructor
  · exact newProjectsPropagation zero succ q D body E schemaInstance a progress n
  constructor
  · exact here.1
  constructor
  · exact here.2.1
  · cases (schemaInstance a progress (succ n)).2.2 with
    | inl impossible => exact False.elim (successorNonzero n impossible)
    | inr equalityAndTail => exact equalityAndTail.2

theorem oldToNew
    (zero : A) (succ pred : A → A) (q D : A → A → A)
    (body : A → A) (E : A → A → Prop)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (schemaInstance : OldInstance zero succ q D body E) :
    NewInstance zero succ q D body E := by
  intro a progress n
  have here := schemaInstance a progress n
  constructor
  · exact here.2.1
  constructor
  · exact here.2.2.1
  · cases here.1 with
    | inl root => exact Or.inl root
    | inr equality =>
        cases coverage n with
        | inl root => exact Or.inl root
        | inr predecessor =>
            apply Or.inr
            constructor
            · exact equality
            · have equation := (schemaInstance a progress (pred n)).2.2.2
              rw [← predecessor] at equation
              exact equation

theorem selectedInstancesGiveSuccessorNonzero
    (zero : A) (succ : A → A) (q Z : A → A → A)
    (oneInstance : NewInstance zero succ q q (fun _ => succ zero)
      (fun _ _ => succ zero = succ zero))
    (zeroInstance : NewInstance zero succ q Z (fun _ => zero)
      (fun _ _ => zero = zero)) :
    ∀ n, succ n ≠ zero := by
  have oneFacts := extractReflexive zero succ q q (fun _ => succ zero) oneInstance
  have zeroFacts := extractReflexive zero succ q Z (fun _ => zero) zeroInstance
  exact successorNonzeroFromGuard zero succ q Z oneFacts.1
    oneFacts.2.1 zeroFacts.2.1 oneFacts.2.2 zeroFacts.2.2

theorem selectedNewToOld
    (zero : A) (succ : A → A) (q Z D : A → A → A)
    (body : A → A) (E : A → A → Prop)
    (oneInstance : NewInstance zero succ q q (fun _ => succ zero)
      (fun _ _ => succ zero = succ zero))
    (zeroInstance : NewInstance zero succ q Z (fun _ => zero)
      (fun _ _ => zero = zero))
    (schemaInstance : NewInstance zero succ q D body E) :
    OldInstance zero succ q D body E := by
  exact newToOld zero succ q D body E
    (selectedInstancesGiveSuccessorNonzero zero succ q Z oneInstance zeroInstance) schemaInstance

#print axioms extractReflexive
#print axioms guardedSeeds
#print axioms successorNonzeroFromGuard
#print axioms recoverDelayedTail
#print axioms delayedTailToGuard
#print axioms newProjectsPropagation
#print axioms newToOld
#print axioms oldToNew
#print axioms selectedInstancesGiveSuccessorNonzero
#print axioms selectedNewToOld

end GuardedTailKernel
