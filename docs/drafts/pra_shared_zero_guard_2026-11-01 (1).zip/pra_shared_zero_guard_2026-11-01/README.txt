PRA BY SHARING THE ZERO GUARD
Research deliverable for Vladimir Reshetnikov, 1 November 2026.

RESULT
The smallest current adjacent-parameter one-term schema can be shortened
uniformly by sharing its zero disjunction with its iteration equation.
The language, one binary term input, constructor count, two-name budget,
three quantifiers, and depth two are unchanged.

The saving is exactly 1 + the number of active n occurrences in the input
term, under both active-tree and descriptor-inclusive repeated-tree counts.
The proof is intuitionistic. In each matching logic the theory is
definitionally equivalent, bi-interpretable, and equiconsistent with
first-order PRA, preserving the entire carrier and native equality.

START HERE
  report.pdf       Complete mathematical paper.
  report.tex       Main LaTeX source.
  AXIOMS.txt       Exact standalone specification.
  sections/        All included LaTeX sections.

SUPPORTING ARTIFACTS
  formal/GuardedTailKernel.lean
      Checked local proof of the new guarded recurrence reduction.
      Lean 4.19.0; imports only Init; ten theorems, no axiom dependencies.
  formal/SCOPE.txt
      What is and is not mechanized.
  checks/check_schema.py
      Deterministic exact syntax checks: 600 inputs, 1200 formulas.
  checks/examples.txt
      Representative expanded size comparisons.
  audit/
      Actual Lean output and hash; syntax-check JSON; independent
      mathematical review notes; pinned source-archive manifest.
  build.py
      Reproduce checks and compile PDF; no downloads.
  SHA256SUMS.txt
      Hashes of the supplied package files (excluding this hash list).

BUILD
  python3 build.py

Requirements: Python 3 and pdfLaTeX with the ordinary packages listed in
report.tex. To repeat Lean as well:
  python3 build.py --lean /absolute/path/to/lean

Or invoke:
  lean formal/GuardedTailKernel.lean

SOURCE COMPARISON
All five files in ProveIt/docs/drafts at commit
9e77f2a2bb9ccf0a4f85934f1f83df8a3f8767be were reviewed.
The exact same-input baseline is the adjacent-parameter presentation
shared by pra_adjacent_parameter_2026-11-01.zip and the (1) variant
of pra_one_term_one_schema_2026-11-01.zip.

The new result is Section 2 of the report. The full arithmetic calibration
is adapted with attribution from the current adjacent drafts so that the
deliverable includes proofs of equality reflection, pairing, compilation,
and both internal round trips. It is not presented as newly discovered.
The original comparison archives are not duplicated here.

LIMITS
No encoding-independent minimum is proved. The effective language and
schema are infinite. The Lean artifact checks the new local reduction,
not the entire first-order definitional-equivalence proof. Python tests
are finite diagnostics. These boundaries are stated in the report.
