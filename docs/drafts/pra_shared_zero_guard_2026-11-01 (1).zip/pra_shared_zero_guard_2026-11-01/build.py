#!/usr/bin/env python3
"""Build the report and repeat the finite checks; no downloads."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lean", help="Optional path to Lean 4.19.0.")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    audit = root / "audit"
    audit.mkdir(exist_ok=True)
    subprocess.run([sys.executable, str(root / "checks/check_schema.py")],
                   cwd=root, check=True)
    if args.lean:
        version = subprocess.run([args.lean, "--version"], cwd=root,
                                 text=True, capture_output=True, check=True)
        check = subprocess.run(
            [args.lean, "formal/GuardedTailKernel.lean"], cwd=root,
            text=True, capture_output=True, check=True)
        (audit / "lean-version.txt").write_text(version.stdout + version.stderr)
        (audit / "lean-check.txt").write_text(check.stdout + check.stderr)
        source = root / "formal/GuardedTailKernel.lean"
        records = {
            "version_exit": version.returncode, "check_exit": check.returncode,
            "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "theorems_reported": check.stdout.count("does not depend on any axioms"),
            "contains_axiom_dependency": "depends on axioms" in check.stdout,
        }
        (audit / "verification.json").write_text(json.dumps(records, indent=2) + "\n")
    latex = shutil.which("pdflatex")
    if not latex:
        raise SystemExit("pdfLaTeX is required to compile report.tex.")
    for number in range(1, 4):
        result = subprocess.run(
            [latex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=root, text=True, capture_output=True)
        (audit / f"latex_pass_{number}.txt").write_text(
            result.stdout + result.stderr)
        if result.returncode:
            print(result.stdout[-6000:], file=sys.stderr)
            raise SystemExit(result.returncode)
    print("Built report.pdf; syntax checks passed.")
    if not args.lean:
        print("Lean was not rerun by this invocation; the supplied audit records its checked run.")


if __name__ == "__main__":
    main()
