"""Optional larger sweeps for the same syntax boundaries as the normal suite.

Run explicitly when changing the opening algorithm or computation dispatcher:
  python3 validation/exhaustive.py --mode openings
  python3 validation/exhaustive.py --mode computations
These are finite tests, not a formal soundness proof. They are deliberately
separate from the normal reproduction run to avoid redundant routine checks.
"""
import argparse
import itertools
import json
from pathlib import Path
import platform

from oracle import Oracle
from validate import digest, load_checker, numerical_value, trace

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent

def attempt(f,*args):
    try:return True,f(*args)
    except Exception:return False,None

def openings(module):
    leaves=[None,False,True,-4,-1,-0.5,0,0.5,1,1.5,2,3,4,100,
            '', 'x','xx','xxxx',{}, {'':3}, {'x':3},
            float('nan'),float('inf'),float('-inf')]
    objects=leaves+[[]]
    objects += [[x] for x in leaves]
    objects += [[x,y] for x,y in itertools.product(leaves[:16],repeat=2)]
    objects += [[x,0,y] for x,y in itertools.product(leaves[:16],repeat=2)]
    objects += [[0,0,0,0],[[],[],[]],[[[]],[],[[]]],[[0,0],0],
                [0,[0,0]],[0,0,[0,0]]]
    images=[None,0,-1,1,[],[0],[1],[[0],0,0],{},'']
    checks=0
    for lower,depth,value,image in itertools.product((0,-1,-3),range(6),objects,images):
        module.k=lower
        oracle=Oracle();oracle.lower=lower
        method=oracle.formula if depth%2==0 else oracle.term
        actual=attempt(module.inst,value,image,depth)
        expected=attempt(method,value,image,depth//2)
        if actual!=expected:
            raise AssertionError((lower,depth,value,image,actual,expected))
        checks+=1
    return {'opening_comparisons':checks,'all_agreed':True}

def computations(module):
    values=[0,False,0.5,[],'',{},[0],[[]],{'':None},[[0]],[[[]]],
            [1],[3],1,2,3,4]
    checks=accepted=0
    for count,initial,update,right in itertools.product(values,repeat=4):
        goal=[[count,initial,update],right]
        checks+=1
        if not trace(module,[[],goal])[0]:continue
        accepted+=1
        module.k=0
        normalized=module.inst(goal)
        left_value,right_value=[numerical_value(term) for term in normalized]
        if left_value!=right_value:
            raise AssertionError((goal,normalized,left_value,right_value))
    return {'computation_packets':checks,'accepted_equalities':accepted,
            'false_equations_accepted':0}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode',choices=('openings','computations','both'),required=True)
    parser.add_argument('--checker',type=Path,default=ROOT/'checker.py')
    args=parser.parse_args()
    module=load_checker(args.checker)
    receipt={'status':'PASS','python':platform.python_version(),
             'checker_sha256':digest(args.checker),'script_sha256':digest(Path(__file__)),
             'oracle_sha256':digest(HERE/'oracle.py'),'mode':args.mode}
    if args.mode in ('openings','both'):receipt.update(openings(module))
    if args.mode in ('computations','both'):receipt.update(computations(module))
    path=ROOT/'results'/('exhaustive_'+args.mode+'.json')
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
