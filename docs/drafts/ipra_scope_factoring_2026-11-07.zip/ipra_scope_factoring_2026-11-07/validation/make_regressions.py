"""Build documented regression packets from frozen sources and explicit examples.

The translation adds the same unused/doubled numerical slots as uniform_scopes.
It is a finite syntax operation used only for regression data, never trusted by
checker.py. A rejected packet is not a claim that its conclusion is unprovable.
"""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent

def number(n,env,new_depth):
    if not isinstance(n,(int,float)) or n<=0:return n
    i=(int(n)-1)//2
    target=env[i] if i<len(env) else i+new_depth-len(env)
    return n+2*(target-i)

def term(a,env=(),new_depth=0):
    if not isinstance(a,list):return number(a,env,new_depth)
    if not a:return []
    if len(a)==1:return [term(a[0],tuple(i+1 for i in env),new_depth+1)]
    if len(a)==3:
        shifted=tuple(i+2 for i in env)
        return [term(a[0],shifted,new_depth+2),term(a[1],shifted,new_depth+2),
                term(a[2],(0,)+shifted,new_depth+2)]
    return deepcopy(a)

def formula(a,env=(),new_depth=0):
    if not isinstance(a,list):return number(a,env,new_depth)
    if not a:return []
    if len(a)==1:
        return [formula(a[0],(0,)+tuple(i+1 for i in env),new_depth+1)]
    if len(a)==2:return [term(x,env,new_depth) for x in a]
    if len(a)==3:
        return [formula(x,(0,1)+tuple(i+2 for i in env),new_depth+2) for x in a]
    return deepcopy(a)

def packet(p):
    out=[]
    for a in p[:-1]:
        if isinstance(a,list) and len(a)==2:
            m,t=a
            out.append([formula(m),formula(t) if isinstance(m,list) and len(m)==2 else term(t)])
        elif a==[]:out.append([])
        else:out.append(term(a))
    return out+[formula(p[-1])]

NEW=[
('reject_wrong_initializer', [[], [[0,[0],0],0]], False, 'The zero computation returns its initializer, not an unconditional zero.'),
('empty_count', [[], [[[],0,0],0]], True, 'An empty numerical array denotes the zero iterator count.'),
('empty_count_wrong_value', [[], [[[],0,0],[0]]], False, 'The empty count cannot change a zero initializer into one.'),
('empty_initializer', [[], [[0,[],0],[]]], True, 'Empty arrays can denote the initializer and its resulting zero.'),
('empty_update_zero', [[], [[0,0,[]],0]], True, 'An empty update denotes the constant-zero operation.'),
('empty_update_successor', [[], [[[0],0,[]],[]]], True, 'The empty update also computes zero at a successor count.'),
('empty_successor_count', [[], [[[[]],0,0],0]], True, 'Successor of an empty numerical zero is an admitted count.'),
('empty_successor_state', [[], [[[[]],[],1],[[],[],1]]], True, 'Successor computation with an empty initializer and state update.'),
('empty_formula_matrix', [0,[[],[],[]]], True, 'The empty formula matrix denotes truth; retained assumptions are harmless truths.'),
('empty_formula_padding', [0,[[],[],[0,0]]], True, 'Empty truth padding does not affect the meaningful third matrix.'),
('empty_witness_instruction_reserved', [[],[[],[],[]]], False, 'An empty instruction remains the computation instruction, not an introduction witness.'),
('empty_root_needs_a_derivation', [0,[]], False, 'Truth completion does not make an arbitrary one-cell proof instruction succeed.'),
('empty_count_future_update', [[],[[[],0,-1],0]], False, 'An empty count cannot hide an unallocated parameter in its update.'),
('empty_does_not_enable_binary_term', [[],[[[],[0,0],0],[0,0]]], False, 'Empty completion preserves the ban on numerical binary nodes.'),
('empty_does_not_enable_four_children', [0,[[],[],[],[]]], False, 'A four-child formula is still invalid.'),
('empty_padding_future_parameter', [0,[[],[],[-1,0]]], False, 'Truth padding cannot hide a future rigid parameter.'),
('nonlist_empty_string', [[],[['',0,0],0]], False, 'An empty string does not pass the retained list gate.'),
('nonlist_empty_object', [[],[[{},0,0],0]], False, 'An empty object does not pass the retained list gate.'),
('nonlist_single_empty_key', [[],[[{'':None},0,0],0]], False, 'An object containing one empty key is not numerical syntax.'),
('nonempty_string', [[],[['x',0,0],0]], False, 'A used nonempty string rejects without recursive character expansion.'),
]

def main():
    index_path=ROOT/'examples/index.json'
    index=json.loads(index_path.read_text())
    index=[x for x in index if not x.get('added_by_scope_factoring')]
    records=list(NEW)
    sources=json.loads((HERE/'inherited_attack_sources.json').read_text())
    for r in sources['records']:
        records.append(('regression_'+r['name'],packet(r['packet']),False,
                        'Scope-completed inherited regression: '+r['name'].replace('_',' ')+'.'))
    for name,p,expected,description in records:
        path=ROOT/'examples'/f'{name}.json'
        path.write_text(json.dumps(p,indent=2)+'\n')
        index.append({'file':path.name,'expected':expected,'description':description,
                      'sha256':sha256(path.read_bytes()).hexdigest(),
                      'added_by_scope_factoring':True})
    index_path.write_text(json.dumps(index,indent=2)+'\n')
    print(f'Wrote {len(records)} new cases; total public cases: {len(index)}')

if __name__=='__main__':main()
