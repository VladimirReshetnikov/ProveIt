REPRODUCIBLE VALIDATION
======================

From the complete delivered package directory:

  python3 validation/validate.py

The runner expects checker.py and examples/ in its parent directory, so it
also works when invoked by absolute path from another working directory.
Use --checker /absolute/path/checker.py to assess another copy, and
--interface stdin only if that copy deliberately uses standard input.
The principal public interface takes a JSON filename as its first argument.

The main run writes results/validation.json and reports the exact checker,
runner, oracle, and fixture hashes. It exercises all 147 inherited positive
certificates, finite mutations, all published examples, false conclusions,
malformed JSON syntax, interval boundaries, sorted substitution, dummy and
duplicate numerical scopes, and empty-array completion. The independent oracle
has separate numerical/formula traversals and explicit named inference rules;
it does not share the checker's packed offset table or match dispatcher.

The numerical evaluator separately checks decoded substitution and accepted
computation equations. Six deliberate faulty variants must be detected:
permitted future parameters, compound induction hypotheses, first-child
introduction, binary numerical syntax, discarded initializers, and capture
through an unvalidated substitution image. These variants exist only in memory
inside the validation process; the delivered checker is not edited.

All 47 public packets and five additional varied positive fixtures run through
the actual public JSON/file interface both normally and under Python -O.
Malformed JSON and command-line conditions are checked separately. In-memory
comparisons additionally check the consumed proof stack and fresh-name floor,
not just the acceptance verdict. Counts overlap across categories and should
not be summed as independent mathematical theorems.

Results from the inspected final source:
- 5,225 packet/oracle comparisons, including 147 unchanged positive fixtures.
- 2,080 explicit opening comparisons across two sorts and six local depths.
- 1,000 decoded numerical substitutions, with no evaluation-budget skips.
- 800 generated computation equations checked numerically, with no skips.
- 15 named opening regressions.
- All six deliberate faults detected.
- 128 command-line executions, normal and optimized, all with expected status,
  stdout and stderr.
The receipt, not these descriptive counts, identifies the exact tested source.

OPTIONAL LARGER CHECKS

When changing opening or computation code, the targeted larger sweeps remain
available separately:

  python3 validation/exhaustive.py --mode openings
  python3 validation/exhaustive.py --mode computations

They write their own source-hashed receipts and are not part of the normal
run. The opening grid has 102,060 cases and the computation grid has 83,521
packets. They include disallowed empty strings/objects and nonfinite parser
extensions, not just accepted canonical syntax. No previous experimental
checker receipt is presented as evidence about a changed final source.

FIXTURE REGENERATION

  python3 validation/make_regressions.py

This regenerates only the new documented examples and their index entries
from explicit cases and the small frozen attack-source file. It does not need
network access and does not rewrite the 147 inherited positive certificates.
The named opening fixtures are in opening_cases.json. See ATTRIBUTION.txt and
LICENSE-inherited.txt for source lineage and permission.

These are finite implementation checks. The report supplies written
mathematical arguments; this package does not claim a Lean/Rocq formalization
or a machine-checked metatheorem.
