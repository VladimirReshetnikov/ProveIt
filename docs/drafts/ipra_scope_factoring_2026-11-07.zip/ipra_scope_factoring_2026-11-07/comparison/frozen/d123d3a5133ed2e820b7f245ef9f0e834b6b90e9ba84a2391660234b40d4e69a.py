"""Independent typed-tree audit of the successor-initialized recursion kernels.

The proof kernel never imports this file. This audit records successful kernel
calls, then checks each inference using a separate, explicit two-sort parser
and a binder-aware operation on tagged tuples. It does not use the kernel's
packed depth, table, or opening implementation in its oracle.
"""
from copy import deepcopy
from dataclasses import dataclass, field
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from translator import load_kernel, negative_parameters, require, transport

ROOT = Path(__file__).resolve().parent


def parse(raw, sort, floor, closed=False, depth=0, holes=0):
    if sort == 'term' and type(raw) is int:
        if raw == 0:
            return ('zero',)
        if raw < 0:
            require(raw >= floor or not closed and raw % 2 == 1,
                    'undeclared numerical parameter')
            return ('free', raw)
        coordinate = (raw + 1) // 2
        require(coordinate <= depth + holes, 'escaping bound coordinate')
        return ('bound', coordinate)
    require(type(raw) is list, 'a noninteger syntax node must be an array')
    if sort == 'term':
        if len(raw) == 1:
            return ('succ', parse(raw[0], sort, floor, closed, depth, holes))
        require(len(raw) == 3, 'invalid term arity')
        return ('rec', parse(raw[0], sort, floor, closed, depth, holes),
                parse(raw[1], sort, floor, closed, depth, holes),
                parse(raw[2], sort, floor, closed, depth + 2, holes))
    if len(raw) == 1:
        return ('q', parse(raw[0], sort, floor, closed, depth + 1, holes))
    if len(raw) == 2:
        return ('eq', *(parse(x, 'term', floor, closed, depth, holes) for x in raw))
    require(len(raw) == 3, 'invalid formula arity')
    return ('ex', *(parse(x, sort, floor, closed, depth + 1, holes) for x in raw))


def opening(tree, images, depth=0):
    tag = tree[0]
    if tag == 'bound':
        if tree[1] <= depth:
            return tree
        image = images[tree[1] - depth - 1]
        return image() if callable(image) else image
    if tag in ('zero', 'free'):
        return tree
    if tag == 'succ':
        return ('succ', opening(tree[1], images, depth))
    if tag == 'rec':
        return ('rec', opening(tree[1], images, depth),
                opening(tree[2], images, depth),
                opening(tree[3], images, depth + 2))
    if tag == 'eq':
        return ('eq', opening(tree[1], images, depth), opening(tree[2], images, depth))
    return (tag, *(opening(t, images, depth + 1) for t in tree[1:]))


@dataclass
class Node:
    goal: object
    context: list
    floor: int
    cells: list = field(default_factory=list)
    children: list = field(default_factory=list)
    accepted: bool = False
    final_floor: int = 0


def recorded_run(certificate, context=(), closed=False):
    module = load_kernel(ROOT / ('checker.py' if closed else 'checker_open.py'), 'recorded')
    module.k = 0
    for formula in context:
        module.inst(formula)
    stream = deepcopy(certificate)
    root_goal = stream.pop()
    active = []
    roots = []
    original = module.check

    def take():
        value = stream.pop()
        active[-1].cells.append(deepcopy(value))
        return value

    def check(goal, gamma):
        node = Node(deepcopy(goal), deepcopy(gamma), module.k)
        (active[-1].children if active else roots).append(node)
        active.append(node)
        try:
            node.accepted = bool(original(goal, gamma))
            return node.accepted
        finally:
            node.final_floor = module.k
            active.pop()

    module.check = check
    module.take = take
    error = None
    try:
        accepted = check(root_goal, deepcopy(list(context)))
    except Exception as exc:
        accepted = False
        error = type(exc).__name__
    return accepted, roots[0], len(stream), error


def audit_node(node, closed=False):
    require(node.accepted, 'a successful trace includes a rejected node')
    p = lambda value, sort='formula', holes=0, floor=node.floor: parse(
        value, sort, floor, closed, holes=holes)
    goal = p(node.goal)
    gamma = [p(a) for a in node.context]
    step = 1 if closed else 2
    if not node.cells:
        require(node.goal in node.context and goal in gamma, 'bad automatic hypothesis')
        require(not node.children, 'a hypothesis consumed a subtree')
        return 1
    require(len(node.cells) == 1, 'a node consumed several local instructions')
    cell = node.cells[0]
    children = node.children

    def child(index, expected, expected_context):
        ch = children[index]
        require(parse(ch.goal, 'formula', ch.floor, closed) == expected,
                'wrong independently decoded child goal')
        actual_context = [parse(a, 'formula', ch.floor, closed) for a in ch.context]
        require(actual_context == expected_context, 'wrong child assumptions')

    if type(cell) is list and len(cell) == 2:
        require(len(children) == 2, 'elimination needs two premises')
        major = p(cell[0])
        child(0, major, gamma)
        floor = children[0].final_floor
        if major[0] == 'ex':
            fresh = floor - step
            require(children[1].floor == fresh, 'incorrect existential eigenname allocation')
            child(1, goal, gamma + [opening(major[1], [('free', fresh)])])
        elif major[0] == 'q':
            witness = lambda: parse(cell[1], 'term', floor, closed)
            require(opening(major[1], [witness]) == goal, 'bad Q elimination target')
            child(1, opening(major[1], [('zero',)]), gamma)
        else:
            motive = parse(cell[1], 'formula', floor, closed, holes=1)
            require(opening(motive, [major[2]]) == goal, 'bad equality transport target')
            child(1, opening(motive, [major[1]]), gamma)
    elif goal[0] == 'q' and cell == []:
        require(len(children) == 1, 'closure introduction needs one premise')
        fresh = node.floor - step
        require(children[0].floor == fresh, 'incorrect closure eigenname allocation')
        matrix = goal[1]
        base = opening(matrix, [('zero',)])
        hypotheses = [opening(matrix, [('free', fresh)]), base] if matrix[0] == 'eq' else [base]
        child(0, opening(matrix, [('succ', ('free', fresh))]), gamma + hypotheses)
    elif goal[0] == 'ex' and type(cell) is list and len(cell) == 1:
        require(len(children) == 1, 'existential introduction needs one premise')
        witness = lambda: parse(cell[0], 'term', node.floor, closed)
        child(0, opening(goal[1], [witness]), gamma)
    else:
        require(cell == [] and goal[0] == 'eq' and goal[1][0] == 'rec',
                'unrecognized proof instruction')
        require(not children, 'a computation consumed premises')
        counter, initial, update = goal[1][1:]
        if counter == ('zero',):
            result = ('succ', initial)
        else:
            require(counter[0] == 'succ', 'computation counter is neither zero nor successor')
            n = counter[1]
            result = opening(update, [('rec', n, initial, update), n])
        require(goal[2] == result, 'incorrect recursion computation equation')
    return 1 + sum(audit_node(c, closed) for c in children)


def oracle_run(certificate, context=(), closed=False):
    accepted, root, remaining, error = recorded_run(certificate, context, closed)
    nodes = audit_node(root, closed) if accepted else 0
    return {'accepted': accepted, 'nodes': nodes, 'remaining': remaining, 'error': error}


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def alias(value):
    if type(value) is int and value > 0:
        return value + 1 if value % 2 else value
    if type(value) is list:
        return [alias(v) for v in value]
    if type(value) is dict:
        return {k: alias(v) for k, v in value.items()}
    return value


def main():
    provenance = json.loads((ROOT / 'provenance.json').read_text())
    for key in ('source_checker', 'fixture_manifest'):
        item = provenance[key]
        require(hashlib.sha256((ROOT / item['local_file']).read_bytes()).hexdigest()
                == item['sha256'], 'changed inherited source: ' + key)
    fixture_manifest = json.loads((ROOT / 'source_fixtures/manifest.json').read_text())
    for item in fixture_manifest['files']:
        require(hashlib.sha256((ROOT / 'source_fixtures' / item['file']).read_bytes()).hexdigest()
                == item['sha256'], 'changed inherited fixture: ' + item['file'])
    records = []
    public = []
    for kind in ('theorems', 'open_sequents'):
        for path in sorted((ROOT / 'source_fixtures' / kind).glob('*.json')):
            value = json.loads(path.read_text())
            context = value['validated_external_context'] if kind == 'open_sequents' else []
            certificate = value['stack'] + [value['goal']] if context else value
            for closed in (False, True):
                target, summary = transport(certificate, context, closed=closed)
                translated_context = summary['translated_context']
                for alternate in (False, True):
                    actual = alias(target) if alternate else target
                    gamma = alias(translated_context) if alternate else translated_context
                    result = oracle_run(actual, gamma, closed)
                    require(result['accepted'] and result['remaining'] == 0,
                            'transported fixture does not have a complete audited derivation')
                    records.append({'source': path.name, 'kind': kind,
                                    'closed': closed, 'alternate_coordinates': alternate, **result})
                if kind == 'theorems':
                    name = ('closed_' if closed else 'open_') + path.name
                    output = ROOT / 'examples' / name
                    write_json(output, target)
                    public.append((output, closed, True))

    truth = [0, 0]
    falsehood = [0, [0]]
    base_cases = {
        'falsehood': [falsehood],
        'old_zero_axiom_is_invalid': [[], [[0, 0, 0], 0]],
        'capture_under_recursor_witness': [[], [1], [[[0, 0, 5], [0]], truth, truth]],
        'capture_under_closure_witness': [[], [1], [[[3, 3]], truth, truth]],
        'falsehood_instruction': [[], falsehood],
        'reflexivity_missing_proof': [truth],
        'unmatched_instruction': [None, [[0, 0, 0], 0]],
        'future_even_parameter': [[], [[0, -2, 0], -2]],
        'positive_root_coordinate': [[], [[0, 1, 0], 1]],
        'future_even_witness': [[-2], [[1, 1], truth, truth]],
        'positive_witness': [[1], [[1, 1], truth, truth]],
        'missing_R_successor': [[], [[-1, 0, 0], 0]],
        'invalid_R_counter': [[], [[[0, 0, 0], 0, 0], 0]],
        'undeclared_even_in_padding': [[0], [truth, [-2, -2], truth]],
        'compound_step_needs_proof': [[], [], [[[1, 3], truth, truth]]],
    }
    bad_scalars = [True, False, None, 0.0, 1.0, '', 'x', {}, []]
    for i, value in enumerate(bad_scalars):
        base_cases[f'scalar_goal_{i}'] = [[], value]
        base_cases[f'scalar_eq_leaf_{i}'] = [[], [[0, 0, 0], value]]
        base_cases[f'scalar_rec_initial_{i}'] = [[], [[0, value, 0], 0]]
        base_cases[f'scalar_rec_step_{i}'] = [[], [[0, 0, value], 0]]
    for arity in (0, 4, 5, 8):
        base_cases[f'formula_arity_{arity}'] = [[], [truth] * arity]
        base_cases[f'term_arity_{arity}'] = [[], [[0, [0] * arity, 0], [0] * arity]]
    for kind, certificate in base_cases.items():
        for closed in (False, True):
            result = oracle_run(certificate, closed=closed)
            require(not result['accepted'], 'a hostile certificate was accepted: ' + kind)
            out = ROOT / 'rejected' / (kind + '.json')
            write_json(out, certificate)
            public.append((out, closed, False))

    # Hostile conclusion substitutions cannot exploit bool/float equality aliases.
    corrupted = []
    for path, closed, accepted in public.copy():
        if not accepted:
            continue
        value = json.loads(path.read_text())
        value[-1] = deepcopy(falsehood)
        result = oracle_run(value, closed=closed)
        require(not result['accepted'], 'proof accepted with false root conclusion')
        corrupted.append({'source': path.name, 'closed': closed})

    cli = []
    for path, closed, expected in public:
        for optimized in (False, True):
            command = [sys.executable] + (['-O'] if optimized else [])
            command += [str(ROOT / ('checker.py' if closed else 'checker_open.py')), str(path)]
            p = subprocess.run(command, capture_output=True, text=True, timeout=15)
            require(p.returncode == (0 if expected else 1), 'wrong public exit status')
            require(p.stdout.strip() == ('ACCEPT' if expected else 'REJECT'), 'wrong public verdict')
            cli.append({'file': path.name, 'closed': closed, 'optimized': optimized,
                        'accepted': expected, 'exit_code': p.returncode})

    result = {'status': 'passed', 'source_public_theorems': 45,
              'source_open_sequents': sum(r['kind'] == 'open_sequents' for r in records) // 4,
              'audited_transports': len(records),
              'independently_audited_inference_nodes': sum(r['nodes'] for r in records),
              'hostile_inputs_per_kernel': len(base_cases),
              'false_root_substitutions': len(corrupted), 'cli_runs': len(cli),
              'records': records, 'cli': cli,
              'limit': 'Finite regression evidence; not a formal metatheorem proof.'}
    write_json(ROOT / 'audit_results.json', result)
    print(json.dumps({k: v for k, v in result.items() if k not in ('records', 'cli')}, indent=2))


if __name__ == '__main__':
    main()
