"""Complete iPRA checker with numerical leaves interpreted by integer intervals.

A successful non-list leaf is a finite JSON number. Its numerical meaning
is determined by its floor; a formula leaf denotes truth. The kernel never
computes that floor. The two computation schemas and five native inference
patterns are inherited; the interval interpretation justifies removing the
separate list-coercion guard. See report.pdf for the soundness proof.
"""
import json, sys
k = 0

def inst(a, t=None, d=0):
    if type(a) != list:
        return a if k <= a < d else inst(t, d=1)
    return [inst(b, t, d + w) for b, w in zip(a, (0, 0, b'\x02', b'\x00', b'\x01\x01', 0, b'\x04\x04\x04', b'\x00\x00\x02')[len(a) * 2 + d % 2])]

def check(a, g):
    global k
    if inst(a) in g:
        return True
    match take():
        case [m, t] if check(m, g):
            if m[2:]:
                h = [m[2:]]
            else:
                if not m[1:]:
                    t, m = (m[0], [0, t])
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(r, [n, t, r], 1)
            return b == t
        case t:
            a = inst(a[2], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
    k -= 1
    return check(inst(a, [k]), g + [inst(c, k) for c in h])
try:
    take = json.load(open(sys.argv[1])).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
