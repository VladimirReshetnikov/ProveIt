"""Closed-sentence iPRA checker with parameters declared before use."""
import json
import sys
k = 0


def inst(a, t=None, d=0):
    if type(a) is int and d % 2 and k <= a < d + 2:
        return a if a < d else inst(t, d=1)
    return [inst(b, t, d=d + w) for b, w in zip(a + [], (0, 0, b'\2', b'\0', b'\1\1', 0, b'\4\4\4', b'\0\0\2')[2 * len(a) + d % 2])]


def check(a, g):
    global k
    if inst(a) in g:
        return True
    match (a, take()):
        case [b, [m, t]] if check(m, g):
            if m[2:]:
                h = [m[:1]]
            else:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
        case [b, [t]]:
            b = inst(b[0], t, d=2)
            h = [b, inst(b, 0)][len(b) % 2:]
        case [[[n, t, h], b], []]:
            if n:
                n, = n
                t = inst(h, [n, t, h], d=1)
            return b == t
    k -= 1
    return check(inst(b, [k]), g + [inst(c, k) for c in h])


if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except:
        print('REJECT')
        sys.exit(1)
