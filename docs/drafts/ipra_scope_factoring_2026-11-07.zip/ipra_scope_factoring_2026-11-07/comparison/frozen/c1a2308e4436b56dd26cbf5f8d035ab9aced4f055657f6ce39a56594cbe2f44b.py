"""Independent explicit-grammar oracle for the proof-stream-clock calculus.

This is untrusted validation code, not part of the measured acceptance kernel.
It does not import a kernel or reuse its opening/validation implementation.

Numerical coordinates are decoded to fresh *named* bound variables. Opening
then substitutes named free holes, after separately checking each demanded
image as a closed-at-depth-zero numerical term. Re-encoding preserves the
odd/even spelling of protected coordinates, so comparisons match the literal
certificate contract rather than silently quotienting variable aliases.

The parser receives a frozen stream length. A negative name a is permitted
exactly when a < -remaining. Unused images and unread prefix contents supply
no inferences; prefix length still contributes to the namespace clock.
"""

from copy import deepcopy
from dataclasses import dataclass
import json
from pathlib import Path
import sys


class InvalidCertificate(ValueError):
    pass


@dataclass(frozen=True)
class Node:
    kind: str
    children: tuple = ()
    value: object = None


class NamedSyntax:
    def __init__(self):
        self.serial = 0

    def fresh(self):
        self.serial += 1
        return f"bound_{self.serial}"

    @staticmethod
    def sequence(raw, permitted, sort):
        if type(raw) is not list or len(raw) not in permitted:
            raise InvalidCertificate(f"invalid {sort} constructor")

    def term(self, raw, bound, remaining):
        if type(raw) is int:
            if raw == 0:
                return Node("zero")
            if raw < 0:
                if raw >= -remaining:
                    raise InvalidCertificate("negative name lies in reserved interval")
                return Node("parameter", value=raw)
            coordinate = (raw + 1) // 2
            if coordinate <= len(bound):
                return Node("variable", value=(bound[coordinate - 1], raw % 2))
            return Node("hole", value=coordinate - len(bound) - 1)

        self.sequence(raw, {1, 3}, "term")
        if len(raw) == 1:
            return Node("successor", (self.term(raw[0], bound, remaining),))
        previous_value, previous_counter = self.fresh(), self.fresh()
        return Node(
            "recursor",
            (
                self.term(raw[0], bound, remaining),
                self.term(raw[1], bound, remaining),
                self.term(raw[2], (previous_value, previous_counter) + bound, remaining),
            ),
            (previous_value, previous_counter),
        )

    def formula(self, raw, bound, remaining):
        self.sequence(raw, {1, 2, 3}, "formula")
        if len(raw) == 2:
            return Node("equality", tuple(self.term(t, bound, remaining) for t in raw))
        variable = self.fresh()
        matrices = tuple(self.formula(b, (variable,) + bound, remaining) for b in raw)
        return Node("closure" if len(raw) == 1 else "existential", matrices, variable)

    @staticmethod
    def substitute(tree, resolve):
        """Substitute free named holes; bound names have disjoint identities."""
        if tree.kind == "hole":
            return resolve(tree.value)
        return Node(
            tree.kind,
            tuple(NamedSyntax.substitute(child, resolve) for child in tree.children),
            tree.value,
        )

    def encode(self, tree, bound=()):
        if tree.kind == "zero":
            return 0
        if tree.kind == "parameter":
            return tree.value
        if tree.kind == "variable":
            name, odd_spelling = tree.value
            try:
                coordinate = bound.index(name) + 1
            except ValueError as error:
                raise InvalidCertificate("bound name escaped its binder") from error
            return 2 * coordinate - odd_spelling
        if tree.kind == "hole":
            raise InvalidCertificate("unresolved free coordinate")
        if tree.kind == "successor":
            return [self.encode(tree.children[0], bound)]
        if tree.kind == "recursor":
            return [
                self.encode(tree.children[0], bound),
                self.encode(tree.children[1], bound),
                self.encode(tree.children[2], tree.value + bound),
            ]
        if tree.kind == "equality":
            return [self.encode(child, bound) for child in tree.children]
        if tree.kind in {"closure", "existential"}:
            return [self.encode(child, (tree.value,) + bound) for child in tree.children]
        raise InvalidCertificate("unknown named node")

    def open(self, raw, images=(), *, numerical=False, remaining=0):
        """Decode, perform capture-free substitution, and preserve literal aliases.

        Every used image is independently parsed with an empty binder context.
        This is the essential defense against a positive free coordinate in an
        image being captured by a binder in the surrounding matrix.
        """
        parser = self.term if numerical else self.formula
        tree = parser(raw, (), remaining)

        def no_holes(_):
            raise InvalidCertificate("substitution image is not closed at depth zero")

        def resolve(index):
            try:
                image = images[index]
            except (IndexError, KeyError, TypeError) as error:
                raise InvalidCertificate("missing substitution image") from error
            named_image = self.term(image, (), remaining)
            return self.substitute(named_image, no_holes)

        return self.encode(self.substitute(tree, resolve))


class ReferenceChecker:
    """Follow the inference rules using the independent named syntax above."""

    def __init__(self, packet):
        if type(packet) is not list:
            raise InvalidCertificate("the document must be a JSON list")
        self.stream = deepcopy(packet)
        self.syntax = NamedSyntax()
        self.allocations = []
        self.calls = 0

    def opening(self, raw, images=(), *, numerical=False):
        return self.syntax.open(
            raw, images, numerical=numerical, remaining=len(self.stream)
        )

    def enter_scope(self, matrix, assumptions, extra):
        remaining = len(self.stream)
        name = -remaining - 1
        self.allocations.append({"remaining": remaining, "name": name})
        successor_instance = self.opening(matrix, [[name]])
        local_assumptions = [self.opening(a, [name]) for a in extra]
        return self.check(successor_instance, assumptions + local_assumptions)

    def check(self, goal, assumptions):
        self.calls += 1
        # Validate before consuming the current rule instruction.
        self.opening(goal)
        instruction = self.stream.pop()

        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, assumptions):
                # The successful major has already passed the explicit grammar.
                if len(major) == 3:
                    return self.enter_scope(goal, assumptions, [major[0]])
                if len(major) == 1:
                    motive, left, right = major[0], 0, annotation
                else:
                    motive, left, right = annotation, major[0], major[1]
                conclusion = self.opening(motive, [right])
                return conclusion == goal and self.check(
                    self.opening(motive, [left]), assumptions
                )
            # A major that returns false can fall back to an actual assumption.
            # Its consumed instructions remain consumed, but no assumptions escape.
            return goal in assumptions

        if instruction == [] and type(instruction) is list:
            if len(goal) == 1:
                matrix = goal[0]
                base = self.opening(matrix, [0])
                extra = [matrix, base] if len(matrix) == 2 else [base]
                return self.enter_scope(matrix, assumptions, extra)

            if len(goal) == 2 and type(goal[0]) is list and len(goal[0]) == 3:
                counter, initializer, update = goal[0]
                if counter == 0 and type(counter) is int:
                    computed = initializer
                elif type(counter) is list and len(counter) == 1:
                    predecessor = counter[0]
                    recursive_value = [predecessor, initializer, update]
                    computed = self.opening(
                        update, [recursive_value, predecessor], numerical=True
                    )
                else:
                    raise InvalidCertificate("recursor counter is neither zero nor successor")
                return goal[1] == computed

        if len(goal) == 3 and type(instruction) is list and len(instruction) == 1:
            return self.check(self.opening(goal[0], instruction), assumptions)

        return goal in assumptions

    def run(self):
        goal = self.stream.pop()
        return self.check(goal, [])


def inspect(packet):
    checker = None
    try:
        checker = ReferenceChecker(packet)
        accepted = bool(checker.run())
        reason = "accepted" if accepted else "no applicable derivation"
    except Exception as error:
        accepted = False
        reason = f"{type(error).__name__}: {error}"
    return {
        "accepted": accepted,
        "reason": reason,
        "calls": 0 if checker is None else checker.calls,
        "unread": None if checker is None else len(checker.stream),
        "allocations": [] if checker is None else checker.allocations,
    }


def verdict(packet):
    return inspect(packet)["accepted"]


if __name__ == "__main__":
    try:
        result = inspect(json.loads(Path(sys.argv[1]).read_text()))
    except Exception as error:
        result = {"accepted": False, "reason": f"{type(error).__name__}: {error}"}
    print("ACCEPT" if result["accepted"] else "REJECT")
    sys.exit(0 if result["accepted"] else 1)
