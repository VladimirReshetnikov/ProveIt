"""Complete scalar-iterator iPRA checker with Boolean numerical aliases.

JSON false aliases code 0; JSON true aliases bound-variable code 1.
The numerical update binds only the previous value. Closure introduction
is an admissible extra branch justified by separation of the two sorts.
"""
import json, sys
k = 0

def inst(a, *env, d=0):
    if isinstance(a, int) and d % 2 and (a >= k):
        return a if a < d else inst(env[a - d >> 1], d=1)
    return [inst(b, *env, d=d + w) for b, w in zip(a + [], (0, 0, b'\x02', b'\x00', b'\x01\x01', 0, b'\x04\x04\x04', b'\x00\x00\x02')[len(a) * 2 + d % 2])]

def check(a, g):
    global k
    if inst(a) in g:
        return True
    match (a, take()):
        case [b, [m, t]] if check(m, g):
            if m[2:]:
                h = [m[:1]]
            else:
                if not m[1:]:
                    t, m = (m[0], [0, t])
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
        case [b, [t]]:
            b, = inst(b[:1], t)
            h = [b, inst(b, 0)][len(b) % 2:]
        case [[[n, t, r], b], []]:
            if n:
                n, = n
                t = inst(r, [n, t, r], d=1)
            return b == t
    k -= 1
    return check(inst(b, [k]), g + [inst(c, k) for c in h])
if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except:
        print('REJECT')
        sys.exit(1)
