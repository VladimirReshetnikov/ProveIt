"""Experimental one-binder iPRA checker with reusable rule hypotheses.
D is a singleton formula, binding two variables. Context entries [P,Q]
stand for the reusable rule from P to each numerical instance of Q.
A retained ordinary assumption A is the arrow T -> A, where T is the
fixed computation theorem Iter(0,0;u.0)=0.
"""
import json, sys
k = 0


def inst(a, t=None, d=0):
    if type(a) is int and d % 2:
        return a if k <= a < d else inst(t, d=1)
    return [inst(b, t, d + w) for b, w in zip(a + [], (0, 0, b'\4', b'\0', b'\1\1', 0, 0, b'\0\0\2')[len(a) * 2 + d % 2])]


def check(a, g):
    global k
    inst(a)
    match take():
        case [int(i), t]:
            p, q = g[i]
            return inst(q, t) == a and check(p, g)
        case [m, t] if check(m, g):
            if m[1:]:
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
            k -= 1
            b = inst(m[0], k, 2)
            return check(a, g + [[inst(b, 0), b]])
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(r, [n, t, r], 1)
            return b == t
        case t:
            a = inst(a[0], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
    k -= 1
    return check(inst(a, [k]), g + [[[[0, 0, 0], 0], inst(c, k)] for c in h])


try:
    take = json.load(open(sys.argv[1])).pop
    accepted = check(take(), [])
except:
    accepted = False
print('ACCEPT' if accepted else 'REJECT')
sys.exit(not accepted)
