"""Complete iPRA checker with empty-array zero/truth completion.

The paired formula's meaningful matrix is its third entry. Direct closure
introduction is absent; canonical proofs expand it through paired rules.
Integer formula leaves and empty formula arrays denote truth; empty numerical
arrays denote zero. No project-specific helper or translator is imported.
"""
import json, sys
k = 0


def inst(a, t=None, d=0):
    if isinstance(a, int):
        return a if k <= a < d else inst(t, d=1)
    return [inst(b, t, d + w) for b, w in zip(a + [], (b'\4\4\4', b'\0\0\2', b'\1\1', 0, b'\2', b'\0')[d % 2 - len(a) * 2])]


def check(a, g):
    global k
    if inst(a) in g:
        return True
    match take():
        case [m, t] if check(m, g):
            if not m[2:]:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
            h = [m[2:]]
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(r, [n, t, r], 1)
            return b == t
        case t:
            a = inst(a[2], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
    k -= 1
    return check(inst(a, [k]), g + [inst(c, k) for c in h])


try:
    take = json.load(open(sys.argv[1])).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
