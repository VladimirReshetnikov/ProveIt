"""Closed-sentence iPRA checker with context-bounded local eigenparameters."""
import json
import sys


def check(a, g):
    k = -len(g)

    def inst(a, e=(), d=0, s=1):
        if type(a) is int and not s and a >= k:
            return a if a <= d else inst(e[a - d - 1], s=0)
        return [inst(b, e, d + w, w == 1) for b, w in zip(a + [], ((None, b'\0', None, b'\0\0\2'), (None, b'\1', b'\0\0', b'\1\1\1'))[s][len(a)])]

    b = inst(a)
    match (a, take()):
        case [_, [m, t]] if check(m, g):
            if len(m) == 3:
                h = m[:1]
            else:
                if len(m) == 1:
                    t, m = m[0], [0, t]
                b, c = (inst(t, [v]) for v in m)
                return c == a and check(b, g)
        case [[b], []]:
            h = [inst(b, [0]), b][:2 - len(b) % 2]
        case [[b, _, _], [t]]:
            return check(inst(b, [t]), g)
        case [[[n, t, h], b], []]:
            if n:
                n, = n
                t = inst(h, ([n, t, h], n), s=0)
            return b == t
        case _:
            return a in g
    k -= 1
    return check(inst(b, [[k]]), g + [inst(c, [k]) for c in h])


if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
