import json, sys
k = 0


def inst(a, t=None, d=0):
    if type(a) is int and d % 2:
        return a if k <= a < d else inst(t, d=1)
    return [inst(b, t, d + w) for b, w in zip(a + [], (0, b'\0', b'\4', 0, b'\1\1', b'\0\0\2', 0)[2 * len(a) - d % 2])]


def check(a, g):
    global k
    inst(a)
    match take():
        case [i, t, _]:
            b, *p = g[i]
            return inst(b, t) == a and all(check(c, g) for c in p)
        case [m, t] if check(m, g):
            if m[1:]:
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
            k -= 1
            b = inst(m[0], k, 2)
            return check(a, g + [[b, inst(b, 0)]])
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(r, [n, t, r], 1)
            return b == t
        case t:
            a = inst(a[0], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
            k -= 1
            return check(inst(a, [k]), g + [[inst(c, k)] for c in h])


try:
    take = json.load(open(sys.argv[1])).pop
    if not check(take(), []):
        raise ValueError
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
