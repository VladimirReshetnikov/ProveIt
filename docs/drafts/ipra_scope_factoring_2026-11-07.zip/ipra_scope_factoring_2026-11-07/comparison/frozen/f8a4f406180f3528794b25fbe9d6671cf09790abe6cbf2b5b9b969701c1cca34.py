"""Scalar-iterator iPRA checker with raw witness instructions.

The complete trust boundary is this file plus Python/JSON standard semantics.
All matrices, terms, binding depths, schema instances, and premise proofs are
checked here. The external validation and comparison scripts are not imported.
An introduction instruction is its witness term itself; a two-element list
selects elimination, and an empty list selects a computation equation when
its goal has the required iterator shape. See the accompanying specification.
"""
import json, sys
k = 0


def inst(a, *env, d=0):
    if type(a) is int and d % 2 and a >= k:
        return a if a < d else inst(env[a - d >> 1], d=1)
    return [inst(b, *env, d=d + w) for b, w in zip(a + [], (0, 0, b'\2', b'\0', b'\1\1', 0, b'\4\4\4', b'\0\0\2')[2 * len(a) + d % 2])]


def check(a, g):
    global k
    if inst(a) in g:
        return True
    match (a, take()):
        case [b, [m, t]] if check(m, g):
            if m[2:]:
                h = [m[:1]]
            else:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
        case [[[n, t, h], b], []]:
            if n:
                n, = n
                t = inst(h, [n, t, h], d=1)
            return b == t
        case [b, t]:
            b = inst(b[0], t, d=2)
            h = [b, inst(b, 0)][len(b) % 2:]
    k -= 1
    return check(inst(b, [k]), g + [inst(c, k) for c in h])


if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except:
        print('REJECT')
        sys.exit(1)
