"""iPRA with context-derived eigenparameters and scalar iteration.

No global variable allocator: the active assumption count bounds rigid
parameter codes and determines the next fresh name. Each local-variable
rule extends the context by at least one assumption.
"""
import json, sys
def check(a, g):
    k = -len(g)

    def inst(a, t=None, d=0):
        if isinstance(a, int) and d % 2 and a >= k:
            return a if a < d else inst(t, d=1)
        return [inst(b, t, d + w) for b, w in zip(a + [], (0, 0, b'\2', b'\0', b'\1\1', 0, b'\4\4\4', b'\0\0\2')[len(a) * 2 + d % 2])]

    if inst(a) in g:
        return True
    match take():
        case [m, t] if check(m, g):
            if m[2:]:
                h = [m[:1]]
            else:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(r, [n, t, r], d=1)
            return b == t
        case t:
            a = inst(a[0], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
    k -= 1
    return check(inst(a, [k]), g + [inst(c, k) for c in h])


try:
    take = json.load(open(sys.argv[1])).pop
    accepted = check(take(), [])
except:
    accepted = False
print('ACCEPT' if accepted else 'REJECT')
sys.exit(not accepted)
