"""Standalone iPRA certificate checker with uniform completed scopes.

Numerical unary nodes bind zero. Iterator count and seed bind two zeros;
its update binds two copies of the preceding state. Formula scalar leaves
mean truth. The report specifies the complete certificate interpretation.
"""
import json, sys
k = 0


def inst(a, t=None, d=0):
    try:
        return [inst(b, t, d + w) for b, w in zip(a + [], (0, b'\2', (b'\1\1', 0)[d % 2], b'\4\4\4')[len(a)])]
    except:
        return a if k <= a < d else inst(t, d=1)


def check(a, g):
    global k
    if inst(a) in g:
        return True
    match take():
        case [m, t] if check(m, g):
            if m[2:]:
                h = [m[2:]]
            else:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(r, [n, t, r], 1)
            return b == t
        case t:
            a = inst(a[2], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
    k -= 1
    return check(inst(a, [k]), g + [inst(c, k) for c in h])


try:
    take = json.load(open(sys.argv[1])).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
