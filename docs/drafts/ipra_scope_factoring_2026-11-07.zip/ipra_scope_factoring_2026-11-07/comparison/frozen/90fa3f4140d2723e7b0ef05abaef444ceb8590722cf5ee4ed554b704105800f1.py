"""Reproduce proof transport and independent audit of the combined kernel."""
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types

from absorption_bridge import tr, p, formula, compile_proof, emit, raw_formula, transport, SUPPORT
from named_oracle import Oracle, opening

HERE=Path(__file__).resolve().parent
KERNEL=HERE.parent/'checker.py'
module=tr.load_kernel(KERNEL,'combined_fusion_absorption')
T=[0,0]


def capture_attack():
    x,y,e=tr.fresh(),tr.fresh(),tr.fresh()
    step=tr.gate_convert(tr.refl(tr.S(e)),tr.Eq(tr.S(e),tr.S(e)),tr.S(e),True)
    source=tr.d_intro(tr.D(x,y,tr.gate(tr.Eq(y,y),y)),0,e,step)
    packet,_=emit(compile_proof(source))
    false=tr.D(x,y,tr.gate(tr.Eq(x,y),y))
    packet[-1]=raw_formula(formula(false),{})
    # 5 is the protected y coordinate at the insertion under the two
    # accumulator/counter binders of the compiled arithmetic selector.
    packet[-2]=[5]
    return packet


def escape_attack():
    x,y,e,a=(tr.fresh() for _ in range(4))
    body=tr.gate(tr.Eq(x,0),y)
    step=tr.gate_convert(tr.refl(0),tr.Eq(0,0),tr.S(e),True)
    major=tr.d_intro(tr.D(x,y,body),0,e,step)
    closure=tr.Q(y,tr.sf(body,x,a))
    ungated=tr.Eq(a,0)
    extracted=tr.q_elim(tr.hyp(closure),tr.S(0),tr.gate_zero(ungated))
    minor=tr.gate_convert(extracted,ungated,tr.S(0),False)
    proof=compile_proof(tr.d_elim(major,a,minor))
    original=tr.raw_formula; tr.raw_formula=raw_formula
    try:
        emitter=tr.Emitter()
        emitter.emit(proof,scope={a:-2})
        tr.require(emitter.k == -2,'Unexpected escape-attack allocation')
        return emitter.cells[::-1]+[raw_formula(proof.goal,{a:-2})]
    finally:
        tr.raw_formula=original


def induction_attack():
    x,y,e,z,u,v,hole=(tr.fresh() for _ in range(7))
    def value(t):
        return tr.R(t,0,u,v,u)
    body=tr.Q(z,tr.Eq(value(y),0))
    computation=tr.comp(value(tr.S(e)),value(e))
    step=tr.eq_elim(tr.sym(computation),hole,tr.Q(z,tr.Eq(hole,0)),
                    tr.hyp(tr.sf(body,y,e)))
    proof=compile_proof(step)
    original=tr.raw_formula; tr.raw_formula=raw_formula
    try:
        emitter=tr.Emitter(); emitter.k=-1; emitter.cells.append([0])
        scope={e:-1}
        extra=[raw_formula(formula(tr.sf(body,y,0)),scope),
               raw_formula(formula(tr.sf(body,y,e)),scope)]
        emitter.emit(proof,extra,scope)
        return emitter.cells[::-1]+[raw_formula(formula(tr.D(x,y,body)),{})]
    finally:
        tr.raw_formula=original


def boundaries():
    comp=[[[0],0,3],0] # A(S0,0;u,v.v)=0
    reflexive=[[],[],[comp,[1,0]],T]
    return [
      ('zero_computation',[[],[[0,0,0],[0]]],True),
      ('successor_computation',[[],comp],True),
      ('derived_reflexivity',reflexive,True),
      ('D_constant',[[0],[T]],True),
      ('D_used_witness',[[0],[[3,3]]],True),
      ('D_used_witness_alias',[[0],[[3,4]]],True),
      ('D_unused_future_witness',[[-999],[T]],True),
      ('D_unused_object_witness',[[{}],[T]],True),
      ('unused_prefix',[None,[0],[T]],True),
      ('old_zero_axiom_invalid',[[],[[0,0,0],0]],False),
      ('false_equality',[[],[0,[0]]],False),
      ('undeclared_root_parameter',[[],[-1,-1]],False),
      ('unbound_root_coordinate',[[],[1,1]],False),
      ('boolean_is_not_zero',[[],[[0,False,0],[False]]],False),
      ('float_is_not_zero',[[],[[0,0.0,0],[0.0]]],False),
      ('used_future_witness',[[-1],[[3,3]]],False),
      ('used_unbound_witness',[[1],[[3,3]]],False),
      ('used_boolean_witness',[[True],[[3,3]]],False),
      ('used_object_witness',[[{}],[[3,3]]],False),
      ('used_recursive_witness_leaks_coordinate',[[[0,0,5]],[[3,3]]],False),
      ('missing_D_witness',[[],[T]],False),
      ('multiple_D_witnesses',[[0,0],[T]],False),
      ('scalar_D_witness',[0,[T]],False),
      ('direct_Q_introduction_removed',[[],[T,T,T]],False),
      ('bad_Q_padding',[[],[T,None,T]],False),
      ('future_parameter_in_Q_padding',[[],[T,[-1,-1],T]],False),
      ('unbound_coordinate_in_Q_padding',[[],[T,[3,3],T]],False),
      ('empty_formula',[[],[]],False),
      ('false_capture',capture_attack(),False),
      ('false_eigenparameter_escape',escape_attack(),False),
      ('illegal_compound_induction',induction_attack(),False),
    ]


def audit_opening():
    counts=Counter()
    atoms=[-3,-2,-1,0,1,2,3,4,5,6,True,None,{}]
    terms=[*atoms,[],[0],[1],[5],[0,0],[0,0,1],[0,0,3],[0,0,5],
           [1,0,[0,3,7]],[0,0,[0,1,9]]]
    formulas=[[t,0] for t in terms]
    formulas += [[[t,0]] for t in (-2,0,1,2,3,4,5,6)]
    formulas += [[[t,0],[1,2],[1,2]] for t in (-2,0,1,2,3,4,5,6)]
    formulas += [[],None,{},[True],[[0,0],[5,5],[0,0]],
                 [[[5,1]],[[3,4]],[[1,2]]],[[[[0,0,9],5]],[0,0],[0,0]]]
    images=[(),(0,),(-1,),(-3,),(1,),([0],),([0,0,3],),([0,0,5],),(0,[0])]
    for is_formula,values in ((True,formulas),(False,terms)):
      for value in values:
       for depth in (0,1,2):
        for lower in (0,-2):
         for env in images:
          module.k=lower
          try:
            a=module.inst(deepcopy(value),*deepcopy(env),d=2*depth+(not is_formula)); av=True
          except Exception:
            a,av=None,False
          try:
            b=opening(deepcopy(value),deepcopy(env),formula=is_formula,depth=depth,lower=lower); bv=True
          except Exception:
            b,bv=None,False
          if av != bv or av and a != b:
            raise AssertionError((value,env,depth,lower,is_formula,a,b,av,bv))
          counts['valid' if av else 'invalid'] += 1
    return dict(counts)


def check(packet,expected):
    actual=tr.run_target(module,deepcopy(packet))
    oracle=Oracle().run(deepcopy(packet))
    if actual['accepted'] != expected or oracle['accepted'] != expected:
        raise AssertionError({'actual':actual,'oracle':oracle,'expected':expected,'packet':packet})
    if expected:
        for key in ('remaining','final_k'):
            if actual[key] != oracle[key]: raise AssertionError((key,actual,oracle))
    return {'kernel':actual,'oracle':oracle}


def main():
    output=HERE.parent/'examples';output.mkdir(exist_ok=True)
    rows=[]; packets=[]
    for group in ('declared','declared_aliases'):
        for path in sorted((SUPPORT/'frozen'/group).glob('*.json')):
            source=json.loads(path.read_text())
            packet,stats=transport(source)
            name=group+'__'+path.name
            pathout=output/name;pathout.write_text(json.dumps(packet,separators=(',',':'))+'\n')
            record=check(packet,True)
            rows.append({'name':name,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                         'source_root_parameters':sorted(tr.negative_parameters(source[-1])),
                         'packet_sha256':hashlib.sha256(pathout.read_bytes()).hexdigest(),
                         'translation':stats,**record})
            packets.append((name,pathout,True))
    boundary_rows=[]; boundary_packets={}
    for name,packet,expected in boundaries():
        pathout=output/(name+'.json');pathout.write_text(json.dumps(packet,separators=(',',':'))+'\n')
        boundary_packets[name]=packet
        record=check(packet,expected)
        boundary_rows.append({'name':name,'expected':expected,
                              'packet_sha256':hashlib.sha256(pathout.read_bytes()).hexdigest(),**record})
        packets.append((name,pathout,expected))
    controls=[]; code=KERNEL.read_text()
    for name,old,new,fixture in [
      ('capture','inst(env[a - d >> 1], d=1)','inst(env[a - d >> 1], d=d)','false_capture'),
      ('escape','if inst(a) in g:','if a in g:','false_eigenparameter_escape'),
      ('compound_induction','h = [inst(b, 0), b][:2 - len(b) % 2]',
                             'h = [inst(b, 0), b]','illegal_compound_induction'),
    ]:
        if code.count(old) != 1:raise ValueError('Mutation site changed')
        changed=types.ModuleType('mutant_'+name)
        exec(compile(code.replace(old,new),'explicit_mutant_'+name,'exec'),changed.__dict__)
        run=tr.run_target(changed,deepcopy(boundary_packets[fixture]))
        if not run['accepted']:raise AssertionError((name,run))
        controls.append({'defect':name,'fixture':fixture,'mutant_accepts':True,'kernel_accepts':False})
    cli_count=0
    for name,path,expected in packets:
      for optimized in (False,True):
        run=subprocess.run([sys.executable,*(['-O'] if optimized else []),str(KERNEL),str(path)],
                            text=True,capture_output=True,timeout=30)
        want=(0,'ACCEPT') if expected else (1,'REJECT')
        if (run.returncode,run.stdout.strip()) != want or run.stderr:
            raise AssertionError((name,optimized,run.returncode,run.stdout,run.stderr))
        cli_count+=1
    summary={'status':'PASS','candidate_sha256':hashlib.sha256(KERNEL.read_bytes()).hexdigest(),
             'transported_packets':len(rows),'boundary_packets':len(boundary_rows),
             'boundary_accepts':sum(r['expected'] for r in boundary_rows),
             'boundary_rejects':sum(not r['expected'] for r in boundary_rows),
             'cli_runs':cli_count,'opening_checks':audit_opening(),'defect_controls':controls,
             'transported_cells':sum(r['translation']['cells'] for r in rows),
             'transported_eigenparameters':sum(r['translation']['eigenparameters'] for r in rows),
             'transported':rows,'boundaries':boundary_rows}
    (HERE.parent/'results/verification.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ('transported','boundaries')},indent=2))


if __name__ == '__main__':main()
