"""Scalar-iterator iPRA checker; update binds only the previous value."""
import json, sys
k = 0


def inst(a, t=None, d=0):
    if type(a) is int and d % 2:
        return a if k <= a < d else inst(t, d=1)
    return [inst(b, t, d + w) for b, w in zip(a + [], (0, 0, b'\2', b'\0', b'\1\1', 0, b'\4\4\4', b'\0\0\2')[len(a) * 2 + d % 2])]


def check(a, g):
    global k
    if inst(a) in g:
        return True
    match take():
        case [m, t] if check(m, g):
            if m[2:]:
                h = [m[:1]]
            else:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(r, [n, t, r], 1)
            return b == t
        case t:
            a = inst(a[0], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
    k -= 1
    return check(inst(a, [k]), g + [inst(c, k) for c in h])


try:
    take = json.load(open(sys.argv[1])).pop
    accepted = check(take(), [])
except:
    accepted = False
print('ACCEPT' if accepted else 'REJECT')
sys.exit(not accepted)
