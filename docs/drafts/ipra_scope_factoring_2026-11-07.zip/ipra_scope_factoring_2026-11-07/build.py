"""Compile the complete LaTeX report twice; no network is used."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
engine = shutil.which('pdflatex')
if engine is None:
    raise SystemExit('pdflatex is required to rebuild report.pdf')
for run in range(2):
    result = subprocess.run([engine, '-interaction=nonstopmode', '-halt-on-error',
                             'report.tex'], cwd=ROOT, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    (ROOT / 'results' / ('latex_' + str(run + 1) + '.log')).write_text(result.stdout)
    if result.returncode:
        print(result.stdout[-12000:])
        raise SystemExit(result.returncode)
print('Built report.pdf')
