FACTORING SCOPE TRANSITIONS FOR iPRA
==================================
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific date).

RESULT

The complete standalone checker has 349 normalized tokens, 369 AST nodes,
and 1,000 normalized bytes. The six current supplied archives contain 11
root programs with a coordinatewise minimum of 356 / 378 / 1,038.
The comparison is pinned to ProveIt commit
df8beb801d9f3e3eb3a8141722953fb58e63009e.

With the identical stdin driver in every program, the comparison is
343 / 363 / 992 against 350 / 372 / 1,030. The gain is therefore not an
input-interface trick. The expanded heuristic inventory contains 443 paths
and 198 distinct complete-checker-like sources, with the same minimum.
All frozen sources and the unchanged inherited metric are included.

WHAT CHANGED

The uniform-scopes representation gives every child of a constructor the
same depth increment. The new program replaces zip plus a repeated offset
word with one scalar offset. The previously established empty-array
completion lets the empty traversal return immediately: [] denotes zero
numerically and truth propositionally. The inference dispatcher and public
driver are unchanged from the supplied uniform-scopes scalar checker.

The arithmetic basis and five-pattern logical calculus are inherited.
This is a strictly smaller complete presentation, not a new arithmetic
foundation, an absolute minimum, or a large foundational breakthrough.
The report identifies precisely what is new and what is reused.

MATHEMATICAL GUARANTEES

report.pdf gives the complete native axioms, schemas, and rules; the
opening and whole-checker soundness arguments; structural termination;
preservation of all old accepted packets; full intuitionistic logical
reconstruction; and whole-domain bi-interpretations with iPRA whose
composite isomorphisms are the identity graph x=y. Both interpretation
directions work internally at arbitrary, including nonstandard, arguments.
The ordinary falsity bridge is explicit.

The inherited scalar predecessor, conserved-remainder pairing proof,
primitive-recursion compiler, and quantifier-free reflection are reproduced
with attribution. Three further propositions show why no single fixed
natural-number seed preserves the existing term compilation, and why
simply deleting the zero equation fails the canonical interpretation. These are restricted obstructions, not a
universal impossibility theorem. A Further research questions section
describes the remaining opportunities.

QUICK START

  python3 checker.py examples/zero.json
  python3 checker.py examples/reject_false.json

The first prints ACCEPT; the second prints REJECT. All public example
filenames and expected outcomes are recorded in examples/index.json.
A JSON packet is a stack whose final element is the goal;
FORMAT.txt specifies the representation. The public result is ACCEPT with
exit status zero or REJECT with exit status one. Python -O does not remove
an acceptance check. Python 3.10 or later is required.

REPRODUCTION

  python3 reproduce.py
  python3 reproduce.py --pdf

The first command reproduces measurements and the finite validation suite.
The second also compiles the report with pdflatex. No network is required.
The original measurements use CPython 3.12.14. AST normalization may vary
between Python versions; the version is recorded in the receipts.

FINAL-SOURCE EVIDENCE

  5,225 full packet/oracle comparisons (includes 147 unchanged positives)
  2,080 opening comparisons
  1,000 independently decoded substitution checks, with no skipped budgets
  15 named opening regressions
  6 of 6 deliberately faulty variants detected
  128 public command-line executions, normal and -O

The oracle uses explicit separate term/formula traversals and named rules;
it does not share the production offset table or dispatcher. Optional
larger sweeps are included, but their earlier experimental results are not
counted as final-source evidence. Finite tests do not prove the metatheorems.
The soundness and interpretation proofs are written mathematics, not a
Lean or Rocq mechanization.

CONTENTS

report.tex, report.pdf, sections/, foundation/ -- complete report and sources
checker.py -- the entire project-specific trusted acceptance program
FORMAT.txt -- precise public packet conventions
measure.py, comparison/ -- unchanged metric, pinned sources, manifest
validation/, examples/ -- independent oracle, checks, and proof packets
results/ -- measurements, final validation receipt, build and visual QA
build.py, reproduce.py -- offline reproduction entry points
ATTRIBUTION.txt, LICENSE_SOURCE.txt -- provenance and reuse terms
SHA256SUMS.txt -- deliverable checksums

Resource limits can reject large valid certificates. REJECT does not mean
that the decoded goal is unprovable. Canonical completeness is the ideal
finite-proof claim; redundant raw spellings need not have identical packets.
