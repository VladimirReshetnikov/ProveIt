"""Reproduce complete-source comparisons using the unchanged inherited metric."""
import ast
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
DRIVER = """try:
    take = json.load(SOURCE).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
"""


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    metric_path = ROOT / 'comparison/source_measure.py'
    if hashlib.sha256(metric_path.read_bytes()).hexdigest() != manifest['metric_sha256']:
        raise ValueError('The inherited metric has changed')
    spec = importlib.util.spec_from_file_location('inherited_metric', metric_path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    measured = {}
    for row in manifest['expanded_sources']:
        value = metric.metrics(ROOT / row['local_file'])
        if value['sha256'] != row['sha256']:
            raise ValueError('Changed source: ' + row['local_file'])
        measured[row['sha256']] = value
    roots = [{**row, **measured[row['sha256']]} for row in manifest['root_programs']]
    delivered_minimum = {key: min(row[key] for row in roots) for key in KEYS}
    expanded_minimum = {key: min(row[key] for row in measured.values()) for key in KEYS}
    candidate = metric.metrics(ROOT / 'checker.py')
    common = {}
    with tempfile.TemporaryDirectory() as directory:
        temporary = Path(directory) / 'checker.py'

        def controlled(path, source):
            tree = ast.parse(path.read_text())
            body = []
            for node in tree.body:
                if isinstance(node, ast.Try):
                    break
                body.append(node)
            prefix = ast.unparse(ast.Module(body=body, type_ignores=[])) + '\n'
            temporary.write_text(prefix + DRIVER.replace('SOURCE', source))
            return {key: metric.metrics(temporary)[key] for key in KEYS}

        for label, source in [('argv', 'open(sys.argv[1])'), ('stdin', 'sys.stdin')]:
            rows = [{**{k: row[k] for k in ('archive', 'path', 'sha256')},
                     **controlled(ROOT / row['local_file'], source)} for row in roots]
            minimum = {key: min(row[key] for row in rows) for key in KEYS}
            new = controlled(ROOT / 'checker.py', source)
            if not all(new[key] < minimum[key] for key in KEYS):
                raise ValueError('Candidate fails the controlled comparison: ' + label)
            common[label] = {'minimum': minimum, 'candidate': new, 'programs': rows}
    if delivered_minimum != expanded_minimum:
        raise ValueError('Expanded inventory changed the frontier')
    if not all(candidate[key] < delivered_minimum[key] for key in KEYS):
        raise ValueError('Candidate is not below the delivered-source envelope')
    result = {
        'status': 'PASS', 'python': platform.python_version(),
        'implementation': platform.python_implementation(), 'commit': manifest['commit'],
        'metric_sha256': manifest['metric_sha256'], 'root_programs': len(roots),
        'expanded_paths': sum(len(row['paths']) for row in manifest['expanded_sources']),
        'expanded_unique': len(measured), 'expanded_filter': manifest['expanded_filter'],
        'delivered_minimum': delivered_minimum, 'expanded_minimum': expanded_minimum,
        'candidate': candidate, 'common_driver': common, 'programs': roots,
        'scope': 'Finite-corpus implementation comparison, not an absolute minimality theorem.'
    }
    target = ROOT / 'results'
    target.mkdir(exist_ok=True)
    (target / 'measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    with (target / 'comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ['archive', 'path', *KEYS, 'sha256'], extrasaction='ignore')
        writer.writeheader()
        writer.writerows(roots)
    print(json.dumps({key: result[key] for key in
                     ('status', 'python', 'root_programs', 'expanded_paths', 'expanded_unique',
                      'delivered_minimum', 'candidate')}, indent=2))


if __name__ == '__main__':
    main()
