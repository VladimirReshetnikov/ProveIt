"""Reproduce the comparison and validation; optionally rebuild the PDF."""
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--pdf', action='store_true')
options = parser.parse_args()
for script in ('measure.py', 'validation/validate.py'):
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
if options.pdf:
    subprocess.run([sys.executable, str(ROOT / 'build.py')], cwd=ROOT, check=True)
