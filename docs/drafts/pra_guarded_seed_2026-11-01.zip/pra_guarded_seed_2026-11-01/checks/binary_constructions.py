#!/usr/bin/env python3
"""Finite diagnostics for the report's actual binary-recursion descriptions.

Run: python3 checks/binary_constructions.py

Python 3.10+, standard library only.  Variables, zero, successor, and R_h
applications are the ONLY term constructors.  Arithmetic helper notation
expands to these constructors; it is never an evaluator shortcut.  Update
bodies refer only to earlier descriptions and have free variables among
u,v.  The interpreter evaluates R_h(0,a)=a and R_h(Sn,a)=h(n,R_h(n,a))
literally, retaining computed prefixes to avoid repeating work.

This is a finite diagnostic, not a formal proof of any universal statement,
schema equivalence, or bi-interpretation.  The separate Python expectations
use ordinary arithmetic only as a bounded comparison oracle.

The interned-term representation and literal-recursion evaluator follow
the approach in ProveIt's pra_one_parameter_2026-11-01/artifacts/binary_terms.py
(draft ZIP Git blob 79084d946c8f55c5e9516eea1fa0f93a3216c3c4, inspected at
commit 0bf6525f9b09421e5ffacdd5fba7648d28b7fcff).  This implementation is
reduced and adapted for the K unit-residual decoder, the J(x,y)=T(x+y)+y
orientation, and a generic compiler retaining a tuple of fixed parameters.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
from functools import lru_cache
from itertools import product
import json
from math import isqrt
from pathlib import Path


@dataclass(frozen=True)
class Term:
    op: str
    children: tuple[int, ...] = ()
    name: str = ""
    reference: int = -1


TERMS: list[Term] = []
TERM_IDS: dict[Term, int] = {}


def intern(node: Term) -> int:
    if node in TERM_IDS:
        return TERM_IDS[node]
    identifier = len(TERMS)
    if any(not 0 <= child < identifier for child in node.children):
        raise ValueError("A term must refer to existing child terms")
    TERMS.append(node)
    TERM_IDS[node] = identifier
    return identifier


def var(name: str) -> int:
    return intern(Term("var", name=name))


ZERO = intern(Term("zero"))


def succ(x: int) -> int:
    return intern(Term("succ", (x,)))


ONE = succ(ZERO)


def rec(reference: int, counter: int, seed: int) -> int:
    if not 0 <= reference < len(DESCRIPTIONS):
        raise ValueError("An application must reference an admitted description")
    return intern(Term("rec", (counter, seed), reference=reference))


@lru_cache(maxsize=None)
def variables(identifier: int) -> frozenset[str]:
    node = TERMS[identifier]
    if node.op == "var":
        return frozenset((node.name,))
    return frozenset().union(*(variables(child) for child in node.children))


@lru_cache(maxsize=None)
def references(identifier: int) -> frozenset[int]:
    node = TERMS[identifier]
    own = frozenset((node.reference,)) if node.op == "rec" else frozenset()
    return own.union(*(references(child) for child in node.children))


@lru_cache(maxsize=None)
def tree_size(identifier: int) -> int:
    return 1 + sum(tree_size(child) for child in TERMS[identifier].children)


@lru_cache(maxsize=None)
def display(identifier: int) -> str:
    node = TERMS[identifier]
    if node.op == "var":
        return node.name
    if node.op == "zero":
        return "0"
    if node.op == "succ":
        return "S(" + display(node.children[0]) + ")"
    if node.op == "rec":
        n, a = node.children
        return f"R{node.reference}({display(n)},{display(a)})"
    raise ValueError(node.op)


def substitute(identifier: int, replacements: dict[str, int]) -> int:
    """Simultaneous substitution; stored update bodies are not traversed."""
    memo: dict[int, int] = {}

    def visit(current: int) -> int:
        if current in memo:
            return memo[current]
        node = TERMS[current]
        if node.op == "var":
            result = replacements.get(node.name, current)
        elif node.op == "zero":
            result = ZERO
        elif node.op == "succ":
            result = succ(visit(node.children[0]))
        elif node.op == "rec":
            result = rec(node.reference, *(visit(c) for c in node.children))
        else:
            raise ValueError(node.op)
        memo[current] = result
        return result

    return visit(identifier)


@dataclass(frozen=True)
class Description:
    name: str
    body: int


DESCRIPTIONS: list[Description] = []


def admit(name: str, body: int) -> int:
    identifier = len(DESCRIPTIONS)
    if not variables(body) <= {"u", "v"}:
        raise ValueError(f"Illegal free update variables in {name}")
    if any(reference >= identifier for reference in references(body)):
        raise ValueError(f"Non-earlier update reference in {name}")
    DESCRIPTIONS.append(Description(name, body))
    return identifier


U, W = var("u"), var("v")
PRED = admit("predecessor: h(u,v)=u", U)
RESET = admit("zero reset: h(u,v)=0", ZERO)
INCREMENT = admit("addition: h(u,v)=S(v)", succ(W))


def p(x: int) -> int:
    return rec(PRED, x, ZERO)


def Z(n: int, a: int) -> int:
    return rec(RESET, n, a)


def add(x: int, y: int) -> int:
    return rec(INCREMENT, y, x)


DECREMENT = admit("subtraction: h(u,v)=p(v)", p(W))


def d(x: int, y: int) -> int:
    return rec(DECREMENT, y, x)


def C(r: int, a: int, b: int) -> int:
    return add(Z(r, a), Z(Z(r, ONE), b))


def K(r: int, a: int, b: int) -> int:
    return C(r, b, C(p(r), a, b))


TRIANGLE = admit("triangular sum: h(u,v)=v+S(u)", add(W, succ(U)))


def T(n: int) -> int:
    return rec(TRIANGLE, n, ZERO)


INVERSE = admit(
    "inverse triangular: h(u,v)=K(d(T(S(v)),u),S(v),v)",
    K(d(T(succ(W)), U), succ(W), W),
)


def V(n: int) -> int:
    return rec(INVERSE, n, ZERO)


def J(x: int, y: int) -> int:
    return add(T(add(x, y)), y)


def pi2(z: int) -> int:
    return d(z, T(V(z)))


def pi1(z: int) -> int:
    return d(V(z), pi2(z))


def pack(entries: tuple[int, ...]) -> int:
    """The report's fixed-arity code: J(first, code(rest)), ending at zero."""
    if not entries:
        return ZERO
    return J(entries[0], pack(entries[1:]))


def project(code: int, arity: int, index: int) -> int:
    if not 0 <= index < arity:
        raise ValueError("Invalid tuple projection")
    if index == 0:
        return pi1(code)
    return project(pi2(code), arity - 1, index - 1)


def compile_recursion(
    name: str, parameter_names: tuple[str, ...], base: int, step: int
) -> int:
    """Compile f(0,p)=base(p), f(Sn,p)=step(n,f(n,p),p).

    The external step interface uses variables `index`, `value`, and the
    listed parameter names.  The returned term uses `n` and those names.
    The update state J(value, pack(parameters)) retains ALL parameters.
    Both tuple length and the description syntax are metatheoretically
    finite.  There is no evaluator or program-code quantifier in the theory.
    """
    if len(set(parameter_names)) != len(parameter_names):
        raise ValueError("Duplicate parameter name")
    if {"n", "index", "value", "u", "v"} & set(parameter_names):
        raise ValueError("Reserved parameter name")
    if not variables(base) <= set(parameter_names):
        raise ValueError("Illegal base variables")
    if not variables(step) <= set(parameter_names) | {"index", "value"}:
        raise ValueError("Illegal step variables")
    saved_parameters = pi2(W)
    substitutions = {"index": U, "value": pi1(W)}
    substitutions.update({
        parameter: project(saved_parameters, len(parameter_names), index)
        for index, parameter in enumerate(parameter_names)
    })
    body = J(substitute(step, substitutions), saved_parameters)
    reference = admit(name, body)
    seed = J(base, pack(tuple(var(name) for name in parameter_names)))
    return pi1(rec(reference, var("n"), seed))


class Evaluator:
    def __init__(self) -> None:
        self.prefixes: dict[tuple[int, int], list[int]] = {}
        self.update_counts: Counter[int] = Counter()

    def evaluate(self, identifier: int, environment: dict[str, int]) -> int:
        memo: dict[int, int] = {}

        def visit(current: int) -> int:
            if current in memo:
                return memo[current]
            node = TERMS[current]
            if node.op == "var":
                value = environment[node.name]
            elif node.op == "zero":
                value = 0
            elif node.op == "succ":
                value = visit(node.children[0]) + 1
            elif node.op == "rec":
                counter, seed = (visit(child) for child in node.children)
                value = self.recursion(node.reference, counter, seed)
            else:
                raise ValueError(node.op)
            if not isinstance(value, int) or value < 0:
                raise ValueError("The diagnostic interpreter uses natural numbers")
            memo[current] = value
            return value

        return visit(identifier)

    def recursion(self, reference: int, counter: int, seed: int) -> int:
        values = self.prefixes.setdefault((reference, seed), [seed])
        while len(values) <= counter:
            index = len(values) - 1
            values.append(self.evaluate(
                DESCRIPTIONS[reference].body, {"u": index, "v": values[-1]}
            ))
            self.update_counts[reference] += 1
        return values[counter]


def main() -> None:
    evaluator = Evaluator()
    counts: Counter[str] = Counter()

    def check(group: str, term: int, env: dict[str, int], expected: int) -> None:
        actual = evaluator.evaluate(term, env)
        if actual != expected:
            raise AssertionError({
                "group": group, "environment": env,
                "expected": expected, "actual": actual,
            })
        counts[group] += 1

    x, y, r, a, b, z = map(var, ("x", "y", "r", "a", "b", "z"))
    for value in range(16):
        check("predecessor", p(x), {"x": value}, max(value - 1, 0))
    for n, seed in product(range(8), repeat=2):
        check("zero_reset", Z(x, y), {"x": n, "y": seed}, seed if n == 0 else 0)
    for left, right in product(range(12), repeat=2):
        env = {"x": left, "y": right}
        check("addition", add(x, y), env, left + right)
        check("subtraction", d(x, y), env, max(left - right, 0))
    for test, left, right in product(range(6), range(4), range(4)):
        env = {"r": test, "a": left, "b": right}
        check("zero_case", C(r, a, b), env, left if test == 0 else right)
        check("unit_residual_case", K(r, a, b), env, left if test == 1 else right)
    for n in range(21):
        check("triangular", T(x), {"x": n}, n * (n + 1) // 2)
    for n in range(301):
        check("inverse_triangular", V(z), {"z": n}, (isqrt(8 * n + 1) - 1) // 2)
    for t in range(21):
        for offset in range(t + 1):
            check("guarded_interval", V(add(T(x), y)), {"x": t, "y": offset}, t)
    for left, right in product(range(12), repeat=2):
        env = {"x": left, "y": right}
        check("pair_value", J(x, y), env, (left + right) * (left + right + 1) // 2 + right)
        check("first_inverse", pi1(J(x, y)), env, left)
        check("second_inverse", pi2(J(x, y)), env, right)
    for n in range(301):
        check("pair_surjectivity_diagnostic", J(pi1(z), pi2(z)), {"z": n}, n)

    for arity in range(1, 5):
        names = tuple(f"tuple_{i}" for i in range(arity))
        code = pack(tuple(var(name) for name in names))
        for entries in product(range(2), repeat=arity):
            for index, value in enumerate(entries):
                check("tuple_projection", project(code, arity, index),
                      dict(zip(names, entries)), value)

    pa, pb, pc = map(var, ("pa", "pb", "pc"))
    index, value = var("index"), var("value")
    affine = compile_recursion(
        "compiled: f(0,a,b)=a; f(Sn,a,b)=f(n,a,b)+b",
        ("pa", "pb"), pa, add(value, pb),
    )
    accumulated = compile_recursion(
        "compiled: f(0,a,b)=a; f(Sn,a,b)=f(n,a,b)+a+b+n",
        ("pa", "pb"), pa, add(add(add(value, pa), pb), index),
    )
    three_parameters = compile_recursion(
        "compiled: f(0,a,b,c)=a; f(Sn,a,b,c)=f(n,a,b,c)+a+b+c+n",
        ("pa", "pb", "pc"), pa, add(add(add(add(value, pa), pb), pc), index),
    )
    for left, right, n in product(range(3), range(3), range(5)):
        env = {"pa": left, "pb": right, "n": n}
        check("compiled_two_parameter_affine", affine, env, left + n * right)
        check("compiled_two_parameter_indexed", accumulated, env,
              left + n * (left + right) + n * (n - 1) // 2)
    for left, middle, right, n in product(range(2), range(2), range(2), range(4)):
        env = {"pa": left, "pb": middle, "pc": right, "n": n}
        check("compiled_three_parameter_indexed", three_parameters, env,
              left + n * (left + middle + right) + n * (n - 1) // 2)

    # Recheck the dependency and variable conditions after compiler extensions.
    for identifier, description in enumerate(DESCRIPTIONS):
        assert variables(description.body) <= {"u", "v"}
        assert all(ref < identifier for ref in references(description.body))

    output = Path(__file__).resolve().parent
    result = {
        "status": "passed",
        "scope": "Finite numerical diagnostics in the standard natural numbers; not a proof.",
        "terms": "Only variables, zero, successor, and literal binary-recursion applications.",
        "comparison_oracle": "Separate ordinary Python arithmetic; never used to evaluate terms.",
        "finite_ranges": {
            "predecessor": "0..15", "zero_reset": "counter and seed 0..7",
            "addition_and_subtraction": "both arguments 0..11",
            "C_and_K": "test 0..5; branches 0..3",
            "triangular": "0..20", "inverse_and_surjectivity": "0..300",
            "intervals": "t 0..20 and offset 0..t", "pairs": "both arguments 0..11",
            "tuples": "arity 1..4; entries 0..1",
            "two_parameter_compilers": "parameters 0..2; counter 0..4",
            "three_parameter_compiler": "parameters 0..1; counter 0..3",
        },
        "checks_by_group": dict(counts), "total_checks": sum(counts.values()),
        "description_count": len(DESCRIPTIONS), "term_dag_node_count": len(TERMS),
        "all_update_bodies_have_only_u_v": True,
        "all_description_dependencies_are_earlier": True,
        "evaluated_recursion_updates": sum(evaluator.update_counts.values()),
        "new_decoder": "V(Sn)=K(d(T(S(V(n))),n),S(V(n)),V(n))",
        "pair_orientation": "J(x,y)=T(x+y)+y",
        "compiler_state_orientation": "J(current_value, code(fixed_parameters))",
        "tuple_convention": "code([])=0; code(first::rest)=J(first,code(rest))",
        "not_claimed": [
            "universal correctness from finite tests",
            "formal verification of the full manuscript",
            "internal use of Python, universal evaluation, or an equality oracle",
        ],
    }
    descriptions = {
        "term_nodes": [asdict(node) for node in TERMS],
        "descriptions": [
            {"id": identifier, "name": description.name, "body": description.body,
             "expanded_tree_nodes": tree_size(description.body),
             "free_variables": sorted(variables(description.body)),
             "earlier_references": sorted(references(description.body))}
            for identifier, description in enumerate(DESCRIPTIONS)
        ],
        "note": "The JSON is a finite DAG storage format for ordinary finite term trees.",
    }
    (output / "binary_results.json").write_text(json.dumps(result, indent=2) + "\n")
    (output / "binary_descriptions.json").write_text(json.dumps(descriptions, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
