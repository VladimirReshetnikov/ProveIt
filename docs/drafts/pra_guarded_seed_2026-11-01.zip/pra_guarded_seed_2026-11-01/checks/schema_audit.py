#!/usr/bin/env python3
"""Finite syntax checks for the guarded-seed presentation of PRA.

This program implements the literal admission test and constructs actual
nonlogical axioms.  It also audits the four witness families and the partial
display metric.  It is a syntax/implementation diagnostic, not a first-order
proof checker and not a proof of bi-interpretability or consistency.

Exact object terms use only variables, 0, S, and registered binary recursors.
Stored update bodies have local variables u,v and may use earlier recursors.
Ordinary formula substitution never traverses a stored update body.

Metric-only nodes called 'schema' and 'update_placeholder' are deliberately
rejected by the exact-language validator.  Their use is confined to the
explicitly partial template ledger.  In particular, its advertised 29 does
not include the admission algorithm or the substituted formula/update bodies.

Run:
    python3 checks/schema_audit.py
    python3 checks/schema_audit.py --json
    python3 checks/schema_audit.py --output checks/schema_results.json
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping


@dataclass(frozen=True)
class Node:
    op: str
    args: tuple[Node, ...] = ()
    label: str = ""


def var(name: str) -> Node:
    return Node("var", label=name)


ZERO = Node("zero")
FALSE = Node("false")
N, Z, A = var("n"), var("z"), var("a")
U, V = var("u"), var("v")


def succ(term: Node) -> Node:
    return Node("succ", (term,))


def rec(name: str, counter: Node, seed: Node) -> Node:
    return Node("rec", (counter, seed), name)


def eq(left: Node, right: Node) -> Node:
    return Node("eq", (left, right))


def conj(left: Node, right: Node) -> Node:
    return Node("and", (left, right))


def disj(left: Node, right: Node) -> Node:
    return Node("or", (left, right))


def impl(left: Node, right: Node) -> Node:
    return Node("imp", (left, right))


def forall(name: str, formula: Node) -> Node:
    return Node("all", (formula,), name)


BAD = eq(ZERO, succ(ZERO))
TRUE = eq(ZERO, ZERO)


def guard(formula: Node) -> Node:
    return impl(disj(formula, BAD), formula)


def size(node: Node) -> int:
    """One node per occurrence; quantifier binder labels are not children."""
    return 1 + sum(size(child) for child in node.args)


def free_variables(node: Node) -> set[str]:
    if node.op == "var":
        return {node.label}
    result: set[str] = set()
    for child in node.args:
        result.update(free_variables(child))
    if node.op == "all":
        result.discard(node.label)
    return result


def variable_names(node: Node) -> set[str]:
    result = {node.label} if node.op in {"var", "all"} else set()
    for child in node.args:
        result.update(variable_names(child))
    return result


def occurrences(node: Node, name: str) -> int:
    if node.op == "var":
        return int(node.label == name)
    if node.op == "all" and node.label == name:
        return 0
    return sum(occurrences(child, name) for child in node.args)


def substitute(node: Node, replacements: Mapping[str, Node]) -> Node:
    """Simultaneous substitution on terms or quantifier-free formulas.

    Inserted replacement trees are returned directly, not substituted again.
    Quantifiers are rejected: no capture issue is silently delegated to this
    routine.  Exact schema inputs and all update bodies are quantifier-free.
    Recursor labels are names; their locally bound update bodies are untouched.
    """
    if node.op == "all":
        raise ValueError("substitution input must be quantifier-free")
    if node.op == "var":
        return replacements.get(node.label, node)
    return Node(
        node.op,
        tuple(substitute(child, replacements) for child in node.args),
        node.label,
    )


@dataclass(frozen=True)
class Description:
    name: str
    update: Node


class Language:
    """A finite prefix of the effective well-founded description grammar."""

    def __init__(self) -> None:
        self.descriptions: dict[str, Description] = {}

    def check_term(self, term: Node) -> None:
        if term.op == "var" and not term.args and term.label:
            return
        if term.op == "zero" and not term.args and not term.label:
            return
        if term.op == "succ" and len(term.args) == 1 and not term.label:
            self.check_term(term.args[0])
            return
        if term.op == "rec" and len(term.args) == 2:
            if term.label not in self.descriptions:
                raise ValueError("recursor is not earlier/registered: " + term.label)
            for argument in term.args:
                self.check_term(argument)
            return
        raise ValueError("not a term of the exact binary language: " + term.op)

    def check_formula(self, formula: Node) -> None:
        if formula.op == "false" and not formula.args and not formula.label:
            return
        if formula.op == "eq" and len(formula.args) == 2 and not formula.label:
            for argument in formula.args:
                self.check_term(argument)
            return
        if (formula.op in {"and", "or", "imp"}
                and len(formula.args) == 2 and not formula.label):
            for argument in formula.args:
                self.check_formula(argument)
            return
        raise ValueError("not a quantifier-free formula: " + formula.op)

    def add(self, name: str, update: Node) -> Description:
        if not name or name in self.descriptions:
            raise ValueError("recursor name must be fresh")
        self.check_term(update)
        if not free_variables(update) <= {"u", "v"}:
            raise ValueError("an update may have only local variables u,v")
        description = Description(name, update)
        self.descriptions[name] = description
        return description

    def admission(self, name: str, phi: Node) -> tuple[bool, Node | None]:
        """Recognize Phi(0,R_h(0,a),a) literally as (B or BAD) -> B."""
        if name not in self.descriptions:
            raise ValueError("unknown target recursor")
        self.check_formula(phi)
        if not free_variables(phi) <= {"n", "z", "a"}:
            raise ValueError("Phi has a free variable outside n,z,a")
        base = substitute(phi, {"n": ZERO, "z": rec(name, ZERO, A), "a": A})
        if base.op != "imp":
            return False, None
        antecedent, consequent = base.args
        if antecedent.op != "or":
            return False, None
        left, right = antecedent.args
        admitted = right == BAD and left == consequent
        return admitted, left if admitted else None

    def step_equation(self, name: str) -> Node:
        description = self.descriptions[name]
        body = substitute(description.update, {"u": N, "v": rec(name, N, A)})
        return eq(rec(name, succ(N), A), body)

    def generate(self, name: str, phi: Node) -> Node:
        admitted, _ = self.admission(name, phi)
        if not admitted:
            raise ValueError("literal guarded-base admission test failed")
        current = substitute(phi, {"n": N, "z": A, "a": A})
        following = substitute(phi, {"n": succ(N), "z": A, "a": A})
        return joint_axiom(current, following, self.step_equation(name))


def joint_axiom(current: Node, following: Node, step_equation: Node) -> Node:
    return forall(
        "a",
        impl(
            forall("n", impl(current, following)),
            forall("n", conj(current, step_equation)),
        ),
    )


def induction_witness(formula: Node) -> Node:
    if not free_variables(formula) <= {"n", "a"}:
        raise ValueError("induction matrix has more than one frozen parameter")
    base = substitute(formula, {"n": ZERO})
    return impl(disj(base, BAD), formula)


def initialization_witness(name: str) -> Node:
    initial = rec(name, ZERO, A)
    reflexivity = eq(initial, initial)
    return impl(disj(reflexivity, BAD), eq(Z, initial))


def pretty(node: Node) -> str:
    if node.op == "var":
        return node.label
    if node.op == "zero":
        return "0"
    if node.op == "false":
        return "false"
    if node.op == "succ":
        return "S(" + pretty(node.args[0]) + ")"
    if node.op in {"rec", "schema", "update_placeholder"}:
        label = "R_" + node.label if node.op == "rec" else node.label
        return label + "(" + ",".join(map(pretty, node.args)) + ")"
    if node.op == "all":
        return "forall " + node.label + ". " + pretty(node.args[0])
    operator = {"eq": "=", "and": "&", "or": "|", "imp": "=>"}[node.op]
    return "(" + pretty(node.args[0]) + " " + operator + " " + pretty(node.args[1]) + ")"


def tree(node: Node) -> dict:
    result: dict = {"op": node.op}
    if node.label:
        result["label"] = node.label
    if node.args:
        result["children"] = [tree(child) for child in node.args]
    return result


def placeholder(name: str, *arguments: Node) -> Node:
    return Node("schema", tuple(arguments), name)


def opaque_step() -> Node:
    return eq(
        rec("h", succ(N), A),
        Node("update_placeholder", (N, rec("h", N, A)), "h"),
    )


def fused_axiom(formula: Node) -> Node:
    base = substitute(formula, {"n": ZERO})
    following = substitute(formula, {"n": succ(N)})
    return forall(
        "a",
        impl(
            conj(disj(base, BAD), forall("n", impl(formula, following))),
            forall("n", formula),
        ),
    )


def normalized_axiom(formula: Node) -> Node:
    following = substitute(formula, {"n": succ(N)})
    return forall("a", impl(forall("n", impl(formula, following)), forall("n", formula)))


def implicit_initialization_template(extra_parameters: int) -> Node:
    extras = tuple(var("c" + str(i)) for i in range(extra_parameters))
    base = placeholder("A", ZERO, rec("h", ZERO, A), *extras)
    current = placeholder("A", N, A, *extras)
    following = placeholder("A", succ(N), A, *extras)
    formula = impl(
        conj(disj(base, BAD), forall("n", impl(current, following))),
        forall("n", conj(current, opaque_step())),
    )
    for variable in reversed((A,) + extras):
        formula = forall(variable.label, formula)
    return formula


def template_ledger() -> dict:
    base = forall("a", eq(rec("h", ZERO, A), A))
    step = forall("n", forall("a", opaque_step()))
    separation = impl(BAD, FALSE)
    formula = placeholder("F", N, A)
    normalized = normalized_axiom(formula)
    fused = fused_axiom(formula)
    current = placeholder("Phi", N, A, A)
    following = placeholder("Phi", succ(N), A, A)
    proposed = joint_axiom(current, following, opaque_step())
    components = {
        "R0": size(base),
        "RS": size(step),
        "separation": size(separation),
        "fused_QFI_one_parameter": size(fused),
        "reflexive_NI_one_parameter": size(normalized),
        "proposed_progress": size(proposed.args[0].args[0]),
        "proposed_conclusion": size(proposed.args[0].args[1]),
        "proposed_outer_implication_and_parameter_quantifier": 2,
    }
    totals = {
        "existing_two_variable_fused": size(base) + size(step) + size(fused),
        "existing_reflexive_display_at_one_parameter": (
            size(base) + size(step) + size(separation) + size(normalized)
        ),
        "implicit_initialization_at_zero_extra_parameters": size(
            implicit_initialization_template(0)
        ),
        "implicit_initialization_at_one_extra_parameter": size(
            implicit_initialization_template(1)
        ),
        "proposed_guarded_seed": size(proposed),
    }
    assert components == {
        "R0": 6, "RS": 12, "separation": 6,
        "fused_QFI_one_parameter": 24,
        "reflexive_NI_one_parameter": 15,
        "proposed_progress": 11, "proposed_conclusion": 16,
        "proposed_outer_implication_and_parameter_quantifier": 2,
    }
    assert totals == {
        "existing_two_variable_fused": 42,
        "existing_reflexive_display_at_one_parameter": 39,
        "implicit_initialization_at_zero_extra_parameters": 37,
        "implicit_initialization_at_one_extra_parameter": 42,
        "proposed_guarded_seed": 29,
    }
    return {
        "scope": "Partial template AST ledger; bodies and admission algorithms excluded.",
        "components": components,
        "totals": totals,
        "proposed_tree": tree(proposed),
        "proposed_display": pretty(proposed),
        "caveats": [
            "The old implicit-initialization proof uses an extra probe parameter.",
            "The 37-node zero-extra-parameter fragment was not proved complete there.",
            "The old reflexive presentation allows arbitrary parameter tuples.",
            "29 is not a complete encoding length or a global minimality result.",
        ],
    }


def concrete_ledger(language: Language, name: str, formulas: list[Node]) -> list[dict]:
    records = []
    for formula in formulas:
        language.check_formula(formula)
        assert free_variables(formula) <= {"n", "a"}
        a_size, d = size(formula), occurrences(formula, "n")
        raw = induction_witness(formula)
        current = substitute(raw, {"z": A})
        following = substitute(raw, {"n": succ(N), "z": A})
        assert size(raw) == 2 * a_size + 6
        ordinary_normalization = impl(substitute(formula, {"n": ZERO}), formula)
        for scope, step in [("opaque_update", opaque_step()),
                            ("actual_update_u", language.step_equation(name))]:
            k = size(step)
            base_template = forall("a", eq(rec(name, ZERO, A), A))
            step_template = forall("n", forall("a", step))
            common = size(base_template) + size(step_template)
            proposed = size(joint_axiom(current, following, step))
            old_fused = common + size(fused_axiom(formula))
            old_normalized = (
                common + size(impl(BAD, FALSE))
                + size(normalized_axiom(ordinary_normalization))
            )
            assert proposed == 6 * a_size + d + 24 + k
            assert old_fused == 4 * a_size + d + 19 + k
            assert old_normalized == 6 * a_size + d + 22 + k
            assert proposed - old_fused == 2 * a_size + 5
            assert proposed - old_normalized == 2
            if scope == "actual_update_u":
                assert proposed == size(language.generate(name, raw))
            records.append({
                "matrix": pretty(formula), "matrix_size": a_size,
                "counter_occurrences": d, "update_scope": scope,
                "successor_equation_size": k,
                "proposed_induction_witness_axiom": proposed,
                "fused_basis_with_same_matrix": old_fused,
                "reflexive_basis_with_normalized_matrix": old_normalized,
                "proposed_minus_fused": proposed - old_fused,
                "proposed_minus_reflexive": proposed - old_normalized,
            })
    return records


def run_checks() -> dict:
    language = Language()
    language.add("counter", U)
    language.add("zero", ZERO)
    language.add("increment", succ(V))
    language.add("previous", rec("counter", V, ZERO))
    name = "counter"
    # The target symbol may occur in Phi; it may not occur in its own update.
    witnesses = {
        "separation": guard(FALSE),
        "successor_computation": guard(TRUE),
        "initialization": initialization_witness(name),
        "one_parameter_induction": induction_witness(eq(N, A)),
    }
    witness_records = {}
    for label, raw in witnesses.items():
        admitted, b = language.admission(name, raw)
        assert admitted and b is not None
        generated = language.generate(name, raw)
        assert variable_names(generated) <= {"n", "a"}
        assert not free_variables(generated)
        witness_records[label] = {
            "raw_phi": pretty(raw), "raw_free_variables": sorted(free_variables(raw)),
            "recognized_B": pretty(b), "admitted": admitted,
            "generated_axiom": pretty(generated),
            "generated_variable_names": sorted(variable_names(generated)),
            "generated_axiom_nodes_actual_update": size(generated),
            "raw_tree": tree(raw), "generated_tree": tree(generated),
        }

    negatives = {}

    def reject(label: str, action) -> None:
        try:
            answer = action()
        except ValueError as error:
            negatives[label] = {"rejected": True, "reason": str(error)}
            return
        assert answer is False, (label, "mutation was wrongly accepted")
        negatives[label] = {"rejected": True, "reason": "literal pattern mismatch"}

    def accepts(raw: Node) -> bool:
        return language.admission(name, raw)[0]

    reject("wrong_exception", lambda: accepts(impl(disj(TRUE, eq(ZERO, succ(succ(ZERO)))), TRUE)))
    reject("reversed_disjunction", lambda: accepts(impl(disj(BAD, TRUE), TRUE)))
    reject("nonidentical_branches", lambda: accepts(impl(disj(TRUE, BAD), eq(succ(ZERO), succ(ZERO)))))
    reject("wrong_outer_connective", lambda: accepts(conj(disj(TRUE, BAD), TRUE)))
    reject("missing_guard", lambda: accepts(impl(TRUE, TRUE)))
    reject("bare_true_formula", lambda: accepts(TRUE))
    reject("extra_free_parameter", lambda: accepts(guard(eq(var("b"), var("b")))))
    reject("quantified_matrix", lambda: accepts(forall("b", guard(TRUE))))
    wrong_initial = rec(name, succ(ZERO), A)
    reject(
        "wrong_initialization_counter",
        lambda: accepts(impl(disj(eq(wrong_initial, wrong_initial), BAD), eq(Z, wrong_initial))),
    )
    reject("unregistered_function", lambda: accepts(guard(eq(rec("unknown", N, A), A))))
    reject("self_referential_update", lambda: language.add("self", rec("self", U, V)))
    reject("frozen_update_parameter", lambda: language.add("frozen", var("a")))
    reject("fresh_name_reuse", lambda: language.add("counter", V))
    reject("schematic_node_in_exact_input", lambda: accepts(placeholder("Phi", N, Z, A)))
    reject("noncanonical_zero_label", lambda: accepts(guard(eq(Node("zero", label="x"), ZERO))))
    reject("recursor_wrong_arity", lambda: accepts(guard(eq(Node("rec", (N,), name), A))))

    replacement = rec(name, ZERO, A)
    # This would instead return R_counter(0,S(0)) under sequential substitution.
    assert substitute(Z, {"z": replacement, "a": succ(ZERO)}) == replacement
    before = language.descriptions["previous"].update
    substitute(rec("previous", N, Z), {"n": ZERO, "z": A, "u": succ(ZERO)})
    assert language.descriptions["previous"].update == before

    formulas = [
        FALSE, TRUE, eq(N, A), eq(succ(N), N),
        conj(eq(N, A), eq(rec("previous", N, ZERO), A)),
        impl(eq(rec("increment", N, A), A), disj(eq(N, ZERO), eq(succ(N), A))),
    ]
    for formula in formulas:
        assert language.admission(name, induction_witness(formula))[0]

    return {
        "status": "passed",
        "scope": (
            "Finite AST admission, generation, substitution, variable and metric checks. "
            "These diagnostics are not a proof of the infinite theory's logical theorems."
        ),
        "admission_pattern": "Phi(0,R_h(0,a),a) is literally (B or 0=S(0)) -> B",
        "registered_descriptions": [
            {"name": description.name, "update": pretty(description.update)}
            for description in language.descriptions.values()
        ],
        "witnesses": witness_records,
        "negative_cases": negatives,
        "negative_case_count": len(negatives),
        "simultaneous_substitution_checked": True,
        "stored_update_scope_checked": True,
        "template_ledger": template_ledger(),
        "concrete_formula_sizes": {
            "variables": "a = matrix AST size; d = free counter occurrences; K = RS matrix size",
            "proposed": "6*a + d + 24 + K",
            "fused_basis": "4*a + d + 19 + K",
            "reflexive_normalized_basis": "6*a + d + 22 + K",
            "opaque_update_K": 10,
            "important_limit": (
                "For these particular QFI extraction witnesses, the proposed concrete "
                "axiom is two nodes longer than the reflexive normalized subtotal and "
                "2*a+5 nodes longer than the fused subtotal.  Template compression "
                "does not imply concrete-instance or proof-length compression."
            ),
            "examples": concrete_ledger(language, name, formulas),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", help="print complete JSON results")
    parser.add_argument("--output", type=Path, help="also write complete JSON results here")
    arguments = parser.parse_args()
    result = run_checks()
    serialized = json.dumps(result, indent=2, ensure_ascii=True) + "\n"
    if arguments.output:
        arguments.output.parent.mkdir(parents=True, exist_ok=True)
        arguments.output.write_text(serialized, encoding="utf-8")
    if arguments.json:
        print(serialized, end="")
        return
    print("Guarded-seed schema audit: PASSED")
    print("Four extraction witnesses admitted; every generated axiom has only n,a.")
    print(str(result["negative_case_count"]) + " malformed candidates rejected.")
    print("Simultaneous substitution and stored update scopes checked.")
    print("Partial template counts:")
    for label, count in result["template_ledger"]["totals"].items():
        print("  " + label + ": " + str(count))
    print("Expanded QFI witness sizes (a=|F|, d=counter occurrences, opaque K=10):")
    print("  proposed 6a+d+34; fused 4a+d+29; reflexive normalized 6a+d+32")
    print("Admission algorithms and arbitrary bodies are excluded from template counts.")
    print("Syntax checks are not a first-order proof or a proof of bi-interpretability.")
    if arguments.output:
        print("JSON results: " + str(arguments.output))


if __name__ == "__main__":
    main()
