/-
  Adapted from ProveIt's pra_one_parameter_2026-11-01/formal/OneParameter.lean,
  inspected in draft ZIP Git blob 79084d946c8f55c5e9516eea1fa0f93a3216c3c4
  at repository commit 0bf6525f9b09421e5ffacdd5fba7648d28b7fcff.
  The conditional parameter-transfer lemma is adapted from the same-named
  theorem in pra_two_variable_2026-11-01/formal/OneParameter.lean,
  draft ZIP Git blob 44c0cce9940664c6d82fc4c1c4146be386c82e2b.

  The inherited one-parameter triangular-interval proof and finite tuple
  packing proof are retained.  This adaptation replaces the old global
  equality-bit operation by the report's exact unit-residual detector K,
  and uses pair(x,y)=T(x+y)+y, with the corresponding projection orientation.

  This arbitrary-carrier constructive kernel encodes its induction matrices
  with only a running variable and one fixed parameter.  It does NOT assume
  induction for arbitrary predicates on the carrier.

  Basis lists elementary arithmetic and K equations explicitly as hypotheses.
  In particular, sub_one_implies is d(x,y)=1 -> x=S(y); it is not an equality
  oracle.  The manuscript must derive these hypotheses from initialized
  binary recursion and one-parameter quantifier-free induction.  The guarded
  decoder steps below then follow from K's residual test, without any global
  equality-bit function.  This file checks the interval and endpoint proofs,
  pairing inverses, finite tuple packing, and the conditional logical transfer
  of a supplied decoded induction instance.  It does not formalize the
  full binary-description grammar, all arithmetic bootstrap lemmas, the
  guarded-schema admission test, or the full PRA bi-interpretation.

  Lean 4.19.0; no Mathlib; no Classical; no sorry.
-/

namespace GuardedSeedPairing

universe u

structure Operations (D : Type u) where
  zero : D
  succ : D → D
  pred : D → D
  add : D → D → D
  sub : D → D → D
  unitCase : D → D → D → D
  tri : D → D
  inv : D → D

/- A small concrete fragment of quantifier-free term/formula syntax.
   .run and .parameter are its ONLY free-variable constructors. -/
inductive Term where
  | zero
  | run
  | parameter
  | succ (a : Term)
  | pred (a : Term)
  | add (a b : Term)
  | sub (a b : Term)
  | tri (a : Term)
  | inv (a : Term)

inductive Formula where
  | falsity
  | equal (a b : Term)
  | conj (a b : Formula)
  | disj (a b : Formula)
  | impl (a b : Formula)

def Term.eval {D : Type u} (o : Operations D) : Term → D → D → D
  | .zero, _, _ => o.zero
  | .run, n, _ => n
  | .parameter, _, c => c
  | .succ a, n, c => o.succ (a.eval o n c)
  | .pred a, n, c => o.pred (a.eval o n c)
  | .add a b, n, c => o.add (a.eval o n c) (b.eval o n c)
  | .sub a b, n, c => o.sub (a.eval o n c) (b.eval o n c)
  | .tri a, n, c => o.tri (a.eval o n c)
  | .inv a, n, c => o.inv (a.eval o n c)

def Formula.eval {D : Type u} (o : Operations D) : Formula → D → D → Prop
  | .falsity, _, _ => False
  | .equal a b, n, c => a.eval o n c = b.eval o n c
  | .conj a b, n, c => a.eval o n c ∧ b.eval o n c
  | .disj a b, n, c => a.eval o n c ∨ b.eval o n c
  | .impl a b, n, c => a.eval o n c → b.eval o n c

structure Basis (D : Type u) where
  o : Operations D
  sep : o.zero ≠ o.succ o.zero
  succ_injective : ∀ x y, o.succ x = o.succ y → x = y
  pred_zero : o.pred o.zero = o.zero
  pred_succ : ∀ x, o.pred (o.succ x) = x
  add_zero : ∀ x, o.add x o.zero = x
  add_comm : ∀ x y, o.add x y = o.add y x
  add_succ : ∀ x y, o.add x (o.succ y) = o.succ (o.add x y)
  sub_succ : ∀ x y, o.sub x (o.succ y) = o.pred (o.sub x y)
  sub_diagonal : ∀ x, o.sub x x = o.zero
  sub_succ_diagonal : ∀ x, o.sub (o.succ x) x = o.succ o.zero
  sub_both : ∀ x y, o.sub (o.succ x) (o.succ y) = o.sub x y
  sub_add_cancel : ∀ x y, o.sub (o.add x y) x = y
  sub_one_implies : ∀ x y, o.sub x y = o.succ o.zero → x = o.succ y
  unitCase_one : ∀ x y, o.unitCase (o.succ o.zero) x y = x
  unitCase_other : ∀ r x y, r ≠ o.succ o.zero → o.unitCase r x y = y
  tri_zero : o.tri o.zero = o.zero
  tri_succ : ∀ n, o.tri (o.succ n) = o.add (o.tri n) (o.succ n)
  inv_zero : o.inv o.zero = o.zero
  inv_succ : ∀ n,
    o.inv (o.succ n) =
      o.unitCase (o.sub (o.tri (o.succ (o.inv n))) n)
        (o.succ (o.inv n)) (o.inv n)
  induction_one_parameter : ∀ (a : Formula) (c : D),
    a.eval o o.zero c →
    (∀ n, a.eval o n c → a.eval o (o.succ n) c) →
    ∀ n, a.eval o n c

variable {D : Type u} (b : Basis D)

theorem add_left_cancel (a x y : D)
    (h : b.o.add a x = b.o.add a y) : x = y := by
  have hs := congrArg (fun z => b.o.sub z a) h
  change b.o.sub (b.o.add a x) a = b.o.sub (b.o.add a y) a at hs
  rw [b.sub_add_cancel, b.sub_add_cancel] at hs
  exact hs

theorem triangular_step (t : D) :
    b.o.tri (b.o.succ t) = b.o.succ (b.o.add (b.o.tri t) t) := by
  rw [b.tri_succ, b.add_succ]

/- In this formula, run = r and parameter = t.
   All hypotheses are inside the quantifier-free induction matrix. -/
def segmentFormula : Formula :=
  .impl (.equal (.inv (.tri .parameter)) .parameter)
    (.impl (.equal (.sub .run .parameter) .zero)
      (.equal (.inv (.add (.tri .parameter) .run)) .parameter))

theorem segment (t r : D) :
    b.o.inv (b.o.tri t) = t →
    b.o.sub r t = b.o.zero →
    b.o.inv (b.o.add (b.o.tri t) r) = t := by
  apply b.induction_one_parameter segmentFormula t
  · change (b.o.inv (b.o.tri t) = t) →
      (b.o.sub b.o.zero t = b.o.zero) →
      b.o.inv (b.o.add (b.o.tri t) b.o.zero) = t
    intro ht _
    rw [b.add_zero]
    exact ht
  · intro n ih
    change (b.o.inv (b.o.tri t) = t) →
      (b.o.sub (b.o.succ n) t = b.o.zero) →
      b.o.inv (b.o.add (b.o.tri t) (b.o.succ n)) = t
    change (b.o.inv (b.o.tri t) = t) →
      (b.o.sub n t = b.o.zero) →
      b.o.inv (b.o.add (b.o.tri t) n) = t at ih
    intro ht hle
    have hle' : b.o.sub n t = b.o.zero := by
      calc
        b.o.sub n t = b.o.sub (b.o.succ n) (b.o.succ t) :=
          (b.sub_both n t).symm
        _ = b.o.pred (b.o.sub (b.o.succ n) t) := b.sub_succ _ _
        _ = b.o.zero := by rw [hle, b.pred_zero]
    have hnt : n ≠ t := by
      intro h
      rw [h, b.sub_succ_diagonal] at hle
      exact b.sep hle.symm
    have hv : b.o.inv (b.o.add (b.o.tri t) n) = t := ih ht hle'
    have hthreshold :
        b.o.tri (b.o.succ t) ≠ b.o.succ (b.o.add (b.o.tri t) n) := by
      intro h
      have hsum : b.o.add (b.o.tri t) t = b.o.add (b.o.tri t) n := by
        apply b.succ_injective
        exact (triangular_step b t).symm.trans h
      have htn : t = n := add_left_cancel b (b.o.tri t) t n hsum
      exact hnt htn.symm
    have hresidual :
        b.o.sub (b.o.tri (b.o.succ t)) (b.o.add (b.o.tri t) n) ≠
          b.o.succ b.o.zero := by
      intro h
      exact hthreshold (b.sub_one_implies _ _ h)
    rw [b.add_succ, b.inv_succ, hv, b.unitCase_other _ _ _ hresidual]

/- This matrix uses no parameter.  The permitted extra parameter is
   simply assigned zero and ignored. -/
def endpointFormula : Formula :=
  .equal (.inv (.tri .run)) .run

theorem inverse_triangular (t : D) : b.o.inv (b.o.tri t) = t := by
  apply b.induction_one_parameter endpointFormula b.o.zero
  · change b.o.inv (b.o.tri b.o.zero) = b.o.zero
    rw [b.tri_zero, b.inv_zero]
  · intro n ih
    change b.o.inv (b.o.tri n) = n at ih
    change b.o.inv (b.o.tri (b.o.succ n)) = b.o.succ n
    have hv : b.o.inv (b.o.add (b.o.tri n) n) = n :=
      segment b n n ih (b.sub_diagonal n)
    have hresidual :
        b.o.sub (b.o.tri (b.o.succ n)) (b.o.add (b.o.tri n) n) =
          b.o.succ b.o.zero := by
      rw [triangular_step b n, b.sub_succ_diagonal]
    rw [triangular_step b n, b.inv_succ, hv, hresidual, b.unitCase_one]

/- Here run = y and parameter = x. -/
def belowSumFormula : Formula :=
  .equal (.sub .parameter (.add .parameter .run)) .zero

theorem sub_below_sum (x y : D) :
    b.o.sub x (b.o.add x y) = b.o.zero := by
  apply b.induction_one_parameter belowSumFormula x
  · change b.o.sub x (b.o.add x b.o.zero) = b.o.zero
    rw [b.add_zero, b.sub_diagonal]
  · intro n ih
    change b.o.sub x (b.o.add x n) = b.o.zero at ih
    change b.o.sub x (b.o.add x (b.o.succ n)) = b.o.zero
    rw [b.add_succ, b.sub_succ, ih, b.pred_zero]

def pair (x y : D) : D := b.o.add (b.o.tri (b.o.add x y)) y
def second (z : D) : D := b.o.sub z (b.o.tri (b.o.inv z))
def first (z : D) : D := b.o.sub (b.o.inv z) (second b z)

theorem inverse_pair (x y : D) : b.o.inv (pair b x y) = b.o.add x y := by
  have hy : b.o.sub y (b.o.add x y) = b.o.zero := by
    rw [b.add_comm x y]
    exact sub_below_sum b y x
  exact segment b (b.o.add x y) y (inverse_triangular b (b.o.add x y)) hy

theorem second_pair (x y : D) : second b (pair b x y) = y := by
  unfold second
  rw [inverse_pair]
  exact b.sub_add_cancel (b.o.tri (b.o.add x y)) y

theorem first_pair (x y : D) : first b (pair b x y) = x := by
  unfold first
  rw [inverse_pair, second_pair, b.add_comm x y]
  exact b.sub_add_cancel y x

theorem pair_injective (x y x' y' : D)
    (h : pair b x y = pair b x' y') : x = x' ∧ y = y' := by
  constructor
  · have h' := congrArg (first b) h
    rw [first_pair, first_pair] at h'
    exact h'
  · have h' := congrArg (second b) h
    rw [second_pair, second_pair] at h'
    exact h'

/- The following recursion is on a finite METATHEORETIC list, not on
   elements of D.  For each fixed list length it expands to a term. -/
def pack : List D → D
  | [] => b.o.zero
  | x :: xs => pair b x (pack xs)

def unpack : Nat → D → List D
  | 0, _ => []
  | k + 1, z => first b z :: unpack k (second b z)

theorem unpack_pack (xs : List D) : unpack b xs.length (pack b xs) = xs := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    change first b (pair b x (pack b xs)) ::
      unpack b xs.length (second b (pair b x (pack b xs))) = x :: xs
    rw [first_pair, second_pair, ih]

/- This is a conditional logical transfer, not unrestricted predicate induction.
   The caller supplies precisely the decoded one-parameter induction instance.
   Its quantifier-free syntactic admissibility is established in the manuscript
   by substitution of fixed finite decoding terms. -/
theorem transfer_parameters
    (F : D → List D → Prop) (xs : List D)
    (coded : ∀ c,
      F b.o.zero (unpack b xs.length c) →
      (∀ n, F n (unpack b xs.length c) →
        F (b.o.succ n) (unpack b xs.length c)) →
      ∀ n, F n (unpack b xs.length c))
    (base : F b.o.zero xs)
    (step : ∀ n, F n xs → F (b.o.succ n) xs) :
    ∀ n, F n xs := by
  have h := coded (pack b xs)
  rw [unpack_pack b xs] at h
  exact h base step

#print axioms add_left_cancel
#print axioms segment
#print axioms inverse_triangular
#print axioms sub_below_sum
#print axioms first_pair
#print axioms second_pair
#print axioms pair_injective
#print axioms unpack_pack
#print axioms transfer_parameters

end GuardedSeedPairing
