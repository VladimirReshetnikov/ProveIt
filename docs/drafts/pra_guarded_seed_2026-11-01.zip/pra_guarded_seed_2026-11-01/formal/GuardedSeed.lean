/-
Guarded seed normalization: a constructive logical kernel.

The quantified variables below range over an arbitrary carrier. The file
checks the exact four probe instances used to recover the arithmetic basis,
and checks the converse for one admitted matrix. It does NOT quantify an
arithmetic theory over arbitrary semantic predicates. Quantifier-freeness,
the finite-description grammar, and the literal syntactic admission test
belong to the written construction and its separate syntax audit.

In particular, `AdmittedBase` is the semantic consequence of the literal
syntax check. It is used only as an explicit hypothesis in the converse.
No classical logic, choice, arithmetic induction, or opaque axioms are used.
-/

universe u

namespace GuardedSeed

variable {Carrier : Type u}

def SuccessorEquation (successor : Carrier → Carrier)
    (update recursor : Carrier → Carrier → Carrier) (counter seed : Carrier) : Prop :=
  recursor (successor counter) seed = update counter (recursor counter seed)

def SchemaInstance (successor : Carrier → Carrier)
    (update recursor : Carrier → Carrier → Carrier)
    (matrix : Carrier → Carrier → Carrier → Prop) : Prop :=
  ∀ seed,
    (∀ counter, matrix counter seed seed → matrix (successor counter) seed seed) →
    ∀ counter, matrix counter seed seed ∧
      SuccessorEquation successor update recursor counter seed

def AdmittedBase (zero : Carrier) (successor : Carrier → Carrier)
    (recursor : Carrier → Carrier → Carrier)
    (matrix : Carrier → Carrier → Carrier → Prop) (base : Carrier → Prop) : Prop :=
  ∀ seed, matrix zero (recursor zero seed) seed ↔
    ((base seed ∨ zero = successor zero) → base seed)

def TruthProbe (zero : Carrier) (successor : Carrier → Carrier)
    (_counter _slot _seed : Carrier) : Prop :=
  ((zero = zero) ∨ zero = successor zero) → zero = zero

def FalseProbe (zero : Carrier) (successor : Carrier → Carrier)
    (_counter _slot _seed : Carrier) : Prop :=
  (False ∨ zero = successor zero) → False

def SeedProbe (zero : Carrier) (successor : Carrier → Carrier)
    (recursor : Carrier → Carrier → Carrier) (_counter slot seed : Carrier) : Prop :=
  ((recursor zero seed = recursor zero seed) ∨ zero = successor zero) →
    slot = recursor zero seed

def InductionProbe (zero : Carrier) (successor : Carrier → Carrier)
    (formula : Carrier → Carrier → Prop) (counter _slot seed : Carrier) : Prop :=
  (formula zero seed ∨ zero = successor zero) → formula counter seed

theorem truth_probe_admitted (zero : Carrier) (successor : Carrier → Carrier)
    (recursor : Carrier → Carrier → Carrier) :
    AdmittedBase zero successor recursor (TruthProbe zero successor)
      (fun _ => zero = zero) := by
  intro seed
  exact Iff.rfl

theorem false_probe_admitted (zero : Carrier) (successor : Carrier → Carrier)
    (recursor : Carrier → Carrier → Carrier) :
    AdmittedBase zero successor recursor (FalseProbe zero successor)
      (fun _ => False) := by
  intro seed
  exact Iff.rfl

theorem seed_probe_admitted (zero : Carrier) (successor : Carrier → Carrier)
    (recursor : Carrier → Carrier → Carrier) :
    AdmittedBase zero successor recursor (SeedProbe zero successor recursor)
      (fun seed => recursor zero seed = recursor zero seed) := by
  intro seed
  exact Iff.rfl

theorem induction_probe_admitted (zero : Carrier) (successor : Carrier → Carrier)
    (recursor : Carrier → Carrier → Carrier) (formula : Carrier → Carrier → Prop) :
    AdmittedBase zero successor recursor (InductionProbe zero successor formula)
      (fun seed => formula zero seed) := by
  intro seed
  exact Iff.rfl

theorem successor_from_truth_probe (zero : Carrier) (successor : Carrier → Carrier)
    (update recursor : Carrier → Carrier → Carrier)
    (axiomInstance : SchemaInstance successor update recursor (TruthProbe zero successor)) :
    ∀ counter seed, SuccessorEquation successor update recursor counter seed := by
  intro counter seed
  exact (axiomInstance seed (by intro index hypothesis; exact hypothesis) counter).2

theorem separation_from_false_probe (zero : Carrier) (successor : Carrier → Carrier)
    (update recursor : Carrier → Carrier → Carrier)
    (axiomInstance : SchemaInstance successor update recursor (FalseProbe zero successor)) :
    zero ≠ successor zero := by
  have conclusion :=
    (axiomInstance zero (by intro index hypothesis; exact hypothesis) zero).1
  intro collapsed
  exact conclusion (Or.inr collapsed)

theorem initialization_from_seed_probe (zero : Carrier) (successor : Carrier → Carrier)
    (update recursor : Carrier → Carrier → Carrier)
    (axiomInstance : SchemaInstance successor update recursor
      (SeedProbe zero successor recursor)) :
    ∀ seed, recursor zero seed = seed := by
  intro seed
  have conclusion :=
    (axiomInstance seed (by intro index hypothesis; exact hypothesis) zero).1
  exact (conclusion (Or.inl rfl)).symm

theorem induction_from_induction_probe (zero : Carrier) (successor : Carrier → Carrier)
    (update recursor : Carrier → Carrier → Carrier) (formula : Carrier → Carrier → Prop)
    (axiomInstance : SchemaInstance successor update recursor
      (InductionProbe zero successor formula)) :
    ∀ seed, formula zero seed →
      (∀ counter, formula counter seed → formula (successor counter) seed) →
      ∀ counter, formula counter seed := by
  intro seed base progress
  have normalizedProgress : ∀ counter,
      InductionProbe zero successor formula counter seed seed →
        InductionProbe zero successor formula (successor counter) seed seed := by
    intro counter hypothesis guardedBase
    exact progress counter (hypothesis guardedBase)
  intro counter
  exact (axiomInstance seed normalizedProgress counter).1 (Or.inl base)

theorem schema_from_basis (zero : Carrier) (successor : Carrier → Carrier)
    (update recursor : Carrier → Carrier → Carrier)
    (initialization : ∀ seed, recursor zero seed = seed)
    (computation : ∀ counter seed,
      SuccessorEquation successor update recursor counter seed)
    (separation : zero ≠ successor zero)
    (matrix : Carrier → Carrier → Carrier → Prop) (base : Carrier → Prop)
    (admitted : AdmittedBase zero successor recursor matrix base)
    (diagonalInduction : ∀ seed, matrix zero seed seed →
      (∀ counter, matrix counter seed seed → matrix (successor counter) seed seed) →
      ∀ counter, matrix counter seed seed) :
    SchemaInstance successor update recursor matrix := by
  intro seed progress
  have guarded : (base seed ∨ zero = successor zero) → base seed := by
    intro alternatives
    cases alternatives with
    | inl value => exact value
    | inr collapsed => exact False.elim (separation collapsed)
  have substitutedBase : matrix zero (recursor zero seed) seed :=
    (admitted seed).mpr guarded
  have diagonalBase : matrix zero seed seed := by
    rw [initialization seed] at substitutedBase
    exact substitutedBase
  intro counter
  exact ⟨diagonalInduction seed diagonalBase progress counter,
    computation counter seed⟩

end GuardedSeed

/-
The local residual detector used by the shorter pairing proof.

The equations and coverage supplied as hypotheses are precisely the earlier
arithmetic lemmas of the paper. These lemmas do not assume decidable native
equality, do not use excluded middle, and perform no arithmetic induction.
-/

namespace GuardedResidual

variable {Carrier : Type u}

def SelectOne (selector : Carrier → Carrier → Carrier → Carrier)
    (predecessor : Carrier → Carrier) (residual yes no : Carrier) : Carrier :=
  selector residual no (selector (predecessor residual) yes no)

theorem select_one_at_one (zero : Carrier) (successor predecessor : Carrier → Carrier)
    (selector : Carrier → Carrier → Carrier → Carrier)
    (predecessorSuccessor : ∀ value, predecessor (successor value) = value)
    (selectorZero : ∀ yes no, selector zero yes no = yes)
    (selectorSuccessor : ∀ value yes no, selector (successor value) yes no = no)
    (yes no : Carrier) :
    SelectOne selector predecessor (successor zero) yes no = yes := by
  unfold SelectOne
  rw [selectorSuccessor, predecessorSuccessor, selectorZero]

theorem select_one_off_one (zero : Carrier) (successor predecessor : Carrier → Carrier)
    (selector : Carrier → Carrier → Carrier → Carrier)
    (coverage : ∀ value, value = zero ∨ value = successor (predecessor value))
    (selectorZero : ∀ yes no, selector zero yes no = yes)
    (selectorSuccessor : ∀ value yes no, selector (successor value) yes no = no)
    (residual yes no : Carrier) (away : residual ≠ successor zero) :
    SelectOne selector predecessor residual yes no = no := by
  unfold SelectOne
  cases coverage residual with
  | inl atZero => rw [atZero, selectorZero]
  | inr atSuccessor =>
    have outerReduction : selector residual no (selector (predecessor residual) yes no) =
        selector (predecessor residual) yes no := by
      calc
        selector residual no (selector (predecessor residual) yes no) =
            selector (successor (predecessor residual)) no
              (selector (predecessor residual) yes no) :=
          congrArg (fun value => selector value no (selector (predecessor residual) yes no))
            atSuccessor
        _ = selector (predecessor residual) yes no := selectorSuccessor _ _ _
    rw [outerReduction]
    cases coverage (predecessor residual) with
    | inl predecessorZero =>
      exact False.elim (away (atSuccessor.trans (congrArg successor predecessorZero)))
    | inr predecessorSuccessor =>
      calc
        selector (predecessor residual) yes no =
            selector (successor (predecessor (predecessor residual))) yes no :=
          congrArg (fun value => selector value yes no) predecessorSuccessor
        _ = no := selectorSuccessor _ _ _

theorem residual_is_one_iff_successor (zero : Carrier) (successor : Carrier → Carrier)
    (addition residual : Carrier → Carrier → Carrier)
    (selector : Carrier → Carrier → Carrier → Carrier)
    (selectorSuccessor : ∀ value yes no, selector (successor value) yes no = no)
    (additionOne : ∀ value, addition value (successor zero) = successor value)
    (diagonalResidual : ∀ value, residual (successor value) value = successor zero)
    (guard : ∀ value counter,
      selector (residual value counter) value (addition counter (residual value counter)) =
        value)
    (value counter : Carrier) :
    residual value counter = successor zero ↔ value = successor counter := by
  constructor
  · intro residualOne
    have guardedIdentity := guard value counter
    have reversed : successor counter = value := by
      simpa only [residualOne, selectorSuccessor, additionOne] using guardedIdentity
    exact reversed.symm
  · intro valueSuccessor
    rw [valueSuccessor]
    exact diagonalResidual counter

end GuardedResidual

#print axioms GuardedSeed.successor_from_truth_probe
#print axioms GuardedSeed.separation_from_false_probe
#print axioms GuardedSeed.initialization_from_seed_probe
#print axioms GuardedSeed.induction_from_induction_probe
#print axioms GuardedSeed.schema_from_basis
#print axioms GuardedResidual.select_one_at_one
#print axioms GuardedResidual.select_one_off_one
#print axioms GuardedResidual.residual_is_one_iff_successor
