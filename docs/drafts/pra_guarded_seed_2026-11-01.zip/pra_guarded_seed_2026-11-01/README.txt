PRIMITIVE RECURSIVE ARITHMETIC FROM ONE PROPAGATION SCHEMA
Research report prepared for Vladimir Reshetnikov
1 November 2026

Read report.pdf; report.tex is its complete LaTeX source.

RESULT
The same nonlogical specification works separately in classical and
intuitionistic first-order equality logic. It has one effective axiom family,
binary recursion symbols, and at most two individual variable names in each
emitted axiom. Both theories have common conservative definitional extensions
with the corresponding first-order PRA. Both interpretation domains are the
whole carrier and both round-trip isomorphisms are native equality.

THE SPECIFICATION
Generate 0, unary S, and a binary symbol R_h for each earlier finite update
term h(u,v). A raw quantifier-free matrix Phi(n,z,a) is admitted exactly when
the literal simultaneous substitution Phi(0,R_h(0,a),a) has the syntax

    (B or 0=S0) -> B

with two identical B syntax trees. Emit the sole axiom family

    forall a,
      (forall n, Phi(n,a,a) -> Phi(Sn,a,a)) ->
      forall n, Phi(n,a,a) and R_h(Sn,a)=h(n,R_h(n,a)).

There are no separately postulated initialization equations, separation
sentence, or induction-base premises. Those facts are derived by exact probes.
The raw admission interface has three slots; the emitted axiom has two
individual variables. Phi may use the entire generated language, including
R_h; only the stored update h must use earlier descriptions.

WHAT IS SMALLER
The inherited partial display metric gives 29 nodes, compared with 39 for the
current reflexive-induction presentation at one parameter and 42 for the
current two-variable presentation. This excludes the admission machinery and
arbitrary substituted bodies. Concrete normalized induction instances can be
LONGER. This is not a theorem of absolute shortestness, a finite first-order
axiomatization, or a claim of uniformly shorter proofs. The report gives all
qualifications and a reproducible ledger.

COMPARISON INPUTS
All five archives in ProveIt/docs/drafts at commit
0bf6525f9b09421e5ffacdd5fba7648d28b7fcff were inspected. Their Git blob identities
and SHA-256 hashes are recorded in audit/source_manifest.json and their
mathematical comparison is recorded in audit/comparison.json. The archive with
'(1)' in its name is a distinct input. Earlier inventories within those drafts
refer to older snapshots.

CONTENTS
  report.tex, report.pdf              Complete article and compiled report
  build.py                            Rebuild and diagnostic runner
  checks/schema_audit.py               Exact finite syntax and size audit
  checks/schema_results.json          Successful syntax-audit record
  checks/binary_constructions.py       Finite binary-description evaluator
  checks/binary_results.json           Bounded numerical diagnostic record
  checks/binary_descriptions.json      Explicit generated update descriptions
  formal/GuardedSeed.lean              New constructive logical kernel
  formal/Pairing.lean                  Adapted constructive pairing kernel
  formal/*.log, verification.json      Checked Lean results and source hashes
  formal/SCOPE.txt                     Formalization boundary and hypotheses
  audit/source_manifest.json          Immutable input provenance
  audit/comparison.json                Detailed comparison and limits
  audit/pdf_validation.json            Render/layout validation record
  SHA256SUMS                          Integrity hashes for packaged files

REPRODUCTION
Requirements: Python 3.10 or newer; pdflatex with the standard packages listed
in report.tex. Optional formal checker: Lean 4.19.0, standard prelude only;
Mathlib is not required.

From this directory:

    python3 build.py
    python3 build.py --lean /absolute/path/to/lean
    python3 build.py --skip-pdf

Individual checks:

    python3 checks/schema_audit.py
    python3 checks/binary_constructions.py
    lean formal/GuardedSeed.lean
    lean formal/Pairing.lean
    sha256sum -c SHA256SUMS

Running the build regenerates some diagnostic files and the PDF; the supplied
integrity hashes describe the distributed archive before regeneration.

VERIFICATION SCOPE
The manuscript gives the complete mathematical equivalence proof, arithmetic
bootstrap, primitive-recursion compiler, and both identity round trips.
The Lean files verify logical and pairing kernels over an arbitrary carrier,
with explicitly listed mathematical premises. Their printed theorems have no
global axiom dependencies. They do not formalize the complete first-order
syntax, all bootstrap inductions, or the entire bi-interpretability theorem.
The Python audits check syntax, accounting, and finite numerical behavior;
they are not a proof of the infinite theory or a test of nonstandard models.

ATTRIBUTION
Binary recursion, one-parameter pairing, reflexive normalization, and earlier
implicit initialization are inherited from the five inspected ProveIt drafts.
The present contribution combines separate raw seed slots with guarded
reflexive admission and a two-variable output, and simplifies the pairing
bootstrap using a unit-residual detector. Pairing.lean identifies its source
archive and the changes made. Novelty is relative to the five inspected
archives; no exhaustive historical priority claim is made.
