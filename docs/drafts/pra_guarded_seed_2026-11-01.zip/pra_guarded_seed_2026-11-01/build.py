#!/usr/bin/env python3
"""Rebuild the report and diagnostics; optionally recheck the Lean kernels."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def run(command: list[str], log_path: Path) -> str:
    result = subprocess.run(command, cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        print(result.stdout, file=sys.stderr)
        raise SystemExit(f"Command failed ({result.returncode}): {' '.join(command)}")
    return result.stdout


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Path to a Lean executable (tested with 4.19.0).")
    parser.add_argument("--skip-pdf", action="store_true", help="Run diagnostics only.")
    args = parser.parse_args()
    audit = ROOT / "audit"
    run([sys.executable, "checks/schema_audit.py", "--output",
         "checks/schema_results.json"], audit / "schema_console.txt")
    print("Finite syntax and size audit: passed.")
    run([sys.executable, "checks/binary_constructions.py"], audit / "binary_console.txt")
    print("Bounded binary-description diagnostics: passed.")

    if args.lean:
        lean = str(Path(args.lean).expanduser().resolve()) if "/" in args.lean else args.lean
        version = run([lean, "--version"], audit / "lean_version.txt").strip()
        records = []
        for filename in ("GuardedSeed.lean", "Pairing.lean"):
            source = ROOT / "formal" / filename
            log = source.with_suffix(".log")
            output = run([lean, str(source.relative_to(ROOT))], log)
            audits = [line for line in output.splitlines()
                      if "does not depend on any axioms" in line]
            if not audits or "depends on axioms" in output:
                raise SystemExit(f"Unexpected axiom audit in {filename}; inspect {log}.")
            records.append({"source": str(source.relative_to(ROOT)),
                            "source_sha256": sha256(source), "exit_code": 0,
                            "printed_axiom_free_theorems": len(audits),
                            "log": str(log.relative_to(ROOT))})
        record = {"tool": "Lean", "version": version, "kernels": records,
                  "scope": "Constructive logical and pairing kernels, with explicit "
                           "premises; not an end-to-end formalization of first-order "
                           "PRA bi-interpretability."}
        (ROOT / "formal" / "verification.json").write_text(
            json.dumps(record, indent=2) + "\n", encoding="utf-8")
        print("Lean kernels: passed; printed theorems have no global axiom dependencies.")

    if not args.skip_pdf:
        pdflatex = shutil.which("pdflatex")
        if not pdflatex:
            raise SystemExit("pdflatex is required; install a TeX distribution or use --skip-pdf.")
        for iteration in range(3):
            run([pdflatex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                audit / "latex_console.txt")
        log = (ROOT / "report.log").read_text(encoding="utf-8", errors="replace")
        forbidden = ("Overfull ", "undefined references", "Citation `", "Reference `")
        problems = [line for line in log.splitlines() if any(x in line for x in forbidden)]
        if problems:
            raise SystemExit("Review TeX warnings:\n" + "\n".join(problems))
        print("LaTeX article: compiled in three passes with no overfull boxes or unresolved references.")


if __name__ == "__main__":
    main()
