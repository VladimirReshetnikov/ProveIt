#!/usr/bin/env python3
"""Independently build and count the three computation-module ASTs.

Every function application costs one node, plus its active arguments,
plus the full frozen descriptor if it is a generated recursor. Substitution
never enters a frozen descriptor. No cost is estimated from an emitted
formula's claimed closed form: the AST is traversed independently.

This verifies serialization identities, not the arithmetic calibration.
The Lean file verifies the abstract logical equivalences.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Term:
    name: str
    args: tuple[Term, ...] = ()
    descriptor: Term | None = None

    def size(self) -> int:
        return (1 + sum(arg.size() for arg in self.args)
                + (0 if self.descriptor is None else self.descriptor.size()))

    def active_size(self) -> int:
        return 1 + sum(arg.active_size() for arg in self.args)

    def occurrences(self, var: str) -> int:
        # Stored descriptor occurrences are deliberately inactive.
        return int(self.name == var and not self.args) + sum(
            arg.occurrences(var) for arg in self.args)

    def substitute(self, substitutions: dict[str, Term]) -> Term:
        if not self.args and self.name in substitutions:
            return substitutions[self.name]
        return Term(self.name, tuple(arg.substitute(substitutions)
                                    for arg in self.args), self.descriptor)


@dataclass(frozen=True)
class Formula:
    name: str
    args: tuple[Formula | Term, ...]
    variable: str | None = None

    def size(self) -> int:
        # A quantifier costs one; its bound-variable label is not a node.
        return 1 + sum(arg.size() for arg in self.args)

    def active_size(self) -> int:
        return 1 + sum(arg.active_size() for arg in self.args)


def eq(left: Term, right: Term) -> Formula:
    return Formula("=", (left, right))


def imp(left: Formula, right: Formula) -> Formula:
    return Formula("implies", (left, right))


def conj(left: Formula, right: Formula) -> Formula:
    return Formula("and", (left, right))


def quant(kind: str, variables: str, matrix: Formula) -> Formula:
    for var in reversed(variables.split()):
        matrix = Formula(kind, (matrix,), var)
    return matrix


zero = Term("0")
a, n, u, x, y, v, w = (Term(name) for name in "a n u x y v w".split())


def S(t: Term) -> Term:
    return Term("S", (t,))


def R(body: Term, counter: Term, initial: Term) -> Term:
    return Term("R", (counter, initial), body)


def formulas(body: Term) -> tuple[Formula, Formula, Formula, Formula]:
    current = R(body, n, a)
    next_value = R(body, S(n), a)
    h_expanded = body.substitute({"v": current, "w": n})
    h_shared = body.substitute({"v": u, "w": n})
    base = quant("forall", "a", eq(R(body, zero, a), a))
    step = quant("forall", "a n", eq(next_value, h_expanded))
    graph = quant("forall", "a n u", imp(eq(current, u),
        conj(imp(eq(n, zero), eq(u, a)), eq(next_value, h_shared))))
    endpoints = quant("forall", "a n", quant("exists", "u",
        conj(imp(eq(n, zero), eq(u, a)),
             quant("forall", "x y", imp(eq(R(body, x, a), y),
                  conj(imp(eq(x, n), eq(y, u)),
                       imp(eq(x, S(n)), eq(y, h_shared))))))))
    return base, step, graph, endpoints


def inspect(body: Term) -> dict[str, int | str]:
    H = body.size()
    m = body.active_size()
    k = body.occurrences("v")
    base, step, graph, endpoints = formulas(body)
    old = base.size() + step.size()
    expected = [H + 6, 2 * H + 7 + k * (H + 2),
                3 * H + 22, 2 * H + 34]
    actual = [base.size(), step.size(), graph.size(), endpoints.size()]
    assert actual == expected, (body, H, k, actual, expected)
    actual_active = [base.active_size(), step.active_size(),
                     graph.active_size(), endpoints.active_size()]
    assert actual_active == [6, m + 7 + 2 * k, m + 22, m + 34]
    candidate_costs = [old, actual[2], actual[3]]
    saving = old - min(candidate_costs)
    assert saving == max(0, k * (H + 2) - 9,
                         H - 21 + k * (H + 2))
    assert actual[3] - actual[2] == 12 - H
    return {"H": H, "m": m, "active_v": k, "base": actual[0],
            "step": actual[1], "old_pair": old,
            "current_graph": actual[2], "endpoint_graph": actual[3],
            "selected": ["old_pair", "current_graph", "endpoint_graph"][
                candidate_costs.index(min(candidate_costs))],
            "minimum": min(candidate_costs), "saving": saving,
            "active_old_pair": actual_active[0] + actual_active[1],
            "active_current_graph": actual_active[2],
            "active_endpoint_graph": actual_active[3]}


def random_body(rng: random.Random, depth: int,
                earlier: tuple[Term, ...]) -> Term:
    if depth == 0 or rng.randrange(5) == 0:
        return rng.choice((zero, v, w))
    if rng.randrange(3) == 0:
        return S(random_body(rng, depth - 1, earlier))
    return R(rng.choice(earlier),
             random_body(rng, depth - 1, earlier),
             random_body(rng, depth - 1, earlier))


def main() -> None:
    rng = random.Random(20261102)
    earlier = [zero, v, w]
    cases = [zero, v, w, S(v), R(v, v, w), R(w, v, v)]
    # Four dependency stages ensure the traversal tests genuinely nested
    # frozen descriptors, including v and w which must remain untouched.
    for stage in range(4):
        new = [random_body(rng, 1 + stage, tuple(earlier)) for _ in range(400)]
        cases.extend(new)
        earlier.extend(new[:12])
    results = [inspect(body) for body in cases]
    unary_rows = []
    for H in (1, 2, 4, 8, 12, 13, 20, 50, 100):
        body = v
        for _ in range(H - 1):
            body = S(body)
        unary_rows.append(inspect(body))
    # A highly duplicated body: active v leaves are distinct from the
    # inactive v leaves in R_v's stored description.
    duplicate = v
    duplicate_rows = []
    for _ in range(7):
        duplicate_rows.append(inspect(duplicate))
        duplicate = R(v, duplicate, duplicate)
    out = {
        "scope": "AST identities and syntax-only selection; not a proof of PRA equivalence",
        "seed": 20261102,
        "random_legal_descriptors_checked": len(results),
        "maximum_full_descriptor_size": max(row["H"] for row in results),
        "maximum_active_v_occurrences": max(row["active_v"] for row in results),
        "all_ast_counts_match": True,
        "unary_chain_examples": unary_rows,
        "duplicated_state_examples": duplicate_rows,
        "full_costs": {
            "old_pair": "3H+13+k(H+2)",
            "current_graph": "3H+22",
            "endpoint_graph": "2H+34",
            "saving": "max(0,k(H+2)-9,H-21+k(H+2))"
        },
        "active_costs": {
            "old_pair": "m+13+2k",
            "current_graph": "m+22",
            "endpoint_graph": "m+34",
        },
    }
    path = Path(__file__).with_name("computation_size_results.json")
    path.write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
