/-
  Pure first-order computation kernels for the PRA report.
  No induction, decidable equality, nonzero successor, injectivity, or
  absence of successor fixed points is assumed.
-/

namespace ComputationGraphs

variable {A : Type} (zero : A) (succ : A → A)
variable (F : A → A → A) (h : A → A → A)

def Equations : Prop :=
  (∀ a, F zero a = a) ∧
  (∀ a n, F (succ n) a = h (F n a) n)

def CurrentGraph : Prop :=
  ∀ a n u, F n a = u →
    ((n = zero → u = a) ∧ F (succ n) a = h u n)

def EndpointGraph : Prop :=
  ∀ a n, ∃ u,
    (n = zero → u = a) ∧
    (∀ x y, F x a = y →
      ((x = n → y = u) ∧ (x = succ n → y = h u n)))

theorem equations_iff_currentGraph :
    Equations zero succ F h ↔ CurrentGraph zero succ F h := by
  constructor
  · rintro ⟨base, step⟩ a n u hu
    constructor
    · intro hn
      subst n
      exact hu.symm.trans (base a)
    · exact (step a n).trans (congrArg (fun v => h v n) hu)
  · intro graph
    constructor
    · intro a
      exact (graph a zero (F zero a) rfl).1 rfl
    · intro a n
      exact (graph a n (F n a) rfl).2

theorem equations_iff_endpointGraph :
    Equations zero succ F h ↔ EndpointGraph zero succ F h := by
  constructor
  · rintro ⟨base, step⟩ a n
    refine ⟨F n a, ?_, ?_⟩
    · intro hn
      subst n
      exact base a
    · intro x y hy
      constructor
      · intro hx
        subst x
        exact hy.symm
      · intro hx
        subst x
        exact hy.symm.trans (step a n)
  · intro graph
    constructor
    · intro a
      obtain ⟨u, base, endpoints⟩ := graph a zero
      have current : F zero a = u :=
        (endpoints zero (F zero a) rfl).1 rfl
      exact current.trans (base rfl)
    · intro a n
      obtain ⟨u, base, endpoints⟩ := graph a n
      have current : F n a = u :=
        (endpoints n (F n a) rfl).1 rfl
      have next : F (succ n) a = h u n :=
        (endpoints (succ n) (F (succ n) a) rfl).2 rfl
      exact next.trans (congrArg (fun v => h v n) current.symm)

theorem currentGraph_iff_endpointGraph :
    CurrentGraph zero succ F h ↔ EndpointGraph zero succ F h :=
  (equations_iff_currentGraph zero succ F h).symm.trans
    (equations_iff_endpointGraph zero succ F h)

#print axioms equations_iff_currentGraph
#print axioms equations_iff_endpointGraph
#print axioms currentGraph_iff_endpointGraph

end ComputationGraphs
