#!/usr/bin/env python3
"""Build actual boundary ASTs and check their charged sizes.

This independently constructs both signed boundaries, the primitive and
expanded positive conditional, and native value-sharing alternatives.
It imports only the small AST data classes and constructors authored for
this package; it does not execute any downloaded source-repository script.

The Boolean enumeration checks a finite truth-function statement. Neither
the enumeration nor these serialization checks proves the PRA calibration;
the paper supplies the unbounded mathematical proofs.
"""

from __future__ import annotations

import json
from pathlib import Path
import random

from check_computation_sizes import (
    Term, Formula, eq, imp, conj, quant, R, S,
)


def require(condition: bool, detail: object) -> None:
    # Do not make substantive checks depend on Python's optimization mode.
    if not condition:
        raise AssertionError(detail)


def disj(left: Formula, right: Formula) -> Formula:
    return Formula("or", (left, right))


bottom = Formula("false", ())
top = Formula("true", ())
zero = Term("0")
x, a, n, b, c, u, z, v, w = (
    Term(name) for name in "x a n b c u z v w".split()
)


def neg(formula: Formula) -> Formula:
    return imp(formula, bottom)


def conditional(test: Formula, yes: Formula, no: Formula) -> Formula:
    return Formula("C", (test, yes, no))


def expand_conditional(test: Formula, yes: Formula, no: Formula) -> Formula:
    return conj(disj(test, no), imp(test, yes))


def expand_strong_if(test: Formula, yes: Formula, no: Formula) -> Formula:
    return disj(conj(test, yes), conj(neg(test), no))


def equation_at(left: Term, right: Term, point: Term) -> Formula:
    return eq(left.substitute({"x": point}),
              right.substitute({"x": point}))


def native_matrix(at_b: Formula, at_next: Formula, sign: str) -> Formula:
    if sign == "+":
        return conj(disj(eq(b, zero), at_b), imp(at_next, eq(b, n)))
    if sign == "-":
        return conj(imp(at_b, eq(b, zero)), disj(eq(b, n), at_next))
    raise ValueError(sign)


def native(left: Term, right: Term, sign: str, shared: bool = False) -> Formula:
    matrix = native_matrix(equation_at(left, right, b),
                           equation_at(left, right, c if shared else S(b)),
                           sign)
    if shared:
        return quant("forall", "a n", quant("exists", "b c",
                     conj(eq(c, S(b)), matrix)))
    return quant("forall", "a n", quant("exists", "b", matrix))


def conditional_boundary(left: Term, right: Term, sign: str,
                         spelling: str = "primitive") -> Formula:
    yes = imp(eq(x, S(b)), eq(b, n))
    no = imp(eq(x, b), eq(b, zero))
    if sign == "-":
        yes, no = no, yes
    elif sign != "+":
        raise ValueError(sign)
    constructor = {"primitive": conditional,
                   "expanded": expand_conditional,
                   "strong_expanded": expand_strong_if}[spelling]
    matrix = constructor(eq(left, right), yes, no)
    return quant("forall", "a n", quant("exists", "b",
                 quant("forall", "x", matrix)))


def endpoint_constraints(test: Formula, sign: str) -> Formula:
    if sign == "+":
        at_b = disj(eq(b, zero), test)
        at_next = imp(test, eq(b, n))
    elif sign == "-":
        at_b = imp(test, eq(b, zero))
        at_next = disj(eq(b, n), test)
    else:
        raise ValueError(sign)
    return conj(imp(eq(x, b), at_b), imp(eq(x, S(b)), at_next))


def graph_boundary(left: Term, right: Term, sign: str,
                   bind: str = "both") -> Formula:
    if bind == "both":
        guard = conj(eq(u, left), eq(z, right))
        test = eq(u, z)
        variables = "x u z"
    elif bind == "left":
        guard = eq(u, left)
        test = eq(u, right)
        variables = "x u"
    elif bind == "right":
        guard = eq(z, right)
        test = eq(left, z)
        variables = "x z"
    else:
        raise ValueError(bind)
    return quant("forall", "a n", quant("exists", "b",
                 quant("forall", variables,
                       imp(guard, endpoint_constraints(test, sign)))))


def inspect(left: Term, right: Term) -> dict[str, int]:
    T, U = left.size(), right.size()
    G = T + U + 1
    i = left.occurrences("x") + right.occurrences("x")
    expected = [2 * G + i + 12, 2 * G + 18, G + 20,
                2 * G + 22, 2 * G + 24, G + 35,
                T + 2 * U + 30, 2 * T + U + 30]
    for sign in ("+", "-"):
        formulas = [native(left, right, sign),
                    native(left, right, sign, shared=True),
                    conditional_boundary(left, right, sign),
                    conditional_boundary(left, right, sign, "expanded"),
                    conditional_boundary(left, right, sign, "strong_expanded"),
                    graph_boundary(left, right, sign),
                    graph_boundary(left, right, sign, "left"),
                    graph_boundary(left, right, sign, "right")]
        actual = [formula.size() for formula in formulas]
        require(actual == expected, {"sign": sign, "T": T, "U": U,
                                     "i": i, "actual": actual,
                                     "expected": expected})
    ordinary = min(expected[0], expected[1], expected[5],
                   expected[6], expected[7])
    conditional_cost = min(expected[0], expected[2])
    require(ordinary == min(2 * G + i + 12, 2 * G + 18,
                            G + 29 + min(T, U, 6)), (T, U, G, i))
    if i > 0:
        require(conditional_cost <= ordinary, (G, i, ordinary))
        selected = 2 * G + i + 12 if G + i <= 8 else G + 20
        require(selected == conditional_cost, (G, i, selected))
    else:
        # With no active induction input, both signed induction implications
        # are logical consequences of their bases and no clause is emitted.
        selected = 0
    return {"T": T, "U": U, "G": G, "active_x": i,
            "native": expected[0], "native_shared": expected[1],
            "conditional": expected[2], "expanded_conditional": expected[3],
            "expanded_strong": expected[4], "native_graph": expected[5],
            "native_left_binding": expected[6],
            "native_right_binding": expected[7],
            "ordinary_minimum": ordinary,
            "conditional_minimum": conditional_cost,
            "emitted": selected}


def random_term(rng: random.Random, depth: int, leaves: tuple[Term, ...],
                earlier: tuple[Term, ...]) -> Term:
    if depth == 0 or rng.randrange(5) == 0:
        return rng.choice(leaves)
    if rng.randrange(3) == 0:
        return S(random_term(rng, depth - 1, leaves, earlier))
    return R(rng.choice(earlier),
             random_term(rng, depth - 1, leaves, earlier),
             random_term(rng, depth - 1, leaves, earlier))


def boolean_definition_checks() -> dict[str, object]:
    A, U, V = (Formula(name, ()) for name in ("A", "U", "V"))
    c_left = conditional(A, U, V)
    c_right = expand_conditional(A, U, V)
    strong_left = Formula("If", (A, U, V))
    strong_right = expand_strong_if(A, U, V)
    require([c_left.size(), c_right.size(), strong_right.size()] == [4, 7, 9],
            "logical-definition AST counts")
    rows = []
    for assignment in range(8):
        aa, uu, vv = ((assignment >> shift) & 1 for shift in (2, 1, 0))
        weak = (aa or vv) and ((not aa) or uu)
        strong = (aa and uu) or ((not aa) and vv)
        mux = uu if aa else vv
        require(int(weak) == int(strong) == mux, assignment)
        rows.append({"A": aa, "U": uu, "V": vv, "C": int(weak),
                     "strong_If": int(strong), "conditional": mux})

    # Truth-table signatures over the same eight assignments. Dynamic
    # programming stores only minimum-size representatives. Any minimum
    # formula has minimum-size immediate subformulas, so this loses none.
    mask = (1 << 8) - 1
    signatures = {
        "A": sum(((i >> 2) & 1) << i for i in range(8)),
        "U": sum(((i >> 1) & 1) << i for i in range(8)),
        "V": sum((i & 1) << i for i in range(8)),
        "false": 0, "true": mask,
    }
    levels: dict[int, dict[int, str]] = {1: {v: k for k, v in signatures.items()}}
    minima = {sig: (1, expression) for sig, expression in levels[1].items()}
    for size in (3, 5, 7):
        level: dict[int, str] = {}
        for left_size in range(1, size, 2):
            right_size = size - left_size - 1
            if right_size not in levels:
                continue
            for lsig, lexpr in levels[left_size].items():
                for rsig, rexpr in levels[right_size].items():
                    results = ((lsig & rsig, "and"),
                               (lsig | rsig, "or"),
                               (((~lsig) | rsig) & mask, "implies"))
                    for result, op in results:
                        if result not in minima and result not in level:
                            level[result] = f"({lexpr} {op} {rexpr})"
        levels[size] = level
        minima.update({sig: (size, expression) for sig, expression in level.items()})
    target = sum(row["conditional"] << idx for idx, row in enumerate(rows))
    require(target in minima and minima[target][0] == 7,
            {"target": target, "minimum": minima.get(target)})
    return {"truth_table": rows, "C_definition_nodes": c_right.size(),
            "strong_If_definition_nodes": strong_right.size(),
            "C_rewrite_record_nodes": c_left.size() + c_right.size() + 1,
            "strong_If_rewrite_record_nodes": strong_left.size() + strong_right.size() + 1,
            "boolean_conditional_minimum_nodes": minima[target][0],
            "minimum_representative": minima[target][1],
            "functions_first_represented_at_size": {
                str(size): len(level) for size, level in levels.items()},
            "enumeration_scope": (
                "Classical truth functions in binary and/or/implies with false/true; "
                "the stronger intuitionistic nine-node lower bound is proved in the paper, "
                "not established by a truth-table search.")}


def main() -> None:
    rng = random.Random(20261102)
    earlier = [zero, v, w]
    for stage in range(4):
        fresh = [random_term(rng, stage + 1, (zero, v, w), tuple(earlier))
                 for _ in range(18)]
        earlier.extend(fresh)
    pairs = [(x, a), (x, x), (zero, a), (S(x), a),
             (R(R(v, v, w), x, a), R(w, x, x))]
    for depth in range(1, 5):
        for _ in range(150):
            pairs.append((random_term(rng, depth, (zero, x, a), tuple(earlier)),
                          random_term(rng, depth, (zero, x, a), tuple(earlier))))
    rows = [inspect(left, right) for left, right in pairs]

    frozen = R(R(v, v, w), v, w)
    replaced = frozen.substitute({"v": S(n), "w": a})
    require(replaced.descriptor == frozen.descriptor,
            "substitution modified a frozen descriptor")
    require(replaced.args == (S(n), a), "active substitution failed")
    require(frozen.occurrences("v") == 1,
            "stored v occurrences counted as active")

    raw_rows = []
    for left, _ in pairs[:80]:
        row = inspect(left, zero)
        T, i = left.size(), left.occurrences("x")
        require(row["native"] == 2 * T + i + 16, (T, i))
        require(row["conditional"] == T + 22, (T, i))
        if i:
            require(row["emitted"] == min(2 * T + i + 16, T + 22), (T, i))
        raw_rows.append(row)

    usable = [row for row in rows if row["active_x"]]
    batches = []
    for length in (1, 2, 3, 5, 10, 20, 40):
        for repetition in range(8):
            selected = rng.choices(usable, k=length)
            signs = [rng.choice(("+", "-")) for _ in selected]
            ordinary = sum(row["ordinary_minimum"] for row in selected)
            new_conditional = 12 + sum(row["conditional_minimum"] for row in selected)
            old_conditional = 14
            for row, sign in zip(selected, signs):
                F = row["G"] + (2 if sign == "-" else 0)
                old_conditional += min(2 * F + row["active_x"] + 12, F + 20)
            new_cost = 6 + min(ordinary, new_conditional)
            old_cost = 6 + min(ordinary, old_conditional)
            require(new_cost <= old_cost, (new_cost, old_cost))
            if old_conditional <= ordinary:
                require(old_cost - new_cost >= 2, (new_cost, old_cost))
            batches.append({"instances": length, "new_total": new_cost,
                            "favorable_current_total": old_cost,
                            "saving": old_cost - new_cost})

    definitions = boolean_definition_checks()
    separation = imp(eq(zero, S(zero)), bottom)
    require(separation.size() == 6, separation.size())
    out = {
        "scope": "Charged AST identities, finite selector ledgers, and Boolean truth functions; not the PRA metatheorem",
        "seed": 20261102,
        "generated_term_pairs_checked": len(rows),
        "signed_boundary_ASTs_checked": 16 * len(rows),
        "maximum_full_equation_size": max(row["G"] for row in rows),
        "maximum_active_x_occurrences": max(row["active_x"] for row in rows),
        "nested_frozen_descriptor_substitution_check": "passed",
        "all_AST_counts_match": True,
        "definition_checks": definitions,
        "fixed_arithmetic_seed_nodes": separation.size(),
        "size_formulas": {
            "native_signed": "2G+i+12", "shared_successor": "2G+18",
            "primitive_conditional_signed": "G+20",
            "expanded_C_signed": "2G+22", "expanded_strong_If": "2G+24",
            "two_value_graph": "G+35", "left_binding": "T+2U+30",
            "right_binding": "2T+U+30",
            "raw_negative_selector": "min(2T+i+16,T+22)",
            "batch_ledger": "6+min(sum A_j,12+sum M_j)"},
        "examples": rows[:5],
        "raw_zero_test_examples": raw_rows[:5],
        "finite_batch_comparisons": batches,
    }
    path = Path(__file__).with_name("boundary_size_results.json")
    path.write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps({"generated_term_pairs_checked": len(rows),
                      "all_AST_counts_match": True,
                      "logical_definition_records": [12, 14],
                      "conditional_minimum_nodes": definitions["boolean_conditional_minimum_nodes"],
                      "batch_comparisons": len(batches),
                      "results_file": str(path)}, indent=2))


if __name__ == "__main__":
    main()
