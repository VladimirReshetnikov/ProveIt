#!/usr/bin/env python3
"""Finite arithmetic checks of the analytically proved covered-ledger bound.

Profiles T >= 3*i-2 are a superset of full-size profiles realizable in
the native 0,S,R_h grammar. Thus the script never accepts a smaller
description merely because a frozen recursor body was left uncharged.
The accompanying TeX proves the result for all finite lists; finite
enumeration here is a diagnostic check, not a proof by sampling.
"""

import itertools
import json
from pathlib import Path
import random


def costs(T, i):
    assert i >= 1 and T >= 3 * i - 2
    N = min(2 * T + i + 16, 2 * T + 22, T + 32)
    O = min(N, 2 * T + 18)
    M = min(2 * T + i + 16, T + 22)
    return N, O, M


def check_profile(profile):
    T, i = profile
    N, O, M = costs(T, i)
    assert M <= O <= N
    if N > O:
        assert i >= 3 and T >= 7
        assert O - M >= 3


def check_batch(batch):
    values = [costs(T, i) for T, i in batch]
    sN, sO, sM = (sum(row[k] for row in values) for k in range(3))
    old_native, old_covered = 6 + sN, 16 + sO
    new_conditional = 18 + sM
    old = min(old_native, old_covered)
    new = min(old_native, new_conditional)
    assert new <= old
    assert new < old_covered
    return {"profiles": list(batch), "old_native": old_native,
            "old_covered": old_covered,
            "new_conditional": new_conditional,
            "old_best": old, "new_best": new,
            "saving": old - new}


def profiles(max_T):
    return [(T, i) for T in range(1, max_T + 1)
            for i in range(1, (T + 2) // 3 + 1)]


def main():
    all_profiles = profiles(250)
    for p in all_profiles:
        check_profile(p)
        check_batch([p])
    small = profiles(30)
    for batch in itertools.product(small, repeat=2):
        check_batch(batch)
    tiny = profiles(12)
    for batch in itertools.product(tiny, repeat=3):
        check_batch(batch)
    rng = random.Random(20261102)
    for _ in range(2000):
        check_batch([rng.choice(all_profiles) for _ in range(rng.randrange(41))])
    result = {
        "scope": "finite checks of a general analytical inequality",
        "profile_constraint": "T>=3i-2, i>=1",
        "maximum_single_T": 250,
        "single_profiles_checked": len(all_profiles),
        "ordered_pairs_checked": len(small) ** 2,
        "ordered_triples_checked": len(tiny) ** 3,
        "random_long_batches_checked": 2000,
        "random_seed": 20261102,
        "all_checks_passed": True,
        "examples": [
            check_batch([]),
            check_batch([(1, 1)]),
            check_batch([(7, 3)]),
            check_batch([(7, 3)] * 11),
            check_batch([(1, 1), (7, 3), (100, 1)]),
            check_batch([(100, 1)]),
        ],
    }
    path = Path(__file__).with_name("covered_ledger_results.json")
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
