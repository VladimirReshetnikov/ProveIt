/-
Local logical kernels for the conjunctive conditional presentation of PRA.

This file uses Lean's core library only. It contains no arithmetic-induction
axiom, no classical axiom, no `sorry`, and no unproved opaque declaration.
The predicate P is arbitrary: specializing it to an equation gives the atomic
boundary kernel. The arithmetic reconstruction, parameter coding, and the
full bi-interpretability metatheorem are NOT formalized in this file.
-/

namespace ConjunctiveBoundary

def C (A U V : Prop) : Prop := (A ∨ V) ∧ (A → U)

def StrongIf (A U V : Prop) : Prop := (A ∧ U) ∨ ((A → False) ∧ V)

def NativeWitness {α : Type} (zero : α) (succ : α → α)
    (P : α → Prop) (b n : α) : Prop :=
  (b = zero ∨ P b) ∧ (P (succ b) → b = n)

def ConditionalWitness {α : Type} (zero : α) (succ : α → α)
    (P : α → Prop) (b n : α) : Prop :=
  ∀ x, C (P x) (x = succ b → b = n) (x = b → b = zero)

theorem conditional_to_native {α : Type} {zero : α} {succ : α → α}
    {P : α → Prop} {b n : α}
    (h : ConditionalWitness zero succ P b n) :
    NativeWitness zero succ P b n := by
  constructor
  · cases (h b).1 with
    | inl hp => exact Or.inr hp
    | inr hb => exact Or.inl (hb rfl)
  · intro hp
    exact (h (succ b)).2 hp rfl

/- Only equality with b is decided. P itself is never decided. -/
theorem native_to_conditional {α : Type} {zero : α} {succ : α → α}
    {P : α → Prop} {b n : α}
    (dec : ∀ x : α, Decidable (x = b))
    (h : NativeWitness zero succ P b n) :
    ConditionalWitness zero succ P b n := by
  intro x
  constructor
  · cases dec x with
    | isTrue hxb =>
      cases h.1 with
      | inl hb0 => exact Or.inr (fun _ => hb0)
      | inr hp => exact Or.inl (hxb.symm ▸ hp)
    | isFalse hxb =>
      exact Or.inr (fun hx => False.elim (hxb hx))
  · intro px hxS
    exact h.2 (hxS ▸ px)

theorem witness_iff {α : Type} {zero : α} {succ : α → α}
    {P : α → Prop} {b n : α}
    (dec : ∀ x : α, Decidable (x = b)) :
    ConditionalWitness zero succ P b n ↔
      NativeWitness zero succ P b n := by
  constructor
  · exact conditional_to_native
  · exact native_to_conditional dec

/- This proves the full implication under arbitrary retained hypotheses. -/
theorem boundary_induction {α : Type} {zero : α} {succ : α → α}
    {P : α → Prop}
    (boundary : ∀ n, ∃ b, ConditionalWitness zero succ P b n)
    (base : P zero) (step : ∀ x, P x → P (succ x)) :
    ∀ n, P n := by
  intro n
  cases boundary n with
  | intro b cert =>
    have nb : NativeWitness zero succ P b n := conditional_to_native cert
    have pb : P b := by
      cases nb.1 with
      | inl hb0 => exact hb0.symm ▸ base
      | inr hp => exact hp
    have hbn : b = n := nb.2 (step b pb)
    exact hbn ▸ pb

theorem parameter_boundary_induction {α : Type} {zero : α} {succ : α → α}
    (P : α → α → Prop)
    (boundary : ∀ a n, ∃ b, ConditionalWitness zero succ (fun x => P x a) b n) :
    ∀ a, (P zero a ∧ (∀ x, P x a → P (succ x) a)) → ∀ n, P n a := by
  intro a h
  exact boundary_induction (boundary a) h.1 h.2

def NegativeWitness {α : Type} (zero : α) (succ : α → α)
    (P : α → Prop) (b n : α) : Prop :=
  (P b → b = zero) ∧ (b = n ∨ P (succ b))

def NegativeConditionalWitness {α : Type} (zero : α) (succ : α → α)
    (P : α → Prop) (b n : α) : Prop :=
  ∀ x, C (P x) (x = b → b = zero) (x = succ b → b = n)

theorem negative_conditional_to_native {α : Type} {zero : α} {succ : α → α}
    {P : α → Prop} {b n : α}
    (h : NegativeConditionalWitness zero succ P b n) :
    NegativeWitness zero succ P b n := by
  constructor
  · intro pb
    exact (h b).2 pb rfl
  · cases (h (succ b)).1 with
    | inl psb => exact Or.inr psb
    | inr endpoint => exact Or.inl (endpoint rfl)

theorem negative_native_to_conditional {α : Type} {zero : α} {succ : α → α}
    {P : α → Prop} {b n : α}
    (dec : ∀ x : α, Decidable (x = succ b))
    (h : NegativeWitness zero succ P b n) :
    NegativeConditionalWitness zero succ P b n := by
  intro x
  constructor
  · cases dec x with
    | isTrue hxS =>
      cases h.2 with
      | inl hbn => exact Or.inr (fun _ => hbn)
      | inr psb => exact Or.inl (hxS.symm ▸ psb)
    | isFalse hxS => exact Or.inr (fun eqn => False.elim (hxS eqn))
  · intro px hxb
    exact h.1 (hxb ▸ px)

theorem negative_boundary_induction {α : Type} {zero : α} {succ : α → α}
    {P : α → Prop}
    (boundary : ∀ n, ∃ b, NegativeConditionalWitness zero succ P b n)
    (base : P zero → False)
    (step : ∀ x, (P x → False) → (P (succ x) → False)) :
    ∀ n, P n → False := by
  intro n
  cases boundary n with
  | intro b cert =>
    have nb : NegativeWitness zero succ P b n := negative_conditional_to_native cert
    have notpb : P b → False := by
      intro pb
      have hb0 : b = zero := nb.1 pb
      exact base (hb0 ▸ pb)
    have notpsb : P (succ b) → False := step b notpb
    cases nb.2 with
    | inl hbn => exact hbn ▸ notpb
    | inr psb => exact False.elim (notpsb psb)

theorem strong_implies_conjunctive {A U V : Prop}
    (h : StrongIf A U V) : C A U V := by
  cases h with
  | inl hau => exact ⟨Or.inl hau.1, fun _ => hau.2⟩
  | inr hnv => exact ⟨Or.inr hnv.2, fun ha => False.elim (hnv.1 ha)⟩

theorem conjunctive_true (A : Prop) : C A True True :=
  ⟨Or.inr True.intro, fun _ => True.intro⟩

theorem strong_true_iff_decision (A : Prop) :
    StrongIf A True True ↔ A ∨ (A → False) := by
  constructor
  · intro h
    cases h with
    | inl ha => exact Or.inl ha.1
    | inr hn => exact Or.inr hn.1
  · intro h
    cases h with
    | inl ha => exact Or.inl ⟨ha, True.intro⟩
    | inr hn => exact Or.inr ⟨hn, True.intro⟩

theorem conditional_eq_strong_when_decided {A U V : Prop}
    (decision : A ∨ (A → False)) : C A U V ↔ StrongIf A U V := by
  constructor
  · intro hc
    cases decision with
    | inl ha => exact Or.inl ⟨ha, hc.2 ha⟩
    | inr hn =>
      have hv : V := by
        cases hc.1 with
        | inl ha => exact False.elim (hn ha)
        | inr hv => exact hv
      exact Or.inr ⟨hn, hv⟩
  · exact strong_implies_conjunctive

def GraphComputation {α : Type} (zero : α) (succ : α → α)
    (R h : α → α → α) : Prop :=
  ∀ a n u, R n a = u → ((n = zero → u = a) ∧ R (succ n) a = h u n)

def ComputationClauses {α : Type} (zero : α) (succ : α → α)
    (R h : α → α → α) : Prop :=
  (∀ a, R zero a = a) ∧ (∀ a n, R (succ n) a = h (R n a) n)

theorem graph_computation_iff {α : Type} (zero : α) (succ : α → α)
    (R h : α → α → α) :
    GraphComputation zero succ R h ↔ ComputationClauses zero succ R h := by
  constructor
  · intro graph
    constructor
    · intro a
      exact (graph a zero (R zero a) rfl).1 rfl
    · intro a n
      exact (graph a n (R n a) rfl).2
  · intro standard a n u hu
    constructor
    · intro hn
      cases hn
      exact hu.symm.trans (standard.1 a)
    · exact (standard.2 a n).trans (congrArg (fun v => h v n) hu)

#print axioms conditional_to_native
#print axioms native_to_conditional
#print axioms boundary_induction
#print axioms parameter_boundary_induction
#print axioms negative_boundary_induction
#print axioms graph_computation_iff
#print axioms strong_implies_conjunctive
#print axioms conjunctive_true

end ConjunctiveBoundary
