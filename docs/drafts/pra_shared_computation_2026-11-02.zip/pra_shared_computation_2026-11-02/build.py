#!/usr/bin/env python3
"""Rebuild the mathematical checks and the PDF without network access."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
VERIFY = ROOT / 'verification'

def run(args, cwd, log):
    p = subprocess.run(args, cwd=cwd, text=True, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT)
    log.write_text(p.stdout)
    if p.returncode:
        print(p.stdout)
        raise SystemExit(p.returncode)
    return p.stdout

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--lean', help='Path to the Lean 4 executable')
    args = ap.parse_args()
    for script in ['check_computation_sizes.py', 'check_boundary_sizes.py',
                   'check_covered_ledger.py']:
        run([sys.executable, script], VERIFY,
            VERIFY / (Path(script).stem + '.log'))
    lean = args.lean or shutil.which('lean')
    lean_status = 'not rerun: pass --lean or put lean on PATH'
    if lean:
        output = run([lean, '--version'], ROOT, VERIFY / 'lean_version.txt')
        for source in ['BoundaryKernels.lean', 'ComputationGraphs.lean']:
            output += run([lean, source], VERIFY,
                          VERIFY / (Path(source).stem + '.log'))
        (VERIFY / 'lean_verification.txt').write_text(output)
        lean_status = 'both files compiled successfully'
    latex = shutil.which('pdflatex')
    if not latex:
        raise SystemExit('pdflatex is required to rebuild the PDF')
    logs = []
    for i in range(3):
        logs.append(run([latex, '-interaction=nonstopmode', '-halt-on-error',
                         'report.tex'], ROOT, VERIFY / f'latex_pass_{i+1}.log'))
    final = logs[-1]
    warnings = [line for line in final.splitlines()
                if any(x in line for x in ['Overfull', 'undefined',
                                           'multiply defined', 'Warning', 'warning'])]
    summary = {'pdf_created': (ROOT / 'report.pdf').is_file(),
               'lean': lean_status, 'latex_final_warnings': warnings}
    (VERIFY / 'build_summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
