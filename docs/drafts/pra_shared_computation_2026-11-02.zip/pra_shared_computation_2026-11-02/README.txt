PRA WITH SHARED COMPUTATION GRAPHS
2 November 2026

Read report.pdf for the complete mathematical report; report.tex and
sections/*.tex are its editable LaTeX source. AXIOMS.txt is the standalone
formal specification. The report includes Further research questions.

Source baseline: VladimirReshetnikov/ProveIt, commit
2ba9e7a5767fee450c6611868fdf0c4d3a27754e.
Five current and eight archived proposals were inspected. Exact source
paths, Git blob hashes, sizes, and download URLs are in provenance/.

RESULT
The new theory is bi-interpretable and equiconsistent with first-order
PRA, separately in classical and intuitionistic logic. Both interpretations
use the whole carrier, native equality, and identity composites. The main
new reduction shares complete recursor computation modules. A second
reduction uses the weaker generic logical conditional
  C(A,U,V) := (A OR V) AND (A -> U).
Every size comparison states its vocabulary, fixed definitions, and
complete-module accounting. No absolute global shortestness is claimed.

FORMAL VERIFICATION SCOPE
verification/BoundaryKernels.lean and ComputationGraphs.lean check the
new local logical implications and computation equivalences in Lean 4.19.0.
They contain no sorry or unproved declarations, and the logged theorems
depend on no axioms. The full arithmetic reconstruction and complete
bi-interpretability metatheorem are proved in the report, not fully
formalized by those local kernels.

REPRODUCING
Requires Python 3 and a LaTeX installation with pdflatex, amsmath, amsthm,
mathtools, lmodern, microtype, hyperref, enumitem, and booktabs/tabularx.
From this directory:
  python3 build.py
To additionally recheck the Lean kernels:
  python3 build.py --lean /absolute/path/to/lean
The included lean-toolchain records leanprover/lean4:v4.19.0.
No external Python packages are needed for the mathematical checkers.

The build reruns actual AST size checks and the covered-ledger checks,
then compiles the PDF. It does not download source archives or install
software. Visual PDF review is recorded separately in verification/.
MANIFEST.sha256 records the delivered files' hashes; rebuilding can change
PDF metadata or logs, so their new hashes may differ.
