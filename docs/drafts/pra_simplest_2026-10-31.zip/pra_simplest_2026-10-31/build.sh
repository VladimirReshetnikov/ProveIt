#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_simplest.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_simplest.tex
cp build/pra_simplest.pdf pra_simplest.pdf
