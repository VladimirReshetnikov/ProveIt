"""Replay symbolic PRA certificates and deliberately malformed negative controls.

Run from any directory with Python 3.10+:
    python3 path/to/artifacts/check_examples.py

Every displayed equation is obtained by the proof checker.  The examples are
universal symbolic proofs, not finite numerical tests.  They illustrate the
kernel; they are not a complete formalization of the paper's equivalence proof.
"""

from __future__ import annotations

from pra_kernel import (
    Checker,
    Equation,
    KernelError,
    Proof,
    Rec,
    Recursor,
    Succ,
    Var,
    ZERO,
    cong,
    eta,
    rec_succ,
    rec_zero,
    refl,
    subst,
    sym,
    trans,
    uniqueness,
)


def main() -> None:
    x, y, z, a = (Var(name) for name in ("x", "y", "z", "a"))
    n, r, p = (Var(name) for name in ("n", "r", "p"))
    definitions = (
        Recursor("id", "n", "r", (), r),
        Recursor("succ", "n", "r", (), Succ(r)),
        Recursor("succ_copy", "n", "r", (), Succ(r)),
        Recursor("keep", "n", "r", ("p",), p),
        # A legal later definition may use an earlier recursor.
        Recursor("double_step", "n", "r", (), Rec("succ", Succ(Succ(ZERO)), r)),
    )
    checker = Checker(definitions)
    accepted = 0

    def certify(label: str, certificate: Proof, expected: Equation) -> None:
        nonlocal accepted
        equation = checker.check(certificate)
        if equation != expected:
            raise AssertionError(f"Unexpected conclusion for {label}: {equation}")
        accepted += 1
        print(f"PASS {label}: {equation}")

    # Stationarity is a special case of eta with step h(n,r)=r.
    stationary = sym(eta("id", "x", ("z",), z, (), refl(z)))
    certify("stationary iteration", stationary, Equation(Rec("id", x, z), z))

    # eta applied to the identity function t(x)=x identifies the successor fold.
    counting = sym(eta("succ", "x", (), x, (), refl(Succ(x))))
    certify("successor iteration", counting, Equation(Rec("succ", x, ZERO), x))

    # Define addition by add(x,y)=R_succ(y,x), recursion in the second argument.
    certify("addition x + 0 = x", rec_zero("succ", x), Equation(Rec("succ", ZERO, x), x))
    certify("addition 0 + x = x", counting, Equation(Rec("succ", x, ZERO), x))
    certify(
        "substituted successor iteration",
        subst(counting, ("x", Succ(y))),
        Equation(Rec("succ", Succ(y), ZERO), Succ(y)),
    )

    # Three-premise uniqueness is a macro, derived from two eta applications.
    first = Rec("succ", x, z)
    second = Rec("succ_copy", x, z)
    same_iteration = uniqueness(
        "succ", "x", ("z",), first, second, (),
        trans(rec_zero("succ", z), sym(rec_zero("succ_copy", z))),
        rec_succ("succ", x, z),
        rec_succ("succ_copy", x, z),
    )
    certify("derived uniqueness macro", same_iteration, Equation(first, second))

    # A non-definitional addition identity, also proved through uniqueness.
    first = Rec("succ", x, Succ(z))
    second = Succ(Rec("succ", x, z))
    successor_initial = uniqueness(
        "succ", "x", ("z",), first, second, (),
        trans(rec_zero("succ", Succ(z)), sym(cong("S", rec_zero("succ", z)))),
        rec_succ("succ", x, Succ(z)),
        cong("S", rec_succ("succ", x, z)),
    )
    certify("addition S(z) + x = S(z + x)", successor_initial, Equation(first, second))

    # Parameterized steps are admitted; their fixed arguments cannot contain x.
    fixed = sym(eta("keep", "x", ("a",), a, (a,), refl(a)))
    certify("parameterized fixed iteration", fixed, Equation(Rec("keep", x, a, (a,)), a))

    rejected = 0

    def reject(label: str, action) -> None:
        nonlocal rejected
        try:
            action()
        except KernelError as error:
            rejected += 1
            print(f"REJECT {label}: {error}")
        else:
            raise AssertionError(f"Invalid input was accepted: {label}")

    reject(
        "malformed eta premise",
        lambda: checker.check(eta("id", "x", (), x, (), refl(Succ(x)))),
    )
    reject(
        "eta eigenvariable reused as parameter",
        lambda: checker.check(eta("id", "x", ("x",), x, (), refl(x))),
    )
    reject(
        "eta moving argument (capture hazard)",
        lambda: checker.check(eta("keep", "x", (), x, (x,), refl(x))),
    )
    reject(
        "eta undeclared target parameter",
        lambda: checker.check(eta("id", "x", (), z, (), refl(z))),
    )
    reject(
        "eta undeclared fixed parameter",
        lambda: checker.check(eta("keep", "x", (), ZERO, (z,), refl(ZERO))),
    )
    reject(
        "wrong recursor arity",
        lambda: checker.check(rec_zero("keep", ZERO)),
    )
    reject(
        "invalid transitivity",
        lambda: checker.check(trans(refl(x), refl(y))),
    )
    reject(
        "invalid congruence arity",
        lambda: checker.check(cong("S")),
    )
    reject(
        "duplicate substitution variable",
        lambda: checker.check(subst(refl(x), ("x", y), ("x", z))),
    )
    reject(
        "unknown proof rule",
        lambda: checker.check(Proof("assume_any_equation", data=(x, y))),
    )
    reject(
        "forward definition reference",
        lambda: Checker((Recursor("bad", "n", "r", (), Rec("later", n, r)),)),
    )
    reject(
        "self-recursive definition reference",
        lambda: Checker((Recursor("bad", "n", "r", (), Rec("bad", n, r)),)),
    )
    reject(
        "undeclared definition variable",
        lambda: Checker((Recursor("bad", "n", "r", (), z),)),
    )
    reject(
        "duplicate definition formal variable",
        lambda: Checker((Recursor("bad", "n", "n", (), n),)),
    )
    reject(
        "definition redefinition",
        lambda: Checker((definitions[0], definitions[0])),
    )

    print(f"\nChecked {accepted} symbolic proofs; rejected {rejected} malformed controls.")
    print("No numerical sampling was used.  Metatheorem equivalence is not formalized here.")


if __name__ == "__main__":
    main()
