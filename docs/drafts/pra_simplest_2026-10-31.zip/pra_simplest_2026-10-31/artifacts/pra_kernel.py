"""A small proof checker for the initialized-recursion presentation of PRA.

This module checks finite symbolic equation certificates.  It does not evaluate
sample natural numbers, perform proof search, or formalize the metatheorem that
this calculus is equivalent to the usual presentations of PRA.

Terms are first-order.  A recursor's step body lives in a separate, acyclic
definition registry; it is not a binder inside terms.  Ordinary substitution is
therefore simultaneous and capture-free.  The eta rule nevertheless checks its
eigenvariable and fixed-parameter conditions explicitly.

The arithmetic computation clauses for a registered step h(n, r, a) are:

    R_h(0, z, a) = z
    R_h(S(n), z, a) = h(n, R_h(n, z, a), a).

The sole arithmetic inference rule is initialized-recursion uniqueness (eta):

    t(S(x), b) = h(x, t(x, b), a(b))
    -------------------------------------------------
    t(x, b) = R_h(x, t(0, b), a(b)).

Here x is absent from b and from every fixed argument a(b).  There are no
undischarged assumptions: every certificate denotes an unconditional equation,
whose free variables are implicitly universal.  Equality rules are reflexivity,
symmetry, transitivity, congruence, and simultaneous substitution.

Python 3.10 or later; standard library only.
"""

from __future__ import annotations

from dataclasses import dataclass
import re
from types import MappingProxyType
from typing import Any, Iterable, Mapping


class KernelError(ValueError):
    """An ill-formed signature, term, or proof certificate."""


def _name(value: str) -> None:
    if not isinstance(value, str) or re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", value) is None:
        raise KernelError(f"Invalid identifier: {value!r}")


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    arg: Term


@dataclass(frozen=True)
class Rec:
    name: str
    index: Term
    initial: Term
    parameters: tuple[Term, ...] = ()


Term = Var | Zero | Succ | Rec
ZERO = Zero()


def free_variables(term: Term) -> frozenset[str]:
    if isinstance(term, Var):
        return frozenset((term.name,))
    if isinstance(term, Zero):
        return frozenset()
    if isinstance(term, Succ):
        return free_variables(term.arg)
    if isinstance(term, Rec):
        children = (term.index, term.initial) + term.parameters
        return frozenset().union(*(free_variables(child) for child in children))
    raise KernelError("Unknown term constructor")


def substitute(term: Term, substitution: Mapping[str, Term]) -> Term:
    """Simultaneous substitution; replacement terms are not substituted again."""
    if isinstance(term, Var):
        return substitution.get(term.name, term)
    if isinstance(term, Zero):
        return term
    if isinstance(term, Succ):
        return Succ(substitute(term.arg, substitution))
    if isinstance(term, Rec):
        return Rec(
            term.name,
            substitute(term.index, substitution),
            substitute(term.initial, substitution),
            tuple(substitute(arg, substitution) for arg in term.parameters),
        )
    raise KernelError("Unknown term constructor")


def format_term(term: Term) -> str:
    if isinstance(term, Var):
        return term.name
    if isinstance(term, Zero):
        return "0"
    if isinstance(term, Succ):
        return f"S({format_term(term.arg)})"
    if isinstance(term, Rec):
        args = (term.index, term.initial) + term.parameters
        return f"R_{term.name}({', '.join(map(format_term, args))})"
    raise KernelError("Unknown term constructor")


@dataclass(frozen=True)
class Recursor:
    name: str
    index_variable: str
    previous_variable: str
    parameter_variables: tuple[str, ...]
    step: Term

    @property
    def arity(self) -> int:
        return 2 + len(self.parameter_variables)


@dataclass(frozen=True)
class Equation:
    left: Term
    right: Term

    def __str__(self) -> str:
        return f"{format_term(self.left)} = {format_term(self.right)}"


@dataclass(frozen=True)
class Proof:
    """Untrusted certificate syntax: the checker recomputes its conclusion."""

    rule: str
    premises: tuple[Proof, ...] = ()
    data: tuple[Any, ...] = ()


class Checker:
    """Validate an ordered definition registry and then equation certificates."""

    def __init__(self, definitions: Iterable[Recursor]):
        registered: dict[str, Recursor] = {}
        self._definitions: Mapping[str, Recursor] = registered
        for definition in definitions:
            if not isinstance(definition, Recursor):
                raise KernelError("Registry entry is not a recursor definition")
            _name(definition.name)
            if definition.name == "S":
                raise KernelError("S is reserved for the successor function")
            if definition.name in self._definitions:
                raise KernelError(f"Duplicate recursor: {definition.name}")
            if not isinstance(definition.parameter_variables, tuple):
                raise KernelError("Recursor parameter variables must be a tuple")
            formals = (
                definition.index_variable,
                definition.previous_variable,
            ) + definition.parameter_variables
            for formal in formals:
                _name(formal)
            if len(set(formals)) != len(formals):
                raise KernelError("Recursor formal variables must be distinct")
            # Only previous definitions are visible: forward/self-reference fails.
            self.validate_term(definition.step)
            if not free_variables(definition.step) <= frozenset(formals):
                raise KernelError("Undeclared free variable in recursor step")
            registered[definition.name] = definition
        self._definitions = MappingProxyType(registered)

    def definition(self, name: str) -> Recursor:
        if name not in self._definitions:
            raise KernelError(f"Unknown recursor: {name}")
        return self._definitions[name]

    def validate_term(self, term: Term) -> None:
        if isinstance(term, Var):
            _name(term.name)
        elif isinstance(term, Zero):
            pass
        elif isinstance(term, Succ):
            self.validate_term(term.arg)
        elif isinstance(term, Rec):
            definition = self.definition(term.name)
            if not isinstance(term.parameters, tuple):
                raise KernelError("Recursor arguments must be a tuple")
            if len(term.parameters) != len(definition.parameter_variables):
                raise KernelError(f"Wrong arity for recursor {term.name}")
            for arg in (term.index, term.initial) + term.parameters:
                self.validate_term(arg)
        else:
            raise KernelError("Unknown term constructor")

    def _step(self, name: str, n: Term, r: Term, args: tuple[Term, ...]) -> Term:
        definition = self.definition(name)
        if len(args) != len(definition.parameter_variables):
            raise KernelError(f"Wrong arity for step {name}")
        substitution = dict(zip(definition.parameter_variables, args))
        substitution[definition.index_variable] = n
        substitution[definition.previous_variable] = r
        return substitute(definition.step, substitution)

    def check(self, proof: Proof) -> Equation:
        if not isinstance(proof, Proof):
            raise KernelError("Expected a proof certificate")
        if not isinstance(proof.premises, tuple) or not isinstance(proof.data, tuple):
            raise KernelError("Certificate premises and data must be tuples")
        premises = tuple(self.check(premise) for premise in proof.premises)
        data = proof.data

        def shape(premise_count: int, data_count: int) -> None:
            if len(premises) != premise_count or len(data) != data_count:
                raise KernelError(f"Wrong certificate shape for {proof.rule}")

        if proof.rule == "refl":
            shape(0, 1)
            self.validate_term(data[0])
            result = Equation(data[0], data[0])
        elif proof.rule == "sym":
            shape(1, 0)
            result = Equation(premises[0].right, premises[0].left)
        elif proof.rule == "trans":
            shape(2, 0)
            first, second = premises
            if first.right != second.left:
                raise KernelError("Transitivity endpoints do not match")
            result = Equation(first.left, second.right)
        elif proof.rule == "cong":
            if len(data) != 1 or not isinstance(data[0], str):
                raise KernelError("Congruence needs one function symbol")
            symbol = data[0]
            if symbol == "S":
                shape(1, 1)
                result = Equation(Succ(premises[0].left), Succ(premises[0].right))
            else:
                definition = self.definition(symbol)
                shape(definition.arity, 1)
                left_args = tuple(premise.left for premise in premises)
                right_args = tuple(premise.right for premise in premises)
                result = Equation(
                    Rec(symbol, left_args[0], left_args[1], left_args[2:]),
                    Rec(symbol, right_args[0], right_args[1], right_args[2:]),
                )
        elif proof.rule == "subst":
            shape(1, 1)
            if not isinstance(data[0], tuple):
                raise KernelError("Substitution must be a tuple of variable-term pairs")
            substitution: dict[str, Term] = {}
            for pair in data[0]:
                if not isinstance(pair, tuple) or len(pair) != 2:
                    raise KernelError("Invalid substitution entry")
                variable, term = pair
                _name(variable)
                if variable in substitution:
                    raise KernelError("Repeated substitution variable")
                self.validate_term(term)
                substitution[variable] = term
            result = Equation(
                substitute(premises[0].left, substitution),
                substitute(premises[0].right, substitution),
            )
        elif proof.rule == "rec_zero":
            shape(0, 3)
            name, initial, args = data
            recursor = Rec(name, ZERO, initial, args)
            self.validate_term(recursor)
            result = Equation(recursor, initial)
        elif proof.rule == "rec_succ":
            shape(0, 4)
            name, index, initial, args = data
            predecessor = Rec(name, index, initial, args)
            self.validate_term(predecessor)
            result = Equation(
                Rec(name, Succ(index), initial, args),
                self._step(name, index, predecessor, args),
            )
        elif proof.rule == "eta":
            shape(1, 5)
            name, variable, parameters, term, args = data
            _name(variable)
            if not isinstance(parameters, tuple) or not isinstance(args, tuple):
                raise KernelError("Eta parameters and arguments must be tuples")
            for parameter in parameters:
                _name(parameter)
            if len(set(parameters)) != len(parameters) or variable in parameters:
                raise KernelError("Eta eigenvariable and parameters must be distinct")
            allowed = frozenset(parameters)
            self.validate_term(term)
            if not free_variables(term) <= allowed | {variable}:
                raise KernelError("Undeclared parameter in eta target")
            for arg in args:
                self.validate_term(arg)
                if variable in free_variables(arg):
                    raise KernelError("Eta fixed argument contains the eigenvariable")
                if not free_variables(arg) <= allowed:
                    raise KernelError("Undeclared parameter in eta fixed argument")
            x = Var(variable)
            expected = Equation(
                substitute(term, {variable: Succ(x)}),
                self._step(name, x, term, args),
            )
            if premises[0] != expected:
                raise KernelError("Eta premise does not match its required equation")
            initial = substitute(term, {variable: ZERO})
            result = Equation(term, Rec(name, x, initial, args))
        else:
            raise KernelError(f"Unknown proof rule: {proof.rule}")

        self.validate_term(result.left)
        self.validate_term(result.right)
        return result


# These constructors produce untrusted syntax.  Only Checker.check certifies it.
def refl(term: Term) -> Proof:
    return Proof("refl", data=(term,))


def sym(proof: Proof) -> Proof:
    return Proof("sym", (proof,))


def trans(first: Proof, second: Proof) -> Proof:
    return Proof("trans", (first, second))


def cong(symbol: str, *premises: Proof) -> Proof:
    return Proof("cong", premises, (symbol,))


def subst(proof: Proof, *replacement_pairs: tuple[str, Term]) -> Proof:
    return Proof("subst", (proof,), (replacement_pairs,))


def rec_zero(name: str, initial: Term, *args: Term) -> Proof:
    return Proof("rec_zero", data=(name, initial, args))


def rec_succ(name: str, index: Term, initial: Term, *args: Term) -> Proof:
    return Proof("rec_succ", data=(name, index, initial, args))


def eta(
    name: str,
    variable: str,
    parameters: tuple[str, ...],
    term: Term,
    args: tuple[Term, ...],
    step_proof: Proof,
) -> Proof:
    return Proof("eta", (step_proof,), (name, variable, parameters, term, args))


def uniqueness(
    name: str,
    variable: str,
    parameters: tuple[str, ...],
    first: Term,
    second: Term,
    args: tuple[Term, ...],
    base_proof: Proof,
    first_step: Proof,
    second_step: Proof,
) -> Proof:
    """Expand three-premise recursion uniqueness into eta and equality rules.

    This is an untrusted macro, not an additional kernel rule.  Its base proof
    must equate first[0/x] and second[0/x]; the two step proofs must use the same
    registered step body.  The checker independently enforces these requirements
    when it replays the expanded certificate.
    """
    left_eta = eta(name, variable, parameters, first, args, first_step)
    right_eta = eta(name, variable, parameters, second, args, second_step)
    equal_initials = cong(
        name,
        refl(Var(variable)),
        base_proof,
        *(refl(arg) for arg in args),
    )
    return trans(left_eta, trans(equal_initials, sym(right_eta)))
