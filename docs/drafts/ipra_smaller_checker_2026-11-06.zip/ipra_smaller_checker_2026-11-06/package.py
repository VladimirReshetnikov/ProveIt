"""Package the complete deliverable and its checksums, excluding build caches."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent


def included(path):
    relative = path.relative_to(ROOT)
    if not path.is_file() or any(part.startswith(".") or part == "__pycache__"
                                 for part in relative.parts):
        return False
    if path.name == "SHA256SUMS.txt" or path.suffix in {".pyc", ".aux", ".out", ".toc"}:
        return False
    if path.suffix == ".log" and relative.as_posix() != "results/latex_build.log":
        return False
    return True


def main():
    files = sorted(p for p in ROOT.rglob("*") if included(p))
    checksum = ROOT / "SHA256SUMS.txt"
    checksum.write_text("".join(hashlib.sha256(p.read_bytes()).hexdigest()
                               + "  " + p.relative_to(ROOT).as_posix() + "\n"
                               for p in files))
    files.append(checksum)
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as bundle:
        for path in files:
            bundle.write(path, ROOT.name + "/" + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive) as bundle:
        if bundle.testzip() is not None:
            raise RuntimeError("Archive integrity failure")
        for line in checksum.read_text().splitlines():
            digest, name = line.split("  ", 1)
            if hashlib.sha256(bundle.read(ROOT.name + "/" + name)).hexdigest() != digest:
                raise RuntimeError("Packaged checksum failure: " + name)
    print(f"{archive.name}: {len(files)} files; {archive.stat().st_size:,} bytes")


if __name__ == "__main__":
    main()
