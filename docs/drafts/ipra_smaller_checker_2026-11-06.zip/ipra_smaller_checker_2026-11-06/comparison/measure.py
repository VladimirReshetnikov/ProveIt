"""Remeasure complete frozen iPRA checkers without executing them.

All executable syntax, validators, axiom construction and CLI code are counted.
Only comments, whitespace and docstrings are omitted from syntax metrics.
Run python3 measure.py [CANDIDATE.py] from any working directory.
"""

import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
FIELDS = ('source_bytes', 'tokens', 'normalized_tokens', 'ast_nodes', 'normalized_bytes')
SKIP = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
        tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}


def docstrings(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                yield first


def measure(path):
    data = Path(path).read_bytes()
    source = data.decode('utf-8')
    parsed = ast.parse(source)
    stripped = copy.deepcopy(parsed)
    excluded = {id(node) for node in docstrings(stripped)}
    for node in ast.walk(stripped):
        if hasattr(node, 'body') and isinstance(node.body, list):
            node.body = [item for item in node.body if id(item) not in excluded]
    spans = [((node.lineno, node.col_offset), (node.end_lineno, node.end_col_offset))
             for node in docstrings(parsed)]
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in SKIP and not any(a <= t.start and t.end <= b for a, b in spans)]
    normalized = ast.unparse(stripped) + '\n'
    imports = []
    for node in ast.walk(stripped):
        if isinstance(node, ast.Import):
            imports.extend(a.name for a in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append(node.module)
    return {
        'sha256': hashlib.sha256(data).hexdigest(),
        'source_bytes': len(data),
        'tokens': len(tokens),
        'normalized_tokens': sum(t.type not in SKIP for t in tokenize.generate_tokens(io.StringIO(normalized).readline)),
        'ast_nodes': sum(1 for _ in ast.walk(stripped)),
        'normalized_bytes': len(normalized.encode('utf-8')),
        'imports': sorted(set(imports)),
    }


def envelope(rows):
    return {key: min(r[key] for r in rows) for key in FIELDS}


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    measured = {}
    for entry in manifest['source_files']:
        row = measure(ROOT / entry['stored_path'])
        if row['sha256'] != entry['sha256'] or row['source_bytes'] != entry['source_bytes']:
            raise ValueError('Frozen comparator identity changed: ' + entry['stored_path'])
        measured[row['sha256']] = row
    primary = [{**r, 'metrics': measured[r['sha256']]} for r in manifest['primary']]
    standalone = [{**r, 'metrics': measured[r['sha256']]} for r in manifest['standalone']]
    groups = [{**g, 'metrics': {key: sum(measured[s][key] for s in g['files']) for key in FIELDS}}
              for g in manifest['inherited_groups']]
    all_metrics = [r['metrics'] for r in standalone + groups]
    result = {
        'snapshot_commit': manifest['snapshot']['commit'],
        'python_version': platform.python_version(),
        'primary': primary,
        'primary_envelope': envelope([r['metrics'] for r in primary]),
        'complete_envelope': envelope(all_metrics),
        'unique_standalone_count': len(standalone),
        'historical_group_count': len(groups),
        'frozen_source_count': len(measured),
        'standalone': standalone,
        'historical_groups': groups,
        'notes': manifest['notes'],
    }
    if len(sys.argv) > 1:
        candidate = measure(Path(sys.argv[1]))
        result['candidate'] = candidate
        result['candidate_at_or_below_complete_envelope'] = {
            key: candidate[key] <= result['complete_envelope'][key] for key in FIELDS}
        result['candidate_strictly_below_complete_envelope'] = {
            key: candidate[key] < result['complete_envelope'][key] for key in FIELDS}
    (ROOT / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    summary = {key: value for key, value in result.items()
               if key not in ('standalone', 'historical_groups', 'primary', 'notes')}
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
