A SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 6 November 2026

START HERE
  report.pdf       Complete mathematical exposition and entire checker listing.
  report.tex       Main LaTeX source; all included sources are in sections/.
  checker.py       Entire standalone trusted acceptance program.

RESULT
  Final checker: 735 executable AST nodes; 684 significant source tokens;
                 682 normalized tokens; 2,257 normalized bytes; 2,517 raw bytes.
  Prior envelope:750 executable AST nodes; 703 significant source tokens;
                 701 normalized tokens; 2,265 normalized bytes; 2,574 raw bytes.

Each coordinate improves on the minimum found in the complete checker variants
inside all six current draft archives, including smaller optional companions.
The frozen comparison contains 145 standalone variants and 74 overlapping
historical dependency groups in 181 exact source files. These are not disjoint
counts of independent theories. Historical soundness is not recertified.

Repository snapshot:
  VladimirReshetnikov/ProveIt
  473749742630b5a7779e7c3a36cd23ebd9cb53b5
  docs/drafts

NEW IN THIS ITERATION
  - Direct assumption positions replace repeated-formula lookup.
  - Numerical inference consumes a local successor proof.
  - Universal, existential, and numerical local proofs share context extension.
  - One substitution call shares validation and base-case construction.

The arithmetic/logic core, formula amalgamation, quantifier-free reflection,
and corrected ordinary realization are inherited from the draft series and
explicitly attributed in the report. The ordinary realization includes
numerical coverage and the falsity bridge. It is whole-domain bi-interpretable
with first-order intuitionistic PRA with quantifier-free induction; the native
checker faithfully presents it. This is a modest implementation reduction,
not an absolute minimality theorem or a new arithmetic-strength theorem.

RUN
  python3 checker.py examples/reflexivity.json
  python3 reproduce.py
  python3 reproduce.py --pdf

Python 3.10+ and the standard library suffice for checking and finite evidence.
The recorded measurements use Python 3.12.14. The PDF build also needs standard
pdfLaTeX packages; build_pdf.py can initialize a missing cached format when
the installed TeX sources are available.

The checker prints ACCEPT/REJECT and exits 0/1 for handled outcomes.
Run verification drivers without -O; the independent audit tests the actual
checker separately both with and without -O. No third-party Python package
or network access is required.

CERTIFICATES
  [context, goal, proof]
The context is an array of native formulas. An empty context certifies a
theorem; a nonempty context certifies only the conditional sequent.
The goal is validated independently of proof inference.

Terms:
  -1               Numerical zero.
  0,1,2,...        De Bruijn number-variable indices.
  ["s",t]          Successor.
  ["r",n,a,h]      Initialized recursion; h binds old value at 0 and counter at 1.
Formulas:
  ["=",s,t]        Equality.
  ["pi",A,B]       forall x(A -> B), binding x in both A and B.
  ["ex",A]         exists x A.
Falsity is the actual equation ["=",-1,["s",-1]]; no separate false token exists.
All constructor arities are exact. Boolean/float arithmetic payloads are invalid.

Proof forms:
  i                Assumption position. Negative positions count from the end.
  ["lam",A,q]      Guarded universal introduction with local proof q.
  ["pack",t,q]     Existential introduction under local witness equation y=t.
  ["nat",P,q]      Local numerical successor proof, as specified in the report.
  ["use",p,a,q]    Elimination selected by the inferred principal formula's head.
  ["r",n,a,h]      A literal zero/successor computation certificate.

Boolean proof-position aliases false/true select positions 0/1 if present.
They return actual validated stored assumptions. They are not numerical
terms or variable indices. Floats and other inappropriate reference types
are rejected. The position grammar is deliberately documented rather than
hidden behind a stricter advertised contract.

EVIDENCE
  - 239 frozen regressions: 132 accept, 107 reject.
  - 132 accepted reverse translations checked by the unchanged predecessor.
  - 18 complete examples translated and checked in both directions.
  - 17 extra selector/syntax cases.
  - 32,318 independent grammar probes.
  - 2,400 independently named-variable substitution comparisons.
  - 32,539 independent certificate checks: 55 accept, 32,484 reject.
  - 302 actual CLI executions, normal and optimized Python.

Additional identity/immutability checks overlap these inputs and are not
counted as new logical examples. The results identify the exact checker hash.
Finite tests are implementation evidence, not a formal proof of the metatheory.
The written proofs are not a Lean/Rocq formalization.

FILES
  comparison/               Frozen sources, provenance, metrics and measurement.
  proof_tools/              Untrusted, scope-aware proof translations.
  validation/               Original/frozen fixtures and portable regressions.
  validation/independent/   Named-binder oracle, adversarial and CLI audit.
  examples/                 18 final-format certificates.
  controls/indexed.py       Intermediate change with indexed assumptions only.
  results/                  Reproduction, mathematical audit and document records.
  source_archives.json      Exact source archive URLs, sizes and hashes.
  SHA256SUMS.txt             Checksums of all other packaged files.

Final checker SHA-256:
  9b0714684562edbb91a6595eb814934a6076cbe685beed5bd8cae270aa5c38e4

All acceptance code is in checker.py, importing only json and sys.
No translator, test, comparison program, external axiom database, or document
build utility is part of the acceptance boundary.
