"""Reproduce the frozen-corpus translations and selector cases offline.

This test program, its fixture converters, and the frozen predecessor are
untrusted development evidence. checker.py imports none of them.
"""
import hashlib
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def checked_file(path, digest):
    raw = (ROOT / path).read_bytes()
    require(sha(raw) == digest, 'File hash changed: ' + path)
    return raw


def encoded(data):
    return (json.dumps(data, separators=(',', ':'), ensure_ascii=True) + '\n').encode('utf-8')


def accepts(kernel, data):
    try:
        return kernel.check(data) is True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        return False


def main():
    manifest = json.loads((ROOT / 'validation/regression_manifest.json').read_text())
    for prefix in ('predecessor', 'candidate', 'legacy_converter', 'new_translator', 'selector_cases'):
        checked_file(manifest[prefix + '_file'], manifest[prefix + '_sha256'])

    originals = {}
    for source in manifest['source_manifests']:
        data = json.loads(checked_file(source['file'], source['sha256']))
        filename = Path(source['file']).name.removeprefix('source_')
        originals[filename] = {row['name']: row for row in data['records']}

    tr = load(ROOT / manifest['new_translator_file'], 'shared_transition_translation')
    legacy = load(ROOT / manifest['legacy_converter_file'], 'frozen_legacy_converter')
    rows = []
    for entry in manifest['records']:
        name = entry['name']
        original = originals[entry['original_manifest']][entry['original_name']]
        original_expected = original['accepted'] if entry['group'] == 'inherited' else original['expected']
        require(original_expected is entry['expected'], 'Label changed: ' + name)
        require(original['sha256'] == entry['raw_sha256'], 'Source digest changed: ' + name)

        raw = checked_file(entry['raw_file'], entry['raw_sha256'])
        parsed = json.loads(raw)
        regenerated = legacy.translate(parsed) if entry['group'] == 'inherited' else legacy.erase_false(parsed)
        canonical_raw = checked_file(entry['canonical_file'], entry['canonical_sha256'])
        require(encoded(regenerated) == canonical_raw, 'Canonicalization changed: ' + name)
        data = json.loads(canonical_raw)
        expected = entry['expected']
        require(accepts(tr.source, data) == expected, 'Predecessor outcome changed: ' + name)

        converted = tr.translate(data)
        require(sha(encoded(converted)) == entry['target_sha256'], 'Target translation changed: ' + name)
        if type(data) is list and len(data) == 3:
            require(converted[:2] == data[:2], 'Claimed sequent changed: ' + name)
        require(accepts(tr.target, converted) == expected, 'Candidate outcome changed: ' + name)
        reverse_checked = False
        if expected:
            returned = tr.translate(converted, reverse=True)
            require(returned[:2] == data[:2], 'Reverse sequent changed: ' + name)
            require(accepts(tr.source, returned), 'Reverse proof rejected: ' + name)
            reverse_checked = True
        rows.append({'name': name, 'group': entry['group'], 'expected': expected,
                     'source_checked': True, 'candidate_checked': True,
                     'reverse_checked': reverse_checked, 'target_sha256': entry['target_sha256']})

    examples = []
    for entry in manifest['examples']:
        original = json.loads(checked_file(entry['source_file'], entry['source_sha256']))
        packaged_raw = checked_file(entry['file'], entry['sha256'])
        data = json.loads(packaged_raw)
        require(accepts(tr.source, original), 'Example source rejected: ' + entry['name'])
        require(encoded(tr.translate(original)) == packaged_raw, 'Example translation changed: ' + entry['name'])
        require(accepts(tr.target, data), 'Example rejected: ' + entry['name'])
        reverse = tr.translate(data, reverse=True)
        require(reverse[:2] == original[:2], 'Example reverse sequent changed: ' + entry['name'])
        require(accepts(tr.source, reverse), 'Example reverse proof rejected: ' + entry['name'])
        examples.append({'name': entry['name'], 'assumptions': len(data[0]),
                         'candidate_checked': True, 'reverse_checked': True, 'sha256': entry['sha256']})

    selectors = json.loads((ROOT / manifest['selector_cases_file']).read_text())
    selector_rows = []
    for entry in selectors:
        data = entry['certificate']
        require(accepts(tr.target, data) == entry['expected'], 'Selector outcome changed: ' + entry['name'])
        if entry['expected']:
            reverse = tr.translate(data, reverse=True)
            require(reverse[:2] == data[:2], 'Selector reverse sequent changed: ' + entry['name'])
            require(accepts(tr.source, reverse), 'Selector reverse proof rejected: ' + entry['name'])
        selector_rows.append({'name': entry['name'], 'expected': entry['expected'],
                              'candidate_checked': True, 'reverse_checked': entry['expected']})

    result = {
        'status': 'passed', 'python_version': platform.python_version(),
        'candidate_sha256': manifest['candidate_sha256'],
        'predecessor_sha256': manifest['predecessor_sha256'],
        'frozen_records': len(rows), 'positive_records': sum(r['expected'] for r in rows),
        'negative_records': sum(not r['expected'] for r in rows),
        'positive_roundtrips': sum(r['reverse_checked'] for r in rows),
        'translated_examples': len(examples), 'selector_cases': len(selector_rows),
        'selector_acceptances': sum(r['expected'] for r in selector_rows),
        'records': rows, 'examples': examples, 'selectors': selector_rows,
        'qualification': manifest['qualification'],
        'proof_status': 'Finite implementation checks, not a formal proof of checker correctness.'
    }
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/regression.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('records', 'examples', 'selectors')}, indent=2))
    return result


if __name__ == '__main__':
    main()
