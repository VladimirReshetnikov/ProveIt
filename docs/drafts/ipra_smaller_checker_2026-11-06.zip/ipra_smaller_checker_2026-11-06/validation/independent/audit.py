"""Independent audit of the indexed canonical checker.

Grammar, named-binder conversion and generated-input helpers are adapted
from the sorted-certificates draft at the repository snapshot recorded
in SOURCE_PROVENANCE.json. The indexed rule cases and CLI boundary suite
are new. Expected conclusions never use candidate inference or substitution.

No candidate substitution, constructor-scope table, or inferred conclusion
is used to construct the expected results. Candidate files are imported
only to exercise them after tests have been constructed.
"""
import argparse
import copy
import hashlib
import subprocess
import tempfile
import importlib.util
import itertools
import json
from pathlib import Path
import random
import sys

COUNTER = itertools.count()
Z = -1
T = ['=', Z, Z]
D = ['=', Z, ['s', Z]]


def require(x):
    if not x:
        raise ValueError('invalid grammar')


def grammar(a, formula):
    """A strict, separately written ordinary JSON grammar recognizer."""
    if type(a) is int:
        return not formula and a >= -1
    if type(a) is not list or not a or type(a[0]) is not str:
        return False
    tag = a[0]
    if formula:
        if tag == '=' and len(a) == 3:
            return grammar(a[1], False) and grammar(a[2], False)
        if tag == 'pi' and len(a) == 3:
            return grammar(a[1], True) and grammar(a[2], True)
        if tag == 'ex' and len(a) == 2:
            return grammar(a[1], True)
        return False
    if tag == 's' and len(a) == 2:
        return grammar(a[1], False)
    if tag == 'r' and len(a) == 4:
        return all(grammar(x, False) for x in a[1:])
    return False


def named(a, bound=()):
    if type(a) is int:
        if a == -1:
            return ('zero',)
        if a < len(bound):
            return ('bound', bound[a])
        return ('free', a-len(bound))
    tag = a[0]
    if tag == 'r':
        u,v = next(COUNTER), next(COUNTER)
        return ('r', named(a[1], bound), named(a[2], bound), u,v,
                named(a[3], (u,v,*bound)))
    if tag == 'pi':
        x = next(COUNTER)
        return ('pi', x, named(a[1], (x,*bound)), named(a[2], (x,*bound)))
    if tag == 'ex':
        x = next(COUNTER)
        return ('ex', x, named(a[1], (x,*bound)))
    return (tag, *(named(x,bound) for x in a[1:]))


def transform(a, replacements, shift):
    tag = a[0]
    if tag == 'free':
        i = a[1]
        return replacements[i] if i < len(replacements) else ('free',i+shift)
    if tag in ('zero','bound'):
        return a
    if tag == 'r':
        return ('r', transform(a[1],replacements,shift),
                transform(a[2],replacements,shift), a[3],a[4],
                transform(a[5],replacements,shift))
    if tag == 'pi':
        return ('pi',a[1],transform(a[2],replacements,shift),
                transform(a[3],replacements,shift))
    if tag == 'ex':
        return ('ex',a[1],transform(a[2],replacements,shift))
    return (tag, *(transform(x,replacements,shift) for x in a[1:]))


def indexed(a, bound=()):
    tag = a[0]
    if tag == 'zero':
        return -1
    if tag == 'bound':
        return bound.index(a[1])
    if tag == 'free':
        return a[1] + len(bound)
    if tag == 'r':
        return ['r', indexed(a[1],bound), indexed(a[2],bound),
                indexed(a[5],(a[3],a[4],*bound))]
    if tag == 'pi':
        return ['pi',indexed(a[2],(a[1],*bound)),indexed(a[3],(a[1],*bound))]
    if tag == 'ex':
        return ['ex',indexed(a[2],(a[1],*bound))]
    return [tag, *(indexed(x,bound) for x in a[1:])]


def oracle(a, environment, depth=0):
    binders = tuple(next(COUNTER) for _ in range(depth))
    tree = named(a, binders)
    replacements = tuple(named(t) for t in environment[:-1])
    return indexed(transform(tree,replacements,environment[-1]),binders)


def load(path):
    spec = importlib.util.spec_from_file_location('candidate_'+Path(path).stem,path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def calls_ok(f,*args,**kwargs):
    try:
        return True,f(*args,**kwargs)
    except (ValueError,TypeError,KeyError,IndexError,RecursionError):
        return False,None


def erase(a):
    if type(a) is list:
        if a == ['false']:
            return D
        return [erase(x) for x in a]
    return a


def generated(rng,formula,depth):
    if not formula:
        if depth == 0 or rng.randrange(3) == 0:
            return rng.randrange(-1,7)
        if rng.randrange(2):
            return ['s',generated(rng,False,depth-1)]
        return ['r', *(generated(rng,False,depth-1) for _ in range(3))]
    if depth == 0:
        return ['=',generated(rng,False,1),generated(rng,False,1)]
    k=rng.randrange(3)
    if k == 0:
        return ['=',generated(rng,False,depth),generated(rng,False,depth)]
    if k == 1:
        return ['pi',generated(rng,True,depth-1),generated(rng,True,depth-1)]
    return ['ex',generated(rng,True,depth-1)]


def malformed_pool():
    vals=[-1,0,2,T,['s',0],['ex',T],None,False,True,0.0,-1.0,2.5,-2,-100,'','s','ss','r','rrr','=',
          '===','pi','pipipi','ex','exex','0','-1',{},[],['s'],['r'],['='],
          ['pi'],['ex'],['false'],['s',False],['s',0.0],['=',True,False],
          ['r',0,0,False],['r',0,0],['pi',T],['ex',T,T],['bogus',T],
          {'s':-1}, {'s':1,'0':-1}, {'=':0,'0':1,'1':2},
          {'pi':None,'ex':None,'s':None},['ex',{'=':0,'0':1,'1':2}],
          ['=',-1,{'s':-1}],['r',0,0,{'s':-1}]]
    alphabet='sr=pi ex01-'
    for n in range(1,5):
        vals.extend(''.join(v) for v in itertools.product(alphabet,repeat=n))
    for keys in [('s','r'),('r','s','0','1'),('=','s','r'),('pi','=', 'ex'),('ex','=')]:
        vals.append(dict.fromkeys(keys,None))
    return vals


def test_one(path, output):
    path = Path(path).resolve()
    before = hashlib.sha256(path.read_bytes()).hexdigest()
    mod = load(path)
    counts, failures, cases = {}, [], []

    def record(label, ok, detail=None):
        counts[label] = counts.get(label, 0) + 1
        if not ok:
            failures.append({'category': label, 'detail': detail})

    pool = malformed_pool()
    for val in pool:
        for formula in (False, True):
            ok, actual = calls_ok(mod.subst, val, (0,), formula=formula)
            expected = grammar(val, formula)
            record('grammar', ok == expected,
                   {'input': val, 'formula': formula, 'accepted': ok,
                    'expected': expected})
            if ok:
                record('validated_result', grammar(actual, formula) and actual == val)

    rng = random.Random(490344)
    for i in range(2400):
        formula, depth, k = bool(i % 2), i % 4, i % 4
        a = generated(rng, formula, 4)
        env = [generated(rng, False, 2) for _ in range(k)] + [rng.randrange(-k, 4)]
        expected = oracle(a, env, depth)
        ok, actual = calls_ok(mod.subst, a, env, d=depth, formula=formula)
        record('named_substitution', ok and actual == expected,
               {'input': a, 'environment': env, 'depth': depth,
                'expected': expected, 'actual': actual})

    def check(name, data, expected, category, cli=False):
        original = copy.deepcopy(data)
        ok, result = calls_ok(mod.check, data)
        actual = ok and result is True
        record(category, actual == expected,
               {'name': name, 'certificate': original,
                'expected': expected, 'accepted': actual})
        record('input_unchanged', data == original, {'name': name})
        if cli:
            cases.append({'name': name, 'data': original, 'expected': expected})

    # Positional references are proof metadata, separate from term integers.
    bank = [T, D, ['ex', T], ['pi', T, D]]
    for size in range(5):
        g = copy.deepcopy(bank[:size])
        for i in range(size):
            for p in (i, i - size):
                check(f'position_{size}_{p}', [g, g[i], p], True,
                      'signed_position', cli=size in (1, 4))
                ok, value = calls_ok(mod.infer, p, g)
                record('stored_object_identity', ok and value is g[i],
                       {'size': size, 'index': p})
        for p in (size, -size - 1, 10**80, -(10**80)):
            check(f'position_outside_{size}_{p}', [g, T, p], False,
                  'position_bounds', cli=size in (0, 4))

    check('bool_false_position', [[T, D], T, False], True, 'boolean_position', True)
    check('bool_true_position', [[T, D], D, True], True, 'boolean_position', True)
    check('bool_true_wrong_goal', [[T, D], T, True], False, 'boolean_position', True)
    check('bool_true_outside', [[T], T, True], False, 'boolean_position', True)
    check('bool_false_empty', [[], T, False], False, 'boolean_position', True)
    for p in (0.0, -1.0, 1.0, 2.5, '0', '-1', None, {}, [],
              ['hyp', T], ['=', Z, Z], ['pi', T, T], [0], {'index': 0}):
        check('wrong_position_' + repr(p), [[T], T, p], False,
              'position_type', True)

    # Every nonformula is rejected in the context and the asserted goal.
    for val in pool:
        if not grammar(val, True):
            check('bad_context', [[T, val], T, 0], False, 'malformed_context')
            check('bad_goal', [[T], val, 0], False, 'malformed_goal')
    for val in (False, True, 0.0, -1.0):
        check('term_alias_context', [[['=', val, val]], T, 0], False,
              'term_alias_rejected', True)
        check('term_alias_goal', [[['=', 0, 0]], ['=', val, val], 0], False,
              'term_alias_rejected', True)
    for data in (None, False, True, 0, 0.0, 'abc', {}, [], [[], T],
                 [[], T, 0, 0], [T, T, 0], ['not a context', T, 0]):
        check('bad_envelope_' + repr(data), data, False, 'envelope', True)

    # Hand-authored sequents exercise every rule, with independent conclusions.
    check('closed_guard_identity', [[], ['pi', T, T], ['lam', T, 0]],
          True, 'logical_positive', True)
    parameter = ['=', 0, Z]
    shifted = ['=', 1, Z]
    twice = ['=', 2, Z]
    check('guard_retained_parameter', [[parameter], ['pi', T, shifted], ['lam', T, 0]],
          True, 'logical_positive', True)
    check('nested_guard_retained_parameter',
          [[parameter], ['pi', T, ['pi', T, twice]], ['lam', T, ['lam', T, 0]]],
          True, 'logical_positive', True)
    check('pack_zero', [[], ['ex', ['=', 0, Z]], ['pack', Z, 0]],
          True, 'logical_positive', True)
    check('pack_parameter', [[], ['ex', ['=', 0, 1]], ['pack', 0, -1]],
          True, 'logical_positive', True)
    check('guard_application', [[['pi', T, T], T], T, ['use', 0, Z, 1]],
          True, 'logical_positive', True)
    # Witness occurrence beneath a second quantifier tests insertion lifting.
    body = ['ex', ['=', 0, 1]]
    principal = ['pi', T, body]
    witness = ['r', ['s', 0], 1, ['s', 0]]
    conclusion = oracle(body, [witness, -1])
    check('application_nested_binder', [[principal, T], conclusion, ['use', 0, witness, 1]],
          True, 'logical_positive', True)
    for template in (
        ['=', 0, 0],
        ['ex', ['=', 0, 1]],
        ['pi', ['=', 0, 1], ['ex', ['=', 0, 2]]],
        ['=', ['r', 0, 1, ['r', 1, 2, ['s', 0]]], 0],
    ):
        left, right = 0, ['s', 0]
        premise = oracle(template, [left, -1])
        result = oracle(template, [right, -1])
        check('transport_' + repr(template),
              [[['=', left, right], premise], result, ['use', 0, template, 1]],
              True, 'logical_positive', True)
    check('existential_retained_parameter',
          [[['ex', T], parameter], parameter, ['use', 0, parameter, 1]],
          True, 'logical_positive', True)
    check('existential_branch_assumption',
          [[['ex', T]], T, ['use', 0, T, -1]], True, 'logical_positive', True)

    # Syntactic eigenvariable conditions: use fixed wrong goals, not inferred ones.
    check('guard_capture', [[parameter], ['pi', T, parameter], ['lam', T, 0]],
          False, 'scope_rejection', True)
    check('nested_guard_capture',
          [[parameter], ['pi', T, ['pi', T, shifted]], ['lam', T, ['lam', T, 0]]],
          False, 'scope_rejection', True)
    check('witness_escape', [[['ex', parameter]], parameter, ['use', 0, parameter, -1]],
          False, 'scope_rejection', True)
    check('pack_unlifted_parameter', [[], ['ex', ['=', 0, 0]], ['pack', 0, -1]],
          False, 'scope_rejection', True)
    check('existential_wrong_slot',
          [[parameter, ['ex', T]], parameter, ['use', -1, parameter, -1]],
          False, 'scope_rejection', True)

    focused = [None, False, True, 0.0, 's', 'ss', 'r', 'pi', '=', {},
               {'s': 1, '0': 2}, [], T, ['ex', T], ['s', False], ['r', 0, 0, False]]
    for bad in focused:
        check('unused_application_witness', [[['pi', T, T], T], T, ['use', 0, bad, 1]],
              False, 'vacuous_witness_rejection')
        check('unused_pack_witness', [[T], ['ex', T], ['pack', bad, 0]],
              False, 'vacuous_witness_rejection')
        if not grammar(bad, True):
            check('malformed_guard', [[], ['pi', T, T], ['lam', bad, 0]],
                  False, 'malformed_rule_argument')
        check('unused_recursion_body', [[], ['=', ['r', Z, Z, 0], Z], ['r', Z, Z, bad]],
              False, 'unused_recursion_body')

    # Simultaneous state/counter substitution, including nested recursion.
    updates = [0, 1, 2, ['s', 0], ['r', 1, 0, ['r', 1, 2, ['s', 0]]]]
    for h in updates:
        r = ['r', Z, ['s', 2], h]
        check('recursion_base_' + repr(h), [[], ['=', r, ['s', 2]], r],
              True, 'recursion_positive', True)
        n, a = 0, ['s', 2]
        r = ['r', ['s', n], a, h]
        expected = oracle(h, [['r', n, a, h], n, -2])
        check('recursion_step_' + repr(h), [[], ['=', r, expected], r],
              True, 'recursion_positive', True)
    for n in (0, 3, ['r', Z, Z, 0]):
        r = ['r', n, Z, 0]
        check('noncanonical_recursion_counter', [[], ['=', r, Z], r],
              False, 'recursion_counter_rejection', True)
    for wrong in (['r', Z, Z], ['r', Z, Z, 0, Z], ['rec', ['r', Z, Z, 0]],
                  ['s', Z], ['bogus'], ['lam'], ['pack', Z], ['use', 0, T],
                  ['use', 0, T, 0, 0]):
        check('bad_proof_record_' + repr(wrong), [[T], T, wrong],
              False, 'proof_arity', True)

    matrices = [
        ['=', 0, 0], ['=', 0, 3], ['ex', ['=', 0, 1]],
        ['pi', ['=', 0, 1], ['=', 1, 0]],
        ['ex', ['pi', ['=', 0, 2], ['=', 1, 4]]],
    ]
    for P in matrices:
        base = oracle(P, [Z, 0])
        guard = P if P[0] == '=' else base
        required_step = ['pi', guard, oracle(P, [['s', 0], 0])]
        goal = ['pi', base, P]
        # The new N rule checks a local successor derivation, not a closed
        # guarded-step formula. The lifted major is instantiated at fresh 0.
        local_step = ['use', 0, 0, -1]
        check('numerical_rule_' + repr(P), [[required_step], goal, ['nat', P, local_step]],
              True, 'numerical_rule', True)
        incorrect = ['pi', base, oracle(P, [1])]
        if incorrect != goal:
            check('numerical_parameter_shift', [[required_step], incorrect, ['nat', P, local_step]],
                  False, 'numerical_scope_rejection', True)
        if P[0] != '=':
            forbidden = ['pi', P, oracle(P, [['s', 0], 0])]
            check('quantified_induction', [[forbidden], goal, ['nat', P, local_step]],
                  False, 'quantified_induction_rejection', True)
            check('compound_matrix_as_local_hypothesis',
                  [[], goal, ['nat', P, -1]], False,
                  'quantified_induction_rejection', True)
    term = ['r', 0, 1, ['s', 0]]
    P = ['=', ['r', Z, term, Z], term]
    term_next = oracle(term, [['s', 0], 0])
    q = ['r', Z, term_next, Z]
    goal = ['pi', oracle(P, [Z, 0]), P]
    check('proved_numerical_parameter', [[], goal, ['nat', P, q]],
          True, 'proved_numerical_rule', True)
    inner = ['r', 1, 2, 0]
    P = ['ex', ['=', ['r', Z, inner, Z], inner]]
    base = oracle(P, [Z, 0])
    inner_next = ['r', ['s', 1], 2, 0]
    q = ['pack', Z, ['r', Z, inner_next, Z]]
    check('proved_compound_parameter', [[], ['pi', base, P], ['nat', P, q]],
          True, 'proved_numerical_rule', True)
    for bad in (None, True, False, 0, 'pi', {}, ['=', True, False], ['s', 0], ['ex', 0]):
        check('malformed_numerical_matrix', [[], ['pi', T, T], ['nat', bad, ['lam', T, 0]]],
              False, 'malformed_numerical_matrix', True)
    for good in (0, -1, False):
        check('constant_matrix_local_reference', [[], ['pi', T, T], ['nat', T, good]],
              True, 'local_numerical_context', True)
    for bad in (None, True, 1, 'pi', {}, [], ['lam'], ['nat', T], ['r', Z, Z], ['lam', T, 0]):
        check('malformed_numerical_premise', [[], ['pi', T, T], ['nat', T, bad]],
              False, 'malformed_numerical_premise', True)
    P = ['=', 0, Z]
    successor = oracle(P, [['s', 0], 0])
    check('numerical_context_capture',
          [[successor], ['pi', oracle(P, [Z, 0]), P], ['nat', P, 0]],
          False, 'numerical_scope_rejection', True)
    check('closed_falsity', [[], D, 0], False, 'closed_falsity', True)
    check('raw_falsity_alias', [[D], ['false'], 0], False, 'canonical_boundary', True)
    check('raw_falsity_alias_in_guard', [[], ['pi', D, D], ['lam', ['false'], 0]],
          False, 'canonical_boundary', True)

    with tempfile.TemporaryDirectory(prefix='ipra-independent-audit-') as directory:
        directory = Path(directory)
        cli_jobs = []
        for i, case in enumerate(cases):
            fixture = directory / f'case_{i:03}.json'
            fixture.write_text(json.dumps(case['data']) + '\n')
            cli_jobs.append((case['name'], [str(fixture)], case['expected']))
        raw_cases = {
            'invalid_utf8': b'\xff\xfe',
            'empty': b'',
            'truncated': b'[[],',
            'trailing_json': b'[[],[],[]] null',
            'nan_position': b'[[["=",-1,-1]],["=",-1,-1],NaN]',
            'infinite_position': b'[[["=",-1,-1]],["=",-1,-1],Infinity]',
            'parser_depth': b'[' * 5000 + b'0' + b']' * 5000,
        }
        for name, raw in raw_cases.items():
            fixture = directory / (name + '.json')
            fixture.write_bytes(raw)
            cli_jobs.append((name, [str(fixture)], False))
        cli_jobs += [('missing_argument', [], False),
                     ('extra_argument', ['one', 'two'], False),
                     ('missing_file', [str(directory / 'missing.json')], False)]
        for name, args, expected in cli_jobs:
            for optimized in (False, True):
                command = [sys.executable, *(['-O'] if optimized else []), str(path), *args]
                try:
                    p = subprocess.run(command, capture_output=True, text=True, timeout=8)
                    actual = p.returncode == (0 if expected else 1) and p.stdout.strip() == ('ACCEPT' if expected else 'REJECT') and not p.stderr
                    detail = {'name': name, 'optimized': optimized, 'expected': expected,
                              'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}
                except (OSError, subprocess.TimeoutExpired) as error:
                    actual = False
                    detail = {'name': name, 'optimized': optimized, 'error': type(error).__name__}
                record('cli', actual, detail)

    after = hashlib.sha256(path.read_bytes()).hexdigest()
    record('candidate_unchanged', before == after)
    result = {
        'candidate': str(path), 'candidate_sha256': before,
        'python_version': sys.version,
        'counts': counts, 'total': sum(counts.values()),
        'passed': not failures, 'failures': failures,
        'scope': 'Finite independent implementation checks; not formal verification or a universal proof of the metatheory.',
        'oracle': 'Strict grammar plus named-binder simultaneous substitution; candidate code is used only for actual outcomes.'
    }
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'failures'}, indent=2))
    if failures:
        print(json.dumps(failures[:12], indent=2))
    return not failures


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).parent / 'results.json')
    args = parser.parse_args()
    sys.exit(0 if test_one(args.candidate, args.output) else 1)


