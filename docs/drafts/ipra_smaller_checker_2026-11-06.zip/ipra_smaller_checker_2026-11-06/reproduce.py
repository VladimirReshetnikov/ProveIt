"""Reproduce the frozen comparison and finite checks, optionally the PDF."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pdf", action="store_true")
    args = parser.parse_args()
    if not __debug__:
        raise SystemExit("Run this test driver without -O; it separately tests the checker with -O.")
    commands = [
        ["comparison/measure.py", "checker.py"],
        ["validation/regression.py"],
        ["validation/independent/audit.py", "checker.py"],
        ["document_data.py"],
    ]
    if args.pdf:
        commands.append(["build_pdf.py"])
    records = []
    for command in commands:
        result = subprocess.run([sys.executable, *command], cwd=ROOT,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True)
        records.append({"command": command, "returncode": result.returncode,
                        "output": result.stdout})
        print("PASS" if result.returncode == 0 else "FAIL", " ".join(command))
        if result.returncode:
            print(result.stdout)
            raise SystemExit(result.returncode)
    metrics = json.loads((ROOT / "comparison/metrics.json").read_text())
    if not all(metrics["candidate_strictly_below_complete_envelope"].values()):
        raise SystemExit("The checker is no longer below the frozen baseline envelope.")
    result = {"passed": True, "candidate_sha256":
              hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
              "pdf_built": args.pdf, "steps": records}
    (ROOT / "results/reproduction.json").write_text(json.dumps(result, indent=2) + "\n")
    print("All requested reproduction steps passed.")


if __name__ == "__main__":
    main()
