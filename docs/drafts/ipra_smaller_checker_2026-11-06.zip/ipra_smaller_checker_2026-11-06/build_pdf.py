"""Compile the report; no part of this script participates in proof acceptance."""
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def run(command, cwd):
    result = subprocess.run(command, cwd=cwd, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    if result.returncode:
        raise RuntimeError(result.stdout)
    return result.stdout


def main():
    build = ROOT / ".build"
    pdf_dir = build / "pdf"
    pdf_dir.mkdir(parents=True, exist_ok=True)
    format_path = subprocess.run(["kpsewhich", "pdflatex.fmt"],
                                stdout=subprocess.PIPE, text=True).stdout.strip()
    extra = []
    if not format_path:
        # Some minimal TeX installations contain the sources but no cached format.
        fmt_dir = build / "tex"
        fmt_dir.mkdir(exist_ok=True)
        fmt = fmt_dir / "pdflatex.fmt"
        if not fmt.exists():
            run(["pdftex", "-ini", "-jobname=pdflatex", "-progname=pdflatex",
                 "-etex", "-interaction=nonstopmode", "-halt-on-error",
                 "pdflatex.ini"], fmt_dir)
        extra = ["-fmt=" + str(fmt)]
    logs = []
    for _ in range(3):
        logs.append(run(["pdflatex", *extra, "-interaction=nonstopmode",
                         "-halt-on-error", "-output-directory=" + str(pdf_dir),
                         "report.tex"], ROOT))
    log = (pdf_dir / "report.log").read_text()
    if re.search(r"Overfull \\[hv]box|undefined references|Reference .* undefined", log):
        raise RuntimeError("The report has overflow or unresolved references; inspect the build log.")
    shutil.copyfile(pdf_dir / "report.pdf", ROOT / "report.pdf")
    (ROOT / "results/latex_build.log").write_text(log)
    print("Compiled report.pdf without overflow or unresolved references.")


if __name__ == "__main__":
    main()
