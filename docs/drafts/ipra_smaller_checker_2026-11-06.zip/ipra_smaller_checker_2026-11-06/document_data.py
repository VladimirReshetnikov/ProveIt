"""Generate the article's tables from the recorded executable evidence."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    result = json.loads((ROOT / "comparison/metrics.json").read_text())
    candidate = result["candidate"]
    out = ROOT / "results"
    out.mkdir(exist_ok=True)
    names = {"NewAST": "ast_nodes", "NewTokens": "tokens",
             "NewNorm": "normalized_bytes", "NewRaw": "source_bytes"}
    (out / "metrics.tex").write_text("".join(
        "\\newcommand{\\" + name + "}{" + f"{candidate[key]:,}" + "}\n"
        for name, key in names.items()))
    labels = ["Canonical leaf", "Factored checker", "Indexed kernel",
              "Shared rules", "Small kernel", "Sorted certificates"]
    rows = [(name, row["metrics"]) for name, row in zip(labels, result["primary"])]
    by_hash = {row["sha256"]: row["metrics"] for row in result["standalone"]}
    rows.extend([
        ("Sorted canonical companion", by_hash["1a6a988bed59af630213c78bba3d12bf2579d30190706cdd8de7ebba5d21a8fd"]),
        ("Sorted split-introduction control", by_hash["8d9219151facdaca4b3aedb881721ffbb0bf9f18081346d18942ae4fdb6542ad"]),
        ("Complete baseline envelope", result["complete_envelope"]),
        ("New shared local rules", candidate),
    ])
    lines = ["\\begin{tabular}{lrrrr}", "\\toprule",
             "Complete implementation & AST & Tokens & Norm. bytes & Raw bytes\\\\",
             "\\midrule"]
    for i, (name, metrics) in enumerate(rows):
        if i >= 8:
            lines.append("\\midrule")
        fields = [name] + [f"{metrics[key]:,}" for key in
                           ["ast_nodes", "tokens", "normalized_bytes", "source_bytes"]]
        if i >= 8:
            fields = ["\\textbf{" + f + "}" for f in fields]
        lines.append(" & ".join(fields) + "\\\\")
    lines.extend(["\\bottomrule", "\\end{tabular}"])
    (out / "comparison_table.tex").write_text("\n".join(lines) + "\n")
    audit = json.loads((ROOT / "validation/independent/results.json").read_text())
    assert audit["passed"] and audit["candidate_sha256"] == candidate["sha256"]
    counts = audit["counts"]
    table = [
        ("Grammar probes", counts["grammar"]),
        ("Named-variable substitution comparisons", counts["named_substitution"]),
        ("Certificate decisions (55 accept; 32,484 reject)", counts["input_unchanged"]),
        ("Stored-assumption identity checks", counts["stored_object_identity"]),
        ("Actual command-line executions", counts["cli"]),
        ("Separate input-immutability comparisons", counts["input_unchanged"]),
    ]
    lines = ["\\begin{tabular}{lr}", "\\toprule", "Audit category & Checks\\\\",
             "\\midrule"]
    lines.extend(name + " & " + f"{number:,}" + "\\\\" for name, number in table)
    lines.extend(["\\bottomrule", "\\end{tabular}"])
    (out / "audit_table.tex").write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
