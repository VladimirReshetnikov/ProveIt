UNTRUSTED PROOF TRANSLATIONS AND FROZEN REGRESSION EVIDENCE

The acceptance program is ../checker.py. It imports none of these tools,
none of the fixtures, and none of the frozen predecessor or comparison code.

TRANSLATE ONE CERTIFICATE

From the package root:

  python3 proof_tools/translate.py forward SOURCE.json
  python3 proof_tools/translate.py reverse TARGET.json

The forward direction takes a canonical certificate for the frozen sorted
predecessor in validation/sorted_predecessor.py. It replaces formula-key
assumptions by context indices and replaces the closed successor-step premise
by a derivation under a fresh number variable and its allowed hypothesis.
The reverse direction restores formula-key assumptions and introduces the
successor-step binder. Contexts and claimed goals are preserved.

The forward translator performs scope-aware numerical weakening. It retains
proof-local numerical variables, the formal equality-template slot, and the
numerical-matrix slot. These details are part of the translation, never an
extra privilege of the checker.

Malformed source proofs may translate to null when local syntax or scope
reconstruction fails. Null is rejected as a proof by both kernels. The
translator's output must be checked; its execution is not evidence that the
supplied input was a proof. Formula syntax, finite computation equations,
and inference rules are always checked again by the selected kernel.

REPLAY EVERYTHING

  python3 validation/regression.py

This writes results/regression.json and checks:

  - 239 frozen source records: 132 acceptances and 107 rejections;
  - all 132 positive reverse proof translations;
  - 18 complete demonstrations translated in both directions;
  - 17 direct selector/object-syntax cases, of which six are positive.

The 239 records comprise 176 inherited cases (116 positive / 60 negative)
and 63 direct sorted-kernel cases (16 positive / 47 negative). Their labels
are verified against verbatim copies of the original source manifests.
The raw source fixtures are retained with original hashes. Their canonical
forms, produced by the preserved legacy adapter, are also retained and
verified. Each final-format translation is checked against its recorded
SHA-256 digest before its acceptance result is tested.

The runner uses only paths relative to this package. It does not use the
source repository, any network connection, or the development workspace.

PROVENANCE

Repository: https://github.com/VladimirReshetnikov/ProveIt
Snapshot: 473749742630b5a7779e7c3a36cd23ebd9cb53b5
Archive: docs/drafts/ipra_sorted_certificates_2026-11-06.zip
Archive SHA-256:
5109b5c5d47911cbb049ca269016f79f94dbbebf396f81d0d4bab74b65a56ac2

The frozen predecessor is the archive's checker_core.py, copied verbatim.
legacy_to_sorted.py is its proof_tools/translate_to_new.py, copied verbatim.
The latter is used only to reproduce the source fixtures' explicit arithmetic
falsity expansion and the earlier schema-to-step translation. Per-file
provenance and all retained hashes are in validation/regression_manifest.json.

The matched control controls/indexed.py uses the frozen predecessor's rules
with only direct context selectors added. It is not imported by the final
checker or needed by the final proof translator.

These are finite executable checks. The mathematical equivalence arguments
are in the paper; no proof-assistant verification of Python is claimed.
