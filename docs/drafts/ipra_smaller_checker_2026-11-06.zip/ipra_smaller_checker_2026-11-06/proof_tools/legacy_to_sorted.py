"""Untrusted old-axiom to literal-hypothesis/step-rule elaborator.

The checker never imports this module. Native syntax and contexts are
unchanged. Surface falsity is expanded to its declared arithmetic spelling
before constructing the numerical-schema derivation. Every old numerical
axiom is replaced by a proof using two lambda introductions and the new
single-premise numerical rule.

Unknown or malformed old proof records map to an invalid certificate tag;
this prevents an old invalid bare formula from becoming a new hypothesis.
"""

import json
import sys


SCOPES = {"s": (0,), "r": (0, 0, 2), "=": (0, 0),
          "pi": (1, 1), "ex": (1,)}


def subst(a, env=(1,), d=0):
    """Finite-prefix substitution used only by the untrusted elaborator."""
    if type(a) is int:
        i = a - d
        return a if i < 0 else subst(env[i], (d,)) if i < len(env) - 1 else a + env[-1]
    tag, *args = a
    return [tag, *(subst(child, env, d + width)
                   for child, width in zip(args, SCOPES[tag], strict=True))]


def erase_false(value):
    if value == ["false"]:
        return ["=", -1, ["s", -1]]
    return list(map(erase_false, value)) if type(value) is list else value


def numerical_axiom(matrix):
    base = subst(matrix, [-1, 0])
    hypothesis = matrix if matrix[0] == "=" else base
    step = ["pi", hypothesis, subst(matrix, [["s", 0], 0])]
    shifted_step = subst(step, (2,))
    shifted_matrix = subst(matrix, (2,), d=1)
    return ["lam", base,
            ["lam", shifted_step,
             ["use", ["nat", shifted_matrix, shifted_step], 1, subst(base)]]]


def to_step(proof):
    match proof:
        case ["hyp", formula]:
            return formula
        case ["pi", formula, child]:
            return ["lam", formula, to_step(child)]
        case ["use", first, argument, second]:
            return ["use", to_step(first), argument, to_step(second)]
        case ["pack", witness, child]:
            return ["pack", witness, to_step(child)]
        case ["rec", ["r", _, _, _] as recursor]:
            return recursor
        case ["nat", formula]:
            try:
                return numerical_axiom(formula)
            except (ValueError, TypeError, IndexError, KeyError, RecursionError):
                return ["invalid-old-record", proof]
        case _:
            return ["invalid-old-record", proof]


def translate(data):
    data = erase_false(data)
    if type(data) is not list or len(data) != 3:
        return data
    context, conclusion, proof = data
    return [context, conclusion, to_step(proof)]


if __name__ == "__main__":
    with open(sys.argv[1], encoding="utf-8") as stream:
        data = translate(json.load(stream))
    print(json.dumps(data, separators=(",", ":")))
