"""Untrusted translations for the checker with a shared binder transition.

Source: sorted_certificates/checker_core.py (formula leaves, closed step).
Target: checker.py (indexed leaves, fresh-variable step branch).
No translator is imported by an acceptance kernel.
"""
import json
from pathlib import Path
import sys
import importlib.util

ROOT = Path(__file__).resolve().parents[1]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


source = load(ROOT / 'validation/sorted_predecessor.py', 'formula_kernel')
target = load(ROOT / 'checker.py', 'shared_kernel')
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError, AttributeError)


def guard(matrix):
    base = source.subst(matrix, [-1, 0])
    return matrix if matrix[0] == '=' else base


def lift(proof, context, amount=1, depth=0):
    """Raise only outer number parameters in a source-format derivation.

    Formula-key assumptions make adding an irrelevant formula harmless.
    Proof-local binders, equality-template slot, and numerical matrix slot
    are retained. SCOPES handles binders internal to expressions.
    """
    def expression(value, formula=True, extra=0):
        return source.subst(value, (amount,), d=depth + extra, formula=formula)

    match proof:
        case ['lam', a, q]:
            local = [*map(source.subst, context), a]
            return ['lam', expression(a, extra=1), lift(q, local, amount, depth+1)]
        case ['pack', a, q]:
            local = [*map(source.subst, context), ['=', 0, source.subst(a, formula=False)]]
            return ['pack', expression(a, formula=False), lift(q, local, amount, depth+1)]
        case ['use', p, a, q]:
            e = source.infer(p, context)
            tag = e[0]
            local = [*map(source.subst, context), *e[1:]] if tag == 'ex' else context
            return ['use', lift(p, context, amount, depth),
                    expression(a, formula=tag != 'pi', extra=int(tag == '=')),
                    lift(q, local, amount, depth + int(tag == 'ex'))]
        case ['r', _, _, _]:
            return expression(proof, formula=False)
        case ['nat', a, q]:
            return ['nat', expression(a, extra=1), lift(q, context, amount, depth)]
        case _:
            return expression(context[context.index(proof)])


def transform(proof, context, reverse=False):
    kernel = target if reverse else source
    try:
        match proof:
            case [('lam' | 'pack') as tag, a, q]:
                h = a if tag == 'lam' else ['=', 0, kernel.subst(a, formula=False)]
                local = [*map(kernel.subst, context), h]
                return [tag, a, transform(q, local, reverse)]
            case ['use', p, a, q]:
                e = kernel.infer(p, context)
                local = [*map(kernel.subst, context), *e[1:]] if e[0] == 'ex' else context
                return ['use', transform(p, context, reverse), a, transform(q, local, reverse)]
            case ['r', _, _, _]:
                return proof
            case ['nat', a, q]:
                h = guard(a)
                local = [*map(kernel.subst, context), h]
                if reverse:
                    return ['nat', a, ['lam', h, transform(q, local, True)]]
                # Instantiate the weakened closed step at the new number 0,
                # then use the fresh retained hypothesis h.
                body = ['use', lift(q, context), 0, h]
                return ['nat', a, transform(body, local)]
            case _:
                return context[proof] if reverse else context.index(proof)
    except ERRORS:
        return None


def translate(data, reverse=False):
    if type(data) is not list or len(data) != 3:
        return data
    g, a, p = data
    return [g, a, transform(p, g, reverse)]


if __name__ == '__main__':
    direction, file = sys.argv[1:]
    if direction not in ('forward', 'reverse'):
        raise SystemExit('direction must be forward or reverse')
    with open(file, encoding='utf-8') as stream:
        print(json.dumps(translate(json.load(stream), direction == 'reverse')))
