#!/usr/bin/env python3
"""Executable checks for PRA by predecessor returns.

This program constructs actual formula trees for the new emitter and the
three same-language current drafts.  It checks their syntax and node counts,
the claimed finite comparison ledger, frozen-descriptor substitution,
normalization, computation recovery, and bounded Boolean trajectories.

It is NOT a proof of the universal comparison theorem, consistency,
bi-interpretability, or the arithmetic compilation theorem.  Those claims
require the written proofs.  No previous draft's code is imported.

Python 3.10 or later; no third-party packages.  Run from any directory:
    python3 checks/check_syntax_and_witnesses.py
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
import itertools
import json
from pathlib import Path
import platform
import random


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple["Term", ...] = ()
    descriptor: "Term | None" = None


@dataclass(frozen=True)
class Formula:
    op: str
    args: tuple["Term | Formula", ...] = ()
    variable: str | None = None


def var(name: str) -> Term:
    return Term("$" + name)


N, A, B, C, V, W, X, Y = map(var, ("n", "a", "b", "c", "v", "w", "x", "y"))
ZERO = Term("0")


def S(t: Term) -> Term:
    return Term("S", (t,))


ONE = S(ZERO)


def chi(t: Term, u: Term) -> Term:
    return Term("chi", (t, u))


def R(h: Term, t: Term, u: Term) -> Term:
    return Term("R", (t, u), h)


def Q(t: Term, u: Term) -> Term:
    return R(W, t, u)


def Z(t: Term, u: Term) -> Term:
    return R(ZERO, t, u)


def substitute(t: Term, assignments: dict[str, Term]) -> Term:
    """Simultaneous substitution into active arguments only."""
    if t.op.startswith("$"):
        return assignments.get(t.op[1:], t)
    return Term(t.op, tuple(substitute(a, assignments) for a in t.args), t.descriptor)


def at(t: Term, first: Term, second: Term) -> Term:
    return substitute(t, {"n": first, "a": second})


def nf(t: Term) -> Term:
    """Strip only literal root Q(S(r),s); do not visit other subtrees."""
    while t.op == "R" and t.descriptor == W and t.args[0].op == "S":
        t = t.args[0].args[0]
    return t


def descriptor(t: Term) -> Term:
    return at(nf(t), V, W)


@lru_cache(maxsize=200_000)
def weight(node: Term | Formula, full: bool = False) -> int:
    result = 1 + sum(weight(a, full) for a in node.args)
    if full and isinstance(node, Term) and node.descriptor is not None:
        result += weight(node.descriptor, True)
    return result


@lru_cache(maxsize=100_000)
def occurrences(t: Term, name: str) -> int:
    return int(t.op == "$" + name) + sum(occurrences(a, name) for a in t.args)


def free_variables(node: Term | Formula) -> set[str]:
    if isinstance(node, Term) and node.op.startswith("$"):
        return {node.op[1:]}
    result: set[str] = set()
    for child in node.args:
        result |= free_variables(child)
    if isinstance(node, Formula) and node.op in {"forall", "exists"}:
        result.discard(node.variable)
    return result


def eq(t: Term, u: Term) -> Formula:
    return Formula("=", (t, u))


def conjunction(p: Formula, q: Formula) -> Formula:
    return Formula("and", (p, q))


def disjunction(p: Formula, q: Formula) -> Formula:
    return Formula("or", (p, q))


def implication(p: Formula, q: Formula) -> Formula:
    return Formula("implies", (p, q))


FALSE = Formula("false")


def negation(p: Formula) -> Formula:
    return implication(p, FALSE)


def forall(name: str, p: Formula) -> Formula:
    return Formula("forall", (p,), name)


def exists(name: str, p: Formula) -> Formula:
    return Formula("exists", (p,), name)


def close(p: Formula) -> Formula:
    return forall("a", forall("n", p))


def counts(p: Formula) -> tuple[int, int]:
    return weight(p), weight(p, True)


def show(node: Term | Formula) -> str:
    if isinstance(node, Formula):
        if node.op in {"forall", "exists"}:
            return f"{node.op} {node.variable} ({show(node.args[0])})"
        if node.op == "false":
            return "FALSE"
        return f"({show(node.args[0])} {node.op} {show(node.args[1])})"
    if node.op.startswith("$"):
        return node.op[1:]
    if node.op == "0":
        return "0"
    if node.op == "R":
        name = "Q" if node.descriptor == W else "Z" if node.descriptor == ZERO else f"R[{show(node.descriptor)}]"
    else:
        name = node.op
    return name + "(" + ",".join(map(show, node.args)) + ")"


SEED_BIT = Q(S(N), A)
SEED_PARTITION = Z(chi(N, ZERO), A)
BIT = close(conjunction(eq(chi(A, A), ONE), disjunction(eq(A, N), eq(chi(A, N), ZERO))))
SEPARATION = negation(eq(ZERO, ONE))
OLD_SEED = close(conjunction(SEPARATION, conjunction(eq(chi(A, A), ONE), disjunction(eq(A, N), eq(chi(A, N), ZERO)))))
PARTITION = forall("x", exists("y", negation(eq(chi(X, ZERO), chi(X, S(Y))))))


def computation(t: Term, mode: str) -> Formula:
    h = descriptor(t)
    base = eq(R(h, ZERO, A), A)
    lhs = R(h, S(N), A)
    if mode == "left":
        step = eq(lhs, at(t, R(h, N, A), N))
    elif mode == "right":
        step = eq(lhs, R(h, N, at(t, A, ZERO)))
    elif mode == "bound":
        step = forall("c", implication(eq(R(h, N, A), C), eq(lhs, at(t, C, N))))
    else:
        raise ValueError(mode)
    return close(conjunction(base, step))


def predecessor_return(t: Term) -> Formula:
    h = descriptor(t)
    q = Q(Q(chi(R(h, B, A), A), B), N)
    return close(exists("b", eq(R(h, q, A), A)))


def boundary_return(t: Term) -> Formula:
    h = descriptor(t)
    first = eq(R(h, S(B), A), A)
    second = eq(R(h, S(S(B)), A), A)
    return close(exists("b", conjunction(first, implication(second, eq(B, N)))))


def old_local_return(t: Term) -> Formula:
    h = descriptor(t)
    q = Q(Z(chi(R(h, S(S(B)), A), A), S(B)), N)
    return close(exists("b", eq(R(h, S(q), A), A)))


def old_rooted_return(t: Term) -> Formula:
    h = descriptor(t)
    first = eq(R(h, S(B), A), A)
    second = eq(R(h, S(S(B)), A), A)
    progress = forall("b", implication(first, second))
    conclusion = eq(R(h, S(N), A), A)
    return close(implication(progress, conclusion))


def local_mark(t: Term) -> Term:
    return Q(Z(chi(A, ZERO), S(t)), N)


def rooted_mark(t: Term) -> Term:
    return Z(Z(chi(A, ZERO), chi(t, ZERO)), N)


def is_local_mark(t: Term) -> bool:
    if not (t.op == "R" and t.descriptor == W and t.args[1] == N):
        return False
    z = t.args[0]
    return (z.op == "R" and z.descriptor == ZERO and z.args[0] == chi(A, ZERO)
            and z.args[1].op == "S")


def is_broad_local_mark(t: Term) -> bool:
    return is_local_mark(t) or (
        t.op == "R" and t.descriptor == ZERO and t.args[0] == chi(N, ZERO)
        and is_local_mark(t.args[1])
    )


def is_rooted_mark(t: Term) -> bool:
    if not (t.op == "R" and t.descriptor == ZERO and t.args[1] == N):
        return False
    z = t.args[0]
    if not (z.op == "R" and z.descriptor == ZERO and z.args[0] == chi(A, ZERO)):
        return False
    c = z.args[1]
    return c.op == "chi" and c.args[1] == ZERO


def new_emitter(t: Term) -> tuple[str, Formula]:
    i, j = occurrences(t, "n"), occurrences(t, "a")
    if t == SEED_BIT:
        return "bit seed", BIT
    if t == SEED_PARTITION:
        return "partition seed", PARTITION
    if nf(t) == t and i > 0 and t != N:
        return "predecessor return", predecessor_return(t)
    if i > 0 and j == 0:
        return "right computation", computation(t, "right")
    if i >= 4:
        return "bound computation", computation(t, "bound")
    return "left computation", computation(t, "left")


def old_emitter(t: Term, source: str) -> tuple[str, Formula]:
    i, j = occurrences(t, "n"), occurrences(t, "a")
    if source == "rooted":
        if t == SEED_PARTITION:
            return "old seed", OLD_SEED
        if i > 0 and j == 0:
            return "right computation", computation(t, "right")
        if is_rooted_mark(t):
            return "rooted return", old_rooted_return(t)
        if i >= 4:
            return "bound computation", computation(t, "bound")
        return "left computation", computation(t, "left")
    if t == SEED_BIT:
        return "old seed", OLD_SEED
    if i > 0 and j == 0:
        return "right computation", computation(t, "right")
    marked = is_broad_local_mark(t) if source == "local broad option" else is_local_mark(t)
    if marked:
        return ("boundary return", boundary_return(t)) if source == "boundary" else ("local return", old_local_return(t))
    return "left computation", computation(t, "left")


def expected_computation_counts(t: Term, mode: str) -> tuple[int, int]:
    m, full, canonical, i = weight(t), weight(t, True), weight(nf(t), True), occurrences(t, "n")
    if mode == "left":
        return 13 + m + 2 * i, 13 + full + 2 * i + (2 + i) * canonical
    if mode == "right":
        return 15 + m, 15 + full + 3 * canonical
    return 20 + m, 20 + full + 3 * canonical


def examples() -> list[Term]:
    large = chi(chi(N, N), chi(N, A))
    frozen = S(Q(S(V), W))
    return [ZERO, A, N, S(N), chi(N, A), SEED_BIT, SEED_PARTITION,
            local_mark(ZERO), local_mark(N), rooted_mark(ZERO), rooted_mark(N),
            Z(chi(N, ZERO), local_mark(A)), Q(S(large), A),
            Q(S(Q(S(N), A)), A), R(frozen, N, A)]


def finite_terms(max_size: int = 6) -> list[Term]:
    """Exhaustive active trees in {0,n,a,S,chi,Q,Z}, up to max_size."""
    by_size: dict[int, list[Term]] = {1: [ZERO, N, A]}
    for size in range(2, max_size + 1):
        current = [S(t) for t in by_size[size - 1]]
        for left_size in range(1, size - 1):
            right_size = size - left_size - 1
            for t in by_size[left_size]:
                for u in by_size[right_size]:
                    current.extend((chi(t, u), Q(t, u), Z(t, u)))
        by_size[size] = current
    return [t for size in by_size for t in by_size[size]]


def random_terms(seed: int = 20261102, count: int = 700) -> list[Term]:
    rng = random.Random(seed)
    bodies = [V, W, ZERO, S(V), chi(V, W), S(Q(S(V), W)), R(S(V), W, V)]

    def make(depth: int) -> Term:
        if depth == 0 or rng.randrange(5) == 0:
            return rng.choice((ZERO, N, A))
        kind = rng.randrange(7)
        if kind == 0:
            return S(make(depth - 1))
        left, right = make(depth - 1), make(depth - 1)
        if kind == 1:
            return chi(left, right)
        if kind == 2:
            return Q(left, right)
        if kind == 3:
            return Z(left, right)
        return R(rng.choice(bodies), left, right)

    result: list[Term] = []
    for _ in range(count):
        t = make(rng.randrange(1, 5))
        result.extend((t, local_mark(t), rooted_mark(t), Q(S(t), A)))
    return result


def check_syntax() -> dict:
    assert counts(BIT) == (18, 18)
    assert counts(PARTITION) == (12, 12)
    assert counts(OLD_SEED) == (25, 25)

    # Frozen descriptors and root-only normalization are independently tested.
    frozen = S(Q(S(V), W))
    active = R(frozen, N, A)
    changed = substitute(active, {"n": S(A), "a": N, "v": ZERO, "w": ZERO})
    assert changed.descriptor == frozen
    assert changed.args == (S(A), N)
    assert occurrences(active, "n") == 1
    assert free_variables(active) == {"n", "a"}
    assert nf(S(Q(S(N), A))) == S(Q(S(N), A))
    assert nf(R(frozen, Q(S(N), A), A)) == R(frozen, Q(S(N), A), A)
    assert nf(Q(S(Q(S(N), A)), A)) == N

    terms = list(dict.fromkeys(examples() + finite_terms() + random_terms()))
    branches: Counter[str] = Counter()
    strict_both = 0
    source_names = ("boundary", "local", "rooted", "local broad option")
    recovery_count = 0
    for t in terms:
        assert free_variables(t) <= {"n", "a"}
        assert nf(nf(t)) == nf(t)
        assert weight(nf(t)) <= weight(t)
        assert weight(nf(t), True) <= weight(t, True)
        assert nf(at(t, V, W)) == at(nf(t), V, W)
        for mode in ("left", "right", "bound"):
            f = computation(t, mode)
            assert counts(f) == expected_computation_counts(t, mode)
            assert not free_variables(f)
        name, current = new_emitter(t)
        branches[name] += 1
        assert not free_variables(current)
        if name == "predecessor return":
            assert counts(current) == (16, 18 + 2 * weight(t, True))
        older = [old_emitter(t, source)[1] for source in source_names]
        for f in older:
            assert not free_variables(f)
        minima = tuple(min(counts(f)[axis] for f in older) for axis in (0, 1))
        actual = counts(current)
        assert all(actual[axis] <= minima[axis] for axis in (0, 1)), (show(t), actual, minima)
        strict_both += int(all(actual[axis] < minima[axis] for axis in (0, 1)))

        # An unmarked raw projection alias selects the same actual recursor.
        # At t=n the separately retained right equation already is its left
        # equation, so the exceptional bit-seed alias is not used.
        if t != N:
            alias = Q(S(t), A)
            alias_branch, _ = new_emitter(alias)
            assert alias_branch in {"left computation", "bound computation"}
            assert descriptor(alias) == descriptor(t)
            # The exposed RHS reduces by Q(S(r),s)=r in one root step.
            raw_rhs = at(alias, R(descriptor(t), N, A), N)
            assert raw_rhs.op == "R" and raw_rhs.descriptor == W
            assert raw_rhs.args[0].op == "S"
            assert raw_rhs.args[0].args[0] == at(t, R(descriptor(t), N, A), N)
            recovery_count += 1

    assert set(branches) == {"bit seed", "partition seed", "predecessor return",
                            "right computation", "bound computation", "left computation"}
    explicit = []
    for t in examples():
        branch, f = new_emitter(t)
        baseline = {name: list(counts(old_emitter(t, name)[1])) for name in source_names}
        explicit.append({"input": show(t), "m": weight(t), "W": weight(t, True),
                         "V": weight(nf(t), True), "i": occurrences(t, "n"),
                         "j": occurrences(t, "a"), "new_branch": branch,
                         "new_counts": list(counts(f)), "baseline_counts": baseline,
                         "formula": show(f)})
    return {"input_count": len(terms), "branch_counts": dict(branches),
            "strict_in_both_counts": strict_both, "alias_recoveries": recovery_count,
            "exhaustive_max_active_size": 6, "random_seed": 20261102,
            "frozen_substitution": "passed", "root_normalization": "passed",
            "closed_form_counts": "passed", "closed_axioms": "passed",
            "pointwise_comparison_on_test_set": "passed", "examples": explicit}


def q_value(counter: int, initial: int) -> int:
    return initial if counter == 0 else counter - 1


def selected_index(f: tuple[bool, ...], witness: int, target: int) -> int:
    bit = int(f[witness])
    return q_value(q_value(bit, witness), target)


def check_witnesses(length: int = 12) -> dict:
    """Every Boolean trajectory of this length with F(0)=true.

    d(0)=0 and d(n+1)=n+1 if F(d(n)), else d(n), is the actual
    primitive-recursive first-failure witness used in the written proof.
    The test also checks the local progress argument without assuming a
    global finite trajectory is closed under successor.
    """
    trajectories = targets = local_progress_cases = 0
    true_branch = false_branch = 0
    for tail in itertools.product((False, True), repeat=length - 1):
        f = (True,) + tail
        trajectories += 1
        d = 0
        for target in range(length):
            if target:
                d = target if f[d] else d
            invariant = (f[d] and d == target) or (d != 0 and not f[d] and f[d - 1])
            assert invariant
            chosen = selected_index(f, d, target)
            assert 0 <= chosen < length and f[chosen]
            assert d <= target
            if f[d]:
                assert chosen == target
                true_branch += 1
            else:
                assert chosen == d - 1
                false_branch += 1
            targets += 1

            for b in range(length):
                selected = selected_index(f, b, target)
                # If b is false and nonzero, a witness at its predecessor
                # conflicts with progress across precisely that edge.
                if not f[b]:
                    assert b > 0
                    assert selected == b - 1
                    progress = (not f[b - 1]) or f[b]
                else:
                    assert selected == target
                    progress = True
                if f[selected] and progress:
                    assert f[target]
                    local_progress_cases += 1

    # A guard against accidentally counting a shift in the new selector.
    # False at b=1 selects 0; true at any b selects the requested n.
    assert selected_index((True, False, True), 1, 2) == 0
    assert selected_index((True, False, True), 2, 1) == 1
    return {"trajectory_length": length, "boolean_trajectories": trajectories,
            "target_checks": targets, "true_witness_branch": true_branch,
            "false_witness_branch": false_branch,
            "local_progress_implication_checks": local_progress_cases,
            "primitive_recursive_witness_invariant": "passed",
            "scope": "Finite Boolean trajectories on standard natural indices; not a model-theoretic proof."}


def check_partition(limit: int = 100) -> dict:
    def bit(x: int, y: int) -> int:
        return int(x == y)
    for x in range(limit + 1):
        y = 0 if x == 0 else x - 1
        assert bit(x, 0) != bit(x, y + 1)
        assert x == 0 or x == y + 1
    # If zero and one are identified, all values fixed by K are identical;
    # no two such values can satisfy the partition's disequality.
    collapsed_bit_values = (0, 0)
    assert all(x == y for x in collapsed_bit_values for y in collapsed_bit_values)
    return {"standard_values_checked": limit + 1,
            "explicit_partition_witness": "y=0 at x=0, y=x-1 otherwise",
            "status": "passed", "scope": "Sanity check of the PRA interpretation; see written arbitrary-carrier proof."}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("verification_results.json"))
    args = parser.parse_args()
    result = {"status": "passed", "python": platform.python_version(),
              "scope": "Executable syntax accounting and finite semantic checks only; no claim of a complete machine proof.",
              "syntax": check_syntax(), "witnesses": check_witnesses(),
              "partition": check_partition()}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "inputs": result["syntax"]["input_count"],
                      "branches": result["syntax"]["branch_counts"],
                      "strict_both": result["syntax"]["strict_in_both_counts"],
                      "trajectory_targets": result["witnesses"]["target_checks"],
                      "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
