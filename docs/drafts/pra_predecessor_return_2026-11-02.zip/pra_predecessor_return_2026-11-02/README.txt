PRA FROM PREDECESSOR RETURN WITNESSES
Prepared for Vladimir Reshetnikov, November 2, 2026

MAIN RESULT
The fully specified first-order theory has a common conservative
definitional extension with PRA, hence full-carrier bi-interpretations
with identity composites and syntactic equiconsistency. The proof works
separately in classical and intuitionistic logic.

The new induction replacement has 16 active syntax nodes and 18+2W fully
charged nodes. Its matrix is one equality, with no successor occurrence.
A 12-node equality-bit partition sentence supplies both separation and
zero-or-successor coverage. The six-case emitter is pointwise no larger
than the actual current lower envelope of all three same-language scalar
drafts, in both their tree-size measures. It improves both existing seed
positions and all canonical inputs containing n other than literal n. Some
computation inputs tie.

This is not a claim of a globally shortest axiomatization across languages.
Fixed arithmetic increases from 25 to 30 nodes, and the emitter has six
cases. The fourth current draft uses a different autonomous grammar;
the report distinguishes matched profile comparisons from literal ones.

START HERE
  report.pdf          Complete mathematical report and proofs.
  report.tex          LaTeX entry point.
  sections/*.tex      Full source, including Further research questions.
  AXIOMS.txt          Exact machine-independent specification.

VERIFICATION
  formal/PredecessorReturn.lean  Nine checked mathematical kernels.
  formal/SCOPE.txt              What is and is not formalized.
  formal/lean_output.txt        Actual successful Lean output.
  formal/verification.json      Compiler version and source hash.
  checks/check_syntax_and_witnesses.py  Actual AST and finite witness checks.
  checks/verification_results.json     Recorded results and examples.
  verification/                Build and review records.
  provenance/source_manifest.json     Pinned source archives and hashes.
  SHA256SUMS                   Hashes of deliverable files.

REBUILD
  python3 build.py
Requires Python 3 and pdflatex (standard TeX Live). The mathematical Python
checks use only the standard library.

To repeat the Lean kernel check with Lean 4.19.0:
  lean formal/PredecessorReturn.lean

The full bi-interpretability theorem is proved in writing, not fully
formalized in Lean. Finite syntax/trajectory tests supplement the general
proofs; they do not replace them.

SOURCE SNAPSHOT
VladimirReshetnikov/ProveIt
53f59452ff3340cfdff9b1ac34c80d14ee2ce1b4
Four ZIP archives under docs/drafts, downloaded and inspected.
