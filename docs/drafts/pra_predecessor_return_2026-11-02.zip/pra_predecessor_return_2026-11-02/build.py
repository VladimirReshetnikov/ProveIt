#!/usr/bin/env python3
"""Reproduce the executable checks and compile report.pdf. No Python packages required."""
from pathlib import Path
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "verification"
OUT.mkdir(exist_ok=True)

def run(command, log_name):
    result = subprocess.run(command, cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUT / log_name).write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        print(result.stdout[-6000:])
        raise SystemExit(f"Failed ({result.returncode}): {' '.join(command)}")
    return result.returncode

if not shutil.which("pdflatex"):
    raise SystemExit("pdflatex is required (a standard TeX Live installation suffices).")
run([sys.executable, "checks/check_syntax_and_witnesses.py"], "python_checks.txt")
for iteration in range(1, 4):
    run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
        f"latex_pass_{iteration}.txt")
log = (ROOT / "report.log").read_text(errors="replace")
problems = [line for line in log.splitlines()
            if "Overfull" in line or "undefined" in line.lower()
            or "multiply defined" in line.lower()]
result = {"pdf_created": (ROOT / "report.pdf").is_file(),
          "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
          "latex_passes": 3, "layout_or_reference_warnings": problems,
          "lean_scope": "Separate compiler check; see formal/verification.json."}
(OUT / "build_results.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
if problems:
    raise SystemExit("Inspect the recorded LaTeX warnings before delivery.")
