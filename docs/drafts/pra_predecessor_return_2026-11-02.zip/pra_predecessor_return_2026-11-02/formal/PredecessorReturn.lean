import Std

/-!
Arbitrary-carrier logical kernels for predecessor-return arithmetic.
No model-theoretic completeness, syntax compiler, or bi-interpretation is
formalized here. See SCOPE.txt for the exact verification boundary.
-/

namespace PredecessorReturn

universe u
variable {A : Type u}

theorem partition_separation
    (z : A) (s : A → A) (chi : A → A → A)
    (diag : ∀ x, chi x x = s z)
    (off : ∀ x y, x = y ∨ chi x y = z)
    (partition : ∀ x, ∃ y, chi x z ≠ chi x (s y)) :
    z ≠ s z := by
  intro hz
  obtain ⟨y, hy⟩ := partition z
  rcases off z (s y) with heq | hzero
  · exact hy (congrArg (chi z) heq)
  · apply hy
    calc
      chi z z = s z := diag z
      _ = z := hz.symm
      _ = chi z (s y) := hzero.symm

theorem partition_coverage
    (z : A) (s : A → A) (chi : A → A → A)
    (off : ∀ x y, x = y ∨ chi x y = z)
    (partition : ∀ x, ∃ y, chi x z ≠ chi x (s y)) :
    ∀ x, x = z ∨ ∃ y, x = s y := by
  intro x
  obtain ⟨y, hy⟩ := partition x
  rcases off x z with hx | hzero
  · exact Or.inl hx
  · rcases off x (s y) with hs | hother
    · exact Or.inr ⟨y, hs⟩
    · exact False.elim (hy (hzero.trans hother.symm))

theorem explicit_coverage
    (z : A) (s : A → A) (Q : A → A → A)
    (qs : ∀ x a, Q (s x) a = x)
    (coverage : ∀ x, x = z ∨ ∃ y, x = s y) :
    ∀ x, x = z ∨ x = s (Q x z) := by
  intro x
  rcases coverage x with hx | ⟨y, hy⟩
  · exact Or.inl hx
  · right
    subst x
    rw [qs]

theorem successor_nonzero
    (z : A) (s : A → A) (Q : A → A → A)
    (qz : ∀ a, Q z a = a)
    (qs : ∀ x a, Q (s x) a = x)
    (sep : z ≠ s z) :
    ∀ x, s x ≠ z := by
  intro x hx
  have h := congrArg (fun t => Q t z) hx
  dsimp only at h
  rw [qs, qz] at h
  subst x
  exact sep hx.symm

theorem chi_zero_excludes_equality
    (z : A) (s : A → A) (chi : A → A → A)
    (diag : ∀ x, chi x x = s z)
    (sep : z ≠ s z) :
    ∀ x y, chi x y = z → x ≠ y := by
  intro x y hxy heq
  subst y
  exact sep (hxy.symm.trans (diag x))

theorem partition_converse
    (z : A) (s : A → A) (chi : A → A → A)
    (diag : ∀ x, chi x x = s z)
    (off : ∀ x y, x = y ∨ chi x y = z)
    (sep : z ≠ s z)
    (snonzero : ∀ x, s x ≠ z)
    (coverage : ∀ x, x = z ∨ ∃ y, x = s y) :
    ∀ x, ∃ y, chi x z ≠ chi x (s y) := by
  intro x
  rcases coverage x with hx | ⟨y, hxy⟩
  · subst x
    refine ⟨z, ?_⟩
    have hchi : chi z (s z) = z := by
      rcases off z (s z) with heq | hzero
      · exact False.elim (sep heq)
      · exact hzero
    rw [diag, hchi]
    exact Ne.symm sep
  · refine ⟨y, ?_⟩
    have hxzero : x ≠ z := by
      rw [hxy]
      exact snonzero y
    have hleft : chi x z = z := by
      rcases off x z with heq | hzero
      · exact False.elim (hxzero heq)
      · exact hzero
    have hright : chi x (s y) = s z := by
      rw [← hxy]
      exact diag x
    rw [hleft, hright]
    exact sep

/-- The 16-active-node witness implies return everywhere under progress. -/
theorem predecessor_return_elimination
    (z : A) (s : A → A) (Q chi : A → A → A)
    (f : A → A) (a : A)
    (qz : ∀ c, Q z c = c)
    (qs : ∀ x c, Q (s x) c = x)
    (diag : ∀ x, chi x x = s z)
    (off : ∀ x y, x = y ∨ chi x y = z)
    (sep : z ≠ s z)
    (coverage : ∀ x, x = z ∨ ∃ y, x = s y)
    (base : f z = a)
    (witness : ∀ n, ∃ b, f (Q (Q (chi (f b) a) b) n) = a)
    (progress : ∀ n, f n = a → f (s n) = a) :
    ∀ n, f n = a := by
  intro n
  obtain ⟨b, hb⟩ := witness n
  rcases off (f b) a with hreturn | hzero
  · have hchi : chi (f b) a = s z := by
      rw [hreturn]
      exact diag a
    rw [hchi, qs, qz] at hb
    exact hb
  · have hnot : f b ≠ a :=
      chi_zero_excludes_equality z s chi diag sep (f b) a hzero
    rcases coverage b with hbzero | ⟨k, hbk⟩
    · subst b
      exact False.elim (hnot base)
    · subst b
      rw [hzero, qz, qs] at hb
      exact False.elim (hnot (progress k hb))

/-- Unshifted latch induction: coverage resolves the only missing case. -/
theorem latch_induction
    (z : A) (s : A → A) (Q chi R h : A → A → A)
    (P : A → A → Prop)
    (qz : ∀ c, Q z c = c)
    (qs : ∀ x c, Q (s x) c = x)
    (diag : ∀ x, chi x x = s z)
    (off : ∀ x y, x = y ∨ chi x y = z)
    (sep : z ≠ s z)
    (coverage : ∀ x, x = z ∨ ∃ y, x = s y)
    (rzero : ∀ c, R z c = c)
    (rstep : ∀ n c, R (s n) c = h (R n c) n)
    (reflection : ∀ v n b, h v n = s b ↔ v = s b ∧ P n b)
    (witness : ∀ a n, ∃ k,
      R (Q (Q (chi (R k a) a) k) n) a = a) :
    ∀ b, P z b → (∀ n, P n b → P (s n) b) → ∀ n, P n b := by
  intro b pzero pstep
  have return_implies : ∀ n, R n (s b) = s b → P n b := by
    intro n hn
    rcases coverage n with hnzero | ⟨m, hnm⟩
    · subst n
      exact pzero
    · subst n
      rw [rstep] at hn
      exact pstep m ((reflection (R m (s b)) m b).mp hn).2
  have return_progress : ∀ n,
      R n (s b) = s b → R (s n) (s b) = s b := by
    intro n hn
    rw [rstep]
    exact (reflection (R n (s b)) n b).mpr
      ⟨hn, return_implies n hn⟩
  have all_return := predecessor_return_elimination z s Q chi
    (fun n => R n (s b)) (s b) qz qs diag off sep coverage
    (rzero (s b)) (witness (s b)) return_progress
  intro n
  exact return_implies n (all_return n)

def BoundaryInv (F : A → Prop) (s p c : A → A) (n : A) : Prop :=
  (F (c n) ∧ c n = n) ∨
  (¬ F (c n) ∧ F (p (c n)) ∧ c n = s (p (c n)))

/-- The reverse verification uses induction only for the displayed invariant. -/
theorem predecessor_return_converse
    (z : A) (s : A → A) (Q chi : A → A → A)
    (f c : A → A) (a : A)
    (qz : ∀ d, Q z d = d)
    (qs : ∀ x d, Q (s x) d = x)
    (diag : ∀ x, chi x x = s z)
    (off : ∀ x y, x = y ∨ chi x y = z)
    (decideF : ∀ n, f n = a ∨ f n ≠ a)
    (base : f z = a)
    (czero : c z = z)
    (ctrue : ∀ n, f (c n) = a → c (s n) = s n)
    (cfalse : ∀ n, f (c n) ≠ a → c (s n) = c n)
    (induction :
      BoundaryInv (fun n => f n = a) s (fun n => Q n z) c z →
      (∀ n, BoundaryInv (fun n => f n = a) s (fun n => Q n z) c n →
        BoundaryInv (fun n => f n = a) s (fun n => Q n z) c (s n)) →
      ∀ n, BoundaryInv (fun n => f n = a) s (fun n => Q n z) c n) :
    ∀ n, ∃ b, f (Q (Q (chi (f b) a) b) n) = a := by
  have inv0 : BoundaryInv (fun n => f n = a) s (fun n => Q n z) c z := by
    left
    rw [czero]
    exact ⟨base, rfl⟩
  have invstep : ∀ n,
      BoundaryInv (fun n => f n = a) s (fun n => Q n z) c n →
      BoundaryInv (fun n => f n = a) s (fun n => Q n z) c (s n) := by
    intro n hn
    rcases hn with ⟨hf, hcn⟩ | ⟨hnf, hprev, hcov⟩
    · have hc := ctrue n hf
      rcases decideF (s n) with hnext | hnext
      · left
        rw [hc]
        exact ⟨hnext, rfl⟩
      · right
        dsimp only
        rw [hc, qs]
        exact ⟨hnext, hcn ▸ hf, rfl⟩
    · have hc := cfalse n hnf
      right
      rw [hc]
      exact ⟨hnf, hprev, hcov⟩
  have invariant := induction inv0 invstep
  intro n
  refine ⟨c n, ?_⟩
  rcases invariant n with ⟨hf, hcn⟩ | ⟨hnf, hprev, hcov⟩
  · have hchi : chi (f (c n)) a = s z := by
      rw [hf]
      exact diag a
    rw [hchi, qs, qz]
    exact hcn ▸ hf
  · have hchi : chi (f (c n)) a = z := by
      rcases off (f (c n)) a with heq | hzero
      · exact False.elim (hnf heq)
      · exact hzero
    rw [hchi, qz]
    have hQ : Q (c n) n = Q (c n) z := by
      calc
        Q (c n) n = Q (s (Q (c n) z)) n := congrArg (fun x => Q x n) hcov
        _ = Q (c n) z := qs _ _
    rw [hQ]
    exact hprev

#print axioms partition_separation
#print axioms partition_coverage
#print axioms explicit_coverage
#print axioms successor_nonzero
#print axioms chi_zero_excludes_equality
#print axioms partition_converse
#print axioms predecessor_return_elimination
#print axioms latch_induction
#print axioms predecessor_return_converse

end PredecessorReturn
