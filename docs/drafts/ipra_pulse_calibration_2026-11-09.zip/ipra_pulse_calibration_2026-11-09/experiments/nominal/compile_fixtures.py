"""Untrusted compiler from the supplied flat certificates to proof trees.

This is deliberately outside the candidate's trusted source and measurement.
It records a successful trace of the inherited checker, erases failed probes,
and encodes the retained eigenparameters by proof-tree binding coordinates.
"""
import ast
import copy
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
FIXTURES = ROOT / 'source_fixtures.json'


class Trace:
    def __init__(self, packet):
        self.packet = copy.deepcopy(packet)
        self.k = 0

    def i(self, a, t=None, d=0):
        try:
            return [self.i(b, t, d + b' \2\1\4'[len(a)]) for b in a + []]
        except Exception:
            return a if self.k <= a < d else d % 2 and self.i(t, d=1)

    def c(self, a, g, s=0):
        if self.i(a) in g:
            return True, {'mode': 'hyp'}
        m, t = self.packet.pop()
        node = {'major': copy.deepcopy(m), 'payload': copy.deepcopy(t)}
        ok, major = self.c(m, g) if m else (False, None)
        if m and ok:
            node['major_proof'] = major
            h = [0, m[2:]]
            if [] in h:
                u = t
                try:
                    t, = m
                    node['mode'] = 'closure'
                except Exception:
                    s, u = m
                    node['mode'] = 'transport'
                if self.i(t, u) != a:
                    return False, node
                ok, node['minor_proof'] = self.c(self.i(t, s), g)
                return ok, node
            node['mode'] = 'elimination'
        elif t:
            node['major'] = 0
            node['mode'] = 'introduction'
            a = self.i(a[2], t, 2)
            h = [len(a) % 2 or a, self.i(a, 0)]
        else:
            node['major'] = 0
            node['mode'] = 'computation'
            (n, t, r), b = a
            if n:
                n, = n
                t = self.i(r, [n, t, r], 1)
            return b == t, node
        self.k -= 1
        node['fresh'] = self.k
        ok, node['minor_proof'] = self.c(
            self.i(a, [self.k]), g + self.i(h, self.k, -1))
        return ok, node


OFF = [0, 2, 1, 4]


def syntax(a, env, d=0, motive=False):
    """Encode current eigenparameters; canonicalize a motive's exposed slots.

    env[k] is the proof-path depth from the binder opening k to this
    field. d is the native-syntax depth, excluding that proof-path depth.
    """
    if type(a) is list:
        return [syntax(x, env, d + OFF[len(a)], motive) for x in a]
    if type(a) not in (int, float, bool):
        raise ValueError('Only canonical array/numeric fixtures are compiled')
    if a < 0:
        return env[a] + d if a in env else 0
    if motive and a >= d:
        return d if d % 2 else 0
    return a


def add(env, n):
    return {k: v+n for k, v in env.items()}


def proof(node, env):
    mode = node['mode']
    if mode == 'hyp':
        return 0
    major = syntax(node['major'], add(env, 4))
    if mode == 'transport':
        payload = [syntax(node['payload'], add(env, 6), motive=True)]
    elif mode in ('closure', 'introduction'):
        # The d=1 numerical root is supplied by the wrapper's +1.
        payload = [syntax(node['payload'], add(env, 4), d=1), 0]
    else:
        payload = [0]
    child_env = add(env, 8)
    major_proof = proof(node['major_proof'], child_env) if 'major_proof' in node else 0
    minor_env = dict(child_env)
    if 'fresh' in node:
        minor_env[node['fresh']] = 0
    minor_proof = proof(node['minor_proof'], minor_env) if 'minor_proof' in node else 0
    return [major, payload, [major_proof, minor_proof, 0]]


def load_kernel():
    module = ast.parse((ROOT / 'nominal_checker.py').read_text())
    module.body = [x for x in module.body if isinstance(x, ast.FunctionDef)]
    scope = {}
    exec(compile(module, str(ROOT / 'nominal_checker.py'), 'exec'), scope)
    return scope


def main():
    records = json.loads(FIXTURES.read_text())['records']
    nominal = load_kernel()
    compiled = []
    failures = []
    for record in records:
        trace = Trace(record['packet'])
        goal = trace.packet.pop()
        ok, tree = trace.c(goal, [])
        if not ok:
            raise RuntimeError('Inherited fixture rejected: '+record['id'])
        candidate = [proof(tree, {}), goal]
        try:
            accepted = bool(nominal['c'](goal, [], candidate[0]))
            error = None
        except Exception as exc:
            accepted = False
            error = type(exc).__name__+': '+str(exc)
        compiled.append({'id':record['id'], 'name':record['name'], 'packet':candidate})
        if not accepted:
            failures.append({'id':record['id'], 'name':record['name'], 'error':error})
    (ROOT / 'compiled_fixtures.json').write_text(json.dumps({'records':compiled}, indent=2)+'\n')
    receipt = {'source_fixture_count':len(records), 'accepted':len(records)-len(failures),
               'failures':failures, 'scope':'Finite replay of a syntactic proof compiler; no universal soundness claim.'}
    (ROOT / 'fixture_results.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__ == '__main__':
    main()
