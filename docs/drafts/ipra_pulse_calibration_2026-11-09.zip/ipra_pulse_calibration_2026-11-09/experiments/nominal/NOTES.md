# Generative eigenparameters: a larger experimental kernel

## Result

This experiment removes the global freshness floor from the inherited native
checker. It replaces it with freshly allocated, opaque numerical atoms and
opens the complete continuation proof when an eigenparameter is introduced.
The resulting complete source is **338 normalized tokens, 380 AST nodes, and
912 normalized bytes** under the inherited normalizer. It is therefore larger
than the current 306-token/340-node frontier and larger than the separate
839-byte coordinate minimum. It is not a new smallest checker.

The untrusted compiler successfully translated all 147 inherited positive
certificates. They were replayed by the actual command-line checker. Additional
false-goal, malformed-input, and known overlong-major attacks are in the
validation receipt. These finite checks are useful evidence; they are not a
formal proof of universal soundness or bi-interpretability. The candidate is
kept as an explicitly experimental alternative, not the report's certified
axiomatization.

## Why simply replacing an integer by `object()` does not work

Fresh allocation immediately solves one problem: the new atom cannot already
occur in the goal, context, witness, or previously parsed data. It creates
another: a later JSON certificate cell cannot name that object. A flat packet
therefore needs either an environment mapping names to generated atoms or an
operation that opens a scoped continuation. The present experiment pays for
the latter. The extra proof structure and continuation opening more than offset
the deleted counter and lower-bound checks.

The tempting context-length replacement also has an actual obstruction. If
`x = ~len(g)` and the scalar guard is `x < a < d`, the trusted fresh variable
`x` itself fails the existing image revalidation in `i(t, d=1)`. It cannot
simply replace the old counter while leaving that operation unchanged.
Relaxing the guard to admit `x` in arbitrary untrusted data would abandon the
freshness argument. A local floor update or a distinct trusted insertion path
would have to be implemented and counted.

## Native mathematical theory

The experiment does not change the inherited theory. Its mathematical formulas
are equations and paired binders

    D_{x,y} B  =  exists x (B(x,0) -> forall y B(x,y)).

The local closure Q is an internal context form. The primitive rules are the
inherited computation equations, hypothesis, paired introduction, paired
elimination, closure specialization, and equality transport. Paired introduction
retains an induction assumption only when the matrix is literally an equation.
The experiment neither removes the induction/cases distinction nor derives a
new arithmetic schema.

## Concrete certificate grammar

The input is `[proof, closed_goal]`. A hypothesis proof may be the scalar zero
because hypothesis membership is checked before the proof node is inspected.
Every other canonical proof node has the shape

    [major, packed_payload, [major_proof, minor_proof, 0]].

The major and the actual payload carry the inherited instruction meanings.
An equality-transport motive is packed as `[formula]`. A numerical witness or
closure target is packed as `[term, 0]`. An unused payload is packed as `[0]`.
The inference function reads only the first member of the payload wrapper.
The wrapper's arity also determines its binding depth during continuation
opening. Unread payload padding is not an axiom or an external oracle.

The original structural operation `i` is retained with its arity offsets:

| Node arity | Added depth |
| --- | ---: |
| 0 | No recursive children |
| 1 | 2 |
| 2 | 1 |
| 3 | 4 |

Arrays longer than three, when traversed by `i`, fail. Strings and maps do not
enter its array traversal. The exception branch only retains a fresh opaque
object or a numerical coordinate in the protected interval. In particular,
an overlong array does not become an arbitrary atom after its lookup fails.

At a paired introduction or elimination, the kernel performs

    x = object()
    c(i(a, [x]), g + i(h, x, -1), i(minor_proof, x)).

The same fresh object is thus inserted into the next goal, its local assumptions,
and the scoped continuation proof. Numerical occurrences of earlier objects
are retained unchanged. Objects at formula-sort padding positions have the
same harmless truth reading as the inherited scalar padding.

## Scope argument

Python's ordinary JSON parser returns arrays, mappings, strings, numerical
scalars, booleans, and null. It cannot return a value whose exact type is
`object`. The only source of those atoms is the single explicit allocation
in the checker. Each allocation creates an object different from every existing
object; equality between these objects is identity. They have no mutable
payload that certificate data can alter.

Consequently a newly generated atom is absent from every existing syntax tree,
including the selected witness and retained context. This establishes the
eigenparameter freshness condition without a scan or a numerical floor.
The original sorted common-motive argument extends by treating each opaque
object as a free numerical parameter: substitution leaves it unchanged, and
inserting it under another numerical binder does not capture it.

Continuation opening is not itself a theorem-producing rule. It selects the
data that a recursive proof check subsequently inspects. Regardless of how an
untrusted packet's metadata is transformed, every successful recursive check
must still pass the same native logical or computation inference as the
inherited checker. The three-element paired introduction test remains in place;
the literal-equation induction boundary is unchanged. The major premise's
formula still passes the initial traversal, so the existing four-element-major
attack is blocked.

A complete success-trace proof would induct on the recursively checked proof
tree, use the existing sorted-decoder/common-motive lemmas, and add exactly the
fresh-object case above. No acceptance decision depends on the untrusted
compiler. This note records that route and its essential invariants; the
archive does not describe the Python source as a Lean/Rocq-verified kernel.

## Canonical proof compiler

`compile_fixtures.py` records the successful branch of the original flat-packet
checker, preserving all logical premises and dropping unsuccessful probes.
It then gives every still-active eigenparameter a proof-local binding
coordinate. The proof's structural depth supplies its coordinate:

* Entering a proof node contributes four.
* Entering its three-element premise container contributes another four.
* A numerical payload wrapper contributes one.
* A formula-motive wrapper contributes two.
* Ordinary term/formula children retain the inherited arity offsets.

At the root of the continuation that introduces an eigenparameter, its depth is
reset to zero. Along a meaningful numerical occurrence, the inserted coordinate
equals the traversal depth from that opening point. Therefore the opening
operation replaces that occurrence by the new object. More deeply bound
parameters use nearer protected coordinates, and existing outer parameters
have already become opaque objects.

Equality-transport templates may use arbitrarily high exposed coordinates in
the flat format. Before wrapping such a motive, the compiler normalizes every
exposed numerical coordinate to the least coordinate with the same template
meaning. The singleton wrapper protects that one template hole while the
surrounding proof continuation is opened. Without that normalization, a large
coordinate such as 80 can be mistaken for a surrounding proof parameter.
This is a substantive part of the proposed canonical encoding, not an
optional presentation detail.

The delivered compiler accepts only the intended array/numeric fixtures; it
does not promise preservation of arbitrary malformed flat packets. The proof
tree interface is different. A full published canonical-completeness theorem
would prove the compiler invariants for arbitrary native derivations, including
all interactions of motive padding and nested paired binders. Successful replay
of the 147 supplied cases is not a substitute for that theorem.

## Termination and trusted size

The array traversal descends proper finite subtrees. Its insertion rechecks a
numerical image with no further image; a missing meaningful image rejects.
It does not recurse through the characters of a string. Opaque atoms contain
no children. The proof checker recurses through proper premise subtrees;
opening replaces scalar occurrences by atoms and cannot introduce a cycle or
additional proof nodes. Thus the proposed architecture has a structural
termination argument on finite JSON, without the iterable-string dependence
of one smaller reference implementation. Real interpreter resource bounds
remain ordinary execution limitations.

All parser, traversal, inference, fresh allocation, opening, and verdict code
is in `nominal_checker.py`. The compiler, test driver, and fixtures are outside
the trust base and outside its measured source. They are not called by the
checker. Nothing is dynamically executed from the input. The measured increase
is precisely why this architecture is not offered as meeting the user's
strict size target.

## Reproduction and provenance

The source fixtures and unchanged source normalizer are taken from

    baseline/ipra_package_reconstructed/ipra_reset_2026-11-08/

within ProveIt snapshot `572c3ef372fb22e30951af30bf1041efcffc8b7d`.
The source-normalizer hash and candidate source hash are in `validation.json`.
The parent report records the original archive's provenance and includes
attributed reference material. From the delivered package directory, run:

    python3 experiments/nominal/compile_fixtures.py
    python3 experiments/nominal/verify_nominal.py

These supporting scripts resolve their bundled fixtures and the unchanged
reference normalizer relative to this package. The candidate itself is
standalone and needs only Python's standard library.
