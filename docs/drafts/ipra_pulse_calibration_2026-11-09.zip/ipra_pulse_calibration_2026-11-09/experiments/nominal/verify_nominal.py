"""Finite public-interface checks and complete-source measurements.

This script is supporting evidence, not part of the candidate's trust base.
"""
import hashlib
import importlib.util
import json
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
NORMALIZER = ROOT.parents[1] / 'reference/source_measure.py'
KERNEL = ROOT / 'nominal_checker.py'


def run(packet, optimize=False, raw=False):
    cmd = [sys.executable] + (['-O'] if optimize else []) + [str(KERNEL)]
    data = packet if raw else json.dumps(packet)
    p = subprocess.run(cmd, input=data, text=True, capture_output=True, timeout=5)
    return (p.returncode, p.stdout, p.stderr)


def main():
    fixture = json.loads((ROOT/'compiled_fixtures.json').read_text())['records']
    passed = 0
    for optimize in (False, True):
        for record in fixture:
            if run(record['packet'], optimize) != (0, 'ACCEPT\n', ''):
                raise RuntimeError('Positive CLI failure: '+record['id'])
            passed += 1
    computation = [0, [0], [0, 0, 0]]
    contradiction = [[], [0]]
    attack_major = [0, 0, [], [0]]
    attack = [
        [attack_major, [0], [[0, [[0], 0], [0, 0, 0]], 0, 0]],
        contradiction,
    ]
    negatives = [('overlong-major attack', attack),
                 ('free negative parameter', [computation, [-1, -1]]),
                 ('dictionary cannot forge object atom', [computation, [{}, {}]]),
                 ('string cannot forge object atom', [computation, ['atom', 'atom']]),
                 ('null cannot forge object atom', [computation, [None, None]]),
                 ('overlong root', [computation, [0, 0, 0, 0]]),
                 ('false closed equation', [computation, contradiction]),
                 ('missing proof', [0, contradiction]),
                 ('malformed proof node', [[0, [0], []], contradiction])]
    negatives += [('false-goal mutation '+r['id'], [r['packet'][0], contradiction]) for r in fixture]
    rejected = 0
    for optimize in (False, True):
        for name, packet in negatives:
            if run(packet, optimize) != (1, 'REJECT\n', ''):
                raise RuntimeError('Negative CLI failure: '+name)
            rejected += 1
        for raw in ('', '{', '[NaN,', 'null', '[]'):
            if run(raw, optimize, raw=True) != (1, 'REJECT\n', ''):
                raise RuntimeError('Malformed input failure')
            rejected += 1
    spec = importlib.util.spec_from_file_location('source_measure', NORMALIZER)
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    receipt = {
        'status': 'Experimental candidate; no lower-frontier claim.',
        'python': platform.python_version(),
        'source_normalizer_sha256': hashlib.sha256(NORMALIZER.read_bytes()).hexdigest(),
        'complete_source_metrics': measure.metrics(KERNEL),
        'positive_public_runs': passed,
        'negative_public_runs': rejected,
        'positive_fixture_count': len(fixture),
        'negative_packet_count': len(negatives),
        'negative_categories': [name for name, _ in negatives[:9]],
        'scope': 'Finite checks of exact stdout, stderr, and exit status, in normal and optimized Python. These do not establish universal soundness or full iPRA bi-interpretability.',
    }
    (ROOT/'validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__ == '__main__':
    main()
