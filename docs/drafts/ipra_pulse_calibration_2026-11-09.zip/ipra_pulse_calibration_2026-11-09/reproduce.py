"""Reproduce the mathematical-fragment checks and matched complete comparison."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(arguments):
    command = [sys.executable, *arguments]
    process = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    if process.returncode:
        raise RuntimeError('Command failed: ' + ' '.join(arguments) + '\n' + process.stdout + process.stderr)
    return json.loads(process.stdout)


def main():
    producer = run(['code/make_pulse_certificate.py'])
    replay = run(['code/replay_pulse_certificate.py'])
    diagnostic = run(['code/validate_pulse.py'])
    for filename in ['validation_results.json', 'target_diagnostics.json']:
        shutil.move(str(ROOT/'code'/filename),str(ROOT/'evidence'/filename))
    (ROOT/'evidence/pulse_certificate_results.json').write_text(json.dumps(replay,indent=2)+'\n')
    generated = run(['code/expand_comparators.py'])
    measured = run(['code/measure.py'])
    tests = run(['code/test_checker.py','code/checker_baseline.py','code/checker_pulse.py'])
    (ROOT/'evidence/complete_checker_tests.json').write_text(json.dumps(tests,indent=2)+'\n')
    result = {'calibration': {'accepted':replay['accepted'],'proof_steps':replay['proof_steps'],
                             'reset_uses':replay['rules']['AR'],'BR_uses':replay['rules']['BR']},
              'diagnostics':diagnostic,
              'matched_complete_metrics':measured['matched_complete_checkers'],
              'matched_saving':measured['matched_saving'],
              'current_coordinate_minima':measured['coordinate_minima'],
              'pulse_below_entire_envelope':measured['pulse_below_entire_envelope'],
              'checker_tests':tests}
    (ROOT/'evidence/reproduction.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
