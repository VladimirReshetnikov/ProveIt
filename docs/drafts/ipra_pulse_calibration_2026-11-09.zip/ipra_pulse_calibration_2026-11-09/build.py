"""Build the supplied manuscript and its portable single-file LaTeX source."""
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def flatten(path, seen=()):
    path = path.resolve()
    if path in seen or not path.is_relative_to(ROOT):
        raise ValueError('Invalid or cyclic LaTeX input')
    source = path.read_text()
    def include(match):
        child = ROOT / match.group(1)
        if not child.suffix:
            child = child.with_suffix('.tex')
        return '\n% Included from ' + str(child.relative_to(ROOT)) + '\n' + flatten(child, seen + (path,))
    return re.sub(r'\\input\{([^}]+)\}', include, source)


def main():
    (ROOT/'report_standalone.tex').write_text(flatten(ROOT/'report.tex'))
    build = ROOT/'build'
    build.mkdir(exist_ok=True)
    commands = []
    for turn in range(3):
        command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                   '-file-line-error', '-output-directory', 'build', 'report.tex']
        result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
        (build/('pass_' + str(turn + 1) + '.txt')).write_text(result.stdout + result.stderr)
        commands.append({'pass':turn+1,'returncode':result.returncode})
        if result.returncode:
            raise RuntimeError('pdfLaTeX failed; see build/pass_' + str(turn+1) + '.txt')
    shutil.copy2(build/'report.pdf', ROOT/'ipra_pulse_calibration.pdf')
    log = (build/'report.log').read_text(errors='replace')
    result = {'commands':commands, 'pdf':'ipra_pulse_calibration.pdf',
              'standalone_source':'report_standalone.tex',
              'undefined_references':bool(re.search(r'(Reference|Citation).*undefined',log)),
              'overfull_boxes':[line for line in log.splitlines() if 'Overfull' in line],
              'output_line':next((line for line in log.splitlines() if line.startswith('Output written')),None)}
    (ROOT/'evidence/build.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
