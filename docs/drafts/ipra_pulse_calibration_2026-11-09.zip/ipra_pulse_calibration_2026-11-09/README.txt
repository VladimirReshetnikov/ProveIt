A TRANSIENT EQUALITY PULSE FOR iPRA
==================================
Prepared for Vladimir Reshetnikov, 9 November 2026.

RESULT AND LIMITATION
---------------------
This package gives a new closed-iteration axiomatization proved
equiconsistent and whole-domain bi-interpretable with full first-order
intuitionistic primitive recursive arithmetic.

The mathematical advance is a generic calibration of a raw Boolean
comparator, requiring neither a pre-established diagonal nor a separating
endpoint, and a single transient equality pulse. The fixed detector shrinks
from 182 expanded numerical syntax nodes to 70. Its two argument
multiplicities decrease from two each to one each.

The complete matched ordinary checkers have exactly the same engine and
differ only in their fully expanded fixed comparator:

                              normalized tokens / AST nodes / bytes
  checker_baseline.py                3247 / 3327 / 8874
  checker_pulse.py                   2743 / 2963 / 7950
  saving                              504 /  364 /  924

THIS DOES NOT BEAT THE ENTIRE CURRENT COMPLETE-CHECKER CORPUS.
Its actual literal coordinate envelope is 306 / 340 / 839, attained by
different native programs. No absolute simplest axiomatization, global
minimality theorem, or new overall record is claimed.

START HERE
----------
ipra_pulse_calibration.pdf   Complete report, proofs, comparison and appendices.
report_standalone.tex        Complete source in one LaTeX file.
report.tex + sections/       Organized manuscript source.

The report explicitly specifies all logical and nonlogical axioms, schemas,
inference rules, freshness conditions, both interpretations and both
composite isomorphisms. The inherited whole-domain compiler from closed
iteration to primitive recursion is reproduced and attributed.

REPRODUCTION
------------
From this directory:

  python3 reproduce.py
  python3 build.py

The first command needs only Python's standard library. It regenerates the
finite proof certificate, replays it, runs negative mutations and numerical
diagnostics, expands the comparator literals, checks the matched engine
identity, remeasures the 22 frozen complete comparison programs, and tests
both complete ordinary checkers. CPython 3.12.14 was used for the recorded
AST and source normalization. Other versions may format source differently.

The second command needs pdfLaTeX and the standard packages listed in the
manuscript preamble. The already compiled PDF is supplied.

For a direct complete-checker invocation, pass a JSON theorem packet on
standard input. The syntax and every proof instruction are documented in
code/CHECKER.md. The packet must have exactly context, goal and proof keys;
context is empty and goal is closed. Success prints ACCEPT with exit 0;
failure prints REJECT with exit 1. Resource limits can reject large valid
proofs. No imported producer, verifier or evaluator belongs to these kernels.

VERIFICATION SCOPE
------------------
code/pulse_certificate.json is an explicit 1,880-step symbolic proof of the
new spike and diagonal calibration: one AR inference and three BR instances.
The separate fragment replayer checks definitions, literal computation,
equality/logical rules, dependency discharge and exact AR freshness. It has
no induction, coverage, clock or equality-reflection oracle. Eight mutated
certificates reject. This is not a Lean/Rocq formalization of the entire
bi-interpretability theorem, and the fragment replayer is not the complete
checker being measured.

Each complete ordinary checker passed 22 positive and 25 negative packets,
102 normal/-O subprocess observations and two substitution contracts. The
exact target orbit was also diagnosed on 63 numeral pairs, with 24 pairs
checked using literal successor iteration. Numerical checks supplement the
written equation-induction proof; they do not prove arbitrary-domain claims.

PROVENANCE
----------
Baseline: VladimirReshetnikov/ProveIt, docs/drafts, commit
572c3ef372fb22e30951af30bf1041efcffc8b7d (12 archives).
evidence/repository_snapshot.json gives Git blob IDs and archive hashes.
reference/checkers_manifest.json identifies the 22 frozen complete programs.
evidence/measurements.json contains remeasured complete-source metrics.
ATTRIBUTION.txt distinguishes inherited proofs/software from new work.
MANIFEST.json records package file hashes.

OPTIONAL UNSUCCESSFUL EXPERIMENT
-------------------------------
experiments/nominal/ contains a generative-eigenparameter alternative to the
native kernel. It is larger: 338 / 380 / 912. Its finite test evidence is
included, but its generic proof-tree compiler metatheory is experimental.
It is not used to establish the proposed theory's equivalence.

To repeat that separate experiment:

  python3 experiments/nominal/compile_fixtures.py
  python3 experiments/nominal/verify_nominal.py
