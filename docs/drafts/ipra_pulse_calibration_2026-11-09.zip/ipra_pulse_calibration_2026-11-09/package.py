"""Hash and package the complete deliverable, excluding disposable build files."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent


def included(path):
    relative = path.relative_to(ROOT)
    return (path.is_file() and 'build' not in relative.parts
            and '__pycache__' not in relative.parts
            and path.suffix not in {'.pyc', '.pyo'}
            and relative.as_posix() != 'MANIFEST.json')


def main():
    files = sorted(path for path in ROOT.rglob('*') if included(path))
    entries = []
    for path in files:
        data = path.read_bytes()
        entries.append({'path': path.relative_to(ROOT).as_posix(),
                        'bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()})
    manifest = {'title': 'A transient equality pulse for iPRA',
                'version': '2026-11-09',
                'baseline_commit': '572c3ef372fb22e30951af30bf1041efcffc8b7d',
                'hash_algorithm': 'sha256',
                'note': 'The manifest excludes itself; disposable build files are omitted.',
                'files': entries}
    manifest_path = ROOT/'MANIFEST.json'
    manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')
    files.append(manifest_path)
    destination = ROOT.parent/(ROOT.name+'.zip')
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted(files):
            name = ROOT.name+'/'+path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive integrity check failed')
        for entry in entries:
            data = archive.read(ROOT.name+'/'+entry['path'])
            if (len(data) != entry['bytes']
                    or hashlib.sha256(data).hexdigest() != entry['sha256']):
                raise ValueError('Manifest verification failed: '+entry['path'])
    print(json.dumps({'archive': str(destination), 'files': len(files),
                      'bytes': destination.stat().st_size,
                      'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
                      'verified': True}, indent=2))


if __name__ == '__main__':
    main()
