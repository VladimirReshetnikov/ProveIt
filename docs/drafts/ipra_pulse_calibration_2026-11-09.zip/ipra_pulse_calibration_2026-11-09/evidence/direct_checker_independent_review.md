# Independent mathematical code review of the direct ND kernel

## Scope and conclusion

Reviewed `research_checker/checker_template.py` as a standalone source template
for the closed-iteration, raw-reset theory. The fixed comparator placeholder
was still `@@COMPARATOR@@` at review time. This is a mathematical inspection of
the logical and arithmetic inference implementation, not an execution test or
a formal proof of the instantiated comparator's arithmetic properties.

Inspected template SHA-256:
`231939558c525ec77d5c0855324a6e9c802dd63c1464d9b12cb1e62ce9a65148`.

**No defect was found in the inspected inference, scoping, or theorem-interface
code.** The comparator's correctness and its interpretation in iPRA remain
separate mathematical obligations, addressed by the pulse/comparison argument
and its own review. A clean code inspection does not establish minimality.

## Syntax and closed updates

`term` accepts only the declared finite tree constructors. At an iterator node,
it validates the update in the fresh variable environment `{u}` and excludes
the update's locally bound state from the free names of the whole iterator.
Nested iterators are proper finite subtrees, so the required staging exists.
No arbitrary program code, recursive self-reference, or runtime evaluator
is supplied by a certificate.

`replace` performs simultaneous substitution only in actual numerical
arguments. It does not descend into the fixed closed update tree. It returns a
replacement image directly, rather than substituting again within the image;
this is necessary when an actual passive parameter happens to be named `a` or
`b`, the two formal names in the fixed comparator.

The state name `u` may also be used as an ambient variable name. This is safe:
the update occurrence is locally bound, while an argument occurrence is free
unless bound by a surrounding formula. All relevant routines consistently
make that distinction.

## Capture avoidance and alpha-equivalence

Formula substitution stops at a quantifier that binds the substituted name.
It also stops when the name does not occur free in the matrix. When a binder
occurs free in the substitution image, it alpha-renames the binder first.
The replacement name is absent from all strings in the matrix and image, so
it is conservatively fresh even in the presence of nested binders and closed
update descriptions. The recursive renaming correctly respects shadowing.

`canonical` records bound numerical names by their nearest binding position.
At an iterator update it resets the term environment to the single locally
bound name `u`; it does not inherit unrelated outer quantifier bindings.
Consequently `same` compares formulas up to the intended alpha-equivalence
without confusing a closed update's state with an ambient parameter.

Every argument passed to these operations is first validated or is built by
an inference from already validated objects. The routines are not being used
as permissive parsers for arbitrary unvalidated trees.

## Intuitionistic inference rules

The propositional rules have the usual intuitionistic natural-deduction
premises. The two disjunction-elimination branches must have alpha-equivalent
conclusions. Implication introduction extends an immutable context copy;
the added assumption cannot escape to its parent check.

Universal introduction checks that the generalized name is absent from the
retained context. Existential elimination checks that its eigenname is absent
from the context and the free parameters of the existential major, and then
checks that it is absent from the minor conclusion. Instantiation is the
capture-avoiding operation reviewed above. An eigenname may equal the major's
bound existential name; that is harmless and does not evade either free-name
test.

Equality elimination reconstructs both substitutions in one fixed validated
formula motive and compares its minor premise to the required source instance.
It does not permit the certificate to supply an independently trusted target
formula. Equality reflexivity and genuine falsity elimination are explicit.
No excluded-middle or unrestricted induction rule is present.

## Computation and raw anchored reset

The `zero` and `step` rules reconstruct the exact two closed-iterator equations.
The successor equation substitutes the preceding iterator value only for the
update's free state name. The `br` rule is an instance of the declared Boolean
range sentence for `Z(n)=I_0(n,1)`. The `sep` rule is precisely `0=1 -> false`.

For `reset`, the checker reads one finite template `f`, one distinguished
argument name `x`, one fresh eigenname `z`, one target term, and one premise.
It constructs, without trusting a certificate annotation:

1. The anchor `f(1)`.
2. The current value `f(z)`.
3. The fixed comparison `E(f(z), f(1))` by simultaneous substitution.
4. The reset argument `M(E(f(z), f(1)), S(z))`.
5. The required premise `f(reset_argument) = f(1)`.
6. The conclusion `f(target) = f(1)`.

The eigenname is required to differ from `x` and to be absent from all passive
free names of the template, the target, and the retained assumptions. The
premise is checked in exactly that retained context. Thus the same template
and passive parameters occur everywhere; the rule is the stated contextual
raw-reset inference, not a broader matching or reflection rule.

## Public theorem interface

The top-level object must have exactly the keys `context`, `goal`, and `proof`.
The context must be empty, and the goal must be a well-formed closed formula.
The inferred conclusion must be alpha-equivalent to that goal. A derivation
from an unproved assumption cannot be passed off as a closed theorem by a
top-level context field. Rule indices require actual integers rather than
Boolean aliases.

The only runtime import is JSON. Certificate data are not executed. The
recursive inference procedure visits strict finite proof subtrees; the term
and formula routines descend finite syntax trees. Runtime resource exhaustion
remains an ordinary implementation limitation, rather than an additional
inference principle.

## Limits of this receipt

This review did not independently formalize soundness or completeness in a
proof assistant, did not inspect an arbitrary replacement for the comparator
placeholder, and did not infer universal correctness from finite tests. It
records a targeted inspection of the parts most liable to introduce a hidden
strength increase: capture avoidance, update closure, eigenvariable side
conditions, repeated-template matching, and the theorem-only interface.
