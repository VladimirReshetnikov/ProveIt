# Current iPRA corpus audit

Snapshot: `572c3ef372fb22e30951af30bf1041efcffc8b7d`, 12 ZIP archives in
`VladimirReshetnikov/ProveIt/docs/drafts`. All paths below are relative to
`/workspace/scratch/6695757fe80b/baseline/`; extracted originals were read only.

## Corrected complete-source envelope

Static measurements were independently recomputed using the unchanged
`ipra_package_reconstructed/ipra_reset_2026-11-08/reference/source_measure.py`
under CPython 3.12.14. The script strips genuine docstrings, normalizes the
whole module with `ast.unparse`, and counts non-layout tokens, AST nodes, and
UTF-8 bytes. It does not exclude parsing, input handling, rejection, or output.
124 distinct extracted Python sources were inspected by hash; build/package
scripts and fragment verifiers are not complete proof-checker candidates.
Full measurements are in `audit/all_python_metrics.json`.

| Complete source | Tokens | AST nodes | Bytes |
|---|---:|---:|---:|
| `clock_and_kernel/.../code/native/checker.py` | 306 | 340 | 859 |
| `progress_closure/.../code/kernel_variants/lambda_instance.py` | 307 | 347 | 839 |
| `clock_and_kernel/.../code/native/strict_checker.py` | 308 | 341 | 894 |
| `progress_closure/.../code/kernel_variants/local_s.py` | 308 | 346 | 869 |
| inherited `complete_kernel.py` | 309 | 344 | 864 |
| `progress_closure/.../code/progress_checker/checker.py` | 2380 | 2640 | 9682 |
| `local_rewriting/.../code/local_checker.py` | 3287 | 3650 | 16192 |
| `raw_reset/.../code/complete_checker.py` | 3347 | 3539 | 13354 |

The **current literal coordinate envelope is 306/340/839**, with different
attainers. Repeating the 309/344/864 figure quoted by many manuscripts would
compare against a stale subset. If an abstract checker is required to
terminate structurally on every malformed JSON input independently of a
runtime recursion bound, the iterable-alias checker must be distinguished:
the corresponding inspected array-only envelope is 307/341/839.

The 306-token checker removes the `+ []` guard from syntax traversal and adds
harmless decoded aliases for the empty string, empty object, and a singleton
empty-key object. Its published soundness argument is by extraction from a
finite successful trace, not packetwise normalization equivalence. Active
nonempty strings recur until CPython's recursion guard rejects them. Thus it
is a qualified valid implementation result, not a structurally total abstract
input checker. Its source hash is
`7018272edd7cb343c67acfa865c6444d48b01987de7c4be4317006a09c06e3d7`.

The 307-token lambda variant retains an explicit list test. Its source hash is
`b683fd7c5a19036f8f651733ecc536a007b8e06dae567280357b81a72e17a946`.
The 308-token strict dispatcher retains the old array-only guard and has hash
`709eb51d04b76a02b963bc4e62568feb8d6341d1823cd5c0c6e9bf90bb7b1bed`.
These are refinements of the inherited calculus, not new arithmetic theories.

Bytes are name-sensitive: the corpus itself reports that uniformly shortening
three interface names in `compact_open.py` yields 816 bytes while preserving
317 tokens and 351 AST nodes. No source count here is a universal mathematical
lower bound on all iPRA axiomatizations.

## Mathematical presentations already available

### Native paired-binder calculus

The clean four-pattern presentation has formulas `s=t` and `D_{x,y}A`.
Contexts contain reusable clauses `A -> forall y B(y)`. Its rules are:

1. Clause use.
2. Paired introduction: from `B(t,0)` and, only when B is literally an
   equation, `B(t,z)`, derive `B(t,Sz)` and conclude `D_{x,y}B`.
3. Paired elimination: a proved `D` opens its fresh witness and the clause
   `B(a,0) -> forall y B(a,y)`.
4. Equality transport, optionally restricted to literal equation motives.

The intended meaning is `exists x (B(x,0) -> forall y B(x,y))`.
Equationhood is an essential induction-strength condition; deleting it would
allow full formula induction. The retained base is part of the conditional
closure meaning. Restricting a paired elimination major to an assumption is
not justified by ordinary logical normalization: a DI-DE detour can implement
equation induction at an arbitrary target.

The strongest numerical signature reduction represented in the current
dependencies is the shifted closed-iteration basis: variables, zero, and
staged binary `K_h` for closed unary earlier-stage h, with
`K_h(0,a)=Sa`, `K_h(Sn,a)=h(K_h(n,a))`, and `S(a)=K_id(0,a)`.
Predecessor, exact initialized iteration, pairing, all fixed PR operations,
logical selectors and ordinary intuitionistic connectives are reconstructed.
No universal evaluator for variable program codes is asserted.

The tiny checker uses an inherited raw scalar/native representation, not
every later arithmetic basis. An improvement to a later arithmetic rule
does not automatically improve this tiny implementation.

### One fixed recurrence

`ipra_one_fixed_recurrence` uses full PR defining equations, ordinary
intuitionistic equality logic, coverage `x=0 or x=S(Px)`, separation
`0=S0 -> false`, and one fixed recurrence uniqueness rule

`f(Sz)=B(f(z))  /  f(t)=I_B(t,f(0))`,

where B is signed integer increment under the even/nonnegative,
odd/negative numerical coding. The same fixed B is used in every instance;
the term template may have passive parameters and the context is arbitrary.

The substantial new proof in that archive already deletes the separate
half/doubling retraction. It constructs an explicit signed action T on all
states, proves both inverse equations for every iterator I(p,-), derives
arbitrary-value stationarity, uses a two-periodic correction to recover
whole-domain parity decomposition, and then derives `H(D(n))=n`.
The proof order avoids assuming nonstandard iterator cancellation before
proving it. Inspection of that chain found no immediate circularity.
Equality reflection and a Boolean latch then recover full contextual QF
induction. The interpretations are identities in the common full language.
Its certificate checks a substantial fragment relative to a finite elementary
interface; it is explicitly not a complete tiny iPRA checker.

### Rotation and zero-based successor uniqueness

`ipra_rotation` uses full PR equations, coverage, separation,
zero-based successor uniqueness SU0, and one fixed equation
`J(n,Ba)=B(J(n,a))`. SU0 has premises `f(0)=0` and `f(Sz)=S(f(z))`,
and concludes `f(t)=t`.

Before rotation is used, the report derives zero-equation induction,
half/doubling retraction, zero-based double-speed uniqueness, and zero-based
signed uniqueness. Rotation is used to derive a negative diagonal and an
anchored translation; these supply actual equality reflection. The theorem
is an exact trade of a contextual uniqueness schema for a fixed equation,
not a new full-checker minimum. The later local-rewriting report proves
rotation when either parameter is a fixed standard numeral, but explicitly
leaves uniform rotation from SU0 unresolved. This distinction must be kept:
fixed-numeral equations do not prove a theorem for arbitrary internal values.

### Raw reset and closed Boolean bootstrap

`ipra_raw_reset` deletes a diagonal normalizer inside an anchored reset
transition in the full PR signature. The residual rule uses a raw equality
test and successor anchor `f(1)`. Calibration derives its diagonal and
reflection without presupposing induction. A matched direct implementation
saves 14 tokens, 13 AST nodes and 39 bytes, but remains 3347/3539/13354.

`ipra_two_diagonal` transports this program to closed unary iteration, where
the missing identity of the successor clock creates a separate circularity.
`ipra_boolean_bootstrap` already removes the additional clock-related mask:
Boolean-valued induction first corrects the clock, after which a defective
ramp reflects actual equality and full QF induction follows. Therefore
removing this second diagonal is not a new candidate in the present task.

### Equality normalization

`ipra_frontier_audit` makes atomic-motive equality transport explicit, and
`ipra_neutral_transport` restricts its sources. `ipra_local_rewriting` already
proves the simultaneous normalization: literal equation motive, neutral
equation source (computation or clause use), and one occurrence per rewrite.
Its simultaneous induction strengthens the induction hypothesis to a
two-direction conversion operation under arbitrary weakened contexts; this
handles DE and chains of derived equalities without assuming the restricted
cut theorem. The proof is coherent on inspection. DE still needs arbitrary
proved majors. This is a real mathematical interface reduction, but its
readable complete checker is larger than the native source envelope.

### Progression/closure hybrid

`ipra_progress_closure` already reduces every paired introduction to one
local assumption by changing the meaning at literal equations. An atomic
closure denotes `forall y(E(y)->E(Sy))`; a compound closure retains the old
conditional universal meaning. It adds an atomic progression elimination
rule, derives protected closures and existential padding, then proves both
formula round trips. The separate elimination repair is essential.
Unrestricted raw-binder congruence across atomic/compound status is false;
the report explicitly handles this with a protected grammar. A one-assumption
introduction alone therefore cannot be promoted as a new simplification.

## Scope of audit and unresolved obligations

This is a source and proof-interface audit, not a Lean/Rocq verification of
the inherited arithmetic reconstruction. The main handwritten chains were
read at the relevant interfaces and the fixed-recurrence and local-rewrite
normalization proofs were inspected in detail. Every theorem reusing the
small native checker remains dependent on the full inherited arithmetic and
sorted-decoder metatheory; finite fixture tests are not a substitute.

Useful open targets are: derive uniform signed rotation from SU0, or exhibit
a model of its full schema where rotation fails; combine an actual arithmetic
rule deletion with a smaller complete native implementation; or develop a
new binder organization that reduces trusted matching without strengthening
equation induction to full induction. The current drafts do not prove a
universal lower bound barring these approaches.
