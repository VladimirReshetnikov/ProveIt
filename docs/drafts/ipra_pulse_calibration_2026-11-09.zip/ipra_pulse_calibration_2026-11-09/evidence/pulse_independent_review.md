# Independent review of the pulse calibration

Reviewed `research_pulse/pulse_bootstrap.tex` and
`research_pulse/term_definitions.json`, together with the inherited
closed-equational reconstruction under
`ipra_boolean_bootstrap_2026-11-09/.../reference/closed_equational/sections/`.
This is a mathematical source review, not a machine-checked proof.

## Verdict

The predecessor-free spike calibration and pulse comparator are valid on
inspection. The proof does not assume numerical coverage, a calibrated
clock, a previously correct equality test, or induction during its initial
source calibration. The inherited reconstruction supplies the required
whole-domain compiler and interpretation composites after equation induction
has been recovered. No substantive gap was identified in the inspected
chain. The result is a real reduction of the trusted comparator term, not
yet a below-envelope complete proof checker.

## Source calibration

All definitions are legal in the closed-update grammar. In particular the
new update

`h(u)=C0(Z(u), M(Z(N(u)),2), 1)`

contains only its state variable u. The arguments a,b of the ramp and spike
occur in iterator initializers/counters, not as captured update parameters.
Each descriptor is finite and staged after its dependencies.

The key arbitrary-domain implication is local:

`Z(v)=1 -> h(v)=C0(1,M(Z(N(v)),2),1)=Add(0,1)=1`.

The last identity is a finite one-step computation. It does not use the
unproved identity `Add(0,a)=a` for arbitrary a. With
`q(n)=Z(I_h(n,1))`, this gives `q(z)=1 -> q(Sz)=0` at every source-domain
element. The finite computations give q(0)=q(1)=0 and q(2)=1. The outer Z
provides its Boolean range.

The ramp `F_ab` has values c(a) and b, where c is the as-yet-uncalibrated
successor clock. Consequently `H_ab(z)=F_ba(Z(q(z)))` has **exact** default a
and exceptional c(b), with the exception immediately followed by a.
Its anchor H(1)=a and H(0)=a are exact before clock calibration.

Under e(a,a)=1, the anchored-rule premise holds in both Boolean cases of q:
the default case resets to zero; the exceptional case resets either to zero
or to the known default successor. Therefore H(2)=H(1), giving c(b)=a.
Applying this at b=0 and b=1 uses only c(0)=0,c(1)=1 and yields 0=1. Under
the retained e(a,a)=1 assumption, equality transport gives e(a,a)=0 directly.
Boolean case elimination then proves the diagonal without using separation
or ex falso. The source has not silently invoked arbitrary excluded middle.

After this diagonal is proved, the inherited argument has all its required
hypotheses: Boolean range, diagonal zero, and e(1,0)=1. Restricted reflection
uses the defective ramp; Boolean-valued induction uses only the two finite
comparison endpoints; applying it to e(c(n),n) calibrates the clock; full
reflection follows. The order of these lemmas is noncircular.

The final arbitrary zero-equation induction uses the now-proved reflection.
The exact selector and separation then justify all QF Boolean characteristics,
including implication by Boolean cases. Contexts may retain arbitrary
quantified formulas; only the induction matrix is restricted.

## Target proof

The proposed comparator is

`e(a,b)=Z(N(I_K(b,E(a))))`, with `K(u)=M(N(u),G(u))`.

In ordinary iPRA, the fixed closed descriptions prove the identities
`K(2n)=3n`, `K(2n+1)=0`, and `E(a)=2^a` by QF inductions. Thus its orbit is
`3^b * 2^(a-b)` when b<=a and zero when b>a. At b=a it is odd; before b=a
it is even; afterward it is zero. The orbit display can be written as one
PR-selector equation using truncated subtraction, and the induction is a
permitted equation induction with fixed a. The case distinctions are
decidable QF arithmetic, not classical reasoning on arbitrary propositions.
Hence the target proves the exact raw comparator correct internally for all
elements, not only at sampled numerals.

For source-rule soundness in the target, put c=f(1). At z=0, either the raw
test e(f(0),c) is zero, in which case target reflection gives f(0)=c, or it is
one, in which case the reset premise specializes directly to f(0)=c. Under
f(n)=c, its diagonal comparison is zero, so the reset premise gives
f(Sn)=c. Target equation induction proves f(t)=c with the retained context
unchanged. This spells out both the base and the step.

## Inherited arithmetic compiler

The inspected dependency is substantial, but it is explicit:

* `03_predecessor.tex` proves a closed-update predecessor using equality
  reasoning and single-equation induction alone. Its Boolean gluing lemma
  interprets equality through two complementary projections. The projected
  induction matrix remains one literal equation. The two clock invariants
  are proved in separate inductions, so no conjunction induction is hidden.
  The final finite prefix/tail join uses endpoint equation induction.
* `04_pairing_compiler.tex` derives a pairing and its two projections without
  an order axiom. An explicit slack equation bounds the required trajectory
  internally. The semigroup/rotation equations are first proved with fixed
  parameters and only then specialized to changing initializers.
* The same section packs a fixed parameter environment, counter, and current
  value into one state. The update has only that state free. Two separate
  equation inductions establish environment preservation and the internal
  counter identity. The value projection satisfies each compiled PR defining
  equation.
* External induction on a fixed descriptor/stage, followed by internal
  equality induction for each recursive node, identifies both double
  translations with the original function. Domains and actual equality are
  unchanged; ordinary logical operations commute with translation. Thus the
  composite isomorphism has graph x=y on the entire domain.

These proofs apply after the new calibration has recovered contextual
equation induction. They do not presuppose that every domain element is a
standard numeral, and they introduce no uniform evaluator on program codes.

## Independent size verification

A separate recursion over the descriptor JSON, counting each variable,
zero, successor and iterator node and fully expanding each update body,
reproduced:

| Term | Expanded nodes | Constant/argument coefficients |
|---|---:|---|
| Previous comparison | 182 | (178,2,2) |
| New pulse comparison | 70 | (68,1,1) |
| Spike update | 40 | (37,3) |
| Spike bit | 48 | (47,1) |
| Proof-library spike | 133 | (129,2,1,1) |

The spike is used only in a derived proof. It does not become a new primitive
axiom, matcher, or trusted test. The previous raw-reset draft already uses an
isolated-spike calibration in the richer full-PR language; the new point is
the predecessor-free construction valid before the closed clock is calibrated,
and the resulting permission to replace the doubled comparison by one pulse.
No literature-wide novelty claim was audited.

## Symbolic calibration replay reviewed later

The finite replayer `replay_pulse_certificate.py` was inspected separately.
Its declaration validator enforces acyclic earlier-stage macro use, fixed
arities and closed unary iterator updates. Definition expansion performs
simultaneous substitution. Its arithmetic leaves are computation and BR;
the reset inference checks the literal premise and the freshness of its
eigenvariable against the term template, target and all undischarged
assumptions. Disjunction/implication discharge tracks hypothesis indices;
all exported claims must have empty dependency sets. There is no induction
rule, universal evaluator, assumed clock identity, or assumed spike interface.

An independent run of `validate_pulse.py` accepted all 1,880 proof steps and
rejected its eight negative controls. The same run reported 63 finite orbit
pairs and 24 literal-successor checks. These calculations are supporting
tests; the internal orbit theorem is the written QF-induction argument above.
The fragment replayer is not the complete theory checker and is not used as
a below-envelope checker candidate.

## Complete ordinary-ND implementation

A separate complete ND engine was implemented in
`research_checker/checker_template.py`, with the fixed comparator literal
charged in full after expansion. It covers all displayed intuitionistic
first-order logical rules, reflexivity and general equality substitution,
closed iterator computation, BR, separation and the exact anchored-reset
rule. It has no primitive induction rule. Quantifier substitution avoids
capture; matching is modulo alpha equivalence; the CLI accepts only closed
theorems with an empty context. Its numerical substitution skips each closed
update body and instantiates the two comparator arguments simultaneously.

The matched baseline and pulse files generated by the parent were tested
with 22 positive packets and 25 negative packets each, in normal and optimized
Python, plus four malformed-input cases in both modes: 102 public subprocess
checks per file. Every rule was exercised. Additional direct tests checked
closed-update binding and simultaneous substitution. The nonconstant-template
reset test uses `f(x)=I_0(1,I_S(x,b))`: the argument occurs in its actual
syntax, and its reset premise is derived by computation and equality
transport. Deliberately changing the fixed comparator or using sequential
argument substitution is rejected. Freshness controls cover universal,
existential and reset rules, including free parameters and retained contexts.

These tests and the independent code review by the logic agent support the
readable implementation; they do not mechanize its soundness theorem or the
whole arithmetic bi-interpretation. The new engine is larger than the native
corpus envelope. Its matched comparator saving is a local complete-source
comparison and must not be reported as a new global minimum.
