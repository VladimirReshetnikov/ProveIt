"""Produce an explicit finite proof DAG; all steps replay in the separate verifier."""
import hashlib
import json
from pathlib import Path
import replay_pulse_certificate as R

base=Path(__file__).resolve().parent
declarations=json.loads((base/'term_definitions.json').read_text())
table=R.declarations_table(declarations)
ZERO,ONE,TWO=R.ZERO,R.ONE,R.TWO
V,A,I,Eq,Or,Imp,All=R.V,R.A,R.I,R.Eq,R.Or,R.Imp,R.All
steps=[];formulas=[]

def emit(rule,conclusion,**fields):
    steps.append({'rule':rule,**fields});formulas.append(conclusion);return len(steps)-1

def refl(t):return emit('refl',Eq(t,t),term=t)
def definition(t):return emit('definition',Eq(t,R.expand(t,table)),term=t)
def compute(t):
    v=t[3] if t[2]==ZERO else A(t[1],I(t[1],t[2][1],t[3]))
    return emit('compute',Eq(t,v),term=t)
def sym(p):
    f=formulas[p];return emit('sym',Eq(f[2],f[1]),proof=p)
def trans(p,q):
    f,g=formulas[p],formulas[q]
    assert f[0]==g[0]=='eq' and f[2]==g[1],('middle mismatch',f,g)
    return emit('trans',Eq(f[1],g[2]),left=p,right=q)
def congr(p,t,variable='hole'):
    f=formulas[p]
    return emit('congruence',Eq(R.subst(t,variable,f[1]),R.subst(t,variable,f[2])),proof=p,template=t,variable=variable)
def hypothesis(f):return emit('hyp',f,formula=f)
def transport(eq,body,template,variable='hole'):
    f=formulas[eq]
    assert formulas[body]==R.fsubst(template,variable,f[1])
    return emit('transport',R.fsubst(template,variable,f[2]),equality=eq,body=body,template=template,variable=variable)
def imp_intro(h,p):return emit('imp_intro',Imp(formulas[h],formulas[p]),hypothesis=h,body=p)
def imp_elim(p,q):
    assert formulas[p][0]=='imp' and formulas[p][1]==formulas[q]
    return emit('imp_elim',formulas[p][2],major=p,minor=q)
def all_intro(variable,p):return emit('all_intro',All(variable,formulas[p]),variable=variable,body=p)
def all_elim(p,t):
    f=formulas[p];assert f[0]=='all'
    return emit('all_elim',R.fsubst(f[2],f[1],t),proof=p,term=t)
def or_elim(major,lh,lp,rh,rp):
    assert formulas[major]==Or(formulas[lh],formulas[rh])
    assert formulas[lp]==formulas[rp]
    return emit('or_elim',formulas[lp],major=major,left_hypothesis=lh,left=lp,right_hypothesis=rh,right=rp)

cache={}

def normal(t,known=()):
    """Construct a sequence of permitted equations; do not evaluate a number oracle."""
    key=(json.dumps(t,separators=(',',':')),tuple(known))
    if key in cache:return cache[key]
    for p in known:
        e=formulas[p]
        if t==e[1]:
            cache[key]=(e[2],p);return cache[key]
    tag=t[0]
    if tag in ('v','0'):
        result=t,refl(t)
    elif tag=='call':
        p=definition(t);u,q=normal(formulas[p][2],known)
        result=u,trans(p,q)
    elif tag=='I' and (t[2]==ZERO or t[2][0]=='S'):
        p=compute(t);u,q=normal(formulas[p][2],known)
        result=u,trans(p,q)
    else:
        current=t;p=refl(t)
        indices=[1] if tag=='S' else [2,3]
        for index in indices:
            child,q=normal(current[index],known)
            if child!=current[index]:
                template=current.copy();template[index]=V('hole')
                q=congr(q,template);p=trans(p,q)
                current=current.copy();current[index]=child
        for q in known:
            e=formulas[q]
            if current==e[1]:
                result=e[2],trans(p,q);break
        else:
            if current[0]=='I' and (current[2]==ZERO or current[2][0]=='S'):
                q=compute(current);u,r=normal(formulas[q][2],known)
                result=u,trans(p,trans(q,r))
            else:result=current,p
    cache[key]=result;return result


def augmented(hypotheses):
    result=list(hypotheses)
    for h in hypotheses:
        e=formulas[h];assert e[0]=='eq'
        lhs,p=normal(e[1]);rhs,q=normal(e[2])
        result.append(trans(trans(sym(p),h),q))
    return tuple(result)


def prove_equal(lhs,rhs,known=()):
    nl,pl=normal(lhs,known);nr,pr=normal(rhs,known)
    assert nl==nr,('normal forms differ',nl,nr)
    return trans(pl,sym(pr))


def range_outer_Z(t):
    p=definition(t);body=formulas[p][2]
    assert body[0:2]==['call','Z']
    major=emit('BR',Or(Eq(body,ZERO),Eq(body,ONE)),term=body[2])
    return transport(sym(p),major,Or(Eq(V('hole'),ZERO),Eq(V('hole'),ONE)))


q=lambda t:A('spike_bit',t)
e=lambda a,b:A('pulse_equality',a,b)
claims={}
for name,n,value in [('q_zero',ZERO,ZERO),('q_one',ONE,ZERO),('q_two',TWO,ONE)]:
    claims[name]=prove_equal(q(n),value)
z=V('z');a=V('a');b=V('b')
h= hypothesis(Eq(q(z),ONE))
p=prove_equal(q(['S',z]),ZERO,augmented([h]))
claims['q_successor']=all_intro('z',imp_intro(h,p))
claims['comparator_endpoint']=prove_equal(e(ONE,ZERO),ONE)

# The exact AR premise is proved branch by branch, with all local assumptions discharged.
f=lambda t:A('spike',t,a,b)
anchor=f(ONE)
reset=A('mask',e(f(z),anchor),['S',z])
lhs=f(reset);rhs=anchor
bad=hypothesis(Eq(e(a,a),ONE))
q_range=range_outer_Z(q(z))
q0=hypothesis(Eq(q(z),ZERO));q1=hypothesis(Eq(q(z),ONE))
p0=prove_equal(lhs,rhs,augmented([bad,q0]))
ecb=e(A('clock',b),a)
e_range=range_outer_Z(ecb)
e0=hypothesis(Eq(ecb,ZERO));e1=hypothesis(Eq(ecb,ONE))
p10=prove_equal(lhs,rhs,augmented([bad,q1,e0]))
p11=prove_equal(lhs,rhs,augmented([bad,q1,e1]))
p1=or_elim(e_range,e0,p10,e1,p11)
premise=or_elim(q_range,q0,p0,q1,p1)
matrix=A('spike',V('x'),a,b)
ar=emit('AR',Eq(f(TWO),anchor),template=matrix,variable='x',eigenvariable='z',target=TWO,premise=premise)
left=prove_equal(f(TWO),A('clock',b))
right=prove_equal(anchor,a)
collapse=trans(trans(sym(left),ar),right)
claims['failed_diagonal_collapse']=all_intro('a',all_intro('b',imp_intro(bad,collapse)))

# Diagonal calibration: both clock endpoints are finite computations, and no ex falso is used.
eaa=e(a,a)
diagonal_range=range_outer_Z(eaa)
d0=hypothesis(Eq(eaa,ZERO));d1=hypothesis(Eq(eaa,ONE))
generic=all_elim(claims['failed_diagonal_collapse'],a)
c0=imp_elim(all_elim(generic,ZERO),d1)
c1=imp_elim(all_elim(generic,ONE),d1)
zero_a=trans(sym(prove_equal(A('clock',ZERO),ZERO)),c0)
one_a=trans(sym(prove_equal(A('clock',ONE),ONE)),c1)
one_zero=trans(one_a,sym(zero_a))
one_branch=trans(d1,one_zero)
diagonal=or_elim(diagonal_range,d0,d0,d1,one_branch)
claims['diagonal']=all_intro('a',diagonal)

certificate={'format':'pulse-source-calibration-v1',
 'declarations_sha256':hashlib.sha256(json.dumps(declarations,separators=(',',':'),sort_keys=True).encode()).hexdigest(),
 'steps':steps,'claims':claims}
result=R.verify(certificate,declarations)
(base/'pulse_certificate.json').write_text(json.dumps(certificate,separators=(',',':'))+'\n')
(base/'pulse_certificate_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
