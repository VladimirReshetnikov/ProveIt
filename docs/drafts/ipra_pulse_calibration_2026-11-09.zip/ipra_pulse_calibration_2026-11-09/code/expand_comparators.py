"""Build matched, standalone complete checkers from explicit finite syntax.

This producer is not imported by either checker. Every update body is fully
expanded into the resulting checker's fixed comparator literal.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def expand(declarations, name):
    table = {row['name']: row for row in declarations}

    def walk(t, environment):
        tag = t[0]
        if tag == 'v':
            return environment.get(t[1], t)
        if tag == '0':
            return ['0']
        if tag == 'S':
            return ['S', walk(t[1], environment)]
        if tag == 'call':
            row = table[t[1]]
            arguments = [walk(a, environment) for a in t[2:]]
            return walk(row['body'], dict(zip(row['parameters'], arguments)))
        if tag == 'I':
            update = table[t[1]]
            if len(update['parameters']) != 1:
                raise ValueError('A closed update must have one argument')
            body = walk(update['body'], {update['parameters'][0]: ['v', 'u']})
            return ['I', body, walk(t[2], environment), walk(t[3], environment)]
        raise ValueError('Unknown term constructor')

    row = table[name]
    return walk(row['body'], {x: ['v', x] for x in row['parameters']})


def nodes(t):
    if t[0] in ('0', 'v'):
        return 1
    return 1 + sum(nodes(x) for x in t[1:])


def main():
    template = (ROOT / 'code/checker_template.py.in').read_text()
    records = []
    for label, name, expected in [('baseline', 'epsilon', 182),
                                  ('pulse', 'pulse_equality', 70)]:
        filename = 'baseline_comparison_terms.json' if label == 'baseline' else 'term_definitions.json'
        declarations = json.loads((ROOT / 'code' / filename).read_text())
        tree = expand(declarations, name)
        if nodes(tree) != expected:
            raise ValueError('Expanded node count changed')
        literal = repr(tree)
        source = template.replace('E = @@COMPARATOR@@', 'E = ' + literal)
        out = ROOT / 'code' / ('checker_' + label + '.py')
        out.write_text(source)
        (ROOT / 'code' / ('comparator_' + label + '.json')).write_text(
            json.dumps(tree, indent=2) + '\n')
        records.append({'label': label, 'fixed_comparator': name,
                        'nodes': nodes(tree), 'file': str(out.relative_to(ROOT)),
                        'sha256': hashlib.sha256(out.read_bytes()).hexdigest()})
    result = {'same_engine': True, 'only_executable_difference': 'fixed E literal',
              'checkers': records}
    (ROOT / 'evidence/matched_sources.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
