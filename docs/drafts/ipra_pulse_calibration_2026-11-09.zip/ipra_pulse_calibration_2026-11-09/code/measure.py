"""Reproduce full-source baseline and matched checker measurements."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('source_measure', ROOT / 'reference/source_measure.py')
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
manifest = json.loads((ROOT / 'reference/checkers_manifest.json').read_text())
rows = []
for entry in manifest['programs']:
    result = measure.metrics(ROOT / entry['file'])
    if result['sha256'] != entry['sha256']:
        raise ValueError('Changed frozen comparator: ' + entry['file'])
    rows.append({**entry, **result})
coordinates = ['normalized_tokens', 'ast_nodes', 'normalized_bytes']
floor = {k: min(r[k] for r in rows) for k in coordinates}
matched = [{**measure.metrics(ROOT / 'code' / ('checker_' + label + '.py')),
            'label': label} for label in ['baseline', 'pulse']]
trees = []
for label in ['baseline', 'pulse']:
    tree = ast.parse((ROOT / 'code' / ('checker_' + label + '.py')).read_text())
    found = 0
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'E':
            node.value = ast.Constant(value=None)
            found += 1
    if found != 1:
        raise ValueError('Fixed comparator assignment changed')
    trees.append(ast.dump(tree, include_attributes=False))
if trees[0] != trees[1]:
    raise ValueError('Matched checkers have another executable difference')
result = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
          'source_normalizer_sha256': hashlib.sha256((ROOT/'reference/source_measure.py').read_bytes()).hexdigest(),
          'whole_module_including_parser_driver_and_failure_handling': True,
          'frozen_program_count': len(rows), 'coordinate_minima': floor,
          'minimum_attainers': {k: [r['file'] for r in rows if r[k] == floor[k]] for k in coordinates},
          'baseline_programs': rows, 'matched_complete_checkers': matched,
          'matched_engine_identity': True,
          'matched_saving': {k: matched[0][k] - matched[1][k] for k in coordinates},
          'pulse_below_entire_envelope': all(matched[1][k] < floor[k] for k in coordinates)}
(ROOT/'evidence/measurements.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='baseline_programs'}, indent=2))
