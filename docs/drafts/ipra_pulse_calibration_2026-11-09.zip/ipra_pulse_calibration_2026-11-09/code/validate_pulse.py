"""Reproduce source-fragment replay, rejection tests, term sizes and numeral diagnostics.

Numeral diagnostics are not interpretation proofs. Replay is scoped to the
finite source calibration, not the entire iPRA equivalence or complete kernel.
"""
from copy import deepcopy
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import replay_pulse_certificate as R

BASE=Path(__file__).resolve().parent


def sizes(declarations):
    R.declarations_table(declarations)
    affine={};rows=[]
    for row in declarations:
        params=row['parameters'];width=1+len(params)
        def add(a,b):return [x+y for x,y in zip(a,b)]
        def walk(t):
            tag=t[0]
            if tag=='v':
                v=[0]*width;v[params.index(t[1])+1]=1;return v
            if tag=='0':return [1]+[0]*len(params)
            if tag=='S':
                v=walk(t[1]);v[0]+=1;return v
            if tag=='I':
                v=add(walk(t[2]),walk(t[3]));v[0]+=1+sum(affine[t[1]]);return v
            coeff=affine[t[1]];v=[coeff[0]]+[0]*len(params)
            for k,arg in zip(coeff[1:],t[2:]):v=add(v,[k*x for x in walk(arg)])
            return v
        affine[row['name']]=walk(row['body'])
        rows.append({'name':row['name'],'expanded_nodes':sum(affine[row['name']]),'affine_coefficients':affine[row['name']]})
    return rows


def evaluator(declarations,accelerate_successor):
    table=R.declarations_table(declarations)
    if accelerate_successor:
        assert table['succ']=={'name':'succ','parameters':['u'],'body':['S',['v','u']]}
    @lru_cache(None)
    def call(name,args):
        row=table[name];assert len(row['parameters'])==len(args)
        return evaluate(row['body'],dict(zip(row['parameters'],args)))
    @lru_cache(None)
    def iterate(name,n,seed):
        if accelerate_successor and name=='succ':return n+seed
        value=seed;step=0;seen={}
        while step<n:
            if value in seen:
                period=step-seen[value]
                skip=(n-step)//period
                if skip:
                    step+=skip*period;continue
            else:seen[value]=step
            value=call(name,(value,));step+=1
        return value
    def evaluate(t,env):
        tag=t[0]
        if tag=='v':return env[t[1]]
        if tag=='0':return 0
        if tag=='S':return 1+evaluate(t[1],env)
        if tag=='call':return call(t[1],tuple(evaluate(x,env) for x in t[2:]))
        return iterate(t[1],evaluate(t[2],env),evaluate(t[3],env))
    return call,iterate


def main():
    declarations=json.loads((BASE/'term_definitions.json').read_text())
    certificate=json.loads((BASE/'pulse_certificate.json').read_text())
    replay=R.verify(certificate,declarations)
    negative=[]
    def rejected(name,c,d=declarations):
        try:R.verify(c,d)
        except (R.InvalidCertificate,KeyError,TypeError,IndexError,ValueError) as e:
            negative.append({'case':name,'rejected':True,'reason':str(e)});return
        raise AssertionError('Mutation accepted: '+name)
    ar_index=next(i for i,s in enumerate(certificate['steps']) if s['rule']=='AR')
    c=deepcopy(certificate);c['steps'][ar_index]['target']=R.V('z');rejected('eigenvariable_occurs_in_target',c)
    c=deepcopy(certificate);c['steps'][ar_index]['template']=R.A('spike',R.V('x'),R.V('z'),R.V('b'));rejected('eigenvariable_captured_by_template',c)
    c=deepcopy(certificate);c['steps'][ar_index]['premise']=certificate['claims']['q_zero'];rejected('wrong_reset_premise',c)
    c=deepcopy(certificate);c['claims']['diagonal']=certificate['claims']['comparator_endpoint'];rejected('false_export',c)
    c=deepcopy(certificate);c['steps'][next(i for i,s in enumerate(c['steps']) if s['rule']=='compute')]['rule']='equality_oracle';rejected('unlicensed_oracle',c)
    c=deepcopy(certificate);c['declarations_sha256']='0'*64;rejected('definition_digest_mismatch',c)
    d=deepcopy(declarations);next(r for r in d if r['name']=='spike_step')['body']=R.V('ambient');rejected('update_parameter_capture',certificate,d)
    # An exact reset premise as a retained z-dependent hypothesis must fail freshness.
    ar=deepcopy(certificate['steps'][ar_index]);matrix=ar['template'];z=R.V(ar['eigenvariable'])
    f=lambda t:R.subst(matrix,ar['variable'],t)
    anchor=f(R.ONE);reset=R.A('mask',R.A('pulse_equality',f(z),anchor),['S',z])
    ar['premise']=0
    c=deepcopy(certificate);c['steps']=[{'rule':'hyp','formula':R.Eq(f(reset),anchor)},ar]
    rejected('eigenvariable_in_retained_hypothesis',c)

    fast,it=evaluator(declarations,True)
    numerical=[]
    for a in range(7):
        for b in range(9):
            orbit=it('pulse_step',b,fast('pow2',(a,)))
            expected=3**b*2**(a-b) if b<=a else 0
            bit=fast('pulse',(a,b));eq=fast('pulse_equality',(a,b))
            assert orbit==expected and bit==int(a==b) and eq==int(a!=b)
            numerical.append({'a':a,'b':b,'orbit':orbit,'pulse':bit,'comparator':eq})
    literal,literal_it=evaluator(declarations,False)
    for a in range(4):
        for b in range(6):
            assert literal('pulse_equality',(a,b))==int(a!=b)
    q=[fast('spike_bit',(n,)) for n in range(24)]
    assert q[:3]==[0,0,1] and all(x==0 or y==0 for x,y in zip(q,q[1:]))
    target={'checked_orbit_pairs':len(numerical),'literal_successor_pairs':24,'spike_bits':q,'values':numerical,
            'scope':'Finite numeral diagnostics only; the written target equation-induction proof handles arbitrary elements.'}
    (BASE/'target_diagnostics.json').write_text(json.dumps(target,indent=2)+'\n')
    result={'replay':replay,'negative_cases':negative,'term_sizes':sizes(declarations),
            'numerical_summary':{k:v for k,v in target.items() if k!='values'}}
    comparator_path=BASE/'baseline_comparison_terms.json'
    if comparator_path.exists():
        old_sizes=sizes(json.loads(comparator_path.read_text()))
        old=next(x for x in old_sizes if x['name']=='epsilon')
        new=next(x for x in result['term_sizes'] if x['name']=='pulse_equality')
        result['comparator_comparison']={'baseline':old,'pulse':new,'node_reduction':old['expanded_nodes']-new['expanded_nodes'],
            'scope':'Fully expanded numerical syntax, including closed update bodies; not complete proof-checker size.'}
    (BASE/'validation_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'accepted':replay['accepted'],'proof_steps':replay['proof_steps'],'negative_tests':len(negative),
                     'orbit_pairs':len(numerical),'literal_successor_pairs':24,
                     'comparison':result.get('comparator_comparison')},indent=2))


if __name__=='__main__':main()
