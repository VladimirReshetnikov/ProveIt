#!/usr/bin/env python3
"""Replay the mathematical fragments and measure complete comparison sources."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def main():
    commands = [
        [sys.executable, "verification/validate.py"],
        [sys.executable, "verification/autonomous/validate.py"],
        [sys.executable, "verification/two_updates/validate.py"],
        [sys.executable, "comparison/measure.py"],
    ]
    for command in commands:
        print("Running " + " ".join(command[1:]), flush=True)
        subprocess.run(command, cwd=ROOT, check=True)

if __name__ == "__main__":
    main()

