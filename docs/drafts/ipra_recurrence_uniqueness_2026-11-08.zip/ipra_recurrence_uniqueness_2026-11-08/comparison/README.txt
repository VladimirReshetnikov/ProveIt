COMPLETE COMPARISON PROGRAMS
===========================

These sixteen complete programs are copied unchanged from
ipra_stationarity_2026-11-08.zip at the current ProveIt commit
deefab74912eef91a2cd1ba6686589cb8964466e.

They implement the inherited scalar/native presentation of iPRA, not the
recurrence-uniqueness presentation studied in this report. They are included
to make the actual comparison boundary reproducible, not as newly authored
checkers.

The original stationarity archive froze an earlier six-archive snapshot
12a94890af11b5e75f753260f3be00bb11ae7f08 and copied twelve older complete
programs plus four source variants. baseline_manifest.json retains that
original provenance and each complete source's SHA-256. The report's
provenance/source_snapshot.json records the ten archives actually inspected
for this request. These are distinct, explicitly recorded source boundaries.

Run from the package root:
    python3 comparison/measure.py

The unchanged source normalizer verifies hashes, parses (but does not execute)
each checker, removes comments and genuine docstrings, normalizes the entire
program with ast.unparse, and counts significant tokens, AST nodes, and bytes.
It retains imports, drivers, scope traversal, validation, and inference code.

Reproduced using CPython 3.12.14:
    313 normalized tokens / 347 AST nodes / 878 normalized UTF-8 bytes.
The minima have different attainers. They are observed finite-corpus minima,
not a universal lower-bound theorem. The current report does not claim a new
complete program below this envelope.

The script writes evidence/baseline_metrics.json.

INHERITED_README.txt and provenance/ retain the original explanatory and
license files. References there to "this report", old snapshots, or old
archives describe the original source package, not this investigation.

