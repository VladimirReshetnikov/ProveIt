"""Construct symbolic arithmetic certificates without importing the verifier."""
from __future__ import annotations
import json
from pathlib import Path

Z = ["0"]
def S(t): return ["S", t]
def app(f, *args): return [f, *args]
def A(n, a): return app("add", n, a)
def P(n): return app("pred", n)
def C(n, a, b): return app("sel", n, a, b)
def D(a, n): return app("sub", n, a)
def sg(n): return C(n, Z, S(Z))
def k(n): return C(n, S(Z), P(n))
def eps(a, b): return sg(k(D(S(a), b)))

def sub(t, images):
    return images.get(t, t) if isinstance(t, str) else [t[0], *(sub(a, images) for a in t[1:])]

def fv(t):
    return {t} if isinstance(t, str) else set().union(*(fv(a) for a in t[1:])) if len(t) > 1 else set()


class Producer:
    def __init__(self):
        self.declarations = []
        self.definitions = {}
        self.proofs = []
        self.contexts = []
        self.exports = []
        self.case_count = 0

    def declare(self, d):
        self.declarations.append(d)
        self.definitions[d["name"]] = d

    def recursor(self, name, step, parameters=()):
        self.declare({"kind": "recursor", "name": name, "counter": "ri", "state": "ru",
                      "parameters": list(parameters), "step": step})

    def macro(self, name, parameters, body):
        self.declare({"kind": "macro", "name": name, "parameters": list(parameters), "body": body})

    def emit(self, rule, equation, context=(), **data):
        number = len(self.proofs)
        self.proofs.append({"rule": rule, **data, "equation": equation})
        self.contexts.append(list(context))
        return number

    def equation(self, p): return self.proofs[p]["equation"]

    def union(self, *proofs):
        out = []
        for p in proofs:
            for e in self.contexts[p]:
                if e not in out: out.append(e)
        return out

    def refl(self, t): return self.emit("refl", [t, t], term=t)
    def hyp(self, a, b): return self.emit("hyp", [a, b], [[a, b]])
    def sym(self, p):
        a, b = self.equation(p)
        return self.emit("sym", [b, a], self.contexts[p], proof=p)

    def trans(self, p, q):
        a, b = self.equation(p); c, d = self.equation(q)
        if b != c: raise ValueError(f"producer transitivity mismatch: {b} != {c}")
        return self.emit("trans", [a, d], self.union(p, q), left=p, right=q)

    def cong(self, symbol, *proofs):
        pairs = [self.equation(p) for p in proofs]
        return self.emit("cong", [[symbol, *(p[0] for p in pairs)], [symbol, *(p[1] for p in pairs)]],
                         self.union(*proofs), symbol=symbol, proofs=list(proofs))

    def subst(self, p, **images):
        equation = [sub(t, images) for t in self.equation(p)]
        context = [[sub(t, images) for t in e] for e in self.contexts[p]]
        return self.emit("subst", equation, context, proof=p, images=images)

    def definition(self, term):
        decl = self.definitions[term[0]]
        if decl["kind"] == "macro":
            right = sub(decl["body"], dict(zip(decl["parameters"], term[1:])))
        else:
            n, initial, *parameters = term[1:]
            if n == Z:
                right = initial
            else:
                if not (isinstance(n, list) and len(n) == 2 and n[0] == "S"):
                    raise ValueError("producer requested nonconstructor computation")
                images = dict(zip(decl["parameters"], parameters))
                images["ri"] = n[1]
                images["ru"] = app(term[0], n[1], initial, *parameters)
                right = sub(decl["step"], images)
        return self.emit("def", [term, right], term=term)

    def norm(self, term):
        if isinstance(term, str) or len(term) == 1:
            return self.refl(term)
        children = [self.norm(a) for a in term[1:]]
        result = self.cong(term[0], *children)
        current = self.equation(result)[1]
        if current[0] in self.definitions:
            decl = self.definitions[current[0]]
            n = current[1]
            if decl["kind"] == "macro" or n == Z or (isinstance(n, list) and n and n[0] == "S"):
                first = self.definition(current)
                rest = self.norm(self.equation(first)[1])
                result = self.trans(result, self.trans(first, rest))
        return result

    def definitional(self, left, right):
        p, q = self.norm(left), self.norm(right)
        if self.equation(p)[1] != self.equation(q)[1]:
            raise ValueError(f"different normal forms: {self.equation(p)[1]} / {self.equation(q)[1]}")
        return self.trans(p, self.sym(q))

    def rewrite(self, term, proof):
        left, right = self.equation(proof)
        if term == left:
            return proof
        if isinstance(term, list):
            for i, child in enumerate(term[1:]):
                try:
                    changed = self.rewrite(child, proof)
                except LookupError:
                    continue
                parts = [self.refl(t) for t in term[1:]]
                parts[i] = changed
                return self.cong(term[0], *parts)
        raise LookupError(f"no occurrence of {left} in {term}")

    def lift(self, template, variable, proof):
        """Congruence for every occurrence of one named template variable."""
        if template == variable:
            return proof
        if isinstance(template, str) or len(template) == 1:
            return self.refl(template)
        return self.cong(template[0], *(self.lift(t, variable, proof) for t in template[1:]))

    def chain(self, start, *rewrites):
        proof = self.refl(start)
        for rewrite in rewrites:
            proof = self.trans(proof, self.rewrite(self.equation(proof)[1], rewrite))
        return proof

    def U(self, body, variable, target, recursor, premise, parameters=(), eigen="z"):
        initial = sub(body, {variable: Z})
        right = app(recursor, target, initial, *parameters)
        return self.emit("U", [sub(body, {variable: target}), right], self.contexts[premise],
                         body=body, variable=variable, target=target, recursor=recursor,
                         proof=premise, parameters=list(parameters), eigen=eigen)

    def cases(self, left, right, variable, base, successor, eigen="z"):
        """Expand endpoint equation cases into two U nodes; no case rule is trusted."""
        self.case_count += 1
        name = f"case_rec_{self.case_count}"
        params = sorted((fv(left) | fv(right)) - {variable})
        formal = [f"cp{i}" for i in range(len(params))]
        images = dict(zip(params, formal)); images[variable] = S("ri")
        self.recursor(name, sub(right, images), formal)
        first = self.U(left, variable, variable, name, successor, params, eigen)
        second_step = self.refl(sub(right, {variable: S(eigen)}))
        second = self.U(right, variable, variable, name, second_step, params, eigen)
        bridge = self.cong(name, self.refl(variable), base, *(self.refl(p) for p in params))
        return self.trans(first, self.trans(bridge, self.sym(second)))

    def export(self, name, proof):
        self.exports.append({"name": name, "proof": proof, "equation": self.equation(proof),
                             "assumptions": self.contexts[proof]})

    def bundle(self):
        return {"format": "equational-U-v1", "declarations": self.declarations,
                "proofs": self.proofs, "exports": self.exports}


def produce():
    b = Producer()
    b.recursor("add", S("ru"))
    b.recursor("pred_rec", "ri")
    b.macro("pred", ["x"], app("pred_rec", "x", Z))
    b.recursor("sel", "b", ["b"])
    b.recursor("sub", P("ru"))
    b.recursor("identity_rec", "ru")

    # 0+n=n and successor shift for addition (A(n,a)=a+n).
    raw = b.U("n", "n", "n", "add", b.refl(S("z")))
    add_zero = b.sym(raw)
    b.export("zero_plus", add_zero)
    f = S(A("n", "a"))
    rec = b.definitional(sub(f, {"n": S("z")}), S(sub(f, {"n": "z"})))
    raw = b.U(f, "n", "n", "add", rec)
    add_shift = b.trans(raw, b.rewrite(b.equation(raw)[1], b.definition(A(Z, "a"))))
    b.export("addition_successor_shift", add_shift)

    # Selector diagonal, derived endpoint cases expanded to U.
    left = C("r", "v", "v")
    sel_diag = b.cases(left, "v", "r", b.definitional(sub(left, {"r": Z}), "v"),
                      b.definitional(sub(left, {"r": S("z")}), "v"))
    b.export("selector_diagonal", sel_diag)

    # d(Sa,Sn)=d(a,n).
    f = D(S("a"), S("n"))
    rec = b.definitional(sub(f, {"n": S("z")}), P(sub(f, {"n": "z"})))
    raw = b.U(f, "n", "n", "sub", rec)
    initial = b.norm(D(S("a"), S(Z)))
    sub_shift = b.trans(raw, b.rewrite(b.equation(raw)[1], initial))
    b.export("subtraction_successor_shift", sub_shift)

    # Stationarity for d(Sn,n), compared to the constant-one solution.
    f = D(S("n"), "n")
    rec = b.subst(sub_shift, a=S("z"), n="z")
    raw = b.U(f, "n", "n", "identity_rec", rec)
    raw = b.trans(raw, b.rewrite(b.equation(raw)[1], b.norm(D(S(Z), Z))))
    const = b.U(S(Z), "n", "n", "identity_rec", b.refl(S(Z)))
    diagonal = b.trans(raw, b.sym(const))
    b.export("subtraction_diagonal", diagonal)

    # The arbitrary-residual patch used in Ref; no coverage axiom is used.
    l = C(P("r"), "y", A(P("r"), S("n")))
    r = C(P("r"), "y", C("r", "y", A("r", "n")))
    base = b.definitional(sub(l, {"r": Z}), sub(r, {"r": Z}))
    left_s, right_s = sub(l, {"r": S("z")}), sub(r, {"r": S("z")})
    pl, pr = b.norm(left_s), b.norm(right_s)
    shift = b.sym(b.subst(add_shift, n="z", a="n"))
    mid = b.rewrite(b.equation(pl)[1], shift)
    successor = b.trans(pl, b.trans(mid, b.sym(pr)))
    patch = b.cases(l, r, "r", base, successor)
    b.export("residual_step_patch", patch)

    # F_y(n)=y via a common counter-dependent reset recurrence.
    def F(n): return C(D("y", n), "y", A(D("y", n), n))
    H = C(D("cp0", S("ri")), "cp0", "ru")
    b.recursor("residual_rec", H, ["cp0"])
    expected = C(D("y", S("z")), "y", F("z"))
    left, right = F(S("z")), expected
    patch_inst = b.subst(patch, r=D("y", "z"), n="z")
    left_normal = b.definitional(left, b.equation(patch_inst)[0])
    right_normal = b.definitional(b.equation(patch_inst)[1], right)
    recurrence = b.trans(left_normal, b.trans(patch_inst, right_normal))
    f0 = b.norm(F(Z))
    p = b.rewrite(b.equation(f0)[1], b.subst(add_zero, n="y"))
    f0 = b.trans(f0, p)
    f0 = b.trans(f0, b.subst(sel_diag, r="y", v="y"))
    raw = b.U(F("n"), "n", "n", "residual_rec", recurrence, ["y"])
    raw = b.trans(raw, b.rewrite(b.equation(raw)[1], f0))
    const_step = b.sym(b.subst(sel_diag, r=D("y", S("z")), v="y"))
    const = b.U("y", "n", "n", "residual_rec", const_step, ["y"])
    reflection = b.trans(raw, b.sym(const))
    b.export("residual_reflection", reflection)

    # Two selector equations give algebraic extraction of a zero test.
    left = C("q", S("q"), S(Z))
    aux = b.cases(left, S(Z), "q", b.definitional(sub(left, {"q": Z}), S(Z)),
                  b.definitional(sub(left, {"q": S("z")}), S(Z)))
    b.export("selector_successor_patch", aux)
    left = C(k("r"), "r", S(Z))
    base = b.definitional(sub(left, {"r": Z}), S(Z))
    ps = b.norm(sub(left, {"r": S("z")}))
    successor = b.trans(ps, b.subst(aux, q="z"))
    kpatch = b.cases(left, S(Z), "r", base, successor)
    b.export("one_test_extraction_patch", kpatch)
    left = C(sg("r"), "r", Z)
    sgpatch = b.cases(left, Z, "r", b.definitional(sub(left, {"r": Z}), Z),
                      b.definitional(sub(left, {"r": S("z")}), Z))
    b.export("sign_extraction_patch", sgpatch)

    # epsilon(a,a)=0.
    inst = b.subst(diagonal, n="a")
    p = b.chain(eps("a", "a"), inst, inst)
    p = b.trans(p, b.norm(b.equation(p)[1]))
    b.export("equality_reflector_diagonal", p)

    # The contextual direction epsilon(a,b)=0 |- a=b.
    assumption = b.hyp(eps("a", "b"), Z)
    e = k(D(S("a"), "b"))
    q = b.subst(sgpatch, r=e)
    changed = b.rewrite(b.equation(q)[0], assumption)
    # q: C(epsilon,e,0)=0; changed followed by computation gives C(...)=e.
    changed = b.trans(changed, b.definition(b.equation(changed)[1]))
    e_zero = b.trans(b.sym(changed), q)
    q = b.subst(kpatch, r=D(S("a"), "b"))
    changed = b.rewrite(b.equation(q)[0], e_zero)
    changed = b.trans(changed, b.definition(b.equation(changed)[1]))
    residual_one = b.trans(b.sym(changed), q)
    q = b.subst(reflection, y=S("a"), n="b")
    changed = b.chain(b.equation(q)[0], residual_one, residual_one)
    changed = b.trans(changed, b.norm(b.equation(changed)[1]))
    successor_equal = b.trans(b.sym(changed), q)
    pred_equal = b.cong("pred", successor_equal)
    lhs_normal = b.norm(b.equation(pred_equal)[0]); rhs_normal = b.norm(b.equation(pred_equal)[1])
    extracted = b.trans(b.sym(lhs_normal), b.trans(pred_equal, rhs_normal))
    b.export("equality_reflector_sound", b.sym(extracted))

    # The converse direction, retaining only the equation a=b.
    equality_hypothesis = b.hyp("a", "b")
    diagonal_proof = next(e["proof"] for e in b.exports if e["name"] == "equality_reflector_diagonal")
    transported = b.lift(eps("a", "w"), "w", equality_hypothesis)
    complete = b.trans(b.sym(transported), diagonal_proof)
    b.export("equality_reflector_complete", complete)

    return b.bundle()


if __name__ == "__main__":
    target = Path(__file__).with_name("certificates.json")
    bundle = produce()
    target.write_text(json.dumps(bundle, indent=2) + "\n")
    print(json.dumps({"path": target.name, "proof_nodes": len(bundle["proofs"]),
                      "exports": [e["name"] for e in bundle["exports"]]}, indent=2))
