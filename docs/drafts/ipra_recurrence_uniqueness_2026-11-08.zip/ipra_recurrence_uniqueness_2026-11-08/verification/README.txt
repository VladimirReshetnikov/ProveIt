SYMBOLIC EQUATIONAL CERTIFICATES FOR RECURRENCE UNIQUENESS
=======================================================

Purpose and result
------------------
These files provide executable evidence for the arithmetic bootstrap in
report.tex. They are a fragment verifier, NOT a complete first-order iPRA
checker, and are NOT entered in the report's checker-size comparison.

The supplied certificate has 854 proof nodes, including 17 applications
of the one-premise recurrence-uniqueness rule U. It exports 13 sequents:
11 unconditional equations and two equations under an explicit retained
assumption. Eleven targeted invalid modifications are rejected.

Reproduction (Python standard library only)
------------------------------------------
  python3 produce.py
  python3 checker.py certificates.json
  python3 validate.py

produce.py generates the JSON certificate without importing checker.py.
checker.py independently reads the declaration and proof records, computes
the equation and context justified by each inference, and compares them
with the claimed result. validate.py independently states all 13 advertised sequents and requires an
exact match, replays the negative controls, then writes verification_receipt.json. There is no evaluation of
Python source, expression strings, or semantic sample values from input.

Representation and finite signature
-----------------------------------
A term is either a variable name (a string) or a nonempty JSON array
[function_name, argument_1, ...]. The primitive constructors are ["0"]
and ["S", term]. A fixed finite declaration either introduces:

1. a macro with explicitly listed formal parameters and a body using
   previously declared symbols; or
2. a recursor R with counter variable i, state variable u, numerical
   parameters p, and a fixed step term h(i,u,p) over earlier symbols.

The recursor has actual arguments R(n,a,p) and exactly the equations
  R(0,a,p) = a,
  R(Sn,a,p) = h(n,R(n,a,p),p).

The initial value is an ordinary argument. Declarations are staged:
self-reference, unknown symbols, duplicate binders, undeclared free
parameters, and incorrect arities reject. A recursor description is not
a numerical program code and is never evaluated by a universal evaluator.
Substitution is ordinary first-order simultaneous substitution; fixed
recursor indices are separate declarations, so no term-level binder is
traversed or captured.

The base declarations are:
  A(n,a)       = add(n,a),       with update S(u);
  pred_rec     with update i;    P(n) = pred_rec(n,0);
  C(n,a,b)     = sel(n,a,b),     with update b;
  d(a,n)       = sub(n,a),       with update P(u);
  identity_rec with update u.
Thus A(n,a) means a+n. The presentation uses the convention a+b=A(b,a).
The remaining declarations are five recursors for expanded endpoint-case
arguments and one counter-dependent residual recursor. They add no axioms
beyond their displayed defining equations.

Exact trusted proof rules
-------------------------
- Reflexivity of equality.
- An explicitly retained equation hypothesis.
- One instance of a declared macro or a recursor computation equation.
- Symmetry, transitivity, function congruence, and simultaneous numerical
  substitution of already checked equation sequents.
- Context weakening (used by a freshness negative control).
- The one-premise rule U, described below.

There are NO trusted induction, coverage, separation, Boolean-range,
case-splitting, order, reflection, or full first-order logical rules.

For a fixed term f(x), recursor R_h, numerical parameters p, and fresh z,
U checks the exact premise
  Gamma |- f(Sz) = h(z,f(z),p)
and returns
  Gamma |- f(t) = R_h(t,f(0),p).
The verifier computes f(0) itself; a certificate cannot choose it.
The eigenvariable z must be absent from Gamma, t, p, and the other free
variables of f. Retained contexts are propagated by the verifier and
compared with each exported sequent's declared assumptions. U discharges
no equation assumptions.

Every use of endpoint equation cases is expanded into U. From
  f(0)=g(0) and f(Sz)=g(Sz),
the producer declares h(i,u,p)=g(Si,p), independently of u. U applied to
f and to g yields equalities with the same recursor and equal initial
values. Congruence and transitivity conclude f(x)=g(x). The verifier does
not have an endpoint-case rule or import this argument as an oracle.

Exported sequents
-----------------
Write 1=S0, sg(r)=C(r,0,1), k(r)=C(r,1,P(r)), and
  epsilon(a,b)=sg(k(d(Sa,b))).
The exported names and exact mathematical conclusions are:

zero_plus:
  A(n,0)=n.

addition_successor_shift:
  S(A(n,a))=A(n,Sa).

selector_diagonal:
  C(r,v,v)=v.

subtraction_successor_shift:
  d(Sa,Sn)=d(a,n).

subtraction_diagonal:
  d(Sn,n)=1.

residual_step_patch:
  C(P(r),y,Sn+P(r))
    = C(P(r),y,C(r,y,n+r)).

residual_reflection:
  C(d(y,n),y,n+d(y,n))=y.

selector_successor_patch:
  C(q,Sq,1)=1.

one_test_extraction_patch:
  C(k(r),r,1)=1.

sign_extraction_patch:
  C(sg(r),r,0)=0.

equality_reflector_diagonal:
  epsilon(a,a)=0.

equality_reflector_sound:
  epsilon(a,b)=0 |- a=b.

equality_reflector_complete:
  a=b |- epsilon(a,b)=0.

The last two exports retain exactly the displayed equation; the other
exports have empty contexts. All variables remain symbolic. In particular,
the residual identity is certified for arbitrary y and n, not tested on
a bounded range of natural numbers.

Negative controls
-----------------
validate.py changes the reflection RHS, changes a U recurrence, changes
its claimed initializer, violates freshness in the target and retained
context, inserts a forward reference, makes a recursor declaration
circular, inserts an undeclared description parameter, omits a required
retained assumption, requests an unlisted case oracle, and replaces an export
by a valid proof of the wrong theorem. Every mutation is rejected. These controls exercise the claimed trust boundary; their
success is not a formal proof of verifier correctness.

Limits
------
The small verifier and its implementation of the listed equational rules
remain trusted. No Lean or Rocq formalization is claimed. This certificate
does not check ordinary intuitionistic logical reasoning, coverage and
separation, the characteristic-term construction for all quantifier-free
formulas, the full induction simulation, or the two interpretation
composites. Those are written mathematical proofs in the report. The
certificate supplies the central algebraic steps needed by those proofs.
The producer's normalizer only unfolds syntactic definitions and proved
rewrites; it is outside the trusted acceptance path.
