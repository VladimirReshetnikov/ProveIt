"""Readable verifier for a finite equational/U-rule certificate language.

This is a fragment verifier, not a complete iPRA proof checker and not a
competitor in the report's source-size table. It never evaluates Python
from a certificate. See README.txt for the exact trusted mathematical rules.
"""
from __future__ import annotations
import json
import re
import sys
from pathlib import Path


class InvalidCertificate(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise InvalidCertificate(message)


def variable(name):
    return isinstance(name, str) and re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", name) is not None


def free(term):
    if isinstance(term, str):
        return {term}
    return set().union(*(free(arg) for arg in term[1:])) if len(term) > 1 else set()


def substitute(term, images):
    if isinstance(term, str):
        return images.get(term, term)
    return [term[0], *(substitute(arg, images) for arg in term[1:])]


def merge_contexts(*contexts):
    out = []
    for context in contexts:
        for equation in context:
            if equation not in out:
                out.append(equation)
    return out


class Verifier:
    def __init__(self, declarations):
        self.arity = {"0": 0, "S": 1}
        self.declarations = {}
        self.results = []
        self.counts = {}
        require(isinstance(declarations, list), "declarations must be an array")
        for declaration in declarations:
            self.declare(declaration)

    def term(self, term):
        if isinstance(term, str):
            require(variable(term), "invalid variable name")
            return
        require(type(term) is list and term, "term must be a variable or nonempty array")
        symbol = term[0]
        require(isinstance(symbol, str) and symbol in self.arity, "unknown function symbol")
        require(len(term) == self.arity[symbol] + 1, "wrong function arity")
        for argument in term[1:]:
            self.term(argument)

    def equation(self, equation):
        require(type(equation) is list and len(equation) == 2, "equation needs two terms")
        for term in equation:
            self.term(term)

    def declare(self, declaration):
        require(type(declaration) is dict, "declaration must be an object")
        kind, name = declaration.get("kind"), declaration.get("name")
        require(variable(name) and name not in self.arity, "duplicate or invalid symbol")
        parameters = declaration.get("parameters")
        require(type(parameters) is list and all(variable(p) for p in parameters), "invalid parameters")
        require(len(set(parameters)) == len(parameters), "repeated parameter")
        if kind == "macro":
            body = declaration.get("body")
            self.term(body)
            require(free(body) <= set(parameters), "free variable in macro")
            self.arity[name] = len(parameters)
        elif kind == "recursor":
            counter, state = declaration.get("counter"), declaration.get("state")
            require(variable(counter) and variable(state), "invalid recursor binders")
            require(len(set(parameters + [counter, state])) == len(parameters) + 2, "binder collision")
            body = declaration.get("step")
            self.term(body)
            require(free(body) <= set(parameters + [counter, state]), "free variable in update")
            self.arity[name] = len(parameters) + 2
        else:
            raise InvalidCertificate("unknown declaration kind")
        self.declarations[name] = declaration

    def prior(self, index):
        require(type(index) is int and 0 <= index < len(self.results), "invalid or forward proof reference")
        return self.results[index]

    def derive(self, node):
        require(type(node) is dict, "proof node must be an object")
        rule = node.get("rule")
        context = []
        if rule == "refl":
            self.term(node.get("term"))
            equation = [node["term"], node["term"]]
        elif rule == "hyp":
            equation = node.get("equation")
            self.equation(equation)
            context = [equation]
        elif rule == "def":
            term = node.get("term")
            self.term(term)
            require(type(term) is list and term[0] in self.declarations, "not a declared function")
            declaration = self.declarations[term[0]]
            if declaration["kind"] == "macro":
                result = substitute(declaration["body"], dict(zip(declaration["parameters"], term[1:])))
            else:
                counter, initial, *parameters = term[1:]
                images = dict(zip(declaration["parameters"], parameters))
                if counter == ["0"]:
                    result = initial
                else:
                    require(type(counter) is list and len(counter) == 2 and counter[0] == "S", "recursor counter is not a constructor")
                    images[declaration["counter"]] = counter[1]
                    images[declaration["state"]] = [term[0], counter[1], initial, *parameters]
                    result = substitute(declaration["step"], images)
            equation = [term, result]
        elif rule == "sym":
            old, context = self.prior(node.get("proof"))
            equation = [old[1], old[0]]
        elif rule == "trans":
            left, left_context = self.prior(node.get("left"))
            right, right_context = self.prior(node.get("right"))
            require(left[1] == right[0], "transitivity middle terms disagree")
            equation = [left[0], right[1]]
            context = merge_contexts(left_context, right_context)
        elif rule == "cong":
            symbol = node.get("symbol")
            premises = node.get("proofs")
            require(symbol in self.arity and type(premises) is list and len(premises) == self.arity[symbol], "invalid congruence")
            checked = [self.prior(p) for p in premises]
            equation = [[symbol, *(e[0] for e, _ in checked)], [symbol, *(e[1] for e, _ in checked)]]
            context = merge_contexts(*(c for _, c in checked))
        elif rule == "subst":
            old, old_context = self.prior(node.get("proof"))
            images = node.get("images")
            require(type(images) is dict and all(variable(x) for x in images), "invalid substitution")
            for image in images.values():
                self.term(image)
            equation = [substitute(t, images) for t in old]
            context = [[substitute(t, images) for t in e] for e in old_context]
        elif rule == "weaken":
            equation, old_context = self.prior(node.get("proof"))
            extra = node.get("assumptions")
            require(type(extra) is list, "invalid weakening context")
            for e in extra:
                self.equation(e)
            context = merge_contexts(old_context, extra)
        elif rule == "U":
            recurrence, context = self.prior(node.get("proof"))
            name = node.get("recursor")
            declaration = self.declarations.get(name)
            require(declaration is not None and declaration["kind"] == "recursor", "U requires a declared recursor")
            x, z = node.get("variable"), node.get("eigen")
            require(variable(x) and variable(z) and x != z, "invalid U variable/eigenvariable")
            body, target, parameters = node.get("body"), node.get("target"), node.get("parameters")
            self.term(body)
            self.term(target)
            require(type(parameters) is list and len(parameters) == len(declaration["parameters"]), "wrong U parameter count")
            for parameter in parameters:
                self.term(parameter)
            forbidden = free(body) - {x}
            forbidden |= free(target)
            forbidden |= set().union(*(free(p) for p in parameters)) if parameters else set()
            forbidden |= set().union(*(free(t) for e in context for t in e)) if context else set()
            require(z not in forbidden, "U eigenvariable is not fresh")
            initial = substitute(body, {x: ["0"]})
            previous = substitute(body, {x: z})
            next_value = substitute(body, {x: ["S", z]})
            images = dict(zip(declaration["parameters"], parameters))
            images[declaration["counter"]] = z
            images[declaration["state"]] = previous
            expected = [next_value, substitute(declaration["step"], images)]
            require(recurrence == expected, "U premise is not the required recurrence")
            equation = [substitute(body, {x: target}), [name, target, initial, *parameters]]
        else:
            raise InvalidCertificate("unknown proof rule")
        self.equation(equation)
        require(node.get("equation") == equation, "claimed equation does not match inference")
        self.counts[rule] = self.counts.get(rule, 0) + 1
        self.results.append((equation, context))

    def run(self, bundle):
        nodes = bundle.get("proofs")
        require(type(nodes) is list, "proofs must be an array")
        for index, node in enumerate(nodes):
            try:
                self.derive(node)
            except (InvalidCertificate, KeyError, TypeError, IndexError) as exc:
                raise InvalidCertificate(f"node {index}: {exc}") from exc
        exports = bundle.get("exports")
        require(type(exports) is list and exports, "exports must be nonempty")
        names = set()
        for export in exports:
            require(type(export) is dict and variable(export.get("name")), "bad export name")
            require(export["name"] not in names, "duplicate export")
            names.add(export["name"])
            equation, context = self.prior(export.get("proof"))
            require(export.get("equation") == equation, "export equation mismatch")
            require(export.get("assumptions") == context, "export context mismatch")
        return {"status": "PASS", "proof_nodes": len(nodes), "declarations": len(self.declarations),
                "exports": len(exports), "rules": self.counts,
                "closed_exports": sum(not e["assumptions"] for e in exports)}


def verify(bundle):
    require(type(bundle) is dict and bundle.get("format") == "equational-U-v1", "unsupported certificate format")
    return Verifier(bundle.get("declarations")).run(bundle)


if __name__ == "__main__":
    try:
        path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("certificates.json")
        result = verify(json.loads(path.read_text()))
        print(json.dumps(result, indent=2))
    except (InvalidCertificate, ValueError, OSError, KeyError, TypeError, IndexError, RecursionError) as exc:
        print(json.dumps({"status": "REJECT", "reason": str(exc)}, indent=2))
        raise SystemExit(1)
