THREE FIXED AUTONOMOUS UPDATES: SYMBOLIC CERTIFICATE
=================================================

Scope and result
----------------
This separate certificate verifies the signed-clock arithmetic bootstrap
for the three-update theory U_3. It preserves the parent directory's pure
unrestricted-U certificate unchanged.

The bundle contains 1,415 symbolic proof nodes and 15 exact exported
sequents. There are nine uniqueness applications: four with identity,
two with successor, and three with B. Six equation-case inferences are
explicitly charged to numerical coverage. Thirteen exports are closed;
two retain the single displayed equation assumption. Twelve targeted
invalid modifications are rejected.

This is a finite arithmetic FRAGMENT VERIFIER. It is neither a complete
first-order iPRA checker nor a competitor in the source-size table.

Reproduction (Python standard library only)
------------------------------------------
  python3 produce.py
  python3 checker.py certificates.json
  python3 validate.py

The producer does not import the verifier. The verifier reads declarative
JSON, computes the consequence of every inference, checks its claimed
formula, and propagates retained equation contexts. validate.py separately
specifies and checks all ten fixed declarations and all fifteen advertised
equations and contexts. It then replays negative controls and writes the
receipt. No numerical sampling, Python evaluation of input, or proof
assistant is involved.

Finite fixed descriptions
-------------------------
Terms use variables, 0, S, and finite staged primitive-recursive symbols.
The JSON grammar and basic equality rules are the same as in the parent
certificate. Each recursor R(n,a,p) has equations
  R(0,a,p)=a,
  R(Sn,a,p)=h(n,R(n,a,p),p),
for its explicitly declared earlier-stage step h. Arbitrary initial values
are ordinary numerical arguments. No program-code evaluator is used.

The ten declarations describe:
  P(n)       via the counter update i and initializer 0;
  C(n,a,b)   via the constant update b and initializer a;
  D(n)       via update S(Su) and initializer 0;
  E(n)       via update delta(u)=C(u,1,0) and initializer 0;
  H(n)       via update C(E(i),u,Su) and initializer 0;
  B(x)       = C(E(x),S(Sx),P(Px));
  N(x)       = C(x,0,S(D(Px)));
  I_S(n,a), I_id(n,a), I_B(n,a).

Thus D(0)=0, D(Sn)=S(S(D(n))), E(0)=0,
E(Sn)=delta(E(n)), H(0)=0, and
  H(Sn)=C(E(n),H(n),S(H(n))).
The half description reads its counter. It is an ordinary retained
primitive-recursive definition; no uniqueness rule for it is available.
Likewise D and E have their defining equations, but uniqueness with their
updates S^2 or delta is NOT permitted.

Exact uniqueness restriction
----------------------------
The checker has no general U rule. Its A inference requires one of exactly
these three declared updates:
  successor_iter: u |-> Su,
  identity_iter:  u |-> u,
  B_iter:         u |-> B(u).
It checks that the declaration has no passive parameters, its step has
no free variable other than the state, and it matches the specified fixed
update. Counter-dependent updates, passive parameters, and even other
closed unary updates such as S^2 reject.

For a fixed term f(x,p), numerical target t, and fresh z, the rule checks
  Gamma |- f(Sz,p)=h(f(z,p))
and returns
  Gamma |- f(t,p)=I_h(t,f(0,p)).
The numerical parameters p may occur in f and its initial value; they do
not occur in h. The verifier computes f(0,p). The eigenvariable must be
absent from all retained assumptions, t, and the fixed parameters.

Explicit coverage charge
------------------------
Unlike the pure-U certificate in the parent directory, this certificate
uses a trusted DERIVED equation-case rule:
  Gamma |- l(0)=r(0),
  Gamma |- l(Sz)=r(Sz)
  --------------------------------
  Gamma |- l(t)=r(t).
There is NO induction hypothesis. The verifier checks both exact premises
and the eigenvariable conditions, including the retained context.

This rule is justified from the separately charged numerical coverage
axiom t=0 or exists z, t=Sz, using ordinary intuitionistic disjunction and
existential elimination followed by equality substitution. It is not
claimed to follow from the three uniqueness rules in pure equational
logic. The artifact implements this derived rule directly; it does not
implement the full ordinary logical derivation of coverage cases.

Every parity-based equation split is expanded into two such endpoint-case
inferences. First, delta(r) takes only its computed endpoint values. Next,
E(0)=0 and E(Sn)=delta(E(n)) transfer the same equation to E(n). There is
no Boolean-range or parity oracle, and no induction on a disjunction.

Other trusted rules
-------------------
Reflexivity, an explicit equation hypothesis, one declared defining-
equation instance, symmetry, transitivity, function congruence,
simultaneous substitution, and context weakening are the remaining rules.
No induction, separation, inverse permutation Q, equality-reflection axiom,
semantic evaluation, or full first-order logical checker is imported.

Exact exported sequents
-----------------------
Write I=I_B, sg(r)=C(r,0,1), and epsilon_3(a,b)=sg(I(a,N(b))).
The following thirteen equations have empty retained contexts:

parity_two_step:            E(S(Sn))=E(n).
parity_of_double:           E(D(n))=0.
parity_of_odd_code:         E(S(D(n)))=1.
half_two_step:              H(S(Sn))=S(H(n)).
half_of_double:             H(D(n))=n.
B_positive_clock_step:      B(D(n))=D(Sn).
B_negative_clock_step:      B(N(Sn))=N(n).
B_commutes_with_iteration:  B(I(n,a))=I(n,B(a)).
iterates_commute:           I(k,I(n,a))=I(n,I(k,a)).
negative_clock_cancellation:I(n,N(n))=0.
positive_clock:             I(n,0)=D(n).
sign_extraction_patch:     C(sg(r),r,0)=0.
signed_reflector_diagonal: epsilon_3(a,a)=0.

The last two exports are the exact contextual directions:
  signed_reflector_sound:
    epsilon_3(a,b)=0 |- a=b.
  signed_reflector_complete:
    a=b |- epsilon_3(a,b)=0.

All variables remain symbolic. The certificate does not infer an identity
from evaluation on a bounded set of natural numbers.

Proof architecture
------------------
Parity and the half equations give H(D(n))=n, hence an internal way to
cancel doubled values. The map B has a positive clock D and a backward
clock N. Uniqueness with B proves commutation with its own iterates and
commutation between two iterates. The composite I(n,N(n)) is stationary,
so uniqueness with identity makes it zero. The positive clock follows
from uniqueness with B. Applying a second iterate to a sign-zero equation,
commuting the two iterates, and then applying H recovers numerical equality.
No global inverse of B is needed in this derivation.

Negative controls and limits
----------------------------
Controls alter a reflector RHS, request a counter-dependent update,
request a passive-parameter update, request the unpermitted closed update
S^2, invoke unrestricted U, change an initializer, violate uniqueness
freshness in target or context, alter an endpoint premise, violate case
freshness, omit a retained assumption, and replace an advertised theorem
by a valid proof of the wrong equation. All twelve reject.

The verifier implementation and the stated coverage-derived case rule
remain trusted; finite negative controls are not a formal proof of the
implementation. No Lean or Rocq verification is claimed. The artifact does
not certify the full Boolean characteristic compiler, saturating-latch
induction simulation, all logical rules, or the interpretation composites.
Those are written mathematical arguments in the report. This artifact
certifies their central three-update arithmetic reflection construction.
