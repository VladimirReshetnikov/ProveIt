"""Independent advertised-goal checks and adversarial controls for U_2."""
import copy
import hashlib
import json
from collections import Counter
from pathlib import Path
from checker import InvalidCertificate, verify

ROOT = Path(__file__).resolve().parent
bundle = json.loads((ROOT / "certificates.json").read_text())
Z = ["0"]
def S(x): return ["S", x]
def C(x, a, b): return ["sel", x, a, b]
def P(x): return ["pred", x, Z]
def D(x): return ["double", x, Z]
def E(x): return ["parity", x, Z]
def H(x): return ["half", x, Z]
def B(x): return ["B", x]
def N(x): return ["N", x]
def I(n, a): return ["B_iter", n, a]
def sg(x): return C(x, Z, S(Z))
def eps(a, b): return sg(I(a, N(b)))

def rec(name, step, parameters=()):
    return {"kind": "recursor", "name": name, "counter": "ri", "state": "ru",
            "parameters": list(parameters), "step": step}
def macro(name, body):
    return {"kind": "macro", "name": name, "parameters": ["x"], "body": body}

EXPECTED_DECLARATIONS = [
    rec("pred", "ri"), rec("sel", "b", ["b"]),
    rec("double", S(S("ru"))), rec("parity", C("ru", S(Z), Z)),
    rec("half", C(E("ri"), "ru", S("ru"))),
    macro("B", C(E("x"), S(S("x")), P(P("x")))),
    macro("N", C("x", Z, S(D(P("x"))))),
    rec("successor_iter", S("ru")), rec("B_iter", B("ru")),
    rec("stationary_zero_reset_1", C(E(D("ru")), S("ru"), Z)),
    rec("stationary_zero_reset_2", C(I("ru", N("ru")), S("ru"), Z)),
]
EXPECTED = {
    "parity_two_step": ([E(S(S("n"))), E("n")], []),
    "parity_of_double": ([E(D("n")), Z], []),
    "parity_of_odd_code": ([E(S(D("n"))), S(Z)], []),
    "half_two_step": ([H(S(S("n"))), S(H("n"))], []),
    "half_of_double": ([H(D("n")), "n"], []),
    "B_positive_clock_step": ([B(D("n")), D(S("n"))], []),
    "B_negative_clock_step": ([B(N(S("n"))), N("n")], []),
    "B_commutes_with_iteration": ([B(I("n", "a")), I("n", B("a"))], []),
    "iterates_commute": ([I("k", I("n", "a")), I("n", I("k", "a"))], []),
    "negative_clock_cancellation": ([I("n", N("n")), Z], []),
    "positive_clock": ([I("n", Z), D("n")], []),
    "sign_extraction_patch": ([C(sg("r"), "r", Z), Z], []),
    "signed_reflector_diagonal": ([eps("a", "a"), Z], []),
    "signed_reflector_sound": (["a", "b"], [[eps("a", "b"), Z]]),
    "signed_reflector_complete": ([eps("a", "b"), Z], [["a", "b"]]),
}


def verify_scope(candidate):
    result = verify(candidate)
    if candidate["declarations"] != EXPECTED_DECLARATIONS:
        raise InvalidCertificate("fixed primitive-recursive descriptions differ from the advertised theory")
    actual = {e["name"]: (e["equation"], e["assumptions"]) for e in candidate["exports"]}
    if actual != EXPECTED:
        raise InvalidCertificate("exported sequents differ from the independently stated obligations")
    return result


receipt = verify_scope(bundle)
controls = []
first_a = next(i for i, n in enumerate(bundle["proofs"]) if n["rule"] == "A")
first_case = next(i for i, n in enumerate(bundle["proofs"]) if n["rule"] == "cases")


def reject(name, change):
    malformed = copy.deepcopy(bundle)
    change(malformed)
    try:
        verify_scope(malformed)
    except InvalidCertificate as exc:
        controls.append({"name": name, "status": "REJECTED", "reason": str(exc)})
    else:
        raise AssertionError(f"invalid certificate accepted: {name}")


def wrong_rhs(b):
    export = next(e for e in b["exports"] if e["name"] == "signed_reflector_sound")
    b["proofs"][export["proof"]]["equation"][1] = S("b")
reject("changed_reflector_rhs", wrong_rhs)


def counter_update(b):
    b["proofs"][first_a]["recursor"] = "pred"
reject("counter_dependent_uniqueness_update", counter_update)


def parameter_update(b):
    b["proofs"][first_a]["recursor"] = "sel"
reject("passive_parameter_in_uniqueness_update", parameter_update)


def fourth_update(b):
    b["proofs"][first_a]["recursor"] = "double"
reject("unpermitted_closed_unary_update_SS", fourth_update)


def unrestricted_u(b):
    b["proofs"][first_a]["rule"] = "U"
reject("unrestricted_U_rule", unrestricted_u)


def identity_update(b):
    b["declarations"].append(rec("identity_iter", "ru"))
    b["proofs"][first_a]["recursor"] = "identity_iter"
reject("identity_uniqueness_not_permitted", identity_update)


def reset_update(b):
    b["proofs"][first_a]["recursor"] = "stationary_zero_reset_1"
reject("reset_uniqueness_not_permitted", reset_update)


def wrong_initial(b):
    b["proofs"][first_a]["equation"][1][2] = S(Z)
reject("changed_uniqueness_initializer", wrong_initial)


def target_capture(b):
    b["proofs"][first_a]["target"] = "z"
reject("uniqueness_eigenvariable_in_target", target_capture)


def context_capture(b):
    original = copy.deepcopy(b["proofs"][first_a])
    premise = original["proof"]
    weakened = {"rule": "weaken", "proof": premise, "assumptions": [["z", "z"]],
                "equation": copy.deepcopy(b["proofs"][premise]["equation"])}
    original["proof"] = len(b["proofs"])
    b["proofs"].append(weakened)
    b["proofs"].append(original)
reject("uniqueness_eigenvariable_in_retained_context", context_capture)


def wrong_case(b):
    b["proofs"][first_case]["base"] = b["proofs"][first_case]["step"]
reject("wrong_endpoint_case_premise", wrong_case)


def case_capture(b):
    b["proofs"][first_case]["target"] = "z"
reject("case_eigenvariable_in_target", case_capture)


def missing_assumption(b):
    export = next(e for e in b["exports"] if e["name"] == "signed_reflector_sound")
    export["assumptions"] = []
reject("omitted_reflector_assumption", missing_assumption)


def wrong_valid_export(b):
    export = next(e for e in b["exports"] if e["name"] == "signed_reflector_diagonal")
    proof = next(i for i, n in enumerate(b["proofs"]) if n["rule"] == "refl")
    export.update(proof=proof, equation=copy.deepcopy(b["proofs"][proof]["equation"]), assumptions=[])
reject("valid_proof_of_wrong_advertised_theorem", wrong_valid_export)

receipt["expected_declarations"] = "all 11 fixed descriptions matched exactly"
receipt["expected_exported_sequents"] = "all 15 matched exactly"
receipt["uniqueness_updates"] = dict(Counter(n["recursor"] for n in bundle["proofs"] if n["rule"] == "A"))
receipt["negative_controls"] = controls
receipt["rejected_negative_controls"] = len(controls)
receipt["source_sha256"] = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                             for name in ("checker.py", "produce.py", "certificates.json")}
receipt["scope"] = ("Finite symbolic equations with uniqueness restricted to S and B. "
                    "Endpoint equation cases are an explicit trusted derived rule charged to numerical "
                    "coverage. Zero stationarity is expanded through two checked reset descriptions. No general U, identity uniqueness, induction, Q inverse, semantic sample evaluation, or full "
                    "first-order checker is imported. Not a complete iPRA checker or size competitor.")
(ROOT / "verification_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
