"""Construct autonomous signed-arithmetic certificates without importing the verifier."""
from __future__ import annotations
import json
from pathlib import Path

Z = ["0"]
def S(t): return ["S", t]
def app(f, *args): return [f, *args]
def C(n, a, b): return app("sel", n, a, b)
def sg(n): return C(n, Z, S(Z))

def sub(t, images):
    return images.get(t, t) if isinstance(t, str) else [t[0], *(sub(a, images) for a in t[1:])]

def fv(t):
    return {t} if isinstance(t, str) else set().union(*(fv(a) for a in t[1:])) if len(t) > 1 else set()


class Producer:
    def __init__(self):
        self.declarations = []
        self.definitions = {}
        self.proofs = []
        self.contexts = []
        self.exports = []
        self.case_count = 0

    def declare(self, d):
        self.declarations.append(d)
        self.definitions[d["name"]] = d

    def recursor(self, name, step, parameters=()):
        self.declare({"kind": "recursor", "name": name, "counter": "ri", "state": "ru",
                      "parameters": list(parameters), "step": step})

    def macro(self, name, parameters, body):
        self.declare({"kind": "macro", "name": name, "parameters": list(parameters), "body": body})

    def emit(self, rule, equation, context=(), **data):
        number = len(self.proofs)
        self.proofs.append({"rule": rule, **data, "equation": equation})
        self.contexts.append(list(context))
        return number

    def equation(self, p): return self.proofs[p]["equation"]

    def union(self, *proofs):
        out = []
        for p in proofs:
            for e in self.contexts[p]:
                if e not in out: out.append(e)
        return out

    def refl(self, t): return self.emit("refl", [t, t], term=t)
    def hyp(self, a, b): return self.emit("hyp", [a, b], [[a, b]])
    def sym(self, p):
        a, b = self.equation(p)
        return self.emit("sym", [b, a], self.contexts[p], proof=p)

    def trans(self, p, q):
        a, b = self.equation(p); c, d = self.equation(q)
        if b != c: raise ValueError(f"producer transitivity mismatch: {b} != {c}")
        return self.emit("trans", [a, d], self.union(p, q), left=p, right=q)

    def cong(self, symbol, *proofs):
        pairs = [self.equation(p) for p in proofs]
        return self.emit("cong", [[symbol, *(p[0] for p in pairs)], [symbol, *(p[1] for p in pairs)]],
                         self.union(*proofs), symbol=symbol, proofs=list(proofs))

    def subst(self, p, **images):
        equation = [sub(t, images) for t in self.equation(p)]
        context = [[sub(t, images) for t in e] for e in self.contexts[p]]
        return self.emit("subst", equation, context, proof=p, images=images)

    def definition(self, term):
        decl = self.definitions[term[0]]
        if decl["kind"] == "macro":
            right = sub(decl["body"], dict(zip(decl["parameters"], term[1:])))
        else:
            n, initial, *parameters = term[1:]
            if n == Z:
                right = initial
            else:
                if not (isinstance(n, list) and len(n) == 2 and n[0] == "S"):
                    raise ValueError("producer requested nonconstructor computation")
                images = dict(zip(decl["parameters"], parameters))
                images["ri"] = n[1]
                images["ru"] = app(term[0], n[1], initial, *parameters)
                right = sub(decl["step"], images)
        return self.emit("def", [term, right], term=term)

    def norm(self, term):
        if isinstance(term, str) or len(term) == 1:
            return self.refl(term)
        children = [self.norm(a) for a in term[1:]]
        result = self.cong(term[0], *children)
        current = self.equation(result)[1]
        if current[0] in self.definitions:
            decl = self.definitions[current[0]]
            n = current[1]
            if decl["kind"] == "macro" or n == Z or (isinstance(n, list) and n and n[0] == "S"):
                first = self.definition(current)
                rest = self.norm(self.equation(first)[1])
                result = self.trans(result, self.trans(first, rest))
        return result

    def definitional(self, left, right):
        p, q = self.norm(left), self.norm(right)
        if self.equation(p)[1] != self.equation(q)[1]:
            raise ValueError(f"different normal forms: {self.equation(p)[1]} / {self.equation(q)[1]}")
        return self.trans(p, self.sym(q))

    def rewrite(self, term, proof):
        left, right = self.equation(proof)
        if term == left:
            return proof
        if isinstance(term, list):
            for i, child in enumerate(term[1:]):
                try:
                    changed = self.rewrite(child, proof)
                except LookupError:
                    continue
                parts = [self.refl(t) for t in term[1:]]
                parts[i] = changed
                return self.cong(term[0], *parts)
        raise LookupError(f"no occurrence of {left} in {term}")

    def lift(self, template, variable, proof):
        """Congruence for every occurrence of one named template variable."""
        if template == variable:
            return proof
        if isinstance(template, str) or len(template) == 1:
            return self.refl(template)
        return self.cong(template[0], *(self.lift(t, variable, proof) for t in template[1:]))

    def chain(self, start, *rewrites):
        proof = self.refl(start)
        for rewrite in rewrites:
            proof = self.trans(proof, self.rewrite(self.equation(proof)[1], rewrite))
        return proof

    def A(self, body, variable, target, recursor, premise, parameters=(), eigen="z"):
        initial = sub(body, {variable: Z})
        right = app(recursor, target, initial, *parameters)
        return self.emit("A", [sub(body, {variable: target}), right], self.contexts[premise],
                         body=body, variable=variable, target=target, recursor=recursor,
                         proof=premise, parameters=list(parameters), eigen=eigen)

    def cases(self, left, right, variable, base, successor, eigen="z"):
        """Endpoint equation cases, explicitly derived from charged coverage."""
        return self.emit("cases", [left, right], self.union(base, successor),
                         left=left, right=right, variable=variable, target=variable,
                         eigen=eigen, base=base, step=successor)

    def stationary(self, body, variable, recurrence, eigen="z"):
        """Zero stationarity from successor uniqueness and explicit coverage cases.

        This routine adds a fixed reset recursor; it never invokes uniqueness
        for that recursor, identity, or any update except successor.
        """
        initial = sub(body, {variable: Z})
        initial_zero = self.norm(initial)
        if self.equation(initial_zero)[1] != Z:
            raise ValueError("this construction requires a computed zero initial value")
        if fv(body) - {variable}:
            raise ValueError("the two supplied zero-stationarity instances are closed unary")
        self.case_count += 1
        name = f"stationary_zero_reset_{self.case_count}"
        self.recursor(name, C(sub(body, {variable: "ru"}), S("ru"), Z))
        def q(x): return app(name, x, Z)
        def r(x): return sub(body, {variable: x})

        # Arbitrary unary terms preserve the selector, by coverage alone.
        v, a, c = "selector_v", "selector_a", "selector_b"
        left, right = r(C(v, a, c)), C(v, r(a), r(c))
        base = self.auto(sub(left, {v: Z}), sub(right, {v: Z}))
        step = self.auto(sub(left, {v: S(eigen)}), sub(right, {v: S(eigen)}))
        hom = self.cases(left, right, v, base, step, eigen)
        annihilator = self.cases(C(v, v, Z), Z, v,
                                self.auto(C(Z, Z, Z), Z),
                                self.auto(C(S(eigen), S(eigen), Z), Z), eigen)

        # r(q(Sz))=0, with no hypothesis about r(q(z)).
        qz = q(eigen)
        step_zero = self.lift(body, variable, self.definition(q(S(eigen))))
        step_zero = self.trans(step_zero, self.subst(hom, **{v: r(qz), a: S(qz), c: Z}))
        stationary_instance = self.subst(recurrence, **{eigen: qz})
        step_zero = self.trans(step_zero, self.rewrite(self.equation(step_zero)[1], stationary_instance))
        step_zero = self.trans(step_zero, self.rewrite(self.equation(step_zero)[1], initial_zero))
        step_zero = self.trans(step_zero, self.subst(annihilator, **{v: r(qz)}))
        zero_along_reset = self.cases(r(q(variable)), Z, variable,
                                     self.auto(r(q(Z)), Z), step_zero, eigen)

        # The reset therefore never fires; successor uniqueness gives q(n)=n.
        step = self.definition(q(S(eigen)))
        step = self.trans(step, self.rewrite(self.equation(step)[1],
                                            self.subst(zero_along_reset, **{variable: eigen})))
        step = self.trans(step, self.definition(self.equation(step)[1]))
        first = self.A(q(variable), variable, variable, "successor_iter", step, eigen=eigen)
        first = self.trans(first, self.rewrite(self.equation(first)[1], self.definition(q(Z))))
        identity_clock = self.A(variable, variable, variable, "successor_iter",
                                self.refl(S(eigen)), eigen=eigen)
        reset_is_identity = self.trans(first, self.sym(identity_clock))
        transported = self.lift(body, variable, reset_is_identity)
        return self.trans(self.sym(transported), zero_along_reset)

    def normalize_with(self, term, lemmas):
        def match(pattern, actual, images):
            if isinstance(pattern, str):
                if pattern in images:
                    return images[pattern] == actual
                images[pattern] = actual
                return True
            return (isinstance(actual, list) and len(pattern) == len(actual)
                    and pattern[0] == actual[0]
                    and all(match(p, a, images) for p, a in zip(pattern[1:], actual[1:])))
        for lemma in lemmas:
            if self.contexts[lemma]:
                raise ValueError("automatic rewrite lemmas must be unconditional")
            left, right = self.equation(lemma)
            if isinstance(left, str):
                continue
            images = {}
            if match(left, term, images) and sub(right, images) != term:
                first = self.subst(lemma, **images)
                return self.trans(first, self.normalize_with(self.equation(first)[1], lemmas))
        if isinstance(term, str) or len(term) == 1:
            return self.refl(term)
        decl = self.definitions.get(term[0])
        n = term[1]
        if decl and (decl["kind"] == "macro" or n == Z or (isinstance(n, list) and n and n[0] == "S")):
            first = self.definition(term)
            return self.trans(first, self.normalize_with(self.equation(first)[1], lemmas))
        children = [self.normalize_with(a, lemmas) for a in term[1:]]
        first = self.cong(term[0], *children)
        current = self.equation(first)[1]
        if current != term:
            return self.trans(first, self.normalize_with(current, lemmas))
        return first

    def auto(self, left, right, lemmas=()):
        p = self.normalize_with(left, lemmas)
        q = self.normalize_with(right, lemmas)
        if self.equation(p)[1] != self.equation(q)[1]:
            raise ValueError("different auto normal forms: " + repr(self.equation(p)[1]) + " / " + repr(self.equation(q)[1]))
        return self.trans(p, self.sym(q))

    def parity_cases(self, left, right, bit, at_zero, at_one, n="n"):
        """Two applications of coverage-derived equation cases; no bit oracle."""
        delta = C("r", S(Z), Z)
        dl, dr = sub(left, {bit: delta}), sub(right, {bit: delta})
        base_l = sub(dl, {"r": Z}); base_r = sub(dr, {"r": Z})
        step_l = sub(dl, {"r": S("z")}); step_r = sub(dr, {"r": S("z")})
        first_base = self.trans(self.auto(base_l, self.equation(at_one)[0]),
                                self.trans(at_one, self.auto(self.equation(at_one)[1], base_r)))
        first_step = self.trans(self.auto(step_l, self.equation(at_zero)[0]),
                                self.trans(at_zero, self.auto(self.equation(at_zero)[1], step_r)))
        delta_equation = self.cases(dl, dr, "r", first_base, first_step)
        result_l, result_r = sub(left, {bit: E(n)}), sub(right, {bit: E(n)})
        base = self.trans(self.auto(sub(result_l, {n: Z}), sub(self.equation(at_zero)[0], {n: Z})),
                          self.trans(self.subst(at_zero, **{n: Z}),
                                     self.auto(sub(self.equation(at_zero)[1], {n: Z}), sub(result_r, {n: Z}))))
        step_lemma = self.subst(delta_equation, r=E("z"), **{n: S("z")})
        step = self.trans(self.auto(sub(result_l, {n: S("z")}), self.equation(step_lemma)[0]),
                          self.trans(step_lemma, self.auto(self.equation(step_lemma)[1], sub(result_r, {n: S("z")}))))
        return self.cases(result_l, result_r, n, base, step)

    def export(self, name, proof):
        self.exports.append({"name": name, "proof": proof, "equation": self.equation(proof),
                             "assumptions": self.contexts[proof]})

    def bundle(self):
        return {"format": "equational-A2-Cov-v1", "declarations": self.declarations,
                "proofs": self.proofs, "exports": self.exports}


# Fixed descriptions for the signed-arithmetic construction.
def P(n): return app("pred", n, Z)
def D(n): return app("double", n, Z)
def E(n): return app("parity", n, Z)
def H(n): return app("half", n, Z)
def delta(n): return C(n, S(Z), Z)
def B(n): return app("B", n)
def IB(n, a): return app("B_iter", n, a)

def N(n): return app("N", n)
def eps2(a, b): return sg(IB(a, N(b)))


def produce():
    b = Producer()
    b.recursor("pred", "ri")
    b.recursor("sel", "b", ["b"])
    b.recursor("double", S(S("ru")))
    b.recursor("parity", delta("ru"))
    b.recursor("half", C(E("ri"), "ru", S("ru")))
    b.macro("B", ["x"], C(E("x"), S(S("x")), P(P("x"))))
    b.macro("N", ["x"], C("x", Z, S(D(P("x")))))
    b.recursor("successor_iter", S("ru"))
    b.recursor("B_iter", B("ru"))

    # Parity is Boolean by two endpoint case arguments, not induction.
    l, r = delta(delta("bit")), "bit"
    bit_zero = b.auto(sub(l, {"bit": Z}), Z)
    bit_one = b.auto(sub(l, {"bit": S(Z)}), S(Z))
    toggle = b.parity_cases(l, r, "bit", bit_zero, bit_one)
    parity_two = b.auto(E(S(S("n"))), E("n"), [toggle])
    b.export("parity_two_step", parity_two)

    f = E(D("n"))
    recurrence = b.auto(sub(f, {"n": S("z")}), sub(f, {"n": "z"}), [toggle])
    parity_double = b.stationary(f, "n", recurrence)
    b.export("parity_of_double", parity_double)
    parity_odd = b.auto(E(S(D("n"))), S(Z), [parity_double])
    b.export("parity_of_odd_code", parity_odd)

    # H(SSn)=S(Hn), by the same two finite parity cases.
    l = C(delta("bit"), C("bit", "v", S("v")), S(C("bit", "v", S("v"))))
    r = S("v")
    bit_zero = b.auto(sub(l, {"bit": Z}), r)
    bit_one = b.auto(sub(l, {"bit": S(Z)}), r)
    half_bit = b.parity_cases(l, r, "bit", bit_zero, bit_one)
    half_two = b.auto(H(S(S("n"))), S(H("n")), [half_bit])
    b.export("half_two_step", half_two)
    f = H(D("n"))
    recurrence = b.auto(sub(f, {"n": S("z")}), S(sub(f, {"n": "z"})), [half_two])
    raw = b.A(f, "n", "n", "successor_iter", recurrence)
    raw = b.trans(raw, b.rewrite(b.equation(raw)[1], b.norm(H(D(Z)))))
    counter = b.A("n", "n", "n", "successor_iter", b.refl(S("z")))
    half_double = b.trans(raw, b.sym(counter))
    b.export("half_of_double", half_double)

    # Positive and negative signed clocks, using only the single map B.
    b_positive = b.auto(B(D("n")), D(S("n")), [parity_double])
    b.export("B_positive_clock_step", b_positive)
    left, right = B(N(S("n"))), N("n")
    base = b.auto(sub(left, {"n": Z}), sub(right, {"n": Z}), [parity_double])
    successor = b.auto(sub(left, {"n": S("z")}), sub(right, {"n": S("z")}), [parity_double])
    b_negative = b.cases(left, right, "n", base, successor)
    b.export("B_negative_clock_step", b_negative)

    # B commutes with its own iterates; the selected update is exactly B.
    f = B(IB("n", "a"))
    recurrence = b.rewrite(sub(f, {"n": S("z")}), b.definition(IB(S("z"), "a")))
    raw = b.A(f, "n", "n", "B_iter", recurrence)
    commute = b.trans(raw, b.rewrite(b.equation(raw)[1], b.definition(IB(Z, "a"))))
    b.export("B_commutes_with_iteration", commute)

    # Two iterates commute. k,a are fixed parameters in f, not in B.
    f = IB("k", IB("n", "a"))
    recurrence = b.rewrite(sub(f, {"n": S("z")}), b.definition(IB(S("z"), "a")))
    instance = b.sym(b.subst(commute, n="k", a=IB("z", "a")))
    recurrence = b.trans(recurrence, instance)
    raw = b.A(f, "n", "n", "B_iter", recurrence)
    iterate_commute = b.trans(raw, b.rewrite(b.equation(raw)[1], b.definition(IB(Z, "a"))))
    b.export("iterates_commute", iterate_commute)

    # I_B(n,N(n)) is stationary; no inverse permutation is used.
    f = IB("n", N("n"))
    recurrence = b.definition(IB(S("z"), N(S("z"))))
    instance = b.subst(commute, n="z", a=N(S("z")))
    recurrence = b.trans(recurrence, instance)
    recurrence = b.trans(recurrence, b.rewrite(b.equation(recurrence)[1], b.subst(b_negative, n="z")))
    negative_clock = b.stationary(f, "n", recurrence)
    b.export("negative_clock_cancellation", negative_clock)

    f = D("n")
    recurrence = b.sym(b.subst(b_positive, n="z"))
    raw = b.A(f, "n", "n", "B_iter", recurrence)
    raw = b.trans(raw, b.rewrite(b.equation(raw)[1], b.definition(D(Z))))
    positive_clock = b.sym(raw)
    b.export("positive_clock", positive_clock)

    # sg(r)=0 entails r=0 via an explicit coverage-derived equation.
    left = C(sg("r"), "r", Z)
    sign_patch = b.cases(left, Z, "r", b.auto(sub(left, {"r": Z}), Z),
                         b.auto(sub(left, {"r": S("z")}), Z))
    b.export("sign_extraction_patch", sign_patch)
    diagonal = b.chain(eps2("a", "a"), b.subst(negative_clock, n="a"))
    diagonal = b.trans(diagonal, b.norm(b.equation(diagonal)[1]))
    b.export("signed_reflector_diagonal", diagonal)

    assumption = b.hyp(eps2("a", "b"), Z)
    value = IB("a", N("b"))
    sign_eq = b.subst(sign_patch, r=value)
    change = b.rewrite(b.equation(sign_eq)[0], assumption)
    change = b.trans(change, b.definition(b.equation(change)[1]))
    value_zero = b.trans(b.sym(change), sign_eq)
    applied = b.cong("B_iter", b.refl("b"), value_zero)
    # Its left side = D(a), by commuting and the negative clock;
    # its right side = D(b), by the positive clock.
    lhs = b.chain(b.equation(applied)[0],
                  b.subst(iterate_commute, k="b", n="a", a=N("b")),
                  b.subst(negative_clock, n="b"),
                  b.subst(positive_clock, n="a"))
    rhs = b.subst(positive_clock, n="b")
    double_equal = b.trans(b.sym(lhs), b.trans(applied, rhs))
    half_equal = b.cong("half", double_equal, b.refl(Z))
    # H(t) is half(t,0); congruence above preserves the zero initializer.
    extracted = b.trans(b.sym(b.subst(half_double, n="a")),
                         b.trans(half_equal, b.subst(half_double, n="b")))
    b.export("signed_reflector_sound", extracted)
    equality_hypothesis = b.hyp("a", "b")
    transported = b.lift(eps2("a", "w"), "w", equality_hypothesis)
    complete = b.trans(b.sym(transported), diagonal)
    b.export("signed_reflector_complete", complete)
    return b.bundle()


if __name__ == "__main__":
    target = Path(__file__).with_name("certificates.json")
    bundle = produce()
    target.write_text(json.dumps(bundle, indent=2) + "\n")
    print(json.dumps({"path": target.name, "proof_nodes": len(bundle["proofs"]),
                      "exports": [e["name"] for e in bundle["exports"]]}, indent=2))
