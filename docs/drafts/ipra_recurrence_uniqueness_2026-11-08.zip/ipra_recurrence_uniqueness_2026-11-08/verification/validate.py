"""Replay the certificate and reject targeted invalid modifications."""
import copy
import hashlib
import json
from pathlib import Path
from checker import InvalidCertificate, verify

ROOT = Path(__file__).resolve().parent
bundle = json.loads((ROOT / "certificates.json").read_text())
# Independently state every advertised sequent. A valid proof of a weaker or
# differently oriented equation must not silently satisfy the artifact task.
Z = ["0"]
def S(x): return ["S", x]
def A(n, a): return ["add", n, a]
def P(x): return ["pred", x]
def C(n, a, b): return ["sel", n, a, b]
def D(a, n): return ["sub", n, a]
def sg(x): return C(x, Z, S(Z))
def k(x): return C(x, S(Z), P(x))
def eps(a, b): return sg(k(D(S(a), b)))
EXPECTED = {
    "zero_plus": ([A("n", Z), "n"], []),
    "addition_successor_shift": ([S(A("n", "a")), A("n", S("a"))], []),
    "selector_diagonal": ([C("r", "v", "v"), "v"], []),
    "subtraction_successor_shift": ([D(S("a"), S("n")), D("a", "n")], []),
    "subtraction_diagonal": ([D(S("n"), "n"), S(Z)], []),
    "residual_step_patch": ([C(P("r"), "y", A(P("r"), S("n"))),
                             C(P("r"), "y", C("r", "y", A("r", "n")))], []),
    "residual_reflection": ([C(D("y", "n"), "y", A(D("y", "n"), "n")), "y"], []),
    "selector_successor_patch": ([C("q", S("q"), S(Z)), S(Z)], []),
    "one_test_extraction_patch": ([C(k("r"), "r", S(Z)), S(Z)], []),
    "sign_extraction_patch": ([C(sg("r"), "r", Z), Z], []),
    "equality_reflector_diagonal": ([eps("a", "a"), Z], []),
    "equality_reflector_sound": (["a", "b"], [[eps("a", "b"), Z]]),
    "equality_reflector_complete": ([eps("a", "b"), Z], [["a", "b"]]),
}


def verify_scope(candidate):
    result = verify(candidate)
    advertised = {e["name"]: (e["equation"], e["assumptions"]) for e in candidate["exports"]}
    if advertised != EXPECTED:
        raise InvalidCertificate("exported sequents differ from the independently stated obligations")
    return result


receipt = verify_scope(bundle)
controls = []


def reject(name, change):
    malformed = copy.deepcopy(bundle)
    change(malformed)
    try:
        verify_scope(malformed)
    except InvalidCertificate as exc:
        controls.append({"name": name, "status": "REJECTED", "reason": str(exc)})
    else:
        raise AssertionError(f"invalid certificate accepted: {name}")


first_u = next(i for i, n in enumerate(bundle["proofs"]) if n["rule"] == "U")
residual = next(e["proof"] for e in bundle["exports"] if e["name"] == "residual_reflection")


def wrong_rhs(b):
    b["proofs"][residual]["equation"][1] = ["S", "y"]
reject("changed_reflection_rhs", wrong_rhs)


def wrong_recurrence(b):
    p = b["proofs"][first_u]["proof"]
    term = ["S", ["S", "z"]]
    b["proofs"][p] = {"rule": "refl", "term": term, "equation": [term, term]}
reject("changed_U_recurrence", wrong_recurrence)


def wrong_initial(b):
    b["proofs"][first_u]["equation"][1][2] = ["S", ["0"]]
reject("changed_U_initial_value", wrong_initial)


def target_capture(b):
    n = b["proofs"][first_u]
    n["target"] = "z"
    n["equation"] = ["z", ["add", "z", ["0"]]]
reject("U_eigenvariable_in_target", target_capture)


def context_capture(b):
    original = copy.deepcopy(b["proofs"][first_u])
    premise = original["proof"]
    weakened = {"rule": "weaken", "proof": premise, "assumptions": [["z", "z"]],
                "equation": copy.deepcopy(b["proofs"][premise]["equation"])}
    original["proof"] = len(b["proofs"])
    b["proofs"].append(weakened)
    b["proofs"].append(original)
reject("U_eigenvariable_in_retained_context", context_capture)


def forward_reference(b):
    b["proofs"][first_u]["proof"] = len(b["proofs"])
reject("forward_proof_reference", forward_reference)


def circular_description(b):
    b["declarations"][0]["step"] = ["add", "ri", "ru"]
reject("circular_recursor_description", circular_description)


def free_description_parameter(b):
    macro = next(d for d in b["declarations"] if d["kind"] == "macro")
    macro["body"] = "undeclared_parameter"
reject("free_parameter_in_description", free_description_parameter)


def omitted_assumption(b):
    export = next(e for e in b["exports"] if e["name"] == "equality_reflector_sound")
    export["assumptions"] = []
reject("omitted_reflector_assumption", omitted_assumption)


def unsupported_case_rule(b):
    b["proofs"][-1]["rule"] = "equation_case_oracle"
reject("unlisted_case_oracle", unsupported_case_rule)

def weaker_valid_export(b):
    export = next(e for e in b["exports"] if e["name"] == "equality_reflector_diagonal")
    proof = next(i for i, node in enumerate(b["proofs"]) if node["rule"] == "refl")
    export["proof"] = proof
    export["equation"] = copy.deepcopy(b["proofs"][proof]["equation"])
    export["assumptions"] = []
reject("valid_proof_of_wrong_exported_theorem", weaker_valid_export)

receipt["expected_exported_sequents"] = "all 13 matched exactly"
receipt["negative_controls"] = controls
receipt["rejected_negative_controls"] = len(controls)
receipt["source_sha256"] = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                             for name in ("checker.py", "produce.py", "certificates.json")}
receipt["scope"] = ("Finite symbolic equational derivations with staged primitive recursors and the "
                    "one-premise U rule. Every case derivation is expanded to U. No induction, "
                    "coverage, separation, Boolean range, semantic evaluation, or full first-order "
                    "proof verifier is imported. Not a complete iPRA checker or a size competitor.")
(ROOT / "verification_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
