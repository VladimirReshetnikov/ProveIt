#!/usr/bin/env python3
"""Build the self-contained report with pdfLaTeX and no shell escape."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent

def main():
    engine = shutil.which("pdflatex")
    if engine is None:
        raise SystemExit("pdflatex is required to rebuild the included PDF.")
    with tempfile.TemporaryDirectory(prefix="ipra-tex-") as temporary:
        logs = []
        for pass_index in range(5):
            process = subprocess.run(
                [engine, "-no-shell-escape", "-halt-on-error",
                 "-interaction=nonstopmode", "-output-directory", temporary,
                 "report.tex"], cwd=ROOT, capture_output=True, text=True)
            logs.append(process.stdout + process.stderr)
            if process.returncode:
                (ROOT / "results").mkdir(exist_ok=True)
                (ROOT / "results" / "tex_build_failure.log").write_text(logs[-1])
                raise SystemExit(logs[-1][-7000:])
            final_log = (Path(temporary) / "report.log").read_text(errors="replace")
            needs_rerun = any(message in final_log for message in (
                "Label(s) may have changed", "undefined references", "Rerun to get"))
            if pass_index >= 1 and not needs_rerun:
                break
        if needs_rerun:
            raise SystemExit("LaTeX cross-references did not settle after five passes.")
        shutil.copy2(Path(temporary) / "report.pdf", ROOT / "report.pdf")
        final_log = (Path(temporary) / "report.log").read_text(errors="replace")
        (ROOT / "results").mkdir(exist_ok=True)
        (ROOT / "results" / "tex_build.log").write_text(final_log)
        receipt = {
            "status": "PASS",
            "engine": "pdfLaTeX",
            "passes": pass_index + 1,
            "shell_escape": False,
            "overfull_boxes": final_log.count("Overfull"),
            "undefined_references": "undefined references" in final_log,
            "source_sha256": hashlib.sha256((ROOT / "report.tex").read_bytes()).hexdigest(),
            "pdf_sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest(),
        }
        (ROOT / "results" / "build_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps(receipt, indent=2))

if __name__ == "__main__":
    main()

