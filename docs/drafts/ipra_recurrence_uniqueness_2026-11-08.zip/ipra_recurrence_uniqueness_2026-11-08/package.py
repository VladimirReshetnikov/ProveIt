#!/usr/bin/env python3
"""Refresh the payload manifest and create a reproducible ZIP."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent

def payload():
    return sorted(p for p in ROOT.rglob("*")
                  if p.is_file() and p.name != "MANIFEST.json"
                  and "__pycache__" not in p.parts
                  and p.suffix not in {".pyc", ".aux", ".out", ".toc", ".log"})

def main():
    files = payload()
    manifest = {
        "format": "ipra-research-payload-v1",
        "scope": "Every packaged file except this manifest.",
        "files": [{
            "path": p.relative_to(ROOT).as_posix(),
            "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        } for p in files],
    }
    manifest_path = ROOT / "MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    archive = ROOT.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as out:
        for p in sorted([*files, manifest_path]):
            name = ROOT.name + "/" + p.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 8, 20, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            out.writestr(info, p.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                         compresslevel=9)
    print(json.dumps({"archive": str(archive), "files": len(files) + 1,
                      "bytes": archive.stat().st_size,
                      "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()},
                     indent=2))

if __name__ == "__main__":
    main()

