RECURRENCE UNIQUENESS FOR FULL INTUITIONISTIC PRA
==============================================

Prepared for Vladimir Reshetnikov. Source comparison pinned to ProveIt
commit deefab74912eef91a2cd1ba6686589cb8964466e, docs/drafts.

Read report.pdf for the complete mathematical statement, proofs, source
comparison, history, and limitations. report.tex is monolithic editable
LaTeX source; a normal TeX Live installation with the listed packages can
compile it without any repository dependencies or shell escape.

Established mathematical results
--------------------------------
1. Unrestricted initialized-recursion uniqueness derives a numerical
   equality reflector from the PR defining equations alone. This first
   derivation uses neither numerical coverage nor separation nor induction.
2. A different equality-reflection construction needs only TWO fixed
   closed unary uniqueness updates: successor and B, an explicit
   signed-counter update. Numerical coverage is explicitly retained. A
   reset clock derives every required use of zero stationarity using
   successor uniqueness alone. Identity uniqueness is not an assumption.
3. With the full PR description signature, coverage, separation, and full
   intuitionistic first-order logic, the resulting conventional theory is
   deductively equivalent and identity-domain bi-interpretable with iPRA.
   The report specifies both interpretations and both composites.

The positive-language variants use the designated absurdity 0=1 and a
specified formula translation. They are not asserted to identify arbitrary
positive models (including singleton models) with ordinary iPRA models.

Complexity status
-----------------
This package does NOT establish a complete-checker improvement below the
current observed coordinate envelope:
  313 normalized tokens / 347 AST nodes / 878 normalized UTF-8 bytes.
The three minima have different attainers. These are reproduced empirical
minima from sixteen complete programs, not a universal lower-bound theorem.
The new function descriptions, logical rules, and uniqueness matching cost
must all count in any future implementation comparison.

Recursion uniqueness, including fixed-successor presentations, has classical
precedent. No literature-wide novelty, absolute smallestness, or significant
new minimum is claimed. Historical and inherited methods are attributed in
report.tex and ATTRIBUTION.txt.

Reproduce the executed evidence
------------------------------
  python3 reproduce.py

This command uses only the Python standard library. It runs:
  verification/validate.py
  verification/autonomous/validate.py
  verification/two_updates/validate.py
  comparison/measure.py

The first certificate verifies the pure unrestricted-U reflection core:
  854 symbolic nodes, 17 U uses, 13 exact exported sequents;
  11 deliberately invalid controls reject.

The second certificate verifies the three-update signed-clock reflection:
  1,415 symbolic nodes, 9 U uses, 15 exact exported sequents;
  6 equation-case inferences explicitly charged to coverage;
  12 deliberately invalid controls reject.

The final certificate verifies the two-update refinement:
  1,804 symbolic nodes, 9 U uses (S6 and B3), 15 exact exported sequents;
  12 coverage-derived equation cases and 11 fixed declarations;
  14 deliberately invalid controls reject.
It expands both reset-clock proofs. Its checker has no identity-U, general
U, reset-U, or trusted zero-stationarity rule.

Each certificate has separate producer, checker, exact endpoint validation,
README, and executed receipt. The producers do not import their checkers.
The certificates do not implement a complete first-order iPRA proof kernel;
full logical translation and latch induction have written proofs. The
coverage-derived case rule in the autonomous verifier is a stated trusted
derived rule, not silently inferred from pure equations. The verifiers are
not entries in the complete-checker source-size comparison.

The comparison script preserves the inherited normalizer and all sixteen
source programs unchanged, verifies their hashes, and counts whole programs.
See comparison/README.txt, comparison/provenance/, and the original license
and attribution records there.

Build and integrity
-------------------
  python3 build.py
  python3 package.py

build.py compiles report.tex without shell escape, running at least two
passes and continuing until references settle, then writes a build receipt.
A complete TeX Live installation is needed; runtime format/font caches are
not bundled. The supplied PDF is the actual compiled LaTeX document.

package.py regenerates MANIFEST.json and a deterministic ZIP alongside
this directory. It excludes transient LaTeX files, logs, and Python caches.
The manifest covers every packaged file other than itself. Building the
PDF again can change timestamps and therefore its byte hash; regenerate
the manifest after any deliberate changes.

Primary files
-------------
report.pdf                         Compiled report
report.tex                         Complete LaTeX source
ATTRIBUTION.txt                    Contribution and source boundaries
verification/                      Pure-U certificate and validation
verification/autonomous/           Three-update certificate and validation
verification/two_updates/          Final two-update certificate and validation
comparison/                        Exact complete-source comparison corpus
provenance/source_snapshot.json     Ten pinned draft archive identities
results/                           Build and visual QA receipts
MANIFEST.json                     Integrity hashes for packaged files

No repository modifications were made and no reference PDFs are repackaged.
