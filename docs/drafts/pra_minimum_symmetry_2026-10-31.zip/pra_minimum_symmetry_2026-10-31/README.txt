PRA from Positive Constancy and a Minimum Identity
================================================
Prepared for Vladimir Reshetnikov, 31 October 2026.

MAIN RESULT
The same nonlogical theory works over classical or intuitionistic
first-order equality logic, with bi-interpretability proved separately
against ordinary PRA in the matching logic:

    D + Sep + Min + PC.

D is the effective binary initialized-iterator computation grammar.
Sep is 0 != S0. Min is the fixed equation

    M(M(x,y),y) = M(M(y,x),x),

where M(x,y) is the already-declared iterator with standard meaning
max(y-x,0). PC is the one-parameter positive-constancy term schema.
See axioms.txt for the complete specification.

WHAT IMPROVES
This replaces the positive-constancy draft's fixed equality-recognition
biconditional by separation plus a single arithmetic equation. It retains
the exact binary grammar and one numerical parameter. A small early latch
proves M(x,0)=0; Min then provides the diagonal and native equality
reflection. The remainder recovers ordinary PRA without circularity.

Under the supplied expanded-connective AST convention, the fixed bridge
shrinks from 39 to 19 nodes; the complete displayed templates shrink from
83 to 63. With biconditional primitive, the corresponding change is 64
to 63. Conjoining Sep and Min gives 64, tying the primitive-biconditional
baseline; the one-node advantage in that convention depends on packing.
The delayed uniqueness draft still has a shorter total display
(52 nodes), so this is not a claim to an absolute smallest axiomatization.
The new basis has two computation schemas, one arithmetic schema, and
two fixed sentences. There are infinitely many instances and symbols.

An additional theorem restricts PC to literal zero-indicator terms
B(g(n,a),1); its printed schema is longer, so that refinement is separate.

CONTENTS
pra_minimum_symmetry.tex / .pdf  Complete 15-page report and proofs.
axioms.txt                      Standalone full specification.
formal/MinSymmetry.lean          Small constructive new-bridge certificate.
formal/MinConstancy.lean         Finite-syntax completion through QF induction.
formal/README.txt               Exact formal scope and axiom-audit explanation.
formal/lean_check.log            Original compiler output for the linked file.
artifacts/check_axioms.py        Formula-tree counts and finite diagnostics.
artifacts/metrics_and_diagnostics.json  Reproduced metrics.
artifacts/full_check.log         End-to-end compiler/diagnostic verification.
audit/source_audit.json          Snapshot, immutable paths, hashes, review scope.
ATTRIBUTION.txt                  Source provenance and adaptation boundaries.
build.sh / check.sh              Reproduction commands.
SHA256SUMS                       Hashes of the packaged files.

BUILD
    ./build.sh
Requires pdflatex and latexmk with ordinary LaTeX packages.

CHECK
    ./check.sh
Requires Python 3.10+ and Lean 4.19.0. If Lean is not on PATH:
    PRA_LEAN=/absolute/path/to/lean ./check.sh
No Lean package dependencies or imports are required.

VERIFICATION SCOPE
The linked Lean certificate checks one-parameter quantifier-free
induction over arbitrary carriers, starting from the actual finite-term
PC schema, computations, Sep, and Min. Its 28 printed global axiom
dependency audits are empty. Arithmetic assumptions remain explicit
hypotheses; empty audits do not mean arithmetic was proved without axioms.
The report, rather than the Lean certificate, proves triangular pairing,
all finite parameter tuples, full recursion compilation, the converse,
the PC_Z refinement, and the first-order bi-interpretability metatheorem.

No repository changes are part of this deliverable.
