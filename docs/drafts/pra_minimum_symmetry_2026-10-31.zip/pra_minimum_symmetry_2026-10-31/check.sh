#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 artifacts/check_axioms.py
pra_lean_bin="${PRA_LEAN:-lean}"
"$pra_lean_bin" --version
"$pra_lean_bin" formal/MinSymmetry.lean
"$pra_lean_bin" formal/MinConstancy.lean
