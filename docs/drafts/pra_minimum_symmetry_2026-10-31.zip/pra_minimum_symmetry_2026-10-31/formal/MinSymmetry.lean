/-
  Constructive arithmetic kernel for the min-symmetry bridge.

  No imports, arithmetic-carrier induction, or decidable equality are used.
  The carrier is arbitrary. The two PC inputs are precisely the gate family
  B(n,a) and the parameter-free latch q(n) = I_h(n,1),
  h(k,v) = B(M(k,0),v). The computation equations are explicit hypotheses.
  This file checks the new bridge, not the full PRA interpretation theorem.
-/

universe u

namespace MinSymmetry

def PositiveConstancy {A : Type u} (zero : A) (succ : A → A)
    (f : A → A) : Prop :=
  (∀ n, f (succ (succ n)) = f (succ n)) →
  ∀ n, n = zero ∨ f n = f (succ zero)

structure Kernel (A : Type u) where
  zero : A
  succ : A → A
  P : A → A → A
  B : A → A → A
  M : A → A → A
  q : A → A
  pZero : ∀ a, P zero a = a
  pSucc : ∀ n a, P (succ n) a = n
  bZero : ∀ a, B zero a = a
  bSucc : ∀ n a, B (succ n) a = zero
  mZero : ∀ a, M zero a = a
  mSucc : ∀ n a, M (succ n) a = P (M n a) zero
  nontrivial : zero ≠ succ zero
  pcGate : ∀ a, PositiveConstancy zero succ (fun n => B n a)
  qZero : q zero = succ zero
  qSucc : ∀ n, q (succ n) = B (M n zero) (q n)
  pcLatch : PositiveConstancy zero succ q
  minSymmetry : ∀ x y, M (M x y) y = M (M y x) x

namespace Kernel

variable {A : Type u} (K : Kernel A)

def one : A := K.succ K.zero

def C (z a b : A) : A := K.P (K.B z (K.succ a)) b

def error (x y : A) : A := K.C (K.M x y) (K.M y x) K.one

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro hx
  have hpred : K.P (K.succ x) K.zero = K.P K.zero K.zero :=
    congrArg (fun t => K.P t K.zero) hx
  rw [K.pSucc, K.pZero] at hpred
  apply K.nontrivial
  rw [hpred] at hx
  exact hx.symm

theorem gate_alternative (n a : A) :
    n = K.zero ∨ K.B n a = K.zero := by
  have htail : ∀ k, K.B (K.succ (K.succ k)) a = K.B (K.succ k) a := by
    intro k
    rw [K.bSucc, K.bSucc]
  have h := K.pcGate a htail n
  change n = K.zero ∨ K.B n a = K.B (K.succ K.zero) a at h
  rw [K.bSucc] at h
  exact h

theorem gate_nonzero (n a : A) (hn : n ≠ K.zero) : K.B n a = K.zero := by
  cases K.gate_alternative n a with
  | inl hz => exact False.elim (hn hz)
  | inr h => exact h

theorem zero_decision (n : A) : n = K.zero ∨ n ≠ K.zero := by
  cases K.gate_alternative n K.one with
  | inl hz => exact Or.inl hz
  | inr h =>
      apply Or.inr
      intro hz
      rw [hz, K.bZero] at h
      exact K.nontrivial h.symm

theorem gate_zero (n : A) : K.B n K.zero = K.zero := by
  cases K.gate_alternative n K.zero with
  | inl hz => rw [hz, K.bZero]
  | inr h => exact h

theorem m_zero_step (n : A) (hn : K.M n K.zero = K.zero) :
    K.M (K.succ n) K.zero = K.zero := by
  rw [K.mSucc, hn, K.pZero]

theorem latch_one : K.q K.one = K.one := by
  change K.q (K.succ K.zero) = K.succ K.zero
  rw [K.qSucc, K.mZero, K.bZero, K.qZero]

theorem latch_stationary (n : A) :
    K.q (K.succ (K.succ n)) = K.q (K.succ n) := by
  cases K.zero_decision (K.M n K.zero) with
  | inl hz =>
      rw [K.qSucc (K.succ n), K.m_zero_step n hz, K.bZero]
  | inr hn =>
      have hq : K.q (K.succ n) = K.zero := by
        rw [K.qSucc, K.gate_nonzero (K.M n K.zero) (K.q n) hn]
      rw [K.qSucc (K.succ n), hq, K.gate_zero]

theorem latch_successor_value (n : A) : K.q (K.succ n) = K.one := by
  have h := K.pcLatch K.latch_stationary (K.succ n)
  cases h with
  | inl hz => exact False.elim (K.succ_ne_zero n hz)
  | inr h => exact h.trans K.latch_one

theorem monus_zero (n : A) : K.M n K.zero = K.zero := by
  cases K.zero_decision (K.M n K.zero) with
  | inl hz => exact hz
  | inr hn =>
      have hq : K.q (K.succ n) = K.zero := by
        rw [K.qSucc, K.gate_nonzero (K.M n K.zero) (K.q n) hn]
      have h01 : K.zero = K.one := hq.symm.trans (K.latch_successor_value n)
      exact False.elim (K.nontrivial h01)

theorem monus_diagonal (x : A) : K.M x x = K.zero := by
  have h := K.minSymmetry x K.zero
  rw [K.monus_zero x, K.mZero, K.mZero] at h
  exact h.symm

theorem two_zeros_iff (x y : A) :
    (K.M x y = K.zero ∧ K.M y x = K.zero) ↔ x = y := by
  constructor
  · intro hxy
    have h := K.minSymmetry x y
    rw [hxy.1, hxy.2, K.mZero, K.mZero] at h
    exact h.symm
  · intro hxy
    rw [hxy]
    exact ⟨K.monus_diagonal y, K.monus_diagonal y⟩

theorem selector_zero (a b : A) : K.C K.zero a b = a := by
  unfold C
  rw [K.bZero, K.pSucc]

theorem selector_nonzero (z a b : A) (hz : z ≠ K.zero) : K.C z a b = b := by
  unfold C
  rw [K.gate_nonzero z (K.succ a) hz, K.pZero]

theorem error_zero_iff (x y : A) : K.error x y = K.zero ↔ x = y := by
  constructor
  · intro he
    cases K.zero_decision (K.M x y) with
    | inl hz =>
        have hy : K.M y x = K.zero := by
          change K.C (K.M x y) (K.M y x) K.one = K.zero at he
          rw [hz, K.selector_zero] at he
          exact he
        exact (K.two_zeros_iff x y).mp ⟨hz, hy⟩
    | inr hn =>
        change K.C (K.M x y) (K.M y x) K.one = K.zero at he
        rw [K.selector_nonzero (K.M x y) (K.M y x) K.one hn] at he
        exact False.elim (K.nontrivial he.symm)
  · intro hxy
    have hz := (K.two_zeros_iff x y).mpr hxy
    change K.C (K.M x y) (K.M y x) K.one = K.zero
    rw [hz.1, K.selector_zero, hz.2]

include K in
theorem equality_decision (x y : A) : x = y ∨ x ≠ y := by
  cases K.zero_decision (K.error x y) with
  | inl hz => exact Or.inl ((K.error_zero_iff x y).mp hz)
  | inr hn =>
      exact Or.inr (fun hxy => hn ((K.error_zero_iff x y).mpr hxy))

#print axioms monus_zero
#print axioms monus_diagonal
#print axioms two_zeros_iff
#print axioms error_zero_iff
#print axioms equality_decision

end Kernel

end MinSymmetry
