/-
Min-commutativity and positive constancy.
Finite-syntax constructive certificate, Lean 4.19.0; no imports.

New bridge and final linking theorem prepared for Vladimir Reshetnikov.
The generic finite-syntax completion is adapted from
pra_positive_constancy_2026-10-31/formal/PositiveConstancy.lean, inspected
in ProveIt commit 514b6dfd2c1232848a259549c352b1935d53191c. Its preceding
attribution is preserved below. The equality-error term is changed from
the sum of two remainders to the selector C(M(x,y),M(y,x),1).

The main theorem is main_quantifier_free_induction. Its only arithmetic
hypotheses are the computation Model, finite-term PositiveConstancy,
0 != S0, and the fixed min-commutativity equation. The auxiliary generic
completion still exposes an equality-recognition interface; the new
finite-syntax bridge discharges that interface, without arithmetic
carrier induction, choice, or a general decidable-equality hypothesis.

This certificate proves one-parameter quantifier-free induction in an
arbitrary carrier model of the stated schemas. Pairing, full parameter
elimination, source-language translation, and first-order syntactic
bi-interpretability remain written proofs, not claimed Lean endpoints.
-/

/-
  Constructive arithmetic kernel for the min-symmetry bridge.

  No imports, arithmetic-carrier induction, or decidable equality are used.
  The carrier is arbitrary. The two PC inputs are precisely the gate family
  B(n,a) and the parameter-free latch q(n) = I_h(n,1),
  h(k,v) = B(M(k,0),v). The computation equations are explicit hypotheses.
  This file checks the new bridge, not the full PRA interpretation theorem.
-/

universe u

namespace MinSymmetry

def PositiveConstancy {A : Type u} (zero : A) (succ : A → A)
    (f : A → A) : Prop :=
  (∀ n, f (succ (succ n)) = f (succ n)) →
  ∀ n, n = zero ∨ f n = f (succ zero)

structure Kernel (A : Type u) where
  zero : A
  succ : A → A
  P : A → A → A
  B : A → A → A
  M : A → A → A
  q : A → A
  pZero : ∀ a, P zero a = a
  pSucc : ∀ n a, P (succ n) a = n
  bZero : ∀ a, B zero a = a
  bSucc : ∀ n a, B (succ n) a = zero
  mZero : ∀ a, M zero a = a
  mSucc : ∀ n a, M (succ n) a = P (M n a) zero
  nontrivial : zero ≠ succ zero
  pcGate : ∀ a, PositiveConstancy zero succ (fun n => B n a)
  qZero : q zero = succ zero
  qSucc : ∀ n, q (succ n) = B (M n zero) (q n)
  pcLatch : PositiveConstancy zero succ q
  minSymmetry : ∀ x y, M (M x y) y = M (M y x) x

namespace Kernel

variable {A : Type u} (K : Kernel A)

def one : A := K.succ K.zero

def C (z a b : A) : A := K.P (K.B z (K.succ a)) b

def error (x y : A) : A := K.C (K.M x y) (K.M y x) K.one

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro hx
  have hpred : K.P (K.succ x) K.zero = K.P K.zero K.zero :=
    congrArg (fun t => K.P t K.zero) hx
  rw [K.pSucc, K.pZero] at hpred
  apply K.nontrivial
  rw [hpred] at hx
  exact hx.symm

theorem gate_alternative (n a : A) :
    n = K.zero ∨ K.B n a = K.zero := by
  have htail : ∀ k, K.B (K.succ (K.succ k)) a = K.B (K.succ k) a := by
    intro k
    rw [K.bSucc, K.bSucc]
  have h := K.pcGate a htail n
  change n = K.zero ∨ K.B n a = K.B (K.succ K.zero) a at h
  rw [K.bSucc] at h
  exact h

theorem gate_nonzero (n a : A) (hn : n ≠ K.zero) : K.B n a = K.zero := by
  cases K.gate_alternative n a with
  | inl hz => exact False.elim (hn hz)
  | inr h => exact h

theorem zero_decision (n : A) : n = K.zero ∨ n ≠ K.zero := by
  cases K.gate_alternative n K.one with
  | inl hz => exact Or.inl hz
  | inr h =>
      apply Or.inr
      intro hz
      rw [hz, K.bZero] at h
      exact K.nontrivial h.symm

theorem gate_zero (n : A) : K.B n K.zero = K.zero := by
  cases K.gate_alternative n K.zero with
  | inl hz => rw [hz, K.bZero]
  | inr h => exact h

theorem m_zero_step (n : A) (hn : K.M n K.zero = K.zero) :
    K.M (K.succ n) K.zero = K.zero := by
  rw [K.mSucc, hn, K.pZero]

theorem latch_one : K.q K.one = K.one := by
  change K.q (K.succ K.zero) = K.succ K.zero
  rw [K.qSucc, K.mZero, K.bZero, K.qZero]

theorem latch_stationary (n : A) :
    K.q (K.succ (K.succ n)) = K.q (K.succ n) := by
  cases K.zero_decision (K.M n K.zero) with
  | inl hz =>
      rw [K.qSucc (K.succ n), K.m_zero_step n hz, K.bZero]
  | inr hn =>
      have hq : K.q (K.succ n) = K.zero := by
        rw [K.qSucc, K.gate_nonzero (K.M n K.zero) (K.q n) hn]
      rw [K.qSucc (K.succ n), hq, K.gate_zero]

theorem latch_successor_value (n : A) : K.q (K.succ n) = K.one := by
  have h := K.pcLatch K.latch_stationary (K.succ n)
  cases h with
  | inl hz => exact False.elim (K.succ_ne_zero n hz)
  | inr h => exact h.trans K.latch_one

theorem monus_zero (n : A) : K.M n K.zero = K.zero := by
  cases K.zero_decision (K.M n K.zero) with
  | inl hz => exact hz
  | inr hn =>
      have hq : K.q (K.succ n) = K.zero := by
        rw [K.qSucc, K.gate_nonzero (K.M n K.zero) (K.q n) hn]
      have h01 : K.zero = K.one := hq.symm.trans (K.latch_successor_value n)
      exact False.elim (K.nontrivial h01)

theorem monus_diagonal (x : A) : K.M x x = K.zero := by
  have h := K.minSymmetry x K.zero
  rw [K.monus_zero x, K.mZero, K.mZero] at h
  exact h.symm

theorem two_zeros_iff (x y : A) :
    (K.M x y = K.zero ∧ K.M y x = K.zero) ↔ x = y := by
  constructor
  · intro hxy
    have h := K.minSymmetry x y
    rw [hxy.1, hxy.2, K.mZero, K.mZero] at h
    exact h.symm
  · intro hxy
    rw [hxy]
    exact ⟨K.monus_diagonal y, K.monus_diagonal y⟩

theorem selector_zero (a b : A) : K.C K.zero a b = a := by
  unfold C
  rw [K.bZero, K.pSucc]

theorem selector_nonzero (z a b : A) (hz : z ≠ K.zero) : K.C z a b = b := by
  unfold C
  rw [K.gate_nonzero z (K.succ a) hz, K.pZero]

theorem error_zero_iff (x y : A) : K.error x y = K.zero ↔ x = y := by
  constructor
  · intro he
    cases K.zero_decision (K.M x y) with
    | inl hz =>
        have hy : K.M y x = K.zero := by
          change K.C (K.M x y) (K.M y x) K.one = K.zero at he
          rw [hz, K.selector_zero] at he
          exact he
        exact (K.two_zeros_iff x y).mp ⟨hz, hy⟩
    | inr hn =>
        change K.C (K.M x y) (K.M y x) K.one = K.zero at he
        rw [K.selector_nonzero (K.M x y) (K.M y x) K.one hn] at he
        exact False.elim (K.nontrivial he.symm)
  · intro hxy
    have hz := (K.two_zeros_iff x y).mpr hxy
    change K.C (K.M x y) (K.M y x) K.one = K.zero
    rw [hz.1, K.selector_zero, hz.2]

include K in
theorem equality_decision (x y : A) : x = y ∨ x ≠ y := by
  cases K.zero_decision (K.error x y) with
  | inl hz => exact Or.inl ((K.error_zero_iff x y).mp hz)
  | inr hn =>
      exact Or.inr (fun hxy => hn ((K.error_zero_iff x y).mpr hxy))


end Kernel

end MinSymmetry

/-
Inherited generic completion through an equality-recognition interface.
Finite-syntax constructive certificate, Lean 4.19.0; no imports.
The interface is discharged from min-commutativity at the end of this file.

Adapted from FourUpdates.lean (this research archive), whose underlying
syntax, selector, digit coding, and formula compiler refine the ProveIt
positive-uniqueness draft (1), snapshot
b0350fd1c96d8273ca9c3b5ce025782b748cded7.

The carrier is arbitrary. Every PC instance ranges over the actual finite
Term syntax below, never over arbitrary carrier maps. The auxiliary ER
interface uses the displayed primitive-recursive equalityError term. The
final endpoint derives it from the new fixed equation and separation;
it is not an unlinked hypothesis. No induction on the carrier is assumed.

The final endpoint certifies all one-parameter quantifier-free induction
instances via actual finite Formula syntax. Pairing and elimination of
arbitrary finite parameter tuples remain written proofs in the paper.
-/

namespace MinConstancy

inductive Term where
  | first
  | second
  | zero
  | succ (argument : Term)
  | iter (update counter seed : Term)
  deriving DecidableEq

def substitute : Term → Term → Term → Term
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => .zero
  | .succ t, x, y => .succ (substitute t x y)
  | .iter h n a, x, y => .iter h (substitute n x y) (substitute a x y)

def evaluate {A : Type u} (zero : A) (succ : A → A)
    (run : Term → A → A → A) : Term → A → A → A
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => zero
  | .succ t, x, y => succ (evaluate zero succ run t x y)
  | .iter h n a, x, y =>
      run h (evaluate zero succ run n x y) (evaluate zero succ run a x y)

structure Model (A : Type u) where
  zero : A
  succ : A → A
  run : Term → A → A → A
  run_zero : ∀ h a, run h zero a = a
  run_succ : ∀ h n a,
    run h (succ n) a = evaluate zero succ run h n (run h n a)

def value {A : Type u} (C : Model A) (t : Term) (x y : A) : A :=
  evaluate C.zero C.succ C.run t x y

variable {A : Type u} (C : Model A)

theorem value_substitute (t x y : Term) (n a : A) :
    value C (substitute t x y) n a =
      value C t (value C x n a) (value C y n a) := by
  induction t with
  | first => rfl
  | second => rfl
  | zero => rfl
  | succ t ih => exact congrArg C.succ ih
  | iter h n' a' _ ihn iha =>
      change C.run h (value C (substitute n' x y) n a)
          (value C (substitute a' x y) n a) =
        C.run h (value C n' (value C x n a) (value C y n a))
          (value C a' (value C x n a) (value C y n a))
      exact congr (congrArg (C.run h) ihn) iha

def oneTerm : Term := .succ .zero
def predTerm (t : Term) : Term := .iter .first t .zero
def addTerm (s t : Term) : Term := .iter (.succ .second) s t
def gateTerm (s t : Term) : Term := .iter .zero s t
def monusTerm (s t : Term) : Term := .iter (predTerm .second) s t

def one : A := C.succ C.zero
def pred (x : A) : A := C.run .first x C.zero
def add (x y : A) : A := C.run (.succ .second) x y
def gate (x y : A) : A := C.run .zero x y
def monus (x y : A) : A := C.run (predTerm .second) x y

theorem pred_zero : pred C C.zero = C.zero := C.run_zero _ _
theorem pred_succ (x : A) : pred C (C.succ x) = x := C.run_succ _ _ _
theorem add_zero (x : A) : add C C.zero x = x := C.run_zero _ _
theorem add_succ (x y : A) : add C (C.succ x) y = C.succ (add C x y) :=
  C.run_succ _ _ _
theorem gate_zero (x : A) : gate C C.zero x = x := C.run_zero _ _
theorem gate_succ (x y : A) : gate C (C.succ x) y = C.zero := C.run_succ _ _ _
theorem monus_zero (x : A) : monus C C.zero x = x := C.run_zero _ _
theorem monus_succ (x y : A) : monus C (C.succ x) y = pred C (monus C x y) :=
  C.run_succ _ _ _

/-- Selector obtained from the initialized predecessor, without arithmetic laws. -/
def selectTerm (z x y : Term) : Term := .iter .first (gateTerm z (.succ x)) y

def select (z x y : A) : A := C.run .first (gate C z (C.succ x)) y

/-- A zero error precisely when both subtraction remainders vanish. -/
def equalityErrorTerm (x y : Term) : Term :=
  selectTerm (monusTerm x y) (monusTerm y x) oneTerm

def equalityError (x y : A) : A :=
  select C (monus C x y) (monus C y x) (one C)

/-- One unrestricted finite term, one fixed numerical parameter. -/
def PositiveConstancy : Prop :=
  ∀ t : Term, ∀ a : A,
    (∀ n, value C t (C.succ (C.succ n)) a = value C t (C.succ n) a) →
    ∀ n, n = C.zero ∨ value C t n a = value C t (one C) a

/-- Auxiliary interface, discharged by derived_equality_recognition below. -/
def EqualityRecognition : Prop :=
  ∀ x y : A, x = y ↔ gate C (equalityError C x y) (one C) ≠ C.zero

variable (PC : PositiveConstancy C) (ER : EqualityRecognition C)
include PC ER

omit PC in
theorem separation : C.zero ≠ C.succ C.zero := by
  have h := (ER C.zero C.zero).mp rfl
  have hz : equalityError C C.zero C.zero = C.zero := by
    change C.run .first (gate C (monus C C.zero C.zero)
      (C.succ (monus C C.zero C.zero))) (one C) = C.zero
    rw [monus_zero C, gate_zero C]
    exact C.run_succ .first C.zero (one C)
  rw [hz, gate_zero C] at h
  intro bad
  exact h bad.symm

omit PC ER in
theorem successor_injective {x y : A} (h : C.succ x = C.succ y) : x = y := by
  have e := congrArg (pred C) h
  rw [pred_succ C, pred_succ C] at e
  exact e

omit PC in
theorem successor_ne_zero (x : A) : C.succ x ≠ C.zero := by
  intro h
  have e := congrArg (pred C) h
  rw [pred_succ C, pred_zero C] at e
  have bad : C.succ C.zero = C.zero := (congrArg C.succ e).symm.trans h
  exact separation C ER bad.symm

omit ER in
/-- The first PC instance obtains a gate law before constructor coverage. -/
theorem zero_or_gate (a x : A) : x = C.zero ∨ gate C x a = C.zero := by
  have q := PC (gateTerm .first .second) a (by
    intro n
    change gate C (C.succ (C.succ n)) a = gate C (C.succ n) a
    rw [gate_succ C, gate_succ C]) x
  rcases q with h | h
  · exact Or.inl h
  · change gate C x a = gate C (C.succ C.zero) a at h
    rw [gate_succ C] at h
    exact Or.inr h

theorem zero_decision (x : A) : x = C.zero ∨ x ≠ C.zero := by
  rcases zero_or_gate C PC (one C) x with h | h
  · exact Or.inl h
  · apply Or.inr
    intro bad
    rw [bad, gate_zero C] at h
    exact separation C ER h.symm

omit ER in
theorem gate_nonzero {x : A} (hx : x ≠ C.zero) (y : A) : gate C x y = C.zero := by
  rcases zero_or_gate C PC y x with h | h
  · exact False.elim (hx h)
  · exact h

theorem gate_nonzero_iff (x : A) : gate C x (one C) ≠ C.zero ↔ x = C.zero := by
  constructor
  · intro h
    rcases zero_or_gate C PC (one C) x with hx | hx
    · exact hx
    · exact False.elim (h hx)
  · intro h bad
    rw [h, gate_zero C] at bad
    exact separation C ER bad.symm

theorem equality_reflection (x y : A) : equalityError C x y = C.zero ↔ x = y := by
  exact ((ER x y).trans (gate_nonzero_iff C PC ER (equalityError C x y))).symm

theorem equality_decision (x y : A) : x = y ∨ x ≠ y := by
  rcases zero_decision C PC ER (equalityError C x y) with h | h
  · exact Or.inl ((equality_reflection C PC ER x y).mp h)
  · exact Or.inr (fun q => h ((equality_reflection C PC ER x y).mpr q))

theorem coverage (x : A) : x = C.zero ∨ x = C.succ (pred C x) := by
  let t := equalityErrorTerm .first (.succ (predTerm .first))
  have at_succ (n : A) : value C t (C.succ n) C.zero = C.zero := by
    change equalityError C (C.succ n) (C.succ (pred C (C.succ n))) = C.zero
    rw [pred_succ C]
    exact (equality_reflection C PC ER _ _).mpr rfl
  have q := PC t C.zero (by
    intro n
    exact (at_succ (C.succ n)).trans (at_succ n).symm) x
  rcases q with h | h
  · exact Or.inl h
  · have r := h.trans (at_succ C.zero)
    exact Or.inr ((equality_reflection C PC ER _ _).mp r)

/-- Ordinary term constancy is obtained by one predecessor delay. -/
theorem ordinary_constancy (t : Term) (a : A)
    (step : ∀ n, value C t (C.succ n) a = value C t n a) :
    ∀ n, value C t n a = value C t C.zero a := by
  let delayed := substitute t (predTerm .first) .second
  have delay (x : A) : value C delayed x a = value C t (pred C x) a := by
    exact value_substitute C t (predTerm .first) .second x a
  have positive := PC delayed a (by
    intro n
    rw [delay, delay, pred_succ C, pred_succ C]
    exact step n)
  intro n
  rcases positive (C.succ n) with hz | he
  · exact False.elim (successor_ne_zero C ER n hz)
  · rw [delay, delay, pred_succ C] at he
    change value C t n a = value C t (pred C (C.succ C.zero)) a at he
    rw [pred_succ C] at he
    exact he

def Bit (x : A) : Prop := x = C.zero ∨ x = one C

theorem gate_is_bit (x : A) : Bit C (gate C x (one C)) := by
  rcases zero_decision C PC ER x with h | h
  · exact Or.inr (by rw [h, gate_zero C])
  · exact Or.inl (gate_nonzero C PC h _)

def equalBitTerm (s t : Term) : Term := gateTerm (equalityErrorTerm s t) oneTerm
def equalBit (x y : A) : A := gate C (equalityError C x y) (one C)

theorem equalBit_is_bit (x y : A) : Bit C (equalBit C x y) :=
  gate_is_bit C PC ER _

theorem equalBit_one_iff (x y : A) : equalBit C x y = one C ↔ x = y := by
  constructor
  · intro h
    apply (ER x y).mpr
    change equalBit C x y ≠ C.zero
    intro bad
    exact separation C ER (bad.symm.trans h)
  · intro h
    rcases equalBit_is_bit C PC ER x y with hz | ho
    · exact False.elim ((ER x y).mp h hz)
    · exact ho

theorem equalBit_invariance (x y z w : A) (h : x = y ↔ z = w) :
    equalBit C x y = equalBit C z w := by
  rcases equalBit_is_bit C PC ER x y with hx | hx
  · rcases equalBit_is_bit C PC ER z w with hz | hz
    · exact hx.trans hz.symm
    · have eqxy := h.mpr ((equalBit_one_iff C PC ER z w).mp hz)
      have hx1 := (equalBit_one_iff C PC ER x y).mpr eqxy
      exact False.elim (separation C ER (hx.symm.trans hx1))
  · have eqzw := h.mp ((equalBit_one_iff C PC ER x y).mp hx)
    exact hx.trans ((equalBit_one_iff C PC ER z w).mpr eqzw).symm

/-- Successor uniqueness is derived, not included in the arithmetic schema. -/
theorem successor_solutions_equal (t u : Term) (a : A)
    (base : value C t C.zero a = value C u C.zero a)
    (stept : ∀ n, value C t (C.succ n) a = C.succ (value C t n a))
    (stepu : ∀ n, value C u (C.succ n) a = C.succ (value C u n a)) :
    ∀ n, value C t n a = value C u n a := by
  let monitor := equalBitTerm t u
  have invariant (n : A) : value C monitor (C.succ n) a = value C monitor n a := by
    change equalBit C (value C t (C.succ n) a) (value C u (C.succ n) a) =
      equalBit C (value C t n a) (value C u n a)
    apply equalBit_invariance C PC ER
    rw [stept, stepu]
    exact ⟨successor_injective C, congrArg C.succ⟩
  have q := ordinary_constancy C PC ER monitor a invariant
  intro n
  have qn := q n
  change equalBit C (value C t n a) (value C u n a) =
    equalBit C (value C t C.zero a) (value C u C.zero a) at qn
  have b := (equalBit_one_iff C PC ER _ _).mpr base
  exact (equalBit_one_iff C PC ER _ _).mp (qn.trans b)



omit PC ER in
theorem select_zero (x y : A) : select C C.zero x y = x := by
  unfold select
  rw [gate_zero C]
  exact C.run_succ .first x y

omit PC ER in
theorem select_succ (z x y : A) : select C (C.succ z) x y = y := by
  unfold select
  rw [gate_succ C]
  exact C.run_zero .first y

omit ER in
theorem select_nonzero {z : A} (hz : z ≠ C.zero) (x y : A) :
    select C z x y = y := by
  unfold select
  rw [gate_nonzero C PC hz]
  exact C.run_zero .first y

theorem select_same (z x : A) : select C z x x = x := by
  rcases zero_decision C PC ER z with h | h
  · rw [h, select_zero C]
  · exact select_nonzero C PC h x x

omit PC ER in
theorem value_select (z x y : Term) (n a : A) :
    value C (selectTerm z x y) n a =
      select C (value C z n a) (value C x n a) (value C y n a) := rfl

def parityUpdate : Term := gateTerm .second oneTerm
def parityTerm (t : Term) : Term := .iter parityUpdate t .zero
def halfUpdate : Term := selectTerm (parityTerm .first) .second (.succ .second)
def halfTerm (t : Term) : Term := .iter halfUpdate t .zero
def doubleTerm (t : Term) : Term := .iter (.succ (.succ .second)) t .zero

def parity (x : A) : A := C.run parityUpdate x C.zero
def half (x : A) : A := C.run halfUpdate x C.zero
def double (x : A) : A := C.run (.succ (.succ .second)) x C.zero

omit PC ER in
theorem parity_zero : parity C C.zero = C.zero := C.run_zero _ _
omit PC ER in
theorem parity_succ (x : A) : parity C (C.succ x) = gate C (parity C x) (one C) :=
  C.run_succ _ _ _
omit PC ER in
theorem half_zero : half C C.zero = C.zero := C.run_zero _ _
omit PC ER in
theorem half_succ (x : A) : half C (C.succ x) =
    select C (parity C x) (half C x) (C.succ (half C x)) := C.run_succ _ _ _
omit PC ER in
theorem double_zero : double C C.zero = C.zero := C.run_zero _ _
omit PC ER in
theorem double_succ (x : A) : double C (C.succ x) =
    C.succ (C.succ (double C x)) := C.run_succ _ _ _
theorem parity_is_bit (x : A) : Bit C (parity C x) := by
  rcases coverage C PC ER x with h | h
  · exact Or.inl (by rw [h, parity_zero C])
  · rw [h, parity_succ C]
    exact gate_is_bit C PC ER _

theorem parity_twice (x : A) : parity C (C.succ (C.succ x)) = parity C x := by
  rw [parity_succ C, parity_succ C]
  rcases parity_is_bit C PC ER x with h | h
  · rw [h, gate_zero C]
    exact gate_succ C C.zero (one C)
  · rw [h]
    change gate C (gate C (C.succ C.zero) (one C)) (one C) = one C
    rw [gate_succ C, gate_zero C]

theorem half_twice (x : A) : half C (C.succ (C.succ x)) = C.succ (half C x) := by
  rw [half_succ C, half_succ C, parity_succ C]
  rcases parity_is_bit C PC ER x with h | h
  · rw [h, gate_zero C, select_zero C]
    exact select_succ C C.zero (half C x) (C.succ (half C x))
  · rw [h]
    change select C (gate C (C.succ C.zero) (one C))
      (select C (C.succ C.zero) (half C x) (C.succ (half C x)))
      (C.succ (select C (C.succ C.zero) (half C x) (C.succ (half C x)))) =
      C.succ (half C x)
    rw [gate_succ C, select_succ C, select_zero C]


/-- This proof uses only the derived term-constancy principle. -/
theorem parity_double (x : A) : parity C (double C x) = C.zero := by
  let t := parityTerm (doubleTerm .first)
  have step (n : A) : value C t (C.succ n) C.zero = value C t n C.zero := by
    change parity C (double C (C.succ n)) = parity C (double C n)
    rw [double_succ C, parity_twice C PC ER]
  have q := ordinary_constancy C PC ER t C.zero step x
  change parity C (double C x) = parity C (double C C.zero) at q
  rw [double_zero C, parity_zero C] at q
  exact q

/-- Successor comparison was proved with a Boolean equality monitor. -/
theorem half_double (x : A) : half C (double C x) = x := by
  let t := halfTerm (doubleTerm .first)
  have base : value C t C.zero C.zero = value C .first C.zero C.zero := by
    change half C (double C C.zero) = C.zero
    rw [double_zero C, half_zero C]
  have step (n : A) : value C t (C.succ n) C.zero = C.succ (value C t n C.zero) := by
    change half C (double C (C.succ n)) = C.succ (half C (double C n))
    rw [double_succ C, half_twice C PC ER]
  exact successor_solutions_equal C PC ER t .first C.zero base step (fun _ => rfl) x
theorem parity_odd (x : A) : parity C (C.succ (double C x)) = one C := by
  rw [parity_succ C, parity_double C PC ER, gate_zero C]

theorem half_odd (x : A) : half C (C.succ (double C x)) = x := by
  rw [half_succ C, parity_double C PC ER, select_zero C, half_double C PC ER]

def encodeTerm (a b : Term) : Term := selectTerm b (doubleTerm a) (.succ (doubleTerm a))
def encode (a b : A) : A := select C b (double C a) (C.succ (double C a))

omit PC ER in
theorem encode_zero (a : A) : encode C a C.zero = double C a :=
  select_zero C _ _

omit PC ER in
theorem encode_one (a : A) : encode C a (one C) = C.succ (double C a) :=
  select_succ C C.zero _ _

theorem half_encode (a b : A) : half C (encode C a b) = a := by
  rcases coverage C PC ER b with h | h
  · rw [h, encode_zero C, half_double C PC ER]
  · unfold encode
    rw [h, select_succ C, half_odd C PC ER]

theorem parity_encode (a b : A) (hb : Bit C b) : parity C (encode C a b) = b := by
  rcases hb with h | h
  · rw [h, encode_zero C, parity_double C PC ER]
  · rw [h, encode_one C, parity_odd C PC ER]

def indicatorTerm (t : Term) : Term := selectTerm t .zero oneTerm
def indicator (x : A) : A := select C x C.zero (one C)

omit PC ER in
theorem indicator_zero : indicator C C.zero = C.zero := select_zero C _ _
omit ER in
theorem indicator_nonzero {x : A} (hx : x ≠ C.zero) : indicator C x = one C :=
  select_nonzero C PC hx _ _

theorem indicator_is_bit (x : A) : Bit C (indicator C x) := by
  rcases zero_decision C PC ER x with h | h
  · exact Or.inl (by rw [h, indicator_zero C])
  · exact Or.inr (indicator_nonzero C PC h)

theorem indicator_reflects (x : A) (hx : indicator C x = C.zero) : x = C.zero := by
  rcases zero_decision C PC ER x with h | h
  · exact h
  · rw [indicator_nonzero C PC h] at hx
    exact False.elim (separation C ER hx.symm)

omit PC ER in
theorem value_encode (a b : Term) (n p : A) :
    value C (encodeTerm a b) n p = encode C (value C a n p) (value C b n p) := rfl

omit PC ER in
theorem value_indicator (t : Term) (n a : A) :
    value C (indicatorTerm t) n a = indicator C (value C t n a) := rfl


/-- This target-dependent update belongs only to the computation grammar. -/
def latchUpdate (t : Term) : Term :=
  encodeTerm (halfTerm .second)
    (selectTerm (parityTerm .second)
      (indicatorTerm (substitute t (.succ .first) (halfTerm .second))) oneTerm)

def latchStateTerm (t : Term) : Term :=
  .iter (latchUpdate t) .first
    (encodeTerm .second (indicatorTerm (substitute t .zero .second)))

def latchTerm (t : Term) : Term := parityTerm (latchStateTerm t)

def latchState (t : Term) (n a : A) : A :=
  C.run (latchUpdate t) n (encode C a (indicator C (value C t C.zero a)))

def latch (t : Term) (n a : A) : A := parity C (latchState C t n a)

omit PC ER in
theorem value_latchUpdate (t : Term) (n v : A) :
    value C (latchUpdate t) n v =
      encode C (half C v)
        (select C (parity C v)
          (indicator C (value C t (C.succ n) (half C v))) (one C)) := by
  unfold latchUpdate
  rw [value_encode C, value_select C, value_indicator C, value_substitute C]
  rfl

omit PC ER in
theorem value_latchState (t : Term) (n a : A) :
    value C (latchStateTerm t) n a = latchState C t n a := by
  change C.run (latchUpdate t) n
    (value C (encodeTerm .second (indicatorTerm (substitute t .zero .second))) n a) = _
  rw [value_encode C, value_indicator C, value_substitute C]
  rfl

omit PC ER in
theorem value_latch (t : Term) (n a : A) :
    value C (latchTerm t) n a = latch C t n a := by
  change parity C (value C (latchStateTerm t) n a) = _
  rw [value_latchState C]
  rfl

omit PC ER in
theorem latchState_zero (t : Term) (a : A) :
    latchState C t C.zero a = encode C a (indicator C (value C t C.zero a)) :=
  C.run_zero _ _

omit PC ER in
theorem latchState_succ (t : Term) (n a : A) :
    latchState C t (C.succ n) a =
      encode C (half C (latchState C t n a))
        (select C (parity C (latchState C t n a))
          (indicator C (value C t (C.succ n) (half C (latchState C t n a))))
          (one C)) := by
  have q := C.run_succ (latchUpdate t) n
    (encode C a (indicator C (value C t C.zero a)))
  change latchState C t (C.succ n) a =
    value C (latchUpdate t) n (latchState C t n a) at q
  rw [value_latchUpdate C] at q
  exact q


/-- Parameter preservation invokes only the derived term-constancy principle. -/
theorem stored_parameter (t : Term) (n a : A) :
    half C (latchState C t n a) = a := by
  let f := halfTerm (latchStateTerm t)
  have vf (x : A) : value C f x a = half C (latchState C t x a) := by
    change half C (value C (latchStateTerm t) x a) = _
    rw [value_latchState C]
  have step (x : A) : value C f (C.succ x) a = value C f x a := by
    rw [vf, vf, latchState_succ C, half_encode C PC ER]
  have q := ordinary_constancy C PC ER f a step n
  rw [vf, vf, latchState_zero C, half_encode C PC ER] at q
  exact q
omit PC ER in
theorem bit_or (x y : A) (hx : Bit C x) (hy : Bit C y) :
    Bit C (select C x y (one C)) := by
  rcases hx with hx | hx
  · rw [hx, select_zero C]
    exact hy
  · rw [hx]
    change Bit C (select C (C.succ C.zero) y (one C))
    rw [select_succ C]
    exact Or.inr rfl

theorem bit_or_zero_right (x y : A)
    (h : select C x y (one C) = C.zero) : y = C.zero := by
  rcases zero_decision C PC ER x with hx | hx
  · rw [hx, select_zero C] at h
    exact h
  · rw [select_nonzero C PC hx] at h
    exact False.elim (separation C ER h.symm)

theorem latch_is_bit (t : Term) (n a : A) : Bit C (latch C t n a) :=
  parity_is_bit C PC ER _

theorem latch_zero (t : Term) (a : A) :
    latch C t C.zero a = indicator C (value C t C.zero a) := by
  unfold latch
  rw [latchState_zero C, parity_encode C PC ER _ _ (indicator_is_bit C PC ER _)]

theorem latch_succ (t : Term) (n a : A) :
    latch C t (C.succ n) a =
      select C (latch C t n a)
        (indicator C (value C t (C.succ n) a)) (one C) := by
  unfold latch
  rw [latchState_succ C]
  rw [parity_encode C PC ER _ _ (bit_or C _ _
    (parity_is_bit C PC ER _) (indicator_is_bit C PC ER _))]
  rw [stored_parameter C PC ER]

/-- The current factor is present in the latch by constructor coverage alone. -/
theorem latch_reflects (t : Term) (n a : A)
    (hn : latch C t n a = C.zero) : value C t n a = C.zero := by
  rcases coverage C PC ER n with hz | hs
  · rw [hz, latch_zero C PC ER] at hn
    rw [hz]
    exact indicator_reflects C PC ER _ hn
  · rw [hs, latch_succ C PC ER] at hn
    have hb := bit_or_zero_right C PC ER _ _ hn
    rw [hs]
    exact indicator_reflects C PC ER _ hb


/-- Contextual zero induction from positive constancy and the fixed ER sentence. -/
theorem zero_induction (t : Term) (a : A)
    (base : value C t C.zero a = C.zero)
    (step : ∀ n, value C t n a = C.zero → value C t (C.succ n) a = C.zero) :
    ∀ n, value C t n a = C.zero := by
  have constant (n : A) : latch C t (C.succ n) a = latch C t n a := by
    rcases latch_is_bit C PC ER t n a with hz | ho
    · have next := step n (latch_reflects C PC ER t n a hz)
      rw [latch_succ C PC ER, hz, next, indicator_zero C, select_zero C]
    · rw [latch_succ C PC ER, ho]
      exact select_succ C C.zero _ _
  have term_step (n : A) : value C (latchTerm t) (C.succ n) a =
      value C (latchTerm t) n a := by
    rw [value_latch C, value_latch C]
    exact constant n
  have trace := ordinary_constancy C PC ER (latchTerm t) a term_step
  intro n
  have q := trace n
  rw [value_latch C, value_latch C, latch_zero C PC ER, base, indicator_zero C] at q
  exact latch_reflects C PC ER t n a q
/-- Actual finite quantifier-free syntax with two free numerical slots. -/
inductive Formula where
  | equal (left right : Term)
  | falsehood
  | conj (left right : Formula)
  | disj (left right : Formula)
  | impl (left right : Formula)

def holds : Formula → A → A → Prop
  | .equal s t, n, a => value C s n a = value C t n a
  | .falsehood, _, _ => False
  | .conj P Q, n, a => holds P n a ∧ holds Q n a
  | .disj P Q, n, a => holds P n a ∨ holds Q n a
  | .impl P Q, n, a => holds P n a → holds Q n a

def errorTerm : Formula → Term
  | .equal s t => equalityErrorTerm s t
  | .falsehood => oneTerm
  | .conj P Q => selectTerm (errorTerm P) (errorTerm Q) oneTerm
  | .disj P Q => selectTerm (errorTerm P) .zero (errorTerm Q)
  | .impl P Q => selectTerm (errorTerm P) (errorTerm Q) .zero

/-- Constructive compilation, including material implication on decided atoms. -/
theorem error_correct (P : Formula) (n a : A) :
    value C (errorTerm P) n a = C.zero ↔ holds C P n a := by
  induction P with
  | equal s t =>
      exact equality_reflection C PC ER (value C s n a) (value C t n a)
  | falsehood =>
      change one C = C.zero ↔ False
      constructor
      · intro h
        exact separation C ER h.symm
      · intro h
        exact False.elim h
  | conj P Q ihP ihQ =>
      change select C (value C (errorTerm P) n a) (value C (errorTerm Q) n a)
        (one C) = C.zero ↔ holds C P n a ∧ holds C Q n a
      rcases zero_decision C PC ER (value C (errorTerm P) n a) with hp | hp
      · rw [hp, select_zero C]
        constructor
        · intro hq
          exact ⟨ihP.mp hp, ihQ.mp hq⟩
        · intro h
          exact ihQ.mpr h.2
      · rw [select_nonzero C PC hp]
        constructor
        · intro h
          exact False.elim (separation C ER h.symm)
        · intro h
          exact False.elim (hp (ihP.mpr h.1))
  | disj P Q ihP ihQ =>
      change select C (value C (errorTerm P) n a) C.zero
        (value C (errorTerm Q) n a) = C.zero ↔ holds C P n a ∨ holds C Q n a
      rcases zero_decision C PC ER (value C (errorTerm P) n a) with hp | hp
      · rw [hp, select_zero C]
        constructor
        · intro _
          exact Or.inl (ihP.mp hp)
        · intro _
          rfl
      · rw [select_nonzero C PC hp]
        constructor
        · intro hq
          exact Or.inr (ihQ.mp hq)
        · intro h
          rcases h with h | h
          · exact False.elim (hp (ihP.mpr h))
          · exact ihQ.mpr h
  | impl P Q ihP ihQ =>
      change select C (value C (errorTerm P) n a) (value C (errorTerm Q) n a)
        C.zero = C.zero ↔ (holds C P n a → holds C Q n a)
      rcases zero_decision C PC ER (value C (errorTerm P) n a) with hp | hp
      · rw [hp, select_zero C]
        constructor
        · intro hq _
          exact ihQ.mp hq
        · intro h
          exact ihQ.mpr (h (ihP.mp hp))
      · rw [select_nonzero C PC hp]
        constructor
        · intro _ h
          exact False.elim (hp (ihP.mpr h))
        · intro _
          rfl

theorem quantifier_free_decision (P : Formula) (n a : A) :
    holds C P n a ∨ ¬ holds C P n a := by
  rcases zero_decision C PC ER (value C (errorTerm P) n a) with h | h
  · exact Or.inl ((error_correct C PC ER P n a).mp h)
  · exact Or.inr (fun q => h ((error_correct C PC ER P n a).mpr q))

/-- The linked finite-syntax endpoint: full quantifier-free induction,
    with one arbitrary fixed numerical parameter, from PC and the fixed ER sentence. -/
theorem quantifier_free_induction (P : Formula) (a : A)
    (base : holds C P C.zero a)
    (step : ∀ n, holds C P n a → holds C P (C.succ n) a) :
    ∀ n, holds C P n a := by
  have ezero := (error_correct C PC ER P C.zero a).mpr base
  have estep (n : A) (h : value C (errorTerm P) n a = C.zero) :
      value C (errorTerm P) (C.succ n) a = C.zero := by
    apply (error_correct C PC ER P (C.succ n) a).mpr
    exact step n ((error_correct C PC ER P n a).mp h)
  have eind := zero_induction C PC ER (errorTerm P) a ezero estep
  intro n
  exact (error_correct C PC ER P n a).mp (eind n)


#print axioms value_substitute
#print axioms separation
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms zero_or_gate
#print axioms zero_decision
#print axioms gate_nonzero_iff
#print axioms equality_reflection
#print axioms equality_decision
#print axioms coverage
#print axioms ordinary_constancy
#print axioms equalBit_invariance
#print axioms successor_solutions_equal
#print axioms parity_double
#print axioms half_double
#print axioms half_encode
#print axioms parity_encode
#print axioms stored_parameter
#print axioms latch_reflects
#print axioms zero_induction
#print axioms error_correct
#print axioms quantifier_free_decision
#print axioms quantifier_free_induction


/- The new bridge: every kernel PC use is supplied by an actual Term. -/

/-- The single fixed arithmetic equation, without a new function symbol. -/
def MinCommutativity : Prop :=
  ∀ x y : A, monus C (monus C x y) y = monus C (monus C y x) x

def zeroLatchUpdate : Term := gateTerm (monusTerm .first .zero) .second

def zeroLatchTerm : Term := .iter zeroLatchUpdate .first oneTerm

def zeroLatch (n : A) : A := C.run zeroLatchUpdate n (one C)

omit PC ER in
/-- Explicitly instantiate the abstract kernel from finite syntax. -/
def bridgeKernel (pc : PositiveConstancy C) (sep : C.zero ≠ C.succ C.zero)
    (hmin : MinCommutativity C) : MinSymmetry.Kernel A where
  zero := C.zero
  succ := C.succ
  P := C.run .first
  B := gate C
  M := monus C
  q := zeroLatch C
  pZero := C.run_zero .first
  pSucc := fun n a => C.run_succ .first n a
  bZero := gate_zero C
  bSucc := gate_succ C
  mZero := monus_zero C
  mSucc := monus_succ C
  nontrivial := sep
  pcGate := by
    intro a h n
    exact pc (gateTerm .first .second) a h n
  qZero := C.run_zero zeroLatchUpdate (one C)
  qSucc := by
    intro n
    exact C.run_succ zeroLatchUpdate n (one C)
  pcLatch := by
    intro h n
    exact pc zeroLatchTerm C.zero h n
  minSymmetry := hmin

omit PC ER in
theorem min_error_correct (pc : PositiveConstancy C)
    (sep : C.zero ≠ C.succ C.zero) (hmin : MinCommutativity C)
    (x y : A) : equalityError C x y = C.zero ↔ x = y := by
  exact (bridgeKernel C pc sep hmin).error_zero_iff x y

omit PC ER in
/-- The old interface is now a theorem, not an endpoint hypothesis. -/
theorem derived_equality_recognition (pc : PositiveConstancy C)
    (sep : C.zero ≠ C.succ C.zero) (hmin : MinCommutativity C) :
    EqualityRecognition C := by
  intro x y
  constructor
  · intro hxy hz
    have herror := (min_error_correct C pc sep hmin x y).mpr hxy
    rw [herror, gate_zero C] at hz
    exact sep hz.symm
  · intro hn
    rcases zero_or_gate C pc (one C) (equalityError C x y) with hz | hg
    · exact (min_error_correct C pc sep hmin x y).mp hz
    · exact False.elim (hn hg)

omit PC ER in
/-- The final fully linked finite-syntax endpoint for the new basis. -/
theorem main_quantifier_free_induction (pc : PositiveConstancy C)
    (sep : C.zero ≠ C.succ C.zero) (hmin : MinCommutativity C)
    (P : Formula) (a : A) (base : holds C P C.zero a)
    (step : ∀ n, holds C P n a → holds C P (C.succ n) a) :
    ∀ n, holds C P n a := by
  exact quantifier_free_induction C pc
    (derived_equality_recognition C pc sep hmin) P a base step

omit PC ER in
theorem main_quantifier_free_decision (pc : PositiveConstancy C)
    (sep : C.zero ≠ C.succ C.zero) (hmin : MinCommutativity C)
    (P : Formula) (n a : A) : holds C P n a ∨ ¬ holds C P n a := by
  exact quantifier_free_decision C pc
    (derived_equality_recognition C pc sep hmin) P n a

#print axioms bridgeKernel
#print axioms min_error_correct
#print axioms derived_equality_recognition
#print axioms main_quantifier_free_induction
#print axioms main_quantifier_free_decision

#check main_quantifier_free_induction
#check main_quantifier_free_decision

end MinConstancy
