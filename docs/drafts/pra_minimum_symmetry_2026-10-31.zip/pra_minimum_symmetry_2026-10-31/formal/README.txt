Formal certificates -- Lean 4.19.0
================================

MinSymmetry.lean checks the new equality-reflection bridge over an
arbitrary carrier. Its selected positive-constancy hypotheses are exactly
the gate family B(n,a) and one explicitly described parameter-free latch.

MinConstancy.lean embeds that bridge and links it to finite term syntax.
The remaining completion is adapted, with attribution, from the inspected
positive-constancy draft. The atomic equality-error term is changed to
C(M(x,y),M(y,x),1). The file compiles independently with no imports.

Primary endpoint:
    MinConstancy.main_quantifier_free_induction

Its arithmetic assumptions are:
  - Model: the binary iterator computations;
  - PositiveConstancy: the schema over finite Term syntax, not all
    arbitrary semantic functions;
  - zero != succ zero;
  - MinCommutativity: M(M(x,y),y)=M(M(y,x),x).
It then accepts an arbitrary finite quantifier-free Formula, one fixed
numerical parameter, and that formula's induction base and step.

The endpoint MinConstancy.main_quantifier_free_decision also derives the
decision of every such formula from the same arithmetic hypotheses.

The auxiliary interface EqualityRecognition is derived internally by
derived_equality_recognition; it is NOT a final endpoint hypothesis.
No arithmetic-carrier induction, classical choice, propositional
extensionality, or assumed decidable equality is used.

All 28 '#print axioms' reports in MinConstancy.lean are empty.
The standalone MinSymmetry.lean prints five empty reports.
These are global proof-term dependency audits. Explicit arithmetic
hypotheses remain present in the theorem types.

NOT FORMALIZED HERE
The Lean files do not claim a full first-order proof calculus or
bi-interpretability metatheorem. Triangular pairing, arbitrary parameter
coding, all ordinary primitive-recursion translations, their converse,
the optional PC_Z restriction, and identity interpretation round trips
are proved in the manuscript.

Reproduce from the package root with ./check.sh; set PRA_LEAN if necessary.
