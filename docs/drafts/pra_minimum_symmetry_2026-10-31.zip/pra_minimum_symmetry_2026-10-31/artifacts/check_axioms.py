#!/usr/bin/env python3
"""Reproduce syntax counts and small transcription diagnostics.

The arithmetic theorem is proved in the report; finite checks are not its proof.
Formula-tree conventions match the inspected positive-constancy draft.
"""
import json
from dataclasses import dataclass

@dataclass(frozen=True)
class Node:
    name: str
    args: tuple = ()

def node(name, *args): return Node(name, args)
def app(name, *args): return node('app:' + name, *args)
def eq(x, y): return node('eq', x, y)
def imp(x, y): return node('implies', x, y)
def conj(x, y): return node('and', x, y)
def disj(x, y): return node('or', x, y)
def allv(name, body): return node('forall:' + name, body)
def neg(x): return imp(x, node('false'))
def iff(x, y, expanded):
    return conj(imp(x, y), imp(y, x)) if expanded else node('iff', x, y)
def size(t): return 1 + sum(map(size, t.args))
def atoms(t): return int(t.name == 'eq') + sum(map(atoms, t.args))
def metric(t): return dict(nodes=size(t), equality_occurrences=atoms(t))

z = node('zero')
S = lambda x: app('S', x)
one = S(z)
n, a, x, y = (node('var:' + s) for s in ('n','a','x','y'))
P = lambda x: app('I_counter', x, z)
B = lambda x,y: app('I_zero', x,y)
A = lambda x,y: app('I_successor', x,y)
M = lambda x,y: app('I_predecessor', x,y)
Z = lambda x: B(x,one)
f = lambda x: app('f',x,a)
rho = lambda x: app('rho',x)

def pc(call=f):
    return allv('a',imp(allv('n',eq(call(S(S(n))),call(S(n)))),
        allv('n',disj(eq(n,z),eq(call(n),call(one))))))
def er(expanded):
    delta=A(M(x,y),M(y,x))
    return allv('x',allv('y',iff(eq(x,y),neg(eq(B(delta,one),z)),expanded)))
def au(delayed=False):
    rhs=(rho(app('D_rho',n,f(z))) if delayed
         else app('I_rho',P(n),f(one)))
    return allv('a',imp(allv('n',eq(f(S(n)),rho(f(n)))),
        conj(neg(eq(z,one)),allv('n',disj(eq(n,z),eq(f(n),rhs))))))

d0=allv('a',eq(app('I_h',z,a),a))
ds=allv('n',allv('a',eq(app('I_h',S(n),a),app('h',n,app('I_h',n,a)))))
sep=neg(eq(z,one))
minimum=allv('x',allv('y',eq(M(M(x,y),y),M(M(y,x),x))))
rows={
    'D_initial':metric(d0),'D_step':metric(ds),
    'PC':metric(pc()),'Sep':metric(sep),'Min':metric(minimum),
    'old_ER_expanded_iff':metric(er(True)),
    'old_ER_primitive_iff':metric(er(False)),
    'autonomous_uniqueness':metric(au()),
    'delayed_autonomous_uniqueness':metric(au(True)),
    'zero_indicator_PC':metric(pc(lambda t:Z(app('g',t,a)))),
}
expected={'D_initial':6,'D_step':12,'PC':26,'Sep':6,'Min':13,
    'old_ER_expanded_iff':39,'old_ER_primitive_iff':20,
    'autonomous_uniqueness':36,'delayed_autonomous_uniqueness':34,
    'zero_indicator_PC':38}
assert {k:v['nodes'] for k,v in rows.items()} == expected

# These are checks of the intended numerical formulas only.
def monus(counter, seed): return max(seed-counter,0)
def selector(test, yes, no): return yes if test==0 else no
def error(x,y): return selector(monus(x,y),monus(y,x),1)
def tri(k): return k*(k+1)//2
def rank(n):
    k=0
    for t in range(1,n+1):
        if t==tri(k+1): k+=1
    return k
def pair(x,y): return tri(x+y)+y
def right(v): return monus(tri(rank(v)),v)
def left(v): return monus(right(v),rank(v))
checks=0
for i in range(80):
    for j in range(80):
        assert monus(monus(i,j),j)==monus(monus(j,i),i)==min(i,j)
        assert (error(i,j)==0)==(i==j)
        checks+=2
for i in range(30):
    for j in range(30):
        code=pair(i,j)
        assert left(code)==i and right(code)==j
        checks+=1
for i in range(80):
    for bit in (0,1):
        code=2*i+bit
        assert code//2==i and code%2==bit
        checks+=1

result={
    'convention':{
        'node':'Variables, zero, applications, equalities, connectives, falsity, and individual quantifiers each count one.',
        'expanded':'1=S0; predecessor=I_counter(x,0); negation is implication to falsity.',
        'indices':'Stored finite program descriptions index symbols; their bodies are not numerical arguments.',
        'schematic_terms':'Displayed arguments count; arbitrary substituted bodies are not charged.',
        'limits':'These are template sizes, not complete encoding lengths or a minimality theorem.'},
    'components':rows,
    'totals':{
        'old_PC_expanded_iff':18+26+39,
        'old_PC_primitive_iff':18+26+20,
        'new_PC_Sep_Min':18+26+6+13,
        'new_conjoined_fixed_block':18+26+6+13+1,
        'zero_indicator_restriction':18+38+6+13,
        'delayed_autonomous':18+34},
    'finite_diagnostics':{
        'assertions':checks,'result':'passed',
        'scope':'Standard-value transcription checks, not proof of arithmetic equivalence.'}}
print(json.dumps(result,indent=2))
