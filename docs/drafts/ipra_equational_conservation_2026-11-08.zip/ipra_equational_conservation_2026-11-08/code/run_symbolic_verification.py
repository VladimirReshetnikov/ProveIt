"""Reproduce the specialized symbolic replay and its negative controls."""
from collections import Counter
import copy
import hashlib
import json
from pathlib import Path
import platform

from symbolic_checker import InvalidCertificate, verify_certificate
from symbolic_producer import make_certificates


ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    certificates = make_certificates()
    packet_path = ROOT / "symbolic_certificates.json"
    packet_path.write_text(json.dumps(certificates, indent=2) + "\n")
    # The producer and checker communicate through serialized JSON.  No
    # producer objects, computed normal forms, or assertions are trusted.
    certificates = json.loads(packet_path.read_text())
    by_name = {c["name"]: c for c in certificates}
    if len(by_name) != len(certificates):
        raise ValueError("Duplicate certificate name")
    positive = [verify_certificate(c) for c in certificates]
    negatives = []

    def reject(name, original, mutate):
        candidate = copy.deepcopy(by_name[original])
        mutate(candidate)
        try:
            verify_certificate(candidate)
        except InvalidCertificate as error:
            negatives.append({"name": name, "rejected": True, "reason": str(error)})
        else:
            raise AssertionError("Negative control accepted: " + name)

    reject("changed_goal", "selector_idempotence",
           lambda c: c.update(goal=[0, ["S", 0]]))
    reject("missing_gluing_endpoint", "implication_introduction_identity",
           lambda c: c["proof"].pop("one"))
    reject("undeclared_boolean", "implication_introduction_identity",
           lambda c: c.update(boolean_variables=[]))
    reject("malformed_term_arity", "selector_idempotence",
           lambda c: c.update(goal=[["C", 0, 0], 0]))
    reject("boolean_python_literal_is_not_zero", "selector_idempotence",
           lambda c: c.update(goal=[False, 0]))
    reject("induction_variable_not_fresh", "selector_idempotence",
           lambda c: c["variables"].append("_ind"))
    reject("wrong_induction_base", "selector_idempotence",
           lambda c: c["proof"].update(base={"rule": "refl", "term": "x"}))
    reject("collapse_without_hypothesis", "collapse_arbitrary_equation",
           lambda c: c.update(assumptions=[]))
    reject("local_assumption_escapes", "implication_introduction_identity",
           lambda c: c.update(goal=["a", ["S", 0]],
                              proof={"rule": "hyp", "equation": ["a", ["S", 0]]}))
    reject("different_gluing_conclusions", "implication_introduction_identity",
           lambda c: c["proof"].update(one={"rule": "refl", "term": ["S", 0]}))
    reject("unknown_rule", "selector_idempotence",
           lambda c: c.update(proof={"rule": "declare_true"}))

    groups = Counter(p["group"] for p in positive)
    rules = Counter()
    for p in positive:
        rules.update(p["rule_counts"])
    main = [p for p in positive if p["group"] in {"central_selector", "collapse"}]
    if any(p["rule_counts"].get("glue", 0) for p in main):
        raise AssertionError("Main algebraic certificates must not import gluing")
    result = {
        "status": "PASS", "method": "symbolic proof-tree replay, not numerical sampling",
        "python": platform.python_version(), "positive_certificates": len(positive),
        "negative_controls": len(negatives), "groups": dict(groups),
        "total_proof_nodes": sum(p["proof_nodes"] for p in positive),
        "rule_counts": dict(rules), "main_algebraic_certificates": len(main),
        "main_algebraic_certificates_use_imported_gluing": False,
        "claim_boundary": [
            "The checker is specialized to symbolic equations, not a complete iPRA kernel.",
            "Selector endpoint equations and literal-equation induction are trusted mathematical rules.",
            "Supplemental Boolean schemas explicitly import equational Boolean gluing.",
            "No Boolean-range disjunction or arbitrary-formula gluing rule is accepted.",
            "The program does not verify cut elimination, conservation, the arithmetic bootstrap, or bi-interpretability.",
            "The main mathematical argument does not depend on the optional Boolean truth-schema supplement."
        ],
        "sha256": {p.name: digest(p) for p in [ROOT / "symbolic_checker.py",
                    ROOT / "symbolic_producer.py", ROOT / "run_symbolic_verification.py", packet_path]},
        "positive": positive, "negative": negatives,
    }
    (ROOT / "symbolic_verification_receipt.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in ["status", "positive_certificates",
          "negative_controls", "groups", "total_proof_nodes", "main_algebraic_certificates",
          "main_algebraic_certificates_use_imported_gluing"]}, indent=2))


if __name__ == "__main__":
    main()
