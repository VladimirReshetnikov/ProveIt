"""Small, explicit symbolic-equation certificate checker.

This is NOT an iPRA proof checker.  Its trusted mathematical interface is:
equality; selector endpoint equations; endpoint equation induction; and,
only when a certificate uses `glue`, the stated equational Boolean-gluing
metatheorem.  It does not check the proof of that metatheorem, cut elimination,
the arithmetic bootstrap, or bi-interpretability.

Terms are 0, declared variable names, or [symbol, argument, ...].  The
signature is C/3, S/1 and two opaque fixed symbols f/1, g/2.  One means S(0).
No numerical evaluation of f or g, or of an arbitrary C-control, occurs.
"""
from collections import Counter
import argparse
import json
from pathlib import Path
import re


ARITIES = {"C": 3, "S": 1, "f": 1, "g": 2}
IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z_0-9]*\Z")
ONE = ("S", 0)


class InvalidCertificate(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise InvalidCertificate(message)


def fields(node, names):
    require(type(node) is dict, "Proof node must be an object")
    require(set(node) == set(names), "Wrong or missing fields: " + repr(sorted(names)))


def variable_name(name):
    require(type(name) is str and IDENTIFIER.fullmatch(name),
            "Malformed variable name")
    require(name not in ARITIES, "Variable collides with function symbol")
    return name


def term(raw, variables):
    if type(raw) is int:
        require(raw == 0, "Only zero is a primitive numeric literal; one is S(0)")
        return 0
    if type(raw) is str:
        require(raw in variables, "Undeclared variable: " + raw)
        return raw
    require(type(raw) is list and raw, "Malformed term syntax")
    symbol = raw[0]
    require(type(symbol) is str and symbol in ARITIES, "Unknown function symbol")
    require(len(raw) == 1 + ARITIES[symbol], "Wrong function arity")
    return (symbol, *(term(t, variables) for t in raw[1:]))


def equation(raw, variables):
    require(type(raw) is list and len(raw) == 2, "An equation has two terms")
    return term(raw[0], variables), term(raw[1], variables)


def substitute(t, name, value):
    if type(t) is str:
        return value if t == name else t
    if type(t) is tuple:
        return (t[0], *(substitute(u, name, value) for u in t[1:]))
    return t


def substitute_equation(eq, name, value):
    return tuple(substitute(t, name, value) for t in eq)


def free_variables(t):
    if type(t) is str:
        return {t}
    if type(t) is tuple:
        return set().union(*(free_variables(u) for u in t[1:]))
    return set()


def boolean_guard(name):
    return ("C", name, 0, ONE), name


class Replay:
    def __init__(self, boolean_variables):
        self.boolean_variables = set(boolean_variables)
        self.counts = Counter()
        self.max_depth = 0

    def infer(self, proof, context, variables, depth=0):
        require(type(proof) is dict and type(proof.get("rule")) is str,
                "Missing proof rule")
        rule = proof["rule"]
        self.counts[rule] += 1
        self.max_depth = max(self.max_depth, depth)

        def child(p, ctx=context, allowed=variables):
            return self.infer(p, ctx, allowed, depth + 1)

        if rule == "hyp":
            fields(proof, {"rule", "equation"})
            eq = equation(proof["equation"], variables)
            require(eq in context, "Hypothesis is not in the current context")
            return eq
        if rule == "refl":
            fields(proof, {"rule", "term"})
            t = term(proof["term"], variables)
            return t, t
        if rule == "sym":
            fields(proof, {"rule", "proof"})
            left, right = child(proof["proof"])
            return right, left
        if rule == "trans":
            fields(proof, {"rule", "left", "right"})
            left, middle = child(proof["left"])
            middle2, right = child(proof["right"])
            require(middle == middle2, "Transitivity middle terms differ")
            return left, right
        if rule == "cong":
            fields(proof, {"rule", "symbol", "arguments"})
            symbol = proof["symbol"]
            require(type(symbol) is str and symbol in ARITIES,
                    "Unknown congruence symbol")
            args = proof["arguments"]
            require(type(args) is list and len(args) == ARITIES[symbol],
                    "Wrong congruence arity")
            equalities = [child(p) for p in args]
            return ((symbol, *(e[0] for e in equalities)),
                    (symbol, *(e[1] for e in equalities)))
        if rule == "endpoint":
            fields(proof, {"rule", "control", "zero", "successor"})
            n = term(proof["control"], variables)
            a = term(proof["zero"], variables)
            b = term(proof["successor"], variables)
            require(n == 0 or (type(n) is tuple and n[0] == "S"),
                    "Selector endpoint requires 0 or a syntactic successor")
            return ("C", n, a, b), a if n == 0 else b
        if rule == "endpoint_induction":
            fields(proof, {"rule", "variable", "eigenvariable", "equation",
                           "at", "base", "step"})
            n = variable_name(proof["variable"])
            k = variable_name(proof["eigenvariable"])
            require(n != k and n not in variables and k not in variables,
                    "Induction variables must be fresh for the outer signature")
            template = equation(proof["equation"], variables | {n})
            at = term(proof["at"], variables)
            require(all(n not in free_variables(t) and k not in free_variables(t)
                        for eq in context for t in eq),
                    "Induction variable occurs in retained context")
            base = child(proof["base"])
            step = child(proof["step"], allowed=variables | {k})
            require(base == substitute_equation(template, n, 0),
                    "Wrong induction base equation")
            require(step == substitute_equation(template, n, ("S", k)),
                    "Wrong induction successor equation")
            # This is EqInd with its induction hypothesis unused.  There is
            # no case rule for arbitrary formulas and no Boolean range axiom.
            return substitute_equation(template, n, at)
        if rule == "glue":
            fields(proof, {"rule", "variable", "zero", "one"})
            b = variable_name(proof["variable"])
            require(b in variables and b in self.boolean_variables,
                    "Gluing variable is not declared Boolean")
            require(boolean_guard(b) in context, "Missing Boolean guard B(b)=b")
            zero = child(proof["zero"], context + ((b, 0),))
            one = child(proof["one"], context + ((b, ONE),))
            require(zero == one, "Gluing branches have different conclusions")
            # Explicitly imported theorem: equational contexts and conclusions
            # only.  This rule does NOT assert b=0 or b=1 in the object logic.
            return zero
        raise InvalidCertificate("Unknown proof rule: " + rule)


def verify_certificate(certificate):
    fields(certificate, {"name", "group", "description", "variables",
                         "boolean_variables", "assumptions", "goal", "proof"})
    require(all(type(certificate[k]) is str for k in ("name", "group", "description")),
            "Name, group, and description must be text")
    require(type(certificate["variables"]) is list, "Variable list required")
    names = [variable_name(n) for n in certificate["variables"]]
    require(len(names) == len(set(names)), "Repeated variable declaration")
    variables = set(names)
    bvars = certificate["boolean_variables"]
    require(type(bvars) is list and all(type(b) is str for b in bvars),
            "Boolean variable list required")
    require(len(bvars) == len(set(bvars)) and set(bvars) <= variables,
            "Bad Boolean variable declaration")
    require(type(certificate["assumptions"]) is list, "Assumptions must be a list")
    context = tuple(boolean_guard(b) for b in bvars)
    context += tuple(equation(eq, variables) for eq in certificate["assumptions"])
    goal = equation(certificate["goal"], variables)
    replay = Replay(bvars)
    derived = replay.infer(certificate["proof"], context, variables)
    require(derived == goal, "Derived equation differs from the requested goal")
    imports = ["equality"]
    if replay.counts["endpoint"]:
        imports.append("selector endpoint equations C(0,x,y)=x and C(Sn,x,y)=y")
    if replay.counts["endpoint_induction"]:
        imports.append("literal-equation induction with unused induction hypothesis")
    if replay.counts["glue"]:
        imports.append("equational Boolean-gluing metatheorem (imported, not proved here)")
    return {"name": certificate["name"], "group": certificate["group"],
            "accepted": True, "proof_nodes": sum(replay.counts.values()),
            "max_depth": replay.max_depth, "rule_counts": dict(replay.counts),
            "mathematical_imports": imports}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificates", type=Path)
    args = parser.parse_args()
    packet = json.loads(args.certificates.read_text())
    certificates = packet if type(packet) is list else [packet]
    print(json.dumps([verify_certificate(c) for c in certificates], indent=2))


if __name__ == "__main__":
    main()
