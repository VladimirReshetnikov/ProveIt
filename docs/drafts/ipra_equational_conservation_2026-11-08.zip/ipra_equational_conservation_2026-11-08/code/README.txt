SYMBOLIC SELECTOR CERTIFICATES AND FROZEN CHECKER COMPARISON
=========================================================

Purpose and exact claim boundary
--------------------------------

This package supplies a fresh, transparent specialized equation verifier,
an independent proof producer, explicit JSON proof trees, negative controls,
and a frozen-source measurement reproduction. It is NOT a complete iPRA
proof checker and is NOT entered as a smaller axiomatization or checker.

The main proof replay has 17 algebraic certificates. It uses equality,
the two selector endpoint schemas, and literal-equation induction with its
induction hypothesis unused. It does not import Boolean gluing. The main
certificate list is:

  selector idempotence; left and right absorption;
  left and right projections; two-projection recovery;
  left and right Boolean endpoints;
  centrality for an opaque unary f and an opaque binary g;
  compatibility of each projection with f;
  idempotence of B and equality B=Z composed with Z;
  joint-kernel reflection; unary congruence of the left kernel;
  collapse of an arbitrary equation from 0=S(0).

There are also 27 optional Boolean certificates: all endpoint truth tables
for conjunction, disjunction, implication and negation; Boolean closure;
several propositional equation sequents; and two actual local-premise
compilations for implication introduction. These supplement the algebraic
engine. The paper's main conservation argument need not depend on them.

The programs do NOT verify cut elimination, the general conservation
metatheorem, the complete primitive-recursive bootstrap, the equivalence
with iPRA, or either interpretation composite.

Reproduction
------------

Run using Python 3.12 (the recorded environment is CPython 3.12.14):

  python3 run_symbolic_verification.py
  python3 ../comparison/measure.py

The first command rewrites symbolic_certificates.json from the untrusted
producer, serializes and reloads it, and checks every proof with the separate
symbolic_checker.py. It writes symbolic_verification_receipt.json. The
second command checks the hashes of all twelve frozen baseline programs
and the unchanged source normalizer, then writes ../results/measurements.json.
It measures the old programs without executing them. No network is used.

To replay the explicit certificate file without running the producer:

  python3 symbolic_checker.py symbolic_certificates.json

The initial verified run accepted 44 certificates (1910 proof nodes) and
rejected all 11 negative controls. These are symbolic derivations, not
bounded numerical experiments. In particular, f and g remain opaque symbols
and the induction successor parameter is a fresh variable, not a numeral.

Syntax and the trusted mathematical interface
--------------------------------------------

The signature is 0, S/1, C/3, f/1, g/2. The last two symbols are arbitrary
fixed operations. Terms in JSON are the literal integer 0, a declared
variable name, or [symbol, argument, ...]. One is ["S", 0]; Python booleans
and all other numeric literals are rejected. An equation is [left, right].
Every symbol's arity and every free variable are checked.

The only proof rules are:

  hyp:       a displayed equation belongs to the current context;
  refl:      t=t;
  sym:       symmetry of a checked equation;
  trans:     transitivity, with literal agreement of the middle terms;
  cong:      congruence for one symbol, with a proof for every argument;
  endpoint:  C(0,x,y)=x or C(Sn,x,y)=y;
  endpoint_induction:
             from E(0) and E(Sk), infer E(t), for a literal equation E,
             with k and the induction placeholder fresh for all retained
             assumptions and the outer variables;
  glue:      the explicitly imported equational Boolean-gluing metatheorem,
             limited to a declared b with the actual equation B(b)=b in
             context, and two checked equational branches at b=0 and b=1
             having exactly the same conclusion.

Endpoint induction is ordinary equation induction with the induction
hypothesis unused. It is not a numerical coverage axiom or a cases rule for
arbitrary formulas. No proof step numerically evaluates an opaque operation
or a selector whose control has not become 0 or a syntactic successor.

The glue rule is deliberately exposed as an import. It is not being proved
by the supplementary Boolean proof trees. The central-selector certificates
that supply the algebraic engine for its mathematical proof do not use it.
The scope of glue is equations under equational assumptions only. There is
no constructor for a disjunctive conclusion or a negative assumption here.

Selector notation and the minor strengthening
--------------------------------------------

  q_b(x,y) = C(b,x,y)
  p_b(x)   = C(b,x,0)
  r_b(x)   = C(b,0,x)
  B(n)     = C(n,0,1)
  Z(n)     = C(n,1,0)

An unconditional endpoint-induction certificate proves B(n)=Z(Z(n)), so
this spelling of B agrees with the zero-test convention used in the paper.

The centrality, absorption, projection, recovery, and left-endpoint
identities hold for every b, without the guard B(b)=b. Direct endpoint
equation induction on b proves them. The right endpoint
r_b(b)=r_b(1) needs the guard. Its certificate first proves the corresponding
equation at b=B(n), then substitutes n=b and transports along B(b)=b.
This small strengthening is immediate from the endpoint argument; no
independent novelty claim is attached to it.

The kernel-congruence certificate concerns the equivalence relation
p_b(x)=p_b(y). It does not assert that p_b preserves the named constants.
That distinction is important when interpreting equality in a quotient.

Optional Boolean notation
-------------------------

Truth is 1=S(0), falsity is 0. For algebraically Boolean inputs:

  a AND b  = C(a,0,b)
  a OR b   = C(a,b,1)
  a -> b   = C(a,1,b)
  NOT a    = C(a,1,0)

Declaring a variable Boolean merely adds the equation B(a)=a to the
equational context. It does NOT add a=0 OR a=1. The imported gluing theorem
allows two equational branch proofs to be combined under that guard.
These certificates therefore do not confuse algebraic Booleanity with
constructive Boolean range, nor identify every first-order formula with
a Boolean-valued term.

The producer's implication_introduction constructor takes a supplied
actual proof of Gamma,a=1 |- b=1. It builds the zero endpoint directly and
inserts the supplied local proof only in the one branch. The checker has
no implication-introduction shortcut. It replays the expanded equality
proof and checks every local hypothesis. A regression deliberately moves
the local assumption outside its branch and must be rejected.

Negative controls
-----------------

The receipt records rejection of: a changed goal; a missing gluing branch;
an undeclared Boolean variable; malformed term arity; a Python Boolean
literal masquerading as zero; a nonfresh induction variable; an incorrect
induction base; collapse without its assumption; an escaping local
assumption; mismatched gluing conclusions; and an unknown proof rule.
These focused checks support the concrete implementation. They are not
a machine-checked metatheorem about the verifier's soundness.

Frozen comparison and provenance
--------------------------------

../comparison/checkers/ contains twelve complete prior acceptance programs copied
unchanged from the comparison payload of the current closed-updates-v2
archive. Their retained archive is
docs/drafts/ipra_closed_updates_2026-11-08(1).zip at repository snapshot
9773e5e0376fdaf953567d0e1e6f19570d566bc6, Git blob
b2ece06c2c842f3eca1c8d5efd27bf714d7b346c.

These programs are historical comparators inside the six live reports,
not twelve new live submissions. The original source notices, inherited
snapshot metadata, and attribution files are preserved. The normalizer is
also copied unchanged, including its original documentation. The new driver
imports only its metrics function, checks hashes, and records all counts.

Under the inherited whole-program accounting, the envelope is
317 normalized tokens / 348 AST nodes / 885 normalized bytes. The structural
profile attains the first two coordinates; the primary profile attains the
byte coordinate. No single program attains all three. Genuine docstrings
are removed; imports, I/O, scope validation, rule checking, and rejection
handling count. The source is normalized with ast.unparse.

The symbolic producer and checker in this package were written afresh for
this investigation. They implement no copied prior checking code. Their
mathematical selector and gluing interface is inherited from the supplied
Boolean-gluing and equational-core drafts and is credited as such. There is
no claim that these much more explicit specialized files improve the size
of a complete iPRA kernel.
