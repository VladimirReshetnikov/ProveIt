"""Produce explicit proof trees for symbolic selector identities.

The producer is untrusted.  symbolic_checker.py replays every equality step.
Central-selector certificates use endpoint equation induction, not Boolean
gluing.  Optional propositional certificates use the explicitly imported
equational gluing theorem.  Truth is S(0), falsity is 0.
"""
import json
from pathlib import Path


ZERO = 0
ONE = ("S", 0)


def C(n, a, b):
    return ("C", n, a, b)


def S(n):
    return ("S", n)


def B(n):
    return C(n, ZERO, ONE)


def Z(n):
    return C(n, ONE, ZERO)


def conjunction(a, b):
    return C(a, ZERO, b)


def disjunction(a, b):
    return C(a, b, ONE)


def implication(a, b):
    return C(a, ONE, b)


def negation(a):
    return C(a, ONE, ZERO)


def p(b, x):
    return C(b, x, ZERO)


def r(b, x):
    return C(b, ZERO, x)


def refl(t):
    return {"rule": "refl", "term": t}


def hyp(eq):
    return {"rule": "hyp", "equation": eq}


def sym(proof):
    return {"rule": "sym", "proof": proof}


def trans(*proofs):
    result = proofs[0]
    for proof in proofs[1:]:
        result = {"rule": "trans", "left": result, "right": proof}
    return result


def cong(symbol, *arguments):
    return {"rule": "cong", "symbol": symbol, "arguments": arguments}


def endpoint(control, zero, successor):
    return {"rule": "endpoint", "control": control,
            "zero": zero, "successor": successor}


def substitute(t, name, value):
    if type(t) is str:
        return value if t == name else t
    if type(t) is tuple:
        return (t[0], *(substitute(u, name, value) for u in t[1:]))
    return t


def substitute_equation(eq, name, value):
    return tuple(substitute(t, name, value) for t in eq)


def normalize(t, assignments=None):
    """Return a symbolic normal term and a proof of t = normal term.

    This only unfolds a selector whose control has become literally 0 or
    S(k).  Opaque f and g are never evaluated.  Assignment rewrites are
    explicit hypothesis leaves, not an implicit semantic evaluator.
    """
    assignments = assignments or {}
    if type(t) is str:
        if t in assignments:
            return assignments[t], hyp((t, assignments[t]))
        return t, refl(t)
    if type(t) is not tuple:
        return t, refl(t)
    children = [normalize(u, assignments) for u in t[1:]]
    values = [c[0] for c in children]
    proof = cong(t[0], *(c[1] for c in children))
    if t[0] == "C":
        control, a, b = values
        if control == ZERO or (type(control) is tuple and control[0] == "S"):
            return (a if control == ZERO else b,
                    trans(proof, endpoint(control, a, b)))
    return (t[0], *values), proof


def collapse(left, right, zero_equals_one):
    """Construct left = right from 0 = S(0), using equality only."""
    return trans(sym(endpoint(ZERO, left, right)),
                 cong("C", zero_equals_one, refl(left), refl(right)),
                 endpoint(ONE, left, right))


def normalized_equation(goal, assignments=None, assumptions=()):
    assignments = assignments or {}
    left, pl = normalize(goal[0], assignments)
    right, pr = normalize(goal[1], assignments)
    if left == right:
        return trans(pl, sym(pr))
    for assumption in assumptions:
        a, pa = normalize(assumption[0], assignments)
        b, pb = normalize(assumption[1], assignments)
        contradiction = trans(sym(pa), hyp(assumption), pb)
        if (a, b) == (ONE, ZERO):
            contradiction = sym(contradiction)
        elif (a, b) != (ZERO, ONE):
            continue
        return trans(pl, collapse(left, right, contradiction), sym(pr))
    raise ValueError("Unproved symbolic endpoint: " + repr((left, right)))


def endpoint_induction(goal, variable):
    """Prove an equation by literal-equation induction, ignoring its IH."""
    template = substitute_equation(goal, variable, "_ind")
    return {"rule": "endpoint_induction", "variable": "_ind",
            "eigenvariable": "_eig", "equation": template, "at": variable,
            "base": normalized_equation(substitute_equation(template, "_ind", ZERO)),
            "step": normalized_equation(substitute_equation(template, "_ind", S("_eig")))}


def substitution_congruence(t, variable, equality):
    if t == variable:
        return equality
    if type(t) is tuple:
        return cong(t[0], *(substitution_congruence(u, variable, equality)
                            for u in t[1:]))
    return refl(t)


def boolean_endpoint_induction(goal, variable):
    """Prove G(b) by endpoint induction on G(B(n)) and the guard B(b)=b."""
    template = substitute_equation(goal, variable, B("_ind"))
    theorem = {"rule": "endpoint_induction", "variable": "_ind",
               "eigenvariable": "_eig", "equation": template, "at": variable,
               "base": normalized_equation(substitute_equation(template, "_ind", ZERO)),
               "step": normalized_equation(substitute_equation(template, "_ind", S("_eig")))}
    guard = hyp((B(variable), variable))
    left = substitution_congruence(goal[0], variable, guard)
    right = substitution_congruence(goal[1], variable, guard)
    return trans(sym(left), theorem, right)


def glue_sequent(goal, boolean_variables, assumptions=(), assignments=None):
    """Produce a finite symbolic tree using imported equational gluing."""
    assignments = assignments or {}
    if not boolean_variables:
        return normalized_equation(goal, assignments, assumptions)
    variable, *rest = boolean_variables
    return {"rule": "glue", "variable": variable,
            "zero": glue_sequent(goal, rest, assumptions,
                                  {**assignments, variable: ZERO}),
            "one": glue_sequent(goal, rest, assumptions,
                                 {**assignments, variable: ONE})}


def implication_introduction(a, b, local_proof):
    """Compile a local proof Gamma,a=1 |- b=1 into Gamma |- (a->b)=1.

    The caller must supply the actual local proof; it is inserted only under
    the one branch of gluing.  Replay checks its hypotheses there.  This
    constructor performs no axiom admission and is not a checker rule.
    """
    zero = trans(cong("C", hyp((a, ZERO)), refl(ONE), refl(b)),
                 endpoint(ZERO, ONE, b))
    one = trans(cong("C", hyp((a, ONE)), refl(ONE), refl(b)),
                endpoint(ONE, ONE, b), local_proof)
    return {"rule": "glue", "variable": a, "zero": zero, "one": one}


def wire(value):
    if type(value) in (list, tuple):
        return [wire(v) for v in value]
    if type(value) is dict:
        return {k: wire(v) for k, v in value.items()}
    return value


def certificate(name, group, description, variables, goal, proof,
                boolean_variables=(), assumptions=()):
    return wire({"name": name, "group": group, "description": description,
                 "variables": list(variables), "boolean_variables": list(boolean_variables),
                 "assumptions": list(assumptions), "goal": goal, "proof": proof})


def make_certificates():
    certificates = []

    def central(name, variables, left, right, boolean=False):
        goal = (left, right)
        proof = (boolean_endpoint_induction(goal, "b") if boolean
                 else endpoint_induction(goal, "b"))
        certificates.append(certificate(
            name, "central_selector", "Symbolic selector identity by endpoint equation induction",
            variables, goal, proof, ["b"] if boolean else []))

    central("selector_idempotence", ["b", "x"], C("b", "x", "x"), "x")
    central("selector_left_absorption", ["b", "x", "y", "z"],
            C("b", C("b", "x", "y"), "z"), C("b", "x", "z"))
    central("selector_right_absorption", ["b", "x", "y", "z"],
            C("b", "x", C("b", "y", "z")), C("b", "x", "z"))
    central("left_projection", ["b", "x", "y"],
            p("b", C("b", "x", "y")), p("b", "x"))
    central("right_projection", ["b", "x", "y"],
            r("b", C("b", "x", "y")), r("b", "y"))
    central("two_projection_recovery", ["b", "x"],
            C("b", p("b", "x"), r("b", "x")), "x")
    central("left_boolean_endpoint", ["b"], p("b", "b"), p("b", ZERO))
    central("right_boolean_endpoint", ["b"], r("b", "b"), r("b", ONE), True)
    central("opaque_unary_homomorphism", ["b", "x", "y"],
            ("f", C("b", "x", "y")), C("b", ("f", "x"), ("f", "y")))
    central("opaque_binary_homomorphism", ["b", "x", "y", "z", "w"],
            ("g", C("b", "x", "y"), C("b", "z", "w")),
            C("b", ("g", "x", "z"), ("g", "y", "w")))
    central("left_projection_compatibility", ["b", "x"],
            p("b", ("f", "x")), p("b", ("f", p("b", "x"))))
    central("right_projection_compatibility", ["b", "x"],
            r("b", ("f", "x")), r("b", ("f", r("b", "x"))))

    for name, goal in [
        ("boolean_projector_idempotence", (B(B("n")), B("n"))),
        ("boolean_projector_equals_double_zero_test", (B("n"), Z(Z("n"))))]:
        certificates.append(certificate(name, "central_selector",
            "Unconditional equation; it does not assert Boolean range",
            ["n"], goal, endpoint_induction(goal, "n")))

    px, py, rx, ry = p("b", "x"), p("b", "y"), r("b", "x"), r("b", "y")
    recx = (C("b", px, rx), "x")
    recy = (C("b", py, ry), "y")
    recovery = trans(sym(endpoint_induction(recx, "b")),
                     cong("C", refl("b"), hyp((px, py)), hyp((rx, ry))),
                     endpoint_induction(recy, "b"))
    certificates.append(certificate("joint_kernel_reflection", "central_selector",
        "Equality of both projections implies equality of their source elements",
        ["b", "x", "y"], ("x", "y"), recovery, assumptions=[(px, py), (rx, ry)]))

    fx, fy = ("f", "x"), ("f", "y")
    compatibility_x = (p("b", fx), p("b", ("f", px)))
    compatibility_y = (p("b", fy), p("b", ("f", py)))
    kernel_congruence = trans(endpoint_induction(compatibility_x, "b"),
        cong("C", refl("b"), cong("f", hyp((px, py))), refl(ZERO)),
        sym(endpoint_induction(compatibility_y, "b")))
    certificates.append(certificate("left_kernel_unary_congruence", "central_selector",
        "The kernel of p is a congruence; p itself need not preserve constants",
        ["b", "x", "y"], (p("b", fx), p("b", fy)), kernel_congruence,
        assumptions=[(px, py)]))

    certificates.append(certificate("collapse_arbitrary_equation", "collapse",
        "From 0=S(0), derive x=y by selector congruence, without falsity",
        ["x", "y"], ("x", "y"), collapse("x", "y", hyp((ZERO, ONE))),
        assumptions=[(ZERO, ONE)]))

    operations = [("and", conjunction), ("or", disjunction), ("implies", implication)]
    for name, op in operations:
        for a in (ZERO, ONE):
            for b in (ZERO, ONE):
                expression = op(a, b)
                value, proof = normalize(expression)
                index = str(int(a == ONE)) + str(int(b == ONE))
                certificates.append(certificate("truth_" + name + "_" + index,
                    "boolean_supplement", "Closed endpoint computation; truth is S(0)",
                    [], (expression, value), proof))
        expression = op("a", "b")
        goal = (B(expression), expression)
        certificates.append(certificate("boolean_closure_" + name, "boolean_supplement",
            "Boolean inputs produce an algebraically Boolean output",
            ["a", "b"], goal, glue_sequent(goal, ["a", "b"]), ["a", "b"]))

    for a in (ZERO, ONE):
        expression = negation(a)
        value, proof = normalize(expression)
        certificates.append(certificate("truth_not_" + str(int(a == ONE)),
            "boolean_supplement", "Closed endpoint computation for negation",
            [], (expression, value), proof))

    a, b, c = "a", "b", "c"
    schemas = [
        ("and_introduction", [(a, ONE), (b, ONE)], (conjunction(a, b), ONE)),
        ("and_elimination_left", [(conjunction(a, b), ONE)], (a, ONE)),
        ("and_elimination_right", [(conjunction(a, b), ONE)], (b, ONE)),
        ("or_introduction_left", [(a, ONE)], (disjunction(a, b), ONE)),
        ("or_introduction_right", [(b, ONE)], (disjunction(a, b), ONE)),
        ("implication_elimination", [(implication(a, b), ONE), (a, ONE)], (b, ONE)),
        ("encoded_or_elimination", [(disjunction(a, b), ONE),
                                   (implication(a, c), ONE),
                                   (implication(b, c), ONE)], (c, ONE)),
        ("encoded_implication_composition", [(implication(a, b), ONE),
                                             (implication(b, c), ONE)],
                                            (implication(a, c), ONE)),
    ]
    for name, assumptions, goal in schemas:
        variables = ["a", "b", "c"] if "c" in repr((assumptions, goal)) else ["a", "b"]
        certificates.append(certificate(name, "boolean_supplement",
            "Equation sequent about Boolean-valued terms, not arbitrary first-order formulas",
            variables, goal, glue_sequent(goal, variables, assumptions), variables, assumptions))

    # A real local-premise compilation: from c=1, assume a=1 and prove
    # a AND c = 1.  Insert that proof only into the one branch of implication
    # introduction.  No local assumption remains in the final context.
    target = conjunction(a, c)
    local = trans(cong("C", hyp((a, ONE)), refl(ZERO), hyp((c, ONE))),
                  endpoint(ONE, ZERO, ONE))
    certificates.append(certificate("implication_introduction_local_premise",
        "boolean_supplement", "Actual scoped proof of c=1 |- a -> (a AND c) = 1",
        ["a", "c"], (implication(a, target), ONE),
        implication_introduction(a, target, local), ["a", "c"], [(c, ONE)]))

    certificates.append(certificate("implication_introduction_identity",
        "boolean_supplement", "Discharge the local equation a=1 to prove a -> a = 1",
        ["a"], (implication(a, a), ONE),
        implication_introduction(a, a, hyp((a, ONE))), ["a"]))
    return certificates


def main():
    destination = Path(__file__).resolve().parent / "symbolic_certificates.json"
    certificates = make_certificates()
    destination.write_text(json.dumps(certificates, indent=2) + "\n")
    print(json.dumps({"file": str(destination), "certificates": len(certificates)}))


if __name__ == "__main__":
    main()
