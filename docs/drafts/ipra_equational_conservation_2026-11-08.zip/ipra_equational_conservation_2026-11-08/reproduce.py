"""Replay the limited symbolic evidence and reproduce the pinned source-size comparison."""
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    for relative in ('code/run_symbolic_verification.py', 'comparison/measure.py'):
        subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT, check=True)
    shutil.copy2(ROOT / 'code' / 'symbolic_verification_receipt.json',
                 ROOT / 'results' / 'symbolic_verification.json')
    symbolic = json.loads((ROOT / 'results' / 'symbolic_verification.json').read_text())
    metrics = json.loads((ROOT / 'results' / 'measurements.json').read_text())
    result = {
        'status': 'PASS', 'python': platform.python_version(),
        'symbolic_certificates': symbolic['positive_certificates'],
        'symbolic_nodes': symbolic['total_proof_nodes'],
        'negative_controls_rejected': symbolic['negative_controls'],
        'main_certificates_import_gluing': symbolic['main_algebraic_certificates_use_imported_gluing'],
        'complete_comparator_count': metrics['program_count'],
        'inherited_coordinate_envelope': metrics['coordinatewise_minimum'],
        'full_metatheory_formally_checked': False,
        'new_smaller_complete_checker': False
    }
    (ROOT / 'results' / 'reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
