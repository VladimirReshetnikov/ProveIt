Closed-update arithmetic: equational conservation and the iPRA boundary
=====================================================================

Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date).

STATUS
------
The requested complete axiomatization below every current checker benchmark
has NOT been established. No new smallest complete checker is claimed.

The new mathematical result relative to the six inspected current reports
is a full first-order EQUATIONAL conservation theorem. From any proof of an
equation from equation assumptions in the closed-update theory with Boolean
range and the falsity bridge, a finite proof transformation produces a proof
using only ordinary equality, closed-update computation, and equation
induction. Arbitrary quantified intermediates are allowed in the source.

The key step puts Boolean range into an equation-branch split rule and the
bridge into a formula-parametric collapse rule. Every cut on a formula other
than a literal equation can then be removed. Equational Boolean gluing
removes the remaining splits. This does not claim conservativity for arbitrary
formulas or negative assumptions retained unchanged.

The theorem combines two previously separate advances: closed updates and
branch-free arithmetic reconstruction. It transfers the predecessor, pairing,
and complete primitive-recursion compiler into the bare closed-update
equational theory. Both algebraic translation composites are internally the
identity. The full iPRA presentation still includes its logical boundary.

FILES
-----
report.pdf, report.tex       Main paper and complete primary LaTeX source.
code/                       Symbolic certificate producer/replayer and controls.
comparison/                 Frozen complete benchmark programs and normalizer.
results/                    Reproducible receipts, measurements, and QA.
references/                 Pinned inherited mathematical sources, attributed.
provenance/                 Current six-archive snapshot and integrity metadata.
reproduce.py                Offline artifact checks and source measurement.
Makefile                    PDF build and reproduction commands.
SHA256SUMS                  Hashes for all other delivered files.

The paper states all logical and nonlogical rules, the whole-domain
bi-interpretations for the completed theory, and the limits of the result.
The new proof transformation is a written proof, independently checked during
this investigation. The included programs are limited symbolic certificates
and source-size audits, not a Lean/Rocq formalization or a full implementation
of first-order cut elimination.

PINNED COMPARISON
-----------------
Repository: VladimirReshetnikov/ProveIt
Commit: 9773e5e0376fdaf953567d0e1e6f19570d566bc6
Directory: docs/drafts

The six live archives retain twelve principal complete comparison programs.
Their inherited normalized coordinate envelope is 317 tokens / 348 AST nodes /
885 bytes. Different programs attain different coordinates. The direct
closed-update prototype in the prior report is larger, at 396 / 430 / 1168.
No new complete checker is entered against that envelope here.

BUILD AND REPRODUCE
-------------------
  python3 reproduce.py
  make pdf

Python 3.10+ is required for the included standard-library scripts. Exact
normalized metrics were produced under CPython 3.12.14. PDF rebuilding needs
pdflatex and the common TeX Live packages listed at the start of report.tex.
No network access is needed to reproduce the packaged evidence.

No changes have been pushed to GitHub.
