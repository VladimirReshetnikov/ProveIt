FROZEN COMPLETE-PROGRAM COMPARISON
=================================

Run: python3 comparison/measure.py from the package directory.

The twelve checkers are copied unchanged from the comparison payload of
ipra_closed_updates_2026-11-08(1).zip in the current pinned six-archive
ProveIt snapshot. They are historical comparators retained in current
reports, not twelve newly submitted live programs. The source normalizer
is inherited unchanged and its hash is pinned in manifest.json.

The complete source is counted, including imports, input/output, syntax and
scope validation, checking, exceptions, and rejection. Genuine docstrings
are stripped and ast.unparse normalization is applied. The new measurement
driver calls only the inherited metrics function; it never executes a
comparison checker. Its results are in results/measurements.json.

The prior closed-update prototype is separately retained and measured in
prototypes/. It is exploratory and is not included in the twelve-program
complete-comparison envelope. No new complete checker is submitted here.

Inherited sources are covered by ProveIt's MIT No Attribution license,
also preserved in references/closed_updates_v2/LICENSE.txt. Original source
comments remain intact. Historical attribution notices are retained when
present in the comparison source package.
