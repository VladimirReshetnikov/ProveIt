"""Reproduce sizes of twelve frozen complete comparison programs, without running them."""
import hashlib
import importlib.util
import json
from pathlib import Path
import platform

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def main():
    manifest = json.loads((HERE / 'manifest.json').read_text())
    normalizer = HERE / 'source_measure.py'
    if hashlib.sha256(normalizer.read_bytes()).hexdigest() != manifest['normalizer_sha256']:
        raise ValueError('The inherited normalizer has changed')
    spec = importlib.util.spec_from_file_location('inherited_measure', normalizer)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = []
    for entry in manifest['programs']:
        measured = module.metrics(HERE / entry['file'])
        if measured['sha256'] != entry['sha256']:
            raise ValueError('Frozen comparator changed: ' + entry['file'])
        rows.append({**entry, **measured})
    keys = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
    minima = {key: min(row[key] for row in rows) for key in keys}
    prototype = module.metrics(HERE / 'prototypes' / 'checker_closed_update_prototype.py')
    result = {
        'status': 'PASS', 'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'snapshot': manifest['current_snapshot'], 'program_count': len(rows),
        'scope': 'Twelve historical complete acceptance programs retained in current six reports',
        'whole_program': True, 'coordinatewise_minimum': minima,
        'attainers': {key: [row['file'] for row in rows if row[key] == minima[key]] for key in keys},
        'programs': rows, 'prior_exploratory_prototype': prototype,
        'new_complete_checker': None,
        'claim': 'NO_NEW_COMPLETE_CHECKER_SIZE_RECORD',
        'limits': 'Measurements do not prove correctness, absolute minimality, or a universal lower bound.'
    }
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results' / 'measurements.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('status', 'python', 'program_count',
                     'coordinatewise_minimum', 'claim')}, indent=2))


if __name__ == '__main__':
    main()
