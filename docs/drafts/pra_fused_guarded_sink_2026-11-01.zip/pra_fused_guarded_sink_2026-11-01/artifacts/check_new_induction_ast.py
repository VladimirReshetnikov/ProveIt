#!/usr/bin/env python3
"""Independent tree-occurrence counts, not a formal arithmetic proof.

No source-package code is imported or executed. Each recursive visit charges
one node, so shared Python objects still represent repeated tree occurrences.
Quantifier names and application labels are labels, not extra child nodes.
"""
import json
from pathlib import Path

def require(condition, message=None):
    if not condition:
        raise AssertionError(message or "Diagnostic check failed")



def t(label, *children):
    return (label, children)


def size(tree):
    return 1 + sum(size(child) for child in tree[1])


def close(names, matrix):
    for name in reversed(names):
        matrix = t("forall " + name, matrix)
    return matrix


z, n, a, x, y, bottom = map(t, ("0", "n", "a", "x", "y", "false"))
S = lambda term: t("S", term)
eq = lambda left, right: t("=", left, right)
OR = lambda left, right: t("or", left, right)
AND = lambda left, right: t("and", left, right)
IMP = lambda left, right: t("implies", left, right)
sep = IMP(eq(z, S(z)), bottom)
coverage = close(["x"], OR(eq(x, z), t("exists y", eq(x, S(y)))))


def compute(m):
    frozen_names = ["b" + str(i) for i in range(m - 1)]
    bs = [t(name) for name in frozen_names]
    R = lambda counter: t("R", counter, a, *bs)
    base = close(["a"] + frozen_names, eq(R(z), a))
    step = close(["n", "a"] + frozen_names,
                 eq(R(S(n)), t("h", n, *bs, R(n))))
    return size(base), size(step)


def schemas(q):
    names = ["c" + str(i) for i in range(q)]
    cs = [t(name) for name in names]
    A = lambda counter: t("A", counter, *cs)
    B = lambda counter: eq(t("s", counter, *cs), t("t", counter, *cs))
    D = lambda counter: OR(B(counter), eq(t("u", counter, *cs),
                                         t("v", counter, *cs)))

    def ordinary(matrix):
        return close(names, IMP(AND(matrix(z),
            close(["n"], IMP(matrix(n), matrix(S(n))))),
            close(["n"], matrix(n))))

    fused = close(names, IMP(AND(OR(A(z), eq(z, S(z))),
        close(["n"], IMP(A(n), A(S(n))))), close(["n"], A(n))))
    guard = lambda counter: OR(eq(counter, z), B(counter))
    guarded = close(names, IMP(
        close(["n"], IMP(guard(n), B(S(n)))), close(["n"], guard(n))))
    return {"qfi": size(ordinary(A)), "fused": size(fused),
            "atomic": size(ordinary(B)), "two_equation": size(ordinary(D)),
            "guarded_equation": size(guarded)}


require(size(sep) == 6 and size(coverage) == 10, None)
rows = []
for m in range(1, 9):
    r0, rs = compute(m)
    require((r0, rs) == (2*m + 4, 4*m + 8), None)
    for q in range(9):
        costs = schemas(q)
        require(costs == {"qfi": 5*q+14, "fused": 5*q+19,
                         "atomic": 9*q+27, "two_equation": 17*q+53,
                         "guarded_equation": 7*q+29}, None)
        totals = {
            "original_formula_qfi": r0+rs+size(sep)+costs["qfi"],
            "fused_formula_qfi": r0+rs+costs["fused"],
            "atomic_plus_coverage": r0+rs+size(sep)+size(coverage)+costs["atomic"],
            "guarded_equation": r0+rs+size(sep)+costs["guarded_equation"],
            "original_two_equation": r0+rs+size(sep)+costs["two_equation"],
        }
        require(totals["fused_formula_qfi"] == 6*m+5*q+31, None)
        require(totals["atomic_plus_coverage"] == 6*m+9*q+55, None)
        require(totals["guarded_equation"] == 6*m+7*q+47, None)
        require(totals["original_two_equation"] == 6*m+17*q+71, None)
        rows.append({"m": m, "q": q, "R0": r0, "RS": rs,
                     "schema_counts": costs, "totals": totals})

result = {
    "status": "passed",
    "scope": "Independent occurrence-tree display counting only; not a formal equivalence proof.",
    "separation": size(sep), "existential_coverage": size(coverage),
    "representative": next(row for row in rows if row["m"] == row["q"] == 1),
    "q0_m1": next(row for row in rows if row["m"] == 1 and row["q"] == 0),
    "rows_checked": len(rows),
    "rows": rows,
}
output = Path(__file__).with_name("new_induction_ast_audit.json")
output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: result[key] for key in
                 ("status", "scope", "representative", "q0_m1", "rows_checked")}, indent=2))
