#!/usr/bin/env python3
"""Small constant-domain Kripke diagnostics, supplementary to the proof."""
from functools import lru_cache
from itertools import product
import random,json,pathlib,time
from sink_pair_metrics import *

def ordinary_AST():
    P=lambda x:AND(neg(eq(x,'m')),neg(O(x)))
    return AND(FA('x',neg(E('m','x'))),FA('x',OR(eq('x','m'),O('x'),P('x'))),
      ALL(['x','y'],imp(AND(O('x'),O('y')),neg(E('x','y')))),
      FA('x',imp(P('x'),unique('a','a1',lambda a:AND(O(a),E(a,'x'))))),
      FA('x',imp(P('x'),unique('b','b1',lambda b:AND(O(b),E('x',b))))),
      ALL(['a','b'],imp(AND(O('a'),O('b')),unique('p','p1',lambda p:AND(P(p),E('a',p),E(p,'b'))))))

def evaluate(formulas,n,world_edges,future,m):
    @lru_cache(None)
    def ev(t,w,env):
        op=t[0];d=dict(env)
        if op=='var':return d[t[1]]
        if op=='false':return False
        if op=='E':return (d[t[1][1]],d[t[2][1]]) in world_edges[w]
        if op=='=':return d[t[1][1]]==d[t[2][1]]
        if op=='and':return ev(t[1],w,env) and ev(t[2],w,env)
        if op=='or':return ev(t[1],w,env) or ev(t[2],w,env)
        if op=='imp':return all(not ev(t[1],v,env) or ev(t[2],v,env) for v in future[w])
        if op=='exists':return any(ev(t[2],w,tuple(sorted({**d,t[1]:x}.items()))) for x in range(n))
        if op=='forall':return all(ev(t[2],v,tuple(sorted({**d,t[1]:x}.items()))) for v in future[w] for x in range(n))
        raise ValueError(op)
    return [ev(t,0,(('m',m),)) for t in formulas]

def main():
    start=time.monotonic();rng=random.Random(20261101)
    formulas=[ordinary_AST(),K(),prenexK(),J(),prenexJ()];tested=accepted=0
    frames=[('chain',{0:(0,1),1:(1,)},[(),(1,),(0,1)]),
            ('fork',{0:(0,1,2),1:(1,),2:(2,)},[(),(1,),(2,),(1,2),(0,1,2)])]
    counts={}
    for name,future,patterns in frames:
        cnt=0
        for n in [1,2,3]:
            edges=list(product(range(n),repeat=2))
            assignments=product(range(len(patterns)),repeat=len(edges)) if n<3 else (
                tuple(rng.randrange(len(patterns)) for _ in edges) for _ in range(1500))
            for assignment in assignments:
                WE={w:set() for w in future}
                for e,p in zip(edges,assignment):
                    for w in patterns[p]:WE[w].add(e)
                for m in range(n):
                    values=evaluate(formulas,n,WE,future,m)
                    if len(set(values))!=1:raise AssertionError((name,n,assignment,m,values))
                    tested+=1;cnt+=1;accepted+=int(values[0])
        # Nonvacuous structured models: all worlds satisfy the graph theory,
        # while pair-to-pair data remain genuinely undecided at the root.
        for n_objects,repetitions in [(1,len(patterns)),(2,100)]:
            rows=list(product(range(n_objects),repeat=4))
            for i in range(repetitions):
                assignment=[i] if n_objects==1 else [rng.randrange(len(patterns)) for _ in rows]
                labels=None;WE={}
                for w in future:
                    R={row for row,p in zip(rows,assignment) if w in patterns[p]}
                    V,EE=encode(range(n_objects),R)
                    if labels is None:labels={v:j for j,v in enumerate(sorted(V,key=repr))}
                    WE[w]={(labels[a],labels[b]) for a,b in EE}
                values=evaluate(formulas,len(labels),WE,future,labels[('marker',)])
                if not all(values):raise AssertionError((name,n_objects,assignment,values))
                tested+=1;cnt+=1;accepted+=1
        counts[name]=cnt
    out={'status':'PASS','constant_domain_Kripke_models_and_markers':tested,
      'per_frame':counts,'root_satisfying_cases':accepted,
      'formulas_compared':'ordinary six-clause sink structure; 93,92,91,90-node structures',
      'exhaustive_domains_1_and_2':True,'sampled_domain_3_assignments_per_frame':1500,
      'canonical_valid_models_with_persistent_pair_data':208,
      'all_relation_valuations_persistent':True,'not_a_completeness_or_formal_proof_certificate':True,
      'seconds':round(time.monotonic()-start,3)}
    out.pop('seconds',None)
    pathlib.Path(__file__).with_name('sink_kripke_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
