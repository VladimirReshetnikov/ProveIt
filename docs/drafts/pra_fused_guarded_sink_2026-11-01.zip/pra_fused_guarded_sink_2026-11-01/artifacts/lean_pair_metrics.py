#!/usr/bin/env python3
"""Expanded graph-structure AST ledger; not the arithmetic display ledger."""
from structural_metrics_round4 import *

def lean_decode():
    return SOME(['p','q'],AND(E('a','p'),E('p','b'),E('c','q'),E('q','d'),E('p','q')))

def coordinates(x):
    # Unique incoming and outgoing OBJECT coordinates. All syntax is charged.
    return SOME(['a','b'],AND(O('a'),O('b'),E('a',x),E(x,'b'),
        FA('c',OR(E('c','m'),AND(imp(E('c',x),eq('c','a')),
                                  imp(E(x,'c'),eq('c','b')))))))

def object_case(x):
    return AND(O(x),FA('y',OR(E('y','m'),AND(neg(E(x,'y')),
        unique('p','p1',lambda p:AND(E(x,p),E(p,'y')))))))

def lean_H():
    return FA('x',AND(E('m','x'),OR(eq('x','m'),object_case('x'),
                                      AND(E('x','m'),coordinates('x')))))

def H104():
    return FA('x',AND(E('m','x'),OR(eq('x','m'),object_case('x'),
       AND(E('x','m'),unique('a','a1',lambda a:AND(O(a),E(a,'x'))),
                       unique('b','b1',lambda b:AND(O(b),E('x',b)))))))

def H128():
    h=new_H()
    c=FA('p',OR(eq('p','m'),O('p'),AND(E('p','m'),
        unique('a','a1',lambda a:AND(O(a),E(a,'p'))),
        unique('b','b1',lambda b:AND(O(b),E('p',b))))))
    q=ALL(['a','b'],imp(AND(O('a'),O('b')),
        unique('p','p1',lambda p:AND(E('a',p),E(p,'b')))))
    return AND(h['universal_marker'],h['forbidden_object_edges'],c,q)

def sexpr(t):
    if t[0]=='var':return t[1]
    if t[0]=='false':return 'false'
    if t[0] in ['exists','forall']:return '('+t[0]+' '+t[1]+' '+sexpr(t[2])+')'
    return '('+t[0]+' '+' '.join(map(sexpr,t[1:]))+')'

if __name__=='__main__':
    old=new_H()
    out={'convention':'Variable occurrence, relation/equality, binary connective, falsity and quantifier each count one; negation and uniqueness fully expanded.',
        'round4_closed_structure':count(EX('m',AND(*old.values()))),
        'round4_without_two_object_clause':count(EX('m',AND(*(v for k,v in old.items() if k!='two_objects')))),
        'readable_round5_structure':count(EX('m',H128())),
        'intermediate_round5_structure':count(EX('m',H104())),
        'lean_round5_structure':count(EX('m',lean_H())),
        'lean_H_free_marker':count(lean_H()),
        'coordinate_formula':count(coordinates('x')),
        'object_branch':count(object_case('x')),
        'old_decoder':count(newdecode()),'lean_decoder':count(lean_decode()),
        'object_predicate_relative_to_marker':count(O('x')),
        'marker_formula_repeated_in_schema_antecedent':count(lean_H()),
        'needs_source_theorem_of_two_distinct_objects_for_marker_uniqueness':True,
        'finite_structure_only_not_full_infinite_theory_size':True,
        'not_a_claim_of_global_optimality':True}
    here=pathlib.Path(__file__).parent
    (here/'lean_pair_metrics.json').write_text(json.dumps(out,indent=2)+'\n')
    (here/'lean_structure_expanded.sexp').write_text(sexpr(EX('m',lean_H()))+'\n')
    (here/'lean_decoder_expanded.sexp').write_text(sexpr(lean_decode())+'\n')
    print(json.dumps(out,indent=2))
