#!/usr/bin/env python3
"""Finite diagnostics; these do not replace the intuitionistic derivations."""
import itertools,json,pathlib,random,time
from pair_incidence_round4 import encode,encode_two_coordinates,require
from lean_pair_metrics import H128,H104,lean_H

def old_H0(V,E,m):
    O={x for x in V if (x,m) not in E}; P={x for x in V if x!=m and (x,m) in E}
    return (all((m,x) in E for x in V)
        and all(x==m or x in O or x in P for x in V)
        and not any((a,b) in E for a in O for b in O)
        and all(sum((a,p) in E for a in O)==1 and sum((p,b) in E for b in O)==1 for p in P)
        and all(sum((a,p) in E and (p,b) in E for p in P)==1 for a in O for b in O))

def lean(V,E,m):
    O=lambda x:(x,m) not in E
    pair=lambda x,y:sum((x,p) in E and (p,y) in E for p in V)==1
    obj=lambda x:O(x) and all((y,m) in E or ((x,y) not in E and pair(x,y)) for y in V)
    coords=lambda x:any(O(a) and O(b) and (a,x) in E and (x,b) in E and
        all((c,m) in E or (((c,x) not in E or c==a) and ((x,c) not in E or c==b)) for c in V)
        for a in V for b in V)
    return all((m,x) in E and (x==m or obj(x) or ((x,m) in E and coords(x))) for x in V)

def ast_eval(t,V,E,env):
    op=t[0]
    if op=='var':return env[t[1]]
    if op=='false':return False
    if op=='E':return (ast_eval(t[1],V,E,env),ast_eval(t[2],V,E,env)) in E
    if op=='=':return ast_eval(t[1],V,E,env)==ast_eval(t[2],V,E,env)
    if op=='and':return ast_eval(t[1],V,E,env) and ast_eval(t[2],V,E,env)
    if op=='or':return ast_eval(t[1],V,E,env) or ast_eval(t[2],V,E,env)
    if op=='imp':return not ast_eval(t[1],V,E,env) or ast_eval(t[2],V,E,env)
    if op in ['forall','exists']:
        f=all if op=='forall' else any
        return f(ast_eval(t[2],V,E,{**env,t[1]:x}) for x in V)
    raise ValueError(op)

def roundtrip(V,E,m):
    require(lean(V,E,m)); O={x for x in V if (x,m) not in E};P=V-O-{m}
    coords={p:(next(a for a in O if (a,p) in E),next(b for b in O if (p,b) in E)) for p in P}
    # Lean decoder has no P tests. Its witnesses genuinely range over V.
    R={(a,b,c,d) for a,b,c,d in itertools.product(O,repeat=4)
       if any((a,p) in E and (p,b) in E and (c,q) in E and (q,d) in E and (p,q) in E for p in V for q in V)}
    VV,EE=encode(O,R)
    f={m:('marker',),**{a:('object',a) for a in O},**{p:('pair',*coords[p]) for p in P}}
    require(len(set(f.values()))==len(V) and set(f.values())==VV)
    require({(f[a],f[b]) for a,b in E}==EE)
    return R

def main():
    start=time.monotonic();tested=accepted=0
    # Exhaust every directed graph including loops, every candidate marker.
    for n in range(1,5):
        V=set(range(n));edges=list(itertools.product(range(n),repeat=2))
        for mask in range(1<<len(edges)):
            E={e for i,e in enumerate(edges) if mask>>i&1}
            for m in V:
                a,b=old_H0(V,E,m),lean(V,E,m)
                require(a==b);tested+=1;accepted+=int(b)
                # Cross-check executable direct semantics against the exact AST.
                if mask%503==0 or b:
                    require(all(ast_eval(t,V,E,{'m':m})==b for t in [H128(),H104(),lean_H()]))
    rows=list(itertools.product(range(2),repeat=4)); roundtrips=0
    # Every source relation on two objects, all 65,536 possible pair-edge tables.
    for mask in range(1<<len(rows)):
        R={r for i,r in enumerate(rows) if mask>>i&1};V,E=encode(range(2),R)
        require(old_H0(V,E,('marker',)) and lean(V,E,('marker',)))
        RR=roundtrip(V,E,('marker',));require({tuple(a[1] for a in r) for r in RR}==R)
        roundtrips+=1
    rng=random.Random(20261101);random_graphs=0
    for n in [5,6,7,8,9]:
        V=set(range(n)); edges=list(itertools.product(V,repeat=2))
        for _ in range(200):
            E={e for e in edges if rng.randrange(2)};m=rng.randrange(n)
            require(old_H0(V,E,m)==lean(V,E,m));random_graphs+=1
    # H0 does not itself imply marker uniqueness: the full source matters.
    V,E=encode([0],{(0,0,0,0)})
    universals={m for m in V if all((m,x) in E for x in V)}
    require(len(universals)==2)
    result={'status':'PASS','all_graph_marker_pairs_through_4_vertices':tested,
       'accepted_graph_marker_pairs':accepted,'all_relations_on_2_objects_both_roundtrips':roundtrips,
       'random_graph_marker_pairs_5_to_9_vertices':random_graphs,
       'exact_AST_semantics_cross_checked':True,
       'one_object_universal_marker_ambiguity_preserved_as_warning':True,
       'intuitionistic_equivalence_is_proved_in_TeX_not_by_these_classical_tests':True,
       'seconds':round(time.monotonic()-start,3)}
    pathlib.Path(__file__).with_name('lean_pair_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
