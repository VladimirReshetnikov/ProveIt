#!/usr/bin/env python3
"""Finite diagnostics of legal autonomous swap descriptions, NOT an internal proof."""
import json
from functools import lru_cache

def require(condition, message=None):
    if not condition:
        raise AssertionError(message or "Diagnostic check failed")


def swap(h):
    # Standard N well-founded recursion; code evaluates literal swap equations.
    @lru_cache(None)
    def r(x, a):
        if x == 0:
            return a
        return h(r(a, x - 1))
    return r

D = swap(lambda v: v)
delta_program = swap(lambda v: v + 1)
delta = lambda n: delta_program(n,n)
cycle5 = swap(lambda v: 0 if v == 4 else v + 1)
q5 = lambda n: cycle5(n,n)
skip4 = swap(lambda v: v + (2 if q5(v) == 1 else 1))
z = lambda n: skip4(n,n)
half = lambda n: D(delta(n),z(n))

N=150
checks = {
    'q5_standard': all(q5(n) == 2*n % 5 for n in range(N)),
    'z_standard': all(z(n) == 2*n+n//2 for n in range(N)),
    'halving_standard': all(half(n) == n//2 for n in range(N)),
    'even_tag_inverse': all(half(delta(n)) == n for n in range(N//2)),
    'odd_tag_inverse': all(half(delta(n)+1) == n for n in range(N//2)),
    'joint_D_cancel': all(D(a+1,b+1)==D(a,b) for a in range(30) for b in range(30)),
}
require(all(checks.values()), checks)
out = {'scope':'Standard N finite diagnostics only; no arbitrary-model or QFI claim',
       'range_exclusive':N, 'checks':checks,
       'first_values':[{'n':n,'q5':q5(n),'z':z(n),'half':half(n)} for n in range(12)]}
from pathlib import Path
Path(__file__).with_name('halving_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out, indent=2))
