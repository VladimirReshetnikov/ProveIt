#!/usr/bin/env python3
"""Independent finite diagnostics for the single-sink encoding."""
import itertools,json,pathlib,random,time
from pair_incidence_round4 import require
from lean_pair_check import ast_eval
from sink_pair_metrics import encode,K,prenexK,J,prenexJ

def ordinary(V,E,m):
    O={x for x in V if (x,m) in E};P={x for x in V if x!=m and (x,m) not in E}
    return (all((m,x) not in E for x in V)
        and all(x==m or x in O or x in P for x in V)
        and not any((a,b) in E for a in O for b in O)
        and all(sum((a,p) in E for a in O)==1 and sum((p,b) in E for b in O)==1 for p in P)
        and all(sum((a,p) in E and (p,b) in E for p in P)==1 for a in O for b in O))

def sink(V,E,m):
    O=lambda x:(x,m) in E
    q=lambda x,y:sum((x,p) in E and (p,y) in E for p in V)==1
    b=lambda x:O(x) and all(not O(y) or ((x,y) not in E and q(x,y)) for y in V)
    d=lambda x:any(O(a) and O(b) and (a,x) in E and (x,b) in E and
        all(not O(c) or (((c,x) not in E or c==a) and ((x,c) not in E or c==b)) for c in V)
        for a in V for b in V)
    return all((m,x) not in E and (x==m or b(x) or (not O(x) and d(x))) for x in V)

def roundtrip(V,E,m):
    require(sink(V,E,m));O={x for x in V if (x,m) in E};P=V-O-{m}
    require({v for v in V if all((v,w) not in E for w in V)}=={m})
    coords={p:(next(a for a in O if (a,p) in E),next(b for b in O if (p,b) in E)) for p in P}
    R={(a,b,c,d) for a,b,c,d in itertools.product(O,repeat=4)
       if any((a,p) in E and (p,b) in E and (c,q) in E and (q,d) in E and (p,q) in E for p in V for q in V)}
    VV,EE=encode(O,R)
    f={m:('marker',),**{a:('object',a) for a in O},**{p:('pair',*coords[p]) for p in P}}
    require(len(set(f.values()))==len(V) and set(f.values())==VV)
    require({(f[a],f[b]) for a,b in E}==EE)
    return R

def main():
    start=time.monotonic();tested=accepted=0
    for n in range(1,5):
        V=set(range(n));edges=list(itertools.product(V,repeat=2))
        for mask in range(1<<len(edges)):
            E={e for i,e in enumerate(edges) if mask>>i&1}
            for m in V:
                a,b=ordinary(V,E,m),sink(V,E,m)
                require(a==b);tested+=1;accepted+=int(b)
                if b:roundtrip(V,E,m)
                if mask%503==0 or b:
                    require(all(ast_eval(t,V,E,{'m':m})==b for t in [K(),prenexK(),J(),prenexJ()]))
    rows=list(itertools.product(range(2),repeat=4));roundtrips=0
    for mask in range(1<<len(rows)):
        R={r for i,r in enumerate(rows) if mask>>i&1};V,E=encode(range(2),R)
        require(ordinary(V,E,('marker',)) and sink(V,E,('marker',)))
        RR=roundtrip(V,E,('marker',));require({tuple(a[1] for a in r) for r in RR}==R)
        roundtrips+=1
    rng=random.Random(20261101);random_graphs=0
    for n in [5,6,7,8,9]:
        V=set(range(n));edges=list(itertools.product(V,repeat=2))
        for _ in range(200):
            E={e for e in edges if rng.randrange(2)};m=rng.randrange(n)
            require(ordinary(V,E,m)==sink(V,E,m));random_graphs+=1
    # Unlike the universal-marker variant, marker uniqueness needs no objects.
    for objects,R in [((),set()),((0,),set()),((0,),{(0,0,0,0)})]:
        V,E=encode(objects,R);roundtrip(V,E,('marker',))
    result={'status':'PASS','all_graph_marker_pairs_through_4_vertices':tested,
       'accepted_graph_marker_pairs':accepted,'all_relations_on_2_objects_both_roundtrips':roundtrips,
       'random_graph_marker_pairs_5_to_9_vertices':random_graphs,
       'exact_AST_semantics_cross_checked_93_92_91_90_node_versions':True,
       'unique_sink_also_checked_for_empty_and_one_object_sources':True,
       'intuitionistic_equivalence_is_proved_in_TeX_not_by_these_classical_tests':True,
       'seconds':round(time.monotonic()-start,3)}
    result.pop('seconds',None)
    pathlib.Path(__file__).with_name('sink_pair_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
