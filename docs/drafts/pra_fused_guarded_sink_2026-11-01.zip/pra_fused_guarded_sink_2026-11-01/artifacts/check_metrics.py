#!/usr/bin/env python3
"""Fresh independent AST arithmetic; does not import or execute source archives."""
import json
from pathlib import Path

def require(condition, message=None):
    if not condition:
        raise AssertionError(message or "Diagnostic check failed")


def node(label,*args): return (label,)+args
def var(label): return (label,)
def size(t): return 1+sum(map(size,t[1:]))
def all_(names,t):
    for n in reversed(names): t=node('forall '+n,t)
    return t
def exists(names,t):
    for n in reversed(names): t=node('exists '+n,t)
    return t
z=var('0'); n=var('n'); a=var('a'); x=var('x'); y=var('y')
S=lambda t: node('S',t)
eq=lambda u,v: node('=',u,v)
AND=lambda u,v: node('and',u,v)
OR=lambda u,v: node('or',u,v)
IMP=lambda u,v: node('implies',u,v)
bot=var('false')
SEP=IMP(eq(z,S(z)),bot)
COVER=all_(['x'],OR(eq(x,z),exists(['y'],eq(x,S(y)))))

def ind(q,kind):
    cs=[var('c'+str(i)) for i in range(q)]
    def A(t):
        if kind=='formula': return node('A',t,*cs)
        first=eq(node('s',t,*cs),node('t',t,*cs))
        if kind=='equation': return first
        return OR(first,eq(node('u',t,*cs),node('v',t,*cs)))
    return all_([c[0] for c in cs],IMP(AND(A(z),all_(['n'],IMP(A(n),A(S(n))))),all_(['n'],A(n))))

def guarded_ind(q):
    cs=[var('c'+str(i)) for i in range(q)]
    def B(t):return eq(node('s',t,*cs),node('t',t,*cs))
    guard=OR(eq(n,z),B(n))
    return all_([c[0] for c in cs],IMP(all_(['n'],IMP(guard,B(S(n)))),all_(['n'],guard)))

def computation(m,swap='ordinary'):
    bs=[var('b'+str(i)) for i in range(m-1)]
    R=lambda u,v:node('R',u,v,*bs)
    base=all_(['a']+[b[0] for b in bs],eq(R(z,a),a))
    inner=R(n,a) if swap=='ordinary' else R(a,n)
    update_args=([n,a] if swap=='full_swap' else [a] if swap=='seed_swap' else [n])+bs+[inner]
    step=all_(['n','a']+[b[0] for b in bs],eq(R(S(n),a),node('h',*update_args)))
    return base,step

def probe(q,fresh):
    cs=[var('c'+str(i)) for i in range(q)]
    f=lambda t:node('f',t,*cs)
    station=all_(['n'],eq(f(S(n)),f(n)))
    conclusion=all_(['n'],OR(eq(node('T',f(z),a),a),eq(f(n),a)))
    if fresh: return all_([c[0] for c in cs],IMP(station,all_(['a'],conclusion)))
    # old q includes the distinguished probe, use c0 as its identity
    if not cs: raise ValueError('Dependent convention needs q>=1')
    def replace(t):
        if t==a:return cs[0]
        return (t[0],)+tuple(replace(c) for c in t[1:])
    return all_([c[0] for c in cs],replace(IMP(station,conclusion)))

rows=[]
guarded_rows=[]
for m in range(1,8):
  base,step=computation(m)
  require(size(base)+size(step)==6*m+12, None)
  for q in range(0,8):
    I=ind(q,'equation'); T2=ind(q,'two_equations'); Q=ind(q,'formula')
    require(size(I)==9*q+27, None)
    require(size(T2)==17*q+53, None)
    require(size(Q)==5*q+14, None)
    total=size(base)+size(step)+size(SEP)+size(COVER)+size(I)
    old=size(base)+size(step)+size(SEP)+size(T2)
    require(total==6*m+9*q+55, None)
    require(old-total==8*q+16, None)
    guarded=size(base)+size(step)+size(SEP)+size(guarded_ind(q))
    require(size(guarded_ind(q))==7*q+29, None)
    require(guarded==6*m+7*q+47, None)
    require(old-guarded==10*q+24, None)
    guarded_rows.append(dict(m=m,q=q,schema=size(guarded_ind(q)),total=guarded,previous_two_equation=old,saving=old-guarded))
    rows.append(dict(m=m,q=q,computation=size(base)+size(step),sep=size(SEP),coverage=size(COVER),atomic_induction=size(I),new_total=total,two_equation_total=old,saving=old-total))
require(size(COVER)==10 and size(SEP)==6, None)
probe_rows=[]
for q in range(0,8):
    require(size(probe(q,True))==21+5*q, None)
    old=None if q==0 else size(probe(q,False))
    if q: require(old==20+5*q, None)
    probe_rows.append(dict(actual_f_parameters=q,fresh=size(probe(q,True)),old_dependent=old))
result=dict(guarded_rows=guarded_rows,guarded_representative=[r for r in guarded_rows if r['m']==r['q']==1][0],guarded_zero_parameter=[r for r in guarded_rows if r['m']==1 and r['q']==0][0],status='passed',scope='Exact independent formula-AST counts; not a proof of arithmetic equivalence',representative=[r for r in rows if r['m']==r['q']==1][0],rows=rows,probe_normalization=probe_rows,representative_trees=dict(atomic_induction=ind(1,'equation'),coverage=COVER))
p=Path(__file__).with_name('metrics.json');p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k in ['status','representative','guarded_representative','guarded_zero_parameter']},indent=2))
