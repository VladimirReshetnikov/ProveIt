"""Fresh AST counter. No inherited modules/code are imported or run."""
import json,pathlib

def require(condition, message=None):
    if not condition:
        raise AssertionError(message or "Diagnostic check failed")

# Bound variable names are labels, not extra nodes; each quantifier costs one.
def leaf(name):return (name,())
def op(name,*kids):return (name,kids)
def count(t):return 1+sum(count(x) for x in t[1])
def quant(names,t):
 for name in reversed(names): t=op('forall '+name,t)
 return t
zero=leaf('0');bot=leaf('false');n=leaf('n');a=leaf('a')
S=lambda t:op('S',t)
eq=lambda l,r:op('=',l,r)
def compute(p,full):
 bs=[leaf('b'+str(i)) for i in range(p)];bn=[str(i) for i in range(p)]
 R=lambda x,y:op('R',x,y,*bs)
 base=quant(['a']+bn,eq(R(zero,a),a))
 args=[n]+([a] if full else [])+bs+[R(a,n)]
 step=quant(['n','a']+bn,eq(R(S(n),a),op('h',*args)))
 return count(base),count(step)
def schema(q,inline,fresh):
 cs=[leaf('c'+str(i)) for i in range(q)];cn=[str(i) for i in range(q)]
 f=lambda x:op('f',x,*([] if fresh else [a]),*cs)
 stat=quant(['n'],eq(f(S(n)),f(n)))
 left=op('C',op('D',a,f(zero)),f(zero),a) if inline else op('T',f(zero),a)
 right=S(f(n)) if inline else f(n)
 conclusion=quant((['a'] if fresh else [])+['n'],op('or',eq(left,a),eq(right,a)))
 return count(quant(([] if fresh else ['a'])+cn,op('implies',stat,conclusion)))
sep=count(op('implies',eq(zero,S(zero)),bot));require(sep==6, None)
rows=[]
for p in range(4):
 for q in range(4):
  b,s=compute(p,False);require((b,s)==(2*p+6,4*p+12), None)
  fi=schema(q,True,True);oi=schema(q,True,False);fn=schema(q,False,True);on=schema(q,False,False)
  require((fi,oi,fn,on)==(6*q+26,6*q+31,5*q+21,5*q+25), None)
  _,fs=compute(p,True);require(fs==4*p+13, None)
  fresh_inline=b+s+sep+fi+2;fresh_named=b+fs+sep+fn+8
  require(fresh_inline==52+6*p+6*q and fresh_named==54+6*p+5*q, None)
  rows.append({'update_frozen_arity_p':p,'term_frozen_arity_q':q,'one_index_base':b,'one_index_step':s,'separation':sep,'fresh_inline_schema':fi,'old_inline_schema_same_extra_params':oi,'fresh_named_schema':fn,'old_named_schema_same_extra_params':on,'fresh_inline_display':fresh_inline-2,'fresh_inline_subtotal':fresh_inline,'fresh_named_subtotal':fresh_named})
# Same actual f-arity comparison: old designated probe is one of the q inputs.
for q in range(1,5):
 require(schema(q,True,True)==schema(q-1,True,False)+1, None)
 require(schema(q,False,True)==schema(q-1,False,False)+1, None)
result={'status':'PASS','definition_p':'number of frozen update parameters','definition_q':'number of frozen parameters of f, independent of probe in fresh form','rows':rows,'fresh_inline_formula':'52+6p+6q','fresh_named_formula':'54+6p+5q','difference':'q-2','interface_saving_inline':5,'interface_saving_named':4,'same_actual_f_arity':'fresh adds one universally quantified probe; it is one node longer than old template with one of these parameters designated as probe','scope':'Partial display+selected-body ledger only; no complete theory encoding or instancewise saving claimed.'}
pathlib.Path(__file__).with_name('independent_arity_ledger.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2));print(json.dumps([r for r in rows if r['update_frozen_arity_p']==r['term_frozen_arity_q']],indent=2))
