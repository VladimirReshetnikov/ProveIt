#!/usr/bin/env python3
"""Fully expanded first-order AST ledger, distinct from PRA display-node ledger.
Quantifier contributes one node (bound name is a label); every variable
occurrence, relation/equality, binary connective, and falsity contributes one.
Negation=A->bottom; iff=(A->B)&(B->A); exists! is expanded.
No abbreviation definitions are left as free nodes.
"""
from functools import reduce
import json,pathlib
V=lambda x:('var',x)
BOT=('false',)
def E(x,y):return ('E',V(x),V(y))
def eq(x,y):return ('=',V(x),V(y))
def imp(a,b):return ('imp',a,b)
def neg(a):return imp(a,BOT)
def AND(*xs):return reduce(lambda a,b:('and',a,b),xs)
def OR(*xs):return reduce(lambda a,b:('or',a,b),xs)
def iff(a,b):return AND(imp(a,b),imp(b,a))
def FA(x,f):return ('forall',x,f)
def EX(x,f):return ('exists',x,f)
def ALL(vs,f):return reduce(lambda f,x:FA(x,f),reversed(vs),f)
def SOME(vs,f):return reduce(lambda f,x:EX(x,f),reversed(vs),f)
def unique(x,y,f):return EX(x,AND(f(x),FA(y,imp(f(y),eq(y,x)))))
def count(t):
 if t[0] in ['var','false']:return 1
 if t[0] in ['forall','exists']:return 1+count(t[2])
 return 1+sum(map(count,t[1:]))

def oldsort(i,x):return AND(neg(E(x,x)),E(x,f'm{i}'))
def oldI(i,t,o,v):return EX(v,AND(oldsort(i+2,v),E(t,v),E(v,o)))
def olddecode():return EX('t',AND(oldsort(1,'t'),*(oldI(i,'t',f'x{i}',f'v{i}') for i in range(4))))

def old_H():
 out={}
 out['distinct_markers']=AND(*(neg(eq(f'm{i}',f'm{j}')) for i in range(6) for j in range(i+1,6)))
 out['loop_enumeration']=FA('x',iff(E('x','x'),OR(*(eq('x',f'm{i}') for i in range(6)))))
 # The source's E(mi,mj) iff truth/falsity is read, as specified, as the
 # equivalent finite positive/negative literal list (generous to old theory).
 out['marker_order']=AND(*(E(f'm{i}',f'm{j}') if i<=j else neg(E(f'm{i}',f'm{j}')) for i in range(6) for j in range(6)))
 out['nonempty']=EX('x',oldsort(0,'x'))
 out['classification']=FA('x',OR(*(eq('x',f'm{i}') for i in range(6)),*(oldsort(i,'x') for i in range(6))))
 out['sort_disjointness']=AND(*(FA('x',neg(AND(oldsort(i,'x'),oldsort(j,'x')))) for i in range(6) for j in range(i+1,6)))
 rhs=OR(*(AND(eq('x',f'm{i}'),eq('y',f'm{j}')) for i in range(6) for j in range(i,6)),
   *(AND(oldsort(i,'x'),eq('y',f'm{i}')) for i in range(6)),
   AND(oldsort(1,'x'),OR(*(oldsort(i+2,'y') for i in range(4))),E('x','y')),
   AND(OR(*(oldsort(i+2,'x') for i in range(4))),oldsort(0,'y'),E('x','y')))
 out['edge_shape']=ALL(['x','y'],iff(E('x','y'),rhs))
 incidence=[]
 for i in range(4):
  incidence += [FA('t',imp(oldsort(1,'t'),unique('v','v1',lambda v:AND(oldsort(i+2,v),E('t',v))))),
   FA('v',imp(oldsort(i+2,'v'),unique('t','t1',lambda t:AND(oldsort(1,t),E(t,'v'))))),
   FA('v',imp(oldsort(i+2,'v'),unique('o','o1',lambda o:AND(oldsort(0,o),E('v',o)))))]
 out['incidence']=AND(*incidence)
 ext=AND(oldsort(1,'t'),oldsort(1,'t1'),*(EX(f'o{i}',AND(oldI(i,'t',f'o{i}',f'v{i}'),oldI(i,'t1',f'o{i}',f'v1{i}'))) for i in range(4)))
 out['tuple_extensionality']=ALL(['t','t1'],imp(ext,eq('t','t1')))
 return out

def O(x):return neg(E(x,'m'))
def P(x):return AND(neg(eq(x,'m')),E(x,'m'))
def newdecode():return SOME(['p','q'],AND(P('p'),P('q'),E('x0','p'),E('p','x1'),E('x2','q'),E('q','x3'),E('p','q')))
def new_H():
 out={}
 out['universal_marker']=FA('x',E('m','x'))
 out['two_objects']=SOME(['a','b'],AND(O('a'),O('b'),neg(eq('a','b'))))
 out['classification']=FA('x',OR(eq('x','m'),O('x'),P('x')))
 out['forbidden_object_edges']=ALL(['x','y'],imp(AND(O('x'),O('y')),neg(E('x','y'))))
 pairs=[FA('b',imp(P('b'),unique('x','x1',lambda x:AND(O(x),E(x,'b'))))),
   FA('b',imp(P('b'),unique('y','y1',lambda y:AND(O(y),E('b',y))))),
   ALL(['x','y'],imp(AND(O('x'),O('y')),unique('b','b1',lambda b:AND(P(b),E('x',b),E(b,'y')))))]
 out['pair_axioms']=AND(*pairs)
 return out

def main():
 old,new=old_H(),new_H()
 result={'convention':__doc__,'old_H_parts':{k:count(v) for k,v in old.items()},
   'new_H_parts':{k:count(v) for k,v in new.items()},
   'old_closed_structural_axiom':count(SOME([f'm{i}' for i in range(6)],AND(*old.values()))),
   'new_closed_structural_axiom':count(EX('m',AND(*new.values()))),
   'old_fully_expanded_relation_decoder':count(olddecode()),
   'new_fully_expanded_relation_decoder':count(newdecode()),
   'old_object_domain_predicate':count(oldsort(0,'x')),
   'new_object_domain_predicate':count(O('x')),
   'not_the_PRA_49_or_50_node_display_convention':True}
 print(json.dumps(result,indent=2));pathlib.Path(__file__).with_name('structural_metrics.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
