#!/usr/bin/env python3
"""Finite diagnostics for new atomic bootstrap; not an infinite-model proof."""
import json
from pathlib import Path

def require(condition, message=None):
    if not condition:
        raise AssertionError(message or "Diagnostic check failed")

N=100
checks={'separate_invariants':0,'reflection':0,'boolean_range':0,'cancellation':0}
for x in range(N+1):
    m=w=0
    for j in range(N+1):
        r=max(x-j,0)
        require(x==r+m, None)
        require(j==w+m, None)
        checks['separate_invariants']+=2
        if r==0:w+=1
        else:m+=1
    for y in range(N+1):
        dxy=max(x-y,0);dyx=max(y-x,0)
        require((dxy==dyx==0)==(x==y), None)
        checks['reflection']+=1
        e=0 if dxy+dyx==0 else 1
        require(e in (0,1) and ((e==0)==(x==y)), None)
        checks['boolean_range']+=1
        require(max((x+y)-x,0)==y, None)
        checks['cancellation']+=1
out=dict(status='passed',bound=N,checks=checks,total=sum(checks.values()),scope='Finite arithmetic diagnostics only; written proof handles arbitrary models and both logics.')
Path(__file__).with_name('bootstrap_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
