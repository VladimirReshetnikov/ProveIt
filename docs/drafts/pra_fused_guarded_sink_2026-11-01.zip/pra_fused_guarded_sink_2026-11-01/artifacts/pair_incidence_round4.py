#!/usr/bin/env python3
"""Independent finite diagnostics for single-copy pair incidence.
Not a proof-assistant certificate. The decoder does not inspect vertex tags.
"""
from itertools import product
import json, random, pathlib, time

def require(condition):
    if not condition:
        raise AssertionError("Graph diagnostic condition failed")

def encode(objects, relation):
    objects=tuple(objects); M=('marker',)
    O={a:('object',a) for a in objects}
    P={(a,b):('pair',a,b) for a,b in product(objects,repeat=2)}
    V={M}|set(O.values())|set(P.values())
    E={(M,v) for v in V}|{(p,M) for p in P.values()}
    for (a,b),p in P.items():E|={(O[a],p),(p,O[b])}
    E|={(P[a,b],P[c,d]) for a,b,c,d in relation}
    return V,E

def encode_two_coordinates(n,relation):
    M=(0,0);O={a:(0,a+1) for a in range(n)}
    P={(a,b):(a+1,b+1) for a,b in product(range(n),repeat=2)}
    V={M}|set(O.values())|set(P.values())
    E={(M,v) for v in V}|{(p,M) for p in P.values()}
    for (a,b),p in P.items():E|={(O[a],p),(p,O[b])}
    E|={(P[a,b],P[c,d]) for a,b,c,d in relation}
    return V,E

def decode(V,E):
    require(all(a in V and b in V for a,b in E))
    universal={m for m in V if all((m,x) in E for x in V)}
    require(len(universal)==1)
    m,=universal
    O={x for x in V if (x,m) not in E}
    P={x for x in V-{m} if (x,m) in E}
    require(len(O)>=2 and O|P|{m}==V and not O&P)
    require(not any((x,y) in E for x in O for y in O))
    coord={};inv={}
    for p in P:
        first={a for a in O if (a,p) in E};require(len(first)==1)
        second={a for a in O if (p,a) in E};require(len(second)==1)
        ab=(next(iter(first)),next(iter(second)))
        require(ab not in inv)
        coord[p]=ab;inv[ab]=p
    require(set(inv)==set(product(O,repeat=2)))
    allowed={(m,v) for v in V}|{(p,m) for p in P}
    allowed|={(o,p) for o in O for p in P if (o,p) in E}
    allowed|={(p,o) for o in O for p in P if (p,o) in E}
    allowed|={(p,q) for p in P for q in P if (p,q) in E}
    require(E==allowed)
    R={(*coord[p],*coord[q]) for p in P for q in P if (p,q) in E}
    VV,EE=encode(O,R)
    F={m:('marker',)}
    F.update({o:('object',o) for o in O})
    F.update({p:('pair',*coord[p]) for p in P})
    require(set(F)==V and len(set(F.values()))==len(V) and set(F.values())==VV)
    require({(F[a],F[b]) for a,b in E}==EE)
    return O,R

def rename(V,E,rng):
    labels=list(range(len(V)));rng.shuffle(labels)
    f=dict(zip(sorted(V,key=repr),labels))
    return set(f.values()),{(f[a],f[b]) for a,b in E},f

def main():
    started=time.monotonic();count=renamed=two_dimensional=0;rng=random.Random(20261101)
    n=2;rows=list(product(range(n),repeat=4))
    for mask in range(1<<len(rows)):
        R={r for i,r in enumerate(rows) if mask>>i&1}
        V,E=encode(range(n),R);O,RR=decode(V,E)
        require({tuple(o[1] for o in r) for r in RR}==R)
        require(len(V)==1+n+n*n)
        V2,E2=encode_two_coordinates(n,R);O2,R2=decode(V2,E2)
        require({tuple(o[1]-1 for o in r) for r in R2}==R)
        require(len(V2)==len(V))
        two_dimensional+=1
        if mask%257==0:
            VV,EE,f=rename(V,E,rng);OO,RRR=decode(VV,EE)
            require(RRR=={tuple(f[('object',a)] for a in r) for r in R})
            renamed+=1
        count+=1
    random_cases=0
    for n in [3,4,7]:
        rows=list(product(range(n),repeat=4))
        for _ in range(20):
            R={r for r in rows if rng.randrange(4)==0}
            V,E=encode(range(n),R);VV,EE,f=rename(V,E,rng)
            O,RR=decode(VV,EE)
            require(RR=={tuple(f[('object',a)] for a in r) for r in R})
            random_cases+=1
    V,E=encode(range(2),{(0,1,1,0)})
    M=('marker',);o0=('object',0);o1=('object',1);p=('pair',0,1)
    bads={
      'extra_object_loop':(V,E|{(o0,o0)}),
      'missing_first_coordinate':(V,E-{(o0,p)}),
      'missing_second_coordinate':(V,E-{(p,o1)}),
      'extra_first_coordinate':(V,E|{(o1,p)}),
      'forbidden_object_object_edge':(V,E|{(o0,o1)}),
      'missing_pair_vertex':(V-{p},{(a,b) for a,b in E if a!=p and b!=p}),
      'missing_marker_universal_edge':(V,E-{(M,o0)}),
      'object_to_marker_edge':(V,E|{(o0,M)}),
      'pair_missing_marker_edge':(V,E-{(p,M)}),
      'one_object_allows_ambiguous_universal_marker':encode([0],{(0,0,0,0)}),
    }
    accepted=[];rejected=[]
    for name,(VV,EE) in bads.items():
        try:decode(VV,EE);accepted.append(name)
        except AssertionError:rejected.append(name)
    require(not accepted)
    V1,E1=encode([0],{(0,0,0,0)})
    require(len({m for m in V1 if all((m,x) in E1 for x in V1)})==2)
    result={'status':'PASS','exhaustive_relations_on_2_objects':count,
      'two_dimensional_successor_encodings_checked':two_dimensional,
      'additional_renamed_graphs':renamed,'larger_random_renamed_graphs':random_cases,
      'negative_controls_rejected':rejected,'both_roundtrips_checked':True,
      'one_object_counterexample_has_two_universal_vertices':True,
      'pair_loops_are_allowed_and_preserved':True,
      'checks_are_finite_diagnostics_not_formal_derivations':True,
      }
    pathlib.Path(__file__).with_name('pair_incidence_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
