#!/usr/bin/env python3
"""Independent audit: no imports or execution of inherited/generated project code.
Parse the emitted S-expression; compare to a separately transcribed TeX formula;
count AST nodes; exhaust classical 90-node semantics vs six-clause specification.
This is a diagnostic, not an intuitionistic proof certificate.
"""
import json,re,pathlib,time,itertools,collections

def require(condition, message=None):
    if not condition:
        raise AssertionError(message or "Diagnostic check failed")

HERE=pathlib.Path(__file__).resolve().parent
SRC=HERE/'sink_structure_expanded.sexp'

def parse(s):
    toks=iter(re.findall(r'\(|\)|[^\s()]+',s))
    def one(t):
        if t!='(':return t
        a=[]
        while (t:=next(toks))!=')':a.append(one(t))
        return tuple(a)
    out=one(next(toks));require(next(toks,None) is None, None);return out

def nodes(t):
    if isinstance(t,str):return 1
    if t[0] in ('forall','exists'):return 1+nodes(t[2])
    return 1+sum(map(nodes,t[1:]))
def vars_free(t,bound=frozenset()):
    if isinstance(t,str):return set() if t=='false' or t in bound else {t}
    if t[0] in ('forall','exists'):return vars_free(t[2],bound|{t[1]})
    return set().union(*(vars_free(x,bound) for x in t[1:]))
def E(a,b):return ('E',a,b)
def eq(a,b):return ('=',a,b)
def no(t):return ('imp',t,'false')
def imp(a,b):return ('imp',a,b)
def chain(op,*args):
    z=args[0]
    for a in args[1:]:z=(op,z,a)
    return z
A=lambda *a:chain('and',*a)
V=lambda *a:chain('or',*a)
def all_(x,p):return ('forall',x,p)
def some(x,p):return ('exists',x,p)
def uniq(x,y,F):return some(x,A(F(x),all_(y,imp(F(y),eq(y,x)))))
O=lambda x:E(x,'m')
Q=lambda x,y:uniq('p','p1',lambda p:A(E(x,p),E(p,y)))
obj=lambda x,y:imp(O(y),A(no(E(x,y)),Q(x,y)))
coord=lambda x,a,b,y:imp(O(y),A(imp(E(y,x),eq(y,a)),imp(E(x,y),eq(y,b))))
g=lambda x,a,b,y:A(O(a),O(b),E(a,x),E(x,b),coord(x,a,b,y))
D=lambda x:some('a',some('b',A(O('a'),O('b'),E('a',x),E(x,'b'),all_('y',coord(x,'a','b','y')))))
expected=some('m',all_('x',some('a',some('b',all_('y',A(no(E('m','x')),imp(O('x'),obj('x','y')),V(eq('x','m'),O('x'),g('x','a','b','y'))))))))
readable=some('m',all_('x',A(no(E('m','x')),imp(O('x'),all_('y',obj('x','y'))),V(eq('x','m'),O('x'),D('x')))))
decoder=some('p',some('q',A(E('a','p'),E('p','b'),E('c','q'),E('q','d'),E('p','q'))))
oldO=lambda x:no(E(x,'m'))
oldP=lambda x:A(no(eq(x,'m')),E(x,'m'))
oldclauses=[all_('x',E('m','x')),some('a',some('b',A(oldO('a'),oldO('b'),no(eq('a','b'))))),all_('x',V(eq('x','m'),oldO('x'),oldP('x'))),all_('x',all_('y',imp(A(oldO('x'),oldO('y')),no(E('x','y'))))),all_('p',imp(oldP('p'),uniq('a','a1',lambda a:A(oldO(a),E(a,'p'))))),all_('p',imp(oldP('p'),uniq('b','b1',lambda b:A(oldO(b),E('p',b))))),all_('a',all_('b',imp(A(oldO('a'),oldO('b')),uniq('p','p1',lambda p:A(oldP(p),E('a',p),E(p,'b'))))))]
old=some('m',A(*oldclauses))
olddec=some('p',some('q',A(oldP('p'),oldP('q'),E('a','p'),E('p','b'),E('c','q'),E('q','d'),E('p','q'))))

def compiled(t):
    if t=='false':return lambda e,edge,n:False
    op=t[0]
    if op=='E':
        a,b=t[1:];return lambda e,edge,n:bool(edge & (1 << (e[a]*n+e[b])))
    if op=='=':
        a,b=t[1:];return lambda e,edge,n:e[a]==e[b]
    if op in ('and','or','imp'):
        a,b=compiled(t[1]),compiled(t[2])
        if op=='and':return lambda e,edge,n:a(e,edge,n) and b(e,edge,n)
        if op=='or':return lambda e,edge,n:a(e,edge,n) or b(e,edge,n)
        return lambda e,edge,n:not a(e,edge,n) or b(e,edge,n)
    name=t[1];body=compiled(t[2]);want=op=='exists'
    def quant(e,edge,n):
        prior=e.get(name,None)
        for x in range(n):
            e[name]=x
            if body(e,edge,n)==want:
                if prior is None:e.pop(name)
                else:e[name]=prior
                return want
        if prior is None:e.pop(name)
        else:e[name]=prior
        return not want
    return quant

def conventional(mask,n,m):
    edge=lambda x,y:bool(mask & (1<<(x*n+y)))
    if any(edge(m,x) for x in range(n)):return False
    objects=[x for x in range(n) if edge(x,m)]
    pairs=[x for x in range(n) if x!=m and not edge(x,m)]
    if any(edge(a,b) for a in objects for b in objects):return False
    if any(sum(edge(a,p) for a in objects)!=1 or sum(edge(p,b) for b in objects)!=1 for p in pairs):return False
    return all(sum(edge(a,p) and edge(p,b) for p in pairs)==1 for a in objects for b in objects)

def main():
    start=time.monotonic();tree=parse(SRC.read_text());require(tree==expected, None);require(vars_free(tree)==set(), None)
    counts={'new_structure':nodes(tree),'new_readable':nodes(readable),'new_decoder':nodes(decoder),'old_structure':nodes(old),'old_decoder':nodes(olddec),'Q':nodes(Q('x','y')),'A':nodes(obj('x','y')),'F':nodes(coord('x','a','b','y')),'G':nodes(g('x','a','b','y')),'old_structural_clause_parts':list(map(nodes,oldclauses))}
    require([counts[k] for k in ('new_structure','new_readable','new_decoder','old_structure','old_decoder')]==[90,91,21,196,41], None)
    formula=compiled(tree[2]);tested=accepted=0
    for n in range(1,5):
        for mask in range(1<<(n*n)):
            for m in range(n):
                a=conventional(mask,n,m);b=formula({'m':m},mask,n)
                require(a==b, (n,mask,m,a,b))
                tested+=1;accepted+=int(a)
                if a:
                    sinks=[x for x in range(n) if not any(mask & (1<<(x*n+y)) for y in range(n))]
                    require(sinks==[m], None)
        print('Exhausted n =',n,'cumulative =',tested,flush=True)
    out={'status':'PASS','no_project_code_imported_or_executed':True,'emitted_AST_matches_independent_TeX_transcription':True,'free_variables':[], 'counts':counts,'exhaustive_exact_90_AST_vs_conventional_graph_marker_pairs':tested,'accepted':accepted,'unique_sink_checked_on_all_accepted':True,'seconds':round(time.monotonic()-start,3),'scope':'Classical finite diagnostic plus independent AST check; the written constructive proof is audited separately.'}
    out.pop('seconds',None)
    (HERE/'independent_sink_audit_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
