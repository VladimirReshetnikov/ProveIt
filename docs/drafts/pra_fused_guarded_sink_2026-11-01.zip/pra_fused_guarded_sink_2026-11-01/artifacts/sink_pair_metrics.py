#!/usr/bin/env python3
"""Single-sink variant: atomic object domain and unconditional unique marker."""
from structural_metrics_round4 import *

def O(x):return E(x,'m')
def Q(x,y):return unique('p','p1',lambda p:AND(E(x,p),E(p,y)))
def Bbody(x,y):return imp(O(y),AND(neg(E(x,y)),Q(x,y)))
def Dbody(x,a,b,c):return imp(O(c),AND(imp(E(c,x),eq(c,a)),imp(E(x,c),eq(c,b))))
def B(x):return AND(O(x),FA('y',Bbody(x,'y')))
def D(x):return SOME(['a','b'],AND(O('a'),O('b'),E('a',x),E(x,'b'),FA('c',Dbody(x,'a','b','c'))))
def K():return FA('x',AND(neg(E('m','x')),OR(eq('x','m'),B('x'),AND(neg(O('x')),D('x')))))
def prenexK():
    return FA('x',SOME(['a','b'],FA('y',AND(neg(E('m','x')),OR(eq('x','m'),
        AND(O('x'),Bbody('x','y')),
        AND(neg(O('x')),O('a'),O('b'),E('a','x'),E('x','b'),Dbody('x','a','b','y')))))))
def J():
    return FA('x',AND(neg(E('m','x')),imp(O('x'),FA('y',Bbody('x','y'))),
        OR(eq('x','m'),O('x'),D('x'))))
def prenexJ():
    return FA('x',SOME(['a','b'],FA('y',AND(neg(E('m','x')),
        imp(O('x'),Bbody('x','y')),
        OR(eq('x','m'),O('x'),AND(O('a'),O('b'),E('a','x'),E('x','b'),Dbody('x','a','b','y')))))))
def decoder():return SOME(['p','q'],AND(E('a','p'),E('p','b'),E('c','q'),E('q','d'),E('p','q')))

def encode(objects,relation):
    from itertools import product
    objects=tuple(objects);m=('marker',)
    oo={a:('object',a) for a in objects}; pp={(a,b):('pair',a,b) for a,b in product(objects,repeat=2)}
    V={m}|set(oo.values())|set(pp.values())
    EE={(o,m) for o in oo.values()}
    for (a,b),p in pp.items():EE|={(oo[a],p),(p,oo[b])}
    EE|={(pp[a,b],pp[c,d]) for a,b,c,d in relation}
    return V,EE

if __name__=='__main__':
    from lean_pair_metrics import sexpr
    here=pathlib.Path(__file__).parent
    out={'convention':'Same fully expanded first-order AST ledger as lean_pair_metrics.py',
        'sink_structure_factored_readable':count(EX('m',J())),
        'sink_structure_factored_prenex':count(EX('m',prenexJ())),
        'sink_structure_readable':count(EX('m',K())),
        'sink_structure_prenex_factored':count(EX('m',prenexK())),
        'object_branch':count(B('x')),'coordinate_branch':count(D('x')),
        'decoder':count(decoder()),'object_predicate':count(O('x')),
        'marker_uniqueness_from_structure_alone':True,
        'source_scheme_sink_antecedent':count(FA('y',neg(E('m','y')))),
        'decoder_contains_no_marker_parameter':True,
        'parameterfree_object_formula_via_unique_sink':count(EX('m',AND(FA('y',neg(E('m','y'))),O('x')))),
        'source_nonempty_needed_for_object_interpretation_not_marker_uniqueness':True}
    (here/'sink_pair_metrics.json').write_text(json.dumps(out,indent=2)+'\n')
    (here/'sink_structure_expanded.sexp').write_text(sexpr(EX('m',prenexJ()))+'\n')
    print(json.dumps(out,indent=2))
