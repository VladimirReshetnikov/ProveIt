Simpler Induction and Relational Bases for PRA
Prepared for Vladimir Reshetnikov, 1 November 2026.

Reviewed commit: bd7c1189f8d75f1cf738c156d8c376158de16460.
Inventory pin: 3fba4b511ccf102160c21b19a0f3c6429a239231.
The six draft archives have identical Git blob hashes at both commits.

RECOMMENDATIONS
1. For a short unrestricted formula schema, use initialized ordinary
   recursion and the fused induction schema. The declared representative
   display decreases from 43 to 42. This is a logical packing improvement.
2. For restricted term induction, use the guarded single-equation schema.
   It recovers full QFI constructively and reduces the committed expanded
   two-equation presentation from 94 to 60 nodes at m=q=1.
3. For one binary relation, the sink encoding reduces structural overhead
   from 196 to 90 and the relation decoder from 41 to 21.
These are DIFFERENT metrics/classes; they do not form one global ranking.
All positive PRA equivalences are matching-logic bi-interpretations, with
both internal round trips. The graph application explicitly inherits its
quaternary source theorem. No absolute minimum or full formal certificate.

Also included: fresh-inline normalization with subtotal 52 under its own
representative convention and an exact warning about actual term arity;
proved partial value-only constructions with the internal completeness
problem explicitly left open. No value-only PRA equivalence is claimed.

FILES
report.pdf: 18-page report.
report.tex and included sections: complete editable manuscript.
axioms.txt: the two new ordinary-recursion arithmetic specifications.
artifacts/: independent AST counters, arithmetic diagnostics, exact graph
AST, exhaustive and Kripke diagnostics, and standard-model halving checks.
references/: unchanged source TeX and the prior full one-index package.
source_manifest.json: pinned input archive/member provenance.
VALIDATION.txt: performed checks and their boundaries.
SHA256SUMS: release payload hashes.

REPRODUCTION
Requires Python 3 and a normal TeX Live installation:
  sh build.sh
All scripts are standard-library Python. Checks remain active under -O.
The graph AST checker independently exhausts the exact 90-node formula;
other graph/AST variants have the precisely described sampling scopes.
The value-only numerical check is not an internal arbitrary-model proof.

The retained previous ZIP is a reference, not a build input. No downloaded
repository scripts or inherited proof-assistant logs were executed.
