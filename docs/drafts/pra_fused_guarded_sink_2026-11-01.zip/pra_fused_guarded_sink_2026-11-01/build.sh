#!/bin/sh
set -eu
cd "$(dirname "$0")"
for script in check_new_induction_ast check_metrics check_bootstrap independent_arity_ledger sink_pair_metrics independent_sink_audit sink_pair_check sink_kripke_check check_halving; do
  python3 "artifacts/$script.py"
done
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
