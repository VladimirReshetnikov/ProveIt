A THREE-SCHEMA NUMERICAL BASIS FOR iPRA
Prepared for Vladimir Reshetnikov, 9 November 2026 (Pacific date)

RESULT
------
The new 0,G,J presentation has S(x):=G(0,x) and exactly three
numerical computation schemas:
    G(Sa,b)=a
    J(0;u.h)=0
    J(Sn;u.h)=h[J(n;u.h)/u]

It replaces the four numerical schemas in the supplied finite-gate
0,G,J draft with three. A computation-only predecessor and selector
lead to arbitrary initialized iteration through a single equation
invariant. The complete report gives all ordinary and native rules,
an internal arithmetic completion, and both whole-domain interpretation
composites with full first-order intuitionistic PRA.

The matched whole-checker comparison improves:
    1529 tokens / 1772 AST nodes / 5620 normalized bytes
to  1442 tokens / 1674 AST nodes / 5323 normalized bytes.
Only the G recognizer changes in the matched executable sources.
The four-schema comparator was newly implemented for this comparison;
its mathematical theory is inherited from the pinned source draft.

THE NEW G/J CONSTRUCTION DOES NOT BEAT THE ENTIRE COMPACT-CHECKER FRONTIER.
The included existing leaders attain coordinate minima 295/334/801.
The scalar initialized-iterator basis already has two computation
schemas. No absolute simplestness or global minimization breakthrough
is claimed. The user's requested strict global improvement remains
unestablished. The local mathematical and matched implementation
reductions are the new arithmetic results.

A separate consolidation of inherited implementation techniques in
compact_controls/ lowers the individual coordinate minima to 292/330/795.
Three different programs attain those coordinates; no one supplied
program beats all three old minima. These programs implement the inherited
initialized-scalar Choice-DI calculus, NOT the new G/J presentation.
They improve every measurement of their respective original profiles.
Exact diffs, the preservation argument, full triples, fixtures, and
replay evidence are included. No new logical rule is claimed there.

OPEN FIRST
----------
ipra_three_schema_2026-11-09.pdf  Complete report.
ipra_three_schema_2026-11-09.tex  Standalone editable LaTeX source.
report.tex and sections/          Modular source.
code/checker.py                   Complete new native checker.
code/checker_four_schema.py       Matched old-theory checker.
code/FORMAT.txt                   Exact public syntax and rules.
code/arithmetic.py                Untrusted term compiler/evaluator.
tests/                           Actual proof packets and executable checks.
comparison/                      Frozen current leaders and normalizer.
compact_controls/                Smaller composed inherited checkers.
evidence/                        Measurements, provenance, review, receipts.
CLAIMS.json                       Explicit claim boundaries.
MANIFEST.json                     Hashes and lengths of all payload files.

REPRODUCE
---------
    python3 reproduce.py
    python3 build.py
    python3 package.py

The first command needs only Python's standard library. The normalizer
was measured under CPython 3.12.14; other versions may unparse differently.
Building the report needs pdfLaTeX with the ordinary packages named in
report.tex. The build disables shell escape and requires no network.
Packaging verifies every CRC and payload hash. Temporary build files and
Python caches are excluded. Exact rebuilt PDF bytes may vary by TeX version.

CHECK ONE CERTIFICATE
---------------------
The JSON file tests/certificates.json is an inventory of cases. Each
case's packet field is a standalone checker input. For example:

    python3 -c 'import json; print(json.dumps(json.load(open("tests/certificates.json"))["cases"][0]["packet"]))' | python3 code/checker.py

The checker imports no producer or arithmetic evaluator. Its goal must
be closed; witnesses, eigenparameters, and bound indices are checked.

VERIFICATION SCOPE
------------------
The finite tests and two independent assistant reviews support the
written proofs. They do not constitute a Lean/Rocq formalization or
external human peer review. Full bi-interpretability concerns all
elements of models, not just the finite standard examples tested.

SOURCE SNAPSHOT
---------------
VladimirReshetnikov/ProveIt, commit
6c902762efcb1e78a5dd25db745310bab74f47a5, docs/drafts.
All 14 top-level archives were downloaded and checked by Git blob hash
and byte length. Their direct extracted Python files contain 351
distinct source hashes. The original archives are not duplicated here.
No source-repository write was performed.
