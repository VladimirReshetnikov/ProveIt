COMPOSING THE EXISTING CHOICE-DI IMPLEMENTATION REDUCTIONS

Scope of this companion
-----------------------
These three complete standalone programs check the inherited initialized-
scalar Choice-DI calculus. They do NOT implement the new three-schema G/J
presentation. Their improvement must not be assigned to the G/J checker.
No new axiom, inference rule, or arithmetic bootstrap is claimed here.

The programs combine two existing ingredients: the deferred local-assumption
selection in kernel_and_initializer and the shorter public driver/import
choices already present in countdown_retraction. This consolidation gives
a smaller observed coordinate envelope than the current 14-archive snapshot.
Different complete programs attain its different coordinates:

                         tokens    AST nodes    normalized bytes
old tokens profile          295          341                 866
composed tokens profile     292          336                 865
old structure profile       300          334                 893
composed structure profile  296          330                 882
old byte profile            303          349                 801
composed byte profile       300          346                 795

old coordinate envelope     295          334                 801
composed envelope           292          330                 795

No one supplied program is below all three old coordinate minima. The
word envelope means independently attained coordinates, not a single
program with that vector. These observed sizes are upper bounds on what
can be implemented, not mathematical lower bounds.

Inheritance and provenance
--------------------------
The pinned repository commit is
6c902762efcb1e78a5dd25db745310bab74f47a5.
The unchanged comparator files are ../comparison/old_tokens.py,
../comparison/old_structure.py and ../comparison/old_bytes.py. Their
provenance is recorded by the containing report. Exact complete-source
diffs are tokens.diff, structure.diff and bytes.diff.

The same inherited source_measure.py normalizer counts each entire
standalone program, including the standard JSON import, syntax opening,
proof logic, input parser call, rejection, successful output and exit
behavior. It removes comments and genuine docstrings only, normalizes
with ast.unparse, and counts significant tokens, AST nodes and UTF-8
bytes. The Python and JSON runtimes are common uncounted infrastructure.
metrics.json records complete source hashes and the normalizer results.

All 351 distinct Python source contents in the current snapshot were
checked for raw-byte identity and for identity after this normalization.
None of these three exact composed programs occurred in that inventory.
That is a provenance statement about program identities; their constituent
ideas are inherited and are not being claimed as novel.

Exact public interface
----------------------
Each file reads one JSON array from standard input. Its last cell is the
closed goal. Earlier two-field packets are consumed from the end;
hypothesis closure consumes no packet, and an unread prefix is inert.
Success prints ACCEPT followed by a newline and exits zero. Rejection
prints REJECT followed by a newline and re-raises the exception, exiting
nonzero (one in the recorded CLI tests). As in the unchanged comparators,
a traceback may appear on stderr. Traceback text and line numbers are not
claimed identical. Both ordinary and python -O execution are supported.

INHERITED_FORMAT.txt is an unchanged copy of the inherited Choice-DI
specification for the exact Eq/Q/D and initialized-iterator raw decoding;
its historical paths and validation counts refer to that earlier package.
The inherited_choice_basis.tex and inherited_ordinary_bridge.tex source
extracts are also copied unchanged for their logical rule inventory.
The current deferred-selection changes are explained below. These programs change no constructor,
certificate field, formula meaning or arithmetic computation schema.

Why deferred selection preserves the checker
--------------------------------------------
Every truthy major must still pass 1/c(m,g). A failed major is never
allowed to fall through to introduction. Equality transport and Q
elimination return before the common eigenparameter continuation.
There are consequently just two paths to that continuation:

1. Paired elimination: m is truthy, and the local object h is a unary
   closure. The previous image is k, and the composed conditional also
   selects k. The condition short-circuits on m, without inspecting the
   conclusion's matrix arity.

2. Paired introduction: m is falsy, h is the opened matrix B, and the
   selected image is k exactly when len(B)%2 == m, otherwise zero.
   This is precisely the old Choice-DI selection. A compound formula
   never receives an induction assumption. Numeric zero/False selects
   progress for literal equations; [] and other nonnumeric falsy mode
   values select cases, exactly as in the original decoder.

For tokens.py and bytes.py, the old code stored a Boolean s and used k*s
after allocation. The new conditional k if m or len(B)%2==m else 0 has
exactly the same value. The default selector argument and the separate
introduction assignment have therefore been deleted. The remaining
equality/Q endpoint variables are assigned on their own returning paths.

For structure.py, the old code opened a case matrix with zero before
allocation, then normalized that already closed result after allocation.
The new code retains the original matrix and performs that zero opening
once after allocation. This requires an opening lemma, not just source
counting. The initial witness-opening validates every meaningful free
negative coordinate against the old freshness floor. Its result cannot
contain the next fresh label. Thus reducing the floor by one cannot
change which old numerical leaves are exposed. Opening with zero is
therefore independent of the allocation order. Its result is closed at
the root; opening it again with the new eigenparameter leaves it fixed.
The progress choice and paired elimination are unchanged. Invalid scalar
matrices may fail at different moments, but both versions reject.

The tokens profile additionally replaces import json / json.load by
from json import load / load, referring to the same standard-library
function. The decoder and traversal guards are unchanged within each
matched profile. No proof generator, encoded checker, arithmetic oracle,
or external theorem database is imported.

Induction on a successful finite checking trace now gives the same
accepted conclusion, final freshness floor and remaining packets. The
consequence relation and the inherited native-to-iPRA interpretations
are unchanged. Physical resource cutoffs can differ; the equivalence
statement uses the customary sufficient-finite-resources model.

Verification and replay
-----------------------
cases.json preserves all 147 inherited certificates and 21 focused cases
from kernel_and_initializer. The focused cases include failed truthy
numeric majors, failed majors before valid computation, captured counters,
false-base case introductions, malformed syntax and all permitted falsy
mode aliases. Their provenance is the pinned archive's
code/validation/converted_inherited_certificates.json and
code/validation/focused_certificates.json.

The recorded validation covers 1,008 in-process fixture checks, 12,096
old/new deterministic subtree-mutation comparison pairs and 2,016 fresh
CLI executions across all six programs in normal and optimized Python.
All passed. On accepted inputs, the comparison also requires equal final
freshness floors and equal remaining packet data. Failed internal states
are not required to be equal. Finite checks support the implementation
argument; they do not prove the full arithmetic interpretation theorem.

From the containing report directory, run:
    python3 compact_controls/replay.py
When this companion is elsewhere, pass the comparison directory explicitly:
    python3 replay.py /absolute/path/to/comparison

The modest implementation consolidation is independent of the report's
new three-schema arithmetic reduction. Neither result is an absolute
minimality theorem or a large new logical-kernel reduction.
