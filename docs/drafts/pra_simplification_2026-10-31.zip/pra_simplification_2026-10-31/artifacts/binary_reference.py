#!/usr/bin/env python3
"""Executable reference for the binary PRA descriptions.

Only zero, successor, variables, and calls to earlier binary descriptions
occur in the admitted term AST. A new description has base context (a,)
and step context (n, previous_value, a). There is no ternary primitive,
native multiplication instruction, primitive comparison, or parameter-changing
recursive call in the object language.

The checks below are finite computations, not proofs of the paper's theorems.
Python arithmetic appears in the evaluator and in independent test oracles.
Run with Python 3.10 or later; no third-party packages are needed.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import sys
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple = ()


ZERO = Term("zero")


def var(i):
    return Term("var", (i,))


def succ(t):
    return Term("succ", (t,))


ONE = succ(ZERO)


def call(name, x, a):
    return Term("call", (name, x, a))


def pred(x):
    return call("P", x, ZERO)


def gate(x, y):
    return call("gate", x, y)


def add(x, y):
    return call("add", x, y)


def alpha(x, y):
    """Orientation: alpha(x,y) has standard value max(y-x,0)."""
    return call("alpha", x, y)


def select(x, u, v):
    """An expanded binary term, not an extra ternary function symbol."""
    return add(gate(x, u), gate(gate(x, ONE), v))


def error(x, y):
    return select(alpha(x, y), alpha(y, x), ONE)


def triangular(x):
    return call("T", x, ZERO)


def rank(x):
    return call("q", x, ZERO)


def pair(x, y):
    return add(triangular(add(x, y)), y)


def right(z):
    return alpha(triangular(rank(z)), z)


def left(z):
    return alpha(right(z), rank(z))


def tuple_code(items):
    result = ZERO
    for item in reversed(tuple(items)):
        result = pair(item, result)
    return result


def tuple_projection(z, index):
    """Zero-based index; a finite syntactic composition, not recursion."""
    for _ in range(index):
        z = right(z)
    return left(z)


def substitute(t, replacements):
    if t.tag == "zero":
        return t
    if t.tag == "var":
        return replacements[t.args[0]]
    if t.tag == "succ":
        return succ(substitute(t.args[0], replacements))
    name, x, a = t.args
    return call(name, substitute(x, replacements), substitute(a, replacements))


def validate_term(t, context_size, earlier):
    """Check syntax and context; descriptor declarations call this first."""
    if not isinstance(t, Term):
        raise ValueError("not a term")
    if t.tag == "zero" and not t.args:
        return
    if t.tag == "var" and len(t.args) == 1:
        i = t.args[0]
        if type(i) is not int or not 0 <= i < context_size:
            raise ValueError(f"variable {i} outside context of size {context_size}")
        return
    if t.tag == "succ" and len(t.args) == 1:
        validate_term(t.args[0], context_size, earlier)
        return
    if t.tag == "call" and len(t.args) == 3:
        name, x, a = t.args
        if name not in earlier:
            raise ValueError(f"call to non-earlier symbol {name}")
        validate_term(x, context_size, earlier)
        validate_term(a, context_size, earlier)
        return
    raise ValueError("malformed term constructor")


def show(t):
    if t.tag == "zero":
        return "0"
    if t.tag == "var":
        return f"v{t.args[0]}"
    if t.tag == "succ":
        return f"S({show(t.args[0])})"
    name, x, a = t.args
    return f"{name}({show(x)},{show(a)})"


@dataclass(frozen=True)
class Descriptor:
    name: str
    base: Term
    step: Term


class BinaryMachine:
    def __init__(self):
        self.descriptions = {}

    def declare(self, name, base, step):
        if name in self.descriptions:
            raise ValueError("description names must be fresh")
        validate_term(base, 1, self.descriptions)
        validate_term(step, 3, self.descriptions)
        self.descriptions[name] = Descriptor(name, base, step)

    @lru_cache(maxsize=None)
    def evaluate(self, t, env):
        if t.tag == "zero":
            return 0
        if t.tag == "var":
            return env[t.args[0]]
        if t.tag == "succ":
            return self.evaluate(t.args[0], env) + 1
        name, x, a = t.args
        return self.apply(name, self.evaluate(x, env), self.evaluate(a, env))

    @lru_cache(maxsize=None)
    def apply(self, name, n, a):
        if type(n) is not int or type(a) is not int or n < 0 or a < 0:
            raise ValueError("standard semantics requires natural numbers")
        d = self.descriptions[name]
        result = self.evaluate(d.base, (a,))
        for k in range(n):
            result = self.evaluate(d.step, (k, result, a))
        return result

    def check_guarded_instance(self, s, t):
        """The G1 context has only n,a, even when a term ignores one."""
        validate_term(s, 2, self.descriptions)
        validate_term(t, 2, self.descriptions)


def build_machine():
    machine = BinaryMachine()
    n, r, a = var(0), var(1), var(2)
    machine.declare("P", ZERO, n)
    machine.declare("gate", var(0), ZERO)
    machine.declare("add", var(0), succ(r))
    machine.declare("alpha", var(0), pred(r))
    machine.declare("T", ZERO, add(r, succ(n)))
    machine.declare("q", ZERO,
                    select(error(succ(n), triangular(succ(r))), succ(r), r))
    return machine


@dataclass(frozen=True)
class Formula:
    tag: str
    args: tuple = ()


def atom(s, t):
    return Formula("equal", (s, t))


def compile_formula(A):
    if A.tag == "equal":
        return error(*A.args)
    if A.tag == "true":
        return ZERO
    if A.tag == "false":
        return ONE
    x = compile_formula(A.args[0])
    if A.tag == "not":
        return select(x, ONE, ZERO)
    y = compile_formula(A.args[1])
    if A.tag == "and":
        return select(x, y, ONE)
    if A.tag == "or":
        return select(x, ZERO, y)
    if A.tag == "implies":
        return select(x, y, ZERO)
    raise ValueError("unknown formula constructor")


def truth(machine, A, env):
    """Independent finite Boolean semantics, not an intuitionistic proof."""
    if A.tag == "equal":
        return machine.evaluate(A.args[0], env) == machine.evaluate(A.args[1], env)
    if A.tag == "true":
        return True
    if A.tag == "false":
        return False
    x = truth(machine, A.args[0], env)
    if A.tag == "not":
        return not x
    y = truth(machine, A.args[1], env)
    if A.tag == "and":
        return x and y
    if A.tag == "or":
        return x or y
    if A.tag == "implies":
        return (not x) or y
    raise ValueError("unknown formula constructor")


def run_checks():
    machine = build_machine()
    counts = {}

    def check(group, condition):
        if not condition:
            raise AssertionError(f"failed check in {group}")
        counts[group] = counts.get(group, 0) + 1

    n, a = var(0), var(1)
    induction_pairs = [
        (add(n, ZERO), n),
        (alpha(succ(n), succ(a)), alpha(n, a)),
        (alpha(n, n), ZERO),
        (alpha(n, succ(n)), ONE),
        (select(alpha(a, n), alpha(alpha(n, a), a), n), n),
    ]
    for s, t in induction_pairs:
        machine.check_guarded_instance(s, t)
        check("one_parameter_schema_checks", True)
    for bad in (var(2), call("undeclared", n, a)):
        try:
            machine.check_guarded_instance(bad, ZERO)
        except ValueError:
            check("rejected_invalid_schema_terms", True)
        else:
            raise AssertionError("invalid schema term accepted")
    for base, step in ((var(1), ZERO), (ZERO, var(3)),
                       (ZERO, call("self", n, a))):
        try:
            machine.declare("self", base, step)
        except ValueError:
            check("rejected_invalid_descriptions", True)
        else:
            raise AssertionError("invalid description accepted")

    for x, y in itertools.product(range(13), repeat=2):
        env = (x, y)
        check("predecessor", machine.apply("P", x, y) == max(x - 1, 0))
        check("binary_gate", machine.apply("gate", x, y) == (y if x == 0 else 0))
        check("addition", machine.apply("add", x, y) == x + y)
        check("monus", machine.apply("alpha", x, y) == max(y - x, 0))
        check("equality_detector", (machine.evaluate(error(n, a), env) == 0) ==
              (x == y))
        check("shift_identity", machine.evaluate(alpha(succ(n), succ(a)), env) ==
              machine.evaluate(alpha(n, a), env))
        check("reconstruction_invariant", machine.evaluate(induction_pairs[-1][0],
                                                            env) == x)
    for x in range(21):
        check("diagonal", machine.apply("alpha", x, x) == 0)
        check("adjacent_diagonal", machine.apply("alpha", x, x + 1) == 1)
    for x, u, v in itertools.product(range(5), range(6), range(6)):
        check("expanded_selector", machine.evaluate(select(var(0), var(1), var(2)),
                                                     (x, u, v)) ==
              (u if x == 0 else v))

    A, B = atom(n, ZERO), atom(a, ZERO)
    formulas = [Formula("true"), Formula("false"), A, B,
                Formula("not", (A,)), Formula("and", (A, B)),
                Formula("or", (A, B)), Formula("implies", (A, B)),
                Formula("implies", (Formula("or", (A, B)), A))]
    truth_rows = []
    for formula in formulas:
        code = compile_formula(formula)
        validate_term(code, 2, machine.descriptions)
        for env in itertools.product(range(4), repeat=2):
            observed = machine.evaluate(code, env) == 0
            expected = truth(machine, formula, env)
            check("formula_compiler", observed == expected)
            if max(env) <= 1:
                truth_rows.append({"formula": formula.tag, "inputs": list(env),
                                   "truth": expected, "compiled_zero": observed})

    for k in range(31):
        check("triangular_numbers", machine.apply("T", k, 0) == k * (k + 1) // 2)
    for x in range(201):
        qx = machine.apply("q", x, 0)
        check("rank_independent_oracle", qx == (math.isqrt(8 * x + 1) - 1) // 2)
        successor = machine.apply("q", x + 1, 0)
        expected = qx + 1 if x + 1 == (qx + 1) * (qx + 2) // 2 else qx
        check("rank_recurrence", successor == expected)
    for x, y in itertools.product(range(9), repeat=2):
        packed = machine.evaluate(pair(n, a), (x, y))
        check("cantor_pair_formula", packed == (x + y) * (x + y + 1) // 2 + y)
        check("left_retraction", machine.evaluate(left(n), (packed,)) == x)
        check("right_retraction", machine.evaluate(right(n), (packed,)) == y)
    largest_tuple_code = 0
    for length in range(4):
        context = tuple(var(i) for i in range(length))
        code = tuple_code(context)
        validate_term(code, length, machine.descriptions)
        for values in itertools.product(range(3), repeat=length):
            packed = machine.evaluate(code, values)
            largest_tuple_code = max(largest_tuple_code, packed)
            for j, value in enumerate(values):
                check("finite_tuple_retractions",
                      machine.evaluate(tuple_projection(n, j), (packed,)) == value)

    # A concrete ternary source recursion f(0,u,v)=u;
    # f(Sn,u,v)=f(n,u,v)+v, translated with the specialized pair code J(u,v).
    # Its binary descriptor uses only c in the base and n,r,c in the step.
    machine.declare("F", left(var(0)), add(var(1), right(var(2))))
    translated = call("F", var(0), pair(var(1), var(2)))
    validate_term(translated, 3, machine.descriptions)
    for x, u, v in itertools.product(range(6), range(5), range(5)):
        observed = machine.evaluate(translated, (x, u, v))
        check("ternary_to_binary_translation", observed == u + x * v)
        packed = machine.evaluate(pair(n, a), (u, v))
        check("translated_recursion_equation",
              machine.apply("F", x + 1, packed) == observed + v)

    # Composition/substitution: the same translation with an actual parameter
    # term substituted for its code has exactly the expected standard value.
    binary_term = call("F", n, a)
    composed = substitute(binary_term, (var(0), pair(var(1), var(2))))
    check("term_substitution", composed == translated)

    descriptions = [{"name": d.name, "arity": 2,
                     "base_context": ["a"], "base": show(d.base),
                     "step_context": ["n", "r", "a"], "step": show(d.step)}
                    for d in machine.descriptions.values()]
    return {
        "status": "all finite checks passed",
        "scope": "Finite standard-model computations and syntax checks; not proofs.",
        "python_version": sys.version.split()[0],
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "core_helper_count": 6,
        "core_helpers": ["P", "gate", "add", "alpha", "T", "q"],
        "demonstration_description": "F",
        "description_grammar": "All calls binary; base context size 1; step size 3; "
                               "only earlier descriptions may be called.",
        "guarded_schema_context": ["n", "a"],
        "description_context_indexing": "v0=a in bases; v0=n,v1=r,v2=a in steps",
        "counts": counts,
        "total_checks": sum(counts.values()),
        "largest_tested_tuple_code": largest_tuple_code,
        "ternary_translation": {
            "source_base": "f(0,u,v)=u",
            "source_step": "f(Sn,u,v)=f(n,u,v)+v",
            "binary_base": "F(0,c)=L(c)",
            "binary_step": "F(Sn,c)=F(n,c)+R(c)",
            "translation": "f(n,u,v) becomes F(n,J(u,v))",
            "standard_oracle": "u+n*v; multiplication used only by test oracle",
        },
        "descriptions": descriptions,
        "connective_truth_rows": truth_rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("binary_verification.json"))
    args = parser.parse_args()
    report = run_checks()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"],
                      "total_checks": report["total_checks"],
                      "report": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
