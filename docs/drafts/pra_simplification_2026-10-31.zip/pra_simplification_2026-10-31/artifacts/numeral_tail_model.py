#!/usr/bin/env python3
"""Execute finite examples from the duplicated-tail countermodel for PRA.

For K >= 0 the model has elements (n, 0), n >= 0, and (n, 1), n > K.
Successor preserves the tag.  Every primitive-recursion description is
interpreted normally on the canonical chain.  Its value at the extra root
(K+1, 1) is the canonical copy of its standard numerical value, and its
values above that root follow its own recursion equation.

The description language is staged: base and step terms may reference only
earlier declarations.  Base contexts are (a_0, ..., a_(k-1)); step contexts
are (n, recursive_result, a_0, ..., a_(k-1)).  Variables implement projections
and nested terms implement composition.

This Python interpreter is an external evaluator of finite descriptions.
It is not claimed to be a primitive-recursive universal numerical evaluator.
Finite checks exercise this implementation; the paper proves the assertions
about every description and every induction instance.

Run with Python 3.10 or later, using only its standard library:
    python3 numeral_tail_model.py
    python3 numeral_tail_model.py --output numeral_tail_verification.json
"""

from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import asdict, dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Variable:
    index: int


@dataclass(frozen=True)
class Successor:
    argument: Term


@dataclass(frozen=True)
class Application:
    name: str
    arguments: tuple[Term, ...]


Term = Zero | Variable | Successor | Application
ZERO = Zero()


def variable(index: int) -> Variable:
    return Variable(index)


def successor(term: Term) -> Successor:
    return Successor(term)


def call(name: str, *arguments: Term) -> Application:
    return Application(name, arguments)


@dataclass(frozen=True)
class Recursion:
    name: str
    parameter_count: int
    base: Term
    step: Term


class Program:
    """A finite initial segment of the PR-description language."""

    def __init__(self) -> None:
        self.declarations: dict[str, Recursion] = {}

    def validate(self, term: Term, context_size: int) -> None:
        if isinstance(term, Zero):
            return
        if isinstance(term, Variable):
            if not 0 <= term.index < context_size:
                raise ValueError("Variable is outside its displayed context")
            return
        if isinstance(term, Successor):
            self.validate(term.argument, context_size)
            return
        if isinstance(term, Application):
            if term.name not in self.declarations:
                raise ValueError("A declaration may use only earlier function symbols")
            declaration = self.declarations[term.name]
            if len(term.arguments) != declaration.parameter_count + 1:
                raise ValueError("Function application has the wrong arity")
            for argument in term.arguments:
                self.validate(argument, context_size)
            return
        raise TypeError("Unknown term constructor")

    def add_recursion(
        self, name: str, parameter_count: int, base: Term, step: Term
    ) -> None:
        if not name or name in self.declarations or parameter_count < 0:
            raise ValueError("A declaration requires a fresh name and nonnegative arity")
        self.validate(base, parameter_count)
        self.validate(step, parameter_count + 2)
        self.declarations[name] = Recursion(name, parameter_count, base, step)

    @lru_cache(maxsize=None)
    def evaluate(self, term: Term, environment: tuple[int, ...]) -> int:
        if isinstance(term, Zero):
            return 0
        if isinstance(term, Variable):
            return environment[term.index]
        if isinstance(term, Successor):
            return self.evaluate(term.argument, environment) + 1
        if isinstance(term, Application):
            values = tuple(self.evaluate(arg, environment) for arg in term.arguments)
            return self.apply(term.name, values[0], values[1:])
        raise TypeError("Unknown term constructor")

    @lru_cache(maxsize=None)
    def apply(self, name: str, number: int, parameters: tuple[int, ...]) -> int:
        declaration = self.declarations[name]
        if len(parameters) != declaration.parameter_count:
            raise ValueError("Wrong parameter count")
        if number < 0 or any(parameter < 0 for parameter in parameters):
            raise ValueError("Numerical arguments must be natural numbers")
        value = self.evaluate(declaration.base, parameters)
        for predecessor in range(number):
            value = self.evaluate(declaration.step, (predecessor, value, *parameters))
        return value


@dataclass(frozen=True)
class Element:
    number: int
    tag: int = 0

    def successor(self) -> Element:
        return Element(self.number + 1, self.tag)


class TailModel:
    def __init__(self, program: Program, cutoff: int) -> None:
        if cutoff < 0:
            raise ValueError("K must be nonnegative")
        self.program = program
        self.cutoff = cutoff
        self.root = Element(cutoff + 1, 1)

    def validate_element(self, element: Element) -> None:
        if element.number < 0 or element.tag not in (0, 1):
            raise ValueError("Invalid model element")
        if element.tag == 1 and element.number <= self.cutoff:
            raise ValueError("The extra chain starts at K+1")

    @lru_cache(maxsize=None)
    def evaluate(self, term: Term, environment: tuple[Element, ...]) -> Element:
        if isinstance(term, Zero):
            return Element(0)
        if isinstance(term, Variable):
            return environment[term.index]
        if isinstance(term, Successor):
            return self.evaluate(term.argument, environment).successor()
        if isinstance(term, Application):
            values = tuple(self.evaluate(arg, environment) for arg in term.arguments)
            return self.apply(term.name, values[0], values[1:])
        raise TypeError("Unknown term constructor")

    @lru_cache(maxsize=None)
    def apply(
        self, name: str, argument: Element, parameters: tuple[Element, ...]
    ) -> Element:
        declaration = self.program.declarations[name]
        if len(parameters) != declaration.parameter_count:
            raise ValueError("Wrong parameter count")
        for element in (argument, *parameters):
            self.validate_element(element)

        if argument.tag == 0:
            value = self.evaluate(declaration.base, parameters)
            first_step = 0
        else:
            # This is the essential model choice at the extra root.  It uses
            # the standard interpretation of THIS complete recursion symbol.
            value = Element(
                self.program.apply(
                    name,
                    self.cutoff + 1,
                    tuple(parameter.number for parameter in parameters),
                )
            )
            first_step = self.cutoff + 1

        for predecessor in range(first_step, argument.number):
            environment = (Element(predecessor, argument.tag), value, *parameters)
            value = self.evaluate(declaration.step, environment)
        self.validate_element(value)
        return value


def example_program() -> Program:
    program = Program()
    # p(0)=0; p(Sn)=n.
    program.add_recursion("p", 0, ZERO, variable(0))
    # c(0,u,v)=u; c(Sn,u,v)=v.
    program.add_recursion("c", 2, variable(0), variable(3))
    # r is a description of numerical identity, kept distinct from a variable.
    program.add_recursion("r", 0, ZERO, successor(variable(1)))
    # z is the numerical zero test, with 1 meaning zero.
    program.add_recursion("z", 0, successor(ZERO), ZERO)
    # mu(n,a)=a dotminus n numerically: iterate predecessor n times.
    program.add_recursion("mu", 1, variable(0), call("p", variable(1)))
    # add(n,a)=n+a, with recursion on n.
    program.add_recursion("add", 1, variable(0), successor(variable(1)))
    return program


def syntax_checks() -> int:
    """Check the three distinct admission constraints used by the examples."""
    rejected = 0
    attempts = (
        ("bad_variable", 0, variable(0), ZERO),
        ("bad_recursion", 0, ZERO, call("bad_recursion", variable(0))),
        ("bad_arity", 0, ZERO, call("p", variable(0), variable(1))),
    )
    for declaration in attempts:
        program = example_program()
        try:
            program.add_recursion(*declaration)
        except ValueError:
            rejected += 1
        else:
            raise AssertionError("An inadmissible declaration was accepted")
    return rejected


def finite_checks(cutoff: int, bound: int = 6) -> dict[str, object]:
    program = example_program()
    model = TailModel(program, cutoff)
    elements = tuple(
        Element(number, tag)
        for number in range(bound + 1)
        for tag in (0, 1)
        if tag == 0 or number > cutoff
    )
    counts = {
        "recursion_base": 0,
        "recursion_step": 0,
        "function_projection": 0,
        "term_projection": 0,
        "fixed_numeral_reflection": 0,
    }

    for name, declaration in program.declarations.items():
        for parameters in itertools.product(elements, repeat=declaration.parameter_count):
            assert model.apply(name, Element(0), parameters) == model.evaluate(
                declaration.base, parameters
            )
            counts["recursion_base"] += 1
            for argument in elements:
                value = model.apply(name, argument, parameters)
                successor_value = model.apply(name, argument.successor(), parameters)
                step_value = model.evaluate(
                    declaration.step, (argument, value, *parameters)
                )
                assert successor_value == step_value
                counts["recursion_step"] += 1
                expected = program.apply(
                    name, argument.number, tuple(item.number for item in parameters)
                )
                assert value.number == expected
                counts["function_projection"] += 1

    x, y = variable(0), variable(1)
    terms = (
        x,
        y,
        successor(x),
        call("p", x),
        call("c", x, y, call("r", x)),
        call("mu", x, y),
        call("add", x, y),
        call("mu", x, call("add", x, y)),
    )
    for term in terms:
        program.validate(term, 2)
        for environment in itertools.product(elements, repeat=2):
            value = model.evaluate(term, environment)
            standard_value = program.evaluate(
                term, tuple(item.number for item in environment)
            )
            assert value.number == standard_value
            counts["term_projection"] += 1
            for numeral in range(cutoff + 1):
                assert (value == Element(numeral)) == (standard_value == numeral)
                counts["fixed_numeral_reflection"] += 1

    root = model.root
    predecessor = model.apply("p", root, ())
    recursive_identity = model.apply("r", root, ())
    assert predecessor == Element(cutoff)
    assert root != Element(0) and root != predecessor.successor()
    assert recursive_identity == Element(cutoff + 1) and recursive_identity != root

    return {
        "K": cutoff,
        "sample_number_bound": bound,
        "sample_element_count": len(elements),
        "declarations": list(program.declarations),
        "passed_check_counts": counts,
        "constructor_failure_witness": {
            "x": asdict(root),
            "p_x": asdict(predecessor),
            "S_p_x": asdict(predecessor.successor()),
            "x_equals_zero": False,
            "x_equals_S_p_x": False,
            "r_x": asdict(recursive_identity),
            "r_x_equals_x": False,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Also write the JSON report here")
    args = parser.parse_args()
    report = {
        "status": "PASS",
        "scope": (
            "Finite checks of the explicit evaluator and selected terms. "
            "These are not a proof of infinitely many axioms or induction instances."
        ),
        "rejected_invalid_declarations": syntax_checks(),
        "models": [finite_checks(0), finite_checks(1)],
    }
    rendered = json.dumps(report, indent=2) + "\n"
    if args.output is not None:
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")


if __name__ == "__main__":
    main()
