PRA SIMPLIFICATION PACKAGE
Prepared for Vladimir Reshetnikov
31 October 2026

MAIN RESULT

The same four arithmetic templates present PRA with either classical or
intuitionistic first-order logic:

  * the two defining equations of binary primitive recursion;
  * 0 != S(0);
  * guarded equation induction with only n and one parameter a free.

Every newly introduced recursive function symbol is binary. Arbitrary
finite-arity primitive recursive functions and arbitrary induction
parameter lists are recovered by an explicitly justified coding.

Full PRA is an explicit conservative definitional extension of the binary
theory. Retaining the original language instead gives exact same-language
equivalence after restricting only the induction parameter count.

This improves the current six supplied drafts by fixing both the recursion
arity and the induction parameter context. The guarded logical pattern
itself was already in three drafts. No claim of an absolute shortest
axiomatization or historical priority for binary coding is made.

FILES

pra_binary_axiomatization.tex
    Complete mathematical paper, including all definitions, constructive
    proofs, source comparison, scope qualifications, and countermodels.

pra_binary_axiomatization.pdf
    Compiled and visually reviewed paper.

axioms.txt
    Complete standalone axiom specification and concrete helper programs.

sources.json
    Immutable repository commit and six input archive names, paths, Git blob
    hashes, SHA-256 hashes, and background references.

formal/ThreeHelperPRA.lean
formal/README.txt
formal/verification.txt
    Lean 4.19.0 certificate and its exact scope. It uses actual two-variable
    term syntax, proves the comparison/compiler and one-parameter induction
    equivalence, and does not assume arbitrary-predicate induction.
    It does NOT formalize the pairing reduction, complete first-order proof
    translation, or countermodels. Those have mathematical proofs in the paper.

artifacts/binary_reference.py
artifacts/binary_verification.json
    Binary-recursion syntax, the actual six helper descriptions, formula
    compiler, pairing examples, and finite implementation checks.

artifacts/numeral_tail_model.py
artifacts/numeral_tail_verification.json
    General PR-description syntax and the exact duplicated-tail model,
    with explicit witnesses and finite checks of its implementation.

SHA256SUMS.txt
    Checksums for all other delivered files.

REPRODUCE

From this directory:

    latexmk -pdf -interaction=nonstopmode -halt-on-error pra_binary_axiomatization.tex

    lean formal/ThreeHelperPRA.lean

    python3 artifacts/binary_reference.py

    python3 artifacts/numeral_tail_model.py

    sha256sum -c SHA256SUMS.txt

The PDF needs a normal TeX Live installation with the packages named in the
preamble. The certificate needs Lean 4.19.0 only (no imports or Mathlib).
Python companions use the standard library.

WHAT WAS CHECKED

1. All six GitHub archives were downloaded and their Git blob SHA-1 values
   recomputed from their bytes; the pinned directory listing matches them.
2. The main mathematical constructions received independent proof review,
   including all induction parameter counts and the two theory translations.
3. Lean checked the explicitly scoped syntactic certificate successfully;
   the audited final theorems use only propositional extensionality.
4. Python finite checks passed for the helper programs, compiler, pairing,
   and duplicated-tail model implementation.
5. LaTeX compiled, references resolved, and the resulting pages were rendered
   and visually inspected.

Finite Python checks do not prove an infinite induction schema. The paper
contains the mathematical model constructions. The complete binary-PRA
equivalence is not advertised as fully mechanized.

READING GUIDE

Start with the boxed specification and Sections 1-2. Sections 3-5 prove
constructor cases, the shorter equality detector, and formula compilation.
Sections 6-7 give the carefully restricted pairing proof and the explicit
conservative definitional extension. Section 8 compares the six current
drafts. Sections 9 and Appendix A explain why several simpler-looking
constant-test proposals fail. Section 11 states verification scope.

The source drafts are not redistributed in this archive. This package was
prepared as the requested deliverable; no repository changes are required
to use it.

