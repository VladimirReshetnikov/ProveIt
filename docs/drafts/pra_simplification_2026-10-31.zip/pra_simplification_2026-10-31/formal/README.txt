FORMAL CERTIFICATE: THREE-HELPER PRA CORE

File: ThreeHelperPRA.lean
Checked with: Lean 4.19.0, commit 6caaee842e94, Release
Dependencies: Lean's standard initial environment only; no imports or Mathlib.

From the package root, run:

    lean formal/ThreeHelperPRA.lean

The successful check and dependency audit are recorded in verification.txt.

WHAT IS FORMALIZED

1. A finite term syntax Term Sigma arity n, with n numerical variables,
   zero, successor, predecessor, conditional, monus, and arbitrary further
   function symbols with specified finite arities. Terms and formulas are
   syntax trees, not arbitrary functions or predicates on the number type.

2. An abstract numerical type M with the six displayed defining equations
   for p, c, and monus, and the separation assumption 0 != S0. These are
   explicit fields of Core. No theorem asserts those hypotheses without
   assuming them.

3. The guarded schema G restricted to Term ... 2. Variable 0 is the induction
   variable n; variable 1 is one numerical parameter a. Dummy or unused
   variables are allowed. There is no induction assumption for arbitrary
   functions M -> M, arbitrary predicates M -> Prop, or terms containing
   an unbounded tuple of numerical parameters.

4. Derivation of successor injectivity and nonzeroness, constructor
   coverage, and one-parameter equation induction.

5. The addition-free equality detector based only on predecessor,
   conditional, and monus. Its four equation-induction instances are:

     monus(Sn, Sa) = monus(n, a)                         one parameter
     monus(n, n) = 0                                  no parameter
     monus(n, Sn) = 1                                  no parameter
     c(monus(a,n), monus(monus(n,a),a), n) = n          one parameter

   The certificate derives, without excluded middle:

     c(monus(x,y), monus(y,x), 1) = 0  iff  x = y.

6. A quantifier-free formula syntax with equality, truth, falsehood,
   conjunction, disjunction, and implication. Negation is implication to
   falsehood. The compiler is correct for every finite variable context.
   This proof uses structural induction on formula syntax in the metatheory;
   it is not an extra arithmetic induction assumption on M.

7. Quantifier-free induction for formulas with the induction variable and
   one numerical parameter, and the converse derivation of G from that
   one-parameter quantifier-free induction scheme. The final equivalence
   theorem is guarded_iff_quantifier_free.

AUDITED TRUST BASE

The five final #print axioms commands report only [propext]. This is Lean's
propositional extensionality principle, used by simplification. There is no
Classical.choice, sorryAx, or separately declared project axiom. Arithmetic
hypotheses remain explicit theorem parameters through Core and Guarded.

SCOPE LIMITS

This is a kernel-checked constructive algebraic certificate, not a complete
formalization of the paper as a first-order proof calculus. It does not
formalize the effective enumeration of all primitive-recursive descriptions,
the paired coding argument that reduces arbitrarily many numerical
parameters to one, the countermodels, or a syntactic translation of entire
first-order derivations. Those parts are proved in the paper. In particular,
the mechanically checked induction-transfer theorem has exactly the
one-parameter scope advertised in its statement; full finite-parameter PRA
equivalence also uses the paper's pairing reduction.
