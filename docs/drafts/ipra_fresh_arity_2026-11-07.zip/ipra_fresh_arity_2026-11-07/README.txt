A SMALLER COMPLETE PRESENTATION OF iPRA
Fresh parameters and constructor arities
Prepared for Vladimir Reshetnikov, 7 November 2026

RESULT

The strict standalone checker is below every current top-level checker
variant in all three reported implementation-size measures:

                              Current minimum       This work
Normalized significant tokens             483             460
AST nodes                                 491             475
Normalized UTF-8 bytes                   1,462           1,377

The same coordinatewise reduction holds for the uniformly isolated core:
  Current minimum: 423 tokens / 425 AST nodes / 1,200 bytes
  This work:       400 tokens / 410 AST nodes / 1,117 bytes

The corpus is the six archives and nine root checkers in ProveIt/docs/drafts
at commit c5f42a50d9213259760ee385977481c04dccab28. Earlier papers' quoted
505/510/1554 minima describe an older corpus and are not used here.
Normalization was executed with CPython 3.12.14 using the unchanged metric
function from the arity draft. The candidate remains strict about both
existential and closure witnesses while also beating the demand variants.

This is a strict finite-corpus implementation reduction, not a theorem of
absolute shortestness. The mathematical arithmetic and logical basis is
inherited and explicitly credited. The work combines compatible syntax and
scope reductions and proves two additional redundancies removable. It does
not claim that fewer arithmetic principles have been found.

READ

ipra_fresh_arity.pdf          Compiled self-contained report
ipra_fresh_arity.tex          Main LaTeX source
sections/*.tex               All included mathematical sections
checker.py                   Entire trusted acceptance program
FORMAT.txt                   Syntax, binding, and proof-stream contract
comparison/                  Nine unchanged comparators and source hashes
results/                     Measurements and independent audit records
validation/                  Offline translator, fixtures, references, tests
examples/zero_reflexivity.json  A three-instruction proof of zero reflexivity
reproduce.py                 Reproduce metrics and all finite validation
build.py                     Compile the supplied LaTeX twice with pdfLaTeX
MANIFEST.sha256              Integrity hashes for all other packaged files

RUN

From the extracted archive directory, with Python 3.10 or later:

  python3 checker.py examples/zero_reflexivity.json
  python3 reproduce.py
  python3 build.py

The first command prints ACCEPT and exits zero. Rejected inputs print
REJECT and exit one. The checker imports only json and sys. The validation
also uses only Python's standard library and files included here. It does
not need a repository checkout or network access. PDF rebuilding requires
a configured pdfLaTeX installation with the ordinary packages named in
ipra_fresh_arity.tex; the supplied PDF is already compiled.

The public theorem document is ONE FLAT JSON LIST: proof instructions first,
goal last. It is NOT the predecessor format [goal,stack]. The theorem CLI
always supplies an empty assumption context. Internal tests with a supplied
context are explicitly identified and are not a public theorem interface.

THEORY AND EQUIVALENCE

Terms: variables, zero, successor, and fixed finite initialized recursion.
Formulas: equality, existential binding, and Q_x B, whose ordinary meaning
is B(0) -> forall x B(x). The report states every primitive rule and both
recursion computation schemas. Ordinary intuitionistic logic, successor
properties, numerical cases, and quantifier-free induction are derived.

The ordinary first-order realization is bi-interpretable with iPRA on the
whole numerical domain. The two composite isomorphisms are defined by x=y;
internal recursion uniqueness establishes preservation of every fixed
operation, including on nonstandard elements. Faithful proof translations
connect that realization to the native calculus and the checker.

The report also proves a precise obstruction to the simplest untyped
numerical SK alternative: total application on the entire number domain,
with an element representing arithmetic successor, forces a=Sa. This is
incompatible with iPRA. Typed, partial, separate-sort, and proof-only
combinators are not ruled out. They need their own complete cost and
bi-interpretability argument.

VALIDATION

All tests ran against checker.py SHA-256:
d6a8c170db3214034020894efd4809ece785325be4de529453ef5e27cf0ffc5c

The main suite compares 143 historical fixtures, including 122 empty-context
theorem fixtures (numerical parameters allowed) and 21 explicitly contextual
internal sequents. Their translations yield 45 distinct theorem certificates,
each run through the real CLI normally and under -O. It also checks 48 source
adversarial cases, 1,200 openings against three references, 29 malformed
formation cases, and four cache/freshness regressions.

One independent suite checks 91 focused cases, 1,212 grammar comparisons,
and 182 real CLI executions. A second independently written suite checks
2,000 openings, 2,000 raw grammar inputs, and 24 end-to-end cases. Every
expected outcome matches. These overlapping categories must not be added
as a count of distinct theorems.

Finite executable checks support the mathematical proofs. Neither the
complete checker theorem nor the general bi-interpretations are claimed
to have been formally verified in Lean or Rocq.

PROVENANCE

The underlying calculus and its full reconstruction are adapted from the
fresh-parameter draft. Arity syntax, packed state, and direct streaming
come from the corresponding supplied proposals. The exact scope of the
new integration and redundancy deletion is stated in the paper.

comparison/manifest.json records immutable Git identities, archive SHA-256
hashes, and every copied checker hash. validation/data/provenance.json
records original fixture bytes and reference hashes. LICENSE_SOURCE.txt
preserves the supplied MIT No Attribution license.

