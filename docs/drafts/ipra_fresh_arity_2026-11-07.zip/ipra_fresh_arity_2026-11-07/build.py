"""Build the paper from its supplied LaTeX sources."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
for _ in range(2):
    subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                    'ipra_fresh_arity.tex'], cwd=ROOT, check=True)
print(ROOT / 'ipra_fresh_arity.pdf')
