"""Independent finite checks for the direct-stream iPRA certificates.

This is validation code, not part of the trusted acceptance program.
The reference answer does not reuse the compact kernel's substitution
algorithm. The kernels are imported only to compare their outputs with that
independently computed answer. It decodes coordinates to distinct, named binders, performs
simultaneous substitution on free names, and encodes back to coordinates.
The named-variable strategy also appears in the supplied archive2 validate.py;
this implementation has a separately written typed syntax and inference
interpreter.  See the package's attribution and source-license files.

Usage, from any directory:
    python3 validation/independent.py
    python3 validation/independent.py --samples 12000 --output validation/independent.json

The environment convention is OFFSET FIRST: [offset, image1, image2, ...].
Tests assume its well-scoped precondition offset >= -number_of_images.
Certificates retain the public JSON form [*reverse_execution_instructions, goal].
The reference interpreter supports both the strict and demand witness policy.
Passing these finite tests is evidence about the implementations, not a proof
of soundness, completeness, or the bi-interpretability metatheorem.
"""

from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import importlib.util
from itertools import count
import json
from pathlib import Path
import random
import sys


class Invalid(ValueError):
    """A malformed syntax tree, certificate, or substitution environment."""


# A named representation distinguishes constants, parameters, free coordinates,
# and bound names.  It never uses a de Bruijn shift during substitution itself.
@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Parameter:
    number: int


@dataclass(frozen=True)
class Free:
    number: int


@dataclass(frozen=True)
class Bound:
    name: int


@dataclass(frozen=True)
class Successor:
    value: object


@dataclass(frozen=True)
class Recursor:
    counter: object
    initial: object
    previous_value: int
    previous_counter: int
    update: object


@dataclass(frozen=True)
class Equation:
    left: object
    right: object


@dataclass(frozen=True)
class Closure:
    variable: int
    body: object


@dataclass(frozen=True)
class Existence:
    variable: int
    body: object


fresh_names = count()


def term_from_json(raw, scope=()):
    """Decode numerical syntax; scope[0] names coordinate one."""
    if type(raw) is int:
        if raw == 0:
            return Zero()
        if raw < 0:
            return Parameter(raw)
        if raw <= len(scope):
            return Bound(scope[raw - 1])
        return Free(raw - len(scope))
    if type(raw) is not list or not raw:
        raise Invalid("expected a numerical term")
    if raw[0] == "s" and len(raw) == 2:
        return Successor(term_from_json(raw[1], scope))
    if raw[0] == "r" and len(raw) == 4:
        initial_counter = term_from_json(raw[1], scope)
        initial_value = term_from_json(raw[2], scope)
        u, v = next(fresh_names), next(fresh_names)
        update = term_from_json(raw[3], (u, v) + scope)
        return Recursor(initial_counter, initial_value, u, v, update)
    raise Invalid("unknown term constructor or wrong numerical arity")


def formula_from_json(raw, scope=()):
    if type(raw) is not list or not raw:
        raise Invalid("expected a formula")
    if raw[0] == "=" and len(raw) == 3:
        return Equation(term_from_json(raw[1], scope), term_from_json(raw[2], scope))
    if raw[0] in ("q", "ex") and len(raw) == 2:
        x = next(fresh_names)
        body = formula_from_json(raw[1], (x,) + scope)
        return Closure(x, body) if raw[0] == "q" else Existence(x, body)
    raise Invalid("unknown formula constructor or wrong logical arity")


def term_to_json(term, scope=()):
    if isinstance(term, Zero):
        return 0
    if isinstance(term, Parameter):
        return term.number
    if isinstance(term, Free):
        if term.number <= 0:
            raise Invalid("free coordinate underflow")
        return term.number + len(scope)
    if isinstance(term, Bound):
        try:
            return scope.index(term.name) + 1
        except ValueError as error:
            raise Invalid("a bound name escaped its scope") from error
    if isinstance(term, Successor):
        return ["s", term_to_json(term.value, scope)]
    if isinstance(term, Recursor):
        update_scope = (term.previous_value, term.previous_counter) + scope
        return [
            "r", term_to_json(term.counter, scope), term_to_json(term.initial, scope),
            term_to_json(term.update, update_scope),
        ]
    raise Invalid("not a named numerical term")


def formula_to_json(formula, scope=()):
    if isinstance(formula, Equation):
        return ["=", term_to_json(formula.left, scope), term_to_json(formula.right, scope)]
    if isinstance(formula, Closure):
        return ["q", formula_to_json(formula.body, (formula.variable,) + scope)]
    if isinstance(formula, Existence):
        return ["ex", formula_to_json(formula.body, (formula.variable,) + scope)]
    raise Invalid("not a named formula")


def replace_free_names(node, environment, cache):
    """Simultaneous substitution: replacement images are not resubstituted.

    Images are parsed only when referenced.  This is needed to specify the
    demand policy for unused annotations without silently making it strict.
    Bound names cannot be captured, because every parser-created name is fresh.
    """
    if isinstance(node, Free):
        if node.number < len(environment):
            if node.number not in cache:
                cache[node.number] = term_from_json(environment[node.number])
            return cache[node.number]
        return Free(node.number + environment[0])
    if isinstance(node, (Zero, Parameter, Bound)):
        return node
    if isinstance(node, Successor):
        return Successor(replace_free_names(node.value, environment, cache))
    if isinstance(node, Recursor):
        return Recursor(
            replace_free_names(node.counter, environment, cache),
            replace_free_names(node.initial, environment, cache),
            node.previous_value, node.previous_counter,
            replace_free_names(node.update, environment, cache),
        )
    if isinstance(node, Equation):
        return Equation(
            replace_free_names(node.left, environment, cache),
            replace_free_names(node.right, environment, cache),
        )
    if isinstance(node, Closure):
        return Closure(node.variable, replace_free_names(node.body, environment, cache))
    if isinstance(node, Existence):
        return Existence(node.variable, replace_free_names(node.body, environment, cache))
    raise Invalid("unrecognized named syntax")


def reference_subst(raw, env=(1,), sort=True, d=0):
    """Capture-avoiding substitution through named syntax, independently."""
    if not env or type(env[0]) is not int or env[0] < 1 - len(env):
        raise Invalid("ill-scoped affine substitution environment")
    if type(d) is not int or d < 0:
        raise Invalid("invalid protected binder depth")
    protected = tuple(next(fresh_names) for _ in range(d))
    named = formula_from_json(raw, protected) if sort else term_from_json(raw, protected)
    changed = replace_free_names(named, env, {})
    return formula_to_json(changed, protected) if sort else term_to_json(changed, protected)


class ReferenceChecker:
    """Readable implementation of the six rules, with a separate named oracle.

    The input-language details are intentional: one instruction is consumed per
    visited node; an unrecognized instruction may discharge a hypothesis;
    failed-major pattern guards fall back to that hypothesis check; unused
    earlier input is inert.  These are the published acceptance policies.
    """

    def __init__(self, strict_witness=True):
        self.strict_witness = strict_witness
        self.stream = []
        self.rules = Counter()

    def check(self, goal, context):
        formula_from_json(goal)
        instruction = self.stream.pop()

        if goal[0] == "q" and instruction == []:
            self.rules["Q introduction"] += 1
            body = goal[1]
            new_context = [reference_subst(body, [0, 0])]
            if body[0] == "=":
                new_context.append(body)
            new_context.extend(reference_subst(a) for a in context)
            successor_goal = reference_subst(body, [0, ["s", 1]])
            return self.check(successor_goal, new_context)

        if goal[0] == "ex" and type(instruction) is list and len(instruction) == 1:
            self.rules["existence introduction"] += 1
            witness = reference_subst(instruction[0], sort=False)
            new_context = [["=", 1, witness]]
            new_context.extend(reference_subst(a) for a in context)
            return self.check(goal[1], new_context)

        elimination = (
            type(instruction) is list and len(instruction) == 2
            and type(instruction[0]) is list and len(instruction[0]) > 0
        )
        if elimination:
            major, annotation = instruction
            if not self.check(major, context):
                self.rules["hypothesis after failed major"] += 1
                return goal in context
            if major[0] == "ex":
                self.rules["existence elimination"] += 1
                new_context = [major[1]]
                new_context.extend(reference_subst(a) for a in context)
                return self.check(reference_subst(goal), new_context)
            if major[0] == "q":
                self.rules["Q elimination"] += 1
                if self.strict_witness:
                    term_from_json(annotation)
                premise = reference_subst(major[1], [-1, 0])
                conclusion = reference_subst(major[1], [-1, annotation])
            else:
                self.rules["equality transport"] += 1
                premise = reference_subst(annotation, [-1, major[1]])
                conclusion = reference_subst(annotation, [-1, major[2]])
            return conclusion == goal and self.check(premise, context)

        if (
            instruction == [] and goal[0] == "="
            and type(goal[1]) is list and goal[1][0] == "r"
        ):
            counter, initial, update = goal[1][1:]
            if counter == 0:
                self.rules["recursion zero"] += 1
                return goal[2] == initial
            if type(counter) is list and counter[0] == "s":
                self.rules["recursion successor"] += 1
                predecessor = counter[1]
                recursive_value = ["r", predecessor, initial, update]
                computed = reference_subst(update, [-2, recursive_value, predecessor], sort=False)
                return goal[2] == computed
            return False

        self.rules["hypothesis"] += 1
        return goal in context

    def accepts(self, document, context=()):
        self.stream = deepcopy(document)
        self.rules.clear()
        if type(self.stream) is not list:
            return False
        try:
            goal = self.stream.pop()
            return bool(self.check(goal, deepcopy(list(context))))
        except (Invalid, IndexError, TypeError, ValueError, RecursionError):
            return False


def load_kernel(path):
    name = "checked_" + path.stem
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def kernel_accepts(module, document, context=()):
    data = deepcopy(document)
    try:
        module.take = data.pop
        return bool(module.check(module.take(), deepcopy(list(context))))
    except Exception:
        return False


@dataclass
class Proof:
    goal: list
    instructions: list

    def document(self):
        return deepcopy(self.instructions + [self.goal])


def hypothesis(goal):
    return Proof(goal, [None])


def computation(counter, initial, update):
    if counter == 0:
        value = initial
    elif type(counter) is list and counter[0] == "s":
        n = counter[1]
        value = reference_subst(update, [-2, ["r", n, initial, update], n], sort=False)
    else:
        raise Invalid("a computation fixture needs zero or a successor")
    return Proof(["=", ["r", counter, initial, update], value], [[]])


def transport(major, motive, premise):
    if major.goal[0] != "=":
        raise Invalid("transport major is not equality")
    expected = reference_subst(motive, [-1, major.goal[1]])
    if premise.goal != expected:
        raise Invalid("transport fixture has the wrong premise")
    result = reference_subst(motive, [-1, major.goal[2]])
    return Proof(result, premise.instructions + major.instructions + [[major.goal, motive]])


def reflexivity(term):
    axiom = computation(0, term, 0)
    motive = ["=", 1, reference_subst(term, sort=False)]
    return transport(axiom, motive, axiom)


def closure_intro(body, step):
    if step.goal != reference_subst(body, [0, ["s", 1]]):
        raise Invalid("closure fixture has the wrong successor goal")
    return Proof(["q", body], step.instructions + [[]])


def closure_elim(major, witness, base):
    if major.goal[0] != "q":
        raise Invalid("closure elimination fixture has the wrong major")
    body = major.goal[1]
    if base.goal != reference_subst(body, [-1, 0]):
        raise Invalid("closure fixture has the wrong base")
    result = reference_subst(body, [-1, witness])
    return Proof(result, base.instructions + major.instructions + [[major.goal, witness]])


def existence_intro(body, witness, premise):
    if premise.goal != body:
        raise Invalid("existence fixture has the wrong open matrix")
    return Proof(["ex", body], premise.instructions + [[witness]])


def existence_elim(major, target, continuation, ignored_annotation=0):
    if major.goal[0] != "ex" or continuation.goal != reference_subst(target):
        raise Invalid("existence elimination fixture has wrong scoped data")
    return Proof(target, continuation.instructions + major.instructions + [[major.goal, ignored_annotation]])


def selector(n, a, b):
    return ["r", n, a, reference_subst(b, [2], sort=False)]


def explode_equation(contradiction, left, right):
    """A finite native derivation of left=right from the hypothesis 0=S0."""
    update = reference_subst(right, [2], sort=False)
    zero_case = computation(0, left, update)
    successor_case = computation(["s", 0], left, update)
    shifted_left = reference_subst(left, sort=False)
    shifted_right = reference_subst(right, sort=False)
    motive = ["=", selector(1, shifted_left, shifted_right), shifted_left]
    selected = transport(contradiction, motive, zero_case)
    return transport(selected, ["=", 1, shifted_right], successor_case)


def generated_cases():
    """Replayable closed and contextual fixtures, with explicit expectations."""
    cases = []

    def add(name, proof, strict=True, demand=None, context=()):
        document = proof.document() if isinstance(proof, Proof) else deepcopy(proof)
        cases.append({
            "name": name, "document": document, "context": list(context),
            "strict": strict, "demand": strict if demand is None else demand,
        })

    r0 = reflexivity(0)
    add("derived reflexivity at zero", r0)
    add("derived reflexivity at an ordinary free coordinate", reflexivity(7))
    add("derived reflexivity at a rigid parameter", reflexivity(-19))
    add("derived reflexivity at a nested recursor", reflexivity(["r", 2, -3, ["r", 2, 1, 5]]))
    add("recursion zero with two bound update variables", computation(0, 4, ["r", 2, 1, 3]))
    add("recursion successor with a nested update binder", computation(["s", 3], 5, ["r", 2, 1, 5]))

    identity_body = ["=", ["r", 1, 0, ["s", 1]], 1]
    identity_step_computation = computation(["s", 1], 0, ["s", 1])
    identity_step_motive = ["=", reference_subst(identity_step_computation.goal[1], sort=False), ["s", 1]]
    identity_step = transport(hypothesis(identity_body), identity_step_motive, identity_step_computation)
    identity_closure = closure_intro(identity_body, identity_step)
    add("equation induction using its induction hypothesis", identity_closure)
    identity_base = computation(0, 0, ["s", 1])
    add("equation induction instantiated at a rigid parameter", closure_elim(identity_closure, -7, identity_base))
    add("equation induction instantiated at a compound term", closure_elim(identity_closure, ["r", 1, 2, ["s", 1]], identity_base))

    contradiction = ["=", 0, ["s", 0]]
    retained_base_body = ["=", 1, ["s", 0]]
    retained_base_step = explode_equation(hypothesis(contradiction), ["s", 1], ["s", 0])
    add("retained atomic base is actually used", closure_intro(retained_base_body, retained_base_step))

    exists_zero = existence_intro(["=", 1, 0], 0, hypothesis(["=", 1, 0]))
    add("equality-guarded existence introduction", exists_zero)
    exists_parameter_body = ["=", 1, 2]
    add("existence introduction shifts a free witness", existence_intro(exists_parameter_body, 1, hypothesis(exists_parameter_body)))
    add("existence elimination with a fresh local witness", existence_elim(exists_zero, r0.goal, r0))
    add("existence elimination ignores its unused annotation", existence_elim(exists_zero, r0.goal, r0, {"unused": [True, "not syntax"]}))

    q_reflexivity = closure_intro(["=", 1, 1], reflexivity(["s", 1]))
    add("numerical closure of reflexivity", q_reflexivity)
    add("numerical closure elimination", closure_elim(q_reflexivity, ["s", -4], r0))
    vacuous_q = closure_intro(["=", 0, 0], r0)
    add("unused malformed Q witness distinguishes policies", closure_elim(vacuous_q, {"unused": True}, r0), strict=False, demand=True)
    add("unused Boolean Q witness distinguishes policies", closure_elim(vacuous_q, False, r0), strict=False, demand=True)
    used_bad_witness = closure_elim(q_reflexivity, 0, r0).document()
    used_bad_witness[-2][1] = {"used": "malformed"}
    add("used malformed Q witness is rejected by both", used_bad_witness, strict=False)
    add("existence witness is validated even for a vacuous matrix", existence_intro(["=", 0, 0], {"unused": True}, r0), strict=False)

    # This would be accepted if a compound closure incorrectly received B(y)
    # as an induction hypothesis.  Its actual context contains only B(0).
    compound_body = ["ex", ["=", 1, 2]]
    compound_step_goal = reference_subst(compound_body, [0, ["s", 1]])
    continued_goal = reference_subst(compound_step_goal)
    continuation = existence_intro(continued_goal[1], ["s", 2], hypothesis(continued_goal[1]))
    bad_step = existence_elim(hypothesis(compound_body), compound_step_goal, continuation)
    add("compound closure must not receive an induction hypothesis", closure_intro(compound_body, bad_step), strict=False)

    leaked_goal = ["=", 1, 0]
    leaking_document = [None] + exists_zero.instructions + [[exists_zero.goal, 0], leaked_goal]
    add("existential eigenvariable cannot escape into the conclusion", leaking_document, strict=False)
    add("a top-level hypothesis has no ambient assumptions", hypothesis(["=", 0, 0]), strict=False)
    add("a missing instruction is rejected", [["=", 0, 0]], strict=False)
    add("a false computation equation is rejected", [[], ["=", ["r", 0, 0, 1], ["s", 0]]], strict=False)
    add("symbolic counters are not one-step computation leaves", [[], ["=", ["r", 1, 0, 1], 0]], strict=False)
    add("irrelevant earlier stream entries are inert", [{"unused prefix": [False, None]}] + r0.document())
    add("root data is a stream, not a goal-proof pair", [r0.goal, r0.instructions], strict=False)
    add("empty stream is rejected", [], strict=False)
    add("an object is not an input stream", {"goal": ["=", 0, 0]}, strict=False)

    malformed_goals = {
        "Boolean numeral": ["=", False, 0],
        "Boolean below a successor": ["=", ["s", True], 0],
        "extra equation argument": ["=", 0, 0, 0],
        "missing equation argument": ["=", 0],
        "extra closure argument": ["q", ["=", 0, 0], 0],
        "numerical formula body": ["ex", 0],
        "formula in a term position": ["=", ["q", ["=", 0, 0]], 0],
        "extra successor argument": ["=", ["s", 0, 0], 0],
        "missing recursor update": ["=", ["r", 0, 0], 0],
        "formula in a recursor update": ["=", ["r", 0, 0, ["=", 0, 0]], 0],
        "unknown formula tag": ["implies", ["=", 0, 0], ["=", 0, 0]],
        "integer formula": 0,
    }
    for description, malformed in malformed_goals.items():
        add("syntax rejects " + description, [[], malformed], strict=False)

    # Internal sequents are separately labeled.  The public checker starts with
    # an empty context; these isolate individual rule and fallback obligations.
    eq = ["=", 1, 0]
    symmetry = transport(hypothesis(eq), ["=", 1, 2], reflexivity(1))
    add("contextual equality symmetry", symmetry, context=[eq])
    major = ["=", 0, ["s", 0]]
    fallback = [None, [major, 0], ["=", 0, 0]]
    add("failed major falls back to a valid hypothesis", fallback, context=[["=", 0, 0]])
    add("failed major cannot justify a missing hypothesis", fallback, strict=False)
    return cases


def random_term(rng, height, ambient=0):
    if height <= 0 or rng.random() < 0.48:
        return rng.choice([0, -1, -7, -31] + list(range(1, ambient + 6)))
    if rng.random() < 0.45:
        return ["s", random_term(rng, height - 1, ambient)]
    return [
        "r", random_term(rng, height - 1, ambient),
        random_term(rng, height - 1, ambient),
        random_term(rng, height - 1, ambient + 2),
    ]


def random_formula(rng, height, ambient=0):
    if height <= 0 or rng.random() < 0.55:
        return ["=", random_term(rng, 3, ambient), random_term(rng, 3, ambient)]
    return [rng.choice(["q", "ex"]), random_formula(rng, height - 1, ambient + 1)]


def check_substitution(kernels, samples, seed):
    explicit = [
        (["ex", ["=", 2, 1]], [-1, 1], True, 0, ["ex", ["=", 2, 1]]),
        (["r", 2, 1, ["r", 3, 2, 5]], [-1, 3], False, 0, ["r", 1, 3, ["r", 5, 2, 7]]),
        (["r", 3, 2, ["r", 3, 4, 5]], [-2, 2, 1], False, 0, ["r", 1, 1, ["r", 4, 3, 6]]),
        (["=", -19, 2], [-1, ["s", 4]], True, 1, ["=", -19, ["s", 5]]),
        (["q", ["=", 2, 1]], [0, ["s", 1]], True, 0, ["q", ["=", ["s", 2], 1]]),
        (["=", 0, -9], [-1, {"unused": True}], True, 0, ["=", 0, -9]),
    ]
    checks = 0
    for raw, env, sort, depth, expected in explicit:
        if reference_subst(raw, env, sort, depth) != expected:
            raise AssertionError("incorrect explicit named-oracle fixture")
        for name, kernel in kernels.items():
            if kernel.subst(raw, env, sort, depth) != expected:
                raise AssertionError(("explicit substitution", name, raw, env, depth, expected))
            checks += 1

    rng = random.Random(seed)
    for index in range(samples):
        sort = bool(rng.getrandbits(1))
        protected = rng.randrange(5)
        raw = random_formula(rng, 4, protected) if sort else random_term(rng, 5, protected)
        replacements = rng.randrange(4)
        env = [rng.randrange(-replacements, 4)]
        env.extend(random_term(rng, 3) for _ in range(replacements))
        expected = reference_subst(raw, env, sort, protected)
        for name, kernel in kernels.items():
            actual = kernel.subst(raw, env, sort, protected)
            if actual != expected:
                raise AssertionError(("random named substitution", index, name, raw, env, sort, protected, expected, actual))
            if kernel.subst(raw, [0], sort, protected) != raw:
                raise AssertionError(("identity substitution", index, name))
            raised = kernel.subst(raw, [1], sort, protected)
            if kernel.subst(raised, [-1, random_term(rng, 2)], sort, protected) != raw:
                raise AssertionError(("raise then discharge", index, name))
            checks += 3
    return {
        "seed": seed, "random_named_oracle_inputs": samples,
        "explicit_capture_and_simultaneous_cases": len(explicit),
        "kernel_comparisons_and_algebra_checks": checks,
        "environment_order": "offset first",
        "oracle": "fresh named binders; simultaneous substitution on free names; re-encoding",
    }


def check_certificates(kernels):
    outcomes = []
    rule_coverage = Counter()
    for case in generated_cases():
        row = {"name": case["name"], "contextual": bool(case["context"])}
        for policy, kernel in kernels.items():
            reference = ReferenceChecker(strict_witness=(policy == "strict"))
            oracle = reference.accepts(case["document"], case["context"])
            actual = kernel_accepts(kernel, case["document"], case["context"])
            expected = case[policy]
            if oracle != expected or actual != expected:
                raise AssertionError((case["name"], policy, "expected", expected, "oracle", oracle, "kernel", actual))
            row[policy] = "ACCEPT" if actual else "REJECT"
            if oracle:
                rule_coverage.update(reference.rules)
        row["certificate_sha256"] = hashlib.sha256(json.dumps(case["document"], sort_keys=True).encode()).hexdigest()
        outcomes.append(row)
    return {"cases": outcomes, "successful_rule_visits": dict(sorted(rule_coverage.items()))}


def mutation_corpus(kernels, seed):
    """Mutate real certificate fields; compare acceptance, not theorem truth.

    A mutation can remain a legitimate proof, so no general claim is made that
    every mutation should be rejected.  Both acceptance outcomes are counted.
    """
    rng = random.Random(seed)
    source_cases = [c for c in generated_cases() if c["strict"] and not c["context"]]
    counters = {name: Counter() for name in kernels}
    mutation_values = [None, True, False, -3, 0, 1, [], ["s", 0], ["bad"], ["=", 0, 0], {"bad": 1}]

    def paths(value, prefix=()):
        yield prefix
        if type(value) is list:
            for index, child in enumerate(value):
                yield from paths(child, prefix + (index,))

    documents = []
    for case in source_cases:
        original = case["document"]
        all_paths = list(paths(original))
        selected = rng.sample(all_paths, min(24, len(all_paths)))
        for path in selected:
            for replacement in rng.sample(mutation_values, 5):
                document = deepcopy(original)
                if not path:
                    document = deepcopy(replacement)
                else:
                    parent = document
                    for item in path[:-1]:
                        parent = parent[item]
                    parent[path[-1]] = deepcopy(replacement)
                documents.append(document)
        documents.extend([original[:-1], original[1:], list(reversed(original))])

    for index, document in enumerate(documents):
        for policy, kernel in kernels.items():
            reference = ReferenceChecker(strict_witness=(policy == "strict"))
            expected = reference.accepts(document)
            actual = kernel_accepts(kernel, document)
            if actual != expected:
                raise AssertionError(("certificate mutation", index, policy, document, expected, actual))
            counters[policy]["accepted" if actual else "rejected"] += 1
    return {"seed": seed, "mutated_documents": len(documents), "outcomes": {key: dict(value) for key, value in counters.items()}}


def check_examples(kernels, directory):
    """Optional comparison on the distributed public-format example files."""
    if not directory.exists():
        return {"files": 0, "status": "no examples directory supplied"}
    checked = 0
    outcomes = {name: Counter() for name in kernels}
    for path in sorted(directory.rglob("*.json")):
        document = json.loads(path.read_text())
        if type(document) is not list:
            continue
        for policy, kernel in kernels.items():
            reference = ReferenceChecker(strict_witness=(policy == "strict"))
            expected = reference.accepts(document)
            actual = kernel_accepts(kernel, document)
            if actual != expected:
                raise AssertionError(("distributed example", str(path), policy, expected, actual))
            outcomes[policy]["accepted" if actual else "rejected"] += 1
        checked += 1
    return {"files": checked, "outcomes": {key: dict(value) for key, value in outcomes.items()}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--samples", type=int, default=8000)
    parser.add_argument("--seed", type=int, default=20261106)
    parser.add_argument("--examples", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.samples < 1:
        parser.error("samples must be positive")
    root = args.root.resolve()
    kernels = {
        "strict": load_kernel(root / "checker.py"),
        "demand": load_kernel(root / "checker_demand.py"),
    }
    report = {
        "status": "PASS",
        "python": sys.version,
        "kernel_sha256": {
            name: hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
            for name, module in kernels.items()
        },
        "substitution": check_substitution(kernels, args.samples, args.seed),
        "certificates": check_certificates(kernels),
        "mutations": mutation_corpus(kernels, args.seed + 1),
        "distributed_examples": check_examples(kernels, args.examples or root / "examples"),
        "limitation": "Finite validation evidence, not a machine-checked proof of the metatheorems.",
    }
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(encoded, end="")


if __name__ == "__main__":
    main()
