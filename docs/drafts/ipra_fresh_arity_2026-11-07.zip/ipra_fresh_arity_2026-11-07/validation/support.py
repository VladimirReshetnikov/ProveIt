"""Shared validation utilities; never imported by checker.py."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PROGRAM = ROOT / 'checker.py'
BASELINE = ROOT / 'comparison/sources/fresh_parameters/checker.py'


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify_provenance():
    provenance = json.loads((HERE / 'data/provenance.json').read_text())
    for item in provenance['references']:
        actual = sha256(HERE / item['local_file'])
        require(actual == item['sha256'], ('Changed reference file', item['local_file'], actual))
    require(sha256(PROGRAM) == provenance['candidate_sha256'], 'Selected checker bytes changed.')
    return provenance


def run(module, goal, proof, context=(), candidate=False):
    """Run one sequent with a fresh supply; validate all external assumptions.

    External contexts are internal tests only. The theorem CLI always uses [].
    """
    module.k = 0
    stream = deepcopy(proof)
    try:
        for assumption in context:
            module.inst(assumption)
        if candidate:
            module.take = stream.pop
            accepted = bool(module.check(deepcopy(goal), deepcopy(list(context))))
        else:
            accepted = bool(module.check(deepcopy(goal), stream, deepcopy(list(context))))
        return {'accepted': accepted, 'remaining': stream, 'counter': module.k, 'error': None}
    except Exception as error:
        return {'accepted': False, 'remaining': stream, 'counter': module.k,
                'error': type(error).__name__}
