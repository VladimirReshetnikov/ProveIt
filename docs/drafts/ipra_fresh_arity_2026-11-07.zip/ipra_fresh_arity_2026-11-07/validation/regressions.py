"""New arity, cached-goal, and fresh-name regression cases."""
from support import require, run
from translate import encode


def reflexivity(term):
    return [[], [], [['=', ['r', 0, term, 0], term], ['=', 1, term]]]


def targeted_checks(candidate, baseline):
    major = ['ex', ['=', 0, 0]]
    major_proof = reflexivity(0) + [[0]]
    qgoal = ['u', ['=', 1, 1]]
    egoal = ['ex', ['=', 1, 1]]
    cases = [
        ('existential_elimination_to_Q', qgoal,
         reflexivity(['s', -2]) + [[]] + major_proof + [[major, None]], True),
        ('existential_elimination_to_E', egoal,
         reflexivity(0) + [[0]] + major_proof + [[major, None]], True),
        ('existential_elimination_to_false', ['=', 0, ['s', 0]],
         [None] + major_proof + [[major, None]], False),
    ]
    rows = []
    for name, goal, proof, wanted in cases:
        source = run(baseline, goal, proof)
        target = run(candidate, encode(goal), encode(proof), candidate=True)
        require(source['accepted'] == target['accepted'] == wanted,
                ('New regression', name, source, target))
        require(source['counter'] == target['counter'], ('Regression counter', name))
        rows.append({'name': name, 'expected': wanted, 'baseline': source, 'candidate': target,
                     'candidate_document': [*encode(proof), encode(goal)]})
    truth = [0, 0]
    ghost_major = [truth, [-100, -100], [[1, 1]]]
    ghost_proof = encode(reflexivity(0)) + encode(major_proof) + [[ghost_major, None]]
    ghost = run(candidate, truth, ghost_proof, candidate=True)
    require(ghost['accepted'] and ghost['counter'] == -101, ('Ghost registration', ghost))
    rows.append({'name': 'existential_ghost_parameter_registration', 'expected': True,
                 'candidate': ghost, 'candidate_document': [*ghost_proof, truth]})
    return rows


def formation_checks(candidate):
    invalid_terms = [None, False, True, 0.0, 1.0, '', 'x', {}, [], [0, 0],
                     [0, 0, 0, 0], [False], [None], [0, 0, False]]
    truth = [0, 0]
    invalid_formulas = [None, False, True, 0, 1, -1, 0.0, '', {}, [], [0],
                        [truth, False, truth], [truth, truth, []],
                        [truth, truth, truth, truth], [0, 1]]
    rows = []
    for kind, invalid, state in [('term', invalid_terms, 1), ('formula', invalid_formulas, 0)]:
        for bad in invalid:
            candidate.k = 0
            try:
                candidate.inst(bad, d=state)
            except (TypeError, IndexError, KeyError) as error:
                rows.append({'kind': kind, 'bad': bad, 'rejected': True,
                             'exception': type(error).__name__})
            else:
                raise AssertionError(('Malformed expression accepted', kind, bad))
    return rows
