SELF-CONTAINED VALIDATION OF THE STRICT LOCALLY CLOSED ARITY CHECKER

Run from any working directory:

  python3 validation/verify.py

The runner expects the complete deliverable layout:

  checker.py
  comparison/sources/fresh_parameters/checker.py
  validation/verify.py
  validation/translate.py
  validation/support.py
  validation/opening.py
  validation/regressions.py
  validation/data/...
  validation/reference/...

No download, external package, source repository, or optional proof assistant
is needed. The checker under test imports none of this directory.

WHAT IS TESTED

1. All 143 original strict fixtures from the reviewed fresh-parameter archive
   are merged into data/source_fixtures.json. Each record retains its original
   member path, exact UTF-8 source bytes, byte size, and SHA-256. The runner
   verifies those bytes before parsing. There are 122 closed source fixtures
   and 21 explicitly contextual internal sequents. Public theorem execution
   always starts with an empty assumption context.

   Canonical translation is compared with the unchanged fresh-parameter
   checker. Acceptance, final fresh-parameter counter, and unread stream
   prefix must all match. The closed fixtures yield 45 distinct certificates.

2. data/source_audit_cases.json is copied unchanged from that archive. All 48
   source cases must match their explicit strict-policy expectations. Cases
   include malformed witnesses, numerical-index capture, fresh-name
   collision, and eigenvariable escape attempts.

3. The 1,200 deterministic opening cases cover both sorts, zero through three
   outer image slots, and zero through two protected binder depths. Outputs
   are compared against three existing references: the unchanged locally
   closed fresh-parameter checker, the unchanged affine substitution checker,
   and an unchanged oracle that decodes to distinct named binders and
   substitutes free names. The latter two are in reference/. Only their
   substitution APIs are used here; their standalone historical runners are
   retained byte-for-byte for provenance and are not this package's runner.

4. Twenty-nine explicit malformed term/formula cases test list formation,
   constructor arities, sorts, Boolean rejection, and locally closed scope.
   Four new targeted tests cover existential elimination to both closure and
   existential conclusions, a false target, and fresh-name registration in
   existential ghost matrices. The first two exercise the cached-goal branch
   and prevent introduction patterns from rebinding that cached goal before
   a successful elimination.

5. All 45 distinct closed certificates run through checker.py as real CLI
   processes, normally and under Python -O: 90 processes. The runner emits
   these certificates under validation/examples/ and full results under
   validation/results/.

TRANSLATOR

  python3 validation/translate.py source.json target.json

The standalone producer accepts the tagged source public pair [goal,stack]
and emits the new flat stream [*stack,goal]. It erases exact constructor tags
and inserts two fixed true ghost matrices per existential. It is not part of
the trusted checker. Its theorem-translation claim is for well-formed source
derivations; arbitrary malformed inputs need not have matching acceptance.

PROVENANCE AND TRUST BOUNDARY

data/provenance.json records the pinned current repository commit, exact
archive identities and hashes, copied file paths and hashes, merged dataset
hash, and the selected checker hash. Reference files and the source audit
are copied without editing. The original MIT No Attribution license is in
reference/LICENSE_SOURCE.txt. The copied reference implementations are
validation tools, not additional trusted acceptance code.

The numerical supply k is reset before every independent document. External
contexts in internal tests are explicitly validated before the checker runs.
These fixture classes overlap and must not be added as distinct theorem
counts. Finite executable checks support the handwritten metatheory; they
do not constitute a general Lean/Rocq soundness or bi-interpretability proof.
