"""Translate a fresh-parameter tagged theorem certificate to canonical arity.

Usage: python3 validation/translate.py source.json target.json
This untrusted producer is not imported by the acceptance program.
"""
import argparse
import json
from pathlib import Path


def encode(value):
    """Erase exact constructor tags; add two true existential ghost matrices.

    Unknown shapes are copied recursively, not repaired into valid constructors.
    The correctness theorem concerns well-formed source derivations; this is
    not a promised acceptance-preserving map on all malformed JSON documents.
    """
    if type(value) is not list:
        return value
    if len(value) == 2 and value[0] == 'ex':
        return [encode(value[1]), [0, 0], [0, 0]]
    arities = {'s': 2, 'u': 2, '=': 3, 'r': 4}
    if value and type(value[0]) is str and arities.get(value[0]) == len(value):
        return [encode(child) for child in value[1:]]
    return [encode(child) for child in value]


def theorem_document(source):
    """Convert the source public pair [goal,stack] to [*stack,goal]."""
    if type(source) is not list or len(source) != 2 or type(source[1]) is not list:
        raise ValueError('Expected a public source theorem pair [goal, stack].')
    goal, proof = source
    return [*encode(proof), encode(goal)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('target', type=Path)
    args = parser.parse_args()
    result = theorem_document(json.loads(args.source.read_text()))
    args.target.write_text(json.dumps(result, separators=(',', ':')) + '\n')


if __name__ == '__main__':
    main()
