"""Deterministic opening comparisons using unchanged affine and named oracles."""
import random
from support import HERE, load, require
from translate import encode

SEED = 20261107


def term(rng, depth, budget):
    if budget <= 0 or rng.randrange(4) == 0:
        return rng.choice([0, -1, -7, -23, *range(1, depth + 1)])
    if rng.randrange(2):
        return ['s', term(rng, depth, budget - 1)]
    return ['r', term(rng, depth, budget - 1), term(rng, depth, budget - 1),
            term(rng, depth + 2, budget - 1)]


def formula(rng, depth, budget):
    if budget <= 0 or rng.randrange(3) == 0:
        return ['=', term(rng, depth, budget), term(rng, depth, budget)]
    return [rng.choice(['u', 'ex']), formula(rng, depth + 1, budget - 1)]


def q_tag(value):
    """The frozen named oracle spells the same closure constructor q."""
    if type(value) is list:
        result = [q_tag(child) for child in value]
        if result and result[0] == 'u':
            result[0] = 'q'
        return result
    return value


def opening_checks(candidate, baseline):
    named = load(HERE / 'reference/named_oracle.py', 'frozen_named_oracle')
    affine = load(HERE / 'reference/affine_reference.py', 'frozen_affine_reference')
    rng = random.Random(SEED)
    comparisons = 0
    for is_formula in (False, True):
        for holes in range(4):
            for depth in range(3):
                for trial in range(50):
                    expression = (formula if is_formula else term)(rng, depth + holes, 3)
                    images = [term(rng, 0, 2) for _ in range(holes)]
                    baseline.k = candidate.k = 0
                    for image in images:
                        baseline.inst(image, formula=False)
                        candidate.inst(encode(image), d=1)
                    expected = baseline.inst(expression, images, depth, is_formula)
                    affine_result = affine.subst(expression, [*images, -holes], depth, is_formula)
                    named_result = named.reference_subst(q_tag(expression), [-holes, *q_tag(images)],
                                                         sort=is_formula, d=depth)
                    actual = candidate.inst(encode(expression), encode(images),
                                            2 * depth + (not is_formula))
                    require(expected == affine_result and q_tag(expected) == named_result,
                            ('Reference disagreement', expression, images, depth, is_formula))
                    require(actual == encode(expected) and baseline.k == candidate.k,
                            ('Opening or supply disagreement', expression, images, depth, is_formula))
                    comparisons += 1
    return {'seed': SEED, 'comparisons': comparisons, 'sorts': 2,
            'hole_counts': [0, 1, 2, 3], 'protected_depths': [0, 1, 2],
            'trials_per_combination': 50,
            'references': ['unchanged fresh-parameter checker',
                           'unchanged affine substitution checker',
                           'unchanged named-binder substitution oracle'],
            'status': 'all expected outcomes matched'}
