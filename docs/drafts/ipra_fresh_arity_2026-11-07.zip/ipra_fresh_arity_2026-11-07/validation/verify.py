"""Reproduce the finite validation of the frozen strict arity checker.

Run from any directory: python3 validation/verify.py
Only Python's standard library and the files in this archive are required.
Every check here is untrusted support; checker.py imports none of it.
"""
import hashlib
import json
from pathlib import Path
import platform
import re
import subprocess
import sys

from opening import opening_checks
from regressions import formation_checks, targeted_checks
from support import BASELINE, HERE, PROGRAM, load, require, run, sha256, verify_provenance
from translate import encode, theorem_document


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + '\n')


def corpus_checks(candidate, baseline):
    dataset_path = HERE / 'data/source_fixtures.json'
    dataset = json.loads(dataset_path.read_text())
    require(dataset['fixture_count'] == len(dataset['fixtures']) == 143, 'Wrong fixture count.')
    rows = []
    distinct = {}
    theorem_count = 0
    for item in dataset['fixtures']:
        raw = item['raw_utf8'].encode('utf-8')
        require(hashlib.sha256(raw).hexdigest() == item['sha256'],
                ('Changed source fixture', item['source_member']))
        require(len(raw) == item['size_bytes'], ('Source size mismatch', item['source_member']))
        goal, proof, *context = json.loads(raw)
        require(len(context) == item['context_size'], ('Context count', item['source_member']))
        source = run(baseline, goal, proof, context)
        target = run(candidate, encode(goal), encode(proof), encode(context), candidate=True)
        good = (source['accepted'] and target['accepted'] and
                encode(source['remaining']) == target['remaining'] and
                source['counter'] == target['counter'])
        require(good, ('Corpus mismatch', item['source_member'], source, target))
        row = {'source_member': item['source_member'], 'source_sha256': item['sha256'],
               'context_size': len(context), 'baseline': source, 'candidate': target}
        if not context:
            theorem_count += 1
            document = theorem_document([goal, proof])
            encoded = (json.dumps(document, separators=(',', ':')) + '\n').encode()
            if encoded not in distinct:
                stem = re.sub('[^A-Za-z0-9_-]', '_', Path(item['source_member']).stem)
                destination = HERE / 'examples' / ('%03d_%s.json' % (len(distinct) + 1, stem))
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(encoded)
                distinct[encoded] = destination
            row['translated_example'] = str(distinct[encoded].relative_to(HERE))
            row['translated_sha256'] = hashlib.sha256(encoded).hexdigest()
        rows.append(row)
    require(theorem_count == 122 and len(distinct) == 45, 'Changed theorem fixture totals.')
    return rows, list(distinct.values()), theorem_count


def source_audit(candidate, baseline):
    cases = json.loads((HERE / 'data/source_audit_cases.json').read_text())
    require(len(cases) == 48, 'Wrong source audit count.')
    rows = []
    for case in cases:
        source = run(baseline, case['goal'], case['proof'])
        target = run(candidate, encode(case['goal']), encode(case['proof']), candidate=True)
        require(source['accepted'] == target['accepted'] == case['expected_strict'],
                ('Source audit mismatch', case['name'], source, target))
        rows.append({'name': case['name'], 'expected': case['expected_strict'],
                     'baseline': source, 'candidate': target})
    return rows


def cli_checks(examples):
    rows = []
    for example in examples:
        for optimized in (False, True):
            process = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                      str(PROGRAM), str(example)],
                                     capture_output=True, text=True, timeout=30)
            row = {'example': str(example.relative_to(HERE)), 'optimized': optimized,
                   'returncode': process.returncode, 'stdout': process.stdout.strip(),
                   'stderr': process.stderr.strip()}
            require(process.returncode == 0 and row['stdout'] == 'ACCEPT', ('CLI failure', row))
            rows.append(row)
    return rows


def main():
    provenance = verify_provenance()
    candidate = load(PROGRAM, 'selected_arity_checker')
    baseline = load(BASELINE, 'unchanged_fresh_parameter_checker')
    corpus, examples, theorem_count = corpus_checks(candidate, baseline)
    audit = source_audit(candidate, baseline)
    openings = opening_checks(candidate, baseline)
    formation = formation_checks(candidate)
    targeted = targeted_checks(candidate, baseline)
    cli = cli_checks(examples)
    verify_provenance()
    summary = {
        'status': 'all expected outcomes matched', 'python': platform.python_version(),
        'repository_commit': provenance['snapshot_commit'],
        'checker_sha256': sha256(PROGRAM), 'baseline_sha256': sha256(BASELINE),
        'corpus_cases': len(corpus), 'closed_source_fixtures': theorem_count,
        'open_sequent_fixtures': len(corpus) - theorem_count,
        'distinct_closed_certificates': len(examples), 'source_audit_cases': len(audit),
        'opening_comparisons': openings['comparisons'],
        'malformed_formation_cases': len(formation),
        'new_targeted_cases': len(targeted), 'cli_executions': len(cli),
        'normal_cli_acceptances': sum(not row['optimized'] for row in cli),
        'optimized_cli_acceptances': sum(row['optimized'] for row in cli),
        'scope': 'Finite regression and differential evidence; no general formal-verification claim.'
    }
    write_json(HERE / 'results/corpus.json', corpus)
    write_json(HERE / 'results/source_audit.json', audit)
    write_json(HERE / 'results/openings.json', openings)
    write_json(HERE / 'results/formation.json', formation)
    write_json(HERE / 'results/targeted.json', targeted)
    write_json(HERE / 'results/cli.json', cli)
    write_json(HERE / 'results/summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
