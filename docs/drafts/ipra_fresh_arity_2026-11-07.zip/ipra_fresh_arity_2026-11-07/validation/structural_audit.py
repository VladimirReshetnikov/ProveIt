"""Independent grammar/opening and fresh-name audit of packed_cached.

Only this audit imports the delivered candidate; the candidate imports no
audit code.  The reference traversal uses separate explicit term/formula
grammars, rather than the candidate's packed sort/depth and arity table.
"""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location(
    'candidate', ROOT / 'checker.py')
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)


def reference(a, env, depth, formula, minimum):
    if not formula and type(a) is int:
        minimum[0] = min(minimum[0], a)
        return a if a <= depth else env[a - depth - 1]
    if type(a) is not list:
        raise ValueError('list required')
    if formula:
        if len(a) == 1:
            return [reference(a[0], env, depth + 1, True, minimum)]
        if len(a) == 2:
            return [reference(a[0], env, depth, False, minimum),
                    reference(a[1], env, depth, False, minimum)]
        if len(a) == 3:
            return [reference(x, env, depth + 1, True, minimum) for x in a]
    else:
        if len(a) == 1:
            return [reference(a[0], env, depth, False, minimum)]
        if len(a) == 3:
            return [reference(a[0], env, depth, False, minimum),
                    reference(a[1], env, depth, False, minimum),
                    reference(a[2], env, depth + 2, False, minimum)]
    raise ValueError('unsupported arity')


rng = random.Random(7112026)


def closed_term(depth=0, budget=3):
    if not budget or rng.randrange(3) == 0:
        return rng.choice([0, -1, -9, -100, *range(1, depth + 1)])
    if rng.randrange(2):
        return [closed_term(depth, budget - 1)]
    return [closed_term(depth, budget - 1),
            closed_term(depth, budget - 1),
            closed_term(depth + 2, budget - 1)]


def formula(depth=0, budget=3):
    if not budget or rng.randrange(3) == 0:
        return [closed_term(depth), closed_term(depth)]
    if rng.randrange(2):
        return [formula(depth + 1, budget - 1)]
    return [formula(depth + 1, budget - 1) for _ in range(3)]


def raw(budget=3):
    leaves = [None, True, False, 0, -1, 1, 2, 3, 99, 0.0, '', 'x', {}]
    if not budget or rng.randrange(3) == 0:
        return rng.choice(leaves)
    return [raw(budget - 1) for _ in range(rng.randrange(6))]


def traverse(a, env, depth, is_formula):
    minimum = [-7]
    try:
        expected = reference(deepcopy(a), env, depth, is_formula, minimum)
        expected_ok = True
    except Exception:
        expected, expected_ok = None, False
    candidate.k = -7
    try:
        got = candidate.inst(deepcopy(a), deepcopy(env), 2 * depth + (not is_formula))
        got_ok = True
    except Exception:
        got, got_ok = None, False
    assert expected_ok == got_ok, (a, env, depth, is_formula, expected_ok, got_ok)
    if got_ok:
        assert got == expected and candidate.k == minimum[0]
    return got_ok


def refl_instructions(t):
    major = [[0, t, 0], t]
    return [[major, [1, t]], [], []]


def check(name, goal, instructions, expected, expected_counter=None):
    candidate.k = 0
    stack = list(reversed(deepcopy(instructions)))
    candidate.take = stack.pop
    try:
        accepted = bool(candidate.check(deepcopy(goal), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    assert accepted == expected, (name, accepted, expected, error)
    if expected_counter is not None:
        assert candidate.k == expected_counter, (name, candidate.k, expected_counter)
    return {'name': name, 'expected': expected, 'accepted': accepted,
            'counter': candidate.k, 'expected_counter': expected_counter,
            'remaining_instructions': len(stack), 'error': error}


def main():
    traversal_accepted = 0
    for _ in range(2000):
        mode = bool(rng.randrange(2))
        depth = rng.randrange(4)
        holes = rng.randrange(3)
        env = [closed_term() for _ in range(holes)]
        a = formula(depth + holes) if mode else closed_term(depth + holes)
        traversal_accepted += traverse(a, env, depth, mode)
    raw_accepted = 0
    for _ in range(2000):
        raw_accepted += traverse(raw(), [], rng.randrange(4), bool(rng.randrange(2)))

    rows = []
    rows.append(check('reflexivity zero', [0, 0], refl_instructions(0), True, 0))
    rows.append(check('Q fresh parameter', [[1, 1]],
                      [[]] + refl_instructions([-1]), True, -1))
    rows.append(check('Q deep update parameter registered', [[[0, 1, -500], 1]],
                      [[], []], True, -501))
    rows.append(check('Q opening under recursor double binder', [[[0, 1, 3], 1]],
                      [[], []], True, -1))
    e_outer = [[2, 2], [0, 0], [0, 0]]
    rows.append(check('Q opening under existential binder', [e_outer],
                      [[], [0]] + refl_instructions([-1]), True, -1))

    major = [[1, -700], [0, 0], [0, 0]]
    rows.append(check('E major names precede allocation', [0, 0],
                      [[major, None], [-700]] + refl_instructions(-700)
                      + refl_instructions(0), True, -701))
    major = [[1, 0], [-1000, -1000], [0, 0]]
    rows.append(check('E inert padding names still registered', [0, 0],
                      [[major, None], [0]] + refl_instructions(0)
                      + refl_instructions(0), True, -1001))
    major = [[1, 0], [0, 0], [0, 0]]
    rows.append(check('E eigenparameter cannot escape into conclusion', [-1, 0],
                      [[major, None], [0]] + refl_instructions(0) + [None], False, -2))
    rows.append(check('strict vacuous E witness boolean rejected',
                      [[0, 0], [0, 0], [0, 0]],
                      [[True]] + refl_instructions(0), False))
    major = [[0, 0]]
    rows.append(check('strict vacuous Q witness boolean rejected', [0, 0],
                      [[major, True], [], None] + refl_instructions(0), False))

    malformed = [[], 0, False, [0], [0, True], [0, 0, 0],
                 [0, 0, 0, 0], [[0, 0], [0], [0, 0]],
                 [[2, 2], [0, 0], [0, 0]], [[0, 0, 3], 0],
                 [[0, 0], 0]]
    for i, a in enumerate(malformed):
        rows.append(check(f'malformed syntax {i}', a, [None], False))
    for n in [0, -1, -10]:
        rows.append(check(f'false rigid successor equation {n}', [n, [n]],
                          [None], False))
    result = {'candidate': 'checker.py',
              'seed': 7112026, 'well_formed_opening_cases': 2000,
              'well_formed_opening_cases_accepted': traversal_accepted,
              'raw_json_grammar_cases': 2000,
              'raw_json_grammar_cases_accepted': raw_accepted,
              'end_to_end_cases': len(rows), 'all_passed': True,
              'cases': rows}
    (ROOT / 'results/structural_audit.json').write_text(
        json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'cases'}, indent=2))


if __name__ == '__main__':
    main()
