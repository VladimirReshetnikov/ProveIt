"""Reproduce the pinned, whole-program checker comparison and paper tables."""
import csv
import json
import platform
from pathlib import Path
from comparison.source_measure import metrics

ROOT = Path(__file__).resolve().parent
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    for entry in manifest['programs']:
        measured = metrics(ROOT / 'comparison' / entry['local_file'])
        if measured['sha256'] != entry['sha256']:
            raise ValueError('Comparison source changed: ' + entry['label'])
        rows.append({**entry, **measured})
    candidate = metrics(ROOT / 'checker.py')
    minimum = {key: min(row[key] for row in rows) for key in KEYS}
    strict_minimum = {key: min(row[key] for row in rows if row['witness_policy'] == 'strict') for key in KEYS}
    core_minimum = {key: min(row['core'][key] for row in rows) for key in KEYS}
    result = {
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'commit': manifest['commit'],
        'archive_count': len(manifest['archives']),
        'program_count': len(rows),
        'coordinatewise_minimum': minimum,
        'strict_coordinatewise_minimum': strict_minimum,
        'core_coordinatewise_minimum': core_minimum,
        'candidate': candidate,
        'strict_improvement': {key: candidate[key] < minimum[key] for key in KEYS},
        'strict_core_improvement': {key: candidate['core'][key] < core_minimum[key] for key in KEYS},
        'programs': rows,
    }
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (ROOT / 'results/metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ['label', 'witness_policy', *KEYS, 'sha256'], extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
        writer.writerow({'label': 'new/checker.py', 'witness_policy': 'strict', **candidate})
    values = {'NewTokens': candidate[KEYS[0]], 'NewAST': candidate[KEYS[1]], 'NewBytes': candidate[KEYS[2]],
              'OldTokens': minimum[KEYS[0]], 'OldAST': minimum[KEYS[1]], 'OldBytes': minimum[KEYS[2]],
              'CoreTokens': candidate['core'][KEYS[0]], 'CoreAST': candidate['core'][KEYS[1]], 'CoreBytes': candidate['core'][KEYS[2]],
              'OldCoreTokens': core_minimum[KEYS[0]], 'OldCoreAST': core_minimum[KEYS[1]], 'OldCoreBytes': core_minimum[KEYS[2]]}
    (ROOT / 'results/numbers.tex').write_text(''.join('\\newcommand{\\' + key + '}{' + str(value) + '}\n' for key, value in values.items()))
    table = ['\\begin{tabular}{@{}llrrr@{}}', '\\toprule',
             'Archive / program & Policy & Tokens & AST & Bytes\\\\', '\\midrule']
    for row in rows:
        name, filename = row['label'].split('/')
        label = name.replace('_', r'\_') + (' (demand)' if 'demand' in filename else '')
        table.append(label + ' & ' + row['witness_policy'] + ' & ' + ' & '.join(str(row[k]) for k in KEYS) + r'\\')
    table += ['\\midrule', 'Coordinatewise minimum & all & ' + ' & '.join(str(minimum[k]) for k in KEYS) + r'\\',
              r'\textbf{This work} & strict & ' + ' & '.join(r'\textbf{' + str(candidate[k]) + '}' for k in KEYS) + r'\\',
              '\\bottomrule', '\\end{tabular}']
    (ROOT / 'results/comparison_table.tex').write_text('\n'.join(table) + '\n')
    if not all(result['strict_improvement'].values()) or not all(result['strict_core_improvement'].values()):
        raise AssertionError('The claimed strict comparison no longer holds')
    print(json.dumps({k: v for k, v in result.items() if k != 'programs'}, indent=2))


if __name__ == '__main__':
    main()
