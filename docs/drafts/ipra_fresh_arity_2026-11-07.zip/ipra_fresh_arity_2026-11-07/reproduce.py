"""Reproduce all recorded measurements and executable checks, offline."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
for script in ('measure.py', 'validation/verify.py', 'validation/independent_audit.py', 'validation/structural_audit.py'):
    print('Running', script, flush=True)
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
files = ('results/metrics.json', 'validation/results/summary.json',
         'results/independent_audit.json', 'results/structural_audit.json')
summary = {'status': 'PASS', 'recorded_results': list(files)}
(ROOT / 'results/reproduction.json').write_text(json.dumps(summary, indent=2) + '\n')
print('PASS: all measurement comparisons and validation suites completed.')
