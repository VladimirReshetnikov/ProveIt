TWO VARIABLE PRA AND SMALLER GRAPH AXIOMS
Prepared for Vladimir Reshetnikov, 1 November 2026.
Latest reviewed commit: 0bf6525f9b09421e5ffacdd5fba7648d28b7fcff.

START HERE
  report.pdf                 Complete mathematical report.
  report.tex, *.tex           Editable self-contained manuscript sections.
  AXIOMS.txt                 Exact JNI1 arithmetic specification.
  source_manifest.json        Both pinned comparison snapshots and hashes.
  VALIDATION.txt              Checked scope, replay steps, and limitations.
  supplements/t0_boundary.tex  Optional exact T0 boundary proof, not in main PDF.

MAIN RESULTS
1. Complete binary-recursion JNI1 presentation: 38 partial AST nodes,
   at most two individual variable names in each nonlogical axiom, and
   one optional frozen induction parameter. A literal reflexive-base
   syntax gate is essential and its encoding is not priced. Both matching
   classical/intuitionistic theories have full-carrier identity
   bi-interpretations with first-order PRA.
2. The latest implicit-initialization family is independently smaller
   at its 37+5r display profile; its initialization recovery uses an extra
   probe. The zero-extra-parameter fragment is NOT claimed sufficient.
   No global shortestness or full encoding minimum is claimed here.
3. Graph structure: 90 -> 50 with unchanged source relation.
   Fully priced C79/G12 source variant: fixed seed 661 -> 337;
   repeated arithmetic-axiom overhead 572 -> 72. The infinite arithmetic
   axiom scheme remains. Alternative fixed/repeated trade-offs are listed.
4. Zero induction parameters fail in the stated raw-description theories;
   one suffices. Pure scalar iteration remains conditional on an internally
   verified predecessor term, not constructed in this report.

PROVENANCE
sources/ records the five current archives and eight preceding archives,
including immutable GitHub URLs, Git blob identities, SHA-256 values,
member inventories and successful supplied-checksum audits. None of their
scripts or Lean sources was executed. The original quaternary calibration
sources are retained under references/; the previous fused/guarded/sink
package is an unmodified, unexecuted reference ZIP.

SUPPLEMENT
supplements/t0_boundary.tex proves T0 equivalent to successor computation,
separation, one-parameter QFI, and unary parameter-free pullback. It also
proves closed-seed initialization and the seed/successor interchange
criterion. Arbitrary-seed initialization and a T0/PRA compiler remain open.
See the adjacent scope note. The audited main PDF is unchanged.

REPRODUCTION
Python 3.10+ standard library and a configured TeX Live installation suffice.
  sh checks.sh
  sh build.sh --pdf-only
  sh build.sh
Direct Python equivalents are available via build.py; its PDF mode needs
a configured TeX Live. The shell wrapper can build a local TeX cache on
a minimal Linux TeX installation.
The PDF build disables shell escape and needs only packages named in
report.tex. Checks are offline and execute this report's authored scripts,
not any code inside references/ or source archives. Graph checks are the
portable hardened copies; their numerical checks remain active under -O.
See VALIDATION.txt and artifacts/*/RUN_VALIDATION.txt for detailed scope.

Run before rebuilding to verify delivered bytes:
  sha256sum -c SHA256SUMS
Rebuilding may change PDF metadata and logs; identical rebuilt PDF bytes
are not promised. The diagnostic JSON outputs exclude run timestamps where
normal/optimized equality is claimed. No end-to-end Lean/Rocq certificate
or finite-model proof of PRA is claimed.
