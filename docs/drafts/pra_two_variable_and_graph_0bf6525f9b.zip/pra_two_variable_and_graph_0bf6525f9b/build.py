#!/usr/bin/env python3
"""Offline rebuild of this local report and its independently authored checks.

Python 3.10+ and configured TeX Live are required. Never executes the
inherited source/reference archives. Generated outputs may change hashes.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def run(command, cwd=ROOT, capture=False):
    return subprocess.run(command, cwd=cwd, check=True, text=True,
                          capture_output=capture)

def checks():
    a = ROOT / 'artifacts'
    run([sys.executable, str(a/'check_binary.py')])
    run([sys.executable, str(a/'binary_fused_counts.py')])
    run([sys.executable, str(a/'induction'/'check_joint_reflexive.py'),
         str(a/'induction'/'joint_reflexive_checks.json')])
    r = a/'relational'
    run([sys.executable, str(r/'validate_relational_portable.py'),
         '--relational', str(r), '--ledger', str(r/'independent_sink53_ledger.py'),
         '--baseline', str(r/'sink90_baseline.sexp'),
         '--output', str(r/'replay_validation')])
    pure = run([sys.executable, str(a/'check_pure_pairing.py')], capture=True)
    json.loads(pure.stdout)
    (a/'pure_iteration_diagnostics.json').write_text(pure.stdout)
    print(pure.stdout, end='')

def pdf():
    exe = shutil.which('pdflatex')
    if not exe:
        raise SystemExit('pdflatex unavailable: install/configure TeX Live, then rerun.')
    out = ROOT/'_build'; out.mkdir(exist_ok=True)
    for i in range(1, 4):
        result = run([exe, '-interaction=nonstopmode', '-halt-on-error',
                      '-no-shell-escape', '-output-directory='+str(out),
                      'report.tex'], capture=True)
        (out/f'latex-pass-{i}.log').write_text(result.stdout+result.stderr)
    log = (out/'report.log').read_text(errors='replace')
    if 'Undefined control sequence' in log or 'There were undefined references' in log:
        raise SystemExit('Unresolved TeX error/reference; inspect _build/report.log.')
    shutil.copy2(out/'report.pdf', ROOT/'report.pdf')
    print('Rebuilt report.pdf. Review its layout before redistribution.')

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group()
    group.add_argument('--checks-only', action='store_true')
    group.add_argument('--pdf-only', action='store_true')
    args=parser.parse_args()
    if not args.pdf_only: checks()
    if not args.checks_only: pdf()
