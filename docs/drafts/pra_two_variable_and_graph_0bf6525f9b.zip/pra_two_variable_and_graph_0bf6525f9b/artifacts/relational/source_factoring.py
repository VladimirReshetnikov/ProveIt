"""Fully expanded reduced source conditions; no selectors hidden as atoms."""
from sink53 import *

def C71():
    body = AND(R('x', 'y', 'z', 'x'), R('x', 'y', 'a', 'u'), R('x', 'y', 'k', 'v'), imp(R('x', 'y', 'a', 'w'), eq('w', 'u')), imp(R('x', 'y', 'k', 'w'), eq('w', 'v')), imp(R('x', 'y', 't', 'w'), OR(AND(eq('t', 'z'), eq('w', 'x')), eq('t', 'a'), eq('t', 'k'))))
    return AND(R('a', 'a', 'a', 'k'), ALL(['x', 'y'], SOME(['u', 'v'], ALL(['w', 't'], body))))

def C79():
    body = AND(R('a', 'x', 'y', 'u'), R('k', 'x', 'y', 'v'), imp(R('a', 'x', 'y', 'w'), eq('w', 'u')), imp(R('k', 'x', 'y', 'w'), eq('w', 'v')), imp(R('t', 'x', 'y', 'w'), OR(AND(eq('t', 'z'), eq('x', 'z'), eq('y', 'z'), eq('w', 'z')), eq('t', 'a'), eq('t', 'k'))))
    return AND(R('a', 'a', 'a', 'k'), R('z', 'z', 'z', 'z'), ALL(['x', 'y'], SOME(['u', 'v'], ALL(['w', 't'], body))))

def stats(t):
    if t[0] in ['var', 'false']:
        return (0, 0)
    if t[0] in ['forall', 'exists']:
        r, q = stats(t[2])
        return (r, q + 1)
    v = [stats(s) for s in t[1:]]
    return (int(t[0] == 'R') + sum((a for a, b in v)), sum((b for a, b in v)))
if __name__ == '__main__':
    here = pathlib.Path(__file__).parent
    out = {}
    for name, t in [('projection', C71()), ('old_source', C79())]:
        n = count(t)
        r, q = stats(t)
        g = n + 16 * r + 4 * q
        out[name] = {'nodes': n, 'R_occurrences': r, 'quantifiers': q, 'graph_translated_C': g, 'sink_guarded_existence': g + 23, 'fixed_seed_plus_graph50': g + 73, 'per_arithmetic_axiom_overhead_plus_translated_theta': g + 24}
        (here / (name + '_factored_C.sexp')).write_text(sexpr(t) + '\n')
    (here / 'source_factoring_metrics.json').write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps(out, indent=2))
