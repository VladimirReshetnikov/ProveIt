"""Exact AST finite Kripke diagnostics for the pair-test binder sharing."""
from itertools import product
import random, json, pathlib
from sink53 import *
from sink82 import J81
from diagnostic_helpers import evaluate, encode, ordinary_AST
Qall = ALL(['i', 'j'], imp(AND(O('i'), O('j')), pair_exists('i', 'j')))
formulas = [imp(AND(J50()[2], Qall), J51()[2]), imp(J51()[2], J50()[2]), imp(J81()[2], J()[2]), imp(J()[2], J81()[2])]
frames = [('chain', {0: (0, 1), 1: (1,)}, [(), (1,), (0, 1)]), ('fork', {0: (0, 1, 2), 1: (1,), 2: (2,)}, [(), (1,), (2,), (1, 2), (0, 1, 2)])]
rng = random.Random(20261101)
tested = 0
counts = {}
for name, future, patterns in frames:
    count_here = 0
    for n in (1, 2, 3):
        edges = list(product(range(n), repeat=2))
        vals = product(range(len(patterns)), repeat=len(edges)) if n < 3 else (tuple((rng.randrange(len(patterns)) for _ in edges)) for _ in range(1500))
        for val in vals:
            WE = {w: set() for w in future}
            for e, p in zip(edges, val):
                for w in patterns[p]:
                    WE[w].add(e)
            for m in range(n):
                outcomes = evaluate(formulas, n, WE, future, m)
                if not all(outcomes):
                    raise AssertionError((name, n, val, m, outcomes))
                tested += 1
                count_here += 1
    for nobj, reps in ((1, len(patterns)), (2, 100)):
        rows = list(product(range(nobj), repeat=4))
        for i in range(reps):
            val = [i] if nobj == 1 else [rng.randrange(len(patterns)) for _ in rows]
            WE = {}
            labels = None
            for w in future:
                R = {row for row, p in zip(rows, val) if w in patterns[p]}
                V, EE = encode(range(nobj), R)
                if labels is None:
                    labels = {v: j for j, v in enumerate(sorted(V, key=repr))}
                WE[w] = {(labels[a], labels[b]) for a, b in EE}
            outcomes = evaluate(formulas + [J50()[2], J51()[2], J81()[2], J()[2]], len(labels), WE, future, labels['marker',])
            if not all(outcomes):
                raise AssertionError((name, nobj, val, outcomes))
            tested += 1
            count_here += 1
    counts[name] = count_here
out = {'status': 'PASS', 'constant_domain_Kripke_models_and_markers': tested, 'frames': counts, 'checked_implications': ['J50 AND pair existence -> J51', 'J51 -> J50', 'J81 -> J82', 'J82 -> J81'], 'exhaustive_domains_1_and_2': True, 'sampled_domain_3_valuations_per_frame': 1500, 'canonical_nonconstant_relation_models': 208, 'not_a_completeness_certificate': True}
pathlib.Path(__file__).with_name('sink50_kripke_checks.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
