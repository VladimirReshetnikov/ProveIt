from ledger import *

def O(x):
    return E(x, 'm')

def pair_exists(x, y):
    return EX('p', AND(E(x, 'p'), E('p', y)))

def B(x, y):
    return imp(O(y), AND(neg(E(x, y)), pair_exists(x, y)))

def F(x, a, b, y):
    return imp(O(y), AND(imp(E(y, x), eq(y, a)), imp(E(x, y), eq(y, b))))

def U(x, a, b, y):
    return imp(AND(E(a, y), E(y, b)), eq(y, x))

def D(x):
    return SOME(['a', 'b'], AND(O('a'), O('b'), FA('y', AND(F(x, 'a', 'b', 'y'), U(x, 'a', 'b', 'y')))))

def J():
    return EX('m', FA('x', AND(neg(E('m', 'x')), imp(O('x'), FA('y', B('x', 'y'))), OR(eq('x', 'm'), O('x'), D('x')))))

def J85():
    return EX('m', FA('x', SOME(['a', 'b'], FA('y', AND(neg(E('m', 'x')), imp(O('x'), B('x', 'y')), OR(eq('x', 'm'), O('x'), AND(O('a'), O('b'), E('x', 'b'), F('x', 'a', 'b', 'y'), U('x', 'a', 'b', 'y'))))))))

def sexpr(t):
    if t[0] == 'var':
        return t[1]
    if t[0] == 'false':
        return 'false'
    if t[0] in ['forall', 'exists']:
        return f'({t[0]} {t[1]} {sexpr(t[2])})'
    return '(' + ' '.join([t[0]] + [sexpr(a) for a in t[1:]]) + ')'
if __name__ == '__main__':
    r = {'closed_readable': count(J()), 'closed_prenex': count(J85()), 'coordinate_branch': count(D('x')), 'ordinary_pair_existence': count(pair_exists('x', 'y'))}
    print(json.dumps(r, indent=2))
    pathlib.Path(__file__).with_name('sink82_metrics.json').write_text(json.dumps(r, indent=2) + '\n')
    pathlib.Path(__file__).with_name('sink82.sexp').write_text(sexpr(J()) + '\n')
    pathlib.Path(__file__).with_name('sink85.sexp').write_text(sexpr(J85()) + '\n')

def J81():
    return EX('m', FA('x', SOME(['a', 'b'], FA('y', AND(neg(E('m', 'x')), imp(O('x'), B('x', 'y')), OR(eq('x', 'm'), O('x'), AND(O('a'), O('b'), F('x', 'a', 'b', 'y'), U('x', 'a', 'b', 'y'))))))))
