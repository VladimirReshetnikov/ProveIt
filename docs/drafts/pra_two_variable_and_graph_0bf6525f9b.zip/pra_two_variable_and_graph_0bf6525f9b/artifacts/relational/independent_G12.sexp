(and (forall v (R k z v z)) (R a k z k))
