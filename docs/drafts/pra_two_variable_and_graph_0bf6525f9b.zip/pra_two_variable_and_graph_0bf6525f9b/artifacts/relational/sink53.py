from sink82 import *

def D0(x):
    return SOME(['a', 'b'], AND(O('a'), O('b'), FA('y', U(x, 'a', 'b', 'y'))))

def J53():
    return EX('m', FA('x', AND(neg(E('m', 'x')), imp(O('x'), FA('y', imp(O('y'), neg(E('x', 'y'))))), OR(eq('x', 'm'), O('x'), D0('x')))))

def J62():
    return EX('m', FA('x', AND(neg(E('m', 'x')), imp(O('x'), FA('y', B('x', 'y'))), OR(eq('x', 'm'), O('x'), D0('x')))))

def R(x, y, t, w):
    return ('R', V(x), V(y), V(t), V(w))

def oldbranch():
    return AND(eq('t', 'z'), eq('x', 'z'), eq('y', 'z'), eq('w', 'z'))

def newbranch():
    return AND(eq('t', 'z'), eq('w', 'x'))

def reconstruction(branch):
    return ALL(['x', 'y', 't', 'w'], iff(R('x', 'y', 't', 'w'), OR(branch, AND(eq('t', 'a'), R('x', 'y', 'a', 'w')), AND(eq('t', 'k'), R('x', 'y', 'k', 'w')))))
if __name__ == '__main__':
    data = {'closed_structure': count(J53()), 'structure_plus_explicit_pair_existence': count(J62()), 'coordinate_inverse_fibre_branch': count(D0('x')), 'old_source_zero_branch': count(oldbranch()), 'new_source_projection_branch': count(newbranch()), 'old_source_reconstruction_equation': count(reconstruction(oldbranch())), 'new_source_reconstruction_equation': count(reconstruction(newbranch())), 'source_reconstruction_saving': count(reconstruction(oldbranch())) - count(reconstruction(newbranch())), 'marker_unique_from_full_theory_not_structure_alone': True, 'unchanged_source_supported_by_operand_output_argument_regrouping': True}
    print(json.dumps(data, indent=2))
    pathlib.Path(__file__).with_name('sink53_metrics.json').write_text(json.dumps(data, indent=2) + '\n')
    pathlib.Path(__file__).with_name('sink53.sexp').write_text(sexpr(J53()) + '\n')
    pathlib.Path(__file__).with_name('sink62.sexp').write_text(sexpr(J62()) + '\n')

def H(x, y):
    return imp(OR(eq(x, 'm'), AND(O(x), O(y))), neg(E(x, y)))

def J51():
    return EX('m', FA('x', AND(FA('y', H('x', 'y')), OR(eq('x', 'm'), O('x'), D0('x')))))

def J50():
    return EX('m', FA('x', SOME(['a', 'b'], FA('y', AND(H('x', 'y'), OR(eq('x', 'm'), O('x'), AND(O('a'), O('b'), U('x', 'a', 'b', 'y'))))))))
