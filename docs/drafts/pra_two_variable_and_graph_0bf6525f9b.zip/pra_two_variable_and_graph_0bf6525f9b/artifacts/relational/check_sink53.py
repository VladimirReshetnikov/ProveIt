"""Finite diagnostics of the sufficient separate-cancellation package.
These are NOT finite models of PRA. The formal constructive proof uses
actual source addition; finite Latin squares test just the structural lemma.
"""
import sys, pathlib, itertools, json, random
HERE = pathlib.Path(__file__).resolve().parent
from diagnostic_helpers import ordinary, ast_eval
from sink53 import J53, J51, J50

def weak(V, E, m):
    O = {x for x in V if (x, m) in E}
    return not any(((m, x) in E for x in V)) and (not any(((a, b) in E for a in O for b in O))) and all((x == m or x in O or any((all(((a, y) not in E or (y, b) not in E or y == x for y in V)) for a in O for b in O)) for x in V))

def decode(V, E, m):
    O = {x for x in V if (x, m) in E}
    pairs = {(a, b): {p for p in V if (a, p) in E and (p, b) in E} for a in O for b in O}
    return {(t, a, b, s) for t, a, b, s in itertools.product(O, repeat=4) if any(((p, q) in E for p in pairs[a, b] for q in pairs[t, s]))}

def package(O, R, t):
    A = {(a, b, s) for tt, a, b, s in R if tt == t}
    return all((any(((a, b, s) in A for s in O)) for a in O for b in O)) and all((len({a for a in O if (a, b, s) in A}) <= 1 for b in O for s in O)) and all((len({b for b in O if (a, b, s) in A}) <= 1 for a in O for s in O))

def canonical(O, R):
    m = ('m',)
    oo = {a: ('o', a) for a in O}
    pp = {(a, b): ('p', a, b) for a in O for b in O}
    V = {m} | set(oo.values()) | set(pp.values())
    E = {(oo[a], m) for a in O} | {(oo[a], pp[a, b]) for a in O for b in O} | {(pp[a, b], oo[b]) for a in O for b in O} | {(pp[a, b], pp[t, s]) for t, a, b, s in R}
    return (V, E, m)
checks = weakaccept = sourceaccept = ast = 0
for n in range(1, 5):
    V = set(range(n))
    edges = list(itertools.product(V, repeat=2))
    for bits in range(1 << len(edges)):
        E = {e for i, e in enumerate(edges) if bits >> i & 1}
        for m in V:
            ok = weak(V, E, m)
            checks += 1
            weakaccept += ok
            if bits % 503 == 0 or ok:
                if not all((ast_eval(t[2], V, E, {'m': m}) == ok for t in (J53(), J51(), J50()))):
                    raise AssertionError('validation condition failed')
                ast += 1
            if ok:
                O = {x for x in V if (x, m) in E}
                R = decode(V, E, m)
                for t in O:
                    if package(O, R, t):
                        if not ordinary(V, E, m):
                            raise AssertionError((n, bits, m, t))
                        sourceaccept += 1
V = {0, 1, 2}
E = {(1, 0)}
if not (weak(V, E, 0) and (not ordinary(V, E, 0))):
    raise AssertionError('validation condition failed')
if not all((ast_eval(t[2], V, E, {'m': 0}) for t in (J53(), J51(), J50()))):
    raise AssertionError('validation condition failed')
if not not package({1}, decode(V, E, 0), 1):
    raise AssertionError('validation condition failed')
if not {x for x in V if not any(((x, y) in E for y in V))} == {0, 2}:
    raise AssertionError('validation condition failed')
roundtrips = mutations = accepted_mutations = 0
free = list(itertools.product(range(2), repeat=3))
for bits in range(256):
    R = {(0, a, b, a ^ b) for a in range(2) for b in range(2)} | {(1, *row) for i, row in enumerate(free) if bits >> i & 1}
    V, E, m = canonical(range(2), R)
    if not (weak(V, E, m) and ordinary(V, E, m)):
        raise AssertionError('validation condition failed')
    RR = decode(V, E, m)
    raw = {tuple((x[1] for x in r)) for r in RR}
    if not raw == R:
        raise AssertionError('validation condition failed')
    O = {x for x in V if (x, m) in E}
    if not package(O, RR, ('o', 0)):
        raise AssertionError('validation condition failed')
    coords = {p: (next((a for a in O if (a, p) in E)), next((b for b in O if (p, b) in E))) for p in V - O - {m}}
    VV, EE, mm = canonical(O, RR)
    f = {m: mm, **{a: ('o', a) for a in O}, **{p: ('p', *ab) for p, ab in coords.items()}}
    if not (set(f.values()) == VV and {(f[a], f[b]) for a, b in E} == EE):
        raise AssertionError('validation condition failed')
    roundtrips += 1
    for edge in itertools.product(V, repeat=2):
        EE = E ^ {edge}
        mutations += 1
        if weak(V, EE, m):
            OO = {x for x in V if (x, m) in EE}
            RRR = decode(V, EE, m)
            if ('o', 0) in OO and package(OO, RRR, ('o', 0)):
                if not ordinary(V, EE, m):
                    raise AssertionError('validation condition failed')
                accepted_mutations += 1
out = {'status': 'PASS', 'all_graph_marker_pairs_through_4_vertices': checks, 'J53_accepted': weakaccept, 'J53_plus_decoded_total_separately_cancellative_operation_cases': sourceaccept, 'exact_AST_checks': ast, 'structure_alone_two_sink_counterexample_verified': True, 'two_object_Latin_square_plus_all_free_tag_relations_both_roundtrips': roundtrips, 'single_edge_mutations_of_those_graphs': mutations, 'mutations_still_satisfying_sufficient_package': accepted_mutations, 'finite_package_models_are_not_models_of_PRA': True}
(HERE / 'sink53_checks.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
