"""Independent complete finite/source-scheme ledger for the round-six graph.

This file does not import or execute the candidate or repository programs.
Quantifier binder names are labels; each variable occurrence, relation,
equality, binary connective, falsity, and quantifier costs one node.
"""
from functools import reduce
from pathlib import Path
import json
import hashlib
HERE = Path(__file__).resolve().parent
REL = HERE if (HERE / 'sink50.sexp').is_file() else HERE.parent / 'research' / 'relational'
OLD = HERE.parents[1] / 'pra_round5' / 'package'

def v(s):
    return ('var', s)

def atom(s, *xs):
    return (s, *(v(x) for x in xs))

def eq(x, y):
    return atom('=', x, y)

def edge(x, y):
    return atom('E', x, y)

def imp(a, b):
    return ('implies', a, b)

def conj(*xs):
    return reduce(lambda a, b: ('and', a, b), xs)

def disj(*xs):
    return reduce(lambda a, b: ('or', a, b), xs)

def neg(a):
    return imp(a, ('false',))

def iff(a, b):
    return conj(imp(a, b), imp(b, a))

def quant(kind, x, a):
    return (kind, x, a)

def forall(xs, a):
    return reduce(lambda a, x: quant('forall', x, a), reversed(xs), a)

def exists(xs, a):
    return reduce(lambda a, x: quant('exists', x, a), reversed(xs), a)

def unique(x, y, f):
    return exists([x], conj(f(x), forall([y], imp(f(y), eq(y, x)))))

def size(t):
    if t[0] in ('var', 'false'):
        return 1
    if t[0] in ('forall', 'exists'):
        return 1 + size(t[2])
    return 1 + sum((size(a) for a in t[1:]))

def nodes(t, kind):
    if t[0] in ('var', 'false'):
        return int(t[0] == kind)
    children = [t[2]] if t[0] in ('forall', 'exists') else t[1:]
    return int(t[0] == kind) + sum((nodes(a, kind) for a in children))

def source_parts(projection):

    def R(t, x, y, w):
        return atom('R', x, y, t, w) if projection else atom('R', t, x, y, w)
    Z = lambda u: R(u, u, u, u)
    A = lambda u: forall(['v'], R(u, 'z', 'v', 'v'))
    B = (lambda u: forall(['v'], R(u, 'a', 'v', 'v'))) if projection else lambda u: forall(['v'], R(u, 'z', 'v', 'z'))
    branch = conj(eq('t', 'z'), eq('w', 'x')) if projection else conj(eq('t', 'z'), eq('x', 'z'), eq('y', 'z'), eq('w', 'z'))
    return {'zero_selector': forall(['u'], iff(Z('u'), eq('u', 'z'))), 'addition_selector': forall(['u'], iff(A('u'), eq('u', 'a'))), 'multiplication_selector': forall(['u'], iff(B('u'), eq('u', 'k'))), 'addition_total_unique': forall(['x', 'y'], unique('w', 'w1', lambda w: R('a', 'x', 'y', w))), 'multiplication_total_unique': forall(['x', 'y'], unique('w', 'w1', lambda w: R('k', 'x', 'y', w))), 'two_is_one_plus_one': R('a', 'a', 'a', 'k'), 'reconstruction': forall(['t', 'x', 'y', 'w'], iff(R('t', 'x', 'y', 'w'), disj(branch, conj(eq('t', 'a'), R('a', 'x', 'y', 'w')), conj(eq('t', 'k'), R('k', 'x', 'y', 'w')))))}

def translate(t, projection, serial=None):
    if serial is None:
        serial = [0]
    if t[0] in ('var', 'false'):
        return t
    if t[0] in ('forall', 'exists'):
        op, x, a = t
        body = translate(a, projection, serial)
        guarded = imp(edge(x, 'marker'), body) if op == 'forall' else conj(edge(x, 'marker'), body)
        return quant(op, x, guarded)
    if t[0] == 'R':
        args = [a[1] for a in t[1:]]
        if projection:
            x, y, tag, w = args
        else:
            tag, x, y, w = args
        serial[0] += 1
        p, q = (f'decoder_p_{serial[0]}', f'decoder_q_{serial[0]}')
        return exists([p, q], conj(edge(x, p), edge(p, y), edge(tag, q), edge(q, w), edge(p, q)))
    return (t[0], *(translate(a, projection, serial) for a in t[1:]))

def sink_guard(a):
    return forall(['marker'], imp(forall(['s'], neg(edge('marker', 's'))), a))

def structure53():
    O = lambda x: edge(x, 'marker')
    D = lambda x: exists(['a', 'b'], conj(O('a'), O('b'), forall(['y'], imp(conj(edge('a', 'y'), edge('y', 'b')), eq('y', x)))))
    return exists(['marker'], forall(['x'], conj(neg(edge('marker', 'x')), imp(O('x'), forall(['y'], imp(O('y'), neg(edge('x', 'y'))))), disj(eq('x', 'marker'), O('x'), D('x')))))

def structure50():
    O = lambda x: edge(x, 'marker')
    H = imp(disj(eq('x', 'marker'), conj(O('x'), O('y'))), neg(edge('x', 'y')))
    U = imp(conj(edge('a', 'y'), edge('y', 'b')), eq('y', 'x'))
    return exists(['marker'], forall(['x'], exists(['a', 'b'], forall(['y'], conj(H, disj(eq('x', 'marker'), O('x'), conj(O('a'), O('b'), U)))))))

def factored_C(projection):

    def R(t, x, y, w):
        return atom('R', x, y, t, w) if projection else atom('R', t, x, y, w)
    support_zero = conj(eq('t', 'z'), eq('w', 'x')) if projection else conj(eq('t', 'z'), eq('x', 'z'), eq('y', 'z'), eq('w', 'z'))
    clauses = [R('a', 'x', 'y', 'u'), R('k', 'x', 'y', 'v'), imp(R('a', 'x', 'y', 'w'), eq('w', 'u')), imp(R('k', 'x', 'y', 'w'), eq('w', 'v')), imp(R('t', 'x', 'y', 'w'), disj(support_zero, eq('t', 'a'), eq('t', 'k')))]
    if projection:
        clauses.insert(0, R('z', 'x', 'y', 'x'))
    shared = forall(['x', 'y'], exists(['u', 'v'], forall(['w', 't'], conj(*clauses))))
    return conj(R('a', 'a', 'a', 'k'), shared) if projection else conj(R('a', 'a', 'a', 'k'), R('z', 'z', 'z', 'z'), shared)

def short_old_source_guard():
    return conj(forall(['v'], atom('R', 'k', 'z', 'v', 'z')), atom('R', 'a', 'k', 'z', 'k'))

def sexpr(t):
    if t[0] == 'var':
        return t[1]
    if t[0] == 'false':
        return 'false'
    if t[0] in ('forall', 'exists'):
        return f'({t[0]} {t[1]} {sexpr(t[2])})'
    return '(' + ' '.join([t[0], *(sexpr(a) for a in t[1:])]) + ')'

def parse(s):
    ts = iter(s.replace('(', ' ( ').replace(')', ' ) ').split())

    def item(tok):
        if tok != '(':
            return tok
        ans = []
        for t in ts:
            if t == ')':
                return ans
            ans.append(item(t))
        raise ValueError('unterminated sexp')
    ans = item(next(ts))
    if not next(ts, None) is None:
        raise AssertionError('validation condition failed')
    return ans

def raw_count(t):
    if isinstance(t, str):
        return 1
    if t[0] in ('forall', 'exists'):
        return 1 + raw_count(t[2])
    return 1 + sum((raw_count(x) for x in t[1:]))

def main():
    result = {'status': 'PASS', 'convention': __doc__.strip(), 'variants': {}}
    if not (size(structure53()) == 53 and size(structure50()) == 50):
        raise AssertionError('validation condition failed')
    for projection, omit_selectors in ((False, False), (True, False), (False, True), (True, True)):
        key = 'projection_normalized_source' if projection else 'unchanged_source'
        parts = source_parts(projection)
        if omit_selectors:
            key += '_selectors_derived'
            parts = {k: t for k, t in parts.items() if not k.endswith('selector')}
        C = conj(*parts.values())
        seed = exists(['z', 'a', 'k'], C)
        Cgraph = translate(C, projection)
        seedgraph = sink_guard(translate(seed, projection))
        test_theta = forall(['x'], eq('x', 'x'))
        translated_scheme = sink_guard(translate(forall(['z', 'a', 'k'], imp(C, test_theta)), projection))
        c = size(C)
        r = nodes(C, 'R')
        q = nodes(C, 'forall') + nodes(C, 'exists')
        if not size(Cgraph) == c + 16 * r + 4 * q:
            raise AssertionError('validation condition failed')
        overhead = size(translated_scheme) - size(translate(test_theta, projection))
        result['variants'][key] = {'C_parts': {k: size(t) for k, t in parts.items()}, 'C': c, 'C_relation_occurrences': r, 'C_quantifiers': q, 'closed_source_seed': size(seed), 'graph_translated_C': size(Cgraph), 'sink_guarded_graph_source_seed': size(seedgraph), 'graph_guarded_arithmetic_scheme_overhead_beyond_translated_theta': overhead, 'structure53_plus_fixed_source_seed_sum': 53 + size(seedgraph), 'single_conjunction_of_structure53_and_fixed_source_seed': size(conj(structure53(), seedgraph)), 'structure50_plus_fixed_source_seed_sum': 50 + size(seedgraph), 'single_conjunction_of_structure50_and_fixed_source_seed': size(conj(structure50(), seedgraph))}
        (HERE / f'independent_{key}_C.sexp').write_text(sexpr(C) + '\n')
        (HERE / f'independent_{key}_graph_seed.sexp').write_text(sexpr(seedgraph) + '\n')
    paths = [REL / 'sink53.sexp', REL / 'sink50.sexp', (HERE / 'sink90_baseline.sexp' if (HERE / 'sink90_baseline.sexp').is_file() else OLD / 'artifacts' / 'sink_structure_expanded.sexp')]
    result['independently_parsed_candidate_structure_sizes'] = {str(p): {'nodes': raw_count(parse(p.read_text())), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths}
    result['finite_seed_comparison'] = {'old90_plus_old_source': 90 + result['variants']['unchanged_source']['sink_guarded_graph_source_seed'], 'new53_plus_old_source': 53 + result['variants']['unchanged_source']['sink_guarded_graph_source_seed'], 'new53_plus_projection_source': 53 + result['variants']['projection_normalized_source']['sink_guarded_graph_source_seed'], 'new50_plus_old_source': 50 + result['variants']['unchanged_source']['sink_guarded_graph_source_seed'], 'new50_plus_projection_source': 50 + result['variants']['projection_normalized_source']['sink_guarded_graph_source_seed'], 'new50_plus_old_relation_derived_selectors': 50 + result['variants']['unchanged_source_selectors_derived']['sink_guarded_graph_source_seed'], 'new50_plus_projection_relation_derived_selectors': 50 + result['variants']['projection_normalized_source_selectors_derived']['sink_guarded_graph_source_seed'], 'old90_to_new53_unchanged_source_saving': 37, 'old90_to_new53_normalized_source_saving': 53, 'normalized_saving_per_guarded_arithmetic_axiom': 16, 'selector_omission_source_C_saving': 67, 'selector_omission_translated_seed_and_each_scheme_saving': 191, 'unfactored_selector_free_finite_seed_saving_from_old661': 247, 'unfactored_selector_free_each_guarded_arithmetic_axiom_saving_from_old': 207, 'sum_is_for_two_axioms_add_one_if_conjoined': True, 'infinite_arithmetic_scheme_still_required': True, 'reverse_interpretation_formulas_not_counted_as_axioms_or_free': True}
    result['general_scheme_formula'] = {'theta_relation_only_size': 'N', 'theta_relation_occurrences': 'r', 'theta_quantifiers': 'q', 'theta_graph_translation': 'N + 16 r + 4 q', 'unchanged_source_complete_guarded_graph_axiom': 'N + 16 r + 4 q + 572', 'projection_source_complete_guarded_graph_axiom': 'N + 16 r + 4 q + 556', 'old_relation_derived_selectors_complete_guarded_graph_axiom': 'N + 16 r + 4 q + 381', 'projection_relation_derived_selectors_complete_guarded_graph_axiom': 'N + 16 r + 4 q + 365'}
    result['fully_factored_variants'] = {}
    for projection in (False, True):
        key = 'projection_C71' if projection else 'old_relation_C79'
        C = factored_C(projection)
        seed = sink_guard(translate(exists(['z', 'a', 'k'], C), projection))
        overhead = size(sink_guard(translate(forall(['z', 'a', 'k'], imp(C, eq('x', 'x'))), projection))) - 3
        result['fully_factored_variants'][key] = {'source_C': size(C), 'R_occurrences': nodes(C, 'R'), 'quantifiers': nodes(C, 'forall') + nodes(C, 'exists'), 'graph_C': size(translate(C, projection)), 'graph_seed': size(seed), 'fixed_seed_plus_structure50': 50 + size(seed), 'scheme_overhead': overhead}
        (HERE / f'independent_{key}.sexp').write_text(sexpr(C) + '\n')
    C = factored_C(False)
    G = short_old_source_guard()
    source_seed = exists(['z', 'a', 'k'], conj(C, G))
    graph_seed = sink_guard(translate(source_seed, False))
    test = eq('x', 'x')
    scheme = sink_guard(translate(forall(['z', 'a', 'k'], imp(G, test)), False))
    result['short_guard_old_relation_C79_G12'] = {'source_C': size(C), 'source_G': size(G), 'graph_C': size(translate(C, False)), 'graph_G': size(translate(G, False)), 'source_seed_exists_C_and_G': size(source_seed), 'graph_seed': size(graph_seed), 'fixed_seed_plus_structure50': 50 + size(graph_seed), 'conjoined_fixed_seed': 51 + size(graph_seed), 'scheme_overhead': size(scheme) - size(test), 'fixed_seed_saving_from_old661': 661 - (50 + size(graph_seed)), 'per_arithmetic_axiom_saving_from_old572': 572 - (size(scheme) - size(test)), 'source_relation_definition_remains_unchanged': True, 'source_theory_axiom_presentation_is_changed': True, 'canonical_G_uniqueness_used_for_reverse_interpretation': True}
    for name, t in (('G12', G), ('C79_G12_source_seed', source_seed), ('C79_G12_graph_seed', graph_seed)):
        (HERE / f'independent_{name}.sexp').write_text(sexpr(t) + '\n')
    result['general_scheme_formula'].update({'factored_old_C79_guard': 'N + 16 r + 4 q + 239', 'factored_projection_C71_guard': 'N + 16 r + 4 q + 231', 'factored_old_C79_G12_short_guard': 'N + 16 r + 4 q + 72'})
    (HERE / 'independent_sink53_ledger.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
if __name__ == '__main__':
    main()
