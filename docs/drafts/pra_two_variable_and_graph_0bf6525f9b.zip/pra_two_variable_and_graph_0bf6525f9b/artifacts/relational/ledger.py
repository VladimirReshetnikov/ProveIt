"""Fully expanded first-order AST ledger, distinct from PRA display-node ledger.
Quantifier contributes one node (bound name is a label); every variable
occurrence, relation/equality, binary connective, and falsity contributes one.
Negation=A->bottom; iff=(A->B)&(B->A); exists! is expanded.
No abbreviation definitions are left as free nodes.
"""
from functools import reduce
import json, pathlib
V = lambda x: ('var', x)
BOT = ('false',)

def E(x, y):
    return ('E', V(x), V(y))

def eq(x, y):
    return ('=', V(x), V(y))

def imp(a, b):
    return ('imp', a, b)

def neg(a):
    return imp(a, BOT)

def AND(*xs):
    return reduce(lambda a, b: ('and', a, b), xs)

def OR(*xs):
    return reduce(lambda a, b: ('or', a, b), xs)

def iff(a, b):
    return AND(imp(a, b), imp(b, a))

def FA(x, f):
    return ('forall', x, f)

def EX(x, f):
    return ('exists', x, f)

def ALL(vs, f):
    return reduce(lambda f, x: FA(x, f), reversed(vs), f)

def SOME(vs, f):
    return reduce(lambda f, x: EX(x, f), reversed(vs), f)

def unique(x, y, f):
    return EX(x, AND(f(x), FA(y, imp(f(y), eq(y, x)))))

def count(t):
    if t[0] in ['var', 'false']:
        return 1
    if t[0] in ['forall', 'exists']:
        return 1 + count(t[2])
    return 1 + sum(map(count, t[1:]))
