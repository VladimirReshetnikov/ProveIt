"""Reproduce relational ledgers/diagnostics in isolated local-only workspaces.

Plain -O runs are execution checks, not assertion checks. Additional hardened
copies replace every ast.Assert by equivalent explicit if/raise before BOTH
normal and -O runs, ensuring optimized validation executes every check.
Nothing is downloaded; original research and package files are not edited.
"""
import argparse, ast, concurrent.futures, hashlib, json, pathlib, shutil, subprocess, sys, tempfile, time
HERE = pathlib.Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--relational', type=pathlib.Path, default=HERE if (HERE / 'sink53.py').exists() else HERE.parent / 'research' / 'relational')
p.add_argument('--ledger', type=pathlib.Path, default=HERE / 'independent_sink53_ledger.py')
p.add_argument('--baseline', type=pathlib.Path, default=HERE / 'sink90_baseline.sexp')
p.add_argument('--output', type=pathlib.Path, default=HERE / 'final_relational_validation')
a = p.parse_args()
a.output.parent.mkdir(parents=True, exist_ok=True)
SCRIPTS = ['generate_relational.py', 'source_factoring.py', 'check_sink53.py', 'check_sink50_kripke.py', 'check_sink82.py']
MODES = [('plain_normal', False, False), ('plain_optimized', True, False), ('checked_normal', False, True), ('checked_optimized', True, True)]

class Harden(ast.NodeTransformer):

    def visit_Assert(self, node):
        self.generic_visit(node)
        msg = node.msg or ast.Constant('validation condition failed')
        return ast.copy_location(ast.If(ast.UnaryOp(ast.Not(), node.test), [ast.Raise(ast.Call(ast.Name('AssertionError', ast.Load()), [msg], []), None)], []), node)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check(ok, msg):
    if not ok:
        raise RuntimeError(msg)
inputs = {str(f.resolve()): digest(f) for f in sorted(a.relational.glob('*.py'))}
inputs.update({str(a.ledger.resolve()): digest(a.ledger), str(a.baseline.resolve()): digest(a.baseline)})

def run_mode(mode):
    label, opt, harden = mode
    start = time.monotonic()
    with tempfile.TemporaryDirectory(prefix='relational_validation_') as td:
        root = pathlib.Path(td)
        rel = root / 'pra_round6' / 'research' / 'relational'
        review = root / 'pra_round6' / 'review'
        shutil.copytree(a.relational, rel, ignore=shutil.ignore_patterns('__pycache__'))
        review.mkdir(parents=True)
        shutil.copy2(a.ledger, review / 'independent_sink53_ledger.py')
        old = root / 'pra_round5' / 'package' / 'artifacts'
        old.mkdir(parents=True)
        shutil.copy2(a.baseline, old / 'sink_structure_expanded.sexp')
        asserts = 0
        for source in [*rel.glob('*.py'), review / 'independent_sink53_ledger.py']:
            tree = ast.parse(source.read_text())
            asserts += sum((isinstance(n, ast.Assert) for n in ast.walk(tree)))
            if harden:
                source.write_text(ast.unparse(ast.fix_missing_locations(Harden().visit(tree))) + '\n')
        commands = []
        for script in [*(rel / x for x in SCRIPTS), review / 'independent_sink53_ledger.py']:
            cmd = [sys.executable, *(['-O'] if opt else []), str(script)]
            cp = subprocess.run(cmd, cwd=root, capture_output=True, text=True, timeout=300)
            out = cp.stdout.replace(td, '$WORKSPACE')
            err = cp.stderr.replace(td, '$WORKSPACE')
            check(cp.returncode == 0, f'{label}: {script.name} failed: {err}\n{out}')
            commands.append({'script': script.name, 'python_optimized': opt, 'returncode': cp.returncode, 'stdout_sha256': hashlib.sha256(out.encode()).hexdigest(), 'stderr': err})
        results = {}
        for name in ['all_relational_metrics.json', 'source_factoring_metrics.json', 'sink53_checks.json', 'sink50_kripke_checks.json', 'sink82_checks.json']:
            results[name] = json.loads((rel / name).read_text())
        ledger = json.loads((review / 'independent_sink53_ledger.json').read_text().replace(td, '$WORKSPACE'))
        results['independent_sink53_ledger.json'] = ledger
        check(results['all_relational_metrics.json']['sink50'] == 50, 'wrong graph50 count')
        check(ledger['short_guard_old_relation_C79_G12']['fixed_seed_plus_structure50'] == 337, 'wrong complete seed')
        check(ledger['short_guard_old_relation_C79_G12']['scheme_overhead'] == 72, 'wrong short-guard overhead')
        check(results['sink53_checks.json']['all_graph_marker_pairs_through_4_vertices'] == 263714, 'wrong graph coverage')
        check(results['sink50_kripke_checks.json']['constant_domain_Kripke_models_and_markers'] == 10628, 'wrong Kripke coverage')
        for f in ['sink53_checks.json', 'sink50_kripke_checks.json', 'sink82_checks.json']:
            check(results[f]['status'] == 'PASS', f'{label}: {f} not PASS')
        artifacts = {str(f.relative_to(root)): digest(f) for f in [*rel.glob('*.sexp'), *review.glob('*.sexp')]}
        return {'mode': label, 'optimized': opt, 'hardened_assertions': harden, 'assert_statements_found': asserts, 'commands': commands, 'results': results, 'artifact_hashes': artifacts, 'elapsed_seconds': round(time.monotonic() - start, 3)}
started = time.monotonic()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
    runs = list(ex.map(run_mode, MODES))
base = runs[0]
for r in runs[1:]:
    check(r['results'] == base['results'], f"JSON results differ in {r['mode']}")
    check(r['artifact_hashes'] == base['artifact_hashes'], f"AST artifact hashes differ in {r['mode']}")
result = {'status': 'PASS', 'inputs_sha256': inputs, 'modes': runs, 'all_modes_identical_json_results': True, 'all_modes_identical_sexp_hashes': True, 'no_downloaded_code': True, 'original_files_unmodified': True, 'elapsed_seconds': round(time.monotonic() - started, 3), 'gaps': [('Plain python -O suppresses original source assert statements; hardened runs preserve them explicitly.' if runs[0]['assert_statements_found'] else 'Delivered Python files contain zero assert statements; all validation checks remain active under python -O.'), 'Finite graph and constant-domain Kripke diagnostics are not formal proofs or completeness certificates.', 'Finite Latin-square package models are not models of PRA.']}
a.output.with_suffix('.json').write_text(json.dumps(result, indent=2) + '\n')
g = base['results']['sink53_checks.json']
k = base['results']['sink50_kripke_checks.json']
q = base['results']['independent_sink53_ledger.json']['short_guard_old_relation_C79_G12']
lines = ['FINAL RELATIONAL VALIDATION: PASS', f'Python: {sys.version.split()[0]}', f"Elapsed seconds: {result['elapsed_seconds']}", f'Runs: 4 modes x 6 scripts = 24 successful processes', f'Modes: plain normal; plain python -O; assertion-hardened normal; assertion-hardened python -O', f"Assert statements detected and mechanically preserved in hardened copies: {runs[0]['assert_statements_found']}", f'JSON results identical in all four modes: True', f'All regenerated S-expression hashes identical in all four modes: True', '', f'Closed graph structure: 50; decoder: 21', f"Source C: {q['source_C']}; source G: {q['source_G']}; translated C: {q['graph_C']}; translated G: {q['graph_G']}", f"Sink-guarded source seed: {q['graph_seed']}; fixed two-axiom sum: {q['fixed_seed_plus_structure50']}; conjoined: {q['conjoined_fixed_seed']}", f"Per arithmetic axiom: N + 16 r + 4 q + {q['scheme_overhead']}", f"Finite graph/marker cases through four vertices: {g['all_graph_marker_pairs_through_4_vertices']}", f"Exact AST comparison cases (50/51/53): {g['exact_AST_checks']}", f"Two-object cyclic-addition/free-tag datasets with both roundtrips: {g['two_object_Latin_square_plus_all_free_tag_relations_both_roundtrips']}", f"Single-edge mutations: {g['single_edge_mutations_of_those_graphs']}", f'Phantom pair/two-sink negative control: verified', f"Kripke cases for shared-binder implications: {k['constant_domain_Kripke_models_and_markers']}", 'Source-independent 82/85 diagnostics also PASS: 263714 finite cases; 10628 Kripke cases.', '', 'GAPS / SCOPE', *('- ' + s for s in result['gaps']), '', 'No downloaded code executed. Original files not edited. Input hashes and full process/mode evidence are in the adjacent JSON.', 'Portable invocation: python validate_relational_portable.py --relational PATH --ledger independent_sink53_ledger.py --baseline sink90_baseline.sexp --output final_relational_validation']
a.output.with_suffix('.txt').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines), flush=True)
