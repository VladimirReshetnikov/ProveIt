"""Self-contained diagnostic helpers; finite checks do not replace proof."""
import itertools
from functools import lru_cache
from sink82 import *

def require(p):
    if not p:
        raise AssertionError()

def ordinary(V, E, m):
    O = {x for x in V if (x, m) in E}
    P = {x for x in V if x != m and (x, m) not in E}
    return all(((m, x) not in E for x in V)) and all((x == m or x in O or x in P for x in V)) and (not any(((a, b) in E for a in O for b in O))) and all((sum(((a, p) in E for a in O)) == 1 and sum(((p, b) in E for b in O)) == 1 for p in P)) and all((sum(((a, p) in E and (p, b) in E for p in P)) == 1 for a in O for b in O))

def ast_eval(t, V, E, env):
    op = t[0]
    if op == 'var':
        return env[t[1]]
    if op == 'false':
        return False
    if op == 'E':
        return (ast_eval(t[1], V, E, env), ast_eval(t[2], V, E, env)) in E
    if op == '=':
        return ast_eval(t[1], V, E, env) == ast_eval(t[2], V, E, env)
    if op == 'and':
        return ast_eval(t[1], V, E, env) and ast_eval(t[2], V, E, env)
    if op == 'or':
        return ast_eval(t[1], V, E, env) or ast_eval(t[2], V, E, env)
    if op == 'imp':
        return not ast_eval(t[1], V, E, env) or ast_eval(t[2], V, E, env)
    if op in ['forall', 'exists']:
        f = all if op == 'forall' else any
        return f((ast_eval(t[2], V, E, {**env, t[1]: x}) for x in V))
    raise ValueError(op)

def encode(objects, relation):
    from itertools import product
    objects = tuple(objects)
    m = ('marker',)
    oo = {a: ('object', a) for a in objects}
    pp = {(a, b): ('pair', a, b) for a, b in product(objects, repeat=2)}
    V = {m} | set(oo.values()) | set(pp.values())
    EE = {(o, m) for o in oo.values()}
    for (a, b), p in pp.items():
        EE |= {(oo[a], p), (p, oo[b])}
    EE |= {(pp[a, b], pp[c, d]) for a, b, c, d in relation}
    return (V, EE)

def roundtrip(V, E, m):
    require(ordinary(V, E, m))
    O = {x for x in V if (x, m) in E}
    P = V - O - {m}
    require({v for v in V if all(((v, w) not in E for w in V))} == {m})
    coords = {p: (next((a for a in O if (a, p) in E)), next((b for b in O if (p, b) in E))) for p in P}
    R = {(a, b, c, d) for a, b, c, d in itertools.product(O, repeat=4) if any(((a, p) in E and (p, b) in E and ((c, q) in E) and ((q, d) in E) and ((p, q) in E) for p in V for q in V))}
    VV, EE = encode(O, R)
    f = {m: ('marker',), **{a: ('object', a) for a in O}, **{p: ('pair', *coords[p]) for p in P}}
    require(len(set(f.values())) == len(V) and set(f.values()) == VV)
    require({(f[a], f[b]) for a, b in E} == EE)
    return R

def ordinary_AST():
    P = lambda x: AND(neg(eq(x, 'm')), neg(O(x)))
    return AND(FA('x', neg(E('m', 'x'))), FA('x', OR(eq('x', 'm'), O('x'), P('x'))), ALL(['x', 'y'], imp(AND(O('x'), O('y')), neg(E('x', 'y')))), FA('x', imp(P('x'), unique('a', 'a1', lambda a: AND(O(a), E(a, 'x'))))), FA('x', imp(P('x'), unique('b', 'b1', lambda b: AND(O(b), E('x', b))))), ALL(['a', 'b'], imp(AND(O('a'), O('b')), unique('p', 'p1', lambda p: AND(P(p), E('a', p), E(p, 'b'))))))

def evaluate(formulas, n, world_edges, future, m):

    @lru_cache(None)
    def ev(t, w, env):
        op = t[0]
        d = dict(env)
        if op == 'var':
            return d[t[1]]
        if op == 'false':
            return False
        if op == 'E':
            return (d[t[1][1]], d[t[2][1]]) in world_edges[w]
        if op == '=':
            return d[t[1][1]] == d[t[2][1]]
        if op == 'and':
            return ev(t[1], w, env) and ev(t[2], w, env)
        if op == 'or':
            return ev(t[1], w, env) or ev(t[2], w, env)
        if op == 'imp':
            return all((not ev(t[1], v, env) or ev(t[2], v, env) for v in future[w]))
        if op == 'exists':
            return any((ev(t[2], w, tuple(sorted({**d, t[1]: x}.items()))) for x in range(n)))
        if op == 'forall':
            return all((ev(t[2], v, tuple(sorted({**d, t[1]: x}.items()))) for v in future[w] for x in range(n)))
        raise ValueError(op)
    return [ev(t, 0, (('m', m),)) for t in formulas]
