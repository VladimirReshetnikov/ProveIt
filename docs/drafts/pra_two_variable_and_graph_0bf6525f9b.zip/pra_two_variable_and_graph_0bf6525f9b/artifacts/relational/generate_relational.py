from sink53 import *
from sink82 import J81
here = pathlib.Path(__file__).parent
out = {}
for n, t in [(50, J50()), (51, J51()), (53, J53()), (62, J62()), (81, J81()), (82, J()), (85, J85())]:
    if not count(t) == n:
        raise AssertionError('validation condition failed')
    (here / f'sink{n}.sexp').write_text(sexpr(t) + '\n')
    out[f'sink{n}'] = count(t)
(here / 'all_relational_metrics.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
