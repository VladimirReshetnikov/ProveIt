RELATIONAL RESEARCH, ROUND 6

Main graph result: sink53_unchanged_source.tex + sink50_refinement.tex.
The inherited source relation is unchanged; regroup operands vs tag/output.
Source addition totality supplies pair existence, separate cancellation
supplies coordinate uniqueness, and a pair-test justifies the final
intuitionistic shared-universal normal form. Structure90 ->50, decoder21.

Full source improvements: source_reconstruction_factoring.tex.
Selector clauses can be bootstrapped only with the explicit canonical-
witness lemma in BOTH directions. Old relation C79 gives complete fixed
seed288. Optional projection-normalized relation C71 gives fixed seed280.
source_projection_and_sink53.tex contains the full normalization definition,
selectors, and identity roundtrips, but its53-node and16-node comparisons
are intermediate; use the50/71 factoring files for final metrics.
Independent source/graph audit and expanded translated ASTs are under
../../review (owned by the separate audit agent).

Backup: sink82_proof.tex gives a source-independent structure82 readable,
81 shared-universal. The earlier85 variant remains valid but dominated.

Regeneration (all now self-contained within this folder):
 python generate_relational.py
 python source_factoring.py
 python check_sink53.py
 python check_sink50_kripke.py
 python check_sink82.py

Finite checks are diagnostics, not formal proofs. The Latin-square package
models in check_sink53.py are NOT finite models of PRA. The Kripke checks
supplement the explicit intuitionistic derivations. No global optimality
claim and no finite axiomatizability claim is made.

DELIVERY VALIDATION NOTE
All delivered Python files were mechanically hardened to use explicit
if/raise checks rather than assert, with hashes in HARDENING_PROVENANCE.json.
The independent source ledger and sink90 baseline are adjacent in this
folder, so no prior package is required. See RUN_VALIDATION.txt for the
portable validation command.
