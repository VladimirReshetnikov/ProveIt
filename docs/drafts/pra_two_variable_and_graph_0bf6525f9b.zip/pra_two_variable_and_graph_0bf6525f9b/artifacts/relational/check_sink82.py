import sys, pathlib, itertools, json, random
HERE = pathlib.Path(__file__).resolve().parent
from diagnostic_helpers import ordinary, roundtrip, ast_eval, ordinary_AST, evaluate, encode
from sink82 import J, J85

def optimized(V, E, m):
    O = {x for x in V if (x, m) in E}
    if any(((m, x) in E for x in V)):
        return False
    if any(((x, y) in E or not any(((x, p) in E and (p, y) in E for p in V)) for x in O for y in O)):
        return False
    return all((x == m or x in O or any((all((((a, p) not in E or (p, b) not in E or p == x) and (p not in O or (((p, x) not in E or p == a) and ((x, p) not in E or p == b))) for p in V)) for a in O for b in O)) for x in V))
nchecked = accepted = astchecks = 0
for n in range(1, 5):
    V = set(range(n))
    edges = list(itertools.product(V, repeat=2))
    for bits in range(1 << len(edges)):
        EE = {e for i, e in enumerate(edges) if bits >> i & 1}
        for m in V:
            got = optimized(V, EE, m)
            want = ordinary(V, EE, m)
            if not got == want:
                raise AssertionError((n, bits, m, got, want))
            nchecked += 1
            accepted += want
            if want:
                roundtrip(V, EE, m)
            if want or bits % 503 == 0:
                if not ast_eval(J()[2], V, EE, {'m': m}) == want:
                    raise AssertionError('validation condition failed')
                if not ast_eval(J85()[2], V, EE, {'m': m}) == want:
                    raise AssertionError('validation condition failed')
                astchecks += 1
print('finite', nchecked, accepted, astchecks, flush=True)
frames = [('chain', {0: (0, 1), 1: (1,)}, [(), (1,), (0, 1)]), ('fork', {0: (0, 1, 2), 1: (1,), 2: (2,)}, [(), (1,), (2,), (1, 2), (0, 1, 2)])]
kripke = 0
rng = random.Random(20261101)
for name, future, patterns in frames:
    for n in (1, 2, 3):
        edges = list(itertools.product(range(n), repeat=2))
        valuations = itertools.product(range(len(patterns)), repeat=len(edges)) if n < 3 else (tuple((rng.randrange(len(patterns)) for _ in edges)) for _ in range(1500))
        for val in valuations:
            world_edges = {w: set() for w in future}
            for e, p in zip(edges, val):
                for w in patterns[p]:
                    world_edges[w].add(e)
            for m in range(n):
                values = evaluate([ordinary_AST(), J()[2], J85()[2]], n, world_edges, future, m)
                if not len(set(values)) == 1:
                    raise AssertionError((name, n, val, m, values))
                kripke += 1
    for nobj, reps in [(1, len(patterns)), (2, 100)]:
        rows = list(itertools.product(range(nobj), repeat=4))
        for i in range(reps):
            val = [i] if nobj == 1 else [rng.randrange(len(patterns)) for _ in rows]
            WE = {}
            labels = None
            for w in future:
                R = {row for row, p in zip(rows, val) if w in patterns[p]}
                V, EE = encode(range(nobj), R)
                if labels is None:
                    labels = {v: j for j, v in enumerate(sorted(V, key=repr))}
                WE[w] = {(labels[a], labels[b]) for a, b in EE}
            values = evaluate([ordinary_AST(), J()[2], J85()[2]], len(labels), WE, future, labels['marker',])
            if not all(values):
                raise AssertionError((name, nobj, val, values))
            kripke += 1
result = {'status': 'PASS', 'all_graph_marker_pairs_through_4_vertices': nchecked, 'accepted_graph_marker_pairs': accepted, 'exact_AST_cross_checks': astchecks, 'constant_domain_Kripke_models_and_markers': kripke, 'formulas_compared': 'ordinary six-clause sink structure, 82-node readable, 85-node shared-universal', 'proof_not_replaced_by_finite_diagnostics': True}
(HERE / 'sink82_checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
