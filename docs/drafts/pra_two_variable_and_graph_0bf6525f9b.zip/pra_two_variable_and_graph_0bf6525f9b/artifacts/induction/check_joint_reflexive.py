#!/usr/bin/env python3
"""Authored reproducible diagnostics for the NI1/JNI1 synthesis.

Standard library only. No downloaded source is executed. All checks are
always-active exceptions (not Python assert), so python -O does not disable
them. Finite arithmetic tests are diagnostics, not arbitrary-model proofs.
"""
from __future__ import annotations

import json
import random
import sys
from pathlib import Path


class CheckFailure(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise CheckFailure(message)


# Tuples encode syntax. Names and quantifier binders are metadata, not nodes.
# 'meta' is used ONLY for formula-placeholder ledgers, never actual admission.
def var(name): return ("var", name)
def const(name): return ("const", name)
def app(name, *args): return ("app", name, tuple(args))
def eq(left, right): return ("eq", left, right)
def bot(): return ("bot",)
def conj(left, right): return ("and", left, right)
def disj(left, right): return ("or", left, right)
def imp(left, right): return ("imp", left, right)
def all_(name, body): return ("forall", name, body)
def meta(name, *args): return ("meta", name, tuple(args))


def size(tree):
    kind = tree[0]
    if kind in ("var", "const", "bot"):
        return 1
    if kind in ("app", "meta"):
        return 1 + sum(size(arg) for arg in tree[2])
    if kind in ("eq", "and", "or", "imp"):
        return 1 + size(tree[1]) + size(tree[2])
    if kind == "forall":
        return 1 + size(tree[2])
    raise CheckFailure(f"unknown AST node: {kind}")


def fv(tree):
    kind = tree[0]
    if kind == "var": return {tree[1]}
    if kind in ("const", "bot"): return set()
    if kind in ("app", "meta"):
        return set().union(*(fv(arg) for arg in tree[2]))
    if kind in ("eq", "and", "or", "imp"):
        return fv(tree[1]) | fv(tree[2])
    if kind == "forall": return fv(tree[2]) - {tree[1]}
    raise CheckFailure(f"unknown AST node: {kind}")


def subst(tree, name, replacement):
    """Literal substitution on QF formula/term syntax, no arithmetic rewrite."""
    kind = tree[0]
    if kind == "var": return replacement if tree[1] == name else tree
    if kind in ("const", "bot"): return tree
    if kind in ("app", "meta"):
        return (kind, tree[1], tuple(subst(x, name, replacement) for x in tree[2]))
    if kind in ("eq", "and", "or", "imp"):
        return (kind, subst(tree[1], name, replacement), subst(tree[2], name, replacement))
    raise CheckFailure("substitution test is restricted to quantifier-free syntax")


def is_term(tree):
    return tree[0] in ("var", "const") or (
        tree[0] == "app" and all(is_term(x) for x in tree[2]))


def is_qf(tree):
    kind = tree[0]
    if kind == "bot": return True
    if kind == "eq": return is_term(tree[1]) and is_term(tree[2])
    if kind in ("and", "or", "imp"):
        return is_qf(tree[1]) and is_qf(tree[2])
    return False


ZERO = const("0")
N, A = var("n"), var("a")
S = lambda t: app("S", t)
R = lambda x, y: app("R_h", x, y)
H = lambda x, y: app("h", x, y)


def admitted(tree):
    if not is_qf(tree) or not fv(tree) <= {"n", "a"}:
        return False
    at_zero = subst(tree, "n", ZERO)
    return at_zero[0] == "imp" and at_zero[1] == at_zero[2]


def normalize(tree):
    require(is_qf(tree), "normalization input is not QF")
    return imp(subst(tree, "n", ZERO), tree)


def ledger_checks():
    d0 = eq(R(ZERO, A), A)
    ds = eq(R(S(N), A), H(N, R(N, A)))
    sep = imp(eq(ZERO, S(ZERO)), bot())
    a_n = meta("A", N, A)
    a_sn = meta("A", S(N), A)
    progress = all_("n", imp(a_n, a_sn))
    ni = all_("a", imp(progress, all_("n", a_n)))
    r0 = all_("a", d0)
    rs = all_("n", all_("a", ds))
    jni = all_("a", imp(progress, all_("n", conj(a_n, conj(d0, ds)))))
    fused = all_("a", imp(conj(disj(meta("A", ZERO, A), eq(ZERO, S(ZERO))),
                                progress), all_("n", a_n)))
    counts = {
        "zero_equation_unquantified": size(d0),
        "step_equation_unquantified": size(ds),
        "zero_equation_closed": size(r0),
        "step_equation_closed": size(rs),
        "separation": size(sep),
        "NI1_closed": size(ni),
        "JNI1_closed": size(jni),
        "separate_NI1_total": size(r0) + size(rs) + size(sep) + size(ni),
        "joint_JNI1_total": size(sep) + size(jni),
        "fused_one_parameter_total": size(r0) + size(rs) + size(fused),
    }
    expected = {
        "zero_equation_unquantified": 5, "step_equation_unquantified": 10,
        "zero_equation_closed": 6, "step_equation_closed": 12,
        "separation": 6, "NI1_closed": 15, "JNI1_closed": 32,
        "separate_NI1_total": 39, "joint_JNI1_total": 38,
        "fused_one_parameter_total": 42,
    }
    require(counts == expected, f"ledger mismatch: {counts}")
    require(fv(ni) == fv(jni) == set(), "closed template has free variables")
    # Independently reconstruct the share-binders calculation.
    require(counts["separate_NI1_total"] - 3 + 2 == counts["joint_JNI1_total"],
            "binder-sharing identity failed")
    require(size(jni) == size(ni) + size(d0) + size(ds) + 2,
            "conclusion-adjoining count failed")
    arity_rows = []
    for q in range(6):
        params = tuple(var(f"c{i}") for i in range(q))
        aq = meta("A", N, *params)
        asq = meta("A", S(N), *params)
        nq = imp(all_("n", imp(aq, asq)), all_("n", aq))
        for param in reversed(params): nq = all_(param[1], nq)
        total = 18 + 6 + size(nq)
        require(total == 35 + 4 * q, "unrestricted NI arity polynomial failed")
        arity_rows.append({"q": q, "NI_nodes": size(nq), "total": total})
    implicit_rows = []
    implicit_asts = []
    for r in range(5):
        extras = tuple(var(f"c{i}") for i in range(r))
        at_n = meta("A", N, A, *extras)
        at_sn = meta("A", S(N), A, *extras)
        at_0 = meta("A", ZERO, A, *extras)
        at_modified_0 = meta("A", ZERO, R(ZERO, A), *extras)
        step = all_("n", imp(at_n, at_sn))
        t_schema = imp(conj(disj(at_modified_0, eq(ZERO, S(ZERO))), step),
                       all_("n", conj(at_n, ds)))
        old_fused = imp(conj(disj(at_0, eq(ZERO, S(ZERO))), step), all_("n", at_n))
        for parameter in reversed((A,) + extras):
            t_schema = all_(parameter[1], t_schema)
            old_fused = all_(parameter[1], old_fused)
        require(size(t_schema) == 37 + 5 * r, "implicit T arity polynomial failed")
        require(18 + size(old_fused) == 42 + 5 * r, "matched fused arity polynomial failed")
        implicit_rows.append({"extra_parameters_r": r, "total_induction_parameters": 1 + r,
                              "implicit_T_nodes": size(t_schema),
                              "matched_fused_total": 18 + size(old_fused)})
        implicit_asts.append(t_schema)
    return {"counts": counts, "unrestricted_NI_reference_rows": arity_rows,
            "implicit_initialization_reference_rows": implicit_rows,
            "implicit_initialization_exact_AST": implicit_asts,
            "implicit_initialization_scope": "37+5r counts the committed family at matched interfaces. This diagnostic does not prove that its zero-extra-parameter fragment T0 alone recovers arbitrary-seed initialization or PRA.",
            "exact_AST": {"R0": r0, "RS": rs, "Sep": sep, "NI1": ni, "JNI1": jni},
            "metric_scope": "One node per occurrence/application/connective/equality/falsity/quantifier; binder names metadata; binary conjunctions; no shared subtrees. Admission-algorithm length and arbitrary substituted bodies are not counted."}


def gate_checks():
    n, a, c = N, A, var("c")
    terms = [ZERO, n, a, S(n), S(a), R(n, a), R(ZERO, a), H(n, R(n, a))]
    atoms = [bot()] + [eq(x, y) for x in terms for y in terms]
    formulas = list(atoms)
    rng = random.Random(6525)
    operators = (conj, disj, imp)
    # Bounded-depth, reproducible actual formulas, not meta placeholders.
    layer = atoms
    for _ in range(4):
        new_layer = [operators[rng.randrange(3)](rng.choice(layer), rng.choice(atoms))
                     for _ in range(1250)]
        formulas.extend(new_layer)
        layer = new_layer
    normalized_count = 0
    for formula in formulas:
        f0 = subst(formula, "n", ZERO)
        require(subst(f0, "n", ZERO) == f0, "zero substitution is not idempotent")
        normalized = normalize(formula)
        require(admitted(normalized), "normalized matrix rejected")
        require(fv(normalized) <= {"n", "a"}, "normalization introduced a parameter")
        zero_tree = subst(normalized, "n", ZERO)
        require(zero_tree == imp(f0, f0), "normalization failed literal reflexivity")
        normalized_count += 1
    truth = imp(bot(), bot())
    special = [
        ("constant truth", truth, True),
        ("normalized equality", imp(eq(ZERO, a), eq(n, a)), True),
        ("moving antecedent also admitted", imp(eq(n, a), eq(ZERO, a)), True),
        ("plain n=0 rejected", eq(n, ZERO), False),
        ("plain reflexive equality rejected", eq(ZERO, ZERO), False),
        ("falsity rejected", bot(), False),
        ("equality symmetry not syntax identity", imp(eq(n, a), eq(a, n)), False),
        ("foreign parameter rejected", normalize(eq(n, c)), False),
        ("quantified matrix rejected", all_("n", eq(n, n)), False),
        ("formula-placeholder rejected", meta("A", n, a), False),
    ]
    for name, formula, expected in special:
        require(admitted(formula) == expected, f"gate special case failed: {name}")
    opaque_name = "R_description_with_bound_n_and_v"
    opaque = app(opaque_name, n, a)
    opaque_zero = subst(opaque, "n", ZERO)
    require(opaque_zero[1] == opaque_name and opaque_zero[2] == (ZERO, a),
            "substitution changed descriptor internals")
    return {"normalized_formulas_checked": normalized_count,
            "literal_gate_special_cases": len(special),
            "max_formula_AST_size": max(size(x) for x in formulas),
            "normalization_preserves_parameter_bound": True,
            "descriptor_names_opaque_under_substitution": True,
            "scope": "Finite executable tests of the exact syntax test. General substitution/normalization theorem remains the written structural proof."}


# Standard-natural evaluation of the source equations. No intended-model
# test below is offered as a proof about arbitrary or nonstandard models.
def rec(update, counter, seed):
    value = seed
    for k in range(counter): value = update(k, value)
    return value


def p(x): return 0 if x == 0 else x - 1

def z(n, a): return a if n == 0 else 0

def add(x, y): return rec(lambda _k, v: v + 1, y, x)

def d(x, y): return rec(lambda _k, v: p(v), y, x)

def choose(q, a, b): return add(z(q, a), z(z(q, 1), b))

def unit_error(r): return choose(r, 1, choose(p(r), 0, 1))

def equality_error(x, y): return unit_error(d(x + 1, y))


def pairing_checks(bound=40):
    count = {"primitive_equation_checks": 0, "arithmetic_identity_checks": 0,
             "equality_bit_pairs": 0, "residual_pairs": 0,
             "conditional_segments": 0, "triangular_endpoints": 0,
             "pairing_left_inverse_pairs": 0}
    for x in range(bound + 1):
        require(p(x) == rec(lambda k, _v: k, x, 0), "predecessor evaluator mismatch")
        require(p(x + 1) == x and p(0) == 0, "predecessor equations failed")
        count["primitive_equation_checks"] += 2
        for y in range(bound + 1):
            require(z(x, y) == rec(lambda _k, _v: 0, x, y), "Z evaluator mismatch")
            require(add(x, 0) == x and add(x, y + 1) == add(x, y) + 1,
                    "addition equations failed")
            require(d(x, 0) == x and d(x, y + 1) == p(d(x, y)),
                    "subtraction equations failed")
            count["primitive_equation_checks"] += 5
            tests = [add(0, y) == y,
                     add(x + 1, y) == add(x, y) + 1,
                     d(0, y) == 0,
                     d(x + 1, y + 1) == d(x, y),
                     d(add(x, y), x) == y,
                     d(x, add(x, y)) == 0,
                     d(p(x), y) == p(d(x, y))]
            require(all(tests), f"one-parameter arithmetic identity failed at {x},{y}")
            count["arithmetic_identity_checks"] += len(tests)
            residual = choose(d(x, y), x, add(y, d(x, y)))
            require(residual == x, f"guarded residual failed at {x},{y}")
            count["residual_pairs"] += 1
            bit = equality_error(x, y)
            require(bit in (0, 1) and (bit == 0) == (x == y), "equality bit failed")
            require((bit == 1) == (x != y), "equality bit complement failed")
            count["equality_bit_pairs"] += 1
    t_limit = 2 * bound + 2
    triangular = [0]
    for n in range(t_limit): triangular.append(add(triangular[-1], n + 1))
    max_code = add(triangular[2 * bound], bound)
    v_values = [0]
    wrong_values = [0]
    for n in range(max_code):
        v = v_values[-1]
        v_values.append(choose(equality_error(triangular[v + 1], n + 1), v + 1, v))
        w = wrong_values[-1]
        # Negative control: deliberately tests n instead of Sn.
        wrong_values.append(choose(equality_error(triangular[w + 1], n), w + 1, w))
    for t in range(2 * bound + 1):
        require(v_values[triangular[t]] == t, f"endpoint failed at {t}")
        count["triangular_endpoints"] += 1
    for t in range(bound + 1):
        for r in range(bound + 1):
            if d(r, t) == 0:
                require(v_values[add(triangular[t], r)] == t, "segment failed")
                count["conditional_segments"] += 1
    seen = {}
    negative_witness = None
    for x in range(bound + 1):
        for y in range(bound + 1):
            code = add(triangular[add(x, y)], x)
            row = v_values[code]
            left = d(code, triangular[row])
            right = d(row, left)
            require((left, right) == (x, y), f"pair left inverses failed: {x},{y}")
            require(code not in seen or seen[code] == (x, y), "pair collision")
            seen[code] = (x, y)
            count["pairing_left_inverse_pairs"] += 1
            wrong_row = wrong_values[code]
            wl = d(code, triangular[wrong_row])
            wr = d(wrong_row, wl)
            if negative_witness is None and (wl, wr) != (x, y):
                negative_witness = {"x": x, "y": y, "code": code,
                                    "wrong_decoded": [wl, wr]}
    require(negative_witness is not None, "negative control unexpectedly passed")
    return {"input_bound_inclusive": bound, "maximum_tested_code": max_code,
            "counts": count, "distinct_pair_codes": len(seen),
            "negative_control_detected": negative_witness,
            "orientation": "J(x,y)=T(x+y)+x; L(z)=d(z,T(V(z))); P(z)=d(V(z),L(z))",
            "scope": "Standard-natural bounded diagnostics of the written equations, including a deliberately incorrect decoder. Not a proof of arbitrary-model identities, induction admission, compiler correctness, or bi-interpretability."}


def main():
    require(len(sys.argv) <= 2, "usage: check_joint_reflexive.py [output.json]")
    result = {"status": "PASS", "checker": "authored NI1/JNI1 AST, admission, pairing diagnostics",
              "always_active_checks": True, "ledger": ledger_checks(),
              "syntax": gate_checks(), "arithmetic": pairing_checks(),
              "formalization_boundary": "This script does not formalize first-order derivation transport or the arbitrary-model proofs. Those remain the separately audited TeX arguments. No downloaded code is executed."}
    output = json.dumps(result, sort_keys=True, indent=2) + "\n"
    if len(sys.argv) == 2:
        Path(sys.argv[1]).write_text(output, encoding="utf-8")
    sys.stdout.write(output)


if __name__ == "__main__":
    main()
