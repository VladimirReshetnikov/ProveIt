#!/usr/bin/env python3
"""Fresh finite diagnostics for binary_fused.tex (Python standard library only).

All source operations are evaluated from finite syntax by literal binary
initialized recursion R_h(0,a)=a; R_h(n+1,a)=h(n,R_h(n,a)). Prefix caching
shares computations but does not substitute arithmetic formulas for recursors.
Host arithmetic appears only in independent expected-value oracles.

Run: python3 check_binary.py [--output PATH]
Default output: binary_checks.json beside this file; JSON is also printed.
Normal and python -O runs are deterministic. No correctness check uses assert.
These finite standard-N diagnostics do NOT prove the schemas, nonstandard
calibration, source-wide QFI, or the mathematical bi-interpretation theorem.
No downloaded checker or third-party package is imported or executed.
"""
import argparse
import itertools
import json
from collections import Counter
from functools import lru_cache
from pathlib import Path


class CheckFailure(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise CheckFailure(message)


# Source term syntax: zero, variable, successor, binary-description application.
ZERO = ('zero',)
def var(i): return ('var', i)
def succ(t): return ('succ', t)
def app(symbol, n, a): return ('R', symbol, n, a)


def variables(t):
    if t[0] == 'var':
        return {t[1]}
    if t[0] == 'zero':
        return set()
    if t[0] == 'succ':
        return variables(t[1])
    if t[0] == 'R':
        return variables(t[2]) | variables(t[3])
    raise CheckFailure('Unknown term constructor')


def substitute(t, replacements):
    if t[0] == 'var':
        return replacements[t[1]]
    if t[0] == 'zero':
        return t
    if t[0] == 'succ':
        return succ(substitute(t[1], replacements))
    return app(t[1], substitute(t[2], replacements),
               substitute(t[3], replacements))


class Machine:
    """No stored update has inputs other than counter and current value."""
    def __init__(self):
        self.updates = []
        self.names = []
        self.prefixes = {}
        self.steps = 0
        self.max_counter = 0
        self.max_value = 0

    def add(self, name, update):
        require(variables(update) <= {0, 1}, 'Frozen update variable')
        def earlier(t):
            if t[0] == 'R':
                require(0 <= t[1] < len(self.updates), 'Non-earlier description')
                earlier(t[2]); earlier(t[3])
            elif t[0] == 'succ':
                earlier(t[1])
        earlier(update)
        symbol = len(self.updates)
        self.updates.append(update)
        self.names.append(name)
        return symbol

    @lru_cache(maxsize=None)
    def term(self, t, env=()):
        if t[0] == 'zero':
            value = 0
        elif t[0] == 'var':
            value = env[t[1]]
        elif t[0] == 'succ':
            value = self.term(t[1], env) + 1
        elif t[0] == 'R':
            value = self.run(t[1], self.term(t[2], env), self.term(t[3], env))
        else:
            raise CheckFailure('Unknown term constructor')
        require(isinstance(value, int) and value >= 0, 'Invalid natural value')
        self.max_value = max(self.max_value, value)
        return value

    def run(self, symbol, n, a):
        require(0 <= n <= 6000, 'Explicit diagnostic counter bound exceeded')
        self.max_counter = max(self.max_counter, n)
        seq = self.prefixes.setdefault((symbol, a), [a])
        while len(seq) <= n:
            counter = len(seq) - 1
            value = self.term(self.updates[symbol], (counter, seq[-1]))
            seq.append(value)
            self.steps += 1
            require(self.steps <= 3000000, 'Diagnostic step budget exceeded')
        return seq[n]


M = Machine()
U, V = var(0), var(1)
ONE = succ(ZERO)
P_ID = M.add('predecessor', U)
Z_ID = M.add('zero_reset', ZERO)
ADD_ID = M.add('addition', succ(V))
def pred(x): return app(P_ID, x, ZERO)
def reset(n, a): return app(Z_ID, n, a)
def add(x, y): return app(ADD_ID, y, x)
D_ID = M.add('truncated_subtraction', pred(V))
def sub(x, y): return app(D_ID, y, x)
def case(z, a, b): return add(reset(z, a), reset(reset(z, ONE), b))
def unit_bit(r): return case(r, ONE, case(pred(r), ZERO, ONE))
def error_bit(x, y): return unit_bit(sub(succ(x), y))
T_ID = M.add('triangular', add(V, succ(U)))
def triangular(n): return app(T_ID, n, ZERO)
V_ID = M.add('triangular_inverse',
             case(sub(triangular(succ(V)), succ(U)), succ(V), V))
def inverse(n): return app(V_ID, n, ZERO)
def pair(x, y): return add(triangular(add(x, y)), y)
def second(z): return sub(z, triangular(inverse(z)))
def first(z): return sub(inverse(z), second(z))


def code(parameters):
    value = ZERO
    for parameter in parameters:
        value = pair(value, parameter)
    return value


def decode(k, value):
    result = []
    for i in range(k):
        t = value
        for _ in range(k - i - 1):
            t = first(t)
        result.append(second(t))
    return result


def compile_ordinary(name, k, base, update, lose_parameters=False):
    """Return binary symbol and term for F(n,b); interface expressions are ASTs."""
    stored_parameters = first(V)
    new_value = update(U, decode(k, stored_parameters), second(V))
    packed_update = pair(ZERO if lose_parameters else stored_parameters, new_value)
    symbol = M.add(name, packed_update)
    parameters = [var(i + 1) for i in range(k)]
    initial = pair(code(parameters), base(parameters))
    state = app(symbol, U, initial)
    return symbol, state, second(state), initial


def ordinary_reference(n, parameters, base, step):
    value = base(parameters)
    for counter in range(n):
        value = step(counter, parameters, value)
    return value


counts = Counter()

def check(category, condition, message):
    counts[category] += 1
    require(condition, category + ': ' + message)


def evaluate(term, *env):
    return M.term(term, tuple(env))


def main(output):
    # Direct zero/successor equation diagnostics, including arbitrary seeds.
    initial_symbols = len(M.updates)
    for symbol in range(initial_symbols):
        for a in range(7):
            check('literal_recurrence', M.run(symbol, 0, a) == a, 'base')
            for n in range(7):
                check('literal_recurrence',
                      M.run(symbol, n + 1, a) ==
                      M.term(M.updates[symbol], (n, M.run(symbol, n, a))), 'step')

    for x in range(17):
        check('predecessor', evaluate(pred(U), x) == max(x - 1, 0), str(x))
        for y in range(17):
            check('zero_reset', evaluate(reset(U, V), x, y) == (y if x == 0 else 0), 'Z')
            check('addition', evaluate(add(U, V), x, y) == x + y, '+')
            check('subtraction', evaluate(sub(U, V), x, y) == max(x - y, 0), 'd')
            residual = case(sub(U, V), U, add(V, sub(U, V)))
            check('guarded_residual', evaluate(residual, x, y) == x, 'guard')
            check('shifted_equality',
                  (evaluate(sub(succ(U), V), x, y) == 1) == (x == y), 'shift')
            bit = evaluate(error_bit(U, V), x, y)
            check('equality_error_bit', bit in (0, 1) and (bit == 0) == (x == y), 'bit')
    for z, a, b in itertools.product(range(7), repeat=3):
        check('composed_selector',
              evaluate(case(U, V, var(2)), z, a, b) == (a if z == 0 else b), 'C')

    for n in range(97):
        t = evaluate(triangular(U), n)
        v = evaluate(inverse(U), n)
        check('triangular', t == n * (n + 1) // 2, 'T')
        check('triangular_inverse_interval',
              evaluate(triangular(U), v) <= n < evaluate(triangular(U), v + 1), 'V')
        x, y = evaluate(first(U), n), evaluate(second(U), n)
        check('pair_surjectivity', evaluate(pair(U, V), x, y) == n, 'J(pi1,pi2)')
    for x, y in itertools.product(range(9), repeat=2):
        z = evaluate(pair(U, V), x, y)
        check('pair_numeric_formula', z == (x + y) * (x + y + 1) // 2 + y, 'J')
        check('pair_projections',
              evaluate(first(U), z) == x and evaluate(second(U), z) == y, 'pi')

    cases = [
        ('zero_parameters', 0, lambda b: ZERO,
         lambda n, b, v: succ(add(v, n)),
         lambda b: 0, lambda n, b, v: v + n + 1),
        ('one_parameter', 1, lambda b: b[0],
         lambda n, b, v: succ(add(v, b[0])),
         lambda b: b[0], lambda n, b, v: v + b[0] + 1),
        ('two_parameters', 2, lambda b: add(b[0], b[1]),
         lambda n, b, v: case(n, b[1], add(v, b[0])),
         lambda b: b[0] + b[1],
         lambda n, b, v: b[1] if n == 0 else v + b[0]),
    ]
    compiled_records = []
    for name, k, base, update, base_ref, step_ref in cases:
        symbol, state, result, initial = compile_ordinary(name, k, base, update)
        for parameters in itertools.product(range(3), repeat=k):
            expected_code = evaluate(code([var(i) for i in range(k)]), *parameters)
            for n in range(5):
                env = (n,) + parameters
                packed = evaluate(state, *env)
                check('compiler_parameter_invariant',
                      evaluate(first(U), packed) == expected_code, name)
                expected = ordinary_reference(n, parameters, base_ref, step_ref)
                check('ordinary_compiler', evaluate(result, *env) == expected, name)
        compiled_records.append({'name': name, 'parameters': k, 'symbol': symbol,
                                 'counter_range': [0, 4], 'parameter_range': [0, 2]})

    # Source -> ordinary -> packed binary, after earlier terms are identified.
    # The generic compiler stores parameter a even when the update ignores it.
    source_updates = [
        ('source_counter', U), ('source_identity', V),
        ('source_successor', succ(V)), ('source_add_counter', add(V, U)),
        ('source_zero_reset', reset(U, V)),
    ]
    roundtrip_records = []
    for name, body in source_updates:
        original = M.add(name, body)
        update = lambda n, b, v, body=body: substitute(body, {0: n, 1: v})
        symbol, state, result, initial = compile_ordinary(
            name + '_roundtrip', 1, lambda b: b[0], update)
        expected_initial = pair(pair(ZERO, var(1)), var(1))
        check('roundtrip_seed_syntax', initial == expected_initial, name)
        require(variables(M.updates[symbol]) <= {0, 1}, 'Roundtrip seed escaped update')
        for a in range(5):
            expected_code = evaluate(pair(ZERO, U), a)
            for n in range(6):
                packed = evaluate(state, n, a)
                check('source_roundtrip_parameter_invariant',
                      evaluate(first(U), packed) == expected_code, name)
                check('source_roundtrip',
                      evaluate(result, n, a) == M.run(original, n, a), name)
        roundtrip_records.append({'name': name, 'counter_range': [0, 5],
                                  'seed_range': [0, 4],
                                  'initial_seed': 'J(J(0,a),a)'})

    # Active negative controls: incorrect but well-formed implementations fail.
    _, _, bad_result, _ = compile_ordinary(
        'bad_parameter_loss', 1, lambda b: b[0],
        lambda n, b, v: succ(add(v, b[0])), lose_parameters=True)
    wrong_value = evaluate(bad_result, 2, 1)
    correct_value = 5
    check('negative_control', wrong_value != correct_value, 'parameter loss must fail')
    z = evaluate(pair(U, V), 0, 1)
    wrong_projection = evaluate(second(U), z)  # deliberately used as pi1
    check('negative_control', wrong_projection != 0, 'wrong pi1 must fail')

    result = {
        'status': 'passed',
        'scope': 'Finite standard-N diagnostics only; not a formal or nonstandard-model proof.',
        'implementation': 'Fresh standalone literal binary-recursion AST evaluator; prefix memoization.',
        'optimization_safety': 'Always-active require/check functions; no Python assert statements.',
        'bounds': {'elementary_grid': [0, 16], 'selector_cube': [0, 6],
                   'triangular_and_decode_inputs': [0, 96], 'pair_grid': [0, 8],
                   'recursor_counter_safety_cap': 6000, 'literal_step_safety_cap': 3000000},
        'checks_by_category': dict(sorted(counts.items())),
        'total_checks': sum(counts.values()),
        'ordinary_compiler_cases': compiled_records,
        'source_roundtrip_scope': 'Selected one-step source round trips after earlier terms are identified; not a complete recursive description compiler.',
        'source_roundtrip_cases': roundtrip_records,
        'negative_controls': [
            {'name': 'parameter_loss', 'rejected': True, 'n': 2, 'parameters': [1],
             'expected': correct_value, 'wrong_value': wrong_value},
            {'name': 'wrong_first_projection', 'rejected': True, 'pair_inputs': [0, 1],
             'expected': 0, 'wrong_value': wrong_projection}],
        'evaluator': {'descriptions': len(M.updates), 'literal_update_steps': M.steps,
                      'maximum_counter': M.max_counter, 'maximum_value': M.max_value},
    }
    encoded = json.dumps(result, indent=2, sort_keys=True) + '\n'
    output.write_text(encoded, encoding='utf-8')
    print(encoded, end='')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).with_name('binary_checks.json'))
    main(parser.parse_args().output)
