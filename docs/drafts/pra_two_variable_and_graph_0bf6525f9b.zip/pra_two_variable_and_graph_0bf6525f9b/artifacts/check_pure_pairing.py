#!/usr/bin/env python3
# Local authored diagnostic, hardened from research/recursion/check_pure_pairing.py.
# Python asserts replaced mechanically by explicit conditional exceptions;
# no predecessor is synthesized and its existence remains an assumption.
"""Finite diagnostics, not an internal or arbitrary-model proof.
The added predecessor p is explicitly assumed. Every iterator update is unary.
"""
import json
from functools import lru_cache
DESCRIPTIONS = []

def iteration(name, body):
    if not body.__code__.co_argcount == 1:
        raise AssertionError('Conditional pure-iteration diagnostic failed')
    DESCRIPTIONS.append({'name': name, 'update_arity': 1})

    @lru_cache(None)
    def result(n, a):
        if not (n >= 0 and a >= 0):
            raise AssertionError('Conditional pure-iteration diagnostic failed')
        for _ in range(n):
            a = body(a)
        return a
    return result
IS = iteration('successor', lambda v: v + 1)
I0 = iteration('zero', lambda v: 0)
IP = iteration('assumed_predecessor', lambda v: max(v - 1, 0))

def add(x, y):
    return IS(y, x)

def d(x, y):
    return IP(y, x)

def C(z, a, b):
    return add(I0(z, a), I0(I0(z, 1), b))

def e1(x):
    return int(x == 1)
IC = iteration('cycle3', lambda v: C(d(v, 1), v + 1, 0))

def m(n):
    return IC(n, 0)
IG = iteration('half_clock', lambda v: add(v + 1, e1(m(v))))

def G(n):
    return IG(n, 0)

def H(n):
    return d(G(n), n)

def r(n):
    return m(G(n))

def D(n):
    return add(n, n)
ID = iteration('double', lambda v: D(v))

def E(n, a):
    return ID(n, a)
IU = iteration('strip', lambda v: C(r(v), H(v), v))
IW = iteration('strip_then_drift', lambda v: C(r(v), H(v), v + 2))

def U(n):
    return IU(n, n)

def W(n):
    return IW(n, n)

def J(x, y):
    return E(x, D(y) + 1)

def L(z):
    return H(d(add(D(z), U(z)), W(z)))

def R(z):
    return H(U(z))
for n in range(150):
    if not G(n) == n + n // 2:
        raise AssertionError('Conditional pure-iteration diagnostic failed')
    if not (H(n) == n // 2 and r(n) == n % 2):
        raise AssertionError('Conditional pure-iteration diagnostic failed')
for x in range(7):
    for y in range(7):
        z = J(x, y)
        if not (L(z) == x and R(z) == y):
            raise AssertionError('Conditional pure-iteration diagnostic failed')
        if not U(z) == 2 * y + 1:
            raise AssertionError('Conditional pure-iteration diagnostic failed')
        if not W(z) == 2 * y + 1 + 2 * (z - x):
            raise AssertionError('Conditional pure-iteration diagnostic failed')
if not J(L(0), R(0)) != 0:
    raise AssertionError('Conditional pure-iteration diagnostic failed')

def update(z):
    n, value = (L(z), R(z))
    return J(n + 1, add(value, n + 1))
IT = iteration('compiled_triangular', update)
for a in range(3):
    for n in range(5):
        z = IT(n, J(0, a))
        if not (L(z) == n and R(z) == a + n * (n + 1) // 2):
            raise AssertionError('Conditional pure-iteration diagnostic failed')
result = {'status': 'passed', 'assumptions': ['a predecessor operation is explicitly assumed', 'native equality bit supplied after the constructive bootstrap'], 'halving_range': [0, 149], 'pairing_grid': {'x': [0, 6], 'y': [0, 6]}, 'compiler_example': 'F(0,a)=a; F(n+1,a)=F(n,a)+n+1', 'compiler_grid': {'n': [0, 4], 'a': [0, 2]}, 'surjectivity_claimed': False, 'recursor_descriptions': DESCRIPTIONS, 'scope': 'Finite standard-model diagnostics only; no predecessor is synthesized.'}
print(json.dumps(result, indent=2))
