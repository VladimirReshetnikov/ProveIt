import json,pathlib
# Fresh, independent abstract syntax trees. Quantifier binder names are labels.
def N(op,*args):return (op,args)
def V(x):return N(x)
z=V('0');a=V('a');n=V('n');S=lambda t:N('S',t)
E=lambda x,y:N('=',x,y)
Q=lambda x,t:N('forall:'+x,t)
def count(t):return 1+sum(map(count,t[1]))
def closed(xs,t):
 for x in reversed(xs):t=Q(x,t)
 return t
b0=Q('a',E(N('R',z,a),a))
bs=closed(['n','a'],E(N('R',S(n),a),N('h',n,N('R',n,a))))
def formulas(q):
 cs=[V('c'+str(i)) for i in range(q)]
 A=lambda t:N('A',t,*cs)
 eq=lambda t:E(N('s',t,*cs),N('t',t,*cs))
 fi=N('->',N('and',N('or',A(z),E(z,S(z))),Q('n',N('->',A(n),A(S(n))))),Q('n',A(n)))
 ze=N('->',Q('n',N('->',N('or',E(n,z),eq(n)),eq(S(n)))),Q('n',N('or',E(n,z),eq(n))))
 return [closed([c[0] for c in cs],t) for t in (fi,ze)]
sep=N('->',E(z,S(z)),N('false'))
rows=[]
for q in range(9):
 fi,ze=formulas(q);f=count(b0)+count(bs)+count(fi);g=count(b0)+count(bs)+count(sep)+count(ze)
 if not (f==37+5*q and g==53+7*q):
  raise AssertionError("Displayed AST count does not match the claimed profile")
 rows.append({'q':q,'B0':count(b0),'BS':count(bs),'BFI':count(fi),'fused_total':f,'ZE':count(ze),'ZE_total':g})
out={'scope':'Independent displayed-AST count; not a full description encoding.','profiles':rows}
p=pathlib.Path(__file__).with_suffix('.json');p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
