# Trace-resolved union multiplicities

Research note for ProveIt, 25 November 2026.

**Start with `paper.pdf`.** It contains the main theorems, complete proofs, precise novelty qualifications, and an appendix reproducing the inherited recursive estimate.

## Files

- `paper.tex`, `paper.pdf`: manuscript and compiled PDF (10 pages, subject to changes if recompiled).
- `certify.py`, `certificate.txt`: exact rational interval proof of the scalar thresholds and final numerical inequalities; standard-library Python only.
- `audit.py`, `audit.txt`: exact exhaustive tests of the trace majorization and refinement hierarchy on small ground sets, using integers and fractions; not a substitute for the proofs.
- `provenance.md`: source inventory, comparison scope, and limitations.
- `Makefile`: rebuild and re-run checks.
- `SHA256SUMS`: integrity manifest for the included files.

## Reproduction

With Python 3.10+ and a TeX Live installation containing the usual AMS, Latin Modern, microtype and hyperref packages:

```sh
python3 certify.py
python3 audit.py
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
```

Alternatively run `make check` and `make pdf`. The scalar certificate has no external numerical dependency: all decisions are based on rational interval arithmetic with explicit logarithmic series remainders. The proof of the frequency corollaries invokes the known Chase–Lovett entropy inequality; it is not reproved in this archive. All general trace and recurrence proofs are in the manuscript. No GitHub modifications were made.
