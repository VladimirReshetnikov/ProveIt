# Research provenance and scope

Date of investigation: 25 November 2026 (Pacific time).

## Repository materials

The GitHub connector returned 18 ZIP archives at `VladimirReshetnikov/ProveIt`, `main`, `docs/drafts` (plus `.gitkeep`). The connector returned base64 archive bytes for seven selected archives; an in-memory ZIP/DEFLATE extraction was used to inspect LaTeX text. The following are the relevant observed archive names and Git blob SHAs (not SHA-256 hashes of the generated files):

| Archive | Git blob SHA | Material inspected / relation |
|---|---|---|
| `union_closed_advances_2026-11-25.zip` | `76d24159fb2ef3cff97a5488d023c382efc916a9` | Abstract, section headings and complete `union_closed_advances/sections/entropy.tex`; direct antecedent of the 0.19 recursive bound and 2.6-billion/407 corollaries. Its mathematical proof is restated with a freshly executed rational certificate in the appendix. |
| `union_closed_entropy_research_2026-11-25.zip` | `7dc1bb231d80709abab006c9e567356600d57786` | Abstract and portions of entropy, approximate closure and nonchain extremal sections. Prior chain majorization and entropy-deficit method. |
| `union_closed_refinements_2026-11-25.zip` | `6477927e6fa8d36b4696f74d46a2591001d809a7` | Abstract and portions of the capped profile, discrete refinement and nonchain sections. Prior water-level argument for approximate-closure leakage, not the lower-floor trace hierarchy developed here. |
| `union_closed_joint_laws_2026-11-25.zip` | `c497e7f366a6c29bd2002919c0a5e497d6359133` | Abstract and portions of generator-system sections. Different focus. |
| `union_closed_partial_theorems_2026-11-25.zip` | `6e072fb3cad5eb9fd6131db36ada8c2758804ea5` | Abstract and sections on generator incidence and high girth. Different focus. |
| `union_closed_marked_abundance.zip` | `25495ddc85bae5c765322bf19546314aefa79619` | Abstracts of marked graph/local/tagged abundance manuscripts. Different focus. |
| `union_closed_extensions_2026-11-25(1).zip` | `617984b228471ff98faed0c06561101cbd08c71a` | Selected extracted section openings; output was truncated, so this was only a partial inspection. |

Repository URL: https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts

Other archive names were listed but not fully inspected. Direct container access to raw.githubusercontent.com was unavailable (DNS failure); the GitHub connector provided the text described above. No repository files or branches were modified.

## External literature

- Justin Gilmer, arXiv:2211.09055, foundational entropy approach: https://arxiv.org/abs/2211.09055
- Zachary Chase and Shachar Lovett, arXiv:2211.11689, independent entropy inequality and golden-ratio threshold: https://arxiv.org/abs/2211.11689
- Matthew Aldridge's exposition independently records the exact inequality used here: https://mpaldridge.github.io/blog/union-closed.html
- Simone Costa and Ankan Sadhu, arXiv:2610.02295, 2026 stronger unconditional constant as reported in abstract: https://arxiv.org/abs/2610.02295
- Yunjiang Jiang, arXiv:2609.08291, global couplings and family-size refinements: https://arxiv.org/abs/2609.08291
- Quantavane, November 2026 self-published report claiming 0.38317525996679...; not independently audited: https://quantavane.com/major-results/union-closed-sets-conjecture/
- Overview: https://en.wikipedia.org/wiki/Union-closed_sets_conjecture

Targeted queries included `union closed families entropy of union k samples majorization second maximum semilattice chain Orlov`, `union closed sets conjecture trace entropy fibers union multiplicities entropy upper bound`, `union closed sets entropy upper bound water-filling trace fibers union closed family`, and `union closed sets conjecture entropy finite family size entropy upper bound chain incomparable pairs`. The searches did not establish an exact predecessor for the monotone trace-refinement profile theorem. This is not a comprehensive literature review or a guarantee of novelty. In particular, the latest global-coupling and fibre-based techniques are outside the scope of the numerical comparison; the explicit numerical improvements are relative to the named ProveIt draft and independent-sampling argument.

## Status of mathematical claims

- New candidate: the exact relaxed trace profile, its majorization monotonicity under refinement, strictness for incomparable traces, sharp examples, and its two-coordinate recursion. These have complete general proofs in the manuscript.
- New candidate: finite-size corollaries using the new recursion; scalar thresholds proved by rational interval certificates and the cited established Chase--Lovett inequality.
- Inherited: the chain profile, entropy transfer, 0.19 recursive stability theorem and its scalar input. The last is re-proved and re-certified to make the report self-contained apart from the established analytic input.
- Exhaustive tests are supplemental checks, not formal proof of the general statements.
- No new asymptotic constant, complete proof of the conjecture, independent specialist review or Lean formalization is claimed.
