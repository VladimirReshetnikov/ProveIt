#!/usr/bin/env python3
"""Exact exhaustive tests of trace majorization, refinement and two-block counts.
These are regression tests, not substitutes for the general proofs.
"""
from fractions import Fraction
from itertools import product
from collections import Counter, defaultdict
from math import log

def families(n):
    U=1<<n
    for fm in range(1,1<<U):
        F=[a for a in range(U) if (fm>>a)&1]
        if all((fm>>(a|b))&1 for a in F for b in F):yield F

def power_counts(F,t):
    r=Counter(F)
    for _ in range(t-1):
        z=Counter()
        for a,v in r.items():
            for b in F:z[a|b]+=v
        r=z
    return r

def waterfill(b,extra):
    assert extra>=0 and b==sorted(b)
    if extra==0:return list(map(Fraction,b))
    acc=extra
    for j,x in enumerate(b,1):
        acc+=x
        level=Fraction(acc,j)
        if j==len(b) or level<=b[j]:
            assert level>=x
            return [level]*j+list(map(Fraction,b[j:]))
    raise AssertionError

def majorizes(a,b):
    """a majorizes b, in ascending-prefix convention."""
    assert len(a)==len(b)
    aa=sorted(a); bb=sorted(b); x=y=0
    for u,v in zip(aa,bb):
        x+=u;y+=v
        assert x<=y,(a,b,x,y)
    assert x==y

def profile(F,r,mask,t):
    fib=defaultdict(list)
    for a in F:fib[a&mask].append(a)
    output=defaultdict(int)
    for a,v in r.items():output[a&mask]+=v
    allw=[]
    for T,f in fib.items():
        n=len(f); s=sum(len(g) for V,g in fib.items() if V!=T and V&T==V)
        b=[(s+j)**t-(s+j-1)**t for j in range(1,n+1)]
        M=output[T]-sum(b)
        w=waterfill(b,M)
        majorizes([r[a] for a in f],w)
        # prefix constraints in a valid inclusion-compatible order
        f=sorted(f,key=lambda a:(a.bit_count(),a)); k=h=0
        for a,v in zip(f,b):
            k+=r[a];h+=v
            assert k<=h+M
        assert k==h+M
        allw+=w
    majorizes(list(r.values()),allw)
    return allw

def incomparable_traces(F,mask):
    T={a&mask for a in F}
    return any(a&b!=a and a&b!=b for a in T for b in T)

def run(n,ts):
    nf=np=nr=ns=0
    for F in families(n):
        nf+=1
        for t in ts:
            r=power_counts(F,t); N=len(F)
            W={m:profile(F,r,m,t) for m in range(1<<n)}
            np+=len(W)
            assert sorted(W[(1<<n)-1])==sorted(r.values())
            chain=[j**t-(j-1)**t for j in range(1,N+1)]
            assert W[0]==chain
            for m,w in W.items():
                if incomparable_traces(F,m):
                    assert sorted(w)!=chain;ns+=1
                for i in range(n):
                    if not m>>i&1:majorizes(W[m|1<<i],w);nr+=1
    print(f'n={n}: {nf} nonempty union-closed families, {np} profiles, {nr} refinements, {ns} strict trace tests')
    return nf,np,nr,ns

if __name__=='__main__':
    a=run(3,[2,3,4]);b=run(4,[2,3]);print('PASS (integer and rational arithmetic).')
