#!/usr/bin/env python3
"""Exact rational certificates for the numerical corollaries; no floats in decisions."""
from fractions import Fraction as Q
from dataclasses import dataclass
from functools import lru_cache

@dataclass(frozen=True)
class I:
    lo: Q
    hi: Q
    def __add__(self, other):
        o=iv(other); return I(self.lo+o.lo,self.hi+o.hi)
    __radd__=__add__
    def __neg__(self): return I(-self.hi,-self.lo)
    def __sub__(self,other): return self+-iv(other)
    def __rsub__(self,other): return iv(other)+-self
    def __mul__(self,other):
        o=iv(other); v=[a*b for a in (self.lo,self.hi) for b in (o.lo,o.hi)]
        return I(min(v),max(v))
    __rmul__=__mul__
    def __truediv__(self,other):
        o=iv(other); assert o.lo*o.hi>0
        return self*I(1/o.hi,1/o.lo)

def iv(x): return x if isinstance(x,I) else I(Q(x),Q(x))

@lru_cache(None)
def log_unit(x):
    assert 1<=x<=2
    t=(x-1)/(x+1); s=Q(0); y=t
    for j in range(32):
        s+=2*y/(2*j+1); y*=t*t
    return I(s,s+2*y/(65*(1-t*t)))

@lru_cache(None)
def log(x):
    x=Q(x); assert x>0
    n=0
    while x<1: x*=2; n-=1
    while x>2: x/=2; n+=1
    return log_unit(x)+n*log_unit(Q(2))

g=Q('0.381966011250105'); gu=Q('0.381966011250106')
assert g*g-3*g+1>0>gu*gu-3*gu+1

def R(z):
    J=1-(1+g)**2*z*z; d=2*g*g*z*z
    assert J>0
    return (J+d)*log(1+d/J)-d

def B(q): return Q('.19')*(1-q)**2+R(1-q)

def F_over(q):
    return log((2-q)/(2+q))+2*q/(2-q)+2*(q-log(1+q))/(2-q)

def Jint(x):
    if x==0:return iv(0)
    return x*x*(log(2*x)-Q(1,2))

def E(s,q):
    K=1+2*q-q*q; c=1-s*(1+q); T=1-K*s*s
    assert c>0 and T>0
    return 2*Jint(s)-Jint(s*(1-q))+T*log(T/c)-Jint(Q(1))

def floor_decimal(x, digits=9):
    f=x.numerator*10**digits//x.denominator
    return f'{f//10**digits}.{f%10**digits:0{digits}d}'

# Inherited scalar lemma, independently re-certified. Both summands have
# opposite monotonicities as proved in the manuscript.
old=[g]+list(map(Q,['.382','.383','.384','.385','.386','.388','.390','.395','.400','.410','.420','1']))
print('Inherited scalar certificate:')
for u,v in zip(old,old[1:]):
    L=F_over(u)+R(1-v)/(v*(2-v))
    assert L.lo>Q('.19')
    print(str(u),str(v),floor_decimal(L.lo))

# New scalar comparisons. E increases in s and q in the range used;
# B decreases in q. Thus endpoint enclosures certify full intervals.
pts=[g]+list(map(Q,['.382','.3822','.3825','.383','.384','.385','.388','.39','.4','.42','.45','1']))
print('\nNew scalar certificate: interval | s=.61 | s=.593')
for u,v in zip(pts,pts[1:]):
    vals=[E(s,u)+s*s*B(v) for s in [Q('.61'),Q('.593')]]
    assert vals[0].lo>Q('.09855') and vals[1].lo>Q('.09188')
    print(str(u),str(v),*[floor_decimal(z.lo) for z in vals])

# Derivative bounds for monotonicity in s.
# s>=.593, q>=.38. P(s)=1-4s+(3+2q+q^2)s^2 > 0,
# increasing in both arguments on this range.
s=Q('.593'); q=Q('.38'); A=3+2*q+q*q
assert 1-4*s+A*s*s>0 and -4+2*A*s>0
assert log(Q(2)).hi<Q('.7')
assert Q('1.4')**2-4*Q('1.7')*Q('.3')<0

# Final numerical corollaries. delta_N decreases for N>=2 (proof in paper).
D=log(Q(2))-Q(1,2)
def delta(N):return (D+log(Q(N))/4)/(N*N)

def frequency(deficit,N):
    return g+(1-gu)*deficit/log(Q(N))

cases=[('2..9',frequency(iv(Q(8,81)),9),Q('.39')),
       ('10..999',frequency(D-delta(10),1000),Q('.39')),
       ('1000..5.5e9',frequency(D+Q('.09855')-3*delta(1000)-Q(1,1000000),5500000000),Q('.39')),
       ('N=1000, p<=.407',frequency(D+Q('.09188')-3*delta(1000)-Q(1,1000000),1000),Q('.407'))]
print('\nCertified frequency lower bounds under the relevant contradictory assumptions:')
for name,val,target in cases:
    assert val.lo>target
    print(name, floor_decimal(val.lo),'>',target)
print('PASS: all numerical decisions made with exact rational enclosures.')
