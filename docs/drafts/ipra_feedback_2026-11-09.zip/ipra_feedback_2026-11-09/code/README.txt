FEEDBACK-RESET COMPLETE CHECKER
==============================

Acceptance program: feedback_checker.py
Public input: one JSON object with exactly goal and proof fields.
The goal must be a closed formula. Proof nodes have an exact rule inventory;
unrecognized or extra fields reject. Python's standard library is the only
runtime dependency. No proof producer or external theorem table is imported.

Arithmetic descriptions
----------------------
The inherited finite primitive-recursive descriptions are zero, succ, proj,
comp and rec. There is one added base description ["compare"] of arity two.
Composition and recursion may contain this base. The ordinary interpretation
replaces it by the Boolean equality characteristic. The source checker gives
compare NO defining equation; a compute instruction on compare rejects.
Arithmetic equality is syntax in formulas, not an instruction to evaluate
the intended standard numerical function.

The fixed primitive-recursive descriptions PREDECESSOR, SELECTOR and SIGN
remain explicit and charged in the source. Their intended equations are
P(0)=0, P(Sn)=n; C(0,a,b)=a, C(Sn,a,b)=b; sg(0)=0, sg(Sn)=1.
The retained fixed arithmetic sentences are BR, stating sg(n)=0 or sg(n)=1,
and Sep, stating 0=1 implies genuine falsity. Neither numerical coverage
nor any induction rule is primitive.

New arithmetic rule
-------------------
FR fields are var, template, anchor, at, and exactly one premise.
Let x be var, f(x) be template, c be anchor, and t be at. Write

  a(x) = compare(f(x),c)
  rho(x) = C(sg(a(x)), Sx, sg(P(a(x)))).

The premise must conclude exactly f(rho(x))=c, modulo bound-variable names.
The conclusion is f(t)=c. The template name x is fresh for the ambient
context and parameters; c and t are validated in the old ambient scope,
so neither can contain x. The anchor is arbitrary passive data and need not
be f(1). Reset construction, substitution and premise matching are all
performed by the acceptance program, not trusted certificate fields.

Logical rules
-------------
The inherited complete natural-deduction rules remain unchanged: hypotheses,
reflexivity, equality transport with capture-avoiding substitution, falsity
elimination, conjunction, disjunction, implication, universal and existential
introduction/elimination. All logical and arithmetic results are validated
at the resulting scope. Eigenvariables cannot escape. Alpha equivalence
uses the nearest matching binder.

Reproduce
---------
  python3 code/validate_feedback.py
  python3 code/validate_anchored.py
  python3 code/measure_frontier.py
  python3 code/feedback_checker.py < fixtures/arbitrary_anchor_schema.json

validate_feedback.py constructs expected formulas independently of the
checker, tests every rule, exercises compare within composition and recursion,
and rejects a direct comparison computation, wrong reset fallback, altered
premise, missing anchor, eigenvariable capture, logical capture errors and
malformed JSON. It runs the public interface in ordinary and optimized
Python. These finite tests do not mechanize the report's universal calibration
or interpretation theorem. The handwritten soundness argument for the checker
is induction on its finite proof tree, using the exact displayed rules.

Comparison scope
----------------
baseline_raw_reset.py is the unchanged upstream complete full-PR checker.
SOURCE_CHANGE.patch is the exact derivative. This is a matched architectural
comparison, including all syntax, descriptions, logic, arithmetic and CLI;
it is not a comparison of only the reset function. The feedback derivative
has 3316 normalized tokens, 3526 AST nodes and 13382 normalized bytes on
CPython 3.12.14, against 3347/3539/13354 for the frozen baseline. Thus tokens
and AST nodes decrease; normalized bytes increase by 28.

The 22 frozen native comparators have coordinate minima 306/340/839,
attained by different programs. The 306-token candidate accepts documented
syntax aliases and uses CPython's recursion guard on malformed strings.
The 839-byte source is a separate lambda variant. These implementation
observations are not an invariant lower-bound theorem. The feedback checker
does NOT beat that global envelope.

Anchored companion
------------------
feedback_anchored_checker.py retains the upstream SR certificate fields,
computes c=f(1), and uses the same new feedback transition and unspecified
comparison. No arbitrary anchor field is accepted. Its ordinary arithmetic
profile and all logical rules coincide with the free-anchor companion.
It measures 3318 tokens / 3528 AST nodes / 13390 normalized bytes, so the
free-anchor version is slightly smaller despite its more general rule.
ANCHORED_SOURCE_CHANGE.patch gives its exact delta from the unchanged
baseline; anchored_validation.json records 33 accepted and 42 rejected
packets, tested in 150 normal/optimized CLI runs. The report's spike and
ramp use anchors f(1), and the supplied induction base and step establish
f(1)=c, so the same calibration and induction proof supports this variant.
The written equivalence argument is separate from these finite checks.

Attribution and trust
---------------------
The direct source is ProveIt docs/drafts/ipra_raw_reset_2026-11-09.zip,
internal code/complete_checker.py, at repository snapshot
2afdf8f5df47a2c7f3da6cdf4b4130dd34d7fa91. Its SHA-256 is
3fa070933cce77e4e702eabceb71453a0ea349c728b79c5ebf4ca072b749e570.
Upstream logical code attribution is retained in UPSTREAM_ATTRIBUTION.txt;
the supplied license is LICENSE-inherited.txt. upstream_fixtures.py preserves
the upstream independent fixture definitions and whole-source normalizer.
The new checker, feedback fixtures, and exact mathematical rule change were
prepared during this research task. No Lean/Rocq verification is claimed.
