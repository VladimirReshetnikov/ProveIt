A COMPARISON FUNCTION FORCED BY RESET INDUCTION
Research prepared for Vladimir Reshetnikov, 9 November 2026
==========================================================

START HERE
----------
ipra_feedback.pdf is the complete report.
ipra_feedback.tex is its standalone editable LaTeX source.

RESULT
------
A primitive binary comparison e has no defining equations or range axiom.
Let E(a,b)=sign(e(a,b)) and V(a,b)=sign(P(e(a,b))).
One feedback-reset rule uses

    rho(z) = C(E(f(z),c), S(z), V(f(z),c))
    Gamma |- f(rho(z))=c  /  Gamma |- f(t)=c.

With the ordinary PR-relative description equations, sign Boolean range,
and separation, the rule forces the full specification of e and recovers
all contextual quantifier-free induction. Both whole-domain interpretation
composites with full first-order intuitionistic PRA are proved.

The source has ordinary intuitionistic first-order logic. The report lists
every logical rule and every numerical formation/defining schema. Numerical
coverage and raw comparison range are derived, not assumed.

STATUS OF THE REQUESTED MINIMUM
------------------------------
The new mathematical feedback calibration is proved relative to the current
draft corpus. A complete checker below the entire compact native frontier
was NOT obtained. The arbitrary-target complete checker has 3316 normalized
tokens / 3526 AST nodes / 13382 bytes, versus the matched raw-reset baseline
3347 / 3539 / 13354. It saves tokens and nodes but adds 28 bytes.
The current native coordinate envelope is 306 / 340 / 839, attained by
different programs with different documented input contracts.
No absolute simplestness or literature-wide priority is claimed.

REPRODUCE
---------
From this directory, with Python's standard library:

    python3 verify_archive.py
    python3 reproduce.py

To compile the PDF, with pdfLaTeX and its ordinary standard packages:

    python3 build.py

The build uses no shell escape or network. Exact source-normalization
measurements use CPython 3.12.14. Other versions may change ast.unparse
formatting. Reproduction refreshes receipts, so verify the original manifest
before running it. A build/ directory and Python bytecode are transient.

WHAT IS CHECKED
---------------
The paper contains a complete written proof independently reviewed by
assistant agents. There is no Lean/Rocq mechanization or external peer review.
The main checker passed 162 ordinary/optimized CLI runs; its anchored variant
passed 150. The checks cover all 19 rule tags, the exact feedback transition,
comparison-computation rejection, malformed input, scope and capture.
An independent case program checks the Boolean calibration branches and exact
finite-support counterexamples. It does not certify the entire theorem.

PACKAGE
-------
code/feedback_checker.py          Complete arbitrary-target acceptance program
code/feedback_anchored_checker.py Complete fixed-anchor companion
code/baseline_raw_reset.py        Unchanged matched comparison source
code/validate_*.py                Public CLI fixture generation and validation
code/check_calibration.py         Independent exact cases/counterexamples
code/measure_frontier.py          Frozen complete-source measurements
reference/                       22 inherited comparator sources and provenance
fixtures/, anchored_fixtures/    Generated interface certificates
reviews/                         Independent mathematical and code reviews
source_snapshot.json             All 15 inspected archive identities
corpus_audit.json/.md             Contribution and novelty matrix
*_validation.json                Executed checker receipts
calibration_cases.json            Exact-case receipt
frontier_metrics.json             Whole-source results
CLAIMS.json                      Proven/inherited/unestablished claim ledger
MANIFEST.json                    SHA-256 and size of every packaged payload file

PROVENANCE
----------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Snapshot: 2afdf8f5df47a2c7f3da6cdf4b4130dd34d7fa91
Directory: docs/drafts
All 15 current ZIPs were verified against Git blob identities.
The isolated spike, ramp, formula characteristics and ordinary checker logic
are attributed inherited components. The new feedback destination and raw
comparison specification theorem are the new contribution.
Original notices are retained in code/UPSTREAM_ATTRIBUTION.txt and
code/LICENSE-inherited.txt. No remote repository modifications were made.

