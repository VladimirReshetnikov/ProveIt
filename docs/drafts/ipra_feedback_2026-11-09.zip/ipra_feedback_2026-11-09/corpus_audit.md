# Current 15-archive audit

Pinned commit: `2afdf8f5df47a2c7f3da6cdf4b4130dd34d7fa91`.

| Archive | Established contribution | Comparison limit |
|---|---|---|
| ipra_boolean_bootstrap_2026-11-09.zip | Derives Boolean-valued zero induction before general reflection; deletes the clock-related second diagonal; expanded fixed guard374→182 nodes. | Retains a fixed PR comparator; no below-frontier complete checker. |
| ipra_clock_and_kernel_2026-11-09.zip | Bare-equational predecessor uses16 declarations/93 shared body nodes instead of22/130; separate inherited-calculus implementation reaches306 tokens and340 AST nodes. | New clock is a derived term. The306-token implementation has documented syntax aliases and a CPython recursion-guard malformed-input qualification. |
| ipra_frontier_audit_2026-11-09.zip | Explicit atomic-only equality transport normalization and a finite-first-order-axiomatization obstruction; corrects an earlier omitted comparator. | Neither a new arithmetic basis nor a smaller complete checker. Its309-token minimum was later superseded. |
| ipra_left_rewriting_2026-11-09.zip | Rewrites only the root or one immediate argument of an equation left side; arbitrary checked equation source suffices; full consequence equivalence. | Matched readable checker3287→3160 tokens, not below compact native envelope. |
| ipra_local_rewriting_2026-11-09.zip | Restricts transport to one numerical occurrence in a literal equation, with computation/direct atomic clause sources; continuation-strengthened proof translation. | Readable checker3287 tokens; arithmetic uses attributed rotation theorem. |
| ipra_neutral_transport_2026-11-09.zip | Bidirectional replacements can use computation equations or atomic local-clause consequences; arbitrary native formulas preserved. | No new complete checker. Its premise-validation deletion experiment is unsound. |
| ipra_one_fixed_recurrence_2026-11-09.zip | Derives the prior retraction H(Dn)=n from the remaining signed-counter uniqueness theory; full iPRA equivalence with coverage/separation. | Retains full PR descriptions and ordinary logic; no global complete-checker improvement. |
| ipra_package_reconstructed.zip | One-premise reset with fixed anchor f(1) derives equality reflection and removes the former absorption axiom. | Separate309-token checker implements an inherited native calculus, not the new reset theory. |
| ipra_progress_closure_2026-11-09.zip | Atomic binder means progression; compound binder means conditional closure; protected padding and an additional progression elimination give full round trips. | No full-checker mathematical reduction;307-token/839-byte variant is a separate inherited-code refactor. |
| ipra_pulse_calibration_2026-11-09.zip | Predecessor-free spike calibrates a raw Boolean comparator; one pulse at exact time a detects equality; expanded detector182→70 nodes. | Matched ordinary checker3247→2743 tokens; still above native envelope. |
| ipra_raw_reset_2026-11-09.zip | A spike proves the raw Boolean test diagonal and a ramp proves reflection; failure reset is literally0. | The test remains a fixed PR term. Complete full-PR checker3347 tokens. |
| ipra_recurrence_boundary_2026-11-09.zip | Countermodels for bounded observation and separately defined identity-clock inputs; stationarity/retraction equivalence; bouncing predecessor partial calibration. | Bouncing-predecessor full equivalence remains unproved; no new smaller complete checker. |
| ipra_rotation_2026-11-09.zip | One fixed rotation equation completes successor-trajectory uniqueness to iPRA; rotation captures the unresolved equality-reflection gap. | A local mathematical presentation; no below-frontier complete implementation. |
| ipra_two_diagonal_2026-11-09.zip | Repairs closed-iteration clock and raw equality via two forced zeros; full identity-domain interpretation. Also proves counter-coupled-seed majorization boundary. | The second diagonal is removed by Boolean-bootstrap; fixed detector is later reduced by pulse. |
| ipra_unbounded_depth_2026-11-09.zip | Realizability proves unbounded native-depth gap at classical depth zero; stable-image obstruction to a particular unary conditional closure. | Formula-representation obstructions, not checker lower bounds; CVI and related recurrence simplifications remain incomplete. |

## Feedback novelty

The proposed reset uses the formerly discarded comparison value in its fallback: C(sg(e(f(z),c)), Sz, sg(P(e(f(z),c)))). No occurrence of this calibration was found in the current extracted TeX/Markdown/text corpus or inspected historical reflection-absorption source. The closest predecessor is raw reset with fallback zero and a fixed Boolean-normalized PR term. The historical report explicitly identifies uncontrolled positive outputs as the obstacle to adding an unspecified comparison symbol. This is a corpus-relative novelty assessment, not a claim of literature-wide priority.

The original source and predecessor references are explicitly preserved in code/UPSTREAM_ATTRIBUTION.txt and the current snapshot manifest.
