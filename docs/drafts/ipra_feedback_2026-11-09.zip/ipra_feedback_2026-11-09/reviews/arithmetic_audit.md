# Arithmetic audit and new result

Pinned corpus: ProveIt commit `2afdf8f5df47a2c7f3da6cdf4b4130dd34d7fa91`, 15 current ZIPs in `docs/drafts`, all downloaded by root and SHA-matched.

## Assigned baseline reports inspected

1. **ipra_raw_reset_2026-11-09**: full fixed PR language, ordinary intuitionistic FOL, BR for sign, separation, one anchored reset rule. It removes a diagonal normalizer from the fixed residual detector using the isolated spike `H(0)=H(1)=a,H(2)=b` and the local exceptional-successor property. Generic comparison-symbol calibration is explicitly known: `e` can be primitive if Boolean range is postulated. The auxiliary `evidence/paper_review.txt` has a dedicated “Generic comparison-symbol observation”. Merely proposing primitive Boolean `e` would duplicate the corpus.

2. **ipra_boolean_bootstrap_2026-11-09**: closed unary iterator signature, BR, separation, raw reset. It removes the second clock-diagonal mask by deriving Boolean-valued induction, applying it to the clock defect, then obtaining ordinary equality reflection and full induction. It explicitly does not beat the native checker minimum. Exact initialization is important; a shifted-only plain-reset model with erased tags defeats whole-domain biinterpretability.

3. **ipra_one_fixed_recurrence_2026-11-09**: full PR language, Cov, separation, one signed-update uniqueness rule `U_B`. Already derives arbitrary-value stationarity, a signed action with explicit inverse, parity decomposition, and the formerly assumed half/doubling retraction. Thus `U_B` alone with its stated boundaries is already equivalent to iPRA. This must not be offered as new.

4. **ipra_rotation_2026-11-09**: full PR language, Cov, separation, zero-based successor uniqueness `SU0`, and one fixed rotation equation for the signed iterator. It derives zero-equation induction, zero-based signed uniqueness, the anchored translation identity, actual equality reflection, and full iPRA. Removal of rotation remains unproved there.

5. **ipra_recurrence_boundary_2026-11-09**: obstruction for rules whose state observations factor through finite ranges; plus retraction/stationarity theorem and bouncing-predecessor partial results. It emphasizes that identical standard dynamics need not give identical pre-induction source strength. W uniqueness alone is not resolved there. No source-size breakthrough is claimed.

## New mathematical result

File `comparison_feedback.tex` gives a complete proof. Add primitive binary comparison `e`, with **no equations and no range axiom**, to the finite PR description grammar. Retain exactly BR for the ordinary sign operation and separation. Put

`E(a,b) = sigma(e(a,b))`

`V(a,b) = sigma(P(e(a,b)))`.

Replace the old constant-zero failure destination by `V`:

`rho_f,c(z) = C(E(f(z),c), S(z), V(f(z),c))`.

The one rule is from `f(rho_f,c(z))=c`, uniformly at fresh z, to `f(t)=c`. The passive c is arbitrary and fixed; anchored c=f(1) also works.

Dependency order:

1. E and V have Boolean range solely because sign has BR.
2. Inherited isolated spike calibrates E(a,a)=0. Both potential failure values 0,1 miss its exceptional state.
3. Ordinary zero/successor ramp proves E(a,b)=0 iff actual a=b.
4. A new use of that ramp rules out V(a,b)=1 when E(a,b)=1: it would make the exceptional state reset to anchor 1 and force a=b. Hence all actual failure destinations are 0.
5. Contextual zero-equation induction follows using E as the now-faithful guard.
6. Let `j(n)=C(sigma(n),0,S(Pn))` and `r(n)=E(j(n),n)`. Finite equations give r(0)=0 and r(Sn)=0, so zero-equation induction and reflection prove j(n)=n. BR then yields coverage and sign reflection without general formula induction.
7. E=0 forces raw e=0. E=1 gives V=0, hence P(e)=0; coverage yields raw e=1 (a collapsed 0=1 branch can be handled by numerical rewriting). Thus e=E and e is actually Boolean.
8. Separation and ordinary Boolean characteristics now recover all contextual quantifier-free formula induction and the ordinary iPRA boundaries.
9. The source comparison is uniquely definable as an ordinary PR Boolean equality characteristic. Replace e leaves with that target description and use induction on description syntax, equation induction for each recursive symbol, to prove both whole-domain identity round trips.

All of steps 1–7 are separation-free numerical derivations. Sep is needed to preserve genuine falsity and obtain the full intuitionistic formula interface.

## Novelty and scope

Global searches of the current extracted corpus for primitive/uninterpreted comparators, feedback/reset destinations, predecessor of tests, and comparison normalization found the old generic primitive Boolean observation but no reset with predecessor-sign feedback. Every old plain-reset transition encountered used constant zero as its failure destination. The proposed new contribution is therefore **automatic specification of the raw primitive comparison by its numeric feedback**, not arbitrary-anchor reset, primitive Boolean comparison, spike calibration, or ordinary reflection themselves.

Root's independent logical reviewer checked both the initial Cov-based predecessor-feedback version and this stronger BR-only bounded-feedback version. No circularity was found. The key distinction is that the early spike needs only its local successor property, not unique exception at 2 in every weak model.

No complete checker size below the existing native minima has been established by this mathematical proof. The extra e syntax case and feedback terms must be charged. Implementation work is assigned separately.
