# Independent review: Boolean feedback calibration

## Verdict

The Boolean-feedback version is valid over the same base as the inherited raw-reset theory: full fixed primitive-recursion descriptions, Boolean range of the sign function, separation, and ordinary intuitionistic first-order equality logic. Numerical coverage is not an input. The comparator is a primitive binary symbol with no equations or range axiom. Calibration derives its behavior. The three calibration equations below do not need separation at all.

## Exact base and rule

Let C, P, sigma be fixed PR descriptions with

`C(0,a,b)=a`, `C(Sn,a,b)=b`, `P0=0`, `P(Sn)=n`, `sigma0=0`, `sigma(Sn)=1`.

The sole positive range axiom is `sigma(x)=0 or sigma(x)=1` for every x. Numerical descriptions may be primitive recursive relative to the initially unconstrained e. After calibration this relative language is a definitional extension of the ordinary PR language.

Define `E(a,b)=sigma(e(a,b))`, `R(a,b)=sigma(P(e(a,b)))`. Both are Boolean immediately from the stated range axiom, without any property of e.

For fixed template f, passive numerical term c, and fresh z, define

`rho(z)=C(E(f(z),c),Sz,R(f(z),c))`.

The rule infers `Gamma |- f(t)=c` from `Gamma |- f(rho(z))=c`. The freshness restriction excludes z from Gamma, c, t, and the fixed passive parameters of f. All substitutions are capture-avoiding.

## Lemma 1: the two-position-avoiding spike

For fixed parameters a,b put

`H(z)=C(C(sigma(Pz),1,sigma(P(Pz))),b,a)`.

Direct computation gives H0=H1=a and H2=b. Let `p=sigma(Pz)` and `q=sigma(P(Pz))`. BR gives three exhaustive control branches:

1. p=0, so H(z)=a.
2. p=1,q=1, so H(z)=a.
3. p=1,q=0, so H(z)=b, and H(Sz)=a.

For the last assertion, predecessor computation gives the inner control at Sz as `C(sigma(z),1,p)`. With p=1 this is 1 by BR on sigma(z). Hence H(Sz)=a. No coverage, arbitrary equality decidability, induction, or comparator equation occurs in this proof. A statement merely saying `H(z)=b implies H(Sz)=a` would be imprecise when a=b; use the explicit control branches, or note that the implication is still harmless in that degenerate case because H is then constant.

## Lemma 2: diagonal E(a,a)=0

BR splits E(a,a). The zero branch is finished. In the one branch, use H and c=a. In either branch where H(z)=a, the comparison is E(a,a)=1 and the reset is R(a,a), which is Boolean; both H0 and H1 are a. In the exceptional branch H(z)=b, split E(b,a). Its zero branch advances to Sz, where H is a. Its one branch resets to the Boolean R(b,a), again yielding a. Thus the rule premise is proved for arbitrary z, and its conclusion at t=2 is b=a.

This works for arbitrary b. Take b=0 and b=1 to obtain 0=1. In the current E(a,a)=1 branch, equality replacement now yields E(a,a)=0. Close the original Boolean disjunction. This derives the diagonal without separation or falsity elimination; the equality collapse alone suffices.

## Lemma 3: reflection E(a,b)=0 iff a=b

Under E(a,b)=0 use the sign-controlled ramp `F(z)=C(sigma(z),a,b)` with c=b. F0=a, F1=b, and F(Sz)=b for every z by defining equations. BR on sigma(z) gives F(z)=a or b. In the first branch its comparison is the assumed zero E(a,b); in the second it is the calibrated zero E(b,b). Both reset to Sz, whose ramp value is b. The rule at t=0 yields a=b. The reverse implication follows by equality replacement and the diagonal. No separation is used.

## Lemma 4: E(a,b)=1 implies R(a,b)=0

Assume E(a,b)=1 and split Boolean R(a,b). The zero branch is finished. In the one branch use the same ramp F and c=b. When sigma(z)=0, its value is a and its reset is R(a,b)=1, where F1=b. When sigma(z)=1, its value is b and its comparison is the zero diagonal, so it advances to Sz, where F is b. The rule at t=0 gives a=b. Reflection of equality through the diagonal gives E(a,b)=0, hence 0=1. Rewrite R(a,b)=1 to R(a,b)=0 and close its Boolean disjunction. Again no separation is used.

## Effective reset and full induction

The preceding three equations prove

`rho(z)=C(E(f(z),c),Sz,0)`

by BR on E: the successful branch ignores R; the failing branch has R=0. The comparison E is a Boolean characteristic of actual equality. With separation, ordinary structural induction on a fixed quantifier-free formula supplies its Boolean characteristic, including conjunction, disjunction, implication and genuine falsity. The inherited ordinary-reset induction proof now applies, or is reproved directly:

Given A(0) and A(n)->A(Sn), let f(n) be its zero-characteristic and take c=0. In the E(f(z),0)=0 branch, reflection gives f(z)=0, hence A(z) and A(Sz), hence f(Sz)=0. In the comparison-one branch, the effective reset is zero and the given base gives f0=0. The reset rule yields f(t)=0, hence A(t). Retained contexts are arbitrary; only the matrix must be quantifier-free. The arbitrary-passive-c version avoids needing a separate argument f1=0, although that argument also validates the anchored c=f1 variant.

## Final normalization of primitive e

Full QF induction proves numerical coverage. Coverage, sign equations, and separation prove sigma(x)=0 iff x=0. Thus E(a,b)=0 implies e(a,b)=0. If E(a,b)=1, coverage of e(a,b) gives e(a,b)=S(P(e(a,b))); the zero case would contradict E=1. Lemma 4 gives sigma(P(e(a,b)))=0, hence P(e(a,b))=0, and consequently e(a,b)=1. Therefore e itself is the canonical Boolean equality detector, not merely a nonstandard raw representation of one.

This final step is essential for whole-domain bi-interpretability. Calibrating only E while leaving arbitrary raw values e would leave additional structure. Here both zero and positive raw fibers are internally normalized.

## Converse and round trips

In iPRA interpret e by a fixed canonical primitive-recursive equality detector. Then E=e and R=0, and the new rule is ordinary reset induction. At z=0, comparison-zero gives f0=c directly; comparison-one makes the premise itself f0=c. From f(n)=c the comparison is zero, so the premise gives f(Sn)=c. QF induction validates the conclusion. This proves the rule sound even with arbitrary passive c.

In the source, after full QF induction and raw-e normalization, prove e equals the same canonical detector. External induction on fixed finite descriptions, using recursion uniqueness in the now-derived arithmetic, proves each e-relative description equals its translated ordinary PR description. The interpretation maps preserve actual equality and the entire numerical domain, with identity composite graph x=y. The proof is deductive/definitional, not merely a standard-model argument.

## Complexity qualification

The mathematical change removes the fixed raw comparator definition from the trusted arithmetic package and derives all behavior of a new primitive comparison symbol from the feedback rule. It also avoids adding coverage to the old BR base. That is a real mathematical calibration result. A claim to beat the current compact native 306-token frontier still requires a complete matched checker; the proof above does not establish that stronger implementation claim.
