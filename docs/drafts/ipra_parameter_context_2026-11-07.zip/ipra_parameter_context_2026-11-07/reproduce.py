"""Reproduce the offline implementation evidence and write RESULTS.json."""
import contextlib
import io
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
import measure
import validate

ROOT = Path(__file__).resolve().parent


def main():
    with contextlib.redirect_stdout(io.StringIO()):
        measurements = measure.main()
        validation = validate.main()
        independent_module = validate.load(
            ROOT / 'validation/independent_audit.py', 'independent_public_audit')
        independent_module.main()
    independent = json.loads((ROOT / 'validation/independent_results.json').read_text())
    normalizer_process = subprocess.run(
        [sys.executable, '-B', str(ROOT / 'validation/alternating_test.py')],
        capture_output=True, text=True)
    if normalizer_process.returncode:
        raise RuntimeError(normalizer_process.stderr or normalizer_process.stdout)
    alternating = json.loads(normalizer_process.stdout)
    if alternating['status'] != 'PASS':
        raise AssertionError('Alternating-normalizer validation failed')
    (ROOT / 'results/alternating.json').write_text(json.dumps(alternating, indent=2) + '\n')
    result = {
        'status': 'passed',
        'python': measurements['python'],
        'implementation': measurements['implementation'],
        'source_commit': measurements['commit'],
        'comparison': {
            'archive_count': measurements['archive_count'],
            'root_comparator_count': measurements['root_comparator_count'],
            'coordinatewise_minimum': measurements['coordinatewise_minimum'],
            'arbitrary_parameter_minimum': measurements['arbitrary_parameter_minimum'],
            'core_coordinatewise_minimum': measurements['core_coordinatewise_minimum'],
            'candidates': measurements['candidates'],
            'strict_improvement': measurements['strict_improvement'],
            'strict_core_improvement': measurements['strict_core_improvement']
        },
        'validation': {key: value for key, value in validation.items()
                       if key != 'records' and not key.endswith('_results')},
        'independent_audit': {key: value for key, value in independent.items()
                              if key != 'cases'},
        'alternating_normalizer': alternating,
        'detailed_results': ['results/metrics.json', 'results/metrics.csv',
                             'results/validation.json',
                             'validation/independent_results.json',
                             'results/alternating.json'],
        'evidence_scope': 'Finite implementation-size comparisons and executable validation; mathematical metatheorems are proved in the accompanying report, not formally verified by these scripts.'
    }
    (ROOT / 'RESULTS.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
