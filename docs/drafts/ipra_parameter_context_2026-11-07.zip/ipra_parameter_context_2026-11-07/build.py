"""Compile the report with pdfLaTeX and report material layout diagnostics."""
from pathlib import Path
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
command = shutil.which("pdflatex")
if not command:
    raise SystemExit("pdfLaTeX is required to rebuild report.pdf")
build = ROOT / "build"
build.mkdir(exist_ok=True)
for _ in range(3):
    result = subprocess.run(
        [command, "-interaction=nonstopmode", "-halt-on-error",
         "-output-directory=build", "report.tex"],
        cwd=ROOT, capture_output=True, text=True,
    )
    if result.returncode:
        print(result.stdout[-12000:])
        raise SystemExit(result.returncode)
shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
log = (build / "report.log").read_text(errors="replace")
diagnostics = [line for line in log.splitlines()
               if "Overfull" in line or "undefined" in line.lower()
               or "LaTeX Warning" in line]
record = {"passes": 3, "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
          "diagnostics": diagnostics}
results = ROOT / "results"
results.mkdir(exist_ok=True)
(results / "pdf_build.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
