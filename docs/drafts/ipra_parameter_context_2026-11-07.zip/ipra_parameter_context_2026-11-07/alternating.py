#!/usr/bin/env python3
"""Untrusted tools for the alternating-spine theorem; not a proof checker.

Named JSON syntax (Python callers use tuples instead of JSON arrays):
  terms:    0 | "x" | ["S", t] | ["R", n, a, "u", "v", h]
  formulas: ["=", s, t] | ["Q", "x", A] | ["E", "x", A]
The R binders u,v scope only over h.  ["C", z, a, b] is a displayed
abbreviation for R(z,a;u,v.b), with fresh, unused u,v.  Normalization
preserves source terms and only adds such conditional wrappers.

Examples (read JSON from stdin, or give a filename after the operation):
  python3 alternating.py normalize
    ["Q","x",["Q","y",["=","x","y"]]]
  python3 alternating.py pad
    {"formula":["=","a",0],"rank":3}
  python3 alternating.py selector
    {"variable":"z","left":["=","a",0],
     "right":["Q","x",["=","x","b"]],"parity":0}
  python3 alternating.py gate
    {"selector":["S","z"],"formula":["Q","z",["=","z","a"]]}

The first example becomes Q_x E__p0 Q_y (x=y).  Its new E is vacuous.
pad, align and selector require alternating input; normalize arbitrary
input first.  selector's variable must not occur free in either operand.
The semantic roles of the single alternating binder are parity indexed;
this module does not assert cross-phase congruence or compile proofs.
Run validation/alternating_test.py for finite, independent checks of the
syntax transformations.  These tests do not formalize the metatheorem.
"""

import argparse
import json
import sys


def freeze(value):
    """Convert JSON arrays to the immutable tuple representation."""
    if isinstance(value, list):
        return tuple(freeze(x) for x in value)
    return value


def _name(value):
    if not isinstance(value, str) or not value:
        raise ValueError("a variable name must be a nonempty string")


def validate_term(t):
    if type(t) is int and t == 0:
        return
    if isinstance(t, str):
        _name(t)
        return
    if not isinstance(t, tuple) or not t:
        raise ValueError("invalid numerical term")
    if t[0] == "S" and len(t) == 2:
        validate_term(t[1])
    elif t[0] == "C" and len(t) == 4:
        for x in t[1:]:
            validate_term(x)
    elif t[0] == "R" and len(t) == 6:
        _, n, a, u, v, h = t
        _name(u)
        _name(v)
        if u == v:
            raise ValueError("R's two update binders must be distinct")
        for x in (n, a, h):
            validate_term(x)
    else:
        raise ValueError("invalid numerical constructor")


def validate_formula(a):
    while isinstance(a, tuple) and len(a) == 3 and a[0] in ("Q", "E"):
        _name(a[1])
        a = a[2]
    if not isinstance(a, tuple) or len(a) != 3 or a[0] != "=":
        raise ValueError("a formula must end in an equation")
    validate_term(a[1])
    validate_term(a[2])


def term_free(t):
    if isinstance(t, str):
        return {t}
    if t == 0:
        return set()
    if t[0] == "R":
        _, n, a, u, v, h = t
        return term_free(n) | term_free(a) | (term_free(h) - {u, v})
    return set().union(*(term_free(x) for x in t[1:]))


def formula_free(a):
    if a[0] == "=":
        return term_free(a[1]) | term_free(a[2])
    return formula_free(a[2]) - {a[1]}


def _names(tree):
    # Including constructor strings in this reserve set is harmless.
    if isinstance(tree, str):
        return {tree}
    if isinstance(tree, tuple):
        return set().union(*(_names(x) for x in tree))
    return set()


class _Fresh:
    def __init__(self, used):
        self.used = set(used)
        self.index = 0

    def new(self):
        while True:
            name = "_p" + str(self.index)
            self.index += 1
            if name not in self.used:
                self.used.add(name)
                return name


def _subst_term(t, x, replacement, supply):
    if isinstance(t, str):
        return replacement if t == x else t
    if t == 0:
        return t
    if t[0] != "R":
        return (t[0], *(_subst_term(y, x, replacement, supply) for y in t[1:]))
    _, n, a, u, v, h = t
    n = _subst_term(n, x, replacement, supply)
    a = _subst_term(a, x, replacement, supply)
    if x not in (u, v):
        binders = [u, v]
        for i, old in enumerate(binders):
            if old in term_free(replacement):
                new = supply.new()
                h = _subst_term(h, old, new, supply)
                binders[i] = new
        u, v = binders
        h = _subst_term(h, x, replacement, supply)
    return ("R", n, a, u, v, h)


def _subst_formula(a, x, replacement, supply):
    if a[0] == "=":
        return ("=", *(_subst_term(t, x, replacement, supply) for t in a[1:]))
    kind, y, body = a
    if y == x:
        return a
    if y in term_free(replacement):
        new = supply.new()
        body = _subst_formula(body, y, new, supply)
        y = new
    return (kind, y, _subst_formula(body, x, replacement, supply))


def substitute(a, x, replacement):
    """Capture-avoiding numerical substitution, including inside R updates."""
    validate_formula(a)
    validate_term(replacement)
    _name(x)
    supply = _Fresh(_names(a) | _names(replacement) | {x})
    return _subst_formula(a, x, replacement, supply)


def _gate(z, a, supply):
    if a[0] == "=":
        return ("=", ("C", z, 0, a[1]), ("C", z, 0, a[2]))
    kind, x, body = a
    if x in term_free(z):
        new = supply.new()
        body = _subst_formula(body, x, new, supply)
        x = new
    return (kind, x, _gate(z, body, supply))


def gate(z, a):
    """G_z(A), freshening numerical binders that would capture z."""
    validate_formula(a)
    validate_term(z)
    return _gate(z, a, _Fresh(_names(a) | _names(z)))


def prefix(a):
    word = ""
    while a[0] != "=":
        word += a[0]
        a = a[2]
    return word


def rank(a):
    return len(prefix(a))


def is_alternating(a):
    word = prefix(a)
    return not word or (word[-1] == "Q" and all(x != y for x, y in zip(word, word[1:])))


def _normalize(a, supply):
    if a[0] == "=":
        return a
    kind, x, body = a
    body = _normalize(body, supply)
    if kind == "Q" and rank(body) % 2:
        body = ("E", supply.new(), body)
    elif kind == "E" and not rank(body) % 2:
        y = supply.new()
        body = ("Q", y, _gate(y, body, supply))
    return (kind, x, body)


def normalize(a):
    """N: arbitrary Q/E words -> alternating words ending in Q."""
    validate_formula(a)
    return _normalize(a, _Fresh(_names(a)))


def _pad_to(a, target, supply):
    for current in range(rank(a), target):
        y = supply.new()
        a = ("E", y, a) if current % 2 else ("Q", y, _gate(y, a, supply))
    return a


def pad_to(a, target):
    """Iterated P, with P(A)=Q_y G_y A at even rank and E_y A at odd rank."""
    validate_formula(a)
    if not is_alternating(a) or type(target) is not int or target < rank(a):
        raise ValueError("padding needs alternating input and a rank at least its current rank")
    return _pad_to(a, target, _Fresh(_names(a)))


def _rename_prefix(a, names, supply):
    if not names:
        return a
    kind, old, body = a
    body = _subst_formula(body, old, names[0], supply)
    return (kind, names[0], _rename_prefix(body, names[1:], supply))


def align(a, b, target=None, parity=None, reserved=()):
    """Pad to a common rank and give both prefixes the same fresh names."""
    for formula in (a, b):
        validate_formula(formula)
        if not is_alternating(formula):
            raise ValueError("normalize before aligning")
    minimum = max(rank(a), rank(b))
    n = minimum if target is None else target
    if type(n) is not int or n < minimum or parity not in (None, 0, 1):
        raise ValueError("invalid common rank or parity")
    if parity is not None:
        if target is None:
            n += (parity - n) % 2
        elif n % 2 != parity:
            raise ValueError("the specified rank has the wrong parity")
    supply = _Fresh(_names(a) | _names(b) | set(reserved))
    a, b = _pad_to(a, n, supply), _pad_to(b, n, supply)
    names = [supply.new() for _ in range(n)]
    return _rename_prefix(a, names, supply), _rename_prefix(b, names, supply)


def selector(z, a, b, target=None, parity=None):
    """Align the prefixes and select their terminal equations using C_z."""
    _name(z)
    if z in formula_free(a) | formula_free(b):
        raise ValueError("the selector variable must be fresh for both operands")
    a, b = align(a, b, target, parity, reserved={z})
    binders = []
    while a[0] != "=":
        assert a[:2] == b[:2]
        binders.append(a[:2])
        a, b = a[2], b[2]
    result = ("=", ("C", z, a[1], b[1]), ("C", z, a[2], b[2]))
    for kind, name in reversed(binders):
        result = (kind, name, result)
    return result


def _simplify_term(t):
    if not isinstance(t, tuple):
        return t
    if t[0] == "R":
        _, n, a, u, v, h = t
        return ("R", _simplify_term(n), _simplify_term(a), u, v, _simplify_term(h))
    values = tuple(_simplify_term(x) for x in t[1:])
    if t[0] == "C":
        z, a, b = values
        if z == 0:
            return a
        if isinstance(z, tuple) and z[0] == "S":
            return b
    return (t[0], *values)


def simplify_conditionals(a):
    """Only C(0,a,b)=a and C(Sn,a,b)=b; no general evaluation oracle."""
    validate_formula(a)
    if a[0] == "=":
        return ("=", _simplify_term(a[1]), _simplify_term(a[2]))
    return (a[0], a[1], simplify_conditionals(a[2]))


def _term_key(t, environment):
    if isinstance(t, str):
        return ("bound", environment.index(t)) if t in environment else ("free", t)
    if t == 0:
        return 0
    if t[0] == "R":
        _, n, a, u, v, h = t
        return ("R", _term_key(n, environment), _term_key(a, environment),
                _term_key(h, (u, v) + environment))
    return (t[0], *(_term_key(x, environment) for x in t[1:]))


def _formula_key(a, environment=()):
    if a[0] == "=":
        return ("=", _term_key(a[1], environment), _term_key(a[2], environment))
    return (a[0], _formula_key(a[2], (a[1],) + environment))


def alpha_equivalent(a, b):
    """An independent de Bruijn-key comparison, including R's two binders."""
    validate_formula(a)
    validate_formula(b)
    return _formula_key(a) == _formula_key(b)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", nargs="?", default="normalize",
                        choices=("normalize", "gate", "pad", "selector"))
    parser.add_argument("file", nargs="?")
    args = parser.parse_args()
    if args.file:
        with open(args.file, encoding="utf-8") as stream:
            raw = json.load(stream)
    else:
        raw = json.load(sys.stdin)
    if args.operation == "normalize":
        result = normalize(freeze(raw))
    elif args.operation == "gate":
        result = gate(freeze(raw["selector"]), freeze(raw["formula"]))
    elif args.operation == "pad":
        result = pad_to(freeze(raw["formula"]), raw["rank"])
    else:
        result = selector(raw["variable"], freeze(raw["left"]), freeze(raw["right"]),
                          raw.get("rank"), raw.get("parity"))
    print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))


if __name__ == "__main__":
    main()
