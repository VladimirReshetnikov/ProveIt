"""Offline validation of the parameter-context certificate checker.

All source fixtures and their exact provenance are included. This program is
untrusted supporting evidence and is never imported by either checker.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import types

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_document(module, document, parameter_header=True):
    stream = copy.deepcopy(document)
    try:
        module.k = -len(stream.pop()) if parameter_header else 0
        module.take = stream.pop
        return bool(module.check(module.take(), []))
    except Exception:
        return False


def integer_atoms(value):
    if type(value) is int:
        return [value]
    if type(value) is list:
        return [n for child in value for n in integer_atoms(child)]
    return []


def canonical_document(source):
    # Every finite root formula has only finitely many numerical parameters.
    count = -min([0, *integer_atoms(source[-1])])
    return copy.deepcopy(source) + [[None] * count]


def formation(value, depth=0, sort='formula', parameters=3):
    """Explicit recursive grammar; no arity-sort table or packed depth."""
    if sort == 'term' and type(value) is int:
        return -parameters <= value <= depth
    if type(value) is not list:
        return False
    if sort == 'term':
        if len(value) == 1:
            return formation(value[0], depth, 'term', parameters)
        if len(value) == 3:
            return (formation(value[0], depth, 'term', parameters)
                    and formation(value[1], depth, 'term', parameters)
                    and formation(value[2], depth + 2, 'term', parameters))
    elif len(value) == 1:
        return formation(value[0], depth + 1, 'formula', parameters)
    elif len(value) == 2:
        return all(formation(child, depth, 'term', parameters) for child in value)
    elif len(value) == 3:
        return all(formation(child, depth + 1, 'formula', parameters) for child in value)
    return False


def grammar_checks(module):
    generator = random.Random(7112026)
    leaves = [None, False, True, 0, 0.0, 1, -1, -3, -4, '', {}, 'a']

    def tree(depth):
        if not depth or generator.randrange(3) == 0:
            return generator.choice(leaves)
        return [tree(depth - 1) for _ in range(generator.randrange(6))]

    count = 0
    for sort in ('term', 'formula'):
        for depth in range(4):
            for _ in range(200):
                value = tree(3)
                expected = formation(value, depth, sort)
                module.k = -3
                try:
                    module.inst(value, d=2 * depth + (sort == 'term'))
                    actual = True
                except Exception:
                    actual = False
                require(actual == expected,
                        repr(('formation', sort, depth, value, expected, actual)))
                count += 1
    return count


def reflexivity(term):
    major = [[0, term, 0], term]
    return [[], [], [major, [1, term]], [term, term]]


def focused_checks(module):
    cases = {
        'zero_reflexivity': (reflexivity(0), 0, True),
        'open_reflexivity': (reflexivity(-4), 4, True),
        'undeclared_parameter': (reflexivity(-4), 3, False),
        'false_equation': ([[], [0, [0]]], 0, False),
        'recursion_mismatch': ([[], [[0, 0, 0], [0]]], 0, False),
        'term_arity_two': ([[], [[0, 0], 0]], 0, False),
        'term_arity_four': ([[], [[0, 0, 0, 0], 0]], 0, False),
        'formula_arity_five': ([[], [[0, 0]] * 5], 0, False),
        'boolean_atom': ([[], [False, False]], 0, False),
        'float_atom': ([[], [0.0, 0.0]], 0, False),
        'free_bound_index': ([[], [1, 1]], 0, False),
        'malformed_padding': ([[], [[0, 0], False, [0, 0]]], 0, False)
    }
    records = []
    for name, (source, parameters, expected) in cases.items():
        actual = run_document(module, source + [[None] * parameters])
        require(actual == expected, 'Focused case failed: ' + name)
        records.append({'name': name, 'expected': expected, 'actual': actual})
    module.k = -3
    try:
        module.inst(1, [1], d=1)
    except Exception:
        pass
    else:
        raise AssertionError('A free positive replacement index was captured')
    require(module.inst([0, 0, 3], [-2], d=1) == [0, 0, -2],
            'Recursor outer-hole depth')
    require(module.inst([0, 0, 1], [-2], d=1) == [0, 0, 1],
            'Recursor bound value coordinate')
    require(module.inst([[2, 2]], [-2]) == [[-2, -2]],
            'Formula opening beneath a binder')
    records.extend({'name': name, 'expected': True, 'actual': True}
                   for name in ('capture_rejected', 'recursor_outer_hole',
                                'recursor_bound_value', 'nested_formula_hole'))
    return records


def cli_case(program, document, expected, optimize=False):
    with tempfile.TemporaryDirectory(prefix='ipra_certificate_') as directory:
        path = Path(directory) / 'certificate.json'
        path.write_text(json.dumps(document) + '\n')
        command = [sys.executable, *(['-O'] if optimize else []),
                   str(ROOT / program), str(path)]
        result = subprocess.run(command, capture_output=True, text=True)
    verdict = 'ACCEPT' if expected else 'REJECT'
    require(result.stdout.strip() == verdict,
            repr(('CLI verdict', program, optimize, result.stdout, result.stderr)))
    require(result.returncode == (0 if expected else 1),
            repr(('CLI status', program, optimize, result.returncode)))


def interface_checks(module):
    records = []
    for label, header in (
            ('empty_list', []), ('empty_string', ''), ('empty_object', {}),
            ('null_header', None), ('integer_header', 0), ('boolean_header', False)):
        document = reflexivity(0) + [header]
        expected = label.startswith('empty_')
        actual = run_document(module, document)
        require(actual == expected, label)
        cli_case('checker.py', document, expected)
        records.append({'name': label, 'expected': expected, 'actual': actual})
    for label, header in (
            ('four_list_entries', [None] * 4), ('four_characters', 'abcd'),
            ('four_object_keys', dict.fromkeys(('a', 'b', 'c', 'd')))):
        document = reflexivity(-4) + [header]
        require(run_document(module, document), label)
        cli_case('checker.py', document, True)
        records.append({'name': label, 'expected': True, 'actual': True})
    for label, document in (
            ('unread_prefix', [{'ignored': [False, None]}, *reflexivity(0), []]),
            ('unused_malformed_witness',
             [*reflexivity(0)[:-1], [None], [[0, 0], [0, 0], [0, 0]], []])):
        require(run_document(module, document), label)
        cli_case('checker.py', document, True)
        records.append({'name': label, 'expected': True, 'actual': True})
    used_witness = [[None], [[1, 1], [0, 0], [0, 0]], []]
    require(not run_document(module, used_witness), 'Used malformed witness')
    cli_case('checker.py', used_witness, False)
    records.append({'name': 'used_malformed_witness', 'expected': False, 'actual': False})
    return records


def mutant_controls(module):
    """Tests must notice removing either half of the freshness discipline."""
    major = [[1, 0], [0, 0], [0, 0]]
    false_source = [None, *reflexivity(0)[:-1], [0], [major, None], [-1, 0]]
    source = (ROOT / 'checker.py').read_text()
    controls = (
        ('freshness_decrement', '    k -= 1\n', '    k -= 0\n', [None]),
        ('declaration_guard', 'and a >= k:', ':', [])
    )
    records = []
    for name, old, new, header in controls:
        document = false_source + [header]
        require(not run_document(module, document), 'Real kernel accepted ' + name)
        require(source.count(old) == 1, 'Mutation no longer targets one location')
        mutant = types.ModuleType('deliberately_invalid_' + name)
        exec(compile(source.replace(old, new), '<invalid test control>', 'exec'),
             mutant.__dict__)
        require(run_document(mutant, document), 'Control did not expose ' + name)
        records.append({'name': name, 'real_kernel_accepts': False,
                        'deliberately_invalid_variant_accepts': True})
    return records


def main():
    kernel = load(ROOT / 'checker.py', 'parameter_context_kernel')
    closed = load(ROOT / 'checker_closed.py', 'closed_companion_kernel')
    provenance = json.loads((ROOT / 'validation/provenance.json').read_text())
    reference_path = ROOT / provenance['reference_checker']
    require(digest(reference_path) == provenance['reference_checker_sha256'],
            'Changed frozen reference checker')
    reference = load(reference_path, 'frozen_scope_kernel')
    replacements = {item['for']: item for item in provenance['replacements']}
    for item in replacements.values():
        require(digest(ROOT / item['file']) == item['sha256'], 'Changed replacement fixture')
    records = []
    target_values = []
    goal_values = []
    closed_count = 0
    for entry in provenance['theorems']:
        source_path = ROOT / entry['file']
        require(digest(source_path) == entry['sha256'], 'Changed source fixture: ' + entry['name'])
        source = json.loads(source_path.read_text())
        require(run_document(reference, source, False), 'Frozen reference rejected ' + entry['name'])
        original_goal = copy.deepcopy(source[-1])
        replacement = replacements.get(entry['name'])
        if replacement:
            source = json.loads((ROOT / replacement['file']).read_text())
            require(source[-1] == original_goal, 'Replacement changed the end formula')
            original = json.loads(source_path.read_text())

            def substitute_auxiliary(value):
                if type(value) is int and value == -6:
                    return 0
                if type(value) is list:
                    return [substitute_auxiliary(child) for child in value]
                return value

            require(substitute_auxiliary(original) == source,
                    'Replacement is not exactly the recorded auxiliary substitution')
        target = canonical_document(source)
        target_path = ROOT / entry['certificate']
        require(digest(target_path) == entry['certificate_sha256'],
                'Changed candidate certificate: ' + entry['name'])
        require(json.loads(target_path.read_text()) == target,
                'Certificate does not match its stated compilation')
        require(run_document(kernel, target), 'Candidate rejected ' + entry['name'])
        for optimize in (False, True):
            cli_case('checker.py', target, True, optimize)
        numerical_closure = not target[-1]
        require(run_document(closed, target[:-1], False) == numerical_closure,
                'Closed interface mismatch: ' + entry['name'])
        if numerical_closure:
            closed_count += 1
            for optimize in (False, True):
                cli_case('checker_closed.py', target[:-1], True, optimize)
        target_values.append(json.dumps(target, sort_keys=True))
        goal_values.append(json.dumps(original_goal, sort_keys=True))
        records.append({'name': entry['name'], 'parameters': len(target[-1]),
                        'replaced_auxiliary_witness': bool(replacement),
                        'candidate_sha256': digest(target_path)})
    grammar_count = grammar_checks(kernel)
    focused = focused_checks(kernel)
    interface = interface_checks(kernel)
    controls = mutant_controls(kernel)
    example_count = 0
    for path in sorted((ROOT / 'examples').glob('*.json')):
        document = json.loads(path.read_text())
        require(run_document(kernel, document), 'Example rejected: ' + path.name)
        cli_case('checker.py', document, True)
        example_count += 1
    result = {
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'kernel_sha256': digest(ROOT / 'checker.py'),
        'closed_kernel_sha256': digest(ROOT / 'checker_closed.py'),
        'source_commit': provenance['commit'],
        'source_archive': provenance['archive'],
        'frozen_source_certificates': len(records),
        'unique_public_certificates': len(set(target_values)),
        'distinct_serialized_end_formulas': len(set(goal_values)),
        'source_reference_acceptances': len(records),
        'candidate_acceptances': len(records),
        'root_parameter_count_range': [min(record['parameters'] for record in records),
                                       max(record['parameters'] for record in records)],
        'exact_auxiliary_substitutions': len(replacements),
        'closed_companion_acceptances': closed_count,
        'closed_companion_open_goal_rejections': len(records) - closed_count,
        'independent_grammar_checks': grammar_count,
        'focused_checks': len(focused),
        'public_interface_checks': len(interface),
        'deliberately_invalid_variant_controls': len(controls),
        'examples': example_count,
        'actual_cli_executions': 2 * len(records) + 2 * closed_count + len(interface) + example_count,
        'failed_checks': 0,
        'records': records,
        'focused_results': focused,
        'interface_results': interface,
        'invalid_variant_results': controls,
        'limitations': 'Finite implementation checks; no machine-checked general soundness, completeness, consistency, or bi-interpretability theorem. Cohorts overlap and must not be summed as distinct theorems.'
    }
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items()
                      if not key.endswith('_results') and key != 'records'}, indent=2))
    return result


if __name__ == '__main__':
    main()
