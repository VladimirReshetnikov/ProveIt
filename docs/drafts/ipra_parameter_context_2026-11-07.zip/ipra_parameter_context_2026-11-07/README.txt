A SMALLER CERTIFICATE KERNEL FOR FULL INTUITIONISTIC PRA
======================================================
Prepared for Vladimir Reshetnikov, 7 November 2026.

IMPLEMENTED RESULT
------------------
The complete primary acceptance program is below every coordinate of the
current finite comparison envelope:

                                  Tokens     AST nodes     UTF-8 bytes
  Current all-variant envelope       457           469           1352
  Current open-parameter envelope    460           469           1374
  Primary checker.py                450           468           1338
  Optional checker_closed.py        444           461           1319

These are normalized whole-program measures under CPython 3.12.14. The
comparison includes JSON input, parameter declarations, verdict handling,
and the rejection exit status. It includes all ten root acceptance
programs from all six archives in ProveIt/docs/drafts at:

  8b00e6ea50c664476e3a3289a78287946e5e0a34

The primary still accepts arbitrary finite free numerical parameters in
its root formula. Its improvement does not depend on restricting the
input to numerically closed sentences. It validates substitution images
when they are used; this demand policy is stated explicitly below.

The primary's uniformly measured core is 381 tokens / 392 AST nodes /
1052 bytes, compared with the current core envelope 397 / 404 / 1092.
The closed companion's core is 384 / 396 / 1059. Its module-level initial
parameter state is included in that core; the primary initializes its
state from the public parameter header in the counted CLI wrapper.

This is a strict result against a pinned finite corpus and a disclosed
Python measurement contract. The envelope is the coordinatewise minimum
of supplied implementations, not a proved universal lower bound. No
globally shortest axiomatization is claimed.

WHAT CHANGES
------------
An explicit finite numerical parameter context extends the earlier
declaration-before-use checker to open formulas. A header of length n
declares names -1 through -n; these names stand for arbitrary natural
numbers. Scope entry allocates a smaller negative name. The validator
therefore needs no whole-tree minimum scan to choose a fresh parameter.

A single constructor table is indexed by 2*arity+sort. Its valid rows
have exactly the right length, and every overlong node is out of range.
Validated-goal reuse and exact-arity traversal remove further redundant
implementation work. The current numerical and logical basis is retained
and credited; the arithmetic rules themselves are not newly deleted by
these source reductions. See ATTRIBUTION.txt for the detailed lineage.

MATHEMATICAL CONTENT
--------------------
The native numerical terms are zero, successor, and fixed finite
initialized primitive recursion. Native formulas are equality, existence,
and unary closure Q_x B, with ordinary meaning B(0) -> forall x B(x).

There are six primitive inference patterns and two recursion computation
schemas. Closure introduction retains B(0), and receives B(y) as an
induction hypothesis only when B is literally an equation. FORMAT.txt
states the full implemented syntax and rules. The complete report.tex and
compiled report.pdf provide the mathematical development, interpretations,
and qualifications; sections/ contains all included LaTeX sources.

SEPARATE MATHEMATICAL RESULT: ONE BINDER SYMBOL
----------------------------------------------
The report also proves an alternating formula theorem. Every native Q/E
formula has a single logical spine ending in an equation. Gates and
vacuous padding transform it into an equivalent formula whose binders
alternate and whose innermost binder is Q. The parity of the remaining
rank therefore determines whether each binder has the Q or E role.

This gives a faithful presentation with one written binder symbol and
phase-dependent rules. The report translates derivations into that
restricted grammar and preserves exactly the rank-zero, equation-only
induction restriction. It is not a claim of an unrestricted intuitionistic
prenex theorem or of a phase-independent logical connective.

alternating.py implements an UNTRUSTED formula normalizer supporting this
separate result. It is not imported by checker.py and is not included in
the measured acceptance boundary. Normalized formulas can be larger, and
no smaller implemented one-binder checker is claimed. See report.pdf,
Section 6, for the exact normalization and derivation-translation theorems.

The proof checkers do not import a logic library, proof generator, source
comparator, test oracle, or universal evaluator. Only the selected checker
and Python's standard json/sys support participate in acceptance.

START HERE
----------
  checker.py                  Entire primary acceptance program.
  checker_closed.py           Optional numerically closed interface.
  FORMAT.txt                  Complete public syntax and rule contract.
  examples/                   Five small primary certificates.
  certificates/               45 public certificates with explicit contexts.
  README.txt, ATTRIBUTION.txt  Scope, provenance, and contribution boundary.
  report.tex, report.pdf       Complete mathematical report and compiled PDF.
  sections/                   All included mathematical LaTeX sources.
  alternating.py              Untrusted alternating-formula normalizer.

REPRODUCE
---------
From this directory, using Python 3.10 or newer:

  python3 checker.py examples/reflexivity_zero.json
  python3 checker.py examples/reflexivity_parameter.json
  python3 checker.py examples/recursion_successor.json
  python3 reproduce.py

An accepted certificate prints ACCEPT and exits 0. A rejected input prints
REJECT and exits 1. The programs use no network. Exact normalized source
counts should be reproduced with CPython 3.12.14 because ast.unparse can
vary between Python versions.

For the optional closed interface, which has no parameter header:

  python3 checker_closed.py validation/reference/replacements/exists_reflexivity_closed.json

reproduce.py checks frozen source hashes, recomputes all current metrics,
reconstructs the candidate certificates from the included source fixtures,
and runs the primary validation, independent audit, and alternating-syntax
checks. It updates RESULTS.json and results/. measure.py and validate.py
may also be run separately. The original measurement module
is retained unchanged at comparison/source_measure.py; its own previous-
snapshot main entry point is not used.

PUBLIC INPUT
------------
The primary input is one JSON array:

  [ ... reversed proof instructions ..., goal, parameter_context ]

The header must be a JSON array, string, or object. Its decoded length n
declares the numerical names -1,...,-n. Its contents supply no assumptions
and no axioms. Canonical headers are arrays of null entries; [] declares
no free parameters. Headers that have no length are rejected.

The public checker always starts with an empty logical assumption context.
Free numerical parameters are different from logical assumptions. Negative
integers in formula syntax are variable names, not negative natural numbers.
Positive integers are bound coordinates; arithmetic one is [0], not 1.

An unused witness annotation may be malformed under the demand policy.
Whenever its numerical value is used, it is validated as a locally closed
term in the current parameter context. An unused annotation may be replaced
by the genuine numerical witness zero in the extracted mathematical proof.

Instructions are consumed from the right. As in the baselines, an unread
initial prefix is permitted. It contributes no hypotheses or computation.
The optional closed checker instead reads the older format without a final
header and initially permits no negative parameter names.

VALIDATION EVIDENCE
-------------------
All checks passed under CPython 3.12.14:

  45 frozen public source certificates accepted by the original checker;
  45 corresponding primary certificates accepted, with 43 distinct
     serialized end formulas;
  10 closed certificates accepted by the optional companion, and 35 open
     goals rejected at that narrower interface;
  1600 formation comparisons against an independent explicit grammar;
  16 focused formation, opening, scope, and false-equation checks;
  12 checks of header types, prefix handling, and demand witnesses;
  2 deliberate invalid-variant controls detecting broken freshness;
  5 small example certificates;
  127 actual CLI executions, including every main corpus certificate both
      normally and with python -O.

An independent audit adds 26 focused public-wrapper cases and one
deliberate-defect control. Its certificates are constructed independently
of the inherited corpus and proof generators; the public wrapper runs via
runpy. Those executions are separate from the 127 subprocess CLI checks
above. See validation/INDEPENDENT_AUDIT.txt and independent_results.json.

The normalizer's syntax checks run separately with:

  python3 validation/alternating_test.py

They exercise all Q/E prefix words of length at most ten, padding ranks,
capture-avoiding numerical substitution, gate and selector endpoints, and
the named-syntax CLI. Their counts and source hashes are recorded separately
in results/alternating.json. They do not check proofs of logical equivalence
or contribute to the count of accepted arithmetic certificates.

These cohorts overlap and are not summed as distinct theorems. All checks
start with empty logical assumptions except for scopes created by the
proof rules themselves. The main corpus uses root parameter-context sizes
from 0 through 92.

One original closed proof used auxiliary numerical name -6, absent from
its conclusion. Its replacement substitutes zero for that name. The same
zero-witness proof was already supplied in the baseline archive; both
files are retained. Reproduction checks the exact substitution and the
unchanged goal. The other 44 source certificates only receive a header.

Finite tests support the correspondence between code and rules. They do
not formally prove the general soundness, completeness, consistency, or
bi-interpretability theorems. The report's metatheory is mathematical,
not a Lean or Rocq formalization. Very large correct certificates may
exceed a concrete Python process's recursion or memory limits.

FILES FOR AUDIT
---------------
  comparison/manifest.json        All archive and comparator identities.
  comparison/sources/             Ten unchanged current root programs.
  comparison/source_measure.py    Unchanged upstream metric implementation.
  validation/provenance.json      Source fixture hashes and replacement record.
  validation/reference/           Unchanged original inputs.
  validation/independent_audit.py  Independently constructed wrapper tests.
  validation/INDEPENDENT_AUDIT.txt Independent scope and soundness review.
  validation/alternating_test.py  Syntax tests of the untrusted normalizer.
  results/metrics.json, .csv       Recomputed complete and core measures.
  results/validation.json          Individual cases and evidence counts.
  results/alternating.json         Separate normalizer results and hashes.
  RESULTS.json                    Combined reproduction summary.
  LICENSE_SOURCE.txt              Preserved upstream MIT No Attribution text.

The entire comparison is reproducible from this package. The original
ZIP archives are identified by hashes but are not duplicated here; only
the required root programs, source certificates, licenses, and provenance
are retained.
