"""Build the clean research archive and verify its file manifest."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED = {"build", "__pycache__"}


def members():
    return sorted(p for p in ROOT.rglob("*") if p.is_file()
                  and not EXCLUDED.intersection(p.relative_to(ROOT).parts)
                  and p.suffix != ".pyc" and p.name != "MANIFEST.sha256")


def main():
    files = members()
    manifest = "".join(
        hashlib.sha256(p.read_bytes()).hexdigest() + "  "
        + p.relative_to(ROOT).as_posix() + "\n" for p in files)
    manifest_path = ROOT / "MANIFEST.sha256"
    manifest_path.write_text(manifest)
    destination = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for p in sorted(files + [manifest_path]):
            name = ROOT.name + "/" + p.relative_to(ROOT).as_posix()
            entry = zipfile.ZipInfo(name, date_time=(2026, 11, 7, 12, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, p.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP integrity check failed")
        for line in manifest.splitlines():
            digest, relative = line.split("  ", 1)
            archived = archive.read(ROOT.name + "/" + relative)
            if hashlib.sha256(archived).hexdigest() != digest:
                raise ValueError("Manifest mismatch: " + relative)
    print(json.dumps({"archive": str(destination), "files": len(files) + 1,
                      "bytes": destination.stat().st_size,
                      "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
                      "manifest_verified": True}, indent=2))


if __name__ == "__main__":
    main()
