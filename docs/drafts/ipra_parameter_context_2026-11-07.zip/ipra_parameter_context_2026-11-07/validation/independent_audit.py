"""Independent focused audit of the declared-parameter kernel.

Exercises the actual public wrapper via runpy, without importing a baseline
checker, inherited corpus, or kernel-research validation utilities.
"""
from contextlib import redirect_stdout
from copy import deepcopy
import hashlib
import io
import json
from pathlib import Path
import runpy
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
CHECKER = ROOT.parent / 'checker.py'


def refl(term):
    """Proof segment for t=t, by R0 followed by equality transport."""
    equation = [[0, term, 0], term]
    return [[], [], [equation, [1, term]]]


def exists_eq(term):
    return refl(term) + [[term]], [[1, 1], [0, 0], [0, 0]]


def execute(path, certificate, name):
    location = ROOT / 'independent_cases' / (name + '.json')
    location.parent.mkdir(exist_ok=True)
    location.write_text(json.dumps(certificate, separators=(',', ':')) + '\n')
    saved_argv = sys.argv
    sys.argv = [str(path), str(location)]
    output = io.StringIO()
    status = 0
    namespace = None
    try:
        with redirect_stdout(output):
            try:
                namespace = runpy.run_path(str(path), run_name='__main__')
            except SystemExit as error:
                status = error.code
    finally:
        sys.argv = saved_argv
    return {'accepted': status == 0 and output.getvalue() == 'ACCEPT\n',
            'exit_status': status, 'output': output.getvalue().strip(),
            'final_supply': namespace['k'] if namespace else None}


def main():
    cases = []
    def add(name, stream, goal, header, expected, rationale, final_supply=None):
        cases.append({'name': name, 'document': stream + [goal, header],
                      'expected': expected, 'rationale': rationale,
                      'expected_final_supply': final_supply})

    add('zero_context_closed_reflexivity', refl(0), [0, 0], [], True,
        'The empty declaration context retains closed theorems.', 0)
    add('last_declared_parameter', refl(-2), [-2, -2], [None, None], True,
        'The boundary parameter -N is allowed.', -2)
    add('parameter_below_declared_floor', refl(-2), [-2, -2], [None], False,
        'A root parameter below -N is rejected before proof processing.')
    add('empty_context_does_not_admit_free_root', refl(-1), [-1, -1], [], False,
        'No undeclared free name is admitted at the root.')
    add('string_header_counts_codepoints', refl(-2), [-2, -2], 'a\u03bb', True,
        'The implementation accepts a string header and uses its character count.', -2)
    add('object_header_counts_keys', refl(-2), [-2, -2], {'a': 17, 'b': []}, True,
        'The implementation accepts a JSON object header and uses its key count.', -2)
    add('header_contents_are_inert', refl(-1), [-1, -1], [{'invalid': [False, 3.5]}], True,
        'Only the header length declares parameters; its elements are not syntax.', -1)
    for name, header in [('null', None), ('boolean', False), ('integer', 1),
                         ('float', 1.5)]:
        add('nonsized_header_' + name, refl(0), [0, 0], header, False,
            'A nonsized JSON scalar has no declaration length and is rejected.')
    add('header_cannot_supply_an_assumption', [None], [0, [0]], [[0, [0]]], False,
        'The public assumption context remains empty even if the header contains the goal.')

    major = [[1, 0], [0, 0], [0, 0]]
    major_stream = refl(0) + [[0]]
    capture = [None] + major_stream + [[major, None]]
    add('future_eigenname_in_root', capture, [-1, 0], [], False,
        'Without the declaration guard, existential elimination can capture a root parameter.')
    add('declared_name_not_reused_as_eigenname', capture, [-1, 0], [None], False,
        'Declaring -1 forces the elimination eigenname to -2, so x=0 is not proved.')

    stream, goal = exists_eq(-1)
    add('used_future_witness_rejected', stream, goal, [], False,
        'A used witness cannot mention a name that has not been declared or allocated.')
    add('used_declared_witness_allowed', stream, goal, [None], True,
        'The same witness is valid when declared.', -1)
    vacuous = [[0, 0], [0, 0], [0, 0]]
    add('unused_future_witness_is_inert', refl(0) + [[-500]], vacuous, [], True,
        'An unused witness is not active syntax and can be replaced by zero in extraction.', 0)
    add('unused_malformed_witness_is_inert', refl(0) + [[{'bad': [True, 3.5]}]],
        vacuous, [], True,
        'Demand validation permits irrelevant witness data; no malformed term is inserted.', 0)

    false_major = [[[[1], 1]]][0]
    # Q(x, Sx=x): its supplied step proof deliberately fails, after allocation.
    fallthrough_stream = [None, [], [false_major, None], []]
    add('failed_major_then_actual_hypothesis', fallthrough_stream, [[0, 0]], [], True,
        'A false elimination guard may fall back to a real hypothesis; the failed branch adds no assumptions.', -2)
    add('malformed_major_exception_does_not_fall_back', [[[], None], []],
        [[0, 0]], [], False,
        'A malformed major raises an exception and rejects even when the goal is a hypothesis.')
    add('out_of_context_major_does_not_fall_back', [[[-2, -2], None], []],
        [[0, 0]], [], False,
        'Undeclared annotation parameters are rejected before hypothesis fallthrough.')
    add('unused_declarations_still_reserve_names', [None, []], [[0, 0]],
        [None] * 4, True,
        'Freshness depends on the explicit context, including declarations absent from the goal.', -5)
    add('two_allocations_are_monotone', [None, [], []], [[[0, 0]]],
        [None] * 2, True,
        'Nested successful scopes allocate distinct names and never restore the global supply.', -4)

    add('dead_recursion_update_still_scoped', [[]], [[0, 0, -1], 0], [], False,
        'An inactive R0 update remains part of active term syntax and cannot hide an undeclared name.')
    add('declared_dead_recursion_update', [[]], [[0, 0, -1], 0], [None], True,
        'The same R0 equation is accepted with its update parameter declared.', -1)
    add('boolean_zero_alias_is_rejected', refl(False), [False, False], [], False,
        'Python equality False==0 cannot be exploited because Boolean term leaves fail validation.')

    rows = []
    for case in cases:
        actual = execute(CHECKER, deepcopy(case['document']), case['name'])
        passed = actual['accepted'] == case['expected']
        if case['expected_final_supply'] is not None:
            passed = passed and actual['final_supply'] == case['expected_final_supply']
        row = {k: v for k, v in case.items() if k != 'document'}
        row.update(actual)
        row['passed'] = passed
        rows.append(row)

    # Sensitivity control: the focused capture attack must find the exact
    # invariant that the new header architecture is intended to establish.
    source = CHECKER.read_text()
    if source.count(' and a >= k') != 1:
        raise AssertionError('Cannot identify the unique declaration guard')
    attack = next(c for c in cases if c['name'] == 'future_eigenname_in_root')
    with tempfile.TemporaryDirectory(prefix='ipra-invalid-control-') as temporary:
        mutant = Path(temporary) / 'invalid_checker.py'
        mutant.write_text(source.replace(' and a >= k', ''))
        control = execute(mutant, attack['document'], 'control_missing_guard_capture')
    control['expected_accepted'] = True
    control['passed'] = control['accepted']

    result = {
        'kernel': 'checker.py',
        'kernel_sha256': hashlib.sha256(CHECKER.read_bytes()).hexdigest(),
        'independent_cases': len(rows),
        'all_cases_passed': all(row['passed'] for row in rows),
        'cases': rows,
        'defect_control': control,
        'scope': 'Focused independent tests; no inherited corpus or proof generator is used. They support but do not prove soundness or completeness.'
    }
    (ROOT / 'independent_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'cases'}, indent=2))
    if not result['all_cases_passed'] or not control['passed']:
        raise AssertionError([row for row in rows if not row['passed']])


if __name__ == '__main__':
    main()
