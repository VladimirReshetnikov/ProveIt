#!/usr/bin/env python3
"""Finite tests of the untrusted alternating normalizer, not metatheorem proofs.

Run from any directory with Python 3.10+:
    python3 validation/alternating_test.py
The output is one JSON result object, suitable for a reproduction log.
"""

import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("alternating", ROOT / "alternating.py")
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
COUNTS = {"prefixes": 0, "substitution_commutations": 0, "gate_endpoints": 0,
          "selector_cases": 0, "selector_endpoints": 0, "focused_cases": 0, "cli_runs": 0}


def same(a, b):
    assert M.alpha_equivalent(a, b), (a, b)


def truth_spine(a):
    return ("=", 0, 0) if a[0] == "=" else (a[0], a[1], truth_spine(a[2]))


def contains(tree, item):
    return tree == item or (isinstance(tree, tuple) and any(contains(x, item) for x in tree))


def example(word):
    names = ["b" + str(i) for i in range(len(word))]
    first, last = (names[0], names[-1]) if names else ("x", "y")
    primitive = ("R", ("S", first), "a", "u", "v",
                 ("R", "v", "u", "r", "i", ("S", "r")))
    a = ("=", primitive, last)
    for kind, name in reversed(list(zip(word, names))):
        a = (kind, name, a)
    return a, primitive


def all_prefixes():
    replacement = ("C", "b0", "_p0", ("S", 0))
    for length in range(11):
        for letters in itertools.product("QE", repeat=length):
            word = "".join(letters)
            a, primitive = example(word)
            n = M.normalize(a)
            expected_rank = length + sum(x == y for x, y in zip(word, word[1:]))
            expected_rank += int(bool(word) and word[-1] == "E")
            assert M.rank(n) == expected_rank
            assert M.is_alternating(n)
            assert M.normalize(n) == n
            assert M.formula_free(n) == M.formula_free(a)
            assert contains(n, primitive), "N changed a source primitive term"
            COUNTS["prefixes"] += 1

            substituted = M.substitute(a, "a", replacement)
            same(M.normalize(substituted), M.substitute(n, "a", replacement))
            expected_free = (M.formula_free(a) - {"a"}) | M.term_free(replacement)
            assert M.formula_free(substituted) == expected_free
            COUNTS["substitution_commutations"] += 1

            zero = M.gate(0, n)
            successor = M.gate(("S", "b0"), n)
            assert M.rank(zero) == M.rank(successor) == M.rank(n)
            assert M.formula_free(successor) == M.formula_free(n) | {"b0"}
            same(M.simplify_conditionals(zero), truth_spine(n))
            same(M.simplify_conditionals(successor), n)
            COUNTS["gate_endpoints"] += 2


def selectors():
    for ra, rb, parity in itertools.product(range(11), range(11), (None, 0, 1)):
        a = M.pad_to(("=", "a", 0), ra)
        b = M.pad_to(("=", "b", ("S", 0)), rb)
        selected = M.selector("z", a, b, parity=parity)
        n = max(ra, rb)
        if parity is not None:
            n += (parity - n) % 2
        assert M.rank(selected) == n and M.is_alternating(selected)
        assert M.formula_free(selected) == {"a", "b", "z"}
        same(M.simplify_conditionals(M.substitute(selected, "z", 0)), M.pad_to(a, n))
        same(M.simplify_conditionals(M.substitute(selected, "z", ("S", "w"))), M.pad_to(b, n))
        aligned_a, aligned_b = M.align(a, b, parity=parity)
        assert M.prefix(aligned_a) == M.prefix(aligned_b)
        while aligned_a[0] != "=":
            assert aligned_a[:2] == aligned_b[:2]
            aligned_a, aligned_b = aligned_a[2], aligned_b[2]
        COUNTS["selector_cases"] += 1
        COUNTS["selector_endpoints"] += 2


def focused():
    # Substitution must freshen both shadowing logical binders.
    a = ("Q", "x", ("E", "x", ("=", "x", "a")))
    result = M.substitute(a, "a", "x")
    same(result, ("Q", "q", ("E", "e", ("=", "e", "x"))))
    assert M.formula_free(result) == {"x"}
    COUNTS["focused_cases"] += 1

    # R binds u,v in its update only, not in its counter/initializer.
    a = ("=", ("R", "x", "a", "u", "v", ("C", "u", "x", "v")), 0)
    result = M.substitute(a, "x", "u")
    expected = ("=", ("R", "u", "a", "fresh", "v", ("C", "fresh", "u", "v")), 0)
    same(result, expected)
    assert M.formula_free(result) == {"u", "a"}
    COUNTS["focused_cases"] += 1

    # The selector can share an old bound name; align must rename that binder.
    a = ("Q", "z", ("=", "z", "a"))
    b = M.normalize(("E", "x", ("=", "x", "b")))
    selected = M.selector("z", a, b)
    assert M.formula_free(selected) == {"z", "a", "b"}
    same(M.simplify_conditionals(M.substitute(selected, "z", 0)), M.pad_to(a, M.rank(selected)))
    same(M.simplify_conditionals(M.substitute(selected, "z", ("S", "w"))), M.pad_to(b, M.rank(selected)))
    COUNTS["focused_cases"] += 1

    # The fresh-name reserve includes previously used _p names and R binders.
    a = ("E", "x", ("=", ("R", "x", "_p0", "_p1", "_p2", "_p1"), "_p3"))
    n = M.normalize(a)
    assert n[2][1] == "_p4"
    assert M.formula_free(n) == {"_p0", "_p3"}
    COUNTS["focused_cases"] += 1

    # No substitution is permitted to change bound occurrences of its name.
    a = ("Q", "x", ("=", "x", ("R", 0, "x", "u", "v", "x")))
    assert M.substitute(a, "x", ("S", "x")) == a
    COUNTS["focused_cases"] += 1

    # APIs reject invalid syntax, forbidden capture, and impossible ranks.
    invalid = [
        lambda: M.normalize(("=", True, 0)),
        lambda: M.normalize(("=", 1, 0)),
        lambda: M.normalize(("=", ("R", 0, 0, "u", "u", 0), 0)),
        lambda: M.normalize(("Q", "", ("=", 0, 0))),
        lambda: M.selector("z", ("=", "z", 0), ("=", 0, 0)),
        lambda: M.pad_to(("E", "x", ("=", 0, 0)), 3),
        lambda: M.pad_to(("Q", "x", ("=", 0, 0)), 0),
        lambda: M.align(("=", 0, 0), ("=", 0, 0), target=2, parity=1),
    ]
    for operation in invalid:
        try:
            operation()
        except ValueError:
            pass
        else:
            raise AssertionError("invalid input was accepted")
        COUNTS["focused_cases"] += 1


def cli():
    examples = [
        ("normalize", ["Q", "x", ["Q", "y", ["=", "x", "y"]]]),
        ("gate", {"selector": ["S", "z"], "formula": ["Q", "z", ["=", "z", "a"]]}),
        ("pad", {"formula": ["=", "a", 0], "rank": 3}),
        ("selector", {"variable": "z", "left": ["=", "a", 0],
                      "right": ["Q", "x", ["=", "x", "b"]], "parity": 0}),
    ]
    for operation, payload in examples:
        process = subprocess.run([sys.executable, str(ROOT / "alternating.py"), operation],
                                 input=json.dumps(payload), capture_output=True, text=True, check=True)
        result = M.freeze(json.loads(process.stdout))
        M.validate_formula(result)
        if operation in ("normalize", "pad", "selector"):
            assert M.is_alternating(result)
        COUNTS["cli_runs"] += 1


if __name__ == "__main__":
    all_prefixes()
    selectors()
    focused()
    cli()
    hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in (ROOT / "alternating.py", Path(__file__).resolve())}
    print(json.dumps({"status": "PASS", "counts": COUNTS, "sha256": hashes}, indent=2))
