"""Measure the complete candidates and all ten pinned root comparators.

The source metric implementation is preserved unchanged from the upstream
arity-parameters archive. No measurement code participates in acceptance.
"""
import csv
import hashlib
import importlib.util
import json
import platform
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verified(entry):
    path = ROOT / entry['file']
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    require(digest == entry['sha256'], 'Changed frozen source: ' + entry['file'])
    return path


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    source = verified(manifest['measurement_source'])
    spec = importlib.util.spec_from_file_location('frozen_source_measure', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = []
    for archive in manifest['archives']:
        verified(archive['license'])
    for entry in manifest['programs']:
        rows.append({**entry, **module.metrics(verified(entry))})
    candidates = {name: module.metrics(ROOT / name)
                  for name in ('checker.py', 'checker_closed.py')}
    minimum = {key: min(row[key] for row in rows) for key in KEYS}
    open_rows = [row for row in rows if row['interface'] != 'closed sentences']
    open_minimum = {key: min(row[key] for row in open_rows) for key in KEYS}
    core_minimum = {key: min(row['core'][key] for row in rows) for key in KEYS}
    improvement = {name: {key: data[key] < minimum[key] for key in KEYS}
                   for name, data in candidates.items()}
    core_improvement = {name: {key: data['core'][key] < core_minimum[key]
                               for key in KEYS}
                        for name, data in candidates.items()}
    require(all(all(values.values()) for values in improvement.values()),
            'A complete candidate no longer beats every coordinate minimum')
    require(all(all(values.values()) for values in core_improvement.values()),
            'A candidate core no longer beats every coordinate minimum')
    result = {
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'repository': manifest['repository'],
        'commit': manifest['commit'],
        'archive_count': len(manifest['archives']),
        'root_comparator_count': len(rows),
        'coordinatewise_minimum': minimum,
        'arbitrary_parameter_minimum': open_minimum,
        'core_coordinatewise_minimum': core_minimum,
        'candidates': candidates,
        'strict_improvement': improvement,
        'strict_core_improvement': core_improvement,
        'programs': rows,
        'boundary': 'Entire Python source, including imports, input, verdict, and exit handling; actual docstrings removed; ast.unparse normalization.',
        'limitation': 'Finite-corpus implementation comparison, not a universal lower bound or absolute-minimality theorem.'
    }
    directory = ROOT / 'results'
    directory.mkdir(exist_ok=True)
    (directory / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (directory / 'metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream,
            ('label', 'interface', *KEYS, 'raw_bytes', 'sha256'), extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
        for name, data in candidates.items():
            writer.writerow({'label': 'candidate/' + name,
                             'interface': 'closed sentences' if 'closed' in name else 'declared arbitrary finite parameters',
                             **data})
    print(json.dumps({key: value for key, value in result.items()
                      if key != 'programs'}, indent=2))
    return result


if __name__ == '__main__':
    main()
