"""Compile the self-contained article with pdfLaTeX, without network access."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    engine = shutil.which('pdflatex')
    if engine is None:
        raise SystemExit('Install pdfLaTeX and the packages listed in report.tex.')
    for _ in range(2):
        process = subprocess.run([engine, '-interaction=nonstopmode',
                                  '-halt-on-error', 'report.tex'],
                                 cwd=ROOT, capture_output=True, text=True)
        if process.returncode:
            print(process.stdout[-6000:])
            raise SystemExit(process.returncode)
    print('Built report.pdf')


if __name__ == '__main__':
    main()
