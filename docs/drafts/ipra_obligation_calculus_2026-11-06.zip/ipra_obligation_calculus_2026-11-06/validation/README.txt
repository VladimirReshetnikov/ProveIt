Obligation checker validation
=============================

The only trusted project acceptance file is the parent checker.py.
Everything in this directory constructs or tests proofs; the checker imports
none of it. Python and json/sys are the common runtime boundary.

Run from any directory:
  python3 audit.py --checker /absolute/path/to/checker.py

When installed as validation/ under a deliverable containing checker.py, the
--checker argument may be omitted. All source paths are relative to this
validation directory. The driver verifies the exact frozen predecessor hash
and all 194 source-certificate hashes before translation. It regenerates
corpus/, examples/, translated_manifest.json, and results.json.

Files:
  reference_checker.py   Exact immediate predecessor reduction checker.
  source_manifest.json   Pinned repository/archive/source identities.
  source_corpus/         194 original accepted strict predecessor proofs.
  translate.py           Forward/backward proof adapters, independent of target.
  named_oracle.py        Attributed named-variable binding/substitution oracle.
  reference_rules.py     Attributed explicit-rule interpreter and targeted cases.
  audit.py               New focused candidate validation/reproduction driver.
  corpus/                Translated certificates, same literal statements.
  examples/              18 ordinary mathematical examples from that corpus.
  results.json           Recorded execution with hashes, counts, and failures.
  AUDIT.txt              Invariant proof and exact limits of the evidence.

Internal target check(a,p,g) success means exactly Boolean True. False and
exceptions reject. A normal return alone is NOT an acceptance signal.
The internal function assumes g is already validated; the real public CLI
validates every assumption. The validation wrapper reproduces this contract.

The oracle source is credited to the supplied ProveIt reduction draft and,
through that draft, its shared-transition predecessor. The corpus is inherited
with exact hashes. Finite tests are evidence about implementations and are not
claimed to mechanize the mathematical equivalence theorem or establish an
absolute minimality result.
