"""Focused independent audit of the iPRA obligation checker.

Run: python3 audit.py --checker /absolute/path/checker.py
The default checker is ../checker.py in a packaged deliverable. The only
candidate-specific adapter is candidate_accepts(), which treats True as
success and False or an exception as rejection. No validation file is
imported by the acceptance checker.
"""
import argparse
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys
import tempfile

from named_oracle import oracle, valid
from reference_rules import direct_cases, reference_check, TRUE, FALSE, ZERO, ONE, eq, reflexivity
from translate import forward, forward_proof, backward

HERE = Path(__file__).resolve().parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def candidate_accepts(checker, data):
    """Exactly reproduce the public CLI's checks on already-decoded data."""
    try:
        goal, proof, *context = data
        for hypothesis in context:
            checker.subst(hypothesis)
        return checker.check(goal, proof, context) is True
    except Exception:
        return False


def source_accepts(checker, data):
    try:
        goal, proof, *context = data
        for hypothesis in context:
            checker.subst(hypothesis)
        checker.check(goal, proof, context)
        return True
    except Exception:
        return False


def independent_accepts(data):
    try:
        return True, reference_check(backward(data), strict_witness=False)
    except Exception:
        return False, Counter()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def extra_cases():
    """Boundaries specific to Boolean propagation and erased markers."""
    def case(name, data, expected=False, category='changed_dispatch'):
        return {'name': name, 'data': data, 'expected': expected, 'category': category}
    pi = ['pi', TRUE, TRUE]
    ex = ['ex', TRUE]
    cases = [
        case('old use marker is not a target command',
             [TRUE, ['use', pi, 0, ZERO, 1], pi, TRUE]),
        case('old pack marker is not a target command',
             [ex, ['pack', ZERO, 0], TRUE]),
        case('anonymous existential pair is accepted',
             [['ex', eq(0, ZERO)], [ZERO, -1]], True),
        case('anonymous pair is not universal introduction',
             [pi, [ZERO, -1]]),
        case('anonymous pair is not an equality proof',
             [TRUE, [ZERO, -1], TRUE]),
        case('two-field explicit major cannot become valid witness',
             [ex, [pi, 0], pi]),
        case('existential pair recursor witness remains a term',
             [['ex', eq(0, ['r', ZERO, ZERO, ZERO])],
              [['r', ZERO, ZERO, ZERO], -1]], True),
        case('false branch propagates through anonymous existential pair',
             [ex, [ZERO, 0], FALSE]),
        case('false branch propagates through lambda',
             [pi, ['lam', 0], FALSE]),
        case('false major propagates before universal elimination',
             [TRUE, [pi, 0, ZERO, 1], TRUE, TRUE]),
        case('false minor propagates through universal elimination',
             [TRUE, [pi, 0, ZERO, 1], pi, FALSE]),
        case('false existential branch propagates',
             [TRUE, [ex, 0, 1], ex, FALSE]),
        case('non-equational cases cannot smuggle the step induction premise',
             [['pi', ['ex', eq(0, ZERO)], ['ex', eq(0, 1)]], ['nat', -1]]),
    ]
    return cases


def main(options):
    sys.dont_write_bytecode = True
    candidate_path = options.checker.resolve()
    source_path = HERE / 'reference_checker.py'
    manifest = json.loads((HERE / 'source_manifest.json').read_text())
    if digest(source_path) != manifest['source_checker_sha256']:
        raise ValueError('Frozen immediate predecessor changed')
    target = load(candidate_path, 'candidate_obligations')
    source = load(source_path, 'source_reduction')
    failures = []
    checks = Counter()
    rule_counts = Counter()
    records = []
    translations = []

    def record(category, name, ok):
        checks[category] += 1
        if not ok:
            failures.append({'category': category, 'name': name})

    # The public trusted boundary has no application-module imports or assert.
    tree = ast.parse(candidate_path.read_text())
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(a.name for a in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append('.' * node.level + (node.module or ''))
    record('static_boundary', 'imports are exactly json and sys', sorted(imports) == ['json', 'sys'])
    record('static_boundary', 'no assert erased by Python -O', not any(isinstance(n, ast.Assert) for n in ast.walk(tree)))
    record('static_boundary', 'no dynamic evaluation or importing', not any(
        isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
        and n.func.id in {'eval', 'exec', 'compile', '__import__'} for n in ast.walk(tree)))

    # All 194 accepted strict predecessor certificates, with literal statements.
    (HERE / 'corpus').mkdir(exist_ok=True)
    (HERE / 'examples').mkdir(exist_ok=True)
    corpus_cases = []
    for row in manifest['corpus']:
        path = HERE / row['file']
        if digest(path) != row['sha256']:
            raise ValueError('Source corpus changed: ' + row['file'])
        old = json.loads(path.read_text())
        new = forward(old)
        restored = backward(new)
        name = path.stem
        record('source_corpus', name, source_accepts(source, old))
        record('forward_translation', name, candidate_accepts(target, new))
        record('backward_translation', name, source_accepts(source, restored))
        record('literal_roundtrip', name, restored == old and forward(restored) == new)
        record('literal_statement', name, new[0] == old[0] and new[2:] == old[2:])
        record('independent_corpus', name, independent_accepts(new)[0])
        target_path = HERE / 'corpus' / path.name
        target_path.write_text(json.dumps(new, separators=(',', ':')) + '\n')
        if name.startswith('example_'):
            (HERE / 'examples' / (name.removeprefix('example_') + '.json')).write_bytes(target_path.read_bytes())
        translations.append({'source': row['file'], 'source_sha256': row['sha256'],
                             'candidate': 'corpus/' + path.name, 'candidate_sha256': digest(target_path),
                             'literal_roundtrip': restored == old,
                             'same_statement': new[0] == old[0] and new[2:] == old[2:]})
        corpus_cases.append({'name': name, 'data': new, 'expected': True, 'category': 'corpus'})

    direct = []
    for entry in direct_cases(strict_witness=False):
        entry = deepcopy(entry)
        source_data = entry['data']
        try:
            entry['data'] = forward(source_data)
        except Exception:
            entry['data'] = deepcopy(source_data)
        entry['source_data'] = source_data
        direct.append(entry)
    direct.extend(extra_cases())
    for case in direct:
        if 'source_data' in case:
            record('source_direct', case['name'], source_accepts(source, case['source_data']) == case['expected'])
        accepted, rules = independent_accepts(case['data'])
        record('independent_direct', case['name'], accepted == case['expected'])
        actual = candidate_accepts(target, case['data'])
        record('candidate_direct', case['name'], actual == case['expected'])
        if accepted:
            rule_counts.update(rules)
        records.append({'name': case['name'], 'category': case['category'],
                        'expected': case['expected'], 'independent_accepted': accepted,
                        'candidate_accepted': actual})
    for case in corpus_cases:
        rule_counts.update(independent_accepts(case['data'])[1])

    # Fixed binder cross-sections: no large random or mutation campaign.
    expressions = [
        (eq(0, 1), True),
        (['ex', eq(1, 0)], True),
        (['pi', eq(0, 1), ['ex', eq(2, 0)]], True),
        (['r', 0, 1, ['r', 2, 0, ['s', 4]]], False),
        (eq(['r', 0, ['s', 1], 2], ['r', ZERO, 2, 1]), True),
    ]
    environments = [(0,), (1,), [ZERO, -1], [['s', 0], 0], [ZERO, ['s', 0], -2]]
    for i, (expression, formula) in enumerate(expressions):
        for depth in (0, 1, 2):
            for j, environment in enumerate(environments):
                try:
                    expected = oracle(expression, environment, depth, formula)
                    actual = target.subst(expression, environment, depth, formula=formula)
                    good = actual == expected
                except Exception:
                    good = False
                record('named_substitution', f'{i}/{depth}/{j}', good)

    # Confirm both non-exceptional Boolean outcomes are used as advertised.
    for name, goal, proof, context, expected in [
        ('valid assumption returns True', TRUE, 0, [TRUE], True),
        ('wrong assumption returns False', FALSE, 0, [TRUE], False),
        ('wrong recursor reduct returns False', eq(['r', ZERO, ZERO, ZERO], ONE), 'r', [], False),
        ('wrong numerical base returns False', ['pi', FALSE, TRUE], ['nat', -1], [], False),
        ('failed major returns False', TRUE, [['pi', TRUE, TRUE], 0, ZERO, 1], [TRUE, TRUE], False),
        ('failed introduction child returns False', ['ex', TRUE], [ZERO, 0], [FALSE], False),
    ]:
        try:
            actual = target.check(goal, proof, context)
            good = type(actual) is bool and actual is expected
        except Exception:
            good = False
        record('boolean_result', name, good)

    def cli(path, payload, optimize=False, arguments=None, raw=False):
        if raw:
            path.write_text(payload)
        else:
            path.write_text(json.dumps(payload) + '\n')
        process = subprocess.run([sys.executable, *(['-O'] if optimize else []),
                                  str(candidate_path), *(arguments if arguments is not None else [str(path)])],
                                 capture_output=True, text=True, timeout=20)
        return process.returncode, process.stdout.strip(), process.stderr.strip()

    with tempfile.TemporaryDirectory(prefix='ipra-obligation-audit-') as temporary:
        path = Path(temporary) / 'certificate.json'
        # Every targeted case goes through the real public decoder and CLI once.
        for case in direct:
            expected = (0, 'ACCEPT', '') if case['expected'] else (1, 'REJECT', '')
            record('public_cli', case['name'], cli(path, case['data']) == expected)
        # Process-level coverage of all supplied theorem examples in both modes.
        examples = sorted((HERE / 'examples').glob('*.json'))
        for example in examples:
            data = json.loads(example.read_text())
            for optimize in (False, True):
                record('example_cli_optimized' if optimize else 'example_cli', example.stem,
                       cli(path, data, optimize=optimize) == (0, 'ACCEPT', ''))
        optimized_names = {
            'unproved falsity', 'pi cannot capture a free parameter',
            'quantified matrix does not receive induction hypothesis',
            'vacuous pi payload 0', 'used malformed witness 2',
            'existential eigenvariable escape 2', 'malformed unused hypothesis 8',
            'old use marker is not a target command', 'old pack marker is not a target command',
            'false branch propagates through anonymous existential pair',
            'false major propagates before universal elimination',
            'false minor propagates through universal elimination',
            'false existential branch propagates',
        }
        for case in direct:
            if case['name'] in optimized_names:
                expected = (0, 'ACCEPT', '') if case['expected'] else (1, 'REJECT', '')
                record('optimized_boundary', case['name'], cli(path, case['data'], optimize=True) == expected)
        raw_cases = [
            ('truncated JSON', '['),
            ('NaN in goal', '[["=",NaN,-1],0]'),
            ('Infinity in unused hypothesis', '[["=",-1,-1],0,["=",-1,-1],["=",Infinity,0]]'),
        ]
        for name, data in raw_cases:
            for optimize in (False, True):
                record('decoder_boundary', name + (' -O' if optimize else ''),
                       cli(path, data, optimize=optimize, raw=True) == (1, 'REJECT', ''))
        for name, arguments in [('no filename', []), ('extra filename', [str(path), str(path)]),
                                ('missing file', [str(Path(temporary) / 'absent.json')])]:
            record('argument_boundary', name,
                   cli(path, [], arguments=arguments) == (1, 'REJECT', ''))

    (HERE / 'translated_manifest.json').write_text(json.dumps(translations, indent=2) + '\n')
    report = {'candidate_sha256': digest(candidate_path), 'source_checker_sha256': digest(source_path),
              'python': platform.python_version(), 'source_commit': manifest['commit'],
              'audit_sha256': digest(Path(__file__)), 'translator_sha256': digest(HERE / 'translate.py'),
              'named_oracle_sha256': digest(HERE / 'named_oracle.py'),
              'reference_rules_sha256': digest(HERE / 'reference_rules.py'),
              'source_corpus_certificates': len(corpus_cases),
              'targeted_certificates': len(direct),
              'targeted_acceptances': sum(c['expected'] for c in direct),
              'targeted_rejections': sum(not c['expected'] for c in direct),
              'checks': dict(checks), 'total_checks': sum(checks.values()),
              'independent_rule_nodes': sum(rule_counts.values()), 'independent_rule_counts': dict(rule_counts),
              'failures': failures, 'case_results': records,
              'scope': 'Finite implementation evidence and source-certificate roundtrips; not a mechanized metatheory or consistency proof.'}
    options.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k:v for k,v in report.items() if k not in {'case_results'}}, indent=2))
    return not failures


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, default=HERE.parent / 'checker.py')
    parser.add_argument('--output', type=Path, default=HERE / 'results.json')
    raise SystemExit(0 if main(parser.parse_args()) else 1)
