"""Untrusted, sequent-preserving adapters for the obligation checker.

Source: frozen reduction checker ("use" and "pack" markers).
Target: Boolean obligation checker (both markers omitted).
No target helper is called. Backward reconstruction uses the independent
named-variable substitution oracle; annotations remain proof data.
"""
from copy import deepcopy
from named_oracle import oracle, named, valid
from reference_rules import uses_outer_variable


def ensure(condition):
    if not condition:
        raise ValueError('invalid translation input')


def forward_proof(proof):
    """Erase only proof-command markers; never traverse terms as proofs.

The broad handling of malformed use records is for negative tests. On
accepted source derivations all use records have their exact rule arity.
"""
    if type(proof) is not list or not proof:
        return deepcopy(proof)
    if proof[0] in ('lam', 'nat') and len(proof) == 2:
        return [proof[0], forward_proof(proof[1])]
    if proof[0] == 'pack' and len(proof) == 3:
        return [deepcopy(proof[1]), forward_proof(proof[2])]
    if proof[0] == 'use' and len(proof) >= 3:
        tail = deepcopy(proof[3:])
        if tail:
            tail[-1] = forward_proof(tail[-1])
        return [deepcopy(proof[1]), forward_proof(proof[2]), *tail]
    return deepcopy(proof)


def forward(data):
    ensure(type(data) is list and len(data) >= 2)
    goal, proof, *context = data
    return [deepcopy(goal), forward_proof(proof), *deepcopy(context)]


def minor_goal(major, annotation):
    ensure(valid(major, True))
    if major[0] == '=':
        return oracle(annotation, [major[1], -1])
    ensure(major[0] == 'pi')
    used = any(uses_outer_variable(named(part)) for part in major[1:])
    witness = annotation if used else -1
    ensure(valid(witness, False))
    return oracle(major[1], [witness, -1])


def backward_proof(goal, proof):
    """Restore a source derivation using each known expected conclusion.

For accepted target inputs this is total by the native-rule induction.
The routine rejects unrecognized proof data and does not pretend to prove
that arbitrary malformed certificates are meaningful.
"""
    ensure(valid(goal, True))
    if type(proof) in (int, bool) or proof == 'r':
        return deepcopy(proof)
    ensure(type(proof) is list)
    if goal[0] == 'pi' and len(proof) == 2 and proof[0] in ('lam', 'nat'):
        matrix = goal[2]
        child_goal = oracle(matrix, [['s', 0], 0]) if proof[0] == 'nat' else matrix
        return [proof[0], backward_proof(child_goal, proof[1])]
    if goal[0] == 'ex' and len(proof) == 2:
        return ['pack', deepcopy(proof[0]), backward_proof(goal[1], proof[1])]
    ensure(len(proof) >= 2 and type(proof[0]) is list)
    major, evidence, *arguments = proof
    ensure(valid(major, True))
    source_major = backward_proof(major, evidence)
    if major[0] == 'ex':
        ensure(len(arguments) == 1)
        return ['use', deepcopy(major), source_major,
                backward_proof(oracle(goal), arguments[0])]
    ensure(len(arguments) == 2)
    annotation, minor = arguments
    return ['use', deepcopy(major), source_major, deepcopy(annotation),
            backward_proof(minor_goal(major, annotation), minor)]


def backward(data):
    ensure(type(data) is list and len(data) >= 2)
    goal, proof, *context = data
    return [deepcopy(goal), backward_proof(goal, proof), *deepcopy(context)]
