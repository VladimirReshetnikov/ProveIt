Finite comparison corpus: ProveIt iPRA drafts
============================================

Pinned current repository commit:
edf7ea445673b29301012177998b0cc66bfabbf0

This census inspects the six current ZIP archives, verifies each Git blob
identity, and measures exact Python source bytes without importing or
executing any compared program. Genuine docstrings are removed; comments and
layout disappear under AST normalization. Executable constants and schema
tables remain counted. The common runtime is Python with json/sys.

Observed coordinatewise lower envelope (CPython 3.12.14):
  source tokens          603  (factored kernel)
  normalized tokens      603  (factored kernel)
  AST nodes              639  (goal-directed reduction)
  normalized UTF-8 bytes 1928  (goal-directed reduction)
  raw bytes             2007  (goal-directed reduction)

These coordinates do not all belong to one program. Being strictly below
this vector means beating every counted boundary in every chosen coordinate.
It says nothing about an absolute shortest possible iPRA axiomatization.

Current archives contain 1,482 Python-file occurrences / 338 distinct exact
sources. The declared/algorithmic selection retains 217 standalone or favorable
core-only boundaries and 74 historical dependency groups. It freezes 241 exact
sources. These sets overlap; their counts must not be added as distinct
candidate theories. Group members are measured together. A Hilbert fragment
has only 1,844 normalized bytes, but its imported syntax/arithmetic/CLI code is
part of its trusted boundary, and the complete group exceeds the envelope.
All excluded source identities and paths remain recorded in manifest.json.
This size inventory does not certify every historical program's soundness.

Run from any directory:
  python3 measure.py
  python3 measure.py --candidate /absolute/path/to/checker.py

The command rechecks source hashes, parses all frozen source files, recomputes
the complete finite comparison, and writes measurements.json. It uses only
Python's standard library. No source in sources/ is executed by measurement.

To rebuild the census from the original ZIPs, supply a directory containing
the six ZIP files and the original source manifest.json (copied from the
source_snapshot.json alongside the research package, if included):
  python3 build_census.py --archives-dir /absolute/path/to/original-zips

The classification includes inherited favorable core-only boundaries and
current json/sys-only check/infer acceptance modules. This choice is disclosed
rather than presented as a universal automatic recognition of proof checkers.
