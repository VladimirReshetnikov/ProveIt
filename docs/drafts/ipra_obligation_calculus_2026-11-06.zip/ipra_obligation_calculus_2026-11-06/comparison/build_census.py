"""Rebuild a finite source census from the six pinned current ZIP archives.

No compared source is executed. Source selection includes all inherited
standalone boundaries and dependency groups plus newly present json/sys
acceptance modules. Core-only inherited boundaries intentionally favor the
baseline. Classification is explicit, and does not endorse their soundness.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--archives-dir', type=Path, default=HERE.parent / 'sources')
args = parser.parse_args()
ROOT = args.archives_dir
manifest = json.loads((ROOT / 'manifest.json').read_text())
by_hash = {}
all_json = []
primary = []
occurrences = 0
for entry in manifest['files']:
    data = (ROOT / entry['name']).read_bytes()
    git_hash = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if git_hash != entry['sha'] or len(data) != entry['size']:
        raise ValueError('Archive identity mismatch: ' + entry['name'])
    with zipfile.ZipFile(ROOT / entry['name']) as archive:
        for member in archive.namelist():
            if member.endswith('.py'):
                raw = archive.read(member)
                h = hashlib.sha256(raw).hexdigest()
                row = by_hash.setdefault(h, {'raw': raw, 'origins': []})
                row['origins'].append({'archive': entry['name'], 'member': member})
                occurrences += 1
                if member.count('/') == 1 and member.endswith('/checker.py'):
                    primary.append({'archive': entry['name'], 'member': member,
                                    'sha256': h, 'git_blob': entry['sha']})
            if member.endswith('.json') and '/comparison/' in member:
                try:
                    obj = json.loads(archive.read(member))
                except Exception:
                    continue
                if isinstance(obj, dict):
                    all_json.append((entry['name'], member, obj))
standalone = set()
groups = {}
for archive, member, obj in all_json:
    for key in ['standalone', 'standalone_boundaries']:
        for item in obj.get(key, []):
            h = item if isinstance(item, str) else item.get('sha256') if isinstance(item, dict) else None
            if h in by_hash:
                standalone.add(h)
    for key in ['historical_groups', 'dependency_groups']:
        for group in obj.get(key, []):
            if not isinstance(group, dict):
                continue
            members = group.get('members', group.get('files', []))
            hashes = set()
            for item in members:
                h = item if isinstance(item, str) else item.get('sha256') if isinstance(item, dict) else None
                if h in by_hash:
                    hashes.add(h)
            # Do not accept a partly resolved dependency boundary.
            if not hashes or len(hashes) != len(set(
                    item if isinstance(item, str) else item.get('sha256')
                    for item in members if isinstance(item, (str, dict)))):
                continue
            identity = tuple(sorted(hashes))
            row = groups.setdefault(identity, {'members': list(identity), 'labels': [], 'origins': []})
            label = group.get('label', group.get('id', 'inherited declared boundary'))
            if label not in row['labels']:
                row['labels'].append(label)
            origin = {'archive': archive, 'member': member}
            if origin not in row['origins']:
                row['origins'].append(origin)
new_scan = []
for h, row in by_hash.items():
    tree = ast.parse(row['raw'].decode('utf-8'))
    names = {n.name for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    imports = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            imports.extend(x.name.split('.')[0] for x in n.names)
        elif isinstance(n, ast.ImportFrom):
            imports.append('.' if n.level else (n.module or '').split('.')[0])
    has_cli = any(isinstance(n, ast.If) and '__main__' in ast.unparse(n.test) for n in tree.body)
    if set(imports) <= {'json', 'sys'} and (
            names & {'check', 'infer'} or has_cli and names & {'accept', 'check_proof', 'verify'}):
        if h not in standalone:
            new_scan.append(h)
        standalone.add(h)
selected = standalone | {h for group in groups.values() for h in group['members']}
(HERE / 'sources').mkdir(exist_ok=True)
rows = []
for h in sorted(selected):
    row = by_hash[h]
    path = 'sources/' + h + '.py'
    (HERE / path).write_bytes(row['raw'])
    rows.append({'sha256': h, 'file': path, 'origins': row['origins']})
result = {'commit': manifest['commit'],
          'archives': manifest['files'],
          'boundary': 'Complete supplied acceptance programs: syntax, substitution, logical and arithmetic rules, JSON input, and rejection are counted. Python and json/sys are the common runtime. Genuine docstrings, comments, and layout are excluded by normalization. Imported application modules are counted jointly. Inherited favorable core-only boundaries are also included; this is a finite implementation comparison, not a soundness endorsement or global minimality proof.',
          'scan': {'python_occurrences': occurrences, 'distinct_python_sources': len(by_hash),
                   'standalone_or_favorable_core_boundaries': len(standalone),
                   'dependency_groups': len(groups), 'frozen_sources': len(rows),
                   'additional_scan_boundaries': len(new_scan)},
          'primary': primary, 'standalone_boundaries': sorted(standalone),
          'dependency_groups': list(groups.values()), 'sources': rows,
          'excluded_sources': [{'sha256':h, 'origins':row['origins'],
              'reason':'Not a selected acceptance boundary or recorded boundary dependency; inspected as support by the finite census.'}
              for h,row in sorted(by_hash.items()) if h not in selected]}
(HERE / 'manifest.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result['scan'], indent=2))
