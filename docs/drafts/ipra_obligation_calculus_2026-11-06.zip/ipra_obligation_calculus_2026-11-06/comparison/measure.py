"""Offline complete-program comparison. Comparison sources are parsed, never run.

Run: python3 measure.py [--candidate /absolute/path/checker.py]
The pinned source manifest and exact source bytes live beside this script.
All five source measures include complete acceptance, syntax, substitution,
logical/arithmetic rules, JSON input, and exception handling where supplied.
"""
import argparse
import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

HERE = Path(__file__).resolve().parent
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes', 'normalized_bytes', 'raw_bytes')
PRIMARY_FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
OWNERS = (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)


def docstrings(tree):
    for node in ast.walk(tree):
        if isinstance(node, OWNERS) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                yield first


def measure(data):
    source = data.decode('utf-8')
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    def position(line, column):
        return line, len(lines[line - 1].encode('utf-8')[:column].decode('utf-8'))
    spans = [(position(n.lineno, n.col_offset), position(n.end_lineno, n.end_col_offset))
             for n in docstrings(tree)]
    stripped = copy.deepcopy(tree)
    removed = {id(n) for n in docstrings(stripped)}
    for n in ast.walk(stripped):
        if isinstance(n, OWNERS):
            n.body = [b for b in n.body if id(b) not in removed]
    normalized = ast.unparse(stripped) + '\n'
    def tokens(text, omit=()):
        return sum(t.type not in IGNORED and not any(start <= t.start and t.end <= end
                   for start, end in omit)
                   for t in tokenize.generate_tokens(io.StringIO(text).readline))
    return {'sha256': hashlib.sha256(data).hexdigest(),
            'source_tokens': tokens(source, spans),
            'normalized_tokens': tokens(normalized),
            'ast_nodes': sum(1 for _ in ast.walk(stripped)),
            'normalized_bytes': len(normalized.encode('utf-8')),
            'raw_bytes': len(data)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', type=Path)
    parser.add_argument('--output', type=Path, default=HERE / 'measurements.json')
    args = parser.parse_args()
    manifest = json.loads((HERE / 'manifest.json').read_text())
    measurements = {}
    for row in manifest['sources']:
        result = measure((HERE / row['file']).read_bytes())
        if result['sha256'] != row['sha256']:
            raise ValueError('Comparison source hash mismatch: ' + row['file'])
        measurements[row['sha256']] = result
    boundaries = []
    for h in manifest['standalone_boundaries']:
        boundaries.append({'kind': 'standalone_or_favorable_core', 'members': [h],
                           **measurements[h]})
    for group in manifest['dependency_groups']:
        members = sorted(set(group['members']))
        boundaries.append({'kind': 'historical_dependency_group', 'members': members,
                           'labels': group['labels'],
                           **{key: sum(measurements[h][key] for h in members) for key in FIELDS}})
    envelope = {key: min(row[key] for row in boundaries) for key in FIELDS}
    primary = [{**row, **measurements[row['sha256']]} for row in manifest['primary']]
    result = {'commit': manifest['commit'], 'python': platform.python_version(),
              'boundary': manifest['boundary'], 'scan': manifest['scan'],
              'primary': primary, 'envelope': envelope,
              'minimum_witnesses': {key: [row['members'] for row in boundaries
                                       if row[key] == envelope[key]] for key in FIELDS},
              'sources': measurements, 'boundaries': boundaries}
    if args.candidate:
        candidate = measure(args.candidate.read_bytes())
        result['candidate'] = candidate
        result['strictly_below'] = {key: candidate[key] < envelope[key] for key in FIELDS}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in
                     ['commit', 'python', 'scan', 'envelope', 'primary',
                      'candidate', 'strictly_below'] if key in result}, indent=2))


if __name__ == '__main__':
    main()
