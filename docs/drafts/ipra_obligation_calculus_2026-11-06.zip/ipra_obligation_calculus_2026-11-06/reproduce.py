"""Reproduce the finite comparison and focused validation, entirely offline."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(relative, *arguments):
    subprocess.run([sys.executable, str(ROOT / relative), *map(str, arguments)],
                   cwd=ROOT, check=True)


def main():
    run('comparison/measure.py', '--candidate', ROOT / 'checker.py')
    metrics = json.loads((ROOT / 'comparison/measurements.json').read_text())
    if not all(metrics['strictly_below'].values()):
        raise RuntimeError('Candidate is not strictly below every recorded size coordinate')
    run('validation/audit.py')
    audit = json.loads((ROOT / 'validation/results.json').read_text())
    if audit['failures'] or metrics['candidate']['sha256'] != audit['candidate_sha256']:
        raise RuntimeError('Validation failure or inconsistent candidate identity')
    report = {'candidate': metrics['candidate'], 'envelope': metrics['envelope'],
              'strictly_below': metrics['strictly_below'],
              'source_commit': metrics['commit'], 'python': metrics['python'],
              'validation_checks': audit['total_checks'],
              'validation_failures': len(audit['failures']),
              'source_certificates': audit['source_corpus_certificates'],
              'targeted_certificates': audit['targeted_certificates'],
              'independent_rule_nodes': audit['independent_rule_nodes']}
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/summary.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: strict complete-program comparison and all focused checks.')


if __name__ == '__main__':
    main()
