"""Refresh an integrity manifest and package the complete deliverable."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'.aux', '.log', '.out', '.toc', '.pyc', '.fdb_latexmk', '.fls', '.synctex.gz'}


def included(path):
    return (path.is_file() and path.name != 'MANIFEST.sha256'
            and '__pycache__' not in path.parts
            and path.suffix not in EXCLUDED)


def main():
    files = sorted(p for p in ROOT.rglob('*') if included(p))
    rows = [hashlib.sha256(p.read_bytes()).hexdigest() + '  ' +
            p.relative_to(ROOT).as_posix() for p in files]
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text('\n'.join(rows) + '\n')
    destination = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in [*files, manifest]:
            archive.write(path, (Path(ROOT.name) / path.relative_to(ROOT)).as_posix())
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('ZIP integrity check failed')
    print(destination)
    print('SHA-256:', hashlib.sha256(destination.read_bytes()).hexdigest())
    print('Files:', len(files) + 1, 'Bytes:', destination.stat().st_size)


if __name__ == '__main__':
    main()
