A SMALLER COMPLETE CALCULUS FOR INTUITIONISTIC PRA
================================================
Prepared for Vladimir Reshetnikov -- 6 November 2026 (Pacific time)

RESULT

The complete 55-line checker has 595 normalized significant Python tokens,
620 executable AST nodes, and 1,876 normalized UTF-8 bytes. These are below
the componentwise observed minima of the six current supplied ProveIt drafts:
603 tokens, 639 AST nodes, and 1,928 normalized bytes. Its raw size is 1,956
bytes versus the current minimum of 2,007. All measurements include syntax
validation, substitution, logical and arithmetic rules, input decoding, CLI,
and success/rejection handling. No project module is imported by checker.py.

The contribution is a smaller COMPLETE PRESENTATION and proof checker.
The native mathematical basis and logical/arithmetic reconstruction are
inherited from the cited ProveIt draft series. Goals determine introduction
structure; mathematical obligations compose as Boolean results; redundant
use and pack certificate markers disappear. The mathematical theory is
unchanged. This is a strict finite-corpus improvement, not an absolute
minimality theorem among every possible language, runtime, or axiomatization.

MATHEMATICAL CONTENT

report.pdf specifies all logical and nonlogical rules. The theory uses
initialized recursion, equality, guarded universal quantification, existence,
and one numerical rule combining literal-equation induction with arbitrary
numerical cases. It derives full intuitionistic logic, all primitive recursive
functions, and all quantifier-free induction. Its ordinary faithful realization
is bi-interpretable with full first-order iPRA on the whole number domain.
Equality defines the internal double-interpretation isomorphisms.
Equiconsistency follows. These metatheorems are paper proofs, not a completed
Lean or Rocq formalization.

PINNED COMPARISON

Repository: VladimirReshetnikov/ProveIt
Commit: edf7ea445673b29301012177998b0cc66bfabbf0
Directory: docs/drafts
All six actual archive Git blob identities and sizes were verified.
The larger census contains 1,482 Python-file occurrences / 338 exact sources,
217 standalone or favorable inherited core boundaries, 74 historical
dependency groups, and 241 frozen source files. These sets overlap. The
envelope is unchanged by the historical boundaries. Detailed provenance
and exclusions are recorded in comparison/manifest.json.

VERIFICATION

All 1,913 recorded checks passed. The audit includes 194 inherited strict
certificates translated in both directions with identical sequents and
literal proof round trips; 155 targeted cases (48 accepted, 107 rejected);
75 named-variable substitution comparisons; Boolean propagation; malformed
public inputs; scope/eigenvariable restrictions; optimized Python; and actual
CLI checks. The independent rule interpreter replayed 6,018 inference
occurrences and calls no candidate helper. The categories overlap and are
not counts of independent theorems. Tests supplement the paper's arguments.

USAGE

Python 3.10+; recorded measurements use CPython 3.12.14.

  python3 checker.py examples/reflexivity.json
  python3 -O checker.py examples/forall_exists_successor.json
  python3 reproduce.py
  python3 build.py

The first two commands print ACCEPT and exit zero. Invalid certificates print
REJECT and exit one. The reproduction script checks the complete measured
boundary and validation suite offline, using only the Python standard library.
The PDF build requires pdfLaTeX and ordinary packages listed in report.tex.

The public certificate is [goal, proof, *hypotheses]. Read FORMAT.txt for the
exact grammar. The internal check(a,p,g) requires a validated context: exactly
True means success; False and exceptions mean rejection. The public CLI
validates every hypothesis, including unused ones. A vacuous universal witness
may be ignored and replaced by zero; every used witness, every existential
witness, every equality template, and every recursor body is fully validated.
All checks remain active under python -O.

FILES

  report.pdf, report.tex, sections/  Complete paper and LaTeX source.
  checker.py                       Entire project-specific acceptance boundary.
  FORMAT.txt, examples/             Certificate contract and theorem examples.
  comparison/                      Frozen sources, hashes, size measurements.
  validation/                      Oracle, adapters, corpora, tests, results.
  reproduce.py                     One-command offline verification.
  build.py                         Compile the supplied paper twice.
  package.py                       Rebuild checksums and ZIP archive.
  source_snapshot.json             Original six archive identities.
  ATTRIBUTION.txt                   Source contributions and exact provenance.
  LICENSE_SOURCE.txt               Verified ProveIt MIT No Attribution license.
  MANIFEST.sha256                  Integrity hashes of all other deliverables.

Fixed machine resources can reject very large valid certificates; mathematical
completeness is for the ideal finite-tree algorithm with unbounded resources.

CHECKER SHA-256
98ea2ac02323298e23569a2770afc3858c9cce251e777936e7139b98bdd8ff9d
