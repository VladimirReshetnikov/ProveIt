#!/usr/bin/env python3
"""Run the finite audits and compile the complete research paper."""

from pathlib import Path
import json
import shutil
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parent
    verification = root / 'verification'
    verification.mkdir(exist_ok=True)
    for script, name in (
        ('check_bit_schema.py', 'schema'),
        ('check_bit_semantics.py', 'semantics'),
    ):
        result = subprocess.run(
            [sys.executable, str(root / 'checks' / script)],
            cwd=root, text=True, capture_output=True, check=True,
        )
        parsed = json.loads(result.stdout)
        (verification / (name + '.json')).write_text(
            json.dumps(parsed, indent=2) + '\n', encoding='utf-8'
        )
        print(name + ': checks passed')
    if shutil.which('pdflatex') is None:
        raise SystemExit('Checks passed, but pdflatex is needed to build the PDF.')
    build = root / '.build'
    build.mkdir(exist_ok=True)
    for pass_number in (1, 2):
        result = subprocess.run(
            ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
             '-file-line-error', '-output-directory=.build', 'report.tex'],
            cwd=root, text=True, capture_output=True,
        )
        (build / ('pass_' + str(pass_number) + '.txt')).write_text(
            result.stdout + result.stderr, encoding='utf-8'
        )
        if result.returncode:
            print(result.stdout[-6000:], file=sys.stderr)
            raise SystemExit(result.returncode)
    log = (build / 'report.log').read_text(encoding='utf-8')
    if 'undefined references' in log or 'undefined citations' in log:
        raise SystemExit('Unresolved cross-references: inspect .build/report.log.')
    shutil.copyfile(build / 'report.pdf', root / 'report.pdf')
    print('report.pdf: compiled successfully')
    if 'Overfull' in log:
        print('Layout warning: inspect overfull boxes in .build/report.log.')


if __name__ == '__main__':
    main()
