#!/usr/bin/env python3
"""Finite standard-model checks for the equality-bit counter-recursion theory.

These checks are not a formal proof, an induction-schema verification on all
models, or a substitute for the paper's interpretation and round-trip proofs.
The program uses only Python's standard library.  Pairing projections are
evaluated from the actual scalar recursors; Python bit_length and valuation
oracles are deliberately not used.
"""

from __future__ import annotations

import json
import random
from functools import lru_cache


class TermLanguage:
    """Interned finite syntax; descriptor bodies are fixed syntactic indices."""

    def __init__(self):
        self.nodes = []
        self.intern = {}

    def node(self, op, args=(), body=None):
        key = (op, tuple(args), body)
        if key not in self.intern:
            self.intern[key] = len(self.nodes)
            self.nodes.append(key)
        return self.intern[key]

    def var(self, index):
        return self.node("var", (index,))

    def succ(self, term):
        return self.node("S", (term,))

    def bit(self, left, right):
        return self.node("B", (left, right))

    def rec(self, body, count, seed):
        assert self.free(body) <= {2, 3}, "Only v,w may occur in a body"
        return self.node("R", (count, seed), body)

    @lru_cache(None)
    def free(self, term):
        op, args, _ = self.nodes[term]
        if op == "var":
            return frozenset(args)
        if op == "0":
            return frozenset()
        return frozenset().union(*(self.free(arg) for arg in args))

    @lru_cache(None)
    def size(self, term):
        op, args, _ = self.nodes[term]
        if op in ("var", "0"):
            return 1
        return 1 + sum(self.size(arg) for arg in args)

    @lru_cache(None)
    def occurrences(self, term, index):
        op, args, _ = self.nodes[term]
        if op == "var":
            return int(args[0] == index)
        return sum(self.occurrences(arg, index) for arg in args)

    def substitute(self, term, replacements):
        """Substitute active slots only; never rewrite a stored descriptor."""
        op, args, body = self.nodes[term]
        if op == "var":
            return replacements.get(args[0], term)
        if op == "0":
            return term
        changed = tuple(self.substitute(arg, replacements) for arg in args)
        return self.node(op, changed, body)

    @lru_cache(None)
    def evaluate(self, term, environment):
        op, args, body = self.nodes[term]
        if op == "0":
            return 0
        if op == "var":
            return environment[args[0]]
        if op == "S":
            return self.evaluate(args[0], environment) + 1
        if op == "B":
            return int(self.evaluate(args[0], environment)
                       != self.evaluate(args[1], environment))
        if op == "R":
            count = self.evaluate(args[0], environment)
            state = self.evaluate(args[1], environment)
            for counter in range(count):
                state = self.evaluate(body, (0, 0, state, counter))
            return state
        raise ValueError(op)


language = TermLanguage()
zero = language.node("0")
n, a, v, w = (language.var(i) for i in range(4))
S = language.succ
B = language.bit
R = language.rec
one = S(zero)


def Q(x, y):
    return R(w, x, y)


def predecessor(x):
    return Q(x, zero)


def Z(x, y):
    return R(zero, x, y)


def choose(r, b, c):
    return Q(Z(r, S(b)), Z(Z(r, one), c))


def add(x, y):
    return R(S(v), y, x)


def subtract(x, y):
    return R(predecessor(v), y, x)


def parity(x):
    return R(Z(v, one), x, zero)


def double(x):
    return add(x, x)


def half(x):
    return R(choose(parity(w), v, S(v)), x, zero)


def power_two_times(x, seed):
    return R(double(v), x, seed)


strip_zero_body = choose(parity(v), half(v), v)
strip_one_body = choose(parity(v), half(v), S(S(v)))


def U(x):
    return R(strip_zero_body, x, x)


def W(x):
    return R(strip_one_body, x, x)


def pair(x, y):
    return power_two_times(x, S(double(y)))


def left_projection(x):
    return subtract(x, half(subtract(W(x), U(x))))


def right_projection(x):
    return half(U(x))


def eq(left, right):
    return ("eq", left, right)


false = ("false",)


def connective(op, *args):
    return (op, *args)


@lru_cache(None)
def compile_truth(formula):
    op, *args = formula
    if op == "false":
        return one
    if op == "eq":
        return B(*args)
    if op == "not":
        return B(compile_truth(args[0]), one)
    left, right = map(compile_truth, args)
    if op == "and":
        return choose(left, right, one)
    if op == "or":
        return choose(left, zero, right)
    if op == "implies":
        return choose(left, right, zero)
    raise ValueError(op)


def evaluate_formula(formula, environment):
    op, *args = formula
    if op == "false":
        return False
    if op == "eq":
        return language.evaluate(args[0], environment) == language.evaluate(
            args[1], environment)
    if op == "not":
        return not evaluate_formula(args[0], environment)
    left = evaluate_formula(args[0], environment)
    right = evaluate_formula(args[1], environment)
    if op == "and":
        return left and right
    if op == "or":
        return left or right
    if op == "implies":
        return not left or right
    raise ValueError(op)


def formula_size(formula):
    op, *args = formula
    if op == "false":
        return 1
    if op == "eq":
        return 1 + sum(language.size(term) for term in args)
    if op == "forall":
        return 1 + formula_size(args[1])
    return 1 + sum(formula_size(arg) for arg in args)


def all_(index, formula):
    return ("forall", index, formula)


def main_template(u, old=False, rooted=False):
    body = language.substitute(u, {0: v, 1: w})
    sigma = connective("implies", eq(zero, one), false)
    base = eq(R(body, zero, a), a)
    update = eq(R(body, S(n), a), language.substitute(
        u, {0: R(body, n, a), 1: n}))
    payload = connective("and", sigma, connective("and", base, update))
    if old:
        e = eq(u, language.substitute(u, {1: S(a)}))
        e_step = eq(language.substitute(u, {0: S(n)}),
                    language.substitute(u, {0: S(n), 1: S(a)}))
        p = connective("or", eq(n, zero), e)
        antecedent = all_(0, connective("implies", p, e_step))
        conclusion = p
    elif rooted:
        e = eq(u, zero)
        e_step = eq(language.substitute(u, {0: S(n)}), zero)
        p = connective("or", eq(n, zero), e)
        antecedent = all_(0, connective("implies", p, e_step))
        conclusion = p
    else:
        e = eq(u, zero)
        e_base = eq(language.substitute(u, {0: zero}), zero)
        e_step = eq(language.substitute(u, {0: S(n)}), zero)
        antecedent = connective("and", e_base,
            all_(0, connective("implies", e, e_step)))
        conclusion = e
    return all_(1, all_(0, connective("and", payload,
        connective("implies", antecedent, conclusion))))


def run():
    counts = {}
    samples = {
        "0": zero, "n": n, "a": a, "S(n)": S(n), "S(a)": S(a),
        "R_p(n,a)": R(predecessor(v), n, a),
        "B(n,a)": B(n, a),
        "C(n,a,S(a))": choose(n, a, S(a)),
    }
    for name, u in samples.items():
        m = language.size(u)
        i = language.occurrences(u, 0)
        j = language.occurrences(u, 1)
        actual_new = formula_size(main_template(u))
        actual_old = formula_size(main_template(u, old=True))
        actual_rooted = formula_size(main_template(u, rooted=True))
        assert actual_new == 33 + 5*m + 3*i
        assert actual_old == 35 + 7*m + 4*i + 3*j
        assert actual_rooted == 38 + 4*m + 3*i
        assert actual_old - actual_new == 2 + 2*m + i + 3*j
        counts[name] = {"m": m, "i": i, "j": j,
                        "old": actual_old, "ordinary": actual_new,
                        "rooted": actual_rooted}

    bit_definition = all_(0, all_(1, connective("and",
        connective("implies", eq(n, a), eq(B(n, a), zero)),
        connective("implies", connective("implies", eq(n, a), false),
                   eq(B(n, a), one)))))
    assert formula_size(bit_definition) == 24

    stored_body = B(v, w)
    example = R(stored_body, n, a)
    changed = language.substitute(example, {0: S(n), 1: S(a)})
    assert language.nodes[changed][2] == stored_body

    basic_checks = 0
    q = Q(n, a)
    z = Z(n, a)
    p = predecessor(n)
    h = half(n)
    rho = parity(n)
    addition = add(n, a)
    difference = subtract(n, a)
    for first in range(20):
        for second in range(20):
            env = (first, second, 0, 0)
            expected = (
                second if first == 0 else first-1,
                second if first == 0 else 0,
                max(first-1, 0), first//2, first % 2,
                first+second, max(first-second, 0),
            )
            observed = tuple(language.evaluate(term, env)
                             for term in (q, z, p, h, rho, addition, difference))
            assert observed == expected, (first, second, observed, expected)
            basic_checks += len(expected)

    selector_checks = 0
    selector = choose(n, a, S(a))
    for r in range(10):
        for seed in range(10):
            expected = seed if r == 0 else seed+1
            assert language.evaluate(selector, (r, seed, 0, 0)) == expected
            selector_checks += 1

    atoms = [false, eq(n, a), eq(S(n), a), eq(predecessor(n), a),
             eq(subtract(n, a), zero), eq(B(n, a), zero)]
    formulas = list(atoms)
    formulas += [connective("not", atom) for atom in atoms]
    for op in ("and", "or", "implies"):
        formulas += [connective(op, left, right)
                     for left in atoms for right in atoms]
    rng = random.Random(20261102)
    for _ in range(500):
        if rng.randrange(5) == 0:
            formulas.append(connective("not", rng.choice(formulas)))
        else:
            formulas.append(connective(rng.choice(("and", "or", "implies")),
                                       rng.choice(formulas), rng.choice(formulas)))
    truth_checks = 0
    for formula in formulas:
        truth_term = compile_truth(formula)
        assert language.free(truth_term) <= {0, 1}
        for first in range(7):
            for second in range(7):
                env = (first, second, 0, 0)
                value = language.evaluate(truth_term, env)
                truth = evaluate_formula(formula, env)
                assert value in (0, 1)
                assert (value == 0) == truth
                truth_checks += 1

    pairing_checks = 0
    pair_term = pair(n, a)
    left_term = left_projection(n)
    right_term = right_projection(n)
    largest_code = 0
    for first in range(4):
        for second in range(4):
            code = language.evaluate(pair_term, (first, second, 0, 0))
            assert code == 2**first * (2*second+1)
            largest_code = max(largest_code, code)
            env = (code, 0, 0, 0)
            assert language.evaluate(left_term, env) == first
            assert language.evaluate(right_term, env) == second
            pairing_checks += 2

    print(json.dumps({
        "status": "passed",
        "scope": "Finite standard-N checks only; not a formal or all-model proof.",
        "bit_definition_nodes_in_ordinary_fol": formula_size(bit_definition),
        "template_counts": counts,
        "active_substitution_preserves_stored_descriptor": True,
        "basic_arithmetic_equalities_checked": basic_checks,
        "selector_evaluations_checked": selector_checks,
        "truth_formulas": len(formulas),
        "truth_formula_assignments_checked": truth_checks,
        "pairing_projection_equalities_checked": pairing_checks,
        "pairing_coordinate_range": [0, 3],
        "largest_pairing_code": largest_code,
        "interned_syntax_nodes": len(language.nodes),
        "memoized_term_evaluations": language.evaluate.cache_info().currsize,
    }, indent=2))


if __name__ == "__main__":
    run()
